# LFUS notes — 0001628280-26-009585


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001628280-26-009585:notes:1]
Portions of the Littelfuse, Inc. Proxy Statement for the 2026 Annual Meeting of Stockholders (the “Proxy Statement”) are incorporated by reference into Part III of this Form 10-K.


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0001628280-26-009585:notes:2]
The cybersecurity and data protection program at Littelfuse is based on foundational principles outlined in applicable industry and internationally accepted-cybersecurity frameworks. The Company has experienced and will continue to experience cyber-attacks, attempts to breach its systems, and other similar incidents, however we do not believe that the prior cyber incidents have materially affected or are reasonably likely to materially affect the Company. Littelfuse faces risks from cybersecurity threats that could have a material adverse effect on its business, financial condition, results of operations, cash flows, or reputation. Like all cybersecurity programs, there is no guarantee that every attack method and technique has been fully addressed, as these change constantly, but Littelfuse is diligent in its attempts to protect data of the Company and its stakeholders.

[0001628280-26-009585:notes:3]
Littelfuse strives to assess and update its cybersecurity program on a regular basis using an Information Security Management System ("ISMS") comprised of three main elements – 1) independent internationally recognized vendors and technologies for

[0001628280-26-009585:notes:4]
assessments and monitoring, 2) strong internal controls based on industry standards, and 3) Board and Senior Leadership governance and support.

[0001628280-26-009585:notes:5]
The ISMS within Littelfuse consists of internationally recognized program elements that reduce the risk of an operational or cybersecurity incident from significantly impacting Littelfuse and its customers, vendors, and employees. These ISMS elements include but are not limited to:

[0001628280-26-009585:notes:6]
Security Awareness and Training – Littelfuse has an IT security awareness program consisting of training on the fundamentals of information security protection.  These training courses are provided annually.

[0001628280-26-009585:notes:7]
Network Protection – Network protection, detection, and monitoring technologies have been deployed on all external and internal network connections to segment different sections of the business from each other to strengthen key protection capabilities.

[0001628280-26-009585:notes:8]
Identity and Access Management ("IAM") – Littelfuse has implemented user authentication controls on its systems, devices, data, and applications. In addition, multi-factor authentication is implemented for all personnel who remotely access or have privileged account access to Littelfuse systems and networks.

[0001628280-26-009585:notes:9]
Data Classification and Protection – Littelfuse has implemented data loss prevention and classification labels and encryption on its internal unstructured data to prevent unauthorized data loss and data sharing. Structured data in ERP systems and core business systems are encrypted and protected by industry cybersecurity standards and procedures.

[0001628280-26-009585:notes:10]
Endpoint Protection – Littelfuse has implemented anti-virus, malware, and endpoint protection management detection and monitoring solutions on end-user devices and servers. Logs and alerts from these monitoring solutions are routed to independent third-party monitoring vendors that provide 24/7 monitoring, around the world.

[0001628280-26-009585:notes:11]
Threat and Vulnerability Management – Littelfuse uses an internationally recognized managed security services provider ("MSSP") and technologies to collect security alert and audit logs on a 24/7 basis, monitor and assess latest threat intelligence, provide analysis on new identified potential vulnerabilities, and provide response and support services to rapidly reduce any identified vulnerabilities.

[0001628280-26-009585:notes:12]
Security Incident Management – Security incident response plans and procedures have been developed in collaboration with our MSSP. They allow us to assess potential threats, first and second level notification and response protocols, and supporting notification protocols – both internally and externally. These plans, procedures, and protocols are tested and updated on a regular basis.

[0001628280-26-009585:notes:13]
Resiliency and Contingency Planning – Risk assessments are performed on a regular basis to assess the IT risk of single points of failure, security maturity, and security vulnerabilities. The results of these assessments are used to define various resiliency and contingency mitigation strategies, corrective action plans, on-site and remote data back-up strategies and technologies and allocation of IT resources.

[0001628280-26-009585:notes:14]
Assessments and testing – Littelfuse engages third party specialists to conduct periodic assessments and testing of our policies, standards, processes, and practices that are designed to address cybersecurity threats. These efforts include tabletop exercises, risk assessments, vulnerability testing, and other exercises focused on evaluating the effectiveness of our cybersecurity program. We adjust our cybersecurity program where appropriate based on the internal and external assessments and testing results.

[0001628280-26-009585:notes:15]
Governance


## cyd:CybersecurityRiskBoardCommitteeOrSubcommitteeResponsibleForOversightTextBlock

[0001628280-26-009585:notes:16]
The Audit Committee of the Board of Directors is tasked with overseeing the Company’s cybersecurity program as a part of its broader compliance oversight mandate. The Company’s Chief Information Officer ("CIO") and Chief Information Security Officer (“CISO”) are responsible for its cybersecurity program and regularly provide updates to the Littelfuse Executive Leadership Team (“ELT”) and the Audit Committee, as well as the full Board, which include information regarding our cybersecurity program initiatives, insurance coverage, acquisition integration processes, program performance as well as the maturity of the Littelfuse cybersecurity program. These cybersecurity maturity updates are based on cybersecurity maturity reporting and analysis by the Littelfuse internal IT team, as well as reporting provided by independent third parties. The updates help the ELT, the Audit Committee, and the Board to understand the risks the organization faces based on changing cybersecurity threats and on changes to the Littelfuse environment due to factors such as acquisitions and new technology upgrades and improvements. Representatives from Littelfuse’s technology team and other business functions receive regular

[0001628280-26-009585:notes:17]
cybersecurity risk reports and use this information for its decision making in operational improvements as well as budget and resource allocations. For the past seven years, the CIO has led and evolved Littelfuse’s cybersecurity function. To address growing cyber threats and advance the program further, in 2025 the Company appointed a CISO with over 20 years of information technology and cybersecurity experience.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001628280-26-009585:notes:18]
Summary of Significant Accounting Policies and Other Information

[0001628280-26-009585:notes:19]
Nature of Operations

[0001628280-26-009585:notes:20]
Littelfuse, Inc. and subsidiaries (the “Company”) is a diversified, industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 20 countries, and with approximately 17,000 global associates, the Company partners with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, the Company’s products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day.

[0001628280-26-009585:notes:21]
Fiscal Year

[0001628280-26-009585:notes:22]
References herein to “2025”, “fiscal 2025” or “fiscal year 2025” refer to the fiscal year ended December 27, 2025. References herein to “2024”, “fiscal 2024” or “fiscal year 2024” refer to the fiscal year ended December 28, 2024. References herein to “2023”, “fiscal 2023” or “fiscal year 2023” refer to the fiscal year ended December 30, 2023. The Company operates on a 52-53 week fiscal year (4-4-5 basis) ending on the Saturday closest to December 31.

[0001628280-26-009585:notes:23]
Basis of Presentation

[0001628280-26-009585:notes:24]
The Consolidated Financial Statements include the accounts of Littelfuse, Inc. and its subsidiaries. All significant intercompany accounts and transactions have been eliminated. The Company’s Consolidated Financial Statements were prepared in accordance with generally accepted accounting principles in the United States of America ("U.S.") and include the assets, liabilities, sales and expenses of all wholly owned subsidiaries and majority-owned subsidiaries over which the Company exercises control.

[0001628280-26-009585:notes:25]
Out-of-Period Adjustments

[0001628280-26-009585:notes:26]
During the year ended December 28, 2024, the Company identified certain errors in its previously issued financial statements that were corrected through cumulative out-of-period adjustments in the financial statements as of and for the year ended December 28, 2024. The error was identified by management and related to the valuation and existence of inventory that originated in prior periods at certain of our non-U.S. manufacturing locations within the Transportation and Industrial segments. As a result, the Company recorded an out-of-period adjustment to the prior years of $12.3 million in the year ended December 28, 2024. The adjustment increased cost of sales, offset by a reduction in inventory. The out-of-period adjustment resulted in a decrease to net income of $12.3 million. The Company evaluated the impact of the error and out-of-period adjustment and concluded it was not material to any previously issued financial statements and the adjustment was not material to the year ended December 28, 2024.

[0001628280-26-009585:notes:27]
Use of Estimates

[0001628280-26-009585:notes:28]
The process of preparing financial statements in conformity with generally accepted accounting principles in the U.S. requires management to make estimates and assumptions that affect the amounts of assets and liabilities at the date of the Consolidated Financial Statements, and the reported amounts of revenues and expenses and the accompanying notes. The Company evaluates and updates its assumptions and estimates on an ongoing basis and may employ outside experts to assist in its evaluation, as considered necessary. Actual results could differ from those estimates.

[0001628280-26-009585:notes:29]
Cash, Cash Equivalents and Restricted Cash

[0001628280-26-009585:notes:30]
All highly liquid investments, with an original maturity of three months or less when purchased, are considered to be cash equivalents. The Company maintains several pools including multicurrency notional pools and physical pools internationally and a zero-balance account ("ZBA") structure in the U.S. In the notional pools, actual cash balances are not physically converted and are not commingled between participating legal entities. The Company will classify any overdraft balances within accrued expenses and other current liabilities on the Consolidated Balance Sheets.

[0001628280-26-009585:notes:31]
The following table provides a reconciliation of cash, cash equivalents and restricted cash at December 27, 2025 and December 28, 2024 reported within the Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Consolidated Statement of Cash Flows.

[0001628280-26-009585:notes:32]
|  |  | Fiscal Year Ended |
| (in millions) |  | 2025 |  | 2024 |
| Cash and cash equivalents |  | $ | 563,391 |  |  | $ | 724,924 |  |
| Restricted cash included in other assets |  | 1,713 |  |  | 1,513 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 565,104 |  |  | $ | 726,437 |  |

[0001628280-26-009585:notes:33]
Short-Term and Long-Term Investments

[0001628280-26-009585:notes:34]
As of December 27, 2025, the Company has an investment in Polytronics Technology Corporation Ltd. (“Polytronics”). The Company’s Polytronics shares held at the end of fiscal 2025 and 2024 represent approximately 6.7% of total Polytronics shares outstanding for both years. The Polytronics investment is carried at fair value. The fair value of the Polytronics investment was €6.5 million (approximately $7.7 million) at December 27, 2025 and €9.8 million (approximately $10.2 million) at December 28, 2024.

[0001628280-26-009585:notes:35]
As a result of the Company’s acquisition of IXYS Corporation ("IXYS"), the Company has equity ownerships in various investments that are accounted for under the equity method. The Company owns 45% of the outstanding equity of Powersem GmbH, a module manufacturer based in Germany, approximately 15% of the outstanding equity of EB Tech Co., Ltd., a company with expertise in radiation technology based in South Korea, and approximately 24% of the outstanding common shares of Automated Technology (Phil), Inc., a supplier located in the Philippines that provides assembly and test services. The Company recognized a loss of $1.0 million and $0.6 million from its equity method investments for the fiscal years ended December 27, 2025 and December 28, 2024, respectively, recorded in Other (income), net, in the Consolidated Statements of Net (Loss) Income. The balance of these equity method investments was $12.3 million and $13.1 million as of the fiscal years ended December 27, 2025 and December 28, 2024, respectively. See Note 18, Related Party Transactions, for further discussion.

[0001628280-26-009585:notes:36]
The Company has investments related to its non-qualified Supplemental Retirement and Savings Plan. The Company maintains accounts for participants through which participants make investment elections. The investment securities are subject to the claims of the Company’s creditors. The investment securities are all mutual funds. The investment securities are measured at net asset value. As of December 27, 2025 and December 28, 2024, the investment securities balance was $25.7 million and $23.3 million, respectively, related to the plan and are included in Other long-term assets on the Consolidated Balance Sheets.

[0001628280-26-009585:notes:37]
Trade Receivables

[0001628280-26-009585:notes:38]
The Company performs credit evaluations of customers’ financial condition and generally does not require collateral. A receivable is considered past due if payments have not been received within agreed upon invoice terms. Write-offs are recorded at the time a customer receivable is deemed uncollectible.

[0001628280-26-009585:notes:39]
The Company also maintains allowances against trade receivables for the settlement of rebates and sales discounts to customers. These allowances are based upon specific customer sales and sales discounts as well as actual historical experience.

[0001628280-26-009585:notes:40]
Inventories

[0001628280-26-009585:notes:41]
Inventories are stated at the lower of cost or net realizable value, which approximates current replacement cost. Cost is principally determined using the first-in, first-out method. The Company maintains excess and obsolete reserves against inventory to reduce the carrying value to the expected net realizable value. These reserves are based upon a combination of factors including historical sales volume, market conditions, and lower of cost or net realizable value of the inventory.

[0001628280-26-009585:notes:42]
Property, Plant, and Equipment

[0001628280-26-009585:notes:43]
Land, buildings, and equipment are carried at cost. Depreciation is calculated using the straight-line method with useful lives of up to 35 years for buildings, three to 20 years for equipment, seven years for furniture and fixtures, five years for tooling, and three years for computer equipment. Leasehold improvements are depreciated over the lesser of their useful life or the lease term. Maintenance and repair costs are charged to expense as incurred. Major overhauls that extend the useful lives of existing assets are capitalized.

[0001628280-26-009585:notes:44]
Goodwill

[0001628280-26-009585:notes:45]
The Company annually tests goodwill for impairment on the first day of its fiscal fourth quarter, or more frequently if an event occurs or circumstances change that would more likely than not reduce the fair value of a reporting unit below its carrying value.

[0001628280-26-009585:notes:46]
The results of the goodwill impairment test as of September 28, 2025 indicated that the estimated fair value for the Electronics-Semiconductor reporting unit was below its respective carrying value. Accordingly, the Company recorded a non-cash impairment charge of $301.2 million to reflect the impairment of goodwill for the Electronics-Semiconductor reporting unit within the Electronics segment. As a result of the impairment charge, the Electronics-Semiconductor reporting unit had $238.5 million of goodwill as of December 27, 2025.  For the remainder of the Company's reporting units with goodwill: Electronics-Passive Products and Sensors, Passenger Car Products, Commercial Vehicle Products, Industrial Controls and Sensors, and Industrial Circuit Protection, the results of the goodwill impairment test as of September 28, 2025 indicated that their estimated fair values exceeded their respective carrying values.

[0001628280-26-009585:notes:47]
During the fourth quarter of 2024, the Company recorded non-cash charges of $36.1 million and $8.6 million, respectively, to reflect the impairment of goodwill for the Industrial Controls and Sensors reporting unit within the Industrial segment and the Automotive Sensors reporting unit within the Transportation segment. As of December 27, 2025, the Industrial controls and sensors reporting unit had $274.9 million of remaining goodwill. There was no goodwill remaining within the Automotive sensors reporting unit as of December 28, 2024.

[0001628280-26-009585:notes:48]
There was no impairment charge recorded during the fiscal year of 2023.

[0001628280-26-009585:notes:49]
The Company compares each reporting unit’s fair value, estimated based on comparable company market valuations and expected future discounted cash flows to be generated by the reporting unit, to its carrying value. With the exception of the Electronics-Semiconductor reporting unit within the Electronics segment, the other five reporting units with goodwill passed the goodwill impairment test, with estimated fair values that exceeded the carrying values between 22% and 303%. As of the most recent annual test conducted on September 28, 2025, the Company noted that the excess of fair value over the carrying value was 87%, 153%, 99%, 22% and 303% for its reporting units: Electronics-Passive Products and Sensors, Passenger Car Products, Commercial Vehicle Products, Industrial Controls and Sensors, and Industrial Circuit Protection, respectively. Relatively small changes in the Company’s key assumptions would not have resulted in any reporting units failing the goodwill impairment test. See Note 5, Goodwill and Other Intangible Assets, for additional information.

[0001628280-26-009585:notes:50]
The Company also performs an interim review for indicators of impairment each quarter to assess whether an interim impairment review is required for any reporting unit. As part of its interim reviews, management analyzes potential changes in the value of individual reporting units based on each reporting unit’s operating results for the period compared to expected results as of the prior year’s annual impairment test. In addition, management considers how other key assumptions, including discount rates and expected long-term growth rates, used in the last annual impairment test, could be impacted by changes in market conditions and economic events. Based on the interim assessments as of December 27, 2025, management concluded that no events or changes in circumstances indicated that it was more likely than not that the fair value for any reporting unit had declined below its carrying value.

[0001628280-26-009585:notes:51]
Long-Lived Assets

[0001628280-26-009585:notes:52]
For the fiscal year ended December 27, 2025, the Company recognized impairment charges of $0.5 million and $0.4 million related to certain machinery and equipment in the commercial vehicle business within the Transportation and the electronics products business within the Electronics segment, respectively.

[0001628280-26-009585:notes:53]
For the fiscal year ended December 28, 2024, the Company recorded non-cash impairment charges of $47.8 million for the impairment of intangible assets, including $47.6 million related to the impairment of certain acquired customer relationships, developed technology, and tradename intangible assets in the Industrial Controls and Sensors reporting unit within the Industrial segment. The impairment of the intangible assets resulted from lower expectations of future revenue and cash flows driven by lower-than-expected demand in the electrical vehicle end market as well as reduced government funding to support charging infrastructures for electric vehicles, primarily in Europe. The fair value was determined using Level 3 inputs and estimated based on cash flow analyses, which included management’s assumptions related to future revenues and profitability. The remaining impairment charges included $0.2 million for patents and customer relationships related to the exit of a small business in China within the Industrial segment. In addition, during the first quarter of 2024, the Company recognized a $0.9 million impairment related to certain machinery and equipment in the commercial vehicle business within the Transportation segment.

[0001628280-26-009585:notes:54]
For the fiscal year ended December 30, 2023, the Company recognized a $3.9 million impairment charge related to the land and building of a property in the commercial vehicle business within the Transportation segment that the Company made the decision to donate, a $0.9 million impairment charge substantially related to certain patents in a business within the Industrial segment, and a $0.1 million impairment on certain machinery and equipment in the semiconductor business within the Electronics segment.

[0001628280-26-009585:notes:55]
Customer relationships, trademarks and tradenames are amortized using the straight-line method over estimated useful lives that have a range of 3 to 20 years. Patents, licenses, and software are amortized using the straight-line method or an accelerated method over estimated useful lives that have a range of 4 to 17 years. The distribution networks are amortized on either a straight-line or accelerated basis over estimated useful lives that have a range of 4 to 10 years. Land use rights are amortized using the straight-line method up to 50 years which is the term of the land use rights.

[0001628280-26-009585:notes:56]
The Company assesses potential impairments to its long-lived assets if events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable. An impaired asset is written down to its estimated fair value based upon the most recent information available. Estimated fair market value is generally measured by discounting estimated future cash flows. Long-lived assets, other than goodwill and other intangible assets, which are held for sale are recorded at the lower of carrying value or the fair market value less the estimated cost to sell.

[0001628280-26-009585:notes:57]
Environmental Liabilities

[0001628280-26-009585:notes:58]
Environmental liabilities are accrued based on engineering studies estimating the cost of remediating sites. Expenses related to on-going maintenance of environmental sites are expensed as incurred. If actual or estimated probable future losses exceed the Company’s recorded liability for such claims, the Company would record additional charges during the period in which the actual loss or change in estimate occurred.

[0001628280-26-009585:notes:59]
Pension and Other Post-retirement Benefits

[0001628280-26-009585:notes:60]
The Company records annual income and expense amounts relating to its pension and post-retirement benefits plans based on calculations which include various actuarial assumptions including discount rates, expected long-term rates of return and compensation increases. The Company reviews its actuarial assumptions on an annual basis as of the fiscal year-end balance sheet date (or more frequently if a significant event requiring remeasurement occurs) and modifies the assumption based on current rates and trends when it is appropriate to do so. The effects of modifications are recognized immediately on the Consolidated Balance Sheets, but are generally amortized into operating earnings over future periods, with the deferred amount recorded in accumulated other comprehensive loss. The Company believes that the assumptions utilized in recording its obligations under its plans are reasonable based on its experience, market conditions and input from its actuaries and investment advisors.

[0001628280-26-009585:notes:61]
Revenue Recognition

[0001628280-26-009585:notes:62]
Revenue Disaggregation

[0001628280-26-009585:notes:63]
The following table disaggregates the Company’s revenue by primary business units for the fiscal years ended December 27, 2025, December 28, 2024, and December 30, 2023:

[0001628280-26-009585:notes:64]
|  |  | Fiscal Year Ended December 27, 2025 |
| (in thousands) |  | ElectronicsSegment |  | Transportation Segment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 669,579 |  |  | $ | — |  |  | $ | — |  |  | $ | 669,579 |  |
| Electronics – Passive Products and Sensors |  | 675,943 |  |  | — |  |  | — |  |  | 675,943 |  |
| Commercial Vehicle Products |  | — |  |  | 320,545 |  |  | — |  |  | 320,545 |  |
| Passenger Car Products |  | — |  |  | 293,641 |  |  | — |  |  | 293,641 |  |
| Automotive Sensors |  | — |  |  | 62,191 |  |  | — |  |  | 62,191 |  |
| Industrial Products |  | — |  |  | — |  |  | 364,395 |  |  | 364,395 |  |
| Total |  | $ | 1,345,522 |  |  | $ | 676,377 |  |  | $ | 364,395 |  |  | $ | 2,386,294 |  |

[0001628280-26-009585:notes:65]
|  |  | Fiscal Year Ended December 28, 2024 |
| (in thousands) |  | ElectronicsSegment |  | Transportation Segment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 615,372 |  |  | $ | — |  |  | $ | — |  |  | $ | 615,372 |  |
| Electronics – Passive Products and Sensors |  | 571,401 |  |  | — |  |  | — |  |  | 571,401 |  |
| Commercial Vehicle Products |  | — |  |  | 320,549 |  |  | — |  |  | 320,549 |  |
| Passenger Car Products |  | — |  |  | 278,332 |  |  | — |  |  | 278,332 |  |
| Automotive Sensors |  | — |  |  | 73,553 |  |  | — |  |  | 73,553 |  |
| Industrial Products |  | — |  |  | — |  |  | 331,561 |  |  | 331,561 |  |
| Total |  | $ | 1,186,773 |  |  | $ | 672,434 |  |  | $ | 331,561 |  |  | $ | 2,190,768 |  |

[0001628280-26-009585:notes:66]
|  |  | Fiscal Year Ended December 30, 2023 |
| (in thousands) |  | ElectronicsSegment |  | Transportation Segment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 767,393 |  |  | $ | — |  |  | $ | — |  |  | $ | 767,393 |  |
| Electronics – Passive Products and Sensors |  | 583,033 |  |  | — |  |  | — |  |  | 583,033 |  |
| Commercial Vehicle Products |  | — |  |  | 323,758 |  |  | — |  |  | 323,758 |  |
| Passenger Car Products |  | — |  |  | 266,004 |  |  | — |  |  | 266,004 |  |
| Automotive Sensors |  | — |  |  | 88,516 |  |  | — |  |  | 88,516 |  |
| Industrial Products |  | — |  |  | — |  |  | 333,953 |  |  | 333,953 |  |
| Total |  | $ | 1,350,426 |  |  | $ | 678,278 |  |  | $ | 333,953 |  |  | $ | 2,362,657 |  |

[0001628280-26-009585:notes:67]
See Note 16, Segment Information, for net sales by segment and country.

[0001628280-26-009585:notes:68]
The Company recognizes revenue on product sales in the period in which the Company satisfies its performance obligation and control of the product is transferred to the customer. The Company’s sales arrangements with customers are predominately short term in nature and generally provide for transfer of control at the time of shipment as this is the point at which title and risk of loss of the product transfers to the customer. At the end of each period, for those shipments where title to the products and the risk of loss and rewards of ownership do not transfer until the product has been received by the customer, the Company adjusts revenues and cost of sales for the delay between the time that the products are shipped and when they are received by the customer. The amount of revenue recorded reflects the consideration to which the Company expects to be entitled in exchange for goods and may include adjustments for customer allowance, rebates, and price adjustments. The Company’s distribution channels are primarily through direct sales and independent third-party distributors.

[0001628280-26-009585:notes:69]
The Company has elected the practical expedient under ASC 340-40-25-4 to expense commissions when incurred as the amortization period of the commission asset the Company would have otherwise recognized is less than one year.

[0001628280-26-009585:notes:70]
Revenue and Billing

[0001628280-26-009585:notes:71]
The Company generally accepts orders from customers through receipt of purchase orders or electronic data interchange based on written sales agreements and purchasing contracts. Contract pricing and selling agreement terms are based on market factors, costs, and competition. Pricing is often negotiated as an adjustment (premium or discount) from the Company’s published price lists. The customer is invoiced when the Company’s products are shipped to them in accordance with the terms of the sales agreement. As the Company’s standard payment terms are less than one year, the Company has elected the practical expedient under ASC 606-10-32-18 to not assess whether a contract has a significant financing component. The Company also elected the practical expedient provided in ASC 606-10-25-18B to treat all product shipping and handling activities as fulfillment activities, and therefore recognize the gross revenue associated with the contract, inclusive of any shipping and handling revenue.

[0001628280-26-009585:notes:72]
Ship and Debit Program

[0001628280-26-009585:notes:73]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributors to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historic activity, distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

[0001628280-26-009585:notes:74]
Return to Stock

[0001628280-26-009585:notes:75]
The Company has a return to stock policy whereby certain customers, with prior authorization from the Company's management, can return previously purchased goods for full or partial credit. The Company establishes an estimated allowance for these returns based on historic activity. Sales revenue and cost of sales are reduced to anticipate estimated returns.

[0001628280-26-009585:notes:76]
Volume Rebates

[0001628280-26-009585:notes:77]
The Company offers volume-based sales incentives to certain customers to encourage greater product sales. If customers achieve their specific quarterly or annual sales targets, they are entitled to rebates. The Company estimates the projected amount of rebates that will be achieved by the customer and recognizes this estimated cost as a reduction to revenue as products are sold.

[0001628280-26-009585:notes:78]
Allowance for Credit Losses

[0001628280-26-009585:notes:79]
The Company currently measures the expected credit losses based on our historical credit loss experience. The Company has not experienced significant recent or historical credit losses and is not forecasting any significant credit losses which would require adjustments to our methodology. If current conditions and supportable forecasts indicate that our historical loss experience is not reasonable and no longer supportable, the Company may adjust its historical credit loss experience and to reflect these conditions and forecasts. The Company regularly analyzes its significant customer accounts and, when the Company becomes aware of a customer’s inability to meet its financial obligations, the Company records a specific reserve for bad debt to reduce the related receivable to the amount the Company reasonably believes is collectible. The Company also analyzes all other customers based on a variety of factors including the length of time the receivables are past due, the financial health of the customer, macroeconomic considerations and historical collection and loss experience. Historically, the allowance for credit losses has been adequate to cover bad debts. If circumstances related to specific customers change, the estimates of the recoverability of receivables could be further adjusted.

[0001628280-26-009585:notes:80]
As of December 27, 2025 and December 28, 2024, the Company’s allowance for credit losses was $2.5 million and $1.6 million, respectively. Additionally, the Company had $9.3 million and $3.8 million of trade receivables greater than 90 days past due as of December 27, 2025 and December 28, 2024, respectively.

[0001628280-26-009585:notes:81]
Advertising Costs

[0001628280-26-009585:notes:82]
The Company expenses advertising costs as incurred, which amounted to $4.0 million, $5.0 million, and $4.0 million in fiscal years 2025, 2024 and 2023, respectively, and are included as a component of selling, general, and administrative expenses.

[0001628280-26-009585:notes:83]
Shipping and Handling Fees and Costs

[0001628280-26-009585:notes:84]
Amounts billed to customers related to shipping and handling are classified as revenue. Costs incurred for shipping and handling of $14.3 million, $15.3 million, and $15.4 million in fiscal years 2025, 2024, and 2023, respectively, are classified in selling, general, and administrative expenses.

[0001628280-26-009585:notes:85]
Foreign Currency Translation / Remeasurement

[0001628280-26-009585:notes:86]
The Company’s foreign subsidiaries use the local currency or the U.S. dollar as their functional currency, as appropriate. Assets and liabilities are translated using exchange rates at the balance sheet date, and revenues and expenses are translated at weighted average rates. Adjustments from the translation process are recognized in Shareholders’ equity as a component of Accumulated other comprehensive loss. The amount of foreign currency loss or (gain) recognized in the Consolidated Statements of Net (Loss) Income was loss (gain) of $16.6 million, $(9.2) million, and $12.3 million in fiscal years 2025, 2024 and 2023, respectively.

[0001628280-26-009585:notes:87]
Stock-Based Compensation

[0001628280-26-009585:notes:88]
The Company recognizes compensation expense for the cost of awards of equity compensation using a fair value method. Benefits of tax deductions in excess of recognized compensation expense are reported as operating cash flows. See Note 12, Stock-Based Compensation, for additional information on stock-based compensation.

[0001628280-26-009585:notes:89]
Coal Mining Liability

[0001628280-26-009585:notes:90]
Included in accrued liabilities is an accrual related to former coal mining operations at Littelfuse GmbH (formerly known as Heinrich Industries, AG) for the amounts of €1.8 million ($2.2 million) and €2.2 million ($2.3 million) at December 27, 2025 and December 28, 2024, respectively. Management, in conjunction with an independent third-party, performs an annual evaluation of the former coal mining operations in order to develop an estimate of the probable future obligations in regard to remediating the dangers (such as a shaft collapse) of abandoned coal mine shafts in the former coal mining operations. Management accrues for costs associated with such remediation efforts based on management's best estimate when such costs are probable and reasonably able to be estimated. The ultimate determination can only be done after respective investigations because the concrete conditions are mostly unknown at this time.

[0001628280-26-009585:notes:91]
Other Income, Net

[0001628280-26-009585:notes:92]
Other income, net generally consists of interest income, royalties, changes in fair value of available-for-sale securities, pension non-service costs and settlements and other non-operating (income) expense. The amount of interest income included in Other income, net, was $26.3 million, $28.0 million, and $18.9 million in fiscal years 2025, 2024 and 2023, respectively.

[0001628280-26-009585:notes:93]
Income Taxes

[0001628280-26-009585:notes:94]
The Company accounts for income taxes using the asset and liability method. Deferred taxes are recognized for the future effects of temporary differences between financial and income tax reporting using enacted tax rates in effect for the years in which the differences are expected to reverse. The Company recognizes deferred taxes for temporary differences, operating loss carryforwards, and tax credit and other tax attribute carryforwards (excluding carryforwards where usage has been determined to be remote). Deferred tax assets are reduced by a valuation allowance if it is more likely than not that some portion, or all, of the deferred tax assets will not be realized. U.S. state and non-U.S. income taxes are provided on the portion of non-U.S. income that is expected to be remitted to the U.S. and be taxable (and non-U.S. income taxes are provided on the portion of non-U.S. income that is expected to be remitted to an upper-tier non-U.S. entity). Deferred tax assets and liabilities are adjusted for the effects of changes in tax laws and rates on the date of enactment.

[0001628280-26-009585:notes:95]
Deferred U.S. income taxes and non-U.S. taxes are not provided on the excess of the investment value for financial reporting over the tax basis of investments in those non-U.S. subsidiaries for which such excess is considered to be permanently reinvested in those operations. Management regularly evaluates whether non-U.S. earnings are expected to be permanently reinvested. This evaluation requires judgment about the future operating and liquidity needs of the Company and its non-U.S. subsidiaries. Changes in economic and business conditions, tax laws, or the Company’s financial situation could result in changes to these judgments and the need to record additional tax liabilities.

[0001628280-26-009585:notes:96]
The Company recognizes the tax benefit from an uncertain tax position only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such a position are measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement.

[0001628280-26-009585:notes:97]
The 2017 Tax Cuts and Jobs Act (the "Tax Act"), among other things, imposed a one-time tax (the “Toll Charge”) on accumulated earnings of certain non-U.S. subsidiaries and included base broadening provisions commonly referred to as the global intangible low-taxed income provisions ("GILTI").

[0001628280-26-009585:notes:98]
In accordance with guidance issued by the FASB staff, the Company has adopted an accounting policy to treat any GILTI inclusions as a period cost if and when incurred. Thus, for the fiscal years ended December 27, 2025, December 28, 2024, and December 30, 2023, deferred taxes were computed without consideration of the possible future impact of the GILTI provisions, and any current year impact was recorded as a part of the current portion of income tax expense.

[0001628280-26-009585:notes:99]
On July 4, 2025, the United States enacted into law the legislation formally titled “An Act to provide for reconciliation pursuant to title II of H. Con. Res. 14,” and commonly referred to as the One Big Beautiful Bill Act (“OBBB”). The OBBB contains multiple business tax provisions, including the permanent extension of several expiring provisions of the Tax Act and multiple modifications to the international tax framework. The legislation has multiple effective dates with certain provisions effective in 2025 and others to be implemented in future years, and the Company determined the impact for the year ended December 27, 2025 was not significant. The Company will continue to monitor future administrative guidance and regulations that clarify the legislative text of the OBBB and the bill’s potential effect on the Company’s income taxes.

[0001628280-26-009585:notes:100]
Fair Value Measurements

[0001628280-26-009585:notes:101]
Certain assets and liabilities are required to be recorded at fair value on a recurring basis. Fair value is determined based on the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants. The Company records the fair value of its available-for-sale securities and pension plan assets on a recurring basis. Assets measured at fair value on a nonrecurring basis include long-lived assets held and used, long-lived assets held for sale, goodwill, and other intangible assets. The fair value of cash and cash equivalents, short-term investments, accounts receivable, accounts payable, and accrued liabilities approximate their carrying values. The three-tier value hierarchy, which prioritizes valuation methodologies based on the reliability of the inputs, is:

[0001628280-26-009585:notes:102]
Level 1 – Valuations based on unadjusted quoted prices for identical assets and liabilities in active markets.

[0001628280-26-009585:notes:103]
Level 2 – Valuations based on observable inputs other than quoted prices included in Level 1, such as quoted prices for similar assets and liabilities in active markets, quoted prices for identical or similar assets and liabilities in markets that are not active, or other inputs that are observable or can be corroborated by observable market data.

[0001628280-26-009585:notes:104]
Level 3 – Valuations based on unobservable inputs reflecting the Company’s own assumptions, consistent with reasonably available assumptions made by other market participants.

[0001628280-26-009585:notes:105]
Recently Adopted Accounting Standards

[0001628280-26-009585:notes:106]
In December 2023, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Updates ("ASU") No. 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures." The amendments in this update provide more transparency about income tax information through improvements to the income tax disclosure primarily related to the income tax rate reconciliation and income taxes paid information. These requirements include: (1) consistent categories and greater disaggregation of information in the rate reconciliation and (2) income taxes paid disaggregated by jurisdiction. The other amendments in this update improve the effectiveness and comparability of disclosures by (3) adding disclosures of pretax income (or loss) and income tax expense (or benefit), and (4) removing disclosures that are no longer considered cost beneficial or relevant. The guidance is effective for fiscal years beginning after December 15, 2024 with early adoption permitted. The Company adopted ASU 2023-09 for the year ended December 27, 2025, and applied the new disclosure requirements prospectively to the current annual period. Prior period disclosures have not been adjusted to reflect the new disclosure requirements. See Note 14, Income Taxes, for more information and the updated disclosures.

[0001628280-26-009585:notes:107]
Recently Issued Accounting Standards

[0001628280-26-009585:notes:108]
In December 2025, the FASB issued ASU No. 2025-12, "Codification Improvements." The amendments in this update represent changes to the codification that clarify, correct errors, or make minor improvements. The amendments make the codification easier to understand and apply. The amendments in this update are varied in nature and may affect the application of guidance in cases in which the original guidance may have been unclear. The guidance is effective for fiscal years beginning after December 15, 2026 with early adoption permitted. The Company does not expect any material effect of the adoption of this guidance on the Company's Consolidated Financial Statements.

[0001628280-26-009585:notes:109]
In December 2025, the FASB issued ASU No. 2025-11, "Interim Reporting (Topic 270): Narrow-Scope Improvements." The amendments in this update result in a comprehensive list of interim disclosures that are required by GAAP. The objective of the amendments is to provide clarity about the current requirements, rather than evaluate whether to expand or reduce interim disclosure requirements. The amendments in this update include a disclosure principle that requires entities to disclose events since the end of the last annual reporting period that have a material impact on the entity. The amendments in this update also clarify the applicability of Topic 270, the types of interim reporting, and the form and content of interim financial statements in accordance with GAAP. The guidance is effective for fiscal years beginning after December 15, 2027 with early adoption permitted. The Company does not expect any material effect of the adoption of this guidance on the Company's Consolidated Financial Statements.

[0001628280-26-009585:notes:110]
In November 2025, the FASB issued ASU No. 2025-09, "Derivatives and Hedging (Topic 815): Hedge Accounting Improvements." The amendments in this update are intended to more closely align hedge accounting with the economics of an entity's risk management activities.The five issues addressed in this update (1) expand the hedged risks permitted to be aggregated in a group of individual forecasted transactions in a cash flow hedge by changing the requirement to designate a group of individual forecasted transactions from having a shared risk exposure to having a similar risk exposure, (2) provide a model to facilitate the application of cash flow hedge accounting to forecasted interest payments on variable-rate debt instruments with contractual terms that permit the borrower to change the interest rate index and interest rate tenor upon which interest is accrued, (3) expand hedge accounting for forecasted purchases and sales of nonfinancial assets, (4) update the hedge accounting guidance to accommodate differences in the loan and swap markets that developed after the cessation of the London Interbank Offered Rate, and (5) eliminate the recognition and presentation mismatch related to a dual hedge strategy. The guidance is effective for fiscal years beginning after December 15, 2026 with early adoption permitted. The Company does not expect any material effect of the adoption of this guidance on the Company's Consolidated Financial Statements.

[0001628280-26-009585:notes:111]
In September 2025, the FASB issued ASU No. 2025-06, "Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software." The amendments in this update require the entity to start capitalizing software costs when both of the following criteria are met: (1) management has authorized and committed to funding the software project, and (2) it is probable that the project will be completed and the software will be used to perform the function intended (referred to as the "probable-to-complete recognition threshold"). The amendments clarify that the intangibles disclosures are not required for capitalized internal-use software costs. Additionally, the amendments in this update supersede the website development costs guidance and incorporate the recognition requirements for website-specific development costs. The guidance is effective for fiscal years beginning after December 15, 2027 with early adoption permitted. The Company is currently evaluating the potential effects of these amendments on its Consolidated Financial Statements.

[0001628280-26-009585:notes:112]
In September 2025, the FASB issued ASU No. 2025-05, "Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets." The amendments in this update provide entities with a practical expedient when estimating expected credit losses for current accounts receivable and current contract assets arising from transactions accounted for under Topic 606. In developing reasonable and supportable forecasts as part of estimating expected credit losses, the practical expedient allows entities to assume that current conditions as of the balance sheet date do not change for the remaining life of the asset. The guidance is effective for fiscal years beginning after December 15, 2025 with early adoption permitted. The Company does not expect any material effect of the adoption of this guidance on the Company's Consolidated Financial Statements.

[0001628280-26-009585:notes:113]
In November 2024, the FASB issued ASU No. 2024-03, "Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40)." The amendments in this update require disclosure, in the notes to financial statements, of specified information about certain costs and expenses. The amendments require that at each interim and annual reporting period an entity (a) disclose the amounts of (i) purchases of inventory, (ii) employee compensation, (iii) depreciation, (iv) intangible asset amortization, and (v) depreciation, depletion, and amortization recognized as part of oil and gas producing activities ("DD&A") included in each relevant expense caption. A relevant expense caption is an expense caption presented on the face of the income statement within continuing operations that contains any of the expense categories listed in (i)–(v); (b) include certain amounts that are already required to be disclosed under current Generally Accepted Accounting Principles ("GAAP") in the same disclosure as the other disaggregation requirements; (c) disclose a qualitative description of the amounts remaining in relevant expense captions that are not separately disaggregated quantitatively; (d) disclose the total amount of selling expenses and, in annual reporting periods, an entity’s definition of selling expenses. The guidance is effective for fiscal years beginning after December 15, 2026, and interim reporting periods beginning after December 15, 2027, with early adoption permitted. The adoption of this guidance will increase the Company's disclosures in its Consolidated Financial Statements. The Company is currently evaluating the potential impact on the disclosures in the Company's Consolidated Financial Statements.

[0001628280-26-009585:notes:114]
In October 2023, the FASB issued ASU No. 2023-06, "Disclosure Improvements." The amendments in this update represent changes to clarify or improve the disclosure or presentation requirements of a variety of Topics in the ASC. The Company may be affected by one or more of those amendments. The amendments in this ASU should be applied prospectively and will not be effective until June 30, 2027. The Company is currently evaluating the potential effects of these amendments on its Consolidated Financial Statements.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0001628280-26-009585:notes:115]
Acquisitions

[0001628280-26-009585:notes:116]
The Company accounts for acquisitions using the acquisition method in accordance with ASC 805, “Business Combinations,” in which assets acquired and liabilities assumed are recorded at fair value as of the date of acquisition. The operating results of the acquired businesses are included in the Company’s Consolidated Financial Statements from the date of the acquisition.

[0001628280-26-009585:notes:117]
Basler Electric

[0001628280-26-009585:notes:118]
On December 11, 2025, the Company completed the acquisition of Basler. Basler is a leading designer and manufacturer of innovative electrical control and protection solutions for high-growth industrial markets including grid and utility infrastructure, power generation and data center. At the time of acquisition, Basler had annualized sales of approximately $130 million. The business is reported within the Company’s Industrial segment. The purchase price for Basler  was $361.7 million and is subject to a working capital adjustment.

[0001628280-26-009585:notes:119]
The Company financed the transaction with cash on hand. The total purchase consideration of $350.3 million, net of cash acquired, has been allocated, on a preliminary basis, based on estimated fair values of assets acquired and liabilities assumed. As of December 27, 2025, the Company’s purchase price allocation reflects various provisional estimates that were based on the information that was available as of the acquisition date and the filing date of this Form 10-K. The Company believes that information provides a reasonable basis for estimating the fair values of assets acquired and liabilities assumed; however, the determination of those fair values, including the third-party valuation of acquired tangible and intangible assets, is not yet finalized. Thus, the preliminary measurements of fair value set forth in the table below are subject to change during the measurement period as valuations are finalized. The Company expects to finalize the valuation and complete the purchase price allocation as soon as practicable.

[0001628280-26-009585:notes:120]
The following table summarizes the preliminary purchase price allocation of the fair value of assets acquired and liabilities assumed in the Basler acquisition:

[0001628280-26-009585:notes:121]
| (in thousands) | Purchase PriceAllocation |
| Total purchase consideration: |  |
| Cash, net of cash acquired | $ | 350,301 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |
| Trade receivables, net | 16,798 |  |
| Inventories | 23,363 |  |
| Other current assets | 2,965 |  |
| Property, plant, and equipment | 23,237 |  |
| Intangible assets | 150,000 |  |
| Goodwill | 152,343 |  |
| Other long-term assets | 5,731 |  |
| Current liabilities | (21,386) |  |
| Other long-term liabilities | (2,750) |  |
|  | $ | 350,301 |  |

[0001628280-26-009585:notes:122]
All Basler assets and liabilities were recorded in the Industrial segment and are primarily reflected in the North America geographic area. The goodwill resulting from this acquisition consists largely of the Company’s expected future product sales and synergies from combining Basler’s products and technology with the Company’s existing Industrial products portfolio. Goodwill resulting from the Basler acquisition is expected to be deductible for tax purposes.

[0001628280-26-009585:notes:123]
Included in the Company’s Consolidated Statements of Net (Loss) Income for the fiscal year ended December 27, 2025 were net sales of $3.7 million, and a loss before income taxes of $1.2 million, respectively, since the December 11, 2025 acquisition of Basler.

[0001628280-26-009585:notes:124]
As required by purchase accounting guidance, the Company recorded a $6.4 million step-up of inventory to its fair value as of the acquisition date based on the preliminary valuation. The step-up is being amortized as a non-cash charge to cost of goods sold during the fourth quarter of 2025 and first quarter of 2026, as the acquired inventory is sold, and reflected as other non-segment costs. The Company recognized a non-cash charge of $1.1 million to cost of goods sold during the fiscal year ended December 27, 2025.

[0001628280-26-009585:notes:125]
For the fiscal year ended December 27, 2025, the Company incurred $2.6 million of legal and professional fees related to the Basler acquisition recognized as Selling, general, and administrative expenses and reflected as other non-segment costs.

[0001628280-26-009585:notes:126]
Dortmund Fab

[0001628280-26-009585:notes:127]
On December 31, 2024, the Company completed the acquisition of a 200mm wafer fab located in Dortmund, Germany (“Dortmund Fab”) from Elmos Semiconductor SE. The total purchase price for the Dortmund Fab was approximately €94 million, of which a €37.2 million down payment (approximately $40.5 million) was paid in the third quarter of 2023 after regulatory approvals, and €56.7 million (approximately $58.8 million) was paid at closing. The business is reported in the Electronics-Semiconductor business within the Company’s Electronics segment.

[0001628280-26-009585:notes:128]
The acquisition was funded with the Company’s cash on hand. The total purchase consideration of $95.9 million, net of cash acquired, has been allocated to assets acquired and liabilities assumed, as of the completion of the acquisition, based on estimated fair values.

[0001628280-26-009585:notes:129]
The following table summarizes the final purchase price allocation of the fair value of assets acquired and liabilities assumed in the Dortmund Fab acquisition:

[0001628280-26-009585:notes:130]
| (in thousands) | Purchase PriceAllocation |
| Total purchase consideration: |  |
| Cash, net of cash acquired | $ | 95,942 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |
| Trade receivables, net | 5,985 |  |
| Inventories | 6,600 |  |
| Other current assets | 8,278 |  |
| Property, plant, and equipment | 30,132 |  |
| Intangible assets | 1,800 |  |
| Goodwill | 57,321 |  |
| Other long-term assets | 8,579 |  |
| Current liabilities | (7,464) |  |
| Other long-term liabilities | (15,289) |  |
|  | $ | 95,942 |  |

[0001628280-26-009585:notes:131]
All Dortmund Fab assets and liabilities were recorded in the Electronics segment and are primarily reflected in the Europe geographic area. The goodwill resulting from this acquisition consists largely of the Company’s expected future product sales and synergies from combining Dortmund Fab’s products and technology with the Company’s existing semiconductor products portfolio. Goodwill resulting from the Dortmund Fab acquisition is expected to be deductible for tax purposes.

[0001628280-26-009585:notes:132]
Included in the Company’s Consolidated Statements of Net (Loss) Income for the fiscal year ended December 27, 2025 were net sales of $49.0 million, and a loss before income taxes of $69.1 million, respectively, since the December 31, 2024 acquisition of Dortmund Fab. The loss before income taxes included the goodwill impairment charge of $64.6 million recorded in the fourth quarter of the fiscal year 2025.

[0001628280-26-009585:notes:133]
As required by purchase accounting guidance, the Company recorded a $0.5 million step-down of inventory to its fair value as of the acquisition date based on the valuation. The step-down was fully amortized as a non-cash credit to cost of sales during the first fiscal quarter of 2025 as the acquired inventory was sold and reflected as other non-segment costs.

[0001628280-26-009585:notes:134]
For the fiscal year ended December 28, 2024 and December 30, 2023, the Company incurred $0.5 million and $3.0 million, respectively, of legal and professional fees related to the Dortmund Fab acquisition recognized as Selling, general, and administrative expenses and reflected as other non-segment costs. A total of $3.5 million of legal and professional fees related to the Dortmund Fab acquisition was recognized since 2023. These costs were reflected as other non-segment costs.

[0001628280-26-009585:notes:135]
Western Automation

[0001628280-26-009585:notes:136]
On February 3, 2023, the Company completed the acquisition of Western Automation Research and Development Limited (“Western Automation”) for approximately $162 million in cash. Headquartered in Galway, Ireland, Western Automation is a designer and manufacturer of electrical shock protection devices used across a broad range of high-growth end markets,

[0001628280-26-009585:notes:137]
including electric vehicle charging infrastructure, industrial safety and renewables. At the time the Company and Western Automation entered into the definitive agreement, Western Automation had annualized sales of approximately $25 million. The business is reported within the Company’s Industrial segment.

[0001628280-26-009585:notes:138]
The acquisition was funded with cash on hand. The total purchase consideration of $158.3 million, net of cash, has been allocated to assets acquired and liabilities assumed, as of the completion of the acquisition, based on estimated fair values.

[0001628280-26-009585:notes:139]
The following table summarizes the final purchase price allocation of the fair value of assets acquired and liabilities assumed in the Western Automation acquisition:

[0001628280-26-009585:notes:140]
| (in thousands) | Purchase PriceAllocation |
| Total purchase consideration: |  |
| Cash, net of cash acquired | $ | 158,260 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |
| Trade receivables, net | 3,359 |  |
| Inventories | 3,678 |  |
| Other current assets | 718 |  |
| Property, plant, and equipment | 1,328 |  |
| Intangible assets | 68,000 |  |
| Goodwill | 93,937 |  |
| Other long-term assets | 573 |  |
| Current liabilities | (4,335) |  |
| Other long-term liabilities | (8,998) |  |
|  | $ | 158,260 |  |

[0001628280-26-009585:notes:141]
All Western Automation assets and liabilities were recorded in the Industrial segment and are primarily reflected in the Europe geographic area. The goodwill resulting from this acquisition consists largely of the Company’s expected future product sales and synergies from combining Western Automation’s products and technology with the Company’s existing Industrial products portfolio. Goodwill resulting from the Western Automation acquisition is not expected to be deductible for tax purposes.

[0001628280-26-009585:notes:142]
For the fiscal year ended December 30, 2023, the Company incurred $1.2 million of legal and professional fees related to the Western Automation acquisition recognized as Selling, general, and administrative expenses and reflected as other non-segment costs.

[0001628280-26-009585:notes:143]
Pro Forma Results

[0001628280-26-009585:notes:144]
The following table summarizes, on an unaudited pro forma basis, the combined results of operations of the Company, Basler and Dortmund Fab as though the acquisitions had occurred as of December 31, 2023, and Western Automation as though the acquisition had occurred as of January 2, 2022. The pro forma amounts presented are not necessarily indicative of either the actual consolidated results had the Basler and Dortmund Fab acquisitions occurred as of December 31, 2023, and Western Automation acquisition occurred as of January 2, 2022 or of future consolidated operating results.

[0001628280-26-009585:notes:145]
|  |  | For the Fiscal Year Ended |
| (in thousands, except per share amounts) |  | December 27, 2025 |  | December 28, 2024 |  | December 30, 2023 |
| Net sales |  | $ | 2,515,937 |  |  | $ | 2,354,262 |  |  | $ | 2,364,543 |  |
| Income before income taxes |  | 11,474 |  |  | 148,476 |  |  | 330,114 |  |
| Net (loss) income |  | (66,100) |  |  | 96,901 |  |  | 260,812 |  |
| Net (loss) income per share — basic |  | (2.66) |  |  | 3.90 |  |  | 10.49 |  |
| Net (loss) income per share — diluted |  | (2.66) |  |  | 3.87 |  |  | 10.39 |  |

[0001628280-26-009585:notes:146]
Pro forma results presented above primarily reflect the following adjustments:

[0001628280-26-009585:notes:147]
|  |  |  |  | For the Fiscal Year Ended |
| (in thousands) |  |  |  | December 27, 2025 |  | December 28, 2024 |  | December 30, 2023 |
| Amortization (a) |  |  |  | $ | (11,009) |  |  | $ | (10,481) |  |  | $ | (479) |  |
| Depreciation |  |  |  | (833) |  |  | (1,821) |  |  | — |  |
| Transaction costs (b) |  |  |  | 2,536 |  |  | (2,535) |  |  | 1,203 |  |
| Amortization of unfavorable production contract (c) |  |  |  | — |  |  | 2,269 |  |  | — |  |
| Amortization of inventory adjustment (d) |  |  |  | 563 |  |  | (5,890) |  |  | — |  |
| Income tax benefit (expense) of above items |  |  |  | 2,130 |  |  | 4,352 |  |  | (91) |  |
| Total |  |  |  | $ | (6,613) |  |  | $ | (14,106) |  |  | $ | 633 |  |

[0001628280-26-009585:notes:148]
(a)The amortization adjustment for the twelve months ended December 27, 2025, December 28, 2024, and December 30, 2023, primarily reflects incremental amortization resulting from the measurement of intangibles at their fair values.

[0001628280-26-009585:notes:149]
(b)The transaction cost adjustments reflect the reversal of certain legal and professional fees from the twelve months ended December 27, 2025 and December 30, 2023, respectively, and recognition of those fees during the twelve months ended December 28, 2024 and December 31, 2022, respectively.

[0001628280-26-009585:notes:150]
(c)The amortization of the unfavorable production contract during the twelve months ended December 28, 2024 results from the fair value assigned to the unfavorable production contract liability that is amortized over four years.

[0001628280-26-009585:notes:151]
(d)The amortization of inventory adjustment reflects the reversal of the amount recognized during the twelve months ended December 27, 2025 and recognition of the amortization during the twelve months ended December 28, 2024. The inventory adjustment related to the Basler acquisition is being amortized over three months as the inventory is sold. The inventory adjustment related to the Dortmund Fab acquisition was fully amortized over two months as the inventory was sold during 2025.


## us-gaap:InventoryDisclosureTextBlock

[0001628280-26-009585:notes:152]
The components of inventories at December 27, 2025 and December 28, 2024 were as follows:

[0001628280-26-009585:notes:153]
| (in thousands) | 2025 |  | 2024 |
| Raw materials | $ | 186,662 |  |  | $ | 193,788 |  |
| Work in process | 131,129 |  |  | 115,497 |  |
| Finished goods | 181,376 |  |  | 173,513 |  |
| Inventory reserves | (82,695) |  |  | (66,525) |  |
| Total | $ | 416,472 |  |  | $ | 416,273 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001628280-26-009585:notes:154]
Property, Plant, and Equipment, net

[0001628280-26-009585:notes:155]
The components of net property, plant, and equipment at December 27, 2025 and December 28, 2024 were as follows:

[0001628280-26-009585:notes:156]
| (in thousands) | 2025 |  | 2024 |
| Land and land improvements | $ | 24,088 |  |  | $ | 17,593 |  |
| Building and building improvements | 215,024 |  |  | 192,441 |  |
| Machinery and equipment | 998,988 |  |  | 892,940 |  |
| Accumulated depreciation and amortization | (697,460) |  |  | (625,906) |  |
| Total | $ | 540,640 |  |  | $ | 477,068 |  |

[0001628280-26-009585:notes:157]
The Company recorded depreciation expense of $74.9 million, $68.3 million, and $71.6 million for the fiscal years ended December 27, 2025, December 28, 2024, and December 30, 2023, respectively, in Cost of sales, Selling, general, and administrative expenses, and Research and development expenses in the Consolidated Statements of Net (Loss) Income.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001628280-26-009585:notes:158]
Goodwill and Other Intangible Assets

[0001628280-26-009585:notes:159]
The amounts for goodwill and changes in the carrying value by segment were as follows:

[0001628280-26-009585:notes:160]
| (in thousands) | Electronics |  | Transportation |  | Industrial |  | Total |
| Gross goodwill as of December 30, 2023 | $ | 936,505 |  |  | $ | 237,115 |  |  | $ | 179,117 |  |  | $ | 1,352,737 |  |
| Accumulated impairment losses as of December 30, 2023 | — |  |  | (34,004) |  |  | (8,735) |  |  | (42,739) |  |
| Net goodwill as of December 30, 2023 | $ | 936,505 |  |  | $ | 203,111 |  |  | $ | 170,382 |  |  | $ | 1,309,998 |  |
| Changes during 2024: |  |  |  |  |  |  |  |
| Impairments | — |  |  | (8,616) |  |  | (36,147) |  |  | (44,763) |  |
| Foreign currency translation adjustments | (29,634) |  |  | (2,854) |  |  | (4,245) |  |  | (36,733) |  |
| Gross goodwill as of December 28, 2024 | 906,871 |  |  | 233,286 |  |  | 173,882 |  |  | 1,314,039 |  |
| Accumulated impairment losses as of December 28, 2024 | — |  |  | (41,645) |  |  | (43,892) |  |  | (85,537) |  |
| Net goodwill as of December 28, 2024 | $ | 906,871 |  |  | $ | 191,641 |  |  | $ | 129,990 |  |  | $ | 1,228,502 |  |
| Changes during 2025: |  |  |  |  |  |  |  |
| Additions (a) | 57,321 |  |  | — |  |  | 152,343 |  |  | 209,664 |  |
| Impairments | (301,185) |  |  | — |  |  | — |  |  | (301,185) |  |
| Foreign currency translation adjustments | 61,322 |  |  | 5,758 |  |  | 7,350 |  |  | 74,430 |  |
| Gross goodwill as of December 27, 2025 | 1,027,462 |  |  | 242,192 |  |  | 338,739 |  |  | 1,608,393 |  |
| Accumulated impairment losses as of December 27, 2025 | (303,133) |  |  | (44,793) |  |  | (49,056) |  |  | (396,982) |  |
| Net goodwill as of December 27, 2025 | $ | 724,329 |  |  | $ | 197,399 |  |  | $ | 289,683 |  |  | $ | 1,211,411 |  |

[0001628280-26-009585:notes:161]
(a) The additions resulted from the acquisitions of Dortmund Fab and Basler.

[0001628280-26-009585:notes:162]
The Company tests its goodwill annually for impairment on the first day of its fiscal fourth quarter, or more frequently if an event occurs or circumstances change that would more likely than not reduce the fair value of a reporting unit below its carrying value. The results of the goodwill impairment test as of September 28, 2025 indicated that the estimated fair value for the Electronics-Semiconductor reporting unit was below its respective carrying value. Accordingly, the Company recorded a non-cash charge of $301.2 million to reflect the impairment of goodwill for the Electronics-Semiconductor reporting unit within the Electronics segment during the fourth quarter of 2025.

[0001628280-26-009585:notes:163]
The goodwill impairment charge for the Electronics-Semiconductor reporting unit in the fourth quarter of 2025 was due to reductions in the estimated fair value from lower expectations for future revenue, profitability and cash flows for the Electronics-Semiconductor reporting unit as compared to the expectations of the 2024 annual goodwill impairment test. In the context of a recent leadership transition and strategic reassessment in the semiconductor business, the reduction was primarily driven by lower projected volumes in the power semiconductor business, largely associated with the Dortmund Fab.

[0001628280-26-009585:notes:164]
During the fourth quarter of 2024, the Company recorded non-cash charges of $36.1 million and $8.6 million, respectively, to reflect the impairment of goodwill for the Industrial controls and sensors reporting unit within the Industrial segment and the Automotive sensors reporting unit within the Transportation segment. There were no impairment charges recorded during the fiscal year of 2023. The goodwill impairment charge for the Industrial controls and sensors reporting unit was due to a reduction in the estimated fair value of the reporting unit based on lower expectations for future revenue, profitability and cash flows as compared to the expectations of the 2023 annual goodwill impairment test driven by lower-than-expected demand in the electric vehicle end market as well as reduced government funding to support charging infrastructures for electric vehicles, primarily in Europe.

[0001628280-26-009585:notes:165]
The goodwill impairment charge was determined using Level 3 inputs, including discounted cash flow analysis and comparable marketplace fair value data. As of December 27, 2025, the Electronics-Semiconductor and the Industrial Controls and Sensors reporting units had $238.5 million and $274.9 million of remaining goodwill, respectively.

[0001628280-26-009585:notes:166]
The components of intangible assets at December 27, 2025 and December 28, 2024 were as follows:

[0001628280-26-009585:notes:167]
|  | As of December 27, 2025 |
| (in thousands) | GrossCarryingValue |  | AccumulatedAmortization |  | Net BookValue |
| Land use rights | $ | 16,661 |  |  | $ | 3,613 |  |  | $ | 13,048 |  |
| Patents, licenses, and software | 291,192 |  |  | 212,184 |  |  | 79,008 |  |
| Distribution network | 42,384 |  |  | 42,384 |  |  | — |  |
| Customer relationships, trademarks, and tradenames | 793,670 |  |  | 290,819 |  |  | 502,851 |  |
| Total | $ | 1,143,907 |  |  | $ | 549,000 |  |  | $ | 594,907 |  |

[0001628280-26-009585:notes:168]
|  | As of December 28, 2024 |
| (in thousands) | GrossCarryingValue |  | AccumulatedAmortization |  | Net BookValue |
| Land use rights | $ | 16,079 |  |  | $ | 2,994 |  |  | $ | 13,085 |  |
| Patents, licenses, and software | 260,096 |  |  | 180,674 |  |  | 79,422 |  |
| Distribution network | 41,667 |  |  | 41,667 |  |  | — |  |
| Customer relationships, trademarks, and tradenames | 632,572 |  |  | 242,961 |  |  | 389,611 |  |
| Total | $ | 950,414 |  |  | $ | 468,296 |  |  | $ | 482,118 |  |

[0001628280-26-009585:notes:169]
During the fiscal year ended December 27, 2025, the Company recorded additions to other intangible assets of $150.0 million and $1.8 million related to the Basler and Dortmund Fab acquisitions, respectively, the components of which were as follows:

[0001628280-26-009585:notes:170]
|  | 2025 |
| (in thousands, except weighted average useful life) | Weighted AverageUseful Life (Years) |  | Amount |
| Basler |  |  |  |
| Patents, developed technology | 6.0 |  | $ | 15,000 |  |
| Customer relationships, trademarks, and tradenames | 13.6 |  | 135,000 |  |
|  |  |  | $ | 150,000 |  |
| Dortmund Fab |  |  |  |
| Customer relationships, trademarks, and tradenames | 5.0 |  | $ | 1,800 |  |

[0001628280-26-009585:notes:171]
For intangible assets with definite lives, the Company recorded amortization expense of $59.8 million, $62.1 million, and $65.8 million in 2025, 2024, and 2023, respectively.

[0001628280-26-009585:notes:172]
During the fourth quarter of 2024, the Company recorded non-cash impairment charges of $47.8 million for the impairment of intangible assets, including $47.6 million related to the impairment of certain acquired customer relationships, developed technology, and tradename intangible assets in the Industrial Controls and Sensors reporting unit within the Industrial segment. This impairment resulted from lower expectations of future revenue and cash flows and was determined using Level 3 inputs and estimated based on cash flow analyses, which included management’s assumptions related to future revenues and profitability. The remaining impairment charges included $0.2 million for patents and customer relationships related to the exit of a small business in China within Industrial segment. In addition, during the first quarter of 2024, the Company recognized a $0.9 million impairment related to certain machinery and equipment in the commercial vehicle business within the Transportation segment.

[0001628280-26-009585:notes:173]
Estimated annual amortization expense related to intangible assets with definite lives at December 27, 2025 is as follows:

[0001628280-26-009585:notes:174]
| (in thousands) | Amount |
| 2026 | $ | 61,306 |  |
| 2027 | 59,123 |  |
| 2028 | 58,720 |  |
| 2029 | 58,309 |  |
| 2030 | 54,908 |  |
| 2031 and thereafter | 302,541 |  |
| Total | $ | 594,907 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001628280-26-009585:notes:175]
Accrued Liabilities

[0001628280-26-009585:notes:176]
The components of accrued liabilities at December 27, 2025 and December 28, 2024 were as follows:

[0001628280-26-009585:notes:177]
| (in thousands) | 2025 |  | 2024 |
| Employee-related liabilities | $ | 114,662 |  |  | $ | 67,639 |  |
| Current lease liability | 11,435 |  |  | 13,900 |  |
| Deferred revenue | 11,215 |  |  | 1,557 |  |
| Other non-income taxes | 7,960 |  |  | 7,022 |  |
| Interest | 7,069 |  |  | 8,131 |  |
| Professional services | 6,629 |  |  | 6,613 |  |
| Restructuring liability | 6,014 |  |  | 4,624 |  |
| Other customer reserves | 2,874 |  |  | 3,450 |  |
| Current benefit liability | 1,680 |  |  | 1,514 |  |
| Current hedge liability | — |  |  | 4,067 |  |
| Other | 29,733 |  |  | 29,759 |  |
| Total | $ | 199,271 |  |  | $ | 148,276 |  |

[0001628280-26-009585:notes:178]
Employee-related liabilities consist primarily of payroll, sales commission, bonus, employee benefit accruals and workers’ compensation. Bonus accruals include amounts earned pursuant to the Company’s primary employee incentive compensation plans. Other accrued liabilities include miscellaneous operating accruals and other customer-related liabilities.


## us-gaap:LesseeFinanceLeasesTextBlock

[0001628280-26-009585:notes:179]
Lease Commitments
Under ASC 842, a contract contains a lease if there is an identified asset and the Company has the right to control the asset. The Company determines whether a contract contains a lease at contract inception. The Company leases office and production space under various non-cancellable operating leases that expire no later than 2036. Certain real estate leases include one or more options to renew. The exercise of lease renewal options is at the Company's sole discretion. Options to extend the lease are included in the lease term when it is reasonably certain the Company will exercise the option. The depreciable life of assets and leasehold improvements are limited by the expected lease term, unless there is a transfer of title or purchase option that is reasonably certain of exercise. Certain leases include rental payments adjusted periodically for inflation. The lease agreements do not contain any material residual value guarantee or material restrictive covenants. The Company has elected to use the available practical expedient to account for the lease and non-lease components of its leases as a single component. As the Company elected not to separate lease and non-lease components and instead to account for them as a single lease component, the variable lease cost primarily represents variable payments such as common area maintenance and utilities.

[0001628280-26-009585:notes:180]
The Company does not have a published credit rating because it has no publicly traded debt; therefore, the Company is generating its incremental borrowing rate ("IBR"), using a synthetic credit rating model that compares its credit quality to other rated companies based on certain financial metrics and ratios. The reference rate will be based on the yield curve of companies with similar credit quality based on the metrics and adjusted for currency in regions where we have significant operations.

[0001628280-26-009585:notes:181]
All leases with an initial term of 12 months or less that do not include an option to extend or purchase the underlying asset that the Company is reasonably certain to exercise (“short-term leases”) are not recorded on the Consolidated Balance Sheets. Short-term lease expenses are recognized on a straight-line basis over the lease term.

[0001628280-26-009585:notes:182]
The following table presents the classification of right of use assets and lease liabilities as of December 27, 2025 and December 28, 2024:

[0001628280-26-009585:notes:183]
|  |  |  | Fiscal Year Ended |
| (in thousands) | Consolidated Balance Sheet Classification |  | December 27, 2025 |  | December 28, 2024 |
| Operating Leases |  |  |  |  |  |
| Right of use assets - operating lease | Right of use lease assets |  | $ | 85,318 |  |  | $ | 71,513 |  |
| Current operating lease liabilities | Accrued liabilities |  | 11,347 |  |  | 13,626 |  |
| Non-current operating lease liabilities | Non-current lease liabilities |  | 71,664 |  |  | 60,558 |  |
| Total operating lease liabilities |  |  | $ | 83,011 |  |  | $ | 74,184 |  |
| Finance Leases |  |  |  |  |  |
| Right of use assets - finance lease | Right of use lease assets |  | $ | 945 |  |  | $ | 698 |  |
| Current finance lease liabilities | Accrued liabilities |  | 88 |  |  | 274 |  |
| Non-current finance lease liabilities | Non-current lease liabilities |  | 101 |  |  | 1 |  |
| Total finance lease liabilities |  |  | $ | 189 |  |  | $ | 275 |  |

[0001628280-26-009585:notes:184]
The following table represents the lease costs for 2025, 2024, and 2023:

[0001628280-26-009585:notes:185]
|  |  |  | Fiscal Year Ended |
| (in thousands) | Consolidated Statements of Net (Loss) Income Classification |  | December 27, 2025 |  | December 28, 2024 |  | December 30, 2023 |
| Operating lease expenses | Cost of sales, Selling, general, and administrative expenses |  | $ | 18,906 |  |  | $ | 17,310 |  |  | $ | 15,817 |  |
| Finance lease: |  |  |  |  |  |  |  |
| Finance lease expenses | Cost of sales |  | 107 |  |  | 96 |  |  | 219 |  |
| Interest on lease liabilities | Other (income) expense, net |  | 9 |  |  | 8 |  |  | 19 |  |
| Short-term lease expenses | Cost of sales, Selling, general, and administrative expenses |  | 758 |  |  | 1,170 |  |  | 1,229 |  |
| Variable lease expenses | Cost of sales, Selling, general, and administrative expenses |  | 1,407 |  |  | 1,151 |  |  | 1,034 |  |
| Total lease costs | Cost of sales, Selling, general, and administrative expenses |  | $ | 21,187 |  |  | $ | 19,735 |  |  | $ | 18,318 |  |

[0001628280-26-009585:notes:186]
The Company leases certain office and warehouse space as well as certain machinery and equipment under non-cancellable operating leases. Rent expense under these leases was $21.2 million, $19.7 million, and $18.3 million in 2025, 2024, and 2023, respectively.

[0001628280-26-009585:notes:187]
| Maturity of lease liabilities as of December 27, 2025(in thousands) | Operating Leases |  | Finance Leases |
| 2026 | $ | 15,282 |  |  | $ | 94 |  |
| 2027 | 14,481 |  |  | 97 |  |
| 2028 | 13,681 |  |  | 4 |  |
| 2029 | 13,031 |  |  | 4 |  |
| 2030 | 10,583 |  |  | — |  |
| 2031 and thereafter | 35,091 |  |  | — |  |
| Total lease payments | $ | 102,149 |  |  | $ | 199 |  |
| Less: Imputed interest | (19,138) |  |  | (10) |  |
| Present value of lease liabilities | $ | 83,011 |  |  | $ | 189 |  |

[0001628280-26-009585:notes:188]
|  | Fiscal Year Ended |
|  | December 27, 2025 |  | December 28, 2024 |
| Weighted-average remaining lease term (years) |  |  |  |
| Operating leases | 7.63 |  | 8.67 |
| Finance leases | 1.56 |  | 1.00 |
| Weighted-average discount rate |  |  |  |
| Operating leases | 5.07 | % |  | 5.39 | % |
| Finance leases | 5.30 | % |  | 2.00 | % |

[0001628280-26-009585:notes:189]
|  | Fiscal Year Ended |
| (in thousands) | December 27, 2025 |  | December 28, 2024 |  | December 30, 2023 |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |  |  |
| Operating cash flow - payments on operating leases | $ | (19,848) |  |  | $ | (13,258) |  |  | $ | (14,518) |  |
| Operating cash flow - interest payments on finance leases | (9) |  |  | (8) |  |  | (19) |  |
| Financing cash flow - payments on finance lease obligations | (377) |  |  | (280) |  |  | (1,164) |  |
| Leased assets obtained in exchange of new lease obligations, including leases acquired: |  |  |  |  |  |
| Operating leases | $ | 21,895 |  |  | $ | 26,785 |  |  | $ | 16,689 |  |
| Finance leases | 269 |  |  | — |  |  | — |  |

[0001628280-26-009585:notes:190]
There were no sale leaseback transactions for the fiscal years ended December 27, 2025 and December 30, 2023. The net gain recorded from a sale leaseback transaction was $0.3 million for the fiscal year ended December 28, 2024.


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0001628280-26-009585:notes:191]
Restructuring, Impairment, and Other Charges
The Company recorded restructuring, impairment, and other charges for fiscal years 2025, 2024, and 2023 as follows:

[0001628280-26-009585:notes:192]
|  | Fiscal Year Ended December 27, 2025 |
| (in thousands) | Electronics |  | Transportation |  | Industrial |  | Total |
| Employee terminations | $ | 8,708 |  |  | $ | 7,542 |  |  | $ | 992 |  |  | $ | 17,242 |  |
| Other restructuring charges | 639 |  |  | 116 |  |  | 1 |  |  | 756 |  |
| Total restructuring charges | 9,347 |  |  | 7,658 |  |  | 993 |  |  | 17,998 |  |
| Impairment | 301,521 |  |  | 531 |  |  | — |  |  | 302,052 |  |
| Total | $ | 310,868 |  |  | $ | 8,189 |  |  | $ | 993 |  |  | $ | 320,050 |  |

[0001628280-26-009585:notes:193]
|  | Fiscal Year Ended December 28, 2024 |
| (in thousands) | Electronics |  | Transportation |  | Industrial |  | Total |
| Employee terminations | $ | 8,748 |  |  | $ | 4,620 |  |  | $ | 583 |  |  | $ | 13,951 |  |
| Other restructuring charges | 310 |  |  | 543 |  |  | 122 |  |  | 975 |  |
| Total restructuring charges | 9,058 |  |  | 5,163 |  |  | 705 |  |  | 14,926 |  |
| Impairment | — |  |  | 9,549 |  |  | 83,966 |  |  | 93,515 |  |
| Total | $ | 9,058 |  |  | $ | 14,712 |  |  | $ | 84,671 |  |  | $ | 108,441 |  |

[0001628280-26-009585:notes:194]
|  | Fiscal Year Ended December 30, 2023 |
| (in thousands) | Electronics |  | Transportation |  | Industrial |  | Total |
| Employee terminations | $ | 4,162 |  |  | $ | 3,649 |  |  | $ | 894 |  |  | $ | 8,705 |  |
| Other restructuring charges | 342 |  |  | 976 |  |  | 1,625 |  |  | 2,943 |  |
| Total restructuring charges | 4,504 |  |  | 4,625 |  |  | 2,519 |  |  | 11,648 |  |
| Impairment | 111 |  |  | 3,870 |  |  | 872 |  |  | 4,853 |  |
| Total | $ | 4,615 |  |  | $ | 8,495 |  |  | $ | 3,391 |  |  | $ | 16,501 |  |

[0001628280-26-009585:notes:195]
2025

[0001628280-26-009585:notes:196]
For the year ended December 27, 2025, the Company recorded $302.1 million of non-cash impairment charges, which included a $301.2 million non-cash goodwill impairment charge associated with the Electronics-Semiconductor reporting unit within the Electronics segment. The remaining impairment charges included $0.5 million and $0.4 million of impairment charges related to certain machinery and equipment in the commercial vehicle business within the Transportation segment and the electronics products business within the Electronics segment, respectively. The Company also recorded total restructuring charges of $18.0 million, primarily for employee termination costs. These charges primarily related to the reorganization of certain manufacturing, selling and administrative functions in the power semiconductor business within the Electronics segment and the reorganization of certain manufacturing, selling and administrative functions in the commercial vehicle business and automotive sensors business within the Transportation segment. See Note 5, Goodwill and Other Intangible Assets for further discussion regarding the goodwill and intangible impairment charges.

[0001628280-26-009585:notes:197]
2024

[0001628280-26-009585:notes:198]
For the year ended December 28, 2024, the Company recorded $93.5 million of non-cash impairment charges, which included $47.8 million for the impairment of intangible assets primarily related to certain acquired customer relationships, developed technology, and tradename in the Industrial Controls and Sensors reporting unit within the Industrial segment, and $36.1 million and $8.6 million of non-cash goodwill impairment charges associated with the Industrial Controls and Sensors reporting unit within the Industrial segment and the Automotive sensors reporting unit within the Transportation segment, respectively. The remaining impairment charges included $0.2 million for patents and customer relationships related to the exit of a small business in China within the Industrial segment. In addition, during the first quarter of 2024, the Company recognized a $0.9 million impairment related to certain machinery and equipment in the commercial vehicle business within the Transportation segment. The Company also recorded total restructuring charges of $14.9 million, primarily for employee termination costs. These charges primarily related to the reorganization of certain manufacturing, selling and administrative functions in the semiconductor business within the Electronics segment and the reorganization of certain selling and administrative functions in the commercial vehicle business within the Transportation segment. See Note 5, Goodwill and Other Intangible Assets for further discussion regarding the goodwill and intangible impairment charges.

[0001628280-26-009585:notes:199]
2023

[0001628280-26-009585:notes:200]
For the year ended December 30, 2023, the Company recorded total restructuring charges of $11.6 million, primarily for employee termination costs. These charges primarily related to the reorganization of certain manufacturing, selling and administrative functions within the Transportation segment's commercial vehicle business, the reorganization of certain selling and administrative functions within the Electronics segment due to the C&K Switches acquisition, and reorganization of certain manufacturing, selling and administrative functions within the Industrial segment. During 2023, the Company recorded a $3.9 million impairment charge related to the land and building of a property in the commercial vehicle business within the Transportation segment that the Company made the decision to donate, a $0.9 million impairment charge substantially related to certain patents in a business within the Industrial segment, and a $0.1 million impairment related to certain machinery and equipment in the semiconductor business within the Electronics segment.

[0001628280-26-009585:notes:201]
The restructuring reserves as of December 27, 2025 and December 28, 2024 were $6.0 million and $4.6 million, respectively included within Accrued liabilities. Additionally, $0.3 million was included within Other long-term liabilities in the Consolidated Balance Sheets as of December 27, 2025. Payments associated with employee terminations reflected in the above table were substantially completed by December 27, 2025. The Company anticipates that the remaining payments associated with employee terminations will be substantially completed in fiscal 2026.


## us-gaap:DebtDisclosureTextBlock

[0001628280-26-009585:notes:202]
Debt

[0001628280-26-009585:notes:203]
The carrying amounts of debt at December 27, 2025 and December 28, 2024 were as follows:

[0001628280-26-009585:notes:204]
| (in thousands) | 2025 |  | 2024 |
| Revolving credit facility | $ | 100,000 |  |  | $ | 100,000 |  |
| Term loan | 266,250 |  |  | 281,250 |  |
| Euro Senior Notes, Series B due 2028 | 111,977 |  |  | 98,928 |  |
| U.S. Senior Notes, Series A due 2025 | — |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2027 | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series B due 2030 | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 | 100,000 |  |  | 100,000 |  |
| Other | 1,233 |  |  | 3,702 |  |
| Unamortized debt issuance costs | (1,833) |  |  | (2,766) |  |
| Total debt | 802,627 |  |  | 856,114 |  |
| Less: Current maturities | (96,233) |  |  | (67,612) |  |
| Total long-term debt | $ | 706,394 |  |  | $ | 788,502 |  |

[0001628280-26-009585:notes:205]
Interest paid on all Company debt was $34.4 million, $36.2 million, and $37.2 million in fiscal year 2025, 2024, and 2023, respectively, which included cash settlements received from the interest rate swap entered on May 12, 2022.

[0001628280-26-009585:notes:206]
Revolving Credit Facility and Term Loan

[0001628280-26-009585:notes:207]
On June 30, 2022, the Company amended and restated its Credit Agreement, dated as of April 3, 2020 (as so amended and restated, the “Credit Agreement”) to effect certain changes, including, among other changes: (i) adding a $300 million unsecured term loan credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company and its subsidiaries; (iii) replacing LIBOR-based interest rate benchmarks and modifying performance-based interest rate margins; and (iv) extending the maturity date to June 30, 2027 (the “Maturity Date”). Pursuant to the Credit Agreement, the Company may, from time to time, increase the size of the revolving credit facility or enter into one or more tranches of term loans in minimum increments of $25 million if there is no event of default and the Company is in compliance with certain financial covenants.

[0001628280-26-009585:notes:208]
Loans made under the available credit facility pursuant to the Credit Agreement (the "Credit Facility") bear interest at the Company’s option, at either SOFR, fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 1.75%, plus a SOFR adjustment of 0.10% or at the bank’s Base Rate, as defined in the Credit Agreement, plus 0.00% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to 0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.

[0001628280-26-009585:notes:209]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the fiscal year ended December 27, 2025, the Company made term loan payments of $15.0 million. The revolving loan and term loan balance under the Credit Facility was $100.0 million and $266.3 million, respectively, as of December 27, 2025.

[0001628280-26-009585:notes:210]
On May 12, 2022, the Company entered into an interest rate swap agreement to manage interest rate risk exposure, effectively converting the interest rate on the Company's SOFR based floating-rate loans to a fixed-rate. The interest rate swap, with a notional value of $200 million, was designated as a cash flow hedge against the variability of cash flows associated with the Company's SOFR based loans scheduled to mature on June 30, 2027.

[0001628280-26-009585:notes:211]
As of December 27, 2025, the effective interest rate on unhedged portion of the outstanding borrowings under the Credit Facility was 4.82%, and 3.88% on the hedged portion.

[0001628280-26-009585:notes:212]
As of December 27, 2025, the Company had $1.1 million outstanding in letters of credit and had available $598.9 million of borrowing capacity under the revolving credit facility. As of December 27, 2025, the Company was in compliance with all covenants under the credit agreement.

[0001628280-26-009585:notes:213]
Senior Notes

[0001628280-26-009585:notes:214]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). During the fiscal year ended December 30, 2023, the Company paid off €117 million of Euro Senior Notes, Series A due 2023. Interest on the Euro Senior Notes, Series B due 2028 is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0001628280-26-009585:notes:215]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. During the fiscal year ended December 31, 2022, the Company paid off $25 million of U.S. Senior Notes, Series A due 2022. Interest on the U.S. Senior Notes, Series B due 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0001628280-26-009585:notes:216]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together, the “U.S. Senior Notes due 2025 and 2030”) were funded. During the first fiscal quarter of 2025, the Company paid

[0001628280-26-009585:notes:217]
off $50 million of U.S. Senior Notes, Series A due 2025. Interest on the U.S. Senior Notes Series B due 2030 is payable on February 15 and August 15, commencing on August 15, 2018.

[0001628280-26-009585:notes:218]
On May 18, 2022, the above note purchase agreements were amended to, among other things, update certain terms, including financial covenants to be consistent with the terms of the restated Credit Agreement and the 2022 Purchase Agreement, as defined below.

[0001628280-26-009585:notes:219]
On May 18, 2022, the Company entered into a Note Purchase Agreement (“2022 Purchase Agreement”) pursuant to which the Company issued and funded on July 18, 2022 $100 million in aggregate principal amount of 4.33% Senior Notes, due June 30, 2032 (“U.S. Senior Notes, due 2032”) (together with the U.S. Senior Notes due 2025 and 2030, the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”). Interest on the U.S. Senior Notes due 2032 is payable semiannually on June 30 and December 30, commencing on December 30, 2022.

[0001628280-26-009585:notes:220]
The Senior Notes have not been registered under the Securities Act, or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the Company.

[0001628280-26-009585:notes:221]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. As of December 27, 2025, the Company was in compliance with all covenants under the Senior Notes.

[0001628280-26-009585:notes:222]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders, and is required to offer to repurchase the Senior Notes at par following certain events, including a change of control.

[0001628280-26-009585:notes:223]
Debt Issuance Costs

[0001628280-26-009585:notes:224]
During fiscal year 2022, the Company paid debt issuance costs of $2.7 million in connection with the amended and restated Credit Agreement, dated June 30, 2022 which, along with the remaining balance of debt issuance costs of the previous credit facility, are being amortized over the life of the amended and restated Credit Agreement.

[0001628280-26-009585:notes:225]
Debt Maturities

[0001628280-26-009585:notes:226]
Scheduled maturities of the Company’s long-term debt for each of the five years succeeding December 27, 2025 and thereafter are summarized as follows:

[0001628280-26-009585:notes:227]
| (in thousands) | ScheduledMaturities |
| 2026 | $ | 96,233 |  |
| 2027 | 371,250 |  |
| 2028 | 111,977 |  |
| 2029 | — |  |
| 2030 | 125,000 |  |
| 2031 and thereafter | 100,000 |  |
|  | $ | 804,460 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-26-009585:notes:228]
Fair Value of Assets and Liabilities
For assets and liabilities measured at fair value on a recurring and nonrecurring basis, a three-level hierarchy of measurements based upon observable and unobservable inputs is used to arrive at fair value. Observable inputs are developed based on market data obtained from independent sources, while unobservable inputs reflect the Company’s assumptions about valuation based on the best information available in the circumstances. Depending on the inputs, the Company classifies each fair value measurement as follows:

[0001628280-26-009585:notes:229]
Level 1—Valuations based on unadjusted quoted prices for identical assets or liabilities in active markets;

[0001628280-26-009585:notes:230]
Level 2—Valuations based upon quoted prices for similar instruments, prices for identical or similar instruments in markets that are not active, or model-derived valuations, all of whose significant inputs are observable or can be corroborated by observable market data;

[0001628280-26-009585:notes:231]
Level 3—Valuations based upon one or more significant unobservable inputs;

[0001628280-26-009585:notes:232]
There were no transfers in or out of Level 1, Level 2 and Level 3 during the year ended December 27, 2025.

[0001628280-26-009585:notes:233]
Following is a description of the valuation methodologies used for instruments measured at fair value and their classification in the valuation hierarchy.

[0001628280-26-009585:notes:234]
Cash Equivalents

[0001628280-26-009585:notes:235]
Cash equivalents primarily consist of money market funds, certificates of deposit, and short-term time deposits, which are held with institutions with sound credit ratings and are highly liquid. The Company classified cash equivalents as Level 1 and are valued at cost, which approximates fair value.

[0001628280-26-009585:notes:236]
Investments in Equity Securities

[0001628280-26-009585:notes:237]
Investments in equity securities listed on a national market or exchange are valued at the last sales price and classified within Level 1 of the valuation hierarchy. Such securities are further detailed in Note 1, Summary of Significant Accounting Policies and Other Information.

[0001628280-26-009585:notes:238]
Derivatives Designated as Hedging Instruments

[0001628280-26-009585:notes:239]
For derivatives that will be accounted for as hedging instruments, the Company formally designates and documents, at inception, the financial instrument as a hedge of a specific underlying exposure, the risk management objective, and the strategy for undertaking the hedge transaction. In addition, the Company formally assesses, both at the inception and at least quarterly thereafter, whether the financial instruments used in hedging transactions are effective at offsetting changes in either the fair values or cash flows of the related underlying exposures. For highly effective cash flow hedges, ASC 815 requires the entire change in fair value of the hedging instrument included in the assessment of hedge effectiveness to be recorded in other comprehensive income. No components of the Company's hedging instruments were excluded from the assessment of hedge effectiveness.

[0001628280-26-009585:notes:240]
Zero Cost Collar Agreement

[0001628280-26-009585:notes:241]
In July 2024, the Company implemented a hedging program to manage foreign currency risk exposure related to fluctuations between the U.S. dollar and Mexican peso. These foreign currency zero cost collars are designated as cash flow hedges for a portion of our Mexican peso-denominated manufacturing expenses, predominantly salary expenses, vendor payments, and utility expenses. If the spot rate is between the weighted-average ceiling and floor rates on the date of maturity, then the Company would not owe or receive any payments under these collars. The Company plans to continue executing zero cost collars with 14-month rolling maturities as an ongoing strategy to hedge peso-denominated manufacturing expenses. The trade

[0001628280-26-009585:notes:242]
entry date, maturity date, weighted-average floor, and weighted-average ceiling for each collar trade was as follows:

[0001628280-26-009585:notes:243]
| Trade Entry Date | Trade Maturity Date | Weighted-Average Floor | Weighted-Average Ceiling |
| July 3, 2024 | August 29, 2025 | 18.0000 | 19.4350 |
| August 5, 2024 | September 29, 2025 | 19.6550 | 21.0000 |
| September 3, 2024 | November 3, 2025 | 20.0820 | 21.7571 |
| September 30, 2024 | November 26, 2025 | 19.8700 | 21.3650 |
| November 4, 2024 | January 2, 2026 | 20.1200 | 21.6900 |
| December 3, 2024 | February 2, 2026 | 20.4250 | 22.0377 |
| January 2, 2025 | March 2, 2026 | 20.8000 | 21.9082 |
| February 6, 2025 | March 30, 2026 | 20.5300 | 22.0000 |
| April 9, 2025 | June 1, 2026 | 20.9700 | 22.2355 |
| May 1, 2025 | June 29, 2026 | 19.6940 | 20.9700 |
| June 4, 2025 | August 3, 2026 | 19.3100 | 20.3437 |
| July 2, 2025 | August 31, 2026 | 18.8500 | 19.8025 |
| August 5, 2025 | September 29, 2026 | 18.8500 | 19.8000 |
| September 2, 2025 | November 2, 2026 | 18.8100 | 19.8347 |
| September 30, 2025 | November 30, 2026 | 18.4200 | 19.3700 |
| November 4, 2025 | January 4, 2027 | 18.7200 | 19.7000 |
| November 26, 2025 | February 2, 2027 | 18.4300 | 19.4852 |

[0001628280-26-009585:notes:244]
The fair value of the collars was determined using an independent third-party valuation model. Pursuant to this model, changes in fair value of derivatives that are designated as cash flow hedges are deferred in accumulated other comprehensive loss until the underlying transactions are recognized in earnings. For the fiscal year ended December 27, 2025, the Company recorded a pre-tax unrealized gain on the collars of $10.8 million. The Company estimates that approximately $7.2 million of pre-tax gains currently recorded in accumulated other comprehensive loss will be recognized in earnings over the next 12 months. The amounts included in accumulated other comprehensive loss will be reclassified to earnings should the hedge no longer be considered effective. No amount of ineffectiveness was included in net income for the fiscal year ended December 27, 2025. The Company will continue to assess the effectiveness of the hedge on an ongoing basis. The primary inputs into the valuation of the collars are interest yield curves, interest rate volatilities, foreign exchange rates, foreign exchange volatilities, credit risk, credit spreads and other market information. The collars are classified within Level 2 of the fair value hierarchy since all significant inputs are corroborated by market observable data.

[0001628280-26-009585:notes:245]
Interest Rate Swap

[0001628280-26-009585:notes:246]
On May 12, 2022, the Company entered into an interest rate swap agreement to manage interest rate risk exposure, effectively converting the interest rate on the Company's SOFR based floating-rate loans to a fixed-rate. The interest rate swap, with a notional value of $200 million, was designated as a cash flow hedge against the variability of cash flows associated with the Company's SOFR based loans scheduled to mature on June 30, 2027. The fair value of the interest rate swap was valued using an independent third-party valuation model. Pursuant to this model, changes in fair value of derivatives that are designated as cash flow hedges are deferred in accumulated other comprehensive loss until the underlying transactions are recognized in earnings. For the fiscal year ended December 27, 2025, the Company recorded a pre-tax unrealized loss on the interest rate swap of $4.7 million. The Company estimates that approximately $1.2 million of pre-tax gains currently recorded in accumulated other comprehensive loss will be recognized in earnings over the next 12 months. The primary inputs into the valuation of the interest rate swap are interest yield curves, interest rate volatility, credit risk, credit spreads and other market information. The interest rate swap is classified within Level 2 of the fair value hierarchy since all significant inputs are corroborated by observable market data.

[0001628280-26-009585:notes:247]
The use of derivatives creates exposure to credit risk relating to potential losses that could be recognized in the event that the counterparties to these instruments fail to perform their obligations under the contracts. The Company seeks to minimize this risk by limiting our counterparties to major financial institutions with acceptable credit ratings and monitoring the total value of positions with individual counterparties. In the event of a default by one of our counterparties, the Company may not receive payments provided for under the terms of our derivatives.

[0001628280-26-009585:notes:248]
Derivatives Not Designated as Hedging Instruments

[0001628280-26-009585:notes:249]
On July 14, 2022, the Company entered into a foreign currency exchange forward contract to mitigate the currency fluctuation risk between the Euro and U.S. dollar on its Euro denominated Senior Notes, Series A due 2023. The notional value of the forward contract at July 14, 2022 was €117 million and expired on December 7, 2023 with the final settlement value of $6.3 million which the Company used to convert USD to Euro to pay down the €117 million of Euro Senior Notes, Series A due 2023. The foreign currency contract was not designated as a hedge instrument and was marked to market on a monthly basis. As a result, changes in fair value during 2023 were reported in Foreign exchange (loss) gain in the Consolidated Statements of Net (Loss) Income. The fair value of the foreign currency forward contract was valued by a third party using market exchange rates and classified as a Level 2 input under the fair value hierarchy.

[0001628280-26-009585:notes:250]
As of December 27, 2025 and December 28, 2024, the fair values of our derivative financial instrument and their classifications on the Consolidated Balance Sheets were as follows:

[0001628280-26-009585:notes:251]
|  |  |  | Fiscal Year Ended |
| (in thousands) | Consolidated Balance Sheets Classification |  | December 27, 2025 |  | December 28, 2024 |
| Derivatives designated as hedging instruments |  |  |  |  |  |
| Interest rate swap agreement: |  |  |  |  |  |
| Designated as cash flow hedge | Prepaid expenses and other current assets |  | $ | 1,162 |  |  | $ | 2,482 |  |
|  | Other long-term assets |  | 382 |  |  | 3,716 |  |
| Zero cost collar agreement |  |  |  |  |  |
| Designated as cash flow hedge | Prepaid expenses and other current assets |  | $ | 6,816 |  |  | $ | 22 |  |
|  | Accrued liabilities |  | — |  |  | 4,067 |  |
|  | Other long-term assets |  | 3 |  |  | 2 |  |

[0001628280-26-009585:notes:252]
The pre-tax (gains) losses recognized on derivative financial instruments in the Consolidated Statements of Net (Loss) Income for the fiscal year ended December 27, 2025, December 28, 2024, and December 30, 2023 were as follows:

[0001628280-26-009585:notes:253]
|  |  |  | Fiscal Year Ended |
| (in thousands) | Classification of (Gains) Losses Recognized in the Consolidated Statements of Net (Loss) Income |  | December 27, 2025 |  | December 28, 2024 |  | December 30, 2023 |
| Derivatives designated as cash flow hedges |  |  |  |  |  |  |  |
| Interest rate swap agreement | Interest expense, net |  | $ | (2,987) |  |  | $ | (4,826) |  |  | $ | (4,551) |  |
| Zero cost collar agreement | Cost of sales |  | (2,791) |  |  | 1,766 |  |  | — |  |
| Zero cost collar agreement | Selling, general, and administrative expenses |  | (219) |  |  | 97 |  |  | — |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |
| Foreign exchange forward contract | Foreign exchange gain |  | $ | — |  |  | $ | — |  |  | $ | (52) |  |

[0001628280-26-009585:notes:254]
The pre-tax losses (gains) recognized on derivative financial instruments in the Consolidated Statements of Comprehensive Income for the fiscal year ended December 27, 2025, December 28, 2024, and December 30, 2023 were as follows:

[0001628280-26-009585:notes:255]
|  |  | Fiscal Year Ended |  |  |
| (in thousands) |  | December 27, 2025 |  | December 28, 2024 |  | December 30, 2023 |  |  |
| Derivatives designated as cash flow hedges |  |  |  |  |  |  |  |  |
| Interest rate swap agreement |  | $ | 4,654 |  |  | $ | (346) |  |  | $ | 2,827 |  |  |  |
| Zero cost collar agreement |  | (10,787) |  |  | 3,534 |  |  | — |  |  |  |

[0001628280-26-009585:notes:256]
Mutual Funds

[0001628280-26-009585:notes:257]
The Company has a non-qualified Supplemental Retirement and Savings Plan that provides additional retirement benefits for certain management employees and named executive officers by allowing participants to defer a portion of their annual compensation. The Company maintains investment accounts for participants through which participants make investment elections. The marketable securities are classified as Level 1 under the fair value hierarchy as they are maintained in mutual funds with readily determinable fair value and recorded in Other long-term assets on the Consolidated Balance sheets.

[0001628280-26-009585:notes:258]
There were no changes during the fiscal year ended December 27, 2025 to the Company’s valuation techniques used to measure asset and liability fair values on a recurring basis. As of December 27, 2025 and December 28, 2024, the Company did not hold any non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0001628280-26-009585:notes:259]
Defined Benefit Plan Assets / Non-qualified Supplemental Retirement and Savings Plan Investments

[0001628280-26-009585:notes:260]
See Note 11, Benefit Plans, for a description of valuation methodologies and investment balances for defined benefit plan assets and investments related to the Company’s Non-Qualified Supplemental Retirement and Savings Plan.

[0001628280-26-009585:notes:261]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of December 27, 2025:

[0001628280-26-009585:notes:262]
|  | Fair Value Measurements Using |
| (in thousands) | Quoted Prices in Active Markets for Identical Assets (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Total |
| Cash equivalents | $ | 465,915 |  |  | $ | — |  |  | $ | — |  |  | $ | 465,915 |  |
| Investments in equity securities | 7,676 |  |  | — |  |  | — |  |  | 7,676 |  |
| Mutual funds | 25,730 |  |  | — |  |  | — |  |  | 25,730 |  |
| Total | $ | 499,321 |  |  | $ | — |  |  | $ | — |  |  | $ | 499,321 |  |

[0001628280-26-009585:notes:263]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of December 28, 2024:

[0001628280-26-009585:notes:264]
|  | Fair Value Measurements Using |
| (in thousands) | Quoted Prices in Active Markets for Identical Assets (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Total |
| Cash equivalents | $ | 658,491 |  |  | $ | — |  |  | $ | — |  |  | $ | 658,491 |  |
| Investments in equity securities | 10,182 |  |  | — |  |  | — |  |  | 10,182 |  |
| Mutual funds | 23,268 |  |  | — |  |  | — |  |  | 23,268 |  |
| Total: | $ | 691,941 |  |  | $ | — |  |  | $ | — |  |  | $ | 691,941 |  |

[0001628280-26-009585:notes:265]
In addition to the methods and assumptions used for the financial instruments recorded at fair value as discussed above, the following methods and assumptions are used to estimate the fair value of other financial instruments that are not marked to market on a recurring basis. The Company’s other financial instruments include cash and cash equivalents, short-term investments, trade receivables and its long-term debt. Due to their short-term maturity, the carrying amounts of cash and cash equivalents, short-term investments and trade receivables approximate their fair values. The Company’s revolving and term loan debt facilities’ fair values approximate book value at December 27, 2025 and December 28, 2024, as the rates on these borrowings are variable in nature.

[0001628280-26-009585:notes:266]
The carrying value and estimated fair values of the Company’s Euro Senior Notes, Series B and USD Senior Notes, Series A and Series B, as of December 27, 2025 and December 28, 2024 were as follows:

[0001628280-26-009585:notes:267]
|  | December 27, 2025 |  | December 28, 2024 |
| (in thousands) | CarryingValue |  | EstimatedFair Value |  | CarryingValue |  | EstimatedFair Value |
| Euro Senior Notes, Series B due 2028 | $ | 111,977 |  |  | $ | 106,908 |  |  | $ | 98,928 |  |  | $ | 91,741 |  |
| USD Senior Notes, Series A due 2025 | — |  |  | — |  |  | 50,000 |  |  | 49,919 |  |
| USD Senior Notes, Series B due 2027 | 100,000 |  |  | 99,152 |  |  | 100,000 |  |  | 96,623 |  |
| USD Senior Notes, Series B due 2030 | 125,000 |  |  | 120,076 |  |  | 125,000 |  |  | 114,786 |  |
| USD Senior Notes, due 2032 | 100,000 |  |  | 95,587 |  |  | 100,000 |  |  | 91,175 |  |

[0001628280-26-009585:notes:268]
Impairments

[0001628280-26-009585:notes:269]
The results of the annual goodwill impairment test as of September 28, 2025 indicated that the estimated fair value for Electronics-Semiconductor reporting unit were below its respective carrying value. Accordingly, the Company recorded a non-cash impairment charge of $301.2 million to reflect the impairment of goodwill for the Electronics-Semiconductor reporting unit within the Electronics segment. See Note 5, Goodwill and Other Intangible Assets, for further discussion. In addition, the Company recorded $0.5 million and $0.4 million of impairment charges related to certain machinery and equipment in the commercial vehicle business within the Transportation segment and the electronics products business within the Electronics segment, respectively.

[0001628280-26-009585:notes:270]
2025 goodwill impairment charges were the result of measuring a reporting unit at fair value on a nonrecurring basis as shown below:

[0001628280-26-009585:notes:271]
| (in thousands) | For Fiscal Year Ended December 27, 2025 |  | December 27, 2025 |
|  | Impairment Charge |  | Estimated Fair Value Measurement (Level 3) |  | Net Carrying Value |
| Electronics-Semiconductor reporting unit |  |  |  |  |  |
| Goodwill | $ | 301,185 |  |  | $ | 238,057 |  |  | $ | 238,486 |  |

[0001628280-26-009585:notes:272]
During the fourth quarter of 2024 the Company recorded non-cash charges of $36.1 million and $8.6 million, respectively, to reflect the impairment of goodwill for the Industrial Controls and Sensors reporting unit within the Industrial segment and the Automotive Sensors reporting unit within the Transportation segment. Additionally, during the fourth quarter of 2024, the

[0001628280-26-009585:notes:273]
Company recorded non-cash impairment charges of $47.8 million for the impairment of intangible assets primarily related to the impairment of certain acquired customer relationships, developed technology, and tradename intangible assets in the Industrial Controls and Sensors reporting unit within the Industrial segment. See Note 5, Goodwill and Other Intangible Assets, for further discussion. In addition, during the first quarter of 2024, the Company recognized a $0.9 million impairment related to certain machinery and equipment in the commercial vehicle business within the Transportation segment.

[0001628280-26-009585:notes:274]
2024 goodwill and intangible assets impairment charges were the result of measuring a reporting unit at fair value on a nonrecurring basis as shown below:

[0001628280-26-009585:notes:275]
| (in thousands) | For Fiscal Year Ended December 28, 2024 |  | December 28, 2024 |
|  | Impairment Charge |  | Estimated Fair Value Measurement (Level 3) |  | Net Carrying Value |
| Industrial Controls and Sensors reporting unit |  |  |  |  |  |
| Customer relationships, trademarks, and tradenames | $ | 40,641 |  |  | $ | 6,620 |  |  | $ | 7,142 |  |
| Patents, licenses and software | 6,938 |  |  | 950 |  |  | 1,065 |  |
| Intangible assets, net of amortization | $ | 47,579 |  |  | $ | 7,570 |  |  | $ | 8,207 |  |
| Goodwill | $ | 36,147 |  |  | $ | 119,361 |  |  | $ | 115,159 |  |
| Automotive Sensors reporting unit |  |  |  |  |  |
| Goodwill | $ | 8,616 |  |  | $ | — |  |  | $ | — |  |

[0001628280-26-009585:notes:276]
During the fiscal year 2023, the Company recognized a $3.9 million impairment charge related to the land and building of a property in the commercial vehicle business within the Transportation segment that the Company made the decision to donate, a $0.9 million impairment charge substantially related to certain patents in a business within the Industrial segment, and a $0.1 million impairment related to certain machinery and equipment in the semiconductor business within the Electronics segment. See Note 8, Restructuring, Impairment, and Other Charges, for further discussion.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001628280-26-009585:notes:277]
Benefit Plans

[0001628280-26-009585:notes:278]
The Company has Company-sponsored and mandatory defined benefit pension plans covering employees in the United Kingdom ("U.K."), Germany, the Philippines, China, Japan, Mexico, Italy, and France. The amount of the retirement benefits provided under the plans is generally based on years of service and final average pay.

[0001628280-26-009585:notes:279]
On October 4, 2024, the Company entered into a definitive agreement to purchase a group annuity contract, under which an insurance company will be required to pay pension payments to the Company’s United Kingdom pension plan to match required pension payments until a later buyout, at which point the insurance company will directly pay and administer the benefits to the plan's participants, or to their designated beneficiaries. The purchase of this group annuity contract will reduce the Company’s outstanding pension benefit obligation by approximately $25 million, representing approximately 31% of the total obligations of the Company’s qualified pension plans, and will be funded with pension plan assets and additional cash on hand. In connection with this transaction, the Company currently expects to record a one-time non-cash settlement charge in the second half of 2026 estimated between $6 million and $8 million, reflecting the accelerated recognition of a portion of unamortized actuarial losses in the plan. The actual settlement charge could differ from this estimate due to final data and plan wind-up expenses.

[0001628280-26-009585:notes:280]
Benefit plan related information is as follows for the years 2025 and 2024:

[0001628280-26-009585:notes:281]
| (in thousands) | 2025 |  | 2024 |
| Change in benefit obligation: |  |  |  |
| Benefit obligation at beginning of year | $ | 70,682 |  |  | $ | 73,521 |  |
| Service cost | 3,020 |  |  | 3,060 |  |
| Interest cost | 4,013 |  |  | 3,873 |  |
| Net actuarial loss | 1,471 |  |  | 501 |  |
| Benefits paid from the plan assets | (1,984) |  |  | (2,037) |  |
| Benefits paid directly by the Company | (2,349) |  |  | (2,042) |  |
| Settlements | (868) |  |  | (1,248) |  |
| Acquisitions | 1,725 |  |  | — |  |
| Effect of exchange rate movements | 6,075 |  |  | (4,946) |  |
| Benefit obligation at end of year | $ | 81,785 |  |  | $ | 70,682 |  |
| Change in plan assets at fair value: |  |  |  |
| Fair value of plan assets at beginning of year | $ | 39,338 |  |  | $ | 37,696 |  |
| Actual gain (loss) on plan assets | 983 |  |  | (529) |  |
| Employer contributions | 1,415 |  |  | 5,376 |  |
| Benefits paid from the plan assets | (1,984) |  |  | (2,037) |  |
| Settlements | (509) |  |  | — |  |
| Effect of exchange rate movements | 2,370 |  |  | (1,168) |  |
| Fair value of plan assets at end of year | 41,613 |  |  | 39,338 |  |
| Net amount unfunded status | $ | (40,172) |  |  | $ | (31,344) |  |

[0001628280-26-009585:notes:282]
Amounts recognized in the Consolidated Balance Sheets as of December 27, 2025 and December 28, 2024 consisted of the following:

[0001628280-26-009585:notes:283]
| (in thousands) | 2025 |  | 2024 |
| Amounts recognized in the Consolidated Balance Sheets consist of: |  |  |  |
| Non-current assets | $ | 241 |  |  | $ | 6 |  |
| Current benefit liability | (1,680) |  |  | (1,514) |  |
| Non-current benefit liability | (38,733) |  |  | (29,836) |  |
| Net liability recognized | $ | (40,172) |  |  | $ | (31,344) |  |

[0001628280-26-009585:notes:284]
The amounts included in accumulated other comprehensive loss in the Consolidated Balance Sheets, excluding tax effects that have not yet been recognized as components of net periodic benefit costs as of December 27, 2025 and December 28, 2024 were as follows:

[0001628280-26-009585:notes:285]
| (in thousands) | 2025 |  | 2024 |
| Net actuarial loss | $ | 9,328 |  |  | $ | 6,679 |  |
| Prior service cost | 1,249 |  |  | 1,304 |  |
| Total | $ | 10,577 |  |  | $ | 7,983 |  |

[0001628280-26-009585:notes:286]
The pre-tax amounts recognized in other comprehensive (loss) income in 2025 and 2024 were as follows:

[0001628280-26-009585:notes:287]
|  | 2025 |  | 2024 |
| (in thousands) |  |  |  |
| Amortization of: |  |  |  |
| Prior service cost | $ | 93 |  |  | $ | 93 |  |
| Net actuarial loss | 309 |  |  | 81 |  |
| Amount arising during the period: |  |  |  |
| Net actuarial loss | (2,028) |  |  | (3,099) |  |
| Net curtailment and settlement loss | 12 |  |  | 299 |  |
| Foreign currency adjustments | (980) |  |  | 265 |  |
| Total | $ | (2,594) |  |  | $ | (2,361) |  |

[0001628280-26-009585:notes:288]
Due to the signing of the group annuity contract for the U.K. pension plan, the liabilities of the plan were remeasured as of October 4, 2024 resulting in an increase of $3.8 million to unamortized actuarial loss within other comprehensive (loss) income. In addition, the net actuarial loss during 2025 as compared to 2024 were impacted by higher discount rates in 2025 as compared to 2024.

[0001628280-26-009585:notes:289]
The components of net periodic benefit costs for the fiscal years 2025, 2024, and 2023 were as follows:

[0001628280-26-009585:notes:290]
| (in thousands) | 2025 |  | 2024 |  | 2023 |
| Components of net periodic benefit cost: |  |  |  |  |  |
| Service cost | $ | 3,020 |  |  | $ | 3,060 |  |  | $ | 2,774 |  |
| Interest cost | 4,013 |  |  | 3,873 |  |  | 3,795 |  |
| Expected return on plan assets | (1,899) |  |  | (2,069) |  |  | (1,879) |  |
| Amortization of prior service and net actuarial loss | 402 |  |  | 174 |  |  | 45 |  |
| Net periodic benefit cost | 5,536 |  |  | 5,038 |  |  | 4,735 |  |
| Net settlement loss (gain) | 12 |  |  | 299 |  |  | (266) |  |
| Total expense for the year | $ | 5,548 |  |  | $ | 5,337 |  |  | $ | 4,469 |  |

[0001628280-26-009585:notes:291]
Weighted average assumptions used to determine net periodic benefit cost for the fiscal years 2025, 2024, and 2023 were as follows:

[0001628280-26-009585:notes:292]
|  | 2025 |  | 2024 |  | 2023 |
| Discount rate | 5.6 | % |  | 5.6 | % |  | 5.8 | % |
| Expected return on plan assets | 4.7 | % |  | 5.5 | % |  | 5.2 | % |
| Compensation increase rate | 4.8 | % |  | 4.8 | % |  | 4.7 | % |

[0001628280-26-009585:notes:293]
The accumulated benefit obligation for the plans was $65.2 million and $58.7 million as of December 27, 2025 and December 28, 2024, respectively.

[0001628280-26-009585:notes:294]
The following table provides a summary of under-funded or unfunded pension benefit plans with projected benefit obligations in excess of plan assets as of December 27, 2025 and December 28, 2024:

[0001628280-26-009585:notes:295]
| (in thousands) | 2025 |  | 2024 |
| Projected benefit obligation | $ | 52,927 |  |  | $ | 47,016 |  |
| Fair value of plan assets | 12,491 |  |  | 15,666 |  |

[0001628280-26-009585:notes:296]
The following table provides a summary of under-funded or unfunded pension benefit plans with accumulated benefit obligations in excess of plan assets as of December 27, 2025 and December 28, 2024:

[0001628280-26-009585:notes:297]
| (in thousands) | 2025 |  | 2024 |
| Accumulated benefit obligation | $ | 29,239 |  |  | $ | 28,028 |  |
| Fair value of plan assets | 2,440 |  |  | 5,419 |  |

[0001628280-26-009585:notes:298]
Weighted average assumptions used to determine benefit obligations as of December 27, 2025, December 28, 2024 and December 30, 2023 were as follows:

[0001628280-26-009585:notes:299]
|  | 2025 |  | 2024 |  | 2023 |
| Discount rate | 6.1 | % |  | 5.6 | % |  | 5.6 | % |
| Compensation increase rate | 4.6 | % |  | 4.8 | % |  | 4.8 | % |

[0001628280-26-009585:notes:300]
Expected benefit payments to be paid to participants for the fiscal year ending are as follows:

[0001628280-26-009585:notes:301]
| (in thousands) | Expected Benefit Payments |
| 2026 | $ | 4,626 |  |
| 2027 | 4,283 |  |
| 2028 | 5,035 |  |
| 2029 | 5,562 |  |
| 2030 | 6,729 |  |
| 2031-2035 and thereafter | 43,340 |  |

[0001628280-26-009585:notes:302]
The Company expects to make approximately $1.5 million of contributions to the plans and pay $2.3 million of benefits directly in 2026.

[0001628280-26-009585:notes:303]
The Company also sponsors certain post-employment plans in foreign countries and other statutory benefit plans. For the fiscal years ended December 27, 2025, December 28, 2024, and December 30, 2023, the Company recorded $3.5 million, $5.0 million and $1.5 million expense, respectively, in Cost of sales, Restructuring, impairment, and other charges, and Other income, net within the Consolidated Statements of Net (Loss) Income. As of December 27, 2025 and December 28, 2024, the Company reported benefit liabilities of $5.9 million and $4.4 million for these plans, of which $1.9 million and $1.5 million was recorded in Accrued liabilities and $4.0 million and $2.9 million was recorded in Other long-term liabilities on the Consolidated Balance Sheets, respectively. For the fiscal years ended December 27, 2025 and December 28, 2024, the pre-tax amounts recognized in other comprehensive (loss) income for these plans were $0.1 million and $(0.2) million, respectively. For the fiscal year ended December 27, 2025, the expense reclassified from accumulated other comprehensive loss to earnings as components of net periodic benefit costs was $1.9 million. For the fiscal year ended December 28, 2024, the expense reclassified from accumulated other comprehensive loss to earnings as components of net periodic benefit costs was $3.3 million.

[0001628280-26-009585:notes:304]
Defined Benefit Plan Assets

[0001628280-26-009585:notes:305]
Based upon analysis of the target asset allocation and historical returns by type of investment, the Company has assumed that the expected long-term rate of return will be 4.7% on plan assets. Assets are invested to maximize long-term return taking into consideration timing of settlement of the retirement liabilities and liquidity needs for benefits payments. Pension plan assets were invested as follows, and were not materially different from the target asset allocation:

[0001628280-26-009585:notes:306]
|  | Asset Allocation |
|  | 2025 |  | 2024 |
| Cash and cash equivalents, and other | 2 | % |  | 1 | % |
| Equity securities | 6 | % |  | 7 | % |
| Fixed income securities | 32 | % |  | 32 | % |
| Bulk annuity contract | 60 | % |  | 60 | % |
|  | 100 | % |  | 100 | % |

[0001628280-26-009585:notes:307]
The Company segregated its plan assets by the following major categories and level for determining their fair value as of December 27, 2025 and December 28, 2024. All plan assets that are valued using the net asset value per share (“NAV”) practical expedient have not been included within the fair value hierarchy, but are separately disclosed.

[0001628280-26-009585:notes:308]
Cash and cash equivalents – Carrying value approximates fair value. As such, these assets were classified as Level 1. The Company also invests in certain short-term investments which are valued using the amortized cost method. Lastly, the Company has certain pooled pension funds that have short-term investments with third party mutual funds that are valued at unit value per share at measurement date. As such, these assets were classified as Level 2.

[0001628280-26-009585:notes:309]
Equity – The values of individual equity securities were based on quoted prices in active markets. As such, these assets are classified as Level 1. The Company has certain pooled pension funds which have mutual funds with underlying investments in certain equity securities that are not quoted on active markets; therefore, they were classified as Level 2.

[0001628280-26-009585:notes:310]
Fixed income – Fixed income securities are typically priced based on a last trade basis and are exchange-traded. Accordingly, the Company classified fixed income securities as Level 1. The Company has certain pooled pension funds which have mutual funds with underlying investments in fixed income securities and funds priced based on a valuation model rather than a last trade basis and are not exchange-traded. As such, they were classified as Level 2. The Company also invests in certain fixed income funds which are valued at the NAV.

[0001628280-26-009585:notes:311]
Insurance contracts and other – This category includes pooled pension funds which have mutual funds with underlying investments in other assets and liabilities including alternatives priced based on a valuation model and are not exchange-traded. These were classified as Level 2. This category also includes insurance contracts that are valued by the re-insurer with the valuation inputs being not highly observable or traded on an open market. Accordingly, insurance contracts were categorized as Level 3. Lastly, this category includes other assets and liabilities including futures or swaps.

[0001628280-26-009585:notes:312]
Bulk Annuity Contract – Bulk annuity contract includes a U.K insurance policy issued by an authorized U.K. life insurer. This bulk annuity contract is valued by the re-insurer with the valuation inputs being not highly observable or traded on an open market. Accordingly, this contract was categorized as Level 3.

[0001628280-26-009585:notes:313]
For any Level 2 and Level 3 plan assets, management reviews significant investments on a periodic basis including investigation of unusual fluctuations in price or returns and obtaining an understanding of the pricing methodology to assess the reliability of third-party pricing estimates.

[0001628280-26-009585:notes:314]
The valuation methodologies described above may generate a fair value calculation that may not be indicative of net realizable value or future fair values. While the Company believes the valuation methodologies used are appropriate, the use of different methodologies or assumptions in calculating fair value could result in different amounts. The Company invests in assets in which valuation is determined by the NAV. The Company believes that the NAV is representative of fair value at the reporting date, as there are no significant restrictions on redemption of these investments or other reasons to indicate that the investment would be redeemed at an amount different than the NAV.

[0001628280-26-009585:notes:315]
The following table presents the Company’s pension plan assets measured at fair value by classification within the fair value hierarchy as of December 27, 2025:

[0001628280-26-009585:notes:316]
|  | Fair Value Measurements Using |
| (in thousands) | Level 1 |  | Level 2 |  | Level 3 |  | NAV |  | Total |
| Insurance contracts and other | $ | — |  |  | $ | — |  |  | $ | 154 |  |  | $ | — |  |  | $ | 154 |  |
| Cash and cash equivalents | 808 |  |  | — |  |  | — |  |  | — |  |  | 808 |  |
| Equities | 2,635 |  |  | — |  |  | — |  |  | — |  |  | 2,635 |  |
| Fixed income | 7,242 |  |  | — |  |  | — |  |  | 5,787 |  |  | 13,029 |  |
| Bulk annuity contract | — |  |  | — |  |  | 24,987 |  |  | — |  |  | 24,987 |  |
| Total pension plan assets | $ | 10,685 |  |  | $ | — |  |  | $ | 25,141 |  |  | $ | 5,787 |  |  | $ | 41,613 |  |

[0001628280-26-009585:notes:317]
The following table presents the Company’s pension plan assets measured at fair value by classification within the fair value hierarchy as of December 28, 2024:

[0001628280-26-009585:notes:318]
|  | Fair Value Measurements Using |
| (in thousands) | Level 1 |  | Level 2 |  | Level 3 |  | NAV |  | Total |
| Insurance contracts and other | $ | — |  |  | $ | — |  |  | $ | 131 |  |  | $ | — |  |  | $ | 131 |  |
| Cash and cash equivalents | 422 |  |  | — |  |  | — |  |  | — |  |  | 422 |  |
| Equities | 2,921 |  |  | — |  |  | — |  |  | — |  |  | 2,921 |  |
| Fixed income | 7,224 |  |  | — |  |  | — |  |  | 5,198 |  |  | 12,422 |  |
| Bulk annuity contract | — |  |  | — |  |  | 23,442 |  |  | — |  |  | 23,442 |  |
| Total pension plan assets | $ | 10,567 |  |  | $ | — |  |  | $ | 23,573 |  |  | $ | 5,198 |  |  | $ | 39,338 |  |

[0001628280-26-009585:notes:319]
The fair value measurement of plan assets using significant unobservable inputs (Level 3) changed during 2025 and 2024 due to the following:

[0001628280-26-009585:notes:320]
| (in thousands) | Level 3 |
| Balance at December 30, 2023 | $ | 133 |  |
| Level 3 assets transferred in from Level 1 and 2 assets valued at NAV: |  |
| Bulk annuity contract added during the year | 23,442 |  |
| Employer contribution | 2 |  |
| Actual return on assets | 4 |  |
| Foreign currency adjustments | (8) |  |
| Balance at December 28, 2024 | $ | 23,573 |  |
| Level 3 assets transferred in from Level 1 and 2 assets valued at NAV: |  |
| Employer contribution | 125 |  |
| Actual return on assets | 1,059 |  |
| Benefits paid from the plan assets | (1,392) |  |
| Foreign currency adjustments | 1,776 |  |
| Balance at December 27, 2025 | $ | 25,141 |  |

[0001628280-26-009585:notes:321]
Defined Contribution Plan

[0001628280-26-009585:notes:322]
The Company also maintains a 401(k) savings plan covering substantially all U.S. employees. The Company matches 100% of the employee’s annual contributions for the first 4% of the employee’s eligible compensation. The Company may provide an additional discretionary match to participants and made discretionary matches of 2% of the employee’s eligible compensation for each of the fiscal years ended December 27, 2025, December 28, 2024 and December 30, 2023. Employees are immediately vested in their contributions plus actual earnings thereon, as well as the Company contributions. Company matching contributions amounted to $6.6 million, $6.5 million, and $7.7 million in 2025, 2024, and 2023, respectively.

[0001628280-26-009585:notes:323]
Non-qualified Supplemental Retirement and Savings Plan

[0001628280-26-009585:notes:324]
The Company has a non-qualified Supplemental Retirement and Savings Plan which provides additional retirement benefits for certain management employees and named executive officers by allowing participants to defer a portion of their annual compensation. The Company maintains accounts for participants through which participants make investment elections. The investments are subject to the claims of the Company’s creditors and the Company is responsible for the payment of all benefits under the plan from its general assets. As of December 27, 2025, there was $25.7 million of marketable securities related to the plan included in Other long-term assets and $25.7 million of accrued compensation benefits included in Other long-term liabilities. The marketable securities are classified as Level 1 under the fair value hierarchy as they are maintained in mutual funds with readily determinable fair value. The Company made matching contributions to the plan of $0.3 million, $0.5 million, and $0.6 million in 2025, 2024, and 2023, respectively.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-26-009585:notes:325]
Equity Plans: The Company has equity-based compensation plans authorizing the granting of stock options, restricted shares, restricted share units, performance shares units, and other stock rights to employees and directors. As of December 27, 2025, there were 0.8 million shares available for issuance of future awards under the Company’s equity-based compensation plans.

[0001628280-26-009585:notes:326]
Stock options generally vest over a three-year period and are exercisable over either a seven or ten-year period commencing from the date of the grant. Restricted shares and share units granted by the Company generally vest over three years. Performance share units have three-year performance periods with vesting at the end of the performance period and earned based on the Company’s relative Total Shareholder Return ("TSR") relative to a group of peer companies. Stock options, restricted share and performance share units may have accelerated vesting upon meeting certain qualified conditions.

[0001628280-26-009585:notes:327]
The following table provides a reconciliation of outstanding stock options for the fiscal year ended December 27, 2025.

[0001628280-26-009585:notes:328]
|  | Shares UnderOption |  | WeightedAveragePrice |  | WeightedAverageRemainingContract Life(Years) |  | AggregateIntrinsicValue(000’s) |
| Outstanding December 28, 2024 | 629,812 |  |  | $ | 200.07 |  |  |  |  |  |
| Granted | — |  |  | N/A |  |  |  |  |
| Exercised | (164,064) |  |  | 173.67 |  |  |  |  |  |
| Forfeited | (7,712) |  |  | 236.20 |  |  |  |  |  |
| Outstanding December 27, 2025 | 458,036 |  |  | 208.92 |  |  | 3.1 |  | $ | 24,677 |  |
| Exercisable December 27, 2025 | 416,903 |  |  | 206.38 |  |  | 2.9 |  | 23,550 |  |

[0001628280-26-009585:notes:329]
The following table provides a reconciliation of non-vested restricted share and share unit awards ("RSU") for the fiscal year ended December 27, 2025.

[0001628280-26-009585:notes:330]
|  | Shares |  | Weighted Average Grant-Date Fair Value |
| Nonvested December 28, 2024 | 186,013 |  |  | $ | 229.56 |  |
| Granted | 175,235 |  |  | 186.04 |  |
| Vested | (98,705) |  |  | 229.94 |  |
| Forfeited | (35,652) |  |  | 212.78 |  |
| Nonvested December 27, 2025 | 226,891 |  |  | 198.43 |  |

[0001628280-26-009585:notes:331]
The following table provides a reconciliation of non-vested performance share unit awards ("PSU") for the fiscal year ended December 27, 2025.

[0001628280-26-009585:notes:332]
|  | Shares |  | Weighted Average Grant-Date Fair Value |
| Nonvested December 28, 2024 | — |  |  | N/A |
| Granted | 75,067 |  |  | 319.63 |  |
| Vested | — |  |  | N/A |
| Forfeited | (2,400) |  |  | 252.93 |  |
| Nonvested December 27, 2025 | 72,667 |  |  | 321.83 |  |

[0001628280-26-009585:notes:333]
The total intrinsic value of options exercised during 2025, 2024, and 2023 was $13.0 million, $6.3 million, and $12.2 million, respectively. The total fair value of the vested RSU shares was $17.7 million, $16.2 million, and $19.8 million for 2025, 2024, and 2023, respectively. No PSU shares vested in 2025. The total amount of share-based liabilities paid was $1.2 million, $1.3 million, and $2.2 million for 2025, 2024, and 2023, respectively.

[0001628280-26-009585:notes:334]
The Company recognizes compensation cost of all share-based awards as an expense on a straight-line basis over the vesting period of the awards. At December 27, 2025, the unrecognized compensation cost for options, restricted shares and performance shares was $43.6 million before tax, and will be recognized over a weighted average period of 2.0 years. Compensation cost included as a component of cost of sales, research and development and selling, general, and administrative expenses for all equity compensation plans discussed above was $28.6 million, $27.4 million, and $25.7 million for 2025, 2024,

[0001628280-26-009585:notes:335]
and 2023, respectively. The total related income tax benefit recognized in the Consolidated Statements of Net (Loss) Income was $4.0 million, $4.0 million, and $3.8 million for 2025, 2024, and 2023, respectively.

[0001628280-26-009585:notes:336]
The Company uses the Monte Carlo valuation model to determine the fair value of PSU shares granted. The weighted average fair value of and related assumptions for PSU shares granted are as follows:

[0001628280-26-009585:notes:337]
|  | 2025 |  | 2024 |  | 2023 |
| Weighted average fair value of options granted | $319.63 |  | N/A |  | N/A |
| Assumptions: |  |  |  |  |  |
| Risk-free interest rate | 4.01% |  | N/A |  | N/A |
| Expected dividend yield | —% |  | N/A |  | N/A |
| Expected stock price volatility | 33.16% |  | N/A |  | N/A |
| Expected correlation | 24.29% |  | N/A |  | N/A |

[0001628280-26-009585:notes:338]
Expected volatilities and correlation factors are based on the historical volatility of the Company’s and each peer company’s stock price. The risk-free rates are based on yields available at the time of grant on U.S. Treasury bonds with maturities consistent with the remaining performance period.

[0001628280-26-009585:notes:339]
The fair value of RSU shares without rights to dividend equivalents is determined based on the Company's stock price on the grant date reduced by the present value of expected dividends through the vesting period.  The fair value of RSU with rights to dividend equivalents is based on the Company’s stock price on the grant date.

[0001628280-26-009585:notes:340]
The Company uses the Black-Scholes option valuation model to determine the fair value of stock option awards granted. The weighted average fair value of and related assumptions for options granted are as follows:

[0001628280-26-009585:notes:341]
|  | 2025 |  | 2024 |  | 2023 |
| Weighted average fair value of options granted | N/A |  | $75.25 |  | $77.40 |
| Assumptions: |  |  |  |  |  |
| Risk-free interest rate | N/A |  | 4.71% |  | 3.67% |
| Expected dividend yield | N/A |  | 1.13% |  | 1.00% |
| Expected stock price volatility | N/A |  | 34.9% |  | 36.0% |
| Expected life of options (years) | N/A |  | 4.4 |  | 4.4 |

[0001628280-26-009585:notes:342]
Preferred Stock: The Board of Directors may authorize the issuance of preferred stock from time to time in one or more series with such designations, preferences, qualifications, limitations, restrictions, and optional or other special rights as the Board may fix by resolution.

[0001628280-26-009585:notes:343]
Share Repurchase Program

[0001628280-26-009585:notes:344]
The Company's Board of Directors authorized the repurchase of up to $300 million in the aggregate of shares of the Company’s common stock for the period May 1, 2021 to April 30, 2024 ("2021 program"). On April 25, 2024, the Company's Board of Directors authorized a new three-year program to repurchase up to $300.0 million in the aggregate of shares of the Company's stock for the period May 1, 2024 to April 30, 2027 ("2024 program") to replace the expired 2021 program. 
During the fiscal year of 2025, the Company repurchased 120,689 shares of its common stock totaling $27.4 million pursuant to the 2024 program. There are $270.6 million of an authorized amount not yet purchased under the 2024 program as of December 27, 2025. During the fiscal year of 2024, the Company repurchased 179,311 shares of its common stock totaling $40.9 million, of which, $38.9 million was pursuant to the 2021 program and $2.0 million was pursuant to the 2024 program. During the fiscal year of 2023, the Company did not repurchase any shares of its common stock.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-26-009585:notes:345]
Other Comprehensive (Loss) Income
Changes in other comprehensive (loss) income by component for fiscal years 2025, 2024, and 2023 were as follows:

[0001628280-26-009585:notes:346]
|  | Fiscal Year Ended |
|  | December 27, 2025 |  | December 28, 2024 |  | December 30, 2023 |
| (in thousands) | Pre-tax |  | Tax |  | Net of tax |  | Pre-tax |  | Tax |  | Net of tax |  | Pre-tax |  | Tax |  | Net of tax |
| Defined benefit pension plan and other adjustments | $ | (2,154) |  |  | $ | (24) |  |  | $ | (2,178) |  |  | $ | (2,947) |  |  | $ | 51 |  |  | $ | (2,896) |  |  | $ | (5,911) |  |  | $ | 491 |  |  | $ | (5,420) |  |
| Cash flow hedges | 6,134 |  |  | 697 |  |  | 6,831 |  |  | (3,188) |  |  | 41 |  |  | (3,147) |  |  | (2,827) |  |  | 679 |  |  | (2,148) |  |
| Foreign currency translation adjustments (1) | 139,430 |  |  | (3,105) |  |  | 136,325 |  |  | (86,273) |  |  | 1,772 |  |  | (84,501) |  |  | 48,227 |  |  | (712) |  |  | 47,515 |  |
| Total change in other comprehensive income (loss) | $ | 143,410 |  |  | $ | (2,432) |  |  | $ | 140,978 |  |  | $ | (92,408) |  |  | $ | 1,864 |  |  | $ | (90,544) |  |  | $ | 39,489 |  |  | $ | 458 |  |  | $ | 39,947 |  |

[0001628280-26-009585:notes:347]
(1) The tax shown above within the foreign currency translation adjustments is the U.S. tax associated with the foreign currency translation adjustments of earnings of non-U.S. subsidiaries which have been previously taxed in the U.S. and are not permanently reinvested.

[0001628280-26-009585:notes:348]
Accumulated Other Comprehensive Loss (“AOCI”): The following table sets forth the changes in the components of AOCI by component for fiscal years 2025, 2024, and 2023:

[0001628280-26-009585:notes:349]
| (in thousands) | Pension and postretirement liability and reclassification adjustments |  | Cash flow hedges |  | Foreign currency translation adjustments |  | Accumulated other comprehensive (loss) income |
| Balance at December 31, 2022 | $ | (2,193) |  |  | $ | 6,596 |  |  | $ | (100,167) |  |  | $ | (95,764) |  |
| 2023 activity | (5,420) |  |  | (2,148) |  |  | 47,515 |  |  | 39,947 |  |
| Balance at December 30, 2023 | $ | (7,613) |  |  | $ | 4,448 |  |  | $ | (52,652) |  |  | $ | (55,817) |  |
| 2024 activity | (2,896) |  |  | (3,147) |  |  | (84,501) |  |  | (90,544) |  |
| Balance at December 28, 2024 | $ | (10,509) |  |  | $ | 1,301 |  |  | $ | (137,153) |  |  | $ | (146,361) |  |
| 2025 activity | (2,178) |  |  | 6,831 |  |  | 136,325 |  |  | 140,978 |  |
| Balance at December 27, 2025 | $ | (12,687) |  |  | $ | 8,132 |  |  | $ | (828) |  |  | $ | (5,383) |  |

[0001628280-26-009585:notes:350]
On October 4, 2024, the Company entered into a definitive agreement to purchase a group annuity contract, under which an insurance company will be required to pay pension payments to the Company’s United Kingdom pension plan to match required pension payments until a later buyout, at which point the insurance company will directly pay and administer the benefits to the plan's participants, or to their designated beneficiaries. The purchase of this group annuity contract will reduce the Company’s outstanding pension benefit obligation by approximately $25 million, representing approximately 31% of the total obligations of the Company’s qualified pension plans, and will be funded with pension plan assets and additional cash on hand. In connection with this transaction, the Company currently expects to record a one-time non-cash settlement charge in 2026 estimated between $6 million and $8 million, reflecting the accelerated recognition of a portion of unamortized actuarial losses in the plan. The actual settlement charge could differ from this estimate due to final data and plan wind-up expenses.

[0001628280-26-009585:notes:351]
Due to the signing of the group annuity contract for the U.K. pension plan, the liabilities of the plan were remeasured as of October 4, 2024 resulting in an increase of $3.8 million to unamortized actuarial loss within other comprehensive (loss) income. See Note 11, Benefits Plans for further discussion.

[0001628280-26-009585:notes:352]
Amounts reclassified from accumulated other comprehensive loss to earnings for fiscal years 2025, 2024, and 2023 were as follows:

[0001628280-26-009585:notes:353]
|  |  | Fiscal Year Ended |
| (in thousands) |  | December 27, 2025 |  | December 28, 2024 |  | December 30, 2023 |
| Pension and postemployment and other plans: |  |  |  |  |  |  |
| Amortization of prior service, net actuarial loss (gain), and other |  | $ | 1,941 |  |  | $ | 3,441 |  |  | $ | (43) |  |
| Net settlement loss and accelerated prior service costs |  | 365 |  |  | 299 |  |  | 247 |  |
| Total |  | $ | 2,306 |  |  | $ | 3,740 |  |  | $ | 204 |  |

[0001628280-26-009585:notes:354]
The Company recognizes the amortization of prior service costs and net settlement loss in Other income, net, and Restructuring, impairment, and other charges  within the Consolidated Statements of Net (Loss) Income.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-26-009585:notes:355]
During the fiscal year ended December 27, 2025, the Company elected to prospectively adopt the guidance in ASU 2023-09. The footnote below reflects this adopted guidance for the fiscal year ended December 27, 2025. For the fiscal years ended December 28, 2024, and December 30, 2023, the footnote reflects the guidance in effect prior to the adoption of ASU 2023-09.

[0001628280-26-009585:notes:356]
The Company elected to pay its 2017 Toll Charge over the eight-year period prescribed by the Tax Act. The eighth and final installment of the Toll Charge of $8.2 million was paid in 2025, and accordingly, there was no remaining liability on the Consolidated Balance Sheet as of December 27, 2025.

[0001628280-26-009585:notes:357]
On July 4, 2025, the United States enacted into law the legislation formally titled “An Act to provide for reconciliation pursuant to title II of H. Con. Res. 14,” and commonly referred to as the One Big Beautiful Bill Act (“OBBB”). The OBBB contains multiple business tax provisions, including the permanent extension of several expiring provisions of the Tax Act and multiple modifications to the international tax framework. The legislation has multiple effective dates with certain provisions effective in 2025 and others to be implemented in future years, and the Company determined the impact for the year ended December 27, 2025 is not significant. The Company will continue to monitor future administrative guidance and regulations that clarify the legislative text of the OBBB and the bill’s potential effect on the Company’s income taxes.

[0001628280-26-009585:notes:358]
Domestic and foreign income (loss) before income taxes is as follows:

[0001628280-26-009585:notes:359]
| (in thousands) | 2025 |  | 2024 |  | 2023 |
| Domestic | $ | (94,209) |  |  | $ | 3,151 |  |  | $ | 40,571 |  |
| Foreign | 97,816 |  |  | 148,712 |  |  | 288,027 |  |
| Income before income taxes | $ | 3,607 |  |  | $ | 151,863 |  |  | $ | 328,598 |  |

[0001628280-26-009585:notes:360]
Federal, state, and foreign income tax expense (benefit) consists of the following:

[0001628280-26-009585:notes:361]
| (in thousands) | 2025 |  | 2024 |  | 2023 |
| Current: |  |  |  |  |  |
| Federal | $ | 3,875 |  |  | $ | (5,881) |  |  | $ | 8,188 |  |
| State | 3,449 |  |  | 1,826 |  |  | 2,880 |  |
| Foreign | 64,644 |  |  | 58,551 |  |  | 57,999 |  |
| Subtotal | $ | 71,968 |  |  | $ | 54,496 |  |  | $ | 69,067 |  |
| Deferred: |  |  |  |  |  |
| Federal (including State for 2024 and 2023) | $ | 1,304 |  |  | $ | 4,091 |  |  | $ | 1,751 |  |
| State | $ | (2,070) |  |  | $ | — |  |  | $ | — |  |
| Foreign | 4,105 |  |  | (6,914) |  |  | (1,705) |  |
| Subtotal | $ | 3,339 |  |  | $ | (2,823) |  |  | $ | 46 |  |
| Provision for income taxes | $ | 75,307 |  |  | $ | 51,673 |  |  | $ | 69,113 |  |

[0001628280-26-009585:notes:362]
As described above, the Company elected to prospectively adopt the guidance in ASU 2023-09. In accordance with the guidance in ASU 2023-09, for the ear ended December 27, 2025, a reconciliation between income taxes computed on income before income taxes at the federal statutory rate and the provision for income taxes is provided below:

[0001628280-26-009585:notes:363]
| (in thousands) |  | 2025 |  | ETR% |
| Tax expense at statutory rate of 21% |  | $ | 757 |  |  | 21.0 | % |
| Effect of Cross-Border Tax Laws: | US Tax on Non-US income (GILTI) | 4,738 |  |  | 131.4 | % |
|  | US Tax on Non-US income (Subpart F) | 6,760 |  |  | 187.4 | % |
|  | Other | (2,503) |  |  | (69.4) | % |
| Tax Credits: | Foreign Tax Credits | (4,301) |  |  | (119.2) | % |
|  | Other | (1,106) |  |  | (30.7) | % |
| Nontaxable or Non-deductible items: | Non-deductible goodwill impairment | 23,028 |  |  | 638.4 | % |
|  | Non-deductible expenses | 3,378 |  |  | 93.7 | % |
|  | Other | 397 |  |  | 11.0 | % |
| Valuation Allowance |  | 409 |  |  | 11.3 | % |
| Other |  | 138 |  |  | 3.8 | % |
| State Taxes, Net of Federal Tax Effect (a) |  | 1,089 |  |  | 30.2 | % |
| Foreign Tax Effects: |  |  |  |  |
| China | Withholding Taxes | 6,129 |  |  | 169.9 | % |
|  | Other | (2,895) |  |  | (80.2) | % |
| Germany | Non-U.S. income tax rate differential | 10,079 |  |  | 279.4 | % |
|  | Non-deductible goodwill impairment | 17,031 |  |  | 472.2 | % |
|  | Valuation allowance | 26,839 |  |  | 744.1 | % |
|  | German Trade Tax | (13,740) |  |  | (380.9) | % |
|  | Other | (674) |  |  | (18.7) | % |
| Korea | Withholding Taxes | 4,752 |  |  | 131.7 | % |
|  | Other | 611 |  |  | 17.0 | % |
| Mexico | Non-U.S. income tax rate differential (b) | (4,604) |  |  | (127.6) | % |
| Netherlands | Valuation allowance | 6,990 |  |  | 193.8 | % |
|  | Other | (462) |  |  | (12.8) | % |
| Philippines | Non-U.S. income tax rate differential (c) | (4,659) |  |  | (129.2) | % |
|  | Withholding Taxes | 4,712 |  |  | 130.6 | % |
|  | Other | 288 |  |  | 8.1 | % |
| Singapore | Non-U.S. income tax rate differential | (3,906) |  |  | (108.3) | % |
|  | Nontaxable Income | (5,100) |  |  | (141.4) | % |
|  | Other | (346) |  |  | (9.6) | % |
| United Kingdom | Non-deductible goodwill impairment | 7,018 |  |  | 194.6 | % |
|  | Other | 57 |  |  | 1.5 | % |
| Other Foreign Jurisdictions |  | 230 |  |  | 6.2 | % |
| Worldwide Changes in Unrecognized Tax Benefits |  | (5,827) |  |  | (161.5) | % |
| Provision for income taxes |  | 75,307 |  |  | 2,087.8 | % |

[0001628280-26-009585:notes:364]
(a) In 2025, state and local income taxes in Illinois and Minnesota comprise the majority of the state and local income taxes, net of federal effect category.

[0001628280-26-009585:notes:365]
(b) The Company operates certain manufacturing activities in Mexico under a Maquiladora structure. The non-U.S. income tax rate differential represents the tax benefits associated with the Maquiladora safe harbor as defined under Mexican tax law.

[0001628280-26-009585:notes:366]
(c) The Company conducts certain operations in the Philippines under the Philippine Economic Zone Authority ("PEZA") regime. The non-U.S. income tax rate differential represents the preferential tax rate benefits associated with the PEZA regime as defined under Philippines tax law.

[0001628280-26-009585:notes:367]
For the years 2024 and 2023, in accordance with the guidance in effect prior to ASU 2023-09, a reconciliation between income taxes computed on income before income taxes at the federal statutory rate and the provision for income taxes is provided below:

[0001628280-26-009585:notes:368]
| (in thousands) | 2024 |  | 2023 |
| Tax expense at statutory rate of 21% | $ | 31,891 |  |  | $ | 69,006 |  |
| Non-U.S. income tax rate differential | (1,130) |  |  | (25,623) |  |
| Non-U.S. losses and expenses with no tax benefit | 9,401 |  |  | 11,261 |  |
| Tax on unremitted earnings | 6,616 |  |  | 6,394 |  |
| Non-deductible goodwill impairment | 5,810 |  |  | — |  |
| Net impact associated with U.S. tax on non-U.S. income, including GILTI | 5,809 |  |  | 4,739 |  |
| State and local taxes, net of federal tax benefit | 2,533 |  |  | 1,503 |  |
| Certain changes in unrecognized tax benefits and related accrued interest | (8,692) |  |  | (172) |  |
| Other, net | (565) |  |  | 2,005 |  |
| Provision for income taxes | $ | 51,673 |  |  | $ | 69,113 |  |

[0001628280-26-009585:notes:369]
Deferred income taxes are provided for the tax effects of temporary differences between the financial reporting bases and the tax bases of the Company’s assets and liabilities. Significant components of the Company’s deferred tax assets and liabilities at December 27, 2025 and December 28, 2024, were as follows:

[0001628280-26-009585:notes:370]
| (in thousands) | 2025 |  | 2024 |
| Deferred tax assets: |  |  |  |
| Net operating loss carryforwards | $ | 66,851 |  |  | $ | 46,263 |  |
| Interest expense carryforwards | 47,581 |  |  | 34,800 |  |
| Accrued expenses and reserves | 42,154 |  |  | 32,336 |  |
| Lease liabilities | 16,559 |  |  | 13,016 |  |
| Excess of tax basis over the book basis for intangible assets and goodwill | 16,016 |  |  | — |  |
| Capitalized expenses | 11,032 |  |  | 18,939 |  |
| U.S. foreign tax credit carryforwards | 3,772 |  |  | 3,490 |  |
| U.S. research and other general business tax credit carryforwards | 1,222 |  |  | 1,252 |  |
| Other | — |  |  | 196 |  |
| Deferred tax assets | 205,187 |  |  | 150,292 |  |
| Less: Valuation allowance | (97,557) |  |  | (55,468) |  |
| Total deferred tax assets | 107,630 |  |  | 94,824 |  |
| Deferred tax liabilities: |  |  |  |
| Excess of book basis over the tax basis for intangible assets and goodwill | 134,666 |  |  | 133,701 |  |
| Excess of book basis over the tax basis for property, plant, and equipment | 34,448 |  |  | 24,238 |  |
| Right of use lease assets | 17,289 |  |  | 12,906 |  |
| Tax on unremitted earnings | 16,311 |  |  | 14,612 |  |
| Other | 1,996 |  |  | — |  |
| Total deferred tax liabilities | 204,710 |  |  | 185,457 |  |
| Net deferred tax liabilities | $ | 97,080 |  |  | $ | 90,633 |  |

[0001628280-26-009585:notes:371]
The deferred tax asset valuation allowance is mainly related to certain U.S. and non-U.S. net operating loss, non-U.S. interest expense carryforwards, and U.S. foreign tax credit carryforwards which are not more likely that not to be realized. The remaining U.S. and non-U.S. net operating loss, interest expense, and foreign tax credit carryforwards either have no expiration date or are expected to be utilized prior to expiration (which begin expiring in 2028). No deferred tax asset nor valuation allowance has been recorded for certain U.S. and non-U.S. net operating loss carryforwards for which the possibility of usage has been determined to be remote.

[0001628280-26-009585:notes:372]
As described above, the Company has elected to prospectively adopt the guidance in ASU No. 2023-09, Income Taxes (Topic 740): Improvements to Income Taxes Disclosures, or ASU 2023-09. In accordance with the guidance in ASU 2023-09, for the year ended December 27, 2025, a summary of income taxes paid net of refunds by jurisdiction is provided below:

[0001628280-26-009585:notes:373]
| Jurisdiction | 2025 |  |
| Federal | $ | 10,154 |  |  |
| State | 1,792 |  |  |
| Foreign |  |  |
| China | 25,016 |  |  |
| Singapore | 12,581 |  |  |
| Philippines | 8,141 |  |  |
| Mexico | 5,961 |  |  |
| Korea | 5,853 |  |  |
| Other | $ | 12,103 |  |  |
| Total income taxes paid net of refunds received | $ | 81,601 |  |  |

[0001628280-26-009585:notes:374]
State income taxes paid in Texas and Minnesota make up the majority (greater than 50%) of the total 2025 state income taxes paid. The Company paid income taxes of $88.1 million, and $81.1 million in 2024, and 2023, respectively, and received income tax refunds of $4.3 million, and $7.2 million in 2024, and 2023, respectively.

[0001628280-26-009585:notes:375]
Deferred income taxes are not provided on the excess of the investment value for financial reporting over the tax basis of investments in those subsidiaries for which such excess is considered to be permanently reinvested in those operations. The Company recognized deferred tax liabilities of $16.3 million as of December 27, 2025 and $14.6 million as of December 28, 2024, related to taxes on certain non-U.S. earnings which are not considered to be permanently reinvested.

[0001628280-26-009585:notes:376]
The Company has two subsidiaries in China which benefit from lower tax rates due to “tax holidays” which apply for three-year periods. The tax holiday for one of the subsidiaries expired at the end of 2023, but was later extended for an additional three years, retroactive to include all of 2024, as well as 2025 and 2026, and for the other subsidiary the tax holiday expired at the end of 2025. The Company intends to seek an extension for the expired tax holiday. Together, the tax holidays contributed $6.6 million in current tax benefits, or $0.27 per diluted share, during 2025. Future year tax benefits will depend upon the Company’s ability to obtain extensions, after the three-year periods expire. There can be no assurance that future extensions will be granted.

[0001628280-26-009585:notes:377]
A reconciliation of the beginning and ending amount of unrecognized tax benefits as of December 27, 2025, December 28, 2024, and December 30, 2023 is as follows:

[0001628280-26-009585:notes:378]
| (in thousands) | Unrecognized Tax Benefits |
| Balance at December 30, 2023 | $ | 31,449 |  |
| Additions for tax positions taken in the current year | 1,251 |  |
| Additions for tax positions taken in the prior year | 375 |  |
| Decreases for lapses in statute of limitations | (7,650) |  |
| Other | 574 |  |
| Balance at December 28, 2024 | $ | 25,999 |  |
| Additions for tax positions taken in the current year | 1,695 |  |
| Additions for tax positions taken in the prior year | 170 |  |
| Decreases for lapses in statute of limitations | (5,850) |  |
| Decreases for settlements | (563) |  |
| Other | 4,356 |  |
| Balance at December 27, 2025 | $ | 25,807 |  |

[0001628280-26-009585:notes:379]
As of December 27, 2025, the net amount of tax benefits that, if recognized, would favorably affect the effective tax rate in future periods is approximately $23.2 million. None of the positions included in unrecognized tax benefits are related to tax positions for which the ultimate deductibility is highly certain, but for which there is uncertainty about the timing of such deductibility.

[0001628280-26-009585:notes:380]
The Company recognizes accrued interest and penalties associated with uncertain tax positions as part of income tax expense. The Company recognized such interest benefit of $2.3 million (including a $3.5 million decrease due to a lapse in the statute of limitations), $2.7 million expense (net of a $4.1 million decrease due to a lapse in the statute of limitations) and $0.5 million expense (net of a $1.7 million decrease due to a lapse in the statute of limitations) in 2025, 2024, and 2023, respectively. Accrued interest for such matters included in Other long-term liabilities within the Consolidated Balance Sheets was $8.7 million and $11.1 million as of December 27, 2025 and December 28, 2024, respectively.

[0001628280-26-009585:notes:381]
The U.S. federal statute of limitations remains open for the Company for the 2022 tax year and later years. Non-U.S. and U.S. state statutes of limitations generally range from three to seven years, although certain jurisdictions do not have a statute expiration. Tax examinations occur from time to time, including examinations currently in process in China, Germany, the Netherlands, Singapore, other non-U.S. jurisdictions and certain U.S. states. The Company does not expect to recognize a significant amount of additional tax expense as a result of concluding these examinations.


## us-gaap:EarningsPerShareTextBlock

[0001628280-26-009585:notes:382]
(Loss) Earnings Per Share

[0001628280-26-009585:notes:383]
The following table sets forth the computation of basic and diluted (loss) earnings per share:

[0001628280-26-009585:notes:384]
| (in thousands, except per share amounts) | 2025 |  | 2024 |  | 2023 |
| Numerator: |  |  |  |  |  |
| Net (loss) income as reported | $ | (71,700) |  |  | $ | 100,190 |  |  | $ | 259,485 |  |
| Denominator: |  |  |  |  |  |
| Weighted average shares outstanding |  |  |  |  |  |
| Basic | 24,817 |  |  | 24,821 |  |  | 24,854 |  |
| Effect of dilutive securities | — |  |  | 218 |  |  | 248 |  |
| Diluted | 24,817 |  |  | 25,039 |  |  | 25,102 |  |
| (Loss) Earnings Per Share: |  |  |  |  |  |
| Basic (loss) earnings per share | $ | (2.89) |  |  | $ | 4.04 |  |  | $ | 10.44 |  |
| Diluted (loss) earnings per share | $ | (2.89) |  |  | $ | 4.00 |  |  | $ | 10.34 |  |

[0001628280-26-009585:notes:385]
Potential shares of common stock attributable to stock options and restricted shares excluded from the earnings per share calculation because their effect would be anti-dilutive based on their strike price or the vesting condition was not met, were 204,189, 139,839, and 110,002 shares in 2025, 2024, and 2023, respectively.

[0001628280-26-009585:notes:386]
In addition, potential common shares of 205,571 for fiscal year 2025 were excluded from the computation of diluted loss per share, because the effect would have been antidilutive as a result of the Company incurring a net loss in 2025.
During the fiscal year of 2025, the Company repurchased 120,689 shares of its common stock totaling $27.4 million pursuant to the 2024 program. There are $270.6 million of an authorized amount not yet purchased under the 2024 program as of December 27, 2025. During the fiscal year of 2024, the Company repurchased 179,311 shares of its common stock totaling $40.9 million, of which, $38.9 million was pursuant to the 2021 program and $2.0 million was pursuant to the 2024 program. During the fiscal year of 2023, the Company did not repurchase any shares of its common stock.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-26-009585:notes:387]
Segment Information

[0001628280-26-009585:notes:388]
The Company and its subsidiaries design, manufacture and sell component, modules and subassemblies to empower the long-term structural themes of sustainability, connectivity and safety. The Company aggregated its operating segments into the reportable segments: Electronics, Transportation, and Industrial. An operating segment is defined as a component of an enterprise that engages in business activities from which it may earn revenues and incur expenses, and about which separate financial information is regularly evaluated by the Chief Operating Decision Maker (“CODM”) in deciding how to allocate resources. The CODM is the Company’s President and Chief Executive Officer (“CEO”). The CODM allocates resources to and assesses the performance of each operating segment using information about its revenue and operating income (loss) before interest and taxes, but does not evaluate the operating segments using discrete balance sheet information and as such, segment asset information is not disclosed. The CODM’s key decisions involve the allocation of resources, such as acquisitions, divestitures, investments, capital expenditures, significant customer contracts, and other key management resources, and assessment of performance, such as executive officer hiring, promotion, and compensation. The CODM uses operating income as the key metric when establishing targets in the annual budget and in evaluating the allocation of resources to each segment. The CODM regularly reviews each segment's operating income against the forecast, budget and previous quarterly results to assess performance and make decisions about the allocation of operating and capital resources to each segment.

[0001628280-26-009585:notes:389]
Sales, marketing, and research and development expenses are charged directly into each operating segment. Finance, information technology, and human resources are shared functions that are allocated back to the operating segments. The Company does not report inter-segment revenue because the operating segments do not record it. Certain expenses, determined by the CODM to be strategic in nature and not directly related to segments current results, are not allocated but identified as “Other.” Additionally, the Company does not allocate interest and other income, interest expense, or taxes to operating segments. These costs are not allocated to the segments, as management excludes such costs when assessing the performance of the segments. Except as discussed above, the accounting policies for segment reporting are the same as for the Company as a whole.

[0001628280-26-009585:notes:390]
•Electronics Segment: Consists of one of the broadest product offerings in the industry, including fuses and fuse accessories, positive temperature coefficient (“PTC”) resettable fuses, electromechanical switches and interconnect solutions, polymer electrostatic discharge (“ESD”) suppressors, varistors, reed switch based magnetic sensing, gas discharge tubes; semiconductor products such as discrete transient voltage suppressor (“TVS”) diodes, TVS diode arrays, protection and switching thyristors, silicon and silicon carbide metal-oxide-semiconductor field effect transistors (“MOSFETs”) and diodes, and insulated gate bipolar transistors (“IGBT”) technologies. The segment covers a broad range of end markets, including data center – computing and communication, data center and communications infrastructure, industrial controls, building controls, aerospace and defense, appliances, consumer electronics solutions, healthcare solutions, industrial equipment, energy storage, diversified industrials, grid and utility infrastructure, renewable energy, passenger vehicles, and commercial vehicles.

[0001628280-26-009585:notes:391]
•Transportation Segment: Consists of a wide range of circuit protection, power control and sensing technologies for global original equipment manufacturers (“OEMs”), Tier-one suppliers and parts and aftermarket distributors in passenger vehicles, heavy-duty truck and bus, off-road and recreational vehicles, material handling, agricultural equipment, construction equipment and other commercial vehicle end markets. Passenger vehicle products are used in internal combustion engines, hybrid and electric vehicles including blade fuses, battery cable protectors, resettable fuses, high-current fuses, high-voltage fuses, and sensor products designed to monitor the occupant’s safety and environment as well as the vehicle’s powertrain. Commercial vehicle products include fuses, switches, circuit breakers, relays, and power distribution modules and units used in applications serving a number of end markets, including heavy-duty truck and bus, off-road and recreational vehicles, material handling, agriculture equipment, construction equipment, and ship, marine and train.

[0001628280-26-009585:notes:392]
•Industrial Segment: Consists of industrial circuit protection (industrial fuses), protective and monitoring relays (protection relays, residual current devices and monitors, ground fault circuit interrupters, solid state switches, and arc fault detection devices), and industrial controls and sensors (contactors, transformers, and temperature sensors) for use in various applications such as data center – computing and communication, data center and communications infrastructure, industrial controls, building controls, grid and utility infrastructure, construction, renewable energy, HVAC, processing and extracting, and energy storage.

[0001628280-26-009585:notes:393]
The Company has provided this segment information for all comparable prior periods. Segment information is summarized as follows:

[0001628280-26-009585:notes:394]
| (in thousands) | 2025 |  | 2024 |  | 2023 |
| Net sales |  |  |  |  |  |
| Electronics | $ | 1,345,522 |  |  | $ | 1,186,773 |  |  | $ | 1,350,426 |  |
| Transportation | 676,377 |  |  | 672,434 |  |  | 678,278 |  |
| Industrial | 364,395 |  |  | 331,561 |  |  | 333,953 |  |
| Total net sales | $ | 2,386,294 |  |  | $ | 2,190,768 |  |  | $ | 2,362,657 |  |
| Other segment expenses |  |  |  |  |  |
| Electronics | $ | 1,125,456 |  |  | $ | 1,016,880 |  |  | $ | 1,049,845 |  |
| Transportation | 591,597 |  |  | 613,856 |  |  | 644,644 |  |
| Industrial | 305,372 |  |  | 289,230 |  |  | 279,153 |  |
| Total other segment expenses | $ | 2,022,425 |  |  | $ | 1,919,966 |  |  | $ | 1,973,642 |  |
| Segment operating income |  |  |  |  |  |
| Electronics | $ | 220,066 |  |  | $ | 169,893 |  |  | $ | 300,581 |  |
| Transportation | 84,780 |  |  | 58,578 |  |  | 33,634 |  |
| Industrial | 59,023 |  |  | 42,331 |  |  | 54,800 |  |
| Total segment operating income | 363,869 |  |  | 270,802 |  |  | 389,015 |  |
| Other(a) | (326,341) |  |  | (112,022) |  |  | (28,153) |  |
| Total operating income | 37,528 |  |  | 158,780 |  |  | 360,862 |  |
| Interest expense | 34,303 |  |  | 38,717 |  |  | 39,866 |  |
| Foreign exchange loss (gain) | 16,612 |  |  | (9,230) |  |  | 12,299 |  |
| Other income, net | (16,994) |  |  | (22,570) |  |  | (19,901) |  |
| Income before income taxes | $ | 3,607 |  |  | $ | 151,863 |  |  | $ | 328,598 |  |

[0001628280-26-009585:notes:395]
(a) Included in “Other” Operating income for 2025 was $302.1 million of non-cash impairment charges, which included a  $301.2 million non-cash goodwill impairment charge associated with the Electronics-Semiconductor reporting unit within the Electronics segment. In addition, the Company recognized impairment charges of $0.5 million and $0.4 million related to certain machinery and equipment in the commercial vehicle business within the Transportation segment and the electronics products business within the Electronics segment, respectively. The Company also recognized total restructuring charges of $18.0 million, primarily for employee termination costs. These charges primarily related to the reorganization of certain manufacturing, selling and administrative functions in the power semiconductor business within the Electronics segment and the reorganization of certain manufacturing, selling and administrative functions in the commercial vehicle business and automotive sensors business within the Transportation segment. See Note 8, Restructuring, Impairment and Other Charges, for further discussion. Also included in "Other" Operating income was $5.4 million of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, $0.6 million of purchase accounting inventory adjustments related to the Basler and Dortmund Fab acquisitions, and a $0.3 million loss related to the sale of the Marine business within the Transportation segment.

[0001628280-26-009585:notes:396]
Included in “Other” Operating income for 2024 was $93.5 million of non-cash impairment charges, which included $47.8 million for the impairment of intangible assets primarily related to certain acquired customer relationships, developed technology, and tradename in the Industrial Controls and Sensors reporting unit within the Industrial segment, and $36.1 million and $8.6 million of non-cash goodwill impairment charges associated with the Industrial Controls and Sensors reporting unit within the Industrial segment and the Automotive Sensors reporting unit within the Transportation segment, respectively. The remaining impairment charges included $0.2 million for patents and customer relationships related to the exit of a small business in China within the Industrial segment. In addition, during the first quarter of 2024, the Company recognized a $0.9 million impairment charge related to certain machinery and equipment in the commercial vehicle business within the Transportation segment. The Company also recognized total restructuring charges of $14.9 million, primarily for employee termination costs related to the reorganization of certain manufacturing, selling and administrative functions in the semiconductor business within the Electronics segment and the reorganization of certain selling and administrative functions in the commercial vehicle business within the Transportation segment. See Note 8, Restructuring, Impairment and Other Charges,

[0001628280-26-009585:notes:397]
for further discussion. Also included in "Other" Operating income was $5.1 million of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, a gain of $1.0 million for the sale of two buildings within the Transportation segment, and a gain of $0.5 million recorded for the sale of a land use right within the Electronics segment.

[0001628280-26-009585:notes:398]
Included in “Other” Operating income for 2023 was $11.7 million of legal and professional fees and other integration expenses related to completed and contemplated acquisitions and $11.6 million of restructuring, impairment and other charges, primarily related to employee termination costs. During 2023, the Company recorded a $3.9 million impairment charge related to the land and building in the commercial vehicle business within the Transportation segment, $0.9 million impairment charge substantially related to certain patents in a business within the Industrial segment, and a $0.1 million impairment related to certain machinery and equipment in the semiconductor business within the Electronics segment. See Note 8, Restructuring, Impairment and Other Charges, for further discussion.

[0001628280-26-009585:notes:399]
Other segment operating expenses include cost of sales, selling, general, and administration expenses, and research and development expenses. Other segment expenses are reconciled to the operating income of each segment. The CODM regularly assesses the performance of each operating segment focusing on each operating segment’s revenue and operating income.

[0001628280-26-009585:notes:400]
The Company’s depreciation and amortization expenses by segment for the fiscal years 2025, 2024, and 2023 were as follows:

[0001628280-26-009585:notes:401]
| (in thousands) | 2025 |  | 2024 |  | 2023 |
| Depreciation |  |  |  |  |  |
| Electronics | $ | 47,599 |  |  | $ | 40,456 |  |  | $ | 39,461 |  |
| Transportation | 21,143 |  |  | 22,117 |  |  | 26,732 |  |
| Industrial | 6,129 |  |  | 5,752 |  |  | 5,441 |  |
| Total depreciation | $ | 74,871 |  |  | $ | 68,325 |  |  | $ | 71,634 |  |
| Amortization |  |  |  |  |  |
| Electronics | $ | 40,350 |  |  | $ | 39,362 |  |  | $ | 39,883 |  |
| Transportation | 13,540 |  |  | 13,518 |  |  | 15,782 |  |
| Industrial | 5,903 |  |  | 9,247 |  |  | 10,129 |  |
| Total amortization | $ | 59,793 |  |  | $ | 62,127 |  |  | $ | 65,794 |  |

[0001628280-26-009585:notes:402]
The Company’s net sales classified according to the country where the customer is located, net property, plant, and equipment and additions to net property, plant, and equipment by country for the fiscal years 2025, 2024, and 2023 were as follows:

[0001628280-26-009585:notes:403]
| (in thousands) | 2025 |  | 2024 |  | 2023 |
| Net sales |  |  |  |  |  |
| U.S. | $ | 830,293 |  |  | $ | 800,331 |  |  | $ | 820,735 |  |
| China | 571,587 |  |  | 506,643 |  |  | 546,786 |  |
| Other countries(a) | 984,414 |  |  | 883,794 |  |  | 995,136 |  |
| Total net sales | $ | 2,386,294 |  |  | $ | 2,190,768 |  |  | $ | 2,362,657 |  |
| Long-lived assets |  |  |  |  |  |
| U.S. | $ | 95,619 |  |  | $ | 74,698 |  |  | $ | 73,126 |  |
| China | 130,047 |  |  | 132,504 |  |  | 139,736 |  |
| Mexico | 83,478 |  |  | 89,558 |  |  | 102,218 |  |
| Germany | 110,246 |  |  | 58,758 |  |  | 47,217 |  |
| Philippines | 61,591 |  |  | 66,174 |  |  | 73,217 |  |
| Other countries | 59,659 |  |  | 55,376 |  |  | 57,639 |  |
| Total long-lived assets | $ | 540,640 |  |  | $ | 477,068 |  |  | $ | 493,153 |  |
| Additions to long-lived assets |  |  |  |  |  |
| U.S. | $ | 10,694 |  |  | $ | 19,081 |  |  | $ | 9,502 |  |
| China | 13,371 |  |  | 16,045 |  |  | 32,805 |  |
| Mexico | 6,381 |  |  | 10,181 |  |  | 13,920 |  |
| Germany | 20,626 |  |  | 19,972 |  |  | 10,279 |  |
| Philippines | 5,716 |  |  | 4,383 |  |  | 6,156 |  |
| Other countries | 8,462 |  |  | 8,751 |  |  | 10,992 |  |
| Total additions to long-lived assets | $ | 65,250 |  |  | $ | 78,413 |  |  | $ | 83,654 |  |

[0001628280-26-009585:notes:404]
(a)Each country included in other countries are less than 10% of net sales.

[0001628280-26-009585:notes:405]
For the year ended December 27, 2025, approximately 65% of the Company’s net sales were to customers outside the U.S. (exports and foreign operations), including approximately 24% to China. For the year ended December 28, 2024, approximately 63% of the Company's net sales were to customers outside the U.S. (exports and foreign operations), including approximately 23% to China. For the year ended December 30, 2023, approximately 65% of the Company's net sales were to customers outside the U.S. (exports and foreign operations), including approximately 23% to China. Sales to Arrow Electronics, Inc., which were included in the Electronics, Transportation, and Industrial segments, were 9.5%, 9.4%, and 11.2% of consolidated net sales in 2025, 2024, and 2023 respectively. No other single customer accounted for more than 10% of net sales during the last three years.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001628280-26-009585:notes:406]
for further discussion. Also included in "Other" Operating income was $5.1 million of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, a gain of $1.0 million for the sale of two buildings within the Transportation segment, and a gain of $0.5 million recorded for the sale of a land use right within the Electronics segment.
Included in “Other” Operating income for 2023 was $11.7 million of legal and professional fees and other integration expenses related to completed and contemplated acquisitions and $11.6 million of restructuring, impairment and other charges, primarily related to employee termination costs. During 2023, the Company recorded a $3.9 million impairment charge related to the land and building in the commercial vehicle business within the Transportation segment, $0.9 million impairment charge substantially related to certain patents in a business within the Industrial segment, and a $0.1 million impairment related to certain machinery and equipment in the semiconductor business within the Electronics segment. See Note 8, Restructuring, Impairment and Other Charges, for further discussion.
The Company’s depreciation and amortization expenses by segment for the fiscal years 2025, 2024, and 2023 were as follows:


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-26-009585:notes:407]
Commitments and Contingencies
Off-Balance Sheet Arrangements

[0001628280-26-009585:notes:408]
As of December 27, 2025, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0001628280-26-009585:notes:409]
Product Warranty Liabilities

[0001628280-26-009585:notes:410]
The Company's policy is to accrue for warranty claims when a loss is both probable and estimable. Liabilities for warranty claims have historically not been material and in limited instances, customers may make claims for costs they incurred or other damages related to a claim.

[0001628280-26-009585:notes:411]
The Company carries insurance for potential product liability claims at coverage levels based on the Company's prior claims experience. This coverage is subject to deductibles, and various terms and conditions. The Company cannot assure that the level of coverage will be sufficient to cover every possible claim that can arise in its businesses, now or in the future, or that such coverage always will be available should the Company, now or in the future, wish to extend, increase or otherwise adjust its insurance.

[0001628280-26-009585:notes:412]
The Company has been notified by one of its customers of a product recall potentially due to certain fuses provided by Littelfuse and incorporated in such products. The Company is currently working with its customer to investigate the cause and level of responsibility for this recall. The Company has determined pursuant to ASC 450, "Contingencies", that a loss is reasonably possible. However, the Company continues to evaluate this matter and the ultimate costs of the recall and range of the potential loss cannot be determined at this time. Accordingly, no accrual has been made yet for this matter. Factors that will impact the amount of such losses include the per vehicle cost of fuse replacement, the determination of the relative liability among the customer, the Company, and any relevant third parties, as well as actual insurance recoveries.

[0001628280-26-009585:notes:413]
Environmental Remediation Liabilities

[0001628280-26-009585:notes:414]
Refer to Note 1: Summary of Significant Accounting Policies and Other Information related to environmental liabilities. Our operations and facilities are subject to U.S. and non-U.S. laws and regulations governing the protection of the environment and our employees, including those governing air emissions, chemical usage, water discharges, the management and disposal of hazardous substances and wastes, and the cleanup of contaminated sites. We could incur significant costs, including cleanup costs, fines, civil or criminal sanctions, or third-party property damage or personal injury claims, in the event of violations or liabilities under these laws and regulations, or non-compliance with the environmental permits required at our facilities. Potentially significant expenditures could be required in order to comply with environmental laws that may be adopted or imposed in the future. We are, however, not aware of any threatened or pending material environmental investigations, lawsuits, or claims involving the Company or its operations.

[0001628280-26-009585:notes:415]
Legal Proceedings

[0001628280-26-009585:notes:416]
In the ordinary course of business, the Company may be involved in a number of claims and litigation matters. While it is not feasible to predict the outcome of these matters, based upon our experience and current information known to us, we do not expect the outcome of these matters, either individually or in the aggregate, to have a material adverse effect on our results of operations, financial position, and/or cash flows.

[0001628280-26-009585:notes:417]
The Company accounts for litigation and claims losses in accordance with FASB ASC Topic 450, Contingencies where loss contingency provisions are recognized for probable and estimable losses at our best estimate of a loss or, when a best estimate cannot be made, at our estimate of the minimum loss. These estimates require the application of considerable judgment and are refined each accounting period as additional information becomes known. We are often initially unable to develop a best estimate of loss and therefore the minimum amount, which could be an immaterial amount, is recognized. As information becomes known, either the minimum loss amount is increased, or a best estimate can be made, resulting in additional loss provisions. A best estimate may be changed to a lower amount when events result in an expectation of a more favorable outcome than previously expected.

[0001628280-26-009585:notes:418]
Pending Litigation and Claims

[0001628280-26-009585:notes:419]
There are no material pending litigation or claims outstanding as of December 27, 2025.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001628280-26-009585:notes:420]
Related Party Transactions

[0001628280-26-009585:notes:421]
As a result of the Company’s acquisition of IXYS, the Company has equity ownerships in various investments that are accounted for under the equity method. The following is a description of the investments and related party transactions.

[0001628280-26-009585:notes:422]
Powersem GmbH: The Company owns 45% of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany.

[0001628280-26-009585:notes:423]
EB-Tech Co., Ltd.: The Company owns approximately 15% of the outstanding equity of EB-Tech Co., Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea.

[0001628280-26-009585:notes:424]
Automated Technology (Phil), Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology (Phil), Inc. (“ATEC”), a supplier located in the Philippines that provides assembly and test services.

[0001628280-26-009585:notes:425]
|  | Fiscal Year Ended |
|  | December 27, 2025 |  | December 28, 2024 |
| (in millions) | Powersem |  | EB Tech |  | ATEC |  | Powersem |  | EB Tech |  | ATEC |
| Sales to related party | $ | 1.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 1.5 |  |  | $ | — |  |  | $ | — |  |
| Purchase of material/services from related party | 2.2 |  |  | 0.9 |  |  | 9.0 |  |  | 3.8 |  |  | 0.7 |  |  | 5.7 |  |
| Accounts payable balance | $ | 0.1 |  |  | $ | 0.1 |  |  | $ | 2.1 |  |  | $ | 0.7 |  |  | $ | 0.1 |  |  | $ | 0.7 |  |


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001628280-26-009585:notes:426]
SCHEDULE II

[0001628280-26-009585:notes:427]
VALUATION AND QUALIFYING ACCOUNTS AND RESERVES

[0001628280-26-009585:notes:428]
| Description | Balance atBeginningof Year |  | Charged toCosts andExpenses (a) |  | Deductions (b) |  | Other (c) |  | Balance atEndof Year |
| (in thousands) |  |  |  |  |  |  |  |  |  |
| Fiscal year ended December 27, 2025 |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses on accounts receivable | $ | 1,589 |  |  | $ | 815 |  |  | $ | (266) |  |  | $ | 382 |  |  | $ | 2,520 |  |
| Reserves for sales discounts and allowances | $ | 68,401 |  |  | $ | 168,821 |  |  | $ | (164,156) |  |  | $ | 1,487 |  |  | $ | 74,553 |  |
| Fiscal year ended December 28, 2024 |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses on accounts receivable | $ | 2,187 |  |  | $ | (182) |  |  | $ | (345) |  |  | $ | (71) |  |  | $ | 1,589 |  |
| Reserves for sales discounts and allowances | $ | 82,509 |  |  | $ | 138,735 |  |  | $ | (151,946) |  |  | $ | (897) |  |  | $ | 68,401 |  |
| Fiscal year ended December 30, 2023 |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses on accounts receivable | $ | 1,575 |  |  | $ | 519 |  |  | $ | (181) |  |  | $ | 274 |  |  | $ | 2,187 |  |
| Reserves for sales discounts and allowances | $ | 81,987 |  |  | $ | 186,021 |  |  | $ | (186,043) |  |  | $ | 544 |  |  | $ | 82,509 |  |

[0001628280-26-009585:notes:429]
(a)Includes provision for credit losses, sales returns and sales discounts granted to customers.

[0001628280-26-009585:notes:430]
(b)Represents uncollectible accounts written off, net of recoveries and credits issued to customers.

[0001628280-26-009585:notes:431]
(c)Represents business acquisitions and foreign currency translation adjustments.
