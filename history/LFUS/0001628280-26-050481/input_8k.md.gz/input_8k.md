# LFUS 8-K — 0001628280-26-050382 filed 2026-07-29

## item codes, every 8-K on or before 2026-07-29

- 2026-07-29 0001628280-26-050382 — 2.02, 7.01, 9.01
- 2026-05-14 0001140361-26-021160 — 7.01, 9.01
- 2026-05-06 0001628280-26-030892 — 2.02, 7.01, 9.01
- 2026-04-28 0000889331-26-000005 — 5.02, 5.07, 9.01
- 2026-03-13 0001140361-26-009393 — 1.01, 2.03, 9.01
- 2026-03-05 0000889331-26-000002 — 5.02, 7.01, 9.01
- 2026-01-28 0001628280-26-003710 — 2.02, 7.01, 9.01
- 2026-01-08 0001140361-26-000720 — 5.02, 9.01
- 2025-10-29 0001628280-25-046908 — 2.02, 7.01, 9.01
- 2025-10-28 0000889331-25-000186 — 1.01, 7.01, 9.01
- 2025-08-07 0000889331-25-000151 — 5.02, 7.01, 9.01
- 2025-07-30 0001628280-25-036551 — 2.02, 7.01, 9.01
- 2025-05-27 0000889331-25-000109 — 5.02, 7.01, 9.01
- 2025-04-29 0000889331-25-000095 — 2.02, 7.01, 9.01
- 2025-04-28 0000889331-25-000082 — 5.02, 5.07, 9.01
- 2025-04-09 0001140361-25-012942 — 5.02, 7.01, 9.01
- 2025-01-28 0000889331-25-000013 — 2.02, 7.01, 9.01
- 2025-01-13 0001140361-25-000873 — 5.02, 9.01
- 2024-10-29 0000889331-24-000188 — 2.02, 7.01, 9.01
- 2024-07-30 0000889331-24-000159 — 2.02, 7.01, 9.01
- 2024-04-30 0000889331-24-000125 — 2.02, 7.01, 9.01
- 2024-04-26 0000889331-24-000064 — 5.02, 5.07, 9.01
- 2024-02-01 0000889331-24-000014 — 5.02
- 2024-01-30 0000889331-24-000010 — 2.02, 7.01, 9.01
- 2024-01-05 0000889331-24-000004 — 5.02
- 2023-10-31 0000889331-23-000154 — 2.02, 7.01, 9.01
- 2023-09-28 0000889331-23-000145 — 5.02, 8.01, 9.01
- 2023-08-16 0000889331-23-000135 — 4.01
- 2023-08-01 0000889331-23-000129 — 2.02, 7.01, 9.01
- 2023-05-15 0000889331-23-000104 — 5.02, 8.01, 9.01
- 2023-05-02 0000889331-23-000091 — 2.02, 7.01, 9.01
- 2023-04-28 0000889331-23-000039 — 5.02, 5.07, 8.01, 9.01
- 2023-02-02 0000889331-23-000007 — 5.03, 9.01
- 2023-02-01 0000889331-23-000003 — 2.02, 7.01, 9.01
- 2022-11-01 0000889331-22-000044 — 2.02, 7.01, 9.01
- 2022-08-02 0000889331-22-000037 — 2.02, 7.01, 9.01
- 2022-07-19 0000889331-22-000032 — 2.03, 7.01, 9.01
- 2022-06-30 0000889331-22-000028 — 1.01, 2.03, 9.01
- 2022-05-19 0001140361-22-019845 — 1.01, 2.03, 9.01
- 2022-05-03 0000889331-22-000020 — 2.02, 7.01, 9.01
- 2022-04-29 0000889331-22-000015 — 5.07
- 2022-04-08 0001140361-22-013670 — 1.01, 7.01, 9.01
- 2022-02-01 0000889331-22-000004 — 2.02, 7.01, 9.01
- 2021-11-30 0000889331-21-000069 — 2.01, 7.01, 9.01
- 2021-10-26 0000889331-21-000062 — 2.02, 7.01, 9.01
- 2021-10-20 0000889331-21-000057 — 1.01, 7.01, 9.01
- 2021-07-28 0000889331-21-000045 — 2.02, 7.01, 9.01
- 2021-04-28 0000889331-21-000032 — 2.02, 7.01, 9.01
- 2021-04-23 0000889331-21-000026 — 5.02, 5.07
- 2021-02-23 0000889331-21-000014 — 7.01, 9.01
- 2021-02-03 0000889331-21-000006 — 2.02, 9.01
- 2021-01-27 0000889331-21-000004 — 5.02
- 2020-10-28 0000889331-20-000052 — 2.02, 9.01
- 2020-07-29 0000889331-20-000043 — 2.02, 9.01
- 2020-04-29 0000889331-20-000036 — 2.02, 9.01
- 2020-04-24 0000889331-20-000029 — 5.02 — amendment of 0000889331-20-000003
- 2020-04-24 0000889331-20-000027 — 5.02, 5.07, 9.01
- 2020-04-07 0000889331-20-000025 — 1.01, 2.03, 9.01
- 2020-02-26 0000889331-20-000016 — 7.01, 9.01
- 2020-01-29 0000889331-20-000007 — 2.02, 9.01
- 2020-01-27 0000889331-20-000003 — 5.02, 8.01, 9.01
- 2019-10-30 0000889331-19-000049 — 2.02, 9.01
- 2019-08-28 0000889331-19-000045 — 7.01, 9.01
- 2019-07-31 0000889331-19-000040 — 2.02, 9.01
- 2019-07-17 0000889331-19-000035 — 2.02
- 2019-05-01 0000889331-19-000028 — 2.02, 9.01
- 2019-04-29 0000889331-19-000023 — 5.02, 5.07
- 2019-01-30 0000889331-19-000007 — 2.02, 9.01
- 2019-01-25 0000889331-19-000003 — 5.03, 9.01
- 2018-12-10 0000889331-18-000008 — 5.02, 8.01, 9.01
- 2018-10-31 0001437749-18-019099 — 2.02, 9.01
- 2018-08-01 0001437749-18-014136 — 2.02, 8.01, 9.01
- 2018-05-03 0001437749-18-008417 — 8.01, 9.01
- 2018-05-02 0001437749-18-008297 — 2.02, 9.01
- 2018-04-30 0001437749-18-008145 — 5.07
- 2018-03-23 0001437749-18-005267 — 9.01 — amendment of 0001104659-18-002723
- 2018-01-31 0001437749-18-001357 — 2.02, 9.01
- 2018-01-23 0001437749-18-000993 — 5.02, 9.01
- 2018-01-18 0001104659-18-002723 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-01-04 0001104659-18-000788 — 8.01, 9.01
- 2017-11-15 0001437749-17-019474 — 1.01, 2.03, 9.01
- 2017-11-01 0001437749-17-017988 — 2.02, 9.01
- 2017-10-16 0001437749-17-017141 — 1.01, 2.03, 9.01
- 2017-08-28 0001104659-17-053761 — 1.01, 8.01, 9.01
- 2017-08-14 0001437749-17-014727 — 5.02, 9.01
- 2017-08-02 0001437749-17-013530 — 2.02, 9.01
- 2017-07-18 0001437749-17-012737 — 2.02, 7.01, 9.01
- 2017-05-03 0001437749-17-007795 — 2.02, 9.01
- 2017-05-01 0001437749-17-007625 — 5.02, 5.07, 9.01
- 2017-03-02 0001437749-17-003603 — 7.01, 9.01
- 2017-02-15 0001437749-17-002588 — 1.01, 2.03, 9.01
- 2017-02-01 0001437749-17-001426 — 2.02, 9.01
- 2016-12-09 0001437749-16-043140 — 1.01, 2.03, 7.01, 9.01
- 2016-12-07 0001437749-16-043008 — 7.01
- 2016-11-16 0001437749-16-042222 — 5.02, 9.01
- 2016-11-03 0001437749-16-040906 — 2.02, 9.01
- 2016-10-24 0001437749-16-040112 — 2.02, 7.01, 9.01
- 2016-08-29 0000898822-16-000433 — 8.01
- 2016-08-25 0000898822-16-000429 — 8.01, 9.01
- 2016-08-04 0001437749-16-036352 — 2.02, 9.01
- 2016-07-26 0001437749-16-035667 — 5.02, 9.01
- 2016-06-10 0001437749-16-033638 — 9.01 — amendment of 0001437749-16-028458
- 2016-05-05 0001437749-16-030854 — 2.02, 9.01
- 2016-04-28 0001437749-16-030217 — 5.07
- 2016-03-28 0001437749-16-028458 — 2.01, 8.01, 9.01
- 2016-03-10 0001437749-16-027272 — 1.01, 1.02, 2.03, 9.01
- 2016-02-03 0001437749-16-024613 — 5.02, 9.01
- 2016-02-02 0001437749-16-024462 — 2.02, 9.01
- 2015-11-12 0001437749-15-020546 — 1.01, 9.01
- 2015-11-09 0001437749-15-020125 — 8.01, 9.01
- 2015-10-28 0001437749-15-018951 — 2.02, 9.01
- 2015-07-29 0001437749-15-014196 — 2.02, 9.01
- 2015-04-29 0001437749-15-008246 — 2.02, 5.07, 9.01
- 2015-02-04 0001437749-15-001708 — 2.02, 9.01
- 2014-12-22 0001437749-14-022368 — 5.02, 9.01
- 2014-11-12 0001437749-14-020421 — 8.01, 9.01
- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2026-07-29

- 2025-02-27 0001140361-25-006294 — NT 10-K, for the period ended 2024-12-28
- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0001628280-26-050382:8k_2_02:1]
EX-99.1
2
q22026earningsreleaseex991.htm
EX-99.1

[0001628280-26-050382:8k_2_02:2]
Document

[0001628280-26-050382:8k_2_02:3]
Exhibit 99.1

[0001628280-26-050382:8k_2_02:4]
|  | FOR IMMEDIATE RELEASEDavid Kelley224-727-2535dkelley@littelfuse.com |

[0001628280-26-050382:8k_2_02:5]
Littelfuse Reports Second Quarter Results for 2026

[0001628280-26-050382:8k_2_02:6]
Second Quarter Highlights:

[0001628280-26-050382:8k_2_02:7]
(Year-over-year comparisons unless otherwise noted)

[0001628280-26-050382:8k_2_02:8]
•Net sales of $739 million, +20%; organic growth contributed +14%

[0001628280-26-050382:8k_2_02:9]
•Cash flow from operations of $146 million; free cash flow of $127 million, +75%

[0001628280-26-050382:8k_2_02:10]
•YTD Cash flow from operations of $226 million; free cash flow of $193 million, +68%

[0001628280-26-050382:8k_2_02:11]
•GAAP diluted earnings per share of $3.49; Adjusted diluted earnings per share of $4.19

[0001628280-26-050382:8k_2_02:12]
•GAAP operating margin of 16.2%, +110 bps; Adjusted EBITDA margin of 23.6%, +220 bps

[0001628280-26-050382:8k_2_02:13]
•Cash dividend of $0.80 per share, annualized to $3.20 per share, +7%

[0001628280-26-050382:8k_2_02:14]
CHICAGO, July 29, 2026  - Littelfuse, Inc. (NASDAQ: LFUS), a leader in developing smart solutions that enable safe and efficient electrical energy transfer, today reported financial results for its second quarter ended June 27, 2026:

[0001628280-26-050382:8k_2_02:15]
“We delivered strong second quarter results, with performance exceeding our expectations reflecting broad-based demand strength and disciplined execution across the portfolio,” said Greg Henderson, Littelfuse President and Chief Executive Officer. “We drove growth across our segments as our teams continued to make progress on our strategic priorities while leveraging our leadership position in safe and efficient electrical energy transfer. We remain focused on scaling our high growth opportunities, partnering with our market leading customers, enhancing operational excellence, and deploying capital with discipline as we execute our long‑term strategy.”

[0001628280-26-050382:8k_2_02:16]
“Looking ahead to the third quarter, we expect approximately 26% total revenue growth versus the prior year, supported by record bookings, continued customer momentum, and contributions from the Basler acquisition. We continue to partner closely with our customers to drive the ongoing evolution to higher power and higher energy density solutions.”

[0001628280-26-050382:8k_2_02:17]
Third Quarter of 2026*

[0001628280-26-050382:8k_2_02:18]
Based on current market conditions, for the third quarter the company expects,

[0001628280-26-050382:8k_2_02:19]
•Net sales in the range of $780 - $800 million, adjusted diluted EPS in the range of $4.85 – $5.05 and an adjusted effective tax rate of approximately 23% - 24%

[0001628280-26-050382:8k_2_02:20]
-more-

[0001628280-26-050382:8k_2_02:21]
*Littelfuse provides guidance on a non-GAAP (adjusted) basis. GAAP items excluded from guidance may include the after-tax impact of items including acquisition and integration costs, restructuring, impairment and other charges, certain purchase accounting adjustments, non-operating foreign exchange adjustments and significant and unusual items. These items are uncertain, depend on various factors, and could be material to results computed in accordance with GAAP. Littelfuse is not able to forecast the excluded items in order to provide the most directly comparable GAAP financial measure without unreasonable efforts.

[0001628280-26-050382:8k_2_02:22]
Second Quarter 2026 Segment Performance Highlights

[0001628280-26-050382:8k_2_02:23]
Electronics Segment

[0001628280-26-050382:8k_2_02:24]
•Net sales for the second quarter 2026 increased +21%. Organic sales increased +20% driven by improved passive products (+26% organic) sales. Semiconductor product (+15% organic) sales also contributed to growth driven by increased protection and power semiconductor volumes. Favorable FX contributed +1% to growth.

[0001628280-26-050382:8k_2_02:25]
•Adjusted EBITDA margin for the second quarter 2026 increased to 26.3% (+470 bps) due to volume leverage, favorable mix, and operational execution in both passive products and semiconductor products.

[0001628280-26-050382:8k_2_02:26]
Transportation Segment

[0001628280-26-050382:8k_2_02:27]
•Net sales for the second quarter 2026 increased +2% as organic sales increased +1% while favorable FX contributed +1% to growth. Organic sales growth benefited from improved commercial vehicle sales (+4% organic), which offset lower passenger vehicle organic sales (-2%). Commercial vehicle sales growth benefited from improved truck, construction and agricultural equipment demand. Passenger vehicle sales were impacted by lower global passenger car builds and auto sensor product declines.

[0001628280-26-050382:8k_2_02:28]
•Adjusted EBITDA margin for the second quarter 2026 decreased to 18.6% (-190 bps) driven by lower commercial vehicle profitability which more than offset passenger vehicle margin expansion.

[0001628280-26-050382:8k_2_02:29]
Industrial Segment

[0001628280-26-050382:8k_2_02:30]
•Net sales for the second quarter 2026 increased +52%. Organic sales increased +16% driven by improved data center, HVAC, industrial automation, and construction demand. The Basler acquisition contributed +36% to growth.

[0001628280-26-050382:8k_2_02:31]
•Adjusted EBITDA margin for the second quarter 2026 increased to 22.6% (+50 bps) driven by favorable volume leverage and mix.

[0001628280-26-050382:8k_2_02:32]
Dividend

[0001628280-26-050382:8k_2_02:33]
•The company will pay a cash dividend of $0.80 per share on its common stock, a 7% increase from the prior quarter dividend of $0.75 per share. The dividend will be paid on September 3, 2026, to shareholders of record as of August 20, 2026.

[0001628280-26-050382:8k_2_02:34]
Conference Call and Webcast Information

[0001628280-26-050382:8k_2_02:35]
Littelfuse will host a conference call on Wednesday, July 29, 2026, at 8:00 a.m. Central Time to discuss the results. The call will be broadcast and available for replay at Littelfuse.com. A slide presentation is available in the Investor Relations section of the company’s website at Littelfuse.com.

[0001628280-26-050382:8k_2_02:36]
-more-

[0001628280-26-050382:8k_2_02:37]
About Littelfuse

[0001628280-26-050382:8k_2_02:38]
Littelfuse, Inc. (NASDAQ: LFUS) is a diversified, industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 20 countries, and with approximately 18,000 global associates, we partner with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, our products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day. Learn more at Littelfuse.com.

[0001628280-26-050382:8k_2_02:39]
The statements in this press release that are not historical facts are intended to constitute "forward-looking statements" entitled to the safe-harbor provisions of the Private Securities Litigation Reform Act. Such statements are based on Littelfuse, Inc.’s (“Littelfuse” or the “Company”) current expectations and are subject to a number of factors and uncertainties, which could cause actual results to differ materially from those described in the forward-looking statements. These risks, uncertainties and other factors include, but are not limited to, risks and uncertainties relating to general economic conditions; product demand and market acceptance; economic conditions; the impact of competitive products and pricing; product quality problems or product recalls; capacity and supply difficulties or constraints; coal mining exposures reserves; cybersecurity matters; failure of an indemnification for environmental liability; changes in import and export duty and tariff rates; exchange rate fluctuations; commodity price fluctuations; the effect of the Company's accounting policies; labor disputes and shortages; restructuring costs in excess of expectations; pension plan asset returns less than assumed; uncertainties related to political or regulatory changes; integration of acquisitions may not be achieved in a timely manner, or at all; limited realization of the expected benefits from investment and strategic plans; the risk that expected benefits, synergies and growth prospects of the transaction with Basler may not be achieved in a timely manner, or at all; and other risks which may be detailed in the company's Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This release should be read in conjunction with information provided in the financial statements appearing in the company's Annual Report on Form 10-K for the year ended December 27, 2025.

[0001628280-26-050382:8k_2_02:40]
Further discussion of the risk factors of the company can be found under the caption "Risk Factors" in the company's Annual Report on Form 10-K for the year ended December 27, 2025, and in other filings and submissions with the SEC, each of which are available free of charge on the company’s investor relations website at investor.littelfuse.com and on the SEC’s website at www.sec.gov. These forward-looking statements are made as of the date hereof. The company does not undertake any obligation to update, amend or clarify these forward-looking statements to reflect events or circumstances after the date hereof or to reflect the availability of new information.

[0001628280-26-050382:8k_2_02:41]
-more-

[0001628280-26-050382:8k_2_02:42]
Non-GAAP Financial Measures

[0001628280-26-050382:8k_2_02:43]
The information included in this press release and other materials filed with the SEC may include non-GAAP financial measures including organic net sales (decline) growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted income taxes, adjusted effective tax rate, free cash flow, net debt, consolidated EBITDA, and consolidated net leverage ratio (as defined in the credit agreement). Many of these non-GAAP financial measures exclude the effect of certain expenses and income not related directly to the underlying performance of our fundamental business operations. A reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures is set forth in the attached schedules. The company believes that organic net sales (decline) growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted income taxes, and adjusted effective tax rate provide useful information to investors regarding its operational performance because they enhance an investor’s overall understanding of the company’s core financial performance and facilitate comparisons to historical results of operations, by excluding items that are not related directly to the underlying performance of its fundamental business operations or were not part of the company’s business operations during a comparable period. The company believes that free cash flow is a useful measure of its ability to generate cash. The company believes that net debt, consolidated EBITDA, and consolidated net leverage ratio are useful measures of its credit position. The company believes that all of these non-GAAP financial measures are commonly used by financial analysts and others in the industries in which we operate, and thus further provide useful information to investors. Management additionally uses these measures when assessing the performance of the business and for business planning purposes. Note that the company’s definitions of these non-GAAP financial measures may differ from those terms as defined or used by other companies.

[0001628280-26-050382:8k_2_02:44]
LFUS-F

[0001628280-26-050382:8k_2_02:45]
###

[0001628280-26-050382:8k_2_02:46]
|  | Littelfuse Inc.6133 North River Road, Suite 500Rosemont, Illinois 60018p: (773) 628-1000www.littelfuse.com |

[0001628280-26-050382:8k_2_02:47]
LITTELFUSE, INC.

[0001628280-26-050382:8k_2_02:48]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-26-050382:8k_2_02:49]
|  |  | (Unaudited) |  |  |
| (in thousands, except share and per share data) |  | June 27,2026 |  | December 27,2025 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 628,224 |  |  | $ | 563,391 |  |
| Short-term investments |  | 367 |  |  | 287 |  |
| Trade receivables, less allowances of $86,865 and $77,073 at June 27, 2026 and December 27, 2025, respectively |  | 423,590 |  |  | 363,215 |  |
| Inventories |  | 433,755 |  |  | 416,472 |  |
| Prepaid income taxes and income taxes receivable |  | 4,044 |  |  | 6,137 |  |
| Prepaid expenses and other current assets |  | 93,629 |  |  | 85,832 |  |
| Total current assets |  | 1,583,609 |  |  | 1,435,334 |  |
| Net property, plant, and equipment |  | 513,160 |  |  | 540,640 |  |
| Intangible assets, net of amortization |  | 553,511 |  |  | 594,907 |  |
| Goodwill |  | 1,203,861 |  |  | 1,211,411 |  |
| Investments |  | 11,923 |  |  | 20,010 |  |
| Deferred income taxes |  | 4,977 |  |  | 5,255 |  |
| Right of use lease assets |  | 81,729 |  |  | 86,263 |  |
| Other long-term assets |  | 59,709 |  |  | 62,976 |  |
| Total assets |  | $ | 4,012,479 |  |  | $ | 3,956,796 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 248,972 |  |  | $ | 211,079 |  |
| Accrued liabilities |  | 191,873 |  |  | 199,271 |  |
| Accrued income taxes |  | 32,667 |  |  | 26,186 |  |
| Current portion of long-term debt |  | 100,000 |  |  | 96,233 |  |
| Total current liabilities |  | 573,512 |  |  | 532,769 |  |
| Long-term debt, less current portion |  | 529,660 |  |  | 706,394 |  |
| Deferred income taxes |  | 110,081 |  |  | 102,335 |  |
| Accrued post-retirement benefits |  | 40,062 |  |  | 38,733 |  |
| Non-current lease liabilities |  | 68,146 |  |  | 71,765 |  |
| Other long-term liabilities |  | 72,658 |  |  | 78,766 |  |
| Total equity |  | 2,618,360 |  |  | 2,426,034 |  |
| Total liabilities and equity |  | $ | 4,012,479 |  |  | $ | 3,956,796 |  |

[0001628280-26-050382:8k_2_02:50]
LITTELFUSE, INC.

[0001628280-26-050382:8k_2_02:51]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001628280-26-050382:8k_2_02:52]
(Unaudited)

[0001628280-26-050382:8k_2_02:53]
|  |  | Three Months Ended |  | Six Months Ended |
| (in thousands, except per share data) |  | June 27,2026 |  | June 28,2025 |  | June 27,2026 |  | June 28,2025 |
| Net sales |  | $ | 738,781 |  |  | $ | 613,413 |  |  | $ | 1,395,750 |  |  | $ | 1,167,720 |  |
| Cost of sales |  | 432,717 |  |  | 381,359 |  |  | 835,537 |  |  | 728,410 |  |
| Gross profit |  | 306,064 |  |  | 232,054 |  |  | 560,213 |  |  | 439,310 |  |
| Selling, general, and administrative expenses |  | 120,578 |  |  | 95,517 |  |  | 219,903 |  |  | 183,225 |  |
| Research and development expenses |  | 31,037 |  |  | 26,401 |  |  | 60,774 |  |  | 52,449 |  |
| Amortization of intangibles |  | 14,704 |  |  | 14,852 |  |  | 31,204 |  |  | 29,183 |  |
| Restructuring, impairment, and other charges |  | 20,021 |  |  | 2,506 |  |  | 27,443 |  |  | 11,525 |  |
| Total operating expenses |  | 186,340 |  |  | 139,276 |  |  | 339,324 |  |  | 276,382 |  |
| Operating income |  | 119,724 |  |  | 92,778 |  |  | 220,889 |  |  | 162,928 |  |
| Interest expense |  | 5,739 |  |  | 8,568 |  |  | 12,716 |  |  | 17,443 |  |
| Foreign exchange (gain) loss |  | (160) |  |  | 10,448 |  |  | (2,573) |  |  | 15,291 |  |
| Other income, net |  | (2,919) |  |  | (4,452) |  |  | (3,049) |  |  | (7,967) |  |
| Income before income taxes |  | 117,064 |  |  | 78,214 |  |  | 213,795 |  |  | 138,161 |  |
| Income taxes |  | 27,659 |  |  | 20,872 |  |  | 49,243 |  |  | 37,248 |  |
| Net income |  | $ | 89,405 |  |  | $ | 57,342 |  |  | $ | 164,552 |  |  | $ | 100,913 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 3.53 |  |  | $ | 2.32 |  |  | $ | 6.53 |  |  | $ | 4.08 |  |
| Diluted |  | $ | 3.49 |  |  | $ | 2.30 |  |  | $ | 6.44 |  |  | $ | 4.05 |  |
| Weighted-average shares and equivalent shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  | 25,305 |  |  | 24,755 |  |  | 25,190 |  |  | 24,760 |  |
| Diluted |  | 25,620 |  |  | 24,905 |  |  | 25,534 |  |  | 24,938 |  |
| Comprehensive income |  | $ | 83,699 |  |  | $ | 155,255 |  |  | $ | 139,672 |  |  | $ | 236,423 |  |

[0001628280-26-050382:8k_2_02:54]
LITTELFUSE, INC.

[0001628280-26-050382:8k_2_02:55]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001628280-26-050382:8k_2_02:56]
(Unaudited)

[0001628280-26-050382:8k_2_02:57]
|  |  | Six Months Ended |
| (in thousands) |  | June 27, 2026 |  | June 28, 2025 |
| OPERATING ACTIVITIES |  |  |  |  |
| Net income |  | $ | 164,552 |  |  | $ | 100,913 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  | 105,753 |  |  | 86,758 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Trade receivables |  | (65,720) |  |  | (52,635) |  |
| Inventories |  | (21,254) |  |  | 23,316 |  |
| Accounts payable |  | 39,159 |  |  | (7,001) |  |
| Accrued liabilities and income taxes |  | 2,147 |  |  | (14,425) |  |
| Prepaid expenses and other assets |  | 1,837 |  |  | 11,299 |  |
| Net cash provided by operating activities |  | 226,474 |  |  | 148,225 |  |
| INVESTING ACTIVITIES |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  | (2,818) |  |  | (57,417) |  |
| Purchases of property, plant, and equipment |  | (33,021) |  |  | (32,999) |  |
| Net proceeds from sale of property, plant and equipment, and other |  | 9,115 |  |  | 712 |  |
| Net cash used in investing activities |  | (26,724) |  |  | (89,704) |  |
| FINANCING ACTIVITIES |  |  |  |  |
| Net payments of credit facility |  | (166,250) |  |  | (57,500) |  |
| Repurchases of common stock |  | — |  |  | (27,553) |  |
| Cash dividends paid |  | (37,872) |  |  | (34,677) |  |
| All other cash provided by financing activities |  | 72,179 |  |  | (813) |  |
| Net cash used in financing activities |  | (131,943) |  |  | (120,543) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash |  | (3,035) |  |  | 22,468 |  |
| Increase (decrease) in cash, cash equivalents, and restricted cash |  | 64,772 |  |  | (39,554) |  |
| Cash, cash equivalents, and restricted cash at beginning of period |  | 565,104 |  |  | 726,437 |  |
| Cash, cash equivalents, and restricted cash at end of period |  | $ | 629,876 |  |  | $ | 686,883 |  |

[0001628280-26-050382:8k_2_02:58]
LITTELFUSE, INC.

[0001628280-26-050382:8k_2_02:59]
NET SALES AND OPERATING INCOME BY SEGMENT

[0001628280-26-050382:8k_2_02:60]
(Unaudited)

[0001628280-26-050382:8k_2_02:61]
|  |  | Second Quarter |  | Year-to-Date |
| (in thousands) |  | 2026 |  | 2025 |  |  |  | %Growth/Decline |  | 2026 |  | 2025 |  |  |  | %Growth |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 406,420 |  |  | $ | 335,666 |  |  |  |  | 21.1 | % |  | $ | 769,195 |  |  | $ | 642,915 |  |  |  |  | 19.6 | % |
| Transportation |  | 182,411 |  |  | 179,400 |  |  |  |  | 1.7 | % |  | 352,792 |  |  | 341,262 |  |  |  |  | 3.4 | % |
| Industrial |  | 149,950 |  |  | 98,347 |  |  |  |  | 52.5 | % |  | 273,763 |  |  | 183,543 |  |  |  |  | 49.2 | % |
| Total net sales |  | $ | 738,781 |  |  | $ | 613,413 |  |  |  |  | 20.4 | % |  | $ | 1,395,750 |  |  | $ | 1,167,720 |  |  |  |  | 19.5 | % |
| Operating income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 86,916 |  |  | $ | 49,861 |  |  |  |  | 74.3 | % |  | $ | 157,195 |  |  | $ | 96,627 |  |  |  |  | 62.7 | % |
| Transportation |  | 25,691 |  |  | 28,074 |  |  |  |  | (8.5) | % |  | 49,794 |  |  | 46,991 |  |  |  |  | 6.0 | % |
| Industrial |  | 27,474 |  |  | 18,863 |  |  |  |  | 45.7 | % |  | 48,235 |  |  | 31,937 |  |  |  |  | 51.0 | % |
| Other (a) |  | (20,357) |  |  | (4,020) |  |  |  |  | N.M. |  | (34,335) |  |  | (12,627) |  |  |  |  | N.M. |
| Total operating income |  | $ | 119,724 |  |  | $ | 92,778 |  |  |  |  | 29.0 | % |  | $ | 220,889 |  |  | $ | 162,928 |  |  |  |  | 35.6 | % |
| Operating Margin |  | 16.2 | % |  | 15.1 | % |  |  |  |  |  | 15.8 | % |  | 14.0 | % |  |  |  |  |
| Interest expense |  | 5,739 |  |  | 8,568 |  |  |  |  |  |  | 12,716 |  |  | 17,443 |  |  |  |  |  |
| Foreign exchange (gain) loss |  | (160) |  |  | 10,448 |  |  |  |  |  |  | (2,573) |  |  | 15,291 |  |  |  |  |  |
| Other income, net |  | (2,919) |  |  | (4,452) |  |  |  |  |  |  | (3,049) |  |  | (7,967) |  |  |  |  |  |
| Income before income taxes |  | $ | 117,064 |  |  | $ | 78,214 |  |  |  |  | 49.7 | % |  | $ | 213,795 |  |  | $ | 138,161 |  |  |  |  | 54.7 | % |

[0001628280-26-050382:8k_2_02:62]
(a) "Other" typically includes non-GAAP adjustments such as acquisition-related and integration costs, purchase accounting inventory adjustments, and restructuring and impairment charges. See Supplemental Financial Information for details.

[0001628280-26-050382:8k_2_02:63]
N.M. - Not meaningful

[0001628280-26-050382:8k_2_02:64]
|  |  | Second Quarter |  | Year-to-Date |
| (in thousands) |  | 2026 |  | 2025 |  | %Growth/Decline |  | 2026 |  | 2025 |  | %Growth |
| Operating Margin |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | 21.4 | % |  | 14.9 | % |  | 6.5 | % |  | 20.4 | % |  | 15.0 | % |  | 5.4 | % |
| Transportation |  | 14.1 | % |  | 15.6 | % |  | (1.5) | % |  | 14.1 | % |  | 13.8 | % |  | 0.3 | % |
| Industrial |  | 18.3 | % |  | 19.2 | % |  | (0.9) | % |  | 17.6 | % |  | 17.4 | % |  | 0.2 | % |

[0001628280-26-050382:8k_2_02:65]
LITTELFUSE, INC.

[0001628280-26-050382:8k_2_02:66]
SUPPLEMENTAL FINANCIAL INFORMATION

[0001628280-26-050382:8k_2_02:67]
(In millions of USD except per share amounts - unaudited)

[0001628280-26-050382:8k_2_02:68]
| Non-GAAP EPS reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q2-26 |  | Q2-25 |  | YTD-26 |  | YTD-25 |
| GAAP diluted EPS |  | $ | 3.49 |  |  | $ | 2.30 |  |  | $ | 6.44 |  |  | $ | 4.05 |  |
| EPS impact of Non-GAAP adjustments (below) |  | 0.70 |  |  | 0.55 |  |  | 1.06 |  |  | 0.99 |  |
| Adjusted diluted EPS |  | $ | 4.19 |  |  | $ | 2.85 |  |  | $ | 7.50 |  |  | $ | 5.04 |  |

[0001628280-26-050382:8k_2_02:69]
| Non-GAAP adjustments - expense / (income) |  |  |  |  |  |  |  |  |
|  |  | Q2-26 |  | Q2-25 |  | YTD-26 |  | YTD-25 |
| Acquisition-related and integration costs (a) |  | $ | 0.4 |  |  | $ | 1.5 |  |  | $ | 1.5 |  |  | $ | 1.6 |  |
| Purchase accounting inventory adjustments (b) |  | — |  |  | — |  |  | 5.4 |  |  | (0.5) |  |
| Restructuring, impairment and other charges (c) |  | 20.0 |  |  | 2.5 |  |  | 27.4 |  |  | 11.5 |  |
| Non-GAAP adjustments to operating income |  | 20.4 |  |  | 4.0 |  |  | 34.3 |  |  | 12.6 |  |
| Other income, net (d) |  | — |  |  | — |  |  | 2.7 |  |  | — |  |
| Non-operating foreign exchange (gain) loss |  | (0.2) |  |  | 10.4 |  |  | (2.6) |  |  | 15.3 |  |
| Non-GAAP adjustments to income before income taxes |  | 20.2 |  |  | 14.4 |  |  | 34.5 |  |  | 27.9 |  |
| Income taxes (e) |  | 2.4 |  |  | 0.8 |  |  | 7.6 |  |  | 3.2 |  |
| Non-GAAP adjustments to net income |  | $ | 17.8 |  |  | $ | 13.6 |  |  | $ | 26.9 |  |  | $ | 24.7 |  |
| Total EPS impact |  | $ | 0.70 |  |  | $ | 0.55 |  |  | $ | 1.06 |  |  | $ | 0.99 |  |

[0001628280-26-050382:8k_2_02:70]
| Adjusted operating margin / Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q2-26 |  | Q2-25 |  | YTD-26 |  | YTD-25 |
| Net income |  | $ | 89.4 |  |  | $ | 57.3 |  |  | $ | 164.6 |  |  | $ | 100.9 |  |
| Add: |  |  |  |  |  |  |  |  |
| Income taxes |  | 27.7 |  |  | 20.9 |  |  | 49.2 |  |  | 37.2 |  |
| Interest expense |  | 5.7 |  |  | 8.6 |  |  | 12.7 |  |  | 17.4 |  |
| Foreign exchange (gain) loss |  | (0.2) |  |  | 10.4 |  |  | (2.6) |  |  | 15.3 |  |
| Other income, net |  | (2.9) |  |  | (4.5) |  |  | (3.0) |  |  | (8.0) |  |
| GAAP operating income |  | $ | 119.7 |  |  | $ | 92.8 |  |  | $ | 220.9 |  |  | $ | 162.9 |  |
| Non-GAAP adjustments to operating income |  | 20.4 |  |  | 4.0 |  |  | 34.3 |  |  | 12.6 |  |
| Adjusted operating income |  | $ | 140.1 |  |  | $ | 96.8 |  |  | $ | 255.2 |  |  | $ | 175.5 |  |
| Amortization of intangibles |  | 14.7 |  |  | 14.9 |  |  | 31.2 |  |  | 29.2 |  |
| Depreciation expense |  | 19.9 |  |  | 19.4 |  |  | 38.8 |  |  | 37.8 |  |
| Adjusted EBITDA |  | $ | 174.7 |  |  | $ | 131.1 |  |  | $ | 325.2 |  |  | $ | 242.5 |  |
| Net sales |  | $ | 738.8 |  |  | $ | 613.4 |  |  | $ | 1,395.8 |  |  | $ | 1,167.7 |  |
| Net income as a percentage of net sales |  | 12.1 | % |  | 9.3 | % |  | 11.8 | % |  | 8.6 | % |
| Operating margin |  | 16.2 | % |  | 15.1 | % |  | 15.8 | % |  | 14.0 | % |
| Adjusted operating margin |  | 19.0 | % |  | 15.8 | % |  | 18.3 | % |  | 15.0 | % |
| Adjusted EBITDA margin |  | 23.6 | % |  | 21.4 | % |  | 23.3 | % |  | 20.8 | % |

[0001628280-26-050382:8k_2_02:71]
| Adjusted EBITDA by Segment |  | Q2-26 |  | Q2-25 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Electronics |  | Transportation |  | Industrial |
| GAAP operating income |  | $ | 86.9 |  |  | $ | 25.7 |  |  | $ | 27.5 |  |  | $ | 49.9 |  |  | $ | 28.1 |  |  | $ | 18.8 |  |
| Add: |  |  |  |  |  |  |  |  |  |  |  |  |
| Add back amortization |  | 7.6 |  |  | 2.8 |  |  | 4.3 |  |  | 10.1 |  |  | 3.4 |  |  | 1.4 |  |
| Add back depreciation |  | 12.2 |  |  | 5.5 |  |  | 2.2 |  |  | 12.6 |  |  | 5.3 |  |  | 1.5 |  |
| Adjusted EBITDA |  | $ | 106.7 |  |  | $ | 34.0 |  |  | $ | 34.0 |  |  | $ | 72.6 |  |  | $ | 36.8 |  |  | $ | 21.7 |  |
| Adjusted EBITDA Margin |  | 26.3 | % |  | 18.6 | % |  | 22.6 | % |  | 21.6 | % |  | 20.5 | % |  | 22.1 | % |

[0001628280-26-050382:8k_2_02:72]
| Adjusted EBITDA by Segment |  | YTD-26 |  | YTD-25 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Electronics |  | Transportation |  | Industrial |
| GAAP operating income |  | $ | 157.2 |  |  | $ | 49.8 |  |  | $ | 48.2 |  |  | $ | 96.6 |  |  | $ | 47.0 |  |  | $ | 31.9 |  |
| Add: |  |  |  |  |  |  |  |  |  |  |  |  |
| Add back amortization |  | 16.6 |  |  | 6.1 |  |  | 8.5 |  |  | 19.9 |  |  | 6.8 |  |  | 2.5 |  |
| Add back depreciation |  | 24.0 |  |  | 10.5 |  |  | 4.3 |  |  | 24.0 |  |  | 10.8 |  |  | 3.0 |  |
| Adjusted EBITDA |  | $ | 197.8 |  |  | $ | 66.4 |  |  | $ | 61.0 |  |  | $ | 140.5 |  |  | $ | 64.6 |  |  | $ | 37.4 |  |
| Adjusted EBITDA Margin |  | 25.7 | % |  | 18.8 | % |  | 22.3 | % |  | 21.8 | % |  | 18.9 | % |  | 20.4 | % |

[0001628280-26-050382:8k_2_02:73]
| Net sales reconciliation |  | Q2-26 vs. Q2-25 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Net sales growth |  | 21 | % |  | 2 | % |  | 52 | % |  | 20 | % |
| Less: |  |  |  |  |  |  |  |  |
| Acquisitions |  | — | % |  | — | % |  | 36 | % |  | 6 | % |
| FX impact |  | 1 | % |  | 1 | % |  | — | % |  | 1 | % |
| Organic net sales growth |  | 20 | % |  | 1 | % |  | 16 | % |  | 14 | % |

[0001628280-26-050382:8k_2_02:74]
| Electronics segment net sales reconciliation |  | Q2-26 vs. Q2-25 |
|  |  | Electronics - Passive Products and Sensors |  | Electronics - Semiconductor |  | Total Electronics |
| Net sales growth |  | 26 | % |  | 16 | % |  | 21 | % |
| Less: |  |  |  |  |  |  |
| FX impact |  | 1 | % |  | 1 | % |  | 1 | % |
| Organic net sales growth |  | 26 | % |  | 15 | % |  | 20 | % |

[0001628280-26-050382:8k_2_02:75]
| Transportation segment net sales reconciliation |  | Q2-26 vs. Q2-25 |
|  |  | Commercial Vehicle Products |  | Passenger Car Products (1) |  | Auto Sensor Products (1) |  | Total Transportation |
| Net sales growth (decline) |  | 5 | % |  | 1 | % |  | (10) | % |  | 2 | % |
| Less: |  |  |  |  |  |  |  |  |
| FX impact |  | 1 | % |  | 1 | % |  | 2 | % |  | 1 | % |
| Organic net sales growth (decline) |  | 4 | % |  | — | % |  | (12) | % |  | 1 | % |

[0001628280-26-050382:8k_2_02:76]
(1) Passenger vehicle business (PVB) includes passenger car and auto sensor products.

[0001628280-26-050382:8k_2_02:77]
| Net sales reconciliation |  | YTD-26 vs. YTD-25 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Net sales growth |  | 20 | % |  | 3 | % |  | 49 | % |  | 20 | % |
| Less: |  |  |  |  |  |  |  |  |
| Acquisitions |  | — | % |  | — | % |  | 38 | % |  | 6 | % |
| FX impact |  | 2 | % |  | 2 | % |  | — | % |  | 2 | % |
| Organic net sales growth |  | 18 | % |  | 1 | % |  | 11 | % |  | 12 | % |

[0001628280-26-050382:8k_2_02:78]
| Electronics segment net sales reconciliation |  | YTD-26 vs. YTD-25 |
|  |  | Electronics - Passive Products and Sensors |  | Electronics - Semiconductor |  | Total Electronics |
| Net sales growth |  | 26 | % |  | 13 | % |  | 20 | % |
| Less: |  |  |  |  |  |  |
| FX impact |  | 2 | % |  | 2 | % |  | 2 | % |
| Organic net sales growth |  | 24 | % |  | 11 | % |  | 18 | % |

[0001628280-26-050382:8k_2_02:79]
| Transportation segment net sales reconciliation |  | YTD-26 vs. YTD-25 |
|  |  | Commercial Vehicle Products |  | Passenger Car Products (1) |  | Auto Sensor Products (1) |  | Total Transportation |
| Net sales growth (decline) |  | 3 | % |  | 5 | % |  | (5) | % |  | 3 | % |
| Less: |  |  |  |  |  |  |  |  |
| FX impact |  | 2 | % |  | 2 | % |  | 5 | % |  | 2 | % |
| Organic net sales growth (decline) |  | 2 | % |  | 3 | % |  | (10) | % |  | 1 | % |

[0001628280-26-050382:8k_2_02:80]
(1) Passenger vehicle business (PVB) includes passenger car and auto sensor products.

[0001628280-26-050382:8k_2_02:81]
| Income tax reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q2-26 |  | Q2-25 |  | YTD-26 |  | YTD-25 |
| Income taxes |  | $ | 27.7 |  |  | $ | 20.9 |  |  | $ | 49.2 |  |  | $ | 37.2 |  |
| Effective rate |  | 23.6 | % |  | 26.7 | % |  | 23.0 | % |  | 27.0 | % |
| Non-GAAP adjustments - income taxes |  | 2.4 |  |  | 0.8 |  |  | 7.6 |  |  | 3.2 |  |
| Adjusted income taxes |  | $ | 30.1 |  |  | $ | 21.7 |  |  | $ | 56.9 |  |  | $ | 40.4 |  |
| Adjusted effective rate |  | 21.9 | % |  | 23.4 | % |  | 22.9 | % |  | 24.4 | % |
| Free cash flow reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q2-26 |  | Q2-25 |  | YTD-26 |  | YTD-25 |
| Net cash provided by operating activities |  | $ | 146.2 |  |  | $ | 82.5 |  |  | $ | 226.5 |  |  | $ | 148.2 |  |
| Less: Purchases of property, plant, and equipment |  | (18.9) |  |  | (9.9) |  |  | (33.0) |  |  | (33.0) |  |
| Free cash flow |  | $ | 127.3 |  |  | $ | 72.6 |  |  | $ | 193.5 |  |  | $ | 115.2 |  |

[0001628280-26-050382:8k_2_02:82]
| Consolidated Total Debt |  | As of June 27, 2026 |
| Consolidated total debt |  | $ | 629.7 |  |
| Unamortized debt issuance costs |  | 3.3 |  |
| Finance lease liability |  | 0.1 |  |
| Consolidated funded indebtedness |  | 633.1 |  |
| Cash held in U.S. (up to $400 million) |  | 139.3 |
| Net debt |  | $ | 493.8 |  |
| Consolidated EBITDA |  | Twelve Months Ended June 27, 2026 |
| Net Loss |  | $ | (8.2) |  |
| Interest expense |  | 29.6 |  |
| Income taxes |  | 87.3 |  |
| Depreciation expense |  | 75.9 |  |
| Amortization expense |  | 61.8 |  |
| Non-cash additions: |  |  |
| Stock-based compensation expense |  | 28.8 |  |
| Purchase accounting inventory step-up charge |  | 6.4 |  |
| Unrealized loss on investments |  | 1.7 |  |
| Impairment charges |  | 315.1 |  |
| Other |  | 25.5 |  |
| Consolidated EBITDA (1) |  | $ | 623.9 |  |
| Consolidated Net Leverage Ratio (as defined in the Credit Agreement) * |  | 0.8x |

[0001628280-26-050382:8k_2_02:83]
* Our Credit Agreement and Private Placement Note with maturities ranging from 2027 to 2031, contain financial ratio covenants providing that if, as of the last day of each fiscal quarter, the Consolidated Net Leverage ratio at such time for the then most recently concluded period of four consecutive fiscal quarters of the Company exceeds 3.50:1.00, an Event of Default (as defined in the Credit Agreement and Private Placement Senior Notes) is triggered.

[0001628280-26-050382:8k_2_02:84]
The Credit Agreement was amended in Q1 2026 and now allows to add restructuring charges and business optimization expenses in addition to the prior credit agreement.

[0001628280-26-050382:8k_2_02:85]
(1) Represents Consolidated EBITDA as defined in our Credit Agreement and Private Placement Senior Notes and is calculated using the most recently concluded period of four consecutive quarters.

[0001628280-26-050382:8k_2_02:86]
Note: Total will not always foot due to rounding.

[0001628280-26-050382:8k_2_02:87]
(a) Reflected in selling, general and administrative expenses ("SG&A").

[0001628280-26-050382:8k_2_02:88]
(b) Reflected in cost of sales.

[0001628280-26-050382:8k_2_02:89]
(c) Reflected in restructuring, impairment and other charges.

[0001628280-26-050382:8k_2_02:90]
(d) 2026 included the reversal of an indemnification receivable of $2.7 million related to lapses in the statute of limitations for previously unrecognized tax benefits recognized in the first quarter of 2026.

[0001628280-26-050382:8k_2_02:91]
(e) Reflected the tax impact associated with the non-GAAP adjustments including $2.7 million of tax benefits due to lapses in the statute of limitations for previously unrecognized tax benefits recognized in the first quarter of 2026.

[0001628280-26-050382:8k_2_02:92]
###
