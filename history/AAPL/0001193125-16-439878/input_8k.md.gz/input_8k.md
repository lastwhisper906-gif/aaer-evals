# AAPL 8-K — 0001193125-16-438421 filed 2016-01-26

## item codes, every 8-K on or before 2016-01-27

- 2016-01-26 0001193125-16-438421 — 2.02, 9.01
- 2015-12-22 0001193125-15-410853 — 5.03, 9.01
- 2015-12-17 0001193125-15-406279 — 5.02
- 2015-10-27 0001193125-15-354756 — 2.02, 9.01
- 2015-10-02 0001193125-15-336615 — 5.02
- 2015-09-17 0001193125-15-322466 — 8.01, 9.01
- 2015-07-31 0001193125-15-273023 — 8.01, 9.01
- 2015-07-21 0001193125-15-258464 — 2.02, 9.01
- 2015-06-10 0001193125-15-219298 — 8.01, 9.01
- 2015-05-13 0001193125-15-186064 — 8.01, 9.01
- 2015-04-27 0001193125-15-149607 — 7.01, 9.01
- 2015-04-27 0001193125-15-149590 — 2.02, 9.01
- 2015-03-13 0001104659-15-019336 — 5.07, 9.01
- 2015-02-09 0001193125-15-039270 — 8.01, 9.01
- 2015-01-28 0001193125-15-023732 — 8.01, 9.01
- 2015-01-27 0001193125-15-021857 — 2.02, 9.01
- 2014-11-10 0001193125-14-406296 — 8.01, 9.01
- 2014-10-20 0001193125-14-376361 — 2.02, 9.01
- 2014-07-23 0001193125-14-277193 — 8.01, 9.01
- 2014-07-22 0001193125-14-275598 — 2.02, 9.01
- 2014-07-17 0001193125-14-271698 — 5.02
- 2014-06-06 0001193125-14-228798 — 5.03, 9.01
- 2014-05-30 0001181431-14-021923 — 5.02
- 2014-05-06 0001193125-14-184969 — 8.01, 9.01
- 2014-04-23 0001193125-14-154883 — 7.01, 9.01
- 2014-04-23 0001193125-14-154871 — 2.02, 9.01
- 2014-03-05 0001193125-14-084697 — 5.02, 5.03, 5.07, 9.01
- 2014-01-27 0001193125-14-022238 — 2.02, 9.01
- 2013-10-28 0001193125-13-413498 — 2.02, 9.01
- 2013-09-23 0001181431-13-050140 — 8.01
- 2013-07-30 0001181431-13-041847 — 5.02
- 2013-07-23 0001193125-13-298914 — 2.02, 9.01
- 2013-06-21 0001193125-13-267629 — 5.02
- 2013-05-03 0001193125-13-199324 — 8.01, 9.01
- 2013-04-24 0001193125-13-170623 — 8.01, 9.01
- 2013-04-23 0001193125-13-167469 — 7.01, 9.01
- 2013-04-23 0001193125-13-167458 — 2.02, 9.01
- 2013-03-01 0001193125-13-085842 — 5.07
- 2013-01-23 0001193125-13-020783 — 2.02, 9.01
- 2012-10-25 0001193125-12-435506 — 2.02, 9.01
- 2012-07-24 0001193125-12-312355 — 2.02, 9.01
- 2012-06-28 0001181431-12-038301 — 5.02
- 2012-05-24 0001181431-12-032458 — 5.02
- 2012-04-24 0001193125-12-178928 — 2.02, 9.01
- 2012-02-27 0001193125-12-081892 — 5.07
- 2012-01-24 0001193125-12-021833 — 2.02, 9.01
- 2011-11-16 0001181431-11-056354 — 5.02
- 2011-10-18 0001193125-11-273826 — 2.02, 9.01
- 2011-10-06 0001181431-11-051976 — 8.01
- 2011-08-26 0001181431-11-047179 — 5.02
- 2011-07-19 0001193125-11-191368 — 2.02, 9.01
- 2011-06-15 0001181431-11-036782 — 5.02
- 2011-04-20 0001193125-11-103732 — 2.02, 9.01
- 2011-02-24 0001193125-11-045411 — 5.07
- 2011-01-18 0001193125-11-009392 — 2.02, 9.01
- 2011-01-18 0001181431-11-003847 — 5.02
- 2010-11-17 0001181431-10-056327 — 5.02, 5.03, 9.01
- 2010-10-18 0001193125-10-230992 — 2.02, 9.01
- 2010-07-20 0001193125-10-161807 — 2.02, 9.01
- 2010-04-20 0001193125-10-087786 — 2.02, 9.01
- 2010-03-12 0001181431-10-016054 — 5.02
- 2010-03-01 0001193125-10-044765 — 5.02, 5.07, 9.01
- 2010-01-25 0001193125-10-012096 — 2.02, 9.01
- 2009-10-19 0001193125-09-209633 — 2.02, 9.01
- 2009-08-04 0001181431-09-037492 — 5.02
- 2009-07-21 0001193125-09-152290 — 2.02, 9.01
- 2009-06-02 0001181431-09-028400 — 5.03
- 2009-04-22 0001193125-09-084599 — 2.02, 9.01
- 2009-02-27 0001181431-09-012161 — 4.01
- 2009-01-21 0001193125-09-009009 — 2.02, 9.01
- 2009-01-16 0001181431-09-003017 — 5.02
- 2008-10-21 0001193125-08-213642 — 2.02, 9.01
- 2008-08-26 0001181431-08-050059 — 5.03
- 2008-07-21 0001193125-08-154381 — 2.02, 9.01
- 2008-06-09 0001181431-08-037620 — 8.01
- 2008-04-23 0001193125-08-088001 — 2.02, 9.01
- 2008-01-22 0001193125-08-009715 — 2.02, 9.01
- 2008-01-15 0001181431-08-003342 — 2.02, 8.01
- 2008-01-08 0001181431-08-002372 — 5.02
- 2007-10-22 0001104659-07-076142 — 2.02, 9.01
- 2007-07-25 0001104659-07-056111 — 2.02, 9.01
- 2007-05-16 0001104659-07-040672 — 5.02, 9.01
- 2007-04-25 0001104659-07-031354 — 2.02, 9.01
- 2007-04-24 0001104659-07-030938 — 8.01, 9.01
- 2007-02-21 0001104659-07-012760 — 5.03, 9.01
- 2007-01-17 0001104659-07-002905 — 2.02, 9.01
- 2007-01-10 0001104659-07-001648 — 5.03, 9.01
- 2006-10-27 0001104659-06-069015 — 8.01
- 2006-10-18 0001104659-06-067275 — 2.02, 9.01
- 2006-10-04 0001104659-06-064935 — 5.02, 8.01, 9.01
- 2006-09-01 0001104659-06-058808 — 1.01, 5.02, 5.03, 9.01
- 2006-08-11 0001104659-06-054118 — 2.02, 3.01, 9.01
- 2006-08-04 0001104659-06-051302 — 2.02, 4.02, 9.01
- 2006-07-19 0001104659-06-047739 — 2.02, 9.01
- 2006-04-21 0001181431-06-024759 — 1.01
- 2006-04-19 0001104659-06-025992 — 2.02, 9.01
- 2006-01-18 0001104659-06-002690 — 2.02, 9.01
- 2006-01-10 0001104659-06-001428 — 2.02
- 2005-12-19 0001181431-05-067468 — 1.01
- 2005-10-14 0001181431-05-056604 — 5.02
- 2005-10-11 0001104659-05-048094 — 2.02, 9.01
- 2005-08-26 0001181431-05-049163 — 1.01
- 2005-08-15 0001181431-05-046871 — 1.01
- 2005-07-13 0001104659-05-032297 — 2.02, 9.01
- 2005-06-06 0001181431-05-033177 — 8.01
- 2005-04-26 0001181431-05-023450 — 1.01
- 2005-04-13 0001104659-05-016307 — 2.02, 9.01
- 2005-03-02 0001181431-05-013840 — 3.03, 5.03
- 2005-02-11 0001104659-05-005507 — 8.01
- 2005-01-12 0001104659-05-001183 — 2.02, 9.01
- 2005-01-11 0001104659-05-001049 — 2.02
- 2004-10-13 0001104659-04-030400 — 2.02, 9.01
- 2004-07-14 0001104659-04-019574 — 12, 7
- 2004-04-14 0001104659-04-010122 — 12, 7
- 2004-01-14 0001104659-04-000896 — 12, 7
- 2003-10-15 0001104659-03-022879 — 12, 7
- 2003-07-16 0001104659-03-014913 — 7, 9
- 2003-04-16 0001047469-03-013617 — 7, 9
- 2003-03-21 0001104659-03-004649 — 5, 7
- 2002-08-13 0000912057-02-031595 — 5, 7
- 2002-08-05 0000912057-02-029692 — 5, 7
- 2000-01-24 0000912057-00-002128 — 5, 7
- 1999-09-07 0000320193-99-000010 — 2
- 1999-07-16 0000320193-99-000007 — 2
- 1998-12-23 0000320193-98-000010 — 1
- 1998-01-08 0000320193-98-000001 — 2
- 1997-09-25 0000320193-97-000019 — 2
- 1997-09-25 0000320193-97-000018 — 2
- 1997-09-05 0000320193-97-000016 — 2
- 1997-07-28 0000320193-97-000012 — 4
- 1997-04-25 0000320193-97-000009 — 5
- 1997-04-10 0000320193-97-000007 — 7
- 1996-12-24 0000320193-96-000027 — 7
- 1996-12-23 0000320193-96-000025 — 4 — amendment of 0000320193-96-000021
- 1996-12-13 0000320193-96-000021 — 4
- 1996-10-28 0000912057-96-023874 — 5, 7
- 1996-06-17 0000320193-96-000014 — 1
- 1996-04-12 0000320193-96-000006 — 1

## late-filing notifications on or before 2016-01-27

- 2006-12-15 0001104659-06-081617 — NT 10-K, for the period ended 2006-09-30
- 2006-08-11 0001104659-06-053743 — NT 10-Q, for the period ended 2006-07-01

## item 2.02 — earnings release, exhibit 99.1

[0001193125-16-438421:8k_2_02:1]
EX-99.1
2
d22806dex991.htm
EX-99.1

[0001193125-16-438421:8k_2_02:2]
EX-99.1

[0001193125-16-438421:8k_2_02:3]
Exhibit 99.1

[0001193125-16-438421:8k_2_02:4]
Apple Reports Record First Quarter Results

[0001193125-16-438421:8k_2_02:5]
iPhone, Apple Watch,
Services & Apple TV Drive All-time Record Revenue

[0001193125-16-438421:8k_2_02:6]
Results Produce Record Quarterly Profit of $18.4 Billion

[0001193125-16-438421:8k_2_02:7]
CUPERTINO, California — January 26, 2016 — Apple® today announced financial
results for its fiscal 2016 first quarter ended December 26, 2015. The Company posted record quarterly revenue of $75.9 billion and record quarterly net income of $18.4 billion, or $3.28 per diluted share. These results compare to revenue of
$74.6 billion and net income of $18 billion, or $3.06 per diluted share, in the year-ago quarter. Gross margin was 40.1 percent compared to 39.9 percent in the year-ago quarter. International sales accounted for 66 percent of the quarter’s
revenue.

[0001193125-16-438421:8k_2_02:8]
“Our team delivered Apple’s biggest quarter ever, thanks to the world’s most innovative products and all-time record sales
of iPhone, Apple Watch and Apple TV,” said Tim Cook, Apple’s CEO. “The growth of our Services business accelerated during the quarter to produce record results, and our installed base recently crossed a major milestone of one billion
active devices.”

[0001193125-16-438421:8k_2_02:9]
“Our record sales and strong margins drove all-time records for net income and EPS in spite of a very difficult
macroeconomic environment,” said Luca Maestri, Apple’s CFO. “We generated operating cash flow of $27.5 billion during the quarter, and returned over $9 billion to investors through share repurchases and dividends. We have now
completed $153 billion of our $200 billion capital return program.”

[0001193125-16-438421:8k_2_02:10]
Apple is providing the following guidance for its fiscal 2016 second
quarter:

[0001193125-16-438421:8k_2_02:11]
| • |  | revenue between $50 billion and $53 billion |

[0001193125-16-438421:8k_2_02:12]
| • |  | gross margin between 39 percent and 39.5 percent |

[0001193125-16-438421:8k_2_02:13]
| • |  | operating expenses between $6 billion and $6.1 billion |

[0001193125-16-438421:8k_2_02:14]
| • |  | other income/(expense) of $325 million |

[0001193125-16-438421:8k_2_02:15]
| • |  | tax rate of 25.5 percent |

[0001193125-16-438421:8k_2_02:16]
Apple’s
board of directors has declared a cash dividend of $.52 per share of the Company’s common stock. The dividend is payable on February 11, 2016, to shareholders of record as of the close of business on February 8, 2016.

[0001193125-16-438421:8k_2_02:17]
Apple will provide live streaming of its Q1 2016 financial results conference call beginning at 2:00 p.m. PST on January 26, 2016 at
www.apple.com/investor/earnings-call/. This webcast will also be available for replay for approximately two weeks thereafter.

[0001193125-16-438421:8k_2_02:18]
Q1’16
 Earnings Supplemental Material

[0001193125-16-438421:8k_2_02:19]
Apple revolutionized personal technology with the introduction of the Macintosh in 1984.
Today, Apple leads the world in innovation with iPhone, iPad, Mac, Apple Watch and Apple TV. Apple’s four software platforms — iOS, OS X, watchOS and tvOS — provide seamless experiences across all Apple devices and empower people with
breakthrough services including the App Store, Apple Music, Apple Pay and iCloud. Apple’s 100,000 employees are dedicated to making the best products on earth, and to leaving the world better than we found it.

[0001193125-16-438421:8k_2_02:20]
Press Contact:

[0001193125-16-438421:8k_2_02:21]
Kristin Huguet

[0001193125-16-438421:8k_2_02:22]
Apple

[0001193125-16-438421:8k_2_02:23]
khuguet@apple.com

[0001193125-16-438421:8k_2_02:24]
(408) 974-2414

[0001193125-16-438421:8k_2_02:25]
Investor Relations Contacts:

[0001193125-16-438421:8k_2_02:26]
Nancy Paxton

[0001193125-16-438421:8k_2_02:27]
Apple

[0001193125-16-438421:8k_2_02:28]
paxton1@apple.com

[0001193125-16-438421:8k_2_02:29]
(408) 974-5420

[0001193125-16-438421:8k_2_02:30]
Joan Hoover

[0001193125-16-438421:8k_2_02:31]
Apple

[0001193125-16-438421:8k_2_02:32]
hoover1@apple.com

[0001193125-16-438421:8k_2_02:33]
(408) 974-4570

[0001193125-16-438421:8k_2_02:34]
NOTE TO EDITORS: For additional information visit Apple’s PR website (www.apple.com/pr), or call Apple’s Media Helpline at
(408) 974-2042.

[0001193125-16-438421:8k_2_02:35]
© 2016 Apple Inc. All rights reserved. Apple and the Apple logo are trademarks of Apple. Other company and product names
may be trademarks of their respective owners.

[0001193125-16-438421:8k_2_02:36]
Apple Inc.

[0001193125-16-438421:8k_2_02:37]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-16-438421:8k_2_02:38]
(In millions, except number of shares which are reflected in thousands and per share amounts)

[0001193125-16-438421:8k_2_02:39]
|  |  | Three Months Ended |  |
|  |  | December 26,2015 |  |  | December 27,2014 |  |
| Net sales |  | $ | 75,872 |  |  | $ | 74,599 |  |
| Cost of sales (1) |  |  | 45,449 |  |  |  | 44,858 |  |
| Gross margin |  |  | 30,423 |  |  |  | 29,741 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development (1) |  |  | 2,404 |  |  |  | 1,895 |  |
| Selling, general and administrative (1) |  |  | 3,848 |  |  |  | 3,600 |  |
| Total operating expenses |  |  | 6,252 |  |  |  | 5,495 |  |
| Operating income |  |  | 24,171 |  |  |  | 24,246 |  |
| Other income/(expense), net |  |  | 402 |  |  |  | 170 |  |
| Income before provision for income taxes |  |  | 24,573 |  |  |  | 24,416 |  |
| Provision for income taxes |  |  | 6,212 |  |  |  | 6,392 |  |
| Net income |  | $ | 18,361 |  |  | $ | 18,024 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 3.30 |  |  | $ | 3.08 |  |
| Diluted |  | $ | 3.28 |  |  | $ | 3.06 |  |
| Shares used in computing earnings per share: |  |  |  |  |  |  |  |  |
| Basic |  |  | 5,558,930 |  |  |  | 5,843,082 |  |
| Diluted |  |  | 5,594,127 |  |  |  | 5,881,803 |  |
| Cash dividends declared per share |  | $ | 0.52 |  |  | $ | 0.47 |  |
| (1) Includes share-based compensation expense as follows: |  |  |  |  |  |  |  |  |
| Cost of sales |  | $ | 204 |  |  | $ | 140 |  |
| Research and development |  | $ | 466 |  |  | $ | 374 |  |
| Selling, general and administrative |  | $ | 408 |  |  | $ | 374 |  |

[0001193125-16-438421:8k_2_02:40]
Apple Inc.

[0001193125-16-438421:8k_2_02:41]
UNAUDITED CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-16-438421:8k_2_02:42]
(In millions, except number of shares which are reflected in thousands and par value)

[0001193125-16-438421:8k_2_02:43]
|  |  | December 26,2015 |  |  | September 26,2015 |  |
| ASSETS: |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 16,689 |  |  | $ | 21,120 |  |
| Short-term marketable securities |  |  | 21,385 |  |  |  | 20,481 |  |
| Accounts receivable, less allowances of $63 in each period |  |  | 12,953 |  |  |  | 16,849 |  |
| Inventories |  |  | 2,451 |  |  |  | 2,349 |  |
| Vendor non-trade receivables |  |  | 11,668 |  |  |  | 13,494 |  |
| Other current assets |  |  | 11,073 |  |  |  | 15,085 |  |
| Total current assets |  |  | 76,219 |  |  |  | 89,378 |  |
| Long-term marketable securities |  |  | 177,665 |  |  |  | 164,065 |  |
| Property, plant and equipment, net |  |  | 22,300 |  |  |  | 22,471 |  |
| Goodwill |  |  | 5,202 |  |  |  | 5,116 |  |
| Acquired intangible assets, net |  |  | 3,924 |  |  |  | 3,893 |  |
| Other non-current assets |  |  | 7,974 |  |  |  | 5,556 |  |
| Total assets |  | $ | 293,284 |  |  | $ | 290,479 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY: |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 33,312 |  |  | $ | 35,490 |  |
| Accrued expenses |  |  | 24,032 |  |  |  | 25,181 |  |
| Deferred revenue |  |  | 8,989 |  |  |  | 8,940 |  |
| Commercial paper |  |  | 7,259 |  |  |  | 8,499 |  |
| Current portion of long-term debt |  |  | 2,500 |  |  |  | 2,500 |  |
| Total current liabilities |  |  | 76,092 |  |  |  | 80,610 |  |
| Deferred revenue, non-current |  |  | 3,546 |  |  |  | 3,624 |  |
| Long-term debt |  |  | 53,204 |  |  |  | 53,463 |  |
| Other non-current liabilities |  |  | 32,175 |  |  |  | 33,427 |  |
| Total liabilities |  |  | 165,017 |  |  |  | 171,124 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Shareholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock and additional paid-in capital, $0.00001 par value: 12,600,000 shares authorized; 5,544,487 and 5,578,753 shares issued and outstanding, respectively |  |  | 28,253 |  |  |  | 27,416 |  |
| Retained earnings |  |  | 101,494 |  |  |  | 92,284 |  |
| Accumulated other comprehensive income/(loss) |  |  | (1,480 | ) |  |  | (345 | ) |
| Total shareholders’ equity |  |  | 128,267 |  |  |  | 119,355 |  |
| Total liabilities and shareholders’ equity |  | $ | 293,284 |  |  | $ | 290,479 |  |

[0001193125-16-438421:8k_2_02:44]
Apple Inc.

[0001193125-16-438421:8k_2_02:45]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-16-438421:8k_2_02:46]
(In millions)

[0001193125-16-438421:8k_2_02:47]
|  |  | Three Months Ended |  |
|  |  | December 26,2015 |  |  | December 27,2014 |  |
| Cash and cash equivalents, beginning of the period |  | $ | 21,120 |  |  | $ | 13,844 |  |
| Operating activities: |  |  |  |  |
| Net income |  |  | 18,361 |  |  |  | 18,024 |  |
| Adjustments to reconcile net income to cash generated by operating activities: |  |  |  |  |
| Depreciation and amortization |  |  | 2,954 |  |  |  | 2,575 |  |
| Share-based compensation expense |  |  | 1,078 |  |  |  | 888 |  |
| Deferred income tax expense |  |  | 1,592 |  |  |  | 2,197 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  |  | 3,896 |  |  |  | 751 |  |
| Inventories |  |  | (102 | ) |  |  | (172 | ) |
| Vendor non-trade receivables |  |  | 1,826 |  |  |  | (3,508 | ) |
| Other current and non-current assets |  |  | (893 | ) |  |  | (1,648 | ) |
| Accounts payable |  |  | (852 | ) |  |  | 9,003 |  |
| Deferred revenue |  |  | (29 | ) |  |  | 945 |  |
| Other current and non-current liabilities |  |  | (368 | ) |  |  | 4,667 |  |
| Cash generated by operating activities |  |  | 27,463 |  |  |  | 33,722 |  |
| Investing activities: |  |  |  |  |
| Purchases of marketable securities |  |  | (47,836 | ) |  |  | (44,915 | ) |
| Proceeds from maturities of marketable securities |  |  | 3,514 |  |  |  | 2,807 |  |
| Proceeds from sales of marketable securities |  |  | 28,262 |  |  |  | 24,166 |  |
| Payments made in connection with business acquisitions, net |  |  | (86 | ) |  |  | (23 | ) |
| Payments for acquisition of property, plant and equipment |  |  | (3,612 | ) |  |  | (3,217 | ) |
| Payments for acquisition of intangible assets |  |  | (394 | ) |  |  | (48 | ) |
| Other |  |  | (298 | ) |  |  | 65 |  |
| Cash used in investing activities |  |  | (20,450 | ) |  |  | (21,165 | ) |
| Financing activities: |  |  |  |  |
| Proceeds from issuance of common stock |  |  | 1 |  |  |  | 80 |  |
| Excess tax benefits from equity awards |  |  | 224 |  |  |  | 264 |  |
| Payments for taxes related to net share settlement of equity awards |  |  | (597 | ) |  |  | (512 | ) |
| Payments for dividends and dividend equivalents |  |  | (2,969 | ) |  |  | (2,801 | ) |
| Repurchase of common stock |  |  | (6,863 | ) |  |  | (5,030 | ) |
| Proceeds from issuance of term debt, net |  |  | 0 |  |  |  | 3,485 |  |
| Change in commercial paper, net |  |  | (1,240 | ) |  |  | (2,409 | ) |
| Cash used in financing activities |  |  | (11,444 | ) |  |  | (6,923 | ) |
| Increase/(decrease) in cash and cash equivalents |  |  | (4,431 | ) |  |  | 5,634 |  |
| Cash and cash equivalents, end of the period |  | $ | 16,689 |  |  | $ | 19,478 |  |
| Supplemental cash flow disclosure: |  |  |  |  |
| Cash paid for income taxes, net |  | $ | 3,398 |  |  | $ | 3,869 |  |
| Cash paid for interest |  | $ | 396 |  |  | $ | 202 |  |
