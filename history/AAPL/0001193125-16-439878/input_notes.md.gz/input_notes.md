# AAPL notes — 0001193125-16-439878


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-16-439878:notes:1]
Note 4 – Acquired Intangible Assets

[0001193125-16-439878:notes:2]
The Company’s acquired intangible assets
 with definite useful lives primarily consist of patents and
 licenses and are amortized over periods typically from three to
 seven years. The following table summarizes the components of gross
 and net acquired intangible asset balances as of December 26,
 2015 and September 26, 2015 (in millions):

[0001193125-16-439878:notes:3]
|  |  | December 26, 2015 |  |  | September 26, 2015 |  |
|  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Carrying Amount |  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Carrying Amount |  |
| Definite-lived and amortizable acquired intangible assets |  | $ | 8,490 |  |  | $ | (4,666 | ) |  | $ | 3,824 |  |  | $ | 8,125 |  |  | $ | (4,332 | ) |  | $ | 3,793 |  |
| Indefinite-lived and non-amortizable acquired intangible assets |  |  | 100 |  |  |  | 0 |  |  |  | 100 |  |  |  | 100 |  |  |  | 0 |  |  |  | 100 |  |
| Total acquired intangible assets |  | $ | 8,590 |  |  | $ | (4,666 | ) |  | $ | 3,924 |  |  | $ | 8,225 |  |  | $ | (4,332 | ) |  | $ | 3,893 |  |


## us-gaap:ScheduleOfDerivativeInstrumentsInStatementOfFinancialPositionFairValueTextBlock

[0001193125-16-439878:notes:4]
The following tables show the Company’s
 derivative instruments at gross fair value as of December 26,
 2015 and September 26, 2015 (in millions):

[0001193125-16-439878:notes:5]
|  |  | December 26, 2015 |  |
|  |  | Fair Value of Derivatives Designated as Hedge Instruments |  |  | Fair Value of Derivatives Not Designated as Hedge Instruments |  |  | Total Fair Value |  |
| Derivative assets (1): |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 1,021 |  |  | $ | 275 |  |  | $ | 1,296 |  |
| Interest rate contracts |  | $ | 313 |  |  | $ | 0 |  |  | $ | 313 |  |
| Derivative liabilities (2): |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 877 |  |  | $ | 157 |  |  | $ | 1,034 |  |
| Interest rate contracts |  | $ | 30 |  |  | $ | 0 |  |  | $ | 30 |  |

[0001193125-16-439878:notes:6]
|  |  | September 26, 2015 |  |
|  |  | Fair Value of Derivatives Designated as Hedge Instruments |  |  | Fair Value of Derivatives Not Designated as Hedge Instruments |  |  | Total Fair Value |  |
| Derivative assets (1): |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 1,442 |  |  | $ | 109 |  |  | $ | 1,551 |  |
| Interest rate contracts |  | $ | 394 |  |  | $ | 0 |  |  | $ | 394 |  |
| Derivative liabilities (2): |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 905 |  |  | $ | 94 |  |  | $ | 999 |  |
| Interest rate contracts |  | $ | 13 |  |  | $ | 0 |  |  | $ | 13 |  |

[0001193125-16-439878:notes:7]
[same as prior period, unchanged from 0001193125-15-259935:notes:3]

[0001193125-16-439878:notes:8]
[same as prior period, unchanged from 0001193125-15-259935:notes:4]


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001193125-16-439878:notes:9]
A reconciliation of the Company’s segment
 operating income to the Condensed Consolidated Statements of
 Operations for the three months ended December 26, 2015 and
 December 27, 2014 (in millions):

[0001193125-16-439878:notes:10]
|  |  | Three Months Ended |  |
|  |  | December 26, 2015 |  |  | December 27, 2014 |  |
| Segment operating income |  | $ | 27,645 |  |  | $ | 27,286 |  |
| Research and development expense |  |  | (2,404 | ) |  |  | (1,895 | ) |
| Other corporate expenses, net |  |  | (1,070 | ) |  |  | (1,145 | ) |
| Total operating income |  | $ | 24,171 |  |  | $ | 24,246 |  |


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001193125-16-439878:notes:11]
The following table shows the computation of basic
 and diluted earnings per share for the three months ended
 December 26, 2015 and December 27, 2014 (net income in
 millions and shares in thousands):

[0001193125-16-439878:notes:12]
|  |  | Three Months Ended |  |
|  |  | December 26, 2015 |  |  | December 27, 2014 |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 18,361 |  |  | $ | 18,024 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding |  |  | 5,558,930 |  |  |  | 5,843,082 |  |
| Effect of dilutive securities |  |  | 35,197 |  |  |  | 38,721 |  |
| Weighted-average diluted shares |  |  | 5,594,127 |  |  |  | 5,881,803 |  |
| Basic earnings per share |  | $ | 3.30 |  |  | $ | 3.08 |  |
| Diluted earnings per share |  | $ | 3.28 |  |  | $ | 3.06 |  |


## us-gaap:DebtDisclosureTextBlock

[0001193125-16-439878:notes:13]
Note 6 – Debt

[0001193125-16-439878:notes:14]
Commercial Paper

[0001193125-16-439878:notes:15]
The Company issues unsecured short-term promissory
 notes (“Commercial Paper”) pursuant to a commercial
 paper program. The Company uses net proceeds from the commercial
 paper program for general corporate purposes, including dividends
 and share repurchases. As of December 26, 2015 and
 September 26, 2015, the Company had $7.3 billion and $8.5
 billion of Commercial Paper outstanding, respectively, with
 maturities generally less than nine months. The weighted-average
 interest rate of the Company’s Commercial Paper was 0.20% as
 of December 26, 2015 and 0.14% as of September 26,
 2015.

[0001193125-16-439878:notes:16]
The following table provides a summary of cash
 flows associated with the issuance and maturities of Commercial
 Paper for the three months ended December 26, 2015 and
 December 27, 2014 (in millions):

[0001193125-16-439878:notes:17]
|  |  | Three Months Ended |  |
|  |  | December 26, 2015 |  |  | December 27, 2014 |  |
| Maturities less than 90 days: |  |  |  |  |  |  |  |  |
| Proceeds from (repayments of) commercial paper, net |  | $ | (393 | ) |  | $ | 62 |  |
| Maturities greater than 90 days: |  |  |  |  |  |  |  |  |
| Proceeds from commercial paper |  |  | 492 |  |  |  | 197 |  |
| Repayments of commercial paper |  |  | (1,339 | ) |  |  | (2,668 | ) |
| Proceeds from (repayments of) commercial paper, net |  |  | (847 | ) |  |  | (2,471 | ) |
| Total change in commercial paper, net |  | $ | (1,240 | ) |  | $ | (2,409 | ) |

[0001193125-16-439878:notes:18]
Long-Term Debt

[0001193125-16-439878:notes:19]
As of December 26, 2015, the Company had
 outstanding floating- and fixed-rate notes with varying maturities
 for an aggregate principal amount of $55.5 billion (collectively
 the “Notes”). The Notes are senior unsecured
 obligations, and interest is payable in arrears, quarterly for the
 U.S. dollar-denominated and Australian dollar-denominated
 floating-rate notes, semi-annually for the U.S. dollar-denominated,
 Australian dollar-denominated, British pound-denominated and
 Japanese yen-denominated fixed-rate notes and annually for the
 euro-denominated and Swiss franc-denominated fixed-rate notes. The
 following table provides a summary of the Company’s term debt
 as of December 26, 2015 and September 26, 2015:

[0001193125-16-439878:notes:20]
|  |  | Maturities |  |  | December, 26, 2015 |  |  | September 26, 2015 |  |
|  |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2016 - 2018 |  |  | $ | 3,000 |  |  |  | 0.51% - 1.10% |  |  | $ | 3,000 |  |  |  | 0.51% - 1.10% |  |
| Fixed-rate 0.45% - 3.85% notes |  |  | 2016 - 2043 |  |  |  | 14,000 |  |  |  | 0.51% - 3.91% |  |  |  | 14,000 |  |  |  | 0.51% - 3.91% |  |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2017 - 2019 |  |  |  | 2,000 |  |  |  | 0.41% - 0.64% |  |  |  | 2,000 |  |  |  | 0.37% - 0.60% |  |
| Fixed-rate 1.05% - 4.45% notes |  |  | 2017 - 2044 |  |  |  | 10,000 |  |  |  | 0.40% - 4.48% |  |  |  | 10,000 |  |  |  | 0.37% - 4.48% |  |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2017 - 2020 |  |  |  | 1,755 |  |  |  | 0.41% - 1.87% |  |  |  | 1,743 |  |  |  | 0.36% - 1.87% |  |
| Fixed-rate 0.35% - 4.375% notes |  |  | 2017 - 2045 |  |  |  | 24,793 |  |  |  | 0.28% - 4.51% |  |  |  | 24,958 |  |  |  | 0.28% - 4.51% |  |
| Total term debt |  |  |  |  |  |  | 55,548 |  |  |  |  |  |  |  | 55,701 |  |  |  |  |  |
| Unamortized discount |  |  |  |  |  |  | (109 | ) |  |  |  |  |  |  | (114 | ) |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  |  |  | 265 |  |  |  |  |  |  |  | 376 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | (2,500 | ) |  |  |  |  |  |  | (2,500 | ) |  |  |  |  |
| Total long-term debt |  |  |  |  |  | $ | 53,204 |  |  |  |  |  |  | $ | 53,463 |  |  |  |  |  |

[0001193125-16-439878:notes:21]
As of December 26, 2015, ¥118.0 billion
 of Japanese yen-denominated notes was designated as a hedge of the
 foreign currency exposure of its net investment in a foreign
 operation. The foreign currency transaction gain or loss on the
 Japanese yen-denominated debt designated as a hedge is recorded in
 OCI as a part of the cumulative translation adjustment. As of
 December 26, 2015 and September 26, 2015, the carrying
 value of the debt designated as a net investment hedge was $1.0
 billion and $2.1 billion, respectively. For further discussion
 regarding the Company’s use of derivative instruments see the
 Derivative Financial Instruments section of Note 2,
 “Financial Instruments.”

[0001193125-16-439878:notes:22]
The effective interest rates for the Notes include
 the interest on the Notes, amortization of the discount and, if
 applicable, adjustments related to hedging. The Company recognized
 $271 million and $128 million of interest expense on its term debt
 for the three months ended December 26, 2015 and
 December 27, 2014, respectively.

[0001193125-16-439878:notes:23]
As of December 26, 2015 and September 26,
 2015, the fair value of the Company’s Notes, based on Level 2
 inputs, was $55.1 billion and $54.9 billion, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-16-439878:notes:24]
[same as prior period, unchanged from 0001193125-15-259935:notes:25]

[0001193125-16-439878:notes:25]
[same as prior period, unchanged from 0001193125-15-259935:notes:26]

[0001193125-16-439878:notes:26]
The Company manages its business primarily on a
 geographic basis. The Company’s reportable operating segments
 consist of the Americas, Europe, Greater China, Japan and Rest of
 Asia Pacific. The Americas segment includes both North and South
 America. The Europe segment includes European countries, as well as
 India, the Middle East and Africa. The Greater China segment
 includes China, Hong Kong and Taiwan. The Rest of Asia Pacific
 segment includes Australia and those Asian countries not included
 in the Company’s other reportable operating segments.
 Although each reportable operating segment provides similar
 hardware and software products and similar services, they are
 managed separately to better align with the location of the
 Company’s customers and distribution partners and the unique
 market dynamics of each geographic region. The accounting policies
 of the various segments are the same as those described in Note 1,
 “Summary of Significant Accounting Policies” of the
 Notes to Consolidated Financial Statements in Part II, Item 8
 of the 2015 Form 10-K.

[0001193125-16-439878:notes:27]
The Company evaluates the performance of its
 reportable operating segments based on net sales and operating
 income. Net sales for geographic segments are generally based on
 the location of customers and sales through the Company’s
 retail stores located in those geographic locations. Operating
 income for each segment includes net sales to third parties,
 related cost of sales and operating expenses directly attributable
 to the segment. Advertising expenses are generally included in the
 geographic segment in which the expenditures are incurred.
 Operating income for each segment excludes other income and expense
 and certain expenses managed outside the reportable operating
 segments. Costs excluded from segment operating income include
 various corporate expenses such as research and development,
 corporate marketing expenses, certain share-based compensation
 expenses, income taxes, various nonrecurring charges and other
 separately managed general and administrative costs. The Company
 does not include intercompany transfers between segments for
 management reporting purposes.

[0001193125-16-439878:notes:28]
The following table shows information by reportable
 operating segment for the three months ended December 26, 2015
 and December 27, 2014 (in millions):

[0001193125-16-439878:notes:29]
|  |  | Three Months Ended |  |
|  |  | December 26, 2015 |  |  | December 27, 2014 |  |
| Americas: |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 29,325 |  |  | $ | 30,566 |  |
| Operating income |  | $ | 10,018 |  |  | $ | 10,701 |  |
| Europe: |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 17,932 |  |  | $ | 17,214 |  |
| Operating income |  | $ | 5,779 |  |  | $ | 5,882 |  |
| Greater China: |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 18,373 |  |  | $ | 16,144 |  |
| Operating income |  | $ | 7,576 |  |  | $ | 6,366 |  |
| Japan: |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 4,794 |  |  | $ | 5,448 |  |
| Operating income |  | $ | 2,240 |  |  | $ | 2,488 |  |
| Rest of Asia Pacific: |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 5,448 |  |  | $ | 5,227 |  |
| Operating income |  | $ | 2,032 |  |  | $ | 1,849 |  |


## us-gaap:AcceleratedShareRepurchasesTextBlock

[0001193125-16-439878:notes:30]
The following table shows the Company’s ASR
 activity and related information during the three months ended
 December 26, 2015 and the year ended September 26,
 2015:

[0001193125-16-439878:notes:31]
|  |  | Purchase Period End Date |  |  | Number of Shares (in thousands) |  |  | Average Repurchase Price Per Share |  |  | ASR Amount (in millions) |  |
| November 2015 ASR |  |  | April 2016 |  |  |  | 20,382 (1) |  |  | $ | (1) |  |  | $ | 3,000 |  |
| May 2015 ASR |  |  | July 2015 |  |  |  | 48,293 |  |  | $ | 124.24 |  |  | $ | 6,000 |  |
| August 2014 ASR |  |  | February 2015 |  |  |  | 81,525 |  |  | $ | 110.40 |  |  | $ | 9,000 |  |
| January 2014 ASR |  |  | December 2014 |  |  |  | 134,247 |  |  | $ | 89.39 |  |  | $ | 12,000 |  |

[0001193125-16-439878:notes:32]
|  | (1) | “Number of Shares” represents those shares delivered in the beginning of the purchase period and does not represent the final number of shares to be delivered under the ASR. The total number of shares ultimately delivered, and therefore the average repurchase price paid per share, will be determined at the end of the applicable purchase period based on the volume-weighted average price of the Company’s common stock during that period. The November 2015 ASR purchase period will end in or before April 2016. |  |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001193125-16-439878:notes:33]
The following tables show the Company’s cash
 and available-for-sale
 securities’ adjusted cost, gross unrealized gains, gross
 unrealized losses and fair value by significant investment category
 recorded as cash and cash equivalents or short- or long-term
 marketable securities as of December 26, 2015 and
 September 26, 2015 (in millions):

[0001193125-16-439878:notes:34]
|  |  | December 26, 2015 |  |
|  |  | Adjusted Cost |  |  | Unrealized Gains |  |  | Unrealized Losses |  |  | Fair Value |  |  | Cash and Cash Equivalents |  |  | Short-Term Marketable Securities |  |  | Long-Term Marketable Securities |  |
| Cash |  | $ | 11,152 |  |  | $ | 0 |  |  | $ | 0 |  |  | $ | 11,152 |  |  | $ | 11,152 |  |  | $ | 0 |  |  | $ | 0 |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  |  | 3,517 |  |  |  | 0 |  |  |  | 0 |  |  |  | 3,517 |  |  |  | 3,517 |  |  |  | 0 |  |  |  | 0 |  |
| Mutual funds |  |  | 1,772 |  |  |  | 0 |  |  |  | (206 | ) |  |  | 1,566 |  |  |  | 0 |  |  |  | 1,566 |  |  |  | 0 |  |
| Subtotal |  |  | 5,289 |  |  |  | 0 |  |  |  | (206 | ) |  |  | 5,083 |  |  |  | 3,517 |  |  |  | 1,566 |  |  |  | 0 |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities |  |  | 40,739 |  |  |  | 43 |  |  |  | (108 | ) |  |  | 40,674 |  |  |  | 203 |  |  |  | 1,602 |  |  |  | 38,869 |  |
| U.S. agency securities |  |  | 5,307 |  |  |  | 2 |  |  |  | (10 | ) |  |  | 5,299 |  |  |  | 469 |  |  |  | 865 |  |  |  | 3,965 |  |
| Non-U.S. government securities |  |  | 6,530 |  |  |  | 31 |  |  |  | (201 | ) |  |  | 6,360 |  |  |  | 0 |  |  |  | 454 |  |  |  | 5,906 |  |
| Certificates of deposit and time deposits |  |  | 2,986 |  |  |  | 0 |  |  |  | 0 |  |  |  | 2,986 |  |  |  | 258 |  |  |  | 1,424 |  |  |  | 1,304 |  |
| Commercial paper |  |  | 2,236 |  |  |  | 0 |  |  |  | 0 |  |  |  | 2,236 |  |  |  | 1,089 |  |  |  | 895 |  |  |  | 252 |  |
| Corporate securities |  |  | 125,000 |  |  |  | 132 |  |  |  | (1,684 | ) |  |  | 123,448 |  |  |  | 1 |  |  |  | 14,463 |  |  |  | 108,984 |  |
| Municipal securities |  |  | 946 |  |  |  | 3 |  |  |  | (1 | ) |  |  | 948 |  |  |  | 0 |  |  |  | 28 |  |  |  | 920 |  |
| Mortgage- and asset-backed securities |  |  | 17,635 |  |  |  | 23 |  |  |  | (105 | ) |  |  | 17,553 |  |  |  | 0 |  |  |  | 88 |  |  |  | 17,465 |  |
| Subtotal |  |  | 201,379 |  |  |  | 234 |  |  |  | (2,109 | ) |  |  | 199,504 |  |  |  | 2,020 |  |  |  | 19,819 |  |  |  | 177,665 |  |
| Total |  | $ | 217,820 |  |  | $ | 234 |  |  | $ | (2,315 | ) |  | $ | 215,739 |  |  | $ | 16,689 |  |  | $ | 21,385 |  |  | $ | 177,665 |  |

[0001193125-16-439878:notes:35]
|  |  | September 26, 2015 |  |
|  |  | Adjusted Cost |  |  | Unrealized Gains |  |  | Unrealized Losses |  |  | Fair Value |  |  | Cash and Cash Equivalents |  |  | Short-Term Marketable Securities |  |  | Long-Term Marketable Securities |  |
| Cash |  | $ | 11,389 |  |  | $ | 0 |  |  | $ | 0 |  |  | $ | 11,389 |  |  | $ | 11,389 |  |  | $ | 0 |  |  | $ | 0 |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  |  | 1,798 |  |  |  | 0 |  |  |  | 0 |  |  |  | 1,798 |  |  |  | 1,798 |  |  |  | 0 |  |  |  | 0 |  |
| Mutual funds |  |  | 1,772 |  |  |  | 0 |  |  |  | (144 | ) |  |  | 1,628 |  |  |  | 0 |  |  |  | 1,628 |  |  |  | 0 |  |
| Subtotal |  |  | 3,570 |  |  |  | 0 |  |  |  | (144 | ) |  |  | 3,426 |  |  |  | 1,798 |  |  |  | 1,628 |  |  |  | 0 |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities |  |  | 34,902 |  |  |  | 181 |  |  |  | (1 | ) |  |  | 35,082 |  |  |  | 0 |  |  |  | 3,498 |  |  |  | 31,584 |  |
| U.S. agency securities |  |  | 5,864 |  |  |  | 14 |  |  |  | 0 |  |  |  | 5,878 |  |  |  | 841 |  |  |  | 767 |  |  |  | 4,270 |  |
| Non-U.S. government securities |  |  | 6,356 |  |  |  | 45 |  |  |  | (167 | ) |  |  | 6,234 |  |  |  | 43 |  |  |  | 135 |  |  |  | 6,056 |  |
| Certificates of deposit and time deposits |  |  | 4,347 |  |  |  | 0 |  |  |  | 0 |  |  |  | 4,347 |  |  |  | 2,065 |  |  |  | 1,405 |  |  |  | 877 |  |
| Commercial paper |  |  | 6,016 |  |  |  | 0 |  |  |  | 0 |  |  |  | 6,016 |  |  |  | 4,981 |  |  |  | 1,035 |  |  |  | 0 |  |
| Corporate securities |  |  | 116,908 |  |  |  | 242 |  |  |  | (985 | ) |  |  | 116,165 |  |  |  | 3 |  |  |  | 11,948 |  |  |  | 104,214 |  |
| Municipal securities |  |  | 947 |  |  |  | 5 |  |  |  | 0 |  |  |  | 952 |  |  |  | 0 |  |  |  | 48 |  |  |  | 904 |  |
| Mortgage- and asset-backed securities |  |  | 16,121 |  |  |  | 87 |  |  |  | (31 | ) |  |  | 16,177 |  |  |  | 0 |  |  |  | 17 |  |  |  | 16,160 |  |
| Subtotal |  |  | 191,461 |  |  |  | 574 |  |  |  | (1,184 | ) |  |  | 190,851 |  |  |  | 7,933 |  |  |  | 18,853 |  |  |  | 164,065 |  |
| Total |  | $ | 206,420 |  |  | $ | 574 |  |  | $ | (1,328 | ) |  | $ | 205,666 |  |  | $ | 21,120 |  |  | $ | 20,481 |  |  | $ | 164,065 |  |

[0001193125-16-439878:notes:36]
[same as prior period, unchanged from 0001193125-15-259935:notes:39]

[0001193125-16-439878:notes:37]
|  | (2) | The fair value of Level 2 securities is estimated based on observable inputs other than quoted prices in active markets for identical assets and liabilities, quoted prices for identical or similar assets or liabilities in inactive markets, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities. |  |


## us-gaap:DividendsDeclaredTableTextBlock

[0001193125-16-439878:notes:38]
[same as prior period, unchanged from 0001193125-15-259935:notes:41]

[0001193125-16-439878:notes:39]
|  |  | Dividends Per Share |  |  | Amount (in millions) |  |
| 2016: |  |  |  |  |  |  |  |  |
| First quarter |  | $ | 0.52 |  |  | $ | 2,898 |  |
| 2015: |  |  |  |  |  |  |  |  |
| Fourth quarter |  | $ | 0.52 |  |  | $ | 2,950 |  |
| Third quarter |  |  | 0.52 |  |  |  | 2,997 |  |
| Second quarter |  |  | 0.47 |  |  |  | 2,734 |  |
| First quarter |  |  | 0.47 |  |  |  | 2,750 |  |
| Total cash dividends declared and paid |  | $ | 1.98 |  |  | $ | 11,431 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001193125-16-439878:notes:40]
[same as prior period, unchanged from 0001193125-15-259935:notes:43]

[0001193125-16-439878:notes:41]
The accompanying condensed consolidated financial
 statements include the accounts of the Company. Intercompany
 accounts and transactions have been eliminated. In the opinion of
 the Company’s management, the condensed consolidated
 financial statements reflect all adjustments, which are normal and
 recurring in nature, necessary for fair financial statement
 presentation. The preparation of these condensed consolidated
 financial statements in conformity with U.S. generally accepted
 accounting principles (“GAAP”) requires management to
 make estimates and assumptions that affect the amounts reported in
 these condensed consolidated financial statements and accompanying
 notes. Actual results could differ materially from those estimates.
 Certain prior period amounts in the condensed consolidated
 financial statements have been reclassified to conform to the
 current period’s presentation.

[0001193125-16-439878:notes:42]
These condensed consolidated financial statements
 and accompanying notes should be read in conjunction with the
 Company’s annual consolidated financial statements and the
 notes thereto included in its Annual Report on Form 10-K for the
 fiscal year ended September 26, 2015 (the “2015 Form
 10-K”). The Company’s fiscal year is the 52 or 53-week
 period that ends on the last Saturday of September. An additional
 week is included in the first fiscal quarter approximately every
 six years to realign fiscal quarters with calendar quarters. The
 Company’s fiscal years 2016 and 2015 each include 52 weeks.
 Unless otherwise stated, references to particular years, quarters
 or months refer to the Company’s fiscal years ended in
 September and the associated quarters or months of those fiscal
 years.

[0001193125-16-439878:notes:43]
During the first quarter of 2016, the Company
 adopted an accounting standard that simplified the presentation of
 deferred taxes by requiring deferred tax assets and liabilities be
 classified as noncurrent in a classified statement of
 financial position. The Company has adopted this accounting
 standard prospectively; accordingly, the prior period amounts in
 the Company’s Condensed Consolidated Balance Sheets within
 this Quarterly Report on Form 10-Q were not adjusted to conform to
 the new accounting standard. The adoption of this accounting
 standard was not material to the Company’s condensed
 consolidated financial statements.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001193125-16-439878:notes:44]
[same as prior period, unchanged from 0001193125-15-259935:notes:46]

[0001193125-16-439878:notes:45]
[same as prior period, unchanged from 0001193125-15-259935:notes:47]

[0001193125-16-439878:notes:46]
Potentially dilutive securities whose effect would
 have been antidilutive are excluded from the computation of diluted
 earnings per share.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001193125-16-439878:notes:47]
[same as prior period, unchanged from 0001193125-15-259935:notes:49]

[0001193125-16-439878:notes:48]
[same as prior period, unchanged from 0001193125-15-259935:notes:50]

[0001193125-16-439878:notes:49]
The Company may sell certain of its marketable
 securities prior to their stated maturities for strategic reasons
 including, but not limited to, anticipation of credit deterioration
 and duration management. The maturities of the Company’s
 long-term marketable securities generally range from one to five
 years.

[0001193125-16-439878:notes:50]
As of December 26, 2015, the Company considers
 the declines in market value of its marketable securities
 investment portfolio to be temporary in nature and does not
 consider any of its investments other-than-temporarily impaired.
 The Company typically invests in highly-rated securities, and its
 investment policy generally limits the amount of credit exposure to
 any one issuer. The policy generally requires investments to be
 investment grade, with the primary objective of minimizing the
 potential risk of principal loss. Fair values were determined for
 each individual security in the investment portfolio. When
 evaluating an investment for other-than-temporary impairment the
 Company reviews factors such as the length of time and extent to
 which fair value has been below its cost basis, the financial
 condition of the issuer and any changes thereto, changes in market
 interest rates and the Company’s intent to sell, or whether
 it is more likely than not it will be required to sell the
 investment before recovery of the investment’s cost
 basis.

[0001193125-16-439878:notes:51]
[same as prior period, unchanged from 0001193125-15-259935:notes:55]

[0001193125-16-439878:notes:52]
[same as prior period, unchanged from 0001193125-15-259935:notes:56]

[0001193125-16-439878:notes:53]
[same as prior period, unchanged from 0001193125-15-259935:notes:57]

[0001193125-16-439878:notes:54]
To help protect the net investment in a foreign
 operation from adverse changes in foreign currency exchange rates,
 the Company may enter into foreign currency forward and option
 contracts to offset the changes in the carrying amounts of these
 investments due to fluctuations in foreign currency exchange rates.
 In addition, the Company may use non-derivative financial
 instruments, such as its foreign currency-denominated debt, as
 economic hedges of its net investments in certain foreign
 subsidiaries. In both of these cases, the Company designates these
 instruments as net investment hedges.

[0001193125-16-439878:notes:55]
[same as prior period, unchanged from 0001193125-15-259935:notes:59]

[0001193125-16-439878:notes:56]
The Company may enter into interest rate swaps,
 options, or other instruments to manage interest rate risk. These
 instruments may offset a portion of changes in income or expense,
 or changes in fair value of the Company’s term debt or
 investments. The Company designates these instruments as either
 cash flow or fair value hedges. The Company’s hedged interest
 rate transactions as of December 26, 2015 are expected to be
 recognized within nine years.

[0001193125-16-439878:notes:57]
[same as prior period, unchanged from 0001193125-15-259935:notes:61]

[0001193125-16-439878:notes:58]
The effective portions of cash flow hedges are
 recorded in accumulated other comprehensive income
 (“AOCI”) until the hedged item is recognized in
 earnings. Deferred gains and losses associated with cash flow
 hedges of foreign currency revenue are recognized as a component of
 net sales in the same period as the related revenue is recognized,
 and deferred gains and losses related to cash flow hedges of
 inventory purchases are recognized as a component of cost of sales
 in the same period as the related costs are recognized. Deferred
 gains and losses associated with cash flow hedges of interest
 income or expense are recognized in other income/(expense), net in
 the same period as the related income or expense is recognized. The
 ineffective portions and amounts excluded from the effectiveness
 testing of cash flow hedges are recognized in other
 income/(expense), net.

[0001193125-16-439878:notes:59]
Derivative instruments designated as cash flow
 hedges must be de-designated as hedges when it is probable the
 forecasted hedged transaction will not occur in the initially
 identified time period or within a subsequent two-month time
 period. Deferred gains and losses in AOCI associated with such
 derivative instruments are reclassified immediately into other
 income/(expense), net. Any subsequent changes in fair value of such
 derivative instruments are reflected in other income/(expense), net
 unless they are re-designated as hedges of other transactions.

[0001193125-16-439878:notes:60]
[same as prior period, unchanged from 0001193125-15-259935:notes:65]

[0001193125-16-439878:notes:61]
The effective portions of net investment hedges are
 recorded in other comprehensive income (“OCI”) as a
 part of the cumulative translation adjustment. The ineffective
 portions and amounts excluded from the effectiveness testing of net
 investment hedges are recognized in other income/(expense),
 net.

[0001193125-16-439878:notes:62]
[same as prior period, unchanged from 0001193125-15-259935:notes:67]

[0001193125-16-439878:notes:63]
Gains and losses related to changes in fair value
 hedges are recognized in earnings along with a corresponding loss
 or gain related to the change in value of the underlying hedged
 item.

[0001193125-16-439878:notes:64]
[same as prior period, unchanged from 0001193125-15-259935:notes:69]

[0001193125-16-439878:notes:65]
Derivatives that are not designated as hedging
 instruments are adjusted to fair value through earnings in the
 financial statement line item to which the derivative relates.

[0001193125-16-439878:notes:66]
The Company records all derivatives in the
 Condensed Consolidated Balance Sheets at fair value. The
 Company’s accounting treatment for these derivative
 instruments is based on its hedge designation. The following tables
 show the Company’s derivative instruments at gross fair value
 as of December 26, 2015 and September 26, 2015 (in
 millions):

[0001193125-16-439878:notes:67]
The following table shows the pre-tax gains and
 losses of the Company’s derivative and non-derivative
 instruments designated as cash flow, net investment and fair value
 hedges on OCI and the Condensed Consolidated Statements of
 Operations for the three months ended December 26, 2015 and
 December 27, 2014 (in millions):

[0001193125-16-439878:notes:68]
|  |  | December 26, 2015 |  |  | December 27, 2014 |  |
| Gains/(Losses) recognized in OCI – effective portion: |  |  |  |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 326 |  |  | $ | 2,501 |  |
| Interest rate contracts |  |  | 8 |  |  |  | (4 | ) |
| Total |  | $ | 334 |  |  | $ | 2,497 |  |
| Net investment hedges: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 0 |  |  | $ | 118 |  |
| Foreign currency debt |  |  | 10 |  |  |  | 0 |  |
| Total |  | $ | 10 |  |  | $ | 118 |  |
| Gains/(Losses) reclassified from AOCI into net income – effective portion: |  |  |  |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 515 |  |  | $ | 667 |  |
| Interest rate contracts |  |  | (4 | ) |  |  | (4 | ) |
| Total |  | $ | 511 |  |  | $ | 663 |  |
| Gains/(Losses) on derivative instruments: |  |  |  |  |  |  |  |  |
| Fair value hedges: |  |  |  |  |  |  |  |  |
| Interest rate contracts |  | $ | (111 | ) |  | $ | 117 |  |
| Gains/(Losses) related to hedged items: |  |  |  |  |  |  |  |  |
| Fair value hedges: |  |  |  |  |  |  |  |  |
| Interest rate contracts |  | $ | 111 |  |  | $ | (117 | ) |

[0001193125-16-439878:notes:69]
The following table shows the notional amounts of
 the Company’s outstanding derivative instruments and credit
 risk amounts associated with outstanding or unsettled derivative
 instruments as of December 26, 2015 and September 26,
 2015 (in millions):

[0001193125-16-439878:notes:70]
|  |  | December 26, 2015 |  |  | September 26, 2015 |  |
|  |  | Notional Amount |  |  | Credit Risk Amount |  |  | Notional Amount |  |  | Credit Risk Amount |  |
| Instruments designated as accounting hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 59,305 |  |  | $ | 1,021 |  |  | $ | 70,054 |  |  | $ | 1,385 |  |
| Interest rate contracts |  | $ | 18,750 |  |  | $ | 313 |  |  | $ | 18,750 |  |  | $ | 394 |  |
| Instruments not designated as accounting hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 48,365 |  |  | $ | 275 |  |  | $ | 49,190 |  |  | $ | 109 |  |

[0001193125-16-439878:notes:71]
The notional amounts for outstanding derivative
 instruments provide one measure of the transaction volume
 outstanding and do not represent the amount of the Company’s
 exposure to credit or market loss. The credit risk amounts
 represent the Company’s gross exposure to potential
 accounting loss on derivative instruments that are outstanding or
 unsettled if all counterparties failed to perform according to the
 terms of the contract, based on then-current currency or interest
 rates at each respective date. The Company’s exposure to
 credit loss and market risk will vary over time as currency and
 interest rates change. Although the table above reflects the
 notional and credit risk amounts of the Company’s derivative
 instruments, it does not reflect the gains or losses associated
 with the exposures and transactions that the instruments are
 intended to hedge. The amounts ultimately realized upon settlement
 of these financial instruments, together with the gains and losses
 on the underlying exposures, will depend on actual market
 conditions during the remaining life of the instruments.

[0001193125-16-439878:notes:72]
The Company generally enters into master netting
 arrangements, which are designed to reduce credit risk by
 permitting net settlement of transactions with the same
 counterparty. To further limit credit risk, the Company generally
 enters into collateral security arrangements that provide for
 collateral to be received or posted when the net fair value of
 certain financial instruments fluctuates from contractually
 established thresholds. The Company presents its derivative assets
 and derivative liabilities at their gross fair values in its
 Condensed Consolidated Balance Sheets. The net cash collateral
 received by the Company related to derivative instruments under its
 collateral security arrangements was $660 million as of
 December 26, 2015 and $1.0 billion as of September 26,
 2015.

[0001193125-16-439878:notes:73]
Under master netting arrangements with the
 respective counterparties to the Company’s derivative
 contracts, the Company is allowed to net settle transactions
 with a single net amount payable by one party to the other. As of
 December 26, 2015 and September 26, 2015, the potential
 effects of these rights of set-off associated with the
 Company’s derivative contracts, including the effects of
 collateral, would be a reduction to both derivative assets and
 derivative liabilities of $1.7 billion and $2.2 billion,
 respectively, resulting in net derivative liabilities
 of $116 million and $78 million, respectively.

[0001193125-16-439878:notes:74]
[same as prior period, unchanged from 0001193125-15-259935:notes:79]

[0001193125-16-439878:notes:75]
[same as prior period, unchanged from 0001193125-15-259935:notes:80]

[0001193125-16-439878:notes:76]
The Company has considerable trade receivables
 outstanding with its third-party cellular network carriers,
 wholesalers, retailers, value-added resellers, small and mid-sized
 businesses and education, enterprise and government customers that
 are not covered by collateral, third-party financing arrangements
 or credit insurance. As of December 26, 2015, there was no
 single customer that accounted for 10% or more of total trade
 receivables. As of September 26, 2015, the Company had one
 customer that represented 10% or more of total trade receivables,
 which accounted for 12%. The Company’s cellular network
 carriers accounted for 50% and 71% of trade receivables as of
 December 26, 2015 and September 26, 2015,
 respectively.

[0001193125-16-439878:notes:77]
[same as prior period, unchanged from 0001193125-15-259935:notes:82]

[0001193125-16-439878:notes:78]
The Company has non-trade receivables from certain
 of its manufacturing vendors resulting from the sale of components
 to these vendors who manufacture sub-assemblies or assemble final
 products for the Company. Vendor non-trade receivables from three
 of the Company’s vendors accounted for 51%, 14% and 10% of
 total vendor non-trade receivables as of December 26, 2015 and
 three of the Company’s vendors accounted for 38%, 18% and 14%
 of total vendor non-trade receivables as of September 26,
 2015.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001193125-16-439878:notes:79]
[same as prior period, unchanged from 0001193125-15-259935:notes:84]

[0001193125-16-439878:notes:80]
Apple Inc. and its wholly-owned subsidiaries
 (collectively “Apple” or the “Company”)
 designs, manufactures and markets mobile communication and media
 devices, personal computers and portable digital music players, and
 sells a variety of related software, services, accessories,
 networking solutions and third-party digital content and
 applications. The Company sells its products worldwide through its
 retail stores, online stores and direct sales force, as well as
 through third-party cellular network carriers, wholesalers,
 retailers and value-added resellers. In addition, the Company sells
 a variety of third-party Apple-compatible products, including
 application software and various accessories through its online and
 retail stores. The Company sells to consumers, small and mid-sized
 businesses and education, enterprise and government customers.


## us-gaap:OtherNoncurrentLiabilitiesTableTextBlock

[0001193125-16-439878:notes:81]
Other Non-Current Liabilities

[0001193125-16-439878:notes:82]
|  |  | December 26, 2015 |  |  | September 26, 2015 |  |
| Deferred tax liabilities |  | $ | 21,617 |  |  | $ | 24,062 |  |
| Other non-current liabilities |  |  | 10,558 |  |  |  | 9,365 |  |
| Total other non-current liabilities |  | $ | 32,175 |  |  | $ | 33,427 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001193125-16-439878:notes:83]
[same as prior period, unchanged from 0001193125-15-259935:notes:87]

[0001193125-16-439878:notes:84]
|  |  | December 26, 2015 |  |  | September 26, 2015 |  |
| Land and buildings |  | $ | 7,729 |  |  | $ | 6,956 |  |
| Machinery, equipment and internal-use software |  |  | 38,039 |  |  |  | 37,038 |  |
| Leasehold improvements |  |  | 5,574 |  |  |  | 5,263 |  |
| Gross property, plant and equipment |  |  | 51,342 |  |  |  | 49,257 |  |
| Accumulated depreciation and amortization |  |  | (29,042 | ) |  |  | (26,786 | ) |
| Total property, plant and equipment, net |  | $ | 22,300 |  |  | $ | 22,471 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-16-439878:notes:85]
[same as prior period, unchanged from 0001193125-15-259935:notes:89]

[0001193125-16-439878:notes:86]
[same as prior period, unchanged from 0001193125-15-259935:notes:90]

[0001193125-16-439878:notes:87]
The following table shows the pre-tax amounts
 reclassified from AOCI into the Condensed Consolidated Statements
 of Operations, and the associated financial statement line item,
 for the three months ended December 26, 2015 and
 December 27, 2014 (in millions):

[0001193125-16-439878:notes:88]
| Comprehensive Income Components |  | Financial Statement Line Item |  | December 26, 2015 |  |  | December 27, 2014 |  |
| Unrealized (gains)/losses on derivative instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Revenue |  | $ | (329 | ) |  | $ | (449 | ) |
|  |  | Cost of sales |  |  | (306 | ) |  |  | (313 | ) |
|  |  | Other income/(expense), net |  |  | 120 |  |  |  | 95 |  |
| Interest rate contracts |  | Other income/(expense), net |  |  | 4 |  |  |  | 4 |  |
|  |  |  |  |  | (511 | ) |  |  | (663 | ) |
| Unrealized (gains)/losses on marketable securities |  | Other income/(expense), net |  |  | 73 |  |  |  | (22 | ) |
| Total amounts reclassified from AOCI |  | $ | (438 | ) |  | $ | (685 | ) |

[0001193125-16-439878:notes:89]
The following table shows the changes in AOCI by component for the
 three months ended December 26, 2015 (in millions):

[0001193125-16-439878:notes:90]
|  |  | Cumulative Foreign Currency Translation |  |  | Unrealized Gains/Losses on Derivative Instruments |  |  | Unrealized Gains/Losses on Marketable Securities |  |  | Total |  |
| Balance at September 26, 2015 |  | $ | (653 | ) |  | $ | 772 |  |  | $ | (464 | ) |  | $ | (345 | ) |
| Other comprehensive income/(loss) before reclassifications |  |  | (121 | ) |  |  | 325 |  |  |  | (1,430 | ) |  |  | (1,226 | ) |
| Amounts reclassified from AOCI |  |  | 0 |  |  |  | (511 | ) |  |  | 73 |  |  |  | (438 | ) |
| Tax effect |  |  | 19 |  |  |  | 28 |  |  |  | 482 |  |  |  | 529 |  |
| Other comprehensive income/(loss) |  |  | (102 | ) |  |  | (158 | ) |  |  | (875 | ) |  |  | (1,135 | ) |
| Balance at December 26, 2015 |  | $ | (755 | ) |  | $ | 614 |  |  | $ | (1,339 | ) |  | $ | (1,480 | ) |


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001193125-16-439878:notes:91]
[same as prior period, unchanged from 0001193125-15-259935:notes:99]

[0001193125-16-439878:notes:92]
[same as prior period, unchanged from 0001193125-15-259935:notes:100]

[0001193125-16-439878:notes:93]
The Company had 376.5 million shares reserved
 for future issuance under its stock plans as of December 26,
 2015. RSUs granted generally vest over four years, based on
 continued employment, and are settled upon vesting in shares of the
 Company’s common stock on a one-for-one basis. Each share
 issued with respect to RSUs granted under the Company’s stock
 plans reduces the number of shares available for grant under the
 plan by two shares. RSUs cancelled and shares withheld to satisfy
 tax withholding obligations increase the number of shares available
 for grant under the plans utilizing a factor of two times the
 number of RSUs cancelled or shares withheld. Stock options count
 against the number of shares available for grant on a one-for-one
 basis.

[0001193125-16-439878:notes:94]
[same as prior period, unchanged from 0001193125-15-259935:notes:102]

[0001193125-16-439878:notes:95]
During the three months ended December 26,
 2015, Section 16 officers Timothy D. Cook, Luca Maestri,
 Daniel Riccio, Philip Schiller and Jeffrey Williams had equity
 trading plans in place in accordance with Rule 10b5-1(c)(1) under
 the Exchange Act. An equity trading plan is a written document that
 pre-establishes the amounts, prices and dates (or formula for
 determining the amounts, prices and dates) of future purchases or
 sales of the Company’s stock, including shares acquired
 pursuant to the Company’s employee and director equity
 plans.

[0001193125-16-439878:notes:96]
[same as prior period, unchanged from 0001193125-15-259935:notes:104]

[0001193125-16-439878:notes:97]
A summary of the Company’s RSU activity and
 related information for the three months ended December 26,
 2015 is as follows:

[0001193125-16-439878:notes:98]
|  |  | Number of RSUs (in thousands) |  |  | Weighted-Average Grant Date Fair Value Per Share |  |  | Aggregate Intrinsic Value (in millions) |  |
| Balance at September 26, 2015 |  |  | 101,467 |  |  | $ | 85.77 |  |  |  |  |  |
| RSUs granted |  |  | 41,082 |  |  | $ | 111.31 |  |  |  |  |  |
| RSUs vested |  |  | (17,923 | ) |  | $ | 79.24 |  |  |  |  |  |
| RSUs cancelled |  |  | (1,282 | ) |  | $ | 90.95 |  |  |  |  |  |
| Balance at December 26, 2015 |  |  | 123,344 |  |  | $ | 95.09 |  |  | $ | 13,325 |  |

[0001193125-16-439878:notes:99]
RSUs that vested during the three months ended
 December 26, 2015 and December 27, 2014 had fair values
 of $2.0 billion and $1.7 billion, respectively, as of the vesting
 date.

[0001193125-16-439878:notes:100]
[same as prior period, unchanged from 0001193125-15-259935:notes:108]

[0001193125-16-439878:notes:101]
The Company had 1.1 million stock options
 outstanding as of December 26, 2015, with a weighted-average
 exercise price per share of $15.24 and weighted-average remaining
 contractual term of 4.0 years, substantially all of which are
 exercisable. The aggregate intrinsic value of the stock options
 outstanding as of December 26, 2015 was $106 million, which
 represents the value of the Company’s closing stock price on
 the last trading day of the period in excess of the
 weighted-average exercise price multiplied by the number of options
 outstanding.

[0001193125-16-439878:notes:102]
[same as prior period, unchanged from 0001193125-15-259935:notes:111]

[0001193125-16-439878:notes:103]
The following table shows a summary of the
 share-based compensation expense included in the Condensed
 Consolidated Statements of Operations for the three months ended
 December 26, 2015 and December 27, 2014 (in
 millions):

[0001193125-16-439878:notes:104]
|  |  | Three Months Ended |  |
|  |  | December 26, 2015 |  |  | December 27, 2014 |  |
| Cost of sales |  | $ | 204 |  |  | $ | 140 |  |
| Research and development |  |  | 466 |  |  |  | 374 |  |
| Selling, general and administrative |  |  | 408 |  |  |  | 374 |  |
| Total share-based compensation expense |  | $ | 1,078 |  |  | $ | 888 |  |

[0001193125-16-439878:notes:105]
The income tax benefit related to share-based
 compensation expense was $413 million and $351 million for the
 three months ended December 26, 2015 and December 27,
 2014, respectively. As of December 26, 2015, the total
 unrecognized compensation cost related to outstanding stock
 options, RSUs and restricted stock was $10.0 billion, which the
 Company expects to recognize over a weighted-average period of 3.0
 years.


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001193125-16-439878:notes:106]
The following table shows changes in the
 Company’s accrued warranties and related costs for the three
 months ended December 26, 2015 and December 27, 2014 (in
 millions):

[0001193125-16-439878:notes:107]
|  |  | Three Months Ended |  |
|  |  | December 26, 2015 |  |  | December 27, 2014 |  |
| Beginning accrued warranty and related costs |  | $ | 4,780 |  |  | $ | 4,159 |  |
| Cost of warranty claims |  |  | (1,269 | ) |  |  | (1,044 | ) |
| Accruals for product warranty |  |  | 1,725 |  |  |  | 2,080 |  |
| Ending accrued warranty and related costs |  | $ | 5,236 |  |  | $ | 5,195 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-16-439878:notes:108]
[same as prior period, unchanged from 0001193125-15-259935:notes:117]

[0001193125-16-439878:notes:109]
As of December 26, 2015, the Company recorded
 gross unrecognized tax benefits of $7.4 billion, of which $2.7
 billion, if recognized, would affect the Company’s effective
 tax rate. As of September 26, 2015, the total amount of gross
 unrecognized tax benefits was $6.9 billion, of which $2.5 billion,
 if recognized, would have affected the Company’s effective
 tax rate. The Company’s total gross unrecognized tax benefits
 are classified as other non-current liabilities in the Condensed
 Consolidated Balance Sheets. The Company had $1.4 billion and $1.3
 billion of gross interest and penalties accrued as of
 December 26, 2015 and September 26, 2015, respectively,
 which are classified as other non-current liabilities in the
 Condensed Consolidated Balance Sheets.

[0001193125-16-439878:notes:110]
[same as prior period, unchanged from 0001193125-15-259935:notes:119]

[0001193125-16-439878:notes:111]
On June 11, 2014, the European Commission
 issued an opening decision initiating a formal investigation
 against Ireland for alleged state aid to the Company. The opening
 decision concerns the allocation of profits for taxation purposes
 of the Irish branches of two subsidiaries of the Company. The
 Company believes the European Commission’s assertions are
 without merit. If the European Commission were to conclude against
 Ireland, the European Commission could require Ireland to recover
 from the Company past taxes covering a period of up to 10 years
 reflective of the disallowed state aid. While such amount could be
 material, as of December 26, 2015 the Company is unable to
 estimate the impact.


## us-gaap:InterestAndOtherIncomeTableTextBlock

[0001193125-16-439878:notes:112]
[same as prior period, unchanged from 0001193125-15-259935:notes:121]

[0001193125-16-439878:notes:113]
The following table shows the detail of other
 income/(expense), net for the three months ended December 26,
 2015 and December 27, 2014 (in millions):

[0001193125-16-439878:notes:114]
|  |  | Three Months Ended |  |
|  |  | December 26, 2015 |  |  | December 27, 2014 |  |
| Interest and dividend income |  | $ | 941 |  |  | $ | 654 |  |
| Interest expense |  |  | (276 | ) |  |  | (131 | ) |
| Other expense, net |  |  | (263 | ) |  |  | (353 | ) |
| Total other income/(expense), net |  | $ | 402 |  |  | $ | 170 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-16-439878:notes:115]
[same as prior period, unchanged from 0001193125-15-259935:notes:124]

[0001193125-16-439878:notes:116]
[same as prior period, unchanged from 0001193125-15-259935:notes:125]

[0001193125-16-439878:notes:117]
[same as prior period, unchanged from 0001193125-15-259935:notes:126]

[0001193125-16-439878:notes:118]
[same as prior period, unchanged from 0001193125-15-259935:notes:127]

[0001193125-16-439878:notes:119]
In 2015, the Company’s Board of Directors
 increased the share repurchase authorization to $140 billion of the
 Company’s common stock, of which $110 billion had been
 utilized as of December 26, 2015. The Company’s share
 repurchase program does not obligate it to acquire any specific
 number of shares. Under the program, shares may be repurchased in
 privately negotiated and/or open market transactions, including
 under plans complying with Rule 10b5-1 under the Securities
 Exchange Act of 1934, as amended (the “Exchange
 Act”).

[0001193125-16-439878:notes:120]
[same as prior period, unchanged from 0001193125-15-259935:notes:129]

[0001193125-16-439878:notes:121]
[same as prior period, unchanged from 0001193125-15-259935:notes:130]

[0001193125-16-439878:notes:122]
|  |  | Number of Shares (in thousands) |  |  | Average Repurchase Price Per Share |  |  | Amount (in millions) |  |
| 2016: |  |  |  |  |  |  |  |  |  |  |  |  |
| First quarter |  |  | 25,984 |  |  | $ | 115.45 |  |  | $ | 3,000 |  |
| 2015: |  |  |  |  |  |  |  |  |  |  |  |  |
| Fourth quarter |  |  | 121,802 |  |  | $ | 115.15 |  |  | $ | 14,026 |  |
| Third quarter |  |  | 31,231 |  |  | $ | 128.08 |  |  |  | 4,000 |  |
| Second quarter |  |  | 56,400 |  |  | $ | 124.11 |  |  |  | 7,000 |  |
| First quarter |  |  | 45,704 |  |  | $ | 109.40 |  |  |  | 5,000 |  |
| Total open market common stock repurchases |  |  | 255,137 |  |  |  |  |  |  | $ | 30,026 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-16-439878:notes:123]
Note 10 – Commitments and Contingencies

[0001193125-16-439878:notes:124]
Accrued Warranty and Indemnification

[0001193125-16-439878:notes:125]
The Company generally does not indemnify end-users
 of its operating system and application software against legal
 claims that the software infringes third-party intellectual
 property rights. Other agreements entered into by the Company
 sometimes include indemnification provisions under which the
 Company could be subject to costs and/or damages in the event of an
 infringement claim against the Company or an indemnified
 third-party. In the opinion of management, there was not at least a
 reasonable possibility the Company may have incurred a material
 loss with respect to indemnification of end-users of its operating
 system or application software for infringement of third-party
 intellectual property rights.

[0001193125-16-439878:notes:126]
The Company offers an iPhone Upgrade Program, which
 is available to customers who purchase an iPhone 6s and 6s Plus in
 one of its U.S. physical retail stores and activate the purchased
 iPhone with one of the four national carriers. The iPhone Upgrade
 Program provides customers the right to trade in that iPhone for a
 new iPhone, provided certain conditions are met. One of the
 conditions of this program requires the customer to finance the
 initial purchase price of the iPhone with a third-party lender.
 Upon exercise of the trade-in right and purchase of a new iPhone,
 the Company satisfies the customer’s outstanding balance due
 to the third-party lender on the original device. The Company
 accounts for the trade-in right as a guarantee liability and
 recognizes arrangement revenue net of the fair value of such right
 with subsequent changes to the guarantee liability recognized
 within revenue.

[0001193125-16-439878:notes:127]
The Company has entered into indemnification
 agreements with its directors and executive officers. Under these
 agreements, the Company has agreed to indemnify such individuals to
 the fullest extent permitted by law against liabilities that arise
 by reason of their status as directors or officers and to advance
 expenses incurred by such individuals in connection with related
 legal proceedings. It is not possible to determine the maximum
 potential amount of payments the Company could be required to make
 under these agreements due to the limited history of prior
 indemnification claims and the unique facts and circumstances
 involved in each claim. However, the Company maintains directors
 and officers liability insurance coverage to reduce its exposure to
 such obligations.

[0001193125-16-439878:notes:128]
Concentrations in the Available Sources of Supply of Materials
 and Product

[0001193125-16-439878:notes:129]
Although most components essential to the
 Company’s business are generally available from multiple
 sources, a number of components are currently obtained from single
 or limited sources. In addition, the Company competes for various
 components with other participants in the markets for mobile
 communication and media devices and personal computers. Therefore,
 many components used by the Company, including those that are
 available from multiple sources, are at times subject to
 industry-wide shortage and significant pricing fluctuations that
 could materially adversely affect the Company’s financial
 condition and operating results.

[0001193125-16-439878:notes:130]
The Company uses some custom components that are
 not commonly used by its competitors, and new products introduced
 by the Company often utilize custom components available from only
 one source. When a component or product uses new technologies,
 initial capacity constraints may exist until the suppliers’
 yields have matured or manufacturing capacity has increased. If the
 Company’s supply of components for a new or existing product
 were delayed or constrained, or if an outsourcing partner delayed
 shipments of completed products to the Company, the Company’s
 financial condition and operating results could be materially
 adversely affected. The Company’s business and financial
 performance could also be materially adversely affected depending
 on the time required to obtain sufficient quantities from the
 original source, or to identify and obtain sufficient quantities
 from an alternative source. Continued availability of these
 components at acceptable prices, or at all, may be affected if
 those suppliers concentrated on the production of common components
 instead of components customized to meet the Company’s
 requirements.

[0001193125-16-439878:notes:131]
The Company has entered into agreements for the
 supply of many components; however, there can be no guarantee that
 the Company will be able to extend or renew these agreements on
 similar terms, or at all. Therefore, the Company remains subject to
 significant risks of supply shortages and price increases that
 could materially adversely affect its financial condition and
 operating results.

[0001193125-16-439878:notes:132]
Substantially all of the Company’s hardware
 products are manufactured by outsourcing partners that are located
 primarily in Asia. A significant concentration of this
 manufacturing is currently performed by a small number of
 outsourcing partners, often in single locations. Certain of these
 outsourcing partners are the sole-sourced suppliers of components
 and manufacturers for many of the Company’s products.
 Although the Company works closely with its outsourcing partners on
 manufacturing schedules, the Company’s operating results
 could be adversely affected if its outsourcing partners were unable
 to meet their production commitments. The Company’s purchase
 commitments typically cover its requirements for periods up to 150
 days.

[0001193125-16-439878:notes:133]
Other Off-Balance Sheet Commitments

[0001193125-16-439878:notes:134]
Operating Leases

[0001193125-16-439878:notes:135]
The Company leases various equipment and
 facilities, including retail space, under noncancelable operating
 lease arrangements. The major facility leases are typically for
 terms not exceeding 10 years and generally contain multi-year
 renewal options. As of December 26, 2015, the Company had a
 total of 469 retail stores. Leases for retail space are for terms
 ranging from five to 20 years, the majority of which are for 10
 years, and often contain multi-year renewal options. As of
 December 26, 2015, the Company’s total future minimum
 lease payments under noncancelable operating leases were $6.6
 billion, of which $3.7 billion related to leases for retail
 space.

[0001193125-16-439878:notes:136]
Contingencies

[0001193125-16-439878:notes:137]
The Company is subject to various legal proceedings
 and claims that have arisen in the ordinary course of business and
 that have not been fully adjudicated, certain of which are
 discussed in Part II, Item 1 of this Form 10-Q under the
 heading “Legal Proceedings” and in Part II,
 Item 1A of this Form 10-Q under the heading “Risk
 Factors.” In the opinion of management, there was not at
 least a reasonable possibility the Company may have incurred a
 material loss, or a material loss in excess of a recorded accrual,
 with respect to loss contingencies for asserted legal and other
 claims. However, the outcome of litigation is inherently uncertain.
 Therefore, although management considers the likelihood of such an
 outcome to be remote, if one or more of these legal matters were
 resolved against the Company in a reporting period for amounts in
 excess of management’s expectations, the Company’s
 consolidated financial statements for that reporting period could
 be materially adversely affected.

[0001193125-16-439878:notes:138]
Apple Inc. v. Samsung Electronics Co., Ltd., et al.

[0001193125-16-439878:notes:139]
On August 24, 2012, a jury returned a verdict
 awarding the Company $1.05 billion in its lawsuit against Samsung
 Electronics Co., Ltd. and affiliated parties in the United States
 District Court, Northern District of California, San Jose Division.
 On March 6, 2014, the District Court entered final judgment in
 favor of the Company in the amount of approximately $930
 million. On May 18, 2015, the U.S. Court of Appeals for
 the Federal Circuit affirmed in part, and reversed in part, the
 decision of the District Court. As a result, the Court of Appeals
 ordered entry of final judgment on damages in the amount of
 approximately $548 million, with the District Court to determine
 supplemental damages and interest, as well as damages owed for
 products subject to the reversal in part. Samsung Electronics Co.,
 Ltd. paid $548 million to the Company in December 2015, which was
 included in net sales in the Condensed Consolidated Statement of
 Operations. Because the March 6, 2014 ruling remains
 subject to further proceedings, the Company has not recognized any
 further amounts in its results of operations.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001193125-16-439878:notes:140]
[same as prior period, unchanged from 0001193125-15-259935:notes:155]

[0001193125-16-439878:notes:141]
The following tables show the Company’s
 condensed consolidated financial statement details as of
 December 26, 2015 and September 26, 2015 (in
 millions):

[0001193125-16-439878:notes:142]
|  |  | December 26, 2015 |  |  | September 26, 2015 |  |
| Land and buildings |  | $ | 7,729 |  |  | $ | 6,956 |  |
| Machinery, equipment and internal-use software |  |  | 38,039 |  |  |  | 37,038 |  |
| Leasehold improvements |  |  | 5,574 |  |  |  | 5,263 |  |
| Gross property, plant and equipment |  |  | 51,342 |  |  |  | 49,257 |  |
| Accumulated depreciation and amortization |  |  | (29,042 | ) |  |  | (26,786 | ) |
| Total property, plant and equipment, net |  | $ | 22,300 |  |  | $ | 22,471 |  |
| Other Non-Current Liabilities |  |  |  |  |  |  |  |  |
|  |  | December 26, 2015 |  |  | September 26, 2015 |  |
| Deferred tax liabilities |  | $ | 21,617 |  |  | $ | 24,062 |  |
| Other non-current liabilities |  |  | 10,558 |  |  |  | 9,365 |  |
| Total other non-current liabilities |  | $ | 32,175 |  |  | $ | 33,427 |  |
