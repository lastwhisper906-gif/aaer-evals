# AAPL MD&A — 0001193125-16-439878


## mdna

[0001193125-16-439878:mdna:1]
[same as prior period, unchanged from 0001193125-15-259935:mdna:1]

[0001193125-16-439878:mdna:2]
[same as prior period, unchanged from 0001193125-15-259935:mdna:2]

[0001193125-16-439878:mdna:3]
[same as prior period, unchanged from 0001193125-15-259935:mdna:3]

[0001193125-16-439878:mdna:4]
[same as prior period, unchanged from 0001193125-15-259935:mdna:4]

[0001193125-16-439878:mdna:5]
[same as prior period, unchanged from 0001193125-15-259935:mdna:5]

[0001193125-16-439878:mdna:6]
The Company designs, manufactures and markets mobile communication and media devices, personal computers and portable digital music players, and sells a
variety of related software, services, accessories, networking solutions and third-party digital content and applications. The Company’s products and services include iPhone®, iPad®, Mac®, iPod®, Apple
Watch®, Apple TV®, a portfolio of consumer and professional software applications, iOS, OS X®, watchOS™ and tvOS™operating systems, iCloud®, Apple Pay® and a variety
of accessory, service and support offerings. The Company sells and delivers digital content and applications through the iTunes Store®, App
Store®, Mac App Store, TV App Store, iBooks Store™ and Apple Music™ (collectively “Internet Services”). The Company sells its products worldwide through its retail stores,
online stores and direct sales force, as well as through third-party cellular network carriers, wholesalers, retailers and value-added resellers. In addition, the Company sells a variety of third-party Apple compatible products, including
application software and various accessories through its online and retail stores. The Company sells to consumers, small and mid-sized businesses and education, enterprise and government customers.

[0001193125-16-439878:mdna:7]
[same as prior period, unchanged from 0001193125-15-259935:mdna:7]

[0001193125-16-439878:mdna:8]
The Company is committed to bringing the
best user experience to its customers through its innovative hardware, software and services. The Company’s business strategy leverages its unique ability to design and develop its own operating systems, hardware, application software and
services to provide its customers products and solutions with innovative design, superior ease-of-use and seamless integration. As part of its strategy, the Company continues to expand its platform for the discovery and delivery of digital content
and applications through its Internet Services, which allows customers to discover and download digital content, iOS, Mac, Apple Watch and Apple TV applications, and books through either a Mac or Windows-based computer or through iPhone, iPad and
iPod touch® devices (“iOS devices”) and Apple Watch. The Company also supports a community for the development of third-party software and hardware products and digital content that
complement the Company’s offerings. The Company believes a high-quality buying experience with knowledgeable salespersons who can convey the value of the Company’s products and services greatly enhances its ability to attract and retain
customers. Therefore, the Company’s strategy also includes building and expanding its own retail and online stores and its third-party distribution network to effectively reach more customers and provide them with a high-quality sales and
post-sales support experience. The Company believes ongoing investment in research and development (“R&D”), marketing and advertising is critical to the development and sale of innovative products and technologies.

[0001193125-16-439878:mdna:9]
Business Seasonality and Product Introductions

[0001193125-16-439878:mdna:10]
The Company has historically experienced higher net sales in its first quarter compared to other quarters in its fiscal year due in part to seasonal
holiday demand. Additionally, new product introductions can significantly impact net sales, product costs and operating expenses. Product introductions can also impact the Company’s net sales to its indirect distribution channels as these
channels are filled with new product inventory following a product introduction, and often, channel inventory of a particular product declines as the next related major product launch approaches. Net sales can also be affected when consumers and
distributors anticipate a product introduction. However, neither historical seasonal patterns nor historical patterns of product introductions should be considered reliable indicators of the Company’s future pattern of product introductions,
future net sales or financial performance.

[0001193125-16-439878:mdna:11]
First Quarter Fiscal 2016 Highlights

[0001193125-16-439878:mdna:12]
Net sales grew 2% or $1.3 billion during the first quarter of 2016 compared to the first quarter of 2015, primarily driven by strong growth in Other
Products and in Services, partially offset by lower iPad net sales. Additionally, the effect of weakness in most foreign currencies relative to the U.S. dollar negatively impacted the Company’s net sales. Other Products and Services net sales
increased in all of the Company’s reportable operating segments.

[0001193125-16-439878:mdna:13]
During the first quarter of 2016, the Company released OS X El Capitan, its 12th major release of OS X, and its new tvOS™ operating system. Additionally, the Company began shipping iPad Pro and the new Apple TV, and launched its Apple TV App Store.

[0001193125-16-439878:mdna:14]
[same as prior period, unchanged from 0001193125-15-259935:mdna:15]

[0001193125-16-439878:mdna:15]
The following table shows net sales by operating
segment and net sales and unit sales by product during the three months ended December 26, 2015 and December 27, 2014 (dollars in millions and units in thousands):

[0001193125-16-439878:mdna:16]
|  |  | Three Months Ended |  |
|  |  | December 26, 2015 |  |  | December 27, 2014 |  |  | Change |  |
| Net Sales by Operating Segment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 29,325 |  |  | $ | 30,566 |  |  |  | (4)% |  |
| Europe |  |  | 17,932 |  |  |  | 17,214 |  |  |  | 4% |  |
| Greater China |  |  | 18,373 |  |  |  | 16,144 |  |  |  | 14% |  |
| Japan |  |  | 4,794 |  |  |  | 5,448 |  |  |  | (12)% |  |
| Rest of Asia Pacific |  |  | 5,448 |  |  |  | 5,227 |  |  |  | 4% |  |
| Total net sales |  | $ | 75,872 |  |  | $ | 74,599 |  |  |  | 2% |  |
| Net Sales by Product: |  |  |  |  |  |  |  |  |  |  |  |  |
| iPhone (1) |  | $ | 51,635 |  |  | $ | 51,182 |  |  |  | 1% |  |
| iPad (1) |  |  | 7,084 |  |  |  | 8,985 |  |  |  | (21)% |  |
| Mac (1) |  |  | 6,746 |  |  |  | 6,944 |  |  |  | (3)% |  |
| Services (2) |  |  | 6,056 |  |  |  | 4,799 |  |  |  | 26% |  |
| Other Products (1)(3) |  |  | 4,351 |  |  |  | 2,689 |  |  |  | 62% |  |
| Total net sales |  | $ | 75,872 |  |  | $ | 74,599 |  |  |  | 2% |  |
| Unit Sales by Product: |  |  |  |  |  |  |  |  |  |  |  |  |
| iPhone |  |  | 74,779 |  |  |  | 74,468 |  |  |  | 0% |  |
| iPad |  |  | 16,122 |  |  |  | 21,419 |  |  |  | (25)% |  |
| Mac |  |  | 5,312 |  |  |  | 5,519 |  |  |  | (4)% |  |

[0001193125-16-439878:mdna:17]
|  | (1) | Includes deferrals and amortization of related software upgrade rights and non-software services. |  |

[0001193125-16-439878:mdna:18]
|  | (2) | Includes revenue from Internet Services, AppleCare®, Apple Pay, licensing and other services. |  |

[0001193125-16-439878:mdna:19]
|  | (3) | Includes sales of Apple TV, Apple Watch, Beats® products, iPod and Apple-branded and third-party accessories. |  |

[0001193125-16-439878:mdna:20]
[same as prior period, unchanged from 0001193125-15-259935:mdna:22]

[0001193125-16-439878:mdna:21]
[same as prior period, unchanged from 0001193125-15-259935:mdna:23]

[0001193125-16-439878:mdna:22]
The following table presents iPhone net sales and unit sales information for the first quarter of 2016 and 2015 (dollars in millions and units in
thousands):

[0001193125-16-439878:mdna:23]
|  |  | Three Months Ended |  |
|  |  | December 26, 2015 |  |  | December 27, 2014 |  |  | Change |  |
| Net sales |  | $ | 51,635 |  |  | $ | 51,182 |  |  |  | 1% |  |
| Percentage of total net sales |  |  | 68% |  |  |  | 69% |  |  |  |  |  |
| Unit sales |  |  | 74,779 |  |  |  | 74,468 |  |  |  | 0% |  |

[0001193125-16-439878:mdna:24]
iPhone net sales and unit sales during the first quarter of 2016 were slightly higher than the first quarter of 2015.
Overall average selling prices (“ASPs”) for iPhone were flat year-over-year.

[0001193125-16-439878:mdna:25]
[same as prior period, unchanged from 0001193125-15-259935:mdna:27]

[0001193125-16-439878:mdna:26]
The following table presents iPad net sales and unit sales information for the first quarter of 2016 and 2015 (dollars in millions and units in
thousands):

[0001193125-16-439878:mdna:27]
|  |  | Three Months Ended |  |
|  |  | December 26, 2015 |  |  | December 27, 2014 |  |  | Change |  |
| Net sales |  | $ | 7,084 |  |  | $ | 8,985 |  |  |  | (21)% |  |
| Percentage of total net sales |  |  | 9% |  |  |  | 12% |  |  |  |  |  |
| Unit sales |  |  | 16,122 |  |  |  | 21,419 |  |  |  | (25)% |  |

[0001193125-16-439878:mdna:28]
Net sales and unit sales for iPad declined during the first quarter of 2016 compared to the first quarter of 2015. The
Company believes the decline in iPad sales is due in part to a longer repurchase cycle for iPads and some level of cannibalization from the Company’s other products. iPad ASPs increased by 5% year-over-year due primarily to a shift in mix to
higher-priced iPads, including iPad Pro, partially offset by the effect of weakness in most foreign currencies relative to the U.S. dollar.

[0001193125-16-439878:mdna:29]
[same as prior period, unchanged from 0001193125-15-259935:mdna:31]

[0001193125-16-439878:mdna:30]
The following table presents Mac net sales and unit sales information for the first quarter of 2016 and 2015 (dollars in millions and units in thousands):

[0001193125-16-439878:mdna:31]
|  |  | Three Months Ended |  |
|  |  | December 26, 2015 |  |  | December 27, 2014 |  |  | Change |  |
| Net sales |  | $ | 6,746 |  |  | $ | 6,944 |  |  |  | (3)% |  |
| Percentage of total net sales |  |  | 9% |  |  |  | 9% |  |  |  |  |  |
| Unit sales |  |  | 5,312 |  |  |  | 5,519 |  |  |  | (4)% |  |

[0001193125-16-439878:mdna:32]
Mac unit sales declined 4% on a year-over-year basis, which was less than the contraction in the overall personal
computer market during the same period. Mac ASPs during the first quarter of 2016 were flat compared to the first quarter of 2015.

[0001193125-16-439878:mdna:33]
[same as prior period, unchanged from 0001193125-15-259935:mdna:35]

[0001193125-16-439878:mdna:34]
The
following table presents net sales information of Services for the first quarter of 2016 and 2015 (dollars in millions):

[0001193125-16-439878:mdna:35]
|  |  | Three Months Ended |  |
|  |  | December 26, 2015 |  |  | December 27, 2014 |  |  | Change |  |
| Net sales |  | $ | 6,056 |  |  | $ | 4,799 |  |  |  | 26% |  |
| Percentage of total net sales |  |  | 8% |  |  |  | 6% |  |  |  |  |  |

[0001193125-16-439878:mdna:36]
During the first quarter of 2016, the Company received $548 million from Samsung Electronics Co., Ltd. related to its
patent infringement lawsuit, which was recorded as licensing net sales within Services. The remainder of the year-over-year growth in net sales of Services was due primarily to higher App Store and AppleCare sales.

[0001193125-16-439878:mdna:37]
[same as prior period, unchanged from 0001193125-15-259935:mdna:39]

[0001193125-16-439878:mdna:38]
The Company manages its business
primarily on a geographic basis. The Company’s reportable operating segments consist of the Americas, Europe, Greater China, Japan and Rest of Asia Pacific. The Americas segment includes both North and South America. The Europe segment includes
European countries, as well as India, the Middle East and Africa. The Greater China segment includes China, Hong Kong and Taiwan. The Rest of Asia Pacific segment includes Australia and those Asian countries not included in the Company’s other
reportable operating segments. Although, each reportable operating segment provides similar hardware and software products and similar services, they are managed separately to better align with the location of the Company’s customers and
distribution partners and the unique market dynamics of each geographic region. Further information regarding the Company’s reportable operating segments can be found in Part I, Item 1 of this Form 10-Q in the Notes to Condensed
Consolidated Financial Statements, in Note 11, “Segment Information and Geographic Data.”

[0001193125-16-439878:mdna:39]
[same as prior period, unchanged from 0001193125-15-259935:mdna:41]

[0001193125-16-439878:mdna:40]
The following table presents Americas net sales information for the first quarter of 2016 and 2015 (dollars in millions):

[0001193125-16-439878:mdna:41]
|  |  | Three Months Ended |  |
|  |  | December 26, 2015 |  |  | December 27, 2014 |  |  | Change |  |
| Net sales |  | $ | 29,325 |  |  | $ | 30,566 |  |  |  | (4)% |  |
| Percentage of total net sales |  |  | 39% |  |  |  | 41% |  |  |  |  |  |

[0001193125-16-439878:mdna:42]
Americas net sales decreased during the first quarter of 2016 compared to the first quarter of 2015 due primarily to
lower net sales of iPhone and the effect of weakness in foreign currencies relative to the U.S. dollar, partially offset by an increase in net sales of Other Products.

[0001193125-16-439878:mdna:43]
[same as prior period, unchanged from 0001193125-15-259935:mdna:45]

[0001193125-16-439878:mdna:44]
The following table presents Europe net sales
information for the first quarter of 2016 and 2015 (dollars in millions):

[0001193125-16-439878:mdna:45]
|  |  | Three Months Ended |  |
|  |  | December 26, 2015 |  |  | December 27, 2014 |  |  | Change |  |
| Net sales |  | $ | 17,932 |  |  | $ | 17,214 |  |  |  | 4% |  |
| Percentage of total net sales |  |  | 24% |  |  |  | 23% |  |  |  |  |  |

[0001193125-16-439878:mdna:46]
The year-over-year increase in Europe net sales during the first quarter of 2016 was driven primarily by growth in net
sales of iPhone, partially offset by the effect of weakness in foreign currencies relative to the U.S. dollar.

[0001193125-16-439878:mdna:47]
[same as prior period, unchanged from 0001193125-15-259935:mdna:49]

[0001193125-16-439878:mdna:48]
The
following table presents Greater China net sales information for the first quarter of 2016 and 2015 (dollars in millions):

[0001193125-16-439878:mdna:49]
|  |  | Three Months Ended |  |
|  |  | December 26, 2015 |  |  | December 27, 2014 |  |  | Change |  |
| Net sales |  | $ | 18,373 |  |  | $ | 16,144 |  |  |  | 14% |  |
| Percentage of total net sales |  |  | 24% |  |  |  | 22% |  |  |  |  |  |

[0001193125-16-439878:mdna:50]
The Greater China segment experienced year-over-year growth in net sales during the first quarter of 2016 that was
significantly higher than the growth rate for the Company overall. Greater China experienced year-over-year increases in net sales driven primarily by strong iPhone performance, partially offset by the effect of weakness in foreign currencies
relative to the U.S. dollar.

[0001193125-16-439878:mdna:51]
[same as prior period, unchanged from 0001193125-15-259935:mdna:53]

[0001193125-16-439878:mdna:52]
The following table
presents Japan net sales information for the first quarter of 2016 and 2015 (dollars in millions):

[0001193125-16-439878:mdna:53]
|  |  | Three Months Ended |  |
|  |  | December 26, 2015 |  |  | December 27, 2014 |  |  | Change |  |
| Net sales |  | $ | 4,794 |  |  | $ | 5,448 |  |  |  | (12)% |  |
| Percentage of total net sales |  |  | 6% |  |  |  | 7% |  |  |  |  |  |

[0001193125-16-439878:mdna:54]
Japan net sales decreased during the first quarter of 2016 compared to the first quarter of 2015 due primarily to lower
net sales of iPhone and the effect of weakness in the Japanese yen relative to the U.S. dollar, partially offset by higher net sales of Services.

[0001193125-16-439878:mdna:55]
Rest of Asia
Pacific

[0001193125-16-439878:mdna:56]
The following table presents Rest of Asia Pacific net sales information for the first quarter of 2016 and 2015 (dollars in millions):

[0001193125-16-439878:mdna:57]
|  |  | Three Months Ended |  |
|  |  | December 26, 2015 |  |  | December 27, 2014 |  |  | Change |  |
| Net sales |  | $ | 5,448 |  |  | $ | 5,227 |  |  |  | 4% |  |
| Percentage of total net sales |  |  | 7% |  |  |  | 7% |  |  |  |  |  |

[0001193125-16-439878:mdna:58]
The year-over-year increase in Rest of Asia Pacific net sales during the first quarter of 2016 primarily reflects higher
demand for iPhone, partially offset by the effect of weakness in foreign currencies relative to the U.S. dollar.

[0001193125-16-439878:mdna:59]
[same as prior period, unchanged from 0001193125-15-259935:mdna:61]

[0001193125-16-439878:mdna:60]
Gross margin for the first quarter of 2016 and 2015 was as follows (dollars in millions):

[0001193125-16-439878:mdna:61]
|  |  | Three Months Ended |  |
|  |  | December 26, 2015 |  |  | December 27, 2014 |  |
| Net sales |  | $ | 75,872 |  |  | $ | 74,599 |  |
| Cost of sales |  |  | 45,449 |  |  |  | 44,858 |  |
| Gross margin |  | $ | 30,423 |  |  | $ | 29,741 |  |
| Gross margin percentage |  |  | 40.1% |  |  |  | 39.9% |  |

[0001193125-16-439878:mdna:62]
The year-over-year increase in the gross margin percentage during the first quarter of 2016 was driven primarily by a
favorable shift in mix to products with higher margins, partially offset by the effect of weakness in most foreign currencies relative to the U.S. dollar.

[0001193125-16-439878:mdna:63]
The Company anticipates gross margin during the second quarter of 2016 to be between 39% and 39.5%. The foregoing statement regarding the Company’s
expected gross margin percentage in the second quarter of 2016 is forward-looking and could differ from actual results. The Company’s future gross margins can be impacted by multiple factors including, but not limited to, those set forth in
Part II, Item 1A of this Form 10-Q under the heading “Risk Factors” and those described in this paragraph. In general, the Company believes gross margins will remain under downward pressure due to a variety of factors, including
continued industry wide global product pricing pressures, increased competition, compressed product life cycles, product transitions, potential increases in the cost of components, and potential strengthening of the U.S. dollar, as well as potential
increases in the costs of outside manufacturing services and a potential shift in the Company’s sales mix towards products with lower gross margins. In response to competitive pressures, the Company expects it will continue to take product
pricing actions, which would adversely affect gross margins. Gross margins could also be affected by the Company’s ability to manage product quality and warranty costs effectively and to stimulate demand for certain of its products. Due to the
Company’s significant international operations, its financial condition and operating results, including gross margins, could be significantly affected by fluctuations in exchange rates.

[0001193125-16-439878:mdna:64]
[same as prior period, unchanged from 0001193125-15-259935:mdna:66]

[0001193125-16-439878:mdna:65]
Operating expenses for the first quarter of
2016 and 2015 were as follows (dollars in millions):

[0001193125-16-439878:mdna:66]
|  |  | Three Months Ended |  |
|  |  | December 26, 2015 |  |  | December 27, 2014 |  |  | Change |  |
| Research and development |  | $ | 2,404 |  |  | $ | 1,895 |  |  |  | 27% |  |
| Percentage of total net sales |  |  | 3% |  |  |  | 3% |  |  |  |  |  |
| Selling, general and administrative |  | $ | 3,848 |  |  | $ | 3,600 |  |  |  | 7% |  |
| Percentage of total net sales |  |  | 5% |  |  |  | 5% |  |  |  |  |  |
| Total operating expenses |  | $ | 6,252 |  |  | $ | 5,495 |  |  |  | 14% |  |
| Percentage of total net sales |  |  | 8% |  |  |  | 7% |  |  |  |  |  |

[0001193125-16-439878:mdna:67]
[same as prior period, unchanged from 0001193125-15-259935:mdna:69]

[0001193125-16-439878:mdna:68]
The
year-over-year increase in R&D expense during the first quarter of 2016 was driven primarily by an increase in headcount and related expenses, including share-based compensation costs, and material costs to support expanded R&D activities.
The Company continues to believe that focused investments in R&D are critical to its future growth and competitive position in the marketplace and are directly related to timely development of new and updated products that are central to the
Company’s core business strategy.

[0001193125-16-439878:mdna:69]
[same as prior period, unchanged from 0001193125-15-259935:mdna:71]

[0001193125-16-439878:mdna:70]
The year-over-year increase in selling, general and administrative expense during the first quarter of 2016 was due primarily to increased headcount and
related expenses, including share-based compensation costs.

[0001193125-16-439878:mdna:71]
[same as prior period, unchanged from 0001193125-15-259935:mdna:73]

[0001193125-16-439878:mdna:72]
Other income/(expense), net for the first quarter of 2016 and 2015 was as follows (dollars in millions):

[0001193125-16-439878:mdna:73]
|  |  | Three Months Ended |  |
|  |  | December 26, 2015 |  |  | December 27, 2014 |  |  | Change |  |
| Interest and dividend income |  | $ | 941 |  |  | $ | 654 |  |  |  |  |  |
| Interest expense |  |  | (276 | ) |  |  | (131 | ) |  |  |  |  |
| Other expense, net |  |  | (263 | ) |  |  | (353 | ) |  |  |  |  |
| Total other income/(expense), net |  | $ | 402 |  |  | $ | 170 |  |  |  | 136% |  |

[0001193125-16-439878:mdna:74]
The increase in other income/(expense), net during the first quarter of 2016 compared to the first quarter of 2015 was
due primarily to lower expenses associated with foreign exchange activity and higher interest income, partially offset by higher interest expense on debt. The weighted-average interest rate earned by the Company on its cash, cash equivalents and
marketable securities was 1.65% and 1.41% in the first quarter of 2016 and 2015, respectively.

[0001193125-16-439878:mdna:75]
[same as prior period, unchanged from 0001193125-15-259935:mdna:77]

[0001193125-16-439878:mdna:76]
Provision for income taxes and effective tax rates for the first quarter of 2016 and 2015 were as follows (dollars in millions):

[0001193125-16-439878:mdna:77]
|  |  | Three Months Ended |  |
|  |  | December 26, 2015 |  |  | December 27, 2014 |  |
| Provision for income taxes |  | $ | 6,212 |  |  | $ | 6,392 |  |
| Effective tax rate |  |  | 25.3% |  |  |  | 26.2% |  |

[0001193125-16-439878:mdna:78]
The Company’s effective tax rates for the first quarter of 2016 and 2015 differ from the statutory federal income
tax rate of 35% due primarily to certain undistributed foreign earnings, a substantial portion of which was generated by subsidiaries organized in Ireland, for which no U.S. taxes are provided when such earnings are intended to be indefinitely
reinvested outside the U.S. The lower effective tax rate during the first quarter of 2016 compared to the first quarter of 2015 was due primarily to a different geographic mix of earnings as well as the retroactive reinstatement of the U.S. federal
R&D tax credit.

[0001193125-16-439878:mdna:79]
The U.S. Internal Revenue Service is currently examining the years 2010 through 2012, and all years prior to 2010 are closed. In
addition, the Company is subject to audits by state, local and foreign tax authorities. Management believes that adequate provisions have been made for any adjustments that may result from tax examinations. However, the outcome of tax audits
cannot be predicted with certainty. If any issues addressed in the Company’s tax audits are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the
period such resolution occurs.

[0001193125-16-439878:mdna:80]
On June 11, 2014, the European Commission issued an opening decision initiating a formal investigation against
Ireland for alleged state aid to the Company. The opening decision concerns the allocation of profits for taxation purposes of the Irish branches of two subsidiaries of the Company. The Company believes the European Commission’s assertions are
without merit. If the European Commission were to conclude against Ireland, the European Commission could require Ireland to recover from the Company past taxes covering a period of up to 10 years reflective of the disallowed state aid. While such
amount could be material, as of December 26, 2015 the Company is unable to estimate the impact.

[0001193125-16-439878:mdna:81]
[same as prior period, unchanged from 0001193125-15-259935:mdna:83]

[0001193125-16-439878:mdna:82]
In January 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2016-01,
Financial Instruments – Overall (Subtopic 825-10) (“ASU 2016-01”), which updates certain aspects of recognition, measurement, presentation and disclosure of financial instruments. ASU 2016-01 will be effective for the Company
beginning in its first quarter of 2019 and early adoption is not permitted. The Company does not believe the adoption of the new financial instruments standard will have a material impact on its consolidated financial statements.

[0001193125-16-439878:mdna:83]
In May 2014, the FASB issued ASU No. 2014-09, Revenue from Contracts with Customers (Topic 606) (“ASU 2014-09”), which amends the existing
accounting standards for revenue recognition. ASU 2014-09 is based on principles that govern the recognition of revenue at an amount an entity expects to be entitled when products are transferred to customers.

[0001193125-16-439878:mdna:84]
The original effective date for ASU 2014-09 would have required the Company to adopt beginning in its first quarter of 2018. In August 2015, the FASB
issued ASU No. 2015-14, Revenue from Contracts with Customers (Topic 606) – Deferral of the Effective Date, which defers the effective date of ASU 2014-09 for one year and permits early adoption as early as the original effective date of
ASU 2014-09. Accordingly, the Company may adopt the standard in either its first quarter of 2018 or 2019. The new revenue standard may be applied retrospectively to each prior period presented or retrospectively with the cumulative effect recognized
as of the date of adoption. The Company is currently evaluating the timing of its adoption and the impact of adopting the new revenue standard on its consolidated financial statements.

[0001193125-16-439878:mdna:85]
Liquidity and Capital Resources

[0001193125-16-439878:mdna:86]
The following tables present selected financial information and statistics as of and during the three months ended December 26, 2015 and
September 26, 2015 (in millions):

[0001193125-16-439878:mdna:87]
|  |  | December 26, 2015 |  |  | September 26, 2015 |  |
| Cash, cash equivalents and marketable securities |  | $ | 215,739 |  |  | $ | 205,666 |  |
| Property, plant and equipment, net |  | $ | 22,300 |  |  | $ | 22,471 |  |
| Commercial paper |  | $ | 7,259 |  |  | $ | 8,499 |  |
| Total term debt |  | $ | 55,704 |  |  | $ | 55,963 |  |
| Working capital |  | $ | 127 |  |  | $ | 8,768 |  |
|  |  | Three Months Ended |  |
|  |  | December 26, 2015 |  |  | December 27, 2014 |  |
| Cash generated by operating activities |  | $ | 27,463 |  |  | $ | 33,722 |  |
| Cash used in investing activities |  | $ | (20,450 | ) |  | $ | (21,165 | ) |
| Cash used in financing activities |  | $ | (11,444 | ) |  | $ | (6,923 | ) |

[0001193125-16-439878:mdna:88]
[same as prior period, unchanged from 0001193125-15-259935:mdna:89]

[0001193125-16-439878:mdna:89]
As of December 26, 2015 and September 26, 2015, the Company’s cash, cash equivalents and marketable securities held by foreign
subsidiaries were $200.1 billion and $186.9 billion, respectively, and are generally based in U.S. dollar-denominated holdings. Amounts held by foreign subsidiaries are generally subject to U.S. income
taxation on repatriation to the U.S. The Company’s marketable securities investment portfolio is invested primarily in highly-rated securities and its investment policy generally limits the amount of credit exposure to any one issuer. The
policy requires investments generally to be investment grade with the objective of minimizing the potential risk of principal loss.

[0001193125-16-439878:mdna:90]
During the three
months ended December 26, 2015, cash generated from operating activities of $27.5 billion was a result of $18.4 billion of net income, non-cash adjustments to net income of $5.6 billion and an increase in the net change in operating assets and
liabilities of $3.5 billion. Cash used in investing activities of $20.5 billion during the three months ended December 26, 2015 consisted primarily of cash used for purchases of marketable securities, net of sales and maturities, of $16.1
billion and cash used to acquire property, plant and equipment of $3.6 billion. Cash used in financing activities of $11.4 billion during the three months ended December 26, 2015 consisted primarily of cash used to repurchase common stock of
$6.9 billion, and cash used to pay dividends and dividend equivalents of $3.0 billion.

[0001193125-16-439878:mdna:91]
During the three months ended December 27, 2014, cash
generated from operating activities of $33.7 billion was a result of $18.0 billion of net income, non-cash adjustments to net income of $5.7 billion and an increase in the net change in operating assets and liabilities of $10.0 billion. Cash used in
investing activities of $21.2 billion during the three months ended December 27, 2014 consisted primarily of cash used for purchases of marketable securities, net of sales and maturities, of $17.9 billion and cash used to acquire property,
plant and equipment of $3.2 billion. Cash used in financing activities of $6.9 billion during the three months ended December 27, 2014 consisted primarily of cash used to repurchase common stock of $5.0 billion, cash used to pay dividends and
dividend equivalents of $2.8 billion and cash used for repayments of commercial paper, net of proceeds, of $2.4 billion, partially offset by proceeds from the issuance of long-term debt of $3.5 billion.

[0001193125-16-439878:mdna:92]
[same as prior period, unchanged from 0001193125-15-259935:mdna:93]

[0001193125-16-439878:mdna:93]
The Company’s capital expenditures were
$2.3 billion during the first quarter of 2016. The Company anticipates utilizing approximately $15.0 billion for capital expenditures during 2016, which includes product tooling and manufacturing process equipment; data centers; corporate facilities
and infrastructure, including information systems hardware, software and enhancements; and retail store facilities.

[0001193125-16-439878:mdna:94]
[same as prior period, unchanged from 0001193125-15-259935:mdna:95]

[0001193125-16-439878:mdna:95]
The Company
issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses the net proceeds from the commercial paper program for general corporate purposes, including dividends and share
repurchases. As of December 26, 2015, the Company had $7.3 billion of Commercial Paper outstanding, with a weighted-average interest rate of 0.20% and maturities generally less than nine months.

[0001193125-16-439878:mdna:96]
As of December 26, 2015, the Company has outstanding floating- and fixed-rate notes for an aggregate principal amount of $55.5 billion (collectively
the “Notes”). The Company has entered, and in the future may enter, into interest rate swaps to manage interest rate risk on the Notes. In addition, the Company has entered, and in the future may enter, into currency swaps to manage
foreign currency risk on the Notes.

[0001193125-16-439878:mdna:97]
Further information regarding the Company’s debt issuances and related hedging activity can be found in
Part I, Item 1 of this Form 10-Q in the Notes to Condensed Consolidated Financial Statements, in Note 2, “Financial Instruments” and Note 6, “Debt.”

[0001193125-16-439878:mdna:98]
[same as prior period, unchanged from 0001193125-15-259935:mdna:98]

[0001193125-16-439878:mdna:99]
In April 2015, the Company’s Board
of Directors increased the share repurchase program authorization from $90 billion to $140 billion of the Company’s common stock, increasing the expected total size of the capital return program to $200 billion. The Company expects to execute
the capital return program by the end of March 2017 by paying dividends and dividend equivalents, repurchasing shares and remitting withheld taxes related to net share settlement of restricted stock units. To assist in funding its capital return
program, the Company expects to continue to access the debt markets, both domestically and internationally. As of December 26, 2015, $110 billion of the share repurchase program has been utilized. The Company’s share repurchase program
does not obligate it to acquire any specific number of shares. Under the program, shares may be repurchased in privately negotiated or open market transactions, including under plans complying with Rule 10b5-1 under the Exchange Act.

[0001193125-16-439878:mdna:100]
In April 2015, the Company’s Board of Directors raised the quarterly cash dividend by 11%. The Company plans to increase its dividend on an annual
basis subject to declaration by the Board of Directors.

[0001193125-16-439878:mdna:101]
The following table presents the Company’s dividends, dividend equivalents, share
repurchases and net share settlement activity from the start of the capital return program in August 2012 through December 26, 2015 (in millions):

[0001193125-16-439878:mdna:102]
|  |  | Dividends andDividendEquivalentsPaid |  |  | AcceleratedShareRepurchases |  |  | Open MarketShareRepurchases |  |  | TaxesRelated toSettlement ofEquity Awards |  |  | Total |  |
| Q1 2016 |  | $ | 2,969 |  |  | $ | 3,000 |  |  | $ | 3,000 |  |  | $ | 597 |  |  | $ | 9,566 |  |
| 2015 |  |  | 11,561 |  |  |  | 6,000 |  |  |  | 30,026 |  |  |  | 1,499 |  |  |  | 49,086 |  |
| 2014 |  |  | 11,126 |  |  |  | 21,000 |  |  |  | 24,000 |  |  |  | 1,158 |  |  |  | 57,284 |  |
| 2013 |  |  | 10,564 |  |  |  | 13,950 |  |  |  | 9,000 |  |  |  | 1,082 |  |  |  | 34,596 |  |
| 2012 |  |  | 2,488 |  |  |  | 0 |  |  |  | 0 |  |  |  | 56 |  |  |  | 2,544 |  |
| Total |  | $ | 38,708 |  |  | $ | 43,950 |  |  | $ | 66,026 |  |  | $ | 4,392 |  |  | $ | 153,076 |  |

[0001193125-16-439878:mdna:103]
[same as prior period, unchanged from 0001193125-15-259935:mdna:103]

[0001193125-16-439878:mdna:104]
[same as prior period, unchanged from 0001193125-15-259935:mdna:104]

[0001193125-16-439878:mdna:105]
[same as prior period, unchanged from 0001193125-15-259935:mdna:105]

[0001193125-16-439878:mdna:106]
The Company’s major facility leases are typically for terms not exceeding 10 years and generally contain multi-year renewal options. As of
December 26, 2015, the Company had a total of 469 retail stores. Leases for retail space are for terms ranging from five to 20 years, the majority of which are for 10 years, and often contain multi-year renewal options. As of December 26,
2015, the Company’s total future minimum lease payments under noncancelable operating leases were $6.6 billion, of which $3.7 billion related to leases for retail space.

[0001193125-16-439878:mdna:107]
[same as prior period, unchanged from 0001193125-15-259935:mdna:107]

[0001193125-16-439878:mdna:108]
The Company utilizes several outsourcing partners to manufacture sub-assemblies for the Company’s products and to perform final assembly and testing
of finished products. These outsourcing partners acquire components and build product based on demand information supplied by the Company, which typically covers periods up to 150 days. The Company also obtains individual components for its products
from a wide variety of individual suppliers. Consistent with industry practice, the Company acquires components through a combination of purchase orders, supplier contracts, and open orders based on projected demand information. Where
appropriate, the purchases are applied to inventory component prepayments that are outstanding with the respective supplier. As of December 26, 2015, the Company had outstanding off-balance sheet third-party
manufacturing commitments and component purchase commitments of $20.7 billion.

[0001193125-16-439878:mdna:109]
[same as prior period, unchanged from 0001193125-15-259935:mdna:109]

[0001193125-16-439878:mdna:110]
In addition to the commitments mentioned above, the Company had other off-balance sheet obligations of $7.9 billion as of December 26, 2015 that
consisted of commitments to acquire capital assets, including product tooling and manufacturing process equipment, and commitments related to inventory prepayments, advertising, licensing, R&D, internet and telecommunications services, energy
and other obligations.

[0001193125-16-439878:mdna:111]
The Company’s other non-current liabilities in the Condensed Consolidated Balance Sheets consist primarily of deferred
tax liabilities, gross unrecognized tax benefits and the related gross interest and penalties. As of December 26, 2015, the Company had non-current deferred tax liabilities of $21.6 billion. Additionally, as of December 26, 2015, the
Company had gross unrecognized tax benefits of $7.4 billion and an additional $1.4 billion for gross interest and penalties classified as non-current liabilities. At this time, the Company is unable to make a reasonably reliable estimate of the
timing of payments due to uncertainties in the timing of tax audit outcomes.

[0001193125-16-439878:mdna:112]
[same as prior period, unchanged from 0001193125-15-259935:mdna:112]

[0001193125-16-439878:mdna:113]
The Company generally does not indemnify end-users of its operating system and application software against legal claims that the software infringes
third-party intellectual property rights. Other agreements entered into by the Company sometimes include indemnification provisions under which the Company could be subject to costs and/or damages in the event of an infringement claim against the
Company or an indemnified third-party. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss with respect to indemnification of end-users of its operating system or application
software for infringement of third-party intellectual property rights.

[0001193125-16-439878:mdna:114]
The Company offers an iPhone Upgrade Program, which is available to customers
who purchase an iPhone 6s and 6s Plus in one of its U.S. physical retail stores and activate the purchased iPhone with one of the four national carriers. The iPhone Upgrade Program provides customers the right to trade in that iPhone for a new
iPhone, provided certain conditions are met. One of the conditions of this program requires the customer to finance the initial purchase price of the iPhone with a third-party lender. Upon exercise of the trade-in right and purchase of a new iPhone,
the Company satisfies the customer’s outstanding balance due to the third-party lender on the original device. The Company accounts for the trade-in right as a guarantee liability and recognizes arrangement revenue net of the fair value of such
right with subsequent changes to the guarantee liability recognized within revenue.

[0001193125-16-439878:mdna:115]
The Company has entered into indemnification agreements with its
directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance
expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of
prior indemnification claims and the unique facts and circumstances involved in each claim. However, the Company maintains directors and officers liability insurance coverage to reduce its exposure to such obligations.

[0001193125-16-439878:mdna:116]
[same as prior period, unchanged from 0001193125-15-259935:mdna:115]

[0001193125-16-439878:mdna:117]
The preparation of financial statements and related disclosures in conformity with U.S. generally accepted accounting principles (“GAAP”) and
the Company’s discussion and analysis of its financial condition and operating results require the Company’s management to make judgments, assumptions and estimates that affect the amounts reported in its condensed consolidated financial
statements and accompanying notes. Management bases its estimates on historical experience and on various other assumptions it believes to be reasonable under the circumstances, the results of which form the basis for making judgments about the
carrying values of assets and liabilities. Actual results may differ from these estimates, and such differences may be material.

[0001193125-16-439878:mdna:118]
Note 1,
“Summary of Significant Accounting Policies” in Part I, Item 1 of this Form 10-Q and in the Notes to Consolidated Financial Statements in Part II, Item 8 of the 2015 Form 10-K, and “Critical Accounting Policies and
Estimates” in Part I, Item 7 of the 2015 Form 10-K describe the significant accounting policies and methods used in the preparation of the Company’s condensed consolidated financial statements. There have been no material changes to
the Company’s critical accounting policies and estimates since the 2015 Form 10-K.
