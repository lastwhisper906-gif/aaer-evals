# AAPL note change history — 0001193125-15-259935 → 0001193125-16-439878


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-01-27):
[0001193125-16-439878:note_history:1]
The following table shows changes in the
 Company’s accrued warranties and related costs for the three
 months ended December 26, 2015 and December 27, 2014 (in
 millions):
  (was, 2015-07-22, similarity 0.8869):
[0001193125-15-259935:note_history:1]
The following table shows changes in the
 Company’s accrued warranties and related costs for the three-
 and nine-month periods ended June 27, 2015 and June 28,
 2014 (in millions):

- changed (2016-01-27):
[0001193125-16-439878:note_history:2]
|  |  | Three Months Ended |  |
|  |  | December 26, 2015 |  |  | December 27, 2014 |  |
| Beginning accrued warranty and related costs |  | $ | 4,780 |  |  | $ | 4,159 |  |
| Cost of warranty claims |  |  | (1,269 | ) |  |  | (1,044 | ) |
| Accruals for product warranty |  |  | 1,725 |  |  |  | 2,080 |  |
| Ending accrued warranty and related costs |  | $ | 5,236 |  |  | $ | 5,195 |  |
  (was, 2015-07-22, similarity 0.7442):
[0001193125-15-259935:note_history:2]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 27, 2015 |  |  | June 28, 2014 |  |  | June 27, 2015 |  |  | June 28, 2014 |  |
| Beginning accrued warranty and related costs |  | $ | 5,143 |  |  | $ | 4,368 |  |  | $ | 4,159 |  |  | $ | 2,967 |  |
| Cost of warranty claims |  |  | (1,077 | ) |  |  | (882 | ) |  |  | (3,151 | ) |  |  | (2,811 | ) |
| Accruals for product warranty |  |  | 1,071 |  |  |  | 756 |  |  |  | 4,129 |  |  |  | 4,086 |  |
| Ending accrued warranty and related costs |  | $ | 5,137 |  |  | $ | 4,242 |  |  | $ | 5,137 |  |  | $ | 4,242 |  |

- changed (2016-01-27):
[0001193125-16-439878:note_history:3]
The Company generally does not indemnify end-users
 of its operating system and application software against legal
 claims that the software infringes third-party intellectual
 property rights. Other agreements entered into by the Company
 sometimes include indemnification provisions under which the
 Company could be subject to costs and/or damages in the event of an
 infringement claim against the Company or an indemnified
 third-party. In the opinion of management, there was not at least a
 reasonable possibility the Company may have incurred a material
 loss with respect to indemnification of end-users of its operating
 system or application software for infringement of third-party
 intellectual property rights.
  (was, 2015-07-22, similarity 0.7984):
[0001193125-15-259935:note_history:3]
The Company generally does not indemnify end-users
 of its operating system and application software against legal
 claims that the software infringes third-party intellectual
 property rights. Other agreements entered into by the Company
 sometimes include indemnification provisions under which the
 Company could be subject to costs and/or damages in the event of an
 infringement claim against the Company or an indemnified
 third-party. However, the Company has not been required to make any
 significant payments resulting from such an infringement claim
 asserted against it or an indemnified third-party. In the opinion
 of management, there was not at least a reasonable possibility the
 Company may have incurred a material loss with respect to
 indemnification of end-users of its operating system or application
 software for infringement of third-party intellectual property
 rights. The Company did not record a liability for infringement
 costs related to indemnification as of June 27, 2015 or
 September 27, 2014.

- added (2016-01-27):
[0001193125-16-439878:note_history:4]
The Company offers an iPhone Upgrade Program, which
 is available to customers who purchase an iPhone 6s and 6s Plus in
 one of its U.S. physical retail stores and activate the purchased
 iPhone with one of the four national carriers. The iPhone Upgrade
 Program provides customers the right to trade in that iPhone for a
 new iPhone, provided certain conditions are met. One of the
 conditions of this program requires the customer to finance the
 initial purchase price of the iPhone with a third-party lender.
 Upon exercise of the trade-in right and purchase of a new iPhone,
 the Company satisfies the customer’s outstanding balance due
 to the third-party lender on the original device. The Company
 accounts for the trade-in right as a guarantee liability and
 recognizes arrangement revenue net of the fair value of such right
 with subsequent changes to the guarantee liability recognized
 within revenue.

- changed (2016-01-27):
[0001193125-16-439878:note_history:5]
The Company has entered into indemnification
 agreements with its directors and executive officers. Under these
 agreements, the Company has agreed to indemnify such individuals to
 the fullest extent permitted by law against liabilities that arise
 by reason of their status as directors or officers and to advance
 expenses incurred by such individuals in connection with related
 legal proceedings. It is not possible to determine the maximum
 potential amount of payments the Company could be required to make
 under these agreements due to the limited history of prior
 indemnification claims and the unique facts and circumstances
 involved in each claim. However, the Company maintains directors
 and officers liability insurance coverage to reduce its exposure to
 such obligations.
  (was, 2015-07-22, similarity 0.9523):
[0001193125-15-259935:note_history:5]
The Company has entered into indemnification
 agreements with its directors and executive officers. Under these
 agreements, the Company has agreed to indemnify such individuals to
 the fullest extent permitted by law against liabilities that arise
 by reason of their status as directors or officers and to advance
 expenses incurred by such individuals in connection with related
 legal proceedings. It is not possible to determine the maximum
 potential amount of payments the Company could be required to make
 under these agreements due to the limited history of prior
 indemnification claims and the unique facts and circumstances
 involved in each claim. However, the Company maintains directors
 and officers liability insurance coverage to reduce its exposure to
 such obligations, and payments made under these agreements
 historically have not been material.

- added (2016-01-27):
[0001193125-16-439878:note_history:6]
The Company leases various equipment and
 facilities, including retail space, under noncancelable operating
 lease arrangements. The major facility leases are typically for
 terms not exceeding 10 years and generally contain multi-year
 renewal options. As of December 26, 2015, the Company had a
 total of 469 retail stores. Leases for retail space are for terms
 ranging from five to 20 years, the majority of which are for 10
 years, and often contain multi-year renewal options. As of
 December 26, 2015, the Company’s total future minimum
 lease payments under noncancelable operating leases were $6.6
 billion, of which $3.7 billion related to leases for retail
 space.

- changed (2016-01-27):
[0001193125-16-439878:note_history:7]
The Company is subject to various legal proceedings
 and claims that have arisen in the ordinary course of business and
 that have not been fully adjudicated, certain of which are
 discussed in Part II, Item 1 of this Form 10-Q under the
 heading “Legal Proceedings” and in Part II,
 Item 1A of this Form 10-Q under the heading “Risk
 Factors.” In the opinion of management, there was not at
 least a reasonable possibility the Company may have incurred a
 material loss, or a material loss in excess of a recorded accrual,
 with respect to loss contingencies for asserted legal and other
 claims. However, the outcome of litigation is inherently uncertain.
 Therefore, although management considers the likelihood of such an
 outcome to be remote, if one or more of these legal matters were
 resolved against the Company in a reporting period for amounts in
 excess of management’s expectations, the Company’s
 consolidated financial statements for that reporting period could
 be materially adversely affected.
  (was, 2015-07-22, similarity 0.9816):
[0001193125-15-259935:note_history:7]
The Company is subject to various legal proceedings
 and claims that have arisen in the ordinary course of business and
 that have not been fully adjudicated, certain of which are
 discussed in Part II, Item 1 of this Form 10-Q under the
 heading “Legal Proceedings” and in Part II,
 Item 1A of this Form 10-Q under the heading “Risk
 Factors.” In the opinion of management, there was not at
 least a reasonable possibility the Company may have incurred a
 material loss, or a material loss in excess of a recorded accrual,
 with respect to loss contingencies. However, the outcome of
 litigation is inherently uncertain. Therefore, although management
 considers the likelihood of such an outcome to be remote, if one or
 more of these legal matters were resolved against the Company in a
 reporting period for amounts in excess of management’s
 expectations, the Company’s consolidated financial statements
 for that reporting period could be materially adversely
 affected.

- changed (2016-01-27):
[0001193125-16-439878:note_history:8]
Apple Inc. v. Samsung Electronics Co., Ltd., et al.
  (was, 2015-07-22, similarity 0.9901):
[0001193125-15-259935:note_history:8]
Apple Inc. v. Samsung Electronics Co., Ltd, et al.

- changed (2016-01-27):
[0001193125-16-439878:note_history:9]
On August 24, 2012, a jury returned a verdict
 awarding the Company $1.05 billion in its lawsuit against Samsung
 Electronics Co., Ltd. and affiliated parties in the United States
 District Court, Northern District of California, San Jose Division.
 On March 6, 2014, the District Court entered final judgment in
 favor of the Company in the amount of approximately $930
 million. On May 18, 2015, the U.S. Court of Appeals for
 the Federal Circuit affirmed in part, and reversed in part, the
 decision of the District Court. As a result, the Court of Appeals
 ordered entry of final judgment on damages in the amount of
 approximately $548 million, with the District Court to determine
 supplemental damages and interest, as well as damages owed for
 products subject to the reversal in part. Samsung Electronics Co.,
 Ltd. paid $548 million to the Company in December 2015, which was
 included in net sales in the Condensed Consolidated Statement of
 Operations. Because the March 6, 2014 ruling remains
 subject to further proceedings, the Company has not recognized any
 further amounts in its results of operations.
  (was, 2015-07-22, similarity 0.888):
[0001193125-15-259935:note_history:9]
On August 24, 2012, a jury returned a verdict
 awarding the Company $1.05 billion in its lawsuit against Samsung
 Electronics Co., Ltd and affiliated parties in the United States
 District Court, Northern District of California, San Jose Division.
 On March 6, 2014, the District Court entered final judgment in
 favor of the Company in the amount of approximately $930
 million. On May 18, 2015, the U.S. Court of Appeals for
 the Federal Circuit affirmed in part, and reversed in part, the
 decision of the District Court. As a result, the Court of Appeals
 ordered entry of final judgment on damages in the amount of
 approximately $548 million, with the District Court to determine
 supplemental damages and interest, as well as damages owed for
 products subject to the reversal in part. Because the ruling
 remains subject to further proceedings, the Company has not
 recognized the award in its results of operations.

- removed (2016-01-27):
[0001193125-15-259935:note_history:10]
The Company leases various equipment and
 facilities, including retail space, under noncancelable operating
 lease arrangements. The Company does not currently utilize any
 other off-balance sheet financing arrangements. The major facility
 leases are typically for terms not exceeding 10 years and generally
 contain multi-year renewal options. As of June 27, 2015, the
 Company had a total of 456 retail stores. Leases for retail space
 are for terms ranging from five to 20 years, the majority of which
 are for 10 years, and often contain multi-year renewal options. As
 of June 27, 2015, the Company’s total future minimum
 lease payments under noncancelable operating leases were $5.0
 billion, of which $3.4 billion related to leases for retail
 space.

- removed (2016-01-27):
[0001193125-15-259935:note_history:11]
Other Commitments

- removed (2016-01-27):
[0001193125-15-259935:note_history:12]
The Company utilizes several outsourcing partners
 to manufacture sub-assemblies for the Company’s products and
 to perform final assembly and testing of finished products. These
 outsourcing partners acquire components and build product based on
 demand information supplied by the Company, which typically covers
 periods up to 150 days. The Company also obtains individual
 components for its products from a wide variety of individual
 suppliers. Consistent with industry practice, the Company acquires
 components through a combination of purchase orders, supplier
 contracts and open orders based on projected demand information.
 Where appropriate, the purchases are applied
 to inventory component prepayments that
 are outstanding with the respective supplier. As of
 June 27, 2015, the Company had outstanding off-balance sheet
 third-party manufacturing commitments and component purchase
 commitments of $21.7 billion.

- removed (2016-01-27):
[0001193125-15-259935:note_history:13]
In addition to the commitments mentioned above, the
 Company had other off-balance sheet obligations of $4.8 billion as
 of June 27, 2015 that consisted of commitments to acquire
 capital assets, including product tooling and manufacturing process
 equipment, and commitments related to advertising, research and
 development (“R&D”), internet and
 telecommunications services, energy and other obligations.
 Subsequent to June 27, 2015, the Company entered into
 additional other off-balance sheet obligations of $2.1 billion.

- removed (2016-01-27):
[0001193125-15-259935:note_history:14]
Smartflash LLC, et al., v. Apple Inc., et al.

- removed (2016-01-27):
[0001193125-15-259935:note_history:15]
On May 29, 2013, Smartflash LLC and Smartflash
 Technologies Limited filed an action against the Company in the
 United States District Court for the Eastern District of Texas,
 Tyler Division, alleging that the Company infringed certain patents
 relating to data storage and access systems. On February 24,
 2015, a jury returned a verdict against the Company, and awarded
 damages of approximately $533 million. On July 7, 2015, the
 District Court vacated the award and ordered a new trial for
 damages. Accordingly, the Company has not recorded a loss accrual
 at this time.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-01-27):
[0001193125-16-439878:note_history:16]
Apple Inc. and its wholly-owned subsidiaries
 (collectively “Apple” or the “Company”)
 designs, manufactures and markets mobile communication and media
 devices, personal computers and portable digital music players, and
 sells a variety of related software, services, accessories,
 networking solutions and third-party digital content and
 applications. The Company sells its products worldwide through its
 retail stores, online stores and direct sales force, as well as
 through third-party cellular network carriers, wholesalers,
 retailers and value-added resellers. In addition, the Company sells
 a variety of third-party Apple-compatible products, including
 application software and various accessories through its online and
 retail stores. The Company sells to consumers, small and mid-sized
 businesses and education, enterprise and government customers.
  (was, 2015-07-22, similarity 0.7386):
[0001193125-15-259935:note_history:16]
Apple Inc. and its wholly-owned subsidiaries
 (collectively “Apple” or the “Company”)
 designs, manufactures and markets mobile communication and media
 devices, personal computers and portable digital music players, and
 sells a variety of related software, services, accessories,
 networking solutions and third-party digital content and
 applications. The Company sells its products worldwide through its
 retail stores, online stores and direct sales force, as well as
 through third-party cellular network carriers, wholesalers,
 retailers and value-added resellers. In addition, the Company sells
 a variety of third-party Apple compatible products, including
 application software and various accessories through its online and
 retail stores. The Company sells to consumers, small and mid-sized
 businesses and education, enterprise and government customers.

- changed (2016-01-27):
[0001193125-16-439878:note_history:17]
The accompanying condensed consolidated financial
 statements include the accounts of the Company. Intercompany
 accounts and transactions have been eliminated. In the opinion of
 the Company’s management, the condensed consolidated
 financial statements reflect all adjustments, which are normal and
 recurring in nature, necessary for fair financial statement
 presentation. The preparation of these condensed consolidated
 financial statements in conformity with U.S. generally accepted
 accounting principles (“GAAP”) requires management to
 make estimates and assumptions that affect the amounts reported in
 these condensed consolidated financial statements and accompanying
 notes. Actual results could differ materially from those estimates.
 Certain prior period amounts in the condensed consolidated
 financial statements have been reclassified to conform to the
 current period’s presentation.
  (was, 2015-07-22, similarity 0.9066):
[0001193125-15-259935:note_history:17]
The accompanying condensed consolidated financial
 statements include the accounts of the Company. Intercompany
 accounts and transactions have been eliminated. In the opinion of
 the Company’s management, the condensed consolidated
 financial statements reflect all adjustments, which are normal and
 recurring in nature, necessary for fair financial statement
 presentation. The preparation of these condensed consolidated
 financial statements in conformity with U.S. generally accepted
 accounting principles (“GAAP”) requires management to
 make estimates and assumptions that affect the amounts reported in
 these condensed consolidated financial statements and accompanying
 notes. Actual results could differ materially from those
 estimates.

- changed (2016-01-27):
[0001193125-16-439878:note_history:18]
These condensed consolidated financial statements
 and accompanying notes should be read in conjunction with the
 Company’s annual consolidated financial statements and the
 notes thereto included in its Annual Report on Form 10-K for the
 fiscal year ended September 26, 2015 (the “2015 Form
 10-K”). The Company’s fiscal year is the 52 or 53-week
 period that ends on the last Saturday of September. An additional
 week is included in the first fiscal quarter approximately every
 six years to realign fiscal quarters with calendar quarters. The
 Company’s fiscal years 2016 and 2015 each include 52 weeks.
 Unless otherwise stated, references to particular years, quarters
 or months refer to the Company’s fiscal years ended in
 September and the associated quarters or months of those fiscal
 years.
  (was, 2015-07-22, similarity 0.9055):
[0001193125-15-259935:note_history:18]
These condensed consolidated financial statements
 and accompanying notes should be read in conjunction with the
 Company’s annual consolidated financial statements and the
 notes thereto for the fiscal year ended September 27, 2014,
 included in its Annual Report on Form 10-K as updated by the
 Company’s Current Report on Form 8-K dated January 28,
 2015 (hereinafter, the “2014 Form 10-K”). The
 Company’s fiscal year is the 52 or 53-week period that ends
 on the last Saturday of September. An additional week is included
 in the first fiscal quarter approximately every six years to
 realign fiscal quarters with calendar quarters. The Company’s
 fiscal years 2015 and 2014 each include 52 weeks. Unless otherwise
 stated, references to particular years, quarters or months refer to
 the Company’s fiscal years ended in September and the
 associated quarters or months of those fiscal years.

- added (2016-01-27):
[0001193125-16-439878:note_history:19]
During the first quarter of 2016, the Company
 adopted an accounting standard that simplified the presentation of
 deferred taxes by requiring deferred tax assets and liabilities be
 classified as noncurrent in a classified statement of
 financial position. The Company has adopted this accounting
 standard prospectively; accordingly, the prior period amounts in
 the Company’s Condensed Consolidated Balance Sheets within
 this Quarterly Report on Form 10-Q were not adjusted to conform to
 the new accounting standard. The adoption of this accounting
 standard was not material to the Company’s condensed
 consolidated financial statements.

- changed (2016-01-27):
[0001193125-16-439878:note_history:20]
The following table shows the computation of basic
 and diluted earnings per share for the three months ended
 December 26, 2015 and December 27, 2014 (net income in
 millions and shares in thousands):
  (was, 2015-07-22, similarity 0.9039):
[0001193125-15-259935:note_history:20]
The following table shows the computation of basic
 and diluted earnings per share for the three- and nine-month
 periods ended June 27, 2015 and June 28, 2014 (net income
 in millions and shares in thousands):

- changed (2016-01-27):
[0001193125-16-439878:note_history:21]
|  |  | Three Months Ended |  |
|  |  | December 26, 2015 |  |  | December 27, 2014 |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 18,361 |  |  | $ | 18,024 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding |  |  | 5,558,930 |  |  |  | 5,843,082 |  |
| Effect of dilutive securities |  |  | 35,197 |  |  |  | 38,721 |  |
| Weighted-average diluted shares |  |  | 5,594,127 |  |  |  | 5,881,803 |  |
| Basic earnings per share |  | $ | 3.30 |  |  | $ | 3.08 |  |
| Diluted earnings per share |  | $ | 3.28 |  |  | $ | 3.06 |  |
  (was, 2015-07-22, similarity 0.6313):
[0001193125-15-259935:note_history:21]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 27, 2015 |  |  | June 28, 2014 |  |  | June 27, 2015 |  |  | June 28, 2014 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 10,677 |  |  | $ | 7,748 |  |  | $ | 42,270 |  |  | $ | 31,043 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding |  |  | 5,729,886 |  |  |  | 6,012,635 |  |  |  | 5,788,922 |  |  |  | 6,136,147 |  |
| Effect of dilutive securities |  |  | 43,213 |  |  |  | 39,076 |  |  |  | 40,998 |  |  |  | 36,710 |  |
| Weighted-average diluted shares |  |  | 5,773,099 |  |  |  | 6,051,711 |  |  |  | 5,829,920 |  |  |  | 6,172,857 |  |
| Basic earnings per share |  | $ | 1.86 |  |  | $ | 1.29 |  |  | $ | 7.30 |  |  | $ | 5.06 |  |
| Diluted earnings per share |  | $ | 1.85 |  |  | $ | 1.28 |  |  | $ | 7.25 |  |  | $ | 5.03 |  |

- changed (2016-01-27):
[0001193125-16-439878:note_history:22]
Potentially dilutive securities whose effect would
 have been antidilutive are excluded from the computation of diluted
 earnings per share.
  (was, 2015-07-22, similarity 0.6959):
[0001193125-15-259935:note_history:22]
Potentially dilutive securities whose effect would
 have been antidilutive were not significant for the three- and
 nine-month periods ended June 27, 2015 and June 28, 2014.
 The Company excluded these securities from the computation of
 diluted earnings per share.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-01-27):
[0001193125-16-439878:note_history:23]
The Company issues unsecured short-term promissory
 notes (“Commercial Paper”) pursuant to a commercial
 paper program. The Company uses net proceeds from the commercial
 paper program for general corporate purposes, including dividends
 and share repurchases. As of December 26, 2015 and
 September 26, 2015, the Company had $7.3 billion and $8.5
 billion of Commercial Paper outstanding, respectively, with
 maturities generally less than nine months. The weighted-average
 interest rate of the Company’s Commercial Paper was 0.20% as
 of December 26, 2015 and 0.14% as of September 26,
 2015.
  (was, 2015-07-22, similarity 0.6569):
[0001193125-15-259935:note_history:23]
In 2014, the Board of Directors authorized the
 Company to issue unsecured short-term promissory notes
 (“Commercial Paper”) pursuant to a commercial paper
 program. The Company intends to use net proceeds from the
 commercial paper program for general corporate purposes, including
 dividends and share repurchases. As of June 27, 2015 and
 September 27, 2014, the Company had $4.5 billion and $6.3
 billion of Commercial Paper outstanding, respectively, with a
 weighted-average interest rate of 0.10% and 0.12%, respectively,
 and maturities generally less than nine months.

- changed (2016-01-27):
[0001193125-16-439878:note_history:24]
The following table provides a summary of cash
 flows associated with the issuance and maturities of Commercial
 Paper for the three months ended December 26, 2015 and
 December 27, 2014 (in millions):
  (was, 2015-07-22, similarity 0.904):
[0001193125-15-259935:note_history:24]
The following table provides a summary of cash
 flows associated with the issuance and maturities of Commercial
 Paper for the nine months ended June 27, 2015 (in
 millions):

- added (2016-01-27):
[0001193125-16-439878:note_history:25]
|  |  | Three Months Ended |  |
|  |  | December 26, 2015 |  |  | December 27, 2014 |  |
| Maturities less than 90 days: |  |  |  |  |  |  |  |  |
| Proceeds from (repayments of) commercial paper, net |  | $ | (393 | ) |  | $ | 62 |  |
| Maturities greater than 90 days: |  |  |  |  |  |  |  |  |
| Proceeds from commercial paper |  |  | 492 |  |  |  | 197 |  |
| Repayments of commercial paper |  |  | (1,339 | ) |  |  | (2,668 | ) |
| Proceeds from (repayments of) commercial paper, net |  |  | (847 | ) |  |  | (2,471 | ) |
| Total change in commercial paper, net |  | $ | (1,240 | ) |  | $ | (2,409 | ) |

- added (2016-01-27):
[0001193125-16-439878:note_history:26]
As of December 26, 2015, the Company had
 outstanding floating- and fixed-rate notes with varying maturities
 for an aggregate principal amount of $55.5 billion (collectively
 the “Notes”). The Notes are senior unsecured
 obligations, and interest is payable in arrears, quarterly for the
 U.S. dollar-denominated and Australian dollar-denominated
 floating-rate notes, semi-annually for the U.S. dollar-denominated,
 Australian dollar-denominated, British pound-denominated and
 Japanese yen-denominated fixed-rate notes and annually for the
 euro-denominated and Swiss franc-denominated fixed-rate notes. The
 following table provides a summary of the Company’s term debt
 as of December 26, 2015 and September 26, 2015:

- added (2016-01-27):
[0001193125-16-439878:note_history:27]
|  |  | Maturities |  |  | December, 26, 2015 |  |  | September 26, 2015 |  |
|  |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2016 - 2018 |  |  | $ | 3,000 |  |  |  | 0.51% - 1.10% |  |  | $ | 3,000 |  |  |  | 0.51% - 1.10% |  |
| Fixed-rate 0.45% - 3.85% notes |  |  | 2016 - 2043 |  |  |  | 14,000 |  |  |  | 0.51% - 3.91% |  |  |  | 14,000 |  |  |  | 0.51% - 3.91% |  |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2017 - 2019 |  |  |  | 2,000 |  |  |  | 0.41% - 0.64% |  |  |  | 2,000 |  |  |  | 0.37% - 0.60% |  |
| Fixed-rate 1.05% - 4.45% notes |  |  | 2017 - 2044 |  |  |  | 10,000 |  |  |  | 0.40% - 4.48% |  |  |  | 10,000 |  |  |  | 0.37% - 4.48% |  |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2017 - 2020 |  |  |  | 1,755 |  |  |  | 0.41% - 1.87% |  |  |  | 1,743 |  |  |  | 0.36% - 1.87% |  |
| Fixed-rate 0.35% - 4.375% notes |  |  | 2017 - 2045 |  |  |  | 24,793 |  |  |  | 0.28% - 4.51% |  |  |  | 24,958 |  |  |  | 0.28% - 4.51% |  |
| Total term debt |  |  |  |  |  |  | 55,548 |  |  |  |  |  |  |  | 55,701 |  |  |  |  |  |
| Unamortized discount |  |  |  |  |  |  | (109 | ) |  |  |  |  |  |  | (114 | ) |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  |  |  | 265 |  |  |  |  |  |  |  | 376 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | (2,500 | ) |  |  |  |  |  |  | (2,500 | ) |  |  |  |  |
| Total long-term debt |  |  |  |  |  | $ | 53,204 |  |  |  |  |  |  | $ | 53,463 |  |  |  |  |  |

- added (2016-01-27):
[0001193125-16-439878:note_history:28]
As of December 26, 2015, ¥118.0 billion
 of Japanese yen-denominated notes was designated as a hedge of the
 foreign currency exposure of its net investment in a foreign
 operation. The foreign currency transaction gain or loss on the
 Japanese yen-denominated debt designated as a hedge is recorded in
 OCI as a part of the cumulative translation adjustment. As of
 December 26, 2015 and September 26, 2015, the carrying
 value of the debt designated as a net investment hedge was $1.0
 billion and $2.1 billion, respectively. For further discussion
 regarding the Company’s use of derivative instruments see the
 Derivative Financial Instruments section of Note 2,
 “Financial Instruments.”

- changed (2016-01-27):
[0001193125-16-439878:note_history:29]
The effective interest rates for the Notes include
 the interest on the Notes, amortization of the discount and, if
 applicable, adjustments related to hedging. The Company recognized
 $271 million and $128 million of interest expense on its term debt
 for the three months ended December 26, 2015 and
 December 27, 2014, respectively.
  (was, 2015-07-22, similarity 0.6996):
[0001193125-15-259935:note_history:29]
The effective interest rates for the Notes include
 the interest on the Notes, amortization of the discount and, if
 applicable, adjustments related to hedging. The Company recognized
 $197 million and $486 million of interest expense on its long-term
 debt for the three- and nine-month periods ended June 27,
 2015, respectively. The Company recognized $100 million and $268
 million of interest expense on its long-term debt for the three-
 and nine-month periods ended June 28, 2014, respectively.

- changed (2016-01-27):
[0001193125-16-439878:note_history:30]
As of December 26, 2015 and September 26,
 2015, the fair value of the Company’s Notes, based on Level 2
 inputs, was $55.1 billion and $54.9 billion, respectively.
  (was, 2015-07-22, similarity 0.965):
[0001193125-15-259935:note_history:30]
As of June 27, 2015 and September 27,
 2014, the fair value of the Company’s Notes, based on Level 2
 inputs, was $48.7 billion and $28.5 billion, respectively.

- removed (2016-01-27):
[0001193125-15-259935:note_history:31]
| Maturities less than 90 days: |  |  |  |  |
| Proceeds from (repayments of) commercial paper, net |  | $ | 579 |  |
| Maturities greater than 90 days: |  |  |  |  |
| Proceeds from commercial paper |  |  | 2,601 |  |
| Repayments of commercial paper |  |  | (4,988 | ) |
| Maturities greater than 90 days, net |  |  | (2,387 | ) |
| Total change in commercial paper, net |  | $ | (1,808 | ) |

- removed (2016-01-27):
[0001193125-15-259935:note_history:32]
As of June 27, 2015, the Company has
 outstanding floating- and fixed-rate notes with varying maturities
 for an aggregate principal amount of $50.0 billion (collectively
 the “Notes”). The Notes are senior unsecured
 obligations, and interest is payable in arrears, quarterly for the
 U.S. dollar-denominated floating-rate notes, semi-annually for the
 U.S. dollar- and yen-denominated fixed-rate notes and annually for
 the euro- and Swiss franc-denominated fixed-rate notes. The
 following table provides a summary of the Company’s long-term
 debt as of June 27, 2015 and September 27, 2014:

- removed (2016-01-27):
[0001193125-15-259935:note_history:33]
|  |  | Maturities |  |  | June 27, 2015 |  |  | September 27, 2014 |  |
|  |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2016 - 2018 |  |  | $ | 3,000 |  |  |  | 0.51% - 1.10% |  |  | $ | 3,000 |  |  |  | 0.51% - 1.10% |  |
| Fixed-rate 0.45% - 3.85% notes |  |  | 2016 - 2043 |  |  |  | 14,000 |  |  |  | 0.51% - 3.91% |  |  |  | 14,000 |  |  |  | 0.51% - 3.91% |  |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2017 - 2019 |  |  |  | 2,000 |  |  |  | 0.35% - 0.58% |  |  |  | 2,000 |  |  |  | 0.31% - 0.54% |  |
| Fixed-rate 1.05% - 4.45% notes |  |  | 2017 - 2044 |  |  |  | 10,000 |  |  |  | 0.34% - 4.48% |  |  |  | 10,000 |  |  |  | 0.30% - 4.48% |  |
| First quarter 2015 euro-denominated debt issuance of €2.8 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 1.00% notes |  |  | 2022 |  |  |  | 1,567 |  |  |  | 2.94% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 1.63% notes |  |  | 2026 |  |  |  | 1,567 |  |  |  | 3.45% |  |  |  | 0 |  |  |  | 0 |  |
| Second quarter 2015 debt issuance of $6.5 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2020 |  |  |  | 500 |  |  |  | 0.53% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 1.55% notes |  |  | 2020 |  |  |  | 1,250 |  |  |  | 0.53% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.15% notes |  |  | 2022 |  |  |  | 1,250 |  |  |  | 0.84% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.50% notes |  |  | 2025 |  |  |  | 1,500 |  |  |  | 2.60% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 3.45% notes |  |  | 2045 |  |  |  | 2,000 |  |  |  | 3.58% |  |  |  | 0 |  |  |  | 0 |  |
| Second quarter 2015 Swiss franc-denominated debt issuance of SFr1.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.38% notes |  |  | 2024 |  |  |  | 939 |  |  |  | 0.28% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 0.75% notes |  |  | 2030 |  |  |  | 403 |  |  |  | 0.74% |  |  |  | 0 |  |  |  | 0 |  |
| Third quarter 2015 debt issuance of $8.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2017 |  |  |  | 250 |  |  |  | 0.33% |  |  |  | 0 |  |  |  | 0 |  |
| Floating-rate notes |  |  | 2020 |  |  |  | 500 |  |  |  | 0.58% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 0.90% notes |  |  | 2017 |  |  |  | 750 |  |  |  | 0.32% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.00% notes |  |  | 2020 |  |  |  | 1,250 |  |  |  | 0.57% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.70% notes |  |  | 2022 |  |  |  | 1,250 |  |  |  | 0.95% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 3.20% notes |  |  | 2025 |  |  |  | 2,000 |  |  |  | 1.18% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 4.38% notes |  |  | 2045 |  |  |  | 2,000 |  |  |  | 4.40% |  |  |  | 0 |  |  |  | 0 |  |
| Third quarter 2015 yen-denominated debt issuance of ¥250.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.35% notes |  |  | 2020 |  |  |  | 2,016 |  |  |  | 0.35% |  |  |  | 0 |  |  |  | 0 |  |
| Total borrowings |  |  |  |  |  |  | 49,992 |  |  |  |  |  |  |  | 29,000 |  |  |  |  |  |
| Unamortized discount |  |  |  |  |  |  | (97 | ) |  |  |  |  |  |  | (52 | ) |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  |  |  | 24 |  |  |  |  |  |  |  | 39 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | (2,500 | ) |  |  |  |  |  |  | 0 |  |  |  |  |  |
| Total long-term debt |  |  |  |  |  | $ | 47,419 |  |  |  |  |  |  | $ | 28,987 |  |  |  |  |  |

- removed (2016-01-27):
[0001193125-15-259935:note_history:34]
To manage foreign currency risk associated with the
 euro-denominated notes issued in the first quarter of 2015, the
 Company entered into currency swaps with an aggregate notional
 amount of $3.5 billion, which effectively converted the
 euro-denominated notes to U.S. dollar-denominated notes.

- removed (2016-01-27):
[0001193125-15-259935:note_history:35]
To manage interest rate risk on the U.S.
 dollar-denominated fixed-rate notes issued in the second quarter of
 2015 and maturing in 2020 and 2022, the Company entered into
 interest rate swaps with an aggregate notional amount of $2.5
 billion. To manage interest rate risk on the U.S.
 dollar-denominated fixed-rate notes issued in the third quarter of
 2015 and maturing in 2017, 2020, 2022 and 2025, the Company entered
 into interest rate swaps with an aggregate notional amount of $4.3
 billion. These interest rate swaps effectively converted the fixed
 interest rates on the U.S. dollar-denominated notes to a floating
 interest rate.

- removed (2016-01-27):
[0001193125-15-259935:note_history:36]
During the third quarter of 2015, the Company
 designated ¥212.4 billion of the ¥250.0 billion of
 yen-denominated notes as a hedge of the foreign currency exposure
 of its net investment in a foreign operation. As a result, the
 foreign currency transaction gain or loss on the portion of the
 yen-denominated debt designated as a hedge is recorded in OCI as a
 part of the cumulative translation adjustment. As of June 27,
 2015, the carrying value of the debt designated as a net investment
 hedge was $1.7 billion.

- removed (2016-01-27):
[0001193125-15-259935:note_history:37]
For further discussion regarding the
 Company’s use of derivative instruments see the Derivative
 Financial Instruments section of Note 2, “Financial
 Instruments.”

- removed (2016-01-27):
[0001193125-15-259935:note_history:38]
Future principal payments for the Company’s
 Notes as of June 27, 2015 are as follows (in millions):

- removed (2016-01-27):
[0001193125-15-259935:note_history:39]
| 2015 |  | $ | 0 |  |
| 2016 |  |  | 2,500 |  |
| 2017 |  |  | 3,500 |  |
| 2018 |  |  | 6,000 |  |
| 2019 |  |  | 3,000 |  |
| Thereafter |  |  | 34,992 |  |
| Total future principal payments |  | $ | 49,992 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-01-27):
[0001193125-16-439878:note_history:40]
The following table provides a summary of the
 Company’s term debt as of December 26, 2015 and
 September 26, 2015:
  (was, 2015-07-22, similarity 0.9275):
[0001193125-15-259935:note_history:40]
The following table provides a summary of the
 Company’s long-term debt as of June 27, 2015 and
 September 27, 2014:

- added (2016-01-27):
[0001193125-16-439878:note_history:41]
|  |  | Maturities |  |  | December, 26, 2015 |  |  | September 26, 2015 |  |
|  |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2016 - 2018 |  |  | $ | 3,000 |  |  |  | 0.51% - 1.10% |  |  | $ | 3,000 |  |  |  | 0.51% - 1.10% |  |
| Fixed-rate 0.45% - 3.85% notes |  |  | 2016 - 2043 |  |  |  | 14,000 |  |  |  | 0.51% - 3.91% |  |  |  | 14,000 |  |  |  | 0.51% - 3.91% |  |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2017 - 2019 |  |  |  | 2,000 |  |  |  | 0.41% - 0.64% |  |  |  | 2,000 |  |  |  | 0.37% - 0.60% |  |
| Fixed-rate 1.05% - 4.45% notes |  |  | 2017 - 2044 |  |  |  | 10,000 |  |  |  | 0.40% - 4.48% |  |  |  | 10,000 |  |  |  | 0.37% - 4.48% |  |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2017 - 2020 |  |  |  | 1,755 |  |  |  | 0.41% - 1.87% |  |  |  | 1,743 |  |  |  | 0.36% - 1.87% |  |
| Fixed-rate 0.35% - 4.375% notes |  |  | 2017 - 2045 |  |  |  | 24,793 |  |  |  | 0.28% - 4.51% |  |  |  | 24,958 |  |  |  | 0.28% - 4.51% |  |
| Total term debt |  |  |  |  |  |  | 55,548 |  |  |  |  |  |  |  | 55,701 |  |  |  |  |  |
| Unamortized discount |  |  |  |  |  |  | (109 | ) |  |  |  |  |  |  | (114 | ) |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  |  |  | 265 |  |  |  |  |  |  |  | 376 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | (2,500 | ) |  |  |  |  |  |  | (2,500 | ) |  |  |  |  |
| Total long-term debt |  |  |  |  |  | $ | 53,204 |  |  |  |  |  |  | $ | 53,463 |  |  |  |  |  |

- removed (2016-01-27):
[0001193125-15-259935:note_history:42]
|  |  | Maturities |  |  | June 27, 2015 |  |  | September 27, 2014 |  |
|  |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2016 - 2018 |  |  | $ | 3,000 |  |  |  | 0.51% - 1.10% |  |  | $ | 3,000 |  |  |  | 0.51% - 1.10% |  |
| Fixed-rate 0.45% - 3.85% notes |  |  | 2016 - 2043 |  |  |  | 14,000 |  |  |  | 0.51% - 3.91% |  |  |  | 14,000 |  |  |  | 0.51% - 3.91% |  |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2017 - 2019 |  |  |  | 2,000 |  |  |  | 0.35% - 0.58% |  |  |  | 2,000 |  |  |  | 0.31% - 0.54% |  |
| Fixed-rate 1.05% - 4.45% notes |  |  | 2017 - 2044 |  |  |  | 10,000 |  |  |  | 0.34% - 4.48% |  |  |  | 10,000 |  |  |  | 0.30% - 4.48% |  |
| First quarter 2015 euro-denominated debt issuance of €2.8 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 1.00% notes |  |  | 2022 |  |  |  | 1,567 |  |  |  | 2.94% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 1.63% notes |  |  | 2026 |  |  |  | 1,567 |  |  |  | 3.45% |  |  |  | 0 |  |  |  | 0 |  |
| Second quarter 2015 debt issuance of $6.5 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2020 |  |  |  | 500 |  |  |  | 0.53% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 1.55% notes |  |  | 2020 |  |  |  | 1,250 |  |  |  | 0.53% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.15% notes |  |  | 2022 |  |  |  | 1,250 |  |  |  | 0.84% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.50% notes |  |  | 2025 |  |  |  | 1,500 |  |  |  | 2.60% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 3.45% notes |  |  | 2045 |  |  |  | 2,000 |  |  |  | 3.58% |  |  |  | 0 |  |  |  | 0 |  |
| Second quarter 2015 Swiss franc-denominated debt issuance of SFr1.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.38% notes |  |  | 2024 |  |  |  | 939 |  |  |  | 0.28% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 0.75% notes |  |  | 2030 |  |  |  | 403 |  |  |  | 0.74% |  |  |  | 0 |  |  |  | 0 |  |
| Third quarter 2015 debt issuance of $8.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2017 |  |  |  | 250 |  |  |  | 0.33% |  |  |  | 0 |  |  |  | 0 |  |
| Floating-rate notes |  |  | 2020 |  |  |  | 500 |  |  |  | 0.58% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 0.90% notes |  |  | 2017 |  |  |  | 750 |  |  |  | 0.32% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.00% notes |  |  | 2020 |  |  |  | 1,250 |  |  |  | 0.57% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.70% notes |  |  | 2022 |  |  |  | 1,250 |  |  |  | 0.95% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 3.20% notes |  |  | 2025 |  |  |  | 2,000 |  |  |  | 1.18% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 4.38% notes |  |  | 2045 |  |  |  | 2,000 |  |  |  | 4.40% |  |  |  | 0 |  |  |  | 0 |  |
| Third quarter 2015 yen-denominated debt issuance of ¥250.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.35% notes |  |  | 2020 |  |  |  | 2,016 |  |  |  | 0.35% |  |  |  | 0 |  |  |  | 0 |  |
| Total borrowings |  |  |  |  |  |  | 49,992 |  |  |  |  |  |  |  | 29,000 |  |  |  |  |  |
| Unamortized discount |  |  |  |  |  |  | (97 | ) |  |  |  |  |  |  | (52 | ) |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  |  |  | 24 |  |  |  |  |  |  |  | 39 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | (2,500 | ) |  |  |  |  |  |  | 0 |  |  |  |  |  |
| Total long-term debt |  |  |  |  |  | $ | 47,419 |  |  |  |  |  |  | $ | 28,987 |  |  |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2016-01-27):
[0001193125-15-259935:note_history:43]
Future principal payments for the Company’s
 Notes as of June 27, 2015 are as follows (in millions):

- removed (2016-01-27):
[0001193125-15-259935:note_history:44]
| 2015 |  | $ | 0 |  |
| 2016 |  |  | 2,500 |  |
| 2017 |  |  | 3,500 |  |
| 2018 |  |  | 6,000 |  |
| 2019 |  |  | 3,000 |  |
| Thereafter |  |  | 34,992 |  |
| Total future principal payments |  | $ | 49,992 |  |
