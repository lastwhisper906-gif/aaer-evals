# AAPL MD&A — 0001628280-17-004790


## mdna

[0001628280-17-004790:mdna:1]
[same as prior period, unchanged from 0001628280-17-000717:mdna:1]

[0001628280-17-004790:mdna:2]
[same as prior period, unchanged from 0001628280-17-000717:mdna:2]

[0001628280-17-004790:mdna:3]
[same as prior period, unchanged from 0001628280-17-000717:mdna:3]

[0001628280-17-004790:mdna:4]
[same as prior period, unchanged from 0001628280-17-000717:mdna:4]

[0001628280-17-004790:mdna:5]
The Company designs, manufactures and markets mobile communication and media devices and personal computers, and sells a variety of related software, services, accessories, networking solutions and third-party digital content and applications. The Company’s products and services include iPhone®, iPad®, Mac®, Apple Watch®, Apple TV®, a portfolio of consumer and professional software applications, iOS, macOS®, watchOS® and tvOS™ operating systems, iCloud®, Apple Pay® and a variety of accessory, service and support offerings. The Company sells and delivers digital content and applications through the iTunes Store®, App Store®, Mac App Store, TV App Store, iBooks Store™ and Apple Music® (collectively “Digital Content and Services”). The Company sells its products worldwide through its retail stores, online stores and direct sales force, as well as through third-party cellular network carriers, wholesalers, retailers and value-added resellers. In addition, the Company sells a variety of third-party Apple-compatible products, including application software and various accessories through its retail and online stores. The Company sells to consumers, small and mid-sized businesses and education, enterprise and government customers.

[0001628280-17-004790:mdna:6]
[same as prior period, unchanged from 0001628280-17-000717:mdna:6]

[0001628280-17-004790:mdna:7]
[same as prior period, unchanged from 0001628280-17-000717:mdna:7]

[0001628280-17-004790:mdna:8]
23

[0001628280-17-004790:mdna:9]
[same as prior period, unchanged from 0001628280-17-000717:mdna:8]

[0001628280-17-004790:mdna:10]
[same as prior period, unchanged from 0001628280-17-000717:mdna:9]

[0001628280-17-004790:mdna:11]
[same as prior period, unchanged from 0001628280-17-000717:mdna:10]

[0001628280-17-004790:mdna:12]
The Company’s fiscal year is the 52 or 53-week period that ends on the last Saturday of September. The Company’s fiscal year 2017 will include 53 weeks and will end on September 30, 2017. A 14th week was included in the first quarter of 2017, as is done every five or six years, to realign the Company’s fiscal quarters with calendar quarters.

[0001628280-17-004790:mdna:13]
Second Quarter Fiscal 2017 Highlights

[0001628280-17-004790:mdna:14]
Net sales increased 5% or $2.3 billion during the second quarter of 2017 compared to the same quarter in 2016, primarily driven by strong growth in Services, Mac and Other Products, partially offset by the effect of weakness in foreign currencies relative to the U.S. dollar. Net sales reflected year-over-year growth in each of the geographic operating segments, with the exception of Greater China. During the second quarter of 2017, the Company introduced a new 9.7-inch iPad, which became available at the end of the quarter.

[0001628280-17-004790:mdna:15]
The Company utilized $7.0 billion to repurchase shares of its common stock and paid dividends and dividend equivalents of $3.0 billion during the second quarter of 2017. Additionally, the Company issued $11.0 billion of U.S. dollar-denominated long-term debt.

[0001628280-17-004790:mdna:16]
[same as prior period, unchanged from 0001628280-17-000717:mdna:15]

[0001628280-17-004790:mdna:17]
The following table shows net sales by operating segment and net sales and unit sales by product for the three- and six-month periods ended April 1, 2017 and March 26, 2016 (dollars in millions and units in thousands):

[0001628280-17-004790:mdna:18]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1, 2017 |  | March 26, 2016 |  | Change |  | April 1, 2017 |  | March 26, 2016 |  | Change |
| Net Sales by Operating Segment: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 21,157 |  |  | $ | 19,096 |  |  | 11 | % |  | $ | 53,125 |  |  | $ | 48,421 |  |  | 10 | % |
| Europe | 12,733 |  |  | 11,535 |  |  | 10 | % |  | 31,254 |  |  | 29,467 |  |  | 6 | % |
| Greater China | 10,726 |  |  | 12,486 |  |  | (14 | )% |  | 26,959 |  |  | 30,859 |  |  | (13 | )% |
| Japan | 4,485 |  |  | 4,281 |  |  | 5 | % |  | 10,251 |  |  | 9,075 |  |  | 13 | % |
| Rest of Asia Pacific | 3,795 |  |  | 3,159 |  |  | 20 | % |  | 9,658 |  |  | 8,607 |  |  | 12 | % |
| Total net sales | $ | 52,896 |  |  | $ | 50,557 |  |  | 5 | % |  | $ | 131,247 |  |  | $ | 126,429 |  |  | 4 | % |
| Net Sales by Product: |  |  |  |  |  |  |  |  |  |  |  |
| iPhone (1) | $ | 33,249 |  |  | $ | 32,857 |  |  | 1 | % |  | $ | 87,627 |  |  | $ | 84,492 |  |  | 4 | % |
| iPad (1) | 3,889 |  |  | 4,413 |  |  | (12 | )% |  | 9,422 |  |  | 11,497 |  |  | (18 | )% |
| Mac (1) | 5,844 |  |  | 5,107 |  |  | 14 | % |  | 13,088 |  |  | 11,853 |  |  | 10 | % |
| Services (2) | 7,041 |  |  | 5,991 |  |  | 18 | % |  | 14,213 |  |  | 12,047 |  |  | 18 | % |
| Other Products (1)(3) | 2,873 |  |  | 2,189 |  |  | 31 | % |  | 6,897 |  |  | 6,540 |  |  | 5 | % |
| Total net sales | $ | 52,896 |  |  | $ | 50,557 |  |  | 5 | % |  | $ | 131,247 |  |  | $ | 126,429 |  |  | 4 | % |
| Unit Sales by Product: |  |  |  |  |  |  |  |  |  |  |  |
| iPhone | 50,763 |  |  | 51,193 |  |  | (1 | )% |  | 129,053 |  |  | 125,972 |  |  | 2 | % |
| iPad | 8,922 |  |  | 10,251 |  |  | (13 | )% |  | 22,003 |  |  | 26,373 |  |  | (17 | )% |
| Mac | 4,199 |  |  | 4,034 |  |  | 4 | % |  | 9,573 |  |  | 9,346 |  |  | 2 | % |

[0001628280-17-004790:mdna:19]
(1)Includes deferrals and amortization of related software upgrade rights and non-software services.

[0001628280-17-004790:mdna:20]
(2)Includes revenue from Digital Content and Services, AppleCare®, Apple Pay, licensing and other services.

[0001628280-17-004790:mdna:21]
(3)Includes sales of Apple TV, Apple Watch, Beats® products, iPod and Apple-branded and third-party accessories.

[0001628280-17-004790:mdna:22]
[same as prior period, unchanged from 0001628280-17-000717:mdna:38]

[0001628280-17-004790:mdna:23]
[same as prior period, unchanged from 0001628280-17-000717:mdna:21]

[0001628280-17-004790:mdna:24]
[same as prior period, unchanged from 0001628280-17-000717:mdna:22]

[0001628280-17-004790:mdna:25]
The following table presents iPhone net sales and unit sales information for the three- and six-month periods ended April 1, 2017 and March 26, 2016 (dollars in millions and units in thousands):

[0001628280-17-004790:mdna:26]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1, 2017 |  | March 26, 2016 |  | Change |  | April 1, 2017 |  | March 26, 2016 |  | Change |
| Net sales | $ | 33,249 |  |  | $ | 32,857 |  |  | 1 | % |  | $ | 87,627 |  |  | $ | 84,492 |  |  | 4 | % |
| Percentage of total net sales | 63 | % |  | 65 | % |  |  |  | 67 | % |  | 67 | % |  |  |
| Unit sales | 50,763 |  |  | 51,193 |  |  | (1 | )% |  | 129,053 |  |  | 125,972 |  |  | 2 | % |

[0001628280-17-004790:mdna:27]
iPhone net sales increased during the second quarter of 2017 compared to the same period in 2016 due to higher iPhone average selling prices (“ASPs”), largely offset by the effect of weakness in foreign currencies relative to the U.S. dollar. The year-over-year increase in iPhone net sales during the first six months of 2017 was due primarily to higher iPhone unit sales and to a lesser extent higher iPhone ASPs, partially offset by the effect of weakness in foreign currencies relative to the U.S. dollar.

[0001628280-17-004790:mdna:28]
[same as prior period, unchanged from 0001628280-17-000717:mdna:26]

[0001628280-17-004790:mdna:29]
The following table presents iPad net sales and unit sales information for the three- and six-month periods ended April 1, 2017 and March 26, 2016 (dollars in millions and units in thousands):

[0001628280-17-004790:mdna:30]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1, 2017 |  | March 26, 2016 |  | Change |  | April 1, 2017 |  | March 26, 2016 |  | Change |
| Net sales | $ | 3,889 |  |  | $ | 4,413 |  |  | (12 | )% |  | $ | 9,422 |  |  | $ | 11,497 |  |  | (18 | )% |
| Percentage of total net sales | 7 | % |  | 9 | % |  |  |  | 7 | % |  | 9 | % |  |  |
| Unit sales | 8,922 |  |  | 10,251 |  |  | (13 | )% |  | 22,003 |  |  | 26,373 |  |  | (17 | )% |

[0001628280-17-004790:mdna:31]
iPad net sales decreased in the second quarter and first six months of 2017 compared to the same periods in 2016 due primarily to lower iPad unit sales in each of the geographic operating segments and to a lesser extent the effect of weakness in foreign currencies relative to the U.S. dollar.

[0001628280-17-004790:mdna:32]
[same as prior period, unchanged from 0001628280-17-000717:mdna:30]

[0001628280-17-004790:mdna:33]
The following table presents Mac net sales and unit sales information for the three- and six-month periods ended April 1, 2017 and March 26, 2016 (dollars in millions and units in thousands):

[0001628280-17-004790:mdna:34]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1, 2017 |  | March 26, 2016 |  | Change |  | April 1, 2017 |  | March 26, 2016 |  | Change |
| Net sales | $ | 5,844 |  |  | $ | 5,107 |  |  | 14 | % |  | $ | 13,088 |  |  | $ | 11,853 |  |  | 10 | % |
| Percentage of total net sales | 11 | % |  | 10 | % |  |  |  | 10 | % |  | 9 | % |  |  |
| Unit sales | 4,199 |  |  | 4,034 |  |  | 4 | % |  | 9,573 |  |  | 9,346 |  |  | 2 | % |

[0001628280-17-004790:mdna:35]
Mac net sales increased during the second quarter and first six months of 2017 compared to the same periods in 2016 due primarily to a different mix of Macs, including the new MacBook Pro introduced in the first quarter of 2017, and to a lesser extent higher Mac unit sales. The year-over-year increase in Mac net sales was partially offset by the effect of weakness in foreign currencies relative to the U.S. dollar.

[0001628280-17-004790:mdna:36]
25

[0001628280-17-004790:mdna:37]
[same as prior period, unchanged from 0001628280-17-000717:mdna:34]

[0001628280-17-004790:mdna:38]
The following table presents Services net sales information for the three- and six-month periods ended April 1, 2017 and March 26, 2016 (dollars in millions):

[0001628280-17-004790:mdna:39]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1, 2017 |  | March 26, 2016 |  | Change |  | April 1, 2017 |  | March 26, 2016 |  | Change |
| Net sales | $ | 7,041 |  |  | $ | 5,991 |  |  | 18 | % |  | $ | 14,213 |  |  | $ | 12,047 |  |  | 18 | % |
| Percentage of total net sales | 13 | % |  | 12 | % |  |  |  | 11 | % |  | 10 | % |  |  |

[0001628280-17-004790:mdna:40]
The year-over-year increase in Services net sales in the second quarter and first six months of 2017 compared to the same periods in 2016 was due primarily to growth from the App Store and licensing sales. The year-over-year increase in Services net sales during the first six months of 2017 was partially offset by the non-recurrence of the $548 million received from Samsung Electronics Co., Ltd. in the first quarter of 2016 related to patent infringement matters.

[0001628280-17-004790:mdna:41]
[same as prior period, unchanged from 0001628280-17-000717:mdna:39]

[0001628280-17-004790:mdna:42]
[same as prior period, unchanged from 0001628280-17-000717:mdna:40]

[0001628280-17-004790:mdna:43]
[same as prior period, unchanged from 0001628280-17-000717:mdna:41]

[0001628280-17-004790:mdna:44]
The following table presents Americas net sales information for the three- and six-month periods ended April 1, 2017 and March 26, 2016 (dollars in millions):

[0001628280-17-004790:mdna:45]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1, 2017 |  | March 26, 2016 |  | Change |  | April 1, 2017 |  | March 26, 2016 |  | Change |
| Net sales | $ | 21,157 |  |  | $ | 19,096 |  |  | 11 | % |  | $ | 53,125 |  |  | $ | 48,421 |  |  | 10 | % |
| Percentage of total net sales | 40 | % |  | 38 | % |  |  |  | 40 | % |  | 38 | % |  |  |

[0001628280-17-004790:mdna:46]
Americas net sales increased during the second quarter of 2017 compared to the same period in 2016 due primarily to higher net sales of iPhone and Other Products. The year-over-year increase in Americas net sales during the first six months of 2017 was due primarily to higher net sales of iPhone and Mac, partially offset by lower net sales of iPad.

[0001628280-17-004790:mdna:47]
[same as prior period, unchanged from 0001628280-17-000717:mdna:45]

[0001628280-17-004790:mdna:48]
The following table presents Europe net sales information for the three- and six-month periods ended April 1, 2017 and March 26, 2016 (dollars in millions):

[0001628280-17-004790:mdna:49]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1, 2017 |  | March 26, 2016 |  | Change |  | April 1, 2017 |  | March 26, 2016 |  | Change |
| Net sales | $ | 12,733 |  |  | $ | 11,535 |  |  | 10 | % |  | $ | 31,254 |  |  | $ | 29,467 |  |  | 6 | % |
| Percentage of total net sales | 24 | % |  | 23 | % |  |  |  | 24 | % |  | 23 | % |  |  |

[0001628280-17-004790:mdna:50]
Europe net sales increased during the second quarter of 2017 compared to the same period in 2016 due primarily to higher net sales of iPhone and Mac, partially offset by the effect of weakness in foreign currencies relative to the U.S. dollar. The year-over-year increase in Europe net sales during the first six months of 2017 was due primarily to higher net sales of iPhone and Services, partially offset by the effect of weakness in foreign currencies relative to the U.S. dollar and to a lesser extent lower net sales of iPad.

[0001628280-17-004790:mdna:51]
[same as prior period, unchanged from 0001628280-17-000717:mdna:49]

[0001628280-17-004790:mdna:52]
The following table presents Greater China net sales information for the three- and six-month periods ended April 1, 2017 and March 26, 2016 (dollars in millions):

[0001628280-17-004790:mdna:53]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1, 2017 |  | March 26, 2016 |  | Change |  | April 1, 2017 |  | March 26, 2016 |  | Change |
| Net sales | $ | 10,726 |  |  | $ | 12,486 |  |  | (14 | )% |  | $ | 26,959 |  |  | $ | 30,859 |  |  | (13 | )% |
| Percentage of total net sales | 20 | % |  | 25 | % |  |  |  | 21 | % |  | 24 | % |  |  |

[0001628280-17-004790:mdna:54]
Greater China net sales decreased during the second quarter and first six months of 2017 compared to the same periods in 2016 due primarily to lower net sales of iPhone and the effect of weakness in foreign currencies relative to the U.S. dollar, partially offset by growth in net sales of Services.

[0001628280-17-004790:mdna:55]
[same as prior period, unchanged from 0001628280-17-000717:mdna:53]

[0001628280-17-004790:mdna:56]
The following table presents Japan net sales information for the three- and six-month periods ended April 1, 2017 and March 26, 2016 (dollars in millions):

[0001628280-17-004790:mdna:57]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1, 2017 |  | March 26, 2016 |  | Change |  | April 1, 2017 |  | March 26, 2016 |  | Change |
| Net sales | $ | 4,485 |  |  | $ | 4,281 |  |  | 5 | % |  | $ | 10,251 |  |  | $ | 9,075 |  |  | 13 | % |
| Percentage of total net sales | 8 | % |  | 8 | % |  |  |  | 8 | % |  | 7 | % |  |  |

[0001628280-17-004790:mdna:58]
Japan net sales increased during the second quarter of 2017 compared to the same period in 2016 due primarily to higher net sales of Services and the effect of strength in the Japanese yen relative to the U.S. dollar. The year-over-year increase in Japan net sales during the first six months of 2017 was due primarily to the effect of strength in the Japanese yen relative to the U.S. dollar and growth in net sales of iPhone.

[0001628280-17-004790:mdna:59]
[same as prior period, unchanged from 0001628280-17-000717:mdna:57]

[0001628280-17-004790:mdna:60]
The following table presents Rest of Asia Pacific net sales information for the three- and six-month periods ended April 1, 2017 and March 26, 2016 (dollars in millions):

[0001628280-17-004790:mdna:61]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1, 2017 |  | March 26, 2016 |  | Change |  | April 1, 2017 |  | March 26, 2016 |  | Change |
| Net sales | $ | 3,795 |  |  | $ | 3,159 |  |  | 20 | % |  | $ | 9,658 |  |  | $ | 8,607 |  |  | 12 | % |
| Percentage of total net sales | 7 | % |  | 6 | % |  |  |  | 7 | % |  | 7 | % |  |  |

[0001628280-17-004790:mdna:62]
Rest of Asia Pacific net sales increased during the second quarter of 2017 compared to the same period in 2016 due primarily to higher net sales of iPhone and Mac. The year-over-year increase in Rest of Asia Pacific net sales during the first six months of 2017 was due primarily to higher net sales of iPhone and the effect of strength in foreign currencies relative to the U.S. dollar.

[0001628280-17-004790:mdna:63]
[same as prior period, unchanged from 0001628280-17-000717:mdna:61]

[0001628280-17-004790:mdna:64]
Gross margin for the three- and six-month periods ended April 1, 2017 and March 26, 2016 was as follows (dollars in millions):

[0001628280-17-004790:mdna:65]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1, 2017 |  | March 26, 2016 |  | April 1, 2017 |  | March 26, 2016 |
| Net sales | $ | 52,896 |  |  | $ | 50,557 |  |  | $ | 131,247 |  |  | $ | 126,429 |  |
| Cost of sales | 32,305 |  |  | 30,636 |  |  | 80,480 |  |  | 76,085 |  |
| Gross margin | $ | 20,591 |  |  | $ | 19,921 |  |  | $ | 50,767 |  |  | $ | 50,344 |  |
| Gross margin percentage | 38.9 | % |  | 39.4 | % |  | 38.7 | % |  | 39.8 | % |

[0001628280-17-004790:mdna:66]
Gross margin decreased during the second quarter and first six months of 2017 compared to the same periods in 2016 due primarily to higher product cost structures and the effect of weakness in foreign currencies relative to the U.S. dollar, partially offset by a favorable mix of products and services.

[0001628280-17-004790:mdna:67]
The Company anticipates gross margin during the third quarter of 2017 to be between 37.5% and 38.5%. The foregoing statement regarding the Company’s expected gross margin percentage in the third quarter of 2017 is forward-looking and could differ from actual results. The Company’s future gross margins can be impacted by multiple factors including, but not limited to, those set forth in Part II, Item 1A of this Form 10-Q under the heading “Risk Factors” and those described in this paragraph. In general, the Company believes gross margins will remain under downward pressure due to a variety of factors, including continued industry-wide global product pricing pressures, increased competition, compressed product life cycles, product transitions, potential increases in the cost of components, and potential strengthening of the U.S. dollar, as well as potential increases in the costs of outside manufacturing services and a potential shift in the Company’s sales mix towards products with lower gross margins. In response to competitive pressures, the Company expects it will continue to take product pricing actions, which would adversely affect gross margins. Gross margins could also be affected by the Company’s ability to manage product quality and warranty costs effectively and to stimulate demand for certain of its products. Due to the Company’s significant international operations, its financial condition and operating results, including gross margins, could be significantly affected by fluctuations in exchange rates.

[0001628280-17-004790:mdna:68]
[same as prior period, unchanged from 0001628280-17-000717:mdna:66]

[0001628280-17-004790:mdna:69]
Operating expenses for the three- and six-month periods ended April 1, 2017 and March 26, 2016 were as follows (dollars in millions):

[0001628280-17-004790:mdna:70]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1, 2017 |  | March 26, 2016 |  | April 1, 2017 |  | March 26, 2016 |
| Research and development | $ | 2,776 |  |  | $ | 2,511 |  |  | $ | 5,647 |  |  | $ | 4,915 |  |
| Percentage of total net sales | 5 | % |  | 5 | % |  | 4 | % |  | 4 | % |
| Selling, general and administrative | $ | 3,718 |  |  | $ | 3,423 |  |  | $ | 7,664 |  |  | $ | 7,271 |  |
| Percentage of total net sales | 7 | % |  | 7 | % |  | 6 | % |  | 6 | % |
| Total operating expenses | $ | 6,494 |  |  | $ | 5,934 |  |  | $ | 13,311 |  |  | $ | 12,186 |  |
| Percentage of total net sales | 12 | % |  | 12 | % |  | 10 | % |  | 10 | % |

[0001628280-17-004790:mdna:71]
[same as prior period, unchanged from 0001628280-17-000717:mdna:69]

[0001628280-17-004790:mdna:72]
The growth in R&D expense during the second quarter and first six months of 2017 compared to the same periods in 2016 was driven primarily by an increase in headcount and related expenses to support expanded R&D activities. The Company continues to believe that focused investments in R&D are critical to its future growth and competitive position in the marketplace, and to the development of new and updated products that are central to the Company’s core business strategy.

[0001628280-17-004790:mdna:73]
[same as prior period, unchanged from 0001628280-17-000717:mdna:71]

[0001628280-17-004790:mdna:74]
The growth in selling, general and administrative expense during the second quarter of 2017 compared to the same quarter in 2016 was driven primarily by an increase in headcount and related expenses and higher spending on marketing and advertising. The year-over-year growth in selling, general and administrative expense during the first six months of 2017 was driven primarily by an increase in headcount and related expenses and higher variable selling costs.

[0001628280-17-004790:mdna:75]
[same as prior period, unchanged from 0001628280-17-000717:mdna:73]

[0001628280-17-004790:mdna:76]
Other income/(expense), net for the three- and six-month periods ended April 1, 2017 and March 26, 2016 was as follows (dollars in millions):

[0001628280-17-004790:mdna:77]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1, 2017 |  | March 26, 2016 |  | Change |  | April 1, 2017 |  | March 26, 2016 |  | Change |
| Interest and dividend income | $ | 1,282 |  |  | $ | 986 |  |  |  |  | $ | 2,506 |  |  | $ | 1,927 |  |  |  |
| Interest expense | (530 | ) |  | (321 | ) |  |  |  | (1,055 | ) |  | (597 | ) |  |  |
| Other expense, net | (165 | ) |  | (510 | ) |  |  |  | (43 | ) |  | (773 | ) |  |  |
| Total other income/(expense), net | $ | 587 |  |  | $ | 155 |  |  | 279 | % |  | $ | 1,408 |  |  | $ | 557 |  |  | 153 | % |

[0001628280-17-004790:mdna:78]
The increase in other income/(expense), net during the second quarter and first six months of 2017 compared to the same periods in 2016 was due primarily to higher interest income and the favorable impact of foreign exchange-related items, partially offset by higher interest expense on debt. The weighted-average interest rate earned by the Company on its cash, cash equivalents and marketable securities was 1.99% and 1.74% in the second quarter of 2017 and 2016, respectively, and 1.93% and 1.70% in the first six months of 2017 and 2016, respectively.

[0001628280-17-004790:mdna:79]
[same as prior period, unchanged from 0001628280-17-000717:mdna:77]

[0001628280-17-004790:mdna:80]
Provision for income taxes and effective tax rates for the three- and six-month periods ended April 1, 2017 and March 26, 2016 were as follows (dollars in millions):

[0001628280-17-004790:mdna:81]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1, 2017 |  | March 26, 2016 |  | April 1, 2017 |  | March 26, 2016 |
| Provision for income taxes | $ | 3,655 |  |  | $ | 3,626 |  |  | $ | 9,944 |  |  | $ | 9,838 |  |
| Effective tax rate | 24.9 | % |  | 25.6 | % |  | 25.6 | % |  | 25.4 | % |

[0001628280-17-004790:mdna:82]
The Company’s effective tax rates during the second quarter of 2017 and 2016 differ from the statutory federal income tax rate of 35% due primarily to certain undistributed foreign earnings, a substantial portion of which was generated by subsidiaries organized in Ireland, for which no U.S. taxes are provided when such earnings are intended to be indefinitely reinvested outside the U.S. The lower effective tax rate during the second quarter of 2017 compared to the same quarter in 2016 was due primarily to a different geographic mix of earnings. The slightly higher effective tax rate in the first six months of 2017 compared to the same period in 2016 was due primarily to the retroactive reinstatement of the U.S. federal R&D tax credit during the first quarter of 2016.

[0001628280-17-004790:mdna:83]
[same as prior period, unchanged from 0001628280-17-000717:mdna:81]

[0001628280-17-004790:mdna:84]
[same as prior period, unchanged from 0001628280-17-000717:mdna:82]

[0001628280-17-004790:mdna:85]
[same as prior period, unchanged from 0001628280-17-000717:mdna:83]

[0001628280-17-004790:mdna:86]
[same as prior period, unchanged from 0001628280-17-000717:mdna:84]

[0001628280-17-004790:mdna:87]
In November 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash (“ASU 2016-18”), which enhances and clarifies the guidance on the classification and presentation of restricted cash in the statement of cash flows. The Company will adopt ASU 2016-18 in its first quarter of 2019 utilizing the retrospective adoption method. Currently, the Company's restricted cash balance is not significant.

[0001628280-17-004790:mdna:88]
[same as prior period, unchanged from 0001628280-17-000717:mdna:86]

[0001628280-17-004790:mdna:89]
In October 2016, the FASB issued ASU No. 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory (“ASU 2016-16”), which requires the recognition of the income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. The Company will adopt ASU 2016-16 in its first quarter of 2019 utilizing the modified retrospective adoption method. Currently, the Company anticipates recording up to $9 billion of net deferred tax assets on its Consolidated Balance Sheets. However, the ultimate impact of adopting ASU 2016-16 will depend on the balance of intellectual property transferred between its subsidiaries as of the adoption date. The Company will recognize incremental deferred income tax expense thereafter as these deferred tax assets are utilized.

[0001628280-17-004790:mdna:90]
[same as prior period, unchanged from 0001628280-17-000717:mdna:88]

[0001628280-17-004790:mdna:91]
In March 2016, the FASB issued ASU No. 2016-09, Compensation – Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting (“ASU 2016-09”), which modifies certain aspects of the accounting for share-based payment transactions, including income taxes, classification of awards, and classification in the statement of cash flows. The Company will adopt ASU 2016-09 in its first quarter of 2018. Currently, excess tax benefits or deficiencies from the Company's equity awards are recorded as additional paid-in capital in its Consolidated Balance Sheets. Upon adoption, the Company will record any excess tax benefits or deficiencies from its equity awards in its Consolidated Statements of Operations in the reporting periods in which vesting occurs. As a result, subsequent to adoption the Company's income tax expense and associated effective tax rate will be impacted by fluctuations in stock price between the grant dates and vesting dates of equity awards.

[0001628280-17-004790:mdna:92]
[same as prior period, unchanged from 0001628280-17-000717:mdna:90]

[0001628280-17-004790:mdna:93]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842) (“ASU 2016-02”), which modifies lease accounting for lessees to increase transparency and comparability by recording lease assets and liabilities for operating leases and disclosing key information about leasing arrangements. ASU 2016-02 will be effective for the Company beginning in its first quarter of 2020, and early adoption is permitted. The Company will use a modified retrospective adoption approach. While the Company is currently evaluating the timing and impact of adopting ASU 2016-02, currently the Company anticipates recording lease assets and liabilities in excess of $8.2 billion on its Consolidated Balance Sheets, with no material impact to its Consolidated Statements of Operations. However, the ultimate impact of adopting ASU 2016-02 will depend on the Company's lease portfolio as of the adoption date.

[0001628280-17-004790:mdna:94]
[same as prior period, unchanged from 0001628280-17-000717:mdna:92]

[0001628280-17-004790:mdna:95]
In January 2016, the FASB issued ASU No. 2016-01, Financial Instruments – Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities (“ASU 2016-01”), which updates certain aspects of recognition, measurement, presentation and disclosure of financial instruments. The Company will adopt ASU 2016-01 in its first quarter of 2019 utilizing the modified retrospective adoption method. Based on the composition of the Company's investment portfolio, the adoption of ASU 2016-01 is not expected to have a material impact on its consolidated financial statements.

[0001628280-17-004790:mdna:96]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (“ASU 2016-13”), which modifies the measurement of expected credit losses of certain financial instruments. The Company will adopt ASU 2016-13 in its first quarter of 2021 utilizing the modified retrospective adoption method. Based on the composition of the Company's investment portfolio, current market conditions, and historical credit loss activity, the adoption of ASU 2016-13 is not expected to have a material impact on its consolidated financial statements.

[0001628280-17-004790:mdna:97]
[same as prior period, unchanged from 0001628280-17-000717:mdna:95]

[0001628280-17-004790:mdna:98]
In May 2014, the FASB issued ASU No. 2014-09, Revenue from Contracts with Customers (Topic 606) (“ASU 2014-09”), which amends the existing accounting standards for revenue recognition. ASU 2014-09 is based on principles that govern the recognition of revenue at an amount an entity expects to be entitled when products are transferred to customers.

[0001628280-17-004790:mdna:99]
Subsequently, the FASB has issued the following standards related to ASU 2014-09: ASU No. 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (“ASU 2016-08”); ASU No. 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing (“ASU 2016-10”); ASU No. 2016-12, Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients (“ASU 2016-12”); and ASU No. 2016-20, Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers (“ASU 2016-20”). The Company must adopt ASU 2016-08, ASU 2016-10, ASU 2016-12 and ASU 2016-20 with ASU 2014-09 (collectively, the “new revenue standards”).

[0001628280-17-004790:mdna:100]
The new revenue standards may be applied retrospectively to each prior period presented or retrospectively with the cumulative effect recognized as of the date of adoption. The Company plans to adopt the new revenue standards in its first quarter of 2019 utilizing the full retrospective adoption method. The new revenue standards are not expected to have a material impact on the amount and timing of revenue recognized in the Company's consolidated financial statements.

[0001628280-17-004790:mdna:101]
[same as prior period, unchanged from 0001628280-17-000717:mdna:99]

[0001628280-17-004790:mdna:102]
The following tables present selected financial information and statistics as of April 1, 2017 and September 24, 2016 and for the first six months of 2017 and 2016 (in millions):

[0001628280-17-004790:mdna:103]
|  | April 1, 2017 |  | September 24, 2016 |
| Cash, cash equivalents and marketable securities | $ | 256,841 |  |  | $ | 237,585 |  |
| Property, plant and equipment, net | $ | 27,163 |  |  | $ | 27,010 |  |
| Commercial paper | $ | 9,992 |  |  | $ | 8,105 |  |
| Total term debt | $ | 88,530 |  |  | $ | 78,927 |  |
| Working capital | $ | 28,648 |  |  | $ | 27,863 |  |

[0001628280-17-004790:mdna:104]
|  | Six Months Ended |
|  | April 1, 2017 |  | March 26, 2016 |
| Cash generated by operating activities | $ | 39,579 |  |  | $ | 39,064 |  |
| Cash used in investing activities | $ | (33,324 | ) |  | $ | (34,110 | ) |
| Cash used in financing activities | $ | (11,582 | ) |  | $ | (4,560 | ) |

[0001628280-17-004790:mdna:105]
The Company believes its existing balances of cash, cash equivalents and marketable securities will be sufficient to satisfy its working capital needs, capital asset purchases, outstanding commitments and other liquidity requirements associated with its existing operations over the next 12 months. The Company currently anticipates the cash used for future dividends, the share repurchase program and debt repayments will come from its current domestic cash, cash generated from ongoing U.S. operating activities and from borrowings.

[0001628280-17-004790:mdna:106]
As of April 1, 2017 and September 24, 2016, the Company’s cash, cash equivalents and marketable securities held by foreign subsidiaries were $239.6 billion and $216.0 billion, respectively, and are generally based in U.S. dollar-denominated holdings. Amounts held by foreign subsidiaries are generally subject to U.S. income taxation on repatriation to the U.S. In connection with the State Aid Decision, the European Commission announced a recovery amount of up to €13 billion, plus interest. The actual amount of additional taxes subject to recovery is to be calculated by Ireland in accordance with the European Commission's guidance. Once the recovery amount is computed by Ireland, the Company anticipates funding it, including interest, out of foreign cash into escrow, where it will remain pending conclusion of all appeals.

[0001628280-17-004790:mdna:107]
The Company’s marketable securities investment portfolio is primarily invested in highly-rated securities, and its investment policy generally limits the amount of credit exposure to any one issuer. The policy generally requires investments to be investment grade, with the primary objective of minimizing the potential risk of principal loss.

[0001628280-17-004790:mdna:108]
During the six months ended April 1, 2017, cash generated by operating activities of $39.6 billion was a result of $28.9 billion of net income, non-cash adjustments to net income of $10.4 billion and an increase in the net change in operating assets and liabilities of $0.3 billion. Cash used in investing activities of $33.3 billion during the six months ended April 1, 2017 consisted primarily of cash used for purchases of marketable securities, net of sales and maturities, of $26.9 billion and cash used to acquire property, plant and equipment of $6.3 billion. Cash used in financing activities of $11.6 billion during the six months ended April 1, 2017 consisted primarily of cash used to repurchase common stock of $18.0 billion and cash used to pay dividends and dividend equivalents of $6.1 billion, partially offset by proceeds from the issuance of term debt, net of $11.0 billion and a net increase in commercial paper of $1.9 billion.

[0001628280-17-004790:mdna:109]
During the six months ended March 26, 2016, cash generated by operating activities of $39.1 billion was a result of $28.9 billion of net income, non-cash adjustments to net income of $11.0 billion and a decrease in the net change in operating assets and liabilities of $0.8 billion. Cash used in investing activities of $34.1 billion during the six months ended March 26, 2016 consisted primarily of cash used for purchases of marketable securities, net of sales and maturities, of $27.0 billion and cash used to acquire property, plant and equipment of $5.9 billion. Cash used in financing activities of $4.6 billion during the six months ended March 26, 2016 consisted primarily of cash used to repurchase common stock of $13.5 billion and cash used to pay dividends and dividend equivalents of $5.9 billion, partially offset by proceeds from the issuance of term debt, net of $15.6 billion.

[0001628280-17-004790:mdna:110]
[same as prior period, unchanged from 0001628280-17-000717:mdna:108]

[0001628280-17-004790:mdna:111]
The Company’s capital expenditures were $4.5 billion during the first six months of 2017. The Company anticipates utilizing approximately $16.0 billion for capital expenditures during 2017, which includes product tooling and manufacturing process equipment; data centers; corporate facilities and infrastructure, including information systems hardware, software and enhancements; and retail store facilities.

[0001628280-17-004790:mdna:112]
[same as prior period, unchanged from 0001628280-17-000717:mdna:110]

[0001628280-17-004790:mdna:113]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses the net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of April 1, 2017, the Company had $10.0 billion of Commercial Paper outstanding, with a weighted-average interest rate of 0.80% and maturities generally less than nine months.

[0001628280-17-004790:mdna:114]
As of April 1, 2017, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $88.9 billion (collectively the “Notes”). The Company has entered, and in the future may enter, into interest rate swaps to manage interest rate risk on the Notes. In addition, the Company has entered, and in the future may enter, into currency swaps to manage foreign currency risk on the Notes.

[0001628280-17-004790:mdna:115]
[same as prior period, unchanged from 0001628280-17-000717:mdna:113]

[0001628280-17-004790:mdna:116]
[same as prior period, unchanged from 0001628280-17-000717:mdna:114]

[0001628280-17-004790:mdna:117]
As of April 1, 2017, the Company had an authorized capital return program of $250 billion, which included a share repurchase program of $175 billion of the Company’s common stock. As of April 1, 2017, $151 billion of the share repurchase program had been utilized. The Company’s share repurchase program does not obligate it to acquire any specific number of shares. Under the program, shares may be repurchased in privately negotiated or open market transactions, including under plans complying with Rule 10b5-1 under the Exchange Act.

[0001628280-17-004790:mdna:118]
The following table presents the Company’s dividends, dividend equivalents, share repurchases and net share settlement activity from the start of the capital return program in August 2012 through April 1, 2017 (in millions):

[0001628280-17-004790:mdna:119]
|  | Dividends andDividend Equivalents Paid |  | Accelerated ShareRepurchases |  | Open MarketShare Repurchases |  | Taxes Related to Settlement of Equity Awards |  | Total |
| Q2 2017 | $ | 3,004 |  |  | $ | 3,000 |  |  | $ | 4,001 |  |  | $ | 159 |  |  | $ | 10,164 |  |
| Q1 2017 | 3,130 |  |  | 6,000 |  |  | 5,000 |  |  | 629 |  |  | 14,759 |  |
| 2016 | 12,150 |  |  | 12,000 |  |  | 17,000 |  |  | 1,570 |  |  | 42,720 |  |
| 2015 | 11,561 |  |  | 6,000 |  |  | 30,026 |  |  | 1,499 |  |  | 49,086 |  |
| 2014 | 11,126 |  |  | 21,000 |  |  | 24,000 |  |  | 1,158 |  |  | 57,284 |  |
| 2013 | 10,564 |  |  | 13,950 |  |  | 9,000 |  |  | 1,082 |  |  | 34,596 |  |
| 2012 | 2,488 |  |  | — |  |  | — |  |  | 56 |  |  | 2,544 |  |
| Total | $ | 54,023 |  |  | $ | 61,950 |  |  | $ | 89,027 |  |  | $ | 6,153 |  |  | $ | 211,153 |  |

[0001628280-17-004790:mdna:120]
On May 2, 2017, the Company announced that the Board of Directors increased the total capital return program from $250 billion to $300 billion, which includes an increase in the share repurchase authorization from $175 billion to $210 billion. Additionally, the Company announced that the Board of Directors raised the Company's quarterly cash dividend by 10.5% from $0.57 to $0.63 per share, beginning with the dividend to be paid during the third quarter of 2017. The Company intends to increase its dividend on an annual basis subject to declaration by the Board of Directors.

[0001628280-17-004790:mdna:121]
The Company expects to execute its capital return program by the end of March 2019 by paying dividends and dividend equivalents, repurchasing shares and remitting withheld taxes related to net share settlement of restricted stock units. The Company plans to continue to access the domestic and international debt markets to assist in funding its capital return program.

[0001628280-17-004790:mdna:122]
[same as prior period, unchanged from 0001628280-17-000717:mdna:120]

[0001628280-17-004790:mdna:123]
[same as prior period, unchanged from 0001628280-17-000717:mdna:121]

[0001628280-17-004790:mdna:124]
[same as prior period, unchanged from 0001628280-17-000717:mdna:122]

[0001628280-17-004790:mdna:125]
As of April 1, 2017, the Company’s total future minimum lease payments under noncancelable operating leases were $8.2 billion. The Company’s retail store and other facility leases are typically for terms not exceeding 10 years and generally contain multi-year renewal options.

[0001628280-17-004790:mdna:126]
[same as prior period, unchanged from 0001628280-17-000717:mdna:124]

[0001628280-17-004790:mdna:127]
The Company utilizes several outsourcing partners to manufacture sub-assemblies for the Company’s products and to perform final assembly and testing of finished products. These outsourcing partners acquire components and build product based on demand information supplied by the Company, which typically covers periods up to 150 days. The Company also obtains individual components for its products from a wide variety of individual suppliers. Consistent with industry practice, the Company acquires components through a combination of purchase orders, supplier contracts, and open orders based on projected demand information. As of April 1, 2017, the Company had manufacturing purchase obligations of $21.7 billion.

[0001628280-17-004790:mdna:128]
[same as prior period, unchanged from 0001628280-17-000717:mdna:126]

[0001628280-17-004790:mdna:129]
The Company’s other purchase obligations were comprised of commitments to acquire capital assets, including product tooling and manufacturing process equipment, and commitments related to advertising, licensing, R&D, internet and telecommunications services and other obligations. As of April 1, 2017, the Company had other purchase obligations of $5.9 billion.

[0001628280-17-004790:mdna:130]
The Company’s other non-current liabilities in the Condensed Consolidated Balance Sheets consist primarily of deferred tax liabilities, gross unrecognized tax benefits and the related gross interest and penalties. As of April 1, 2017, the Company had non-current deferred tax liabilities of $28.2 billion, gross unrecognized tax benefits of $8.8 billion and an additional $1.3 billion for gross interest and penalties.

[0001628280-17-004790:mdna:131]
31

[0001628280-17-004790:mdna:132]
[same as prior period, unchanged from 0001628280-17-000717:mdna:129]

[0001628280-17-004790:mdna:133]
The Company generally does not indemnify end-users of its operating system and application software against legal claims that the software infringes third-party intellectual property rights. Other agreements entered into by the Company sometimes include indemnification provisions under which the Company could be subject to costs and/or damages in the event of an infringement claim against the Company or an indemnified third party. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss with respect to indemnification of end-users of its operating system or application software for infringement of third-party intellectual property rights.

[0001628280-17-004790:mdna:134]
[same as prior period, unchanged from 0001628280-17-000717:mdna:131]

[0001628280-17-004790:mdna:135]
The Company has entered into indemnification agreements with its directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, the Company maintains directors and officers liability insurance coverage to reduce its exposure to such obligations.

[0001628280-17-004790:mdna:136]
[same as prior period, unchanged from 0001628280-17-000717:mdna:133]

[0001628280-17-004790:mdna:137]
[same as prior period, unchanged from 0001628280-17-000717:mdna:134]

[0001628280-17-004790:mdna:138]
Note 1, “Summary of Significant Accounting Policies” in Part I, Item 1 of this Form 10-Q and in the Notes to Consolidated Financial Statements in Part II, Item 8 of the 2016 Form 10-K, and “Critical Accounting Policies and Estimates” in Part II, Item 7 of the 2016 Form 10-K describe the significant accounting policies and methods used in the preparation of the Company’s condensed consolidated financial statements. There have been no material changes to the Company’s critical accounting policies and estimates since the 2016 Form 10-K.
