# AAPL 8-K — 0001628280-17-004663 filed 2017-05-02

## item codes, every 8-K on or before 2017-05-03

- 2017-05-02 0001628280-17-004663 — 2.02, 9.01
- 2017-03-03 0001193125-17-069853 — 8.01, 9.01
- 2017-03-01 0001193125-17-064019 — 5.07
- 2017-02-09 0001193125-17-036283 — 8.01, 9.01
- 2017-01-31 0001628280-17-000663 — 2.02, 9.01
- 2016-12-15 0001628280-16-022047 — 5.03, 9.01
- 2016-10-25 0001628280-16-020258 — 2.02, 9.01
- 2016-08-04 0001193125-16-672044 — 8.01, 9.01
- 2016-07-26 0001628280-16-017762 — 2.02, 9.01
- 2016-06-22 0001193125-16-628957 — 8.01, 9.01
- 2016-04-26 0001193125-16-556520 — 2.02, 9.01
- 2016-03-24 0001193125-16-516891 — 8.01, 9.01
- 2016-03-01 0001193125-16-488223 — 5.02, 5.07, 9.01
- 2016-02-23 0001193125-16-473562 — 8.01, 9.01
- 2016-01-26 0001193125-16-438421 — 2.02, 9.01
- 2015-12-22 0001193125-15-410853 — 5.03, 9.01
- 2015-12-17 0001193125-15-406279 — 5.02
- 2015-10-27 0001193125-15-354756 — 2.02, 9.01
- 2015-10-02 0001193125-15-336615 — 5.02
- 2015-09-17 0001193125-15-322466 — 8.01, 9.01
- 2015-07-31 0001193125-15-273023 — 8.01, 9.01
- 2015-07-21 0001193125-15-258464 — 2.02, 9.01
- 2015-06-10 0001193125-15-219298 — 8.01, 9.01
- 2015-05-13 0001193125-15-186064 — 8.01, 9.01
- 2015-04-27 0001193125-15-149607 — 7.01, 9.01
- 2015-04-27 0001193125-15-149590 — 2.02, 9.01
- 2015-03-13 0001104659-15-019336 — 5.07, 9.01
- 2015-02-09 0001193125-15-039270 — 8.01, 9.01
- 2015-01-28 0001193125-15-023732 — 8.01, 9.01
- 2015-01-27 0001193125-15-021857 — 2.02, 9.01
- 2014-11-10 0001193125-14-406296 — 8.01, 9.01
- 2014-10-20 0001193125-14-376361 — 2.02, 9.01
- 2014-07-23 0001193125-14-277193 — 8.01, 9.01
- 2014-07-22 0001193125-14-275598 — 2.02, 9.01
- 2014-07-17 0001193125-14-271698 — 5.02
- 2014-06-06 0001193125-14-228798 — 5.03, 9.01
- 2014-05-30 0001181431-14-021923 — 5.02
- 2014-05-06 0001193125-14-184969 — 8.01, 9.01
- 2014-04-23 0001193125-14-154883 — 7.01, 9.01
- 2014-04-23 0001193125-14-154871 — 2.02, 9.01
- 2014-03-05 0001193125-14-084697 — 5.02, 5.03, 5.07, 9.01
- 2014-01-27 0001193125-14-022238 — 2.02, 9.01
- 2013-10-28 0001193125-13-413498 — 2.02, 9.01
- 2013-09-23 0001181431-13-050140 — 8.01
- 2013-07-30 0001181431-13-041847 — 5.02
- 2013-07-23 0001193125-13-298914 — 2.02, 9.01
- 2013-06-21 0001193125-13-267629 — 5.02
- 2013-05-03 0001193125-13-199324 — 8.01, 9.01
- 2013-04-24 0001193125-13-170623 — 8.01, 9.01
- 2013-04-23 0001193125-13-167469 — 7.01, 9.01
- 2013-04-23 0001193125-13-167458 — 2.02, 9.01
- 2013-03-01 0001193125-13-085842 — 5.07
- 2013-01-23 0001193125-13-020783 — 2.02, 9.01
- 2012-10-25 0001193125-12-435506 — 2.02, 9.01
- 2012-07-24 0001193125-12-312355 — 2.02, 9.01
- 2012-06-28 0001181431-12-038301 — 5.02
- 2012-05-24 0001181431-12-032458 — 5.02
- 2012-04-24 0001193125-12-178928 — 2.02, 9.01
- 2012-02-27 0001193125-12-081892 — 5.07
- 2012-01-24 0001193125-12-021833 — 2.02, 9.01
- 2011-11-16 0001181431-11-056354 — 5.02
- 2011-10-18 0001193125-11-273826 — 2.02, 9.01
- 2011-10-06 0001181431-11-051976 — 8.01
- 2011-08-26 0001181431-11-047179 — 5.02
- 2011-07-19 0001193125-11-191368 — 2.02, 9.01
- 2011-06-15 0001181431-11-036782 — 5.02
- 2011-04-20 0001193125-11-103732 — 2.02, 9.01
- 2011-02-24 0001193125-11-045411 — 5.07
- 2011-01-18 0001193125-11-009392 — 2.02, 9.01
- 2011-01-18 0001181431-11-003847 — 5.02
- 2010-11-17 0001181431-10-056327 — 5.02, 5.03, 9.01
- 2010-10-18 0001193125-10-230992 — 2.02, 9.01
- 2010-07-20 0001193125-10-161807 — 2.02, 9.01
- 2010-04-20 0001193125-10-087786 — 2.02, 9.01
- 2010-03-12 0001181431-10-016054 — 5.02
- 2010-03-01 0001193125-10-044765 — 5.02, 5.07, 9.01
- 2010-01-25 0001193125-10-012096 — 2.02, 9.01
- 2009-10-19 0001193125-09-209633 — 2.02, 9.01
- 2009-08-04 0001181431-09-037492 — 5.02
- 2009-07-21 0001193125-09-152290 — 2.02, 9.01
- 2009-06-02 0001181431-09-028400 — 5.03
- 2009-04-22 0001193125-09-084599 — 2.02, 9.01
- 2009-02-27 0001181431-09-012161 — 4.01
- 2009-01-21 0001193125-09-009009 — 2.02, 9.01
- 2009-01-16 0001181431-09-003017 — 5.02
- 2008-10-21 0001193125-08-213642 — 2.02, 9.01
- 2008-08-26 0001181431-08-050059 — 5.03
- 2008-07-21 0001193125-08-154381 — 2.02, 9.01
- 2008-06-09 0001181431-08-037620 — 8.01
- 2008-04-23 0001193125-08-088001 — 2.02, 9.01
- 2008-01-22 0001193125-08-009715 — 2.02, 9.01
- 2008-01-15 0001181431-08-003342 — 2.02, 8.01
- 2008-01-08 0001181431-08-002372 — 5.02
- 2007-10-22 0001104659-07-076142 — 2.02, 9.01
- 2007-07-25 0001104659-07-056111 — 2.02, 9.01
- 2007-05-16 0001104659-07-040672 — 5.02, 9.01
- 2007-04-25 0001104659-07-031354 — 2.02, 9.01
- 2007-04-24 0001104659-07-030938 — 8.01, 9.01
- 2007-02-21 0001104659-07-012760 — 5.03, 9.01
- 2007-01-17 0001104659-07-002905 — 2.02, 9.01
- 2007-01-10 0001104659-07-001648 — 5.03, 9.01
- 2006-10-27 0001104659-06-069015 — 8.01
- 2006-10-18 0001104659-06-067275 — 2.02, 9.01
- 2006-10-04 0001104659-06-064935 — 5.02, 8.01, 9.01
- 2006-09-01 0001104659-06-058808 — 1.01, 5.02, 5.03, 9.01
- 2006-08-11 0001104659-06-054118 — 2.02, 3.01, 9.01
- 2006-08-04 0001104659-06-051302 — 2.02, 4.02, 9.01
- 2006-07-19 0001104659-06-047739 — 2.02, 9.01
- 2006-04-21 0001181431-06-024759 — 1.01
- 2006-04-19 0001104659-06-025992 — 2.02, 9.01
- 2006-01-18 0001104659-06-002690 — 2.02, 9.01
- 2006-01-10 0001104659-06-001428 — 2.02
- 2005-12-19 0001181431-05-067468 — 1.01
- 2005-10-14 0001181431-05-056604 — 5.02
- 2005-10-11 0001104659-05-048094 — 2.02, 9.01
- 2005-08-26 0001181431-05-049163 — 1.01
- 2005-08-15 0001181431-05-046871 — 1.01
- 2005-07-13 0001104659-05-032297 — 2.02, 9.01
- 2005-06-06 0001181431-05-033177 — 8.01
- 2005-04-26 0001181431-05-023450 — 1.01
- 2005-04-13 0001104659-05-016307 — 2.02, 9.01
- 2005-03-02 0001181431-05-013840 — 3.03, 5.03
- 2005-02-11 0001104659-05-005507 — 8.01
- 2005-01-12 0001104659-05-001183 — 2.02, 9.01
- 2005-01-11 0001104659-05-001049 — 2.02
- 2004-10-13 0001104659-04-030400 — 2.02, 9.01
- 2004-07-14 0001104659-04-019574 — 12, 7
- 2004-04-14 0001104659-04-010122 — 12, 7
- 2004-01-14 0001104659-04-000896 — 12, 7
- 2003-10-15 0001104659-03-022879 — 12, 7
- 2003-07-16 0001104659-03-014913 — 7, 9
- 2003-04-16 0001047469-03-013617 — 7, 9
- 2003-03-21 0001104659-03-004649 — 5, 7
- 2002-08-13 0000912057-02-031595 — 5, 7
- 2002-08-05 0000912057-02-029692 — 5, 7
- 2000-01-24 0000912057-00-002128 — 5, 7
- 1999-09-07 0000320193-99-000010 — 2
- 1999-07-16 0000320193-99-000007 — 2
- 1998-12-23 0000320193-98-000010 — 1
- 1998-01-08 0000320193-98-000001 — 2
- 1997-09-25 0000320193-97-000019 — 2
- 1997-09-25 0000320193-97-000018 — 2
- 1997-09-05 0000320193-97-000016 — 2
- 1997-07-28 0000320193-97-000012 — 4
- 1997-04-25 0000320193-97-000009 — 5
- 1997-04-10 0000320193-97-000007 — 7
- 1996-12-24 0000320193-96-000027 — 7
- 1996-12-23 0000320193-96-000025 — 4 — amendment of 0000320193-96-000021
- 1996-12-13 0000320193-96-000021 — 4
- 1996-10-28 0000912057-96-023874 — 5, 7
- 1996-06-17 0000320193-96-000014 — 1
- 1996-04-12 0000320193-96-000006 — 1

## late-filing notifications on or before 2017-05-03

- 2006-12-15 0001104659-06-081617 — NT 10-K, for the period ended 2006-09-30
- 2006-08-11 0001104659-06-053743 — NT 10-Q, for the period ended 2006-07-01

## item 2.02 — earnings release, exhibit 99.1

[0001628280-17-004663:8k_2_02:1]
EX-99.1
2
a8-kexhibit991q22017412017.htm
EXHIBIT 99.1

[0001628280-17-004663:8k_2_02:2]
Exhibit

[0001628280-17-004663:8k_2_02:3]
Exhibit 99.1

[0001628280-17-004663:8k_2_02:4]
Apple Reports Second Quarter Results

[0001628280-17-004663:8k_2_02:5]
Capital Return Program Expanding to $300 Billion

[0001628280-17-004663:8k_2_02:6]
CUPERTINO, California — May 2, 2017 — Apple® today announced financial results for its fiscal 2017 second quarter ended April 1, 2017. The Company posted quarterly revenue of $52.9 billion and quarterly earnings per diluted share of $2.10. These results compare to revenue of $50.6 billion and earnings per diluted share of $1.90 in the year-ago quarter. International sales accounted for 65 percent of the quarter’s revenue.

[0001628280-17-004663:8k_2_02:7]
“We are proud to report a strong March quarter, with revenue growth accelerating from the December quarter and continued robust demand for iPhone 7 Plus,” said Tim Cook, Apple’s CEO. “We’ve seen great customer response to both models of the new iPhone 7 (PRODUCT)RED Special Edition and we’re thrilled with the strong momentum of our Services business, with our highest revenue ever for a 13-week quarter. Looking ahead, we are excited to welcome attendees from around the world to our annual Worldwide Developers Conference next month in San Jose.”

[0001628280-17-004663:8k_2_02:8]
Apple also announced that its Board of Directors has authorized an increase of $50 billion to the Company’s program to return capital to shareholders and is extending the program timeframe by four quarters.  Under the expanded program, Apple plans to spend a cumulative total of $300 billion by the end of March 2019.

[0001628280-17-004663:8k_2_02:9]
“We generated strong operating cash flow of $12.5 billion and returned over $10 billion to our investors in the March quarter,” said Luca Maestri, Apple’s CFO. “Given the strength of our business and our confidence in our future, we are happy to announce another $50 billion increase to our capital return program today.”

[0001628280-17-004663:8k_2_02:10]
As part of the latest update to the program, the Board has increased its share repurchase authorization to $210 billion from the $175 billion level announced a year ago. The Company also expects to continue to net-share-settle vesting restricted stock units.

[0001628280-17-004663:8k_2_02:11]
The Board has approved a 10.5% increase to the Company’s quarterly dividend, and has declared a dividend of $0.63 per share of the Company’s common stock, payable on May 18, 2017 to shareholders of record as of the close of business on May 15, 2017.

[0001628280-17-004663:8k_2_02:12]
From the inception of its capital return program in August 2012 through March 2017, Apple has returned over $211 billion to shareholders, including $151 billion in share repurchases.

[0001628280-17-004663:8k_2_02:13]
The Company plans to continue to access the domestic and international debt markets to assist in funding the program. The management team and the Board will continue to review each element of the capital return program regularly and plan to provide an update on the program on an annual basis.

[0001628280-17-004663:8k_2_02:14]
Apple is providing the following guidance for its fiscal 2017 third quarter:

[0001628280-17-004663:8k_2_02:15]
| • | revenue between $43.5 billion and $45.5 billion |

[0001628280-17-004663:8k_2_02:16]
| • | gross margin between 37.5 percent and 38.5 percent |

[0001628280-17-004663:8k_2_02:17]
| • | operating expenses between $6.6 billion and $6.7 billion |

[0001628280-17-004663:8k_2_02:18]
| • | other income/(expense) of $450 million |

[0001628280-17-004663:8k_2_02:19]
| • | tax rate of 25.5 percent |

[0001628280-17-004663:8k_2_02:20]
Apple will provide live streaming of its Q2 2017 financial results conference call beginning at 2:00 p.m. PDT on May 2, 2017 at www.apple.com/investor/earnings-call/. This webcast will also be available for replay for approximately two weeks thereafter.

[0001628280-17-004663:8k_2_02:21]
Apple revolutionized personal technology with the introduction of the Macintosh in 1984. Today, Apple leads the world in innovation with iPhone, iPad, Mac, Apple Watch and Apple TV. Apple’s four software platforms — iOS, macOS, watchOS and tvOS — provide seamless experiences across all Apple devices and empower people with breakthrough services including the App Store, Apple Music, Apple Pay and iCloud. Apple’s more than 100,000 employees are dedicated to making the best products on earth, and to leaving the world better than we found it.

[0001628280-17-004663:8k_2_02:22]
Press Contact:

[0001628280-17-004663:8k_2_02:23]
Kristin Huguet

[0001628280-17-004663:8k_2_02:24]
Apple

[0001628280-17-004663:8k_2_02:25]
khuguet@apple.com

[0001628280-17-004663:8k_2_02:26]
(408) 974-2414

[0001628280-17-004663:8k_2_02:27]
Investor Relations Contacts:

[0001628280-17-004663:8k_2_02:28]
Nancy Paxton

[0001628280-17-004663:8k_2_02:29]
Apple

[0001628280-17-004663:8k_2_02:30]
paxton1@apple.com

[0001628280-17-004663:8k_2_02:31]
(408) 974-5420

[0001628280-17-004663:8k_2_02:32]
Joan Hoover

[0001628280-17-004663:8k_2_02:33]
Apple

[0001628280-17-004663:8k_2_02:34]
hoover1@apple.com

[0001628280-17-004663:8k_2_02:35]
(408) 974-4570

[0001628280-17-004663:8k_2_02:36]
NOTE TO EDITORS: For additional information visit Apple’s PR website (www.apple.com/pr), or call Apple’s Media Helpline at (408) 974-2042.

[0001628280-17-004663:8k_2_02:37]
© 2017 Apple Inc. All rights reserved. Apple and the Apple logo are trademarks of Apple. Other company and product names may be trademarks of their respective owners.

[0001628280-17-004663:8k_2_02:38]
Apple Inc.

[0001628280-17-004663:8k_2_02:39]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS (Unaudited)

[0001628280-17-004663:8k_2_02:40]
(In millions, except number of shares which are reflected in thousands and per share amounts)

[0001628280-17-004663:8k_2_02:41]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1, 2017 |  | March 26, 2016 |  | April 1, 2017 |  | March 26, 2016 |
| Net sales | $ | 52,896 |  |  | $ | 50,557 |  |  | $ | 131,247 |  |  | $ | 126,429 |  |
| Cost of sales (1) | 32,305 |  |  | 30,636 |  |  | 80,480 |  |  | 76,085 |  |
| Gross margin | 20,591 |  |  | 19,921 |  |  | 50,767 |  |  | 50,344 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development (1) | 2,776 |  |  | 2,511 |  |  | 5,647 |  |  | 4,915 |  |
| Selling, general and administrative (1) | 3,718 |  |  | 3,423 |  |  | 7,664 |  |  | 7,271 |  |
| Total operating expenses | 6,494 |  |  | 5,934 |  |  | 13,311 |  |  | 12,186 |  |
| Operating income | 14,097 |  |  | 13,987 |  |  | 37,456 |  |  | 38,158 |  |
| Other income/(expense), net | 587 |  |  | 155 |  |  | 1,408 |  |  | 557 |  |
| Income before provision for income taxes | 14,684 |  |  | 14,142 |  |  | 38,864 |  |  | 38,715 |  |
| Provision for income taxes | 3,655 |  |  | 3,626 |  |  | 9,944 |  |  | 9,838 |  |
| Net income | $ | 11,029 |  |  | $ | 10,516 |  |  | $ | 28,920 |  |  | $ | 28,877 |  |
| Earnings per share: |  |  |  |  |  |  |  |
| Basic | $ | 2.11 |  |  | $ | 1.91 |  |  | $ | 5.50 |  |  | $ | 5.22 |  |
| Diluted | $ | 2.10 |  |  | $ | 1.90 |  |  | $ | 5.46 |  |  | $ | 5.19 |  |
| Shares used in computing earnings per share: |  |  |  |  |  |  |  |
| Basic | 5,225,791 |  |  | 5,514,381 |  |  | 5,262,226 |  |  | 5,536,656 |  |
| Diluted | 5,261,688 |  |  | 5,540,886 |  |  | 5,294,841 |  |  | 5,567,506 |  |
| Cash dividends declared per share | $ | 0.57 |  |  | $ | 0.52 |  |  | $ | 1.14 |  |  | $ | 1.04 |  |
| (1) Includes share-based compensation expense as follows: |
| Cost of sales | $ | 217 |  |  | $ | 191 |  |  | $ | 446 |  |  | $ | 395 |  |
| Research and development | $ | 575 |  |  | $ | 468 |  |  | $ | 1,164 |  |  | $ | 934 |  |
| Selling, general and administrative | $ | 425 |  |  | $ | 389 |  |  | $ | 863 |  |  | $ | 797 |  |

[0001628280-17-004663:8k_2_02:42]
Apple Inc.

[0001628280-17-004663:8k_2_02:43]
CONDENSED CONSOLIDATED BALANCE SHEETS (Unaudited)

[0001628280-17-004663:8k_2_02:44]
(In millions, except number of shares which are reflected in thousands and par value)

[0001628280-17-004663:8k_2_02:45]
|  | April 1, 2017 |  | September 24, 2016 |
| ASSETS: |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 15,157 |  |  | $ | 20,484 |  |
| Short-term marketable securities | 51,944 |  |  | 46,671 |  |
| Accounts receivable, less an allowance of $53 at each period end | 11,579 |  |  | 15,754 |  |
| Inventories | 2,910 |  |  | 2,132 |  |
| Vendor non-trade receivables | 9,033 |  |  | 13,545 |  |
| Other current assets | 11,367 |  |  | 8,283 |  |
| Total current assets | 101,990 |  |  | 106,869 |  |
| Long-term marketable securities | 189,740 |  |  | 170,430 |  |
| Property, plant and equipment, net | 27,163 |  |  | 27,010 |  |
| Goodwill | 5,473 |  |  | 5,414 |  |
| Acquired intangible assets, net | 2,617 |  |  | 3,206 |  |
| Other non-current assets | 7,549 |  |  | 8,757 |  |
| Total assets | $ | 334,532 |  |  | $ | 321,686 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY: |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 28,573 |  |  | $ | 37,294 |  |
| Accrued expenses | 23,096 |  |  | 22,027 |  |
| Deferred revenue | 7,682 |  |  | 8,080 |  |
| Commercial paper | 9,992 |  |  | 8,105 |  |
| Current portion of long-term debt | 3,999 |  |  | 3,500 |  |
| Total current liabilities | 73,342 |  |  | 79,006 |  |
| Deferred revenue, non-current | 3,107 |  |  | 2,930 |  |
| Long-term debt | 84,531 |  |  | 75,427 |  |
| Other non-current liabilities | 39,470 |  |  | 36,074 |  |
| Total liabilities | 200,450 |  |  | 193,437 |  |
| Commitments and contingencies |  |  |  |
| Shareholders’ equity: |  |  |  |
| Common stock and additional paid-in capital, $0.00001 par value: 12,600,000 shares authorized; 5,205,815 and 5,336,166 shares issued and outstanding, respectively | 33,579 |  |  | 31,251 |  |
| Retained earnings | 100,925 |  |  | 96,364 |  |
| Accumulated other comprehensive income/(loss) | (422 | ) |  | 634 |  |
| Total shareholders’ equity | 134,082 |  |  | 128,249 |  |
| Total liabilities and shareholders’ equity | $ | 334,532 |  |  | $ | 321,686 |  |

[0001628280-17-004663:8k_2_02:46]
Apple Inc.

[0001628280-17-004663:8k_2_02:47]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (Unaudited)

[0001628280-17-004663:8k_2_02:48]
(In millions)

[0001628280-17-004663:8k_2_02:49]
|  | Six Months Ended |
|  | April 1, 2017 |  | March 26, 2016 |
| Cash and cash equivalents, beginning of the period | $ | 20,484 |  |  | $ | 21,120 |  |
| Operating activities: |  |  |  |
| Net income | 28,920 |  |  | 28,877 |  |
| Adjustments to reconcile net income to cash generated by operating activities: |  |  |  |
| Depreciation and amortization | 5,319 |  |  | 5,431 |  |
| Share-based compensation expense | 2,473 |  |  | 2,126 |  |
| Deferred income tax expense | 2,822 |  |  | 3,092 |  |
| Other | (209 | ) |  | 308 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | 4,183 |  |  | 4,538 |  |
| Inventories | (778 | ) |  | 68 |  |
| Vendor non-trade receivables | 4,512 |  |  | 5,899 |  |
| Other current and non-current assets | (896 | ) |  | 186 |  |
| Accounts payable | (6,862 | ) |  | (9,388 | ) |
| Deferred revenue | (221 | ) |  | 219 |  |
| Other current and non-current liabilities | 316 |  |  | (2,292 | ) |
| Cash generated by operating activities | 39,579 |  |  | 39,064 |  |
| Investing activities: |  |  |  |
| Purchases of marketable securities | (99,821 | ) |  | (86,242 | ) |
| Proceeds from maturities of marketable securities | 12,429 |  |  | 9,148 |  |
| Proceeds from sales of marketable securities | 60,454 |  |  | 50,051 |  |
| Payments made in connection with business acquisitions, net | (67 | ) |  | (140 | ) |
| Payments for acquisition of property, plant and equipment | (6,309 | ) |  | (5,948 | ) |
| Payments for acquisition of intangible assets | (126 | ) |  | (657 | ) |
| Payments for strategic investments | — |  |  | (126 | ) |
| Other | 116 |  |  | (196 | ) |
| Cash used in investing activities | (33,324 | ) |  | (34,110 | ) |
| Financing activities: |  |  |  |
| Proceeds from issuance of common stock | 273 |  |  | 247 |  |
| Excess tax benefits from equity awards | 225 |  |  | 264 |  |
| Payments for taxes related to net share settlement of equity awards | (788 | ) |  | (751 | ) |
| Payments for dividends and dividend equivalents | (6,134 | ) |  | (5,871 | ) |
| Repurchases of common stock | (18,012 | ) |  | (13,530 | ) |
| Proceeds from issuance of term debt, net | 10,975 |  |  | 15,584 |  |
| Change in commercial paper, net | 1,879 |  |  | (503 | ) |
| Cash used in financing activities | (11,582 | ) |  | (4,560 | ) |
| Increase/(Decrease) in cash and cash equivalents | (5,327 | ) |  | 394 |  |
| Cash and cash equivalents, end of the period | $ | 15,157 |  |  | $ | 21,514 |  |
| Supplemental cash flow disclosure: |  |  |  |
| Cash paid for income taxes, net | $ | 6,878 |  |  | $ | 6,630 |  |
| Cash paid for interest | $ | 1,007 |  |  | $ | 565 |  |
