# AAPL note change history — 0001628280-17-000717 → 0001628280-17-004790


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-05-03):
[0001628280-17-004790:note_history:1]
The following table shows changes in the Company’s accrued warranties and related costs for the three- and six-month periods ended April 1, 2017 and March 26, 2016 (in millions):
  (was, 2017-02-01, similarity 0.8902):
[0001628280-17-000717:note_history:1]
The following table shows changes in the Company’s accrued warranties and related costs for the three months ended December 31, 2016 and December 26, 2015 (in millions):

- added (2017-05-03):
[0001628280-17-004790:note_history:2]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1, 2017 |  | March 26, 2016 |  | April 1, 2017 |  | March 26, 2016 |
| Beginning accrued warranty and related costs | $ | 4,698 |  |  | $ | 5,236 |  |  | $ | 3,702 |  |  | $ | 4,780 |  |
| Cost of warranty claims | (1,031 | ) |  | (1,128 | ) |  | (2,368 | ) |  | (2,397 | ) |
| Accruals for product warranty | 1,068 |  |  | 877 |  |  | 3,401 |  |  | 2,602 |  |
| Ending accrued warranty and related costs | $ | 4,735 |  |  | $ | 4,985 |  |  | $ | 4,735 |  |  | $ | 4,985 |  |

- changed (2017-05-03):
[0001628280-17-004790:note_history:3]
The Company generally does not indemnify end-users of its operating system and application software against legal claims that the software infringes third-party intellectual property rights. Other agreements entered into by the Company sometimes include indemnification provisions under which the Company could be subject to costs and/or damages in the event of an infringement claim against the Company or an indemnified third party. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss with respect to indemnification of end-users of its operating system or application software for infringement of third-party intellectual property rights.
  (was, 2017-02-01, similarity 0.9986):
[0001628280-17-000717:note_history:3]
The Company generally does not indemnify end-users of its operating system and application software against legal claims that the software infringes third-party intellectual property rights. Other agreements entered into by the Company sometimes include indemnification provisions under which the Company could be subject to costs and/or damages in the event of an infringement claim against the Company or an indemnified third-party. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss with respect to indemnification of end-users of its operating system or application software for infringement of third-party intellectual property rights.

- changed (2017-05-03):
[0001628280-17-004790:note_history:4]
The Company uses some custom components that are not commonly used by its competitors, and new products introduced by the Company often utilize custom components available from only one source. When a component or product uses new technologies, initial capacity constraints may exist until the suppliers’ yields have matured or manufacturing capacity has increased. If the Company’s supply of components for a new or existing product were delayed or constrained, or if an outsourcing partner delayed shipments of completed products to the Company, the Company’s financial condition and operating results could be materially adversely affected. The Company’s business and financial performance could also be materially adversely affected depending on the time required to obtain sufficient quantities from the original source, or to identify and obtain sufficient quantities from an alternative source. Continued availability of these components at acceptable prices, or at all, may be affected if those suppliers decide to concentrate on the production of common components instead of components customized to meet the Company’s requirements.
  (was, 2017-02-01, similarity 0.9855):
[0001628280-17-000717:note_history:4]
The Company uses some custom components that are not commonly used by its competitors, and new products introduced by the Company often utilize custom components available from only one source. When a component or product uses new technologies, initial capacity constraints may exist until the suppliers’ yields have matured or manufacturing capacity has increased. If the Company’s supply of components for a new or existing product were delayed or constrained, or if an outsourcing partner delayed shipments of completed products to the Company, the Company’s financial condition and operating results could be materially adversely affected. The Company’s business and financial performance could also be materially adversely affected depending on the time required to obtain sufficient quantities from the original source, or to identify and obtain sufficient quantities from an alternative source. Continued availability of these components at acceptable prices, or at all, may be affected if those suppliers concentrated on the production of common components instead of components customized to meet the Company’s requirements.

- changed (2017-05-03):
[0001628280-17-004790:note_history:5]
The Company leases various equipment and facilities, including retail space, under noncancelable operating lease arrangements. The Company does not currently utilize any other off-balance sheet financing arrangements. As of April 1, 2017, the Company’s total future minimum lease payments under noncancelable operating leases were $8.2 billion. The Company's retail store and other facility leases are typically for terms not exceeding 10 years and generally contain multi-year renewal options.
  (was, 2017-02-01, similarity 0.9867):
[0001628280-17-000717:note_history:5]
The Company leases various equipment and facilities, including retail space, under noncancelable operating lease arrangements. The Company does not currently utilize any other off-balance sheet financing arrangements. As of December 31, 2016, the Company’s total future minimum lease payments under noncancelable operating leases were $7.5 billion. The Company's retail store and other facility leases are typically for terms not exceeding 10 years and generally contain multi-year renewal options.

- changed (2017-05-03):
[0001628280-17-004790:note_history:6]
On August 24, 2012, a jury returned a verdict awarding the Company $1.05 billion in its lawsuit against Samsung Electronics Co., Ltd. and affiliated parties in the United States District Court, Northern District of California, San Jose Division. On March 6, 2014, the District Court entered final judgment in favor of the Company in the amount of approximately $930 million. On May 18, 2015, the U.S. Court of Appeals for the Federal Circuit affirmed in part, and reversed in part, the decision of the District Court. As a result, the Court of Appeals ordered entry of final judgment on damages in the amount of approximately $548 million, with the District Court to determine supplemental damages and interest, as well as damages owed for products subject to the reversal in part. Samsung paid $548 million to the Company in December 2015, which was included in net sales in the Condensed Consolidated Statement of Operations. On December 6, 2016, the U.S. Supreme Court remanded the case to the U.S. Court of Appeals for the Federal Circuit for further proceedings related to the $548 million in damages. On February 7, 2017, the U.S. Court of Appeals for the Federal Circuit remanded the case to the District Court to determine what additional proceedings, if any, are needed. Because the case remains subject to further proceedings, the Company has not recognized any further amounts in its results of operations.
  (was, 2017-02-01, similarity 0.9349):
[0001628280-17-000717:note_history:6]
On August 24, 2012, a jury returned a verdict awarding the Company $1.05 billion in its lawsuit against Samsung Electronics Co., Ltd. and affiliated parties in the United States District Court, Northern District of California, San Jose Division. On March 6, 2014, the District Court entered final judgment in favor of the Company in the amount of approximately $930 million. On May 18, 2015, the U.S. Court of Appeals for the Federal Circuit affirmed in part, and reversed in part, the decision of the District Court. As a result, the Court of Appeals ordered entry of final judgment on damages in the amount of approximately $548 million, with the District Court to determine supplemental damages and interest, as well as damages owed for products subject to the reversal in part. Samsung paid $548 million to the Company in December 2015, which was included in net sales in the Condensed Consolidated Statement of Operations. On December 6, 2016, the U.S. Supreme Court remanded the case to the U.S. Court of Appeals for the Federal Circuit for further proceedings related to the $548 million in damages. Because the case remains subject to further proceedings, the Company has not recognized any further amounts in its results of operations.

- removed (2017-05-03):
[0001628280-17-000717:note_history:7]
|  | Three Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |
| Beginning accrued warranty and related costs | $ | 3,702 |  |  | $ | 4,780 |  |
| Cost of warranty claims | (1,337 | ) |  | (1,269 | ) |
| Accruals for product warranty | 2,333 |  |  | 1,725 |  |
| Ending accrued warranty and related costs | $ | 4,698 |  |  | $ | 5,236 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-05-03):
[0001628280-17-004790:note_history:8]
Apple Inc. and its wholly-owned subsidiaries (collectively “Apple” or the “Company”) designs, manufactures and markets mobile communication and media devices and personal computers, and sells a variety of related software, services, accessories, networking solutions and third-party digital content and applications. The Company’s products and services include iPhone®, iPad®, Mac®, Apple Watch®, Apple TV®, a portfolio of consumer and professional software applications, iOS, macOS®, watchOS® and tvOS™ operating systems, iCloud®, Apple Pay® and a variety of accessory, service and support offerings. The Company sells and delivers digital content and applications through the iTunes Store®, App Store®, Mac App Store, TV App Store, iBooks Store™ and Apple Music® (collectively “Digital Content and Services”). The Company sells its products worldwide through its retail stores, online stores and direct sales force, as well as through third-party cellular network carriers, wholesalers, retailers and value-added resellers. In addition, the Company sells a variety of third-party Apple-compatible products, including application software and various accessories through its retail and online stores. The Company sells to consumers, small and mid-sized businesses and education, enterprise and government customers.
  (was, 2017-02-01, similarity 0.9697):
[0001628280-17-000717:note_history:8]
Apple Inc. and its wholly-owned subsidiaries (collectively “Apple” or the “Company”) designs, manufactures and markets mobile communication and media devices, personal computers and portable digital music players, and sells a variety of related software, services, accessories, networking solutions and third-party digital content and applications. The Company’s products and services include iPhone®, iPad®, Mac®, iPod®, Apple Watch®, Apple TV®, a portfolio of consumer and professional software applications, iOS, macOS™, watchOS® and tvOS™ operating systems, iCloud®, Apple Pay® and a variety of accessory, service and support offerings. The Company sells and delivers digital content and applications through the iTunes Store®, App Store®, Mac App Store, TV App Store, iBooks Store™ and Apple Music® (collectively “Digital Content and Services”). The Company sells its products worldwide through its retail stores, online stores and direct sales force, as well as through third-party cellular network carriers, wholesalers, retailers and value-added resellers. In addition, the Company sells a variety of third-party Apple-compatible products, including application software and various accessories through its retail and online stores. The Company sells to consumers, small and mid-sized businesses and education, enterprise and government customers.

- changed (2017-05-03):
[0001628280-17-004790:note_history:9]
The Company’s fiscal year is the 52 or 53-week period that ends on the last Saturday of September. The Company’s fiscal year 2017 will include 53 weeks and ends on September 30, 2017 and its fiscal year 2016 included 52 weeks and ended on September 24, 2016. A 14th week was included in the first quarter of 2017, as is done every five or six years, to realign fiscal quarters with calendar quarters. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in September and the associated quarters, months and periods of those fiscal years.
  (was, 2017-02-01, similarity 0.9907):
[0001628280-17-000717:note_history:9]
The Company’s fiscal year is the 52 or 53-week period that ends on the last Saturday of September. The Company’s fiscal year 2017 will include 53 weeks and ends on September 30, 2017 and its fiscal year 2016 included 52 weeks and ended on September 24, 2016. A 14th week has been included in the first quarter of 2017, as is done every five or six years, to realign fiscal quarters with calendar quarters. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in September and the associated quarters, months and periods of those fiscal years.

- changed (2017-05-03):
[0001628280-17-004790:note_history:10]
The following table shows the computation of basic and diluted earnings per share for the three- and six-month periods ended April 1, 2017 and March 26, 2016 (net income in millions and shares in thousands):
  (was, 2017-02-01, similarity 0.9067):
[0001628280-17-000717:note_history:10]
The following table shows the computation of basic and diluted earnings per share for the three months ended December 31, 2016 and December 26, 2015 (net income in millions and shares in thousands):

- changed (2017-05-03):
[0001628280-17-004790:note_history:11]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1, 2017 |  | March 26, 2016 |  | April 1, 2017 |  | March 26, 2016 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 11,029 |  |  | $ | 10,516 |  |  | $ | 28,920 |  |  | $ | 28,877 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average shares outstanding | 5,225,791 |  |  | 5,514,381 |  |  | 5,262,226 |  |  | 5,536,656 |  |
| Effect of dilutive securities | 35,897 |  |  | 26,505 |  |  | 32,615 |  |  | 30,850 |  |
| Weighted-average diluted shares | 5,261,688 |  |  | 5,540,886 |  |  | 5,294,841 |  |  | 5,567,506 |  |
| Basic earnings per share | $ | 2.11 |  |  | $ | 1.91 |  |  | $ | 5.50 |  |  | $ | 5.22 |  |
| Diluted earnings per share | $ | 2.10 |  |  | $ | 1.90 |  |  | $ | 5.46 |  |  | $ | 5.19 |  |
  (was, 2017-02-01, similarity 0.74):
[0001628280-17-000717:note_history:11]
|  | Three Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |
| Numerator: |  |  |  |
| Net income | $ | 17,891 |  |  | $ | 18,361 |  |
| Denominator: |  |  |  |
| Weighted-average shares outstanding | 5,298,661 |  |  | 5,558,930 |  |
| Effect of dilutive securities | 29,334 |  |  | 35,197 |  |
| Weighted-average diluted shares | 5,327,995 |  |  | 5,594,127 |  |
| Basic earnings per share | $ | 3.38 |  |  | $ | 3.30 |  |
| Diluted earnings per share | $ | 3.36 |  |  | $ | 3.28 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-05-03):
[0001628280-17-004790:note_history:12]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of April 1, 2017 and September 24, 2016, the Company had $10.0 billion and $8.1 billion of Commercial Paper outstanding, respectively, with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 0.80% as of April 1, 2017 and 0.45% as of September 24, 2016.
  (was, 2017-02-01, similarity 0.9527):
[0001628280-17-000717:note_history:12]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of December 31, 2016 and September 24, 2016, the Company had $10.5 billion and $8.1 billion of Commercial Paper outstanding, respectively, with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 0.61% as of December 31, 2016 and 0.45% as of September 24, 2016.

- changed (2017-05-03):
[0001628280-17-004790:note_history:13]
The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the six months ended April 1, 2017 and March 26, 2016 (in millions):
  (was, 2017-02-01, similarity 0.9239):
[0001628280-17-000717:note_history:13]
The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the three months ended December 31, 2016 and December 26, 2015 (in millions):

- changed (2017-05-03):
[0001628280-17-004790:note_history:14]
|  | Six Months Ended |
|  | April 1, 2017 |  | March 26, 2016 |
| Maturities less than 90 days: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | (1,318 | ) |  | $ | 660 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 7,057 |  |  | 669 |  |
| Repayments of commercial paper | (3,860 | ) |  | (1,832 | ) |
| Proceeds from/(Repayments of) commercial paper, net | 3,197 |  |  | (1,163 | ) |
| Total change in commercial paper, net | $ | 1,879 |  |  | $ | (503 | ) |
  (was, 2017-02-01, similarity 0.8874):
[0001628280-17-000717:note_history:14]
|  | Three Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |
| Maturities less than 90 days: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | 1,550 |  |  | $ | (393 | ) |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 2,544 |  |  | 492 |  |
| Repayments of commercial paper | (1,709 | ) |  | (1,339 | ) |
| Proceeds from/(Repayments of) commercial paper, net | 835 |  |  | (847 | ) |
| Total change in commercial paper, net | $ | 2,385 |  |  | $ | (1,240 | ) |

- changed (2017-05-03):
[0001628280-17-004790:note_history:15]
As of April 1, 2017, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $88.9 billion (collectively the “Notes”). The Notes are senior unsecured obligations, and interest is payable in arrears, quarterly for the U.S. dollar-denominated and Australian dollar-denominated floating-rate notes, semi-annually for the U.S. dollar-denominated, Australian dollar-denominated, British pound-denominated and Japanese yen-denominated fixed-rate notes and annually for the euro-denominated and Swiss franc-denominated fixed-rate notes. The following table provides a summary of the Company’s term debt as of April 1, 2017 and September 24, 2016:
  (was, 2017-02-01, similarity 0.9811):
[0001628280-17-000717:note_history:15]
As of December 31, 2016, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $77.4 billion (collectively the “Notes”). The Notes are senior unsecured obligations, and interest is payable in arrears, quarterly for the U.S. dollar-denominated and Australian dollar-denominated floating-rate notes, semi-annually for the U.S. dollar-denominated, Australian dollar-denominated, British pound-denominated and Japanese yen-denominated fixed-rate notes and annually for the euro-denominated and Swiss franc-denominated fixed-rate notes. The following table provides a summary of the Company’s term debt as of December 31, 2016 and September 24, 2016:

- added (2017-05-03):
[0001628280-17-004790:note_history:16]
|  | Maturities |  | April 1, 2017 |  | September 24, 2016 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2018 |  | 2018 |  | $ | 2,000 |  |  |  | 1.10% |  | 1.10 | % |  | $ | 2,000 |  |  |  | 1.10% |  | 1.10 | % |
| Fixed-rate 1.000% – 3.850% notes | 2018 | – | 2043 |  | 12,500 |  |  |  | 1.08% | – | 3.91 | % |  | 12,500 |  |  |  | 1.08% | – | 3.91 | % |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2017 | – | 2019 |  | 2,000 |  |  |  | 1.10% | – | 1.33 | % |  | 2,000 |  |  |  | 0.86% | – | 1.09 | % |
| Fixed-rate 1.050% – 4.450% notes | 2017 | – | 2044 |  | 10,000 |  |  |  | 1.10% | – | 4.48 | % |  | 10,000 |  |  |  | 0.85% | – | 4.48 | % |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2017 | – | 2020 |  | 1,785 |  |  |  | 1.08% | – | 1.87 | % |  | 1,781 |  |  |  | 0.87% | – | 1.87 | % |
| Fixed-rate 0.350% – 4.375% notes | 2017 | – | 2045 |  | 24,668 |  |  |  | 0.28% | – | 4.51 | % |  | 25,144 |  |  |  | 0.28% | – | 4.51 | % |
| 2016 debt issuances of $24.9 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2021 |  | 1,350 |  |  |  | 1.17% | – | 2.18 | % |  | 1,350 |  |  |  | 0.91% | – | 1.95 | % |
| Fixed-rate 1.100% – 4.650% notes | 2018 | – | 2046 |  | 23,616 |  |  |  | 1.13% | – | 4.78 | % |  | 23,609 |  |  |  | 1.13% | – | 4.58 | % |
| Second quarter 2017 debt issuance of $10.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2019 |  | 500 |  |  |  |  |  | 1.12 | % |  | — |  |  |  |  |  | — | % |
| Floating-rate notes |  |  | 2020 |  | 500 |  |  |  |  |  | 1.24 | % |  | — |  |  |  |  |  | — | % |
| Floating-rate notes |  |  | 2022 |  | 1,000 |  |  |  |  |  | 1.54 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 1.550% notes |  |  | 2019 |  | 500 |  |  |  |  |  | 1.59 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 1.900% notes |  |  | 2020 |  | 1,000 |  |  |  |  |  | 1.24 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.500% notes |  |  | 2022 |  | 1,500 |  |  |  |  |  | 1.53 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.000% notes |  |  | 2024 |  | 1,750 |  |  |  |  |  | 1.83 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.350% notes |  |  | 2027 |  | 2,250 |  |  |  |  |  | 1.98 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 4.250% notes |  |  | 2047 |  | 1,000 |  |  |  |  |  | 4.26 | % |  | — |  |  |  |  |  | — | % |
| Second quarter 2017 debt issuance of $1.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 4.300% notes |  |  | 2047 |  | 1,000 |  |  |  |  |  | 4.30 | % |  | — |  |  |  |  |  | — | % |
| Total term debt |  |  |  |  | 88,919 |  |  |  |  |  |  |  | 78,384 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (184 | ) |  |  |  |  |  |  | (174 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | (205 | ) |  |  |  |  |  |  | 717 |  |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  |  |  | (3,999 | ) |  |  |  |  |  |  | (3,500 | ) |  |  |  |  |  |
| Total long-term debt |  |  |  |  | $ | 84,531 |  |  |  |  |  |  |  | $ | 75,427 |  |  |  |  |  |  |

- added (2017-05-03):
[0001628280-17-004790:note_history:17]
During the second quarter of 2017, the Company issued $10.0 billion of U.S. dollar-denominated notes in the United States and $1.0 billion of U.S. dollar-denominated notes in Taiwan. To manage interest rate risk on the fixed-rate notes maturing in 2020, 2022, 2024 and 2027, the Company entered into interest rate swaps with an aggregate notional amount of $6.5 billion, which effectively converted the fixed interest rates on these notes to floating interest rates.

- added (2017-05-03):
[0001628280-17-004790:note_history:18]
A portion of the Company's Japanese yen-denominated notes is designated as a hedge of the foreign currency exposure of the Company's net investment in a foreign operation. The foreign currency transaction gain or loss on the Japanese yen-denominated debt designated as a hedge is recorded in OCI as a part of the cumulative translation adjustment. As of April 1, 2017 and September 24, 2016, the carrying value of the debt designated as a net investment hedge was $1.7 billion and $1.9 billion, respectively. For further discussion regarding the Company’s use of derivative instruments see the Derivative Financial Instruments section of Note 2, “Financial Instruments.”

- added (2017-05-03):
[0001628280-17-004790:note_history:19]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount and, if applicable, adjustments related to hedging. The Company recognized $507 million and $1.0 billion of interest expense on its term debt for the three- and six-month periods ended April 1, 2017, respectively. The Company recognized $311 million and $582 million of interest expense on its term debt for the three- and six-month periods ended March 26, 2016, respectively.

- changed (2017-05-03):
[0001628280-17-004790:note_history:20]
As of April 1, 2017 and September 24, 2016, the fair value of the Company’s Notes, based on Level 2 inputs, was $89.7 billion and $81.7 billion, respectively.
  (was, 2017-02-01, similarity 0.9617):
[0001628280-17-000717:note_history:20]
As of December 31, 2016 and September 24, 2016, the fair value of the Company’s Notes, based on Level 2 inputs, was $77.7 billion and $81.7 billion, respectively.

- removed (2017-05-03):
[0001628280-17-000717:note_history:21]
|  | Maturities |  | December 31, 2016 |  | September 24, 2016 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2018 |  | $ | 2,000 |  |  | 1.10% |  | $ | 2,000 |  |  | 1.10% |
| Fixed-rate 1.000% - 3.850% notes | 2018 - 2043 |  | 12,500 |  |  | 1.08% - 3.91% |  | 12,500 |  |  | 1.08% - 3.91% |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2017 - 2019 |  | 2,000 |  |  | 0.95% - 1.18% |  | 2,000 |  |  | 0.86% - 1.09% |
| Fixed-rate 1.050% - 4.450% notes | 2017 - 2044 |  | 10,000 |  |  | 0.95% - 4.48% |  | 10,000 |  |  | 0.85% - 4.48% |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2017 - 2020 |  | 1,753 |  |  | 0.95% - 1.87% |  | 1,781 |  |  | 0.87% - 1.87% |
| Fixed-rate 0.350% - 4.375% notes | 2017 - 2045 |  | 24,225 |  |  | 0.28% - 4.51% |  | 25,144 |  |  | 0.28% - 4.51% |
| 2016 debt issuances of $24.9 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 - 2021 |  | 1,350 |  |  | 1.02% - 2.05% |  | 1,350 |  |  | 0.91% - 1.95% |
| Fixed-rate 1.100% - 4.650% notes | 2018 - 2046 |  | 23,550 |  |  | 1.13% - 4.78% |  | 23,609 |  |  | 1.13% - 4.58% |
| Total term debt |  |  | 77,378 |  |  |  |  | 78,384 |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  | (166 | ) |  |  |  | (174 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | (156 | ) |  |  |  | 717 |  |  |  |
| Less: Current portion of long-term debt |  |  | (3,499 | ) |  |  |  | (3,500 | ) |  |  |
| Total long-term debt |  |  | $ | 73,557 |  |  |  |  | $ | 75,427 |  |  |  |

- removed (2017-05-03):
[0001628280-17-000717:note_history:22]
As of December 31, 2016 and September 24, 2016, ¥90.4 billion and ¥195.5 billion, respectively, of Japanese yen-denominated notes were designated as a hedge of the foreign currency exposure of the Company's net investment in a foreign operation. The foreign currency transaction gain or loss on the Japanese yen-denominated debt designated as a hedge is recorded in OCI as a part of the cumulative translation adjustment. As of December 31, 2016 and September 24, 2016, the carrying value of the debt designated as a net investment hedge was $767 million and $1.9 billion, respectively. For further discussion regarding the Company’s use of derivative instruments see the Derivative Financial Instruments section of Note 2, “Financial Instruments.”

- removed (2017-05-03):
[0001628280-17-000717:note_history:23]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount and, if applicable, adjustments related to hedging. The Company recognized $509 million and $271 million of interest expense on its term debt for the three months ended December 31, 2016 and December 26, 2015, respectively.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-05-03):
[0001628280-17-004790:note_history:24]
he following table provides a summary of the Company’s term debt as of April 1, 2017 and September 24, 2016:
  (was, 2017-02-01, similarity 0.9406):
[0001628280-17-000717:note_history:24]
The following table provides a summary of the Company’s term debt as of December 31, 2016 and September 24, 2016:

- added (2017-05-03):
[0001628280-17-004790:note_history:25]
|  | Maturities |  | April 1, 2017 |  | September 24, 2016 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2018 |  | 2018 |  | $ | 2,000 |  |  |  | 1.10% |  | 1.10 | % |  | $ | 2,000 |  |  |  | 1.10% |  | 1.10 | % |
| Fixed-rate 1.000% – 3.850% notes | 2018 | – | 2043 |  | 12,500 |  |  |  | 1.08% | – | 3.91 | % |  | 12,500 |  |  |  | 1.08% | – | 3.91 | % |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2017 | – | 2019 |  | 2,000 |  |  |  | 1.10% | – | 1.33 | % |  | 2,000 |  |  |  | 0.86% | – | 1.09 | % |
| Fixed-rate 1.050% – 4.450% notes | 2017 | – | 2044 |  | 10,000 |  |  |  | 1.10% | – | 4.48 | % |  | 10,000 |  |  |  | 0.85% | – | 4.48 | % |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2017 | – | 2020 |  | 1,785 |  |  |  | 1.08% | – | 1.87 | % |  | 1,781 |  |  |  | 0.87% | – | 1.87 | % |
| Fixed-rate 0.350% – 4.375% notes | 2017 | – | 2045 |  | 24,668 |  |  |  | 0.28% | – | 4.51 | % |  | 25,144 |  |  |  | 0.28% | – | 4.51 | % |
| 2016 debt issuances of $24.9 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2021 |  | 1,350 |  |  |  | 1.17% | – | 2.18 | % |  | 1,350 |  |  |  | 0.91% | – | 1.95 | % |
| Fixed-rate 1.100% – 4.650% notes | 2018 | – | 2046 |  | 23,616 |  |  |  | 1.13% | – | 4.78 | % |  | 23,609 |  |  |  | 1.13% | – | 4.58 | % |
| Second quarter 2017 debt issuance of $10.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2019 |  | 500 |  |  |  |  |  | 1.12 | % |  | — |  |  |  |  |  | — | % |
| Floating-rate notes |  |  | 2020 |  | 500 |  |  |  |  |  | 1.24 | % |  | — |  |  |  |  |  | — | % |
| Floating-rate notes |  |  | 2022 |  | 1,000 |  |  |  |  |  | 1.54 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 1.550% notes |  |  | 2019 |  | 500 |  |  |  |  |  | 1.59 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 1.900% notes |  |  | 2020 |  | 1,000 |  |  |  |  |  | 1.24 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.500% notes |  |  | 2022 |  | 1,500 |  |  |  |  |  | 1.53 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.000% notes |  |  | 2024 |  | 1,750 |  |  |  |  |  | 1.83 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.350% notes |  |  | 2027 |  | 2,250 |  |  |  |  |  | 1.98 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 4.250% notes |  |  | 2047 |  | 1,000 |  |  |  |  |  | 4.26 | % |  | — |  |  |  |  |  | — | % |
| Second quarter 2017 debt issuance of $1.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 4.300% notes |  |  | 2047 |  | 1,000 |  |  |  |  |  | 4.30 | % |  | — |  |  |  |  |  | — | % |
| Total term debt |  |  |  |  | 88,919 |  |  |  |  |  |  |  | 78,384 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (184 | ) |  |  |  |  |  |  | (174 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | (205 | ) |  |  |  |  |  |  | 717 |  |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  |  |  | (3,999 | ) |  |  |  |  |  |  | (3,500 | ) |  |  |  |  |  |
| Total long-term debt |  |  |  |  | $ | 84,531 |  |  |  |  |  |  |  | $ | 75,427 |  |  |  |  |  |  |

- removed (2017-05-03):
[0001628280-17-000717:note_history:26]
|  | Maturities |  | December 31, 2016 |  | September 24, 2016 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2018 |  | $ | 2,000 |  |  | 1.10% |  | $ | 2,000 |  |  | 1.10% |
| Fixed-rate 1.000% - 3.850% notes | 2018 - 2043 |  | 12,500 |  |  | 1.08% - 3.91% |  | 12,500 |  |  | 1.08% - 3.91% |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2017 - 2019 |  | 2,000 |  |  | 0.95% - 1.18% |  | 2,000 |  |  | 0.86% - 1.09% |
| Fixed-rate 1.050% - 4.450% notes | 2017 - 2044 |  | 10,000 |  |  | 0.95% - 4.48% |  | 10,000 |  |  | 0.85% - 4.48% |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2017 - 2020 |  | 1,753 |  |  | 0.95% - 1.87% |  | 1,781 |  |  | 0.87% - 1.87% |
| Fixed-rate 0.350% - 4.375% notes | 2017 - 2045 |  | 24,225 |  |  | 0.28% - 4.51% |  | 25,144 |  |  | 0.28% - 4.51% |
| 2016 debt issuances of $24.9 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 - 2021 |  | 1,350 |  |  | 1.02% - 2.05% |  | 1,350 |  |  | 0.91% - 1.95% |
| Fixed-rate 1.100% - 4.650% notes | 2018 - 2046 |  | 23,550 |  |  | 1.13% - 4.78% |  | 23,609 |  |  | 1.13% - 4.58% |
| Total term debt |  |  | 77,378 |  |  |  |  | 78,384 |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  | (166 | ) |  |  |  | (174 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | (156 | ) |  |  |  | 717 |  |  |  |
| Less: Current portion of long-term debt |  |  | (3,499 | ) |  |  |  | (3,500 | ) |  |  |
| Total long-term debt |  |  | $ | 73,557 |  |  |  |  | $ | 75,427 |  |  |  |
