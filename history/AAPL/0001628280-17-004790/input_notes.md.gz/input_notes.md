# AAPL notes — 0001628280-17-004790


## aapl:CashCashEquivalentsandAvailableforSaleSecuritiesTableTextBlock

[0001628280-17-004790:notes:1]
The following tables show the Company’s cash and available-for-sale securities by significant investment category as of April 1, 2017 and September 24, 2016 (in millions):

[0001628280-17-004790:notes:2]
|  | April 1, 2017 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | Short-TermMarketableSecurities |  | Long-TermMarketableSecurities |
| Cash | $ | 7,600 |  |  | $ | — |  |  | $ | — |  |  | $ | 7,600 |  |  | $ | 7,600 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 2,742 |  |  | — |  |  | — |  |  | 2,742 |  |  | 2,742 |  |  | — |  |  | — |  |
| Mutual funds | 997 |  |  | — |  |  | (120 | ) |  | 877 |  |  | — |  |  | 877 |  |  | — |  |
| Subtotal | 3,739 |  |  | — |  |  | (120 | ) |  | 3,619 |  |  | 2,742 |  |  | 877 |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 53,365 |  |  | 65 |  |  | (300 | ) |  | 53,130 |  |  | 2,280 |  |  | 16,067 |  |  | 34,783 |  |
| U.S. agency securities | 5,680 |  |  | 3 |  |  | (10 | ) |  | 5,673 |  |  | 687 |  |  | 3,687 |  |  | 1,299 |  |
| Non-U.S. government securities | 7,151 |  |  | 135 |  |  | (67 | ) |  | 7,219 |  |  | — |  |  | 193 |  |  | 7,026 |  |
| Certificates of deposit and time deposits | 6,386 |  |  | — |  |  | — |  |  | 6,386 |  |  | 921 |  |  | 4,665 |  |  | 800 |  |
| Commercial paper | 3,233 |  |  | — |  |  | — |  |  | 3,233 |  |  | 877 |  |  | 2,356 |  |  | — |  |
| Corporate securities | 147,939 |  |  | 643 |  |  | (449 | ) |  | 148,133 |  |  | 50 |  |  | 23,992 |  |  | 124,091 |  |
| Municipal securities | 950 |  |  | 3 |  |  | (3 | ) |  | 950 |  |  | — |  |  | 77 |  |  | 873 |  |
| Mortgage- and asset-backed securities | 21,086 |  |  | 31 |  |  | (219 | ) |  | 20,898 |  |  | — |  |  | 30 |  |  | 20,868 |  |
| Subtotal | 245,790 |  |  | 880 |  |  | (1,048 | ) |  | 245,622 |  |  | 4,815 |  |  | 51,067 |  |  | 189,740 |  |
| Total | $ | 257,129 |  |  | $ | 880 |  |  | $ | (1,168 | ) |  | $ | 256,841 |  |  | $ | 15,157 |  |  | $ | 51,944 |  |  | $ | 189,740 |  |

[0001628280-17-004790:notes:3]
|  | September 24, 2016 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | Short-TermMarketableSecurities |  | Long-TermMarketableSecurities |
| Cash | $ | 8,601 |  |  | $ | — |  |  | $ | — |  |  | $ | 8,601 |  |  | $ | 8,601 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 3,666 |  |  | — |  |  | — |  |  | 3,666 |  |  | 3,666 |  |  | — |  |  | — |  |
| Mutual funds | 1,407 |  |  | — |  |  | (146 | ) |  | 1,261 |  |  | — |  |  | 1,261 |  |  | — |  |
| Subtotal | 5,073 |  |  | — |  |  | (146 | ) |  | 4,927 |  |  | 3,666 |  |  | 1,261 |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 41,697 |  |  | 319 |  |  | (4 | ) |  | 42,012 |  |  | 1,527 |  |  | 13,492 |  |  | 26,993 |  |
| U.S. agency securities | 7,543 |  |  | 16 |  |  | — |  |  | 7,559 |  |  | 2,762 |  |  | 2,441 |  |  | 2,356 |  |
| Non-U.S. government securities | 7,609 |  |  | 259 |  |  | (27 | ) |  | 7,841 |  |  | 110 |  |  | 818 |  |  | 6,913 |  |
| Certificates of deposit and time deposits | 6,598 |  |  | — |  |  | — |  |  | 6,598 |  |  | 1,108 |  |  | 3,897 |  |  | 1,593 |  |
| Commercial paper | 7,433 |  |  | — |  |  | — |  |  | 7,433 |  |  | 2,468 |  |  | 4,965 |  |  | — |  |
| Corporate securities | 131,166 |  |  | 1,409 |  |  | (206 | ) |  | 132,369 |  |  | 242 |  |  | 19,599 |  |  | 112,528 |  |
| Municipal securities | 956 |  |  | 5 |  |  | — |  |  | 961 |  |  | — |  |  | 167 |  |  | 794 |  |
| Mortgage- and asset-backed securities | 19,134 |  |  | 178 |  |  | (28 | ) |  | 19,284 |  |  | — |  |  | 31 |  |  | 19,253 |  |
| Subtotal | 222,136 |  |  | 2,186 |  |  | (265 | ) |  | 224,057 |  |  | 8,217 |  |  | 45,410 |  |  | 170,430 |  |
| Total | $ | 235,810 |  |  | $ | 2,186 |  |  | $ | (411 | ) |  | $ | 237,585 |  |  | $ | 20,484 |  |  | $ | 46,671 |  |  | $ | 170,430 |  |

[0001628280-17-004790:notes:4]
| (1) | Level 1 fair value estimates are based on quoted prices in active markets for identical assets or liabilities. |

[0001628280-17-004790:notes:5]
| (2) | Level 2 fair value estimates are based on observable inputs other than quoted prices in active markets for identical assets and liabilities, quoted prices for identical or similar assets or liabilities in inactive markets, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities. |


## aapl:CommercialPaperCashFlowSummaryTableTextBlock

[0001628280-17-004790:notes:6]
The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the six months ended April 1, 2017 and March 26, 2016 (in millions):

[0001628280-17-004790:notes:7]
|  | Six Months Ended |
|  | April 1, 2017 |  | March 26, 2016 |
| Maturities less than 90 days: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | (1,318 | ) |  | $ | 660 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 7,057 |  |  | 669 |  |
| Repayments of commercial paper | (3,860 | ) |  | (1,832 | ) |
| Proceeds from/(Repayments of) commercial paper, net | 3,197 |  |  | (1,163 | ) |
| Total change in commercial paper, net | $ | 1,879 |  |  | $ | (503 | ) |


## aapl:NotionalAndCreditRiskAmountsOfOutstandingDerivativePositionsDisclosureTextBlock

[0001628280-17-004790:notes:8]
The following table shows the notional amounts of the Company’s outstanding derivative instruments and credit risk amounts associated with outstanding or unsettled derivative instruments as of April 1, 2017 and September 24, 2016 (in millions):

[0001628280-17-004790:notes:9]
|  | April 1, 2017 |  | September 24, 2016 |
|  | NotionalAmount |  | Credit RiskAmount |  | NotionalAmount |  | Credit RiskAmount |
| Instruments designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 37,550 |  |  | $ | 691 |  |  | $ | 44,678 |  |  | $ | 518 |  |
| Interest rate contracts | $ | 31,000 |  |  | $ | 161 |  |  | $ | 24,500 |  |  | $ | 728 |  |
| Instruments not designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 50,573 |  |  | $ | 272 |  |  | $ | 54,305 |  |  | $ | 153 |  |


## aapl:ScheduleOfCommonStockRepurchasedTableTextBlock

[0001628280-17-004790:notes:10]
[same as prior period, unchanged from 0001628280-17-000717:notes:5]

[0001628280-17-004790:notes:11]
|  | Number of Shares(in thousands) |  | Average Repurchase Price Per Share |  | Amount(in millions) |
| 2017: |  |  |  |  |  |
| Second quarter | 31,070 |  |  | $ | 128.74 |  |  | $ | 4,001 |  |
| First quarter | 44,333 |  |  | $ | 112.78 |  |  | 5,000 |  |
| Total open market common stock repurchases | 75,403 |  |  |  |  | $ | 9,001 |  |
| 2016: |  |  |  |  |  |
| Fourth quarter | 28,579 |  |  | $ | 104.97 |  |  | $ | 3,000 |  |
| Third quarter | 41,238 |  |  | $ | 97.00 |  |  | 4,000 |  |
| Second quarter | 71,766 |  |  | $ | 97.54 |  |  | 7,000 |  |
| First quarter | 25,984 |  |  | $ | 115.45 |  |  | 3,000 |  |
| Total open market common stock repurchases | 167,567 |  |  |  |  | $ | 17,000 |  |


## us-gaap:AcceleratedShareRepurchasesTextBlock

[0001628280-17-004790:notes:12]
The following table shows the Company’s ASR activity and related information during the six months ended April 1, 2017 and the year ended September 24, 2016:

[0001628280-17-004790:notes:13]
|  | Purchase PeriodEnd Date |  | Number of Shares(in thousands) |  | Average RepurchasePrice Per Share |  | ASR Amount(in millions) |
| February 2017 ASR | May 2017 |  | 17,527 |  | (1) | (1) |  |  | $ | 3,000 |  |
| November 2016 ASR | February 2017 |  | 51,157 |  | (2) | $ | 117.29 |  |  | $ | 6,000 |  |
| August 2016 ASR | November 2016 |  | 26,850 |  |  | $ | 111.73 |  |  | $ | 3,000 |  |
| May 2016 ASR | August 2016 |  | 60,452 |  |  | $ | 99.25 |  |  | $ | 6,000 |  |
| November 2015 ASR | April 2016 |  | 29,122 |  |  | $ | 103.02 |  |  | $ | 3,000 |  |

[0001628280-17-004790:notes:14]
| (1) | “Number of Shares” represents those shares delivered at the beginning of the purchase period and does not represent the final number of shares to be delivered under the ASR. The total number of shares ultimately delivered, and therefore the average repurchase price paid per share, will be determined at the end of the purchase period based on the volume-weighted average price of the Company’s common stock during that period. The February 2017 ASR purchase period will end in May 2017. |

[0001628280-17-004790:notes:15]
| (2) | Includes 44.8 million shares delivered and retired at the beginning of the purchase period, which began in the first quarter of 2017 and 6.3 million shares delivered and retired at the end of the purchase period, which concluded in the second quarter of 2017. |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001628280-17-004790:notes:16]
[same as prior period, unchanged from 0001628280-17-000717:notes:11]

[0001628280-17-004790:notes:17]
The following tables show the Company’s condensed consolidated financial statement details as of April 1, 2017 and September 24, 2016 (in millions):

[0001628280-17-004790:notes:18]
[same as prior period, unchanged from 0001628280-17-000717:notes:13]

[0001628280-17-004790:notes:19]
|  | April 1, 2017 |  | September 24, 2016 |
| Land and buildings | $ | 11,746 |  |  | $ | 10,185 |  |
| Machinery, equipment and internal-use software | 46,688 |  |  | 44,543 |  |
| Leasehold improvements | 6,690 |  |  | 6,517 |  |
| Gross property, plant and equipment | 65,124 |  |  | 61,245 |  |
| Accumulated depreciation and amortization | (37,961 | ) |  | (34,235 | ) |
| Total property, plant and equipment, net | $ | 27,163 |  |  | $ | 27,010 |  |

[0001628280-17-004790:notes:20]
[same as prior period, unchanged from 0001628280-17-000717:notes:15]

[0001628280-17-004790:notes:21]
|  | April 1, 2017 |  | September 24, 2016 |
| Deferred tax liabilities | $ | 28,226 |  |  | $ | 26,019 |  |
| Other non-current liabilities | 11,244 |  |  | 10,055 |  |
| Total other non-current liabilities | $ | 39,470 |  |  | $ | 36,074 |  |

[0001628280-17-004790:notes:22]
[same as prior period, unchanged from 0001628280-17-000717:notes:17]

[0001628280-17-004790:notes:23]
The following table shows the detail of other income/(expense), net for the three- and six-month periods ended April 1, 2017 and March 26, 2016 (in millions):

[0001628280-17-004790:notes:24]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1, 2017 |  | March 26, 2016 |  | April 1, 2017 |  | March 26, 2016 |
| Interest and dividend income | $ | 1,282 |  |  | $ | 986 |  |  | $ | 2,506 |  |  | $ | 1,927 |  |
| Interest expense | (530 | ) |  | (321 | ) |  | (1,055 | ) |  | (597 | ) |
| Other expense, net | (165 | ) |  | (510 | ) |  | (43 | ) |  | (773 | ) |
| Total other income/(expense), net | $ | 587 |  |  | $ | 155 |  |  | $ | 1,408 |  |  | $ | 557 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001628280-17-004790:notes:25]
[same as prior period, unchanged from 0001628280-17-000717:notes:25]

[0001628280-17-004790:notes:26]
[same as prior period, unchanged from 0001628280-17-000717:notes:26]


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001628280-17-004790:notes:27]
[same as prior period, unchanged from 0001628280-17-000717:notes:27]

[0001628280-17-004790:notes:28]
Apple Inc. and its wholly-owned subsidiaries (collectively “Apple” or the “Company”) designs, manufactures and markets mobile communication and media devices and personal computers, and sells a variety of related software, services, accessories, networking solutions and third-party digital content and applications. The Company’s products and services include iPhone®, iPad®, Mac®, Apple Watch®, Apple TV®, a portfolio of consumer and professional software applications, iOS, macOS®, watchOS® and tvOS™ operating systems, iCloud®, Apple Pay® and a variety of accessory, service and support offerings. The Company sells and delivers digital content and applications through the iTunes Store®, App Store®, Mac App Store, TV App Store, iBooks Store™ and Apple Music® (collectively “Digital Content and Services”). The Company sells its products worldwide through its retail stores, online stores and direct sales force, as well as through third-party cellular network carriers, wholesalers, retailers and value-added resellers. In addition, the Company sells a variety of third-party Apple-compatible products, including application software and various accessories through its retail and online stores. The Company sells to consumers, small and mid-sized businesses and education, enterprise and government customers.

[0001628280-17-004790:notes:29]
The Company’s fiscal year is the 52 or 53-week period that ends on the last Saturday of September. The Company’s fiscal year 2017 will include 53 weeks and ends on September 30, 2017 and its fiscal year 2016 included 52 weeks and ended on September 24, 2016. A 14th week was included in the first quarter of 2017, as is done every five or six years, to realign fiscal quarters with calendar quarters. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in September and the associated quarters, months and periods of those fiscal years.

[0001628280-17-004790:notes:30]
[same as prior period, unchanged from 0001628280-17-000717:notes:30]

[0001628280-17-004790:notes:31]
[same as prior period, unchanged from 0001628280-17-000717:notes:31]

[0001628280-17-004790:notes:32]
The following table shows the computation of basic and diluted earnings per share for the three- and six-month periods ended April 1, 2017 and March 26, 2016 (net income in millions and shares in thousands):

[0001628280-17-004790:notes:33]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1, 2017 |  | March 26, 2016 |  | April 1, 2017 |  | March 26, 2016 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 11,029 |  |  | $ | 10,516 |  |  | $ | 28,920 |  |  | $ | 28,877 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average shares outstanding | 5,225,791 |  |  | 5,514,381 |  |  | 5,262,226 |  |  | 5,536,656 |  |
| Effect of dilutive securities | 35,897 |  |  | 26,505 |  |  | 32,615 |  |  | 30,850 |  |
| Weighted-average diluted shares | 5,261,688 |  |  | 5,540,886 |  |  | 5,294,841 |  |  | 5,567,506 |  |
| Basic earnings per share | $ | 2.11 |  |  | $ | 1.91 |  |  | $ | 5.50 |  |  | $ | 5.22 |  |
| Diluted earnings per share | $ | 2.10 |  |  | $ | 1.90 |  |  | $ | 5.46 |  |  | $ | 5.19 |  |

[0001628280-17-004790:notes:34]
[same as prior period, unchanged from 0001628280-17-000717:notes:34]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-17-004790:notes:35]
Commitments and Contingencies

[0001628280-17-004790:notes:36]
Accrued Warranty and Indemnification

[0001628280-17-004790:notes:37]
The following table shows changes in the Company’s accrued warranties and related costs for the three- and six-month periods ended April 1, 2017 and March 26, 2016 (in millions):

[0001628280-17-004790:notes:38]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1, 2017 |  | March 26, 2016 |  | April 1, 2017 |  | March 26, 2016 |
| Beginning accrued warranty and related costs | $ | 4,698 |  |  | $ | 5,236 |  |  | $ | 3,702 |  |  | $ | 4,780 |  |
| Cost of warranty claims | (1,031 | ) |  | (1,128 | ) |  | (2,368 | ) |  | (2,397 | ) |
| Accruals for product warranty | 1,068 |  |  | 877 |  |  | 3,401 |  |  | 2,602 |  |
| Ending accrued warranty and related costs | $ | 4,735 |  |  | $ | 4,985 |  |  | $ | 4,735 |  |  | $ | 4,985 |  |

[0001628280-17-004790:notes:39]
The Company generally does not indemnify end-users of its operating system and application software against legal claims that the software infringes third-party intellectual property rights. Other agreements entered into by the Company sometimes include indemnification provisions under which the Company could be subject to costs and/or damages in the event of an infringement claim against the Company or an indemnified third party. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss with respect to indemnification of end-users of its operating system or application software for infringement of third-party intellectual property rights.

[0001628280-17-004790:notes:40]
The Company offers an iPhone Upgrade Program, which is available to customers who purchase a qualifying iPhone in the U.S., the U.K. and mainland China. The iPhone Upgrade Program provides customers the right to trade in that iPhone for a specified amount when purchasing a new iPhone, provided certain conditions are met. The Company accounts for the trade-in right as a guarantee liability and recognizes arrangement revenue net of the fair value of such right with subsequent changes to the guarantee liability recognized within revenue.

[0001628280-17-004790:notes:41]
The Company has entered into indemnification agreements with its directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, the Company maintains directors and officers liability insurance coverage to reduce its exposure to such obligations.

[0001628280-17-004790:notes:42]
Concentrations in the Available Sources of Supply of Materials and Product

[0001628280-17-004790:notes:43]
Although most components essential to the Company’s business are generally available from multiple sources, a number of components are currently obtained from single or limited sources. In addition, the Company competes for various components with other participants in the markets for mobile communication and media devices and personal computers. Therefore, many components used by the Company, including those that are available from multiple sources, are at times subject to industry-wide shortage and significant pricing fluctuations that could materially adversely affect the Company’s financial condition and operating results.

[0001628280-17-004790:notes:44]
The Company uses some custom components that are not commonly used by its competitors, and new products introduced by the Company often utilize custom components available from only one source. When a component or product uses new technologies, initial capacity constraints may exist until the suppliers’ yields have matured or manufacturing capacity has increased. If the Company’s supply of components for a new or existing product were delayed or constrained, or if an outsourcing partner delayed shipments of completed products to the Company, the Company’s financial condition and operating results could be materially adversely affected. The Company’s business and financial performance could also be materially adversely affected depending on the time required to obtain sufficient quantities from the original source, or to identify and obtain sufficient quantities from an alternative source. Continued availability of these components at acceptable prices, or at all, may be affected if those suppliers decide to concentrate on the production of common components instead of components customized to meet the Company’s requirements.

[0001628280-17-004790:notes:45]
The Company has entered into agreements for the supply of many components; however, there can be no guarantee that the Company will be able to extend or renew these agreements on similar terms, or at all. Therefore, the Company remains subject to significant risks of supply shortages and price increases that could materially adversely affect its financial condition and operating results.

[0001628280-17-004790:notes:46]
Substantially all of the Company’s hardware products are manufactured by outsourcing partners that are located primarily in Asia. A significant concentration of this manufacturing is currently performed by a small number of outsourcing partners, often in single locations. Certain of these outsourcing partners are the sole-sourced suppliers of components and manufacturers for many of the Company’s products. Although the Company works closely with its outsourcing partners on manufacturing schedules, the Company’s operating results could be adversely affected if its outsourcing partners were unable to meet their production commitments. The Company’s manufacturing purchase obligations typically cover its requirements for periods up to 150 days.

[0001628280-17-004790:notes:47]
Other Off-Balance Sheet Commitments

[0001628280-17-004790:notes:48]
Operating Leases

[0001628280-17-004790:notes:49]
The Company leases various equipment and facilities, including retail space, under noncancelable operating lease arrangements. The Company does not currently utilize any other off-balance sheet financing arrangements. As of April 1, 2017, the Company’s total future minimum lease payments under noncancelable operating leases were $8.2 billion. The Company's retail store and other facility leases are typically for terms not exceeding 10 years and generally contain multi-year renewal options.

[0001628280-17-004790:notes:50]
Contingencies

[0001628280-17-004790:notes:51]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully adjudicated, as further discussed in Part II, Item 1 of this Form 10-Q under the heading “Legal Proceedings” and in Part II, Item 1A of this Form 10-Q under the heading “Risk Factors.” In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to loss contingencies for asserted legal and other claims. However, the outcome of litigation is inherently uncertain. Therefore, although management considers the likelihood of such an outcome to be remote, if one or more of these legal matters were resolved against the Company in a reporting period for amounts in excess of management’s expectations, the Company’s consolidated financial statements for that reporting period could be materially adversely affected.

[0001628280-17-004790:notes:52]
Apple Inc. v. Samsung Electronics Co., Ltd., et al.

[0001628280-17-004790:notes:53]
On August 24, 2012, a jury returned a verdict awarding the Company $1.05 billion in its lawsuit against Samsung Electronics Co., Ltd. and affiliated parties in the United States District Court, Northern District of California, San Jose Division. On March 6, 2014, the District Court entered final judgment in favor of the Company in the amount of approximately $930 million. On May 18, 2015, the U.S. Court of Appeals for the Federal Circuit affirmed in part, and reversed in part, the decision of the District Court. As a result, the Court of Appeals ordered entry of final judgment on damages in the amount of approximately $548 million, with the District Court to determine supplemental damages and interest, as well as damages owed for products subject to the reversal in part. Samsung paid $548 million to the Company in December 2015, which was included in net sales in the Condensed Consolidated Statement of Operations. On December 6, 2016, the U.S. Supreme Court remanded the case to the U.S. Court of Appeals for the Federal Circuit for further proceedings related to the $548 million in damages. On February 7, 2017, the U.S. Court of Appeals for the Federal Circuit remanded the case to the District Court to determine what additional proceedings, if any, are needed. Because the case remains subject to further proceedings, the Company has not recognized any further amounts in its results of operations.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001628280-17-004790:notes:54]
[same as prior period, unchanged from 0001628280-17-000717:notes:54]

[0001628280-17-004790:notes:55]
[same as prior period, unchanged from 0001628280-17-000717:notes:55]

[0001628280-17-004790:notes:56]
The Company had 317.4 million shares reserved for future issuance under its stock plans as of April 1, 2017. RSUs granted generally vest over four years, based on continued employment, and are settled upon vesting in shares of the Company’s common stock on a one-for-one basis. Each share issued with respect to RSUs granted under the Company’s stock plans reduces the number of shares available for grant under the plan by two shares. RSUs cancelled and shares withheld to satisfy tax withholding obligations increase the number of shares available for grant under the plans utilizing a factor of two times the number of RSUs cancelled or shares withheld.

[0001628280-17-004790:notes:57]
[same as prior period, unchanged from 0001628280-17-000717:notes:57]

[0001628280-17-004790:notes:58]
During the three months ended April 1, 2017, Section 16 officers Angela Ahrendts, Timothy D. Cook, Luca Maestri, Daniel Riccio and Philip Schiller had equity trading plans in place in accordance with Rule 10b5-1(c)(1) under the Exchange Act. An equity trading plan is a written document that pre-establishes the amounts, prices and dates (or formula for determining the amounts, prices and dates) of future purchases or sales of the Company’s stock, including shares acquired pursuant to the Company’s employee and director equity plans.

[0001628280-17-004790:notes:59]
[same as prior period, unchanged from 0001628280-17-000717:notes:59]

[0001628280-17-004790:notes:60]
A summary of the Company’s RSU activity and related information for the six months ended April 1, 2017 is as follows:

[0001628280-17-004790:notes:61]
|  | Number ofRSUs(in thousands) |  | Weighted-AverageGrant Date FairValue Per Share |  | Aggregate Fair Value(in millions) |
| Balance at September 24, 2016 | 99,089 |  |  | $ | 97.54 |  |  |  |
| RSUs granted | 45,313 |  |  | $ | 118.36 |  |  |  |
| RSUs vested | (21,942 | ) |  | $ | 92.65 |  |  |  |
| RSUs cancelled | (3,227 | ) |  | $ | 105.68 |  |  |  |
| Balance at April 1, 2017 | 119,233 |  |  | $ | 106.13 |  |  | $ | 17,129 |  |

[0001628280-17-004790:notes:62]
RSUs that vested during the three- and six-month periods ended April 1, 2017 had fair values of $460 million and $2.6 billion, respectively, as of the vesting date. RSUs that vested during the three- and six-month periods ended March 26, 2016 had fair values of $450 million and $2.5 billion, respectively, as of the vesting date.

[0001628280-17-004790:notes:63]
[same as prior period, unchanged from 0001628280-17-000717:notes:63]

[0001628280-17-004790:notes:64]
The following table shows a summary of the share-based compensation expense included in the Condensed Consolidated Statements of Operations for the three- and six-month periods ended April 1, 2017 and March 26, 2016 (in millions):

[0001628280-17-004790:notes:65]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1, 2017 |  | March 26, 2016 |  | April 1, 2017 |  | March 26, 2016 |
| Cost of sales | $ | 217 |  |  | $ | 191 |  |  | $ | 446 |  |  | $ | 395 |  |
| Research and development | 575 |  |  | 468 |  |  | 1,164 |  |  | 934 |  |
| Selling, general and administrative | 425 |  |  | 389 |  |  | 863 |  |  | 797 |  |
| Total share-based compensation expense | $ | 1,217 |  |  | $ | 1,048 |  |  | $ | 2,473 |  |  | $ | 2,126 |  |

[0001628280-17-004790:notes:66]
The income tax benefit related to share-based compensation expense was $424 million and $889 million for the three- and six-month periods ended April 1, 2017, respectively, and was $347 million and $760 million for the three- and six-month periods ended March 26, 2016, respectively. As of April 1, 2017, the total unrecognized compensation cost related to outstanding RSUs, restricted stock and stock options was $10.0 billion, which the Company expects to recognize over a weighted-average period of 2.8 years.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-17-004790:notes:67]
[same as prior period, unchanged from 0001628280-17-000717:notes:67]

[0001628280-17-004790:notes:68]
[same as prior period, unchanged from 0001628280-17-000717:notes:68]

[0001628280-17-004790:notes:69]
The following table shows the pre-tax amounts reclassified from AOCI into the Condensed Consolidated Statements of Operations, and the associated financial statement line item, for the three- and six-month periods ended April 1, 2017 and March 26, 2016 (in millions):

[0001628280-17-004790:notes:70]
|  |  |  |  | Three Months Ended |  | Six Months Ended |
| Comprehensive Income Components |  | Financial Statement Line Item |  | April 1, 2017 |  | March 26, 2016 |  | April 1, 2017 |  | March 26, 2016 |
| Unrealized (gains)/losses on derivative instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Revenue |  | $ | (408 | ) |  | $ | (325 | ) |  | $ | (509 | ) |  | $ | (654 | ) |
|  |  | Cost of sales |  | (570 | ) |  | (219 | ) |  | (557 | ) |  | (525 | ) |
|  |  | Other income/(expense), net |  | (367 | ) |  | (131 | ) |  | 237 |  |  | (11 | ) |
| Interest rate contracts |  | Other income/(expense), net |  | 2 |  |  | 3 |  |  | 3 |  |  | 7 |  |
|  |  |  |  | (1,343 | ) |  | (672 | ) |  | (826 | ) |  | (1,183 | ) |
| Unrealized (gains)/losses on marketable securities |  | Other income/(expense), net |  | (20 | ) |  | 76 |  |  | 11 |  |  | 149 |  |
| Total amounts reclassified from AOCI |  | $ | (1,363 | ) |  | $ | (596 | ) |  | $ | (815 | ) |  | $ | (1,034 | ) |

[0001628280-17-004790:notes:71]
The following table shows the changes in AOCI by component for the six months ended April 1, 2017 (in millions):

[0001628280-17-004790:notes:72]
|  | Cumulative ForeignCurrency Translation |  | Unrealized Gains/Losseson Derivative Instruments |  | Unrealized Gains/Losseson Marketable Securities |  | Total |
| Balance at September 24, 2016 | $ | (578 | ) |  | $ | 38 |  |  | $ | 1,174 |  |  | $ | 634 |  |
| Other comprehensive income/(loss) before reclassifications | (193 | ) |  | 1,421 |  |  | (2,077 | ) |  | (849 | ) |
| Amounts reclassified from AOCI | — |  |  | (826 | ) |  | 11 |  |  | (815 | ) |
| Tax effect | 32 |  |  | (153 | ) |  | 729 |  |  | 608 |  |
| Other comprehensive income/(loss) | (161 | ) |  | 442 |  |  | (1,337 | ) |  | (1,056 | ) |
| Balance at April 1, 2017 | $ | (739 | ) |  | $ | 480 |  |  | $ | (163 | ) |  | $ | (422 | ) |


## us-gaap:DebtDisclosureTextBlock

[0001628280-17-004790:notes:73]
Debt

[0001628280-17-004790:notes:74]
Commercial Paper

[0001628280-17-004790:notes:75]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of April 1, 2017 and September 24, 2016, the Company had $10.0 billion and $8.1 billion of Commercial Paper outstanding, respectively, with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 0.80% as of April 1, 2017 and 0.45% as of September 24, 2016.

[0001628280-17-004790:notes:76]
Long-Term Debt

[0001628280-17-004790:notes:77]
As of April 1, 2017, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $88.9 billion (collectively the “Notes”). The Notes are senior unsecured obligations, and interest is payable in arrears, quarterly for the U.S. dollar-denominated and Australian dollar-denominated floating-rate notes, semi-annually for the U.S. dollar-denominated, Australian dollar-denominated, British pound-denominated and Japanese yen-denominated fixed-rate notes and annually for the euro-denominated and Swiss franc-denominated fixed-rate notes. The following table provides a summary of the Company’s term debt as of April 1, 2017 and September 24, 2016:

[0001628280-17-004790:notes:78]
|  | Maturities |  | April 1, 2017 |  | September 24, 2016 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2018 |  | 2018 |  | $ | 2,000 |  |  |  | 1.10% |  | 1.10 | % |  | $ | 2,000 |  |  |  | 1.10% |  | 1.10 | % |
| Fixed-rate 1.000% – 3.850% notes | 2018 | – | 2043 |  | 12,500 |  |  |  | 1.08% | – | 3.91 | % |  | 12,500 |  |  |  | 1.08% | – | 3.91 | % |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2017 | – | 2019 |  | 2,000 |  |  |  | 1.10% | – | 1.33 | % |  | 2,000 |  |  |  | 0.86% | – | 1.09 | % |
| Fixed-rate 1.050% – 4.450% notes | 2017 | – | 2044 |  | 10,000 |  |  |  | 1.10% | – | 4.48 | % |  | 10,000 |  |  |  | 0.85% | – | 4.48 | % |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2017 | – | 2020 |  | 1,785 |  |  |  | 1.08% | – | 1.87 | % |  | 1,781 |  |  |  | 0.87% | – | 1.87 | % |
| Fixed-rate 0.350% – 4.375% notes | 2017 | – | 2045 |  | 24,668 |  |  |  | 0.28% | – | 4.51 | % |  | 25,144 |  |  |  | 0.28% | – | 4.51 | % |
| 2016 debt issuances of $24.9 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2021 |  | 1,350 |  |  |  | 1.17% | – | 2.18 | % |  | 1,350 |  |  |  | 0.91% | – | 1.95 | % |
| Fixed-rate 1.100% – 4.650% notes | 2018 | – | 2046 |  | 23,616 |  |  |  | 1.13% | – | 4.78 | % |  | 23,609 |  |  |  | 1.13% | – | 4.58 | % |
| Second quarter 2017 debt issuance of $10.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2019 |  | 500 |  |  |  |  |  | 1.12 | % |  | — |  |  |  |  |  | — | % |
| Floating-rate notes |  |  | 2020 |  | 500 |  |  |  |  |  | 1.24 | % |  | — |  |  |  |  |  | — | % |
| Floating-rate notes |  |  | 2022 |  | 1,000 |  |  |  |  |  | 1.54 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 1.550% notes |  |  | 2019 |  | 500 |  |  |  |  |  | 1.59 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 1.900% notes |  |  | 2020 |  | 1,000 |  |  |  |  |  | 1.24 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.500% notes |  |  | 2022 |  | 1,500 |  |  |  |  |  | 1.53 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.000% notes |  |  | 2024 |  | 1,750 |  |  |  |  |  | 1.83 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.350% notes |  |  | 2027 |  | 2,250 |  |  |  |  |  | 1.98 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 4.250% notes |  |  | 2047 |  | 1,000 |  |  |  |  |  | 4.26 | % |  | — |  |  |  |  |  | — | % |
| Second quarter 2017 debt issuance of $1.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 4.300% notes |  |  | 2047 |  | 1,000 |  |  |  |  |  | 4.30 | % |  | — |  |  |  |  |  | — | % |
| Total term debt |  |  |  |  | 88,919 |  |  |  |  |  |  |  | 78,384 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (184 | ) |  |  |  |  |  |  | (174 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | (205 | ) |  |  |  |  |  |  | 717 |  |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  |  |  | (3,999 | ) |  |  |  |  |  |  | (3,500 | ) |  |  |  |  |  |
| Total long-term debt |  |  |  |  | $ | 84,531 |  |  |  |  |  |  |  | $ | 75,427 |  |  |  |  |  |  |

[0001628280-17-004790:notes:79]
During the second quarter of 2017, the Company issued $10.0 billion of U.S. dollar-denominated notes in the United States and $1.0 billion of U.S. dollar-denominated notes in Taiwan. To manage interest rate risk on the fixed-rate notes maturing in 2020, 2022, 2024 and 2027, the Company entered into interest rate swaps with an aggregate notional amount of $6.5 billion, which effectively converted the fixed interest rates on these notes to floating interest rates.

[0001628280-17-004790:notes:80]
A portion of the Company's Japanese yen-denominated notes is designated as a hedge of the foreign currency exposure of the Company's net investment in a foreign operation. The foreign currency transaction gain or loss on the Japanese yen-denominated debt designated as a hedge is recorded in OCI as a part of the cumulative translation adjustment. As of April 1, 2017 and September 24, 2016, the carrying value of the debt designated as a net investment hedge was $1.7 billion and $1.9 billion, respectively. For further discussion regarding the Company’s use of derivative instruments see the Derivative Financial Instruments section of Note 2, “Financial Instruments.”

[0001628280-17-004790:notes:81]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount and, if applicable, adjustments related to hedging. The Company recognized $507 million and $1.0 billion of interest expense on its term debt for the three- and six-month periods ended April 1, 2017, respectively. The Company recognized $311 million and $582 million of interest expense on its term debt for the three- and six-month periods ended March 26, 2016, respectively.

[0001628280-17-004790:notes:82]
As of April 1, 2017 and September 24, 2016, the fair value of the Company’s Notes, based on Level 2 inputs, was $89.7 billion and $81.7 billion, respectively.


## us-gaap:DerivativesPolicyTextBlock

[0001628280-17-004790:notes:83]
[same as prior period, unchanged from 0001628280-17-000717:notes:83]

[0001628280-17-004790:notes:84]
[same as prior period, unchanged from 0001628280-17-000717:notes:84]

[0001628280-17-004790:notes:85]
[same as prior period, unchanged from 0001628280-17-000717:notes:85]

[0001628280-17-004790:notes:86]
[same as prior period, unchanged from 0001628280-17-000717:notes:86]

[0001628280-17-004790:notes:87]
The Company may also enter into non-designated foreign currency contracts to partially offset the foreign currency exchange gains and losses generated by the remeasurement of certain assets and liabilities denominated in non-functional currencies.

[0001628280-17-004790:notes:88]
The Company may enter into interest rate swaps, options, or other instruments to manage interest rate risk. These instruments may offset a portion of changes in income or expense, or changes in fair value of the Company’s term debt or investments. The Company designates these instruments as either cash flow or fair value hedges. The Company’s hedged interest rate transactions as of April 1, 2017 are expected to be recognized within 10 years.

[0001628280-17-004790:notes:89]
[same as prior period, unchanged from 0001628280-17-000717:notes:89]

[0001628280-17-004790:notes:90]
[same as prior period, unchanged from 0001628280-17-000717:notes:90]

[0001628280-17-004790:notes:91]
[same as prior period, unchanged from 0001628280-17-000717:notes:91]

[0001628280-17-004790:notes:92]
[same as prior period, unchanged from 0001628280-17-000717:notes:92]

[0001628280-17-004790:notes:93]
[same as prior period, unchanged from 0001628280-17-000717:notes:93]

[0001628280-17-004790:notes:94]
[same as prior period, unchanged from 0001628280-17-000717:notes:94]

[0001628280-17-004790:notes:95]
[same as prior period, unchanged from 0001628280-17-000717:notes:95]

[0001628280-17-004790:notes:96]
[same as prior period, unchanged from 0001628280-17-000717:notes:96]

[0001628280-17-004790:notes:97]
[same as prior period, unchanged from 0001628280-17-000717:notes:97]

[0001628280-17-004790:notes:98]
[same as prior period, unchanged from 0001628280-17-000717:notes:82]


## us-gaap:DividendsDeclaredTableTextBlock

[0001628280-17-004790:notes:99]
[same as prior period, unchanged from 0001628280-17-000717:notes:98]

[0001628280-17-004790:notes:100]
|  | DividendsPer Share |  | Amount(in millions) |
| 2017: |  |  |  |
| Second quarter | $ | 0.57 |  |  | $ | 2,988 |  |
| First quarter | 0.57 |  |  | 3,042 |  |
| Total cash dividends declared and paid | $ | 1.14 |  |  | $ | 6,030 |  |
| 2016: |  |  |  |
| Fourth quarter | $ | 0.57 |  |  | $ | 3,071 |  |
| Third quarter | 0.57 |  |  | 3,117 |  |
| Second quarter | 0.52 |  |  | 2,879 |  |
| First quarter | 0.52 |  |  | 2,898 |  |
| Total cash dividends declared and paid | $ | 2.18 |  |  | $ | 11,965 |  |


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001628280-17-004790:notes:101]
[same as prior period, unchanged from 0001628280-17-000717:notes:100]

[0001628280-17-004790:notes:102]
[same as prior period, unchanged from 0001628280-17-000717:notes:101]


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001628280-17-004790:notes:103]
[same as prior period, unchanged from 0001628280-17-000717:notes:102]

[0001628280-17-004790:notes:104]
[same as prior period, unchanged from 0001628280-17-000717:notes:103]

[0001628280-17-004790:notes:105]
[same as prior period, unchanged from 0001628280-17-000717:notes:104]

[0001628280-17-004790:notes:106]
The Company considers the declines in market value of its marketable securities investment portfolio to be temporary in nature. The Company typically invests in highly-rated securities, and its investment policy generally limits the amount of credit exposure to any one issuer. The policy generally requires investments to be investment grade, with the primary objective of minimizing the potential risk of principal loss. Fair values were determined for each individual security in the investment portfolio. When evaluating an investment for other-than-temporary impairment, the Company reviews factors such as the length of time and extent to which fair value has been below its cost basis, the financial condition of the issuer and any changes thereto, changes in market interest rates and the Company’s intent to sell, or whether it is more likely than not it will be required to sell the investment before recovery of the investment’s cost basis. As of April 1, 2017, the Company does not consider any of its investments to be other-than-temporarily impaired.

[0001628280-17-004790:notes:107]
Derivatives that are not designated as hedging instruments are adjusted to fair value through earnings in the financial statement line item to which the derivative relates. As a result, during the three- and six-month periods ended April 1, 2017, respectively, the Company recognized a loss of $67 million and a gain of $206 million in net sales, a loss of $253 million and a gain of $79 million in cost of sales and a loss of $76 million and a gain of $432 million in other income/(expense), net.

[0001628280-17-004790:notes:108]
The Company records all derivatives in the Condensed Consolidated Balance Sheets at fair value. The Company’s accounting treatment for these derivative instruments is based on its hedge designation. The following tables show the Company’s derivative instruments at gross fair value as of April 1, 2017 and September 24, 2016 (in millions):

[0001628280-17-004790:notes:109]
|  | April 1, 2017 |
|  | Fair Value ofDerivatives Designatedas Hedge Instruments |  | Fair Value ofDerivatives Not Designatedas Hedge Instruments |  | TotalFair Value |
| Derivative assets (1): |  |  |  |  |  |
| Foreign exchange contracts | $ | 691 |  |  | $ | 272 |  |  | $ | 963 |  |
| Interest rate contracts | $ | 161 |  |  | $ | — |  |  | $ | 161 |  |
| Derivative liabilities (2): |  |  |  |  |  |
| Foreign exchange contracts | $ | 832 |  |  | $ | 245 |  |  | $ | 1,077 |  |
| Interest rate contracts | $ | 354 |  |  | $ | — |  |  | $ | 354 |  |

[0001628280-17-004790:notes:110]
[same as prior period, unchanged from 0001628280-17-000717:notes:109]

[0001628280-17-004790:notes:111]
[same as prior period, unchanged from 0001628280-17-000717:notes:110]

[0001628280-17-004790:notes:112]
[same as prior period, unchanged from 0001628280-17-000717:notes:111]

[0001628280-17-004790:notes:113]
The following table shows the pre-tax gains and losses of the Company’s derivative and non-derivative instruments designated as cash flow, net investment and fair value hedges in OCI and the Condensed Consolidated Statements of Operations for the three- and six-month periods ended April 1, 2017 and March 26, 2016 (in millions):

[0001628280-17-004790:notes:114]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1, 2017 |  | March 26, 2016 |  | April 1, 2017 |  | March 26, 2016 |
| Gains/(Losses) recognized in OCI – effective portion: |  |  |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | (317 | ) |  | $ | (138 | ) |  | $ | 1,410 |  |  | $ | 188 |  |
| Interest rate contracts | 2 |  |  | (50 | ) |  | 9 |  |  | (42 | ) |
| Total | $ | (315 | ) |  | $ | (188 | ) |  | $ | 1,419 |  |  | $ | 146 |  |
| Net investment hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Foreign currency debt | (85 | ) |  | (87 | ) |  | 37 |  |  | (77 | ) |
| Total | $ | (85 | ) |  | $ | (87 | ) |  | $ | 37 |  |  | $ | (77 | ) |
| Gains/(Losses) reclassified from AOCI into net income – effective portion: |  |  |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 1,344 |  |  | $ | 668 |  |  | $ | 833 |  |  | $ | 1,183 |  |
| Interest rate contracts | (2 | ) |  | (3 | ) |  | (3 | ) |  | (7 | ) |
| Total | $ | 1,342 |  |  | $ | 665 |  |  | $ | 830 |  |  | $ | 1,176 |  |
| Gains/(Losses) on derivative instruments: |  |  |  |  |  |  |  |
| Fair value hedges: |  |  |  |  |  |  |  |
| Interest rate contracts | $ | (50 | ) |  | $ | 250 |  |  | $ | (922 | ) |  | $ | 139 |  |
| Gains/(Losses) related to hedged items: |  |  |  |  |  |  |  |
| Fair value hedges: |  |  |  |  |  |  |  |
| Interest rate contracts | $ | 50 |  |  | $ | (250 | ) |  | $ | 922 |  |  | $ | (139 | ) |

[0001628280-17-004790:notes:115]
[same as prior period, unchanged from 0001628280-17-000717:notes:114]

[0001628280-17-004790:notes:116]
The Company generally enters into master netting arrangements, which are designed to reduce credit risk by permitting net settlement of transactions with the same counterparty. To further limit credit risk, the Company generally enters into collateral security arrangements that provide for collateral to be received or posted when the net fair value of certain financial instruments fluctuates from contractually established thresholds. The Company presents its derivative assets and derivative liabilities at their gross fair values in its Condensed Consolidated Balance Sheets. As of April 1, 2017, the net cash collateral posted by the Company related to derivative instruments under its collateral security arrangements was $230 million, which was recorded as other current assets in the Condensed Consolidated Balance Sheet. As of September 24, 2016, the net cash collateral received by the Company related to derivative instruments under its collateral security arrangements was $163 million, which was recorded as accrued expenses in the Condensed Consolidated Balance Sheet.

[0001628280-17-004790:notes:117]
Under master netting arrangements with the respective counterparties to the Company’s derivative contracts, the Company is allowed to net settle transactions with a single net amount payable by one party to the other. As of both April 1, 2017 and September 24, 2016, the potential effects of these rights of set-off associated with the Company’s derivative contracts, including the effects of collateral, would be a reduction to both derivative assets and derivative liabilities of $1.5 billion, resulting in a net derivative liability of $77 million as of April 1, 2017 and a net derivative asset of $160 million as of September 24, 2016.

[0001628280-17-004790:notes:118]
[same as prior period, unchanged from 0001628280-17-000717:notes:117]

[0001628280-17-004790:notes:119]
[same as prior period, unchanged from 0001628280-17-000717:notes:118]

[0001628280-17-004790:notes:120]
[same as prior period, unchanged from 0001628280-17-000717:notes:119]

[0001628280-17-004790:notes:121]
As of April 1, 2017, the Company had two customers that individually represented 10% or more of total trade receivables, one of which accounted for 12% and the other 10%. As of September 24, 2016, the Company had one customer that represented 10% or more of total trade receivables, which accounted for 10%. The Company’s cellular network carriers accounted for 52% and 63% of trade receivables as of April 1, 2017 and September 24, 2016, respectively.

[0001628280-17-004790:notes:122]
[same as prior period, unchanged from 0001628280-17-000717:notes:121]

[0001628280-17-004790:notes:123]
The Company has non-trade receivables from certain of its manufacturing vendors resulting from the sale of components to these vendors who manufacture sub-assemblies or assemble final products for the Company. The Company purchases these components directly from suppliers. As of April 1, 2017, the Company had three vendors that individually accounted for 42%, 17% and 14% of total vendor non-trade receivables. As of September 24, 2016, the Company had two vendors that individually accounted for 47% and 21% of total vendor non-trade receivables.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-17-004790:notes:124]
[same as prior period, unchanged from 0001628280-17-000717:notes:123]

[0001628280-17-004790:notes:125]
As of April 1, 2017, the Company recorded gross unrecognized tax benefits of $8.8 billion, of which $3.0 billion, if recognized, would affect the Company’s effective tax rate. As of September 24, 2016, the total amount of gross unrecognized tax benefits was $7.7 billion, of which $2.8 billion, if recognized, would have affected the Company’s effective tax rate. The Company’s total gross unrecognized tax benefits are classified as other non-current liabilities in the Condensed Consolidated Balance Sheets. The Company had $1.3 billion and $1.0 billion of gross interest and penalties accrued as of April 1, 2017 and September 24, 2016, respectively, which are classified as other non-current liabilities in the Condensed Consolidated Balance Sheets.

[0001628280-17-004790:notes:126]
The Company believes that an adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax audits cannot be predicted with certainty. If any issues addressed in the Company’s tax audits are resolved in a manner not consistent with its expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. Although timing of the resolution and/or closure of audits is not certain, the Company believes it is reasonably possible that its gross unrecognized tax benefits could decrease (whether by payment, release or a combination of both) in the next 12 months by as much as $1.3 billion.

[0001628280-17-004790:notes:127]
[same as prior period, unchanged from 0001628280-17-000717:notes:126]


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001628280-17-004790:notes:128]
[same as prior period, unchanged from 0001628280-17-000717:notes:127]

[0001628280-17-004790:notes:129]
The Company’s acquired intangible assets with definite useful lives primarily consist of patents and licenses. The following table summarizes the components of acquired intangible asset balances as of April 1, 2017 and September 24, 2016 (in millions):

[0001628280-17-004790:notes:130]
|  | April 1, 2017 |  | September 24, 2016 |
|  | GrossCarrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |  | GrossCarrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |
| Definite-lived and amortizable acquired intangible assets | $ | 7,258 |  |  | $ | (4,741 | ) |  | $ | 2,517 |  |  | $ | 8,912 |  |  | $ | (5,806 | ) |  | $ | 3,106 |  |
| Indefinite-lived and non-amortizable acquired intangible assets | 100 |  |  | — |  |  | 100 |  |  | 100 |  |  | — |  |  | 100 |  |
| Total acquired intangible assets | $ | 7,358 |  |  | $ | (4,741 | ) |  | $ | 2,617 |  |  | $ | 9,012 |  |  | $ | (5,806 | ) |  | $ | 3,206 |  |


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001628280-17-004790:notes:131]
A reconciliation of the Company’s segment operating income to the Condensed Consolidated Statements of Operations for the three- and six-month periods ended April 1, 2017 and March 26, 2016 is as follows (in millions):

[0001628280-17-004790:notes:132]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1, 2017 |  | March 26, 2016 |  | April 1, 2017 |  | March 26, 2016 |
| Segment operating income | $ | 18,089 |  |  | $ | 17,561 |  |  | $ | 45,397 |  |  | $ | 45,206 |  |
| Research and development expense | (2,776 | ) |  | (2,511 | ) |  | (5,647 | ) |  | (4,915 | ) |
| Other corporate expenses, net | (1,216 | ) |  | (1,063 | ) |  | (2,294 | ) |  | (2,133 | ) |
| Total operating income | $ | 14,097 |  |  | $ | 13,987 |  |  | $ | 37,456 |  |  | $ | 38,158 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001628280-17-004790:notes:133]
The following table shows information by reportable operating segment for the three- and six-month periods ended April 1, 2017 and March 26, 2016 (in millions):

[0001628280-17-004790:notes:134]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1, 2017 |  | March 26, 2016 |  | April 1, 2017 |  | March 26, 2016 |
| Americas: |  |  |  |  |  |  |  |
| Net sales | $ | 21,157 |  |  | $ | 19,096 |  |  | $ | 53,125 |  |  | $ | 48,421 |  |
| Operating income | $ | 6,668 |  |  | $ | 6,116 |  |  | $ | 17,162 |  |  | $ | 16,134 |  |
| Europe: |  |  |  |  |  |  |  |
| Net sales | $ | 12,733 |  |  | $ | 11,535 |  |  | $ | 31,254 |  |  | $ | 29,467 |  |
| Operating income | $ | 3,851 |  |  | $ | 3,602 |  |  | $ | 9,587 |  |  | $ | 9,381 |  |
| Greater China: |  |  |  |  |  |  |  |
| Net sales | $ | 10,726 |  |  | $ | 12,486 |  |  | $ | 26,959 |  |  | $ | 30,859 |  |
| Operating income | $ | 4,224 |  |  | $ | 4,818 |  |  | $ | 10,400 |  |  | $ | 12,394 |  |
| Japan: |  |  |  |  |  |  |  |
| Net sales | $ | 4,485 |  |  | $ | 4,281 |  |  | $ | 10,251 |  |  | $ | 9,075 |  |
| Operating income | $ | 2,037 |  |  | $ | 1,930 |  |  | $ | 4,710 |  |  | $ | 4,170 |  |
| Rest of Asia Pacific: |  |  |  |  |  |  |  |
| Net sales | $ | 3,795 |  |  | $ | 3,159 |  |  | $ | 9,658 |  |  | $ | 8,607 |  |
| Operating income | $ | 1,309 |  |  | $ | 1,095 |  |  | $ | 3,538 |  |  | $ | 3,127 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-17-004790:notes:135]
[same as prior period, unchanged from 0001628280-17-000717:notes:134]

[0001628280-17-004790:notes:136]
[same as prior period, unchanged from 0001628280-17-000717:notes:135]

[0001628280-17-004790:notes:137]
[same as prior period, unchanged from 0001628280-17-000717:notes:136]

[0001628280-17-004790:notes:138]
[same as prior period, unchanged from 0001628280-17-000717:notes:137]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-17-004790:notes:139]
[same as prior period, unchanged from 0001628280-17-000717:notes:138]

[0001628280-17-004790:notes:140]
[same as prior period, unchanged from 0001628280-17-000717:notes:139]

[0001628280-17-004790:notes:141]
[same as prior period, unchanged from 0001628280-17-000717:notes:140]

[0001628280-17-004790:notes:142]
[same as prior period, unchanged from 0001628280-17-000717:notes:141]

[0001628280-17-004790:notes:143]
As of April 1, 2017, the Company had an authorized share repurchase program of $175 billion of the Company’s common stock, of which $151 billion had been utilized. The Company’s share repurchase program does not obligate it to acquire any specific number of shares. Under the program, shares may be repurchased in privately negotiated and/or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).

[0001628280-17-004790:notes:144]
[same as prior period, unchanged from 0001628280-17-000717:notes:143]
