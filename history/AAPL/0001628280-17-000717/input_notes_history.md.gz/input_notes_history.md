# AAPL note change history — 0001628280-16-017809 → 0001628280-17-000717


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-02-01):
[0001628280-17-000717:note_history:1]
The following table shows changes in the Company’s accrued warranties and related costs for the three months ended December 31, 2016 and December 26, 2015 (in millions):
  (was, 2016-07-27, similarity 0.8869):
[0001628280-16-017809:note_history:1]
The following table shows changes in the Company’s accrued warranties and related costs for the three- and nine-month periods ended June 25, 2016 and June 27, 2015 (in millions):

- changed (2017-02-01):
[0001628280-17-000717:note_history:2]
|  | Three Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |
| Beginning accrued warranty and related costs | $ | 3,702 |  |  | $ | 4,780 |  |
| Cost of warranty claims | (1,337 | ) |  | (1,269 | ) |
| Accruals for product warranty | 2,333 |  |  | 1,725 |  |
| Ending accrued warranty and related costs | $ | 4,698 |  |  | $ | 5,236 |  |
  (was, 2016-07-27, similarity 0.7514):
[0001628280-16-017809:note_history:2]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25, 2016 |  | June 27, 2015 |  | June 25, 2016 |  | June 27, 2015 |
| Beginning accrued warranty and related costs | $ | 4,985 |  |  | $ | 5,143 |  |  | $ | 4,780 |  |  | $ | 4,159 |  |
| Cost of warranty claims | (1,110 | ) |  | (1,077 | ) |  | (3,507 | ) |  | (3,151 | ) |
| Accruals for product warranty | 380 |  |  | 1,071 |  |  | 2,982 |  |  | 4,129 |  |
| Ending accrued warranty and related costs | $ | 4,255 |  |  | $ | 5,137 |  |  | $ | 4,255 |  |  | $ | 5,137 |  |

- added (2017-02-01):
[0001628280-17-000717:note_history:3]
The Company offers an iPhone Upgrade Program, which is available to customers who purchase a qualifying iPhone in the U.S., the U.K. and mainland China. The iPhone Upgrade Program provides customers the right to trade in that iPhone for a specified amount when purchasing a new iPhone, provided certain conditions are met. The Company accounts for the trade-in right as a guarantee liability and recognizes arrangement revenue net of the fair value of such right with subsequent changes to the guarantee liability recognized within revenue.

- changed (2017-02-01):
[0001628280-17-000717:note_history:4]
Substantially all of the Company’s hardware products are manufactured by outsourcing partners that are located primarily in Asia. A significant concentration of this manufacturing is currently performed by a small number of outsourcing partners, often in single locations. Certain of these outsourcing partners are the sole-sourced suppliers of components and manufacturers for many of the Company’s products. Although the Company works closely with its outsourcing partners on manufacturing schedules, the Company’s operating results could be adversely affected if its outsourcing partners were unable to meet their production commitments. The Company’s manufacturing purchase obligations typically cover its requirements for periods up to 150 days.
  (was, 2016-07-27, similarity 0.9649):
[0001628280-16-017809:note_history:4]
Substantially all of the Company’s hardware products are manufactured by outsourcing partners that are located primarily in Asia. A significant concentration of this manufacturing is currently performed by a small number of outsourcing partners, often in single locations. Certain of these outsourcing partners are the sole-sourced suppliers of components and manufacturers for many of the Company’s products. Although the Company works closely with its outsourcing partners on manufacturing schedules, the Company’s operating results could be adversely affected if its outsourcing partners were unable to meet their production commitments. The Company’s purchase commitments typically cover its requirements for periods up to 150 days.

- changed (2017-02-01):
[0001628280-17-000717:note_history:5]
The Company leases various equipment and facilities, including retail space, under noncancelable operating lease arrangements. The Company does not currently utilize any other off-balance sheet financing arrangements. As of December 31, 2016, the Company’s total future minimum lease payments under noncancelable operating leases were $7.5 billion. The Company's retail store and other facility leases are typically for terms not exceeding 10 years and generally contain multi-year renewal options.
  (was, 2016-07-27, similarity 0.8698):
[0001628280-16-017809:note_history:5]
The Company leases various equipment and facilities, including retail space, under noncancelable operating lease arrangements. As of June 25, 2016, the Company’s total future minimum lease payments under noncancelable operating leases were $7.1 billion. The Company's retail store and other facility leases are typically for terms not exceeding 10 years and generally contain multi-year renewal options.

- changed (2017-02-01):
[0001628280-17-000717:note_history:6]
On August 24, 2012, a jury returned a verdict awarding the Company $1.05 billion in its lawsuit against Samsung Electronics Co., Ltd. and affiliated parties in the United States District Court, Northern District of California, San Jose Division. On March 6, 2014, the District Court entered final judgment in favor of the Company in the amount of approximately $930 million. On May 18, 2015, the U.S. Court of Appeals for the Federal Circuit affirmed in part, and reversed in part, the decision of the District Court. As a result, the Court of Appeals ordered entry of final judgment on damages in the amount of approximately $548 million, with the District Court to determine supplemental damages and interest, as well as damages owed for products subject to the reversal in part. Samsung paid $548 million to the Company in December 2015, which was included in net sales in the Condensed Consolidated Statement of Operations. On December 6, 2016, the U.S. Supreme Court remanded the case to the U.S. Court of Appeals for the Federal Circuit for further proceedings related to the $548 million in damages. Because the case remains subject to further proceedings, the Company has not recognized any further amounts in its results of operations.
  (was, 2016-07-27, similarity 0.8738):
[0001628280-16-017809:note_history:6]
On August 24, 2012, a jury returned a verdict awarding the Company $1.05 billion in its lawsuit against Samsung Electronics Co., Ltd. and affiliated parties in the United States District Court, Northern District of California, San Jose Division. On March 6, 2014, the District Court entered final judgment in favor of the Company in the amount of approximately $930 million. On May 18, 2015, the U.S. Court of Appeals for the Federal Circuit affirmed in part, and reversed in part, the decision of the District Court. As a result, the Court of Appeals ordered entry of final judgment on damages in the amount of approximately $548 million, with the District Court to determine supplemental damages and interest, as well as damages owed for products subject to the reversal in part. Samsung paid $548 million to the Company in December 2015, which was included in net sales in the Condensed Consolidated Statement of Operations. Because the case remains subject to further proceedings, the Company has not recognized any further amounts in its results of operations. On March 21, 2016, the United States Supreme Court agreed to hear Samsung’s request for appeal related to the $548 million in damages.

- removed (2017-02-01):
[0001628280-16-017809:note_history:7]
The Company offers an iPhone Upgrade Program, which is available to customers who purchase an iPhone 6s and 6s Plus in its U.S. retail and online stores and activate the purchased iPhone with one of the four U.S. national carriers. The iPhone Upgrade Program provides customers the right to trade in that iPhone for a new iPhone, provided certain conditions are met. One of the conditions of this program requires the customer to finance the initial purchase price of the iPhone with a third-party lender. Upon exercise of the trade-in right and purchase of a new iPhone, the Company satisfies the customer’s outstanding balance due to the third-party lender on the original device. The Company accounts for the trade-in right as a guarantee liability and recognizes arrangement revenue net of the fair value of such right with subsequent changes to the guarantee liability recognized within revenue.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2017-02-01):
[0001628280-17-000717:note_history:8]
Apple Inc. and its wholly-owned subsidiaries (collectively “Apple” or the “Company”) designs, manufactures and markets mobile communication and media devices, personal computers and portable digital music players, and sells a variety of related software, services, accessories, networking solutions and third-party digital content and applications. The Company’s products and services include iPhone®, iPad®, Mac®, iPod®, Apple Watch®, Apple TV®, a portfolio of consumer and professional software applications, iOS, macOS™, watchOS® and tvOS™ operating systems, iCloud®, Apple Pay® and a variety of accessory, service and support offerings. The Company sells and delivers digital content and applications through the iTunes Store®, App Store®, Mac App Store, TV App Store, iBooks Store™ and Apple Music® (collectively “Digital Content and Services”). The Company sells its products worldwide through its retail stores, online stores and direct sales force, as well as through third-party cellular network carriers, wholesalers, retailers and value-added resellers. In addition, the Company sells a variety of third-party Apple-compatible products, including application software and various accessories through its retail and online stores. The Company sells to consumers, small and mid-sized businesses and education, enterprise and government customers.

- changed (2017-02-01):
[0001628280-17-000717:note_history:9]
The accompanying condensed consolidated financial statements include the accounts of the Company. Intercompany accounts and transactions have been eliminated. In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements in conformity with U.S. generally accepted accounting principles (“GAAP”) requires management to make estimates and assumptions that affect the amounts reported in these condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. Certain prior period amounts in the condensed consolidated financial statements have been reclassified to conform to the current period’s presentation. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company's annual consolidated financial statements and the notes thereto included in its Annual Report on Form 10-K for the fiscal year ended September 24, 2016 (the “2016 Form 10-K”).
  (was, 2016-07-27, similarity 0.8612):
[0001628280-16-017809:note_history:9]
The accompanying condensed consolidated financial statements include the accounts of the Company. Intercompany accounts and transactions have been eliminated. In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements in conformity with U.S. generally accepted accounting principles (“GAAP”) requires management to make estimates and assumptions that affect the amounts reported in these condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. Certain prior period amounts in the condensed consolidated financial statements have been reclassified to conform to the current period’s presentation.

- added (2017-02-01):
[0001628280-17-000717:note_history:10]
The Company’s fiscal year is the 52 or 53-week period that ends on the last Saturday of September. The Company’s fiscal year 2017 will include 53 weeks and ends on September 30, 2017 and its fiscal year 2016 included 52 weeks and ended on September 24, 2016. A 14th week has been included in the first quarter of 2017, as is done every five or six years, to realign fiscal quarters with calendar quarters. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in September and the associated quarters, months and periods of those fiscal years.

- changed (2017-02-01):
[0001628280-17-000717:note_history:11]
Basic earnings per share is computed by dividing income available to common shareholders by the weighted-average number of shares of common stock outstanding during the period. Diluted earnings per share is computed by dividing income available to common shareholders by the weighted-average number of shares of common stock outstanding during the period increased to include the number of additional shares of common stock that would have been outstanding if the potentially dilutive securities had been issued. Potentially dilutive securities include outstanding stock options, shares to be purchased by employees under the Company’s employee stock purchase plan, unvested restricted stock and unvested restricted stock units (“RSUs”). The dilutive effect of potentially dilutive securities is reflected in diluted earnings per share by application of the treasury stock method. Under the treasury stock method, an increase in the fair market value of the Company’s common stock can result in a greater dilutive effect from potentially dilutive securities.
  (was, 2016-07-27, similarity 0.9938):
[0001628280-16-017809:note_history:11]
Basic earnings per share is computed by dividing income available to common shareholders by the weighted-average number of shares of common stock outstanding during the period. Diluted earnings per share is computed by dividing income available to common shareholders by the weighted-average number of shares of common stock outstanding during the period increased to include the number of additional shares of common stock that would have been outstanding if the potentially dilutive securities had been issued. Potentially dilutive securities include outstanding stock options, shares to be purchased under the Company’s employee stock purchase plan, unvested restricted stock and unvested restricted stock units (“RSUs”). The dilutive effect of potentially dilutive securities is reflected in diluted earnings per share by application of the treasury stock method. Under the treasury stock method, an increase in the fair market value of the Company’s common stock can result in a greater dilutive effect from potentially dilutive securities.

- changed (2017-02-01):
[0001628280-17-000717:note_history:12]
The following table shows the computation of basic and diluted earnings per share for the three months ended December 31, 2016 and December 26, 2015 (net income in millions and shares in thousands):
  (was, 2016-07-27, similarity 0.9039):
[0001628280-16-017809:note_history:12]
The following table shows the computation of basic and diluted earnings per share for the three- and nine-month periods ended June 25, 2016 and June 27, 2015 (net income in millions and shares in thousands):

- changed (2017-02-01):
[0001628280-17-000717:note_history:13]
|  | Three Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |
| Numerator: |  |  |  |
| Net income | $ | 17,891 |  |  | $ | 18,361 |  |
| Denominator: |  |  |  |
| Weighted-average shares outstanding | 5,298,661 |  |  | 5,558,930 |  |
| Effect of dilutive securities | 29,334 |  |  | 35,197 |  |
| Weighted-average diluted shares | 5,327,995 |  |  | 5,594,127 |  |
| Basic earnings per share | $ | 3.38 |  |  | $ | 3.30 |  |
| Diluted earnings per share | $ | 3.36 |  |  | $ | 3.28 |  |
  (was, 2016-07-27, similarity 0.633):
[0001628280-16-017809:note_history:13]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25, 2016 |  | June 27, 2015 |  | June 25, 2016 |  | June 27, 2015 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 7,796 |  |  | $ | 10,677 |  |  | $ | 36,673 |  |  | $ | 42,270 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average shares outstanding | 5,443,058 |  |  | 5,729,886 |  |  | 5,505,456 |  |  | 5,788,922 |  |
| Effect of dilutive securities | 29,723 |  |  | 43,213 |  |  | 30,475 |  |  | 40,998 |  |
| Weighted-average diluted shares | 5,472,781 |  |  | 5,773,099 |  |  | 5,535,931 |  |  | 5,829,920 |  |
| Basic earnings per share | $ | 1.43 |  |  | $ | 1.86 |  |  | $ | 6.66 |  |  | $ | 7.30 |  |
| Diluted earnings per share | $ | 1.42 |  |  | $ | 1.85 |  |  | $ | 6.62 |  |  | $ | 7.25 |  |

- removed (2017-02-01):
[0001628280-16-017809:note_history:14]
Apple Inc. and its wholly-owned subsidiaries (collectively “Apple” or the “Company”) designs, manufactures and markets mobile communication and media devices, personal computers and portable digital music players, and sells a variety of related software, services, accessories, networking solutions and third-party digital content and applications. The Company sells its products worldwide through its retail stores, online stores and direct sales force, as well as through third-party cellular network carriers, wholesalers, retailers and value-added resellers. In addition, the Company sells a variety of third-party Apple-compatible products, including application software and various accessories through its online and retail stores. The Company sells to consumers, small and mid-sized businesses and education, enterprise and government customers.

- removed (2017-02-01):
[0001628280-16-017809:note_history:15]
These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company's annual consolidated financial statements and the notes thereto included in its Annual Report on Form 10-K for the fiscal year ended September 26, 2015 (the “2015 Form 10-K”). The Company’s fiscal year is the 52 or 53-week period that ends on the last Saturday of September. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal quarters with calendar quarters, which will next occur in the first quarter of fiscal year 2017. The Company’s fiscal years 2016 and 2015 each include 52 weeks. Unless otherwise stated, references to particular years, quarters or months refer to the Company’s fiscal years ended in September and the associated quarters or months of those fiscal years.

- removed (2017-02-01):
[0001628280-16-017809:note_history:16]
During the first quarter of 2016, the Company adopted an accounting standard that simplified the presentation of deferred taxes by requiring deferred tax assets and liabilities be classified as noncurrent in a classified statement of financial position. The Company has adopted this accounting standard prospectively; accordingly, the prior period amounts in the Company’s Condensed Consolidated Balance Sheets within this Quarterly Report on Form 10-Q were not adjusted to conform to the new accounting standard. The adoption of this accounting standard was not material to the Company’s condensed consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2017-02-01):
[0001628280-17-000717:note_history:17]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of December 31, 2016 and September 24, 2016, the Company had $10.5 billion and $8.1 billion of Commercial Paper outstanding, respectively, with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 0.61% as of December 31, 2016 and 0.45% as of September 24, 2016.

- changed (2017-02-01):
[0001628280-17-000717:note_history:18]
The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the three months ended December 31, 2016 and December 26, 2015 (in millions):
  (was, 2016-07-27, similarity 0.9264):
[0001628280-16-017809:note_history:18]
The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the nine months ended June 25, 2016 and June 27, 2015 (in millions):

- added (2017-02-01):
[0001628280-17-000717:note_history:19]
|  | Three Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |
| Maturities less than 90 days: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | 1,550 |  |  | $ | (393 | ) |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 2,544 |  |  | 492 |  |
| Repayments of commercial paper | (1,709 | ) |  | (1,339 | ) |
| Proceeds from/(Repayments of) commercial paper, net | 835 |  |  | (847 | ) |
| Total change in commercial paper, net | $ | 2,385 |  |  | $ | (1,240 | ) |

- changed (2017-02-01):
[0001628280-17-000717:note_history:20]
As of December 31, 2016, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $77.4 billion (collectively the “Notes”). The Notes are senior unsecured obligations, and interest is payable in arrears, quarterly for the U.S. dollar-denominated and Australian dollar-denominated floating-rate notes, semi-annually for the U.S. dollar-denominated, Australian dollar-denominated, British pound-denominated and Japanese yen-denominated fixed-rate notes and annually for the euro-denominated and Swiss franc-denominated fixed-rate notes. The following table provides a summary of the Company’s term debt as of December 31, 2016 and September 24, 2016:
  (was, 2016-07-27, similarity 0.9826):
[0001628280-16-017809:note_history:20]
As of June 25, 2016, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $71.6 billion (collectively the “Notes”). The Notes are senior unsecured obligations, and interest is payable in arrears, quarterly for the U.S. dollar-denominated and Australian dollar-denominated floating-rate notes, semi-annually for the U.S. dollar-denominated, Australian dollar-denominated, British pound-denominated and Japanese yen-denominated fixed-rate notes and annually for the euro-denominated and Swiss franc-denominated fixed-rate notes. The following table provides a summary of the Company’s term debt as of June 25, 2016 and September 26, 2015:

- added (2017-02-01):
[0001628280-17-000717:note_history:21]
|  | Maturities |  | December 31, 2016 |  | September 24, 2016 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2018 |  | $ | 2,000 |  |  | 1.10% |  | $ | 2,000 |  |  | 1.10% |
| Fixed-rate 1.000% - 3.850% notes | 2018 - 2043 |  | 12,500 |  |  | 1.08% - 3.91% |  | 12,500 |  |  | 1.08% - 3.91% |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2017 - 2019 |  | 2,000 |  |  | 0.95% - 1.18% |  | 2,000 |  |  | 0.86% - 1.09% |
| Fixed-rate 1.050% - 4.450% notes | 2017 - 2044 |  | 10,000 |  |  | 0.95% - 4.48% |  | 10,000 |  |  | 0.85% - 4.48% |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2017 - 2020 |  | 1,753 |  |  | 0.95% - 1.87% |  | 1,781 |  |  | 0.87% - 1.87% |
| Fixed-rate 0.350% - 4.375% notes | 2017 - 2045 |  | 24,225 |  |  | 0.28% - 4.51% |  | 25,144 |  |  | 0.28% - 4.51% |
| 2016 debt issuances of $24.9 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 - 2021 |  | 1,350 |  |  | 1.02% - 2.05% |  | 1,350 |  |  | 0.91% - 1.95% |
| Fixed-rate 1.100% - 4.650% notes | 2018 - 2046 |  | 23,550 |  |  | 1.13% - 4.78% |  | 23,609 |  |  | 1.13% - 4.58% |
| Total term debt |  |  | 77,378 |  |  |  |  | 78,384 |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  | (166 | ) |  |  |  | (174 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | (156 | ) |  |  |  | 717 |  |  |  |
| Less: Current portion of long-term debt |  |  | (3,499 | ) |  |  |  | (3,500 | ) |  |  |
| Total long-term debt |  |  | $ | 73,557 |  |  |  |  | $ | 75,427 |  |  |  |

- added (2017-02-01):
[0001628280-17-000717:note_history:22]
As of December 31, 2016 and September 24, 2016, ¥90.4 billion and ¥195.5 billion, respectively, of Japanese yen-denominated notes were designated as a hedge of the foreign currency exposure of the Company's net investment in a foreign operation. The foreign currency transaction gain or loss on the Japanese yen-denominated debt designated as a hedge is recorded in OCI as a part of the cumulative translation adjustment. As of December 31, 2016 and September 24, 2016, the carrying value of the debt designated as a net investment hedge was $767 million and $1.9 billion, respectively. For further discussion regarding the Company’s use of derivative instruments see the Derivative Financial Instruments section of Note 2, “Financial Instruments.”

- changed (2017-02-01):
[0001628280-17-000717:note_history:23]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount and, if applicable, adjustments related to hedging. The Company recognized $509 million and $271 million of interest expense on its term debt for the three months ended December 31, 2016 and December 26, 2015, respectively.
  (was, 2016-07-27, similarity 0.7086):
[0001628280-16-017809:note_history:23]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount and, if applicable, adjustments related to hedging. The Company recognized $393 million and $975 million of interest expense on its term debt for the three- and nine-month periods ended June 25, 2016, respectively. The Company recognized $197 million and $486 million of interest expense on its term debt for the three- and nine-month periods ended June 27, 2015, respectively.

- changed (2017-02-01):
[0001628280-17-000717:note_history:24]
As of December 31, 2016 and September 24, 2016, the fair value of the Company’s Notes, based on Level 2 inputs, was $77.7 billion and $81.7 billion, respectively.
  (was, 2016-07-27, similarity 0.965):
[0001628280-16-017809:note_history:24]
As of June 25, 2016 and September 26, 2015, the fair value of the Company’s Notes, based on Level 2 inputs, was $74.1 billion and $54.9 billion, respectively.

- removed (2017-02-01):
[0001628280-16-017809:note_history:25]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of June 25, 2016 and September 26, 2015, the Company had $12.5 billion and $8.5 billion of Commercial Paper outstanding, respectively, with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 0.42% as of June 25, 2016 and 0.14% as of September 26, 2015.

- removed (2017-02-01):
[0001628280-16-017809:note_history:26]
|  | Nine Months Ended |
|  | June 25, 2016 |  | June 27, 2015 |
| Maturities less than 90 days: |  |  |  |
| Proceeds from (repayments of) commercial paper, net | $ | 4,154 |  |  | $ | 579 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 1,846 |  |  | 2,601 |  |
| Repayments of commercial paper | (2,008 | ) |  | (4,988 | ) |
| Proceeds from (repayments of) commercial paper, net | (162 | ) |  | (2,387 | ) |
| Total change in commercial paper, net | $ | 3,992 |  |  | $ | (1,808 | ) |

- removed (2017-02-01):
[0001628280-16-017809:note_history:27]
|  | Maturities |  | June 25, 2016 |  | September 26, 2015 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2018 |  | $ | 2,000 |  |  | 1.10% |  |  | $ | 3,000 |  |  | 0.51% - 1.10% |  |
| Fixed-rate 1.00% - 3.85% notes | 2018 - 2043 |  | 12,500 |  |  | 1.08% - 3.91% |  |  | 14,000 |  |  | 0.51% - 3.91% |  |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2017 - 2019 |  | 2,000 |  |  | 0.70% - 0.93% |  |  | 2,000 |  |  | 0.37% - 0.60% |  |
| Fixed-rate 1.05% - 4.45% notes | 2017 - 2044 |  | 10,000 |  |  | 0.70% - 4.48% |  |  | 10,000 |  |  | 0.37% - 4.48% |  |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2017 - 2020 |  | 1,774 |  |  | 0.68% - 1.87% |  |  | 1,743 |  |  | 0.36% - 1.87% |  |
| Fixed-rate 0.35% - 4.375% notes | 2017 - 2045 |  | 25,347 |  |  | 0.28% - 4.51% |  |  | 24,958 |  |  | 0.28% - 4.51% |  |
| Second quarter 2016 debt issuance of $15.5 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 |  | 500 |  |  | 1.47 | % |  | — |  |  | — |  |
| Floating-rate notes | 2021 |  | 500 |  |  | 1.78 | % |  | — |  |  | — |  |
| Fixed-rate 1.30% notes | 2018 |  | 500 |  |  | 1.32 | % |  | — |  |  | — |  |
| Fixed-rate 1.70% notes | 2019 |  | 1,000 |  |  | 1.71 | % |  | — |  |  | — |  |
| Fixed-rate 2.25% notes | 2021 |  | 3,000 |  |  | 1.80 | % |  | — |  |  | — |  |
| Fixed-rate 2.85% notes | 2023 |  | 1,500 |  |  | 2.50 | % |  | — |  |  | — |  |
| Fixed-rate 3.25% notes | 2026 |  | 3,250 |  |  | 2.40 | % |  | — |  |  | — |  |
| Fixed-rate 4.50% notes | 2036 |  | 1,250 |  |  | 4.54 | % |  | — |  |  | — |  |
| Fixed-rate 4.65% notes | 2046 |  | 4,000 |  |  | 4.58 | % |  | — |  |  | — |  |
| Third quarter 2016 Australian dollar-denominated debt issuance of A$1.4 billion: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 2.65% notes | 2020 |  | 487 |  |  | 1.92 | % |  | — |  |  | — |  |
| Fixed-rate 3.35% notes | 2024 |  | 337 |  |  | 2.61 | % |  | — |  |  | — |  |
| Fixed-rate 3.60% notes | 2026 |  | 243 |  |  | 2.84 | % |  | — |  |  | — |  |
| Third quarter 2016 debt issuance of $1.4 billion: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 4.15% notes | 2046 |  | 1,377 |  |  | 4.15 | % |  | — |  |  | — |  |
| Total term debt |  |  | 71,565 |  |  |  |  | 55,701 |  |  |  |
| Unamortized premium/(discount) |  |  | 14 |  |  |  |  | (114 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 860 |  |  |  |  | 376 |  |  |  |
| Less: Current portion of long-term debt |  |  | (3,500 | ) |  |  |  | (2,500 | ) |  |  |
| Total long-term debt |  |  | $ | 68,939 |  |  |  |  | $ | 53,463 |  |  |  |

- removed (2017-02-01):
[0001628280-16-017809:note_history:28]
During the third quarter of 2016, the Company issued $1.4 billion U.S. dollar-denominated notes in Taiwan and A$1.4 billion    Australian dollar-denominated notes. To manage foreign currency risk associated with the Australian dollar-denominated notes, the Company entered into currency swaps with an aggregate notional amount of $1.0 billion, which effectively converted these notes to U.S. dollar-denominated notes.

- removed (2017-02-01):
[0001628280-16-017809:note_history:29]
During the second quarter of 2016, the Company issued $15.5 billion U.S. dollar-denominated notes. To manage interest rate risk on the fixed-rate notes maturing in 2021, 2023 and 2026, the Company entered into interest rate swaps with an aggregate notional amount of  $5.0 billion, which effectively converted a portion of the fixed interest rates on these notes to a floating interest rate.

- removed (2017-02-01):
[0001628280-16-017809:note_history:30]
As of June 25, 2016, ¥191.0 billion of Japanese yen-denominated notes was designated as a hedge of the foreign currency exposure of its net investment in a foreign operation. The foreign currency transaction gain or loss on the Japanese yen-denominated debt designated as a hedge is recorded in OCI as a part of the cumulative translation adjustment.  As of June 25, 2016 and September 26, 2015, the carrying value of the debt designated as a net investment hedge was $1.8 billion and $2.1 billion, respectively. For further discussion regarding the Company’s use of derivative instruments see the Derivative Financial Instruments section of Note 2, “Financial Instruments.”


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-02-01):
[0001628280-17-000717:note_history:31]
The following table provides a summary of the Company’s term debt as of December 31, 2016 and September 24, 2016:
  (was, 2016-07-27, similarity 0.9505):
[0001628280-16-017809:note_history:31]
The following table provides a summary of the Company’s term debt as of June 25, 2016 and September 26, 2015:

- added (2017-02-01):
[0001628280-17-000717:note_history:32]
|  | Maturities |  | December 31, 2016 |  | September 24, 2016 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2018 |  | $ | 2,000 |  |  | 1.10% |  | $ | 2,000 |  |  | 1.10% |
| Fixed-rate 1.000% - 3.850% notes | 2018 - 2043 |  | 12,500 |  |  | 1.08% - 3.91% |  | 12,500 |  |  | 1.08% - 3.91% |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2017 - 2019 |  | 2,000 |  |  | 0.95% - 1.18% |  | 2,000 |  |  | 0.86% - 1.09% |
| Fixed-rate 1.050% - 4.450% notes | 2017 - 2044 |  | 10,000 |  |  | 0.95% - 4.48% |  | 10,000 |  |  | 0.85% - 4.48% |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2017 - 2020 |  | 1,753 |  |  | 0.95% - 1.87% |  | 1,781 |  |  | 0.87% - 1.87% |
| Fixed-rate 0.350% - 4.375% notes | 2017 - 2045 |  | 24,225 |  |  | 0.28% - 4.51% |  | 25,144 |  |  | 0.28% - 4.51% |
| 2016 debt issuances of $24.9 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 - 2021 |  | 1,350 |  |  | 1.02% - 2.05% |  | 1,350 |  |  | 0.91% - 1.95% |
| Fixed-rate 1.100% - 4.650% notes | 2018 - 2046 |  | 23,550 |  |  | 1.13% - 4.78% |  | 23,609 |  |  | 1.13% - 4.58% |
| Total term debt |  |  | 77,378 |  |  |  |  | 78,384 |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  | (166 | ) |  |  |  | (174 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | (156 | ) |  |  |  | 717 |  |  |  |
| Less: Current portion of long-term debt |  |  | (3,499 | ) |  |  |  | (3,500 | ) |  |  |
| Total long-term debt |  |  | $ | 73,557 |  |  |  |  | $ | 75,427 |  |  |  |

- removed (2017-02-01):
[0001628280-16-017809:note_history:33]
|  | Maturities |  | June 25, 2016 |  | September 26, 2015 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2018 |  | $ | 2,000 |  |  | 1.10% |  |  | $ | 3,000 |  |  | 0.51% - 1.10% |  |
| Fixed-rate 1.00% - 3.85% notes | 2018 - 2043 |  | 12,500 |  |  | 1.08% - 3.91% |  |  | 14,000 |  |  | 0.51% - 3.91% |  |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2017 - 2019 |  | 2,000 |  |  | 0.70% - 0.93% |  |  | 2,000 |  |  | 0.37% - 0.60% |  |
| Fixed-rate 1.05% - 4.45% notes | 2017 - 2044 |  | 10,000 |  |  | 0.70% - 4.48% |  |  | 10,000 |  |  | 0.37% - 4.48% |  |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2017 - 2020 |  | 1,774 |  |  | 0.68% - 1.87% |  |  | 1,743 |  |  | 0.36% - 1.87% |  |
| Fixed-rate 0.35% - 4.375% notes | 2017 - 2045 |  | 25,347 |  |  | 0.28% - 4.51% |  |  | 24,958 |  |  | 0.28% - 4.51% |  |
| Second quarter 2016 debt issuance of $15.5 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 |  | 500 |  |  | 1.47 | % |  | — |  |  | — |  |
| Floating-rate notes | 2021 |  | 500 |  |  | 1.78 | % |  | — |  |  | — |  |
| Fixed-rate 1.30% notes | 2018 |  | 500 |  |  | 1.32 | % |  | — |  |  | — |  |
| Fixed-rate 1.70% notes | 2019 |  | 1,000 |  |  | 1.71 | % |  | — |  |  | — |  |
| Fixed-rate 2.25% notes | 2021 |  | 3,000 |  |  | 1.80 | % |  | — |  |  | — |  |
| Fixed-rate 2.85% notes | 2023 |  | 1,500 |  |  | 2.50 | % |  | — |  |  | — |  |
| Fixed-rate 3.25% notes | 2026 |  | 3,250 |  |  | 2.40 | % |  | — |  |  | — |  |
| Fixed-rate 4.50% notes | 2036 |  | 1,250 |  |  | 4.54 | % |  | — |  |  | — |  |
| Fixed-rate 4.65% notes | 2046 |  | 4,000 |  |  | 4.58 | % |  | — |  |  | — |  |
| Third quarter 2016 Australian dollar-denominated debt issuance of A$1.4 billion: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 2.65% notes | 2020 |  | 487 |  |  | 1.92 | % |  | — |  |  | — |  |
| Fixed-rate 3.35% notes | 2024 |  | 337 |  |  | 2.61 | % |  | — |  |  | — |  |
| Fixed-rate 3.60% notes | 2026 |  | 243 |  |  | 2.84 | % |  | — |  |  | — |  |
| Third quarter 2016 debt issuance of $1.4 billion: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 4.15% notes | 2046 |  | 1,377 |  |  | 4.15 | % |  | — |  |  | — |  |
| Total term debt |  |  | 71,565 |  |  |  |  | 55,701 |  |  |  |
| Unamortized premium/(discount) |  |  | 14 |  |  |  |  | (114 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 860 |  |  |  |  | 376 |  |  |  |
| Less: Current portion of long-term debt |  |  | (3,500 | ) |  |  |  | (2,500 | ) |  |  |
| Total long-term debt |  |  | $ | 68,939 |  |  |  |  | $ | 53,463 |  |  |  |
