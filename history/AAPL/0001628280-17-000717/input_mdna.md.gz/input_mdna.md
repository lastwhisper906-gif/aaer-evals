# AAPL MD&A — 0001628280-17-000717


## mdna

[0001628280-17-000717:mdna:1]
[same as prior period, unchanged from 0001628280-16-017809:mdna:1]

[0001628280-17-000717:mdna:2]
[same as prior period, unchanged from 0001628280-16-017809:mdna:2]

[0001628280-17-000717:mdna:3]
[same as prior period, unchanged from 0001628280-16-017809:mdna:3]

[0001628280-17-000717:mdna:4]
[same as prior period, unchanged from 0001628280-16-017809:mdna:4]

[0001628280-17-000717:mdna:5]
The Company designs, manufactures and markets mobile communication and media devices, personal computers and portable digital music players, and sells a variety of related software, services, accessories, networking solutions and third-party digital content and applications. The Company’s products and services include iPhone®, iPad®, Mac®, iPod®, Apple Watch®, Apple TV®, a portfolio of consumer and professional software applications, iOS, macOS™, watchOS® and tvOS™ operating systems, iCloud®, Apple Pay® and a variety of accessory, service and support offerings. The Company sells and delivers digital content and applications through the iTunes Store®, App Store®, Mac App Store, TV App Store, iBooks Store™ and Apple Music® (collectively “Digital Content and Services”). The Company sells its products worldwide through its retail stores, online stores and direct sales force, as well as through third-party cellular network carriers, wholesalers, retailers and value-added resellers. In addition, the Company sells a variety of third-party Apple-compatible products, including application software and various accessories through its retail and online stores. The Company sells to consumers, small and mid-sized businesses and education, enterprise and government customers.

[0001628280-17-000717:mdna:6]
[same as prior period, unchanged from 0001628280-16-017809:mdna:7]

[0001628280-17-000717:mdna:7]
The Company is committed to bringing the best user experience to its customers through its innovative hardware, software and services. The Company’s business strategy leverages its unique ability to design and develop its own operating systems, hardware, application software and services to provide its customers products and solutions with innovative design, superior ease-of-use and seamless integration. As part of its strategy, the Company continues to expand its platform for the discovery and delivery of digital content and applications through its Digital Content and Services, which allows customers to discover and download digital content, iOS, Mac, Apple Watch and Apple TV applications, and books through either a Mac or Windows personal computer or through iPhone, iPad and iPod touch® devices (“iOS devices”), Apple TV and Apple Watch. The Company also supports a community for the development of third-party software and hardware products and digital content that complement the Company’s offerings. The Company believes a high-quality buying experience with knowledgeable salespersons who can convey the value of the Company’s products and services greatly enhances its ability to attract and retain customers. Therefore, the Company’s strategy also includes building and expanding its own retail and online stores and its third-party distribution network to effectively reach more customers and provide them with a high-quality sales and post-sales support experience. The Company believes ongoing investment in research and development (“R&D”), marketing and advertising is critical to the development and sale of innovative products and technologies.

[0001628280-17-000717:mdna:8]
[same as prior period, unchanged from 0001628280-16-017809:mdna:10]

[0001628280-17-000717:mdna:9]
[same as prior period, unchanged from 0001628280-16-017809:mdna:11]

[0001628280-17-000717:mdna:10]
Fiscal Period

[0001628280-17-000717:mdna:11]
The Company’s fiscal year is the 52 or 53-week period that ends on the last Saturday of September. The Company’s fiscal year 2017 will include 53 weeks and will end on September 30, 2017. A 14th week has been included in the first quarter of 2017, as is done every five or six years, to realign the Company’s fiscal quarters with calendar quarters.

[0001628280-17-000717:mdna:12]
First Quarter Fiscal 2017 Highlights

[0001628280-17-000717:mdna:13]
Net sales grew 3% or $2.5 billion during the first quarter of 2017 compared to the first quarter of 2016, primarily driven by strong growth in iPhone and Services, partially offset by lower iPad sales. The positive impact of having an additional week in the first quarter of 2017 was primarily offset by lower year-over-year channel inventory growth, an earlier launch of iPhone 7 and 7 Plus as compared to the prior year and the effect of weakness in foreign currencies relative to the U.S. dollar.

[0001628280-17-000717:mdna:14]
During the first quarter of 2017, the Company introduced a new MacBook Pro® with Touch Bar™, an interface that replaces the traditional row of function keys, and released AirPods™, which are new wireless headphones.

[0001628280-17-000717:mdna:15]
[same as prior period, unchanged from 0001628280-16-017809:mdna:16]

[0001628280-17-000717:mdna:16]
The following table shows net sales by operating segment and net sales and unit sales by product for the three months ended December 31, 2016 and December 26, 2015 (dollars in millions and units in thousands):

[0001628280-17-000717:mdna:17]
|  | Three Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |  | Change |
| Net Sales by Operating Segment: |  |  |  |  |  |
| Americas | $ | 31,968 |  |  | $ | 29,325 |  |  | 9 | % |
| Europe | 18,521 |  |  | 17,932 |  |  | 3 | % |
| Greater China | 16,233 |  |  | 18,373 |  |  | (12 | )% |
| Japan | 5,766 |  |  | 4,794 |  |  | 20 | % |
| Rest of Asia Pacific | 5,863 |  |  | 5,448 |  |  | 8 | % |
| Total net sales | $ | 78,351 |  |  | $ | 75,872 |  |  | 3 | % |
| Net Sales by Product: |  |  |  |  |  |
| iPhone (1) | $ | 54,378 |  |  | $ | 51,635 |  |  | 5 | % |
| iPad (1) | 5,533 |  |  | 7,084 |  |  | (22 | )% |
| Mac (1) | 7,244 |  |  | 6,746 |  |  | 7 | % |
| Services (2) | 7,172 |  |  | 6,056 |  |  | 18 | % |
| Other Products (1)(3) | 4,024 |  |  | 4,351 |  |  | (8 | )% |
| Total net sales | $ | 78,351 |  |  | $ | 75,872 |  |  | 3 | % |
| Unit Sales by Product: |  |  |  |  |  |
| iPhone | 78,290 |  |  | 74,779 |  |  | 5 | % |
| iPad | 13,081 |  |  | 16,122 |  |  | (19 | )% |
| Mac | 5,374 |  |  | 5,312 |  |  | 1 | % |

[0001628280-17-000717:mdna:18]
[same as prior period, unchanged from 0001628280-16-017809:mdna:19]

[0001628280-17-000717:mdna:19]
| (2) | Includes revenue from Digital Content and Services, AppleCare®, Apple Pay, licensing and other services. |

[0001628280-17-000717:mdna:20]
[same as prior period, unchanged from 0001628280-16-017809:mdna:21]

[0001628280-17-000717:mdna:21]
[same as prior period, unchanged from 0001628280-16-017809:mdna:23]

[0001628280-17-000717:mdna:22]
[same as prior period, unchanged from 0001628280-16-017809:mdna:24]

[0001628280-17-000717:mdna:23]
The following table presents iPhone net sales and unit sales information for the first quarter of 2017 and 2016 (dollars in millions and units in thousands):

[0001628280-17-000717:mdna:24]
|  | Three Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |  | Change |
| Net sales | $ | 54,378 |  |  | $ | 51,635 |  |  | 5 | % |
| Percentage of total net sales | 69 | % |  | 68 | % |  |  |
| Unit sales | 78,290 |  |  | 74,779 |  |  | 5 | % |

[0001628280-17-000717:mdna:25]
iPhone net sales increased during the first quarter of 2017 compared to the same quarter in 2016, driven by strong growth in each of the geographic operating segments, with the exception of Greater China.

[0001628280-17-000717:mdna:26]
[same as prior period, unchanged from 0001628280-16-017809:mdna:28]

[0001628280-17-000717:mdna:27]
The following table presents iPad net sales and unit sales information for the first quarter of 2017 and 2016 (dollars in millions and units in thousands):

[0001628280-17-000717:mdna:28]
|  | Three Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |  | Change |
| Net sales | $ | 5,533 |  |  | $ | 7,084 |  |  | (22 | )% |
| Percentage of total net sales | 7 | % |  | 9 | % |  |  |
| Unit sales | 13,081 |  |  | 16,122 |  |  | (19 | )% |

[0001628280-17-000717:mdna:29]
iPad net sales decreased in the first quarter of 2017 compared to the same quarter in 2016 due to lower iPad unit sales and lower average selling prices for iPad, both due in part to the introduction of the 12.9-inch iPad Pro in the first quarter of 2016.

[0001628280-17-000717:mdna:30]
[same as prior period, unchanged from 0001628280-16-017809:mdna:32]

[0001628280-17-000717:mdna:31]
The following table presents Mac net sales and unit sales information for the first quarter of 2017 and 2016 (dollars in millions and units in thousands):

[0001628280-17-000717:mdna:32]
|  | Three Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |  | Change |
| Net sales | $ | 7,244 |  |  | $ | 6,746 |  |  | 7 | % |
| Percentage of total net sales | 9 | % |  | 9 | % |  |  |
| Unit sales | 5,374 |  |  | 5,312 |  |  | 1 | % |

[0001628280-17-000717:mdna:33]
Mac net sales increased during the first quarter of 2017 compared to the same quarter in 2016 due primarily to a different mix of Macs, including the new MacBook Pro introduced in the first quarter of 2017.

[0001628280-17-000717:mdna:34]
[same as prior period, unchanged from 0001628280-16-017809:mdna:37]

[0001628280-17-000717:mdna:35]
The following table presents Services net sales information for the first quarter of 2017 and 2016 (dollars in millions):

[0001628280-17-000717:mdna:36]
|  | Three Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |  | Change |
| Net sales | $ | 7,172 |  |  | $ | 6,056 |  |  | 18 | % |
| Percentage of total net sales | 9 | % |  | 8 | % |  |  |

[0001628280-17-000717:mdna:37]
The year-over-year increase in Services net sales in the first quarter of 2017 compared to the same quarter in 2016 was due primarily to growth from the App Store and AppleCare sales, partially offset by the $548 million received from Samsung Electronics Co., Ltd. in the first quarter of 2016 related to patent infringement matters.

[0001628280-17-000717:mdna:38]
[same as prior period, unchanged from 0001628280-16-017809:mdna:22]

[0001628280-17-000717:mdna:39]
[same as prior period, unchanged from 0001628280-16-017809:mdna:41]

[0001628280-17-000717:mdna:40]
[same as prior period, unchanged from 0001628280-16-017809:mdna:42]

[0001628280-17-000717:mdna:41]
[same as prior period, unchanged from 0001628280-16-017809:mdna:43]

[0001628280-17-000717:mdna:42]
The following table presents Americas net sales information for the first quarter of 2017 and 2016 (dollars in millions):

[0001628280-17-000717:mdna:43]
|  | Three Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |  | Change |
| Net sales | $ | 31,968 |  |  | $ | 29,325 |  |  | 9 | % |
| Percentage of total net sales | 41 | % |  | 39 | % |  |  |

[0001628280-17-000717:mdna:44]
Americas net sales increased during the first quarter of 2017 compared to the same quarter in 2016 due primarily to higher net sales of iPhone, partially offset by lower net sales of iPad.

[0001628280-17-000717:mdna:45]
[same as prior period, unchanged from 0001628280-16-017809:mdna:47]

[0001628280-17-000717:mdna:46]
The following table presents Europe net sales information for the first quarter of 2017 and 2016 (dollars in millions):

[0001628280-17-000717:mdna:47]
|  | Three Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |  | Change |
| Net sales | $ | 18,521 |  |  | $ | 17,932 |  |  | 3 | % |
| Percentage of total net sales | 24 | % |  | 24 | % |  |  |

[0001628280-17-000717:mdna:48]
Europe net sales increased during the first quarter of 2017 compared to the same quarter in 2016 due primarily to higher net sales of iPhone, partially offset by the effect of weakness in foreign currencies relative to the U.S. dollar and a decrease in net sales of iPad.

[0001628280-17-000717:mdna:49]
[same as prior period, unchanged from 0001628280-16-017809:mdna:51]

[0001628280-17-000717:mdna:50]
The following table presents Greater China net sales information for the first quarter of 2017 and 2016 (dollars in millions):

[0001628280-17-000717:mdna:51]
|  | Three Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |  | Change |
| Net sales | $ | 16,233 |  |  | $ | 18,373 |  |  | (12 | )% |
| Percentage of total net sales | 21 | % |  | 24 | % |  |  |

[0001628280-17-000717:mdna:52]
Greater China net sales decreased during the first quarter of 2017 compared to the same quarter in 2016 due primarily to lower net sales of iPhone and the effect of weakness in foreign currencies relative to the U.S. dollar.

[0001628280-17-000717:mdna:53]
[same as prior period, unchanged from 0001628280-16-017809:mdna:55]

[0001628280-17-000717:mdna:54]
The following table presents Japan net sales information for the first quarter of 2017 and 2016 (dollars in millions):

[0001628280-17-000717:mdna:55]
|  | Three Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |  | Change |
| Net sales | $ | 5,766 |  |  | $ | 4,794 |  |  | 20 | % |
| Percentage of total net sales | 7 | % |  | 6 | % |  |  |

[0001628280-17-000717:mdna:56]
Japan net sales increased during the first quarter of 2017 compared to the same quarter in 2016 due primarily to higher net sales of iPhone and Services, and the effect of strength in the Japanese yen relative to the U.S. dollar.

[0001628280-17-000717:mdna:57]
[same as prior period, unchanged from 0001628280-16-017809:mdna:59]

[0001628280-17-000717:mdna:58]
The following table presents Rest of Asia Pacific net sales information for the first quarter of 2017 and 2016 (dollars in millions):

[0001628280-17-000717:mdna:59]
|  | Three Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |  | Change |
| Net sales | $ | 5,863 |  |  | $ | 5,448 |  |  | 8 | % |
| Percentage of total net sales | 7 | % |  | 7 | % |  |  |

[0001628280-17-000717:mdna:60]
Rest of Asia Pacific net sales increased during the first quarter of 2017 compared to the same quarter in 2016 due primarily to higher net sales of iPhone and the effect of strength in foreign currencies relative to the U.S. dollar.

[0001628280-17-000717:mdna:61]
[same as prior period, unchanged from 0001628280-16-017809:mdna:64]

[0001628280-17-000717:mdna:62]
Gross margin for the first quarter of 2017 and 2016 was as follows (dollars in millions):

[0001628280-17-000717:mdna:63]
|  | Three Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |
| Net sales | $ | 78,351 |  |  | $ | 75,872 |  |
| Cost of sales | 48,175 |  |  | 45,449 |  |
| Gross margin | $ | 30,176 |  |  | $ | 30,423 |  |
| Gross margin percentage | 38.5 | % |  | 40.1 | % |

[0001628280-17-000717:mdna:64]
Gross margin decreased during the first quarter of 2017 compared to the same quarter in 2016 due primarily to higher product cost structures and the effect of weakness in foreign currencies relative to the U.S. dollar, partially offset by a favorable mix of products and services.

[0001628280-17-000717:mdna:65]
The Company anticipates gross margin during the second quarter of 2017 to be between 38% and 39%. The foregoing statement regarding the Company’s expected gross margin percentage in the second quarter of 2017 is forward-looking and could differ from actual results. The Company’s future gross margins can be impacted by multiple factors including, but not limited to, those set forth in Part II, Item 1A of this Form 10-Q under the heading “Risk Factors” and those described in this paragraph. In general, the Company believes gross margins will remain under downward pressure due to a variety of factors, including continued industry-wide global product pricing pressures, increased competition, compressed product life cycles, product transitions, potential increases in the cost of components, and potential strengthening of the U.S. dollar, as well as potential increases in the costs of outside manufacturing services and a potential shift in the Company’s sales mix towards products with lower gross margins. In response to competitive pressures, the Company expects it will continue to take product pricing actions, which would adversely affect gross margins. Gross margins could also be affected by the Company’s ability to manage product quality and warranty costs effectively and to stimulate demand for certain of its products. Due to the Company’s significant international operations, its financial condition and operating results, including gross margins, could be significantly affected by fluctuations in exchange rates.

[0001628280-17-000717:mdna:66]
[same as prior period, unchanged from 0001628280-16-017809:mdna:69]

[0001628280-17-000717:mdna:67]
Operating expenses for the first quarter of 2017 and 2016 were as follows (dollars in millions):

[0001628280-17-000717:mdna:68]
|  | Three Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |
| Research and development | $ | 2,871 |  |  | $ | 2,404 |  |
| Percentage of total net sales | 4 | % |  | 3 | % |
| Selling, general and administrative | $ | 3,946 |  |  | $ | 3,848 |  |
| Percentage of total net sales | 5 | % |  | 5 | % |
| Total operating expenses | $ | 6,817 |  |  | $ | 6,252 |  |
| Percentage of total net sales | 9 | % |  | 8 | % |

[0001628280-17-000717:mdna:69]
[same as prior period, unchanged from 0001628280-16-017809:mdna:72]

[0001628280-17-000717:mdna:70]
The growth in R&D expense during the first quarter of 2017 compared to the same quarter in 2016 was driven primarily by an increase in headcount and related expenses, and material costs to support expanded R&D activities. The Company continues to believe that focused investments in R&D are critical to its future growth and competitive position in the marketplace, and to the development of new and updated products that are central to the Company’s core business strategy.

[0001628280-17-000717:mdna:71]
[same as prior period, unchanged from 0001628280-16-017809:mdna:74]

[0001628280-17-000717:mdna:72]
The growth in selling, general and administrative expense during the first quarter of 2017 compared to the same quarter in 2016 was driven primarily by an increase in headcount and related expenses and higher variable selling costs, partially offset by lower advertising costs.

[0001628280-17-000717:mdna:73]
[same as prior period, unchanged from 0001628280-16-017809:mdna:76]

[0001628280-17-000717:mdna:74]
Other income/(expense), net for the first quarter of 2017 and 2016 was as follows (dollars in millions):

[0001628280-17-000717:mdna:75]
|  | Three Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |  | Change |
| Interest and dividend income | $ | 1,224 |  |  | $ | 941 |  |  |  |
| Interest expense | (525 | ) |  | (276 | ) |  |  |
| Other income/(expense), net | 122 |  |  | (263 | ) |  |  |
| Total other income/(expense), net | $ | 821 |  |  | $ | 402 |  |  | 104 | % |

[0001628280-17-000717:mdna:76]
The increase in other income/(expense), net during the first quarter of 2017 compared to the same quarter in 2016 was due primarily to higher interest income and foreign exchange gains, partially offset by higher interest expense on debt. The weighted-average interest rate earned by the Company on its cash, cash equivalents and marketable securities was 1.87% and 1.65% in the first quarter of 2017 and 2016, respectively.

[0001628280-17-000717:mdna:77]
[same as prior period, unchanged from 0001628280-16-017809:mdna:80]

[0001628280-17-000717:mdna:78]
Provision for income taxes and effective tax rates for the first quarter of 2017 and 2016 were as follows (dollars in millions):

[0001628280-17-000717:mdna:79]
|  | Three Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |
| Provision for income taxes | $ | 6,289 |  |  | $ | 6,212 |  |
| Effective tax rate | 26.0 | % |  | 25.3 | % |

[0001628280-17-000717:mdna:80]
The Company’s effective tax rates during the first quarter of 2017 and 2016 differ from the statutory federal income tax rate of 35% due primarily to certain undistributed foreign earnings, a substantial portion of which was generated by subsidiaries organized in Ireland, for which no U.S. taxes are provided when such earnings are intended to be indefinitely reinvested outside the U.S. The higher year-over-year effective tax rate during the first quarter of 2017 was due primarily to the retroactive reinstatement of the U.S. federal R&D tax credit during the first quarter of 2016.

[0001628280-17-000717:mdna:81]
The Company is subject to audits by federal, state, local and foreign tax authorities. Management believes that adequate provisions have been made for any adjustments that may result from tax examinations. However, the outcome of tax audits cannot be predicted with certainty. If any issues addressed in the Company’s tax audits are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs.

[0001628280-17-000717:mdna:82]
On August 30, 2016, the European Commission announced its decision that Ireland granted state aid to the Company by providing tax opinions in 1991 and 2007 concerning the tax allocation of profits of the Irish branches of two subsidiaries of the Company (the “State Aid Decision”). The State Aid Decision orders Ireland to calculate and recover additional taxes from the Company for the period June 2003 through December 2014. Irish legislative changes, effective as of January 2015, eliminated the application of the tax opinions from that date forward. The Company believes the State Aid Decision to be without merit and appealed to the General Court of the Court of Justice of the European Union. Ireland has also appealed the State Aid Decision. While the European Commission announced a recovery amount of up to €13 billion, plus interest, the actual amount of additional taxes subject to recovery is to be calculated by Ireland in accordance with the European Commission's guidance. Once the recovery amount is computed by Ireland, the Company anticipates funding it, including interest, out of foreign cash into escrow, where it will remain pending conclusion of all appeals. The Company believes that any incremental Irish corporate income taxes potentially due related to the State Aid Decision would be creditable against U.S. taxes.

[0001628280-17-000717:mdna:83]
[same as prior period, unchanged from 0001628280-16-017809:mdna:86]

[0001628280-17-000717:mdna:84]
Restricted Cash

[0001628280-17-000717:mdna:85]
In November 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash (“ASU 2016-18”), which enhances and clarifies the guidance on the classification and presentation of restricted cash in the statement of cash flows. The Company will adopt ASU 2016-18 in its first quarter of 2019 utilizing the retrospective adoption method. Currently, the Company's restricted cash balance is not significant.

[0001628280-17-000717:mdna:86]
Income Taxes

[0001628280-17-000717:mdna:87]
In October 2016, the FASB issued ASU No. 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory (“ASU 2016-16”), which requires the recognition of the income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. The Company will adopt ASU 2016-16 in its first quarter of 2019 utilizing the modified retrospective adoption method. Currently, the Company anticipates recording up to $9 billion of net deferred tax assets on its Consolidated Balance Sheets. However, the ultimate impact of adopting ASU 2016-16 will depend on the balance of intellectual property transferred between its subsidiaries as of the adoption date. The Company will recognize incremental deferred income tax expense thereafter as these deferred tax assets are utilized.

[0001628280-17-000717:mdna:88]
[same as prior period, unchanged from 0001628280-16-017809:mdna:87]

[0001628280-17-000717:mdna:89]
In March 2016, the FASB issued ASU No. 2016-09, Compensation – Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting (“ASU 2016-09”), which modifies certain aspects of the accounting for share-based payment transactions, including income taxes, classification of awards, and classification in the statement of cash flows. The Company will adopt ASU 2016-09 in its first quarter of 2018. Currently, excess tax benefits or deficiencies from the Company's equity awards are recorded as additional paid-in capital in its Consolidated Balance Sheets. Upon adoption, the Company will record any excess tax benefits or deficiencies from its equity awards in its Consolidated Statements of Operations in the reporting periods in which vesting occurs. As a result, subsequent to adoption the Company's income tax expense and associated effective tax rate will be impacted by fluctuations in stock price between the grant dates and vesting dates of equity awards.

[0001628280-17-000717:mdna:90]
[same as prior period, unchanged from 0001628280-16-017809:mdna:89]

[0001628280-17-000717:mdna:91]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842) (“ASU 2016-02”), which modifies lease accounting for lessees to increase transparency and comparability by recording lease assets and liabilities for operating leases and disclosing key information about leasing arrangements. ASU 2016-02 will be effective for the Company beginning in its first quarter of 2020, and early adoption is permitted. The Company will use a modified retrospective adoption approach. While the Company is currently evaluating the timing and impact of adopting ASU 2016-02, currently the Company anticipates recording lease assets and liabilities in excess of $7.5 billion on its Consolidated Balance Sheets, with no material impact to its Consolidated Statements of Operations. However, the ultimate impact of adopting ASU 2016-02 will depend on the Company's lease portfolio as of the adoption date.

[0001628280-17-000717:mdna:92]
[same as prior period, unchanged from 0001628280-16-017809:mdna:91]

[0001628280-17-000717:mdna:93]
In January 2016, the FASB issued ASU No. 2016-01, Financial Instruments – Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities (“ASU 2016-01”), which updates certain aspects of recognition, measurement, presentation and disclosure of financial instruments. The Company will adopt ASU 2016-01 in its first quarter of 2019 utilizing the modified retrospective adoption method. Based on the composition of the Company's investment portfolio, the adoption of ASU 2016-01 is not expected to have a material impact on its consolidated financial statements.

[0001628280-17-000717:mdna:94]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (“ASU 2016-13”), which modifies the measurement of expected credit losses of certain financial instruments. The Company will adopt ASU 2016-13 in its first quarter of 2021 utilizing the modified retrospective adoption method. Based on the composition of the Company's investment portfolio, current market conditions, and historical credit loss activity, the adoption of ASU 2016-13 is not expected to have a material impact on its consolidated financial statements.

[0001628280-17-000717:mdna:95]
[same as prior period, unchanged from 0001628280-16-017809:mdna:94]

[0001628280-17-000717:mdna:96]
In May 2014, the FASB issued ASU No. 2014-09, Revenue from Contracts with Customers (Topic 606) (“ASU 2014-09”), which amends the existing accounting standards for revenue recognition. ASU 2014-09 is based on principles that govern the recognition of revenue at an amount an entity expects to be entitled when products are transferred to customers.

[0001628280-17-000717:mdna:97]
Subsequently, the FASB has issued the following standards related to ASU 2014-09: ASU No. 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (“ASU 2016-08”); ASU No. 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing (“ASU 2016-10”); ASU No. 2016-12, Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients (“ASU 2016-12”); and ASU No. 2016-20, Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers (“ASU 2016-20”). The Company must adopt ASU 2016-08, ASU 2016-10, ASU 2016-12 and ASU 2016-20 with ASU 2014-09 (collectively, the “new revenue standards”).

[0001628280-17-000717:mdna:98]
The new revenue standards may be applied retrospectively to each prior period presented or retrospectively with the cumulative effect recognized as of the date of adoption. The Company currently expects to adopt the new revenue standards in its first quarter of 2018 utilizing the full retrospective adoption method. The new revenue standards are not expected to have a material impact on the amount and timing of revenue recognized in the Company's consolidated financial statements.

[0001628280-17-000717:mdna:99]
[same as prior period, unchanged from 0001628280-16-017809:mdna:98]

[0001628280-17-000717:mdna:100]
The following tables present selected financial information and statistics as of December 31, 2016 and September 24, 2016 and for the first three months of 2017 and 2016 (in millions):

[0001628280-17-000717:mdna:101]
|  | December 31, 2016 |  | September 24, 2016 |
| Cash, cash equivalents and marketable securities | $ | 246,090 |  |  | $ | 237,585 |  |
| Property, plant and equipment, net | $ | 26,510 |  |  | $ | 27,010 |  |
| Commercial paper | $ | 10,493 |  |  | $ | 8,105 |  |
| Total term debt | $ | 77,056 |  |  | $ | 78,927 |  |
| Working capital | $ | 19,202 |  |  | $ | 27,863 |  |

[0001628280-17-000717:mdna:102]
|  | Three Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |
| Cash generated by operating activities | $ | 27,056 |  |  | $ | 27,463 |  |
| Cash used in investing activities | $ | (19,122 | ) |  | $ | (20,450 | ) |
| Cash used in financing activities | $ | (12,047 | ) |  | $ | (11,444 | ) |

[0001628280-17-000717:mdna:103]
[same as prior period, unchanged from 0001628280-16-017809:mdna:102]

[0001628280-17-000717:mdna:104]
As of December 31, 2016 and September 24, 2016, the Company’s cash, cash equivalents and marketable securities held by foreign subsidiaries were $230.2 billion and $216.0 billion, respectively, and are generally based in U.S. dollar-denominated holdings. Amounts held by foreign subsidiaries are generally subject to U.S. income taxation on repatriation to the U.S. In connection with the State Aid Decision, the European Commission announced a recovery amount of up to €13 billion, plus interest. The actual amount of additional taxes subject to recovery is to be calculated by Ireland in accordance with the European Commission's guidance. Once the recovery amount is computed by Ireland, the Company anticipates funding it, including interest, out of foreign cash into escrow, where it will remain pending conclusion of all appeals.

[0001628280-17-000717:mdna:105]
The Company’s marketable securities investment portfolio is invested primarily in highly-rated securities, and its investment policy generally limits the amount of credit exposure to any one issuer. The policy requires investments generally to be investment grade with the objective of minimizing the potential risk of principal loss.

[0001628280-17-000717:mdna:106]
During the three months ended December 31, 2016, cash generated from operating activities of $27.1 billion was a result of $17.9 billion of net income, non-cash adjustments to net income of $5.4 billion and an increase in the net change in operating assets and liabilities of $3.7 billion. Cash used in investing activities of $19.1 billion during the three months ended December 31, 2016 consisted primarily of cash used for purchases of marketable securities, net of sales and maturities, of $15.6 billion and cash used to acquire property, plant and equipment of $3.3 billion. Cash used in financing activities of $12.0 billion during the three months ended December 31, 2016 consisted primarily of cash used to repurchase common stock of $10.9 billion and cash used to pay dividends and dividend equivalents of $3.1 billion, partially offset by a net increase in commercial paper of $2.4 billion.

[0001628280-17-000717:mdna:107]
During the three months ended December 26, 2015, cash generated from operating activities of $27.5 billion was a result of $18.4 billion of net income, non-cash adjustments to net income of $5.7 billion and an increase in the net change in operating assets and liabilities of $3.4 billion. Cash used in investing activities of $20.5 billion during the three months ended December 26, 2015 consisted primarily of cash used for purchases of marketable securities, net of sales and maturities, of $16.1 billion and cash used to acquire property, plant and equipment of $3.6 billion. Cash used in financing activities of $11.4 billion during the three months ended December 26, 2015 consisted primarily of cash used to repurchase common stock of $6.9 billion, and cash used to pay dividends and dividend equivalents of $3.0 billion.

[0001628280-17-000717:mdna:108]
[same as prior period, unchanged from 0001628280-16-017809:mdna:106]

[0001628280-17-000717:mdna:109]
The Company’s capital expenditures were $2.1 billion during the first quarter of 2017. The Company anticipates utilizing approximately $16.0 billion for capital expenditures during 2017, which includes product tooling and manufacturing process equipment; data centers; corporate facilities and infrastructure, including information systems hardware, software and enhancements; and retail store facilities.

[0001628280-17-000717:mdna:110]
[same as prior period, unchanged from 0001628280-16-017809:mdna:108]

[0001628280-17-000717:mdna:111]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses the net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of December 31, 2016, the Company had $10.5 billion of Commercial Paper outstanding, with a weighted-average interest rate of 0.61% and maturities generally less than nine months.

[0001628280-17-000717:mdna:112]
As of December 31, 2016, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $77.4 billion (collectively the “Notes”). The Company has entered, and in the future may enter, into interest rate swaps to manage interest rate risk on the Notes. In addition, the Company has entered, and in the future may enter, into currency swaps to manage foreign currency risk on the Notes.

[0001628280-17-000717:mdna:113]
[same as prior period, unchanged from 0001628280-16-017809:mdna:111]

[0001628280-17-000717:mdna:114]
[same as prior period, unchanged from 0001628280-16-017809:mdna:112]

[0001628280-17-000717:mdna:115]
In April 2016, the Company’s Board of Directors increased the share repurchase program authorization from $140 billion to $175 billion of the Company’s common stock, increasing the expected total size of the capital return program from $200 billion to $250 billion. Additionally in April 2016, the Company announced that the Board of Directors raised the rate of the Company's quarterly cash dividend by 10% from $0.52 to $0.57 per share, beginning with the dividend paid during the third quarter of 2016. The Company intends to increase its dividend on an annual basis subject to declaration by the Board of Directors.

[0001628280-17-000717:mdna:116]
As of December 31, 2016, $144 billion of the share repurchase program has been utilized. The Company’s share repurchase program does not obligate it to acquire any specific number of shares. Under the program, shares may be repurchased in privately negotiated or open market transactions, including under plans complying with Rule 10b5-1 under the Exchange Act.

[0001628280-17-000717:mdna:117]
The following table presents the Company’s dividends, dividend equivalents, share repurchases and net share settlement activity from the start of the capital return program in August 2012 through December 31, 2016 (in millions):

[0001628280-17-000717:mdna:118]
|  | Dividends andDividend Equivalents Paid |  | Accelerated ShareRepurchases |  | Open MarketShare Repurchases |  | Taxes Related to Settlement of Equity Awards |  | Total |
| Q1 2017 | $ | 3,130 |  |  | $ | 6,000 |  |  | $ | 5,000 |  |  | $ | 629 |  |  | $ | 14,759 |  |
| 2016 | 12,150 |  |  | 12,000 |  |  | 17,000 |  |  | 1,570 |  |  | 42,720 |  |
| 2015 | 11,561 |  |  | 6,000 |  |  | 30,026 |  |  | 1,499 |  |  | 49,086 |  |
| 2014 | 11,126 |  |  | 21,000 |  |  | 24,000 |  |  | 1,158 |  |  | 57,284 |  |
| 2013 | 10,564 |  |  | 13,950 |  |  | 9,000 |  |  | 1,082 |  |  | 34,596 |  |
| 2012 | 2,488 |  |  | — |  |  | — |  |  | 56 |  |  | 2,544 |  |
| Total | $ | 51,019 |  |  | $ | 58,950 |  |  | $ | 85,026 |  |  | $ | 5,994 |  |  | $ | 200,989 |  |

[0001628280-17-000717:mdna:119]
[same as prior period, unchanged from 0001628280-16-017809:mdna:117]

[0001628280-17-000717:mdna:120]
[same as prior period, unchanged from 0001628280-16-017809:mdna:118]

[0001628280-17-000717:mdna:121]
[same as prior period, unchanged from 0001628280-16-017809:mdna:119]

[0001628280-17-000717:mdna:122]
[same as prior period, unchanged from 0001628280-16-017809:mdna:120]

[0001628280-17-000717:mdna:123]
As of December 31, 2016, the Company’s total future minimum lease payments under noncancelable operating leases were $7.5 billion. The Company’s retail store and other facility leases are typically for terms not exceeding 10 years and generally contain multi-year renewal options.

[0001628280-17-000717:mdna:124]
Manufacturing Purchase Obligations

[0001628280-17-000717:mdna:125]
The Company utilizes several outsourcing partners to manufacture sub-assemblies for the Company’s products and to perform final assembly and testing of finished products. These outsourcing partners acquire components and build product based on demand information supplied by the Company, which typically covers periods up to 150 days. The Company also obtains individual components for its products from a wide variety of individual suppliers. Consistent with industry practice, the Company acquires components through a combination of purchase orders, supplier contracts, and open orders based on projected demand information. As of December 31, 2016, the Company had manufacturing purchase obligations of $24.0 billion.

[0001628280-17-000717:mdna:126]
Other Purchase Obligations

[0001628280-17-000717:mdna:127]
The Company’s other purchase obligations were comprised of commitments to acquire capital assets, including product tooling and manufacturing process equipment, and commitments related to advertising, licensing, R&D, internet and telecommunications services, energy and other obligations. As of December 31, 2016, the Company had other purchase obligations of $6.7 billion.

[0001628280-17-000717:mdna:128]
The Company’s other non-current liabilities in the Condensed Consolidated Balance Sheets consist primarily of deferred tax liabilities, gross unrecognized tax benefits and the related gross interest and penalties. As of December 31, 2016, the Company had non-current deferred tax liabilities of $26.9 billion, gross unrecognized tax benefits of $8.5 billion and an additional $1.2 billion for gross interest and penalties.

[0001628280-17-000717:mdna:129]
[same as prior period, unchanged from 0001628280-16-017809:mdna:127]

[0001628280-17-000717:mdna:130]
[same as prior period, unchanged from 0001628280-16-017809:mdna:128]

[0001628280-17-000717:mdna:131]
The Company offers an iPhone Upgrade Program, which is available to customers who purchase a qualifying iPhone in the U.S., the U.K. and mainland China. The iPhone Upgrade Program provides customers the right to trade in that iPhone for a specified amount when purchasing a new iPhone, provided certain conditions are met. The Company accounts for the trade-in right as a guarantee liability and recognizes arrangement revenue net of the fair value of such right with subsequent changes to the guarantee liability recognized within revenue.

[0001628280-17-000717:mdna:132]
The Company has entered into indemnification agreements with its directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, the Company maintains directors and officers liability insurance coverage to reduce its exposure to such obligations.

[0001628280-17-000717:mdna:133]
[same as prior period, unchanged from 0001628280-16-017809:mdna:131]

[0001628280-17-000717:mdna:134]
[same as prior period, unchanged from 0001628280-16-017809:mdna:132]

[0001628280-17-000717:mdna:135]
Note 1, “Summary of Significant Accounting Policies” in Part I, Item 1 of this Form 10-Q and in the Notes to Consolidated Financial Statements in Part II, Item 8 of the 2016 Form 10-K, and “Critical Accounting Policies and Estimates” in Part I, Item 7 of the 2016 Form 10-K describe the significant accounting policies and methods used in the preparation of the Company’s condensed consolidated financial statements. There have been no material changes to the Company’s critical accounting policies and estimates since the 2016 Form 10-K.
