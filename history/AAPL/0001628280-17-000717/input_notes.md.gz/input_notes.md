# AAPL notes — 0001628280-17-000717


## aapl:CommercialPaperCashFlowSummaryTableTextBlock

[0001628280-17-000717:notes:1]
The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the three months ended December 31, 2016 and December 26, 2015 (in millions):

[0001628280-17-000717:notes:2]
|  | Three Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |
| Maturities less than 90 days: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | 1,550 |  |  | $ | (393 | ) |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 2,544 |  |  | 492 |  |
| Repayments of commercial paper | (1,709 | ) |  | (1,339 | ) |
| Proceeds from/(Repayments of) commercial paper, net | 835 |  |  | (847 | ) |
| Total change in commercial paper, net | $ | 2,385 |  |  | $ | (1,240 | ) |


## aapl:NotionalAndCreditRiskAmountsOfOutstandingDerivativePositionsDisclosureTextBlock

[0001628280-17-000717:notes:3]
The following table shows the notional amounts of the Company’s outstanding derivative instruments and credit risk amounts associated with outstanding or unsettled derivative instruments as of December 31, 2016 and September 24, 2016 (in millions):

[0001628280-17-000717:notes:4]
|  | December 31, 2016 |  | September 24, 2016 |
|  | NotionalAmount |  | Credit RiskAmount |  | NotionalAmount |  | Credit RiskAmount |
| Instruments designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 40,526 |  |  | $ | 1,453 |  |  | $ | 44,678 |  |  | $ | 518 |  |
| Interest rate contracts | $ | 24,500 |  |  | $ | 186 |  |  | $ | 24,500 |  |  | $ | 728 |  |
| Instruments not designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 57,144 |  |  | $ | 1,104 |  |  | $ | 54,305 |  |  | $ | 153 |  |


## aapl:ScheduleOfCommonStockRepurchasedTableTextBlock

[0001628280-17-000717:notes:5]
[same as prior period, unchanged from 0001628280-16-017809:notes:5]

[0001628280-17-000717:notes:6]
|  | Number of Shares(in thousands) |  | Average Repurchase Price Per Share |  | Amount(in millions) |
| 2017: |  |  |  |  |  |
| First quarter | 44,333 |  |  | $ | 112.78 |  |  | $ | 5,000 |  |
| 2016: |  |  |  |  |  |
| Fourth quarter | 28,579 |  |  | $ | 104.97 |  |  | $ | 3,000 |  |
| Third quarter | 41,238 |  |  | $ | 97.00 |  |  | 4,000 |  |
| Second quarter | 71,766 |  |  | $ | 97.54 |  |  | 7,000 |  |
| First quarter | 25,984 |  |  | $ | 115.45 |  |  | 3,000 |  |
| Total open market common stock repurchases | 167,567 |  |  |  |  | $ | 17,000 |  |


## us-gaap:AcceleratedShareRepurchasesTextBlock

[0001628280-17-000717:notes:7]
The following table shows the Company’s ASR activity and related information during the three months ended December 31, 2016 and the year ended September 24, 2016:

[0001628280-17-000717:notes:8]
|  | Purchase PeriodEnd Date |  | Number of Shares(in thousands) |  | Average RepurchasePrice Per Share |  | ASR Amount(in millions) |
| November 2016 ASR | February 2017 |  | 44,814 |  | (1) | (1) |  |  | $ | 6,000 |  |
| August 2016 ASR | November 2016 |  | 26,850 |  | (2) | $ | 111.73 |  |  | $ | 3,000 |  |
| May 2016 ASR | August 2016 |  | 60,452 |  |  | $ | 99.25 |  |  | $ | 6,000 |  |
| November 2015 ASR | April 2016 |  | 29,122 |  |  | $ | 103.02 |  |  | $ | 3,000 |  |

[0001628280-17-000717:notes:9]
| (1) | “Number of Shares” represents those shares delivered in the beginning of the purchase period and does not represent the final number of shares to be delivered under the ASR. The total number of shares ultimately delivered, and therefore the average repurchase price paid per share, will be determined at the end of the purchase period based on the volume-weighted average price of the Company’s common stock during that period. The November 2016 ASR purchase period will end in February 2017. |

[0001628280-17-000717:notes:10]
| (2) | Includes 22.5 million shares delivered and retired at the beginning of the purchase period, which began in the fourth quarter of 2016 and 4.4 million shares delivered and retired at the end of the purchase period, which concluded in the first quarter of 2017. |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001628280-17-000717:notes:11]
[same as prior period, unchanged from 0001628280-16-017809:notes:11]

[0001628280-17-000717:notes:12]
The following tables show the Company’s condensed consolidated financial statement details as of December 31, 2016 and September 24, 2016 (in millions):

[0001628280-17-000717:notes:13]
[same as prior period, unchanged from 0001628280-16-017809:notes:13]

[0001628280-17-000717:notes:14]
|  | December 31, 2016 |  | September 24, 2016 |
| Land and buildings | $ | 10,932 |  |  | $ | 10,185 |  |
| Machinery, equipment and internal-use software | 45,309 |  |  | 44,543 |  |
| Leasehold improvements | 6,518 |  |  | 6,517 |  |
| Gross property, plant and equipment | 62,759 |  |  | 61,245 |  |
| Accumulated depreciation and amortization | (36,249 | ) |  | (34,235 | ) |
| Total property, plant and equipment, net | $ | 26,510 |  |  | $ | 27,010 |  |

[0001628280-17-000717:notes:15]
[same as prior period, unchanged from 0001628280-16-017809:notes:15]

[0001628280-17-000717:notes:16]
|  | December 31, 2016 |  | September 24, 2016 |
| Deferred tax liabilities | $ | 26,948 |  |  | $ | 26,019 |  |
| Other non-current liabilities | 10,953 |  |  | 10,055 |  |
| Total other non-current liabilities | $ | 37,901 |  |  | $ | 36,074 |  |

[0001628280-17-000717:notes:17]
[same as prior period, unchanged from 0001628280-16-017809:notes:17]

[0001628280-17-000717:notes:18]
The following table shows the detail of other income/(expense), net for the three months ended December 31, 2016 and December 26, 2015 (in millions):

[0001628280-17-000717:notes:19]
|  | Three Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |
| Interest and dividend income | $ | 1,224 |  |  | $ | 941 |  |
| Interest expense | (525 | ) |  | (276 | ) |
| Other income/(expense), net | 122 |  |  | (263 | ) |
| Total other income/(expense), net | $ | 821 |  |  | $ | 402 |  |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001628280-17-000717:notes:20]
The following tables show the Company’s cash and available-for-sale securities’ adjusted cost, gross unrealized gains, gross unrealized losses and fair value by significant investment category recorded as cash and cash equivalents or short- or long-term marketable securities as of December 31, 2016 and September 24, 2016 (in millions):

[0001628280-17-000717:notes:21]
|  | December 31, 2016 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | Short-TermMarketableSecurities |  | Long-TermMarketableSecurities |
| Cash | $ | 9,359 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,359 |  |  | $ | 9,359 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 4,640 |  |  | — |  |  | — |  |  | 4,640 |  |  | 4,640 |  |  | — |  |  | — |  |
| Mutual funds | 1,004 |  |  | — |  |  | (137 | ) |  | 867 |  |  | — |  |  | 867 |  |  | — |  |
| Subtotal | 5,644 |  |  | — |  |  | (137 | ) |  | 5,507 |  |  | 4,640 |  |  | 867 |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 48,431 |  |  | 47 |  |  | (333 | ) |  | 48,145 |  |  | 1,022 |  |  | 13,074 |  |  | 34,049 |  |
| U.S. agency securities | 4,284 |  |  | 4 |  |  | (10 | ) |  | 4,278 |  |  | 404 |  |  | 1,999 |  |  | 1,875 |  |
| Non-U.S. government securities | 7,574 |  |  | 79 |  |  | (136 | ) |  | 7,517 |  |  | — |  |  | 408 |  |  | 7,109 |  |
| Certificates of deposit and time deposits | 5,893 |  |  | — |  |  | — |  |  | 5,893 |  |  | 334 |  |  | 4,089 |  |  | 1,470 |  |
| Commercial paper | 3,750 |  |  | — |  |  | — |  |  | 3,750 |  |  | 536 |  |  | 3,214 |  |  | — |  |
| Corporate securities | 140,697 |  |  | 469 |  |  | (737 | ) |  | 140,429 |  |  | 76 |  |  | 20,283 |  |  | 120,070 |  |
| Municipal securities | 955 |  |  | — |  |  | (9 | ) |  | 946 |  |  | — |  |  | 111 |  |  | 835 |  |
| Mortgage- and asset-backed securities | 20,486 |  |  | 23 |  |  | (243 | ) |  | 20,266 |  |  | — |  |  | 36 |  |  | 20,230 |  |
| Subtotal | 232,070 |  |  | 622 |  |  | (1,468 | ) |  | 231,224 |  |  | 2,372 |  |  | 43,214 |  |  | 185,638 |  |
| Total | $ | 247,073 |  |  | $ | 622 |  |  | $ | (1,605 | ) |  | $ | 246,090 |  |  | $ | 16,371 |  |  | $ | 44,081 |  |  | $ | 185,638 |  |

[0001628280-17-000717:notes:22]
|  | September 24, 2016 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | Short-TermMarketableSecurities |  | Long-TermMarketableSecurities |
| Cash | $ | 8,601 |  |  | $ | — |  |  | $ | — |  |  | $ | 8,601 |  |  | $ | 8,601 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 3,666 |  |  | — |  |  | — |  |  | 3,666 |  |  | 3,666 |  |  | — |  |  | — |  |
| Mutual funds | 1,407 |  |  | — |  |  | (146 | ) |  | 1,261 |  |  | — |  |  | 1,261 |  |  | — |  |
| Subtotal | 5,073 |  |  | — |  |  | (146 | ) |  | 4,927 |  |  | 3,666 |  |  | 1,261 |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 41,697 |  |  | 319 |  |  | (4 | ) |  | 42,012 |  |  | 1,527 |  |  | 13,492 |  |  | 26,993 |  |
| U.S. agency securities | 7,543 |  |  | 16 |  |  | — |  |  | 7,559 |  |  | 2,762 |  |  | 2,441 |  |  | 2,356 |  |
| Non-U.S. government securities | 7,609 |  |  | 259 |  |  | (27 | ) |  | 7,841 |  |  | 110 |  |  | 818 |  |  | 6,913 |  |
| Certificates of deposit and time deposits | 6,598 |  |  | — |  |  | — |  |  | 6,598 |  |  | 1,108 |  |  | 3,897 |  |  | 1,593 |  |
| Commercial paper | 7,433 |  |  | — |  |  | — |  |  | 7,433 |  |  | 2,468 |  |  | 4,965 |  |  | — |  |
| Corporate securities | 131,166 |  |  | 1,409 |  |  | (206 | ) |  | 132,369 |  |  | 242 |  |  | 19,599 |  |  | 112,528 |  |
| Municipal securities | 956 |  |  | 5 |  |  | — |  |  | 961 |  |  | — |  |  | 167 |  |  | 794 |  |
| Mortgage- and asset-backed securities | 19,134 |  |  | 178 |  |  | (28 | ) |  | 19,284 |  |  | — |  |  | 31 |  |  | 19,253 |  |
| Subtotal | 222,136 |  |  | 2,186 |  |  | (265 | ) |  | 224,057 |  |  | 8,217 |  |  | 45,410 |  |  | 170,430 |  |
| Total | $ | 235,810 |  |  | $ | 2,186 |  |  | $ | (411 | ) |  | $ | 237,585 |  |  | $ | 20,484 |  |  | $ | 46,671 |  |  | $ | 170,430 |  |

[0001628280-17-000717:notes:23]
| (1) | Level 1 fair value estimates are based on quoted prices in active markets for identical assets or liabilities. |

[0001628280-17-000717:notes:24]
| (2) | Level 2 fair value estimates are based on observable inputs other than quoted prices in active markets for identical assets and liabilities, quoted prices for identical or similar assets or liabilities in inactive markets, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities. |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001628280-17-000717:notes:25]
[same as prior period, unchanged from 0001628280-16-017809:notes:25]

[0001628280-17-000717:notes:26]
The accompanying condensed consolidated financial statements include the accounts of the Company. Intercompany accounts and transactions have been eliminated. In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements in conformity with U.S. generally accepted accounting principles (“GAAP”) requires management to make estimates and assumptions that affect the amounts reported in these condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. Certain prior period amounts in the condensed consolidated financial statements have been reclassified to conform to the current period’s presentation. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company's annual consolidated financial statements and the notes thereto included in its Annual Report on Form 10-K for the fiscal year ended September 24, 2016 (the “2016 Form 10-K”).


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001628280-17-000717:notes:27]
[same as prior period, unchanged from 0001628280-16-017809:notes:27]

[0001628280-17-000717:notes:28]
Apple Inc. and its wholly-owned subsidiaries (collectively “Apple” or the “Company”) designs, manufactures and markets mobile communication and media devices, personal computers and portable digital music players, and sells a variety of related software, services, accessories, networking solutions and third-party digital content and applications. The Company’s products and services include iPhone®, iPad®, Mac®, iPod®, Apple Watch®, Apple TV®, a portfolio of consumer and professional software applications, iOS, macOS™, watchOS® and tvOS™ operating systems, iCloud®, Apple Pay® and a variety of accessory, service and support offerings. The Company sells and delivers digital content and applications through the iTunes Store®, App Store®, Mac App Store, TV App Store, iBooks Store™ and Apple Music® (collectively “Digital Content and Services”). The Company sells its products worldwide through its retail stores, online stores and direct sales force, as well as through third-party cellular network carriers, wholesalers, retailers and value-added resellers. In addition, the Company sells a variety of third-party Apple-compatible products, including application software and various accessories through its retail and online stores. The Company sells to consumers, small and mid-sized businesses and education, enterprise and government customers.

[0001628280-17-000717:notes:29]
The Company’s fiscal year is the 52 or 53-week period that ends on the last Saturday of September. The Company’s fiscal year 2017 will include 53 weeks and ends on September 30, 2017 and its fiscal year 2016 included 52 weeks and ended on September 24, 2016. A 14th week has been included in the first quarter of 2017, as is done every five or six years, to realign fiscal quarters with calendar quarters. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in September and the associated quarters, months and periods of those fiscal years.

[0001628280-17-000717:notes:30]
[same as prior period, unchanged from 0001628280-16-017809:notes:31]

[0001628280-17-000717:notes:31]
Basic earnings per share is computed by dividing income available to common shareholders by the weighted-average number of shares of common stock outstanding during the period. Diluted earnings per share is computed by dividing income available to common shareholders by the weighted-average number of shares of common stock outstanding during the period increased to include the number of additional shares of common stock that would have been outstanding if the potentially dilutive securities had been issued. Potentially dilutive securities include outstanding stock options, shares to be purchased by employees under the Company’s employee stock purchase plan, unvested restricted stock and unvested restricted stock units (“RSUs”). The dilutive effect of potentially dilutive securities is reflected in diluted earnings per share by application of the treasury stock method. Under the treasury stock method, an increase in the fair market value of the Company’s common stock can result in a greater dilutive effect from potentially dilutive securities.

[0001628280-17-000717:notes:32]
The following table shows the computation of basic and diluted earnings per share for the three months ended December 31, 2016 and December 26, 2015 (net income in millions and shares in thousands):

[0001628280-17-000717:notes:33]
|  | Three Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |
| Numerator: |  |  |  |
| Net income | $ | 17,891 |  |  | $ | 18,361 |  |
| Denominator: |  |  |  |
| Weighted-average shares outstanding | 5,298,661 |  |  | 5,558,930 |  |
| Effect of dilutive securities | 29,334 |  |  | 35,197 |  |
| Weighted-average diluted shares | 5,327,995 |  |  | 5,594,127 |  |
| Basic earnings per share | $ | 3.38 |  |  | $ | 3.30 |  |
| Diluted earnings per share | $ | 3.36 |  |  | $ | 3.28 |  |

[0001628280-17-000717:notes:34]
[same as prior period, unchanged from 0001628280-16-017809:notes:35]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-17-000717:notes:35]
Commitments and Contingencies

[0001628280-17-000717:notes:36]
Accrued Warranty and Indemnification

[0001628280-17-000717:notes:37]
The following table shows changes in the Company’s accrued warranties and related costs for the three months ended December 31, 2016 and December 26, 2015 (in millions):

[0001628280-17-000717:notes:38]
|  | Three Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |
| Beginning accrued warranty and related costs | $ | 3,702 |  |  | $ | 4,780 |  |
| Cost of warranty claims | (1,337 | ) |  | (1,269 | ) |
| Accruals for product warranty | 2,333 |  |  | 1,725 |  |
| Ending accrued warranty and related costs | $ | 4,698 |  |  | $ | 5,236 |  |

[0001628280-17-000717:notes:39]
The Company generally does not indemnify end-users of its operating system and application software against legal claims that the software infringes third-party intellectual property rights. Other agreements entered into by the Company sometimes include indemnification provisions under which the Company could be subject to costs and/or damages in the event of an infringement claim against the Company or an indemnified third-party. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss with respect to indemnification of end-users of its operating system or application software for infringement of third-party intellectual property rights.

[0001628280-17-000717:notes:40]
The Company offers an iPhone Upgrade Program, which is available to customers who purchase a qualifying iPhone in the U.S., the U.K. and mainland China. The iPhone Upgrade Program provides customers the right to trade in that iPhone for a specified amount when purchasing a new iPhone, provided certain conditions are met. The Company accounts for the trade-in right as a guarantee liability and recognizes arrangement revenue net of the fair value of such right with subsequent changes to the guarantee liability recognized within revenue.

[0001628280-17-000717:notes:41]
The Company has entered into indemnification agreements with its directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, the Company maintains directors and officers liability insurance coverage to reduce its exposure to such obligations.

[0001628280-17-000717:notes:42]
Concentrations in the Available Sources of Supply of Materials and Product

[0001628280-17-000717:notes:43]
Although most components essential to the Company’s business are generally available from multiple sources, a number of components are currently obtained from single or limited sources. In addition, the Company competes for various components with other participants in the markets for mobile communication and media devices and personal computers. Therefore, many components used by the Company, including those that are available from multiple sources, are at times subject to industry-wide shortage and significant pricing fluctuations that could materially adversely affect the Company’s financial condition and operating results.

[0001628280-17-000717:notes:44]
The Company uses some custom components that are not commonly used by its competitors, and new products introduced by the Company often utilize custom components available from only one source. When a component or product uses new technologies, initial capacity constraints may exist until the suppliers’ yields have matured or manufacturing capacity has increased. If the Company’s supply of components for a new or existing product were delayed or constrained, or if an outsourcing partner delayed shipments of completed products to the Company, the Company’s financial condition and operating results could be materially adversely affected. The Company’s business and financial performance could also be materially adversely affected depending on the time required to obtain sufficient quantities from the original source, or to identify and obtain sufficient quantities from an alternative source. Continued availability of these components at acceptable prices, or at all, may be affected if those suppliers concentrated on the production of common components instead of components customized to meet the Company’s requirements.

[0001628280-17-000717:notes:45]
The Company has entered into agreements for the supply of many components; however, there can be no guarantee that the Company will be able to extend or renew these agreements on similar terms, or at all. Therefore, the Company remains subject to significant risks of supply shortages and price increases that could materially adversely affect its financial condition and operating results.

[0001628280-17-000717:notes:46]
Substantially all of the Company’s hardware products are manufactured by outsourcing partners that are located primarily in Asia. A significant concentration of this manufacturing is currently performed by a small number of outsourcing partners, often in single locations. Certain of these outsourcing partners are the sole-sourced suppliers of components and manufacturers for many of the Company’s products. Although the Company works closely with its outsourcing partners on manufacturing schedules, the Company’s operating results could be adversely affected if its outsourcing partners were unable to meet their production commitments. The Company’s manufacturing purchase obligations typically cover its requirements for periods up to 150 days.

[0001628280-17-000717:notes:47]
Other Off-Balance Sheet Commitments

[0001628280-17-000717:notes:48]
Operating Leases

[0001628280-17-000717:notes:49]
The Company leases various equipment and facilities, including retail space, under noncancelable operating lease arrangements. The Company does not currently utilize any other off-balance sheet financing arrangements. As of December 31, 2016, the Company’s total future minimum lease payments under noncancelable operating leases were $7.5 billion. The Company's retail store and other facility leases are typically for terms not exceeding 10 years and generally contain multi-year renewal options.

[0001628280-17-000717:notes:50]
Contingencies

[0001628280-17-000717:notes:51]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully adjudicated, as further discussed in Part II, Item 1 of this Form 10-Q under the heading “Legal Proceedings” and in Part II, Item 1A of this Form 10-Q under the heading “Risk Factors.” In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to loss contingencies for asserted legal and other claims. However, the outcome of litigation is inherently uncertain. Therefore, although management considers the likelihood of such an outcome to be remote, if one or more of these legal matters were resolved against the Company in a reporting period for amounts in excess of management’s expectations, the Company’s consolidated financial statements for that reporting period could be materially adversely affected.

[0001628280-17-000717:notes:52]
Apple Inc. v. Samsung Electronics Co., Ltd., et al.

[0001628280-17-000717:notes:53]
On August 24, 2012, a jury returned a verdict awarding the Company $1.05 billion in its lawsuit against Samsung Electronics Co., Ltd. and affiliated parties in the United States District Court, Northern District of California, San Jose Division. On March 6, 2014, the District Court entered final judgment in favor of the Company in the amount of approximately $930 million. On May 18, 2015, the U.S. Court of Appeals for the Federal Circuit affirmed in part, and reversed in part, the decision of the District Court. As a result, the Court of Appeals ordered entry of final judgment on damages in the amount of approximately $548 million, with the District Court to determine supplemental damages and interest, as well as damages owed for products subject to the reversal in part. Samsung paid $548 million to the Company in December 2015, which was included in net sales in the Condensed Consolidated Statement of Operations. On December 6, 2016, the U.S. Supreme Court remanded the case to the U.S. Court of Appeals for the Federal Circuit for further proceedings related to the $548 million in damages. Because the case remains subject to further proceedings, the Company has not recognized any further amounts in its results of operations.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001628280-17-000717:notes:54]
[same as prior period, unchanged from 0001628280-16-017809:notes:55]

[0001628280-17-000717:notes:55]
[same as prior period, unchanged from 0001628280-16-017809:notes:56]

[0001628280-17-000717:notes:56]
The Company had 316.4 million shares reserved for future issuance under its stock plans as of December 31, 2016. RSUs granted generally vest over four years, based on continued employment, and are settled upon vesting in shares of the Company’s common stock on a one-for-one basis. Each share issued with respect to RSUs granted under the Company’s stock plans reduces the number of shares available for grant under the plan by two shares. RSUs cancelled and shares withheld to satisfy tax withholding obligations increase the number of shares available for grant under the plans utilizing a factor of two times the number of RSUs cancelled or shares withheld.

[0001628280-17-000717:notes:57]
[same as prior period, unchanged from 0001628280-16-017809:notes:58]

[0001628280-17-000717:notes:58]
During the three months ended December 31, 2016, Section 16 officers Timothy D. Cook, Luca Maestri, Daniel Riccio, Philip Schiller and Jeffrey Williams had equity trading plans in place in accordance with Rule 10b5-1(c)(1) under the Exchange Act. An equity trading plan is a written document that pre-establishes the amounts, prices and dates (or formula for determining the amounts, prices and dates) of future purchases or sales of the Company’s stock, including shares acquired pursuant to the Company’s employee and director equity plans.

[0001628280-17-000717:notes:59]
[same as prior period, unchanged from 0001628280-16-017809:notes:60]

[0001628280-17-000717:notes:60]
A summary of the Company’s RSU activity and related information for the three months ended December 31, 2016 is as follows:

[0001628280-17-000717:notes:61]
|  | Number ofRSUs(in thousands) |  | Weighted-AverageGrant Date FairValue Per Share |  | Aggregate Fair Value(in millions) |
| Balance at September 24, 2016 | 99,089 |  |  | $ | 97.54 |  |  |  |
| RSUs granted | 42,882 |  |  | $ | 117.95 |  |  |  |
| RSUs vested | (18,535 | ) |  | $ | 92.65 |  |  |  |
| RSUs cancelled | (1,577 | ) |  | $ | 105.01 |  |  |  |
| Balance at December 31, 2016 | 121,859 |  |  | $ | 105.37 |  |  | $ | 14,114 |  |

[0001628280-17-000717:notes:62]
RSUs that vested during the three months ended December 31, 2016 and December 26, 2015 had fair values of $2.2 billion and $2.0 billion, respectively, as of the vesting date.

[0001628280-17-000717:notes:63]
[same as prior period, unchanged from 0001628280-16-017809:notes:66]

[0001628280-17-000717:notes:64]
The following table shows a summary of the share-based compensation expense included in the Condensed Consolidated Statements of Operations for the three months ended December 31, 2016 and December 26, 2015 (in millions):

[0001628280-17-000717:notes:65]
|  | Three Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |
| Cost of sales | $ | 229 |  |  | $ | 204 |  |
| Research and development | 589 |  |  | 466 |  |
| Selling, general and administrative | 438 |  |  | 408 |  |
| Total share-based compensation expense | $ | 1,256 |  |  | $ | 1,078 |  |

[0001628280-17-000717:notes:66]
The income tax benefit related to share-based compensation expense was $465 million and $413 million for the three months ended December 31, 2016 and December 26, 2015, respectively. As of December 31, 2016, the total unrecognized compensation cost related to outstanding RSUs, restricted stock and stock options was $11.0 billion, which the Company expects to recognize over a weighted-average period of 2.9 years.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-17-000717:notes:67]
[same as prior period, unchanged from 0001628280-16-017809:notes:70]

[0001628280-17-000717:notes:68]
[same as prior period, unchanged from 0001628280-16-017809:notes:71]

[0001628280-17-000717:notes:69]
The following table shows the pre-tax amounts reclassified from AOCI into the Condensed Consolidated Statements of Operations, and the associated financial statement line item, for the three months ended December 31, 2016 and December 26, 2015 (in millions):

[0001628280-17-000717:notes:70]
|  |  |  |  | Three Months Ended |
| Comprehensive Income Components |  | Financial Statement Line Item |  | December 31, 2016 |  | December 26, 2015 |
| Unrealized (gains)/losses on derivative instruments: |  |  |  |  |  |  |
| Foreign exchange contracts |  | Revenue |  | $ | (101 | ) |  | $ | (329 | ) |
|  |  | Cost of sales |  | 13 |  |  | (306 | ) |
|  |  | Other income/(expense), net |  | 604 |  |  | 120 |  |
| Interest rate contracts |  | Other income/(expense), net |  | 1 |  |  | 4 |  |
|  |  |  |  | 517 |  |  | (511 | ) |
| Unrealized (gains)/losses on marketable securities |  | Other income/(expense), net |  | 31 |  |  | 73 |  |
| Total amounts reclassified from AOCI |  | $ | 548 |  |  | $ | (438 | ) |

[0001628280-17-000717:notes:71]
The following table shows the changes in AOCI by component for the three months ended December 31, 2016 (in millions):

[0001628280-17-000717:notes:72]
|  | Cumulative ForeignCurrency Translation |  | Unrealized Gains/Losseson Derivative Instruments |  | Unrealized Gains/Losseson Marketable Securities |  | Total |
| Balance at September 24, 2016 | $ | (578 | ) |  | $ | 38 |  |  | $ | 1,174 |  |  | $ | 634 |  |
| Other comprehensive income/(loss) before reclassifications | (451 | ) |  | 1,696 |  |  | (2,797 | ) |  | (1,552 | ) |
| Amounts reclassified from AOCI | — |  |  | 517 |  |  | 31 |  |  | 548 |  |
| Tax effect | 76 |  |  | (439 | ) |  | 978 |  |  | 615 |  |
| Other comprehensive income/(loss) | (375 | ) |  | 1,774 |  |  | (1,788 | ) |  | (389 | ) |
| Balance at December 31, 2016 | $ | (953 | ) |  | $ | 1,812 |  |  | $ | (614 | ) |  | $ | 245 |  |


## us-gaap:DebtDisclosureTextBlock

[0001628280-17-000717:notes:73]
Debt

[0001628280-17-000717:notes:74]
Commercial Paper

[0001628280-17-000717:notes:75]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of December 31, 2016 and September 24, 2016, the Company had $10.5 billion and $8.1 billion of Commercial Paper outstanding, respectively, with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 0.61% as of December 31, 2016 and 0.45% as of September 24, 2016.

[0001628280-17-000717:notes:76]
Long-Term Debt

[0001628280-17-000717:notes:77]
As of December 31, 2016, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $77.4 billion (collectively the “Notes”). The Notes are senior unsecured obligations, and interest is payable in arrears, quarterly for the U.S. dollar-denominated and Australian dollar-denominated floating-rate notes, semi-annually for the U.S. dollar-denominated, Australian dollar-denominated, British pound-denominated and Japanese yen-denominated fixed-rate notes and annually for the euro-denominated and Swiss franc-denominated fixed-rate notes. The following table provides a summary of the Company’s term debt as of December 31, 2016 and September 24, 2016:

[0001628280-17-000717:notes:78]
|  | Maturities |  | December 31, 2016 |  | September 24, 2016 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2018 |  | $ | 2,000 |  |  | 1.10% |  | $ | 2,000 |  |  | 1.10% |
| Fixed-rate 1.000% - 3.850% notes | 2018 - 2043 |  | 12,500 |  |  | 1.08% - 3.91% |  | 12,500 |  |  | 1.08% - 3.91% |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2017 - 2019 |  | 2,000 |  |  | 0.95% - 1.18% |  | 2,000 |  |  | 0.86% - 1.09% |
| Fixed-rate 1.050% - 4.450% notes | 2017 - 2044 |  | 10,000 |  |  | 0.95% - 4.48% |  | 10,000 |  |  | 0.85% - 4.48% |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2017 - 2020 |  | 1,753 |  |  | 0.95% - 1.87% |  | 1,781 |  |  | 0.87% - 1.87% |
| Fixed-rate 0.350% - 4.375% notes | 2017 - 2045 |  | 24,225 |  |  | 0.28% - 4.51% |  | 25,144 |  |  | 0.28% - 4.51% |
| 2016 debt issuances of $24.9 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 - 2021 |  | 1,350 |  |  | 1.02% - 2.05% |  | 1,350 |  |  | 0.91% - 1.95% |
| Fixed-rate 1.100% - 4.650% notes | 2018 - 2046 |  | 23,550 |  |  | 1.13% - 4.78% |  | 23,609 |  |  | 1.13% - 4.58% |
| Total term debt |  |  | 77,378 |  |  |  |  | 78,384 |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  | (166 | ) |  |  |  | (174 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | (156 | ) |  |  |  | 717 |  |  |  |
| Less: Current portion of long-term debt |  |  | (3,499 | ) |  |  |  | (3,500 | ) |  |  |
| Total long-term debt |  |  | $ | 73,557 |  |  |  |  | $ | 75,427 |  |  |  |

[0001628280-17-000717:notes:79]
As of December 31, 2016 and September 24, 2016, ¥90.4 billion and ¥195.5 billion, respectively, of Japanese yen-denominated notes were designated as a hedge of the foreign currency exposure of the Company's net investment in a foreign operation. The foreign currency transaction gain or loss on the Japanese yen-denominated debt designated as a hedge is recorded in OCI as a part of the cumulative translation adjustment. As of December 31, 2016 and September 24, 2016, the carrying value of the debt designated as a net investment hedge was $767 million and $1.9 billion, respectively. For further discussion regarding the Company’s use of derivative instruments see the Derivative Financial Instruments section of Note 2, “Financial Instruments.”

[0001628280-17-000717:notes:80]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount and, if applicable, adjustments related to hedging. The Company recognized $509 million and $271 million of interest expense on its term debt for the three months ended December 31, 2016 and December 26, 2015, respectively.

[0001628280-17-000717:notes:81]
As of December 31, 2016 and September 24, 2016, the fair value of the Company’s Notes, based on Level 2 inputs, was $77.7 billion and $81.7 billion, respectively.


## us-gaap:DerivativesPolicyTextBlock

[0001628280-17-000717:notes:82]
[same as prior period, unchanged from 0001628280-16-017809:notes:102]

[0001628280-17-000717:notes:83]
[same as prior period, unchanged from 0001628280-16-017809:notes:87]

[0001628280-17-000717:notes:84]
[same as prior period, unchanged from 0001628280-16-017809:notes:88]

[0001628280-17-000717:notes:85]
[same as prior period, unchanged from 0001628280-16-017809:notes:89]

[0001628280-17-000717:notes:86]
To help protect the net investment in a foreign operation from adverse changes in foreign currency exchange rates, the Company may enter into foreign currency forward and option contracts to offset the changes in the carrying amounts of these investments due to fluctuations in foreign currency exchange rates. In addition, the Company may use non-derivative financial instruments, such as its foreign currency-denominated debt, as economic hedges of its net investments in certain foreign subsidiaries. In both of these cases, the Company designates these instruments as net investment hedges.

[0001628280-17-000717:notes:87]
[same as prior period, unchanged from 0001628280-16-017809:notes:91]

[0001628280-17-000717:notes:88]
The Company may enter into interest rate swaps, options, or other instruments to manage interest rate risk. These instruments may offset a portion of changes in income or expense, or changes in fair value of the Company’s term debt or investments. The Company designates these instruments as either cash flow or fair value hedges. The Company’s hedged interest rate transactions as of December 31, 2016 are expected to be recognized within 10 years.

[0001628280-17-000717:notes:89]
[same as prior period, unchanged from 0001628280-16-017809:notes:93]

[0001628280-17-000717:notes:90]
[same as prior period, unchanged from 0001628280-16-017809:notes:94]

[0001628280-17-000717:notes:91]
[same as prior period, unchanged from 0001628280-16-017809:notes:95]

[0001628280-17-000717:notes:92]
[same as prior period, unchanged from 0001628280-16-017809:notes:96]

[0001628280-17-000717:notes:93]
[same as prior period, unchanged from 0001628280-16-017809:notes:97]

[0001628280-17-000717:notes:94]
[same as prior period, unchanged from 0001628280-16-017809:notes:98]

[0001628280-17-000717:notes:95]
[same as prior period, unchanged from 0001628280-16-017809:notes:99]

[0001628280-17-000717:notes:96]
[same as prior period, unchanged from 0001628280-16-017809:notes:100]

[0001628280-17-000717:notes:97]
[same as prior period, unchanged from 0001628280-16-017809:notes:101]


## us-gaap:DividendsDeclaredTableTextBlock

[0001628280-17-000717:notes:98]
[same as prior period, unchanged from 0001628280-16-017809:notes:103]

[0001628280-17-000717:notes:99]
|  | DividendsPer Share |  | Amount(in millions) |
| 2017: |  |  |  |
| First quarter | $ | 0.57 |  |  | $ | 3,042 |  |
| 2016: |  |  |  |
| Fourth quarter | $ | 0.57 |  |  | $ | 3,071 |  |
| Third quarter | 0.57 |  |  | 3,117 |  |
| Second quarter | 0.52 |  |  | 2,879 |  |
| First quarter | 0.52 |  |  | 2,898 |  |
| Total cash dividends declared and paid | $ | 2.18 |  |  | $ | 11,965 |  |


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001628280-17-000717:notes:100]
Level 1 fair value estimates are based on quoted prices in active markets for identical assets or liabilities.

[0001628280-17-000717:notes:101]
Level 2 fair value estimates are based on observable inputs other than quoted prices in active markets for identical assets and liabilities, quoted prices for identical or similar assets or liabilities in inactive markets, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001628280-17-000717:notes:102]
[same as prior period, unchanged from 0001628280-16-017809:notes:105]

[0001628280-17-000717:notes:103]
[same as prior period, unchanged from 0001628280-16-017809:notes:106]

[0001628280-17-000717:notes:104]
[same as prior period, unchanged from 0001628280-16-017809:notes:107]

[0001628280-17-000717:notes:105]
The Company considers the declines in market value of its marketable securities investment portfolio to be temporary in nature. The Company typically invests in highly-rated securities, and its investment policy generally limits the amount of credit exposure to any one issuer. The policy generally requires investments to be investment grade, with the primary objective of minimizing the potential risk of principal loss. Fair values were determined for each individual security in the investment portfolio. When evaluating an investment for other-than-temporary impairment the Company reviews factors such as the length of time and extent to which fair value has been below its cost basis, the financial condition of the issuer and any changes thereto, changes in market interest rates and the Company’s intent to sell, or whether it is more likely than not it will be required to sell the investment before recovery of the investment’s cost basis. As of December 31, 2016, the Company does not consider any of its investments to be other-than-temporarily impaired.

[0001628280-17-000717:notes:106]
Derivatives that are not designated as hedging instruments are adjusted to fair value through earnings in the financial statement line item to which the derivative relates. As a result, during the three months ended December 31, 2016, the Company recognized gains in net sales, cost of sales and other income/(expense), net of $273 million, $332 million and $508 million, respectively.

[0001628280-17-000717:notes:107]
The Company records all derivatives in the Condensed Consolidated Balance Sheets at fair value. The Company’s accounting treatment for these derivative instruments is based on its hedge designation. The following tables show the Company’s derivative instruments at gross fair value as of December 31, 2016 and September 24, 2016 (in millions):

[0001628280-17-000717:notes:108]
|  | December 31, 2016 |
|  | Fair Value ofDerivatives Designatedas Hedge Instruments |  | Fair Value ofDerivatives Not Designatedas Hedge Instruments |  | TotalFair Value |
| Derivative assets (1): |  |  |  |  |  |
| Foreign exchange contracts | $ | 1,453 |  |  | $ | 1,104 |  |  | $ | 2,557 |  |
| Interest rate contracts | $ | 186 |  |  | $ | — |  |  | $ | 186 |  |
| Derivative liabilities (2): |  |  |  |  |  |
| Foreign exchange contracts | $ | 977 |  |  | $ | 536 |  |  | $ | 1,513 |  |
| Interest rate contracts | $ | 331 |  |  | $ | — |  |  | $ | 331 |  |

[0001628280-17-000717:notes:109]
|  | September 24, 2016 |
|  | Fair Value ofDerivatives Designatedas Hedge Instruments |  | Fair Value ofDerivatives Not Designatedas Hedge Instruments |  | TotalFair Value |
| Derivative assets (1): |  |  |  |  |  |
| Foreign exchange contracts | $ | 518 |  |  | $ | 153 |  |  | $ | 671 |  |
| Interest rate contracts | $ | 728 |  |  | $ | — |  |  | $ | 728 |  |
| Derivative liabilities (2): |  |  |  |  |  |
| Foreign exchange contracts | $ | 935 |  |  | $ | 134 |  |  | $ | 1,069 |  |
| Interest rate contracts | $ | 7 |  |  | $ | — |  |  | $ | 7 |  |

[0001628280-17-000717:notes:110]
[same as prior period, unchanged from 0001628280-16-017809:notes:112]

[0001628280-17-000717:notes:111]
[same as prior period, unchanged from 0001628280-16-017809:notes:113]

[0001628280-17-000717:notes:112]
The following table shows the pre-tax gains and losses of the Company’s derivative and non-derivative instruments designated as cash flow, net investment and fair value hedges in OCI and the Condensed Consolidated Statements of Operations for the three months ended December 31, 2016 and December 26, 2015 (in millions):

[0001628280-17-000717:notes:113]
|  | Three Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |
| Gains/(Losses) recognized in OCI – effective portion: |  |  |  |
| Cash flow hedges: |  |  |  |
| Foreign exchange contracts | $ | 1,727 |  |  | $ | 326 |  |
| Interest rate contracts | 7 |  |  | 8 |  |
| Total | $ | 1,734 |  |  | $ | 334 |  |
| Net investment hedges: |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | — |  |
| Foreign currency debt | 122 |  |  | 10 |  |
| Total | $ | 122 |  |  | $ | 10 |  |
| Gains/(Losses) reclassified from AOCI into net income – effective portion: |  |  |  |
| Cash flow hedges: |  |  |  |
| Foreign exchange contracts | $ | (511 | ) |  | $ | 515 |  |
| Interest rate contracts | (1 | ) |  | (4 | ) |
| Total | $ | (512 | ) |  | $ | 511 |  |
| Gains/(Losses) on derivative instruments: |  |  |  |
| Fair value hedges: |  |  |  |
| Interest rate contracts | $ | (872 | ) |  | $ | (111 | ) |
| Gains/(Losses) related to hedged items: |  |  |  |
| Fair value hedges: |  |  |  |
| Interest rate contracts | $ | 872 |  |  | $ | 111 |  |

[0001628280-17-000717:notes:114]
[same as prior period, unchanged from 0001628280-16-017809:notes:116]

[0001628280-17-000717:notes:115]
The Company generally enters into master netting arrangements, which are designed to reduce credit risk by permitting net settlement of transactions with the same counterparty. To further limit credit risk, the Company generally enters into collateral security arrangements that provide for collateral to be received or posted when the net fair value of certain financial instruments fluctuates from contractually established thresholds. The Company presents its derivative assets and derivative liabilities at their gross fair values in its Condensed Consolidated Balance Sheets. The net cash collateral received by the Company related to derivative instruments under its collateral security arrangements was $1.1 billion as of December 31, 2016 and $163 million as of September 24, 2016, which were recorded as accrued expenses in the Condensed Consolidated Balance Sheets.

[0001628280-17-000717:notes:116]
Under master netting arrangements with the respective counterparties to the Company’s derivative contracts, the Company is allowed to net settle transactions with a single net amount payable by one party to the other. As of December 31, 2016 and September 24, 2016, the potential effects of these rights of set-off associated with the Company’s derivative contracts, including the effects of collateral, would be a reduction to both derivative assets and derivative liabilities of $2.7 billion and $1.5 billion, respectively, resulting in a net derivative liability of $222 million and a net derivative asset of $160 million, respectively.

[0001628280-17-000717:notes:117]
[same as prior period, unchanged from 0001628280-16-017809:notes:119]

[0001628280-17-000717:notes:118]
[same as prior period, unchanged from 0001628280-16-017809:notes:120]

[0001628280-17-000717:notes:119]
The Company has considerable trade receivables outstanding with its third-party cellular network carriers, wholesalers, retailers, value-added resellers, small and mid-sized businesses and education, enterprise and government customers. The Company generally does not require collateral from its customers; however, the Company will require collateral in certain instances to limit credit risk. In addition, when possible, the Company attempts to limit credit risk on trade receivables with credit insurance for certain customers or by requiring third-party financing, loans or leases to support credit exposure. These credit-financing arrangements are directly between the third-party financing company and the end customer. As such, the Company generally does not assume any recourse or credit risk sharing related to any of these arrangements.

[0001628280-17-000717:notes:120]
As of December 31, 2016 and September 24, 2016, the Company had one customer that represented 10% or more of total trade receivables, which accounted for 11% and 10%, respectively. The Company’s cellular network carriers accounted for 55% and 63% of trade receivables as of December 31, 2016 and September 24, 2016, respectively.

[0001628280-17-000717:notes:121]
[same as prior period, unchanged from 0001628280-16-017809:notes:122]

[0001628280-17-000717:notes:122]
The Company has non-trade receivables from certain of its manufacturing vendors resulting from the sale of components to these vendors who manufacture sub-assemblies or assemble final products for the Company. The Company purchases these components directly from suppliers. Vendor non-trade receivables from three of the Company’s vendors accounted for 49%, 14% and 13% of total vendor non-trade receivables as of December 31, 2016, and two of the Company’s vendors accounted for 47% and 21% of total vendor non-trade receivables as of September 24, 2016.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-17-000717:notes:123]
[same as prior period, unchanged from 0001628280-16-017809:notes:124]

[0001628280-17-000717:notes:124]
As of December 31, 2016, the Company recorded gross unrecognized tax benefits of $8.5 billion, of which $3.0 billion, if recognized, would affect the Company’s effective tax rate. As of September 24, 2016, the total amount of gross unrecognized tax benefits was $7.7 billion, of which $2.8 billion, if recognized, would have affected the Company’s effective tax rate. The Company’s total gross unrecognized tax benefits are classified as other non-current liabilities in the Condensed Consolidated Balance Sheets. The Company had $1.2 billion and $1.0 billion of gross interest and penalties accrued as of December 31, 2016 and September 24, 2016, respectively, which are classified as other non-current liabilities in the Condensed Consolidated Balance Sheets.

[0001628280-17-000717:notes:125]
The Company believes that an adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax audits cannot be predicted with certainty. If any issues addressed in the Company’s tax audits are resolved in a manner not consistent with its expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. Although timing of the resolution and/or closure of audits is not certain, the Company believes it is reasonably possible that its gross unrecognized tax benefits could decrease (whether by payment, release or a combination of both) in the next 12 months by as much as $1.1 billion.

[0001628280-17-000717:notes:126]
On August 30, 2016, the European Commission announced its decision that Ireland granted state aid to the Company by providing tax opinions in 1991 and 2007 concerning the tax allocation of profits of the Irish branches of two subsidiaries of the Company (the “State Aid Decision”). The State Aid Decision orders Ireland to calculate and recover additional taxes from the Company for the period June 2003 through December 2014. Irish legislative changes, effective as of January 2015, eliminated the application of the tax opinions from that date forward. The Company believes the State Aid Decision to be without merit and appealed to the General Court of the Court of Justice of the European Union. Ireland has also appealed the State Aid Decision. While the European Commission announced a recovery amount of up to €13 billion, plus interest, the actual amount of additional taxes subject to recovery is to be calculated by Ireland in accordance with the European Commission's guidance. Once the recovery amount is computed by Ireland, the Company anticipates funding it, including interest, out of foreign cash into escrow, where it will remain pending conclusion of all appeals. The Company believes that any incremental Irish corporate income taxes potentially due related to the State Aid Decision would be creditable against U.S. taxes.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001628280-17-000717:notes:127]
[same as prior period, unchanged from 0001628280-16-017809:notes:128]

[0001628280-17-000717:notes:128]
The Company’s acquired intangible assets with definite useful lives primarily consist of patents and licenses. The following table summarizes the components of gross and net acquired intangible asset balances as of December 31, 2016 and September 24, 2016 (in millions):

[0001628280-17-000717:notes:129]
|  | December 31, 2016 |  | September 24, 2016 |
|  | GrossCarrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |  | GrossCarrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |
| Definite-lived and amortizable acquired intangible assets | $ | 7,472 |  |  | $ | (4,724 | ) |  | $ | 2,748 |  |  | $ | 8,912 |  |  | $ | (5,806 | ) |  | $ | 3,106 |  |
| Indefinite-lived and non-amortizable acquired intangible assets | 100 |  |  | — |  |  | 100 |  |  | 100 |  |  | — |  |  | 100 |  |
| Total acquired intangible assets | $ | 7,572 |  |  | $ | (4,724 | ) |  | $ | 2,848 |  |  | $ | 9,012 |  |  | $ | (5,806 | ) |  | $ | 3,206 |  |


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001628280-17-000717:notes:130]
A reconciliation of the Company’s segment operating income to the Condensed Consolidated Statements of Operations for the three months ended December 31, 2016 and December 26, 2015 is as follows (in millions):

[0001628280-17-000717:notes:131]
|  | Three Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |
| Segment operating income | $ | 27,308 |  |  | $ | 27,645 |  |
| Research and development expense | (2,871 | ) |  | (2,404 | ) |
| Other corporate expenses, net | (1,078 | ) |  | (1,070 | ) |
| Total operating income | $ | 23,359 |  |  | $ | 24,171 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001628280-17-000717:notes:132]
The following table shows information by reportable operating segment for the three months ended December 31, 2016 and December 26, 2015 (in millions):

[0001628280-17-000717:notes:133]
|  | Three Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |
| Americas: |  |  |  |
| Net sales | $ | 31,968 |  |  | $ | 29,325 |  |
| Operating income | $ | 10,494 |  |  | $ | 10,018 |  |
| Europe: |  |  |  |
| Net sales | $ | 18,521 |  |  | $ | 17,932 |  |
| Operating income | $ | 5,736 |  |  | $ | 5,779 |  |
| Greater China: |  |  |  |
| Net sales | $ | 16,233 |  |  | $ | 18,373 |  |
| Operating income | $ | 6,176 |  |  | $ | 7,576 |  |
| Japan: |  |  |  |
| Net sales | $ | 5,766 |  |  | $ | 4,794 |  |
| Operating income | $ | 2,673 |  |  | $ | 2,240 |  |
| Rest of Asia Pacific: |  |  |  |
| Net sales | $ | 5,863 |  |  | $ | 5,448 |  |
| Operating income | $ | 2,229 |  |  | $ | 2,032 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-17-000717:notes:134]
[same as prior period, unchanged from 0001628280-16-017809:notes:135]

[0001628280-17-000717:notes:135]
[same as prior period, unchanged from 0001628280-16-017809:notes:136]

[0001628280-17-000717:notes:136]
The Company manages its business primarily on a geographic basis. The Company’s reportable operating segments consist of the Americas, Europe, Greater China, Japan and Rest of Asia Pacific. The Americas segment includes both North and South America. The Europe segment includes European countries, as well as India, the Middle East and Africa. The Greater China segment includes China, Hong Kong and Taiwan. The Rest of Asia Pacific segment includes Australia and those Asian countries not included in the Company’s other reportable operating segments. Although the reportable operating segments provide similar hardware and software products and similar services, each one is managed separately to better align with the location of the Company’s customers and distribution partners and the unique market dynamics of each geographic region. The accounting policies of the various segments are the same as those described in Note 1, “Summary of Significant Accounting Policies” of the Notes to Consolidated Financial Statements in Part II, Item 8 of the 2016 Form 10-K.

[0001628280-17-000717:notes:137]
[same as prior period, unchanged from 0001628280-16-017809:notes:138]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-17-000717:notes:138]
[same as prior period, unchanged from 0001628280-16-017809:notes:139]

[0001628280-17-000717:notes:139]
[same as prior period, unchanged from 0001628280-16-017809:notes:140]

[0001628280-17-000717:notes:140]
[same as prior period, unchanged from 0001628280-16-017809:notes:141]

[0001628280-17-000717:notes:141]
[same as prior period, unchanged from 0001628280-16-017809:notes:142]

[0001628280-17-000717:notes:142]
In April 2016, the Company’s Board of Directors increased the share repurchase authorization from $140 billion to $175 billion of the Company’s common stock, of which $144 billion had been utilized as of December 31, 2016. The Company’s share repurchase program does not obligate it to acquire any specific number of shares. Under the program, shares may be repurchased in privately negotiated and/or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).

[0001628280-17-000717:notes:143]
The Company has entered, and in the future may enter, into accelerated share repurchase arrangements (“ASRs”) with financial institutions. In exchange for up-front payments, the financial institutions deliver shares of the Company’s common stock during the purchase periods of each ASR. The total number of shares ultimately delivered, and therefore the average repurchase price paid per share, is determined at the end of the applicable purchase period of each ASR based on the volume-weighted average price of the Company’s common stock during that period. The shares received are retired in the periods they are delivered, and the up-front payments are accounted for as a reduction to shareholders’ equity in the Company’s Condensed Consolidated Balance Sheets in the periods the payments are made. The Company reflects the ASRs as a repurchase of common stock in the period delivered for purposes of calculating earnings per share and as forward contracts indexed to its own common stock. The ASRs met all of the applicable criteria for equity classification, and therefore were not accounted for as derivative instruments.
