# AAPL notes — 0000320193-19-000010


## aapl:CashCashEquivalentsandAvailableforSaleSecuritiesTableTextBlock

[0000320193-19-000010:notes:1]
The following tables show the Company’s cash and marketable securities by significant investment category as of December 29, 2018 and September 29, 2018 (in millions):

[0000320193-19-000010:notes:2]
|  | December 29, 2018 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | Short-TermMarketableSecurities |  | Long-TermMarketableSecurities |
| Cash | $ | 9,489 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,489 |  |  | $ | 9,489 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 6,424 |  |  | — |  |  | — |  |  | 6,424 |  |  | 6,424 |  |  | — |  |  | — |  |
| Mutual funds | 682 |  |  | — |  |  | — |  |  | 682 |  |  | — |  |  | 682 |  |  | — |  |
| Subtotal | 7,106 |  |  | — |  |  | — |  |  | 7,106 |  |  | 6,424 |  |  | 682 |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 46,191 |  |  | 6 |  |  | (729 | ) |  | 45,468 |  |  | 3,923 |  |  | 6,415 |  |  | 35,130 |  |
| U.S. agency securities | 9,731 |  |  | — |  |  | (31 | ) |  | 9,700 |  |  | 7,552 |  |  | 597 |  |  | 1,551 |  |
| Non-U.S. government securities | 23,460 |  |  | 48 |  |  | (289 | ) |  | 23,219 |  |  | 1,895 |  |  | 4,129 |  |  | 17,195 |  |
| Certificates of deposit and time deposits | 5,349 |  |  | — |  |  | — |  |  | 5,349 |  |  | 3,705 |  |  | 1,348 |  |  | 296 |  |
| Commercial paper | 11,953 |  |  | — |  |  | — |  |  | 11,953 |  |  | 11,679 |  |  | 274 |  |  | — |  |
| Corporate debt securities | 117,260 |  |  | 32 |  |  | (2,387 | ) |  | 114,905 |  |  | 104 |  |  | 27,134 |  |  | 87,667 |  |
| Municipal securities | 953 |  |  | 1 |  |  | (7 | ) |  | 947 |  |  | — |  |  | 187 |  |  | 760 |  |
| Mortgage- and asset-backed securities | 17,320 |  |  | 7 |  |  | (428 | ) |  | 16,899 |  |  | — |  |  | 890 |  |  | 16,009 |  |
| Subtotal | 232,217 |  |  | 94 |  |  | (3,871 | ) |  | 228,440 |  |  | 28,858 |  |  | 40,974 |  |  | 158,608 |  |
| Total (3) | $ | 248,812 |  |  | $ | 94 |  |  | $ | (3,871 | ) |  | $ | 245,035 |  |  | $ | 44,771 |  |  | $ | 41,656 |  |  | $ | 158,608 |  |

[0000320193-19-000010:notes:3]
|  | September 29, 2018 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | Short-TermMarketableSecurities |  | Long-TermMarketableSecurities |
| Cash | $ | 11,575 |  |  | $ | — |  |  | $ | — |  |  | $ | 11,575 |  |  | $ | 11,575 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 8,083 |  |  | — |  |  | — |  |  | 8,083 |  |  | 8,083 |  |  | — |  |  | — |  |
| Mutual funds | 799 |  |  | — |  |  | (116 | ) |  | 683 |  |  | — |  |  | 683 |  |  | — |  |
| Subtotal | 8,882 |  |  | — |  |  | (116 | ) |  | 8,766 |  |  | 8,083 |  |  | 683 |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 47,296 |  |  | — |  |  | (1,202 | ) |  | 46,094 |  |  | 1,613 |  |  | 7,606 |  |  | 36,875 |  |
| U.S. agency securities | 4,127 |  |  | — |  |  | (48 | ) |  | 4,079 |  |  | 1,732 |  |  | 360 |  |  | 1,987 |  |
| Non-U.S. government securities | 21,601 |  |  | 49 |  |  | (250 | ) |  | 21,400 |  |  | — |  |  | 3,355 |  |  | 18,045 |  |
| Certificates of deposit and time deposits | 3,074 |  |  | — |  |  | — |  |  | 3,074 |  |  | 1,247 |  |  | 1,330 |  |  | 497 |  |
| Commercial paper | 2,573 |  |  | — |  |  | — |  |  | 2,573 |  |  | 1,663 |  |  | 910 |  |  | — |  |
| Corporate debt securities | 123,001 |  |  | 152 |  |  | (2,038 | ) |  | 121,115 |  |  | — |  |  | 25,162 |  |  | 95,953 |  |
| Municipal securities | 946 |  |  | — |  |  | (12 | ) |  | 934 |  |  | — |  |  | 178 |  |  | 756 |  |
| Mortgage- and asset-backed securities | 18,105 |  |  | 8 |  |  | (623 | ) |  | 17,490 |  |  | — |  |  | 804 |  |  | 16,686 |  |
| Subtotal | 220,723 |  |  | 209 |  |  | (4,173 | ) |  | 216,759 |  |  | 6,255 |  |  | 39,705 |  |  | 170,799 |  |
| Total (3) | $ | 241,180 |  |  | $ | 209 |  |  | $ | (4,289 | ) |  | $ | 237,100 |  |  | $ | 25,913 |  |  | $ | 40,388 |  |  | $ | 170,799 |  |

[0000320193-19-000010:notes:4]
[same as prior period, unchanged from 0000320193-18-000100:notes:4]

[0000320193-19-000010:notes:5]
[same as prior period, unchanged from 0000320193-18-000100:notes:5]

[0000320193-19-000010:notes:6]
| (3) | As of December 29, 2018 and September 29, 2018, total cash, cash equivalents and marketable securities included $19.9 billion and $20.3 billion, respectively, that was restricted from general use, related to the State Aid Decision (refer to Note 5, “Income Taxes”) and other agreements. |


## aapl:CommercialPaperCashFlowSummaryTableTextBlock

[0000320193-19-000010:notes:7]
The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the three months ended December 29, 2018 and December 30, 2017 (in millions):

[0000320193-19-000010:notes:8]
|  | Three Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | 2,011 |  |  | $ | 1,621 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 2,166 |  |  | 3,441 |  |
| Repayments of commercial paper | (4,171 | ) |  | (5,060 | ) |
| Proceeds from/(Repayments of) commercial paper, net | (2,005 | ) |  | (1,619 | ) |
| Total change in commercial paper, net | $ | 6 |  |  | $ | 2 |  |


## aapl:NotionalAndCreditRiskAmountsOfOutstandingDerivativePositionsDisclosureTextBlock

[0000320193-19-000010:notes:9]
The following table shows the notional amounts of the Company’s outstanding derivative instruments and credit risk amounts associated with outstanding or unsettled derivative instruments as of December 29, 2018 and September 29, 2018 (in millions):

[0000320193-19-000010:notes:10]
|  | December 29, 2018 |  | September 29, 2018 |
|  | NotionalAmount |  | Credit RiskAmount |  | NotionalAmount |  | Credit RiskAmount |
| Instruments designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 56,000 |  |  | $ | 1,110 |  |  | $ | 65,368 |  |  | $ | 1,015 |  |
| Interest rate contracts | $ | 33,250 |  |  | $ | 22 |  |  | $ | 33,250 |  |  | $ | — |  |
| Instruments not designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 82,013 |  |  | $ | 419 |  |  | $ | 63,062 |  |  | $ | 259 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000320193-19-000010:notes:11]
[same as prior period, unchanged from 0000320193-18-000100:notes:11]

[0000320193-19-000010:notes:12]
The following tables show the Company’s condensed consolidated financial statement details as of December 29, 2018 and September 29, 2018 (in millions):

[0000320193-19-000010:notes:13]
[same as prior period, unchanged from 0000320193-18-000100:notes:15]

[0000320193-19-000010:notes:14]
|  | December 29, 2018 |  | September 29, 2018 |
| Land and buildings | $ | 16,352 |  |  | $ | 16,216 |  |
| Machinery, equipment and internal-use software | 66,823 |  |  | 65,982 |  |
| Leasehold improvements | 8,351 |  |  | 8,205 |  |
| Gross property, plant and equipment | 91,526 |  |  | 90,403 |  |
| Accumulated depreciation and amortization | (51,929 | ) |  | (49,099 | ) |
| Total property, plant and equipment, net | $ | 39,597 |  |  | $ | 41,304 |  |

[0000320193-19-000010:notes:15]
[same as prior period, unchanged from 0000320193-18-000100:notes:17]

[0000320193-19-000010:notes:16]
|  | December 29, 2018 |  | September 29, 2018 |
| Long-term taxes payable | $ | 30,948 |  |  | $ | 33,589 |  |
| Other non-current liabilities | 23,607 |  |  | 15,325 |  |
| Total other non-current liabilities | $ | 54,555 |  |  | $ | 48,914 |  |

[0000320193-19-000010:notes:17]
[same as prior period, unchanged from 0000320193-18-000100:notes:19]

[0000320193-19-000010:notes:18]
The following table shows the detail of other income/(expense), net for the three months ended December 29, 2018 and December 30, 2017 (in millions):

[0000320193-19-000010:notes:19]
|  | Three Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |
| Interest and dividend income | $ | 1,307 |  |  | $ | 1,452 |  |
| Interest expense | (890 | ) |  | (734 | ) |
| Other income, net | 143 |  |  | 38 |  |
| Total other income/(expense), net | $ | 560 |  |  | $ | 756 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000320193-19-000010:notes:20]
[same as prior period, unchanged from 0000320193-18-000100:notes:22]

[0000320193-19-000010:notes:21]
The accompanying condensed consolidated financial statements include the accounts of the Company. Intercompany accounts and transactions have been eliminated. In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements and accompanying notes in conformity with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported. Actual results could differ materially from those estimates. Certain prior period amounts in the condensed consolidated financial statements and accompanying notes have been reclassified to conform to the current period’s presentation. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company’s annual consolidated financial statements and the notes thereto included in its Annual Report on Form 10-K for the fiscal year ended September 29, 2018 (the “2018 Form 10-K”).


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000320193-19-000010:notes:22]
[same as prior period, unchanged from 0000320193-18-000100:notes:24]

[0000320193-19-000010:notes:23]
Apple Inc. and its wholly-owned subsidiaries (collectively “Apple” or the “Company”) designs, manufactures and markets mobile communication and media devices and personal computers, and sells a variety of related software, services, accessories and third-party digital content and applications. The Company’s products and services include iPhone®, Mac®, iPad®, Apple Watch®, AirPods®, Apple TV®, HomePod™, a portfolio of consumer and professional software applications, iOS, macOS®, watchOS® and tvOS® operating systems, iCloud®, Apple Pay® and a variety of accessory, service and support offerings. The Company sells and delivers digital content and applications through the iTunes Store®, App Store®, Mac App Store, TV App Store, Book Store and Apple Music® (collectively “Digital Content and Services”). The Company sells its products worldwide through its retail stores, online stores and direct sales force, as well as through third-party cellular network carriers, wholesalers, retailers and resellers. In addition, the Company sells a variety of third-party Apple-compatible products, including application software and various accessories, through its retail and online stores. The Company sells to consumers, small and mid-sized businesses and education, enterprise and government customers.

[0000320193-19-000010:notes:24]
The Company’s fiscal year is the 52- or 53-week period that ends on the last Saturday of September. A 14th week is included in the first fiscal quarter every five or six years to realign the Company’s fiscal quarters with calendar quarters. The Company’s fiscal years 2019 and 2018 span 52 weeks each. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in September and the associated quarters, months and periods of those fiscal years.

[0000320193-19-000010:notes:25]
Recently Adopted Accounting Pronouncements

[0000320193-19-000010:notes:26]
Revenue Recognition

[0000320193-19-000010:notes:27]
In the first quarter of 2019, the Company adopted the Financial Accounting Standards Board’s (the “FASB”) Accounting Standards Update (“ASU”) No. 2014-09, Revenue from Contracts with Customers (Topic 606) (“ASU 2014-09”), and additional ASUs issued to clarify the guidance in ASU 2014-09 (collectively the “new revenue standard”), which amends the existing accounting standards for revenue recognition. The Company adopted the new revenue standard utilizing the full retrospective transition method. The Company did not restate total net sales in the prior periods presented, as adoption of the new revenue standard did not have a material impact on previously reported amounts.

[0000320193-19-000010:notes:28]
Additionally, beginning in the first quarter of 2019, the Company classified the amortization of the deferred value of Maps, Siri® and free iCloud services, which are bundled in the sales price of iPhone, Mac, iPad and certain other products, in Services net sales. Historically, the Company classified the amortization of these amounts in Products net sales consistent with its management reporting framework. As a result, Products and Services net sales information for the first quarter of 2018 was reclassified to conform to the 2019 presentation.

[0000320193-19-000010:notes:29]
Financial Instruments

[0000320193-19-000010:notes:30]
In the first quarter of 2019, the Company adopted FASB ASU No. 2016-01, Financial Instruments – Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities (“ASU 2016-01”), which updates certain aspects of the recognition, measurement, presentation and disclosure of financial instruments. The adoption of ASU 2016-01 did not have a material impact on the Company’s condensed consolidated financial statements.

[0000320193-19-000010:notes:31]
Income Taxes

[0000320193-19-000010:notes:32]
In the first quarter of 2019, the Company adopted FASB ASU No. 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory (“ASU 2016-16”), which requires the recognition of the income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. The Company adopted ASU 2016-16 utilizing the modified retrospective transition method. Upon adoption, the Company recorded $2.7 billion of net deferred tax assets, reduced other non-current assets by $128 million, and increased retained earnings by $2.6 billion on its Condensed Consolidated Balance Sheet. The Company will recognize incremental deferred income tax expense as these net deferred tax assets are utilized.

[0000320193-19-000010:notes:33]
[same as prior period, unchanged from 0000320193-18-000100:notes:29]

[0000320193-19-000010:notes:34]
The following table shows the computation of basic and diluted earnings per share for the three months ended December 29, 2018 and December 30, 2017 (net income in millions and shares in thousands):

[0000320193-19-000010:notes:35]
|  | Three Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |
| Numerator: |  |  |  |
| Net income | $ | 19,965 |  |  | $ | 20,065 |  |
| Denominator: |  |  |  |
| Weighted-average basic shares outstanding | 4,735,820 |  |  | 5,112,877 |  |
| Effect of dilutive securities | 37,432 |  |  | 44,910 |  |
| Weighted-average diluted shares | 4,773,252 |  |  | 5,157,787 |  |
| Basic earnings per share | $ | 4.22 |  |  | $ | 3.92 |  |
| Diluted earnings per share | $ | 4.18 |  |  | $ | 3.89 |  |

[0000320193-19-000010:notes:36]
Potentially dilutive securities representing 28.8 million shares of common stock were excluded from the computation of diluted earnings per share for the three months ended December 29, 2018 because their effect would have been antidilutive.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000320193-19-000010:notes:37]
Commitments and Contingencies

[0000320193-19-000010:notes:38]
Accrued Warranty and Indemnification

[0000320193-19-000010:notes:39]
The following table shows changes in the Company’s accrued warranties and related costs for the three months ended December 29, 2018 and December 30, 2017 (in millions):

[0000320193-19-000010:notes:40]
|  | Three Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |
| Beginning accrued warranty and related costs | $ | 3,692 |  |  | $ | 3,834 |  |
| Cost of warranty claims | (996 | ) |  | (982 | ) |
| Accruals for product warranty | 1,123 |  |  | 1,471 |  |
| Ending accrued warranty and related costs | $ | 3,819 |  |  | $ | 4,323 |  |

[0000320193-19-000010:notes:41]
Agreements entered into by the Company may include indemnification provisions, which may subject the Company to costs and damages in the event of a claim against an indemnified third party. Except as disclosed under the heading “Contingencies” below, in the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to indemnification of third parties.

[0000320193-19-000010:notes:42]
The Company offers an iPhone Upgrade Program, which is available to customers who purchase a qualifying iPhone in the U.S., the U.K. and mainland China. The iPhone Upgrade Program provides customers the right to trade in that iPhone for a specified amount when purchasing a new iPhone, provided certain conditions are met. The Company accounts for the trade-in right as a guarantee liability and recognizes arrangement revenue net of the fair value of such right, with subsequent changes to the guarantee liability recognized within net sales.

[0000320193-19-000010:notes:43]
The Company has entered into indemnification agreements with its directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers of the Company, and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. While the Company maintains directors and officers liability insurance coverage, such insurance coverage may be insufficient to cover all losses or all types of claims that may arise.

[0000320193-19-000010:notes:44]
Concentrations in the Available Sources of Supply of Materials and Product

[0000320193-19-000010:notes:45]
Although most components essential to the Company’s business are generally available from multiple sources, certain components are currently obtained from single or limited sources. In addition, the Company competes for various components with other participants in the markets for mobile communication and media devices and personal computers. Therefore, many components used by the Company, including those that are available from multiple sources, are at times subject to industry-wide shortage and significant commodity pricing fluctuations that could materially adversely affect the Company’s financial condition and operating results.

[0000320193-19-000010:notes:46]
The Company uses some custom components that are not commonly used by its competitors, and new products introduced by the Company often utilize custom components available from only one source. When a component or product uses new technologies, initial capacity constraints may exist until the suppliers’ yields have matured or manufacturing capacity has increased. If the Company’s supply of components for a new or existing product were delayed or constrained, or if an outsourcing partner delayed shipments of completed products to the Company, the Company’s financial condition and operating results could be materially adversely affected. The Company’s business and financial performance could also be materially adversely affected depending on the time required to obtain sufficient quantities from the original source, or to identify and obtain sufficient quantities from an alternative source. Continued availability of these components at acceptable prices, or at all, may be affected if suppliers decide to concentrate on the production of common components instead of components customized to meet the Company’s requirements.

[0000320193-19-000010:notes:47]
The Company has entered into agreements for the supply of many components; however, there can be no guarantee that the Company will be able to extend or renew these agreements on similar terms, or at all. Therefore, the Company remains subject to significant risks of supply shortages and price increases that could materially adversely affect its financial condition and operating results.

[0000320193-19-000010:notes:48]
Substantially all of the Company’s hardware products are manufactured by outsourcing partners that are located primarily in Asia, with some Mac computers manufactured in the U.S. and Ireland. A significant concentration of this manufacturing is currently performed by a small number of outsourcing partners, often in single locations. Certain of these outsourcing partners are single-sourced suppliers of components and manufacturers for many of the Company’s products. Although the Company works closely with its outsourcing partners on manufacturing schedules, the Company’s financial condition and operating results could be materially adversely affected if its outsourcing partners were unable to meet their production commitments. The Company’s manufacturing purchase obligations typically cover its requirements for periods up to 150 days.

[0000320193-19-000010:notes:49]
Other Off–Balance Sheet Commitments

[0000320193-19-000010:notes:50]
Operating Leases

[0000320193-19-000010:notes:51]
The Company leases various equipment and facilities, including retail space, under noncancelable operating lease arrangements. The Company does not currently utilize any other off–balance sheet financing arrangements. As of December 29, 2018, the Company’s total future minimum lease payments under noncancelable operating leases were $9.9 billion. The Company’s retail store and other facility leases typically have original terms not exceeding 10 years and generally contain multi-year renewal options.

[0000320193-19-000010:notes:52]
Unconditional Purchase Obligations

[0000320193-19-000010:notes:53]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of payments for supplier arrangements, internet and telecommunication services, intellectual property licenses and content creation. As of December 29, 2018, the Company’s total future payments under noncancelable unconditional purchase obligations having a remaining term in excess of one year were $7.4 billion.

[0000320193-19-000010:notes:54]
Contingencies

[0000320193-19-000010:notes:55]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully adjudicated, as further discussed in Part II, Item 1 of this Form 10-Q under the heading “Legal Proceedings” and in Part II, Item 1A of this Form 10-Q under the heading “Risk Factors.” The outcome of litigation is inherently uncertain. If one or more legal matters were resolved against the Company in a reporting period for amounts in excess of management’s expectations, the Company’s financial condition and operating results for that reporting period could be materially adversely affected. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to loss contingencies for asserted legal and other claims, except for the following matters:

[0000320193-19-000010:notes:56]
VirnetX

[0000320193-19-000010:notes:57]
VirnetX, Inc. filed two lawsuits in the U.S. District Court for the Eastern District of Texas (the “Eastern Texas District Court”) against the Company alleging that certain Company products infringe four patents (the “VirnetX Patents”) relating to network communications technology (“VirnetX I” and “VirnetX II”). On September 30, 2016, a jury returned a verdict in VirnetX I against the Company and awarded damages of $302 million, which later increased to $440 million in post-trial proceedings. The Company appealed the VirnetX I verdict to the U.S. Court of Appeals for the Federal Circuit (the “Federal Circuit”). On April 11, 2018, a jury returned a verdict in VirnetX II against the Company and awarded damages of $503 million. VirnetX II is currently on appeal. The Company has challenged the validity of the VirnetX Patents at the U.S. Patent and Trademark Office (the “PTO”). In response, the PTO has declared the VirnetX Patents invalid. VirnetX appealed the invalidity decision of the PTO to the Federal Circuit. The Federal Circuit consolidated the Company’s appeal of the Eastern Texas District Court VirnetX I verdict and VirnetX’s appeals from the PTO invalidity proceedings. On January 15, 2019, the Federal Circuit affirmed the VirnetX I verdict, which the Company intends to further appeal. The remaining appeals from the PTO proceedings invalidating the VirnetX Patents remain pending.

[0000320193-19-000010:notes:58]
Qualcomm

[0000320193-19-000010:notes:59]
On January 20, 2017, the Company filed a lawsuit against Qualcomm Incorporated and affiliated parties (“Qualcomm”) in the U.S. District Court for the Southern District of California seeking, among other things, to enjoin Qualcomm from requiring the Company to pay royalties at the rate demanded by Qualcomm. As the Company does not believe the demanded royalty it has historically paid contract manufacturers for each applicable device is fair, reasonable and non-discriminatory, and believes it to be invalid and/or overstated in other respects as well, no Qualcomm-related royalty payments have been remitted by the Company to its contract manufacturers since the beginning of the second quarter of 2017. The Company believes it will prevail on the merits of the case and has accrued its best estimate for the ultimate resolution of this matter.

[0000320193-19-000010:notes:60]
Following the Company’s lawsuit, Qualcomm has filed patent infringement suits against the Company and its affiliates in the U.S. and various international jurisdictions, some of which seek to enjoin the sale of certain of the Company’s products in particular countries. In one matter pending in China, on November 30, 2018, a court issued an order enjoining the sale in China of certain iPhone models running iOS 10 or iOS 11. The Company has taken steps to comply with the order and has deployed a software update to address the functionality at issue. The Company has sought reconsideration and a declaration of compliance with the order and has appealed the decision. In another matter pending in Germany, on December 20, 2018, a court issued an order enjoining the sale in Germany by the Company and certain of its subsidiaries of iPhone 7, 7 Plus, 8, 8 Plus and X. The Company has taken steps to comply with the order and has appealed the decision.

[0000320193-19-000010:notes:61]
iOS Performance Management Cases

[0000320193-19-000010:notes:62]
Various civil litigation matters have been filed in state and federal courts in the U.S. and in various international jurisdictions alleging violation of consumer protection laws, fraud, computer intrusion and other causes of action related to the Company’s performance management feature used in its iPhone operating systems, introduced to certain iPhones in iOS updates 10.2.1 and 11.2. The claims seek monetary damages and other non-monetary relief. On April 5, 2018, several U.S. federal actions were consolidated through a Multidistrict Litigation process into a single action in the U.S. District Court for the Northern District of California. In addition to civil litigation, the Company is also responding to governmental investigations and requests for information relating to the performance management feature. The Company believes that its iPhones were not defective, that the performance management feature introduced with iOS updates 10.2.1 and 11.2 was intended to, and did, improve customers’ user experience, and that the Company did not make any misleading statements or fail to disclose any material information. The Company has accrued its best estimate for the ultimate resolution of these matters.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000320193-19-000010:notes:63]
[same as prior period, unchanged from 0000320193-18-000100:notes:55]

[0000320193-19-000010:notes:64]
[same as prior period, unchanged from 0000320193-18-000100:notes:56]

[0000320193-19-000010:notes:65]
The Company had 237.9 million shares reserved for future issuance under its stock plans as of December 29, 2018. Restricted stock units (“RSUs”) granted under the Company’s stock plans generally vest over four years, based on continued employment, and are settled upon vesting in shares of the Company’s common stock on a one-for-one basis. Each share issued with respect to RSUs granted under the Company’s stock plans reduces the number of shares available for grant under the plans by two shares. RSUs canceled and shares withheld to satisfy tax withholding obligations increase the number of shares available for grant under the plans utilizing a factor of two times the number of RSUs canceled or shares withheld.

[0000320193-19-000010:notes:66]
[same as prior period, unchanged from 0000320193-18-000100:notes:58]

[0000320193-19-000010:notes:67]
During the three months ended December 29, 2018, Section 16 officers Angela Ahrendts, Timothy D. Cook, Chris Kondo, Luca Maestri and Jeffrey Williams had equity trading plans in place in accordance with Rule 10b5-1(c)(1) under the Exchange Act. An equity trading plan is a written document that pre-establishes the amounts, prices and dates (or formula for determining the amounts, prices and dates) of future purchases or sales of the Company’s stock, including shares acquired pursuant to the Company’s employee and director equity plans.

[0000320193-19-000010:notes:68]
[same as prior period, unchanged from 0000320193-18-000100:notes:60]

[0000320193-19-000010:notes:69]
A summary of the Company’s RSU activity and related information for the three months ended December 29, 2018 is as follows:

[0000320193-19-000010:notes:70]
|  | Number ofRSUs(in thousands) |  | Weighted-AverageGrant Date FairValue Per RSU |  | AggregateFair Value(in millions) |
| Balance as of September 29, 2018 | 92,155 |  |  | $ | 134.60 |  |  |  |
| RSUs granted | 29,228 |  |  | $ | 223.41 |  |  |  |
| RSUs vested | (18,935 | ) |  | $ | 124.36 |  |  |  |
| RSUs canceled | (1,147 | ) |  | $ | 154.53 |  |  |  |
| Balance as of December 29, 2018 | 101,301 |  |  | $ | 161.91 |  |  | $ | 15,826 |  |

[0000320193-19-000010:notes:71]
The fair value as of the respective vesting dates of RSUs was $4.1 billion and $3.1 billion for the three months ended December 29, 2018 and December 30, 2017, respectively.

[0000320193-19-000010:notes:72]
Share-Based Compensation

[0000320193-19-000010:notes:73]
The following table shows share-based compensation expense and the related income tax benefit included in the Condensed Consolidated Statements of Operations for the three months ended December 29, 2018 and December 30, 2017 (in millions):

[0000320193-19-000010:notes:74]
|  | Three Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |
| Share-based compensation expense | $ | 1,559 |  |  | $ | 1,296 |  |
| Income tax benefit related to share-based compensation expense | $ | (750 | ) |  | $ | (631 | ) |

[0000320193-19-000010:notes:75]
As of December 29, 2018, the total unrecognized compensation cost related to outstanding RSUs and stock options was $14.0 billion, which the Company expects to recognize over a weighted-average period of 2.9 years.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000320193-19-000010:notes:76]
[same as prior period, unchanged from 0000320193-18-000100:notes:67]

[0000320193-19-000010:notes:77]
The Company’s OCI consists of foreign currency translation adjustments from those subsidiaries not using the U.S. dollar as their functional currency, net deferred gains and losses on certain derivative instruments accounted for as cash flow hedges and unrealized gains and losses on marketable debt securities classified as available-for-sale.

[0000320193-19-000010:notes:78]
The following table shows the pre-tax amounts reclassified from AOCI into the Condensed Consolidated Statements of Operations, and the associated financial statement line item, for the three months ended December 29, 2018 and December 30, 2017 (in millions):

[0000320193-19-000010:notes:79]
|  |  |  |  | Three Months Ended |
| Comprehensive Income Components |  | Financial Statement Line Item |  | December 29, 2018 |  | December 30, 2017 |
| Unrealized (gains)/losses on derivative instruments: |  |  |  |  |  |  |
| Foreign exchange contracts |  | Total net sales |  | $ | 63 |  |  | $ | 184 |  |
|  |  | Total cost of sales |  | (375 | ) |  | (27 | ) |
|  |  | Other income/(expense), net |  | 396 |  |  | (33 | ) |
| Interest rate contracts |  | Other income/(expense), net |  | 1 |  |  | (1 | ) |
|  |  |  |  | 85 |  |  | 123 |  |
| Unrealized (gains)/losses on marketable securities |  | Other income/(expense), net |  | 47 |  |  | (116 | ) |
| Total amounts reclassified from AOCI |  | $ | 132 |  |  | $ | 7 |  |

[0000320193-19-000010:notes:80]
The following table shows the changes in AOCI by component for the three months ended December 29, 2018 (in millions):

[0000320193-19-000010:notes:81]
|  | Cumulative ForeignCurrency Translation |  | Unrealized Gains/Losseson Derivative Instruments |  | Unrealized Gains/Losseson Marketable Securities |  | Total |
| Balances as of September 29, 2018 | $ | (1,055 | ) |  | $ | 810 |  |  | $ | (3,209 | ) |  | $ | (3,454 | ) |
| Other comprehensive income/(loss) before reclassifications | (82 | ) |  | (472 | ) |  | 140 |  |  | (414 | ) |
| Amounts reclassified from AOCI | — |  |  | 85 |  |  | 47 |  |  | 132 |  |
| Tax effect | 4 |  |  | 95 |  |  | (40 | ) |  | 59 |  |
| Other comprehensive income/(loss) | (78 | ) |  | (292 | ) |  | 147 |  |  | (223 | ) |
| Cumulative effect of change in accounting principle (1) | — |  |  | — |  |  | 89 |  |  | 89 |  |
| Balances as of December 29, 2018 | $ | (1,133 | ) |  | $ | 518 |  |  | $ | (2,973 | ) |  | $ | (3,588 | ) |

[0000320193-19-000010:notes:82]
| (1) | Refer to Note 1, “Summary of Significant Accounting Policies” for more information on the Company’s adoption of ASU 2016-01 at the beginning of the first quarter of 2019. |


## us-gaap:DebtDisclosureTextBlock

[0000320193-19-000010:notes:83]
Debt

[0000320193-19-000010:notes:84]
Commercial Paper

[0000320193-19-000010:notes:85]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of both December 29, 2018 and September 29, 2018, the Company had $12.0 billion of Commercial Paper outstanding with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 2.39% as of December 29, 2018 and 2.18% as of September 29, 2018. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the three months ended December 29, 2018 and December 30, 2017 (in millions):

[0000320193-19-000010:notes:86]
Term Debt

[0000320193-19-000010:notes:87]
As of December 29, 2018, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $103.8 billion (collectively the “Notes”). The Notes are senior unsecured obligations, and interest is payable in arrears, quarterly for the U.S. dollar–denominated and Australian dollar–denominated floating-rate notes, semi-annually for the U.S. dollar–denominated, Australian dollar–denominated, British pound–denominated, Japanese yen–denominated and Canadian dollar–denominated fixed-rate notes and annually for the euro-denominated and Swiss franc–denominated fixed-rate notes.

[0000320193-19-000010:notes:88]
The following table provides a summary of the Company’s term debt as of December 29, 2018 and September 29, 2018:

[0000320193-19-000010:notes:89]
|  | Maturities(calendar year) |  | December 29, 2018 |  | September 29, 2018 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 2.400% – 3.850% notes | 2023 | – | 2043 |  | $ | 8,500 |  |  |  | 2.44% | – | 3.91 | % |  | $ | 8,500 |  |  |  | 2.44% | – | 3.91 | % |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2019 |  | 1,000 |  |  |  |  |  | 2.89 | % |  | 1,000 |  |  |  |  |  | 2.64 | % |
| Fixed-rate 2.100% – 4.450% notes | 2019 | – | 2044 |  | 8,500 |  |  |  | 2.89% | – | 4.48 | % |  | 8,500 |  |  |  | 2.64% | – | 4.48 | % |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2020 |  | 1,497 |  |  |  | 1.87% | – | 2.92 | % |  | 1,507 |  |  |  | 1.87% | – | 2.64 | % |
| Fixed-rate 0.350% – 4.375% notes | 2019 | – | 2045 |  | 24,181 |  |  |  | 0.28% | – | 4.51 | % |  | 24,410 |  |  |  | 0.28% | – | 4.51 | % |
| 2016 debt issuances of $24.9 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2021 |  | 1,350 |  |  |  | 2.72% | – | 3.81 | % |  | 1,350 |  |  |  | 2.48% | – | 3.44 | % |
| Fixed-rate 1.100% – 4.650% notes | 2019 | – | 2046 |  | 23,038 |  |  |  | 1.13% | – | 4.78 | % |  | 23,059 |  |  |  | 1.13% | – | 4.78 | % |
| 2017 debt issuances of $28.7 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2022 |  | 3,250 |  |  |  | 2.68% | – | 3.10 | % |  | 3,250 |  |  |  | 2.41% | – | 2.84 | % |
| Fixed-rate 0.875% – 4.300% notes | 2019 | – | 2047 |  | 25,454 |  |  |  | 1.54% | – | 4.30 | % |  | 25,617 |  |  |  | 1.54% | – | 4.30 | % |
| 2018 debt issuance of $7.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 1.800% – 3.750% notes | 2019 | – | 2047 |  | 7,000 |  |  |  | 1.83% | – | 3.80 | % |  | 7,000 |  |  |  | 1.83% | – | 3.80 | % |
| Total term debt |  |  |  |  | 103,770 |  |  |  |  |  |  |  | 104,193 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (210 | ) |  |  |  |  |  |  | (218 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | (799 | ) |  |  |  |  |  |  | (1,456 | ) |  |  |  |  |  |
| Less: Current portion of term debt |  |  |  |  | (9,772 | ) |  |  |  |  |  |  | (8,784 | ) |  |  |  |  |  |
| Total non-current portion of term debt |  |  |  |  | $ | 92,989 |  |  |  |  |  |  |  | $ | 93,735 |  |  |  |  |  |  |

[0000320193-19-000010:notes:90]
To manage interest rate risk on certain of its U.S. dollar–denominated fixed- or floating-rate notes, the Company has entered into interest rate swaps to effectively convert the fixed interest rates to floating interest rates or the floating interest rates to fixed interest rates on a portion of these notes. Additionally, to manage foreign currency risk on certain of its foreign currency–denominated notes, the Company has entered into foreign currency swaps to effectively convert these notes to U.S. dollar–denominated notes.

[0000320193-19-000010:notes:91]
A portion of the Company’s Japanese yen–denominated notes is designated as a hedge of the foreign currency exposure of the Company’s net investment in a foreign operation. As of December 29, 2018 and September 29, 2018, the carrying value of the debt designated as a net investment hedge was $1.0 billion and $811 million, respectively. For further discussion regarding the Company’s use of derivative instruments, refer to the Derivative Financial Instruments section of Note 3, “Financial Instruments.”

[0000320193-19-000010:notes:92]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $809 million and $695 million of interest expense on its term debt for the three months ended December 29, 2018 and December 30, 2017, respectively.

[0000320193-19-000010:notes:93]
As of December 29, 2018 and September 29, 2018, the fair value of the Company’s Notes, based on Level 2 inputs, was $102.6 billion and $103.2 billion, respectively.


## us-gaap:DerivativesPolicyTextBlock

[0000320193-19-000010:notes:94]
[same as prior period, unchanged from 0000320193-18-000100:notes:85]

[0000320193-19-000010:notes:95]
The Company classifies cash flows related to derivative financial instruments as operating activities in its Condensed Consolidated Statements of Cash Flows.

[0000320193-19-000010:notes:96]
[same as prior period, unchanged from 0000320193-18-000100:notes:86]

[0000320193-19-000010:notes:97]
The Company may use derivatives to partially offset its business exposure to foreign currency and interest rate risk on expected future cash flows, net investments in certain foreign subsidiaries, and certain existing assets and liabilities. However, the Company may choose not to hedge certain exposures for a variety of reasons including, but not limited to, accounting considerations or the prohibitive economic cost of hedging particular exposures. There can be no assurance the hedges will offset more than a portion of the financial impact resulting from movements in foreign currency exchange or interest rates.

[0000320193-19-000010:notes:98]
To protect gross margins from fluctuations in foreign currency exchange rates, certain of the Company’s subsidiaries whose functional currency is the U.S. dollar may hedge a portion of forecasted foreign currency revenue, and subsidiaries whose functional currency is not the U.S. dollar may hedge a portion of forecasted inventory purchases not denominated in the subsidiaries’ functional currencies. The Company may enter into forward contracts, option contracts or other instruments to manage this risk and may designate these instruments as cash flow hedges. The Company generally hedges portions of its forecasted foreign currency exposure associated with revenue and inventory purchases, typically for up to 12 months.

[0000320193-19-000010:notes:99]
To protect the net investment in a foreign operation from fluctuations in foreign currency exchange rates, the Company may enter into foreign currency forward and option contracts to offset a portion of the changes in the carrying amounts of these investments due to fluctuations in foreign currency exchange rates. In addition, the Company may use non-derivative financial instruments, such as its foreign currency–denominated debt, as hedges of its net investments in certain foreign subsidiaries. In both of these cases, the Company designates these instruments as net investment hedges.

[0000320193-19-000010:notes:100]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in foreign currency exchange rates, the Company may enter into forward contracts, cross-currency swaps or other instruments. These instruments may offset a portion of the foreign currency remeasurement gains or losses, or changes in fair value. The Company may designate these instruments as either cash flow or fair value hedges. As of December 29, 2018, the Company’s hedged term debt– and marketable securities–related foreign currency transactions are expected to be recognized within 24 years.

[0000320193-19-000010:notes:101]
The Company may also enter into non-designated foreign currency contracts to offset a portion of the foreign currency exchange gains and losses generated by the remeasurement of certain assets and liabilities denominated in non-functional currencies.

[0000320193-19-000010:notes:102]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in interest rates, the Company may enter into interest rate swaps, options or other instruments. These instruments may offset a portion of the changes in interest income or expense, or changes in fair value. The Company designates these instruments as either cash flow or fair value hedges. As of December 29, 2018, the Company’s hedged interest rate transactions are expected to be recognized within 9 years.

[0000320193-19-000010:notes:103]
[same as prior period, unchanged from 0000320193-18-000100:notes:93]

[0000320193-19-000010:notes:104]
The effective portions of cash flow hedges are recorded in accumulated other comprehensive income/(loss) (“AOCI”) until the hedged item is recognized in earnings. Deferred gains and losses associated with cash flow hedges of foreign currency revenue are recognized as a component of net sales in the same period as the related revenue is recognized, and deferred gains and losses related to cash flow hedges of inventory purchases are recognized as a component of cost of sales in the same period as the related costs are recognized. Deferred gains and losses associated with cash flow hedges of interest income or expense are recognized in other income/(expense), net in the same period as the related income or expense is recognized. For options designated as cash flow hedges, changes in the time value are excluded from the assessment of hedge effectiveness. The ineffective portions and amounts excluded from the effectiveness testing of cash flow hedges are recognized in other income/(expense), net.

[0000320193-19-000010:notes:105]
[same as prior period, unchanged from 0000320193-18-000100:notes:95]

[0000320193-19-000010:notes:106]
[same as prior period, unchanged from 0000320193-18-000100:notes:96]

[0000320193-19-000010:notes:107]
The effective portions of net investment hedges are recorded in OCI as a part of the cumulative translation adjustment. The ineffective portions and amounts excluded from the effectiveness testing of net investment hedges are recognized in other income/(expense), net. For forward exchange contracts designated as net investment hedges, the Company excludes changes in fair value relating to changes in the forward carry component from its definition of effectiveness. Accordingly, any gains or losses related to this forward carry component are recognized in earnings in the current period.

[0000320193-19-000010:notes:108]
[same as prior period, unchanged from 0000320193-18-000100:notes:98]

[0000320193-19-000010:notes:109]
Gains and losses related to changes in fair value hedges are recognized in earnings along with a corresponding loss or gain related to the change in value of the underlying hedged item in the same line in the Condensed Consolidated Statements of Operations.

[0000320193-19-000010:notes:110]
[same as prior period, unchanged from 0000320193-18-000100:notes:100]

[0000320193-19-000010:notes:111]
[same as prior period, unchanged from 0000320193-18-000100:notes:101]


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000320193-19-000010:notes:112]
Net sales disaggregated by significant products and services for the three months ended December 29, 2018 and December 30, 2017 were as follows (in millions):

[0000320193-19-000010:notes:113]
|  | Three Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |
| iPhone (1) | $ | 51,982 |  |  | $ | 61,104 |  |
| Mac (1) | 7,416 |  |  | 6,824 |  |
| iPad (1) | 6,729 |  |  | 5,755 |  |
| Wearables, Home and Accessories (1)(2) | 7,308 |  |  | 5,481 |  |
| Services (3) | 10,875 |  |  | 9,129 |  |
| Total net sales (4) | $ | 84,310 |  |  | $ | 88,293 |  |

[0000320193-19-000010:notes:114]
| (1) | Products net sales include amortization of the deferred value of unspecified software upgrade rights, which are bundled in the sales price of the respective product. |

[0000320193-19-000010:notes:115]
| (2) | Wearables, Home and Accessories net sales include sales of AirPods, Apple TV, Apple Watch, Beats® products, HomePod, iPod touch® and Apple-branded and third-party accessories. |

[0000320193-19-000010:notes:116]
| (3) | Services net sales include sales from Digital Content and Services, AppleCare®, Apple Pay, licensing and other services. Services net sales also include amortization of the deferred value of Maps, Siri and free iCloud services, which are bundled in the sales price of certain products. |

[0000320193-19-000010:notes:117]
| (4) | Includes $2.4 billion and $2.0 billion of revenue recognized in the three months ended December 29, 2018 and December 30, 2017, respectively, that was included in deferred revenue at the beginning of each respective period. |


## us-gaap:EquitySecuritiesWithoutReadilyDeterminableFairValuePolicyTextBlock

[0000320193-19-000010:notes:118]
The Company holds non-marketable equity securities of certain privately held companies without readily determinable fair values, and has elected to apply the measurement alternative. As such, the Company’s non-marketable equity securities are measured at cost, less any impairment, and are adjusted for changes in fair value resulting from observable transactions for identical or similar investments of the same issuer. Gains and losses on non-marketable equity securities are recognized in other income/(expense), net.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000320193-19-000010:notes:119]
[same as prior period, unchanged from 0000320193-18-000100:notes:102]

[0000320193-19-000010:notes:120]
[same as prior period, unchanged from 0000320193-18-000100:notes:103]


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000320193-19-000010:notes:121]
[same as prior period, unchanged from 0000320193-18-000100:notes:105]

[0000320193-19-000010:notes:122]
The Company’s investments in marketable debt securities have been classified and accounted for as available-for-sale. The Company classifies its marketable debt securities as either short-term or long-term based on each instrument’s underlying contractual maturity date. Unrealized gains and losses on marketable debt securities classified as available-for-sale are recognized in other comprehensive income/(loss) (“OCI”).

[0000320193-19-000010:notes:123]
The Company’s investments in mutual funds represent its only marketable equity securities and are classified as short-term based on the nature of the securities and their availability for use in current operations. The Company’s marketable equity securities are measured at fair value with gains and losses recognized in other income/(expense), net.

[0000320193-19-000010:notes:124]
The Company may sell certain of its marketable debt securities prior to their stated maturities for reasons including, but not limited to, managing liquidity, credit risk, duration and asset allocation. The maturities of the Company’s long-term marketable debt securities generally range from one to five years.

[0000320193-19-000010:notes:125]
The following tables show information about the Company’s marketable securities that had been in a continuous unrealized loss position for less than 12 months and for 12 months or greater as of December 29, 2018 and September 29, 2018 (in millions):

[0000320193-19-000010:notes:126]
|  | December 29, 2018 |
|  | Continuous Unrealized Losses |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
| Fair value of marketable debt securities | $ | 53,336 |  |  | $ | 127,006 |  |  | $ | 180,342 |  |
| Unrealized losses | $ | (1,153 | ) |  | $ | (2,718 | ) |  | $ | (3,871 | ) |

[0000320193-19-000010:notes:127]
|  | September 29, 2018 |
|  | Continuous Unrealized Losses |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
| Fair value of marketable securities | $ | 126,238 |  |  | $ | 60,599 |  |  | $ | 186,837 |  |
| Unrealized losses | $ | (2,400 | ) |  | $ | (1,889 | ) |  | $ | (4,289 | ) |

[0000320193-19-000010:notes:128]
The Company typically invests in highly rated securities, with the primary objective of minimizing the potential risk of principal loss. The Company’s investment policy generally requires securities to be investment grade and limits the amount of credit exposure to any one issuer. Fair values were determined for each individual security in the investment portfolio. When evaluating a marketable debt security for other-than-temporary impairment, the Company reviews factors such as the length of time and extent to which fair value has been below its cost basis, the financial condition of the issuer and any changes thereto, changes in market interest rates and the Company’s intent to sell, or whether it is more likely than not it will be required to sell the security before recovery of the security’s cost basis. As of December 29, 2018, the Company does not consider any of its marketable debt securities to be other-than-temporarily impaired.

[0000320193-19-000010:notes:129]
Non-Marketable Securities

[0000320193-19-000010:notes:130]
The Company holds non-marketable equity securities of certain privately held companies without readily determinable fair values, and has elected to apply the measurement alternative. As such, the Company’s non-marketable equity securities are measured at cost, less any impairment, and are adjusted for changes in fair value resulting from observable transactions for identical or similar investments of the same issuer. Gains and losses on non-marketable equity securities are recognized in other income/(expense), net. As of December 29, 2018, the Company’s non-marketable equity securities had a carrying value of $2.2 billion.

[0000320193-19-000010:notes:131]
The Company holds a non-marketable debt security that is classified and accounted for as held-to-maturity. As of December 29, 2018, the Company’s non-marketable debt security had an amortized cost basis and carrying value of $1.5 billion.

[0000320193-19-000010:notes:132]
Derivatives that are not designated as hedging instruments are adjusted to fair value through earnings in the financial statement line item to which the derivative relates. As a result, during the three months ended December 29, 2018, the Company recognized a gain of $255 million in net sales, a gain of $175 million in cost of sales and a gain of $723 million in other income/(expense), net.

[0000320193-19-000010:notes:133]
The Company records all derivatives in the Condensed Consolidated Balance Sheets at fair value. The Company’s accounting treatment for these derivative instruments is based on its hedge designation. The following tables show the Company’s derivative instruments at gross fair value as of December 29, 2018 and September 29, 2018 (in millions):

[0000320193-19-000010:notes:134]
|  | December 29, 2018 |
|  | Fair Value ofDerivatives Designatedas Hedge Instruments |  | Fair Value ofDerivatives Not Designatedas Hedge Instruments |  | TotalFair Value |
| Derivative assets (1): |  |  |  |  |  |
| Foreign exchange contracts | $ | 1,110 |  |  | $ | 419 |  |  | $ | 1,529 |  |
| Interest rate contracts | $ | 22 |  |  | $ | — |  |  | $ | 22 |  |
| Derivative liabilities (2): |  |  |  |  |  |
| Foreign exchange contracts | $ | 701 |  |  | $ | 345 |  |  | $ | 1,046 |  |
| Interest rate contracts | $ | 821 |  |  | $ | — |  |  | $ | 821 |  |

[0000320193-19-000010:notes:135]
|  | September 29, 2018 |
|  | Fair Value ofDerivatives Designatedas Hedge Instruments |  | Fair Value ofDerivatives Not Designatedas Hedge Instruments |  | TotalFair Value |
| Derivative assets (1): |  |  |  |  |  |
| Foreign exchange contracts | $ | 1,015 |  |  | $ | 259 |  |  | $ | 1,274 |  |
| Derivative liabilities (2): |  |  |  |  |  |
| Foreign exchange contracts | $ | 543 |  |  | $ | 137 |  |  | $ | 680 |  |
| Interest rate contracts | $ | 1,456 |  |  | $ | — |  |  | $ | 1,456 |  |

[0000320193-19-000010:notes:136]
[same as prior period, unchanged from 0000320193-18-000100:notes:115]

[0000320193-19-000010:notes:137]
| (2) | The fair value of derivative liabilities is measured using Level 2 fair value inputs and is recorded as other current liabilities and other non-current liabilities in the Condensed Consolidated Balance Sheets. |

[0000320193-19-000010:notes:138]
The following table shows the pre-tax gains and losses of the Company’s derivative and non-derivative instruments designated as cash flow, net investment and fair value hedges in OCI and the Condensed Consolidated Statements of Operations for the three months ended December 29, 2018 and December 30, 2017 (in millions):

[0000320193-19-000010:notes:139]
|  | Three Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |
| Gains/(Losses) recognized in OCI – effective portion: |  |  |  |
| Cash flow hedges: |  |  |  |
| Foreign exchange contracts | $ | (478 | ) |  | $ | 153 |  |
| Interest rate contracts | — |  |  | 1 |  |
| Total | $ | (478 | ) |  | $ | 154 |  |
| Net investment hedges: |  |  |  |
| Foreign currency debt | $ | (16 | ) |  | $ | 2 |  |
| Gains/(Losses) reclassified from AOCI into net income – effective portion: |  |  |  |
| Cash flow hedges: |  |  |  |
| Foreign exchange contracts | $ | (118 | ) |  | $ | (124 | ) |
| Interest rate contracts | (1 | ) |  | 1 |  |
| Total | $ | (119 | ) |  | $ | (123 | ) |
| Gains/(Losses) on derivative instruments: |  |  |  |
| Fair value hedges: |  |  |  |
| Foreign exchange contracts | $ | 402 |  |  | $ | — |  |
| Interest rate contracts | 657 |  |  | (274 | ) |
| Total | $ | 1,059 |  |  | $ | (274 | ) |
| Gains/(Losses) related to hedged items: |  |  |  |
| Fair value hedges: |  |  |  |
| Marketable securities | $ | (402 | ) |  | $ | — |  |
| Fixed-rate debt | (657 | ) |  | 274 |  |
| Total | $ | (1,059 | ) |  | $ | 274 |  |

[0000320193-19-000010:notes:140]
[same as prior period, unchanged from 0000320193-18-000100:notes:119]

[0000320193-19-000010:notes:141]
The Company generally enters into master netting arrangements, which are designed to reduce credit risk by permitting net settlement of transactions with the same counterparty. To further limit credit risk, the Company generally enters into collateral security arrangements that provide for collateral to be received or posted when the net fair value of certain financial instruments fluctuates from contractually established thresholds. The Company presents its derivative assets and derivative liabilities at their gross fair values in its Condensed Consolidated Balance Sheets. The net cash collateral posted by the Company related to derivative instruments under its collateral security arrangements was $56 million and $1.0 billion as of December 29, 2018 and September 29, 2018, respectively, which were recorded as other current assets in the Condensed Consolidated Balance Sheets.

[0000320193-19-000010:notes:142]
Under master netting arrangements with the respective counterparties to the Company’s derivative contracts, the Company is allowed to net settle transactions with a single net amount payable by one party to the other. As of December 29, 2018 and September 29, 2018, the potential effects of these rights of set-off associated with the Company’s derivative contracts, including the effects of collateral, would be a reduction to both derivative assets and derivative liabilities of $1.9 billion and $2.1 billion, respectively, resulting in a net derivative liability of $260 million and a net derivative asset of $138 million, respectively.

[0000320193-19-000010:notes:143]
[same as prior period, unchanged from 0000320193-18-000100:notes:122]

[0000320193-19-000010:notes:144]
[same as prior period, unchanged from 0000320193-18-000100:notes:123]

[0000320193-19-000010:notes:145]
[same as prior period, unchanged from 0000320193-18-000100:notes:124]

[0000320193-19-000010:notes:146]
As of December 29, 2018, the Company had no customers that individually represented 10% or more of total trade receivables. As of September 29, 2018, the Company had one customer that represented 10% or more of total trade receivables, which accounted for 10%. The Company’s cellular network carriers accounted for 45% and 59% of total trade receivables as of December 29, 2018 and September 29, 2018, respectively.

[0000320193-19-000010:notes:147]
[same as prior period, unchanged from 0000320193-18-000100:notes:126]

[0000320193-19-000010:notes:148]
The Company has non-trade receivables from certain of its manufacturing vendors resulting from the sale of components to these vendors who manufacture sub-assemblies or assemble final products for the Company. The Company purchases these components directly from suppliers. As of December 29, 2018, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 56% and 15%. As of September 29, 2018, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 62% and 12%.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000320193-19-000010:notes:149]
U.S. Tax Cuts and Jobs Act

[0000320193-19-000010:notes:150]
On December 22, 2017, the U.S. enacted the Tax Cuts and Jobs Act (the “Act”), which significantly changed U.S. tax law. The Act lowered the Company’s U.S. statutory federal income tax rate from 35% to 21% effective January 1, 2018, while also imposing a deemed repatriation tax on previously deferred foreign income. The Act also created a new minimum tax on certain future foreign earnings. The Company completed its accounting for the income tax effects of the Act during the first quarter of 2019, in accordance with the U.S. Securities and Exchange Commission Staff Accounting Bulletin No. 118.

[0000320193-19-000010:notes:151]
Uncertain Tax Positions

[0000320193-19-000010:notes:152]
As of December 29, 2018, the total amount of gross unrecognized tax benefits was $14.7 billion, of which $8.2 billion, if recognized, would impact the Company’s effective tax rate. The Company had accrued $1.2 billion of gross interest and penalties as of December 29, 2018. Both the unrecognized tax benefits and the associated interest and penalties that are not expected to result in payment or receipt of cash within one year are classified as other non-current liabilities in the Condensed Consolidated Balance Sheet.

[0000320193-19-000010:notes:153]
The Company is subject to taxation and files income tax returns in the U.S. federal jurisdiction and in many state and foreign jurisdictions. The U.S. Internal Revenue Service concluded its review of the years 2013 through 2015 in 2018, and all years prior to 2016 are closed. Tax years subsequent to 2006 in certain major U.S. states and subsequent to 2010 in certain major foreign jurisdictions remain open, and could be subject to examination by the taxing authorities. The Company believes that an adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax audits cannot be predicted with certainty. If any issues addressed in the Company’s tax audits are resolved in a manner inconsistent with its expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. Although timing of resolution and/or closure of audits is not certain, the Company believes it is reasonably possible that its gross unrecognized tax benefits could decrease (either by payment, release or a combination of both) in the next 12 months by as much as $300 million.

[0000320193-19-000010:notes:154]
[same as prior period, unchanged from 0000320193-18-000100:notes:139]

[0000320193-19-000010:notes:155]
On August 30, 2016, the European Commission announced its decision that Ireland granted state aid to the Company by providing tax opinions in 1991 and 2007 concerning the tax allocation of profits of the Irish branches of two subsidiaries of the Company (the “State Aid Decision”). The State Aid Decision ordered Ireland to calculate and recover additional taxes from the Company for the period June 2003 through December 2014. The recovery amount was calculated to be €13.1 billion, plus interest of €1.2 billion. Irish legislative changes, effective as of January 2015, eliminated the application of the tax opinions from that date forward. The Company believes the State Aid Decision to be without merit and appealed to the General Court of the Court of Justice of the European Union. Ireland has also appealed the State Aid Decision. The Company believes that any incremental Irish corporate income taxes potentially due related to the State Aid Decision would be creditable against U.S. taxes, subject to any foreign tax credit limitations in the Act. As of December 29, 2018, the entire recovery amount plus interest was funded into escrow, where it will remain restricted from general use pending conclusion of all appeals. Refer to Note 3, “Financial Instruments” for more information.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0000320193-19-000010:notes:156]
A reconciliation of the Company’s segment operating income to the Condensed Consolidated Statements of Operations for the three months ended December 29, 2018 and December 30, 2017 is as follows (in millions):

[0000320193-19-000010:notes:157]
|  | Three Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |
| Segment operating income | $ | 28,746 |  |  | $ | 30,774 |  |
| Research and development expense | (3,902 | ) |  | (3,407 | ) |
| Other corporate expenses, net | (1,498 | ) |  | (1,093 | ) |
| Total operating income | $ | 23,346 |  |  | $ | 26,274 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000320193-19-000010:notes:158]
Net sales consist of revenue from the sale of iPhone, Mac, iPad, services and other products. The Company recognizes revenue at the amount to which it expects to be entitled when control of the products or services is transferred to its customers. Control is generally transferred when the Company has a present right to payment and title and the significant risks and rewards of ownership of products or services are transferred to its customers. For most of the Company’s products net sales, control transfers when products are shipped. For the Company’s services net sales, control transfers over time as services are delivered. Payment for products and services net sales is collected within a short period of time following transfer of control or commencement of delivery of services, as applicable.

[0000320193-19-000010:notes:159]
The Company records reductions to products net sales related to future product returns, price protection and other customer incentive programs based on the Company’s expectations and historical experience.

[0000320193-19-000010:notes:160]
For arrangements with multiple performance obligations, which represent promises within an arrangement that are capable of being distinct, the Company allocates revenue to all distinct performance obligations based on their relative stand-alone selling prices (“SSP”). When available, the Company uses observable prices to determine the SSP. When observable prices are not available, SSPs are established that reflect the Company’s best estimates of what the selling prices of the performance obligations would be if they were sold regularly on a stand-alone basis. The Company’s process for estimating SSPs without observable prices considers multiple factors that may vary depending upon the unique facts and circumstances related to each performance obligation including, where applicable, prices charged by the Company for similar offerings, market trends in the pricing for similar offerings, product-specific business objectives and the estimated cost to provide the performance obligation.

[0000320193-19-000010:notes:161]
The Company has identified up to three performance obligations regularly included in arrangements involving the sale of iPhone, Mac, iPad and certain other products. The first performance obligation, which represents the substantial portion of the allocated sales price, is the hardware and bundled software delivered at the time of sale. The second performance obligation is the right to receive certain product-related bundled services, which include iCloud, Siri and Maps. The third performance obligation is the right to receive, on a when-and-if-available basis, future unspecified software upgrades relating to the software bundled with each device. The Company allocates revenue and any related discounts to these performance obligations based on their relative SSPs. Because the Company lacks observable prices for the undelivered performance obligations, the allocation of revenue is based on the Company’s estimated SSPs. Revenue allocated to the delivered hardware and bundled software is recognized when control has transferred to the customer, which generally occurs when the product is shipped. Revenue allocated to the product-related bundled services and unspecified software upgrade rights is deferred and recognized on a straight-line basis over the estimated period they are expected to be provided. Cost of sales related to delivered hardware and bundled software, including estimated warranty costs, are recognized at the time of sale. Costs incurred to provide product-related bundled services and unspecified software upgrade rights are recognized as cost of sales as incurred.

[0000320193-19-000010:notes:162]
For certain long-term service arrangements, the Company has performance obligations for services it has not yet delivered. For these arrangements, the Company does not have a right to bill for the undelivered services. The Company has determined that any unbilled consideration relates entirely to the value of the undelivered services. Accordingly, the Company has not recognized revenue, and has elected not to disclose amounts, related to these undelivered services.

[0000320193-19-000010:notes:163]
For the sale of third-party products where the Company obtains control of the product before transferring it to the customer, the Company recognizes revenue based on the gross amount billed to customers. The Company considers multiple factors when determining whether it obtains control of third-party products including, but not limited to, evaluating if it has the ability to establish the price of the product, retains inventory risk for tangible products or has the responsibility for ensuring acceptability of the product. For third-party applications sold through the App Store, Mac App Store and TV App Store and certain digital content sold through the iTunes Store, the Company does not obtain control of the product before transferring it to the customer. Therefore, the Company accounts for such sales on a net basis by recognizing in services net sales only the commission it retains.

[0000320193-19-000010:notes:164]
The Company has elected to record revenue net of taxes collected from customers that are remitted to governmental authorities, with the collected taxes recorded within other current liabilities until remitted to the relevant government authority.

[0000320193-19-000010:notes:165]
Deferred Revenue

[0000320193-19-000010:notes:166]
As of December 29, 2018 and September 29, 2018, the Company had total deferred revenue of $8.4 billion and $8.8 billion, respectively. As of December 29, 2018, the Company expects 66% of total deferred revenue to be realized in less than a year, 27% within one-to-two years, 6% within two-to-three years and 1% in greater than three years.

[0000320193-19-000010:notes:167]
Disaggregated Revenue

[0000320193-19-000010:notes:168]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 11, “Segment Information and Geographic Data” for the three months ended December 29, 2018 and December 30, 2017.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000320193-19-000010:notes:169]
The following table shows information by reportable segment for the three months ended December 29, 2018 and December 30, 2017 (in millions):

[0000320193-19-000010:notes:170]
|  | Three Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |
| Americas: |  |  |  |
| Net sales | $ | 36,940 |  |  | $ | 35,193 |  |
| Operating income | $ | 11,200 |  |  | $ | 11,316 |  |
| Europe: |  |  |  |
| Net sales | $ | 20,363 |  |  | $ | 21,054 |  |
| Operating income | $ | 6,658 |  |  | $ | 6,893 |  |
| Greater China: |  |  |  |
| Net sales | $ | 13,169 |  |  | $ | 17,956 |  |
| Operating income | $ | 5,314 |  |  | $ | 6,908 |  |
| Japan: |  |  |  |
| Net sales | $ | 6,910 |  |  | $ | 7,237 |  |
| Operating income | $ | 3,014 |  |  | $ | 3,082 |  |
| Rest of Asia Pacific: |  |  |  |
| Net sales | $ | 6,928 |  |  | $ | 6,853 |  |
| Operating income | $ | 2,560 |  |  | $ | 2,575 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000320193-19-000010:notes:171]
[same as prior period, unchanged from 0000320193-18-000100:notes:145]

[0000320193-19-000010:notes:172]
[same as prior period, unchanged from 0000320193-18-000100:notes:146]

[0000320193-19-000010:notes:173]
The Company manages its business primarily on a geographic basis. The Company’s reportable segments consist of the Americas, Europe, Greater China, Japan and Rest of Asia Pacific. Americas includes both North and South America. Europe includes European countries, as well as India, the Middle East and Africa. Greater China includes China, Hong Kong and Taiwan. Rest of Asia Pacific includes Australia and those Asian countries not included in the Company’s other reportable segments. Although the reportable segments provide similar hardware and software products and similar services, each one is managed separately to better align with the location of the Company’s customers and distribution partners and the unique market dynamics of each geographic region. The accounting policies of the various segments are the same as those described in Note 1, “Summary of Significant Accounting Policies” of the Notes to Consolidated Financial Statements in Part II, Item 8 of the 2018 Form 10-K.

[0000320193-19-000010:notes:174]
[same as prior period, unchanged from 0000320193-18-000100:notes:148]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000320193-19-000010:notes:175]
[same as prior period, unchanged from 0000320193-18-000100:notes:149]

[0000320193-19-000010:notes:176]
[same as prior period, unchanged from 0000320193-18-000100:notes:150]

[0000320193-19-000010:notes:177]
On May 1, 2018, the Company announced the Board of Directors had authorized a program to repurchase up to $100 billion of the Company’s common stock, of which $37.3 billion had been utilized as of December 29, 2018. During the three months ended December 29, 2018, the Company repurchased 38.0 million shares of its common stock for $8.2 billion. The Company’s share repurchase program does not obligate it to acquire any specific number of shares. Under this program, shares may be repurchased in privately negotiated and/or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).
