# AAPL note change history — 0000320193-18-000100 → 0000320193-19-000010


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-01-30):
[0000320193-19-000010:note_history:1]
The following table shows changes in the Company’s accrued warranties and related costs for the three months ended December 29, 2018 and December 30, 2017 (in millions):
  (was, 2018-08-01, similarity 0.8807):
[0000320193-18-000100:note_history:1]
The following table shows changes in the Company’s accrued warranties and related costs for the three- and nine-month periods ended June 30, 2018 and July 1, 2017 (in millions):

- changed (2019-01-30):
[0000320193-19-000010:note_history:2]
|  | Three Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |
| Beginning accrued warranty and related costs | $ | 3,692 |  |  | $ | 3,834 |  |
| Cost of warranty claims | (996 | ) |  | (982 | ) |
| Accruals for product warranty | 1,123 |  |  | 1,471 |  |
| Ending accrued warranty and related costs | $ | 3,819 |  |  | $ | 4,323 |  |
  (was, 2018-08-01, similarity 0.7514):
[0000320193-18-000100:note_history:2]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | June 30, 2018 |  | July 1, 2017 |
| Beginning accrued warranty and related costs | $ | 4,030 |  |  | $ | 4,735 |  |  | $ | 3,834 |  |  | $ | 3,702 |  |
| Cost of warranty claims | (1,044 | ) |  | (932 | ) |  | (2,959 | ) |  | (3,300 | ) |
| Accruals for product warranty | 567 |  |  | 496 |  |  | 2,678 |  |  | 3,897 |  |
| Ending accrued warranty and related costs | $ | 3,553 |  |  | $ | 4,299 |  |  | $ | 3,553 |  |  | $ | 4,299 |  |

- changed (2019-01-30):
[0000320193-19-000010:note_history:3]
Agreements entered into by the Company may include indemnification provisions, which may subject the Company to costs and damages in the event of a claim against an indemnified third party. Except as disclosed under the heading “Contingencies” below, in the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to indemnification of third parties.
  (was, 2018-08-01, similarity 0.9864):
[0000320193-18-000100:note_history:3]
Agreements entered into by the Company sometimes include indemnification provisions which may subject the Company to costs and damages in the event of a claim against an indemnified third party. Except as disclosed under the heading “Contingencies” below, in the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to indemnification of third parties.

- changed (2019-01-30):
[0000320193-19-000010:note_history:4]
The Company offers an iPhone Upgrade Program, which is available to customers who purchase a qualifying iPhone in the U.S., the U.K. and mainland China. The iPhone Upgrade Program provides customers the right to trade in that iPhone for a specified amount when purchasing a new iPhone, provided certain conditions are met. The Company accounts for the trade-in right as a guarantee liability and recognizes arrangement revenue net of the fair value of such right, with subsequent changes to the guarantee liability recognized within net sales.
  (was, 2018-08-01, similarity 0.9834):
[0000320193-18-000100:note_history:4]
The Company offers an iPhone Upgrade Program, which is available to customers who purchase a qualifying iPhone in the U.S., the U.K. and mainland China. The iPhone Upgrade Program provides customers the right to trade in that iPhone for a specified amount when purchasing a new iPhone, provided certain conditions are met. The Company accounts for the trade-in right as a guarantee liability and recognizes arrangement revenue net of the fair value of such right, with subsequent changes to the guarantee liability recognized within revenue.

- added (2019-01-30):
[0000320193-19-000010:note_history:5]
The Company has entered into indemnification agreements with its directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers of the Company, and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. While the Company maintains directors and officers liability insurance coverage, such insurance coverage may be insufficient to cover all losses or all types of claims that may arise.

- changed (2019-01-30):
[0000320193-19-000010:note_history:6]
Although most components essential to the Company’s business are generally available from multiple sources, certain components are currently obtained from single or limited sources. In addition, the Company competes for various components with other participants in the markets for mobile communication and media devices and personal computers. Therefore, many components used by the Company, including those that are available from multiple sources, are at times subject to industry-wide shortage and significant commodity pricing fluctuations that could materially adversely affect the Company’s financial condition and operating results.
  (was, 2018-08-01, similarity 0.9906):
[0000320193-18-000100:note_history:6]
Although most components essential to the Company’s business are generally available from multiple sources, a few components are currently obtained from single or limited sources. In addition, the Company competes for various components with other participants in the markets for mobile communication and media devices and personal computers. Therefore, many components used by the Company, including those that are available from multiple sources, are at times subject to industry-wide shortage and significant commodity pricing fluctuations that could materially adversely affect the Company’s financial condition and operating results.

- changed (2019-01-30):
[0000320193-19-000010:note_history:7]
The Company uses some custom components that are not commonly used by its competitors, and new products introduced by the Company often utilize custom components available from only one source. When a component or product uses new technologies, initial capacity constraints may exist until the suppliers’ yields have matured or manufacturing capacity has increased. If the Company’s supply of components for a new or existing product were delayed or constrained, or if an outsourcing partner delayed shipments of completed products to the Company, the Company’s financial condition and operating results could be materially adversely affected. The Company’s business and financial performance could also be materially adversely affected depending on the time required to obtain sufficient quantities from the original source, or to identify and obtain sufficient quantities from an alternative source. Continued availability of these components at acceptable prices, or at all, may be affected if suppliers decide to concentrate on the production of common components instead of components customized to meet the Company’s requirements.
  (was, 2018-08-01, similarity 0.9974):
[0000320193-18-000100:note_history:7]
The Company uses some custom components that are not commonly used by its competitors, and new products introduced by the Company often utilize custom components available from only one source. When a component or product uses new technologies, initial capacity constraints may exist until the suppliers’ yields have matured or manufacturing capacity has increased. If the Company’s supply of components for a new or existing product were delayed or constrained, or if an outsourcing partner delayed shipments of completed products to the Company, the Company’s financial condition and operating results could be materially adversely affected. The Company’s business and financial performance could also be materially adversely affected depending on the time required to obtain sufficient quantities from the original source, or to identify and obtain sufficient quantities from an alternative source. Continued availability of these components at acceptable prices, or at all, may be affected if those suppliers decide to concentrate on the production of common components instead of components customized to meet the Company’s requirements.

- changed (2019-01-30):
[0000320193-19-000010:note_history:8]
Substantially all of the Company’s hardware products are manufactured by outsourcing partners that are located primarily in Asia, with some Mac computers manufactured in the U.S. and Ireland. A significant concentration of this manufacturing is currently performed by a small number of outsourcing partners, often in single locations. Certain of these outsourcing partners are single-sourced suppliers of components and manufacturers for many of the Company’s products. Although the Company works closely with its outsourcing partners on manufacturing schedules, the Company’s financial condition and operating results could be materially adversely affected if its outsourcing partners were unable to meet their production commitments. The Company’s manufacturing purchase obligations typically cover its requirements for periods up to 150 days.
  (was, 2018-08-01, similarity 0.9728):
[0000320193-18-000100:note_history:8]
Substantially all of the Company’s hardware products are manufactured by outsourcing partners that are located primarily in Asia, with some Mac computers manufactured in the U.S. and Ireland. A significant concentration of this manufacturing is currently performed by a small number of outsourcing partners, often in single locations. Certain of these outsourcing partners are the sole-sourced suppliers of components and manufacturers for many of the Company’s products. Although the Company works closely with its outsourcing partners on manufacturing schedules, the Company’s operating results could be adversely affected if its outsourcing partners were unable to meet their production commitments. The Company’s manufacturing purchase obligations typically cover its requirements for periods up to 150 days.

- changed (2019-01-30):
[0000320193-19-000010:note_history:9]
The Company leases various equipment and facilities, including retail space, under noncancelable operating lease arrangements. The Company does not currently utilize any other off–balance sheet financing arrangements. As of December 29, 2018, the Company’s total future minimum lease payments under noncancelable operating leases were $9.9 billion. The Company’s retail store and other facility leases typically have original terms not exceeding 10 years and generally contain multi-year renewal options.
  (was, 2018-08-01, similarity 0.9878):
[0000320193-18-000100:note_history:9]
The Company leases various equipment and facilities, including retail space, under noncancelable operating lease arrangements. The Company does not currently utilize any other off–balance sheet financing arrangements. As of June 30, 2018, the Company’s total future minimum lease payments under noncancelable operating leases were $9.6 billion. The Company’s retail store and other facility leases typically have original terms not exceeding 10 years and generally contain multi-year renewal options.

- changed (2019-01-30):
[0000320193-19-000010:note_history:10]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of payments for supplier arrangements, internet and telecommunication services, intellectual property licenses and content creation. As of December 29, 2018, the Company’s total future payments under noncancelable unconditional purchase obligations having a remaining term in excess of one year were $7.4 billion.
  (was, 2018-08-01, similarity 0.8719):
[0000320193-18-000100:note_history:10]
The Company has entered into certain off–balance sheet arrangements which require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of payments for supplier arrangements, internet and telecommunication services and intellectual property licenses. As of June 30, 2018, the Company’s total future payments under noncancelable unconditional purchase obligations having a remaining term in excess of one year were $8.5 billion.

- changed (2019-01-30):
[0000320193-19-000010:note_history:11]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully adjudicated, as further discussed in Part II, Item 1 of this Form 10-Q under the heading “Legal Proceedings” and in Part II, Item 1A of this Form 10-Q under the heading “Risk Factors.” The outcome of litigation is inherently uncertain. If one or more legal matters were resolved against the Company in a reporting period for amounts in excess of management’s expectations, the Company’s financial condition and operating results for that reporting period could be materially adversely affected. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to loss contingencies for asserted legal and other claims, except for the following matters:
  (was, 2018-08-01, similarity 0.9617):
[0000320193-18-000100:note_history:11]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully adjudicated, as further discussed in Part II, Item 1 of this Form 10-Q under the heading “Legal Proceedings” and in Part II, Item 1A of this Form 10-Q under the heading “Risk Factors.” The outcome of litigation is inherently uncertain. If one or more legal matters were resolved against the Company in a reporting period for amounts in excess of management’s expectations, the Company’s consolidated financial statements for that reporting period could be materially adversely affected. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to loss contingencies for asserted legal and other claims, except for the following matters:

- changed (2019-01-30):
[0000320193-19-000010:note_history:12]
VirnetX, Inc. filed two lawsuits in the U.S. District Court for the Eastern District of Texas (the “Eastern Texas District Court”) against the Company alleging that certain Company products infringe four patents (the “VirnetX Patents”) relating to network communications technology (“VirnetX I” and “VirnetX II”). On September 30, 2016, a jury returned a verdict in VirnetX I against the Company and awarded damages of $302 million, which later increased to $440 million in post-trial proceedings. The Company appealed the VirnetX I verdict to the U.S. Court of Appeals for the Federal Circuit (the “Federal Circuit”). On April 11, 2018, a jury returned a verdict in VirnetX II against the Company and awarded damages of $503 million. VirnetX II is currently on appeal. The Company has challenged the validity of the VirnetX Patents at the U.S. Patent and Trademark Office (the “PTO”). In response, the PTO has declared the VirnetX Patents invalid. VirnetX appealed the invalidity decision of the PTO to the Federal Circuit. The Federal Circuit consolidated the Company’s appeal of the Eastern Texas District Court VirnetX I verdict and VirnetX’s appeals from the PTO invalidity proceedings. On January 15, 2019, the Federal Circuit affirmed the VirnetX I verdict, which the Company intends to further appeal. The remaining appeals from the PTO proceedings invalidating the VirnetX Patents remain pending.
  (was, 2018-08-01, similarity 0.7741):
[0000320193-18-000100:note_history:12]
VirnetX, Inc. filed two lawsuits in the U.S. District Court for the Eastern District of Texas (the “Eastern Texas District Court”) against the Company alleging that certain Company products infringe four patents (the “VirnetX Patents”) relating to network communications technology (“VirnetX I” and “VirnetX II”). On September 30, 2016, a jury returned a verdict in VirnetX I against the Company and awarded damages of $302 million, which later increased to $440 million in post-trial proceedings. VirnetX I is currently on appeal at the U.S. Court of Appeals for the Federal Circuit (the “Federal Circuit”). On April 11, 2018, a jury returned a verdict in VirnetX II against the Company and awarded damages of $503 million. VirnetX II is currently in post-trial proceedings and is expected to proceed to appeal thereafter. The Company has challenged the validity of the VirnetX Patents at the U.S. Patent and Trademark Office (the “PTO”). In response, the PTO has declared the VirnetX Patents invalid. VirnetX has appealed, and those appeals are currently pending at the Federal Circuit. The Federal Circuit has consolidated the Company’s appeal of the Eastern Texas District Court VirnetX I verdict and VirnetX’s appeals from the PTO invalidity proceedings. The Company believes it will prevail on the merits.

- added (2019-01-30):
[0000320193-19-000010:note_history:13]
Following the Company’s lawsuit, Qualcomm has filed patent infringement suits against the Company and its affiliates in the U.S. and various international jurisdictions, some of which seek to enjoin the sale of certain of the Company’s products in particular countries. In one matter pending in China, on November 30, 2018, a court issued an order enjoining the sale in China of certain iPhone models running iOS 10 or iOS 11. The Company has taken steps to comply with the order and has deployed a software update to address the functionality at issue. The Company has sought reconsideration and a declaration of compliance with the order and has appealed the decision. In another matter pending in Germany, on December 20, 2018, a court issued an order enjoining the sale in Germany by the Company and certain of its subsidiaries of iPhone 7, 7 Plus, 8, 8 Plus and X. The Company has taken steps to comply with the order and has appealed the decision.

- added (2019-01-30):
[0000320193-19-000010:note_history:14]
iOS Performance Management Cases

- added (2019-01-30):
[0000320193-19-000010:note_history:15]
Various civil litigation matters have been filed in state and federal courts in the U.S. and in various international jurisdictions alleging violation of consumer protection laws, fraud, computer intrusion and other causes of action related to the Company’s performance management feature used in its iPhone operating systems, introduced to certain iPhones in iOS updates 10.2.1 and 11.2. The claims seek monetary damages and other non-monetary relief. On April 5, 2018, several U.S. federal actions were consolidated through a Multidistrict Litigation process into a single action in the U.S. District Court for the Northern District of California. In addition to civil litigation, the Company is also responding to governmental investigations and requests for information relating to the performance management feature. The Company believes that its iPhones were not defective, that the performance management feature introduced with iOS updates 10.2.1 and 11.2 was intended to, and did, improve customers’ user experience, and that the Company did not make any misleading statements or fail to disclose any material information. The Company has accrued its best estimate for the ultimate resolution of these matters.

- removed (2019-01-30):
[0000320193-18-000100:note_history:16]
The Company has entered into indemnification agreements with its directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers of the Company and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. While the Company maintains directors and officers liability insurance coverage, such insurance coverage may be insufficient to cover all losses or all types of claims that may arise.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-01-30):
[0000320193-19-000010:note_history:17]
Apple Inc. and its wholly-owned subsidiaries (collectively “Apple” or the “Company”) designs, manufactures and markets mobile communication and media devices and personal computers, and sells a variety of related software, services, accessories and third-party digital content and applications. The Company’s products and services include iPhone®, Mac®, iPad®, Apple Watch®, AirPods®, Apple TV®, HomePod™, a portfolio of consumer and professional software applications, iOS, macOS®, watchOS® and tvOS® operating systems, iCloud®, Apple Pay® and a variety of accessory, service and support offerings. The Company sells and delivers digital content and applications through the iTunes Store®, App Store®, Mac App Store, TV App Store, Book Store and Apple Music® (collectively “Digital Content and Services”). The Company sells its products worldwide through its retail stores, online stores and direct sales force, as well as through third-party cellular network carriers, wholesalers, retailers and resellers. In addition, the Company sells a variety of third-party Apple-compatible products, including application software and various accessories, through its retail and online stores. The Company sells to consumers, small and mid-sized businesses and education, enterprise and government customers.
  (was, 2018-08-01, similarity 0.9571):
[0000320193-18-000100:note_history:17]
Apple Inc. and its wholly-owned subsidiaries (collectively “Apple” or the “Company”) designs, manufactures and markets mobile communication and media devices and personal computers, and sells a variety of related software, services, accessories and third-party digital content and applications. The Company’s products and services include iPhone®, iPad®, Mac®, Apple Watch®, AirPods®, Apple TV®, HomePod™, a portfolio of consumer and professional software applications, iOS, macOS®, watchOS® and tvOS™ operating systems, iCloud®, Apple Pay® and a variety of other accessory, service and support offerings. The Company sells and delivers digital content and applications through the iTunes Store®, App Store®, Mac App Store, TV App Store, iBooks Store® and Apple Music® (collectively “Digital Content and Services”). The Company sells its products worldwide through its retail stores, online stores and direct sales force, as well as through third-party cellular network carriers, wholesalers, retailers and resellers. In addition, the Company sells a variety of third-party Apple-compatible products, including application software and various accessories through its retail and online stores. The Company sells to consumers, small and mid-sized businesses and education, enterprise and government customers.

- changed (2019-01-30):
[0000320193-19-000010:note_history:18]
The accompanying condensed consolidated financial statements include the accounts of the Company. Intercompany accounts and transactions have been eliminated. In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements and accompanying notes in conformity with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported. Actual results could differ materially from those estimates. Certain prior period amounts in the condensed consolidated financial statements and accompanying notes have been reclassified to conform to the current period’s presentation. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company’s annual consolidated financial statements and the notes thereto included in its Annual Report on Form 10-K for the fiscal year ended September 29, 2018 (the “2018 Form 10-K”).
  (was, 2018-08-01, similarity 0.8332):
[0000320193-18-000100:note_history:18]
The accompanying condensed consolidated financial statements include the accounts of the Company. Intercompany accounts and transactions have been eliminated. In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements in conformity with U.S. generally accepted accounting principles (“GAAP”) requires management to make estimates and assumptions that affect the amounts reported in these condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. Certain prior period amounts in the condensed consolidated financial statements and accompanying notes have been reclassified to conform to the current period’s presentation. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company’s annual consolidated financial statements and the notes thereto included in its Annual Report on Form 10-K for the fiscal year ended September 30, 2017 (the “2017 Form 10-K”).

- added (2019-01-30):
[0000320193-19-000010:note_history:19]
The Company’s fiscal year is the 52- or 53-week period that ends on the last Saturday of September. A 14th week is included in the first fiscal quarter every five or six years to realign the Company’s fiscal quarters with calendar quarters. The Company’s fiscal years 2019 and 2018 span 52 weeks each. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in September and the associated quarters, months and periods of those fiscal years.

- added (2019-01-30):
[0000320193-19-000010:note_history:20]
Recently Adopted Accounting Pronouncements

- added (2019-01-30):
[0000320193-19-000010:note_history:21]
Revenue Recognition

- added (2019-01-30):
[0000320193-19-000010:note_history:22]
In the first quarter of 2019, the Company adopted the Financial Accounting Standards Board’s (the “FASB”) Accounting Standards Update (“ASU”) No. 2014-09, Revenue from Contracts with Customers (Topic 606) (“ASU 2014-09”), and additional ASUs issued to clarify the guidance in ASU 2014-09 (collectively the “new revenue standard”), which amends the existing accounting standards for revenue recognition. The Company adopted the new revenue standard utilizing the full retrospective transition method. The Company did not restate total net sales in the prior periods presented, as adoption of the new revenue standard did not have a material impact on previously reported amounts.

- added (2019-01-30):
[0000320193-19-000010:note_history:23]
Additionally, beginning in the first quarter of 2019, the Company classified the amortization of the deferred value of Maps, Siri® and free iCloud services, which are bundled in the sales price of iPhone, Mac, iPad and certain other products, in Services net sales. Historically, the Company classified the amortization of these amounts in Products net sales consistent with its management reporting framework. As a result, Products and Services net sales information for the first quarter of 2018 was reclassified to conform to the 2019 presentation.

- added (2019-01-30):
[0000320193-19-000010:note_history:24]
Financial Instruments

- added (2019-01-30):
[0000320193-19-000010:note_history:25]
In the first quarter of 2019, the Company adopted FASB ASU No. 2016-01, Financial Instruments – Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities (“ASU 2016-01”), which updates certain aspects of the recognition, measurement, presentation and disclosure of financial instruments. The adoption of ASU 2016-01 did not have a material impact on the Company’s condensed consolidated financial statements.

- added (2019-01-30):
[0000320193-19-000010:note_history:26]
Income Taxes

- added (2019-01-30):
[0000320193-19-000010:note_history:27]
In the first quarter of 2019, the Company adopted FASB ASU No. 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory (“ASU 2016-16”), which requires the recognition of the income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. The Company adopted ASU 2016-16 utilizing the modified retrospective transition method. Upon adoption, the Company recorded $2.7 billion of net deferred tax assets, reduced other non-current assets by $128 million, and increased retained earnings by $2.6 billion on its Condensed Consolidated Balance Sheet. The Company will recognize incremental deferred income tax expense as these net deferred tax assets are utilized.

- changed (2019-01-30):
[0000320193-19-000010:note_history:28]
The following table shows the computation of basic and diluted earnings per share for the three months ended December 29, 2018 and December 30, 2017 (net income in millions and shares in thousands):
  (was, 2018-08-01, similarity 0.8987):
[0000320193-18-000100:note_history:28]
The following table shows the computation of basic and diluted earnings per share for the three- and nine-month periods ended June 30, 2018 and July 1, 2017 (net income in millions and shares in thousands):

- added (2019-01-30):
[0000320193-19-000010:note_history:29]
|  | Three Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |
| Numerator: |  |  |  |
| Net income | $ | 19,965 |  |  | $ | 20,065 |  |
| Denominator: |  |  |  |
| Weighted-average basic shares outstanding | 4,735,820 |  |  | 5,112,877 |  |
| Effect of dilutive securities | 37,432 |  |  | 44,910 |  |
| Weighted-average diluted shares | 4,773,252 |  |  | 5,157,787 |  |
| Basic earnings per share | $ | 4.22 |  |  | $ | 3.92 |  |
| Diluted earnings per share | $ | 4.18 |  |  | $ | 3.89 |  |

- added (2019-01-30):
[0000320193-19-000010:note_history:30]
Potentially dilutive securities representing 28.8 million shares of common stock were excluded from the computation of diluted earnings per share for the three months ended December 29, 2018 because their effect would have been antidilutive.

- removed (2019-01-30):
[0000320193-18-000100:note_history:31]
The Company’s fiscal year is the 52- or 53-week period that ends on the last Saturday of September. The first quarter of 2018 spanned 13 weeks, whereas a 14th week was added to the first fiscal quarter of 2017, as is done every five or six years, to realign the Company’s fiscal quarters with calendar quarters. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in September and the associated quarters, months and periods of those fiscal years.

- removed (2019-01-30):
[0000320193-18-000100:note_history:32]
Share-Based Compensation

- removed (2019-01-30):
[0000320193-18-000100:note_history:33]
During the first quarter of 2018, the Company adopted the Financial Accounting Standards Board’s (the “FASB”) Accounting Standards Update (“ASU”) No. 2016-09, Compensation – Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting (“ASU 2016-09”), which modified certain aspects of the accounting for share-based payment transactions, including income taxes, classification of awards and classification in the statement of cash flows. Historically, excess tax benefits or deficiencies from the Company’s equity awards were recorded as additional paid-in capital in its Condensed Consolidated Balance Sheets and were classified as a financing activity in its Condensed Consolidated Statements of Cash Flows. Beginning in 2018, the Company records any excess tax benefits or deficiencies from its equity awards as part of the provision for income taxes in its Condensed Consolidated Statements of Operations in the reporting periods in which equity vesting occurs. The Company elected to apply the cash flow classification requirements related to excess tax benefits retrospectively to all periods presented, which resulted in an increase to cash generated by operating activities in the Condensed Consolidated Statements of Cash Flows of $534 million for the nine months ended July 1, 2017.

- removed (2019-01-30):
[0000320193-18-000100:note_history:34]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | June 30, 2018 |  | July 1, 2017 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 11,519 |  |  | $ | 8,717 |  |  | $ | 45,406 |  |  | $ | 37,637 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 4,882,167 |  |  | 5,195,088 |  |  | 5,006,640 |  |  | 5,239,847 |  |
| Effect of dilutive securities | 44,442 |  |  | 38,411 |  |  | 44,323 |  |  | 34,547 |  |
| Weighted-average diluted shares | 4,926,609 |  |  | 5,233,499 |  |  | 5,050,963 |  |  | 5,274,394 |  |
| Basic earnings per share | $ | 2.36 |  |  | $ | 1.68 |  |  | $ | 9.07 |  |  | $ | 7.18 |  |
| Diluted earnings per share | $ | 2.34 |  |  | $ | 1.67 |  |  | $ | 8.99 |  |  | $ | 7.14 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-01-30):
[0000320193-19-000010:note_history:35]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of both December 29, 2018 and September 29, 2018, the Company had $12.0 billion of Commercial Paper outstanding with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 2.39% as of December 29, 2018 and 2.18% as of September 29, 2018. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the three months ended December 29, 2018 and December 30, 2017 (in millions):
  (was, 2018-08-01, similarity 0.7269):
[0000320193-18-000100:note_history:35]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of both June 30, 2018 and September 30, 2017, the Company had $12.0 billion of Commercial Paper outstanding with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 2.03% as of June 30, 2018 and 1.20% as of September 30, 2017. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the nine months ended June 30, 2018 and July 1, 2017 (in millions):

- added (2019-01-30):
[0000320193-19-000010:note_history:36]
|  | Three Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | 2,011 |  |  | $ | 1,621 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 2,166 |  |  | 3,441 |  |
| Repayments of commercial paper | (4,171 | ) |  | (5,060 | ) |
| Proceeds from/(Repayments of) commercial paper, net | (2,005 | ) |  | (1,619 | ) |
| Total change in commercial paper, net | $ | 6 |  |  | $ | 2 |  |

- changed (2019-01-30):
[0000320193-19-000010:note_history:37]
As of December 29, 2018, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $103.8 billion (collectively the “Notes”). The Notes are senior unsecured obligations, and interest is payable in arrears, quarterly for the U.S. dollar–denominated and Australian dollar–denominated floating-rate notes, semi-annually for the U.S. dollar–denominated, Australian dollar–denominated, British pound–denominated, Japanese yen–denominated and Canadian dollar–denominated fixed-rate notes and annually for the euro-denominated and Swiss franc–denominated fixed-rate notes.
  (was, 2018-08-01, similarity 0.9902):
[0000320193-18-000100:note_history:37]
As of June 30, 2018, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $104.1 billion (collectively the “Notes”). The Notes are senior unsecured obligations, and interest is payable in arrears, quarterly for the U.S. dollar–denominated and Australian dollar–denominated floating-rate notes, semi-annually for the U.S. dollar–denominated, Australian dollar–denominated, British pound–denominated, Japanese yen–denominated and Canadian dollar–denominated fixed-rate notes and annually for the euro-denominated and Swiss franc–denominated fixed-rate notes.

- changed (2019-01-30):
[0000320193-19-000010:note_history:38]
The following table provides a summary of the Company’s term debt as of December 29, 2018 and September 29, 2018:
  (was, 2018-08-01, similarity 0.9505):
[0000320193-18-000100:note_history:38]
The following table provides a summary of the Company’s term debt as of June 30, 2018 and September 30, 2017:

- changed (2019-01-30):
[0000320193-19-000010:note_history:39]
|  | Maturities(calendar year) |  | December 29, 2018 |  | September 29, 2018 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 2.400% – 3.850% notes | 2023 | – | 2043 |  | $ | 8,500 |  |  |  | 2.44% | – | 3.91 | % |  | $ | 8,500 |  |  |  | 2.44% | – | 3.91 | % |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2019 |  | 1,000 |  |  |  |  |  | 2.89 | % |  | 1,000 |  |  |  |  |  | 2.64 | % |
| Fixed-rate 2.100% – 4.450% notes | 2019 | – | 2044 |  | 8,500 |  |  |  | 2.89% | – | 4.48 | % |  | 8,500 |  |  |  | 2.64% | – | 4.48 | % |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2020 |  | 1,497 |  |  |  | 1.87% | – | 2.92 | % |  | 1,507 |  |  |  | 1.87% | – | 2.64 | % |
| Fixed-rate 0.350% – 4.375% notes | 2019 | – | 2045 |  | 24,181 |  |  |  | 0.28% | – | 4.51 | % |  | 24,410 |  |  |  | 0.28% | – | 4.51 | % |
| 2016 debt issuances of $24.9 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2021 |  | 1,350 |  |  |  | 2.72% | – | 3.81 | % |  | 1,350 |  |  |  | 2.48% | – | 3.44 | % |
| Fixed-rate 1.100% – 4.650% notes | 2019 | – | 2046 |  | 23,038 |  |  |  | 1.13% | – | 4.78 | % |  | 23,059 |  |  |  | 1.13% | – | 4.78 | % |
| 2017 debt issuances of $28.7 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2022 |  | 3,250 |  |  |  | 2.68% | – | 3.10 | % |  | 3,250 |  |  |  | 2.41% | – | 2.84 | % |
| Fixed-rate 0.875% – 4.300% notes | 2019 | – | 2047 |  | 25,454 |  |  |  | 1.54% | – | 4.30 | % |  | 25,617 |  |  |  | 1.54% | – | 4.30 | % |
| 2018 debt issuance of $7.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 1.800% – 3.750% notes | 2019 | – | 2047 |  | 7,000 |  |  |  | 1.83% | – | 3.80 | % |  | 7,000 |  |  |  | 1.83% | – | 3.80 | % |
| Total term debt |  |  |  |  | 103,770 |  |  |  |  |  |  |  | 104,193 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (210 | ) |  |  |  |  |  |  | (218 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | (799 | ) |  |  |  |  |  |  | (1,456 | ) |  |  |  |  |  |
| Less: Current portion of term debt |  |  |  |  | (9,772 | ) |  |  |  |  |  |  | (8,784 | ) |  |  |  |  |  |
| Total non-current portion of term debt |  |  |  |  | $ | 92,989 |  |  |  |  |  |  |  | $ | 93,735 |  |  |  |  |  |  |
  (was, 2018-08-01, similarity 0.7278):
[0000320193-18-000100:note_history:39]
|  | Maturities |  | June 30, 2018 |  | September 30, 2017 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | — |  | $ | — |  |  |  |  |  | — | % |  | $ | 2,000 |  |  |  | 1.10% |  | 1.10 | % |
| Fixed-rate 2.400% – 3.850% notes | 2023 | – | 2043 |  | 8,500 |  |  |  | 2.44% | – | 3.91 | % |  | 12,500 |  |  |  | 1.08% | – | 3.91 | % |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 |  | 2019 |  | 1,000 |  |  |  | 2.66% |  | 2.66 | % |  | 1,000 |  |  |  | 1.61% |  | 1.61 | % |
| Fixed-rate 2.100% – 4.450% notes | 2019 | – | 2044 |  | 8,500 |  |  |  | 2.66% | – | 4.48 | % |  | 8,500 |  |  |  | 1.61% | – | 4.48 | % |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2020 |  | 1,517 |  |  |  | 1.87% | – | 2.66 | % |  | 1,549 |  |  |  | 1.56% | – | 1.87 | % |
| Fixed-rate 0.350% – 4.375% notes | 2019 | – | 2045 |  | 24,395 |  |  |  | 0.28% | – | 4.51 | % |  | 24,522 |  |  |  | 0.28% | – | 4.51 | % |
| 2016 debt issuances of $24.9 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2021 |  | 1,350 |  |  |  | 2.50% | – | 3.46 | % |  | 1,350 |  |  |  | 1.45% | – | 2.44 | % |
| Fixed-rate 1.100% – 4.650% notes | 2019 | – | 2046 |  | 23,079 |  |  |  | 1.13% | – | 4.78 | % |  | 23,645 |  |  |  | 1.13% | – | 4.78 | % |
| 2017 debt issuances of $28.7 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2022 |  | 3,250 |  |  |  | 2.43% | – | 2.87 | % |  | 3,250 |  |  |  | 1.38% | – | 1.81 | % |
| Fixed-rate 0.875% – 4.300% notes | 2019 | – | 2047 |  | 25,533 |  |  |  | 1.54% | – | 4.30 | % |  | 25,705 |  |  |  | 1.51% | – | 4.30 | % |
| First quarter 2018 debt issuance of $7.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 1.800% notes |  |  | 2019 |  | 1,000 |  |  |  |  |  | 1.83 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.000% notes |  |  | 2020 |  | 1,000 |  |  |  |  |  | 2.03 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.400% notes |  |  | 2023 |  | 750 |  |  |  |  |  | 2.66 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.750% notes |  |  | 2025 |  | 1,500 |  |  |  |  |  | 2.77 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.000% notes |  |  | 2027 |  | 1,500 |  |  |  |  |  | 3.07 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.750% notes |  |  | 2047 |  | 1,250 |  |  |  |  |  | 3.80 | % |  | — |  |  |  |  |  | — | % |
| Total term debt |  |  |  |  | 104,124 |  |  |  |  |  |  |  | 104,021 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (227 | ) |  |  |  |  |  |  | (225 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | (1,271 | ) |  |  |  |  |  |  | (93 | ) |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  |  |  | (5,498 | ) |  |  |  |  |  |  | (6,496 | ) |  |  |  |  |  |
| Total long-term debt |  |  |  |  | $ | 97,128 |  |  |  |  |  |  |  | $ | 97,207 |  |  |  |  |  |  |

- changed (2019-01-30):
[0000320193-19-000010:note_history:40]
A portion of the Company’s Japanese yen–denominated notes is designated as a hedge of the foreign currency exposure of the Company’s net investment in a foreign operation. As of December 29, 2018 and September 29, 2018, the carrying value of the debt designated as a net investment hedge was $1.0 billion and $811 million, respectively. For further discussion regarding the Company’s use of derivative instruments, refer to the Derivative Financial Instruments section of Note 3, “Financial Instruments.”
  (was, 2018-08-01, similarity 0.7653):
[0000320193-18-000100:note_history:40]
A portion of the Company’s Japanese yen–denominated notes is designated as a hedge of the foreign currency exposure of the Company’s net investment in a foreign operation. As of June 30, 2018 and September 30, 2017, the carrying value of the debt designated as a net investment hedge was $349 million and $1.6 billion, respectively. For further discussion regarding the Company’s use of derivative instruments, see the Derivative Financial Instruments section of Note 2, “Financial Instruments.”

- changed (2019-01-30):
[0000320193-19-000010:note_history:41]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $809 million and $695 million of interest expense on its term debt for the three months ended December 29, 2018 and December 30, 2017, respectively.
  (was, 2018-08-01, similarity 0.7141):
[0000320193-18-000100:note_history:41]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $780 million and $2.2 billion of interest expense on its term debt for the three- and nine-month periods ended June 30, 2018, respectively. The Company recognized $574 million and $1.6 billion of interest expense on its term debt for the three- and nine-month periods ended July 1, 2017, respectively.

- changed (2019-01-30):
[0000320193-19-000010:note_history:42]
As of December 29, 2018 and September 29, 2018, the fair value of the Company’s Notes, based on Level 2 inputs, was $102.6 billion and $103.2 billion, respectively.
  (was, 2018-08-01, similarity 0.965):
[0000320193-18-000100:note_history:42]
As of June 30, 2018 and September 30, 2017, the fair value of the Company’s Notes, based on Level 2 inputs, was $103.1 billion and $106.1 billion, respectively.

- removed (2019-01-30):
[0000320193-18-000100:note_history:43]
|  | Nine Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | 2,619 |  |  | $ | (143 | ) |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 9,782 |  |  | 12,633 |  |
| Repayments of commercial paper | (12,411 | ) |  | (8,624 | ) |
| Proceeds from/(Repayments of) commercial paper, net | (2,629 | ) |  | 4,009 |  |
| Total change in commercial paper, net | $ | (10 | ) |  | $ | 3,866 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-01-30):
[0000320193-19-000010:note_history:44]
The following table provides a summary of the Company’s term debt as of December 29, 2018 and September 29, 2018:
  (was, 2018-08-01, similarity 0.9505):
[0000320193-18-000100:note_history:44]
The following table provides a summary of the Company’s term debt as of June 30, 2018 and September 30, 2017:

- changed (2019-01-30):
[0000320193-19-000010:note_history:45]
|  | Maturities(calendar year) |  | December 29, 2018 |  | September 29, 2018 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 2.400% – 3.850% notes | 2023 | – | 2043 |  | $ | 8,500 |  |  |  | 2.44% | – | 3.91 | % |  | $ | 8,500 |  |  |  | 2.44% | – | 3.91 | % |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2019 |  | 1,000 |  |  |  |  |  | 2.89 | % |  | 1,000 |  |  |  |  |  | 2.64 | % |
| Fixed-rate 2.100% – 4.450% notes | 2019 | – | 2044 |  | 8,500 |  |  |  | 2.89% | – | 4.48 | % |  | 8,500 |  |  |  | 2.64% | – | 4.48 | % |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2020 |  | 1,497 |  |  |  | 1.87% | – | 2.92 | % |  | 1,507 |  |  |  | 1.87% | – | 2.64 | % |
| Fixed-rate 0.350% – 4.375% notes | 2019 | – | 2045 |  | 24,181 |  |  |  | 0.28% | – | 4.51 | % |  | 24,410 |  |  |  | 0.28% | – | 4.51 | % |
| 2016 debt issuances of $24.9 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2021 |  | 1,350 |  |  |  | 2.72% | – | 3.81 | % |  | 1,350 |  |  |  | 2.48% | – | 3.44 | % |
| Fixed-rate 1.100% – 4.650% notes | 2019 | – | 2046 |  | 23,038 |  |  |  | 1.13% | – | 4.78 | % |  | 23,059 |  |  |  | 1.13% | – | 4.78 | % |
| 2017 debt issuances of $28.7 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2022 |  | 3,250 |  |  |  | 2.68% | – | 3.10 | % |  | 3,250 |  |  |  | 2.41% | – | 2.84 | % |
| Fixed-rate 0.875% – 4.300% notes | 2019 | – | 2047 |  | 25,454 |  |  |  | 1.54% | – | 4.30 | % |  | 25,617 |  |  |  | 1.54% | – | 4.30 | % |
| 2018 debt issuance of $7.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 1.800% – 3.750% notes | 2019 | – | 2047 |  | 7,000 |  |  |  | 1.83% | – | 3.80 | % |  | 7,000 |  |  |  | 1.83% | – | 3.80 | % |
| Total term debt |  |  |  |  | 103,770 |  |  |  |  |  |  |  | 104,193 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (210 | ) |  |  |  |  |  |  | (218 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | (799 | ) |  |  |  |  |  |  | (1,456 | ) |  |  |  |  |  |
| Less: Current portion of term debt |  |  |  |  | (9,772 | ) |  |  |  |  |  |  | (8,784 | ) |  |  |  |  |  |
| Total non-current portion of term debt |  |  |  |  | $ | 92,989 |  |  |  |  |  |  |  | $ | 93,735 |  |  |  |  |  |  |
  (was, 2018-08-01, similarity 0.7278):
[0000320193-18-000100:note_history:45]
|  | Maturities |  | June 30, 2018 |  | September 30, 2017 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | — |  | $ | — |  |  |  |  |  | — | % |  | $ | 2,000 |  |  |  | 1.10% |  | 1.10 | % |
| Fixed-rate 2.400% – 3.850% notes | 2023 | – | 2043 |  | 8,500 |  |  |  | 2.44% | – | 3.91 | % |  | 12,500 |  |  |  | 1.08% | – | 3.91 | % |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 |  | 2019 |  | 1,000 |  |  |  | 2.66% |  | 2.66 | % |  | 1,000 |  |  |  | 1.61% |  | 1.61 | % |
| Fixed-rate 2.100% – 4.450% notes | 2019 | – | 2044 |  | 8,500 |  |  |  | 2.66% | – | 4.48 | % |  | 8,500 |  |  |  | 1.61% | – | 4.48 | % |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2020 |  | 1,517 |  |  |  | 1.87% | – | 2.66 | % |  | 1,549 |  |  |  | 1.56% | – | 1.87 | % |
| Fixed-rate 0.350% – 4.375% notes | 2019 | – | 2045 |  | 24,395 |  |  |  | 0.28% | – | 4.51 | % |  | 24,522 |  |  |  | 0.28% | – | 4.51 | % |
| 2016 debt issuances of $24.9 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2021 |  | 1,350 |  |  |  | 2.50% | – | 3.46 | % |  | 1,350 |  |  |  | 1.45% | – | 2.44 | % |
| Fixed-rate 1.100% – 4.650% notes | 2019 | – | 2046 |  | 23,079 |  |  |  | 1.13% | – | 4.78 | % |  | 23,645 |  |  |  | 1.13% | – | 4.78 | % |
| 2017 debt issuances of $28.7 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2022 |  | 3,250 |  |  |  | 2.43% | – | 2.87 | % |  | 3,250 |  |  |  | 1.38% | – | 1.81 | % |
| Fixed-rate 0.875% – 4.300% notes | 2019 | – | 2047 |  | 25,533 |  |  |  | 1.54% | – | 4.30 | % |  | 25,705 |  |  |  | 1.51% | – | 4.30 | % |
| First quarter 2018 debt issuance of $7.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 1.800% notes |  |  | 2019 |  | 1,000 |  |  |  |  |  | 1.83 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.000% notes |  |  | 2020 |  | 1,000 |  |  |  |  |  | 2.03 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.400% notes |  |  | 2023 |  | 750 |  |  |  |  |  | 2.66 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.750% notes |  |  | 2025 |  | 1,500 |  |  |  |  |  | 2.77 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.000% notes |  |  | 2027 |  | 1,500 |  |  |  |  |  | 3.07 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.750% notes |  |  | 2047 |  | 1,250 |  |  |  |  |  | 3.80 | % |  | — |  |  |  |  |  | — | % |
| Total term debt |  |  |  |  | 104,124 |  |  |  |  |  |  |  | 104,021 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (227 | ) |  |  |  |  |  |  | (225 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | (1,271 | ) |  |  |  |  |  |  | (93 | ) |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  |  |  | (5,498 | ) |  |  |  |  |  |  | (6,496 | ) |  |  |  |  |  |
| Total long-term debt |  |  |  |  | $ | 97,128 |  |  |  |  |  |  |  | $ | 97,207 |  |  |  |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2019-01-30):
[0000320193-19-000010:note_history:46]
Net sales disaggregated by significant products and services for the three months ended December 29, 2018 and December 30, 2017 were as follows (in millions):

- added (2019-01-30):
[0000320193-19-000010:note_history:47]
|  | Three Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |
| iPhone (1) | $ | 51,982 |  |  | $ | 61,104 |  |
| Mac (1) | 7,416 |  |  | 6,824 |  |
| iPad (1) | 6,729 |  |  | 5,755 |  |
| Wearables, Home and Accessories (1)(2) | 7,308 |  |  | 5,481 |  |
| Services (3) | 10,875 |  |  | 9,129 |  |
| Total net sales (4) | $ | 84,310 |  |  | $ | 88,293 |  |

- added (2019-01-30):
[0000320193-19-000010:note_history:48]
| (1) | Products net sales include amortization of the deferred value of unspecified software upgrade rights, which are bundled in the sales price of the respective product. |

- added (2019-01-30):
[0000320193-19-000010:note_history:49]
| (2) | Wearables, Home and Accessories net sales include sales of AirPods, Apple TV, Apple Watch, Beats® products, HomePod, iPod touch® and Apple-branded and third-party accessories. |

- added (2019-01-30):
[0000320193-19-000010:note_history:50]
| (3) | Services net sales include sales from Digital Content and Services, AppleCare®, Apple Pay, licensing and other services. Services net sales also include amortization of the deferred value of Maps, Siri and free iCloud services, which are bundled in the sales price of certain products. |

- added (2019-01-30):
[0000320193-19-000010:note_history:51]
| (4) | Includes $2.4 billion and $2.0 billion of revenue recognized in the three months ended December 29, 2018 and December 30, 2017, respectively, that was included in deferred revenue at the beginning of each respective period. |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2019-01-30):
[0000320193-19-000010:note_history:52]
Revenue Recognition

- added (2019-01-30):
[0000320193-19-000010:note_history:53]
Net sales consist of revenue from the sale of iPhone, Mac, iPad, services and other products. The Company recognizes revenue at the amount to which it expects to be entitled when control of the products or services is transferred to its customers. Control is generally transferred when the Company has a present right to payment and title and the significant risks and rewards of ownership of products or services are transferred to its customers. For most of the Company’s products net sales, control transfers when products are shipped. For the Company’s services net sales, control transfers over time as services are delivered. Payment for products and services net sales is collected within a short period of time following transfer of control or commencement of delivery of services, as applicable.

- added (2019-01-30):
[0000320193-19-000010:note_history:54]
The Company records reductions to products net sales related to future product returns, price protection and other customer incentive programs based on the Company’s expectations and historical experience.

- added (2019-01-30):
[0000320193-19-000010:note_history:55]
For arrangements with multiple performance obligations, which represent promises within an arrangement that are capable of being distinct, the Company allocates revenue to all distinct performance obligations based on their relative stand-alone selling prices (“SSP”). When available, the Company uses observable prices to determine the SSP. When observable prices are not available, SSPs are established that reflect the Company’s best estimates of what the selling prices of the performance obligations would be if they were sold regularly on a stand-alone basis. The Company’s process for estimating SSPs without observable prices considers multiple factors that may vary depending upon the unique facts and circumstances related to each performance obligation including, where applicable, prices charged by the Company for similar offerings, market trends in the pricing for similar offerings, product-specific business objectives and the estimated cost to provide the performance obligation.

- added (2019-01-30):
[0000320193-19-000010:note_history:56]
The Company has identified up to three performance obligations regularly included in arrangements involving the sale of iPhone, Mac, iPad and certain other products. The first performance obligation, which represents the substantial portion of the allocated sales price, is the hardware and bundled software delivered at the time of sale. The second performance obligation is the right to receive certain product-related bundled services, which include iCloud, Siri and Maps. The third performance obligation is the right to receive, on a when-and-if-available basis, future unspecified software upgrades relating to the software bundled with each device. The Company allocates revenue and any related discounts to these performance obligations based on their relative SSPs. Because the Company lacks observable prices for the undelivered performance obligations, the allocation of revenue is based on the Company’s estimated SSPs. Revenue allocated to the delivered hardware and bundled software is recognized when control has transferred to the customer, which generally occurs when the product is shipped. Revenue allocated to the product-related bundled services and unspecified software upgrade rights is deferred and recognized on a straight-line basis over the estimated period they are expected to be provided. Cost of sales related to delivered hardware and bundled software, including estimated warranty costs, are recognized at the time of sale. Costs incurred to provide product-related bundled services and unspecified software upgrade rights are recognized as cost of sales as incurred.

- added (2019-01-30):
[0000320193-19-000010:note_history:57]
For certain long-term service arrangements, the Company has performance obligations for services it has not yet delivered. For these arrangements, the Company does not have a right to bill for the undelivered services. The Company has determined that any unbilled consideration relates entirely to the value of the undelivered services. Accordingly, the Company has not recognized revenue, and has elected not to disclose amounts, related to these undelivered services.

- added (2019-01-30):
[0000320193-19-000010:note_history:58]
For the sale of third-party products where the Company obtains control of the product before transferring it to the customer, the Company recognizes revenue based on the gross amount billed to customers. The Company considers multiple factors when determining whether it obtains control of third-party products including, but not limited to, evaluating if it has the ability to establish the price of the product, retains inventory risk for tangible products or has the responsibility for ensuring acceptability of the product. For third-party applications sold through the App Store, Mac App Store and TV App Store and certain digital content sold through the iTunes Store, the Company does not obtain control of the product before transferring it to the customer. Therefore, the Company accounts for such sales on a net basis by recognizing in services net sales only the commission it retains.

- added (2019-01-30):
[0000320193-19-000010:note_history:59]
The Company has elected to record revenue net of taxes collected from customers that are remitted to governmental authorities, with the collected taxes recorded within other current liabilities until remitted to the relevant government authority.

- added (2019-01-30):
[0000320193-19-000010:note_history:60]
Deferred Revenue

- added (2019-01-30):
[0000320193-19-000010:note_history:61]
As of December 29, 2018 and September 29, 2018, the Company had total deferred revenue of $8.4 billion and $8.8 billion, respectively. As of December 29, 2018, the Company expects 66% of total deferred revenue to be realized in less than a year, 27% within one-to-two years, 6% within two-to-three years and 1% in greater than three years.

- added (2019-01-30):
[0000320193-19-000010:note_history:62]
Disaggregated Revenue

- added (2019-01-30):
[0000320193-19-000010:note_history:63]
Net sales disaggregated by significant products and services for the three months ended December 29, 2018 and December 30, 2017 were as follows (in millions):

- added (2019-01-30):
[0000320193-19-000010:note_history:64]
|  | Three Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |
| iPhone (1) | $ | 51,982 |  |  | $ | 61,104 |  |
| Mac (1) | 7,416 |  |  | 6,824 |  |
| iPad (1) | 6,729 |  |  | 5,755 |  |
| Wearables, Home and Accessories (1)(2) | 7,308 |  |  | 5,481 |  |
| Services (3) | 10,875 |  |  | 9,129 |  |
| Total net sales (4) | $ | 84,310 |  |  | $ | 88,293 |  |

- added (2019-01-30):
[0000320193-19-000010:note_history:65]
| (1) | Products net sales include amortization of the deferred value of unspecified software upgrade rights, which are bundled in the sales price of the respective product. |

- added (2019-01-30):
[0000320193-19-000010:note_history:66]
| (2) | Wearables, Home and Accessories net sales include sales of AirPods, Apple TV, Apple Watch, Beats® products, HomePod, iPod touch® and Apple-branded and third-party accessories. |

- added (2019-01-30):
[0000320193-19-000010:note_history:67]
| (3) | Services net sales include sales from Digital Content and Services, AppleCare®, Apple Pay, licensing and other services. Services net sales also include amortization of the deferred value of Maps, Siri and free iCloud services, which are bundled in the sales price of certain products. |

- added (2019-01-30):
[0000320193-19-000010:note_history:68]
| (4) | Includes $2.4 billion and $2.0 billion of revenue recognized in the three months ended December 29, 2018 and December 30, 2017, respectively, that was included in deferred revenue at the beginning of each respective period. |

- added (2019-01-30):
[0000320193-19-000010:note_history:69]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 11, “Segment Information and Geographic Data” for the three months ended December 29, 2018 and December 30, 2017.


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2019-01-30):
[0000320193-19-000010:note_history:70]
Net sales consist of revenue from the sale of iPhone, Mac, iPad, services and other products. The Company recognizes revenue at the amount to which it expects to be entitled when control of the products or services is transferred to its customers. Control is generally transferred when the Company has a present right to payment and title and the significant risks and rewards of ownership of products or services are transferred to its customers. For most of the Company’s products net sales, control transfers when products are shipped. For the Company’s services net sales, control transfers over time as services are delivered. Payment for products and services net sales is collected within a short period of time following transfer of control or commencement of delivery of services, as applicable.

- added (2019-01-30):
[0000320193-19-000010:note_history:71]
The Company records reductions to products net sales related to future product returns, price protection and other customer incentive programs based on the Company’s expectations and historical experience.

- added (2019-01-30):
[0000320193-19-000010:note_history:72]
For arrangements with multiple performance obligations, which represent promises within an arrangement that are capable of being distinct, the Company allocates revenue to all distinct performance obligations based on their relative stand-alone selling prices (“SSP”). When available, the Company uses observable prices to determine the SSP. When observable prices are not available, SSPs are established that reflect the Company’s best estimates of what the selling prices of the performance obligations would be if they were sold regularly on a stand-alone basis. The Company’s process for estimating SSPs without observable prices considers multiple factors that may vary depending upon the unique facts and circumstances related to each performance obligation including, where applicable, prices charged by the Company for similar offerings, market trends in the pricing for similar offerings, product-specific business objectives and the estimated cost to provide the performance obligation.

- added (2019-01-30):
[0000320193-19-000010:note_history:73]
The Company has identified up to three performance obligations regularly included in arrangements involving the sale of iPhone, Mac, iPad and certain other products. The first performance obligation, which represents the substantial portion of the allocated sales price, is the hardware and bundled software delivered at the time of sale. The second performance obligation is the right to receive certain product-related bundled services, which include iCloud, Siri and Maps. The third performance obligation is the right to receive, on a when-and-if-available basis, future unspecified software upgrades relating to the software bundled with each device. The Company allocates revenue and any related discounts to these performance obligations based on their relative SSPs. Because the Company lacks observable prices for the undelivered performance obligations, the allocation of revenue is based on the Company’s estimated SSPs. Revenue allocated to the delivered hardware and bundled software is recognized when control has transferred to the customer, which generally occurs when the product is shipped. Revenue allocated to the product-related bundled services and unspecified software upgrade rights is deferred and recognized on a straight-line basis over the estimated period they are expected to be provided. Cost of sales related to delivered hardware and bundled software, including estimated warranty costs, are recognized at the time of sale. Costs incurred to provide product-related bundled services and unspecified software upgrade rights are recognized as cost of sales as incurred.

- added (2019-01-30):
[0000320193-19-000010:note_history:74]
For certain long-term service arrangements, the Company has performance obligations for services it has not yet delivered. For these arrangements, the Company does not have a right to bill for the undelivered services. The Company has determined that any unbilled consideration relates entirely to the value of the undelivered services. Accordingly, the Company has not recognized revenue, and has elected not to disclose amounts, related to these undelivered services.

- added (2019-01-30):
[0000320193-19-000010:note_history:75]
For the sale of third-party products where the Company obtains control of the product before transferring it to the customer, the Company recognizes revenue based on the gross amount billed to customers. The Company considers multiple factors when determining whether it obtains control of third-party products including, but not limited to, evaluating if it has the ability to establish the price of the product, retains inventory risk for tangible products or has the responsibility for ensuring acceptability of the product. For third-party applications sold through the App Store, Mac App Store and TV App Store and certain digital content sold through the iTunes Store, the Company does not obtain control of the product before transferring it to the customer. Therefore, the Company accounts for such sales on a net basis by recognizing in services net sales only the commission it retains.

- added (2019-01-30):
[0000320193-19-000010:note_history:76]
The Company has elected to record revenue net of taxes collected from customers that are remitted to governmental authorities, with the collected taxes recorded within other current liabilities until remitted to the relevant government authority.
