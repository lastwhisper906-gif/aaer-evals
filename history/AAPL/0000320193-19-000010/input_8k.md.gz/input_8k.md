# AAPL 8-K — 0000320193-19-000007 filed 2019-01-29

## item codes, every 8-K on or before 2019-01-30

- 2019-01-29 0000320193-19-000007 — 2.02, 9.01
- 2019-01-02 0000320193-19-000002 — 2.02, 9.01
- 2018-11-01 0000320193-18-000142 — 2.02, 9.01
- 2018-07-31 0000320193-18-000098 — 2.02, 9.01
- 2018-05-08 0001193125-18-154948 — 8.01 — amendment of 0001193125-18-154515
- 2018-05-07 0001193125-18-154515 — 8.01, 9.01
- 2018-05-01 0000320193-18-000067 — 2.02, 9.01
- 2018-02-14 0001193125-18-045761 — 5.07, 9.01
- 2018-02-01 0000320193-18-000005 — 2.02, 9.01
- 2017-11-13 0001193125-17-341015 — 8.01, 9.01
- 2017-11-02 0000320193-17-000067 — 2.02, 9.01
- 2017-10-12 0001193125-17-308859 — 5.02
- 2017-09-12 0001193125-17-282809 — 8.01, 9.01
- 2017-08-18 0001193125-17-262261 — 8.01, 9.01
- 2017-08-01 0000320193-17-000006 — 2.02, 9.01
- 2017-06-20 0001193125-17-208226 — 8.01, 9.01
- 2017-05-24 0001193125-17-181867 — 8.01, 9.01
- 2017-05-11 0001193125-17-167400 — 8.01, 9.01
- 2017-05-02 0001628280-17-004663 — 2.02, 9.01
- 2017-03-03 0001193125-17-069853 — 8.01, 9.01
- 2017-03-01 0001193125-17-064019 — 5.07
- 2017-02-09 0001193125-17-036283 — 8.01, 9.01
- 2017-01-31 0001628280-17-000663 — 2.02, 9.01
- 2016-12-15 0001628280-16-022047 — 5.03, 9.01
- 2016-10-25 0001628280-16-020258 — 2.02, 9.01
- 2016-08-04 0001193125-16-672044 — 8.01, 9.01
- 2016-07-26 0001628280-16-017762 — 2.02, 9.01
- 2016-06-22 0001193125-16-628957 — 8.01, 9.01
- 2016-04-26 0001193125-16-556520 — 2.02, 9.01
- 2016-03-24 0001193125-16-516891 — 8.01, 9.01
- 2016-03-01 0001193125-16-488223 — 5.02, 5.07, 9.01
- 2016-02-23 0001193125-16-473562 — 8.01, 9.01
- 2016-01-26 0001193125-16-438421 — 2.02, 9.01
- 2015-12-22 0001193125-15-410853 — 5.03, 9.01
- 2015-12-17 0001193125-15-406279 — 5.02
- 2015-10-27 0001193125-15-354756 — 2.02, 9.01
- 2015-10-02 0001193125-15-336615 — 5.02
- 2015-09-17 0001193125-15-322466 — 8.01, 9.01
- 2015-07-31 0001193125-15-273023 — 8.01, 9.01
- 2015-07-21 0001193125-15-258464 — 2.02, 9.01
- 2015-06-10 0001193125-15-219298 — 8.01, 9.01
- 2015-05-13 0001193125-15-186064 — 8.01, 9.01
- 2015-04-27 0001193125-15-149607 — 7.01, 9.01
- 2015-04-27 0001193125-15-149590 — 2.02, 9.01
- 2015-03-13 0001104659-15-019336 — 5.07, 9.01
- 2015-02-09 0001193125-15-039270 — 8.01, 9.01
- 2015-01-28 0001193125-15-023732 — 8.01, 9.01
- 2015-01-27 0001193125-15-021857 — 2.02, 9.01
- 2014-11-10 0001193125-14-406296 — 8.01, 9.01
- 2014-10-20 0001193125-14-376361 — 2.02, 9.01
- 2014-07-23 0001193125-14-277193 — 8.01, 9.01
- 2014-07-22 0001193125-14-275598 — 2.02, 9.01
- 2014-07-17 0001193125-14-271698 — 5.02
- 2014-06-06 0001193125-14-228798 — 5.03, 9.01
- 2014-05-30 0001181431-14-021923 — 5.02
- 2014-05-06 0001193125-14-184969 — 8.01, 9.01
- 2014-04-23 0001193125-14-154883 — 7.01, 9.01
- 2014-04-23 0001193125-14-154871 — 2.02, 9.01
- 2014-03-05 0001193125-14-084697 — 5.02, 5.03, 5.07, 9.01
- 2014-01-27 0001193125-14-022238 — 2.02, 9.01
- 2013-10-28 0001193125-13-413498 — 2.02, 9.01
- 2013-09-23 0001181431-13-050140 — 8.01
- 2013-07-30 0001181431-13-041847 — 5.02
- 2013-07-23 0001193125-13-298914 — 2.02, 9.01
- 2013-06-21 0001193125-13-267629 — 5.02
- 2013-05-03 0001193125-13-199324 — 8.01, 9.01
- 2013-04-24 0001193125-13-170623 — 8.01, 9.01
- 2013-04-23 0001193125-13-167469 — 7.01, 9.01
- 2013-04-23 0001193125-13-167458 — 2.02, 9.01
- 2013-03-01 0001193125-13-085842 — 5.07
- 2013-01-23 0001193125-13-020783 — 2.02, 9.01
- 2012-10-25 0001193125-12-435506 — 2.02, 9.01
- 2012-07-24 0001193125-12-312355 — 2.02, 9.01
- 2012-06-28 0001181431-12-038301 — 5.02
- 2012-05-24 0001181431-12-032458 — 5.02
- 2012-04-24 0001193125-12-178928 — 2.02, 9.01
- 2012-02-27 0001193125-12-081892 — 5.07
- 2012-01-24 0001193125-12-021833 — 2.02, 9.01
- 2011-11-16 0001181431-11-056354 — 5.02
- 2011-10-18 0001193125-11-273826 — 2.02, 9.01
- 2011-10-06 0001181431-11-051976 — 8.01
- 2011-08-26 0001181431-11-047179 — 5.02
- 2011-07-19 0001193125-11-191368 — 2.02, 9.01
- 2011-06-15 0001181431-11-036782 — 5.02
- 2011-04-20 0001193125-11-103732 — 2.02, 9.01
- 2011-02-24 0001193125-11-045411 — 5.07
- 2011-01-18 0001193125-11-009392 — 2.02, 9.01
- 2011-01-18 0001181431-11-003847 — 5.02
- 2010-11-17 0001181431-10-056327 — 5.02, 5.03, 9.01
- 2010-10-18 0001193125-10-230992 — 2.02, 9.01
- 2010-07-20 0001193125-10-161807 — 2.02, 9.01
- 2010-04-20 0001193125-10-087786 — 2.02, 9.01
- 2010-03-12 0001181431-10-016054 — 5.02
- 2010-03-01 0001193125-10-044765 — 5.02, 5.07, 9.01
- 2010-01-25 0001193125-10-012096 — 2.02, 9.01
- 2009-10-19 0001193125-09-209633 — 2.02, 9.01
- 2009-08-04 0001181431-09-037492 — 5.02
- 2009-07-21 0001193125-09-152290 — 2.02, 9.01
- 2009-06-02 0001181431-09-028400 — 5.03
- 2009-04-22 0001193125-09-084599 — 2.02, 9.01
- 2009-02-27 0001181431-09-012161 — 4.01
- 2009-01-21 0001193125-09-009009 — 2.02, 9.01
- 2009-01-16 0001181431-09-003017 — 5.02
- 2008-10-21 0001193125-08-213642 — 2.02, 9.01
- 2008-08-26 0001181431-08-050059 — 5.03
- 2008-07-21 0001193125-08-154381 — 2.02, 9.01
- 2008-06-09 0001181431-08-037620 — 8.01
- 2008-04-23 0001193125-08-088001 — 2.02, 9.01
- 2008-01-22 0001193125-08-009715 — 2.02, 9.01
- 2008-01-15 0001181431-08-003342 — 2.02, 8.01
- 2008-01-08 0001181431-08-002372 — 5.02
- 2007-10-22 0001104659-07-076142 — 2.02, 9.01
- 2007-07-25 0001104659-07-056111 — 2.02, 9.01
- 2007-05-16 0001104659-07-040672 — 5.02, 9.01
- 2007-04-25 0001104659-07-031354 — 2.02, 9.01
- 2007-04-24 0001104659-07-030938 — 8.01, 9.01
- 2007-02-21 0001104659-07-012760 — 5.03, 9.01
- 2007-01-17 0001104659-07-002905 — 2.02, 9.01
- 2007-01-10 0001104659-07-001648 — 5.03, 9.01
- 2006-10-27 0001104659-06-069015 — 8.01
- 2006-10-18 0001104659-06-067275 — 2.02, 9.01
- 2006-10-04 0001104659-06-064935 — 5.02, 8.01, 9.01
- 2006-09-01 0001104659-06-058808 — 1.01, 5.02, 5.03, 9.01
- 2006-08-11 0001104659-06-054118 — 2.02, 3.01, 9.01
- 2006-08-04 0001104659-06-051302 — 2.02, 4.02, 9.01
- 2006-07-19 0001104659-06-047739 — 2.02, 9.01
- 2006-04-21 0001181431-06-024759 — 1.01
- 2006-04-19 0001104659-06-025992 — 2.02, 9.01
- 2006-01-18 0001104659-06-002690 — 2.02, 9.01
- 2006-01-10 0001104659-06-001428 — 2.02
- 2005-12-19 0001181431-05-067468 — 1.01
- 2005-10-14 0001181431-05-056604 — 5.02
- 2005-10-11 0001104659-05-048094 — 2.02, 9.01
- 2005-08-26 0001181431-05-049163 — 1.01
- 2005-08-15 0001181431-05-046871 — 1.01
- 2005-07-13 0001104659-05-032297 — 2.02, 9.01
- 2005-06-06 0001181431-05-033177 — 8.01
- 2005-04-26 0001181431-05-023450 — 1.01
- 2005-04-13 0001104659-05-016307 — 2.02, 9.01
- 2005-03-02 0001181431-05-013840 — 3.03, 5.03
- 2005-02-11 0001104659-05-005507 — 8.01
- 2005-01-12 0001104659-05-001183 — 2.02, 9.01
- 2005-01-11 0001104659-05-001049 — 2.02
- 2004-10-13 0001104659-04-030400 — 2.02, 9.01
- 2004-07-14 0001104659-04-019574 — 12, 7
- 2004-04-14 0001104659-04-010122 — 12, 7
- 2004-01-14 0001104659-04-000896 — 12, 7
- 2003-10-15 0001104659-03-022879 — 12, 7
- 2003-07-16 0001104659-03-014913 — 7, 9
- 2003-04-16 0001047469-03-013617 — 7, 9
- 2003-03-21 0001104659-03-004649 — 5, 7
- 2002-08-13 0000912057-02-031595 — 5, 7
- 2002-08-05 0000912057-02-029692 — 5, 7
- 2000-01-24 0000912057-00-002128 — 5, 7
- 1999-09-07 0000320193-99-000010 — 2
- 1999-07-16 0000320193-99-000007 — 2
- 1998-12-23 0000320193-98-000010 — 1
- 1998-01-08 0000320193-98-000001 — 2
- 1997-09-25 0000320193-97-000019 — 2
- 1997-09-25 0000320193-97-000018 — 2
- 1997-09-05 0000320193-97-000016 — 2
- 1997-07-28 0000320193-97-000012 — 4
- 1997-04-25 0000320193-97-000009 — 5
- 1997-04-10 0000320193-97-000007 — 7
- 1996-12-24 0000320193-96-000027 — 7
- 1996-12-23 0000320193-96-000025 — 4 — amendment of 0000320193-96-000021
- 1996-12-13 0000320193-96-000021 — 4
- 1996-10-28 0000912057-96-023874 — 5, 7
- 1996-06-17 0000320193-96-000014 — 1
- 1996-04-12 0000320193-96-000006 — 1

## late-filing notifications on or before 2019-01-30

- 2006-12-15 0001104659-06-081617 — NT 10-K, for the period ended 2006-09-30
- 2006-08-11 0001104659-06-053743 — NT 10-Q, for the period ended 2006-07-01

## item 2.02 — earnings release, exhibit 99.1

[0000320193-19-000007:8k_2_02:1]
EX-99.1
2
a8-kexhibit991q12019122920.htm
EXHIBIT 99.1

[0000320193-19-000007:8k_2_02:2]
Exhibit

[0000320193-19-000007:8k_2_02:3]
Exhibit 99.1

[0000320193-19-000007:8k_2_02:4]
Apple Reports First Quarter Results

[0000320193-19-000007:8k_2_02:5]
Services, Mac and Wearables Set New All-Time Revenue Records

[0000320193-19-000007:8k_2_02:6]
EPS Reaches All-Time High at $4.18

[0000320193-19-000007:8k_2_02:7]
CUPERTINO, California — January 29, 2019 — Apple® today announced financial results for its fiscal 2019 first quarter ended December 29, 2018. The Company posted quarterly revenue of $84.3 billion, a decline of 5 percent from the year-ago quarter, and quarterly earnings per diluted share of $4.18, up 7.5 percent. International sales accounted for 62 percent of the quarter’s revenue.

[0000320193-19-000007:8k_2_02:8]
Revenue from iPhone® declined 15 percent from the prior year, while total revenue from all other products and services grew 19 percent. Services revenue reached an all-time high of $10.9 billion, up 19 percent over the prior year. Revenue from Mac® and Wearables, Home and Accessories also reached all-time highs, growing 9 percent and 33 percent, respectively, and revenue from iPad® grew 17 percent.

[0000320193-19-000007:8k_2_02:9]
“While it was disappointing to miss our revenue guidance, we manage Apple for the long term, and this quarter’s results demonstrate that the underlying strength of our business runs deep and wide,” said Tim Cook, Apple’s CEO. “Our active installed base of devices reached an all-time high of 1.4 billion in the first quarter, growing in each of our geographic segments. That’s a great testament to the satisfaction and loyalty of our customers, and it’s driving our Services business to new records thanks to our large and fast-growing ecosystem.”

[0000320193-19-000007:8k_2_02:10]
“We generated very strong operating cash flow of $26.7 billion during the December quarter and set an all-time EPS record of $4.18,” said Luca Maestri, Apple’s CFO. “We returned over $13 billion to our investors during the quarter through dividends and share repurchases. Our net cash balance was $130 billion at the end of the quarter, and we continue to target a net cash neutral position over time.”

[0000320193-19-000007:8k_2_02:11]
Apple is providing the following guidance for its fiscal 2019 second quarter:

[0000320193-19-000007:8k_2_02:12]
| • | revenue between $55 billion and $59 billion |

[0000320193-19-000007:8k_2_02:13]
| • | gross margin between 37 percent and 38 percent |

[0000320193-19-000007:8k_2_02:14]
| • | operating expenses between $8.5 billion and $8.6 billion |

[0000320193-19-000007:8k_2_02:15]
| • | other income/(expense) of $300 million |

[0000320193-19-000007:8k_2_02:16]
| • | tax rate of approximately 17 percent |

[0000320193-19-000007:8k_2_02:17]
Apple’s board of directors has declared a cash dividend of $0.73 per share of the Company’s common stock. The dividend is payable on February 14, 2019 to shareholders of record as of the close of business on February 11, 2019.

[0000320193-19-000007:8k_2_02:18]
Apple will provide live streaming of its Q1 2019 financial results conference call beginning at 2:00 p.m. PST on January 29, 2019 at www.apple.com/investor/earnings-call/. This webcast will also be available for replay for approximately two weeks thereafter.

[0000320193-19-000007:8k_2_02:19]
Apple periodically provides information for investors on its corporate website, apple.com, and its investors relations website, investor.apple.com. This includes press releases and other information about financial performance, reports filed or furnished with the SEC, information on corporate governance and details related to its annual meeting of shareholders.

[0000320193-19-000007:8k_2_02:20]
Apple revolutionized personal technology with the introduction of the Macintosh in 1984. Today, Apple leads the world in innovation with iPhone, iPad, Mac, Apple Watch and Apple TV. Apple’s four software platforms — iOS, macOS, watchOS and tvOS — provide seamless experiences across all Apple devices and empower people with breakthrough services including the App Store, Apple Music, Apple Pay and iCloud. Apple’s more than 100,000 employees are dedicated to making the best products on earth, and to leaving the world better than we found it.

[0000320193-19-000007:8k_2_02:21]
Press Contact:

[0000320193-19-000007:8k_2_02:22]
Kristin Huguet

[0000320193-19-000007:8k_2_02:23]
Apple

[0000320193-19-000007:8k_2_02:24]
khuguet@apple.com

[0000320193-19-000007:8k_2_02:25]
(408) 974-2414

[0000320193-19-000007:8k_2_02:26]
Investor Relations Contacts:

[0000320193-19-000007:8k_2_02:27]
Nancy Paxton

[0000320193-19-000007:8k_2_02:28]
Apple

[0000320193-19-000007:8k_2_02:29]
paxton1@apple.com

[0000320193-19-000007:8k_2_02:30]
(408) 974-5420

[0000320193-19-000007:8k_2_02:31]
Matt Blake

[0000320193-19-000007:8k_2_02:32]
Apple

[0000320193-19-000007:8k_2_02:33]
mattblake@apple.com

[0000320193-19-000007:8k_2_02:34]
(408) 974-7406

[0000320193-19-000007:8k_2_02:35]
NOTE TO EDITORS: For additional information visit Apple Newsroom (www.apple.com/newsroom), or call Apple’s Media Helpline at (408) 974-2042.

[0000320193-19-000007:8k_2_02:36]
© 2019 Apple Inc. All rights reserved. Apple, the Apple logo, iPhone, Mac and iPad are trademarks of Apple Inc. Other company and product names may be trademarks of their respective owners.

[0000320193-19-000007:8k_2_02:37]
Apple Inc.

[0000320193-19-000007:8k_2_02:38]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS (Unaudited)

[0000320193-19-000007:8k_2_02:39]
(In millions, except number of shares which are reflected in thousands and per share amounts)

[0000320193-19-000007:8k_2_02:40]
|  | Three Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |
| Net sales: |  |  |  |
| Products | $ | 73,435 |  |  | $ | 79,164 |  |
| Services | 10,875 |  |  | 9,129 |  |
| Total net sales (1) | 84,310 |  |  | 88,293 |  |
| Cost of sales: |  |  |  |
| Products | 48,238 |  |  | 50,575 |  |
| Services | 4,041 |  |  | 3,806 |  |
| Total cost of sales | 52,279 |  |  | 54,381 |  |
| Gross margin | 32,031 |  |  | 33,912 |  |
| Operating expenses: |  |  |  |
| Research and development | 3,902 |  |  | 3,407 |  |
| Selling, general and administrative | 4,783 |  |  | 4,231 |  |
| Total operating expenses | 8,685 |  |  | 7,638 |  |
| Operating income | 23,346 |  |  | 26,274 |  |
| Other income/(expense), net | 560 |  |  | 756 |  |
| Income before provision for income taxes | 23,906 |  |  | 27,030 |  |
| Provision for income taxes | 3,941 |  |  | 6,965 |  |
| Net income | $ | 19,965 |  |  | $ | 20,065 |  |
| Earnings per share: |  |  |  |
| Basic | $ | 4.22 |  |  | $ | 3.92 |  |
| Diluted | $ | 4.18 |  |  | $ | 3.89 |  |
| Shares used in computing earnings per share: |  |  |  |
| Basic | 4,735,820 |  |  | 5,112,877 |  |
| Diluted | 4,773,252 |  |  | 5,157,787 |  |
| (1) Net sales by reportable segment: |  |  |  |
| Americas | $ | 36,940 |  |  | $ | 35,193 |  |
| Europe | 20,363 |  |  | 21,054 |  |
| Greater China | 13,169 |  |  | 17,956 |  |
| Japan | 6,910 |  |  | 7,237 |  |
| Rest of Asia Pacific | 6,928 |  |  | 6,853 |  |
| Total net sales | $ | 84,310 |  |  | $ | 88,293 |  |
| (1) Net sales by category: |  |  |  |
| iPhone | $ | 51,982 |  |  | $ | 61,104 |  |
| Mac | 7,416 |  |  | 6,824 |  |
| iPad | 6,729 |  |  | 5,755 |  |
| Wearables, Home and Accessories | 7,308 |  |  | 5,481 |  |
| Services | 10,875 |  |  | 9,129 |  |
| Total net sales | $ | 84,310 |  |  | $ | 88,293 |  |

[0000320193-19-000007:8k_2_02:41]
Apple Inc.

[0000320193-19-000007:8k_2_02:42]
CONDENSED CONSOLIDATED BALANCE SHEETS (Unaudited)

[0000320193-19-000007:8k_2_02:43]
(In millions, except number of shares which are reflected in thousands and par value)

[0000320193-19-000007:8k_2_02:44]
|  | December 29, 2018 |  | September 29, 2018 |
| ASSETS: |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 44,771 |  |  | $ | 25,913 |  |
| Marketable securities | 41,656 |  |  | 40,388 |  |
| Accounts receivable, net | 18,077 |  |  | 23,186 |  |
| Inventories | 4,988 |  |  | 3,956 |  |
| Vendor non-trade receivables | 18,904 |  |  | 25,809 |  |
| Other current assets | 12,432 |  |  | 12,087 |  |
| Total current assets | 140,828 |  |  | 131,339 |  |
| Non-current assets: |  |  |  |
| Marketable securities | 158,608 |  |  | 170,799 |  |
| Property, plant and equipment, net | 39,597 |  |  | 41,304 |  |
| Other non-current assets | 34,686 |  |  | 22,283 |  |
| Total non-current assets | 232,891 |  |  | 234,386 |  |
| Total assets | $ | 373,719 |  |  | $ | 365,725 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY: |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 44,293 |  |  | $ | 55,888 |  |
| Other current liabilities | 36,703 |  |  | 33,327 |  |
| Deferred revenue | 5,546 |  |  | 5,966 |  |
| Commercial paper | 11,969 |  |  | 11,964 |  |
| Term debt | 9,772 |  |  | 8,784 |  |
| Total current liabilities | 108,283 |  |  | 115,929 |  |
| Non-current liabilities: |  |  |  |
| Term debt | 92,989 |  |  | 93,735 |  |
| Other non-current liabilities | 54,555 |  |  | 48,914 |  |
| Total non-current liabilities | 147,544 |  |  | 142,649 |  |
| Total liabilities | 255,827 |  |  | 258,578 |  |
| Commitments and contingencies |  |  |  |
| Shareholders’ equity: |  |  |  |
| Common stock and additional paid-in capital, $0.00001 par value: 12,600,000 shares authorized; 4,729,803 and 4,754,986 shares issued and outstanding, respectively | 40,970 |  |  | 40,201 |  |
| Retained earnings | 80,510 |  |  | 70,400 |  |
| Accumulated other comprehensive income/(loss) | (3,588 | ) |  | (3,454 | ) |
| Total shareholders’ equity | 117,892 |  |  | 107,147 |  |
| Total liabilities and shareholders’ equity | $ | 373,719 |  |  | $ | 365,725 |  |

[0000320193-19-000007:8k_2_02:45]
Apple Inc.

[0000320193-19-000007:8k_2_02:46]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (Unaudited)

[0000320193-19-000007:8k_2_02:47]
(In millions)

[0000320193-19-000007:8k_2_02:48]
|  | Three Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |
| Cash and cash equivalents, beginning balances | $ | 25,913 |  |  | $ | 20,289 |  |
| Operating activities: |  |  |  |
| Net income | 19,965 |  |  | 20,065 |  |
| Adjustments to reconcile net income to cash generated by operating activities: |  |  |  |
| Depreciation and amortization | 3,395 |  |  | 2,745 |  |
| Share-based compensation expense | 1,559 |  |  | 1,296 |  |
| Deferred income tax expense/(benefit) | 53 |  |  | (33,737 | ) |
| Other | (54 | ) |  | (11 | ) |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | 5,130 |  |  | (5,570 | ) |
| Inventories | (1,076 | ) |  | 434 |  |
| Vendor non-trade receivables | 6,905 |  |  | (9,660 | ) |
| Other current and non-current assets | (886 | ) |  | (197 | ) |
| Accounts payable | (8,501 | ) |  | 12,602 |  |
| Deferred revenue | (370 | ) |  | 569 |  |
| Other current and non-current liabilities | 570 |  |  | 39,757 |  |
| Cash generated by operating activities | 26,690 |  |  | 28,293 |  |
| Investing activities: |  |  |  |
| Purchases of marketable securities | (7,077 | ) |  | (41,272 | ) |
| Proceeds from maturities of marketable securities | 7,203 |  |  | 14,048 |  |
| Proceeds from sales of marketable securities | 9,723 |  |  | 16,801 |  |
| Payments for acquisition of property, plant and equipment | (3,355 | ) |  | (2,810 | ) |
| Payments made in connection with business acquisitions, net | (167 | ) |  | (173 | ) |
| Purchases of non-marketable securities | (427 | ) |  | (141 | ) |
| Other | (56 | ) |  | (43 | ) |
| Cash generated by/(used in) investing activities | 5,844 |  |  | (13,590 | ) |
| Financing activities: |  |  |  |
| Payments for taxes related to net share settlement of equity awards | (1,318 | ) |  | (1,038 | ) |
| Payments for dividends and dividend equivalents | (3,568 | ) |  | (3,339 | ) |
| Repurchases of common stock | (8,796 | ) |  | (10,095 | ) |
| Proceeds from issuance of term debt, net | — |  |  | 6,969 |  |
| Change in commercial paper, net | 6 |  |  | 2 |  |
| Cash used in financing activities | (13,676 | ) |  | (7,501 | ) |
| Increase/(Decrease) in cash and cash equivalents | 18,858 |  |  | 7,202 |  |
| Cash and cash equivalents, ending balances | $ | 44,771 |  |  | $ | 27,491 |  |
| Supplemental cash flow disclosure: |  |  |  |
| Cash paid for income taxes, net | $ | 4,916 |  |  | $ | 3,551 |  |
| Cash paid for interest | $ | 836 |  |  | $ | 623 |  |
