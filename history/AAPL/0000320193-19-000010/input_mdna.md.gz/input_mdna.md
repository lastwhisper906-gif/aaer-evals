# AAPL MD&A — 0000320193-19-000010


## mdna

[0000320193-19-000010:mdna:1]
[same as prior period, unchanged from 0000320193-18-000100:mdna:1]

[0000320193-19-000010:mdna:2]
[same as prior period, unchanged from 0000320193-18-000100:mdna:2]

[0000320193-19-000010:mdna:3]
The Company’s Annual Reports on Form 10-K, Quarterly Reports on Form 10-Q, Current Reports on Form 8-K, and amendments to reports filed pursuant to Sections 13(a) and 15(d) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), are filed with the SEC. The Company is subject to the informational requirements of the Exchange Act and files or furnishes reports, proxy statements and other information with the SEC. Such reports and other information filed by the Company with the SEC are available free of charge at investor.apple.com/investor-relations/sec-filings/default.aspx when such reports are available on the SEC’s website. The SEC maintains an internet site that contains reports, proxy and information statements, and other information regarding issuers that file electronically with the SEC at www.sec.gov. The Company periodically provides other information for investors on its corporate website, www.apple.com, and its investor relations website, investor.apple.com. This includes press releases and other information about financial performance, information on corporate governance and details related to the Company’s annual meeting of shareholders. The information contained on the websites referenced in this Form 10-Q is not incorporated by reference into this filing. Further, the Company’s references to website URLs are intended to be inactive textual references only.

[0000320193-19-000010:mdna:4]
[same as prior period, unchanged from 0000320193-18-000100:mdna:4]

[0000320193-19-000010:mdna:5]
The Company designs, manufactures and markets mobile communication and media devices and personal computers, and sells a variety of related software, services, accessories and third-party digital content and applications. The Company’s products and services include iPhone, Mac, iPad, Apple Watch, AirPods, Apple TV, HomePod, a portfolio of consumer and professional software applications, iOS, macOS, watchOS and tvOS operating systems, iCloud, Apple Pay and a variety of accessory, service and support offerings. The Company sells and delivers digital content and applications through the iTunes Store, App Store, Mac App Store, TV App Store, Book Store and Apple Music (collectively “Digital Content and Services”). The Company sells its products worldwide through its retail stores, online stores and direct sales force, as well as through third-party cellular network carriers, wholesalers, retailers and resellers. In addition, the Company sells a variety of third-party Apple-compatible products, including application software and various accessories, through its retail and online stores. The Company sells to consumers, small and mid-sized businesses and education, enterprise and government customers.

[0000320193-19-000010:mdna:6]
[same as prior period, unchanged from 0000320193-18-000100:mdna:6]

[0000320193-19-000010:mdna:7]
The Company is committed to bringing the best user experience to its customers through its innovative hardware, software and services. The Company’s business strategy leverages its unique ability to design and develop its own operating systems, hardware, application software and services to provide its customers products and solutions with innovative design, superior ease-of-use and seamless integration. As part of its strategy, the Company continues to expand its platform for the discovery and delivery of digital content and applications through its Digital Content and Services, which allows customers to discover and download or stream digital content, iOS, Mac, Apple Watch and Apple TV applications, and books through either a Mac or Windows personal computer or through iPhone, iPad and iPod touch devices, Apple TV, Apple Watch and HomePod. The Company also supports a community for the development of third-party software and hardware products and digital content that complement the Company’s offerings. The Company believes a high-quality buying experience with knowledgeable salespersons who can convey the value of the Company’s products and services greatly enhances its ability to attract and retain customers. Therefore, the Company’s strategy also includes building and expanding its own retail and online stores and its third-party distribution network to effectively reach more customers and provide them with a high-quality sales and post-sales support experience. The Company believes ongoing investment in research and development (“R&D”), marketing and advertising is critical to the development and sale of innovative products, services and technologies.

[0000320193-19-000010:mdna:8]
[same as prior period, unchanged from 0000320193-18-000100:mdna:8]

[0000320193-19-000010:mdna:9]
The Company has historically experienced higher net sales in its first quarter compared to other quarters in its fiscal year due in part to seasonal holiday demand. Additionally, new product introductions can significantly impact product sales, product costs and operating expenses. Product introductions can also impact the Company’s net sales to its indirect distribution channels as these channels are filled with new product inventory following a product introduction, and channel inventory of a particular product often declines as the next related major product launch approaches. Net sales can also be affected when consumers and distributors anticipate a product introduction. However, neither historical seasonal patterns nor historical patterns of product introductions should be considered reliable indicators of the Company’s future pattern of product introductions, future net sales or financial performance.

[0000320193-19-000010:mdna:10]
First Quarter Fiscal 2019 Highlights

[0000320193-19-000010:mdna:11]
Total net sales decreased 5% or $4.0 billion during the first quarter of 2019 compared to the same quarter in 2018, driven by lower iPhone net sales, partially offset primarily by higher Wearables, Home and Accessories and Services net sales. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on net sales during the first quarter of 2019.

[0000320193-19-000010:mdna:12]
The Company began shipping iPhone XR in October 2018. During the first quarter of 2019, the Company introduced two new versions of iPad Pro® as well as a new Apple Pencil® and Smart Keyboard Folio™, all of which began shipping in November 2018. The Company also introduced a new version of MacBook Air® and a new Mac mini®, both of which began shipping in November 2018.

[0000320193-19-000010:mdna:13]
The Company repurchased $8.2 billion of its common stock and paid dividends and dividend equivalents of $3.6 billion during the first quarter of 2019.

[0000320193-19-000010:mdna:14]
Products and Services Performance

[0000320193-19-000010:mdna:15]
Beginning in the first quarter of 2019, the Company classified the amortization of the deferred value of Maps, Siri and free iCloud services, which are bundled in the sales price of iPhone, Mac, iPad and certain other products, in Services net sales. Historically, the Company classified the amortization of these amounts in Products net sales consistent with its management reporting framework. As a result, Products and Services net sales information for the first quarter of 2018 was reclassified to conform to the 2019 presentation.

[0000320193-19-000010:mdna:16]
The following table shows net sales by category for the three months ended December 29, 2018 and December 30, 2017 (dollars in millions):

[0000320193-19-000010:mdna:17]
|  | Three Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |  | Change |
| Net sales by category: |  |  |  |  |  |
| iPhone (1) | $ | 51,982 |  |  | $ | 61,104 |  |  | (15 | )% |
| Mac (1) | 7,416 |  |  | 6,824 |  |  | 9 | % |
| iPad (1) | 6,729 |  |  | 5,755 |  |  | 17 | % |
| Wearables, Home and Accessories (1)(2) | 7,308 |  |  | 5,481 |  |  | 33 | % |
| Services (3) | 10,875 |  |  | 9,129 |  |  | 19 | % |
| Total net sales | $ | 84,310 |  |  | $ | 88,293 |  |  | (5 | )% |

[0000320193-19-000010:mdna:18]
| (1) | Products net sales include amortization of the deferred value of unspecified software upgrade rights, which are bundled in the sales price of the respective product. |

[0000320193-19-000010:mdna:19]
| (2) | Wearables, Home and Accessories net sales include sales of AirPods, Apple TV, Apple Watch, Beats products, HomePod, iPod touch and Apple-branded and third-party accessories. |

[0000320193-19-000010:mdna:20]
| (3) | Services net sales include sales from Digital Content and Services, AppleCare, Apple Pay, licensing and other services. Services net sales also include amortization of the deferred value of Maps, Siri and free iCloud services, which are bundled in the sales price of certain products. |

[0000320193-19-000010:mdna:21]
[same as prior period, unchanged from 0000320193-18-000100:mdna:23]

[0000320193-19-000010:mdna:22]
iPhone net sales decreased during the first quarter of 2019 compared to the same quarter in 2018 due to lower iPhone unit sales in all the reportable geographic segments.

[0000320193-19-000010:mdna:23]
[same as prior period, unchanged from 0000320193-18-000100:mdna:31]

[0000320193-19-000010:mdna:24]
Mac net sales increased during the first quarter of 2019 compared to the same quarter in 2018 due primarily to higher net sales of MacBook Air.

[0000320193-19-000010:mdna:25]
[same as prior period, unchanged from 0000320193-18-000100:mdna:27]

[0000320193-19-000010:mdna:26]
iPad net sales increased during the first quarter of 2019 compared to the same quarter in 2018 due primarily to higher net sales of iPad Pro.

[0000320193-19-000010:mdna:27]
Wearables, Home and Accessories

[0000320193-19-000010:mdna:28]
Wearables, Home and Accessories net sales increased during the first quarter of 2019 compared to the same quarter in 2018 due primarily to higher net sales of Apple Watch and AirPods.

[0000320193-19-000010:mdna:29]
[same as prior period, unchanged from 0000320193-18-000100:mdna:35]

[0000320193-19-000010:mdna:30]
Services net sales increased during the first quarter of 2019 compared to the same quarter in 2018 due primarily to licensing, the App Store and AppleCare.

[0000320193-19-000010:mdna:31]
[same as prior period, unchanged from 0000320193-18-000100:mdna:39]

[0000320193-19-000010:mdna:32]
The Company manages its business primarily on a geographic basis. The Company’s reportable segments consist of the Americas, Europe, Greater China, Japan and Rest of Asia Pacific. Americas includes both North and South America. Europe includes European countries, as well as India, the Middle East and Africa. Greater China includes China, Hong Kong and Taiwan. Rest of Asia Pacific includes Australia and those Asian countries not included in the Company’s other reportable segments. Although the reportable segments provide similar hardware and software products and similar services, each one is managed separately to better align with the location of the Company’s customers and distribution partners and the unique market dynamics of each geographic region. Further information regarding the Company’s reportable segments can be found in Part I, Item 1 of this Form 10-Q in the Notes to Condensed Consolidated Financial Statements in Note 11, “Segment Information and Geographic Data.”

[0000320193-19-000010:mdna:33]
The following table shows net sales by reportable segment for the three months ended December 29, 2018 and December 30, 2017 (dollars in millions):

[0000320193-19-000010:mdna:34]
|  | Three Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |  | Change |
| Net sales by reportable segment: |  |  |  |  |  |
| Americas | $ | 36,940 |  |  | $ | 35,193 |  |  | 5 | % |
| Europe | 20,363 |  |  | 21,054 |  |  | (3 | )% |
| Greater China | 13,169 |  |  | 17,956 |  |  | (27 | )% |
| Japan | 6,910 |  |  | 7,237 |  |  | (5 | )% |
| Rest of Asia Pacific | 6,928 |  |  | 6,853 |  |  | 1 | % |
| Total net sales | $ | 84,310 |  |  | $ | 88,293 |  |  | (5 | )% |

[0000320193-19-000010:mdna:35]
[same as prior period, unchanged from 0000320193-18-000100:mdna:41]

[0000320193-19-000010:mdna:36]
Americas net sales increased during the first quarter of 2019 compared to the same quarter in 2018 due primarily to higher Wearables, Home and Accessories and Services net sales, partially offset by lower iPhone net sales. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on Americas net sales during the first quarter of 2019.

[0000320193-19-000010:mdna:37]
[same as prior period, unchanged from 0000320193-18-000100:mdna:45]

[0000320193-19-000010:mdna:38]
Europe net sales decreased during the first quarter of 2019 compared to the same quarter in 2018 due primarily to lower iPhone net sales, partially offset by higher Wearables, Home and Accessories and Services net sales. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on Europe net sales during the first quarter of 2019.

[0000320193-19-000010:mdna:39]
[same as prior period, unchanged from 0000320193-18-000100:mdna:49]

[0000320193-19-000010:mdna:40]
Greater China net sales decreased during the first quarter of 2019 compared to the same quarter in 2018 due primarily to lower iPhone net sales.

[0000320193-19-000010:mdna:41]
[same as prior period, unchanged from 0000320193-18-000100:mdna:53]

[0000320193-19-000010:mdna:42]
Japan net sales decreased during the first quarter of 2019 compared to the same quarter in 2018 due primarily to lower iPhone net sales, partially offset by higher Services and iPad net sales.

[0000320193-19-000010:mdna:43]
[same as prior period, unchanged from 0000320193-18-000100:mdna:57]

[0000320193-19-000010:mdna:44]
Rest of Asia Pacific net sales during the first quarter of 2019 were generally flat compared to the same quarter in 2018, as higher Wearables, Home and Accessories and Services net sales were offset by lower iPhone net sales. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on Rest of Asia Pacific net sales during the first quarter of 2019.

[0000320193-19-000010:mdna:45]
[same as prior period, unchanged from 0000320193-18-000100:mdna:61]

[0000320193-19-000010:mdna:46]
Products and services gross margin and gross margin percentage for the three months ended December 29, 2018 and December 30, 2017 were as follows (dollars in millions):

[0000320193-19-000010:mdna:47]
|  | Three Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |
| Gross margin: |  |  |  |
| Products | $ | 25,197 |  |  | $ | 28,589 |  |
| Services | 6,834 |  |  | 5,323 |  |
| Total gross margin | $ | 32,031 |  |  | $ | 33,912 |  |
| Gross margin percentage: |  |  |  |
| Products | 34.3 | % |  | 36.1 | % |
| Services | 62.8 | % |  | 58.3 | % |
| Total gross margin percentage | 38.0 | % |  | 38.4 | % |

[0000320193-19-000010:mdna:48]
Products Gross Margin

[0000320193-19-000010:mdna:49]
Products gross margin decreased during the first quarter of 2019 compared to the same quarter in 2018 due primarily to lower iPhone unit sales and the weakness in foreign currencies relative to the U.S. dollar, partially offset by higher net sales of Mac, iPad and Wearables. Year-over-year products gross margin percentage decreased during the first quarter of 2019 due primarily to a different product mix and the impact of lower iPhone unit sales on the Company’s products fixed cost structure.

[0000320193-19-000010:mdna:50]
Services Gross Margin

[0000320193-19-000010:mdna:51]
Services gross margin increased during the first quarter of 2019 compared to the same quarter in 2018 due primarily to a different services mix. Year-over-year services gross margin percentage increased during the first quarter of 2019 due primarily to a favorable mix of services with higher margins and the impact of higher services net sales on the Company’s services fixed cost structure.

[0000320193-19-000010:mdna:52]
The Company anticipates total gross margin percentage during the second quarter of 2019 to be between 37.0% and 38.0%. The foregoing statement regarding the Company’s expected total gross margin percentage in the second quarter of 2019 is forward-looking and could differ from actual results. The Company’s future gross margins can be impacted by multiple factors including, but not limited to, those set forth in Part II, Item 1A of this Form 10-Q under the heading “Risk Factors” and those described in this paragraph. In general, the Company believes gross margins will be subject to volatility and remain under downward pressure due to a variety of factors, including: continued industry-wide global product pricing pressures and product pricing actions that the Company may take in response to such pressures; increased competition; the Company’s ability to effectively stimulate demand for certain of its products; compressed product life cycles; potential increases in the cost of components and outside manufacturing services; the Company’s ability to manage product quality and warranty costs effectively; shifts in the mix of products and services, or in the geographic, currency or channel mix; fluctuations in exchange rates; and costs associated with the Company’s frequent introductions and transitions of products and services.

[0000320193-19-000010:mdna:53]
[same as prior period, unchanged from 0000320193-18-000100:mdna:67]

[0000320193-19-000010:mdna:54]
Operating expenses for the three months ended December 29, 2018 and December 30, 2017 were as follows (dollars in millions):

[0000320193-19-000010:mdna:55]
|  | Three Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |
| Research and development | $ | 3,902 |  |  | $ | 3,407 |  |
| Percentage of total net sales | 5 | % |  | 4 | % |
| Selling, general and administrative | $ | 4,783 |  |  | $ | 4,231 |  |
| Percentage of total net sales | 6 | % |  | 5 | % |
| Total operating expenses | $ | 8,685 |  |  | $ | 7,638 |  |
| Percentage of total net sales | 10 | % |  | 9 | % |

[0000320193-19-000010:mdna:56]
[same as prior period, unchanged from 0000320193-18-000100:mdna:70]

[0000320193-19-000010:mdna:57]
The growth in R&D expense during the first quarter of 2019 compared to the same quarter in 2018 was driven primarily by increases in headcount-related expenses and infrastructure-related costs. The Company continues to believe that focused investments in R&D are critical to its future growth and competitive position in the marketplace, and to the development of new and updated products and services that are central to the Company’s core business strategy.

[0000320193-19-000010:mdna:58]
[same as prior period, unchanged from 0000320193-18-000100:mdna:72]

[0000320193-19-000010:mdna:59]
The growth in selling, general and administrative expense during the first quarter of 2019 compared to the same quarter in 2018 was driven primarily by increases in professional fees and headcount-related expenses.

[0000320193-19-000010:mdna:60]
[same as prior period, unchanged from 0000320193-18-000100:mdna:74]

[0000320193-19-000010:mdna:61]
Other income/(expense), net for the three months ended December 29, 2018 and December 30, 2017 was as follows (dollars in millions):

[0000320193-19-000010:mdna:62]
|  | Three Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |  | Change |
| Interest and dividend income | $ | 1,307 |  |  | $ | 1,452 |  |  |  |
| Interest expense | (890 | ) |  | (734 | ) |  |  |
| Other income, net | 143 |  |  | 38 |  |  |  |
| Total other income/(expense), net | $ | 560 |  |  | $ | 756 |  |  | (26 | )% |

[0000320193-19-000010:mdna:63]
The decrease in other income/(expense), net during the first quarter of 2019 compared to the same quarter in 2018 was due primarily to higher interest expense on debt, lower interest income and lower investment-related gains, partially offset by the impact of foreign exchange–related items. The weighted-average interest rate earned by the Company on its cash, cash equivalents and marketable securities was 2.19% and 2.11% in the first quarter of 2019 and 2018, respectively.

[0000320193-19-000010:mdna:64]
[same as prior period, unchanged from 0000320193-18-000100:mdna:78]

[0000320193-19-000010:mdna:65]
Provision for income taxes, effective tax rate and statutory federal income tax rate for the three months ended December 29, 2018 and December 30, 2017 were as follows (dollars in millions):

[0000320193-19-000010:mdna:66]
|  | Three Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |
| Provision for income taxes | $ | 3,941 |  |  | $ | 6,965 |  |
| Effective tax rate | 16.5 | % |  | 25.8 | % |
| Statutory federal income tax rate | 21 | % |  | 24.5 | % |

[0000320193-19-000010:mdna:67]
The Company’s effective tax rate for the first quarter of 2019 was lower than the statutory federal income tax rate of 21% due primarily to the lower tax rate on foreign earnings and tax benefits from share-based compensation.

[0000320193-19-000010:mdna:68]
The Company’s effective tax rate for the first quarter of 2019 was lower compared to the same quarter in 2018 due to higher taxes in 2018 as a result of the Tax Cuts and Jobs Act (the “Act”) and a lower statutory federal income tax rate in 2019, partially offset by higher taxes on foreign earnings in 2019.

[0000320193-19-000010:mdna:69]
[same as prior period, unchanged from 0000320193-18-000100:mdna:88]

[0000320193-19-000010:mdna:70]
[same as prior period, unchanged from 0000320193-18-000100:mdna:89]

[0000320193-19-000010:mdna:71]
In August 2017, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) No. 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities (“ASU 2017-12”). ASU 2017-12 expands component and fair value hedging, specifies the presentation of the effects of hedging instruments, and eliminates the separate measurement and presentation of hedge ineffectiveness. The Company will adopt ASU 2017-12 in its first quarter of 2020 utilizing the modified retrospective transition method and is currently evaluating the impact of adoption on its consolidated financial statements.

[0000320193-19-000010:mdna:72]
[same as prior period, unchanged from 0000320193-18-000100:mdna:97]

[0000320193-19-000010:mdna:73]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (“ASU 2016-13”), which modifies the measurement of expected credit losses on certain financial instruments. The Company will adopt ASU 2016-13 in its first quarter of 2021 utilizing the modified retrospective transition method. Based on the composition of the Company’s investment portfolio, current market conditions, and historical credit loss activity, the adoption of ASU 2016-13 is not expected to have a material impact on its consolidated financial statements.

[0000320193-19-000010:mdna:74]
[same as prior period, unchanged from 0000320193-18-000100:mdna:95]

[0000320193-19-000010:mdna:75]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842) (“ASU 2016-02”), which modifies lease accounting for lessees to increase transparency and comparability by recording lease assets and liabilities for operating leases and disclosing key information about leasing arrangements. The Company will adopt ASU 2016-02 utilizing the modified retrospective transition method through a cumulative-effect adjustment at the beginning of its first quarter of 2020. While the Company is currently evaluating the impact of adopting ASU 2016-02, based on the lease portfolio as of December 29, 2018, the Company anticipates recording lease assets and liabilities of approximately $9.1 billion on its Condensed Consolidated Balance Sheets, with no material impact to its Condensed Consolidated Statements of Operations. However, the ultimate impact of adopting ASU 2016-02 will depend on the Company’s lease portfolio as of the adoption date.

[0000320193-19-000010:mdna:76]
[same as prior period, unchanged from 0000320193-18-000100:mdna:104]

[0000320193-19-000010:mdna:77]
The following tables present selected financial information and statistics as of December 29, 2018 and September 29, 2018 and for the first three months of 2019 and 2018 (in millions):

[0000320193-19-000010:mdna:78]
|  | December 29, 2018 |  | September 29, 2018 |
| Cash, cash equivalents and marketable securities (1) | $ | 245,035 |  |  | $ | 237,100 |  |
| Property, plant and equipment, net | $ | 39,597 |  |  | $ | 41,304 |  |
| Commercial paper | $ | 11,969 |  |  | $ | 11,964 |  |
| Total term debt | $ | 102,761 |  |  | $ | 102,519 |  |
| Working capital | $ | 32,545 |  |  | $ | 15,410 |  |

[0000320193-19-000010:mdna:79]
|  | Three Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |
| Cash generated by operating activities | $ | 26,690 |  |  | $ | 28,293 |  |
| Cash generated by/(used in) investing activities | $ | 5,844 |  |  | $ | (13,590 | ) |
| Cash used in financing activities | $ | (13,676 | ) |  | $ | (7,501 | ) |

[0000320193-19-000010:mdna:80]
| (1) | As of December 29, 2018 and September 29, 2018, total cash, cash equivalents and marketable securities included $19.9 billion and $20.3 billion, respectively, that was restricted from general use, related to the State Aid Decision (refer to Note 5, “Income Taxes” in the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Form 10-Q) and other agreements. |

[0000320193-19-000010:mdna:81]
The Company believes its existing balances of cash, cash equivalents and marketable securities, along with commercial paper and other short-term liquidity arrangements, will be sufficient to satisfy its working capital needs, capital asset purchases, dividends, share repurchases, debt repayments and other liquidity requirements associated with its existing operations over the next 12 months.

[0000320193-19-000010:mdna:82]
In connection with the State Aid Decision, as of December 29, 2018, the entire recovery amount of €13.1 billion plus interest of €1.2 billion was funded into escrow, where it will remain restricted from general use pending conclusion of all appeals.

[0000320193-19-000010:mdna:83]
The Company’s marketable securities investment portfolio is primarily invested in highly rated securities, with the primary objective of minimizing the potential risk of principal loss. The Company’s investment policy generally requires securities to be investment grade and limits the amount of credit exposure to any one issuer.

[0000320193-19-000010:mdna:84]
During the three months ended December 29, 2018, cash generated by operating activities of $26.7 billion was a result of $20.0 billion of net income, non-cash adjustments to net income of $5.0 billion and an increase in the net change in operating assets and liabilities of $1.8 billion. Cash generated by investing activities of $5.8 billion during the three months ended December 29, 2018 consisted primarily of proceeds from maturities and sales of marketable securities, net of purchases, of $9.8 billion, partially offset by cash used to acquire property, plant and equipment of $3.4 billion. Cash used in financing activities of $13.7 billion during the three months ended December 29, 2018 consisted primarily of cash used to repurchase common stock of $8.8 billion and cash used to pay dividends and dividend equivalents of $3.6 billion.

[0000320193-19-000010:mdna:85]
During the three months ended December 30, 2017, cash generated by operating activities of $28.3 billion was a result of $20.1 billion of net income and an increase in the net change in operating assets and liabilities of $37.9 billion, partially offset by non-cash adjustments to net income of $29.7 billion. Cash used in investing activities of $13.6 billion during the three months ended December 30, 2017 consisted primarily of cash used for purchases of marketable securities, net of sales and maturities, of $10.4 billion and cash used to acquire property, plant and equipment of $2.8 billion. Cash used in financing activities of $7.5 billion during the three months ended December 30, 2017 consisted primarily of cash used to repurchase common stock of $10.1 billion and cash used to pay dividends and dividend equivalents of $3.3 billion, partially offset by proceeds from the issuance of term debt, net of $7.0 billion.

[0000320193-19-000010:mdna:86]
[same as prior period, unchanged from 0000320193-18-000100:mdna:115]

[0000320193-19-000010:mdna:87]
The Company’s capital expenditures were $1.5 billion during the first three months of 2019. The Company anticipates utilizing approximately $12.0 billion for capital expenditures during 2019, which includes product tooling and manufacturing process equipment; data centers; corporate facilities and infrastructure, including information systems hardware, software and enhancements; and retail store facilities.

[0000320193-19-000010:mdna:88]
[same as prior period, unchanged from 0000320193-18-000100:mdna:117]

[0000320193-19-000010:mdna:89]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses the net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of December 29, 2018, the Company had $12.0 billion of Commercial Paper outstanding, with a weighted-average interest rate of 2.39% and maturities generally less than nine months.

[0000320193-19-000010:mdna:90]
As of December 29, 2018, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $103.8 billion (collectively the “Notes”). The Company has entered, and in the future may enter, into interest rate swaps to manage interest rate risk on the Notes. In addition, the Company has entered, and in the future may enter, into foreign currency swaps to manage foreign currency risk on the Notes.

[0000320193-19-000010:mdna:91]
Further information regarding the Company’s debt issuances and related hedging activity can be found in Part I, Item 1 of this Form 10-Q in the Notes to Condensed Consolidated Financial Statements in Note 3, “Financial Instruments” and Note 6, “Debt.”

[0000320193-19-000010:mdna:92]
[same as prior period, unchanged from 0000320193-18-000100:mdna:121]

[0000320193-19-000010:mdna:93]
On May 1, 2018, the Company announced the Board of Directors had authorized a program to repurchase up to $100 billion of the Company’s common stock, of which $37.3 billion had been utilized as of December 29, 2018. During the three months ended December 29, 2018, the Company repurchased 38.0 million shares of its common stock for $8.2 billion. The Company’s share repurchase program does not obligate it to acquire any specific number of shares. Under this program, shares may be repurchased in privately negotiated and/or open market transactions, including under plans complying with Rule 10b5-1 under the Exchange Act.

[0000320193-19-000010:mdna:94]
On May 1, 2018, the Company also announced the Board of Directors raised the Company’s quarterly cash dividend from $0.63 to $0.73 per share, beginning with the dividend paid during the third quarter of 2018. The Company intends to increase its dividend on an annual basis, subject to declaration by the Board of Directors.

[0000320193-19-000010:mdna:95]
Contractual Obligations

[0000320193-19-000010:mdna:96]
[same as prior period, unchanged from 0000320193-18-000100:mdna:126]

[0000320193-19-000010:mdna:97]
As of December 29, 2018, the Company’s total future minimum lease payments under noncancelable operating leases were $9.9 billion. The Company’s retail store and other facility leases typically have original terms not exceeding 10 years and generally contain multi-year renewal options.

[0000320193-19-000010:mdna:98]
[same as prior period, unchanged from 0000320193-18-000100:mdna:128]

[0000320193-19-000010:mdna:99]
The Company utilizes several outsourcing partners to manufacture sub-assemblies for the Company’s products and to perform final assembly and testing of finished products. These outsourcing partners acquire components and build product based on demand information supplied by the Company, which typically covers periods up to 150 days. The Company also obtains individual components for its products from a wide variety of individual suppliers. As of December 29, 2018, the Company expects to pay $30.2 billion under manufacturing-related supplier arrangements, which are primarily noncancelable.

[0000320193-19-000010:mdna:100]
[same as prior period, unchanged from 0000320193-18-000100:mdna:130]

[0000320193-19-000010:mdna:101]
The Company’s other purchase obligations consist of noncancelable obligations to acquire capital assets, including product tooling and manufacturing process equipment, and noncancelable obligations related to advertising, licensing, R&D, internet and telecommunications services, content creation and other activities. As of December 29, 2018, the Company had other purchase obligations of $6.3 billion.

[0000320193-19-000010:mdna:102]
[same as prior period, unchanged from 0000320193-18-000100:mdna:132]

[0000320193-19-000010:mdna:103]
As of December 29, 2018, a significant portion of the other non-current liabilities in the Company’s Condensed Consolidated Balance Sheet consisted of the $30.9 billion deemed repatriation tax payable imposed by the Act. The Company plans to pay the deemed repatriation tax payable in installments in accordance with the Act. The Company’s remaining other non-current liabilities primarily consist of items for which the Company is unable to make a reasonably reliable estimate of the timing of payments.

[0000320193-19-000010:mdna:104]
[same as prior period, unchanged from 0000320193-18-000100:mdna:134]

[0000320193-19-000010:mdna:105]
Agreements entered into by the Company may include indemnification provisions, which may subject the Company to costs and damages in the event of a claim against an indemnified third party. Except as disclosed in Part I, Item 1 of this Form 10-Q in the Notes to Condensed Consolidated Financial Statements in Note 10, “Commitments and Contingencies” under the heading “Contingencies,” in the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to indemnification of third parties.

[0000320193-19-000010:mdna:106]
The Company offers an iPhone Upgrade Program, which is available to customers who purchase a qualifying iPhone in the U.S., the U.K. and mainland China. The iPhone Upgrade Program provides customers the right to trade in that iPhone for a specified amount when purchasing a new iPhone, provided certain conditions are met. The Company accounts for the trade-in right as a guarantee liability and recognizes arrangement revenue net of the fair value of such right, with subsequent changes to the guarantee liability recognized within net sales.

[0000320193-19-000010:mdna:107]
The Company has entered into indemnification agreements with its directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers of the Company, and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. While the Company maintains directors and officers liability insurance coverage, such insurance coverage may be insufficient to cover all losses or all types of claims that may arise.

[0000320193-19-000010:mdna:108]
[same as prior period, unchanged from 0000320193-18-000100:mdna:138]

[0000320193-19-000010:mdna:109]
The preparation of financial statements and related disclosures in conformity with U.S. generally accepted accounting principles and the Company’s discussion and analysis of its financial condition and operating results require the Company’s management to make judgments, assumptions and estimates that affect the amounts reported. Management bases its estimates on historical experience and on various other assumptions it believes to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities. Actual results may differ from these estimates, and such differences may be material.

[0000320193-19-000010:mdna:110]
Note 1, “Summary of Significant Accounting Policies” in Part I, Item 1 of this Form 10-Q and in the Notes to Consolidated Financial Statements in Part II, Item 8 of the 2018 Form 10-K, and “Critical Accounting Policies and Estimates” in Part II, Item 7 of the 2018 Form 10-K describe the significant accounting policies and methods used in the preparation of the Company’s condensed consolidated financial statements. With the exception of Revenue Recognition and Impairment of Marketable Debt Securities, there have been no material changes to the Company’s critical accounting policies and estimates since the 2018 Form 10-K.

[0000320193-19-000010:mdna:111]
[same as prior period, unchanged from 0000320193-18-000100:mdna:100]

[0000320193-19-000010:mdna:112]
The Company has identified up to three performance obligations regularly included in arrangements involving the sale of iPhone, Mac, iPad and certain other products. The first performance obligation, which represents the substantial portion of the allocated sales price, is the hardware and bundled software delivered at the time of sale. The second performance obligation is the right to receive certain product-related bundled services, which include iCloud, Siri and Maps. The third performance obligation is the right to receive, on a when-and-if-available basis, future unspecified software upgrades relating to the software bundled with each device. The Company allocates revenue and any related discounts to these performance obligations based on their relative stand-alone selling prices (“SSP”). Because the Company lacks observable prices for the undelivered performance obligations, the allocation of revenue is based on the Company’s estimated SSPs. Revenue allocated to the product-related bundled services and unspecified software upgrade rights is deferred and recognized on a straight-line basis over the estimated period they are expected to be provided.

[0000320193-19-000010:mdna:113]
The Company’s process for determining estimated SSPs involves management’s judgment and considers multiple factors that may vary over time depending upon the unique facts and circumstances related to each deliverable. Should future facts and circumstances change, the Company’s SSPs and the future rate of related amortization for unspecified software upgrades and services related to future sales of these devices could change. Factors subject to change include the nature of the unspecified software upgrade rights and product-related bundled services offered, their estimated value and the estimated period they are expected to be provided.

[0000320193-19-000010:mdna:114]
Impairment of Marketable Debt Securities

[0000320193-19-000010:mdna:115]
The Company’s investments in marketable debt securities are classified as available-for-sale and reported at fair value. The Company regularly reviews its investment portfolio to determine if any security is other-than-temporarily impaired, which would require the Company to record an impairment charge in the period any such determination is made. In making this determination, the Company evaluates, among other things, the duration and extent to which the fair value of a security is less than its cost; the financial condition of the issuer and any changes thereto; and the Company’s intent to sell, or whether it will more likely than not be required to sell, the security before recovery of its amortized cost basis. The Company’s assessment of whether an available-for-sale debt security is other-than-temporarily impaired could change in the future due to new developments or changes in assumptions related to any particular security, which would have an adverse impact on the Company’s financial condition and operating results.
