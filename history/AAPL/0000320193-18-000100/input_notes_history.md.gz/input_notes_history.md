# AAPL note change history — 0000320193-18-000070 → 0000320193-18-000100


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-08-01):
[0000320193-18-000100:note_history:1]
The following table shows changes in the Company’s accrued warranties and related costs for the three- and nine-month periods ended June 30, 2018 and July 1, 2017 (in millions):
  (was, 2018-05-02, similarity 0.9377):
[0000320193-18-000070:note_history:1]
The following table shows changes in the Company’s accrued warranties and related costs for the three- and six-month periods ended March 31, 2018 and April 1, 2017 (in millions):

- added (2018-08-01):
[0000320193-18-000100:note_history:2]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | June 30, 2018 |  | July 1, 2017 |
| Beginning accrued warranty and related costs | $ | 4,030 |  |  | $ | 4,735 |  |  | $ | 3,834 |  |  | $ | 3,702 |  |
| Cost of warranty claims | (1,044 | ) |  | (932 | ) |  | (2,959 | ) |  | (3,300 | ) |
| Accruals for product warranty | 567 |  |  | 496 |  |  | 2,678 |  |  | 3,897 |  |
| Ending accrued warranty and related costs | $ | 3,553 |  |  | $ | 4,299 |  |  | $ | 3,553 |  |  | $ | 4,299 |  |

- added (2018-08-01):
[0000320193-18-000100:note_history:3]
Agreements entered into by the Company sometimes include indemnification provisions which may subject the Company to costs and damages in the event of a claim against an indemnified third party. Except as disclosed under the heading “Contingencies” below, in the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to indemnification of third parties.

- changed (2018-08-01):
[0000320193-18-000100:note_history:4]
Although most components essential to the Company’s business are generally available from multiple sources, a few components are currently obtained from single or limited sources. In addition, the Company competes for various components with other participants in the markets for mobile communication and media devices and personal computers. Therefore, many components used by the Company, including those that are available from multiple sources, are at times subject to industry-wide shortage and significant commodity pricing fluctuations that could materially adversely affect the Company’s financial condition and operating results.
  (was, 2018-05-02, similarity 0.9921):
[0000320193-18-000070:note_history:4]
Although most components essential to the Company’s business are generally available from multiple sources, a few components are currently obtained from single or limited sources. In addition, the Company competes for various components with other participants in the markets for mobile communication and media devices and personal computers. Therefore, many components used by the Company, including those that are available from multiple sources, are at times subject to industry-wide shortage and significant pricing fluctuations that could materially adversely affect the Company’s financial condition and operating results.

- changed (2018-08-01):
[0000320193-18-000100:note_history:5]
The Company leases various equipment and facilities, including retail space, under noncancelable operating lease arrangements. The Company does not currently utilize any other off–balance sheet financing arrangements. As of June 30, 2018, the Company’s total future minimum lease payments under noncancelable operating leases were $9.6 billion. The Company’s retail store and other facility leases typically have original terms not exceeding 10 years and generally contain multi-year renewal options.
  (was, 2018-05-02, similarity 0.9908):
[0000320193-18-000070:note_history:5]
The Company leases various equipment and facilities, including retail space, under noncancelable operating lease arrangements. The Company does not currently utilize any other off–balance sheet financing arrangements. As of March 31, 2018, the Company’s total future minimum lease payments under noncancelable operating leases were $9.8 billion. The Company’s retail store and other facility leases typically have original terms not exceeding 10 years and generally contain multi-year renewal options.

- changed (2018-08-01):
[0000320193-18-000100:note_history:6]
The Company has entered into certain off–balance sheet arrangements which require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of payments for supplier arrangements, internet and telecommunication services and intellectual property licenses. As of June 30, 2018, the Company’s total future payments under noncancelable unconditional purchase obligations having a remaining term in excess of one year were $8.5 billion.
  (was, 2018-05-02, similarity 0.9912):
[0000320193-18-000070:note_history:6]
The Company has entered into certain off–balance sheet arrangements which require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of payments for supplier arrangements, internet and telecommunication services and intellectual property licenses. As of March 31, 2018, the Company’s total future payments under noncancelable unconditional purchase obligations having a remaining term in excess of one year were $8.3 billion.

- added (2018-08-01):
[0000320193-18-000100:note_history:7]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully adjudicated, as further discussed in Part II, Item 1 of this Form 10-Q under the heading “Legal Proceedings” and in Part II, Item 1A of this Form 10-Q under the heading “Risk Factors.” The outcome of litigation is inherently uncertain. If one or more legal matters were resolved against the Company in a reporting period for amounts in excess of management’s expectations, the Company’s consolidated financial statements for that reporting period could be materially adversely affected. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to loss contingencies for asserted legal and other claims, except for the following matters:

- added (2018-08-01):
[0000320193-18-000100:note_history:8]
Qualcomm

- added (2018-08-01):
[0000320193-18-000100:note_history:9]
On January 20, 2017, the Company filed a lawsuit against Qualcomm Incorporated and affiliated parties (“Qualcomm”) in the U.S. District Court for the Southern District of California seeking, among other things, to enjoin Qualcomm from requiring the Company to pay royalties at the rate demanded by Qualcomm. As the Company does not believe the demanded royalty it has historically paid contract manufacturers for each applicable device is fair, reasonable and non-discriminatory, and believes it to be invalid and/or overstated in other respects as well, no Qualcomm-related royalty payments have been remitted by the Company to its contract manufacturers since the beginning of the second quarter of 2017. The Company believes it will prevail on the merits of the case and has accrued its best estimate for the ultimate resolution of this matter.

- removed (2018-08-01):
[0000320193-18-000070:note_history:10]
|  | Three Months Ended |  | Six Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |
| Beginning accrued warranty and related costs | $ | 4,323 |  |  | $ | 4,698 |  |  | $ | 3,834 |  |  | $ | 3,702 |  |
| Cost of warranty claims | (933 | ) |  | (1,031 | ) |  | (1,915 | ) |  | (2,368 | ) |
| Accruals for product warranty | 640 |  |  | 1,068 |  |  | 2,111 |  |  | 3,401 |  |
| Ending accrued warranty and related costs | $ | 4,030 |  |  | $ | 4,735 |  |  | $ | 4,030 |  |  | $ | 4,735 |  |

- removed (2018-08-01):
[0000320193-18-000070:note_history:11]
Agreements entered into by the Company sometimes include indemnification provisions which may subject the Company to costs and damages in the event of a claim against an indemnified third party. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to indemnification of third parties.

- removed (2018-08-01):
[0000320193-18-000070:note_history:12]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully adjudicated, as further discussed in Part II, Item 1 of this Form 10-Q under the heading “Legal Proceedings” and in Part II, Item 1A of this Form 10-Q under the heading “Risk Factors.” In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to loss contingencies for asserted legal and other claims, except for the following matter:

- removed (2018-08-01):
[0000320193-18-000070:note_history:13]
The outcome of litigation is inherently uncertain. If one or more legal matters were resolved against the Company in a reporting period for amounts in excess of management’s expectations, the Company’s consolidated financial statements for that reporting period could be materially adversely affected.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-08-01):
[0000320193-18-000100:note_history:14]
Apple Inc. and its wholly-owned subsidiaries (collectively “Apple” or the “Company”) designs, manufactures and markets mobile communication and media devices and personal computers, and sells a variety of related software, services, accessories and third-party digital content and applications. The Company’s products and services include iPhone®, iPad®, Mac®, Apple Watch®, AirPods®, Apple TV®, HomePod™, a portfolio of consumer and professional software applications, iOS, macOS®, watchOS® and tvOS™ operating systems, iCloud®, Apple Pay® and a variety of other accessory, service and support offerings. The Company sells and delivers digital content and applications through the iTunes Store®, App Store®, Mac App Store, TV App Store, iBooks Store® and Apple Music® (collectively “Digital Content and Services”). The Company sells its products worldwide through its retail stores, online stores and direct sales force, as well as through third-party cellular network carriers, wholesalers, retailers and resellers. In addition, the Company sells a variety of third-party Apple-compatible products, including application software and various accessories through its retail and online stores. The Company sells to consumers, small and mid-sized businesses and education, enterprise and government customers.
  (was, 2018-05-02, similarity 0.9917):
[0000320193-18-000070:note_history:14]
Apple Inc. and its wholly-owned subsidiaries (collectively “Apple” or the “Company”) designs, manufactures and markets mobile communication and media devices and personal computers, and sells a variety of related software, services, accessories, networking solutions and third-party digital content and applications. The Company’s products and services include iPhone®, iPad®, Mac®, Apple Watch®, AirPods®, Apple TV®, HomePod™, a portfolio of consumer and professional software applications, iOS, macOS®, watchOS® and tvOS™ operating systems, iCloud®, Apple Pay® and a variety of other accessory, service and support offerings. The Company sells and delivers digital content and applications through the iTunes Store®, App Store®, Mac App Store, TV App Store, iBooks Store® and Apple Music® (collectively “Digital Content and Services”). The Company sells its products worldwide through its retail stores, online stores and direct sales force, as well as through third-party cellular network carriers, wholesalers, retailers and resellers. In addition, the Company sells a variety of third-party Apple-compatible products, including application software and various accessories through its retail and online stores. The Company sells to consumers, small and mid-sized businesses and education, enterprise and government customers.

- changed (2018-08-01):
[0000320193-18-000100:note_history:15]
During the first quarter of 2018, the Company adopted the Financial Accounting Standards Board’s (the “FASB”) Accounting Standards Update (“ASU”) No. 2016-09, Compensation – Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting (“ASU 2016-09”), which modified certain aspects of the accounting for share-based payment transactions, including income taxes, classification of awards and classification in the statement of cash flows. Historically, excess tax benefits or deficiencies from the Company’s equity awards were recorded as additional paid-in capital in its Condensed Consolidated Balance Sheets and were classified as a financing activity in its Condensed Consolidated Statements of Cash Flows. Beginning in 2018, the Company records any excess tax benefits or deficiencies from its equity awards as part of the provision for income taxes in its Condensed Consolidated Statements of Operations in the reporting periods in which equity vesting occurs. The Company elected to apply the cash flow classification requirements related to excess tax benefits retrospectively to all periods presented, which resulted in an increase to cash generated by operating activities in the Condensed Consolidated Statements of Cash Flows of $534 million for the nine months ended July 1, 2017.
  (was, 2018-05-02, similarity 0.983):
[0000320193-18-000070:note_history:15]
During the first quarter of 2018, the Company adopted the Financial Accounting Standards Board’s (the “FASB”) Accounting Standards Update (“ASU”) No. 2016-09, Compensation – Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting (“ASU 2016-09”), which modified certain aspects of the accounting for share-based payment transactions, including income taxes, classification of awards and classification in the statement of cash flows. Historically, excess tax benefits or deficiencies from the Company’s equity awards were recorded as additional paid-in capital in its Condensed Consolidated Balance Sheets and were classified as a financing activity in its Condensed Consolidated Statements of Cash Flows. Beginning in 2018, the Company records any excess tax benefits or deficiencies from its equity awards as part of the provision for income taxes in its Condensed Consolidated Statements of Operations in the reporting periods in which equity vesting occurs. The Company elected to apply the cash flow classification requirements related to excess tax benefits retrospectively to all periods presented, which resulted in an increase to cash generated by operating activities in the Condensed Consolidated Statements of Cash Flows of $225 million for the six months ended April 1, 2017.

- changed (2018-08-01):
[0000320193-18-000100:note_history:16]
The following table shows the computation of basic and diluted earnings per share for the three- and nine-month periods ended June 30, 2018 and July 1, 2017 (net income in millions and shares in thousands):
  (was, 2018-05-02, similarity 0.9468):
[0000320193-18-000070:note_history:16]
The following table shows the computation of basic and diluted earnings per share for the three- and six-month periods ended March 31, 2018 and April 1, 2017 (net income in millions and shares in thousands):

- changed (2018-08-01):
[0000320193-18-000100:note_history:17]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | June 30, 2018 |  | July 1, 2017 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 11,519 |  |  | $ | 8,717 |  |  | $ | 45,406 |  |  | $ | 37,637 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 4,882,167 |  |  | 5,195,088 |  |  | 5,006,640 |  |  | 5,239,847 |  |
| Effect of dilutive securities | 44,442 |  |  | 38,411 |  |  | 44,323 |  |  | 34,547 |  |
| Weighted-average diluted shares | 4,926,609 |  |  | 5,233,499 |  |  | 5,050,963 |  |  | 5,274,394 |  |
| Basic earnings per share | $ | 2.36 |  |  | $ | 1.68 |  |  | $ | 9.07 |  |  | $ | 7.18 |  |
| Diluted earnings per share | $ | 2.34 |  |  | $ | 1.67 |  |  | $ | 8.99 |  |  | $ | 7.14 |  |
  (was, 2018-05-02, similarity 0.8854):
[0000320193-18-000070:note_history:17]
|  | Three Months Ended |  | Six Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 13,822 |  |  | $ | 11,029 |  |  | $ | 33,887 |  |  | $ | 28,920 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 5,024,877 |  |  | 5,225,791 |  |  | 5,068,877 |  |  | 5,262,226 |  |
| Effect of dilutive securities | 43,616 |  |  | 35,897 |  |  | 44,263 |  |  | 32,615 |  |
| Weighted-average diluted shares | 5,068,493 |  |  | 5,261,688 |  |  | 5,113,140 |  |  | 5,294,841 |  |
| Basic earnings per share | $ | 2.75 |  |  | $ | 2.11 |  |  | $ | 6.69 |  |  | $ | 5.50 |  |
| Diluted earnings per share | $ | 2.73 |  |  | $ | 2.10 |  |  | $ | 6.63 |  |  | $ | 5.46 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-08-01):
[0000320193-18-000100:note_history:18]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of both June 30, 2018 and September 30, 2017, the Company had $12.0 billion of Commercial Paper outstanding with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 2.03% as of June 30, 2018 and 1.20% as of September 30, 2017. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the nine months ended June 30, 2018 and July 1, 2017 (in millions):
  (was, 2018-05-02, similarity 0.9366):
[0000320193-18-000070:note_history:18]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of both March 31, 2018 and September 30, 2017, the Company had $12.0 billion of Commercial Paper outstanding with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 1.68% as of March 31, 2018 and 1.20% as of September 30, 2017. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the six months ended March 31, 2018 and April 1, 2017 (in millions):

- added (2018-08-01):
[0000320193-18-000100:note_history:19]
|  | Nine Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | 2,619 |  |  | $ | (143 | ) |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 9,782 |  |  | 12,633 |  |
| Repayments of commercial paper | (12,411 | ) |  | (8,624 | ) |
| Proceeds from/(Repayments of) commercial paper, net | (2,629 | ) |  | 4,009 |  |
| Total change in commercial paper, net | $ | (10 | ) |  | $ | 3,866 |  |

- changed (2018-08-01):
[0000320193-18-000100:note_history:20]
As of June 30, 2018, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $104.1 billion (collectively the “Notes”). The Notes are senior unsecured obligations, and interest is payable in arrears, quarterly for the U.S. dollar–denominated and Australian dollar–denominated floating-rate notes, semi-annually for the U.S. dollar–denominated, Australian dollar–denominated, British pound–denominated, Japanese yen–denominated and Canadian dollar–denominated fixed-rate notes and annually for the euro-denominated and Swiss franc–denominated fixed-rate notes.
  (was, 2018-05-02, similarity 0.9172):
[0000320193-18-000070:note_history:20]
As of March 31, 2018, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $111.1 billion (collectively the “Notes”). The Notes are senior unsecured obligations, and interest is payable in arrears, quarterly for the U.S. dollar–denominated and Australian dollar–denominated floating-rate notes, semi-annually for the U.S. dollar–denominated, Australian dollar–denominated, British pound–denominated, Japanese yen–denominated and Canadian dollar–denominated fixed-rate notes and annually for the euro-denominated and Swiss franc–denominated fixed-rate notes. The following table provides a summary of the Company’s term debt as of March 31, 2018 and September 30, 2017:

- added (2018-08-01):
[0000320193-18-000100:note_history:21]
The following table provides a summary of the Company’s term debt as of June 30, 2018 and September 30, 2017:

- changed (2018-08-01):
[0000320193-18-000100:note_history:22]
|  | Maturities |  | June 30, 2018 |  | September 30, 2017 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | — |  | $ | — |  |  |  |  |  | — | % |  | $ | 2,000 |  |  |  | 1.10% |  | 1.10 | % |
| Fixed-rate 2.400% – 3.850% notes | 2023 | – | 2043 |  | 8,500 |  |  |  | 2.44% | – | 3.91 | % |  | 12,500 |  |  |  | 1.08% | – | 3.91 | % |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 |  | 2019 |  | 1,000 |  |  |  | 2.66% |  | 2.66 | % |  | 1,000 |  |  |  | 1.61% |  | 1.61 | % |
| Fixed-rate 2.100% – 4.450% notes | 2019 | – | 2044 |  | 8,500 |  |  |  | 2.66% | – | 4.48 | % |  | 8,500 |  |  |  | 1.61% | – | 4.48 | % |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2020 |  | 1,517 |  |  |  | 1.87% | – | 2.66 | % |  | 1,549 |  |  |  | 1.56% | – | 1.87 | % |
| Fixed-rate 0.350% – 4.375% notes | 2019 | – | 2045 |  | 24,395 |  |  |  | 0.28% | – | 4.51 | % |  | 24,522 |  |  |  | 0.28% | – | 4.51 | % |
| 2016 debt issuances of $24.9 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2021 |  | 1,350 |  |  |  | 2.50% | – | 3.46 | % |  | 1,350 |  |  |  | 1.45% | – | 2.44 | % |
| Fixed-rate 1.100% – 4.650% notes | 2019 | – | 2046 |  | 23,079 |  |  |  | 1.13% | – | 4.78 | % |  | 23,645 |  |  |  | 1.13% | – | 4.78 | % |
| 2017 debt issuances of $28.7 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2022 |  | 3,250 |  |  |  | 2.43% | – | 2.87 | % |  | 3,250 |  |  |  | 1.38% | – | 1.81 | % |
| Fixed-rate 0.875% – 4.300% notes | 2019 | – | 2047 |  | 25,533 |  |  |  | 1.54% | – | 4.30 | % |  | 25,705 |  |  |  | 1.51% | – | 4.30 | % |
| First quarter 2018 debt issuance of $7.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 1.800% notes |  |  | 2019 |  | 1,000 |  |  |  |  |  | 1.83 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.000% notes |  |  | 2020 |  | 1,000 |  |  |  |  |  | 2.03 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.400% notes |  |  | 2023 |  | 750 |  |  |  |  |  | 2.66 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.750% notes |  |  | 2025 |  | 1,500 |  |  |  |  |  | 2.77 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.000% notes |  |  | 2027 |  | 1,500 |  |  |  |  |  | 3.07 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.750% notes |  |  | 2047 |  | 1,250 |  |  |  |  |  | 3.80 | % |  | — |  |  |  |  |  | — | % |
| Total term debt |  |  |  |  | 104,124 |  |  |  |  |  |  |  | 104,021 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (227 | ) |  |  |  |  |  |  | (225 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | (1,271 | ) |  |  |  |  |  |  | (93 | ) |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  |  |  | (5,498 | ) |  |  |  |  |  |  | (6,496 | ) |  |  |  |  |  |
| Total long-term debt |  |  |  |  | $ | 97,128 |  |  |  |  |  |  |  | $ | 97,207 |  |  |  |  |  |  |
  (was, 2018-05-02, similarity 0.989):
[0000320193-18-000070:note_history:22]
|  | Maturities |  | March 31, 2018 |  | September 30, 2017 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2018 |  | 2018 |  | $ | 2,000 |  |  |  | 1.10% |  | 1.10 | % |  | $ | 2,000 |  |  |  | 1.10% |  | 1.10 | % |
| Fixed-rate 1.000% – 3.850% notes | 2018 | – | 2043 |  | 12,500 |  |  |  | 1.08% | – | 3.91 | % |  | 12,500 |  |  |  | 1.08% | – | 3.91 | % |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 |  | 2019 |  | 1,000 |  |  |  | 2.09% |  | 2.09 | % |  | 1,000 |  |  |  | 1.61% |  | 1.61 | % |
| Fixed-rate 2.100% – 4.450% notes | 2019 | – | 2044 |  | 8,500 |  |  |  | 2.09% | – | 4.48 | % |  | 8,500 |  |  |  | 1.61% | – | 4.48 | % |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2020 |  | 1,537 |  |  |  | 1.87% | – | 2.12 | % |  | 1,549 |  |  |  | 1.56% | – | 1.87 | % |
| Fixed-rate 0.350% – 4.375% notes | 2019 | – | 2045 |  | 25,094 |  |  |  | 0.28% | – | 4.51 | % |  | 24,522 |  |  |  | 0.28% | – | 4.51 | % |
| 2016 debt issuances of $24.9 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2021 |  | 1,350 |  |  |  | 1.93% | – | 3.05 | % |  | 1,350 |  |  |  | 1.45% | – | 2.44 | % |
| Fixed-rate 1.100% – 4.650% notes | 2019 | – | 2046 |  | 23,120 |  |  |  | 1.13% | – | 4.78 | % |  | 23,645 |  |  |  | 1.13% | – | 4.78 | % |
| 2017 debt issuances of $28.7 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2022 |  | 3,250 |  |  |  | 1.88% | – | 2.30 | % |  | 3,250 |  |  |  | 1.38% | – | 1.81 | % |
| Fixed-rate 0.875% – 4.300% notes | 2019 | – | 2047 |  | 25,786 |  |  |  | 1.54% | – | 4.30 | % |  | 25,705 |  |  |  | 1.51% | – | 4.30 | % |
| First quarter 2018 debt issuance of $7.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 1.800% notes |  |  | 2019 |  | 1,000 |  |  |  |  |  | 1.83 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.000% notes |  |  | 2020 |  | 1,000 |  |  |  |  |  | 2.03 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.400% notes |  |  | 2023 |  | 750 |  |  |  |  |  | 2.14 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.750% notes |  |  | 2025 |  | 1,500 |  |  |  |  |  | 2.77 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.000% notes |  |  | 2027 |  | 1,500 |  |  |  |  |  | 2.54 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.750% notes |  |  | 2047 |  | 1,250 |  |  |  |  |  | 3.80 | % |  | — |  |  |  |  |  | — | % |
| Total term debt |  |  |  |  | 111,137 |  |  |  |  |  |  |  | 104,021 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (236 | ) |  |  |  |  |  |  | (225 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | (1,041 | ) |  |  |  |  |  |  | (93 | ) |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  |  |  | (8,498 | ) |  |  |  |  |  |  | (6,496 | ) |  |  |  |  |  |
| Total long-term debt |  |  |  |  | $ | 101,362 |  |  |  |  |  |  |  | $ | 97,207 |  |  |  |  |  |  |

- changed (2018-08-01):
[0000320193-18-000100:note_history:23]
A portion of the Company’s Japanese yen–denominated notes is designated as a hedge of the foreign currency exposure of the Company’s net investment in a foreign operation. As of June 30, 2018 and September 30, 2017, the carrying value of the debt designated as a net investment hedge was $349 million and $1.6 billion, respectively. For further discussion regarding the Company’s use of derivative instruments, see the Derivative Financial Instruments section of Note 2, “Financial Instruments.”
  (was, 2018-05-02, similarity 0.9896):
[0000320193-18-000070:note_history:23]
A portion of the Company’s Japanese yen–denominated notes is designated as a hedge of the foreign currency exposure of the Company’s net investment in a foreign operation. As of March 31, 2018 and September 30, 2017, the carrying value of the debt designated as a net investment hedge was $518 million and $1.6 billion, respectively. For further discussion regarding the Company’s use of derivative instruments see the Derivative Financial Instruments section of Note 2, “Financial Instruments.”

- changed (2018-08-01):
[0000320193-18-000100:note_history:24]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $780 million and $2.2 billion of interest expense on its term debt for the three- and nine-month periods ended June 30, 2018, respectively. The Company recognized $574 million and $1.6 billion of interest expense on its term debt for the three- and nine-month periods ended July 1, 2017, respectively.
  (was, 2018-05-02, similarity 0.9663):
[0000320193-18-000070:note_history:24]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $742 million and $1.4 billion of interest expense on its term debt for the three- and six-month periods ended March 31, 2018, respectively. The Company recognized $507 million and $1.0 billion of interest expense on its term debt for the three- and six-month periods ended April 1, 2017, respectively.

- changed (2018-08-01):
[0000320193-18-000100:note_history:25]
As of June 30, 2018 and September 30, 2017, the fair value of the Company’s Notes, based on Level 2 inputs, was $103.1 billion and $106.1 billion, respectively.
  (was, 2018-05-02, similarity 0.9682):
[0000320193-18-000070:note_history:25]
As of March 31, 2018 and September 30, 2017, the fair value of the Company’s Notes, based on Level 2 inputs, was $111.1 billion and $106.1 billion, respectively.

- removed (2018-08-01):
[0000320193-18-000070:note_history:26]
|  | Six Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | 4,070 |  |  | $ | (1,318 | ) |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 5,550 |  |  | 7,057 |  |
| Repayments of commercial paper | (9,619 | ) |  | (3,860 | ) |
| Proceeds from/(Repayments of) commercial paper, net | (4,069 | ) |  | 3,197 |  |
| Total change in commercial paper, net | $ | 1 |  |  | $ | 1,879 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-08-01):
[0000320193-18-000100:note_history:27]
The following table provides a summary of the Company’s term debt as of June 30, 2018 and September 30, 2017:
  (was, 2018-05-02, similarity 0.9548):
[0000320193-18-000070:note_history:27]
The following table provides a summary of the Company’s term debt as of March 31, 2018 and September 30, 2017:

- changed (2018-08-01):
[0000320193-18-000100:note_history:28]
|  | Maturities |  | June 30, 2018 |  | September 30, 2017 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | — |  | $ | — |  |  |  |  |  | — | % |  | $ | 2,000 |  |  |  | 1.10% |  | 1.10 | % |
| Fixed-rate 2.400% – 3.850% notes | 2023 | – | 2043 |  | 8,500 |  |  |  | 2.44% | – | 3.91 | % |  | 12,500 |  |  |  | 1.08% | – | 3.91 | % |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 |  | 2019 |  | 1,000 |  |  |  | 2.66% |  | 2.66 | % |  | 1,000 |  |  |  | 1.61% |  | 1.61 | % |
| Fixed-rate 2.100% – 4.450% notes | 2019 | – | 2044 |  | 8,500 |  |  |  | 2.66% | – | 4.48 | % |  | 8,500 |  |  |  | 1.61% | – | 4.48 | % |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2020 |  | 1,517 |  |  |  | 1.87% | – | 2.66 | % |  | 1,549 |  |  |  | 1.56% | – | 1.87 | % |
| Fixed-rate 0.350% – 4.375% notes | 2019 | – | 2045 |  | 24,395 |  |  |  | 0.28% | – | 4.51 | % |  | 24,522 |  |  |  | 0.28% | – | 4.51 | % |
| 2016 debt issuances of $24.9 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2021 |  | 1,350 |  |  |  | 2.50% | – | 3.46 | % |  | 1,350 |  |  |  | 1.45% | – | 2.44 | % |
| Fixed-rate 1.100% – 4.650% notes | 2019 | – | 2046 |  | 23,079 |  |  |  | 1.13% | – | 4.78 | % |  | 23,645 |  |  |  | 1.13% | – | 4.78 | % |
| 2017 debt issuances of $28.7 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2022 |  | 3,250 |  |  |  | 2.43% | – | 2.87 | % |  | 3,250 |  |  |  | 1.38% | – | 1.81 | % |
| Fixed-rate 0.875% – 4.300% notes | 2019 | – | 2047 |  | 25,533 |  |  |  | 1.54% | – | 4.30 | % |  | 25,705 |  |  |  | 1.51% | – | 4.30 | % |
| First quarter 2018 debt issuance of $7.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 1.800% notes |  |  | 2019 |  | 1,000 |  |  |  |  |  | 1.83 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.000% notes |  |  | 2020 |  | 1,000 |  |  |  |  |  | 2.03 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.400% notes |  |  | 2023 |  | 750 |  |  |  |  |  | 2.66 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.750% notes |  |  | 2025 |  | 1,500 |  |  |  |  |  | 2.77 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.000% notes |  |  | 2027 |  | 1,500 |  |  |  |  |  | 3.07 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.750% notes |  |  | 2047 |  | 1,250 |  |  |  |  |  | 3.80 | % |  | — |  |  |  |  |  | — | % |
| Total term debt |  |  |  |  | 104,124 |  |  |  |  |  |  |  | 104,021 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (227 | ) |  |  |  |  |  |  | (225 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | (1,271 | ) |  |  |  |  |  |  | (93 | ) |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  |  |  | (5,498 | ) |  |  |  |  |  |  | (6,496 | ) |  |  |  |  |  |
| Total long-term debt |  |  |  |  | $ | 97,128 |  |  |  |  |  |  |  | $ | 97,207 |  |  |  |  |  |  |
  (was, 2018-05-02, similarity 0.989):
[0000320193-18-000070:note_history:28]
|  | Maturities |  | March 31, 2018 |  | September 30, 2017 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2018 |  | 2018 |  | $ | 2,000 |  |  |  | 1.10% |  | 1.10 | % |  | $ | 2,000 |  |  |  | 1.10% |  | 1.10 | % |
| Fixed-rate 1.000% – 3.850% notes | 2018 | – | 2043 |  | 12,500 |  |  |  | 1.08% | – | 3.91 | % |  | 12,500 |  |  |  | 1.08% | – | 3.91 | % |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 |  | 2019 |  | 1,000 |  |  |  | 2.09% |  | 2.09 | % |  | 1,000 |  |  |  | 1.61% |  | 1.61 | % |
| Fixed-rate 2.100% – 4.450% notes | 2019 | – | 2044 |  | 8,500 |  |  |  | 2.09% | – | 4.48 | % |  | 8,500 |  |  |  | 1.61% | – | 4.48 | % |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2020 |  | 1,537 |  |  |  | 1.87% | – | 2.12 | % |  | 1,549 |  |  |  | 1.56% | – | 1.87 | % |
| Fixed-rate 0.350% – 4.375% notes | 2019 | – | 2045 |  | 25,094 |  |  |  | 0.28% | – | 4.51 | % |  | 24,522 |  |  |  | 0.28% | – | 4.51 | % |
| 2016 debt issuances of $24.9 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2021 |  | 1,350 |  |  |  | 1.93% | – | 3.05 | % |  | 1,350 |  |  |  | 1.45% | – | 2.44 | % |
| Fixed-rate 1.100% – 4.650% notes | 2019 | – | 2046 |  | 23,120 |  |  |  | 1.13% | – | 4.78 | % |  | 23,645 |  |  |  | 1.13% | – | 4.78 | % |
| 2017 debt issuances of $28.7 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2022 |  | 3,250 |  |  |  | 1.88% | – | 2.30 | % |  | 3,250 |  |  |  | 1.38% | – | 1.81 | % |
| Fixed-rate 0.875% – 4.300% notes | 2019 | – | 2047 |  | 25,786 |  |  |  | 1.54% | – | 4.30 | % |  | 25,705 |  |  |  | 1.51% | – | 4.30 | % |
| First quarter 2018 debt issuance of $7.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 1.800% notes |  |  | 2019 |  | 1,000 |  |  |  |  |  | 1.83 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.000% notes |  |  | 2020 |  | 1,000 |  |  |  |  |  | 2.03 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.400% notes |  |  | 2023 |  | 750 |  |  |  |  |  | 2.14 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.750% notes |  |  | 2025 |  | 1,500 |  |  |  |  |  | 2.77 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.000% notes |  |  | 2027 |  | 1,500 |  |  |  |  |  | 2.54 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.750% notes |  |  | 2047 |  | 1,250 |  |  |  |  |  | 3.80 | % |  | — |  |  |  |  |  | — | % |
| Total term debt |  |  |  |  | 111,137 |  |  |  |  |  |  |  | 104,021 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (236 | ) |  |  |  |  |  |  | (225 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | (1,041 | ) |  |  |  |  |  |  | (93 | ) |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  |  |  | (8,498 | ) |  |  |  |  |  |  | (6,496 | ) |  |  |  |  |  |
| Total long-term debt |  |  |  |  | $ | 101,362 |  |  |  |  |  |  |  | $ | 97,207 |  |  |  |  |  |  |
