# AAPL notes — 0000320193-18-000100


## aapl:CashCashEquivalentsandAvailableforSaleSecuritiesTableTextBlock

[0000320193-18-000100:notes:1]
The following tables show the Company’s cash and available-for-sale securities by significant investment category as of June 30, 2018 and September 30, 2017 (in millions):

[0000320193-18-000100:notes:2]
|  | June 30, 2018 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | Short-TermMarketableSecurities |  | Long-TermMarketableSecurities |
| Cash | $ | 9,973 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,973 |  |  | $ | 9,973 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 7,722 |  |  | — |  |  | — |  |  | 7,722 |  |  | 7,722 |  |  | — |  |  | — |  |
| Mutual funds | 799 |  |  | — |  |  | (112 | ) |  | 687 |  |  | — |  |  | 687 |  |  | — |  |
| Subtotal | 8,521 |  |  | — |  |  | (112 | ) |  | 8,409 |  |  | 7,722 |  |  | 687 |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 47,056 |  |  | 1 |  |  | (1,055 | ) |  | 46,002 |  |  | 350 |  |  | 7,262 |  |  | 38,390 |  |
| U.S. agency securities | 6,994 |  |  | — |  |  | (44 | ) |  | 6,950 |  |  | 4,477 |  |  | 483 |  |  | 1,990 |  |
| Non-U.S. government securities | 11,774 |  |  | 40 |  |  | (282 | ) |  | 11,532 |  |  | — |  |  | 1,124 |  |  | 10,408 |  |
| Certificates of deposit and time deposits | 5,662 |  |  | — |  |  | — |  |  | 5,662 |  |  | 3,649 |  |  | 1,412 |  |  | 601 |  |
| Commercial paper | 7,064 |  |  | — |  |  | — |  |  | 7,064 |  |  | 5,653 |  |  | 1,411 |  |  | — |  |
| Corporate securities | 130,945 |  |  | 129 |  |  | (2,246 | ) |  | 128,828 |  |  | 147 |  |  | 25,874 |  |  | 102,807 |  |
| Municipal securities | 956 |  |  | — |  |  | (8 | ) |  | 948 |  |  | — |  |  | 172 |  |  | 776 |  |
| Mortgage- and asset-backed securities | 18,919 |  |  | 9 |  |  | (553 | ) |  | 18,375 |  |  | — |  |  | 574 |  |  | 17,801 |  |
| Subtotal | 229,370 |  |  | 179 |  |  | (4,188 | ) |  | 225,361 |  |  | 14,276 |  |  | 38,312 |  |  | 172,773 |  |
| Total (3) | $ | 247,864 |  |  | $ | 179 |  |  | $ | (4,300 | ) |  | $ | 243,743 |  |  | $ | 31,971 |  |  | $ | 38,999 |  |  | $ | 172,773 |  |

[0000320193-18-000100:notes:3]
[same as prior period, unchanged from 0000320193-18-000070:notes:3]

[0000320193-18-000100:notes:4]
[same as prior period, unchanged from 0000320193-18-000070:notes:4]

[0000320193-18-000100:notes:5]
[same as prior period, unchanged from 0000320193-18-000070:notes:5]

[0000320193-18-000100:notes:6]
| (3) | As of June 30, 2018, total cash, cash equivalents and marketable securities included $8.8 billion, related to the State Aid Decision (see Note 4, “Income Taxes”) and other agreements, which was restricted from general use. |


## aapl:CommercialPaperCashFlowSummaryTableTextBlock

[0000320193-18-000100:notes:7]
The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the nine months ended June 30, 2018 and July 1, 2017 (in millions):

[0000320193-18-000100:notes:8]
|  | Nine Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | 2,619 |  |  | $ | (143 | ) |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 9,782 |  |  | 12,633 |  |
| Repayments of commercial paper | (12,411 | ) |  | (8,624 | ) |
| Proceeds from/(Repayments of) commercial paper, net | (2,629 | ) |  | 4,009 |  |
| Total change in commercial paper, net | $ | (10 | ) |  | $ | 3,866 |  |


## aapl:NotionalAndCreditRiskAmountsOfOutstandingDerivativePositionsDisclosureTextBlock

[0000320193-18-000100:notes:9]
The following table shows the notional amounts of the Company’s outstanding derivative instruments and credit risk amounts associated with outstanding or unsettled derivative instruments as of June 30, 2018 and September 30, 2017 (in millions):

[0000320193-18-000100:notes:10]
|  | June 30, 2018 |  | September 30, 2017 |
|  | NotionalAmount |  | Credit RiskAmount |  | NotionalAmount |  | Credit RiskAmount |
| Instruments designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 36,807 |  |  | $ | 850 |  |  | $ | 56,156 |  |  | $ | 1,049 |  |
| Interest rate contracts | $ | 33,250 |  |  | $ | — |  |  | $ | 33,000 |  |  | $ | 218 |  |
| Instruments not designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 50,936 |  |  | $ | 385 |  |  | $ | 69,774 |  |  | $ | 363 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000320193-18-000100:notes:11]
[same as prior period, unchanged from 0000320193-18-000070:notes:15]

[0000320193-18-000100:notes:12]
The following tables show the Company’s condensed consolidated financial statement details as of June 30, 2018 and September 30, 2017 (in millions):

[0000320193-18-000100:notes:13]
[same as prior period, unchanged from 0000320193-18-000070:notes:17]

[0000320193-18-000100:notes:14]
|  | June 30, 2018 |  | September 30, 2017 |
| Components | $ | 4,287 |  |  | $ | 3,025 |  |
| Finished goods | 1,649 |  |  | 1,830 |  |
| Total inventories | $ | 5,936 |  |  | $ | 4,855 |  |

[0000320193-18-000100:notes:15]
[same as prior period, unchanged from 0000320193-18-000070:notes:19]

[0000320193-18-000100:notes:16]
|  | June 30, 2018 |  | September 30, 2017 |
| Land and buildings | $ | 15,409 |  |  | $ | 13,587 |  |
| Machinery, equipment and internal-use software | 62,060 |  |  | 54,210 |  |
| Leasehold improvements | 7,899 |  |  | 7,279 |  |
| Gross property, plant and equipment | 85,368 |  |  | 75,076 |  |
| Accumulated depreciation and amortization | (47,251 | ) |  | (41,293 | ) |
| Total property, plant and equipment, net | $ | 38,117 |  |  | $ | 33,783 |  |

[0000320193-18-000100:notes:17]
[same as prior period, unchanged from 0000320193-18-000070:notes:21]

[0000320193-18-000100:notes:18]
|  | June 30, 2018 |  | September 30, 2017 |
| Long-term taxes payable | $ | 34,029 |  |  | $ | 257 |  |
| Deferred tax liabilities | 398 |  |  | 31,504 |  |
| Other non-current liabilities | 11,267 |  |  | 8,654 |  |
| Total other non-current liabilities | $ | 45,694 |  |  | $ | 40,415 |  |

[0000320193-18-000100:notes:19]
[same as prior period, unchanged from 0000320193-18-000070:notes:23]

[0000320193-18-000100:notes:20]
The following table shows the detail of other income/(expense), net for the three- and nine-month periods ended June 30, 2018 and July 1, 2017 (in millions):

[0000320193-18-000100:notes:21]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | June 30, 2018 |  | July 1, 2017 |
| Interest and dividend income | $ | 1,418 |  |  | $ | 1,327 |  |  | $ | 4,375 |  |  | $ | 3,833 |  |
| Interest expense | (846 | ) |  | (602 | ) |  | (2,372 | ) |  | (1,657 | ) |
| Other income/(expense), net | 100 |  |  | (185 | ) |  | (301 | ) |  | (228 | ) |
| Total other income/(expense), net | $ | 672 |  |  | $ | 540 |  |  | $ | 1,702 |  |  | $ | 1,948 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000320193-18-000100:notes:22]
[same as prior period, unchanged from 0000320193-18-000070:notes:26]

[0000320193-18-000100:notes:23]
[same as prior period, unchanged from 0000320193-18-000070:notes:27]


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000320193-18-000100:notes:24]
[same as prior period, unchanged from 0000320193-18-000070:notes:28]

[0000320193-18-000100:notes:25]
Apple Inc. and its wholly-owned subsidiaries (collectively “Apple” or the “Company”) designs, manufactures and markets mobile communication and media devices and personal computers, and sells a variety of related software, services, accessories and third-party digital content and applications. The Company’s products and services include iPhone®, iPad®, Mac®, Apple Watch®, AirPods®, Apple TV®, HomePod™, a portfolio of consumer and professional software applications, iOS, macOS®, watchOS® and tvOS™ operating systems, iCloud®, Apple Pay® and a variety of other accessory, service and support offerings. The Company sells and delivers digital content and applications through the iTunes Store®, App Store®, Mac App Store, TV App Store, iBooks Store® and Apple Music® (collectively “Digital Content and Services”). The Company sells its products worldwide through its retail stores, online stores and direct sales force, as well as through third-party cellular network carriers, wholesalers, retailers and resellers. In addition, the Company sells a variety of third-party Apple-compatible products, including application software and various accessories through its retail and online stores. The Company sells to consumers, small and mid-sized businesses and education, enterprise and government customers.

[0000320193-18-000100:notes:26]
[same as prior period, unchanged from 0000320193-18-000070:notes:30]

[0000320193-18-000100:notes:27]
[same as prior period, unchanged from 0000320193-18-000070:notes:31]

[0000320193-18-000100:notes:28]
During the first quarter of 2018, the Company adopted the Financial Accounting Standards Board’s (the “FASB”) Accounting Standards Update (“ASU”) No. 2016-09, Compensation – Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting (“ASU 2016-09”), which modified certain aspects of the accounting for share-based payment transactions, including income taxes, classification of awards and classification in the statement of cash flows. Historically, excess tax benefits or deficiencies from the Company’s equity awards were recorded as additional paid-in capital in its Condensed Consolidated Balance Sheets and were classified as a financing activity in its Condensed Consolidated Statements of Cash Flows. Beginning in 2018, the Company records any excess tax benefits or deficiencies from its equity awards as part of the provision for income taxes in its Condensed Consolidated Statements of Operations in the reporting periods in which equity vesting occurs. The Company elected to apply the cash flow classification requirements related to excess tax benefits retrospectively to all periods presented, which resulted in an increase to cash generated by operating activities in the Condensed Consolidated Statements of Cash Flows of $534 million for the nine months ended July 1, 2017.

[0000320193-18-000100:notes:29]
[same as prior period, unchanged from 0000320193-18-000070:notes:33]

[0000320193-18-000100:notes:30]
The following table shows the computation of basic and diluted earnings per share for the three- and nine-month periods ended June 30, 2018 and July 1, 2017 (net income in millions and shares in thousands):

[0000320193-18-000100:notes:31]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | June 30, 2018 |  | July 1, 2017 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 11,519 |  |  | $ | 8,717 |  |  | $ | 45,406 |  |  | $ | 37,637 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 4,882,167 |  |  | 5,195,088 |  |  | 5,006,640 |  |  | 5,239,847 |  |
| Effect of dilutive securities | 44,442 |  |  | 38,411 |  |  | 44,323 |  |  | 34,547 |  |
| Weighted-average diluted shares | 4,926,609 |  |  | 5,233,499 |  |  | 5,050,963 |  |  | 5,274,394 |  |
| Basic earnings per share | $ | 2.36 |  |  | $ | 1.68 |  |  | $ | 9.07 |  |  | $ | 7.18 |  |
| Diluted earnings per share | $ | 2.34 |  |  | $ | 1.67 |  |  | $ | 8.99 |  |  | $ | 7.14 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000320193-18-000100:notes:32]
Commitments and Contingencies

[0000320193-18-000100:notes:33]
Accrued Warranty and Indemnification

[0000320193-18-000100:notes:34]
The following table shows changes in the Company’s accrued warranties and related costs for the three- and nine-month periods ended June 30, 2018 and July 1, 2017 (in millions):

[0000320193-18-000100:notes:35]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | June 30, 2018 |  | July 1, 2017 |
| Beginning accrued warranty and related costs | $ | 4,030 |  |  | $ | 4,735 |  |  | $ | 3,834 |  |  | $ | 3,702 |  |
| Cost of warranty claims | (1,044 | ) |  | (932 | ) |  | (2,959 | ) |  | (3,300 | ) |
| Accruals for product warranty | 567 |  |  | 496 |  |  | 2,678 |  |  | 3,897 |  |
| Ending accrued warranty and related costs | $ | 3,553 |  |  | $ | 4,299 |  |  | $ | 3,553 |  |  | $ | 4,299 |  |

[0000320193-18-000100:notes:36]
Agreements entered into by the Company sometimes include indemnification provisions which may subject the Company to costs and damages in the event of a claim against an indemnified third party. Except as disclosed under the heading “Contingencies” below, in the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to indemnification of third parties.

[0000320193-18-000100:notes:37]
The Company offers an iPhone Upgrade Program, which is available to customers who purchase a qualifying iPhone in the U.S., the U.K. and mainland China. The iPhone Upgrade Program provides customers the right to trade in that iPhone for a specified amount when purchasing a new iPhone, provided certain conditions are met. The Company accounts for the trade-in right as a guarantee liability and recognizes arrangement revenue net of the fair value of such right, with subsequent changes to the guarantee liability recognized within revenue.

[0000320193-18-000100:notes:38]
The Company has entered into indemnification agreements with its directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers of the Company and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. While the Company maintains directors and officers liability insurance coverage, such insurance coverage may be insufficient to cover all losses or all types of claims that may arise.

[0000320193-18-000100:notes:39]
Concentrations in the Available Sources of Supply of Materials and Product

[0000320193-18-000100:notes:40]
Although most components essential to the Company’s business are generally available from multiple sources, a few components are currently obtained from single or limited sources. In addition, the Company competes for various components with other participants in the markets for mobile communication and media devices and personal computers. Therefore, many components used by the Company, including those that are available from multiple sources, are at times subject to industry-wide shortage and significant commodity pricing fluctuations that could materially adversely affect the Company’s financial condition and operating results.

[0000320193-18-000100:notes:41]
The Company uses some custom components that are not commonly used by its competitors, and new products introduced by the Company often utilize custom components available from only one source. When a component or product uses new technologies, initial capacity constraints may exist until the suppliers’ yields have matured or manufacturing capacity has increased. If the Company’s supply of components for a new or existing product were delayed or constrained, or if an outsourcing partner delayed shipments of completed products to the Company, the Company’s financial condition and operating results could be materially adversely affected. The Company’s business and financial performance could also be materially adversely affected depending on the time required to obtain sufficient quantities from the original source, or to identify and obtain sufficient quantities from an alternative source. Continued availability of these components at acceptable prices, or at all, may be affected if those suppliers decide to concentrate on the production of common components instead of components customized to meet the Company’s requirements.

[0000320193-18-000100:notes:42]
The Company has entered into agreements for the supply of many components; however, there can be no guarantee that the Company will be able to extend or renew these agreements on similar terms, or at all. Therefore, the Company remains subject to significant risks of supply shortages and price increases that could materially adversely affect its financial condition and operating results.

[0000320193-18-000100:notes:43]
Substantially all of the Company’s hardware products are manufactured by outsourcing partners that are located primarily in Asia, with some Mac computers manufactured in the U.S. and Ireland. A significant concentration of this manufacturing is currently performed by a small number of outsourcing partners, often in single locations. Certain of these outsourcing partners are the sole-sourced suppliers of components and manufacturers for many of the Company’s products. Although the Company works closely with its outsourcing partners on manufacturing schedules, the Company’s operating results could be adversely affected if its outsourcing partners were unable to meet their production commitments. The Company’s manufacturing purchase obligations typically cover its requirements for periods up to 150 days.

[0000320193-18-000100:notes:44]
Other Off–Balance Sheet Commitments

[0000320193-18-000100:notes:45]
Operating Leases

[0000320193-18-000100:notes:46]
The Company leases various equipment and facilities, including retail space, under noncancelable operating lease arrangements. The Company does not currently utilize any other off–balance sheet financing arrangements. As of June 30, 2018, the Company’s total future minimum lease payments under noncancelable operating leases were $9.6 billion. The Company’s retail store and other facility leases typically have original terms not exceeding 10 years and generally contain multi-year renewal options.

[0000320193-18-000100:notes:47]
Unconditional Purchase Obligations

[0000320193-18-000100:notes:48]
The Company has entered into certain off–balance sheet arrangements which require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of payments for supplier arrangements, internet and telecommunication services and intellectual property licenses. As of June 30, 2018, the Company’s total future payments under noncancelable unconditional purchase obligations having a remaining term in excess of one year were $8.5 billion.

[0000320193-18-000100:notes:49]
Contingencies

[0000320193-18-000100:notes:50]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully adjudicated, as further discussed in Part II, Item 1 of this Form 10-Q under the heading “Legal Proceedings” and in Part II, Item 1A of this Form 10-Q under the heading “Risk Factors.” The outcome of litigation is inherently uncertain. If one or more legal matters were resolved against the Company in a reporting period for amounts in excess of management’s expectations, the Company’s consolidated financial statements for that reporting period could be materially adversely affected. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to loss contingencies for asserted legal and other claims, except for the following matters:

[0000320193-18-000100:notes:51]
VirnetX

[0000320193-18-000100:notes:52]
VirnetX, Inc. filed two lawsuits in the U.S. District Court for the Eastern District of Texas (the “Eastern Texas District Court”) against the Company alleging that certain Company products infringe four patents (the “VirnetX Patents”) relating to network communications technology (“VirnetX I” and “VirnetX II”). On September 30, 2016, a jury returned a verdict in VirnetX I against the Company and awarded damages of $302 million, which later increased to $440 million in post-trial proceedings. VirnetX I is currently on appeal at the U.S. Court of Appeals for the Federal Circuit (the “Federal Circuit”). On April 11, 2018, a jury returned a verdict in VirnetX II against the Company and awarded damages of $503 million. VirnetX II is currently in post-trial proceedings and is expected to proceed to appeal thereafter. The Company has challenged the validity of the VirnetX Patents at the U.S. Patent and Trademark Office (the “PTO”). In response, the PTO has declared the VirnetX Patents invalid. VirnetX has appealed, and those appeals are currently pending at the Federal Circuit. The Federal Circuit has consolidated the Company’s appeal of the Eastern Texas District Court VirnetX I verdict and VirnetX’s appeals from the PTO invalidity proceedings. The Company believes it will prevail on the merits.

[0000320193-18-000100:notes:53]
Qualcomm

[0000320193-18-000100:notes:54]
On January 20, 2017, the Company filed a lawsuit against Qualcomm Incorporated and affiliated parties (“Qualcomm”) in the U.S. District Court for the Southern District of California seeking, among other things, to enjoin Qualcomm from requiring the Company to pay royalties at the rate demanded by Qualcomm. As the Company does not believe the demanded royalty it has historically paid contract manufacturers for each applicable device is fair, reasonable and non-discriminatory, and believes it to be invalid and/or overstated in other respects as well, no Qualcomm-related royalty payments have been remitted by the Company to its contract manufacturers since the beginning of the second quarter of 2017. The Company believes it will prevail on the merits of the case and has accrued its best estimate for the ultimate resolution of this matter.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000320193-18-000100:notes:55]
[same as prior period, unchanged from 0000320193-18-000070:notes:58]

[0000320193-18-000100:notes:56]
[same as prior period, unchanged from 0000320193-18-000070:notes:59]

[0000320193-18-000100:notes:57]
The Company had 280.4 million shares reserved for future issuance under its stock plans as of June 30, 2018. Restricted stock units (“RSUs”) granted generally vest over four years, based on continued employment, and are settled upon vesting in shares of the Company’s common stock on a one-for-one basis. Each share issued with respect to RSUs granted under the Company’s stock plans reduces the number of shares available for grant under the plans by two shares. RSUs canceled and shares withheld to satisfy tax withholding obligations increase the number of shares available for grant under the plans utilizing a factor of two times the number of RSUs canceled or shares withheld.

[0000320193-18-000100:notes:58]
[same as prior period, unchanged from 0000320193-18-000070:notes:61]

[0000320193-18-000100:notes:59]
During the three months ended June 30, 2018, Section 16 officers Angela Ahrendts, Timothy D. Cook, Chris Kondo, Luca Maestri, Daniel Riccio, Philip Schiller and Jeffrey Williams had equity trading plans in place in accordance with Rule 10b5-1(c)(1) under the Exchange Act. An equity trading plan is a written document that pre-establishes the amounts, prices and dates (or formula for determining the amounts, prices and dates) of future purchases or sales of the Company’s stock, including shares acquired pursuant to the Company’s employee and director equity plans.

[0000320193-18-000100:notes:60]
[same as prior period, unchanged from 0000320193-18-000070:notes:63]

[0000320193-18-000100:notes:61]
A summary of the Company’s RSU activity and related information for the nine months ended June 30, 2018 is as follows:

[0000320193-18-000100:notes:62]
|  | Number ofRSUs(in thousands) |  | Weighted-AverageGrant Date FairValue Per RSU |  | AggregateFair Value(in millions) |
| Balance as of September 30, 2017 | 97,571 |  |  | $ | 110.33 |  |  |  |
| RSUs granted | 43,340 |  |  | $ | 160.79 |  |  |  |
| RSUs vested | (41,292 | ) |  | $ | 111.62 |  |  |  |
| RSUs canceled | (4,884 | ) |  | $ | 126.32 |  |  |  |
| Balance as of June 30, 2018 | 94,735 |  |  | $ | 132.03 |  |  | $ | 17,536 |  |

[0000320193-18-000100:notes:63]
The fair value as of the respective vesting dates of RSUs was $3.3 billion and $6.9 billion for the three- and nine-month periods ended June 30, 2018, respectively, and was $2.8 billion and $5.4 billion for the three- and nine-month periods ended July 1, 2017, respectively.

[0000320193-18-000100:notes:64]
The following table shows a summary of the share-based compensation expense included in the Condensed Consolidated Statements of Operations for the three- and nine-month periods ended June 30, 2018 and July 1, 2017 (in millions):

[0000320193-18-000100:notes:65]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | June 30, 2018 |  | July 1, 2017 |
| Cost of sales | $ | 250 |  |  | $ | 216 |  |  | $ | 759 |  |  | $ | 662 |  |
| Research and development | 675 |  |  | 566 |  |  | 1,987 |  |  | 1,730 |  |
| Selling, general and administrative | 426 |  |  | 411 |  |  | 1,249 |  |  | 1,274 |  |
| Total share-based compensation expense | $ | 1,351 |  |  | $ | 1,193 |  |  | $ | 3,995 |  |  | $ | 3,666 |  |

[0000320193-18-000100:notes:66]
The income tax benefit related to share-based compensation expense was $528 million and $1.5 billion for the three- and nine-month periods ended June 30, 2018, respectively, and was $380 million and $1.3 billion for the three- and nine-month periods ended July 1, 2017, respectively. As of June 30, 2018, the total unrecognized compensation cost related to outstanding RSUs and stock options was $10.4 billion, which the Company expects to recognize over a weighted-average period of 2.6 years.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000320193-18-000100:notes:67]
[same as prior period, unchanged from 0000320193-18-000070:notes:70]

[0000320193-18-000100:notes:68]
[same as prior period, unchanged from 0000320193-18-000070:notes:71]

[0000320193-18-000100:notes:69]
The following table shows the pre-tax amounts reclassified from AOCI into the Condensed Consolidated Statements of Operations, and the associated financial statement line item, for the three- and nine-month periods ended June 30, 2018 and July 1, 2017 (in millions):

[0000320193-18-000100:notes:70]
|  |  |  |  | Three Months Ended |  | Nine Months Ended |
| Comprehensive Income Components |  | Financial Statement Line Item |  | June 30, 2018 |  | July 1, 2017 |  | June 30, 2018 |  | July 1, 2017 |
| Unrealized (gains)/losses on derivative instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Net sales |  | $ | 162 |  |  | $ | (148 | ) |  | $ | 433 |  |  | $ | (657 | ) |
|  |  | Cost of sales |  | 206 |  |  | (73 | ) |  | 200 |  |  | (630 | ) |
|  |  | Other income/(expense), net |  | 864 |  |  | (364 | ) |  | 441 |  |  | (127 | ) |
| Interest rate contracts |  | Other income/(expense), net |  | — |  |  | — |  |  | (3 | ) |  | 3 |  |
|  |  |  |  | 1,232 |  |  | (585 | ) |  | 1,071 |  |  | (1,411 | ) |
| Unrealized (gains)/losses on marketable securities |  | Other income/(expense), net |  | 31 |  |  | (48 | ) |  | (49 | ) |  | (37 | ) |
| Total amounts reclassified from AOCI |  | $ | 1,263 |  |  | $ | (633 | ) |  | $ | 1,022 |  |  | $ | (1,448 | ) |

[0000320193-18-000100:notes:71]
The following table shows the changes in AOCI by component for the nine months ended June 30, 2018 (in millions):

[0000320193-18-000100:notes:72]
|  | Cumulative ForeignCurrency Translation |  | Unrealized Gains/Losseson Derivative Instruments |  | Unrealized Gains/Losseson Marketable Securities |  | Total |
| Balances as of September 30, 2017 | $ | (354 | ) |  | $ | (124 | ) |  | $ | 328 |  |  | $ | (150 | ) |
| Other comprehensive income/(loss) before reclassifications | (291 | ) |  | 230 |  |  | (4,576 | ) |  | (4,637 | ) |
| Amounts reclassified from AOCI | — |  |  | 1,071 |  |  | (49 | ) |  | 1,022 |  |
| Tax effect | 4 |  |  | (258 | ) |  | 1,186 |  |  | 932 |  |
| Other comprehensive income/(loss) | (287 | ) |  | 1,043 |  |  | (3,439 | ) |  | (2,683 | ) |
| Cumulative effect of change in accounting principle (1) | (176 | ) |  | 29 |  |  | (131 | ) |  | (278 | ) |
| Balances as of June 30, 2018 | $ | (817 | ) |  | $ | 948 |  |  | $ | (3,242 | ) |  | $ | (3,111 | ) |

[0000320193-18-000100:notes:73]
| (1) | Refer to Note 4, “Income Taxes” for more information on the Company’s adoption of ASU 2018-02 at the beginning of the second quarter of 2018. |


## us-gaap:DebtDisclosureTextBlock

[0000320193-18-000100:notes:74]
Debt

[0000320193-18-000100:notes:75]
Commercial Paper

[0000320193-18-000100:notes:76]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of both June 30, 2018 and September 30, 2017, the Company had $12.0 billion of Commercial Paper outstanding with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 2.03% as of June 30, 2018 and 1.20% as of September 30, 2017. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the nine months ended June 30, 2018 and July 1, 2017 (in millions):

[0000320193-18-000100:notes:77]
Term Debt

[0000320193-18-000100:notes:78]
As of June 30, 2018, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $104.1 billion (collectively the “Notes”). The Notes are senior unsecured obligations, and interest is payable in arrears, quarterly for the U.S. dollar–denominated and Australian dollar–denominated floating-rate notes, semi-annually for the U.S. dollar–denominated, Australian dollar–denominated, British pound–denominated, Japanese yen–denominated and Canadian dollar–denominated fixed-rate notes and annually for the euro-denominated and Swiss franc–denominated fixed-rate notes.

[0000320193-18-000100:notes:79]
The following table provides a summary of the Company’s term debt as of June 30, 2018 and September 30, 2017:

[0000320193-18-000100:notes:80]
|  | Maturities |  | June 30, 2018 |  | September 30, 2017 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | — |  | $ | — |  |  |  |  |  | — | % |  | $ | 2,000 |  |  |  | 1.10% |  | 1.10 | % |
| Fixed-rate 2.400% – 3.850% notes | 2023 | – | 2043 |  | 8,500 |  |  |  | 2.44% | – | 3.91 | % |  | 12,500 |  |  |  | 1.08% | – | 3.91 | % |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 |  | 2019 |  | 1,000 |  |  |  | 2.66% |  | 2.66 | % |  | 1,000 |  |  |  | 1.61% |  | 1.61 | % |
| Fixed-rate 2.100% – 4.450% notes | 2019 | – | 2044 |  | 8,500 |  |  |  | 2.66% | – | 4.48 | % |  | 8,500 |  |  |  | 1.61% | – | 4.48 | % |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2020 |  | 1,517 |  |  |  | 1.87% | – | 2.66 | % |  | 1,549 |  |  |  | 1.56% | – | 1.87 | % |
| Fixed-rate 0.350% – 4.375% notes | 2019 | – | 2045 |  | 24,395 |  |  |  | 0.28% | – | 4.51 | % |  | 24,522 |  |  |  | 0.28% | – | 4.51 | % |
| 2016 debt issuances of $24.9 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2021 |  | 1,350 |  |  |  | 2.50% | – | 3.46 | % |  | 1,350 |  |  |  | 1.45% | – | 2.44 | % |
| Fixed-rate 1.100% – 4.650% notes | 2019 | – | 2046 |  | 23,079 |  |  |  | 1.13% | – | 4.78 | % |  | 23,645 |  |  |  | 1.13% | – | 4.78 | % |
| 2017 debt issuances of $28.7 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2022 |  | 3,250 |  |  |  | 2.43% | – | 2.87 | % |  | 3,250 |  |  |  | 1.38% | – | 1.81 | % |
| Fixed-rate 0.875% – 4.300% notes | 2019 | – | 2047 |  | 25,533 |  |  |  | 1.54% | – | 4.30 | % |  | 25,705 |  |  |  | 1.51% | – | 4.30 | % |
| First quarter 2018 debt issuance of $7.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 1.800% notes |  |  | 2019 |  | 1,000 |  |  |  |  |  | 1.83 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.000% notes |  |  | 2020 |  | 1,000 |  |  |  |  |  | 2.03 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.400% notes |  |  | 2023 |  | 750 |  |  |  |  |  | 2.66 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.750% notes |  |  | 2025 |  | 1,500 |  |  |  |  |  | 2.77 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.000% notes |  |  | 2027 |  | 1,500 |  |  |  |  |  | 3.07 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.750% notes |  |  | 2047 |  | 1,250 |  |  |  |  |  | 3.80 | % |  | — |  |  |  |  |  | — | % |
| Total term debt |  |  |  |  | 104,124 |  |  |  |  |  |  |  | 104,021 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (227 | ) |  |  |  |  |  |  | (225 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | (1,271 | ) |  |  |  |  |  |  | (93 | ) |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  |  |  | (5,498 | ) |  |  |  |  |  |  | (6,496 | ) |  |  |  |  |  |
| Total long-term debt |  |  |  |  | $ | 97,128 |  |  |  |  |  |  |  | $ | 97,207 |  |  |  |  |  |  |

[0000320193-18-000100:notes:81]
To manage interest rate risk on certain of its U.S. dollar–denominated fixed- or floating-rate notes, the Company has entered into interest rate swaps to effectively convert the fixed interest rates to floating interest rates or the floating interest rates to fixed interest rates on a portion of these notes. Additionally, to manage foreign currency risk on certain of its foreign currency–denominated notes, the Company has entered into foreign currency swaps to effectively convert these notes to U.S. dollar–denominated notes.

[0000320193-18-000100:notes:82]
A portion of the Company’s Japanese yen–denominated notes is designated as a hedge of the foreign currency exposure of the Company’s net investment in a foreign operation. As of June 30, 2018 and September 30, 2017, the carrying value of the debt designated as a net investment hedge was $349 million and $1.6 billion, respectively. For further discussion regarding the Company’s use of derivative instruments, see the Derivative Financial Instruments section of Note 2, “Financial Instruments.”

[0000320193-18-000100:notes:83]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $780 million and $2.2 billion of interest expense on its term debt for the three- and nine-month periods ended June 30, 2018, respectively. The Company recognized $574 million and $1.6 billion of interest expense on its term debt for the three- and nine-month periods ended July 1, 2017, respectively.

[0000320193-18-000100:notes:84]
As of June 30, 2018 and September 30, 2017, the fair value of the Company’s Notes, based on Level 2 inputs, was $103.1 billion and $106.1 billion, respectively.


## us-gaap:DerivativesPolicyTextBlock

[0000320193-18-000100:notes:85]
[same as prior period, unchanged from 0000320193-18-000070:notes:103]

[0000320193-18-000100:notes:86]
[same as prior period, unchanged from 0000320193-18-000070:notes:87]

[0000320193-18-000100:notes:87]
[same as prior period, unchanged from 0000320193-18-000070:notes:88]

[0000320193-18-000100:notes:88]
To help protect gross margins from fluctuations in foreign currency exchange rates, certain of the Company’s subsidiaries whose functional currency is the U.S. dollar may hedge a portion of forecasted foreign currency revenue, and subsidiaries whose functional currency is not the U.S. dollar and who sell in local currencies may hedge a portion of forecasted inventory purchases not denominated in the subsidiaries’ functional currencies. The Company may enter into forward contracts, option contracts or other instruments to manage this risk and may designate these instruments as cash flow hedges. The Company generally hedges portions of its forecasted foreign currency exposure associated with revenue and inventory purchases, typically for up to 12 months.

[0000320193-18-000100:notes:89]
[same as prior period, unchanged from 0000320193-18-000070:notes:90]

[0000320193-18-000100:notes:90]
To help protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in foreign currency exchange rates, the Company may enter into forward contracts, cross-currency swaps or other instruments. These instruments may offset a portion of the foreign currency remeasurement gains or losses, or changes in fair value. The Company may designate these instruments as either cash flow or fair value hedges. As of June 30, 2018, the Company’s hedged term debt– and marketable securities–related foreign currency transactions are expected to be recognized within 24 years.

[0000320193-18-000100:notes:91]
[same as prior period, unchanged from 0000320193-18-000070:notes:91]

[0000320193-18-000100:notes:92]
To help protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in interest rates, the Company may enter into interest rate swaps, options or other instruments. These instruments may offset a portion of the changes in interest income or expense, or changes in fair value. The Company designates these instruments as either cash flow or fair value hedges. As of June 30, 2018, the Company’s hedged interest rate transactions are expected to be recognized within 9 years.

[0000320193-18-000100:notes:93]
[same as prior period, unchanged from 0000320193-18-000070:notes:94]

[0000320193-18-000100:notes:94]
[same as prior period, unchanged from 0000320193-18-000070:notes:95]

[0000320193-18-000100:notes:95]
[same as prior period, unchanged from 0000320193-18-000070:notes:96]

[0000320193-18-000100:notes:96]
[same as prior period, unchanged from 0000320193-18-000070:notes:97]

[0000320193-18-000100:notes:97]
[same as prior period, unchanged from 0000320193-18-000070:notes:98]

[0000320193-18-000100:notes:98]
[same as prior period, unchanged from 0000320193-18-000070:notes:99]

[0000320193-18-000100:notes:99]
[same as prior period, unchanged from 0000320193-18-000070:notes:100]

[0000320193-18-000100:notes:100]
[same as prior period, unchanged from 0000320193-18-000070:notes:101]

[0000320193-18-000100:notes:101]
[same as prior period, unchanged from 0000320193-18-000070:notes:102]


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000320193-18-000100:notes:102]
[same as prior period, unchanged from 0000320193-18-000070:notes:104]

[0000320193-18-000100:notes:103]
[same as prior period, unchanged from 0000320193-18-000070:notes:105]


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000320193-18-000100:notes:104]
[same as prior period, unchanged from 0000320193-18-000070:notes:106]

[0000320193-18-000100:notes:105]
[same as prior period, unchanged from 0000320193-18-000070:notes:107]

[0000320193-18-000100:notes:106]
[same as prior period, unchanged from 0000320193-18-000070:notes:108]

[0000320193-18-000100:notes:107]
The following tables show information about the Company’s marketable securities that had been in a continuous unrealized loss position for less than 12 months and for 12 months or greater as of June 30, 2018 and September 30, 2017 (in millions):

[0000320193-18-000100:notes:108]
|  | June 30, 2018 |
|  | Continuous Unrealized Losses |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
| Fair value of marketable securities | $ | 150,468 |  |  | $ | 36,960 |  |  | $ | 187,428 |  |
| Unrealized losses | $ | (3,134 | ) |  | $ | (1,166 | ) |  | $ | (4,300 | ) |

[0000320193-18-000100:notes:109]
[same as prior period, unchanged from 0000320193-18-000070:notes:111]

[0000320193-18-000100:notes:110]
The Company typically invests in highly rated securities, and its investment policy generally limits the amount of credit exposure to any one issuer. The policy generally requires securities to be investment grade, with the primary objective of minimizing the potential risk of principal loss. Fair values were determined for each individual security in the investment portfolio. When evaluating an investment for other-than-temporary impairment, the Company reviews factors such as the length of time and extent to which fair value has been below its cost basis, the financial condition of the issuer and any changes thereto, changes in market interest rates and the Company’s intent to sell, or whether it is more likely than not it will be required to sell the investment before recovery of the investment’s cost basis. As of June 30, 2018, the Company does not consider any of its investments to be other-than-temporarily impaired.

[0000320193-18-000100:notes:111]
Derivatives that are not designated as hedging instruments are adjusted to fair value through earnings in the financial statement line item to which the derivative relates. As a result, during the three- and nine-month periods ended June 30, 2018, respectively, the Company recognized a gain of $135 million and a loss of $7 million in net sales, a gain of $151 million and a loss of $61 million in cost of sales and a gain of $254 million and a loss of $119 million in other income/(expense), net. During the three- and nine-month periods ended July 1, 2017, respectively, the Company recognized a loss of $77 million and a gain of $129 million in net sales, gains of $12 million and $91 million in cost of sales and gains of $49 million and $481 million in other income/(expense), net.

[0000320193-18-000100:notes:112]
The Company records all derivatives in the Condensed Consolidated Balance Sheets at fair value. The Company’s accounting treatment for these derivative instruments is based on its hedge designation. The following tables show the Company’s derivative instruments at gross fair value as of June 30, 2018 and September 30, 2017 (in millions):

[0000320193-18-000100:notes:113]
|  | June 30, 2018 |
|  | Fair Value ofDerivatives Designatedas Hedge Instruments |  | Fair Value ofDerivatives Not Designatedas Hedge Instruments |  | TotalFair Value |
| Derivative assets (1): |  |  |  |  |  |
| Foreign exchange contracts | $ | 850 |  |  | $ | 385 |  |  | $ | 1,235 |  |
| Interest rate contracts | $ | — |  |  | $ | — |  |  | $ | — |  |
| Derivative liabilities (2): |  |  |  |  |  |
| Foreign exchange contracts | $ | 357 |  |  | $ | 221 |  |  | $ | 578 |  |
| Interest rate contracts | $ | 1,271 |  |  | $ | — |  |  | $ | 1,271 |  |

[0000320193-18-000100:notes:114]
[same as prior period, unchanged from 0000320193-18-000070:notes:116]

[0000320193-18-000100:notes:115]
[same as prior period, unchanged from 0000320193-18-000070:notes:117]

[0000320193-18-000100:notes:116]
[same as prior period, unchanged from 0000320193-18-000070:notes:118]

[0000320193-18-000100:notes:117]
The following table shows the pre-tax gains and losses of the Company’s derivative and non-derivative instruments designated as cash flow, net investment and fair value hedges in OCI and the Condensed Consolidated Statements of Operations for the three- and nine-month periods ended June 30, 2018 and July 1, 2017 (in millions):

[0000320193-18-000100:notes:118]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | June 30, 2018 |  | July 1, 2017 |
| Gains/(Losses) recognized in OCI – effective portion: |  |  |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 40 |  |  | $ | (143 | ) |  | $ | 230 |  |  | $ | 1,267 |  |
| Interest rate contracts | — |  |  | (2 | ) |  | 1 |  |  | 7 |  |
| Total | $ | 40 |  |  | $ | (145 | ) |  | $ | 231 |  |  | $ | 1,274 |  |
| Net investment hedges: |  |  |  |  |  |  |  |
| Foreign currency debt | $ | 13 |  |  | $ | 16 |  |  | $ | (18 | ) |  | $ | 53 |  |
| Gains/(Losses) reclassified from AOCI into net income – effective portion: |  |  |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | (1,231 | ) |  | $ | 585 |  |  | $ | (1,068 | ) |  | $ | 1,418 |  |
| Interest rate contracts | — |  |  | — |  |  | 3 |  |  | (3 | ) |
| Total | $ | (1,231 | ) |  | $ | 585 |  |  | $ | (1,065 | ) |  | $ | 1,415 |  |
| Gains/(Losses) on derivative instruments: |  |  |  |  |  |  |  |
| Fair value hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 31 |  |  | $ | — |  |  | $ | 31 |  |  | $ | — |  |
| Interest rate contracts | (230 | ) |  | 185 |  |  | (1,178 | ) |  | (737 | ) |
| Total | $ | (199 | ) |  | $ | 185 |  |  | $ | (1,147 | ) |  | $ | (737 | ) |
| Gains/(Losses) related to hedged items: |  |  |  |  |  |  |  |
| Fair value hedges: |  |  |  |  |  |  |  |
| Marketable securities | $ | (31 | ) |  | $ | — |  |  | $ | (31 | ) |  | $ | — |  |
| Fixed-rate debt | 230 |  |  | (185 | ) |  | 1,178 |  |  | 737 |  |
| Total | $ | 199 |  |  | $ | (185 | ) |  | $ | 1,147 |  |  | $ | 737 |  |

[0000320193-18-000100:notes:119]
[same as prior period, unchanged from 0000320193-18-000070:notes:121]

[0000320193-18-000100:notes:120]
The Company generally enters into master netting arrangements, which are designed to reduce credit risk by permitting net settlement of transactions with the same counterparty. To further limit credit risk, the Company generally enters into collateral security arrangements that provide for collateral to be received or posted when the net fair value of certain financial instruments fluctuates from contractually established thresholds. The Company presents its derivative assets and derivative liabilities at their gross fair values in its Condensed Consolidated Balance Sheets. As of June 30, 2018, the net cash collateral posted by the Company related to derivative instruments under its collateral security arrangements was $211 million, which was recorded as other current assets in the Condensed Consolidated Balance Sheet. As of September 30, 2017, the net cash collateral received by the Company related to derivative instruments under its collateral security arrangements was $35 million, which was recorded as accrued expenses in the Condensed Consolidated Balance Sheet.

[0000320193-18-000100:notes:121]
Under master netting arrangements with the respective counterparties to the Company’s derivative contracts, the Company is allowed to net settle transactions with a single net amount payable by one party to the other. As of June 30, 2018 and September 30, 2017, the potential effects of these rights of set-off associated with the Company’s derivative contracts, including the effects of collateral, would be a reduction to both derivative assets and derivative liabilities of $1.5 billion and $1.4 billion, respectively, resulting in a net derivative liability of $403 million and a net derivative asset of $32 million, respectively.

[0000320193-18-000100:notes:122]
[same as prior period, unchanged from 0000320193-18-000070:notes:124]

[0000320193-18-000100:notes:123]
[same as prior period, unchanged from 0000320193-18-000070:notes:125]

[0000320193-18-000100:notes:124]
[same as prior period, unchanged from 0000320193-18-000070:notes:126]

[0000320193-18-000100:notes:125]
The Company had no customers that individually represented 10% or more of total trade receivables as of June 30, 2018. As of September 30, 2017, the Company had two customers that individually represented 10% or more of total trade receivables, each of which accounted for 10%. The Company’s cellular network carriers accounted for 45% and 59% of total trade receivables as of June 30, 2018 and September 30, 2017, respectively.

[0000320193-18-000100:notes:126]
[same as prior period, unchanged from 0000320193-18-000070:notes:128]

[0000320193-18-000100:notes:127]
The Company has non-trade receivables from certain of its manufacturing vendors resulting from the sale of components to these vendors who manufacture sub-assemblies or assemble final products for the Company. The Company purchases these components directly from suppliers. As of June 30, 2018, the Company had three vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 54%, 12% and 11%. As of September 30, 2017, the Company had three vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 42%, 19% and 10%.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000320193-18-000100:notes:128]
[same as prior period, unchanged from 0000320193-18-000070:notes:130]

[0000320193-18-000100:notes:129]
U.S. Tax Cuts and Jobs Act and Provisional Estimates

[0000320193-18-000100:notes:130]
On December 22, 2017, the U.S. enacted the Tax Cuts and Jobs Act (the “Act”), which significantly changed U.S. tax law. The Act lowered the Company’s U.S. statutory federal income tax rate from 35% to 21% effective January 1, 2018, while also imposing a deemed repatriation tax on previously deferred foreign income. The Act also created a new minimum tax on certain future foreign earnings. During the first quarter of 2018, the Company’s income tax expense included a provisional estimate of $2.6 billion in accordance with the U.S. Securities and Exchange Commission Staff Accounting Bulletin No. 118. This $2.6 billion provisional estimate included $1.8 billion related to the impact of remeasuring the Company’s deferred tax balances to reflect the new lower tax rate, and approximately $800 million associated with the net impact of the deemed repatriation tax. During the third quarter of 2018, the Company reduced its estimate of the deemed repatriation tax by $1.0 billion and adjusted the estimated impact of the deemed repatriation tax on unrecognized tax benefits by $700 million, resulting in the reduction of the Company’s provisional estimate from $2.6 billion to $900 million. The adjustments to the provisional estimate for the deemed repatriation tax and unrecognized tax benefits are discussed below and their impact was included in the Company’s income tax expense during the third quarter of 2018.

[0000320193-18-000100:notes:131]
[same as prior period, unchanged from 0000320193-18-000070:notes:132]

[0000320193-18-000100:notes:132]
[same as prior period, unchanged from 0000320193-18-000070:notes:133]

[0000320193-18-000100:notes:133]
During the second quarter of 2018, the FASB issued ASU No. 2018-02, Income Statement – Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income (“ASU 2018-02”). ASU 2018-02 allows an entity to elect to reclassify the income tax effects of the Act on items within AOCI to retained earnings. The Company elected to apply the provision of ASU 2018-02 at the beginning of the second quarter of 2018 with a reclassification of net tax benefits related to cumulative foreign currency translation and unrealized gains/losses on derivative instruments and marketable securities, resulting in a $278 million decrease in AOCI and a corresponding increase in retained earnings in the Condensed Consolidated Balance Sheet.

[0000320193-18-000100:notes:134]
[same as prior period, unchanged from 0000320193-18-000070:notes:135]

[0000320193-18-000100:notes:135]
As of September 30, 2017, the Company had a U.S. deferred tax liability of $36.4 billion for deferred foreign income. During the first quarter of 2018 the Company replaced $36.1 billion of its U.S. deferred tax liability with a provisional deemed repatriation tax payable of $38.0 billion, which was based on the Company’s cumulative post-1986 deferred foreign income. The Company’s estimate of the deemed repatriation tax is based, in part, on the amount of cash and other specified assets anticipated to be held by the Company’s foreign subsidiaries as of September 29, 2018. Therefore, the provisional tax payable is subject to change as the asset amounts are finalized. During the third quarter of 2018, the Company reduced its provisional tax payable by $1.0 billion to $37.0 billion due, in part, to revised estimates of the amount of cash and other specified assets anticipated to be held by the Company’s foreign subsidiaries as of September 29, 2018. The Company plans to pay the tax in installments in accordance with the Act.

[0000320193-18-000100:notes:136]
[same as prior period, unchanged from 0000320193-18-000070:notes:137]

[0000320193-18-000100:notes:137]
As of June 30, 2018, the Company had gross unrecognized tax benefits of $9.4 billion. These gross unrecognized tax benefits have been offset by certain tax deposits and reduced by the estimated impact of the deemed repatriation tax. As of December 30, 2017, the estimated impact of the deemed repatriation tax on unrecognized tax benefits was $1.1 billion. During the third quarter of 2018, the Company increased the estimated impact of the deemed repatriation tax on unrecognized tax benefits by $700 million, resulting in a revised total estimated impact of $1.8 billion. Upon recognition, $7.3 billion of the unrecognized tax benefits would impact the Company’s effective tax rate. The Company had accrued $1.3 billion of gross interest and penalties as of June 30, 2018. Both the net unrecognized tax benefits and the interest and penalties are classified as other non-current liabilities in the Condensed Consolidated Balance Sheet.

[0000320193-18-000100:notes:138]
The Company is subject to taxation and files income tax returns in the U.S. federal jurisdiction and in many state and foreign jurisdictions. The U.S. Internal Revenue Service concluded its review of the years 2013 through 2015 during the third quarter of 2018. All years prior to 2016 are now closed. The Company is also subject to audits by state, local and foreign tax authorities. In major states and major foreign jurisdictions, the years subsequent to 2003 generally remain open and could be subject to examination by the taxing authorities. The Company believes that an adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax audits cannot be predicted with certainty. If any issues addressed in the Company’s tax audits are resolved in a manner inconsistent with its expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. Although timing of resolution and/or closure of audits is not certain, the Company believes it is reasonably possible that its gross unrecognized tax benefits could decrease (either by payment, release or a combination of both) in the next 12 months by as much as $500 million.

[0000320193-18-000100:notes:139]
[same as prior period, unchanged from 0000320193-18-000070:notes:140]

[0000320193-18-000100:notes:140]
On August 30, 2016, the European Commission announced its decision that Ireland granted state aid to the Company by providing tax opinions in 1991 and 2007 concerning the tax allocation of profits of the Irish branches of two subsidiaries of the Company (the “State Aid Decision”). The State Aid Decision ordered Ireland to calculate and recover additional taxes from the Company for the period June 2003 through December 2014. The recovery amount was calculated to be €13 billion, plus interest of €1 billion. Irish legislative changes, effective as of January 2015, eliminated the application of the tax opinions from that date forward. The Company believes the State Aid Decision to be without merit and appealed to the General Court of the Court of Justice of the European Union. Ireland has also appealed the State Aid Decision. The Company believes that any incremental Irish corporate income taxes potentially due related to the State Aid Decision would be creditable against U.S. taxes, subject to any foreign tax credit limitations in the Act. During the third quarter of 2018, the Company began funding amounts into escrow, where they will remain pending conclusion of all appeals. As of June 30, 2018, €4.5 billion of the recovery amount was funded into escrow and was restricted from general use. Refer to Note 2, “Financial Instruments” for more information. Subsequent to June 30, 2018, the Company has funded an additional €4.5 billion of the recovery amount into escrow.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0000320193-18-000100:notes:141]
A reconciliation of the Company’s segment operating income to the Condensed Consolidated Statements of Operations for the three- and nine-month periods ended June 30, 2018 and July 1, 2017 is as follows (in millions):

[0000320193-18-000100:notes:142]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | June 30, 2018 |  | July 1, 2017 |
| Segment operating income | $ | 17,694 |  |  | $ | 14,922 |  |  | $ | 69,082 |  |  | $ | 60,319 |  |
| Research and development expense | (3,701 | ) |  | (2,937 | ) |  | (10,486 | ) |  | (8,584 | ) |
| Other corporate expenses, net | (1,381 | ) |  | (1,217 | ) |  | (3,816 | ) |  | (3,511 | ) |
| Total operating income | $ | 12,612 |  |  | $ | 10,768 |  |  | $ | 54,780 |  |  | $ | 48,224 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000320193-18-000100:notes:143]
The following table shows information by reportable segment for the three- and nine-month periods ended June 30, 2018 and July 1, 2017 (in millions):

[0000320193-18-000100:notes:144]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | June 30, 2018 |  | July 1, 2017 |
| Americas: |  |  |  |  |  |  |  |
| Net sales | $ | 24,542 |  |  | $ | 20,376 |  |  | $ | 84,576 |  |  | $ | 73,501 |  |
| Operating income | $ | 7,496 |  |  | $ | 6,420 |  |  | $ | 26,580 |  |  | $ | 23,582 |  |
| Europe: |  |  |  |  |  |  |  |
| Net sales | $ | 12,138 |  |  | $ | 10,675 |  |  | $ | 47,038 |  |  | $ | 41,929 |  |
| Operating income | $ | 3,892 |  |  | $ | 2,984 |  |  | $ | 15,044 |  |  | $ | 12,571 |  |
| Greater China: |  |  |  |  |  |  |  |
| Net sales | $ | 9,551 |  |  | $ | 8,004 |  |  | $ | 40,531 |  |  | $ | 34,963 |  |
| Operating income | $ | 3,414 |  |  | $ | 3,002 |  |  | $ | 15,285 |  |  | $ | 13,402 |  |
| Japan: |  |  |  |  |  |  |  |
| Net sales | $ | 3,867 |  |  | $ | 3,624 |  |  | $ | 16,572 |  |  | $ | 13,875 |  |
| Operating income | $ | 1,765 |  |  | $ | 1,624 |  |  | $ | 7,193 |  |  | $ | 6,334 |  |
| Rest of Asia Pacific: |  |  |  |  |  |  |  |
| Net sales | $ | 3,167 |  |  | $ | 2,729 |  |  | $ | 13,978 |  |  | $ | 12,387 |  |
| Operating income | $ | 1,127 |  |  | $ | 892 |  |  | $ | 4,980 |  |  | $ | 4,430 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000320193-18-000100:notes:145]
[same as prior period, unchanged from 0000320193-18-000070:notes:146]

[0000320193-18-000100:notes:146]
[same as prior period, unchanged from 0000320193-18-000070:notes:147]

[0000320193-18-000100:notes:147]
[same as prior period, unchanged from 0000320193-18-000070:notes:148]

[0000320193-18-000100:notes:148]
[same as prior period, unchanged from 0000320193-18-000070:notes:149]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000320193-18-000100:notes:149]
[same as prior period, unchanged from 0000320193-18-000070:notes:150]

[0000320193-18-000100:notes:150]
[same as prior period, unchanged from 0000320193-18-000070:notes:151]

[0000320193-18-000100:notes:151]
During the third quarter of 2018, the Company repurchased 112.8 million shares of its common stock for $20.0 billion in connection with two separate share repurchase programs. Of the $20.0 billion, $10.4 billion was repurchased under the Company’s previous share repurchase program of up to $210 billion, thereby completing that program. On May 1, 2018, the Company announced the Board of Directors had authorized a new program to repurchase up to $100 billion of the Company’s common stock. The remaining $9.6 billion repurchased during the third quarter of 2018 was in connection with the new share repurchase program. The Company’s new share repurchase program does not obligate it to acquire any specific number of shares. Under this program, shares may be repurchased in privately negotiated and/or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).
