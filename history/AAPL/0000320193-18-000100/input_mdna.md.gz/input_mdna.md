# AAPL MD&A — 0000320193-18-000100


## mdna

[0000320193-18-000100:mdna:1]
[same as prior period, unchanged from 0000320193-18-000070:mdna:1]

[0000320193-18-000100:mdna:2]
[same as prior period, unchanged from 0000320193-18-000070:mdna:2]

[0000320193-18-000100:mdna:3]
[same as prior period, unchanged from 0000320193-18-000070:mdna:3]

[0000320193-18-000100:mdna:4]
[same as prior period, unchanged from 0000320193-18-000070:mdna:4]

[0000320193-18-000100:mdna:5]
The Company designs, manufactures and markets mobile communication and media devices and personal computers, and sells a variety of related software, services, accessories and third-party digital content and applications. The Company’s products and services include iPhone, iPad, Mac, Apple Watch, AirPods, Apple TV, HomePod, a portfolio of consumer and professional software applications, iOS, macOS, watchOS and tvOS operating systems, iCloud, Apple Pay and a variety of other accessory, service and support offerings. The Company sells and delivers digital content and applications through the iTunes Store, App Store, Mac App Store, TV App Store, iBooks Store and Apple Music (collectively “Digital Content and Services”). The Company sells its products worldwide through its retail stores, online stores and direct sales force, as well as through third-party cellular network carriers, wholesalers, retailers and resellers. In addition, the Company sells a variety of third-party Apple-compatible products, including application software and various accessories through its retail and online stores. The Company sells to consumers, small and mid-sized businesses and education, enterprise and government customers.

[0000320193-18-000100:mdna:6]
[same as prior period, unchanged from 0000320193-18-000070:mdna:6]

[0000320193-18-000100:mdna:7]
[same as prior period, unchanged from 0000320193-18-000070:mdna:7]

[0000320193-18-000100:mdna:8]
[same as prior period, unchanged from 0000320193-18-000070:mdna:8]

[0000320193-18-000100:mdna:9]
[same as prior period, unchanged from 0000320193-18-000070:mdna:9]

[0000320193-18-000100:mdna:10]
[same as prior period, unchanged from 0000320193-18-000070:mdna:10]

[0000320193-18-000100:mdna:11]
[same as prior period, unchanged from 0000320193-18-000070:mdna:11]

[0000320193-18-000100:mdna:12]
Third Quarter Fiscal 2018 Highlights

[0000320193-18-000100:mdna:13]
Net sales increased 17% or $7.9 billion during the third quarter of 2018 compared to the same quarter in 2017, primarily driven by higher net sales of iPhone, Services and Other Products. Additionally, the strength in foreign currencies relative to the U.S. dollar had a favorable impact on net sales during the third quarter of 2018 compared to the same quarter in 2017. Net sales increased year-over-year in each of the geographic reportable segments.

[0000320193-18-000100:mdna:14]
During the third quarter of 2018, the Company announced iOS 12, macOS Mojave, watchOS 5 and tvOS 12, updates to its operating systems which are expected to be available in the fall of 2018.

[0000320193-18-000100:mdna:15]
The Company spent $20.0 billion to repurchase shares of its common stock and paid dividends and dividend equivalents of $3.7 billion during the third quarter of 2018.

[0000320193-18-000100:mdna:16]
[same as prior period, unchanged from 0000320193-18-000070:mdna:16]

[0000320193-18-000100:mdna:17]
The following table shows net sales by reportable segment and net sales and unit sales by product for the three- and nine-month periods ended June 30, 2018 and July 1, 2017 (dollars in millions and units in thousands):

[0000320193-18-000100:mdna:18]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | Change |  | June 30, 2018 |  | July 1, 2017 |  | Change |
| Net Sales by Reportable Segment: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 24,542 |  |  | $ | 20,376 |  |  | 20 | % |  | $ | 84,576 |  |  | $ | 73,501 |  |  | 15 | % |
| Europe | 12,138 |  |  | 10,675 |  |  | 14 | % |  | 47,038 |  |  | 41,929 |  |  | 12 | % |
| Greater China | 9,551 |  |  | 8,004 |  |  | 19 | % |  | 40,531 |  |  | 34,963 |  |  | 16 | % |
| Japan | 3,867 |  |  | 3,624 |  |  | 7 | % |  | 16,572 |  |  | 13,875 |  |  | 19 | % |
| Rest of Asia Pacific | 3,167 |  |  | 2,729 |  |  | 16 | % |  | 13,978 |  |  | 12,387 |  |  | 13 | % |
| Total net sales | $ | 53,265 |  |  | $ | 45,408 |  |  | 17 | % |  | $ | 202,695 |  |  | $ | 176,655 |  |  | 15 | % |
| Net Sales by Product: |  |  |  |  |  |  |  |  |  |  |  |
| iPhone (1) | $ | 29,906 |  |  | $ | 24,846 |  |  | 20 | % |  | $ | 129,514 |  |  | $ | 112,473 |  |  | 15 | % |
| iPad (1) | 4,741 |  |  | 4,969 |  |  | (5 | )% |  | 14,716 |  |  | 14,391 |  |  | 2 | % |
| Mac (1) | 5,330 |  |  | 5,592 |  |  | (5 | )% |  | 18,073 |  |  | 18,680 |  |  | (3 | )% |
| Services (2) | 9,548 |  |  | 7,266 |  |  | 31 | % |  | 27,209 |  |  | 21,479 |  |  | 27 | % |
| Other Products (1)(3) | 3,740 |  |  | 2,735 |  |  | 37 | % |  | 13,183 |  |  | 9,632 |  |  | 37 | % |
| Total net sales | $ | 53,265 |  |  | $ | 45,408 |  |  | 17 | % |  | $ | 202,695 |  |  | $ | 176,655 |  |  | 15 | % |
| Unit Sales by Product: |  |  |  |  |  |  |  |  |  |  |  |
| iPhone | 41,300 |  |  | 41,026 |  |  | 1 | % |  | 170,833 |  |  | 170,079 |  |  | — | % |
| iPad | 11,553 |  |  | 11,424 |  |  | 1 | % |  | 33,836 |  |  | 33,427 |  |  | 1 | % |
| Mac | 3,720 |  |  | 4,292 |  |  | (13 | )% |  | 12,910 |  |  | 13,865 |  |  | (7 | )% |

[0000320193-18-000100:mdna:19]
[same as prior period, unchanged from 0000320193-18-000070:mdna:19]

[0000320193-18-000100:mdna:20]
| (2) | Includes revenue from Digital Content and Services, AppleCare®, Apple Pay, licensing and other services. Services net sales in the third quarter of 2018 included a favorable one-time item of $236 million in connection with the final resolution of various lawsuits. |

[0000320193-18-000100:mdna:21]
[same as prior period, unchanged from 0000320193-18-000070:mdna:21]

[0000320193-18-000100:mdna:22]
[same as prior period, unchanged from 0000320193-18-000070:mdna:22]

[0000320193-18-000100:mdna:23]
[same as prior period, unchanged from 0000320193-18-000070:mdna:23]

[0000320193-18-000100:mdna:24]
The following table presents iPhone net sales and unit sales information for the three- and nine-month periods ended June 30, 2018 and July 1, 2017 (dollars in millions and units in thousands):

[0000320193-18-000100:mdna:25]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | Change |  | June 30, 2018 |  | July 1, 2017 |  | Change |
| Net sales | $ | 29,906 |  |  | $ | 24,846 |  |  | 20 | % |  | $ | 129,514 |  |  | $ | 112,473 |  |  | 15 | % |
| Percentage of total net sales | 56 | % |  | 55 | % |  |  |  | 64 | % |  | 64 | % |  |  |
| Unit sales | 41,300 |  |  | 41,026 |  |  | 1 | % |  | 170,833 |  |  | 170,079 |  |  | — | % |

[0000320193-18-000100:mdna:26]
iPhone net sales increased during the third quarter and first nine months of 2018 compared to the same periods in 2017 due primarily to a different mix of iPhones resulting in higher average selling prices.

[0000320193-18-000100:mdna:27]
[same as prior period, unchanged from 0000320193-18-000070:mdna:27]

[0000320193-18-000100:mdna:28]
The following table presents iPad net sales and unit sales information for the three- and nine-month periods ended June 30, 2018 and July 1, 2017 (dollars in millions and units in thousands):

[0000320193-18-000100:mdna:29]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | Change |  | June 30, 2018 |  | July 1, 2017 |  | Change |
| Net sales | $ | 4,741 |  |  | $ | 4,969 |  |  | (5 | )% |  | $ | 14,716 |  |  | $ | 14,391 |  |  | 2 | % |
| Percentage of total net sales | 9 | % |  | 11 | % |  |  |  | 7 | % |  | 8 | % |  |  |
| Unit sales | 11,553 |  |  | 11,424 |  |  | 1 | % |  | 33,836 |  |  | 33,427 |  |  | 1 | % |

[0000320193-18-000100:mdna:30]
iPad net sales decreased during the third quarter of 2018 compared to the same period in 2017 due primarily to a different mix of iPads resulting in lower average selling prices. iPad net sales increased year-over-year during the first nine months of 2018 due primarily to higher iPad unit sales and the strength in foreign currencies relative to the U.S. dollar.

[0000320193-18-000100:mdna:31]
[same as prior period, unchanged from 0000320193-18-000070:mdna:31]

[0000320193-18-000100:mdna:32]
The following table presents Mac net sales and unit sales information for the three- and nine-month periods ended June 30, 2018 and July 1, 2017 (dollars in millions and units in thousands):

[0000320193-18-000100:mdna:33]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | Change |  | June 30, 2018 |  | July 1, 2017 |  | Change |
| Net sales | $ | 5,330 |  |  | $ | 5,592 |  |  | (5 | )% |  | $ | 18,073 |  |  | $ | 18,680 |  |  | (3 | )% |
| Percentage of total net sales | 10 | % |  | 12 | % |  |  |  | 9 | % |  | 11 | % |  |  |
| Unit sales | 3,720 |  |  | 4,292 |  |  | (13 | )% |  | 12,910 |  |  | 13,865 |  |  | (7 | )% |

[0000320193-18-000100:mdna:34]
Mac net sales decreased during the third quarter and first nine months of 2018 compared to the same periods in 2017 due primarily to lower Mac unit sales. The launch of MacBook Pro® in the first quarter of 2017 and the updated Mac portables in the third quarter of 2017 contributed to higher Mac net sales and unit sales during the first nine months of 2017.

[0000320193-18-000100:mdna:35]
[same as prior period, unchanged from 0000320193-18-000070:mdna:35]

[0000320193-18-000100:mdna:36]
The following table presents Services net sales information for the three- and nine-month periods ended June 30, 2018 and July 1, 2017 (dollars in millions):

[0000320193-18-000100:mdna:37]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | Change |  | June 30, 2018 |  | July 1, 2017 |  | Change |
| Net sales | $ | 9,548 |  |  | $ | 7,266 |  |  | 31 | % |  | $ | 27,209 |  |  | $ | 21,479 |  |  | 27 | % |
| Percentage of total net sales | 18 | % |  | 16 | % |  |  |  | 13 | % |  | 12 | % |  |  |

[0000320193-18-000100:mdna:38]
Services net sales increased during the third quarter and first nine months of 2018 compared to the same periods in 2017 due primarily to licensing, App Store and AppleCare. During the third quarter of 2018, the Company recognized a favorable one-time item of $236 million in connection with the final resolution of various lawsuits.

[0000320193-18-000100:mdna:39]
[same as prior period, unchanged from 0000320193-18-000070:mdna:39]

[0000320193-18-000100:mdna:40]
[same as prior period, unchanged from 0000320193-18-000070:mdna:40]

[0000320193-18-000100:mdna:41]
[same as prior period, unchanged from 0000320193-18-000070:mdna:41]

[0000320193-18-000100:mdna:42]
The following table presents Americas net sales information for the three- and nine-month periods ended June 30, 2018 and July 1, 2017 (dollars in millions):

[0000320193-18-000100:mdna:43]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | Change |  | June 30, 2018 |  | July 1, 2017 |  | Change |
| Net sales | $ | 24,542 |  |  | $ | 20,376 |  |  | 20 | % |  | $ | 84,576 |  |  | $ | 73,501 |  |  | 15 | % |
| Percentage of total net sales | 46 | % |  | 45 | % |  |  |  | 42 | % |  | 42 | % |  |  |

[0000320193-18-000100:mdna:44]
Americas net sales increased during the third quarter and first nine months of 2018 compared to the same periods in 2017 due primarily to higher net sales of iPhone and Services.

[0000320193-18-000100:mdna:45]
[same as prior period, unchanged from 0000320193-18-000070:mdna:45]

[0000320193-18-000100:mdna:46]
The following table presents Europe net sales information for the three- and nine-month periods ended June 30, 2018 and July 1, 2017 (dollars in millions):

[0000320193-18-000100:mdna:47]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | Change |  | June 30, 2018 |  | July 1, 2017 |  | Change |
| Net sales | $ | 12,138 |  |  | $ | 10,675 |  |  | 14 | % |  | $ | 47,038 |  |  | $ | 41,929 |  |  | 12 | % |
| Percentage of total net sales | 23 | % |  | 24 | % |  |  |  | 23 | % |  | 24 | % |  |  |

[0000320193-18-000100:mdna:48]
Europe net sales increased during the third quarter and first nine months of 2018 compared to the same periods in 2017 due primarily to higher net sales of iPhone and Services. Additionally, the strength in foreign currencies relative to the U.S. dollar had a favorable impact on Europe net sales.

[0000320193-18-000100:mdna:49]
[same as prior period, unchanged from 0000320193-18-000070:mdna:49]

[0000320193-18-000100:mdna:50]
The following table presents Greater China net sales information for the three- and nine-month periods ended June 30, 2018 and July 1, 2017 (dollars in millions):

[0000320193-18-000100:mdna:51]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | Change |  | June 30, 2018 |  | July 1, 2017 |  | Change |
| Net sales | $ | 9,551 |  |  | $ | 8,004 |  |  | 19 | % |  | $ | 40,531 |  |  | $ | 34,963 |  |  | 16 | % |
| Percentage of total net sales | 18 | % |  | 18 | % |  |  |  | 20 | % |  | 20 | % |  |  |

[0000320193-18-000100:mdna:52]
Greater China net sales increased during the third quarter of 2018 compared to the same period in 2017 due primarily to higher net sales of iPhone and Other Products. Greater China net sales increased year-over-year during the first nine months of 2018 due primarily to higher net sales of iPhone and Services. The strength in foreign currencies relative to the U.S. dollar also had a favorable impact on Greater China net sales during the third quarter and first nine months of 2018.

[0000320193-18-000100:mdna:53]
[same as prior period, unchanged from 0000320193-18-000070:mdna:53]

[0000320193-18-000100:mdna:54]
The following table presents Japan net sales information for the three- and nine-month periods ended June 30, 2018 and July 1, 2017 (dollars in millions):

[0000320193-18-000100:mdna:55]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | Change |  | June 30, 2018 |  | July 1, 2017 |  | Change |
| Net sales | $ | 3,867 |  |  | $ | 3,624 |  |  | 7 | % |  | $ | 16,572 |  |  | $ | 13,875 |  |  | 19 | % |
| Percentage of total net sales | 7 | % |  | 8 | % |  |  |  | 8 | % |  | 8 | % |  |  |

[0000320193-18-000100:mdna:56]
Japan net sales increased during the third quarter of 2018 compared to the same period in 2017 due primarily to higher net sales of Services. Japan net sales increased year-over-year during the first nine months of 2018 due primarily to higher net sales of iPhone and Services. Additionally, the value of the Japanese Yen relative to the U.S. dollar had a favorable impact on Japan net sales during the third quarter of 2018 and an unfavorable impact during the first nine months of 2018.

[0000320193-18-000100:mdna:57]
[same as prior period, unchanged from 0000320193-18-000070:mdna:57]

[0000320193-18-000100:mdna:58]
The following table presents Rest of Asia Pacific net sales information for the three- and nine-month periods ended June 30, 2018 and July 1, 2017 (dollars in millions):

[0000320193-18-000100:mdna:59]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | Change |  | June 30, 2018 |  | July 1, 2017 |  | Change |
| Net sales | $ | 3,167 |  |  | $ | 2,729 |  |  | 16 | % |  | $ | 13,978 |  |  | $ | 12,387 |  |  | 13 | % |
| Percentage of total net sales | 6 | % |  | 6 | % |  |  |  | 7 | % |  | 7 | % |  |  |

[0000320193-18-000100:mdna:60]
Rest of Asia Pacific net sales increased during the third quarter and first nine months of 2018 compared to the same periods in 2017 due primarily to higher net sales of iPhone and Services. Additionally, the strength in foreign currencies relative to the U.S. dollar had a favorable impact on Rest of Asia Pacific net sales.

[0000320193-18-000100:mdna:61]
[same as prior period, unchanged from 0000320193-18-000070:mdna:61]

[0000320193-18-000100:mdna:62]
Gross margin for the three- and nine-month periods ended June 30, 2018 and July 1, 2017 was as follows (dollars in millions):

[0000320193-18-000100:mdna:63]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | June 30, 2018 |  | July 1, 2017 |
| Net sales | $ | 53,265 |  |  | $ | 45,408 |  |  | $ | 202,695 |  |  | $ | 176,655 |  |
| Cost of sales | 32,844 |  |  | 27,920 |  |  | 124,940 |  |  | 108,400 |  |
| Gross margin | $ | 20,421 |  |  | $ | 17,488 |  |  | $ | 77,755 |  |  | $ | 68,255 |  |
| Gross margin percentage | 38.3 | % |  | 38.5 | % |  | 38.4 | % |  | 38.6 | % |

[0000320193-18-000100:mdna:64]
Gross margin increased during the third quarter and first nine months of 2018 compared to the same periods in 2017 due primarily to higher Services net sales and a favorable shift in the mix of iPhones with higher average selling prices, partially offset by higher product cost structures. Additionally, to a lesser extent the strength in foreign currencies relative to the U.S. dollar and higher year-over-year product unit sales had a favorable impact on gross margin.

[0000320193-18-000100:mdna:65]
Gross margin percentage decreased during the third quarter and first nine months of 2018 compared to the same periods in 2017 due primarily to higher product cost structures, partially offset by a favorable shift in mix of products and Services. Additionally, the strength in foreign currencies relative to the U.S. dollar had a favorable impact on gross margin percentage.

[0000320193-18-000100:mdna:66]
The Company anticipates gross margin percentage during the fourth quarter of 2018 to be between 38.0% and 38.5%. The foregoing statement regarding the Company’s expected gross margin percentage in the fourth quarter of 2018 is forward-looking and could differ from actual results. The Company’s future gross margins can be impacted by multiple factors including, but not limited to, those set forth in Part II, Item 1A of this Form 10-Q under the heading “Risk Factors” and those described in this paragraph. In general, the Company believes gross margins will remain under downward pressure due to a variety of factors, including: continued industry-wide global product pricing pressures and product pricing actions that the Company may take in response to such pressures; increased competition; the Company’s ability to effectively stimulate demand for certain of its products; compressed product life cycles; product transitions; potential increases in the cost of components and outside manufacturing services; the Company’s ability to manage product quality and warranty costs effectively; and a potential shift in the Company’s sales mix towards products with lower gross margins. Due to the Company’s significant international operations, its financial condition and operating results, including gross margins, could be significantly affected by fluctuations in exchange rates.

[0000320193-18-000100:mdna:67]
[same as prior period, unchanged from 0000320193-18-000070:mdna:67]

[0000320193-18-000100:mdna:68]
Operating expenses for the three- and nine-month periods ended June 30, 2018 and July 1, 2017 were as follows (dollars in millions):

[0000320193-18-000100:mdna:69]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | June 30, 2018 |  | July 1, 2017 |
| Research and development | $ | 3,701 |  |  | $ | 2,937 |  |  | $ | 10,486 |  |  | $ | 8,584 |  |
| Percentage of total net sales | 7 | % |  | 6 | % |  | 5 | % |  | 5 | % |
| Selling, general and administrative | $ | 4,108 |  |  | $ | 3,783 |  |  | $ | 12,489 |  |  | $ | 11,447 |  |
| Percentage of total net sales | 8 | % |  | 8 | % |  | 6 | % |  | 6 | % |
| Total operating expenses | $ | 7,809 |  |  | $ | 6,720 |  |  | $ | 22,975 |  |  | $ | 20,031 |  |
| Percentage of total net sales | 15 | % |  | 15 | % |  | 11 | % |  | 11 | % |

[0000320193-18-000100:mdna:70]
[same as prior period, unchanged from 0000320193-18-000070:mdna:70]

[0000320193-18-000100:mdna:71]
The growth in R&D expense during the third quarter and first nine months of 2018 compared to the same periods in 2017 was driven primarily by increases in headcount-related expenses and material costs to support expanded R&D activities. The Company continues to believe that focused investments in R&D are critical to its future growth and competitive position in the marketplace, and to the development of new and updated products and services that are central to the Company’s core business strategy.

[0000320193-18-000100:mdna:72]
[same as prior period, unchanged from 0000320193-18-000070:mdna:72]

[0000320193-18-000100:mdna:73]
The growth in selling, general and administrative expense during the third quarter and first nine months of 2018 compared to the same periods in 2017 was driven primarily by increases in headcount-related expenses, professional services and infrastructure-related costs.

[0000320193-18-000100:mdna:74]
[same as prior period, unchanged from 0000320193-18-000070:mdna:74]

[0000320193-18-000100:mdna:75]
Other income/(expense), net for the three- and nine-month periods ended June 30, 2018 and July 1, 2017 was as follows (dollars in millions):

[0000320193-18-000100:mdna:76]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | Change |  | June 30, 2018 |  | July 1, 2017 |  | Change |
| Interest and dividend income | $ | 1,418 |  |  | $ | 1,327 |  |  |  |  | $ | 4,375 |  |  | $ | 3,833 |  |  |  |
| Interest expense | (846 | ) |  | (602 | ) |  |  |  | (2,372 | ) |  | (1,657 | ) |  |  |
| Other income/(expense), net | 100 |  |  | (185 | ) |  |  |  | (301 | ) |  | (228 | ) |  |  |
| Total other income/(expense), net | $ | 672 |  |  | $ | 540 |  |  | 24 | % |  | $ | 1,702 |  |  | $ | 1,948 |  |  | (13 | )% |

[0000320193-18-000100:mdna:77]
The increase in other income/(expense), net during the third quarter of 2018 compared to the same period in 2017 was due primarily to the impact of foreign exchange–related items, partially offset by higher interest expense on debt. The year-over-year decrease in other income/(expense), net during the first nine months of 2018 was due primarily to higher interest expense on debt and the impact of foreign exchange–related items, partially offset by higher interest income. The weighted-average interest rate earned by the Company on its cash, cash equivalents and marketable securities was 2.25% and 2.03% in the third quarter of 2018 and 2017, respectively, and 2.16% and 1.96% in the first nine months of 2018 and 2017, respectively.

[0000320193-18-000100:mdna:78]
[same as prior period, unchanged from 0000320193-18-000070:mdna:78]

[0000320193-18-000100:mdna:79]
Provision for income taxes and effective tax rates for the three- and nine-month periods ended June 30, 2018 and July 1, 2017 were as follows (dollars in millions):

[0000320193-18-000100:mdna:80]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | June 30, 2018 |  | July 1, 2017 |
| Provision for income taxes | $ | 1,765 |  |  | $ | 2,591 |  |  | $ | 11,076 |  |  | $ | 12,535 |  |
| Effective tax rate | 13.3 | % |  | 22.9 | % |  | 19.6 | % |  | 25.0 | % |

[0000320193-18-000100:mdna:81]
[same as prior period, unchanged from 0000320193-18-000070:mdna:81]

[0000320193-18-000100:mdna:82]
The Company’s effective tax rate of 13.3% for the third quarter of 2018 was lower than the 2018 blended U.S. tax rate due primarily to the reduction in its provisional tax expense estimate. The Company’s effective tax rate of 19.6% for the first nine months of 2018 was lower than the 2018 blended U.S. tax rate due primarily to the lower tax rate on foreign earnings, partially offset by the remeasurement of deferred tax assets and liabilities as a result of the Act.

[0000320193-18-000100:mdna:83]
The Company’s effective tax rate of 13.3% for the third quarter of 2018 was lower than the same period in 2017 due primarily to the lower 2018 blended U.S. tax rate as a result of the Act and the reduction in its provisional tax expense estimate, partially offset by higher taxes on foreign earnings during the third quarter of 2018. The Company’s effective tax rate of 19.6% for the first nine months of 2018 was lower than the same period in 2017 due to the lower 2018 blended U.S. tax rate, partially offset by the remeasurement of deferred tax assets and liabilities as a result of the Act.

[0000320193-18-000100:mdna:84]
As a result of adopting Accounting Standards Update (“ASU”) No. 2016-09, Compensation – Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting, in 2018, the Company records any excess tax benefits or deficiencies from its equity awards as part of the provision for income taxes. The Company anticipates that these excess tax benefits or deficiencies will have the greatest impact on its effective tax rates in the first and third quarters, as the majority of the Company’s equity awards vest in those quarters.

[0000320193-18-000100:mdna:85]
The Company is subject to taxation and files income tax returns in the U.S. federal jurisdiction and in many state and foreign jurisdictions. The U.S. Internal Revenue Service (the “IRS”) concluded its review of the years 2013 through 2015 during the third quarter of 2018. All years prior to 2016 are now closed. The Company is also subject to audits by state, local and foreign tax authorities. In major states and major foreign jurisdictions, the years subsequent to 2003 generally remain open and could be subject to examination by the taxing authorities. The Company believes that adequate provisions have been made for any adjustments that may result from tax examinations. However, the outcome of tax audits cannot be predicted with certainty. If any issues addressed in the Company’s tax audits are resolved in a manner inconsistent with its expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs.

[0000320193-18-000100:mdna:86]
On August 30, 2016, the European Commission announced its decision that Ireland granted state aid to the Company by providing tax opinions in 1991 and 2007 concerning the tax allocation of profits of the Irish branches of two subsidiaries of the Company (the “State Aid Decision”). The State Aid Decision ordered Ireland to calculate and recover additional taxes from the Company for the period June 2003 through December 2014. The recovery amount was calculated to be €13 billion, plus interest of €1 billion. Irish legislative changes, effective as of January 2015, eliminated the application of the tax opinions from that date forward. The Company believes the State Aid Decision to be without merit and appealed to the General Court of the Court of Justice of the European Union. Ireland has also appealed the State Aid Decision. The Company believes that any incremental Irish corporate income taxes potentially due related to the State Aid Decision would be creditable against U.S. taxes, subject to any foreign tax credit limitations in the Act. During the third quarter of 2018, the Company began funding amounts into escrow, where they will remain pending conclusion of all appeals.

[0000320193-18-000100:mdna:87]
On July 24, 2018, the U.S. Ninth Circuit Court of Appeals reversed the U.S. Tax Court's decision in Altera Corp v. Commissioner. As a result of this reversal, the Company expects to include share-based compensation in cost-sharing arrangements with its foreign subsidiaries. The Company is still evaluating the effect of this reversal and anticipates recognizing the impact during the fourth quarter of 2018.

[0000320193-18-000100:mdna:88]
[same as prior period, unchanged from 0000320193-18-000070:mdna:87]

[0000320193-18-000100:mdna:89]
[same as prior period, unchanged from 0000320193-18-000070:mdna:88]

[0000320193-18-000100:mdna:90]
In August 2017, the Financial Accounting Standards Board (the “FASB”) issued ASU No. 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities (“ASU 2017-12”). ASU 2017-12 expands component and fair value hedging, specifies the presentation of the effects of hedging instruments, and eliminates the separate measurement and presentation of hedge ineffectiveness. The Company will adopt ASU 2017-12 in its first quarter of 2020 utilizing the modified retrospective transition method and is currently evaluating the impact of adoption on its consolidated financial statements.

[0000320193-18-000100:mdna:91]
[same as prior period, unchanged from 0000320193-18-000070:mdna:90]

[0000320193-18-000100:mdna:92]
In November 2016, the FASB issued ASU No. 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash (“ASU 2016-18”), which enhances and clarifies the guidance on the classification and presentation of restricted cash in the statement of cash flows. The Company will adopt ASU 2016-18 in its first quarter of 2019 utilizing the retrospective transition method. Currently, the Company’s restricted cash balance is not significant.

[0000320193-18-000100:mdna:93]
[same as prior period, unchanged from 0000320193-18-000070:mdna:92]

[0000320193-18-000100:mdna:94]
In October 2016, the FASB issued ASU No. 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory (“ASU 2016-16”), which requires the recognition of the income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. The Company will adopt ASU 2016-16 in its first quarter of 2019 utilizing the modified retrospective transition method. Currently, the Company estimates recording up to $4 billion of net deferred tax assets on its Condensed Consolidated Balance Sheets upon adoption. However, the ultimate impact of adopting ASU 2016-16 will depend on the balance of intellectual property transferred between its subsidiaries as of the adoption date, as well as the deferred tax impact of the new minimum tax on certain future foreign earnings. The Company will recognize incremental deferred income tax expense thereafter as these net deferred tax assets are utilized.

[0000320193-18-000100:mdna:95]
[same as prior period, unchanged from 0000320193-18-000070:mdna:94]

[0000320193-18-000100:mdna:96]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842) (“ASU 2016-02”), which modifies lease accounting for lessees to increase transparency and comparability by recording lease assets and liabilities for operating leases and disclosing key information about leasing arrangements. The Company will adopt ASU 2016-02 in its first quarter of 2020 utilizing the modified retrospective transition method. While the Company is currently evaluating the impact of adopting ASU 2016-02, based on the lease portfolio as of June 30, 2018, the Company anticipates recording lease assets and liabilities of approximately $8.8 billion on its Condensed Consolidated Balance Sheets, with no material impact to its Condensed Consolidated Statements of Operations. However, the ultimate impact of adopting ASU 2016-02 will depend on the Company’s lease portfolio as of the adoption date.

[0000320193-18-000100:mdna:97]
[same as prior period, unchanged from 0000320193-18-000070:mdna:96]

[0000320193-18-000100:mdna:98]
In January 2016, the FASB issued ASU No. 2016-01, Financial Instruments – Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities (“ASU 2016-01”), which updates certain aspects of recognition, measurement, presentation and disclosure of financial instruments. The Company will adopt ASU 2016-01 in its first quarter of 2019 utilizing the modified retrospective transition method. Based on the composition of the Company’s investment portfolio, the adoption of ASU 2016-01 is not expected to have a material impact on its consolidated financial statements.

[0000320193-18-000100:mdna:99]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (“ASU 2016-13”), which modifies the measurement of expected credit losses of certain financial instruments. The Company will adopt ASU 2016-13 in its first quarter of 2021 utilizing the modified retrospective transition method. Based on the composition of the Company’s investment portfolio, current market conditions, and historical credit loss activity, the adoption of ASU 2016-13 is not expected to have a material impact on its consolidated financial statements.

[0000320193-18-000100:mdna:100]
[same as prior period, unchanged from 0000320193-18-000070:mdna:99]

[0000320193-18-000100:mdna:101]
In May 2014, the FASB issued ASU No. 2014-09, Revenue from Contracts with Customers (Topic 606) (“ASU 2014-09”), which amends the existing accounting standards for revenue recognition. ASU 2014-09 is based on principles that govern the recognition of revenue at an amount an entity expects to be entitled when products are transferred to customers.

[0000320193-18-000100:mdna:102]
Subsequently, the FASB has issued the following standards related to ASU 2014-09: ASU No. 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (“ASU 2016-08”); ASU No. 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing (“ASU 2016-10”); ASU No. 2016-12, Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients (“ASU 2016-12”); and ASU No. 2016-20, Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers (“ASU 2016-20”). The Company must adopt ASU 2016-08, ASU 2016-10, ASU 2016-12 and ASU 2016-20 with ASU 2014-09 (collectively, the “new revenue standards”).

[0000320193-18-000100:mdna:103]
[same as prior period, unchanged from 0000320193-18-000070:mdna:102]

[0000320193-18-000100:mdna:104]
[same as prior period, unchanged from 0000320193-18-000070:mdna:103]

[0000320193-18-000100:mdna:105]
The following tables present selected financial information and statistics as of June 30, 2018 and September 30, 2017 and for the first nine months of 2018 and 2017 (in millions):

[0000320193-18-000100:mdna:106]
|  | June 30, 2018 |  | September 30, 2017 |
| Cash, cash equivalents and marketable securities (1) | $ | 243,743 |  |  | $ | 268,895 |  |
| Property, plant and equipment, net | $ | 38,117 |  |  | $ | 33,783 |  |
| Commercial paper | $ | 11,974 |  |  | $ | 11,977 |  |
| Total term debt | $ | 102,626 |  |  | $ | 103,703 |  |
| Working capital | $ | 27,213 |  |  | $ | 27,831 |  |

[0000320193-18-000100:mdna:107]
|  | Nine Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |
| Cash generated by operating activities (2) | $ | 57,911 |  |  | $ | 48,476 |  |
| Cash generated by/(used in) investing activities | $ | 19,067 |  |  | $ | (36,504 | ) |
| Cash used in financing activities (2) | $ | (65,296 | ) |  | $ | (13,885 | ) |

[0000320193-18-000100:mdna:108]
| (1) | As of June 30, 2018, total cash, cash equivalents and marketable securities included $8.8 billion, related to the State Aid Decision and other agreements, which was restricted from general use. |

[0000320193-18-000100:mdna:109]
| (2) | Refer to Note 1, “Summary of Significant Accounting Polices” in the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Form 10-Q for more information on the prior period reclassification related to the Company’s adoption of ASU 2016-09. |

[0000320193-18-000100:mdna:110]
[same as prior period, unchanged from 0000320193-18-000070:mdna:108]

[0000320193-18-000100:mdna:111]
In connection with the State Aid Decision, the Company began funding amounts into escrow during the third quarter of 2018, where they will remain pending conclusion of all appeals. As of June 30, 2018, €4.5 billion of the recovery amount was funded into escrow and was restricted from general use. Subsequent to June 30, 2018, the Company has funded an additional €4.5 billion of the recovery amount into escrow. The Company expects to fund the remaining recovery amount during the fourth quarter of 2018.

[0000320193-18-000100:mdna:112]
The Company’s marketable securities investment portfolio is primarily invested in highly rated securities, and its investment policy generally limits the amount of credit exposure to any one issuer. The policy generally requires securities to be investment grade, with the primary objective of minimizing the potential risk of principal loss.

[0000320193-18-000100:mdna:113]
During the nine months ended June 30, 2018, cash generated by operating activities of $57.9 billion was a result of $45.4 billion of net income and an increase in the net change in operating assets and liabilities of $33.9 billion, partially offset by non-cash adjustments to net income of $21.4 billion. Cash generated by investing activities of $19.1 billion during the nine months ended June 30, 2018 consisted primarily of proceeds from maturities and sales of marketable securities, net of purchases, of $31.8 billion, partially offset by cash used to acquire property, plant and equipment of $10.3 billion. Cash used in financing activities of $65.3 billion during the nine months ended June 30, 2018 consisted primarily of cash used to repurchase common stock of $53.6 billion, cash used to pay dividends and dividend equivalents of $10.2 billion and cash used to repay term debt of $6.5 billion, partially offset by proceeds from the issuance of term debt, net of $7.0 billion.

[0000320193-18-000100:mdna:114]
During the nine months ended July 1, 2017, cash generated by operating activities of $48.5 billion was a result of $37.6 billion of net income, non-cash adjustments to net income of $16.0 billion and a decrease in the net change in operating assets and liabilities of $5.1 billion, which included a one-time payment of $1.9 billion related to a multi-year license agreement. Cash used in investing activities of $36.5 billion during the nine months ended July 1, 2017 consisted primarily of cash used for purchases of marketable securities, net of sales and maturities, of $27.7 billion and cash used to acquire property, plant and equipment of $8.6 billion. Cash used in financing activities of $13.9 billion during the nine months ended July 1, 2017 consisted primarily of cash used to repurchase common stock of $25.1 billion, cash used to pay dividends and dividend equivalents of $9.5 billion and cash used to repay term debt of $3.5 billion, partially offset by proceeds from the issuance of term debt, net of $21.7 billion and proceeds from commercial paper, net of $3.9 billion.

[0000320193-18-000100:mdna:115]
[same as prior period, unchanged from 0000320193-18-000070:mdna:113]

[0000320193-18-000100:mdna:116]
The Company’s capital expenditures were $11.1 billion during the first nine months of 2018. The Company anticipates utilizing approximately $17.0 billion for capital expenditures during 2018, which includes product tooling and manufacturing process equipment; data centers; corporate facilities and infrastructure, including information systems hardware, software and enhancements; and retail store facilities.

[0000320193-18-000100:mdna:117]
[same as prior period, unchanged from 0000320193-18-000070:mdna:115]

[0000320193-18-000100:mdna:118]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses the net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of June 30, 2018, the Company had $12.0 billion of Commercial Paper outstanding, with a weighted-average interest rate of 2.03% and maturities generally less than nine months.

[0000320193-18-000100:mdna:119]
As of June 30, 2018, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $104.1 billion (collectively the “Notes”). During the first nine months of 2018, the Company repaid $6.5 billion of its Notes. The Company has entered, and in the future may enter, into interest rate swaps to manage interest rate risk on the Notes. In addition, the Company has entered, and in the future may enter, into foreign currency swaps to manage foreign currency risk on the Notes.

[0000320193-18-000100:mdna:120]
[same as prior period, unchanged from 0000320193-18-000070:mdna:118]

[0000320193-18-000100:mdna:121]
[same as prior period, unchanged from 0000320193-18-000070:mdna:119]

[0000320193-18-000100:mdna:122]
During the third quarter of 2018, the Company repurchased 112.8 million shares of its common stock for $20.0 billion in connection with two separate share repurchase programs. Of the $20.0 billion, $10.4 billion was repurchased under the Company’s previous share repurchase program of up to $210 billion, thereby completing that program. On May 1, 2018, the Company announced the Board of Directors had authorized a new program to repurchase up to $100 billion of the Company’s common stock. The remaining $9.6 billion repurchased during the third quarter of 2018 was in connection with the new share repurchase program.

[0000320193-18-000100:mdna:123]
On May 1, 2018, the Company also announced the Board of Directors raised the Company’s quarterly cash dividend from $0.63 to $0.73 per share, beginning with the dividend paid during the third quarter of 2018. The Company intends to increase its dividend on an annual basis, subject to declaration by the Board of Directors. The Company plans to use current cash and cash generated from ongoing operating activities to fund its share repurchase program and quarterly cash dividend.

[0000320193-18-000100:mdna:124]
[same as prior period, unchanged from 0000320193-18-000070:mdna:124]

[0000320193-18-000100:mdna:125]
The Company has not entered into any transactions with unconsolidated entities whereby the Company has financial guarantees, subordinated retained interests, derivative instruments, or other contingent arrangements that expose the Company to material continuing risks, contingent liabilities, or any other obligation under a variable interest in an unconsolidated entity that provides financing, liquidity, market risk or credit risk support to the Company, or engages in leasing, hedging or R&D services with the Company.

[0000320193-18-000100:mdna:126]
[same as prior period, unchanged from 0000320193-18-000070:mdna:126]

[0000320193-18-000100:mdna:127]
As of June 30, 2018, the Company’s total future minimum lease payments under noncancelable operating leases were $9.6 billion. The Company’s retail store and other facility leases typically have original terms not exceeding 10 years and generally contain multi-year renewal options.

[0000320193-18-000100:mdna:128]
[same as prior period, unchanged from 0000320193-18-000070:mdna:128]

[0000320193-18-000100:mdna:129]
The Company utilizes several outsourcing partners to manufacture sub-assemblies for the Company’s products and to perform final assembly and testing of finished products. These outsourcing partners acquire components and build product based on demand information supplied by the Company, which typically covers periods up to 150 days. The Company also obtains individual components for its products from a wide variety of individual suppliers. As of June 30, 2018, the Company expects to pay $31.4 billion under manufacturing-related supplier arrangements, substantially all of which is noncancelable.

[0000320193-18-000100:mdna:130]
[same as prior period, unchanged from 0000320193-18-000070:mdna:130]

[0000320193-18-000100:mdna:131]
The Company’s other purchase obligations consist of noncancelable obligations to acquire capital assets, including product tooling and manufacturing process equipment, and noncancelable obligations related to advertising, licensing, R&D, internet and telecommunications services and other obligations. As of June 30, 2018, the Company had other purchase obligations of $8.5 billion.

[0000320193-18-000100:mdna:132]
[same as prior period, unchanged from 0000320193-18-000070:mdna:132]

[0000320193-18-000100:mdna:133]
The Company’s other non-current liabilities in the Condensed Consolidated Balance Sheets consist primarily of long-term taxes payable of $34.0 billion, and net unrecognized tax benefits and related interest and penalties of $6.8 billion. The Company plans to pay the tax payable in installments in accordance with the Act. The Company is unable to make a reasonably reliable estimate of the timing of payments related to unrecognized tax benefits due to uncertainties in the timing of tax audit outcomes.

[0000320193-18-000100:mdna:134]
[same as prior period, unchanged from 0000320193-18-000070:mdna:134]

[0000320193-18-000100:mdna:135]
Agreements entered into by the Company sometimes include indemnification provisions which may subject the Company to costs and damages in the event of a claim against an indemnified third party. Except as disclosed in Part I, Item 1 of this Form 10-Q in the Notes to Condensed Consolidated Financial Statements in Note 9, “Commitments and Contingencies” under the heading “Contingencies,” in the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to indemnification of third parties.

[0000320193-18-000100:mdna:136]
[same as prior period, unchanged from 0000320193-18-000070:mdna:136]

[0000320193-18-000100:mdna:137]
The Company has entered into indemnification agreements with its directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers of the Company and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. While the Company maintains directors and officers liability insurance coverage, such insurance coverage may be insufficient to cover all losses or all types of claims that may arise.

[0000320193-18-000100:mdna:138]
[same as prior period, unchanged from 0000320193-18-000070:mdna:138]

[0000320193-18-000100:mdna:139]
[same as prior period, unchanged from 0000320193-18-000070:mdna:139]

[0000320193-18-000100:mdna:140]
[same as prior period, unchanged from 0000320193-18-000070:mdna:140]

[0000320193-18-000100:mdna:141]
[same as prior period, unchanged from 0000320193-18-000070:mdna:141]

[0000320193-18-000100:mdna:142]
[same as prior period, unchanged from 0000320193-18-000070:mdna:142]

[0000320193-18-000100:mdna:143]
[same as prior period, unchanged from 0000320193-18-000070:mdna:143]

[0000320193-18-000100:mdna:144]
[same as prior period, unchanged from 0000320193-18-000070:mdna:144]

[0000320193-18-000100:mdna:145]
On December 22, 2017, the U.S. enacted the Act, which significantly changed U.S. tax law. The Act lowered the Company’s U.S. statutory federal income tax rate from 35% to 21% effective January 1, 2018, while also imposing a deemed repatriation tax on previously deferred foreign income. The Act also created a new minimum tax on certain future foreign earnings. During the first quarter of 2018, the Company’s income tax expense included a provisional estimate of $2.6 billion in accordance with the SEC Staff Accounting Bulletin No. 118. This $2.6 billion provisional estimate included $1.8 billion related to the impact of remeasuring the Company’s deferred tax balances to reflect the new lower tax rate, and approximately $800 million associated with the net impact of the deemed repatriation tax. During the third quarter of 2018, the Company reduced its estimate of the deemed repatriation tax by $1.0 billion and adjusted the estimated impact of the deemed repatriation tax on unrecognized tax benefits by $700 million, resulting in the reduction of the Company’s provisional estimate from $2.6 billion to $900 million. The impact of the adjustments to the provisional estimate for the deemed repatriation tax and unrecognized tax benefits was included in the Company’s income tax expense during the third quarter of 2018. Resolution of the provisional estimates of the Act’s effects different from the assumptions made by the Company could have a material impact on the Company’s financial condition and operating results.
