# AAPL 8-K — 0000320193-26-000011 filed 2026-04-30

## item codes, every 8-K on or before 2026-05-01

- 2026-04-30 0000320193-26-000011 — 2.02, 9.01
- 2026-04-20 0001140361-26-015711 — 5.02
- 2026-02-24 0001140361-26-006577 — 5.07, 9.01
- 2026-01-29 0000320193-26-000005 — 2.02, 9.01
- 2026-01-02 0001140361-26-000199 — 5.02
- 2025-12-05 0001140361-25-044561 — 5.02
- 2025-10-30 0000320193-25-000077 — 2.02, 9.01
- 2025-07-31 0000320193-25-000071 — 2.02, 9.01
- 2025-07-25 0001140361-25-027340 — 5.02
- 2025-07-09 0001140361-25-025275 — 5.02
- 2025-05-12 0001140361-25-018400 — 8.01, 9.01
- 2025-05-01 0000320193-25-000055 — 2.02, 9.01
- 2025-02-25 0001140361-25-005876 — 5.07
- 2025-01-30 0000320193-25-000007 — 2.02, 9.01
- 2025-01-03 0001140361-25-000228 — 5.02
- 2024-10-31 0000320193-24-000120 — 2.02, 9.01
- 2024-09-10 0001140361-24-040659 — 7.01
- 2024-08-26 0001140361-24-038601 — 5.02
- 2024-08-23 0001140361-24-038403 — 5.03, 9.01
- 2024-08-01 0000320193-24-000080 — 2.02, 9.01
- 2024-05-03 0001140361-24-024352 — 7.01, 9.01
- 2024-05-02 0000320193-24-000067 — 2.02, 9.01
- 2024-02-28 0001140361-24-010155 — 5.07
- 2024-02-01 0000320193-24-000005 — 2.02, 9.01
- 2023-11-02 0000320193-23-000104 — 2.02, 9.01
- 2023-08-03 0000320193-23-000075 — 2.02, 9.01
- 2023-05-10 0001140361-23-023909 — 8.01, 9.01
- 2023-05-04 0000320193-23-000063 — 2.02, 9.01
- 2023-03-10 0001140361-23-011192 — 5.07
- 2023-02-02 0000320193-23-000005 — 2.02, 9.01
- 2022-11-07 0001193125-22-278435 — 7.01, 9.01
- 2022-10-27 0000320193-22-000107 — 2.02, 9.01
- 2022-08-19 0001193125-22-225365 — 5.02, 5.03, 9.01
- 2022-08-08 0001193125-22-214914 — 8.01, 9.01
- 2022-07-28 0000320193-22-000069 — 2.02, 9.01
- 2022-04-28 0000320193-22-000058 — 2.02, 9.01
- 2022-03-04 0001193125-22-066169 — 5.02, 5.07, 9.01
- 2022-01-27 0000320193-22-000006 — 2.02, 9.01
- 2021-11-12 0001193125-21-328151 — 5.02, 5.03, 9.01
- 2021-10-28 0000320193-21-000104 — 2.02, 9.01
- 2021-08-05 0001193125-21-237787 — 8.01, 9.01
- 2021-07-27 0000320193-21-000063 — 2.02, 9.01
- 2021-04-28 0000320193-21-000055 — 2.02, 9.01
- 2021-02-24 0001193125-21-054710 — 5.07
- 2021-02-08 0001193125-21-032394 — 8.01, 9.01
- 2021-01-27 0000320193-21-000009 — 2.02, 9.01
- 2021-01-05 0001193125-21-001982 — 5.02
- 2020-10-29 0000320193-20-000094 — 2.02, 9.01
- 2020-08-20 0001193125-20-225672 — 8.01, 9.01
- 2020-08-07 0001193125-20-213158 — 5.03, 9.01
- 2020-07-30 0000320193-20-000060 — 2.02, 9.01
- 2020-05-11 0001193125-20-139112 — 8.01, 9.01
- 2020-04-30 0000320193-20-000050 — 2.02, 9.01
- 2020-02-27 0001193125-20-050884 — 5.07
- 2020-02-18 0001193125-20-039203 — 7.01, 9.01
- 2020-01-28 0000320193-20-000008 — 2.02, 9.01
- 2019-11-15 0001193125-19-292676 — 8.01, 9.01
- 2019-10-30 0000320193-19-000117 — 2.02, 9.01
- 2019-09-13 0000320193-19-000093 — 5.02
- 2019-09-11 0001193125-19-242975 — 8.01, 9.01
- 2019-07-30 0000320193-19-000073 — 2.02, 9.01
- 2019-04-30 0000320193-19-000063 — 2.02, 9.01
- 2019-03-04 0000320193-19-000032 — 5.07
- 2019-02-06 0000320193-19-000026 — 5.02
- 2019-01-29 0000320193-19-000007 — 2.02, 9.01
- 2019-01-02 0000320193-19-000002 — 2.02, 9.01
- 2018-11-01 0000320193-18-000142 — 2.02, 9.01
- 2018-07-31 0000320193-18-000098 — 2.02, 9.01
- 2018-05-08 0001193125-18-154948 — 8.01 — amendment of 0001193125-18-154515
- 2018-05-07 0001193125-18-154515 — 8.01, 9.01
- 2018-05-01 0000320193-18-000067 — 2.02, 9.01
- 2018-02-14 0001193125-18-045761 — 5.07, 9.01
- 2018-02-01 0000320193-18-000005 — 2.02, 9.01
- 2017-11-13 0001193125-17-341015 — 8.01, 9.01
- 2017-11-02 0000320193-17-000067 — 2.02, 9.01
- 2017-10-12 0001193125-17-308859 — 5.02
- 2017-09-12 0001193125-17-282809 — 8.01, 9.01
- 2017-08-18 0001193125-17-262261 — 8.01, 9.01
- 2017-08-01 0000320193-17-000006 — 2.02, 9.01
- 2017-06-20 0001193125-17-208226 — 8.01, 9.01
- 2017-05-24 0001193125-17-181867 — 8.01, 9.01
- 2017-05-11 0001193125-17-167400 — 8.01, 9.01
- 2017-05-02 0001628280-17-004663 — 2.02, 9.01
- 2017-03-03 0001193125-17-069853 — 8.01, 9.01
- 2017-03-01 0001193125-17-064019 — 5.07
- 2017-02-09 0001193125-17-036283 — 8.01, 9.01
- 2017-01-31 0001628280-17-000663 — 2.02, 9.01
- 2016-12-15 0001628280-16-022047 — 5.03, 9.01
- 2016-10-25 0001628280-16-020258 — 2.02, 9.01
- 2016-08-04 0001193125-16-672044 — 8.01, 9.01
- 2016-07-26 0001628280-16-017762 — 2.02, 9.01
- 2016-06-22 0001193125-16-628957 — 8.01, 9.01
- 2016-04-26 0001193125-16-556520 — 2.02, 9.01
- 2016-03-24 0001193125-16-516891 — 8.01, 9.01
- 2016-03-01 0001193125-16-488223 — 5.02, 5.07, 9.01
- 2016-02-23 0001193125-16-473562 — 8.01, 9.01
- 2016-01-26 0001193125-16-438421 — 2.02, 9.01
- 2015-12-22 0001193125-15-410853 — 5.03, 9.01
- 2015-12-17 0001193125-15-406279 — 5.02
- 2015-10-27 0001193125-15-354756 — 2.02, 9.01
- 2015-10-02 0001193125-15-336615 — 5.02
- 2015-09-17 0001193125-15-322466 — 8.01, 9.01
- 2015-07-31 0001193125-15-273023 — 8.01, 9.01
- 2015-07-21 0001193125-15-258464 — 2.02, 9.01
- 2015-06-10 0001193125-15-219298 — 8.01, 9.01
- 2015-05-13 0001193125-15-186064 — 8.01, 9.01
- 2015-04-27 0001193125-15-149607 — 7.01, 9.01
- 2015-04-27 0001193125-15-149590 — 2.02, 9.01
- 2015-03-13 0001104659-15-019336 — 5.07, 9.01
- 2015-02-09 0001193125-15-039270 — 8.01, 9.01
- 2015-01-28 0001193125-15-023732 — 8.01, 9.01
- 2015-01-27 0001193125-15-021857 — 2.02, 9.01
- 2014-11-10 0001193125-14-406296 — 8.01, 9.01
- 2014-10-20 0001193125-14-376361 — 2.02, 9.01
- 2014-07-23 0001193125-14-277193 — 8.01, 9.01
- 2014-07-22 0001193125-14-275598 — 2.02, 9.01
- 2014-07-17 0001193125-14-271698 — 5.02
- 2014-06-06 0001193125-14-228798 — 5.03, 9.01
- 2014-05-30 0001181431-14-021923 — 5.02
- 2014-05-06 0001193125-14-184969 — 8.01, 9.01
- 2014-04-23 0001193125-14-154883 — 7.01, 9.01
- 2014-04-23 0001193125-14-154871 — 2.02, 9.01
- 2014-03-05 0001193125-14-084697 — 5.02, 5.03, 5.07, 9.01
- 2014-01-27 0001193125-14-022238 — 2.02, 9.01
- 2013-10-28 0001193125-13-413498 — 2.02, 9.01
- 2013-09-23 0001181431-13-050140 — 8.01
- 2013-07-30 0001181431-13-041847 — 5.02
- 2013-07-23 0001193125-13-298914 — 2.02, 9.01
- 2013-06-21 0001193125-13-267629 — 5.02
- 2013-05-03 0001193125-13-199324 — 8.01, 9.01
- 2013-04-24 0001193125-13-170623 — 8.01, 9.01
- 2013-04-23 0001193125-13-167469 — 7.01, 9.01
- 2013-04-23 0001193125-13-167458 — 2.02, 9.01
- 2013-03-01 0001193125-13-085842 — 5.07
- 2013-01-23 0001193125-13-020783 — 2.02, 9.01
- 2012-10-25 0001193125-12-435506 — 2.02, 9.01
- 2012-07-24 0001193125-12-312355 — 2.02, 9.01
- 2012-06-28 0001181431-12-038301 — 5.02
- 2012-05-24 0001181431-12-032458 — 5.02
- 2012-04-24 0001193125-12-178928 — 2.02, 9.01
- 2012-02-27 0001193125-12-081892 — 5.07
- 2012-01-24 0001193125-12-021833 — 2.02, 9.01
- 2011-11-16 0001181431-11-056354 — 5.02
- 2011-10-18 0001193125-11-273826 — 2.02, 9.01
- 2011-10-06 0001181431-11-051976 — 8.01
- 2011-08-26 0001181431-11-047179 — 5.02
- 2011-07-19 0001193125-11-191368 — 2.02, 9.01
- 2011-06-15 0001181431-11-036782 — 5.02
- 2011-04-20 0001193125-11-103732 — 2.02, 9.01
- 2011-02-24 0001193125-11-045411 — 5.07
- 2011-01-18 0001193125-11-009392 — 2.02, 9.01
- 2011-01-18 0001181431-11-003847 — 5.02
- 2010-11-17 0001181431-10-056327 — 5.02, 5.03, 9.01
- 2010-10-18 0001193125-10-230992 — 2.02, 9.01
- 2010-07-20 0001193125-10-161807 — 2.02, 9.01
- 2010-04-20 0001193125-10-087786 — 2.02, 9.01
- 2010-03-12 0001181431-10-016054 — 5.02
- 2010-03-01 0001193125-10-044765 — 5.02, 5.07, 9.01
- 2010-01-25 0001193125-10-012096 — 2.02, 9.01
- 2009-10-19 0001193125-09-209633 — 2.02, 9.01
- 2009-08-04 0001181431-09-037492 — 5.02
- 2009-07-21 0001193125-09-152290 — 2.02, 9.01
- 2009-06-02 0001181431-09-028400 — 5.03
- 2009-04-22 0001193125-09-084599 — 2.02, 9.01
- 2009-02-27 0001181431-09-012161 — 4.01
- 2009-01-21 0001193125-09-009009 — 2.02, 9.01
- 2009-01-16 0001181431-09-003017 — 5.02
- 2008-10-21 0001193125-08-213642 — 2.02, 9.01
- 2008-08-26 0001181431-08-050059 — 5.03
- 2008-07-21 0001193125-08-154381 — 2.02, 9.01
- 2008-06-09 0001181431-08-037620 — 8.01
- 2008-04-23 0001193125-08-088001 — 2.02, 9.01
- 2008-01-22 0001193125-08-009715 — 2.02, 9.01
- 2008-01-15 0001181431-08-003342 — 2.02, 8.01
- 2008-01-08 0001181431-08-002372 — 5.02
- 2007-10-22 0001104659-07-076142 — 2.02, 9.01
- 2007-07-25 0001104659-07-056111 — 2.02, 9.01
- 2007-05-16 0001104659-07-040672 — 5.02, 9.01
- 2007-04-25 0001104659-07-031354 — 2.02, 9.01
- 2007-04-24 0001104659-07-030938 — 8.01, 9.01
- 2007-02-21 0001104659-07-012760 — 5.03, 9.01
- 2007-01-17 0001104659-07-002905 — 2.02, 9.01
- 2007-01-10 0001104659-07-001648 — 5.03, 9.01
- 2006-10-27 0001104659-06-069015 — 8.01
- 2006-10-18 0001104659-06-067275 — 2.02, 9.01
- 2006-10-04 0001104659-06-064935 — 5.02, 8.01, 9.01
- 2006-09-01 0001104659-06-058808 — 1.01, 5.02, 5.03, 9.01
- 2006-08-11 0001104659-06-054118 — 2.02, 3.01, 9.01
- 2006-08-04 0001104659-06-051302 — 2.02, 4.02, 9.01
- 2006-07-19 0001104659-06-047739 — 2.02, 9.01
- 2006-04-21 0001181431-06-024759 — 1.01
- 2006-04-19 0001104659-06-025992 — 2.02, 9.01
- 2006-01-18 0001104659-06-002690 — 2.02, 9.01
- 2006-01-10 0001104659-06-001428 — 2.02
- 2005-12-19 0001181431-05-067468 — 1.01
- 2005-10-14 0001181431-05-056604 — 5.02
- 2005-10-11 0001104659-05-048094 — 2.02, 9.01
- 2005-08-26 0001181431-05-049163 — 1.01
- 2005-08-15 0001181431-05-046871 — 1.01
- 2005-07-13 0001104659-05-032297 — 2.02, 9.01
- 2005-06-06 0001181431-05-033177 — 8.01
- 2005-04-26 0001181431-05-023450 — 1.01
- 2005-04-13 0001104659-05-016307 — 2.02, 9.01
- 2005-03-02 0001181431-05-013840 — 3.03, 5.03
- 2005-02-11 0001104659-05-005507 — 8.01
- 2005-01-12 0001104659-05-001183 — 2.02, 9.01
- 2005-01-11 0001104659-05-001049 — 2.02
- 2004-10-13 0001104659-04-030400 — 2.02, 9.01
- 2004-07-14 0001104659-04-019574 — 12, 7
- 2004-04-14 0001104659-04-010122 — 12, 7
- 2004-01-14 0001104659-04-000896 — 12, 7
- 2003-10-15 0001104659-03-022879 — 12, 7
- 2003-07-16 0001104659-03-014913 — 7, 9
- 2003-04-16 0001047469-03-013617 — 7, 9
- 2003-03-21 0001104659-03-004649 — 5, 7
- 2002-08-13 0000912057-02-031595 — 5, 7
- 2002-08-05 0000912057-02-029692 — 5, 7
- 2000-01-24 0000912057-00-002128 — 5, 7
- 1999-09-07 0000320193-99-000010 — 2
- 1999-07-16 0000320193-99-000007 — 2
- 1998-12-23 0000320193-98-000010 — 1
- 1998-01-08 0000320193-98-000001 — 2
- 1997-09-25 0000320193-97-000019 — 2
- 1997-09-25 0000320193-97-000018 — 2
- 1997-09-05 0000320193-97-000016 — 2
- 1997-07-28 0000320193-97-000012 — 4
- 1997-04-25 0000320193-97-000009 — 5
- 1997-04-10 0000320193-97-000007 — 7
- 1996-12-24 0000320193-96-000027 — 7
- 1996-12-23 0000320193-96-000025 — 4 — amendment of 0000320193-96-000021
- 1996-12-13 0000320193-96-000021 — 4
- 1996-10-28 0000912057-96-023874 — 5, 7
- 1996-06-17 0000320193-96-000014 — 1
- 1996-04-12 0000320193-96-000006 — 1

## late-filing notifications on or before 2026-05-01

- 2006-12-15 0001104659-06-081617 — NT 10-K, for the period ended 2006-09-30
- 2006-08-11 0001104659-06-053743 — NT 10-Q, for the period ended 2006-07-01

## item 2.02 — earnings release, exhibit 99.1

[0000320193-26-000011:8k_2_02:1]
EX-99.1
2
a8-kex991q2202603282026.htm
EX-99.1

[0000320193-26-000011:8k_2_02:2]
Document

[0000320193-26-000011:8k_2_02:3]
Exhibit 99.1

[0000320193-26-000011:8k_2_02:4]
Apple reports second quarter results

[0000320193-26-000011:8k_2_02:5]
March quarter records for total company revenue, iPhone revenue, and EPS

[0000320193-26-000011:8k_2_02:6]
Services revenue reaches new all-time high

[0000320193-26-000011:8k_2_02:7]
CUPERTINO, CALIFORNIA — Apple® today announced financial results for its fiscal 2026 second quarter ended March 28, 2026. The Company posted quarterly revenue of $111.2 billion, up 17 percent year over year. Diluted earnings per share was $2.01, up 22 percent year over year.

[0000320193-26-000011:8k_2_02:8]
“Today Apple is proud to report our best March quarter ever, with revenue of $111.2 billion and double-digit growth across every geographic segment,” said Tim Cook, Apple’s CEO. “iPhone achieved a March quarter revenue record, fueled by such extraordinary demand for the iPhone 17 lineup. During the quarter, Services achieved yet another all-time record, and we were excited to introduce remarkable new products to our strongest lineup ever. That included the addition of the iPhone 17e and the M4-powered iPad Air, along with the launch of MacBook Neo, which is captivating customers all around the world.”

[0000320193-26-000011:8k_2_02:9]
“Our strong business performance during the March quarter generated over $28 billion in operating cash flow and drove new March quarter records for both operating cash flow and EPS,” said Kevan Parekh, Apple’s CFO. “Continued strong customer demand for our products and services once again helped us achieve a new all-time high for our installed base of active devices across all major product categories and geographic segments.”

[0000320193-26-000011:8k_2_02:10]
Apple’s board of directors has declared a cash dividend of $0.27 per share of the Company’s common stock, an increase of 4 percent. The dividend is payable on May 14, 2026, to shareholders of record as of the close of business on May 11, 2026. The board of directors has also authorized an additional program to repurchase up to $100 billion of the Company’s common stock.

[0000320193-26-000011:8k_2_02:11]
Apple will provide live streaming of its Q2 2026 financial results conference call beginning at 2:00 p.m. PT on April 30, 2026, at apple.com/investor/earnings-call. The webcast will be available for replay for approximately two weeks thereafter.

[0000320193-26-000011:8k_2_02:12]
Apple periodically provides information for investors on its corporate website, apple.com, and its investor relations website, investor.apple.com. This includes press releases and other information about financial performance, reports filed or furnished with the SEC, information on corporate governance, and details related to its annual meeting of shareholders.

[0000320193-26-000011:8k_2_02:13]
Apple revolutionized personal technology with the introduction of the Macintosh in 1984. Today, Apple leads the world in innovation with iPhone, iPad, Mac, AirPods, Apple Watch, and Apple Vision Pro. Apple’s six software platforms — iOS, iPadOS, macOS, watchOS, visionOS, and tvOS — provide seamless experiences across all Apple devices and empower people with breakthrough services including the App Store, Apple Music, Apple Pay, iCloud, and Apple TV. Apple’s more than 150,000 employees are dedicated to making the best products on earth and to leaving the world better than we found it.

[0000320193-26-000011:8k_2_02:14]
Press Contact:

[0000320193-26-000011:8k_2_02:15]
Josh Rosenstock

[0000320193-26-000011:8k_2_02:16]
Apple

[0000320193-26-000011:8k_2_02:17]
jrosenstock@apple.com

[0000320193-26-000011:8k_2_02:18]
(408) 862-1142

[0000320193-26-000011:8k_2_02:19]
Investor Relations Contact:

[0000320193-26-000011:8k_2_02:20]
Suhasini Chandramouli

[0000320193-26-000011:8k_2_02:21]
Apple

[0000320193-26-000011:8k_2_02:22]
suhasini@apple.com

[0000320193-26-000011:8k_2_02:23]
(408) 974-3123

[0000320193-26-000011:8k_2_02:24]
NOTE TO EDITORS: For additional information visit Apple Newsroom (www.apple.com/newsroom), or email Apple’s Media Helpline at media.help@apple.com.

[0000320193-26-000011:8k_2_02:25]
© 2026 Apple Inc. All rights reserved. Apple and the Apple logo are trademarks of Apple. Other company and product names may be trademarks of their respective owners.

[0000320193-26-000011:8k_2_02:26]
Apple Inc.

[0000320193-26-000011:8k_2_02:27]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS (Unaudited)

[0000320193-26-000011:8k_2_02:28]
(In millions, except number of shares, which are reflected in thousands, and per-share amounts)

[0000320193-26-000011:8k_2_02:29]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28,2026 |  | March 29,2025 |  | March 28,2026 |  | March 29,2025 |
| Net sales: |  |  |  |  |  |  |  |
| Products | $ | 80,208 |  |  | $ | 68,714 |  |  | $ | 193,951 |  |  | $ | 166,674 |  |
| Services | 30,976 |  |  | 26,645 |  |  | 60,989 |  |  | 52,985 |  |
| Total net sales (1) | 111,184 |  |  | 95,359 |  |  | 254,940 |  |  | 219,659 |  |
| Cost of sales: |  |  |  |  |  |  |  |
| Products | 49,179 |  |  | 44,030 |  |  | 116,657 |  |  | 103,477 |  |
| Services | 7,224 |  |  | 6,462 |  |  | 14,271 |  |  | 13,040 |  |
| Total cost of sales | 56,403 |  |  | 50,492 |  |  | 130,928 |  |  | 116,517 |  |
| Gross margin | 54,781 |  |  | 44,867 |  |  | 124,012 |  |  | 103,142 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 11,419 |  |  | 8,550 |  |  | 22,306 |  |  | 16,818 |  |
| Selling, general and administrative | 7,477 |  |  | 6,728 |  |  | 14,969 |  |  | 13,903 |  |
| Total operating expenses | 18,896 |  |  | 15,278 |  |  | 37,275 |  |  | 30,721 |  |
| Operating income | 35,885 |  |  | 29,589 |  |  | 86,737 |  |  | 72,421 |  |
| Other income/(expense), net | (52) |  |  | (279) |  |  | 98 |  |  | (527) |  |
| Income before provision for income taxes | 35,833 |  |  | 29,310 |  |  | 86,835 |  |  | 71,894 |  |
| Provision for income taxes | 6,255 |  |  | 4,530 |  |  | 15,160 |  |  | 10,784 |  |
| Net income | $ | 29,578 |  |  | $ | 24,780 |  |  | $ | 71,675 |  |  | $ | 61,110 |  |
| Earnings per share: |  |  |  |  |  |  |  |
| Basic | $ | 2.02 |  |  | $ | 1.65 |  |  | $ | 4.87 |  |  | $ | 4.06 |  |
| Diluted | $ | 2.01 |  |  | $ | 1.65 |  |  | $ | 4.85 |  |  | $ | 4.05 |  |
| Shares used in computing earnings per share: |  |  |  |  |  |  |  |
| Basic | 14,673,278 |  |  | 14,994,082 |  |  | 14,710,718 |  |  | 15,037,903 |  |
| Diluted | 14,725,873 |  |  | 15,056,133 |  |  | 14,768,115 |  |  | 15,103,499 |  |
| (1) Net sales by reportable segment: |  |  |  |  |  |  |  |
| Americas | $ | 45,093 |  |  | $ | 40,315 |  |  | $ | 103,622 |  |  | $ | 92,963 |  |
| Europe | 28,055 |  |  | 24,454 |  |  | 66,201 |  |  | 58,315 |  |
| Greater China | 20,497 |  |  | 16,002 |  |  | 46,023 |  |  | 34,515 |  |
| Japan | 8,401 |  |  | 7,298 |  |  | 17,814 |  |  | 16,285 |  |
| Rest of Asia Pacific | 9,138 |  |  | 7,290 |  |  | 21,280 |  |  | 17,581 |  |
| Total net sales | $ | 111,184 |  |  | $ | 95,359 |  |  | $ | 254,940 |  |  | $ | 219,659 |  |
| (1) Net sales by category: |  |  |  |  |  |  |  |
| iPhone | $ | 56,994 |  |  | $ | 46,841 |  |  | $ | 142,263 |  |  | $ | 115,979 |  |
| Mac | 8,399 |  |  | 7,949 |  |  | 16,785 |  |  | 16,936 |  |
| iPad | 6,914 |  |  | 6,402 |  |  | 15,509 |  |  | 14,490 |  |
| Wearables, Home and Accessories | 7,901 |  |  | 7,522 |  |  | 19,394 |  |  | 19,269 |  |
| Services | 30,976 |  |  | 26,645 |  |  | 60,989 |  |  | 52,985 |  |
| Total net sales | $ | 111,184 |  |  | $ | 95,359 |  |  | $ | 254,940 |  |  | $ | 219,659 |  |

[0000320193-26-000011:8k_2_02:30]
Apple Inc.

[0000320193-26-000011:8k_2_02:31]
CONDENSED CONSOLIDATED BALANCE SHEETS (Unaudited)

[0000320193-26-000011:8k_2_02:32]
(In millions, except number of shares, which are reflected in thousands, and par value)

[0000320193-26-000011:8k_2_02:33]
|  | March 28,2026 |  | September 27,2025 |
| ASSETS: |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 45,572 |  |  | $ | 35,934 |  |
| Marketable securities | 22,935 |  |  | 18,763 |  |
| Accounts receivable, net | 30,339 |  |  | 39,777 |  |
| Vendor non-trade receivables | 23,172 |  |  | 33,180 |  |
| Inventories | 6,747 |  |  | 5,718 |  |
| Other current assets | 15,349 |  |  | 14,585 |  |
| Total current assets | 144,114 |  |  | 147,957 |  |
| Non-current assets: |  |  |  |
| Marketable securities | 78,088 |  |  | 77,723 |  |
| Property, plant and equipment, net | 50,116 |  |  | 49,834 |  |
| Intangible assets, net | 21,334 |  |  | 11,093 |  |
| Other non-current assets | 77,430 |  |  | 72,634 |  |
| Total non-current assets | 226,968 |  |  | 211,284 |  |
| Total assets | $ | 371,082 |  |  | $ | 359,241 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY: |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 57,349 |  |  | $ | 69,860 |  |
| Other current liabilities | 57,654 |  |  | 66,387 |  |
| Deferred revenue | 9,331 |  |  | 9,055 |  |
| Commercial paper | 1,997 |  |  | 7,979 |  |
| Term debt | 8,310 |  |  | 12,350 |  |
| Total current liabilities | 134,641 |  |  | 165,631 |  |
| Non-current liabilities: |  |  |  |
| Term debt | 74,404 |  |  | 78,328 |  |
| Other non-current liabilities | 55,546 |  |  | 41,549 |  |
| Total non-current liabilities | 129,950 |  |  | 119,877 |  |
| Total liabilities | 264,591 |  |  | 285,508 |  |
| Commitments and contingencies |  |  |  |
| Shareholders’ equity: |  |  |  |
| Common stock and additional paid-in capital, $0.00001 par value: 50,400,000 shares authorized; 14,667,688 and 14,773,260 shares issued and outstanding, respectively | 99,507 |  |  | 93,568 |  |
| Retained earnings/(Accumulated deficit) | 12,359 |  |  | (14,264) |  |
| Accumulated other comprehensive loss | (5,375) |  |  | (5,571) |  |
| Total shareholders’ equity | 106,491 |  |  | 73,733 |  |
| Total liabilities and shareholders’ equity | $ | 371,082 |  |  | $ | 359,241 |  |

[0000320193-26-000011:8k_2_02:34]
Apple Inc.

[0000320193-26-000011:8k_2_02:35]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (Unaudited)

[0000320193-26-000011:8k_2_02:36]
(In millions)

[0000320193-26-000011:8k_2_02:37]
|  | Six Months Ended |
|  | March 28,2026 |  | March 29,2025 |
| Cash, cash equivalents, and restricted cash and cash equivalents, beginning balances | $ | 35,934 |  |  | $ | 29,943 |  |
| Operating activities: |  |  |  |
| Net income | 71,675 |  |  | 61,110 |  |
| Adjustments to reconcile net income to cash generated by operating activities: |  |  |  |
| Depreciation and amortization | 6,653 |  |  | 5,741 |  |
| Share-based compensation expense | 7,122 |  |  | 6,512 |  |
| Other | (1,717) |  |  | (2,217) |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | 9,295 |  |  | 7,266 |  |
| Vendor non-trade receivables | 10,008 |  |  | 9,171 |  |
| Inventories | (1,084) |  |  | 858 |  |
| Other current and non-current assets | (14,329) |  |  | (4,371) |  |
| Accounts payable | (12,297) |  |  | (14,604) |  |
| Other current and non-current liabilities | 7,301 |  |  | (15,579) |  |
| Cash generated by operating activities | 82,627 |  |  | 53,887 |  |
| Investing activities: |  |  |  |
| Purchases of marketable securities | (32,432) |  |  | (12,442) |  |
| Proceeds from maturities of marketable securities | 18,691 |  |  | 26,587 |  |
| Proceeds from sales of marketable securities | 8,615 |  |  | 5,210 |  |
| Payments for acquisition of property, plant and equipment | (4,344) |  |  | (6,011) |  |
| Other | (1,584) |  |  | (635) |  |
| Cash generated by/(used in) investing activities | (11,054) |  |  | 12,709 |  |
| Financing activities: |  |  |  |
| Payments for taxes related to net share settlement of equity awards | (3,252) |  |  | (3,205) |  |
| Payments for dividends and dividend equivalents | (7,743) |  |  | (7,614) |  |
| Repurchases of common stock | (36,989) |  |  | (49,504) |  |
| Repayments of term debt | (7,914) |  |  | (4,009) |  |
| Repayments of commercial paper, net | (5,911) |  |  | (3,968) |  |
| Other | (126) |  |  | (77) |  |
| Cash used in financing activities | (61,935) |  |  | (68,377) |  |
| Increase/(Decrease) in cash, cash equivalents, and restricted cash and cash equivalents | 9,638 |  |  | (1,781) |  |
| Cash, cash equivalents, and restricted cash and cash equivalents, ending balances | $ | 45,572 |  |  | $ | 28,162 |  |
| Supplemental cash flow disclosure: |  |  |  |
| Cash paid for income taxes, net | $ | 20,397 |  |  | $ | 31,683 |  |
