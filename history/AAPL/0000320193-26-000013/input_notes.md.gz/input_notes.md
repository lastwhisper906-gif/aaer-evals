# AAPL notes — 0000320193-26-000013


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000320193-26-000013:notes:1]
[same as prior period, unchanged from 0000320193-26-000006:notes:1]

[0000320193-26-000013:notes:2]
The condensed consolidated financial statements include the accounts of Apple Inc. and its wholly owned subsidiaries (collectively “Apple” or the “Company”). In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements and accompanying notes in conformity with U.S. generally accepted accounting principles (“GAAP”) requires the use of management estimates. Certain prior period amounts in the condensed consolidated financial statements and accompanying notes have been reclassified to conform to the current period’s presentation. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company’s annual consolidated financial statements and accompanying notes included in its Annual Report on Form 10-K for the fiscal year ended September 27, 2025 (the “2025 Form 10-K”).

[0000320193-26-000013:notes:3]
[same as prior period, unchanged from 0000320193-26-000006:notes:3]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000320193-26-000013:notes:4]
Revenue
The following table shows disaggregated net sales, as well as the portion of total net sales that was previously deferred, for the three- and six-month periods ended March 28, 2026 and March 29, 2025 (in millions):

[0000320193-26-000013:notes:5]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28,2026 |  | March 29,2025 |  | March 28,2026 |  | March 29,2025 |
| iPhone® | $ | 56,994 |  |  | $ | 46,841 |  |  | $ | 142,263 |  |  | $ | 115,979 |  |
| Mac® | 8,399 |  |  | 7,949 |  |  | 16,785 |  |  | 16,936 |  |
| iPad® | 6,914 |  |  | 6,402 |  |  | 15,509 |  |  | 14,490 |  |
| Wearables, Home and Accessories | 7,901 |  |  | 7,522 |  |  | 19,394 |  |  | 19,269 |  |
| Services | 30,976 |  |  | 26,645 |  |  | 60,989 |  |  | 52,985 |  |
| Total net sales | $ | 111,184 |  |  | $ | 95,359 |  |  | $ | 254,940 |  |  | $ | 219,659 |  |
| Portion of total net sales that was included in deferred revenue as of the beginning of the period | $ | 3,987 |  |  | $ | 3,672 |  |  | $ | 5,834 |  |  | $ | 5,440 |  |

[0000320193-26-000013:notes:6]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 10, “Segment Information” for the three- and six-month periods ended March 28, 2026 and March 29, 2025, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.

[0000320193-26-000013:notes:7]
As of March 28, 2026 and September 27, 2025, the Company had total deferred revenue of $14.7 billion and $13.7 billion, respectively. As of March 28, 2026, the Company expects 64% of total deferred revenue to be realized in less than a year, 23% within one-to-two years, 11% within two-to-three years and 2% in greater than three years.


## us-gaap:EarningsPerShareTextBlock

[0000320193-26-000013:notes:8]
Earnings Per Share
The following table shows the computation of basic and diluted earnings per share for the three- and six-month periods ended March 28, 2026 and March 29, 2025 (net income in millions and shares in thousands):

[0000320193-26-000013:notes:9]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28,2026 |  | March 29,2025 |  | March 28,2026 |  | March 29,2025 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 29,578 |  |  | $ | 24,780 |  |  | $ | 71,675 |  |  | $ | 61,110 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 14,673,278 |  |  | 14,994,082 |  |  | 14,710,718 |  |  | 15,037,903 |  |
| Effect of dilutive share-based awards | 52,595 |  |  | 62,051 |  |  | 57,397 |  |  | 65,596 |  |
| Weighted-average diluted shares | 14,725,873 |  |  | 15,056,133 |  |  | 14,768,115 |  |  | 15,103,499 |  |
| Basic earnings per share | $ | 2.02 |  |  | $ | 1.65 |  |  | $ | 4.87 |  |  | $ | 4.06 |  |
| Diluted earnings per share | $ | 2.01 |  |  | $ | 1.65 |  |  | $ | 4.85 |  |  | $ | 4.05 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000320193-26-000013:notes:10]
[same as prior period, unchanged from 0000320193-26-000006:notes:10]

[0000320193-26-000013:notes:11]
The following tables show the Company’s cash, cash equivalents and marketable securities by significant investment category as of March 28, 2026 and September 27, 2025 (in millions):

[0000320193-26-000013:notes:12]
|  | March 28, 2026 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | CurrentMarketableSecurities |  | Non-CurrentMarketableSecurities |
| Cash | $ | 29,740 |  |  | $ | — |  |  | $ | — |  |  | $ | 29,740 |  |  | $ | 29,740 |  |  | $ | — |  |  | $ | — |  |
| Level 1: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 6,588 |  |  | — |  |  | — |  |  | 6,588 |  |  | 6,588 |  |  | — |  |  | — |  |
| Mutual funds | 821 |  |  | 128 |  |  | (14) |  |  | 935 |  |  | — |  |  | 935 |  |  | — |  |
| Subtotal | 7,409 |  |  | 128 |  |  | (14) |  |  | 7,523 |  |  | 6,588 |  |  | 935 |  |  | — |  |
| Level 2 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 18,650 |  |  | 14 |  |  | (254) |  |  | 18,410 |  |  | 2,935 |  |  | 4,174 |  |  | 11,301 |  |
| U.S. agency securities | 7,483 |  |  | — |  |  | (112) |  |  | 7,371 |  |  | 2,923 |  |  | 2,470 |  |  | 1,978 |  |
| Non-U.S. government securities | 5,906 |  |  | 45 |  |  | (493) |  |  | 5,458 |  |  | — |  |  | 576 |  |  | 4,882 |  |
| Certificates of deposit and time deposits | 3,263 |  |  | — |  |  | — |  |  | 3,263 |  |  | 2,987 |  |  | 276 |  |  | — |  |
| Commercial paper | 3,628 |  |  | — |  |  | — |  |  | 3,628 |  |  | 399 |  |  | 3,229 |  |  | — |  |
| Corporate debt securities | 48,111 |  |  | 83 |  |  | (982) |  |  | 47,212 |  |  | — |  |  | 11,042 |  |  | 36,170 |  |
| Municipal securities | 122 |  |  | — |  |  | (1) |  |  | 121 |  |  | — |  |  | 95 |  |  | 26 |  |
| Mortgage- and asset-backed securities | 25,106 |  |  | 64 |  |  | (1,301) |  |  | 23,869 |  |  | — |  |  | 138 |  |  | 23,731 |  |
| Subtotal | 112,269 |  |  | 206 |  |  | (3,143) |  |  | 109,332 |  |  | 9,244 |  |  | 22,000 |  |  | 78,088 |  |
| Total | $ | 149,418 |  |  | $ | 334 |  |  | $ | (3,157) |  |  | $ | 146,595 |  |  | $ | 45,572 |  |  | $ | 22,935 |  |  | $ | 78,088 |  |

[0000320193-26-000013:notes:13]
[same as prior period, unchanged from 0000320193-26-000006:notes:13]

[0000320193-26-000013:notes:14]
[same as prior period, unchanged from 0000320193-26-000006:notes:14]

[0000320193-26-000013:notes:15]
As of March 28, 2026, 79% of the Company’s non-current marketable debt securities other than mortgage- and asset-backed securities had maturities between 1 and 5 years, 17% between 5 and 10 years, and 4% greater than 10 years. As of March 28, 2026, 13% of the Company’s non-current mortgage- and asset-backed securities had maturities between 1 and 5 years, 22% between 5 and 10 years, and 65% greater than 10 years.

[0000320193-26-000013:notes:16]
[same as prior period, unchanged from 0000320193-26-000006:notes:16]

[0000320193-26-000013:notes:17]
[same as prior period, unchanged from 0000320193-26-000006:notes:17]

[0000320193-26-000013:notes:18]
[same as prior period, unchanged from 0000320193-26-000006:notes:18]

[0000320193-26-000013:notes:19]
[same as prior period, unchanged from 0000320193-26-000006:notes:19]

[0000320193-26-000013:notes:20]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in foreign exchange rates, the Company may use forwards, cross-currency swaps or other instruments. The Company designates these instruments as either cash flow or fair value hedges. As of March 28, 2026, the maximum length of time over which the Company is hedging its exposure to the variability in future cash flows for term debt–related foreign currency transactions is 16 years.

[0000320193-26-000013:notes:21]
[same as prior period, unchanged from 0000320193-26-000006:notes:21]

[0000320193-26-000013:notes:22]
[same as prior period, unchanged from 0000320193-26-000006:notes:22]

[0000320193-26-000013:notes:23]
[same as prior period, unchanged from 0000320193-26-000006:notes:23]

[0000320193-26-000013:notes:24]
The notional amounts of the Company’s outstanding derivative instruments as of March 28, 2026 and September 27, 2025, were as follows (in millions):

[0000320193-26-000013:notes:25]
|  | March 28,2026 |  | September 27,2025 |
| Derivative instruments designated as accounting hedges: |  |  |  |
| Foreign exchange contracts | $ | 57,963 |  |  | $ | 62,647 |  |
| Interest rate contracts | $ | 10,625 |  |  | $ | 12,875 |  |
| Derivative instruments not designated as accounting hedges: |  |  |  |
| Foreign exchange contracts | $ | 96,341 |  |  | $ | 109,079 |  |

[0000320193-26-000013:notes:26]
As of March 28, 2026 and September 27, 2025, the carrying amount of the Company’s current and non-current term debt subject to fair value hedges was $10.4 billion and $12.6 billion, respectively.

[0000320193-26-000013:notes:27]
[same as prior period, unchanged from 0000320193-26-000006:notes:27]

[0000320193-26-000013:notes:28]
[same as prior period, unchanged from 0000320193-26-000006:notes:28]

[0000320193-26-000013:notes:29]
As of both March 28, 2026 and September 27, 2025, the Company had one customer that represented 10% or more of total trade receivables, which accounted for 17% and 12%, respectively. The Company’s third-party cellular network carriers accounted for 30% and 34% of total trade receivables as of March 28, 2026 and September 27, 2025, respectively. The Company requires third-party credit support or collateral from certain customers to limit credit risk.

[0000320193-26-000013:notes:30]
[same as prior period, unchanged from 0000320193-26-000006:notes:30]

[0000320193-26-000013:notes:31]
The Company has non-trade receivables from certain of its manufacturing vendors resulting from the sale of components to these vendors who manufacture subassemblies or assemble final products for the Company. The Company purchases these components directly from suppliers. The Company does not reflect the sale of these components in products net sales. Rather, the Company recognizes any gain on these sales as a reduction of products cost of sales when the related final products are sold by the Company. As of March 28, 2026, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 51% and 18%. As of September 27, 2025, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 46% and 23%.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000320193-26-000013:notes:32]
Condensed Consolidated Financial Statement Details
The following tables show the Company’s condensed consolidated financial statement details as of March 28, 2026 and September 27, 2025 (in millions):

[0000320193-26-000013:notes:33]
[same as prior period, unchanged from 0000320193-26-000006:notes:33]

[0000320193-26-000013:notes:34]
|  | March 28,2026 |  | September 27,2025 |
| Gross property, plant and equipment | $ | 127,557 |  |  | $ | 125,848 |  |
| Accumulated depreciation | (77,441) |  |  | (76,014) |  |
| Total property, plant and equipment, net | $ | 50,116 |  |  | $ | 49,834 |  |

[0000320193-26-000013:notes:35]
Intangible Assets, Net

[0000320193-26-000013:notes:36]
|  | March 28,2026 |  | September 27,2025 |
| Gross intangible assets | $ | 37,767 |  |  | $ | 24,950 |  |
| Accumulated amortization | (11,970) |  |  | (11,649) |  |
| Total intangible assets, net | 25,797 |  |  | 13,301 |  |
| Less: Current portion of intangible assets, net | (4,463) |  |  | (2,208) |  |
| Non-current portion of intangible assets, net | $ | 21,334 |  |  | $ | 11,093 |  |


## us-gaap:DebtDisclosureTextBlock

[0000320193-26-000013:notes:37]
Debt
Commercial Paper

[0000320193-26-000013:notes:38]
The Company issues unsecured short-term promissory notes pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of March 28, 2026 and September 27, 2025, the Company had $2.0 billion and $8.0 billion of commercial paper outstanding, respectively. The following table provides a summary of cash flows associated with commercial paper for the six months ended March 28, 2026 and March 29, 2025 (in millions):

[0000320193-26-000013:notes:39]
|  | Six Months Ended |
|  | March 28,2026 |  | March 29,2025 |
| Maturities 90 days or less: |  |  |  |
| Repayments of commercial paper, net | $ | (2,123) |  |  | $ | (3,968) |  |
| Maturities greater than 90 days: |  |  |  |
| Repayments of commercial paper | (3,788) |  |  | — |  |
| Total repayments of commercial paper, net | $ | (5,911) |  |  | $ | (3,968) |  |

[0000320193-26-000013:notes:40]
Term Debt

[0000320193-26-000013:notes:41]
As of March 28, 2026 and September 27, 2025, the Company had outstanding fixed-rate notes with varying maturities for an aggregate carrying amount of $82.7 billion and $90.7 billion, respectively (collectively the “Notes”). As of March 28, 2026 and September 27, 2025, the fair value of the Company’s Notes, based on Level 2 inputs, was $70.8 billion and $80.4 billion, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000320193-26-000013:notes:42]
[same as prior period, unchanged from 0000320193-26-000006:notes:40]

[0000320193-26-000013:notes:43]
During the six months ended March 28, 2026, the Company repurchased 135 million shares of its common stock for $36.0 billion. The Company’s share repurchase program does not obligate the Company to acquire a minimum amount of shares. Under the program, shares may be repurchased in privately negotiated or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended (“Exchange Act”).


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000320193-26-000013:notes:44]
[same as prior period, unchanged from 0000320193-26-000006:notes:42]

[0000320193-26-000013:notes:45]
A summary of the Company’s restricted stock unit (“RSU”) activity and related information for the six months ended March 28, 2026, is as follows:

[0000320193-26-000013:notes:46]
|  | Number ofRSUs(in thousands) |  | Weighted-AverageGrant-Date FairValue Per RSU |
| Balance as of September 27, 2025 | 151,574 |  |  | $ | 189.75 |  |
| RSUs granted | 66,083 |  |  | $ | 256.04 |  |
| RSUs vested | (37,502) |  |  | $ | 174.38 |  |
| RSUs forfeited | (6,170) |  |  | $ | 210.31 |  |
| Balance as of March 28, 2026 | 173,985 |  |  | $ | 217.51 |  |

[0000320193-26-000013:notes:47]
The total vesting-date fair value of RSUs was $917 million and $906 million for the three months ended March 28, 2026 and March 29, 2025, respectively, and was $9.5 billion and $9.3 billion for the six months ended March 28, 2026 and March 29, 2025, respectively.

[0000320193-26-000013:notes:48]
[same as prior period, unchanged from 0000320193-26-000006:notes:46]

[0000320193-26-000013:notes:49]
The following table shows share-based compensation expense and the related income tax benefit included in the Condensed Consolidated Statements of Operations for the three- and six-month periods ended March 28, 2026 and March 29, 2025 (in millions):

[0000320193-26-000013:notes:50]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28,2026 |  | March 29,2025 |  | March 28,2026 |  | March 29,2025 |
| Share-based compensation expense | $ | 3,528 |  |  | $ | 3,226 |  |  | $ | 7,122 |  |  | $ | 6,512 |  |
| Income tax benefit related to share-based compensation expense | $ | (802) |  |  | $ | (743) |  |  | $ | (2,095) |  |  | $ | (2,075) |  |

[0000320193-26-000013:notes:51]
As of March 28, 2026, the total unrecognized compensation cost related to outstanding RSUs was $28.8 billion, which the Company expects to recognize over a weighted-average period of 2.8 years.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000320193-26-000013:notes:52]
Commitments and Contingencies
Unconditional Purchase Obligations

[0000320193-26-000013:notes:53]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of supplier arrangements, distribution rights, and licensed intellectual property and content. Future payments under unconditional purchase obligations with a remaining term in excess of one year as of March 28, 2026, are as follows (in millions):

[0000320193-26-000013:notes:54]
| 2026 (remaining six months) | $ | 2,994 |  |
| 2027 | 7,343 |  |
| 2028 | 6,130 |  |
| 2029 | 5,394 |  |
| 2030 | 5,281 |  |
| Thereafter | 549 |  |
| Total | $ | 27,691 |  |

[0000320193-26-000013:notes:55]
Contingencies

[0000320193-26-000013:notes:56]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully resolved. The outcome of litigation is inherently uncertain. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss greater than a recorded accrual, concerning loss contingencies for asserted legal and other claims.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000320193-26-000013:notes:57]
Segment Information
The following tables show information by reportable segment for the three- and six-month periods ended March 28, 2026 and March 29, 2025 (in millions):

[0000320193-26-000013:notes:58]
|  | Three Months Ended March 28, 2026 |
|  | Americas |  | Europe |  | GreaterChina |  | Japan |  | Rest ofAsia Pacific |  | Corporate |  | Total |
| Net sales | $ | 45,093 |  |  | $ | 28,055 |  |  | $ | 20,497 |  |  | $ | 8,401 |  |  | $ | 9,138 |  |  | $ | — |  |  | $ | 111,184 |  |
| Cost of sales | (23,114) |  |  | (13,756) |  |  | (10,633) |  |  | (4,267) |  |  | (4,633) |  |  | — |  |  | (56,403) |  |
| Research and development | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (11,419) |  |  | (11,419) |  |
| Selling and marketing | (2,606) |  |  | (1,247) |  |  | (675) |  |  | (295) |  |  | (378) |  |  | — |  |  | (5,201) |  |
| General and administrative | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (2,276) |  |  | (2,276) |  |
| Operating income/(loss) | $ | 19,373 |  |  | $ | 13,052 |  |  | $ | 9,189 |  |  | $ | 3,839 |  |  | $ | 4,127 |  |  | $ | (13,695) |  |  | $ | 35,885 |  |
|  | Three Months Ended March 29, 2025 |
|  | Americas |  | Europe |  | GreaterChina |  | Japan |  | Rest ofAsia Pacific |  | Corporate |  | Total |
| Net sales | $ | 40,315 |  |  | $ | 24,454 |  |  | $ | 16,002 |  |  | $ | 7,298 |  |  | $ | 7,290 |  |  | $ | — |  |  | $ | 95,359 |  |
| Cost of sales | (21,094) |  |  | (13,025) |  |  | (8,794) |  |  | (3,610) |  |  | (3,969) |  |  | — |  |  | (50,492) |  |
| Research and development | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (8,550) |  |  | (8,550) |  |
| Selling and marketing | (2,447) |  |  | (1,113) |  |  | (582) |  |  | (254) |  |  | (335) |  |  | — |  |  | (4,731) |  |
| General and administrative | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (1,997) |  |  | (1,997) |  |
| Operating income/(loss) | $ | 16,774 |  |  | $ | 10,316 |  |  | $ | 6,626 |  |  | $ | 3,434 |  |  | $ | 2,986 |  |  | $ | (10,547) |  |  | $ | 29,589 |  |

[0000320193-26-000013:notes:59]
|  | Six Months Ended March 28, 2026 |
|  | Americas |  | Europe |  | GreaterChina |  | Japan |  | Rest ofAsia Pacific |  | Corporate |  | Total |
| Net sales | $ | 103,622 |  |  | $ | 66,201 |  |  | $ | 46,023 |  |  | $ | 17,814 |  |  | $ | 21,280 |  |  | $ | — |  |  | $ | 254,940 |  |
| Cost of sales | (54,963) |  |  | (32,817) |  |  | (23,663) |  |  | (8,778) |  |  | (10,707) |  |  | — |  |  | (130,928) |  |
| Research and development | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (22,306) |  |  | (22,306) |  |
| Selling and marketing | (5,333) |  |  | (2,542) |  |  | (1,379) |  |  | (584) |  |  | (760) |  |  | — |  |  | (10,598) |  |
| General and administrative | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (4,371) |  |  | (4,371) |  |
| Operating income/(loss) | $ | 43,326 |  |  | $ | 30,842 |  |  | $ | 20,981 |  |  | $ | 8,452 |  |  | $ | 9,813 |  |  | $ | (26,677) |  |  | $ | 86,737 |  |
|  | Six Months Ended March 29, 2025 |
|  | Americas |  | Europe |  | GreaterChina |  | Japan |  | Rest ofAsia Pacific |  | Corporate |  | Total |
| Net sales | $ | 92,963 |  |  | $ | 58,315 |  |  | $ | 34,515 |  |  | $ | 16,285 |  |  | $ | 17,581 |  |  | $ | — |  |  | $ | 219,659 |  |
| Cost of sales | (49,589) |  |  | (31,068) |  |  | (18,553) |  |  | (8,003) |  |  | (9,304) |  |  | — |  |  | (116,517) |  |
| Research and development | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (16,818) |  |  | (16,818) |  |
| Selling and marketing | (5,091) |  |  | (2,324) |  |  | (1,176) |  |  | (534) |  |  | (707) |  |  | — |  |  | (9,832) |  |
| General and administrative | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (4,071) |  |  | (4,071) |  |
| Operating income/(loss) | $ | 38,283 |  |  | $ | 24,923 |  |  | $ | 14,786 |  |  | $ | 7,748 |  |  | $ | 7,570 |  |  | $ | (20,889) |  |  | $ | 72,421 |  |
