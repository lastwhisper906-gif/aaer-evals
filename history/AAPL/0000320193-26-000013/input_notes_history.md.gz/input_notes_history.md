# AAPL note change history — 0000320193-26-000006 → 0000320193-26-000013


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2026-05-01):
[0000320193-26-000013:note_history:1]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of supplier arrangements, distribution rights, and licensed intellectual property and content. Future payments under unconditional purchase obligations with a remaining term in excess of one year as of March 28, 2026, are as follows (in millions):
  (was, 2026-01-30, similarity 0.8565):
[0000320193-26-000006:note_history:1]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of supplier arrangements, licensed intellectual property and content, and distribution rights. Future payments under unconditional purchase obligations with a remaining term in excess of one year as of December 27, 2025, are as follows (in millions):

- changed (2026-05-01):
[0000320193-26-000013:note_history:2]
| 2026 (remaining six months) | $ | 2,994 |  |
| 2027 | 7,343 |  |
| 2028 | 6,130 |  |
| 2029 | 5,394 |  |
| 2030 | 5,281 |  |
| Thereafter | 549 |  |
| Total | $ | 27,691 |  |
  (was, 2026-01-30, similarity 0.9804):
[0000320193-26-000006:note_history:2]
| 2026 (remaining nine months) | $ | 4,754 |  |
| 2027 | 8,066 |  |
| 2028 | 7,005 |  |
| 2029 | 6,538 |  |
| 2030 | 5,992 |  |
| Thereafter | 827 |  |
| Total | $ | 33,182 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2026-05-01):
[0000320193-26-000013:note_history:3]
The condensed consolidated financial statements include the accounts of Apple Inc. and its wholly owned subsidiaries (collectively “Apple” or the “Company”). In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements and accompanying notes in conformity with U.S. generally accepted accounting principles (“GAAP”) requires the use of management estimates. Certain prior period amounts in the condensed consolidated financial statements and accompanying notes have been reclassified to conform to the current period’s presentation. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company’s annual consolidated financial statements and accompanying notes included in its Annual Report on Form 10-K for the fiscal year ended September 27, 2025 (the “2025 Form 10-K”).
  (was, 2026-01-30, similarity 0.9081):
[0000320193-26-000006:note_history:3]
The condensed consolidated financial statements include the accounts of Apple Inc. and its wholly owned subsidiaries (collectively “Apple” or the “Company”). In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements and accompanying notes in conformity with U.S. generally accepted accounting principles (“GAAP”) requires the use of management estimates. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company’s annual consolidated financial statements and accompanying notes included in its Annual Report on Form 10-K for the fiscal year ended September 27, 2025 (the “2025 Form 10-K”).


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-05-01):
[0000320193-26-000013:note_history:4]
The Company issues unsecured short-term promissory notes pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of March 28, 2026 and September 27, 2025, the Company had $2.0 billion and $8.0 billion of commercial paper outstanding, respectively. The following table provides a summary of cash flows associated with commercial paper for the six months ended March 28, 2026 and March 29, 2025 (in millions):
  (was, 2026-01-30, similarity 0.9094):
[0000320193-26-000006:note_history:4]
The Company issues unsecured short-term promissory notes pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of December 27, 2025 and September 27, 2025, the Company had $2.0 billion and $8.0 billion of commercial paper outstanding, respectively. The following table provides a summary of cash flows associated with commercial paper for the three months ended December 27, 2025 and December 28, 2024 (in millions):

- added (2026-05-01):
[0000320193-26-000013:note_history:5]
|  | Six Months Ended |
|  | March 28,2026 |  | March 29,2025 |
| Maturities 90 days or less: |  |  |  |
| Repayments of commercial paper, net | $ | (2,123) |  |  | $ | (3,968) |  |
| Maturities greater than 90 days: |  |  |  |
| Repayments of commercial paper | (3,788) |  |  | — |  |
| Total repayments of commercial paper, net | $ | (5,911) |  |  | $ | (3,968) |  |

- changed (2026-05-01):
[0000320193-26-000013:note_history:6]
As of March 28, 2026 and September 27, 2025, the Company had outstanding fixed-rate notes with varying maturities for an aggregate carrying amount of $82.7 billion and $90.7 billion, respectively (collectively the “Notes”). As of March 28, 2026 and September 27, 2025, the fair value of the Company’s Notes, based on Level 2 inputs, was $70.8 billion and $80.4 billion, respectively.
  (was, 2026-01-30, similarity 0.9631):
[0000320193-26-000006:note_history:6]
As of December 27, 2025 and September 27, 2025, the Company had outstanding fixed-rate notes with varying maturities for an aggregate carrying amount of $88.5 billion and $90.7 billion, respectively (collectively the “Notes”). As of December 27, 2025 and September 27, 2025, the fair value of the Company’s Notes, based on Level 2 inputs, was $78.1 billion and $80.4 billion, respectively.

- removed (2026-05-01):
[0000320193-26-000006:note_history:7]
|  | Three Months Ended |
|  | December 27,2025 |  | December 28,2024 |
| Maturities 90 days or less: |  |  |  |
| Repayments of commercial paper, net | $ | (2,122) |  |  | $ | (7,944) |  |
| Maturities greater than 90 days: |  |  |  |
| Repayments of commercial paper | (3,788) |  |  | — |  |
| Total repayments of commercial paper, net | $ | (5,910) |  |  | $ | (7,944) |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-05-01):
[0000320193-26-000013:note_history:8]
Revenue
The following table shows disaggregated net sales, as well as the portion of total net sales that was previously deferred, for the three- and six-month periods ended March 28, 2026 and March 29, 2025 (in millions):
  (was, 2026-01-30, similarity 0.7971):
[0000320193-26-000006:note_history:8]
Revenue
The following table shows disaggregated net sales, as well as the portion of total net sales that was previously deferred, for the three months ended December 27, 2025 and December 28, 2024 (in millions):

- added (2026-05-01):
[0000320193-26-000013:note_history:9]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28,2026 |  | March 29,2025 |  | March 28,2026 |  | March 29,2025 |
| iPhone® | $ | 56,994 |  |  | $ | 46,841 |  |  | $ | 142,263 |  |  | $ | 115,979 |  |
| Mac® | 8,399 |  |  | 7,949 |  |  | 16,785 |  |  | 16,936 |  |
| iPad® | 6,914 |  |  | 6,402 |  |  | 15,509 |  |  | 14,490 |  |
| Wearables, Home and Accessories | 7,901 |  |  | 7,522 |  |  | 19,394 |  |  | 19,269 |  |
| Services | 30,976 |  |  | 26,645 |  |  | 60,989 |  |  | 52,985 |  |
| Total net sales | $ | 111,184 |  |  | $ | 95,359 |  |  | $ | 254,940 |  |  | $ | 219,659 |  |
| Portion of total net sales that was included in deferred revenue as of the beginning of the period | $ | 3,987 |  |  | $ | 3,672 |  |  | $ | 5,834 |  |  | $ | 5,440 |  |

- changed (2026-05-01):
[0000320193-26-000013:note_history:10]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 10, “Segment Information” for the three- and six-month periods ended March 28, 2026 and March 29, 2025, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.
  (was, 2026-01-30, similarity 0.8433):
[0000320193-26-000006:note_history:10]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 10, “Segment Information” for the three months ended December 27, 2025 and December 28, 2024, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.

- changed (2026-05-01):
[0000320193-26-000013:note_history:11]
As of March 28, 2026 and September 27, 2025, the Company had total deferred revenue of $14.7 billion and $13.7 billion, respectively. As of March 28, 2026, the Company expects 64% of total deferred revenue to be realized in less than a year, 23% within one-to-two years, 11% within two-to-three years and 2% in greater than three years.
  (was, 2026-01-30, similarity 0.9585):
[0000320193-26-000006:note_history:11]
As of December 27, 2025 and September 27, 2025, the Company had total deferred revenue of $14.3 billion and $13.7 billion, respectively. As of December 27, 2025, the Company expects 66% of total deferred revenue to be realized in less than a year, 23% within one-to-two years, 9% within two-to-three years and 2% in greater than three years.

- removed (2026-05-01):
[0000320193-26-000006:note_history:12]
|  | Three Months Ended |  |  |
|  | December 27,2025 |  | December 28,2024 |  |  |  |  |
| iPhone® | $ | 85,269 |  |  | $ | 69,138 |  |  |  |  |  |
| Mac® | 8,386 |  |  | 8,987 |  |  |  |  |  |
| iPad® | 8,595 |  |  | 8,088 |  |  |  |  |  |
| Wearables, Home and Accessories | 11,493 |  |  | 11,747 |  |  |  |  |  |
| Services | 30,013 |  |  | 26,340 |  |  |  |  |  |
| Total net sales | $ | 143,756 |  |  | $ | 124,300 |  |  |  |  |  |
| Portion of total net sales that was included in deferred revenue as of the beginning of the period | $ | 4,050 |  |  | $ | 3,690 |  |  |  |  |  |
