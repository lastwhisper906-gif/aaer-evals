# AAPL MD&A — 0000320193-26-000013


## mdna

[0000320193-26-000013:mdna:1]
[same as prior period, unchanged from 0000320193-26-000006:mdna:1]

[0000320193-26-000013:mdna:2]
[same as prior period, unchanged from 0000320193-26-000006:mdna:2]

[0000320193-26-000013:mdna:3]
[same as prior period, unchanged from 0000320193-26-000006:mdna:3]

[0000320193-26-000013:mdna:4]
[same as prior period, unchanged from 0000320193-26-000006:mdna:4]

[0000320193-26-000013:mdna:5]
[same as prior period, unchanged from 0000320193-26-000006:mdna:5]

[0000320193-26-000013:mdna:6]
[same as prior period, unchanged from 0000320193-26-000006:mdna:6]

[0000320193-26-000013:mdna:7]
[same as prior period, unchanged from 0000320193-26-000006:mdna:7]

[0000320193-26-000013:mdna:8]
During the second quarter of 2026, the Company announced the following new or updated products:

[0000320193-26-000013:mdna:9]
•iPad Air®

[0000320193-26-000013:mdna:10]
•iPhone 17e

[0000320193-26-000013:mdna:11]
•MacBook Pro®

[0000320193-26-000013:mdna:12]
•MacBook Air®

[0000320193-26-000013:mdna:13]
•MacBook Neo™

[0000320193-26-000013:mdna:14]
•AirPods Max® 2

[0000320193-26-000013:mdna:15]
[same as prior period, unchanged from 0000320193-26-000006:mdna:12]

[0000320193-26-000013:mdna:16]
[same as prior period, unchanged from 0000320193-26-000006:mdna:13]

[0000320193-26-000013:mdna:17]
The Company is experiencing a period of supply constraints and increasing costs for components driven by factors such as industry supply-demand imbalances for components, including advanced semiconductors, storage (NAND) and memory (DRAM). The Company expects these trends to intensify, which, together with actions that may be taken by the Company in response to such trends, may materially adversely affect demand for the Company’s products and negatively impact the Company’s revenue, costs, gross margin, results of operations and financial condition.

[0000320193-26-000013:mdna:18]
[same as prior period, unchanged from 0000320193-26-000006:mdna:14]

[0000320193-26-000013:mdna:19]
Beginning in the second quarter of 2025, new tariffs were announced on imports to the U.S., including additional tariffs on imports from China, India, Japan, South Korea, Taiwan, Vietnam and the European Union (“EU”), among others. In response, several countries have imposed, or threatened to impose, reciprocal tariffs on imports from the U.S. and other retaliatory measures. On January 14, 2026, initial results were published of the previously announced U.S. Department of Commerce investigation under Section 232 of the Trade Expansion Act of 1962, as amended, into imports of semiconductors, semiconductor manufacturing equipment, and their derivative products, including downstream products that contain semiconductors. The announcement of the initial results of the investigation did not impose any additional tariffs affecting the Company’s products. Separately, on February 20, 2026, the U.S. Supreme Court issued a ruling striking down certain tariffs previously imposed under the International Emergency Economic Powers Act of 1977. The Company is applying for a refund of tariffs paid, following the processes established by U.S. Customs and Border Protection. Various modifications to U.S. tariffs have been announced, including the imposition of tariffs under Section 122 of the Trade Act of 1974, and further changes could be made in the future, which may include additional measures under the Section 232 semiconductor sector investigation, additional sector-based tariffs, actions under Section 301 of the Trade Act of 1974, or other measures. Tariffs and other measures that are applied to the Company’s products or their components can have a material adverse impact on the Company’s business, results of operations and financial condition, including impacting the Company’s supply chain, the availability of rare earths and other raw materials and components, pricing and gross margin. The ultimate impact remains uncertain and will depend on several factors, including whether additional or incremental U.S. tariffs or other measures are announced or imposed, to what extent other countries implement tariffs or other retaliatory measures in response, and the overall magnitude and duration of these measures. Trade and other international disputes can have an adverse impact on the overall macroeconomic environment and result in shifts and reductions in consumer spending and negative consumer sentiment for the Company’s products and services, all of which can further adversely affect the Company’s business and results of operations.

[0000320193-26-000013:mdna:20]
[same as prior period, unchanged from 0000320193-26-000006:mdna:16]

[0000320193-26-000013:mdna:21]
The following table shows net sales by reportable segment for the three- and six-month periods ended March 28, 2026 and March 29, 2025 (dollars in millions):

[0000320193-26-000013:mdna:22]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28,2026 |  | March 29,2025 |  | Change |  | March 28,2026 |  | March 29,2025 |  | Change |
| Americas | $ | 45,093 |  |  | $ | 40,315 |  |  | 12 | % |  | $ | 103,622 |  |  | $ | 92,963 |  |  | 11 | % |
| Europe | 28,055 |  |  | 24,454 |  |  | 15 | % |  | 66,201 |  |  | 58,315 |  |  | 14 | % |
| Greater China | 20,497 |  |  | 16,002 |  |  | 28 | % |  | 46,023 |  |  | 34,515 |  |  | 33 | % |
| Japan | 8,401 |  |  | 7,298 |  |  | 15 | % |  | 17,814 |  |  | 16,285 |  |  | 9 | % |
| Rest of Asia Pacific | 9,138 |  |  | 7,290 |  |  | 25 | % |  | 21,280 |  |  | 17,581 |  |  | 21 | % |
| Total net sales | $ | 111,184 |  |  | $ | 95,359 |  |  | 17 | % |  | $ | 254,940 |  |  | $ | 219,659 |  |  | 16 | % |

[0000320193-26-000013:mdna:23]
[same as prior period, unchanged from 0000320193-26-000006:mdna:19]

[0000320193-26-000013:mdna:24]
Americas net sales increased during the second quarter and first six months of 2026 compared to the same periods in 2025 due to higher net sales of iPhone and Services. The strength in foreign currencies relative to the U.S. dollar had a favorable year-over-year impact on Americas net sales during the second quarter of 2026.

[0000320193-26-000013:mdna:25]
[same as prior period, unchanged from 0000320193-26-000006:mdna:21]

[0000320193-26-000013:mdna:26]
Europe net sales increased during the second quarter and first six months of 2026 compared to the same periods in 2025 primarily due to higher net sales of iPhone and Services. The strength in foreign currencies relative to the U.S. dollar had a net favorable year-over-year impact on Europe net sales during the second quarter and first six months of 2026.

[0000320193-26-000013:mdna:27]
[same as prior period, unchanged from 0000320193-26-000006:mdna:23]

[0000320193-26-000013:mdna:28]
Greater China net sales increased during the second quarter and first six months of 2026 compared to the same periods in 2025 due to higher net sales of iPhone. The strength in the renminbi relative to the U.S. dollar had a favorable year-over-year impact on Greater China net sales during the second quarter of 2026.

[0000320193-26-000013:mdna:29]
[same as prior period, unchanged from 0000320193-26-000006:mdna:25]

[0000320193-26-000013:mdna:30]
Japan net sales increased during the second quarter and first six months of 2026 compared to the same periods in 2025 primarily due to higher net sales of iPhone. The weakness in the yen relative to the U.S. dollar had an unfavorable year-over-year impact on Japan net sales during the first six months of 2026.

[0000320193-26-000013:mdna:31]
[same as prior period, unchanged from 0000320193-26-000006:mdna:27]

[0000320193-26-000013:mdna:32]
Rest of Asia Pacific net sales increased during the second quarter and first six months of 2026 compared to the same periods in 2025 primarily due to higher net sales of iPhone and Services. The strength in foreign currencies relative to the U.S. dollar had a net favorable year-over-year impact on Rest of Asia Pacific net sales during the second quarter of 2026.

[0000320193-26-000013:mdna:33]
[same as prior period, unchanged from 0000320193-26-000006:mdna:29]

[0000320193-26-000013:mdna:34]
The following table shows net sales by category for the three- and six-month periods ended March 28, 2026 and March 29, 2025 (dollars in millions):

[0000320193-26-000013:mdna:35]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28,2026 |  | March 29,2025 |  | Change |  | March 28,2026 |  | March 29,2025 |  | Change |
| iPhone | $ | 56,994 |  |  | $ | 46,841 |  |  | 22 | % |  | $ | 142,263 |  |  | $ | 115,979 |  |  | 23 | % |
| Mac | 8,399 |  |  | 7,949 |  |  | 6 | % |  | 16,785 |  |  | 16,936 |  |  | (1) | % |
| iPad | 6,914 |  |  | 6,402 |  |  | 8 | % |  | 15,509 |  |  | 14,490 |  |  | 7 | % |
| Wearables, Home and Accessories | 7,901 |  |  | 7,522 |  |  | 5 | % |  | 19,394 |  |  | 19,269 |  |  | 1 | % |
| Services | 30,976 |  |  | 26,645 |  |  | 16 | % |  | 60,989 |  |  | 52,985 |  |  | 15 | % |
| Total net sales | $ | 111,184 |  |  | $ | 95,359 |  |  | 17 | % |  | $ | 254,940 |  |  | $ | 219,659 |  |  | 16 | % |

[0000320193-26-000013:mdna:36]
[same as prior period, unchanged from 0000320193-26-000006:mdna:32]

[0000320193-26-000013:mdna:37]
iPhone net sales increased during the second quarter and first six months of 2026 compared to the same periods in 2025 due to higher net sales of Pro models.

[0000320193-26-000013:mdna:38]
[same as prior period, unchanged from 0000320193-26-000006:mdna:34]

[0000320193-26-000013:mdna:39]
Mac net sales increased during the second quarter of 2026 compared to the second quarter of 2025 due to higher net sales of laptops. Year-over-year Mac net sales during the first six months of 2026 were relatively flat.

[0000320193-26-000013:mdna:40]
[same as prior period, unchanged from 0000320193-26-000006:mdna:36]

[0000320193-26-000013:mdna:41]
iPad net sales increased during the second quarter and first six months of 2026 compared to the same periods in 2025 primarily due to higher net sales of iPad, partially offset by lower net sales of iPad mini®.

[0000320193-26-000013:mdna:42]
[same as prior period, unchanged from 0000320193-26-000006:mdna:38]

[0000320193-26-000013:mdna:43]
Wearables, Home and Accessories net sales increased during the second quarter of 2026 compared to the second quarter of 2025 primarily due to higher net sales of Accessories and Wearables. Year-over-year Wearables, Home and Accessories net sales during the first six months of 2026 were relatively flat.

[0000320193-26-000013:mdna:44]
[same as prior period, unchanged from 0000320193-26-000006:mdna:40]

[0000320193-26-000013:mdna:45]
Services net sales increased during the second quarter and first six months of 2026 compared to the same periods in 2025 primarily due to higher net sales from advertising, the App Store® and cloud services.

[0000320193-26-000013:mdna:46]
[same as prior period, unchanged from 0000320193-26-000006:mdna:42]

[0000320193-26-000013:mdna:47]
Products and Services gross margin and gross margin percentage for the three- and six-month periods ended March 28, 2026 and March 29, 2025, were as follows (dollars in millions):

[0000320193-26-000013:mdna:48]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28,2026 |  | March 29,2025 |  | March 28,2026 |  | March 29,2025 |
| Gross margin: |  |  |  |  |  |  |  |
| Products | $ | 31,029 |  |  | $ | 24,684 |  |  | $ | 77,294 |  |  | $ | 63,197 |  |
| Services | 23,752 |  |  | 20,183 |  |  | 46,718 |  |  | 39,945 |  |
| Total gross margin | $ | 54,781 |  |  | $ | 44,867 |  |  | $ | 124,012 |  |  | $ | 103,142 |  |

[0000320193-26-000013:mdna:49]
| Gross margin percentage: |  |  |  |  |  |  |  |
| Products | 38.7 | % |  | 35.9 | % |  | 39.9 | % |  | 37.9 | % |
| Services | 76.7 | % |  | 75.7 | % |  | 76.6 | % |  | 75.4 | % |
| Total gross margin percentage | 49.3 | % |  | 47.1 | % |  | 48.6 | % |  | 47.0 | % |

[0000320193-26-000013:mdna:50]
[same as prior period, unchanged from 0000320193-26-000006:mdna:46]

[0000320193-26-000013:mdna:51]
Products gross margin and gross margin percentage increased during the second quarter and first six months of 2026 compared to the same periods in 2025 primarily due to a different mix of products and strength in foreign currencies relative to the U.S. dollar, partially offset by higher costs.

[0000320193-26-000013:mdna:52]
[same as prior period, unchanged from 0000320193-26-000006:mdna:48]

[0000320193-26-000013:mdna:53]
Services gross margin increased during the second quarter and first six months of 2026 compared to the same periods in 2025 primarily due to higher Services net sales and a different mix of services.

[0000320193-26-000013:mdna:54]
Services gross margin percentage increased during the second quarter and first six months of 2026 compared to the same periods in 2025 primarily due to a different mix of services and strength in foreign currencies relative to the U.S. dollar, partially offset by higher costs.

[0000320193-26-000013:mdna:55]
[same as prior period, unchanged from 0000320193-26-000006:mdna:51]

[0000320193-26-000013:mdna:56]
[same as prior period, unchanged from 0000320193-26-000006:mdna:52]

[0000320193-26-000013:mdna:57]
Operating expenses for the three- and six-month periods ended March 28, 2026 and March 29, 2025, were as follows (dollars in millions):

[0000320193-26-000013:mdna:58]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28,2026 |  | March 29,2025 |  | Change |  | March 28,2026 |  | March 29,2025 |  | Change |
| Research and development | $ | 11,419 |  |  | $ | 8,550 |  |  | 34 | % |  | $ | 22,306 |  |  | $ | 16,818 |  |  | 33 | % |
| Percentage of total net sales | 10 | % |  | 9 | % |  |  |  | 9 | % |  | 8 | % |  |  |
| Selling, general and administrative | $ | 7,477 |  |  | $ | 6,728 |  |  | 11 | % |  | $ | 14,969 |  |  | $ | 13,903 |  |  | 8 | % |
| Percentage of total net sales | 7 | % |  | 7 | % |  |  |  | 6 | % |  | 6 | % |  |  |
| Total operating expenses | $ | 18,896 |  |  | $ | 15,278 |  |  | 24 | % |  | $ | 37,275 |  |  | $ | 30,721 |  |  | 21 | % |
| Percentage of total net sales | 17 | % |  | 16 | % |  |  |  | 15 | % |  | 14 | % |  |  |

[0000320193-26-000013:mdna:59]
[same as prior period, unchanged from 0000320193-26-000006:mdna:55]

[0000320193-26-000013:mdna:60]
Research and development (“R&D”) expense increased during the second quarter and first six months of 2026 compared to the same periods in 2025 primarily due to higher infrastructure-related costs and headcount-related expenses.

[0000320193-26-000013:mdna:61]
[same as prior period, unchanged from 0000320193-26-000006:mdna:57]

[0000320193-26-000013:mdna:62]
Selling, general and administrative expense increased during the second quarter and first six months of 2026 compared to the same periods in 2025 primarily due to higher headcount-related expenses, variable selling expenses and professional services.

[0000320193-26-000013:mdna:63]
[same as prior period, unchanged from 0000320193-26-000006:mdna:59]

[0000320193-26-000013:mdna:64]
Provision for income taxes, effective tax rate and statutory federal income tax rate for the three- and six-month periods ended March 28, 2026 and March 29, 2025, were as follows (dollars in millions):

[0000320193-26-000013:mdna:65]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28,2026 |  | March 29,2025 |  | March 28,2026 |  | March 29,2025 |
| Provision for income taxes | $ | 6,255 |  |  | $ | 4,530 |  |  | $ | 15,160 |  |  | $ | 10,784 |  |
| Effective tax rate | 17.5 | % |  | 15.5 | % |  | 17.5 | % |  | 15.0 | % |
| Statutory federal income tax rate | 21 | % |  | 21 | % |  | 21 | % |  | 21 | % |

[0000320193-26-000013:mdna:66]
The Company’s effective tax rate for the second quarter of 2026 was lower than the statutory federal income tax rate primarily due to a lower effective tax rate on foreign earnings, the impact of the U.S. federal R&D credit, and a change in valuation allowance, partially offset by state income taxes. The Company’s effective tax rate for the first six months of 2026 was lower than the statutory federal income tax rate primarily due to a lower effective tax rate on foreign earnings, the impact of the U.S. federal R&D credit, and tax benefits from share-based compensation, partially offset by state income taxes.

[0000320193-26-000013:mdna:67]
The Company’s effective tax rate for the second quarter of 2026 was higher compared to the second quarter of 2025 primarily due to the impact of changes in unrecognized tax benefits, partially offset by a change in valuation allowance. The Company’s effective tax rate for the first six months of 2026 was higher compared to the same period in 2025 primarily due to the impact of changes in unrecognized tax benefits, the impact of foreign currency loss regulations issued by the U.S. Department of the Treasury in December 2024, and the tax impact from foreign currency revaluations in the first quarter of 2025 related to the State Aid Decision.

[0000320193-26-000013:mdna:68]
[same as prior period, unchanged from 0000320193-26-000006:mdna:64]

[0000320193-26-000013:mdna:69]
[same as prior period, unchanged from 0000320193-26-000006:mdna:65]

[0000320193-26-000013:mdna:70]
The Company’s contractual cash requirements have not changed materially since the 2025 Form 10-K, except for manufacturing purchase obligations, other purchase obligations, and deemed repatriation tax payable.

[0000320193-26-000013:mdna:71]
[same as prior period, unchanged from 0000320193-26-000006:mdna:67]

[0000320193-26-000013:mdna:72]
The Company utilizes several outsourcing partners to manufacture subassemblies for the Company’s products and to perform final assembly and testing of finished products. The Company also obtains individual components for its products from a wide variety of individual suppliers. As of March 28, 2026, the Company had manufacturing purchase obligations of $44.6 billion, with $43.9 billion payable within 12 months.

[0000320193-26-000013:mdna:73]
[same as prior period, unchanged from 0000320193-26-000006:mdna:69]

[0000320193-26-000013:mdna:74]
The Company’s other purchase obligations primarily consist of noncancelable obligations related to supplier arrangements, licensed intellectual property and content, distribution rights, and the acquisition of capital assets related to product manufacturing. As of March 28, 2026, the Company had other purchase obligations of $30.4 billion, with $9.3 billion payable within 12 months.

[0000320193-26-000013:mdna:75]
Deemed Repatriation Tax Payable

[0000320193-26-000013:mdna:76]
During the first six months of 2026, the Company paid the remaining $8.8 billion balance of the deemed repatriation tax payable imposed by the U.S. Tax Cuts and Jobs Act of 2017.

[0000320193-26-000013:mdna:77]
[same as prior period, unchanged from 0000320193-26-000006:mdna:71]

[0000320193-26-000013:mdna:78]
In addition to its contractual cash requirements, the Company has an authorized share repurchase program, under which the remaining availability was $63.8 billion as of March 28, 2026. On April 30, 2026, the Company announced the Board of Directors had authorized an additional program to repurchase up to $100 billion of the Company’s common stock. The programs do not obligate the Company to acquire a minimum amount of shares.

[0000320193-26-000013:mdna:79]
On April 30, 2026, the Company also announced the Board of Directors raised the Company’s quarterly cash dividend from $0.26 to $0.27 per share, beginning with the dividend to be paid during the third quarter of 2026. The Company intends to increase its dividend on an annual basis, subject to declaration by the Board of Directors.

[0000320193-26-000013:mdna:80]
During the second quarter of 2026, the Company repurchased $11.0 billion of its common stock and paid dividends and dividend equivalents of $3.8 billion.

[0000320193-26-000013:mdna:81]
[same as prior period, unchanged from 0000320193-26-000006:mdna:74]

[0000320193-26-000013:mdna:82]
[same as prior period, unchanged from 0000320193-26-000006:mdna:75]

[0000320193-26-000013:mdna:83]
In September 2025, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2025-06, Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software (“ASU 2025-06”), which modernizes the accounting for internal-use software. ASU 2025-06 removes all references to software development stages and requires capitalization of software costs when management has committed to the software project and it is probable the software will be completed and perform its intended use. ASU 2025-06 will be effective for the Company in its first quarter of 2029, and early adoption is permitted. The Company is currently evaluating the timing and method of its adoption of ASU 2025-06.

[0000320193-26-000013:mdna:84]
[same as prior period, unchanged from 0000320193-26-000006:mdna:77]

[0000320193-26-000013:mdna:85]
In November 2024, the FASB issued ASU No. 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses (“ASU 2024-03”) and in January 2025, the FASB issued ASU No. 2025-01, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date, which clarified the effective date of ASU 2024-03. ASU 2024-03 will require the Company to disclose the amounts of purchases of inventory, employee compensation, depreciation and intangible asset amortization, as applicable, included in certain expense captions in the Consolidated Statements of Operations, as well as qualitatively describe remaining amounts included in those captions. ASU 2024-03 will also require the Company to disclose both the amount and the Company’s definition of selling expenses. The Company will adopt ASU 2024-03 in its fourth quarter of 2028 using a prospective transition method.

[0000320193-26-000013:mdna:86]
[same as prior period, unchanged from 0000320193-26-000006:mdna:79]

[0000320193-26-000013:mdna:87]
In December 2023, the FASB issued ASU No. 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures (“ASU 2023-09”), which will require the Company to disclose specified additional information in its income tax rate reconciliation and provide additional information for reconciling items that meet a quantitative threshold. ASU 2023-09 will also require the Company to disaggregate its income taxes paid disclosure by federal, state and foreign taxes, with further disaggregation required for significant individual jurisdictions. The Company will adopt ASU 2023-09 in its fourth quarter of 2026 using a prospective transition method.

[0000320193-26-000013:mdna:88]
[same as prior period, unchanged from 0000320193-26-000006:mdna:81]

[0000320193-26-000013:mdna:89]
[same as prior period, unchanged from 0000320193-26-000006:mdna:82]
