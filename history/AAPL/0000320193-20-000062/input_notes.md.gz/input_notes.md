# AAPL notes — 0000320193-20-000062


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000320193-20-000062:notes:1]
[same as prior period, unchanged from 0000320193-20-000052:notes:1]

[0000320193-20-000062:notes:2]
The condensed consolidated financial statements include the accounts of Apple Inc. and its wholly owned subsidiaries (collectively “Apple” or the “Company”). Intercompany accounts and transactions have been eliminated. In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements and accompanying notes in conformity with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported. Actual results could differ materially from those estimates. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company’s annual consolidated financial statements and accompanying notes included in its Annual Report on Form 10-K for the fiscal year ended September 28, 2019 (the “2019 Form 10-K”).

[0000320193-20-000062:notes:3]
[same as prior period, unchanged from 0000320193-20-000052:notes:3]

[0000320193-20-000062:notes:4]
Recently Adopted Accounting Pronouncements

[0000320193-20-000062:notes:5]
[same as prior period, unchanged from 0000320193-20-000052:notes:5]

[0000320193-20-000062:notes:6]
At the beginning of the first quarter of 2020, the Company adopted the Financial Accounting Standards Board’s (the “FASB”) Accounting Standards Update (“ASU”) No. 2016-02, Leases (Topic 842) (“ASU 2016-02”), and additional ASUs issued to clarify and update the guidance in ASU 2016-02 (collectively, the “new leases standard”), which modifies lease accounting for lessees to increase transparency and comparability by recording lease assets and liabilities for operating leases and disclosing key information about leasing arrangements. The Company adopted the new leases standard utilizing the modified retrospective transition method, under which amounts in prior periods presented were not restated. For contracts existing at the time of adoption, the Company elected to not reassess (i) whether any are or contain leases, (ii) lease classification, and (iii) initial direct costs. Upon adoption, the Company recorded $7.5 billion of right-of-use (“ROU”) assets and $8.1 billion of lease liabilities on its Condensed Consolidated Balance Sheet.

[0000320193-20-000062:notes:7]
[same as prior period, unchanged from 0000320193-20-000052:notes:7]

[0000320193-20-000062:notes:8]
At the beginning of the first quarter of 2020, the Company adopted FASB ASU No. 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities (“ASU 2017-12”). ASU 2017-12 expands component and fair value hedging, specifies the presentation of the effects of hedging instruments, eliminates the separate measurement and presentation of hedge ineffectiveness, and updates disclosure requirements related to hedging. The Company adopted ASU 2017-12 utilizing the modified retrospective transition method. Upon adoption, the Company recorded a $136 million increase in accumulated other comprehensive income/(loss) (“AOCI”) and a corresponding decrease in retained earnings in the Condensed Consolidated Statement of Shareholders’ Equity.

[0000320193-20-000062:notes:9]
[same as prior period, unchanged from 0000320193-20-000052:notes:9]

[0000320193-20-000062:notes:10]
The following table shows the computation of basic and diluted earnings per share for the three- and nine-month periods ended June 27, 2020 and June 29, 2019 (net income in millions and shares in thousands):

[0000320193-20-000062:notes:11]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | June 27,2020 |  | June 29,2019 |  | June 27,2020 |  | June 29,2019 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 11,253 |  |  | $ | 10,044 |  |  | $ | 44,738 |  |  | $ | 41,570 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 4,312,573 |  |  | 4,570,633 |  |  | 4,362,571 |  |  | 4,660,175 |  |
| Effect of dilutive securities | 42,215 |  |  | 30,747 |  |  | 42,124 |  |  | 31,584 |  |
| Weighted-average diluted shares | 4,354,788 |  |  | 4,601,380 |  |  | 4,404,695 |  |  | 4,691,759 |  |
| Basic earnings per share | $ | 2.61 |  |  | $ | 2.20 |  |  | $ | 10.25 |  |  | $ | 8.92 |  |
| Diluted earnings per share | $ | 2.58 |  |  | $ | 2.18 |  |  | $ | 10.16 |  |  | $ | 8.86 |  |

[0000320193-20-000062:notes:12]
Potentially dilutive securities representing 1.5 million and 20.5 million shares of common stock were excluded from the computation of diluted earnings per share for the three- and nine-month periods ended June 29, 2019, respectively, because their effect would have been antidilutive.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000320193-20-000062:notes:13]
[same as prior period, unchanged from 0000320193-20-000052:notes:13]

[0000320193-20-000062:notes:14]
[same as prior period, unchanged from 0000320193-20-000052:notes:14]

[0000320193-20-000062:notes:15]
[same as prior period, unchanged from 0000320193-20-000052:notes:15]

[0000320193-20-000062:notes:16]
[same as prior period, unchanged from 0000320193-20-000052:notes:16]

[0000320193-20-000062:notes:17]
[same as prior period, unchanged from 0000320193-20-000052:notes:17]

[0000320193-20-000062:notes:18]
[same as prior period, unchanged from 0000320193-20-000052:notes:18]

[0000320193-20-000062:notes:19]
[same as prior period, unchanged from 0000320193-20-000052:notes:19]

[0000320193-20-000062:notes:20]
[same as prior period, unchanged from 0000320193-20-000052:notes:20]

[0000320193-20-000062:notes:21]
As of June 27, 2020 and September 28, 2019, the Company had total deferred revenue of $9.8 billion and $8.1 billion, respectively. As of June 27, 2020, the Company expects 65% of total deferred revenue to be realized in less than a year, 26% within one-to-two years, 7% within two-to-three years and 2% in greater than three years.

[0000320193-20-000062:notes:22]
[same as prior period, unchanged from 0000320193-20-000052:notes:22]

[0000320193-20-000062:notes:23]
Net sales disaggregated by significant products and services for the three- and nine-month periods ended June 27, 2020 and June 29, 2019 were as follows (in millions):

[0000320193-20-000062:notes:24]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | June 27,2020 |  | June 29,2019 |  | June 27,2020 |  | June 29,2019 |
| iPhone (1) | $ | 26,418 |  |  | $ | 25,986 |  |  | $ | 111,337 |  |  | $ | 109,019 |  |
| Mac (1) | 7,079 |  |  | 5,820 |  |  | 19,590 |  |  | 18,749 |  |
| iPad (1) | 6,582 |  |  | 5,023 |  |  | 16,927 |  |  | 16,624 |  |
| Wearables, Home and Accessories (1)(2) | 6,450 |  |  | 5,525 |  |  | 22,744 |  |  | 17,962 |  |
| Services (3) | 13,156 |  |  | 11,455 |  |  | 39,219 |  |  | 33,780 |  |
| Total net sales (4) | $ | 59,685 |  |  | $ | 53,809 |  |  | $ | 209,817 |  |  | $ | 196,134 |  |

[0000320193-20-000062:notes:25]
(1)Products net sales include amortization of the deferred value of unspecified software upgrade rights, which are bundled in the sales price of the respective product.

[0000320193-20-000062:notes:26]
(2)Wearables, Home and Accessories net sales include sales of AirPods®, Apple TV®, Apple Watch®, Beats® products, HomePod®, iPod touch® and Apple-branded and third-party accessories.

[0000320193-20-000062:notes:27]
(3)Services net sales include sales from the Company’s digital content stores and streaming services, AppleCare®, Advertising and other services. Services net sales also include amortization of the deferred value of Maps, Siri, and free iCloud storage and Apple TV + services, which are bundled in the sales price of certain products.

[0000320193-20-000062:notes:28]
(4)Includes $2.1 billion of revenue recognized in the three months ended June 27, 2020 that was included in deferred revenue as of March 28, 2020, $2.0 billion of revenue recognized in the three months ended June 29, 2019 that was included in deferred revenue as of March 30, 2019, $4.0 billion of revenue recognized in the nine months ended June 27, 2020 that was included in deferred revenue as of September 28, 2019, and $4.9 billion of revenue recognized in the nine months ended June 29, 2019 that was included in deferred revenue as of September 29, 2018.

[0000320193-20-000062:notes:29]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 11, “Segment Information and Geographic Data” for the three- and nine-month periods ended June 27, 2020 and June 29, 2019.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000320193-20-000062:notes:30]
[same as prior period, unchanged from 0000320193-20-000052:notes:30]

[0000320193-20-000062:notes:31]
The following tables show the Company’s cash and marketable securities by significant investment category as of June 27, 2020 and September 28, 2019 (in millions):

[0000320193-20-000062:notes:32]
|  | June 27, 2020 |  |  |  |  |  |  |  |  |  |  |  |  |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | CurrentMarketableSecurities |  | Non-Current Marketable Securities |
| Cash | $ | 20,253 |  |  | $ | — |  |  | $ | — |  |  | $ | 20,253 |  |  | $ | 20,253 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 7,013 |  |  | — |  |  | — |  |  | 7,013 |  |  | 7,013 |  |  | — |  |  | — |  |
| Subtotal | 7,013 |  |  | — |  |  | — |  |  | 7,013 |  |  | 7,013 |  |  | — |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 23,207 |  |  | 394 |  |  | — |  |  | 23,601 |  |  | 1,767 |  |  | 11,346 |  |  | 10,488 |  |
| U.S. agency securities | 7,129 |  |  | 9 |  |  | (2) |  |  | 7,136 |  |  | 59 |  |  | 2,737 |  |  | 4,340 |  |
| Non-U.S. government securities | 19,324 |  |  | 255 |  |  | (272) |  |  | 19,307 |  |  | 1 |  |  | 4,062 |  |  | 15,244 |  |
| Certificates of deposit and time deposits | 10,247 |  |  | — |  |  | — |  |  | 10,247 |  |  | 3,324 |  |  | 6,787 |  |  | 136 |  |
| Commercial paper | 12,105 |  |  | — |  |  | — |  |  | 12,105 |  |  | 936 |  |  | 11,169 |  |  | — |  |
| Corporate debt securities | 78,747 |  |  | 1,672 |  |  | (280) |  |  | 80,139 |  |  | 30 |  |  | 22,581 |  |  | 57,528 |  |
| Municipal securities | 964 |  |  | 20 |  |  | — |  |  | 984 |  |  | — |  |  | 43 |  |  | 941 |  |
| Mortgage- and asset-backed securities | 12,530 |  |  | 322 |  |  | (20) |  |  | 12,832 |  |  | — |  |  | 917 |  |  | 11,915 |  |
| Subtotal | 164,253 |  |  | 2,672 |  |  | (574) |  |  | 166,351 |  |  | 6,117 |  |  | 59,642 |  |  | 100,592 |  |
| Total (3) | $ | 191,519 |  |  | $ | 2,672 |  |  | $ | (574) |  |  | $ | 193,617 |  |  | $ | 33,383 |  |  | $ | 59,642 |  |  | $ | 100,592 |  |

[0000320193-20-000062:notes:33]
|  | September 28, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | CurrentMarketableSecurities |  | Non-CurrentMarketableSecurities |
| Cash | $ | 12,204 |  |  | $ | — |  |  | $ | — |  |  | $ | 12,204 |  |  | $ | 12,204 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 15,897 |  |  | — |  |  | — |  |  | 15,897 |  |  | 15,897 |  |  | — |  |  | — |  |
| Subtotal | 15,897 |  |  | — |  |  | — |  |  | 15,897 |  |  | 15,897 |  |  | — |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 30,293 |  |  | 33 |  |  | (62) |  |  | 30,264 |  |  | 6,165 |  |  | 9,817 |  |  | 14,282 |  |
| U.S. agency securities | 9,767 |  |  | 1 |  |  | (3) |  |  | 9,765 |  |  | 6,489 |  |  | 2,249 |  |  | 1,027 |  |
| Non-U.S. government securities | 19,821 |  |  | 337 |  |  | (50) |  |  | 20,108 |  |  | 749 |  |  | 3,168 |  |  | 16,191 |  |
| Certificates of deposit and time deposits | 4,041 |  |  | — |  |  | — |  |  | 4,041 |  |  | 2,024 |  |  | 1,922 |  |  | 95 |  |
| Commercial paper | 12,433 |  |  | — |  |  | — |  |  | 12,433 |  |  | 5,193 |  |  | 7,240 |  |  | — |  |
| Corporate debt securities | 85,383 |  |  | 756 |  |  | (92) |  |  | 86,047 |  |  | 123 |  |  | 26,127 |  |  | 59,797 |  |
| Municipal securities | 958 |  |  | 8 |  |  | (1) |  |  | 965 |  |  | — |  |  | 68 |  |  | 897 |  |
| Mortgage- and asset-backed securities | 14,180 |  |  | 67 |  |  | (73) |  |  | 14,174 |  |  | — |  |  | 1,122 |  |  | 13,052 |  |
| Subtotal | 176,876 |  |  | 1,202 |  |  | (281) |  |  | 177,797 |  |  | 20,743 |  |  | 51,713 |  |  | 105,341 |  |
| Total (3) | $ | 204,977 |  |  | $ | 1,202 |  |  | $ | (281) |  |  | $ | 205,898 |  |  | $ | 48,844 |  |  | $ | 51,713 |  |  | $ | 105,341 |  |

[0000320193-20-000062:notes:34]
(1)Level 1 fair value estimates are based on quoted prices in active markets for identical assets or liabilities.

[0000320193-20-000062:notes:35]
(2)Level 2 fair value estimates are based on observable inputs other than quoted prices in active markets for identical assets and liabilities, quoted prices for identical or similar assets or liabilities in inactive markets, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities.

[0000320193-20-000062:notes:36]
(3)As of June 27, 2020 and September 28, 2019, total marketable securities included $18.3 billion and $18.9 billion, respectively, that was restricted from general use, related to the State Aid Decision (refer to Note 5, “Income Taxes”) and other agreements. Additionally, as of June 27, 2020, $5.3 billion of marketable securities were pledged as collateral under repurchase agreements (refer to Note 6, “Debt”).

[0000320193-20-000062:notes:37]
[same as prior period, unchanged from 0000320193-20-000052:notes:37]

[0000320193-20-000062:notes:38]
The Company typically invests in highly rated securities, with the primary objective of minimizing the potential risk of principal loss. The Company’s investment policy generally requires securities to be investment grade and limits the amount of credit exposure to any one issuer. Fair values were determined for each individual security in the investment portfolio. When evaluating a marketable debt security for other-than-temporary impairment, the Company reviews factors such as the duration and extent to which the fair value of the security is less than its cost, the financial condition of the issuer and any changes thereto, and the Company’s intent to sell, or whether it will more likely than not be required to sell the security before recovery of its amortized cost basis. As of June 27, 2020, the Company does not consider any of its marketable debt securities to be other-than-temporarily impaired.

[0000320193-20-000062:notes:39]
[same as prior period, unchanged from 0000320193-20-000052:notes:39]

[0000320193-20-000062:notes:40]
The Company holds non-marketable equity securities of certain privately held companies without readily determinable fair values. As of June 27, 2020 and September 28, 2019, the Company’s non-marketable equity securities had a carrying value of $2.8 billion and $2.9 billion, respectively.

[0000320193-20-000062:notes:41]
[same as prior period, unchanged from 0000320193-20-000052:notes:41]

[0000320193-20-000062:notes:42]
A reconciliation of the Company’s cash and cash equivalents in the Condensed Consolidated Balance Sheets to cash, cash equivalents and restricted cash in the Condensed Consolidated Statements of Cash Flows as of June 27, 2020 and September 28, 2019 is as follows (in millions):

[0000320193-20-000062:notes:43]
|  | June 27,2020 |  | September 28,2019 |
| Cash and cash equivalents | $ | 33,383 |  |  | $ | 48,844 |  |
| Restricted cash included in other current assets | 29 |  |  | 23 |  |
| Restricted cash included in other non-current assets | 1,627 |  |  | 1,357 |  |
| Cash, cash equivalents and restricted cash | $ | 35,039 |  |  | $ | 50,224 |  |

[0000320193-20-000062:notes:44]
The Company’s restricted cash primarily consisted of cash to support the Company’s iPhone Upgrade Program.

[0000320193-20-000062:notes:45]
[same as prior period, unchanged from 0000320193-20-000052:notes:45]

[0000320193-20-000062:notes:46]
[same as prior period, unchanged from 0000320193-20-000052:notes:46]

[0000320193-20-000062:notes:47]
[same as prior period, unchanged from 0000320193-20-000052:notes:47]

[0000320193-20-000062:notes:48]
[same as prior period, unchanged from 0000320193-20-000052:notes:48]

[0000320193-20-000062:notes:49]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in foreign currency exchange rates, the Company may enter into forward contracts, cross-currency swaps or other instruments. These instruments may offset a portion of the foreign currency remeasurement gains or losses, or changes in fair value. The Company may designate these instruments as either cash flow or fair value hedges. As of June 27, 2020, the Company’s hedged term debt– and marketable securities–related foreign currency transactions are expected to be recognized within 22 years.

[0000320193-20-000062:notes:50]
[same as prior period, unchanged from 0000320193-20-000052:notes:50]

[0000320193-20-000062:notes:51]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in interest rates, the Company may enter into interest rate swaps, options or other instruments. These instruments may offset a portion of the changes in interest income or expense, or changes in fair value. The Company designates these instruments as either cash flow or fair value hedges. As of June 27, 2020, the Company’s hedged interest rate transactions are expected to be recognized within seven years.

[0000320193-20-000062:notes:52]
[same as prior period, unchanged from 0000320193-20-000052:notes:52]

[0000320193-20-000062:notes:53]
[same as prior period, unchanged from 0000320193-20-000052:notes:53]

[0000320193-20-000062:notes:54]
[same as prior period, unchanged from 0000320193-20-000052:notes:54]

[0000320193-20-000062:notes:55]
[same as prior period, unchanged from 0000320193-20-000052:notes:55]

[0000320193-20-000062:notes:56]
[same as prior period, unchanged from 0000320193-20-000052:notes:56]

[0000320193-20-000062:notes:57]
[same as prior period, unchanged from 0000320193-20-000052:notes:57]

[0000320193-20-000062:notes:58]
Fair value hedge gains and losses related to amounts that are included in the assessment of hedge effectiveness are recognized in earnings along with a corresponding loss or gain related to the change in value of the hedged item in the same line in the Condensed Consolidated Statements of Operations. For foreign exchange forward contracts designated as fair value hedges, the forward carry component is excluded from the assessment of hedge effectiveness and recognized in OI&E on a straight-line basis over the life of the hedge. Changes in the fair value of amounts excluded from the assessment of hedge effectiveness are recognized in OCI. Amounts excluded from the effectiveness assessment of fair value hedges and recognized in OI&E were gains of $119 million and $373 million for the three- and nine-month periods ended June 27, 2020, respectively.

[0000320193-20-000062:notes:59]
[same as prior period, unchanged from 0000320193-20-000052:notes:59]

[0000320193-20-000062:notes:60]
[same as prior period, unchanged from 0000320193-20-000052:notes:60]

[0000320193-20-000062:notes:61]
The Company records all derivatives in the Condensed Consolidated Balance Sheets at fair value. The Company’s accounting treatment for these derivative instruments is based on its hedge designation. The following tables show the Company’s derivative instruments at gross fair value as of June 27, 2020 and September 28, 2019 (in millions):

[0000320193-20-000062:notes:62]
|  | June 27, 2020 |  |  |  |  |
|  | Fair Value ofDerivatives Designatedas Hedge Instruments |  | Fair Value ofDerivatives Not Designatedas Hedge Instruments |  | TotalFair Value |
| Derivative assets (1): |  |  |  |  |  |
| Foreign exchange contracts | $ | 1,247 |  |  | $ | 172 |  |  | $ | 1,419 |  |
| Interest rate contracts | $ | 1,612 |  |  | $ | — |  |  | $ | 1,612 |  |
| Derivative liabilities (2): |  |  |  |  |  |
| Foreign exchange contracts | $ | 1,757 |  |  | $ | 277 |  |  | $ | 2,034 |  |

[0000320193-20-000062:notes:63]
|  | September 28, 2019 |  |  |  |  |
|  | Fair Value ofDerivatives Designatedas Hedge Instruments |  | Fair Value ofDerivatives Not Designatedas Hedge Instruments |  | TotalFair Value |
| Derivative assets (1): |  |  |  |  |  |
| Foreign exchange contracts | $ | 1,798 |  |  | $ | 323 |  |  | $ | 2,121 |  |
| Interest rate contracts | $ | 685 |  |  | $ | — |  |  | $ | 685 |  |
| Derivative liabilities (2): |  |  |  |  |  |
| Foreign exchange contracts | $ | 1,341 |  |  | $ | 160 |  |  | $ | 1,501 |  |
| Interest rate contracts | $ | 105 |  |  | $ | — |  |  | $ | 105 |  |

[0000320193-20-000062:notes:64]
(1)The fair value of derivative assets is measured using Level 2 fair value inputs and is included in other current assets and other non-current assets in the Condensed Consolidated Balance Sheets.

[0000320193-20-000062:notes:65]
(2)The fair value of derivative liabilities is measured using Level 2 fair value inputs and is included in other current liabilities and other non-current liabilities in the Condensed Consolidated Balance Sheets.

[0000320193-20-000062:notes:66]
[same as prior period, unchanged from 0000320193-20-000052:notes:66]

[0000320193-20-000062:notes:67]
The following table shows the pre-tax gains and losses of the Company’s derivative and non-derivative instruments designated as cash flow and net investment hedges in OCI and the Condensed Consolidated Statements of Operations for the three- and nine-month periods ended June 27, 2020 and June 29, 2019 (in millions):

[0000320193-20-000062:notes:68]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | June 27,2020 |  | June 29,2019 |  | June 27,2020 |  | June 29,2019 |
| Gains/(Losses) recognized in OCI – included in effectiveness assessment: |  |  |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 366 |  |  | $ | (147) |  |  | $ | 175 |  |  | $ | (689) |  |
| Interest rate contracts | (6) |  |  | — |  |  | (72) |  |  | — |  |
| Total | $ | 360 |  |  | $ | (147) |  |  | $ | 103 |  |  | $ | (689) |  |
| Net investment hedges: |  |  |  |  |  |  |  |
| Foreign currency debt | $ | (20) |  |  | $ | (32) |  |  | $ | 15 |  |  | $ | (55) |  |
| Gains/(Losses) reclassified from AOCI into net income – included in effectiveness assessment: |  |  |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 1,389 |  |  | $ | 53 |  |  | $ | 1,063 |  |  | $ | 69 |  |
| Interest rate contracts | (3) |  |  | (2) |  |  | (6) |  |  | (5) |  |
| Total | $ | 1,386 |  |  | $ | 51 |  |  | $ | 1,057 |  |  | $ | 64 |  |

[0000320193-20-000062:notes:69]
Amounts excluded from the effectiveness assessment of the Company’s hedges and recognized in OCI were losses of $220 million and $51 million for the three- and nine-month periods ended June 27, 2020, respectively.

[0000320193-20-000062:notes:70]
The following tables show information about the Company’s derivative instruments designated as fair value hedges and the related hedged items for the three- and nine-month periods ended June 27, 2020 and June 29, 2019 and as of June 27, 2020 (in millions):

[0000320193-20-000062:notes:71]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | June 27,2020 |  | June 29,2019 |  | June 27,2020 |  | June 29,2019 |
| Gains/(Losses) on derivative instruments (1): |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | (675) |  |  | $ | (136) |  |  | $ | (422) |  |  | $ | 509 |  |
| Interest rate contracts | 57 |  |  | 671 |  |  | 1,185 |  |  | 1,793 |  |
| Total | $ | (618) |  |  | $ | 535 |  |  | $ | 763 |  |  | $ | 2,302 |  |
| Gains/(Losses) related to hedged items (1): |  |  |  |  |  |  |  |
| Marketable securities | $ | 675 |  |  | $ | 136 |  |  | $ | 422 |  |  | $ | (508) |  |
| Fixed-rate debt | (57) |  |  | (671) |  |  | (1,185) |  |  | (1,793) |  |
| Total | $ | 618 |  |  | $ | (535) |  |  | $ | (763) |  |  | $ | (2,301) |  |

[0000320193-20-000062:notes:72]
|  | June 27,2020 |  |  |
| Carrying amounts of hedged assets/(liabilities): |  |  |  |
| Marketable securities (2) | $ | 15,736 |  |  |  |
| Fixed-rate debt (3) | $ | (21,104) |  |  |  |
| Cumulative hedging adjustments included in the carrying amounts of hedged items: |  |  |  |
| Marketable securities carrying amount increases/(decreases) | $ | (146) |  |  |  |
| Fixed-rate debt carrying amount (increases)/decreases | $ | (1,612) |  |  |  |

[0000320193-20-000062:notes:73]
(1)Gains and losses related to fair value hedges are included in OI&E in the Condensed Consolidated Statements of Operations.

[0000320193-20-000062:notes:74]
(2)The carrying amounts of marketable securities that are designated as hedged items in fair value hedges are included in current marketable securities and non-current marketable securities in the Condensed Consolidated Balance Sheet.

[0000320193-20-000062:notes:75]
(3)The carrying amounts of fixed-rate debt instruments that are designated as hedged items in fair value hedges are included in current term debt and non-current term debt in the Condensed Consolidated Balance Sheet.

[0000320193-20-000062:notes:76]
The following table shows the notional amounts of the Company’s outstanding derivative instruments and credit risk amounts associated with outstanding or unsettled derivative instruments as of June 27, 2020 and September 28, 2019 (in millions):

[0000320193-20-000062:notes:77]
|  | June 27, 2020 |  |  |  | September 28, 2019 |  |  |
|  | NotionalAmount |  | Credit RiskAmount |  | NotionalAmount |  | Credit RiskAmount |
| Instruments designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 52,845 |  |  | $ | 1,247 |  |  | $ | 61,795 |  |  | $ | 1,798 |  |
| Interest rate contracts | $ | 19,500 |  |  | $ | 1,612 |  |  | $ | 31,250 |  |  | $ | 685 |  |
| Instruments not designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 50,208 |  |  | $ | 172 |  |  | $ | 76,868 |  |  | $ | 323 |  |

[0000320193-20-000062:notes:78]
[same as prior period, unchanged from 0000320193-20-000052:notes:78]

[0000320193-20-000062:notes:79]
The Company generally enters into master netting arrangements, which are designed to reduce credit risk by permitting net settlement of transactions with the same counterparty. To further limit credit risk, the Company generally enters into collateral security arrangements that provide for collateral to be received or posted when the net fair value of certain financial instruments fluctuates from contractually established thresholds. The Company presents its derivative assets and derivative liabilities at their gross fair values in its Condensed Consolidated Balance Sheets. As of June 27, 2020 and September 28, 2019, the net cash collateral received by the Company related to derivative instruments under its collateral security arrangements was $1.2 billion and $1.6 billion, respectively, which were included in other current liabilities in the Condensed Consolidated Balance Sheets.

[0000320193-20-000062:notes:80]
Under master netting arrangements with the respective counterparties to the Company’s derivative contracts, the Company is allowed to net settle transactions with a single net amount payable by one party to the other. As of June 27, 2020 and September 28, 2019, the potential effects of these rights of set-off associated with the Company’s derivative contracts, including the effects of collateral, would be a reduction to both derivative assets and derivative liabilities of $3.3 billion and $2.7 billion, respectively, resulting in net derivative liabilities of $197 million and $407 million, respectively.

[0000320193-20-000062:notes:81]
[same as prior period, unchanged from 0000320193-20-000052:notes:81]

[0000320193-20-000062:notes:82]
[same as prior period, unchanged from 0000320193-20-000052:notes:82]

[0000320193-20-000062:notes:83]
[same as prior period, unchanged from 0000320193-20-000052:notes:83]

[0000320193-20-000062:notes:84]
As of both June 27, 2020 and September 28, 2019, the Company had no customers that individually represented 10% or more of total trade receivables. The Company’s cellular network carriers accounted for 32% and 51% of total trade receivables as of June 27, 2020 and September 28, 2019, respectively.

[0000320193-20-000062:notes:85]
[same as prior period, unchanged from 0000320193-20-000052:notes:85]

[0000320193-20-000062:notes:86]
The Company has non-trade receivables from certain of its manufacturing vendors resulting from the sale of components to these vendors who manufacture sub-assemblies or assemble final products for the Company. The Company purchases these components directly from suppliers. As of June 27, 2020, the Company had three vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 49%, 18% and 11%. As of September 28, 2019, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 59% and 14%.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000320193-20-000062:notes:87]
Level 1 fair value estimates are based on quoted prices in active markets for identical assets or liabilities.Level 2 fair value estimates are based on observable inputs other than quoted prices in active markets for identical assets and liabilities, quoted prices for identical or similar assets or liabilities in inactive markets, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities.


## us-gaap:DerivativesPolicyTextBlock

[0000320193-20-000062:notes:88]
Derivatives that are not designated as hedging instruments are adjusted to fair value through earnings in the financial statement line item to which the derivative relates.
The Company records all derivatives in the Condensed Consolidated Balance Sheets at fair value. The Company’s accounting treatment for these derivative instruments is based on its hedge designation.The Company classifies cash flows related to derivative financial instruments as operating activities in its Condensed Consolidated Statements of Cash Flows.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000320193-20-000062:notes:89]
Condensed Consolidated Financial Statement Details
The following tables show the Company’s condensed consolidated financial statement details as of June 27, 2020 and September 28, 2019 (in millions):

[0000320193-20-000062:notes:90]
[same as prior period, unchanged from 0000320193-20-000052:notes:91]

[0000320193-20-000062:notes:91]
|  | June 27,2020 |  | September 28,2019 |
| Land and buildings | $ | 18,068 |  |  | $ | 17,085 |  |
| Machinery, equipment and internal-use software | 72,982 |  |  | 69,797 |  |
| Leasehold improvements | 9,867 |  |  | 9,075 |  |
| Gross property, plant and equipment | 100,917 |  |  | 95,957 |  |
| Accumulated depreciation and amortization | (65,230) |  |  | (58,579) |  |
| Total property, plant and equipment, net | $ | 35,687 |  |  | $ | 37,378 |  |

[0000320193-20-000062:notes:92]
[same as prior period, unchanged from 0000320193-20-000052:notes:93]

[0000320193-20-000062:notes:93]
|  | June 27,2020 |  | September 28,2019 |
| Long-term taxes payable | $ | 28,188 |  |  | $ | 29,545 |  |
| Other non-current liabilities | 27,508 |  |  | 20,958 |  |
| Total other non-current liabilities | $ | 55,696 |  |  | $ | 50,503 |  |

[0000320193-20-000062:notes:94]
[same as prior period, unchanged from 0000320193-20-000052:notes:95]

[0000320193-20-000062:notes:95]
The following table shows the detail of OI&E for the three- and nine-month periods ended June 27, 2020 and June 29, 2019 (in millions):

[0000320193-20-000062:notes:96]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | June 27,2020 |  | June 29,2019 |  | June 27,2020 |  | June 29,2019 |
| Interest and dividend income | $ | 901 |  |  | $ | 1,190 |  |  | $ | 2,995 |  |  | $ | 3,855 |  |
| Interest expense | (697) |  |  | (866) |  |  | (2,239) |  |  | (2,766) |  |
| Other income/(expense), net | (158) |  |  | 43 |  |  | (79) |  |  | 216 |  |
| Total other income/(expense), net | $ | 46 |  |  | $ | 367 |  |  | $ | 677 |  |  | $ | 1,305 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000320193-20-000062:notes:97]
[same as prior period, unchanged from 0000320193-20-000052:notes:98]

[0000320193-20-000062:notes:98]
As of June 27, 2020, the total amount of gross unrecognized tax benefits was $16.2 billion, of which $8.6 billion, if recognized, would impact the Company’s effective tax rate. The Company had accrued $1.3 billion of gross interest and penalties related to income tax matters as of June 27, 2020.

[0000320193-20-000062:notes:99]
The Company is subject to taxation and files income tax returns in the U.S. federal jurisdiction and many state and foreign jurisdictions. The U.S. Internal Revenue Service concluded its review of the years 2013 through 2015 in 2018, and all years before 2016 are closed. Tax years after 2014 remain open in certain major foreign jurisdictions and are subject to examination by the taxing authorities. The Company believes that an adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax audits cannot be predicted with certainty. If any issues addressed in the Company’s tax audits are resolved in a manner inconsistent with its expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. Although the timing of resolution and/or closure of audits is not certain, the Company believes it is reasonably possible that its gross unrecognized tax benefits could decrease in the next 12 months by as much as $4.8 billion.

[0000320193-20-000062:notes:100]
[same as prior period, unchanged from 0000320193-20-000052:notes:101]

[0000320193-20-000062:notes:101]
On August 30, 2016, the European Commission announced its decision that Ireland granted state aid to the Company by providing tax opinions in 1991 and 2007 concerning the tax allocation of profits of the Irish branches of two subsidiaries of the Company (the “State Aid Decision”). The State Aid Decision ordered Ireland to calculate and recover additional taxes from the Company for the period June 2003 through December 2014. Irish legislative changes, effective as of January 2015, eliminated the application of the tax opinions from that date forward. The recovery amount was calculated to be €13.1 billion, plus interest of €1.2 billion. The Company and Ireland appealed the State Aid Decision to the General Court of the Court of Justice of the European Union (the “General Court”). On July 15, 2020, the General Court annulled the State Aid Decision. The General Court’s judgment is subject to appeal by the European Commission.

[0000320193-20-000062:notes:102]
On an annual basis, the Company may request approval from the Irish Minister for Finance to reduce the recovery amount for certain taxes paid to other countries. As of June 27, 2020, the adjusted recovery amount was €12.9 billion, excluding interest. The adjusted recovery amount plus interest is funded into escrow, where it will remain restricted from general use pending the conclusion of all legal proceedings. Refer to the Cash, Cash Equivalents and Marketable Securities section of Note 3, “Financial Instruments” for more information.


## us-gaap:DebtDisclosureTextBlock

[0000320193-20-000062:notes:103]
Debt
Commercial Paper and Repurchase Agreements

[0000320193-20-000062:notes:104]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of both June 27, 2020 and September 28, 2019, the Company had $6.0 billion of Commercial Paper outstanding with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 0.77% and 2.24% as of June 27, 2020 and September 28, 2019, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the nine months ended June 27, 2020 and June 29, 2019 (in millions):

[0000320193-20-000062:notes:105]
|  | Nine Months Ended |  |  |
|  | June 27,2020 |  | June 29,2019 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | 401 |  |  | $ | (3,720) |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 5,373 |  |  | 12,977 |  |
| Repayments of commercial paper | (5,743) |  |  | (11,283) |  |
| Proceeds from/(Repayments of) commercial paper, net | (370) |  |  | 1,694 |  |
| Total proceeds from/(repayments of) commercial paper, net | $ | 31 |  |  | $ | (2,026) |  |

[0000320193-20-000062:notes:106]
In 2020, the Company entered into agreements to sell certain of its marketable securities with a promise to repurchase the securities at a specified time and amount (“Repos”). Due to the Company’s continuing involvement with the marketable securities, the Company accounts for its Repos as collateralized borrowings. As of June 27, 2020, the Company had $5.2 billion of Repo liabilities outstanding with maturities of less than three months, and had pledged $5.3 billion of marketable securities as collateral.

[0000320193-20-000062:notes:107]
Term Debt

[0000320193-20-000062:notes:108]
As of June 27, 2020, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $100.1 billion (collectively the “Notes”). The Notes are senior unsecured obligations and interest is payable in arrears. The following table provides a summary of the Company’s term debt as of June 27, 2020 and September 28, 2019:

[0000320193-20-000062:notes:109]
|  | Maturities(calendar year) |  | June 27, 2020 |  |  |  | September 28, 2019 |  |  |
|  |  |  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 – 2019 debt issuances: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2021 – 2022 |  | $ | 2,250 |  |  | 0.80% – 1.49% |  | $ | 4,250 |  |  | 2.25% – 3.28% |
| Fixed-rate 0.375% – 4.650% notes | 2020 – 2049 |  | 87,055 |  |  | 0.28% – 4.78% |  | 97,429 |  |  | 0.28% – 4.78% |
| First quarter 2020 debt issuance of €2.0 billion: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.000% – 0.500% notes | 2025 – 2031 |  | 2,260 |  |  | 0.03% – 0.56% |  | — |  |  | — | % |
| Third quarter 2020 debt issuance of $8.5 billion: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.750% – 2.650% notes | 2023 – 2050 |  | 8,500 |  |  | 0.84% – 2.72% |  | — |  |  | — | % |
| Total term debt |  |  | 100,065 |  |  |  |  | 101,679 |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  | (279) |  |  |  |  | (224) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 1,771 |  |  |  |  | 612 |  |  |  |
| Less: Current portion of term debt |  |  | (7,509) |  |  |  |  | (10,260) |  |  |  |
| Total non-current portion of term debt |  |  | $ | 94,048 |  |  |  |  | $ | 91,807 |  |  |  |

[0000320193-20-000062:notes:110]
To manage interest rate risk on certain of its U.S. dollar–denominated fixed- or floating-rate notes, the Company has entered into interest rate swaps to effectively convert the fixed interest rates to floating interest rates or the floating interest rates to fixed interest rates on a portion of these notes. Additionally, to manage foreign currency risk on certain of its foreign currency–denominated notes, the Company has entered into foreign currency swaps to effectively convert these notes to U.S. dollar–denominated notes.

[0000320193-20-000062:notes:111]
As of September 28, 2019, a portion of the Company’s Japanese yen–denominated notes with a carrying value of $1.0 billion was designated as a hedge of the foreign currency exposure of the Company’s net investment in a foreign operation. The Company’s Japanese yen–denominated notes matured during the third quarter of 2020 and the associated net investment hedges were terminated. For further discussion regarding the Company’s use of derivative instruments, refer to the Derivative Financial Instruments section of Note 3, “Financial Instruments.”

[0000320193-20-000062:notes:112]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $664 million and $2.1 billion of interest cost on its term debt for the three- and nine-month periods ended June 27, 2020, respectively. The Company recognized $790 million and $2.4 billion of interest cost on its term debt for the three- and nine-month periods ended June 29, 2019, respectively.

[0000320193-20-000062:notes:113]
As of June 27, 2020 and September 28, 2019, the fair value of the Company’s Notes, based on Level 2 inputs, was $110.8 billion and $107.5 billion, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000320193-20-000062:notes:114]
Shareholders’ Equity
Share Repurchase Program

[0000320193-20-000062:notes:115]
As of June 27, 2020, the Company was authorized to purchase up to $225 billion of the Company’s common stock under a share repurchase program, of which $150.6 billion had been utilized. During the nine months ended June 27, 2020, the Company repurchased 186.4 million shares of its common stock for $54.5 billion, including 35.2 million shares delivered under a $10.0 billion November 2019 accelerated share repurchase arrangement (“ASR”) and 15.2 million shares initially delivered under a $6.0 billion May 2020 ASR. The Company’s share repurchase program does not obligate it to acquire any specific number of shares. Under this program, shares may be repurchased in privately negotiated and/or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).

[0000320193-20-000062:notes:116]
Under the Company’s ASRs, financial institutions deliver shares of the Company’s common stock during the purchase period of each ASR in exchange for an up-front payment. The total number of shares ultimately delivered under the May 2020 ASR, and therefore the average repurchase price paid per share, is determined based on the volume-weighted average price of the Company’s common stock during the purchase period, which will end in or before August 2020. The shares received are retired in the periods they are delivered, and the up-front payment is accounted for as a reduction to retained earnings in the Company’s Condensed Consolidated Statement of Shareholders’ Equity in the period the payment is made.

[0000320193-20-000062:notes:117]
Common Stock Split

[0000320193-20-000062:notes:118]
On July 30, 2020, the Company announced a four-for-one split of its common stock to shareholders of record as of the close of business on August 24, 2020. Trading of the Company’s common stock will begin on a split-adjusted basis on August 31, 2020.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000320193-20-000062:notes:119]
Comprehensive IncomeThe Company’s OCI consists of foreign currency translation adjustments from those subsidiaries not using the U.S. dollar as their functional currency, net deferred gains and losses on certain derivative instruments accounted for as hedges, and unrealized gains and losses on marketable debt securities classified as available-for-sale.
The following table shows the pre-tax amounts reclassified from AOCI into the Condensed Consolidated Statements of Operations, and the associated financial statement line items, for the three- and nine-month periods ended June 27, 2020 and June 29, 2019 (in millions):

[0000320193-20-000062:notes:120]
|  |  |  |  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
| Comprehensive Income Components |  | Financial Statement Line Items |  | June 27,2020 |  | June 29,2019 |  | June 27,2020 |  | June 29,2019 |
| Unrealized (gains)/losses on derivative instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Total net sales |  | $ | (270) |  |  | $ | (68) |  |  | $ | (333) |  |  | $ | (102) |  |
|  |  | Total cost of sales |  | (362) |  |  | 13 |  |  | (521) |  |  | (438) |  |
|  |  | Other income/(expense), net |  | (760) |  |  | 3 |  |  | (212) |  |  | 451 |  |
| Interest rate contracts |  | Other income/(expense), net |  | 3 |  |  | 2 |  |  | 6 |  |  | 5 |  |
|  |  |  |  | (1,389) |  |  | (50) |  |  | (1,060) |  |  | (84) |  |
| Unrealized (gains)/losses on marketable debt securities |  | Other income/(expense), net |  | (14) |  |  | (28) |  |  | 10 |  |  | 55 |  |
| Total amounts reclassified from AOCI |  |  |  | $ | (1,403) |  |  | $ | (78) |  |  | $ | (1,050) |  |  | $ | (29) |  |

[0000320193-20-000062:notes:121]
The following table shows the changes in AOCI by component for the nine months ended June 27, 2020 (in millions):

[0000320193-20-000062:notes:122]
|  | Cumulative ForeignCurrency Translation |  | Unrealized Gains/Losseson Derivative Instruments |  | Unrealized Gains/Losseson Marketable Debt Securities |  | Total |
| Balances as of September 28, 2019 | $ | (1,463) |  |  | $ | 172 |  |  | $ | 707 |  |  | $ | (584) |  |
| Other comprehensive income/(loss) before reclassifications | (167) |  |  | 32 |  |  | 1,167 |  |  | 1,032 |  |
| Amounts reclassified from AOCI | — |  |  | (1,060) |  |  | 10 |  |  | (1,050) |  |
| Tax effect | (3) |  |  | 190 |  |  | (271) |  |  | (84) |  |
| Other comprehensive income/(loss) | (170) |  |  | (838) |  |  | 906 |  |  | (102) |  |
| Cumulative effect of change in accounting principle (1) | — |  |  | 136 |  |  | — |  |  | 136 |  |
| Balances as of June 27, 2020 | $ | (1,633) |  |  | $ | (530) |  |  | $ | 1,613 |  |  | $ | (550) |  |

[0000320193-20-000062:notes:123]
(1)Refer to Note 1, “Summary of Significant Accounting Policies” for more information on the Company’s adoption of ASU 2017-12 at the beginning of the first quarter of 2020.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000320193-20-000062:notes:124]
[same as prior period, unchanged from 0000320193-20-000052:notes:123]

[0000320193-20-000062:notes:125]
The Company had 203.3 million shares reserved for future issuance under its stock plans as of June 27, 2020. Restricted stock units (“RSUs”) granted under the Company’s stock plans generally vest over four years, based on continued employment, and are settled upon vesting in shares of the Company’s common stock on a one-for-one basis. RSUs granted under the Company’s stock plans reduce the number of shares available for grant under the plans by a factor of two times the number of RSUs granted. RSUs canceled and shares withheld to satisfy tax withholding obligations increase the number of shares available for grant under the plans utilizing a factor of two times the number of RSUs canceled or shares withheld.

[0000320193-20-000062:notes:126]
[same as prior period, unchanged from 0000320193-20-000052:notes:125]

[0000320193-20-000062:notes:127]
During the three months ended June 27, 2020, Section 16 officers Katherine L. Adams, Timothy D. Cook, Chris Kondo, Luca Maestri, Deirdre O’Brien and Jeffrey Williams had equity trading plans in place in accordance with Rule 10b5-1(c)(1) under the Exchange Act. An equity trading plan is a written document that pre-establishes the amounts, prices and dates (or formula for determining the amounts, prices and dates) of future purchases or sales of the Company’s stock, including shares acquired under the Company’s employee and director equity plans.

[0000320193-20-000062:notes:128]
[same as prior period, unchanged from 0000320193-20-000052:notes:127]

[0000320193-20-000062:notes:129]
A summary of the Company’s RSU activity and related information for the nine months ended June 27, 2020 is as follows:

[0000320193-20-000062:notes:130]
|  | Number ofRSUs(in thousands) |  | Weighted-AverageGrant Date FairValue Per RSU |  | AggregateFair Value(in millions) |
| Balance as of September 28, 2019 | 81,517 |  |  | $ | 169.18 |  |  |  |
| RSUs granted | 37,815 |  |  | $ | 229.58 |  |  |  |
| RSUs vested | (37,076) |  |  | $ | 161.71 |  |  |  |
| RSUs canceled | (3,122) |  |  | $ | 190.50 |  |  |  |
| Balance as of June 27, 2020 | 79,134 |  |  | $ | 200.70 |  |  | $ | 27,984 |  |

[0000320193-20-000062:notes:131]
The fair value as of the respective vesting dates of RSUs was $5.0 billion and $9.8 billion for the three- and nine-month periods ended June 27, 2020, respectively, and was $3.7 billion and $8.1 billion for the three- and nine-month periods ended June 29, 2019, respectively.

[0000320193-20-000062:notes:132]
[same as prior period, unchanged from 0000320193-20-000052:notes:131]

[0000320193-20-000062:notes:133]
The following table shows share-based compensation expense and the related income tax benefit included in the Condensed Consolidated Statements of Operations for the three- and nine-month periods ended June 27, 2020 and June 29, 2019 (in millions):

[0000320193-20-000062:notes:134]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | June 27,2020 |  | June 29,2019 |  | June 27,2020 |  | June 29,2019 |
| Share-based compensation expense | $ | 1,698 |  |  | $ | 1,496 |  |  | $ | 5,105 |  |  | $ | 4,569 |  |
| Income tax benefit related to share-based compensation expense | $ | (740) |  |  | $ | (502) |  |  | $ | (1,942) |  |  | $ | (1,583) |  |

[0000320193-20-000062:notes:135]
As of June 27, 2020, the total unrecognized compensation cost related to outstanding RSUs and stock options was $13.4 billion, which the Company expects to recognize over a weighted-average period of 2.7 years.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000320193-20-000062:notes:136]
Commitments and Contingencies
Accrued Warranty and Guarantees

[0000320193-20-000062:notes:137]
The following table shows changes in the Company’s accrued warranties and related costs for the three- and nine-month periods ended June 27, 2020 and June 29, 2019 (in millions):

[0000320193-20-000062:notes:138]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | June 27,2020 |  | June 29,2019 |  | June 27,2020 |  | June 29,2019 |
| Beginning accrued warranty and related costs | $ | 3,923 |  |  | $ | 3,487 |  |  | $ | 3,570 |  |  | $ | 3,692 |  |
| Cost of warranty claims | (576) |  |  | (912) |  |  | (2,180) |  |  | (2,823) |  |
| Accruals for product warranty | 557 |  |  | 548 |  |  | 2,514 |  |  | 2,254 |  |
| Ending accrued warranty and related costs | $ | 3,904 |  |  | $ | 3,123 |  |  | $ | 3,904 |  |  | $ | 3,123 |  |

[0000320193-20-000062:notes:139]
The Company offers an iPhone Upgrade Program, which is available to customers who purchase a qualifying iPhone in the U.S., the U.K. and mainland China. The iPhone Upgrade Program provides customers the right to trade in that iPhone for a specified amount when purchasing a new iPhone, provided certain conditions are met. The Company accounts for the trade-in right as a guarantee liability and recognizes arrangement revenue net of the fair value of such right, with subsequent changes to the guarantee liability recognized within net sales.

[0000320193-20-000062:notes:140]
Concentrations in the Available Sources of Supply of Materials and Product

[0000320193-20-000062:notes:141]
Although most components essential to the Company’s business are generally available from multiple sources, certain components are currently obtained from single or limited sources. The Company also competes for various components with other participants in the markets for smartphones, personal computers, tablets and other electronic devices. Therefore, many components used by the Company, including those that are available from multiple sources, are at times subject to industry-wide shortage and significant commodity pricing fluctuations.

[0000320193-20-000062:notes:142]
The Company uses some custom components that are not commonly used by its competitors, and new products introduced by the Company often utilize custom components available from only one source. When a component or product uses new technologies, initial capacity constraints may exist until the suppliers’ yields have matured or their manufacturing capacities have increased. The continued availability of these components at acceptable prices, or at all, may be affected if suppliers decide to concentrate on the production of common components instead of components customized to meet the Company’s requirements.

[0000320193-20-000062:notes:143]
The Company has entered into agreements for the supply of many components; however, there can be no guarantee that the Company will be able to extend or renew these agreements on similar terms, or at all.

[0000320193-20-000062:notes:144]
Substantially all of the Company’s hardware products are manufactured by outsourcing partners that are located primarily in Asia, with some Mac computers manufactured in the U.S. and Ireland.

[0000320193-20-000062:notes:145]
Unconditional Purchase Obligations

[0000320193-20-000062:notes:146]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of payments for supplier arrangements, Internet and telecommunication services, intellectual property licenses and content creation. As of June 27, 2020, the Company’s total future payments under noncancelable unconditional purchase obligations having a remaining term in excess of one year were $9.2 billion.

[0000320193-20-000062:notes:147]
Contingencies

[0000320193-20-000062:notes:148]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully resolved. The outcome of litigation is inherently uncertain. If one or more legal matters were resolved against the Company in a reporting period for amounts above management’s expectations, the Company’s financial condition and operating results for that reporting period could be materially adversely affected. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss greater than a recorded accrual, concerning loss contingencies for asserted legal and other claims, except for the following matters:

[0000320193-20-000062:notes:149]
VirnetX

[0000320193-20-000062:notes:150]
VirnetX, Inc. (“VirnetX”) filed a lawsuit against the Company alleging that certain of the Company’s products infringe on patents owned by VirnetX. On April 11, 2018, a jury returned a verdict against the Company and awarded damages of $503 million. The Company appealed the verdict to the U.S. Court of Appeals for the Federal Circuit, which remanded the case back to the U.S. District Court for the Eastern District of Texas, where it is scheduled for a re-trial in August 2020. The Company has challenged the validity of the patents at issue in the re-trial at the U.S. Patent and Trademark Office (the “PTO”), and the PTO has declared the patents invalid, subject to further appeal by VirnetX.

[0000320193-20-000062:notes:151]
iOS Performance Management Cases

[0000320193-20-000062:notes:152]
Various civil litigation matters have been filed in state and federal courts in the U.S. and in various international jurisdictions alleging violation of consumer protection laws, fraud, computer intrusion and other causes of action related to the Company’s performance management feature used in its iPhone operating systems, introduced to certain iPhones in iOS updates 10.2.1 and 11.2. The claims seek monetary damages and other non-monetary relief. On April 5, 2018, several U.S. federal actions were consolidated through a Multidistrict Litigation process into a single action in the U.S. District Court for the Northern District of California (the “Northern California District Court”). On February 28, 2020, the parties in the Multidistrict Litigation reached a settlement to resolve the U.S. federal and California state class actions. Under the terms of the settlement, which the Northern California District Court preliminarily approved in May 2020, the Company has agreed to pay up to $500 million in the aggregate to certain U.S. owners of iPhones if certain conditions are met. The final amount of the settlement will be determined based on the number of consumers who file valid claims and the attorneys’ fee award. However, the Company has agreed to pay at least $310 million to settle the claims. In addition to civil litigation, the Company is also responding to governmental investigations and requests for information relating to the performance management feature. The Company continues to believe that its iPhones were not defective, that the performance management feature introduced with iOS updates 10.2.1 and 11.2 was intended to, and did, improve customers’ user experience, and that the Company did not make any misleading statements or fail to disclose any material information. The Company has accrued its best estimate for the ultimate resolution of these matters.

[0000320193-20-000062:notes:153]
French Competition Authority

[0000320193-20-000062:notes:154]
On March 16, 2020, the French Competition Authority (“FCA”) announced its decision that aspects of the Company’s sales and distribution practices in France violate French competition law, and issued a fine of €1.1 billion. The Company strongly disagrees with the FCA’s decision, and has appealed.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000320193-20-000062:notes:155]
[same as prior period, unchanged from 0000320193-20-000052:notes:154]

[0000320193-20-000062:notes:156]
[same as prior period, unchanged from 0000320193-20-000052:notes:155]

[0000320193-20-000062:notes:157]
[same as prior period, unchanged from 0000320193-20-000052:notes:156]

[0000320193-20-000062:notes:158]
The following table shows information by reportable segment for the three- and nine-month periods ended June 27, 2020 and June 29, 2019 (in millions):

[0000320193-20-000062:notes:159]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | June 27,2020 |  | June 29,2019 |  | June 27,2020 |  | June 29,2019 |
| Americas: |  |  |  |  |  |  |  |
| Net sales | $ | 27,018 |  |  | $ | 25,056 |  |  | $ | 93,858 |  |  | $ | 87,592 |  |
| Operating income | $ | 7,974 |  |  | $ | 7,442 |  |  | $ | 28,327 |  |  | $ | 26,329 |  |
| Europe: |  |  |  |  |  |  |  |
| Net sales | $ | 14,173 |  |  | $ | 11,925 |  |  | $ | 51,740 |  |  | $ | 45,342 |  |
| Operating income | $ | 4,420 |  |  | $ | 3,687 |  |  | $ | 16,667 |  |  | $ | 14,371 |  |
| Greater China: |  |  |  |  |  |  |  |
| Net sales | $ | 9,329 |  |  | $ | 9,157 |  |  | $ | 32,362 |  |  | $ | 32,544 |  |
| Operating income | $ | 3,414 |  |  | $ | 3,221 |  |  | $ | 12,535 |  |  | $ | 12,142 |  |
| Japan: |  |  |  |  |  |  |  |
| Net sales | $ | 4,966 |  |  | $ | 4,082 |  |  | $ | 16,395 |  |  | $ | 16,524 |  |
| Operating income | $ | 2,114 |  |  | $ | 1,795 |  |  | $ | 7,128 |  |  | $ | 7,199 |  |
| Rest of Asia Pacific: |  |  |  |  |  |  |  |
| Net sales | $ | 4,199 |  |  | $ | 3,589 |  |  | $ | 15,462 |  |  | $ | 14,132 |  |
| Operating income | $ | 1,374 |  |  | $ | 1,155 |  |  | $ | 5,395 |  |  | $ | 4,811 |  |

[0000320193-20-000062:notes:160]
A reconciliation of the Company’s segment operating income to the Condensed Consolidated Statements of Operations for the three- and nine-month periods ended June 27, 2020 and June 29, 2019 is as follows (in millions):

[0000320193-20-000062:notes:161]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | June 27,2020 |  | June 29,2019 |  | June 27,2020 |  | June 29,2019 |
| Segment operating income | $ | 19,296 |  |  | $ | 17,300 |  |  | $ | 70,052 |  |  | $ | 64,852 |  |
| Research and development expense | (4,758) |  |  | (4,257) |  |  | (13,774) |  |  | (12,107) |  |
| Other corporate expenses, net | (1,447) |  |  | (1,499) |  |  | (4,765) |  |  | (4,440) |  |
| Total operating income | $ | 13,091 |  |  | $ | 11,544 |  |  | $ | 51,513 |  |  | $ | 48,305 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000320193-20-000062:notes:162]
Leases
The Company has lease arrangements for certain equipment and facilities, including retail, corporate, manufacturing and data center space. These leases typically have original terms not exceeding 10 years and generally contain multi-year renewal options, some of which are reasonably certain of exercise. The Company’s lease arrangements may contain both lease and non-lease components. The Company has elected to combine and account for lease and non-lease components as a single lease component for leases of retail, corporate, and data center facilities.

[0000320193-20-000062:notes:163]
Payments under the Company’s lease arrangements may be fixed or variable, and variable lease payments are primarily based on purchases of output of the underlying leased assets. Lease costs associated with fixed payments on the Company’s operating leases were $381 million and $1.1 billion for the three- and nine-month periods ended June 27, 2020, respectively. Lease costs associated with variable payments on the Company’s leases were $1.8 billion and $6.6 billion for the three- and nine-month periods ended June 27, 2020, respectively.

[0000320193-20-000062:notes:164]
For the three- and nine-month periods ended June 27, 2020, the Company made $388 million and $1.1 billion of fixed cash payments related to operating leases, respectively. Non-cash activities involving ROU assets obtained in exchange for lease liabilities were $403 million and $9.7 billion for the three- and nine-month periods ended June 27, 2020, respectively, including the impact of adopting the new leases standard in the first quarter of 2020.

[0000320193-20-000062:notes:165]
The following table shows ROU assets and lease liabilities, and the associated financial statement line items, as of June 27, 2020 (in millions):

[0000320193-20-000062:notes:166]
| Lease-Related Assets and Liabilities |  | Financial Statement Line Items |  | June 27,2020 |  |  |
| Right-of-use assets: |  |  |  |  |  |  |
| Operating leases |  | Other non-current assets |  | $ | 8,164 |  |  |  |
| Finance leases |  | Property, plant and equipment, net |  | 625 |  |  |  |
| Total right-of-use assets |  |  |  | $ | 8,789 |  |  |  |
| Lease liabilities: |  |  |  |  |  |  |
| Operating leases |  | Other current liabilities |  | $ | 1,353 |  |  |  |
|  |  | Other non-current liabilities |  | 7,460 |  |  |  |
| Finance leases |  | Other current liabilities |  | 20 |  |  |  |
|  |  | Other non-current liabilities |  | 630 |  |  |  |
| Total lease liabilities |  |  |  | $ | 9,463 |  |  |  |

[0000320193-20-000062:notes:167]
Lease liability maturities as of June 27, 2020, are as follows (in millions):

[0000320193-20-000062:notes:168]
|  | OperatingLeases |  | FinanceLeases |  | Total |
| 2020 (remaining three months) | $ | 309 |  |  | $ | 5 |  |  | $ | 314 |  |
| 2021 | 1,504 |  |  | 41 |  |  | 1,545 |  |
| 2022 | 1,356 |  |  | 39 |  |  | 1,395 |  |
| 2023 | 1,183 |  |  | 50 |  |  | 1,233 |  |
| 2024 | 994 |  |  | 27 |  |  | 1,021 |  |
| Thereafter | 4,511 |  |  | 920 |  |  | 5,431 |  |
| Total undiscounted liabilities | 9,857 |  |  | 1,082 |  |  | 10,939 |  |
| Less: Imputed interest | (1,044) |  |  | (432) |  |  | (1,476) |  |
| Total lease liabilities | $ | 8,813 |  |  | $ | 650 |  |  | $ | 9,463 |  |

[0000320193-20-000062:notes:169]
The weighted-average remaining lease term and discount rate related to the Company’s lease liabilities as of June 27, 2020 were 10.5 years and 2.2%, respectively. The Company’s lease discount rates are generally based on estimates of its incremental borrowing rate, as the discount rates implicit in the Company’s leases cannot be readily determined.

[0000320193-20-000062:notes:170]
As of June 27, 2020, the Company had $1.8 billion of future payments under additional leases, primarily for corporate facilities and retail space, that had not yet commenced. These leases will commence between 2020 and 2022, with lease terms ranging from less than 1 year to 20 years.
