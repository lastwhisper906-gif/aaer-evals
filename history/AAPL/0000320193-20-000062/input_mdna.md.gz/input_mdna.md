# AAPL MD&A — 0000320193-20-000062


## mdna

[0000320193-20-000062:mdna:1]
Item 2. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000320193-20-000062:mdna:2]
[same as prior period, unchanged from 0000320193-20-000052:mdna:2]

[0000320193-20-000062:mdna:3]
[same as prior period, unchanged from 0000320193-20-000052:mdna:3]

[0000320193-20-000062:mdna:4]
[same as prior period, unchanged from 0000320193-20-000052:mdna:4]

[0000320193-20-000062:mdna:5]
[same as prior period, unchanged from 0000320193-20-000052:mdna:5]

[0000320193-20-000062:mdna:6]
[same as prior period, unchanged from 0000320193-20-000052:mdna:6]

[0000320193-20-000062:mdna:7]
[same as prior period, unchanged from 0000320193-20-000052:mdna:7]

[0000320193-20-000062:mdna:8]
During the second quarter of 2020, a novel strain of coronavirus (“COVID-19”) began spreading rapidly throughout the world, prompting governments and businesses to take unprecedented measures in response. Such measures included restrictions on travel and business operations, temporary closures of businesses, and quarantines and shelter-in-place orders. The COVID-19 pandemic has significantly curtailed global economic activity and caused significant volatility and disruption in global financial markets. The COVID-19 pandemic and the measures taken by many countries in response have adversely affected and could in the future materially adversely impact the Company’s business, results of operations, financial condition and stock price.

[0000320193-20-000062:mdna:9]
During the third quarter of 2020, aspects of the Company’s business continued to be adversely affected by the COVID-19 pandemic, with many of the Company’s retail stores temporarily closed and the vast majority of the Company’s employees working remotely. The Company is working on safely re-opening its offices and retail stores, subject to local rules and regulations.

[0000320193-20-000062:mdna:10]
Demand for certain of the Company’s products and services was impacted throughout the third quarter of 2020. The most pronounced impact occurred in April 2020, with demand improving in May and June 2020 across all product categories and Services.

[0000320193-20-000062:mdna:11]
The full extent of the future impact of the COVID-19 pandemic on the Company’s operational and financial performance is currently uncertain and will depend on many factors outside the Company’s control, including, without limitation, the timing, extent, trajectory and duration of the pandemic, the development and availability of effective treatments and vaccines, the imposition of protective public safety measures, and the impact of the pandemic on the global economy and demand for consumer products. Refer to Part I, Item 1A of the 2019 Form 10-K and Part II, Item 1A of this Form 10-Q, in each case under the heading “Risk Factors,” for more information.

[0000320193-20-000062:mdna:12]
[same as prior period, unchanged from 0000320193-20-000052:mdna:12]

[0000320193-20-000062:mdna:13]
Third Quarter Fiscal 2020 Highlights

[0000320193-20-000062:mdna:14]
Total net sales increased 11% or $5.9 billion during the third quarter of 2020 compared to the same quarter in 2019, primarily driven by higher net sales of Services, iPad and Mac. The year-over-year increase in net sales during the third quarter of 2020 reflected growth in all of the Company’s geographic reportable segments and product categories. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on net sales during the third quarter of 2020.

[0000320193-20-000062:mdna:15]
During the third quarter of 2020, the Company released a new iPhone SE and an updated 13-inch MacBook Pro®. The Company also announced iOS 14, iPadOS® 14, macOS® Big Sur, watchOS® 7 and tvOS® 14, updates to its operating systems that are expected to be available in the fall of 2020.

[0000320193-20-000062:mdna:16]
The Company repurchased $16.0 billion of its common stock and paid dividends and dividend equivalents of $3.7 billion during the third quarter of 2020.

[0000320193-20-000062:mdna:17]
[same as prior period, unchanged from 0000320193-20-000052:mdna:17]

[0000320193-20-000062:mdna:18]
The following table shows net sales by category for the three- and nine-month periods ended June 27, 2020 and June 29, 2019 (dollars in millions):

[0000320193-20-000062:mdna:19]
|  | Three Months Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | June 27,2020 |  | June 29,2019 |  | Change |  | June 27,2020 |  | June 29,2019 |  | Change |
| Net sales by category: |  |  |  |  |  |  |  |  |  |  |  |
| iPhone (1) | $ | 26,418 |  |  | $ | 25,986 |  |  | 2 | % |  | $ | 111,337 |  |  | $ | 109,019 |  |  | 2 | % |
| Mac (1) | 7,079 |  |  | 5,820 |  |  | 22 | % |  | 19,590 |  |  | 18,749 |  |  | 4 | % |
| iPad (1) | 6,582 |  |  | 5,023 |  |  | 31 | % |  | 16,927 |  |  | 16,624 |  |  | 2 | % |
| Wearables, Home and Accessories (1)(2) | 6,450 |  |  | 5,525 |  |  | 17 | % |  | 22,744 |  |  | 17,962 |  |  | 27 | % |
| Services (3) | 13,156 |  |  | 11,455 |  |  | 15 | % |  | 39,219 |  |  | 33,780 |  |  | 16 | % |
| Total net sales | $ | 59,685 |  |  | $ | 53,809 |  |  | 11 | % |  | $ | 209,817 |  |  | $ | 196,134 |  |  | 7 | % |

[0000320193-20-000062:mdna:20]
(1)Products net sales include amortization of the deferred value of unspecified software upgrade rights, which are bundled in the sales price of the respective product.

[0000320193-20-000062:mdna:21]
(2)Wearables, Home and Accessories net sales include sales of AirPods, Apple TV, Apple Watch, Beats products, HomePod, iPod touch and Apple-branded and third-party accessories.

[0000320193-20-000062:mdna:22]
(3)Services net sales include sales from the Company’s digital content stores and streaming services, AppleCare, Advertising and other services. Services net sales also include amortization of the deferred value of Maps, Siri, and free iCloud storage and Apple TV + services, which are bundled in the sales price of certain products.

[0000320193-20-000062:mdna:23]
[same as prior period, unchanged from 0000320193-20-000052:mdna:23]

[0000320193-20-000062:mdna:24]
iPhone net sales increased during the third quarter of 2020 compared to the third quarter of 2019 due primarily to net sales of the new iPhone SE released during the third quarter of 2020. Year-over-year iPhone net sales increased during the first nine months of 2020 due primarily to higher net sales of iPhone 11, 11 Pro and 11 Pro Max.

[0000320193-20-000062:mdna:25]
[same as prior period, unchanged from 0000320193-20-000052:mdna:25]

[0000320193-20-000062:mdna:26]
Mac net sales increased during the third quarter of 2020 compared to the third quarter of 2019 due to higher net sales of MacBook Pro and MacBook Air®. Year-over-year Mac net sales increased during the first nine months of 2020 due to higher net sales of MacBook Pro.

[0000320193-20-000062:mdna:27]
[same as prior period, unchanged from 0000320193-20-000052:mdna:27]

[0000320193-20-000062:mdna:28]
iPad net sales increased during the third quarter of 2020 compared to the third quarter of 2019 due primarily to higher net sales of iPad Pro®. Year-over-year iPad net sales increased during the first nine months of 2020 due primarily to higher net sales of iPad Air®.

[0000320193-20-000062:mdna:29]
[same as prior period, unchanged from 0000320193-20-000052:mdna:29]

[0000320193-20-000062:mdna:30]
Wearables, Home and Accessories net sales increased during the third quarter and first nine months of 2020 compared to the same periods in 2019 due primarily to higher net sales of AirPods.

[0000320193-20-000062:mdna:31]
[same as prior period, unchanged from 0000320193-20-000052:mdna:31]

[0000320193-20-000062:mdna:32]
Services net sales increased during the third quarter of 2020 compared to the third quarter of 2019 due primarily to higher net sales from the App Store, Video and Cloud Services. Year-over-year Services net sales increased during the first nine months of 2020 due primarily to higher net sales from the App Store, Advertising and AppleCare. Advertising net sales includes net sales from licensing arrangements and the Company’s advertising platforms.

[0000320193-20-000062:mdna:33]
[same as prior period, unchanged from 0000320193-20-000052:mdna:33]

[0000320193-20-000062:mdna:34]
[same as prior period, unchanged from 0000320193-20-000052:mdna:34]

[0000320193-20-000062:mdna:35]
The following table shows net sales by reportable segment for the three- and nine-month periods ended June 27, 2020 and June 29, 2019 (dollars in millions):

[0000320193-20-000062:mdna:36]
|  | Three Months Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | June 27,2020 |  | June 29,2019 |  | Change |  | June 27,2020 |  | June 29,2019 |  | Change |
| Net sales by reportable segment: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 27,018 |  |  | $ | 25,056 |  |  | 8 | % |  | $ | 93,858 |  |  | $ | 87,592 |  |  | 7 | % |
| Europe | 14,173 |  |  | 11,925 |  |  | 19 | % |  | 51,740 |  |  | 45,342 |  |  | 14 | % |
| Greater China | 9,329 |  |  | 9,157 |  |  | 2 | % |  | 32,362 |  |  | 32,544 |  |  | (1) | % |
| Japan | 4,966 |  |  | 4,082 |  |  | 22 | % |  | 16,395 |  |  | 16,524 |  |  | (1) | % |
| Rest of Asia Pacific | 4,199 |  |  | 3,589 |  |  | 17 | % |  | 15,462 |  |  | 14,132 |  |  | 9 | % |
| Total net sales | $ | 59,685 |  |  | $ | 53,809 |  |  | 11 | % |  | $ | 209,817 |  |  | $ | 196,134 |  |  | 7 | % |

[0000320193-20-000062:mdna:37]
[same as prior period, unchanged from 0000320193-20-000052:mdna:37]

[0000320193-20-000062:mdna:38]
Americas net sales increased during the third quarter of 2020 compared to the third quarter of 2019 due primarily to higher net sales of Services and iPad. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on Americas net sales during the third quarter of 2020. Year-over-year Americas net sales increased during the first nine months of 2020 due primarily to higher net sales of Services and Wearables, Home and Accessories.

[0000320193-20-000062:mdna:39]
[same as prior period, unchanged from 0000320193-20-000052:mdna:39]

[0000320193-20-000062:mdna:40]
Europe net sales increased during the third quarter of 2020 compared to the third quarter of 2019 due primarily to higher net sales of iPhone, iPad and Wearables, Home and Accessories. Year-over-year Europe net sales increased during the first nine months of 2020 due primarily to higher net sales of iPhone and Wearables, Home and Accessories. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on Europe net sales during the third quarter and first nine months of 2020.

[0000320193-20-000062:mdna:41]
[same as prior period, unchanged from 0000320193-20-000052:mdna:41]

[0000320193-20-000062:mdna:42]
Greater China net sales increased during the third quarter of 2020 compared to the third quarter of 2019 due primarily to higher net sales of iPad and Services, partially offset by lower net sales of iPhone. Year-over-year Greater China net sales decreased during the first nine months of 2020 due primarily to lower net sales of iPhone, partially offset by higher net sales of Services and Wearables, Home and Accessories. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on Greater China net sales during the third quarter and first nine months of 2020.

[0000320193-20-000062:mdna:43]
[same as prior period, unchanged from 0000320193-20-000052:mdna:43]

[0000320193-20-000062:mdna:44]
Japan net sales increased during the third quarter of 2020 compared to the third quarter of 2019 due primarily to higher net sales of Services, iPad and Mac. Year-over-year Japan net sales decreased during the first nine months of 2020 due primarily to lower net sales of iPhone, partially offset by higher net sales of Services and Wearables, Home and Accessories. The strength of the Japanese Yen relative to the U.S. dollar had a favorable impact on Japan net sales during the first nine months of 2020.

[0000320193-20-000062:mdna:45]
[same as prior period, unchanged from 0000320193-20-000052:mdna:45]

[0000320193-20-000062:mdna:46]
Rest of Asia Pacific net sales increased during the third quarter of 2020 compared to the third quarter of 2019 due primarily to higher net sales of iPhone, iPad and Mac. Year-over-year Rest of Asia Pacific net sales increased during the first nine months of 2020 due primarily to higher net sales of Wearables, Home and Accessories, iPhone and Services. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on Rest of Asia Pacific net sales during the third quarter and first nine months of 2020.

[0000320193-20-000062:mdna:47]
[same as prior period, unchanged from 0000320193-20-000052:mdna:47]

[0000320193-20-000062:mdna:48]
Products and Services gross margin and gross margin percentage for the three- and nine-month periods ended June 27, 2020 and June 29, 2019 were as follows (dollars in millions):

[0000320193-20-000062:mdna:49]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | June 27,2020 |  | June 29,2019 |  | June 27,2020 |  | June 29,2019 |
| Gross margin: |  |  |  |  |  |  |  |
| Products | $ | 13,836 |  |  | $ | 12,881 |  |  | $ | 54,509 |  |  | $ | 52,596 |  |
| Services | 8,844 |  |  | 7,346 |  |  | 25,758 |  |  | 21,483 |  |
| Total gross margin | $ | 22,680 |  |  | $ | 20,227 |  |  | $ | 80,267 |  |  | $ | 74,079 |  |

[0000320193-20-000062:mdna:50]
| Gross margin percentage: |  |  |  |  |  |  |  |
| Products | 29.7 | % |  | 30.4 | % |  | 32.0 | % |  | 32.4 | % |
| Services | 67.2 | % |  | 64.1 | % |  | 65.7 | % |  | 63.6 | % |
| Total gross margin percentage | 38.0 | % |  | 37.6 | % |  | 38.3 | % |  | 37.8 | % |

[0000320193-20-000062:mdna:51]
[same as prior period, unchanged from 0000320193-20-000052:mdna:50]

[0000320193-20-000062:mdna:52]
Products gross margin increased during the third quarter of 2020 compared to the third quarter of 2019 due primarily to higher Products volume and material cost savings, partially offset by a different Products mix and the weakness in foreign currencies relative to the U.S. dollar. Year-over-year Products gross margin percentage decreased during the third quarter of 2020 due primarily to a different Products mix and the weakness in foreign currencies relative to the U.S. dollar, partially offset by material cost savings and higher leverage.

[0000320193-20-000062:mdna:53]
Products gross margin increased during the first nine months of 2020 compared to the same period in 2019 due primarily to higher Products volume, partially offset by the weakness in foreign currencies relative to the U.S. dollar. Year-over-year Products gross margin percentage decreased during the first nine months of 2020 due primarily to the weakness in foreign currencies relative to the U.S. dollar and a different Products mix, partially offset by higher leverage.

[0000320193-20-000062:mdna:54]
[same as prior period, unchanged from 0000320193-20-000052:mdna:53]

[0000320193-20-000062:mdna:55]
Services gross margin increased during the third quarter and first nine months of 2020 compared to the same periods in 2019 due primarily to higher Services net sales. Services gross margin percentage increased during the third quarter and first nine months of 2020 compared to the same periods in 2019 due primarily to a different Services mix and higher leverage, partially offset by higher Services costs.

[0000320193-20-000062:mdna:56]
[same as prior period, unchanged from 0000320193-20-000052:mdna:55]

[0000320193-20-000062:mdna:57]
[same as prior period, unchanged from 0000320193-20-000052:mdna:56]

[0000320193-20-000062:mdna:58]
Operating expenses for the three- and nine-month periods ended June 27, 2020 and June 29, 2019 were as follows (dollars in millions):

[0000320193-20-000062:mdna:59]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | June 27,2020 |  | June 29,2019 |  | June 27,2020 |  | June 29,2019 |
| Research and development | $ | 4,758 |  |  | $ | 4,257 |  |  | $ | 13,774 |  |  | $ | 12,107 |  |
| Percentage of total net sales | 8 | % |  | 8 | % |  | 7 | % |  | 6 | % |
| Selling, general and administrative | $ | 4,831 |  |  | $ | 4,426 |  |  | $ | 14,980 |  |  | $ | 13,667 |  |
| Percentage of total net sales | 8 | % |  | 8 | % |  | 7 | % |  | 7 | % |
| Total operating expenses | $ | 9,589 |  |  | $ | 8,683 |  |  | $ | 28,754 |  |  | $ | 25,774 |  |
| Percentage of total net sales | 16 | % |  | 16 | % |  | 14 | % |  | 13 | % |

[0000320193-20-000062:mdna:60]
[same as prior period, unchanged from 0000320193-20-000052:mdna:59]

[0000320193-20-000062:mdna:61]
The growth in research and development (“R&D”) expense during the third quarter and first nine months of 2020 compared to the same periods in 2019 was driven primarily by increases in headcount-related expenses. The Company continues to believe that focused investments in R&D are critical to its future growth and competitive position in the marketplace, and to the development of new and updated products and services that are central to the Company’s core business strategy.

[0000320193-20-000062:mdna:62]
[same as prior period, unchanged from 0000320193-20-000052:mdna:61]

[0000320193-20-000062:mdna:63]
The growth in selling, general and administrative expense during the third quarter and first nine months of 2020 compared to the same periods in 2019 was driven primarily by increases in headcount-related expenses, higher spending on marketing and advertising and higher variable selling expenses.

[0000320193-20-000062:mdna:64]
[same as prior period, unchanged from 0000320193-20-000052:mdna:63]

[0000320193-20-000062:mdna:65]
Other income/(expense), net (“OI&E”) for the three- and nine-month periods ended June 27, 2020 and June 29, 2019 was as follows (dollars in millions):

[0000320193-20-000062:mdna:66]
|  | Three Months Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | June 27,2020 |  | June 29,2019 |  | Change |  | June 27,2020 |  | June 29,2019 |  | Change |
| Interest and dividend income | $ | 901 |  |  | $ | 1,190 |  |  |  |  | $ | 2,995 |  |  | $ | 3,855 |  |  |  |
| Interest expense | (697) |  |  | (866) |  |  |  |  | (2,239) |  |  | (2,766) |  |  |  |
| Other income/(expense), net | (158) |  |  | 43 |  |  |  |  | (79) |  |  | 216 |  |  |  |
| Total other income/(expense), net | $ | 46 |  |  | $ | 367 |  |  | (87) | % |  | $ | 677 |  |  | $ | 1,305 |  |  | (48) | % |

[0000320193-20-000062:mdna:67]
OI&E decreased during the third quarter and first nine months of 2020 compared to the same periods in 2019 due primarily to lower interest income and impairments on non-marketable securities, partially offset by lower interest expense. The weighted-average interest rate earned by the Company on its cash, cash equivalents and marketable securities was 1.74% and 2.17% in the third quarter of 2020 and 2019, respectively, and 1.95% and 2.21% in the first nine months of 2020 and 2019, respectively.

[0000320193-20-000062:mdna:68]
[same as prior period, unchanged from 0000320193-20-000052:mdna:67]

[0000320193-20-000062:mdna:69]
Provision for income taxes, effective tax rate and statutory federal income tax rate for the three- and nine-month periods ended June 27, 2020 and June 29, 2019 were as follows (dollars in millions):

[0000320193-20-000062:mdna:70]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | June 27,2020 |  | June 29,2019 |  | June 27,2020 |  | June 29,2019 |
| Provision for income taxes | $ | 1,884 |  |  | $ | 1,867 |  |  | $ | 7,452 |  |  | $ | 8,040 |  |
| Effective tax rate | 14.3 | % |  | 15.7 | % |  | 14.3 | % |  | 16.2 | % |
| Statutory federal income tax rate | 21 | % |  | 21 | % |  | 21 | % |  | 21 | % |

[0000320193-20-000062:mdna:71]
The Company’s effective tax rate for the third quarter and first nine months of 2020 was lower than the statutory federal income tax rate due primarily to lower taxes on foreign earnings, including the impact of tax settlements, and tax benefits from share-based compensation.

[0000320193-20-000062:mdna:72]
The Company’s effective tax rate for the third quarter of 2020 was lower compared to the third quarter of 2019 due primarily to higher tax benefits from share-based compensation. The Company’s effective tax rate for the first nine months of 2020 was lower compared to the same period in 2019 due primarily to the one-time adjustment of U.S. foreign tax credits in response to regulations issued by the U.S. Department of the Treasury in December 2019 and lower taxes on foreign earnings, including the impact of tax settlements.

[0000320193-20-000062:mdna:73]
[same as prior period, unchanged from 0000320193-20-000052:mdna:72]

[0000320193-20-000062:mdna:74]
[same as prior period, unchanged from 0000320193-20-000052:mdna:73]

[0000320193-20-000062:mdna:75]
In June 2016, the Financial Accounting Standards Board issued Accounting Standards Update No. 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (“ASU 2016-13”), which modifies the measurement of expected credit losses on certain financial instruments. The Company will adopt ASU 2016-13 in its first quarter of 2021 utilizing the modified retrospective transition method. Based on the composition of the Company’s investment portfolio, current market conditions, and historical credit loss activity, the adoption of ASU 2016-13 is not expected to have a material impact on its consolidated financial statements.

[0000320193-20-000062:mdna:76]
[same as prior period, unchanged from 0000320193-20-000052:mdna:75]

[0000320193-20-000062:mdna:77]
The following tables present selected financial information and statistics as of June 27, 2020 and September 28, 2019 and for the first nine months of 2020 and 2019 (in millions):

[0000320193-20-000062:mdna:78]
|  | June 27,2020 |  | September 28,2019 |
| Cash, cash equivalents and marketable securities (1) | $ | 193,617 |  |  | $ | 205,898 |  |
| Property, plant and equipment, net | $ | 35,687 |  |  | $ | 37,378 |  |
| Commercial paper and repurchase agreements | $ | 11,166 |  |  | $ | 5,980 |  |
| Total term debt | $ | 101,557 |  |  | $ | 102,067 |  |
| Working capital | $ | 44,747 |  |  | $ | 57,101 |  |

[0000320193-20-000062:mdna:79]
|  | Nine Months Ended |  |  |
|  | June 27,2020 |  | June 29,2019 |
| Cash generated by operating activities | $ | 60,098 |  |  | $ | 49,481 |  |
| Cash generated by/(used in) investing activities | $ | (9,820) |  |  | $ | 46,694 |  |
| Cash used in financing activities | $ | (65,463) |  |  | $ | (69,937) |  |

[0000320193-20-000062:mdna:80]
(1)As of June 27, 2020 and September 28, 2019, total marketable securities included $18.3 billion and $18.9 billion, respectively, that was restricted from general use, related to the State Aid Decision (refer to Note 5, “Income Taxes” in the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Form 10-Q) and other agreements. Additionally, as of June 27, 2020, $5.3 billion of marketable securities were pledged as collateral under repurchase agreements (refer to Note 6, “Debt” in the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Form 10-Q).

[0000320193-20-000062:mdna:81]
[same as prior period, unchanged from 0000320193-20-000052:mdna:80]

[0000320193-20-000062:mdna:82]
In connection with the State Aid Decision, as of June 27, 2020, the adjusted recovery amount of €12.9 billion plus interest of €1.2 billion was funded into escrow, where it will remain restricted from general use pending the conclusion of all legal proceedings.

[0000320193-20-000062:mdna:83]
[same as prior period, unchanged from 0000320193-20-000052:mdna:82]

[0000320193-20-000062:mdna:84]
During the nine months ended June 27, 2020, cash generated by operating activities of $60.1 billion was a result of $44.7 billion of net income, non-cash adjustments to net income of $13.5 billion and an increase in the net change in operating assets and liabilities of $1.8 billion. Cash used in investing activities of $9.8 billion during the nine months ended June 27, 2020 consisted primarily of cash used for purchases of marketable securities, net of maturities and sales, of $2.0 billion and cash used to acquire property, plant and equipment of $5.5 billion. Cash used in financing activities of $65.5 billion during the nine months ended June 27, 2020 consisted primarily of cash used to repurchase common stock of $55.2 billion, cash used to pay dividends and dividend equivalents of $10.6 billion and cash used to repay or redeem term debt of $12.6 billion, partially offset by net proceeds from the issuance of term debt of $10.6 billion and proceeds from repurchase agreements of $5.2 billion.

[0000320193-20-000062:mdna:85]
During the nine months ended June 29, 2019, cash generated by operating activities of $49.5 billion was a result of $41.6 billion of net income and non-cash adjustments to net income of $13.6 billion, partially offset by a decrease in the net change in operating assets and liabilities of $5.6 billion. Cash generated by investing activities of $46.7 billion during the nine months ended June 29, 2019 consisted primarily of proceeds from sales and maturities of marketable securities, net of purchases, of $54.4 billion, partially offset by cash used to acquire property, plant and equipment of $7.7 billion. Cash used in financing activities of $69.9 billion during the nine months ended June 29, 2019 consisted primarily of cash used to repurchase common stock of $49.5 billion, cash used to pay dividends and dividend equivalents of $10.6 billion and cash used to repay term debt of $5.5 billion.

[0000320193-20-000062:mdna:86]
[same as prior period, unchanged from 0000320193-20-000052:mdna:85]

[0000320193-20-000062:mdna:87]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses the net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of June 27, 2020, the Company had $6.0 billion of Commercial Paper outstanding, with a weighted-average interest rate of 0.77% and maturities generally less than nine months.

[0000320193-20-000062:mdna:88]
In 2020, the Company entered into agreements to sell certain of its marketable securities with a promise to repurchase the securities at a specified time and amount (“Repos”). Due to the Company’s continuing involvement with the marketable securities, the Company accounts for its Repos as collateralized borrowings. As of June 27, 2020, the Company had $5.2 billion of Repo liabilities outstanding with maturities of less than three months, and had pledged $5.3 billion of marketable securities as collateral.

[0000320193-20-000062:mdna:89]
As of June 27, 2020, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $100.1 billion (collectively the “Notes”). During the first nine months of 2020, the Company issued $10.6 billion and repaid or redeemed $12.6 billion of Notes. The Company has entered, and in the future may enter, into interest rate swaps to manage interest rate risk on the Notes. In addition, the Company has entered, and in the future may enter, into foreign currency swaps to manage foreign currency risk on the Notes.

[0000320193-20-000062:mdna:90]
[same as prior period, unchanged from 0000320193-20-000052:mdna:89]

[0000320193-20-000062:mdna:91]
[same as prior period, unchanged from 0000320193-20-000052:mdna:90]

[0000320193-20-000062:mdna:92]
As of June 27, 2020, the Company was authorized to purchase up to $225 billion of the Company’s common stock under a share repurchase program, of which $150.6 billion had been utilized. During the nine months ended June 27, 2020, the Company repurchased 186.4 million shares of its common stock for $54.5 billion, including 35.2 million shares delivered under a $10.0 billion November 2019 accelerated share repurchase arrangement (“ASR”) and 15.2 million shares initially delivered under a $6.0 billion May 2020 ASR. The Company’s share repurchase program does not obligate it to acquire any specific number of shares. Under this program, shares may be repurchased in privately negotiated and/or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).

[0000320193-20-000062:mdna:93]
As of June 27, 2020, the Company’s quarterly cash dividend was $0.82 per share. The Company intends to increase its dividend on an annual basis, subject to declaration by the Board of Directors.

[0000320193-20-000062:mdna:94]
Common Stock Split

[0000320193-20-000062:mdna:95]
On July 30, 2020, the Company announced a four-for-one split of its common stock to shareholders of record as of the close of business on August 24, 2020. Trading of the Company’s common stock will begin on a split-adjusted basis on August 31, 2020.

[0000320193-20-000062:mdna:96]
[same as prior period, unchanged from 0000320193-20-000052:mdna:93]

[0000320193-20-000062:mdna:97]
[same as prior period, unchanged from 0000320193-20-000052:mdna:94]

[0000320193-20-000062:mdna:98]
As of June 27, 2020, the Company’s total fixed lease payment obligations were $12.8 billion, of which $8.1 billion was included in other non-current liabilities in the Company’s Condensed Consolidated Balance Sheet. The Company’s leases typically have original terms not exceeding 10 years and generally contain multi-year renewal options.

[0000320193-20-000062:mdna:99]
[same as prior period, unchanged from 0000320193-20-000052:mdna:96]

[0000320193-20-000062:mdna:100]
The Company utilizes several outsourcing partners to manufacture sub-assemblies for the Company’s products and to perform final assembly and testing of finished products. These outsourcing partners acquire components and build product based on demand information supplied by the Company, which typically covers periods up to 150 days. The Company also obtains individual components for its products from a wide variety of individual suppliers. As of June 27, 2020, the Company expects to pay $30.3 billion under manufacturing-related supplier arrangements, which are primarily noncancelable.

[0000320193-20-000062:mdna:101]
[same as prior period, unchanged from 0000320193-20-000052:mdna:98]

[0000320193-20-000062:mdna:102]
The Company’s other purchase obligations consist of noncancelable obligations to acquire capital assets, including product tooling and manufacturing process equipment, and noncancelable obligations related to advertising, licensing, R&D, Internet and telecommunications services, content creation and other activities. As of June 27, 2020, the Company had other purchase obligations of $10.0 billion.

[0000320193-20-000062:mdna:103]
[same as prior period, unchanged from 0000320193-20-000052:mdna:100]

[0000320193-20-000062:mdna:104]
As of June 27, 2020, the balance of the deemed repatriation tax payable imposed by the U.S. Tax Cuts and Jobs Act (the “Act”) was $28.1 billion, and was included in other non-current liabilities in the Company’s Condensed Consolidated Balance Sheet. The Company plans to pay the deemed repatriation tax payable in installments in accordance with the Act.

[0000320193-20-000062:mdna:105]
[same as prior period, unchanged from 0000320193-20-000052:mdna:102]

[0000320193-20-000062:mdna:106]
[same as prior period, unchanged from 0000320193-20-000052:mdna:103]

[0000320193-20-000062:mdna:107]
[same as prior period, unchanged from 0000320193-20-000052:mdna:104]

[0000320193-20-000062:mdna:108]
[same as prior period, unchanged from 0000320193-20-000052:mdna:105]

[0000320193-20-000062:mdna:109]
[same as prior period, unchanged from 0000320193-20-000052:mdna:106]
