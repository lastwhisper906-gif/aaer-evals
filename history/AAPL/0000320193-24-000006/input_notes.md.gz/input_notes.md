# AAPL notes — 0000320193-24-000006


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000320193-24-000006:notes:1]
[same as prior period, unchanged from 0000320193-23-000077:notes:1]

[0000320193-24-000006:notes:2]
The condensed consolidated financial statements include the accounts of Apple Inc. and its wholly owned subsidiaries (collectively “Apple” or the “Company”). In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements and accompanying notes in conformity with U.S. generally accepted accounting principles (“GAAP”) requires the use of management estimates. Certain prior period amounts in the condensed consolidated financial statements and accompanying notes have been reclassified to conform to the current period’s presentation. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company’s annual consolidated financial statements and accompanying notes included in its Annual Report on Form 10-K for the fiscal year ended September 30, 2023 (the “2023 Form 10-K”).

[0000320193-24-000006:notes:3]
The Company’s fiscal year is the 52- or 53-week period that ends on the last Saturday of September. An additional week is included in the first fiscal quarter every five or six years to realign the Company’s fiscal quarters with calendar quarters, which occurred in the first fiscal quarter of 2023. The Company’s fiscal years 2024 and 2023 span 52 and 53 weeks, respectively. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in September and the associated quarters, months and periods of those fiscal years.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000320193-24-000006:notes:4]
Revenue
Net sales disaggregated by significant products and services for the three months ended December 30, 2023 and December 31, 2022 were as follows (in millions):

[0000320193-24-000006:notes:5]
|  | Three Months Ended |  |  |
|  | December 30,2023 |  | December 31,2022 |  |  |  |  |
| iPhone® | $ | 69,702 |  |  | $ | 65,775 |  |  |  |  |  |
| Mac® | 7,780 |  |  | 7,735 |  |  |  |  |  |
| iPad® | 7,023 |  |  | 9,396 |  |  |  |  |  |
| Wearables, Home and Accessories | 11,953 |  |  | 13,482 |  |  |  |  |  |
| Services | 23,117 |  |  | 20,766 |  |  |  |  |  |
| Total net sales | $ | 119,575 |  |  | $ | 117,154 |  |  |  |  |  |

[0000320193-24-000006:notes:6]
Total net sales include $3.5 billion of revenue recognized in the three months ended December 30, 2023 that was included in deferred revenue as of September 30, 2023 and $3.4 billion of revenue recognized in the three months ended December 31, 2022 that was included in deferred revenue as of September 24, 2022.

[0000320193-24-000006:notes:7]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 10, “Segment Information and Geographic Data” for the three months ended December 30, 2023 and December 31, 2022, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.

[0000320193-24-000006:notes:8]
As of December 30, 2023 and September 30, 2023, the Company had total deferred revenue of $12.5 billion and $12.1 billion, respectively. As of December 30, 2023, the Company expects 66% of total deferred revenue to be realized in less than a year, 26% within one-to-two years, 7% within two-to-three years and 1% in greater than three years.


## us-gaap:EarningsPerShareTextBlock

[0000320193-24-000006:notes:9]
Earnings Per Share
The following table shows the computation of basic and diluted earnings per share for the three months ended December 30, 2023 and December 31, 2022 (net income in millions and shares in thousands):

[0000320193-24-000006:notes:10]
|  | Three Months Ended |  |  |
|  | December 30,2023 |  | December 31,2022 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 33,916 |  |  | $ | 29,998 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 15,509,763 |  |  | 15,892,723 |  |  |  |  |  |
| Effect of dilutive share-based awards | 66,878 |  |  | 62,995 |  |  |  |  |  |
| Weighted-average diluted shares | 15,576,641 |  |  | 15,955,718 |  |  |  |  |  |
| Basic earnings per share | $ | 2.19 |  |  | $ | 1.89 |  |  |  |  |  |
| Diluted earnings per share | $ | 2.18 |  |  | $ | 1.88 |  |  |  |  |  |

[0000320193-24-000006:notes:11]
Approximately 89 million restricted stock units (“RSUs”) were excluded from the computation of diluted earnings per share for the three months ended December 31, 2022 because their effect would have been antidilutive.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000320193-24-000006:notes:12]
[same as prior period, unchanged from 0000320193-23-000077:notes:13]

[0000320193-24-000006:notes:13]
The following tables show the Company’s cash, cash equivalents and marketable securities by significant investment category as of December 30, 2023 and September 30, 2023 (in millions):

[0000320193-24-000006:notes:14]
|  | December 30, 2023 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | CurrentMarketableSecurities |  | Non-CurrentMarketableSecurities |
| Cash | $ | 29,542 |  |  | $ | — |  |  | $ | — |  |  | $ | 29,542 |  |  | $ | 29,542 |  |  | $ | — |  |  | $ | — |  |
| Level 1: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 2,000 |  |  | — |  |  | — |  |  | 2,000 |  |  | 2,000 |  |  | — |  |  | — |  |
| Mutual funds | 448 |  |  | 35 |  |  | (11) |  |  | 472 |  |  | — |  |  | 472 |  |  | — |  |
| Subtotal | 2,448 |  |  | 35 |  |  | (11) |  |  | 2,472 |  |  | 2,000 |  |  | 472 |  |  | — |  |
| Level 2 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 24,041 |  |  | 12 |  |  | (920) |  |  | 23,133 |  |  | 7,303 |  |  | 4,858 |  |  | 10,972 |  |
| U.S. agency securities | 5,791 |  |  | — |  |  | (448) |  |  | 5,343 |  |  | 243 |  |  | 98 |  |  | 5,002 |  |
| Non-U.S. government securities | 17,326 |  |  | 54 |  |  | (675) |  |  | 16,705 |  |  | — |  |  | 11,175 |  |  | 5,530 |  |
| Certificates of deposit and time deposits | 1,448 |  |  | — |  |  | — |  |  | 1,448 |  |  | 1,119 |  |  | 329 |  |  | — |  |
| Commercial paper | 1,361 |  |  | — |  |  | — |  |  | 1,361 |  |  | 472 |  |  | 889 |  |  | — |  |
| Corporate debt securities | 75,360 |  |  | 112 |  |  | (3,964) |  |  | 71,508 |  |  | 81 |  |  | 13,909 |  |  | 57,518 |  |
| Municipal securities | 562 |  |  | — |  |  | (14) |  |  | 548 |  |  | — |  |  | 185 |  |  | 363 |  |
| Mortgage- and asset-backed securities | 22,369 |  |  | 53 |  |  | (1,907) |  |  | 20,515 |  |  | — |  |  | 425 |  |  | 20,090 |  |
| Subtotal | 148,258 |  |  | 231 |  |  | (7,928) |  |  | 140,561 |  |  | 9,218 |  |  | 31,868 |  |  | 99,475 |  |
| Total (2) | $ | 180,248 |  |  | $ | 266 |  |  | $ | (7,939) |  |  | $ | 172,575 |  |  | $ | 40,760 |  |  | $ | 32,340 |  |  | $ | 99,475 |  |

[0000320193-24-000006:notes:15]
|  | September 30, 2023 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | CurrentMarketableSecurities |  | Non-CurrentMarketableSecurities |
| Cash | $ | 28,359 |  |  | $ | — |  |  | $ | — |  |  | $ | 28,359 |  |  | $ | 28,359 |  |  | $ | — |  |  | $ | — |  |
| Level 1: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 481 |  |  | — |  |  | — |  |  | 481 |  |  | 481 |  |  | — |  |  | — |  |
| Mutual funds and equity securities | 442 |  |  | 12 |  |  | (26) |  |  | 428 |  |  | — |  |  | 428 |  |  | — |  |
| Subtotal | 923 |  |  | 12 |  |  | (26) |  |  | 909 |  |  | 481 |  |  | 428 |  |  | — |  |
| Level 2 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 19,406 |  |  | — |  |  | (1,292) |  |  | 18,114 |  |  | 35 |  |  | 5,468 |  |  | 12,611 |  |
| U.S. agency securities | 5,736 |  |  | — |  |  | (600) |  |  | 5,136 |  |  | 36 |  |  | 271 |  |  | 4,829 |  |
| Non-U.S. government securities | 17,533 |  |  | 6 |  |  | (1,048) |  |  | 16,491 |  |  | — |  |  | 11,332 |  |  | 5,159 |  |
| Certificates of deposit and time deposits | 1,354 |  |  | — |  |  | — |  |  | 1,354 |  |  | 1,034 |  |  | 320 |  |  | — |  |
| Commercial paper | 608 |  |  | — |  |  | — |  |  | 608 |  |  | — |  |  | 608 |  |  | — |  |
| Corporate debt securities | 76,840 |  |  | 6 |  |  | (5,956) |  |  | 70,890 |  |  | 20 |  |  | 12,627 |  |  | 58,243 |  |
| Municipal securities | 628 |  |  | — |  |  | (26) |  |  | 602 |  |  | — |  |  | 192 |  |  | 410 |  |
| Mortgage- and asset-backed securities | 22,365 |  |  | 6 |  |  | (2,735) |  |  | 19,636 |  |  | — |  |  | 344 |  |  | 19,292 |  |
| Subtotal | 144,470 |  |  | 18 |  |  | (11,657) |  |  | 132,831 |  |  | 1,125 |  |  | 31,162 |  |  | 100,544 |  |
| Total (2) | $ | 173,752 |  |  | $ | 30 |  |  | $ | (11,683) |  |  | $ | 162,099 |  |  | $ | 29,965 |  |  | $ | 31,590 |  |  | $ | 100,544 |  |

[0000320193-24-000006:notes:16]
(1)The valuation techniques used to measure the fair values of the Company’s Level 2 financial instruments, which generally have counterparties with high credit ratings, are based on quoted market prices or model-driven valuations using significant inputs derived from or corroborated by observable market data.

[0000320193-24-000006:notes:17]
(2)As of December 30, 2023 and September 30, 2023, total marketable securities included $13.9 billion and $13.8 billion, respectively, that were restricted from general use, related to the European Commission decision finding that Ireland granted state aid to the Company, and other agreements.

[0000320193-24-000006:notes:18]
The following table shows the fair value of the Company’s non-current marketable debt securities, by contractual maturity, as of December 30, 2023 (in millions):

[0000320193-24-000006:notes:19]
| Due after 1 year through 5 years | $ | 72,994 |  |
| Due after 5 years through 10 years | 9,368 |  |
| Due after 10 years | 17,113 |  |
| Total fair value | $ | 99,475 |  |

[0000320193-24-000006:notes:20]
[same as prior period, unchanged from 0000320193-23-000077:notes:22]

[0000320193-24-000006:notes:21]
[same as prior period, unchanged from 0000320193-23-000077:notes:23]

[0000320193-24-000006:notes:22]
Foreign Exchange Rate Risk

[0000320193-24-000006:notes:23]
To protect gross margins from fluctuations in foreign exchange rates, the Company may use forwards, options or other instruments, and may designate these instruments as cash flow hedges. The Company generally hedges portions of its forecasted foreign currency exposure associated with revenue and inventory purchases, typically for up to 12 months.

[0000320193-24-000006:notes:24]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in foreign exchange rates, the Company may use forwards, cross-currency swaps or other instruments. The Company designates these instruments as either cash flow or fair value hedges. As of December 30, 2023, the maximum length of time over which the Company is hedging its exposure to the variability in future cash flows for term debt–related foreign currency transactions is 19 years.

[0000320193-24-000006:notes:25]
The Company may also use derivative instruments that are not designated as accounting hedges to protect gross margins from certain fluctuations in foreign exchange rates, as well as to offset a portion of the foreign currency gains and losses generated by the remeasurement of certain assets and liabilities denominated in non-functional currencies.

[0000320193-24-000006:notes:26]
[same as prior period, unchanged from 0000320193-23-000077:notes:28]

[0000320193-24-000006:notes:27]
To protect the Company’s term debt or marketable securities from fluctuations in interest rates, the Company may use interest rate swaps, options or other instruments. The Company designates these instruments as either cash flow or fair value hedges.

[0000320193-24-000006:notes:28]
The notional amounts of the Company’s outstanding derivative instruments as of December 30, 2023 and September 30, 2023 were as follows (in millions):

[0000320193-24-000006:notes:29]
|  | December 30,2023 |  | September 30,2023 |
| Derivative instruments designated as accounting hedges: |  |  |  |
| Foreign exchange contracts | $ | 66,735 |  |  | $ | 74,730 |  |
| Interest rate contracts | $ | 19,375 |  |  | $ | 19,375 |  |
| Derivative instruments not designated as accounting hedges: |  |  |  |
| Foreign exchange contracts | $ | 102,108 |  |  | $ | 104,777 |  |

[0000320193-24-000006:notes:30]
The carrying amounts of the Company’s hedged items in fair value hedges as of December 30, 2023 and September 30, 2023 were as follows (in millions):

[0000320193-24-000006:notes:31]
|  | December 30,2023 |  | September 30,2023 |
| Hedged assets/(liabilities): |  |  |  |
| Current and non-current marketable securities | $ | 15,102 |  |  | $ | 14,433 |  |
| Current and non-current term debt | $ | (18,661) |  |  | $ | (18,247) |  |

[0000320193-24-000006:notes:32]
[same as prior period, unchanged from 0000320193-23-000077:notes:39]

[0000320193-24-000006:notes:33]
[same as prior period, unchanged from 0000320193-23-000077:notes:40]

[0000320193-24-000006:notes:34]
The Company’s third-party cellular network carriers accounted for 34% and 41% of total trade receivables as of December 30, 2023 and September 30, 2023, respectively. The Company requires third-party credit support or collateral from certain customers to limit credit risk.

[0000320193-24-000006:notes:35]
[same as prior period, unchanged from 0000320193-23-000077:notes:43]

[0000320193-24-000006:notes:36]
The Company has non-trade receivables from certain of its manufacturing vendors resulting from the sale of components to these vendors who manufacture subassemblies or assemble final products for the Company. The Company purchases these components directly from suppliers. The Company does not reflect the sale of these components in products net sales. Rather, the Company recognizes any gain on these sales as a reduction of products cost of sales when the related final products are sold by the Company. As of December 30, 2023, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 50% and 20%. As of September 30, 2023, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 48% and 23%.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000320193-24-000006:notes:37]
Condensed Consolidated Financial Statement Details
The following table shows the Company’s condensed consolidated financial statement details as of December 30, 2023 and September 30, 2023 (in millions):

[0000320193-24-000006:notes:38]
[same as prior period, unchanged from 0000320193-23-000077:notes:49]

[0000320193-24-000006:notes:39]
|  | December 30,2023 |  | September 30,2023 |
| Gross property, plant and equipment | $ | 116,176 |  |  | $ | 114,599 |  |
| Accumulated depreciation | (72,510) |  |  | (70,884) |  |
| Total property, plant and equipment, net | $ | 43,666 |  |  | $ | 43,715 |  |


## us-gaap:DebtDisclosureTextBlock

[0000320193-24-000006:notes:40]
Debt
Commercial Paper

[0000320193-24-000006:notes:41]
The Company issues unsecured short-term promissory notes pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of December 30, 2023 and September 30, 2023, the Company had $2.0 billion and $6.0 billion of commercial paper outstanding, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of commercial paper for the three months ended December 30, 2023 and December 31, 2022 (in millions):

[0000320193-24-000006:notes:42]
|  | Three Months Ended |
|  | December 30,2023 |  | December 31,2022 |
| Maturities 90 days or less: |  |  |  |
| Repayments of commercial paper, net | $ | (3,984) |  |  | $ | (5,569) |  |
| Maturities greater than 90 days: |  |  |  |
| Repayments of commercial paper | — |  |  | (2,645) |  |
| Total repayments of commercial paper, net | $ | (3,984) |  |  | $ | (8,214) |  |

[0000320193-24-000006:notes:43]
Term Debt

[0000320193-24-000006:notes:44]
As of December 30, 2023 and September 30, 2023, the Company had outstanding fixed-rate notes with varying maturities for an aggregate carrying amount of $106.0 billion and $105.1 billion, respectively (collectively the “Notes”). As of December 30, 2023 and September 30, 2023, the fair value of the Company’s Notes, based on Level 2 inputs, was $96.7 billion and $90.8 billion, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000320193-24-000006:notes:45]
[same as prior period, unchanged from 0000320193-23-000077:notes:61]

[0000320193-24-000006:notes:46]
During the three months ended December 30, 2023, the Company repurchased 118 million shares of its common stock for $20.5 billion. The Company’s share repurchase program does not obligate the Company to acquire a minimum amount of shares. Under the program, shares may be repurchased in privately negotiated or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000320193-24-000006:notes:47]
Share-Based Compensation
Restricted Stock Units

[0000320193-24-000006:notes:48]
A summary of the Company’s RSU activity and related information for the three months ended December 30, 2023 is as follows:

[0000320193-24-000006:notes:49]
|  | Number ofRSUs(in thousands) |  | Weighted-AverageGrant Date FairValue Per RSU |  | AggregateFair Value(in millions) |
| Balance as of September 30, 2023 | 180,247 |  |  | $ | 135.91 |  |  |  |
| RSUs granted | 74,241 |  |  | $ | 171.58 |  |  |  |
| RSUs vested | (42,490) |  |  | $ | 110.75 |  |  |  |
| RSUs canceled | (3,026) |  |  | $ | 109.05 |  |  |  |
| Balance as of December 30, 2023 | 208,972 |  |  | $ | 154.09 |  |  | $ | 40,233 |  |

[0000320193-24-000006:notes:50]
The fair value as of the respective vesting dates of RSUs was $7.7 billion and $6.8 billion for the three months ended December 30, 2023 and December 31, 2022, respectively.

[0000320193-24-000006:notes:51]
Share-Based Compensation

[0000320193-24-000006:notes:52]
The following table shows share-based compensation expense and the related income tax benefit included in the Condensed Consolidated Statements of Operations for the three months ended December 30, 2023 and December 31, 2022 (in millions):

[0000320193-24-000006:notes:53]
|  | Three Months Ended |  |  |
|  | December 30,2023 |  | December 31,2022 |  |  |  |  |
| Share-based compensation expense | $ | 2,997 |  |  | $ | 2,905 |  |  |  |  |  |
| Income tax benefit related to share-based compensation expense | $ | (1,235) |  |  | $ | (1,178) |  |  |  |  |  |

[0000320193-24-000006:notes:54]
As of December 30, 2023, the total unrecognized compensation cost related to outstanding RSUs was $27.4 billion, which the Company expects to recognize over a weighted-average period of 2.9 years.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000320193-24-000006:notes:55]
Segment Information and Geographic Data
The following table shows information by reportable segment for the three months ended December 30, 2023 and December 31, 2022 (in millions):

[0000320193-24-000006:notes:56]
|  | Three Months Ended |  |  |
|  | December 30,2023 |  | December 31,2022 |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |
| Net sales | $ | 50,430 |  |  | $ | 49,278 |  |  |  |  |  |
| Operating income | $ | 20,357 |  |  | $ | 17,864 |  |  |  |  |  |
| Europe: |  |  |  |  |  |  |  |
| Net sales | $ | 30,397 |  |  | $ | 27,681 |  |  |  |  |  |
| Operating income | $ | 12,711 |  |  | $ | 10,017 |  |  |  |  |  |
| Greater China: |  |  |  |  |  |  |  |
| Net sales | $ | 20,819 |  |  | $ | 23,905 |  |  |  |  |  |
| Operating income | $ | 8,622 |  |  | $ | 10,437 |  |  |  |  |  |
| Japan: |  |  |  |  |  |  |  |
| Net sales | $ | 7,767 |  |  | $ | 6,755 |  |  |  |  |  |
| Operating income | $ | 3,819 |  |  | $ | 3,236 |  |  |  |  |  |
| Rest of Asia Pacific: |  |  |  |  |  |  |  |
| Net sales | $ | 10,162 |  |  | $ | 9,535 |  |  |  |  |  |
| Operating income | $ | 4,579 |  |  | $ | 3,851 |  |  |  |  |  |

[0000320193-24-000006:notes:57]
A reconciliation of the Company’s segment operating income to the Condensed Consolidated Statements of Operations for the three months ended December 30, 2023 and December 31, 2022 is as follows (in millions):

[0000320193-24-000006:notes:58]
|  | Three Months Ended |  |  |
|  | December 30,2023 |  | December 31,2022 |  |  |  |  |
| Segment operating income | $ | 50,088 |  |  | $ | 45,405 |  |  |  |  |  |
| Research and development expense | (7,696) |  |  | (7,709) |  |  |  |  |  |
| Other corporate expenses, net | (2,019) |  |  | (1,680) |  |  |  |  |  |
| Total operating income | $ | 40,373 |  |  | $ | 36,016 |  |  |  |  |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0000320193-24-000006:notes:59]
On November 11, 2023 and November 27, 2023, respectively, Luca Maestri, the Company’s Senior Vice President and Chief Financial Officer, and Katherine L. Adams, the Company’s Senior Vice President and General Counsel, each entered into a trading plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act. The plans provide for the sale of all shares vested during the duration of the plans pursuant to certain equity awards granted to Mr. Maestri and Ms. Adams, respectively, excluding any shares withheld by the Company to satisfy income tax withholding and remittance obligations. Mr. Maestri’s plan will expire on December 31, 2024, and Ms. Adams’s plan will expire on November 1, 2024, subject to early termination for certain specified events set forth in the plans.
