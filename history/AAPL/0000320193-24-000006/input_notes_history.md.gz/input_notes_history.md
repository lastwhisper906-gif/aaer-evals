# AAPL note change history — 0000320193-23-000077 → 0000320193-24-000006


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: no_current_note, score: 0.0

- removed (2024-02-02):
[0000320193-23-000077:note_history:1]
Commitments and Contingencies
Unconditional Purchase Obligations

- removed (2024-02-02):
[0000320193-23-000077:note_history:2]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of supplier arrangements, licensed intellectual property and content, and distribution rights. Future payments under noncancelable unconditional purchase obligations with a remaining term in excess of one year as of July 1, 2023, are as follows (in millions):

- removed (2024-02-02):
[0000320193-23-000077:note_history:3]
| 2023 (remaining three months) | $ | 1,260 |  |
| 2024 | 3,417 |  |
| 2025 | 1,990 |  |
| 2026 | 3,079 |  |
| 2027 | 1,013 |  |
| Thereafter | 8,198 |  |
| Total | $ | 18,957 |  |

- removed (2024-02-02):
[0000320193-23-000077:note_history:4]
Contingencies

- removed (2024-02-02):
[0000320193-23-000077:note_history:5]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully resolved. The outcome of litigation is inherently uncertain. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss greater than a recorded accrual, concerning loss contingencies for asserted legal and other claims.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-02-02):
[0000320193-24-000006:note_history:6]
The condensed consolidated financial statements include the accounts of Apple Inc. and its wholly owned subsidiaries (collectively “Apple” or the “Company”). In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements and accompanying notes in conformity with U.S. generally accepted accounting principles (“GAAP”) requires the use of management estimates. Certain prior period amounts in the condensed consolidated financial statements and accompanying notes have been reclassified to conform to the current period’s presentation. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company’s annual consolidated financial statements and accompanying notes included in its Annual Report on Form 10-K for the fiscal year ended September 30, 2023 (the “2023 Form 10-K”).
  (was, 2023-08-04, similarity 0.8851):
[0000320193-23-000077:note_history:6]
The condensed consolidated financial statements include the accounts of Apple Inc. and its wholly owned subsidiaries (collectively “Apple” or the “Company”). Intercompany accounts and transactions have been eliminated. In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements and accompanying notes in conformity with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported. Actual results could differ materially from those estimates. Certain prior period amounts in the condensed consolidated financial statements and accompanying notes have been reclassified to conform to the current period’s presentation. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company’s annual consolidated financial statements and accompanying notes included in its Annual Report on Form 10-K for the fiscal year ended September 24, 2022.

- removed (2024-02-02):
[0000320193-23-000077:note_history:7]
Earnings Per Share

- removed (2024-02-02):
[0000320193-23-000077:note_history:8]
The following table shows the computation of basic and diluted earnings per share for the three- and nine-month periods ended July 1, 2023 and June 25, 2022 (net income in millions and shares in thousands):

- removed (2024-02-02):
[0000320193-23-000077:note_history:9]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1,2023 |  | June 25,2022 |  | July 1,2023 |  | June 25,2022 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 19,881 |  |  | $ | 19,442 |  |  | $ | 74,039 |  |  | $ | 79,082 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 15,697,614 |  |  | 16,162,945 |  |  | 15,792,497 |  |  | 16,277,824 |  |
| Effect of dilutive securities | 77,407 |  |  | 99,258 |  |  | 66,766 |  |  | 117,113 |  |
| Weighted-average diluted shares | 15,775,021 |  |  | 16,262,203 |  |  | 15,859,263 |  |  | 16,394,937 |  |
| Basic earnings per share | $ | 1.27 |  |  | $ | 1.20 |  |  | $ | 4.69 |  |  | $ | 4.86 |  |
| Diluted earnings per share | $ | 1.26 |  |  | $ | 1.20 |  |  | $ | 4.67 |  |  | $ | 4.82 |  |

- removed (2024-02-02):
[0000320193-23-000077:note_history:10]
Approximately 32 million restricted stock units (“RSUs”) were excluded from the computation of diluted earnings per share for the nine months ended July 1, 2023 because their effect would have been antidilutive.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-02-02):
[0000320193-24-000006:note_history:11]
The Company issues unsecured short-term promissory notes pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of December 30, 2023 and September 30, 2023, the Company had $2.0 billion and $6.0 billion of commercial paper outstanding, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of commercial paper for the three months ended December 30, 2023 and December 31, 2022 (in millions):
  (was, 2023-08-04, similarity 0.8989):
[0000320193-23-000077:note_history:11]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of July 1, 2023 and September 24, 2022, the Company had $4.0 billion and $10.0 billion of Commercial Paper outstanding, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the nine months ended July 1, 2023 and June 25, 2022 (in millions):

- added (2024-02-02):
[0000320193-24-000006:note_history:12]
|  | Three Months Ended |
|  | December 30,2023 |  | December 31,2022 |
| Maturities 90 days or less: |  |  |  |
| Repayments of commercial paper, net | $ | (3,984) |  |  | $ | (5,569) |  |
| Maturities greater than 90 days: |  |  |  |
| Repayments of commercial paper | — |  |  | (2,645) |  |
| Total repayments of commercial paper, net | $ | (3,984) |  |  | $ | (8,214) |  |

- changed (2024-02-02):
[0000320193-24-000006:note_history:13]
As of December 30, 2023 and September 30, 2023, the Company had outstanding fixed-rate notes with varying maturities for an aggregate carrying amount of $106.0 billion and $105.1 billion, respectively (collectively the “Notes”). As of December 30, 2023 and September 30, 2023, the fair value of the Company’s Notes, based on Level 2 inputs, was $96.7 billion and $90.8 billion, respectively.
  (was, 2023-08-04, similarity 0.9658):
[0000320193-23-000077:note_history:13]
As of July 1, 2023 and September 24, 2022, the Company had outstanding fixed-rate notes with varying maturities for an aggregate carrying amount of $105.3 billion and $110.1 billion, respectively (collectively the “Notes”). As of July 1, 2023 and September 24, 2022, the fair value of the Company’s Notes, based on Level 2 inputs, was $95.3 billion and $98.8 billion, respectively.

- removed (2024-02-02):
[0000320193-23-000077:note_history:14]
|  | Nine Months Ended |
|  | July 1,2023 |  | June 25,2022 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | (3,326) |  |  | $ | 4,383 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | — |  |  | 5,731 |  |
| Repayments of commercial paper | (2,645) |  |  | (5,144) |  |
| Proceeds from/(Repayments of) commercial paper, net | (2,645) |  |  | 587 |  |
| Total proceeds from/(repayments of) commercial paper, net | $ | (5,971) |  |  | $ | 4,970 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-02-02):
[0000320193-24-000006:note_history:15]
Net sales disaggregated by significant products and services for the three months ended December 30, 2023 and December 31, 2022 were as follows (in millions):
  (was, 2023-08-04, similarity 0.8721):
[0000320193-23-000077:note_history:15]
Net sales disaggregated by significant products and services for the three- and nine-month periods ended July 1, 2023 and June 25, 2022 were as follows (in millions):

- changed (2024-02-02):
[0000320193-24-000006:note_history:16]
|  | Three Months Ended |  |  |
|  | December 30,2023 |  | December 31,2022 |  |  |  |  |
| iPhone® | $ | 69,702 |  |  | $ | 65,775 |  |  |  |  |  |
| Mac® | 7,780 |  |  | 7,735 |  |  |  |  |  |
| iPad® | 7,023 |  |  | 9,396 |  |  |  |  |  |
| Wearables, Home and Accessories | 11,953 |  |  | 13,482 |  |  |  |  |  |
| Services | 23,117 |  |  | 20,766 |  |  |  |  |  |
| Total net sales | $ | 119,575 |  |  | $ | 117,154 |  |  |  |  |  |
  (was, 2023-08-04, similarity 0.7444):
[0000320193-23-000077:note_history:16]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1,2023 |  | June 25,2022 |  | July 1,2023 |  | June 25,2022 |
| iPhone® | $ | 39,669 |  |  | $ | 40,665 |  |  | $ | 156,778 |  |  | $ | 162,863 |  |
| Mac® | 6,840 |  |  | 7,382 |  |  | 21,743 |  |  | 28,669 |  |
| iPad® | 5,791 |  |  | 7,224 |  |  | 21,857 |  |  | 22,118 |  |
| Wearables, Home and Accessories | 8,284 |  |  | 8,084 |  |  | 30,523 |  |  | 31,591 |  |
| Services | 21,213 |  |  | 19,604 |  |  | 62,886 |  |  | 58,941 |  |
| Total net sales | $ | 81,797 |  |  | $ | 82,959 |  |  | $ | 293,787 |  |  | $ | 304,182 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-02-02):
[0000320193-24-000006:note_history:17]
Revenue
Net sales disaggregated by significant products and services for the three months ended December 30, 2023 and December 31, 2022 were as follows (in millions):
  (was, 2023-08-04, similarity 0.8785):
[0000320193-23-000077:note_history:17]
Revenue
Net sales disaggregated by significant products and services for the three- and nine-month periods ended July 1, 2023 and June 25, 2022 were as follows (in millions):

- changed (2024-02-02):
[0000320193-24-000006:note_history:18]
|  | Three Months Ended |  |  |
|  | December 30,2023 |  | December 31,2022 |  |  |  |  |
| iPhone® | $ | 69,702 |  |  | $ | 65,775 |  |  |  |  |  |
| Mac® | 7,780 |  |  | 7,735 |  |  |  |  |  |
| iPad® | 7,023 |  |  | 9,396 |  |  |  |  |  |
| Wearables, Home and Accessories | 11,953 |  |  | 13,482 |  |  |  |  |  |
| Services | 23,117 |  |  | 20,766 |  |  |  |  |  |
| Total net sales | $ | 119,575 |  |  | $ | 117,154 |  |  |  |  |  |
  (was, 2023-08-04, similarity 0.7444):
[0000320193-23-000077:note_history:18]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1,2023 |  | June 25,2022 |  | July 1,2023 |  | June 25,2022 |
| iPhone® | $ | 39,669 |  |  | $ | 40,665 |  |  | $ | 156,778 |  |  | $ | 162,863 |  |
| Mac® | 6,840 |  |  | 7,382 |  |  | 21,743 |  |  | 28,669 |  |
| iPad® | 5,791 |  |  | 7,224 |  |  | 21,857 |  |  | 22,118 |  |
| Wearables, Home and Accessories | 8,284 |  |  | 8,084 |  |  | 30,523 |  |  | 31,591 |  |
| Services | 21,213 |  |  | 19,604 |  |  | 62,886 |  |  | 58,941 |  |
| Total net sales | $ | 81,797 |  |  | $ | 82,959 |  |  | $ | 293,787 |  |  | $ | 304,182 |  |

- added (2024-02-02):
[0000320193-24-000006:note_history:19]
Total net sales include $3.5 billion of revenue recognized in the three months ended December 30, 2023 that was included in deferred revenue as of September 30, 2023 and $3.4 billion of revenue recognized in the three months ended December 31, 2022 that was included in deferred revenue as of September 24, 2022.

- changed (2024-02-02):
[0000320193-24-000006:note_history:20]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 10, “Segment Information and Geographic Data” for the three months ended December 30, 2023 and December 31, 2022, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.
  (was, 2023-08-04, similarity 0.8715):
[0000320193-23-000077:note_history:20]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 10, “Segment Information and Geographic Data” for the three- and nine-month periods ended July 1, 2023 and June 25, 2022, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.

- added (2024-02-02):
[0000320193-24-000006:note_history:21]
As of December 30, 2023 and September 30, 2023, the Company had total deferred revenue of $12.5 billion and $12.1 billion, respectively. As of December 30, 2023, the Company expects 66% of total deferred revenue to be realized in less than a year, 26% within one-to-two years, 7% within two-to-three years and 1% in greater than three years.

- removed (2024-02-02):
[0000320193-23-000077:note_history:22]
Total net sales include $3.3 billion of revenue recognized in the three months ended July 1, 2023 that was included in deferred revenue as of April 1, 2023, $3.1 billion of revenue recognized in the three months ended June 25, 2022 that was included in deferred revenue as of March 26, 2022, $7.0 billion of revenue recognized in the nine months ended July 1, 2023 that was included in deferred revenue as of September 24, 2022, and $6.3 billion of revenue recognized in the nine months ended June 25, 2022 that was included in deferred revenue as of September 25, 2021.

- removed (2024-02-02):
[0000320193-23-000077:note_history:23]
As of July 1, 2023 and September 24, 2022, the Company had total deferred revenue of $12.2 billion and $12.4 billion, respectively. As of July 1, 2023, the Company expects 67% of total deferred revenue to be realized in less than a year, 26% within one-to-two years, 6% within two-to-three years and 1% in greater than three years.
