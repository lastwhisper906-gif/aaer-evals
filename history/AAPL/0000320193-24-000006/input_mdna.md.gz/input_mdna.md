# AAPL MD&A — 0000320193-24-000006


## mdna

[0000320193-24-000006:mdna:1]
[same as prior period, unchanged from 0000320193-23-000077:mdna:1]

[0000320193-24-000006:mdna:2]
Unless otherwise stated, all information presented herein is based on the Company’s fiscal calendar, and references to particular years, quarters, months or periods refer to the Company’s fiscal years ended in September and the associated quarters, months and periods of those fiscal years.

[0000320193-24-000006:mdna:3]
The following discussion should be read in conjunction with the 2023 Form 10-K filed with the U.S. Securities and Exchange Commission (the “SEC”) and the condensed consolidated financial statements and accompanying notes included in Part I, Item 1 of this Form 10-Q.

[0000320193-24-000006:mdna:4]
[same as prior period, unchanged from 0000320193-23-000077:mdna:4]

[0000320193-24-000006:mdna:5]
[same as prior period, unchanged from 0000320193-23-000077:mdna:5]

[0000320193-24-000006:mdna:6]
[same as prior period, unchanged from 0000320193-23-000077:mdna:6]

[0000320193-24-000006:mdna:7]
[same as prior period, unchanged from 0000320193-23-000077:mdna:7]

[0000320193-24-000006:mdna:8]
[same as prior period, unchanged from 0000320193-23-000077:mdna:8]

[0000320193-24-000006:mdna:9]
The Company’s fiscal year is the 52- or 53-week period that ends on the last Saturday of September. An additional week is included in the first fiscal quarter every five or six years to realign the Company’s fiscal quarters with calendar quarters, which occurred in the first quarter of 2023. The Company’s fiscal years 2024 and 2023 span 52 and 53 weeks, respectively.

[0000320193-24-000006:mdna:10]
[same as prior period, unchanged from 0000320193-23-000077:mdna:10]

[0000320193-24-000006:mdna:11]
The Company’s first quarter of 2024 included 13 weeks, compared to 14 weeks during the first quarter of 2023.

[0000320193-24-000006:mdna:12]
The Company’s total net sales increased 2% or $2.4 billion during the first quarter of 2024 compared to the same quarter in 2023, driven primarily by higher net sales of iPhone and Services, partially offset by lower net sales of iPad and Wearables, Home and Accessories.

[0000320193-24-000006:mdna:13]
During the first quarter of 2024, the Company announced an updated MacBook Pro® 14-in., MacBook Pro 16-in. and iMac®.

[0000320193-24-000006:mdna:14]
The Company repurchased $20.5 billion of its common stock and paid dividends and dividend equivalents of $3.8 billion during the first quarter of 2024.

[0000320193-24-000006:mdna:15]
[same as prior period, unchanged from 0000320193-23-000077:mdna:19]

[0000320193-24-000006:mdna:16]
[same as prior period, unchanged from 0000320193-23-000077:mdna:20]

[0000320193-24-000006:mdna:17]
[same as prior period, unchanged from 0000320193-23-000077:mdna:21]

[0000320193-24-000006:mdna:18]
The following table shows net sales by reportable segment for the three months ended December 30, 2023 and December 31, 2022 (dollars in millions):

[0000320193-24-000006:mdna:19]
|  | Three Months Ended |  |  |
|  | December 30,2023 |  | December 31,2022 |  | Change |  |  |  |  |  |  |
| Net sales by reportable segment: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 50,430 |  |  | $ | 49,278 |  |  | 2 | % |  |  |  |  |  |  |
| Europe | 30,397 |  |  | 27,681 |  |  | 10 | % |  |  |  |  |  |  |
| Greater China | 20,819 |  |  | 23,905 |  |  | (13) | % |  |  |  |  |  |  |
| Japan | 7,767 |  |  | 6,755 |  |  | 15 | % |  |  |  |  |  |  |
| Rest of Asia Pacific | 10,162 |  |  | 9,535 |  |  | 7 | % |  |  |  |  |  |  |
| Total net sales | $ | 119,575 |  |  | $ | 117,154 |  |  | 2 | % |  |  |  |  |  |  |

[0000320193-24-000006:mdna:20]
[same as prior period, unchanged from 0000320193-23-000077:mdna:24]

[0000320193-24-000006:mdna:21]
Americas net sales increased 2% or $1.2 billion during the first quarter of 2024 compared to the same quarter in 2023 due primarily to higher net sales of Services and iPhone, partially offset by lower net sales of iPad. The strength in foreign currencies relative to the U.S. dollar had a net favorable year-over-year impact on Americas net sales during the first quarter of 2024.

[0000320193-24-000006:mdna:22]
[same as prior period, unchanged from 0000320193-23-000077:mdna:26]

[0000320193-24-000006:mdna:23]
Europe net sales increased 10% or $2.7 billion during the first quarter of 2024 compared to the same quarter in 2023 due primarily to higher net sales of iPhone. The strength in foreign currencies relative to the U.S. dollar had a net favorable year-over-year impact on Europe net sales during the first quarter of 2024.

[0000320193-24-000006:mdna:24]
[same as prior period, unchanged from 0000320193-23-000077:mdna:28]

[0000320193-24-000006:mdna:25]
Greater China net sales decreased 13% or $3.1 billion during the first quarter of 2024 compared to the same quarter in 2023 due primarily to lower net sales of iPhone, iPad and Wearables, Home and Accessories. The weakness in the renminbi relative to the U.S. dollar had an unfavorable year-over-year impact on Greater China net sales during the first quarter of 2024.

[0000320193-24-000006:mdna:26]
[same as prior period, unchanged from 0000320193-23-000077:mdna:30]

[0000320193-24-000006:mdna:27]
Japan net sales increased 15% or $1.0 billion during the first quarter of 2024 compared to the same quarter in 2023 due primarily to higher net sales of iPhone. The weakness in the yen relative to the U.S. dollar had an unfavorable year-over-year impact on Japan net sales during the first quarter of 2024.

[0000320193-24-000006:mdna:28]
[same as prior period, unchanged from 0000320193-23-000077:mdna:32]

[0000320193-24-000006:mdna:29]
Rest of Asia Pacific net sales increased 7% or $627 million during the first quarter of 2024 compared to the same quarter in 2023 due primarily to higher net sales of iPhone, partially offset by lower net sales of Wearables, Home and Accessories.

[0000320193-24-000006:mdna:30]
[same as prior period, unchanged from 0000320193-23-000077:mdna:34]

[0000320193-24-000006:mdna:31]
The following table shows net sales by category for the three months ended December 30, 2023 and December 31, 2022 (dollars in millions):

[0000320193-24-000006:mdna:32]
|  | Three Months Ended |  |  |
|  | December 30,2023 |  | December 31,2022 |  | Change |  |  |  |  |  |  |
| Net sales by category: |  |  |  |  |  |  |  |  |  |  |  |
| iPhone | $ | 69,702 |  |  | $ | 65,775 |  |  | 6 | % |  |  |  |  |  |  |
| Mac | 7,780 |  |  | 7,735 |  |  | 1 | % |  |  |  |  |  |  |
| iPad | 7,023 |  |  | 9,396 |  |  | (25) | % |  |  |  |  |  |  |
| Wearables, Home and Accessories | 11,953 |  |  | 13,482 |  |  | (11) | % |  |  |  |  |  |  |
| Services | 23,117 |  |  | 20,766 |  |  | 11 | % |  |  |  |  |  |  |
| Total net sales | $ | 119,575 |  |  | $ | 117,154 |  |  | 2 | % |  |  |  |  |  |  |

[0000320193-24-000006:mdna:33]
[same as prior period, unchanged from 0000320193-23-000077:mdna:37]

[0000320193-24-000006:mdna:34]
iPhone net sales increased 6% or $3.9 billion during the first quarter of 2024 compared to the same quarter in 2023 due primarily to higher net sales of Pro models, partially offset by lower net sales of other models.

[0000320193-24-000006:mdna:35]
[same as prior period, unchanged from 0000320193-23-000077:mdna:39]

[0000320193-24-000006:mdna:36]
Mac net sales were relatively flat during the first quarter of 2024 compared to the same quarter in 2023.

[0000320193-24-000006:mdna:37]
[same as prior period, unchanged from 0000320193-23-000077:mdna:41]

[0000320193-24-000006:mdna:38]
iPad net sales decreased 25% or $2.4 billion during the first quarter of 2024 compared to the same quarter in 2023 due primarily to lower net sales of iPad Pro, iPad 9th generation and iPad Air.

[0000320193-24-000006:mdna:39]
[same as prior period, unchanged from 0000320193-23-000077:mdna:43]

[0000320193-24-000006:mdna:40]
Wearables, Home and Accessories net sales decreased 11% or $1.5 billion during the first quarter of 2024 compared to the same quarter in 2023 due primarily to lower net sales of Wearables and Accessories.

[0000320193-24-000006:mdna:41]
[same as prior period, unchanged from 0000320193-23-000077:mdna:45]

[0000320193-24-000006:mdna:42]
Services net sales increased 11% or $2.4 billion during the first quarter of 2024 compared to the same quarter in 2023 due primarily to higher net sales from advertising, video and cloud services.

[0000320193-24-000006:mdna:43]
[same as prior period, unchanged from 0000320193-23-000077:mdna:47]

[0000320193-24-000006:mdna:44]
Products and Services gross margin and gross margin percentage for the three months ended December 30, 2023 and December 31, 2022 were as follows (dollars in millions):

[0000320193-24-000006:mdna:45]
|  | Three Months Ended |  |  |
|  | December 30,2023 |  | December 31,2022 |  |  |  |  |
| Gross margin: |  |  |  |  |  |  |  |
| Products | $ | 38,018 |  |  | $ | 35,623 |  |  |  |  |  |
| Services | 16,837 |  |  | 14,709 |  |  |  |  |  |
| Total gross margin | $ | 54,855 |  |  | $ | 50,332 |  |  |  |  |  |

[0000320193-24-000006:mdna:46]
| Gross margin percentage: |  |  |  |  |  |  |  |
| Products | 39.4 | % |  | 37.0 | % |  |  |  |  |
| Services | 72.8 | % |  | 70.8 | % |  |  |  |  |
| Total gross margin percentage | 45.9 | % |  | 43.0 | % |  |  |  |  |

[0000320193-24-000006:mdna:47]
[same as prior period, unchanged from 0000320193-23-000077:mdna:51]

[0000320193-24-000006:mdna:48]
Products gross margin increased during the first quarter of 2024 compared to the same quarter in 2023 due primarily to cost savings and a different Products mix, partially offset by the weakness in foreign currencies relative to the U.S. dollar and lower Products volume.

[0000320193-24-000006:mdna:49]
Products gross margin percentage increased during the first quarter of 2024 compared to the same quarter in 2023 due primarily to cost savings and a different Products mix, partially offset by the weakness in foreign currencies relative to the U.S. dollar.

[0000320193-24-000006:mdna:50]
[same as prior period, unchanged from 0000320193-23-000077:mdna:54]

[0000320193-24-000006:mdna:51]
Services gross margin increased during the first quarter of 2024 compared to the same quarter in 2023 due primarily to higher Services net sales and a different Services mix.

[0000320193-24-000006:mdna:52]
Services gross margin percentage increased during the first quarter of 2024 compared to the same quarter in 2023 due primarily to a different Services mix.

[0000320193-24-000006:mdna:53]
The Company’s future gross margins can be impacted by a variety of factors, as discussed in Part I, Item 1A of the 2023 Form 10-K under the heading “Risk Factors.” As a result, the Company believes, in general, gross margins will be subject to volatility and downward pressure.

[0000320193-24-000006:mdna:54]
[same as prior period, unchanged from 0000320193-23-000077:mdna:58]

[0000320193-24-000006:mdna:55]
Operating expenses for the three months ended December 30, 2023 and December 31, 2022 were as follows (dollars in millions):

[0000320193-24-000006:mdna:56]
|  | Three Months Ended |  |  |
|  | December 30,2023 |  | December 31,2022 |  |  |  |  |
| Research and development | $ | 7,696 |  |  | $ | 7,709 |  |  |  |  |  |
| Percentage of total net sales | 6 | % |  | 7 | % |  |  |  |  |
| Selling, general and administrative | $ | 6,786 |  |  | $ | 6,607 |  |  |  |  |  |
| Percentage of total net sales | 6 | % |  | 6 | % |  |  |  |  |
| Total operating expenses | $ | 14,482 |  |  | $ | 14,316 |  |  |  |  |  |
| Percentage of total net sales | 12 | % |  | 12 | % |  |  |  |  |

[0000320193-24-000006:mdna:57]
[same as prior period, unchanged from 0000320193-23-000077:mdna:61]

[0000320193-24-000006:mdna:58]
Research and development (“R&D”) expense was relatively flat during the first quarter of 2024 compared to the same quarter in 2023.

[0000320193-24-000006:mdna:59]
[same as prior period, unchanged from 0000320193-23-000077:mdna:63]

[0000320193-24-000006:mdna:60]
Selling, general and administrative expense increased 3% or $179 million during the first quarter of 2024 compared to the same quarter in 2023.

[0000320193-24-000006:mdna:61]
[same as prior period, unchanged from 0000320193-23-000077:mdna:65]

[0000320193-24-000006:mdna:62]
Provision for income taxes, effective tax rate and statutory federal income tax rate for the three months ended December 30, 2023 and December 31, 2022 were as follows (dollars in millions):

[0000320193-24-000006:mdna:63]
|  | Three Months Ended |  |  |
|  | December 30,2023 |  | December 31,2022 |  |  |  |  |
| Provision for income taxes | $ | 6,407 |  |  | $ | 5,625 |  |  |  |  |  |
| Effective tax rate | 15.9 | % |  | 15.8 | % |  |  |  |  |
| Statutory federal income tax rate | 21 | % |  | 21 | % |  |  |  |  |

[0000320193-24-000006:mdna:64]
The Company’s effective tax rate for the first quarter of 2024 was lower than the statutory federal income tax rate due primarily to a lower effective tax rate on foreign earnings, tax benefits from share-based compensation, and the impact of the U.S. federal R&D credit, partially offset by state income taxes.

[0000320193-24-000006:mdna:65]
The Company’s effective tax rate for the first quarter of 2024 was relatively flat compared to the same quarter in 2023.

[0000320193-24-000006:mdna:66]
[same as prior period, unchanged from 0000320193-23-000077:mdna:70]

[0000320193-24-000006:mdna:67]
[same as prior period, unchanged from 0000320193-23-000077:mdna:71]

[0000320193-24-000006:mdna:68]
The Company’s contractual cash requirements have not changed materially since the 2023 Form 10-K, except for manufacturing purchase obligations.

[0000320193-24-000006:mdna:69]
[same as prior period, unchanged from 0000320193-23-000077:mdna:73]

[0000320193-24-000006:mdna:70]
The Company utilizes several outsourcing partners to manufacture subassemblies for the Company’s products and to perform final assembly and testing of finished products. The Company also obtains individual components for its products from a wide variety of individual suppliers. As of December 30, 2023, the Company had manufacturing purchase obligations of $38.0 billion, with $37.9 billion payable within 12 months.

[0000320193-24-000006:mdna:71]
[same as prior period, unchanged from 0000320193-23-000077:mdna:75]

[0000320193-24-000006:mdna:72]
In addition to its contractual cash requirements, the Company has an authorized share repurchase program. The program does not obligate the Company to acquire a minimum amount of shares. As of December 30, 2023, the Company’s quarterly cash dividend was $0.24 per share. The Company intends to increase its dividend on an annual basis, subject to declaration by the Board of Directors.

[0000320193-24-000006:mdna:73]
Recent Accounting Pronouncements

[0000320193-24-000006:mdna:74]
Income Taxes

[0000320193-24-000006:mdna:75]
In December 2023, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) No. 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures (“ASU 2023-09”), which will require the Company to disclose specified additional information in its income tax rate reconciliation and provide additional information for reconciling items that meet a quantitative threshold. ASU 2023-09 will also require the Company to disaggregate its income taxes paid disclosure by federal, state and foreign taxes, with further disaggregation required for significant individual jurisdictions. The Company will adopt ASU 2023-09 in its fourth quarter of 2026. ASU 2023-09 allows for adoption using either a prospective or retrospective transition method.

[0000320193-24-000006:mdna:76]
Segment Reporting

[0000320193-24-000006:mdna:77]
In November 2023, the FASB issued ASU No. 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures (“ASU 2023-07”), which will require the Company to disclose segment expenses that are significant and regularly provided to the Company’s chief operating decision maker (“CODM”). In addition, ASU 2023-07 will require the Company to disclose the title and position of its CODM and how the CODM uses segment profit or loss information in assessing segment performance and deciding how to allocate resources. The Company will adopt ASU 2023-07 in its fourth quarter of 2025 using a retrospective transition method.

[0000320193-24-000006:mdna:78]
[same as prior period, unchanged from 0000320193-23-000077:mdna:77]

[0000320193-24-000006:mdna:79]
The preparation of financial statements and related disclosures in conformity with GAAP and the Company’s discussion and analysis of its financial condition and operating results require the Company’s management to make judgments, assumptions and estimates that affect the amounts reported. Note 1, “Summary of Significant Accounting Policies” of the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Form 10-Q and in the Notes to Consolidated Financial Statements in Part II, Item 8 of the 2023 Form 10-K describe the significant accounting policies and methods used in the preparation of the Company’s condensed consolidated financial statements. There have been no material changes to the Company’s critical accounting estimates since the 2023 Form 10-K.
