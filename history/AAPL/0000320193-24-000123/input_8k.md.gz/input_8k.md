# AAPL 8-K — 0000320193-24-000120 filed 2024-10-31

## item codes, every 8-K on or before 2024-11-01

- 2024-10-31 0000320193-24-000120 — 2.02, 9.01
- 2024-09-10 0001140361-24-040659 — 7.01
- 2024-08-26 0001140361-24-038601 — 5.02
- 2024-08-23 0001140361-24-038403 — 5.03, 9.01
- 2024-08-01 0000320193-24-000080 — 2.02, 9.01
- 2024-05-03 0001140361-24-024352 — 7.01, 9.01
- 2024-05-02 0000320193-24-000067 — 2.02, 9.01
- 2024-02-28 0001140361-24-010155 — 5.07
- 2024-02-01 0000320193-24-000005 — 2.02, 9.01
- 2023-11-02 0000320193-23-000104 — 2.02, 9.01
- 2023-08-03 0000320193-23-000075 — 2.02, 9.01
- 2023-05-10 0001140361-23-023909 — 8.01, 9.01
- 2023-05-04 0000320193-23-000063 — 2.02, 9.01
- 2023-03-10 0001140361-23-011192 — 5.07
- 2023-02-02 0000320193-23-000005 — 2.02, 9.01
- 2022-11-07 0001193125-22-278435 — 7.01, 9.01
- 2022-10-27 0000320193-22-000107 — 2.02, 9.01
- 2022-08-19 0001193125-22-225365 — 5.02, 5.03, 9.01
- 2022-08-08 0001193125-22-214914 — 8.01, 9.01
- 2022-07-28 0000320193-22-000069 — 2.02, 9.01
- 2022-04-28 0000320193-22-000058 — 2.02, 9.01
- 2022-03-04 0001193125-22-066169 — 5.02, 5.07, 9.01
- 2022-01-27 0000320193-22-000006 — 2.02, 9.01
- 2021-11-12 0001193125-21-328151 — 5.02, 5.03, 9.01
- 2021-10-28 0000320193-21-000104 — 2.02, 9.01
- 2021-08-05 0001193125-21-237787 — 8.01, 9.01
- 2021-07-27 0000320193-21-000063 — 2.02, 9.01
- 2021-04-28 0000320193-21-000055 — 2.02, 9.01
- 2021-02-24 0001193125-21-054710 — 5.07
- 2021-02-08 0001193125-21-032394 — 8.01, 9.01
- 2021-01-27 0000320193-21-000009 — 2.02, 9.01
- 2021-01-05 0001193125-21-001982 — 5.02
- 2020-10-29 0000320193-20-000094 — 2.02, 9.01
- 2020-08-20 0001193125-20-225672 — 8.01, 9.01
- 2020-08-07 0001193125-20-213158 — 5.03, 9.01
- 2020-07-30 0000320193-20-000060 — 2.02, 9.01
- 2020-05-11 0001193125-20-139112 — 8.01, 9.01
- 2020-04-30 0000320193-20-000050 — 2.02, 9.01
- 2020-02-27 0001193125-20-050884 — 5.07
- 2020-02-18 0001193125-20-039203 — 7.01, 9.01
- 2020-01-28 0000320193-20-000008 — 2.02, 9.01
- 2019-11-15 0001193125-19-292676 — 8.01, 9.01
- 2019-10-30 0000320193-19-000117 — 2.02, 9.01
- 2019-09-13 0000320193-19-000093 — 5.02
- 2019-09-11 0001193125-19-242975 — 8.01, 9.01
- 2019-07-30 0000320193-19-000073 — 2.02, 9.01
- 2019-04-30 0000320193-19-000063 — 2.02, 9.01
- 2019-03-04 0000320193-19-000032 — 5.07
- 2019-02-06 0000320193-19-000026 — 5.02
- 2019-01-29 0000320193-19-000007 — 2.02, 9.01
- 2019-01-02 0000320193-19-000002 — 2.02, 9.01
- 2018-11-01 0000320193-18-000142 — 2.02, 9.01
- 2018-07-31 0000320193-18-000098 — 2.02, 9.01
- 2018-05-08 0001193125-18-154948 — 8.01 — amendment of 0001193125-18-154515
- 2018-05-07 0001193125-18-154515 — 8.01, 9.01
- 2018-05-01 0000320193-18-000067 — 2.02, 9.01
- 2018-02-14 0001193125-18-045761 — 5.07, 9.01
- 2018-02-01 0000320193-18-000005 — 2.02, 9.01
- 2017-11-13 0001193125-17-341015 — 8.01, 9.01
- 2017-11-02 0000320193-17-000067 — 2.02, 9.01
- 2017-10-12 0001193125-17-308859 — 5.02
- 2017-09-12 0001193125-17-282809 — 8.01, 9.01
- 2017-08-18 0001193125-17-262261 — 8.01, 9.01
- 2017-08-01 0000320193-17-000006 — 2.02, 9.01
- 2017-06-20 0001193125-17-208226 — 8.01, 9.01
- 2017-05-24 0001193125-17-181867 — 8.01, 9.01
- 2017-05-11 0001193125-17-167400 — 8.01, 9.01
- 2017-05-02 0001628280-17-004663 — 2.02, 9.01
- 2017-03-03 0001193125-17-069853 — 8.01, 9.01
- 2017-03-01 0001193125-17-064019 — 5.07
- 2017-02-09 0001193125-17-036283 — 8.01, 9.01
- 2017-01-31 0001628280-17-000663 — 2.02, 9.01
- 2016-12-15 0001628280-16-022047 — 5.03, 9.01
- 2016-10-25 0001628280-16-020258 — 2.02, 9.01
- 2016-08-04 0001193125-16-672044 — 8.01, 9.01
- 2016-07-26 0001628280-16-017762 — 2.02, 9.01
- 2016-06-22 0001193125-16-628957 — 8.01, 9.01
- 2016-04-26 0001193125-16-556520 — 2.02, 9.01
- 2016-03-24 0001193125-16-516891 — 8.01, 9.01
- 2016-03-01 0001193125-16-488223 — 5.02, 5.07, 9.01
- 2016-02-23 0001193125-16-473562 — 8.01, 9.01
- 2016-01-26 0001193125-16-438421 — 2.02, 9.01
- 2015-12-22 0001193125-15-410853 — 5.03, 9.01
- 2015-12-17 0001193125-15-406279 — 5.02
- 2015-10-27 0001193125-15-354756 — 2.02, 9.01
- 2015-10-02 0001193125-15-336615 — 5.02
- 2015-09-17 0001193125-15-322466 — 8.01, 9.01
- 2015-07-31 0001193125-15-273023 — 8.01, 9.01
- 2015-07-21 0001193125-15-258464 — 2.02, 9.01
- 2015-06-10 0001193125-15-219298 — 8.01, 9.01
- 2015-05-13 0001193125-15-186064 — 8.01, 9.01
- 2015-04-27 0001193125-15-149607 — 7.01, 9.01
- 2015-04-27 0001193125-15-149590 — 2.02, 9.01
- 2015-03-13 0001104659-15-019336 — 5.07, 9.01
- 2015-02-09 0001193125-15-039270 — 8.01, 9.01
- 2015-01-28 0001193125-15-023732 — 8.01, 9.01
- 2015-01-27 0001193125-15-021857 — 2.02, 9.01
- 2014-11-10 0001193125-14-406296 — 8.01, 9.01
- 2014-10-20 0001193125-14-376361 — 2.02, 9.01
- 2014-07-23 0001193125-14-277193 — 8.01, 9.01
- 2014-07-22 0001193125-14-275598 — 2.02, 9.01
- 2014-07-17 0001193125-14-271698 — 5.02
- 2014-06-06 0001193125-14-228798 — 5.03, 9.01
- 2014-05-30 0001181431-14-021923 — 5.02
- 2014-05-06 0001193125-14-184969 — 8.01, 9.01
- 2014-04-23 0001193125-14-154883 — 7.01, 9.01
- 2014-04-23 0001193125-14-154871 — 2.02, 9.01
- 2014-03-05 0001193125-14-084697 — 5.02, 5.03, 5.07, 9.01
- 2014-01-27 0001193125-14-022238 — 2.02, 9.01
- 2013-10-28 0001193125-13-413498 — 2.02, 9.01
- 2013-09-23 0001181431-13-050140 — 8.01
- 2013-07-30 0001181431-13-041847 — 5.02
- 2013-07-23 0001193125-13-298914 — 2.02, 9.01
- 2013-06-21 0001193125-13-267629 — 5.02
- 2013-05-03 0001193125-13-199324 — 8.01, 9.01
- 2013-04-24 0001193125-13-170623 — 8.01, 9.01
- 2013-04-23 0001193125-13-167469 — 7.01, 9.01
- 2013-04-23 0001193125-13-167458 — 2.02, 9.01
- 2013-03-01 0001193125-13-085842 — 5.07
- 2013-01-23 0001193125-13-020783 — 2.02, 9.01
- 2012-10-25 0001193125-12-435506 — 2.02, 9.01
- 2012-07-24 0001193125-12-312355 — 2.02, 9.01
- 2012-06-28 0001181431-12-038301 — 5.02
- 2012-05-24 0001181431-12-032458 — 5.02
- 2012-04-24 0001193125-12-178928 — 2.02, 9.01
- 2012-02-27 0001193125-12-081892 — 5.07
- 2012-01-24 0001193125-12-021833 — 2.02, 9.01
- 2011-11-16 0001181431-11-056354 — 5.02
- 2011-10-18 0001193125-11-273826 — 2.02, 9.01
- 2011-10-06 0001181431-11-051976 — 8.01
- 2011-08-26 0001181431-11-047179 — 5.02
- 2011-07-19 0001193125-11-191368 — 2.02, 9.01
- 2011-06-15 0001181431-11-036782 — 5.02
- 2011-04-20 0001193125-11-103732 — 2.02, 9.01
- 2011-02-24 0001193125-11-045411 — 5.07
- 2011-01-18 0001193125-11-009392 — 2.02, 9.01
- 2011-01-18 0001181431-11-003847 — 5.02
- 2010-11-17 0001181431-10-056327 — 5.02, 5.03, 9.01
- 2010-10-18 0001193125-10-230992 — 2.02, 9.01
- 2010-07-20 0001193125-10-161807 — 2.02, 9.01
- 2010-04-20 0001193125-10-087786 — 2.02, 9.01
- 2010-03-12 0001181431-10-016054 — 5.02
- 2010-03-01 0001193125-10-044765 — 5.02, 5.07, 9.01
- 2010-01-25 0001193125-10-012096 — 2.02, 9.01
- 2009-10-19 0001193125-09-209633 — 2.02, 9.01
- 2009-08-04 0001181431-09-037492 — 5.02
- 2009-07-21 0001193125-09-152290 — 2.02, 9.01
- 2009-06-02 0001181431-09-028400 — 5.03
- 2009-04-22 0001193125-09-084599 — 2.02, 9.01
- 2009-02-27 0001181431-09-012161 — 4.01
- 2009-01-21 0001193125-09-009009 — 2.02, 9.01
- 2009-01-16 0001181431-09-003017 — 5.02
- 2008-10-21 0001193125-08-213642 — 2.02, 9.01
- 2008-08-26 0001181431-08-050059 — 5.03
- 2008-07-21 0001193125-08-154381 — 2.02, 9.01
- 2008-06-09 0001181431-08-037620 — 8.01
- 2008-04-23 0001193125-08-088001 — 2.02, 9.01
- 2008-01-22 0001193125-08-009715 — 2.02, 9.01
- 2008-01-15 0001181431-08-003342 — 2.02, 8.01
- 2008-01-08 0001181431-08-002372 — 5.02
- 2007-10-22 0001104659-07-076142 — 2.02, 9.01
- 2007-07-25 0001104659-07-056111 — 2.02, 9.01
- 2007-05-16 0001104659-07-040672 — 5.02, 9.01
- 2007-04-25 0001104659-07-031354 — 2.02, 9.01
- 2007-04-24 0001104659-07-030938 — 8.01, 9.01
- 2007-02-21 0001104659-07-012760 — 5.03, 9.01
- 2007-01-17 0001104659-07-002905 — 2.02, 9.01
- 2007-01-10 0001104659-07-001648 — 5.03, 9.01
- 2006-10-27 0001104659-06-069015 — 8.01
- 2006-10-18 0001104659-06-067275 — 2.02, 9.01
- 2006-10-04 0001104659-06-064935 — 5.02, 8.01, 9.01
- 2006-09-01 0001104659-06-058808 — 1.01, 5.02, 5.03, 9.01
- 2006-08-11 0001104659-06-054118 — 2.02, 3.01, 9.01
- 2006-08-04 0001104659-06-051302 — 2.02, 4.02, 9.01
- 2006-07-19 0001104659-06-047739 — 2.02, 9.01
- 2006-04-21 0001181431-06-024759 — 1.01
- 2006-04-19 0001104659-06-025992 — 2.02, 9.01
- 2006-01-18 0001104659-06-002690 — 2.02, 9.01
- 2006-01-10 0001104659-06-001428 — 2.02
- 2005-12-19 0001181431-05-067468 — 1.01
- 2005-10-14 0001181431-05-056604 — 5.02
- 2005-10-11 0001104659-05-048094 — 2.02, 9.01
- 2005-08-26 0001181431-05-049163 — 1.01
- 2005-08-15 0001181431-05-046871 — 1.01
- 2005-07-13 0001104659-05-032297 — 2.02, 9.01
- 2005-06-06 0001181431-05-033177 — 8.01
- 2005-04-26 0001181431-05-023450 — 1.01
- 2005-04-13 0001104659-05-016307 — 2.02, 9.01
- 2005-03-02 0001181431-05-013840 — 3.03, 5.03
- 2005-02-11 0001104659-05-005507 — 8.01
- 2005-01-12 0001104659-05-001183 — 2.02, 9.01
- 2005-01-11 0001104659-05-001049 — 2.02
- 2004-10-13 0001104659-04-030400 — 2.02, 9.01
- 2004-07-14 0001104659-04-019574 — 12, 7
- 2004-04-14 0001104659-04-010122 — 12, 7
- 2004-01-14 0001104659-04-000896 — 12, 7
- 2003-10-15 0001104659-03-022879 — 12, 7
- 2003-07-16 0001104659-03-014913 — 7, 9
- 2003-04-16 0001047469-03-013617 — 7, 9
- 2003-03-21 0001104659-03-004649 — 5, 7
- 2002-08-13 0000912057-02-031595 — 5, 7
- 2002-08-05 0000912057-02-029692 — 5, 7
- 2000-01-24 0000912057-00-002128 — 5, 7
- 1999-09-07 0000320193-99-000010 — 2
- 1999-07-16 0000320193-99-000007 — 2
- 1998-12-23 0000320193-98-000010 — 1
- 1998-01-08 0000320193-98-000001 — 2
- 1997-09-25 0000320193-97-000019 — 2
- 1997-09-25 0000320193-97-000018 — 2
- 1997-09-05 0000320193-97-000016 — 2
- 1997-07-28 0000320193-97-000012 — 4
- 1997-04-25 0000320193-97-000009 — 5
- 1997-04-10 0000320193-97-000007 — 7
- 1996-12-24 0000320193-96-000027 — 7
- 1996-12-23 0000320193-96-000025 — 4 — amendment of 0000320193-96-000021
- 1996-12-13 0000320193-96-000021 — 4
- 1996-10-28 0000912057-96-023874 — 5, 7
- 1996-06-17 0000320193-96-000014 — 1
- 1996-04-12 0000320193-96-000006 — 1

## late-filing notifications on or before 2024-11-01

- 2006-12-15 0001104659-06-081617 — NT 10-K, for the period ended 2006-09-30
- 2006-08-11 0001104659-06-053743 — NT 10-Q, for the period ended 2006-07-01

## item 2.02 — earnings release, exhibit 99.1

[0000320193-24-000120:8k_2_02:1]
EX-99.1
2
a8-kex991q4202409282024.htm
EX-99.1

[0000320193-24-000120:8k_2_02:2]
Document

[0000320193-24-000120:8k_2_02:3]
Exhibit 99.1

[0000320193-24-000120:8k_2_02:4]
Apple reports fourth quarter results

[0000320193-24-000120:8k_2_02:5]
iPhone drives record September quarter revenue

[0000320193-24-000120:8k_2_02:6]
Services revenue reaches new all-time high

[0000320193-24-000120:8k_2_02:7]
CUPERTINO, CALIFORNIA — Apple® today announced financial results for its fiscal 2024 fourth quarter ended September 28, 2024. The Company posted quarterly revenue of $94.9 billion, up 6 percent year over year, and quarterly diluted earnings per share of $0.97. Diluted earnings per share was $1.64,1 up 12 percent year over year when excluding the one-time charge recognized during the fourth quarter of 2024 related to the impact of the reversal of the European General Court’s State Aid decision.

[0000320193-24-000120:8k_2_02:8]
“Today Apple is reporting a new September quarter revenue record of $94.9 billion, up 6 percent from a year ago,” said Tim Cook, Apple’s CEO. “During the quarter, we were excited to announce our best products yet, with the all-new iPhone 16 lineup, Apple Watch Series 10, AirPods 4, and remarkable features for hearing health and sleep apnea detection. And this week, we released our first set of features for Apple Intelligence, which sets a new standard for privacy in AI and supercharges our lineup heading into the holiday season.”

[0000320193-24-000120:8k_2_02:9]
“Our record business performance during the September quarter drove nearly $27 billion in operating cash flow, allowing us to return over $29 billion to our shareholders,” said Luca Maestri, Apple’s CFO. “We are very pleased that our active installed base of devices reached a new all-time high across all products and all geographic segments, thanks to our high levels of customer satisfaction and loyalty.”

[0000320193-24-000120:8k_2_02:10]
Apple’s board of directors has declared a cash dividend of $0.25 per share of the Company’s common stock. The dividend is payable on November 14, 2024 to shareholders of record as of the close of business on November 11, 2024.

[0000320193-24-000120:8k_2_02:11]
Apple will provide live streaming of its Q4 2024 financial results conference call beginning at 2:00 p.m. PT on October 31, 2024 at apple.com/investor/earnings-call. The webcast will be available for replay for approximately two weeks thereafter.

[0000320193-24-000120:8k_2_02:12]
1. Non-GAAP measure. See the section titled “Reconciliation of Non-GAAP to GAAP Results of Operations” at the end of the accompanying financial statements.

[0000320193-24-000120:8k_2_02:13]
Apple periodically provides information for investors on its corporate website, apple.com, and its investor relations website, investor.apple.com. This includes press releases and other information about financial performance, reports filed or furnished with the SEC, information on corporate governance, and details related to its annual meeting of shareholders.

[0000320193-24-000120:8k_2_02:14]
Apple revolutionized personal technology with the introduction of the Macintosh in 1984. Today, Apple leads the world in innovation with iPhone, iPad, Mac, AirPods, Apple Watch, and Apple Vision Pro. Apple’s six software platforms — iOS, iPadOS, macOS, watchOS, visionOS, and tvOS — provide seamless experiences across all Apple devices and empower people with breakthrough services including the App Store, Apple Music, Apple Pay, iCloud, and Apple TV+. Apple’s more than 150,000 employees are dedicated to making the best products on earth and to leaving the world better than we found it.

[0000320193-24-000120:8k_2_02:15]
Press Contact:

[0000320193-24-000120:8k_2_02:16]
Josh Rosenstock

[0000320193-24-000120:8k_2_02:17]
Apple

[0000320193-24-000120:8k_2_02:18]
jrosenstock@apple.com

[0000320193-24-000120:8k_2_02:19]
(408) 862-1142

[0000320193-24-000120:8k_2_02:20]
Investor Relations Contact:

[0000320193-24-000120:8k_2_02:21]
Suhasini Chandramouli

[0000320193-24-000120:8k_2_02:22]
Apple

[0000320193-24-000120:8k_2_02:23]
suhasini@apple.com

[0000320193-24-000120:8k_2_02:24]
(408) 974-3123

[0000320193-24-000120:8k_2_02:25]
NOTE TO EDITORS: For additional information visit Apple Newsroom (www.apple.com/newsroom), or email Apple’s Media Helpline at media.help@apple.com.

[0000320193-24-000120:8k_2_02:26]
© 2024 Apple Inc. All rights reserved. Apple and the Apple logo are trademarks of Apple. Other company and product names may be trademarks of their respective owners.

[0000320193-24-000120:8k_2_02:27]
Apple Inc.

[0000320193-24-000120:8k_2_02:28]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS (Unaudited)

[0000320193-24-000120:8k_2_02:29]
(In millions, except number of shares, which are reflected in thousands, and per-share amounts)

[0000320193-24-000120:8k_2_02:30]
|  | Three Months Ended |  | Twelve Months Ended |
|  | September 28,2024 |  | September 30,2023 |  | September 28,2024 |  | September 30,2023 |
| Net sales: |  |  |  |  |  |  |  |
| Products | $ | 69,958 |  |  | $ | 67,184 |  |  | $ | 294,866 |  |  | $ | 298,085 |  |
| Services | 24,972 |  |  | 22,314 |  |  | 96,169 |  |  | 85,200 |  |
| Total net sales (1) | 94,930 |  |  | 89,498 |  |  | 391,035 |  |  | 383,285 |  |
| Cost of sales: |  |  |  |  |  |  |  |
| Products | 44,566 |  |  | 42,586 |  |  | 185,233 |  |  | 189,282 |  |
| Services | 6,485 |  |  | 6,485 |  |  | 25,119 |  |  | 24,855 |  |
| Total cost of sales | 51,051 |  |  | 49,071 |  |  | 210,352 |  |  | 214,137 |  |
| Gross margin | 43,879 |  |  | 40,427 |  |  | 180,683 |  |  | 169,148 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 7,765 |  |  | 7,307 |  |  | 31,370 |  |  | 29,915 |  |
| Selling, general and administrative | 6,523 |  |  | 6,151 |  |  | 26,097 |  |  | 24,932 |  |
| Total operating expenses | 14,288 |  |  | 13,458 |  |  | 57,467 |  |  | 54,847 |  |
| Operating income | 29,591 |  |  | 26,969 |  |  | 123,216 |  |  | 114,301 |  |
| Other income/(expense), net | 19 |  |  | 29 |  |  | 269 |  |  | (565) |  |
| Income before provision for income taxes | 29,610 |  |  | 26,998 |  |  | 123,485 |  |  | 113,736 |  |
| Provision for income taxes | 14,874 |  |  | 4,042 |  |  | 29,749 |  |  | 16,741 |  |
| Net income | $ | 14,736 |  |  | $ | 22,956 |  |  | $ | 93,736 |  |  | $ | 96,995 |  |
| Earnings per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.97 |  |  | $ | 1.47 |  |  | $ | 6.11 |  |  | $ | 6.16 |  |
| Diluted | $ | 0.97 |  |  | $ | 1.46 |  |  | $ | 6.08 |  |  | $ | 6.13 |  |
| Shares used in computing earnings per share: |  |  |  |  |  |  |  |
| Basic | 15,171,990 |  |  | 15,599,434 |  |  | 15,343,783 |  |  | 15,744,231 |  |
| Diluted | 15,242,853 |  |  | 15,672,400 |  |  | 15,408,095 |  |  | 15,812,547 |  |
| (1) Net sales by reportable segment: |  |  |  |  |  |  |  |
| Americas | $ | 41,664 |  |  | $ | 40,115 |  |  | $ | 167,045 |  |  | $ | 162,560 |  |
| Europe | 24,924 |  |  | 22,463 |  |  | 101,328 |  |  | 94,294 |  |
| Greater China | 15,033 |  |  | 15,084 |  |  | 66,952 |  |  | 72,559 |  |
| Japan | 5,926 |  |  | 5,505 |  |  | 25,052 |  |  | 24,257 |  |
| Rest of Asia Pacific | 7,383 |  |  | 6,331 |  |  | 30,658 |  |  | 29,615 |  |
| Total net sales | $ | 94,930 |  |  | $ | 89,498 |  |  | $ | 391,035 |  |  | $ | 383,285 |  |
| (1) Net sales by category: |  |  |  |  |  |  |  |
| iPhone | $ | 46,222 |  |  | $ | 43,805 |  |  | $ | 201,183 |  |  | $ | 200,583 |  |
| Mac | 7,744 |  |  | 7,614 |  |  | 29,984 |  |  | 29,357 |  |
| iPad | 6,950 |  |  | 6,443 |  |  | 26,694 |  |  | 28,300 |  |
| Wearables, Home and Accessories | 9,042 |  |  | 9,322 |  |  | 37,005 |  |  | 39,845 |  |
| Services | 24,972 |  |  | 22,314 |  |  | 96,169 |  |  | 85,200 |  |
| Total net sales | $ | 94,930 |  |  | $ | 89,498 |  |  | $ | 391,035 |  |  | $ | 383,285 |  |

[0000320193-24-000120:8k_2_02:31]
Apple Inc.

[0000320193-24-000120:8k_2_02:32]
CONDENSED CONSOLIDATED BALANCE SHEETS (Unaudited)

[0000320193-24-000120:8k_2_02:33]
(In millions, except number of shares, which are reflected in thousands, and par value)

[0000320193-24-000120:8k_2_02:34]
|  | September 28,2024 |  | September 30,2023 |
| ASSETS: |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 29,943 |  |  | $ | 29,965 |  |
| Marketable securities | 35,228 |  |  | 31,590 |  |
| Accounts receivable, net | 33,410 |  |  | 29,508 |  |
| Vendor non-trade receivables | 32,833 |  |  | 31,477 |  |
| Inventories | 7,286 |  |  | 6,331 |  |
| Other current assets | 14,287 |  |  | 14,695 |  |
| Total current assets | 152,987 |  |  | 143,566 |  |
| Non-current assets: |  |  |  |
| Marketable securities | 91,479 |  |  | 100,544 |  |
| Property, plant and equipment, net | 45,680 |  |  | 43,715 |  |
| Other non-current assets | 74,834 |  |  | 64,758 |  |
| Total non-current assets | 211,993 |  |  | 209,017 |  |
| Total assets | $ | 364,980 |  |  | $ | 352,583 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY: |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 68,960 |  |  | $ | 62,611 |  |
| Other current liabilities | 78,304 |  |  | 58,829 |  |
| Deferred revenue | 8,249 |  |  | 8,061 |  |
| Commercial paper | 9,967 |  |  | 5,985 |  |
| Term debt | 10,912 |  |  | 9,822 |  |
| Total current liabilities | 176,392 |  |  | 145,308 |  |
| Non-current liabilities: |  |  |  |
| Term debt | 85,750 |  |  | 95,281 |  |
| Other non-current liabilities | 45,888 |  |  | 49,848 |  |
| Total non-current liabilities | 131,638 |  |  | 145,129 |  |
| Total liabilities | 308,030 |  |  | 290,437 |  |
| Commitments and contingencies |  |  |  |
| Shareholders’ equity: |  |  |  |
| Common stock and additional paid-in capital, $0.00001 par value: 50,400,000 shares authorized; 15,116,786 and 15,550,061 shares issued and outstanding, respectively | 83,276 |  |  | 73,812 |  |
| Accumulated deficit | (19,154) |  |  | (214) |  |
| Accumulated other comprehensive loss | (7,172) |  |  | (11,452) |  |
| Total shareholders’ equity | 56,950 |  |  | 62,146 |  |
| Total liabilities and shareholders’ equity | $ | 364,980 |  |  | $ | 352,583 |  |

[0000320193-24-000120:8k_2_02:35]
Apple Inc.

[0000320193-24-000120:8k_2_02:36]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (Unaudited)

[0000320193-24-000120:8k_2_02:37]
(In millions)

[0000320193-24-000120:8k_2_02:38]
|  | Twelve Months Ended |
|  | September 28,2024 |  | September 30,2023 |
| Cash, cash equivalents, and restricted cash and cash equivalents, beginning balances | $ | 30,737 |  |  | $ | 24,977 |  |
| Operating activities: |  |  |  |
| Net income | 93,736 |  |  | 96,995 |  |
| Adjustments to reconcile net income to cash generated by operating activities: |  |  |  |
| Depreciation and amortization | 11,445 |  |  | 11,519 |  |
| Share-based compensation expense | 11,688 |  |  | 10,833 |  |
| Other | (2,266) |  |  | (2,227) |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | (3,788) |  |  | (1,688) |  |
| Vendor non-trade receivables | (1,356) |  |  | 1,271 |  |
| Inventories | (1,046) |  |  | (1,618) |  |
| Other current and non-current assets | (11,731) |  |  | (5,684) |  |
| Accounts payable | 6,020 |  |  | (1,889) |  |
| Other current and non-current liabilities | 15,552 |  |  | 3,031 |  |
| Cash generated by operating activities | 118,254 |  |  | 110,543 |  |
| Investing activities: |  |  |  |
| Purchases of marketable securities | (48,656) |  |  | (29,513) |  |
| Proceeds from maturities of marketable securities | 51,211 |  |  | 39,686 |  |
| Proceeds from sales of marketable securities | 11,135 |  |  | 5,828 |  |
| Payments for acquisition of property, plant and equipment | (9,447) |  |  | (10,959) |  |
| Other | (1,308) |  |  | (1,337) |  |
| Cash generated by investing activities | 2,935 |  |  | 3,705 |  |
| Financing activities: |  |  |  |
| Payments for taxes related to net share settlement of equity awards | (5,441) |  |  | (5,431) |  |
| Payments for dividends and dividend equivalents | (15,234) |  |  | (15,025) |  |
| Repurchases of common stock | (94,949) |  |  | (77,550) |  |
| Proceeds from issuance of term debt, net | — |  |  | 5,228 |  |
| Repayments of term debt | (9,958) |  |  | (11,151) |  |
| Proceeds from/(Repayments of) commercial paper, net | 3,960 |  |  | (3,978) |  |
| Other | (361) |  |  | (581) |  |
| Cash used in financing activities | (121,983) |  |  | (108,488) |  |
| Increase/(Decrease) in cash, cash equivalents, and restricted cash and cash equivalents | (794) |  |  | 5,760 |  |
| Cash, cash equivalents, and restricted cash and cash equivalents, ending balances | $ | 29,943 |  |  | $ | 30,737 |  |
| Supplemental cash flow disclosure: |  |  |  |
| Cash paid for income taxes, net | $ | 26,102 |  |  | $ | 18,679 |  |

[0000320193-24-000120:8k_2_02:39]
Apple Inc.

[0000320193-24-000120:8k_2_02:40]
RECONCILIATION OF NON-GAAP TO GAAP RESULTS OF OPERATIONS (Unaudited)

[0000320193-24-000120:8k_2_02:41]
(In millions, except number of shares, which are reflected in thousands, and per-share amounts)

[0000320193-24-000120:8k_2_02:42]
|  | Three Months Ended |  | Twelve Months Ended |
|  | September 28, 2024 |  | September 28, 2024 |
|  | As Reported (GAAP) |  | Non-GAAP Adjustments | (a) |  | As Adjusted (Non-GAAP) |  | As Reported (GAAP) |  | Non-GAAP Adjustments | (a) |  | As Adjusted (Non-GAAP) |
| Income before provision for income taxes | $ | 29,610 |  |  | $ | — |  |  |  | $ | 29,610 |  |  | $ | 123,485 |  |  | $ | — |  |  |  | $ | 123,485 |  |
| Provision for income taxes | 14,874 |  |  | (10,246) |  | (b) |  | 4,628 |  |  | 29,749 |  |  | (10,246) |  | (b) |  | 19,503 |  |
| Net income | $ | 14,736 |  |  | $ | 10,246 |  | (b) |  | $ | 24,982 |  |  | $ | 93,736 |  |  | $ | 10,246 |  | (b) |  | $ | 103,982 |  |
| Diluted earnings per share | $ | 0.97 |  |  | $ | 0.67 |  | (c) |  | $ | 1.64 |  |  | $ | 6.08 |  |  | $ | 0.67 |  | (c) |  | $ | 6.75 |  |
| Shares used in computing diluted earnings per share | 15,242,853 |  |  | — |  |  |  | 15,242,853 |  |  | 15,408,095 |  |  | — |  |  |  | 15,408,095 |  |

[0000320193-24-000120:8k_2_02:43]
(a)These adjustments reconcile certain of the Company’s GAAP results of operations to its non-GAAP results of operations. The Company believes that the presentation of results excluding the impact of the reversal of the European General Court’s State Aid decision provides meaningful supplemental information to both management and investors that is indicative of the Company’s core operating results and facilitates comparison of operating results across reporting periods. The Company uses these non-GAAP measures when evaluating its financial results as well as for internal planning and forecasting purposes. These non-GAAP measures should not be viewed as a substitute for the Company’s GAAP results.

[0000320193-24-000120:8k_2_02:44]
(b)Non-GAAP adjustments to provision for income taxes and net income to reflect the impact of the reversal of the European General Court’s State Aid decision recognized during the fourth quarter of 2024. On September 10, 2024, the European Court of Justice announced that it had set aside the 2020 judgment of the European General Court and confirmed the European Commission’s 2016 State Aid decision. As a result, during the fourth quarter of 2024 the Company recorded a one-time income tax charge of $10.2 billion, net, which represents $15.8 billion payable to Ireland via release of restricted funds held in escrow, partially offset by a U.S. foreign tax credit of $4.8 billion and a decrease in unrecognized tax benefits of $823 million. For additional information, refer to Note 7, “Income Taxes” of the Notes to Consolidated Financial Statements that will be included in Part II, Item 8 of the Company's fiscal 2024 Annual Report on Form 10-K.

[0000320193-24-000120:8k_2_02:45]
(c)Represents the per-share impact of the non-GAAP adjustments to net income.
