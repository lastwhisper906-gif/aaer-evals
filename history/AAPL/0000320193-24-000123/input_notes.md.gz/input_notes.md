# AAPL notes — 0000320193-24-000123


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000320193-24-000123:notes:1]
Portions of the Registrant’s definitive proxy statement relating to its 2025 annual meeting of shareholders are incorporated by reference into Part III of this Annual Report on Form 10-K where indicated. The Registrant’s definitive proxy statement will be filed with the U.S. Securities and Exchange Commission within 120 days after the end of the fiscal year to which this report relates.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000320193-24-000123:notes:2]
Summary of Significant Accounting Policies
Basis of Presentation and Preparation

[0000320193-24-000123:notes:3]
The consolidated financial statements include the accounts of Apple Inc. and its wholly owned subsidiaries. The preparation of these consolidated financial statements and accompanying notes in conformity with GAAP requires the use of management estimates. Certain prior period amounts in the consolidated financial statements and accompanying notes have been reclassified to conform to the current period’s presentation.

[0000320193-24-000123:notes:4]
The Company’s fiscal year is the 52- or 53-week period that ends on the last Saturday of September. An additional week is included in the first fiscal quarter every five or six years to realign the Company’s fiscal quarters with calendar quarters, which occurred in the first fiscal quarter of 2023. The Company’s fiscal years 2024 and 2022 spanned 52 weeks each, whereas fiscal year 2023 spanned 53 weeks. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in September and the associated quarters, months and periods of those fiscal years.

[0000320193-24-000123:notes:5]
Revenue

[0000320193-24-000123:notes:6]
The Company records revenue net of taxes collected from customers that are remitted to governmental authorities.

[0000320193-24-000123:notes:7]
Share-Based Compensation

[0000320193-24-000123:notes:8]
The Company recognizes share-based compensation expense on a straight-line basis for its estimate of equity awards that will ultimately vest.

[0000320193-24-000123:notes:9]
Cash Equivalents

[0000320193-24-000123:notes:10]
All highly liquid investments with maturities of three months or less at the date of purchase are treated as cash equivalents.

[0000320193-24-000123:notes:11]
Marketable Securities

[0000320193-24-000123:notes:12]
The cost of securities sold is determined using the specific identification method.

[0000320193-24-000123:notes:13]
Inventories

[0000320193-24-000123:notes:14]
Inventories are measured using the first-in, first-out method.

[0000320193-24-000123:notes:15]
Property, Plant and Equipment

[0000320193-24-000123:notes:16]
Depreciation on property, plant and equipment is recognized on a straight-line basis.

[0000320193-24-000123:notes:17]
Derivative Instruments

[0000320193-24-000123:notes:18]
The Company presents derivative assets and liabilities at their gross fair values in the Consolidated Balance Sheets.

[0000320193-24-000123:notes:19]
Income Taxes

[0000320193-24-000123:notes:20]
The Company records certain deferred tax assets and liabilities in connection with the minimum tax on certain foreign earnings created by the TCJA.

[0000320193-24-000123:notes:21]
Leases

[0000320193-24-000123:notes:22]
The Company combines and accounts for lease and nonlease components as a single lease component for leases of corporate, data center and retail facilities.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0000320193-24-000123:notes:23]
The Company recognizes revenue at the amount to which it expects to be entitled when control of the products or services is transferred to its customers. Control is generally transferred when the Company has a present right to payment and title and the significant risks and rewards of ownership of products or services are transferred to its customers. For most of the Company’s Products net sales, control transfers when products are shipped. For the Company’s Services net sales, control transfers over time as services are delivered. Payment for Products and Services net sales is collected within a short period following transfer of control or commencement of delivery of services, as applicable.

[0000320193-24-000123:notes:24]
The Company records reductions to Products net sales related to future product returns, price protection and other customer incentive programs based on the Company’s expectations and historical experience.

[0000320193-24-000123:notes:25]
For arrangements with multiple performance obligations, which represent promises within an arrangement that are distinct, the Company allocates revenue to all distinct performance obligations based on their relative stand-alone selling prices (“SSPs”). When available, the Company uses observable prices to determine SSPs. When observable prices are not available, SSPs are established that reflect the Company’s best estimates of what the selling prices of the performance obligations would be if they were sold regularly on a stand-alone basis. The Company’s process for estimating SSPs without observable prices considers multiple factors that may vary depending upon the unique facts and circumstances related to each performance obligation including, where applicable, prices charged by the Company for similar offerings, market trends in the pricing for similar offerings, product-specific business objectives and the estimated cost to provide the performance obligation.

[0000320193-24-000123:notes:26]
The Company has identified the performance obligations regularly included in arrangements involving the sale of iPhone, Mac and iPad. The first material performance obligation, which represents the substantial portion of the allocated sales price, is the hardware and bundled software delivered at the time of sale. The second material performance obligation is the right to receive certain product-related bundled services, which include iCloud®, Siri® and Maps. The Company allocates revenue and any related discounts to all of its performance obligations based on their relative SSPs. Because the Company lacks observable prices for product-related bundled services, the allocation of revenue is based on the Company’s estimated SSPs. Revenue allocated to the delivered hardware and bundled software is recognized when control has transferred to the customer, which generally occurs when the product is shipped. Revenue allocated to product-related bundled services is deferred and recognized on a straight-line basis over the estimated period they are expected to be provided.

[0000320193-24-000123:notes:27]
For certain long-term service arrangements, the Company has performance obligations for services it has not yet delivered. For these arrangements, the Company does not have a right to bill for the undelivered services. The Company has determined that any unbilled consideration relates entirely to the value of the undelivered services. Accordingly, the Company has not recognized revenue, and does not disclose amounts, related to these undelivered services.

[0000320193-24-000123:notes:28]
For the sale of third-party products where the Company obtains control of the product before transferring it to the customer, the Company recognizes revenue based on the gross amount billed to customers. The Company considers multiple factors when determining whether it obtains control of third-party products, including evaluating if it can establish the price of the product, retains inventory risk for tangible products or has the responsibility for ensuring acceptability of the product. For third-party applications sold through the App Store, the Company does not obtain control of the product before transferring it to the customer. Therefore, the Company accounts for all third-party application–related sales on a net basis by recognizing in Services net sales only the commission it retains.


## us-gaap:DerivativesPolicyTextBlock

[0000320193-24-000123:notes:29]
The Company classifies cash flows related to derivative instruments in the same section of the Consolidated Statements of Cash Flows as the items being hedged, which are generally classified as operating activities.


## us-gaap:LesseeLeasesPolicyTextBlock

[0000320193-24-000123:notes:30]
The Company combines and accounts for lease and nonlease components as a single lease component for leases of corporate, data center and retail facilities.
The discount rates related to the Company’s lease liabilities are generally based on estimates of the Company’s incremental borrowing rate, as the discount rates implicit in the Company’s leases cannot be readily determined.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000320193-24-000123:notes:31]
Revenue
The Company recognizes revenue at the amount to which it expects to be entitled when control of the products or services is transferred to its customers. Control is generally transferred when the Company has a present right to payment and title and the significant risks and rewards of ownership of products or services are transferred to its customers. For most of the Company’s Products net sales, control transfers when products are shipped. For the Company’s Services net sales, control transfers over time as services are delivered. Payment for Products and Services net sales is collected within a short period following transfer of control or commencement of delivery of services, as applicable.

[0000320193-24-000123:notes:32]
Net sales disaggregated by significant products and services for 2024, 2023 and 2022 were as follows (in millions):

[0000320193-24-000123:notes:33]
|  | 2024 |  | 2023 |  | 2022 |
| iPhone | $ | 201,183 |  |  | $ | 200,583 |  |  | $ | 205,489 |  |
| Mac | 29,984 |  |  | 29,357 |  |  | 40,177 |  |
| iPad | 26,694 |  |  | 28,300 |  |  | 29,292 |  |
| Wearables, Home and Accessories | 37,005 |  |  | 39,845 |  |  | 41,241 |  |
| Services (1) | 96,169 |  |  | 85,200 |  |  | 78,129 |  |
| Total net sales | $ | 391,035 |  |  | $ | 383,285 |  |  | $ | 394,328 |  |

[0000320193-24-000123:notes:34]
(1)Services net sales include amortization of the deferred value of services bundled in the sales price of certain products.

[0000320193-24-000123:notes:35]
Total net sales include $7.7 billion of revenue recognized in 2024 that was included in deferred revenue as of September 30, 2023, $8.2 billion of revenue recognized in 2023 that was included in deferred revenue as of September 24, 2022, and $7.5 billion of revenue recognized in 2022 that was included in deferred revenue as of September 25, 2021.

[0000320193-24-000123:notes:36]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 13, “Segment Information and Geographic Data” for 2024, 2023 and 2022, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.

[0000320193-24-000123:notes:37]
As of September 28, 2024 and September 30, 2023, the Company had total deferred revenue of $12.8 billion and $12.1 billion, respectively. As of September 28, 2024, the Company expects 64% of total deferred revenue to be realized in less than a year, 25% within one-to-two years, 9% within two-to-three years and 2% in greater than three years.


## us-gaap:EarningsPerShareTextBlock

[0000320193-24-000123:notes:38]
Earnings Per Share
The following table shows the computation of basic and diluted earnings per share for 2024, 2023 and 2022 (net income in millions and shares in thousands):

[0000320193-24-000123:notes:39]
|  | 2024 |  | 2023 |  | 2022 |
| Numerator: |  |  |  |  |  |
| Net income | $ | 93,736 |  |  | $ | 96,995 |  |  | $ | 99,803 |  |
| Denominator: |  |  |  |  |  |
| Weighted-average basic shares outstanding | 15,343,783 |  |  | 15,744,231 |  |  | 16,215,963 |  |
| Effect of dilutive share-based awards | 64,312 |  |  | 68,316 |  |  | 109,856 |  |
| Weighted-average diluted shares | 15,408,095 |  |  | 15,812,547 |  |  | 16,325,819 |  |
| Basic earnings per share | $ | 6.11 |  |  | $ | 6.16 |  |  | $ | 6.15 |  |
| Diluted earnings per share | $ | 6.08 |  |  | $ | 6.13 |  |  | $ | 6.11 |  |

[0000320193-24-000123:notes:40]
Approximately 24 million restricted stock units (“RSUs”) were excluded from the computation of diluted earnings per share for 2023 because their effect would have been antidilutive.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000320193-24-000123:notes:41]
Financial Instruments
Cash, Cash Equivalents and Marketable Securities

[0000320193-24-000123:notes:42]
The following tables show the Company’s cash, cash equivalents and marketable securities by significant investment category as of September 28, 2024 and September 30, 2023 (in millions):

[0000320193-24-000123:notes:43]
|  | 2024 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | CurrentMarketableSecurities |  | Non-CurrentMarketableSecurities |
| Cash | $ | 27,199 |  |  | $ | — |  |  | $ | — |  |  | $ | 27,199 |  |  | $ | 27,199 |  |  | $ | — |  |  | $ | — |  |
| Level 1: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 778 |  |  | — |  |  | — |  |  | 778 |  |  | 778 |  |  | — |  |  | — |  |
| Mutual funds | 515 |  |  | 105 |  |  | (3) |  |  | 617 |  |  | — |  |  | 617 |  |  | — |  |
| Subtotal | 1,293 |  |  | 105 |  |  | (3) |  |  | 1,395 |  |  | 778 |  |  | 617 |  |  | — |  |
| Level 2 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 16,150 |  |  | 45 |  |  | (516) |  |  | 15,679 |  |  | 212 |  |  | 4,087 |  |  | 11,380 |  |
| U.S. agency securities | 5,431 |  |  | — |  |  | (272) |  |  | 5,159 |  |  | 155 |  |  | 703 |  |  | 4,301 |  |
| Non-U.S. government securities | 17,959 |  |  | 93 |  |  | (484) |  |  | 17,568 |  |  | 1,158 |  |  | 10,810 |  |  | 5,600 |  |
| Certificates of deposit and time deposits | 873 |  |  | — |  |  | — |  |  | 873 |  |  | 387 |  |  | 478 |  |  | 8 |  |
| Commercial paper | 1,066 |  |  | — |  |  | — |  |  | 1,066 |  |  | 28 |  |  | 1,038 |  |  | — |  |
| Corporate debt securities | 65,622 |  |  | 270 |  |  | (1,953) |  |  | 63,939 |  |  | 26 |  |  | 16,027 |  |  | 47,886 |  |
| Municipal securities | 412 |  |  | — |  |  | (7) |  |  | 405 |  |  | — |  |  | 190 |  |  | 215 |  |
| Mortgage- and asset-backed securities | 24,595 |  |  | 175 |  |  | (1,403) |  |  | 23,367 |  |  | — |  |  | 1,278 |  |  | 22,089 |  |
| Subtotal | 132,108 |  |  | 583 |  |  | (4,635) |  |  | 128,056 |  |  | 1,966 |  |  | 34,611 |  |  | 91,479 |  |
| Total (2)(3) | $ | 160,600 |  |  | $ | 688 |  |  | $ | (4,638) |  |  | $ | 156,650 |  |  | $ | 29,943 |  |  | $ | 35,228 |  |  | $ | 91,479 |  |

[0000320193-24-000123:notes:44]
|  | 2023 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | CurrentMarketableSecurities |  | Non-CurrentMarketableSecurities |
| Cash | $ | 28,359 |  |  | $ | — |  |  | $ | — |  |  | $ | 28,359 |  |  | $ | 28,359 |  |  | $ | — |  |  | $ | — |  |
| Level 1: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 481 |  |  | — |  |  | — |  |  | 481 |  |  | 481 |  |  | — |  |  | — |  |
| Mutual funds and equity securities | 442 |  |  | 12 |  |  | (26) |  |  | 428 |  |  | — |  |  | 428 |  |  | — |  |
| Subtotal | 923 |  |  | 12 |  |  | (26) |  |  | 909 |  |  | 481 |  |  | 428 |  |  | — |  |
| Level 2 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 19,406 |  |  | — |  |  | (1,292) |  |  | 18,114 |  |  | 35 |  |  | 5,468 |  |  | 12,611 |  |
| U.S. agency securities | 5,736 |  |  | — |  |  | (600) |  |  | 5,136 |  |  | 36 |  |  | 271 |  |  | 4,829 |  |
| Non-U.S. government securities | 17,533 |  |  | 6 |  |  | (1,048) |  |  | 16,491 |  |  | — |  |  | 11,332 |  |  | 5,159 |  |
| Certificates of deposit and time deposits | 1,354 |  |  | — |  |  | — |  |  | 1,354 |  |  | 1,034 |  |  | 320 |  |  | — |  |
| Commercial paper | 608 |  |  | — |  |  | — |  |  | 608 |  |  | — |  |  | 608 |  |  | — |  |
| Corporate debt securities | 76,840 |  |  | 6 |  |  | (5,956) |  |  | 70,890 |  |  | 20 |  |  | 12,627 |  |  | 58,243 |  |
| Municipal securities | 628 |  |  | — |  |  | (26) |  |  | 602 |  |  | — |  |  | 192 |  |  | 410 |  |
| Mortgage- and asset-backed securities | 22,365 |  |  | 6 |  |  | (2,735) |  |  | 19,636 |  |  | — |  |  | 344 |  |  | 19,292 |  |
| Subtotal | 144,470 |  |  | 18 |  |  | (11,657) |  |  | 132,831 |  |  | 1,125 |  |  | 31,162 |  |  | 100,544 |  |
| Total (3) | $ | 173,752 |  |  | $ | 30 |  |  | $ | (11,683) |  |  | $ | 162,099 |  |  | $ | 29,965 |  |  | $ | 31,590 |  |  | $ | 100,544 |  |

[0000320193-24-000123:notes:45]
(1)The valuation techniques used to measure the fair values of the Company’s Level 2 financial instruments, which generally have counterparties with high credit ratings, are based on quoted market prices or model-driven valuations using significant inputs derived from or corroborated by observable market data.

[0000320193-24-000123:notes:46]
(2)As of September 28, 2024, cash and cash equivalents included $2.6 billion held in escrow and restricted from general use. These restricted cash and cash equivalents were designated to settle the Company’s obligation related to the State Aid Decision (refer to Note 7, “Income Taxes”).

[0000320193-24-000123:notes:47]
(3)As of September 28, 2024 and September 30, 2023, total marketable securities included $13.2 billion and $13.8 billion, respectively, held in escrow and restricted from general use. The September 28, 2024 restricted marketable securities were designated to settle the Company’s obligation related to the State Aid Decision (refer to Note 7, “Income Taxes”).

[0000320193-24-000123:notes:48]
As of September 28, 2024, 86% of the Company’s non-current marketable debt securities other than mortgage- and asset-backed securities had maturities between 1 and 5 years, 10% between 5 and 10 years, and 4% greater than 10 years. As of September 28, 2024, 14% of the Company’s non-current mortgage- and asset-backed securities had maturities between 1 and 5 years, 9% between 5 and 10 years, and 77% greater than 10 years.

[0000320193-24-000123:notes:49]
The Company’s investments in marketable debt securities have been classified and accounted for as available-for-sale. The Company classifies marketable debt securities as either current or non-current based on each instrument’s underlying maturity.

[0000320193-24-000123:notes:50]
Derivative Instruments and Hedging

[0000320193-24-000123:notes:51]
The Company may use derivative instruments to partially offset its business exposure to foreign exchange and interest rate risk. However, the Company may choose not to hedge certain exposures for a variety of reasons including accounting considerations or the prohibitive economic cost of hedging particular exposures. There can be no assurance the hedges will offset more than a portion of the financial impact resulting from movements in foreign exchange or interest rates.

[0000320193-24-000123:notes:52]
Foreign Exchange Rate Risk

[0000320193-24-000123:notes:53]
To protect gross margins from fluctuations in foreign exchange rates, the Company may use forwards, options or other instruments, and may designate these instruments as cash flow hedges. The Company generally hedges portions of its forecasted foreign currency exposure associated with revenue and inventory purchases, typically for up to 12 months.

[0000320193-24-000123:notes:54]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in foreign exchange rates, the Company may use forwards, cross-currency swaps or other instruments. The Company designates these instruments as either cash flow or fair value hedges. As of September 28, 2024, the maximum length of time over which the Company is hedging its exposure to the variability in future cash flows for term debt–related foreign currency transactions is 18 years.

[0000320193-24-000123:notes:55]
The Company may also use derivative instruments that are not designated as accounting hedges to protect gross margins from certain fluctuations in foreign exchange rates, as well as to offset a portion of the foreign currency gains and losses generated by the remeasurement of certain assets and liabilities denominated in non-functional currencies.

[0000320193-24-000123:notes:56]
Interest Rate Risk

[0000320193-24-000123:notes:57]
To protect the Company’s term debt or marketable securities from fluctuations in interest rates, the Company may use interest rate swaps, options or other instruments. The Company designates these instruments as either cash flow or fair value hedges.

[0000320193-24-000123:notes:58]
The notional amounts of the Company’s outstanding derivative instruments as of September 28, 2024 and September 30, 2023 were as follows (in millions):

[0000320193-24-000123:notes:59]
|  | 2024 |  | 2023 |
| Derivative instruments designated as accounting hedges: |  |  |  |
| Foreign exchange contracts | $ | 64,069 |  |  | $ | 74,730 |  |
| Interest rate contracts | $ | 14,575 |  |  | $ | 19,375 |  |
| Derivative instruments not designated as accounting hedges: |  |  |  |
| Foreign exchange contracts | $ | 91,493 |  |  | $ | 104,777 |  |

[0000320193-24-000123:notes:60]
The carrying amounts of the Company’s hedged items in fair value hedges as of September 28, 2024 and September 30, 2023 were as follows (in millions):

[0000320193-24-000123:notes:61]
|  | 2024 |  | 2023 |
| Hedged assets/(liabilities): |  |  |  |
| Current and non-current marketable securities | $ | — |  |  | $ | 14,433 |  |
| Current and non-current term debt | $ | (13,505) |  |  | $ | (18,247) |  |

[0000320193-24-000123:notes:62]
Accounts Receivable

[0000320193-24-000123:notes:63]
Trade Receivables

[0000320193-24-000123:notes:64]
The Company’s third-party cellular network carriers accounted for 38% and 41% of total trade receivables as of September 28, 2024 and September 30, 2023, respectively. The Company requires third-party credit support or collateral from certain customers to limit credit risk.

[0000320193-24-000123:notes:65]
Vendor Non-Trade Receivables

[0000320193-24-000123:notes:66]
The Company has non-trade receivables from certain of its manufacturing vendors resulting from the sale of components to these vendors who manufacture subassemblies or assemble final products for the Company. The Company purchases these components directly from suppliers. The Company does not reflect the sale of these components in products net sales. Rather, the Company recognizes any gain on these sales as a reduction of products cost of sales when the related final products are sold by the Company. As of September 28, 2024, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 44% and 23%. As of September 30, 2023, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 48% and 23%.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000320193-24-000123:notes:67]
Property, Plant and Equipment
The following table shows the Company’s gross property, plant and equipment by major asset class and accumulated depreciation as of September 28, 2024 and September 30, 2023 (in millions):

[0000320193-24-000123:notes:68]
|  | 2024 |  | 2023 |
| Land and buildings | $ | 24,690 |  |  | $ | 23,446 |  |
| Machinery, equipment and internal-use software | 80,205 |  |  | 78,314 |  |
| Leasehold improvements | 14,233 |  |  | 12,839 |  |
| Gross property, plant and equipment | 119,128 |  |  | 114,599 |  |
| Accumulated depreciation | (73,448) |  |  | (70,884) |  |
| Total property, plant and equipment, net | $ | 45,680 |  |  | $ | 43,715 |  |

[0000320193-24-000123:notes:69]
Depreciation expense on property, plant and equipment was $8.2 billion, $8.5 billion and $8.7 billion during 2024, 2023 and 2022, respectively.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000320193-24-000123:notes:70]
Consolidated Financial Statement Details
The following tables show the Company’s consolidated financial statement details as of September 28, 2024 and September 30, 2023 (in millions):

[0000320193-24-000123:notes:71]
Other Non-Current Assets

[0000320193-24-000123:notes:72]
|  | 2024 |  | 2023 |
| Deferred tax assets | $ | 19,499 |  |  | $ | 17,852 |  |
| Other non-current assets | 55,335 |  |  | 46,906 |  |
| Total other non-current assets | $ | 74,834 |  |  | $ | 64,758 |  |

[0000320193-24-000123:notes:73]
Other Current Liabilities

[0000320193-24-000123:notes:74]
|  | 2024 |  | 2023 |
| Income taxes payable | $ | 26,601 |  |  | $ | 8,819 |  |
| Other current liabilities | 51,703 |  |  | 50,010 |  |
| Total other current liabilities | $ | 78,304 |  |  | $ | 58,829 |  |

[0000320193-24-000123:notes:75]
Other Non-Current Liabilities

[0000320193-24-000123:notes:76]
|  | 2024 |  | 2023 |
| Income taxes payable | $ | 9,254 |  |  | $ | 15,457 |  |
| Other non-current liabilities | 36,634 |  |  | 34,391 |  |
| Total other non-current liabilities | $ | 45,888 |  |  | $ | 49,848 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000320193-24-000123:notes:77]
Income Taxes
European Commission State Aid Decision

[0000320193-24-000123:notes:78]
On August 30, 2016, the Commission announced its decision that Ireland granted state aid to the Company by providing tax opinions in 1991 and 2007 concerning the tax allocation of profits of the Irish branches of two subsidiaries of the Company (the “State Aid Decision”). The State Aid Decision ordered Ireland to calculate and recover additional taxes from the Company for the period June 2003 through December 2014. Irish legislative changes, effective as of January 2015, eliminated the application of the tax opinions from that date forward. The recovery amount was calculated to be €13.1 billion, plus interest of €1.2 billion.

[0000320193-24-000123:notes:79]
From time to time, the Company requested approval from the Irish Minister for Finance to reduce the recovery amount for certain taxes paid to other countries. As of September 28, 2024, the adjusted recovery amount of €12.7 billion plus interest of €1.2 billion was held in escrow and restricted from general use. The total balance of the escrow, including net unrealized investment gains, was €14.2 billion or $15.8 billion as of September 28, 2024, of which $2.6 billion was classified as cash and cash equivalents and $13.2 billion was classified as current marketable securities in the Consolidated Balance Sheet. Refer to the Cash, Cash Equivalents and Marketable Securities section of Note 4, “Financial Instruments” for more information.

[0000320193-24-000123:notes:80]
The Company and Ireland appealed the State Aid Decision to the General Court of the Court of Justice of the European Union (the “General Court”). On July 15, 2020, the General Court annulled the State Aid Decision. On September 25, 2020, the Commission appealed the General Court’s decision to the European Court of Justice (the “ECJ”) and a hearing was held on May 23, 2023. On September 10, 2024, the ECJ announced that it had set aside the 2020 judgment of the General Court and confirmed the Commission’s 2016 State Aid Decision. As a result, during the fourth quarter of 2024 the Company recorded a one-time income tax charge of $10.2 billion, net, which represents $15.8 billion payable to Ireland via release of the escrow, partially offset by a U.S. foreign tax credit of $4.8 billion and a decrease in unrecognized tax benefits of $823 million.

[0000320193-24-000123:notes:81]
Provision for Income Taxes and Effective Tax Rate

[0000320193-24-000123:notes:82]
The provision for income taxes for 2024, 2023 and 2022, consisted of the following (in millions):

[0000320193-24-000123:notes:83]
|  | 2024 |  | 2023 |  | 2022 |
| Federal: |  |  |  |  |  |
| Current | $ | 5,571 |  |  | $ | 9,445 |  |  | $ | 7,890 |  |
| Deferred | (3,080) |  |  | (3,644) |  |  | (2,265) |  |
| Total | 2,491 |  |  | 5,801 |  |  | 5,625 |  |
| State: |  |  |  |  |  |
| Current | 1,726 |  |  | 1,570 |  |  | 1,519 |  |
| Deferred | (298) |  |  | (49) |  |  | 84 |  |
| Total | 1,428 |  |  | 1,521 |  |  | 1,603 |  |
| Foreign: |  |  |  |  |  |
| Current | 25,483 |  |  | 8,750 |  |  | 8,996 |  |
| Deferred | 347 |  |  | 669 |  |  | 3,076 |  |
| Total | 25,830 |  |  | 9,419 |  |  | 12,072 |  |
| Provision for income taxes | $ | 29,749 |  |  | $ | 16,741 |  |  | $ | 19,300 |  |

[0000320193-24-000123:notes:84]
Foreign pretax earnings were $77.3 billion, $72.9 billion and $71.3 billion in 2024, 2023 and 2022, respectively.

[0000320193-24-000123:notes:85]
A reconciliation of the provision for income taxes to the amount computed by applying the statutory federal income tax rate (21% in 2024, 2023 and 2022) to income before provision for income taxes for 2024, 2023 and 2022, is as follows (dollars in millions):

[0000320193-24-000123:notes:86]
|  | 2024 |  | 2023 |  | 2022 |
| Computed expected tax | $ | 25,932 |  |  | $ | 23,885 |  |  | $ | 25,012 |  |
| State taxes, net of federal effect | 1,162 |  |  | 1,124 |  |  | 1,518 |  |
| Impact of the State Aid Decision | 10,246 |  |  | — |  |  | — |  |
| Earnings of foreign subsidiaries | (5,311) |  |  | (5,744) |  |  | (4,366) |  |
| Research and development credit, net | (1,397) |  |  | (1,212) |  |  | (1,153) |  |
| Excess tax benefits from equity awards | (893) |  |  | (1,120) |  |  | (1,871) |  |
| Other | 10 |  |  | (192) |  |  | 160 |  |
| Provision for income taxes | $ | 29,749 |  |  | $ | 16,741 |  |  | $ | 19,300 |  |
| Effective tax rate | 24.1 | % |  | 14.7 | % |  | 16.2 | % |

[0000320193-24-000123:notes:87]
Deferred Tax Assets and Liabilities

[0000320193-24-000123:notes:88]
As of September 28, 2024 and September 30, 2023, the significant components of the Company’s deferred tax assets and liabilities were (in millions):

[0000320193-24-000123:notes:89]
|  | 2024 |  | 2023 |
| Deferred tax assets: |  |  |  |
| Capitalized research and development | $ | 10,739 |  |  | $ | 6,294 |  |
| Tax credit carryforwards | 8,856 |  |  | 8,302 |  |
| Accrued liabilities and other reserves | 6,114 |  |  | 6,365 |  |
| Deferred revenue | 3,413 |  |  | 4,571 |  |
| Lease liabilities | 2,410 |  |  | 2,421 |  |
| Unrealized losses | 1,173 |  |  | 2,447 |  |
| Other | 2,168 |  |  | 2,343 |  |
| Total deferred tax assets | 34,873 |  |  | 32,743 |  |
| Less: Valuation allowance | (8,866) |  |  | (8,374) |  |
| Total deferred tax assets, net | 26,007 |  |  | 24,369 |  |
| Deferred tax liabilities: |  |  |  |
| Depreciation | 2,551 |  |  | 1,998 |  |
| Right-of-use assets | 2,125 |  |  | 2,179 |  |
| Minimum tax on foreign earnings | 1,674 |  |  | 1,940 |  |
| Unrealized gains | — |  |  | 511 |  |
| Other | 455 |  |  | 490 |  |
| Total deferred tax liabilities | 6,805 |  |  | 7,118 |  |
| Net deferred tax assets | $ | 19,202 |  |  | $ | 17,251 |  |

[0000320193-24-000123:notes:90]
As of September 28, 2024, the Company had $5.1 billion in foreign tax credit carryforwards in Ireland and $3.6 billion in California R&D credit carryforwards, both of which can be carried forward indefinitely. A valuation allowance has been recorded for the credit carryforwards and a portion of other temporary differences.

[0000320193-24-000123:notes:91]
Uncertain Tax Positions

[0000320193-24-000123:notes:92]
As of September 28, 2024, the total amount of gross unrecognized tax benefits was $22.0 billion, of which $10.8 billion, if recognized, would impact the Company’s effective tax rate. As of September 30, 2023, the total amount of gross unrecognized tax benefits was $19.5 billion, of which $9.5 billion, if recognized, would have impacted the Company’s effective tax rate.

[0000320193-24-000123:notes:93]
The aggregate change in the balance of gross unrecognized tax benefits, which excludes interest and penalties, for 2024, 2023 and 2022, is as follows (in millions):

[0000320193-24-000123:notes:94]
|  | 2024 |  | 2023 |  | 2022 |
| Beginning balances | $ | 19,454 |  |  | $ | 16,758 |  |  | $ | 15,477 |  |
| Increases related to tax positions taken during a prior year | 1,727 |  |  | 2,044 |  |  | 2,284 |  |
| Decreases related to tax positions taken during a prior year | (386) |  |  | (1,463) |  |  | (1,982) |  |
| Increases related to tax positions taken during the current year | 2,542 |  |  | 2,628 |  |  | 1,936 |  |
| Decreases related to settlements with taxing authorities | (1,070) |  |  | (19) |  |  | (28) |  |
| Decreases related to expiration of the statute of limitations | (229) |  |  | (494) |  |  | (929) |  |
| Ending balances | $ | 22,038 |  |  | $ | 19,454 |  |  | $ | 16,758 |  |

[0000320193-24-000123:notes:95]
The Company is subject to taxation and files income tax returns in the U.S. federal jurisdiction and many state and foreign jurisdictions. Tax years after 2017 for the U.S. federal jurisdiction, and after 2014 in certain major foreign jurisdictions, remain subject to examination. Although the timing of resolution or closure of examinations is not certain, the Company believes it is reasonably possible that its gross unrecognized tax benefits could decrease between approximately $5 billion and $13 billion in the next 12 months, primarily related to intercompany transfer pricing and deemed repatriation tax.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000320193-24-000123:notes:96]
Leases
The Company has lease arrangements for certain equipment and facilities, including corporate, data center, manufacturing and retail space. These leases typically have original terms not exceeding 10 years and generally contain multiyear renewal options, some of which are reasonably certain of exercise.

[0000320193-24-000123:notes:97]
Payments under the Company’s lease arrangements may be fixed or variable, and variable lease payments are primarily based on purchases of output of the underlying leased assets. Lease costs associated with fixed payments on the Company’s operating leases were $2.0 billion for both 2024 and 2023 and $1.9 billion for 2022. Lease costs associated with variable payments on the Company’s leases were $13.8 billion, $13.9 billion and $14.9 billion for 2024, 2023 and 2022, respectively.

[0000320193-24-000123:notes:98]
The Company made fixed cash payments related to operating leases of $1.9 billion in both 2024 and 2023 and $1.8 billion in 2022. Noncash activities involving right-of-use (“ROU”) assets obtained in exchange for lease liabilities were $1.0 billion, $2.1 billion and $2.8 billion for 2024, 2023 and 2022, respectively.

[0000320193-24-000123:notes:99]
The following table shows ROU assets and lease liabilities, and the associated financial statement line items, as of September 28, 2024 and September 30, 2023 (in millions):

[0000320193-24-000123:notes:100]
| Lease-Related Assets and Liabilities |  | Financial Statement Line Items |  | 2024 |  | 2023 |  |  |
| Right-of-use assets: |  |  |  |  |  |  |  |  |
| Operating leases |  | Other non-current assets |  | $ | 10,234 |  |  | $ | 10,661 |  |  |  |
| Finance leases |  | Property, plant and equipment, net |  | 1,069 |  |  | 1,015 |  |  |  |
| Total right-of-use assets |  |  |  | $ | 11,303 |  |  | $ | 11,676 |  |  |  |
| Lease liabilities: |  |  |  |  |  |  |  |  |
| Operating leases |  | Other current liabilities |  | $ | 1,488 |  |  | $ | 1,410 |  |  |  |
|  |  | Other non-current liabilities |  | 10,046 |  |  | 10,408 |  |  |  |
| Finance leases |  | Other current liabilities |  | 144 |  |  | 165 |  |  |  |
|  |  | Other non-current liabilities |  | 752 |  |  | 859 |  |  |  |
| Total lease liabilities |  |  |  | $ | 12,430 |  |  | $ | 12,842 |  |  |  |

[0000320193-24-000123:notes:101]
Lease liability maturities as of September 28, 2024, are as follows (in millions):

[0000320193-24-000123:notes:102]
|  | OperatingLeases |  | FinanceLeases |  | Total |
| 2025 | $ | 1,820 |  |  | $ | 171 |  |  | $ | 1,991 |  |
| 2026 | 1,914 |  |  | 131 |  |  | 2,045 |  |
| 2027 | 1,674 |  |  | 59 |  |  | 1,733 |  |
| 2028 | 1,360 |  |  | 38 |  |  | 1,398 |  |
| 2029 | 1,187 |  |  | 36 |  |  | 1,223 |  |
| Thereafter | 5,563 |  |  | 837 |  |  | 6,400 |  |
| Total undiscounted liabilities | 13,518 |  |  | 1,272 |  |  | 14,790 |  |
| Less: Imputed interest | (1,984) |  |  | (376) |  |  | (2,360) |  |
| Total lease liabilities | $ | 11,534 |  |  | $ | 896 |  |  | $ | 12,430 |  |

[0000320193-24-000123:notes:103]
The weighted-average remaining lease term related to the Company’s lease liabilities as of September 28, 2024 and September 30, 2023 was 10.3 years and 10.6 years, respectively. The discount rate related to the Company’s lease liabilities as of September 28, 2024 and September 30, 2023 was 3.1% and 3.0%, respectively. The discount rates related to the Company’s lease liabilities are generally based on estimates of the Company’s incremental borrowing rate, as the discount rates implicit in the Company’s leases cannot be readily determined.

[0000320193-24-000123:notes:104]
As of September 28, 2024, the Company had $849 million of fixed payment obligations under additional leases, primarily for corporate facilities and retail space, that had not yet commenced. These leases will commence between 2025 and 2026, with lease terms ranging from less than 1 year to 21 years.


## us-gaap:DebtDisclosureTextBlock

[0000320193-24-000123:notes:105]
Debt
Commercial Paper

[0000320193-24-000123:notes:106]
The Company issues unsecured short-term promissory notes pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of September 28, 2024 and September 30, 2023, the Company had $10.0 billion and $6.0 billion of commercial paper outstanding, respectively, with maturities generally less than nine months. The weighted-average interest rate of the Company’s commercial paper was 5.00% and 5.28% as of September 28, 2024 and September 30, 2023, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of commercial paper for 2024, 2023 and 2022 (in millions):

[0000320193-24-000123:notes:107]
|  | 2024 |  | 2023 |  | 2022 |
| Maturities 90 days or less: |  |  |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | 3,960 |  |  | $ | (1,333) |  |  | $ | 5,264 |  |
| Maturities greater than 90 days: |  |  |  |  |  |
| Proceeds from commercial paper | — |  |  | — |  |  | 5,948 |  |
| Repayments of commercial paper | — |  |  | (2,645) |  |  | (7,257) |  |
| Proceeds from/(Repayments of) commercial paper, net | — |  |  | (2,645) |  |  | (1,309) |  |
| Total proceeds from/(repayments of) commercial paper, net | $ | 3,960 |  |  | $ | (3,978) |  |  | $ | 3,955 |  |

[0000320193-24-000123:notes:108]
Term Debt

[0000320193-24-000123:notes:109]
The Company has outstanding Notes, which are senior unsecured obligations with interest payable in arrears. The following table provides a summary of the Company’s term debt as of September 28, 2024 and September 30, 2023:

[0000320193-24-000123:notes:110]
|  | Maturities(calendar year) |  | 2024 |  | 2023 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 – 2023 debt issuances: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.000% – 4.850% notes | 2024 – 2062 |  | $ | 97,341 |  |  | 0.03% – 6.65% |  | $ | 106,572 |  |  | 0.03% – 6.72% |
| Total term debt principal |  |  | 97,341 |  |  |  |  | 106,572 |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  | (321) |  |  |  |  | (356) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (358) |  |  |  |  | (1,113) |  |  |  |
| Total term debt |  |  | 96,662 |  |  |  |  | 105,103 |  |  |  |
| Less: Current portion of term debt |  |  | (10,912) |  |  |  |  | (9,822) |  |  |  |
| Total non-current portion of term debt |  |  | $ | 85,750 |  |  |  |  | $ | 95,281 |  |  |  |

[0000320193-24-000123:notes:111]
To manage interest rate risk on certain of its U.S. dollar–denominated fixed-rate notes, the Company uses interest rate swaps to effectively convert the fixed interest rates to floating interest rates on a portion of these notes. Additionally, to manage foreign exchange rate risk on certain of its foreign currency–denominated notes, the Company uses cross-currency swaps to effectively convert these notes to U.S. dollar–denominated notes.

[0000320193-24-000123:notes:112]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging.

[0000320193-24-000123:notes:113]
The future principal payments for the Company’s Notes as of September 28, 2024, are as follows (in millions):

[0000320193-24-000123:notes:114]
| 2025 | $ | 10,930 |  |
| 2026 | 12,342 |  |
| 2027 | 9,936 |  |
| 2028 | 7,800 |  |
| 2029 | 5,153 |  |
| Thereafter | 51,180 |  |
| Total term debt principal | $ | 97,341 |  |

[0000320193-24-000123:notes:115]
As of September 28, 2024 and September 30, 2023, the fair value of the Company’s Notes, based on Level 2 inputs, was $88.4 billion and $90.8 billion, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000320193-24-000123:notes:116]
Shareholders’ Equity
Share Repurchase Program

[0000320193-24-000123:notes:117]
During 2024, the Company repurchased 499 million shares of its common stock for $95.0 billion. The Company’s share repurchase programs do not obligate the Company to acquire a minimum amount of shares. Under the programs, shares may be repurchased in privately negotiated or open market transactions, including under plans complying with Rule 10b5-1 under the Exchange Act.

[0000320193-24-000123:notes:118]
Shares of Common Stock

[0000320193-24-000123:notes:119]
The following table shows the changes in shares of common stock for 2024, 2023 and 2022 (in thousands):

[0000320193-24-000123:notes:120]
|  | 2024 |  | 2023 |  | 2022 |
| Common stock outstanding, beginning balances | 15,550,061 |  |  | 15,943,425 |  |  | 16,426,786 |  |
| Common stock repurchased | (499,372) |  |  | (471,419) |  |  | (568,589) |  |
| Common stock issued, net of shares withheld for employee taxes | 66,097 |  |  | 78,055 |  |  | 85,228 |  |
| Common stock outstanding, ending balances | 15,116,786 |  |  | 15,550,061 |  |  | 15,943,425 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000320193-24-000123:notes:121]
Share-Based Compensation
2022 Employee Stock Plan

[0000320193-24-000123:notes:122]
The Apple Inc. 2022 Employee Stock Plan (the “2022 Plan”) is a shareholder-approved plan that provides for broad-based equity grants to employees, including executive officers, and permits the granting of RSUs, stock grants, performance-based awards, stock options and stock appreciation rights. RSUs granted under the 2022 Plan generally vest over four years, based on continued employment, and are settled upon vesting in shares of the Company’s common stock on a one-for-one basis. All RSUs granted under the 2022 Plan have dividend equivalent rights, which entitle holders of RSUs to the same dividend value per share as holders of common stock. A maximum of approximately 1.3 billion shares were authorized for issuance pursuant to 2022 Plan awards at the time the plan was approved on March 4, 2022.

[0000320193-24-000123:notes:123]
2014 Employee Stock Plan

[0000320193-24-000123:notes:124]
The Apple Inc. 2014 Employee Stock Plan, as amended and restated (the “2014 Plan”), is a shareholder-approved plan that provided for broad-based equity grants to employees, including executive officers. The 2014 Plan permitted the granting of the same types of equity awards with substantially the same terms as the 2022 Plan. The 2014 Plan also permitted the granting of cash bonus awards. In the third quarter of 2022, the Company terminated the authority to grant new awards under the 2014 Plan.

[0000320193-24-000123:notes:125]
Restricted Stock Units

[0000320193-24-000123:notes:126]
A summary of the Company’s RSU activity and related information for 2024, 2023 and 2022, is as follows:

[0000320193-24-000123:notes:127]
|  | Number ofRSUs(in thousands) |  | Weighted-AverageGrant-Date FairValue Per RSU |  | AggregateFair Value(in millions) |
| Balance as of September 25, 2021 | 240,427 |  |  | $ | 75.16 |  |  |  |
| RSUs granted | 91,674 |  |  | $ | 150.70 |  |  |  |
| RSUs vested | (115,861) |  |  | $ | 72.12 |  |  |  |
| RSUs canceled | (14,739) |  |  | $ | 99.77 |  |  |  |
| Balance as of September 24, 2022 | 201,501 |  |  | $ | 109.48 |  |  |  |
| RSUs granted | 88,768 |  |  | $ | 150.87 |  |  |  |
| RSUs vested | (101,878) |  |  | $ | 97.31 |  |  |  |
| RSUs canceled | (8,144) |  |  | $ | 127.98 |  |  |  |
| Balance as of September 30, 2023 | 180,247 |  |  | $ | 135.91 |  |  |  |
| RSUs granted | 80,456 |  |  | $ | 173.78 |  |  |  |
| RSUs vested | (87,633) |  |  | $ | 127.59 |  |  |  |
| RSUs canceled | (9,744) |  |  | $ | 140.80 |  |  |  |
| Balance as of September 28, 2024 | 163,326 |  |  | $ | 158.73 |  |  | $ | 37,204 |  |

[0000320193-24-000123:notes:128]
The fair value as of the respective vesting dates of RSUs was $15.8 billion, $15.9 billion and $18.2 billion for 2024, 2023 and 2022, respectively. The majority of RSUs that vested in 2024, 2023 and 2022 were net share settled such that the Company withheld shares with a value equivalent to the employees’ obligation for the applicable income and other employment taxes, and remitted cash to the appropriate taxing authorities. The total shares withheld were approximately 31 million, 37 million and 41 million for 2024, 2023 and 2022, respectively, and were based on the value of the RSUs on their respective vesting dates as determined by the Company’s closing stock price. Total payments to taxing authorities for employees’ tax obligations were $5.6 billion in both 2024 and 2023 and $6.4 billion in 2022.

[0000320193-24-000123:notes:129]
The following table shows share-based compensation expense and the related income tax benefit included in the Consolidated Statements of Operations for 2024, 2023 and 2022 (in millions):

[0000320193-24-000123:notes:130]
|  | 2024 |  | 2023 |  | 2022 |
| Share-based compensation expense | $ | 11,688 |  |  | $ | 10,833 |  |  | $ | 9,038 |  |
| Income tax benefit related to share-based compensation expense | $ | (3,350) |  |  | $ | (3,421) |  |  | $ | (4,002) |  |

[0000320193-24-000123:notes:131]
As of September 28, 2024, the total unrecognized compensation cost related to outstanding RSUs was $19.4 billion, which the Company expects to recognize over a weighted-average period of 2.4 years.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000320193-24-000123:notes:132]
Commitments, Contingencies and Supply Concentrations
Unconditional Purchase Obligations

[0000320193-24-000123:notes:133]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of supplier arrangements, licensed intellectual property and content, and distribution rights. Future payments under unconditional purchase obligations with a remaining term in excess of one year as of September 28, 2024, are as follows (in millions):

[0000320193-24-000123:notes:134]
| 2025 | $ | 3,206 |  |
| 2026 | 2,440 |  |
| 2027 | 1,156 |  |
| 2028 | 3,121 |  |
| 2029 | 633 |  |
| Thereafter | 670 |  |
| Total | $ | 11,226 |  |

[0000320193-24-000123:notes:135]
Contingencies

[0000320193-24-000123:notes:136]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully resolved. The outcome of litigation is inherently uncertain. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss greater than a recorded accrual, concerning loss contingencies for asserted legal and other claims.

[0000320193-24-000123:notes:137]
Concentrations in the Available Sources of Supply of Materials and Product

[0000320193-24-000123:notes:138]
Although most components essential to the Company’s business are generally available from multiple sources, certain components are currently obtained from single or limited sources. The Company also competes for various components with other participants in the markets for smartphones, personal computers, tablets, wearables and accessories. Therefore, many components used by the Company, including those that are available from multiple sources, are at times subject to industry-wide shortage and significant commodity pricing fluctuations.

[0000320193-24-000123:notes:139]
The Company uses some custom components that are not commonly used by its competitors, and new products introduced by the Company often utilize custom components available from only one source. When a component or product uses new technologies, initial capacity constraints may exist until the suppliers’ yields have matured or their manufacturing capacities have increased. The continued availability of these components at acceptable prices, or at all, may be affected if suppliers decide to concentrate on the production of common components instead of components customized to meet the Company’s requirements.

[0000320193-24-000123:notes:140]
Substantially all of the Company’s hardware products are manufactured by outsourcing partners that are located primarily in China mainland, India, Japan, South Korea, Taiwan and Vietnam.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000320193-24-000123:notes:141]
Segment Information and Geographic Data
The Company manages its business primarily on a geographic basis. The Company’s reportable segments consist of the Americas, Europe, Greater China, Japan and Rest of Asia Pacific. Americas includes both North and South America. Europe includes European countries, as well as India, the Middle East and Africa. Greater China includes China mainland, Hong Kong and Taiwan. Rest of Asia Pacific includes Australia and those Asian countries not included in the Company’s other reportable segments. Although the reportable segments provide similar hardware and software products and similar services, each one is managed separately to better align with the location of the Company’s customers and distribution partners and the unique market dynamics of each geographic region.

[0000320193-24-000123:notes:142]
The Company evaluates the performance of its reportable segments based on net sales and operating income. Net sales for geographic segments are generally based on the location of customers and sales through the Company’s retail stores located in those geographic locations. Operating income for each segment consists of net sales to third parties, related cost of sales, and operating expenses directly attributable to the segment. The information provided to the Company’s chief operating decision maker for purposes of making decisions and assessing segment performance excludes asset information.

[0000320193-24-000123:notes:143]
The following table shows information by reportable segment for 2024, 2023 and 2022 (in millions):

[0000320193-24-000123:notes:144]
|  | 2024 |  | 2023 |  | 2022 |
| Americas: |  |  |  |  |  |
| Net sales | $ | 167,045 |  |  | $ | 162,560 |  |  | $ | 169,658 |  |
| Operating income | $ | 67,656 |  |  | $ | 60,508 |  |  | $ | 62,683 |  |
| Europe: |  |  |  |  |  |
| Net sales | $ | 101,328 |  |  | $ | 94,294 |  |  | $ | 95,118 |  |
| Operating income | $ | 41,790 |  |  | $ | 36,098 |  |  | $ | 35,233 |  |
| Greater China: |  |  |  |  |  |
| Net sales | $ | 66,952 |  |  | $ | 72,559 |  |  | $ | 74,200 |  |
| Operating income | $ | 27,082 |  |  | $ | 30,328 |  |  | $ | 31,153 |  |
| Japan: |  |  |  |  |  |
| Net sales | $ | 25,052 |  |  | $ | 24,257 |  |  | $ | 25,977 |  |
| Operating income | $ | 12,454 |  |  | $ | 11,888 |  |  | $ | 12,257 |  |
| Rest of Asia Pacific: |  |  |  |  |  |
| Net sales | $ | 30,658 |  |  | $ | 29,615 |  |  | $ | 29,375 |  |
| Operating income | $ | 13,062 |  |  | $ | 12,066 |  |  | $ | 11,569 |  |

[0000320193-24-000123:notes:145]
A reconciliation of the Company’s segment operating income to the Consolidated Statements of Operations for 2024, 2023 and 2022 is as follows (in millions):

[0000320193-24-000123:notes:146]
|  | 2024 |  | 2023 |  | 2022 |
| Segment operating income | $ | 162,044 |  |  | $ | 150,888 |  |  | $ | 152,895 |  |
| Research and development expense | (31,370) |  |  | (29,915) |  |  | (26,251) |  |
| Other corporate expenses, net (1) | (7,458) |  |  | (6,672) |  |  | (7,207) |  |
| Total operating income | $ | 123,216 |  |  | $ | 114,301 |  |  | $ | 119,437 |  |

[0000320193-24-000123:notes:147]
(1)Includes general and administrative compensation costs, various nonrecurring charges, and other separately managed costs.

[0000320193-24-000123:notes:148]
The following tables show net sales for 2024, 2023 and 2022 and long-lived assets as of September 28, 2024 and September 30, 2023 for countries that individually accounted for 10% or more of the respective totals, as well as aggregate amounts for the remaining countries (in millions):

[0000320193-24-000123:notes:149]
|  | 2024 |  | 2023 |  | 2022 |
| Net sales: |  |  |  |  |  |
| U.S. | $ | 142,196 |  |  | $ | 138,573 |  |  | $ | 147,859 |  |
| China (1) | 66,952 |  |  | 72,559 |  |  | 74,200 |  |
| Other countries | 181,887 |  |  | 172,153 |  |  | 172,269 |  |
| Total net sales | $ | 391,035 |  |  | $ | 383,285 |  |  | $ | 394,328 |  |

[0000320193-24-000123:notes:150]
|  | 2024 |  | 2023 |
| Long-lived assets: |  |  |  |
| U.S. | $ | 35,664 |  |  | $ | 33,276 |  |
| China (1) | 4,797 |  |  | 5,778 |  |
| Other countries | 5,219 |  |  | 4,661 |  |
| Total long-lived assets | $ | 45,680 |  |  | $ | 43,715 |  |

[0000320193-24-000123:notes:151]
(1)China includes Hong Kong and Taiwan.


## ecd:MtrlTermsOfTrdArrTextBlock

[0000320193-24-000123:notes:152]
On August 27, 2024, Deirdre O’Brien, the Company’s Senior Vice President, Retail, entered into a trading plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act. The plan provides for the sale, subject to certain price limits, of shares vesting between April 1, 2025 and October 1, 2026, pursuant to certain equity awards granted to Ms. O’Brien, excluding any shares withheld by the Company to satisfy income tax withholding and remittance obligations. Ms. O’Brien’s plan will expire on December 31, 2026, subject to early termination in accordance with the terms of the plan.

[0000320193-24-000123:notes:153]
On August 29, 2024, Jeff Williams, the Company’s Chief Operating Officer, entered into a trading plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act. The plan provides for the sale, subject to certain price limits, of up to 100,000 shares of common stock, as well as shares vesting between April 1, 2025 and October 1, 2025, pursuant to certain equity awards granted to Mr. Williams, excluding any shares withheld by the Company to satisfy income tax withholding and remittance obligations. Mr. Williams’ plan will expire on December 15, 2025, subject to early termination in accordance with the terms of the plan.
