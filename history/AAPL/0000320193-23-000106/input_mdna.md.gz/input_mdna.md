# AAPL MD&A — 0000320193-23-000106


## mdna

[0000320193-23-000106:mdna:1]
Item 7.    Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000320193-23-000106:mdna:2]
The following discussion should be read in conjunction with the consolidated financial statements and accompanying notes included in Part II, Item 8 of this Form 10-K. This Item generally discusses 2023 and 2022 items and year-to-year comparisons between 2023 and 2022. Discussions of 2021 items and year-to-year comparisons between 2022 and 2021 are not included, and can be found in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in Part II, Item 7 of the Company’s Annual Report on Form 10-K for the fiscal year ended September 24, 2022.

[0000320193-23-000106:mdna:3]
Fiscal Period

[0000320193-23-000106:mdna:4]
The Company’s fiscal year is the 52- or 53-week period that ends on the last Saturday of September. An additional week is included in the first fiscal quarter every five or six years to realign the Company’s fiscal quarters with calendar quarters, which occurred in the first quarter of 2023. The Company’s fiscal year 2023 spanned 53 weeks, whereas fiscal years 2022 and 2021 spanned 52 weeks each.

[0000320193-23-000106:mdna:5]
Fiscal Year Highlights

[0000320193-23-000106:mdna:6]
The Company’s total net sales were $383.3 billion and net income was $97.0 billion during 2023.

[0000320193-23-000106:mdna:7]
The Company’s total net sales decreased 3% or $11.0 billion during 2023 compared to 2022. The weakness in foreign currencies relative to the U.S. dollar accounted for more than the entire year-over-year decrease in total net sales, which consisted primarily of lower net sales of Mac and iPhone, partially offset by higher net sales of Services.

[0000320193-23-000106:mdna:8]
The Company announces new product, service and software offerings at various times during the year. Significant announcements during fiscal year 2023 included the following:

[0000320193-23-000106:mdna:9]
First Quarter 2023:

[0000320193-23-000106:mdna:10]
•iPad and iPad Pro;

[0000320193-23-000106:mdna:11]
•Next-generation Apple TV 4K; and

[0000320193-23-000106:mdna:12]
•MLS Season Pass, a Major League Soccer subscription streaming service.

[0000320193-23-000106:mdna:13]
Second Quarter 2023:

[0000320193-23-000106:mdna:14]
•MacBook Pro 14”, MacBook Pro 16” and Mac mini; and

[0000320193-23-000106:mdna:15]
•Second-generation HomePod.

[0000320193-23-000106:mdna:16]
Third Quarter 2023:

[0000320193-23-000106:mdna:17]
•MacBook Air 15”, Mac Studio and Mac Pro;

[0000320193-23-000106:mdna:18]
•Apple Vision Pro™, the Company’s first spatial computer featuring its new visionOS™, expected to be available in early calendar year 2024; and

[0000320193-23-000106:mdna:19]
•iOS 17, macOS Sonoma, iPadOS 17, tvOS 17 and watchOS 10, updates to the Company’s operating systems.

[0000320193-23-000106:mdna:20]
Fourth Quarter 2023:

[0000320193-23-000106:mdna:21]
•iPhone 15, iPhone 15 Plus, iPhone 15 Pro and iPhone 15 Pro Max; and

[0000320193-23-000106:mdna:22]
•Apple Watch Series 9 and Apple Watch Ultra 2.

[0000320193-23-000106:mdna:23]
In May 2023, the Company announced a new share repurchase program of up to $90 billion and raised its quarterly dividend from $0.23 to $0.24 per share beginning in May 2023. During 2023, the Company repurchased $76.6 billion of its common stock and paid dividends and dividend equivalents of $15.0 billion.

[0000320193-23-000106:mdna:24]
Macroeconomic Conditions

[0000320193-23-000106:mdna:25]
Macroeconomic conditions, including inflation, changes in interest rates, and currency fluctuations, have directly and indirectly impacted, and could in the future materially impact, the Company’s results of operations and financial condition.

[0000320193-23-000106:mdna:26]
Segment Operating Performance

[0000320193-23-000106:mdna:27]
The following table shows net sales by reportable segment for 2023, 2022 and 2021 (dollars in millions):

[0000320193-23-000106:mdna:28]
|  | 2023 |  | Change |  | 2022 |  | Change |  | 2021 |
| Net sales by reportable segment: |  |  |  |  |  |  |  |  |  |
| Americas | $ | 162,560 |  |  | (4) | % |  | $ | 169,658 |  |  | 11 | % |  | $ | 153,306 |  |
| Europe | 94,294 |  |  | (1) | % |  | 95,118 |  |  | 7 | % |  | 89,307 |  |
| Greater China | 72,559 |  |  | (2) | % |  | 74,200 |  |  | 9 | % |  | 68,366 |  |
| Japan | 24,257 |  |  | (7) | % |  | 25,977 |  |  | (9) | % |  | 28,482 |  |
| Rest of Asia Pacific | 29,615 |  |  | 1 | % |  | 29,375 |  |  | 11 | % |  | 26,356 |  |
| Total net sales | $ | 383,285 |  |  | (3) | % |  | $ | 394,328 |  |  | 8 | % |  | $ | 365,817 |  |

[0000320193-23-000106:mdna:29]
Americas

[0000320193-23-000106:mdna:30]
Americas net sales decreased 4% or $7.1 billion during 2023 compared to 2022 due to lower net sales of iPhone and Mac, partially offset by higher net sales of Services.

[0000320193-23-000106:mdna:31]
Europe

[0000320193-23-000106:mdna:32]
Europe net sales decreased 1% or $824 million during 2023 compared to 2022. The weakness in foreign currencies relative to the U.S. dollar accounted for more than the entire year-over-year decrease in Europe net sales, which consisted primarily of lower net sales of Mac and Wearables, Home and Accessories, partially offset by higher net sales of iPhone and Services.

[0000320193-23-000106:mdna:33]
Greater China

[0000320193-23-000106:mdna:34]
Greater China net sales decreased 2% or $1.6 billion during 2023 compared to 2022. The weakness in the renminbi relative to the U.S. dollar accounted for more than the entire year-over-year decrease in Greater China net sales, which consisted primarily of lower net sales of Mac and iPhone.

[0000320193-23-000106:mdna:35]
Japan

[0000320193-23-000106:mdna:36]
Japan net sales decreased 7% or $1.7 billion during 2023 compared to 2022. The weakness in the yen relative to the U.S. dollar accounted for more than the entire year-over-year decrease in Japan net sales, which consisted primarily of lower net sales of iPhone, Wearables, Home and Accessories and Mac.

[0000320193-23-000106:mdna:37]
Rest of Asia Pacific

[0000320193-23-000106:mdna:38]
Rest of Asia Pacific net sales increased 1% or $240 million during 2023 compared to 2022. The weakness in foreign currencies relative to the U.S. dollar had a significantly unfavorable year-over-year impact on Rest of Asia Pacific net sales. The net sales increase consisted of higher net sales of iPhone and Services, partially offset by lower net sales of Mac and iPad.

[0000320193-23-000106:mdna:39]
Products and Services Performance

[0000320193-23-000106:mdna:40]
The following table shows net sales by category for 2023, 2022 and 2021 (dollars in millions):

[0000320193-23-000106:mdna:41]
|  | 2023 |  | Change |  | 2022 |  | Change |  | 2021 |
| Net sales by category: |  |  |  |  |  |  |  |  |  |
| iPhone (1) | $ | 200,583 |  |  | (2) | % |  | $ | 205,489 |  |  | 7 | % |  | $ | 191,973 |  |
| Mac (1) | 29,357 |  |  | (27) | % |  | 40,177 |  |  | 14 | % |  | 35,190 |  |
| iPad (1) | 28,300 |  |  | (3) | % |  | 29,292 |  |  | (8) | % |  | 31,862 |  |
| Wearables, Home and Accessories (1) | 39,845 |  |  | (3) | % |  | 41,241 |  |  | 7 | % |  | 38,367 |  |
| Services (2) | 85,200 |  |  | 9 | % |  | 78,129 |  |  | 14 | % |  | 68,425 |  |
| Total net sales | $ | 383,285 |  |  | (3) | % |  | $ | 394,328 |  |  | 8 | % |  | $ | 365,817 |  |

[0000320193-23-000106:mdna:42]
(1)Products net sales include amortization of the deferred value of unspecified software upgrade rights, which are bundled in the sales price of the respective product.

[0000320193-23-000106:mdna:43]
(2)Services net sales include amortization of the deferred value of services bundled in the sales price of certain products.

[0000320193-23-000106:mdna:44]
iPhone

[0000320193-23-000106:mdna:45]
iPhone net sales decreased 2% or $4.9 billion during 2023 compared to 2022 due to lower net sales of non-Pro iPhone models, partially offset by higher net sales of Pro iPhone models.

[0000320193-23-000106:mdna:46]
Mac

[0000320193-23-000106:mdna:47]
Mac net sales decreased 27% or $10.8 billion during 2023 compared to 2022 due primarily to lower net sales of laptops.

[0000320193-23-000106:mdna:48]
iPad

[0000320193-23-000106:mdna:49]
iPad net sales decreased 3% or $1.0 billion during 2023 compared to 2022 due primarily to lower net sales of iPad mini and iPad Air, partially offset by the combined net sales of iPad 9th and 10th generation.

[0000320193-23-000106:mdna:50]
Wearables, Home and Accessories

[0000320193-23-000106:mdna:51]
Wearables, Home and Accessories net sales decreased 3% or $1.4 billion during 2023 compared to 2022 due primarily to lower net sales of Wearables and Accessories.

[0000320193-23-000106:mdna:52]
Services

[0000320193-23-000106:mdna:53]
Services net sales increased 9% or $7.1 billion during 2023 compared to 2022 due to higher net sales across all lines of business.

[0000320193-23-000106:mdna:54]
Gross Margin

[0000320193-23-000106:mdna:55]
Products and Services gross margin and gross margin percentage for 2023, 2022 and 2021 were as follows (dollars in millions):

[0000320193-23-000106:mdna:56]
|  | 2023 |  | 2022 |  | 2021 |
| Gross margin: |  |  |  |  |  |
| Products | $ | 108,803 |  |  | $ | 114,728 |  |  | $ | 105,126 |  |
| Services | 60,345 |  |  | 56,054 |  |  | 47,710 |  |
| Total gross margin | $ | 169,148 |  |  | $ | 170,782 |  |  | $ | 152,836 |  |

[0000320193-23-000106:mdna:57]
| Gross margin percentage: |  |  |  |  |  |
| Products | 36.5 | % |  | 36.3 | % |  | 35.3 | % |
| Services | 70.8 | % |  | 71.7 | % |  | 69.7 | % |
| Total gross margin percentage | 44.1 | % |  | 43.3 | % |  | 41.8 | % |

[0000320193-23-000106:mdna:58]
Products Gross Margin

[0000320193-23-000106:mdna:59]
Products gross margin decreased during 2023 compared to 2022 due to the weakness in foreign currencies relative to the U.S. dollar and lower Products volume, partially offset by cost savings and a different Products mix.

[0000320193-23-000106:mdna:60]
Products gross margin percentage increased during 2023 compared to 2022 due to cost savings and a different Products mix, partially offset by the weakness in foreign currencies relative to the U.S. dollar and decreased leverage.

[0000320193-23-000106:mdna:61]
Services Gross Margin

[0000320193-23-000106:mdna:62]
Services gross margin increased during 2023 compared to 2022 due primarily to higher Services net sales, partially offset by the weakness in foreign currencies relative to the U.S. dollar and higher Services costs.

[0000320193-23-000106:mdna:63]
Services gross margin percentage decreased during 2023 compared to 2022 due to higher Services costs and the weakness in foreign currencies relative to the U.S. dollar, partially offset by a different Services mix.

[0000320193-23-000106:mdna:64]
The Company’s future gross margins can be impacted by a variety of factors, as discussed in Part I, Item 1A of this Form 10-K under the heading “Risk Factors.” As a result, the Company believes, in general, gross margins will be subject to volatility and downward pressure.

[0000320193-23-000106:mdna:65]
Operating Expenses

[0000320193-23-000106:mdna:66]
Operating expenses for 2023, 2022 and 2021 were as follows (dollars in millions):

[0000320193-23-000106:mdna:67]
|  | 2023 |  | Change |  | 2022 |  | Change |  | 2021 |
| Research and development | $ | 29,915 |  |  | 14 | % |  | $ | 26,251 |  |  | 20 | % |  | $ | 21,914 |  |
| Percentage of total net sales | 8 | % |  |  |  | 7 | % |  |  |  | 6 | % |
| Selling, general and administrative | $ | 24,932 |  |  | (1) | % |  | $ | 25,094 |  |  | 14 | % |  | $ | 21,973 |  |
| Percentage of total net sales | 7 | % |  |  |  | 6 | % |  |  |  | 6 | % |
| Total operating expenses | $ | 54,847 |  |  | 7 | % |  | $ | 51,345 |  |  | 17 | % |  | $ | 43,887 |  |
| Percentage of total net sales | 14 | % |  |  |  | 13 | % |  |  |  | 12 | % |

[0000320193-23-000106:mdna:68]
Research and Development

[0000320193-23-000106:mdna:69]
The year-over-year growth in R&D expense in 2023 was driven primarily by increases in headcount-related expenses.

[0000320193-23-000106:mdna:70]
Selling, General and Administrative

[0000320193-23-000106:mdna:71]
Selling, general and administrative expense was relatively flat in 2023 compared to 2022.

[0000320193-23-000106:mdna:72]
Provision for Income Taxes

[0000320193-23-000106:mdna:73]
Provision for income taxes, effective tax rate and statutory federal income tax rate for 2023, 2022 and 2021 were as follows (dollars in millions):

[0000320193-23-000106:mdna:74]
|  | 2023 |  | 2022 |  | 2021 |
| Provision for income taxes | $ | 16,741 |  |  | $ | 19,300 |  |  | $ | 14,527 |  |
| Effective tax rate | 14.7 | % |  | 16.2 | % |  | 13.3 | % |
| Statutory federal income tax rate | 21 | % |  | 21 | % |  | 21 | % |

[0000320193-23-000106:mdna:75]
The Company’s effective tax rate for 2023 and 2022 was lower than the statutory federal income tax rate due primarily to a lower effective tax rate on foreign earnings, the impact of the U.S. federal R&D credit, and tax benefits from share-based compensation, partially offset by state income taxes.

[0000320193-23-000106:mdna:76]
The Company’s effective tax rate for 2023 was lower compared to 2022 due primarily to a lower effective tax rate on foreign earnings and the impact of U.S. foreign tax credit regulations issued by the U.S. Department of the Treasury in 2022, partially offset by lower tax benefits from share-based compensation.

[0000320193-23-000106:mdna:77]
Liquidity and Capital Resources

[0000320193-23-000106:mdna:78]
The Company believes its balances of cash, cash equivalents and unrestricted marketable securities, which totaled $148.3 billion as of September 30, 2023, along with cash generated by ongoing operations and continued access to debt markets, will be sufficient to satisfy its cash requirements and capital return program over the next 12 months and beyond.

[0000320193-23-000106:mdna:79]
The Company’s material cash requirements include the following contractual obligations:

[0000320193-23-000106:mdna:80]
Debt

[0000320193-23-000106:mdna:81]
As of September 30, 2023, the Company had outstanding fixed-rate notes with varying maturities for an aggregate principal amount of $106.6 billion (collectively the “Notes”), with $9.9 billion payable within 12 months. Future interest payments associated with the Notes total $41.1 billion, with $2.9 billion payable within 12 months.

[0000320193-23-000106:mdna:82]
The Company also issues unsecured short-term promissory notes pursuant to a commercial paper program. As of September 30, 2023, the Company had $6.0 billion of commercial paper outstanding, all of which was payable within 12 months.

[0000320193-23-000106:mdna:83]
Leases

[0000320193-23-000106:mdna:84]
The Company has lease arrangements for certain equipment and facilities, including corporate, data center, manufacturing and retail space. As of September 30, 2023, the Company had fixed lease payment obligations of $15.8 billion, with $2.0 billion payable within 12 months.

[0000320193-23-000106:mdna:85]
Manufacturing Purchase Obligations

[0000320193-23-000106:mdna:86]
The Company utilizes several outsourcing partners to manufacture subassemblies for the Company’s products and to perform final assembly and testing of finished products. The Company also obtains individual components for its products from a wide variety of individual suppliers. As of September 30, 2023, the Company had manufacturing purchase obligations of $53.1 billion, with $52.9 billion payable within 12 months. The Company’s manufacturing purchase obligations are primarily noncancelable.

[0000320193-23-000106:mdna:87]
Other Purchase Obligations

[0000320193-23-000106:mdna:88]
The Company’s other purchase obligations primarily consist of noncancelable obligations to acquire capital assets, including assets related to product manufacturing, and noncancelable obligations related to supplier arrangements, licensed intellectual property and content, and distribution rights. As of September 30, 2023, the Company had other purchase obligations of $21.9 billion, with $5.6 billion payable within 12 months.

[0000320193-23-000106:mdna:89]
Deemed Repatriation Tax Payable

[0000320193-23-000106:mdna:90]
As of September 30, 2023, the balance of the deemed repatriation tax payable imposed by the U.S. Tax Cuts and Jobs Act of 2017 (the “Act”) was $22.0 billion, with $6.5 billion expected to be paid within 12 months.

[0000320193-23-000106:mdna:91]
Capital Return Program

[0000320193-23-000106:mdna:92]
In addition to its contractual cash requirements, the Company has an authorized share repurchase program. The program does not obligate the Company to acquire a minimum amount of shares. As of September 30, 2023, the Company’s quarterly cash dividend was $0.24 per share. The Company intends to increase its dividend on an annual basis, subject to declaration by the Board of Directors.

[0000320193-23-000106:mdna:93]
Critical Accounting Estimates

[0000320193-23-000106:mdna:94]
The preparation of financial statements and related disclosures in conformity with U.S. generally accepted accounting principles (“GAAP”) and the Company’s discussion and analysis of its financial condition and operating results require the Company’s management to make judgments, assumptions and estimates that affect the amounts reported. Note 1, “Summary of Significant Accounting Policies” of the Notes to Consolidated Financial Statements in Part II, Item 8 of this Form 10-K describes the significant accounting policies and methods used in the preparation of the Company’s consolidated financial statements. Management bases its estimates on historical experience and on various other assumptions it believes to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities.

[0000320193-23-000106:mdna:95]
Uncertain Tax Positions

[0000320193-23-000106:mdna:96]
The Company is subject to income taxes in the U.S. and numerous foreign jurisdictions. The evaluation of the Company’s uncertain tax positions involves significant judgment in the interpretation and application of GAAP and complex domestic and international tax laws, including the Act and matters related to the allocation of international taxation rights between countries. Although management believes the Company’s reserves are reasonable, no assurance can be given that the final outcome of these uncertainties will not be different from that which is reflected in the Company’s reserves. Reserves are adjusted considering changing facts and circumstances, such as the closing of a tax examination. Resolution of these uncertainties in a manner inconsistent with management’s expectations could have a material impact on the Company’s financial condition and operating results.

[0000320193-23-000106:mdna:97]
Legal and Other Contingencies

[0000320193-23-000106:mdna:98]
The Company is subject to various legal proceedings and claims that arise in the ordinary course of business, the outcomes of which are inherently uncertain. The Company records a liability when it is probable that a loss has been incurred and the amount is reasonably estimable, the determination of which requires significant judgment. Resolution of legal matters in a manner inconsistent with management’s expectations could have a material impact on the Company’s financial condition and operating results.
