# AAPL notes — 0000320193-23-000106


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000320193-23-000106:notes:1]
Portions of the Registrant’s definitive proxy statement relating to its 2024 annual meeting of shareholders are incorporated by reference into Part III of this Annual Report on Form 10-K where indicated. The Registrant’s definitive proxy statement will be filed with the U.S. Securities and Exchange Commission within 120 days after the end of the fiscal year to which this report relates.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000320193-23-000106:notes:2]
Summary of Significant Accounting Policies
Basis of Presentation and Preparation

[0000320193-23-000106:notes:3]
The consolidated financial statements include the accounts of Apple Inc. and its wholly owned subsidiaries. The preparation of these consolidated financial statements and accompanying notes in conformity with GAAP requires the use of management estimates. Certain prior period amounts in the consolidated financial statements and accompanying notes have been reclassified to conform to the current period’s presentation.

[0000320193-23-000106:notes:4]
The Company’s fiscal year is the 52- or 53-week period that ends on the last Saturday of September. An additional week is included in the first fiscal quarter every five or six years to realign the Company’s fiscal quarters with calendar quarters, which occurred in the first fiscal quarter of 2023. The Company’s fiscal year 2023 spanned 53 weeks, whereas fiscal years 2022 and 2021 spanned 52 weeks each. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in September and the associated quarters, months and periods of those fiscal years.

[0000320193-23-000106:notes:5]
Revenue

[0000320193-23-000106:notes:6]
The Company records revenue net of taxes collected from customers that are remitted to governmental authorities.

[0000320193-23-000106:notes:7]
Share-Based Compensation

[0000320193-23-000106:notes:8]
The Company recognizes share-based compensation expense on a straight-line basis for its estimate of equity awards that will ultimately vest.

[0000320193-23-000106:notes:9]
Cash Equivalents

[0000320193-23-000106:notes:10]
All highly liquid investments with maturities of three months or less at the date of purchase are treated as cash equivalents.

[0000320193-23-000106:notes:11]
Marketable Securities

[0000320193-23-000106:notes:12]
The cost of securities sold is determined using the specific identification method.

[0000320193-23-000106:notes:13]
Inventories

[0000320193-23-000106:notes:14]
Inventories are measured using the first-in, first-out method.

[0000320193-23-000106:notes:15]
Property, Plant and Equipment

[0000320193-23-000106:notes:16]
Depreciation on property, plant and equipment is recognized on a straight-line basis.

[0000320193-23-000106:notes:17]
Derivative Instruments

[0000320193-23-000106:notes:18]
The Company presents derivative assets and liabilities at their gross fair values in the Consolidated Balance Sheets.

[0000320193-23-000106:notes:19]
Income Taxes

[0000320193-23-000106:notes:20]
The Company records certain deferred tax assets and liabilities in connection with the minimum tax on certain foreign earnings created by the Act.

[0000320193-23-000106:notes:21]
Leases

[0000320193-23-000106:notes:22]
The Company combines and accounts for lease and nonlease components as a single lease component for leases of corporate, data center and retail facilities.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0000320193-23-000106:notes:23]
The Company recognizes revenue at the amount to which it expects to be entitled when control of the products or services is transferred to its customers. Control is generally transferred when the Company has a present right to payment and title and the significant risks and rewards of ownership of products or services are transferred to its customers. For most of the Company’s Products net sales, control transfers when products are shipped. For the Company’s Services net sales, control transfers over time as services are delivered. Payment for Products and Services net sales is collected within a short period following transfer of control or commencement of delivery of services, as applicable.

[0000320193-23-000106:notes:24]
The Company records reductions to Products net sales related to future product returns, price protection and other customer incentive programs based on the Company’s expectations and historical experience.

[0000320193-23-000106:notes:25]
For arrangements with multiple performance obligations, which represent promises within an arrangement that are distinct, the Company allocates revenue to all distinct performance obligations based on their relative stand-alone selling prices (“SSPs”). When available, the Company uses observable prices to determine SSPs. When observable prices are not available, SSPs are established that reflect the Company’s best estimates of what the selling prices of the performance obligations would be if they were sold regularly on a stand-alone basis. The Company’s process for estimating SSPs without observable prices considers multiple factors that may vary depending upon the unique facts and circumstances related to each performance obligation including, where applicable, prices charged by the Company for similar offerings, market trends in the pricing for similar offerings, product-specific business objectives and the estimated cost to provide the performance obligation.

[0000320193-23-000106:notes:26]
The Company has identified up to three performance obligations regularly included in arrangements involving the sale of iPhone, Mac, iPad and certain other products. The first performance obligation, which represents the substantial portion of the allocated sales price, is the hardware and bundled software delivered at the time of sale. The second performance obligation is the right to receive certain product-related bundled services, which include iCloud®, Siri® and Maps. The third performance obligation is the right to receive, on a when-and-if-available basis, future unspecified software upgrades relating to the software bundled with each device. The Company allocates revenue and any related discounts to these performance obligations based on their relative SSPs. Because the Company lacks observable prices for the undelivered performance obligations, the allocation of revenue is based on the Company’s estimated SSPs. Revenue allocated to the delivered hardware and bundled software is recognized when control has transferred to the customer, which generally occurs when the product is shipped. Revenue allocated to the product-related bundled services and unspecified software upgrade rights is deferred and recognized on a straight-line basis over the estimated period they are expected to be provided.

[0000320193-23-000106:notes:27]
For certain long-term service arrangements, the Company has performance obligations for services it has not yet delivered. For these arrangements, the Company does not have a right to bill for the undelivered services. The Company has determined that any unbilled consideration relates entirely to the value of the undelivered services. Accordingly, the Company has not recognized revenue, and does not disclose amounts, related to these undelivered services.

[0000320193-23-000106:notes:28]
For the sale of third-party products where the Company obtains control of the product before transferring it to the customer, the Company recognizes revenue based on the gross amount billed to customers. The Company considers multiple factors when determining whether it obtains control of third-party products, including evaluating if it can establish the price of the product, retains inventory risk for tangible products or has the responsibility for ensuring acceptability of the product. For third-party applications sold through the App Store, the Company does not obtain control of the product before transferring it to the customer. Therefore, the Company accounts for all third-party application–related sales on a net basis by recognizing in Services net sales only the commission it retains.


## us-gaap:DerivativesPolicyTextBlock

[0000320193-23-000106:notes:29]
The Company presents derivative assets and liabilities at their gross fair values in the Consolidated Balance Sheets.
The Company classifies cash flows related to derivative instruments in the same section of the Consolidated Statements of Cash Flows as the items being hedged, which are generally classified as operating activities.


## us-gaap:LesseeLeasesPolicyTextBlock

[0000320193-23-000106:notes:30]
The Company combines and accounts for lease and nonlease components as a single lease component for leases of corporate, data center and retail facilities.
The discount rates related to the Company’s lease liabilities are generally based on estimates of the Company’s incremental borrowing rate, as the discount rates implicit in the Company’s leases cannot be readily determined.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000320193-23-000106:notes:31]
Revenue
The Company recognizes revenue at the amount to which it expects to be entitled when control of the products or services is transferred to its customers. Control is generally transferred when the Company has a present right to payment and title and the significant risks and rewards of ownership of products or services are transferred to its customers. For most of the Company’s Products net sales, control transfers when products are shipped. For the Company’s Services net sales, control transfers over time as services are delivered. Payment for Products and Services net sales is collected within a short period following transfer of control or commencement of delivery of services, as applicable.

[0000320193-23-000106:notes:32]
Net sales disaggregated by significant products and services for 2023, 2022 and 2021 were as follows (in millions):

[0000320193-23-000106:notes:33]
|  | 2023 |  | 2022 |  | 2021 |
| iPhone (1) | $ | 200,583 |  |  | $ | 205,489 |  |  | $ | 191,973 |  |
| Mac (1) | 29,357 |  |  | 40,177 |  |  | 35,190 |  |
| iPad (1) | 28,300 |  |  | 29,292 |  |  | 31,862 |  |
| Wearables, Home and Accessories (1) | 39,845 |  |  | 41,241 |  |  | 38,367 |  |
| Services (2) | 85,200 |  |  | 78,129 |  |  | 68,425 |  |
| Total net sales | $ | 383,285 |  |  | $ | 394,328 |  |  | $ | 365,817 |  |

[0000320193-23-000106:notes:34]
(1)Products net sales include amortization of the deferred value of unspecified software upgrade rights, which are bundled in the sales price of the respective product.

[0000320193-23-000106:notes:35]
(2)Services net sales include amortization of the deferred value of services bundled in the sales price of certain products.

[0000320193-23-000106:notes:36]
Total net sales include $8.2 billion of revenue recognized in 2023 that was included in deferred revenue as of September 24, 2022, $7.5 billion of revenue recognized in 2022 that was included in deferred revenue as of September 25, 2021, and $6.7 billion of revenue recognized in 2021 that was included in deferred revenue as of September 26, 2020.

[0000320193-23-000106:notes:37]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 13, “Segment Information and Geographic Data” for 2023, 2022 and 2021, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.

[0000320193-23-000106:notes:38]
As of September 30, 2023 and September 24, 2022, the Company had total deferred revenue of $12.1 billion and $12.4 billion, respectively. As of September 30, 2023, the Company expects 67% of total deferred revenue to be realized in less than a year, 25% within one-to-two years, 7% within two-to-three years and 1% in greater than three years.


## us-gaap:EarningsPerShareTextBlock

[0000320193-23-000106:notes:39]
Earnings Per Share
The following table shows the computation of basic and diluted earnings per share for 2023, 2022 and 2021 (net income in millions and shares in thousands):

[0000320193-23-000106:notes:40]
|  | 2023 |  | 2022 |  | 2021 |
| Numerator: |  |  |  |  |  |
| Net income | $ | 96,995 |  |  | $ | 99,803 |  |  | $ | 94,680 |  |
| Denominator: |  |  |  |  |  |
| Weighted-average basic shares outstanding | 15,744,231 |  |  | 16,215,963 |  |  | 16,701,272 |  |
| Effect of dilutive share-based awards | 68,316 |  |  | 109,856 |  |  | 163,647 |  |
| Weighted-average diluted shares | 15,812,547 |  |  | 16,325,819 |  |  | 16,864,919 |  |
| Basic earnings per share | $ | 6.16 |  |  | $ | 6.15 |  |  | $ | 5.67 |  |
| Diluted earnings per share | $ | 6.13 |  |  | $ | 6.11 |  |  | $ | 5.61 |  |

[0000320193-23-000106:notes:41]
Approximately 24 million restricted stock units (“RSUs”) were excluded from the computation of diluted earnings per share for 2023 because their effect would have been antidilutive.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000320193-23-000106:notes:42]
Financial Instruments
Cash, Cash Equivalents and Marketable Securities

[0000320193-23-000106:notes:43]
The following tables show the Company’s cash, cash equivalents and marketable securities by significant investment category as of September 30, 2023 and September 24, 2022 (in millions):

[0000320193-23-000106:notes:44]
|  | 2023 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | CurrentMarketableSecurities |  | Non-CurrentMarketableSecurities |
| Cash | $ | 28,359 |  |  | $ | — |  |  | $ | — |  |  | $ | 28,359 |  |  | $ | 28,359 |  |  | $ | — |  |  | $ | — |  |
| Level 1: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 481 |  |  | — |  |  | — |  |  | 481 |  |  | 481 |  |  | — |  |  | — |  |
| Mutual funds and equity securities | 442 |  |  | 12 |  |  | (26) |  |  | 428 |  |  | — |  |  | 428 |  |  | — |  |
| Subtotal | 923 |  |  | 12 |  |  | (26) |  |  | 909 |  |  | 481 |  |  | 428 |  |  | — |  |
| Level 2 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 19,406 |  |  | — |  |  | (1,292) |  |  | 18,114 |  |  | 35 |  |  | 5,468 |  |  | 12,611 |  |
| U.S. agency securities | 5,736 |  |  | — |  |  | (600) |  |  | 5,136 |  |  | 36 |  |  | 271 |  |  | 4,829 |  |
| Non-U.S. government securities | 17,533 |  |  | 6 |  |  | (1,048) |  |  | 16,491 |  |  | — |  |  | 11,332 |  |  | 5,159 |  |
| Certificates of deposit and time deposits | 1,354 |  |  | — |  |  | — |  |  | 1,354 |  |  | 1,034 |  |  | 320 |  |  | — |  |
| Commercial paper | 608 |  |  | — |  |  | — |  |  | 608 |  |  | — |  |  | 608 |  |  | — |  |
| Corporate debt securities | 76,840 |  |  | 6 |  |  | (5,956) |  |  | 70,890 |  |  | 20 |  |  | 12,627 |  |  | 58,243 |  |
| Municipal securities | 628 |  |  | — |  |  | (26) |  |  | 602 |  |  | — |  |  | 192 |  |  | 410 |  |
| Mortgage- and asset-backed securities | 22,365 |  |  | 6 |  |  | (2,735) |  |  | 19,636 |  |  | — |  |  | 344 |  |  | 19,292 |  |
| Subtotal | 144,470 |  |  | 18 |  |  | (11,657) |  |  | 132,831 |  |  | 1,125 |  |  | 31,162 |  |  | 100,544 |  |
| Total (2) | $ | 173,752 |  |  | $ | 30 |  |  | $ | (11,683) |  |  | $ | 162,099 |  |  | $ | 29,965 |  |  | $ | 31,590 |  |  | $ | 100,544 |  |

[0000320193-23-000106:notes:45]
|  | 2022 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | CurrentMarketableSecurities |  | Non-CurrentMarketableSecurities |
| Cash | $ | 18,546 |  |  | $ | — |  |  | $ | — |  |  | $ | 18,546 |  |  | $ | 18,546 |  |  | $ | — |  |  | $ | — |  |
| Level 1: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 2,929 |  |  | — |  |  | — |  |  | 2,929 |  |  | 2,929 |  |  | — |  |  | — |  |
| Mutual funds | 274 |  |  | — |  |  | (47) |  |  | 227 |  |  | — |  |  | 227 |  |  | — |  |
| Subtotal | 3,203 |  |  | — |  |  | (47) |  |  | 3,156 |  |  | 2,929 |  |  | 227 |  |  | — |  |
| Level 2 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 25,134 |  |  | — |  |  | (1,725) |  |  | 23,409 |  |  | 338 |  |  | 5,091 |  |  | 17,980 |  |
| U.S. agency securities | 5,823 |  |  | — |  |  | (655) |  |  | 5,168 |  |  | — |  |  | 240 |  |  | 4,928 |  |
| Non-U.S. government securities | 16,948 |  |  | 2 |  |  | (1,201) |  |  | 15,749 |  |  | — |  |  | 8,806 |  |  | 6,943 |  |
| Certificates of deposit and time deposits | 2,067 |  |  | — |  |  | — |  |  | 2,067 |  |  | 1,805 |  |  | 262 |  |  | — |  |
| Commercial paper | 718 |  |  | — |  |  | — |  |  | 718 |  |  | 28 |  |  | 690 |  |  | — |  |
| Corporate debt securities | 87,148 |  |  | 9 |  |  | (7,707) |  |  | 79,450 |  |  | — |  |  | 9,023 |  |  | 70,427 |  |
| Municipal securities | 921 |  |  | — |  |  | (35) |  |  | 886 |  |  | — |  |  | 266 |  |  | 620 |  |
| Mortgage- and asset-backed securities | 22,553 |  |  | — |  |  | (2,593) |  |  | 19,960 |  |  | — |  |  | 53 |  |  | 19,907 |  |
| Subtotal | 161,312 |  |  | 11 |  |  | (13,916) |  |  | 147,407 |  |  | 2,171 |  |  | 24,431 |  |  | 120,805 |  |
| Total (2) | $ | 183,061 |  |  | $ | 11 |  |  | $ | (13,963) |  |  | $ | 169,109 |  |  | $ | 23,646 |  |  | $ | 24,658 |  |  | $ | 120,805 |  |

[0000320193-23-000106:notes:46]
(1)The valuation techniques used to measure the fair values of the Company’s Level 2 financial instruments, which generally have counterparties with high credit ratings, are based on quoted market prices or model-driven valuations using significant inputs derived from or corroborated by observable market data.

[0000320193-23-000106:notes:47]
(2)As of September 30, 2023 and September 24, 2022, total marketable securities included $13.8 billion and $12.7 billion, respectively, that were restricted from general use, related to the State Aid Decision (refer to Note 7, “Income Taxes”) and other agreements.

[0000320193-23-000106:notes:48]
The following table shows the fair value of the Company’s non-current marketable debt securities, by contractual maturity, as of September 30, 2023 (in millions):

[0000320193-23-000106:notes:49]
| Due after 1 year through 5 years | $ | 74,427 |  |
| Due after 5 years through 10 years | 9,964 |  |
| Due after 10 years | 16,153 |  |
| Total fair value | $ | 100,544 |  |

[0000320193-23-000106:notes:50]
The Company’s investments in marketable debt securities have been classified and accounted for as available-for-sale. The Company classifies marketable debt securities as either current or non-current based solely on each instrument’s underlying contractual maturity date.

[0000320193-23-000106:notes:51]
Derivative Instruments and Hedging

[0000320193-23-000106:notes:52]
The Company may use derivative instruments to partially offset its business exposure to foreign exchange and interest rate risk. However, the Company may choose not to hedge certain exposures for a variety of reasons including accounting considerations or the prohibitive economic cost of hedging particular exposures. There can be no assurance the hedges will offset more than a portion of the financial impact resulting from movements in foreign exchange or interest rates.

[0000320193-23-000106:notes:53]
The Company classifies cash flows related to derivative instruments in the same section of the Consolidated Statements of Cash Flows as the items being hedged, which are generally classified as operating activities.

[0000320193-23-000106:notes:54]
Foreign Exchange Rate Risk

[0000320193-23-000106:notes:55]
To protect gross margins from fluctuations in foreign exchange rates, the Company may use forwards, options or other instruments, and may designate these instruments as cash flow hedges. The Company generally hedges portions of its forecasted foreign currency exposure associated with revenue and inventory purchases, typically for up to 12 months.

[0000320193-23-000106:notes:56]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in foreign exchange rates, the Company may use forwards, cross-currency swaps or other instruments. The Company designates these instruments as either cash flow or fair value hedges. As of September 30, 2023, the maximum length of time over which the Company is hedging its exposure to the variability in future cash flows for term debt–related foreign currency transactions is 19 years.

[0000320193-23-000106:notes:57]
The Company may also use derivative instruments that are not designated as accounting hedges to protect gross margins from certain fluctuations in foreign exchange rates, as well as to offset a portion of the foreign currency gains and losses generated by the remeasurement of certain assets and liabilities denominated in non-functional currencies.

[0000320193-23-000106:notes:58]
Interest Rate Risk

[0000320193-23-000106:notes:59]
To protect the Company’s term debt or marketable securities from fluctuations in interest rates, the Company may use interest rate swaps, options or other instruments. The Company designates these instruments as either cash flow or fair value hedges.

[0000320193-23-000106:notes:60]
The notional amounts of the Company’s outstanding derivative instruments as of September 30, 2023 and September 24, 2022 were as follows (in millions):

[0000320193-23-000106:notes:61]
|  | 2023 |  | 2022 |
| Derivative instruments designated as accounting hedges: |  |  |  |
| Foreign exchange contracts | $ | 74,730 |  |  | $ | 102,670 |  |
| Interest rate contracts | $ | 19,375 |  |  | $ | 20,125 |  |
| Derivative instruments not designated as accounting hedges: |  |  |  |
| Foreign exchange contracts | $ | 104,777 |  |  | $ | 185,381 |  |

[0000320193-23-000106:notes:62]
The gross fair values of the Company’s derivative assets and liabilities as of September 24, 2022 were as follows (in millions):

[0000320193-23-000106:notes:63]
|  | 2022 |
|  | Fair Value ofDerivatives Designatedas Accounting Hedges |  | Fair Value ofDerivatives Not Designatedas Accounting Hedges |  | TotalFair Value |
| Derivative assets (1): |  |  |  |  |  |
| Foreign exchange contracts | $ | 4,317 |  |  | $ | 2,819 |  |  | $ | 7,136 |  |
| Derivative liabilities (2): |  |  |  |  |  |
| Foreign exchange contracts | $ | 2,205 |  |  | $ | 2,547 |  |  | $ | 4,752 |  |
| Interest rate contracts | $ | 1,367 |  |  | $ | — |  |  | $ | 1,367 |  |

[0000320193-23-000106:notes:64]
(1)Derivative assets are measured using Level 2 fair value inputs and are included in other current assets and other non-current assets in the Consolidated Balance Sheet.

[0000320193-23-000106:notes:65]
(2)Derivative liabilities are measured using Level 2 fair value inputs and are included in other current liabilities and other non-current liabilities in the Consolidated Balance Sheet.

[0000320193-23-000106:notes:66]
The derivative assets above represent the Company’s gross credit exposure if all counterparties failed to perform. To mitigate credit risk, the Company generally uses collateral security arrangements that provide for collateral to be received or posted when the net fair values of certain derivatives fluctuate from contractually established thresholds. To further limit credit risk, the Company generally uses master netting arrangements with the respective counterparties to the Company’s derivative contracts, under which the Company is allowed to settle transactions with a single net amount payable by one party to the other. As of September 24, 2022, the potential effects of these rights of set-off associated with the Company’s derivative contracts, including the effects of collateral, would be a reduction to both derivative assets and derivative liabilities of $7.8 billion, resulting in a net derivative asset of $412 million.

[0000320193-23-000106:notes:67]
The carrying amounts of the Company’s hedged items in fair value hedges as of September 30, 2023 and September 24, 2022 were as follows (in millions):

[0000320193-23-000106:notes:68]
|  | 2023 |  | 2022 |
| Hedged assets/(liabilities): |  |  |  |
| Current and non-current marketable securities | $ | 14,433 |  |  | $ | 13,378 |  |
| Current and non-current term debt | $ | (18,247) |  |  | $ | (18,739) |  |

[0000320193-23-000106:notes:69]
Accounts Receivable

[0000320193-23-000106:notes:70]
Trade Receivables

[0000320193-23-000106:notes:71]
As of September 24, 2022, the Company had one customer that represented 10% or more of total trade receivables, which accounted for 10%. The Company’s third-party cellular network carriers accounted for 41% and 44% of total trade receivables as of September 30, 2023 and September 24, 2022, respectively. The Company requires third-party credit support or collateral from certain customers to limit credit risk.

[0000320193-23-000106:notes:72]
Vendor Non-Trade Receivables

[0000320193-23-000106:notes:73]
The Company has non-trade receivables from certain of its manufacturing vendors resulting from the sale of components to these vendors who manufacture subassemblies or assemble final products for the Company. The Company purchases these components directly from suppliers. The Company does not reflect the sale of these components in products net sales. Rather, the Company recognizes any gain on these sales as a reduction of products cost of sales when the related final products are sold by the Company. As of September 30, 2023, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 48% and 23%. As of September 24, 2022, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 54% and 13%.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000320193-23-000106:notes:74]
Property, Plant and Equipment
The following table shows the Company’s gross property, plant and equipment by major asset class and accumulated depreciation as of September 30, 2023 and September 24, 2022 (in millions):

[0000320193-23-000106:notes:75]
|  | 2023 |  | 2022 |
| Land and buildings | $ | 23,446 |  |  | $ | 22,126 |  |
| Machinery, equipment and internal-use software | 78,314 |  |  | 81,060 |  |
| Leasehold improvements | 12,839 |  |  | 11,271 |  |
| Gross property, plant and equipment | 114,599 |  |  | 114,457 |  |
| Accumulated depreciation | (70,884) |  |  | (72,340) |  |
| Total property, plant and equipment, net | $ | 43,715 |  |  | $ | 42,117 |  |

[0000320193-23-000106:notes:76]
Depreciation expense on property, plant and equipment was $8.5 billion, $8.7 billion and $9.5 billion during 2023, 2022 and 2021, respectively.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000320193-23-000106:notes:77]
Consolidated Financial Statement Details
The following tables show the Company’s consolidated financial statement details as of September 30, 2023 and September 24, 2022 (in millions):

[0000320193-23-000106:notes:78]
Other Non-Current Assets

[0000320193-23-000106:notes:79]
|  | 2023 |  | 2022 |
| Deferred tax assets | $ | 17,852 |  |  | $ | 15,375 |  |
| Other non-current assets | 46,906 |  |  | 39,053 |  |
| Total other non-current assets | $ | 64,758 |  |  | $ | 54,428 |  |

[0000320193-23-000106:notes:80]
Other Current Liabilities

[0000320193-23-000106:notes:81]
|  | 2023 |  | 2022 |
| Income taxes payable | $ | 8,819 |  |  | $ | 6,552 |  |
| Other current liabilities | 50,010 |  |  | 54,293 |  |
| Total other current liabilities | $ | 58,829 |  |  | $ | 60,845 |  |

[0000320193-23-000106:notes:82]
Other Non-Current Liabilities

[0000320193-23-000106:notes:83]
|  | 2023 |  | 2022 |
| Long-term taxes payable | $ | 15,457 |  |  | $ | 16,657 |  |
| Other non-current liabilities | 34,391 |  |  | 32,485 |  |
| Total other non-current liabilities | $ | 49,848 |  |  | $ | 49,142 |  |

[0000320193-23-000106:notes:84]
Other Income/(Expense), Net

[0000320193-23-000106:notes:85]
The following table shows the detail of other income/(expense), net for 2023, 2022 and 2021 (in millions):

[0000320193-23-000106:notes:86]
|  | 2023 |  | 2022 |  | 2021 |
| Interest and dividend income | $ | 3,750 |  |  | $ | 2,825 |  |  | $ | 2,843 |  |
| Interest expense | (3,933) |  |  | (2,931) |  |  | (2,645) |  |
| Other income/(expense), net | (382) |  |  | (228) |  |  | 60 |  |
| Total other income/(expense), net | $ | (565) |  |  | $ | (334) |  |  | $ | 258 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000320193-23-000106:notes:87]
Income Taxes
Provision for Income Taxes and Effective Tax Rate

[0000320193-23-000106:notes:88]
The provision for income taxes for 2023, 2022 and 2021, consisted of the following (in millions):

[0000320193-23-000106:notes:89]
|  | 2023 |  | 2022 |  | 2021 |
| Federal: |  |  |  |  |  |
| Current | $ | 9,445 |  |  | $ | 7,890 |  |  | $ | 8,257 |  |
| Deferred | (3,644) |  |  | (2,265) |  |  | (7,176) |  |
| Total | 5,801 |  |  | 5,625 |  |  | 1,081 |  |
| State: |  |  |  |  |  |
| Current | 1,570 |  |  | 1,519 |  |  | 1,620 |  |
| Deferred | (49) |  |  | 84 |  |  | (338) |  |
| Total | 1,521 |  |  | 1,603 |  |  | 1,282 |  |
| Foreign: |  |  |  |  |  |
| Current | 8,750 |  |  | 8,996 |  |  | 9,424 |  |
| Deferred | 669 |  |  | 3,076 |  |  | 2,740 |  |
| Total | 9,419 |  |  | 12,072 |  |  | 12,164 |  |
| Provision for income taxes | $ | 16,741 |  |  | $ | 19,300 |  |  | $ | 14,527 |  |

[0000320193-23-000106:notes:90]
The foreign provision for income taxes is based on foreign pretax earnings of $72.9 billion, $71.3 billion and $68.7 billion in 2023, 2022 and 2021, respectively.

[0000320193-23-000106:notes:91]
A reconciliation of the provision for income taxes to the amount computed by applying the statutory federal income tax rate (21% in 2023, 2022 and 2021) to income before provision for income taxes for 2023, 2022 and 2021, is as follows (dollars in millions):

[0000320193-23-000106:notes:92]
|  | 2023 |  | 2022 |  | 2021 |
| Computed expected tax | $ | 23,885 |  |  | $ | 25,012 |  |  | $ | 22,933 |  |
| State taxes, net of federal effect | 1,124 |  |  | 1,518 |  |  | 1,151 |  |
| Earnings of foreign subsidiaries | (5,744) |  |  | (4,366) |  |  | (4,715) |  |
| Research and development credit, net | (1,212) |  |  | (1,153) |  |  | (1,033) |  |
| Excess tax benefits from equity awards | (1,120) |  |  | (1,871) |  |  | (2,137) |  |
| Foreign-derived intangible income deduction | — |  |  | (296) |  |  | (1,372) |  |
| Other | (192) |  |  | 456 |  |  | (300) |  |
| Provision for income taxes | $ | 16,741 |  |  | $ | 19,300 |  |  | $ | 14,527 |  |
| Effective tax rate | 14.7 | % |  | 16.2 | % |  | 13.3 | % |

[0000320193-23-000106:notes:93]
Deferred Tax Assets and Liabilities

[0000320193-23-000106:notes:94]
As of September 30, 2023 and September 24, 2022, the significant components of the Company’s deferred tax assets and liabilities were (in millions):

[0000320193-23-000106:notes:95]
|  | 2023 |  | 2022 |
| Deferred tax assets: |  |  |  |
| Tax credit carryforwards | $ | 8,302 |  |  | $ | 6,962 |  |
| Accrued liabilities and other reserves | 6,365 |  |  | 6,515 |  |
| Capitalized research and development | 6,294 |  |  | 1,267 |  |
| Deferred revenue | 4,571 |  |  | 5,742 |  |
| Unrealized losses | 2,447 |  |  | 2,913 |  |
| Lease liabilities | 2,421 |  |  | 2,400 |  |
| Other | 2,343 |  |  | 3,407 |  |
| Total deferred tax assets | 32,743 |  |  | 29,206 |  |
| Less: Valuation allowance | (8,374) |  |  | (7,530) |  |
| Total deferred tax assets, net | 24,369 |  |  | 21,676 |  |
| Deferred tax liabilities: |  |  |  |
| Right-of-use assets | 2,179 |  |  | 2,163 |  |
| Depreciation | 1,998 |  |  | 1,582 |  |
| Minimum tax on foreign earnings | 1,940 |  |  | 1,983 |  |
| Unrealized gains | 511 |  |  | 942 |  |
| Other | 490 |  |  | 469 |  |
| Total deferred tax liabilities | 7,118 |  |  | 7,139 |  |
| Net deferred tax assets | $ | 17,251 |  |  | $ | 14,537 |  |

[0000320193-23-000106:notes:96]
As of September 30, 2023, the Company had $5.2 billion in foreign tax credit carryforwards in Ireland and $3.0 billion in California R&D credit carryforwards, both of which can be carried forward indefinitely. A valuation allowance has been recorded for the credit carryforwards and a portion of other temporary differences.

[0000320193-23-000106:notes:97]
Uncertain Tax Positions

[0000320193-23-000106:notes:98]
As of September 30, 2023, the total amount of gross unrecognized tax benefits was $19.5 billion, of which $9.5 billion, if recognized, would impact the Company’s effective tax rate. As of September 24, 2022, the total amount of gross unrecognized tax benefits was $16.8 billion, of which $8.0 billion, if recognized, would have impacted the Company’s effective tax rate.

[0000320193-23-000106:notes:99]
The aggregate change in the balance of gross unrecognized tax benefits, which excludes interest and penalties, for 2023, 2022 and 2021, is as follows (in millions):

[0000320193-23-000106:notes:100]
|  | 2023 |  | 2022 |  | 2021 |
| Beginning balances | $ | 16,758 |  |  | $ | 15,477 |  |  | $ | 16,475 |  |
| Increases related to tax positions taken during a prior year | 2,044 |  |  | 2,284 |  |  | 816 |  |
| Decreases related to tax positions taken during a prior year | (1,463) |  |  | (1,982) |  |  | (1,402) |  |
| Increases related to tax positions taken during the current year | 2,628 |  |  | 1,936 |  |  | 1,607 |  |
| Decreases related to settlements with taxing authorities | (19) |  |  | (28) |  |  | (1,838) |  |
| Decreases related to expiration of the statute of limitations | (494) |  |  | (929) |  |  | (181) |  |
| Ending balances | $ | 19,454 |  |  | $ | 16,758 |  |  | $ | 15,477 |  |

[0000320193-23-000106:notes:101]
The Company is subject to taxation and files income tax returns in the U.S. federal jurisdiction and many state and foreign jurisdictions. Tax years after 2017 for the U.S. federal jurisdiction, and after 2014 in certain major foreign jurisdictions, remain subject to examination. Although the timing of resolution or closure of examinations is not certain, the Company believes it is reasonably possible that its gross unrecognized tax benefits could decrease in the next 12 months by as much as $4.5 billion.

[0000320193-23-000106:notes:102]
European Commission State Aid Decision

[0000320193-23-000106:notes:103]
On August 30, 2016, the European Commission announced its decision that Ireland granted state aid to the Company by providing tax opinions in 1991 and 2007 concerning the tax allocation of profits of the Irish branches of two subsidiaries of the Company (the “State Aid Decision”). The State Aid Decision ordered Ireland to calculate and recover additional taxes from the Company for the period June 2003 through December 2014. Irish legislative changes, effective as of January 2015, eliminated the application of the tax opinions from that date forward. The recovery amount was calculated to be €13.1 billion, plus interest of €1.2 billion. The Company and Ireland appealed the State Aid Decision to the General Court of the Court of Justice of the European Union (the “General Court”). On July 15, 2020, the General Court annulled the State Aid Decision. On September 25, 2020, the European Commission appealed the General Court’s decision to the European Court of Justice (the “ECJ”) and a hearing was held on May 23, 2023. A decision from the ECJ is expected in calendar year 2024. The Company believes it would be eligible to claim a U.S. foreign tax credit for a portion of any incremental Irish corporate income taxes potentially due related to the State Aid Decision.

[0000320193-23-000106:notes:104]
On an annual basis, the Company may request approval from the Irish Minister for Finance to reduce the recovery amount for certain taxes paid to other countries. As of September 30, 2023, the adjusted recovery amount was €12.7 billion, excluding interest. The adjusted recovery amount plus interest is funded into escrow, where it will remain restricted from general use pending the conclusion of all legal proceedings. Refer to the Cash, Cash Equivalents and Marketable Securities section of Note 4, “Financial Instruments” for more information.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000320193-23-000106:notes:105]
Leases
The Company has lease arrangements for certain equipment and facilities, including corporate, data center, manufacturing and retail space. These leases typically have original terms not exceeding 10 years and generally contain multiyear renewal options, some of which are reasonably certain of exercise.

[0000320193-23-000106:notes:106]
Payments under the Company’s lease arrangements may be fixed or variable, and variable lease payments are primarily based on purchases of output of the underlying leased assets. Lease costs associated with fixed payments on the Company’s operating leases were $2.0 billion, $1.9 billion and $1.7 billion for 2023, 2022 and 2021, respectively. Lease costs associated with variable payments on the Company’s leases were $13.9 billion, $14.9 billion and $12.9 billion for 2023, 2022 and 2021, respectively.

[0000320193-23-000106:notes:107]
The Company made $1.9 billion, $1.8 billion and $1.4 billion of fixed cash payments related to operating leases in 2023, 2022 and 2021, respectively. Noncash activities involving right-of-use (“ROU”) assets obtained in exchange for lease liabilities were $2.1 billion, $2.8 billion and $3.3 billion for 2023, 2022 and 2021, respectively.

[0000320193-23-000106:notes:108]
The following table shows ROU assets and lease liabilities, and the associated financial statement line items, as of September 30, 2023 and September 24, 2022 (in millions):

[0000320193-23-000106:notes:109]
| Lease-Related Assets and Liabilities |  | Financial Statement Line Items |  | 2023 |  | 2022 |  |  |
| Right-of-use assets: |  |  |  |  |  |  |  |  |
| Operating leases |  | Other non-current assets |  | $ | 10,661 |  |  | $ | 10,417 |  |  |  |
| Finance leases |  | Property, plant and equipment, net |  | 1,015 |  |  | 952 |  |  |  |
| Total right-of-use assets |  |  |  | $ | 11,676 |  |  | $ | 11,369 |  |  |  |
| Lease liabilities: |  |  |  |  |  |  |  |  |
| Operating leases |  | Other current liabilities |  | $ | 1,410 |  |  | $ | 1,534 |  |  |  |
|  |  | Other non-current liabilities |  | 10,408 |  |  | 9,936 |  |  |  |
| Finance leases |  | Other current liabilities |  | 165 |  |  | 129 |  |  |  |
|  |  | Other non-current liabilities |  | 859 |  |  | 812 |  |  |  |
| Total lease liabilities |  |  |  | $ | 12,842 |  |  | $ | 12,411 |  |  |  |

[0000320193-23-000106:notes:110]
Lease liability maturities as of September 30, 2023, are as follows (in millions):

[0000320193-23-000106:notes:111]
|  | OperatingLeases |  | FinanceLeases |  | Total |
| 2024 | $ | 1,719 |  |  | $ | 196 |  |  | $ | 1,915 |  |
| 2025 | 1,875 |  |  | 151 |  |  | 2,026 |  |
| 2026 | 1,732 |  |  | 120 |  |  | 1,852 |  |
| 2027 | 1,351 |  |  | 52 |  |  | 1,403 |  |
| 2028 | 1,181 |  |  | 34 |  |  | 1,215 |  |
| Thereafter | 5,983 |  |  | 872 |  |  | 6,855 |  |
| Total undiscounted liabilities | 13,841 |  |  | 1,425 |  |  | 15,266 |  |
| Less: Imputed interest | (2,023) |  |  | (401) |  |  | (2,424) |  |
| Total lease liabilities | $ | 11,818 |  |  | $ | 1,024 |  |  | $ | 12,842 |  |

[0000320193-23-000106:notes:112]
The weighted-average remaining lease term related to the Company’s lease liabilities as of September 30, 2023 and September 24, 2022 was 10.6 years and 10.1 years, respectively. The discount rate related to the Company’s lease liabilities as of September 30, 2023 and September 24, 2022 was 3.0% and 2.3%, respectively. The discount rates related to the Company’s lease liabilities are generally based on estimates of the Company’s incremental borrowing rate, as the discount rates implicit in the Company’s leases cannot be readily determined.

[0000320193-23-000106:notes:113]
As of September 30, 2023, the Company had $544 million of future payments under additional leases, primarily for corporate facilities and retail space, that had not yet commenced. These leases will commence between 2024 and 2026, with lease terms ranging from 1 year to 21 years.


## us-gaap:DebtDisclosureTextBlock

[0000320193-23-000106:notes:114]
Debt
Commercial Paper

[0000320193-23-000106:notes:115]
The Company issues unsecured short-term promissory notes pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of September 30, 2023 and September 24, 2022, the Company had $6.0 billion and $10.0 billion of commercial paper outstanding, respectively, with maturities generally less than nine months. The weighted-average interest rate of the Company’s commercial paper was 5.28% and 2.31% as of September 30, 2023 and September 24, 2022, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of commercial paper for 2023, 2022 and 2021 (in millions):

[0000320193-23-000106:notes:116]
|  | 2023 |  | 2022 |  | 2021 |
| Maturities 90 days or less: |  |  |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | (1,333) |  |  | $ | 5,264 |  |  | $ | (357) |  |
| Maturities greater than 90 days: |  |  |  |  |  |
| Proceeds from commercial paper | — |  |  | 5,948 |  |  | 7,946 |  |
| Repayments of commercial paper | (2,645) |  |  | (7,257) |  |  | (6,567) |  |
| Proceeds from/(Repayments of) commercial paper, net | (2,645) |  |  | (1,309) |  |  | 1,379 |  |
| Total proceeds from/(repayments of) commercial paper, net | $ | (3,978) |  |  | $ | 3,955 |  |  | $ | 1,022 |  |

[0000320193-23-000106:notes:117]
Term Debt

[0000320193-23-000106:notes:118]
The Company has outstanding Notes, which are senior unsecured obligations with interest payable in arrears. The following table provides a summary of the Company’s term debt as of September 30, 2023 and September 24, 2022:

[0000320193-23-000106:notes:119]
|  | Maturities(calendar year) |  | 2023 |  | 2022 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 – 2022 debt issuances: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.000% – 4.650% notes | 2024 – 2062 |  | $ | 101,322 |  |  | 0.03% – 6.72% |  | $ | 111,824 |  |  | 0.03% – 4.78% |
| Third quarter 2023 debt issuance: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 4.000% – 4.850% notes | 2026 – 2053 |  | 5,250 |  |  | 4.04% – 4.88% |  | — |  |  |  |
| Total term debt principal |  |  | 106,572 |  |  |  |  | 111,824 |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  | (356) |  |  |  |  | (374) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (1,113) |  |  |  |  | (1,363) |  |  |  |
| Total term debt |  |  | 105,103 |  |  |  |  | 110,087 |  |  |  |
| Less: Current portion of term debt |  |  | (9,822) |  |  |  |  | (11,128) |  |  |  |
| Total non-current portion of term debt |  |  | $ | 95,281 |  |  |  |  | $ | 98,959 |  |  |  |

[0000320193-23-000106:notes:120]
To manage interest rate risk on certain of its U.S. dollar–denominated fixed-rate notes, the Company uses interest rate swaps to effectively convert the fixed interest rates to floating interest rates on a portion of these notes. Additionally, to manage foreign exchange rate risk on certain of its foreign currency–denominated notes, the Company uses cross-currency swaps to effectively convert these notes to U.S. dollar–denominated notes.

[0000320193-23-000106:notes:121]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $3.7 billion, $2.8 billion and $2.6 billion of interest expense on its term debt for 2023, 2022 and 2021, respectively.

[0000320193-23-000106:notes:122]
The future principal payments for the Company’s Notes as of September 30, 2023, are as follows (in millions):

[0000320193-23-000106:notes:123]
| 2024 | $ | 9,943 |  |
| 2025 | 10,775 |  |
| 2026 | 12,265 |  |
| 2027 | 9,786 |  |
| 2028 | 7,800 |  |
| Thereafter | 56,003 |  |
| Total term debt principal | $ | 106,572 |  |

[0000320193-23-000106:notes:124]
As of September 30, 2023 and September 24, 2022, the fair value of the Company’s Notes, based on Level 2 inputs, was $90.8 billion and $98.8 billion, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000320193-23-000106:notes:125]
Shareholders’ Equity
Share Repurchase Program

[0000320193-23-000106:notes:126]
During 2023, the Company repurchased 471 million shares of its common stock for $76.6 billion, excluding excise tax due under the Inflation Reduction Act of 2022. The Company’s share repurchase programs do not obligate the Company to acquire a minimum amount of shares. Under the programs, shares may be repurchased in privately negotiated or open market transactions, including under plans complying with Rule 10b5-1 under the Exchange Act.

[0000320193-23-000106:notes:127]
Shares of Common Stock

[0000320193-23-000106:notes:128]
The following table shows the changes in shares of common stock for 2023, 2022 and 2021 (in thousands):

[0000320193-23-000106:notes:129]
|  | 2023 |  | 2022 |  | 2021 |
| Common stock outstanding, beginning balances | 15,943,425 |  |  | 16,426,786 |  |  | 16,976,763 |  |
| Common stock repurchased | (471,419) |  |  | (568,589) |  |  | (656,340) |  |
| Common stock issued, net of shares withheld for employee taxes | 78,055 |  |  | 85,228 |  |  | 106,363 |  |
| Common stock outstanding, ending balances | 15,550,061 |  |  | 15,943,425 |  |  | 16,426,786 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000320193-23-000106:notes:130]
Share-Based Compensation
2022 Employee Stock Plan

[0000320193-23-000106:notes:131]
The Apple Inc. 2022 Employee Stock Plan (the “2022 Plan”) is a shareholder-approved plan that provides for broad-based equity grants to employees, including executive officers, and permits the granting of RSUs, stock grants, performance-based awards, stock options and stock appreciation rights. RSUs granted under the 2022 Plan generally vest over four years, based on continued employment, and are settled upon vesting in shares of the Company’s common stock on a one-for-one basis. All RSUs granted under the 2022 Plan have dividend equivalent rights, which entitle holders of RSUs to the same dividend value per share as holders of common stock. A maximum of approximately 1.3 billion shares were authorized for issuance pursuant to 2022 Plan awards at the time the plan was approved on March 4, 2022.

[0000320193-23-000106:notes:132]
2014 Employee Stock Plan

[0000320193-23-000106:notes:133]
The Apple Inc. 2014 Employee Stock Plan (the “2014 Plan”) is a shareholder-approved plan that provided for broad-based equity grants to employees, including executive officers. The 2014 Plan permitted the granting of substantially the same types of equity awards with substantially the same terms as the 2022 Plan. The 2014 Plan also permitted the granting of cash bonus awards. In the third quarter of 2022, the Company terminated the authority to grant new awards under the 2014 Plan.

[0000320193-23-000106:notes:134]
Restricted Stock Units

[0000320193-23-000106:notes:135]
A summary of the Company’s RSU activity and related information for 2023, 2022 and 2021, is as follows:

[0000320193-23-000106:notes:136]
|  | Number ofRSUs(in thousands) |  | Weighted-AverageGrant Date FairValue Per RSU |  | AggregateFair Value(in millions) |
| Balance as of September 26, 2020 | 310,778 |  |  | $ | 51.58 |  |  |  |
| RSUs granted | 89,363 |  |  | $ | 116.33 |  |  |  |
| RSUs vested | (145,766) |  |  | $ | 50.71 |  |  |  |
| RSUs canceled | (13,948) |  |  | $ | 68.95 |  |  |  |
| Balance as of September 25, 2021 | 240,427 |  |  | $ | 75.16 |  |  |  |
| RSUs granted | 91,674 |  |  | $ | 150.70 |  |  |  |
| RSUs vested | (115,861) |  |  | $ | 72.12 |  |  |  |
| RSUs canceled | (14,739) |  |  | $ | 99.77 |  |  |  |
| Balance as of September 24, 2022 | 201,501 |  |  | $ | 109.48 |  |  |  |
| RSUs granted | 88,768 |  |  | $ | 150.87 |  |  |  |
| RSUs vested | (101,878) |  |  | $ | 97.31 |  |  |  |
| RSUs canceled | (8,144) |  |  | $ | 127.98 |  |  |  |
| Balance as of September 30, 2023 | 180,247 |  |  | $ | 135.91 |  |  | $ | 30,860 |  |

[0000320193-23-000106:notes:137]
The fair value as of the respective vesting dates of RSUs was $15.9 billion, $18.2 billion and $19.0 billion for 2023, 2022 and 2021, respectively. The majority of RSUs that vested in 2023, 2022 and 2021 were net share settled such that the Company withheld shares with a value equivalent to the employees’ obligation for the applicable income and other employment taxes, and remitted the cash to the appropriate taxing authorities. The total shares withheld were approximately 37 million, 41 million and 53 million for 2023, 2022 and 2021, respectively, and were based on the value of the RSUs on their respective vesting dates as determined by the Company’s closing stock price. Total payments to taxing authorities for employees’ tax obligations were $5.6 billion, $6.4 billion and $6.8 billion in 2023, 2022 and 2021, respectively.

[0000320193-23-000106:notes:138]
The following table shows share-based compensation expense and the related income tax benefit included in the Consolidated Statements of Operations for 2023, 2022 and 2021 (in millions):

[0000320193-23-000106:notes:139]
|  | 2023 |  | 2022 |  | 2021 |
| Share-based compensation expense | $ | 10,833 |  |  | $ | 9,038 |  |  | $ | 7,906 |  |
| Income tax benefit related to share-based compensation expense | $ | (3,421) |  |  | $ | (4,002) |  |  | $ | (4,056) |  |

[0000320193-23-000106:notes:140]
As of September 30, 2023, the total unrecognized compensation cost related to outstanding RSUs was $18.6 billion, which the Company expects to recognize over a weighted-average period of 2.5 years.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000320193-23-000106:notes:141]
Commitments, Contingencies and Supply Concentrations
Unconditional Purchase Obligations

[0000320193-23-000106:notes:142]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of supplier arrangements, licensed intellectual property and content, and distribution rights. Future payments under noncancelable unconditional purchase obligations with a remaining term in excess of one year as of September 30, 2023, are as follows (in millions):

[0000320193-23-000106:notes:143]
| 2024 | $ | 4,258 |  |
| 2025 | 2,674 |  |
| 2026 | 3,434 |  |
| 2027 | 1,277 |  |
| 2028 | 5,878 |  |
| Thereafter | 3,215 |  |
| Total | $ | 20,736 |  |

[0000320193-23-000106:notes:144]
Contingencies

[0000320193-23-000106:notes:145]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully resolved. The outcome of litigation is inherently uncertain. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss greater than a recorded accrual, concerning loss contingencies for asserted legal and other claims.

[0000320193-23-000106:notes:146]
Concentrations in the Available Sources of Supply of Materials and Product

[0000320193-23-000106:notes:147]
Although most components essential to the Company’s business are generally available from multiple sources, certain components are currently obtained from single or limited sources. The Company also competes for various components with other participants in the markets for smartphones, personal computers, tablets, wearables and accessories. Therefore, many components used by the Company, including those that are available from multiple sources, are at times subject to industry-wide shortage and significant commodity pricing fluctuations.

[0000320193-23-000106:notes:148]
The Company uses some custom components that are not commonly used by its competitors, and new products introduced by the Company often utilize custom components available from only one source. When a component or product uses new technologies, initial capacity constraints may exist until the suppliers’ yields have matured or their manufacturing capacities have increased. The continued availability of these components at acceptable prices, or at all, may be affected if suppliers decide to concentrate on the production of common components instead of components customized to meet the Company’s requirements.

[0000320193-23-000106:notes:149]
Substantially all of the Company’s hardware products are manufactured by outsourcing partners that are located primarily in China mainland, India, Japan, South Korea, Taiwan and Vietnam.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000320193-23-000106:notes:150]
Segment Information and Geographic Data
The Company manages its business primarily on a geographic basis. The Company’s reportable segments consist of the Americas, Europe, Greater China, Japan and Rest of Asia Pacific. Americas includes both North and South America. Europe includes European countries, as well as India, the Middle East and Africa. Greater China includes China mainland, Hong Kong and Taiwan. Rest of Asia Pacific includes Australia and those Asian countries not included in the Company’s other reportable segments. Although the reportable segments provide similar hardware and software products and similar services, each one is managed separately to better align with the location of the Company’s customers and distribution partners and the unique market dynamics of each geographic region.

[0000320193-23-000106:notes:151]
The Company evaluates the performance of its reportable segments based on net sales and operating income. Net sales for geographic segments are generally based on the location of customers and sales through the Company’s retail stores located in those geographic locations. Operating income for each segment consists of net sales to third parties, related cost of sales, and operating expenses directly attributable to the segment. The information provided to the Company’s chief operating decision maker for purposes of making decisions and assessing segment performance excludes asset information.

[0000320193-23-000106:notes:152]
The following table shows information by reportable segment for 2023, 2022 and 2021 (in millions):

[0000320193-23-000106:notes:153]
|  | 2023 |  | 2022 |  | 2021 |
| Americas: |  |  |  |  |  |
| Net sales | $ | 162,560 |  |  | $ | 169,658 |  |  | $ | 153,306 |  |
| Operating income | $ | 60,508 |  |  | $ | 62,683 |  |  | $ | 53,382 |  |
| Europe: |  |  |  |  |  |
| Net sales | $ | 94,294 |  |  | $ | 95,118 |  |  | $ | 89,307 |  |
| Operating income | $ | 36,098 |  |  | $ | 35,233 |  |  | $ | 32,505 |  |
| Greater China: |  |  |  |  |  |
| Net sales | $ | 72,559 |  |  | $ | 74,200 |  |  | $ | 68,366 |  |
| Operating income | $ | 30,328 |  |  | $ | 31,153 |  |  | $ | 28,504 |  |
| Japan: |  |  |  |  |  |
| Net sales | $ | 24,257 |  |  | $ | 25,977 |  |  | $ | 28,482 |  |
| Operating income | $ | 11,888 |  |  | $ | 12,257 |  |  | $ | 12,798 |  |
| Rest of Asia Pacific: |  |  |  |  |  |
| Net sales | $ | 29,615 |  |  | $ | 29,375 |  |  | $ | 26,356 |  |
| Operating income | $ | 12,066 |  |  | $ | 11,569 |  |  | $ | 9,817 |  |

[0000320193-23-000106:notes:154]
A reconciliation of the Company’s segment operating income to the Consolidated Statements of Operations for 2023, 2022 and 2021 is as follows (in millions):

[0000320193-23-000106:notes:155]
|  | 2023 |  | 2022 |  | 2021 |
| Segment operating income | $ | 150,888 |  |  | $ | 152,895 |  |  | $ | 137,006 |  |
| Research and development expense | (29,915) |  |  | (26,251) |  |  | (21,914) |  |
| Other corporate expenses, net (1) | (6,672) |  |  | (7,207) |  |  | (6,143) |  |
| Total operating income | $ | 114,301 |  |  | $ | 119,437 |  |  | $ | 108,949 |  |

[0000320193-23-000106:notes:156]
(1)Includes corporate marketing expenses, certain share-based compensation expenses, various nonrecurring charges, and other separately managed general and administrative costs.

[0000320193-23-000106:notes:157]
The U.S. and China were the only countries that accounted for more than 10% of the Company’s net sales in 2023, 2022 and 2021. Net sales for 2023, 2022 and 2021 and long-lived assets as of September 30, 2023 and September 24, 2022 were as follows (in millions):

[0000320193-23-000106:notes:158]
|  | 2023 |  | 2022 |  | 2021 |
| Net sales: |  |  |  |  |  |
| U.S. | $ | 138,573 |  |  | $ | 147,859 |  |  | $ | 133,803 |  |
| China (1) | 72,559 |  |  | 74,200 |  |  | 68,366 |  |
| Other countries | 172,153 |  |  | 172,269 |  |  | 163,648 |  |
| Total net sales | $ | 383,285 |  |  | $ | 394,328 |  |  | $ | 365,817 |  |

[0000320193-23-000106:notes:159]
|  | 2023 |  | 2022 |
| Long-lived assets: |  |  |  |
| U.S. | $ | 33,276 |  |  | $ | 31,119 |  |
| China (1) | 5,778 |  |  | 7,260 |  |
| Other countries | 4,661 |  |  | 3,738 |  |
| Total long-lived assets | $ | 43,715 |  |  | $ | 42,117 |  |

[0000320193-23-000106:notes:160]
(1)China includes Hong Kong and Taiwan.


## ecd:MtrlTermsOfTrdArrTextBlock

[0000320193-23-000106:notes:161]
On August 30, 2023, Deirdre O’Brien, the Company’s Senior Vice President, Retail, and Jeff Williams, the Company’s Chief Operating Officer, each entered into a trading plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act. The plans provide for the sale of all shares vested during the duration of the plans pursuant to certain equity awards granted to Ms. O’Brien and Mr. Williams, respectively, excluding any shares withheld by the Company to satisfy income tax withholding and remittance obligations. Ms. O’Brien’s plan will expire on October 15, 2024, and Mr. Williams’ plan will expire on December 15, 2024, subject to early termination for certain specified events set forth in the plans.
