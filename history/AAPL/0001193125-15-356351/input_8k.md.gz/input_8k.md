# AAPL 8-K — 0001193125-15-354756 filed 2015-10-27

## item codes, every 8-K on or before 2015-10-28

- 2015-10-27 0001193125-15-354756 — 2.02, 9.01
- 2015-10-02 0001193125-15-336615 — 5.02
- 2015-09-17 0001193125-15-322466 — 8.01, 9.01
- 2015-07-31 0001193125-15-273023 — 8.01, 9.01
- 2015-07-21 0001193125-15-258464 — 2.02, 9.01
- 2015-06-10 0001193125-15-219298 — 8.01, 9.01
- 2015-05-13 0001193125-15-186064 — 8.01, 9.01
- 2015-04-27 0001193125-15-149607 — 7.01, 9.01
- 2015-04-27 0001193125-15-149590 — 2.02, 9.01
- 2015-03-13 0001104659-15-019336 — 5.07, 9.01
- 2015-02-09 0001193125-15-039270 — 8.01, 9.01
- 2015-01-28 0001193125-15-023732 — 8.01, 9.01
- 2015-01-27 0001193125-15-021857 — 2.02, 9.01
- 2014-11-10 0001193125-14-406296 — 8.01, 9.01
- 2014-10-20 0001193125-14-376361 — 2.02, 9.01
- 2014-07-23 0001193125-14-277193 — 8.01, 9.01
- 2014-07-22 0001193125-14-275598 — 2.02, 9.01
- 2014-07-17 0001193125-14-271698 — 5.02
- 2014-06-06 0001193125-14-228798 — 5.03, 9.01
- 2014-05-30 0001181431-14-021923 — 5.02
- 2014-05-06 0001193125-14-184969 — 8.01, 9.01
- 2014-04-23 0001193125-14-154883 — 7.01, 9.01
- 2014-04-23 0001193125-14-154871 — 2.02, 9.01
- 2014-03-05 0001193125-14-084697 — 5.02, 5.03, 5.07, 9.01
- 2014-01-27 0001193125-14-022238 — 2.02, 9.01
- 2013-10-28 0001193125-13-413498 — 2.02, 9.01
- 2013-09-23 0001181431-13-050140 — 8.01
- 2013-07-30 0001181431-13-041847 — 5.02
- 2013-07-23 0001193125-13-298914 — 2.02, 9.01
- 2013-06-21 0001193125-13-267629 — 5.02
- 2013-05-03 0001193125-13-199324 — 8.01, 9.01
- 2013-04-24 0001193125-13-170623 — 8.01, 9.01
- 2013-04-23 0001193125-13-167469 — 7.01, 9.01
- 2013-04-23 0001193125-13-167458 — 2.02, 9.01
- 2013-03-01 0001193125-13-085842 — 5.07
- 2013-01-23 0001193125-13-020783 — 2.02, 9.01
- 2012-10-25 0001193125-12-435506 — 2.02, 9.01
- 2012-07-24 0001193125-12-312355 — 2.02, 9.01
- 2012-06-28 0001181431-12-038301 — 5.02
- 2012-05-24 0001181431-12-032458 — 5.02
- 2012-04-24 0001193125-12-178928 — 2.02, 9.01
- 2012-02-27 0001193125-12-081892 — 5.07
- 2012-01-24 0001193125-12-021833 — 2.02, 9.01
- 2011-11-16 0001181431-11-056354 — 5.02
- 2011-10-18 0001193125-11-273826 — 2.02, 9.01
- 2011-10-06 0001181431-11-051976 — 8.01
- 2011-08-26 0001181431-11-047179 — 5.02
- 2011-07-19 0001193125-11-191368 — 2.02, 9.01
- 2011-06-15 0001181431-11-036782 — 5.02
- 2011-04-20 0001193125-11-103732 — 2.02, 9.01
- 2011-02-24 0001193125-11-045411 — 5.07
- 2011-01-18 0001193125-11-009392 — 2.02, 9.01
- 2011-01-18 0001181431-11-003847 — 5.02
- 2010-11-17 0001181431-10-056327 — 5.02, 5.03, 9.01
- 2010-10-18 0001193125-10-230992 — 2.02, 9.01
- 2010-07-20 0001193125-10-161807 — 2.02, 9.01
- 2010-04-20 0001193125-10-087786 — 2.02, 9.01
- 2010-03-12 0001181431-10-016054 — 5.02
- 2010-03-01 0001193125-10-044765 — 5.02, 5.07, 9.01
- 2010-01-25 0001193125-10-012096 — 2.02, 9.01
- 2009-10-19 0001193125-09-209633 — 2.02, 9.01
- 2009-08-04 0001181431-09-037492 — 5.02
- 2009-07-21 0001193125-09-152290 — 2.02, 9.01
- 2009-06-02 0001181431-09-028400 — 5.03
- 2009-04-22 0001193125-09-084599 — 2.02, 9.01
- 2009-02-27 0001181431-09-012161 — 4.01
- 2009-01-21 0001193125-09-009009 — 2.02, 9.01
- 2009-01-16 0001181431-09-003017 — 5.02
- 2008-10-21 0001193125-08-213642 — 2.02, 9.01
- 2008-08-26 0001181431-08-050059 — 5.03
- 2008-07-21 0001193125-08-154381 — 2.02, 9.01
- 2008-06-09 0001181431-08-037620 — 8.01
- 2008-04-23 0001193125-08-088001 — 2.02, 9.01
- 2008-01-22 0001193125-08-009715 — 2.02, 9.01
- 2008-01-15 0001181431-08-003342 — 2.02, 8.01
- 2008-01-08 0001181431-08-002372 — 5.02
- 2007-10-22 0001104659-07-076142 — 2.02, 9.01
- 2007-07-25 0001104659-07-056111 — 2.02, 9.01
- 2007-05-16 0001104659-07-040672 — 5.02, 9.01
- 2007-04-25 0001104659-07-031354 — 2.02, 9.01
- 2007-04-24 0001104659-07-030938 — 8.01, 9.01
- 2007-02-21 0001104659-07-012760 — 5.03, 9.01
- 2007-01-17 0001104659-07-002905 — 2.02, 9.01
- 2007-01-10 0001104659-07-001648 — 5.03, 9.01
- 2006-10-27 0001104659-06-069015 — 8.01
- 2006-10-18 0001104659-06-067275 — 2.02, 9.01
- 2006-10-04 0001104659-06-064935 — 5.02, 8.01, 9.01
- 2006-09-01 0001104659-06-058808 — 1.01, 5.02, 5.03, 9.01
- 2006-08-11 0001104659-06-054118 — 2.02, 3.01, 9.01
- 2006-08-04 0001104659-06-051302 — 2.02, 4.02, 9.01
- 2006-07-19 0001104659-06-047739 — 2.02, 9.01
- 2006-04-21 0001181431-06-024759 — 1.01
- 2006-04-19 0001104659-06-025992 — 2.02, 9.01
- 2006-01-18 0001104659-06-002690 — 2.02, 9.01
- 2006-01-10 0001104659-06-001428 — 2.02
- 2005-12-19 0001181431-05-067468 — 1.01
- 2005-10-14 0001181431-05-056604 — 5.02
- 2005-10-11 0001104659-05-048094 — 2.02, 9.01
- 2005-08-26 0001181431-05-049163 — 1.01
- 2005-08-15 0001181431-05-046871 — 1.01
- 2005-07-13 0001104659-05-032297 — 2.02, 9.01
- 2005-06-06 0001181431-05-033177 — 8.01
- 2005-04-26 0001181431-05-023450 — 1.01
- 2005-04-13 0001104659-05-016307 — 2.02, 9.01
- 2005-03-02 0001181431-05-013840 — 3.03, 5.03
- 2005-02-11 0001104659-05-005507 — 8.01
- 2005-01-12 0001104659-05-001183 — 2.02, 9.01
- 2005-01-11 0001104659-05-001049 — 2.02
- 2004-10-13 0001104659-04-030400 — 2.02, 9.01
- 2004-07-14 0001104659-04-019574 — 12, 7
- 2004-04-14 0001104659-04-010122 — 12, 7
- 2004-01-14 0001104659-04-000896 — 12, 7
- 2003-10-15 0001104659-03-022879 — 12, 7
- 2003-07-16 0001104659-03-014913 — 7, 9
- 2003-04-16 0001047469-03-013617 — 7, 9
- 2003-03-21 0001104659-03-004649 — 5, 7
- 2002-08-13 0000912057-02-031595 — 5, 7
- 2002-08-05 0000912057-02-029692 — 5, 7
- 2000-01-24 0000912057-00-002128 — 5, 7
- 1999-09-07 0000320193-99-000010 — 2
- 1999-07-16 0000320193-99-000007 — 2
- 1998-12-23 0000320193-98-000010 — 1
- 1998-01-08 0000320193-98-000001 — 2
- 1997-09-25 0000320193-97-000019 — 2
- 1997-09-25 0000320193-97-000018 — 2
- 1997-09-05 0000320193-97-000016 — 2
- 1997-07-28 0000320193-97-000012 — 4
- 1997-04-25 0000320193-97-000009 — 5
- 1997-04-10 0000320193-97-000007 — 7
- 1996-12-24 0000320193-96-000027 — 7
- 1996-12-23 0000320193-96-000025 — 4 — amendment of 0000320193-96-000021
- 1996-12-13 0000320193-96-000021 — 4
- 1996-10-28 0000912057-96-023874 — 5, 7
- 1996-06-17 0000320193-96-000014 — 1
- 1996-04-12 0000320193-96-000006 — 1

## late-filing notifications on or before 2015-10-28

- 2006-12-15 0001104659-06-081617 — NT 10-K, for the period ended 2006-09-30
- 2006-08-11 0001104659-06-053743 — NT 10-Q, for the period ended 2006-07-01

## item 2.02 — earnings release, exhibit 99.1

[0001193125-15-354756:8k_2_02:1]
EX-99.1
2
d74332dex991.htm
EX-99.1

[0001193125-15-354756:8k_2_02:2]
EX-99.1

[0001193125-15-354756:8k_2_02:3]
Exhibit 99.1

[0001193125-15-354756:8k_2_02:4]
Apple Reports Record Fourth Quarter Results

[0001193125-15-354756:8k_2_02:5]
iPhone, Apple Watch &
App Store Drive Revenue Growth of 22%

[0001193125-15-354756:8k_2_02:6]
CUPERTINO, California — October 27, 2015 — Apple® today announced financial results for its fiscal 2015 fourth quarter ended September 26, 2015. The Company posted quarterly revenue of $51.5 billion and quarterly net profit of $11.1
billion, or $1.96 per diluted share. These results compare to revenue of $42.1 billion and net profit of $8.5 billion, or $1.42 per diluted share, in the year-ago quarter. Gross margin was 39.9 percent compared to 38 percent in the year-ago quarter.
International sales accounted for 62 percent of the quarter’s revenue.

[0001193125-15-354756:8k_2_02:7]
The growth was fueled by record fourth quarter sales of iPhone®, the expanded availability of Apple Watch®, and all-time records for Mac® sales
and revenue from services.

[0001193125-15-354756:8k_2_02:8]
“Fiscal 2015 was Apple’s most successful year ever, with revenue growing 28% to nearly $234 billion. This
continued success is the result of our commitment to making the best, most innovative products on earth, and it’s a testament to the tremendous execution by our teams,” said Tim Cook, Apple’s CEO. “We are heading into the
holidays with our strongest product lineup yet, including iPhone 6s and iPhone 6s Plus, Apple Watch with an expanded lineup of cases and bands, the new iPad Pro and the all-new Apple TV which begins shipping this week.”

[0001193125-15-354756:8k_2_02:9]
“Apple’s record September quarter results drove earnings per share growth of 38% and operating cash flow of $13.5 billion,” said Luca
Maestri, Apple’s CFO. “We returned $17 billion to our investors during the quarter through share repurchases and dividends, and we have now completed over $143 billion of our $200 billion capital return program.”

[0001193125-15-354756:8k_2_02:10]
Apple is providing the following guidance for its fiscal 2016 first quarter:

[0001193125-15-354756:8k_2_02:11]
| • |  | revenue between $75.5 billion and $77.5 billion |

[0001193125-15-354756:8k_2_02:12]
| • |  | gross margin between 39 percent and 40 percent |

[0001193125-15-354756:8k_2_02:13]
| • |  | operating expenses between $6.3 billion and $6.4 billion |

[0001193125-15-354756:8k_2_02:14]
| • |  | other income/(expense) of $400 million |

[0001193125-15-354756:8k_2_02:15]
| • |  | tax rate of 26.2 percent |

[0001193125-15-354756:8k_2_02:16]
Apple’s board of directors has declared a cash dividend of $.52 per share
of the Company’s common stock. The dividend is payable on November 12, 2015, to shareholders of record as of the close of business on November 9, 2015.

[0001193125-15-354756:8k_2_02:17]
Apple will provide live streaming of its Q4 2015 financial results conference call beginning at 2:00 p.m. PDT on October 27, 2015 at
www.apple.com/quicktime/qtv/earningsq415. This webcast will also be available for replay for approximately two weeks thereafter.

[0001193125-15-354756:8k_2_02:18]
Apple revolutionized personal technology with the introduction of the Macintosh in 1984. Today, Apple leads the world in innovation with iPhone,
iPad, the Mac and Apple Watch. Apple’s three software platforms — iOS, OS X and watchOS — provide seamless experiences across all Apple devices and empower people with breakthrough services including the App Store, Apple Music, Apple
Pay and iCloud. Apple’s 100,000 employees are dedicated to making the best products on earth, and to leaving the world better than we found it.

[0001193125-15-354756:8k_2_02:19]
Press
Contact:

[0001193125-15-354756:8k_2_02:20]
Kristin Huguet

[0001193125-15-354756:8k_2_02:21]
Apple

[0001193125-15-354756:8k_2_02:22]
khuguet@apple.com

[0001193125-15-354756:8k_2_02:23]
(408) 974-2414

[0001193125-15-354756:8k_2_02:24]
Investor Relations Contacts:

[0001193125-15-354756:8k_2_02:25]
Nancy Paxton

[0001193125-15-354756:8k_2_02:26]
Apple

[0001193125-15-354756:8k_2_02:27]
paxton1@apple.com

[0001193125-15-354756:8k_2_02:28]
(408) 974-5420

[0001193125-15-354756:8k_2_02:29]
Joan Hoover

[0001193125-15-354756:8k_2_02:30]
Apple

[0001193125-15-354756:8k_2_02:31]
hoover1@apple.com

[0001193125-15-354756:8k_2_02:32]
(408) 974-4570

[0001193125-15-354756:8k_2_02:33]
NOTE TO EDITORS: For additional information visit
Apple’s PR website (www.apple.com/pr), or call Apple’s Media Helpline at (408) 974-2042.

[0001193125-15-354756:8k_2_02:34]
© 2015 Apple Inc. All rights reserved.
Apple, the Apple logo, iPhone, Apple Watch and Mac are trademarks of Apple. Other company and product names may be trademarks of their respective owners.

[0001193125-15-354756:8k_2_02:35]
Apple Inc.

[0001193125-15-354756:8k_2_02:36]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-15-354756:8k_2_02:37]
(In millions, except number of shares which are reflected in thousands and per share amounts)

[0001193125-15-354756:8k_2_02:38]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |
|  |  | September 26,2015 |  |  | September 27,2014 |  |  | September 26,2015 |  |  | September 27,2014 |  |
| Net sales |  | $ | 51,501 |  |  | $ | 42,123 |  |  | $ | 233,715 |  |  | $ | 182,795 |  |
| Cost of sales (1) |  |  | 30,953 |  |  |  | 26,114 |  |  |  | 140,089 |  |  |  | 112,258 |  |
| Gross margin |  |  | 20,548 |  |  |  | 16,009 |  |  |  | 93,626 |  |  |  | 70,537 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development (1) |  |  | 2,220 |  |  |  | 1,686 |  |  |  | 8,067 |  |  |  | 6,041 |  |
| Selling, general and administrative (1) |  |  | 3,705 |  |  |  | 3,158 |  |  |  | 14,329 |  |  |  | 11,993 |  |
| Total operating expenses |  |  | 5,925 |  |  |  | 4,844 |  |  |  | 22,396 |  |  |  | 18,034 |  |
| Operating income |  |  | 14,623 |  |  |  | 11,165 |  |  |  | 71,230 |  |  |  | 52,503 |  |
| Other income/(expense), net |  |  | 439 |  |  |  | 307 |  |  |  | 1,285 |  |  |  | 980 |  |
| Income before provision for income taxes |  |  | 15,062 |  |  |  | 11,472 |  |  |  | 72,515 |  |  |  | 53,483 |  |
| Provision for income taxes |  |  | 3,938 |  |  |  | 3,005 |  |  |  | 19,121 |  |  |  | 13,973 |  |
| Net income |  | $ | 11,124 |  |  | $ | 8,467 |  |  | $ | 53,394 |  |  | $ | 39,510 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.97 |  |  | $ | 1.43 |  |  | $ | 9.28 |  |  | $ | 6.49 |  |
| Diluted |  | $ | 1.96 |  |  | $ | 1.42 |  |  | $ | 9.22 |  |  | $ | 6.45 |  |
| Shares used in computing earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 5,646,916 |  |  |  | 5,933,845 |  |  |  | 5,753,421 |  |  |  | 6,085,572 |  |
| Diluted |  |  | 5,682,519 |  |  |  | 5,972,082 |  |  |  | 5,793,069 |  |  |  | 6,122,663 |  |
| Cash dividends declared per share |  | $ | 0.52 |  |  | $ | 0.47 |  |  | $ | 1.98 |  |  | $ | 1.82 |  |
| (1) Includes share-based compensation expense as follows: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of sales |  | $ | 145 |  |  | $ | 116 |  |  | $ | 575 |  |  | $ | 450 |  |
| Research and development |  | $ | 390 |  |  | $ | 314 |  |  | $ | 1,536 |  |  | $ | 1,216 |  |
| Selling, general and administrative |  | $ | 380 |  |  | $ | 332 |  |  | $ | 1,475 |  |  | $ | 1,197 |  |

[0001193125-15-354756:8k_2_02:39]
Apple Inc.

[0001193125-15-354756:8k_2_02:40]
UNAUDITED CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-15-354756:8k_2_02:41]
(In millions, except number of shares which are reflected in thousands and par value)

[0001193125-15-354756:8k_2_02:42]
|  |  | September 26,2015 |  |  | September 27,2014 |  |
| ASSETS: |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 21,120 |  |  | $ | 13,844 |  |
| Short-term marketable securities |  |  | 20,481 |  |  |  | 11,233 |  |
| Accounts receivable, less allowances of $82 and $86, respectively |  |  | 16,849 |  |  |  | 17,460 |  |
| Inventories |  |  | 2,349 |  |  |  | 2,111 |  |
| Deferred tax assets |  |  | 5,546 |  |  |  | 4,318 |  |
| Vendor non-trade receivables |  |  | 13,494 |  |  |  | 9,759 |  |
| Other current assets |  |  | 9,539 |  |  |  | 9,806 |  |
| Total current assets |  |  | 89,378 |  |  |  | 68,531 |  |
| Long-term marketable securities |  |  | 164,065 |  |  |  | 130,162 |  |
| Property, plant and equipment, net |  |  | 22,471 |  |  |  | 20,624 |  |
| Goodwill |  |  | 5,116 |  |  |  | 4,616 |  |
| Acquired intangible assets, net |  |  | 3,893 |  |  |  | 4,142 |  |
| Other assets |  |  | 5,556 |  |  |  | 3,764 |  |
| Total assets |  | $ | 290,479 |  |  | $ | 231,839 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY: |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 35,490 |  |  | $ | 30,196 |  |
| Accrued expenses |  |  | 25,181 |  |  |  | 18,453 |  |
| Deferred revenue |  |  | 8,940 |  |  |  | 8,491 |  |
| Commercial paper |  |  | 8,499 |  |  |  | 6,308 |  |
| Current portion of long-term debt |  |  | 2,500 |  |  |  | 0 |  |
| Total current liabilities |  |  | 80,610 |  |  |  | 63,448 |  |
| Deferred revenue, non-current |  |  | 3,624 |  |  |  | 3,031 |  |
| Long-term debt |  |  | 53,463 |  |  |  | 28,987 |  |
| Other non-current liabilities |  |  | 33,427 |  |  |  | 24,826 |  |
| Total liabilities |  |  | 171,124 |  |  |  | 120,292 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Shareholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock and additional paid-in capital, $0.00001 par value: 12,600,000 shares authorized; 5,578,753 and 5,866,161 shares issued and outstanding, respectively |  |  | 27,416 |  |  |  | 23,313 |  |
| Retained earnings |  |  | 92,284 |  |  |  | 87,152 |  |
| Accumulated other comprehensive income |  |  | (345 | ) |  |  | 1,082 |  |
| Total shareholders’ equity |  |  | 119,355 |  |  |  | 111,547 |  |
| Total liabilities and shareholders’ equity |  | $ | 290,479 |  |  | $ | 231,839 |  |

[0001193125-15-354756:8k_2_02:43]
Apple Inc.

[0001193125-15-354756:8k_2_02:44]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-15-354756:8k_2_02:45]
(In millions)

[0001193125-15-354756:8k_2_02:46]
|  |  | Twelve Months Ended |  |
|  |  | September 26,2015 |  |  | September 27,2014 |  |
| Cash and cash equivalents, beginning of the period |  | $ | 13,844 |  |  | $ | 14,259 |  |
| Operating activities: |  |  |  |  |
| Net income |  |  | 53,394 |  |  |  | 39,510 |  |
| Adjustments to reconcile net income to cash generated by operating activities: |  |  |  |  |
| Depreciation and amortization |  |  | 11,257 |  |  |  | 7,946 |  |
| Share-based compensation expense |  |  | 3,586 |  |  |  | 2,863 |  |
| Deferred income tax expense |  |  | 1,382 |  |  |  | 2,347 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  |  | 611 |  |  |  | (4,232 | ) |
| Inventories |  |  | (238 | ) |  |  | (76 | ) |
| Vendor non-trade receivables |  |  | (3,735 | ) |  |  | (2,220 | ) |
| Other current and non-current assets |  |  | (179 | ) |  |  | 167 |  |
| Accounts payable |  |  | 5,400 |  |  |  | 5,938 |  |
| Deferred revenue |  |  | 1,042 |  |  |  | 1,460 |  |
| Other current and non-current liabilities |  |  | 8,746 |  |  |  | 6,010 |  |
| Cash generated by operating activities |  |  | 81,266 |  |  |  | 59,713 |  |
| Investing activities: |  |  |  |  |
| Purchases of marketable securities |  |  | (166,402 | ) |  |  | (217,128 | ) |
| Proceeds from maturities of marketable securities |  |  | 14,538 |  |  |  | 18,810 |  |
| Proceeds from sales of marketable securities |  |  | 107,447 |  |  |  | 189,301 |  |
| Payments made in connection with business acquisitions, net |  |  | (343 | ) |  |  | (3,765 | ) |
| Payments for acquisition of property, plant and equipment |  |  | (11,247 | ) |  |  | (9,571 | ) |
| Payments for acquisition of intangible assets |  |  | (241 | ) |  |  | (242 | ) |
| Other |  |  | (26 | ) |  |  | 16 |  |
| Cash used in investing activities |  |  | (56,274 | ) |  |  | (22,579 | ) |
| Financing activities: |  |  |  |  |
| Proceeds from issuance of common stock |  |  | 543 |  |  |  | 730 |  |
| Excess tax benefits from equity awards |  |  | 749 |  |  |  | 739 |  |
| Taxes paid related to net share settlement of equity awards |  |  | (1,499 | ) |  |  | (1,158 | ) |
| Dividends and dividend equivalents paid |  |  | (11,561 | ) |  |  | (11,126 | ) |
| Repurchase of common stock |  |  | (35,253 | ) |  |  | (45,000 | ) |
| Proceeds from issuance of term debt, net |  |  | 27,114 |  |  |  | 11,960 |  |
| Change in commercial paper, net |  |  | 2,191 |  |  |  | 6,306 |  |
| Cash used in financing activities |  |  | (17,716 | ) |  |  | (37,549 | ) |
| Increase/(decrease) in cash and cash equivalents |  |  | 7,276 |  |  |  | (415 | ) |
| Cash and cash equivalents, end of the period |  | $ | 21,120 |  |  | $ | 13,844 |  |
| Supplemental cash flow disclosure: |  |  |  |  |
| Cash paid for income taxes, net |  | $ | 13,252 |  |  | $ | 10,026 |  |
| Cash paid for interest |  | $ | 514 |  |  | $ | 339 |  |
