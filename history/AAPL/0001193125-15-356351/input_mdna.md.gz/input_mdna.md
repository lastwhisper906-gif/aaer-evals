# AAPL MD&A — 0001193125-15-356351


## mdna

[0001193125-15-356351:mdna:1]
| Item 7. | Management’s Discussion and Analysis of Financial Condition and Results of Operations |
