# AAPL 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: no heading matched.


## item_9a

[0001193125-15-356351:item_9a:1]
| Item 9A. | Controls and Procedures |

[0001193125-15-356351:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0001193125-15-356351:item_9a:3]
Based on an evaluation under the supervision and with the participation of the Company’s management, the Company’s principal executive officer
and principal financial officer have concluded that the Company’s disclosure controls and procedures as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended (the “Exchange Act”) were effective
as of September 26, 2015 to provide reasonable assurance that information required to be disclosed by the Company in reports that it files or submits under the Exchange Act is (i) recorded, processed, summarized and reported within the
time periods specified in the Securities and Exchange Commission rules and forms and (ii) accumulated and communicated to the Company’s management, including its principal executive officer and principal financial officer, as appropriate
to allow timely decisions regarding required disclosure.

[0001193125-15-356351:item_9a:4]
Inherent Limitations Over Internal Controls

[0001193125-15-356351:item_9a:5]
The Company’s internal control over financial reporting is designed to provide reasonable assurance regarding the reliability of financial reporting
and the preparation of financial statements for external purposes in accordance with U.S. generally accepted accounting principles (“GAAP”). The Company’s internal control over financial reporting includes those policies and
procedures that:

[0001193125-15-356351:item_9a:6]
|  | (i) | pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the Company’s assets; |

[0001193125-15-356351:item_9a:7]
|  | (ii) | provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with GAAP, and that the Company’s receipts and expenditures are being made only in accordance with authorizations of the Company’s management and directors; and |

[0001193125-15-356351:item_9a:8]
|  | (iii) | provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the Company’s assets that could have a material effect on the financial statements. |

[0001193125-15-356351:item_9a:9]
Management, including the Company’s Chief Executive Officer and Chief
Financial Officer, does not expect that the Company’s internal controls will prevent or detect all errors and all fraud. A control system, no matter how well designed and operated, can provide only reasonable, not absolute, assurance that the
objectives of the control system are met. Further, the design of a control system must reflect the fact that there are resource constraints, and the benefits of controls must be considered relative to their costs. Because of the inherent limitations
in all control systems, no evaluation of internal controls can provide absolute assurance that all control issues and instances of fraud, if any, have been detected. Also, any evaluation of the effectiveness of controls in future periods are subject
to the risk that those internal controls may become inadequate because of changes in business conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001193125-15-356351:item_9a:10]
Management’s Annual Report on Internal Control Over Financial Reporting

[0001193125-15-356351:item_9a:11]
The Company’s management is responsible for establishing and maintaining adequate internal control over financial reporting (as defined in Rule
13a-15(f) under the Exchange Act). Management conducted an assessment of the effectiveness of the Company’s internal control over financial reporting based on the criteria set forth in Internal Control – Integrated Framework issued by the
Committee of Sponsoring Organizations of the Treadway Commission (2013 framework). Based on the Company’s assessment, management has concluded that its internal control over financial reporting was effective as of September 26, 2015 to
provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements in accordance with GAAP. The Company’s independent registered public accounting firm, Ernst & Young LLP, has
issued an audit report on the Company’s internal control over financial reporting, which appears in Part II, Item 8 of this Form 10-K.

[0001193125-15-356351:item_9a:12]
Changes in
Internal Control Over Financial Reporting

[0001193125-15-356351:item_9a:13]
There were no changes in the Company’s internal control over financial reporting during the fourth
quarter of 2015, which were identified in connection with management’s evaluation required by paragraph (d) of rules 13a-15 and 15d-15 under the Exchange Act, that have materially affected, or are reasonably likely to materially affect,
the Company’s internal control over financial reporting.
