# AAPL notes — 0001193125-15-356351


## us-gaap:ScheduleOfEffectiveIncomeTaxRateReconciliationTableTextBlock

[0001193125-15-356351:notes:1]
A reconciliation of the provision for income taxes,
 with the amount computed by applying the statutory federal income
 tax rate (35% in 2015, 2014 and 2013) to income before provision
 for income taxes for 2015, 2014 and 2013, is as follows (dollars in
 millions):

[0001193125-15-356351:notes:2]
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Computed expected tax |  | $ | 25,380 |  |  | $ | 18,719 |  |  | $ | 17,554 |  |
| State taxes, net of federal effect |  |  | 680 |  |  |  | 469 |  |  |  | 508 |  |
| Indefinitely invested earnings of foreign subsidiaries |  |  | (6,470 | ) |  |  | (4,744 | ) |  |  | (4,614 | ) |
| Domestic production activities deduction |  |  | (426 | ) |  |  | (495 | ) |  |  | (308 | ) |
| Research and development credit, net |  |  | (171 | ) |  |  | (88 | ) |  |  | (287 | ) |
| Other |  |  | 128 |  |  |  | 112 |  |  |  | 265 |  |
| Provision for income taxes |  | $ | 19,121 |  |  | $ | 13,973 |  |  | $ | 13,118 |  |
| Effective tax rate |  |  | 26.4% |  |  |  | 26.1% |  |  |  | 26.2% |  |


## us-gaap:ResearchDevelopmentAndComputerSoftwarePolicyTextBlock

[0001193125-15-356351:notes:3]
Software Development Costs

[0001193125-15-356351:notes:4]
Research and development (“R&D”)
 costs are expensed as incurred. Development costs of computer
 software to be sold, leased, or otherwise marketed are subject to
 capitalization beginning when a product’s technological
 feasibility has been established and ending when a product is
 available for general release to customers. In most instances, the
 Company’s products are released soon after technological
 feasibility has been established and as a result software
 development costs were expensed as incurred.


## us-gaap:ScheduleOfDerivativeInstrumentsInStatementOfFinancialPositionFairValueTextBlock

[0001193125-15-356351:notes:5]
The following tables show the Company’s
 derivative instruments at gross fair value as of September 26,
 2015 and September 27, 2014 (in millions):

[0001193125-15-356351:notes:6]
|  |  | 2015 |
|  |  | Fair Value of Derivatives Designated as Hedge Instruments |  | Fair Value of Derivatives Not Designated as Hedge Instruments |  | Total Fair Value |
| Derivative assets (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  |  | $ | 1,442 |  |  |  | $ | 109 |  |  |  | $ | 1,551 |  |
| Interest rate contracts |  |  | $ | 394 |  |  |  | $ | 0 |  |  |  | $ | 394 |  |
| Derivative liabilities (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  |  | $ | 905 |  |  |  | $ | 94 |  |  |  | $ | 999 |  |
| Interest rate contracts |  |  | $ | 13 |  |  |  | $ | 0 |  |  |  | $ | 13 |  |

[0001193125-15-356351:notes:7]
|  |  | 2014 |
|  |  | Fair Value of Derivatives Designated as Hedge Instruments |  | Fair Value of Derivatives Not Designated as Hedge Instruments |  | Total Fair Value |
| Derivative assets (1): |  |  |  |  |  |
| Foreign exchange contracts |  |  | $ | 1,332 |  |  |  | $ | 222 |  |  |  | $ | 1,554 |  |
| Interest rate contracts |  |  | $ | 81 |  |  |  | $ | 0 |  |  |  | $ | 81 |  |
| Derivative liabilities (2): |  |  |  |  |  |
| Foreign exchange contracts |  |  | $ | 41 |  |  |  | $ | 40 |  |  |  | $ | 81 |  |

[0001193125-15-356351:notes:8]
|  | (1) | The fair value of derivative assets is measured using Level 2 fair value inputs and is recorded as other current assets in the Consolidated Balance Sheets. |  |

[0001193125-15-356351:notes:9]
|  | (2) | The fair value of derivative liabilities is measured using Level 2 fair value inputs and is recorded as accrued expenses in the Consolidated Balance Sheets. |  |


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001193125-15-356351:notes:10]
Net sales for 2015, 2014 and 2013 are as follows
 (in millions):

[0001193125-15-356351:notes:11]
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Net sales: |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. |  | $ | 81,732 |  |  | $ | 68,909 |  |  | $ | 66,197 |  |
| China (1) |  |  | 56,547 |  |  |  | 30,638 |  |  |  | 25,946 |  |
| Other countries |  |  | 95,436 |  |  |  | 83,248 |  |  |  | 78,767 |  |
| Total net sales |  | $ | 233,715 |  |  | $ | 182,795 |  |  | $ | 170,910 |  |

[0001193125-15-356351:notes:12]
|  | (1) | China includes Hong Kong. |


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001193125-15-356351:notes:13]
A reconciliation of the Company’s segment
 operating income to the Consolidated Statements of Operations for
 2015, 2014 and 2013 is as follows (in millions):

[0001193125-15-356351:notes:14]
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Segment operating income |  | $ | 83,850 |  |  | $ | 62,209 |  |  | $ | 56,525 |  |
| Research and development expense |  |  | (8,067 | ) |  |  | (6,041 | ) |  |  | (4,475 | ) |
| Other corporate expenses, net |  |  | (4,553 | ) |  |  | (3,665 | ) |  |  | (3,051 | ) |
| Total operating income |  | $ | 71,230 |  |  | $ | 52,503 |  |  | $ | 48,999 |  |


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001193125-15-356351:notes:15]
The following table shows the computation of basic
 and diluted earnings per share for 2015, 2014 and 2013 (net income
 in millions and shares in thousands):

[0001193125-15-356351:notes:16]
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 53,394 |  |  | $ | 39,510 |  |  | $ | 37,037 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding |  |  | 5,753,421 |  |  |  | 6,085,572 |  |  |  | 6,477,320 |  |
| Effect of dilutive securities |  |  | 39,648 |  |  |  | 37,091 |  |  |  | 44,314 |  |
| Weighted-average diluted shares |  |  | 5,793,069 |  |  |  | 6,122,663 |  |  |  | 6,521,634 |  |
| Basic earnings per share |  | $ | 9.28 |  |  | $ | 6.49 |  |  | $ | 5.72 |  |
| Diluted earnings per share |  | $ | 9.22 |  |  | $ | 6.45 |  |  | $ | 5.68 |  |


## us-gaap:DebtDisclosureTextBlock

[0001193125-15-356351:notes:17]
Note 6 – Debt

[0001193125-15-356351:notes:18]
Commercial Paper

[0001193125-15-356351:notes:19]
In 2014, the Board of Directors authorized the
 Company to issue unsecured short-term promissory notes
 (“Commercial Paper”) pursuant to a commercial paper
 program. The Company intends to use net proceeds from the
 commercial paper program for general corporate purposes, including
 dividends and share repurchases. As of September 26, 2015 and
 September 27, 2014, the Company had $8.5 billion and $6.3
 billion of Commercial Paper outstanding, respectively, with a
 weighted-average interest rate of 0.14% and 0.12%, respectively,
 and maturities generally less than nine months.

[0001193125-15-356351:notes:20]
The following table provides a summary of cash
 flows associated with the issuance and maturities of Commercial
 Paper for 2015 and 2014 (in millions):

[0001193125-15-356351:notes:21]
|  |  | 2015 |  |  | 2014 |  |
| Maturities less than 90 days: |  |  |  |  |  |  |  |  |
| Proceeds from (repayments of) commercial paper, net |  | $ | 5,293 |  |  | $ | 1,865 |  |
| Maturities greater than 90 days: |  |  |  |  |  |  |  |  |
| Proceeds from commercial paper |  |  | 3,851 |  |  |  | 4,771 |  |
| Repayments of commercial paper |  |  | (6,953 | ) |  |  | (330 | ) |
| Maturities greater than 90 days, net |  |  | (3,102 | ) |  |  | 4,441 |  |
| Total change in commercial paper, net |  | $ | 2,191 |  |  | $ | 6,306 |  |

[0001193125-15-356351:notes:22]
Long-Term Debt

[0001193125-15-356351:notes:23]
As of September 26, 2015, the Company had
 outstanding floating- and fixed-rate notes with varying maturities
 for an aggregate principal amount of $55.7 billion (collectively
 the “Notes”). The Notes are senior unsecured
 obligations, and interest is payable in arrears, quarterly for the
 U.S. dollar-denominated and Australian dollar-denominated
 floating-rate notes, semi-annually for the U.S. dollar-denominated,
 Australian dollar-denominated, British pound-denominated and
 Japanese yen-denominated fixed-rate notes and annually for the
 euro-denominated and Swiss franc-denominated fixed-rate notes.

[0001193125-15-356351:notes:24]
The following table provides a summary of the
 Company’s term debt as of September 26, 2015 and
 September 27, 2014:

[0001193125-15-356351:notes:25]
|  |  |  |  |  | 2015 |  |  | 2014 |  |
|  |  | Maturities |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2016 – 2018 |  |  | $ | 3,000 |  |  |  | 0.51% – 1.10% |  |  | $ | 3,000 |  |  |  | 0.51% – 1.10% |  |
| Fixed-rate 0.45% – 3.85% notes |  |  | 2016 – 2043 |  |  |  | 14,000 |  |  |  | 0.51% – 3.91% |  |  |  | 14,000 |  |  |  | 0.51% – 3.91% |  |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2017 – 2019 |  |  |  | 2,000 |  |  |  | 0.37% – 0.60% |  |  |  | 2,000 |  |  |  | 0.31% – 0.54% |  |
| Fixed-rate 1.05% – 4.45% notes |  |  | 2017 – 2044 |  |  |  | 10,000 |  |  |  | 0.37% – 4.48% |  |  |  | 10,000 |  |  |  | 0.30% – 4.48% |  |
| First quarter 2015 euro-denominated debt issuance of €2.8 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 1.000% notes |  |  | 2022 |  |  |  | 1,558 |  |  |  | 2.94% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 1.625% notes |  |  | 2026 |  |  |  | 1,558 |  |  |  | 3.45% |  |  |  | 0 |  |  |  | 0 |  |
| Second quarter 2015 debt issuance of $6.5 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2020 |  |  |  | 500 |  |  |  | 0.56% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 1.55% notes |  |  | 2020 |  |  |  | 1,250 |  |  |  | 0.56% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.15% notes |  |  | 2022 |  |  |  | 1,250 |  |  |  | 0.87% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.50% notes |  |  | 2025 |  |  |  | 1,500 |  |  |  | 2.60% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 3.45% notes |  |  | 2045 |  |  |  | 2,000 |  |  |  | 3.58% |  |  |  | 0 |  |  |  | 0 |  |
| Second quarter 2015 Swiss franc-denominated debt issuance of SFr1.25 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.375% notes |  |  | 2024 |  |  |  | 895 |  |  |  | 0.28% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 0.750% notes |  |  | 2030 |  |  |  | 384 |  |  |  | 0.74% |  |  |  | 0 |  |  |  | 0 |  |
| Third quarter 2015 debt issuance of $8.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2017 |  |  |  | 250 |  |  |  | 0.36% |  |  |  | 0 |  |  |  | 0 |  |
| Floating-rate notes |  |  | 2020 |  |  |  | 500 |  |  |  | 0.61% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 0.900% notes |  |  | 2017 |  |  |  | 750 |  |  |  | 0.35% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.000% notes |  |  | 2020 |  |  |  | 1,250 |  |  |  | 0.61% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.700% notes |  |  | 2022 |  |  |  | 1,250 |  |  |  | 0.99% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 3.200% notes |  |  | 2025 |  |  |  | 2,000 |  |  |  | 1.22% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 4.375% notes |  |  | 2045 |  |  |  | 2,000 |  |  |  | 4.40% |  |  |  | 0 |  |  |  | 0 |  |
| Third quarter 2015 Japanese yen-denominated debt issuance of ¥250.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.35% notes |  |  | 2020 |  |  |  | 2,081 |  |  |  | 0.35% |  |  |  | 0 |  |  |  | 0 |  |
| Fourth quarter 2015 British pound-denominated debt issuance of £1.25 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 3.05% notes |  |  | 2029 |  |  |  | 1,148 |  |  |  | 3.79% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 3.60% notes |  |  | 2042 |  |  |  | 766 |  |  |  | 4.51% |  |  |  | 0 |  |  |  | 0 |  |
| Fourth quarter 2015 Australian dollar-denominated debt issuance of A$2.25 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2019 |  |  |  | 493 |  |  |  | 1.87% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.85% notes |  |  | 2019 |  |  |  | 282 |  |  |  | 1.89% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 3.70% notes |  |  | 2022 |  |  |  | 810 |  |  |  | 2.79% |  |  |  | 0 |  |  |  | 0 |  |
| Fourth quarter 2015 euro-denominated debt issuance of €2.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 1.375% notes |  |  | 2024 |  |  |  | 1,113 |  |  |  | 3.30% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.000% notes |  |  | 2027 |  |  |  | 1,113 |  |  |  | 3.85% |  |  |  | 0 |  |  |  | 0 |  |
| Total term debt |  |  |  |  |  |  | 55,701 |  |  |  |  |  |  |  | 29,000 |  |  |  |  |  |
| Unamortized discount |  |  |  |  |  |  | (114 | ) |  |  |  |  |  |  | (52 | ) |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  |  |  | 376 |  |  |  |  |  |  |  | 39 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | (2,500 | ) |  |  |  |  |  |  | 0 |  |  |  |  |  |
| Total long-term debt |  |  |  |  |  | $ | 53,463 |  |  |  |  |  |  | $ | 28,987 |  |  |  |  |  |

[0001193125-15-356351:notes:26]
To manage foreign currency risk associated with the
 euro-denominated notes issued in the first quarter of 2015 and the
 British pound-denominated, Australian dollar-denominated and
 euro-denominated notes issued in the fourth quarter of 2015, the
 Company entered into currency swaps with an aggregate notional
 amount of $3.5 billion, $1.9 billion, $1.6 billion and $2.2
 billion, respectively, which effectively converted these notes to
 U.S. dollar-denominated notes.

[0001193125-15-356351:notes:27]
To manage interest rate risk on the U.S.
 dollar-denominated fixed-rate notes issued in the second quarter of
 2015 and maturing in 2020 and 2022, the Company entered into
 interest rate swaps with an aggregate notional amount of $2.5
 billion. To manage interest rate risk on the U.S.
 dollar-denominated fixed-rate notes issued in the third quarter of
 2015 and maturing in 2017, 2020, 2022 and 2025, the Company entered
 into interest rate swaps with an aggregate notional amount of $4.3
 billion. These interest rate swaps effectively converted the fixed
 interest rates on the U.S. dollar-denominated notes to a floating
 interest rate.

[0001193125-15-356351:notes:28]
As of September 26, 2015, ¥250.0 billion
 of the Japanese yen-denominated notes was designated as a hedge of
 the foreign currency exposure of its net investment in a foreign
 operation. The foreign currency transaction gain or loss on the
 Japanese yen-denominated debt designated as a hedge is recorded in
 OCI as a part of the cumulative translation adjustment. As of
 September 26, 2015, the carrying value of the debt designated
 as a net investment hedge was $2.1 billion.

[0001193125-15-356351:notes:29]
For further discussion regarding the
 Company’s use of derivative instruments see the Derivative
 Financial Instruments section of Note 2, “Financial
 Instruments.”

[0001193125-15-356351:notes:30]
The effective interest rates for the Notes include
 the interest on the Notes, amortization of the discount and, if
 applicable, adjustments related to hedging. The Company recognized
 $722 million, $381 million and $136 million of interest expense on
 its term debt for 2015, 2014 and 2013, respectively.

[0001193125-15-356351:notes:31]
The future principal payments for the
 Company’s Notes as of September 26, 2015 are as follows
 (in millions):

[0001193125-15-356351:notes:32]
| 2016 |  | $ | 2,500 |  |
| 2017 |  |  | 3,500 |  |
| 2018 |  |  | 6,000 |  |
| 2019 |  |  | 3,775 |  |
| 2020 |  |  | 5,581 |  |
| Thereafter |  |  | 34,345 |  |
| Total term debt |  | $ | 55,701 |  |

[0001193125-15-356351:notes:33]
As of September 26, 2015 and
 September 27, 2014, the fair value of the Company’s
 Notes, based on Level 2 inputs, was $54.9 billion and $28.5
 billion, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-15-356351:notes:34]
Note 11 – Segment Information and Geographic Data

[0001193125-15-356351:notes:35]
The Company reports segment information based on
 the “management” approach. The management approach
 designates the internal reporting used by management for making
 decisions and assessing performance as the source of the
 Company’s reportable operating segments.

[0001193125-15-356351:notes:36]
The Company manages its business primarily on a
 geographic basis. The Company’s reportable operating segments
 consist of the Americas, Europe, Greater China, Japan and Rest of
 Asia Pacific. The Americas segment includes both North and South
 America. The Europe segment includes European countries, as well as
 India, the Middle East and Africa. The Greater China segment
 includes China, Hong Kong and Taiwan. The Rest of Asia Pacific
 segment includes Australia and those Asian countries not included
 in the Company’s other reportable operating segments.
 Although each reportable operating segment provides similar
 hardware and software products and similar services, they are
 managed separately to better align with the location of the
 Company’s customers and distribution partners and the unique
 market dynamics of each geographic region. The accounting policies
 of the various segments are the same as those described in Note 1,
 “Summary of Significant Accounting Policies.”

[0001193125-15-356351:notes:37]
The Company evaluates the performance of its
 reportable operating segments based on net sales and operating
 income. Net sales for geographic segments are generally based on
 the location of customers and sales through the Company’s
 retail stores located in those geographic locations. Operating
 income for each segment includes net sales to third parties,
 related cost of sales and operating expenses directly attributable
 to the segment. Advertising expenses are generally included in the
 geographic segment in which the expenditures are incurred.
 Operating income for each segment excludes other income and expense
 and certain expenses managed outside the reportable operating
 segments. Costs excluded from segment operating income include
 various corporate expenses such as R&D, corporate marketing
 expenses, certain share-based compensation expenses, income taxes,
 various nonrecurring charges and other separately managed general
 and administrative costs. The Company does not include intercompany
 transfers between segments for management reporting purposes.

[0001193125-15-356351:notes:38]
The following table shows information by reportable
 operating segment for 2015, 2014 and 2013 (in millions):

[0001193125-15-356351:notes:39]
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 93,864 |  |  | $ | 80,095 |  |  | $ | 77,093 |  |
| Operating income |  | $ | 31,186 |  |  | $ | 26,158 |  |  | $ | 24,829 |  |
| Europe: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 50,337 |  |  | $ | 44,285 |  |  | $ | 40,980 |  |
| Operating income |  | $ | 16,527 |  |  | $ | 14,434 |  |  | $ | 12,767 |  |
| Greater China: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 58,715 |  |  | $ | 31,853 |  |  | $ | 27,016 |  |
| Operating income |  | $ | 23,002 |  |  | $ | 11,039 |  |  | $ | 8,499 |  |
| Japan: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 15,706 |  |  | $ | 15,314 |  |  | $ | 13,782 |  |
| Operating income |  | $ | 7,617 |  |  | $ | 6,904 |  |  | $ | 6,668 |  |
| Rest of Asia Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 15,093 |  |  | $ | 11,248 |  |  | $ | 12,039 |  |
| Operating income |  | $ | 5,518 |  |  | $ | 3,674 |  |  | $ | 3,762 |  |

[0001193125-15-356351:notes:40]
The U.S. and China were the only countries that
 accounted for more than 10% of the Company’s net sales in
 2015, 2014 and 2013. There was no single customer that accounted
 for more than 10% of net sales in 2015, 2014 or 2013. Net sales for
 2015, 2014 and 2013 and long-lived assets as of September 26,
 2015 and September 27, 2014 are as follows (in millions):

[0001193125-15-356351:notes:41]
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Net sales: |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. |  | $ | 81,732 |  |  | $ | 68,909 |  |  | $ | 66,197 |  |
| China (1) |  |  | 56,547 |  |  |  | 30,638 |  |  |  | 25,946 |  |
| Other countries |  |  | 95,436 |  |  |  | 83,248 |  |  |  | 78,767 |  |
| Total net sales |  | $ | 233,715 |  |  | $ | 182,795 |  |  | $ | 170,910 |  |
|  |  | 2015 |  |  | 2014 |  |  |  |  |
| Long-lived assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. |  | $ | 12,022 |  |  | $ | 9,108 |  |  |  |  |  |
| China (1) |  |  | 8,722 |  |  |  | 9,477 |  |  |  |  |  |
| Other countries |  |  | 3,040 |  |  |  | 2,917 |  |  |  |  |  |
| Total long-lived assets |  | $ | 23,784 |  |  | $ | 21,502 |  |  |  |  |  |

[0001193125-15-356351:notes:42]
|  | (1) | China includes Hong Kong. Long-lived assets located in China consist primarily of product tooling and manufacturing process equipment and assets related to retail stores and related infrastructure. |  |

[0001193125-15-356351:notes:43]
Net sales by product for 2015, 2014 and 2013 are as
 follows (in millions):

[0001193125-15-356351:notes:44]
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Net Sales by Product: |  |  |  |  |  |  |  |  |  |  |  |  |
| iPhone (1) |  | $ | 155,041 |  |  | $ | 101,991 |  |  | $ | 91,279 |  |
| iPad (1) |  |  | 23,227 |  |  |  | 30,283 |  |  |  | 31,980 |  |
| Mac (1) |  |  | 25,471 |  |  |  | 24,079 |  |  |  | 21,483 |  |
| Services (2) |  |  | 19,909 |  |  |  | 18,063 |  |  |  | 16,051 |  |
| Other Products (1)(3) |  |  | 10,067 |  |  |  | 8,379 |  |  |  | 10,117 |  |
| Total net sales |  | $ | 233,715 |  |  | $ | 182,795 |  |  | $ | 170,910 |  |

[0001193125-15-356351:notes:45]
|  | (1) | Includes deferrals and amortization of related software upgrade rights and non-software services. |  |

[0001193125-15-356351:notes:46]
|  | (2) | Includes revenue from the iTunes Store, App Store, Mac App Store, iBooks Store, Apple Music, AppleCare, Apple Pay, licensing and other services. |  |

[0001193125-15-356351:notes:47]
|  | (3) | Includes sales of Apple TV, Apple Watch, Beats products, iPod and Apple-branded and third-party accessories. |  |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001193125-15-356351:notes:48]
The expected annual amortization expense related to
 acquired intangible assets as of September 26, 2015, is as
 follows (in millions):

[0001193125-15-356351:notes:49]
| 2016 |  | $ | 1,288 |  |
| 2017 |  |  | 1,033 |  |
| 2018 |  |  | 786 |  |
| 2019 |  |  | 342 |  |
| 2020 |  |  | 166 |  |
| Thereafter |  |  | 178 |  |
| Total |  | $ | 3,793 |  |


## us-gaap:AcceleratedShareRepurchasesTextBlock

[0001193125-15-356351:notes:50]
The following table shows the Company’s ASR
 activity and related information during the years ended
 September 26, 2015 and September 27, 2014:

[0001193125-15-356351:notes:51]
|  |  | Purchase Period End Date |  |  | Number of Shares(in thousands) |  |  | Average Repurchase Price Per Share |  |  | ASR Amount (in millions) |  |
| May 2015 ASR |  |  | July 2015 |  |  |  | 48,293 | (1) |  | $ | 124.24 |  |  | $ | 6,000 |  |
| August 2014 ASR |  |  | February 2015 |  |  |  | 81,525 | (2) |  | $ | 110.40 |  |  | $ | 9,000 |  |
| January 2014 ASR |  |  | December 2014 |  |  |  | 134,247 |  |  | $ | 89.39 |  |  | $ | 12,000 |  |
| April 2013 ASR |  |  | March 2014 |  |  |  | 172,548 |  |  | $ | 69.55 |  |  | $ | 12,000 |  |

[0001193125-15-356351:notes:52]
|  | (1) | Includes 38.3 million shares delivered and retired at the beginning of the purchase period, which began in the third quarter of 2015 and 10.0 million shares delivered and retired at the end of the purchase period, which concluded in the fourth quarter of 2015. |  |

[0001193125-15-356351:notes:53]
|  | (2) | Includes 59.9 million shares delivered and retired at the beginning of the purchase period, which began in the fourth quarter of 2014, 8.3 million net shares delivered and retired in the first quarter of 2015 and 13.3 million shares delivered and retired at the end of the purchase period, which concluded in the second quarter of 2015. |  |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001193125-15-356351:notes:54]
The following tables show the Company’s cash
 and available-for-sale
 securities’ adjusted cost, gross unrealized gains, gross
 unrealized losses and fair value by significant investment category
 recorded as cash and cash equivalents or short- or long-term
 marketable securities as of September 26, 2015 and
 September 27, 2014 (in millions):

[0001193125-15-356351:notes:55]
|  |  | 2015 |  |
|  |  | Adjusted Cost |  |  | Unrealized Gains |  |  | Unrealized Losses |  |  | Fair Value |  |  | Cash and Cash Equivalents |  |  | Short-Term Marketable Securities |  |  | Long-Term Marketable Securities |  |
| Cash |  | $ | 11,389 |  |  | $ | 0 |  |  | $ | 0 |  |  | $ | 11,389 |  |  | $ | 11,389 |  |  | $ | 0 |  |  | $ | 0 |  |
| Level 1: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  |  | 1,798 |  |  |  | 0 |  |  |  | 0 |  |  |  | 1,798 |  |  |  | 1,798 |  |  |  | 0 |  |  |  | 0 |  |
| Mutual funds |  |  | 1,772 |  |  |  | 0 |  |  |  | (144 | ) |  |  | 1,628 |  |  |  | 0 |  |  |  | 1,628 |  |  |  | 0 |  |
| Subtotal |  |  | 3,570 |  |  |  | 0 |  |  |  | (144 | ) |  |  | 3,426 |  |  |  | 1,798 |  |  |  | 1,628 |  |  |  | 0 |  |
| Level 2: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities |  |  | 34,902 |  |  |  | 181 |  |  |  | (1 | ) |  |  | 35,082 |  |  |  | 0 |  |  |  | 3,498 |  |  |  | 31,584 |  |
| U.S. agency securities |  |  | 5,864 |  |  |  | 14 |  |  |  | 0 |  |  |  | 5,878 |  |  |  | 841 |  |  |  | 767 |  |  |  | 4,270 |  |
| Non-U.S. government securities |  |  | 6,356 |  |  |  | 45 |  |  |  | (167 | ) |  |  | 6,234 |  |  |  | 43 |  |  |  | 135 |  |  |  | 6,056 |  |
| Certificates of deposit and time deposits |  |  | 4,347 |  |  |  | 0 |  |  |  | 0 |  |  |  | 4,347 |  |  |  | 2,065 |  |  |  | 1,405 |  |  |  | 877 |  |
| Commercial paper |  |  | 6,016 |  |  |  | 0 |  |  |  | 0 |  |  |  | 6,016 |  |  |  | 4,981 |  |  |  | 1,035 |  |  |  | 0 |  |
| Corporate securities |  |  | 116,908 |  |  |  | 242 |  |  |  | (985 | ) |  |  | 116,165 |  |  |  | 3 |  |  |  | 11,948 |  |  |  | 104,214 |  |
| Municipal securities |  |  | 947 |  |  |  | 5 |  |  |  | 0 |  |  |  | 952 |  |  |  | 0 |  |  |  | 48 |  |  |  | 904 |  |
| Mortgage- and asset-backed securities |  |  | 16,121 |  |  |  | 87 |  |  |  | (31 | ) |  |  | 16,177 |  |  |  | 0 |  |  |  | 17 |  |  |  | 16,160 |  |
| Subtotal |  |  | 191,461 |  |  |  | 574 |  |  |  | (1,184 | ) |  |  | 190,851 |  |  |  | 7,933 |  |  |  | 18,853 |  |  |  | 164,065 |  |
| Total |  | $ | 206,420 |  |  | $ | 574 |  |  | $ | (1,328 | ) |  | $ | 205,666 |  |  | $ | 21,120 |  |  | $ | 20,481 |  |  | $ | 164,065 |  |

[0001193125-15-356351:notes:56]
|  |  | 2014 |  |
|  |  | Adjusted Cost |  |  | Unrealized Gains |  |  | Unrealized Losses |  |  | Fair Value |  |  | Cash and Cash Equivalents |  |  | Short-Term Marketable Securities |  |  | Long-Term Marketable Securities |  |
| Cash |  | $ | 10,232 |  |  | $ | 0 |  |  | $ | 0 |  |  | $ | 10,232 |  |  | $ | 10,232 |  |  | $ | 0 |  |  | $ | 0 |  |
| Level 1: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  |  | 1,546 |  |  |  | 0 |  |  |  | 0 |  |  |  | 1,546 |  |  |  | 1,546 |  |  |  | 0 |  |  |  | 0 |  |
| Mutual funds |  |  | 2,531 |  |  |  | 1 |  |  |  | (132 | ) |  |  | 2,400 |  |  |  | 0 |  |  |  | 2,400 |  |  |  | 0 |  |
| Subtotal |  |  | 4,077 |  |  |  | 1 |  |  |  | (132 | ) |  |  | 3,946 |  |  |  | 1,546 |  |  |  | 2,400 |  |  |  | 0 |  |
| Level 2: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities |  |  | 23,140 |  |  |  | 15 |  |  |  | (9 | ) |  |  | 23,146 |  |  |  | 12 |  |  |  | 607 |  |  |  | 22,527 |  |
| U.S. agency securities |  |  | 7,373 |  |  |  | 3 |  |  |  | (11 | ) |  |  | 7,365 |  |  |  | 652 |  |  |  | 157 |  |  |  | 6,556 |  |
| Non-U.S. government securities |  |  | 6,925 |  |  |  | 69 |  |  |  | (69 | ) |  |  | 6,925 |  |  |  | 0 |  |  |  | 204 |  |  |  | 6,721 |  |
| Certificates of deposit and time deposits |  |  | 3,832 |  |  |  | 0 |  |  |  | 0 |  |  |  | 3,832 |  |  |  | 1,230 |  |  |  | 1,233 |  |  |  | 1,369 |  |
| Commercial paper |  |  | 475 |  |  |  | 0 |  |  |  | 0 |  |  |  | 475 |  |  |  | 166 |  |  |  | 309 |  |  |  | 0 |  |
| Corporate securities |  |  | 85,431 |  |  |  | 296 |  |  |  | (241 | ) |  |  | 85,486 |  |  |  | 6 |  |  |  | 6,298 |  |  |  | 79,182 |  |
| Municipal securities |  |  | 940 |  |  |  | 8 |  |  |  | 0 |  |  |  | 948 |  |  |  | 0 |  |  |  | 0 |  |  |  | 948 |  |
| Mortgage- and asset-backed securities |  |  | 12,907 |  |  |  | 26 |  |  |  | (49 | ) |  |  | 12,884 |  |  |  | 0 |  |  |  | 25 |  |  |  | 12,859 |  |
| Subtotal |  |  | 141,023 |  |  |  | 417 |  |  |  | (379 | ) |  |  | 141,061 |  |  |  | 2,066 |  |  |  | 8,833 |  |  |  | 130,162 |  |
| Total |  | $ | 155,332 |  |  | $ | 418 |  |  | $ | (511 | ) |  | $ | 155,239 |  |  | $ | 13,844 |  |  | $ | 11,233 |  |  | $ | 130,162 |  |


## us-gaap:DividendsDeclaredTableTextBlock

[0001193125-15-356351:notes:57]
The Company declared and paid cash dividends per
 share during the periods presented as follows:

[0001193125-15-356351:notes:58]
|  |  | Dividends Per Share |  |  | Amount(in millions) |  |
| 2015: |  |  |  |  |  |  |  |  |
| Fourth quarter |  | $ | 0.52 |  |  | $ | 2,950 |  |
| Third quarter |  |  | 0.52 |  |  |  | 2,997 |  |
| Second quarter |  |  | 0.47 |  |  |  | 2,734 |  |
| First quarter |  |  | 0.47 |  |  |  | 2,750 |  |
| Total cash dividends declared and paid |  | $ | 1.98 |  |  | $ | 11,431 |  |
| 2014: |  |  |  |  |  |  |  |  |
| Fourth quarter |  | $ | 0.47 |  |  | $ | 2,807 |  |
| Third quarter |  |  | 0.47 |  |  |  | 2,830 |  |
| Second quarter |  |  | 0.44 |  |  |  | 2,655 |  |
| First quarter |  |  | 0.44 |  |  |  | 2,739 |  |
| Total cash dividends declared and paid |  | $ | 1.82 |  |  | $ | 11,031 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001193125-15-356351:notes:59]
Basis of Presentation and Preparation

[0001193125-15-356351:notes:60]
The accompanying consolidated financial statements
 include the accounts of the Company. Intercompany accounts and
 transactions have been eliminated. In the opinion of the
 Company’s management, the consolidated financial statements
 reflect all adjustments, which are normal and recurring in nature,
 necessary for fair financial statement presentation. The
 preparation of these consolidated financial statements in
 conformity with U.S. generally accepted accounting principles
 (“GAAP”) requires management to make estimates and
 assumptions that affect the amounts reported in these consolidated
 financial statements and accompanying notes. Actual results could
 differ materially from those estimates.

[0001193125-15-356351:notes:61]
The Company’s fiscal year is the 52 or
 53-week period that ends on the last Saturday of September. The
 Company’s fiscal years 2015, 2014 and 2013 ended on
 September 26, 2015, September 27, 2014 and
 September 28, 2013, respectively. An additional week is
 included in the first fiscal quarter approximately every six years
 to realign fiscal quarters with calendar quarters. Fiscal years
 2015, 2014 and 2013 each spanned 52 weeks. Unless otherwise stated,
 references to particular years, quarters, months and periods refer
 to the Company’s fiscal years ended in September and the
 associated quarters, months and periods of those fiscal years.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001193125-15-356351:notes:62]
Earnings Per Share

[0001193125-15-356351:notes:63]
Basic earnings per share is computed by dividing
 income available to common shareholders by the weighted-average
 number of shares of common stock outstanding during the period.
 Diluted earnings per share is computed by dividing income available
 to common shareholders by the weighted-average number of shares of
 common stock outstanding during the period increased to include the
 number of additional shares of common stock that would have been
 outstanding if the potentially dilutive securities had been issued.
 Potentially dilutive securities include outstanding stock options,
 shares to be purchased under the Company’s employee stock
 purchase plan, unvested restricted stock and unvested RSUs. The
 dilutive effect of potentially dilutive securities is reflected in
 diluted earnings per share by application of the treasury stock
 method. Under the treasury stock method, an increase in the fair
 market value of the Company’s common stock can result in a
 greater dilutive effect from potentially dilutive securities.

[0001193125-15-356351:notes:64]
Potentially dilutive securities whose effect would
 have been antidilutive are excluded from the computation of diluted
 earnings per share.


## us-gaap:ScheduleOfDeferredTaxAssetsAndLiabilitiesTableTextBlock

[0001193125-15-356351:notes:65]
As of September 26, 2015 and
 September 27, 2014, the significant components of the
 Company’s deferred tax assets and liabilities were (in
 millions):

[0001193125-15-356351:notes:66]
|  |  | 2015 |  |  | 2014 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |
| Accrued liabilities and other reserves |  | $ | 4,205 |  |  | $ | 3,326 |  |
| Basis of capital assets and investments |  |  | 2,238 |  |  |  | 898 |  |
| Deferred revenue |  |  | 1,941 |  |  |  | 1,787 |  |
| Deferred cost sharing |  |  | 667 |  |  |  | 0 |  |
| Share-based compensation |  |  | 575 |  |  |  | 454 |  |
| Unrealized losses |  |  | 564 |  |  |  | 130 |  |
| Other |  |  | 721 |  |  |  | 227 |  |
| Total deferred tax assets, net of valuation allowance of $0 |  |  | 10,911 |  |  |  | 6,822 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |
| Unremitted earnings of foreign subsidiaries |  |  | 26,868 |  |  |  | 21,544 |  |
| Other |  |  | 303 |  |  |  | 398 |  |
| Total deferred tax liabilities |  |  | 27,171 |  |  |  | 21,942 |  |
| Net deferred tax liabilities |  | $ | (16,260 | ) |  | $ | (15,120 | ) |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001193125-15-356351:notes:67]
Note 2 – Financial Instruments

[0001193125-15-356351:notes:68]
Cash, Cash Equivalents and Marketable Securities

[0001193125-15-356351:notes:69]
The Company may sell certain of its marketable
 securities prior to their stated maturities for strategic reasons
 including, but not limited to, anticipation of credit deterioration
 and duration management. The maturities of the Company’s
 long-term marketable securities generally range from one to five
 years.

[0001193125-15-356351:notes:70]
As of September 26, 2015, the Company
 considers the declines in market value of its marketable securities
 investment portfolio to be temporary in nature and does not
 consider any of its investments other-than-temporarily impaired.
 The Company typically invests in highly-rated securities, and its
 investment policy generally limits the amount of credit exposure to
 any one issuer. The policy generally requires investments to be
 investment grade, with the primary objective of minimizing the
 potential risk of principal loss. Fair values were determined for
 each individual security in the investment portfolio. When
 evaluating an investment for other-than-temporary impairment the
 Company reviews factors such as the length of time and extent to
 which fair value has been below its cost basis, the financial
 condition of the issuer and any changes thereto, changes in market
 interest rates and the Company’s intent to sell, or whether
 it is more likely than not it will be required to sell the
 investment before recovery of the investment’s cost
 basis.

[0001193125-15-356351:notes:71]
Derivative Financial Instruments

[0001193125-15-356351:notes:72]
The Company may use derivatives to partially offset
 its business exposure to foreign currency and interest rate risk on
 expected future cash flows, on net investments in certain foreign
 subsidiaries and on certain existing assets and liabilities.
 However, the Company may choose not to hedge certain exposures for
 a variety of reasons including, but not limited to, accounting
 considerations and the prohibitive economic cost of hedging
 particular exposures. There can be no assurance the hedges will
 offset more than a portion of the financial impact resulting from
 movements in foreign currency exchange or interest rates.

[0001193125-15-356351:notes:73]
To help protect gross margins from fluctuations in
 foreign currency exchange rates, certain of the Company’s
 subsidiaries whose functional currency is the U.S. dollar may hedge
 a portion of forecasted foreign currency revenue, and subsidiaries
 whose functional currency is not the U.S. dollar and who sell in
 local currencies may hedge a portion of forecasted inventory
 purchases not denominated in the subsidiaries’ functional
 currencies. The Company may enter into forward contracts, option
 contracts or other instruments to manage this risk and may
 designate these instruments as cash flow hedges. The Company
 typically hedges portions of its forecasted foreign currency
 exposure associated with revenue and inventory purchases, typically
 for up to 12 months.

[0001193125-15-356351:notes:74]
To help protect the net investment in a foreign
 operation from adverse changes in foreign currency exchange rates,
 the Company may enter into foreign currency forward and option
 contracts to offset the changes in the carrying amounts of these
 investments due to fluctuations in foreign currency exchange rates.
 In addition, the Company may use non-derivative financial
 instruments, such as its foreign currency-denominated debt, as
 economic hedges of its net investments in certain foreign
 subsidiaries. In both of these cases, the Company designates these
 instruments as net investment hedges.

[0001193125-15-356351:notes:75]
The Company may also enter into non-designated
 foreign currency contracts to partially offset the foreign currency
 exchange gains and losses generated by the re-measurement of
 certain assets and liabilities denominated in non-functional
 currencies.

[0001193125-15-356351:notes:76]
The Company may enter into interest rate swaps,
 options, or other instruments to manage interest rate risk. These
 instruments may offset a portion of changes in income or expense,
 or changes in fair value of the Company’s term debt or
 investments. The Company designates these instruments as either
 cash flow or fair value hedges. The Company’s hedged interest
 rate transactions as of September 26, 2015 are expected to be
 recognized within 10 years.

[0001193125-15-356351:notes:77]
Cash Flow Hedges

[0001193125-15-356351:notes:78]
The effective portions of cash flow hedges are
 recorded in AOCI until the hedged item is recognized in earnings.
 Deferred gains and losses associated with cash flow hedges of
 foreign currency revenue are recognized as a component of net sales
 in the same period as the related revenue is recognized, and
 deferred gains and losses related to cash flow hedges of inventory
 purchases are recognized as a component of cost of sales in the
 same period as the related costs are recognized. Deferred gains and
 losses associated with cash flow hedges of interest income or
 expense are recognized in other income/(expense), net in the same
 period as the related income or expense is recognized. The
 ineffective portions and amounts excluded from the effectiveness
 testing of cash flow hedges are recognized in other
 income/(expense), net.

[0001193125-15-356351:notes:79]
Derivative instruments designated as cash flow
 hedges must be de-designated as hedges when it is probable the
 forecasted hedged transaction will not occur in the initially
 identified time period or within a subsequent two-month time
 period. Deferred gains and losses in AOCI associated with such
 derivative instruments are reclassified immediately into other
 income/(expense), net. Any subsequent changes in fair value of such
 derivative instruments are reflected in other income/(expense), net
 unless they are re-designated as hedges of other transactions.

[0001193125-15-356351:notes:80]
Net Investment Hedges

[0001193125-15-356351:notes:81]
The effective portions of net investment hedges are
 recorded in other comprehensive income (“OCI”) as a
 part of the cumulative translation adjustment. The ineffective
 portions and amounts excluded from the effectiveness testing of net
 investment hedges are recognized in other income/(expense),
 net.

[0001193125-15-356351:notes:82]
Fair Value Hedges

[0001193125-15-356351:notes:83]
Gains and losses related to changes in fair value
 hedges are recognized in earnings along with a corresponding loss
 or gain related to the change in value of the underlying hedged
 item.

[0001193125-15-356351:notes:84]
Non-Designated Derivatives

[0001193125-15-356351:notes:85]
Derivatives that are not designated as hedging
 instruments are adjusted to fair value through earnings in the
 financial statement line item to which the derivative relates.

[0001193125-15-356351:notes:86]
The Company records all derivatives in the
 Consolidated Balance Sheets at fair value. The Company’s
 accounting treatment for these derivative instruments is based on
 its hedge designation. The following tables show the
 Company’s derivative instruments at gross fair value as of
 September 26, 2015 and September 27, 2014 (in
 millions):

[0001193125-15-356351:notes:87]
The following table shows the pre-tax gains and
 losses of the Company’s derivative and non-derivative
 instruments designated as cash flow, net investment and fair value
 hedges on OCI and the Consolidated Statements of Operations for
 2015, 2014 and 2013 (in millions):

[0001193125-15-356351:notes:88]
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Gains/(Losses) recognized in OCI – effective portion: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 3,592 |  |  | $ | 1,750 |  |  | $ | 891 |  |
| Interest rate contracts |  |  | (111 | ) |  |  | (15 | ) |  |  | 12 |  |
| Total |  | $ | 3,481 |  |  | $ | 1,735 |  |  | $ | 903 |  |
| Net investment hedges: |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 167 |  |  | $ | 53 |  |  | $ | 143 |  |
| Foreign currency debt |  |  | (71 | ) |  |  | 0 |  |  |  | 0 |  |
| Total |  | $ | 96 |  |  | $ | 53 |  |  | $ | 143 |  |
| Gains/(Losses) reclassified from AOCI into net income – effective portion: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 4,092 |  |  | $ | (154 | ) |  | $ | 676 |  |
| Interest rate contracts |  |  | (17 | ) |  |  | (16 | ) |  |  | (6 | ) |
| Total |  | $ | 4,075 |  |  | $ | (170 | ) |  | $ | 670 |  |
| Gains/(Losses) on derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Fair value hedges: |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate contracts |  | $ | 337 |  |  | $ | 39 |  |  | $ | 0 |  |
| Gains/(Losses) related to hedged items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Fair value hedges: |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate contracts |  | $ | (337 | ) |  | $ | (39 | ) |  | $ | 0 |  |

[0001193125-15-356351:notes:89]
The following table shows the notional amounts of
 the Company’s outstanding derivative instruments and credit
 risk amounts associated with outstanding or unsettled derivative
 instruments as of September 26, 2015 and September 27,
 2014 (in millions):

[0001193125-15-356351:notes:90]
|  |  | 2015 |  |  | 2014 |  |
|  |  | Notional Amount |  |  | Credit Risk Amount |  |  | Notional Amount |  |  | Credit Risk Amount |  |
| Instruments designated as accounting hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 70,054 |  |  | $ | 1,385 |  |  | $ | 42,945 |  |  | $ | 1,333 |  |
| Interest rate contracts |  | $ | 18,750 |  |  | $ | 394 |  |  | $ | 12,000 |  |  | $ | 89 |  |
| Instruments not designated as accounting hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 49,190 |  |  | $ | 109 |  |  | $ | 38,510 |  |  | $ | 222 |  |

[0001193125-15-356351:notes:91]
The notional amounts for outstanding derivative
 instruments provide one measure of the transaction volume
 outstanding and do not represent the amount of the Company’s
 exposure to credit or market loss. The credit risk amounts
 represent the Company’s gross exposure to potential
 accounting loss on derivative instruments that are outstanding or
 unsettled if all counterparties failed to perform according to the
 terms of the contract, based on then-current currency or interest
 rates at each respective date. The Company’s exposure to
 credit loss and market risk will vary over time as currency and
 interest rates change. Although the table above reflects the
 notional and credit risk amounts of the Company’s derivative
 instruments, it does not reflect the gains or losses associated
 with the exposures and transactions that the instruments are
 intended to hedge. The amounts ultimately realized upon settlement
 of these financial instruments, together with the gains and losses
 on the underlying exposures, will depend on actual market
 conditions during the remaining life of the instruments.

[0001193125-15-356351:notes:92]
The Company generally enters into master netting
 arrangements, which are designed to reduce credit risk by
 permitting net settlement of transactions with the same
 counterparty. To further limit credit risk, the Company generally
 enters into collateral security arrangements that provide for
 collateral to be received or posted when the net fair value of
 certain financial instruments fluctuates from contractually
 established thresholds. The Company presents its derivative assets
 and derivative liabilities at their gross fair values in its
 Consolidated Balance Sheets. The net cash collateral received by
 the Company related to derivative instruments under its collateral
 security arrangements was $1.0 billion as of September 26,
 2015 and $2.1 billion as of September 27, 2014.

[0001193125-15-356351:notes:93]
Under master netting arrangements with the
 respective counterparties to the Company’s derivative
 contracts, the Company is allowed to net settle transactions
 with a single net amount payable by one party to the other. As of
 September 26, 2015 and September 27, 2014, the potential
 effects of these rights of set-off associated with the
 Company’s derivative contracts, including the effects of
 collateral, would be a reduction to both derivative assets and
 derivative liabilities of $2.2 billion and $1.6 billion,
 respectively, resulting in net derivative liabilities
 of $78 million and $549 million, respectively.

[0001193125-15-356351:notes:94]
Accounts Receivable

[0001193125-15-356351:notes:95]
Trade Receivables

[0001193125-15-356351:notes:96]
The Company has considerable trade receivables
 outstanding with its third-party cellular network carriers,
 wholesalers, retailers, value-added resellers, small and mid-sized
 businesses and education, enterprise and government customers. The
 Company generally does not require collateral from its customers;
 however, the Company will require collateral in certain instances
 to limit credit risk. In addition, when possible, the Company
 attempts to limit credit risk on trade receivables with credit
 insurance for certain customers or by requiring third-party
 financing, loans or leases to support credit exposure. These
 credit-financing arrangements are directly between the third-party
 financing company and the end customer. As such, the Company
 generally does not assume any recourse or credit risk sharing
 related to any of these arrangements.

[0001193125-15-356351:notes:97]
As of September 26, 2015, the Company had one
 customer that represented 10% or more of total trade receivables,
 which accounted for 12%. As of September 27, 2014, the Company
 had two customers that represented 10% or more of total trade
 receivables, one of which accounted for 16% and the other 13%. The
 Company’s cellular network carriers accounted for 71% and 72%
 of trade receivables as of September 26, 2015 and
 September 27, 2014, respectively.

[0001193125-15-356351:notes:98]
Vendor Non-Trade Receivables

[0001193125-15-356351:notes:99]
The Company has non-trade receivables from certain
 of its manufacturing vendors resulting from the sale of components
 to these vendors who manufacture sub-assemblies or assemble final
 products for the Company. The Company purchases these components
 directly from suppliers. Vendor non-trade receivables from three of
 the Company’s vendors accounted for 38%, 18% and 14% of total
 vendor non-trade receivables as of September 26, 2015 and
 three of the Company’s vendors accounted for 51%, 16% and 14%
 of total vendor non-trade receivables as of September 27,
 2014.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001193125-15-356351:notes:100]
Note 1 – Summary of Significant Accounting
 Policies

[0001193125-15-356351:notes:101]
Apple Inc. and its wholly-owned subsidiaries
 (collectively “Apple” or the “Company”)
 designs, manufactures and markets mobile communication and media
 devices, personal computers and portable digital music players, and
 sells a variety of related software, services, accessories,
 networking solutions and third-party digital content and
 applications. The Company sells its products worldwide through its
 retail stores, online stores and direct sales force, as well as
 through third-party cellular network carriers, wholesalers,
 retailers and value-added resellers. In addition, the Company sells
 a variety of third-party Apple-compatible products, including
 application software and various accessories through its online and
 retail stores. The Company sells to consumers, small and mid-sized
 businesses and education, enterprise and government customers.

[0001193125-15-356351:notes:102]
Revenue Recognition

[0001193125-15-356351:notes:103]
Net sales consist primarily of revenue from the
 sale of hardware, software, digital content and applications,
 accessories, and service and support contracts. The Company
 recognizes revenue when persuasive evidence of an arrangement
 exists, delivery has occurred, the sales price is fixed or
 determinable and collection is probable. Product is considered
 delivered to the customer once it has been shipped and title, risk
 of loss and rewards of ownership have been transferred. For most of
 the Company’s product sales, these criteria are met at the
 time the product is shipped. For online sales to individuals, for
 some sales to education customers in the U.S., and for certain
 other sales, the Company defers revenue until the customer receives
 the product because the Company retains a portion of the risk of
 loss on these sales during transit. For payment terms in excess of
 the Company’s standard payment terms, revenue is recognized
 as payments become due unless the Company has positive evidence
 that the sales price is fixed or determinable, such as a successful
 history of collection, without concession, on comparable
 arrangements. The Company recognizes revenue from the sale of
 hardware products, software bundled with hardware that is essential
 to the functionality of the hardware and third-party digital
 content sold on the iTunes Store in accordance with general revenue
 recognition accounting guidance. The Company recognizes revenue in
 accordance with industry specific software accounting guidance for
 the following types of sales transactions: (i) standalone
 sales of software products, (ii) sales of software upgrades
 and (iii) sales of software bundled with hardware not
 essential to the functionality of the hardware.

[0001193125-15-356351:notes:104]
For the sale of most third-party products, the
 Company recognizes revenue based on the gross amount billed to
 customers because the Company establishes its own pricing for such
 products, retains related inventory risk for physical products, is
 the primary obligor to the customer and assumes the credit risk for
 amounts billed to its customers. For third-party applications sold
 through the App Store and Mac App Store and certain digital content
 sold through the iTunes Store, the Company does not determine the
 selling price of the products and is not the primary obligor to the
 customer. Therefore, the Company accounts for such sales on a net
 basis by recognizing in net sales only the commission it retains
 from each sale. The portion of the gross amount billed to customers
 that is remitted by the Company to third-party app developers and
 certain digital content owners is not reflected in the
 Company’s Consolidated Statements of Operations.

[0001193125-15-356351:notes:105]
The Company records deferred revenue when it
 receives payments in advance of the delivery of products or the
 performance of services. This includes amounts that have been
 deferred for unspecified and specified software upgrade rights and
 non-software services that are attached to hardware and software
 products. The Company sells gift cards redeemable at its retail and
 online stores, and also sells gift cards redeemable on iTunes
 Store, App Store, Mac App Store and iBooks Store for the purchase
 of digital content and software. The Company records deferred
 revenue upon the sale of the card, which is relieved upon
 redemption of the card by the customer. Revenue from AppleCare
 service and support contracts is deferred and recognized over the
 service coverage periods. AppleCare service and support contracts
 typically include extended phone support, repair services,
 web-based support resources and diagnostic tools offered under the
 Company’s standard limited warranty.

[0001193125-15-356351:notes:106]
The Company records reductions to revenue for
 estimated commitments related to price protection and other
 customer incentive programs. For transactions involving price
 protection, the Company recognizes revenue net of the estimated
 amount to be refunded. For the Company’s other customer
 incentive programs, the estimated cost of these programs is
 recognized at the later of the date at which the Company has sold
 the product or the date at which the program is offered. The
 Company also records reductions to revenue for expected future
 product returns based on the Company’s historical experience.
 Revenue is recorded net of taxes collected from customers that are
 remitted to governmental authorities, with the collected taxes
 recorded as current liabilities until remitted to the relevant
 government authority.

[0001193125-15-356351:notes:107]
Revenue Recognition for Arrangements with Multiple
 Deliverables

[0001193125-15-356351:notes:108]
For multi-element arrangements that include
 hardware products containing software essential to the hardware
 product’s functionality, undelivered software elements that
 relate to the hardware product’s essential software, and
 undelivered non-software services, the Company allocates revenue to
 all deliverables based on their relative selling prices. In such
 circumstances, the Company uses a hierarchy to determine the
 selling price to be used for allocating revenue to deliverables:
 (i) vendor-specific objective evidence of fair value
 (“VSOE”), (ii) third-party evidence of selling
 price (“TPE”) and (iii) best estimate of selling
 price (“ESP”). VSOE generally exists only when the
 Company sells the deliverable separately and is the price actually
 charged by the Company for that deliverable. ESPs reflect the
 Company’s best estimates of what the selling prices of
 elements would be if they were sold regularly on a stand-alone
 basis. For multi-element arrangements accounted for in accordance
 with industry specific software accounting guidance, the Company
 allocates revenue to all deliverables based on the VSOE of each
 element, and if VSOE does not exist revenue is recognized when
 elements lacking VSOE are delivered.

[0001193125-15-356351:notes:109]
For sales of qualifying versions of iPhone, iPad
 and iPod touch (“iOS devices”), Mac, Apple Watch and
 Apple TV, the Company has indicated it may from time to time
 provide future unspecified software upgrades to the device’s
 essential software and/or non-software services free of charge. The
 Company has identified up to three deliverables regularly included
 in arrangements involving the sale of these devices. The first
 deliverable, which represents the substantial portion of the
 allocated sales price, is the hardware and software essential to
 the functionality of the hardware device delivered at the time of
 sale. The second deliverable is the embedded right included with
 qualifying devices to receive on a when-and-if-available basis,
 future unspecified software upgrades relating to the
 product’s essential software. The third deliverable is the
 non-software services to be provided to qualifying devices. The
 Company allocates revenue between these deliverables using the
 relative selling price method. Because the Company has neither VSOE
 nor TPE for these deliverables, the allocation of revenue is based
 on the Company’s ESPs. Revenue allocated to the delivered
 hardware and the related essential software is recognized at the
 time of sale provided the other conditions for revenue recognition
 have been met. Revenue allocated to the embedded unspecified
 software upgrade rights and the non-software services is deferred
 and recognized on a straight-line basis over the estimated period
 the software upgrades and non-software services are expected to be
 provided. Cost of sales related to delivered hardware and related
 essential software, including estimated warranty costs, are
 recognized at the time of sale. Costs incurred to provide
 non-software services are recognized as cost of sales as incurred,
 and engineering and sales and marketing costs are recognized as
 operating expenses as incurred.

[0001193125-15-356351:notes:110]
The Company’s process for determining its ESP
 for deliverables without VSOE or TPE considers multiple factors
 that may vary depending upon the unique facts and circumstances
 related to each deliverable including, where applicable, prices
 charged by the Company and market trends in the pricing for similar
 offerings, product specific business objectives, length of time a
 particular version of a device has been available, estimated cost
 to provide the non-software services and the relative ESP of the
 upgrade rights and non-software services as compared to the total
 selling price of the product.

[0001193125-15-356351:notes:111]
Beginning in September 2015, the Company reduced
 the combined ESPs for iOS devices and Mac between $5 and $10 to
 reflect the increase in competitive offers for similar products at
 little to no cost for users, which reduces the amount the Company
 could reasonably charge for these deliverables on a standalone
 basis.

[0001193125-15-356351:notes:112]
Shipping Costs

[0001193125-15-356351:notes:113]
Amounts billed to customers related to shipping and
 handling are classified as revenue, and the Company’s
 shipping and handling costs are classified as cost of sales.

[0001193125-15-356351:notes:114]
Warranty Costs

[0001193125-15-356351:notes:115]
The Company generally provides for the estimated
 cost of hardware and software warranties at the time the related
 revenue is recognized. The Company assesses the adequacy of its
 accrued warranty liabilities and adjusts the amounts as necessary
 based on actual experience and changes in future estimates.

[0001193125-15-356351:notes:116]
Advertising Costs

[0001193125-15-356351:notes:117]
Advertising costs are expensed as incurred and
 included in selling, general and administrative expenses.
 Advertising expense was $1.8 billion, $1.2 billion and $1.1 billion
 for 2015, 2014 and 2013, respectively.

[0001193125-15-356351:notes:118]
Share-based Compensation

[0001193125-15-356351:notes:119]
The Company recognizes expense related to
 share-based payment transactions in which it receives employee
 services in exchange for (a) equity instruments of the Company
 or (b) liabilities that are based on the fair value of the
 Company’s equity instruments or that may be settled by the
 issuance of such equity instruments. Share-based compensation cost
 for restricted stock and restricted stock units
 (“RSUs”) is measured based on the closing fair market
 value of the Company’s common stock on the date of grant. The
 Company recognizes share-based compensation cost over the
 award’s requisite service period on a straight-line basis for
 time-based RSUs and on a graded basis for RSUs that are contingent
 on the achievement of performance conditions. The Company
 recognizes a benefit from share-based compensation in the
 Consolidated Statements of Shareholders’ Equity if an excess
 tax benefit is realized. In addition, the Company recognizes the
 indirect effects of share-based compensation on R&D tax
 credits, foreign tax credits and domestic manufacturing deductions
 in the Consolidated Statements of Operations. Further information
 regarding share-based compensation can be found in Note 9,
 “Benefit Plans.”

[0001193125-15-356351:notes:120]
Income Taxes

[0001193125-15-356351:notes:121]
The provision for income taxes is computed using
 the asset and liability method, under which deferred tax assets and
 liabilities are recognized for the expected future tax consequences
 of temporary differences between the financial reporting and tax
 bases of assets and liabilities and for operating losses and tax
 credit carryforwards. Deferred tax assets and liabilities are
 measured using the currently enacted tax rates that apply to
 taxable income in effect for the years in which those tax assets
 and liabilities are expected to be realized or settled. The Company
 records a valuation allowance to reduce deferred tax assets to the
 amount that is believed more likely than not to be realized.

[0001193125-15-356351:notes:122]
The Company recognizes the tax benefit from an
 uncertain tax position only if it is more likely than not the tax
 position will be sustained on examination by the taxing
 authorities, based on the technical merits of the position. The tax
 benefits recognized in the financial statements from such positions
 are then measured based on the largest benefit that has a greater
 than 50% likelihood of being realized upon settlement. See Note 5,
 “Income Taxes” for additional information.

[0001193125-15-356351:notes:123]
Financial Instruments

[0001193125-15-356351:notes:124]
Cash Equivalents and Marketable Securities

[0001193125-15-356351:notes:125]
All highly liquid investments with maturities of
 three months or less at the date of purchase are classified as cash
 equivalents. The Company’s marketable debt and equity
 securities have been classified and accounted for as available-for-sale. Management
 determines the appropriate classification of its investments at the
 time of purchase and reevaluates the classifications at each
 balance sheet date. The Company classifies its marketable debt
 securities as either short-term or long-term based on each
 instrument’s underlying contractual maturity date. Marketable
 debt securities with maturities of 12 months or less are classified
 as short-term and marketable debt securities with maturities
 greater than 12 months are classified as long-term. Marketable
 equity securities, including mutual funds, are classified as either
 short-term or long-term based on the nature of each security and
 its availability for use in current operations. The Company’s
 marketable debt and equity securities are carried at fair value,
 with unrealized gains and losses, net of taxes, reported as a
 component of accumulated other comprehensive income
 (“AOCI”) in shareholders’ equity, with the
 exception of unrealized losses believed to be other-than-temporary
 which are reported in earnings in the current period. The cost of
 securities sold is based upon the specific identification
 method.

[0001193125-15-356351:notes:126]
The Company accounts for its derivative instruments
 as either assets or liabilities and carries them at fair value.

[0001193125-15-356351:notes:127]
For derivative instruments that hedge the exposure
 to variability in expected future cash flows that are designated as
 cash flow hedges, the effective portion of the gain or loss on the
 derivative instrument is reported as a component of AOCI in
 shareholders’ equity and reclassified into earnings in the
 same period or periods during which the hedged transaction affects
 earnings. The ineffective portion of the gain or loss on the
 derivative instrument, if any, is recognized in earnings in the
 current period. To receive hedge accounting treatment, cash flow
 hedges must be highly effective in offsetting changes to expected
 future cash flows on hedged transactions. For options designated as
 cash flow hedges, changes in the time value are excluded from the
 assessment of hedge effectiveness and are recognized in
 earnings.

[0001193125-15-356351:notes:128]
For derivative instruments that hedge the exposure
 to changes in the fair value of an asset or a liability and that
 are designated as fair value hedges, both the net gain or loss on
 the derivative instrument as well as the offsetting gain or loss on
 the hedged item are recognized in earnings in the current
 period.

[0001193125-15-356351:notes:129]
For derivative instruments and foreign currency
 debt that hedge the exposure to changes in foreign currency
 exchange rates used for translation of the net investment in a
 foreign operation and that are designated as a net investment
 hedge, the net gain or loss on the effective portion of the
 derivative instrument is reported in the same manner as a foreign
 currency translation adjustment. For forward exchange contracts
 designated as net investment hedges, the Company excludes changes
 in fair value relating to changes in the forward carry component
 from its definition of effectiveness. Accordingly, any gains or
 losses related to this forward carry component are recognized in
 earnings in the current period.

[0001193125-15-356351:notes:130]
Derivatives that do not qualify as hedges are
 adjusted to fair value through earnings in the current period.

[0001193125-15-356351:notes:131]
Allowance for Doubtful Accounts

[0001193125-15-356351:notes:132]
The Company records its allowance for doubtful
 accounts based upon its assessment of various factors, including
 historical experience, age of the accounts receivable balances,
 credit quality of the Company’s customers, current economic
 conditions and other factors that may affect the customers’
 ability to pay.

[0001193125-15-356351:notes:133]
Inventories

[0001193125-15-356351:notes:134]
Inventories are stated at the lower of cost,
 computed using the first-in, first-out method and net realizable
 value. Any adjustments to reduce the cost of inventories to their
 net realizable value are recognized in earnings in the current
 period. As of September 26, 2015 and September 27, 2014,
 the Company’s inventories consist primarily of finished
 goods.

[0001193125-15-356351:notes:135]
Property, Plant and Equipment

[0001193125-15-356351:notes:136]
Property, plant and equipment are stated at cost.
 Depreciation is computed by use of the straight-line method over the
 estimated useful lives of the assets, which for buildings is the
 lesser of 30 years or the remaining life of the underlying
 building; between one to five years for machinery and equipment,
 including product tooling and manufacturing process equipment; and
 the shorter of lease terms or ten years for leasehold improvements.
 The Company capitalizes eligible costs to acquire or develop
 internal-use software that are incurred subsequent to the
 preliminary project stage. Capitalized costs related to
 internal-use software are amortized using the straight-line method
 over the estimated useful lives of the assets, which range from
 three to five years. Depreciation and amortization expense on
 property and equipment was $9.2 billion, $6.9 billion and $5.8
 billion during 2015, 2014 and 2013, respectively.

[0001193125-15-356351:notes:137]
Long-Lived Assets Including Goodwill and Other Acquired
 Intangible Assets

[0001193125-15-356351:notes:138]
The Company reviews property, plant and equipment,
 inventory component prepayments and certain identifiable
 intangibles, excluding goodwill, for impairment. Long-lived assets
 are reviewed for impairment whenever events or changes in
 circumstances indicate the carrying amount of an asset may not be
 recoverable. Recoverability of these assets is measured by
 comparison of their carrying amounts to future undiscounted cash
 flows the assets are expected to generate. If property, plant and
 equipment, inventory component prepayments and certain identifiable
 intangibles are considered to be impaired, the impairment to be
 recognized equals the amount by which the carrying value of the
 assets exceeds its fair value.

[0001193125-15-356351:notes:139]
The Company does not amortize goodwill and
 intangible assets with indefinite useful lives, rather such assets
 are required to be tested for impairment at least annually or
 sooner whenever events or changes in circumstances indicate that
 the assets may be impaired. The Company performs its goodwill and
 intangible asset impairment tests in the fourth quarter of each
 year. The Company did not recognize any impairment charges related
 to goodwill or indefinite lived intangible assets during 2015, 2014
 and 2013. The Company established reporting units based on its
 current reporting structure. For purposes of testing goodwill for
 impairment, goodwill has been allocated to these reporting units to
 the extent it relates to each reporting unit. In 2015 and 2014, the
 Company’s goodwill was primarily allocated to the Americas
 and Europe reporting units.

[0001193125-15-356351:notes:140]
The Company amortizes its intangible assets with
 definite useful lives over their estimated useful lives and reviews
 these assets for impairment. The Company typically amortizes its
 acquired intangible assets with definite useful lives over periods
 from three to seven years.

[0001193125-15-356351:notes:141]
Fair Value Measurements

[0001193125-15-356351:notes:142]
The Company applies fair value accounting for all
 financial assets and liabilities and non-financial assets and
 liabilities that are recognized or disclosed at fair value in the
 financial statements on a recurring basis. The Company defines fair
 value as the price that would be received from selling an asset or
 paid to transfer a liability in an orderly transaction between
 market participants at the measurement date. When determining the
 fair value measurements for assets and liabilities, which are
 required to be recorded at fair value, the Company considers the
 principal or most advantageous market in which the Company would
 transact and the market-based risk measurements or assumptions that
 market participants would use in pricing the asset or liability,
 such as risks inherent in valuation techniques, transfer
 restrictions and credit risk. Fair value is estimated by applying
 the following hierarchy, which prioritizes the inputs used to
 measure fair value into three levels and bases the categorization
 within the hierarchy upon the lowest level of input that is
 available and significant to the fair value measurement:

[0001193125-15-356351:notes:143]
Level 1 – Quoted prices in active markets for
 identical assets or liabilities.

[0001193125-15-356351:notes:144]
Level 2 – Observable inputs other than
 quoted prices in active markets for identical assets and
 liabilities, quoted prices for identical or similar assets or
 liabilities in inactive markets, or other inputs that are
 observable or can be corroborated by observable market data for
 substantially the full term of the assets or liabilities.

[0001193125-15-356351:notes:145]
Level 3 – Inputs that are generally
 unobservable and typically reflect management’s estimate of
 assumptions that market participants would use in pricing the asset
 or liability.

[0001193125-15-356351:notes:146]
The Company’s valuation techniques used to
 measure the fair value of money market funds and certain marketable
 equity securities were derived from quoted prices in active markets
 for identical assets or liabilities. The valuation techniques used
 to measure the fair value of the Company’s debt instruments
 and all other financial instruments, all of which have
 counterparties with high credit ratings, were valued based on
 quoted market prices or model driven valuations using significant
 inputs derived from or corroborated by observable market data.

[0001193125-15-356351:notes:147]
In accordance with the fair value accounting
 requirements, companies may choose to measure eligible financial
 instruments and certain other items at fair value. The Company has
 not elected the fair value option for any eligible financial
 instruments.

[0001193125-15-356351:notes:148]
Foreign Currency Translation and Remeasurement

[0001193125-15-356351:notes:149]
The Company translates the assets and liabilities
 of its non-U.S. dollar functional currency subsidiaries into U.S.
 dollars using exchange rates in effect at the end of each period.
 Revenue and expenses for these subsidiaries are translated using
 rates that approximate those in effect during the period. Gains and
 losses from these translations are recognized in foreign currency
 translation included in AOCI in shareholders’ equity. The
 Company’s subsidiaries that use the U.S. dollar as their
 functional currency remeasure monetary assets and liabilities at
 exchange rates in effect at the end of each period, and
 inventories, property and nonmonetary assets and liabilities at
 historical rates.


## us-gaap:OtherNoncurrentLiabilitiesTableTextBlock

[0001193125-15-356351:notes:150]
Other Non-Current Liabilities

[0001193125-15-356351:notes:151]
|  |  | 2015 |  |  | 2014 |  |
| Deferred tax liabilities |  | $ | 24,062 |  |  | $ | 20,259 |  |
| Other non-current liabilities |  |  | 9,365 |  |  |  | 4,567 |  |
| Total other non-current liabilities |  | $ | 33,427 |  |  | $ | 24,826 |  |


## us-gaap:ScheduleOfComponentsOfIncomeTaxExpenseBenefitTableTextBlock

[0001193125-15-356351:notes:152]
The provision for income taxes for 2015, 2014 and
 2013, consisted of the following (in millions):

[0001193125-15-356351:notes:153]
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Federal: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  | $ | 11,730 |  |  | $ | 8,624 |  |  | $ | 9,334 |  |
| Deferred |  |  | 3,408 |  |  |  | 3,183 |  |  |  | 1,878 |  |
|  |  |  | 15,138 |  |  |  | 11,807 |  |  |  | 11,212 |  |
| State: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  |  | 1,265 |  |  |  | 855 |  |  |  | 1,084 |  |
| Deferred |  |  | (220 | ) |  |  | (178 | ) |  |  | (311 | ) |
|  |  |  | 1,045 |  |  |  | 677 |  |  |  | 773 |  |
| Foreign: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  |  | 4,744 |  |  |  | 2,147 |  |  |  | 1,559 |  |
| Deferred |  |  | (1,806 | ) |  |  | (658 | ) |  |  | (426 | ) |
|  |  |  | 2,938 |  |  |  | 1,489 |  |  |  | 1,133 |  |
| Provision for income taxes |  | $ | 19,121 |  |  | $ | 13,973 |  |  | $ | 13,118 |  |


## us-gaap:ScheduleOfQuarterlyFinancialInformationTableTextBlock

[0001193125-15-356351:notes:154]
The following tables show a summary of the
 Company’s quarterly financial information for each of the
 four quarters of 2015 and 2014 (in millions, except per share
 amounts):

[0001193125-15-356351:notes:155]
|  |  | Fourth Quarter |  |  | Third Quarter |  |  | Second Quarter |  |  | First Quarter |  |
| 2015: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 51,501 |  |  | $ | 49,605 |  |  | $ | 58,010 |  |  | $ | 74,599 |  |
| Gross margin |  | $ | 20,548 |  |  | $ | 19,681 |  |  | $ | 23,656 |  |  | $ | 29,741 |  |
| Net income |  | $ | 11,124 |  |  | $ | 10,677 |  |  | $ | 13,569 |  |  | $ | 18,024 |  |
| Earnings per share (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.97 |  |  | $ | 1.86 |  |  | $ | 2.34 |  |  | $ | 3.08 |  |
| Diluted |  | $ | 1.96 |  |  | $ | 1.85 |  |  | $ | 2.33 |  |  | $ | 3.06 |  |

[0001193125-15-356351:notes:156]
|  |  | Fourth Quarter |  |  | Third Quarter |  |  | Second Quarter |  |  | First Quarter |  |
| 2014: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 42,123 |  |  | $ | 37,432 |  |  | $ | 45,646 |  |  | $ | 57,594 |  |
| Gross margin |  | $ | 16,009 |  |  | $ | 14,735 |  |  | $ | 17,947 |  |  | $ | 21,846 |  |
| Net income |  | $ | 8,467 |  |  | $ | 7,748 |  |  | $ | 10,223 |  |  | $ | 13,072 |  |
| Earnings per share (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.43 |  |  | $ | 1.29 |  |  | $ | 1.67 |  |  | $ | 2.08 |  |
| Diluted |  | $ | 1.42 |  |  | $ | 1.28 |  |  | $ | 1.66 |  |  | $ | 2.07 |  |

[0001193125-15-356351:notes:157]
|  | (1) | Basic and diluted earnings per share are computed independently for each of the quarters presented. Therefore, the sum of quarterly basic and diluted per share information may not equal annual basic and diluted earnings per share. |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001193125-15-356351:notes:158]
Property, Plant and Equipment, Net

[0001193125-15-356351:notes:159]
|  |  | 2015 |  |  | 2014 |  |
| Land and buildings |  | $ | 6,956 |  |  | $ | 4,863 |  |
| Machinery, equipment and internal-use software |  |  | 37,038 |  |  |  | 29,639 |  |
| Leasehold improvements |  |  | 5,263 |  |  |  | 4,513 |  |
| Gross property, plant and equipment |  |  | 49,257 |  |  |  | 39,015 |  |
| Accumulated depreciation and amortization |  |  | (26,786 | ) |  |  | (18,391 | ) |
| Total property, plant and equipment, net |  | $ | 22,471 |  |  | $ | 20,624 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-15-356351:notes:160]
Note 8 – Comprehensive Income

[0001193125-15-356351:notes:161]
Comprehensive income consists of two components,
 net income and OCI. OCI refers to revenue, expenses, and gains and
 losses that under GAAP are recorded as an element of
 shareholders’ equity but are excluded from net income. The
 Company’s OCI consists of foreign currency translation
 adjustments from those subsidiaries not using the U.S. dollar as
 their functional currency, net deferred gains and losses on certain
 derivative instruments accounted for as cash flow hedges and
 unrealized gains and losses on marketable securities classified as
 available-for-sale.

[0001193125-15-356351:notes:162]
The following table shows the pre-tax amounts
 reclassified from AOCI into the Consolidated Statements of
 Operations, and the associated financial statement line item, for
 2015 and 2014 (in millions):

[0001193125-15-356351:notes:163]
| Comprehensive Income Components |  | Financial Statement Line Item |  | 2015 |  |  | 2014 |  |
| Unrealized (gains)/losses on derivative instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Revenue |  | $ | (2,432 | ) |  | $ | 449 |  |
|  |  | Cost of sales |  |  | (2,168 | ) |  |  | (295 | ) |
|  |  | Other income/(expense), net |  |  | 456 |  |  |  | 15 |  |
| Interest rate contracts |  | Other income/(expense), net |  |  | 17 |  |  |  | 16 |  |
|  |  |  |  |  | (4,127 | ) |  |  | 185 |  |
| Unrealized (gains)/losses on marketable securities |  | Other income/(expense), net |  |  | 91 |  |  |  | (205 | ) |
| Total amounts reclassified from AOCI |  |  |  | $ | (4,036 | ) |  | $ | (20 | ) |

[0001193125-15-356351:notes:164]
The following table shows the changes in AOCI by
 component for 2015 (in millions):

[0001193125-15-356351:notes:165]
|  |  | Cumulative Foreign Currency Translation |  |  | Unrealized Gains/Losses on Derivative Instruments |  |  | Unrealized Gains/Losses on Marketable Securities |  |  | Total |  |
| Balance at September 28, 2013 |  | $ | (105 | ) |  | $ | (175 | ) |  | $ | (191 | ) |  | $ | (471 | ) |
| Other comprehensive income/(loss) before reclassifications |  |  | (187 | ) |  |  | 1,687 |  |  |  | 438 |  |  |  | 1,938 |  |
| Amounts reclassified from AOCI |  |  | 0 |  |  |  | 185 |  |  |  | (205 | ) |  |  | (20 | ) |
| Tax effect |  |  | 50 |  |  |  | (333 | ) |  |  | (82 | ) |  |  | (365 | ) |
| Other comprehensive income/(loss) |  |  | (137 | ) |  |  | 1,539 |  |  |  | 151 |  |  |  | 1,553 |  |
| Balance at September 27, 2014 |  |  | (242 | ) |  |  | 1,364 |  |  |  | (40 | ) |  |  | 1,082 |  |
| Other comprehensive income/(loss) before reclassifications |  |  | (612 | ) |  |  | 3,346 |  |  |  | (747 | ) |  |  | 1,987 |  |
| Amounts reclassified from AOCI |  |  | 0 |  |  |  | (4,127 | ) |  |  | 91 |  |  |  | (4,036 | ) |
| Tax effect |  |  | 201 |  |  |  | 189 |  |  |  | 232 |  |  |  | 622 |  |
| Other comprehensive income/(loss) |  |  | (411 | ) |  |  | (592 | ) |  |  | (424 | ) |  |  | (1,427 | ) |
| Balance at September 26, 2015 |  | $ | (653 | ) |  | $ | 772 |  |  | $ | (464 | ) |  | $ | (345 | ) |


## us-gaap:SummaryOfPositionsForWhichSignificantChangeInUnrecognizedTaxBenefitsIsReasonablyPossibleTextBlock

[0001193125-15-356351:notes:166]
The aggregate changes in the balance of gross
 unrecognized tax benefits, which excludes interest and penalties,
 for 2015, 2014 and 2013, is as follows (in millions):

[0001193125-15-356351:notes:167]
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Beginning Balance |  | $ | 4,033 |  |  | $ | 2,714 |  |  | $ | 2,062 |  |
| Increases related to tax positions taken during a prior year |  |  | 2,056 |  |  |  | 1,295 |  |  |  | 745 |  |
| Decreases related to tax positions taken during a prior year |  |  | (345 | ) |  |  | (280 | ) |  |  | (118 | ) |
| Increases related to tax positions taken during the current year |  |  | 1,278 |  |  |  | 882 |  |  |  | 626 |  |
| Decreases related to settlements with taxing authorities |  |  | (109 | ) |  |  | (574 | ) |  |  | (592 | ) |
| Decreases related to expiration of statute of limitations |  |  | (13 | ) |  |  | (4 | ) |  |  | (9 | ) |
| Ending Balance |  | $ | 6,900 |  |  | $ | 4,033 |  |  | $ | 2,714 |  |


## us-gaap:ScheduleOfIndefiniteLivedIntangibleAssetsTableTextBlock

[0001193125-15-356351:notes:168]
The following table summarizes the components of
 gross and net intangible asset balances as of September 26,
 2015 and September 27, 2014 (in millions):

[0001193125-15-356351:notes:169]
|  |  | 2015 |  |  | 2014 |  |
|  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Carrying Amount |  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Carrying Amount |  |
| Definite-lived and amortizable acquired intangible assets |  | $ | 8,125 |  |  | $ | (4,332 | ) |  | $ | 3,793 |  |  | $ | 7,127 |  |  | $ | (3,085 | ) |  | $ | 4,042 |  |
| Indefinite-lived and non-amortizable acquired intangible assets |  |  | 100 |  |  |  | 0 |  |  |  | 100 |  |  |  | 100 |  |  |  | 0 |  |  |  | 100 |  |
| Total acquired intangible assets |  | $ | 8,225 |  |  | $ | (4,332 | ) |  | $ | 3,893 |  |  | $ | 7,227 |  |  | $ | (3,085 | ) |  | $ | 4,142 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-15-356351:notes:170]
Note 4 – Goodwill and Other Intangible Assets

[0001193125-15-356351:notes:171]
On July 31, 2014, the Company completed the
 acquisitions of Beats Music, LLC, which offers a subscription
 streaming music service, and Beats Electronics, LLC, which makes
 Beats®
 headphones, speakers and audio software (collectively,
 “Beats”). The total purchase price consideration for
 these acquisitions was $2.6 billion, which consisted primarily of
 cash, of which $2.2 billion was allocated to goodwill, $636 million
 to acquired intangible assets and $258 million to net liabilities
 assumed. Concurrent with the close of the acquisitions, the Company
 repaid $295 million of existing Beats outstanding debt to
 third-party creditors. In conjunction with the Beats acquisitions,
 the Company issued approximately 5.1 million shares of its
 common stock to certain former equity holders of Beats. The
 restricted stock was valued at approximately $485 million based on
 the Company’s common stock on the acquisition date. The
 majority of these shares, valued at approximately $417 million,
 will vest over time based on continued employment with Apple.

[0001193125-15-356351:notes:172]
The Company also completed various other business
 acquisitions during 2014 for an aggregate cash consideration, net
 of cash acquired, of $957 million, of which $828 million was
 allocated to goodwill, $257 million to acquired intangible assets
 and $128 million to net liabilities assumed.

[0001193125-15-356351:notes:173]
The Company’s acquired intangible assets
 with definite useful lives primarily consist of patents and
 licenses and are amortized over periods typically from three to
 seven years. The following table summarizes the components of gross
 and net intangible asset balances as of September 26, 2015 and
 September 27, 2014 (in millions):

[0001193125-15-356351:notes:174]
Amortization expense related to acquired intangible
 assets was $1.3 billion, $1.1 billion and $960 million in 2015,
 2014 and 2013, respectively. As of September 26, 2015, the
 remaining weighted-average amortization period for acquired
 intangible assets is 3.6 years. The expected annual amortization
 expense related to acquired intangible assets as of
 September 26, 2015, is as follows (in millions):


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001193125-15-356351:notes:175]
Note 9 – Benefit Plans

[0001193125-15-356351:notes:176]
2014 Employee Stock Plan

[0001193125-15-356351:notes:177]
In the second quarter of 2014, shareholders
 approved the 2014 Employee Stock Plan (the “2014 Plan”)
 and terminated the Company’s authority to grant new awards
 under the 2003 Employee Stock Plan (the “2003 Plan”).
 The 2014 Plan provides for broad-based equity grants to employees,
 including executive officers, and permits the granting of RSUs,
 stock grants, performance-based awards, stock options and stock
 appreciation rights, as well as cash bonus awards. RSUs granted
 under the 2014 Plan generally vest over four years, based on
 continued employment, and are settled upon vesting in shares of the
 Company’s common stock on a one-for-one basis. Each share
 issued with respect to RSUs granted under the 2014 Plan reduces the
 number of shares available for grant under the plan by two shares.
 RSUs cancelled and shares withheld to satisfy tax withholding
 obligations increase the number of shares available for grant under
 the 2014 Plan utilizing a factor of two times the number of RSUs
 cancelled or shares withheld. Currently, all RSUs granted under the
 2014 Plan have dividend equivalent rights (“DERs”),
 which entitle holders of RSUs to the same dividend value per share
 as holders of common stock. DERs are subject to the same vesting
 and other terms and conditions as the corresponding unvested RSUs.
 DERs are accumulated and paid when the underlying shares vest. Upon
 approval of the 2014 Plan, the Company reserved 385 million
 shares plus the number of shares remaining that were reserved but
 not issued under the 2003 Plan. Shares subject to outstanding
 awards under the 2003 Plan that expire, are cancelled or otherwise
 terminate, or are withheld to satisfy tax withholding obligations
 with respect to RSUs, will also be available for awards under the
 2014 Plan. As of September 26, 2015, approximately
 442.9 million shares were reserved for future issuance under
 the 2014 Plan.

[0001193125-15-356351:notes:178]
2003 Employee Stock Plan

[0001193125-15-356351:notes:179]
The 2003 Plan is a shareholder approved plan that
 provided for broad-based equity grants to employees, including
 executive officers. The 2003 Plan permitted the granting of
 incentive stock options, nonstatutory stock options, RSUs, stock
 appreciation rights, stock purchase rights and performance-based
 awards. Options granted under the 2003 Plan generally expire seven
 to ten years after the grant date and generally become exercisable
 over a period of four years, based on continued employment, with
 either annual, semi-annual or quarterly vesting. RSUs granted under
 the 2003 Plan generally vest over two to four years, based on
 continued employment and are settled upon vesting in shares of the
 Company’s common stock on a one-for-one basis. All RSUs,
 other than RSUs held by the Chief Executive Officer, granted under
 the 2003 Plan have DERs. DERs are subject to the same vesting and
 other terms and conditions as the corresponding unvested RSUs. DERs
 are accumulated and paid when the underlying shares vest. In the
 second quarter of 2014, the Company terminated the authority to
 grant new awards under the 2003 Plan.

[0001193125-15-356351:notes:180]
1997 Director Stock Plan

[0001193125-15-356351:notes:181]
The 1997 Director Stock Plan (the “Director
 Plan”) is a shareholder approved plan that (i) permits
 the Company to grant awards of RSUs or stock options to the
 Company’s non-employee directors, (ii) provides for
 automatic initial grants of RSUs upon a non-employee director
 joining the Board of Directors and automatic annual grants of RSUs
 at each annual meeting of shareholders, and (iii) permits the
 Board of Directors to prospectively change the relative mixture of
 stock options and RSUs for the initial and annual award grants and
 the methodology for determining the number of shares of the
 Company’s common stock subject to these grants without
 shareholder approval. Each share issued with respect to RSUs
 granted under the Director Plan reduces the number of shares
 available for grant under the plan by two shares. The Director Plan
 expires November 9, 2019. All RSUs granted under the Director
 Plan are entitled to DERs. DERs are subject to the same vesting and
 other terms and conditions as the corresponding unvested RSUs. DERs
 are accumulated and paid when the underlying shares vest. As of
 September 26, 2015, approximately 1.2 million shares were
 reserved for future issuance under the Director Plan.

[0001193125-15-356351:notes:182]
Rule 10b5-1 Trading Plans

[0001193125-15-356351:notes:183]
During the fourth quarter of 2015, Section 16
 officers Timothy D. Cook, Angela Ahrendts, Luca Maestri, Daniel
 Riccio, Philip Schiller and Jeffrey Williams had equity trading
 plans in place in accordance with Rule 10b5-1(c)(1) under the
 Exchange Act. An equity trading plan is a written document that
 pre-establishes the amounts, prices and dates (or formula for
 determining the amounts, prices and dates) of future purchases or
 sales of the Company’s stock, including shares acquired
 pursuant to the Company’s employee and director equity
 plans.

[0001193125-15-356351:notes:184]
Employee Stock Purchase Plan

[0001193125-15-356351:notes:185]
The Employee Stock Purchase Plan (the
 “Purchase Plan”) is a shareholder approved plan under
 which substantially all employees may purchase the Company’s
 common stock through payroll deductions at a price equal to 85% of
 the lower of the fair market values of the stock as of the
 beginning or the end of six-month offering periods. An
 employee’s payroll deductions under the Purchase Plan are
 limited to 10% of the employee’s compensation and employees
 may not purchase more than $25,000 of stock during any calendar
 year. As of September 26, 2015, approximately
 53.0 million shares were reserved for future issuance under
 the Purchase Plan.

[0001193125-15-356351:notes:186]
401(k) Plan

[0001193125-15-356351:notes:187]
The Company’s 401(k) Plan is a deferred
 salary arrangement under Section 401(k) of the Internal
 Revenue Code. Under the 401(k) Plan, participating U.S. employees
 may defer a portion of their pre-tax earnings, up to the IRS annual
 contribution limit ($18,000 for calendar year 2015). The Company
 matches 50% to 100% of each employee’s contributions,
 depending on length of service, up to a maximum 6% of the
 employee’s eligible earnings. The Company’s matching
 contributions to the 401(k) Plan were $200 million, $163 million
 and $135 million in 2015, 2014 and 2013, respectively.

[0001193125-15-356351:notes:188]
Restricted Stock Units

[0001193125-15-356351:notes:189]
A summary of the Company’s RSU activity and
 related information for 2015, 2014 and 2013, is as follows:

[0001193125-15-356351:notes:190]
|  |  | Number of RSUs (in thousands) |  |  | Weighted-Average Grant Date Fair Value Per Share |  |  | Aggregate Intrinsic Value (in millions) |  |
| Balance at September 29, 2012 |  |  | 105,037 |  |  | $ | 49.27 |  |  |  |  |  |
| RSUs granted |  |  | 39,415 |  |  | $ | 78.23 |  |  |  |  |  |
| RSUs vested |  |  | (42,291 | ) |  | $ | 45.96 |  |  |  |  |  |
| RSUs cancelled |  |  | (8,877 | ) |  | $ | 57.31 |  |  |  |  |  |
| Balance at September 28, 2013 |  |  | 93,284 |  |  | $ | 62.24 |  |  |  |  |  |
| RSUs granted |  |  | 59,269 |  |  | $ | 74.54 |  |  |  |  |  |
| RSUs vested |  |  | (43,111 | ) |  | $ | 57.29 |  |  |  |  |  |
| RSUs cancelled |  |  | (5,620 | ) |  | $ | 68.47 |  |  |  |  |  |
| Balance at September 27, 2014 |  |  | 103,822 |  |  | $ | 70.98 |  |  |  |  |  |
| RSUs granted |  |  | 45,587 |  |  | $ | 105.51 |  |  |  |  |  |
| RSUs vested |  |  | (41,684 | ) |  | $ | 71.32 |  |  |  |  |  |
| RSUs cancelled |  |  | (6,258 | ) |  | $ | 80.34 |  |  |  |  |  |
| Balance at September 26, 2015 |  |  | 101,467 |  |  | $ | 85.77 |  |  | $ | 11,639 |  |

[0001193125-15-356351:notes:191]
The fair value as of the respective vesting dates
 of RSUs was $4.8 billion, $3.4 billion and $3.1 billion for 2015,
 2014 and 2013, respectively. The majority of RSUs that vested in
 2015, 2014 and 2013 were net-share settled such that the Company
 withheld shares with value equivalent to the employees’
 minimum statutory obligation for the applicable income and other
 employment taxes, and remitted the cash to the appropriate taxing
 authorities. The total shares withheld were approximately
 14.1 million, 15.6 million and 15.5 million for
 2015, 2014 and 2013, respectively, and were based on the value of
 the RSUs on their respective vesting dates as determined by the
 Company’s closing stock price. Total payments for the
 employees’ tax obligations to taxing authorities were $1.6
 billion, $1.2 billion and $1.1 billion in 2015, 2014 and 2013,
 respectively, and are reflected as a financing activity within the
 Consolidated Statements of Cash Flows. These net-share
 settlements had the effect of share repurchases by the Company as
 they reduced the number of shares that would have otherwise been
 issued as a result of the vesting and did not represent an expense
 to the Company.

[0001193125-15-356351:notes:192]
Stock Options

[0001193125-15-356351:notes:193]
The Company had 1.2 million stock options
 outstanding as of September 26, 2015, with a weighted-average
 exercise price per share of $15.08 and weighted-average remaining
 contractual term of 4.1 years, substantially all of which are
 exercisable. The aggregate intrinsic value of the stock options
 outstanding as of September 26, 2015 was $120 million, which
 represents the value of the Company’s closing stock price on
 the last trading day of the period in excess of the
 weighted-average exercise price multiplied by the number of options
 outstanding. Total intrinsic value of options at time of exercise
 was $479 million, $1.5 billion and $1.0 billion for 2015, 2014 and
 2013, respectively.

[0001193125-15-356351:notes:194]
The following table shows a summary of the
 share-based compensation expense included in the Consolidated
 Statements of Operations for 2015, 2014 and 2013 (in millions):

[0001193125-15-356351:notes:195]
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Cost of sales |  | $ | 575 |  |  | $ | 450 |  |  | $ | 350 |  |
| Research and development |  |  | 1,536 |  |  |  | 1,216 |  |  |  | 917 |  |
| Selling, general and administrative |  |  | 1,475 |  |  |  | 1,197 |  |  |  | 986 |  |
| Total share-based compensation expense |  | $ | 3,586 |  |  | $ | 2,863 |  |  | $ | 2,253 |  |

[0001193125-15-356351:notes:196]
The income tax benefit related to share-based
 compensation expense was $1.2 billion, $1.0 billion and $816
 million for 2015, 2014 and 2013, respectively. As of
 September 26, 2015, the total unrecognized compensation cost
 related to outstanding stock options, RSUs and restricted stock was
 $6.8 billion, which the Company expects to recognize over a
 weighted-average period of 2.7 years.


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001193125-15-356351:notes:197]
The following table shows changes in the
 Company’s accrued warranties and related costs for 2015, 2014
 and 2013 (in millions):

[0001193125-15-356351:notes:198]
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Beginning accrued warranty and related costs |  | $ | 4,159 |  |  | $ | 2,967 |  |  | $ | 1,638 |  |
| Cost of warranty claims |  |  | (4,401 | ) |  |  | (3,760 | ) |  |  | (3,703 | ) |
| Accruals for product warranty |  |  | 5,022 |  |  |  | 4,952 |  |  |  | 5,032 |  |
| Ending accrued warranty and related costs |  | $ | 4,780 |  |  | $ | 4,159 |  |  | $ | 2,967 |  |


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001193125-15-356351:notes:199]
| Long-lived assets as of September 26, 2015 and September 27, 2014 are as follows (in millions): |  | 2015 |  |  | 2014 |  |  |  |  |
| Long-lived assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. |  | $ | 12,022 |  |  | $ | 9,108 |  |  |  |  |  |
| China (1) |  |  | 8,722 |  |  |  | 9,477 |  |  |  |  |  |
| Other countries |  |  | 3,040 |  |  |  | 2,917 |  |  |  |  |  |
| Total long-lived assets |  | $ | 23,784 |  |  | $ | 21,502 |  |  |  |  |  |

[0001193125-15-356351:notes:200]
|  | (1) | China includes Hong Kong. Long-lived assets located in China consist primarily of product tooling and manufacturing process equipment and assets related to retail stores and related infrastructure. |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-15-356351:notes:201]
Note 5 – Income Taxes

[0001193125-15-356351:notes:202]
The foreign provision for income taxes is based on
 foreign pre-tax earnings of $47.6 billion, $33.6 billion and $30.5
 billion in 2015, 2014 and 2013, respectively. The Company’s
 consolidated financial statements provide for any related tax
 liability on undistributed earnings that the Company does not
 intend to be indefinitely reinvested outside the U.S. Substantially
 all of the Company’s undistributed international earnings
 intended to be indefinitely reinvested in operations outside the
 U.S. were generated by subsidiaries organized in Ireland, which has
 a statutory tax rate of 12.5%. As of September 26, 2015, U.S.
 income taxes have not been provided on a cumulative total of $91.5
 billion of such earnings. The amount of unrecognized deferred tax
 liability related to these temporary differences is estimated to be
 $30.0 billion.

[0001193125-15-356351:notes:203]
As of September 26, 2015 and
 September 27, 2014, $186.9 billion and $137.1 billion,
 respectively, of the Company’s cash, cash equivalents and
 marketable securities were held by foreign subsidiaries and are
 generally based in U.S. dollar-denominated holdings. Amounts
 held by foreign subsidiaries are generally subject to U.S. income
 taxation on repatriation to the U.S.

[0001193125-15-356351:notes:204]
The Company’s income taxes payable have been
 reduced by the tax benefits from employee stock plan awards. For
 stock options, the Company receives an income tax benefit
 calculated as the tax effect of the difference between the fair
 market value of the stock issued at the time of the exercise and
 the exercise price. For RSUs, the Company receives an income
 tax benefit upon the award’s vesting equal to the tax effect
 of the underlying stock’s fair market value. The Company had
 net excess tax benefits from equity awards of $748 million, $706
 million and $643 million in 2015, 2014 and 2013, respectively,
 which were reflected as increases to common stock.

[0001193125-15-356351:notes:205]
Deferred tax assets and liabilities reflect the
 effects of tax losses, credits and the future income tax effects of
 temporary differences between the consolidated financial statement
 carrying amounts of existing assets and liabilities and their
 respective tax bases and are measured using enacted tax rates that
 apply to taxable income in the years in which those temporary
 differences are expected to be recovered or settled.

[0001193125-15-356351:notes:206]
Uncertain Tax Positions

[0001193125-15-356351:notes:207]
Tax positions are evaluated in a two-step process.
 The Company first determines whether it is more likely than not
 that a tax position will be sustained upon examination. If a tax
 position meets the more-likely-than-not recognition threshold it is
 then measured to determine the amount of benefit to recognize in
 the financial statements. The tax position is measured as the
 largest amount of benefit that is greater than 50% likely of being
 realized upon ultimate settlement. The Company classifies gross
 interest and penalties and unrecognized tax benefits that are not
 expected to result in payment or receipt of cash within one year as
 non-current liabilities in the Consolidated Balance Sheets.

[0001193125-15-356351:notes:208]
As of September 26, 2015, the total amount of
 gross unrecognized tax benefits was $6.9 billion, of which $2.5
 billion, if recognized, would affect the Company’s effective
 tax rate. As of September 27, 2014, the total amount of gross
 unrecognized tax benefits was $4.0 billion, of which $1.4 billion,
 if recognized, would affect the Company’s effective tax
 rate.

[0001193125-15-356351:notes:209]
The Company includes interest and penalties related
 to unrecognized tax benefits within the provision for income taxes.
 As of September 26, 2015 and September 27, 2014, the
 total amount of gross interest and penalties accrued was $1.3
 billion and $630 million, respectively, which is classified as
 non-current liabilities in the Consolidated Balance Sheets. In
 connection with tax matters, the Company recognized interest and
 penalty expense in 2015, 2014 and 2013 of $709 million, $40 million
 and $189 million, respectively.

[0001193125-15-356351:notes:210]
The Company is subject to taxation and files income
 tax returns in the U.S. federal jurisdiction and in many state and
 foreign jurisdictions. The U.S. Internal Revenue Service (the
 “IRS”) is currently examining the years 2010 through
 2012, and all years prior to 2010 are closed. In addition, the
 Company is subject to audits by state, local and foreign tax
 authorities. In major states and major foreign jurisdictions,
 the years subsequent to 2003 generally remain open and could be
 subject to examination by the taxing authorities.

[0001193125-15-356351:notes:211]
Management believes that an adequate provision has
 been made for any adjustments that may result from tax
 examinations. However, the outcome of tax audits cannot be
 predicted with certainty. If any issues addressed in the
 Company’s tax audits are resolved in a manner not consistent
 with management’s expectations, the Company could be required
 to adjust its provision for income taxes in the period such
 resolution occurs. Although timing of the resolution and/or closure
 of audits is not certain, the Company does not believe it is
 reasonably possible that its unrecognized tax benefits would
 materially change in the next 12 months.

[0001193125-15-356351:notes:212]
On June 11, 2014, the European Commission
 issued an opening decision initiating a formal investigation
 against Ireland for alleged state aid to the Company. The opening
 decision concerns the allocation of profits for taxation purposes
 of the Irish branches of two subsidiaries of the Company. The
 Company believes the European Commission’s assertions are
 without merit. If the European Commission were to conclude against
 Ireland, the European Commission could require Ireland to recover
 from the Company past taxes covering a period of up to 10 years
 reflective of the disallowed state aid. While such amount could be
 material, as of September 26, 2015 the Company is unable to
 estimate the impact.


## us-gaap:InterestAndOtherIncomeTableTextBlock

[0001193125-15-356351:notes:213]
Other Income/(Expense), Net

[0001193125-15-356351:notes:214]
The following table shows the detail of other
 income/(expense), net for 2015, 2014 and 2013 (in millions):

[0001193125-15-356351:notes:215]
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Interest and dividend income |  | $ | 2,921 |  |  | $ | 1,795 |  |  | $ | 1,616 |  |
| Interest expense |  |  | (733 | ) |  |  | (384 | ) |  |  | (136 | ) |
| Other expense, net |  |  | (903 | ) |  |  | (431 | ) |  |  | (324 | ) |
| Total other income/(expense), net |  | $ | 1,285 |  |  | $ | 980 |  |  | $ | 1,156 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-15-356351:notes:216]
Note 7 – Shareholders’ Equity

[0001193125-15-356351:notes:217]
Dividends

[0001193125-15-356351:notes:218]
Future dividends are subject to declaration by the
 Board of Directors.

[0001193125-15-356351:notes:219]
Share Repurchase Program

[0001193125-15-356351:notes:220]
In the third quarter of 2015, the Company’s
 Board of Directors increased the share repurchase authorization to
 $140 billion of the Company’s common stock, of which $104
 billion had been utilized as of September 26, 2015. The
 Company’s share repurchase program does not obligate it to
 acquire any specific number of shares. Under the program, shares
 may be repurchased in privately negotiated and/or open market
 transactions, including under plans complying with Rule 10b5-1
 under the Securities Exchange Act of 1934, as amended (the
 “Exchange Act”).

[0001193125-15-356351:notes:221]
The Company has entered, and in the future may
 enter, into accelerated share repurchase arrangements
 (“ASRs”) with financial institutions. In exchange for
 up-front payments, the financial institutions deliver shares of the
 Company’s common stock during the purchase periods of each
 ASR. The total number of shares ultimately delivered, and therefore
 the average repurchase price paid per share, is determined at the
 end of the applicable purchase period of each ASR based on the
 volume weighted-average price of the Company’s common stock
 during that period. The shares received are retired in the periods
 they are delivered, and the up-front payments are accounted for as
 a reduction to shareholders’ equity in the Company’s
 Consolidated Balance Sheets in the periods the payments are made.
 The Company reflects the ASRs as a repurchase of common stock in
 the period delivered for purposes of calculating earnings per share
 and as forward contracts indexed to its own common stock. The ASRs
 met all of the applicable criteria for equity classification, and
 therefore were not accounted for as derivative instruments.

[0001193125-15-356351:notes:222]
Additionally, the Company repurchased shares of its
 common stock in the open market, which were retired upon
 repurchase, during the periods presented as follows:

[0001193125-15-356351:notes:223]
|  |  | Number of Shares(in thousands) |  |  | Average Repurchase Price Per Share |  |  | Amount (in millions) |  |
| 2015: |  |  |  |  |  |  |  |  |  |  |  |  |
| Fourth quarter |  |  | 121,802 |  |  | $ | 115.15 |  |  | $ | 14,026 |  |
| Third quarter |  |  | 31,231 |  |  | $ | 128.08 |  |  |  | 4,000 |  |
| Second quarter |  |  | 56,400 |  |  | $ | 124.11 |  |  |  | 7,000 |  |
| First quarter |  |  | 45,704 |  |  | $ | 109.40 |  |  |  | 5,000 |  |
| Total open market common stock repurchases |  |  | 255,137 |  |  |  |  |  |  | $ | 30,026 |  |
| 2014: |  |  |  |  |  |  |  |  |  |  |  |  |
| Fourth quarter |  |  | 81,255 |  |  | $ | 98.46 |  |  | $ | 8,000 |  |
| Third quarter |  |  | 58,661 |  |  | $ | 85.23 |  |  |  | 5,000 |  |
| Second quarter |  |  | 79,749 |  |  | $ | 75.24 |  |  |  | 6,000 |  |
| First quarter |  |  | 66,847 |  |  | $ | 74.79 |  |  |  | 5,000 |  |
| Total open market common stock repurchases |  |  | 286,512 |  |  |  |  |  |  | $ | 24,000 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001193125-15-356351:notes:224]
Note 12 – Selected Quarterly Financial Information
 (Unaudited)


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-15-356351:notes:225]
Note 10 – Commitments and Contingencies

[0001193125-15-356351:notes:226]
Accrued Warranty and Indemnification

[0001193125-15-356351:notes:227]
The Company generally does not indemnify end-users
 of its operating system and application software against legal
 claims that the software infringes third-party intellectual
 property rights. Other agreements entered into by the Company
 sometimes include indemnification provisions under which the
 Company could be subject to costs and/or damages in the event of an
 infringement claim against the Company or an indemnified
 third-party. In the opinion of management, there was not at least a
 reasonable possibility the Company may have incurred a material
 loss with respect to indemnification of end-users of its operating
 system or application software for infringement of third-party
 intellectual property rights. The Company did not record a
 liability for infringement costs related to indemnification as of
 September 26, 2015 or September 27, 2014.

[0001193125-15-356351:notes:228]
In September 2015, the Company introduced the
 iPhone Upgrade Program, which is available to customers who
 purchase an iPhone 6s and 6s Plus in one of its U.S. physical
 retail stores and activate the purchased iPhone with one of the
 four national carriers. The iPhone Upgrade Program provides
 customers the right to trade in that iPhone for a new iPhone,
 provided certain conditions are met. One of the conditions of this
 program requires the customer to finance the initial purchase price
 of the iPhone with a third-party lender. Upon exercise of the
 trade-in right and purchase of a new iPhone, the Company satisfies
 the customer’s outstanding balance due to the third-party
 lender on the original device. The Company accounts for the
 trade-in right as a guarantee liability and recognizes arrangement
 revenue net of the fair value of such right with subsequent changes
 to the guarantee liability recognized within revenue.

[0001193125-15-356351:notes:229]
The Company has entered into indemnification
 agreements with its directors and executive officers. Under these
 agreements, the Company has agreed to indemnify such individuals to
 the fullest extent permitted by law against liabilities that arise
 by reason of their status as directors or officers and to advance
 expenses incurred by such individuals in connection with related
 legal proceedings. It is not possible to determine the maximum
 potential amount of payments the Company could be required to make
 under these agreements due to the limited history of prior
 indemnification claims and the unique facts and circumstances
 involved in each claim. However, the Company maintains directors
 and officers liability insurance coverage to reduce its exposure to
 such obligations.

[0001193125-15-356351:notes:230]
Concentrations in the Available Sources of Supply of Materials
 and Product

[0001193125-15-356351:notes:231]
Although most components essential to the
 Company’s business are generally available from multiple
 sources, a number of components are currently obtained from single
 or limited sources. In addition, the Company competes for various
 components with other participants in the markets for mobile
 communication and media devices and personal computers. Therefore,
 many components used by the Company, including those that are
 available from multiple sources, are at times subject to
 industry-wide shortage and significant pricing fluctuations that
 could materially adversely affect the Company’s financial
 condition and operating results.

[0001193125-15-356351:notes:232]
The Company uses some custom components that are
 not commonly used by its competitors, and new products introduced
 by the Company often utilize custom components available from only
 one source. When a component or product uses new technologies,
 initial capacity constraints may exist until the suppliers’
 yields have matured or manufacturing capacity has increased. If the
 Company’s supply of components for a new or existing product
 were delayed or constrained, or if an outsourcing partner delayed
 shipments of completed products to the Company, the Company’s
 financial condition and operating results could be materially
 adversely affected. The Company’s business and financial
 performance could also be materially adversely affected depending
 on the time required to obtain sufficient quantities from the
 original source, or to identify and obtain sufficient quantities
 from an alternative source. Continued availability of these
 components at acceptable prices, or at all, may be affected if
 those suppliers concentrated on the production of common components
 instead of components customized to meet the Company’s
 requirements.

[0001193125-15-356351:notes:233]
The Company has entered into agreements for the
 supply of many components; however, there can be no guarantee that
 the Company will be able to extend or renew these agreements on
 similar terms, or at all. Therefore, the Company remains subject to
 significant risks of supply shortages and price increases that
 could materially adversely affect its financial condition and
 operating results.

[0001193125-15-356351:notes:234]
Substantially all of the Company’s hardware
 products are manufactured by outsourcing partners that are located
 primarily in Asia. A significant concentration of this
 manufacturing is currently performed by a small number of
 outsourcing partners, often in single locations. Certain of these
 outsourcing partners are the sole-sourced suppliers of components
 and manufacturers for many of the Company’s products.
 Although the Company works closely with its outsourcing partners on
 manufacturing schedules, the Company’s operating results
 could be adversely affected if its outsourcing partners were unable
 to meet their production commitments. The Company’s purchase
 commitments typically cover its requirements for periods up to 150
 days.

[0001193125-15-356351:notes:235]
Other Off-Balance Sheet Commitments

[0001193125-15-356351:notes:236]
Operating Leases

[0001193125-15-356351:notes:237]
The Company leases various equipment and
 facilities, including retail space, under noncancelable operating
 lease arrangements. The Company does not currently utilize any
 other off-balance sheet financing arrangements. The major facility
 leases are typically for terms not exceeding 10 years and generally
 contain multi-year renewal options. As of September 26, 2015,
 the Company had a total of 463 retail stores. Leases for retail
 space are for terms ranging from five to 20 years, the majority of
 which are for 10 years, and often contain multi-year renewal
 options. As of September 26, 2015, the Company’s total
 future minimum lease payments under noncancelable operating leases
 were $6.3 billion, of which $3.6 billion related to leases for
 retail space.

[0001193125-15-356351:notes:238]
Rent expense under all operating leases, including
 both cancelable and noncancelable leases, was $794 million, $717
 million and $645 million in 2015, 2014 and 2013, respectively.
 Future minimum lease payments under noncancelable operating leases
 having remaining terms in excess of one year as of
 September 26, 2015, are as follows (in millions):

[0001193125-15-356351:notes:239]
| 2016 |  | $ | 772 |  |
| 2017 |  |  | 774 |  |
| 2018 |  |  | 744 |  |
| 2019 |  |  | 715 |  |
| 2020 |  |  | 674 |  |
| Thereafter |  |  | 2,592 |  |
| Total |  | $ | 6,271 |  |

[0001193125-15-356351:notes:240]
Other Commitments

[0001193125-15-356351:notes:241]
The Company utilizes several outsourcing partners
 to manufacture sub-assemblies for the Company’s products and
 to perform final assembly and testing of finished products. These
 outsourcing partners acquire components and build product based on
 demand information supplied by the Company, which typically covers
 periods up to 150 days. The Company also obtains individual
 components for its products from a wide variety of individual
 suppliers. Consistent with industry practice, the Company acquires
 components through a combination of purchase orders, supplier
 contracts and open orders based on projected demand information.
 Where appropriate, the purchases are applied
 to inventory component prepayments that
 are outstanding with the respective supplier. As of
 September 26, 2015, the Company had outstanding off-balance
 sheet third-party manufacturing commitments and component purchase
 commitments of $29.5 billion.

[0001193125-15-356351:notes:242]
In addition to the commitments mentioned above, the
 Company had other off-balance sheet obligations of $7.3 billion as
 of September 26, 2015 that consisted of commitments to acquire
 capital assets, including product tooling and manufacturing process
 equipment, and commitments related to inventory prepayments,
 advertising, licensing, R&D, internet and telecommunications
 services, energy and other obligations.

[0001193125-15-356351:notes:243]
Contingencies

[0001193125-15-356351:notes:244]
The Company is subject to various legal proceedings
 and claims that have arisen in the ordinary course of business and
 that have not been fully adjudicated, certain of which are
 discussed in Part I, Item 1A of this Form 10-K under the
 heading “Risk Factors” and in Part I, Item 3 of
 this Form 10-K under the heading “Legal Proceedings.”
 In the opinion of management, there was not at least a reasonable
 possibility the Company may have incurred a material loss, or a
 material loss in excess of a recorded accrual, with respect to loss
 contingencies for asserted legal and other claims. However, the
 outcome of litigation is inherently uncertain. Therefore, although
 management considers the likelihood of such an outcome to be
 remote, if one or more of these legal matters were resolved against
 the Company in a reporting period for amounts in excess of
 management’s expectations, the Company’s consolidated
 financial statements for that reporting period could be materially
 adversely affected.

[0001193125-15-356351:notes:245]
Apple Inc. v. Samsung Electronics Co., Ltd, et al.

[0001193125-15-356351:notes:246]
On August 24, 2012, a jury returned a verdict
 awarding the Company $1.05 billion in its lawsuit against Samsung
 Electronics Co., Ltd and affiliated parties in the United States
 District Court, Northern District of California, San Jose Division.
 On March 6, 2014, the District Court entered final judgment in
 favor of the Company in the amount of approximately $930
 million. On May 18, 2015, the U.S. Court of Appeals for
 the Federal Circuit affirmed in part, and reversed in part, the
 decision of the District Court. As a result, the Court of Appeals
 ordered entry of final judgment on damages in the amount of
 approximately $548 million, with the District Court to determine
 supplemental damages and interest, as well as damages owed for
 products subject to the reversal in part. Because the ruling
 remains subject to further proceedings, the Company has not
 recognized the award in its results of operations.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001193125-15-356351:notes:247]
Note 3 – Consolidated Financial Statement Details

[0001193125-15-356351:notes:248]
The following tables show the Company’s
 consolidated financial statement details as of September 26,
 2015 and September 27, 2014 (in millions):
