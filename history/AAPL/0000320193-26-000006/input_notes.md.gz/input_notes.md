# AAPL notes — 0000320193-26-000006


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000320193-26-000006:notes:1]
[same as prior period, unchanged from 0000320193-25-000073:notes:1]

[0000320193-26-000006:notes:2]
The condensed consolidated financial statements include the accounts of Apple Inc. and its wholly owned subsidiaries (collectively “Apple” or the “Company”). In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements and accompanying notes in conformity with U.S. generally accepted accounting principles (“GAAP”) requires the use of management estimates. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company’s annual consolidated financial statements and accompanying notes included in its Annual Report on Form 10-K for the fiscal year ended September 27, 2025 (the “2025 Form 10-K”).

[0000320193-26-000006:notes:3]
The Company’s fiscal year is the 52- or 53-week period that ends on the last Saturday of September. An additional week is included in the first fiscal quarter every five or six years to realign the Company’s fiscal quarters with calendar quarters. The Company’s fiscal years 2026 and 2025 span 52 weeks each. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in September and the associated quarters, months and periods of those fiscal years.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000320193-26-000006:notes:4]
Revenue
The following table shows disaggregated net sales, as well as the portion of total net sales that was previously deferred, for the three months ended December 27, 2025 and December 28, 2024 (in millions):

[0000320193-26-000006:notes:5]
|  | Three Months Ended |  |  |
|  | December 27,2025 |  | December 28,2024 |  |  |  |  |
| iPhone® | $ | 85,269 |  |  | $ | 69,138 |  |  |  |  |  |
| Mac® | 8,386 |  |  | 8,987 |  |  |  |  |  |
| iPad® | 8,595 |  |  | 8,088 |  |  |  |  |  |
| Wearables, Home and Accessories | 11,493 |  |  | 11,747 |  |  |  |  |  |
| Services | 30,013 |  |  | 26,340 |  |  |  |  |  |
| Total net sales | $ | 143,756 |  |  | $ | 124,300 |  |  |  |  |  |
| Portion of total net sales that was included in deferred revenue as of the beginning of the period | $ | 4,050 |  |  | $ | 3,690 |  |  |  |  |  |

[0000320193-26-000006:notes:6]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 10, “Segment Information” for the three months ended December 27, 2025 and December 28, 2024, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.

[0000320193-26-000006:notes:7]
As of December 27, 2025 and September 27, 2025, the Company had total deferred revenue of $14.3 billion and $13.7 billion, respectively. As of December 27, 2025, the Company expects 66% of total deferred revenue to be realized in less than a year, 23% within one-to-two years, 9% within two-to-three years and 2% in greater than three years.


## us-gaap:EarningsPerShareTextBlock

[0000320193-26-000006:notes:8]
Earnings Per Share
The following table shows the computation of basic and diluted earnings per share for the three months ended December 27, 2025 and December 28, 2024 (net income in millions and shares in thousands):

[0000320193-26-000006:notes:9]
|  | Three Months Ended |  |  |
|  | December 27,2025 |  | December 28,2024 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 42,097 |  |  | $ | 36,330 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 14,748,158 |  |  | 15,081,724 |  |  |  |  |  |
| Effect of dilutive share-based awards | 62,198 |  |  | 69,141 |  |  |  |  |  |
| Weighted-average diluted shares | 14,810,356 |  |  | 15,150,865 |  |  |  |  |  |
| Basic earnings per share | $ | 2.85 |  |  | $ | 2.41 |  |  |  |  |  |
| Diluted earnings per share | $ | 2.84 |  |  | $ | 2.40 |  |  |  |  |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000320193-26-000006:notes:10]
[same as prior period, unchanged from 0000320193-25-000073:notes:10]

[0000320193-26-000006:notes:11]
The following tables show the Company’s cash, cash equivalents and marketable securities by significant investment category as of December 27, 2025 and September 27, 2025 (in millions):

[0000320193-26-000006:notes:12]
|  | December 27, 2025 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | CurrentMarketableSecurities |  | Non-CurrentMarketableSecurities |
| Cash | $ | 30,826 |  |  | $ | — |  |  | $ | — |  |  | $ | 30,826 |  |  | $ | 30,826 |  |  | $ | — |  |  | $ | — |  |
| Level 1: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 5,959 |  |  | — |  |  | — |  |  | 5,959 |  |  | 5,959 |  |  | — |  |  | — |  |
| Mutual funds | 792 |  |  | 195 |  |  | (2) |  |  | 985 |  |  | — |  |  | 985 |  |  | — |  |
| Subtotal | 6,751 |  |  | 195 |  |  | (2) |  |  | 6,944 |  |  | 5,959 |  |  | 985 |  |  | — |  |
| Level 2 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 18,715 |  |  | 64 |  |  | (211) |  |  | 18,568 |  |  | 2,302 |  |  | 5,341 |  |  | 10,925 |  |
| U.S. agency securities | 8,692 |  |  | 1 |  |  | (114) |  |  | 8,579 |  |  | 4,192 |  |  | 1,998 |  |  | 2,389 |  |
| Non-U.S. government securities | 6,675 |  |  | 117 |  |  | (399) |  |  | 6,393 |  |  | — |  |  | 771 |  |  | 5,622 |  |
| Certificates of deposit and time deposits | 1,737 |  |  | — |  |  | — |  |  | 1,737 |  |  | 1,723 |  |  | — |  |  | 14 |  |
| Commercial paper | 991 |  |  | — |  |  | — |  |  | 991 |  |  | 297 |  |  | 694 |  |  | — |  |
| Corporate debt securities | 46,682 |  |  | 280 |  |  | (695) |  |  | 46,267 |  |  | 18 |  |  | 11,568 |  |  | 34,681 |  |
| Municipal securities | 154 |  |  | — |  |  | (1) |  |  | 153 |  |  | — |  |  | 97 |  |  | 56 |  |
| Mortgage- and asset-backed securities | 25,296 |  |  | 158 |  |  | (1,117) |  |  | 24,337 |  |  | — |  |  | 136 |  |  | 24,201 |  |
| Subtotal | 108,942 |  |  | 620 |  |  | (2,537) |  |  | 107,025 |  |  | 8,532 |  |  | 20,605 |  |  | 77,888 |  |
| Total | $ | 146,519 |  |  | $ | 815 |  |  | $ | (2,539) |  |  | $ | 144,795 |  |  | $ | 45,317 |  |  | $ | 21,590 |  |  | $ | 77,888 |  |

[0000320193-26-000006:notes:13]
|  | September 27, 2025 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | CurrentMarketableSecurities |  | Non-CurrentMarketableSecurities |
| Cash | $ | 28,267 |  |  | $ | — |  |  | $ | — |  |  | $ | 28,267 |  |  | $ | 28,267 |  |  | $ | — |  |  | $ | — |  |
| Level 1: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 5,272 |  |  | — |  |  | — |  |  | 5,272 |  |  | 5,272 |  |  | — |  |  | — |  |
| Mutual funds | 679 |  |  | 177 |  |  | (2) |  |  | 854 |  |  | — |  |  | 854 |  |  | — |  |
| Subtotal | 5,951 |  |  | 177 |  |  | (2) |  |  | 6,126 |  |  | 5,272 |  |  | 854 |  |  | — |  |
| Level 2 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 16,074 |  |  | 56 |  |  | (282) |  |  | 15,848 |  |  | 1,190 |  |  | 3,712 |  |  | 10,946 |  |
| U.S. agency securities | 5,269 |  |  | — |  |  | (149) |  |  | 5,120 |  |  | 251 |  |  | 2,456 |  |  | 2,413 |  |
| Non-U.S. government securities | 6,586 |  |  | 111 |  |  | (424) |  |  | 6,273 |  |  | — |  |  | 855 |  |  | 5,418 |  |
| Certificates of deposit and time deposits | 917 |  |  | — |  |  | — |  |  | 917 |  |  | 904 |  |  | — |  |  | 13 |  |
| Commercial paper | 100 |  |  | — |  |  | — |  |  | 100 |  |  | 50 |  |  | 50 |  |  | — |  |
| Corporate debt securities | 47,210 |  |  | 266 |  |  | (916) |  |  | 46,560 |  |  | — |  |  | 10,623 |  |  | 35,937 |  |
| Municipal securities | 207 |  |  | — |  |  | (2) |  |  | 205 |  |  | — |  |  | 119 |  |  | 86 |  |
| Mortgage- and asset-backed securities | 24,130 |  |  | 126 |  |  | (1,252) |  |  | 23,004 |  |  | — |  |  | 94 |  |  | 22,910 |  |
| Subtotal | 100,493 |  |  | 559 |  |  | (3,025) |  |  | 98,027 |  |  | 2,395 |  |  | 17,909 |  |  | 77,723 |  |
| Total | $ | 134,711 |  |  | $ | 736 |  |  | $ | (3,027) |  |  | $ | 132,420 |  |  | $ | 35,934 |  |  | $ | 18,763 |  |  | $ | 77,723 |  |

[0000320193-26-000006:notes:14]
[same as prior period, unchanged from 0000320193-25-000073:notes:14]

[0000320193-26-000006:notes:15]
As of December 27, 2025, 78% of the Company’s non-current marketable debt securities other than mortgage- and asset-backed securities had maturities between 1 and 5 years, 17% between 5 and 10 years, and 5% greater than 10 years. As of December 27, 2025, 12% of the Company’s non-current mortgage- and asset-backed securities had maturities between 1 and 5 years, 18% between 5 and 10 years, and 70% greater than 10 years.

[0000320193-26-000006:notes:16]
[same as prior period, unchanged from 0000320193-25-000073:notes:18]

[0000320193-26-000006:notes:17]
[same as prior period, unchanged from 0000320193-25-000073:notes:19]

[0000320193-26-000006:notes:18]
[same as prior period, unchanged from 0000320193-25-000073:notes:20]

[0000320193-26-000006:notes:19]
[same as prior period, unchanged from 0000320193-25-000073:notes:21]

[0000320193-26-000006:notes:20]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in foreign exchange rates, the Company may use forwards, cross-currency swaps or other instruments. The Company designates these instruments as either cash flow or fair value hedges. As of December 27, 2025, the maximum length of time over which the Company is hedging its exposure to the variability in future cash flows for term debt–related foreign currency transactions is 17 years.

[0000320193-26-000006:notes:21]
[same as prior period, unchanged from 0000320193-25-000073:notes:23]

[0000320193-26-000006:notes:22]
[same as prior period, unchanged from 0000320193-25-000073:notes:24]

[0000320193-26-000006:notes:23]
[same as prior period, unchanged from 0000320193-25-000073:notes:25]

[0000320193-26-000006:notes:24]
The notional amounts of the Company’s outstanding derivative instruments as of December 27, 2025 and September 27, 2025, were as follows (in millions):

[0000320193-26-000006:notes:25]
|  | December 27,2025 |  | September 27,2025 |
| Derivative instruments designated as accounting hedges: |  |  |  |
| Foreign exchange contracts | $ | 46,619 |  |  | $ | 62,647 |  |
| Interest rate contracts | $ | 12,875 |  |  | $ | 12,875 |  |
| Derivative instruments not designated as accounting hedges: |  |  |  |
| Foreign exchange contracts | $ | 120,980 |  |  | $ | 109,079 |  |

[0000320193-26-000006:notes:26]
As of both December 27, 2025 and September 27, 2025, the carrying amount of the Company’s current and non-current term debt subject to fair value hedges was $12.6 billion.

[0000320193-26-000006:notes:27]
[same as prior period, unchanged from 0000320193-25-000073:notes:29]

[0000320193-26-000006:notes:28]
[same as prior period, unchanged from 0000320193-25-000073:notes:30]

[0000320193-26-000006:notes:29]
As of December 27, 2025, the Company had two customers that individually represented 10% or more of total trade receivables, which accounted for 15% and 10%. As of September 27, 2025, the Company had one customer that represented 10% or more of total trade receivables, which accounted for 12%. The Company’s third-party cellular network carriers accounted for 35% and 34% of total trade receivables as of December 27, 2025 and September 27, 2025, respectively. The Company requires third-party credit support or collateral from certain customers to limit credit risk.

[0000320193-26-000006:notes:30]
[same as prior period, unchanged from 0000320193-25-000073:notes:32]

[0000320193-26-000006:notes:31]
The Company has non-trade receivables from certain of its manufacturing vendors resulting from the sale of components to these vendors who manufacture subassemblies or assemble final products for the Company. The Company purchases these components directly from suppliers. The Company does not reflect the sale of these components in products net sales. Rather, the Company recognizes any gain on these sales as a reduction of products cost of sales when the related final products are sold by the Company. As of December 27, 2025, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 47% and 26%. As of September 27, 2025, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 46% and 23%.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000320193-26-000006:notes:32]
Condensed Consolidated Financial Statement Details
The following table shows the Company’s condensed consolidated financial statement details as of December 27, 2025 and September 27, 2025 (in millions):

[0000320193-26-000006:notes:33]
[same as prior period, unchanged from 0000320193-25-000073:notes:37]

[0000320193-26-000006:notes:34]
|  | December 27,2025 |  | September 27,2025 |
| Gross property, plant and equipment | $ | 127,320 |  |  | $ | 125,848 |  |
| Accumulated depreciation | (77,161) |  |  | (76,014) |  |
| Total property, plant and equipment, net | $ | 50,159 |  |  | $ | 49,834 |  |


## us-gaap:DebtDisclosureTextBlock

[0000320193-26-000006:notes:35]
Debt
Commercial Paper

[0000320193-26-000006:notes:36]
The Company issues unsecured short-term promissory notes pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of December 27, 2025 and September 27, 2025, the Company had $2.0 billion and $8.0 billion of commercial paper outstanding, respectively. The following table provides a summary of cash flows associated with commercial paper for the three months ended December 27, 2025 and December 28, 2024 (in millions):

[0000320193-26-000006:notes:37]
|  | Three Months Ended |
|  | December 27,2025 |  | December 28,2024 |
| Maturities 90 days or less: |  |  |  |
| Repayments of commercial paper, net | $ | (2,122) |  |  | $ | (7,944) |  |
| Maturities greater than 90 days: |  |  |  |
| Repayments of commercial paper | (3,788) |  |  | — |  |
| Total repayments of commercial paper, net | $ | (5,910) |  |  | $ | (7,944) |  |

[0000320193-26-000006:notes:38]
Term Debt

[0000320193-26-000006:notes:39]
As of December 27, 2025 and September 27, 2025, the Company had outstanding fixed-rate notes with varying maturities for an aggregate carrying amount of $88.5 billion and $90.7 billion, respectively (collectively the “Notes”). As of December 27, 2025 and September 27, 2025, the fair value of the Company’s Notes, based on Level 2 inputs, was $78.1 billion and $80.4 billion, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000320193-26-000006:notes:40]
[same as prior period, unchanged from 0000320193-25-000073:notes:44]

[0000320193-26-000006:notes:41]
During the three months ended December 27, 2025, the Company repurchased 93 million shares of its common stock for $25.0 billion. The Company’s share repurchase program does not obligate the Company to acquire a minimum amount of shares. Under the program, shares may be repurchased in privately negotiated or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended (“Exchange Act”).


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000320193-26-000006:notes:42]
[same as prior period, unchanged from 0000320193-25-000073:notes:46]

[0000320193-26-000006:notes:43]
A summary of the Company’s restricted stock unit (“RSU”) activity and related information for the three months ended December 27, 2025, is as follows:

[0000320193-26-000006:notes:44]
|  | Number ofRSUs(in thousands) |  | Weighted-AverageGrant-Date FairValue Per RSU |
| Balance as of September 27, 2025 | 151,574 |  |  | $ | 189.75 |  |
| RSUs granted | 61,897 |  |  | $ | 256.22 |  |
| RSUs vested | (33,905) |  |  | $ | 173.00 |  |
| RSUs forfeited | (3,470) |  |  | $ | 208.14 |  |
| Balance as of December 27, 2025 | 176,096 |  |  | $ | 215.98 |  |

[0000320193-26-000006:notes:45]
The total vesting-date fair value of RSUs was $8.6 billion and $8.4 billion for the three months ended December 27, 2025 and December 28, 2024, respectively.

[0000320193-26-000006:notes:46]
[same as prior period, unchanged from 0000320193-25-000073:notes:50]

[0000320193-26-000006:notes:47]
The following table shows share-based compensation expense and the related income tax benefit included in the Condensed Consolidated Statements of Operations for the three months ended December 27, 2025 and December 28, 2024 (in millions):

[0000320193-26-000006:notes:48]
|  | Three Months Ended |  |  |
|  | December 27,2025 |  | December 28,2024 |  |  |  |  |
| Share-based compensation expense | $ | 3,594 |  |  | $ | 3,286 |  |  |  |  |  |
| Income tax benefit related to share-based compensation expense | $ | (1,293) |  |  | $ | (1,332) |  |  |  |  |  |

[0000320193-26-000006:notes:49]
As of December 27, 2025, the total unrecognized compensation cost related to outstanding RSUs was $31.5 billion, which the Company expects to recognize over a weighted-average period of 2.9 years.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000320193-26-000006:notes:50]
Commitments and Contingencies
Unconditional Purchase Obligations

[0000320193-26-000006:notes:51]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of supplier arrangements, licensed intellectual property and content, and distribution rights. Future payments under unconditional purchase obligations with a remaining term in excess of one year as of December 27, 2025, are as follows (in millions):

[0000320193-26-000006:notes:52]
| 2026 (remaining nine months) | $ | 4,754 |  |
| 2027 | 8,066 |  |
| 2028 | 7,005 |  |
| 2029 | 6,538 |  |
| 2030 | 5,992 |  |
| Thereafter | 827 |  |
| Total | $ | 33,182 |  |

[0000320193-26-000006:notes:53]
Contingencies

[0000320193-26-000006:notes:54]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully resolved. The outcome of litigation is inherently uncertain. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss greater than a recorded accrual, concerning loss contingencies for asserted legal and other claims.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000320193-26-000006:notes:55]
Segment Information
The following table shows information by reportable segment for the three months ended December 27, 2025 and December 28, 2024 (in millions):

[0000320193-26-000006:notes:56]
|  | Three Months Ended December 27, 2025 |
|  | Americas |  | Europe |  | GreaterChina |  | Japan |  | Rest ofAsia Pacific |  | Corporate |  | Total |
| Net sales | $ | 58,529 |  |  | $ | 38,146 |  |  | $ | 25,526 |  |  | $ | 9,413 |  |  | $ | 12,142 |  |  | $ | — |  |  | $ | 143,756 |  |
| Cost of sales | (31,849) |  |  | (19,061) |  |  | (13,030) |  |  | (4,511) |  |  | (6,074) |  |  | — |  |  | (74,525) |  |
| Research and development | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (10,887) |  |  | (10,887) |  |
| Selling and marketing | (2,727) |  |  | (1,295) |  |  | (704) |  |  | (289) |  |  | (382) |  |  | — |  |  | (5,397) |  |
| General and administrative | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (2,095) |  |  | (2,095) |  |
| Operating income/(loss) | $ | 23,953 |  |  | $ | 17,790 |  |  | $ | 11,792 |  |  | $ | 4,613 |  |  | $ | 5,686 |  |  | $ | (12,982) |  |  | $ | 50,852 |  |
|  | Three Months Ended December 28, 2024 |
|  | Americas |  | Europe |  | GreaterChina |  | Japan |  | Rest ofAsia Pacific |  | Corporate |  | Total |
| Net sales | $ | 52,648 |  |  | $ | 33,861 |  |  | $ | 18,513 |  |  | $ | 8,987 |  |  | $ | 10,291 |  |  | $ | — |  |  | $ | 124,300 |  |
| Cost of sales | (28,495) |  |  | (18,043) |  |  | (9,759) |  |  | (4,393) |  |  | (5,335) |  |  | — |  |  | (66,025) |  |
| Research and development | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (8,268) |  |  | (8,268) |  |
| Selling and marketing | (2,644) |  |  | (1,211) |  |  | (594) |  |  | (280) |  |  | (372) |  |  | — |  |  | (5,101) |  |
| General and administrative | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (2,074) |  |  | (2,074) |  |
| Operating income/(loss) | $ | 21,509 |  |  | $ | 14,607 |  |  | $ | 8,160 |  |  | $ | 4,314 |  |  | $ | 4,584 |  |  | $ | (10,342) |  |  | $ | 42,832 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0000320193-26-000006:notes:57]
On November 21, 2025, Kevan Parekh, the Company’s Senior Vice President and Chief Financial Officer, entered into a trading plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act. The plan provides for the sale, subject to certain price limits, of shares vesting between April 15, 2026 and October 15, 2026, pursuant to certain equity awards granted to Mr. Parekh, excluding any shares withheld by the Company to satisfy income tax withholding and remittance obligations. Mr. Parekh’s plan will expire on December 31, 2026, subject to early termination in accordance with the terms of the plan.

[0000320193-26-000006:notes:58]
On November 24, 2025, Deirdre O’Brien, the Company’s Senior Vice President, Retail + People, terminated a trading plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act, which was previously adopted on August 27, 2024 (the “Prior Plan”). The Prior Plan provided for the sale, subject to certain price limits, of shares vesting between April 1, 2025 and October 1, 2026, pursuant to certain equity awards granted to Ms. O’Brien, excluding any shares withheld by the Company to satisfy income tax withholding and remittance obligations. The Prior Plan would have expired on December 31, 2026, subject to early termination in accordance with the terms of the plan. Following termination of the Prior Plan, on November 24, 2025, Ms. O’Brien entered into a new trading plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act. The new plan provides for the sale of shares vesting between April 1, 2026 and October 1, 2026, pursuant to certain equity awards granted to Ms. O’Brien, excluding any shares withheld by the Company to satisfy income tax withholding and remittance obligations. Ms. O’Brien’s new plan will expire on December 31, 2026, subject to early termination in accordance with the terms of the plan.
