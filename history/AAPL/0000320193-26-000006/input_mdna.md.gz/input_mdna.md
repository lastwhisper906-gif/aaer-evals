# AAPL MD&A — 0000320193-26-000006


## mdna

[0000320193-26-000006:mdna:1]
[same as prior period, unchanged from 0000320193-25-000073:mdna:1]

[0000320193-26-000006:mdna:2]
[same as prior period, unchanged from 0000320193-25-000073:mdna:2]

[0000320193-26-000006:mdna:3]
The following discussion should be read in conjunction with the 2025 Form 10-K filed with the U.S. Securities and Exchange Commission (“SEC”) and the condensed consolidated financial statements and accompanying notes included in Part I, Item 1 of this Form 10-Q.

[0000320193-26-000006:mdna:4]
[same as prior period, unchanged from 0000320193-25-000073:mdna:4]

[0000320193-26-000006:mdna:5]
[same as prior period, unchanged from 0000320193-25-000073:mdna:5]

[0000320193-26-000006:mdna:6]
[same as prior period, unchanged from 0000320193-25-000073:mdna:6]

[0000320193-26-000006:mdna:7]
[same as prior period, unchanged from 0000320193-25-000073:mdna:7]

[0000320193-26-000006:mdna:8]
During the first quarter of 2026, the Company announced the following updated products:

[0000320193-26-000006:mdna:9]
•14-inch MacBook Pro®

[0000320193-26-000006:mdna:10]
•iPad Pro®

[0000320193-26-000006:mdna:11]
•Apple Vision Pro®

[0000320193-26-000006:mdna:12]
[same as prior period, unchanged from 0000320193-25-000073:mdna:9]

[0000320193-26-000006:mdna:13]
Macroeconomic conditions, including inflation, interest rates, component pricing and currency fluctuations, have directly and indirectly impacted, and could in the future materially impact, the Company’s results of operations and financial condition.

[0000320193-26-000006:mdna:14]
[same as prior period, unchanged from 0000320193-25-000073:mdna:11]

[0000320193-26-000006:mdna:15]
Beginning in the second quarter of 2025, new tariffs were announced on imports to the U.S., including additional tariffs on imports from China, India, Japan, South Korea, Taiwan, Vietnam and the European Union (“EU”), among others. In response, several countries have imposed, or threatened to impose, reciprocal tariffs on imports from the U.S. and other retaliatory measures. On January 14, 2026, initial results were published of the previously announced U.S. Department of Commerce investigation under Section 232 of the Trade Expansion Act of 1962, as amended, into imports of semiconductors, semiconductor manufacturing equipment, and their derivative products, including downstream products that contain semiconductors. The announcement of the initial results of the investigation did not impose any additional tariffs affecting the Company’s products at this time. Various modifications to U.S. tariffs have been announced and further changes could be made in the future, which may include additional measures under the Section 232 semiconductor sector investigation, additional sector-based tariffs, or other measures. Tariffs and other measures that are applied to the Company’s products or their components can have a material adverse impact on the Company’s business, results of operations and financial condition, including impacting the Company’s supply chain, the availability of rare earths and other raw materials and components, pricing and gross margin. The ultimate impact remains uncertain and will depend on several factors, including whether additional or incremental U.S. tariffs or other measures are announced or imposed, to what extent other countries implement tariffs or other retaliatory measures in response, and the overall magnitude and duration of these measures. Trade and other international disputes can have an adverse impact on the overall macroeconomic environment and result in shifts and reductions in consumer spending and negative consumer sentiment for the Company’s products and services, all of which can further adversely affect the Company’s business and results of operations.

[0000320193-26-000006:mdna:16]
[same as prior period, unchanged from 0000320193-25-000073:mdna:13]

[0000320193-26-000006:mdna:17]
The following table shows net sales by reportable segment for the three months ended December 27, 2025 and December 28, 2024 (dollars in millions):

[0000320193-26-000006:mdna:18]
|  | Three Months Ended |  |  |
|  | December 27,2025 |  | December 28,2024 |  | Change |  |  |  |  |  |  |
| Americas | $ | 58,529 |  |  | $ | 52,648 |  |  | 11 | % |  |  |  |  |  |  |
| Europe | 38,146 |  |  | 33,861 |  |  | 13 | % |  |  |  |  |  |  |
| Greater China | 25,526 |  |  | 18,513 |  |  | 38 | % |  |  |  |  |  |  |
| Japan | 9,413 |  |  | 8,987 |  |  | 5 | % |  |  |  |  |  |  |
| Rest of Asia Pacific | 12,142 |  |  | 10,291 |  |  | 18 | % |  |  |  |  |  |  |
| Total net sales | $ | 143,756 |  |  | $ | 124,300 |  |  | 16 | % |  |  |  |  |  |  |

[0000320193-26-000006:mdna:19]
[same as prior period, unchanged from 0000320193-25-000073:mdna:16]

[0000320193-26-000006:mdna:20]
Americas net sales increased during the first quarter of 2026 compared to the same quarter in 2025 primarily due to higher net sales of iPhone and Services.

[0000320193-26-000006:mdna:21]
[same as prior period, unchanged from 0000320193-25-000073:mdna:18]

[0000320193-26-000006:mdna:22]
Europe net sales increased during the first quarter of 2026 compared to the same quarter in 2025 primarily due to higher net sales of iPhone and Services. The strength in foreign currencies relative to the U.S. dollar had a net favorable year-over-year impact on Europe net sales during the first quarter of 2026.

[0000320193-26-000006:mdna:23]
[same as prior period, unchanged from 0000320193-25-000073:mdna:20]

[0000320193-26-000006:mdna:24]
Greater China net sales increased during the first quarter of 2026 compared to the same quarter in 2025 due to higher net sales of iPhone.

[0000320193-26-000006:mdna:25]
[same as prior period, unchanged from 0000320193-25-000073:mdna:22]

[0000320193-26-000006:mdna:26]
Japan net sales increased during the first quarter of 2026 compared to the same quarter in 2025 primarily due to higher net sales of iPhone and iPad. The weakness in the yen relative to the U.S. dollar had an unfavorable year-over-year impact on Japan net sales during the first quarter of 2026.

[0000320193-26-000006:mdna:27]
[same as prior period, unchanged from 0000320193-25-000073:mdna:24]

[0000320193-26-000006:mdna:28]
Rest of Asia Pacific net sales increased during the first quarter of 2026 compared to the same quarter in 2025 primarily due to higher net sales of iPhone and Services.

[0000320193-26-000006:mdna:29]
[same as prior period, unchanged from 0000320193-25-000073:mdna:26]

[0000320193-26-000006:mdna:30]
The following table shows net sales by category for the three months ended December 27, 2025 and December 28, 2024 (dollars in millions):

[0000320193-26-000006:mdna:31]
|  | Three Months Ended |  |  |
|  | December 27,2025 |  | December 28,2024 |  | Change |  |  |  |  |  |  |
| iPhone | $ | 85,269 |  |  | $ | 69,138 |  |  | 23 | % |  |  |  |  |  |  |
| Mac | 8,386 |  |  | 8,987 |  |  | (7) | % |  |  |  |  |  |  |
| iPad | 8,595 |  |  | 8,088 |  |  | 6 | % |  |  |  |  |  |  |
| Wearables, Home and Accessories | 11,493 |  |  | 11,747 |  |  | (2) | % |  |  |  |  |  |  |
| Services | 30,013 |  |  | 26,340 |  |  | 14 | % |  |  |  |  |  |  |
| Total net sales | $ | 143,756 |  |  | $ | 124,300 |  |  | 16 | % |  |  |  |  |  |  |

[0000320193-26-000006:mdna:32]
[same as prior period, unchanged from 0000320193-25-000073:mdna:29]

[0000320193-26-000006:mdna:33]
iPhone net sales increased during the first quarter of 2026 compared to the same quarter in 2025 due to higher net sales of Pro models.

[0000320193-26-000006:mdna:34]
[same as prior period, unchanged from 0000320193-25-000073:mdna:31]

[0000320193-26-000006:mdna:35]
Mac net sales decreased during the first quarter of 2026 compared to the same quarter in 2025 primarily due to lower net sales of laptops and desktops.

[0000320193-26-000006:mdna:36]
[same as prior period, unchanged from 0000320193-25-000073:mdna:33]

[0000320193-26-000006:mdna:37]
iPad net sales increased during the first quarter of 2026 compared to the same quarter in 2025 primarily due to higher net sales of iPad and iPad Pro, partially offset by lower net sales of iPad mini®.

[0000320193-26-000006:mdna:38]
[same as prior period, unchanged from 0000320193-25-000073:mdna:35]

[0000320193-26-000006:mdna:39]
Wearables, Home and Accessories net sales decreased during the first quarter of 2026 compared to the same quarter in 2025 primarily due to lower net sales of Wearables.

[0000320193-26-000006:mdna:40]
[same as prior period, unchanged from 0000320193-25-000073:mdna:37]

[0000320193-26-000006:mdna:41]
Services net sales increased during the first quarter of 2026 compared to the same quarter in 2025 primarily due to higher net sales from advertising, the App Store® and cloud services.

[0000320193-26-000006:mdna:42]
[same as prior period, unchanged from 0000320193-25-000073:mdna:39]

[0000320193-26-000006:mdna:43]
Products and Services gross margin and gross margin percentage for the three months ended December 27, 2025 and December 28, 2024, were as follows (dollars in millions):

[0000320193-26-000006:mdna:44]
|  | Three Months Ended |  |  |
|  | December 27,2025 |  | December 28,2024 |  |  |  |  |
| Gross margin: |  |  |  |  |  |  |  |
| Products | $ | 46,265 |  |  | $ | 38,513 |  |  |  |  |  |
| Services | 22,966 |  |  | 19,762 |  |  |  |  |  |
| Total gross margin | $ | 69,231 |  |  | $ | 58,275 |  |  |  |  |  |

[0000320193-26-000006:mdna:45]
| Gross margin percentage: |  |  |  |  |  |  |  |
| Products | 40.7 | % |  | 39.3 | % |  |  |  |  |
| Services | 76.5 | % |  | 75.0 | % |  |  |  |  |
| Total gross margin percentage | 48.2 | % |  | 46.9 | % |  |  |  |  |

[0000320193-26-000006:mdna:46]
[same as prior period, unchanged from 0000320193-25-000073:mdna:43]

[0000320193-26-000006:mdna:47]
Products gross margin and gross margin percentage increased during the first quarter of 2026 compared to the same quarter in 2025 primarily due to a different mix of products, partially offset by tariff costs.

[0000320193-26-000006:mdna:48]
[same as prior period, unchanged from 0000320193-25-000073:mdna:46]

[0000320193-26-000006:mdna:49]
Services gross margin increased during the first quarter of 2026 compared to the same quarter in 2025 primarily due to higher Services net sales and a different mix of services.

[0000320193-26-000006:mdna:50]
Services gross margin percentage increased during the first quarter of 2026 compared to the same quarter in 2025 primarily due to a different mix of services, partially offset by higher costs.

[0000320193-26-000006:mdna:51]
The Company’s future gross margins can be impacted by a variety of factors, as discussed in Part I, Item 1A of the 2025 Form 10-K and Part II, Item 1A of this Form 10-Q, in each case under the heading “Risk Factors.” As a result, the Company believes, in general, gross margins will be subject to volatility and downward pressure.

[0000320193-26-000006:mdna:52]
[same as prior period, unchanged from 0000320193-25-000073:mdna:50]

[0000320193-26-000006:mdna:53]
Operating expenses for the three months ended December 27, 2025 and December 28, 2024, were as follows (dollars in millions):

[0000320193-26-000006:mdna:54]
|  | Three Months Ended |  |  |
|  | December 27,2025 |  | December 28,2024 |  | Change |  |  |  |  |  |  |
| Research and development | $ | 10,887 |  |  | $ | 8,268 |  |  | 32 | % |  |  |  |  |  |  |
| Percentage of total net sales | 8 | % |  | 7 | % |  |  |  |  |  |  |  |  |
| Selling, general and administrative | $ | 7,492 |  |  | $ | 7,175 |  |  | 4 | % |  |  |  |  |  |  |
| Percentage of total net sales | 5 | % |  | 6 | % |  |  |  |  |  |  |  |  |
| Total operating expenses | $ | 18,379 |  |  | $ | 15,443 |  |  | 19 | % |  |  |  |  |  |  |
| Percentage of total net sales | 13 | % |  | 12 | % |  |  |  |  |  |  |  |  |

[0000320193-26-000006:mdna:55]
[same as prior period, unchanged from 0000320193-25-000073:mdna:53]

[0000320193-26-000006:mdna:56]
The growth in research and development (“R&D”) expense during the first quarter of 2026 compared to the same quarter in 2025 was primarily driven by increases in infrastructure-related costs, headcount-related expenses and engineering program costs.

[0000320193-26-000006:mdna:57]
[same as prior period, unchanged from 0000320193-25-000073:mdna:55]

[0000320193-26-000006:mdna:58]
The growth in selling, general and administrative expense during the first quarter of 2026 compared to the same quarter in 2025 was primarily driven by increases in headcount-related expenses and variable selling expenses.

[0000320193-26-000006:mdna:59]
[same as prior period, unchanged from 0000320193-25-000073:mdna:57]

[0000320193-26-000006:mdna:60]
Provision for income taxes, effective tax rate and statutory federal income tax rate for the three months ended December 27, 2025 and December 28, 2024, were as follows (dollars in millions):

[0000320193-26-000006:mdna:61]
|  | Three Months Ended |  |  |
|  | December 27,2025 |  | December 28,2024 |  |  |  |  |
| Provision for income taxes | $ | 8,905 |  |  | $ | 6,254 |  |  |  |  |  |
| Effective tax rate | 17.5 | % |  | 14.7 | % |  |  |  |  |
| Statutory federal income tax rate | 21 | % |  | 21 | % |  |  |  |  |

[0000320193-26-000006:mdna:62]
The Company’s effective tax rate for the first quarter of 2026 was lower than the statutory federal income tax rate primarily due to a lower effective tax rate on foreign earnings, the impact of the U.S. federal R&D credit, and tax benefits from share-based compensation, partially offset by state income taxes.

[0000320193-26-000006:mdna:63]
The Company’s effective tax rate for the first quarter of 2026 was higher compared to the first quarter of 2025 primarily due to the impact of foreign currency loss regulations issued by the U.S. Department of the Treasury in December 2024 and the tax impact from foreign currency revaluations in the first quarter of 2025 related to the State Aid Decision.

[0000320193-26-000006:mdna:64]
[same as prior period, unchanged from 0000320193-25-000073:mdna:62]

[0000320193-26-000006:mdna:65]
[same as prior period, unchanged from 0000320193-25-000073:mdna:63]

[0000320193-26-000006:mdna:66]
The Company’s contractual cash requirements have not changed materially since the 2025 Form 10-K, except for manufacturing purchase obligations and other purchase obligations.

[0000320193-26-000006:mdna:67]
[same as prior period, unchanged from 0000320193-25-000073:mdna:65]

[0000320193-26-000006:mdna:68]
The Company utilizes several outsourcing partners to manufacture subassemblies for the Company’s products and to perform final assembly and testing of finished products. The Company also obtains individual components for its products from a wide variety of individual suppliers. As of December 27, 2025, the Company had manufacturing purchase obligations of $44.4 billion, with $43.7 billion payable within 12 months.

[0000320193-26-000006:mdna:69]
Other Purchase Obligations

[0000320193-26-000006:mdna:70]
The Company’s other purchase obligations primarily consist of noncancelable obligations related to supplier arrangements, licensed intellectual property and content, distribution rights, and the acquisition of capital assets related to product manufacturing. As of December 27, 2025, the Company had other purchase obligations of $35.1 billion, with $9.3 billion payable within 12 months.

[0000320193-26-000006:mdna:71]
[same as prior period, unchanged from 0000320193-25-000073:mdna:69]

[0000320193-26-000006:mdna:72]
In addition to its contractual cash requirements, the Company has an authorized share repurchase program. The program does not obligate the Company to acquire a minimum amount of shares. As of December 27, 2025, the Company’s quarterly cash dividend was $0.26 per share. The Company intends to increase its dividend on an annual basis, subject to declaration by the Board of Directors.

[0000320193-26-000006:mdna:73]
During the first quarter of 2026, the Company repurchased $25.0 billion of its common stock and paid dividends and dividend equivalents of $3.9 billion.

[0000320193-26-000006:mdna:74]
[same as prior period, unchanged from 0000320193-25-000073:mdna:72]

[0000320193-26-000006:mdna:75]
Internal-Use Software

[0000320193-26-000006:mdna:76]
In September 2025, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2025-06, Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software (“ASU 2025-06”), which modernizes the accounting for internal-use software. ASU 2025-06 removes all references to software development stages and requires capitalization of software costs when management has committed to the software project and it is probable the software will be completed and perform its intended use. ASU 2025-06 will be effective for the Company in its first quarter of 2029, and early adoption is permitted. The Company is currently evaluating the timing and method of its adoption of ASU 2025-06.

[0000320193-26-000006:mdna:77]
[same as prior period, unchanged from 0000320193-25-000073:mdna:73]

[0000320193-26-000006:mdna:78]
In November 2024, the FASB issued ASU No. 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses (“ASU 2024-03”) and in January 2025, the FASB issued ASU No. 2025-01, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date, which clarified the effective date of ASU 2024-03. ASU 2024-03 will require the Company to disclose the amounts of purchases of inventory, employee compensation, depreciation and intangible asset amortization, as applicable, included in certain expense captions in the Consolidated Statements of Operations, as well as qualitatively describe remaining amounts included in those captions. ASU 2024-03 will also require the Company to disclose both the amount and the Company’s definition of selling expenses. The Company will adopt ASU 2024-03 in its fourth quarter of 2028 using a prospective transition method.

[0000320193-26-000006:mdna:79]
[same as prior period, unchanged from 0000320193-25-000073:mdna:75]

[0000320193-26-000006:mdna:80]
In December 2023, the FASB issued ASU No. 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures (“ASU 2023-09”), which will require the Company to disclose specified additional information in its income tax rate reconciliation and provide additional information for reconciling items that meet a quantitative threshold. ASU 2023-09 will also require the Company to disaggregate its income taxes paid disclosure by federal, state and foreign taxes, with further disaggregation required for significant individual jurisdictions. The Company will adopt ASU 2023-09 in its fourth quarter of 2026 using a prospective transition method.

[0000320193-26-000006:mdna:81]
[same as prior period, unchanged from 0000320193-25-000073:mdna:79]

[0000320193-26-000006:mdna:82]
The preparation of financial statements and related disclosures in conformity with GAAP and the Company’s discussion and analysis of its financial condition and operating results require the Company’s management to make judgments, assumptions and estimates that affect the amounts reported. Note 1, “Summary of Significant Accounting Policies” of the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Form 10-Q and in the Notes to Consolidated Financial Statements in Part II, Item 8 of the 2025 Form 10-K describe the significant accounting policies and methods used in the preparation of the Company’s condensed consolidated financial statements. There have been no material changes to the Company’s critical accounting estimates since the 2025 Form 10-K.
