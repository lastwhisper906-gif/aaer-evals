# AAPL note change history — 0000320193-25-000073 → 0000320193-26-000006


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: no_prior_note, score: 0.0

- added (2026-01-30):
[0000320193-26-000006:note_history:1]
Commitments and Contingencies
Unconditional Purchase Obligations

- added (2026-01-30):
[0000320193-26-000006:note_history:2]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of supplier arrangements, licensed intellectual property and content, and distribution rights. Future payments under unconditional purchase obligations with a remaining term in excess of one year as of December 27, 2025, are as follows (in millions):

- added (2026-01-30):
[0000320193-26-000006:note_history:3]
| 2026 (remaining nine months) | $ | 4,754 |  |
| 2027 | 8,066 |  |
| 2028 | 7,005 |  |
| 2029 | 6,538 |  |
| 2030 | 5,992 |  |
| Thereafter | 827 |  |
| Total | $ | 33,182 |  |

- added (2026-01-30):
[0000320193-26-000006:note_history:4]
Contingencies

- added (2026-01-30):
[0000320193-26-000006:note_history:5]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully resolved. The outcome of litigation is inherently uncertain. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss greater than a recorded accrual, concerning loss contingencies for asserted legal and other claims.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-01-30):
[0000320193-26-000006:note_history:6]
The Company issues unsecured short-term promissory notes pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of December 27, 2025 and September 27, 2025, the Company had $2.0 billion and $8.0 billion of commercial paper outstanding, respectively. The following table provides a summary of cash flows associated with commercial paper for the three months ended December 27, 2025 and December 28, 2024 (in millions):
  (was, 2025-08-01, similarity 0.9112):
[0000320193-25-000073:note_history:6]
The Company issues unsecured short-term promissory notes pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of June 28, 2025 and September 28, 2024, the Company had $9.9 billion and $10.0 billion of commercial paper outstanding, respectively. The following table provides a summary of cash flows associated with commercial paper for the nine months ended June 28, 2025 and June 29, 2024 (in millions):

- added (2026-01-30):
[0000320193-26-000006:note_history:7]
|  | Three Months Ended |
|  | December 27,2025 |  | December 28,2024 |
| Maturities 90 days or less: |  |  |  |
| Repayments of commercial paper, net | $ | (2,122) |  |  | $ | (7,944) |  |
| Maturities greater than 90 days: |  |  |  |
| Repayments of commercial paper | (3,788) |  |  | — |  |
| Total repayments of commercial paper, net | $ | (5,910) |  |  | $ | (7,944) |  |

- changed (2026-01-30):
[0000320193-26-000006:note_history:8]
As of December 27, 2025 and September 27, 2025, the Company had outstanding fixed-rate notes with varying maturities for an aggregate carrying amount of $88.5 billion and $90.7 billion, respectively (collectively the “Notes”). As of December 27, 2025 and September 27, 2025, the fair value of the Company’s Notes, based on Level 2 inputs, was $78.1 billion and $80.4 billion, respectively.
  (was, 2025-08-01, similarity 0.9658):
[0000320193-25-000073:note_history:8]
As of June 28, 2025 and September 28, 2024, the Company had outstanding fixed-rate notes with varying maturities for an aggregate carrying amount of $91.8 billion and $96.7 billion, respectively (collectively the “Notes”). As of June 28, 2025 and September 28, 2024, the fair value of the Company’s Notes, based on Level 2 inputs, was $80.4 billion and $88.4 billion, respectively.

- removed (2026-01-30):
[0000320193-25-000073:note_history:9]
|  | Nine Months Ended |
|  | June 28,2025 |  | June 29,2024 |
| Maturities 90 days or less: |  |  |  |
| Repayments of commercial paper, net | $ | (5,690) |  |  | $ | (2,985) |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 5,625 |  |  | — |  |
| Total repayments of commercial paper, net | $ | (65) |  |  | $ | (2,985) |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-01-30):
[0000320193-26-000006:note_history:10]
Revenue
The following table shows disaggregated net sales, as well as the portion of total net sales that was previously deferred, for the three months ended December 27, 2025 and December 28, 2024 (in millions):
  (was, 2025-08-01, similarity 0.8136):
[0000320193-25-000073:note_history:10]
Revenue
The following table shows disaggregated net sales, as well as the portion of total net sales that was previously deferred, for the three- and nine-month periods ended June 28, 2025 and June 29, 2024 (in millions):

- changed (2026-01-30):
[0000320193-26-000006:note_history:11]
|  | Three Months Ended |  |  |
|  | December 27,2025 |  | December 28,2024 |  |  |  |  |
| iPhone® | $ | 85,269 |  |  | $ | 69,138 |  |  |  |  |  |
| Mac® | 8,386 |  |  | 8,987 |  |  |  |  |  |
| iPad® | 8,595 |  |  | 8,088 |  |  |  |  |  |
| Wearables, Home and Accessories | 11,493 |  |  | 11,747 |  |  |  |  |  |
| Services | 30,013 |  |  | 26,340 |  |  |  |  |  |
| Total net sales | $ | 143,756 |  |  | $ | 124,300 |  |  |  |  |  |
| Portion of total net sales that was included in deferred revenue as of the beginning of the period | $ | 4,050 |  |  | $ | 3,690 |  |  |  |  |  |
  (was, 2025-08-01, similarity 0.7984):
[0000320193-25-000073:note_history:11]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 28,2025 |  | June 29,2024 |  | June 28,2025 |  | June 29,2024 |
| iPhone® | $ | 44,582 |  |  | $ | 39,296 |  |  | $ | 160,561 |  |  | $ | 154,961 |  |
| Mac® | 8,046 |  |  | 7,009 |  |  | 24,982 |  |  | 22,240 |  |
| iPad® | 6,581 |  |  | 7,162 |  |  | 21,071 |  |  | 19,744 |  |
| Wearables, Home and Accessories | 7,404 |  |  | 8,097 |  |  | 26,673 |  |  | 27,963 |  |
| Services | 27,423 |  |  | 24,213 |  |  | 80,408 |  |  | 71,197 |  |
| Total net sales | $ | 94,036 |  |  | $ | 85,777 |  |  | $ | 313,695 |  |  | $ | 296,105 |  |
| Portion of total net sales that was included in deferred revenue as of the beginning of the period | $ | 4,015 |  |  | $ | 3,405 |  |  | $ | 6,958 |  |  | $ | 6,541 |  |

- changed (2026-01-30):
[0000320193-26-000006:note_history:12]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 10, “Segment Information” for the three months ended December 27, 2025 and December 28, 2024, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.
  (was, 2025-08-01, similarity 0.8371):
[0000320193-25-000073:note_history:12]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 10, “Segment Information and Geographic Data” for the three- and nine-month periods ended June 28, 2025 and June 29, 2024, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.

- added (2026-01-30):
[0000320193-26-000006:note_history:13]
As of December 27, 2025 and September 27, 2025, the Company had total deferred revenue of $14.3 billion and $13.7 billion, respectively. As of December 27, 2025, the Company expects 66% of total deferred revenue to be realized in less than a year, 23% within one-to-two years, 9% within two-to-three years and 2% in greater than three years.

- removed (2026-01-30):
[0000320193-25-000073:note_history:14]
As of June 28, 2025 and September 28, 2024, the Company had total deferred revenue of $13.6 billion and $12.8 billion, respectively. As of June 28, 2025, the Company expects 66% of total deferred revenue to be realized in less than a year, 23% within one-to-two years, 9% within two-to-three years and 2% in greater than three years.
