# AAPL note change history — 0000320193-21-000010 → 0000320193-21-000056


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-04-29):
[0000320193-21-000056:note_history:1]
The following table shows changes in the Company’s accrued warranties and related costs for the three- and six-month periods ended March 27, 2021 and March 28, 2020 (in millions):
  (was, 2021-01-28, similarity 0.8963):
[0000320193-21-000010:note_history:1]
The following table shows changes in the Company’s accrued warranties and related costs for the three months ended December 26, 2020 and December 28, 2019 (in millions):

- changed (2021-04-29):
[0000320193-21-000056:note_history:2]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27,2021 |  | March 28,2020 |  | March 27,2021 |  | March 28,2020 |
| Beginning accrued warranty and related costs | $ | 4,124 |  |  | $ | 3,873 |  |  | $ | 3,354 |  |  | $ | 3,570 |  |
| Cost of warranty claims | (649) |  |  | (689) |  |  | (1,372) |  |  | (1,604) |  |
| Accruals for product warranty | 309 |  |  | 739 |  |  | 1,802 |  |  | 1,957 |  |
| Ending accrued warranty and related costs | $ | 3,784 |  |  | $ | 3,923 |  |  | $ | 3,784 |  |  | $ | 3,923 |  |
  (was, 2021-01-28, similarity 0.7732):
[0000320193-21-000010:note_history:2]
|  | Three Months Ended |  |  |
|  | December 26,2020 |  | December 28,2019 |  |  |  |  |
| Beginning accrued warranty and related costs | $ | 3,354 |  |  | $ | 3,570 |  |  |  |  |  |
| Cost of warranty claims | (723) |  |  | (915) |  |  |  |  |  |
| Accruals for product warranty | 1,493 |  |  | 1,218 |  |  |  |  |  |
| Ending accrued warranty and related costs | $ | 4,124 |  |  | $ | 3,873 |  |  |  |  |  |

- changed (2021-04-29):
[0000320193-21-000056:note_history:3]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of payments for content creation, Internet and telecommunications services and supplier arrangements. As of March 27, 2021, the Company’s total future payments under noncancelable unconditional purchase obligations having a remaining term in excess of one year were $8.2 billion.
  (was, 2021-01-28, similarity 0.987):
[0000320193-21-000010:note_history:3]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of payments for content creation, Internet and telecommunications services and supplier arrangements. As of December 26, 2020, the Company’s total future payments under noncancelable unconditional purchase obligations having a remaining term in excess of one year were $8.1 billion.

- changed (2021-04-29):
[0000320193-21-000056:note_history:4]
VirnetX, Inc. (“VirnetX”) filed a lawsuit against the Company alleging that certain of the Company’s products infringe on patents owned by VirnetX. On April 11, 2018, a jury returned a verdict against the Company in the U.S. District Court for the Eastern District of Texas (the “Eastern Texas District Court”). The Company appealed the verdict to the U.S. Court of Appeals for the Federal Circuit, which remanded the case back to the Eastern Texas District Court, where a re-trial was held in October 2020. The jury returned a verdict against the Company and awarded damages of $503 million, which the Company has appealed. The Company has challenged the validity of the patents at issue in the re-trial at the U.S. Patent and Trademark Office (the “PTO”), and the PTO has declared the patents invalid, subject to further appeal by VirnetX.
  (was, 2021-01-28, similarity 0.9826):
[0000320193-21-000010:note_history:4]
VirnetX, Inc. (“VirnetX”) filed a lawsuit against the Company alleging that certain of the Company’s products infringe on patents owned by VirnetX. On April 11, 2018, a jury returned a verdict against the Company in the U.S. District Court for the Eastern District of Texas (the “Eastern Texas District Court”). The Company appealed the verdict to the U.S. Court of Appeals for the Federal Circuit, which remanded the case back to the Eastern Texas District Court, where a re-trial was held in October 2020. The jury returned a verdict against the Company and awarded damages of $503 million, which the Company intends to appeal. The Company has challenged the validity of the patents at issue in the re-trial at the U.S. Patent and Trademark Office (the “PTO”), and the PTO has declared the patents invalid, subject to further appeal by VirnetX.

- added (2021-04-29):
[0000320193-21-000056:note_history:5]
On April 5, 2018, several U.S. federal actions alleging violation of consumer protection laws, fraud, computer intrusion and other causes of action related to the Company’s performance management feature used in its iPhone operating systems, introduced to certain iPhones in iOS updates 10.2.1 and 11.2, were consolidated through a Multidistrict Litigation process into a single action in the U.S. District Court for the Northern District of California (the “Northern California District Court”). On February 28, 2020, the parties in the Multidistrict Litigation reached a settlement to resolve the U.S. federal and California state class actions. On March 18, 2021, the Northern California District Court granted final approval of the Multidistrict Litigation settlement, which will result in an aggregate payment of $310 million to settle all claims. The Company continues to believe that its iPhones were not defective, that the performance management feature introduced with iOS updates 10.2.1 and 11.2 was intended to, and did, improve customers’ user experience, and that the Company did not make any misleading statements or fail to disclose any material information.

- changed (2021-04-29):
[0000320193-21-000056:note_history:6]
Optis Wireless Technology, LLC and related entities (“Optis”) filed a lawsuit in the U.S. District Court for the Eastern District of Texas against the Company alleging that certain of the Company’s products infringe on patents owned by Optis. On August 11, 2020, a jury returned a verdict against the Company and awarded damages of $506 million. In post-trial proceedings, the damages portion of the verdict was set aside, and the case remains pending further proceedings.
  (was, 2021-01-28, similarity 0.7677):
[0000320193-21-000010:note_history:6]
Optis Wireless Technology, LLC and related entities (“Optis”) filed a lawsuit in the U.S. District Court for the Eastern District of Texas against the Company alleging that certain of the Company’s products infringe on patents owned by Optis. On August 11, 2020, a jury returned a verdict against the Company and awarded damages of $506 million. The Company has asked the court to set aside the verdict, where the case remains pending.

- removed (2021-04-29):
[0000320193-21-000010:note_history:7]
Various civil litigation matters have been filed in state and federal courts in the U.S. and in various international jurisdictions alleging violation of consumer protection laws, fraud, computer intrusion and other causes of action related to the Company’s performance management feature used in its iPhone operating systems, introduced to certain iPhones in iOS updates 10.2.1 and 11.2. The claims seek monetary damages and other non-monetary relief. On April 5, 2018, several U.S. federal actions were consolidated through a Multidistrict Litigation process into a single action in the U.S. District Court for the Northern District of California (the “Northern California District Court”). On February 28, 2020, the parties in the Multidistrict Litigation reached a settlement to resolve the U.S. federal and California state class actions. Under the terms of the settlement, which the Northern California District Court preliminarily approved in May 2020, the Company has agreed to pay up to $500 million in the aggregate to certain U.S. owners of iPhones if certain conditions are met. The final amount of the settlement will be determined based on the number of consumers who file valid claims and the attorneys’ fee award. However, the Company has agreed to pay at least $310 million to settle the claims. In addition to civil litigation, the Company is also responding to governmental investigations and requests for information relating to the performance management feature. On November 18, 2020, the Company reached a settlement with a multi-state group of attorneys general. Under the terms of the settlement, the Company has agreed to pay an aggregate amount of $113 million to resolve civil, statutory claims. The Company continues to believe that its iPhones were not defective, that the performance management feature introduced with iOS updates 10.2.1 and 11.2 was intended to, and did, improve customers’ user experience, and that the Company did not make any misleading statements or fail to disclose any material information.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-04-29):
[0000320193-21-000056:note_history:8]
The following table shows the computation of basic and diluted earnings per share for the three- and six-month periods ended March 27, 2021 and March 28, 2020 (net income in millions and shares in thousands):
  (was, 2021-01-28, similarity 0.9119):
[0000320193-21-000010:note_history:8]
The following table shows the computation of basic and diluted earnings per share for the three months ended December 26, 2020 and December 28, 2019 (net income in millions and shares in thousands):

- changed (2021-04-29):
[0000320193-21-000056:note_history:9]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27,2021 |  | March 28,2020 |  | March 27,2021 |  | March 28,2020 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 23,630 |  |  | $ | 11,249 |  |  | $ | 52,385 |  |  | $ | 33,485 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 16,753,476 |  |  | 17,440,402 |  |  | 16,844,298 |  |  | 17,550,281 |  |
| Effect of dilutive securities | 175,681 |  |  | 178,363 |  |  | 177,125 |  |  | 168,310 |  |
| Weighted-average diluted shares | 16,929,157 |  |  | 17,618,765 |  |  | 17,021,423 |  |  | 17,718,591 |  |
| Basic earnings per share | $ | 1.41 |  |  | $ | 0.64 |  |  | $ | 3.11 |  |  | $ | 1.91 |  |
| Diluted earnings per share | $ | 1.40 |  |  | $ | 0.64 |  |  | $ | 3.08 |  |  | $ | 1.89 |  |
  (was, 2021-01-28, similarity 0.8122):
[0000320193-21-000010:note_history:9]
|  | Three Months Ended |  |  |
|  | December 26,2020 |  | December 28,2019 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 28,755 |  |  | $ | 22,236 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 16,935,119 |  |  | 17,660,160 |  |  |  |  |  |
| Effect of dilutive securities | 178,569 |  |  | 158,257 |  |  |  |  |  |
| Weighted-average diluted shares | 17,113,688 |  |  | 17,818,417 |  |  |  |  |  |
| Basic earnings per share | $ | 1.70 |  |  | $ | 1.26 |  |  |  |  |  |
| Diluted earnings per share | $ | 1.68 |  |  | $ | 1.25 |  |  |  |  |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-04-29):
[0000320193-21-000056:note_history:10]
Debt
Commercial Paper and Repurchase Agreement
  (was, 2021-01-28, similarity 0.6269):
[0000320193-21-000010:note_history:10]
Debt
Commercial Paper

- changed (2021-04-29):
[0000320193-21-000056:note_history:11]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of both March 27, 2021 and September 26, 2020, the Company had $5.0 billion of Commercial Paper outstanding, with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 0.06% and 0.62% as of March 27, 2021 and September 26, 2020, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the six months ended March 27, 2021 and March 28, 2020 (in millions):
  (was, 2021-01-28, similarity 0.9267):
[0000320193-21-000010:note_history:11]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of both December 26, 2020 and September 26, 2020, the Company had $5.0 billion of Commercial Paper outstanding, with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 0.10% and 0.62% as of December 26, 2020 and September 26, 2020, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the three months ended December 26, 2020 and December 28, 2019 (in millions):

- added (2021-04-29):
[0000320193-21-000056:note_history:12]
|  | Six Months Ended |
|  | March 27,2021 |  | March 28,2020 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from commercial paper, net | $ | 2,008 |  |  | $ | 1,377 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 1,368 |  |  | 4,797 |  |
| Repayments of commercial paper | (3,354) |  |  | (4,656) |  |
| Proceeds from/(Repayments of) commercial paper, net | (1,986) |  |  | 141 |  |
| Total proceeds from commercial paper, net | $ | 22 |  |  | $ | 1,518 |  |

- added (2021-04-29):
[0000320193-21-000056:note_history:13]
In the second quarter of 2020, the Company entered into an agreement to sell certain of its marketable securities with a promise to repurchase the securities at a specified time and amount (“Repo”). Due to the Company’s continuing involvement with the marketable securities, the Company accounted for the Repo as a collateralized borrowing. As of September 26, 2020, the Repo had been settled.

- changed (2021-04-29):
[0000320193-21-000056:note_history:14]
As of March 27, 2021, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $116.0 billion (collectively the “Notes”). The Notes are senior unsecured obligations and interest is payable in arrears. The following table provides a summary of the Company’s term debt as of March 27, 2021 and September 26, 2020:
  (was, 2021-01-28, similarity 0.9636):
[0000320193-21-000010:note_history:14]
As of December 26, 2020, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $105.9 billion (collectively the “Notes”). The Notes are senior unsecured obligations and interest is payable in arrears. The following table provides a summary of the Company’s term debt as of December 26, 2020 and September 26, 2020:

- changed (2021-04-29):
[0000320193-21-000056:note_history:15]
|  | Maturities(calendar year) |  | March 27, 2021 |  | September 26, 2020 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 – 2020 debt issuances: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2022 |  | $ | 1,750 |  |  | 0.55% – 0.69% |  | $ | 2,250 |  |  | 0.60% – 1.39% |
| Fixed-rate 0.000% – 4.650% notes | 2021 – 2060 |  | 100,255 |  |  | 0.03% – 4.78% |  | 103,828 |  |  | 0.03% – 4.78% |
| 2021 debt issuance: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.700% – 2.800% notes | 2026 – 2061 |  | 14,000 |  |  | 0.75% – 2.81% |  | — |  |  | — | % |
| Total term debt |  |  | 116,005 |  |  |  |  | 106,078 |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  | (371) |  |  |  |  | (314) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 1,011 |  |  |  |  | 1,676 |  |  |  |
| Less: Current portion of term debt |  |  | (8,003) |  |  |  |  | (8,773) |  |  |  |
| Total non-current portion of term debt |  |  | $ | 108,642 |  |  |  |  | $ | 98,667 |  |  |  |
  (was, 2021-01-28, similarity 0.9155):
[0000320193-21-000010:note_history:15]
|  | Maturities(calendar year) |  | December 26, 2020 |  | September 26, 2020 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 – 2020 debt issuances: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2021 – 2022 |  | $ | 2,250 |  |  | 0.56% – 1.34% |  | $ | 2,250 |  |  | 0.60% – 1.39% |
| Fixed-rate 0.000% – 4.650% notes | 2021 – 2060 |  | 103,613 |  |  | 0.03% – 4.78% |  | 103,828 |  |  | 0.03% – 4.78% |
| Total term debt |  |  | 105,863 |  |  |  |  | 106,078 |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  | (305) |  |  |  |  | (314) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 1,485 |  |  |  |  | 1,676 |  |  |  |
| Less: Current portion of term debt |  |  | (7,762) |  |  |  |  | (8,773) |  |  |  |
| Total non-current portion of term debt |  |  | $ | 99,281 |  |  |  |  | $ | 98,667 |  |  |  |

- added (2021-04-29):
[0000320193-21-000056:note_history:16]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $657 million and $1.3 billion of interest cost on its term debt for the three- and six-month periods ended March 27, 2021, respectively. The Company recognized $725 million and $1.5 billion of interest cost on its term debt for the three- and six-month periods ended March 28, 2020, respectively.

- changed (2021-04-29):
[0000320193-21-000056:note_history:17]
As of March 27, 2021 and September 26, 2020, the fair value of the Company’s Notes, based on Level 2 inputs, was $121.2 billion and $117.1 billion, respectively.
  (was, 2021-01-28, similarity 0.9686):
[0000320193-21-000010:note_history:17]
As of December 26, 2020 and September 26, 2020, the fair value of the Company’s Notes, based on Level 2 inputs, was $117.2 billion and $117.1 billion, respectively.

- removed (2021-04-29):
[0000320193-21-000010:note_history:18]
|  | Three Months Ended |
|  | December 26,2020 |  | December 28,2019 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | 1,439 |  |  | $ | (175) |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 780 |  |  | 1,317 |  |
| Repayments of commercial paper | (2,197) |  |  | (2,121) |  |
| Repayments of commercial paper, net | (1,417) |  |  | (804) |  |
| Total proceeds from/(repayments of) commercial paper, net | $ | 22 |  |  | $ | (979) |  |

- removed (2021-04-29):
[0000320193-21-000010:note_history:19]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $628 million and $757 million of interest cost on its term debt for the three months ended December 26, 2020 and December 28, 2019, respectively.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-04-29):
[0000320193-21-000056:note_history:20]
The following table provides a summary of the Company’s term debt as of March 27, 2021 and September 26, 2020:
  (was, 2021-01-28, similarity 0.9557):
[0000320193-21-000010:note_history:20]
The following table provides a summary of the Company’s term debt as of December 26, 2020 and September 26, 2020:

- changed (2021-04-29):
[0000320193-21-000056:note_history:21]
|  | Maturities(calendar year) |  | March 27, 2021 |  | September 26, 2020 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 – 2020 debt issuances: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2022 |  | $ | 1,750 |  |  | 0.55% – 0.69% |  | $ | 2,250 |  |  | 0.60% – 1.39% |
| Fixed-rate 0.000% – 4.650% notes | 2021 – 2060 |  | 100,255 |  |  | 0.03% – 4.78% |  | 103,828 |  |  | 0.03% – 4.78% |
| 2021 debt issuance: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.700% – 2.800% notes | 2026 – 2061 |  | 14,000 |  |  | 0.75% – 2.81% |  | — |  |  | — | % |
| Total term debt |  |  | 116,005 |  |  |  |  | 106,078 |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  | (371) |  |  |  |  | (314) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 1,011 |  |  |  |  | 1,676 |  |  |  |
| Less: Current portion of term debt |  |  | (8,003) |  |  |  |  | (8,773) |  |  |  |
| Total non-current portion of term debt |  |  | $ | 108,642 |  |  |  |  | $ | 98,667 |  |  |  |
  (was, 2021-01-28, similarity 0.9155):
[0000320193-21-000010:note_history:21]
|  | Maturities(calendar year) |  | December 26, 2020 |  | September 26, 2020 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 – 2020 debt issuances: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2021 – 2022 |  | $ | 2,250 |  |  | 0.56% – 1.34% |  | $ | 2,250 |  |  | 0.60% – 1.39% |
| Fixed-rate 0.000% – 4.650% notes | 2021 – 2060 |  | 103,613 |  |  | 0.03% – 4.78% |  | 103,828 |  |  | 0.03% – 4.78% |
| Total term debt |  |  | 105,863 |  |  |  |  | 106,078 |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  | (305) |  |  |  |  | (314) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 1,485 |  |  |  |  | 1,676 |  |  |  |
| Less: Current portion of term debt |  |  | (7,762) |  |  |  |  | (8,773) |  |  |  |
| Total non-current portion of term debt |  |  | $ | 99,281 |  |  |  |  | $ | 98,667 |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-04-29):
[0000320193-21-000056:note_history:22]
Net sales disaggregated by significant products and services for the three- and six-month periods ended March 27, 2021 and March 28, 2020 were as follows (in millions):
  (was, 2021-01-28, similarity 0.8889):
[0000320193-21-000010:note_history:22]
Net sales disaggregated by significant products and services for the three months ended December 26, 2020 and December 28, 2019 were as follows (in millions):

- changed (2021-04-29):
[0000320193-21-000056:note_history:23]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27,2021 |  | March 28,2020 |  | March 27,2021 |  | March 28,2020 |
| iPhone (1) | $ | 47,938 |  |  | $ | 28,962 |  |  | $ | 113,535 |  |  | $ | 84,919 |  |
| Mac (1) | 9,102 |  |  | 5,351 |  |  | 17,777 |  |  | 12,511 |  |
| iPad (1) | 7,807 |  |  | 4,368 |  |  | 16,242 |  |  | 10,345 |  |
| Wearables, Home and Accessories (1)(2) | 7,836 |  |  | 6,284 |  |  | 20,807 |  |  | 16,294 |  |
| Services (3) | 16,901 |  |  | 13,348 |  |  | 32,662 |  |  | 26,063 |  |
| Total net sales (4) | $ | 89,584 |  |  | $ | 58,313 |  |  | $ | 201,023 |  |  | $ | 150,132 |  |
  (was, 2021-01-28, similarity 0.6693):
[0000320193-21-000010:note_history:23]
|  | Three Months Ended |  |  |
|  | December 26,2020 |  | December 28,2019 |  |  |  |  |
| iPhone (1) | $ | 65,597 |  |  | $ | 55,957 |  |  |  |  |  |
| Mac (1) | 8,675 |  |  | 7,160 |  |  |  |  |  |
| iPad (1) | 8,435 |  |  | 5,977 |  |  |  |  |  |
| Wearables, Home and Accessories (1)(2) | 12,971 |  |  | 10,010 |  |  |  |  |  |
| Services (3) | 15,761 |  |  | 12,715 |  |  |  |  |  |
| Total net sales (4) | $ | 111,439 |  |  | $ | 91,819 |  |  |  |  |  |

- changed (2021-04-29):
[0000320193-21-000056:note_history:24]
(4)Includes $2.7 billion of revenue recognized in the three months ended March 27, 2021 that was included in deferred revenue as of December 26, 2020, $1.9 billion of revenue recognized in the three months ended March 28, 2020 that was included in deferred revenue as of December 28, 2019, $4.1 billion of revenue recognized in the six months ended March 27, 2021 that was included in deferred revenue as of September 26, 2020, and $3.0 billion of revenue recognized in the six months ended March 28, 2020 that was included in deferred revenue as of September 28, 2019.
  (was, 2021-01-28, similarity 0.6111):
[0000320193-21-000010:note_history:24]
(4)Includes $2.5 billion of revenue recognized in the three months ended December 26, 2020 that was included in deferred revenue as of September 26, 2020 and $1.9 billion of revenue recognized in the three months ended December 28, 2019 that was included in deferred revenue as of September 28, 2019.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-04-29):
[0000320193-21-000056:note_history:25]
As of March 27, 2021 and September 26, 2020, the Company had total deferred revenue of $11.9 billion and $10.2 billion, respectively. As of March 27, 2021, the Company expects 64% of total deferred revenue to be realized in less than a year, 26% within one-to-two years, 8% within two-to-three years and 2% in greater than three years.
  (was, 2021-01-28, similarity 0.9585):
[0000320193-21-000010:note_history:25]
As of December 26, 2020 and September 26, 2020, the Company had total deferred revenue of $11.6 billion and $10.2 billion, respectively. As of December 26, 2020, the Company expects 64% of total deferred revenue to be realized in less than a year, 26% within one-to-two years, 8% within two-to-three years and 2% in greater than three years.

- changed (2021-04-29):
[0000320193-21-000056:note_history:26]
Net sales disaggregated by significant products and services for the three- and six-month periods ended March 27, 2021 and March 28, 2020 were as follows (in millions):
  (was, 2021-01-28, similarity 0.8889):
[0000320193-21-000010:note_history:26]
Net sales disaggregated by significant products and services for the three months ended December 26, 2020 and December 28, 2019 were as follows (in millions):

- changed (2021-04-29):
[0000320193-21-000056:note_history:27]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27,2021 |  | March 28,2020 |  | March 27,2021 |  | March 28,2020 |
| iPhone (1) | $ | 47,938 |  |  | $ | 28,962 |  |  | $ | 113,535 |  |  | $ | 84,919 |  |
| Mac (1) | 9,102 |  |  | 5,351 |  |  | 17,777 |  |  | 12,511 |  |
| iPad (1) | 7,807 |  |  | 4,368 |  |  | 16,242 |  |  | 10,345 |  |
| Wearables, Home and Accessories (1)(2) | 7,836 |  |  | 6,284 |  |  | 20,807 |  |  | 16,294 |  |
| Services (3) | 16,901 |  |  | 13,348 |  |  | 32,662 |  |  | 26,063 |  |
| Total net sales (4) | $ | 89,584 |  |  | $ | 58,313 |  |  | $ | 201,023 |  |  | $ | 150,132 |  |
  (was, 2021-01-28, similarity 0.6693):
[0000320193-21-000010:note_history:27]
|  | Three Months Ended |  |  |
|  | December 26,2020 |  | December 28,2019 |  |  |  |  |
| iPhone (1) | $ | 65,597 |  |  | $ | 55,957 |  |  |  |  |  |
| Mac (1) | 8,675 |  |  | 7,160 |  |  |  |  |  |
| iPad (1) | 8,435 |  |  | 5,977 |  |  |  |  |  |
| Wearables, Home and Accessories (1)(2) | 12,971 |  |  | 10,010 |  |  |  |  |  |
| Services (3) | 15,761 |  |  | 12,715 |  |  |  |  |  |
| Total net sales (4) | $ | 111,439 |  |  | $ | 91,819 |  |  |  |  |  |

- changed (2021-04-29):
[0000320193-21-000056:note_history:28]
(4)Includes $2.7 billion of revenue recognized in the three months ended March 27, 2021 that was included in deferred revenue as of December 26, 2020, $1.9 billion of revenue recognized in the three months ended March 28, 2020 that was included in deferred revenue as of December 28, 2019, $4.1 billion of revenue recognized in the six months ended March 27, 2021 that was included in deferred revenue as of September 26, 2020, and $3.0 billion of revenue recognized in the six months ended March 28, 2020 that was included in deferred revenue as of September 28, 2019.
  (was, 2021-01-28, similarity 0.6111):
[0000320193-21-000010:note_history:28]
(4)Includes $2.5 billion of revenue recognized in the three months ended December 26, 2020 that was included in deferred revenue as of September 26, 2020 and $1.9 billion of revenue recognized in the three months ended December 28, 2019 that was included in deferred revenue as of September 28, 2019.

- changed (2021-04-29):
[0000320193-21-000056:note_history:29]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 11, “Segment Information and Geographic Data” for the three- and six-month periods ended March 27, 2021 and March 28, 2020.
  (was, 2021-01-28, similarity 0.7966):
[0000320193-21-000010:note_history:29]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 11, “Segment Information and Geographic Data” for the three months ended December 26, 2020 and December 28, 2019.
