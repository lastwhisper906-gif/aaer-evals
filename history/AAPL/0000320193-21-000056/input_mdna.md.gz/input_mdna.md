# AAPL MD&A — 0000320193-21-000056


## mdna

[0000320193-21-000056:mdna:1]
[same as prior period, unchanged from 0000320193-21-000010:mdna:1]

[0000320193-21-000056:mdna:2]
[same as prior period, unchanged from 0000320193-21-000010:mdna:2]

[0000320193-21-000056:mdna:3]
[same as prior period, unchanged from 0000320193-21-000010:mdna:3]

[0000320193-21-000056:mdna:4]
[same as prior period, unchanged from 0000320193-21-000010:mdna:4]

[0000320193-21-000056:mdna:5]
[same as prior period, unchanged from 0000320193-21-000010:mdna:5]

[0000320193-21-000056:mdna:6]
[same as prior period, unchanged from 0000320193-21-000010:mdna:6]

[0000320193-21-000056:mdna:7]
[same as prior period, unchanged from 0000320193-21-000010:mdna:7]

[0000320193-21-000056:mdna:8]
[same as prior period, unchanged from 0000320193-21-000010:mdna:8]

[0000320193-21-000056:mdna:9]
[same as prior period, unchanged from 0000320193-21-000010:mdna:9]

[0000320193-21-000056:mdna:10]
[same as prior period, unchanged from 0000320193-21-000010:mdna:10]

[0000320193-21-000056:mdna:11]
During the second quarter of 2021, aspects of the Company’s business continued to be affected by the COVID-19 pandemic, with many of the Company’s retail stores, as well as channel partner points of sale, temporarily closed at various times, and the vast majority of the Company’s employees working remotely. The Company has reopened some of its offices and retail stores, subject to operating restrictions to protect public health and the health and safety of employees and customers, and it continues to work on safely reopening the remainder of its offices and retail stores, subject to local rules and regulations.

[0000320193-21-000056:mdna:12]
[same as prior period, unchanged from 0000320193-21-000010:mdna:12]

[0000320193-21-000056:mdna:13]
[same as prior period, unchanged from 0000320193-21-000010:mdna:13]

[0000320193-21-000056:mdna:14]
Second Quarter Fiscal 2021 Highlights

[0000320193-21-000056:mdna:15]
Total net sales increased 54% or $31.3 billion during the second quarter of 2021 compared to the same quarter in 2020, driven by higher net sales in all Products and Services categories in each of the Company’s reportable segments. The COVID-19 pandemic had an unfavorable impact on the Company’s net sales during the second quarter of 2020.

[0000320193-21-000056:mdna:16]
The Company repurchased $19.0 billion of its common stock and paid dividends and dividend equivalents of $3.4 billion during the second quarter of 2021.

[0000320193-21-000056:mdna:17]
In April 2021, the Company announced the following new products and services, all of which are expected to be available in the spring of 2021:

[0000320193-21-000056:mdna:18]
•iMac®, powered by the Apple M1 chip;

[0000320193-21-000056:mdna:19]
•iPad Pro®, powered by the Apple M1 chip;

[0000320193-21-000056:mdna:20]
•Apple TV 4K®, with a redesigned Siri Remote®;

[0000320193-21-000056:mdna:21]
•AirTag™, an accessory that helps keep track of items using the Find My™ network; and

[0000320193-21-000056:mdna:22]
•Apple Podcasts® Subscriptions.

[0000320193-21-000056:mdna:23]
[same as prior period, unchanged from 0000320193-21-000010:mdna:23]

[0000320193-21-000056:mdna:24]
The following table shows net sales by category for the three- and six-month periods ended March 27, 2021 and March 28, 2020 (dollars in millions):

[0000320193-21-000056:mdna:25]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27,2021 |  | March 28,2020 |  | Change |  | March 27,2021 |  | March 28,2020 |  | Change |
| Net sales by category: |  |  |  |  |  |  |  |  |  |  |  |
| iPhone (1) | $ | 47,938 |  |  | $ | 28,962 |  |  | 66 | % |  | $ | 113,535 |  |  | $ | 84,919 |  |  | 34 | % |
| Mac (1) | 9,102 |  |  | 5,351 |  |  | 70 | % |  | 17,777 |  |  | 12,511 |  |  | 42 | % |
| iPad (1) | 7,807 |  |  | 4,368 |  |  | 79 | % |  | 16,242 |  |  | 10,345 |  |  | 57 | % |
| Wearables, Home and Accessories (1)(2) | 7,836 |  |  | 6,284 |  |  | 25 | % |  | 20,807 |  |  | 16,294 |  |  | 28 | % |
| Services (3) | 16,901 |  |  | 13,348 |  |  | 27 | % |  | 32,662 |  |  | 26,063 |  |  | 25 | % |
| Total net sales | $ | 89,584 |  |  | $ | 58,313 |  |  | 54 | % |  | $ | 201,023 |  |  | $ | 150,132 |  |  | 34 | % |

[0000320193-21-000056:mdna:26]
[same as prior period, unchanged from 0000320193-21-000010:mdna:26]

[0000320193-21-000056:mdna:27]
[same as prior period, unchanged from 0000320193-21-000010:mdna:27]

[0000320193-21-000056:mdna:28]
[same as prior period, unchanged from 0000320193-21-000010:mdna:28]

[0000320193-21-000056:mdna:29]
[same as prior period, unchanged from 0000320193-21-000010:mdna:29]

[0000320193-21-000056:mdna:30]
iPhone net sales increased during the second quarter and first six months of 2021 compared to the same periods in 2020 due primarily to higher net sales from the successful launch of the Company’s new iPhone models in the first quarter of 2021 and a favorable mix of iPhone sales.

[0000320193-21-000056:mdna:31]
[same as prior period, unchanged from 0000320193-21-000010:mdna:31]

[0000320193-21-000056:mdna:32]
Mac net sales increased during the second quarter and first six months of 2021 compared to the same periods in 2020 due primarily to higher net sales of MacBook Air® and MacBook Pro®.

[0000320193-21-000056:mdna:33]
[same as prior period, unchanged from 0000320193-21-000010:mdna:33]

[0000320193-21-000056:mdna:34]
iPad net sales increased during the second quarter and first six months of 2021 compared to the same periods in 2020 due primarily to higher net sales of iPad Air® and the 10-inch version of iPad.

[0000320193-21-000056:mdna:35]
[same as prior period, unchanged from 0000320193-21-000010:mdna:35]

[0000320193-21-000056:mdna:36]
Wearables, Home and Accessories net sales increased during the second quarter and first six months of 2021 compared to the same periods in 2020 due primarily to higher net sales of Apple Watch and accessories.

[0000320193-21-000056:mdna:37]
[same as prior period, unchanged from 0000320193-21-000010:mdna:37]

[0000320193-21-000056:mdna:38]
Services net sales increased during the second quarter and first six months of 2021 compared to the same periods in 2020 due primarily to higher net sales from the App Store, advertising and cloud services.

[0000320193-21-000056:mdna:39]
[same as prior period, unchanged from 0000320193-21-000010:mdna:39]

[0000320193-21-000056:mdna:40]
[same as prior period, unchanged from 0000320193-21-000010:mdna:40]

[0000320193-21-000056:mdna:41]
The following table shows net sales by reportable segment for the three- and six-month periods ended March 27, 2021 and March 28, 2020 (dollars in millions):

[0000320193-21-000056:mdna:42]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27,2021 |  | March 28,2020 |  | Change |  | March 27,2021 |  | March 28,2020 |  | Change |
| Net sales by reportable segment: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 34,306 |  |  | $ | 25,473 |  |  | 35 | % |  | $ | 80,616 |  |  | $ | 66,840 |  |  | 21 | % |
| Europe | 22,264 |  |  | 14,294 |  |  | 56 | % |  | 49,570 |  |  | 37,567 |  |  | 32 | % |
| Greater China | 17,728 |  |  | 9,455 |  |  | 87 | % |  | 39,041 |  |  | 23,033 |  |  | 70 | % |
| Japan | 7,742 |  |  | 5,206 |  |  | 49 | % |  | 16,027 |  |  | 11,429 |  |  | 40 | % |
| Rest of Asia Pacific | 7,544 |  |  | 3,885 |  |  | 94 | % |  | 15,769 |  |  | 11,263 |  |  | 40 | % |
| Total net sales | $ | 89,584 |  |  | $ | 58,313 |  |  | 54 | % |  | $ | 201,023 |  |  | $ | 150,132 |  |  | 34 | % |

[0000320193-21-000056:mdna:43]
[same as prior period, unchanged from 0000320193-21-000010:mdna:43]

[0000320193-21-000056:mdna:44]
Americas net sales increased during the second quarter and first six months of 2021 compared to the same periods in 2020 due primarily to higher net sales of iPhone, Services and Mac.

[0000320193-21-000056:mdna:45]
[same as prior period, unchanged from 0000320193-21-000010:mdna:45]

[0000320193-21-000056:mdna:46]
Europe net sales increased during the second quarter and first six months of 2021 compared to the same periods in 2020 due primarily to higher net sales of iPhone, iPad and Mac.

[0000320193-21-000056:mdna:47]
[same as prior period, unchanged from 0000320193-21-000010:mdna:47]

[0000320193-21-000056:mdna:48]
Greater China net sales increased during the second quarter and first six months of 2021 compared to the same periods in 2020 due primarily to higher net sales of iPhone and iPad. The strength of the Chinese renminbi relative to the U.S. dollar had a favorable impact on Greater China net sales during the second quarter and first six months of 2021.

[0000320193-21-000056:mdna:49]
[same as prior period, unchanged from 0000320193-21-000010:mdna:49]

[0000320193-21-000056:mdna:50]
Japan net sales increased during the second quarter and first six months of 2021 compared to the same periods in 2020 due primarily to higher net sales of iPhone, Services and iPad. The strength of the Japanese yen relative to the U.S. dollar had a favorable impact on Japan net sales during the second quarter and first six months of 2021.

[0000320193-21-000056:mdna:51]
[same as prior period, unchanged from 0000320193-21-000010:mdna:51]

[0000320193-21-000056:mdna:52]
Rest of Asia Pacific net sales increased during the second quarter of 2021 compared to the second quarter of 2020 due primarily to higher net sales of iPhone, iPad and Mac. Year-over-year Rest of Asia Pacific net sales increased during the first six months of 2021 due primarily to higher net sales of iPhone, iPad and Wearables, Home and Accessories. The movement of foreign currencies in the Rest of Asia Pacific relative to the U.S. dollar had a net favorable impact on net sales during the second quarter and first six months of 2021.

[0000320193-21-000056:mdna:53]
[same as prior period, unchanged from 0000320193-21-000010:mdna:53]

[0000320193-21-000056:mdna:54]
Products and Services gross margin and gross margin percentage for the three- and six-month periods ended March 27, 2021 and March 28, 2020 were as follows (dollars in millions):

[0000320193-21-000056:mdna:55]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27,2021 |  | March 28,2020 |  | March 27,2021 |  | March 28,2020 |
| Gross margin: |  |  |  |  |  |  |  |
| Products | $ | 26,236 |  |  | $ | 13,644 |  |  | $ | 59,784 |  |  | $ | 40,673 |  |
| Services | 11,843 |  |  | 8,726 |  |  | 22,623 |  |  | 16,914 |  |
| Total gross margin | $ | 38,079 |  |  | $ | 22,370 |  |  | $ | 82,407 |  |  | $ | 57,587 |  |

[0000320193-21-000056:mdna:56]
| Gross margin percentage: |  |  |  |  |  |  |  |
| Products | 36.1 | % |  | 30.3 | % |  | 35.5 | % |  | 32.8 | % |
| Services | 70.1 | % |  | 65.4 | % |  | 69.3 | % |  | 64.9 | % |
| Total gross margin percentage | 42.5 | % |  | 38.4 | % |  | 41.0 | % |  | 38.4 | % |

[0000320193-21-000056:mdna:57]
[same as prior period, unchanged from 0000320193-21-000010:mdna:57]

[0000320193-21-000056:mdna:58]
Products gross margin increased during the second quarter and first six months of 2021 compared to the same periods in 2020 due primarily to higher Products volume, a different Products mix and the strength in foreign currencies relative to the U.S. dollar.

[0000320193-21-000056:mdna:59]
Year-over-year Products gross margin percentage increased during the second quarter and first six months of 2021 due primarily to higher leverage, a different Products mix and the strength in foreign currencies relative to the U.S. dollar.

[0000320193-21-000056:mdna:60]
[same as prior period, unchanged from 0000320193-21-000010:mdna:59]

[0000320193-21-000056:mdna:61]
Services gross margin increased during the second quarter and first six months of 2021 compared to the same periods in 2020 due primarily to higher Services net sales, a different Services mix and the strength in foreign currencies relative to the U.S. dollar.

[0000320193-21-000056:mdna:62]
Year-over-year Services gross margin percentage increased during the second quarter and first six months of 2021 due primarily to a different Services mix, higher leverage and the strength in foreign currencies relative to the U.S. dollar.

[0000320193-21-000056:mdna:63]
The Company’s future gross margins can be impacted by a variety of factors, as discussed in Part I, Item 1A of the 2020 Form 10-K under the heading “Risk Factors.” As a result, the Company believes, in general, gross margins will be subject to volatility and downward pressure.

[0000320193-21-000056:mdna:64]
[same as prior period, unchanged from 0000320193-21-000010:mdna:62]

[0000320193-21-000056:mdna:65]
Operating expenses for the three- and six-month periods ended March 27, 2021 and March 28, 2020 were as follows (dollars in millions):

[0000320193-21-000056:mdna:66]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27,2021 |  | March 28,2020 |  | March 27,2021 |  | March 28,2020 |
| Research and development | $ | 5,262 |  |  | $ | 4,565 |  |  | $ | 10,425 |  |  | $ | 9,016 |  |
| Percentage of total net sales | 6 | % |  | 8 | % |  | 5 | % |  | 6 | % |
| Selling, general and administrative | $ | 5,314 |  |  | $ | 4,952 |  |  | $ | 10,945 |  |  | $ | 10,149 |  |
| Percentage of total net sales | 6 | % |  | 8 | % |  | 5 | % |  | 7 | % |
| Total operating expenses | $ | 10,576 |  |  | $ | 9,517 |  |  | $ | 21,370 |  |  | $ | 19,165 |  |
| Percentage of total net sales | 12 | % |  | 16 | % |  | 11 | % |  | 13 | % |

[0000320193-21-000056:mdna:67]
[same as prior period, unchanged from 0000320193-21-000010:mdna:65]

[0000320193-21-000056:mdna:68]
The growth in research and development (“R&D”) expense during the second quarter and first six months of 2021 compared to the same periods in 2020 was driven primarily by increases in headcount-related expenses. The Company continues to believe that focused investments in R&D are critical to its future growth and competitive position in the marketplace, and to the development of new and updated products and services that are central to the Company’s core business strategy.

[0000320193-21-000056:mdna:69]
[same as prior period, unchanged from 0000320193-21-000010:mdna:67]

[0000320193-21-000056:mdna:70]
The growth in selling, general and administrative expense during the second quarter and first six months of 2021 compared to the same periods in 2020 was driven primarily by increases in headcount-related expenses and higher variable selling expenses.

[0000320193-21-000056:mdna:71]
[same as prior period, unchanged from 0000320193-21-000010:mdna:69]

[0000320193-21-000056:mdna:72]
Other income/(expense), net (“OI&E”) for the three- and six-month periods ended March 27, 2021 and March 28, 2020 was as follows (dollars in millions):

[0000320193-21-000056:mdna:73]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27,2021 |  | March 28,2020 |  | Change |  | March 27,2021 |  | March 28,2020 |  | Change |
| Interest and dividend income | $ | 718 |  |  | $ | 1,049 |  |  |  |  | $ | 1,465 |  |  | $ | 2,094 |  |  |  |
| Interest expense | (670) |  |  | (757) |  |  |  |  | (1,308) |  |  | (1,542) |  |  |  |
| Other income/(expense), net | 460 |  |  | (10) |  |  |  |  | 396 |  |  | 79 |  |  |  |
| Total other income/(expense), net | $ | 508 |  |  | $ | 282 |  |  | 80 | % |  | $ | 553 |  |  | $ | 631 |  |  | (12) | % |

[0000320193-21-000056:mdna:74]
OI&E increased during the second quarter of 2021 compared to the second quarter of 2020 due primarily to impairments of marketable and non-marketable securities in 2020 and a favorable carrying value adjustment of non-marketable securities in 2021, partially offset by lower interest income in 2021.

[0000320193-21-000056:mdna:75]
OI&E decreased during the first six months of 2021 compared to the same period in 2020 due primarily to lower interest income in 2021, partially offset by impairments of marketable and non-marketable securities in 2020 and lower interest expense in 2021.

[0000320193-21-000056:mdna:76]
The weighted-average interest rate earned by the Company on its cash, cash equivalents and marketable securities was 1.37% and 2.01% in the second quarter of 2021 and 2020, respectively, and 1.43% and 2.05% in the first six months of 2021 and 2020, respectively.

[0000320193-21-000056:mdna:77]
[same as prior period, unchanged from 0000320193-21-000010:mdna:73]

[0000320193-21-000056:mdna:78]
Provision for income taxes, effective tax rate and statutory federal income tax rate for the three- and six-month periods ended March 27, 2021 and March 28, 2020 were as follows (dollars in millions):

[0000320193-21-000056:mdna:79]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27,2021 |  | March 28,2020 |  | March 27,2021 |  | March 28,2020 |
| Provision for income taxes | $ | 4,381 |  |  | $ | 1,886 |  |  | $ | 9,205 |  |  | $ | 5,568 |  |
| Effective tax rate | 15.6 | % |  | 14.4 | % |  | 14.9 | % |  | 14.3 | % |
| Statutory federal income tax rate | 21 | % |  | 21 | % |  | 21 | % |  | 21 | % |

[0000320193-21-000056:mdna:80]
The Company’s effective tax rate for the second quarter of 2021 was lower than the statutory federal income tax rate due primarily to lower taxes on foreign earnings. The Company’s effective tax rate for the first six months of 2021 was lower than the statutory federal income tax rate due primarily to lower taxes on foreign earnings and tax benefits from share-based compensation.

[0000320193-21-000056:mdna:81]
The Company’s effective tax rate for the second quarter of 2021 was higher compared to the second quarter of 2020 due primarily to higher taxes on foreign earnings and a lower impact of the U.S. federal R&D tax credit. The Company’s effective tax rate for the first six months of 2021 was higher compared to the same period in 2020 due primarily to higher taxes on foreign earnings, partially offset by higher tax benefits from share-based compensation.

[0000320193-21-000056:mdna:82]
[same as prior period, unchanged from 0000320193-21-000010:mdna:78]

[0000320193-21-000056:mdna:83]
The following tables present selected financial information and statistics as of March 27, 2021 and September 26, 2020 and for the first six months of 2021 and 2020 (in millions):

[0000320193-21-000056:mdna:84]
|  | March 27,2021 |  | September 26,2020 |
| Cash, cash equivalents and marketable securities (1) | $ | 204,373 |  |  | $ | 191,830 |  |
| Property, plant and equipment, net | $ | 37,815 |  |  | $ | 36,766 |  |
| Commercial paper | $ | 5,000 |  |  | $ | 4,996 |  |
| Total term debt | $ | 116,645 |  |  | $ | 107,440 |  |
| Working capital | $ | 15,080 |  |  | $ | 38,321 |  |

[0000320193-21-000056:mdna:85]
|  | Six Months Ended |
|  | March 27,2021 |  | March 28,2020 |
| Cash generated by operating activities | $ | 62,744 |  |  | $ | 43,827 |  |
| Cash used in investing activities | $ | (18,952) |  |  | $ | (4,655) |  |
| Cash used in financing activities | $ | (43,575) |  |  | $ | (46,347) |  |

[0000320193-21-000056:mdna:86]
(1)As of March 27, 2021 and September 26, 2020, total marketable securities included $19.0 billion and $18.6 billion, respectively, that was restricted from general use, related to the State Aid Decision (refer to Note 5, “Income Taxes” in the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Form 10-Q) and other agreements.

[0000320193-21-000056:mdna:87]
[same as prior period, unchanged from 0000320193-21-000010:mdna:83]

[0000320193-21-000056:mdna:88]
In connection with the State Aid Decision, as of March 27, 2021, the adjusted recovery amount of €12.9 billion plus interest of €1.2 billion was funded into escrow, where it will remain restricted from general use pending the conclusion of all legal proceedings. Further information regarding the State Aid Decision can be found in Part I, Item 1 of this Form 10-Q in the Notes to Condensed Consolidated Financial Statements in Note 5, “Income Taxes.”

[0000320193-21-000056:mdna:89]
[same as prior period, unchanged from 0000320193-21-000010:mdna:85]

[0000320193-21-000056:mdna:90]
During the six months ended March 27, 2021, cash generated by operating activities of $62.7 billion was a result of $52.4 billion of net income, non-cash adjustments to net income of $8.8 billion and an increase in the net change in operating assets and liabilities of $1.6 billion. Cash used in investing activities of $19.0 billion during the six months ended March 27, 2021 consisted primarily of cash used for purchases of marketable securities, net of maturities and sales, of $13.2 billion and cash used to acquire property, plant and equipment of $5.8 billion. Cash used in financing activities of $43.6 billion during the six months ended March 27, 2021 consisted primarily of cash used to repurchase common stock of $43.3 billion, cash used to pay dividends and dividend equivalents of $7.1 billion and cash used to repay or redeem term debt of $4.5 billion, partially offset by net proceeds from issuance of term debt of $13.9 billion.

[0000320193-21-000056:mdna:91]
During the six months ended March 28, 2020, cash generated by operating activities of $43.8 billion was a result of $33.5 billion of net income, non-cash adjustments to net income of $8.1 billion and an increase in the net change in operating assets and liabilities of $2.2 billion. Cash used in investing activities of $4.7 billion during the six months ended March 28, 2020 consisted primarily of cash used to acquire property, plant and equipment of $4.0 billion, partially offset by proceeds from maturities and sales of marketable securities, net of purchases, of $1.0 billion. Cash used in financing activities of $46.3 billion during the six months ended March 28, 2020 consisted primarily of cash used to repurchase common stock of $39.3 billion, cash used to pay dividends and dividend equivalents of $6.9 billion and cash used to repay or redeem term debt of $5.3 billion, partially offset by net proceeds from commercial paper and repurchase agreement of $4.1 billion and net proceeds from issuance of term debt of $2.2 billion.

[0000320193-21-000056:mdna:92]
[same as prior period, unchanged from 0000320193-21-000010:mdna:88]

[0000320193-21-000056:mdna:93]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses the net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of March 27, 2021, the Company had $5.0 billion of Commercial Paper outstanding, with a weighted-average interest rate of 0.06% and maturities generally less than nine months.

[0000320193-21-000056:mdna:94]
As of March 27, 2021, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $116.0 billion (collectively the “Notes”). During the first six months of 2021, the Company issued $13.9 billion and repaid or redeemed $4.5 billion of Notes. The Company has entered, and in the future may enter, into interest rate swaps to manage interest rate risk on the Notes. In addition, the Company has entered, and in the future may enter, into foreign currency swaps to manage foreign currency risk on the Notes.

[0000320193-21-000056:mdna:95]
[same as prior period, unchanged from 0000320193-21-000010:mdna:91]

[0000320193-21-000056:mdna:96]
Capital Return

[0000320193-21-000056:mdna:97]
As of March 27, 2021, the Company was authorized to purchase up to $225 billion of the Company’s common stock under a share repurchase program (the “Program”). During the six months ended March 27, 2021, the Company repurchased 347 million shares of its common stock for $43.0 billion, bringing the total utilization under the Program to $211.6 billion. On April 28, 2021, the Company announced the Board of Directors increased the Program authorization by $90 billion. The Program does not obligate the Company to acquire any specific number of shares. Under the Program, shares may be repurchased in privately negotiated and/or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).

[0000320193-21-000056:mdna:98]
On April 28, 2021, the Company also announced the Board of Directors raised the Company’s quarterly cash dividend from $0.205 to $0.22 per share, beginning with the dividend to be paid during the third quarter of 2021. The Company intends to increase its dividend on an annual basis, subject to declaration by the Board of Directors.

[0000320193-21-000056:mdna:99]
[same as prior period, unchanged from 0000320193-21-000010:mdna:95]

[0000320193-21-000056:mdna:100]
[same as prior period, unchanged from 0000320193-21-000010:mdna:96]

[0000320193-21-000056:mdna:101]
The Company has lease arrangements for certain equipment and facilities, including retail, corporate, manufacturing and data center space. The Company’s retail store and other facility leases typically have original terms not exceeding 10 years and generally contain multi-year renewal options. The Company’s total fixed lease payment obligation of $13.1 billion as of March 27, 2021 included future payments under leases that had commenced as of March 27, 2021, and were therefore recorded on the Company’s Condensed Consolidated Balance Sheet, as well as leases that had been signed but not yet commenced as of March 27, 2021.

[0000320193-21-000056:mdna:102]
[same as prior period, unchanged from 0000320193-21-000010:mdna:98]

[0000320193-21-000056:mdna:103]
The Company utilizes several outsourcing partners to manufacture sub-assemblies for the Company’s products and to perform final assembly and testing of finished products. These outsourcing partners acquire components and build product based on demand information supplied by the Company, which typically covers periods up to 150 days. The Company also obtains individual components for its products from a wide variety of individual suppliers. As of March 27, 2021, the Company expects to pay $35.4 billion under manufacturing-related supplier arrangements, which are primarily noncancelable.

[0000320193-21-000056:mdna:104]
[same as prior period, unchanged from 0000320193-21-000010:mdna:100]

[0000320193-21-000056:mdna:105]
The Company’s other purchase obligations primarily consist of noncancelable obligations to acquire capital assets, including product tooling and manufacturing process equipment, and noncancelable obligations related to advertising, content creation and Internet and telecommunications services. As of March 27, 2021, the Company had other purchase obligations of $8.6 billion.

[0000320193-21-000056:mdna:106]
[same as prior period, unchanged from 0000320193-21-000010:mdna:102]

[0000320193-21-000056:mdna:107]
As of March 27, 2021, the balance of the deemed repatriation tax payable imposed by the U.S. Tax Cuts and Jobs Act (the “Act”) was $27.8 billion, of which $25.1 billion was included in other non-current liabilities in the Company’s Condensed Consolidated Balance Sheet. The Company pays the deemed repatriation tax payable in installments in accordance with the Act.

[0000320193-21-000056:mdna:108]
[same as prior period, unchanged from 0000320193-21-000010:mdna:104]

[0000320193-21-000056:mdna:109]
[same as prior period, unchanged from 0000320193-21-000010:mdna:105]

[0000320193-21-000056:mdna:110]
[same as prior period, unchanged from 0000320193-21-000010:mdna:106]

[0000320193-21-000056:mdna:111]
[same as prior period, unchanged from 0000320193-21-000010:mdna:107]

[0000320193-21-000056:mdna:112]
[same as prior period, unchanged from 0000320193-21-000010:mdna:108]
