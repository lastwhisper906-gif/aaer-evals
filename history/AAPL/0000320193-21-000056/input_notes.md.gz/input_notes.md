# AAPL notes — 0000320193-21-000056


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000320193-21-000056:notes:1]
[same as prior period, unchanged from 0000320193-21-000010:notes:1]

[0000320193-21-000056:notes:2]
[same as prior period, unchanged from 0000320193-21-000010:notes:2]

[0000320193-21-000056:notes:3]
[same as prior period, unchanged from 0000320193-21-000010:notes:3]

[0000320193-21-000056:notes:4]
[same as prior period, unchanged from 0000320193-21-000010:notes:4]

[0000320193-21-000056:notes:5]
[same as prior period, unchanged from 0000320193-21-000010:notes:5]

[0000320193-21-000056:notes:6]
Recently Adopted Accounting Pronouncements

[0000320193-21-000056:notes:7]
[same as prior period, unchanged from 0000320193-21-000010:notes:7]

[0000320193-21-000056:notes:8]
At the beginning of the first quarter of 2021, the Company adopted the Financial Accounting Standards Board’s Accounting Standards Update No. 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (“ASU 2016-13”), which modifies the measurement of expected credit losses on certain financial instruments. The Company adopted ASU 2016-13 utilizing the modified retrospective transition method. The adoption of ASU 2016-13 did not have a material impact on the Company’s condensed consolidated financial statements.

[0000320193-21-000056:notes:9]
[same as prior period, unchanged from 0000320193-21-000010:notes:9]

[0000320193-21-000056:notes:10]
The following table shows the computation of basic and diluted earnings per share for the three- and six-month periods ended March 27, 2021 and March 28, 2020 (net income in millions and shares in thousands):

[0000320193-21-000056:notes:11]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27,2021 |  | March 28,2020 |  | March 27,2021 |  | March 28,2020 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 23,630 |  |  | $ | 11,249 |  |  | $ | 52,385 |  |  | $ | 33,485 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 16,753,476 |  |  | 17,440,402 |  |  | 16,844,298 |  |  | 17,550,281 |  |
| Effect of dilutive securities | 175,681 |  |  | 178,363 |  |  | 177,125 |  |  | 168,310 |  |
| Weighted-average diluted shares | 16,929,157 |  |  | 17,618,765 |  |  | 17,021,423 |  |  | 17,718,591 |  |
| Basic earnings per share | $ | 1.41 |  |  | $ | 0.64 |  |  | $ | 3.11 |  |  | $ | 1.91 |  |
| Diluted earnings per share | $ | 1.40 |  |  | $ | 0.64 |  |  | $ | 3.08 |  |  | $ | 1.89 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000320193-21-000056:notes:12]
[same as prior period, unchanged from 0000320193-21-000010:notes:12]

[0000320193-21-000056:notes:13]
[same as prior period, unchanged from 0000320193-21-000010:notes:13]

[0000320193-21-000056:notes:14]
[same as prior period, unchanged from 0000320193-21-000010:notes:14]

[0000320193-21-000056:notes:15]
[same as prior period, unchanged from 0000320193-21-000010:notes:15]

[0000320193-21-000056:notes:16]
[same as prior period, unchanged from 0000320193-21-000010:notes:16]

[0000320193-21-000056:notes:17]
[same as prior period, unchanged from 0000320193-21-000010:notes:17]

[0000320193-21-000056:notes:18]
[same as prior period, unchanged from 0000320193-21-000010:notes:18]

[0000320193-21-000056:notes:19]
[same as prior period, unchanged from 0000320193-21-000010:notes:19]

[0000320193-21-000056:notes:20]
As of March 27, 2021 and September 26, 2020, the Company had total deferred revenue of $11.9 billion and $10.2 billion, respectively. As of March 27, 2021, the Company expects 64% of total deferred revenue to be realized in less than a year, 26% within one-to-two years, 8% within two-to-three years and 2% in greater than three years.

[0000320193-21-000056:notes:21]
[same as prior period, unchanged from 0000320193-21-000010:notes:21]

[0000320193-21-000056:notes:22]
Net sales disaggregated by significant products and services for the three- and six-month periods ended March 27, 2021 and March 28, 2020 were as follows (in millions):

[0000320193-21-000056:notes:23]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27,2021 |  | March 28,2020 |  | March 27,2021 |  | March 28,2020 |
| iPhone (1) | $ | 47,938 |  |  | $ | 28,962 |  |  | $ | 113,535 |  |  | $ | 84,919 |  |
| Mac (1) | 9,102 |  |  | 5,351 |  |  | 17,777 |  |  | 12,511 |  |
| iPad (1) | 7,807 |  |  | 4,368 |  |  | 16,242 |  |  | 10,345 |  |
| Wearables, Home and Accessories (1)(2) | 7,836 |  |  | 6,284 |  |  | 20,807 |  |  | 16,294 |  |
| Services (3) | 16,901 |  |  | 13,348 |  |  | 32,662 |  |  | 26,063 |  |
| Total net sales (4) | $ | 89,584 |  |  | $ | 58,313 |  |  | $ | 201,023 |  |  | $ | 150,132 |  |

[0000320193-21-000056:notes:24]
[same as prior period, unchanged from 0000320193-21-000010:notes:24]

[0000320193-21-000056:notes:25]
[same as prior period, unchanged from 0000320193-21-000010:notes:25]

[0000320193-21-000056:notes:26]
[same as prior period, unchanged from 0000320193-21-000010:notes:26]

[0000320193-21-000056:notes:27]
(4)Includes $2.7 billion of revenue recognized in the three months ended March 27, 2021 that was included in deferred revenue as of December 26, 2020, $1.9 billion of revenue recognized in the three months ended March 28, 2020 that was included in deferred revenue as of December 28, 2019, $4.1 billion of revenue recognized in the six months ended March 27, 2021 that was included in deferred revenue as of September 26, 2020, and $3.0 billion of revenue recognized in the six months ended March 28, 2020 that was included in deferred revenue as of September 28, 2019.

[0000320193-21-000056:notes:28]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 11, “Segment Information and Geographic Data” for the three- and six-month periods ended March 27, 2021 and March 28, 2020.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000320193-21-000056:notes:29]
[same as prior period, unchanged from 0000320193-21-000010:notes:29]

[0000320193-21-000056:notes:30]
The following tables show the Company’s cash and marketable securities by significant investment category as of March 27, 2021 and September 26, 2020 (in millions):

[0000320193-21-000056:notes:31]
|  | March 27, 2021 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | CurrentMarketableSecurities |  | Non-CurrentMarketableSecurities |
| Cash | $ | 19,444 |  |  | $ | — |  |  | $ | — |  |  | $ | 19,444 |  |  | $ | 19,444 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 11,998 |  |  | — |  |  | — |  |  | 11,998 |  |  | 11,998 |  |  | — |  |  | — |  |
| Mutual funds | 143 |  |  | 1 |  |  | (2) |  |  | 142 |  |  | — |  |  | 142 |  |  | — |  |
| Subtotal | 12,141 |  |  | 1 |  |  | (2) |  |  | 12,140 |  |  | 11,998 |  |  | 142 |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 21,331 |  |  | 168 |  |  | (149) |  |  | 21,350 |  |  | 205 |  |  | 8,058 |  |  | 13,087 |  |
| U.S. agency securities | 8,228 |  |  | 5 |  |  | (72) |  |  | 8,161 |  |  | — |  |  | 3,212 |  |  | 4,949 |  |
| Non-U.S. government securities | 19,849 |  |  | 211 |  |  | (169) |  |  | 19,891 |  |  | 200 |  |  | 2,881 |  |  | 16,810 |  |
| Certificates of deposit and time deposits | 7,198 |  |  | — |  |  | — |  |  | 7,198 |  |  | 5,814 |  |  | 1,114 |  |  | 270 |  |
| Commercial paper | 3,353 |  |  | — |  |  | — |  |  | 3,353 |  |  | 805 |  |  | 2,548 |  |  | — |  |
| Corporate debt securities | 88,108 |  |  | 1,506 |  |  | (444) |  |  | 89,170 |  |  | — |  |  | 13,036 |  |  | 76,134 |  |
| Municipal securities | 980 |  |  | 16 |  |  | (1) |  |  | 995 |  |  | — |  |  | 136 |  |  | 859 |  |
| Mortgage- and asset-backed securities | 22,624 |  |  | 234 |  |  | (187) |  |  | 22,671 |  |  | — |  |  | 241 |  |  | 22,430 |  |
| Subtotal | 171,671 |  |  | 2,140 |  |  | (1,022) |  |  | 172,789 |  |  | 7,024 |  |  | 31,226 |  |  | 134,539 |  |
| Total (3) | $ | 203,256 |  |  | $ | 2,141 |  |  | $ | (1,024) |  |  | $ | 204,373 |  |  | $ | 38,466 |  |  | $ | 31,368 |  |  | $ | 134,539 |  |

[0000320193-21-000056:notes:32]
[same as prior period, unchanged from 0000320193-21-000010:notes:32]

[0000320193-21-000056:notes:33]
[same as prior period, unchanged from 0000320193-21-000010:notes:33]

[0000320193-21-000056:notes:34]
[same as prior period, unchanged from 0000320193-21-000010:notes:34]

[0000320193-21-000056:notes:35]
(3)As of March 27, 2021 and September 26, 2020, total marketable securities included $19.0 billion and $18.6 billion, respectively, that was restricted from general use, related to the State Aid Decision (refer to Note 5, “Income Taxes”) and other agreements.

[0000320193-21-000056:notes:36]
The Company may sell certain of its marketable debt securities prior to their stated maturities for reasons including, but not limited to, managing liquidity, credit risk, duration and asset allocation. The following table shows the fair value of the Company’s non-current marketable debt securities, by contractual maturity, as of March 27, 2021 (in millions):

[0000320193-21-000056:notes:37]
| Due after 1 year through 5 years | $ | 83,364 |  |
| Due after 5 years through 10 years | 28,835 |  |
| Due after 10 years | 22,340 |  |
| Total fair value | $ | 134,539 |  |

[0000320193-21-000056:notes:38]
[same as prior period, unchanged from 0000320193-21-000010:notes:37]

[0000320193-21-000056:notes:39]
[same as prior period, unchanged from 0000320193-21-000010:notes:38]

[0000320193-21-000056:notes:40]
The Company holds non-marketable equity securities of certain privately held companies without readily determinable fair values. As of March 27, 2021 and September 26, 2020, the Company’s non-marketable equity securities had a carrying value of $2.7 billion and $2.8 billion, respectively.

[0000320193-21-000056:notes:41]
[same as prior period, unchanged from 0000320193-21-000010:notes:40]

[0000320193-21-000056:notes:42]
A reconciliation of the Company’s cash and cash equivalents in the Condensed Consolidated Balance Sheets to cash, cash equivalents and restricted cash in the Condensed Consolidated Statements of Cash Flows as of March 27, 2021 and September 26, 2020 is as follows (in millions):

[0000320193-21-000056:notes:43]
|  | March 27,2021 |  | September 26,2020 |
| Cash and cash equivalents | $ | 38,466 |  |  | $ | 38,016 |  |
| Restricted cash | 1,540 |  |  | 1,773 |  |
| Cash, cash equivalents and restricted cash | $ | 40,006 |  |  | $ | 39,789 |  |

[0000320193-21-000056:notes:44]
[same as prior period, unchanged from 0000320193-21-000010:notes:43]

[0000320193-21-000056:notes:45]
[same as prior period, unchanged from 0000320193-21-000010:notes:44]

[0000320193-21-000056:notes:46]
[same as prior period, unchanged from 0000320193-21-000010:notes:45]

[0000320193-21-000056:notes:47]
[same as prior period, unchanged from 0000320193-21-000010:notes:46]

[0000320193-21-000056:notes:48]
[same as prior period, unchanged from 0000320193-21-000010:notes:47]

[0000320193-21-000056:notes:49]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in foreign currency exchange rates, the Company may enter into forward contracts, cross-currency swaps or other instruments. These instruments may offset a portion of the foreign currency remeasurement gains or losses, or changes in fair value. The Company may designate these instruments as either cash flow or fair value hedges. As of March 27, 2021, the Company’s hedged term debt– and marketable securities–related foreign currency transactions are expected to be recognized within 21 years.

[0000320193-21-000056:notes:50]
[same as prior period, unchanged from 0000320193-21-000010:notes:49]

[0000320193-21-000056:notes:51]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in interest rates, the Company may enter into interest rate swaps, options or other instruments. These instruments may offset a portion of the changes in interest income or expense, or changes in fair value. The Company designates these instruments as either cash flow or fair value hedges. As of March 27, 2021, the Company’s hedged interest rate transactions are expected to be recognized within seven years.

[0000320193-21-000056:notes:52]
[same as prior period, unchanged from 0000320193-21-000010:notes:51]

[0000320193-21-000056:notes:53]
[same as prior period, unchanged from 0000320193-21-000010:notes:52]

[0000320193-21-000056:notes:54]
[same as prior period, unchanged from 0000320193-21-000010:notes:53]

[0000320193-21-000056:notes:55]
[same as prior period, unchanged from 0000320193-21-000010:notes:54]

[0000320193-21-000056:notes:56]
[same as prior period, unchanged from 0000320193-21-000010:notes:55]

[0000320193-21-000056:notes:57]
[same as prior period, unchanged from 0000320193-21-000010:notes:56]

[0000320193-21-000056:notes:58]
Fair value hedge gains and losses related to amounts that are included in the assessment of hedge effectiveness are recognized in earnings along with a corresponding loss or gain related to the change in value of the hedged item in the same line in the Condensed Consolidated Statements of Operations. For foreign exchange forward contracts designated as fair value hedges, the forward carry component is excluded from the assessment of hedge effectiveness and recognized in OI&E on a straight-line basis over the life of the hedge. Amounts excluded from the effectiveness assessment of fair value hedges and recognized in OI&E were gains of $60 million and $142 million for the three- and six-month periods ended March 27, 2021, respectively, and were gains of $126 million and $254 million for the three- and six-month periods ended March 28, 2020, respectively. Changes in the fair value of amounts excluded from the assessment of hedge effectiveness are recognized in OCI.

[0000320193-21-000056:notes:59]
[same as prior period, unchanged from 0000320193-21-000010:notes:58]

[0000320193-21-000056:notes:60]
[same as prior period, unchanged from 0000320193-21-000010:notes:59]

[0000320193-21-000056:notes:61]
The Company records all derivatives in the Condensed Consolidated Balance Sheets at fair value. The Company’s accounting treatment for these derivative instruments is based on its hedge designation. The following tables show the Company’s derivative instruments at gross fair value as of March 27, 2021 and September 26, 2020 (in millions):

[0000320193-21-000056:notes:62]
|  | March 27, 2021 |
|  | Fair Value ofDerivatives Designatedas Hedge Instruments |  | Fair Value ofDerivatives Not Designatedas Hedge Instruments |  | TotalFair Value |
| Derivative assets (1): |  |  |  |  |  |
| Foreign exchange contracts | $ | 717 |  |  | $ | 778 |  |  | $ | 1,495 |  |
| Interest rate contracts | $ | 923 |  |  | $ | — |  |  | $ | 923 |  |
| Derivative liabilities (2): |  |  |  |  |  |
| Foreign exchange contracts | $ | 1,014 |  |  | $ | 702 |  |  | $ | 1,716 |  |

[0000320193-21-000056:notes:63]
[same as prior period, unchanged from 0000320193-21-000010:notes:62]

[0000320193-21-000056:notes:64]
[same as prior period, unchanged from 0000320193-21-000010:notes:63]

[0000320193-21-000056:notes:65]
[same as prior period, unchanged from 0000320193-21-000010:notes:64]

[0000320193-21-000056:notes:66]
[same as prior period, unchanged from 0000320193-21-000010:notes:65]

[0000320193-21-000056:notes:67]
The following table shows the pre-tax gains and losses of the Company’s derivative and non-derivative instruments designated as cash flow and net investment hedges in OCI and the Condensed Consolidated Statements of Operations for the three- and six-month periods ended March 27, 2021 and March 28, 2020 (in millions):

[0000320193-21-000056:notes:68]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27,2021 |  | March 28,2020 |  | March 27,2021 |  | March 28,2020 |
| Gains/(Losses) recognized in OCI – included in effectiveness assessment: |  |  |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 338 |  |  | $ | (462) |  |  | $ | 147 |  |  | $ | (191) |  |
| Interest rate contracts | 39 |  |  | (66) |  |  | 93 |  |  | (66) |  |
| Total | $ | 377 |  |  | $ | (528) |  |  | $ | 240 |  |  | $ | (257) |  |
| Net investment hedges: |  |  |  |  |  |  |  |
| Foreign currency debt | $ | — |  |  | $ | 11 |  |  | $ | — |  |  | $ | 35 |  |
| Gains/(Losses) reclassified from AOCI into net income – included in effectiveness assessment: |  |  |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | (885) |  |  | $ | (817) |  |  | $ | (571) |  |  | $ | (326) |  |
| Interest rate contracts | (2) |  |  | (1) |  |  | (5) |  |  | (3) |  |
| Total | $ | (887) |  |  | $ | (818) |  |  | $ | (576) |  |  | $ | (329) |  |

[0000320193-21-000056:notes:69]
Amounts excluded from the effectiveness assessment of the Company’s hedges and recognized in OCI were a gain of $41 million and a loss of $97 million for the three- and six-month periods ended March 27, 2021, respectively, and were gains of $258 million and $169 million for the three- and six-month periods ended March 28, 2020, respectively.

[0000320193-21-000056:notes:70]
The following tables show information about the Company’s derivative instruments designated as fair value hedges and the related hedged items for the three- and six-month periods ended March 27, 2021 and March 28, 2020 and as of March 27, 2021 and September 26, 2020 (in millions):

[0000320193-21-000056:notes:71]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27,2021 |  | March 28,2020 |  | March 27,2021 |  | March 28,2020 |
| Gains/(Losses) on derivative instruments (1): |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 570 |  |  | $ | 436 |  |  | $ | (183) |  |  | $ | 253 |  |
| Interest rate contracts | (451) |  |  | 1,290 |  |  | (618) |  |  | 1,128 |  |
| Total | $ | 119 |  |  | $ | 1,726 |  |  | $ | (801) |  |  | $ | 1,381 |  |
| Gains/(Losses) related to hedged items (1): |  |  |  |  |  |  |  |
| Marketable securities | $ | (569) |  |  | $ | (436) |  |  | $ | 183 |  |  | $ | (253) |  |
| Fixed-rate debt | 451 |  |  | (1,290) |  |  | 618 |  |  | (1,128) |  |
| Total | $ | (118) |  |  | $ | (1,726) |  |  | $ | 801 |  |  | $ | (1,381) |  |

[0000320193-21-000056:notes:72]
|  | March 27,2021 |  | September 26,2020 |
| Carrying amounts of hedged assets/(liabilities): |  |  |  |
| Marketable securities (2) | $ | 16,423 |  |  | $ | 16,270 |  |
| Fixed-rate debt (3) | $ | (18,416) |  |  | $ | (21,033) |  |
| Cumulative hedging adjustments included in the carrying amounts of hedged items: |  |  |  |
| Marketable securities carrying amount increases/(decreases) | $ | 403 |  |  | $ | 493 |  |
| Fixed-rate debt carrying amount (increases)/decreases | $ | (923) |  |  | $ | (1,541) |  |

[0000320193-21-000056:notes:73]
[same as prior period, unchanged from 0000320193-21-000010:notes:72]

[0000320193-21-000056:notes:74]
[same as prior period, unchanged from 0000320193-21-000010:notes:73]

[0000320193-21-000056:notes:75]
[same as prior period, unchanged from 0000320193-21-000010:notes:74]

[0000320193-21-000056:notes:76]
The following table shows the notional amounts of the Company’s outstanding derivative instruments and credit risk amounts associated with outstanding or unsettled derivative instruments as of March 27, 2021 and September 26, 2020 (in millions):

[0000320193-21-000056:notes:77]
|  | March 27, 2021 |  | September 26, 2020 |
|  | NotionalAmount |  | Credit RiskAmount |  | NotionalAmount |  | Credit RiskAmount |
| Instruments designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 53,312 |  |  | $ | 717 |  |  | $ | 57,410 |  |  | $ | 749 |  |
| Interest rate contracts | $ | 17,500 |  |  | $ | 923 |  |  | $ | 20,700 |  |  | $ | 1,557 |  |
| Instruments not designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 104,434 |  |  | $ | 778 |  |  | $ | 88,636 |  |  | $ | 303 |  |

[0000320193-21-000056:notes:78]
[same as prior period, unchanged from 0000320193-21-000010:notes:77]

[0000320193-21-000056:notes:79]
The Company generally enters into master netting arrangements, which are designed to reduce credit risk by permitting net settlement of transactions with the same counterparty. To further limit credit risk, the Company generally enters into collateral security arrangements that provide for collateral to be received or posted when the net fair value of certain financial instruments fluctuates from contractually established thresholds. The Company presents its derivative assets and derivative liabilities at their gross fair values in its Condensed Consolidated Balance Sheets. As of March 27, 2021 and September 26, 2020, the net cash collateral received by the Company related to derivative instruments under its collateral security arrangements was $935 million and $875 million, respectively. The Company includes gross collateral posted and received in other current assets and other current liabilities in the Condensed Consolidated Balance Sheets, respectively.

[0000320193-21-000056:notes:80]
Under master netting arrangements with the respective counterparties to the Company’s derivative contracts, the Company is allowed to net settle transactions with a single net amount payable by one party to the other. As of March 27, 2021 and September 26, 2020, the potential effects of these rights of set-off associated with the Company’s derivative contracts, including the effects of collateral, would be a reduction to both derivative assets and derivative liabilities of $2.4 billion and $2.8 billion, respectively, resulting in net derivative liabilities of $233 million and $312 million, respectively.

[0000320193-21-000056:notes:81]
[same as prior period, unchanged from 0000320193-21-000010:notes:80]

[0000320193-21-000056:notes:82]
[same as prior period, unchanged from 0000320193-21-000010:notes:81]

[0000320193-21-000056:notes:83]
[same as prior period, unchanged from 0000320193-21-000010:notes:82]

[0000320193-21-000056:notes:84]
As of March 27, 2021, the Company had one customer that represented 10% or more of total trade receivables, which accounted for 13%. As of September 26, 2020, the Company had no customers that individually represented 10% or more of total trade receivables. The Company’s cellular network carriers accounted for 35% of total trade receivables as of March 27, 2021.

[0000320193-21-000056:notes:85]
[same as prior period, unchanged from 0000320193-21-000010:notes:84]

[0000320193-21-000056:notes:86]
The Company has non-trade receivables from certain of its manufacturing vendors resulting from the sale of components to these vendors who manufacture sub-assemblies or assemble final products for the Company. The Company purchases these components directly from suppliers. As of March 27, 2021, the Company had one vendor that represented 10% or more of total vendor non-trade receivables, which accounted for 65%. As of September 26, 2020, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 57%, and 11%.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000320193-21-000056:notes:87]
[same as prior period, unchanged from 0000320193-21-000010:notes:86]


## us-gaap:DerivativesPolicyTextBlock

[0000320193-21-000056:notes:88]
Fair Value Hedges
Fair value hedge gains and losses related to amounts that are included in the assessment of hedge effectiveness are recognized in earnings along with a corresponding loss or gain related to the change in value of the hedged item in the same line in the Condensed Consolidated Statements of Operations. For foreign exchange forward contracts designated as fair value hedges, the forward carry component is excluded from the assessment of hedge effectiveness and recognized in OI&E on a straight-line basis over the life of the hedge.Changes in the fair value of amounts excluded from the assessment of hedge effectiveness are recognized in OCI. 
Non-Designated Derivatives

[0000320193-21-000056:notes:89]
[same as prior period, unchanged from 0000320193-21-000010:notes:88]


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000320193-21-000056:notes:90]
Condensed Consolidated Financial Statement Details
The following tables show the Company’s condensed consolidated financial statement details as of March 27, 2021 and September 26, 2020 (in millions):

[0000320193-21-000056:notes:91]
[same as prior period, unchanged from 0000320193-21-000010:notes:90]

[0000320193-21-000056:notes:92]
|  | March 27,2021 |  | September 26,2020 |
| Land and buildings | $ | 19,000 |  |  | $ | 17,952 |  |
| Machinery, equipment and internal-use software | 77,841 |  |  | 75,291 |  |
| Leasehold improvements | 10,439 |  |  | 10,283 |  |
| Gross property, plant and equipment | 107,280 |  |  | 103,526 |  |
| Accumulated depreciation and amortization | (69,465) |  |  | (66,760) |  |
| Total property, plant and equipment, net | $ | 37,815 |  |  | $ | 36,766 |  |

[0000320193-21-000056:notes:93]
[same as prior period, unchanged from 0000320193-21-000010:notes:92]

[0000320193-21-000056:notes:94]
|  | March 27,2021 |  | September 26,2020 |
| Long-term taxes payable | $ | 25,162 |  |  | $ | 28,170 |  |
| Other non-current liabilities | 27,791 |  |  | 26,320 |  |
| Total other non-current liabilities | $ | 52,953 |  |  | $ | 54,490 |  |

[0000320193-21-000056:notes:95]
[same as prior period, unchanged from 0000320193-21-000010:notes:94]

[0000320193-21-000056:notes:96]
The following table shows the detail of OI&E for the three- and six-month periods ended March 27, 2021 and March 28, 2020 (in millions):

[0000320193-21-000056:notes:97]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27,2021 |  | March 28,2020 |  | March 27,2021 |  | March 28,2020 |
| Interest and dividend income | $ | 718 |  |  | $ | 1,049 |  |  | $ | 1,465 |  |  | $ | 2,094 |  |
| Interest expense | (670) |  |  | (757) |  |  | (1,308) |  |  | (1,542) |  |
| Other income/(expense), net | 460 |  |  | (10) |  |  | 396 |  |  | 79 |  |
| Total other income/(expense), net | $ | 508 |  |  | $ | 282 |  |  | $ | 553 |  |  | $ | 631 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000320193-21-000056:notes:98]
[same as prior period, unchanged from 0000320193-21-000010:notes:97]

[0000320193-21-000056:notes:99]
As of March 27, 2021, the total amount of gross unrecognized tax benefits was $16.9 billion, of which $8.3 billion, if recognized, would impact the Company’s effective tax rate. The Company had accrued $1.6 billion of gross interest and penalties related to income tax matters as of March 27, 2021.

[0000320193-21-000056:notes:100]
The Company is subject to taxation and files income tax returns in the U.S. federal jurisdiction and many state and foreign jurisdictions. The U.S. Internal Revenue Service concluded its review of the years 2013 through 2015 in 2018, and all years before 2016 are closed. Tax years after 2014 remain open in certain major foreign jurisdictions and are subject to examination by the taxing authorities. The Company believes that an adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax audits cannot be predicted with certainty. If any issues addressed in the Company’s tax audits are resolved in a manner inconsistent with its expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. Although the timing of resolution and/or closure of audits is not certain, the Company believes it is reasonably possible that its gross unrecognized tax benefits could decrease in the next 12 months by as much as $3.1 billion.

[0000320193-21-000056:notes:101]
[same as prior period, unchanged from 0000320193-21-000010:notes:100]

[0000320193-21-000056:notes:102]
[same as prior period, unchanged from 0000320193-21-000010:notes:101]

[0000320193-21-000056:notes:103]
On an annual basis, the Company may request approval from the Irish Minister for Finance to reduce the recovery amount for certain taxes paid to other countries. As of March 27, 2021, the adjusted recovery amount was €12.9 billion, excluding interest. The adjusted recovery amount plus interest is funded into escrow, where it will remain restricted from general use pending the conclusion of all legal proceedings. Refer to the Cash, Cash Equivalents and Marketable Securities section of Note 3, “Financial Instruments” for more information.


## us-gaap:DebtDisclosureTextBlock

[0000320193-21-000056:notes:104]
Debt
Commercial Paper and Repurchase Agreement

[0000320193-21-000056:notes:105]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of both March 27, 2021 and September 26, 2020, the Company had $5.0 billion of Commercial Paper outstanding, with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 0.06% and 0.62% as of March 27, 2021 and September 26, 2020, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the six months ended March 27, 2021 and March 28, 2020 (in millions):

[0000320193-21-000056:notes:106]
|  | Six Months Ended |
|  | March 27,2021 |  | March 28,2020 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from commercial paper, net | $ | 2,008 |  |  | $ | 1,377 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 1,368 |  |  | 4,797 |  |
| Repayments of commercial paper | (3,354) |  |  | (4,656) |  |
| Proceeds from/(Repayments of) commercial paper, net | (1,986) |  |  | 141 |  |
| Total proceeds from commercial paper, net | $ | 22 |  |  | $ | 1,518 |  |

[0000320193-21-000056:notes:107]
In the second quarter of 2020, the Company entered into an agreement to sell certain of its marketable securities with a promise to repurchase the securities at a specified time and amount (“Repo”). Due to the Company’s continuing involvement with the marketable securities, the Company accounted for the Repo as a collateralized borrowing. As of September 26, 2020, the Repo had been settled.

[0000320193-21-000056:notes:108]
Term Debt

[0000320193-21-000056:notes:109]
As of March 27, 2021, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $116.0 billion (collectively the “Notes”). The Notes are senior unsecured obligations and interest is payable in arrears. The following table provides a summary of the Company’s term debt as of March 27, 2021 and September 26, 2020:

[0000320193-21-000056:notes:110]
|  | Maturities(calendar year) |  | March 27, 2021 |  | September 26, 2020 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 – 2020 debt issuances: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2022 |  | $ | 1,750 |  |  | 0.55% – 0.69% |  | $ | 2,250 |  |  | 0.60% – 1.39% |
| Fixed-rate 0.000% – 4.650% notes | 2021 – 2060 |  | 100,255 |  |  | 0.03% – 4.78% |  | 103,828 |  |  | 0.03% – 4.78% |
| 2021 debt issuance: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.700% – 2.800% notes | 2026 – 2061 |  | 14,000 |  |  | 0.75% – 2.81% |  | — |  |  | — | % |
| Total term debt |  |  | 116,005 |  |  |  |  | 106,078 |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  | (371) |  |  |  |  | (314) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 1,011 |  |  |  |  | 1,676 |  |  |  |
| Less: Current portion of term debt |  |  | (8,003) |  |  |  |  | (8,773) |  |  |  |
| Total non-current portion of term debt |  |  | $ | 108,642 |  |  |  |  | $ | 98,667 |  |  |  |

[0000320193-21-000056:notes:111]
To manage interest rate risk on certain of its U.S. dollar–denominated fixed- or floating-rate notes, the Company has entered into interest rate swaps to effectively convert the fixed interest rates to floating interest rates or the floating interest rates to fixed interest rates on a portion of these notes. Additionally, to manage foreign currency risk on certain of its foreign currency–denominated notes, the Company has entered into foreign currency swaps to effectively convert these notes to U.S. dollar–denominated notes.

[0000320193-21-000056:notes:112]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $657 million and $1.3 billion of interest cost on its term debt for the three- and six-month periods ended March 27, 2021, respectively. The Company recognized $725 million and $1.5 billion of interest cost on its term debt for the three- and six-month periods ended March 28, 2020, respectively.

[0000320193-21-000056:notes:113]
As of March 27, 2021 and September 26, 2020, the fair value of the Company’s Notes, based on Level 2 inputs, was $121.2 billion and $117.1 billion, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000320193-21-000056:notes:114]
[same as prior period, unchanged from 0000320193-21-000010:notes:112]

[0000320193-21-000056:notes:115]
As of March 27, 2021, the Company was authorized to purchase up to $225 billion of the Company’s common stock under a share repurchase program (the “Program”). During the six months ended March 27, 2021, the Company repurchased 347 million shares of its common stock for $43.0 billion, bringing the total utilization under the Program to $211.6 billion. On April 28, 2021, the Company announced the Board of Directors increased the Program authorization by $90 billion. The Program does not obligate the Company to acquire any specific number of shares. Under the Program, shares may be repurchased in privately negotiated and/or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000320193-21-000056:notes:116]
[same as prior period, unchanged from 0000320193-21-000010:notes:114]

[0000320193-21-000056:notes:117]
The following table shows the pre-tax amounts reclassified from AOCI into the Condensed Consolidated Statements of Operations, and the associated financial statement line items, for the three- and six-month periods ended March 27, 2021 and March 28, 2020 (in millions):

[0000320193-21-000056:notes:118]
|  |  |  |  | Three Months Ended |  | Six Months Ended |
| Comprehensive Income Components |  | Financial Statement Line Items |  | March 27,2021 |  | March 28,2020 |  | March 27,2021 |  | March 28,2020 |
| Unrealized (gains)/losses on derivative instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Total net sales |  | $ | 314 |  |  | $ | 34 |  |  | $ | 418 |  |  | $ | (63) |  |
|  |  | Total cost of sales |  | 406 |  |  | 12 |  |  | 651 |  |  | (159) |  |
|  |  | Other income/(expense), net |  | 193 |  |  | 771 |  |  | (435) |  |  | 548 |  |
| Interest rate contracts |  | Other income/(expense), net |  | 2 |  |  | 1 |  |  | 5 |  |  | 3 |  |
|  |  |  |  | 915 |  |  | 818 |  |  | 639 |  |  | 329 |  |
| Unrealized (gains)/losses on marketable debt securities |  | Other income/(expense), net |  | (96) |  |  | 37 |  |  | (214) |  |  | 24 |  |
| Total amounts reclassified from AOCI |  | $ | 819 |  |  | $ | 855 |  |  | $ | 425 |  |  | $ | 353 |  |

[0000320193-21-000056:notes:119]
The following table shows the changes in AOCI by component for the six months ended March 27, 2021 (in millions):

[0000320193-21-000056:notes:120]
|  | Cumulative ForeignCurrency Translation |  | Unrealized Gains/Losseson Derivative Instruments |  | Unrealized Gains/Losseson Marketable Debt Securities |  | Total |
| Balances as of September 26, 2020 | $ | (1,375) |  |  | $ | (877) |  |  | $ | 1,846 |  |  | $ | (406) |  |
| Other comprehensive income/(loss) before reclassifications | 471 |  |  | 111 |  |  | (1,067) |  |  | (485) |  |
| Amounts reclassified from AOCI | — |  |  | 639 |  |  | (214) |  |  | 425 |  |
| Tax effect | — |  |  | (146) |  |  | 326 |  |  | 180 |  |
| Other comprehensive income/(loss) | 471 |  |  | 604 |  |  | (955) |  |  | 120 |  |
| Balances as of March 27, 2021 | $ | (904) |  |  | $ | (273) |  |  | $ | 891 |  |  | $ | (286) |  |


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000320193-21-000056:notes:121]
[same as prior period, unchanged from 0000320193-21-000010:notes:119]

[0000320193-21-000056:notes:122]
The Company had 718 million shares reserved for future issuance under its stock plans as of March 27, 2021. RSUs granted under the Company’s stock plans generally vest over four years, based on continued employment, and are settled upon vesting in shares of the Company’s common stock on a one-for-one basis. RSUs granted under the Company’s stock plans reduce the number of shares available for grant under the plans by a factor of two times the number of RSUs granted. RSUs canceled and shares withheld to satisfy tax withholding obligations increase the number of shares available for grant under the plans utilizing a factor of two times the number of RSUs canceled or shares withheld.

[0000320193-21-000056:notes:123]
[same as prior period, unchanged from 0000320193-21-000010:notes:121]

[0000320193-21-000056:notes:124]
During the three months ended March 27, 2021, Section 16 officers Katherine L. Adams, Timothy D. Cook, Chris Kondo, Luca Maestri, Deirdre O’Brien and Jeffrey Williams had equity trading plans in place in accordance with Rule 10b5-1(c)(1) under the Exchange Act. An equity trading plan is a written document that pre-establishes the amounts, prices and dates (or formula for determining the amounts, prices and dates) of future purchases or sales of the Company’s stock, including shares acquired under the Company’s employee and director equity plans.

[0000320193-21-000056:notes:125]
[same as prior period, unchanged from 0000320193-21-000010:notes:123]

[0000320193-21-000056:notes:126]
A summary of the Company’s RSU activity and related information for the six months ended March 27, 2021 is as follows:

[0000320193-21-000056:notes:127]
|  | Number ofRSUs(in thousands) |  | Weighted-AverageGrant Date FairValue Per RSU |  | AggregateFair Value(in millions) |
| Balance as of September 26, 2020 | 310,778 |  |  | $ | 51.58 |  |  |  |
| RSUs granted | 79,068 |  |  | $ | 113.39 |  |  |  |
| RSUs vested | (75,295) |  |  | $ | 45.83 |  |  |  |
| RSUs canceled | (5,918) |  |  | $ | 63.67 |  |  |  |
| Balance as of March 27, 2021 | 308,633 |  |  | $ | 68.58 |  |  | $ | 37,409 |  |

[0000320193-21-000056:notes:128]
The fair value as of the respective vesting dates of RSUs was $867 million and $9.4 billion for the three- and six-month periods ended March 27, 2021, respectively, and was $558 million and $4.8 billion for the three- and six-month periods ended March 28, 2020, respectively.

[0000320193-21-000056:notes:129]
[same as prior period, unchanged from 0000320193-21-000010:notes:127]

[0000320193-21-000056:notes:130]
The following table shows share-based compensation expense and the related income tax benefit included in the Condensed Consolidated Statements of Operations for the three- and six-month periods ended March 27, 2021 and March 28, 2020 (in millions):

[0000320193-21-000056:notes:131]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27,2021 |  | March 28,2020 |  | March 27,2021 |  | March 28,2020 |
| Share-based compensation expense | $ | 1,981 |  |  | $ | 1,697 |  |  | $ | 4,001 |  |  | $ | 3,407 |  |
| Income tax benefit related to share-based compensation expense | $ | (575) |  |  | $ | (444) |  |  | $ | (2,199) |  |  | $ | (1,202) |  |

[0000320193-21-000056:notes:132]
As of March 27, 2021, the total unrecognized compensation cost related to outstanding RSUs and stock options was $16.7 billion, which the Company expects to recognize over a weighted-average period of 2.8 years.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000320193-21-000056:notes:133]
Commitments and Contingencies
Accrued Warranty and Guarantees

[0000320193-21-000056:notes:134]
The following table shows changes in the Company’s accrued warranties and related costs for the three- and six-month periods ended March 27, 2021 and March 28, 2020 (in millions):

[0000320193-21-000056:notes:135]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27,2021 |  | March 28,2020 |  | March 27,2021 |  | March 28,2020 |
| Beginning accrued warranty and related costs | $ | 4,124 |  |  | $ | 3,873 |  |  | $ | 3,354 |  |  | $ | 3,570 |  |
| Cost of warranty claims | (649) |  |  | (689) |  |  | (1,372) |  |  | (1,604) |  |
| Accruals for product warranty | 309 |  |  | 739 |  |  | 1,802 |  |  | 1,957 |  |
| Ending accrued warranty and related costs | $ | 3,784 |  |  | $ | 3,923 |  |  | $ | 3,784 |  |  | $ | 3,923 |  |

[0000320193-21-000056:notes:136]
The Company offers an iPhone Upgrade Program, which is available to customers who purchase a qualifying iPhone in the U.S., the U.K. and China mainland. The iPhone Upgrade Program provides customers the right to trade in that iPhone for a specified amount when purchasing a new iPhone, provided certain conditions are met. The Company accounts for the trade-in right as a guarantee liability and recognizes arrangement revenue net of the fair value of such right, with subsequent changes to the guarantee liability recognized within net sales.

[0000320193-21-000056:notes:137]
Concentrations in the Available Sources of Supply of Materials and Product

[0000320193-21-000056:notes:138]
Although most components essential to the Company’s business are generally available from multiple sources, certain components are currently obtained from single or limited sources. The Company also competes for various components with other participants in the markets for smartphones, personal computers, tablets and other electronic devices. Therefore, many components used by the Company, including those that are available from multiple sources, are at times subject to industry-wide shortage and significant commodity pricing fluctuations.

[0000320193-21-000056:notes:139]
The Company uses some custom components that are not commonly used by its competitors, and new products introduced by the Company often utilize custom components available from only one source. When a component or product uses new technologies, initial capacity constraints may exist until the suppliers’ yields have matured or their manufacturing capacities have increased. The continued availability of these components at acceptable prices, or at all, may be affected if suppliers decide to concentrate on the production of common components instead of components customized to meet the Company’s requirements.

[0000320193-21-000056:notes:140]
The Company has entered into agreements for the supply of many components; however, there can be no guarantee that the Company will be able to extend or renew these agreements on similar terms, or at all.

[0000320193-21-000056:notes:141]
Substantially all of the Company’s hardware products are manufactured by outsourcing partners that are located primarily in Asia, with some Mac computers manufactured in the U.S. and Ireland.

[0000320193-21-000056:notes:142]
Unconditional Purchase Obligations

[0000320193-21-000056:notes:143]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of payments for content creation, Internet and telecommunications services and supplier arrangements. As of March 27, 2021, the Company’s total future payments under noncancelable unconditional purchase obligations having a remaining term in excess of one year were $8.2 billion.

[0000320193-21-000056:notes:144]
Contingencies

[0000320193-21-000056:notes:145]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully resolved. The outcome of litigation is inherently uncertain. When a loss related to a legal proceeding or claim is probable and reasonably estimable, the Company accrues its best estimate for the ultimate resolution of the matter. If one or more legal matters were resolved against the Company in a reporting period for amounts above management’s expectations, the Company’s financial condition and operating results for that reporting period could be materially adversely affected. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss greater than a recorded accrual, concerning loss contingencies for asserted legal and other claims, except for the following matters:

[0000320193-21-000056:notes:146]
VirnetX

[0000320193-21-000056:notes:147]
VirnetX, Inc. (“VirnetX”) filed a lawsuit against the Company alleging that certain of the Company’s products infringe on patents owned by VirnetX. On April 11, 2018, a jury returned a verdict against the Company in the U.S. District Court for the Eastern District of Texas (the “Eastern Texas District Court”). The Company appealed the verdict to the U.S. Court of Appeals for the Federal Circuit, which remanded the case back to the Eastern Texas District Court, where a re-trial was held in October 2020. The jury returned a verdict against the Company and awarded damages of $503 million, which the Company has appealed. The Company has challenged the validity of the patents at issue in the re-trial at the U.S. Patent and Trademark Office (the “PTO”), and the PTO has declared the patents invalid, subject to further appeal by VirnetX.

[0000320193-21-000056:notes:148]
iOS Performance Management Cases

[0000320193-21-000056:notes:149]
On April 5, 2018, several U.S. federal actions alleging violation of consumer protection laws, fraud, computer intrusion and other causes of action related to the Company’s performance management feature used in its iPhone operating systems, introduced to certain iPhones in iOS updates 10.2.1 and 11.2, were consolidated through a Multidistrict Litigation process into a single action in the U.S. District Court for the Northern District of California (the “Northern California District Court”). On February 28, 2020, the parties in the Multidistrict Litigation reached a settlement to resolve the U.S. federal and California state class actions. On March 18, 2021, the Northern California District Court granted final approval of the Multidistrict Litigation settlement, which will result in an aggregate payment of $310 million to settle all claims. The Company continues to believe that its iPhones were not defective, that the performance management feature introduced with iOS updates 10.2.1 and 11.2 was intended to, and did, improve customers’ user experience, and that the Company did not make any misleading statements or fail to disclose any material information.

[0000320193-21-000056:notes:150]
French Competition Authority

[0000320193-21-000056:notes:151]
On March 16, 2020, the French Competition Authority (“FCA”) announced its decision that aspects of the Company’s sales and distribution practices in France violate French competition law and issued a fine of €1.1 billion. The Company strongly disagrees with the FCA’s decision and has appealed.

[0000320193-21-000056:notes:152]
Optis

[0000320193-21-000056:notes:153]
Optis Wireless Technology, LLC and related entities (“Optis”) filed a lawsuit in the U.S. District Court for the Eastern District of Texas against the Company alleging that certain of the Company’s products infringe on patents owned by Optis. On August 11, 2020, a jury returned a verdict against the Company and awarded damages of $506 million. In post-trial proceedings, the damages portion of the verdict was set aside, and the case remains pending further proceedings.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000320193-21-000056:notes:154]
[same as prior period, unchanged from 0000320193-21-000010:notes:152]

[0000320193-21-000056:notes:155]
[same as prior period, unchanged from 0000320193-21-000010:notes:153]

[0000320193-21-000056:notes:156]
[same as prior period, unchanged from 0000320193-21-000010:notes:154]

[0000320193-21-000056:notes:157]
The following table shows information by reportable segment for the three- and six-month periods ended March 27, 2021 and March 28, 2020 (in millions):

[0000320193-21-000056:notes:158]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27,2021 |  | March 28,2020 |  | March 27,2021 |  | March 28,2020 |
| Americas: |  |  |  |  |  |  |  |
| Net sales | $ | 34,306 |  |  | $ | 25,473 |  |  | $ | 80,616 |  |  | $ | 66,840 |  |
| Operating income | $ | 12,050 |  |  | $ | 7,261 |  |  | $ | 27,835 |  |  | $ | 20,353 |  |
| Europe: |  |  |  |  |  |  |  |
| Net sales | $ | 22,264 |  |  | $ | 14,294 |  |  | $ | 49,570 |  |  | $ | 37,567 |  |
| Operating income | $ | 8,265 |  |  | $ | 4,528 |  |  | $ | 17,854 |  |  | $ | 12,247 |  |
| Greater China: |  |  |  |  |  |  |  |
| Net sales | $ | 17,728 |  |  | $ | 9,455 |  |  | $ | 39,041 |  |  | $ | 23,033 |  |
| Operating income | $ | 7,758 |  |  | $ | 3,758 |  |  | $ | 16,288 |  |  | $ | 9,121 |  |
| Japan: |  |  |  |  |  |  |  |
| Net sales | $ | 7,742 |  |  | $ | 5,206 |  |  | $ | 16,027 |  |  | $ | 11,429 |  |
| Operating income | $ | 3,428 |  |  | $ | 2,236 |  |  | $ | 6,931 |  |  | $ | 5,014 |  |
| Rest of Asia Pacific: |  |  |  |  |  |  |  |
| Net sales | $ | 7,544 |  |  | $ | 3,885 |  |  | $ | 15,769 |  |  | $ | 11,263 |  |
| Operating income | $ | 2,736 |  |  | $ | 1,290 |  |  | $ | 5,689 |  |  | $ | 4,021 |  |

[0000320193-21-000056:notes:159]
A reconciliation of the Company’s segment operating income to the Condensed Consolidated Statements of Operations for the three- and six-month periods ended March 27, 2021 and March 28, 2020 is as follows (in millions):

[0000320193-21-000056:notes:160]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27,2021 |  | March 28,2020 |  | March 27,2021 |  | March 28,2020 |
| Segment operating income | $ | 34,237 |  |  | $ | 19,073 |  |  | $ | 74,597 |  |  | $ | 50,756 |  |
| Research and development expense | (5,262) |  |  | (4,565) |  |  | (10,425) |  |  | (9,016) |  |
| Other corporate expenses, net | (1,472) |  |  | (1,655) |  |  | (3,135) |  |  | (3,318) |  |
| Total operating income | $ | 27,503 |  |  | $ | 12,853 |  |  | $ | 61,037 |  |  | $ | 38,422 |  |
