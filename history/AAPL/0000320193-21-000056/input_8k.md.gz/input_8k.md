# AAPL 8-K — 0000320193-21-000055 filed 2021-04-28

## item codes, every 8-K on or before 2021-04-29

- 2021-04-28 0000320193-21-000055 — 2.02, 9.01
- 2021-02-24 0001193125-21-054710 — 5.07
- 2021-02-08 0001193125-21-032394 — 8.01, 9.01
- 2021-01-27 0000320193-21-000009 — 2.02, 9.01
- 2021-01-05 0001193125-21-001982 — 5.02
- 2020-10-29 0000320193-20-000094 — 2.02, 9.01
- 2020-08-20 0001193125-20-225672 — 8.01, 9.01
- 2020-08-07 0001193125-20-213158 — 5.03, 9.01
- 2020-07-30 0000320193-20-000060 — 2.02, 9.01
- 2020-05-11 0001193125-20-139112 — 8.01, 9.01
- 2020-04-30 0000320193-20-000050 — 2.02, 9.01
- 2020-02-27 0001193125-20-050884 — 5.07
- 2020-02-18 0001193125-20-039203 — 7.01, 9.01
- 2020-01-28 0000320193-20-000008 — 2.02, 9.01
- 2019-11-15 0001193125-19-292676 — 8.01, 9.01
- 2019-10-30 0000320193-19-000117 — 2.02, 9.01
- 2019-09-13 0000320193-19-000093 — 5.02
- 2019-09-11 0001193125-19-242975 — 8.01, 9.01
- 2019-07-30 0000320193-19-000073 — 2.02, 9.01
- 2019-04-30 0000320193-19-000063 — 2.02, 9.01
- 2019-03-04 0000320193-19-000032 — 5.07
- 2019-02-06 0000320193-19-000026 — 5.02
- 2019-01-29 0000320193-19-000007 — 2.02, 9.01
- 2019-01-02 0000320193-19-000002 — 2.02, 9.01
- 2018-11-01 0000320193-18-000142 — 2.02, 9.01
- 2018-07-31 0000320193-18-000098 — 2.02, 9.01
- 2018-05-08 0001193125-18-154948 — 8.01 — amendment of 0001193125-18-154515
- 2018-05-07 0001193125-18-154515 — 8.01, 9.01
- 2018-05-01 0000320193-18-000067 — 2.02, 9.01
- 2018-02-14 0001193125-18-045761 — 5.07, 9.01
- 2018-02-01 0000320193-18-000005 — 2.02, 9.01
- 2017-11-13 0001193125-17-341015 — 8.01, 9.01
- 2017-11-02 0000320193-17-000067 — 2.02, 9.01
- 2017-10-12 0001193125-17-308859 — 5.02
- 2017-09-12 0001193125-17-282809 — 8.01, 9.01
- 2017-08-18 0001193125-17-262261 — 8.01, 9.01
- 2017-08-01 0000320193-17-000006 — 2.02, 9.01
- 2017-06-20 0001193125-17-208226 — 8.01, 9.01
- 2017-05-24 0001193125-17-181867 — 8.01, 9.01
- 2017-05-11 0001193125-17-167400 — 8.01, 9.01
- 2017-05-02 0001628280-17-004663 — 2.02, 9.01
- 2017-03-03 0001193125-17-069853 — 8.01, 9.01
- 2017-03-01 0001193125-17-064019 — 5.07
- 2017-02-09 0001193125-17-036283 — 8.01, 9.01
- 2017-01-31 0001628280-17-000663 — 2.02, 9.01
- 2016-12-15 0001628280-16-022047 — 5.03, 9.01
- 2016-10-25 0001628280-16-020258 — 2.02, 9.01
- 2016-08-04 0001193125-16-672044 — 8.01, 9.01
- 2016-07-26 0001628280-16-017762 — 2.02, 9.01
- 2016-06-22 0001193125-16-628957 — 8.01, 9.01
- 2016-04-26 0001193125-16-556520 — 2.02, 9.01
- 2016-03-24 0001193125-16-516891 — 8.01, 9.01
- 2016-03-01 0001193125-16-488223 — 5.02, 5.07, 9.01
- 2016-02-23 0001193125-16-473562 — 8.01, 9.01
- 2016-01-26 0001193125-16-438421 — 2.02, 9.01
- 2015-12-22 0001193125-15-410853 — 5.03, 9.01
- 2015-12-17 0001193125-15-406279 — 5.02
- 2015-10-27 0001193125-15-354756 — 2.02, 9.01
- 2015-10-02 0001193125-15-336615 — 5.02
- 2015-09-17 0001193125-15-322466 — 8.01, 9.01
- 2015-07-31 0001193125-15-273023 — 8.01, 9.01
- 2015-07-21 0001193125-15-258464 — 2.02, 9.01
- 2015-06-10 0001193125-15-219298 — 8.01, 9.01
- 2015-05-13 0001193125-15-186064 — 8.01, 9.01
- 2015-04-27 0001193125-15-149607 — 7.01, 9.01
- 2015-04-27 0001193125-15-149590 — 2.02, 9.01
- 2015-03-13 0001104659-15-019336 — 5.07, 9.01
- 2015-02-09 0001193125-15-039270 — 8.01, 9.01
- 2015-01-28 0001193125-15-023732 — 8.01, 9.01
- 2015-01-27 0001193125-15-021857 — 2.02, 9.01
- 2014-11-10 0001193125-14-406296 — 8.01, 9.01
- 2014-10-20 0001193125-14-376361 — 2.02, 9.01
- 2014-07-23 0001193125-14-277193 — 8.01, 9.01
- 2014-07-22 0001193125-14-275598 — 2.02, 9.01
- 2014-07-17 0001193125-14-271698 — 5.02
- 2014-06-06 0001193125-14-228798 — 5.03, 9.01
- 2014-05-30 0001181431-14-021923 — 5.02
- 2014-05-06 0001193125-14-184969 — 8.01, 9.01
- 2014-04-23 0001193125-14-154883 — 7.01, 9.01
- 2014-04-23 0001193125-14-154871 — 2.02, 9.01
- 2014-03-05 0001193125-14-084697 — 5.02, 5.03, 5.07, 9.01
- 2014-01-27 0001193125-14-022238 — 2.02, 9.01
- 2013-10-28 0001193125-13-413498 — 2.02, 9.01
- 2013-09-23 0001181431-13-050140 — 8.01
- 2013-07-30 0001181431-13-041847 — 5.02
- 2013-07-23 0001193125-13-298914 — 2.02, 9.01
- 2013-06-21 0001193125-13-267629 — 5.02
- 2013-05-03 0001193125-13-199324 — 8.01, 9.01
- 2013-04-24 0001193125-13-170623 — 8.01, 9.01
- 2013-04-23 0001193125-13-167469 — 7.01, 9.01
- 2013-04-23 0001193125-13-167458 — 2.02, 9.01
- 2013-03-01 0001193125-13-085842 — 5.07
- 2013-01-23 0001193125-13-020783 — 2.02, 9.01
- 2012-10-25 0001193125-12-435506 — 2.02, 9.01
- 2012-07-24 0001193125-12-312355 — 2.02, 9.01
- 2012-06-28 0001181431-12-038301 — 5.02
- 2012-05-24 0001181431-12-032458 — 5.02
- 2012-04-24 0001193125-12-178928 — 2.02, 9.01
- 2012-02-27 0001193125-12-081892 — 5.07
- 2012-01-24 0001193125-12-021833 — 2.02, 9.01
- 2011-11-16 0001181431-11-056354 — 5.02
- 2011-10-18 0001193125-11-273826 — 2.02, 9.01
- 2011-10-06 0001181431-11-051976 — 8.01
- 2011-08-26 0001181431-11-047179 — 5.02
- 2011-07-19 0001193125-11-191368 — 2.02, 9.01
- 2011-06-15 0001181431-11-036782 — 5.02
- 2011-04-20 0001193125-11-103732 — 2.02, 9.01
- 2011-02-24 0001193125-11-045411 — 5.07
- 2011-01-18 0001193125-11-009392 — 2.02, 9.01
- 2011-01-18 0001181431-11-003847 — 5.02
- 2010-11-17 0001181431-10-056327 — 5.02, 5.03, 9.01
- 2010-10-18 0001193125-10-230992 — 2.02, 9.01
- 2010-07-20 0001193125-10-161807 — 2.02, 9.01
- 2010-04-20 0001193125-10-087786 — 2.02, 9.01
- 2010-03-12 0001181431-10-016054 — 5.02
- 2010-03-01 0001193125-10-044765 — 5.02, 5.07, 9.01
- 2010-01-25 0001193125-10-012096 — 2.02, 9.01
- 2009-10-19 0001193125-09-209633 — 2.02, 9.01
- 2009-08-04 0001181431-09-037492 — 5.02
- 2009-07-21 0001193125-09-152290 — 2.02, 9.01
- 2009-06-02 0001181431-09-028400 — 5.03
- 2009-04-22 0001193125-09-084599 — 2.02, 9.01
- 2009-02-27 0001181431-09-012161 — 4.01
- 2009-01-21 0001193125-09-009009 — 2.02, 9.01
- 2009-01-16 0001181431-09-003017 — 5.02
- 2008-10-21 0001193125-08-213642 — 2.02, 9.01
- 2008-08-26 0001181431-08-050059 — 5.03
- 2008-07-21 0001193125-08-154381 — 2.02, 9.01
- 2008-06-09 0001181431-08-037620 — 8.01
- 2008-04-23 0001193125-08-088001 — 2.02, 9.01
- 2008-01-22 0001193125-08-009715 — 2.02, 9.01
- 2008-01-15 0001181431-08-003342 — 2.02, 8.01
- 2008-01-08 0001181431-08-002372 — 5.02
- 2007-10-22 0001104659-07-076142 — 2.02, 9.01
- 2007-07-25 0001104659-07-056111 — 2.02, 9.01
- 2007-05-16 0001104659-07-040672 — 5.02, 9.01
- 2007-04-25 0001104659-07-031354 — 2.02, 9.01
- 2007-04-24 0001104659-07-030938 — 8.01, 9.01
- 2007-02-21 0001104659-07-012760 — 5.03, 9.01
- 2007-01-17 0001104659-07-002905 — 2.02, 9.01
- 2007-01-10 0001104659-07-001648 — 5.03, 9.01
- 2006-10-27 0001104659-06-069015 — 8.01
- 2006-10-18 0001104659-06-067275 — 2.02, 9.01
- 2006-10-04 0001104659-06-064935 — 5.02, 8.01, 9.01
- 2006-09-01 0001104659-06-058808 — 1.01, 5.02, 5.03, 9.01
- 2006-08-11 0001104659-06-054118 — 2.02, 3.01, 9.01
- 2006-08-04 0001104659-06-051302 — 2.02, 4.02, 9.01
- 2006-07-19 0001104659-06-047739 — 2.02, 9.01
- 2006-04-21 0001181431-06-024759 — 1.01
- 2006-04-19 0001104659-06-025992 — 2.02, 9.01
- 2006-01-18 0001104659-06-002690 — 2.02, 9.01
- 2006-01-10 0001104659-06-001428 — 2.02
- 2005-12-19 0001181431-05-067468 — 1.01
- 2005-10-14 0001181431-05-056604 — 5.02
- 2005-10-11 0001104659-05-048094 — 2.02, 9.01
- 2005-08-26 0001181431-05-049163 — 1.01
- 2005-08-15 0001181431-05-046871 — 1.01
- 2005-07-13 0001104659-05-032297 — 2.02, 9.01
- 2005-06-06 0001181431-05-033177 — 8.01
- 2005-04-26 0001181431-05-023450 — 1.01
- 2005-04-13 0001104659-05-016307 — 2.02, 9.01
- 2005-03-02 0001181431-05-013840 — 3.03, 5.03
- 2005-02-11 0001104659-05-005507 — 8.01
- 2005-01-12 0001104659-05-001183 — 2.02, 9.01
- 2005-01-11 0001104659-05-001049 — 2.02
- 2004-10-13 0001104659-04-030400 — 2.02, 9.01
- 2004-07-14 0001104659-04-019574 — 12, 7
- 2004-04-14 0001104659-04-010122 — 12, 7
- 2004-01-14 0001104659-04-000896 — 12, 7
- 2003-10-15 0001104659-03-022879 — 12, 7
- 2003-07-16 0001104659-03-014913 — 7, 9
- 2003-04-16 0001047469-03-013617 — 7, 9
- 2003-03-21 0001104659-03-004649 — 5, 7
- 2002-08-13 0000912057-02-031595 — 5, 7
- 2002-08-05 0000912057-02-029692 — 5, 7
- 2000-01-24 0000912057-00-002128 — 5, 7
- 1999-09-07 0000320193-99-000010 — 2
- 1999-07-16 0000320193-99-000007 — 2
- 1998-12-23 0000320193-98-000010 — 1
- 1998-01-08 0000320193-98-000001 — 2
- 1997-09-25 0000320193-97-000019 — 2
- 1997-09-25 0000320193-97-000018 — 2
- 1997-09-05 0000320193-97-000016 — 2
- 1997-07-28 0000320193-97-000012 — 4
- 1997-04-25 0000320193-97-000009 — 5
- 1997-04-10 0000320193-97-000007 — 7
- 1996-12-24 0000320193-96-000027 — 7
- 1996-12-23 0000320193-96-000025 — 4 — amendment of 0000320193-96-000021
- 1996-12-13 0000320193-96-000021 — 4
- 1996-10-28 0000912057-96-023874 — 5, 7
- 1996-06-17 0000320193-96-000014 — 1
- 1996-04-12 0000320193-96-000006 — 1

## late-filing notifications on or before 2021-04-29

- 2006-12-15 0001104659-06-081617 — NT 10-K, for the period ended 2006-09-30
- 2006-08-11 0001104659-06-053743 — NT 10-Q, for the period ended 2006-07-01

## item 2.02 — earnings release, exhibit 99.1

[0000320193-21-000055:8k_2_02:1]
EX-99.1
2
a8-kex991q2202103272021.htm
EX-99.1

[0000320193-21-000055:8k_2_02:2]
Document

[0000320193-21-000055:8k_2_02:3]
Exhibit 99.1

[0000320193-21-000055:8k_2_02:4]
Apple Reports Second Quarter Results

[0000320193-21-000055:8k_2_02:5]
Revenue up 54 percent to new March quarter record

[0000320193-21-000055:8k_2_02:6]
Services and Mac revenue reach new all-time high

[0000320193-21-000055:8k_2_02:7]
CUPERTINO, California — April 28, 2021 — Apple® today announced financial results for its fiscal 2021 second quarter ended March 27, 2021. The Company posted a March quarter record revenue of $89.6 billion, up 54 percent year over year, and quarterly earnings per diluted share of $1.40. International sales accounted for 67 percent of the quarter’s revenue.

[0000320193-21-000055:8k_2_02:8]
“This quarter reflects both the enduring ways our products have helped our users meet this moment in their own lives, as well as the optimism consumers seem to feel about better days ahead for all of us,” said Tim Cook, Apple’s CEO. “Apple is in a period of sweeping innovation across our product lineup, and we’re keeping focus on how we can help our teams and the communities where we work emerge from this pandemic into a better world. That certainly begins with products like the all-new iMac and iPad Pro, but it extends to efforts like the 8 gigawatts of new clean energy we’ll help bring onto the grid and our $430 billion investment in the United States over the next 5 years.”

[0000320193-21-000055:8k_2_02:9]
“We are proud of our March quarter performance, which included revenue records in each of our geographic segments and strong double-digit growth in each of our product categories, driving our installed base of active devices to an all-time high,” said Luca Maestri, Apple’s CFO. “These results allowed us to generate operating cash flow of $24 billion and return nearly $23 billion to shareholders during the quarter. We are confident in our future and continue to make significant investments to support our long-term plans and enrich our customers’ lives.”

[0000320193-21-000055:8k_2_02:10]
Apple’s board of directors has declared a cash dividend of $0.22 per share of the Company’s common stock, an increase of 7 percent. The dividend is payable on May 13, 2021 to shareholders of record as of the close of business on May 10, 2021. The board of directors has also authorized an increase of $90 billion to the existing share repurchase program.

[0000320193-21-000055:8k_2_02:11]
Apple will provide live streaming of its Q2 2021 financial results conference call beginning at 2:00 p.m. PT on April 28, 2021 at apple.com/investor/earnings-call. This webcast will also be available for replay for approximately two weeks thereafter.

[0000320193-21-000055:8k_2_02:12]
Apple periodically provides information for investors on its corporate website, apple.com, and its investor relations website, investor.apple.com. This includes press releases and other information about financial performance, reports filed or furnished with the SEC, information on corporate governance, and details related to its annual meeting of shareholders.

[0000320193-21-000055:8k_2_02:13]
Apple revolutionized personal technology with the introduction of the Macintosh in 1984. Today, Apple leads the world in innovation with iPhone, iPad, Mac, Apple Watch, and Apple TV. Apple’s five software platforms — iOS, iPadOS, macOS, watchOS, and tvOS — provide seamless experiences across all Apple devices and empower people with breakthrough services including the App Store, Apple Music, Apple Pay, and iCloud. Apple’s more than 100,000 employees are dedicated to making the best products on earth, and to leaving the world better than we found it.

[0000320193-21-000055:8k_2_02:14]
Press Contact:

[0000320193-21-000055:8k_2_02:15]
Kristin Huguet

[0000320193-21-000055:8k_2_02:16]
Apple

[0000320193-21-000055:8k_2_02:17]
khuguet@apple.com

[0000320193-21-000055:8k_2_02:18]
(408) 974-2414

[0000320193-21-000055:8k_2_02:19]
Investor Relations Contact:

[0000320193-21-000055:8k_2_02:20]
Tejas Gala

[0000320193-21-000055:8k_2_02:21]
Apple

[0000320193-21-000055:8k_2_02:22]
tgala@apple.com

[0000320193-21-000055:8k_2_02:23]
(669) 227-2402

[0000320193-21-000055:8k_2_02:24]
NOTE TO EDITORS: For additional information visit Apple Newsroom (www.apple.com/newsroom), or call Apple’s Media Helpline at (408) 974-2042.

[0000320193-21-000055:8k_2_02:25]
© 2021 Apple Inc. All rights reserved. Apple and the Apple logo are trademarks of Apple. Other company and product names may be trademarks of their respective owners.

[0000320193-21-000055:8k_2_02:26]
Apple Inc.

[0000320193-21-000055:8k_2_02:27]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS (Unaudited)

[0000320193-21-000055:8k_2_02:28]
(In millions, except number of shares which are reflected in thousands and per share amounts)

[0000320193-21-000055:8k_2_02:29]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27,2021 |  | March 28,2020 |  | March 27,2021 |  | March 28,2020 |
| Net sales: |  |  |  |  |  |  |  |
| Products | $ | 72,683 |  |  | $ | 44,965 |  |  | $ | 168,361 |  |  | $ | 124,069 |  |
| Services | 16,901 |  |  | 13,348 |  |  | 32,662 |  |  | 26,063 |  |
| Total net sales (1) | 89,584 |  |  | 58,313 |  |  | 201,023 |  |  | 150,132 |  |
| Cost of sales: |  |  |  |  |  |  |  |
| Products | 46,447 |  |  | 31,321 |  |  | 108,577 |  |  | 83,396 |  |
| Services | 5,058 |  |  | 4,622 |  |  | 10,039 |  |  | 9,149 |  |
| Total cost of sales | 51,505 |  |  | 35,943 |  |  | 118,616 |  |  | 92,545 |  |
| Gross margin | 38,079 |  |  | 22,370 |  |  | 82,407 |  |  | 57,587 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 5,262 |  |  | 4,565 |  |  | 10,425 |  |  | 9,016 |  |
| Selling, general and administrative | 5,314 |  |  | 4,952 |  |  | 10,945 |  |  | 10,149 |  |
| Total operating expenses | 10,576 |  |  | 9,517 |  |  | 21,370 |  |  | 19,165 |  |
| Operating income | 27,503 |  |  | 12,853 |  |  | 61,037 |  |  | 38,422 |  |
| Other income/(expense), net | 508 |  |  | 282 |  |  | 553 |  |  | 631 |  |
| Income before provision for income taxes | 28,011 |  |  | 13,135 |  |  | 61,590 |  |  | 39,053 |  |
| Provision for income taxes | 4,381 |  |  | 1,886 |  |  | 9,205 |  |  | 5,568 |  |
| Net income | $ | 23,630 |  |  | $ | 11,249 |  |  | $ | 52,385 |  |  | $ | 33,485 |  |
| Earnings per share: |  |  |  |  |  |  |  |
| Basic | $ | 1.41 |  |  | $ | 0.64 |  |  | $ | 3.11 |  |  | $ | 1.91 |  |
| Diluted | $ | 1.40 |  |  | $ | 0.64 |  |  | $ | 3.08 |  |  | $ | 1.89 |  |
| Shares used in computing earnings per share: |  |  |  |  |  |  |  |
| Basic | 16,753,476 |  |  | 17,440,402 |  |  | 16,844,298 |  |  | 17,550,281 |  |
| Diluted | 16,929,157 |  |  | 17,618,765 |  |  | 17,021,423 |  |  | 17,718,591 |  |
| (1) Net sales by reportable segment: |  |  |  |  |  |  |  |
| Americas | $ | 34,306 |  |  | $ | 25,473 |  |  | $ | 80,616 |  |  | $ | 66,840 |  |
| Europe | 22,264 |  |  | 14,294 |  |  | 49,570 |  |  | 37,567 |  |
| Greater China | 17,728 |  |  | 9,455 |  |  | 39,041 |  |  | 23,033 |  |
| Japan | 7,742 |  |  | 5,206 |  |  | 16,027 |  |  | 11,429 |  |
| Rest of Asia Pacific | 7,544 |  |  | 3,885 |  |  | 15,769 |  |  | 11,263 |  |
| Total net sales | $ | 89,584 |  |  | $ | 58,313 |  |  | $ | 201,023 |  |  | $ | 150,132 |  |
| (1) Net sales by category: |  |  |  |  |  |  |  |
| iPhone | $ | 47,938 |  |  | $ | 28,962 |  |  | $ | 113,535 |  |  | $ | 84,919 |  |
| Mac | 9,102 |  |  | 5,351 |  |  | 17,777 |  |  | 12,511 |  |
| iPad | 7,807 |  |  | 4,368 |  |  | 16,242 |  |  | 10,345 |  |
| Wearables, Home and Accessories | 7,836 |  |  | 6,284 |  |  | 20,807 |  |  | 16,294 |  |
| Services | 16,901 |  |  | 13,348 |  |  | 32,662 |  |  | 26,063 |  |
| Total net sales | $ | 89,584 |  |  | $ | 58,313 |  |  | $ | 201,023 |  |  | $ | 150,132 |  |

[0000320193-21-000055:8k_2_02:30]
Apple Inc.

[0000320193-21-000055:8k_2_02:31]
CONDENSED CONSOLIDATED BALANCE SHEETS (Unaudited)

[0000320193-21-000055:8k_2_02:32]
(In millions, except number of shares which are reflected in thousands and par value)

[0000320193-21-000055:8k_2_02:33]
|  | March 27,2021 |  | September 26,2020 |
| ASSETS: |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 38,466 |  |  | $ | 38,016 |  |
| Marketable securities | 31,368 |  |  | 52,927 |  |
| Accounts receivable, net | 18,503 |  |  | 16,120 |  |
| Inventories | 5,219 |  |  | 4,061 |  |
| Vendor non-trade receivables | 14,533 |  |  | 21,325 |  |
| Other current assets | 13,376 |  |  | 11,264 |  |
| Total current assets | 121,465 |  |  | 143,713 |  |
| Non-current assets: |  |  |  |
| Marketable securities | 134,539 |  |  | 100,887 |  |
| Property, plant and equipment, net | 37,815 |  |  | 36,766 |  |
| Other non-current assets | 43,339 |  |  | 42,522 |  |
| Total non-current assets | 215,693 |  |  | 180,175 |  |
| Total assets | $ | 337,158 |  |  | $ | 323,888 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY: |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 40,127 |  |  | $ | 42,296 |  |
| Other current liabilities | 45,660 |  |  | 42,684 |  |
| Deferred revenue | 7,595 |  |  | 6,643 |  |
| Commercial paper | 5,000 |  |  | 4,996 |  |
| Term debt | 8,003 |  |  | 8,773 |  |
| Total current liabilities | 106,385 |  |  | 105,392 |  |
| Non-current liabilities: |  |  |  |
| Term debt | 108,642 |  |  | 98,667 |  |
| Other non-current liabilities | 52,953 |  |  | 54,490 |  |
| Total non-current liabilities | 161,595 |  |  | 153,157 |  |
| Total liabilities | 267,980 |  |  | 258,549 |  |
| Commitments and contingencies |  |  |  |
| Shareholders’ equity: |  |  |  |
| Common stock and additional paid-in capital, $0.00001 par value: 50,400,000 shares authorized; 16,686,305 and 16,976,763 shares issued and outstanding, respectively | 54,203 |  |  | 50,779 |  |
| Retained earnings | 15,261 |  |  | 14,966 |  |
| Accumulated other comprehensive income/(loss) | (286) |  |  | (406) |  |
| Total shareholders’ equity | 69,178 |  |  | 65,339 |  |
| Total liabilities and shareholders’ equity | $ | 337,158 |  |  | $ | 323,888 |  |

[0000320193-21-000055:8k_2_02:34]
Apple Inc.

[0000320193-21-000055:8k_2_02:35]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (Unaudited)

[0000320193-21-000055:8k_2_02:36]
(In millions)

[0000320193-21-000055:8k_2_02:37]
|  | Six Months Ended |
|  | March 27,2021 |  | March 28,2020 |
| Cash, cash equivalents and restricted cash, beginning balances | $ | 39,789 |  |  | $ | 50,224 |  |
| Operating activities: |  |  |  |
| Net income | 52,385 |  |  | 33,485 |  |
| Adjustments to reconcile net income to cash generated by operating activities: |  |  |  |
| Depreciation and amortization | 5,463 |  |  | 5,602 |  |
| Share-based compensation expense | 4,001 |  |  | 3,407 |  |
| Deferred income tax benefit | (207) |  |  | (651) |  |
| Other | (474) |  |  | (259) |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | (2,347) |  |  | 7,284 |  |
| Inventories | (1,226) |  |  | 699 |  |
| Vendor non-trade receivables | 6,792 |  |  | 7,923 |  |
| Other current and non-current assets | (4,333) |  |  | (8,866) |  |
| Accounts payable | (1,997) |  |  | (13,520) |  |
| Deferred revenue | 1,642 |  |  | 1,223 |  |
| Other current and non-current liabilities | 3,045 |  |  | 7,500 |  |
| Cash generated by operating activities | 62,744 |  |  | 43,827 |  |
| Investing activities: |  |  |  |
| Purchases of marketable securities | (74,424) |  |  | (66,489) |  |
| Proceeds from maturities of marketable securities | 39,605 |  |  | 39,738 |  |
| Proceeds from sales of marketable securities | 21,645 |  |  | 27,762 |  |
| Payments for acquisition of property, plant and equipment | (5,769) |  |  | (3,960) |  |
| Payments made in connection with business acquisitions, net | (9) |  |  | (1,134) |  |
| Other | — |  |  | (572) |  |
| Cash used in investing activities | (18,952) |  |  | (4,655) |  |
| Financing activities: |  |  |  |
| Proceeds from issuance of common stock | 561 |  |  | 430 |  |
| Payments for taxes related to net share settlement of equity awards | (3,160) |  |  | (1,566) |  |
| Payments for dividends and dividend equivalents | (7,060) |  |  | (6,914) |  |
| Repurchases of common stock | (43,323) |  |  | (39,280) |  |
| Proceeds from issuance of term debt, net | 13,923 |  |  | 2,210 |  |
| Repayments of term debt | (4,500) |  |  | (5,250) |  |
| Proceeds from commercial paper, net | 22 |  |  | 1,518 |  |
| Proceeds from repurchase agreement | — |  |  | 2,556 |  |
| Other | (38) |  |  | (51) |  |
| Cash used in financing activities | (43,575) |  |  | (46,347) |  |
| Increase/(Decrease) in cash, cash equivalents and restricted cash | 217 |  |  | (7,175) |  |
| Cash, cash equivalents and restricted cash, ending balances | $ | 40,006 |  |  | $ | 43,049 |  |
| Supplemental cash flow disclosure: |  |  |  |
| Cash paid for income taxes, net | $ | 10,276 |  |  | $ | 7,505 |  |
| Cash paid for interest | $ | 1,327 |  |  | $ | 1,689 |  |
