# AAPL MD&A — 0000320193-17-000009


## mdna

[0000320193-17-000009:mdna:1]
[same as prior period, unchanged from 0001628280-17-004790:mdna:1]

[0000320193-17-000009:mdna:2]
[same as prior period, unchanged from 0001628280-17-004790:mdna:2]

[0000320193-17-000009:mdna:3]
[same as prior period, unchanged from 0001628280-17-004790:mdna:3]

[0000320193-17-000009:mdna:4]
[same as prior period, unchanged from 0001628280-17-004790:mdna:4]

[0000320193-17-000009:mdna:5]
The Company designs, manufactures and markets mobile communication and media devices and personal computers, and sells a variety of related software, services, accessories, networking solutions and third-party digital content and applications. The Company’s products and services include iPhone®, iPad®, Mac®, Apple Watch®, Apple TV®, a portfolio of consumer and professional software applications, iOS, macOS®, watchOS® and tvOS™ operating systems, iCloud®, Apple Pay® and a variety of accessory, service and support offerings. The Company sells and delivers digital content and applications through the iTunes Store®, App Store®, Mac App Store, TV App Store, iBooks Store® and Apple Music® (collectively “Digital Content and Services”). The Company sells its products worldwide through its retail stores, online stores and direct sales force, as well as through third-party cellular network carriers, wholesalers, retailers and value-added resellers. In addition, the Company sells a variety of third-party Apple-compatible products, including application software and various accessories through its retail and online stores. The Company sells to consumers, small and mid-sized businesses and education, enterprise and government customers.

[0000320193-17-000009:mdna:6]
[same as prior period, unchanged from 0001628280-17-004790:mdna:6]

[0000320193-17-000009:mdna:7]
The Company is committed to bringing the best user experience to its customers through its innovative hardware, software and services. The Company’s business strategy leverages its unique ability to design and develop its own operating systems, hardware, application software and services to provide its customers products and solutions with innovative design, superior ease-of-use and seamless integration. As part of its strategy, the Company continues to expand its platform for the discovery and delivery of digital content and applications through its Digital Content and Services, which allows customers to discover and download digital content, iOS, Mac, Apple Watch and Apple TV applications, and books through either a Mac or Windows personal computer or through iPhone, iPad and iPod touch® devices (“iOS devices”), Apple TV and Apple Watch. The Company also supports a community for the development of third-party software and hardware products and digital content that complement the Company’s offerings. The Company believes a high-quality buying experience with knowledgeable salespersons who can convey the value of the Company’s products and services greatly enhances its ability to attract and retain customers. Therefore, the Company’s strategy also includes building and expanding its own retail and online stores and its third-party distribution network to effectively reach more customers and provide them with a high-quality sales and post-sales support experience. The Company believes ongoing investment in research and development (“R&D”), marketing and advertising is critical to the development and sale of innovative products, services and technologies.

[0000320193-17-000009:mdna:8]
[same as prior period, unchanged from 0001628280-17-004790:mdna:9]

[0000320193-17-000009:mdna:9]
[same as prior period, unchanged from 0001628280-17-004790:mdna:10]

[0000320193-17-000009:mdna:10]
[same as prior period, unchanged from 0001628280-17-004790:mdna:11]

[0000320193-17-000009:mdna:11]
[same as prior period, unchanged from 0001628280-17-004790:mdna:12]

[0000320193-17-000009:mdna:12]
Third Quarter Fiscal 2017 Highlights

[0000320193-17-000009:mdna:13]
Net sales increased 7% or $3.1 billion during the third quarter of 2017 compared to the same quarter in 2016, primarily driven by growth in Services, iPhone and Other Products. The year-over-year increase in net sales reflected growth in each of the geographic operating segments, with the exception of Greater China. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on net sales during the third quarter of 2017 compared to the same quarter in 2016.

[0000320193-17-000009:mdna:14]
During the third quarter of 2017, the Company began shipping a new 10.5-inch iPad Pro® and an updated 12.9-inch iPad Pro, as well as updated versions of iMac®, MacBook®, MacBook Air® and MacBook® Pro computers. The Company also previewed its new iMac Pro™ and HomePod™ wireless speaker, both of which are expected to be available in December 2017. Additionally, the Company announced updates to its operating systems iOS 11, macOS High Sierra and watchOS 4, all of which are expected to be available in the fall of 2017.

[0000320193-17-000009:mdna:15]
The Company utilized $7.5 billion to repurchase shares of its common stock and paid dividends and dividend equivalents of $3.4 billion during the third quarter of 2017. Additionally, the Company issued $8.0 billion of U.S. dollar-denominated and €2.5 billion of euro-denominated long-term debt.

[0000320193-17-000009:mdna:16]
[same as prior period, unchanged from 0001628280-17-004790:mdna:16]

[0000320193-17-000009:mdna:17]
The following table shows net sales by operating segment and net sales and unit sales by product for the three- and nine-month periods ended July 1, 2017 and June 25, 2016 (dollars in millions and units in thousands):

[0000320193-17-000009:mdna:18]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1, 2017 |  | June 25, 2016 |  | Change |  | July 1, 2017 |  | June 25, 2016 |  | Change |
| Net Sales by Operating Segment: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 20,376 |  |  | $ | 17,963 |  |  | 13 | % |  | $ | 73,501 |  |  | $ | 66,384 |  |  | 11 | % |
| Europe | 10,675 |  |  | 9,643 |  |  | 11 | % |  | 41,929 |  |  | 39,110 |  |  | 7 | % |
| Greater China | 8,004 |  |  | 8,848 |  |  | (10 | )% |  | 34,963 |  |  | 39,707 |  |  | (12 | )% |
| Japan | 3,624 |  |  | 3,529 |  |  | 3 | % |  | 13,875 |  |  | 12,604 |  |  | 10 | % |
| Rest of Asia Pacific | 2,729 |  |  | 2,375 |  |  | 15 | % |  | 12,387 |  |  | 10,982 |  |  | 13 | % |
| Total net sales | $ | 45,408 |  |  | $ | 42,358 |  |  | 7 | % |  | $ | 176,655 |  |  | $ | 168,787 |  |  | 5 | % |
| Net Sales by Product: |  |  |  |  |  |  |  |  |  |  |  |
| iPhone (1) | $ | 24,846 |  |  | $ | 24,048 |  |  | 3 | % |  | $ | 112,473 |  |  | $ | 108,540 |  |  | 4 | % |
| iPad (1) | 4,969 |  |  | 4,876 |  |  | 2 | % |  | 14,391 |  |  | 16,373 |  |  | (12 | )% |
| Mac (1) | 5,592 |  |  | 5,239 |  |  | 7 | % |  | 18,680 |  |  | 17,092 |  |  | 9 | % |
| Services (2) | 7,266 |  |  | 5,976 |  |  | 22 | % |  | 21,479 |  |  | 18,023 |  |  | 19 | % |
| Other Products (1)(3) | 2,735 |  |  | 2,219 |  |  | 23 | % |  | 9,632 |  |  | 8,759 |  |  | 10 | % |
| Total net sales | $ | 45,408 |  |  | $ | 42,358 |  |  | 7 | % |  | $ | 176,655 |  |  | $ | 168,787 |  |  | 5 | % |
| Unit Sales by Product: |  |  |  |  |  |  |  |  |  |  |  |
| iPhone | 41,026 |  |  | 40,399 |  |  | 2 | % |  | 170,079 |  |  | 166,371 |  |  | 2 | % |
| iPad | 11,424 |  |  | 9,950 |  |  | 15 | % |  | 33,427 |  |  | 36,323 |  |  | (8 | )% |
| Mac | 4,292 |  |  | 4,252 |  |  | 1 | % |  | 13,865 |  |  | 13,598 |  |  | 2 | % |

[0000320193-17-000009:mdna:19]
[same as prior period, unchanged from 0001628280-17-004790:mdna:19]

[0000320193-17-000009:mdna:20]
[same as prior period, unchanged from 0001628280-17-004790:mdna:20]

[0000320193-17-000009:mdna:21]
[same as prior period, unchanged from 0001628280-17-004790:mdna:21]

[0000320193-17-000009:mdna:22]
[same as prior period, unchanged from 0001628280-17-004790:mdna:23]

[0000320193-17-000009:mdna:23]
[same as prior period, unchanged from 0001628280-17-004790:mdna:24]

[0000320193-17-000009:mdna:24]
The following table presents iPhone net sales and unit sales information for the three- and nine-month periods ended July 1, 2017 and June 25, 2016 (dollars in millions and units in thousands):

[0000320193-17-000009:mdna:25]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1, 2017 |  | June 25, 2016 |  | Change |  | July 1, 2017 |  | June 25, 2016 |  | Change |
| Net sales | $ | 24,846 |  |  | $ | 24,048 |  |  | 3 | % |  | $ | 112,473 |  |  | $ | 108,540 |  |  | 4 | % |
| Percentage of total net sales | 55 | % |  | 57 | % |  |  |  | 64 | % |  | 64 | % |  |  |
| Unit sales | 41,026 |  |  | 40,399 |  |  | 2 | % |  | 170,079 |  |  | 166,371 |  |  | 2 | % |

[0000320193-17-000009:mdna:26]
iPhone net sales increased during the third quarter and first nine months of 2017 compared to the same periods in 2016 due to higher iPhone unit sales and a different mix of iPhones with higher average selling prices. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on iPhone net sales during the third quarter and first nine months of 2017 compared to the same periods in 2016.

[0000320193-17-000009:mdna:27]
[same as prior period, unchanged from 0001628280-17-004790:mdna:28]

[0000320193-17-000009:mdna:28]
The following table presents iPad net sales and unit sales information for the three- and nine-month periods ended July 1, 2017 and June 25, 2016 (dollars in millions and units in thousands):

[0000320193-17-000009:mdna:29]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1, 2017 |  | June 25, 2016 |  | Change |  | July 1, 2017 |  | June 25, 2016 |  | Change |
| Net sales | $ | 4,969 |  |  | $ | 4,876 |  |  | 2 | % |  | $ | 14,391 |  |  | $ | 16,373 |  |  | (12 | )% |
| Percentage of total net sales | 11 | % |  | 12 | % |  |  |  | 8 | % |  | 10 | % |  |  |
| Unit sales | 11,424 |  |  | 9,950 |  |  | 15 | % |  | 33,427 |  |  | 36,323 |  |  | (8 | )% |

[0000320193-17-000009:mdna:30]
iPad net sales increased during the third quarter of 2017 compared to the same period in 2016 due primarily to higher iPad unit sales, partially offset by lower iPad average selling prices. The year-over-year decrease in iPad net sales during the first nine months of 2017 was due primarily to lower iPad unit sales and a different mix of iPads with lower average selling prices. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on iPad net sales during the third quarter and first nine months of 2017 compared to the same periods in 2016.

[0000320193-17-000009:mdna:31]
[same as prior period, unchanged from 0001628280-17-004790:mdna:32]

[0000320193-17-000009:mdna:32]
The following table presents Mac net sales and unit sales information for the three- and nine-month periods ended July 1, 2017 and June 25, 2016 (dollars in millions and units in thousands):

[0000320193-17-000009:mdna:33]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1, 2017 |  | June 25, 2016 |  | Change |  | July 1, 2017 |  | June 25, 2016 |  | Change |
| Net sales | $ | 5,592 |  |  | $ | 5,239 |  |  | 7 | % |  | $ | 18,680 |  |  | $ | 17,092 |  |  | 9 | % |
| Percentage of total net sales | 12 | % |  | 12 | % |  |  |  | 11 | % |  | 10 | % |  |  |
| Unit sales | 4,292 |  |  | 4,252 |  |  | 1 | % |  | 13,865 |  |  | 13,598 |  |  | 2 | % |

[0000320193-17-000009:mdna:34]
Mac net sales increased during the third quarter and first nine months of 2017 compared to the same periods in 2016 due primarily to a different mix of Macs with higher average selling prices, including the new MacBook Pro introduced in the first quarter of 2017, and to a lesser extent higher Mac unit sales. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on Mac net sales during the third quarter and first nine months of 2017 compared to the same periods in 2016.

[0000320193-17-000009:mdna:35]
[same as prior period, unchanged from 0001628280-17-004790:mdna:37]

[0000320193-17-000009:mdna:36]
The following table presents Services net sales information for the three- and nine-month periods ended July 1, 2017 and June 25, 2016 (dollars in millions):

[0000320193-17-000009:mdna:37]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1, 2017 |  | June 25, 2016 |  | Change |  | July 1, 2017 |  | June 25, 2016 |  | Change |
| Net sales | $ | 7,266 |  |  | $ | 5,976 |  |  | 22 | % |  | $ | 21,479 |  |  | $ | 18,023 |  |  | 19 | % |
| Percentage of total net sales | 16 | % |  | 14 | % |  |  |  | 12 | % |  | 11 | % |  |  |

[0000320193-17-000009:mdna:38]
The increase in Services net sales in the third quarter and first nine months of 2017 compared to the same periods in 2016 was due primarily to growth from the App Store and licensing sales.

[0000320193-17-000009:mdna:39]
[same as prior period, unchanged from 0001628280-17-004790:mdna:41]

[0000320193-17-000009:mdna:40]
The Company manages its business primarily on a geographic basis. The Company’s reportable operating segments consist of the Americas, Europe, Greater China, Japan and Rest of Asia Pacific. The Americas segment includes both North and South America. The Europe segment includes European countries, as well as India, the Middle East and Africa. The Greater China segment includes China, Hong Kong and Taiwan. The Rest of Asia Pacific segment includes Australia and those Asian countries not included in the Company’s other reportable operating segments. Although the reportable operating segments provide similar hardware and software products and similar services, each one is managed separately to better align with the location of the Company’s customers and distribution partners and the unique market dynamics of each geographic region. Further information regarding the Company’s reportable operating segments can be found in Part I, Item 1 of this Form 10-Q in the Notes to Condensed Consolidated Financial Statements in Note 11, “Segment Information and Geographic Data.”

[0000320193-17-000009:mdna:41]
[same as prior period, unchanged from 0001628280-17-004790:mdna:43]

[0000320193-17-000009:mdna:42]
The following table presents Americas net sales information for the three- and nine-month periods ended July 1, 2017 and June 25, 2016 (dollars in millions):

[0000320193-17-000009:mdna:43]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1, 2017 |  | June 25, 2016 |  | Change |  | July 1, 2017 |  | June 25, 2016 |  | Change |
| Net sales | $ | 20,376 |  |  | $ | 17,963 |  |  | 13 | % |  | $ | 73,501 |  |  | $ | 66,384 |  |  | 11 | % |
| Percentage of total net sales | 45 | % |  | 42 | % |  |  |  | 42 | % |  | 39 | % |  |  |

[0000320193-17-000009:mdna:44]
Americas net sales increased during the third quarter of 2017 compared to the same period in 2016 due primarily to higher net sales of iPhone, Services and Other Products. The year-over-year increase in Americas net sales during the first nine months of 2017 was due primarily to higher net sales of iPhone and Services.

[0000320193-17-000009:mdna:45]
[same as prior period, unchanged from 0001628280-17-004790:mdna:47]

[0000320193-17-000009:mdna:46]
The following table presents Europe net sales information for the three- and nine-month periods ended July 1, 2017 and June 25, 2016 (dollars in millions):

[0000320193-17-000009:mdna:47]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1, 2017 |  | June 25, 2016 |  | Change |  | July 1, 2017 |  | June 25, 2016 |  | Change |
| Net sales | $ | 10,675 |  |  | $ | 9,643 |  |  | 11 | % |  | $ | 41,929 |  |  | $ | 39,110 |  |  | 7 | % |
| Percentage of total net sales | 24 | % |  | 23 | % |  |  |  | 24 | % |  | 23 | % |  |  |

[0000320193-17-000009:mdna:48]
Europe net sales increased during the third quarter and first nine months of 2017 compared to the same periods in 2016 due primarily to higher net sales of iPhone and Services. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on Europe net sales during the third quarter and first nine months of 2017 compared to the same periods in 2016.

[0000320193-17-000009:mdna:49]
[same as prior period, unchanged from 0001628280-17-004790:mdna:51]

[0000320193-17-000009:mdna:50]
The following table presents Greater China net sales information for the three- and nine-month periods ended July 1, 2017 and June 25, 2016 (dollars in millions):

[0000320193-17-000009:mdna:51]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1, 2017 |  | June 25, 2016 |  | Change |  | July 1, 2017 |  | June 25, 2016 |  | Change |
| Net sales | $ | 8,004 |  |  | $ | 8,848 |  |  | (10 | )% |  | $ | 34,963 |  |  | $ | 39,707 |  |  | (12 | )% |
| Percentage of total net sales | 18 | % |  | 21 | % |  |  |  | 20 | % |  | 24 | % |  |  |

[0000320193-17-000009:mdna:52]
Greater China net sales decreased during the third quarter and first nine months of 2017 compared to the same periods in 2016 due primarily to lower net sales of iPhone, partially offset by growth in net sales of Services. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on Greater China net sales during the third quarter and first nine months of 2017 compared to the same periods in 2016.

[0000320193-17-000009:mdna:53]
[same as prior period, unchanged from 0001628280-17-004790:mdna:55]

[0000320193-17-000009:mdna:54]
The following table presents Japan net sales information for the three- and nine-month periods ended July 1, 2017 and June 25, 2016 (dollars in millions):

[0000320193-17-000009:mdna:55]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1, 2017 |  | June 25, 2016 |  | Change |  | July 1, 2017 |  | June 25, 2016 |  | Change |
| Net sales | $ | 3,624 |  |  | $ | 3,529 |  |  | 3 | % |  | $ | 13,875 |  |  | $ | 12,604 |  |  | 10 | % |
| Percentage of total net sales | 8 | % |  | 8 | % |  |  |  | 8 | % |  | 7 | % |  |  |

[0000320193-17-000009:mdna:56]
Japan net sales increased during the third quarter of 2017 compared to the same period in 2016 due primarily to higher net sales of Services and iPad, partially offset by lower net sales of iPhone. The year-over-year increase in Japan net sales during the first nine months of 2017 was due primarily to the growth in net sales of Services and iPhone. The strength in the Japanese yen relative to the U.S. dollar had a favorable impact on Japan net sales during the first nine months of 2017 compared to the same period in 2016.

[0000320193-17-000009:mdna:57]
[same as prior period, unchanged from 0001628280-17-004790:mdna:59]

[0000320193-17-000009:mdna:58]
The following table presents Rest of Asia Pacific net sales information for the three- and nine-month periods ended July 1, 2017 and June 25, 2016 (dollars in millions):

[0000320193-17-000009:mdna:59]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1, 2017 |  | June 25, 2016 |  | Change |  | July 1, 2017 |  | June 25, 2016 |  | Change |
| Net sales | $ | 2,729 |  |  | $ | 2,375 |  |  | 15 | % |  | $ | 12,387 |  |  | $ | 10,982 |  |  | 13 | % |
| Percentage of total net sales | 6 | % |  | 6 | % |  |  |  | 7 | % |  | 7 | % |  |  |

[0000320193-17-000009:mdna:60]
Rest of Asia Pacific net sales increased during the third quarter and first nine months of 2017 compared to the same periods in 2016 due primarily to higher net sales of iPhone and Services. The strength in foreign currencies relative to the U.S. dollar had a favorable impact on Rest of Asia Pacific net sales during the third quarter and first nine months of 2017 compared to the same periods in 2016.

[0000320193-17-000009:mdna:61]
[same as prior period, unchanged from 0001628280-17-004790:mdna:63]

[0000320193-17-000009:mdna:62]
Gross margin for the three- and nine-month periods ended July 1, 2017 and June 25, 2016 was as follows (dollars in millions):

[0000320193-17-000009:mdna:63]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1, 2017 |  | June 25, 2016 |  | July 1, 2017 |  | June 25, 2016 |
| Net sales | $ | 45,408 |  |  | $ | 42,358 |  |  | $ | 176,655 |  |  | $ | 168,787 |  |
| Cost of sales | 27,920 |  |  | 26,252 |  |  | 108,400 |  |  | 102,337 |  |
| Gross margin | $ | 17,488 |  |  | $ | 16,106 |  |  | $ | 68,255 |  |  | $ | 66,450 |  |
| Gross margin percentage | 38.5 | % |  | 38.0 | % |  | 38.6 | % |  | 39.4 | % |

[0000320193-17-000009:mdna:64]
Gross margin percentage increased during the third quarter of 2017 compared to the same quarter of 2016 driven primarily by a favorable shift in mix to Services, partially offset by higher product cost structures. The year-over-year decrease in gross margin percentage during the first nine months of 2017 was due primarily to higher product cost structures, partially offset by a favorable mix of products and services. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on gross margin percentage during the third quarter and first nine months of 2017 compared to the same periods in 2016.

[0000320193-17-000009:mdna:65]
The Company anticipates gross margin percentage during the fourth quarter of 2017 to be between 37.5% and 38.0%. The foregoing statement regarding the Company’s expected gross margin percentage in the fourth quarter of 2017 is forward-looking and could differ from actual results. The Company’s future gross margins can be impacted by multiple factors including, but not limited to, those set forth in Part II, Item 1A of this Form 10-Q under the heading “Risk Factors” and those described in this paragraph. In general, the Company believes gross margins will remain under downward pressure due to a variety of factors, including continued industry-wide global product pricing pressures, increased competition, compressed product life cycles, product transitions, potential increases in the cost of components, and potential strengthening of the U.S. dollar, as well as potential increases in the costs of outside manufacturing services and a potential shift in the Company’s sales mix towards products with lower gross margins. In response to competitive pressures, the Company expects it will continue to take product pricing actions, which would adversely affect gross margins. Gross margins could also be affected by the Company’s ability to manage product quality and warranty costs effectively and to stimulate demand for certain of its products. Due to the Company’s significant international operations, its financial condition and operating results, including gross margins, could be significantly affected by fluctuations in exchange rates.

[0000320193-17-000009:mdna:66]
[same as prior period, unchanged from 0001628280-17-004790:mdna:68]

[0000320193-17-000009:mdna:67]
Operating expenses for the three- and nine-month periods ended July 1, 2017 and June 25, 2016 were as follows (dollars in millions):

[0000320193-17-000009:mdna:68]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1, 2017 |  | June 25, 2016 |  | July 1, 2017 |  | June 25, 2016 |
| Research and development | $ | 2,937 |  |  | $ | 2,560 |  |  | $ | 8,584 |  |  | $ | 7,475 |  |
| Percentage of total net sales | 6 | % |  | 6 | % |  | 5 | % |  | 4 | % |
| Selling, general and administrative | $ | 3,783 |  |  | $ | 3,441 |  |  | $ | 11,447 |  |  | $ | 10,712 |  |
| Percentage of total net sales | 8 | % |  | 8 | % |  | 6 | % |  | 6 | % |
| Total operating expenses | $ | 6,720 |  |  | $ | 6,001 |  |  | $ | 20,031 |  |  | $ | 18,187 |  |
| Percentage of total net sales | 15 | % |  | 14 | % |  | 11 | % |  | 11 | % |

[0000320193-17-000009:mdna:69]
[same as prior period, unchanged from 0001628280-17-004790:mdna:71]

[0000320193-17-000009:mdna:70]
The growth in R&D expense during the third quarter and first nine months of 2017 compared to the same periods in 2016 was driven primarily by an increase in headcount-related expenses to support expanded R&D activities. The Company continues to believe that focused investments in R&D are critical to its future growth and competitive position in the marketplace, and to the development of new and updated products and services that are central to the Company’s core business strategy.

[0000320193-17-000009:mdna:71]
[same as prior period, unchanged from 0001628280-17-004790:mdna:73]

[0000320193-17-000009:mdna:72]
The growth in selling, general and administrative expense during the third quarter and first nine months of 2017 compared to the same periods in 2016 was driven primarily by an increase in headcount-related expenses and higher variable selling expenses.

[0000320193-17-000009:mdna:73]
[same as prior period, unchanged from 0001628280-17-004790:mdna:75]

[0000320193-17-000009:mdna:74]
Other income/(expense), net for the three- and nine-month periods ended July 1, 2017 and June 25, 2016 was as follows (dollars in millions):

[0000320193-17-000009:mdna:75]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1, 2017 |  | June 25, 2016 |  | Change |  | July 1, 2017 |  | June 25, 2016 |  | Change |
| Interest and dividend income | $ | 1,327 |  |  | $ | 1,036 |  |  |  |  | $ | 3,833 |  |  | $ | 2,963 |  |  |  |
| Interest expense | (602 | ) |  | (409 | ) |  |  |  | (1,657 | ) |  | (1,006 | ) |  |  |
| Other expense, net | (185 | ) |  | (263 | ) |  |  |  | (228 | ) |  | (1,036 | ) |  |  |
| Total other income/(expense), net | $ | 540 |  |  | $ | 364 |  |  | 48 | % |  | $ | 1,948 |  |  | $ | 921 |  |  | 112 | % |

[0000320193-17-000009:mdna:76]
The increase in other income/(expense), net during the third quarter and first nine months of 2017 compared to the same periods in 2016 was due primarily to higher interest income and the favorable impact of foreign exchange-related items, partially offset by higher interest expense on debt. The weighted-average interest rate earned by the Company on its cash, cash equivalents and marketable securities was 2.03% and 1.77% in the third quarter of 2017 and 2016, respectively, and 1.96% and 1.72% in the first nine months of 2017 and 2016, respectively.

[0000320193-17-000009:mdna:77]
[same as prior period, unchanged from 0001628280-17-004790:mdna:79]

[0000320193-17-000009:mdna:78]
Provision for income taxes and effective tax rates for the three- and nine-month periods ended July 1, 2017 and June 25, 2016 were as follows (dollars in millions):

[0000320193-17-000009:mdna:79]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1, 2017 |  | June 25, 2016 |  | July 1, 2017 |  | June 25, 2016 |
| Provision for income taxes | $ | 2,591 |  |  | $ | 2,673 |  |  | $ | 12,535 |  |  | $ | 12,511 |  |
| Effective tax rate | 22.9 | % |  | 25.5 | % |  | 25.0 | % |  | 25.4 | % |

[0000320193-17-000009:mdna:80]
The Company’s effective tax rates during the third quarter and first nine months of 2017 and 2016 differ from the statutory federal income tax rate of 35% due primarily to certain undistributed foreign earnings, a substantial portion of which was generated by subsidiaries organized in Ireland, for which no U.S. taxes are provided when such earnings are intended to be indefinitely reinvested outside the U.S. The lower effective tax rates during the third quarter and first nine months of 2017 compared to the same periods in 2016 were due to higher U.S. R&D credits, in part as a result of the resolution of the U.S. Internal Revenue Service (“IRS”) audit of years 2010 through 2012.

[0000320193-17-000009:mdna:81]
The IRS concluded its review of the years 2010 through 2012 during the third quarter of 2017. All years prior to 2013 are closed, and the IRS is currently examining the years 2013 through 2015. The Company is subject to audits by federal, state, local and foreign tax authorities. Management believes that adequate provisions have been made for any adjustments that may result from tax examinations. However, the outcome of tax audits cannot be predicted with certainty. If any issues addressed in the Company’s tax audits are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs.

[0000320193-17-000009:mdna:82]
On August 30, 2016, the European Commission announced its decision that Ireland granted state aid to the Company by providing tax opinions in 1991 and 2007 concerning the tax allocation of profits of the Irish branches of two subsidiaries of the Company (the “State Aid Decision”). The State Aid Decision orders Ireland to calculate and recover additional taxes from the Company for the period June 2003 through December 2014. Irish legislative changes, effective as of January 2015, eliminated the application of the tax opinions from that date forward. The Company believes the State Aid Decision to be without merit and appealed to the General Court of the Court of Justice of the European Union. Ireland has also appealed the State Aid Decision. While the European Commission announced a recovery amount of up to €13 billion, plus interest, the actual amount of additional taxes subject to recovery is to be calculated by Ireland in accordance with the European Commission’s guidance. Once the recovery amount is computed by Ireland, the Company anticipates funding it, including interest, out of foreign cash into escrow, where it will remain pending conclusion of all appeals. The Company believes that any incremental Irish corporate income taxes potentially due related to the State Aid Decision would be creditable against U.S. taxes.

[0000320193-17-000009:mdna:83]
[same as prior period, unchanged from 0001628280-17-004790:mdna:85]

[0000320193-17-000009:mdna:84]
[same as prior period, unchanged from 0001628280-17-004790:mdna:86]

[0000320193-17-000009:mdna:85]
In November 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash (“ASU 2016-18”), which enhances and clarifies the guidance on the classification and presentation of restricted cash in the statement of cash flows. The Company will adopt ASU 2016-18 in its first quarter of 2019 utilizing the retrospective adoption method. Currently, the Company’s restricted cash balance is not significant.

[0000320193-17-000009:mdna:86]
[same as prior period, unchanged from 0001628280-17-004790:mdna:88]

[0000320193-17-000009:mdna:87]
In October 2016, the FASB issued ASU No. 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory (“ASU 2016-16”), which requires the recognition of the income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. The Company will adopt ASU 2016-16 in its first quarter of 2019 utilizing the modified retrospective adoption method. Currently, the Company anticipates recording up to $9 billion of net deferred tax assets on its Consolidated Balance Sheets. However, the ultimate impact of adopting ASU 2016-16 will depend on the balance of intellectual property transferred between its subsidiaries as of the adoption date. The Company will recognize incremental deferred income tax expense thereafter as these deferred tax assets are utilized.

[0000320193-17-000009:mdna:88]
[same as prior period, unchanged from 0001628280-17-004790:mdna:90]

[0000320193-17-000009:mdna:89]
In March 2016, the FASB issued ASU No. 2016-09, Compensation – Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting (“ASU 2016-09”), which modifies certain aspects of the accounting for share-based payment transactions, including income taxes, classification of awards, and classification in the statement of cash flows. The Company will adopt ASU 2016-09 in its first quarter of 2018. Currently, excess tax benefits or deficiencies from the Company’s equity awards are recorded as additional paid-in capital in its Consolidated Balance Sheets. Upon adoption, the Company will record any excess tax benefits or deficiencies from its equity awards in its Consolidated Statements of Operations in the reporting periods in which vesting occurs. As a result, subsequent to adoption the Company’s income tax expense and associated effective tax rate will be impacted by fluctuations in stock price between the grant dates and vesting dates of equity awards.

[0000320193-17-000009:mdna:90]
[same as prior period, unchanged from 0001628280-17-004790:mdna:92]

[0000320193-17-000009:mdna:91]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842) (“ASU 2016-02”), which modifies lease accounting for lessees to increase transparency and comparability by recording lease assets and liabilities for operating leases and disclosing key information about leasing arrangements. ASU 2016-02 will be effective for the Company beginning in its first quarter of 2020, and early adoption is permitted. The Company will use a modified retrospective adoption approach. While the Company is currently evaluating the timing and impact of adopting ASU 2016-02, currently the Company anticipates recording lease assets and liabilities in excess of $8.5 billion on its Consolidated Balance Sheets, with no material impact to its Consolidated Statements of Operations. However, the ultimate impact of adopting ASU 2016-02 will depend on the Company’s lease portfolio as of the adoption date.

[0000320193-17-000009:mdna:92]
[same as prior period, unchanged from 0001628280-17-004790:mdna:94]

[0000320193-17-000009:mdna:93]
In January 2016, the FASB issued ASU No. 2016-01, Financial Instruments – Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities (“ASU 2016-01”), which updates certain aspects of recognition, measurement, presentation and disclosure of financial instruments. The Company will adopt ASU 2016-01 in its first quarter of 2019 utilizing the modified retrospective adoption method. Based on the composition of the Company’s investment portfolio, the adoption of ASU 2016-01 is not expected to have a material impact on its consolidated financial statements.

[0000320193-17-000009:mdna:94]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (“ASU 2016-13”), which modifies the measurement of expected credit losses of certain financial instruments. The Company will adopt ASU 2016-13 in its first quarter of 2021 utilizing the modified retrospective adoption method. Based on the composition of the Company’s investment portfolio, current market conditions, and historical credit loss activity, the adoption of ASU 2016-13 is not expected to have a material impact on its consolidated financial statements.

[0000320193-17-000009:mdna:95]
[same as prior period, unchanged from 0001628280-17-004790:mdna:97]

[0000320193-17-000009:mdna:96]
In May 2014, the FASB issued ASU No. 2014-09, Revenue from Contracts with Customers (Topic 606) (“ASU 2014-09”), which amends the existing accounting standards for revenue recognition. ASU 2014-09 is based on principles that govern the recognition of revenue at an amount an entity expects to be entitled when products are transferred to customers.

[0000320193-17-000009:mdna:97]
Subsequently, the FASB has issued the following standards related to ASU 2014-09: ASU No. 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (“ASU 2016-08”); ASU No. 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing (“ASU 2016-10”); ASU No. 2016-12, Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients (“ASU 2016-12”); and ASU No. 2016-20, Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers (“ASU 2016-20”). The Company must adopt ASU 2016-08, ASU 2016-10, ASU 2016-12 and ASU 2016-20 with ASU 2014-09 (collectively, the “new revenue standards”).

[0000320193-17-000009:mdna:98]
The new revenue standards may be applied retrospectively to each prior period presented or retrospectively with the cumulative effect recognized as of the date of adoption. The Company plans to adopt the new revenue standards in its first quarter of 2019 utilizing the full retrospective adoption method. The new revenue standards are not expected to have a material impact on the amount and timing of revenue recognized in the Company’s consolidated financial statements.

[0000320193-17-000009:mdna:99]
[same as prior period, unchanged from 0001628280-17-004790:mdna:101]

[0000320193-17-000009:mdna:100]
The following tables present selected financial information and statistics as of July 1, 2017 and September 24, 2016 and for the first nine months of 2017 and 2016 (in millions):

[0000320193-17-000009:mdna:101]
|  | July 1, 2017 |  | September 24, 2016 |
| Cash, cash equivalents and marketable securities | $ | 261,516 |  |  | $ | 237,585 |  |
| Property, plant and equipment, net | $ | 29,286 |  |  | $ | 27,010 |  |
| Commercial paper | $ | 11,980 |  |  | $ | 8,105 |  |
| Total term debt | $ | 96,359 |  |  | $ | 78,927 |  |
| Working capital | $ | 31,573 |  |  | $ | 27,863 |  |

[0000320193-17-000009:mdna:102]
|  | Nine Months Ended |
|  | July 1, 2017 |  | June 25, 2016 |
| Cash generated by operating activities | $ | 47,942 |  |  | $ | 49,698 |  |
| Cash used in investing activities | $ | (36,504 | ) |  | $ | (38,580 | ) |
| Cash used in financing activities | $ | (13,351 | ) |  | $ | (14,001 | ) |

[0000320193-17-000009:mdna:103]
[same as prior period, unchanged from 0001628280-17-004790:mdna:105]

[0000320193-17-000009:mdna:104]
As of July 1, 2017 and September 24, 2016, the Company’s cash, cash equivalents and marketable securities held by foreign subsidiaries were $246.0 billion and $216.0 billion, respectively, and are generally based in U.S. dollar-denominated holdings. Amounts held by foreign subsidiaries are generally subject to U.S. income taxation on repatriation to the U.S. In connection with the State Aid Decision, the European Commission announced a recovery amount of up to €13 billion, plus interest. The actual amount of additional taxes subject to recovery is to be calculated by Ireland in accordance with the European Commission’s guidance. Once the recovery amount is computed by Ireland, the Company anticipates funding it, including interest, out of foreign cash into escrow, where it will remain pending conclusion of all appeals.

[0000320193-17-000009:mdna:105]
[same as prior period, unchanged from 0001628280-17-004790:mdna:107]

[0000320193-17-000009:mdna:106]
During the nine months ended July 1, 2017, cash generated by operating activities of $47.9 billion was a result of $37.6 billion of net income, non-cash adjustments to net income of $16.0 billion and a decrease in the net change in operating assets and liabilities of $5.7 billion, which included a one-time payment of $1.9 billion related to a multi-year license agreement. Cash used in investing activities of $36.5 billion during the nine months ended July 1, 2017 consisted primarily of cash used for purchases of marketable securities, net of sales and maturities, of $27.7 billion and cash used to acquire property, plant and equipment of $8.6 billion. Cash used in financing activities of $13.4 billion during the nine months ended July 1, 2017 consisted primarily of cash used to repurchase common stock of $25.1 billion, cash used to pay dividends and dividend equivalents of $9.5 billion and cash used to repay term debt of $3.5 billion, partially offset by proceeds from the issuance of term debt, net of $21.7 billion and proceeds from commercial paper, net of $3.9 billion.

[0000320193-17-000009:mdna:107]
During the nine months ended June 25, 2016, cash generated by operating activities of $49.7 billion was a result of $36.7 billion of net income, non-cash adjustments to net income of $16.7 billion and a decrease in the net change in operating assets and liabilities of $3.7 billion. Cash used in investing activities of $38.6 billion during the nine months ended June 25, 2016 consisted primarily of cash used for purchases of marketable securities, net of sales and maturities, of $27.2 billion and cash used to acquire property, plant and equipment of $8.8 billion. Cash used in financing activities of $14.0 billion during the nine months ended June 25, 2016 consisted primarily of cash used to repurchase common stock of $23.7 billion, cash used to pay dividends and dividend equivalents of $9.1 billion and cash used to repay term debt of $2.5 billion, partially offset by proceeds from the issuance of term debt, net of $18.0 billion and proceeds from commercial paper, net of $4.0 billion.

[0000320193-17-000009:mdna:108]
[same as prior period, unchanged from 0001628280-17-004790:mdna:110]

[0000320193-17-000009:mdna:109]
The Company’s capital expenditures were $8.5 billion during the first nine months of 2017. The Company anticipates utilizing approximately $15.0 billion for capital expenditures during 2017, which includes product tooling and manufacturing process equipment; data centers; corporate facilities and infrastructure, including information systems hardware, software and enhancements; and retail store facilities.

[0000320193-17-000009:mdna:110]
[same as prior period, unchanged from 0001628280-17-004790:mdna:112]

[0000320193-17-000009:mdna:111]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses the net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of July 1, 2017, the Company had $12.0 billion of Commercial Paper outstanding, with a weighted-average interest rate of 1.01% and maturities generally less than nine months.

[0000320193-17-000009:mdna:112]
As of July 1, 2017, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $96.6 billion (collectively the “Notes”). During the third quarter of 2017, the Company repaid $3.5 billion of its Notes. The Company has entered, and in the future may enter, into interest rate swaps to manage interest rate risk on the Notes. In addition, the Company has entered, and in the future may enter, into foreign currency swaps to manage foreign currency risk on the Notes.

[0000320193-17-000009:mdna:113]
Further information regarding the Company’s debt issuances and related hedging activity can be found in Part I, Item 1 of this Form 10-Q in the Notes to Condensed Consolidated Financial Statements in Note 2, “Financial Instruments” and Note 6, “Debt.”

[0000320193-17-000009:mdna:114]
[same as prior period, unchanged from 0001628280-17-004790:mdna:116]

[0000320193-17-000009:mdna:115]
In May 2017, the Company’s Board of Directors increased the total capital return program from $250 billion to $300 billion, which included an increase in the share repurchase authorization from $175 billion to $210 billion of the Company’s common stock. Additionally, the Company announced that the Board of Directors raised the Company’s quarterly cash dividend from $0.57 to $0.63 per share, beginning with the dividend paid during the third quarter of 2017. The Company intends to increase its dividend on an annual basis subject to declaration by the Board of Directors.

[0000320193-17-000009:mdna:116]
As of July 1, 2017, $158 billion of the share repurchase program had been utilized. The Company’s share repurchase program does not obligate it to acquire any specific number of shares. Under the program, shares may be repurchased in privately negotiated or open market transactions, including under plans complying with Rule 10b5-1 under the Exchange Act.

[0000320193-17-000009:mdna:117]
The following table presents the Company’s dividends, dividend equivalents, share repurchases and net share settlement activity from the start of the capital return program in August 2012 through July 1, 2017 (in millions):

[0000320193-17-000009:mdna:118]
|  | Dividends andDividend Equivalents Paid |  | Accelerated ShareRepurchases |  | Open MarketShare Repurchases |  | Taxes Related to Settlement of Equity Awards |  | Total |
| Q3 2017 | $ | 3,365 |  |  | $ | 3,000 |  |  | $ | 4,500 |  |  | $ | 858 |  |  | $ | 11,723 |  |
| Q2 2017 | 3,004 |  |  | 3,000 |  |  | 4,001 |  |  | 159 |  |  | 10,164 |  |
| Q1 2017 | 3,130 |  |  | 6,000 |  |  | 5,000 |  |  | 629 |  |  | 14,759 |  |
| 2016 | 12,150 |  |  | 12,000 |  |  | 17,000 |  |  | 1,570 |  |  | 42,720 |  |
| 2015 | 11,561 |  |  | 6,000 |  |  | 30,026 |  |  | 1,499 |  |  | 49,086 |  |
| 2014 | 11,126 |  |  | 21,000 |  |  | 24,000 |  |  | 1,158 |  |  | 57,284 |  |
| 2013 | 10,564 |  |  | 13,950 |  |  | 9,000 |  |  | 1,082 |  |  | 34,596 |  |
| 2012 | 2,488 |  |  | — |  |  | — |  |  | 56 |  |  | 2,544 |  |
| Total | $ | 57,388 |  |  | $ | 64,950 |  |  | $ | 93,527 |  |  | $ | 7,011 |  |  | $ | 222,876 |  |

[0000320193-17-000009:mdna:119]
[same as prior period, unchanged from 0001628280-17-004790:mdna:121]

[0000320193-17-000009:mdna:120]
[same as prior period, unchanged from 0001628280-17-004790:mdna:122]

[0000320193-17-000009:mdna:121]
[same as prior period, unchanged from 0001628280-17-004790:mdna:123]

[0000320193-17-000009:mdna:122]
[same as prior period, unchanged from 0001628280-17-004790:mdna:124]

[0000320193-17-000009:mdna:123]
As of July 1, 2017, the Company’s total future minimum lease payments under noncancelable operating leases were $8.5 billion. The Company’s retail store and other facility leases are typically for terms not exceeding 10 years and generally contain multi-year renewal options.

[0000320193-17-000009:mdna:124]
[same as prior period, unchanged from 0001628280-17-004790:mdna:126]

[0000320193-17-000009:mdna:125]
The Company utilizes several outsourcing partners to manufacture sub-assemblies for the Company’s products and to perform final assembly and testing of finished products. These outsourcing partners acquire components and build product based on demand information supplied by the Company, which typically covers periods up to 150 days. The Company also obtains individual components for its products from a wide variety of individual suppliers. As of July 1, 2017, the Company expects to pay $23.4 billion under manufacturing-related supplier arrangements, substantially all of which is noncancelable.

[0000320193-17-000009:mdna:126]
[same as prior period, unchanged from 0001628280-17-004790:mdna:128]

[0000320193-17-000009:mdna:127]
The Company’s other purchase obligations consisted of noncancelable obligations to acquire capital assets, including product tooling and manufacturing process equipment, and noncancelable obligations related to advertising, licensing, R&D, internet and telecommunications services and other obligations. As of July 1, 2017, the Company had other purchase obligations of $9.0 billion.

[0000320193-17-000009:mdna:128]
The Company’s other non-current liabilities in the Condensed Consolidated Balance Sheets consist primarily of deferred tax liabilities, gross unrecognized tax benefits and the related gross interest and penalties. As of July 1, 2017, the Company had non-current deferred tax liabilities of $30.2 billion, gross unrecognized tax benefits of $8.6 billion and an additional $1.3 billion for gross interest and penalties.

[0000320193-17-000009:mdna:129]
[same as prior period, unchanged from 0001628280-17-004790:mdna:132]

[0000320193-17-000009:mdna:130]
Agreements entered into by the Company sometimes include indemnification provisions which may subject the Company to costs and damages in the event of a claim against an indemnified third party. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to indemnification of third parties.

[0000320193-17-000009:mdna:131]
[same as prior period, unchanged from 0001628280-17-004790:mdna:134]

[0000320193-17-000009:mdna:132]
The Company has entered into indemnification agreements with its directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers of the Company and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. While the Company maintains directors and officers liability insurance coverage, such insurance coverage may be insufficient to cover all losses or all types of claims that may arise.

[0000320193-17-000009:mdna:133]
[same as prior period, unchanged from 0001628280-17-004790:mdna:136]

[0000320193-17-000009:mdna:134]
[same as prior period, unchanged from 0001628280-17-004790:mdna:137]

[0000320193-17-000009:mdna:135]
[same as prior period, unchanged from 0001628280-17-004790:mdna:138]
