# AAPL notes — 0000320193-17-000009


## aapl:CashCashEquivalentsandAvailableforSaleSecuritiesTableTextBlock

[0000320193-17-000009:notes:1]
The following tables show the Company’s cash and available-for-sale securities by significant investment category as of July 1, 2017 and September 24, 2016 (in millions):

[0000320193-17-000009:notes:2]
|  | July 1, 2017 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | Short-TermMarketableSecurities |  | Long-TermMarketableSecurities |
| Cash | $ | 8,529 |  |  | $ | — |  |  | $ | — |  |  | $ | 8,529 |  |  | $ | 8,529 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 3,088 |  |  | — |  |  | — |  |  | 3,088 |  |  | 3,088 |  |  | — |  |  | — |  |
| Mutual funds | 1,004 |  |  | — |  |  | (118 | ) |  | 886 |  |  | — |  |  | 886 |  |  | — |  |
| Subtotal | 4,092 |  |  | — |  |  | (118 | ) |  | 3,974 |  |  | 3,088 |  |  | 886 |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 52,616 |  |  | 77 |  |  | (230 | ) |  | 52,463 |  |  | 1,013 |  |  | 20,104 |  |  | 31,346 |  |
| U.S. agency securities | 5,328 |  |  | 3 |  |  | (9 | ) |  | 5,322 |  |  | 2,255 |  |  | 1,774 |  |  | 1,293 |  |
| Non-U.S. government securities | 6,987 |  |  | 156 |  |  | (50 | ) |  | 7,093 |  |  | — |  |  | 64 |  |  | 7,029 |  |
| Certificates of deposit and time deposits | 6,731 |  |  | — |  |  | — |  |  | 6,731 |  |  | 894 |  |  | 5,191 |  |  | 646 |  |
| Commercial paper | 5,187 |  |  | — |  |  | — |  |  | 5,187 |  |  | 2,683 |  |  | 2,504 |  |  | — |  |
| Corporate securities | 150,089 |  |  | 882 |  |  | (312 | ) |  | 150,659 |  |  | 109 |  |  | 27,522 |  |  | 123,028 |  |
| Municipal securities | 938 |  |  | 3 |  |  | (2 | ) |  | 939 |  |  | — |  |  | 127 |  |  | 812 |  |
| Mortgage- and asset-backed securities | 20,762 |  |  | 34 |  |  | (177 | ) |  | 20,619 |  |  | — |  |  | 16 |  |  | 20,603 |  |
| Subtotal | 248,638 |  |  | 1,155 |  |  | (780 | ) |  | 249,013 |  |  | 6,954 |  |  | 57,302 |  |  | 184,757 |  |
| Total | $ | 261,259 |  |  | $ | 1,155 |  |  | $ | (898 | ) |  | $ | 261,516 |  |  | $ | 18,571 |  |  | $ | 58,188 |  |  | $ | 184,757 |  |

[0000320193-17-000009:notes:3]
[same as prior period, unchanged from 0001628280-17-004790:notes:3]

[0000320193-17-000009:notes:4]
[same as prior period, unchanged from 0001628280-17-004790:notes:4]

[0000320193-17-000009:notes:5]
[same as prior period, unchanged from 0001628280-17-004790:notes:5]


## aapl:CommercialPaperCashFlowSummaryTableTextBlock

[0000320193-17-000009:notes:6]
The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the nine months ended July 1, 2017 and June 25, 2016 (in millions):

[0000320193-17-000009:notes:7]
|  | Nine Months Ended |
|  | July 1, 2017 |  | June 25, 2016 |
| Maturities less than 90 days: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | (143 | ) |  | $ | 4,154 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 12,633 |  |  | 1,846 |  |
| Repayments of commercial paper | (8,624 | ) |  | (2,008 | ) |
| Proceeds from/(Repayments of) commercial paper, net | 4,009 |  |  | (162 | ) |
| Total change in commercial paper, net | $ | 3,866 |  |  | $ | 3,992 |  |


## aapl:NotionalAndCreditRiskAmountsOfOutstandingDerivativePositionsDisclosureTextBlock

[0000320193-17-000009:notes:8]
The following table shows the notional amounts of the Company’s outstanding derivative instruments and credit risk amounts associated with outstanding or unsettled derivative instruments as of July 1, 2017 and September 24, 2016 (in millions):

[0000320193-17-000009:notes:9]
|  | July 1, 2017 |  | September 24, 2016 |
|  | NotionalAmount |  | Credit RiskAmount |  | NotionalAmount |  | Credit RiskAmount |
| Instruments designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 43,700 |  |  | $ | 485 |  |  | $ | 44,678 |  |  | $ | 518 |  |
| Interest rate contracts | $ | 31,500 |  |  | $ | 253 |  |  | $ | 24,500 |  |  | $ | 728 |  |
| Instruments not designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 48,774 |  |  | $ | 242 |  |  | $ | 54,305 |  |  | $ | 153 |  |


## aapl:ScheduleOfCommonStockRepurchasedTableTextBlock

[0000320193-17-000009:notes:10]
[same as prior period, unchanged from 0001628280-17-004790:notes:10]

[0000320193-17-000009:notes:11]
|  | Number of Shares(in thousands) |  | Average Repurchase Price Per Share |  | Amount(in millions) |
| 2017: |  |  |  |  |  |
| Third quarter | 30,356 |  |  | $ | 148.24 |  |  | $ | 4,500 |  |
| Second quarter | 31,070 |  |  | $ | 128.74 |  |  | 4,001 |  |
| First quarter | 44,333 |  |  | $ | 112.78 |  |  | 5,000 |  |
| Total open market common stock repurchases | 105,759 |  |  |  |  | $ | 13,501 |  |
| 2016: |  |  |  |  |  |
| Fourth quarter | 28,579 |  |  | $ | 104.97 |  |  | $ | 3,000 |  |
| Third quarter | 41,238 |  |  | $ | 97.00 |  |  | 4,000 |  |
| Second quarter | 71,766 |  |  | $ | 97.54 |  |  | 7,000 |  |
| First quarter | 25,984 |  |  | $ | 115.45 |  |  | 3,000 |  |
| Total open market common stock repurchases | 167,567 |  |  |  |  | $ | 17,000 |  |


## us-gaap:AcceleratedShareRepurchasesTextBlock

[0000320193-17-000009:notes:12]
The following table shows the Company’s ASR activity and related information during the nine months ended July 1, 2017 and the year ended September 24, 2016:

[0000320193-17-000009:notes:13]
|  | Purchase PeriodEnd Date |  | Number of Shares(in thousands) |  | Average RepurchasePrice Per Share |  | ASR Amount(in millions) |
| May 2017 ASR | August 2017 |  | 15,598 |  | (1) | (1) |  |  | $ | 3,000 |  |
| February 2017 ASR | May 2017 |  | 20,949 |  | (2) | $ | 143.20 |  |  | $ | 3,000 |  |
| November 2016 ASR | February 2017 |  | 51,157 |  |  | $ | 117.29 |  |  | $ | 6,000 |  |
| August 2016 ASR | November 2016 |  | 26,850 |  |  | $ | 111.73 |  |  | $ | 3,000 |  |
| May 2016 ASR | August 2016 |  | 60,452 |  |  | $ | 99.25 |  |  | $ | 6,000 |  |
| November 2015 ASR | April 2016 |  | 29,122 |  |  | $ | 103.02 |  |  | $ | 3,000 |  |

[0000320193-17-000009:notes:14]
| (1) | “Number of Shares” represents those shares delivered at the beginning of the purchase period and does not represent the final number of shares to be delivered under the ASR. The total number of shares ultimately delivered, and therefore the average repurchase price paid per share, will be determined at the end of the purchase period based on the volume-weighted average price of the Company’s common stock during that period. The May 2017 ASR purchase period will end in August 2017. |

[0000320193-17-000009:notes:15]
| (2) | Includes 17.5 million shares delivered and retired at the beginning of the purchase period, which began in the second quarter of 2017 and 3.4 million shares delivered and retired at the end of the purchase period, which concluded in the third quarter of 2017. |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000320193-17-000009:notes:16]
[same as prior period, unchanged from 0001628280-17-004790:notes:16]

[0000320193-17-000009:notes:17]
The following tables show the Company’s condensed consolidated financial statement details as of July 1, 2017 and September 24, 2016 (in millions):

[0000320193-17-000009:notes:18]
[same as prior period, unchanged from 0001628280-17-004790:notes:18]

[0000320193-17-000009:notes:19]
|  | July 1, 2017 |  | September 24, 2016 |
| Land and buildings | $ | 12,529 |  |  | $ | 10,185 |  |
| Machinery, equipment and internal-use software | 49,491 |  |  | 44,543 |  |
| Leasehold improvements | 6,961 |  |  | 6,517 |  |
| Gross property, plant and equipment | 68,981 |  |  | 61,245 |  |
| Accumulated depreciation and amortization | (39,695 | ) |  | (34,235 | ) |
| Total property, plant and equipment, net | $ | 29,286 |  |  | $ | 27,010 |  |

[0000320193-17-000009:notes:20]
[same as prior period, unchanged from 0001628280-17-004790:notes:20]

[0000320193-17-000009:notes:21]
|  | July 1, 2017 |  | September 24, 2016 |
| Deferred tax liabilities | $ | 30,191 |  |  | $ | 26,019 |  |
| Other non-current liabilities | 8,407 |  |  | 10,055 |  |
| Total other non-current liabilities | $ | 38,598 |  |  | $ | 36,074 |  |

[0000320193-17-000009:notes:22]
[same as prior period, unchanged from 0001628280-17-004790:notes:22]

[0000320193-17-000009:notes:23]
The following table shows the detail of other income/(expense), net for the three- and nine-month periods ended July 1, 2017 and June 25, 2016 (in millions):

[0000320193-17-000009:notes:24]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1, 2017 |  | June 25, 2016 |  | July 1, 2017 |  | June 25, 2016 |
| Interest and dividend income | $ | 1,327 |  |  | $ | 1,036 |  |  | $ | 3,833 |  |  | $ | 2,963 |  |
| Interest expense | (602 | ) |  | (409 | ) |  | (1,657 | ) |  | (1,006 | ) |
| Other expense, net | (185 | ) |  | (263 | ) |  | (228 | ) |  | (1,036 | ) |
| Total other income/(expense), net | $ | 540 |  |  | $ | 364 |  |  | $ | 1,948 |  |  | $ | 921 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000320193-17-000009:notes:25]
[same as prior period, unchanged from 0001628280-17-004790:notes:25]

[0000320193-17-000009:notes:26]
The accompanying condensed consolidated financial statements include the accounts of the Company. Intercompany accounts and transactions have been eliminated. In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements in conformity with U.S. generally accepted accounting principles (“GAAP”) requires management to make estimates and assumptions that affect the amounts reported in these condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. Certain prior period amounts in the condensed consolidated financial statements have been reclassified to conform to the current period’s presentation. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company’s annual consolidated financial statements and the notes thereto included in its Annual Report on Form 10-K for the fiscal year ended September 24, 2016 (the “2016 Form 10-K”).


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000320193-17-000009:notes:27]
[same as prior period, unchanged from 0001628280-17-004790:notes:27]

[0000320193-17-000009:notes:28]
Apple Inc. and its wholly-owned subsidiaries (collectively “Apple” or the “Company”) designs, manufactures and markets mobile communication and media devices and personal computers, and sells a variety of related software, services, accessories, networking solutions and third-party digital content and applications. The Company’s products and services include iPhone®, iPad®, Mac®, Apple Watch®, Apple TV®, a portfolio of consumer and professional software applications, iOS, macOS®, watchOS® and tvOS™ operating systems, iCloud®, Apple Pay® and a variety of accessory, service and support offerings. The Company sells and delivers digital content and applications through the iTunes Store®, App Store®, Mac App Store, TV App Store, iBooks Store® and Apple Music® (collectively “Digital Content and Services”). The Company sells its products worldwide through its retail stores, online stores and direct sales force, as well as through third-party cellular network carriers, wholesalers, retailers and value-added resellers. In addition, the Company sells a variety of third-party Apple-compatible products, including application software and various accessories through its retail and online stores. The Company sells to consumers, small and mid-sized businesses and education, enterprise and government customers.

[0000320193-17-000009:notes:29]
[same as prior period, unchanged from 0001628280-17-004790:notes:29]

[0000320193-17-000009:notes:30]
[same as prior period, unchanged from 0001628280-17-004790:notes:30]

[0000320193-17-000009:notes:31]
[same as prior period, unchanged from 0001628280-17-004790:notes:31]

[0000320193-17-000009:notes:32]
The following table shows the computation of basic and diluted earnings per share for the three- and nine-month periods ended July 1, 2017 and June 25, 2016 (net income in millions and shares in thousands):

[0000320193-17-000009:notes:33]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1, 2017 |  | June 25, 2016 |  | July 1, 2017 |  | June 25, 2016 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 8,717 |  |  | $ | 7,796 |  |  | $ | 37,637 |  |  | $ | 36,673 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average shares outstanding | 5,195,088 |  |  | 5,443,058 |  |  | 5,239,847 |  |  | 5,505,456 |  |
| Effect of dilutive securities | 38,411 |  |  | 29,723 |  |  | 34,547 |  |  | 30,475 |  |
| Weighted-average diluted shares | 5,233,499 |  |  | 5,472,781 |  |  | 5,274,394 |  |  | 5,535,931 |  |
| Basic earnings per share | $ | 1.68 |  |  | $ | 1.43 |  |  | $ | 7.18 |  |  | $ | 6.66 |  |
| Diluted earnings per share | $ | 1.67 |  |  | $ | 1.42 |  |  | $ | 7.14 |  |  | $ | 6.62 |  |

[0000320193-17-000009:notes:34]
[same as prior period, unchanged from 0001628280-17-004790:notes:34]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000320193-17-000009:notes:35]
Commitments and Contingencies

[0000320193-17-000009:notes:36]
Accrued Warranty and Indemnification

[0000320193-17-000009:notes:37]
The following table shows changes in the Company’s accrued warranties and related costs for the three- and nine-month periods ended July 1, 2017 and June 25, 2016 (in millions):

[0000320193-17-000009:notes:38]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1, 2017 |  | June 25, 2016 |  | July 1, 2017 |  | June 25, 2016 |
| Beginning accrued warranty and related costs | $ | 4,735 |  |  | $ | 4,985 |  |  | $ | 3,702 |  |  | $ | 4,780 |  |
| Cost of warranty claims | (932 | ) |  | (1,110 | ) |  | (3,300 | ) |  | (3,507 | ) |
| Accruals for product warranty | 496 |  |  | 380 |  |  | 3,897 |  |  | 2,982 |  |
| Ending accrued warranty and related costs | $ | 4,299 |  |  | $ | 4,255 |  |  | $ | 4,299 |  |  | $ | 4,255 |  |

[0000320193-17-000009:notes:39]
Agreements entered into by the Company sometimes include indemnification provisions which may subject the Company to costs and damages in the event of a claim against an indemnified third party. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to indemnification of third parties.

[0000320193-17-000009:notes:40]
The Company offers an iPhone Upgrade Program, which is available to customers who purchase a qualifying iPhone in the U.S., the U.K. and mainland China. The iPhone Upgrade Program provides customers the right to trade in that iPhone for a specified amount when purchasing a new iPhone, provided certain conditions are met. The Company accounts for the trade-in right as a guarantee liability and recognizes arrangement revenue net of the fair value of such right with subsequent changes to the guarantee liability recognized within revenue.

[0000320193-17-000009:notes:41]
The Company has entered into indemnification agreements with its directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers of the Company and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. While the Company maintains directors and officers liability insurance coverage, such insurance coverage may be insufficient to cover all losses or all types of claims that may arise.

[0000320193-17-000009:notes:42]
Concentrations in the Available Sources of Supply of Materials and Product

[0000320193-17-000009:notes:43]
Although most components essential to the Company’s business are generally available from multiple sources, a number of components are currently obtained from single or limited sources. In addition, the Company competes for various components with other participants in the markets for mobile communication and media devices and personal computers. Therefore, many components used by the Company, including those that are available from multiple sources, are at times subject to industry-wide shortage and significant pricing fluctuations that could materially adversely affect the Company’s financial condition and operating results.

[0000320193-17-000009:notes:44]
The Company uses some custom components that are not commonly used by its competitors, and new products introduced by the Company often utilize custom components available from only one source. When a component or product uses new technologies, initial capacity constraints may exist until the suppliers’ yields have matured or manufacturing capacity has increased. If the Company’s supply of components for a new or existing product were delayed or constrained, or if an outsourcing partner delayed shipments of completed products to the Company, the Company’s financial condition and operating results could be materially adversely affected. The Company’s business and financial performance could also be materially adversely affected depending on the time required to obtain sufficient quantities from the original source, or to identify and obtain sufficient quantities from an alternative source. Continued availability of these components at acceptable prices, or at all, may be affected if those suppliers decide to concentrate on the production of common components instead of components customized to meet the Company’s requirements.

[0000320193-17-000009:notes:45]
The Company has entered into agreements for the supply of many components; however, there can be no guarantee that the Company will be able to extend or renew these agreements on similar terms, or at all. Therefore, the Company remains subject to significant risks of supply shortages and price increases that could materially adversely affect its financial condition and operating results.

[0000320193-17-000009:notes:46]
Substantially all of the Company’s hardware products are manufactured by outsourcing partners that are located primarily in Asia. A significant concentration of this manufacturing is currently performed by a small number of outsourcing partners, often in single locations. Certain of these outsourcing partners are the sole-sourced suppliers of components and manufacturers for many of the Company’s products. Although the Company works closely with its outsourcing partners on manufacturing schedules, the Company’s operating results could be adversely affected if its outsourcing partners were unable to meet their production commitments. The Company’s manufacturing purchase obligations typically cover its requirements for periods up to 150 days.

[0000320193-17-000009:notes:47]
Other Off-Balance Sheet Commitments

[0000320193-17-000009:notes:48]
Operating Leases

[0000320193-17-000009:notes:49]
The Company leases various equipment and facilities, including retail space, under noncancelable operating lease arrangements. The Company does not currently utilize any other off-balance sheet financing arrangements. As of July 1, 2017, the Company’s total future minimum lease payments under noncancelable operating leases were $8.5 billion. The Company’s retail store and other facility leases are typically for terms not exceeding 10 years and generally contain multi-year renewal options.

[0000320193-17-000009:notes:50]
Contingencies

[0000320193-17-000009:notes:51]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully adjudicated, as further discussed in Part II, Item 1 of this Form 10-Q under the heading “Legal Proceedings” and in Part II, Item 1A of this Form 10-Q under the heading “Risk Factors.” In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to loss contingencies for asserted legal and other claims. However, the outcome of litigation is inherently uncertain. Therefore, although management considers the likelihood of such an outcome to be remote, if one or more of these legal matters were resolved against the Company in a reporting period for amounts in excess of management’s expectations, the Company’s consolidated financial statements for that reporting period could be materially adversely affected.

[0000320193-17-000009:notes:52]
Apple Inc. v. Samsung Electronics Co., Ltd., et al.

[0000320193-17-000009:notes:53]
On August 24, 2012, a jury returned a verdict awarding the Company $1.05 billion in its lawsuit against Samsung Electronics Co., Ltd. and affiliated parties in the United States District Court, Northern District of California, San Jose Division. On March 6, 2014, the District Court entered final judgment in favor of the Company in the amount of approximately $930 million. On May 18, 2015, the U.S. Court of Appeals for the Federal Circuit affirmed in part, and reversed in part, the decision of the District Court. As a result, the Court of Appeals ordered entry of final judgment on damages in the amount of approximately $548 million, with the District Court to determine supplemental damages and interest, as well as damages owed for products subject to the reversal in part. Samsung paid $548 million to the Company in December 2015, which was included in net sales in the Condensed Consolidated Statement of Operations. On December 6, 2016, the U.S. Supreme Court remanded the case to the U.S. Court of Appeals for the Federal Circuit for further proceedings related to the $548 million in damages. On February 7, 2017, the U.S. Court of Appeals for the Federal Circuit remanded the case to the District Court to determine what additional proceedings, if any, are needed. Because the case remains subject to further proceedings, the Company has not recognized any further amounts in its results of operations.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000320193-17-000009:notes:54]
[same as prior period, unchanged from 0001628280-17-004790:notes:54]

[0000320193-17-000009:notes:55]
[same as prior period, unchanged from 0001628280-17-004790:notes:55]

[0000320193-17-000009:notes:56]
The Company had 328.1 million shares reserved for future issuance under its stock plans as of July 1, 2017. RSUs granted generally vest over four years, based on continued employment, and are settled upon vesting in shares of the Company’s common stock on a one-for-one basis. Each share issued with respect to RSUs granted under the Company’s stock plans reduces the number of shares available for grant under the plan by two shares. RSUs canceled and shares withheld to satisfy tax withholding obligations increase the number of shares available for grant under the plans utilizing a factor of two times the number of RSUs canceled or shares withheld.

[0000320193-17-000009:notes:57]
[same as prior period, unchanged from 0001628280-17-004790:notes:57]

[0000320193-17-000009:notes:58]
During the three months ended July 1, 2017, Section 16 officers Angela Ahrendts, Timothy D. Cook, Luca Maestri, Daniel Riccio and Philip Schiller had equity trading plans in place in accordance with Rule 10b5-1(c)(1) under the Exchange Act. An equity trading plan is a written document that pre-establishes the amounts, prices and dates (or formula for determining the amounts, prices and dates) of future purchases or sales of the Company’s stock, including shares acquired pursuant to the Company’s employee and director equity plans.

[0000320193-17-000009:notes:59]
[same as prior period, unchanged from 0001628280-17-004790:notes:59]

[0000320193-17-000009:notes:60]
A summary of the Company’s RSU activity and related information for the nine months ended July 1, 2017 is as follows:

[0000320193-17-000009:notes:61]
|  | Number ofRSUs(in thousands) |  | Weighted-AverageGrant Date FairValue Per Share |  | Aggregate Fair Value(in millions) |
| Balance at September 24, 2016 | 99,089 |  |  | $ | 97.54 |  |  |  |
| RSUs granted | 48,000 |  |  | $ | 120.09 |  |  |  |
| RSUs vested | (41,712 | ) |  | $ | 95.78 |  |  |  |
| RSUs canceled | (4,779 | ) |  | $ | 106.75 |  |  |  |
| Balance at July 1, 2017 | 100,598 |  |  | $ | 108.59 |  |  | $ | 14,488 |  |

[0000320193-17-000009:notes:62]
RSUs that vested during the three- and nine-month periods ended July 1, 2017 had fair values of $2.8 billion and $5.4 billion, respectively, as of the vesting date. RSUs that vested during the three- and nine-month periods ended June 25, 2016 had fair values of $2.0 billion and $4.5 billion, respectively, as of the vesting date.

[0000320193-17-000009:notes:63]
[same as prior period, unchanged from 0001628280-17-004790:notes:63]

[0000320193-17-000009:notes:64]
The following table shows a summary of the share-based compensation expense included in the Condensed Consolidated Statements of Operations for the three- and nine-month periods ended July 1, 2017 and June 25, 2016 (in millions):

[0000320193-17-000009:notes:65]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1, 2017 |  | June 25, 2016 |  | July 1, 2017 |  | June 25, 2016 |
| Cost of sales | $ | 216 |  |  | $ | 188 |  |  | $ | 662 |  |  | $ | 583 |  |
| Research and development | 566 |  |  | 479 |  |  | 1,730 |  |  | 1,413 |  |
| Selling, general and administrative | 411 |  |  | 387 |  |  | 1,274 |  |  | 1,184 |  |
| Total share-based compensation expense | $ | 1,193 |  |  | $ | 1,054 |  |  | $ | 3,666 |  |  | $ | 3,180 |  |

[0000320193-17-000009:notes:66]
The income tax benefit related to share-based compensation expense was $380 million and $1.3 billion for the three- and nine-month periods ended July 1, 2017, respectively, and was $321 million and $1.1 billion for the three- and nine-month periods ended June 25, 2016, respectively. As of July 1, 2017, the total unrecognized compensation cost related to outstanding RSUs, restricted stock and stock options was $9.0 billion, which the Company expects to recognize over a weighted-average period of 2.6 years.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000320193-17-000009:notes:67]
[same as prior period, unchanged from 0001628280-17-004790:notes:67]

[0000320193-17-000009:notes:68]
[same as prior period, unchanged from 0001628280-17-004790:notes:68]

[0000320193-17-000009:notes:69]
The following table shows the pre-tax amounts reclassified from AOCI into the Condensed Consolidated Statements of Operations, and the associated financial statement line item, for the three- and nine-month periods ended July 1, 2017 and June 25, 2016 (in millions):

[0000320193-17-000009:notes:70]
|  |  |  |  | Three Months Ended |  | Nine Months Ended |
| Comprehensive Income Components |  | Financial Statement Line Item |  | July 1, 2017 |  | June 25, 2016 |  | July 1, 2017 |  | June 25, 2016 |
| Unrealized (gains)/losses on derivative instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Revenue |  | $ | (148 | ) |  | $ | (131 | ) |  | $ | (657 | ) |  | $ | (785 | ) |
|  |  | Cost of sales |  | (73 | ) |  | 106 |  |  | (630 | ) |  | (419 | ) |
|  |  | Other income/(expense), net |  | (364 | ) |  | (112 | ) |  | (127 | ) |  | (123 | ) |
| Interest rate contracts |  | Other income/(expense), net |  | — |  |  | 3 |  |  | 3 |  |  | 10 |  |
|  |  |  |  | (585 | ) |  | (134 | ) |  | (1,411 | ) |  | (1,317 | ) |
| Unrealized (gains)/losses on marketable securities |  | Other income/(expense), net |  | (48 | ) |  | (20 | ) |  | (37 | ) |  | 129 |  |
| Total amounts reclassified from AOCI |  | $ | (633 | ) |  | $ | (154 | ) |  | $ | (1,448 | ) |  | $ | (1,188 | ) |

[0000320193-17-000009:notes:71]
The following table shows the changes in AOCI by component for the nine months ended July 1, 2017 (in millions):

[0000320193-17-000009:notes:72]
|  | Cumulative ForeignCurrency Translation |  | Unrealized Gains/Losseson Derivative Instruments |  | Unrealized Gains/Losseson Marketable Securities |  | Total |
| Balance at September 24, 2016 | $ | (578 | ) |  | $ | 38 |  |  | $ | 1,174 |  |  | $ | 634 |  |
| Other comprehensive income/(loss) before reclassifications | (38 | ) |  | 1,271 |  |  | (1,516 | ) |  | (283 | ) |
| Amounts reclassified from AOCI | — |  |  | (1,411 | ) |  | (37 | ) |  | (1,448 | ) |
| Tax effect | (3 | ) |  | 7 |  |  | 548 |  |  | 552 |  |
| Other comprehensive income/(loss) | (41 | ) |  | (133 | ) |  | (1,005 | ) |  | (1,179 | ) |
| Balance at July 1, 2017 | $ | (619 | ) |  | $ | (95 | ) |  | $ | 169 |  |  | $ | (545 | ) |


## us-gaap:DebtDisclosureTextBlock

[0000320193-17-000009:notes:73]
Debt

[0000320193-17-000009:notes:74]
Commercial Paper

[0000320193-17-000009:notes:75]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of July 1, 2017 and September 24, 2016, the Company had $12.0 billion and $8.1 billion of Commercial Paper outstanding, respectively, with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 1.01% as of July 1, 2017 and 0.45% as of September 24, 2016.

[0000320193-17-000009:notes:76]
Term Debt

[0000320193-17-000009:notes:77]
As of July 1, 2017, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $96.6 billion (collectively the “Notes”). The Notes are senior unsecured obligations, and interest is payable in arrears, quarterly for the U.S. dollar-denominated and Australian dollar-denominated floating-rate notes, semi-annually for the U.S. dollar-denominated, Australian dollar-denominated, British pound-denominated and Japanese yen-denominated fixed-rate notes and annually for the euro-denominated and Swiss franc-denominated fixed-rate notes. The following table provides a summary of the Company’s term debt as of July 1, 2017 and September 24, 2016:

[0000320193-17-000009:notes:78]
|  | Maturities |  | July 1, 2017 |  | September 24, 2016 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2018 |  | 2018 |  | $ | 2,000 |  |  |  | 1.10% |  | 1.10 | % |  | $ | 2,000 |  |  |  | 1.10% |  | 1.10 | % |
| Fixed-rate 1.000% – 3.850% notes | 2018 | – | 2043 |  | 12,500 |  |  |  | 1.08% | – | 3.91 | % |  | 12,500 |  |  |  | 1.08% | – | 3.91 | % |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2019 |  | 1,000 |  |  |  | 1.48% |  | 1.48 | % |  | 2,000 |  |  |  | 0.86% | – | 1.09 | % |
| Fixed-rate 2.100% – 4.450% notes | 2019 | – | 2044 |  | 8,500 |  |  |  | 1.48% | – | 4.48 | % |  | 10,000 |  |  |  | 0.85% | – | 4.48 | % |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2020 |  | 1,532 |  |  |  | 1.43% | – | 1.87 | % |  | 1,781 |  |  |  | 0.87% | – | 1.87 | % |
| Fixed-rate 0.350% – 4.375% notes | 2019 | – | 2045 |  | 24,259 |  |  |  | 0.28% | – | 4.51 | % |  | 25,144 |  |  |  | 0.28% | – | 4.51 | % |
| 2016 debt issuances of $24.9 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2021 |  | 1,350 |  |  |  | 1.31% | – | 2.32 | % |  | 1,350 |  |  |  | 0.91% | – | 1.95 | % |
| Fixed-rate 1.100% – 4.650% notes | 2018 | – | 2046 |  | 23,610 |  |  |  | 1.13% | – | 4.78 | % |  | 23,609 |  |  |  | 1.13% | – | 4.58 | % |
| Second quarter 2017 debt issuance of $10.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2019 |  | 500 |  |  |  |  |  | 1.26 | % |  | — |  |  |  |  |  | — | % |
| Floating-rate notes |  |  | 2020 |  | 500 |  |  |  |  |  | 1.38 | % |  | — |  |  |  |  |  | — | % |
| Floating-rate notes |  |  | 2022 |  | 1,000 |  |  |  |  |  | 1.68 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 1.550% notes |  |  | 2019 |  | 500 |  |  |  |  |  | 1.59 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 1.900% notes |  |  | 2020 |  | 1,000 |  |  |  |  |  | 1.38 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.500% notes |  |  | 2022 |  | 1,500 |  |  |  |  |  | 1.67 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.000% notes |  |  | 2024 |  | 1,750 |  |  |  |  |  | 1.98 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.350% notes |  |  | 2027 |  | 2,250 |  |  |  |  |  | 2.12 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 4.250% notes |  |  | 2047 |  | 1,000 |  |  |  |  |  | 4.26 | % |  | — |  |  |  |  |  | — | % |
| Second quarter 2017 debt issuance of $1.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 4.300% notes |  |  | 2047 |  | 1,000 |  |  |  |  |  | 4.30 | % |  | — |  |  |  |  |  | — | % |
| Third quarter 2017 debt issuance of $7.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2020 |  | 500 |  |  |  |  |  | 1.25 | % |  | — |  |  |  |  |  | — | % |
| Floating-rate notes |  |  | 2022 |  | 750 |  |  |  |  |  | 1.53 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 1.800% notes |  |  | 2020 |  | 1,000 |  |  |  |  |  | 1.84 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.300% notes |  |  | 2022 |  | 1,000 |  |  |  |  |  | 2.34 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.850% notes |  |  | 2024 |  | 1,750 |  |  |  |  |  | 2.16 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.200% notes |  |  | 2027 |  | 2,000 |  |  |  |  |  | 2.34 | % |  | — |  |  |  |  |  | — | % |
| Third quarter 2017 euro-denominated debt issuance of €2.5 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.875% notes |  |  | 2025 |  | 1,419 |  |  |  |  |  | 3.03 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 1.375% notes |  |  | 2029 |  | 1,419 |  |  |  |  |  | 3.37 | % |  | — |  |  |  |  |  | — | % |
| Third quarter 2017 debt issuance of $1.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 3.000% notes |  |  | 2027 |  | 1,000 |  |  |  |  |  | 3.03 | % |  | — |  |  |  |  |  | — | % |
| Total term debt |  |  |  |  | 96,589 |  |  |  |  |  |  |  | 78,384 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (210 | ) |  |  |  |  |  |  | (174 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | (20 | ) |  |  |  |  |  |  | 717 |  |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  |  |  | (6,495 | ) |  |  |  |  |  |  | (3,500 | ) |  |  |  |  |  |
| Total long-term debt |  |  |  |  | $ | 89,864 |  |  |  |  |  |  |  | $ | 75,427 |  |  |  |  |  |  |

[0000320193-17-000009:notes:79]
To manage interest rate risk on certain of its fixed-rate notes issued during the third quarter of 2017 and maturing in 2024 and 2027, the Company entered into interest rate swaps with an aggregate notional amount of $2.75 billion, which effectively converted the fixed interest rates on a portion of these notes to floating interest rates. The Company also hedged its entire third quarter 2017 issuance of €2.5 billion of euro-denominated notes by entering into foreign currency swaps to effectively convert these notes to U.S. dollar-denominated notes.

[0000320193-17-000009:notes:80]
To manage interest rate risk on certain of its fixed-rate notes issued during the second quarter of 2017 and maturing in 2020, 2022, 2024 and 2027, the Company entered into interest rate swaps with an aggregate notional amount of $6.5 billion, which effectively converted the fixed interest rates on these notes to floating interest rates.

[0000320193-17-000009:notes:81]
A portion of the Company’s Japanese yen-denominated notes is designated as a hedge of the foreign currency exposure of the Company’s net investment in a foreign operation. The foreign currency transaction gain or loss on the Japanese yen-denominated debt designated as a hedge is recorded in OCI as a part of the cumulative translation adjustment. As of July 1, 2017 and September 24, 2016, the carrying value of the debt designated as a net investment hedge was $1.5 billion and $1.9 billion, respectively. For further discussion regarding the Company’s use of derivative instruments see the Derivative Financial Instruments section of Note 2, “Financial Instruments.”

[0000320193-17-000009:notes:82]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $574 million and $1.6 billion of interest expense on its term debt for the three- and nine-month periods ended July 1, 2017, respectively. The Company recognized $393 million and $975 million of interest expense on its term debt for the three- and nine-month periods ended June 25, 2016, respectively.

[0000320193-17-000009:notes:83]
As of July 1, 2017 and September 24, 2016, the fair value of the Company’s Notes, based on Level 2 inputs, was $98.3 billion and $81.7 billion, respectively.


## us-gaap:DerivativesPolicyTextBlock

[0000320193-17-000009:notes:84]
[same as prior period, unchanged from 0001628280-17-004790:notes:83]

[0000320193-17-000009:notes:85]
[same as prior period, unchanged from 0001628280-17-004790:notes:84]

[0000320193-17-000009:notes:86]
[same as prior period, unchanged from 0001628280-17-004790:notes:85]

[0000320193-17-000009:notes:87]
[same as prior period, unchanged from 0001628280-17-004790:notes:86]

[0000320193-17-000009:notes:88]
[same as prior period, unchanged from 0001628280-17-004790:notes:87]

[0000320193-17-000009:notes:89]
The Company may enter into interest rate swaps, options, or other instruments to manage interest rate risk. These instruments may offset a portion of changes in income or expense, or changes in fair value of the Company’s term debt or investments. The Company designates these instruments as either cash flow or fair value hedges. The Company’s hedged interest rate transactions as of July 1, 2017 are expected to be recognized within 10 years.

[0000320193-17-000009:notes:90]
[same as prior period, unchanged from 0001628280-17-004790:notes:89]

[0000320193-17-000009:notes:91]
[same as prior period, unchanged from 0001628280-17-004790:notes:90]

[0000320193-17-000009:notes:92]
[same as prior period, unchanged from 0001628280-17-004790:notes:91]

[0000320193-17-000009:notes:93]
[same as prior period, unchanged from 0001628280-17-004790:notes:92]

[0000320193-17-000009:notes:94]
[same as prior period, unchanged from 0001628280-17-004790:notes:93]

[0000320193-17-000009:notes:95]
[same as prior period, unchanged from 0001628280-17-004790:notes:94]

[0000320193-17-000009:notes:96]
[same as prior period, unchanged from 0001628280-17-004790:notes:95]

[0000320193-17-000009:notes:97]
[same as prior period, unchanged from 0001628280-17-004790:notes:96]

[0000320193-17-000009:notes:98]
[same as prior period, unchanged from 0001628280-17-004790:notes:97]

[0000320193-17-000009:notes:99]
[same as prior period, unchanged from 0001628280-17-004790:notes:98]


## us-gaap:DividendsDeclaredTableTextBlock

[0000320193-17-000009:notes:100]
[same as prior period, unchanged from 0001628280-17-004790:notes:99]

[0000320193-17-000009:notes:101]
|  | DividendsPer Share |  | Amount(in millions) |
| 2017: |  |  |  |
| Third quarter | $ | 0.63 |  |  | $ | 3,281 |  |
| Second quarter | 0.57 |  |  | 2,988 |  |
| First quarter | 0.57 |  |  | 3,042 |  |
| Total cash dividends declared and paid | $ | 1.77 |  |  | $ | 9,311 |  |
| 2016: |  |  |  |
| Fourth quarter | $ | 0.57 |  |  | $ | 3,071 |  |
| Third quarter | 0.57 |  |  | 3,117 |  |
| Second quarter | 0.52 |  |  | 2,879 |  |
| First quarter | 0.52 |  |  | 2,898 |  |
| Total cash dividends declared and paid | $ | 2.18 |  |  | $ | 11,965 |  |


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000320193-17-000009:notes:102]
[same as prior period, unchanged from 0001628280-17-004790:notes:101]

[0000320193-17-000009:notes:103]
[same as prior period, unchanged from 0001628280-17-004790:notes:102]


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000320193-17-000009:notes:104]
[same as prior period, unchanged from 0001628280-17-004790:notes:103]

[0000320193-17-000009:notes:105]
[same as prior period, unchanged from 0001628280-17-004790:notes:104]

[0000320193-17-000009:notes:106]
[same as prior period, unchanged from 0001628280-17-004790:notes:105]

[0000320193-17-000009:notes:107]
The Company considers the declines in market value of its marketable securities investment portfolio to be temporary in nature. The Company typically invests in highly-rated securities, and its investment policy generally limits the amount of credit exposure to any one issuer. The policy generally requires investments to be investment grade, with the primary objective of minimizing the potential risk of principal loss. Fair values were determined for each individual security in the investment portfolio. When evaluating an investment for other-than-temporary impairment, the Company reviews factors such as the length of time and extent to which fair value has been below its cost basis, the financial condition of the issuer and any changes thereto, changes in market interest rates and the Company’s intent to sell, or whether it is more likely than not it will be required to sell the investment before recovery of the investment’s cost basis. As of July 1, 2017, the Company does not consider any of its investments to be other-than-temporarily impaired.

[0000320193-17-000009:notes:108]
Derivatives that are not designated as hedging instruments are adjusted to fair value through earnings in the financial statement line item to which the derivative relates. As a result, during the three- and nine-month periods ended July 1, 2017, respectively, the Company recognized a loss of $77 million and a gain of $129 million in net sales, gains of $12 million and $91 million in cost of sales and gains of $49 million and $481 million in other income/(expense), net.

[0000320193-17-000009:notes:109]
The Company records all derivatives in the Condensed Consolidated Balance Sheets at fair value. The Company’s accounting treatment for these derivative instruments is based on its hedge designation. The following tables show the Company’s derivative instruments at gross fair value as of July 1, 2017 and September 24, 2016 (in millions):

[0000320193-17-000009:notes:110]
|  | July 1, 2017 |
|  | Fair Value ofDerivatives Designatedas Hedge Instruments |  | Fair Value ofDerivatives Not Designatedas Hedge Instruments |  | TotalFair Value |
| Derivative assets (1): |  |  |  |  |  |
| Foreign exchange contracts | $ | 485 |  |  | $ | 242 |  |  | $ | 727 |  |
| Interest rate contracts | $ | 253 |  |  | $ | — |  |  | $ | 253 |  |
| Derivative liabilities (2): |  |  |  |  |  |
| Foreign exchange contracts | $ | 842 |  |  | $ | 362 |  |  | $ | 1,204 |  |
| Interest rate contracts | $ | 264 |  |  | $ | — |  |  | $ | 264 |  |

[0000320193-17-000009:notes:111]
[same as prior period, unchanged from 0001628280-17-004790:notes:110]

[0000320193-17-000009:notes:112]
[same as prior period, unchanged from 0001628280-17-004790:notes:111]

[0000320193-17-000009:notes:113]
[same as prior period, unchanged from 0001628280-17-004790:notes:112]

[0000320193-17-000009:notes:114]
The following table shows the pre-tax gains and losses of the Company’s derivative and non-derivative instruments designated as cash flow, net investment and fair value hedges in OCI and the Condensed Consolidated Statements of Operations for the three- and nine-month periods ended July 1, 2017 and June 25, 2016 (in millions):

[0000320193-17-000009:notes:115]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1, 2017 |  | June 25, 2016 |  | July 1, 2017 |  | June 25, 2016 |
| Gains/(Losses) recognized in OCI – effective portion: |  |  |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | (143 | ) |  | $ | (170 | ) |  | $ | 1,267 |  |  | $ | 18 |  |
| Interest rate contracts | (2 | ) |  | (11 | ) |  | 7 |  |  | (53 | ) |
| Total | $ | (145 | ) |  | $ | (181 | ) |  | $ | 1,274 |  |  | $ | (35 | ) |
| Net investment hedges: |  |  |  |  |  |  |  |
| Foreign currency debt | $ | 16 |  |  | $ | (128 | ) |  | $ | 53 |  |  | $ | (205 | ) |
| Gains/(Losses) reclassified from AOCI into net income – effective portion: |  |  |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 585 |  |  | $ | 142 |  |  | $ | 1,418 |  |  | $ | 1,325 |  |
| Interest rate contracts | — |  |  | (3 | ) |  | (3 | ) |  | (10 | ) |
| Total | $ | 585 |  |  | $ | 139 |  |  | $ | 1,415 |  |  | $ | 1,315 |  |
| Gains/(Losses) on derivative instruments: |  |  |  |  |  |  |  |
| Fair value hedges: |  |  |  |  |  |  |  |
| Interest rate contracts | $ | 185 |  |  | $ | 345 |  |  | $ | (737 | ) |  | $ | 484 |  |
| Gains/(Losses) related to hedged items: |  |  |  |  |  |  |  |
| Fair value hedges: |  |  |  |  |  |  |  |
| Fixed-rate debt | $ | (185 | ) |  | $ | (345 | ) |  | $ | 737 |  |  | $ | (484 | ) |

[0000320193-17-000009:notes:116]
[same as prior period, unchanged from 0001628280-17-004790:notes:115]

[0000320193-17-000009:notes:117]
The Company generally enters into master netting arrangements, which are designed to reduce credit risk by permitting net settlement of transactions with the same counterparty. To further limit credit risk, the Company generally enters into collateral security arrangements that provide for collateral to be received or posted when the net fair value of certain financial instruments fluctuates from contractually established thresholds. The Company presents its derivative assets and derivative liabilities at their gross fair values in its Condensed Consolidated Balance Sheets. As of July 1, 2017, the net cash collateral posted by the Company related to derivative instruments under its collateral security arrangements was $162 million, which was recorded as other current assets in the Condensed Consolidated Balance Sheet. As of September 24, 2016, the net cash collateral received by the Company related to derivative instruments under its collateral security arrangements was $163 million, which was recorded as accrued expenses in the Condensed Consolidated Balance Sheet.

[0000320193-17-000009:notes:118]
Under master netting arrangements with the respective counterparties to the Company’s derivative contracts, the Company is allowed to net settle transactions with a single net amount payable by one party to the other. As of July 1, 2017 and September 24, 2016, the potential effects of these rights of set-off associated with the Company’s derivative contracts, including the effects of collateral, would be a reduction to both derivative assets and derivative liabilities of $1.3 billion and $1.5 billion, respectively, resulting in a net derivative liability of $326 million and a net derivative asset of $160 million, respectively.

[0000320193-17-000009:notes:119]
[same as prior period, unchanged from 0001628280-17-004790:notes:118]

[0000320193-17-000009:notes:120]
[same as prior period, unchanged from 0001628280-17-004790:notes:119]

[0000320193-17-000009:notes:121]
[same as prior period, unchanged from 0001628280-17-004790:notes:120]

[0000320193-17-000009:notes:122]
The Company had no customers that individually represented 10% or more of total trade receivables as of July 1, 2017. As of September 24, 2016, the Company had one customer that represented 10% or more of total trade receivables, which accounted for 10%. The Company’s cellular network carriers accounted for 46% and 63% of total trade receivables as of July 1, 2017 and September 24, 2016, respectively.

[0000320193-17-000009:notes:123]
[same as prior period, unchanged from 0001628280-17-004790:notes:122]

[0000320193-17-000009:notes:124]
The Company has non-trade receivables from certain of its manufacturing vendors resulting from the sale of components to these vendors who manufacture sub-assemblies or assemble final products for the Company. The Company purchases these components directly from suppliers. As of July 1, 2017, the Company had three vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 39%, 19% and 16%. As of September 24, 2016, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 47% and 21%.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000320193-17-000009:notes:125]
[same as prior period, unchanged from 0001628280-17-004790:notes:124]

[0000320193-17-000009:notes:126]
As of July 1, 2017, the Company recorded gross unrecognized tax benefits of $8.6 billion, of which $2.6 billion, if recognized, would affect the Company’s effective tax rate. As of September 24, 2016, the total amount of gross unrecognized tax benefits was $7.7 billion, of which $2.8 billion, if recognized, would have affected the Company’s effective tax rate. The Company’s total gross unrecognized tax benefits are classified as other non-current liabilities in the Condensed Consolidated Balance Sheets. The Company had $1.3 billion and $1.0 billion of gross interest and penalties accrued as of July 1, 2017 and September 24, 2016, respectively, which are classified as other non-current liabilities in the Condensed Consolidated Balance Sheets.

[0000320193-17-000009:notes:127]
The Company believes that an adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax audits cannot be predicted with certainty. If any issues addressed in the Company’s tax audits are resolved in a manner not consistent with its expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. Although timing of the resolution and/or closure of audits is not certain, the Company believes it is reasonably possible that its gross unrecognized tax benefits could decrease (whether by payment, release or a combination of both) in the next 12 months by as much as $700 million.

[0000320193-17-000009:notes:128]
On August 30, 2016, the European Commission announced its decision that Ireland granted state aid to the Company by providing tax opinions in 1991 and 2007 concerning the tax allocation of profits of the Irish branches of two subsidiaries of the Company (the “State Aid Decision”). The State Aid Decision orders Ireland to calculate and recover additional taxes from the Company for the period June 2003 through December 2014. Irish legislative changes, effective as of January 2015, eliminated the application of the tax opinions from that date forward. The Company believes the State Aid Decision to be without merit and appealed to the General Court of the Court of Justice of the European Union. Ireland has also appealed the State Aid Decision. While the European Commission announced a recovery amount of up to €13 billion, plus interest, the actual amount of additional taxes subject to recovery is to be calculated by Ireland in accordance with the European Commission’s guidance. Once the recovery amount is computed by Ireland, the Company anticipates funding it, including interest, out of foreign cash into escrow, where it will remain pending conclusion of all appeals. The Company believes that any incremental Irish corporate income taxes potentially due related to the State Aid Decision would be creditable against U.S. taxes.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000320193-17-000009:notes:129]
[same as prior period, unchanged from 0001628280-17-004790:notes:128]

[0000320193-17-000009:notes:130]
The Company’s acquired intangible assets with definite useful lives primarily consist of patents and licenses. The following table summarizes the components of acquired intangible asset balances as of July 1, 2017 and September 24, 2016 (in millions):

[0000320193-17-000009:notes:131]
|  | July 1, 2017 |  | September 24, 2016 |
|  | GrossCarrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |  | GrossCarrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |
| Definite-lived and amortizable acquired intangible assets | $ | 7,358 |  |  | $ | (5,014 | ) |  | $ | 2,344 |  |  | $ | 8,912 |  |  | $ | (5,806 | ) |  | $ | 3,106 |  |
| Indefinite-lived and non-amortizable acquired intangible assets | 100 |  |  | — |  |  | 100 |  |  | 100 |  |  | — |  |  | 100 |  |
| Total acquired intangible assets | $ | 7,458 |  |  | $ | (5,014 | ) |  | $ | 2,444 |  |  | $ | 9,012 |  |  | $ | (5,806 | ) |  | $ | 3,206 |  |


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0000320193-17-000009:notes:132]
A reconciliation of the Company’s segment operating income to the Condensed Consolidated Statements of Operations for the three- and nine-month periods ended July 1, 2017 and June 25, 2016 is as follows (in millions):

[0000320193-17-000009:notes:133]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1, 2017 |  | June 25, 2016 |  | July 1, 2017 |  | June 25, 2016 |
| Segment operating income | $ | 14,922 |  |  | $ | 13,722 |  |  | $ | 60,319 |  |  | $ | 58,928 |  |
| Research and development expense | (2,937 | ) |  | (2,560 | ) |  | (8,584 | ) |  | (7,475 | ) |
| Other corporate expenses, net | (1,217 | ) |  | (1,057 | ) |  | (3,511 | ) |  | (3,190 | ) |
| Total operating income | $ | 10,768 |  |  | $ | 10,105 |  |  | $ | 48,224 |  |  | $ | 48,263 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000320193-17-000009:notes:134]
The following table shows information by reportable operating segment for the three- and nine-month periods ended July 1, 2017 and June 25, 2016 (in millions):

[0000320193-17-000009:notes:135]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1, 2017 |  | June 25, 2016 |  | July 1, 2017 |  | June 25, 2016 |
| Americas: |  |  |  |  |  |  |  |
| Net sales | $ | 20,376 |  |  | $ | 17,963 |  |  | $ | 73,501 |  |  | $ | 66,384 |  |
| Operating income | $ | 6,420 |  |  | $ | 5,453 |  |  | $ | 23,582 |  |  | $ | 21,587 |  |
| Europe: |  |  |  |  |  |  |  |
| Net sales | $ | 10,675 |  |  | $ | 9,643 |  |  | $ | 41,929 |  |  | $ | 39,110 |  |
| Operating income | $ | 2,984 |  |  | $ | 2,666 |  |  | $ | 12,571 |  |  | $ | 12,047 |  |
| Greater China: |  |  |  |  |  |  |  |
| Net sales | $ | 8,004 |  |  | $ | 8,848 |  |  | $ | 34,963 |  |  | $ | 39,707 |  |
| Operating income | $ | 3,002 |  |  | $ | 3,415 |  |  | $ | 13,402 |  |  | $ | 15,809 |  |
| Japan: |  |  |  |  |  |  |  |
| Net sales | $ | 3,624 |  |  | $ | 3,529 |  |  | $ | 13,875 |  |  | $ | 12,604 |  |
| Operating income | $ | 1,624 |  |  | $ | 1,435 |  |  | $ | 6,334 |  |  | $ | 5,605 |  |
| Rest of Asia Pacific: |  |  |  |  |  |  |  |
| Net sales | $ | 2,729 |  |  | $ | 2,375 |  |  | $ | 12,387 |  |  | $ | 10,982 |  |
| Operating income | $ | 892 |  |  | $ | 753 |  |  | $ | 4,430 |  |  | $ | 3,880 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000320193-17-000009:notes:136]
[same as prior period, unchanged from 0001628280-17-004790:notes:135]

[0000320193-17-000009:notes:137]
[same as prior period, unchanged from 0001628280-17-004790:notes:136]

[0000320193-17-000009:notes:138]
[same as prior period, unchanged from 0001628280-17-004790:notes:137]

[0000320193-17-000009:notes:139]
[same as prior period, unchanged from 0001628280-17-004790:notes:138]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000320193-17-000009:notes:140]
[same as prior period, unchanged from 0001628280-17-004790:notes:139]

[0000320193-17-000009:notes:141]
[same as prior period, unchanged from 0001628280-17-004790:notes:140]

[0000320193-17-000009:notes:142]
[same as prior period, unchanged from 0001628280-17-004790:notes:141]

[0000320193-17-000009:notes:143]
[same as prior period, unchanged from 0001628280-17-004790:notes:142]

[0000320193-17-000009:notes:144]
In May 2017, the Company’s Board of Directors increased the share repurchase authorization from $175 billion to $210 billion of the Company’s common stock, of which $158 billion had been utilized as of July 1, 2017. The Company’s share repurchase program does not obligate it to acquire any specific number of shares. Under the program, shares may be repurchased in privately negotiated and/or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).

[0000320193-17-000009:notes:145]
[same as prior period, unchanged from 0001628280-17-004790:notes:144]
