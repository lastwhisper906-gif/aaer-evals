# AAPL 8-K — 0000320193-17-000006 filed 2017-08-01

## item codes, every 8-K on or before 2017-08-02

- 2017-08-01 0000320193-17-000006 — 2.02, 9.01
- 2017-06-20 0001193125-17-208226 — 8.01, 9.01
- 2017-05-24 0001193125-17-181867 — 8.01, 9.01
- 2017-05-11 0001193125-17-167400 — 8.01, 9.01
- 2017-05-02 0001628280-17-004663 — 2.02, 9.01
- 2017-03-03 0001193125-17-069853 — 8.01, 9.01
- 2017-03-01 0001193125-17-064019 — 5.07
- 2017-02-09 0001193125-17-036283 — 8.01, 9.01
- 2017-01-31 0001628280-17-000663 — 2.02, 9.01
- 2016-12-15 0001628280-16-022047 — 5.03, 9.01
- 2016-10-25 0001628280-16-020258 — 2.02, 9.01
- 2016-08-04 0001193125-16-672044 — 8.01, 9.01
- 2016-07-26 0001628280-16-017762 — 2.02, 9.01
- 2016-06-22 0001193125-16-628957 — 8.01, 9.01
- 2016-04-26 0001193125-16-556520 — 2.02, 9.01
- 2016-03-24 0001193125-16-516891 — 8.01, 9.01
- 2016-03-01 0001193125-16-488223 — 5.02, 5.07, 9.01
- 2016-02-23 0001193125-16-473562 — 8.01, 9.01
- 2016-01-26 0001193125-16-438421 — 2.02, 9.01
- 2015-12-22 0001193125-15-410853 — 5.03, 9.01
- 2015-12-17 0001193125-15-406279 — 5.02
- 2015-10-27 0001193125-15-354756 — 2.02, 9.01
- 2015-10-02 0001193125-15-336615 — 5.02
- 2015-09-17 0001193125-15-322466 — 8.01, 9.01
- 2015-07-31 0001193125-15-273023 — 8.01, 9.01
- 2015-07-21 0001193125-15-258464 — 2.02, 9.01
- 2015-06-10 0001193125-15-219298 — 8.01, 9.01
- 2015-05-13 0001193125-15-186064 — 8.01, 9.01
- 2015-04-27 0001193125-15-149607 — 7.01, 9.01
- 2015-04-27 0001193125-15-149590 — 2.02, 9.01
- 2015-03-13 0001104659-15-019336 — 5.07, 9.01
- 2015-02-09 0001193125-15-039270 — 8.01, 9.01
- 2015-01-28 0001193125-15-023732 — 8.01, 9.01
- 2015-01-27 0001193125-15-021857 — 2.02, 9.01
- 2014-11-10 0001193125-14-406296 — 8.01, 9.01
- 2014-10-20 0001193125-14-376361 — 2.02, 9.01
- 2014-07-23 0001193125-14-277193 — 8.01, 9.01
- 2014-07-22 0001193125-14-275598 — 2.02, 9.01
- 2014-07-17 0001193125-14-271698 — 5.02
- 2014-06-06 0001193125-14-228798 — 5.03, 9.01
- 2014-05-30 0001181431-14-021923 — 5.02
- 2014-05-06 0001193125-14-184969 — 8.01, 9.01
- 2014-04-23 0001193125-14-154883 — 7.01, 9.01
- 2014-04-23 0001193125-14-154871 — 2.02, 9.01
- 2014-03-05 0001193125-14-084697 — 5.02, 5.03, 5.07, 9.01
- 2014-01-27 0001193125-14-022238 — 2.02, 9.01
- 2013-10-28 0001193125-13-413498 — 2.02, 9.01
- 2013-09-23 0001181431-13-050140 — 8.01
- 2013-07-30 0001181431-13-041847 — 5.02
- 2013-07-23 0001193125-13-298914 — 2.02, 9.01
- 2013-06-21 0001193125-13-267629 — 5.02
- 2013-05-03 0001193125-13-199324 — 8.01, 9.01
- 2013-04-24 0001193125-13-170623 — 8.01, 9.01
- 2013-04-23 0001193125-13-167469 — 7.01, 9.01
- 2013-04-23 0001193125-13-167458 — 2.02, 9.01
- 2013-03-01 0001193125-13-085842 — 5.07
- 2013-01-23 0001193125-13-020783 — 2.02, 9.01
- 2012-10-25 0001193125-12-435506 — 2.02, 9.01
- 2012-07-24 0001193125-12-312355 — 2.02, 9.01
- 2012-06-28 0001181431-12-038301 — 5.02
- 2012-05-24 0001181431-12-032458 — 5.02
- 2012-04-24 0001193125-12-178928 — 2.02, 9.01
- 2012-02-27 0001193125-12-081892 — 5.07
- 2012-01-24 0001193125-12-021833 — 2.02, 9.01
- 2011-11-16 0001181431-11-056354 — 5.02
- 2011-10-18 0001193125-11-273826 — 2.02, 9.01
- 2011-10-06 0001181431-11-051976 — 8.01
- 2011-08-26 0001181431-11-047179 — 5.02
- 2011-07-19 0001193125-11-191368 — 2.02, 9.01
- 2011-06-15 0001181431-11-036782 — 5.02
- 2011-04-20 0001193125-11-103732 — 2.02, 9.01
- 2011-02-24 0001193125-11-045411 — 5.07
- 2011-01-18 0001193125-11-009392 — 2.02, 9.01
- 2011-01-18 0001181431-11-003847 — 5.02
- 2010-11-17 0001181431-10-056327 — 5.02, 5.03, 9.01
- 2010-10-18 0001193125-10-230992 — 2.02, 9.01
- 2010-07-20 0001193125-10-161807 — 2.02, 9.01
- 2010-04-20 0001193125-10-087786 — 2.02, 9.01
- 2010-03-12 0001181431-10-016054 — 5.02
- 2010-03-01 0001193125-10-044765 — 5.02, 5.07, 9.01
- 2010-01-25 0001193125-10-012096 — 2.02, 9.01
- 2009-10-19 0001193125-09-209633 — 2.02, 9.01
- 2009-08-04 0001181431-09-037492 — 5.02
- 2009-07-21 0001193125-09-152290 — 2.02, 9.01
- 2009-06-02 0001181431-09-028400 — 5.03
- 2009-04-22 0001193125-09-084599 — 2.02, 9.01
- 2009-02-27 0001181431-09-012161 — 4.01
- 2009-01-21 0001193125-09-009009 — 2.02, 9.01
- 2009-01-16 0001181431-09-003017 — 5.02
- 2008-10-21 0001193125-08-213642 — 2.02, 9.01
- 2008-08-26 0001181431-08-050059 — 5.03
- 2008-07-21 0001193125-08-154381 — 2.02, 9.01
- 2008-06-09 0001181431-08-037620 — 8.01
- 2008-04-23 0001193125-08-088001 — 2.02, 9.01
- 2008-01-22 0001193125-08-009715 — 2.02, 9.01
- 2008-01-15 0001181431-08-003342 — 2.02, 8.01
- 2008-01-08 0001181431-08-002372 — 5.02
- 2007-10-22 0001104659-07-076142 — 2.02, 9.01
- 2007-07-25 0001104659-07-056111 — 2.02, 9.01
- 2007-05-16 0001104659-07-040672 — 5.02, 9.01
- 2007-04-25 0001104659-07-031354 — 2.02, 9.01
- 2007-04-24 0001104659-07-030938 — 8.01, 9.01
- 2007-02-21 0001104659-07-012760 — 5.03, 9.01
- 2007-01-17 0001104659-07-002905 — 2.02, 9.01
- 2007-01-10 0001104659-07-001648 — 5.03, 9.01
- 2006-10-27 0001104659-06-069015 — 8.01
- 2006-10-18 0001104659-06-067275 — 2.02, 9.01
- 2006-10-04 0001104659-06-064935 — 5.02, 8.01, 9.01
- 2006-09-01 0001104659-06-058808 — 1.01, 5.02, 5.03, 9.01
- 2006-08-11 0001104659-06-054118 — 2.02, 3.01, 9.01
- 2006-08-04 0001104659-06-051302 — 2.02, 4.02, 9.01
- 2006-07-19 0001104659-06-047739 — 2.02, 9.01
- 2006-04-21 0001181431-06-024759 — 1.01
- 2006-04-19 0001104659-06-025992 — 2.02, 9.01
- 2006-01-18 0001104659-06-002690 — 2.02, 9.01
- 2006-01-10 0001104659-06-001428 — 2.02
- 2005-12-19 0001181431-05-067468 — 1.01
- 2005-10-14 0001181431-05-056604 — 5.02
- 2005-10-11 0001104659-05-048094 — 2.02, 9.01
- 2005-08-26 0001181431-05-049163 — 1.01
- 2005-08-15 0001181431-05-046871 — 1.01
- 2005-07-13 0001104659-05-032297 — 2.02, 9.01
- 2005-06-06 0001181431-05-033177 — 8.01
- 2005-04-26 0001181431-05-023450 — 1.01
- 2005-04-13 0001104659-05-016307 — 2.02, 9.01
- 2005-03-02 0001181431-05-013840 — 3.03, 5.03
- 2005-02-11 0001104659-05-005507 — 8.01
- 2005-01-12 0001104659-05-001183 — 2.02, 9.01
- 2005-01-11 0001104659-05-001049 — 2.02
- 2004-10-13 0001104659-04-030400 — 2.02, 9.01
- 2004-07-14 0001104659-04-019574 — 12, 7
- 2004-04-14 0001104659-04-010122 — 12, 7
- 2004-01-14 0001104659-04-000896 — 12, 7
- 2003-10-15 0001104659-03-022879 — 12, 7
- 2003-07-16 0001104659-03-014913 — 7, 9
- 2003-04-16 0001047469-03-013617 — 7, 9
- 2003-03-21 0001104659-03-004649 — 5, 7
- 2002-08-13 0000912057-02-031595 — 5, 7
- 2002-08-05 0000912057-02-029692 — 5, 7
- 2000-01-24 0000912057-00-002128 — 5, 7
- 1999-09-07 0000320193-99-000010 — 2
- 1999-07-16 0000320193-99-000007 — 2
- 1998-12-23 0000320193-98-000010 — 1
- 1998-01-08 0000320193-98-000001 — 2
- 1997-09-25 0000320193-97-000019 — 2
- 1997-09-25 0000320193-97-000018 — 2
- 1997-09-05 0000320193-97-000016 — 2
- 1997-07-28 0000320193-97-000012 — 4
- 1997-04-25 0000320193-97-000009 — 5
- 1997-04-10 0000320193-97-000007 — 7
- 1996-12-24 0000320193-96-000027 — 7
- 1996-12-23 0000320193-96-000025 — 4 — amendment of 0000320193-96-000021
- 1996-12-13 0000320193-96-000021 — 4
- 1996-10-28 0000912057-96-023874 — 5, 7
- 1996-06-17 0000320193-96-000014 — 1
- 1996-04-12 0000320193-96-000006 — 1

## late-filing notifications on or before 2017-08-02

- 2006-12-15 0001104659-06-081617 — NT 10-K, for the period ended 2006-09-30
- 2006-08-11 0001104659-06-053743 — NT 10-Q, for the period ended 2006-07-01

## item 2.02 — earnings release, exhibit 99.1

[0000320193-17-000006:8k_2_02:1]
EX-99.1
2
a8-kexhibit991q32017712017.htm
EXHIBIT 99.1

[0000320193-17-000006:8k_2_02:2]
Exhibit

[0000320193-17-000006:8k_2_02:3]
Exhibit 99.1

[0000320193-17-000006:8k_2_02:4]
Apple Reports Third Quarter Results

[0000320193-17-000006:8k_2_02:5]
Revenue Growth of 7 Percent and EPS Growth of 17 Percent

[0000320193-17-000006:8k_2_02:6]
Services Revenue Hits All-Time Quarterly Record

[0000320193-17-000006:8k_2_02:7]
CUPERTINO, California — August 1, 2017 — Apple® today announced financial results for its fiscal 2017 third quarter ended July 1, 2017. The Company posted quarterly revenue of $45.4 billion and quarterly earnings per diluted share of $1.67. These results compare to revenue of $42.4 billion and earnings per diluted share of $1.42 in the year-ago quarter. International sales accounted for 61 percent of the quarter’s revenue.

[0000320193-17-000006:8k_2_02:8]
“With revenue up 7 percent year-over-year, we’re happy to report our third consecutive quarter of accelerating growth and an all-time quarterly record for Services revenue,” said Tim Cook, Apple’s CEO. “We hosted an incredibly successful Worldwide Developers Conference in June, and we’re very excited about the advances in iOS, macOS, watchOS and tvOS coming this fall.”

[0000320193-17-000006:8k_2_02:9]
“We reported unit and revenue growth in all our product categories in the June quarter, driving 17 percent growth in earnings per share,” said Luca Maestri, Apple’s CFO. “We also returned $11.7 billion to investors during the quarter, bringing cumulative capital returns under our program to almost $223 billion.”

[0000320193-17-000006:8k_2_02:10]
Apple is providing the following guidance for its fiscal 2017 fourth quarter:

[0000320193-17-000006:8k_2_02:11]
| • | revenue between $49 billion and $52 billion |

[0000320193-17-000006:8k_2_02:12]
| • | gross margin between 37.5 percent and 38 percent |

[0000320193-17-000006:8k_2_02:13]
| • | operating expenses between $6.7 billion and $6.8 billion |

[0000320193-17-000006:8k_2_02:14]
| • | other income/(expense) of $500 million |

[0000320193-17-000006:8k_2_02:15]
| • | tax rate of 25.5 percent |

[0000320193-17-000006:8k_2_02:16]
Apple’s board of directors has declared a cash dividend of $0.63 per share of the Company’s common stock. The dividend is payable on August 17, 2017 to shareholders of record as of the close of business on August 14, 2017.

[0000320193-17-000006:8k_2_02:17]
Apple will provide live streaming of its Q3 2017 financial results conference call beginning at 2:00 p.m. PDT on August 1, 2017 at www.apple.com/investor/earnings-call/. This webcast will also be available for replay for approximately two weeks thereafter.

[0000320193-17-000006:8k_2_02:18]
Apple revolutionized personal technology with the introduction of the Macintosh in 1984. Today, Apple leads the world in innovation with iPhone, iPad, Mac, Apple Watch and Apple TV. Apple’s four software platforms — iOS, macOS, watchOS and tvOS — provide seamless experiences across all Apple devices and empower people with breakthrough services including the App Store, Apple Music, Apple Pay and iCloud. Apple’s more than 100,000 employees are dedicated to making the best products on earth, and to leaving the world better than we found it.

[0000320193-17-000006:8k_2_02:19]
Press Contact:

[0000320193-17-000006:8k_2_02:20]
Kristin Huguet

[0000320193-17-000006:8k_2_02:21]
Apple

[0000320193-17-000006:8k_2_02:22]
khuguet@apple.com

[0000320193-17-000006:8k_2_02:23]
(408) 974-2414

[0000320193-17-000006:8k_2_02:24]
Investor Relations Contacts:

[0000320193-17-000006:8k_2_02:25]
Nancy Paxton

[0000320193-17-000006:8k_2_02:26]
Apple

[0000320193-17-000006:8k_2_02:27]
paxton1@apple.com

[0000320193-17-000006:8k_2_02:28]
(408) 974-5420

[0000320193-17-000006:8k_2_02:29]
Joan Hoover

[0000320193-17-000006:8k_2_02:30]
Apple

[0000320193-17-000006:8k_2_02:31]
hoover1@apple.com

[0000320193-17-000006:8k_2_02:32]
(408) 974-4570

[0000320193-17-000006:8k_2_02:33]
NOTE TO EDITORS: For additional information visit Apple Newsroom (www.apple.com/newsroom), or call Apple’s Media Helpline at (408) 974-2042.

[0000320193-17-000006:8k_2_02:34]
© 2017 Apple Inc. All rights reserved. Apple and the Apple logo are trademarks of Apple. Other company and product names may be trademarks of their respective owners.

[0000320193-17-000006:8k_2_02:35]
Apple Inc.

[0000320193-17-000006:8k_2_02:36]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS (Unaudited)

[0000320193-17-000006:8k_2_02:37]
(In millions, except number of shares which are reflected in thousands and per share amounts)

[0000320193-17-000006:8k_2_02:38]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1, 2017 |  | June 25, 2016 |  | July 1, 2017 |  | June 25, 2016 |
| Net sales | $ | 45,408 |  |  | $ | 42,358 |  |  | $ | 176,655 |  |  | $ | 168,787 |  |
| Cost of sales (1) | 27,920 |  |  | 26,252 |  |  | 108,400 |  |  | 102,337 |  |
| Gross margin | 17,488 |  |  | 16,106 |  |  | 68,255 |  |  | 66,450 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development (1) | 2,937 |  |  | 2,560 |  |  | 8,584 |  |  | 7,475 |  |
| Selling, general and administrative (1) | 3,783 |  |  | 3,441 |  |  | 11,447 |  |  | 10,712 |  |
| Total operating expenses | 6,720 |  |  | 6,001 |  |  | 20,031 |  |  | 18,187 |  |
| Operating income | 10,768 |  |  | 10,105 |  |  | 48,224 |  |  | 48,263 |  |
| Other income/(expense), net | 540 |  |  | 364 |  |  | 1,948 |  |  | 921 |  |
| Income before provision for income taxes | 11,308 |  |  | 10,469 |  |  | 50,172 |  |  | 49,184 |  |
| Provision for income taxes | 2,591 |  |  | 2,673 |  |  | 12,535 |  |  | 12,511 |  |
| Net income | $ | 8,717 |  |  | $ | 7,796 |  |  | $ | 37,637 |  |  | $ | 36,673 |  |
| Earnings per share: |  |  |  |  |  |  |  |
| Basic | $ | 1.68 |  |  | $ | 1.43 |  |  | $ | 7.18 |  |  | $ | 6.66 |  |
| Diluted | $ | 1.67 |  |  | $ | 1.42 |  |  | $ | 7.14 |  |  | $ | 6.62 |  |
| Shares used in computing earnings per share: |  |  |  |  |  |  |  |
| Basic | 5,195,088 |  |  | 5,443,058 |  |  | 5,239,847 |  |  | 5,505,456 |  |
| Diluted | 5,233,499 |  |  | 5,472,781 |  |  | 5,274,394 |  |  | 5,535,931 |  |
| Cash dividends declared per share | $ | 0.63 |  |  | $ | 0.57 |  |  | $ | 1.77 |  |  | $ | 1.61 |  |
| (1) Includes share-based compensation expense as follows: |
| Cost of sales | $ | 216 |  |  | $ | 188 |  |  | $ | 662 |  |  | $ | 583 |  |
| Research and development | $ | 566 |  |  | $ | 479 |  |  | $ | 1,730 |  |  | $ | 1,413 |  |
| Selling, general and administrative | $ | 411 |  |  | $ | 387 |  |  | $ | 1,274 |  |  | $ | 1,184 |  |

[0000320193-17-000006:8k_2_02:39]
Apple Inc.

[0000320193-17-000006:8k_2_02:40]
CONDENSED CONSOLIDATED BALANCE SHEETS (Unaudited)

[0000320193-17-000006:8k_2_02:41]
(In millions, except number of shares which are reflected in thousands and par value)

[0000320193-17-000006:8k_2_02:42]
|  | July 1, 2017 |  | September 24, 2016 |
| ASSETS: |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 18,571 |  |  | $ | 20,484 |  |
| Short-term marketable securities | 58,188 |  |  | 46,671 |  |
| Accounts receivable, less allowances of $55 and $53, respectively | 12,399 |  |  | 15,754 |  |
| Inventories | 3,146 |  |  | 2,132 |  |
| Vendor non-trade receivables | 10,233 |  |  | 13,545 |  |
| Other current assets | 10,338 |  |  | 8,283 |  |
| Total current assets | 112,875 |  |  | 106,869 |  |
| Long-term marketable securities | 184,757 |  |  | 170,430 |  |
| Property, plant and equipment, net | 29,286 |  |  | 27,010 |  |
| Goodwill | 5,661 |  |  | 5,414 |  |
| Acquired intangible assets, net | 2,444 |  |  | 3,206 |  |
| Other non-current assets | 10,150 |  |  | 8,757 |  |
| Total assets | $ | 345,173 |  |  | $ | 321,686 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY: |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 31,915 |  |  | $ | 37,294 |  |
| Accrued expenses | 23,304 |  |  | 22,027 |  |
| Deferred revenue | 7,608 |  |  | 8,080 |  |
| Commercial paper | 11,980 |  |  | 8,105 |  |
| Current portion of long-term debt | 6,495 |  |  | 3,500 |  |
| Total current liabilities | 81,302 |  |  | 79,006 |  |
| Deferred revenue, non-current | 2,984 |  |  | 2,930 |  |
| Long-term debt | 89,864 |  |  | 75,427 |  |
| Other non-current liabilities | 38,598 |  |  | 36,074 |  |
| Total liabilities | 212,748 |  |  | 193,437 |  |
| Commitments and contingencies |  |  |  |
| Shareholders’ equity: |  |  |  |
| Common stock and additional paid-in capital, $0.00001 par value: 12,600,000 shares authorized; 5,169,782 and 5,336,166 shares issued and outstanding, respectively | 34,445 |  |  | 31,251 |  |
| Retained earnings | 98,525 |  |  | 96,364 |  |
| Accumulated other comprehensive income/(loss) | (545 | ) |  | 634 |  |
| Total shareholders’ equity | 132,425 |  |  | 128,249 |  |
| Total liabilities and shareholders’ equity | $ | 345,173 |  |  | $ | 321,686 |  |

[0000320193-17-000006:8k_2_02:43]
Apple Inc.

[0000320193-17-000006:8k_2_02:44]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (Unaudited)

[0000320193-17-000006:8k_2_02:45]
(In millions)

[0000320193-17-000006:8k_2_02:46]
|  | Nine Months Ended |
|  | July 1, 2017 |  | June 25, 2016 |
| Cash and cash equivalents, beginning of the period | $ | 20,484 |  |  | $ | 21,120 |  |
| Operating activities: |  |  |  |
| Net income | 37,637 |  |  | 36,673 |  |
| Adjustments to reconcile net income to cash generated by operating activities: |  |  |  |
| Depreciation and amortization | 7,673 |  |  | 7,957 |  |
| Share-based compensation expense | 3,666 |  |  | 3,180 |  |
| Deferred income tax expense | 4,764 |  |  | 5,191 |  |
| Other | (142 | ) |  | 419 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | 3,381 |  |  | 4,623 |  |
| Inventories | (1,014 | ) |  | 518 |  |
| Vendor non-trade receivables | 3,312 |  |  | 6,166 |  |
| Other current and non-current assets | (3,229 | ) |  | 1,049 |  |
| Accounts payable | (5,212 | ) |  | (9,567 | ) |
| Deferred revenue | (418 | ) |  | (1,148 | ) |
| Other current and non-current liabilities | (2,476 | ) |  | (5,363 | ) |
| Cash generated by operating activities | 47,942 |  |  | 49,698 |  |
| Investing activities: |  |  |  |
| Purchases of marketable securities | (123,781 | ) |  | (112,068 | ) |
| Proceeds from maturities of marketable securities | 19,347 |  |  | 14,915 |  |
| Proceeds from sales of marketable securities | 76,747 |  |  | 69,926 |  |
| Payments made in connection with business acquisitions, net | (248 | ) |  | (146 | ) |
| Payments for acquisition of property, plant and equipment | (8,586 | ) |  | (8,757 | ) |
| Payments for acquisition of intangible assets | (209 | ) |  | (753 | ) |
| Payments for strategic investments, net | (87 | ) |  | (1,376 | ) |
| Other | 313 |  |  | (321 | ) |
| Cash used in investing activities | (36,504 | ) |  | (38,580 | ) |
| Financing activities: |  |  |  |
| Proceeds from issuance of common stock | 274 |  |  | 247 |  |
| Excess tax benefits from equity awards | 534 |  |  | 391 |  |
| Payments for taxes related to net share settlement of equity awards | (1,646 | ) |  | (1,361 | ) |
| Payments for dividends and dividend equivalents | (9,499 | ) |  | (9,058 | ) |
| Repurchases of common stock | (25,105 | ) |  | (23,696 | ) |
| Proceeds from issuance of term debt, net | 21,725 |  |  | 17,984 |  |
| Repayments of term debt | (3,500 | ) |  | (2,500 | ) |
| Change in commercial paper, net | 3,866 |  |  | 3,992 |  |
| Cash used in financing activities | (13,351 | ) |  | (14,001 | ) |
| Increase/(Decrease) in cash and cash equivalents | (1,913 | ) |  | (2,883 | ) |
| Cash and cash equivalents, end of the period | $ | 18,571 |  |  | $ | 18,237 |  |
| Supplemental cash flow disclosure: |  |  |  |
| Cash paid for income taxes, net | $ | 9,752 |  |  | $ | 8,990 |  |
| Cash paid for interest | $ | 1,456 |  |  | $ | 892 |  |
