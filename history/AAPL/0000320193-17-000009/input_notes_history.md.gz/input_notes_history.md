# AAPL note change history — 0001628280-17-004790 → 0000320193-17-000009


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-08-02):
[0000320193-17-000009:note_history:1]
The following table shows changes in the Company’s accrued warranties and related costs for the three- and nine-month periods ended July 1, 2017 and June 25, 2016 (in millions):
  (was, 2017-05-03, similarity 0.9377):
[0001628280-17-004790:note_history:1]
The following table shows changes in the Company’s accrued warranties and related costs for the three- and six-month periods ended April 1, 2017 and March 26, 2016 (in millions):

- added (2017-08-02):
[0000320193-17-000009:note_history:2]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1, 2017 |  | June 25, 2016 |  | July 1, 2017 |  | June 25, 2016 |
| Beginning accrued warranty and related costs | $ | 4,735 |  |  | $ | 4,985 |  |  | $ | 3,702 |  |  | $ | 4,780 |  |
| Cost of warranty claims | (932 | ) |  | (1,110 | ) |  | (3,300 | ) |  | (3,507 | ) |
| Accruals for product warranty | 496 |  |  | 380 |  |  | 3,897 |  |  | 2,982 |  |
| Ending accrued warranty and related costs | $ | 4,299 |  |  | $ | 4,255 |  |  | $ | 4,299 |  |  | $ | 4,255 |  |

- added (2017-08-02):
[0000320193-17-000009:note_history:3]
Agreements entered into by the Company sometimes include indemnification provisions which may subject the Company to costs and damages in the event of a claim against an indemnified third party. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to indemnification of third parties.

- changed (2017-08-02):
[0000320193-17-000009:note_history:4]
The Company has entered into indemnification agreements with its directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers of the Company and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. While the Company maintains directors and officers liability insurance coverage, such insurance coverage may be insufficient to cover all losses or all types of claims that may arise.
  (was, 2017-05-03, similarity 0.8956):
[0001628280-17-004790:note_history:4]
The Company has entered into indemnification agreements with its directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, the Company maintains directors and officers liability insurance coverage to reduce its exposure to such obligations.

- changed (2017-08-02):
[0000320193-17-000009:note_history:5]
The Company leases various equipment and facilities, including retail space, under noncancelable operating lease arrangements. The Company does not currently utilize any other off-balance sheet financing arrangements. As of July 1, 2017, the Company’s total future minimum lease payments under noncancelable operating leases were $8.5 billion. The Company’s retail store and other facility leases are typically for terms not exceeding 10 years and generally contain multi-year renewal options.
  (was, 2017-05-03, similarity 0.9887):
[0001628280-17-004790:note_history:5]
The Company leases various equipment and facilities, including retail space, under noncancelable operating lease arrangements. The Company does not currently utilize any other off-balance sheet financing arrangements. As of April 1, 2017, the Company’s total future minimum lease payments under noncancelable operating leases were $8.2 billion. The Company's retail store and other facility leases are typically for terms not exceeding 10 years and generally contain multi-year renewal options.

- removed (2017-08-02):
[0001628280-17-004790:note_history:6]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1, 2017 |  | March 26, 2016 |  | April 1, 2017 |  | March 26, 2016 |
| Beginning accrued warranty and related costs | $ | 4,698 |  |  | $ | 5,236 |  |  | $ | 3,702 |  |  | $ | 4,780 |  |
| Cost of warranty claims | (1,031 | ) |  | (1,128 | ) |  | (2,368 | ) |  | (2,397 | ) |
| Accruals for product warranty | 1,068 |  |  | 877 |  |  | 3,401 |  |  | 2,602 |  |
| Ending accrued warranty and related costs | $ | 4,735 |  |  | $ | 4,985 |  |  | $ | 4,735 |  |  | $ | 4,985 |  |

- removed (2017-08-02):
[0001628280-17-004790:note_history:7]
The Company generally does not indemnify end-users of its operating system and application software against legal claims that the software infringes third-party intellectual property rights. Other agreements entered into by the Company sometimes include indemnification provisions under which the Company could be subject to costs and/or damages in the event of an infringement claim against the Company or an indemnified third party. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss with respect to indemnification of end-users of its operating system or application software for infringement of third-party intellectual property rights.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-08-02):
[0000320193-17-000009:note_history:8]
Apple Inc. and its wholly-owned subsidiaries (collectively “Apple” or the “Company”) designs, manufactures and markets mobile communication and media devices and personal computers, and sells a variety of related software, services, accessories, networking solutions and third-party digital content and applications. The Company’s products and services include iPhone®, iPad®, Mac®, Apple Watch®, Apple TV®, a portfolio of consumer and professional software applications, iOS, macOS®, watchOS® and tvOS™ operating systems, iCloud®, Apple Pay® and a variety of accessory, service and support offerings. The Company sells and delivers digital content and applications through the iTunes Store®, App Store®, Mac App Store, TV App Store, iBooks Store® and Apple Music® (collectively “Digital Content and Services”). The Company sells its products worldwide through its retail stores, online stores and direct sales force, as well as through third-party cellular network carriers, wholesalers, retailers and value-added resellers. In addition, the Company sells a variety of third-party Apple-compatible products, including application software and various accessories through its retail and online stores. The Company sells to consumers, small and mid-sized businesses and education, enterprise and government customers.
  (was, 2017-05-03, similarity 0.9992):
[0001628280-17-004790:note_history:8]
Apple Inc. and its wholly-owned subsidiaries (collectively “Apple” or the “Company”) designs, manufactures and markets mobile communication and media devices and personal computers, and sells a variety of related software, services, accessories, networking solutions and third-party digital content and applications. The Company’s products and services include iPhone®, iPad®, Mac®, Apple Watch®, Apple TV®, a portfolio of consumer and professional software applications, iOS, macOS®, watchOS® and tvOS™ operating systems, iCloud®, Apple Pay® and a variety of accessory, service and support offerings. The Company sells and delivers digital content and applications through the iTunes Store®, App Store®, Mac App Store, TV App Store, iBooks Store™ and Apple Music® (collectively “Digital Content and Services”). The Company sells its products worldwide through its retail stores, online stores and direct sales force, as well as through third-party cellular network carriers, wholesalers, retailers and value-added resellers. In addition, the Company sells a variety of third-party Apple-compatible products, including application software and various accessories through its retail and online stores. The Company sells to consumers, small and mid-sized businesses and education, enterprise and government customers.

- changed (2017-08-02):
[0000320193-17-000009:note_history:9]
The accompanying condensed consolidated financial statements include the accounts of the Company. Intercompany accounts and transactions have been eliminated. In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements in conformity with U.S. generally accepted accounting principles (“GAAP”) requires management to make estimates and assumptions that affect the amounts reported in these condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. Certain prior period amounts in the condensed consolidated financial statements have been reclassified to conform to the current period’s presentation. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company’s annual consolidated financial statements and the notes thereto included in its Annual Report on Form 10-K for the fiscal year ended September 24, 2016 (the “2016 Form 10-K”).
  (was, 2017-05-03, similarity 0.9992):
[0001628280-17-004790:note_history:9]
The accompanying condensed consolidated financial statements include the accounts of the Company. Intercompany accounts and transactions have been eliminated. In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements in conformity with U.S. generally accepted accounting principles (“GAAP”) requires management to make estimates and assumptions that affect the amounts reported in these condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. Certain prior period amounts in the condensed consolidated financial statements have been reclassified to conform to the current period’s presentation. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company's annual consolidated financial statements and the notes thereto included in its Annual Report on Form 10-K for the fiscal year ended September 24, 2016 (the “2016 Form 10-K”).

- changed (2017-08-02):
[0000320193-17-000009:note_history:10]
The following table shows the computation of basic and diluted earnings per share for the three- and nine-month periods ended July 1, 2017 and June 25, 2016 (net income in millions and shares in thousands):
  (was, 2017-05-03, similarity 0.9468):
[0001628280-17-004790:note_history:10]
The following table shows the computation of basic and diluted earnings per share for the three- and six-month periods ended April 1, 2017 and March 26, 2016 (net income in millions and shares in thousands):

- changed (2017-08-02):
[0000320193-17-000009:note_history:11]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1, 2017 |  | June 25, 2016 |  | July 1, 2017 |  | June 25, 2016 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 8,717 |  |  | $ | 7,796 |  |  | $ | 37,637 |  |  | $ | 36,673 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average shares outstanding | 5,195,088 |  |  | 5,443,058 |  |  | 5,239,847 |  |  | 5,505,456 |  |
| Effect of dilutive securities | 38,411 |  |  | 29,723 |  |  | 34,547 |  |  | 30,475 |  |
| Weighted-average diluted shares | 5,233,499 |  |  | 5,472,781 |  |  | 5,274,394 |  |  | 5,535,931 |  |
| Basic earnings per share | $ | 1.68 |  |  | $ | 1.43 |  |  | $ | 7.18 |  |  | $ | 6.66 |  |
| Diluted earnings per share | $ | 1.67 |  |  | $ | 1.42 |  |  | $ | 7.14 |  |  | $ | 6.62 |  |
  (was, 2017-05-03, similarity 0.8842):
[0001628280-17-004790:note_history:11]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1, 2017 |  | March 26, 2016 |  | April 1, 2017 |  | March 26, 2016 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 11,029 |  |  | $ | 10,516 |  |  | $ | 28,920 |  |  | $ | 28,877 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average shares outstanding | 5,225,791 |  |  | 5,514,381 |  |  | 5,262,226 |  |  | 5,536,656 |  |
| Effect of dilutive securities | 35,897 |  |  | 26,505 |  |  | 32,615 |  |  | 30,850 |  |
| Weighted-average diluted shares | 5,261,688 |  |  | 5,540,886 |  |  | 5,294,841 |  |  | 5,567,506 |  |
| Basic earnings per share | $ | 2.11 |  |  | $ | 1.91 |  |  | $ | 5.50 |  |  | $ | 5.22 |  |
| Diluted earnings per share | $ | 2.10 |  |  | $ | 1.90 |  |  | $ | 5.46 |  |  | $ | 5.19 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-08-02):
[0000320193-17-000009:note_history:12]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of July 1, 2017 and September 24, 2016, the Company had $12.0 billion and $8.1 billion of Commercial Paper outstanding, respectively, with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 1.01% as of July 1, 2017 and 0.45% as of September 24, 2016.
  (was, 2017-05-03, similarity 0.9835):
[0001628280-17-004790:note_history:12]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of April 1, 2017 and September 24, 2016, the Company had $10.0 billion and $8.1 billion of Commercial Paper outstanding, respectively, with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 0.80% as of April 1, 2017 and 0.45% as of September 24, 2016.

- changed (2017-08-02):
[0000320193-17-000009:note_history:13]
The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the nine months ended July 1, 2017 and June 25, 2016 (in millions):
  (was, 2017-05-03, similarity 0.9415):
[0001628280-17-004790:note_history:13]
The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the six months ended April 1, 2017 and March 26, 2016 (in millions):

- added (2017-08-02):
[0000320193-17-000009:note_history:14]
|  | Nine Months Ended |
|  | July 1, 2017 |  | June 25, 2016 |
| Maturities less than 90 days: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | (143 | ) |  | $ | 4,154 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 12,633 |  |  | 1,846 |  |
| Repayments of commercial paper | (8,624 | ) |  | (2,008 | ) |
| Proceeds from/(Repayments of) commercial paper, net | 4,009 |  |  | (162 | ) |
| Total change in commercial paper, net | $ | 3,866 |  |  | $ | 3,992 |  |

- changed (2017-08-02):
[0000320193-17-000009:note_history:15]
Term Debt
  (was, 2017-05-03, similarity 0.7826):
[0001628280-17-004790:note_history:15]
Long-Term Debt

- changed (2017-08-02):
[0000320193-17-000009:note_history:16]
As of July 1, 2017, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $96.6 billion (collectively the “Notes”). The Notes are senior unsecured obligations, and interest is payable in arrears, quarterly for the U.S. dollar-denominated and Australian dollar-denominated floating-rate notes, semi-annually for the U.S. dollar-denominated, Australian dollar-denominated, British pound-denominated and Japanese yen-denominated fixed-rate notes and annually for the euro-denominated and Swiss franc-denominated fixed-rate notes. The following table provides a summary of the Company’s term debt as of July 1, 2017 and September 24, 2016:
  (was, 2017-05-03, similarity 0.9869):
[0001628280-17-004790:note_history:16]
As of April 1, 2017, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $88.9 billion (collectively the “Notes”). The Notes are senior unsecured obligations, and interest is payable in arrears, quarterly for the U.S. dollar-denominated and Australian dollar-denominated floating-rate notes, semi-annually for the U.S. dollar-denominated, Australian dollar-denominated, British pound-denominated and Japanese yen-denominated fixed-rate notes and annually for the euro-denominated and Swiss franc-denominated fixed-rate notes. The following table provides a summary of the Company’s term debt as of April 1, 2017 and September 24, 2016:

- changed (2017-08-02):
[0000320193-17-000009:note_history:17]
|  | Maturities |  | July 1, 2017 |  | September 24, 2016 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2018 |  | 2018 |  | $ | 2,000 |  |  |  | 1.10% |  | 1.10 | % |  | $ | 2,000 |  |  |  | 1.10% |  | 1.10 | % |
| Fixed-rate 1.000% – 3.850% notes | 2018 | – | 2043 |  | 12,500 |  |  |  | 1.08% | – | 3.91 | % |  | 12,500 |  |  |  | 1.08% | – | 3.91 | % |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2019 |  | 1,000 |  |  |  | 1.48% |  | 1.48 | % |  | 2,000 |  |  |  | 0.86% | – | 1.09 | % |
| Fixed-rate 2.100% – 4.450% notes | 2019 | – | 2044 |  | 8,500 |  |  |  | 1.48% | – | 4.48 | % |  | 10,000 |  |  |  | 0.85% | – | 4.48 | % |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2020 |  | 1,532 |  |  |  | 1.43% | – | 1.87 | % |  | 1,781 |  |  |  | 0.87% | – | 1.87 | % |
| Fixed-rate 0.350% – 4.375% notes | 2019 | – | 2045 |  | 24,259 |  |  |  | 0.28% | – | 4.51 | % |  | 25,144 |  |  |  | 0.28% | – | 4.51 | % |
| 2016 debt issuances of $24.9 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2021 |  | 1,350 |  |  |  | 1.31% | – | 2.32 | % |  | 1,350 |  |  |  | 0.91% | – | 1.95 | % |
| Fixed-rate 1.100% – 4.650% notes | 2018 | – | 2046 |  | 23,610 |  |  |  | 1.13% | – | 4.78 | % |  | 23,609 |  |  |  | 1.13% | – | 4.58 | % |
| Second quarter 2017 debt issuance of $10.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2019 |  | 500 |  |  |  |  |  | 1.26 | % |  | — |  |  |  |  |  | — | % |
| Floating-rate notes |  |  | 2020 |  | 500 |  |  |  |  |  | 1.38 | % |  | — |  |  |  |  |  | — | % |
| Floating-rate notes |  |  | 2022 |  | 1,000 |  |  |  |  |  | 1.68 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 1.550% notes |  |  | 2019 |  | 500 |  |  |  |  |  | 1.59 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 1.900% notes |  |  | 2020 |  | 1,000 |  |  |  |  |  | 1.38 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.500% notes |  |  | 2022 |  | 1,500 |  |  |  |  |  | 1.67 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.000% notes |  |  | 2024 |  | 1,750 |  |  |  |  |  | 1.98 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.350% notes |  |  | 2027 |  | 2,250 |  |  |  |  |  | 2.12 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 4.250% notes |  |  | 2047 |  | 1,000 |  |  |  |  |  | 4.26 | % |  | — |  |  |  |  |  | — | % |
| Second quarter 2017 debt issuance of $1.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 4.300% notes |  |  | 2047 |  | 1,000 |  |  |  |  |  | 4.30 | % |  | — |  |  |  |  |  | — | % |
| Third quarter 2017 debt issuance of $7.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2020 |  | 500 |  |  |  |  |  | 1.25 | % |  | — |  |  |  |  |  | — | % |
| Floating-rate notes |  |  | 2022 |  | 750 |  |  |  |  |  | 1.53 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 1.800% notes |  |  | 2020 |  | 1,000 |  |  |  |  |  | 1.84 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.300% notes |  |  | 2022 |  | 1,000 |  |  |  |  |  | 2.34 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.850% notes |  |  | 2024 |  | 1,750 |  |  |  |  |  | 2.16 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.200% notes |  |  | 2027 |  | 2,000 |  |  |  |  |  | 2.34 | % |  | — |  |  |  |  |  | — | % |
| Third quarter 2017 euro-denominated debt issuance of €2.5 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.875% notes |  |  | 2025 |  | 1,419 |  |  |  |  |  | 3.03 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 1.375% notes |  |  | 2029 |  | 1,419 |  |  |  |  |  | 3.37 | % |  | — |  |  |  |  |  | — | % |
| Third quarter 2017 debt issuance of $1.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 3.000% notes |  |  | 2027 |  | 1,000 |  |  |  |  |  | 3.03 | % |  | — |  |  |  |  |  | — | % |
| Total term debt |  |  |  |  | 96,589 |  |  |  |  |  |  |  | 78,384 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (210 | ) |  |  |  |  |  |  | (174 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | (20 | ) |  |  |  |  |  |  | 717 |  |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  |  |  | (6,495 | ) |  |  |  |  |  |  | (3,500 | ) |  |  |  |  |  |
| Total long-term debt |  |  |  |  | $ | 89,864 |  |  |  |  |  |  |  | $ | 75,427 |  |  |  |  |  |  |
  (was, 2017-05-03, similarity 0.8389):
[0001628280-17-004790:note_history:17]
|  | Maturities |  | April 1, 2017 |  | September 24, 2016 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2018 |  | 2018 |  | $ | 2,000 |  |  |  | 1.10% |  | 1.10 | % |  | $ | 2,000 |  |  |  | 1.10% |  | 1.10 | % |
| Fixed-rate 1.000% – 3.850% notes | 2018 | – | 2043 |  | 12,500 |  |  |  | 1.08% | – | 3.91 | % |  | 12,500 |  |  |  | 1.08% | – | 3.91 | % |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2017 | – | 2019 |  | 2,000 |  |  |  | 1.10% | – | 1.33 | % |  | 2,000 |  |  |  | 0.86% | – | 1.09 | % |
| Fixed-rate 1.050% – 4.450% notes | 2017 | – | 2044 |  | 10,000 |  |  |  | 1.10% | – | 4.48 | % |  | 10,000 |  |  |  | 0.85% | – | 4.48 | % |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2017 | – | 2020 |  | 1,785 |  |  |  | 1.08% | – | 1.87 | % |  | 1,781 |  |  |  | 0.87% | – | 1.87 | % |
| Fixed-rate 0.350% – 4.375% notes | 2017 | – | 2045 |  | 24,668 |  |  |  | 0.28% | – | 4.51 | % |  | 25,144 |  |  |  | 0.28% | – | 4.51 | % |
| 2016 debt issuances of $24.9 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2021 |  | 1,350 |  |  |  | 1.17% | – | 2.18 | % |  | 1,350 |  |  |  | 0.91% | – | 1.95 | % |
| Fixed-rate 1.100% – 4.650% notes | 2018 | – | 2046 |  | 23,616 |  |  |  | 1.13% | – | 4.78 | % |  | 23,609 |  |  |  | 1.13% | – | 4.58 | % |
| Second quarter 2017 debt issuance of $10.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2019 |  | 500 |  |  |  |  |  | 1.12 | % |  | — |  |  |  |  |  | — | % |
| Floating-rate notes |  |  | 2020 |  | 500 |  |  |  |  |  | 1.24 | % |  | — |  |  |  |  |  | — | % |
| Floating-rate notes |  |  | 2022 |  | 1,000 |  |  |  |  |  | 1.54 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 1.550% notes |  |  | 2019 |  | 500 |  |  |  |  |  | 1.59 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 1.900% notes |  |  | 2020 |  | 1,000 |  |  |  |  |  | 1.24 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.500% notes |  |  | 2022 |  | 1,500 |  |  |  |  |  | 1.53 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.000% notes |  |  | 2024 |  | 1,750 |  |  |  |  |  | 1.83 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.350% notes |  |  | 2027 |  | 2,250 |  |  |  |  |  | 1.98 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 4.250% notes |  |  | 2047 |  | 1,000 |  |  |  |  |  | 4.26 | % |  | — |  |  |  |  |  | — | % |
| Second quarter 2017 debt issuance of $1.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 4.300% notes |  |  | 2047 |  | 1,000 |  |  |  |  |  | 4.30 | % |  | — |  |  |  |  |  | — | % |
| Total term debt |  |  |  |  | 88,919 |  |  |  |  |  |  |  | 78,384 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (184 | ) |  |  |  |  |  |  | (174 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | (205 | ) |  |  |  |  |  |  | 717 |  |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  |  |  | (3,999 | ) |  |  |  |  |  |  | (3,500 | ) |  |  |  |  |  |
| Total long-term debt |  |  |  |  | $ | 84,531 |  |  |  |  |  |  |  | $ | 75,427 |  |  |  |  |  |  |

- added (2017-08-02):
[0000320193-17-000009:note_history:18]
To manage interest rate risk on certain of its fixed-rate notes issued during the third quarter of 2017 and maturing in 2024 and 2027, the Company entered into interest rate swaps with an aggregate notional amount of $2.75 billion, which effectively converted the fixed interest rates on a portion of these notes to floating interest rates. The Company also hedged its entire third quarter 2017 issuance of €2.5 billion of euro-denominated notes by entering into foreign currency swaps to effectively convert these notes to U.S. dollar-denominated notes.

- changed (2017-08-02):
[0000320193-17-000009:note_history:19]
To manage interest rate risk on certain of its fixed-rate notes issued during the second quarter of 2017 and maturing in 2020, 2022, 2024 and 2027, the Company entered into interest rate swaps with an aggregate notional amount of $6.5 billion, which effectively converted the fixed interest rates on these notes to floating interest rates.
  (was, 2017-05-03, similarity 0.693):
[0001628280-17-004790:note_history:19]
During the second quarter of 2017, the Company issued $10.0 billion of U.S. dollar-denominated notes in the United States and $1.0 billion of U.S. dollar-denominated notes in Taiwan. To manage interest rate risk on the fixed-rate notes maturing in 2020, 2022, 2024 and 2027, the Company entered into interest rate swaps with an aggregate notional amount of $6.5 billion, which effectively converted the fixed interest rates on these notes to floating interest rates.

- changed (2017-08-02):
[0000320193-17-000009:note_history:20]
A portion of the Company’s Japanese yen-denominated notes is designated as a hedge of the foreign currency exposure of the Company’s net investment in a foreign operation. The foreign currency transaction gain or loss on the Japanese yen-denominated debt designated as a hedge is recorded in OCI as a part of the cumulative translation adjustment. As of July 1, 2017 and September 24, 2016, the carrying value of the debt designated as a net investment hedge was $1.5 billion and $1.9 billion, respectively. For further discussion regarding the Company’s use of derivative instruments see the Derivative Financial Instruments section of Note 2, “Financial Instruments.”
  (was, 2017-05-03, similarity 0.9901):
[0001628280-17-004790:note_history:20]
A portion of the Company's Japanese yen-denominated notes is designated as a hedge of the foreign currency exposure of the Company's net investment in a foreign operation. The foreign currency transaction gain or loss on the Japanese yen-denominated debt designated as a hedge is recorded in OCI as a part of the cumulative translation adjustment. As of April 1, 2017 and September 24, 2016, the carrying value of the debt designated as a net investment hedge was $1.7 billion and $1.9 billion, respectively. For further discussion regarding the Company’s use of derivative instruments see the Derivative Financial Instruments section of Note 2, “Financial Instruments.”

- changed (2017-08-02):
[0000320193-17-000009:note_history:21]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $574 million and $1.6 billion of interest expense on its term debt for the three- and nine-month periods ended July 1, 2017, respectively. The Company recognized $393 million and $975 million of interest expense on its term debt for the three- and nine-month periods ended June 25, 2016, respectively.
  (was, 2017-05-03, similarity 0.9542):
[0001628280-17-004790:note_history:21]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount and, if applicable, adjustments related to hedging. The Company recognized $507 million and $1.0 billion of interest expense on its term debt for the three- and six-month periods ended April 1, 2017, respectively. The Company recognized $311 million and $582 million of interest expense on its term debt for the three- and six-month periods ended March 26, 2016, respectively.

- changed (2017-08-02):
[0000320193-17-000009:note_history:22]
As of July 1, 2017 and September 24, 2016, the fair value of the Company’s Notes, based on Level 2 inputs, was $98.3 billion and $81.7 billion, respectively.
  (was, 2017-05-03, similarity 0.9753):
[0001628280-17-004790:note_history:22]
As of April 1, 2017 and September 24, 2016, the fair value of the Company’s Notes, based on Level 2 inputs, was $89.7 billion and $81.7 billion, respectively.

- removed (2017-08-02):
[0001628280-17-004790:note_history:23]
|  | Six Months Ended |
|  | April 1, 2017 |  | March 26, 2016 |
| Maturities less than 90 days: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | (1,318 | ) |  | $ | 660 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 7,057 |  |  | 669 |  |
| Repayments of commercial paper | (3,860 | ) |  | (1,832 | ) |
| Proceeds from/(Repayments of) commercial paper, net | 3,197 |  |  | (1,163 | ) |
| Total change in commercial paper, net | $ | 1,879 |  |  | $ | (503 | ) |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-08-02):
[0000320193-17-000009:note_history:24]
The following table provides a summary of the Company’s term debt as of July 1, 2017 and September 24, 2016:
  (was, 2017-05-03, similarity 0.9596):
[0001628280-17-004790:note_history:24]
he following table provides a summary of the Company’s term debt as of April 1, 2017 and September 24, 2016:

- changed (2017-08-02):
[0000320193-17-000009:note_history:25]
|  | Maturities |  | July 1, 2017 |  | September 24, 2016 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2018 |  | 2018 |  | $ | 2,000 |  |  |  | 1.10% |  | 1.10 | % |  | $ | 2,000 |  |  |  | 1.10% |  | 1.10 | % |
| Fixed-rate 1.000% – 3.850% notes | 2018 | – | 2043 |  | 12,500 |  |  |  | 1.08% | – | 3.91 | % |  | 12,500 |  |  |  | 1.08% | – | 3.91 | % |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2019 |  | 1,000 |  |  |  | 1.48% |  | 1.48 | % |  | 2,000 |  |  |  | 0.86% | – | 1.09 | % |
| Fixed-rate 2.100% – 4.450% notes | 2019 | – | 2044 |  | 8,500 |  |  |  | 1.48% | – | 4.48 | % |  | 10,000 |  |  |  | 0.85% | – | 4.48 | % |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2020 |  | 1,532 |  |  |  | 1.43% | – | 1.87 | % |  | 1,781 |  |  |  | 0.87% | – | 1.87 | % |
| Fixed-rate 0.350% – 4.375% notes | 2019 | – | 2045 |  | 24,259 |  |  |  | 0.28% | – | 4.51 | % |  | 25,144 |  |  |  | 0.28% | – | 4.51 | % |
| 2016 debt issuances of $24.9 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2021 |  | 1,350 |  |  |  | 1.31% | – | 2.32 | % |  | 1,350 |  |  |  | 0.91% | – | 1.95 | % |
| Fixed-rate 1.100% – 4.650% notes | 2018 | – | 2046 |  | 23,610 |  |  |  | 1.13% | – | 4.78 | % |  | 23,609 |  |  |  | 1.13% | – | 4.58 | % |
| Second quarter 2017 debt issuance of $10.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2019 |  | 500 |  |  |  |  |  | 1.26 | % |  | — |  |  |  |  |  | — | % |
| Floating-rate notes |  |  | 2020 |  | 500 |  |  |  |  |  | 1.38 | % |  | — |  |  |  |  |  | — | % |
| Floating-rate notes |  |  | 2022 |  | 1,000 |  |  |  |  |  | 1.68 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 1.550% notes |  |  | 2019 |  | 500 |  |  |  |  |  | 1.59 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 1.900% notes |  |  | 2020 |  | 1,000 |  |  |  |  |  | 1.38 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.500% notes |  |  | 2022 |  | 1,500 |  |  |  |  |  | 1.67 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.000% notes |  |  | 2024 |  | 1,750 |  |  |  |  |  | 1.98 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.350% notes |  |  | 2027 |  | 2,250 |  |  |  |  |  | 2.12 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 4.250% notes |  |  | 2047 |  | 1,000 |  |  |  |  |  | 4.26 | % |  | — |  |  |  |  |  | — | % |
| Second quarter 2017 debt issuance of $1.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 4.300% notes |  |  | 2047 |  | 1,000 |  |  |  |  |  | 4.30 | % |  | — |  |  |  |  |  | — | % |
| Third quarter 2017 debt issuance of $7.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2020 |  | 500 |  |  |  |  |  | 1.25 | % |  | — |  |  |  |  |  | — | % |
| Floating-rate notes |  |  | 2022 |  | 750 |  |  |  |  |  | 1.53 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 1.800% notes |  |  | 2020 |  | 1,000 |  |  |  |  |  | 1.84 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.300% notes |  |  | 2022 |  | 1,000 |  |  |  |  |  | 2.34 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.850% notes |  |  | 2024 |  | 1,750 |  |  |  |  |  | 2.16 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.200% notes |  |  | 2027 |  | 2,000 |  |  |  |  |  | 2.34 | % |  | — |  |  |  |  |  | — | % |
| Third quarter 2017 euro-denominated debt issuance of €2.5 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.875% notes |  |  | 2025 |  | 1,419 |  |  |  |  |  | 3.03 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 1.375% notes |  |  | 2029 |  | 1,419 |  |  |  |  |  | 3.37 | % |  | — |  |  |  |  |  | — | % |
| Third quarter 2017 debt issuance of $1.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 3.000% notes |  |  | 2027 |  | 1,000 |  |  |  |  |  | 3.03 | % |  | — |  |  |  |  |  | — | % |
| Total term debt |  |  |  |  | 96,589 |  |  |  |  |  |  |  | 78,384 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (210 | ) |  |  |  |  |  |  | (174 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | (20 | ) |  |  |  |  |  |  | 717 |  |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  |  |  | (6,495 | ) |  |  |  |  |  |  | (3,500 | ) |  |  |  |  |  |
| Total long-term debt |  |  |  |  | $ | 89,864 |  |  |  |  |  |  |  | $ | 75,427 |  |  |  |  |  |  |
  (was, 2017-05-03, similarity 0.8389):
[0001628280-17-004790:note_history:25]
|  | Maturities |  | April 1, 2017 |  | September 24, 2016 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2018 |  | 2018 |  | $ | 2,000 |  |  |  | 1.10% |  | 1.10 | % |  | $ | 2,000 |  |  |  | 1.10% |  | 1.10 | % |
| Fixed-rate 1.000% – 3.850% notes | 2018 | – | 2043 |  | 12,500 |  |  |  | 1.08% | – | 3.91 | % |  | 12,500 |  |  |  | 1.08% | – | 3.91 | % |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2017 | – | 2019 |  | 2,000 |  |  |  | 1.10% | – | 1.33 | % |  | 2,000 |  |  |  | 0.86% | – | 1.09 | % |
| Fixed-rate 1.050% – 4.450% notes | 2017 | – | 2044 |  | 10,000 |  |  |  | 1.10% | – | 4.48 | % |  | 10,000 |  |  |  | 0.85% | – | 4.48 | % |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2017 | – | 2020 |  | 1,785 |  |  |  | 1.08% | – | 1.87 | % |  | 1,781 |  |  |  | 0.87% | – | 1.87 | % |
| Fixed-rate 0.350% – 4.375% notes | 2017 | – | 2045 |  | 24,668 |  |  |  | 0.28% | – | 4.51 | % |  | 25,144 |  |  |  | 0.28% | – | 4.51 | % |
| 2016 debt issuances of $24.9 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2021 |  | 1,350 |  |  |  | 1.17% | – | 2.18 | % |  | 1,350 |  |  |  | 0.91% | – | 1.95 | % |
| Fixed-rate 1.100% – 4.650% notes | 2018 | – | 2046 |  | 23,616 |  |  |  | 1.13% | – | 4.78 | % |  | 23,609 |  |  |  | 1.13% | – | 4.58 | % |
| Second quarter 2017 debt issuance of $10.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2019 |  | 500 |  |  |  |  |  | 1.12 | % |  | — |  |  |  |  |  | — | % |
| Floating-rate notes |  |  | 2020 |  | 500 |  |  |  |  |  | 1.24 | % |  | — |  |  |  |  |  | — | % |
| Floating-rate notes |  |  | 2022 |  | 1,000 |  |  |  |  |  | 1.54 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 1.550% notes |  |  | 2019 |  | 500 |  |  |  |  |  | 1.59 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 1.900% notes |  |  | 2020 |  | 1,000 |  |  |  |  |  | 1.24 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.500% notes |  |  | 2022 |  | 1,500 |  |  |  |  |  | 1.53 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.000% notes |  |  | 2024 |  | 1,750 |  |  |  |  |  | 1.83 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.350% notes |  |  | 2027 |  | 2,250 |  |  |  |  |  | 1.98 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 4.250% notes |  |  | 2047 |  | 1,000 |  |  |  |  |  | 4.26 | % |  | — |  |  |  |  |  | — | % |
| Second quarter 2017 debt issuance of $1.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 4.300% notes |  |  | 2047 |  | 1,000 |  |  |  |  |  | 4.30 | % |  | — |  |  |  |  |  | — | % |
| Total term debt |  |  |  |  | 88,919 |  |  |  |  |  |  |  | 78,384 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (184 | ) |  |  |  |  |  |  | (174 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | (205 | ) |  |  |  |  |  |  | 717 |  |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  |  |  | (3,999 | ) |  |  |  |  |  |  | (3,500 | ) |  |  |  |  |  |
| Total long-term debt |  |  |  |  | $ | 84,531 |  |  |  |  |  |  |  | $ | 75,427 |  |  |  |  |  |  |
