# AAPL MD&A — 0000320193-18-000145


## mdna

[0000320193-18-000145:mdna:1]
| Item 7. | Management’s Discussion and Analysis of Financial Condition and Results of Operations |

[0000320193-18-000145:mdna:2]
Overview and Highlights

[0000320193-18-000145:mdna:3]
The Company designs, manufactures and markets mobile communication and media devices and personal computers, and sells a variety of related software, services, accessories and third-party digital content and applications. The Company’s products and services include iPhone, iPad, Mac, Apple Watch, AirPods, Apple TV, HomePod, a portfolio of consumer and professional software applications, iOS, macOS, watchOS and tvOS operating systems, iCloud, Apple Pay and a variety of other accessory, service and support offerings. The Company sells and delivers digital content and applications through the iTunes Store, App Store, Mac App Store, TV App Store, Book Store and Apple Music (collectively “Digital Content and Services”). The Company sells its products worldwide through its retail stores, online stores and direct sales force, as well as through third-party cellular network carriers, wholesalers, retailers and resellers. In addition, the Company sells a variety of third-party Apple-compatible products, including application software and various accessories, through its retail and online stores. The Company sells to consumers, small and mid-sized businesses and education, enterprise and government customers.

[0000320193-18-000145:mdna:4]
Fiscal Period

[0000320193-18-000145:mdna:5]
The Company’s fiscal year is the 52- or 53-week period that ends on the last Saturday of September. The Company’s fiscal years 2018 and 2016 spanned 52 weeks each, whereas fiscal year 2017 included 53 weeks. A 14th week was included in the first quarter of 2017, as is done every five or six years, to realign the Company’s fiscal quarters with calendar quarters.

[0000320193-18-000145:mdna:6]
Fiscal 2018 Highlights

[0000320193-18-000145:mdna:7]
Net sales increased 16% or $36.4 billion during 2018 compared to 2017, driven by higher net sales of iPhone, Services and Other Products. Net sales increased year-over-year in each of the geographic reportable segments.

[0000320193-18-000145:mdna:8]
In May 2018, the Company announced a new capital return program of $100 billion and raised its quarterly dividend from $0.63 to $0.73 per share beginning in May 2018. During 2018, the Company spent $73.1 billion to repurchase shares of its common stock and paid dividends and dividend equivalents of $13.7 billion.

[0000320193-18-000145:mdna:9]
Fiscal 2017 Highlights

[0000320193-18-000145:mdna:10]
Net sales increased 6% or $13.6 billion during 2017 compared to 2016, primarily driven by growth in Services, iPhone and Mac. The year-over-year increase in net sales reflected growth in each of the geographic reportable segments, with the exception of Greater China. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on net sales during 2017.

[0000320193-18-000145:mdna:11]
In May 2017, the Company announced an increase to its capital return program by raising the total size of the program from $250 billion to $300 billion. This included increasing its share repurchase authorization from $175 billion to $210 billion and raising its quarterly dividend from $0.57 to $0.63 per share beginning in May 2017. During 2017, the Company spent $33.0 billion to repurchase shares of its common stock and paid dividends and dividend equivalents of $12.8 billion. The $210 billion share repurchase program was completed in the third quarter of 2018.

[0000320193-18-000145:mdna:12]
The Company issued $24.0 billion of U.S. dollar–denominated term debt, €2.5 billion of euro-denominated term debt and C$2.5 billion of Canadian dollar–denominated term debt during 2017.

[0000320193-18-000145:mdna:13]
Sales Data

[0000320193-18-000145:mdna:14]
The following table shows net sales by reportable segment and net sales and unit sales by product for 2018, 2017 and 2016 (dollars in millions and units in thousands):

[0000320193-18-000145:mdna:15]
|  | 2018 |  | Change |  | 2017 |  | Change |  | 2016 |
| Net Sales by Reportable Segment: |  |  |  |  |  |  |  |  |  |
| Americas | $ | 112,093 |  |  | 16 | % |  | $ | 96,600 |  |  | 12 | % |  | $ | 86,613 |  |
| Europe | 62,420 |  |  | 14 | % |  | 54,938 |  |  | 10 | % |  | 49,952 |  |
| Greater China | 51,942 |  |  | 16 | % |  | 44,764 |  |  | (8 | )% |  | 48,492 |  |
| Japan | 21,733 |  |  | 23 | % |  | 17,733 |  |  | 5 | % |  | 16,928 |  |
| Rest of Asia Pacific | 17,407 |  |  | 15 | % |  | 15,199 |  |  | 11 | % |  | 13,654 |  |
| Total net sales | $ | 265,595 |  |  | 16 | % |  | $ | 229,234 |  |  | 6 | % |  | $ | 215,639 |  |
| Net Sales by Product: |  |  |  |  |  |  |  |  |  |
| iPhone (1) | $ | 166,699 |  |  | 18 | % |  | $ | 141,319 |  |  | 3 | % |  | $ | 136,700 |  |
| iPad (1) | 18,805 |  |  | (2 | )% |  | 19,222 |  |  | (7 | )% |  | 20,628 |  |
| Mac (1) | 25,484 |  |  | (1 | )% |  | 25,850 |  |  | 13 | % |  | 22,831 |  |
| Services (2) | 37,190 |  |  | 24 | % |  | 29,980 |  |  | 23 | % |  | 24,348 |  |
| Other Products (1)(3) | 17,417 |  |  | 35 | % |  | 12,863 |  |  | 16 | % |  | 11,132 |  |
| Total net sales | $ | 265,595 |  |  | 16 | % |  | $ | 229,234 |  |  | 6 | % |  | $ | 215,639 |  |
| Unit Sales by Product: |  |  |  |  |  |  |  |  |  |
| iPhone | 217,722 |  |  | — | % |  | 216,756 |  |  | 2 | % |  | 211,884 |  |
| iPad | 43,535 |  |  | — | % |  | 43,753 |  |  | (4 | )% |  | 45,590 |  |
| Mac | 18,209 |  |  | (5 | )% |  | 19,251 |  |  | 4 | % |  | 18,484 |  |

[0000320193-18-000145:mdna:16]
| (1) | Includes deferrals and amortization of related software upgrade rights and non-software services. |

[0000320193-18-000145:mdna:17]
| (2) | Includes revenue from Digital Content and Services, AppleCare, Apple Pay, licensing and other services. Services net sales in 2018 included a favorable one-time item of $236 million in connection with the final resolution of various lawsuits. Services net sales in 2017 included a favorable one-time adjustment of $640 million due to a change in estimate based on the availability of additional supporting information. |

[0000320193-18-000145:mdna:18]
| (3) | Includes sales of AirPods, Apple TV, Apple Watch, Beats products, HomePod, iPod touch and other Apple-branded and third-party accessories. |

[0000320193-18-000145:mdna:19]
Product Performance

[0000320193-18-000145:mdna:20]
iPhone

[0000320193-18-000145:mdna:21]
The following table presents iPhone net sales and unit sales information for 2018, 2017 and 2016 (dollars in millions and units in thousands):

[0000320193-18-000145:mdna:22]
|  | 2018 |  | Change |  | 2017 |  | Change |  | 2016 |
| Net sales | $ | 166,699 |  |  | 18 | % |  | $ | 141,319 |  |  | 3 | % |  | $ | 136,700 |  |
| Percentage of total net sales | 63 | % |  |  |  |  | 62 | % |  |  |  | 63 | % |
| Unit sales | 217,722 |  |  | — | % |  | 216,756 |  |  | 2 | % |  | 211,884 |  |

[0000320193-18-000145:mdna:23]
iPhone net sales increased during 2018 compared to 2017 due primarily to a different mix of iPhones resulting in higher average selling prices.

[0000320193-18-000145:mdna:24]
iPhone net sales increased during 2017 compared to 2016 due to higher iPhone unit sales and a different mix of iPhones with higher average selling prices. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on iPhone net sales during 2017.

[0000320193-18-000145:mdna:25]
iPad

[0000320193-18-000145:mdna:26]
The following table presents iPad net sales and unit sales information for 2018, 2017 and 2016 (dollars in millions and units in thousands):

[0000320193-18-000145:mdna:27]
|  | 2018 |  | Change |  | 2017 |  | Change |  | 2016 |
| Net sales | $ | 18,805 |  |  | (2 | )% |  | $ | 19,222 |  |  | (7 | )% |  | $ | 20,628 |  |
| Percentage of total net sales | 7 | % |  |  |  | 8 | % |  |  |  | 10 | % |
| Unit sales | 43,535 |  |  | — | % |  | 43,753 |  |  | (4 | )% |  | 45,590 |  |

[0000320193-18-000145:mdna:28]
iPad net sales decreased during 2018 compared to 2017 due primarily to a different mix of iPads resulting in lower average selling prices. The strength in foreign currencies relative to the U.S. dollar had a favorable impact on iPad net sales during 2018.

[0000320193-18-000145:mdna:29]
iPad net sales decreased during 2017 compared to 2016 due to lower iPad unit sales and a different mix of iPads with lower average selling prices. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on iPad net sales during 2017.

[0000320193-18-000145:mdna:30]
Mac

[0000320193-18-000145:mdna:31]
The following table presents Mac net sales and unit sales information for 2018, 2017 and 2016 (dollars in millions and units in thousands):

[0000320193-18-000145:mdna:32]
|  | 2018 |  | Change |  | 2017 |  | Change |  | 2016 |
| Net sales | $ | 25,484 |  |  | (1 | )% |  | $ | 25,850 |  |  | 13 | % |  | $ | 22,831 |  |
| Percentage of total net sales | 10 | % |  |  |  | 11 | % |  |  |  | 11 | % |
| Unit sales | 18,209 |  |  | (5 | )% |  | 19,251 |  |  | 4 | % |  | 18,484 |  |

[0000320193-18-000145:mdna:33]
Mac net sales decreased during 2018 compared to 2017 due primarily to lower Mac unit sales, partially offset by a different mix of Macs with higher average selling prices. The strength in foreign currencies relative to the U.S. dollar had a favorable impact on Mac net sales during 2018.

[0000320193-18-000145:mdna:34]
Mac net sales increased during 2017 compared to 2016 due primarily to a different mix of Macs with higher average selling prices and higher Mac unit sales. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on Mac net sales during 2017.

[0000320193-18-000145:mdna:35]
Services

[0000320193-18-000145:mdna:36]
The following table presents Services net sales information for 2018, 2017 and 2016 (dollars in millions):

[0000320193-18-000145:mdna:37]
|  | 2018 |  | Change |  | 2017 |  | Change |  | 2016 |
| Net sales | $ | 37,190 |  |  | 24 | % |  | $ | 29,980 |  |  | 23 | % |  | $ | 24,348 |  |
| Percentage of total net sales | 14 | % |  |  |  | 13 | % |  |  |  | 11 | % |

[0000320193-18-000145:mdna:38]
The year-over-year growth in Services net sales in 2018 was due primarily to licensing, App Store and AppleCare. During 2018, the Company recognized a favorable one-time item of $236 million in connection with the final resolution of various lawsuits.

[0000320193-18-000145:mdna:39]
The year-over-year growth in Services net sales in 2017 was due primarily to increases in App Store and licensing sales. Services net sales in 2017 included a favorable one-time adjustment of $640 million due to a change in estimate based on the availability of additional supporting information.

[0000320193-18-000145:mdna:40]
Segment Operating Performance

[0000320193-18-000145:mdna:41]
The Company manages its business primarily on a geographic basis. The Company’s reportable segments consist of the Americas, Europe, Greater China, Japan and Rest of Asia Pacific. Americas includes both North and South America. Europe includes European countries, as well as India, the Middle East and Africa. Greater China includes China, Hong Kong and Taiwan. Rest of Asia Pacific includes Australia and those Asian countries not included in the Company’s other reportable segments. Although the reportable segments provide similar hardware and software products and similar services, each one is managed separately to better align with the location of the Company’s customers and distribution partners and the unique market dynamics of each geographic region. Further information regarding the Company’s reportable segments can be found in Part II, Item 8 of this Form 10-K in the Notes to Consolidated Financial Statements in Note 10, “Segment Information and Geographic Data.”

[0000320193-18-000145:mdna:42]
Americas

[0000320193-18-000145:mdna:43]
The following table presents Americas net sales information for 2018, 2017 and 2016 (dollars in millions):

[0000320193-18-000145:mdna:44]
|  | 2018 |  | Change |  | 2017 |  | Change |  | 2016 |
| Net sales | $ | 112,093 |  |  | 16 | % |  | $ | 96,600 |  |  | 12 | % |  | $ | 86,613 |  |
| Percentage of total net sales | 42 | % |  |  |  | 42 | % |  |  |  | 40 | % |

[0000320193-18-000145:mdna:45]
Americas net sales increased during 2018 compared to 2017 due to higher net sales of iPhone, Services and Other Products.

[0000320193-18-000145:mdna:46]
Americas net sales increased during 2017 compared to 2016 due primarily to higher net sales of iPhone, Services and Mac.

[0000320193-18-000145:mdna:47]
Europe

[0000320193-18-000145:mdna:48]
The following table presents Europe net sales information for 2018, 2017 and 2016 (dollars in millions):

[0000320193-18-000145:mdna:49]
|  | 2018 |  | Change |  | 2017 |  | Change |  | 2016 |
| Net sales | $ | 62,420 |  |  | 14 | % |  | $ | 54,938 |  |  | 10 | % |  | $ | 49,952 |  |
| Percentage of total net sales | 24 | % |  |  |  | 24 | % |  |  |  | 23 | % |

[0000320193-18-000145:mdna:50]
Europe net sales increased during 2018 compared to 2017 due primarily to higher net sales of iPhone and Services. The strength in foreign currencies relative to the U.S. dollar had a favorable impact on Europe net sales during 2018.

[0000320193-18-000145:mdna:51]
Europe net sales increased during 2017 compared to 2016 due primarily to higher net sales of iPhone and Services. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on Europe net sales during 2017.

[0000320193-18-000145:mdna:52]
Greater China

[0000320193-18-000145:mdna:53]
The following table presents Greater China net sales information for 2018, 2017 and 2016 (dollars in millions):

[0000320193-18-000145:mdna:54]
|  | 2018 |  | Change |  | 2017 |  | Change |  | 2016 |
| Net sales | $ | 51,942 |  |  | 16 | % |  | $ | 44,764 |  |  | (8 | )% |  | $ | 48,492 |  |
| Percentage of total net sales | 20 | % |  |  |  | 20 | % |  |  |  | 22 | % |

[0000320193-18-000145:mdna:55]
Greater China net sales increased during 2018 compared to 2017 due primarily to higher net sales of iPhone and Services. The strength in foreign currencies relative to the U.S. dollar had a favorable impact on Greater China net sales during 2018.

[0000320193-18-000145:mdna:56]
Greater China net sales decreased during 2017 compared to 2016 due primarily to lower net sales of iPhone, partially offset by higher net sales of Services. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on Greater China net sales during 2017.

[0000320193-18-000145:mdna:57]
Japan

[0000320193-18-000145:mdna:58]
The following table presents Japan net sales information for 2018, 2017 and 2016 (dollars in millions):

[0000320193-18-000145:mdna:59]
|  | 2018 |  | Change |  | 2017 |  | Change |  | 2016 |
| Net sales | $ | 21,733 |  |  | 23 | % |  | $ | 17,733 |  |  | 5 | % |  | $ | 16,928 |  |
| Percentage of total net sales | 8 | % |  |  |  | 8 | % |  |  |  | 8 | % |

[0000320193-18-000145:mdna:60]
Japan net sales increased during 2018 compared to 2017 due primarily to higher net sales of iPhone and Services.

[0000320193-18-000145:mdna:61]
The year-over-year increase in Japan net sales in 2017 was due to higher net sales of Services and the strength in the Japanese yen relative to the U.S. dollar.

[0000320193-18-000145:mdna:62]
Rest of Asia Pacific

[0000320193-18-000145:mdna:63]
The following table presents Rest of Asia Pacific net sales information for 2018, 2017 and 2016 (dollars in millions):

[0000320193-18-000145:mdna:64]
|  | 2018 |  | Change |  | 2017 |  | Change |  | 2016 |
| Net sales | $ | 17,407 |  |  | 15 | % |  | $ | 15,199 |  |  | 11 | % |  | $ | 13,654 |  |
| Percentage of total net sales | 7 | % |  |  |  | 7 | % |  |  |  | 6 | % |

[0000320193-18-000145:mdna:65]
Rest of Asia Pacific net sales increased during 2018 compared to 2017 due primarily to higher net sales of iPhone and Services. The strength in foreign currencies relative to the U.S. dollar had a favorable impact on Rest of Asia Pacific net sales during 2018.

[0000320193-18-000145:mdna:66]
Rest of Asia Pacific net sales increased during 2017 compared to 2016 due primarily to higher net sales of iPhone, Services and Mac. The strength in foreign currencies relative to the U.S. dollar had a favorable impact on Rest of Asia Pacific net sales during 2017.

[0000320193-18-000145:mdna:67]
Gross Margin

[0000320193-18-000145:mdna:68]
Gross margin for 2018, 2017 and 2016 was as follows (dollars in millions):

[0000320193-18-000145:mdna:69]
|  | 2018 |  | 2017 |  | 2016 |
| Net sales | $ | 265,595 |  |  | $ | 229,234 |  |  | $ | 215,639 |  |
| Cost of sales | 163,756 |  |  | 141,048 |  |  | 131,376 |  |
| Gross margin | $ | 101,839 |  |  | $ | 88,186 |  |  | $ | 84,263 |  |
| Gross margin percentage | 38.3 | % |  | 38.5 | % |  | 39.1 | % |

[0000320193-18-000145:mdna:70]
Gross margin increased in 2018 compared to 2017 due primarily to a favorable shift in mix of iPhones with higher average selling prices and higher Services net sales, partially offset by higher product cost structures. Gross margin percentage decreased year-over-year due primarily to higher product cost structures, partially offset by higher Services net sales. The strength in foreign currencies relative to the U.S. dollar had a favorable impact on gross margin and gross margin percentage during 2018.

[0000320193-18-000145:mdna:71]
Gross margin increased in 2017 compared to 2016 due primarily to a shift in mix to Services and an overall increase in product volumes. Gross margin percentage decreased year-over-year due primarily to higher product costs, partially offset by a favorable shift in mix to Services. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on gross margin and gross margin percentage during 2017.

[0000320193-18-000145:mdna:72]
The Company anticipates gross margin percentage during the first quarter of 2019 to be between 38.0% and 38.5%. The foregoing statement regarding the Company’s expected gross margin percentage in the first quarter of 2019 is forward-looking and could differ from actual results. The Company’s future gross margins can be impacted by multiple factors including, but not limited to, those set forth in Part I, Item 1A of this Form 10-K under the heading “Risk Factors” and those described in this paragraph. In general, the Company believes gross margins will be subject to volatility and remain under downward pressure due to a variety of factors, including: continued industry-wide global product pricing pressures and product pricing actions that the Company may take in response to such pressures; increased competition; the Company’s ability to effectively stimulate demand for certain of its products; compressed product life cycles; potential increases in the cost of components and outside manufacturing services; the Company’s ability to manage product quality and warranty costs effectively; shifts in the mix of products and services, or in the geographic, currency or channel mix; fluctuations in exchange rates; and costs associated with the Company’s frequent introductions and transitions of products and services.

[0000320193-18-000145:mdna:73]
Operating Expenses

[0000320193-18-000145:mdna:74]
Operating expenses for 2018, 2017 and 2016 were as follows (dollars in millions):

[0000320193-18-000145:mdna:75]
|  | 2018 |  | Change |  | 2017 |  | Change |  | 2016 |
| Research and development | $ | 14,236 |  |  | 23 | % |  | $ | 11,581 |  |  | 15 | % |  | $ | 10,045 |  |
| Percentage of total net sales | 5 | % |  |  |  | 5 | % |  |  |  | 5 | % |
| Selling, general and administrative | $ | 16,705 |  |  | 9 | % |  | $ | 15,261 |  |  | 8 | % |  | $ | 14,194 |  |
| Percentage of total net sales | 6 | % |  |  |  | 7 | % |  |  |  | 7 | % |
| Total operating expenses | $ | 30,941 |  |  | 15 | % |  | $ | 26,842 |  |  | 11 | % |  | $ | 24,239 |  |
| Percentage of total net sales | 12 | % |  |  |  | 12 | % |  |  |  | 11 | % |

[0000320193-18-000145:mdna:76]
Research and Development

[0000320193-18-000145:mdna:77]
The year-over-year growth in R&D expense in 2018 was driven primarily by increases in headcount-related expenses, infrastructure-related costs and material costs to support expanded R&D activities. R&D expense increased during 2017 compared to 2016 due primarily to increases in headcount-related expenses and material costs to support expanded R&D activities. The Company continues to believe that focused investments in R&D are critical to its future growth and competitive position in the marketplace, and to the development of new and updated products and services that are central to the Company’s core business strategy.

[0000320193-18-000145:mdna:78]
Selling, General and Administrative

[0000320193-18-000145:mdna:79]
The year-over-year growth in selling, general and administrative expense in 2018 was driven primarily by increases in in headcount-related expenses, professional services and infrastructure-related costs. The increase in selling, general and administrative expense in 2017 compared to 2016 was driven primarily by an increase in headcount-related expenses, variable selling expenses and infrastructure-related costs.

[0000320193-18-000145:mdna:80]
Other Income/(Expense), Net

[0000320193-18-000145:mdna:81]
Other income/(expense), net for 2018, 2017 and 2016 was as follows (dollars in millions):

[0000320193-18-000145:mdna:82]
|  | 2018 |  | Change |  | 2017 |  | Change |  | 2016 |
| Interest and dividend income | $ | 5,686 |  |  |  |  | $ | 5,201 |  |  |  |  | $ | 3,999 |  |
| Interest expense | (3,240 | ) |  |  |  | (2,323 | ) |  |  |  | (1,456 | ) |
| Other expense, net | (441 | ) |  |  |  | (133 | ) |  |  |  | (1,195 | ) |
| Total other income/(expense), net | $ | 2,005 |  |  | (27 | )% |  | $ | 2,745 |  |  | 104 | % |  | $ | 1,348 |  |

[0000320193-18-000145:mdna:83]
The year-over-year decrease in other income/(expense), net during 2018 was due primarily to higher interest expense on debt and the impact of foreign exchange–related items, partially offset by higher interest income. The year-over-year increase in other income/(expense), net during 2017 was due primarily to higher interest income and the favorable impact of foreign exchange–related items, partially offset by higher interest expense on debt. The weighted-average interest rate earned by the Company on its cash, cash equivalents and marketable securities was 2.16%, 1.99% and 1.73% in 2018, 2017 and 2016, respectively.

[0000320193-18-000145:mdna:84]
Provision for Income Taxes

[0000320193-18-000145:mdna:85]
Provision for income taxes and effective tax rates for 2018, 2017 and 2016 were as follows (dollars in millions):

[0000320193-18-000145:mdna:86]
|  | 2018 |  | 2017 |  | 2016 |
| Provision for income taxes | $ | 13,372 |  |  | $ | 15,738 |  |  | $ | 15,685 |  |
| Effective tax rate | 18.3 | % |  | 24.6 | % |  | 25.6 | % |

[0000320193-18-000145:mdna:87]
On December 22, 2017, the U.S. enacted the Tax Cuts and Jobs Act (the “Act”), which significantly changed U.S. tax law. The Act lowered the Company’s U.S. statutory federal income tax rate from 35% to 21% effective January 1, 2018, while also imposing a deemed repatriation tax on previously deferred foreign income. By operation of law, the Company applied a blended U.S. statutory federal income tax rate of 24.5% for 2018 (the “2018 blended U.S. tax rate”). The Act also created a new minimum tax on certain future foreign earnings.

[0000320193-18-000145:mdna:88]
The Company’s effective tax rate for 2018 was lower than the 2018 blended U.S. tax rate due primarily to the lower tax rate on foreign earnings, partially offset by the remeasurement of deferred tax assets and liabilities as a result of the Act.

[0000320193-18-000145:mdna:89]
The Company’s effective tax rates for 2017 and 2016 were lower than the historical statutory federal income tax rate of 35% due primarily to certain undistributed foreign earnings, a substantial portion of which was generated by subsidiaries organized in Ireland, for which no U.S. taxes were provided when such earnings were intended to be indefinitely reinvested outside the U.S.

[0000320193-18-000145:mdna:90]
The lower effective tax rate in 2018 compared to 2017 was due primarily to the lower 2018 blended U.S. tax rate, partially offset by the remeasurement of deferred tax assets and liabilities as a result of the Act. The lower effective tax rate in 2017 compared to 2016 was due to a different geographic mix of earnings and higher U.S. R&D tax credits.

[0000320193-18-000145:mdna:91]
As a result of adopting Accounting Standards Update (“ASU”) No. 2016-09, Compensation – Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting (“ASU 2016-09”), in 2018, the Company records any excess tax benefits or deficiencies from its equity awards as part of the provision for income taxes. The Company anticipates that these excess tax benefits or deficiencies will have the greatest impact on its effective tax rates in the first and third quarters, as the majority of the Company’s equity awards vest in those quarters.

[0000320193-18-000145:mdna:92]
As of September 29, 2018, the Company had deferred tax assets arising from deductible temporary differences, tax losses and tax credits of $6.3 billion and deferred tax liabilities of $426 million. Management believes it is more likely than not that forecasted income, including income that may be generated as a result of certain tax planning strategies, together with future reversals of existing taxable temporary differences, will be sufficient to recover the deferred tax assets. The Company will continue to evaluate the realizability of deferred tax assets quarterly by assessing the need for and the amount of a valuation allowance.

[0000320193-18-000145:mdna:93]
On August 30, 2016, the European Commission announced its decision that Ireland granted state aid to the Company by providing tax opinions in 1991 and 2007 concerning the tax allocation of profits of the Irish branches of two subsidiaries of the Company (the “State Aid Decision”). The State Aid Decision ordered Ireland to calculate and recover additional taxes from the Company for the period June 2003 through December 2014. The recovery amount was calculated to be €13.1 billion, plus interest of €1.2 billion. Irish legislative changes, effective as of January 2015, eliminated the application of the tax opinions from that date forward. The Company believes the State Aid Decision to be without merit and appealed to the General Court of the Court of Justice of the European Union. Ireland has also appealed the State Aid Decision. The Company believes that any incremental Irish corporate income taxes potentially due related to the State Aid Decision would be creditable against U.S. taxes, subject to any foreign tax credit limitations in the Act. As of September 29, 2018, the entire recovery amount plus interest was funded into escrow, where it will remain restricted from general use pending conclusion of all appeals.

[0000320193-18-000145:mdna:94]
On July 24, 2018, the U.S. Ninth Circuit Court of Appeals reversed the U.S. Tax Court's decision in Altera Corp v. Commissioner, regarding the inclusion of share-based compensation in cost-sharing arrangements with foreign subsidiaries. The reversal was subsequently withdrawn, and the Company believes adequate provision has been made for any adjustments that may result from the final resolution of the case.

[0000320193-18-000145:mdna:95]
Recent Accounting Pronouncements

[0000320193-18-000145:mdna:96]
Hedging

[0000320193-18-000145:mdna:97]
In August 2017, the Financial Accounting Standards Board (the “FASB”) issued ASU No. 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities (“ASU 2017-12”). ASU 2017-12 expands component and fair value hedging, specifies the presentation of the effects of hedging instruments, and eliminates the separate measurement and presentation of hedge ineffectiveness. The Company will adopt ASU 2017-12 in its first quarter of 2020 utilizing the modified retrospective transition method and is currently evaluating the impact of adoption on its consolidated financial statements.

[0000320193-18-000145:mdna:98]
Income Taxes

[0000320193-18-000145:mdna:99]
In October 2016, the FASB issued ASU No. 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory (“ASU 2016-16”), which requires the recognition of the income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. The Company will adopt ASU 2016-16 in its first quarter of 2019 utilizing the modified retrospective transition method. Currently, the Company estimates recording $3 billion of net deferred tax assets on its Condensed Consolidated Balance Sheets upon adoption. However, the ultimate impact of adopting ASU 2016-16 will depend on the balance of intellectual property transferred between its subsidiaries as of the adoption date, as well as the deferred tax impact of the new minimum tax on certain future foreign earnings. The Company will recognize incremental deferred income tax expense thereafter as these net deferred tax assets are utilized.

[0000320193-18-000145:mdna:100]
Leases

[0000320193-18-000145:mdna:101]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842) (“ASU 2016-02”), which modifies lease accounting for lessees to increase transparency and comparability by recording lease assets and liabilities for operating leases and disclosing key information about leasing arrangements. The Company will adopt ASU 2016-02 utilizing the modified retrospective transition method through a cumulative-effect adjustment at the beginning of its first quarter of 2020. While the Company is currently evaluating the impact of adopting ASU 2016-02, based on the lease portfolio as of September 29, 2018, the Company anticipates recording lease assets and liabilities of approximately $8.9 billion on its Condensed Consolidated Balance Sheets, with no material impact to its Condensed Consolidated Statements of Operations. However, the ultimate impact of adopting ASU 2016-02 will depend on the Company’s lease portfolio as of the adoption date.

[0000320193-18-000145:mdna:102]
Financial Instruments

[0000320193-18-000145:mdna:103]
In January 2016, the FASB issued ASU No. 2016-01, Financial Instruments – Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities (“ASU 2016-01”), which updates certain aspects of recognition, measurement, presentation and disclosure of financial instruments. The Company will adopt ASU 2016-01 in its first quarter of 2019 utilizing the modified retrospective transition method. Based on the composition of the Company’s investment portfolio, the adoption of ASU 2016-01 is not expected to have a material impact on its consolidated financial statements.

[0000320193-18-000145:mdna:104]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (“ASU 2016-13”), which modifies the measurement of expected credit losses of certain financial instruments. The Company will adopt ASU 2016-13 in its first quarter of 2021 utilizing the modified retrospective transition method. Based on the composition of the Company’s investment portfolio, current market conditions, and historical credit loss activity, the adoption of ASU 2016-13 is not expected to have a material impact on its consolidated financial statements.

[0000320193-18-000145:mdna:105]
Revenue Recognition

[0000320193-18-000145:mdna:106]
In May 2014, the FASB issued ASU No. 2014-09, Revenue from Contracts with Customers (Topic 606) (“ASU 2014-09”), which amends the existing accounting standards for revenue recognition. ASU 2014-09 is based on principles that govern the recognition of revenue at an amount an entity expects to be entitled when products are transferred to customers.

[0000320193-18-000145:mdna:107]
Subsequently, the FASB issued additional ASUs to clarify the guidance in ASU 2014-09. ASU 2014-09 and its related ASUs are collectively referred to herein as the “new revenue standard.” The new revenue standard may be applied retrospectively to each prior period presented or retrospectively with the cumulative effect recognized as of the date of adoption. The Company will adopt the new revenue standard in its first quarter of 2019 utilizing the full retrospective transition method. The new revenue standard will not have a material impact on the amount and timing of revenue recognized in the Company’s consolidated financial statements.

[0000320193-18-000145:mdna:108]
Liquidity and Capital Resources

[0000320193-18-000145:mdna:109]
The following table presents selected financial information and statistics as of and for the years ended September 29, 2018, September 30, 2017 and September 24, 2016 (in millions):

[0000320193-18-000145:mdna:110]
|  | 2018 |  | 2017 |  | 2016 |
| Cash, cash equivalents and marketable securities (1) | $ | 237,100 |  |  | $ | 268,895 |  |  | $ | 237,585 |  |
| Property, plant and equipment, net | $ | 41,304 |  |  | $ | 33,783 |  |  | $ | 27,010 |  |
| Commercial paper | $ | 11,964 |  |  | $ | 11,977 |  |  | $ | 8,105 |  |
| Total term debt | $ | 102,519 |  |  | $ | 103,703 |  |  | $ | 78,927 |  |
| Working capital | $ | 14,473 |  |  | $ | 27,831 |  |  | $ | 27,863 |  |
| Cash generated by operating activities (2) | $ | 77,434 |  |  | $ | 64,225 |  |  | $ | 66,231 |  |
| Cash generated by/(used in) investing activities | $ | 16,066 |  |  | $ | (46,446 | ) |  | $ | (45,977 | ) |
| Cash used in financing activities (2) | $ | (87,876 | ) |  | $ | (17,974 | ) |  | $ | (20,890 | ) |

[0000320193-18-000145:mdna:111]
| (1) | As of September 29, 2018, total cash, cash equivalents and marketable securities included $20.3 billion that was restricted from general use, related to the State Aid Decision and other agreements. |

[0000320193-18-000145:mdna:112]
| (2) | Refer to Note 1, “Summary of Significant Accounting Polices” in the Notes to Consolidated Financial Statements in Part II, Item 8 of this Form 10-K for more information on the prior period reclassification related to the Company’s adoption of ASU 2016-09. |

[0000320193-18-000145:mdna:113]
The Company believes its existing balances of cash, cash equivalents and marketable securities will be sufficient to satisfy its working capital needs, capital asset purchases, outstanding commitments and other liquidity requirements associated with its existing operations over the next 12 months. The Company currently anticipates the cash used for future dividends, the share repurchase program and debt repayments will come from its current cash and cash generated from ongoing operating activities.

[0000320193-18-000145:mdna:114]
In connection with the State Aid Decision, as of September 29, 2018, the entire recovery amount of €13.1 billion plus interest of €1.2 billion was funded into escrow, where it will remain restricted from general use pending conclusion of all appeals.

[0000320193-18-000145:mdna:115]
The Company’s marketable securities investment portfolio is primarily invested in highly rated securities, with the primary objective of minimizing the potential risk of principal loss. The Company’s investment policy generally requires securities to be investment grade and limits the amount of credit exposure to any one issuer.

[0000320193-18-000145:mdna:116]
During 2018, cash generated by operating activities of $77.4 billion was a result of $59.5 billion of net income and an increase in the net change in operating assets and liabilities of $34.7 billion, partially offset by non-cash adjustments to net income of $16.8 billion. Cash generated by investing activities of $16.1 billion during 2018 consisted primarily of proceeds from maturities and sales of marketable securities, net of purchases, of $32.4 billion, partially offset by cash used to acquire property, plant and equipment of $13.3 billion. Cash used in financing activities of $87.9 billion during 2018 consisted primarily of cash used to repurchase common stock of $72.7 billion, cash used to pay dividends and dividend equivalents of $13.7 billion and cash used to repay term debt of $6.5 billion, partially offset by proceeds from the issuance of term debt, net of $7.0 billion.

[0000320193-18-000145:mdna:117]
During 2017, cash generated by operating activities of $64.2 billion was a result of $48.4 billion of net income, non-cash adjustments to net income of $20.8 billion and a decrease in the net change in operating assets and liabilities of $4.9 billion, which included a one-time payment of $1.9 billion related to a multi-year license agreement. Cash used in investing activities of $46.4 billion during 2017 consisted primarily of cash used for purchases of marketable securities, net of sales and maturities, of $33.1 billion and cash used to acquire property, plant and equipment of $12.5 billion. Cash used in financing activities of $18.0 billion during 2017 consisted primarily of cash used to repurchase common stock of $32.9 billion, cash used to pay dividends and dividend equivalents of $12.8 billion and cash used to repay term debt of $3.5 billion, partially offset by proceeds from the issuance of term debt, net of $28.7 billion and proceeds from commercial paper, net of $3.9 billion.

[0000320193-18-000145:mdna:118]
Capital Assets

[0000320193-18-000145:mdna:119]
The Company’s capital expenditures were $16.7 billion during 2018. The Company anticipates utilizing approximately $14.0 billion for capital expenditures during 2019, which includes product tooling and manufacturing process equipment; data centers; corporate facilities and infrastructure, including information systems hardware, software and enhancements; and retail store facilities.

[0000320193-18-000145:mdna:120]
Debt

[0000320193-18-000145:mdna:121]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses the net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of September 29, 2018, the Company had $12.0 billion of Commercial Paper outstanding, with a weighted-average interest rate of 2.18% and maturities generally less than nine months.

[0000320193-18-000145:mdna:122]
As of September 29, 2018, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $104.2 billion (collectively the “Notes”). During 2018, the Company issued $7.0 billion and repaid $6.5 billion of Notes. The Company has entered, and in the future may enter, into interest rate swaps to manage interest rate risk on the Notes. In addition, the Company has entered, and in the future may enter, into foreign currency swaps to manage foreign currency risk on the Notes.

[0000320193-18-000145:mdna:123]
Further information regarding the Company’s debt issuances and related hedging activity can be found in Part II, Item 8 of this Form 10-K in the Notes to Consolidated Financial Statements in Note 2, “Financial Instruments” and Note 5, “Debt.”

[0000320193-18-000145:mdna:124]
Capital Return Program

[0000320193-18-000145:mdna:125]
During 2018, the Company repurchased 405.5 million shares of its common stock for $73.1 billion in connection with two separate share repurchase programs. Of the $73.1 billion, $44.0 billion was repurchased under the Company’s previous share repurchase program of up to $210 billion, thereby completing that program. On May 1, 2018, the Company announced the Board of Directors had authorized a new program to repurchase up to $100 billion of the Company’s common stock. The remaining $29.0 billion repurchased during 2018 was in connection with the new share repurchase program. The Company’s new share repurchase program does not obligate it to acquire any specific number of shares. Under this program, shares may be repurchased in privately negotiated and/or open market transactions, including under plans complying with Rule 10b5-1 under the Exchange Act.

[0000320193-18-000145:mdna:126]
On May 1, 2018, the Company also announced the Board of Directors raised the Company’s quarterly cash dividend from $0.63 to $0.73 per share, beginning with the dividend paid during the third quarter of 2018. The Company intends to increase its dividend on an annual basis, subject to declaration by the Board of Directors. The Company plans to use current cash and cash generated from ongoing operating activities to fund its share repurchase program and quarterly cash dividend.

[0000320193-18-000145:mdna:127]
Contractual Obligations

[0000320193-18-000145:mdna:128]
The following table presents certain payments due by the Company as of September 29, 2018, and excludes amounts already recorded on the Consolidated Balance Sheet, except for term debt and the deemed repatriation tax payable (in millions):

[0000320193-18-000145:mdna:129]
|  | Payments Due in 2019 |  | Payments Duein 2020–2021 |  | Payments Duein 2022–2023 |  | Payments DueAfter 2023 |  | Total |
| Term debt | $ | 8,797 |  |  | $ | 18,933 |  |  | $ | 17,978 |  |  | $ | 58,485 |  |  | $ | 104,193 |  |
| Operating leases | 1,298 |  |  | 2,507 |  |  | 1,838 |  |  | 3,984 |  |  | 9,627 |  |
| Manufacturing purchase obligations (1) | 41,548 |  |  | 2,469 |  |  | 1,183 |  |  | — |  |  | 45,200 |  |
| Other purchase obligations | 3,784 |  |  | 2,482 |  |  | 681 |  |  | 66 |  |  | 7,013 |  |
| Deemed repatriation tax payable | — |  |  | 5,366 |  |  | 5,942 |  |  | 22,281 |  |  | 33,589 |  |
| Total | $ | 55,427 |  |  | $ | 31,757 |  |  | $ | 27,622 |  |  | $ | 84,816 |  |  | $ | 199,622 |  |

[0000320193-18-000145:mdna:130]
| (1) | Represents amount expected to be paid under manufacturing-related supplier arrangements, substantially all of which is noncancelable. |

[0000320193-18-000145:mdna:131]
Operating Leases

[0000320193-18-000145:mdna:132]
The Company’s retail store and other facility leases typically have original terms not exceeding 10 years and generally contain multi-year renewal options.

[0000320193-18-000145:mdna:133]
Manufacturing Purchase Obligations

[0000320193-18-000145:mdna:134]
The Company utilizes several outsourcing partners to manufacture sub-assemblies for the Company’s products and to perform final assembly and testing of finished products. These outsourcing partners acquire components and build product based on demand information supplied by the Company, which typically covers periods up to 150 days. The Company also obtains individual components for its products from a wide variety of individual suppliers.

[0000320193-18-000145:mdna:135]
Other Purchase Obligations

[0000320193-18-000145:mdna:136]
The Company’s other purchase obligations consist of noncancelable obligations to acquire capital assets, including product tooling and manufacturing process equipment, and noncancelable obligations related to advertising, licensing, R&D, internet and telecommunications services, content creation and other activities.

[0000320193-18-000145:mdna:137]
Deemed Repatriation Tax Payable

[0000320193-18-000145:mdna:138]
As of September 29, 2018, a significant portion of the other non-current liabilities in the Company’s Consolidated Balance Sheet consisted of the deemed repatriation tax payable imposed by the Act. The Company plans to pay the deemed repatriation tax payable in installments in accordance with the Act.

[0000320193-18-000145:mdna:139]
Other Non-Current Liabilities

[0000320193-18-000145:mdna:140]
The Company’s remaining other non-current liabilities primarily consist of items for which the Company is unable to make a reasonably reliable estimate of the timing of payments; therefore, such amounts are not included in the above contractual obligation table.

[0000320193-18-000145:mdna:141]
Indemnification

[0000320193-18-000145:mdna:142]
Agreements entered into by the Company may include indemnification provisions which may subject the Company to costs and damages in the event of a claim against an indemnified third party. Except as disclosed in Part II, Item 8 of this Form 10-K in the Notes to Consolidated Financial Statements in Note 9, “Commitments and Contingencies” under the heading “Contingencies,” in the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to indemnification of third parties.

[0000320193-18-000145:mdna:143]
The Company offers an iPhone Upgrade Program, which is available to customers who purchase a qualifying iPhone in the U.S., the U.K. and mainland China. The iPhone Upgrade Program provides customers the right to trade in that iPhone for a specified amount when purchasing a new iPhone, provided certain conditions are met. The Company accounts for the trade-in right as a guarantee liability and recognizes arrangement revenue net of the fair value of such right, with subsequent changes to the guarantee liability recognized within revenue.

[0000320193-18-000145:mdna:144]
The Company has entered into indemnification agreements with its directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers of the Company, and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. While the Company maintains directors and officers liability insurance coverage, such insurance coverage may be insufficient to cover all losses or all types of claims that may arise.

[0000320193-18-000145:mdna:145]
Critical Accounting Policies and Estimates

[0000320193-18-000145:mdna:146]
The preparation of financial statements and related disclosures in conformity with U.S. generally accepted accounting principles (“GAAP”) and the Company’s discussion and analysis of its financial condition and operating results require the Company’s management to make judgments, assumptions and estimates that affect the amounts reported in its consolidated financial statements and accompanying notes. Note 1, “Summary of Significant Accounting Policies,” of the Notes to Consolidated Financial Statements in Part II, Item 8 of this Form 10-K describes the significant accounting policies and methods used in the preparation of the Company’s consolidated financial statements. Management bases its estimates on historical experience and on various other assumptions it believes to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities. Actual results may differ from these estimates, and such differences may be material.

[0000320193-18-000145:mdna:147]
Management believes the Company’s critical accounting policies and estimates are those related to revenue recognition, valuation and impairment of marketable securities, inventory valuation, valuation of manufacturing-related assets and estimation of purchase commitment cancellation fees, warranty costs, income taxes, and legal and other contingencies. Management considers these policies critical because they are both important to the portrayal of the Company’s financial condition and operating results, and they require management to make judgments and estimates about inherently uncertain matters. The Company’s senior management has reviewed these critical accounting policies and related disclosures with the Audit and Finance Committee of the Company’s Board of Directors.

[0000320193-18-000145:mdna:148]
Revenue Recognition

[0000320193-18-000145:mdna:149]
Net sales consist primarily of revenue from the sale of hardware, software, digital content and applications, accessories, and service and support contracts. The Company recognizes revenue when persuasive evidence of an arrangement exists, delivery has occurred, the sales price is fixed or determinable and collection is probable. Product is considered delivered to the customer once it has been shipped and title, risk of loss and rewards of ownership have been transferred. For most of the Company’s product sales, these criteria are met at the time the product is shipped. For online sales to individuals, for some sales to education customers in the U.S., and for certain other sales, the Company defers revenue until the customer receives the product because the Company retains a portion of the risk of loss on these sales during transit. For payment terms in excess of the Company’s standard payment terms, revenue is recognized as payments become due unless the Company has positive evidence that the sales price is fixed or determinable, such as a successful history of collection, without concession, on comparable arrangements. The Company recognizes revenue from the sale of hardware products, software bundled with hardware that is essential to the functionality of the hardware and third-party digital content sold on the iTunes Store in accordance with general revenue recognition accounting guidance. The Company recognizes revenue in accordance with industry-specific software accounting guidance for the following types of sales transactions: (i) standalone sales of software products, (ii) sales of software upgrades and (iii) sales of software bundled with hardware not essential to the functionality of the hardware.

[0000320193-18-000145:mdna:150]
For multi-element arrangements that include hardware products containing software essential to the hardware product’s functionality, undelivered software elements that relate to the hardware product’s essential software and/or undelivered non-software services, the Company allocates revenue to all deliverables based on their relative selling prices. In such circumstances, the Company uses a hierarchy to determine the selling price to be used for allocating revenue to deliverables: (i) vendor-specific objective evidence of fair value (“VSOE”), (ii) third-party evidence of selling price (“TPE”) and (iii) best estimate of selling price (“ESP”). VSOE generally exists only when the Company sells the deliverable separately and is the price actually charged by the Company for that deliverable. ESPs reflect the Company’s best estimates of what the selling prices of elements would be if they were sold regularly on a stand-alone basis.

[0000320193-18-000145:mdna:151]
For sales of iPhone, iPad, Mac and certain other products, the Company has indicated it may from time to time provide future unspecified software upgrades to the device’s essential software and/or non-software services free of charge. Because the Company has neither VSOE nor TPE for the unspecified software upgrade rights or the non-software services, revenue is allocated to these rights and services based on the Company’s ESPs. Revenue allocated to the unspecified software upgrade rights and non-software services based on the Company’s ESPs is deferred and recognized on a straight-line basis over the estimated period the software upgrades and non-software services are expected to be provided.

[0000320193-18-000145:mdna:152]
The Company’s process for determining ESPs involves management’s judgment and considers multiple factors that may vary over time depending upon the unique facts and circumstances related to each deliverable. Should future facts and circumstances change, the Company’s ESPs and the future rate of related amortization for unspecified software upgrades and non-software services related to future sales of these devices could change. Factors subject to change include the unspecified software upgrade rights and non-software services offered, the estimated value of unspecified software upgrade rights and non-software services and the estimated period unspecified software upgrades and non-software services are expected to be provided.

[0000320193-18-000145:mdna:153]
The Company records reductions to revenue for estimated commitments related to price protection and other customer incentive programs. For transactions involving price protection, the Company recognizes revenue net of the estimated amount to be refunded, provided the refund amount can be reasonably and reliably estimated and the other conditions for revenue recognition have been met. The Company’s policy requires that, if refunds cannot be reliably estimated, revenue is not recognized until reliable estimates can be made or the price protection lapses. For the Company’s other customer incentive programs, the estimated cost is recognized at the later of the date at which the Company has sold the product or the date at which the program is offered. The Company also records reductions to revenue for expected future product returns based on the Company’s historical experience. Future market conditions and product transitions may require the Company to increase customer incentive programs that could result in reductions to future revenue. Additionally, certain customer incentive programs require management to estimate the number of customers who will actually redeem the incentive. Management’s estimates are based on historical experience and the specific terms and conditions of particular incentive programs. If a greater than estimated proportion of customers redeems such incentives, the Company would be required to record additional reductions to revenue, which would have an adverse impact on the Company’s operating results.

[0000320193-18-000145:mdna:154]
Valuation and Impairment of Marketable Securities

[0000320193-18-000145:mdna:155]
The Company’s investments in available-for-sale securities are reported at fair value. Unrealized gains and losses related to changes in the fair value of securities are generally recognized in accumulated other comprehensive income, net of tax, in the Company’s Consolidated Balance Sheets. Changes in the fair value of available-for-sale securities impact the Company’s net income only when such securities are sold or an other-than-temporary impairment is recognized. Realized gains and losses on the sale of securities are determined by specific identification of each security’s cost basis. The Company regularly reviews its investment portfolio to determine if any security is other-than-temporarily impaired, which would require the Company to record an impairment charge in the period any such determination is made. In making this determination, the Company evaluates, among other things, the duration and extent to which the fair value of a security is less than its cost; the financial condition of the issuer and any changes thereto; and the Company’s intent to sell, or whether it will more likely than not be required to sell, the security before recovery of its amortized cost basis. The Company’s assessment of whether a security is other-than-temporarily impaired could change in the future due to new developments or changes in assumptions related to any particular security, which would have an adverse impact on the Company’s financial condition and operating results.

[0000320193-18-000145:mdna:156]
Inventory Valuation, Valuation of Manufacturing-Related Assets and Estimation of Purchase Commitment Cancellation Fees

[0000320193-18-000145:mdna:157]
The Company purchases components and builds inventory in advance of product shipments and invests in manufacturing-related assets, including capital assets held at its suppliers’ facilities. In addition, the Company makes prepayments to certain of its suppliers associated with long-term supply agreements to secure supply of inventory. The Company performs a regular review of inventory that considers multiple factors including demand forecasts, product life cycle status, product development plans, current sales levels and component cost trends. If the Company determines inventories of components and products, including third-party products held for resale, have become obsolete or are in excess of anticipated demand or net realizable value, it records a write-down of the inventories. The Company also reviews its manufacturing-related capital assets and inventory prepayments for impairment whenever events or circumstances indicate the carrying amount of such assets may not be recoverable. If the Company determines that an asset is not recoverable, it records an impairment loss equal to the amount by which the carrying value of such an asset exceeds its fair value. Any write-downs and/or impairments the Company may be required to record would adversely affect the Company’s financial condition and operating results.

[0000320193-18-000145:mdna:158]
The Company accrues for estimated purchase commitment cancellation fees related to inventory orders that have been canceled or are expected to be canceled. Manufacturing purchase obligations cover the Company’s forecasted component and manufacturing requirements, typically for periods up to 150 days. If there is an abrupt and substantial decline in demand for one or more of the Company’s products, a change in the Company’s product development plans, or an unanticipated change in technological requirements for any of the Company’s products, the Company may be required to record accruals for cancellation fees that would adversely affect its operating results.

[0000320193-18-000145:mdna:159]
Warranty Costs

[0000320193-18-000145:mdna:160]
The Company accrues the estimated cost of warranties in the period the related revenue is recognized based on historical and projected warranty claim rates, historical and projected cost per claim and knowledge of specific product failures outside of the Company’s typical experience. The Company regularly reviews these estimates and adjusts the amounts as necessary. If actual product failure rates or repair costs differ from estimates, revisions to the estimated warranty liabilities would be required and could materially affect the Company’s financial condition and operating results.

[0000320193-18-000145:mdna:161]
Income Taxes

[0000320193-18-000145:mdna:162]
The Company records a tax provision for the anticipated tax consequences of its reported operating results. The provision for income taxes is computed using the asset and liability method, under which deferred tax assets and liabilities are recognized for the expected future tax consequences of temporary differences between the financial reporting and tax bases of assets and liabilities, and for operating losses and tax credit carryforwards. Deferred tax assets and liabilities are measured using the currently enacted tax rates that will be in effect for the years in which those tax assets and liabilities are expected to be realized or settled. The Company records a valuation allowance to reduce deferred tax assets to the amount that is believed more likely than not to be realized.

[0000320193-18-000145:mdna:163]
The Company recognizes tax benefits from uncertain tax positions only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement.

[0000320193-18-000145:mdna:164]
Management believes it is more likely than not that forecasted income, including income that may be generated as a result of certain tax planning strategies, together with future reversals of existing taxable temporary differences, will be sufficient to recover the Company’s deferred tax assets. In the event that the Company determines all or part of its net deferred tax assets are not realizable in the future, the Company will record an adjustment to the valuation allowance and a corresponding charge to earnings in the period such determination is made. In addition, the calculation of tax liabilities involves significant judgment in estimating the impact of uncertainties in the application of GAAP and complex tax laws. Resolution of these uncertainties in a manner inconsistent with management’s expectations could have a material impact on the Company’s financial condition and operating results.

[0000320193-18-000145:mdna:165]
On December 22, 2017, the U.S. enacted the Act, which significantly changed U.S. tax law. The Act lowered the Company’s U.S. statutory federal income tax rate from 35% to 21% effective January 1, 2018, while also imposing a deemed repatriation tax on previously deferred foreign income. The Act also created a new minimum tax on certain future foreign earnings. The impact of the Act increased the Company’s provision for income taxes by $1.5 billion during 2018. This increase was composed of $2.0 billion related to the remeasurement of net deferred tax assets and liabilities and $1.2 billion associated with the deemed repatriation tax, partially offset by a $1.7 billion impact the deemed repatriation tax had on the Company’s unrecognized tax benefits. Certain amounts reported by the Company related to the Act are provisional estimates in accordance with the SEC Staff Accounting Bulletin No. 118. Resolution of the Act’s effects different from the assumptions made by the Company could have a material impact on the Company’s financial condition and operating results.

[0000320193-18-000145:mdna:166]
Legal and Other Contingencies

[0000320193-18-000145:mdna:167]
As discussed in Part I, Item 3 of this Form 10-K under the heading “Legal Proceedings” and in Part II, Item 8 of this Form 10-K in the Notes to Consolidated Financial Statements in Note 9, “Commitments and Contingencies,” the Company is subject to various legal proceedings and claims that arise in the ordinary course of business. The Company records a liability when it is probable that a loss has been incurred and the amount is reasonably estimable, the determination of which requires significant judgment. Except as described in Part II, Item 8 of this Form 10-K in the Notes to Consolidated Financial Statements in Note 9, “Commitments and Contingencies” under the heading “Contingencies,” in the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to loss contingencies for asserted legal and other claims.

[0000320193-18-000145:mdna:168]
The outcome of litigation is inherently uncertain. If one or more legal matters were resolved against the Company in a reporting period for amounts in excess of management’s expectations, the Company’s financial condition and operating results for that reporting period could be materially adversely affected.
