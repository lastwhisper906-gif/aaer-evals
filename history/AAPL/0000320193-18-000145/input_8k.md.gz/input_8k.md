# AAPL 8-K — 0000320193-18-000142 filed 2018-11-01

## item codes, every 8-K on or before 2018-11-05

- 2018-11-01 0000320193-18-000142 — 2.02, 9.01
- 2018-07-31 0000320193-18-000098 — 2.02, 9.01
- 2018-05-08 0001193125-18-154948 — 8.01 — amendment of 0001193125-18-154515
- 2018-05-07 0001193125-18-154515 — 8.01, 9.01
- 2018-05-01 0000320193-18-000067 — 2.02, 9.01
- 2018-02-14 0001193125-18-045761 — 5.07, 9.01
- 2018-02-01 0000320193-18-000005 — 2.02, 9.01
- 2017-11-13 0001193125-17-341015 — 8.01, 9.01
- 2017-11-02 0000320193-17-000067 — 2.02, 9.01
- 2017-10-12 0001193125-17-308859 — 5.02
- 2017-09-12 0001193125-17-282809 — 8.01, 9.01
- 2017-08-18 0001193125-17-262261 — 8.01, 9.01
- 2017-08-01 0000320193-17-000006 — 2.02, 9.01
- 2017-06-20 0001193125-17-208226 — 8.01, 9.01
- 2017-05-24 0001193125-17-181867 — 8.01, 9.01
- 2017-05-11 0001193125-17-167400 — 8.01, 9.01
- 2017-05-02 0001628280-17-004663 — 2.02, 9.01
- 2017-03-03 0001193125-17-069853 — 8.01, 9.01
- 2017-03-01 0001193125-17-064019 — 5.07
- 2017-02-09 0001193125-17-036283 — 8.01, 9.01
- 2017-01-31 0001628280-17-000663 — 2.02, 9.01
- 2016-12-15 0001628280-16-022047 — 5.03, 9.01
- 2016-10-25 0001628280-16-020258 — 2.02, 9.01
- 2016-08-04 0001193125-16-672044 — 8.01, 9.01
- 2016-07-26 0001628280-16-017762 — 2.02, 9.01
- 2016-06-22 0001193125-16-628957 — 8.01, 9.01
- 2016-04-26 0001193125-16-556520 — 2.02, 9.01
- 2016-03-24 0001193125-16-516891 — 8.01, 9.01
- 2016-03-01 0001193125-16-488223 — 5.02, 5.07, 9.01
- 2016-02-23 0001193125-16-473562 — 8.01, 9.01
- 2016-01-26 0001193125-16-438421 — 2.02, 9.01
- 2015-12-22 0001193125-15-410853 — 5.03, 9.01
- 2015-12-17 0001193125-15-406279 — 5.02
- 2015-10-27 0001193125-15-354756 — 2.02, 9.01
- 2015-10-02 0001193125-15-336615 — 5.02
- 2015-09-17 0001193125-15-322466 — 8.01, 9.01
- 2015-07-31 0001193125-15-273023 — 8.01, 9.01
- 2015-07-21 0001193125-15-258464 — 2.02, 9.01
- 2015-06-10 0001193125-15-219298 — 8.01, 9.01
- 2015-05-13 0001193125-15-186064 — 8.01, 9.01
- 2015-04-27 0001193125-15-149607 — 7.01, 9.01
- 2015-04-27 0001193125-15-149590 — 2.02, 9.01
- 2015-03-13 0001104659-15-019336 — 5.07, 9.01
- 2015-02-09 0001193125-15-039270 — 8.01, 9.01
- 2015-01-28 0001193125-15-023732 — 8.01, 9.01
- 2015-01-27 0001193125-15-021857 — 2.02, 9.01
- 2014-11-10 0001193125-14-406296 — 8.01, 9.01
- 2014-10-20 0001193125-14-376361 — 2.02, 9.01
- 2014-07-23 0001193125-14-277193 — 8.01, 9.01
- 2014-07-22 0001193125-14-275598 — 2.02, 9.01
- 2014-07-17 0001193125-14-271698 — 5.02
- 2014-06-06 0001193125-14-228798 — 5.03, 9.01
- 2014-05-30 0001181431-14-021923 — 5.02
- 2014-05-06 0001193125-14-184969 — 8.01, 9.01
- 2014-04-23 0001193125-14-154883 — 7.01, 9.01
- 2014-04-23 0001193125-14-154871 — 2.02, 9.01
- 2014-03-05 0001193125-14-084697 — 5.02, 5.03, 5.07, 9.01
- 2014-01-27 0001193125-14-022238 — 2.02, 9.01
- 2013-10-28 0001193125-13-413498 — 2.02, 9.01
- 2013-09-23 0001181431-13-050140 — 8.01
- 2013-07-30 0001181431-13-041847 — 5.02
- 2013-07-23 0001193125-13-298914 — 2.02, 9.01
- 2013-06-21 0001193125-13-267629 — 5.02
- 2013-05-03 0001193125-13-199324 — 8.01, 9.01
- 2013-04-24 0001193125-13-170623 — 8.01, 9.01
- 2013-04-23 0001193125-13-167469 — 7.01, 9.01
- 2013-04-23 0001193125-13-167458 — 2.02, 9.01
- 2013-03-01 0001193125-13-085842 — 5.07
- 2013-01-23 0001193125-13-020783 — 2.02, 9.01
- 2012-10-25 0001193125-12-435506 — 2.02, 9.01
- 2012-07-24 0001193125-12-312355 — 2.02, 9.01
- 2012-06-28 0001181431-12-038301 — 5.02
- 2012-05-24 0001181431-12-032458 — 5.02
- 2012-04-24 0001193125-12-178928 — 2.02, 9.01
- 2012-02-27 0001193125-12-081892 — 5.07
- 2012-01-24 0001193125-12-021833 — 2.02, 9.01
- 2011-11-16 0001181431-11-056354 — 5.02
- 2011-10-18 0001193125-11-273826 — 2.02, 9.01
- 2011-10-06 0001181431-11-051976 — 8.01
- 2011-08-26 0001181431-11-047179 — 5.02
- 2011-07-19 0001193125-11-191368 — 2.02, 9.01
- 2011-06-15 0001181431-11-036782 — 5.02
- 2011-04-20 0001193125-11-103732 — 2.02, 9.01
- 2011-02-24 0001193125-11-045411 — 5.07
- 2011-01-18 0001193125-11-009392 — 2.02, 9.01
- 2011-01-18 0001181431-11-003847 — 5.02
- 2010-11-17 0001181431-10-056327 — 5.02, 5.03, 9.01
- 2010-10-18 0001193125-10-230992 — 2.02, 9.01
- 2010-07-20 0001193125-10-161807 — 2.02, 9.01
- 2010-04-20 0001193125-10-087786 — 2.02, 9.01
- 2010-03-12 0001181431-10-016054 — 5.02
- 2010-03-01 0001193125-10-044765 — 5.02, 5.07, 9.01
- 2010-01-25 0001193125-10-012096 — 2.02, 9.01
- 2009-10-19 0001193125-09-209633 — 2.02, 9.01
- 2009-08-04 0001181431-09-037492 — 5.02
- 2009-07-21 0001193125-09-152290 — 2.02, 9.01
- 2009-06-02 0001181431-09-028400 — 5.03
- 2009-04-22 0001193125-09-084599 — 2.02, 9.01
- 2009-02-27 0001181431-09-012161 — 4.01
- 2009-01-21 0001193125-09-009009 — 2.02, 9.01
- 2009-01-16 0001181431-09-003017 — 5.02
- 2008-10-21 0001193125-08-213642 — 2.02, 9.01
- 2008-08-26 0001181431-08-050059 — 5.03
- 2008-07-21 0001193125-08-154381 — 2.02, 9.01
- 2008-06-09 0001181431-08-037620 — 8.01
- 2008-04-23 0001193125-08-088001 — 2.02, 9.01
- 2008-01-22 0001193125-08-009715 — 2.02, 9.01
- 2008-01-15 0001181431-08-003342 — 2.02, 8.01
- 2008-01-08 0001181431-08-002372 — 5.02
- 2007-10-22 0001104659-07-076142 — 2.02, 9.01
- 2007-07-25 0001104659-07-056111 — 2.02, 9.01
- 2007-05-16 0001104659-07-040672 — 5.02, 9.01
- 2007-04-25 0001104659-07-031354 — 2.02, 9.01
- 2007-04-24 0001104659-07-030938 — 8.01, 9.01
- 2007-02-21 0001104659-07-012760 — 5.03, 9.01
- 2007-01-17 0001104659-07-002905 — 2.02, 9.01
- 2007-01-10 0001104659-07-001648 — 5.03, 9.01
- 2006-10-27 0001104659-06-069015 — 8.01
- 2006-10-18 0001104659-06-067275 — 2.02, 9.01
- 2006-10-04 0001104659-06-064935 — 5.02, 8.01, 9.01
- 2006-09-01 0001104659-06-058808 — 1.01, 5.02, 5.03, 9.01
- 2006-08-11 0001104659-06-054118 — 2.02, 3.01, 9.01
- 2006-08-04 0001104659-06-051302 — 2.02, 4.02, 9.01
- 2006-07-19 0001104659-06-047739 — 2.02, 9.01
- 2006-04-21 0001181431-06-024759 — 1.01
- 2006-04-19 0001104659-06-025992 — 2.02, 9.01
- 2006-01-18 0001104659-06-002690 — 2.02, 9.01
- 2006-01-10 0001104659-06-001428 — 2.02
- 2005-12-19 0001181431-05-067468 — 1.01
- 2005-10-14 0001181431-05-056604 — 5.02
- 2005-10-11 0001104659-05-048094 — 2.02, 9.01
- 2005-08-26 0001181431-05-049163 — 1.01
- 2005-08-15 0001181431-05-046871 — 1.01
- 2005-07-13 0001104659-05-032297 — 2.02, 9.01
- 2005-06-06 0001181431-05-033177 — 8.01
- 2005-04-26 0001181431-05-023450 — 1.01
- 2005-04-13 0001104659-05-016307 — 2.02, 9.01
- 2005-03-02 0001181431-05-013840 — 3.03, 5.03
- 2005-02-11 0001104659-05-005507 — 8.01
- 2005-01-12 0001104659-05-001183 — 2.02, 9.01
- 2005-01-11 0001104659-05-001049 — 2.02
- 2004-10-13 0001104659-04-030400 — 2.02, 9.01
- 2004-07-14 0001104659-04-019574 — 12, 7
- 2004-04-14 0001104659-04-010122 — 12, 7
- 2004-01-14 0001104659-04-000896 — 12, 7
- 2003-10-15 0001104659-03-022879 — 12, 7
- 2003-07-16 0001104659-03-014913 — 7, 9
- 2003-04-16 0001047469-03-013617 — 7, 9
- 2003-03-21 0001104659-03-004649 — 5, 7
- 2002-08-13 0000912057-02-031595 — 5, 7
- 2002-08-05 0000912057-02-029692 — 5, 7
- 2000-01-24 0000912057-00-002128 — 5, 7
- 1999-09-07 0000320193-99-000010 — 2
- 1999-07-16 0000320193-99-000007 — 2
- 1998-12-23 0000320193-98-000010 — 1
- 1998-01-08 0000320193-98-000001 — 2
- 1997-09-25 0000320193-97-000019 — 2
- 1997-09-25 0000320193-97-000018 — 2
- 1997-09-05 0000320193-97-000016 — 2
- 1997-07-28 0000320193-97-000012 — 4
- 1997-04-25 0000320193-97-000009 — 5
- 1997-04-10 0000320193-97-000007 — 7
- 1996-12-24 0000320193-96-000027 — 7
- 1996-12-23 0000320193-96-000025 — 4 — amendment of 0000320193-96-000021
- 1996-12-13 0000320193-96-000021 — 4
- 1996-10-28 0000912057-96-023874 — 5, 7
- 1996-06-17 0000320193-96-000014 — 1
- 1996-04-12 0000320193-96-000006 — 1

## late-filing notifications on or before 2018-11-05

- 2006-12-15 0001104659-06-081617 — NT 10-K, for the period ended 2006-09-30
- 2006-08-11 0001104659-06-053743 — NT 10-Q, for the period ended 2006-07-01

## item 2.02 — earnings release, exhibit 99.1

[0000320193-18-000142:8k_2_02:1]
EX-99.1
2
a8-kexhibit991q420189292018.htm
EXHIBIT 99.1

[0000320193-18-000142:8k_2_02:2]
Exhibit

[0000320193-18-000142:8k_2_02:3]
Exhibit 99.1

[0000320193-18-000142:8k_2_02:4]
Apple Reports Fourth Quarter Results

[0000320193-18-000142:8k_2_02:5]
Revenue Up 20 Percent and EPS Up 41 Percent to New September Quarter Records

[0000320193-18-000142:8k_2_02:6]
Services Revenue of $10 Billion Reaches New All-Time High

[0000320193-18-000142:8k_2_02:7]
CUPERTINO, California — November 1, 2018 — Apple® today announced financial results for its fiscal 2018 fourth quarter ended September 29, 2018. The Company posted quarterly revenue of $62.9 billion, an increase of 20 percent from the year-ago quarter, and quarterly earnings per diluted share of $2.91, up 41 percent. International sales accounted for 61 percent of the quarter’s revenue.

[0000320193-18-000142:8k_2_02:8]
Services revenue reached an all-time high of $10 billion. Excluding a one-time favorable adjustment of $640 million recognized in the fourth quarter of fiscal 2017, Services revenue grew from $7.9 billion in the fourth quarter of fiscal 2017 to $10 billion in the fourth quarter of fiscal 2018, an increase of 27 percent.

[0000320193-18-000142:8k_2_02:9]
“We’re thrilled to report another record-breaking quarter that caps a tremendous fiscal 2018, the year in which we shipped our 2 billionth iOS device, celebrated the 10th anniversary of the App Store and achieved the strongest revenue and earnings in Apple’s history,” said Tim Cook, Apple’s CEO. “Over the past two months, we’ve delivered huge advancements for our customers through new versions of iPhone, Apple Watch, iPad and Mac as well as our four operating systems, and we enter the holiday season with our strongest lineup of products and services ever.”

[0000320193-18-000142:8k_2_02:10]
“We concluded a record year with our best September quarter ever, growing double digits in every geographic segment. We set September quarter revenue records for iPhone and Wearables and all-time quarterly records for Services and Mac,” said Luca Maestri, Apple’s CFO. “We generated $19.5 billion in operating cash flow and returned over $23 billion to shareholders in dividends and share repurchases in the September quarter, bringing total capital returned in fiscal 2018 to almost $90 billion.”

[0000320193-18-000142:8k_2_02:11]
Apple is providing the following guidance for its fiscal 2019 first quarter:

[0000320193-18-000142:8k_2_02:12]
| • | revenue between $89 billion and $93 billion |

[0000320193-18-000142:8k_2_02:13]
| • | gross margin between 38 percent and 38.5 percent |

[0000320193-18-000142:8k_2_02:14]
| • | operating expenses between $8.7 billion and $8.8 billion |

[0000320193-18-000142:8k_2_02:15]
| • | other income/(expense) of $300 million |

[0000320193-18-000142:8k_2_02:16]
| • | tax rate of approximately 16.5 percent before discrete items |

[0000320193-18-000142:8k_2_02:17]
Apple’s board of directors has declared a cash dividend of $0.73 per share of the Company’s common stock. The dividend is payable on November 15, 2018 to shareholders of record as of the close of business on November 12, 2018.

[0000320193-18-000142:8k_2_02:18]
Apple will provide live streaming of its Q4 2018 financial results conference call beginning at 2:00 p.m. PDT on November 1, 2018 at www.apple.com/investor/earnings-call/. This webcast will also be available for replay for approximately two weeks thereafter.

[0000320193-18-000142:8k_2_02:19]
Apple periodically provides information for investors on its corporate website, apple.com, and its investors relations website, investor.apple.com. This includes press releases and other information about financial performance, reports filed or furnished with the SEC, information on corporate governance and details related to its annual meeting of shareholders.

[0000320193-18-000142:8k_2_02:20]
Apple revolutionized personal technology with the introduction of the Macintosh in 1984. Today, Apple leads the world in innovation with iPhone, iPad, Mac, Apple Watch and Apple TV. Apple’s four software platforms — iOS, macOS, watchOS and tvOS — provide seamless experiences across all Apple devices and empower people with breakthrough services including the App Store, Apple Music, Apple Pay and iCloud. Apple’s more than 100,000 employees are dedicated to making the best products on earth, and to leaving the world better than we found it.

[0000320193-18-000142:8k_2_02:21]
Press Contact:

[0000320193-18-000142:8k_2_02:22]
Kristin Huguet

[0000320193-18-000142:8k_2_02:23]
Apple

[0000320193-18-000142:8k_2_02:24]
khuguet@apple.com

[0000320193-18-000142:8k_2_02:25]
(408) 974-2414

[0000320193-18-000142:8k_2_02:26]
Investor Relations Contacts:

[0000320193-18-000142:8k_2_02:27]
Nancy Paxton

[0000320193-18-000142:8k_2_02:28]
Apple

[0000320193-18-000142:8k_2_02:29]
paxton1@apple.com

[0000320193-18-000142:8k_2_02:30]
(408) 974-5420

[0000320193-18-000142:8k_2_02:31]
Matt Blake

[0000320193-18-000142:8k_2_02:32]
Apple

[0000320193-18-000142:8k_2_02:33]
mattblake@apple.com

[0000320193-18-000142:8k_2_02:34]
(408) 974-7406

[0000320193-18-000142:8k_2_02:35]
NOTE TO EDITORS: For additional information visit Apple Newsroom (www.apple.com/newsroom), or call Apple’s Media Helpline at (408) 974-2042.

[0000320193-18-000142:8k_2_02:36]
© 2018 Apple Inc. All rights reserved. Apple and the Apple logo are trademarks of Apple Inc. Other company and product names may be trademarks of their respective owners.

[0000320193-18-000142:8k_2_02:37]
Apple Inc.

[0000320193-18-000142:8k_2_02:38]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS (Unaudited)

[0000320193-18-000142:8k_2_02:39]
(In millions, except number of shares which are reflected in thousands and per share amounts)

[0000320193-18-000142:8k_2_02:40]
|  | Three Months Ended |  | Twelve Months Ended |
|  | September 29, 2018 |  | September 30, 2017 |  | September 29, 2018 |  | September 30, 2017 |
| Net sales | $ | 62,900 |  |  | $ | 52,579 |  |  | $ | 265,595 |  |  | $ | 229,234 |  |
| Cost of sales (1) | 38,816 |  |  | 32,648 |  |  | 163,756 |  |  | 141,048 |  |
| Gross margin | 24,084 |  |  | 19,931 |  |  | 101,839 |  |  | 88,186 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development (1) | 3,750 |  |  | 2,997 |  |  | 14,236 |  |  | 11,581 |  |
| Selling, general and administrative (1) | 4,216 |  |  | 3,814 |  |  | 16,705 |  |  | 15,261 |  |
| Total operating expenses | 7,966 |  |  | 6,811 |  |  | 30,941 |  |  | 26,842 |  |
| Operating income | 16,118 |  |  | 13,120 |  |  | 70,898 |  |  | 61,344 |  |
| Other income/(expense), net | 303 |  |  | 797 |  |  | 2,005 |  |  | 2,745 |  |
| Income before provision for income taxes | 16,421 |  |  | 13,917 |  |  | 72,903 |  |  | 64,089 |  |
| Provision for income taxes | 2,296 |  |  | 3,203 |  |  | 13,372 |  |  | 15,738 |  |
| Net income | $ | 14,125 |  |  | $ | 10,714 |  |  | $ | 59,531 |  |  | $ | 48,351 |  |
| Earnings per share: |  |  |  |  |  |  |  |
| Basic | $ | 2.94 |  |  | $ | 2.08 |  |  | $ | 12.01 |  |  | $ | 9.27 |  |
| Diluted | $ | 2.91 |  |  | $ | 2.07 |  |  | $ | 11.91 |  |  | $ | 9.21 |  |
| Shares used in computing earnings per share: |  |  |  |  |  |  |  |
| Basic | 4,801,589 |  |  | 5,149,428 |  |  | 4,955,377 |  |  | 5,217,242 |  |
| Diluted | 4,847,547 |  |  | 5,183,585 |  |  | 5,000,109 |  |  | 5,251,692 |  |
| Cash dividends declared per share | $ | 0.73 |  |  | $ | 0.63 |  |  | $ | 2.72 |  |  | $ | 2.40 |  |
| (1) Includes share-based compensation expense as follows: |
| Cost of sales | $ | 251 |  |  | $ | 215 |  |  | $ | 1,010 |  |  | $ | 877 |  |
| Research and development | $ | 681 |  |  | $ | 569 |  |  | $ | 2,668 |  |  | $ | 2,299 |  |
| Selling, general and administrative | $ | 413 |  |  | $ | 390 |  |  | $ | 1,662 |  |  | $ | 1,664 |  |

[0000320193-18-000142:8k_2_02:41]
Apple Inc.

[0000320193-18-000142:8k_2_02:42]
CONDENSED CONSOLIDATED BALANCE SHEETS (Unaudited)

[0000320193-18-000142:8k_2_02:43]
(In millions, except number of shares which are reflected in thousands and par value)

[0000320193-18-000142:8k_2_02:44]
|  | September 29, 2018 |  | September 30, 2017 |
| ASSETS: |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 25,913 |  |  | $ | 20,289 |  |
| Marketable securities | 40,388 |  |  | 53,892 |  |
| Accounts receivable, net | 23,186 |  |  | 17,874 |  |
| Inventories | 3,956 |  |  | 4,855 |  |
| Vendor non-trade receivables | 25,809 |  |  | 17,799 |  |
| Other current assets | 12,087 |  |  | 13,936 |  |
| Total current assets | 131,339 |  |  | 128,645 |  |
| Non-current assets: |  |  |  |
| Marketable securities | 170,799 |  |  | 194,714 |  |
| Property, plant and equipment, net | 41,304 |  |  | 33,783 |  |
| Other non-current assets | 22,283 |  |  | 18,177 |  |
| Total non-current assets | 234,386 |  |  | 246,674 |  |
| Total assets | $ | 365,725 |  |  | $ | 375,319 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY: |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 55,888 |  |  | $ | 44,242 |  |
| Other current liabilities | 32,687 |  |  | 30,551 |  |
| Deferred revenue | 7,543 |  |  | 7,548 |  |
| Commercial paper | 11,964 |  |  | 11,977 |  |
| Term debt | 8,784 |  |  | 6,496 |  |
| Total current liabilities | 116,866 |  |  | 100,814 |  |
| Non-current liabilities: |  |  |  |
| Deferred revenue | 2,797 |  |  | 2,836 |  |
| Term debt | 93,735 |  |  | 97,207 |  |
| Other non-current liabilities | 45,180 |  |  | 40,415 |  |
| Total non-current liabilities | 141,712 |  |  | 140,458 |  |
| Total liabilities | 258,578 |  |  | 241,272 |  |
| Commitments and contingencies |  |  |  |
| Shareholders’ equity: |  |  |  |
| Common stock and additional paid-in capital, $0.00001 par value: 12,600,000 shares authorized; 4,754,986 and 5,126,201 shares issued and outstanding, respectively | 40,201 |  |  | 35,867 |  |
| Retained earnings | 70,400 |  |  | 98,330 |  |
| Accumulated other comprehensive income/(loss) | (3,454 | ) |  | (150 | ) |
| Total shareholders’ equity | 107,147 |  |  | 134,047 |  |
| Total liabilities and shareholders’ equity | $ | 365,725 |  |  | $ | 375,319 |  |

[0000320193-18-000142:8k_2_02:45]
Apple Inc.

[0000320193-18-000142:8k_2_02:46]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (Unaudited)

[0000320193-18-000142:8k_2_02:47]
(In millions)

[0000320193-18-000142:8k_2_02:48]
|  | Twelve Months Ended |
|  | September 29, 2018 |  | September 30, 2017 |
| Cash and cash equivalents, beginning of the period | $ | 20,289 |  |  | $ | 20,484 |  |
| Operating activities: |  |  |  |
| Net income | 59,531 |  |  | 48,351 |  |
| Adjustments to reconcile net income to cash generated by operating activities: |  |  |  |
| Depreciation and amortization | 10,903 |  |  | 10,157 |  |
| Share-based compensation expense | 5,340 |  |  | 4,840 |  |
| Deferred income tax expense/(benefit) | (32,590 | ) |  | 5,966 |  |
| Other | (444 | ) |  | (166 | ) |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | (5,322 | ) |  | (2,093 | ) |
| Inventories | 828 |  |  | (2,723 | ) |
| Vendor non-trade receivables | (8,010 | ) |  | (4,254 | ) |
| Other current and non-current assets | (423 | ) |  | (5,318 | ) |
| Accounts payable | 9,175 |  |  | 8,966 |  |
| Deferred revenue | (44 | ) |  | (626 | ) |
| Other current and non-current liabilities | 38,490 |  |  | 1,125 |  |
| Cash generated by operating activities | 77,434 |  |  | 64,225 |  |
| Investing activities: |  |  |  |
| Purchases of marketable securities | (71,356 | ) |  | (159,486 | ) |
| Proceeds from maturities of marketable securities | 55,881 |  |  | 31,775 |  |
| Proceeds from sales of marketable securities | 47,838 |  |  | 94,564 |  |
| Payments for acquisition of property, plant and equipment | (13,313 | ) |  | (12,451 | ) |
| Payments made in connection with business acquisitions, net | (721 | ) |  | (329 | ) |
| Purchases of non-marketable securities | (1,871 | ) |  | (521 | ) |
| Proceeds from non-marketable securities | 353 |  |  | 126 |  |
| Other | (745 | ) |  | (124 | ) |
| Cash generated by/(used in) investing activities | 16,066 |  |  | (46,446 | ) |
| Financing activities: |  |  |  |
| Proceeds from issuance of common stock | 669 |  |  | 555 |  |
| Payments for taxes related to net share settlement of equity awards | (2,527 | ) |  | (1,874 | ) |
| Payments for dividends and dividend equivalents | (13,712 | ) |  | (12,769 | ) |
| Repurchases of common stock | (72,738 | ) |  | (32,900 | ) |
| Proceeds from issuance of term debt, net | 6,969 |  |  | 28,662 |  |
| Repayments of term debt | (6,500 | ) |  | (3,500 | ) |
| Change in commercial paper, net | (37 | ) |  | 3,852 |  |
| Cash used in financing activities | (87,876 | ) |  | (17,974 | ) |
| Increase/(Decrease) in cash and cash equivalents | 5,624 |  |  | (195 | ) |
| Cash and cash equivalents, end of the period | $ | 25,913 |  |  | $ | 20,289 |  |
| Supplemental cash flow disclosure: |  |  |  |
| Cash paid for income taxes, net | $ | 10,417 |  |  | $ | 11,591 |  |
| Cash paid for interest | $ | 3,022 |  |  | $ | 2,092 |  |
