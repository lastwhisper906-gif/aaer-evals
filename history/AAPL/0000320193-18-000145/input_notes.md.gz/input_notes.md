# AAPL notes — 0000320193-18-000145


## aapl:CashCashEquivalentsandAvailableforSaleSecuritiesTableTextBlock

[0000320193-18-000145:notes:1]
The following tables show the Company’s cash and available-for-sale securities by significant investment category as of September 29, 2018 and September 30, 2017 (in millions):

[0000320193-18-000145:notes:2]
|  | 2018 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | Short-TermMarketableSecurities |  | Long-TermMarketableSecurities |
| Cash | $ | 11,575 |  |  | $ | — |  |  | $ | — |  |  | $ | 11,575 |  |  | $ | 11,575 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 8,083 |  |  | — |  |  | — |  |  | 8,083 |  |  | 8,083 |  |  | — |  |  | — |  |
| Mutual funds | 799 |  |  | — |  |  | (116 | ) |  | 683 |  |  | — |  |  | 683 |  |  | — |  |
| Subtotal | 8,882 |  |  | — |  |  | (116 | ) |  | 8,766 |  |  | 8,083 |  |  | 683 |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 47,296 |  |  | — |  |  | (1,202 | ) |  | 46,094 |  |  | 1,613 |  |  | 7,606 |  |  | 36,875 |  |
| U.S. agency securities | 4,127 |  |  | — |  |  | (48 | ) |  | 4,079 |  |  | 1,732 |  |  | 360 |  |  | 1,987 |  |
| Non-U.S. government securities | 21,601 |  |  | 49 |  |  | (250 | ) |  | 21,400 |  |  | — |  |  | 3,355 |  |  | 18,045 |  |
| Certificates of deposit and time deposits | 3,074 |  |  | — |  |  | — |  |  | 3,074 |  |  | 1,247 |  |  | 1,330 |  |  | 497 |  |
| Commercial paper | 2,573 |  |  | — |  |  | — |  |  | 2,573 |  |  | 1,663 |  |  | 910 |  |  | — |  |
| Corporate securities | 123,001 |  |  | 152 |  |  | (2,038 | ) |  | 121,115 |  |  | — |  |  | 25,162 |  |  | 95,953 |  |
| Municipal securities | 946 |  |  | — |  |  | (12 | ) |  | 934 |  |  | — |  |  | 178 |  |  | 756 |  |
| Mortgage- and asset-backed securities | 18,105 |  |  | 8 |  |  | (623 | ) |  | 17,490 |  |  | — |  |  | 804 |  |  | 16,686 |  |
| Subtotal | 220,723 |  |  | 209 |  |  | (4,173 | ) |  | 216,759 |  |  | 6,255 |  |  | 39,705 |  |  | 170,799 |  |
| Total (3) | $ | 241,180 |  |  | $ | 209 |  |  | $ | (4,289 | ) |  | $ | 237,100 |  |  | $ | 25,913 |  |  | $ | 40,388 |  |  | $ | 170,799 |  |

[0000320193-18-000145:notes:3]
|  | 2017 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | Short-TermMarketableSecurities |  | Long-TermMarketableSecurities |
| Cash | $ | 7,982 |  |  | $ | — |  |  | $ | — |  |  | $ | 7,982 |  |  | $ | 7,982 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 6,534 |  |  | — |  |  | — |  |  | 6,534 |  |  | 6,534 |  |  | — |  |  | — |  |
| Mutual funds | 799 |  |  | — |  |  | (88 | ) |  | 711 |  |  | — |  |  | 711 |  |  | — |  |
| Subtotal | 7,333 |  |  | — |  |  | (88 | ) |  | 7,245 |  |  | 6,534 |  |  | 711 |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 55,254 |  |  | 58 |  |  | (230 | ) |  | 55,082 |  |  | 865 |  |  | 17,228 |  |  | 36,989 |  |
| U.S. agency securities | 5,162 |  |  | 2 |  |  | (9 | ) |  | 5,155 |  |  | 1,439 |  |  | 2,057 |  |  | 1,659 |  |
| Non-U.S. government securities | 7,827 |  |  | 210 |  |  | (37 | ) |  | 8,000 |  |  | 9 |  |  | 123 |  |  | 7,868 |  |
| Certificates of deposit and time deposits | 5,832 |  |  | — |  |  | — |  |  | 5,832 |  |  | 1,142 |  |  | 3,918 |  |  | 772 |  |
| Commercial paper | 3,640 |  |  | — |  |  | — |  |  | 3,640 |  |  | 2,146 |  |  | 1,494 |  |  | — |  |
| Corporate securities | 152,724 |  |  | 969 |  |  | (242 | ) |  | 153,451 |  |  | 172 |  |  | 27,591 |  |  | 125,688 |  |
| Municipal securities | 961 |  |  | 4 |  |  | (1 | ) |  | 964 |  |  | — |  |  | 114 |  |  | 850 |  |
| Mortgage- and asset-backed securities | 21,684 |  |  | 35 |  |  | (175 | ) |  | 21,544 |  |  | — |  |  | 656 |  |  | 20,888 |  |
| Subtotal | 253,084 |  |  | 1,278 |  |  | (694 | ) |  | 253,668 |  |  | 5,773 |  |  | 53,181 |  |  | 194,714 |  |
| Total | $ | 268,399 |  |  | $ | 1,278 |  |  | $ | (782 | ) |  | $ | 268,895 |  |  | $ | 20,289 |  |  | $ | 53,892 |  |  | $ | 194,714 |  |

[0000320193-18-000145:notes:4]
| (1) | Level 1 fair value estimates are based on quoted prices in active markets for identical assets or liabilities. |

[0000320193-18-000145:notes:5]
| (2) | Level 2 fair value estimates are based on observable inputs other than quoted prices in active markets for identical assets and liabilities, quoted prices for identical or similar assets or liabilities in inactive markets, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities. |

[0000320193-18-000145:notes:6]
| (3) | As of September 29, 2018, total cash, cash equivalents and marketable securities included $20.3 billion that was restricted from general use, related to the State Aid Decision (refer to Note 4, “Income Taxes”) and other agreements. |


## aapl:CommercialPaperCashFlowSummaryTableTextBlock

[0000320193-18-000145:notes:7]
The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for 2018, 2017 and 2016 (in millions):

[0000320193-18-000145:notes:8]
|  | 2018 |  | 2017 |  | 2016 |
| Maturities 90 days or less: |  |  |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | 1,044 |  |  | $ | (1,782 | ) |  | $ | (869 | ) |
| Maturities greater than 90 days: |  |  |  |  |  |
| Proceeds from commercial paper | 14,555 |  |  | 17,932 |  |  | 3,632 |  |
| Repayments of commercial paper | (15,636 | ) |  | (12,298 | ) |  | (3,160 | ) |
| Proceeds from/(Repayments of) commercial paper, net | (1,081 | ) |  | 5,634 |  |  | 472 |  |
| Total change in commercial paper, net | $ | (37 | ) |  | $ | 3,852 |  |  | $ | (397 | ) |


## aapl:NotionalAndCreditRiskAmountsOfOutstandingDerivativePositionsDisclosureTextBlock

[0000320193-18-000145:notes:9]
The following table shows the notional amounts of the Company’s outstanding derivative instruments and credit risk amounts associated with outstanding or unsettled derivative instruments as of September 29, 2018 and September 30, 2017 (in millions):

[0000320193-18-000145:notes:10]
|  | 2018 |  | 2017 |
|  | NotionalAmount |  | Credit RiskAmount |  | NotionalAmount |  | Credit RiskAmount |
| Instruments designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 65,368 |  |  | $ | 1,015 |  |  | $ | 56,156 |  |  | $ | 1,049 |  |
| Interest rate contracts | $ | 33,250 |  |  | $ | — |  |  | $ | 33,000 |  |  | $ | 218 |  |
| Instruments not designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 63,062 |  |  | $ | 259 |  |  | $ | 69,774 |  |  | $ | 363 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000320193-18-000145:notes:11]
Consolidated Financial Statement Details

[0000320193-18-000145:notes:12]
The following tables show the Company’s consolidated financial statement details as of September 29, 2018 and September 30, 2017 (in millions):

[0000320193-18-000145:notes:13]
Property, Plant and Equipment, Net

[0000320193-18-000145:notes:14]
|  | 2018 |  | 2017 |
| Land and buildings | $ | 16,216 |  |  | $ | 13,587 |  |
| Machinery, equipment and internal-use software | 65,982 |  |  | 54,210 |  |
| Leasehold improvements | 8,205 |  |  | 7,279 |  |
| Gross property, plant and equipment | 90,403 |  |  | 75,076 |  |
| Accumulated depreciation and amortization | (49,099 | ) |  | (41,293 | ) |
| Total property, plant and equipment, net | $ | 41,304 |  |  | $ | 33,783 |  |

[0000320193-18-000145:notes:15]
Other Non-Current Liabilities

[0000320193-18-000145:notes:16]
|  | 2018 |  | 2017 |
| Long-term taxes payable | $ | 33,589 |  |  | $ | 257 |  |
| Deferred tax liabilities | 426 |  |  | 31,504 |  |
| Other non-current liabilities | 11,165 |  |  | 8,654 |  |
| Total other non-current liabilities | $ | 45,180 |  |  | $ | 40,415 |  |

[0000320193-18-000145:notes:17]
Other Income/(Expense), Net

[0000320193-18-000145:notes:18]
The following table shows the detail of other income/(expense), net for 2018, 2017 and 2016 (in millions):

[0000320193-18-000145:notes:19]
|  | 2018 |  | 2017 |  | 2016 |
| Interest and dividend income | $ | 5,686 |  |  | $ | 5,201 |  |  | $ | 3,999 |  |
| Interest expense | (3,240 | ) |  | (2,323 | ) |  | (1,456 | ) |
| Other expense, net | (441 | ) |  | (133 | ) |  | (1,195 | ) |
| Total other income/(expense), net | $ | 2,005 |  |  | $ | 2,745 |  |  | $ | 1,348 |  |


## us-gaap:AdvertisingCostsPolicyTextBlock

[0000320193-18-000145:notes:20]
Advertising Costs

[0000320193-18-000145:notes:21]
Advertising costs are expensed as incurred and included in selling, general and administrative expenses.


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000320193-18-000145:notes:22]
Basis of Presentation and Preparation

[0000320193-18-000145:notes:23]
The accompanying consolidated financial statements include the accounts of the Company. Intercompany accounts and transactions have been eliminated. In the opinion of the Company’s management, the consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these consolidated financial statements and accompanying notes in conformity with U.S. generally accepted accounting principles (“GAAP”) requires management to make estimates and assumptions that affect the amounts reported. Actual results could differ materially from those estimates. Certain prior period amounts in the consolidated financial statements and accompanying notes have been reclassified to conform to the current period’s presentation.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000320193-18-000145:notes:24]
Summary of Significant Accounting Policies

[0000320193-18-000145:notes:25]
Apple Inc. and its wholly-owned subsidiaries (collectively “Apple” or the “Company”) designs, manufactures and markets mobile communication and media devices and personal computers, and sells a variety of related software, services, accessories and third-party digital content and applications. The Company’s products and services include iPhone, iPad, Mac, Apple Watch, AirPods, Apple TV, HomePod, a portfolio of consumer and professional software applications, iOS, macOS, watchOS and tvOS operating systems, iCloud, Apple Pay and a variety of other accessory, service and support offerings. The Company sells and delivers digital content and applications through the iTunes Store, App Store, Mac App Store, TV App Store, Book Store and Apple Music (collectively “Digital Content and Services”). The Company sells its products worldwide through its retail stores, online stores and direct sales force, as well as through third-party cellular network carriers, wholesalers, retailers and resellers. In addition, the Company sells a variety of third-party Apple-compatible products, including application software and various accessories, through its retail and online stores. The Company sells to consumers, small and mid-sized businesses and education, enterprise and government customers.

[0000320193-18-000145:notes:26]
The Company’s fiscal year is the 52- or 53-week period that ends on the last Saturday of September. The Company’s fiscal years 2018 and 2016 spanned 52 weeks each, whereas fiscal year 2017 included 53 weeks. A 14th week was included in the first fiscal quarter of 2017, as is done every five or six years, to realign the Company’s fiscal quarters with calendar quarters. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in September and the associated quarters, months and periods of those fiscal years.

[0000320193-18-000145:notes:27]
Revenue Recognition

[0000320193-18-000145:notes:28]
Net sales consist primarily of revenue from the sale of hardware, software, digital content and applications, accessories, and service and support contracts. The Company recognizes revenue when persuasive evidence of an arrangement exists, delivery has occurred, the sales price is fixed or determinable and collection is probable. Product is considered delivered to the customer once it has been shipped and title, risk of loss and rewards of ownership have been transferred. For most of the Company’s product sales, these criteria are met at the time the product is shipped. For online sales to individuals, for some sales to education customers in the U.S., and for certain other sales, the Company defers revenue until the customer receives the product because the Company retains a portion of the risk of loss on these sales during transit. For payment terms in excess of the Company’s standard payment terms, revenue is recognized as payments become due unless the Company has positive evidence that the sales price is fixed or determinable, such as a successful history of collection, without concession, on comparable arrangements. The Company recognizes revenue from the sale of hardware products, software bundled with hardware that is essential to the functionality of the hardware and third-party digital content sold on the iTunes Store in accordance with general revenue recognition accounting guidance. The Company recognizes revenue in accordance with industry-specific software accounting guidance for the following types of sales transactions: (i) standalone sales of software products, (ii) sales of software upgrades and (iii) sales of software bundled with hardware not essential to the functionality of the hardware.

[0000320193-18-000145:notes:29]
For the sale of most third-party products, the Company recognizes revenue based on the gross amount billed to customers because the Company establishes its own pricing for such products, retains related inventory risk for physical products, is the primary obligor to the customer and assumes the credit risk for amounts billed to its customers. For third-party applications sold through the App Store and Mac App Store and certain digital content sold through the iTunes Store, the Company does not determine the selling price of the products and is not the primary obligor to the customer. Therefore, the Company accounts for such sales on a net basis by recognizing in net sales only the commission it retains from each sale. The portion of the gross amount billed to customers that is remitted by the Company to third-party app developers and certain digital content owners is not reflected in the Company’s Consolidated Statements of Operations.

[0000320193-18-000145:notes:30]
The Company records deferred revenue when it receives payments in advance of the delivery of products or the performance of services. This includes amounts that have been deferred for unspecified and specified software upgrade rights and non-software services that are attached to hardware and software products. The Company sells gift cards redeemable at its retail and online stores, and also sells gift cards redeemable on iTunes Store, App Store, Mac App Store, TV App Store and Book Store for the purchase of digital content and software. The Company records deferred revenue upon the sale of the card, which is relieved upon redemption of the card by the customer. Revenue from AppleCare service and support contracts is deferred and recognized over the service coverage periods. AppleCare service and support contracts typically include extended phone support, repair services, web-based support resources and diagnostic tools offered under the Company’s standard limited warranty.

[0000320193-18-000145:notes:31]
The Company records reductions to revenue for estimated commitments related to price protection and other customer incentive programs. For transactions involving price protection, the Company recognizes revenue net of the estimated amount to be refunded. For the Company’s other customer incentive programs, the estimated cost of these programs is recognized at the later of the date at which the Company has sold the product or the date at which the program is offered. The Company also records reductions to revenue for expected future product returns based on the Company’s historical experience. Revenue is recorded net of taxes collected from customers that are remitted to governmental authorities, with the collected taxes recorded as current liabilities until remitted to the relevant government authority.

[0000320193-18-000145:notes:32]
Revenue Recognition for Arrangements with Multiple Deliverables

[0000320193-18-000145:notes:33]
For multi-element arrangements that include hardware products containing software essential to the hardware product’s functionality, undelivered software elements that relate to the hardware product’s essential software, and undelivered non-software services, the Company allocates revenue to all deliverables based on their relative selling prices. In such circumstances, the Company uses a hierarchy to determine the selling price to be used for allocating revenue to deliverables: (i) vendor-specific objective evidence of fair value (“VSOE”), (ii) third-party evidence of selling price (“TPE”) and (iii) best estimate of selling price (“ESP”). VSOE generally exists only when the Company sells the deliverable separately and is the price actually charged by the Company for that deliverable. ESPs reflect the Company’s best estimates of what the selling prices of elements would be if they were sold regularly on a stand-alone basis. For multi-element arrangements accounted for in accordance with industry-specific software accounting guidance, the Company allocates revenue to all deliverables based on the VSOE of each element, and if VSOE does not exist revenue is recognized when elements lacking VSOE are delivered.

[0000320193-18-000145:notes:34]
For sales of iPhone, iPad, Mac and certain other products, the Company has indicated it may from time to time provide future unspecified software upgrades to the device’s essential software and/or non-software services free of charge. The Company has identified up to three deliverables regularly included in arrangements involving the sale of these devices. The first deliverable, which represents the substantial portion of the allocated sales price, is the hardware and software essential to the functionality of the hardware device delivered at the time of sale. The second deliverable is the embedded right included with qualifying devices to receive, on a when-and-if-available basis, future unspecified software upgrades relating to the product’s essential software. The third deliverable is the non-software services to be provided to qualifying devices. The Company allocates revenue between these deliverables using the relative selling price method. Because the Company has neither VSOE nor TPE for these deliverables, the allocation of revenue is based on the Company’s ESPs. Revenue allocated to the delivered hardware and the related essential software is recognized at the time of sale, provided the other conditions for revenue recognition have been met. Revenue allocated to the embedded unspecified software upgrade rights and the non-software services is deferred and recognized on a straight-line basis over the estimated period the software upgrades and non-software services are expected to be provided. Cost of sales related to delivered hardware and related essential software, including estimated warranty costs, are recognized at the time of sale. Costs incurred to provide non-software services are recognized as cost of sales as incurred, and engineering and sales and marketing costs are recognized as operating expenses as incurred.

[0000320193-18-000145:notes:35]
The Company’s process for determining its ESP for deliverables without VSOE or TPE considers multiple factors that may vary depending upon the unique facts and circumstances related to each deliverable including, where applicable, prices charged by the Company and market trends in the pricing for similar offerings, product-specific business objectives, estimated cost to provide the non-software services and the relative ESP of the upgrade rights and non-software services as compared to the total selling price of the product.

[0000320193-18-000145:notes:36]
Shipping Costs

[0000320193-18-000145:notes:37]
Amounts billed to customers related to shipping and handling are classified as revenue, and the Company’s shipping and handling costs are classified as cost of sales.

[0000320193-18-000145:notes:38]
Share-Based Compensation

[0000320193-18-000145:notes:39]
The Company generally measures share-based compensation based on the closing price of the Company’s common stock on the date of grant, and recognizes expense on a straight-line basis for its estimate of equity awards that will ultimately vest. Further information regarding share-based compensation can be found in Note 8, “Benefit Plans.”

[0000320193-18-000145:notes:40]
During the first quarter of 2018, the Company adopted the Financial Accounting Standards Board’s (the “FASB”) Accounting Standards Update (“ASU”) No. 2016-09, Compensation – Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting (“ASU 2016-09”), which modified certain aspects of the accounting for share-based payment transactions, including income taxes, classification of awards and classification in the statement of cash flows. Historically, excess tax benefits or deficiencies from the Company’s equity awards were recorded as additional paid-in capital in its Consolidated Balance Sheets and were classified as a financing activity in its Consolidated Statements of Cash Flows. Beginning in 2018, the Company records any excess tax benefits or deficiencies from its equity awards as part of the provision for income taxes in its Consolidated Statements of Operations in the reporting periods in which equity vesting occurs. The Company elected to apply the cash flow classification requirements related to excess tax benefits retrospectively to all periods presented, which resulted in an increase to cash generated by operating activities in the Consolidated Statements of Cash Flows of $627 million and $407 million for 2017 and 2016, respectively.

[0000320193-18-000145:notes:41]
Earnings Per Share

[0000320193-18-000145:notes:42]
The following table shows the computation of basic and diluted earnings per share for 2018, 2017 and 2016 (net income in millions and shares in thousands):

[0000320193-18-000145:notes:43]
|  | 2018 |  | 2017 |  | 2016 |
| Numerator: |  |  |  |  |  |
| Net income | $ | 59,531 |  |  | $ | 48,351 |  |  | $ | 45,687 |  |
| Denominator: |  |  |  |  |  |
| Weighted-average basic shares outstanding | 4,955,377 |  |  | 5,217,242 |  |  | 5,470,820 |  |
| Effect of dilutive securities | 44,732 |  |  | 34,450 |  |  | 29,461 |  |
| Weighted-average diluted shares | 5,000,109 |  |  | 5,251,692 |  |  | 5,500,281 |  |
| Basic earnings per share | $ | 12.01 |  |  | $ | 9.27 |  |  | $ | 8.35 |  |
| Diluted earnings per share | $ | 11.91 |  |  | $ | 9.21 |  |  | $ | 8.31 |  |

[0000320193-18-000145:notes:44]
Cash Equivalents and Marketable Securities

[0000320193-18-000145:notes:45]
All highly liquid investments with maturities of three months or less at the date of purchase are classified as cash equivalents. The Company’s marketable debt and equity securities have been classified and accounted for as available-for-sale. The Company classifies its marketable debt securities as either short-term or long-term based on each instrument’s underlying contractual maturity date. Marketable equity securities, including mutual funds, are classified as short-term based on the nature of the securities and their availability for use in current operations. The cost of securities sold is determined using the specific identification method.

[0000320193-18-000145:notes:46]
Inventories

[0000320193-18-000145:notes:47]
Inventories are computed using the first-in, first-out method.

[0000320193-18-000145:notes:48]
Property, Plant and Equipment

[0000320193-18-000145:notes:49]
Depreciation on property, plant and equipment is recognized on a straight-line basis over the estimated useful lives of the assets, which for buildings is the lesser of 30 years or the remaining life of the underlying building; between one and five years for machinery and equipment, including product tooling and manufacturing process equipment; and the shorter of lease term or useful life for leasehold improvements. Capitalized costs related to internal-use software are amortized on a straight-line basis over the estimated useful lives of the assets, which range from three to five years. Depreciation and amortization expense on property and equipment was $9.3 billion, $8.2 billion and $8.3 billion during 2018, 2017 and 2016, respectively.

[0000320193-18-000145:notes:50]
During 2018, non-cash investing activities involving property, plant and equipment resulted in a net increase to accounts payable and other current liabilities of $3.4 billion.

[0000320193-18-000145:notes:51]
Fair Value Measurements

[0000320193-18-000145:notes:52]
The Company’s valuation techniques used to measure the fair value of money market funds and certain marketable equity securities are derived from quoted prices in active markets for identical assets or liabilities. The valuation techniques used to measure the fair value of the Company’s debt instruments and all other financial instruments, which generally have counterparties with high credit ratings, are based on quoted market prices or model-driven valuations using significant inputs derived from or corroborated by observable market data.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000320193-18-000145:notes:53]
Commitments and Contingencies

[0000320193-18-000145:notes:54]
Accrued Warranty and Indemnification

[0000320193-18-000145:notes:55]
The following table shows changes in the Company’s accrued warranties and related costs for 2018, 2017 and 2016 (in millions):

[0000320193-18-000145:notes:56]
|  | 2018 |  | 2017 |  | 2016 |
| Beginning accrued warranty and related costs | $ | 3,834 |  |  | $ | 3,702 |  |  | $ | 4,780 |  |
| Cost of warranty claims | (4,115 | ) |  | (4,322 | ) |  | (4,663 | ) |
| Accruals for product warranty | 3,973 |  |  | 4,454 |  |  | 3,585 |  |
| Ending accrued warranty and related costs | $ | 3,692 |  |  | $ | 3,834 |  |  | $ | 3,702 |  |

[0000320193-18-000145:notes:57]
Agreements entered into by the Company may include indemnification provisions which may subject the Company to costs and damages in the event of a claim against an indemnified third party. Except as disclosed under the heading “Contingencies” below, in the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to indemnification of third parties.

[0000320193-18-000145:notes:58]
The Company offers an iPhone Upgrade Program, which is available to customers who purchase a qualifying iPhone in the U.S., the U.K. and mainland China. The iPhone Upgrade Program provides customers the right to trade in that iPhone for a specified amount when purchasing a new iPhone, provided certain conditions are met. The Company accounts for the trade-in right as a guarantee liability and recognizes arrangement revenue net of the fair value of such right, with subsequent changes to the guarantee liability recognized within revenue.

[0000320193-18-000145:notes:59]
The Company has entered into indemnification agreements with its directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers of the Company, and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. While the Company maintains directors and officers liability insurance coverage, such insurance coverage may be insufficient to cover all losses or all types of claims that may arise.

[0000320193-18-000145:notes:60]
Concentrations in the Available Sources of Supply of Materials and Product

[0000320193-18-000145:notes:61]
Although most components essential to the Company’s business are generally available from multiple sources, certain components are currently obtained from single or limited sources. In addition, the Company competes for various components with other participants in the markets for mobile communication and media devices and personal computers. Therefore, many components used by the Company, including those that are available from multiple sources, are at times subject to industry-wide shortage and significant commodity pricing fluctuations that could materially adversely affect the Company’s financial condition and operating results.

[0000320193-18-000145:notes:62]
The Company uses some custom components that are not commonly used by its competitors, and new products introduced by the Company often utilize custom components available from only one source. When a component or product uses new technologies, initial capacity constraints may exist until the suppliers’ yields have matured or manufacturing capacity has increased. If the Company’s supply of components for a new or existing product were delayed or constrained, or if an outsourcing partner delayed shipments of completed products to the Company, the Company’s financial condition and operating results could be materially adversely affected. The Company’s business and financial performance could also be materially adversely affected depending on the time required to obtain sufficient quantities from the original source, or to identify and obtain sufficient quantities from an alternative source. Continued availability of these components at acceptable prices, or at all, may be affected if suppliers decide to concentrate on the production of common components instead of components customized to meet the Company’s requirements.

[0000320193-18-000145:notes:63]
The Company has entered into agreements for the supply of many components; however, there can be no guarantee that the Company will be able to extend or renew these agreements on similar terms, or at all. Therefore, the Company remains subject to significant risks of supply shortages and price increases that could materially adversely affect its financial condition and operating results.

[0000320193-18-000145:notes:64]
Substantially all of the Company’s hardware products are manufactured by outsourcing partners that are located primarily in Asia, with some Mac computers manufactured in the U.S. and Ireland. A significant concentration of this manufacturing is currently performed by a small number of outsourcing partners, often in single locations. Certain of these outsourcing partners are single-sourced suppliers of components and manufacturers for many of the Company’s products. Although the Company works closely with its outsourcing partners on manufacturing schedules, the Company’s financial condition and operating results could be materially adversely affected if its outsourcing partners were unable to meet their production commitments. The Company’s manufacturing purchase obligations typically cover its requirements for periods up to 150 days.

[0000320193-18-000145:notes:65]
Other Off–Balance Sheet Commitments

[0000320193-18-000145:notes:66]
Operating Leases

[0000320193-18-000145:notes:67]
The Company leases various equipment and facilities, including retail space, under noncancelable operating lease arrangements. The Company does not currently utilize any other off–balance sheet financing arrangements. As of September 29, 2018, the Company’s total future minimum lease payments under noncancelable operating leases were $9.6 billion. The Company’s retail store and other facility leases typically have original terms not exceeding 10 years and generally contain multi-year renewal options.

[0000320193-18-000145:notes:68]
Rent expense under all operating leases, including both cancelable and noncancelable leases, was $1.2 billion, $1.1 billion and $939 million in 2018, 2017 and 2016, respectively. Future minimum lease payments under noncancelable operating leases having initial or remaining terms in excess of one year as of September 29, 2018, are as follows (in millions):

[0000320193-18-000145:notes:69]
| 2019 | $ | 1,298 |  |
| 2020 | 1,289 |  |
| 2021 | 1,218 |  |
| 2022 | 1,038 |  |
| 2023 | 800 |  |
| Thereafter | 3,984 |  |
| Total | $ | 9,627 |  |

[0000320193-18-000145:notes:70]
Unconditional Purchase Obligations

[0000320193-18-000145:notes:71]
The Company has entered into certain off–balance sheet arrangements which require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of payments for supplier arrangements, internet and telecommunication services and intellectual property licenses. Future payments under noncancelable unconditional purchase obligations having a remaining term in excess of one year as of September 29, 2018, are as follows (in millions):

[0000320193-18-000145:notes:72]
| 2019 | $ | 2,447 |  |
| 2020 | 3,202 |  |
| 2021 | 1,749 |  |
| 2022 | 1,596 |  |
| 2023 | 268 |  |
| Thereafter | 66 |  |
| Total | $ | 9,328 |  |

[0000320193-18-000145:notes:73]
Contingencies

[0000320193-18-000145:notes:74]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully adjudicated, as further discussed in Part I, Item 1A of this Form 10-K under the heading “Risk Factors” and in Part I, Item 3 of this Form 10-K under the heading “Legal Proceedings.” The outcome of litigation is inherently uncertain. If one or more legal matters were resolved against the Company in a reporting period for amounts in excess of management’s expectations, the Company’s financial condition and operating results for that reporting period could be materially adversely affected. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to loss contingencies for asserted legal and other claims, except for the following matters:

[0000320193-18-000145:notes:75]
VirnetX

[0000320193-18-000145:notes:76]
VirnetX, Inc. filed two lawsuits in the U.S. District Court for the Eastern District of Texas (the “Eastern Texas District Court”) against the Company alleging that certain Company products infringe four patents (the “VirnetX Patents”) relating to network communications technology (“VirnetX I” and “VirnetX II”). On September 30, 2016, a jury returned a verdict in VirnetX I against the Company and awarded damages of $302 million, which later increased to $440 million in post-trial proceedings. VirnetX I is currently on appeal at the U.S. Court of Appeals for the Federal Circuit (the “Federal Circuit”). On April 11, 2018, a jury returned a verdict in VirnetX II against the Company and awarded damages of $503 million. VirnetX II is currently on appeal. The Company has challenged the validity of the VirnetX Patents at the U.S. Patent and Trademark Office (the “PTO”). In response, the PTO has declared the VirnetX Patents invalid. VirnetX has appealed, and those appeals are currently pending at the Federal Circuit. The Federal Circuit has consolidated the Company’s appeal of the Eastern Texas District Court VirnetX I verdict and VirnetX’s appeals from the PTO invalidity proceedings. The Company believes it will prevail on the merits.

[0000320193-18-000145:notes:77]
Qualcomm

[0000320193-18-000145:notes:78]
On January 20, 2017, the Company filed a lawsuit against Qualcomm Incorporated and affiliated parties (“Qualcomm”) in the U.S. District Court for the Southern District of California seeking, among other things, to enjoin Qualcomm from requiring the Company to pay royalties at the rate demanded by Qualcomm. As the Company does not believe the demanded royalty it has historically paid contract manufacturers for each applicable device is fair, reasonable and non-discriminatory, and believes it to be invalid and/or overstated in other respects as well, no Qualcomm-related royalty payments have been remitted by the Company to its contract manufacturers since the beginning of the second quarter of 2017. The Company believes it will prevail on the merits of the case and has accrued its best estimate for the ultimate resolution of this matter.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000320193-18-000145:notes:79]
Benefit Plans

[0000320193-18-000145:notes:80]
2014 Employee Stock Plan

[0000320193-18-000145:notes:81]
In the second quarter of 2014, shareholders approved the 2014 Employee Stock Plan (the “2014 Plan”) and terminated the Company’s authority to grant new awards under the 2003 Employee Stock Plan (the “2003 Plan”). The 2014 Plan provides for broad-based equity grants to employees, including executive officers, and permits the granting of RSUs, stock grants, performance-based awards, stock options and stock appreciation rights, as well as cash bonus awards. RSUs granted under the 2014 Plan generally vest over four years, based on continued employment, and are settled upon vesting in shares of the Company’s common stock on a one-for-one basis. Each share issued with respect to RSUs granted under the 2014 Plan reduces the number of shares available for grant under the plan by two shares. RSUs canceled and shares withheld to satisfy tax withholding obligations increase the number of shares available for grant under the 2014 Plan utilizing a factor of two times the number of RSUs canceled or shares withheld. Currently, all RSUs granted under the 2014 Plan have dividend equivalent rights (“DERs”), which entitle holders of RSUs to the same dividend value per share as holders of common stock. DERs are subject to the same vesting and other terms and conditions as the corresponding unvested RSUs. DERs are accumulated and paid when the underlying shares vest. Upon approval of the 2014 Plan, the Company reserved 385 million shares plus the number of shares remaining that were reserved but not issued under the 2003 Plan. Shares subject to outstanding awards under the 2003 Plan that expire, are canceled or otherwise terminate, or are withheld to satisfy tax withholding obligations with respect to RSUs, will also be available for awards under the 2014 Plan. As of September 29, 2018, approximately 280.2 million shares were reserved for future issuance under the 2014 Plan.

[0000320193-18-000145:notes:82]
Apple Inc. Non-Employee Director Stock Plan

[0000320193-18-000145:notes:83]
The Apple Inc. Non-Employee Director Stock Plan (the “Director Plan”) is a shareholder-approved plan that (i) permits the Company to grant awards of RSUs or stock options to the Company’s non-employee directors, (ii) provides for automatic initial grants of RSUs upon a non-employee director joining the Board of Directors and automatic annual grants of RSUs at each annual meeting of shareholders, and (iii) permits the Board of Directors to prospectively change the value and relative mixture of stock options and RSUs for the initial and annual award grants and the methodology for determining the number of shares of the Company’s common stock subject to these grants, in each case within the limits set forth in the Director Plan and without further shareholder approval. Each share issued with respect to RSUs granted under the Director Plan reduces the number of shares available for grant under the plan by two shares. The Director Plan expires November 12, 2027. All RSUs granted under the Director Plan are entitled to DERs. DERs are subject to the same vesting and other terms and conditions as the corresponding unvested RSUs. DERs are accumulated and paid when the underlying shares vest. As of September 29, 2018, approximately 1.1 million shares were reserved for future issuance under the Director Plan.

[0000320193-18-000145:notes:84]
Rule 10b5-1 Trading Plans

[0000320193-18-000145:notes:85]
During the three months ended September 29, 2018, Section 16 officers Angela Ahrendts, Timothy D. Cook, Chris Kondo, Luca Maestri, Daniel Riccio, Philip Schiller and Jeffrey Williams had equity trading plans in place in accordance with Rule 10b5-1(c)(1) under the Exchange Act. An equity trading plan is a written document that pre-establishes the amounts, prices and dates (or formula for determining the amounts, prices and dates) of future purchases or sales of the Company’s stock, including shares acquired pursuant to the Company’s employee and director equity plans.

[0000320193-18-000145:notes:86]
Employee Stock Purchase Plan

[0000320193-18-000145:notes:87]
The Employee Stock Purchase Plan (the “Purchase Plan”) is a shareholder-approved plan under which substantially all employees may purchase the Company’s common stock through payroll deductions at a price equal to 85% of the lower of the fair market values of the stock as of the beginning or the end of six-month offering periods. An employee’s payroll deductions under the Purchase Plan are limited to 10% of the employee’s compensation and employees may not purchase more than $25,000 of stock during any calendar year. As of September 29, 2018, approximately 36.5 million shares were reserved for future issuance under the Purchase Plan.

[0000320193-18-000145:notes:88]
401(k) Plan

[0000320193-18-000145:notes:89]
The Company’s 401(k) Plan is a deferred salary arrangement under Section 401(k) of the Internal Revenue Code. Under the 401(k) Plan, participating U.S. employees may defer a portion of their pre-tax earnings, up to the IRS annual contribution limit ($18,500 for calendar year 2018). The Company matches 50% to 100% of each employee’s contributions, depending on length of service, up to a maximum 6% of the employee’s eligible earnings.

[0000320193-18-000145:notes:90]
Restricted Stock Units

[0000320193-18-000145:notes:91]
A summary of the Company’s RSU activity and related information for 2018, 2017 and 2016, is as follows:

[0000320193-18-000145:notes:92]
|  | Number ofRSUs(in thousands) |  | Weighted-AverageGrant Date FairValue Per RSU |  | Aggregate Fair Value(in millions) |
| Balance as of September 26, 2015 | 101,467 |  |  | $ | 85.77 |  |  |  |
| RSUs granted | 49,468 |  |  | $ | 109.28 |  |  |  |
| RSUs vested | (46,313 | ) |  | $ | 84.44 |  |  |  |
| RSUs canceled | (5,533 | ) |  | $ | 96.48 |  |  |  |
| Balance as of September 24, 2016 | 99,089 |  |  | $ | 97.54 |  |  |  |
| RSUs granted | 50,112 |  |  | $ | 121.65 |  |  |  |
| RSUs vested | (45,735 | ) |  | $ | 95.48 |  |  |  |
| RSUs canceled | (5,895 | ) |  | $ | 106.87 |  |  |  |
| Balance as of September 30, 2017 | 97,571 |  |  | $ | 110.33 |  |  |  |
| RSUs granted | 45,351 |  |  | $ | 162.86 |  |  |  |
| RSUs vested | (44,718 | ) |  | $ | 111.24 |  |  |  |
| RSUs canceled | (6,049 | ) |  | $ | 127.82 |  |  |  |
| Balance as of September 29, 2018 | 92,155 |  |  | $ | 134.60 |  |  | $ | 20,803 |  |

[0000320193-18-000145:notes:93]
The fair value as of the respective vesting dates of RSUs was $7.6 billion, $6.1 billion and $5.1 billion for 2018, 2017 and 2016, respectively. The majority of RSUs that vested in 2018, 2017 and 2016 were net share settled such that the Company withheld shares with value equivalent to the employees’ obligation for the applicable income and other employment taxes, and remitted the cash to the appropriate taxing authorities. The total shares withheld were approximately 16.0 million, 15.4 million and 15.9 million for 2018, 2017 and 2016, respectively, and were based on the value of the RSUs on their respective vesting dates as determined by the Company’s closing stock price. Total payments for the employees’ tax obligations to taxing authorities were $2.7 billion, $2.0 billion and $1.7 billion in 2018, 2017 and 2016, respectively, and are reflected as a financing activity within the Consolidated Statements of Cash Flows. These net share settlements had the effect of share repurchases by the Company as they reduced the number of shares that would have otherwise been issued as a result of the vesting and did not represent an expense to the Company.

[0000320193-18-000145:notes:94]
The following table shows a summary of the share-based compensation expense included in the Consolidated Statements of Operations for 2018, 2017 and 2016 (in millions):

[0000320193-18-000145:notes:95]
|  | 2018 |  | 2017 |  | 2016 |
| Cost of sales | $ | 1,010 |  |  | $ | 877 |  |  | $ | 769 |  |
| Research and development | 2,668 |  |  | 2,299 |  |  | 1,889 |  |
| Selling, general and administrative | 1,662 |  |  | 1,664 |  |  | 1,552 |  |
| Total share-based compensation expense | $ | 5,340 |  |  | $ | 4,840 |  |  | $ | 4,210 |  |

[0000320193-18-000145:notes:96]
The income tax benefit related to share-based compensation expense was $1.9 billion, $1.6 billion and $1.4 billion for 2018, 2017 and 2016, respectively. As of September 29, 2018, the total unrecognized compensation cost related to outstanding RSUs and stock options was $9.4 billion, which the Company expects to recognize over a weighted-average period of 2.5 years.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000320193-18-000145:notes:97]
Comprehensive Income

[0000320193-18-000145:notes:98]
The Company’s OCI consists of foreign currency translation adjustments from those subsidiaries not using the U.S. dollar as their functional currency, net deferred gains and losses on certain derivative instruments accounted for as cash flow hedges and unrealized gains and losses on marketable securities classified as available-for-sale.

[0000320193-18-000145:notes:99]
The following table shows the pre-tax amounts reclassified from AOCI into the Consolidated Statements of Operations, and the associated financial statement line item, for 2018 and 2017 (in millions):

[0000320193-18-000145:notes:100]
| Comprehensive Income Components |  | Financial Statement Line Item |  | 2018 |  | 2017 |
| Unrealized (gains)/losses on derivative instruments: |  |  |  |  |  |  |
| Foreign exchange contracts |  | Net sales |  | $ | 214 |  |  | $ | (662 | ) |
|  |  | Cost of sales |  | (70 | ) |  | (654 | ) |
|  |  | Other income/(expense), net |  | 344 |  |  | (638 | ) |
| Interest rate contracts |  | Other income/(expense), net |  | (2 | ) |  | 2 |  |
|  |  |  |  | 486 |  |  | (1,952 | ) |
| Unrealized (gains)/losses on marketable securities |  | Other income/(expense), net |  | (20 | ) |  | (99 | ) |
| Total amounts reclassified from AOCI |  |  |  | $ | 466 |  |  | $ | (2,051 | ) |

[0000320193-18-000145:notes:101]
The following table shows the changes in AOCI by component for 2018 and 2017 (in millions):

[0000320193-18-000145:notes:102]
|  | Cumulative ForeignCurrency Translation |  | Unrealized Gains/Losseson Derivative Instruments |  | Unrealized Gains/Losseson Marketable Securities |  | Total |
| Balances as of September 24, 2016 | $ | (578 | ) |  | $ | 38 |  |  | $ | 1,174 |  |  | $ | 634 |  |
| Other comprehensive income/(loss) before reclassifications | 301 |  |  | 1,793 |  |  | (1,207 | ) |  | 887 |  |
| Amounts reclassified from AOCI | — |  |  | (1,952 | ) |  | (99 | ) |  | (2,051 | ) |
| Tax effect | (77 | ) |  | (3 | ) |  | 460 |  |  | 380 |  |
| Other comprehensive income/(loss) | 224 |  |  | (162 | ) |  | (846 | ) |  | (784 | ) |
| Balances as of September 30, 2017 | (354 | ) |  | (124 | ) |  | 328 |  |  | (150 | ) |
| Other comprehensive income/(loss) before reclassifications | (524 | ) |  | 672 |  |  | (4,563 | ) |  | (4,415 | ) |
| Amounts reclassified from AOCI | — |  |  | 486 |  |  | (20 | ) |  | 466 |  |
| Tax effect | (1 | ) |  | (253 | ) |  | 1,177 |  |  | 923 |  |
| Other comprehensive income/(loss) | (525 | ) |  | 905 |  |  | (3,406 | ) |  | (3,026 | ) |
| Cumulative effect of change in accounting principle (1) | (176 | ) |  | 29 |  |  | (131 | ) |  | (278 | ) |
| Balances as of September 29, 2018 | $ | (1,055 | ) |  | $ | 810 |  |  | $ | (3,209 | ) |  | $ | (3,454 | ) |

[0000320193-18-000145:notes:103]
| (1) | Refer to Note 4, “Income Taxes” for more information on the Company’s adoption of ASU 2018-02 in 2018. |


## us-gaap:DebtDisclosureTextBlock

[0000320193-18-000145:notes:104]
Debt

[0000320193-18-000145:notes:105]
Commercial Paper

[0000320193-18-000145:notes:106]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of both September 29, 2018 and September 30, 2017, the Company had $12.0 billion of Commercial Paper outstanding with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 2.18% as of September 29, 2018 and 1.20% as of September 30, 2017. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for 2018, 2017 and 2016 (in millions):

[0000320193-18-000145:notes:107]
Term Debt

[0000320193-18-000145:notes:108]
As of September 29, 2018, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $104.2 billion (collectively the “Notes”). The Notes are senior unsecured obligations, and interest is payable in arrears, quarterly for the U.S. dollar–denominated and Australian dollar–denominated floating-rate notes, semi-annually for the U.S. dollar–denominated, Australian dollar–denominated, British pound–denominated, Japanese yen–denominated and Canadian dollar–denominated fixed-rate notes and annually for the euro-denominated and Swiss franc–denominated fixed-rate notes. The following table provides a summary of the Company’s term debt as of September 29, 2018 and September 30, 2017:

[0000320193-18-000145:notes:109]
|  | Maturities(calendar year) |  | 2018 |  | 2017 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | — |  | $ | — |  |  |  |  |  | — | % |  | $ | 2,000 |  |  |  |  |  | 1.10 | % |
| Fixed-rate 2.400% – 3.850% notes | 2023 | – | 2043 |  | 8,500 |  |  |  | 2.44% | – | 3.91 | % |  | 12,500 |  |  |  | 1.08% | – | 3.91 | % |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2019 |  | 1,000 |  |  |  |  |  | 2.64 | % |  | 1,000 |  |  |  |  |  | 1.61 | % |
| Fixed-rate 2.100% – 4.450% notes | 2019 | – | 2044 |  | 8,500 |  |  |  | 2.64% | – | 4.48 | % |  | 8,500 |  |  |  | 1.61% | – | 4.48 | % |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2020 |  | 1,507 |  |  |  | 1.87% | – | 2.64 | % |  | 1,549 |  |  |  | 1.56% | – | 1.87 | % |
| Fixed-rate 0.350% – 4.375% notes | 2019 | – | 2045 |  | 24,410 |  |  |  | 0.28% | – | 4.51 | % |  | 24,522 |  |  |  | 0.28% | – | 4.51 | % |
| 2016 debt issuances of $24.9 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2021 |  | 1,350 |  |  |  | 2.48% | – | 3.44 | % |  | 1,350 |  |  |  | 1.45% | – | 2.44 | % |
| Fixed-rate 1.100% – 4.650% notes | 2019 | – | 2046 |  | 23,059 |  |  |  | 1.13% | – | 4.78 | % |  | 23,645 |  |  |  | 1.13% | – | 4.78 | % |
| 2017 debt issuances of $28.7 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2022 |  | 3,250 |  |  |  | 2.41% | – | 2.84 | % |  | 3,250 |  |  |  | 1.38% | – | 1.81 | % |
| Fixed-rate 0.875% – 4.300% notes | 2019 | – | 2047 |  | 25,617 |  |  |  | 1.54% | – | 4.30 | % |  | 25,705 |  |  |  | 1.51% | – | 4.30 | % |
| First quarter 2018 debt issuance of $7.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 1.800% notes |  |  | 2019 |  | 1,000 |  |  |  |  |  | 1.83 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.000% notes |  |  | 2020 |  | 1,000 |  |  |  |  |  | 2.03 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.400% notes |  |  | 2023 |  | 750 |  |  |  |  |  | 2.66 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.750% notes |  |  | 2025 |  | 1,500 |  |  |  |  |  | 2.77 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.000% notes |  |  | 2027 |  | 1,500 |  |  |  |  |  | 3.05 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.750% notes |  |  | 2047 |  | 1,250 |  |  |  |  |  | 3.80 | % |  | — |  |  |  |  |  | — | % |
| Total term debt |  |  |  |  | 104,193 |  |  |  |  |  |  |  | 104,021 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (218 | ) |  |  |  |  |  |  | (225 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | (1,456 | ) |  |  |  |  |  |  | (93 | ) |  |  |  |  |  |
| Less: Current portion of term debt |  |  |  |  | (8,784 | ) |  |  |  |  |  |  | (6,496 | ) |  |  |  |  |  |
| Total non-current portion of term debt |  |  |  |  | $ | 93,735 |  |  |  |  |  |  |  | $ | 97,207 |  |  |  |  |  |  |

[0000320193-18-000145:notes:110]
To manage interest rate risk on certain of its U.S. dollar–denominated fixed- or floating-rate notes, the Company has entered into interest rate swaps to effectively convert the fixed interest rates to floating interest rates or the floating interest rates to fixed interest rates on a portion of these notes. Additionally, to manage foreign currency risk on certain of its foreign currency–denominated notes, the Company has entered into foreign currency swaps to effectively convert these notes to U.S. dollar–denominated notes.

[0000320193-18-000145:notes:111]
A portion of the Company’s Japanese yen–denominated notes is designated as a hedge of the foreign currency exposure of the Company’s net investment in a foreign operation. As of September 29, 2018 and September 30, 2017, the carrying value of the debt designated as a net investment hedge was $811 million and $1.6 billion, respectively. For further discussion regarding the Company’s use of derivative instruments, refer to the Derivative Financial Instruments section of Note 2, “Financial Instruments.”

[0000320193-18-000145:notes:112]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $3.0 billion, $2.2 billion and $1.4 billion of interest expense on its term debt for 2018, 2017 and 2016, respectively.

[0000320193-18-000145:notes:113]
The future principal payments for the Company’s Notes as of September 29, 2018 are as follows (in millions):

[0000320193-18-000145:notes:114]
| 2019 | $ | 8,797 |  |
| 2020 | 10,183 |  |
| 2021 | 8,750 |  |
| 2022 | 8,583 |  |
| 2023 | 9,395 |  |
| Thereafter | 58,485 |  |
| Total term debt | $ | 104,193 |  |

[0000320193-18-000145:notes:115]
As of September 29, 2018 and September 30, 2017, the fair value of the Company’s Notes, based on Level 2 inputs, was $103.2 billion and $106.1 billion, respectively.


## us-gaap:DerivativesPolicyTextBlock

[0000320193-18-000145:notes:116]
Derivative Financial Instruments

[0000320193-18-000145:notes:117]
The Company may use derivatives to partially offset its business exposure to foreign currency and interest rate risk on expected future cash flows, net investments in certain foreign subsidiaries, and certain existing assets and liabilities. However, the Company may choose not to hedge certain exposures for a variety of reasons including, but not limited to, accounting considerations or the prohibitive economic cost of hedging particular exposures. There can be no assurance the hedges will offset more than a portion of the financial impact resulting from movements in foreign currency exchange or interest rates.

[0000320193-18-000145:notes:118]
To protect gross margins from fluctuations in foreign currency exchange rates, certain of the Company’s subsidiaries whose functional currency is the U.S. dollar may hedge a portion of forecasted foreign currency revenue, and subsidiaries whose functional currency is not the U.S. dollar may hedge a portion of forecasted inventory purchases not denominated in the subsidiaries’ functional currencies. The Company may enter into forward contracts, option contracts or other instruments to manage this risk and may designate these instruments as cash flow hedges. The Company generally hedges portions of its forecasted foreign currency exposure associated with revenue and inventory purchases, typically for up to 12 months.

[0000320193-18-000145:notes:119]
To protect the net investment in a foreign operation from fluctuations in foreign currency exchange rates, the Company may enter into foreign currency forward and option contracts to offset a portion of the changes in the carrying amounts of these investments due to fluctuations in foreign currency exchange rates. In addition, the Company may use non-derivative financial instruments, such as its foreign currency–denominated debt, as hedges of its net investments in certain foreign subsidiaries. In both of these cases, the Company designates these instruments as net investment hedges.

[0000320193-18-000145:notes:120]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in foreign currency exchange rates, the Company may enter into forward contracts, cross-currency swaps or other instruments. These instruments may offset a portion of the foreign currency remeasurement gains or losses, or changes in fair value. The Company may designate these instruments as either cash flow or fair value hedges. As of September 29, 2018, the Company’s hedged term debt– and marketable securities–related foreign currency transactions are expected to be recognized within 24 years.

[0000320193-18-000145:notes:121]
The Company may also enter into non-designated foreign currency contracts to offset a portion of the foreign currency exchange gains and losses generated by the remeasurement of certain assets and liabilities denominated in non-functional currencies.

[0000320193-18-000145:notes:122]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in interest rates, the Company may enter into interest rate swaps, options or other instruments. These instruments may offset a portion of the changes in interest income or expense, or changes in fair value. The Company designates these instruments as either cash flow or fair value hedges. As of September 29, 2018, the Company’s hedged interest rate transactions are expected to be recognized within 9 years.

[0000320193-18-000145:notes:123]
Cash Flow Hedges

[0000320193-18-000145:notes:124]
The effective portions of cash flow hedges are recorded in accumulated other comprehensive income/(loss) (“AOCI”) until the hedged item is recognized in earnings. Deferred gains and losses associated with cash flow hedges of foreign currency revenue are recognized as a component of net sales in the same period as the related revenue is recognized, and deferred gains and losses related to cash flow hedges of inventory purchases are recognized as a component of cost of sales in the same period as the related costs are recognized. Deferred gains and losses associated with cash flow hedges of interest income or expense are recognized in other income/(expense), net in the same period as the related income or expense is recognized. For options designated as cash flow hedges, changes in the time value are excluded from the assessment of hedge effectiveness. The ineffective portions and amounts excluded from the effectiveness testing of cash flow hedges are recognized in other income/(expense), net.

[0000320193-18-000145:notes:125]
Derivative instruments designated as cash flow hedges must be de-designated as hedges when it is probable the forecasted hedged transaction will not occur in the initially identified time period or within a subsequent two-month time period. Deferred gains and losses in AOCI associated with such derivative instruments are reclassified into other income/(expense), net in the period of de-designation. Any subsequent changes in fair value of such derivative instruments are reflected in other income/(expense), net unless they are re-designated as hedges of other transactions.

[0000320193-18-000145:notes:126]
Net Investment Hedges

[0000320193-18-000145:notes:127]
The effective portions of net investment hedges are recorded in other comprehensive income/(loss) (“OCI”) as a part of the cumulative translation adjustment. The ineffective portions and amounts excluded from the effectiveness testing of net investment hedges are recognized in other income/(expense), net. For forward exchange contracts designated as net investment hedges, the Company excludes changes in fair value relating to changes in the forward carry component from its definition of effectiveness. Accordingly, any gains or losses related to this forward carry component are recognized in earnings in the current period.

[0000320193-18-000145:notes:128]
Fair Value Hedges

[0000320193-18-000145:notes:129]
Gains and losses related to changes in fair value hedges are recognized in earnings along with a corresponding loss or gain related to the change in value of the underlying hedged item in the same line in the Consolidated Statements of Operations.

[0000320193-18-000145:notes:130]
Non-Designated Derivatives

[0000320193-18-000145:notes:131]
Derivatives that are not designated as hedging instruments are adjusted to fair value through earnings in the financial statement line item to which the derivative relates.

[0000320193-18-000145:notes:132]
The Company records all derivatives in the Consolidated Balance Sheets at fair value. The Company’s accounting treatment for these derivative instruments is based on its hedge designation.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000320193-18-000145:notes:133]
Level 2 fair value estimates are based on observable inputs other than quoted prices in active markets for identical assets and liabilities, quoted prices for identical or similar assets or liabilities in inactive markets, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities.

[0000320193-18-000145:notes:134]
Level 1 fair value estimates are based on quoted prices in active markets for identical assets or liabilities.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000320193-18-000145:notes:135]
Financial Instruments

[0000320193-18-000145:notes:136]
Cash, Cash Equivalents and Marketable Securities

[0000320193-18-000145:notes:137]
The Company may sell certain of its marketable securities prior to their stated maturities for reasons including, but not limited to, managing liquidity, credit risk, duration and asset allocation. The maturities of the Company’s long-term marketable securities generally range from one to five years.

[0000320193-18-000145:notes:138]
The following tables show information about the Company’s marketable securities that had been in a continuous unrealized loss position for less than 12 months and for 12 months or greater as of September 29, 2018 and September 30, 2017 (in millions):

[0000320193-18-000145:notes:139]
|  | 2018 |
|  | Continuous Unrealized Losses |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
| Fair value of marketable securities | $ | 126,238 |  |  | $ | 60,599 |  |  | $ | 186,837 |  |
| Unrealized losses | $ | (2,400 | ) |  | $ | (1,889 | ) |  | $ | (4,289 | ) |

[0000320193-18-000145:notes:140]
|  | 2017 |
|  | Continuous Unrealized Losses |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
| Fair value of marketable securities | $ | 101,986 |  |  | $ | 8,290 |  |  | $ | 110,276 |  |
| Unrealized losses | $ | (596 | ) |  | $ | (186 | ) |  | $ | (782 | ) |

[0000320193-18-000145:notes:141]
The Company typically invests in highly rated securities, with the primary objective of minimizing the potential risk of principal loss. The Company’s investment policy generally requires securities to be investment grade and limits the amount of credit exposure to any one issuer. Fair values were determined for each individual security in the investment portfolio. When evaluating an investment for other-than-temporary impairment, the Company reviews factors such as the length of time and extent to which fair value has been below its cost basis, the financial condition of the issuer and any changes thereto, changes in market interest rates and the Company’s intent to sell, or whether it is more likely than not it will be required to sell the investment before recovery of the investment’s cost basis. As of September 29, 2018, the Company does not consider any of its investments to be other-than-temporarily impaired.

[0000320193-18-000145:notes:142]
Derivatives that are not designated as hedging instruments are adjusted to fair value through earnings in the financial statement line item to which the derivative relates. As a result, during 2018, the Company recognized a gain of $20 million in net sales, a gain of $85 million in cost of sales and a loss of $198 million in other income/(expense), net. During 2017, the Company recognized a gain of $20 million in net sales, a loss of $40 million in cost of sales and a gain of $606 million in other income/(expense), net.

[0000320193-18-000145:notes:143]
The Company records all derivatives in the Consolidated Balance Sheets at fair value. The Company’s accounting treatment for these derivative instruments is based on its hedge designation. The following tables show the Company’s derivative instruments at gross fair value as of September 29, 2018 and September 30, 2017 (in millions):

[0000320193-18-000145:notes:144]
|  | 2018 |
|  | Fair Value ofDerivatives Designatedas Hedge Instruments |  | Fair Value ofDerivatives Not Designatedas Hedge Instruments |  | TotalFair Value |
| Derivative assets (1): |  |  |  |  |  |
| Foreign exchange contracts | $ | 1,015 |  |  | $ | 259 |  |  | $ | 1,274 |  |
| Derivative liabilities (2): |  |  |  |  |  |
| Foreign exchange contracts | $ | 543 |  |  | $ | 137 |  |  | $ | 680 |  |
| Interest rate contracts | $ | 1,456 |  |  | $ | — |  |  | $ | 1,456 |  |

[0000320193-18-000145:notes:145]
|  | 2017 |
|  | Fair Value ofDerivatives Designatedas Hedge Instruments |  | Fair Value ofDerivatives Not Designatedas Hedge Instruments |  | TotalFair Value |
| Derivative assets (1): |  |  |  |  |  |
| Foreign exchange contracts | $ | 1,049 |  |  | $ | 363 |  |  | $ | 1,412 |  |
| Interest rate contracts | $ | 218 |  |  | $ | — |  |  | $ | 218 |  |
| Derivative liabilities (2): |  |  |  |  |  |
| Foreign exchange contracts | $ | 759 |  |  | $ | 501 |  |  | $ | 1,260 |  |
| Interest rate contracts | $ | 303 |  |  | $ | — |  |  | $ | 303 |  |

[0000320193-18-000145:notes:146]
| (1) | The fair value of derivative assets is measured using Level 2 fair value inputs and is recorded as other current assets and other non-current assets in the Consolidated Balance Sheets. |

[0000320193-18-000145:notes:147]
| (2) | The fair value of derivative liabilities is measured using Level 2 fair value inputs and is recorded as other current liabilities and other non-current liabilities in the Consolidated Balance Sheets. |

[0000320193-18-000145:notes:148]
The Company classifies cash flows related to derivative financial instruments as operating activities in its Consolidated Statements of Cash Flows.

[0000320193-18-000145:notes:149]
The following table shows the pre-tax gains and losses of the Company’s derivative and non-derivative instruments designated as cash flow, net investment and fair value hedges in OCI and the Consolidated Statements of Operations for 2018, 2017 and 2016 (in millions):

[0000320193-18-000145:notes:150]
|  | 2018 |  | 2017 |  | 2016 |
| Gains/(Losses) recognized in OCI – effective portion: |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |
| Foreign exchange contracts | $ | 682 |  |  | $ | 1,797 |  |  | $ | 109 |  |
| Interest rate contracts | 1 |  |  | 7 |  |  | (57 | ) |
| Total | $ | 683 |  |  | $ | 1,804 |  |  | $ | 52 |  |
| Net investment hedges: |  |  |  |  |  |
| Foreign currency debt | $ | 4 |  |  | $ | 67 |  |  | $ | (258 | ) |
| Gains/(Losses) reclassified from AOCI into net income – effective portion: |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |
| Foreign exchange contracts | $ | (482 | ) |  | $ | 1,958 |  |  | $ | 885 |  |
| Interest rate contracts | 1 |  |  | (2 | ) |  | (11 | ) |
| Total | $ | (481 | ) |  | $ | 1,956 |  |  | $ | 874 |  |
| Gains/(Losses) on derivative instruments: |  |  |  |  |  |
| Fair value hedges: |  |  |  |  |  |
| Foreign exchange contracts | $ | (168 | ) |  | $ | — |  |  | $ | — |  |
| Interest rate contracts | (1,363 | ) |  | (810 | ) |  | 341 |  |
| Total | $ | (1,531 | ) |  | $ | (810 | ) |  | $ | 341 |  |
| Gains/(Losses) related to hedged items: |  |  |  |  |  |
| Fair value hedges: |  |  |  |  |  |
| Marketable securities | $ | 167 |  |  | $ | — |  |  | $ | — |  |
| Fixed-rate debt | 1,363 |  |  | 810 |  |  | (341 | ) |
| Total | $ | 1,530 |  |  | $ | 810 |  |  | $ | (341 | ) |

[0000320193-18-000145:notes:151]
The notional amounts for outstanding derivative instruments provide one measure of the transaction volume outstanding and do not represent the amount of the Company’s exposure to credit or market loss. The credit risk amounts represent the Company’s gross exposure to potential accounting loss on derivative instruments that are outstanding or unsettled if all counterparties failed to perform according to the terms of the contract, based on then-current currency or interest rates at each respective date. The Company’s exposure to credit loss and market risk will vary over time as currency and interest rates change. Although the table above reflects the notional and credit risk amounts of the Company’s derivative instruments, it does not reflect the gains or losses associated with the exposures and transactions that the instruments are intended to hedge. The amounts ultimately realized upon settlement of these financial instruments, together with the gains and losses on the underlying exposures, will depend on actual market conditions during the remaining life of the instruments.

[0000320193-18-000145:notes:152]
The Company generally enters into master netting arrangements, which are designed to reduce credit risk by permitting net settlement of transactions with the same counterparty. To further limit credit risk, the Company generally enters into collateral security arrangements that provide for collateral to be received or posted when the net fair value of certain financial instruments fluctuates from contractually established thresholds. The Company presents its derivative assets and derivative liabilities at their gross fair values in its Consolidated Balance Sheets. As of September 29, 2018, the net cash collateral posted by the Company related to derivative instruments under its collateral security arrangements was $1.0 billion, which was recorded as other current assets in the Condensed Consolidated Balance Sheet. As of September 30, 2017, the net cash collateral received by the Company related to derivative instruments under its collateral security arrangements was $35 million, which was recorded as other current liabilities in the Consolidated Balance Sheet.

[0000320193-18-000145:notes:153]
Under master netting arrangements with the respective counterparties to the Company’s derivative contracts, the Company is allowed to net settle transactions with a single net amount payable by one party to the other. As of September 29, 2018 and September 30, 2017, the potential effects of these rights of set-off associated with the Company’s derivative contracts, including the effects of collateral, would be a reduction to both derivative assets and derivative liabilities of $2.1 billion and $1.4 billion, respectively, resulting in net derivative assets of $138 million and $32 million, respectively.

[0000320193-18-000145:notes:154]
Accounts Receivable

[0000320193-18-000145:notes:155]
Trade Receivables

[0000320193-18-000145:notes:156]
The Company has considerable trade receivables outstanding with its third-party cellular network carriers, wholesalers, retailers, resellers, small and mid-sized businesses and education, enterprise and government customers. The Company generally does not require collateral from its customers; however, the Company will require collateral or third-party credit support in certain instances to limit credit risk. In addition, when possible, the Company attempts to limit credit risk on trade receivables with credit insurance for certain customers or by requiring third-party financing, loans or leases to support credit exposure. These credit-financing arrangements are directly between the third-party financing company and the end customer. As such, the Company generally does not assume any recourse or credit risk sharing related to any of these arrangements.

[0000320193-18-000145:notes:157]
As of September 29, 2018, the Company had one customer that represented 10% or more of total trade receivables, which accounted for 10%. As of September 30, 2017, the Company had two customers that individually represented 10% or more of total trade receivables, each of which accounted for 10%. The Company’s cellular network carriers accounted for 59% of total trade receivables as of both September 29, 2018 and September 30, 2017.

[0000320193-18-000145:notes:158]
Vendor Non-Trade Receivables

[0000320193-18-000145:notes:159]
The Company has non-trade receivables from certain of its manufacturing vendors resulting from the sale of components to these vendors who manufacture sub-assemblies or assemble final products for the Company. The Company purchases these components directly from suppliers. As of September 29, 2018, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 62% and 12%. As of September 30, 2017, the Company had three vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 42%, 19% and 10%.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000320193-18-000145:notes:160]
Income Taxes

[0000320193-18-000145:notes:161]
U.S. Tax Cuts and Jobs Act

[0000320193-18-000145:notes:162]
On December 22, 2017, the U.S. enacted the Tax Cuts and Jobs Act (the “Act”), which significantly changed U.S. tax law. The Act lowered the Company’s U.S. statutory federal income tax rate from 35% to 21% effective January 1, 2018, while also imposing a deemed repatriation tax on previously deferred foreign income. The Act also created a new minimum tax on certain future foreign earnings. The impact of the Act increased the Company’s provision for income taxes by $1.5 billion during 2018. This increase was composed of $2.0 billion related to the remeasurement of net deferred tax assets and liabilities and $1.2 billion associated with the deemed repatriation tax, partially offset by a $1.7 billion impact the deemed repatriation tax had on the Company’s unrecognized tax benefits.

[0000320193-18-000145:notes:163]
Deferred Tax Balances

[0000320193-18-000145:notes:164]
As a result of the Act, the Company remeasured certain deferred tax assets and liabilities based on the revised rates at which they are expected to reverse, including items for which the related income tax effects were originally recognized in OCI. In addition, the Company elected to record certain deferred tax assets and liabilities related to the new minimum tax on certain future foreign earnings. Of the $2.0 billion recognized related to the remeasurement of net deferred tax assets and liabilities, $1.2 billion is a provisional estimate that incorporates assumptions based upon the most recent interpretations of the Act and may change as the Company continues to analyze the impact of additional implementation guidance. The Company’s provisional estimates are in accordance with the U.S. Securities and Exchange Commission Staff Accounting Bulletin No. 118.

[0000320193-18-000145:notes:165]
Deemed Repatriation Tax

[0000320193-18-000145:notes:166]
As of September 30, 2017, the Company had a U.S. deferred tax liability of $36.4 billion for deferred foreign income. During 2018, the Company replaced $36.1 billion of its U.S. deferred tax liability with a deemed repatriation tax payable of $37.3 billion, which was based on the Company’s cumulative post-1986 deferred foreign income. The deemed repatriation tax payable is a provisional estimate that may change as the Company continues to analyze the impact of additional implementation guidance. The Company plans to pay the tax in installments in accordance with the Act.

[0000320193-18-000145:notes:167]
Adoption of ASU No. 2018-02

[0000320193-18-000145:notes:168]
During the second quarter of 2018, the FASB issued ASU No. 2018-02, Income Statement – Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income (“ASU 2018-02”). ASU 2018-02 allows an entity to elect to reclassify the income tax effects of the Act on items within AOCI to retained earnings. The Company elected to apply the provision of ASU 2018-02 in 2018 with a reclassification of net tax benefits related to cumulative foreign currency translation and unrealized gains/losses on derivative instruments and marketable securities, resulting in a $278 million decrease in AOCI and a corresponding increase in retained earnings in the Consolidated Balance Sheet and Consolidated Statement of Shareholders’ Equity.

[0000320193-18-000145:notes:169]
Provision for Income Taxes and Effective Tax Rate

[0000320193-18-000145:notes:170]
The provision for income taxes for 2018, 2017 and 2016, consisted of the following (in millions):

[0000320193-18-000145:notes:171]
|  | 2018 |  | 2017 |  | 2016 |
| Federal: |  |  |  |  |  |
| Current | $ | 41,425 |  |  | $ | 7,842 |  |  | $ | 7,652 |  |
| Deferred | (33,819 | ) |  | 5,980 |  |  | 5,043 |  |
| Total | 7,606 |  |  | 13,822 |  |  | 12,695 |  |
| State: |  |  |  |  |  |
| Current | 551 |  |  | 259 |  |  | 990 |  |
| Deferred | 48 |  |  | 2 |  |  | (138 | ) |
| Total | 599 |  |  | 261 |  |  | 852 |  |
| Foreign: |  |  |  |  |  |
| Current | 3,986 |  |  | 1,671 |  |  | 2,105 |  |
| Deferred | 1,181 |  |  | (16 | ) |  | 33 |  |
| Total | 5,167 |  |  | 1,655 |  |  | 2,138 |  |
| Provision for income taxes | $ | 13,372 |  |  | $ | 15,738 |  |  | $ | 15,685 |  |

[0000320193-18-000145:notes:172]
The foreign provision for income taxes is based on foreign pre-tax earnings of $48.0 billion, $44.7 billion and $41.1 billion in 2018, 2017 and 2016, respectively.

[0000320193-18-000145:notes:173]
A reconciliation of the provision for income taxes, with the amount computed by applying the statutory federal income tax rate (24.5% in 2018; 35% in 2017 and 2016) to income before provision for income taxes for 2018, 2017 and 2016, is as follows (dollars in millions):

[0000320193-18-000145:notes:174]
|  | 2018 |  | 2017 |  | 2016 |
| Computed expected tax | $ | 17,890 |  |  | $ | 22,431 |  |  | $ | 21,480 |  |
| State taxes, net of federal effect | 271 |  |  | 185 |  |  | 553 |  |
| Impacts of the Act | 1,515 |  |  | — |  |  | — |  |
| Earnings of foreign subsidiaries | (5,606 | ) |  | (6,135 | ) |  | (5,582 | ) |
| Domestic production activities deduction | (195 | ) |  | (209 | ) |  | (382 | ) |
| Research and development credit, net | (560 | ) |  | (678 | ) |  | (371 | ) |
| Other | 57 |  |  | 144 |  |  | (13 | ) |
| Provision for income taxes | $ | 13,372 |  |  | $ | 15,738 |  |  | $ | 15,685 |  |
| Effective tax rate | 18.3 | % |  | 24.6 | % |  | 25.6 | % |

[0000320193-18-000145:notes:175]
The Company’s income taxes payable have been reduced by the tax benefits from employee stock plan awards. For restricted stock units (“RSUs”), the Company receives an income tax benefit upon the award’s vesting equal to the tax effect of the underlying stock’s fair market value. Prior to adopting ASU 2016-09 in the first quarter of 2018, the Company reflected net excess tax benefits from equity awards as increases to additional paid-in capital, which amounted to $620 million and $379 million in 2017 and 2016, respectively. Refer to Note 1, “Summary of Significant Accounting Policies” for more information.

[0000320193-18-000145:notes:176]
Deferred Tax Assets and Liabilities

[0000320193-18-000145:notes:177]
As of September 29, 2018 and September 30, 2017, the significant components of the Company’s deferred tax assets and liabilities were (in millions):

[0000320193-18-000145:notes:178]
|  | 2018 |  | 2017 |
| Deferred tax assets: |  |  |  |
| Accrued liabilities and other reserves | $ | 3,151 |  |  | $ | 4,019 |  |
| Basis of capital assets | 137 |  |  | 1,230 |  |
| Deferred revenue | 1,141 |  |  | 1,521 |  |
| Deferred cost sharing | — |  |  | 667 |  |
| Share-based compensation | 513 |  |  | 703 |  |
| Unrealized losses | 871 |  |  | — |  |
| Other | 797 |  |  | 834 |  |
| Total deferred tax assets | 6,610 |  |  | 8,974 |  |
| Deferred tax liabilities: |  |  |  |
| Earnings of foreign subsidiaries | 275 |  |  | 36,355 |  |
| Other | 501 |  |  | 207 |  |
| Total deferred tax liabilities | 776 |  |  | 36,562 |  |
| Net deferred tax assets/(liabilities) | $ | 5,834 |  |  | $ | (27,588 | ) |

[0000320193-18-000145:notes:179]
Deferred tax assets and liabilities reflect the effects of tax losses, credits and the future income tax effects of temporary differences between the consolidated financial statement carrying amounts of existing assets and liabilities and their respective tax bases and are measured using enacted tax rates that apply to taxable income in the years in which those temporary differences are expected to be recovered or settled.

[0000320193-18-000145:notes:180]
Uncertain Tax Positions

[0000320193-18-000145:notes:181]
As of September 29, 2018, the total amount of gross unrecognized tax benefits was $9.7 billion, of which $7.4 billion, if recognized, would impact the Company’s effective tax rate. As of September 30, 2017, the total amount of gross unrecognized tax benefits was $8.4 billion, of which $2.5 billion, if recognized, would have impacted the Company’s effective tax rate.

[0000320193-18-000145:notes:182]
The aggregate changes in the balance of gross unrecognized tax benefits, which excludes interest and penalties, for 2018, 2017 and 2016, is as follows (in millions):

[0000320193-18-000145:notes:183]
|  | 2018 |  | 2017 |  | 2016 |
| Beginning balances | $ | 8,407 |  |  | $ | 7,724 |  |  | $ | 6,900 |  |
| Increases related to tax positions taken during a prior year | 2,431 |  |  | 333 |  |  | 1,121 |  |
| Decreases related to tax positions taken during a prior year | (2,212 | ) |  | (952 | ) |  | (257 | ) |
| Increases related to tax positions taken during the current year | 1,824 |  |  | 1,880 |  |  | 1,578 |  |
| Decreases related to settlements with taxing authorities | (756 | ) |  | (539 | ) |  | (1,618 | ) |
| Decreases related to expiration of statute of limitations | — |  |  | (39 | ) |  | — |  |
| Ending balances | $ | 9,694 |  |  | $ | 8,407 |  |  | $ | 7,724 |  |

[0000320193-18-000145:notes:184]
The Company includes interest and penalties related to unrecognized tax benefits within the provision for income taxes. As of September 29, 2018 and September 30, 2017, the total amount of gross interest and penalties accrued was $1.4 billion and $1.2 billion, respectively. Both the unrecognized tax benefits and the associated interest and penalties that are not expected to result in payment or receipt of cash within one year are classified as other non-current liabilities in the Consolidated Balance Sheets. In connection with tax matters, the Company recognized interest and penalty expense in 2018, 2017 and 2016 of $236 million, $165 million and $295 million, respectively.

[0000320193-18-000145:notes:185]
The Company is subject to taxation and files income tax returns in the U.S. federal jurisdiction and in many state and foreign jurisdictions. The U.S. Internal Revenue Service (the “IRS”) concluded its review of the years 2013 through 2015 in 2018, and all years prior to 2016 are closed. Tax years subsequent to 2006 in certain major U.S. states and subsequent to 2007 in certain major foreign jurisdictions remain open, and could be subject to examination by the taxing authorities. The Company believes that an adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax audits cannot be predicted with certainty. If any issues addressed in the Company’s tax audits are resolved in a manner inconsistent with its expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. Although timing of resolution and/or closure of audits is not certain, the Company believes it is reasonably possible that its gross unrecognized tax benefits could decrease (either by payment, release or a combination of both) in the next 12 months by as much as $800 million.

[0000320193-18-000145:notes:186]
European Commission State Aid Decision

[0000320193-18-000145:notes:187]
On August 30, 2016, the European Commission announced its decision that Ireland granted state aid to the Company by providing tax opinions in 1991 and 2007 concerning the tax allocation of profits of the Irish branches of two subsidiaries of the Company (the “State Aid Decision”). The State Aid Decision ordered Ireland to calculate and recover additional taxes from the Company for the period June 2003 through December 2014. The recovery amount was calculated to be €13.1 billion, plus interest of €1.2 billion. Irish legislative changes, effective as of January 2015, eliminated the application of the tax opinions from that date forward. The Company believes the State Aid Decision to be without merit and appealed to the General Court of the Court of Justice of the European Union. Ireland has also appealed the State Aid Decision. The Company believes that any incremental Irish corporate income taxes potentially due related to the State Aid Decision would be creditable against U.S. taxes, subject to any foreign tax credit limitations in the Act. As of September 29, 2018, the entire recovery amount plus interest was funded into escrow, where it will remain restricted from general use pending conclusion of all appeals. Refer to Note 2, “Financial Instruments” for more information.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000320193-18-000145:notes:188]
Selected Quarterly Financial Information (Unaudited)

[0000320193-18-000145:notes:189]
The following tables show a summary of the Company’s quarterly financial information for each of the four quarters of 2018 and 2017 (in millions, except per share amounts):

[0000320193-18-000145:notes:190]
|  | Fourth Quarter |  | Third Quarter |  | Second Quarter |  | First Quarter |
| 2018: |  |  |  |  |  |  |  |
| Net sales | $ | 62,900 |  |  | $ | 53,265 |  |  | $ | 61,137 |  |  | $ | 88,293 |  |
| Gross margin | $ | 24,084 |  |  | $ | 20,421 |  |  | $ | 23,422 |  |  | $ | 33,912 |  |
| Net income | $ | 14,125 |  |  | $ | 11,519 |  |  | $ | 13,822 |  |  | $ | 20,065 |  |
| Earnings per share (1): |  |  |  |  |  |  |  |
| Basic | $ | 2.94 |  |  | $ | 2.36 |  |  | $ | 2.75 |  |  | $ | 3.92 |  |
| Diluted | $ | 2.91 |  |  | $ | 2.34 |  |  | $ | 2.73 |  |  | $ | 3.89 |  |

[0000320193-18-000145:notes:191]
|  | Fourth Quarter |  | Third Quarter |  | Second Quarter |  | First Quarter |
| 2017: |  |  |  |  |  |  |  |
| Net sales | $ | 52,579 |  |  | $ | 45,408 |  |  | $ | 52,896 |  |  | $ | 78,351 |  |
| Gross margin | $ | 19,931 |  |  | $ | 17,488 |  |  | $ | 20,591 |  |  | $ | 30,176 |  |
| Net income | $ | 10,714 |  |  | $ | 8,717 |  |  | $ | 11,029 |  |  | $ | 17,891 |  |
| Earnings per share (1): |  |  |  |  |  |  |  |
| Basic | $ | 2.08 |  |  | $ | 1.68 |  |  | $ | 2.11 |  |  | $ | 3.38 |  |
| Diluted | $ | 2.07 |  |  | $ | 1.67 |  |  | $ | 2.10 |  |  | $ | 3.36 |  |

[0000320193-18-000145:notes:192]
| (1) | Basic and diluted earnings per share are computed independently for each of the quarters presented. Therefore, the sum of quarterly basic and diluted per share information may not equal annual basic and diluted earnings per share. |


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0000320193-18-000145:notes:193]
A reconciliation of the Company’s segment operating income to the Consolidated Statements of Operations for 2018, 2017 and 2016 is as follows (in millions):

[0000320193-18-000145:notes:194]
|  | 2018 |  | 2017 |  | 2016 |
| Segment operating income | $ | 90,242 |  |  | $ | 77,631 |  |  | $ | 74,301 |  |
| Research and development expense | (14,236 | ) |  | (11,581 | ) |  | (10,045 | ) |
| Other corporate expenses, net | (5,108 | ) |  | (4,706 | ) |  | (4,232 | ) |
| Total operating income | $ | 70,898 |  |  | $ | 61,344 |  |  | $ | 60,024 |  |


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0000320193-18-000145:notes:195]
Net sales by product for 2018, 2017 and 2016 were as follows (in millions):

[0000320193-18-000145:notes:196]
|  | 2018 |  | 2017 |  | 2016 |
| iPhone (1) | $ | 166,699 |  |  | $ | 141,319 |  |  | $ | 136,700 |  |
| iPad (1) | 18,805 |  |  | 19,222 |  |  | 20,628 |  |
| Mac (1) | 25,484 |  |  | 25,850 |  |  | 22,831 |  |
| Services (2) | 37,190 |  |  | 29,980 |  |  | 24,348 |  |
| Other Products (1)(3) | 17,417 |  |  | 12,863 |  |  | 11,132 |  |
| Total net sales | $ | 265,595 |  |  | $ | 229,234 |  |  | $ | 215,639 |  |

[0000320193-18-000145:notes:197]
| (1) | Includes deferrals and amortization of related software upgrade rights and non-software services. |

[0000320193-18-000145:notes:198]
| (2) | Includes revenue from Digital Content and Services, AppleCare, Apple Pay, licensing and other services. Services net sales in 2018 included a favorable one-time item of $236 million in connection with the final resolution of various lawsuits. Services net sales in 2017 included a favorable one-time adjustment of $640 million due to a change in estimate based on the availability of additional supporting information. |

[0000320193-18-000145:notes:199]
| (3) | Includes sales of AirPods, Apple TV, Apple Watch, Beats products, HomePod, iPod touch and other Apple-branded and third-party accessories. |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0000320193-18-000145:notes:200]
Net sales for 2018, 2017 and 2016 and long-lived assets as of September 29, 2018 and September 30, 2017 were as follows (in millions):

[0000320193-18-000145:notes:201]
|  | 2018 |  | 2017 |  | 2016 |
| Net sales: |  |  |  |  |  |
| U.S. | $ | 98,061 |  |  | $ | 84,339 |  |  | $ | 75,667 |  |
| China (1) | 51,942 |  |  | 44,764 |  |  | 48,492 |  |
| Other countries | 115,592 |  |  | 100,131 |  |  | 91,480 |  |
| Total net sales | $ | 265,595 |  |  | $ | 229,234 |  |  | $ | 215,639 |  |

[0000320193-18-000145:notes:202]
|  | 2018 |  | 2017 |
| Long-lived assets: |  |  |  |
| U.S. | $ | 23,963 |  |  | $ | 20,637 |  |
| China (1) | 13,268 |  |  | 10,211 |  |
| Other countries | 4,073 |  |  | 2,935 |  |
| Total long-lived assets | $ | 41,304 |  |  | $ | 33,783 |  |

[0000320193-18-000145:notes:203]
| (1) | China includes Hong Kong and Taiwan. Long-lived assets located in China consist primarily of product tooling and manufacturing process equipment and assets related to retail stores and related infrastructure. |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000320193-18-000145:notes:204]
The following table shows information by reportable segment for 2018, 2017 and 2016 (in millions):

[0000320193-18-000145:notes:205]
|  | 2018 |  | 2017 |  | 2016 |
| Americas: |  |  |  |  |  |
| Net sales | $ | 112,093 |  |  | $ | 96,600 |  |  | $ | 86,613 |  |
| Operating income | $ | 34,864 |  |  | $ | 30,684 |  |  | $ | 28,172 |  |
| Europe: |  |  |  |  |  |
| Net sales | $ | 62,420 |  |  | $ | 54,938 |  |  | $ | 49,952 |  |
| Operating income | $ | 19,955 |  |  | $ | 16,514 |  |  | $ | 15,348 |  |
| Greater China: |  |  |  |  |  |
| Net sales | $ | 51,942 |  |  | $ | 44,764 |  |  | $ | 48,492 |  |
| Operating income | $ | 19,742 |  |  | $ | 17,032 |  |  | $ | 18,835 |  |
| Japan: |  |  |  |  |  |
| Net sales | $ | 21,733 |  |  | $ | 17,733 |  |  | $ | 16,928 |  |
| Operating income | $ | 9,500 |  |  | $ | 8,097 |  |  | $ | 7,165 |  |
| Rest of Asia Pacific: |  |  |  |  |  |
| Net sales | $ | 17,407 |  |  | $ | 15,199 |  |  | $ | 13,654 |  |
| Operating income | $ | 6,181 |  |  | $ | 5,304 |  |  | $ | 4,781 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000320193-18-000145:notes:206]
Segment Information and Geographic Data

[0000320193-18-000145:notes:207]
The Company reports segment information based on the “management” approach. The management approach designates the internal reporting used by management for making decisions and assessing performance as the source of the Company’s reportable segments.

[0000320193-18-000145:notes:208]
The Company manages its business primarily on a geographic basis. The Company’s reportable segments consist of the Americas, Europe, Greater China, Japan and Rest of Asia Pacific. Americas includes both North and South America. Europe includes European countries, as well as India, the Middle East and Africa. Greater China includes China, Hong Kong and Taiwan. Rest of Asia Pacific includes Australia and those Asian countries not included in the Company’s other reportable segments. Although the reportable segments provide similar hardware and software products and similar services, each one is managed separately to better align with the location of the Company’s customers and distribution partners and the unique market dynamics of each geographic region. The accounting policies of the various segments are the same as those described in Note 1, “Summary of Significant Accounting Policies.”

[0000320193-18-000145:notes:209]
The Company evaluates the performance of its reportable segments based on net sales and operating income. Net sales for geographic segments are generally based on the location of customers and sales through the Company’s retail stores located in those geographic locations. Operating income for each segment includes net sales to third parties, related cost of sales and operating expenses directly attributable to the segment. Advertising expenses are generally included in the geographic segment in which the expenditures are incurred. Operating income for each segment excludes other income and expense and certain expenses managed outside the reportable segments. Costs excluded from segment operating income include various corporate expenses such as research and development, corporate marketing expenses, certain share-based compensation expenses, income taxes, various nonrecurring charges and other separately managed general and administrative costs. The Company does not include intercompany transfers between segments for management reporting purposes.

[0000320193-18-000145:notes:210]
The U.S. and China were the only countries that accounted for more than 10% of the Company’s net sales in 2018, 2017 and 2016. There was no single customer that accounted for more than 10% of net sales in 2018, 2017 and 2016. Net sales for 2018, 2017 and 2016 and long-lived assets as of September 29, 2018 and September 30, 2017 were as follows (in millions):


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000320193-18-000145:notes:211]
Shareholders’ Equity

[0000320193-18-000145:notes:212]
Share Repurchase Program

[0000320193-18-000145:notes:213]
During 2018, the Company repurchased 405.5 million shares of its common stock for $73.1 billion in connection with two separate share repurchase programs. Of the $73.1 billion, $44.0 billion was repurchased under the Company’s previous share repurchase program of up to $210 billion, thereby completing that program. On May 1, 2018, the Company announced the Board of Directors had authorized a new program to repurchase up to $100 billion of the Company’s common stock. The remaining $29.0 billion repurchased during 2018 was in connection with the new share repurchase program. The Company’s new share repurchase program does not obligate it to acquire any specific number of shares. Under this program, shares may be repurchased in privately negotiated and/or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).
