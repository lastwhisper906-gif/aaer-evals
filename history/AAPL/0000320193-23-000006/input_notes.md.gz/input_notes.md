# AAPL notes — 0000320193-23-000006


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000320193-23-000006:notes:1]
[same as prior period, unchanged from 0000320193-22-000070:notes:1]

[0000320193-23-000006:notes:2]
The condensed consolidated financial statements include the accounts of Apple Inc. and its wholly owned subsidiaries (collectively “Apple” or the “Company”). Intercompany accounts and transactions have been eliminated. In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements and accompanying notes in conformity with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported. Actual results could differ materially from those estimates. Certain prior period amounts in the condensed consolidated financial statements and accompanying notes have been reclassified to conform to the current period’s presentation. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company’s annual consolidated financial statements and accompanying notes included in its Annual Report on Form 10-K for the fiscal year ended September 24, 2022.

[0000320193-23-000006:notes:3]
The Company’s fiscal year is the 52- or 53-week period that ends on the last Saturday of September. An additional week is included in the first fiscal quarter every five or six years to realign the Company’s fiscal quarters with calendar quarters, which occurred in the first fiscal quarter of 2023. The Company’s fiscal years 2023 and 2022 span 53 and 52 weeks, respectively. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in September and the associated quarters, months and periods of those fiscal years.

[0000320193-23-000006:notes:4]
[same as prior period, unchanged from 0000320193-22-000070:notes:4]

[0000320193-23-000006:notes:5]
The following table shows the computation of basic and diluted earnings per share for the three months ended December 31, 2022 and December 25, 2021 (net income in millions and shares in thousands):

[0000320193-23-000006:notes:6]
|  | Three Months Ended |  |  |
|  | December 31,2022 |  | December 25,2021 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 29,998 |  |  | $ | 34,630 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 15,892,723 |  |  | 16,391,724 |  |  |  |  |  |
| Effect of dilutive securities | 62,995 |  |  | 127,567 |  |  |  |  |  |
| Weighted-average diluted shares | 15,955,718 |  |  | 16,519,291 |  |  |  |  |  |
| Basic earnings per share | $ | 1.89 |  |  | $ | 2.11 |  |  |  |  |  |
| Diluted earnings per share | $ | 1.88 |  |  | $ | 2.10 |  |  |  |  |  |

[0000320193-23-000006:notes:7]
Approximately 89 million restricted stock units (“RSUs”) were excluded from the computation of diluted earnings per share for the three months ended December 31, 2022 because their effect would have been antidilutive.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000320193-23-000006:notes:8]
Revenue
Net sales disaggregated by significant products and services for the three months ended December 31, 2022 and December 25, 2021 were as follows (in millions):

[0000320193-23-000006:notes:9]
|  | Three Months Ended |  |  |
|  | December 31,2022 |  | December 25,2021 |  |  |  |  |
| iPhone® (1) | $ | 65,775 |  |  | $ | 71,628 |  |  |  |  |  |
| Mac® (1) | 7,735 |  |  | 10,852 |  |  |  |  |  |
| iPad® (1) | 9,396 |  |  | 7,248 |  |  |  |  |  |
| Wearables, Home and Accessories (1)(2) | 13,482 |  |  | 14,701 |  |  |  |  |  |
| Services (3) | 20,766 |  |  | 19,516 |  |  |  |  |  |
| Total net sales (4) | $ | 117,154 |  |  | $ | 123,945 |  |  |  |  |  |

[0000320193-23-000006:notes:10]
[same as prior period, unchanged from 0000320193-22-000070:notes:9]

[0000320193-23-000006:notes:11]
[same as prior period, unchanged from 0000320193-22-000070:notes:10]

[0000320193-23-000006:notes:12]
[same as prior period, unchanged from 0000320193-22-000070:notes:11]

[0000320193-23-000006:notes:13]
(4)Includes $3.4 billion of revenue recognized in the three months ended December 31, 2022 that was included in deferred revenue as of September 24, 2022 and $3.0 billion of revenue recognized in the three months ended December 25, 2021 that was included in deferred revenue as of September 25, 2021.

[0000320193-23-000006:notes:14]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 9, “Segment Information and Geographic Data” for the three months ended December 31, 2022 and December 25, 2021, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.

[0000320193-23-000006:notes:15]
As of December 31, 2022 and September 24, 2022, the Company had total deferred revenue of $12.6 billion and $12.4 billion, respectively. As of December 31, 2022, the Company expects 63% of total deferred revenue to be realized in less than a year, 27% within one-to-two years, 8% within two-to-three years and 2% in greater than three years.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000320193-23-000006:notes:16]
[same as prior period, unchanged from 0000320193-22-000070:notes:15]

[0000320193-23-000006:notes:17]
The following tables show the Company’s cash, cash equivalents and marketable securities by significant investment category as of December 31, 2022 and September 24, 2022 (in millions):

[0000320193-23-000006:notes:18]
|  | December 31, 2022 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | CurrentMarketableSecurities |  | Non-CurrentMarketableSecurities |
| Cash | $ | 17,908 |  |  | $ | — |  |  | $ | — |  |  | $ | 17,908 |  |  | $ | 17,908 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 818 |  |  | — |  |  | — |  |  | 818 |  |  | 818 |  |  | — |  |  | — |  |
| Mutual funds | 330 |  |  | 2 |  |  | (40) |  |  | 292 |  |  | — |  |  | 292 |  |  | — |  |
| Subtotal | 1,148 |  |  | 2 |  |  | (40) |  |  | 1,110 |  |  | 818 |  |  | 292 |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 24,128 |  |  | 1 |  |  | (1,576) |  |  | 22,553 |  |  | 13 |  |  | 9,105 |  |  | 13,435 |  |
| U.S. agency securities | 5,743 |  |  | — |  |  | (643) |  |  | 5,100 |  |  | — |  |  | 310 |  |  | 4,790 |  |
| Non-U.S. government securities | 17,778 |  |  | 14 |  |  | (1,029) |  |  | 16,763 |  |  | — |  |  | 9,907 |  |  | 6,856 |  |
| Certificates of deposit and time deposits | 2,025 |  |  | — |  |  | — |  |  | 2,025 |  |  | 1,795 |  |  | 230 |  |  | — |  |
| Commercial paper | 237 |  |  | — |  |  | — |  |  | 237 |  |  | — |  |  | 237 |  |  | — |  |
| Corporate debt securities | 85,895 |  |  | 14 |  |  | (7,039) |  |  | 78,870 |  |  | 1 |  |  | 10,377 |  |  | 68,492 |  |
| Municipal securities | 864 |  |  | — |  |  | (26) |  |  | 838 |  |  | — |  |  | 278 |  |  | 560 |  |
| Mortgage- and asset-backed securities | 22,448 |  |  | 3 |  |  | (2,405) |  |  | 20,046 |  |  | — |  |  | 84 |  |  | 19,962 |  |
| Subtotal | 159,118 |  |  | 32 |  |  | (12,718) |  |  | 146,432 |  |  | 1,809 |  |  | 30,528 |  |  | 114,095 |  |
| Total (3) | $ | 178,174 |  |  | $ | 34 |  |  | $ | (12,758) |  |  | $ | 165,450 |  |  | $ | 20,535 |  |  | $ | 30,820 |  |  | $ | 114,095 |  |

[0000320193-23-000006:notes:19]
|  | September 24, 2022 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | CurrentMarketableSecurities |  | Non-CurrentMarketableSecurities |
| Cash | $ | 18,546 |  |  | $ | — |  |  | $ | — |  |  | $ | 18,546 |  |  | $ | 18,546 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 2,929 |  |  | — |  |  | — |  |  | 2,929 |  |  | 2,929 |  |  | — |  |  | — |  |
| Mutual funds | 274 |  |  | — |  |  | (47) |  |  | 227 |  |  | — |  |  | 227 |  |  | — |  |
| Subtotal | 3,203 |  |  | — |  |  | (47) |  |  | 3,156 |  |  | 2,929 |  |  | 227 |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 25,134 |  |  | — |  |  | (1,725) |  |  | 23,409 |  |  | 338 |  |  | 5,091 |  |  | 17,980 |  |
| U.S. agency securities | 5,823 |  |  | — |  |  | (655) |  |  | 5,168 |  |  | — |  |  | 240 |  |  | 4,928 |  |
| Non-U.S. government securities | 16,948 |  |  | 2 |  |  | (1,201) |  |  | 15,749 |  |  | — |  |  | 8,806 |  |  | 6,943 |  |
| Certificates of deposit and time deposits | 2,067 |  |  | — |  |  | — |  |  | 2,067 |  |  | 1,805 |  |  | 262 |  |  | — |  |
| Commercial paper | 718 |  |  | — |  |  | — |  |  | 718 |  |  | 28 |  |  | 690 |  |  | — |  |
| Corporate debt securities | 87,148 |  |  | 9 |  |  | (7,707) |  |  | 79,450 |  |  | — |  |  | 9,023 |  |  | 70,427 |  |
| Municipal securities | 921 |  |  | — |  |  | (35) |  |  | 886 |  |  | — |  |  | 266 |  |  | 620 |  |
| Mortgage- and asset-backed securities | 22,553 |  |  | — |  |  | (2,593) |  |  | 19,960 |  |  | — |  |  | 53 |  |  | 19,907 |  |
| Subtotal | 161,312 |  |  | 11 |  |  | (13,916) |  |  | 147,407 |  |  | 2,171 |  |  | 24,431 |  |  | 120,805 |  |
| Total (3) | $ | 183,061 |  |  | $ | 11 |  |  | $ | (13,963) |  |  | $ | 169,109 |  |  | $ | 23,646 |  |  | $ | 24,658 |  |  | $ | 120,805 |  |

[0000320193-23-000006:notes:20]
[same as prior period, unchanged from 0000320193-22-000070:notes:19]

[0000320193-23-000006:notes:21]
[same as prior period, unchanged from 0000320193-22-000070:notes:20]

[0000320193-23-000006:notes:22]
(3)As of December 31, 2022 and September 24, 2022, total marketable securities included $13.6 billion and $12.7 billion, respectively, that were restricted from general use, related to the European Commission decision finding that Ireland granted state aid to the Company, and other agreements.

[0000320193-23-000006:notes:23]
The following table shows the fair value of the Company’s non-current marketable debt securities, by contractual maturity, as of December 31, 2022 (in millions):

[0000320193-23-000006:notes:24]
| Due after 1 year through 5 years | $ | 82,497 |  |
| Due after 5 years through 10 years | 14,243 |  |
| Due after 10 years | 17,355 |  |
| Total fair value | $ | 114,095 |  |

[0000320193-23-000006:notes:25]
[same as prior period, unchanged from 0000320193-22-000070:notes:24]

[0000320193-23-000006:notes:26]
[same as prior period, unchanged from 0000320193-22-000070:notes:25]

[0000320193-23-000006:notes:27]
[same as prior period, unchanged from 0000320193-22-000070:notes:26]

[0000320193-23-000006:notes:28]
[same as prior period, unchanged from 0000320193-22-000070:notes:27]

[0000320193-23-000006:notes:29]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in foreign currency exchange rates, the Company may enter into forward contracts, cross-currency swaps or other instruments. The Company designates these instruments as either cash flow or fair value hedges. As of December 31, 2022, the maximum length of time over which the Company is hedging its exposure to the variability in future cash flows for term debt–related foreign currency transactions is 20 years.

[0000320193-23-000006:notes:30]
[same as prior period, unchanged from 0000320193-22-000070:notes:29]

[0000320193-23-000006:notes:31]
[same as prior period, unchanged from 0000320193-22-000070:notes:30]

[0000320193-23-000006:notes:32]
[same as prior period, unchanged from 0000320193-22-000070:notes:31]

[0000320193-23-000006:notes:33]
The notional amounts of the Company’s outstanding derivative instruments as of December 31, 2022 and September 24, 2022 were as follows (in millions):

[0000320193-23-000006:notes:34]
|  | December 31,2022 |  | September 24,2022 |
| Derivative instruments designated as accounting hedges: |  |  |  |
| Foreign exchange contracts | $ | 66,054 |  |  | $ | 102,670 |  |
| Interest rate contracts | $ | 20,125 |  |  | $ | 20,125 |  |
| Derivative instruments not designated as accounting hedges: |  |  |  |
| Foreign exchange contracts | $ | 134,971 |  |  | $ | 185,381 |  |

[0000320193-23-000006:notes:35]
The gross fair values of the Company’s derivative assets and liabilities as of September 24, 2022 were as follows (in millions):

[0000320193-23-000006:notes:36]
|  | September 24, 2022 |
|  | Fair Value ofDerivatives Designatedas Accounting Hedges |  | Fair Value ofDerivatives Not Designatedas Accounting Hedges |  | TotalFair Value |
| Derivative assets (1): |  |  |  |  |  |
| Foreign exchange contracts | $ | 4,317 |  |  | $ | 2,819 |  |  | $ | 7,136 |  |
| Derivative liabilities (2): |  |  |  |  |  |
| Foreign exchange contracts | $ | 2,205 |  |  | $ | 2,547 |  |  | $ | 4,752 |  |
| Interest rate contracts | $ | 1,367 |  |  | $ | — |  |  | $ | 1,367 |  |

[0000320193-23-000006:notes:37]
(1)Derivative assets are measured using Level 2 fair value inputs and are included in other current assets and other non-current assets in the Condensed Consolidated Balance Sheet.

[0000320193-23-000006:notes:38]
(2)Derivative liabilities are measured using Level 2 fair value inputs and are included in other current liabilities and other non-current liabilities in the Condensed Consolidated Balance Sheet.

[0000320193-23-000006:notes:39]
The derivative assets above represent the Company’s gross credit exposure if all counterparties failed to perform. To mitigate credit risk, the Company generally enters into collateral security arrangements that provide for collateral to be received or posted when the net fair values of certain derivatives fluctuate from contractually established thresholds. To further limit credit risk, the Company generally enters into master netting arrangements with the respective counterparties to the Company’s derivative contracts, under which the Company is allowed to settle transactions with a single net amount payable by one party to the other. As of September 24, 2022, the potential effects of these rights of set-off associated with the Company’s derivative contracts, including the effects of collateral, would be a reduction to both derivative assets and derivative liabilities of $7.8 billion, resulting in a net derivative asset of $412 million.

[0000320193-23-000006:notes:40]
The carrying amounts of the Company’s hedged items in fair value hedges as of December 31, 2022 and September 24, 2022 were as follows (in millions):

[0000320193-23-000006:notes:41]
|  | December 31,2022 |  | September 24,2022 |
| Hedged assets/(liabilities): |  |  |  |
| Current and non-current marketable securities | $ | 14,311 |  |  | $ | 13,378 |  |
| Current and non-current term debt | $ | (18,731) |  |  | $ | (18,739) |  |

[0000320193-23-000006:notes:42]
[same as prior period, unchanged from 0000320193-22-000070:notes:39]

[0000320193-23-000006:notes:43]
[same as prior period, unchanged from 0000320193-22-000070:notes:40]

[0000320193-23-000006:notes:44]
[same as prior period, unchanged from 0000320193-22-000070:notes:41]

[0000320193-23-000006:notes:45]
As of both December 31, 2022 and September 24, 2022, the Company had one customer that represented 10% or more of total trade receivables, which accounted for 11% and 10%, respectively. The Company’s cellular network carriers accounted for 43% and 44% of total trade receivables as of December 31, 2022 and September 24, 2022, respectively.

[0000320193-23-000006:notes:46]
[same as prior period, unchanged from 0000320193-22-000070:notes:43]

[0000320193-23-000006:notes:47]
The Company has non-trade receivables from certain of its manufacturing vendors resulting from the sale of components to these vendors who manufacture subassemblies or assemble final products for the Company. The Company purchases these components directly from suppliers. As of December 31, 2022, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 54% and 16%. As of September 24, 2022, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 54% and 13%.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000320193-23-000006:notes:48]
[same as prior period, unchanged from 0000320193-22-000070:notes:45]


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000320193-23-000006:notes:49]
Condensed Consolidated Financial Statement Details
The following tables show the Company’s condensed consolidated financial statement details as of December 31, 2022 and September 24, 2022 (in millions):

[0000320193-23-000006:notes:50]
Inventories

[0000320193-23-000006:notes:51]
|  | December 31,2022 |  | September 24,2022 |
| Components | $ | 2,513 |  |  | $ | 1,637 |  |
| Finished goods | 4,307 |  |  | 3,309 |  |
| Total inventories | $ | 6,820 |  |  | $ | 4,946 |  |

[0000320193-23-000006:notes:52]
[same as prior period, unchanged from 0000320193-22-000070:notes:47]

[0000320193-23-000006:notes:53]
|  | December 31,2022 |  | September 24,2022 |
| Gross property, plant and equipment | $ | 110,995 |  |  | $ | 114,457 |  |
| Accumulated depreciation and amortization | (68,044) |  |  | (72,340) |  |
| Total property, plant and equipment, net | $ | 42,951 |  |  | $ | 42,117 |  |

[0000320193-23-000006:notes:54]
[same as prior period, unchanged from 0000320193-22-000070:notes:51]

[0000320193-23-000006:notes:55]
The following table shows the detail of other income/(expense), net for the three months ended December 31, 2022 and December 25, 2021 (in millions):

[0000320193-23-000006:notes:56]
|  | Three Months Ended |  |  |
|  | December 31,2022 |  | December 25,2021 |  |  |  |  |
| Interest and dividend income | $ | 868 |  |  | $ | 650 |  |  |  |  |  |
| Interest expense | (1,003) |  |  | (694) |  |  |  |  |  |
| Other expense, net | (258) |  |  | (203) |  |  |  |  |  |
| Total other income/(expense), net | $ | (393) |  |  | $ | (247) |  |  |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0000320193-23-000006:notes:57]
Debt
Commercial Paper

[0000320193-23-000006:notes:58]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of December 31, 2022 and September 24, 2022, the Company had $1.7 billion and $10.0 billion of Commercial Paper outstanding, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the three months ended December 31, 2022 and December 25, 2021 (in millions):

[0000320193-23-000006:notes:59]
|  | Three Months Ended |
|  | December 31,2022 |  | December 25,2021 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | (5,569) |  |  | $ | 1,339 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | — |  |  | 1,191 |  |
| Repayments of commercial paper | (2,645) |  |  | (3,530) |  |
| Repayments of commercial paper, net | (2,645) |  |  | (2,339) |  |
| Total repayments of commercial paper, net | $ | (8,214) |  |  | $ | (1,000) |  |

[0000320193-23-000006:notes:60]
Term Debt

[0000320193-23-000006:notes:61]
As of December 31, 2022 and September 24, 2022, the Company had outstanding fixed-rate notes with varying maturities for an aggregate carrying amount of $109.4 billion and $110.1 billion, respectively (collectively the “Notes”). As of December 31, 2022 and September 24, 2022, the fair value of the Company’s Notes, based on Level 2 inputs, was $98.0 billion and $98.8 billion, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000320193-23-000006:notes:62]
[same as prior period, unchanged from 0000320193-22-000070:notes:59]

[0000320193-23-000006:notes:63]
During the three months ended December 31, 2022, the Company repurchased 133 million shares of its common stock for $19.0 billion under a share repurchase program authorized by the Board of Directors (the “Program”). The Program does not obligate the Company to acquire a minimum amount of shares. Under the Program, shares may be repurchased in privately negotiated and/or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000320193-23-000006:notes:64]
[same as prior period, unchanged from 0000320193-22-000070:notes:61]

[0000320193-23-000006:notes:65]
A summary of the Company’s RSU activity and related information for the three months ended December 31, 2022 is as follows:

[0000320193-23-000006:notes:66]
|  | Number ofRSUs(in thousands) |  | Weighted-AverageGrant Date FairValue Per RSU |  | AggregateFair Value(in millions) |
| Balance as of September 24, 2022 | 201,501 |  |  | $ | 109.48 |  |  |  |
| RSUs granted | 82,123 |  |  | $ | 149.85 |  |  |  |
| RSUs vested | (47,298) |  |  | $ | 84.46 |  |  |  |
| RSUs canceled | (2,958) |  |  | $ | 120.26 |  |  |  |
| Balance as of December 31, 2022 | 233,368 |  |  | $ | 128.62 |  |  | $ | 30,322 |  |

[0000320193-23-000006:notes:67]
The fair value as of the respective vesting dates of RSUs was $6.8 billion and $8.5 billion for the three months ended December 31, 2022 and December 25, 2021, respectively.

[0000320193-23-000006:notes:68]
[same as prior period, unchanged from 0000320193-22-000070:notes:65]

[0000320193-23-000006:notes:69]
The following table shows share-based compensation expense and the related income tax benefit included in the Condensed Consolidated Statements of Operations for the three months ended December 31, 2022 and December 25, 2021 (in millions):

[0000320193-23-000006:notes:70]
|  | Three Months Ended |  |  |
|  | December 31,2022 |  | December 25,2021 |  |  |  |  |
| Share-based compensation expense | $ | 2,905 |  |  | $ | 2,265 |  |  |  |  |  |
| Income tax benefit related to share-based compensation expense | $ | (1,178) |  |  | $ | (1,536) |  |  |  |  |  |

[0000320193-23-000006:notes:71]
As of December 31, 2022, the total unrecognized compensation cost related to outstanding RSUs and stock options was $25.5 billion, which the Company expects to recognize over a weighted-average period of 3.0 years.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000320193-23-000006:notes:72]
Contingencies
Unconditional Purchase Obligations

[0000320193-23-000006:notes:73]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of supplier arrangements, licensed content and distribution rights. Future payments under noncancelable unconditional purchase obligations with a remaining term in excess of one year as of December 31, 2022, are as follows (in millions):

[0000320193-23-000006:notes:74]
| 2023 (remaining nine months) | $ | 2,899 |  |
| 2024 | 2,897 |  |
| 2025 | 1,584 |  |
| 2026 | 6,554 |  |
| 2027 | 348 |  |
| Thereafter | 444 |  |
| Total | $ | 14,726 |  |

[0000320193-23-000006:notes:75]
Contingencies

[0000320193-23-000006:notes:76]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully resolved. The outcome of litigation is inherently uncertain. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss greater than a recorded accrual, concerning loss contingencies for asserted legal and other claims.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000320193-23-000006:notes:77]
Segment Information and Geographic Data
The following table shows information by reportable segment for the three months ended December 31, 2022 and December 25, 2021 (in millions):

[0000320193-23-000006:notes:78]
|  | Three Months Ended |  |  |
|  | December 31,2022 |  | December 25,2021 |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |
| Net sales | $ | 49,278 |  |  | $ | 51,496 |  |  |  |  |  |
| Operating income | $ | 17,864 |  |  | $ | 19,585 |  |  |  |  |  |
| Europe: |  |  |  |  |  |  |  |
| Net sales | $ | 27,681 |  |  | $ | 29,749 |  |  |  |  |  |
| Operating income | $ | 10,017 |  |  | $ | 11,545 |  |  |  |  |  |
| Greater China: |  |  |  |  |  |  |  |
| Net sales | $ | 23,905 |  |  | $ | 25,783 |  |  |  |  |  |
| Operating income | $ | 10,437 |  |  | $ | 11,183 |  |  |  |  |  |
| Japan: |  |  |  |  |  |  |  |
| Net sales | $ | 6,755 |  |  | $ | 7,107 |  |  |  |  |  |
| Operating income | $ | 3,236 |  |  | $ | 3,349 |  |  |  |  |  |
| Rest of Asia Pacific: |  |  |  |  |  |  |  |
| Net sales | $ | 9,535 |  |  | $ | 9,810 |  |  |  |  |  |
| Operating income | $ | 3,851 |  |  | $ | 3,995 |  |  |  |  |  |

[0000320193-23-000006:notes:79]
A reconciliation of the Company’s segment operating income to the Condensed Consolidated Statements of Operations for the three months ended December 31, 2022 and December 25, 2021 is as follows (in millions):

[0000320193-23-000006:notes:80]
|  | Three Months Ended |  |  |
|  | December 31,2022 |  | December 25,2021 |  |  |  |  |
| Segment operating income | $ | 45,405 |  |  | $ | 49,657 |  |  |  |  |  |
| Research and development expense | (7,709) |  |  | (6,306) |  |  |  |  |  |
| Other corporate expenses, net | (1,680) |  |  | (1,863) |  |  |  |  |  |
| Total operating income | $ | 36,016 |  |  | $ | 41,488 |  |  |  |  |  |
