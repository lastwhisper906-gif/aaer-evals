# AAPL MD&A — 0000320193-23-000006


## mdna

[0000320193-23-000006:mdna:1]
[same as prior period, unchanged from 0000320193-22-000070:mdna:1]

[0000320193-23-000006:mdna:2]
[same as prior period, unchanged from 0000320193-22-000070:mdna:2]

[0000320193-23-000006:mdna:3]
The following discussion should be read in conjunction with the 2022 Form 10-K filed with the U.S. Securities and Exchange Commission (the “SEC”) and the condensed consolidated financial statements and accompanying notes included in Part I, Item 1 of this Form 10-Q.

[0000320193-23-000006:mdna:4]
[same as prior period, unchanged from 0000320193-22-000070:mdna:4]

[0000320193-23-000006:mdna:5]
The Company periodically provides certain information for investors on its corporate website, www.apple.com, and its investor relations website, investor.apple.com. This includes press releases and other information about financial performance, information on environmental, social and governance matters, and details related to the Company’s annual meeting of shareholders. The information contained on the websites referenced in this Form 10-Q is not incorporated by reference into this filing. Further, the Company’s references to website URLs are intended to be inactive textual references only.

[0000320193-23-000006:mdna:6]
[same as prior period, unchanged from 0000320193-22-000070:mdna:6]

[0000320193-23-000006:mdna:7]
[same as prior period, unchanged from 0000320193-22-000070:mdna:7]

[0000320193-23-000006:mdna:8]
Fiscal Period

[0000320193-23-000006:mdna:9]
The Company’s fiscal year is the 52- or 53-week period that ends on the last Saturday of September. An additional week is included in the first fiscal quarter every five or six years to realign the Company’s fiscal quarters with calendar quarters, which occurred in the first quarter of 2023. The Company’s fiscal years 2023 and 2022 span 53 and 52 weeks, respectively.

[0000320193-23-000006:mdna:10]
[same as prior period, unchanged from 0000320193-22-000070:mdna:8]

[0000320193-23-000006:mdna:11]
Total net sales decreased 5% or $6.8 billion during the first quarter of 2023 compared to the same quarter in 2022 due to the weakness in foreign currencies relative to the U.S. dollar. The weakness in foreign currencies contributed to lower net sales of iPhone and Mac, which was partially offset by higher net sales of iPad.

[0000320193-23-000006:mdna:12]
During the first quarter of 2023, the Company announced a new iPad, a new iPad Pro® powered by the Apple M2 chip, and a new Apple TV 4K.

[0000320193-23-000006:mdna:13]
The Company repurchased $19.0 billion of its common stock and paid dividends and dividend equivalents of $3.8 billion during the first quarter of 2023.

[0000320193-23-000006:mdna:14]
[same as prior period, unchanged from 0000320193-22-000070:mdna:12]

[0000320193-23-000006:mdna:15]
[same as prior period, unchanged from 0000320193-22-000070:mdna:13]

[0000320193-23-000006:mdna:16]
Certain of the Company’s outsourcing partners, component suppliers and logistical service providers have experienced, and could in the future experience, disruptions related to the COVID-19 pandemic, resulting in supply shortages. During the first quarter of 2023, COVID-related impacts temporarily affected the Company’s primary iPhone 14 Pro and iPhone 14 Pro Max assembly facility located in Zhengzhou, China. The facility operated at significantly reduced capacity, impacting iPhone 14 Pro and iPhone Pro Max shipments.

[0000320193-23-000006:mdna:17]
Macroeconomic Conditions

[0000320193-23-000006:mdna:18]
Macroeconomic conditions, including inflation, rising interest rates and currency fluctuations, have direct and indirect impacts on the Company’s business. The Company believes these factors have impacted, and could in the future materially impact, the Company’s results of operations and financial condition.

[0000320193-23-000006:mdna:19]
[same as prior period, unchanged from 0000320193-22-000070:mdna:31]

[0000320193-23-000006:mdna:20]
[same as prior period, unchanged from 0000320193-22-000070:mdna:32]

[0000320193-23-000006:mdna:21]
The following table shows net sales by reportable segment for the three months ended December 31, 2022 and December 25, 2021 (dollars in millions):

[0000320193-23-000006:mdna:22]
|  | Three Months Ended |  |  |
|  | December 31,2022 |  | December 25,2021 |  | Change |  |  |  |  |  |  |
| Net sales by reportable segment: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 49,278 |  |  | $ | 51,496 |  |  | (4) | % |  |  |  |  |  |  |
| Europe | 27,681 |  |  | 29,749 |  |  | (7) | % |  |  |  |  |  |  |
| Greater China | 23,905 |  |  | 25,783 |  |  | (7) | % |  |  |  |  |  |  |
| Japan | 6,755 |  |  | 7,107 |  |  | (5) | % |  |  |  |  |  |  |
| Rest of Asia Pacific | 9,535 |  |  | 9,810 |  |  | (3) | % |  |  |  |  |  |  |
| Total net sales | $ | 117,154 |  |  | $ | 123,945 |  |  | (5) | % |  |  |  |  |  |  |

[0000320193-23-000006:mdna:23]
[same as prior period, unchanged from 0000320193-22-000070:mdna:35]

[0000320193-23-000006:mdna:24]
Americas net sales decreased during the first quarter of 2023 compared to the same quarter in 2022 due primarily to lower net sales of iPhone and Mac, partially offset by higher net sales of Services and iPad. The weakness of the Canadian dollar relative to the U.S. dollar had an unfavorable year-over-year impact on Americas net sales during the first quarter of 2023.

[0000320193-23-000006:mdna:25]
[same as prior period, unchanged from 0000320193-22-000070:mdna:37]

[0000320193-23-000006:mdna:26]
Europe net sales decreased during the first quarter of 2023 compared to the same quarter in 2022 due to the weakness in foreign currencies relative to the U.S. dollar, which contributed to lower net sales of iPhone and Mac.

[0000320193-23-000006:mdna:27]
[same as prior period, unchanged from 0000320193-22-000070:mdna:39]

[0000320193-23-000006:mdna:28]
Greater China net sales decreased during the first quarter of 2023 compared to the same quarter in 2022 due to the weakness of the renminbi relative to the U.S. dollar. The weakness of the renminbi contributed to lower net sales of iPhone, which was partially offset by higher net sales of iPad.

[0000320193-23-000006:mdna:29]
[same as prior period, unchanged from 0000320193-22-000070:mdna:41]

[0000320193-23-000006:mdna:30]
Japan net sales decreased during the first quarter of 2023 compared to the same quarter in 2022 due to the weakness of the yen relative to the U.S. dollar, which contributed to lower net sales of Services and Mac.

[0000320193-23-000006:mdna:31]
[same as prior period, unchanged from 0000320193-22-000070:mdna:43]

[0000320193-23-000006:mdna:32]
Rest of Asia Pacific net sales decreased during the first quarter of 2023 compared to the same quarter in 2022 due to the weakness in foreign currencies relative to the U.S. dollar. The weakness in foreign currencies contributed to lower net sales of iPhone and Mac, which was partially offset by higher net sales of Services and iPad.

[0000320193-23-000006:mdna:33]
[same as prior period, unchanged from 0000320193-22-000070:mdna:15]

[0000320193-23-000006:mdna:34]
The following table shows net sales by category for the three months ended December 31, 2022 and December 25, 2021 (dollars in millions):

[0000320193-23-000006:mdna:35]
|  | Three Months Ended |  |  |
|  | December 31,2022 |  | December 25,2021 |  | Change |  |  |  |  |  |  |
| Net sales by category: |  |  |  |  |  |  |  |  |  |  |  |
| iPhone (1) | $ | 65,775 |  |  | $ | 71,628 |  |  | (8) | % |  |  |  |  |  |  |
| Mac (1) | 7,735 |  |  | 10,852 |  |  | (29) | % |  |  |  |  |  |  |
| iPad (1) | 9,396 |  |  | 7,248 |  |  | 30 | % |  |  |  |  |  |  |
| Wearables, Home and Accessories (1)(2) | 13,482 |  |  | 14,701 |  |  | (8) | % |  |  |  |  |  |  |
| Services (3) | 20,766 |  |  | 19,516 |  |  | 6 | % |  |  |  |  |  |  |
| Total net sales | $ | 117,154 |  |  | $ | 123,945 |  |  | (5) | % |  |  |  |  |  |  |

[0000320193-23-000006:mdna:36]
[same as prior period, unchanged from 0000320193-22-000070:mdna:18]

[0000320193-23-000006:mdna:37]
[same as prior period, unchanged from 0000320193-22-000070:mdna:19]

[0000320193-23-000006:mdna:38]
[same as prior period, unchanged from 0000320193-22-000070:mdna:20]

[0000320193-23-000006:mdna:39]
[same as prior period, unchanged from 0000320193-22-000070:mdna:21]

[0000320193-23-000006:mdna:40]
iPhone net sales decreased during the first quarter of 2023 compared to the same quarter in 2022 due primarily to lower net sales from the Company’s new iPhone models launched in the fourth quarter of 2022.

[0000320193-23-000006:mdna:41]
[same as prior period, unchanged from 0000320193-22-000070:mdna:23]

[0000320193-23-000006:mdna:42]
Mac net sales decreased during the first quarter of 2023 compared to the same quarter in 2022 due primarily to lower net sales of MacBook Pro®.

[0000320193-23-000006:mdna:43]
[same as prior period, unchanged from 0000320193-22-000070:mdna:25]

[0000320193-23-000006:mdna:44]
iPad net sales increased during the first quarter of 2023 compared to the same quarter in 2022 due primarily to higher net sales of iPad and iPad Air®.

[0000320193-23-000006:mdna:45]
[same as prior period, unchanged from 0000320193-22-000070:mdna:27]

[0000320193-23-000006:mdna:46]
Wearables, Home and Accessories net sales decreased during the first quarter of 2023 compared to the same quarter in 2022 due primarily to lower net sales of AirPods, partially offset by higher net sales of Watch.

[0000320193-23-000006:mdna:47]
[same as prior period, unchanged from 0000320193-22-000070:mdna:29]

[0000320193-23-000006:mdna:48]
Services net sales increased during the first quarter of 2023 compared to the same quarter in 2022 due primarily to higher net sales from cloud services, the App Store® and music.

[0000320193-23-000006:mdna:49]
[same as prior period, unchanged from 0000320193-22-000070:mdna:45]

[0000320193-23-000006:mdna:50]
Products and Services gross margin and gross margin percentage for the three months ended December 31, 2022 and December 25, 2021 were as follows (dollars in millions):

[0000320193-23-000006:mdna:51]
|  | Three Months Ended |  |  |
|  | December 31,2022 |  | December 25,2021 |  |  |  |  |
| Gross margin: |  |  |  |  |  |  |  |
| Products | $ | 35,623 |  |  | $ | 40,120 |  |  |  |  |  |
| Services | 14,709 |  |  | 14,123 |  |  |  |  |  |
| Total gross margin | $ | 50,332 |  |  | $ | 54,243 |  |  |  |  |  |

[0000320193-23-000006:mdna:52]
| Gross margin percentage: |  |  |  |  |  |  |  |
| Products | 37.0 | % |  | 38.4 | % |  |  |  |  |
| Services | 70.8 | % |  | 72.4 | % |  |  |  |  |
| Total gross margin percentage | 43.0 | % |  | 43.8 | % |  |  |  |  |

[0000320193-23-000006:mdna:53]
[same as prior period, unchanged from 0000320193-22-000070:mdna:49]

[0000320193-23-000006:mdna:54]
Products gross margin decreased during the first quarter of 2023 compared to the same quarter in 2022 due primarily to the weakness in foreign currencies relative to the U.S. dollar and lower Products volume.

[0000320193-23-000006:mdna:55]
Products gross margin percentage decreased during the first quarter of 2023 compared to the same quarter in 2022 due primarily to the weakness in foreign currencies relative to the U.S. dollar.

[0000320193-23-000006:mdna:56]
[same as prior period, unchanged from 0000320193-22-000070:mdna:52]

[0000320193-23-000006:mdna:57]
Services gross margin increased during the first quarter of 2023 compared to the same quarter in 2022 due primarily to higher Services net sales, partially offset by the weakness in foreign currencies relative to the U.S. dollar.

[0000320193-23-000006:mdna:58]
Services gross margin percentage decreased during the first quarter of 2023 compared to the same quarter in 2022 due primarily to the weakness in foreign currencies relative to the U.S. dollar and higher Services costs, partially offset by improved leverage.

[0000320193-23-000006:mdna:59]
The Company’s future gross margins can be impacted by a variety of factors, as discussed in Part I, Item 1A of the 2022 Form 10-K under the heading “Risk Factors.” As a result, the Company believes, in general, gross margins will be subject to volatility and downward pressure.

[0000320193-23-000006:mdna:60]
[same as prior period, unchanged from 0000320193-22-000070:mdna:56]

[0000320193-23-000006:mdna:61]
Operating expenses for the three months ended December 31, 2022 and December 25, 2021 were as follows (dollars in millions):

[0000320193-23-000006:mdna:62]
|  | Three Months Ended |  |  |
|  | December 31,2022 |  | December 25,2021 |  |  |  |  |
| Research and development | $ | 7,709 |  |  | $ | 6,306 |  |  |  |  |  |
| Percentage of total net sales | 7 | % |  | 5 | % |  |  |  |  |
| Selling, general and administrative | $ | 6,607 |  |  | $ | 6,449 |  |  |  |  |  |
| Percentage of total net sales | 6 | % |  | 5 | % |  |  |  |  |
| Total operating expenses | $ | 14,316 |  |  | $ | 12,755 |  |  |  |  |  |
| Percentage of total net sales | 12 | % |  | 10 | % |  |  |  |  |

[0000320193-23-000006:mdna:63]
[same as prior period, unchanged from 0000320193-22-000070:mdna:59]

[0000320193-23-000006:mdna:64]
The growth in research and development (“R&D”) expense during the first quarter of 2023 compared to the same quarter in 2022 was driven primarily by increases in headcount-related expenses.

[0000320193-23-000006:mdna:65]
[same as prior period, unchanged from 0000320193-22-000070:mdna:61]

[0000320193-23-000006:mdna:66]
The growth in selling, general and administrative expense during the first quarter of 2023 compared to the same quarter in 2022 was driven primarily by increases in headcount-related expenses.

[0000320193-23-000006:mdna:67]
[same as prior period, unchanged from 0000320193-22-000070:mdna:67]

[0000320193-23-000006:mdna:68]
Provision for income taxes, effective tax rate and statutory federal income tax rate for the three months ended December 31, 2022 and December 25, 2021 were as follows (dollars in millions):

[0000320193-23-000006:mdna:69]
|  | Three Months Ended |  |  |
|  | December 31,2022 |  | December 25,2021 |  |  |  |  |
| Provision for income taxes | $ | 5,625 |  |  | $ | 6,611 |  |  |  |  |  |
| Effective tax rate | 15.8 | % |  | 16.0 | % |  |  |  |  |
| Statutory federal income tax rate | 21 | % |  | 21 | % |  |  |  |  |

[0000320193-23-000006:mdna:70]
The Company’s effective tax rate for the first quarter of 2023 was lower than the statutory federal income tax rate due primarily to a lower effective tax rate on foreign earnings, tax benefits from share-based compensation, and the U.S. federal R&D credit, partially offset by state income taxes.

[0000320193-23-000006:mdna:71]
The Company’s effective tax rate for the first quarter of 2023 was lower compared to the same quarter in 2022 due primarily to a higher U.S. federal R&D credit, lower state income taxes and a lower effective tax rate on foreign earnings, largely offset by lower tax benefits from share-based compensation.

[0000320193-23-000006:mdna:72]
[same as prior period, unchanged from 0000320193-22-000070:mdna:72]

[0000320193-23-000006:mdna:73]
[same as prior period, unchanged from 0000320193-22-000070:mdna:73]

[0000320193-23-000006:mdna:74]
The Company’s contractual cash requirements have not changed materially since the 2022 Form 10-K, except for commercial paper and manufacturing purchase obligations.

[0000320193-23-000006:mdna:75]
Commercial Paper

[0000320193-23-000006:mdna:76]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. As of December 31, 2022, the Company had $1.7 billion of Commercial Paper outstanding, all of which was payable within 12 months.

[0000320193-23-000006:mdna:77]
[same as prior period, unchanged from 0000320193-22-000070:mdna:75]

[0000320193-23-000006:mdna:78]
The Company utilizes several outsourcing partners to manufacture subassemblies for the Company’s products and to perform final assembly and testing of finished products. The Company also obtains individual components for its products from a wide variety of individual suppliers. Outsourcing partners acquire components and build product based on demand information supplied by the Company, which typically covers periods up to 150 days. As of December 31, 2022, the Company had manufacturing purchase obligations of $55.1 billion, with $54.8 billion payable within 12 months. The Company’s manufacturing purchase obligations are primarily noncancelable.

[0000320193-23-000006:mdna:79]
In addition to its contractual cash requirements, the Company has a capital return program authorized by the Board of Directors. The share repurchase program (the “Program”) does not obligate the Company to acquire a minimum amount of shares. As of December 31, 2022, the Company’s quarterly cash dividend was $0.23 per share. The Company intends to increase its dividend on an annual basis, subject to declaration by the Board of Directors.

[0000320193-23-000006:mdna:80]
[same as prior period, unchanged from 0000320193-22-000070:mdna:78]

[0000320193-23-000006:mdna:81]
The preparation of financial statements and related disclosures in conformity with U.S. generally accepted accounting principles and the Company’s discussion and analysis of its financial condition and operating results require the Company’s management to make judgments, assumptions and estimates that affect the amounts reported. Note 1, “Summary of Significant Accounting Policies” of the Notes to condensed consolidated Financial Statements in Part I, Item 1 of this Form 10-Q and in the Notes to Consolidated Financial Statements in Part II, Item 8 of the 2022 Form 10-K describe the significant accounting policies and methods used in the preparation of the Company’s condensed consolidated financial statements. There have been no material changes to the Company’s critical accounting estimates since the 2022 Form 10-K.
