# AAPL note change history — 0000320193-22-000070 → 0000320193-23-000006


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2023-02-03):
[0000320193-23-000006:note_history:1]
Contingencies
Unconditional Purchase Obligations

- added (2023-02-03):
[0000320193-23-000006:note_history:2]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of supplier arrangements, licensed content and distribution rights. Future payments under noncancelable unconditional purchase obligations with a remaining term in excess of one year as of December 31, 2022, are as follows (in millions):

- added (2023-02-03):
[0000320193-23-000006:note_history:3]
| 2023 (remaining nine months) | $ | 2,899 |  |
| 2024 | 2,897 |  |
| 2025 | 1,584 |  |
| 2026 | 6,554 |  |
| 2027 | 348 |  |
| Thereafter | 444 |  |
| Total | $ | 14,726 |  |

- removed (2023-02-03):
[0000320193-22-000070:note_history:4]
Commitments and Contingencies
Accrued Warranty

- removed (2023-02-03):
[0000320193-22-000070:note_history:5]
The following table shows changes in the Company’s accrued warranties and related costs for the three- and nine-month periods ended June 25, 2022 and June 26, 2021 (in millions):

- removed (2023-02-03):
[0000320193-22-000070:note_history:6]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25,2022 |  | June 26,2021 |  | June 25,2022 |  | June 26,2021 |
| Beginning accrued warranty and related costs | $ | 3,206 |  |  | $ | 3,784 |  |  | $ | 3,364 |  |  | $ | 3,354 |  |
| Cost of warranty claims | (534) |  |  | (636) |  |  | (1,787) |  |  | (2,008) |  |
| Accruals for product warranty | 177 |  |  | 384 |  |  | 1,272 |  |  | 2,186 |  |
| Ending accrued warranty and related costs | $ | 2,849 |  |  | $ | 3,532 |  |  | $ | 2,849 |  |  | $ | 3,532 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2023-02-03):
[0000320193-23-000006:note_history:7]
The Company’s fiscal year is the 52- or 53-week period that ends on the last Saturday of September. An additional week is included in the first fiscal quarter every five or six years to realign the Company’s fiscal quarters with calendar quarters, which occurred in the first fiscal quarter of 2023. The Company’s fiscal years 2023 and 2022 span 53 and 52 weeks, respectively. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in September and the associated quarters, months and periods of those fiscal years.

- changed (2023-02-03):
[0000320193-23-000006:note_history:8]
The following table shows the computation of basic and diluted earnings per share for the three months ended December 31, 2022 and December 25, 2021 (net income in millions and shares in thousands):
  (was, 2022-07-29, similarity 0.9039):
[0000320193-22-000070:note_history:8]
The following table shows the computation of basic and diluted earnings per share for the three- and nine-month periods ended June 25, 2022 and June 26, 2021 (net income in millions and shares in thousands):

- added (2023-02-03):
[0000320193-23-000006:note_history:9]
|  | Three Months Ended |  |  |
|  | December 31,2022 |  | December 25,2021 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 29,998 |  |  | $ | 34,630 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 15,892,723 |  |  | 16,391,724 |  |  |  |  |  |
| Effect of dilutive securities | 62,995 |  |  | 127,567 |  |  |  |  |  |
| Weighted-average diluted shares | 15,955,718 |  |  | 16,519,291 |  |  |  |  |  |
| Basic earnings per share | $ | 1.89 |  |  | $ | 2.11 |  |  |  |  |  |
| Diluted earnings per share | $ | 1.88 |  |  | $ | 2.10 |  |  |  |  |  |

- added (2023-02-03):
[0000320193-23-000006:note_history:10]
Approximately 89 million restricted stock units (“RSUs”) were excluded from the computation of diluted earnings per share for the three months ended December 31, 2022 because their effect would have been antidilutive.

- removed (2023-02-03):
[0000320193-22-000070:note_history:11]
The Company’s fiscal year is the 52- or 53-week period that ends on the last Saturday of September. An additional week is included in the first fiscal quarter every five or six years to realign the Company’s fiscal quarters with calendar quarters. The Company’s fiscal years 2022 and 2021 span 52 weeks each. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in September and the associated quarters, months and periods of those fiscal years.

- removed (2023-02-03):
[0000320193-22-000070:note_history:12]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25,2022 |  | June 26,2021 |  | June 25,2022 |  | June 26,2021 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 19,442 |  |  | $ | 21,744 |  |  | $ | 79,082 |  |  | $ | 74,129 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 16,162,945 |  |  | 16,629,371 |  |  | 16,277,824 |  |  | 16,772,656 |  |
| Effect of dilutive securities | 99,258 |  |  | 152,364 |  |  | 117,113 |  |  | 168,871 |  |
| Weighted-average diluted shares | 16,262,203 |  |  | 16,781,735 |  |  | 16,394,937 |  |  | 16,941,527 |  |
| Basic earnings per share | $ | 1.20 |  |  | $ | 1.31 |  |  | $ | 4.86 |  |  | $ | 4.42 |  |
| Diluted earnings per share | $ | 1.20 |  |  | $ | 1.30 |  |  | $ | 4.82 |  |  | $ | 4.38 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-02-03):
[0000320193-23-000006:note_history:13]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of December 31, 2022 and September 24, 2022, the Company had $1.7 billion and $10.0 billion of Commercial Paper outstanding, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the three months ended December 31, 2022 and December 25, 2021 (in millions):
  (was, 2022-07-29, similarity 0.9194):
[0000320193-22-000070:note_history:13]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of June 25, 2022 and September 25, 2021, the Company had $11.0 billion and $6.0 billion of Commercial Paper outstanding, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the nine months ended June 25, 2022 and June 26, 2021 (in millions):

- added (2023-02-03):
[0000320193-23-000006:note_history:14]
|  | Three Months Ended |
|  | December 31,2022 |  | December 25,2021 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | (5,569) |  |  | $ | 1,339 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | — |  |  | 1,191 |  |
| Repayments of commercial paper | (2,645) |  |  | (3,530) |  |
| Repayments of commercial paper, net | (2,645) |  |  | (2,339) |  |
| Total repayments of commercial paper, net | $ | (8,214) |  |  | $ | (1,000) |  |

- changed (2023-02-03):
[0000320193-23-000006:note_history:15]
As of December 31, 2022 and September 24, 2022, the Company had outstanding fixed-rate notes with varying maturities for an aggregate carrying amount of $109.4 billion and $110.1 billion, respectively (collectively the “Notes”). As of December 31, 2022 and September 24, 2022, the fair value of the Company’s Notes, based on Level 2 inputs, was $98.0 billion and $98.8 billion, respectively.
  (was, 2022-07-29, similarity 0.8073):
[0000320193-22-000070:note_history:15]
As of June 25, 2022 and September 25, 2021, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate carrying amount of $108.7 billion and $118.7 billion, respectively (collectively the “Notes”). As of June 25, 2022 and September 25, 2021, the fair value of the Company’s Notes, based on Level 2 inputs, was $101.0 billion and $125.3 billion, respectively.

- removed (2023-02-03):
[0000320193-22-000070:note_history:16]
|  | Nine Months Ended |
|  | June 25,2022 |  | June 26,2021 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from commercial paper, net | $ | 4,383 |  |  | $ | 2,745 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 5,731 |  |  | 3,993 |  |
| Repayments of commercial paper | (5,144) |  |  | (3,716) |  |
| Proceeds from commercial paper, net | 587 |  |  | 277 |  |
| Total proceeds from commercial paper, net | $ | 4,970 |  |  | $ | 3,022 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-02-03):
[0000320193-23-000006:note_history:17]
Net sales disaggregated by significant products and services for the three months ended December 31, 2022 and December 25, 2021 were as follows (in millions):
  (was, 2022-07-29, similarity 0.8787):
[0000320193-22-000070:note_history:17]
Net sales disaggregated by significant products and services for the three- and nine-month periods ended June 25, 2022 and June 26, 2021 were as follows (in millions):

- changed (2023-02-03):
[0000320193-23-000006:note_history:18]
|  | Three Months Ended |  |  |
|  | December 31,2022 |  | December 25,2021 |  |  |  |  |
| iPhone® (1) | $ | 65,775 |  |  | $ | 71,628 |  |  |  |  |  |
| Mac® (1) | 7,735 |  |  | 10,852 |  |  |  |  |  |
| iPad® (1) | 9,396 |  |  | 7,248 |  |  |  |  |  |
| Wearables, Home and Accessories (1)(2) | 13,482 |  |  | 14,701 |  |  |  |  |  |
| Services (3) | 20,766 |  |  | 19,516 |  |  |  |  |  |
| Total net sales (4) | $ | 117,154 |  |  | $ | 123,945 |  |  |  |  |  |
  (was, 2022-07-29, similarity 0.7623):
[0000320193-22-000070:note_history:18]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25,2022 |  | June 26,2021 |  | June 25,2022 |  | June 26,2021 |
| iPhone® (1) | $ | 40,665 |  |  | $ | 39,570 |  |  | $ | 162,863 |  |  | $ | 153,105 |  |
| Mac® (1) | 7,382 |  |  | 8,235 |  |  | 28,669 |  |  | 26,012 |  |
| iPad® (1) | 7,224 |  |  | 7,368 |  |  | 22,118 |  |  | 23,610 |  |
| Wearables, Home and Accessories (1)(2) | 8,084 |  |  | 8,775 |  |  | 31,591 |  |  | 29,582 |  |
| Services (3) | 19,604 |  |  | 17,486 |  |  | 58,941 |  |  | 50,148 |  |
| Total net sales (4) | $ | 82,959 |  |  | $ | 81,434 |  |  | $ | 304,182 |  |  | $ | 282,457 |  |

- added (2023-02-03):
[0000320193-23-000006:note_history:19]
(4)Includes $3.4 billion of revenue recognized in the three months ended December 31, 2022 that was included in deferred revenue as of September 24, 2022 and $3.0 billion of revenue recognized in the three months ended December 25, 2021 that was included in deferred revenue as of September 25, 2021.

- removed (2023-02-03):
[0000320193-22-000070:note_history:20]
(4)Includes $3.1 billion of revenue recognized in the three months ended June 25, 2022 that was included in deferred revenue as of March 26, 2022, $3.0 billion of revenue recognized in the three months ended June 26, 2021 that was included in deferred revenue as of March 27, 2021, $6.3 billion of revenue recognized in the nine months ended June 25, 2022 that was included in deferred revenue as of September 25, 2021, and $5.5 billion of revenue recognized in the nine months ended June 26, 2021 that was included in deferred revenue as of September 26, 2020.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-02-03):
[0000320193-23-000006:note_history:21]
Revenue
Net sales disaggregated by significant products and services for the three months ended December 31, 2022 and December 25, 2021 were as follows (in millions):
  (was, 2022-07-29, similarity 0.8847):
[0000320193-22-000070:note_history:21]
Revenue
Net sales disaggregated by significant products and services for the three- and nine-month periods ended June 25, 2022 and June 26, 2021 were as follows (in millions):

- changed (2023-02-03):
[0000320193-23-000006:note_history:22]
|  | Three Months Ended |  |  |
|  | December 31,2022 |  | December 25,2021 |  |  |  |  |
| iPhone® (1) | $ | 65,775 |  |  | $ | 71,628 |  |  |  |  |  |
| Mac® (1) | 7,735 |  |  | 10,852 |  |  |  |  |  |
| iPad® (1) | 9,396 |  |  | 7,248 |  |  |  |  |  |
| Wearables, Home and Accessories (1)(2) | 13,482 |  |  | 14,701 |  |  |  |  |  |
| Services (3) | 20,766 |  |  | 19,516 |  |  |  |  |  |
| Total net sales (4) | $ | 117,154 |  |  | $ | 123,945 |  |  |  |  |  |
  (was, 2022-07-29, similarity 0.7623):
[0000320193-22-000070:note_history:22]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25,2022 |  | June 26,2021 |  | June 25,2022 |  | June 26,2021 |
| iPhone® (1) | $ | 40,665 |  |  | $ | 39,570 |  |  | $ | 162,863 |  |  | $ | 153,105 |  |
| Mac® (1) | 7,382 |  |  | 8,235 |  |  | 28,669 |  |  | 26,012 |  |
| iPad® (1) | 7,224 |  |  | 7,368 |  |  | 22,118 |  |  | 23,610 |  |
| Wearables, Home and Accessories (1)(2) | 8,084 |  |  | 8,775 |  |  | 31,591 |  |  | 29,582 |  |
| Services (3) | 19,604 |  |  | 17,486 |  |  | 58,941 |  |  | 50,148 |  |
| Total net sales (4) | $ | 82,959 |  |  | $ | 81,434 |  |  | $ | 304,182 |  |  | $ | 282,457 |  |

- added (2023-02-03):
[0000320193-23-000006:note_history:23]
(4)Includes $3.4 billion of revenue recognized in the three months ended December 31, 2022 that was included in deferred revenue as of September 24, 2022 and $3.0 billion of revenue recognized in the three months ended December 25, 2021 that was included in deferred revenue as of September 25, 2021.

- changed (2023-02-03):
[0000320193-23-000006:note_history:24]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 9, “Segment Information and Geographic Data” for the three months ended December 31, 2022 and December 25, 2021, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.
  (was, 2022-07-29, similarity 0.8715):
[0000320193-22-000070:note_history:24]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 9, “Segment Information and Geographic Data” for the three- and nine-month periods ended June 25, 2022 and June 26, 2021, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.

- added (2023-02-03):
[0000320193-23-000006:note_history:25]
As of December 31, 2022 and September 24, 2022, the Company had total deferred revenue of $12.6 billion and $12.4 billion, respectively. As of December 31, 2022, the Company expects 63% of total deferred revenue to be realized in less than a year, 27% within one-to-two years, 8% within two-to-three years and 2% in greater than three years.

- removed (2023-02-03):
[0000320193-22-000070:note_history:26]
(4)Includes $3.1 billion of revenue recognized in the three months ended June 25, 2022 that was included in deferred revenue as of March 26, 2022, $3.0 billion of revenue recognized in the three months ended June 26, 2021 that was included in deferred revenue as of March 27, 2021, $6.3 billion of revenue recognized in the nine months ended June 25, 2022 that was included in deferred revenue as of September 25, 2021, and $5.5 billion of revenue recognized in the nine months ended June 26, 2021 that was included in deferred revenue as of September 26, 2020.

- removed (2023-02-03):
[0000320193-22-000070:note_history:27]
As of June 25, 2022 and September 25, 2021, the Company had total deferred revenue of $12.2 billion and $11.9 billion, respectively. As of June 25, 2022, the Company expects 63% of total deferred revenue to be realized in less than a year, 27% within one-to-two years, 8% within two-to-three years and 2% in greater than three years.
