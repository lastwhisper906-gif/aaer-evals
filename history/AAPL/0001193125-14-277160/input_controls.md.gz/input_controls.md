# AAPL 10-Q controls and the auditor's report


## item_4_controls

[0001193125-14-277160:item_4_controls:1]
| Item 4. | Controls and Procedures. |

[0001193125-14-277160:item_4_controls:2]
Evaluation
of Disclosure Controls and Procedures

[0001193125-14-277160:item_4_controls:3]
Based on an evaluation under the supervision and with the participation of the
Company’s management, the Company’s principal executive officer and principal financial officer have concluded that the Company’s disclosure controls and procedures as defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act
were effective as of June 28, 2014 to ensure that information required to be disclosed by the Company in reports that it files or submits under the Exchange Act is (i) recorded, processed, summarized and reported within the time periods
specified in the SEC rules and forms and (ii) accumulated and communicated to the Company’s management, including its principal executive officer and principal financial officer, as appropriate to allow timely decisions regarding required
disclosure.

[0001193125-14-277160:item_4_controls:4]
Changes in Internal Control Over Financial Reporting

[0001193125-14-277160:item_4_controls:5]
There were no changes in the Company’s internal control over financial reporting during the third quarter of 2014, which were
identified in connection with management’s evaluation required by paragraph (d) of Rules 13a-15 and 15d-15 under the Exchange Act, that have materially affected, or are reasonably likely to materially affect, the Company’s internal
control over financial reporting.

[0001193125-14-277160:item_4_controls:6]
41
