# AAPL MD&A — 0001193125-14-277160


## mdna

[0001193125-14-277160:mdna:1]
| Item 2. | Management’s Discussion and Analysis of Financial Condition and Results of Operations. |

[0001193125-14-277160:mdna:2]
[same as prior period, unchanged from 0001193125-14-157311:mdna:2]

[0001193125-14-277160:mdna:3]
[same as prior period, unchanged from 0001193125-14-157311:mdna:3]

[0001193125-14-277160:mdna:4]
[same as prior period, unchanged from 0001193125-14-157311:mdna:4]

[0001193125-14-277160:mdna:5]
[same as prior period, unchanged from 0001193125-14-157311:mdna:5]

[0001193125-14-277160:mdna:6]
[same as prior period, unchanged from 0001193125-14-157311:mdna:6]

[0001193125-14-277160:mdna:7]
[same as prior period, unchanged from 0001193125-14-157311:mdna:7]

[0001193125-14-277160:mdna:8]
The Company is committed to
bringing the best user experience to its customers through its innovative hardware, software and services. The Company’s business strategy leverages its unique ability to design and develop its own operating systems, hardware, application
software, and services to provide its customers new products and solutions with superior ease-of-use, seamless integration, and innovative design. The Company believes continual investment in research and development, marketing and advertising is
critical to the development and sale of innovative products and technologies. As part of its strategy, the Company continues to expand its platform for the discovery and delivery of third-party digital content and applications through the iTunes
Store. As part of the iTunes Store, the Company’s App Store and iBooks Store allow customers to discover and download applications and books through either a Mac or Windows-based computer or through “iOS devices,” namely iPhone, iPad
and iPod touch®. The Company’s Mac App Store allows customers to easily discover, download and install Mac
applications. The Company also supports a community for the development of third-party software and hardware products and digital content that complement the Company’s offerings. The Company believes a high-quality buying experience with
knowledgeable salespersons who can convey the value of the Company’s products and services greatly enhances its ability to attract and retain customers. Therefore, the Company’s strategy also includes enhancing and expanding its own retail
and online stores and its third-party distribution network to effectively reach more customers and provide them with a high-quality sales and post-sales support experience.

[0001193125-14-277160:mdna:9]
Business Seasonality and Product Introductions

[0001193125-14-277160:mdna:10]
The Company has historically experienced higher net sales in its first quarter compared to other quarters in its fiscal year due in part
to seasonal holiday demand. Additionally, new product introductions can significantly impact net sales, product costs and operating expenses. Product introductions can also impact the Company’s net sales to its indirect distribution channels as
these channels are filled with new product inventory following a product introduction, and often, channel inventory of a particular product declines as the next related major product launch approaches. Net sales can also be affected when consumers
and distributors anticipate a product introduction. However, neither historical seasonal patterns nor historical patterns of product introductions should be considered reliable indicators of the Company’s future pattern of product
introductions, future net sales or financial performance.

[0001193125-14-277160:mdna:11]
Third Quarter Fiscal 2014 Highlights

[0001193125-14-277160:mdna:12]
Net sales rose $2.1 billion in the third quarter of 2014 compared to the same period in 2013, representing growth of
6%. Net sales and unit sales increased for iPhone resulting primarily from the successful introduction of new iPhones in the latter half of calendar year 2013 and expanded distribution. Net sales and unit sales increased for Mac due to strong demand
for MacBook Air® which was updated with faster processors and lower prices in April 2014 and due to sales of the
new Mac Pro® which became available in December 2013. Net sales of iTunes®, Software and Services grew primarily due to increased revenue from sales of iOS Apps, AppleCare® and licensing. Net sales and unit sales for iPad declined in the third quarter of 2014 compared to the same period
in 2013 due to lower unit sales in many markets. Growth in total net sales during the third quarter of 2014 was also negatively impacted by the continuing decline of iPod sales. Growth in net sales was particularly strong in Greater China where
revenue grew 28% in the third quarter of 2014 compared to the same period in 2013.

[0001193125-14-277160:mdna:13]
At its Worldwide Developers Conference in
June 2014, the Company announced new versions of its operating systems, iOS 8 and OS X Yosemite, both of which are expected to be available in the fall of 2014.

[0001193125-14-277160:mdna:14]
During the third quarter of 2014, the Company utilized $5 billion to repurchase its common stock and paid dividends and dividend equivalents of $2.9 billion. Additionally, the Company issued $12.0 billion
of long-term debt and $2.0 billion of commercial paper during the third quarter of 2014.

[0001193125-14-277160:mdna:15]
[same as prior period, unchanged from 0001193125-14-157311:mdna:15]

[0001193125-14-277160:mdna:16]
The following table shows net sales by operating segment and net sales and unit sales by product during the three- and nine-month periods ended June 28, 2014 and June 29, 2013 (dollars in
millions and units in thousands):

[0001193125-14-277160:mdna:17]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 28,2014 |  |  | June 29,2013 |  |  | Change |  |  | June 28,2014 |  |  | June 29,2013 |  |  | Change |  |
| Net Sales by Operating Segment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 14,577 |  |  | $ | 14,405 |  |  |  | 1% |  |  | $ | 48,985 |  |  | $ | 48,798 |  |  |  | 0% |  |
| Europe |  |  | 8,091 |  |  |  | 7,614 |  |  |  | 6% |  |  |  | 31,394 |  |  |  | 29,878 |  |  |  | 5% |  |
| Greater China (a) |  |  | 5,935 |  |  |  | 4,641 |  |  |  | 28% |  |  |  | 24,068 |  |  |  | 19,684 |  |  |  | 22% |  |
| Japan |  |  | 2,564 |  |  |  | 2,543 |  |  |  | 1% |  |  |  | 11,475 |  |  |  | 10,121 |  |  |  | 13% |  |
| Rest of Asia Pacific |  |  | 2,161 |  |  |  | 2,046 |  |  |  | 6% |  |  |  | 8,421 |  |  |  | 9,201 |  |  |  | (8)% |  |
| Retail |  |  | 4,104 |  |  |  | 4,074 |  |  |  | 1% |  |  |  | 16,329 |  |  |  | 15,756 |  |  |  | 4% |  |
| Total net sales |  | $ | 37,432 |  |  | $ | 35,323 |  |  |  | 6% |  |  | $ | 140,672 |  |  | $ | 133,438 |  |  |  | 5% |  |
| Net Sales by Product: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| iPhone (b) |  | $ | 19,751 |  |  | $ | 18,154 |  |  |  | 9% |  |  | $ | 78,313 |  |  | $ | 71,769 |  |  |  | 9% |  |
| iPad (b) |  |  | 5,889 |  |  |  | 6,374 |  |  |  | (8)% |  |  |  | 24,967 |  |  |  | 25,794 |  |  |  | (3)% |  |
| Mac (b) |  |  | 5,540 |  |  |  | 4,893 |  |  |  | 13% |  |  |  | 17,454 |  |  |  | 15,859 |  |  |  | 10% |  |
| iPod (b) |  |  | 442 |  |  |  | 733 |  |  |  | (40)% |  |  |  | 1,876 |  |  |  | 3,838 |  |  |  | (51)% |  |
| iTunes, Software and Services (c) |  |  | 4,485 |  |  |  | 3,990 |  |  |  | 12% |  |  |  | 13,455 |  |  |  | 11,791 |  |  |  | 14% |  |
| Accessories (d) |  |  | 1,325 |  |  |  | 1,179 |  |  |  | 12% |  |  |  | 4,607 |  |  |  | 4,387 |  |  |  | 5% |  |
| Total net sales |  | $ | 37,432 |  |  | $ | 35,323 |  |  |  | 6% |  |  | $ | 140,672 |  |  | $ | 133,438 |  |  |  | 5% |  |
| Unit Sales by Product: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| iPhone |  |  | 35,203 |  |  |  | 31,241 |  |  |  | 13% |  |  |  | 129,947 |  |  |  | 116,460 |  |  |  | 12% |  |
| iPad |  |  | 13,276 |  |  |  | 14,617 |  |  |  | (9)% |  |  |  | 55,661 |  |  |  | 56,954 |  |  |  | (2)% |  |
| Mac |  |  | 4,413 |  |  |  | 3,754 |  |  |  | 18% |  |  |  | 13,386 |  |  |  | 11,767 |  |  |  | 14% |  |
| iPod |  |  | 2,926 |  |  |  | 4,569 |  |  |  | (36)% |  |  |  | 11,736 |  |  |  | 22,881 |  |  |  | (49)% |  |

[0001193125-14-277160:mdna:18]
[same as prior period, unchanged from 0001193125-14-157311:mdna:18]

[0001193125-14-277160:mdna:19]
[same as prior period, unchanged from 0001193125-14-157311:mdna:19]

[0001193125-14-277160:mdna:20]
[same as prior period, unchanged from 0001193125-14-157311:mdna:20]

[0001193125-14-277160:mdna:21]
[same as prior period, unchanged from 0001193125-14-157311:mdna:21]

[0001193125-14-277160:mdna:22]
27

[0001193125-14-277160:mdna:23]
[same as prior period, unchanged from 0001193125-14-157311:mdna:23]

[0001193125-14-277160:mdna:24]
[same as prior period, unchanged from 0001193125-14-157311:mdna:24]

[0001193125-14-277160:mdna:25]
The following table presents iPhone net sales and unit sales
information for the three- and nine-month periods ended June 28, 2014 and June 29, 2013 (dollars in millions and units in thousands):

[0001193125-14-277160:mdna:26]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 28,2014 |  |  | June 29,2013 |  |  | Change |  |  | June 28,2014 |  |  | June 29,2013 |  |  | Change |  |
| Net sales |  | $ | 19,751 |  |  | $ | 18,154 |  |  |  | 9% |  |  | $ | 78,313 |  |  | $ | 71,769 |  |  |  | 9% |  |
| Percentage of total net sales |  |  | 53% |  |  |  | 51% |  |  |  |  |  |  |  | 56% |  |  |  | 54% |  |  |  |  |  |
| Unit sales |  |  | 35,203 |  |  |  | 31,241 |  |  |  | 13% |  |  |  | 129,947 |  |  |  | 116,460 |  |  |  | 12% |  |

[0001193125-14-277160:mdna:27]
The year-over-year growth in iPhone net sales and unit sales in the third quarter and first nine months
of 2014 resulted primarily from the successful introduction of new iPhones in the latter half of calendar year 2013 and expanded distribution. Compared to the same periods in 2013, iPhone net sales and unit sales growth were particularly strong in
the Greater China and Rest of Asia Pacific segments in the third quarter of 2014, and in the Greater China and Japan segments in the first nine months of 2014. Overall average selling prices (“ASPs”) for iPhone were down during the third
quarter and first nine months of 2014 compared to the same periods in 2013, primarily due to a shift in product mix and to weakening of foreign currencies relative to the U.S. dollar.

[0001193125-14-277160:mdna:28]
[same as prior period, unchanged from 0001193125-14-157311:mdna:28]

[0001193125-14-277160:mdna:29]
The following table presents iPad net sales and unit sales
information for the three- and nine-month periods ended June 28, 2014 and June 29, 2013 (dollars in millions and units in thousands):

[0001193125-14-277160:mdna:30]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 28,2014 |  |  | June 29,2013 |  |  | Change |  |  | June 28,2014 |  |  | June 29,2013 |  |  | Change |  |
| Net sales |  | $ | 5,889 |  |  | $ | 6,374 |  |  |  | (8)% |  |  | $ | 24,967 |  |  | $ | 25,794 |  |  |  | (3)% |  |
| Percentage of total net sales |  |  | 16% |  |  |  | 18% |  |  |  |  |  |  |  | 18% |  |  |  | 19% |  |  |  |  |  |
| Unit sales |  |  | 13,276 |  |  |  | 14,617 |  |  |  | (9)% |  |  |  | 55,661 |  |  |  | 56,954 |  |  |  | (2)% |  |

[0001193125-14-277160:mdna:31]
Net sales and unit sales for iPad declined in the third quarter and first nine months of 2014 compared to
the same periods in 2013. iPad net sales and unit sales grew overall in developing markets in the third quarter and first nine months of 2014, but this growth was more than offset by a decline in overall iPad net sales and unit sales in mature
markets. iPad ASPs increased in the third quarter of 2014 compared to the same period in 2013 primarily as a result of a shift in mix toward higher priced iPads, while iPad ASPs declined in the first nine months of 2014 compared to the first nine
months of 2013 with a shift in iPad product mix being more than offset by the October 2013 price reduction of iPad mini.

[0001193125-14-277160:mdna:32]
[same as prior period, unchanged from 0001193125-14-157311:mdna:32]

[0001193125-14-277160:mdna:33]
The following table presents Mac net sales and unit sales information for the three- and nine-month periods ended June 28, 2014 and June 29, 2013 (dollars in millions and units in thousands):

[0001193125-14-277160:mdna:34]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 28,2014 |  |  | June 29,2013 |  |  | Change |  |  | June 28,2014 |  |  | June 29,2013 |  |  | Change |  |
| Net sales |  | $ | 5,540 |  |  | $ | 4,893 |  |  |  | 13% |  |  | $ | 17,454 |  |  | $ | 15,859 |  |  |  | 10% |  |
| Percentage of total net sales |  |  | 15% |  |  |  | 14% |  |  |  |  |  |  |  | 12% |  |  |  | 12% |  |  |  |  |  |
| Unit sales |  |  | 4,413 |  |  |  | 3,754 |  |  |  | 18% |  |  |  | 13,386 |  |  |  | 11,767 |  |  |  | 14% |  |

[0001193125-14-277160:mdna:35]
The year-over-year growth in Mac net sales and unit sales for the third quarter and first nine months of
2014 was primarily driven by increased sales of MacBook Air and Mac Pro. Mac ASPs decreased during the third quarter and first nine months of 2014 compared to the same periods in 2013 primarily due to price reductions on certain Mac models and a
shift in mix towards Mac portable systems.

[0001193125-14-277160:mdna:36]
[same as prior period, unchanged from 0001193125-14-157311:mdna:36]

[0001193125-14-277160:mdna:37]
The following table presents net sales information of iTunes, Software and Services for the three- and nine-month periods ended
June 28, 2014 and June 29, 2013 (dollars in millions):

[0001193125-14-277160:mdna:38]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 28,2014 |  |  | June 29,2013 |  |  | Change |  |  | June 28,2014 |  |  | June 29,2013 |  |  | Change |  |
| Net sales |  | $ | 4,485 |  |  | $ | 3,990 |  |  |  | 12% |  |  | $ | 13,455 |  |  | $ | 11,791 |  |  |  | 14% |  |
| Percentage of total net sales |  |  | 12% |  |  |  | 11% |  |  |  |  |  |  |  | 10% |  |  |  | 9% |  |  |  |  |  |

[0001193125-14-277160:mdna:39]
The increase in net sales of iTunes, Software and Services in the third quarter and first nine months of
2014 compared to the same periods in 2013 was primarily due to growth in net sales from the iTunes Store, AppleCare and licensing. The iTunes Store generated a total of $2.6 billion and $7.6 billion in net sales during the third quarter and first
nine months of 2014, respectively, compared to $2.4 billion and $6.9 billion during the third quarter and first nine months of 2013, respectively. Growth in net sales from the iTunes Store was driven by increases in revenue from App sales reflecting
continued growth in the installed base of iOS devices and the expansion in the number of third-party iOS Apps available. This was partially offset by a decline in sales of digital music.

[0001193125-14-277160:mdna:40]
[same as prior period, unchanged from 0001193125-14-157311:mdna:40]

[0001193125-14-277160:mdna:41]
The Company manages its business primarily
on a geographic basis. Accordingly, the Company determined its reportable operating segments, which are generally based on the nature and location of its customers, to be the Americas, Europe, Greater China, Japan, Rest of Asia Pacific and Retail.
The Americas segment includes both North and South America. The Europe segment includes European countries, as well as India, the Middle East and Africa. The Greater China segment includes China, Hong Kong and Taiwan. The Rest of Asia Pacific
segment includes Australia and Asian countries, other than those countries included in the Company’s other operating segments. The results of the Company’s geographic segments do not include results of the Retail segment. Each operating
segment provides similar hardware and software products and similar services. Further information regarding the Company’s operating segments may be found in Note 11, “Segment Information and Geographic Data” in Notes to Condensed
Consolidated Financial Statements of this Form 10-Q.

[0001193125-14-277160:mdna:42]
[same as prior period, unchanged from 0001193125-14-157311:mdna:42]

[0001193125-14-277160:mdna:43]
The following table presents Americas net sales information for the three- and nine-month periods ended June 28, 2014 and June 29, 2013 (dollars in millions):

[0001193125-14-277160:mdna:44]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 28,2014 |  |  | June 29,2013 |  |  | Change |  |  | June 28,2014 |  |  | June 29,2013 |  |  | Change |  |
| Net sales |  | $ | 14,577 |  |  | $ | 14,405 |  |  |  | 1% |  |  | $ | 48,985 |  |  | $ | 48,798 |  |  |  | 0% |  |
| Percentage of total net sales |  |  | 39% |  |  |  | 41% |  |  |  |  |  |  |  | 35% |  |  |  | 36% |  |  |  |  |  |

[0001193125-14-277160:mdna:45]
Americas experienced increases in net sales of Mac and iTunes, Software and Services that were largely
offset by a decline in net sales of both iPod and iPad and weakness in foreign currencies relative to the U.S. dollar in the third quarter and first nine months of 2014 compared to the same periods in 2013. Mac growth was driven by increased net
sales and unit sales of MacBook Air and Mac Pro. Net sales of iPhone were relatively flat in the third quarter of 2014 and were up only slightly in the first nine months of 2014 compared to the same periods in 2013.

[0001193125-14-277160:mdna:46]
[same as prior period, unchanged from 0001193125-14-157311:mdna:46]

[0001193125-14-277160:mdna:47]
The following
table presents Europe net sales information for the three- and nine-month periods ended June 28, 2014 and June 29, 2013 (dollars in millions):

[0001193125-14-277160:mdna:48]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 28,2014 |  |  | June 29,2013 |  |  | Change |  |  | June 28,2014 |  |  | June 29,2013 |  |  | Change |  |
| Net sales |  | $ | 8,091 |  |  | $ | 7,614 |  |  |  | 6% |  |  | $ | 31,394 |  |  | $ | 29,878 |  |  |  | 5% |  |
| Percentage of total net sales |  |  | 22% |  |  |  | 21% |  |  |  |  |  |  |  | 22% |  |  |  | 22% |  |  |  |  |  |

[0001193125-14-277160:mdna:49]
The increase in Europe net sales during the third quarter and first nine months of 2014 compared to the
same periods in 2013 reflects increases in net sales of iPhone, Mac and iTunes, Software and Services, partially offset by a decline in net sales of iPod and iPad. Net sales growth in the third quarter and first nine months of 2014 was most
pronounced in developing markets within Europe. Strength of foreign currencies relative to the U.S. dollar also contributed to net sales growth in the third quarter and first nine months of 2014.

[0001193125-14-277160:mdna:50]
[same as prior period, unchanged from 0001193125-14-157311:mdna:50]

[0001193125-14-277160:mdna:51]
The
following table presents Greater China net sales information for the three- and nine-month periods ended June 28, 2014 and June 29, 2013 (dollars in millions):

[0001193125-14-277160:mdna:52]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 28,2014 |  |  | June 29,2013 |  |  | Change |  |  | June 28,2014 |  |  | June 29,2013 |  |  | Change |  |
| Net sales |  | $ | 5,935 |  |  | $ | 4,641 |  |  |  | 28% |  |  | $ | 24,068 |  |  | $ | 19,684 |  |  |  | 22% |  |
| Percentage of total net sales |  |  | 16% |  |  |  | 13% |  |  |  |  |  |  |  | 17% |  |  |  | 15% |  |  |  |  |  |

[0001193125-14-277160:mdna:53]
During the third quarter and first nine months of 2014, Greater China experienced year-over-year
increases in net sales that were significantly higher than those experienced by the Company overall. The growth in 2014 compared to 2013 was driven by higher unit sales and net sales of all major product categories, except iPod, in addition to
higher net sales of iTunes, Software and Services. Growth in net sales and unit sales of iPhone was especially strong, driven by the successful launch of new iPhones in Greater China at the end of 2013, increased demand for the Company’s
entry-priced iPhones and the addition of a significant new carrier in the second quarter of 2014.

[0001193125-14-277160:mdna:54]
[same as prior period, unchanged from 0001193125-14-157311:mdna:54]

[0001193125-14-277160:mdna:55]
The following table presents Japan net sales information for the three- and nine-month periods ended June 28, 2014 and June 29, 2013 (dollars in millions):

[0001193125-14-277160:mdna:56]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 28,2014 |  |  | June 29,2013 |  |  | Change |  |  | June 28,2014 |  |  | June 29,2013 |  |  | Change |  |
| Net sales |  | $ | 2,564 |  |  | $ | 2,543 |  |  |  | 1% |  |  | $ | 11,475 |  |  | $ | 10,121 |  |  |  | 13% |  |
| Percentage of total net sales |  |  | 7% |  |  |  | 7% |  |  |  |  |  |  |  | 8% |  |  |  | 8% |  |  |  |  |  |

[0001193125-14-277160:mdna:57]
In the third quarter of 2014, Japan generated increases in net sales of iPad, Mac, and iTunes, Software
and Services that were largely offset by a decline in net sales of iPhone and iPod in addition to the weakening of the Japanese Yen relative to the U.S. dollar. iPhone net sales and unit sales declined in the third quarter of 2014 compared to the
same period in 2013 as changes in the regulatory environment negatively impacted growth of the Japan smartphone market. iPad unit sales were down during the third quarter of 2014 compared to the same period in 2013, but the decline was more than
offset by higher ASPs that drove higher net sales of iPad year-over-year. In the first nine months of 2014, Japan generated year-over-year increases in net sales of every major product category except iPod and generated growth in net sales of
iTunes, Software and Service, partially offset by weakness in the Japanese Yen relative to the U.S. dollar. While net sales of iPad increased during the first nine months of 2014 compared to the same period in 2013, iPad unit sales declined over the
same period.

[0001193125-14-277160:mdna:58]
[same as prior period, unchanged from 0001193125-14-157311:mdna:58]

[0001193125-14-277160:mdna:59]
The following table presents Rest of Asia Pacific net sales information for the three- and nine-month periods ended June 28, 2014 and June 29, 2013 (dollars in millions):

[0001193125-14-277160:mdna:60]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 28,2014 |  |  | June 29,2013 |  |  | Change |  |  | June 28,2014 |  |  | June 29,2013 |  |  | Change |  |
| Net sales |  | $ | 2,161 |  |  | $ | 2,046 |  |  |  | 6% |  |  | $ | 8,421 |  |  | $ | 9,201 |  |  |  | (8)% |  |
| Percentage of total net sales |  |  | 6% |  |  |  | 6% |  |  |  |  |  |  |  | 6% |  |  |  | 7% |  |  |  |  |  |

[0001193125-14-277160:mdna:61]
Net sales in Rest of Asia Pacific increased during the third quarter of 2014 compared to the same period
in 2013 due to strong growth in net sales and unit sales of iPhone and Mac. The growth of iPhone was driven by higher sales of entry-priced iPhones, while the growth of Mac was driven by higher sales of MacBook Air. Net sales declined in the first
nine months of 2014 compared to the same period in 2013 due to year-over-year reductions in net sales in all major product categories except Mac in most countries in Rest of Asia Pacific. Net sales in both the third quarter and first nine months of
2014 were negatively affected by the weakness in several currencies relative to the U.S. dollar, including the Australian dollar.

[0001193125-14-277160:mdna:62]
[same as prior period, unchanged from 0001193125-14-157311:mdna:62]

[0001193125-14-277160:mdna:63]
The following tables present Retail net sales information for the three- and nine-month periods ended June 28, 2014 and June 29, 2013 and Retail store and headcount information as of
June 28, 2014 and June 29, 2013 (dollars in millions):

[0001193125-14-277160:mdna:64]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 28,2014 |  |  | June 29,2013 |  |  | Change |  |  | June 28,2014 |  |  | June 29,2013 |  |  | Change |  |
| Net sales |  | $ | 4,104 |  |  | $ | 4,074 |  |  |  | 1% |  |  | $ | 16,329 |  |  | $ | 15,756 |  |  |  | 4% |  |
| Percentage of total net sales |  |  | 11% |  |  |  | 12% |  |  |  |  |  |  |  | 12% |  |  |  | 12% |  |  |  |  |  |

[0001193125-14-277160:mdna:65]
|  |  | June 28, 2014 |  |  | June 29, 2013 |  |
| U.S. stores |  |  | 254 |  |  |  | 252 |  |
| International stores |  |  | 173 |  |  |  | 156 |  |
| Total store count |  |  | 427 |  |  |  | 408 |  |
| Headcount |  |  | 41,300 |  |  |  | 41,700 |  |

[0001193125-14-277160:mdna:66]
Growth in Retail net sales in the third quarter and first nine months of 2014 was driven by increases in
net sales and unit sales of iPhone and Mac, partially offset by declines in net sales and unit sales of iPad and iPod. With an average of 424 and 405 stores open during the third quarters of 2014 and 2013, respectively, average revenue per store
declined to $9.7 million in the third quarter of 2014 from $10.1 million in the third quarter of 2013. Average revenue per store declined to $38.8 million in the first nine months of 2014 from $39.3 million in the first nine months of 2013.

[0001193125-14-277160:mdna:67]
Retail generated operating income of $711 million during the third quarter of 2014 compared to $667 million in the third
quarter of 2013, and generated operating income of $3.6 billion during the first nine months of 2014 compared to $3.3 billion in the first nine months of 2013. The year-over-year increase in Retail operating income during the third quarter and first
nine months of 2014 was primarily attributable to a higher gross margin percentage.

[0001193125-14-277160:mdna:68]
[same as prior period, unchanged from 0001193125-14-157311:mdna:68]

[0001193125-14-277160:mdna:69]
Gross margin for the three- and nine-month periods ended June 28, 2014 and June 29, 2013 was as follows (dollars in millions):

[0001193125-14-277160:mdna:70]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 28,2014 |  |  | June 29,2013 |  |  | June 28,2014 |  |  | June 29,2013 |  |
| Net sales |  | $ | 37,432 |  |  | $ | 35,323 |  |  | $ | 140,672 |  |  | $ | 133,438 |  |
| Cost of sales |  |  | 22,697 |  |  |  | 22,299 |  |  |  | 86,144 |  |  |  | 83,005 |  |
| Gross margin |  | $ | 14,735 |  |  | $ | 13,024 |  |  | $ | 54,528 |  |  | $ | 50,433 |  |
| Gross margin percentage |  |  | 39.4% |  |  |  | 36.9% |  |  |  | 38.8% |  |  |  | 37.8% |  |

[0001193125-14-277160:mdna:71]
The increase in the gross margin percentage during the third quarter and first nine months of 2014
compared to the same periods in 2013 was driven by multiple factors including a favorable shift in mix to products with higher margins, lower commodity costs, and improved leverage on fixed costs from higher net sales. The impact of these factors
was partially offset by higher cost structures on certain new products and by changes in some foreign currency exchange rates.

[0001193125-14-277160:mdna:72]
The Company anticipates gross margin during the fourth quarter of 2014 to be between 37% and 38%. The foregoing statement regarding the
Company’s expected gross margin percentage in the fourth quarter of 2014 is forward-looking and could differ from actual results. The Company’s future gross margins can be impacted by multiple factors including, but not limited to, those
set forth in Part II, Item 1A of this Form 10-Q under the heading “Risk Factors” and those described in this paragraph. In general, the Company believes gross margins will remain under downward pressure due to a variety of factors,
including continued industry wide global product pricing pressures, increased competition, compressed product life cycles, product transitions, potential increases in the cost of components, and potential strengthening of the U.S. dollar, as well as
potential increases in the costs of outside manufacturing services and a potential shift in the Company’s sales mix towards products with lower gross margins. In response to competitive pressures, the Company expects it will continue to take
product pricing actions, which would adversely affect gross margins. Gross margins could also be affected by the Company’s ability to manage product quality and warranty costs effectively and to stimulate demand for certain of its products. Due
to the Company’s significant international operations, financial results can be significantly affected by fluctuations in exchange rates.

[0001193125-14-277160:mdna:73]
[same as prior period, unchanged from 0001193125-14-157311:mdna:73]

[0001193125-14-277160:mdna:74]
Operating expenses for the three- and nine-month periods ended June 28, 2014 and June 29, 2013 were as follows (dollars in millions):

[0001193125-14-277160:mdna:75]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 28,2014 |  |  | June 29,2013 |  |  | June 28,2014 |  |  | June 29,2013 |  |
| Research and development expense |  | $ | 1,603 |  |  | $ | 1,178 |  |  | $ | 4,355 |  |  | $ | 3,307 |  |
| Percentage of net sales |  |  | 4.3% |  |  |  | 3.3% |  |  |  | 3.1% |  |  |  | 2.5% |  |
| Selling, general and administrative expense |  | $ | 2,850 |  |  | $ | 2,645 |  |  | $ | 8,835 |  |  | $ | 8,157 |  |
| Percentage of net sales |  |  | 7.6% |  |  |  | 7.5% |  |  |  | 6.3% |  |  |  | 6.1% |  |
| Total operating expenses |  | $ | 4,453 |  |  | $ | 3,823 |  |  | $ | 13,190 |  |  | $ | 11,464 |  |
| Percentage of net sales |  |  | 11.9% |  |  |  | 10.8% |  |  |  | 9.4% |  |  |  | 8.6% |  |

[0001193125-14-277160:mdna:76]
[same as prior period, unchanged from 0001193125-14-157311:mdna:76]

[0001193125-14-277160:mdna:77]
The growth in R&D expense during the third quarter and the first nine months of 2014 compared to the same periods in 2013 was driven
primarily by an increase in headcount and related expenses to support expanded R&D activities. The Company continues to believe that focused investments in R&D are critical to its future growth and competitive position in the marketplace and
are directly related to timely development of new and enhanced products that are central to the Company’s core business strategy. As such, the Company expects to make further investments in R&D to remain competitive.

[0001193125-14-277160:mdna:78]
[same as prior period, unchanged from 0001193125-14-157311:mdna:78]

[0001193125-14-277160:mdna:79]
The growth in SG&A expense during the third quarter and the first nine months of 2014 compared to the same periods in 2013 was primarily due to increased headcount and related expenses, and higher
spending on marketing and professional services.

[0001193125-14-277160:mdna:80]
[same as prior period, unchanged from 0001193125-14-157311:mdna:80]

[0001193125-14-277160:mdna:81]
Other income and expense for the three- and nine-month periods ended June 28, 2014 and June 29, 2013 was as follows (dollars in
millions):

[0001193125-14-277160:mdna:82]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 28,2014 |  |  | June 29,2013 |  |  | Change |  |  | June 28,2014 |  |  | June 29,2013 |  |  | Change |  |
| Interest and dividend income |  | $ | 439 |  |  | $ | 385 |  |  |  |  |  |  | $ | 1,276 |  |  | $ | 1,226 |  |  |  |  |  |
| Interest expense |  |  | (100) |  |  |  | (53) |  |  |  |  |  |  |  | (269) |  |  |  | (53) |  |  |  |  |  |
| Other expense, net |  |  | (137) |  |  |  | (98) |  |  |  |  |  |  |  | (334) |  |  |  | (130) |  |  |  |  |  |
| Total other income/(expense), net |  | $ | 202 |  |  | $ | 234 |  |  |  | (14)% |  |  | $ | 673 |  |  | $ | 1,043 |  |  |  | (35)% |  |

[0001193125-14-277160:mdna:83]
The decrease in other income and expense during the third quarter of 2014 compared to the same period in
2013 was due primarily to higher interest expense on debt and lower realized gains on marketable securities, partially offset by higher interest income. The decrease in other income and expense during the first nine months of 2014 compared to the
same period in 2013 was due primarily to higher interest expense on debt, higher expenses associated with foreign exchange rate movements and lower realized gains from investment sales, partially offset by lower premium expenses on foreign exchange
contracts. The weighted-average interest rate earned by the Company on its cash, cash equivalents and marketable securities was 1.09% and 1.00% in the third quarter of 2014 and 2013, respectively, and 1.05% and 1.04% in the first nine months of 2014
and 2013, respectively.

[0001193125-14-277160:mdna:84]
[same as prior period, unchanged from 0001193125-14-157311:mdna:84]

[0001193125-14-277160:mdna:85]
Provision for income taxes and effective tax rates for the three- and nine-month periods ended June 28, 2014 and June 29, 2013 was as follows (dollars in millions):

[0001193125-14-277160:mdna:86]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 28,2014 |  |  | June 29,2013 |  |  | June 28,2014 |  |  | June 29,2013 |  |
| Provision for income taxes |  | $ | 2,736 |  |  | $ | 2,535 |  |  | $ | 10,968 |  |  | $ | 10,487 |  |
| Effective tax rate |  |  | 26.1% |  |  |  | 26.9% |  |  |  | 26.1% |  |  |  | 26.2% |  |

[0001193125-14-277160:mdna:87]
[same as prior period, unchanged from 0001193125-14-157311:mdna:87]

[0001193125-14-277160:mdna:88]
[same as prior period, unchanged from 0001193125-14-157311:mdna:88]

[0001193125-14-277160:mdna:89]
Recent Accounting Pronouncements

[0001193125-14-277160:mdna:90]
In May 2014, the Financial Accounting Standards Board issued Accounting Standards Update No. 2014-09, Revenue from
Contracts with Customers (Topic 606) (“ASU 2014-09”), which amends the existing accounting standards for revenue recognition. ASU 2014-09 is based on principles that govern the recognition of revenue at an amount an entity expects to be
entitled when products are transferred to customers. ASU 2014-09 will be effective for the Company beginning in its first quarter of 2018. Early adoption is not permitted. The new revenue standard may be applied retrospectively to each prior period
presented or retrospectively with the cumulative effect recognized as of the date of adoption. The Company is currently evaluating the impact of adopting the new revenue standard on its consolidated financial statements.

[0001193125-14-277160:mdna:91]
[same as prior period, unchanged from 0001193125-14-157311:mdna:89]

[0001193125-14-277160:mdna:92]
The following tables present selected financial information and statistics as of June 28, 2014 and September 28, 2013 and during the first nine months of 2014 and 2013 (in millions):

[0001193125-14-277160:mdna:93]
|  |  | June 28, 2014 |  |  | September 28, 2013 |  |
| Cash, cash equivalents and marketable securities |  | $ | 164,490 |  |  | $ | 146,761 |  |
| Property, plant and equipment, net |  | $ | 17,585 |  |  | $ | 16,597 |  |
| Long-term debt |  | $ | 29,030 |  |  | $ | 16,960 |  |
| Working capital |  | $ | 21,744 |  |  | $ | 29,628 |  |
|  |  | Nine Months Ended |  |
|  |  | June 28, 2014 |  |  | June 29, 2013 |  |
| Cash generated by operating activities |  | $ | 46,463 |  |  | $ | 43,758 |  |
| Cash used in investing activities |  | $ | (25,576 | ) |  | $ | (34,385 | ) |
| Cash used in financing activities |  | $ | (22,169 | ) |  | $ | (8,871 | ) |

[0001193125-14-277160:mdna:94]
The Company believes its existing balances of cash, cash equivalents and marketable securities will be
sufficient to satisfy its working capital needs, capital asset purchases, outstanding commitments, and other liquidity requirements associated with its existing operations over the next 12 months. To provide additional flexibility in managing
liquidity, the Company began accessing the commercial paper markets in the third quarter of 2014. The Company currently anticipates the cash used for future dividends and the share repurchase program will come from its current domestic cash, cash
generated from on-going U.S. operating activities and from borrowings.

[0001193125-14-277160:mdna:95]
As of June 28, 2014 and September 28, 2013, $137.7 billion and $111.3 billion,
respectively, of the Company’s cash, cash equivalents and marketable securities were held by foreign subsidiaries and generally based in U.S. dollar-denominated holdings. Amounts held by foreign
subsidiaries are typically subject to U.S. income taxation on repatriation to the U.S. The Company’s marketable securities investment portfolio is invested primarily in highly-rated securities and its investment policy limits the amount of
credit exposure to any one issuer. The policy generally requires investments to be investment grade with the objective of minimizing the potential risk of principal loss.

[0001193125-14-277160:mdna:96]
During the nine months ended June 28, 2014, cash generated from operating activities of $46.5 billion was a result of $31.0 billion of net income, non-cash adjustments to net income of $11.2 billion
and an increase in net change in operating assets and liabilities of $4.2 billion. Cash used in investing activities of $25.6 billion during the nine months ended June 28, 2014 consisted primarily of cash used for purchases of marketable
securities, net of sales and maturities, of $18.7 billion and cash used to acquire property, plant and equipment of $5.7 billion. Cash used in financing activities of $22.2 billion during the nine months ended June 28, 2014 consisted primarily
of cash used to repurchase common stock of $28.0 billion and cash used to pay dividends and dividend equivalents of $8.3 billion, partially offset by proceeds from the issuance of long-term debt and commercial paper of $12.0 billion and $2.0
billion, respectively.

[0001193125-14-277160:mdna:97]
During the nine months ended June 29, 2013, cash generated from operating activities of $43.8
billion was a result of $29.5 billion of net income, non-cash adjustments to net income of $9.2 billion and an increase in net change in operating assets and liabilities of $5.0 billion. Cash used in investing activities of $34.4 billion during the
nine months ended June 29, 2013 consisted primarily of cash used for purchases of marketable securities, net of sales and maturities, of $27.0 billion and cash used to acquire property, plant and equipment of $6.2 billion. Cash used in
financing activities of $8.9 billion during the nine months ended June 29, 2013 consisted primarily of cash used to repurchase common stock of $18.0 billion and cash used to pay dividends and dividend equivalents of $7.8 billion, partially
offset by net proceeds from the issuance of long-term debt of $16.9 billion.

[0001193125-14-277160:mdna:98]
[same as prior period, unchanged from 0001193125-14-157311:mdna:97]

[0001193125-14-277160:mdna:99]
The Company’s capital expenditures were $6.2 billion during the first nine months of 2014 consisting of $341 million for retail store
facilities and $5.9 billion for other capital expenditures, including product tooling and manufacturing process equipment, and other corporate facilities and infrastructure. The Company’s actual cash payments for capital expenditures during the
first nine months of 2014 were $5.7 billion.

[0001193125-14-277160:mdna:100]
The Company anticipates utilizing approximately $11.0 billion for capital
expenditures during 2014, including approximately $500 million for retail store facilities and approximately $10.5 billion for other capital expenditures, including product tooling and manufacturing process equipment, and corporate facilities and
infrastructure, including information systems hardware, software and enhancements.

[0001193125-14-277160:mdna:101]
During 2014, the Company expects to open
about 20 new retail stores, with approximately two-thirds located outside of the U.S. During 2014, the Company also expects to remodel approximately 15 of its existing stores.

[0001193125-14-277160:mdna:102]
Debt

[0001193125-14-277160:mdna:103]
In April 2014, the Board of Directors authorized the Company to issue
unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company intends to use net proceeds from the commercial paper program for general corporate purposes, including dividends and share
repurchases. As of June 28, 2014, the Company had $2.0 billion of Commercial Paper outstanding, with a weighted average interest rate of 0.09% and maturities generally less than nine months.

[0001193125-14-277160:mdna:104]
In the third quarter of 2014 and 2013, the Company issued $12.0 billion and $17.0 billion of long-term debt, respectively. The debt
issuances included floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $29.0 billion (collectively the “Notes”). The Company has entered, and may enter in the future, into interest rate swaps to
manage interest rate risk on the Notes. Interest rate swaps allow the Company to effectively convert fixed-rate payments to floating-rate payments or floating-rate payments into fixed-rate payments. In the third quarter of 2014, the Company entered
into interest rate swaps with an aggregate $9.0 billion notional, which effectively converted primarily all of the fixed-rate notes to a floating interest rate, and in the third quarter of 2013, the Company entered into interest rate swaps with an
aggregate $3.0 billion notional, which effectively converted the floating-rate notes to a fixed interest rate.

[0001193125-14-277160:mdna:105]
Capital Return Program

[0001193125-14-277160:mdna:106]
In April 2014, the Company’s Board of Directors increased the share repurchase program authorization from $60 billion to $90 billion of the Company’s common stock, of which $50.9 billion had
been utilized as of June 28, 2014. The share repurchase program is expected to be completed by the end of December 2015. The Company’s share repurchase program does not obligate it to acquire any specific number of shares. Under the
program, shares may be repurchased in privately negotiated or open market transactions, including under plans complying with Rule 10b5-1 under the Exchange Act.

[0001193125-14-277160:mdna:107]
The increase to the Company’s share repurchase program authorization resulted in a total capital return program of over $130 billion. The Company expects to complete the capital return program by the
end of December 2015 by paying dividends and dividend equivalents, repurchasing shares, and remitting withheld taxes related to net share settlement of restricted stock units. To assist in funding its capital return program, the Company expects to
access the public debt markets, both domestically and internationally.

[0001193125-14-277160:mdna:108]
The following table presents the Company’s
dividends, dividend equivalents, share repurchases and net share settlement activity from the start of the capital return program in August 2012 through the third quarter of 2014 (in millions):

[0001193125-14-277160:mdna:109]
|  |  | Dividends andDividendEquivalentsPaid |  |  | AcceleratedShareRepurchases |  |  | Open MarketShareRepurchases |  |  | Taxes Related toSettlement ofEquity Awards |  |  | Total |  |
| 2012 |  | $ | 2,488 |  |  | $ | 0 |  |  | $ | 0 |  |  | $ | 56 |  |  | $ | 2,544 |  |
| 2013 |  |  | 10,564 |  |  |  | 13,950 |  |  |  | 9,000 |  |  |  | 1,082 |  |  |  | 34,596 |  |
| Q1 2014 |  |  | 2,769 |  |  |  | 0 |  |  |  | 5,000 |  |  |  | 365 |  |  |  | 8,134 |  |
| Q2 2014 |  |  | 2,661 |  |  |  | 12,000 |  |  |  | 6,000 |  |  |  | 65 |  |  |  | 20,726 |  |
| Q3 2014 |  |  | 2,867 |  |  |  | 0 |  |  |  | 5,000 |  |  |  | 409 |  |  |  | 8,276 |  |
| Total |  | $ | 21,349 |  |  | $ | 25,950 |  |  | $ | 25,000 |  |  | $ | 1,977 |  |  | $ | 74,276 |  |

[0001193125-14-277160:mdna:110]
In April 2014, the Company’s Board of Directors raised the cash dividend by approximately 8%. The
Company paid cash dividends of $0.47 per common share, totaling $2.8 billion, in May 2014. The Company plans to increase its dividend on an annual basis, subject to declaration by the Board of Directors.

[0001193125-14-277160:mdna:111]
In addition to its capital return program activity, the Company also effected a seven-for-one split of its common stock on June 6,
2014.

[0001193125-14-277160:mdna:112]
[same as prior period, unchanged from 0001193125-14-157311:mdna:110]

[0001193125-14-277160:mdna:113]
[same as prior period, unchanged from 0001193125-14-157311:mdna:111]

[0001193125-14-277160:mdna:114]
[same as prior period, unchanged from 0001193125-14-157311:mdna:112]

[0001193125-14-277160:mdna:115]
The Company’s major facility leases are typically for terms not exceeding 10 years and generally provide renewal options for terms
not exceeding five additional years. Leases for retail space are for terms ranging from five to 20 years, the majority of which are for 10 years, and often contain multi-year renewal options. As of June 28, 2014, the Company’s total future
minimum lease payments under noncancelable operating leases were $5.0 billion, of which $3.8 billion related to leases for retail space.

[0001193125-14-277160:mdna:116]
[same as prior period, unchanged from 0001193125-14-157311:mdna:114]

[0001193125-14-277160:mdna:117]
The Company utilizes several outsourcing partners to manufacture sub-assemblies for the Company’s products and to perform final
assembly and testing of finished products. These outsourcing partners acquire components and build product based on demand information supplied by the Company, which typically covers periods up to 150 days. The Company also obtains individual
components for its products from a wide variety of individual suppliers. Consistent with industry practice, the Company acquires components through a combination of purchase orders, supplier contracts, and open orders based on projected demand
information. Where appropriate, the purchases are applied to inventory component prepayments that are outstanding with the respective supplier. As of June 28, 2014, the Company had outstanding off-balance sheet
third-party manufacturing commitments and component purchase commitments of $15.4 billion.

[0001193125-14-277160:mdna:118]
[same as prior period, unchanged from 0001193125-14-157311:mdna:116]

[0001193125-14-277160:mdna:119]
In addition to the commitments mentioned above, the Company had additional off-balance sheet obligations of $5.6 billion as of
June 28, 2014, that were comprised mainly of commitments to acquire capital assets, including product tooling and manufacturing process equipment, and commitments related to advertising, research and development, Internet and telecommunications
services and other obligations.

[0001193125-14-277160:mdna:120]
The Company’s other non-current liabilities in the Condensed Consolidated Balance Sheets
consist primarily of deferred tax liabilities, gross unrecognized tax benefits and the related gross interest and penalties. As of June 28, 2014, the Company had non-current deferred tax liabilities of $20.2 billion. Additionally, as of
June 28, 2014, the Company had gross unrecognized tax benefits of $3.1 billion and an additional $606 million for gross interest and penalties classified as non-current liabilities.

[0001193125-14-277160:mdna:121]
On May 28, 2014, the Company announced it entered into definitive agreements to acquire Beats Music, LLC, which offers a
subscription streaming music service, and Beats Electronics, LLC, which makes Beats headphones, speakers and audio software (collectively, “Beats”). The Company intends to acquire Beats for a total purchase price of approximately $2.6
billion, consisting primarily of cash. The Company also intends to issue approximately $400 million of its common stock, which will vest over time based on continued employment of certain executives of Beats. The transactions, which are subject to
regulatory approvals, are expected to close in the fourth quarter of 2014.

[0001193125-14-277160:mdna:122]
[same as prior period, unchanged from 0001193125-14-157311:mdna:119]

[0001193125-14-277160:mdna:123]
The Company generally does not indemnify end-users of its operating system and application software against legal claims that the software
infringes third-party intellectual property rights. Other agreements entered into by the Company sometimes include indemnification provisions under which the Company could be subject to costs and/or damages in the event of an infringement claim
against the Company or an indemnified third-party. However, the Company has not been required to make any significant payments resulting from such an infringement claim asserted against it or an indemnified third-party. In the opinion of management,
there was not at least a reasonable possibility the Company may have incurred a material loss with respect to indemnification of end-users of its operating system or application software for infringement of third-party intellectual property rights.
The Company did not record a liability for infringement costs related to indemnification as of June 28, 2014 or September 28, 2013.

[0001193125-14-277160:mdna:124]
The Company has entered into indemnification agreements with its directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent
permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum
potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, the Company maintains
directors and officers liability insurance coverage to reduce its exposure to such obligations, and payments made under these agreements historically have not been material.

[0001193125-14-277160:mdna:125]
[same as prior period, unchanged from 0001193125-14-157311:mdna:122]

[0001193125-14-277160:mdna:126]
[same as prior period, unchanged from 0001193125-14-157311:mdna:123]

[0001193125-14-277160:mdna:127]
Management believes the Company’s critical accounting policies and estimates are those related to revenue recognition,
valuation and impairment of marketable securities, inventory valuation and valuation of manufacturing-related assets and estimated purchase commitment cancellation fees, warranty costs, income taxes, and legal and other contingencies. Management
considers these policies critical because they are both important to the portrayal of the Company’s financial condition and operating results, and they require management to make judgments and estimates about inherently uncertain matters. The
Company’s senior management has reviewed these critical accounting policies and related disclosures with the Audit and Finance Committee of the Company’s Board of Directors.

[0001193125-14-277160:mdna:128]
[same as prior period, unchanged from 0001193125-14-157311:mdna:125]

[0001193125-14-277160:mdna:129]
Net sales consist primarily of revenue from the sale
of hardware, software, digital content and applications, peripherals, and service and support contracts. The Company recognizes revenue when persuasive evidence of an arrangement exists, delivery has occurred, the sales price is fixed or
determinable, and collection is probable. Product is considered delivered to the customer once it has been shipped and title and risk of loss have been transferred. For most of the Company’s product sales, these criteria are met at the time the
product is shipped. For online sales to individuals, for some sales to education customers in the U.S., and for certain other sales, the Company defers revenue until the customer receives the product because the Company retains a portion of the risk
of loss on these sales during transit. The Company recognizes revenue from the sale of hardware products, software bundled with hardware that is essential to the functionality of the hardware, and third-party digital content sold on the iTunes Store
in accordance with general revenue recognition accounting guidance. The Company recognizes revenue in accordance with industry specific software accounting guidance for the following types of sales transactions: (i) standalone sales of software
products, (ii) sales of software upgrades and (iii) sales of software bundled with hardware not essential to the functionality of the hardware.

[0001193125-14-277160:mdna:130]
For multi-element arrangements that include hardware products containing software essential to the hardware product’s functionality, undelivered software elements that relate to the hardware
product’s essential software, and/or undelivered non-software services, the Company allocates revenue to all deliverables based on their relative selling prices. In such circumstances, the Company uses a hierarchy to determine the selling price
to be used for allocating revenue to deliverables: (i) vendor-specific objective evidence of fair value (“VSOE”), (ii) third-party evidence of selling price (“TPE”) and (iii) best estimate of selling price
(“ESP”). VSOE generally exists only when the Company sells the deliverable separately and is the price actually charged by the Company for that deliverable. ESPs reflect the Company’s best estimates of what the selling prices of
elements would be if they were sold regularly on a stand-alone basis.

[0001193125-14-277160:mdna:131]
For sales of qualifying versions of iOS devices, Mac
and Apple TV, the Company has indicated it may from time to time provide future unspecified software upgrades and features free of charge to customers. The Company also provides various non-software services to owners of qualifying versions of iOS
devices and Mac. Because the Company has neither VSOE nor TPE for the unspecified software upgrade rights or the non-software services, revenue is allocated to these rights and services based on the Company’s ESPs. Revenue allocated to the
unspecified software upgrade rights and non-software services based on the Company’s ESPs is deferred and recognized on a straight-line basis over the estimated period the software upgrades and non-software services are expected to be provided
for each of these devices, which ranges from two to four years.

[0001193125-14-277160:mdna:132]
The Company’s process for determining ESPs involves management’s judgment and
considers multiple factors that may vary over time depending upon the unique facts and circumstances related to each deliverable. Should future facts and circumstances change, the Company’s ESPs and the future rate of related amortization for
software upgrades and non-software services related to future sales of these devices could change. Factors subject to change include the unspecified software upgrade rights offered, the estimated value of unspecified software upgrade rights, the
estimated or actual costs incurred to provide non-software services, and the estimated period software upgrades and non-software services are expected to be provided.

[0001193125-14-277160:mdna:133]
The Company records reductions to revenue for estimated commitments related to price protection and other customer incentive programs. For transactions involving price protection, the Company recognizes
revenue net of the estimated amount to be refunded, provided the refund amount can be reasonably and reliably estimated and the other conditions for revenue recognition have been met. The Company’s policy requires that, if refunds cannot be
reliably estimated, revenue is not recognized until reliable estimates can be made or the price protection lapses. For the Company’s other customer incentive programs, the estimated cost is recognized at the later of the date at which the
Company has sold the product or the date at which the program is offered. The Company also records reductions to revenue for expected future product returns based on the Company’s historical experience. Future market conditions and product
transitions may require the Company to increase customer incentive programs that could result in reductions to future revenue. Additionally, certain customer incentive programs require management to estimate the number of customers who will actually
redeem the incentive. Management’s estimates are based on historical experience and the specific terms and conditions of particular incentive programs. If a greater than estimated proportion of customers redeems such incentives, the Company
would be required to record additional reductions to revenue, which would have an adverse impact on the Company’s results of operations.

[0001193125-14-277160:mdna:134]
[same as prior period, unchanged from 0001193125-14-157311:mdna:131]

[0001193125-14-277160:mdna:135]
The Company’s investments in available-for-sale securities are reported at fair value. Unrealized gains and losses related to changes in the fair value of securities are recognized in accumulated
other comprehensive income, net of tax, in the Company’s Condensed Consolidated Balance Sheets. Changes in the fair value of available-for-sale securities impact the Company’s net income only when such securities are sold or an
other-than-temporary impairment is recognized. Realized gains and losses on the sale of securities are determined by specific identification of each security’s cost basis. The Company regularly reviews its investment portfolio to determine if
any security is other-than-temporarily impaired, which would require the Company to record an impairment charge in the period any such determination is made. In making this judgment, the Company evaluates, among other things, the duration and extent
to which the fair value of a security is less than its cost; the financial condition of the issuer and any changes thereto; and the Company’s intent to sell, or whether it will more likely than not be required to sell, the security before
recovery of its amortized cost basis. The Company’s assessment on whether a security is other-than-temporarily impaired could change in the future due to new developments or changes in assumptions related to any particular security.

[0001193125-14-277160:mdna:136]
Inventory Valuation and Valuation of Manufacturing-Related Assets and Estimated Purchase Commitment Cancellation Fees

[0001193125-14-277160:mdna:137]
The Company must order components for its products and build inventory in advance of product shipments and has invested in manufacturing
process equipment, including capital assets held at its suppliers’ facilities. In addition, the Company has made prepayments to certain of its suppliers associated with long-term supply agreements to secure supply of inventory components. The
Company records a write-down for inventories of components and products, including third-party products held for resale, which have become obsolete or are in excess of anticipated demand or net realizable value. The Company performs a detailed
review of inventory that considers multiple factors including demand forecasts, product life cycle status, product development plans, current sales levels, and component cost trends. The Company also reviews its manufacturing-related capital assets
and inventory prepayments for impairment whenever events or circumstances indicate the carrying amount of such assets may not be recoverable. If the Company determines that an asset is not recoverable, it records an impairment loss equal to the
amount by which the carrying value of such an asset exceeds its fair value.

[0001193125-14-277160:mdna:138]
The industries in which the Company competes are
subject to a rapid and unpredictable pace of product and component obsolescence and demand changes. In certain circumstances the Company may be required to record additional write-downs of inventory, inventory prepayments and/or
manufacturing-related capital assets. These circumstances include future demand or market conditions for the Company’s products being less favorable than forecasted, unforeseen technological changes or changes to the Company’s product
development plans that negatively impact the utility of any of these assets, or significant deterioration in the financial condition of one or more of the Company’s suppliers that hold any of the Company’s manufacturing process equipment
or to whom the Company has made an inventory prepayment. Such write-downs would adversely affect the Company’s results of operations in the period when the write-downs were recorded.

[0001193125-14-277160:mdna:139]
The Company records accruals for estimated cancellation fees related to component orders
that have been cancelled or are expected to be cancelled. Consistent with industry practice, the Company acquires components through a combination of purchase orders, supplier contracts, and open orders in each case based on projected demand. Where
appropriate, the purchases are applied to inventory component prepayments that are outstanding with the respective supplier. Purchase commitments typically cover the Company’s forecasted component and manufacturing
requirements for periods up to 150 days. If there is an abrupt and substantial decline in demand for one or more of the Company’s products, if the Company’s product development plans change, or if there is an unanticipated change in
technological requirements for any of the Company’s products, then the Company may be required to record additional accruals for cancellation fees that would adversely affect its results of operations in the period when the cancellation fees
are identified and recorded.

[0001193125-14-277160:mdna:140]
[same as prior period, unchanged from 0001193125-14-157311:mdna:137]

[0001193125-14-277160:mdna:141]
The Company provides for the estimated cost of warranties at the time the related revenue is recognized based on historical and projected warranty claim rates, historical and projected cost-per-claim, and
knowledge of specific product failures that are outside of the Company’s typical experience. Each quarter, the Company reevaluates these estimates to assess the adequacy of its recorded warranty liabilities considering the size of the installed
base of products subject to warranty protection and adjusts the amounts as necessary. If actual product failure rates or repair costs differ from estimates, revisions to the estimated warranty liabilities would be required and could materially
affect the Company’s results of operations.

[0001193125-14-277160:mdna:142]
[same as prior period, unchanged from 0001193125-14-157311:mdna:139]

[0001193125-14-277160:mdna:143]
[same as prior period, unchanged from 0001193125-14-157311:mdna:140]

[0001193125-14-277160:mdna:144]
[same as prior period, unchanged from 0001193125-14-157311:mdna:141]

[0001193125-14-277160:mdna:145]
[same as prior period, unchanged from 0001193125-14-157311:mdna:142]

[0001193125-14-277160:mdna:146]
Legal and Other Contingencies

[0001193125-14-277160:mdna:147]
As discussed in Part II, Item 1 of this Form 10-Q under the heading “Legal Proceedings” and in Note 10, “Commitments
and Contingencies” in the Notes to Condensed Consolidated Financial Statements of this Form 10-Q, the Company is subject to various legal proceedings and claims that arise in the ordinary course of business. The Company records a liability when
it is probable that a loss has been incurred and the amount is reasonably estimable. There is significant judgment required in both the probability determination and as to whether an exposure can be reasonably estimated. In the opinion of
management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to loss contingencies for legal and other contingencies. However, the outcome
of legal proceedings and claims brought against the Company is subject to significant uncertainty. Therefore, although management considers the likelihood of such an outcome to be remote, if one or more of these legal matters were resolved against
the Company in a reporting period for amounts in excess of management’s expectations, the Company’s consolidated financial statements for that reporting period could be materially adversely affected.
