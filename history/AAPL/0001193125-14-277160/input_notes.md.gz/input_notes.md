# AAPL notes — 0001193125-14-277160


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001193125-14-277160:notes:1]
Basis of Presentation and
 Preparation

[0001193125-14-277160:notes:2]
The accompanying
 condensed consolidated financial statements include the accounts of
 the Company. Intercompany accounts and transactions have been
 eliminated. The preparation of these condensed consolidated
 financial statements in conformity with U.S. generally accepted
 accounting principles (“GAAP”) requires management to
 make estimates and assumptions that affect the amounts reported in
 these condensed consolidated financial statements and accompanying
 notes. Actual results could differ materially from those
 estimates.

[0001193125-14-277160:notes:3]
These condensed
 consolidated financial statements and accompanying notes should be
 read in conjunction with the Company’s annual consolidated
 financial statements and the notes thereto for the fiscal year
 ended September 28, 2013, included in its Annual Report on
 Form 10-K (the “2013 Form 10-K”). The Company’s
 fiscal year is the 52 or 53-week period that ends on the last
 Saturday of September. An additional week is included in the first
 fiscal quarter approximately every six years to realign fiscal
 quarters with calendar quarters. The Company’s fiscal years
 2014 and 2013 include 52 weeks each. Unless otherwise stated,
 references to particular years, quarters or months refer to the
 Company’s fiscal years ended in September and the associated
 quarters or months of those fiscal years.

[0001193125-14-277160:notes:4]
During the first
 quarter of 2014, the Company adopted updated accounting standards
 that (i) required disclosure of additional information about
 the amounts reclassified out of Accumulated Other Comprehensive
 Income (“AOCI”) by component and (ii) required
 gross and net disclosures about offsetting assets and liabilities.
 The adoption of these updated standards only impacted the
 disclosures in the Notes to the Condensed Consolidated Financial
 Statements; accordingly, the adoption had no impact on the
 Company’s financial position or results of operations. The
 Company has provided these additional disclosures in this Form 10-Q
 in Note 8, “Comprehensive Income” and Note 2,
 “Financial Instruments,” respectively.


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001193125-14-277160:notes:5]
The following
 tables show the Company’s cash and available-for-sale
 securities’ adjusted cost, gross unrealized gains, gross
 unrealized losses and fair value by significant investment category
 recorded as cash and cash equivalents or short- or long-term
 marketable securities as of June 28, 2014 and
 September 28, 2013 (in millions):

[0001193125-14-277160:notes:6]
|  |  | June 28, 2014 |  |
|  |  | Adjusted Cost |  |  | Unrealized Gains |  |  | Unrealized Losses |  |  | Fair Value |  |  | Cash and Cash Equivalents |  |  | Short-Term Marketable Securities |  |  | Long-Term Marketable Securities |  |
| Cash |  | $ | 8,317 |  |  | $ | 0 |  |  | $ | 0 |  |  | $ | 8,317 |  |  | $ | 8,317 |  |  | $ | 0 |  |  | $ | 0 |  |
| Level 1 (a): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  |  | 1,257 |  |  |  | 0 |  |  |  | 0 |  |  |  | 1,257 |  |  |  | 1,257 |  |  |  | 0 |  |  |  | 0 |  |
| Mutual funds |  |  | 2,673 |  |  |  | 2 |  |  |  | (132 | ) |  |  | 2,543 |  |  |  | 0 |  |  |  | 2,543 |  |  |  | 0 |  |
| Subtotal |  |  | 3,930 |  |  |  | 2 |  |  |  | (132 | ) |  |  | 3,800 |  |  |  | 1,257 |  |  |  | 2,543 |  |  |  | 0 |  |
| Level 2 (b): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities |  |  | 35,320 |  |  |  | 26 |  |  |  | (4 | ) |  |  | 35,342 |  |  |  | 73 |  |  |  | 7,280 |  |  |  | 27,989 |  |
| U.S. agency securities |  |  | 7,804 |  |  |  | 6 |  |  |  | (7 | ) |  |  | 7,803 |  |  |  | 342 |  |  |  | 632 |  |  |  | 6,829 |  |
| Non-U.S. government securities |  |  | 6,292 |  |  |  | 78 |  |  |  | (51 | ) |  |  | 6,319 |  |  |  | 0 |  |  |  | 580 |  |  |  | 5,739 |  |
| Certificates of deposit and time deposits |  |  | 4,509 |  |  |  | 0 |  |  |  | 0 |  |  |  | 4,509 |  |  |  | 1,650 |  |  |  | 1,778 |  |  |  | 1,081 |  |
| Commercial paper |  |  | 5,144 |  |  |  | 0 |  |  |  | 0 |  |  |  | 5,144 |  |  |  | 1,338 |  |  |  | 3,806 |  |  |  | 0 |  |
| Corporate securities |  |  | 72,659 |  |  |  | 477 |  |  |  | (60 | ) |  |  | 73,076 |  |  |  | 0 |  |  |  | 7,718 |  |  |  | 65,358 |  |
| Municipal securities |  |  | 2,807 |  |  |  | 27 |  |  |  | (1 | ) |  |  | 2,833 |  |  |  | 0 |  |  |  | 430 |  |  |  | 2,403 |  |
| Mortgage- and asset-backed securities |  |  | 17,334 |  |  |  | 45 |  |  |  | (32 | ) |  |  | 17,347 |  |  |  | 0 |  |  |  | 61 |  |  |  | 17,286 |  |
| Subtotal |  |  | 151,869 |  |  |  | 659 |  |  |  | (155 | ) |  |  | 152,373 |  |  |  | 3,403 |  |  |  | 22,285 |  |  |  | 126,685 |  |
| Total |  | $ | 164,116 |  |  | $ | 661 |  |  | $ | (287 | ) |  | $ | 164,490 |  |  | $ | 12,977 |  |  | $ | 24,828 |  |  | $ | 126,685 |  |
|  |  | September 28, 2013 |  |
|  |  | Adjusted Cost |  |  | Unrealized Gains |  |  | Unrealized Losses |  |  | Fair Value |  |  | Cash and Cash Equivalents |  |  | Short-Term Marketable Securities |  |  | Long-Term Marketable Securities |  |
| Cash |  | $ | 8,705 |  |  | $ | 0 |  |  | $ | 0 |  |  | $ | 8,705 |  |  | $ | 8,705 |  |  | $ | 0 |  |  | $ | 0 |  |
| Level 1 (a): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  |  | 1,793 |  |  |  | 0 |  |  |  | 0 |  |  |  | 1,793 |  |  |  | 1,793 |  |  |  | 0 |  |  |  | 0 |  |
| Mutual funds |  |  | 3,999 |  |  |  | 0 |  |  |  | (197 | ) |  |  | 3,802 |  |  |  | 0 |  |  |  | 3,802 |  |  |  | 0 |  |
| Subtotal |  |  | 5,792 |  |  |  | 0 |  |  |  | (197 | ) |  |  | 5,595 |  |  |  | 1,793 |  |  |  | 3,802 |  |  |  | 0 |  |
| Level 2 (b): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities |  |  | 27,642 |  |  |  | 24 |  |  |  | (47 | ) |  |  | 27,619 |  |  |  | 431 |  |  |  | 7,554 |  |  |  | 19,634 |  |
| U.S. agency securities |  |  | 16,878 |  |  |  | 12 |  |  |  | (52 | ) |  |  | 16,838 |  |  |  | 177 |  |  |  | 3,412 |  |  |  | 13,249 |  |
| Non-U.S. government securities |  |  | 5,545 |  |  |  | 35 |  |  |  | (137 | ) |  |  | 5,443 |  |  |  | 50 |  |  |  | 313 |  |  |  | 5,080 |  |
| Certificates of deposit and time deposits |  |  | 2,344 |  |  |  | 0 |  |  |  | 0 |  |  |  | 2,344 |  |  |  | 1,264 |  |  |  | 844 |  |  |  | 236 |  |
| Commercial paper |  |  | 2,998 |  |  |  | 0 |  |  |  | 0 |  |  |  | 2,998 |  |  |  | 1,835 |  |  |  | 1,163 |  |  |  | 0 |  |
| Corporate securities |  |  | 54,586 |  |  |  | 275 |  |  |  | (252 | ) |  |  | 54,609 |  |  |  | 0 |  |  |  | 8,077 |  |  |  | 46,532 |  |
| Municipal securities |  |  | 6,257 |  |  |  | 45 |  |  |  | (22 | ) |  |  | 6,280 |  |  |  | 4 |  |  |  | 1,114 |  |  |  | 5,162 |  |
| Mortgage- and asset-backed securities |  |  | 16,396 |  |  |  | 23 |  |  |  | (89 | ) |  |  | 16,330 |  |  |  | 0 |  |  |  | 8 |  |  |  | 16,322 |  |
| Subtotal |  |  | 132,646 |  |  |  | 414 |  |  |  | (599 | ) |  |  | 132,461 |  |  |  | 3,761 |  |  |  | 22,485 |  |  |  | 106,215 |  |
| Total |  | $ | 147,143 |  |  | $ | 414 |  |  | $ | (796 | ) |  | $ | 146,761 |  |  | $ | 14,259 |  |  | $ | 26,287 |  |  | $ | 106,215 |  |

[0001193125-14-277160:notes:7]
| (a) | The fair value of Level 1 securities is estimated based on quoted prices in active markets for identical assets or liabilities. |

[0001193125-14-277160:notes:8]
| (b) | The fair value of Level 2 securities is estimated based on observable inputs other than quoted prices in active markets for identical assets and liabilities, quoted prices for identical or similar assets or liabilities in inactive markets, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities. |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-14-277160:notes:9]
Note 10 –
 Commitments and Contingencies

[0001193125-14-277160:notes:10]
Accrued Warranty and
 Indemnification

[0001193125-14-277160:notes:11]
The following
 table shows changes in the Company’s accrued warranties and
 related costs for the three- and nine-month periods ended
 June 28, 2014 and June 29, 2013 (in millions):

[0001193125-14-277160:notes:12]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 28, 2014 |  |  | June 29, 2013 |  |  | June 28, 2014 |  |  | June 29, 2013 |  |
| Beginning accrued warranty and related costs |  | $ | 4,368 |  |  | $ | 3,014 |  |  | $ | 2,967 |  |  | $ | 1,638 |  |
| Cost of warranty claims |  |  | (882 | ) |  |  | (1,033 | ) |  |  | (2,811 | ) |  |  | (2,566 | ) |
| Accruals for product warranty |  |  | 756 |  |  |  | 736 |  |  |  | 4,086 |  |  |  | 3,645 |  |
| Ending accrued warranty and related costs |  | $ | 4,242 |  |  | $ | 2,717 |  |  | $ | 4,242 |  |  | $ | 2,717 |  |

[0001193125-14-277160:notes:13]
The Company
 generally does not indemnify end-users of its operating system and
 application software against legal claims that the software
 infringes third-party intellectual property rights. Other
 agreements entered into by the Company sometimes include
 indemnification provisions under which the Company could be subject
 to costs and/or damages in the event of an infringement claim
 against the Company or an indemnified third-party. However, the
 Company has not been required to make any significant payments
 resulting from such an infringement claim asserted against it or an
 indemnified third-party. In the opinion of management, there was
 not at least a reasonable possibility the Company may have incurred
 a material loss with respect to indemnification of end-users of its
 operating system or application software for infringement of
 third-party intellectual property rights. The Company did not
 record a liability for infringement costs related to
 indemnification as of June 28, 2014 or September 28,
 2013.

[0001193125-14-277160:notes:14]
The Company has
 entered into indemnification agreements with its directors and
 executive officers. Under these agreements, the Company has agreed
 to indemnify such individuals to the fullest extent permitted by
 law against liabilities that arise by reason of their status as
 directors or officers and to advance expenses incurred by such
 individuals in connection with related legal proceedings. It is not
 possible to determine the maximum potential amount of payments the
 Company could be required to make under these agreements due to the
 limited history of prior indemnification claims and the unique
 facts and circumstances involved in each claim. However, the
 Company maintains directors and officers liability insurance
 coverage to reduce its exposure to such obligations, and payments
 made under these agreements historically have not been
 material.

[0001193125-14-277160:notes:15]
Concentrations in the
 Available Sources of Supply of Materials and Product

[0001193125-14-277160:notes:16]
Although most
 components essential to the Company’s business are generally
 available from multiple sources, a number of components are
 currently obtained from single or limited sources. In addition, the
 Company competes for various components with other participants in
 the markets for mobile communication and media devices and personal
 computers. Therefore, many components used by the Company,
 including those that are available from multiple sources, are at
 times subject to industry-wide shortage and significant pricing
 fluctuations that could materially adversely affect the
 Company’s financial condition and operating
 results.

[0001193125-14-277160:notes:17]
The Company
 uses some custom components that are not commonly used by its
 competitors, and new products introduced by the Company often
 utilize custom components available from only one source. When a
 component or product uses new technologies, initial capacity
 constraints may exist until the suppliers’ yields have
 matured or manufacturing capacity has increased. If the
 Company’s supply of components for a new or existing product
 were delayed or constrained, or if an outsourcing partner delayed
 shipments of completed products to the Company, the Company’s
 financial condition and operating results could be materially
 adversely affected. The Company’s business and financial
 performance could also be materially adversely affected depending
 on the time required to obtain sufficient quantities from the
 original source, or to identify and obtain sufficient quantities
 from an alternative source. Continued availability of these
 components at acceptable prices, or at all, may be affected if
 those suppliers concentrated on the production of common components
 instead of components customized to meet the Company’s
 requirements.

[0001193125-14-277160:notes:18]
The Company has
 entered into agreements for the supply of many components; however,
 there can be no guarantee that the Company will be able to extend
 or renew these agreements on similar terms, or at all. Therefore,
 the Company remains subject to significant risks of supply
 shortages and price increases that could materially adversely
 affect its financial condition and operating results.

[0001193125-14-277160:notes:19]
Substantially
 all of the Company’s hardware products are manufactured by
 outsourcing partners that are located primarily in Asia. A
 significant concentration of this manufacturing is currently
 performed by a small number of outsourcing partners, often in
 single locations. Certain of these outsourcing partners are the
 sole-sourced suppliers of components and manufacturers for many of
 the Company’s products. Although the Company works closely
 with its outsourcing partners on manufacturing schedules, the
 Company’s operating results could be adversely affected if
 its outsourcing partners were unable to meet their production
 commitments. The Company’s purchase commitments typically
 cover its requirements for periods up to 150 days.

[0001193125-14-277160:notes:20]
Other Off-Balance Sheet
 Commitments

[0001193125-14-277160:notes:21]
The Company
 leases various equipment and facilities, including retail space,
 under noncancelable operating lease arrangements. The Company does
 not currently utilize any other off-balance sheet financing
 arrangements. The major facility leases are typically for terms not
 exceeding 10 years and generally provide renewal options for terms
 not exceeding five additional years. Leases for retail space are
 for terms ranging from five to 20 years, the majority of which are
 for 10 years, and often contain multi-year renewal options. As of
 June 28, 2014, the Company’s total future minimum lease
 payments under noncancelable operating leases were $5.0 billion, of
 which $3.8 billion related to leases for retail space.

[0001193125-14-277160:notes:22]
The Company
 utilizes several outsourcing partners to manufacture sub-assemblies
 for the Company’s products and to perform final assembly and
 testing of finished products. These outsourcing partners acquire
 components and build product based on demand information supplied
 by the Company, which typically covers periods up to 150 days. The
 Company also obtains individual components for its products from a
 wide variety of individual suppliers. Consistent with industry
 practice, the Company acquires components through a combination of
 purchase orders, supplier contracts, and open orders based on
 projected demand information. Where
 appropriate, the purchases are applied to inventory
 component prepayments that are outstanding with
 the respective supplier. As of June 28, 2014, the Company
 had outstanding off-balance sheet third-party manufacturing
 commitments and component purchase commitments of $15.4
 billion.

[0001193125-14-277160:notes:23]
In addition to
 the commitments mentioned above, the Company had additional
 off-balance sheet obligations of $5.6 billion as of June 28,
 2014, which were comprised mainly of commitments to acquire capital
 assets, including product tooling and manufacturing process
 equipment, and commitments related to advertising, research and
 development, Internet and telecommunications services and other
 obligations.

[0001193125-14-277160:notes:24]
Contingencies

[0001193125-14-277160:notes:25]
The Company is
 subject to various legal proceedings and claims that have arisen in
 the ordinary course of business and that have not been fully
 adjudicated, certain of which are discussed in Part II, Item 1
 of this Form 10-Q under the heading “Legal Proceedings”
 and in Part II, Item 1A of this Form 10-Q under the heading
 “Risk Factors.” In the opinion of management, there was
 not at least a reasonable possibility the Company may have incurred
 a material loss, or a material loss in excess of a recorded
 accrual, with respect to loss contingencies. However, the outcome
 of litigation is inherently uncertain. Therefore, although
 management considers the likelihood of such an outcome to be
 remote, if one or more of these legal matters were resolved against
 the Company in a reporting period for amounts in excess of
 management’s expectations, the Company’s consolidated
 financial statements for that reporting period could be materially
 adversely affected.

[0001193125-14-277160:notes:26]
Apple Inc. v. Samsung
 Electronics Co., Ltd, et al.

[0001193125-14-277160:notes:27]
On
 August 24, 2012, a jury returned a verdict awarding the
 Company $1.05 billion in its lawsuit against Samsung Electronics
 Co., Ltd and affiliated parties in the United States District
 Court, Northern District of California, San Jose Division. On
 March 6, 2014, the Court entered final judgment in favor of
 the Company in the amount of approximately $930
 million. Because the award is now subject to appeal, the
 Company has not recognized the award in its results of
 operations.

[0001193125-14-277160:notes:28]
VirnetX, Inc. v. Apple
 Inc. et al.

[0001193125-14-277160:notes:29]
On
 August 11, 2010, VirnetX, Inc. filed an action against the
 Company alleging that certain of its products infringed on four
 patents relating to network communications technology. On
 November 6, 2012, a jury returned a verdict against the
 Company, and awarded damages of $368 million. On March 3,
 2014, the Court entered a ruling awarding a royalty of 0.98%
 against adjudicated products and products not colorably
 different than those adjudicated at trial. The Company has
 appealed the verdict, believes it has valid defenses and has not
 recorded a loss accrual at this time.


## us-gaap:DebtDisclosureTextBlock

[0001193125-14-277160:notes:30]
Note 6 –
 Debt

[0001193125-14-277160:notes:31]
Commercial
 Paper

[0001193125-14-277160:notes:32]
In April 2014,
 the Board of Directors authorized the Company to issue unsecured
 short-term promissory notes (“Commercial Paper”)
 pursuant to a commercial paper program. The Company intends to use
 net proceeds from the commercial paper program for general
 corporate purposes, including dividends and share repurchases. As
 of June 28, 2014, the Company had $2.0 billion of Commercial
 Paper outstanding, with a weighted average interest rate of 0.09%
 and maturities generally less than nine months.

[0001193125-14-277160:notes:33]
Long-Term
 Debt

[0001193125-14-277160:notes:34]
In the third
 quarter of 2014 and 2013, the Company issued $12.0 billion and
 $17.0 billion of long-term debt, respectively. The debt issuances
 included floating- and fixed-rate notes with varying maturities for
 an aggregate principal amount of $29.0 billion (collectively the
 “Notes”). The Notes are senior unsecured obligations,
 and interest is payable in arrears, quarterly for the floating-rate
 notes and semi-annually for the fixed-rate notes.

[0001193125-14-277160:notes:35]
The following table
 provides a summary of the Company’s long-term debt as of
 June 28, 2014 and September 28, 2013:

[0001193125-14-277160:notes:36]
|  |  | As of June 28, 2014 |  |  | As of September 28, 2013 |  |
|  |  | Amount (in millions) |  |  | Effective Interest Rate |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |
| Floating-rate notes due 2016 |  | $ | 1,000 |  |  |  | 0.51% |  |  | $ | 1,000 |  |  |  | 0.51% |  |
| Floating-rate notes due 2017 |  |  | 1,000 |  |  |  | 0.29% |  |  |  | 0 |  |  |  | 0 |  |
| Floating-rate notes due 2018 |  |  | 2,000 |  |  |  | 1.10% |  |  |  | 2,000 |  |  |  | 1.10% |  |
| Floating-rate notes due 2019 |  |  | 1,000 |  |  |  | 0.52% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 0.45% notes due 2016 |  |  | 1,500 |  |  |  | 0.51% |  |  |  | 1,500 |  |  |  | 0.51% |  |
| Fixed-rate 1.05% notes due 2017 |  |  | 1,500 |  |  |  | 0.29% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 1.00% notes due 2018 |  |  | 4,000 |  |  |  | 1.08% |  |  |  | 4,000 |  |  |  | 1.08% |  |
| Fixed-rate 2.10% notes due 2019 |  |  | 2,000 |  |  |  | 0.52% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.85% notes due 2021 |  |  | 3,000 |  |  |  | 0.77% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.40% notes due 2023 |  |  | 5,500 |  |  |  | 2.44% |  |  |  | 5,500 |  |  |  | 2.44% |  |
| Fixed-rate 3.45% notes due 2024 |  |  | 2,500 |  |  |  | 0.88% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 3.85% notes due 2043 |  |  | 3,000 |  |  |  | 3.91% |  |  |  | 3,000 |  |  |  | 3.91% |  |
| Fixed-rate 4.45% notes due 2044 |  |  | 1,000 |  |  |  | 4.48% |  |  |  | 0 |  |  |  | 0 |  |
| Total |  |  | 29,000 |  |  |  |  |  |  |  | 17,000 |  |  |  |  |  |
| Unamortized discount |  |  | (53 | ) |  |  |  |  |  |  | (40 | ) |  |  |  |  |
| Hedge accounting fair value adjustments |  |  | 83 |  |  |  |  |  |  |  | 0 |  |  |  |  |  |
| Total |  | $ | 29,030 |  |  |  |  |  |  | $ | 16,960 |  |  |  |  |  |

[0001193125-14-277160:notes:37]
The Company has
 entered, and may enter in the future, into interest rate swaps to
 manage interest rate risk on the Notes. Such swaps allow the
 Company to effectively convert fixed-rate payments to floating-rate
 or floating-rate payments into fixed-rate payments. In the third
 quarter of 2013, the Company entered into interest rate
 swaps with an aggregate $3.0 billion notional, which
 effectively converted the floating-rate notes due 2016 and 2018 to
 a fixed interest rate. In the third quarter of 2014, the Company
 entered into interest rate swaps with an aggregate $9.0 billion
 notional, which effectively converted the fixed-rate notes due
 2017, 2019, 2021 and 2024 to a floating interest rate.

[0001193125-14-277160:notes:38]
The effective
 rates for the Notes include the interest on the Notes, amortization
 of the discount and, if applicable, adjustments related to hedging.
 The Company recognized $100 million and $268 million of interest
 expense on its long-term debt for the three- and nine-month periods
 ended June 28, 2014, respectively.

[0001193125-14-277160:notes:39]
Future principal payments
 for the Company’s Notes as of June 28, 2014, are as
 follows (in millions):

[0001193125-14-277160:notes:40]
| 2014 |  | $ | 0 |  |
| 2015 |  |  | 0 |  |
| 2016 |  |  | 2,500 |  |
| 2017 |  |  | 2,500 |  |
| 2018 |  |  | 6,000 |  |
| Thereafter |  |  | 18,000 |  |
| Total |  | $ | 29,000 |  |

[0001193125-14-277160:notes:41]
As of
 June 28, 2014 and September 28, 2013, the fair value of
 the Company’s Notes, based on Level 2 inputs, was $28.5
 billion and $15.9 billion, respectively.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001193125-14-277160:notes:42]
Earnings Per
 Share

[0001193125-14-277160:notes:43]
Basic earnings
 per share is computed by dividing income available to common
 shareholders by the weighted-average number of shares of common
 stock outstanding during the period. Diluted earnings per share is
 computed by dividing income available to common shareholders by the
 weighted-average number of shares of common stock outstanding
 during the period increased to include the number of additional
 shares of common stock that would have been outstanding if the
 potentially dilutive securities had been issued. Potentially
 dilutive securities include outstanding stock options, shares to be
 purchased under the Company’s employee stock purchase plan
 and unvested restricted stock units (“RSUs”). The
 dilutive effect of potentially dilutive securities is reflected in
 diluted earnings per share by application of the treasury stock
 method. Under the treasury stock method, an increase in the fair
 market value of the Company’s common stock can result in a
 greater dilutive effect from potentially dilutive
 securities.

[0001193125-14-277160:notes:44]
The following
 table shows the computation of basic and diluted earnings per share
 for the three- and nine-month periods ended June 28, 2014 and
 June 29, 2013 (in thousands, except net income in millions and
 per share amounts):

[0001193125-14-277160:notes:45]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 28, 2014 |  |  | June 29, 2013 |  |  | June 28, 2014 |  |  | June 29, 2013 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 7,748 |  |  | $ | 6,900 |  |  | $ | 31,043 |  |  | $ | 29,525 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding |  |  | 6,012,635 |  |  |  | 6,430,323 |  |  |  | 6,136,147 |  |  |  | 6,526,714 |  |
| Effect of dilutive securities |  |  | 39,076 |  |  |  | 39,531 |  |  |  | 36,710 |  |  |  | 47,491 |  |
| Weighted-average diluted shares |  |  | 6,051,711 |  |  |  | 6,469,854 |  |  |  | 6,172,857 |  |  |  | 6,574,205 |  |
| Basic earnings per share |  | $ | 1.29 |  |  | $ | 1.07 |  |  | $ | 5.06 |  |  | $ | 4.52 |  |
| Diluted earnings per share |  | $ | 1.28 |  |  | $ | 1.07 |  |  | $ | 5.03 |  |  | $ | 4.49 |  |

[0001193125-14-277160:notes:46]
Potentially
 dilutive securities, the effect of which would have been
 antidilutive, were not significant for the three- and nine-month
 periods ended June 28, 2014 and the three- and nine-month
 periods ended June 29, 2013. The Company excluded these
 securities from the computation of diluted earnings per
 share.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001193125-14-277160:notes:47]
[same as prior period, unchanged from 0001193125-14-157311:notes:101]

[0001193125-14-277160:notes:48]
[same as prior period, unchanged from 0001193125-14-157311:notes:102]

[0001193125-14-277160:notes:49]
[same as prior period, unchanged from 0001193125-14-157311:notes:103]

[0001193125-14-277160:notes:50]
[same as prior period, unchanged from 0001193125-14-157311:notes:104]

[0001193125-14-277160:notes:51]
[same as prior period, unchanged from 0001193125-14-157311:notes:106]

[0001193125-14-277160:notes:52]
Common Stock
 Split

[0001193125-14-277160:notes:53]
On June 6,
 2014, the Company effected a seven-for-one stock split to
 shareholders of record as of June 2, 2014. All share and per
 share information has been retroactively adjusted to reflect the
 stock split.

[0001193125-14-277160:notes:54]
Revenue
 Recognition

[0001193125-14-277160:notes:55]
In 2013, the
 Company’s combined best estimates of selling price
 (“ESPs”) for the unspecified software upgrade rights
 and the rights to receive the non-software services included with
 its qualifying hardware devices ranged from $5 to $25. Beginning in
 the first quarter of 2014, the Company adjusted the combined ESPs
 for Mac from $20 to $40 to reflect additions to unspecified
 software upgrade rights related to expansion of bundled essential
 software.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-14-277160:notes:56]
[same as prior period, unchanged from 0001193125-14-157311:notes:122]

[0001193125-14-277160:notes:57]
The
 Company’s acquired intangible assets with definite
 useful lives primarily consist of patents and licenses and are
 amortized over periods typically from three to seven years. The
 following table summarizes the components of gross and net
 intangible asset balances as of June 28, 2014 and
 September 28, 2013 (in millions):

[0001193125-14-277160:notes:58]
|  |  | June 28, 2014 |  |  | September 28, 2013 |  |
|  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Carrying Amount |  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Carrying Amount |  |
| Definite-lived and amortizable acquired intangible assets |  | $ | 6,472 |  |  | $ | (2,805 | ) |  | $ | 3,667 |  |  | $ | 6,081 |  |  | $ | (2,002 | ) |  | $ | 4,079 |  |
| Indefinite-lived and non-amortizable acquired intangible assets |  |  | 100 |  |  |  | 0 |  |  |  | 100 |  |  |  | 100 |  |  |  | 0 |  |  |  | 100 |  |
| Total acquired intangible assets |  | $ | 6,572 |  |  | $ | (2,805 | ) |  | $ | 3,767 |  |  | $ | 6,181 |  |  | $ | (2,002 | ) |  | $ | 4,179 |  |

[0001193125-14-277160:notes:59]
During the nine
 months ended June 28, 2014, the Company completed various
 business acquisitions. The aggregate cash consideration paid, net
 of cash acquired, was $898 million, of which $789 million was
 allocated to goodwill, $247 million to acquired intangible assets
 and $138 million to net liabilities assumed. During the nine months
 ended June 29, 2013, the aggregate cash consideration paid,
 net of cash acquired, was $443 million, of which $369 million was
 allocated to goodwill, $167 million to acquired intangible assets
 and $93 million to net liabilities assumed.


## us-gaap:ScheduleOfDerivativeInstrumentsInStatementOfFinancialPositionFairValueTextBlock

[0001193125-14-277160:notes:60]
The following
 tables show the Company’s derivative instruments at gross
 fair value as reflected in the Condensed Consolidated Balance
 Sheets as of June 28, 2014 and September 28, 2013 (in
 millions):

[0001193125-14-277160:notes:61]
|  |  | June 28, 2014 |  |
|  |  | Fair Value of Derivatives Designated as Hedge Instruments |  |  | Fair Value of Derivatives Not Designated as Hedge Instruments |  |  | Total Fair Value |  |
| Derivative assets (a): |  |  |  |  |
| Foreign exchange contracts |  | $ | 132 |  |  | $ | 22 |  |  | $ | 154 |  |
| Interest rate contracts |  | $ | 121 |  |  | $ | 0 |  |  | $ | 121 |  |
| Derivative liabilities (b): |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 69 |  |  | $ | 51 |  |  | $ | 120 |  |
|  |  | September 28, 2013 |  |
|  |  | Fair Value of Derivatives Designated as Hedge Instruments |  |  | Fair Value of Derivatives Not Designated as Hedge Instruments |  |  | Total Fair Value |  |
| Derivative assets (a): |  |  |  |  |
| Foreign exchange contracts |  | $ | 145 |  |  | $ | 25 |  |  | $ | 170 |  |
| Interest rate contracts |  | $ | 44 |  |  | $ | 0 |  |  | $ | 44 |  |
| Derivative liabilities (b): |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 389 |  |  | $ | 46 |  |  | $ | 435 |  |

[0001193125-14-277160:notes:62]
| (a) | The fair value of derivative assets is measured using Level 2 fair value inputs and is recorded as other current assets in the Condensed Consolidated Balance Sheets. |

[0001193125-14-277160:notes:63]
| (b) | The fair value of derivative liabilities is measured using Level 2 fair value inputs and is recorded as accrued expenses in the Condensed Consolidated Balance Sheets. |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001193125-14-277160:notes:64]
[same as prior period, unchanged from 0001193125-14-157311:notes:31]

[0001193125-14-277160:notes:65]
|  |  | June 28, 2014 |  |  | September 28, 2013 |  |
| Components |  | $ | 315 |  |  | $ | 683 |  |
| Finished goods |  |  | 1,279 |  |  |  | 1,081 |  |
| Total inventories |  | $ | 1,594 |  |  | $ | 1,764 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-14-277160:notes:66]
[same as prior period, unchanged from 0001193125-14-157311:notes:126]

[0001193125-14-277160:notes:67]
[same as prior period, unchanged from 0001193125-14-157311:notes:127]

[0001193125-14-277160:notes:68]
The Company
 manages its business primarily on a geographic basis. The
 Company’s reportable operating segments consist of the
 Americas, Europe, Greater China, Japan, Rest of Asia Pacific and
 Retail operations. The Americas segment includes both North and
 South America. The Europe segment includes European countries, as
 well as India, the Middle East and Africa. The Greater China
 segment includes China, Hong Kong and Taiwan. The Rest of Asia
 Pacific segment includes Australia and Asian countries, other than
 those countries included in the Company’s other operating
 segments. The results of the Company’s geographic segments do
 not include results of the Retail segment. Each operating segment
 provides similar hardware and software products and similar
 services. The accounting policies of the various segments are the
 same as those described in Note 1, “Summary of Significant
 Accounting Policies” of the Notes to Consolidated Financial
 Statements in Part II, Item 8 of the Company’s 2013 Form
 10-K.

[0001193125-14-277160:notes:69]
[same as prior period, unchanged from 0001193125-14-157311:notes:129]

[0001193125-14-277160:notes:70]
The following
 table shows information by operating segment for the three- and
 nine-month periods ended June 28, 2014 and June 29, 2013
 (in millions):

[0001193125-14-277160:notes:71]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 28, 2014 |  |  | June 29, 2013 |  |  | June 28, 2014 |  |  | June 29, 2013 |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 14,577 |  |  | $ | 14,405 |  |  | $ | 48,985 |  |  | $ | 48,798 |  |
| Operating income |  | $ | 5,717 |  |  | $ | 5,140 |  |  | $ | 18,416 |  |  | $ | 17,637 |  |
| Europe: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 8,091 |  |  | $ | 7,614 |  |  | $ | 31,394 |  |  | $ | 29,878 |  |
| Operating income |  | $ | 3,016 |  |  | $ | 2,450 |  |  | $ | 11,345 |  |  | $ | 10,308 |  |
| Greater China: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 5,935 |  |  | $ | 4,641 |  |  | $ | 24,068 |  |  | $ | 19,684 |  |
| Operating income |  | $ | 2,173 |  |  | $ | 1,440 |  |  | $ | 8,837 |  |  | $ | 6,771 |  |
| Japan: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 2,564 |  |  | $ | 2,543 |  |  | $ | 11,475 |  |  | $ | 10,121 |  |
| Operating income |  | $ | 1,289 |  |  | $ | 1,343 |  |  | $ | 5,560 |  |  | $ | 5,158 |  |
| Rest of Asia Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 2,161 |  |  | $ | 2,046 |  |  | $ | 8,421 |  |  | $ | 9,201 |  |
| Operating income |  | $ | 721 |  |  | $ | 729 |  |  | $ | 2,948 |  |  | $ | 3,098 |  |
| Retail: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 4,104 |  |  | $ | 4,074 |  |  | $ | 16,329 |  |  | $ | 15,756 |  |
| Operating income |  | $ | 711 |  |  | $ | 667 |  |  | $ | 3,606 |  |  | $ | 3,316 |  |

[0001193125-14-277160:notes:72]
A
 reconciliation of the Company’s segment operating income to
 the condensed consolidated financial statements for the three- and
 nine-month periods ended June 28, 2014 and June 29, 2013
 is as follows (in millions):

[0001193125-14-277160:notes:73]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 28, 2014 |  |  | June 29, 2013 |  |  | June 28, 2014 |  |  | June 29, 2013 |  |
| Segment operating income |  | $ | 13,627 |  |  | $ | 11,769 |  |  | $ | 50,712 |  |  | $ | 46,288 |  |
| Research and development expense (a) |  |  | (1,290 | ) |  |  | (933 | ) |  |  | (3,453 | ) |  |  | (2,599 | ) |
| Share-based compensation expense |  |  | (724 | ) |  |  | (578 | ) |  |  | (2,101 | ) |  |  | (1,698 | ) |
| Other corporate expenses, net |  |  | (1,331 | ) |  |  | (1,057 | ) |  |  | (3,820 | ) |  |  | (3,022 | ) |
| Total operating income |  | $ | 10,282 |  |  | $ | 9,201 |  |  | $ | 41,338 |  |  | $ | 38,969 |  |

[0001193125-14-277160:notes:74]
| (a) | Amount excludes research and development share-based compensation expense. |


## us-gaap:InterestAndOtherIncomeTableTextBlock

[0001193125-14-277160:notes:75]
[same as prior period, unchanged from 0001193125-14-157311:notes:1]

[0001193125-14-277160:notes:76]
The following
 table shows the detail of other income and expense for the three-
 and nine-month periods ended June 28, 2014 and June 29,
 2013 (in millions):

[0001193125-14-277160:notes:77]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 28, 2014 |  |  | June 29, 2013 |  |  | June 28, 2014 |  |  | June 29, 2013 |  |
| Interest and dividend income |  | $ | 439 |  |  | $ | 385 |  |  | $ | 1,276 |  |  | $ | 1,226 |  |
| Interest expense |  |  | (100 | ) |  |  | (53 | ) |  |  | (269 | ) |  |  | (53 | ) |
| Other expense, net |  |  | (137 | ) |  |  | (98 | ) |  |  | (334 | ) |  |  | (130 | ) |
| Total other income/(expense), net |  | $ | 202 |  |  | $ | 234 |  |  | $ | 673 |  |  | $ | 1,043 |  |


## us-gaap:OtherNoncurrentLiabilitiesTableTextBlock

[0001193125-14-277160:notes:78]
[same as prior period, unchanged from 0001193125-14-157311:notes:114]

[0001193125-14-277160:notes:79]
|  |  | June 28, 2014 |  |  | September 28, 2013 |  |
| Deferred tax liabilities |  | $ | 20,159 |  |  | $ | 16,489 |  |
| Other non-current liabilities |  |  | 3,128 |  |  |  | 3,719 |  |
| Total other non-current liabilities |  | $ | 23,287 |  |  | $ | 20,208 |  |


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0001193125-14-277160:notes:80]
The following
 table shows a summary of the share-based compensation expense
 included in the Condensed Consolidated Statements of Operations for
 the three- and nine-month periods ended June 28, 2014 and
 June 29, 2013 (in millions):

[0001193125-14-277160:notes:81]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 28, 2014 |  |  | June 29, 2013 |  |  | June 28, 2014 |  |  | June 29, 2013 |  |
| Cost of sales |  | $ | 115 |  |  | $ | 90 |  |  | $ | 334 |  |  | $ | 262 |  |
| Research and development |  |  | 313 |  |  |  | 245 |  |  |  | 902 |  |  |  | 708 |  |
| Selling, general and administrative |  |  | 296 |  |  |  | 243 |  |  |  | 865 |  |  |  | 728 |  |
| Total share-based compensation expense |  | $ | 724 |  |  | $ | 578 |  |  | $ | 2,101 |  |  | $ | 1,698 |  |


## us-gaap:DerivativesPolicyTextBlock

[0001193125-14-277160:notes:82]
Derivative Financial
 Instruments

[0001193125-14-277160:notes:83]
The Company
 uses derivatives to partially offset its business exposure to
 foreign currency and interest rate risk. The Company may enter into
 forward contracts, option contracts, swaps, or other derivative
 instruments to offset some of the risk on expected future cash
 flows, on net investments in certain foreign subsidiaries, and on
 certain existing assets and liabilities. However, the Company may
 choose not to hedge certain exposures for a variety of reasons
 including, but not limited to, accounting considerations and the
 prohibitive economic cost of hedging particular exposures. There
 can be no assurance the hedges will offset more than a portion of
 the financial impact resulting from movements in foreign currency
 exchange or interest rates.

[0001193125-14-277160:notes:84]
To help protect
 gross margins from fluctuations in foreign currency exchange rates,
 certain of the Company’s subsidiaries whose functional
 currency is the U.S. dollar hedge a portion of forecasted foreign
 currency revenue. The Company’s subsidiaries whose functional
 currency is not the U.S. dollar and who sell in local currencies
 may hedge a portion of forecasted inventory purchases not
 denominated in the subsidiaries’ functional currencies. The
 Company typically hedges portions of its forecasted foreign
 currency exposure associated with revenue and inventory purchases,
 typically for up to 12 months.

[0001193125-14-277160:notes:85]
To help protect
 the net investment in a foreign operation from adverse changes in
 foreign currency exchange rates, the Company may enter into foreign
 currency forward and option contracts to offset the changes in the
 carrying amounts of these investments due to fluctuations in
 foreign currency exchange rates.

[0001193125-14-277160:notes:86]
The Company may
 also enter into foreign currency forward contracts and option
 contracts to partially offset the foreign currency exchange gains
 and losses generated by the re-measurement of certain assets and
 liabilities denominated in non-functional currencies.

[0001193125-14-277160:notes:87]
The Company may
 enter into interest rate swaps, options, or other instruments to
 manage interest rate risk. These instruments may offset a portion
 of changes in income or expense, or changes in fair value of the
 Company’s long-term debt or investments.

[0001193125-14-277160:notes:88]
The Company
 records all derivatives in the Condensed Consolidated Balance
 Sheets at fair value. The Company’s accounting treatment for
 these instruments is based on the hedge designation. The effective
 portions of cash flow hedges are recorded in AOCI until the hedged
 item is recognized in earnings. Gains and losses related to changes
 in fair value hedges are recognized in earnings along with a
 corresponding loss or gain related to the change in value of the
 underlying hedged item. The effective portions of net investment
 hedges are recorded in other comprehensive income
 (“OCI”) as a part of the cumulative translation
 adjustment. The ineffective portions of cash flow hedges and net
 investment hedges are recorded in other income and expense.
 Derivatives that are not designated as hedging instruments are
 adjusted to fair value through earnings in the financial statement
 line item to which the derivative relates.

[0001193125-14-277160:notes:89]
Deferred gains
 and losses associated with cash flow hedges of foreign currency
 revenue are recognized as a component of net sales in the same
 period as the related revenue is recognized, and deferred gains and
 losses related to cash flow hedges of inventory purchases are
 recognized as a component of cost of sales in the same period as
 the related costs are recognized. Deferred gains and losses
 associated with cash flow hedges of interest income or expense are
 recognized as a component of other income/(expense), net in the
 same period as the related income or expense is recognized. The
 Company’s foreign currency and interest rate transactions
 hedged with cash flow hedges as of June 28, 2014 are expected
 to occur within 12 months and four years, respectively.

[0001193125-14-277160:notes:90]
Derivative
 instruments designated as cash flow hedges must be de-designated as
 hedges when it is probable the forecasted hedged transaction will
 not occur in the initially identified time period or within a
 subsequent two-month time period. Deferred gains and losses in AOCI
 associated with such derivative instruments are reclassified
 immediately into other income and expense. Any subsequent changes
 in fair value of such derivative instruments are reflected in other
 income and expense unless they are re-designated as hedges of other
 transactions. The Company did not recognize any significant net
 gains or losses related to the loss of hedge designation on
 discontinued cash flow hedges during the three- and nine-month
 periods ended June 28, 2014 and June 29, 2013.

[0001193125-14-277160:notes:91]
The
 Company’s unrealized net gains and losses on net investment
 hedges, included in the cumulative translation adjustment account
 of AOCI, were not significant as of June 28, 2014 and
 September 28, 2013. The ineffective portions and amounts
 excluded from the effectiveness test of net investment hedges are
 recorded in other income and expense.

[0001193125-14-277160:notes:92]
The gain/loss
 recognized in other income and expense for foreign currency forward
 and option contracts not designated as hedging instruments was not
 significant during the three- and nine-month periods ended
 June 28, 2014 and June 29, 2013.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001193125-14-277160:notes:93]
[same as prior period, unchanged from 0001193125-14-157311:notes:33]

[0001193125-14-277160:notes:94]
[same as prior period, unchanged from 0001193125-14-157311:notes:34]

[0001193125-14-277160:notes:95]
The Company may
 sell certain of its marketable securities prior to their stated
 maturities for strategic reasons including, but not limited to,
 anticipation of credit deterioration and duration management. The
 net realized gains or losses recognized by the Company related to
 such sales were not significant during the three- and nine-month
 periods ended June 28, 2014 and June 29, 2013. The
 maturities of the Company’s long-term marketable securities
 generally range from one to five years.

[0001193125-14-277160:notes:96]
As of
 June 28, 2014 and September 28, 2013, gross unrealized
 losses related to individual securities that had been in a
 continuous loss position for 12 months or longer were not
 significant.

[0001193125-14-277160:notes:97]
As of
 June 28, 2014, the Company considers the declines in market
 value of its marketable securities investment portfolio to be
 temporary in nature and does not consider any of its investments
 other-than-temporarily impaired. The Company typically invests in
 highly-rated securities, and its investment policy limits the
 amount of credit exposure to any one issuer. The policy generally
 requires investments to be investment grade, with the primary
 objective of minimizing the potential risk of principal loss. Fair
 values were determined for each individual security in the
 investment portfolio. When evaluating an investment for
 other-than-temporary impairment the Company reviews factors such as
 the length of time and extent to which fair value has been below
 its cost basis, the financial condition of the issuer and any
 changes thereto, changes in market interest rates, and the
 Company’s intent to sell, or whether it is more likely than
 not it will be required to sell the investment before recovery of
 the investment’s cost basis. During the three- and nine-month
 periods ended June 28, 2014 and June 29, 2013, the
 Company did not recognize any significant impairment
 charges.

[0001193125-14-277160:notes:98]
The following
 table shows the notional principal amounts of the Company’s
 outstanding derivative instruments and credit risk amounts
 associated with outstanding or unsettled derivative instruments as
 of June 28, 2014 and September 28, 2013 (in
 millions):

[0001193125-14-277160:notes:99]
|  |  | June 28, 2014 |  |  | September 28, 2013 |  |
|  |  | Notional Principal |  |  | Credit Risk |  |  | Notional Principal |  |  | Credit Risk |  |
| Instruments designated as accounting hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 22,996 |  |  | $ | 132 |  |  | $ | 35,013 |  |  | $ | 159 |  |
| Interest rate contracts |  | $ | 12,000 |  |  | $ | 121 |  |  | $ | 3,000 |  |  | $ | 44 |  |
| Instruments not designated as accounting hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 21,559 |  |  | $ | 22 |  |  | $ | 16,131 |  |  | $ | 25 |  |

[0001193125-14-277160:notes:100]
[same as prior period, unchanged from 0001193125-14-157311:notes:56]

[0001193125-14-277160:notes:101]
The Company
 generally enters into master netting arrangements, which are
 designed to reduce credit risk by permitting net settlement of
 transactions with the same counterparty. To further limit credit
 risk, the Company generally enters into collateral security
 arrangements that provide for collateral to be received or posted
 when the net fair value of certain financial instruments fluctuates
 from contractually established thresholds. The Company presents its
 derivative assets and derivative liabilities at their gross fair
 values. As of June 28, 2014, the Company received $27 million
 of net cash collateral related to the derivative instruments under
 its collateral security arrangements, which were recorded as
 accrued expenses in the Condensed Consolidated Balance Sheet. As of
 September 28, 2013, the Company posted cash collateral related
 to the derivative instruments under its collateral security
 arrangements of $164 million, which it recorded as other current
 assets in the Condensed Consolidated Balance Sheet. The
 Company did not have any derivative instruments with credit-risk
 related contingent features that would require it to post
 additional collateral as of June 28, 2014 or
 September 28, 2013.

[0001193125-14-277160:notes:102]
Under master
 netting arrangements with the respective counterparties to the
 Company’s derivative contracts, the Company is allowed
 to net settle transactions with a single net amount payable by one
 party to the other. However, the Company has elected to
 present the derivative assets and derivative liabilities on a gross
 basis in its Condensed Consolidated Balance Sheets. As of
 June 28, 2014 and September 28, 2013, the potential
 effects of these rights of set-off associated with the
 Company’s derivative contracts, including the effects of
 collateral, would be a reduction to both derivative assets and
 derivative liabilities of $140 million and $333 million,
 respectively, resulting in net derivative assets of $128
 million and net derivative liabilities of $57 million,
 respectively.

[0001193125-14-277160:notes:103]
The following
 tables show the pre-tax effect of the Company’s derivative
 instruments designated as cash flow, net investment and fair value
 hedges in the Condensed Consolidated Statements of Operations for
 the three- and nine-month periods ended June 28, 2014 and
 June 29, 2013 (in millions):

[0001193125-14-277160:notes:104]
|  |  | Three Months Ended |  |
|  |  | June 28, 2014 |  |  | June 29, 2013 |  |  | June 28, 2014 |  |  | June 29, 2013 |  |  |  |  | June 28, 2014 |  |  | June 29, 2013 |  |
|  |  | Gains/(Losses) Recognized in OCI - Effective Portion |  |  | Gains/(Losses) Reclassified from AOCI into Net Income - Effective Portion |  |  | Financial Statement Line Item |  | Gains/(Losses) Recognized – Ineffective Portion and Amount Excluded from Effectiveness Testing |  |
| Cash flow hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | (73 | ) |  | $ | 272 |  |  | $ | (29 | ) |  | $ | 492 |  |  | Other income/(expense), net |  | $ | (52 | ) |  | $ | (63 | ) |
| Interest rate contracts |  |  | (10 | ) |  |  | 33 |  |  |  | (4 | ) |  |  | (2 | ) |  | Other income/(expense), net |  |  | 0 |  |  |  | 0 |  |
| Total |  | $ | (83 | ) |  | $ | 305 |  |  | $ | (33 | ) |  | $ | 490 |  |  |  |  | $ | (52 | ) |  | $ | (63 | ) |
| Net investment hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | (5 | ) |  | $ | 26 |  |  | $ | 0 |  |  | $ | 0 |  |  | Other income/(expense), net |  | $ | 0 |  |  | $ | 0 |  |
|  |  | Gains/(Losses) On Derivative Instruments |  |  | Gains/(Losses) Related to Hedged Items |  |  |  |  |  |  |  |  |  |
| Fair value hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate contracts |  | $ | 83 |  |  | $ | 0 |  |  | $ | (83 | ) |  | $ | 0 |  |  | Other income/(expense), net |  | $ | 0 |  |  | $ | 0 |  |
|  |  | Nine Months Ended |  |
|  |  | June 28, 2014 |  |  | June 29, 2013 |  |  | June 28, 2014 |  |  | June 29, 2013 |  |  |  |  | June 28, 2014 |  |  | June 29, 2013 |  |
|  |  | Gains/(Losses) Recognized in OCI - Effective Portion |  |  | Gains/(Losses) Reclassified from AOCI into Net Income - Effective Portion |  |  | Financial Statement Line Item |  | Gains/(Losses) Recognized – Ineffective Portion and Amount Excluded from Effectiveness Testing |  |
| Cash flow hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 70 |  |  | $ | 1,218 |  |  | $ | (81 | ) |  | $ | 304 |  |  | Other income/(expense), net |  | $ | (63 | ) |  | $ | (115 | ) |
| Interest rate contracts |  |  | (16 | ) |  |  | 33 |  |  |  | (12 | ) |  |  | (2 | ) |  | Other income/(expense), net |  |  | 0 |  |  |  | 0 |  |
| Total |  | $ | 54 |  |  | $ | 1,251 |  |  | $ | (93 | ) |  | $ | 302 |  |  |  |  | $ | (63 | ) |  | $ | (115 | ) |
| Net investment hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 0 |  |  | $ | 132 |  |  | $ | 0 |  |  | $ | 0 |  |  | Other income/(expense), net |  | $ | 1 |  |  | $ | 1 |  |
|  |  | Gains/(Losses) On Derivative Instruments |  |  | Gains/(Losses) Related to Hedged Items |  |  |  |  |  |  |  |  |  |
| Fair value hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate contracts |  | $ | 83 |  |  | $ | 0 |  |  | $ | (83 | ) |  | $ | 0 |  |  | Other income/(expense), net |  | $ | 0 |  |  | $ | 0 |  |

[0001193125-14-277160:notes:105]
[same as prior period, unchanged from 0001193125-14-157311:notes:67]

[0001193125-14-277160:notes:106]
The Company has
 considerable trade receivables outstanding with its third-party
 cellular network carriers, wholesalers, retailers, value-added
 resellers, small and mid-sized businesses, and education,
 enterprise and government customers that are not covered by
 collateral, third-party financing arrangements or credit insurance.
 As of June 28, 2014, the Company had two customers that
 represented 10% or more of total trade receivables, one of which
 accounted for 12% and the other 11%. As of September 28, 2013,
 the Company had two customers that represented 10% or more of total
 trade receivables, one of which accounted for 13% and the other
 10%. The Company’s cellular network carriers accounted for
 55% and 68% of trade receivables as of June 28, 2014 and
 September 28, 2013, respectively.

[0001193125-14-277160:notes:107]
Additionally,
 the Company has non-trade receivables from certain of its
 manufacturing vendors resulting from the sale of components to
 these manufacturing vendors who manufacture sub-assemblies or
 assemble final products for the Company. Three of the
 Company’s vendors accounted for 50%, 19% and 13% of total
 vendor non-trade receivables as of June 28, 2014 and three of
 the Company’s vendors accounted for 47%, 21% and 15% of total
 vendor non-trade receivables as of September 28,
 2013.


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001193125-14-277160:notes:108]
[same as prior period, unchanged from 0001193125-14-157311:notes:72]

[0001193125-14-277160:notes:109]
|  |  | June 28, 2014 |  |  | September 28, 2013 |  |
| Accrued warranty and related costs |  | $ | 4,242 |  |  | $ | 2,967 |  |
| Accrued marketing and selling expenses |  |  | 1,686 |  |  |  | 1,291 |  |
| Accrued taxes |  |  | 1,437 |  |  |  | 1,200 |  |
| Accrued compensation and employee benefits |  |  | 1,234 |  |  |  | 959 |  |
| Deferred margin on component sales |  |  | 890 |  |  |  | 1,262 |  |
| Other current liabilities |  |  | 5,775 |  |  |  | 6,177 |  |
| Total accrued expenses |  | $ | 15,264 |  |  | $ | 13,856 |  |


## us-gaap:ScheduleOfNonvestedRestrictedStockUnitsActivityTableTextBlock

[0001193125-14-277160:notes:110]
A summary of the
 Company’s RSU activity and related information for the nine
 months ended June 28, 2014, is as follows:

[0001193125-14-277160:notes:111]
|  |  | Number of RSUs (in thousands) |  |  | Weighted-Average Grant Date Fair Value |  |  | Aggregate Intrinsic Value (in millions) |  |
| Balance at September 28, 2013 |  |  | 93,284 |  |  | $ | 62.24 |  |  |  |  |  |
| RSUs granted |  |  | 53,730 |  |  | $ | 72.18 |  |  |  |  |  |
| RSUs vested |  |  | (35,529 | ) |  | $ | 58.87 |  |  |  |  |  |
| RSUs cancelled |  |  | (4,401 | ) |  | $ | 67.64 |  |  |  |  |  |
| Balance at June 28, 2014 |  |  | 107,084 |  |  | $ | 68.12 |  |  | $ | 9,850 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-14-277160:notes:112]
The following table shows
 the changes in AOCI by component for the nine months ended
 June 28, 2014 (in millions):

[0001193125-14-277160:notes:113]
|  |  | Cumulative Foreign Currency Translation |  |  | Unrecognized Gains/Losses on Derivative Instruments |  |  | Unrealized Gains/Losses on Marketable Securities |  |  | Total |  |
| September 28, 2013 |  | $ | (105 | ) |  | $ | (175 | ) |  | $ | (191 | ) |  | $ | (471 | ) |
| Other comprehensive income/(loss) before reclassifications |  |  | (38 | ) |  |  | 43 |  |  |  | 838 |  |  |  | 843 |  |
| Amounts reclassified from AOCI |  |  | 0 |  |  |  | 107 |  |  |  | (127 | ) |  |  | (20 | ) |
| Tax effect |  |  | 3 |  |  |  | (26 | ) |  |  | (243 | ) |  |  | (266 | ) |
| Other comprehensive income/(loss) |  |  | (35 | ) |  |  | 124 |  |  |  | 468 |  |  |  | 557 |  |
| June 28, 2014 |  | $ | (140 | ) |  | $ | (51 | ) |  | $ | 277 |  |  | $ | 86 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-14-277160:notes:114]
Note 7 –
 Shareholders’ Equity

[0001193125-14-277160:notes:115]
Preferred and Common
 Stock

[0001193125-14-277160:notes:116]
During the
 second quarter of 2014, the Company’s shareholders approved
 amendments (the “Amendments”) to the Company’s
 Restated Articles of Incorporation. The Amendments included the
 elimination of the Board of Directors’ authority to issue
 preferred stock and established a par value for the Company’s
 common stock of $0.00001 per share.

[0001193125-14-277160:notes:117]
[same as prior period, unchanged from 0001193125-14-157311:notes:81]

[0001193125-14-277160:notes:118]
The Company declared and
 paid cash dividends per common share during the periods presented
 as follows:

[0001193125-14-277160:notes:119]
|  |  | Dividends Per Share |  |  | Amount (in millions) |  |
| 2014: |  |  |  |  |  |  |  |  |
| Third quarter |  | $ | 0.47 |  |  | $ | 2,830 |  |
| Second quarter |  |  | 0.44 |  |  |  | 2,655 |  |
| First quarter |  |  | 0.44 |  |  |  | 2,739 |  |
| Total |  | $ | 1.35 |  |  | $ | 8,224 |  |
| 2013: |  |  |  |  |  |  |  |  |
| Fourth quarter |  | $ | 0.44 |  |  | $ | 2,763 |  |
| Third quarter |  |  | 0.44 |  |  |  | 2,789 |  |
| Second quarter |  |  | 0.38 |  |  |  | 2,490 |  |
| First quarter |  |  | 0.38 |  |  |  | 2,486 |  |
| Total |  | $ | 1.64 |  |  | $ | 10,528 |  |

[0001193125-14-277160:notes:120]
Future dividends are
 subject to declaration by the Board of Directors.

[0001193125-14-277160:notes:121]
Share Repurchase
 Program

[0001193125-14-277160:notes:122]
In 2012, the
 Company’s Board of Directors authorized a program to
 repurchase up to $10 billion of the Company’s common stock
 beginning in 2013. In April 2013, the Company’s Board of
 Directors increased the share repurchase authorization from $10
 billion to $60 billion. In April 2014, the Company’s Board of
 Directors increased the share repurchase authorization from $60
 billion to $90 billion, of which $50.9 billion had been utilized as
 of June 28, 2014. The Company’s share repurchase program
 does not obligate it to acquire any specific number of shares.
 Under the program, shares may be repurchased in privately
 negotiated and/or open market transactions, including under plans
 complying with Rule 10b5-1 under the Securities Exchange Act of
 1934, as amended (the “Exchange Act”).

[0001193125-14-277160:notes:123]
The Company has
 entered into three accelerated share repurchase arrangements
 (“ASRs”) with financial institutions beginning in
 August 2012. In exchange for up-front payments, the financial
 institutions deliver shares of the Company’s common stock
 during the purchase periods of each ASR. The total number of shares
 ultimately delivered, and therefore the average repurchase price
 paid per share, will be determined at the end of the applicable
 purchase period of each ASR based on the volume weighted-average
 price of the Company’s common stock during that period. The
 shares received are retired in the periods they are delivered, and
 the up-front payments are accounted for as a reduction to
 shareholders’ equity in the Company’s Condensed
 Consolidated Balance Sheet in the periods the payments are made.
 The Company reflects the ASRs as a repurchase of common stock in
 the period delivered for purposes of calculating earnings per share
 and as forward contracts indexed to its own common stock. The ASRs
 met all of the applicable criteria for equity classification, and,
 therefore, were not accounted for as derivative
 instruments.

[0001193125-14-277160:notes:124]
The following table
 presents the Company’s ASRs:

[0001193125-14-277160:notes:125]
|  |  | Purchase Period End Date |  |  | Number of Shares (in thousands) |  |  | Average Repurchase Price Per Share |  |  | ASR Amount (in millions) |  |
| January 2014 ASR |  |  | (a | ) |  |  | 134,247(a) |  |  |  | (a | ) |  | $ | 12,000 |  |
| April 2013 ASR |  |  | March 2014 |  |  |  | 172,548(b) |  |  | $ | 69.55 |  |  | $ | 12,000 |  |
| August 2012 ASR |  |  | April 2013 |  |  |  | 28,544 |  |  | $ | 68.31 |  |  | $ | 1,950 |  |

[0001193125-14-277160:notes:126]
[same as prior period, unchanged from 0001193125-14-157311:notes:89]

[0001193125-14-277160:notes:127]
| (b) | Includes 8.0 million shares that were delivered and retired at the end of the purchase period, which concluded in the second quarter of 2014. |

[0001193125-14-277160:notes:128]
The Company
 repurchased shares of its common stock in the open market, which
 were retired upon repurchase, during the periods presented as
 follows:

[0001193125-14-277160:notes:129]
|  |  | Number of Shares (in thousands) |  |  | Average Repurchase Price Per Share |  |  | Amount (in millions) |  |
| 2014: |  |  |  |  |  |  |  |  |  |  |  |  |
| Third quarter |  |  | 58,661 |  |  | $ | 85.23 |  |  | $ | 5,000 |  |
| Second quarter |  |  | 79,749 |  |  | $ | 75.24 |  |  |  | 6,000 |  |
| First quarter |  |  | 66,847 |  |  | $ | 74.79 |  |  |  | 5,000 |  |
| Total |  |  | 205,257 |  |  |  |  |  |  | $ | 16,000 |  |
| 2013: |  |  |  |  |  |  |  |  |  |  |  |  |
| Fourth quarter |  |  | 73,064 |  |  | $ | 68.43 |  |  | $ | 5,000 |  |
| Third quarter |  |  | 62,676 |  |  | $ | 63.82 |  |  |  | 4,000 |  |
| Second quarter |  |  | 0 |  |  | $ | 0 |  |  |  | 0 |  |
| First quarter |  |  | 0 |  |  | $ | 0 |  |  |  | 0 |  |
| Total |  |  | 135,740 |  |  |  |  |  |  | $ | 9,000 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-14-277160:notes:130]
[same as prior period, unchanged from 0001193125-14-157311:notes:118]

[0001193125-14-277160:notes:131]
As of
 June 28, 2014, the Company recorded gross unrecognized tax
 benefits of $3.1 billion, of which $1.6 billion, if recognized,
 would affect the Company’s effective tax rate. As of
 September 28, 2013, the total amount of gross unrecognized tax
 benefits was $2.7 billion, of which $1.4 billion, if recognized,
 would affect the Company’s effective tax rate. Additionally,
 the Company had $606 million and $590 million of gross interest and
 penalties accrued as of June 28, 2014 and September 28,
 2013, respectively. The Company’s unrecognized tax benefits,
 interest and penalties are presented net of related tax deposits
 and are classified as other non-current liabilities in the
 Condensed Consolidated Balance Sheets.

[0001193125-14-277160:notes:132]
[same as prior period, unchanged from 0001193125-14-157311:notes:120]

[0001193125-14-277160:notes:133]
Management
 believes that an adequate provision has been made for any
 adjustments that may result from tax examinations. However, the
 outcome of tax audits cannot be predicted with certainty. If any
 issues addressed in the Company’s tax audits are resolved in
 a manner not consistent with management’s expectations, the
 Company could be required to adjust its provision for income tax in
 the period such resolution occurs. Although timing of the
 resolution and/or closure of audits is not certain, the Company
 believes it is reasonably possible that tax audit resolutions could
 reduce its unrecognized tax benefits by between $400 million and
 $550 million in the next 12 months.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001193125-14-277160:notes:134]
[same as prior period, unchanged from 0001193125-14-157311:notes:116]

[0001193125-14-277160:notes:135]
The following
 tables show the Company’s condensed consolidated financial
 statement details as of June 28, 2014 and September 28,
 2013 (in millions):

[0001193125-14-277160:notes:136]
Property, Plant and
 Equipment

[0001193125-14-277160:notes:137]
|  |  | June 28, 2014 |  |  | September 28, 2013 |  |
| Land and buildings |  | $ | 4,448 |  |  | $ | 3,309 |  |
| Machinery, equipment and internal-use software |  |  | 25,595 |  |  |  | 21,242 |  |
| Leasehold improvements |  |  | 4,410 |  |  |  | 3,968 |  |
| Gross property, plant and equipment |  |  | 34,453 |  |  |  | 28,519 |  |
| Accumulated depreciation and amortization |  |  | (16,868 | ) |  |  | (11,922 | ) |
| Net property, plant and equipment |  | $ | 17,585 |  |  | $ | 16,597 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-14-277160:notes:138]
[same as prior period, unchanged from 0001193125-14-157311:notes:110]

[0001193125-14-277160:notes:139]
Comprehensive
 income consists of two components, net income and OCI. OCI refers
 to revenue, expenses, and gains and losses that under GAAP are
 recorded as an element of shareholders’ equity but are
 excluded from net income. The Company’s OCI consists of
 foreign currency translation adjustments from those subsidiaries
 not using the U.S. dollar as their functional currency, net
 deferred gains and losses on certain derivative instruments
 accounted for as cash flow hedges, and unrealized gains and losses
 on marketable securities classified as
 available-for-sale.

[0001193125-14-277160:notes:140]
The following
 table shows the gross amounts reclassified from AOCI into the
 Condensed Consolidated Statements of Operations and the associated
 financial statement line item, for the three- and nine-month
 periods ended June 28, 2014 (in millions):

[0001193125-14-277160:notes:141]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| Comprehensive Income Components |  | Financial Statement Line Item |  | June 28, 2014 |  |
| Unrecognized gains/losses on derivative instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Revenue |  | $ | 86 |  |  | $ | 389 |  |
|  |  | Cost of sales |  |  | (57 | ) |  |  | (308 | ) |
|  |  | Other income/expense, net |  |  | 0 |  |  |  | 14 |  |
| Interest rate contracts |  | Other income/expense, net |  |  | 4 |  |  |  | 12 |  |
|  |  |  |  |  | 33 |  |  |  | 107 |  |
| Unrealized gains/losses on marketable securities |  | Other income/expense, net |  |  | (50 | ) |  |  | (127 | ) |
| Total amounts reclassified from AOCI |  |  |  | $ | (17 | ) |  | $ | (20 | ) |


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001193125-14-277160:notes:142]
[same as prior period, unchanged from 0001193125-14-157311:notes:10]

[0001193125-14-277160:notes:143]
[same as prior period, unchanged from 0001193125-14-157311:notes:11]

[0001193125-14-277160:notes:144]
The Company had
 495.7 million shares reserved for future issuance under its
 stock plans as of June 28, 2014. RSUs granted reduce the
 number of shares available for grant under the Company’s
 stock plans utilizing a factor of two times the number of RSUs
 granted. Similarly, RSUs cancelled and shares withheld to satisfy
 tax withholding obligations increase the number of shares available
 for grant under the Company’s stock plans utilizing a factor
 of two times the number of RSUs cancelled or shares withheld. Stock
 options count against the number of shares available for grant on a
 one-for-one basis.

[0001193125-14-277160:notes:145]
[same as prior period, unchanged from 0001193125-14-157311:notes:13]

[0001193125-14-277160:notes:146]
In the second
 quarter of 2014, shareholders approved the 2014 Employee Stock Plan
 (the “2014 Plan”) and terminated the Company’s
 authority to grant new awards under the 2003 Employee Stock Plan
 (the “2003 Plan”). The 2014 Plan provides for
 broad-based equity grants to employees, including executive
 officers, and permits the granting of stock options, stock
 appreciation rights, stock grants and RSUs, as well as cash bonus
 awards. RSUs granted under the 2014 Plan are settled upon vesting
 in shares of the Company’s common stock on a one-for-one
 basis. Currently, all RSUs granted under the 2014 Plan have
 dividend equivalent rights (“DERs”), which entitle
 holders of RSUs to the same dividend value per share as holders of
 common stock. DERs are subject to the same vesting and other terms
 and conditions as the corresponding unvested RSUs. DERs are
 accumulated and paid when the underlying shares vest. Upon approval
 of the 2014 Plan, the Company reserved 385 million shares plus
 any shares that were reserved but not issued under the 2003 Plan
 for future issuance.

[0001193125-14-277160:notes:147]
[same as prior period, unchanged from 0001193125-14-157311:notes:15]

[0001193125-14-277160:notes:148]
During the
 three months ended June 28, 2014, Section 16 officers
 Timothy D. Cook, Luca Maestri, Peter Oppenheimer, Daniel Riccio,
 Philip W. Schiller, D. Bruce Sewell and Jeffrey E. Williams and
 director William V. Campbell had equity trading plans in place in
 accordance with Rule 10b5-1(c)(1) under the Exchange Act. An equity
 trading plan is a written document that pre-establishes the
 amounts, prices and dates (or formula for determining the amounts,
 prices and dates) of future purchases or sales of the
 Company’s stock, including shares acquired pursuant to the
 Company’s employee and director equity plans.

[0001193125-14-277160:notes:149]
[same as prior period, unchanged from 0001193125-14-157311:notes:17]

[0001193125-14-277160:notes:150]
RSUs that
 vested during the three- and nine-month periods ended June 28,
 2014 had fair values of $1.3 billion and $2.6 billion,
 respectively, as of the vesting date. RSUs that vested during the
 three- and nine-month periods ended June 29, 2013 had fair
 values of $1.2 billion and $2.9 billion, respectively, as of the
 vesting date.

[0001193125-14-277160:notes:151]
[same as prior period, unchanged from 0001193125-14-157311:notes:21]

[0001193125-14-277160:notes:152]
The Company had
 13.1 million stock options outstanding as of June 28,
 2014, with a weighted average exercise price per share of $22.39
 and weighted average remaining contractual term of 1.1 years,
 substantially all of which are exercisable. The aggregate intrinsic
 value of the stock options outstanding as of June 28, 2014 was
 $908 million, which represents the value of the Company’s
 closing stock price on the last trading day of the period in excess
 of the weighted-average exercise price multiplied by the number of
 options outstanding.

[0001193125-14-277160:notes:153]
The total
 intrinsic value of options at the time of exercise was $271 million
 and $978 million for the three- and nine-month periods ended
 June 28, 2014, respectively, and $180 million and $738 million
 for the three- and nine-month periods ended June 29, 2013,
 respectively.

[0001193125-14-277160:notes:154]
[same as prior period, unchanged from 0001193125-14-157311:notes:24]

[0001193125-14-277160:notes:155]
Share-based
 compensation cost for RSUs is measured based on the closing fair
 market value of the Company’s common stock on the date of
 grant. Share-based compensation cost for stock options and employee
 stock purchase plan rights (“stock purchase rights”) is
 measured at the grant date and offering date, respectively, based
 on the fair value as calculated by the Black-Scholes-Merton
 (“BSM”) option-pricing model. The BSM option-pricing
 model incorporates various assumptions including expected
 volatility, estimated expected life and interest rates. The
 Company recognizes share-based compensation cost over the
 award’s requisite service period on a straight-line basis for
 time-based RSUs and on a graded basis for RSUs that are contingent
 on the achievement of performance metrics.

[0001193125-14-277160:notes:156]
The income tax
 benefit related to share-based compensation expense was $260
 million and $755 million for the three- and nine-month periods
 ended June 28, 2014, respectively, and was $197 million and
 $606 million for the three- and nine-month periods ended
 June 29, 2013, respectively. As of June 28, 2014, the
 total unrecognized compensation cost related to outstanding stock
 options and RSUs expected to vest was $6.1 billion, which the
 Company expects to recognize over a weighted-average period of 2.9
 years.
