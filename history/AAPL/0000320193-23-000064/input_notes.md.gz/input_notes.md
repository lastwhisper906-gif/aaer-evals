# AAPL notes — 0000320193-23-000064


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000320193-23-000064:notes:1]
[same as prior period, unchanged from 0000320193-23-000006:notes:1]

[0000320193-23-000064:notes:2]
[same as prior period, unchanged from 0000320193-23-000006:notes:2]

[0000320193-23-000064:notes:3]
[same as prior period, unchanged from 0000320193-23-000006:notes:3]

[0000320193-23-000064:notes:4]
[same as prior period, unchanged from 0000320193-23-000006:notes:4]

[0000320193-23-000064:notes:5]
The following table shows the computation of basic and diluted earnings per share for the three- and six-month periods ended April 1, 2023 and March 26, 2022 (net income in millions and shares in thousands):

[0000320193-23-000064:notes:6]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1,2023 |  | March 26,2022 |  | April 1,2023 |  | March 26,2022 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 24,160 |  |  | $ | 25,010 |  |  | $ | 54,158 |  |  | $ | 59,640 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 15,787,154 |  |  | 16,278,802 |  |  | 15,839,939 |  |  | 16,335,263 |  |
| Effect of dilutive securities | 59,896 |  |  | 124,514 |  |  | 61,445 |  |  | 126,041 |  |
| Weighted-average diluted shares | 15,847,050 |  |  | 16,403,316 |  |  | 15,901,384 |  |  | 16,461,304 |  |
| Basic earnings per share | $ | 1.53 |  |  | $ | 1.54 |  |  | $ | 3.42 |  |  | $ | 3.65 |  |
| Diluted earnings per share | $ | 1.52 |  |  | $ | 1.52 |  |  | $ | 3.41 |  |  | $ | 3.62 |  |

[0000320193-23-000064:notes:7]
Approximately 48 million restricted stock units (“RSUs”) were excluded from the computation of diluted earnings per share for the six months ended April 1, 2023 because their effect would have been antidilutive.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000320193-23-000064:notes:8]
Revenue
Net sales disaggregated by significant products and services for the three- and six-month periods ended April 1, 2023 and March 26, 2022 were as follows (in millions):

[0000320193-23-000064:notes:9]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1,2023 |  | March 26,2022 |  | April 1,2023 |  | March 26,2022 |
| iPhone® | $ | 51,334 |  |  | $ | 50,570 |  |  | $ | 117,109 |  |  | $ | 122,198 |  |
| Mac® | 7,168 |  |  | 10,435 |  |  | 14,903 |  |  | 21,287 |  |
| iPad® | 6,670 |  |  | 7,646 |  |  | 16,066 |  |  | 14,894 |  |
| Wearables, Home and Accessories | 8,757 |  |  | 8,806 |  |  | 22,239 |  |  | 23,507 |  |
| Services | 20,907 |  |  | 19,821 |  |  | 41,673 |  |  | 39,337 |  |
| Total net sales | $ | 94,836 |  |  | $ | 97,278 |  |  | $ | 211,990 |  |  | $ | 221,223 |  |

[0000320193-23-000064:notes:10]
Total net sales include $3.5 billion of revenue recognized in the three months ended April 1, 2023 that was included in deferred revenue as of December 31, 2022, $3.0 billion of revenue recognized in the three months ended March 26, 2022 that was included in deferred revenue as of December 25, 2021, $5.5 billion of revenue recognized in the six months ended April 1, 2023 that was included in deferred revenue as of September 24, 2022, and $4.8 billion of revenue recognized in the six months ended March 26, 2022 that was included in deferred revenue as of September 25, 2021.

[0000320193-23-000064:notes:11]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 10, “Segment Information and Geographic Data” for the three- and six-month periods ended April 1, 2023 and March 26, 2022, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.

[0000320193-23-000064:notes:12]
As of April 1, 2023 and September 24, 2022, the Company had total deferred revenue of $12.5 billion and $12.4 billion, respectively. As of April 1, 2023, the Company expects 65% of total deferred revenue to be realized in less than a year, 26% within one-to-two years, 7% within two-to-three years and 2% in greater than three years.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000320193-23-000064:notes:13]
[same as prior period, unchanged from 0000320193-23-000006:notes:16]

[0000320193-23-000064:notes:14]
The following tables show the Company’s cash, cash equivalents and marketable securities by significant investment category as of April 1, 2023 and September 24, 2022 (in millions):

[0000320193-23-000064:notes:15]
|  | April 1, 2023 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | CurrentMarketableSecurities |  | Non-CurrentMarketableSecurities |
| Cash | $ | 20,050 |  |  | $ | — |  |  | $ | — |  |  | $ | 20,050 |  |  | $ | 20,050 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 1,656 |  |  | — |  |  | — |  |  | 1,656 |  |  | 1,656 |  |  | — |  |  | — |  |
| Mutual funds | 345 |  |  | 5 |  |  | (26) |  |  | 324 |  |  | — |  |  | 324 |  |  | — |  |
| Subtotal | 2,001 |  |  | 5 |  |  | (26) |  |  | 1,980 |  |  | 1,656 |  |  | 324 |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 22,754 |  |  | 1 |  |  | (1,262) |  |  | 21,493 |  |  | 9 |  |  | 8,002 |  |  | 13,482 |  |
| U.S. agency securities | 5,743 |  |  | — |  |  | (538) |  |  | 5,205 |  |  | — |  |  | 199 |  |  | 5,006 |  |
| Non-U.S. government securities | 17,380 |  |  | 20 |  |  | (961) |  |  | 16,439 |  |  | — |  |  | 10,222 |  |  | 6,217 |  |
| Certificates of deposit and time deposits | 2,999 |  |  | — |  |  | — |  |  | 2,999 |  |  | 2,881 |  |  | 118 |  |  | — |  |
| Commercial paper | 271 |  |  | — |  |  | — |  |  | 271 |  |  | — |  |  | 271 |  |  | — |  |
| Corporate debt securities | 82,802 |  |  | 32 |  |  | (6,049) |  |  | 76,785 |  |  | 91 |  |  | 11,676 |  |  | 65,018 |  |
| Municipal securities | 790 |  |  | — |  |  | (20) |  |  | 770 |  |  | — |  |  | 257 |  |  | 513 |  |
| Mortgage- and asset-backed securities | 22,438 |  |  | 9 |  |  | (2,106) |  |  | 20,341 |  |  | — |  |  | 116 |  |  | 20,225 |  |
| Subtotal | 155,177 |  |  | 62 |  |  | (10,936) |  |  | 144,303 |  |  | 2,981 |  |  | 30,861 |  |  | 110,461 |  |
| Total (3) | $ | 177,228 |  |  | $ | 67 |  |  | $ | (10,962) |  |  | $ | 166,333 |  |  | $ | 24,687 |  |  | $ | 31,185 |  |  | $ | 110,461 |  |

[0000320193-23-000064:notes:16]
[same as prior period, unchanged from 0000320193-23-000006:notes:19]

[0000320193-23-000064:notes:17]
[same as prior period, unchanged from 0000320193-23-000006:notes:20]

[0000320193-23-000064:notes:18]
[same as prior period, unchanged from 0000320193-23-000006:notes:21]

[0000320193-23-000064:notes:19]
(3)As of April 1, 2023 and September 24, 2022, total marketable securities included $13.1 billion and $12.7 billion, respectively, that were restricted from general use, related to the State Aid Decision (refer to Note 5, “Income Taxes”) and other agreements.

[0000320193-23-000064:notes:20]
The following table shows the fair value of the Company’s non-current marketable debt securities, by contractual maturity, as of April 1, 2023 (in millions):

[0000320193-23-000064:notes:21]
| Due after 1 year through 5 years | $ | 81,352 |  |
| Due after 5 years through 10 years | 11,928 |  |
| Due after 10 years | 17,181 |  |
| Total fair value | $ | 110,461 |  |

[0000320193-23-000064:notes:22]
[same as prior period, unchanged from 0000320193-23-000006:notes:25]

[0000320193-23-000064:notes:23]
[same as prior period, unchanged from 0000320193-23-000006:notes:26]

[0000320193-23-000064:notes:24]
[same as prior period, unchanged from 0000320193-23-000006:notes:27]

[0000320193-23-000064:notes:25]
[same as prior period, unchanged from 0000320193-23-000006:notes:28]

[0000320193-23-000064:notes:26]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in foreign currency exchange rates, the Company may enter into forward contracts, cross-currency swaps or other instruments. The Company designates these instruments as either cash flow or fair value hedges. As of April 1, 2023, the maximum length of time over which the Company is hedging its exposure to the variability in future cash flows for term debt–related foreign currency transactions is 19 years.

[0000320193-23-000064:notes:27]
[same as prior period, unchanged from 0000320193-23-000006:notes:30]

[0000320193-23-000064:notes:28]
[same as prior period, unchanged from 0000320193-23-000006:notes:31]

[0000320193-23-000064:notes:29]
[same as prior period, unchanged from 0000320193-23-000006:notes:32]

[0000320193-23-000064:notes:30]
The notional amounts of the Company’s outstanding derivative instruments as of April 1, 2023 and September 24, 2022 were as follows (in millions):

[0000320193-23-000064:notes:31]
|  | April 1,2023 |  | September 24,2022 |
| Derivative instruments designated as accounting hedges: |  |  |  |
| Foreign exchange contracts | $ | 51,119 |  |  | $ | 102,670 |  |
| Interest rate contracts | $ | 19,375 |  |  | $ | 20,125 |  |
| Derivative instruments not designated as accounting hedges: |  |  |  |
| Foreign exchange contracts | $ | 111,696 |  |  | $ | 185,381 |  |

[0000320193-23-000064:notes:32]
[same as prior period, unchanged from 0000320193-23-000006:notes:35]

[0000320193-23-000064:notes:33]
[same as prior period, unchanged from 0000320193-23-000006:notes:36]

[0000320193-23-000064:notes:34]
[same as prior period, unchanged from 0000320193-23-000006:notes:37]

[0000320193-23-000064:notes:35]
[same as prior period, unchanged from 0000320193-23-000006:notes:38]

[0000320193-23-000064:notes:36]
[same as prior period, unchanged from 0000320193-23-000006:notes:39]

[0000320193-23-000064:notes:37]
The carrying amounts of the Company’s hedged items in fair value hedges as of April 1, 2023 and September 24, 2022 were as follows (in millions):

[0000320193-23-000064:notes:38]
|  | April 1,2023 |  | September 24,2022 |
| Hedged assets/(liabilities): |  |  |  |
| Current and non-current marketable securities | $ | 14,651 |  |  | $ | 13,378 |  |
| Current and non-current term debt | $ | (18,249) |  |  | $ | (18,739) |  |

[0000320193-23-000064:notes:39]
[same as prior period, unchanged from 0000320193-23-000006:notes:42]

[0000320193-23-000064:notes:40]
[same as prior period, unchanged from 0000320193-23-000006:notes:43]

[0000320193-23-000064:notes:41]
[same as prior period, unchanged from 0000320193-23-000006:notes:44]

[0000320193-23-000064:notes:42]
As of both April 1, 2023 and September 24, 2022, the Company had one customer that represented 10% or more of total trade receivables, which accounted for 10%. The Company’s cellular network carriers accounted for 32% and 44% of total trade receivables as of April 1, 2023 and September 24, 2022, respectively.

[0000320193-23-000064:notes:43]
[same as prior period, unchanged from 0000320193-23-000006:notes:46]

[0000320193-23-000064:notes:44]
The Company has non-trade receivables from certain of its manufacturing vendors resulting from the sale of components to these vendors who manufacture subassemblies or assemble final products for the Company. The Company purchases these components directly from suppliers. As of April 1, 2023, the Company had three vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 43%, 19% and 13%. As of September 24, 2022, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 54% and 13%.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000320193-23-000064:notes:45]
[same as prior period, unchanged from 0000320193-23-000006:notes:48]


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000320193-23-000064:notes:46]
Condensed Consolidated Financial Statement Details
The following tables show the Company’s condensed consolidated financial statement details as of April 1, 2023 and September 24, 2022 (in millions):

[0000320193-23-000064:notes:47]
[same as prior period, unchanged from 0000320193-23-000006:notes:50]

[0000320193-23-000064:notes:48]
|  | April 1,2023 |  | September 24,2022 |
| Components | $ | 3,379 |  |  | $ | 1,637 |  |
| Finished goods | 4,103 |  |  | 3,309 |  |
| Total inventories | $ | 7,482 |  |  | $ | 4,946 |  |

[0000320193-23-000064:notes:49]
[same as prior period, unchanged from 0000320193-23-000006:notes:52]

[0000320193-23-000064:notes:50]
|  | April 1,2023 |  | September 24,2022 |
| Gross property, plant and equipment | $ | 113,066 |  |  | $ | 114,457 |  |
| Accumulated depreciation and amortization | (69,668) |  |  | (72,340) |  |
| Total property, plant and equipment, net | $ | 43,398 |  |  | $ | 42,117 |  |

[0000320193-23-000064:notes:51]
[same as prior period, unchanged from 0000320193-23-000006:notes:54]

[0000320193-23-000064:notes:52]
The following table shows the detail of other income/(expense), net for the three- and six-month periods ended April 1, 2023 and March 26, 2022 (in millions):

[0000320193-23-000064:notes:53]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1,2023 |  | March 26,2022 |  | April 1,2023 |  | March 26,2022 |
| Interest and dividend income | $ | 918 |  |  | $ | 700 |  |  | $ | 1,786 |  |  | $ | 1,350 |  |
| Interest expense | (930) |  |  | (691) |  |  | (1,933) |  |  | (1,385) |  |
| Other income/(expense), net | 76 |  |  | 151 |  |  | (182) |  |  | (52) |  |
| Total other income/(expense), net | $ | 64 |  |  | $ | 160 |  |  | $ | (329) |  |  | $ | (87) |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000320193-23-000064:notes:54]
Income Taxes
European Commission State Aid Decision

[0000320193-23-000064:notes:55]
On August 30, 2016, the European Commission announced its decision that Ireland granted state aid to the Company by providing tax opinions in 1991 and 2007 concerning the tax allocation of profits of the Irish branches of two subsidiaries of the Company (the “State Aid Decision”). The State Aid Decision ordered Ireland to calculate and recover additional taxes from the Company for the period June 2003 through December 2014. Irish legislative changes, effective as of January 2015, eliminated the application of the tax opinions from that date forward. The Company and Ireland appealed the State Aid Decision to the General Court of the Court of Justice of the European Union (the “General Court”). On July 15, 2020, the General Court annulled the State Aid Decision. On September 25, 2020, the European Commission appealed the General Court’s decision to the European Court of Justice and a hearing has been scheduled for May 23, 2023. The Company believes it would be eligible to claim a U.S. foreign tax credit for a portion of any incremental Irish corporate income taxes potentially due related to the State Aid Decision.


## us-gaap:DebtDisclosureTextBlock

[0000320193-23-000064:notes:56]
Debt
Commercial Paper

[0000320193-23-000064:notes:57]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of April 1, 2023 and September 24, 2022, the Company had $2.0 billion and $10.0 billion of Commercial Paper outstanding, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the six months ended April 1, 2023 and March 26, 2022 (in millions):

[0000320193-23-000064:notes:58]
|  | Six Months Ended |
|  | April 1,2023 |  | March 26,2022 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | (5,315) |  |  | $ | 4,952 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | — |  |  | 1,191 |  |
| Repayments of commercial paper | (2,645) |  |  | (5,144) |  |
| Repayments of commercial paper, net | (2,645) |  |  | (3,953) |  |
| Total proceeds from/(repayments of) commercial paper, net | $ | (7,960) |  |  | $ | 999 |  |

[0000320193-23-000064:notes:59]
Term Debt

[0000320193-23-000064:notes:60]
As of April 1, 2023 and September 24, 2022, the Company had outstanding fixed-rate notes with varying maturities for an aggregate carrying amount of $107.6 billion and $110.1 billion, respectively (collectively the “Notes”). As of April 1, 2023 and September 24, 2022, the fair value of the Company’s Notes, based on Level 2 inputs, was $98.4 billion and $98.8 billion, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000320193-23-000064:notes:61]
[same as prior period, unchanged from 0000320193-23-000006:notes:62]

[0000320193-23-000064:notes:62]
During the six months ended April 1, 2023, the Company repurchased 262 million shares of its common stock under an authorized share repurchase program for $38.1 billion, excluding excise tax due under the Inflation Reduction Act of 2022. The program does not obligate the Company to acquire a minimum amount of shares. Under the program, shares may be repurchased in privately negotiated or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000320193-23-000064:notes:63]
[same as prior period, unchanged from 0000320193-23-000006:notes:64]

[0000320193-23-000064:notes:64]
A summary of the Company’s RSU activity and related information for the six months ended April 1, 2023 is as follows:

[0000320193-23-000064:notes:65]
|  | Number ofRSUs(in thousands) |  | Weighted-AverageGrant Date FairValue Per RSU |  | AggregateFair Value(in millions) |
| Balance as of September 24, 2022 | 201,501 |  |  | $ | 109.48 |  |  |  |
| RSUs granted | 84,902 |  |  | $ | 149.73 |  |  |  |
| RSUs vested | (54,795) |  |  | $ | 86.72 |  |  |  |
| RSUs canceled | (4,671) |  |  | $ | 122.79 |  |  |  |
| Balance as of April 1, 2023 | 226,937 |  |  | $ | 129.76 |  |  | $ | 37,422 |  |

[0000320193-23-000064:notes:66]
The fair value as of the respective vesting dates of RSUs was $1.1 billion and $8.0 billion for the three- and six-month periods ended April 1, 2023, respectively, and was $1.0 billion and $9.5 billion for the three- and six-month periods ended March 26, 2022, respectively.

[0000320193-23-000064:notes:67]
[same as prior period, unchanged from 0000320193-23-000006:notes:68]

[0000320193-23-000064:notes:68]
The following table shows share-based compensation expense and the related income tax benefit included in the Condensed Consolidated Statements of Operations for the three- and six-month periods ended April 1, 2023 and March 26, 2022 (in millions):

[0000320193-23-000064:notes:69]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1,2023 |  | March 26,2022 |  | April 1,2023 |  | March 26,2022 |
| Share-based compensation expense | $ | 2,686 |  |  | $ | 2,252 |  |  | $ | 5,591 |  |  | $ | 4,517 |  |
| Income tax benefit related to share-based compensation expense | $ | (620) |  |  | $ | (649) |  |  | $ | (1,798) |  |  | $ | (2,185) |  |

[0000320193-23-000064:notes:70]
As of April 1, 2023, the total unrecognized compensation cost related to outstanding RSUs and stock options was $23.2 billion, which the Company expects to recognize over a weighted-average period of 2.8 years.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000320193-23-000064:notes:71]
Commitments and Contingencies
Unconditional Purchase Obligations

[0000320193-23-000064:notes:72]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of supplier arrangements, licensed content and distribution rights. Future payments under noncancelable unconditional purchase obligations with a remaining term in excess of one year as of April 1, 2023, are as follows (in millions):

[0000320193-23-000064:notes:73]
| 2023 (remaining six months) | $ | 2,263 |  |
| 2024 | 2,716 |  |
| 2025 | 2,028 |  |
| 2026 | 2,602 |  |
| 2027 | 571 |  |
| Thereafter | 5,897 |  |
| Total | $ | 16,077 |  |

[0000320193-23-000064:notes:74]
Contingencies

[0000320193-23-000064:notes:75]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully resolved. The outcome of litigation is inherently uncertain. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss greater than a recorded accrual, concerning loss contingencies for asserted legal and other claims.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000320193-23-000064:notes:76]
Segment Information and Geographic Data
The following table shows information by reportable segment for the three- and six-month periods ended April 1, 2023 and March 26, 2022 (in millions):

[0000320193-23-000064:notes:77]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1,2023 |  | March 26,2022 |  | April 1,2023 |  | March 26,2022 |
| Americas: |  |  |  |  |  |  |  |
| Net sales | $ | 37,784 |  |  | $ | 40,882 |  |  | $ | 87,062 |  |  | $ | 92,378 |  |
| Operating income | $ | 13,927 |  |  | $ | 15,279 |  |  | $ | 31,791 |  |  | $ | 34,864 |  |
| Europe: |  |  |  |  |  |  |  |
| Net sales | $ | 23,945 |  |  | $ | 23,287 |  |  | $ | 51,626 |  |  | $ | 53,036 |  |
| Operating income | $ | 9,368 |  |  | $ | 8,505 |  |  | $ | 19,385 |  |  | $ | 20,050 |  |
| Greater China: |  |  |  |  |  |  |  |
| Net sales | $ | 17,812 |  |  | $ | 18,343 |  |  | $ | 41,717 |  |  | $ | 44,126 |  |
| Operating income | $ | 7,531 |  |  | $ | 8,112 |  |  | $ | 17,968 |  |  | $ | 19,295 |  |
| Japan: |  |  |  |  |  |  |  |
| Net sales | $ | 7,176 |  |  | $ | 7,724 |  |  | $ | 13,931 |  |  | $ | 14,831 |  |
| Operating income | $ | 3,394 |  |  | $ | 3,496 |  |  | $ | 6,630 |  |  | $ | 6,845 |  |
| Rest of Asia Pacific: |  |  |  |  |  |  |  |
| Net sales | $ | 8,119 |  |  | $ | 7,042 |  |  | $ | 17,654 |  |  | $ | 16,852 |  |
| Operating income | $ | 3,268 |  |  | $ | 2,823 |  |  | $ | 7,119 |  |  | $ | 6,818 |  |

[0000320193-23-000064:notes:78]
A reconciliation of the Company’s segment operating income to the Condensed Consolidated Statements of Operations for the three- and six-month periods ended April 1, 2023 and March 26, 2022 is as follows (in millions):

[0000320193-23-000064:notes:79]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1,2023 |  | March 26,2022 |  | April 1,2023 |  | March 26,2022 |
| Segment operating income | $ | 37,488 |  |  | $ | 38,215 |  |  | $ | 82,893 |  |  | $ | 87,872 |  |
| Research and development expense | (7,457) |  |  | (6,387) |  |  | (15,166) |  |  | (12,693) |  |
| Other corporate expenses, net | (1,713) |  |  | (1,849) |  |  | (3,393) |  |  | (3,712) |  |
| Total operating income | $ | 28,318 |  |  | $ | 29,979 |  |  | $ | 64,334 |  |  | $ | 71,467 |  |
