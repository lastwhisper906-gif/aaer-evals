# AAPL note change history — 0000320193-23-000006 → 0000320193-23-000064


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-05-05):
[0000320193-23-000064:note_history:1]
Commitments and Contingencies
Unconditional Purchase Obligations
  (was, 2023-02-03, similarity 0.8571):
[0000320193-23-000006:note_history:1]
Contingencies
Unconditional Purchase Obligations

- changed (2023-05-05):
[0000320193-23-000064:note_history:2]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of supplier arrangements, licensed content and distribution rights. Future payments under noncancelable unconditional purchase obligations with a remaining term in excess of one year as of April 1, 2023, are as follows (in millions):
  (was, 2023-02-03, similarity 0.9858):
[0000320193-23-000006:note_history:2]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of supplier arrangements, licensed content and distribution rights. Future payments under noncancelable unconditional purchase obligations with a remaining term in excess of one year as of December 31, 2022, are as follows (in millions):

- changed (2023-05-05):
[0000320193-23-000064:note_history:3]
| 2023 (remaining six months) | $ | 2,263 |  |
| 2024 | 2,716 |  |
| 2025 | 2,028 |  |
| 2026 | 2,602 |  |
| 2027 | 571 |  |
| Thereafter | 5,897 |  |
| Total | $ | 16,077 |  |
  (was, 2023-02-03, similarity 0.9804):
[0000320193-23-000006:note_history:3]
| 2023 (remaining nine months) | $ | 2,899 |  |
| 2024 | 2,897 |  |
| 2025 | 1,584 |  |
| 2026 | 6,554 |  |
| 2027 | 348 |  |
| Thereafter | 444 |  |
| Total | $ | 14,726 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-05-05):
[0000320193-23-000064:note_history:4]
The following table shows the computation of basic and diluted earnings per share for the three- and six-month periods ended April 1, 2023 and March 26, 2022 (net income in millions and shares in thousands):
  (was, 2023-02-03, similarity 0.9067):
[0000320193-23-000006:note_history:4]
The following table shows the computation of basic and diluted earnings per share for the three months ended December 31, 2022 and December 25, 2021 (net income in millions and shares in thousands):

- changed (2023-05-05):
[0000320193-23-000064:note_history:5]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1,2023 |  | March 26,2022 |  | April 1,2023 |  | March 26,2022 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 24,160 |  |  | $ | 25,010 |  |  | $ | 54,158 |  |  | $ | 59,640 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 15,787,154 |  |  | 16,278,802 |  |  | 15,839,939 |  |  | 16,335,263 |  |
| Effect of dilutive securities | 59,896 |  |  | 124,514 |  |  | 61,445 |  |  | 126,041 |  |
| Weighted-average diluted shares | 15,847,050 |  |  | 16,403,316 |  |  | 15,901,384 |  |  | 16,461,304 |  |
| Basic earnings per share | $ | 1.53 |  |  | $ | 1.54 |  |  | $ | 3.42 |  |  | $ | 3.65 |  |
| Diluted earnings per share | $ | 1.52 |  |  | $ | 1.52 |  |  | $ | 3.41 |  |  | $ | 3.62 |  |
  (was, 2023-02-03, similarity 0.8122):
[0000320193-23-000006:note_history:5]
|  | Three Months Ended |  |  |
|  | December 31,2022 |  | December 25,2021 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 29,998 |  |  | $ | 34,630 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 15,892,723 |  |  | 16,391,724 |  |  |  |  |  |
| Effect of dilutive securities | 62,995 |  |  | 127,567 |  |  |  |  |  |
| Weighted-average diluted shares | 15,955,718 |  |  | 16,519,291 |  |  |  |  |  |
| Basic earnings per share | $ | 1.89 |  |  | $ | 2.11 |  |  |  |  |  |
| Diluted earnings per share | $ | 1.88 |  |  | $ | 2.10 |  |  |  |  |  |

- changed (2023-05-05):
[0000320193-23-000064:note_history:6]
Approximately 48 million restricted stock units (“RSUs”) were excluded from the computation of diluted earnings per share for the six months ended April 1, 2023 because their effect would have been antidilutive.
  (was, 2023-02-03, similarity 0.8825):
[0000320193-23-000006:note_history:6]
Approximately 89 million restricted stock units (“RSUs”) were excluded from the computation of diluted earnings per share for the three months ended December 31, 2022 because their effect would have been antidilutive.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-05):
[0000320193-23-000064:note_history:7]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of April 1, 2023 and September 24, 2022, the Company had $2.0 billion and $10.0 billion of Commercial Paper outstanding, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the six months ended April 1, 2023 and March 26, 2022 (in millions):
  (was, 2023-02-03, similarity 0.9178):
[0000320193-23-000006:note_history:7]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of December 31, 2022 and September 24, 2022, the Company had $1.7 billion and $10.0 billion of Commercial Paper outstanding, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the three months ended December 31, 2022 and December 25, 2021 (in millions):

- changed (2023-05-05):
[0000320193-23-000064:note_history:8]
|  | Six Months Ended |
|  | April 1,2023 |  | March 26,2022 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | (5,315) |  |  | $ | 4,952 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | — |  |  | 1,191 |  |
| Repayments of commercial paper | (2,645) |  |  | (5,144) |  |
| Repayments of commercial paper, net | (2,645) |  |  | (3,953) |  |
| Total proceeds from/(repayments of) commercial paper, net | $ | (7,960) |  |  | $ | 999 |  |
  (was, 2023-02-03, similarity 0.8489):
[0000320193-23-000006:note_history:8]
|  | Three Months Ended |
|  | December 31,2022 |  | December 25,2021 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | (5,569) |  |  | $ | 1,339 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | — |  |  | 1,191 |  |
| Repayments of commercial paper | (2,645) |  |  | (3,530) |  |
| Repayments of commercial paper, net | (2,645) |  |  | (2,339) |  |
| Total repayments of commercial paper, net | $ | (8,214) |  |  | $ | (1,000) |  |

- changed (2023-05-05):
[0000320193-23-000064:note_history:9]
As of April 1, 2023 and September 24, 2022, the Company had outstanding fixed-rate notes with varying maturities for an aggregate carrying amount of $107.6 billion and $110.1 billion, respectively (collectively the “Notes”). As of April 1, 2023 and September 24, 2022, the fair value of the Company’s Notes, based on Level 2 inputs, was $98.4 billion and $98.8 billion, respectively.
  (was, 2023-02-03, similarity 0.9631):
[0000320193-23-000006:note_history:9]
As of December 31, 2022 and September 24, 2022, the Company had outstanding fixed-rate notes with varying maturities for an aggregate carrying amount of $109.4 billion and $110.1 billion, respectively (collectively the “Notes”). As of December 31, 2022 and September 24, 2022, the fair value of the Company’s Notes, based on Level 2 inputs, was $98.0 billion and $98.8 billion, respectively.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-05-05):
[0000320193-23-000064:note_history:10]
Net sales disaggregated by significant products and services for the three- and six-month periods ended April 1, 2023 and March 26, 2022 were as follows (in millions):
  (was, 2023-02-03, similarity 0.8824):
[0000320193-23-000006:note_history:10]
Net sales disaggregated by significant products and services for the three months ended December 31, 2022 and December 25, 2021 were as follows (in millions):

- added (2023-05-05):
[0000320193-23-000064:note_history:11]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1,2023 |  | March 26,2022 |  | April 1,2023 |  | March 26,2022 |
| iPhone® | $ | 51,334 |  |  | $ | 50,570 |  |  | $ | 117,109 |  |  | $ | 122,198 |  |
| Mac® | 7,168 |  |  | 10,435 |  |  | 14,903 |  |  | 21,287 |  |
| iPad® | 6,670 |  |  | 7,646 |  |  | 16,066 |  |  | 14,894 |  |
| Wearables, Home and Accessories | 8,757 |  |  | 8,806 |  |  | 22,239 |  |  | 23,507 |  |
| Services | 20,907 |  |  | 19,821 |  |  | 41,673 |  |  | 39,337 |  |
| Total net sales | $ | 94,836 |  |  | $ | 97,278 |  |  | $ | 211,990 |  |  | $ | 221,223 |  |

- removed (2023-05-05):
[0000320193-23-000006:note_history:12]
|  | Three Months Ended |  |  |
|  | December 31,2022 |  | December 25,2021 |  |  |  |  |
| iPhone® (1) | $ | 65,775 |  |  | $ | 71,628 |  |  |  |  |  |
| Mac® (1) | 7,735 |  |  | 10,852 |  |  |  |  |  |
| iPad® (1) | 9,396 |  |  | 7,248 |  |  |  |  |  |
| Wearables, Home and Accessories (1)(2) | 13,482 |  |  | 14,701 |  |  |  |  |  |
| Services (3) | 20,766 |  |  | 19,516 |  |  |  |  |  |
| Total net sales (4) | $ | 117,154 |  |  | $ | 123,945 |  |  |  |  |  |

- removed (2023-05-05):
[0000320193-23-000006:note_history:13]
(1)Products net sales include amortization of the deferred value of unspecified software upgrade rights, which are bundled in the sales price of the respective product.

- removed (2023-05-05):
[0000320193-23-000006:note_history:14]
(2)Wearables, Home and Accessories net sales include sales of AirPods®, Apple TV®, Apple Watch®, Beats® products, HomePod mini® and accessories.

- removed (2023-05-05):
[0000320193-23-000006:note_history:15]
(3)Services net sales include sales from the Company’s advertising, AppleCare®, cloud, digital content, payment and other services. Services net sales also include amortization of the deferred value of services bundled in the sales price of certain products.

- removed (2023-05-05):
[0000320193-23-000006:note_history:16]
(4)Includes $3.4 billion of revenue recognized in the three months ended December 31, 2022 that was included in deferred revenue as of September 24, 2022 and $3.0 billion of revenue recognized in the three months ended December 25, 2021 that was included in deferred revenue as of September 25, 2021.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-05-05):
[0000320193-23-000064:note_history:17]
Revenue
Net sales disaggregated by significant products and services for the three- and six-month periods ended April 1, 2023 and March 26, 2022 were as follows (in millions):
  (was, 2023-02-03, similarity 0.8882):
[0000320193-23-000006:note_history:17]
Revenue
Net sales disaggregated by significant products and services for the three months ended December 31, 2022 and December 25, 2021 were as follows (in millions):

- added (2023-05-05):
[0000320193-23-000064:note_history:18]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1,2023 |  | March 26,2022 |  | April 1,2023 |  | March 26,2022 |
| iPhone® | $ | 51,334 |  |  | $ | 50,570 |  |  | $ | 117,109 |  |  | $ | 122,198 |  |
| Mac® | 7,168 |  |  | 10,435 |  |  | 14,903 |  |  | 21,287 |  |
| iPad® | 6,670 |  |  | 7,646 |  |  | 16,066 |  |  | 14,894 |  |
| Wearables, Home and Accessories | 8,757 |  |  | 8,806 |  |  | 22,239 |  |  | 23,507 |  |
| Services | 20,907 |  |  | 19,821 |  |  | 41,673 |  |  | 39,337 |  |
| Total net sales | $ | 94,836 |  |  | $ | 97,278 |  |  | $ | 211,990 |  |  | $ | 221,223 |  |

- added (2023-05-05):
[0000320193-23-000064:note_history:19]
Total net sales include $3.5 billion of revenue recognized in the three months ended April 1, 2023 that was included in deferred revenue as of December 31, 2022, $3.0 billion of revenue recognized in the three months ended March 26, 2022 that was included in deferred revenue as of December 25, 2021, $5.5 billion of revenue recognized in the six months ended April 1, 2023 that was included in deferred revenue as of September 24, 2022, and $4.8 billion of revenue recognized in the six months ended March 26, 2022 that was included in deferred revenue as of September 25, 2021.

- changed (2023-05-05):
[0000320193-23-000064:note_history:20]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 10, “Segment Information and Geographic Data” for the three- and six-month periods ended April 1, 2023 and March 26, 2022, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.
  (was, 2023-02-03, similarity 0.8525):
[0000320193-23-000006:note_history:20]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 9, “Segment Information and Geographic Data” for the three months ended December 31, 2022 and December 25, 2021, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.

- changed (2023-05-05):
[0000320193-23-000064:note_history:21]
As of April 1, 2023 and September 24, 2022, the Company had total deferred revenue of $12.5 billion and $12.4 billion, respectively. As of April 1, 2023, the Company expects 65% of total deferred revenue to be realized in less than a year, 26% within one-to-two years, 7% within two-to-three years and 2% in greater than three years.
  (was, 2023-02-03, similarity 0.9585):
[0000320193-23-000006:note_history:21]
As of December 31, 2022 and September 24, 2022, the Company had total deferred revenue of $12.6 billion and $12.4 billion, respectively. As of December 31, 2022, the Company expects 63% of total deferred revenue to be realized in less than a year, 27% within one-to-two years, 8% within two-to-three years and 2% in greater than three years.

- removed (2023-05-05):
[0000320193-23-000006:note_history:22]
|  | Three Months Ended |  |  |
|  | December 31,2022 |  | December 25,2021 |  |  |  |  |
| iPhone® (1) | $ | 65,775 |  |  | $ | 71,628 |  |  |  |  |  |
| Mac® (1) | 7,735 |  |  | 10,852 |  |  |  |  |  |
| iPad® (1) | 9,396 |  |  | 7,248 |  |  |  |  |  |
| Wearables, Home and Accessories (1)(2) | 13,482 |  |  | 14,701 |  |  |  |  |  |
| Services (3) | 20,766 |  |  | 19,516 |  |  |  |  |  |
| Total net sales (4) | $ | 117,154 |  |  | $ | 123,945 |  |  |  |  |  |

- removed (2023-05-05):
[0000320193-23-000006:note_history:23]
(1)Products net sales include amortization of the deferred value of unspecified software upgrade rights, which are bundled in the sales price of the respective product.

- removed (2023-05-05):
[0000320193-23-000006:note_history:24]
(2)Wearables, Home and Accessories net sales include sales of AirPods®, Apple TV®, Apple Watch®, Beats® products, HomePod mini® and accessories.

- removed (2023-05-05):
[0000320193-23-000006:note_history:25]
(3)Services net sales include sales from the Company’s advertising, AppleCare®, cloud, digital content, payment and other services. Services net sales also include amortization of the deferred value of services bundled in the sales price of certain products.

- removed (2023-05-05):
[0000320193-23-000006:note_history:26]
(4)Includes $3.4 billion of revenue recognized in the three months ended December 31, 2022 that was included in deferred revenue as of September 24, 2022 and $3.0 billion of revenue recognized in the three months ended December 25, 2021 that was included in deferred revenue as of September 25, 2021.
