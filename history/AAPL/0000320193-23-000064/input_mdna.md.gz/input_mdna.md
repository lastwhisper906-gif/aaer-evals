# AAPL MD&A — 0000320193-23-000064


## mdna

[0000320193-23-000064:mdna:1]
[same as prior period, unchanged from 0000320193-23-000006:mdna:1]

[0000320193-23-000064:mdna:2]
[same as prior period, unchanged from 0000320193-23-000006:mdna:2]

[0000320193-23-000064:mdna:3]
[same as prior period, unchanged from 0000320193-23-000006:mdna:3]

[0000320193-23-000064:mdna:4]
[same as prior period, unchanged from 0000320193-23-000006:mdna:4]

[0000320193-23-000064:mdna:5]
[same as prior period, unchanged from 0000320193-23-000006:mdna:5]

[0000320193-23-000064:mdna:6]
[same as prior period, unchanged from 0000320193-23-000006:mdna:6]

[0000320193-23-000064:mdna:7]
[same as prior period, unchanged from 0000320193-23-000006:mdna:7]

[0000320193-23-000064:mdna:8]
[same as prior period, unchanged from 0000320193-23-000006:mdna:8]

[0000320193-23-000064:mdna:9]
[same as prior period, unchanged from 0000320193-23-000006:mdna:9]

[0000320193-23-000064:mdna:10]
[same as prior period, unchanged from 0000320193-23-000006:mdna:10]

[0000320193-23-000064:mdna:11]
Weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on the Company’s total net sales, which decreased 3% or $2.4 billion during the second quarter of 2023 compared to the same quarter in 2022. The year-over-year net sales decrease consisted primarily of lower net sales of Mac, partially offset by higher net sales of Services.

[0000320193-23-000064:mdna:12]
During the second quarter of 2023, the Company announced the following new products:

[0000320193-23-000064:mdna:13]
•MacBook Pro® 14” and MacBook Pro 16”, powered by the Apple M2 Pro and M2 Max chip;

[0000320193-23-000064:mdna:14]
•Mac mini®, powered by the Apple M2 and M2 Pro chip; and

[0000320193-23-000064:mdna:15]
•Second-generation HomePod®.

[0000320193-23-000064:mdna:16]
The Company repurchased $19.1 billion of its common stock and paid dividends and dividend equivalents of $3.7 billion during the second quarter of 2023.

[0000320193-23-000064:mdna:17]
[same as prior period, unchanged from 0000320193-23-000006:mdna:17]

[0000320193-23-000064:mdna:18]
Macroeconomic conditions, including inflation, changes in interest rates, and currency fluctuations, have directly and indirectly impacted, and could in the future materially impact, the Company’s results of operations and financial condition.

[0000320193-23-000064:mdna:19]
[same as prior period, unchanged from 0000320193-23-000006:mdna:19]

[0000320193-23-000064:mdna:20]
The following table shows net sales by reportable segment for the three- and six-month periods ended April 1, 2023 and March 26, 2022 (dollars in millions):

[0000320193-23-000064:mdna:21]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1,2023 |  | March 26,2022 |  | Change |  | April 1,2023 |  | March 26,2022 |  | Change |
| Net sales by reportable segment: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 37,784 |  |  | $ | 40,882 |  |  | (8) | % |  | $ | 87,062 |  |  | $ | 92,378 |  |  | (6) | % |
| Europe | 23,945 |  |  | 23,287 |  |  | 3 | % |  | 51,626 |  |  | 53,036 |  |  | (3) | % |
| Greater China | 17,812 |  |  | 18,343 |  |  | (3) | % |  | 41,717 |  |  | 44,126 |  |  | (5) | % |
| Japan | 7,176 |  |  | 7,724 |  |  | (7) | % |  | 13,931 |  |  | 14,831 |  |  | (6) | % |
| Rest of Asia Pacific | 8,119 |  |  | 7,042 |  |  | 15 | % |  | 17,654 |  |  | 16,852 |  |  | 5 | % |
| Total net sales | $ | 94,836 |  |  | $ | 97,278 |  |  | (3) | % |  | $ | 211,990 |  |  | $ | 221,223 |  |  | (4) | % |

[0000320193-23-000064:mdna:22]
[same as prior period, unchanged from 0000320193-23-000006:mdna:23]

[0000320193-23-000064:mdna:23]
Americas net sales decreased during the second quarter and first six months of 2023 compared to the same periods in 2022 due primarily to lower net sales of iPhone and Mac, partially offset by higher net sales of Services.

[0000320193-23-000064:mdna:24]
[same as prior period, unchanged from 0000320193-23-000006:mdna:25]

[0000320193-23-000064:mdna:25]
The weakness in foreign currencies relative to the U.S. dollar had a net unfavorable year-over-year impact on Europe net sales during the second quarter and first six months of 2023. During the second quarter of 2023, the Europe net sales increase consisted primarily of higher net sales of iPhone, partially offset by lower net sales of Mac. During the first six months of 2023, the Europe net sales decrease consisted primarily of lower net sales of Mac, partially offset by higher net sales of iPhone.

[0000320193-23-000064:mdna:26]
[same as prior period, unchanged from 0000320193-23-000006:mdna:27]

[0000320193-23-000064:mdna:27]
The weakness in the renminbi relative to the U.S. dollar had an unfavorable year-over-year impact on Greater China net sales during the second quarter and first six months of 2023. During the second quarter and first six months of 2023, the Greater China net sales decrease consisted primarily of lower net sales of iPhone and Mac.

[0000320193-23-000064:mdna:28]
[same as prior period, unchanged from 0000320193-23-000006:mdna:29]

[0000320193-23-000064:mdna:29]
The weakness in the yen relative to the U.S. dollar had an unfavorable year-over-year impact on Japan net sales during the second quarter and first six months of 2023. During the second quarter of 2023, the Japan net sales decrease consisted primarily of lower net sales of iPad, Services and iPhone. During the first six months of 2023, the Japan net sales decrease consisted primarily of lower net sales of Services, Wearables, Home and Accessories and Mac.

[0000320193-23-000064:mdna:30]
[same as prior period, unchanged from 0000320193-23-000006:mdna:31]

[0000320193-23-000064:mdna:31]
The weakness in foreign currencies relative to the U.S. dollar had an unfavorable year-over-year impact on Rest of Asia Pacific net sales during the second quarter and first six months of 2023. During the second quarter and first six months of 2023, the Rest of Asia Pacific net sales increase consisted primarily of higher net sales of iPhone, partially offset by lower net sales of Mac.

[0000320193-23-000064:mdna:32]
[same as prior period, unchanged from 0000320193-23-000006:mdna:33]

[0000320193-23-000064:mdna:33]
The following table shows net sales by category for the three- and six-month periods ended April 1, 2023 and March 26, 2022 (dollars in millions):

[0000320193-23-000064:mdna:34]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1,2023 |  | March 26,2022 |  | Change |  | April 1,2023 |  | March 26,2022 |  | Change |
| Net sales by category: |  |  |  |  |  |  |  |  |  |  |  |
| iPhone | $ | 51,334 |  |  | $ | 50,570 |  |  | 2 | % |  | $ | 117,109 |  |  | $ | 122,198 |  |  | (4) | % |
| Mac | 7,168 |  |  | 10,435 |  |  | (31) | % |  | 14,903 |  |  | 21,287 |  |  | (30) | % |
| iPad | 6,670 |  |  | 7,646 |  |  | (13) | % |  | 16,066 |  |  | 14,894 |  |  | 8 | % |
| Wearables, Home and Accessories | 8,757 |  |  | 8,806 |  |  | (1) | % |  | 22,239 |  |  | 23,507 |  |  | (5) | % |
| Services | 20,907 |  |  | 19,821 |  |  | 5 | % |  | 41,673 |  |  | 39,337 |  |  | 6 | % |
| Total net sales | $ | 94,836 |  |  | $ | 97,278 |  |  | (3) | % |  | $ | 211,990 |  |  | $ | 221,223 |  |  | (4) | % |

[0000320193-23-000064:mdna:35]
[same as prior period, unchanged from 0000320193-23-000006:mdna:39]

[0000320193-23-000064:mdna:36]
iPhone net sales were relatively flat during the second quarter of 2023 compared to the second quarter of 2022. Year-over-year iPhone net sales decreased during the first six months of 2023 due primarily to lower net sales from the Company’s new iPhone models launched in the fourth quarter of 2022.

[0000320193-23-000064:mdna:37]
[same as prior period, unchanged from 0000320193-23-000006:mdna:41]

[0000320193-23-000064:mdna:38]
Mac net sales decreased during the second quarter and first six months of 2023 compared to the same periods in 2022 due primarily to lower net sales of MacBook Pro.

[0000320193-23-000064:mdna:39]
[same as prior period, unchanged from 0000320193-23-000006:mdna:43]

[0000320193-23-000064:mdna:40]
iPad net sales decreased during the second quarter of 2023 compared to the second quarter of 2022 due primarily to lower net sales of iPad Pro® and iPad Air®. Year-over-year iPad net sales increased during the first six months of 2023 due primarily to higher net sales of iPad, partially offset by lower net sales of iPad mini®.

[0000320193-23-000064:mdna:41]
[same as prior period, unchanged from 0000320193-23-000006:mdna:45]

[0000320193-23-000064:mdna:42]
Wearables, Home and Accessories net sales were relatively flat during the second quarter of 2023 compared to the second quarter of 2022. Year-over-year Wearables, Home and Accessories net sales decreased during the first six months of 2023 due primarily to lower net sales of AirPods®.

[0000320193-23-000064:mdna:43]
[same as prior period, unchanged from 0000320193-23-000006:mdna:47]

[0000320193-23-000064:mdna:44]
Services net sales increased during the second quarter and first six months of 2023 compared to the same periods in 2022 due primarily to higher net sales from cloud services, music and advertising.

[0000320193-23-000064:mdna:45]
[same as prior period, unchanged from 0000320193-23-000006:mdna:49]

[0000320193-23-000064:mdna:46]
Products and Services gross margin and gross margin percentage for the three- and six-month periods ended April 1, 2023 and March 26, 2022 were as follows (dollars in millions):

[0000320193-23-000064:mdna:47]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1,2023 |  | March 26,2022 |  | April 1,2023 |  | March 26,2022 |
| Gross margin: |  |  |  |  |  |  |  |
| Products | $ | 27,134 |  |  | $ | 28,167 |  |  | $ | 62,757 |  |  | $ | 68,287 |  |
| Services | 14,842 |  |  | 14,392 |  |  | 29,551 |  |  | 28,515 |  |
| Total gross margin | $ | 41,976 |  |  | $ | 42,559 |  |  | $ | 92,308 |  |  | $ | 96,802 |  |

[0000320193-23-000064:mdna:48]
| Gross margin percentage: |  |  |  |  |  |  |  |
| Products | 36.7 | % |  | 36.4 | % |  | 36.8 | % |  | 37.5 | % |
| Services | 71.0 | % |  | 72.6 | % |  | 70.9 | % |  | 72.5 | % |
| Total gross margin percentage | 44.3 | % |  | 43.7 | % |  | 43.5 | % |  | 43.8 | % |

[0000320193-23-000064:mdna:49]
[same as prior period, unchanged from 0000320193-23-000006:mdna:53]

[0000320193-23-000064:mdna:50]
Products gross margin decreased during the second quarter and first six months of 2023 compared to the same periods in 2022 due primarily to lower Products volume and the weakness in foreign currencies relative to the U.S. dollar, partially offset by a different Products mix.

[0000320193-23-000064:mdna:51]
Products gross margin percentage increased during the second quarter of 2023 compared to the second quarter of 2022 due primarily to a different Products mix, partially offset by the weakness in foreign currencies relative to the U.S. dollar. Year-over-year Products gross margin percentage decreased during the first six months of 2023 due primarily to the weakness in foreign currencies relative to the U.S. dollar, partially offset by a different Products mix.

[0000320193-23-000064:mdna:52]
[same as prior period, unchanged from 0000320193-23-000006:mdna:56]

[0000320193-23-000064:mdna:53]
Services gross margin increased during the second quarter and first six months of 2023 compared to the same periods in 2022 due primarily to higher Services net sales, partially offset by the weakness in foreign currencies relative to the U.S. dollar and higher Services costs.

[0000320193-23-000064:mdna:54]
Services gross margin percentage decreased during the second quarter and first six months of 2023 compared to the same periods in 2022 due primarily to the weakness in foreign currencies relative to the U.S. dollar and higher Services costs, partially offset by improved leverage.

[0000320193-23-000064:mdna:55]
[same as prior period, unchanged from 0000320193-23-000006:mdna:59]

[0000320193-23-000064:mdna:56]
[same as prior period, unchanged from 0000320193-23-000006:mdna:60]

[0000320193-23-000064:mdna:57]
Operating expenses for the three- and six-month periods ended April 1, 2023 and March 26, 2022 were as follows (dollars in millions):

[0000320193-23-000064:mdna:58]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1,2023 |  | March 26,2022 |  | April 1,2023 |  | March 26,2022 |
| Research and development | $ | 7,457 |  |  | $ | 6,387 |  |  | $ | 15,166 |  |  | $ | 12,693 |  |
| Percentage of total net sales | 8 | % |  | 7 | % |  | 7 | % |  | 6 | % |
| Selling, general and administrative | $ | 6,201 |  |  | $ | 6,193 |  |  | $ | 12,808 |  |  | $ | 12,642 |  |
| Percentage of total net sales | 7 | % |  | 6 | % |  | 6 | % |  | 6 | % |
| Total operating expenses | $ | 13,658 |  |  | $ | 12,580 |  |  | $ | 27,974 |  |  | $ | 25,335 |  |
| Percentage of total net sales | 14 | % |  | 13 | % |  | 13 | % |  | 11 | % |

[0000320193-23-000064:mdna:59]
[same as prior period, unchanged from 0000320193-23-000006:mdna:63]

[0000320193-23-000064:mdna:60]
The growth in research and development (“R&D”) expense during the second quarter and first six months of 2023 compared to the same periods in 2022 was driven primarily by increases in headcount-related expenses.

[0000320193-23-000064:mdna:61]
[same as prior period, unchanged from 0000320193-23-000006:mdna:65]

[0000320193-23-000064:mdna:62]
Selling, general and administrative expense was relatively flat during the second quarter and first six months of 2023 compared to the same periods in 2022.

[0000320193-23-000064:mdna:63]
[same as prior period, unchanged from 0000320193-23-000006:mdna:67]

[0000320193-23-000064:mdna:64]
Provision for income taxes, effective tax rate and statutory federal income tax rate for the three- and six-month periods ended April 1, 2023 and March 26, 2022 were as follows (dollars in millions):

[0000320193-23-000064:mdna:65]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1,2023 |  | March 26,2022 |  | April 1,2023 |  | March 26,2022 |
| Provision for income taxes | $ | 4,222 |  |  | $ | 5,129 |  |  | $ | 9,847 |  |  | $ | 11,740 |  |
| Effective tax rate | 14.9 | % |  | 17.0 | % |  | 15.4 | % |  | 16.4 | % |
| Statutory federal income tax rate | 21 | % |  | 21 | % |  | 21 | % |  | 21 | % |

[0000320193-23-000064:mdna:66]
The Company’s effective tax rate for the second quarter of 2023 was lower than the statutory federal income tax rate due primarily to a lower effective tax rate on foreign earnings and the U.S. federal R&D credit, partially offset by state income taxes. The Company’s effective tax rate for the first six months of 2023 was lower than the statutory federal income tax rate due primarily to a lower effective tax rate on foreign earnings, the U.S. federal R&D credit and tax benefits from share-based compensation, partially offset by state income taxes.

[0000320193-23-000064:mdna:67]
The Company’s effective tax rate for the second quarter of 2023 was lower compared to the second quarter of 2022 due primarily to the impact of U.S. foreign tax credit regulations issued by the U.S. Department of the Treasury in 2022 and a higher U.S. federal R&D credit. The Company’s effective tax rate for the first six months of 2023 was lower compared to the same period in 2022 due primarily to the impact of U.S. foreign tax credit regulations issued by the U.S. Department of the Treasury in 2022 and a higher U.S. federal R&D credit, partially offset by lower tax benefits from share-based compensation.

[0000320193-23-000064:mdna:68]
[same as prior period, unchanged from 0000320193-23-000006:mdna:72]

[0000320193-23-000064:mdna:69]
[same as prior period, unchanged from 0000320193-23-000006:mdna:73]

[0000320193-23-000064:mdna:70]
[same as prior period, unchanged from 0000320193-23-000006:mdna:74]

[0000320193-23-000064:mdna:71]
[same as prior period, unchanged from 0000320193-23-000006:mdna:75]

[0000320193-23-000064:mdna:72]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. As of April 1, 2023, the Company had $2.0 billion of Commercial Paper outstanding, all of which was payable within 12 months.

[0000320193-23-000064:mdna:73]
[same as prior period, unchanged from 0000320193-23-000006:mdna:77]

[0000320193-23-000064:mdna:74]
The Company utilizes several outsourcing partners to manufacture subassemblies for the Company’s products and to perform final assembly and testing of finished products. The Company also obtains individual components for its products from a wide variety of individual suppliers. Outsourcing partners acquire components and build product based on demand information supplied by the Company, which typically covers periods up to 150 days. As of April 1, 2023, the Company had manufacturing purchase obligations of $40.5 billion, with $40.1 billion payable within 12 months. The Company’s manufacturing purchase obligations are primarily noncancelable.

[0000320193-23-000064:mdna:75]
Capital Return Program

[0000320193-23-000064:mdna:76]
In addition to its contractual cash requirements, the Company has an authorized share repurchase program, under which the remaining availability was $22.6 billion as of April 1, 2023. On May 4, 2023, the Company announced the Board of Directors had authorized an additional program to repurchase up to $90 billion of the Company’s common stock. The programs do not obligate the Company to acquire a minimum amount of shares.

[0000320193-23-000064:mdna:77]
On May 4, 2023, the Company also announced the Board of Directors raised the Company’s quarterly cash dividend from $0.23 to $0.24 per share, beginning with the dividend to be paid during the third quarter of 2023. The Company intends to increase its dividend on an annual basis, subject to declaration by the Board of Directors.

[0000320193-23-000064:mdna:78]
[same as prior period, unchanged from 0000320193-23-000006:mdna:80]

[0000320193-23-000064:mdna:79]
[same as prior period, unchanged from 0000320193-23-000006:mdna:81]
