# AAPL MD&A — 0001193125-15-153166


## mdna

[0001193125-15-153166:mdna:1]
Item 2. Management’s Discussion and Analysis of Financial Condition and Results
of Operations

[0001193125-15-153166:mdna:2]
[same as prior period, unchanged from 0001193125-15-023697:mdna:2]

[0001193125-15-153166:mdna:3]
[same as prior period, unchanged from 0001193125-15-023697:mdna:3]

[0001193125-15-153166:mdna:4]
[same as prior period, unchanged from 0001193125-15-023697:mdna:4]

[0001193125-15-153166:mdna:5]
[same as prior period, unchanged from 0001193125-15-023697:mdna:5]

[0001193125-15-153166:mdna:6]
The Company designs, manufactures and
markets mobile communication and media devices, personal computers and portable digital music players, and sells a variety of related software, services, accessories, networking solutions and third-party digital content and applications. The
Company’s products and services include iPhone®, iPad®, Mac®, iPod®, Apple TV®, a portfolio of consumer and professional software applications, the iOS and OS
X® operating systems, iCloud®, Apple Pay™ and a variety of accessory, service and support offerings. In September 2014, the
Company announced Apple Watch™, which began shipping in April 2015. The Company also sells and delivers digital content and applications through the iTunes Store®, App Store™, Mac
App Store, and iBooks Store™ (collectively “iTunes”). The Company sells its products worldwide through its retail stores, online stores and direct sales force, as well as through third-party cellular network carriers, wholesalers,
retailers and value-added resellers. In addition, the Company sells a variety of third-party iPhone, iPad, Mac and iPod compatible products, including application software and various accessories through its online and retail stores. The Company
sells to consumers, small and mid-sized businesses and education, enterprise and government customers.

[0001193125-15-153166:mdna:7]
[same as prior period, unchanged from 0001193125-15-023697:mdna:7]

[0001193125-15-153166:mdna:8]
The Company is committed to bringing the best user experience to its customers through its innovative hardware, software and services. The Company’s
business strategy leverages its unique ability to design and develop its own operating systems, hardware, application software and services to provide its customers products and solutions with innovative design, superior ease-of-use and seamless
integration. As part of its strategy, the Company continues to expand its platform for the discovery and delivery of digital content and applications through iTunes®, which allows customers to
discover and download digital content, iOS and Mac applications, and books through either a Mac or Windows-based computer or through iPhone, iPad and iPod touch® devices (“iOS
devices”). The Company also supports a community for the development of third-party software and hardware products and digital content that complement the Company’s offerings. The Company believes a high-quality buying experience with
knowledgeable salespersons who can convey the value of the Company’s products and services greatly enhances its ability to attract and retain customers. Therefore, the Company’s strategy also includes building and expanding its own retail
and online stores and its third-party distribution network to effectively reach more customers and provide them with a high-quality sales and post-sales support experience. The Company believes ongoing investment in research and development
(“R&D”), marketing and advertising is critical to the development and sale of innovative products and technologies.

[0001193125-15-153166:mdna:9]
Business Seasonality and
Product Introductions

[0001193125-15-153166:mdna:10]
The Company has historically experienced higher net sales in its first quarter compared to other quarters in its fiscal
year due in part to seasonal holiday demand. Additionally, new product introductions can significantly impact net sales, product costs and operating expenses. Product introductions can also impact the Company’s net sales to its indirect
distribution channels as these channels are filled with new product inventory following a product introduction, and often, channel inventory of a particular product declines as the next related major product launch approaches. Net sales can also be
affected when consumers and distributors anticipate a product introduction. However, neither historical seasonal patterns nor historical patterns of product introductions should be considered reliable indicators of the Company’s future pattern
of product introductions, future net sales or financial performance.

[0001193125-15-153166:mdna:11]
Second Quarter Fiscal 2015 Highlights

[0001193125-15-153166:mdna:12]
Net sales rose 27% or $12.4 billion during the second quarter of 2015 compared to the same quarter in 2014. Net sales and unit sales increased for iPhone
and Mac following the launches of new iPhone and Mac models in the fourth quarter of 2014 and first quarter of 2015, and net sales of Services increased primarily due to growth from iOS app sales. This growth was partially offset by lower net sales
and unit sales of iPad and by the effect of weakness in most foreign currencies relative to the U.S. dollar. Total net sales increased in each of the Company’s operating segments except Japan, with particularly strong growth in Greater China
and Rest of Asia Pacific, where year-over-year net sales increased 71% and 48%, respectively.

[0001193125-15-153166:mdna:13]
During the second quarter of 2015, the Company
introduced updates to MacBook Air® and MacBook Pro® and announced the all-new
MacBook®, which began shipping in April 2015.

[0001193125-15-153166:mdna:14]
The Company utilized $7.0 billion to
repurchase shares of its common stock and paid dividends of $2.7 billion or $0.47 per share during the second quarter of 2015. Additionally, the Company issued $6.5 billion of U.S. dollar-denominated and SFr1.3 billion of Swiss Franc-denominated
long-term debt.

[0001193125-15-153166:mdna:15]
[same as prior period, unchanged from 0001193125-15-023697:mdna:15]

[0001193125-15-153166:mdna:16]
The following table shows net sales by operating segment and net sales and unit sales by product during the three- and six-month periods ended
March 28, 2015 and March 29, 2014 (dollars in millions and units in thousands):

[0001193125-15-153166:mdna:17]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 28,2015 |  |  | March 29,2014 |  |  | Change |  |  | March 28,2015 |  |  | March 29,2014 |  |  | Change |  |
| Net Sales by Operating Segment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 21,316 |  |  | $ | 17,982 |  |  |  | 19% |  |  | $ | 51,882 |  |  | $ | 42,771 |  |  |  | 21% |  |
| Europe |  |  | 12,204 |  |  |  | 10,941 |  |  |  | 12% |  |  |  | 29,418 |  |  |  | 25,276 |  |  |  | 16% |  |
| Greater China |  |  | 16,823 |  |  |  | 9,835 |  |  |  | 71% |  |  |  | 32,967 |  |  |  | 19,331 |  |  |  | 71% |  |
| Japan |  |  | 3,457 |  |  |  | 4,047 |  |  |  | (15)% |  |  |  | 8,905 |  |  |  | 9,092 |  |  |  | (2)% |  |
| Rest of Asia Pacific |  |  | 4,210 |  |  |  | 2,841 |  |  |  | 48% |  |  |  | 9,437 |  |  |  | 6,770 |  |  |  | 39% |  |
| Total net sales |  | $ | 58,010 |  |  | $ | 45,646 |  |  |  | 27% |  |  | $ | 132,609 |  |  | $ | 103,240 |  |  |  | 28% |  |
| Net Sales by Product: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| iPhone (1) |  | $ | 40,282 |  |  | $ | 26,064 |  |  |  | 55% |  |  | $ | 91,464 |  |  | $ | 58,562 |  |  |  | 56% |  |
| iPad (1) |  |  | 5,428 |  |  |  | 7,610 |  |  |  | (29)% |  |  |  | 14,413 |  |  |  | 19,078 |  |  |  | (24)% |  |
| Mac (1) |  |  | 5,615 |  |  |  | 5,519 |  |  |  | 2% |  |  |  | 12,559 |  |  |  | 11,914 |  |  |  | 5% |  |
| Services (2) |  |  | 4,996 |  |  |  | 4,573 |  |  |  | 9% |  |  |  | 9,795 |  |  |  | 8,970 |  |  |  | 9% |  |
| Other Products (1)(3) |  |  | 1,689 |  |  |  | 1,880 |  |  |  | (10)% |  |  |  | 4,378 |  |  |  | 4,716 |  |  |  | (7)% |  |
| Total net sales |  | $ | 58,010 |  |  | $ | 45,646 |  |  |  | 27% |  |  | $ | 132,609 |  |  | $ | 103,240 |  |  |  | 28% |  |
| Unit Sales by Product: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| iPhone |  |  | 61,170 |  |  |  | 43,719 |  |  |  | 40% |  |  |  | 135,638 |  |  |  | 94,744 |  |  |  | 43% |  |
| iPad |  |  | 12,623 |  |  |  | 16,350 |  |  |  | (23)% |  |  |  | 34,042 |  |  |  | 42,385 |  |  |  | (20)% |  |
| Mac |  |  | 4,563 |  |  |  | 4,136 |  |  |  | 10% |  |  |  | 10,082 |  |  |  | 8,973 |  |  |  | 12% |  |

[0001193125-15-153166:mdna:18]
[same as prior period, unchanged from 0001193125-15-023697:mdna:18]

[0001193125-15-153166:mdna:19]
[same as prior period, unchanged from 0001193125-15-023697:mdna:19]

[0001193125-15-153166:mdna:20]
[same as prior period, unchanged from 0001193125-15-023697:mdna:20]

[0001193125-15-153166:mdna:21]
25

[0001193125-15-153166:mdna:22]
[same as prior period, unchanged from 0001193125-15-023697:mdna:22]

[0001193125-15-153166:mdna:23]
[same as prior period, unchanged from 0001193125-15-023697:mdna:23]

[0001193125-15-153166:mdna:24]
The following table presents iPhone net sales and unit
sales information for the three- and six-month periods ended March 28, 2015 and March 29, 2014 (dollars in millions and units in thousands):

[0001193125-15-153166:mdna:25]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 28,2015 |  |  | March 29,2014 |  |  | Change |  |  | March 28,2015 |  |  | March 29,2014 |  |  | Change |  |
| Net sales |  | $ | 40,282 |  |  | $ | 26,064 |  |  |  | 55% |  |  | $ | 91,464 |  |  | $ | 58,562 |  |  |  | 56% |  |
| Percentage of total net sales |  |  | 69% |  |  |  | 57% |  |  |  |  |  |  |  | 69% |  |  |  | 57% |  |  |  |  |  |
| Unit sales |  |  | 61,170 |  |  |  | 43,719 |  |  |  | 40% |  |  |  | 135,638 |  |  |  | 94,744 |  |  |  | 43% |  |

[0001193125-15-153166:mdna:26]
The year-over-year growth in iPhone net sales and unit sales in the second quarter and first six months of 2015 resulted
from the launch of new iPhones in the fourth quarter of 2014 and first quarter of 2015; and expanded distribution. Overall average selling prices (“ASPs”) for iPhone increased by 10% and 9% in the second quarter and first six months of
2015, respectively, compared to the same periods in 2014, due to a shift in mix to iPhone 6 and 6 Plus and an increased mix of higher storage capacity iPhones, partially offset by the effect of weakness in most foreign currencies relative to the
U.S. dollar.

[0001193125-15-153166:mdna:27]
[same as prior period, unchanged from 0001193125-15-023697:mdna:27]

[0001193125-15-153166:mdna:28]
The following table presents iPad net
sales and unit sales information for the three- and six-month periods ended March 28, 2015 and March 29, 2014 (dollars in millions and units in thousands):

[0001193125-15-153166:mdna:29]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 28,2015 |  |  | March 29,2014 |  |  | Change |  |  | March 28,2015 |  |  | March 29,2014 |  |  | Change |  |
| Net sales |  | $ | 5,428 |  |  | $ | 7,610 |  |  |  | (29)% |  |  | $ | 14,413 |  |  | $ | 19,078 |  |  |  | (24)% |  |
| Percentage of total net sales |  |  | 9% |  |  |  | 17% |  |  |  |  |  |  |  | 11% |  |  |  | 18% |  |  |  |  |  |
| Unit sales |  |  | 12,623 |  |  |  | 16,350 |  |  |  | (23)% |  |  |  | 34,042 |  |  |  | 42,385 |  |  |  | (20)% |  |

[0001193125-15-153166:mdna:30]
Net sales and unit sales for iPad declined in the second quarter and first six months of 2015 compared to the same
periods in 2014. The Company believes the decline in sales is due in part to a longer repurchase cycle for iPads and some level of cannibalization from the Company’s other products. iPad ASPs declined by 8% and 6% during the second quarter and
first six months of 2015, respectively, compared to the same periods in 2014, primarily as a result of a shift in mix to lower-priced iPads and the effect of weakness in most foreign currencies relative to the U.S. dollar, partially offset by an
increased mix of higher storage capacity iPads.

[0001193125-15-153166:mdna:31]
[same as prior period, unchanged from 0001193125-15-023697:mdna:31]

[0001193125-15-153166:mdna:32]
The
following table presents Mac net sales and unit sales information for the three- and six-month periods ended March 28, 2015 and March 29, 2014 (dollars in millions and units in thousands):

[0001193125-15-153166:mdna:33]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 28,2015 |  |  | March 29,2014 |  |  | Change |  |  | March 28,2015 |  |  | March 29,2014 |  |  | Change |  |
| Net sales |  | $ | 5,615 |  |  | $ | 5,519 |  |  |  | 2% |  |  | $ | 12,559 |  |  | $ | 11,914 |  |  |  | 5% |  |
| Percentage of total net sales |  |  | 10% |  |  |  | 12% |  |  |  |  |  |  |  | 9% |  |  |  | 12% |  |  |  |  |  |
| Unit sales |  |  | 4,563 |  |  |  | 4,136 |  |  |  | 10% |  |  |  | 10,082 |  |  |  | 8,973 |  |  |  | 12% |  |

[0001193125-15-153166:mdna:34]
The year-over-year growth in Mac net sales and unit sales for the second quarter and first six months of 2015 was driven
by strong demand for MacBook Air and the launch of new Mac desktops in the first quarter of 2015. Mac ASPs declined by 8% and 6% during the second quarter and first six months of 2015, respectively, compared to the same periods in 2014, primarily as
a result of the effect of weakness in most foreign currencies relative to the U.S. dollar, a shift in mix to lower-priced Macs, and price reductions on Mac portables in the second half of 2014.

[0001193125-15-153166:mdna:35]
[same as prior period, unchanged from 0001193125-15-023697:mdna:35]

[0001193125-15-153166:mdna:36]
The
following table presents Services net sales information for the three- and six-month periods ended March 28, 2015 and March 29, 2014 (dollars in millions):

[0001193125-15-153166:mdna:37]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 28,2015 |  |  | March 29,2014 |  |  | Change |  |  | March 28,2015 |  |  | March 29,2014 |  |  | Change |  |
| Net sales |  | $ | 4,996 |  |  | $ | 4,573 |  |  |  | 9% |  |  | $ | 9,795 |  |  | $ | 8,970 |  |  |  | 9% |  |
| Percentage of total net sales |  |  | 9% |  |  |  | 10% |  |  |  |  |  |  |  | 7% |  |  |  | 9% |  |  |  |  |  |

[0001193125-15-153166:mdna:38]
The increase in net sales of Services in the second quarter and first six months of 2015 compared to the same periods in
2014 was primarily due to growth from licensing and iTunes, partially offset by the effect of weakness in most foreign currencies relative to the U.S. dollar. iTunes generated a total of $2.8 billion and $5.4 billion in net sales during the second
quarter and first six months of 2015, respectively, compared to $2.6 billion and $5.0 billion during the second quarter and first six months of 2014, respectively. Growth from iTunes was driven primarily by increases in revenue from iOS app sales
reflecting continued growth in the installed base of iOS devices, the expansion in third-party iOS apps available, and increased volume of in-app purchases. This growth was partially offset by year-over-year decreases in combined net sales of
digital media, consisting of music, movies, TV shows and books, of 4% and 5% in the second quarter and first six months of 2015, respectively.

[0001193125-15-153166:mdna:39]
Segment Operating
Performance

[0001193125-15-153166:mdna:40]
The Company manages its business primarily on a geographic basis. Accordingly, the Company determined its reportable operating
segments, which are generally based on the location of its customers, to be the Americas, Europe, Greater China, Japan and Rest of Asia Pacific. The Americas segment includes both North and South America. The Europe segment includes European
countries, as well as India, the Middle East and Africa. The Greater China segment includes China, Hong Kong and Taiwan. The Rest of Asia Pacific segment includes Australia and Asian countries, other than those countries included in the
Company’s other operating segments. Each operating segment provides similar hardware and software products and similar services. Further information regarding the Company’s operating segments may be found in Part I, Item 1 of this
Form 10-Q in the Notes to Condensed Consolidated Financial Statements, in Note 11, “Segment Information and Geographic Data.”

[0001193125-15-153166:mdna:41]
[same as prior period, unchanged from 0001193125-15-023697:mdna:41]

[0001193125-15-153166:mdna:42]
The following table presents Americas net sales information for the three- and six-month periods ended March 28, 2015 and March 29, 2014
(dollars in millions):

[0001193125-15-153166:mdna:43]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 28,2015 |  |  | March 29,2014 |  |  | Change |  |  | March 28,2015 |  |  | March 29,2014 |  |  | Change |  |
| Net sales |  | $ | 21,316 |  |  | $ | 17,982 |  |  |  | 19% |  |  | $ | 51,882 |  |  | $ | 42,771 |  |  |  | 21% |  |
| Percentage of total net sales |  |  | 37% |  |  |  | 39% |  |  |  |  |  |  |  | 39% |  |  |  | 41% |  |  |  |  |  |

[0001193125-15-153166:mdna:44]
The year-over-year growth in Americas net sales for the second quarter and first six months of 2015 was driven primarily
by growth in net sales and unit sales of iPhone, partially offset by a decline in net sales and unit sales of iPad. iPhone channel inventory decreased more in the second quarter and first six months of 2015 than in the prior year periods due to
increased customer demand.

[0001193125-15-153166:mdna:45]
[same as prior period, unchanged from 0001193125-15-023697:mdna:45]

[0001193125-15-153166:mdna:46]
The following table
presents Europe net sales information for the three- and six-month periods ended March 28, 2015 and March 29, 2014 (dollars in millions):

[0001193125-15-153166:mdna:47]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 28,2015 |  |  | March 29,2014 |  |  | Change |  |  | March 28,2015 |  |  | March 29,2014 |  |  | Change |  |
| Net sales |  | $ | 12,204 |  |  | $ | 10,941 |  |  |  | 12% |  |  | $ | 29,418 |  |  | $ | 25,276 |  |  |  | 16% |  |
| Percentage of total net sales |  |  | 21% |  |  |  | 24% |  |  |  |  |  |  |  | 22% |  |  |  | 24% |  |  |  |  |  |

[0001193125-15-153166:mdna:48]
The year-over-year increase in Europe net sales for the second quarter and first six months of 2015 was driven primarily
by growth in net sales and unit sales of iPhone, partially offset by a decline in net sales and unit sales of iPad and the effect of weakness in European currencies relative to the U.S. dollar. iPhone channel inventory decreased significantly more
in the first six months of 2015 than in the prior year period due to increased customer demand.

[0001193125-15-153166:mdna:49]
[same as prior period, unchanged from 0001193125-15-023697:mdna:49]

[0001193125-15-153166:mdna:50]
The following table presents Greater China net sales information for the three- and six-month periods ended March 28, 2015 and March 29, 2014
(dollars in millions):

[0001193125-15-153166:mdna:51]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 28,2015 |  |  | March 29,2014 |  |  | Change |  |  | March 28,2015 |  |  | March 29,2014 |  |  | Change |  |
| Net sales |  | $ | 16,823 |  |  | $ | 9,835 |  |  |  | 71% |  |  | $ | 32,967 |  |  | $ | 19,331 |  |  |  | 71% |  |
| Percentage of total net sales |  |  | 29% |  |  |  | 22% |  |  |  |  |  |  |  | 25% |  |  |  | 19% |  |  |  |  |  |

[0001193125-15-153166:mdna:52]
During the second quarter and first six months of 2015, Greater China experienced year-over-year increases in net sales
that were significantly higher than those experienced by the Company overall. iPhone net sales and unit sales grew strongly following the launch of new iPhone models in Greater China in the fourth quarter of 2014 and first quarter of 2015. iPhone
channel inventory increased more in the second quarter and first six months of 2015 than in the prior year periods in anticipation of increased customer demand.

[0001193125-15-153166:mdna:53]
[same as prior period, unchanged from 0001193125-15-023697:mdna:53]

[0001193125-15-153166:mdna:54]
The following table presents Japan net sales information
for the three- and six-month periods ended March 28, 2015 and March 29, 2014 (dollars in millions):

[0001193125-15-153166:mdna:55]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 28,2015 |  |  | March 29,2014 |  |  | Change |  |  | March 28,2015 |  |  | March 29,2014 |  |  | Change |  |
| Net sales |  | $ | 3,457 |  |  | $ | 4,047 |  |  |  | (15)% |  |  | $ | 8,905 |  |  | $ | 9,092 |  |  |  | (2)% |  |
| Percentage of total net sales |  |  | 6% |  |  |  | 9% |  |  |  |  |  |  |  | 7% |  |  |  | 9% |  |  |  |  |  |

[0001193125-15-153166:mdna:56]
The year-over-year decrease in Japan net sales for the second quarter and first six months of 2015 was driven primarily
by a significant adverse impact from weakness in the Japanese Yen relative to the U.S. dollar, as well as lower net sales and unit sales of iPhone. iPhone channel inventory decreased during the first six months of 2015.

[0001193125-15-153166:mdna:57]
[same as prior period, unchanged from 0001193125-15-023697:mdna:57]

[0001193125-15-153166:mdna:58]
The following table presents Rest of Asia
Pacific net sales information for the three- and six-month periods ended March 28, 2015 and March 29, 2014 (dollars in millions):

[0001193125-15-153166:mdna:59]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 28,2015 |  |  | March 29,2014 |  |  | Change |  |  | March 28,2015 |  |  | March 29,2014 |  |  | Change |  |
| Net sales |  | $ | 4,210 |  |  | $ | 2,841 |  |  |  | 48% |  |  | $ | 9,437 |  |  | $ | 6,770 |  |  |  | 39% |  |
| Percentage of total net sales |  |  | 7% |  |  |  | 6% |  |  |  |  |  |  |  | 7% |  |  |  | 7% |  |  |  |  |  |

[0001193125-15-153166:mdna:60]
The year-over-year increase in Rest of Asia Pacific net sales for the second quarter and first six months of 2015
primarily reflects strong growth in net sales and unit sales of iPhone, partially offset by a decline in net sales and unit sales of iPad and the effect of weakness in foreign currencies relative to the U.S. dollar. iPhone channel inventory
increased more in the second quarter and first six months of 2015 than in the prior year periods in anticipation of increased customer demand.

[0001193125-15-153166:mdna:61]
[same as prior period, unchanged from 0001193125-15-023697:mdna:61]

[0001193125-15-153166:mdna:62]
Gross margin for the three- and six-month periods ended March 28, 2015 and March 29, 2014 was as follows (dollars in millions):

[0001193125-15-153166:mdna:63]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 28,2015 |  |  | March 29,2014 |  |  | March 28,2015 |  |  | March 29,2014 |  |
| Net sales |  | $ | 58,010 |  |  | $ | 45,646 |  |  | $ | 132,609 |  |  | $ | 103,240 |  |
| Cost of sales |  |  | 34,354 |  |  |  | 27,699 |  |  |  | 79,212 |  |  |  | 63,447 |  |
| Gross margin |  | $ | 23,656 |  |  | $ | 17,947 |  |  | $ | 53,397 |  |  | $ | 39,793 |  |
| Gross margin percentage |  |  | 40.8% |  |  |  | 39.3% |  |  |  | 40.3% |  |  |  | 38.5% |  |

[0001193125-15-153166:mdna:64]
The increase in the gross margin percentage during the second quarter and first six months of 2015 compared to the same
periods in 2014 was driven primarily by a favorable shift in mix to products with higher margins and, to a lesser extent, by improved leverage on fixed costs from higher net sales. These positive factors were partially offset primarily by higher
cost structures on new products and, to a lesser extent, by the effect of weakness in most foreign currencies relative to the U.S. dollar.

[0001193125-15-153166:mdna:65]
The
Company anticipates gross margin during the third quarter of 2015 to be between 38.5% and 39.5%. The foregoing statement regarding the Company’s expected gross margin percentage in the third quarter of 2015 is forward-looking and could differ
from actual results. The Company’s future gross margins can be impacted by multiple factors including, but not limited to, those set forth in Part II, Item 1A of this Form 10-Q under the heading “Risk Factors” and those described
in this paragraph. In general, the Company believes gross margins will remain under downward pressure due to a variety of factors, including continued industry wide global product pricing pressures, increased competition, compressed product life
cycles, product transitions, potential increases in the cost of components, and potential strengthening of the U.S. dollar, as well as potential increases in the costs of outside manufacturing services and a potential shift in the Company’s
sales mix towards products with lower gross margins. In response to competitive pressures, the Company expects it will continue to take product pricing actions, which would adversely affect gross margins. Gross margins could also be affected by the
Company’s ability to manage product quality and warranty costs effectively and to stimulate demand for certain of its products. Due to the Company’s significant international operations, financial results can be significantly affected by
fluctuations in exchange rates.

[0001193125-15-153166:mdna:66]
[same as prior period, unchanged from 0001193125-15-023697:mdna:66]

[0001193125-15-153166:mdna:67]
Operating expenses for the three- and six-month periods ended March 28, 2015 and March 29, 2014 were as follows (dollars in millions):

[0001193125-15-153166:mdna:68]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 28,2015 |  |  | March 29,2014 |  |  | March 28,2015 |  |  | March 29,2014 |  |
| Research and development |  | $ | 1,918 |  |  | $ | 1,422 |  |  | $ | 3,813 |  |  | $ | 2,752 |  |
| Percentage of total net sales |  |  | 3.3% |  |  |  | 3.1% |  |  |  | 2.9% |  |  |  | 2.7% |  |
| Selling, general and administrative |  | $ | 3,460 |  |  | $ | 2,932 |  |  | $ | 7,060 |  |  | $ | 5,985 |  |
| Percentage of total net sales |  |  | 6.0% |  |  |  | 6.4% |  |  |  | 5.3% |  |  |  | 5.8% |  |
| Total operating expenses |  | $ | 5,378 |  |  | $ | 4,354 |  |  | $ | 10,873 |  |  | $ | 8,737 |  |
| Percentage of total net sales |  |  | 9.3% |  |  |  | 9.5% |  |  |  | 8.2% |  |  |  | 8.5% |  |

[0001193125-15-153166:mdna:69]
[same as prior period, unchanged from 0001193125-15-023697:mdna:69]

[0001193125-15-153166:mdna:70]
The
growth in R&D expense during the second quarter and first six months of 2015 compared to the same periods in 2014 was driven primarily by an increase in headcount and related expenses, including share-based compensation costs, and material costs
to support expanded R&D activities. The Company continues to believe that focused investments in R&D are critical to its future growth and competitive position in the marketplace and are directly related to timely development of new and
enhanced products that are central to the Company’s core business strategy.

[0001193125-15-153166:mdna:71]
[same as prior period, unchanged from 0001193125-15-023697:mdna:71]

[0001193125-15-153166:mdna:72]
The growth in selling, general and administrative expense during the second quarter and first six months of 2015 compared to the same periods in 2014 was
primarily due to increased headcount and related expenses, including share-based compensation costs, and higher spending on marketing and advertising.

[0001193125-15-153166:mdna:73]
[same as prior period, unchanged from 0001193125-15-023697:mdna:73]

[0001193125-15-153166:mdna:74]
Other income/(expense), net for the three- and six-month periods ended March 28, 2015 and March 29, 2014 was as follows (dollars in millions):

[0001193125-15-153166:mdna:75]
|  |  | Three Months Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  |  | March 28,2015 |  |  | March 29,2014 |  |  | Change |  |  | March 28,2015 |  |  | March 29,2014 |  |  | Change |  |
| Interest and dividend income |  | $ | 675 |  |  | $ | 410 |  |  |  |  |  |  | $ | 1,329 |  |  | $ | 837 |  |  |  |  |  |
| Interest expense |  |  | (163 | ) |  |  | (85 | ) |  |  |  |  |  |  | (294 | ) |  |  | (169 | ) |  |  |  |  |
| Other expense, net |  |  | (226 | ) |  |  | (100 | ) |  |  |  |  |  |  | (579 | ) |  |  | (197 | ) |  |  |  |  |
| Total other income/(expense), net |  | $ | 286 |  |  | $ | 225 |  |  |  | 27% |  |  | $ | 456 |  |  | $ | 471 |  |  |  | (3)% |  |

[0001193125-15-153166:mdna:76]
The increase in other income/(expense), net during the second quarter of 2015 compared to the same period in 2014 was due
primarily to higher interest income and a gain on strategic investments, partially offset by higher premium expenses on foreign exchange contracts and higher interest expense on debt. The decrease in other income/(expense), net during the first six
months of 2015 compared to the same period in 2014 was due primarily to higher premium expense on foreign exchange contracts, higher expenses associated with foreign exchange movements and higher interest expense on debt, partially offset by higher
interest income. The weighted-average interest rate earned by the Company on its cash, cash equivalents and marketable securities was 1.43% and 1.04% in the second quarter of 2015 and 2014, respectively, and 1.42% and 1.03% in the first six months
of 2015 and 2014, respectively.

[0001193125-15-153166:mdna:77]
[same as prior period, unchanged from 0001193125-15-023697:mdna:77]

[0001193125-15-153166:mdna:78]
Provision for income taxes and effective tax rates for the three- and six-month periods ended March 28, 2015 and March 29, 2014 were as follows
(dollars in millions):

[0001193125-15-153166:mdna:79]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 28,2015 |  |  | March 29,2014 |  |  | March 28,2015 |  |  | March 29,2014 |  |
| Provision for income taxes |  | $ | 4,995 |  |  | $ | 3,595 |  |  | $ | 11,387 |  |  | $ | 8,232 |  |
| Effective tax rate |  |  | 26.9% |  |  |  | 26.0% |  |  |  | 26.5% |  |  |  | 26.1% |  |

[0001193125-15-153166:mdna:80]
The Company’s effective tax rates for the second quarter and first six months of 2015 and 2014 differ from the
statutory federal income tax rate of 35% due primarily to certain undistributed foreign earnings, a substantial portion of which was generated by subsidiaries organized in Ireland, for which no U.S. taxes are provided because such earnings are
intended to be indefinitely reinvested outside the U.S. The higher effective tax rate during the second quarter and first six months of 2015 as compared to the same periods in 2014 is due primarily to a different geographic mix of earnings.

[0001193125-15-153166:mdna:81]
[same as prior period, unchanged from 0001193125-15-023697:mdna:81]

[0001193125-15-153166:mdna:82]
On June 11, 2014, the European Commission issued an opening decision initiating a formal investigation against Ireland for alleged state aid to the
Company. The opening decision concerns the allocation of profits for taxation purposes of the Irish branches of two subsidiaries of the Company. The Company believes the European Commission’s assertions are without merit. If the European
Commission were to conclude against Ireland, the European Commission could require Ireland to recover from the Company past taxes covering a period of up to 10 years reflective of the disallowed state aid. While such amount could be material, as of
March 28, 2015 the Company is unable to estimate the impact.

[0001193125-15-153166:mdna:83]
[same as prior period, unchanged from 0001193125-15-023697:mdna:82]

[0001193125-15-153166:mdna:84]
In May 2014, the Financial Accounting Standards Board issued Accounting Standards Update No. 2014-09, Revenue from Contracts with Customers (Topic
606) (“ASU 2014-09”), which amends the existing accounting standards for revenue recognition. ASU 2014-09 is based on principles that govern the recognition of revenue at an amount an entity expects to be entitled when products are
transferred to customers. ASU 2014-09 will be effective for the Company beginning in its first quarter of 2018. Early adoption is not permitted. The new revenue standard may be applied retrospectively to each prior period presented or
retrospectively with the cumulative effect recognized as of the date of adoption. The Company is currently evaluating the impact of adopting the new revenue standard on its consolidated financial statements.

[0001193125-15-153166:mdna:85]
[same as prior period, unchanged from 0001193125-15-023697:mdna:84]

[0001193125-15-153166:mdna:86]
The following tables present selected financial information and statistics as of March 28, 2015 and September 27, 2014 and during the first six
months of 2015 and 2014 (in millions):

[0001193125-15-153166:mdna:87]
|  |  | March 28,2015 |  |  | September 27,2014 |  |
| Cash, cash equivalents and marketable securities |  | $ | 193,539 |  |  | $ | 155,239 |  |
| Property, plant and equipment, net |  | $ | 20,151 |  |  | $ | 20,624 |  |
| Long-term debt |  | $ | 40,072 |  |  | $ | 28,987 |  |
| Commercial paper |  | $ | 3,799 |  |  | $ | 6,308 |  |
| Working capital |  | $ | 9,162 |  |  | $ | 5,083 |  |

[0001193125-15-153166:mdna:88]
|  |  | Six Months Ended |  |
|  |  | March 28,2015 |  |  | March 29,2014 |  |
| Cash generated by operating activities |  | $ | 52,803 |  |  | $ | 36,208 |  |
| Cash used in investing activities |  | $ | (43,496 | ) |  | $ | (3,362 | ) |
| Cash used in financing activities |  | $ | (8,662 | ) |  | $ | (28,156 | ) |

[0001193125-15-153166:mdna:89]
The Company believes its existing balances of cash, cash equivalents and marketable securities will be sufficient to
satisfy its working capital needs, capital asset purchases, outstanding commitments and other liquidity requirements associated with its existing operations over the next 12 months. The Company currently anticipates the cash used for future
dividends, the share repurchase program and debt repayments will come from its current domestic cash, cash generated from on-going U.S. operating activities and from borrowings.

[0001193125-15-153166:mdna:90]
As of March 28, 2015 and September 27, 2014, the Company’s cash, cash equivalents and marketable securities held by foreign subsidiaries
were $171.3 billion and $137.1 billion, respectively, and are generally based in U.S. dollar-denominated holdings. Amounts held by foreign subsidiaries are generally subject to U.S. income taxation on
repatriation to the U.S. The Company’s marketable securities investment portfolio is invested primarily in highly-rated securities and its investment policy generally limits the amount of credit exposure to any one issuer. The policy requires
investments generally to be investment grade with the objective of minimizing the potential risk of principal loss.

[0001193125-15-153166:mdna:91]
During the six months ended
March 28, 2015, cash generated from operating activities of $52.8 billion was a result of $31.6 billion of net income, non-cash adjustments to net income of $8.7 billion and an increase in the net change in operating assets and liabilities of
$12.5 billion. Cash used in investing activities of $43.5 billion during the six months ended March 28, 2015 consisted primarily of cash used for purchases of marketable securities, net of sales and maturities, of $37.7 billion and cash used to
acquire property, plant and equipment of $5.6 billion. Cash used in financing activities of $8.7 billion during the six months ended March 28, 2015 consisted primarily of cash used to repurchase common stock of $12.0 billion, cash used to pay
dividends and dividend equivalents of $5.5 billion and cash used for repayments of commercial paper, net of $2.5 billion, partially offset by proceeds from the issuance of long-term debt, net of $11.3 billion.

[0001193125-15-153166:mdna:92]
During the six months ended March 29, 2014, cash generated from operating activities of $36.2 billion was a result of $23.3 billion of net income,
non-cash adjustments to net income of $7.5 billion and an increase in net change in operating assets and liabilities of $5.4 billion. Cash used in investing activities of $3.4 billion during the six months ended March 29, 2014 consisted
primarily of cash used to acquire property, plant and equipment of $3.4 billion. Cash used in financing activities of $28.2 billion during the six months ended March 29, 2014 consisted primarily of cash used to repurchase common stock of $23.0
billion and cash used to pay dividends and dividend equivalents of $5.4 billion.

[0001193125-15-153166:mdna:93]
[same as prior period, unchanged from 0001193125-15-023697:mdna:91]

[0001193125-15-153166:mdna:94]
The Company’s capital expenditures were $4.1 billion during the first six months of 2015. The Company anticipates utilizing approximately $13.0
billion for capital expenditures during 2015, which includes product tooling and manufacturing process equipment; data centers; corporate facilities and infrastructure, including information systems hardware, software and enhancements; and retail
store facilities.

[0001193125-15-153166:mdna:95]
[same as prior period, unchanged from 0001193125-15-023697:mdna:93]

[0001193125-15-153166:mdna:96]
In
2014, the Board of Directors authorized the Company to issue unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company intends to use the net proceeds from the commercial paper program
for general corporate purposes, including dividends and share repurchases. As of March 28, 2015, the Company had $3.8 billion of Commercial Paper outstanding, with a weighted-average interest rate of 0.10% and maturities generally less than
nine months.

[0001193125-15-153166:mdna:97]
As of March 28, 2015, the Company has outstanding floating- and fixed-rate notes with varying maturities for an aggregate
principal amount of $39.9 billion (collectively the “Notes”). The Company has entered, and in the future may enter, into interest rate swaps to manage interest rate risk on the Notes. Interest rate swaps allow the Company to effectively
convert fixed-rate payments into floating-rate payments or floating-rate payments into fixed-rate payments. In addition, the Company has entered, and in the future may enter, into currency swaps to manage foreign currency risk on the Notes. During
the first six months of 2015, the Company issued €2.8 billion of Euro-denominated notes, $6.5 billion of U.S. dollar-denominated notes and SFr1.3 billion of Swiss Franc-denominated notes. To
manage foreign currency risk associated with the Euro-denominated notes, the Company entered into currency swaps with an aggregate notional amount of $3.5 billion, which effectively converted the Euro-denominated notes to U.S. dollar-denominated
notes. To manage interest rate risk on the U.S. dollar-denominated fixed-rate notes maturing in 2020 and 2022, the Company entered into interest rate swaps with an aggregate notional amount of $2.5 billion, which effectively converted the fixed
interest rates on these notes to a floating interest rate.

[0001193125-15-153166:mdna:98]
[same as prior period, unchanged from 0001193125-15-023697:mdna:96]

[0001193125-15-153166:mdna:99]
In 2014, the Company’s Board of Directors increased the share repurchase program authorization from $60 billion to $90 billion of the Company’s
common stock, which resulted in a total capital return program of over $130 billion. As of March 28, 2015, $80.0 billion of the share repurchase program has been utilized. The Company’s share repurchase program does not obligate
it to acquire any specific number of shares. Under the program, shares may be repurchased in privately negotiated or open market transactions, including under plans complying with Rule 10b5-1 under the Exchange Act.

[0001193125-15-153166:mdna:100]
The following table presents the Company’s dividends, dividend equivalents, share repurchases and net share settlement activity from the start of
the capital return program in August 2012 through March 28, 2015 (in millions):

[0001193125-15-153166:mdna:101]
|  |  | Dividends andDividendEquivalentsPaid |  |  | AcceleratedShareRepurchases |  |  | Open MarketShareRepurchases |  |  | TaxesRelated toSettlement ofEquity Awards |  |  | Total |  |
| Q2 2015 |  | $ | 2,743 |  |  | $ | 0 |  |  | $ | 7,000 |  |  | $ | 96 |  |  | $ | 9,839 |  |
| Q1 2015 |  |  | 2,801 |  |  |  | 0 |  |  |  | 5,000 |  |  |  | 512 |  |  |  | 8,313 |  |
| 2014 |  |  | 11,126 |  |  |  | 21,000 |  |  |  | 24,000 |  |  |  | 1,158 |  |  |  | 57,284 |  |
| 2013 |  |  | 10,564 |  |  |  | 13,950 |  |  |  | 9,000 |  |  |  | 1,082 |  |  |  | 34,596 |  |
| 2012 |  |  | 2,488 |  |  |  | 0 |  |  |  | 0 |  |  |  | 56 |  |  |  | 2,544 |  |
| Total |  | $ | 29,722 |  |  | $ | 34,950 |  |  | $ | 45,000 |  |  | $ | 2,904 |  |  | $ | 112,576 |  |

[0001193125-15-153166:mdna:102]
On April 27, 2015, the Company announced that the Board of Directors raised the cash dividend by 11% to $0.52 per
share, beginning with the dividend to be paid during the third quarter of 2015. The Company plans to increase its dividend on an annual basis subject to declaration by the Board of Directors.

[0001193125-15-153166:mdna:103]
Additionally, the Company announced on April 27, 2015 that the Board of Directors increased the share repurchase authorization from $90 billion to
$140 billion, increasing the total capital return program from $130 billion to $200 billion, which the Company expects to execute by the end of March 2017 by paying dividends and dividend equivalents, repurchasing shares and remitting withheld taxes
related to net share settlement of restricted stock units. To assist in funding its capital return program, the Company expects to continue to access the debt markets, both domestically and internationally.

[0001193125-15-153166:mdna:104]
[same as prior period, unchanged from 0001193125-15-023697:mdna:102]

[0001193125-15-153166:mdna:105]
[same as prior period, unchanged from 0001193125-15-023697:mdna:103]

[0001193125-15-153166:mdna:106]
[same as prior period, unchanged from 0001193125-15-023697:mdna:104]

[0001193125-15-153166:mdna:107]
The Company’s major facility leases are typically for terms not exceeding 10 years and generally contain multi-year renewal options. As of
March 28, 2015, the Company had a total of 453 retail stores. Leases for retail space are for terms ranging from five to 20 years, the majority of which are for 10 years, and often contain multi-year renewal options. As of March 28, 2015,
the Company’s total future minimum lease payments under noncancelable operating leases were $5.1 billion, of which $3.4 billion related to leases for retail space.

[0001193125-15-153166:mdna:108]
[same as prior period, unchanged from 0001193125-15-023697:mdna:106]

[0001193125-15-153166:mdna:109]
The Company utilizes several outsourcing
partners to manufacture sub-assemblies for the Company’s products and to perform final assembly and testing of finished products. These outsourcing partners acquire components and build product based on demand information supplied by the
Company, which typically covers periods up to 150 days. The Company also obtains individual components for its products from a wide variety of individual suppliers. Consistent with industry practice, the Company acquires components through a
combination of purchase orders, supplier contracts, and open orders based on projected demand information. Where appropriate, the purchases are applied to inventory component prepayments that are outstanding with
the respective supplier. As of March 28, 2015, the Company had outstanding off-balance sheet third-party manufacturing commitments and component purchase commitments of $19.0 billion.

[0001193125-15-153166:mdna:110]
[same as prior period, unchanged from 0001193125-15-023697:mdna:108]

[0001193125-15-153166:mdna:111]
In addition to the commitments mentioned
above, the Company had other off-balance sheet obligations of $4.1 billion as of March 28, 2015, that were comprised of commitments to acquire capital assets, including product tooling and manufacturing process equipment, and commitments
related to advertising, R&D, Internet and telecommunications services, energy and other obligations.

[0001193125-15-153166:mdna:112]
The Company’s other non-current
liabilities in the Condensed Consolidated Balance Sheets consist primarily of deferred tax liabilities, gross unrecognized tax benefits and the related gross interest and penalties. As of March 28, 2015, the Company had non-current deferred tax
liabilities of $23.8 billion. Additionally, as of March 28, 2015, the Company had gross unrecognized tax benefits of $4.6 billion and an additional $844 million for gross interest and penalties classified as non-current liabilities. At this
time, the Company is unable to make a reasonably reliable estimate of the timing of payments due to uncertainties in the timing of tax audit outcomes.

[0001193125-15-153166:mdna:113]
[same as prior period, unchanged from 0001193125-15-023697:mdna:111]

[0001193125-15-153166:mdna:114]
The Company generally does not indemnify
end-users of its operating system and application software against legal claims that the software infringes third-party intellectual property rights. Other agreements entered into by the Company sometimes include indemnification provisions under
which the Company could be subject to costs and/or damages in the event of an infringement claim against the Company or an indemnified third-party. However, the Company has not been required to make any significant payments resulting from such an
infringement claim asserted against it or an indemnified third-party. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss with respect to indemnification of end-users of its
operating system or application software for infringement of third-party intellectual property rights. The Company did not record a liability for infringement costs related to indemnification as of March 28, 2015 or September 27, 2014.

[0001193125-15-153166:mdna:115]
The Company has entered into indemnification agreements with its directors and executive officers. Under these agreements, the Company has agreed to
indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It
is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each
claim. However, the Company maintains directors and officers liability insurance coverage to reduce its exposure to such obligations, and payments made under these agreements historically have not been material.

[0001193125-15-153166:mdna:116]
[same as prior period, unchanged from 0001193125-15-023697:mdna:114]

[0001193125-15-153166:mdna:117]
The preparation of financial statements and related disclosures in conformity with U.S. generally accepted accounting principles (“GAAP”) and
the Company’s discussion and analysis of its financial condition and operating results require the Company’s management to make judgments, assumptions, and estimates that affect the amounts reported in its condensed consolidated financial
statements and accompanying notes. Note 1, “Summary of Significant Accounting Policies” in Part I, Item 1 of this Form 10-Q and in the Notes to Consolidated Financial Statements in Part II, Item 8 of the 2014 Form 10-K, as
updated by the Company’s Current Report on Form 8-K dated January 28, 2015, describes the significant accounting policies and methods used in the preparation of the Company’s condensed consolidated financial statements. Management
bases its estimates on historical experience and on various other assumptions it believes to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities. Actual
results may differ from these estimates and such differences may be material.

[0001193125-15-153166:mdna:118]
Management believes the Company’s critical accounting policies
and estimates are those related to revenue recognition, valuation and impairment of marketable securities, inventory valuation and valuation of manufacturing-related assets and estimated purchase commitment cancellation fees, warranty costs, income
taxes, and legal and other contingencies. Management considers these policies critical because they are both important to the portrayal of the Company’s financial condition and operating results, and they require management to make judgments
and estimates about inherently uncertain matters. The Company’s senior management has reviewed these critical accounting policies and related disclosures with the Audit and Finance Committee of the Company’s Board of Directors.

[0001193125-15-153166:mdna:119]
[same as prior period, unchanged from 0001193125-15-023697:mdna:117]

[0001193125-15-153166:mdna:120]
Net sales consist primarily of revenue
from the sale of hardware, software, digital content and applications, accessories, and service and support contracts. The Company recognizes revenue when persuasive evidence of an arrangement exists, delivery has occurred, the sales price is fixed
or determinable and collection is probable. Product is considered delivered to the customer once it has been shipped and title, risk of loss and rewards of ownership have been transferred. For most of the Company’s product sales, these criteria
are met at the time the product is shipped. For online sales to individuals, for some sales to education customers in the U.S., and for certain other sales, the Company defers revenue until the customer receives the product because the Company
retains a portion of the risk of loss on these sales during transit. For payment terms in excess of the Company’s standard payment terms, revenue is recognized as payments become due unless the Company has positive evidence that the sales price
is fixed or determinable, such as a successful history of collection, without concession, on comparable arrangements. The Company recognizes revenue from the sale of hardware products, software bundled with hardware that is essential to the
functionality of the hardware and third-party digital content sold on the iTunes Store in accordance with general revenue recognition accounting guidance. The Company recognizes revenue in accordance with industry specific software accounting
guidance for the following types of sales transactions: (i) standalone sales of software products, (ii) sales of software upgrades and (iii) sales of software bundled with hardware not essential to the functionality of the hardware.

[0001193125-15-153166:mdna:121]
For multi-element arrangements that include hardware products containing software essential to the hardware product’s functionality,
undelivered software elements that relate to the hardware product’s essential software and/or undelivered non-software services, the Company allocates revenue to all deliverables based on their relative selling prices. In such circumstances,
the Company uses a hierarchy to determine the selling price to be used for allocating revenue to deliverables: (i) vendor-specific objective evidence of fair value (“VSOE”), (ii) third-party evidence of selling price
(“TPE”) and (iii) best estimate of selling price (“ESP”). VSOE generally exists only when the Company sells the deliverable separately and is the price actually charged by the Company for that deliverable. ESPs reflect the
Company’s best estimates of what the selling prices of elements would be if they were sold regularly on a stand-alone basis.

[0001193125-15-153166:mdna:122]
For sales of
qualifying versions of iOS devices, Mac and Apple TV, the Company has indicated it may from time to time provide future unspecified software upgrades and features free of charge to customers. The Company also provides various non-software services
to owners of qualifying versions of iOS devices and Mac. Because the Company has neither VSOE nor TPE for the unspecified software upgrade rights or the non-software services, revenue is allocated to these rights and services based on the
Company’s ESPs. Revenue allocated to the unspecified software upgrade rights and non-software services based on the Company’s ESPs is deferred and recognized on a straight-line basis over the estimated period the software upgrades and
non-software services are expected to be provided for each of these devices, which ranges from two to four years.

[0001193125-15-153166:mdna:123]
The Company’s process for
determining ESPs involves management’s judgment and considers multiple factors that may vary over time depending upon the unique facts and circumstances related to each deliverable. Should future facts and circumstances change, the
Company’s ESPs and the future rate of related amortization for software upgrades and non-software services related to future sales of these devices could change. Factors subject to change include the unspecified software upgrade rights offered,
the estimated value of unspecified software upgrade rights, the estimated or actual costs incurred to provide non-software services and the estimated period software upgrades and non-software services are expected to be provided.

[0001193125-15-153166:mdna:124]
The Company records reductions to revenue for estimated commitments related to price protection and
other customer incentive programs. For transactions involving price protection, the Company recognizes revenue net of the estimated amount to be refunded, provided the refund amount can be reasonably and reliably estimated and the other conditions
for revenue recognition have been met. The Company’s policy requires that, if refunds cannot be reliably estimated, revenue is not recognized until reliable estimates can be made or the price protection lapses. For the Company’s other
customer incentive programs, the estimated cost is recognized at the later of the date at which the Company has sold the product or the date at which the program is offered. The Company also records reductions to revenue for expected future product
returns based on the Company’s historical experience. Future market conditions and product transitions may require the Company to increase customer incentive programs that could result in reductions to future revenue. Additionally, certain
customer incentive programs require management to estimate the number of customers who will actually redeem the incentive. Management’s estimates are based on historical experience and the specific terms and conditions of particular incentive
programs. If a greater than estimated proportion of customers redeems such incentives, the Company would be required to record additional reductions to revenue, which would have an adverse impact on the Company’s results of operations.

[0001193125-15-153166:mdna:125]
[same as prior period, unchanged from 0001193125-15-023697:mdna:123]

[0001193125-15-153166:mdna:126]
The
Company’s investments in available-for-sale securities are reported at fair value. Unrealized gains and losses related to changes in the fair value of securities are recognized in accumulated other comprehensive income, net of tax, in the
Company’s Condensed Consolidated Balance Sheets. Changes in the fair value of available-for-sale securities impact the Company’s net income only when such securities are sold or an other-than-temporary impairment is recognized. Realized
gains and losses on the sale of securities are determined by specific identification of each security’s cost basis. The Company regularly reviews its investment portfolio to determine if any security is other-than-temporarily impaired, which
would require the Company to record an impairment charge in the period any such determination is made. In making this judgment, the Company evaluates, among other things, the duration and extent to which the fair value of a security is less than its
cost; the financial condition of the issuer and any changes thereto; and the Company’s intent to sell, or whether it will more likely than not be required to sell, the security before recovery of its amortized cost basis. The Company’s
assessment on whether a security is other-than-temporarily impaired could change in the future due to new developments or changes in assumptions related to any particular security.

[0001193125-15-153166:mdna:127]
[same as prior period, unchanged from 0001193125-15-023697:mdna:125]

[0001193125-15-153166:mdna:128]
[same as prior period, unchanged from 0001193125-15-023697:mdna:126]

[0001193125-15-153166:mdna:129]
[same as prior period, unchanged from 0001193125-15-023697:mdna:127]

[0001193125-15-153166:mdna:130]
The
Company records accruals for estimated cancellation fees related to component orders that have been cancelled or are expected to be cancelled. Consistent with industry practice, the Company acquires components through a combination of purchase
orders, supplier contracts, and open orders in each case based on projected demand. Where appropriate, the purchases are applied to inventory component prepayments that are outstanding with the respective supplier. Purchase
commitments typically cover the Company’s forecasted component and manufacturing requirements for periods up to 150 days. If there is an abrupt and substantial decline in demand for one or more of the Company’s products, if the
Company’s product development plans change, or if there is an unanticipated change in technological requirements for any of the Company’s products, then the Company may be required to record additional accruals for cancellation fees that
would adversely affect its results of operations in the period when the cancellation fees are identified and recorded.

[0001193125-15-153166:mdna:131]
[same as prior period, unchanged from 0001193125-15-023697:mdna:129]

[0001193125-15-153166:mdna:132]
[same as prior period, unchanged from 0001193125-15-023697:mdna:130]

[0001193125-15-153166:mdna:133]
[same as prior period, unchanged from 0001193125-15-023697:mdna:131]

[0001193125-15-153166:mdna:134]
[same as prior period, unchanged from 0001193125-15-023697:mdna:132]

[0001193125-15-153166:mdna:135]
[same as prior period, unchanged from 0001193125-15-023697:mdna:133]

[0001193125-15-153166:mdna:136]
[same as prior period, unchanged from 0001193125-15-023697:mdna:134]

[0001193125-15-153166:mdna:137]
Legal and Other Contingencies

[0001193125-15-153166:mdna:138]
As discussed in Part II, Item 1 of this Form 10-Q under the heading “Legal Proceedings” and in Part I, Item 1 of this Form 10-Q in the
Notes to Condensed Consolidated Financial Statements, in Note 10, “Commitments and Contingencies,” the Company is subject to various legal proceedings and claims that arise in the ordinary course of business. The Company records a
liability when it is probable that a loss has been incurred and the amount is reasonably estimable. There is significant judgment required in both the probability determination and as to whether an exposure can be reasonably estimated. In the
opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to loss contingencies for legal and other contingencies. However,
the outcome of legal proceedings and claims brought against the Company is subject to significant uncertainty. Therefore, although management considers the likelihood of such an outcome to be remote, if one or more of these legal matters were
resolved against the Company in a reporting period for amounts in excess of management’s expectations, the Company’s consolidated financial statements for that reporting period could be materially adversely affected.
