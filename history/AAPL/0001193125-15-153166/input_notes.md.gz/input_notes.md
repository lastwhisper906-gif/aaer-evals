# AAPL notes — 0001193125-15-153166


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001193125-15-153166:notes:1]
[same as prior period, unchanged from 0001193125-15-023697:notes:1]

[0001193125-15-153166:notes:2]
[same as prior period, unchanged from 0001193125-15-023697:notes:2]

[0001193125-15-153166:notes:3]
These condensed consolidated financial statements
 and accompanying notes should be read in conjunction with the
 Company’s annual consolidated financial statements and the
 notes thereto for the fiscal year ended September 27, 2014,
 included in its Annual Report on Form 10-K as updated by the
 Company’s Current Report on Form 8-K dated January 28,
 2015 (hereinafter, the “2014 Form 10-K”). The
 Company’s fiscal year is the 52 or 53-week period that ends
 on the last Saturday of September. An additional week is included
 in the first fiscal quarter approximately every six years to
 realign fiscal quarters with calendar quarters. The Company’s
 fiscal years 2015 and 2014 each include 52 weeks. Unless otherwise
 stated, references to particular years, quarters or months refer to
 the Company’s fiscal years ended in September and the
 associated quarters or months of those fiscal years.


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001193125-15-153166:notes:4]
The following tables show the Company’s cash
 and available-for-sale
 securities’ adjusted cost, gross unrealized gains, gross
 unrealized losses and fair value by significant investment category
 recorded as cash and cash equivalents or short- or long-term
 marketable securities as of March 28, 2015 and
 September 27, 2014 (in millions):

[0001193125-15-153166:notes:5]
|  |  | March 28, 2015 |  |
|  |  | Adjusted Cost |  |  | Unrealized Gains |  |  | Unrealized Losses |  |  | Fair Value |  |  | Cash and Cash Equivalents |  |  | Short-Term Marketable Securities |  |  | Long-Term Marketable Securities |  |
| Cash |  | $ | 9,879 |  |  | $ | 0 |  |  | $ | 0 |  |  | $ | 9,879 |  |  | $ | 9,879 |  |  | $ | 0 |  |  | $ | 0 |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  |  | 1,457 |  |  |  | 0 |  |  |  | 0 |  |  |  | 1,457 |  |  |  | 1,457 |  |  |  | 0 |  |  |  | 0 |  |
| Mutual funds |  |  | 2,384 |  |  |  | 0 |  |  |  | (126 | ) |  |  | 2,258 |  |  |  | 0 |  |  |  | 2,258 |  |  |  | 0 |  |
| Subtotal |  |  | 3,841 |  |  |  | 0 |  |  |  | (126 | ) |  |  | 3,715 |  |  |  | 1,457 |  |  |  | 2,258 |  |  |  | 0 |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities |  |  | 42,854 |  |  |  | 145 |  |  |  | (12 | ) |  |  | 42,987 |  |  |  | 0 |  |  |  | 1,791 |  |  |  | 41,196 |  |
| U.S. agency securities |  |  | 6,901 |  |  |  | 11 |  |  |  | (2 | ) |  |  | 6,910 |  |  |  | 585 |  |  |  | 1,056 |  |  |  | 5,269 |  |
| Non-U.S. government securities |  |  | 7,114 |  |  |  | 86 |  |  |  | (80 | ) |  |  | 7,120 |  |  |  | 41 |  |  |  | 271 |  |  |  | 6,808 |  |
| Certificates of deposit and time deposits |  |  | 3,473 |  |  |  | 0 |  |  |  | 0 |  |  |  | 3,473 |  |  |  | 1,163 |  |  |  | 1,252 |  |  |  | 1,058 |  |
| Commercial paper |  |  | 2,956 |  |  |  | 0 |  |  |  | 0 |  |  |  | 2,956 |  |  |  | 1,364 |  |  |  | 1,592 |  |  |  | 0 |  |
| Corporate securities |  |  | 100,658 |  |  |  | 427 |  |  |  | (370 | ) |  |  | 100,715 |  |  |  | 0 |  |  |  | 10,325 |  |  |  | 90,390 |  |
| Municipal securities |  |  | 942 |  |  |  | 5 |  |  |  | (1 | ) |  |  | 946 |  |  |  | 0 |  |  |  | 24 |  |  |  | 922 |  |
| Mortgage- and asset-backed securities |  |  | 14,782 |  |  |  | 75 |  |  |  | (19 | ) |  |  | 14,838 |  |  |  | 0 |  |  |  | 38 |  |  |  | 14,800 |  |
| Subtotal |  |  | 179,680 |  |  |  | 749 |  |  |  | (484 | ) |  |  | 179,945 |  |  |  | 3,153 |  |  |  | 16,349 |  |  |  | 160,443 |  |
| Total |  | $ | 193,400 |  |  | $ | 749 |  |  | $ | (610 | ) |  | $ | 193,539 |  |  | $ | 14,489 |  |  | $ | 18,607 |  |  | $ | 160,443 |  |
|  |  | September 27, 2014 |  |
|  |  | Adjusted Cost |  |  | Unrealized Gains |  |  | Unrealized Losses |  |  | Fair Value |  |  | Cash and Cash Equivalents |  |  | Short-Term Marketable Securities |  |  | Long-Term Marketable Securities |  |
| Cash |  | $ | 10,232 |  |  | $ | 0 |  |  | $ | 0 |  |  | $ | 10,232 |  |  | $ | 10,232 |  |  | $ | 0 |  |  | $ | 0 |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  |  | 1,546 |  |  |  | 0 |  |  |  | 0 |  |  |  | 1,546 |  |  |  | 1,546 |  |  |  | 0 |  |  |  | 0 |  |
| Mutual funds |  |  | 2,531 |  |  |  | 1 |  |  |  | (132 | ) |  |  | 2,400 |  |  |  | 0 |  |  |  | 2,400 |  |  |  | 0 |  |
| Subtotal |  |  | 4,077 |  |  |  | 1 |  |  |  | (132 | ) |  |  | 3,946 |  |  |  | 1,546 |  |  |  | 2,400 |  |  |  | 0 |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities |  |  | 23,140 |  |  |  | 15 |  |  |  | (9 | ) |  |  | 23,146 |  |  |  | 12 |  |  |  | 607 |  |  |  | 22,527 |  |
| U.S. agency securities |  |  | 7,373 |  |  |  | 3 |  |  |  | (11 | ) |  |  | 7,365 |  |  |  | 652 |  |  |  | 157 |  |  |  | 6,556 |  |
| Non-U.S. government securities |  |  | 6,925 |  |  |  | 69 |  |  |  | (69 | ) |  |  | 6,925 |  |  |  | 0 |  |  |  | 204 |  |  |  | 6,721 |  |
| Certificates of deposit and time deposits |  |  | 3,832 |  |  |  | 0 |  |  |  | 0 |  |  |  | 3,832 |  |  |  | 1,230 |  |  |  | 1,233 |  |  |  | 1,369 |  |
| Commercial paper |  |  | 475 |  |  |  | 0 |  |  |  | 0 |  |  |  | 475 |  |  |  | 166 |  |  |  | 309 |  |  |  | 0 |  |
| Corporate securities |  |  | 85,431 |  |  |  | 296 |  |  |  | (241 | ) |  |  | 85,486 |  |  |  | 6 |  |  |  | 6,298 |  |  |  | 79,182 |  |
| Municipal securities |  |  | 940 |  |  |  | 8 |  |  |  | 0 |  |  |  | 948 |  |  |  | 0 |  |  |  | 0 |  |  |  | 948 |  |
| Mortgage- and asset-backed securities |  |  | 12,907 |  |  |  | 26 |  |  |  | (49 | ) |  |  | 12,884 |  |  |  | 0 |  |  |  | 25 |  |  |  | 12,859 |  |
| Subtotal |  |  | 141,023 |  |  |  | 417 |  |  |  | (379 | ) |  |  | 141,061 |  |  |  | 2,066 |  |  |  | 8,833 |  |  |  | 130,162 |  |
| Total |  | $ | 155,332 |  |  | $ | 418 |  |  | $ | (511 | ) |  | $ | 155,239 |  |  | $ | 13,844 |  |  | $ | 11,233 |  |  | $ | 130,162 |  |

[0001193125-15-153166:notes:6]
[same as prior period, unchanged from 0001193125-15-023697:notes:7]

[0001193125-15-153166:notes:7]
[same as prior period, unchanged from 0001193125-15-023697:notes:8]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-15-153166:notes:8]
Note 10 – Commitments and Contingencies

[0001193125-15-153166:notes:9]
Accrued Warranty and Indemnification

[0001193125-15-153166:notes:10]
The following table shows changes in the
 Company’s accrued warranties and related costs for the three-
 and six-month periods ended March 28, 2015 and March 29,
 2014 (in millions):

[0001193125-15-153166:notes:11]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 28, 2015 |  |  | March 29, 2014 |  |  | March 28, 2015 |  |  | March 29, 2014 |  |
| Beginning accrued warranty and related costs |  | $ | 5,195 |  |  | $ | 3,980 |  |  | $ | 4,159 |  |  | $ | 2,967 |  |
| Cost of warranty claims |  |  | (1,030 | ) |  |  | (865 | ) |  |  | (2,074 | ) |  |  | (1,929 | ) |
| Accruals for product warranty |  |  | 978 |  |  |  | 1,253 |  |  |  | 3,058 |  |  |  | 3,330 |  |
| Ending accrued warranty and related costs |  | $ | 5,143 |  |  | $ | 4,368 |  |  | $ | 5,143 |  |  | $ | 4,368 |  |

[0001193125-15-153166:notes:12]
The Company generally does not indemnify end-users
 of its operating system and application software against legal
 claims that the software infringes third-party intellectual
 property rights. Other agreements entered into by the Company
 sometimes include indemnification provisions under which the
 Company could be subject to costs and/or damages in the event of an
 infringement claim against the Company or an indemnified
 third-party. However, the Company has not been required to make any
 significant payments resulting from such an infringement claim
 asserted against it or an indemnified third-party. In the opinion
 of management, there was not at least a reasonable possibility the
 Company may have incurred a material loss with respect to
 indemnification of end-users of its operating system or application
 software for infringement of third-party intellectual property
 rights. The Company did not record a liability for infringement
 costs related to indemnification as of March 28, 2015 or
 September 27, 2014.

[0001193125-15-153166:notes:13]
The Company has entered into indemnification
 agreements with its directors and executive officers. Under these
 agreements, the Company has agreed to indemnify such individuals to
 the fullest extent permitted by law against liabilities that arise
 by reason of their status as directors or officers and to advance
 expenses incurred by such individuals in connection with related
 legal proceedings. It is not possible to determine the maximum
 potential amount of payments the Company could be required to make
 under these agreements due to the limited history of prior
 indemnification claims and the unique facts and circumstances
 involved in each claim. However, the Company maintains directors
 and officers liability insurance coverage to reduce its exposure to
 such obligations, and payments made under these agreements
 historically have not been material.

[0001193125-15-153166:notes:14]
Concentrations in the Available Sources of Supply of Materials
 and Product

[0001193125-15-153166:notes:15]
Although most components essential to the
 Company’s business are generally available from multiple
 sources, a number of components are currently obtained from single
 or limited sources. In addition, the Company competes for various
 components with other participants in the markets for mobile
 communication and media devices and personal computers. Therefore,
 many components used by the Company, including those that are
 available from multiple sources, are at times subject to
 industry-wide shortage and significant pricing fluctuations that
 could materially adversely affect the Company’s financial
 condition and operating results.

[0001193125-15-153166:notes:16]
The Company uses some custom components that are
 not commonly used by its competitors, and new products introduced
 by the Company often utilize custom components available from only
 one source. When a component or product uses new technologies,
 initial capacity constraints may exist until the suppliers’
 yields have matured or manufacturing capacity has increased. If the
 Company’s supply of components for a new or existing product
 were delayed or constrained, or if an outsourcing partner delayed
 shipments of completed products to the Company, the Company’s
 financial condition and operating results could be materially
 adversely affected. The Company’s business and financial
 performance could also be materially adversely affected depending
 on the time required to obtain sufficient quantities from the
 original source, or to identify and obtain sufficient quantities
 from an alternative source. Continued availability of these
 components at acceptable prices, or at all, may be affected if
 those suppliers concentrated on the production of common components
 instead of components customized to meet the Company’s
 requirements.

[0001193125-15-153166:notes:17]
The Company has entered into agreements for the
 supply of many components; however, there can be no guarantee that
 the Company will be able to extend or renew these agreements on
 similar terms, or at all. Therefore, the Company remains subject to
 significant risks of supply shortages and price increases that
 could materially adversely affect its financial condition and
 operating results.

[0001193125-15-153166:notes:18]
Substantially all of the Company’s hardware
 products are manufactured by outsourcing partners that are located
 primarily in Asia. A significant concentration of this
 manufacturing is currently performed by a small number of
 outsourcing partners, often in single locations. Certain of these
 outsourcing partners are the sole-sourced suppliers of components
 and manufacturers for many of the Company’s products.
 Although the Company works closely with its outsourcing partners on
 manufacturing schedules, the Company’s operating results
 could be adversely affected if its outsourcing partners were unable
 to meet their production commitments. The Company’s purchase
 commitments typically cover its requirements for periods up to 150
 days.

[0001193125-15-153166:notes:19]
Other Off-Balance Sheet Commitments

[0001193125-15-153166:notes:20]
Operating Leases

[0001193125-15-153166:notes:21]
The Company leases various equipment and
 facilities, including retail space, under noncancelable operating
 lease arrangements. The Company does not currently utilize any
 other off-balance sheet financing arrangements. The major facility
 leases are typically for terms not exceeding 10 years and generally
 contain multi-year renewal options. As of March 28, 2015, the
 Company had a total of 453 retail stores. Leases for retail space
 are for terms ranging from five to 20 years, the majority of which
 are for 10 years, and often contain multi-year renewal options. As
 of March 28, 2015, the Company’s total future minimum
 lease payments under noncancelable operating leases were $5.1
 billion, of which $3.4 billion related to leases for retail
 space.

[0001193125-15-153166:notes:22]
Other Commitments

[0001193125-15-153166:notes:23]
The Company utilizes several outsourcing partners
 to manufacture sub-assemblies for the Company’s products and
 to perform final assembly and testing of finished products. These
 outsourcing partners acquire components and build product based on
 demand information supplied by the Company, which typically covers
 periods up to 150 days. The Company also obtains individual
 components for its products from a wide variety of individual
 suppliers. Consistent with industry practice, the Company acquires
 components through a combination of purchase orders, supplier
 contracts and open orders based on projected demand information.
 Where appropriate, the purchases are applied
 to inventory component prepayments that
 are outstanding with the respective supplier. As of
 March 28, 2015, the Company had outstanding off-balance sheet
 third-party manufacturing commitments and component purchase
 commitments of $19.0 billion.

[0001193125-15-153166:notes:24]
In addition to the commitments mentioned above, the
 Company had other off-balance sheet obligations of $4.1 billion as
 of March 28, 2015, which were comprised of commitments to
 acquire capital assets, including product tooling and manufacturing
 process equipment, and commitments related to advertising, research
 and development (“R&D”), Internet and
 telecommunications services, energy and other obligations.

[0001193125-15-153166:notes:25]
Contingencies

[0001193125-15-153166:notes:26]
The Company is subject to various legal proceedings
 and claims that have arisen in the ordinary course of business and
 that have not been fully adjudicated, certain of which are
 discussed in Part II, Item 1 of this Form 10-Q under the
 heading “Legal Proceedings” and in Part II,
 Item 1A of this Form 10-Q under the heading “Risk
 Factors.” In the opinion of management, there was not at
 least a reasonable possibility the Company may have incurred a
 material loss, or a material loss in excess of a recorded accrual,
 with respect to loss contingencies. However, the outcome of
 litigation is inherently uncertain. Therefore, although management
 considers the likelihood of such an outcome to be remote, if one or
 more of these legal matters were resolved against the Company in a
 reporting period for amounts in excess of management’s
 expectations, the Company’s consolidated financial statements
 for that reporting period could be materially adversely
 affected.

[0001193125-15-153166:notes:27]
Smartflash LLC, et al., v. Apple Inc., et al.

[0001193125-15-153166:notes:28]
On May 29, 2013, Smartflash LLC and Smartflash
 Technologies Limited filed an action against the Company in the
 United States District Court for the Eastern District of Texas,
 Tyler Division, alleging that the Company infringed certain patents
 relating to data storage and access systems. On February 24,
 2015, a jury returned a verdict against the Company, and awarded
 damages of approximately $533 million. The Company is challenging
 the verdict, believes it has valid defenses and has not recorded a
 loss accrual at this time.

[0001193125-15-153166:notes:29]
Apple Inc. v. Samsung Electronics Co., Ltd, et al.

[0001193125-15-153166:notes:30]
On August 24, 2012, a jury returned a verdict
 awarding the Company $1.05 billion in its lawsuit against Samsung
 Electronics Co., Ltd and affiliated parties in the United States
 District Court, Northern District of California, San Jose Division.
 On March 6, 2014, the District Court entered final judgment in
 favor of the Company in the amount of approximately $930
 million. Because the award is now subject to appeal, the
 Company has not recognized the award in its results of
 operations.


## us-gaap:DebtDisclosureTextBlock

[0001193125-15-153166:notes:31]
Note 6 – Debt

[0001193125-15-153166:notes:32]
Commercial Paper

[0001193125-15-153166:notes:33]
In 2014, the Board of Directors authorized the
 Company to issue unsecured short-term promissory notes
 (“Commercial Paper”) pursuant to a commercial paper
 program. The Company intends to use net proceeds from the
 commercial paper program for general corporate purposes, including
 dividends and share repurchases. As of March 28, 2015 and
 September 27, 2014, the Company had $3.8 billion and $6.3
 billion of Commercial Paper outstanding, respectively, with a
 weighted-average interest rate of 0.10% and 0.12%, respectively,
 and maturities generally less than nine months.

[0001193125-15-153166:notes:34]
The following table provides a summary of cash
 flows associated with the issuance and maturities of Commercial
 Paper for the six months ended March 28, 2015 (in
 millions):

[0001193125-15-153166:notes:35]
| Maturities less than 90 days: |  |  |  |  |
| Proceeds from (repayments of) commercial paper, net |  | $ | 985 |  |
| Maturities greater than 90 days: |  |  |  |  |
| Proceeds from commercial paper |  |  | 547 |  |
| Repayments of commercial paper |  |  | (4,040 | ) |
| Maturities greater than 90 days, net |  |  | (3,493 | ) |
| Total repayments of commercial paper, net |  | $ | (2,508 | ) |

[0001193125-15-153166:notes:36]
Long-Term Debt

[0001193125-15-153166:notes:37]
As of March 28, 2015, the Company has
 outstanding floating- and fixed-rate notes with varying maturities
 for an aggregate principal amount of $39.9 billion (collectively
 the “Notes”). The Notes are senior unsecured
 obligations, and interest is payable in arrears, quarterly for the
 domestic floating-rate notes, semi-annually for the domestic
 fixed-rate notes and annually for the foreign fixed-rate notes. The
 following table provides a summary of the Company’s long-term
 debt as of March 28, 2015 and September 27, 2014:

[0001193125-15-153166:notes:38]
|  |  | March 28, 2015 |  |  | September 27, 2014 |  |
|  |  | Amount (in millions) |  |  | Effective Interest Rate |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |
| Floating-rate notes due 2016 (1) |  | $ | 1,000 |  |  |  | 0.51% |  |  | $ | 1,000 |  |  |  | 0.51% |  |
| Floating-rate notes due 2017 (2) |  |  | 1,000 |  |  |  | 0.33% |  |  |  | 1,000 |  |  |  | 0.31% |  |
| Floating-rate notes due 2018 (1) |  |  | 2,000 |  |  |  | 1.10% |  |  |  | 2,000 |  |  |  | 1.10% |  |
| Floating-rate notes due 2019 (2) |  |  | 1,000 |  |  |  | 0.56% |  |  |  | 1,000 |  |  |  | 0.54% |  |
| Floating-rate notes due 2020 (3) |  |  | 500 |  |  |  | 0.51% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 0.45% notes due 2016 (1) |  |  | 1,500 |  |  |  | 0.51% |  |  |  | 1,500 |  |  |  | 0.51% |  |
| Fixed-rate 1.05% notes due 2017 (2) |  |  | 1,500 |  |  |  | 0.32% |  |  |  | 1,500 |  |  |  | 0.30% |  |
| Fixed-rate 1.00% notes due 2018 (1) |  |  | 4,000 |  |  |  | 1.08% |  |  |  | 4,000 |  |  |  | 1.08% |  |
| Fixed-rate 2.10% notes due 2019 (2) |  |  | 2,000 |  |  |  | 0.55% |  |  |  | 2,000 |  |  |  | 0.53% |  |
| Fixed-rate 1.55% notes due 2020 (3) |  |  | 1,250 |  |  |  | 0.50% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.85% notes due 2021 (2) |  |  | 3,000 |  |  |  | 0.81% |  |  |  | 3,000 |  |  |  | 0.79% |  |
| Fixed-rate 2.15% notes due 2022 (3) |  |  | 1,250 |  |  |  | 0.82% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 1.00% Euro-denominated notes due 2022 (4) |  |  | 1,534 |  |  |  | 2.94% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.40% notes due 2023 (1) |  |  | 5,500 |  |  |  | 2.44% |  |  |  | 5,500 |  |  |  | 2.44% |  |
| Fixed-rate 3.45% notes due 2024 (2) |  |  | 2,500 |  |  |  | 0.92% |  |  |  | 2,500 |  |  |  | 0.90% |  |
| Fixed-rate 0.38% Swiss Franc-denominated notes due 2024 (5) |  |  | 915 |  |  |  | 0.28% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.50% notes due 2025 (3) |  |  | 1,500 |  |  |  | 2.60% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 1.63% Euro-denominated notes due 2026 (4) |  |  | 1,534 |  |  |  | 3.45% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 0.75% Swiss Franc-denominated notes due 2030 (5) |  |  | 392 |  |  |  | 0.74% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 3.85% notes due 2043 (1) |  |  | 3,000 |  |  |  | 3.91% |  |  |  | 3,000 |  |  |  | 3.91% |  |
| Fixed-rate 4.45% notes due 2044 (2) |  |  | 1,000 |  |  |  | 4.48% |  |  |  | 1,000 |  |  |  | 4.48% |  |
| Fixed-rate 3.45% notes due 2045 (3) |  |  | 2,000 |  |  |  | 3.58% |  |  |  | 0 |  |  |  | 0 |  |
| Total borrowings |  |  | 39,875 |  |  |  |  |  |  |  | 29,000 |  |  |  |  |  |
| Unamortized discount |  |  | (80 | ) |  |  |  |  |  |  | (52 | ) |  |  |  |  |
| Hedge accounting fair value adjustments |  |  | 277 |  |  |  |  |  |  |  | 39 |  |  |  |  |  |
| Total long-term debt |  | $ | 40,072 |  |  |  |  |  |  | $ | 28,987 |  |  |  |  |  |

[0001193125-15-153166:notes:39]
|  | (1) | Tranche relates to the $17.0 billion debt issuance in the third quarter of 2013. |  |

[0001193125-15-153166:notes:40]
|  | (2) | Tranche relates to the $12.0 billion debt issuance in the third quarter of 2014. |  |

[0001193125-15-153166:notes:41]
|  | (3) | Tranche relates to the $6.5 billion debt issuance in the second quarter of 2015. |  |

[0001193125-15-153166:notes:42]
|  | (4) | Tranche relates to Euro-denominated debt issuance of €2.8 billion in the first quarter of 2015. |  |

[0001193125-15-153166:notes:43]
|  | (5) | Tranche relates to Swiss Franc-denominated debt issuance of SFr1.3 billion in the second quarter of 2015. |  |

[0001193125-15-153166:notes:44]
During the first six months of 2015, the Company
 issued €2.8
 billion of Euro-denominated notes, $6.5 billion of U.S.
 dollar-denominated notes and SFr1.3 billion of Swiss
 Franc-denominated notes. To manage foreign currency risk associated
 with the Euro-denominated notes, the Company entered into currency
 swaps with an aggregate notional amount of $3.5 billion, which
 effectively converted the Euro-denominated notes to U.S.
 dollar-denominated notes. To manage interest rate risk on the U.S.
 dollar-denominated fixed-rate notes maturing in 2020 and 2022, the
 Company entered into interest rate swaps with an aggregate notional
 amount of $2.5 billion, which effectively converted the fixed
 interest rates on these notes to a floating interest rate. For
 further discussion regarding the Company’s use of derivative
 instruments to manage interest rate and foreign currency risk, see
 the Derivative Financial Instruments section of Note 2,
 “Financial Instruments.”

[0001193125-15-153166:notes:45]
The effective interest rates for the Notes include
 the interest on the Notes, amortization of the discount and, if
 applicable, adjustments related to hedging. The Company recognized
 $161 million and $289 million of interest expense on its long-term
 debt for the three- and six-month periods ended March 28,
 2015, respectively. The Company recognized $84 million and $168
 million of interest expense on its long-term debt for the three-
 and six-month periods ended March 29, 2014, respectively.

[0001193125-15-153166:notes:46]
Future principal payments for the Company’s
 Notes as of March 28, 2015 are as follows (in millions):

[0001193125-15-153166:notes:47]
| 2015 |  | $ | 0 |  |
| 2016 |  |  | 2,500 |  |
| 2017 |  |  | 2,500 |  |
| 2018 |  |  | 6,000 |  |
| 2019 |  |  | 3,000 |  |
| Thereafter |  |  | 25,875 |  |
| Total future principal payments |  | $ | 39,875 |  |

[0001193125-15-153166:notes:48]
As of March 28, 2015 and September 27,
 2014, the fair value of the Company’s Notes, based on Level 2
 inputs, was $40.2 billion and $28.5 billion, respectively.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001193125-15-153166:notes:49]
[same as prior period, unchanged from 0001193125-15-023697:notes:48]

[0001193125-15-153166:notes:50]
[same as prior period, unchanged from 0001193125-15-023697:notes:49]

[0001193125-15-153166:notes:51]
The following table shows the computation of basic
 and diluted earnings per share for the three- and six-month periods
 ended March 28, 2015 and March 29, 2014 (net income in
 millions and shares in thousands):

[0001193125-15-153166:notes:52]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 28, 2015 |  |  | March 29, 2014 |  |  | March 28, 2015 |  |  | March 29, 2014 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 13,569 |  |  | $ | 10,223 |  |  | $ | 31,593 |  |  | $ | 23,295 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding |  |  | 5,793,799 |  |  |  | 6,123,302 |  |  |  | 5,818,441 |  |  |  | 6,197,903 |  |
| Effect of dilutive securities |  |  | 41,059 |  |  |  | 33,397 |  |  |  | 39,889 |  |  |  | 35,527 |  |
| Weighted-average diluted shares |  |  | 5,834,858 |  |  |  | 6,156,699 |  |  |  | 5,858,330 |  |  |  | 6,233,430 |  |
| Basic earnings per share |  | $ | 2.34 |  |  | $ | 1.67 |  |  | $ | 5.43 |  |  | $ | 3.76 |  |
| Diluted earnings per share |  | $ | 2.33 |  |  | $ | 1.66 |  |  | $ | 5.39 |  |  | $ | 3.74 |  |

[0001193125-15-153166:notes:53]
Potentially dilutive securities, whose effect would
 have been antidilutive, were not significant for the three- and
 six-month periods ended March 28, 2015 and the three- and
 six-month periods ended March 29, 2014. The Company excluded
 these securities from the computation of diluted earnings per
 share.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001193125-15-153166:notes:54]
[same as prior period, unchanged from 0001193125-15-023697:notes:53]

[0001193125-15-153166:notes:55]
[same as prior period, unchanged from 0001193125-15-023697:notes:54]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-15-153166:notes:56]
[same as prior period, unchanged from 0001193125-15-023697:notes:55]

[0001193125-15-153166:notes:57]
The Company’s acquired intangible assets
 with definite useful lives primarily consist of patents and
 licenses and are amortized over periods typically from three to
 seven years. The following table summarizes the components of gross
 and net intangible asset balances as of March 28, 2015 and
 September 27, 2014 (in millions):

[0001193125-15-153166:notes:58]
|  |  | March 28, 2015 |  |  | September 27, 2014 |  |
|  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Carrying Amount |  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Carrying Amount |  |
| Definite-lived and amortizable acquired intangible assets |  | $ | 7,672 |  |  | $ | (3,711 | ) |  | $ | 3,961 |  |  | $ | 7,127 |  |  | $ | (3,085 | ) |  | $ | 4,042 |  |
| Indefinite-lived and non-amortizable acquired intangible assets |  |  | 100 |  |  |  | 0 |  |  |  | 100 |  |  |  | 100 |  |  |  | 0 |  |  |  | 100 |  |
| Total acquired intangible assets |  | $ | 7,772 |  |  | $ | (3,711 | ) |  | $ | 4,061 |  |  | $ | 7,227 |  |  | $ | (3,085 | ) |  | $ | 4,142 |  |


## us-gaap:ScheduleOfDerivativeInstrumentsInStatementOfFinancialPositionFairValueTextBlock

[0001193125-15-153166:notes:59]
The following tables show the Company’s
 derivative instruments at gross fair value as of March 28,
 2015 and September 27, 2014 (in millions):

[0001193125-15-153166:notes:60]
|  |  | March 28, 2015 |  |
|  |  | Fair Value of Derivatives Designated as Hedge Instruments |  |  | Fair Value of Derivatives Not Designated as Hedge Instruments |  |  | Total Fair Value |  |
| Derivative assets (1): |  |  |  |  |
| Foreign exchange contracts |  | $ | 3,045 |  |  | $ | 86 |  |  | $ | 3,131 |  |
| Interest rate contracts |  | $ | 329 |  |  | $ | 0 |  |  | $ | 329 |  |
| Derivative liabilities (2): |  |  |  |  |
| Foreign exchange contracts |  | $ | 27 |  |  | $ | 91 |  |  | $ | 118 |  |
| Interest rate contracts |  | $ | 458 |  |  | $ | 0 |  |  | $ | 458 |  |
|  |  | September 27, 2014 |  |
|  |  | Fair Value of Derivatives Designated as Hedge Instruments |  |  | Fair Value of Derivatives Not Designated as Hedge Instruments |  |  | Total Fair Value |  |
| Derivative assets (1): |  |  |  |  |
| Foreign exchange contracts |  | $ | 1,332 |  |  | $ | 222 |  |  | $ | 1,554 |  |
| Interest rate contracts |  | $ | 81 |  |  | $ | 0 |  |  | $ | 81 |  |
| Derivative liabilities (2): |  |  |  |  |
| Foreign exchange contracts |  | $ | 41 |  |  | $ | 40 |  |  | $ | 81 |  |

[0001193125-15-153166:notes:61]
[same as prior period, unchanged from 0001193125-15-023697:notes:60]

[0001193125-15-153166:notes:62]
[same as prior period, unchanged from 0001193125-15-023697:notes:61]


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001193125-15-153166:notes:63]
[same as prior period, unchanged from 0001193125-15-023697:notes:62]

[0001193125-15-153166:notes:64]
|  |  | March 28, 2015 |  |  | September 27, 2014 |  |
| Components |  | $ | 537 |  |  | $ | 471 |  |
| Finished goods |  |  | 1,859 |  |  |  | 1,640 |  |
| Total inventories |  | $ | 2,396 |  |  | $ | 2,111 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-15-153166:notes:65]
[same as prior period, unchanged from 0001193125-15-023697:notes:64]

[0001193125-15-153166:notes:66]
[same as prior period, unchanged from 0001193125-15-023697:notes:65]

[0001193125-15-153166:notes:67]
The Company manages its business primarily on a
 geographic basis. The Company’s reportable operating segments
 consist of the Americas, Europe, Greater China, Japan and Rest of
 Asia Pacific. The Americas segment includes both North and South
 America. The Europe segment includes European countries, as well as
 India, the Middle East and Africa. The Greater China segment
 includes China, Hong Kong and Taiwan. The Rest of Asia Pacific
 segment includes Australia and Asian countries, other than those
 countries included in the Company’s other operating segments.
 Each operating segment provides similar hardware and software
 products and similar services. The accounting policies of the
 various segments are the same as those described in Note 1,
 “Summary of Significant Accounting Policies” of the
 Notes to Consolidated Financial Statements in Part II, Item 8
 of the 2014 Form 10-K.

[0001193125-15-153166:notes:68]
The Company evaluates the performance of its
 operating segments based on net sales and operating income. Net
 sales for geographic segments are generally based on the location
 of customers and sales through the Company’s retail stores
 located in those geographic locations. Operating income for each
 segment includes net sales to third parties, related cost of sales
 and operating expenses directly attributable to the segment.
 Advertising expenses are generally included in the geographic
 segment in which the expenditures are incurred. Operating income
 for each segment excludes other income and expense and certain
 expenses managed outside the operating segments. Costs excluded
 from segment operating income include various corporate expenses
 such as R&D, corporate marketing expenses, certain share-based
 compensation expenses, income taxes, various nonrecurring charges
 and other separately managed general and administrative costs. The
 Company does not include intercompany transfers between segments
 for management reporting purposes.

[0001193125-15-153166:notes:69]
The following table shows information by operating
 segment for the three- and six-month periods ended March 28,
 2015 and March 29, 2014 (in millions):

[0001193125-15-153166:notes:70]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 28, 2015 |  |  | March 29, 2014 |  |  | March 28, 2015 |  |  | March 29, 2014 |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 21,316 |  |  | $ | 17,982 |  |  | $ | 51,882 |  |  | $ | 42,771 |  |
| Operating income |  | $ | 7,186 |  |  | $ | 6,029 |  |  | $ | 17,887 |  |  | $ | 14,098 |  |
| Europe: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 12,204 |  |  | $ | 10,941 |  |  | $ | 29,418 |  |  | $ | 25,276 |  |
| Operating income |  | $ | 4,112 |  |  | $ | 3,605 |  |  | $ | 9,994 |  |  | $ | 8,228 |  |
| Greater China: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 16,823 |  |  | $ | 9,835 |  |  | $ | 32,967 |  |  | $ | 19,331 |  |
| Operating income |  | $ | 6,714 |  |  | $ | 3,541 |  |  | $ | 13,080 |  |  | $ | 6,788 |  |
| Japan: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 3,457 |  |  | $ | 4,047 |  |  | $ | 8,905 |  |  | $ | 9,092 |  |
| Operating income |  | $ | 1,699 |  |  | $ | 1,832 |  |  | $ | 4,187 |  |  | $ | 4,162 |  |
| Rest of Asia Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 4,210 |  |  | $ | 2,841 |  |  | $ | 9,437 |  |  | $ | 6,770 |  |
| Operating income |  | $ | 1,600 |  |  | $ | 904 |  |  | $ | 3,449 |  |  | $ | 2,272 |  |

[0001193125-15-153166:notes:71]
A reconciliation of the Company’s segment
 operating income to the Condensed Consolidated Statements of
 Operations for the three- and six-month periods ended
 March 28, 2015 and March 29, 2014 is as follows (in
 millions):

[0001193125-15-153166:notes:72]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 28, 2015 |  |  | March 29, 2014 |  |  | March 28, 2015 |  |  | March 29, 2014 |  |
| Segment operating income |  | $ | 21,311 |  |  | $ | 15,911 |  |  | $ | 48,597 |  |  | $ | 35,548 |  |
| Research and development expense |  |  | (1,918 | ) |  |  | (1,422 | ) |  |  | (3,813 | ) |  |  | (2,752 | ) |
| Other corporate expenses, net |  |  | (1,115 | ) |  |  | (896 | ) |  |  | (2,260 | ) |  |  | (1,740 | ) |
| Total operating income |  | $ | 18,278 |  |  | $ | 13,593 |  |  | $ | 42,524 |  |  | $ | 31,056 |  |


## us-gaap:InterestAndOtherIncomeTableTextBlock

[0001193125-15-153166:notes:73]
[same as prior period, unchanged from 0001193125-15-023697:notes:72]

[0001193125-15-153166:notes:74]
The following table shows the detail of other
 income/(expense), net for the three- and six-month periods ended
 March 28, 2015 and March 29, 2014 (in millions):

[0001193125-15-153166:notes:75]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 28, 2015 |  |  | March 29, 2014 |  |  | March 28, 2015 |  |  | March 29, 2014 |  |
| Interest and dividend income |  | $ | 675 |  |  | $ | 410 |  |  | $ | 1,329 |  |  | $ | 837 |  |
| Interest expense |  |  | (163 | ) |  |  | (85 | ) |  |  | (294 | ) |  |  | (169 | ) |
| Other expense, net |  |  | (226 | ) |  |  | (100 | ) |  |  | (579 | ) |  |  | (197 | ) |
| Total other income/(expense), net |  | $ | 286 |  |  | $ | 225 |  |  | $ | 456 |  |  | $ | 471 |  |


## us-gaap:OtherNoncurrentLiabilitiesTableTextBlock

[0001193125-15-153166:notes:76]
[same as prior period, unchanged from 0001193125-15-023697:notes:75]

[0001193125-15-153166:notes:77]
|  |  | March 28, 2015 |  |  | September 27, 2014 |  |
| Deferred tax liabilities |  | $ | 23,825 |  |  | $ | 20,259 |  |
| Other non-current liabilities |  |  | 5,991 |  |  |  | 4,567 |  |
| Total other non-current liabilities |  | $ | 29,816 |  |  | $ | 24,826 |  |


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0001193125-15-153166:notes:78]
The following table shows a summary of the
 share-based compensation expense included in the Condensed
 Consolidated Statements of Operations for the three- and six-month
 periods ended March 28, 2015 and March 29, 2014 (in
 millions):

[0001193125-15-153166:notes:79]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 28, 2015 |  |  | March 29, 2014 |  |  | March 28, 2015 |  |  | March 29, 2014 |  |
| Cost of sales |  | $ | 142 |  |  | $ | 110 |  |  | $ | 282 |  |  | $ | 219 |  |
| Research and development |  |  | 384 |  |  |  | 300 |  |  |  | 758 |  |  |  | 589 |  |
| Selling, general and administrative |  |  | 401 |  |  |  | 286 |  |  |  | 775 |  |  |  | 569 |  |
| Total share-based compensation expense |  | $ | 927 |  |  | $ | 696 |  |  | $ | 1,815 |  |  | $ | 1,377 |  |


## us-gaap:DerivativesPolicyTextBlock

[0001193125-15-153166:notes:80]
[same as prior period, unchanged from 0001193125-15-023697:notes:79]

[0001193125-15-153166:notes:81]
[same as prior period, unchanged from 0001193125-15-023697:notes:80]

[0001193125-15-153166:notes:82]
[same as prior period, unchanged from 0001193125-15-023697:notes:81]

[0001193125-15-153166:notes:83]
[same as prior period, unchanged from 0001193125-15-023697:notes:82]

[0001193125-15-153166:notes:84]
[same as prior period, unchanged from 0001193125-15-023697:notes:83]

[0001193125-15-153166:notes:85]
The Company may enter into interest rate swaps,
 options, or other instruments to manage interest rate risk. These
 instruments may offset a portion of changes in income or expense,
 or changes in fair value of the Company’s long-term debt or
 investments. The Company designates these instruments as either
 cash flow or fair value hedges. The Company’s hedged interest
 rate transactions as of March 28, 2015 are expected to be
 recognized within 12 years.

[0001193125-15-153166:notes:86]
[same as prior period, unchanged from 0001193125-15-023697:notes:85]

[0001193125-15-153166:notes:87]
[same as prior period, unchanged from 0001193125-15-023697:notes:86]

[0001193125-15-153166:notes:88]
The ineffective portions and amounts excluded from
 the effectiveness testing of cash flow hedges are recognized in
 other income/(expense), net. These amounts were not significant
 during the three- and six-month periods ended March 28, 2015
 and March 29, 2014.

[0001193125-15-153166:notes:89]
Derivative instruments designated as cash flow
 hedges must be de-designated as hedges when it is probable the
 forecasted hedged transaction will not occur in the initially
 identified time period or within a subsequent two-month time
 period. Deferred gains and losses in AOCI associated with such
 derivative instruments are reclassified immediately into other
 income/(expense), net. Any subsequent changes in fair value of such
 derivative instruments are reflected in other income/(expense), net
 unless they are re-designated as hedges of other transactions. The
 Company did not recognize any significant net gains or losses
 related to the loss of hedge designation on discontinued cash flow
 hedges during the three- and six-month periods ended March 28,
 2015 and March 29, 2014.

[0001193125-15-153166:notes:90]
[same as prior period, unchanged from 0001193125-15-023697:notes:89]

[0001193125-15-153166:notes:91]
The effective portions of net investment hedges are
 recorded in other comprehensive income (“OCI”) as a
 part of the cumulative translation adjustment. The ineffective
 portions and amounts excluded from the effectiveness testing of net
 investment hedges are recognized in other income/(expense), net.
 These amounts were not significant during the three- and six-month
 periods ended March 28, 2015 and March 29, 2014.

[0001193125-15-153166:notes:92]
[same as prior period, unchanged from 0001193125-15-023697:notes:91]

[0001193125-15-153166:notes:93]
Gains and losses related to changes in fair value
 hedges are recognized in earnings along with a corresponding loss
 or gain related to the change in value of the underlying hedged
 item. The ineffective portions and amounts excluded from the
 effectiveness testing of fair value hedges recognized were not
 significant during the three- and six-month periods ended
 March 28, 2015 and March 29, 2014.

[0001193125-15-153166:notes:94]
[same as prior period, unchanged from 0001193125-15-023697:notes:93]

[0001193125-15-153166:notes:95]
Derivatives that are not designated as hedging
 instruments are adjusted to fair value through earnings in the
 financial statement line item to which the derivative relates. The
 net gains and losses recognized for foreign currency forward and
 option contracts not designated as hedging instruments were not
 significant during the three- and six-month periods ended
 March 28, 2015 and March 29, 2014.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001193125-15-153166:notes:96]
[same as prior period, unchanged from 0001193125-15-023697:notes:95]

[0001193125-15-153166:notes:97]
[same as prior period, unchanged from 0001193125-15-023697:notes:96]

[0001193125-15-153166:notes:98]
The Company may sell certain of its marketable
 securities prior to their stated maturities for strategic reasons
 including, but not limited to, anticipation of credit deterioration
 and duration management. The net realized gains or losses
 recognized by the Company related to such sales were not
 significant during the three- and six-month periods ended
 March 28, 2015 and March 29, 2014. The maturities of the
 Company’s long-term marketable securities generally range
 from one to five years.

[0001193125-15-153166:notes:99]
As of March 28, 2015 and September 27,
 2014, gross unrealized losses related to individual securities that
 had been in a continuous loss position for 12 months or longer were
 not significant.

[0001193125-15-153166:notes:100]
During the three- and six-month periods ended
 March 28, 2015 and March 29, 2014, the Company did not
 recognize any significant impairment charges. As of March 28,
 2015, the Company considers the declines in market value of its
 marketable securities investment portfolio to be temporary in
 nature and does not consider any of its investments
 other-than-temporarily impaired. The Company typically invests in
 highly-rated securities, and its investment policy generally limits
 the amount of credit exposure to any one issuer. The policy
 generally requires investments to be investment grade, with the
 primary objective of minimizing the potential risk of principal
 loss. Fair values were determined for each individual security in
 the investment portfolio. When evaluating an investment for
 other-than-temporary impairment the Company reviews factors such as
 the length of time and extent to which fair value has been below
 its cost basis, the financial condition of the issuer and any
 changes thereto, changes in market interest rates and the
 Company’s intent to sell, or whether it is more likely than
 not it will be required to sell the investment before recovery of
 the investment’s cost basis.

[0001193125-15-153166:notes:101]
The Company records all derivatives in the
 Condensed Consolidated Balance Sheets at fair value. The
 Company’s accounting treatment for these derivative
 instruments is based on its hedge designation. The following tables
 show the Company’s derivative instruments at gross fair value
 as of March 28, 2015 and September 27, 2014 (in
 millions):

[0001193125-15-153166:notes:102]
The following tables show the pre-tax gains and
 losses of the Company’s derivative instruments designated as
 cash flow, net investment and fair value hedges on OCI and the
 Condensed Consolidated Statements of Operations for the three- and
 six-month periods ended March 28, 2015 and March 29, 2014
 (in millions):

[0001193125-15-153166:notes:103]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 28, 2015 |  |  | March 29, 2014 |  |  | March 28, 2015 |  |  | March 29, 2014 |  |
| Gains/(Losses) recognized in OCI – effective portion: |  |  |  |  |
| Cash flow hedges: |  |  |  |  |
| Foreign exchange contracts |  | $ | 1,591 |  |  | $ | (121 | ) |  | $ | 4,176 |  |  | $ | 143 |  |
| Interest rate contracts |  |  | (429 | ) |  |  | (27 | ) |  |  | (517 | ) |  |  | (6 | ) |
| Total |  | $ | 1,162 |  |  | $ | (148 | ) |  | $ | 3,659 |  |  | $ | 137 |  |
| Net investment hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | (6 | ) |  | $ | (19 | ) |  | $ | 112 |  |  | $ | 5 |  |
| Gains/(Losses) reclassified from AOCI into net income – effective portion: |  |  |  |  |
| Cash flow hedges: |  |  |  |  |
| Foreign exchange contracts |  | $ | 1,166 |  |  | $ | 22 |  |  | $ | 1,928 |  |  | $ | (52 | ) |
| Interest rate contracts |  |  | (353 | ) |  |  | (4 | ) |  |  | (452 | ) |  |  | (8 | ) |
| Total |  | $ | 813 |  |  | $ | 18 |  |  | $ | 1,476 |  |  | $ | (60 | ) |
| Gains/(Losses) on derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fair value hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate contracts |  | $ | 122 |  |  | $ | 0 |  |  | $ | 239 |  |  | $ | 0 |  |
| Gains/(Losses) related to hedged items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fair value hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate contracts |  | $ | (122 | ) |  | $ | 0 |  |  | $ | (239 | ) |  | $ | 0 |  |

[0001193125-15-153166:notes:104]
The following table shows the notional amounts of
 the Company’s outstanding derivative instruments and credit
 risk amounts associated with outstanding or unsettled derivative
 instruments as of March 28, 2015 and September 27, 2014
 (in millions):

[0001193125-15-153166:notes:105]
|  |  | March 28, 2015 |  |  | September 27, 2014 |  |
|  |  | Notional Amount |  |  | Credit Risk Amounts |  |  | Notional Amount |  |  | Credit Risk Amounts |  |
| Instruments designated as accounting hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 37,855 |  |  | $ | 3,045 |  |  | $ | 42,945 |  |  | $ | 1,333 |  |
| Interest rate contracts |  | $ | 18,013 |  |  | $ | 329 |  |  | $ | 12,000 |  |  | $ | 89 |  |
| Instruments not designated as accounting hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 27,486 |  |  | $ | 86 |  |  | $ | 38,510 |  |  | $ | 222 |  |

[0001193125-15-153166:notes:106]
[same as prior period, unchanged from 0001193125-15-023697:notes:106]

[0001193125-15-153166:notes:107]
The Company generally enters into master netting
 arrangements, which are designed to reduce credit risk by
 permitting net settlement of transactions with the same
 counterparty. To further limit credit risk, the Company generally
 enters into collateral security arrangements that provide for
 collateral to be received or posted when the net fair value of
 certain financial instruments fluctuates from contractually
 established thresholds. The Company presents its derivative assets
 and derivative liabilities at their gross fair values in its
 Condensed Consolidated Balance Sheets. As of March 28, 2015
 and September 27, 2014, the Company received $3.7 billion and
 $2.1 billion, respectively, of cash collateral related to the
 derivative instruments under its collateral security arrangements,
 which were recorded as other current liabilities within accrued
 expenses in the Condensed Consolidated Balance Sheets. The
 Company did not have any derivative instruments with credit-risk
 related contingent features that would require it to post
 additional collateral as of March 28, 2015 and
 September 27, 2014.

[0001193125-15-153166:notes:108]
Under master netting arrangements with the
 respective counterparties to the Company’s derivative
 contracts, the Company is allowed to net settle transactions
 with a single net amount payable by one party to the other. As of
 March 28, 2015 and September 27, 2014, the potential
 effects of these rights of set-off associated with the
 Company’s derivative contracts, including the effects of
 collateral, would be a reduction to both derivative assets and
 derivative liabilities of $3.6 billion and $1.6 billion,
 respectively, resulting in net derivative liabilities
 of $859 million and $549 million, respectively.

[0001193125-15-153166:notes:109]
[same as prior period, unchanged from 0001193125-15-023697:notes:109]

[0001193125-15-153166:notes:110]
[same as prior period, unchanged from 0001193125-15-023697:notes:110]

[0001193125-15-153166:notes:111]
The Company has considerable trade receivables
 outstanding with its third-party cellular network carriers,
 wholesalers, retailers, value-added resellers, small and mid-sized
 businesses and education, enterprise and government customers that
 are not covered by collateral, third-party financing arrangements
 or credit insurance. As of March 28, 2015, the Company had one
 customer that represented 10% or more of total trade receivables,
 which accounted for 11%. As of September 27, 2014, the Company
 had two customers that represented 10% or more of total trade
 receivables, one of which accounted for 16% and the other 13%. The
 Company’s cellular network carriers accounted for 63% and 72%
 of trade receivables as of March 28, 2015 and
 September 27, 2014, respectively.

[0001193125-15-153166:notes:112]
[same as prior period, unchanged from 0001193125-15-023697:notes:112]

[0001193125-15-153166:notes:113]
Additionally, the Company has non-trade receivables
 from certain of its manufacturing vendors resulting from the sale
 of components to these vendors who manufacture sub-assemblies or
 assemble final products for the Company. Vendor non-trade
 receivables from three of the Company’s vendors accounted for
 48%, 18% and 16% of total vendor non-trade receivables as of
 March 28, 2015 and three of the Company’s vendors
 accounted for 51%, 16% and 14% of total vendor non-trade
 receivables as of September 27, 2014.


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001193125-15-153166:notes:114]
[same as prior period, unchanged from 0001193125-15-023697:notes:114]

[0001193125-15-153166:notes:115]
|  |  | March 28, 2015 |  |  | September 27, 2014 |  |
| Accrued warranty and related costs |  | $ | 5,143 |  |  | $ | 4,159 |  |
| Accrued taxes |  |  | 2,017 |  |  |  | 1,209 |  |
| Accrued marketing and selling expenses |  |  | 1,384 |  |  |  | 2,321 |  |
| Accrued compensation and employee benefits |  |  | 1,254 |  |  |  | 1,209 |  |
| Deferred margin on component sales |  |  | 1,130 |  |  |  | 1,057 |  |
| Other current liabilities |  |  | 11,899 |  |  |  | 8,498 |  |
| Total accrued expenses |  | $ | 22,827 |  |  | $ | 18,453 |  |


## us-gaap:ScheduleOfNonvestedRestrictedStockUnitsActivityTableTextBlock

[0001193125-15-153166:notes:116]
A summary of the Company’s RSU activity and related
 information for the six months ended March 28, 2015 is as
 follows:

[0001193125-15-153166:notes:117]
|  |  | Number of RSUs (in thousands) |  |  | Weighted-Average Grant Date Fair Value |  |  | Aggregate Intrinsic Value (in millions) |  |
| Balance at September 27, 2014 |  |  | 103,822 |  |  | $ | 70.98 |  |  |  |  |  |
| RSUs granted |  |  | 38,445 |  |  | $ | 102.36 |  |  |  |  |  |
| RSUs vested |  |  | (19,423 | ) |  | $ | 65.24 |  |  |  |  |  |
| RSUs cancelled |  |  | (2,980 | ) |  | $ | 75.15 |  |  |  |  |  |
| Balance at March 28, 2015 |  |  | 119,864 |  |  | $ | 81.87 |  |  | $ | 14,773 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-15-153166:notes:118]
The following table shows the changes in AOCI by
 component for the six months ended March 28, 2015 (in
 millions):

[0001193125-15-153166:notes:119]
|  |  | Cumulative Foreign Currency Translation |  |  | Unrealized Gains/Losses on Derivative Instruments |  |  | Unrealized Gains/Losses on Marketable Securities |  |  | Total |  |
| Balance at September 27, 2014 |  | $ | (242 | ) |  | $ | 1,364 |  |  | $ | (40 | ) |  | $ | 1,082 |  |
| Other comprehensive income/(loss) before reclassifications |  |  | (365 | ) |  |  | 3,548 |  |  |  | 200 |  |  |  | 3,383 |  |
| Amounts reclassified from AOCI |  |  | 0 |  |  |  | (1,477 | ) |  |  | 34 |  |  |  | (1,443 | ) |
| Tax effect |  |  | 119 |  |  |  | (356 | ) |  |  | (75 | ) |  |  | (312 | ) |
| Other comprehensive income/(loss) |  |  | (246 | ) |  |  | 1,715 |  |  |  | 159 |  |  |  | 1,628 |  |
| Balance at March 28, 2015 |  | $ | (488 | ) |  | $ | 3,079 |  |  | $ | 119 |  |  | $ | 2,710 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-15-153166:notes:120]
[same as prior period, unchanged from 0001193125-15-023697:notes:120]

[0001193125-15-153166:notes:121]
[same as prior period, unchanged from 0001193125-15-023697:notes:121]

[0001193125-15-153166:notes:122]
The Company declared and paid cash dividends per
 share during the periods presented as follows:

[0001193125-15-153166:notes:123]
|  |  | Dividends Per Share |  |  | Amount (in millions) |  |
| 2015: |  |  |  |  |  |  |  |  |
| Second quarter |  | $ | 0.47 |  |  | $ | 2,734 |  |
| First quarter |  |  | 0.47 |  |  |  | 2,750 |  |
| Total cash dividends declared and paid |  | $ | 0.94 |  |  | $ | 5,484 |  |
| 2014: |  |  |  |  |  |  |  |  |
| Fourth quarter |  | $ | 0.47 |  |  | $ | 2,807 |  |
| Third quarter |  |  | 0.47 |  |  |  | 2,830 |  |
| Second quarter |  |  | 0.44 |  |  |  | 2,655 |  |
| First quarter |  |  | 0.44 |  |  |  | 2,739 |  |
| Total cash dividends declared and paid |  | $ | 1.82 |  |  | $ | 11,031 |  |

[0001193125-15-153166:notes:124]
Future dividends are subject to declaration by the Board of
 Directors.

[0001193125-15-153166:notes:125]
[same as prior period, unchanged from 0001193125-15-023697:notes:125]

[0001193125-15-153166:notes:126]
In 2014, the Company’s Board of Directors
 increased the share repurchase authorization to $90 billion of the
 Company’s common stock, of which $80.0 billion had been
 utilized as of March 28, 2015. The Company’s share
 repurchase program does not obligate it to acquire any specific
 number of shares. Under the program, shares may be repurchased in
 privately negotiated and/or open market transactions, including
 under plans complying with Rule 10b5-1 under the Securities
 Exchange Act of 1934, as amended (the “Exchange
 Act”).

[0001193125-15-153166:notes:127]
[same as prior period, unchanged from 0001193125-15-023697:notes:127]

[0001193125-15-153166:notes:128]
The following table shows the Company’s ASR
 activity and related information during the six months ended
 March 28, 2015 and the year ended September 27, 2014:

[0001193125-15-153166:notes:129]
|  |  | Purchase Period End Date |  |  | Number of Shares(in thousands) |  |  | Average Repurchase Price Per Share |  |  | ASR Amount(in millions) |  |
| August 2014 ASR |  |  | February 2015 |  |  |  | 81,525 (1) |  |  | $ | 110.40 |  |  | $ | 9,000 |  |
| January 2014 ASR |  |  | December 2014 |  |  |  | 134,247 |  |  | $ | 89.39 |  |  | $ | 12,000 |  |
| April 2013 ASR |  |  | March 2014 |  |  |  | 172,548 |  |  | $ | 69.55 |  |  | $ | 12,000 |  |

[0001193125-15-153166:notes:130]
|  | (1) | Includes 59.9 million shares delivered and retired at the beginning of the purchase period, which began in the fourth quarter of 2014, 8.3 million net shares delivered and retired in the first quarter of 2015 and 13.3 million shares delivered and retired at the end of the purchase period, which concluded in the second quarter of 2015. |  |

[0001193125-15-153166:notes:131]
[same as prior period, unchanged from 0001193125-15-023697:notes:131]

[0001193125-15-153166:notes:132]
|  |  | Number of Shares(in thousands) |  |  | Average Repurchase Price Per Share |  |  | Amount(in millions) |  |
| 2015: |  |  |  |  |  |  |  |  |  |  |  |  |
| Second quarter |  |  | 56,400 |  |  | $ | 124.11 |  |  | $ | 7,000 |  |
| First quarter |  |  | 45,704 |  |  | $ | 109.40 |  |  |  | 5,000 |  |
| Total open market common stock repurchases |  |  | 102,104 |  |  |  |  |  |  | $ | 12,000 |  |
| 2014: |  |  |  |  |  |  |  |  |  |  |  |  |
| Fourth quarter |  |  | 81,255 |  |  | $ | 98.46 |  |  | $ | 8,000 |  |
| Third quarter |  |  | 58,661 |  |  | $ | 85.23 |  |  |  | 5,000 |  |
| Second quarter |  |  | 79,749 |  |  | $ | 75.24 |  |  |  | 6,000 |  |
| First quarter |  |  | 66,847 |  |  | $ | 74.79 |  |  |  | 5,000 |  |
| Total open market common stock repurchases |  |  | 286,512 |  |  |  |  |  |  | $ | 24,000 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-15-153166:notes:133]
[same as prior period, unchanged from 0001193125-15-023697:notes:133]

[0001193125-15-153166:notes:134]
As of March 28, 2015, the Company recorded
 gross unrecognized tax benefits of $4.6 billion, of which $1.6
 billion, if recognized, would affect the Company’s effective
 tax rate. As of September 27, 2014, the total amount of gross
 unrecognized tax benefits was $4.0 billion, of which $1.4 billion,
 if recognized, would have affected the Company’s effective
 tax rate. The Company’s total gross unrecognized tax benefits
 are classified as other non-current liabilities in the Condensed
 Consolidated Balance Sheets. The Company had $844 million and $630
 million of gross interest and penalties accrued as of
 March 28, 2015 and September 27, 2014, respectively,
 which are classified as other non-current liabilities in the
 Condensed Consolidated Balance Sheets.

[0001193125-15-153166:notes:135]
[same as prior period, unchanged from 0001193125-15-023697:notes:135]

[0001193125-15-153166:notes:136]
On June 11, 2014, the European Commission issued an
 opening decision initiating a formal investigation against Ireland
 for alleged state aid to the Company. The opening decision concerns
 the allocation of profits for taxation purposes of the Irish
 branches of two subsidiaries of the Company. The Company believes
 the European Commission’s assertions are without merit. If
 the European Commission were to conclude against Ireland, the
 European Commission could require Ireland to recover from the
 Company past taxes covering a period of up to 10 years reflective
 of the disallowed state aid. While such amount could be material,
 as of March 28, 2015 the Company is unable to estimate the
 impact.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001193125-15-153166:notes:137]
[same as prior period, unchanged from 0001193125-15-023697:notes:136]

[0001193125-15-153166:notes:138]
The following tables show the Company’s
 condensed consolidated financial statement details as of
 March 28, 2015 and September 27, 2014 (in millions):

[0001193125-15-153166:notes:139]
[same as prior period, unchanged from 0001193125-15-023697:notes:138]

[0001193125-15-153166:notes:140]
|  |  | March 28, 2015 |  |  | September 27, 2014 |  |
| Land and buildings |  | $ | 5,627 |  |  | $ | 4,863 |  |
| Machinery, equipment and internal-use software |  |  | 32,107 |  |  |  | 29,639 |  |
| Leasehold improvements |  |  | 4,726 |  |  |  | 4,513 |  |
| Gross property, plant and equipment |  |  | 42,460 |  |  |  | 39,015 |  |
| Accumulated depreciation and amortization |  |  | (22,309 | ) |  |  | (18,391 | ) |
| Total property, plant and equipment, net |  | $ | 20,151 |  |  | $ | 20,624 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-15-153166:notes:141]
[same as prior period, unchanged from 0001193125-15-023697:notes:140]

[0001193125-15-153166:notes:142]
[same as prior period, unchanged from 0001193125-15-023697:notes:141]

[0001193125-15-153166:notes:143]
The following table shows the pre-tax amounts
 reclassified from AOCI into the Condensed Consolidated Statements
 of Operations, and the associated financial statement line item,
 for the three- and six-month periods ended March 28, 2015 and
 March 29, 2014 (in millions):

[0001193125-15-153166:notes:144]
|  |  |  |  | Three Months Ended |  |  | Six Months Ended |  |
| Comprehensive Income Components |  | Financial Statement Line Item |  | March 28, 2015 |  |  | March 29, 2014 |  |  | March 28, 2015 |  |  | March 29, 2014 |  |
| Unrealized (gains)/losses on derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Revenue |  | $ | (558 | ) |  | $ | 119 |  |  | $ | (1,007 | ) |  | $ | 303 |  |
|  |  | Cost of sales |  |  | (608 | ) |  |  | (141 | ) |  |  | (921 | ) |  |  | (251 | ) |
|  |  | Other income/(expense), net |  |  | (1 | ) |  |  | 4 |  |  |  | (1 | ) |  |  | 14 |  |
| Interest rate contracts |  | Other income/(expense), net |  |  | 353 |  |  |  | 4 |  |  |  | 452 |  |  |  | 8 |  |
|  |  |  |  |  | (814 | ) |  |  | (14 | ) |  |  | (1,477 | ) |  |  | 74 |  |
| Unrealized (gains)/losses on marketable securities |  | Other income/(expense), net |  |  | 56 |  |  |  | (60 | ) |  |  | 34 |  |  |  | (77 | ) |
| Total amounts reclassified from AOCI |  | $ | (758 | ) |  | $ | (74 | ) |  | $ | (1,443 | ) |  | $ | (3 | ) |


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001193125-15-153166:notes:145]
[same as prior period, unchanged from 0001193125-15-023697:notes:144]

[0001193125-15-153166:notes:146]
[same as prior period, unchanged from 0001193125-15-023697:notes:145]

[0001193125-15-153166:notes:147]
The Company had 436.6 million shares reserved
 for future issuance under its stock plans as of March 28,
 2015. RSUs granted generally vest over four years, based on
 continued employment, and are settled upon vesting in shares of the
 Company’s common stock on a one-for-one basis. Each share
 issued with respect to RSUs granted under the Company’s stock
 plans reduces the number of shares available for grant under the
 plan by two shares. RSUs cancelled and shares withheld to satisfy
 tax withholding obligations increase the number of shares available
 for grant under the plans utilizing a factor of two times the
 number of RSUs cancelled or shares withheld. Stock options count
 against the number of shares available for grant on a one-for-one
 basis.

[0001193125-15-153166:notes:148]
[same as prior period, unchanged from 0001193125-15-023697:notes:147]

[0001193125-15-153166:notes:149]
During the three months ended March 28, 2015,
 Section 16 officers Timothy D. Cook, Angela Ahrendts, Luca
 Maestri and Daniel Riccio had equity trading plans in place in
 accordance with Rule 10b5-1(c)(1) under the Exchange Act. An equity
 trading plan is a written document that pre-establishes the
 amounts, prices and dates (or formula for determining the amounts,
 prices and dates) of future purchases or sales of the
 Company’s stock, including shares acquired pursuant to the
 Company’s employee and director equity plans.

[0001193125-15-153166:notes:150]
[same as prior period, unchanged from 0001193125-15-023697:notes:149]

[0001193125-15-153166:notes:151]
RSUs that vested during the three- and six-month
 periods ended March 28, 2015 had fair values of $317 million
 and $2.0 billion, respectively, as of the vesting date. RSUs that
 vested during the three- and six-month periods ended March 29,
 2014 had fair values of $198 million and $1.3 billion,
 respectively, as of the vesting date.

[0001193125-15-153166:notes:152]
[same as prior period, unchanged from 0001193125-15-023697:notes:151]

[0001193125-15-153166:notes:153]
The Company had 2.3 million stock options
 outstanding as of March 28, 2015, with a weighted-average
 exercise price per share of $18.15 and weighted-average remaining
 contractual term of 2.6 years, substantially all of which are
 exercisable. The aggregate intrinsic value of the stock options
 outstanding as of March 28, 2015 was $239 million, which
 represents the value of the Company’s closing stock price on
 the last trading day of the period in excess of the
 weighted-average exercise price multiplied by the number of options
 outstanding.

[0001193125-15-153166:notes:154]
The total intrinsic value of options at the time of
 exercise was $119 million and $367 million for the three- and
 six-month periods ended March 28, 2015, respectively, and $148
 million and $707 million for the three- and six-month periods ended
 March 29, 2014, respectively.

[0001193125-15-153166:notes:155]
[same as prior period, unchanged from 0001193125-15-023697:notes:154]

[0001193125-15-153166:notes:156]
The income tax benefit related to share-based
 compensation expense was $311 million and $662 million for the
 three- and six-month periods ended March 28, 2015,
 respectively, and was $230 million and $495 million for the three-
 and six-month periods ended March 29, 2014, respectively. As
 of March 28, 2015, the total unrecognized compensation cost
 related to outstanding stock options and RSUs expected to vest was
 $8.1 billion, which the Company expects to recognize over a
 weighted-average period of 2.9 years.
