# AAPL 8-K — 0001193125-15-149590 filed 2015-04-27

## item codes, every 8-K on or before 2015-04-28

- 2015-04-27 0001193125-15-149607 — 7.01, 9.01
- 2015-04-27 0001193125-15-149590 — 2.02, 9.01
- 2015-03-13 0001104659-15-019336 — 5.07, 9.01
- 2015-02-09 0001193125-15-039270 — 8.01, 9.01
- 2015-01-28 0001193125-15-023732 — 8.01, 9.01
- 2015-01-27 0001193125-15-021857 — 2.02, 9.01
- 2014-11-10 0001193125-14-406296 — 8.01, 9.01
- 2014-10-20 0001193125-14-376361 — 2.02, 9.01
- 2014-07-23 0001193125-14-277193 — 8.01, 9.01
- 2014-07-22 0001193125-14-275598 — 2.02, 9.01
- 2014-07-17 0001193125-14-271698 — 5.02
- 2014-06-06 0001193125-14-228798 — 5.03, 9.01
- 2014-05-30 0001181431-14-021923 — 5.02
- 2014-05-06 0001193125-14-184969 — 8.01, 9.01
- 2014-04-23 0001193125-14-154883 — 7.01, 9.01
- 2014-04-23 0001193125-14-154871 — 2.02, 9.01
- 2014-03-05 0001193125-14-084697 — 5.02, 5.03, 5.07, 9.01
- 2014-01-27 0001193125-14-022238 — 2.02, 9.01
- 2013-10-28 0001193125-13-413498 — 2.02, 9.01
- 2013-09-23 0001181431-13-050140 — 8.01
- 2013-07-30 0001181431-13-041847 — 5.02
- 2013-07-23 0001193125-13-298914 — 2.02, 9.01
- 2013-06-21 0001193125-13-267629 — 5.02
- 2013-05-03 0001193125-13-199324 — 8.01, 9.01
- 2013-04-24 0001193125-13-170623 — 8.01, 9.01
- 2013-04-23 0001193125-13-167469 — 7.01, 9.01
- 2013-04-23 0001193125-13-167458 — 2.02, 9.01
- 2013-03-01 0001193125-13-085842 — 5.07
- 2013-01-23 0001193125-13-020783 — 2.02, 9.01
- 2012-10-25 0001193125-12-435506 — 2.02, 9.01
- 2012-07-24 0001193125-12-312355 — 2.02, 9.01
- 2012-06-28 0001181431-12-038301 — 5.02
- 2012-05-24 0001181431-12-032458 — 5.02
- 2012-04-24 0001193125-12-178928 — 2.02, 9.01
- 2012-02-27 0001193125-12-081892 — 5.07
- 2012-01-24 0001193125-12-021833 — 2.02, 9.01
- 2011-11-16 0001181431-11-056354 — 5.02
- 2011-10-18 0001193125-11-273826 — 2.02, 9.01
- 2011-10-06 0001181431-11-051976 — 8.01
- 2011-08-26 0001181431-11-047179 — 5.02
- 2011-07-19 0001193125-11-191368 — 2.02, 9.01
- 2011-06-15 0001181431-11-036782 — 5.02
- 2011-04-20 0001193125-11-103732 — 2.02, 9.01
- 2011-02-24 0001193125-11-045411 — 5.07
- 2011-01-18 0001193125-11-009392 — 2.02, 9.01
- 2011-01-18 0001181431-11-003847 — 5.02
- 2010-11-17 0001181431-10-056327 — 5.02, 5.03, 9.01
- 2010-10-18 0001193125-10-230992 — 2.02, 9.01
- 2010-07-20 0001193125-10-161807 — 2.02, 9.01
- 2010-04-20 0001193125-10-087786 — 2.02, 9.01
- 2010-03-12 0001181431-10-016054 — 5.02
- 2010-03-01 0001193125-10-044765 — 5.02, 5.07, 9.01
- 2010-01-25 0001193125-10-012096 — 2.02, 9.01
- 2009-10-19 0001193125-09-209633 — 2.02, 9.01
- 2009-08-04 0001181431-09-037492 — 5.02
- 2009-07-21 0001193125-09-152290 — 2.02, 9.01
- 2009-06-02 0001181431-09-028400 — 5.03
- 2009-04-22 0001193125-09-084599 — 2.02, 9.01
- 2009-02-27 0001181431-09-012161 — 4.01
- 2009-01-21 0001193125-09-009009 — 2.02, 9.01
- 2009-01-16 0001181431-09-003017 — 5.02
- 2008-10-21 0001193125-08-213642 — 2.02, 9.01
- 2008-08-26 0001181431-08-050059 — 5.03
- 2008-07-21 0001193125-08-154381 — 2.02, 9.01
- 2008-06-09 0001181431-08-037620 — 8.01
- 2008-04-23 0001193125-08-088001 — 2.02, 9.01
- 2008-01-22 0001193125-08-009715 — 2.02, 9.01
- 2008-01-15 0001181431-08-003342 — 2.02, 8.01
- 2008-01-08 0001181431-08-002372 — 5.02
- 2007-10-22 0001104659-07-076142 — 2.02, 9.01
- 2007-07-25 0001104659-07-056111 — 2.02, 9.01
- 2007-05-16 0001104659-07-040672 — 5.02, 9.01
- 2007-04-25 0001104659-07-031354 — 2.02, 9.01
- 2007-04-24 0001104659-07-030938 — 8.01, 9.01
- 2007-02-21 0001104659-07-012760 — 5.03, 9.01
- 2007-01-17 0001104659-07-002905 — 2.02, 9.01
- 2007-01-10 0001104659-07-001648 — 5.03, 9.01
- 2006-10-27 0001104659-06-069015 — 8.01
- 2006-10-18 0001104659-06-067275 — 2.02, 9.01
- 2006-10-04 0001104659-06-064935 — 5.02, 8.01, 9.01
- 2006-09-01 0001104659-06-058808 — 1.01, 5.02, 5.03, 9.01
- 2006-08-11 0001104659-06-054118 — 2.02, 3.01, 9.01
- 2006-08-04 0001104659-06-051302 — 2.02, 4.02, 9.01
- 2006-07-19 0001104659-06-047739 — 2.02, 9.01
- 2006-04-21 0001181431-06-024759 — 1.01
- 2006-04-19 0001104659-06-025992 — 2.02, 9.01
- 2006-01-18 0001104659-06-002690 — 2.02, 9.01
- 2006-01-10 0001104659-06-001428 — 2.02
- 2005-12-19 0001181431-05-067468 — 1.01
- 2005-10-14 0001181431-05-056604 — 5.02
- 2005-10-11 0001104659-05-048094 — 2.02, 9.01
- 2005-08-26 0001181431-05-049163 — 1.01
- 2005-08-15 0001181431-05-046871 — 1.01
- 2005-07-13 0001104659-05-032297 — 2.02, 9.01
- 2005-06-06 0001181431-05-033177 — 8.01
- 2005-04-26 0001181431-05-023450 — 1.01
- 2005-04-13 0001104659-05-016307 — 2.02, 9.01
- 2005-03-02 0001181431-05-013840 — 3.03, 5.03
- 2005-02-11 0001104659-05-005507 — 8.01
- 2005-01-12 0001104659-05-001183 — 2.02, 9.01
- 2005-01-11 0001104659-05-001049 — 2.02
- 2004-10-13 0001104659-04-030400 — 2.02, 9.01
- 2004-07-14 0001104659-04-019574 — 12, 7
- 2004-04-14 0001104659-04-010122 — 12, 7
- 2004-01-14 0001104659-04-000896 — 12, 7
- 2003-10-15 0001104659-03-022879 — 12, 7
- 2003-07-16 0001104659-03-014913 — 7, 9
- 2003-04-16 0001047469-03-013617 — 7, 9
- 2003-03-21 0001104659-03-004649 — 5, 7
- 2002-08-13 0000912057-02-031595 — 5, 7
- 2002-08-05 0000912057-02-029692 — 5, 7
- 2000-01-24 0000912057-00-002128 — 5, 7
- 1999-09-07 0000320193-99-000010 — 2
- 1999-07-16 0000320193-99-000007 — 2
- 1998-12-23 0000320193-98-000010 — 1
- 1998-01-08 0000320193-98-000001 — 2
- 1997-09-25 0000320193-97-000019 — 2
- 1997-09-25 0000320193-97-000018 — 2
- 1997-09-05 0000320193-97-000016 — 2
- 1997-07-28 0000320193-97-000012 — 4
- 1997-04-25 0000320193-97-000009 — 5
- 1997-04-10 0000320193-97-000007 — 7
- 1996-12-24 0000320193-96-000027 — 7
- 1996-12-23 0000320193-96-000025 — 4 — amendment of 0000320193-96-000021
- 1996-12-13 0000320193-96-000021 — 4
- 1996-10-28 0000912057-96-023874 — 5, 7
- 1996-06-17 0000320193-96-000014 — 1
- 1996-04-12 0000320193-96-000006 — 1

## late-filing notifications on or before 2015-04-28

- 2006-12-15 0001104659-06-081617 — NT 10-K, for the period ended 2006-09-30
- 2006-08-11 0001104659-06-053743 — NT 10-Q, for the period ended 2006-07-01

## item 2.02 — earnings release, exhibit 99.1

[0001193125-15-149590:8k_2_02:1]
EX-99.1
2
d901296dex991.htm
EX-99.1

[0001193125-15-149590:8k_2_02:2]
EX-99.1

[0001193125-15-149590:8k_2_02:3]
Exhibit 99.1

[0001193125-15-149590:8k_2_02:4]
Apple Reports Record Second Quarter Results

[0001193125-15-149590:8k_2_02:5]
Strong performance of iPhone,
Mac & App Store drives 27% revenue growth & 40% EPS growth, setting new second quarter records

[0001193125-15-149590:8k_2_02:6]
CUPERTINO,
California—April 27, 2015—Apple® today announced financial results for its fiscal 2015 second quarter ended March 28, 2015. The Company posted quarterly revenue of $58 billion
and quarterly net profit of $13.6 billion, or $2.33 per diluted share. These results compare to revenue of $45.6 billion and net profit of $10.2 billion, or $1.66 per diluted share, in the year-ago quarter. Gross margin was 40.8 percent compared to
39.3 percent in the year-ago quarter. International sales accounted for 69 percent of the quarter’s revenue.

[0001193125-15-149590:8k_2_02:7]
The growth was fueled by record
second quarter sales of iPhone® and Mac® and all-time record performance of the App
StoreSM.

[0001193125-15-149590:8k_2_02:8]
“We are thrilled by the continued strength of iPhone, Mac and the App Store,
which drove our best March quarter results ever,” said Tim Cook, Apple’s CEO. “We’re seeing a higher rate of people switching to iPhone than we’ve experienced in previous cycles, and we’re off to an exciting start to
the June quarter with the launch of Apple Watch.”

[0001193125-15-149590:8k_2_02:9]
“The tremendous customer demand for our products and services in the March quarter drove
revenue growth of 27 percent and EPS growth of 40 percent,” said Luca Maestri, Apple’s CFO. “Cash flow from operations was also outstanding at $19.1 billion.”

[0001193125-15-149590:8k_2_02:10]
Apple is providing the following guidance for its fiscal 2015 third quarter:

[0001193125-15-149590:8k_2_02:11]
| • |  | revenue between $46 billion and $48 billion |

[0001193125-15-149590:8k_2_02:12]
| • |  | gross margin between 38.5 percent and 39.5 percent |

[0001193125-15-149590:8k_2_02:13]
| • |  | operating expenses between $5.65 billion and $5.75 billion |

[0001193125-15-149590:8k_2_02:14]
| • |  | other income/(expense) of $350 million |

[0001193125-15-149590:8k_2_02:15]
| • |  | tax rate of 26.3 percent |

[0001193125-15-149590:8k_2_02:16]
Apple will
provide live streaming of its Q2 2015 financial results conference call beginning at 2:00 p.m. PDT on April 27, 2015 at www.apple.com/quicktime/qtv/earningsq215. This webcast will also be available for replay for approximately two weeks
thereafter.

[0001193125-15-149590:8k_2_02:17]
Apple designs Macs, the
best personal computers in the world, along with OS X, iLife, iWork and professional software. Apple leads the digital music revolution with its iPods and iTunes online store. Apple has reinvented the mobile phone with its revolutionary iPhone and
App Store, and is defining the future of mobile media and computing devices with iPad.

[0001193125-15-149590:8k_2_02:18]
Press Contact:

[0001193125-15-149590:8k_2_02:19]
Josh Rosenstock

[0001193125-15-149590:8k_2_02:20]
Apple

[0001193125-15-149590:8k_2_02:21]
jrosenstock@apple.com

[0001193125-15-149590:8k_2_02:22]
(408) 974-2414

[0001193125-15-149590:8k_2_02:23]
Investor Relations Contacts:

[0001193125-15-149590:8k_2_02:24]
Nancy Paxton

[0001193125-15-149590:8k_2_02:25]
Apple

[0001193125-15-149590:8k_2_02:26]
paxton1@apple.com

[0001193125-15-149590:8k_2_02:27]
(408) 974-5420

[0001193125-15-149590:8k_2_02:28]
Joan Hoover

[0001193125-15-149590:8k_2_02:29]
Apple

[0001193125-15-149590:8k_2_02:30]
hoover1@apple.com

[0001193125-15-149590:8k_2_02:31]
(408) 974-4570

[0001193125-15-149590:8k_2_02:32]
NOTE TO EDITORS: For additional
information visit Apple’s PR website (www.apple.com/pr), or call Apple’s Media Helpline at (408) 974-2042.

[0001193125-15-149590:8k_2_02:33]
© 2015 Apple Inc. All
rights reserved. Apple, the Apple logo, Mac, Mac OS, Macintosh, iPhone and App Store are trademarks of Apple. Other company and product names may be trademarks of their respective owners.

[0001193125-15-149590:8k_2_02:34]
Apple Inc.

[0001193125-15-149590:8k_2_02:35]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-15-149590:8k_2_02:36]
(In millions, except number of shares which are reflected in thousands and per share amounts)

[0001193125-15-149590:8k_2_02:37]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 28,2015 |  |  | March 29,2014 |  |  | March 28,2015 |  |  | March 29,2014 |  |
| Net sales |  | $ | 58,010 |  |  | $ | 45,646 |  |  | $ | 132,609 |  |  | $ | 103,240 |  |
| Cost of sales (1) |  |  | 34,354 |  |  |  | 27,699 |  |  |  | 79,212 |  |  |  | 63,447 |  |
| Gross margin |  |  | 23,656 |  |  |  | 17,947 |  |  |  | 53,397 |  |  |  | 39,793 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development (1) |  |  | 1,918 |  |  |  | 1,422 |  |  |  | 3,813 |  |  |  | 2,752 |  |
| Selling, general and administrative (1) |  |  | 3,460 |  |  |  | 2,932 |  |  |  | 7,060 |  |  |  | 5,985 |  |
| Total operating expenses |  |  | 5,378 |  |  |  | 4,354 |  |  |  | 10,873 |  |  |  | 8,737 |  |
| Operating income |  |  | 18,278 |  |  |  | 13,593 |  |  |  | 42,524 |  |  |  | 31,056 |  |
| Other income/(expense), net |  |  | 286 |  |  |  | 225 |  |  |  | 456 |  |  |  | 471 |  |
| Income before provision for income taxes |  |  | 18,564 |  |  |  | 13,818 |  |  |  | 42,980 |  |  |  | 31,527 |  |
| Provision for income taxes |  |  | 4,995 |  |  |  | 3,595 |  |  |  | 11,387 |  |  |  | 8,232 |  |
| Net income |  | $ | 13,569 |  |  | $ | 10,223 |  |  | $ | 31,593 |  |  | $ | 23,295 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.34 |  |  | $ | 1.67 |  |  | $ | 5.43 |  |  | $ | 3.76 |  |
| Diluted |  | $ | 2.33 |  |  | $ | 1.66 |  |  | $ | 5.39 |  |  | $ | 3.74 |  |
| Shares used in computing earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 5,793,799 |  |  |  | 6,123,302 |  |  |  | 5,818,411 |  |  |  | 6,197,903 |  |
| Diluted |  |  | 5,834,858 |  |  |  | 6,156,699 |  |  |  | 5,858,330 |  |  |  | 6,233,430 |  |
| Cash dividends declared per share |  | $ | 0.47 |  |  | $ | 0.44 |  |  | $ | 0.94 |  |  | $ | 0.88 |  |
| (1) Includes share-based compensation expense as follows: |  |
| Cost of sales |  | $ | 142 |  |  | $ | 110 |  |  | $ | 282 |  |  | $ | 219 |  |
| Research and development |  | $ | 384 |  |  | $ | 300 |  |  | $ | 758 |  |  | $ | 589 |  |
| Selling, general and administrative |  | $ | 401 |  |  | $ | 286 |  |  | $ | 775 |  |  | $ | 569 |  |

[0001193125-15-149590:8k_2_02:38]
Apple Inc.

[0001193125-15-149590:8k_2_02:39]
UNAUDITED CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-15-149590:8k_2_02:40]
(In millions, except number of shares which are reflected in thousands and par value)

[0001193125-15-149590:8k_2_02:41]
|  |  | March 28,2015 |  |  | September 27,2014 |  |
| ASSETS: |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 14,489 |  |  | $ | 13,844 |  |
| Short-term marketable securities |  |  | 18,607 |  |  |  | 11,233 |  |
| Accounts receivable, less allowances of $83 and $86, respectively |  |  | 10,905 |  |  |  | 17,460 |  |
| Inventories |  |  | 2,396 |  |  |  | 2,111 |  |
| Deferred tax assets |  |  | 5,141 |  |  |  | 4,318 |  |
| Vendor non-trade receivables |  |  | 7,259 |  |  |  | 9,759 |  |
| Other current assets |  |  | 9,094 |  |  |  | 9,806 |  |
| Total current assets |  |  | 67,891 |  |  |  | 68,531 |  |
| Long-term marketable securities |  |  | 160,443 |  |  |  | 130,162 |  |
| Property, plant and equipment, net |  |  | 20,151 |  |  |  | 20,624 |  |
| Goodwill |  |  | 4,711 |  |  |  | 4,616 |  |
| Acquired intangible assets, net |  |  | 4,061 |  |  |  | 4,142 |  |
| Other assets |  |  | 3,937 |  |  |  | 3,764 |  |
| Total assets |  | $ | 261,194 |  |  | $ | 231,839 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY: |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 23,159 |  |  | $ | 30,196 |  |
| Accrued expenses |  |  | 22,827 |  |  |  | 18,453 |  |
| Deferred revenue |  |  | 8,944 |  |  |  | 8,491 |  |
| Commercial paper |  |  | 3,799 |  |  |  | 6,308 |  |
| Total current liabilities |  |  | 58,729 |  |  |  | 63,448 |  |
| Deferred revenue – non-current |  |  | 3,571 |  |  |  | 3,031 |  |
| Long-term debt |  |  | 40,072 |  |  |  | 28,987 |  |
| Other non-current liabilities |  |  | 29,816 |  |  |  | 24,826 |  |
| Total liabilities |  |  | 132,188 |  |  |  | 120,292 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Shareholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock and additional paid-in capital, $0.00001 par value: 12,600,000 shares authorized; 5,762,278 and 5,866,161 shares issued and outstanding, respectively |  |  | 25,376 |  |  |  | 23,313 |  |
| Retained earnings |  |  | 100,920 |  |  |  | 87,152 |  |
| Accumulated other comprehensive income |  |  | 2,710 |  |  |  | 1,082 |  |
| Total shareholders’ equity |  |  | 129,006 |  |  |  | 111,547 |  |
| Total liabilities and shareholders’ equity |  | $ | 261,194 |  |  | $ | 231,839 |  |

[0001193125-15-149590:8k_2_02:42]
Apple Inc.

[0001193125-15-149590:8k_2_02:43]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-15-149590:8k_2_02:44]
(In millions)

[0001193125-15-149590:8k_2_02:45]
|  |  | Six Months Ended |  |
|  |  | March 28,2015 |  |  | March 29,2014 |  |
| Cash and cash equivalents, beginning of the period |  | $ | 13,844 |  |  | $ | 14,259 |  |
| Operating activities: |  |  |  |  |  |  |  |  |
| Net income |  |  | 31,593 |  |  |  | 23,295 |  |
| Adjustments to reconcile net income to cash generated by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 5,054 |  |  |  | 4,031 |  |
| Share-based compensation expense |  |  | 1,815 |  |  |  | 1,377 |  |
| Deferred income tax expense |  |  | 1,879 |  |  |  | 2,059 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | 6,555 |  |  |  | 3,401 |  |
| Inventories |  |  | (285 | ) |  |  | (65 | ) |
| Vendor non-trade receivables |  |  | 2,500 |  |  |  | 1,419 |  |
| Other current and non-current assets |  |  | 2,448 |  |  |  | 14 |  |
| Accounts payable |  |  | (5,428 | ) |  |  | (2,375 | ) |
| Deferred revenue |  |  | 993 |  |  |  | 1,414 |  |
| Other current and non-current liabilities |  |  | 5,679 |  |  |  | 1,638 |  |
| Cash generated by operating activities |  |  | 52,803 |  |  |  | 36,208 |  |
| Investing activities: |  |  |  |  |  |  |  |  |
| Purchases of marketable securities |  |  | (92,523 | ) |  |  | (90,360 | ) |
| Proceeds from maturities of marketable securities |  |  | 5,871 |  |  |  | 10,869 |  |
| Proceeds from sales of marketable securities |  |  | 48,924 |  |  |  | 80,241 |  |
| Payments made in connection with business acquisitions, net |  |  | (115 | ) |  |  | (559 | ) |
| Payments for acquisition of property, plant and equipment |  |  | (5,586 | ) |  |  | (3,367 | ) |
| Payments for acquisition of intangible assets |  |  | (155 | ) |  |  | (163 | ) |
| Other |  |  | 88 |  |  |  | (23 | ) |
| Cash used in investing activities |  |  | (43,496 | ) |  |  | (3,362 | ) |
| Financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock |  |  | 309 |  |  |  | 341 |  |
| Excess tax benefits from equity awards |  |  | 357 |  |  |  | 363 |  |
| Taxes paid related to net share settlement of equity awards |  |  | (608 | ) |  |  | (430 | ) |
| Dividends and dividend equivalents paid |  |  | (5,544 | ) |  |  | (5,430 | ) |
| Repurchase of common stock |  |  | (12,000 | ) |  |  | (23,000 | ) |
| Proceeds from issuance of long-term debt, net |  |  | 11,332 |  |  |  | 0 |  |
| Repayments of commercial paper, net |  |  | (2,508 | ) |  |  | 0 |  |
| Cash used in financing activities |  |  | (8,662 | ) |  |  | (28,156 | ) |
| Increase in cash and cash equivalents |  |  | 645 |  |  |  | 4,690 |  |
| Cash and cash equivalents, end of the period |  | $ | 14,489 |  |  | $ | 18,949 |  |
| Supplemental cash flow disclosure: |  |  |  |  |  |  |  |  |
| Cash paid for income taxes, net |  | $ | 7,058 |  |  | $ | 5,369 |  |
| Cash paid for interest |  | $ | 220 |  |  | $ | 161 |  |
