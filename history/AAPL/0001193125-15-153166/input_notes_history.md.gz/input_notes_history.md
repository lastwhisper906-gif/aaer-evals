# AAPL note change history — 0001193125-15-023697 → 0001193125-15-153166


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-04-28):
[0001193125-15-153166:note_history:1]
The following table shows changes in the
 Company’s accrued warranties and related costs for the three-
 and six-month periods ended March 28, 2015 and March 29,
 2014 (in millions):
  (was, 2015-01-28, similarity 0.8963):
[0001193125-15-023697:note_history:1]
The following table shows changes in the
 Company’s accrued warranties and related costs for the three
 months ended December 27, 2014 and December 28, 2013 (in
 millions):

- changed (2015-04-28):
[0001193125-15-153166:note_history:2]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 28, 2015 |  |  | March 29, 2014 |  |  | March 28, 2015 |  |  | March 29, 2014 |  |
| Beginning accrued warranty and related costs |  | $ | 5,195 |  |  | $ | 3,980 |  |  | $ | 4,159 |  |  | $ | 2,967 |  |
| Cost of warranty claims |  |  | (1,030 | ) |  |  | (865 | ) |  |  | (2,074 | ) |  |  | (1,929 | ) |
| Accruals for product warranty |  |  | 978 |  |  |  | 1,253 |  |  |  | 3,058 |  |  |  | 3,330 |  |
| Ending accrued warranty and related costs |  | $ | 5,143 |  |  | $ | 4,368 |  |  | $ | 5,143 |  |  | $ | 4,368 |  |
  (was, 2015-01-28, similarity 0.7439):
[0001193125-15-023697:note_history:2]
|  |  | Three Months Ended |  |
|  |  | December 27, 2014 |  |  | December 28, 2013 |  |
| Beginning accrued warranty and related costs |  | $ | 4,159 |  |  | $ | 2,967 |  |
| Cost of warranty claims |  |  | (1,044 | ) |  |  | (1,064 | ) |
| Accruals for product warranty |  |  | 2,080 |  |  |  | 2,077 |  |
| Ending accrued warranty and related costs |  | $ | 5,195 |  |  | $ | 3,980 |  |

- changed (2015-04-28):
[0001193125-15-153166:note_history:3]
The Company generally does not indemnify end-users
 of its operating system and application software against legal
 claims that the software infringes third-party intellectual
 property rights. Other agreements entered into by the Company
 sometimes include indemnification provisions under which the
 Company could be subject to costs and/or damages in the event of an
 infringement claim against the Company or an indemnified
 third-party. However, the Company has not been required to make any
 significant payments resulting from such an infringement claim
 asserted against it or an indemnified third-party. In the opinion
 of management, there was not at least a reasonable possibility the
 Company may have incurred a material loss with respect to
 indemnification of end-users of its operating system or application
 software for infringement of third-party intellectual property
 rights. The Company did not record a liability for infringement
 costs related to indemnification as of March 28, 2015 or
 September 27, 2014.
  (was, 2015-01-28, similarity 0.9935):
[0001193125-15-023697:note_history:3]
The Company generally does not indemnify end-users
 of its operating system and application software against legal
 claims that the software infringes third-party intellectual
 property rights. Other agreements entered into by the Company
 sometimes include indemnification provisions under which the
 Company could be subject to costs and/or damages in the event of an
 infringement claim against the Company or an indemnified
 third-party. However, the Company has not been required to make any
 significant payments resulting from such an infringement claim
 asserted against it or an indemnified third-party. In the opinion
 of management, there was not at least a reasonable possibility the
 Company may have incurred a material loss with respect to
 indemnification of end-users of its operating system or application
 software for infringement of third-party intellectual property
 rights. The Company did not record a liability for infringement
 costs related to indemnification as of December 27, 2014 or
 September 27, 2014.

- changed (2015-04-28):
[0001193125-15-153166:note_history:4]
The Company leases various equipment and
 facilities, including retail space, under noncancelable operating
 lease arrangements. The Company does not currently utilize any
 other off-balance sheet financing arrangements. The major facility
 leases are typically for terms not exceeding 10 years and generally
 contain multi-year renewal options. As of March 28, 2015, the
 Company had a total of 453 retail stores. Leases for retail space
 are for terms ranging from five to 20 years, the majority of which
 are for 10 years, and often contain multi-year renewal options. As
 of March 28, 2015, the Company’s total future minimum
 lease payments under noncancelable operating leases were $5.1
 billion, of which $3.4 billion related to leases for retail
 space.
  (was, 2015-01-28, similarity 0.9822):
[0001193125-15-023697:note_history:4]
The Company leases various equipment and
 facilities, including retail space, under noncancelable operating
 lease arrangements. The Company does not currently utilize any
 other off-balance sheet financing arrangements. The major facility
 leases are typically for terms not exceeding 10 years and generally
 contain multi-year renewal options. As of December 27, 2014,
 the Company had a total of 447 retail stores. Leases for retail
 space are for terms ranging from five to 20 years, the majority of
 which are for 10 years, and often contain multi-year renewal
 options. As of December 27, 2014, the Company’s total
 future minimum lease payments under noncancelable operating leases
 were $4.8 billion, of which $3.5 billion related to leases for
 retail space.

- changed (2015-04-28):
[0001193125-15-153166:note_history:5]
The Company utilizes several outsourcing partners
 to manufacture sub-assemblies for the Company’s products and
 to perform final assembly and testing of finished products. These
 outsourcing partners acquire components and build product based on
 demand information supplied by the Company, which typically covers
 periods up to 150 days. The Company also obtains individual
 components for its products from a wide variety of individual
 suppliers. Consistent with industry practice, the Company acquires
 components through a combination of purchase orders, supplier
 contracts and open orders based on projected demand information.
 Where appropriate, the purchases are applied
 to inventory component prepayments that
 are outstanding with the respective supplier. As of
 March 28, 2015, the Company had outstanding off-balance sheet
 third-party manufacturing commitments and component purchase
 commitments of $19.0 billion.
  (was, 2015-01-28, similarity 0.9928):
[0001193125-15-023697:note_history:5]
The Company utilizes several outsourcing partners
 to manufacture sub-assemblies for the Company’s products and
 to perform final assembly and testing of finished products. These
 outsourcing partners acquire components and build product based on
 demand information supplied by the Company, which typically covers
 periods up to 150 days. The Company also obtains individual
 components for its products from a wide variety of individual
 suppliers. Consistent with industry practice, the Company acquires
 components through a combination of purchase orders, supplier
 contracts and open orders based on projected demand information.
 Where appropriate, the purchases are applied
 to inventory component prepayments that
 are outstanding with the respective supplier. As of
 December 27, 2014, the Company had outstanding off-balance
 sheet third-party manufacturing commitments and component purchase
 commitments of $21.6 billion.

- changed (2015-04-28):
[0001193125-15-153166:note_history:6]
In addition to the commitments mentioned above, the
 Company had other off-balance sheet obligations of $4.1 billion as
 of March 28, 2015, which were comprised of commitments to
 acquire capital assets, including product tooling and manufacturing
 process equipment, and commitments related to advertising, research
 and development (“R&D”), Internet and
 telecommunications services, energy and other obligations.
  (was, 2015-01-28, similarity 0.9839):
[0001193125-15-023697:note_history:6]
In addition to the commitments mentioned above, the
 Company had other off-balance sheet obligations of $3.9 billion as
 of December 27, 2014, which were comprised of commitments to
 acquire capital assets, including product tooling and manufacturing
 process equipment, and commitments related to advertising, research
 and development (“R&D”), Internet and
 telecommunications services, energy and other obligations.

- added (2015-04-28):
[0001193125-15-153166:note_history:7]
Smartflash LLC, et al., v. Apple Inc., et al.

- added (2015-04-28):
[0001193125-15-153166:note_history:8]
On May 29, 2013, Smartflash LLC and Smartflash
 Technologies Limited filed an action against the Company in the
 United States District Court for the Eastern District of Texas,
 Tyler Division, alleging that the Company infringed certain patents
 relating to data storage and access systems. On February 24,
 2015, a jury returned a verdict against the Company, and awarded
 damages of approximately $533 million. The Company is challenging
 the verdict, believes it has valid defenses and has not recorded a
 loss accrual at this time.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-04-28):
[0001193125-15-153166:note_history:9]
These condensed consolidated financial statements
 and accompanying notes should be read in conjunction with the
 Company’s annual consolidated financial statements and the
 notes thereto for the fiscal year ended September 27, 2014,
 included in its Annual Report on Form 10-K as updated by the
 Company’s Current Report on Form 8-K dated January 28,
 2015 (hereinafter, the “2014 Form 10-K”). The
 Company’s fiscal year is the 52 or 53-week period that ends
 on the last Saturday of September. An additional week is included
 in the first fiscal quarter approximately every six years to
 realign fiscal quarters with calendar quarters. The Company’s
 fiscal years 2015 and 2014 each include 52 weeks. Unless otherwise
 stated, references to particular years, quarters or months refer to
 the Company’s fiscal years ended in September and the
 associated quarters or months of those fiscal years.
  (was, 2015-01-28, similarity 0.9472):
[0001193125-15-023697:note_history:9]
These condensed consolidated financial statements
 and accompanying notes should be read in conjunction with the
 Company’s annual consolidated financial statements and the
 notes thereto for the fiscal year ended September 27, 2014,
 included in its Annual Report on Form 10-K (the “2014 Form
 10-K”). The Company’s fiscal year is the 52 or 53-week
 period that ends on the last Saturday of September. An additional
 week is included in the first fiscal quarter approximately every
 six years to realign fiscal quarters with calendar quarters. The
 Company’s fiscal years 2015 and 2014 each include 52 weeks.
 Unless otherwise stated, references to particular years, quarters
 or months refer to the Company’s fiscal years ended in
 September and the associated quarters or months of those fiscal
 years.

- changed (2015-04-28):
[0001193125-15-153166:note_history:10]
The following table shows the computation of basic
 and diluted earnings per share for the three- and six-month periods
 ended March 28, 2015 and March 29, 2014 (net income in
 millions and shares in thousands):
  (was, 2015-01-28, similarity 0.9119):
[0001193125-15-023697:note_history:10]
The following table shows the computation of basic
 and diluted earnings per share for the three months ended
 December 27, 2014 and December 28, 2013 (net income in
 millions and shares in thousands):

- changed (2015-04-28):
[0001193125-15-153166:note_history:11]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 28, 2015 |  |  | March 29, 2014 |  |  | March 28, 2015 |  |  | March 29, 2014 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 13,569 |  |  | $ | 10,223 |  |  | $ | 31,593 |  |  | $ | 23,295 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding |  |  | 5,793,799 |  |  |  | 6,123,302 |  |  |  | 5,818,441 |  |  |  | 6,197,903 |  |
| Effect of dilutive securities |  |  | 41,059 |  |  |  | 33,397 |  |  |  | 39,889 |  |  |  | 35,527 |  |
| Weighted-average diluted shares |  |  | 5,834,858 |  |  |  | 6,156,699 |  |  |  | 5,858,330 |  |  |  | 6,233,430 |  |
| Basic earnings per share |  | $ | 2.34 |  |  | $ | 1.67 |  |  | $ | 5.43 |  |  | $ | 3.76 |  |
| Diluted earnings per share |  | $ | 2.33 |  |  | $ | 1.66 |  |  | $ | 5.39 |  |  | $ | 3.74 |  |
  (was, 2015-01-28, similarity 0.7354):
[0001193125-15-023697:note_history:11]
|  |  | Three Months Ended |  |
|  |  | December 27, 2014 |  |  | December 28, 2013 |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 18,024 |  |  | $ | 13,072 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding |  |  | 5,843,082 |  |  |  | 6,272,504 |  |
| Effect of dilutive securities |  |  | 38,721 |  |  |  | 37,657 |  |
| Weighted-average diluted shares |  |  | 5,881,803 |  |  |  | 6,310,161 |  |
| Basic earnings per share |  | $ | 3.08 |  |  | $ | 2.08 |  |
| Diluted earnings per share |  | $ | 3.06 |  |  | $ | 2.07 |  |

- changed (2015-04-28):
[0001193125-15-153166:note_history:12]
Potentially dilutive securities, whose effect would
 have been antidilutive, were not significant for the three- and
 six-month periods ended March 28, 2015 and the three- and
 six-month periods ended March 29, 2014. The Company excluded
 these securities from the computation of diluted earnings per
 share.
  (was, 2015-01-28, similarity 0.6904):
[0001193125-15-023697:note_history:12]
Potentially dilutive securities whose effect would
 have been antidilutive were not significant for the three months
 ended December 27, 2014 and December 28, 2013. The
 Company excluded these securities from the computation of diluted
 earnings per share.

- removed (2015-04-28):
[0001193125-15-023697:note_history:13]
Certain prior period amounts in the notes to the
 condensed consolidated financial statements have been reclassified
 to conform to the current period’s presentation. In the first
 quarter of 2015, the Company changed its reportable operating
 segments and began allocating certain costs to its operating
 segments that were previously included in other corporate expenses.
 The Company has reclassified the corresponding prior period amounts
 to conform to the current period’s presentation as further
 described in Note 11, “Segment Information and Geographic
 Data.”


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-04-28):
[0001193125-15-153166:note_history:14]
In 2014, the Board of Directors authorized the
 Company to issue unsecured short-term promissory notes
 (“Commercial Paper”) pursuant to a commercial paper
 program. The Company intends to use net proceeds from the
 commercial paper program for general corporate purposes, including
 dividends and share repurchases. As of March 28, 2015 and
 September 27, 2014, the Company had $3.8 billion and $6.3
 billion of Commercial Paper outstanding, respectively, with a
 weighted-average interest rate of 0.10% and 0.12%, respectively,
 and maturities generally less than nine months.
  (was, 2015-01-28, similarity 0.9827):
[0001193125-15-023697:note_history:14]
In April 2014, the Board of Directors authorized
 the Company to issue unsecured short-term promissory notes
 (“Commercial Paper”) pursuant to a commercial paper
 program. The Company intends to use net proceeds from the
 commercial paper program for general corporate purposes, including
 dividends and share repurchases. As of December 27, 2014 and
 September 27, 2014, the Company had $3.9 billion and $6.3
 billion of Commercial Paper outstanding, respectively, with a
 weighted-average interest rate of 0.11% and 0.12%, respectively,
 and maturities generally less than nine months.

- changed (2015-04-28):
[0001193125-15-153166:note_history:15]
The following table provides a summary of cash
 flows associated with the issuance and maturities of Commercial
 Paper for the six months ended March 28, 2015 (in
 millions):
  (was, 2015-01-28, similarity 0.9496):
[0001193125-15-023697:note_history:15]
The following table provides a summary of cash
 flows associated with the issuance and maturities of Commercial
 Paper for the three months ended December 27, 2014 (in
 millions):

- changed (2015-04-28):
[0001193125-15-153166:note_history:16]
As of March 28, 2015, the Company has
 outstanding floating- and fixed-rate notes with varying maturities
 for an aggregate principal amount of $39.9 billion (collectively
 the “Notes”). The Notes are senior unsecured
 obligations, and interest is payable in arrears, quarterly for the
 domestic floating-rate notes, semi-annually for the domestic
 fixed-rate notes and annually for the foreign fixed-rate notes. The
 following table provides a summary of the Company’s long-term
 debt as of March 28, 2015 and September 27, 2014:
  (was, 2015-01-28, similarity 0.8486):
[0001193125-15-023697:note_history:16]
As of December 27, 2014, the Company has
 issued floating- and fixed-rate notes with varying maturities for
 an aggregate principal amount of $32.4 billion (collectively the
 “Notes”). The Notes are senior unsecured obligations,
 and interest is payable in arrears, quarterly for the domestic
 floating-rate notes, semi-annually for the domestic fixed-rate
 notes and annually for the foreign fixed-rate notes.

- changed (2015-04-28):
[0001193125-15-153166:note_history:17]
|  |  | March 28, 2015 |  |  | September 27, 2014 |  |
|  |  | Amount (in millions) |  |  | Effective Interest Rate |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |
| Floating-rate notes due 2016 (1) |  | $ | 1,000 |  |  |  | 0.51% |  |  | $ | 1,000 |  |  |  | 0.51% |  |
| Floating-rate notes due 2017 (2) |  |  | 1,000 |  |  |  | 0.33% |  |  |  | 1,000 |  |  |  | 0.31% |  |
| Floating-rate notes due 2018 (1) |  |  | 2,000 |  |  |  | 1.10% |  |  |  | 2,000 |  |  |  | 1.10% |  |
| Floating-rate notes due 2019 (2) |  |  | 1,000 |  |  |  | 0.56% |  |  |  | 1,000 |  |  |  | 0.54% |  |
| Floating-rate notes due 2020 (3) |  |  | 500 |  |  |  | 0.51% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 0.45% notes due 2016 (1) |  |  | 1,500 |  |  |  | 0.51% |  |  |  | 1,500 |  |  |  | 0.51% |  |
| Fixed-rate 1.05% notes due 2017 (2) |  |  | 1,500 |  |  |  | 0.32% |  |  |  | 1,500 |  |  |  | 0.30% |  |
| Fixed-rate 1.00% notes due 2018 (1) |  |  | 4,000 |  |  |  | 1.08% |  |  |  | 4,000 |  |  |  | 1.08% |  |
| Fixed-rate 2.10% notes due 2019 (2) |  |  | 2,000 |  |  |  | 0.55% |  |  |  | 2,000 |  |  |  | 0.53% |  |
| Fixed-rate 1.55% notes due 2020 (3) |  |  | 1,250 |  |  |  | 0.50% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.85% notes due 2021 (2) |  |  | 3,000 |  |  |  | 0.81% |  |  |  | 3,000 |  |  |  | 0.79% |  |
| Fixed-rate 2.15% notes due 2022 (3) |  |  | 1,250 |  |  |  | 0.82% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 1.00% Euro-denominated notes due 2022 (4) |  |  | 1,534 |  |  |  | 2.94% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.40% notes due 2023 (1) |  |  | 5,500 |  |  |  | 2.44% |  |  |  | 5,500 |  |  |  | 2.44% |  |
| Fixed-rate 3.45% notes due 2024 (2) |  |  | 2,500 |  |  |  | 0.92% |  |  |  | 2,500 |  |  |  | 0.90% |  |
| Fixed-rate 0.38% Swiss Franc-denominated notes due 2024 (5) |  |  | 915 |  |  |  | 0.28% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.50% notes due 2025 (3) |  |  | 1,500 |  |  |  | 2.60% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 1.63% Euro-denominated notes due 2026 (4) |  |  | 1,534 |  |  |  | 3.45% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 0.75% Swiss Franc-denominated notes due 2030 (5) |  |  | 392 |  |  |  | 0.74% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 3.85% notes due 2043 (1) |  |  | 3,000 |  |  |  | 3.91% |  |  |  | 3,000 |  |  |  | 3.91% |  |
| Fixed-rate 4.45% notes due 2044 (2) |  |  | 1,000 |  |  |  | 4.48% |  |  |  | 1,000 |  |  |  | 4.48% |  |
| Fixed-rate 3.45% notes due 2045 (3) |  |  | 2,000 |  |  |  | 3.58% |  |  |  | 0 |  |  |  | 0 |  |
| Total borrowings |  |  | 39,875 |  |  |  |  |  |  |  | 29,000 |  |  |  |  |  |
| Unamortized discount |  |  | (80 | ) |  |  |  |  |  |  | (52 | ) |  |  |  |  |
| Hedge accounting fair value adjustments |  |  | 277 |  |  |  |  |  |  |  | 39 |  |  |  |  |  |
| Total long-term debt |  | $ | 40,072 |  |  |  |  |  |  | $ | 28,987 |  |  |  |  |  |
  (was, 2015-01-28, similarity 0.7587):
[0001193125-15-023697:note_history:17]
|  |  | December 27, 2014 |  |  | September 27, 2014 |  |
|  |  | Amount (in millions) |  |  | Effective Interest Rate |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |
| Floating-rate notes due 2016 (1) |  | $ | 1,000 |  |  |  | 0.51% |  |  | $ | 1,000 |  |  |  | 0.51% |  |
| Floating-rate notes due 2017 (2) |  |  | 1,000 |  |  |  | 0.30% |  |  |  | 1,000 |  |  |  | 0.31% |  |
| Floating-rate notes due 2018 (1) |  |  | 2,000 |  |  |  | 1.10% |  |  |  | 2,000 |  |  |  | 1.10% |  |
| Floating-rate notes due 2019 (2) |  |  | 1,000 |  |  |  | 0.53% |  |  |  | 1,000 |  |  |  | 0.54% |  |
| Fixed-rate 0.45% notes due 2016 (1) |  |  | 1,500 |  |  |  | 0.51% |  |  |  | 1,500 |  |  |  | 0.51% |  |
| Fixed-rate 1.05% notes due 2017 (2) |  |  | 1,500 |  |  |  | 0.30% |  |  |  | 1,500 |  |  |  | 0.30% |  |
| Fixed-rate 1.00% notes due 2018 (1) |  |  | 4,000 |  |  |  | 1.08% |  |  |  | 4,000 |  |  |  | 1.08% |  |
| Fixed-rate 2.10% notes due 2019 (2) |  |  | 2,000 |  |  |  | 0.53% |  |  |  | 2,000 |  |  |  | 0.53% |  |
| Fixed-rate 2.85% notes due 2021 (2) |  |  | 3,000 |  |  |  | 0.78% |  |  |  | 3,000 |  |  |  | 0.79% |  |
| Fixed-rate 1.00% Euro-denominated notes due 2022 (3) |  |  | 1,709 |  |  |  | 2.94% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.40% notes due 2023 (1) |  |  | 5,500 |  |  |  | 2.44% |  |  |  | 5,500 |  |  |  | 2.44% |  |
| Fixed-rate 3.45% notes due 2024 (2) |  |  | 2,500 |  |  |  | 0.89% |  |  |  | 2,500 |  |  |  | 0.90% |  |
| Fixed-rate 1.63% Euro-denominated notes due 2026 (3) |  |  | 1,709 |  |  |  | 3.45% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 3.85% notes due 2043 (1) |  |  | 3,000 |  |  |  | 3.91% |  |  |  | 3,000 |  |  |  | 3.91% |  |
| Fixed-rate 4.45% notes due 2044 (2) |  |  | 1,000 |  |  |  | 4.48% |  |  |  | 1,000 |  |  |  | 4.48% |  |
| Total borrowings |  |  | 32,418 |  |  |  |  |  |  |  | 29,000 |  |  |  |  |  |
| Unamortized discount |  |  | (69 | ) |  |  |  |  |  |  | (52 | ) |  |  |  |  |
| Hedge accounting fair value adjustments |  |  | 155 |  |  |  |  |  |  |  | 39 |  |  |  |  |  |
| Total long-term debt |  | $ | 32,504 |  |  |  |  |  |  | $ | 28,987 |  |  |  |  |  |

- added (2015-04-28):
[0001193125-15-153166:note_history:18]
|  | (3) | Tranche relates to the $6.5 billion debt issuance in the second quarter of 2015. |  |

- added (2015-04-28):
[0001193125-15-153166:note_history:19]
|  | (5) | Tranche relates to Swiss Franc-denominated debt issuance of SFr1.3 billion in the second quarter of 2015. |  |

- added (2015-04-28):
[0001193125-15-153166:note_history:20]
During the first six months of 2015, the Company
 issued €2.8
 billion of Euro-denominated notes, $6.5 billion of U.S.
 dollar-denominated notes and SFr1.3 billion of Swiss
 Franc-denominated notes. To manage foreign currency risk associated
 with the Euro-denominated notes, the Company entered into currency
 swaps with an aggregate notional amount of $3.5 billion, which
 effectively converted the Euro-denominated notes to U.S.
 dollar-denominated notes. To manage interest rate risk on the U.S.
 dollar-denominated fixed-rate notes maturing in 2020 and 2022, the
 Company entered into interest rate swaps with an aggregate notional
 amount of $2.5 billion, which effectively converted the fixed
 interest rates on these notes to a floating interest rate. For
 further discussion regarding the Company’s use of derivative
 instruments to manage interest rate and foreign currency risk, see
 the Derivative Financial Instruments section of Note 2,
 “Financial Instruments.”

- changed (2015-04-28):
[0001193125-15-153166:note_history:21]
The effective interest rates for the Notes include
 the interest on the Notes, amortization of the discount and, if
 applicable, adjustments related to hedging. The Company recognized
 $161 million and $289 million of interest expense on its long-term
 debt for the three- and six-month periods ended March 28,
 2015, respectively. The Company recognized $84 million and $168
 million of interest expense on its long-term debt for the three-
 and six-month periods ended March 29, 2014, respectively.
  (was, 2015-01-28, similarity 0.693):
[0001193125-15-023697:note_history:21]
The effective rates for the Notes include the
 interest on the Notes, amortization of the discount and, if
 applicable, adjustments related to hedging. The Company recognized
 $128 million and $84 million of interest expense on its long-term
 debt for the three months ended December 27, 2014 and
 December 28, 2013, respectively.

- changed (2015-04-28):
[0001193125-15-153166:note_history:22]
Future principal payments for the Company’s
 Notes as of March 28, 2015 are as follows (in millions):
  (was, 2015-01-28, similarity 0.9534):
[0001193125-15-023697:note_history:22]
Future principal payments for the Company’s
 Notes as of December 27, 2014 are as follows (in
 millions):

- changed (2015-04-28):
[0001193125-15-153166:note_history:23]
As of March 28, 2015 and September 27,
 2014, the fair value of the Company’s Notes, based on Level 2
 inputs, was $40.2 billion and $28.5 billion, respectively.
  (was, 2015-01-28, similarity 0.9686):
[0001193125-15-023697:note_history:23]
As of December 27, 2014 and September 27,
 2014, the fair value of the Company’s Notes, based on Level 2
 inputs, was $32.4 billion and $28.5 billion, respectively.

- removed (2015-04-28):
[0001193125-15-023697:note_history:24]
The following table provides a summary of the
 Company’s long-term debt as of December 27, 2014 and
 September 27, 2014:

- removed (2015-04-28):
[0001193125-15-023697:note_history:25]
The Company has entered, and in the future may
 enter, into interest rate swaps to manage interest rate risk on the
 Notes. Such swaps allow the Company to effectively convert
 fixed-rate payments into floating-rate payments or floating-rate
 payments into fixed-rate payments. In addition, the Company has
 entered, and in the future may enter, into currency swaps to manage
 foreign currency risk on the Notes.

- removed (2015-04-28):
[0001193125-15-023697:note_history:26]
In the first quarter of 2015, the Company
 issued €2.8 billion of
 Euro-denominated long-term debt. To manage foreign currency risk
 associated with this issuance, the Company entered into currency
 swaps with an aggregate notional amount of $3.5 billion, which
 effectively converted the Euro-denominated notes to U.S.
 dollar-denominated notes.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-04-28):
[0001193125-15-153166:note_history:27]
The following table provides a summary of the
 Company’s long-term debt as of March 28, 2015 and
 September 27, 2014:
  (was, 2015-01-28, similarity 0.9577):
[0001193125-15-023697:note_history:27]
The following table provides a summary of the
 Company’s long-term debt as of December 27, 2014 and
 September 27, 2014:

- changed (2015-04-28):
[0001193125-15-153166:note_history:28]
|  |  | March 28, 2015 |  |  | September 27, 2014 |  |
|  |  | Amount (in millions) |  |  | Effective Interest Rate |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |
| Floating-rate notes due 2016 (1) |  | $ | 1,000 |  |  |  | 0.51% |  |  | $ | 1,000 |  |  |  | 0.51% |  |
| Floating-rate notes due 2017 (2) |  |  | 1,000 |  |  |  | 0.33% |  |  |  | 1,000 |  |  |  | 0.31% |  |
| Floating-rate notes due 2018 (1) |  |  | 2,000 |  |  |  | 1.10% |  |  |  | 2,000 |  |  |  | 1.10% |  |
| Floating-rate notes due 2019 (2) |  |  | 1,000 |  |  |  | 0.56% |  |  |  | 1,000 |  |  |  | 0.54% |  |
| Floating-rate notes due 2020 (3) |  |  | 500 |  |  |  | 0.51% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 0.45% notes due 2016 (1) |  |  | 1,500 |  |  |  | 0.51% |  |  |  | 1,500 |  |  |  | 0.51% |  |
| Fixed-rate 1.05% notes due 2017 (2) |  |  | 1,500 |  |  |  | 0.32% |  |  |  | 1,500 |  |  |  | 0.30% |  |
| Fixed-rate 1.00% notes due 2018 (1) |  |  | 4,000 |  |  |  | 1.08% |  |  |  | 4,000 |  |  |  | 1.08% |  |
| Fixed-rate 2.10% notes due 2019 (2) |  |  | 2,000 |  |  |  | 0.55% |  |  |  | 2,000 |  |  |  | 0.53% |  |
| Fixed-rate 1.55% notes due 2020 (3) |  |  | 1,250 |  |  |  | 0.50% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.85% notes due 2021 (2) |  |  | 3,000 |  |  |  | 0.81% |  |  |  | 3,000 |  |  |  | 0.79% |  |
| Fixed-rate 2.15% notes due 2022 (3) |  |  | 1,250 |  |  |  | 0.82% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 1.00% Euro-denominated notes due 2022 (4) |  |  | 1,534 |  |  |  | 2.94% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.40% notes due 2023 (1) |  |  | 5,500 |  |  |  | 2.44% |  |  |  | 5,500 |  |  |  | 2.44% |  |
| Fixed-rate 3.45% notes due 2024 (2) |  |  | 2,500 |  |  |  | 0.92% |  |  |  | 2,500 |  |  |  | 0.90% |  |
| Fixed-rate 0.38% Swiss Franc-denominated notes due 2024 (5) |  |  | 915 |  |  |  | 0.28% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.50% notes due 2025 (3) |  |  | 1,500 |  |  |  | 2.60% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 1.63% Euro-denominated notes due 2026 (4) |  |  | 1,534 |  |  |  | 3.45% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 0.75% Swiss Franc-denominated notes due 2030 (5) |  |  | 392 |  |  |  | 0.74% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 3.85% notes due 2043 (1) |  |  | 3,000 |  |  |  | 3.91% |  |  |  | 3,000 |  |  |  | 3.91% |  |
| Fixed-rate 4.45% notes due 2044 (2) |  |  | 1,000 |  |  |  | 4.48% |  |  |  | 1,000 |  |  |  | 4.48% |  |
| Fixed-rate 3.45% notes due 2045 (3) |  |  | 2,000 |  |  |  | 3.58% |  |  |  | 0 |  |  |  | 0 |  |
| Total borrowings |  |  | 39,875 |  |  |  |  |  |  |  | 29,000 |  |  |  |  |  |
| Unamortized discount |  |  | (80 | ) |  |  |  |  |  |  | (52 | ) |  |  |  |  |
| Hedge accounting fair value adjustments |  |  | 277 |  |  |  |  |  |  |  | 39 |  |  |  |  |  |
| Total long-term debt |  | $ | 40,072 |  |  |  |  |  |  | $ | 28,987 |  |  |  |  |  |
  (was, 2015-01-28, similarity 0.7587):
[0001193125-15-023697:note_history:28]
|  |  | December 27, 2014 |  |  | September 27, 2014 |  |
|  |  | Amount (in millions) |  |  | Effective Interest Rate |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |
| Floating-rate notes due 2016 (1) |  | $ | 1,000 |  |  |  | 0.51% |  |  | $ | 1,000 |  |  |  | 0.51% |  |
| Floating-rate notes due 2017 (2) |  |  | 1,000 |  |  |  | 0.30% |  |  |  | 1,000 |  |  |  | 0.31% |  |
| Floating-rate notes due 2018 (1) |  |  | 2,000 |  |  |  | 1.10% |  |  |  | 2,000 |  |  |  | 1.10% |  |
| Floating-rate notes due 2019 (2) |  |  | 1,000 |  |  |  | 0.53% |  |  |  | 1,000 |  |  |  | 0.54% |  |
| Fixed-rate 0.45% notes due 2016 (1) |  |  | 1,500 |  |  |  | 0.51% |  |  |  | 1,500 |  |  |  | 0.51% |  |
| Fixed-rate 1.05% notes due 2017 (2) |  |  | 1,500 |  |  |  | 0.30% |  |  |  | 1,500 |  |  |  | 0.30% |  |
| Fixed-rate 1.00% notes due 2018 (1) |  |  | 4,000 |  |  |  | 1.08% |  |  |  | 4,000 |  |  |  | 1.08% |  |
| Fixed-rate 2.10% notes due 2019 (2) |  |  | 2,000 |  |  |  | 0.53% |  |  |  | 2,000 |  |  |  | 0.53% |  |
| Fixed-rate 2.85% notes due 2021 (2) |  |  | 3,000 |  |  |  | 0.78% |  |  |  | 3,000 |  |  |  | 0.79% |  |
| Fixed-rate 1.00% Euro-denominated notes due 2022 (3) |  |  | 1,709 |  |  |  | 2.94% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.40% notes due 2023 (1) |  |  | 5,500 |  |  |  | 2.44% |  |  |  | 5,500 |  |  |  | 2.44% |  |
| Fixed-rate 3.45% notes due 2024 (2) |  |  | 2,500 |  |  |  | 0.89% |  |  |  | 2,500 |  |  |  | 0.90% |  |
| Fixed-rate 1.63% Euro-denominated notes due 2026 (3) |  |  | 1,709 |  |  |  | 3.45% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 3.85% notes due 2043 (1) |  |  | 3,000 |  |  |  | 3.91% |  |  |  | 3,000 |  |  |  | 3.91% |  |
| Fixed-rate 4.45% notes due 2044 (2) |  |  | 1,000 |  |  |  | 4.48% |  |  |  | 1,000 |  |  |  | 4.48% |  |
| Total borrowings |  |  | 32,418 |  |  |  |  |  |  |  | 29,000 |  |  |  |  |  |
| Unamortized discount |  |  | (69 | ) |  |  |  |  |  |  | (52 | ) |  |  |  |  |
| Hedge accounting fair value adjustments |  |  | 155 |  |  |  |  |  |  |  | 39 |  |  |  |  |  |
| Total long-term debt |  | $ | 32,504 |  |  |  |  |  |  | $ | 28,987 |  |  |  |  |  |

- added (2015-04-28):
[0001193125-15-153166:note_history:29]
|  | (3) | Tranche relates to the $6.5 billion debt issuance in the second quarter of 2015. |  |

- added (2015-04-28):
[0001193125-15-153166:note_history:30]
|  | (5) | Tranche relates to Swiss Franc-denominated debt issuance of SFr1.3 billion in the second quarter of 2015. |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-04-28):
[0001193125-15-153166:note_history:31]
Future principal payments for the Company’s
 Notes as of March 28, 2015 are as follows (in millions):
  (was, 2015-01-28, similarity 0.9534):
[0001193125-15-023697:note_history:31]
Future principal payments for the Company’s
 Notes as of December 27, 2014 are as follows (in
 millions):
