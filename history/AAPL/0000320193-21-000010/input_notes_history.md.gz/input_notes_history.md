# AAPL note change history — 0000320193-20-000062 → 0000320193-21-000010


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-01-28):
[0000320193-21-000010:note_history:1]
The following table shows changes in the Company’s accrued warranties and related costs for the three months ended December 26, 2020 and December 28, 2019 (in millions):
  (was, 2020-07-31, similarity 0.8869):
[0000320193-20-000062:note_history:1]
The following table shows changes in the Company’s accrued warranties and related costs for the three- and nine-month periods ended June 27, 2020 and June 29, 2019 (in millions):

- changed (2021-01-28):
[0000320193-21-000010:note_history:2]
|  | Three Months Ended |  |  |
|  | December 26,2020 |  | December 28,2019 |  |  |  |  |
| Beginning accrued warranty and related costs | $ | 3,354 |  |  | $ | 3,570 |  |  |  |  |  |
| Cost of warranty claims | (723) |  |  | (915) |  |  |  |  |  |
| Accruals for product warranty | 1,493 |  |  | 1,218 |  |  |  |  |  |
| Ending accrued warranty and related costs | $ | 4,124 |  |  | $ | 3,873 |  |  |  |  |  |
  (was, 2020-07-31, similarity 0.776):
[0000320193-20-000062:note_history:2]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | June 27,2020 |  | June 29,2019 |  | June 27,2020 |  | June 29,2019 |
| Beginning accrued warranty and related costs | $ | 3,923 |  |  | $ | 3,487 |  |  | $ | 3,570 |  |  | $ | 3,692 |  |
| Cost of warranty claims | (576) |  |  | (912) |  |  | (2,180) |  |  | (2,823) |  |
| Accruals for product warranty | 557 |  |  | 548 |  |  | 2,514 |  |  | 2,254 |  |
| Ending accrued warranty and related costs | $ | 3,904 |  |  | $ | 3,123 |  |  | $ | 3,904 |  |  | $ | 3,123 |  |

- changed (2021-01-28):
[0000320193-21-000010:note_history:3]
The Company offers an iPhone Upgrade Program, which is available to customers who purchase a qualifying iPhone in the U.S., the U.K. and China mainland. The iPhone Upgrade Program provides customers the right to trade in that iPhone for a specified amount when purchasing a new iPhone, provided certain conditions are met. The Company accounts for the trade-in right as a guarantee liability and recognizes arrangement revenue net of the fair value of such right, with subsequent changes to the guarantee liability recognized within net sales.
  (was, 2020-07-31, similarity 0.9742):
[0000320193-20-000062:note_history:3]
The Company offers an iPhone Upgrade Program, which is available to customers who purchase a qualifying iPhone in the U.S., the U.K. and mainland China. The iPhone Upgrade Program provides customers the right to trade in that iPhone for a specified amount when purchasing a new iPhone, provided certain conditions are met. The Company accounts for the trade-in right as a guarantee liability and recognizes arrangement revenue net of the fair value of such right, with subsequent changes to the guarantee liability recognized within net sales.

- changed (2021-01-28):
[0000320193-21-000010:note_history:4]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of payments for content creation, Internet and telecommunications services and supplier arrangements. As of December 26, 2020, the Company’s total future payments under noncancelable unconditional purchase obligations having a remaining term in excess of one year were $8.1 billion.
  (was, 2020-07-31, similarity 0.8749):
[0000320193-20-000062:note_history:4]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of payments for supplier arrangements, Internet and telecommunication services, intellectual property licenses and content creation. As of June 27, 2020, the Company’s total future payments under noncancelable unconditional purchase obligations having a remaining term in excess of one year were $9.2 billion.

- added (2021-01-28):
[0000320193-21-000010:note_history:5]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully resolved. The outcome of litigation is inherently uncertain. When a loss related to a legal proceeding or claim is probable and reasonably estimable, the Company accrues its best estimate for the ultimate resolution of the matter. If one or more legal matters were resolved against the Company in a reporting period for amounts above management’s expectations, the Company’s financial condition and operating results for that reporting period could be materially adversely affected. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss greater than a recorded accrual, concerning loss contingencies for asserted legal and other claims, except for the following matters:

- changed (2021-01-28):
[0000320193-21-000010:note_history:6]
VirnetX, Inc. (“VirnetX”) filed a lawsuit against the Company alleging that certain of the Company’s products infringe on patents owned by VirnetX. On April 11, 2018, a jury returned a verdict against the Company in the U.S. District Court for the Eastern District of Texas (the “Eastern Texas District Court”). The Company appealed the verdict to the U.S. Court of Appeals for the Federal Circuit, which remanded the case back to the Eastern Texas District Court, where a re-trial was held in October 2020. The jury returned a verdict against the Company and awarded damages of $503 million, which the Company intends to appeal. The Company has challenged the validity of the patents at issue in the re-trial at the U.S. Patent and Trademark Office (the “PTO”), and the PTO has declared the patents invalid, subject to further appeal by VirnetX.
  (was, 2020-07-31, similarity 0.6122):
[0000320193-20-000062:note_history:6]
VirnetX, Inc. (“VirnetX”) filed a lawsuit against the Company alleging that certain of the Company’s products infringe on patents owned by VirnetX. On April 11, 2018, a jury returned a verdict against the Company and awarded damages of $503 million. The Company appealed the verdict to the U.S. Court of Appeals for the Federal Circuit, which remanded the case back to the U.S. District Court for the Eastern District of Texas, where it is scheduled for a re-trial in August 2020. The Company has challenged the validity of the patents at issue in the re-trial at the U.S. Patent and Trademark Office (the “PTO”), and the PTO has declared the patents invalid, subject to further appeal by VirnetX.

- changed (2021-01-28):
[0000320193-21-000010:note_history:7]
Various civil litigation matters have been filed in state and federal courts in the U.S. and in various international jurisdictions alleging violation of consumer protection laws, fraud, computer intrusion and other causes of action related to the Company’s performance management feature used in its iPhone operating systems, introduced to certain iPhones in iOS updates 10.2.1 and 11.2. The claims seek monetary damages and other non-monetary relief. On April 5, 2018, several U.S. federal actions were consolidated through a Multidistrict Litigation process into a single action in the U.S. District Court for the Northern District of California (the “Northern California District Court”). On February 28, 2020, the parties in the Multidistrict Litigation reached a settlement to resolve the U.S. federal and California state class actions. Under the terms of the settlement, which the Northern California District Court preliminarily approved in May 2020, the Company has agreed to pay up to $500 million in the aggregate to certain U.S. owners of iPhones if certain conditions are met. The final amount of the settlement will be determined based on the number of consumers who file valid claims and the attorneys’ fee award. However, the Company has agreed to pay at least $310 million to settle the claims. In addition to civil litigation, the Company is also responding to governmental investigations and requests for information relating to the performance management feature. On November 18, 2020, the Company reached a settlement with a multi-state group of attorneys general. Under the terms of the settlement, the Company has agreed to pay an aggregate amount of $113 million to resolve civil, statutory claims. The Company continues to believe that its iPhones were not defective, that the performance management feature introduced with iOS updates 10.2.1 and 11.2 was intended to, and did, improve customers’ user experience, and that the Company did not make any misleading statements or fail to disclose any material information.
  (was, 2020-07-31, similarity 0.7577):
[0000320193-20-000062:note_history:7]
Various civil litigation matters have been filed in state and federal courts in the U.S. and in various international jurisdictions alleging violation of consumer protection laws, fraud, computer intrusion and other causes of action related to the Company’s performance management feature used in its iPhone operating systems, introduced to certain iPhones in iOS updates 10.2.1 and 11.2. The claims seek monetary damages and other non-monetary relief. On April 5, 2018, several U.S. federal actions were consolidated through a Multidistrict Litigation process into a single action in the U.S. District Court for the Northern District of California (the “Northern California District Court”). On February 28, 2020, the parties in the Multidistrict Litigation reached a settlement to resolve the U.S. federal and California state class actions. Under the terms of the settlement, which the Northern California District Court preliminarily approved in May 2020, the Company has agreed to pay up to $500 million in the aggregate to certain U.S. owners of iPhones if certain conditions are met. The final amount of the settlement will be determined based on the number of consumers who file valid claims and the attorneys’ fee award. However, the Company has agreed to pay at least $310 million to settle the claims. In addition to civil litigation, the Company is also responding to governmental investigations and requests for information relating to the performance management feature. The Company continues to believe that its iPhones were not defective, that the performance management feature introduced with iOS updates 10.2.1 and 11.2 was intended to, and did, improve customers’ user experience, and that the Company did not make any misleading statements or fail to disclose any material information. The Company has accrued its best estimate for the ultimate resolution of these matters.

- changed (2021-01-28):
[0000320193-21-000010:note_history:8]
On March 16, 2020, the French Competition Authority (“FCA”) announced its decision that aspects of the Company’s sales and distribution practices in France violate French competition law and issued a fine of €1.1 billion. The Company strongly disagrees with the FCA’s decision and has appealed.
  (was, 2020-07-31, similarity 0.9965):
[0000320193-20-000062:note_history:8]
On March 16, 2020, the French Competition Authority (“FCA”) announced its decision that aspects of the Company’s sales and distribution practices in France violate French competition law, and issued a fine of €1.1 billion. The Company strongly disagrees with the FCA’s decision, and has appealed.

- added (2021-01-28):
[0000320193-21-000010:note_history:9]
Optis

- added (2021-01-28):
[0000320193-21-000010:note_history:10]
Optis Wireless Technology, LLC and related entities (“Optis”) filed a lawsuit in the U.S. District Court for the Eastern District of Texas against the Company alleging that certain of the Company’s products infringe on patents owned by Optis. On August 11, 2020, a jury returned a verdict against the Company and awarded damages of $506 million. The Company has asked the court to set aside the verdict, where the case remains pending.

- removed (2021-01-28):
[0000320193-20-000062:note_history:11]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully resolved. The outcome of litigation is inherently uncertain. If one or more legal matters were resolved against the Company in a reporting period for amounts above management’s expectations, the Company’s financial condition and operating results for that reporting period could be materially adversely affected. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss greater than a recorded accrual, concerning loss contingencies for asserted legal and other claims, except for the following matters:


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-01-28):
[0000320193-21-000010:note_history:12]
The condensed consolidated financial statements include the accounts of Apple Inc. and its wholly owned subsidiaries (collectively “Apple” or the “Company”). Intercompany accounts and transactions have been eliminated. In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements and accompanying notes in conformity with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported. Actual results could differ materially from those estimates. Certain prior period amounts in the consolidated financial statements and accompanying notes have been reclassified to conform to the current period’s presentation. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company’s annual consolidated financial statements and accompanying notes included in its Annual Report on Form 10-K for the fiscal year ended September 26, 2020 (the “2020 Form 10-K”).
  (was, 2020-07-31, similarity 0.9254):
[0000320193-20-000062:note_history:12]
The condensed consolidated financial statements include the accounts of Apple Inc. and its wholly owned subsidiaries (collectively “Apple” or the “Company”). Intercompany accounts and transactions have been eliminated. In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements and accompanying notes in conformity with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported. Actual results could differ materially from those estimates. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company’s annual consolidated financial statements and accompanying notes included in its Annual Report on Form 10-K for the fiscal year ended September 28, 2019 (the “2019 Form 10-K”).

- changed (2021-01-28):
[0000320193-21-000010:note_history:13]
The Company’s fiscal year is the 52- or 53-week period that ends on the last Saturday of September. An additional week is included in the first fiscal quarter every five or six years to realign the Company’s fiscal quarters with calendar quarters. The Company’s fiscal years 2021 and 2020 span 52 weeks each. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in September and the associated quarters, months and periods of those fiscal years.
  (was, 2020-07-31, similarity 0.9842):
[0000320193-20-000062:note_history:13]
The Company’s fiscal year is the 52- or 53-week period that ends on the last Saturday of September. A 14th week is included in the first fiscal quarter every five or six years to realign the Company’s fiscal quarters with calendar quarters. The Company’s fiscal years 2020 and 2019 span 52 weeks each. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in September and the associated quarters, months and periods of those fiscal years.

- added (2021-01-28):
[0000320193-21-000010:note_history:14]
Common Stock Split

- added (2021-01-28):
[0000320193-21-000010:note_history:15]
On August 28, 2020, the Company effected a four-for-one stock split to shareholders of record as of August 24, 2020. All share, restricted stock unit (“RSU”) and per share or per RSU information has been retroactively adjusted to reflect the stock split.

- added (2021-01-28):
[0000320193-21-000010:note_history:16]
Financial Instruments – Credit Losses

- added (2021-01-28):
[0000320193-21-000010:note_history:17]
At the beginning of the first quarter of 2021, the Company adopted the Financial Accounting Standards Board’s Accounting Standards Update No. 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (“ASU 2016-13”), which modifies the measurement of expected credit losses on certain financial instruments. The Company adopted ASU 2016-13 utilizing the modified retrospective transition method. The adoption of ASU 2016-13 did not have a material impact on the Company’s condensed consolidated financial statements.

- changed (2021-01-28):
[0000320193-21-000010:note_history:18]
The following table shows the computation of basic and diluted earnings per share for the three months ended December 26, 2020 and December 28, 2019 (net income in millions and shares in thousands):
  (was, 2020-07-31, similarity 0.9039):
[0000320193-20-000062:note_history:18]
The following table shows the computation of basic and diluted earnings per share for the three- and nine-month periods ended June 27, 2020 and June 29, 2019 (net income in millions and shares in thousands):

- added (2021-01-28):
[0000320193-21-000010:note_history:19]
|  | Three Months Ended |  |  |
|  | December 26,2020 |  | December 28,2019 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 28,755 |  |  | $ | 22,236 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 16,935,119 |  |  | 17,660,160 |  |  |  |  |  |
| Effect of dilutive securities | 178,569 |  |  | 158,257 |  |  |  |  |  |
| Weighted-average diluted shares | 17,113,688 |  |  | 17,818,417 |  |  |  |  |  |
| Basic earnings per share | $ | 1.70 |  |  | $ | 1.26 |  |  |  |  |  |
| Diluted earnings per share | $ | 1.68 |  |  | $ | 1.25 |  |  |  |  |  |

- removed (2021-01-28):
[0000320193-20-000062:note_history:20]
Leases

- removed (2021-01-28):
[0000320193-20-000062:note_history:21]
At the beginning of the first quarter of 2020, the Company adopted the Financial Accounting Standards Board’s (the “FASB”) Accounting Standards Update (“ASU”) No. 2016-02, Leases (Topic 842) (“ASU 2016-02”), and additional ASUs issued to clarify and update the guidance in ASU 2016-02 (collectively, the “new leases standard”), which modifies lease accounting for lessees to increase transparency and comparability by recording lease assets and liabilities for operating leases and disclosing key information about leasing arrangements. The Company adopted the new leases standard utilizing the modified retrospective transition method, under which amounts in prior periods presented were not restated. For contracts existing at the time of adoption, the Company elected to not reassess (i) whether any are or contain leases, (ii) lease classification, and (iii) initial direct costs. Upon adoption, the Company recorded $7.5 billion of right-of-use (“ROU”) assets and $8.1 billion of lease liabilities on its Condensed Consolidated Balance Sheet.

- removed (2021-01-28):
[0000320193-20-000062:note_history:22]
Hedging

- removed (2021-01-28):
[0000320193-20-000062:note_history:23]
At the beginning of the first quarter of 2020, the Company adopted FASB ASU No. 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities (“ASU 2017-12”). ASU 2017-12 expands component and fair value hedging, specifies the presentation of the effects of hedging instruments, eliminates the separate measurement and presentation of hedge ineffectiveness, and updates disclosure requirements related to hedging. The Company adopted ASU 2017-12 utilizing the modified retrospective transition method. Upon adoption, the Company recorded a $136 million increase in accumulated other comprehensive income/(loss) (“AOCI”) and a corresponding decrease in retained earnings in the Condensed Consolidated Statement of Shareholders’ Equity.

- removed (2021-01-28):
[0000320193-20-000062:note_history:24]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | June 27,2020 |  | June 29,2019 |  | June 27,2020 |  | June 29,2019 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 11,253 |  |  | $ | 10,044 |  |  | $ | 44,738 |  |  | $ | 41,570 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 4,312,573 |  |  | 4,570,633 |  |  | 4,362,571 |  |  | 4,660,175 |  |
| Effect of dilutive securities | 42,215 |  |  | 30,747 |  |  | 42,124 |  |  | 31,584 |  |
| Weighted-average diluted shares | 4,354,788 |  |  | 4,601,380 |  |  | 4,404,695 |  |  | 4,691,759 |  |
| Basic earnings per share | $ | 2.61 |  |  | $ | 2.20 |  |  | $ | 10.25 |  |  | $ | 8.92 |  |
| Diluted earnings per share | $ | 2.58 |  |  | $ | 2.18 |  |  | $ | 10.16 |  |  | $ | 8.86 |  |

- removed (2021-01-28):
[0000320193-20-000062:note_history:25]
Potentially dilutive securities representing 1.5 million and 20.5 million shares of common stock were excluded from the computation of diluted earnings per share for the three- and nine-month periods ended June 29, 2019, respectively, because their effect would have been antidilutive.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-01-28):
[0000320193-21-000010:note_history:26]
Debt
Commercial Paper
  (was, 2020-07-31, similarity 0.6176):
[0000320193-20-000062:note_history:26]
Debt
Commercial Paper and Repurchase Agreements

- changed (2021-01-28):
[0000320193-21-000010:note_history:27]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of both December 26, 2020 and September 26, 2020, the Company had $5.0 billion of Commercial Paper outstanding, with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 0.10% and 0.62% as of December 26, 2020 and September 26, 2020, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the three months ended December 26, 2020 and December 28, 2019 (in millions):
  (was, 2020-07-31, similarity 0.8308):
[0000320193-20-000062:note_history:27]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of both June 27, 2020 and September 28, 2019, the Company had $6.0 billion of Commercial Paper outstanding with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 0.77% and 2.24% as of June 27, 2020 and September 28, 2019, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the nine months ended June 27, 2020 and June 29, 2019 (in millions):

- added (2021-01-28):
[0000320193-21-000010:note_history:28]
|  | Three Months Ended |
|  | December 26,2020 |  | December 28,2019 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | 1,439 |  |  | $ | (175) |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 780 |  |  | 1,317 |  |
| Repayments of commercial paper | (2,197) |  |  | (2,121) |  |
| Repayments of commercial paper, net | (1,417) |  |  | (804) |  |
| Total proceeds from/(repayments of) commercial paper, net | $ | 22 |  |  | $ | (979) |  |

- changed (2021-01-28):
[0000320193-21-000010:note_history:29]
As of December 26, 2020, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $105.9 billion (collectively the “Notes”). The Notes are senior unsecured obligations and interest is payable in arrears. The following table provides a summary of the Company’s term debt as of December 26, 2020 and September 26, 2020:
  (was, 2020-07-31, similarity 0.9663):
[0000320193-20-000062:note_history:29]
As of June 27, 2020, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $100.1 billion (collectively the “Notes”). The Notes are senior unsecured obligations and interest is payable in arrears. The following table provides a summary of the Company’s term debt as of June 27, 2020 and September 28, 2019:

- changed (2021-01-28):
[0000320193-21-000010:note_history:30]
|  | Maturities(calendar year) |  | December 26, 2020 |  | September 26, 2020 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 – 2020 debt issuances: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2021 – 2022 |  | $ | 2,250 |  |  | 0.56% – 1.34% |  | $ | 2,250 |  |  | 0.60% – 1.39% |
| Fixed-rate 0.000% – 4.650% notes | 2021 – 2060 |  | 103,613 |  |  | 0.03% – 4.78% |  | 103,828 |  |  | 0.03% – 4.78% |
| Total term debt |  |  | 105,863 |  |  |  |  | 106,078 |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  | (305) |  |  |  |  | (314) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 1,485 |  |  |  |  | 1,676 |  |  |  |
| Less: Current portion of term debt |  |  | (7,762) |  |  |  |  | (8,773) |  |  |  |
| Total non-current portion of term debt |  |  | $ | 99,281 |  |  |  |  | $ | 98,667 |  |  |  |
  (was, 2020-07-31, similarity 0.8134):
[0000320193-20-000062:note_history:30]
|  | Maturities(calendar year) |  | June 27, 2020 |  |  |  | September 28, 2019 |  |  |
|  |  |  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 – 2019 debt issuances: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2021 – 2022 |  | $ | 2,250 |  |  | 0.80% – 1.49% |  | $ | 4,250 |  |  | 2.25% – 3.28% |
| Fixed-rate 0.375% – 4.650% notes | 2020 – 2049 |  | 87,055 |  |  | 0.28% – 4.78% |  | 97,429 |  |  | 0.28% – 4.78% |
| First quarter 2020 debt issuance of €2.0 billion: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.000% – 0.500% notes | 2025 – 2031 |  | 2,260 |  |  | 0.03% – 0.56% |  | — |  |  | — | % |
| Third quarter 2020 debt issuance of $8.5 billion: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.750% – 2.650% notes | 2023 – 2050 |  | 8,500 |  |  | 0.84% – 2.72% |  | — |  |  | — | % |
| Total term debt |  |  | 100,065 |  |  |  |  | 101,679 |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  | (279) |  |  |  |  | (224) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 1,771 |  |  |  |  | 612 |  |  |  |
| Less: Current portion of term debt |  |  | (7,509) |  |  |  |  | (10,260) |  |  |  |
| Total non-current portion of term debt |  |  | $ | 94,048 |  |  |  |  | $ | 91,807 |  |  |  |

- added (2021-01-28):
[0000320193-21-000010:note_history:31]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $628 million and $757 million of interest cost on its term debt for the three months ended December 26, 2020 and December 28, 2019, respectively.

- changed (2021-01-28):
[0000320193-21-000010:note_history:32]
As of December 26, 2020 and September 26, 2020, the fair value of the Company’s Notes, based on Level 2 inputs, was $117.2 billion and $117.1 billion, respectively.
  (was, 2020-07-31, similarity 0.965):
[0000320193-20-000062:note_history:32]
As of June 27, 2020 and September 28, 2019, the fair value of the Company’s Notes, based on Level 2 inputs, was $110.8 billion and $107.5 billion, respectively.

- removed (2021-01-28):
[0000320193-20-000062:note_history:33]
|  | Nine Months Ended |  |  |
|  | June 27,2020 |  | June 29,2019 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | 401 |  |  | $ | (3,720) |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 5,373 |  |  | 12,977 |  |
| Repayments of commercial paper | (5,743) |  |  | (11,283) |  |
| Proceeds from/(Repayments of) commercial paper, net | (370) |  |  | 1,694 |  |
| Total proceeds from/(repayments of) commercial paper, net | $ | 31 |  |  | $ | (2,026) |  |

- removed (2021-01-28):
[0000320193-20-000062:note_history:34]
In 2020, the Company entered into agreements to sell certain of its marketable securities with a promise to repurchase the securities at a specified time and amount (“Repos”). Due to the Company’s continuing involvement with the marketable securities, the Company accounts for its Repos as collateralized borrowings. As of June 27, 2020, the Company had $5.2 billion of Repo liabilities outstanding with maturities of less than three months, and had pledged $5.3 billion of marketable securities as collateral.

- removed (2021-01-28):
[0000320193-20-000062:note_history:35]
As of September 28, 2019, a portion of the Company’s Japanese yen–denominated notes with a carrying value of $1.0 billion was designated as a hedge of the foreign currency exposure of the Company’s net investment in a foreign operation. The Company’s Japanese yen–denominated notes matured during the third quarter of 2020 and the associated net investment hedges were terminated. For further discussion regarding the Company’s use of derivative instruments, refer to the Derivative Financial Instruments section of Note 3, “Financial Instruments.”

- removed (2021-01-28):
[0000320193-20-000062:note_history:36]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $664 million and $2.1 billion of interest cost on its term debt for the three- and nine-month periods ended June 27, 2020, respectively. The Company recognized $790 million and $2.4 billion of interest cost on its term debt for the three- and nine-month periods ended June 29, 2019, respectively.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-01-28):
[0000320193-21-000010:note_history:37]
The following table provides a summary of the Company’s term debt as of December 26, 2020 and September 26, 2020:
  (was, 2020-07-31, similarity 0.9505):
[0000320193-20-000062:note_history:37]
The following table provides a summary of the Company’s term debt as of June 27, 2020 and September 28, 2019:

- changed (2021-01-28):
[0000320193-21-000010:note_history:38]
|  | Maturities(calendar year) |  | December 26, 2020 |  | September 26, 2020 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 – 2020 debt issuances: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2021 – 2022 |  | $ | 2,250 |  |  | 0.56% – 1.34% |  | $ | 2,250 |  |  | 0.60% – 1.39% |
| Fixed-rate 0.000% – 4.650% notes | 2021 – 2060 |  | 103,613 |  |  | 0.03% – 4.78% |  | 103,828 |  |  | 0.03% – 4.78% |
| Total term debt |  |  | 105,863 |  |  |  |  | 106,078 |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  | (305) |  |  |  |  | (314) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 1,485 |  |  |  |  | 1,676 |  |  |  |
| Less: Current portion of term debt |  |  | (7,762) |  |  |  |  | (8,773) |  |  |  |
| Total non-current portion of term debt |  |  | $ | 99,281 |  |  |  |  | $ | 98,667 |  |  |  |
  (was, 2020-07-31, similarity 0.8134):
[0000320193-20-000062:note_history:38]
|  | Maturities(calendar year) |  | June 27, 2020 |  |  |  | September 28, 2019 |  |  |
|  |  |  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 – 2019 debt issuances: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2021 – 2022 |  | $ | 2,250 |  |  | 0.80% – 1.49% |  | $ | 4,250 |  |  | 2.25% – 3.28% |
| Fixed-rate 0.375% – 4.650% notes | 2020 – 2049 |  | 87,055 |  |  | 0.28% – 4.78% |  | 97,429 |  |  | 0.28% – 4.78% |
| First quarter 2020 debt issuance of €2.0 billion: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.000% – 0.500% notes | 2025 – 2031 |  | 2,260 |  |  | 0.03% – 0.56% |  | — |  |  | — | % |
| Third quarter 2020 debt issuance of $8.5 billion: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.750% – 2.650% notes | 2023 – 2050 |  | 8,500 |  |  | 0.84% – 2.72% |  | — |  |  | — | % |
| Total term debt |  |  | 100,065 |  |  |  |  | 101,679 |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  | (279) |  |  |  |  | (224) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 1,771 |  |  |  |  | 612 |  |  |  |
| Less: Current portion of term debt |  |  | (7,509) |  |  |  |  | (10,260) |  |  |  |
| Total non-current portion of term debt |  |  | $ | 94,048 |  |  |  |  | $ | 91,807 |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-01-28):
[0000320193-21-000010:note_history:39]
Net sales disaggregated by significant products and services for the three months ended December 26, 2020 and December 28, 2019 were as follows (in millions):
  (was, 2020-07-31, similarity 0.8787):
[0000320193-20-000062:note_history:39]
Net sales disaggregated by significant products and services for the three- and nine-month periods ended June 27, 2020 and June 29, 2019 were as follows (in millions):

- changed (2021-01-28):
[0000320193-21-000010:note_history:40]
|  | Three Months Ended |  |  |
|  | December 26,2020 |  | December 28,2019 |  |  |  |  |
| iPhone (1) | $ | 65,597 |  |  | $ | 55,957 |  |  |  |  |  |
| Mac (1) | 8,675 |  |  | 7,160 |  |  |  |  |  |
| iPad (1) | 8,435 |  |  | 5,977 |  |  |  |  |  |
| Wearables, Home and Accessories (1)(2) | 12,971 |  |  | 10,010 |  |  |  |  |  |
| Services (3) | 15,761 |  |  | 12,715 |  |  |  |  |  |
| Total net sales (4) | $ | 111,439 |  |  | $ | 91,819 |  |  |  |  |  |
  (was, 2020-07-31, similarity 0.7629):
[0000320193-20-000062:note_history:40]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | June 27,2020 |  | June 29,2019 |  | June 27,2020 |  | June 29,2019 |
| iPhone (1) | $ | 26,418 |  |  | $ | 25,986 |  |  | $ | 111,337 |  |  | $ | 109,019 |  |
| Mac (1) | 7,079 |  |  | 5,820 |  |  | 19,590 |  |  | 18,749 |  |
| iPad (1) | 6,582 |  |  | 5,023 |  |  | 16,927 |  |  | 16,624 |  |
| Wearables, Home and Accessories (1)(2) | 6,450 |  |  | 5,525 |  |  | 22,744 |  |  | 17,962 |  |
| Services (3) | 13,156 |  |  | 11,455 |  |  | 39,219 |  |  | 33,780 |  |
| Total net sales (4) | $ | 59,685 |  |  | $ | 53,809 |  |  | $ | 209,817 |  |  | $ | 196,134 |  |

- changed (2021-01-28):
[0000320193-21-000010:note_history:41]
(3)Services net sales include sales from the Company’s advertising, AppleCare®, digital content and other services. Services net sales also include amortization of the deferred value of Maps, Siri, and free iCloud storage and Apple TV+SM services, which are bundled in the sales price of certain products.
  (was, 2020-07-31, similarity 0.8732):
[0000320193-20-000062:note_history:41]
(3)Services net sales include sales from the Company’s digital content stores and streaming services, AppleCare®, Advertising and other services. Services net sales also include amortization of the deferred value of Maps, Siri, and free iCloud storage and Apple TV + services, which are bundled in the sales price of certain products.

- added (2021-01-28):
[0000320193-21-000010:note_history:42]
(4)Includes $2.5 billion of revenue recognized in the three months ended December 26, 2020 that was included in deferred revenue as of September 26, 2020 and $1.9 billion of revenue recognized in the three months ended December 28, 2019 that was included in deferred revenue as of September 28, 2019.

- removed (2021-01-28):
[0000320193-20-000062:note_history:43]
(4)Includes $2.1 billion of revenue recognized in the three months ended June 27, 2020 that was included in deferred revenue as of March 28, 2020, $2.0 billion of revenue recognized in the three months ended June 29, 2019 that was included in deferred revenue as of March 30, 2019, $4.0 billion of revenue recognized in the nine months ended June 27, 2020 that was included in deferred revenue as of September 28, 2019, and $4.9 billion of revenue recognized in the nine months ended June 29, 2019 that was included in deferred revenue as of September 29, 2018.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-01-28):
[0000320193-21-000010:note_history:44]
For arrangements with multiple performance obligations, which represent promises within an arrangement that are distinct, the Company allocates revenue to all distinct performance obligations based on their relative stand-alone selling prices (“SSPs”). When available, the Company uses observable prices to determine SSPs. When observable prices are not available, SSPs are established that reflect the Company’s best estimates of what the selling prices of the performance obligations would be if they were sold regularly on a stand-alone basis. The Company’s process for estimating SSPs without observable prices considers multiple factors that may vary depending upon the unique facts and circumstances related to each performance obligation including, where applicable, prices charged by the Company for similar offerings, market trends in the pricing for similar offerings, product-specific business objectives and the estimated cost to provide the performance obligation.
  (was, 2020-07-31, similarity 0.9914):
[0000320193-20-000062:note_history:44]
For arrangements with multiple performance obligations, which represent promises within an arrangement that are capable of being distinct, the Company allocates revenue to all distinct performance obligations based on their relative stand-alone selling prices (“SSPs”). When available, the Company uses observable prices to determine SSPs. When observable prices are not available, SSPs are established that reflect the Company’s best estimates of what the selling prices of the performance obligations would be if they were sold regularly on a stand-alone basis. The Company’s process for estimating SSPs without observable prices considers multiple factors that may vary depending upon the unique facts and circumstances related to each performance obligation including, where applicable, prices charged by the Company for similar offerings, market trends in the pricing for similar offerings, product-specific business objectives and the estimated cost to provide the performance obligation.

- changed (2021-01-28):
[0000320193-21-000010:note_history:45]
For the sale of third-party products where the Company obtains control of the product before transferring it to the customer, the Company recognizes revenue based on the gross amount billed to customers. The Company considers multiple factors when determining whether it obtains control of third-party products including, but not limited to, evaluating if it can establish the price of the product, retains inventory risk for tangible products or has the responsibility for ensuring acceptability of the product. For third-party applications sold through the App Store® and certain digital content sold through the Company’s other digital content stores, the Company does not obtain control of the product before transferring it to the customer. Therefore, the Company accounts for such sales on a net basis by recognizing in Services net sales only the commission it retains.
  (was, 2020-07-31, similarity 0.9728):
[0000320193-20-000062:note_history:45]
For the sale of third-party products where the Company obtains control of the product before transferring it to the customer, the Company recognizes revenue based on the gross amount billed to customers. The Company considers multiple factors when determining whether it obtains control of third-party products including, but not limited to, evaluating if it can establish the price of the product, retains inventory risk for tangible products or has the responsibility for ensuring acceptability of the product. For third-party applications sold through the App Store®, Mac App Store, TV App Store and Watch App Store and certain digital content sold through the Company’s other digital content stores, the Company does not obtain control of the product before transferring it to the customer. Therefore, the Company accounts for such sales on a net basis by recognizing in Services net sales only the commission it retains.

- added (2021-01-28):
[0000320193-21-000010:note_history:46]
As of December 26, 2020 and September 26, 2020, the Company had total deferred revenue of $11.6 billion and $10.2 billion, respectively. As of December 26, 2020, the Company expects 64% of total deferred revenue to be realized in less than a year, 26% within one-to-two years, 8% within two-to-three years and 2% in greater than three years.

- changed (2021-01-28):
[0000320193-21-000010:note_history:47]
Net sales disaggregated by significant products and services for the three months ended December 26, 2020 and December 28, 2019 were as follows (in millions):
  (was, 2020-07-31, similarity 0.8787):
[0000320193-20-000062:note_history:47]
Net sales disaggregated by significant products and services for the three- and nine-month periods ended June 27, 2020 and June 29, 2019 were as follows (in millions):

- changed (2021-01-28):
[0000320193-21-000010:note_history:48]
|  | Three Months Ended |  |  |
|  | December 26,2020 |  | December 28,2019 |  |  |  |  |
| iPhone (1) | $ | 65,597 |  |  | $ | 55,957 |  |  |  |  |  |
| Mac (1) | 8,675 |  |  | 7,160 |  |  |  |  |  |
| iPad (1) | 8,435 |  |  | 5,977 |  |  |  |  |  |
| Wearables, Home and Accessories (1)(2) | 12,971 |  |  | 10,010 |  |  |  |  |  |
| Services (3) | 15,761 |  |  | 12,715 |  |  |  |  |  |
| Total net sales (4) | $ | 111,439 |  |  | $ | 91,819 |  |  |  |  |  |
  (was, 2020-07-31, similarity 0.7629):
[0000320193-20-000062:note_history:48]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | June 27,2020 |  | June 29,2019 |  | June 27,2020 |  | June 29,2019 |
| iPhone (1) | $ | 26,418 |  |  | $ | 25,986 |  |  | $ | 111,337 |  |  | $ | 109,019 |  |
| Mac (1) | 7,079 |  |  | 5,820 |  |  | 19,590 |  |  | 18,749 |  |
| iPad (1) | 6,582 |  |  | 5,023 |  |  | 16,927 |  |  | 16,624 |  |
| Wearables, Home and Accessories (1)(2) | 6,450 |  |  | 5,525 |  |  | 22,744 |  |  | 17,962 |  |
| Services (3) | 13,156 |  |  | 11,455 |  |  | 39,219 |  |  | 33,780 |  |
| Total net sales (4) | $ | 59,685 |  |  | $ | 53,809 |  |  | $ | 209,817 |  |  | $ | 196,134 |  |

- changed (2021-01-28):
[0000320193-21-000010:note_history:49]
(3)Services net sales include sales from the Company’s advertising, AppleCare®, digital content and other services. Services net sales also include amortization of the deferred value of Maps, Siri, and free iCloud storage and Apple TV+SM services, which are bundled in the sales price of certain products.
  (was, 2020-07-31, similarity 0.8732):
[0000320193-20-000062:note_history:49]
(3)Services net sales include sales from the Company’s digital content stores and streaming services, AppleCare®, Advertising and other services. Services net sales also include amortization of the deferred value of Maps, Siri, and free iCloud storage and Apple TV + services, which are bundled in the sales price of certain products.

- added (2021-01-28):
[0000320193-21-000010:note_history:50]
(4)Includes $2.5 billion of revenue recognized in the three months ended December 26, 2020 that was included in deferred revenue as of September 26, 2020 and $1.9 billion of revenue recognized in the three months ended December 28, 2019 that was included in deferred revenue as of September 28, 2019.

- changed (2021-01-28):
[0000320193-21-000010:note_history:51]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 11, “Segment Information and Geographic Data” for the three months ended December 26, 2020 and December 28, 2019.
  (was, 2020-07-31, similarity 0.7983):
[0000320193-20-000062:note_history:51]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 11, “Segment Information and Geographic Data” for the three- and nine-month periods ended June 27, 2020 and June 29, 2019.

- removed (2021-01-28):
[0000320193-20-000062:note_history:52]
As of June 27, 2020 and September 28, 2019, the Company had total deferred revenue of $9.8 billion and $8.1 billion, respectively. As of June 27, 2020, the Company expects 65% of total deferred revenue to be realized in less than a year, 26% within one-to-two years, 7% within two-to-three years and 2% in greater than three years.

- removed (2021-01-28):
[0000320193-20-000062:note_history:53]
(4)Includes $2.1 billion of revenue recognized in the three months ended June 27, 2020 that was included in deferred revenue as of March 28, 2020, $2.0 billion of revenue recognized in the three months ended June 29, 2019 that was included in deferred revenue as of March 30, 2019, $4.0 billion of revenue recognized in the nine months ended June 27, 2020 that was included in deferred revenue as of September 28, 2019, and $4.9 billion of revenue recognized in the nine months ended June 29, 2019 that was included in deferred revenue as of September 29, 2018.


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-01-28):
[0000320193-21-000010:note_history:54]
For arrangements with multiple performance obligations, which represent promises within an arrangement that are distinct, the Company allocates revenue to all distinct performance obligations based on their relative stand-alone selling prices (“SSPs”). When available, the Company uses observable prices to determine SSPs. When observable prices are not available, SSPs are established that reflect the Company’s best estimates of what the selling prices of the performance obligations would be if they were sold regularly on a stand-alone basis. The Company’s process for estimating SSPs without observable prices considers multiple factors that may vary depending upon the unique facts and circumstances related to each performance obligation including, where applicable, prices charged by the Company for similar offerings, market trends in the pricing for similar offerings, product-specific business objectives and the estimated cost to provide the performance obligation.
  (was, 2020-07-31, similarity 0.9914):
[0000320193-20-000062:note_history:54]
For arrangements with multiple performance obligations, which represent promises within an arrangement that are capable of being distinct, the Company allocates revenue to all distinct performance obligations based on their relative stand-alone selling prices (“SSPs”). When available, the Company uses observable prices to determine SSPs. When observable prices are not available, SSPs are established that reflect the Company’s best estimates of what the selling prices of the performance obligations would be if they were sold regularly on a stand-alone basis. The Company’s process for estimating SSPs without observable prices considers multiple factors that may vary depending upon the unique facts and circumstances related to each performance obligation including, where applicable, prices charged by the Company for similar offerings, market trends in the pricing for similar offerings, product-specific business objectives and the estimated cost to provide the performance obligation.

- changed (2021-01-28):
[0000320193-21-000010:note_history:55]
For the sale of third-party products where the Company obtains control of the product before transferring it to the customer, the Company recognizes revenue based on the gross amount billed to customers. The Company considers multiple factors when determining whether it obtains control of third-party products including, but not limited to, evaluating if it can establish the price of the product, retains inventory risk for tangible products or has the responsibility for ensuring acceptability of the product. For third-party applications sold through the App Store® and certain digital content sold through the Company’s other digital content stores, the Company does not obtain control of the product before transferring it to the customer. Therefore, the Company accounts for such sales on a net basis by recognizing in Services net sales only the commission it retains.
  (was, 2020-07-31, similarity 0.9728):
[0000320193-20-000062:note_history:55]
For the sale of third-party products where the Company obtains control of the product before transferring it to the customer, the Company recognizes revenue based on the gross amount billed to customers. The Company considers multiple factors when determining whether it obtains control of third-party products including, but not limited to, evaluating if it can establish the price of the product, retains inventory risk for tangible products or has the responsibility for ensuring acceptability of the product. For third-party applications sold through the App Store®, Mac App Store, TV App Store and Watch App Store and certain digital content sold through the Company’s other digital content stores, the Company does not obtain control of the product before transferring it to the customer. Therefore, the Company accounts for such sales on a net basis by recognizing in Services net sales only the commission it retains.
