# AAPL MD&A — 0000320193-21-000010


## mdna

[0000320193-21-000010:mdna:1]
Item 2.    Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000320193-21-000010:mdna:2]
Unless otherwise stated, all information presented herein is based on the Company’s fiscal calendar, and references to particular years, quarters, months or periods refer to the Company’s fiscal years ended in September and the associated quarters, months and periods of those fiscal years. Each of the terms the “Company” and “Apple” as used herein refers collectively to Apple Inc. and its wholly owned subsidiaries, unless otherwise stated.

[0000320193-21-000010:mdna:3]
The following discussion should be read in conjunction with the 2020 Form 10-K filed with the U.S. Securities and Exchange Commission (the “SEC”) and the condensed consolidated financial statements and accompanying notes included in Part I, Item 1 of this Form 10-Q.

[0000320193-21-000010:mdna:4]
[same as prior period, unchanged from 0000320193-20-000062:mdna:2]

[0000320193-21-000010:mdna:5]
[same as prior period, unchanged from 0000320193-20-000062:mdna:3]

[0000320193-21-000010:mdna:6]
[same as prior period, unchanged from 0000320193-20-000062:mdna:4]

[0000320193-21-000010:mdna:7]
[same as prior period, unchanged from 0000320193-20-000062:mdna:5]

[0000320193-21-000010:mdna:8]
[same as prior period, unchanged from 0000320193-20-000062:mdna:6]

[0000320193-21-000010:mdna:9]
[same as prior period, unchanged from 0000320193-20-000062:mdna:7]

[0000320193-21-000010:mdna:10]
The COVID-19 pandemic has prompted governments and businesses to take unprecedented measures, such as restrictions on travel and business operations, temporary closures of businesses, and quarantines and shelter-in-place orders. The COVID-19 pandemic has significantly curtailed global economic activity and caused significant volatility and disruption in global financial markets. The COVID-19 pandemic and the measures taken by many countries in response have affected and could in the future materially impact the Company’s business, results of operations, financial condition and stock price.

[0000320193-21-000010:mdna:11]
During the first quarter of 2021, aspects of the Company’s business continued to be affected by the COVID-19 pandemic, with many of the Company’s retail stores, as well as channel partner points of sale, temporarily closed at various times, and the vast majority of the Company’s employees working remotely. The Company has reopened some of its offices and retail stores, subject to operating restrictions to protect public health and the health and safety of employees and customers, and it continues to work on safely reopening the remainder of its offices and retail stores, subject to local rules and regulations.

[0000320193-21-000010:mdna:12]
The full extent of the future impact of the COVID-19 pandemic on the Company’s operational and financial performance is currently uncertain and will depend on many factors outside the Company’s control, including, without limitation, the timing, extent, trajectory and duration of the pandemic; the availability, distribution and effectiveness of vaccines; the imposition of protective public safety measures; and the impact of the pandemic on the global economy and demand for consumer products. Refer to Part I, Item 1A of the 2020 Form 10-K under the heading “Risk Factors,” for more information.

[0000320193-21-000010:mdna:13]
[same as prior period, unchanged from 0000320193-20-000062:mdna:12]

[0000320193-21-000010:mdna:14]
First Quarter Fiscal 2021 Highlights

[0000320193-21-000010:mdna:15]
Total net sales increased 21% or $19.6 billion during the first quarter of 2021 compared to the same quarter in 2020, driven by higher net sales in all Products and Services categories. Additionally, net sales in all of the Company’s geographic reportable segments grew during the first quarter of 2021.

[0000320193-21-000010:mdna:16]
During the first quarter of 2021, the Company released the following products and services:

[0000320193-21-000010:mdna:17]
•iPhone 12, iPhone 12 mini, iPhone 12 Pro and iPhone 12 Pro Max, all with 5G technology;

[0000320193-21-000010:mdna:18]
•MacBook Air®, 13-inch MacBook Pro® and Mac mini®, all powered by M1, the Company’s first chip designed specifically for the Mac;

[0000320193-21-000010:mdna:19]
•An all-new iPad Air®;

[0000320193-21-000010:mdna:20]
•AirPods Max™, new over-ear wireless headphones, and HomePod mini™; and

[0000320193-21-000010:mdna:21]
•Apple Fitness+SM, a fitness subscription service.

[0000320193-21-000010:mdna:22]
The Company repurchased $24.0 billion of its common stock and paid dividends and dividend equivalents of $3.6 billion during the first quarter of 2021.

[0000320193-21-000010:mdna:23]
[same as prior period, unchanged from 0000320193-20-000062:mdna:17]

[0000320193-21-000010:mdna:24]
The following table shows net sales by category for the three months ended December 26, 2020 and December 28, 2019 (dollars in millions):

[0000320193-21-000010:mdna:25]
|  | Three Months Ended |  |  |
|  | December 26,2020 |  | December 28,2019 |  | Change |  |  |  |  |  |  |
| Net sales by category: |  |  |  |  |  |  |  |  |  |  |  |
| iPhone (1) | $ | 65,597 |  |  | $ | 55,957 |  |  | 17 | % |  |  |  |  |  |  |
| Mac (1) | 8,675 |  |  | 7,160 |  |  | 21 | % |  |  |  |  |  |  |
| iPad (1) | 8,435 |  |  | 5,977 |  |  | 41 | % |  |  |  |  |  |  |
| Wearables, Home and Accessories (1)(2) | 12,971 |  |  | 10,010 |  |  | 30 | % |  |  |  |  |  |  |
| Services (3) | 15,761 |  |  | 12,715 |  |  | 24 | % |  |  |  |  |  |  |
| Total net sales | $ | 111,439 |  |  | $ | 91,819 |  |  | 21 | % |  |  |  |  |  |  |

[0000320193-21-000010:mdna:26]
[same as prior period, unchanged from 0000320193-20-000062:mdna:20]

[0000320193-21-000010:mdna:27]
[same as prior period, unchanged from 0000320193-20-000062:mdna:21]

[0000320193-21-000010:mdna:28]
(3)Services net sales include sales from the Company’s advertising, AppleCare, digital content and other services. Services net sales also include amortization of the deferred value of Maps, Siri, and free iCloud storage and Apple TV+ services, which are bundled in the sales price of certain products.

[0000320193-21-000010:mdna:29]
[same as prior period, unchanged from 0000320193-20-000062:mdna:23]

[0000320193-21-000010:mdna:30]
iPhone net sales increased during the first quarter of 2021 compared to the same quarter in 2020 due primarily to higher net sales from the successful launch of the Company’s four new iPhone models and a favorable mix of iPhone sales.

[0000320193-21-000010:mdna:31]
[same as prior period, unchanged from 0000320193-20-000062:mdna:25]

[0000320193-21-000010:mdna:32]
Mac net sales increased during the first quarter of 2021 compared to the same quarter in 2020 due primarily to higher net sales of MacBook Air and MacBook Pro.

[0000320193-21-000010:mdna:33]
[same as prior period, unchanged from 0000320193-20-000062:mdna:27]

[0000320193-21-000010:mdna:34]
iPad net sales increased during the first quarter of 2021 compared to the same quarter in 2020 due primarily to higher net sales of iPad Air and iPad Pro®.

[0000320193-21-000010:mdna:35]
[same as prior period, unchanged from 0000320193-20-000062:mdna:29]

[0000320193-21-000010:mdna:36]
Wearables, Home and Accessories net sales increased during the first quarter of 2021 compared to the same quarter in 2020 due primarily to higher net sales of Apple Watch, accessories and AirPods.

[0000320193-21-000010:mdna:37]
[same as prior period, unchanged from 0000320193-20-000062:mdna:31]

[0000320193-21-000010:mdna:38]
Services net sales increased during the first quarter of 2021 compared to the same quarter in 2020 due primarily to higher net sales from the App Store, advertising and cloud services.

[0000320193-21-000010:mdna:39]
[same as prior period, unchanged from 0000320193-20-000062:mdna:33]

[0000320193-21-000010:mdna:40]
The Company manages its business primarily on a geographic basis. The Company’s reportable segments consist of the Americas, Europe, Greater China, Japan and Rest of Asia Pacific. Americas includes both North and South America. Europe includes European countries, as well as India, the Middle East and Africa. Greater China includes China mainland, Hong Kong and Taiwan. Rest of Asia Pacific includes Australia and those Asian countries not included in the Company’s other reportable segments. Although the reportable segments provide similar hardware and software products and similar services, each one is managed separately to better align with the location of the Company’s customers and distribution partners and the unique market dynamics of each geographic region. Further information regarding the Company’s reportable segments can be found in Part I, Item 1 of this Form 10-Q in the Notes to Condensed Consolidated Financial Statements in Note 11, “Segment Information and Geographic Data.”

[0000320193-21-000010:mdna:41]
The following table shows net sales by reportable segment for the three months ended December 26, 2020 and December 28, 2019 (dollars in millions):

[0000320193-21-000010:mdna:42]
|  | Three Months Ended |  |  |
|  | December 26,2020 |  | December 28,2019 |  | Change |  |  |  |  |  |  |
| Net sales by reportable segment: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 46,310 |  |  | $ | 41,367 |  |  | 12 | % |  |  |  |  |  |  |
| Europe | 27,306 |  |  | 23,273 |  |  | 17 | % |  |  |  |  |  |  |
| Greater China | 21,313 |  |  | 13,578 |  |  | 57 | % |  |  |  |  |  |  |
| Japan | 8,285 |  |  | 6,223 |  |  | 33 | % |  |  |  |  |  |  |
| Rest of Asia Pacific | 8,225 |  |  | 7,378 |  |  | 11 | % |  |  |  |  |  |  |
| Total net sales | $ | 111,439 |  |  | $ | 91,819 |  |  | 21 | % |  |  |  |  |  |  |

[0000320193-21-000010:mdna:43]
[same as prior period, unchanged from 0000320193-20-000062:mdna:37]

[0000320193-21-000010:mdna:44]
Americas net sales increased during the first quarter of 2021 compared to the same quarter in 2020 due primarily to higher net sales of Services, iPhone and Wearables, Home and Accessories.

[0000320193-21-000010:mdna:45]
[same as prior period, unchanged from 0000320193-20-000062:mdna:39]

[0000320193-21-000010:mdna:46]
Europe net sales increased during the first quarter of 2021 compared to the same quarter in 2020 due primarily to higher net sales of Wearables, Home and Accessories, iPhone and iPad.

[0000320193-21-000010:mdna:47]
[same as prior period, unchanged from 0000320193-20-000062:mdna:41]

[0000320193-21-000010:mdna:48]
Greater China net sales increased during the first quarter of 2021 compared to the same quarter in 2020 due primarily to higher net sales of iPhone, iPad and Wearables, Home and Accessories. The strength of the Chinese renminbi relative to the U.S. dollar had a favorable impact on Greater China net sales during the first quarter of 2021.

[0000320193-21-000010:mdna:49]
[same as prior period, unchanged from 0000320193-20-000062:mdna:43]

[0000320193-21-000010:mdna:50]
Japan net sales increased during the first quarter of 2021 compared to the same quarter in 2020 due primarily to higher net sales of iPhone, Services and iPad. The strength of the Japanese yen relative to the U.S. dollar had a favorable impact on Japan net sales during the first quarter of 2021.

[0000320193-21-000010:mdna:51]
[same as prior period, unchanged from 0000320193-20-000062:mdna:45]

[0000320193-21-000010:mdna:52]
Rest of Asia Pacific net sales increased during the first quarter of 2021 compared to the same quarter in 2020 due primarily to higher net sales of Services, iPad and Wearables, Home and Accessories. The movement of foreign currencies in the Rest of Asia Pacific relative to the U.S. dollar had a net favorable impact on net sales during the first quarter of 2021.

[0000320193-21-000010:mdna:53]
[same as prior period, unchanged from 0000320193-20-000062:mdna:47]

[0000320193-21-000010:mdna:54]
Products and Services gross margin and gross margin percentage for the three months ended December 26, 2020 and December 28, 2019 were as follows (dollars in millions):

[0000320193-21-000010:mdna:55]
|  | Three Months Ended |  |  |
|  | December 26,2020 |  | December 28,2019 |  |  |  |  |
| Gross margin: |  |  |  |  |  |  |  |
| Products | $ | 33,548 |  |  | $ | 27,029 |  |  |  |  |  |
| Services | 10,780 |  |  | 8,188 |  |  |  |  |  |
| Total gross margin | $ | 44,328 |  |  | $ | 35,217 |  |  |  |  |  |

[0000320193-21-000010:mdna:56]
| Gross margin percentage: |  |  |  |  |  |  |  |
| Products | 35.1 | % |  | 34.2 | % |  |  |  |  |
| Services | 68.4 | % |  | 64.4 | % |  |  |  |  |
| Total gross margin percentage | 39.8 | % |  | 38.4 | % |  |  |  |  |

[0000320193-21-000010:mdna:57]
[same as prior period, unchanged from 0000320193-20-000062:mdna:51]

[0000320193-21-000010:mdna:58]
Products gross margin increased during the first quarter of 2021 compared to the same quarter in 2020 due primarily to higher Products volume and a different Products mix. Products gross margin percentage increased during the first quarter of 2021 compared to the same quarter in 2020 due primarily to higher leverage.

[0000320193-21-000010:mdna:59]
[same as prior period, unchanged from 0000320193-20-000062:mdna:54]

[0000320193-21-000010:mdna:60]
Services gross margin increased during the first quarter of 2021 compared to the same quarter in 2020 due primarily to higher Services net sales and a different Services mix. Services gross margin percentage increased during the first quarter of 2021 compared to the same quarter in 2020 due primarily to a different Services mix and higher leverage, partially offset by higher Services costs.

[0000320193-21-000010:mdna:61]
The Company’s future gross margins can be impacted by a variety of factors, as discussed in Part I, Item 1A of the 2020 Form 10-K under the heading “Risk Factors.” As a result, the Company believes, in general, gross margins will be subject to volatility and remain under downward pressure.

[0000320193-21-000010:mdna:62]
[same as prior period, unchanged from 0000320193-20-000062:mdna:57]

[0000320193-21-000010:mdna:63]
Operating expenses for the three months ended December 26, 2020 and December 28, 2019 were as follows (dollars in millions):

[0000320193-21-000010:mdna:64]
|  | Three Months Ended |  |  |
|  | December 26,2020 |  | December 28,2019 |  |  |  |  |
| Research and development | $ | 5,163 |  |  | $ | 4,451 |  |  |  |  |  |
| Percentage of total net sales | 5 | % |  | 5 | % |  |  |  |  |
| Selling, general and administrative | $ | 5,631 |  |  | $ | 5,197 |  |  |  |  |  |
| Percentage of total net sales | 5 | % |  | 6 | % |  |  |  |  |
| Total operating expenses | $ | 10,794 |  |  | $ | 9,648 |  |  |  |  |  |
| Percentage of total net sales | 10 | % |  | 11 | % |  |  |  |  |

[0000320193-21-000010:mdna:65]
[same as prior period, unchanged from 0000320193-20-000062:mdna:60]

[0000320193-21-000010:mdna:66]
The growth in research and development (“R&D”) expense during the first quarter of 2021 compared to the same quarter in 2020 was driven primarily by increases in headcount-related expenses. The Company continues to believe that focused investments in R&D are critical to its future growth and competitive position in the marketplace, and to the development of new and updated products and services that are central to the Company’s core business strategy.

[0000320193-21-000010:mdna:67]
[same as prior period, unchanged from 0000320193-20-000062:mdna:62]

[0000320193-21-000010:mdna:68]
The growth in selling, general and administrative expense during the first quarter of 2021 compared to the same quarter in 2020 was driven primarily by increases in headcount-related expenses and higher variable selling expenses.

[0000320193-21-000010:mdna:69]
[same as prior period, unchanged from 0000320193-20-000062:mdna:64]

[0000320193-21-000010:mdna:70]
Other income/(expense), net (“OI&E”) for the three months ended December 26, 2020 and December 28, 2019 was as follows (dollars in millions):

[0000320193-21-000010:mdna:71]
|  | Three Months Ended |  |  |
|  | December 26,2020 |  | December 28,2019 |  | Change |  |  |  |  |  |  |
| Interest and dividend income | $ | 747 |  |  | $ | 1,045 |  |  |  |  |  |  |  |  |  |
| Interest expense | (638) |  |  | (785) |  |  |  |  |  |  |  |  |  |
| Other income/(expense), net | (64) |  |  | 89 |  |  |  |  |  |  |  |  |  |
| Total other income/(expense), net | $ | 45 |  |  | $ | 349 |  |  | (87) | % |  |  |  |  |  |  |

[0000320193-21-000010:mdna:72]
OI&E decreased during the first quarter of 2021 compared to the same quarter in 2020 due primarily to lower interest income and an adjustment to the carrying value of a non-marketable security, partially offset by lower interest expense. The weighted-average interest rate earned by the Company on its cash, cash equivalents and marketable securities was 1.49% and 2.08% in the first quarter of 2021 and 2020, respectively.

[0000320193-21-000010:mdna:73]
[same as prior period, unchanged from 0000320193-20-000062:mdna:68]

[0000320193-21-000010:mdna:74]
Provision for income taxes, effective tax rate and statutory federal income tax rate for the three months ended December 26, 2020 and December 28, 2019 were as follows (dollars in millions):

[0000320193-21-000010:mdna:75]
|  | Three Months Ended |  |  |
|  | December 26,2020 |  | December 28,2019 |  |  |  |  |
| Provision for income taxes | $ | 4,824 |  |  | $ | 3,682 |  |  |  |  |  |
| Effective tax rate | 14.4 | % |  | 14.2 | % |  |  |  |  |
| Statutory federal income tax rate | 21 | % |  | 21 | % |  |  |  |  |

[0000320193-21-000010:mdna:76]
The Company’s effective tax rate for the first quarter of 2021 was lower than the statutory federal income tax rate due primarily to lower tax rates on foreign earnings and tax benefits from share-based compensation.

[0000320193-21-000010:mdna:77]
The Company’s effective tax rate for the first quarter of 2021 was relatively flat compared to the same quarter in 2020.

[0000320193-21-000010:mdna:78]
[same as prior period, unchanged from 0000320193-20-000062:mdna:76]

[0000320193-21-000010:mdna:79]
The following tables present selected financial information and statistics as of December 26, 2020 and September 26, 2020 and for the first three months of 2021 and 2020 (in millions):

[0000320193-21-000010:mdna:80]
|  | December 26,2020 |  | September 26,2020 |
| Cash, cash equivalents and marketable securities (1) | $ | 195,571 |  |  | $ | 191,830 |  |
| Property, plant and equipment, net | $ | 37,933 |  |  | $ | 36,766 |  |
| Commercial paper | $ | 5,000 |  |  | $ | 4,996 |  |
| Total term debt | $ | 107,043 |  |  | $ | 107,440 |  |
| Working capital | $ | 21,599 |  |  | $ | 38,321 |  |

[0000320193-21-000010:mdna:81]
|  | Three Months Ended |
|  | December 26,2020 |  | December 28,2019 |
| Cash generated by operating activities | $ | 38,763 |  |  | $ | 30,516 |  |
| Cash used in investing activities | $ | (8,584) |  |  | $ | (13,668) |  |
| Cash used in financing activities | $ | (32,249) |  |  | $ | (25,407) |  |

[0000320193-21-000010:mdna:82]
(1)As of December 26, 2020 and September 26, 2020, total marketable securities included $19.5 billion and $18.6 billion, respectively, that was restricted from general use, related to the State Aid Decision (refer to Note 5, “Income Taxes” in the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Form 10-Q) and other agreements.

[0000320193-21-000010:mdna:83]
[same as prior period, unchanged from 0000320193-20-000062:mdna:81]

[0000320193-21-000010:mdna:84]
In connection with the State Aid Decision, as of December 26, 2020, the adjusted recovery amount of €12.9 billion plus interest of €1.2 billion was funded into escrow, where it will remain restricted from general use pending the conclusion of all legal proceedings. Further information regarding the State Aid Decision can be found in Part I, Item 1 of this Form 10-Q in the Notes to Condensed Consolidated Financial Statements in Note 5, “Income Taxes.”

[0000320193-21-000010:mdna:85]
[same as prior period, unchanged from 0000320193-20-000062:mdna:83]

[0000320193-21-000010:mdna:86]
During the three months ended December 26, 2020, cash generated by operating activities of $38.8 billion was a result of $28.8 billion of net income, non-cash adjustments to net income of $4.7 billion and an increase in the net change in operating assets and liabilities of $5.4 billion. Cash used in investing activities of $8.6 billion during the three months ended December 26, 2020 consisted primarily of cash used for purchases of marketable securities, net of maturities and sales, of $5.3 billion and cash used to acquire property, plant and equipment of $3.5 billion. Cash used in financing activities of $32.2 billion during the three months ended December 26, 2020 consisted primarily of cash used to repurchase common stock of $24.8 billion, cash used to pay dividends and dividend equivalents of $3.6 billion, cash used for taxes related to net share settlement of equity awards of $2.9 billion, and cash used to repay term debt of $1.0 billion.

[0000320193-21-000010:mdna:87]
During the three months ended December 28, 2019, cash generated by operating activities of $30.5 billion was a result of $22.2 billion of net income, non-cash adjustments to net income of $4.0 billion and an increase in the net change in operating assets and liabilities of $4.2 billion. Cash used in investing activities of $13.7 billion during the three months ended December 28, 2019 consisted primarily of cash used for purchases of marketable securities, net of sales and maturities, of $10.4 billion and cash used to acquire property, plant and equipment of $2.1 billion. Cash used in financing activities of $25.4 billion during the three months ended December 28, 2019 consisted primarily of cash used to repurchase common stock of $20.7 billion, cash used to pay dividends and dividend equivalents of $3.5 billion and cash used to repay term debt of $1.0 billion, partially offset by net proceeds from the issuance of term debt of $2.2 billion.

[0000320193-21-000010:mdna:88]
[same as prior period, unchanged from 0000320193-20-000062:mdna:86]

[0000320193-21-000010:mdna:89]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses the net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of December 26, 2020, the Company had $5.0 billion of Commercial Paper outstanding, with a weighted-average interest rate of 0.10% and maturities generally less than nine months.

[0000320193-21-000010:mdna:90]
As of December 26, 2020, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $105.9 billion (collectively the “Notes”). During the first three months of 2021, the Company repaid $1.0 billion of Notes. The Company has entered, and in the future may enter, into interest rate swaps to manage interest rate risk on the Notes. In addition, the Company has entered, and in the future may enter, into foreign currency swaps to manage foreign currency risk on the Notes.

[0000320193-21-000010:mdna:91]
[same as prior period, unchanged from 0000320193-20-000062:mdna:90]

[0000320193-21-000010:mdna:92]
[same as prior period, unchanged from 0000320193-20-000062:mdna:91]

[0000320193-21-000010:mdna:93]
As of December 26, 2020, the Company was authorized to purchase up to $225 billion of the Company’s common stock under a share repurchase program, of which $192.6 billion had been utilized. During the three months ended December 26, 2020, the Company repurchased 200 million shares of its common stock for $24.0 billion. The Company’s share repurchase program does not obligate it to acquire any specific number of shares. Under this program, shares may be repurchased in privately negotiated and/or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).

[0000320193-21-000010:mdna:94]
As of December 26, 2020, the Company’s quarterly cash dividend was $0.205 per share. The Company intends to increase its dividend on an annual basis, subject to declaration by the Board of Directors.

[0000320193-21-000010:mdna:95]
[same as prior period, unchanged from 0000320193-20-000062:mdna:96]

[0000320193-21-000010:mdna:96]
[same as prior period, unchanged from 0000320193-20-000062:mdna:97]

[0000320193-21-000010:mdna:97]
The Company has lease arrangements for certain equipment and facilities, including retail, corporate, manufacturing and data center space. The Company’s retail store and other facility leases typically have original terms not exceeding 10 years and generally contain multi-year renewal options. The Company’s total fixed lease payment obligation of $13.0 billion as of December 26, 2020 included future payments under leases that had commenced as of December 26, 2020, and were therefore recorded on the Company’s Condensed Consolidated Balance Sheet, as well as leases that had been signed but not yet commenced as of December 26, 2020.

[0000320193-21-000010:mdna:98]
[same as prior period, unchanged from 0000320193-20-000062:mdna:99]

[0000320193-21-000010:mdna:99]
The Company utilizes several outsourcing partners to manufacture sub-assemblies for the Company’s products and to perform final assembly and testing of finished products. These outsourcing partners acquire components and build product based on demand information supplied by the Company, which typically covers periods up to 150 days. The Company also obtains individual components for its products from a wide variety of individual suppliers. As of December 26, 2020, the Company expects to pay $45.8 billion under manufacturing-related supplier arrangements, which are primarily noncancelable.

[0000320193-21-000010:mdna:100]
[same as prior period, unchanged from 0000320193-20-000062:mdna:101]

[0000320193-21-000010:mdna:101]
The Company’s other purchase obligations primarily consist of noncancelable obligations to acquire capital assets, including product tooling and manufacturing process equipment, and noncancelable obligations related to advertising, content creation and Internet and telecommunications services. As of December 26, 2020, the Company had other purchase obligations of $7.8 billion.

[0000320193-21-000010:mdna:102]
[same as prior period, unchanged from 0000320193-20-000062:mdna:103]

[0000320193-21-000010:mdna:103]
As of December 26, 2020, the balance of the deemed repatriation tax payable imposed by the U.S. Tax Cuts and Jobs Act (the “Act”) was $29.9 billion, of which $28.1 billion was included in other non-current liabilities in the Company’s Condensed Consolidated Balance Sheet. The Company pays the deemed repatriation tax payable in installments in accordance with the Act.

[0000320193-21-000010:mdna:104]
[same as prior period, unchanged from 0000320193-20-000062:mdna:105]

[0000320193-21-000010:mdna:105]
[same as prior period, unchanged from 0000320193-20-000062:mdna:106]

[0000320193-21-000010:mdna:106]
[same as prior period, unchanged from 0000320193-20-000062:mdna:107]

[0000320193-21-000010:mdna:107]
[same as prior period, unchanged from 0000320193-20-000062:mdna:108]

[0000320193-21-000010:mdna:108]
Note 1, “Summary of Significant Accounting Policies” in Part I, Item 1 of this Form 10-Q and in the Notes to Consolidated Financial Statements in Part II, Item 8 of the 2020 Form 10-K, and “Critical Accounting Policies and Estimates” in Part II, Item 7 of the 2020 Form 10-K describe the significant accounting policies and methods used in the preparation of the Company’s condensed consolidated financial statements. There have been no material changes to the Company’s critical accounting policies and estimates since the 2020 Form 10-K.
