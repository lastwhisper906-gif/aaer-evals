# AAPL notes — 0000320193-21-000010


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000320193-21-000010:notes:1]
[same as prior period, unchanged from 0000320193-20-000062:notes:1]

[0000320193-21-000010:notes:2]
The condensed consolidated financial statements include the accounts of Apple Inc. and its wholly owned subsidiaries (collectively “Apple” or the “Company”). Intercompany accounts and transactions have been eliminated. In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements and accompanying notes in conformity with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported. Actual results could differ materially from those estimates. Certain prior period amounts in the consolidated financial statements and accompanying notes have been reclassified to conform to the current period’s presentation. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company’s annual consolidated financial statements and accompanying notes included in its Annual Report on Form 10-K for the fiscal year ended September 26, 2020 (the “2020 Form 10-K”).

[0000320193-21-000010:notes:3]
The Company’s fiscal year is the 52- or 53-week period that ends on the last Saturday of September. An additional week is included in the first fiscal quarter every five or six years to realign the Company’s fiscal quarters with calendar quarters. The Company’s fiscal years 2021 and 2020 span 52 weeks each. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in September and the associated quarters, months and periods of those fiscal years.

[0000320193-21-000010:notes:4]
Common Stock Split

[0000320193-21-000010:notes:5]
On August 28, 2020, the Company effected a four-for-one stock split to shareholders of record as of August 24, 2020. All share, restricted stock unit (“RSU”) and per share or per RSU information has been retroactively adjusted to reflect the stock split.

[0000320193-21-000010:notes:6]
Recently Adopted Accounting Pronouncements

[0000320193-21-000010:notes:7]
Financial Instruments – Credit Losses

[0000320193-21-000010:notes:8]
At the beginning of the first quarter of 2021, the Company adopted the Financial Accounting Standards Board’s Accounting Standards Update No. 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (“ASU 2016-13”), which modifies the measurement of expected credit losses on certain financial instruments. The Company adopted ASU 2016-13 utilizing the modified retrospective transition method. The adoption of ASU 2016-13 did not have a material impact on the Company’s condensed consolidated financial statements.

[0000320193-21-000010:notes:9]
[same as prior period, unchanged from 0000320193-20-000062:notes:9]

[0000320193-21-000010:notes:10]
The following table shows the computation of basic and diluted earnings per share for the three months ended December 26, 2020 and December 28, 2019 (net income in millions and shares in thousands):

[0000320193-21-000010:notes:11]
|  | Three Months Ended |  |  |
|  | December 26,2020 |  | December 28,2019 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 28,755 |  |  | $ | 22,236 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 16,935,119 |  |  | 17,660,160 |  |  |  |  |  |
| Effect of dilutive securities | 178,569 |  |  | 158,257 |  |  |  |  |  |
| Weighted-average diluted shares | 17,113,688 |  |  | 17,818,417 |  |  |  |  |  |
| Basic earnings per share | $ | 1.70 |  |  | $ | 1.26 |  |  |  |  |  |
| Diluted earnings per share | $ | 1.68 |  |  | $ | 1.25 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000320193-21-000010:notes:12]
[same as prior period, unchanged from 0000320193-20-000062:notes:13]

[0000320193-21-000010:notes:13]
[same as prior period, unchanged from 0000320193-20-000062:notes:14]

[0000320193-21-000010:notes:14]
For arrangements with multiple performance obligations, which represent promises within an arrangement that are distinct, the Company allocates revenue to all distinct performance obligations based on their relative stand-alone selling prices (“SSPs”). When available, the Company uses observable prices to determine SSPs. When observable prices are not available, SSPs are established that reflect the Company’s best estimates of what the selling prices of the performance obligations would be if they were sold regularly on a stand-alone basis. The Company’s process for estimating SSPs without observable prices considers multiple factors that may vary depending upon the unique facts and circumstances related to each performance obligation including, where applicable, prices charged by the Company for similar offerings, market trends in the pricing for similar offerings, product-specific business objectives and the estimated cost to provide the performance obligation.

[0000320193-21-000010:notes:15]
[same as prior period, unchanged from 0000320193-20-000062:notes:16]

[0000320193-21-000010:notes:16]
[same as prior period, unchanged from 0000320193-20-000062:notes:17]

[0000320193-21-000010:notes:17]
For the sale of third-party products where the Company obtains control of the product before transferring it to the customer, the Company recognizes revenue based on the gross amount billed to customers. The Company considers multiple factors when determining whether it obtains control of third-party products including, but not limited to, evaluating if it can establish the price of the product, retains inventory risk for tangible products or has the responsibility for ensuring acceptability of the product. For third-party applications sold through the App Store® and certain digital content sold through the Company’s other digital content stores, the Company does not obtain control of the product before transferring it to the customer. Therefore, the Company accounts for such sales on a net basis by recognizing in Services net sales only the commission it retains.

[0000320193-21-000010:notes:18]
[same as prior period, unchanged from 0000320193-20-000062:notes:19]

[0000320193-21-000010:notes:19]
[same as prior period, unchanged from 0000320193-20-000062:notes:20]

[0000320193-21-000010:notes:20]
As of December 26, 2020 and September 26, 2020, the Company had total deferred revenue of $11.6 billion and $10.2 billion, respectively. As of December 26, 2020, the Company expects 64% of total deferred revenue to be realized in less than a year, 26% within one-to-two years, 8% within two-to-three years and 2% in greater than three years.

[0000320193-21-000010:notes:21]
[same as prior period, unchanged from 0000320193-20-000062:notes:22]

[0000320193-21-000010:notes:22]
Net sales disaggregated by significant products and services for the three months ended December 26, 2020 and December 28, 2019 were as follows (in millions):

[0000320193-21-000010:notes:23]
|  | Three Months Ended |  |  |
|  | December 26,2020 |  | December 28,2019 |  |  |  |  |
| iPhone (1) | $ | 65,597 |  |  | $ | 55,957 |  |  |  |  |  |
| Mac (1) | 8,675 |  |  | 7,160 |  |  |  |  |  |
| iPad (1) | 8,435 |  |  | 5,977 |  |  |  |  |  |
| Wearables, Home and Accessories (1)(2) | 12,971 |  |  | 10,010 |  |  |  |  |  |
| Services (3) | 15,761 |  |  | 12,715 |  |  |  |  |  |
| Total net sales (4) | $ | 111,439 |  |  | $ | 91,819 |  |  |  |  |  |

[0000320193-21-000010:notes:24]
[same as prior period, unchanged from 0000320193-20-000062:notes:25]

[0000320193-21-000010:notes:25]
[same as prior period, unchanged from 0000320193-20-000062:notes:26]

[0000320193-21-000010:notes:26]
(3)Services net sales include sales from the Company’s advertising, AppleCare®, digital content and other services. Services net sales also include amortization of the deferred value of Maps, Siri, and free iCloud storage and Apple TV+SM services, which are bundled in the sales price of certain products.

[0000320193-21-000010:notes:27]
(4)Includes $2.5 billion of revenue recognized in the three months ended December 26, 2020 that was included in deferred revenue as of September 26, 2020 and $1.9 billion of revenue recognized in the three months ended December 28, 2019 that was included in deferred revenue as of September 28, 2019.

[0000320193-21-000010:notes:28]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 11, “Segment Information and Geographic Data” for the three months ended December 26, 2020 and December 28, 2019.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000320193-21-000010:notes:29]
[same as prior period, unchanged from 0000320193-20-000062:notes:30]

[0000320193-21-000010:notes:30]
The following tables show the Company’s cash and marketable securities by significant investment category as of December 26, 2020 and September 26, 2020 (in millions):

[0000320193-21-000010:notes:31]
|  | December 26, 2020 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | CurrentMarketableSecurities |  | Non-CurrentMarketableSecurities |
| Cash | $ | 18,729 |  |  | $ | — |  |  | $ | — |  |  | $ | 18,729 |  |  | $ | 18,729 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): Money market funds | 6,312 |  |  | — |  |  | — |  |  | 6,312 |  |  | 6,312 |  |  | — |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 21,939 |  |  | 270 |  |  | (6) |  |  | 22,203 |  |  | 3,227 |  |  | 8,527 |  |  | 10,449 |  |
| U.S. agency securities | 8,698 |  |  | 9 |  |  | (1) |  |  | 8,706 |  |  | 1,000 |  |  | 3,319 |  |  | 4,387 |  |
| Non-U.S. government securities | 20,185 |  |  | 395 |  |  | (67) |  |  | 20,513 |  |  | 100 |  |  | 2,874 |  |  | 17,539 |  |
| Certificates of deposit and time deposits | 8,002 |  |  | — |  |  | — |  |  | 8,002 |  |  | 5,009 |  |  | 2,623 |  |  | 370 |  |
| Commercial paper | 8,620 |  |  | — |  |  | — |  |  | 8,620 |  |  | 1,632 |  |  | 6,988 |  |  | — |  |
| Corporate debt securities | 83,042 |  |  | 2,155 |  |  | (44) |  |  | 85,153 |  |  | 1 |  |  | 16,117 |  |  | 69,035 |  |
| Municipal securities | 1,004 |  |  | 20 |  |  | — |  |  | 1,024 |  |  | — |  |  | 94 |  |  | 930 |  |
| Mortgage- and asset-backed securities | 16,051 |  |  | 281 |  |  | (23) |  |  | 16,309 |  |  | — |  |  | 274 |  |  | 16,035 |  |
| Subtotal | 167,541 |  |  | 3,130 |  |  | (141) |  |  | 170,530 |  |  | 10,969 |  |  | 40,816 |  |  | 118,745 |  |
| Total (3) | $ | 192,582 |  |  | $ | 3,130 |  |  | $ | (141) |  |  | $ | 195,571 |  |  | $ | 36,010 |  |  | $ | 40,816 |  |  | $ | 118,745 |  |

[0000320193-21-000010:notes:32]
|  | September 26, 2020 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | CurrentMarketableSecurities |  | Non-CurrentMarketableSecurities |
| Cash | $ | 17,773 |  |  | $ | — |  |  | $ | — |  |  | $ | 17,773 |  |  | $ | 17,773 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): Money market funds | 2,171 |  |  | — |  |  | — |  |  | 2,171 |  |  | 2,171 |  |  | — |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 28,439 |  |  | 331 |  |  | — |  |  | 28,770 |  |  | 8,580 |  |  | 11,972 |  |  | 8,218 |  |
| U.S. agency securities | 8,604 |  |  | 8 |  |  | — |  |  | 8,612 |  |  | 2,009 |  |  | 3,078 |  |  | 3,525 |  |
| Non-U.S. government securities | 19,361 |  |  | 275 |  |  | (186) |  |  | 19,450 |  |  | 255 |  |  | 3,329 |  |  | 15,866 |  |
| Certificates of deposit and time deposits | 10,399 |  |  | — |  |  | — |  |  | 10,399 |  |  | 4,043 |  |  | 6,246 |  |  | 110 |  |
| Commercial paper | 11,226 |  |  | — |  |  | — |  |  | 11,226 |  |  | 3,185 |  |  | 8,041 |  |  | — |  |
| Corporate debt securities | 76,937 |  |  | 1,834 |  |  | (175) |  |  | 78,596 |  |  | — |  |  | 19,687 |  |  | 58,909 |  |
| Municipal securities | 1,001 |  |  | 22 |  |  | — |  |  | 1,023 |  |  | — |  |  | 139 |  |  | 884 |  |
| Mortgage- and asset-backed securities | 13,520 |  |  | 314 |  |  | (24) |  |  | 13,810 |  |  | — |  |  | 435 |  |  | 13,375 |  |
| Subtotal | 169,487 |  |  | 2,784 |  |  | (385) |  |  | 171,886 |  |  | 18,072 |  |  | 52,927 |  |  | 100,887 |  |
| Total (3) | $ | 189,431 |  |  | $ | 2,784 |  |  | $ | (385) |  |  | $ | 191,830 |  |  | $ | 38,016 |  |  | $ | 52,927 |  |  | $ | 100,887 |  |

[0000320193-21-000010:notes:33]
[same as prior period, unchanged from 0000320193-20-000062:notes:34]

[0000320193-21-000010:notes:34]
[same as prior period, unchanged from 0000320193-20-000062:notes:35]

[0000320193-21-000010:notes:35]
(3)As of December 26, 2020 and September 26, 2020, total marketable securities included $19.5 billion and $18.6 billion, respectively, that was restricted from general use, related to the State Aid Decision (refer to Note 5, “Income Taxes”) and other agreements.

[0000320193-21-000010:notes:36]
[same as prior period, unchanged from 0000320193-20-000062:notes:37]

[0000320193-21-000010:notes:37]
The Company typically invests in highly rated securities, with the primary objective of minimizing the potential risk of principal loss. The Company’s investment policy generally requires securities to be investment grade and limits the amount of credit exposure to any one issuer. Fair values were determined for each individual security in the investment portfolio.

[0000320193-21-000010:notes:38]
[same as prior period, unchanged from 0000320193-20-000062:notes:39]

[0000320193-21-000010:notes:39]
The Company holds non-marketable equity securities of certain privately held companies without readily determinable fair values. As of December 26, 2020 and September 26, 2020, the Company’s non-marketable equity securities had a carrying value of $2.5 billion and $2.8 billion, respectively.

[0000320193-21-000010:notes:40]
[same as prior period, unchanged from 0000320193-20-000062:notes:41]

[0000320193-21-000010:notes:41]
A reconciliation of the Company’s cash and cash equivalents in the Condensed Consolidated Balance Sheets to cash, cash equivalents and restricted cash in the Condensed Consolidated Statements of Cash Flows as of December 26, 2020 and September 26, 2020 is as follows (in millions):

[0000320193-21-000010:notes:42]
|  | December 26,2020 |  | September 26,2020 |
| Cash and cash equivalents | $ | 36,010 |  |  | $ | 38,016 |  |
| Restricted cash | 1,709 |  |  | 1,773 |  |
| Cash, cash equivalents and restricted cash | $ | 37,719 |  |  | $ | 39,789 |  |

[0000320193-21-000010:notes:43]
The Company’s restricted cash primarily consisted of cash to support the Company’s iPhone Upgrade Program. Substantially all of the Company’s restricted cash was included in other non-current assets in the Condensed Consolidated Balance Sheets.

[0000320193-21-000010:notes:44]
[same as prior period, unchanged from 0000320193-20-000062:notes:45]

[0000320193-21-000010:notes:45]
[same as prior period, unchanged from 0000320193-20-000062:notes:46]

[0000320193-21-000010:notes:46]
[same as prior period, unchanged from 0000320193-20-000062:notes:47]

[0000320193-21-000010:notes:47]
[same as prior period, unchanged from 0000320193-20-000062:notes:48]

[0000320193-21-000010:notes:48]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in foreign currency exchange rates, the Company may enter into forward contracts, cross-currency swaps or other instruments. These instruments may offset a portion of the foreign currency remeasurement gains or losses, or changes in fair value. The Company may designate these instruments as either cash flow or fair value hedges. As of December 26, 2020, the Company’s hedged term debt– and marketable securities–related foreign currency transactions are expected to be recognized within 22 years.

[0000320193-21-000010:notes:49]
[same as prior period, unchanged from 0000320193-20-000062:notes:50]

[0000320193-21-000010:notes:50]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in interest rates, the Company may enter into interest rate swaps, options or other instruments. These instruments may offset a portion of the changes in interest income or expense, or changes in fair value. The Company designates these instruments as either cash flow or fair value hedges. As of December 26, 2020, the Company’s hedged interest rate transactions are expected to be recognized within seven years.

[0000320193-21-000010:notes:51]
[same as prior period, unchanged from 0000320193-20-000062:notes:52]

[0000320193-21-000010:notes:52]
Cash flow hedge amounts that are included in the assessment of hedge effectiveness are deferred in accumulated other comprehensive income/(loss) (“AOCI”) until the hedged item is recognized in earnings. Deferred gains and losses associated with cash flow hedges of foreign currency revenue are recognized as a component of net sales in the same period as the related revenue is recognized, and deferred gains and losses related to cash flow hedges of inventory purchases are recognized as a component of cost of sales in the same period as the related costs are recognized. Deferred gains and losses associated with cash flow hedges of interest income or expense are recognized in other income/(expense), net (“OI&E”) in the same period as the related income or expense is recognized. For options designated as cash flow hedges, the time value is excluded from the assessment of hedge effectiveness and recognized in the financial statement line item to which the hedge relates on a straight-line basis over the life of the hedge. Changes in the fair value of amounts excluded from the assessment of hedge effectiveness are recognized in other comprehensive income/(loss) (“OCI”).

[0000320193-21-000010:notes:53]
[same as prior period, unchanged from 0000320193-20-000062:notes:54]

[0000320193-21-000010:notes:54]
[same as prior period, unchanged from 0000320193-20-000062:notes:55]

[0000320193-21-000010:notes:55]
[same as prior period, unchanged from 0000320193-20-000062:notes:56]

[0000320193-21-000010:notes:56]
[same as prior period, unchanged from 0000320193-20-000062:notes:57]

[0000320193-21-000010:notes:57]
Fair value hedge gains and losses related to amounts that are included in the assessment of hedge effectiveness are recognized in earnings along with a corresponding loss or gain related to the change in value of the hedged item in the same line in the Condensed Consolidated Statements of Operations. For foreign exchange forward contracts designated as fair value hedges, the forward carry component is excluded from the assessment of hedge effectiveness and recognized in OI&E on a straight-line basis over the life of the hedge. Amounts excluded from the effectiveness assessment of fair value hedges and recognized in OI&E were gains of $82 million and $128 million for the three months ended December 26, 2020 and December 28, 2019, respectively. Changes in the fair value of amounts excluded from the assessment of hedge effectiveness are recognized in OCI.

[0000320193-21-000010:notes:58]
[same as prior period, unchanged from 0000320193-20-000062:notes:59]

[0000320193-21-000010:notes:59]
[same as prior period, unchanged from 0000320193-20-000062:notes:60]

[0000320193-21-000010:notes:60]
The Company records all derivatives in the Condensed Consolidated Balance Sheets at fair value. The Company’s accounting treatment for these derivative instruments is based on its hedge designation. The following tables show the Company’s derivative instruments at gross fair value as of December 26, 2020 and September 26, 2020 (in millions):

[0000320193-21-000010:notes:61]
|  | December 26, 2020 |
|  | Fair Value ofDerivatives Designatedas Hedge Instruments |  | Fair Value ofDerivatives Not Designatedas Hedge Instruments |  | TotalFair Value |
| Derivative assets (1): |  |  |  |  |  |
| Foreign exchange contracts | $ | 524 |  |  | $ | 780 |  |  | $ | 1,304 |  |
| Interest rate contracts | $ | 1,443 |  |  | $ | — |  |  | $ | 1,443 |  |
| Derivative liabilities (2): |  |  |  |  |  |
| Foreign exchange contracts | $ | 2,332 |  |  | $ | 1,314 |  |  | $ | 3,646 |  |

[0000320193-21-000010:notes:62]
|  | September 26, 2020 |
|  | Fair Value ofDerivatives Designatedas Hedge Instruments |  | Fair Value ofDerivatives Not Designatedas Hedge Instruments |  | TotalFair Value |
| Derivative assets (1): |  |  |  |  |  |
| Foreign exchange contracts | $ | 749 |  |  | $ | 303 |  |  | $ | 1,052 |  |
| Interest rate contracts | $ | 1,557 |  |  | $ | — |  |  | $ | 1,557 |  |
| Derivative liabilities (2): |  |  |  |  |  |
| Foreign exchange contracts | $ | 1,561 |  |  | $ | 485 |  |  | $ | 2,046 |  |

[0000320193-21-000010:notes:63]
[same as prior period, unchanged from 0000320193-20-000062:notes:64]

[0000320193-21-000010:notes:64]
[same as prior period, unchanged from 0000320193-20-000062:notes:65]

[0000320193-21-000010:notes:65]
[same as prior period, unchanged from 0000320193-20-000062:notes:66]

[0000320193-21-000010:notes:66]
The following table shows the pre-tax gains and losses of the Company’s derivative and non-derivative instruments designated as cash flow and net investment hedges in OCI and the Condensed Consolidated Statements of Operations for the three months ended December 26, 2020 and December 28, 2019 (in millions):

[0000320193-21-000010:notes:67]
|  | Three Months Ended |  |  |
|  | December 26,2020 |  | December 28,2019 |  |  |  |  |
| Gains/(Losses) recognized in OCI – included in effectiveness assessment: |  |  |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | (191) |  |  | $ | 271 |  |  |  |  |  |
| Interest rate contracts | 54 |  |  | — |  |  |  |  |  |
| Total | $ | (137) |  |  | $ | 271 |  |  |  |  |  |
| Net investment hedges: |  |  |  |  |  |  |  |
| Foreign currency debt | $ | — |  |  | $ | 24 |  |  |  |  |  |
| Gains/(Losses) reclassified from AOCI into net income – included in effectiveness assessment: |  |  |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 314 |  |  | $ | 491 |  |  |  |  |  |
| Interest rate contracts | (3) |  |  | (2) |  |  |  |  |  |
| Total | $ | 311 |  |  | $ | 489 |  |  |  |  |  |

[0000320193-21-000010:notes:68]
Amounts excluded from the effectiveness assessment of the Company’s hedges and recognized in OCI were losses of $138 million and $89 million for the three months ended December 26, 2020 and December 28, 2019, respectively.

[0000320193-21-000010:notes:69]
The following tables show information about the Company’s derivative instruments designated as fair value hedges and the related hedged items for the three months ended December 26, 2020 and December 28, 2019 and as of December 26, 2020 and September 26, 2020 (in millions):

[0000320193-21-000010:notes:70]
|  | Three Months Ended |  |  |
|  | December 26,2020 |  | December 28,2019 |  |  |  |  |
| Gains/(Losses) on derivative instruments (1): |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | (753) |  |  | $ | (183) |  |  |  |  |  |
| Interest rate contracts | (167) |  |  | (162) |  |  |  |  |  |
| Total | $ | (920) |  |  | $ | (345) |  |  |  |  |  |
| Gains/(Losses) related to hedged items (1): |  |  |  |  |  |  |  |
| Marketable securities | $ | 752 |  |  | $ | 183 |  |  |  |  |  |
| Fixed-rate debt | 167 |  |  | 162 |  |  |  |  |  |
| Total | $ | 919 |  |  | $ | 345 |  |  |  |  |  |

[0000320193-21-000010:notes:71]
|  | December 26,2020 |  | September 26,2020 |
| Carrying amounts of hedged assets/(liabilities): |  |  |  |
| Marketable securities (2) | $ | 17,009 |  |  | $ | 16,270 |  |
| Fixed-rate debt (3) | $ | (20,866) |  |  | $ | (21,033) |  |
| Cumulative hedging adjustments included in the carrying amounts of hedged items: |  |  |  |
| Marketable securities carrying amount increases/(decreases) | $ | 956 |  |  | $ | 493 |  |
| Fixed-rate debt carrying amount (increases)/decreases | $ | (1,374) |  |  | $ | (1,541) |  |

[0000320193-21-000010:notes:72]
[same as prior period, unchanged from 0000320193-20-000062:notes:73]

[0000320193-21-000010:notes:73]
(2)The carrying amounts of marketable securities that are designated as hedged items in fair value hedges are included in current marketable securities and non-current marketable securities in the Condensed Consolidated Balance Sheets

[0000320193-21-000010:notes:74]
(3)The carrying amounts of fixed-rate debt instruments that are designated as hedged items in fair value hedges are included in current term debt and non-current term debt in the Condensed Consolidated Balance Sheets.

[0000320193-21-000010:notes:75]
The following table shows the notional amounts of the Company’s outstanding derivative instruments and credit risk amounts associated with outstanding or unsettled derivative instruments as of December 26, 2020 and September 26, 2020 (in millions):

[0000320193-21-000010:notes:76]
|  | December 26, 2020 |  | September 26, 2020 |
|  | NotionalAmount |  | Credit RiskAmount |  | NotionalAmount |  | Credit RiskAmount |
| Instruments designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 71,191 |  |  | $ | 524 |  |  | $ | 57,410 |  |  | $ | 749 |  |
| Interest rate contracts | $ | 20,900 |  |  | $ | 1,443 |  |  | $ | 20,700 |  |  | $ | 1,557 |  |
| Instruments not designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 123,267 |  |  | $ | 780 |  |  | $ | 88,636 |  |  | $ | 303 |  |

[0000320193-21-000010:notes:77]
[same as prior period, unchanged from 0000320193-20-000062:notes:78]

[0000320193-21-000010:notes:78]
The Company generally enters into master netting arrangements, which are designed to reduce credit risk by permitting net settlement of transactions with the same counterparty. To further limit credit risk, the Company generally enters into collateral security arrangements that provide for collateral to be received or posted when the net fair value of certain financial instruments fluctuates from contractually established thresholds. The Company presents its derivative assets and derivative liabilities at their gross fair values in its Condensed Consolidated Balance Sheets. As of December 26, 2020, the net cash collateral posted by the Company related to derivative instruments under its collateral security arrangements was $215 million. As of September 26, 2020, the net cash collateral received by the Company related to derivative instruments under its collateral security arrangements was $875 million. The Company includes gross collateral posted and received in other current assets and other current liabilities in the Condensed Consolidated Balance Sheets, respectively.

[0000320193-21-000010:notes:79]
Under master netting arrangements with the respective counterparties to the Company’s derivative contracts, the Company is allowed to net settle transactions with a single net amount payable by one party to the other. As of December 26, 2020 and September 26, 2020, the potential effects of these rights of set-off associated with the Company’s derivative contracts, including the effects of collateral, would be a reduction to both derivative assets and derivative liabilities of $3.5 billion and $2.8 billion, respectively, resulting in net derivative liabilities of $684 million and $312 million, respectively.

[0000320193-21-000010:notes:80]
[same as prior period, unchanged from 0000320193-20-000062:notes:81]

[0000320193-21-000010:notes:81]
[same as prior period, unchanged from 0000320193-20-000062:notes:82]

[0000320193-21-000010:notes:82]
[same as prior period, unchanged from 0000320193-20-000062:notes:83]

[0000320193-21-000010:notes:83]
As of both December 26, 2020 and September 26, 2020, the Company had no customers that individually represented 10% or more of total trade receivables. The Company’s cellular network carriers accounted for 41% of total trade receivables as of December 26, 2020.

[0000320193-21-000010:notes:84]
[same as prior period, unchanged from 0000320193-20-000062:notes:85]

[0000320193-21-000010:notes:85]
The Company has non-trade receivables from certain of its manufacturing vendors resulting from the sale of components to these vendors who manufacture sub-assemblies or assemble final products for the Company. The Company purchases these components directly from suppliers. As of December 26, 2020, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 61% and 14%. As of September 26, 2020, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 57%, and 11%.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000320193-21-000010:notes:86]
[same as prior period, unchanged from 0000320193-20-000062:notes:87]


## us-gaap:DerivativesPolicyTextBlock

[0000320193-21-000010:notes:87]
Net investment hedge amounts that are included in the assessment of hedge effectiveness are recorded in OCI as a part of the cumulative translation adjustment. For foreign exchange forward contracts designated as net investment hedges, the forward carry component is excluded from the assessment of hedge effectiveness and recognized in OCI on a straight-line basis over the life of the hedge. Changes in the fair value of amounts excluded from the assessment of hedge effectiveness are recognized in OCI.
Fair Value HedgesFair value hedge gains and losses related to amounts that are included in the assessment of hedge effectiveness are recognized in earnings along with a corresponding loss or gain related to the change in value of the hedged item in the same line in the Condensed Consolidated Statements of Operations. For foreign exchange forward contracts designated as fair value hedges, the forward carry component is excluded from the assessment of hedge effectiveness and recognized in OI&E on a straight-line basis over the life of the hedge.Changes in the fair value of amounts excluded from the assessment of hedge effectiveness are recognized in OCI. 
Non-Designated Derivatives

[0000320193-21-000010:notes:88]
[same as prior period, unchanged from 0000320193-20-000062:notes:88]


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000320193-21-000010:notes:89]
Condensed Consolidated Financial Statement Details
The following tables show the Company’s condensed consolidated financial statement details as of December 26, 2020 and September 26, 2020 (in millions):

[0000320193-21-000010:notes:90]
[same as prior period, unchanged from 0000320193-20-000062:notes:90]

[0000320193-21-000010:notes:91]
|  | December 26,2020 |  | September 26,2020 |
| Land and buildings | $ | 18,885 |  |  | $ | 17,952 |  |
| Machinery, equipment and internal-use software | 76,224 |  |  | 75,291 |  |
| Leasehold improvements | 10,384 |  |  | 10,283 |  |
| Gross property, plant and equipment | 105,493 |  |  | 103,526 |  |
| Accumulated depreciation and amortization | (67,560) |  |  | (66,760) |  |
| Total property, plant and equipment, net | $ | 37,933 |  |  | $ | 36,766 |  |

[0000320193-21-000010:notes:92]
[same as prior period, unchanged from 0000320193-20-000062:notes:92]

[0000320193-21-000010:notes:93]
|  | December 26,2020 |  | September 26,2020 |
| Long-term taxes payable | $ | 28,170 |  |  | $ | 28,170 |  |
| Other non-current liabilities | 27,872 |  |  | 26,320 |  |
| Total other non-current liabilities | $ | 56,042 |  |  | $ | 54,490 |  |

[0000320193-21-000010:notes:94]
[same as prior period, unchanged from 0000320193-20-000062:notes:94]

[0000320193-21-000010:notes:95]
The following table shows the detail of OI&E for the three months ended December 26, 2020 and December 28, 2019 (in millions):

[0000320193-21-000010:notes:96]
|  | Three Months Ended |  |  |
|  | December 26,2020 |  | December 28,2019 |  |  |  |  |
| Interest and dividend income | $ | 747 |  |  | $ | 1,045 |  |  |  |  |  |
| Interest expense | (638) |  |  | (785) |  |  |  |  |  |
| Other income/(expense), net | (64) |  |  | 89 |  |  |  |  |  |
| Total other income/(expense), net | $ | 45 |  |  | $ | 349 |  |  |  |  |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000320193-21-000010:notes:97]
[same as prior period, unchanged from 0000320193-20-000062:notes:97]

[0000320193-21-000010:notes:98]
As of December 26, 2020, the total amount of gross unrecognized tax benefits was $17.1 billion, of which $9.0 billion, if recognized, would impact the Company’s effective tax rate. The Company had accrued $1.6 billion of gross interest and penalties related to income tax matters as of December 26, 2020.

[0000320193-21-000010:notes:99]
The Company is subject to taxation and files income tax returns in the U.S. federal jurisdiction and many state and foreign jurisdictions. The U.S. Internal Revenue Service concluded its review of the years 2013 through 2015 in 2018, and all years before 2016 are closed. Tax years after 2014 remain open in certain major foreign jurisdictions and are subject to examination by the taxing authorities. The Company believes that an adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax audits cannot be predicted with certainty. If any issues addressed in the Company’s tax audits are resolved in a manner inconsistent with its expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. Although the timing of resolution and/or closure of audits is not certain, the Company believes it is reasonably possible that its gross unrecognized tax benefits could decrease in the next 12 months by as much as $4.1 billion.

[0000320193-21-000010:notes:100]
[same as prior period, unchanged from 0000320193-20-000062:notes:100]

[0000320193-21-000010:notes:101]
On August 30, 2016, the European Commission announced its decision that Ireland granted state aid to the Company by providing tax opinions in 1991 and 2007 concerning the tax allocation of profits of the Irish branches of two subsidiaries of the Company (the “State Aid Decision”). The State Aid Decision ordered Ireland to calculate and recover additional taxes from the Company for the period June 2003 through December 2014. Irish legislative changes, effective as of January 2015, eliminated the application of the tax opinions from that date forward. The recovery amount was calculated to be €13.1 billion, plus interest of €1.2 billion. The Company and Ireland appealed the State Aid Decision to the General Court of the Court of Justice of the European Union (the “General Court”). On July 15, 2020, the General Court annulled the State Aid Decision. On September 25, 2020, the European Commission appealed the General Court’s decision to the European Court of Justice. The Company believes that any incremental Irish corporate income taxes potentially due related to the State Aid Decision would be creditable against U.S. taxes, subject to any foreign tax credit limitations in the U.S. Tax Cuts and Jobs Act of 2017.

[0000320193-21-000010:notes:102]
On an annual basis, the Company may request approval from the Irish Minister for Finance to reduce the recovery amount for certain taxes paid to other countries. As of December 26, 2020, the adjusted recovery amount was €12.9 billion, excluding interest. The adjusted recovery amount plus interest is funded into escrow, where it will remain restricted from general use pending the conclusion of all legal proceedings. Refer to the Cash, Cash Equivalents and Marketable Securities section of Note 3, “Financial Instruments” for more information.


## us-gaap:DebtDisclosureTextBlock

[0000320193-21-000010:notes:103]
Debt
Commercial Paper

[0000320193-21-000010:notes:104]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of both December 26, 2020 and September 26, 2020, the Company had $5.0 billion of Commercial Paper outstanding, with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 0.10% and 0.62% as of December 26, 2020 and September 26, 2020, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the three months ended December 26, 2020 and December 28, 2019 (in millions):

[0000320193-21-000010:notes:105]
|  | Three Months Ended |
|  | December 26,2020 |  | December 28,2019 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | 1,439 |  |  | $ | (175) |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 780 |  |  | 1,317 |  |
| Repayments of commercial paper | (2,197) |  |  | (2,121) |  |
| Repayments of commercial paper, net | (1,417) |  |  | (804) |  |
| Total proceeds from/(repayments of) commercial paper, net | $ | 22 |  |  | $ | (979) |  |

[0000320193-21-000010:notes:106]
Term Debt

[0000320193-21-000010:notes:107]
As of December 26, 2020, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $105.9 billion (collectively the “Notes”). The Notes are senior unsecured obligations and interest is payable in arrears. The following table provides a summary of the Company’s term debt as of December 26, 2020 and September 26, 2020:

[0000320193-21-000010:notes:108]
|  | Maturities(calendar year) |  | December 26, 2020 |  | September 26, 2020 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 – 2020 debt issuances: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2021 – 2022 |  | $ | 2,250 |  |  | 0.56% – 1.34% |  | $ | 2,250 |  |  | 0.60% – 1.39% |
| Fixed-rate 0.000% – 4.650% notes | 2021 – 2060 |  | 103,613 |  |  | 0.03% – 4.78% |  | 103,828 |  |  | 0.03% – 4.78% |
| Total term debt |  |  | 105,863 |  |  |  |  | 106,078 |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  | (305) |  |  |  |  | (314) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 1,485 |  |  |  |  | 1,676 |  |  |  |
| Less: Current portion of term debt |  |  | (7,762) |  |  |  |  | (8,773) |  |  |  |
| Total non-current portion of term debt |  |  | $ | 99,281 |  |  |  |  | $ | 98,667 |  |  |  |

[0000320193-21-000010:notes:109]
To manage interest rate risk on certain of its U.S. dollar–denominated fixed- or floating-rate notes, the Company has entered into interest rate swaps to effectively convert the fixed interest rates to floating interest rates or the floating interest rates to fixed interest rates on a portion of these notes. Additionally, to manage foreign currency risk on certain of its foreign currency–denominated notes, the Company has entered into foreign currency swaps to effectively convert these notes to U.S. dollar–denominated notes.

[0000320193-21-000010:notes:110]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $628 million and $757 million of interest cost on its term debt for the three months ended December 26, 2020 and December 28, 2019, respectively.

[0000320193-21-000010:notes:111]
As of December 26, 2020 and September 26, 2020, the fair value of the Company’s Notes, based on Level 2 inputs, was $117.2 billion and $117.1 billion, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000320193-21-000010:notes:112]
[same as prior period, unchanged from 0000320193-20-000062:notes:114]

[0000320193-21-000010:notes:113]
As of December 26, 2020, the Company was authorized to purchase up to $225 billion of the Company’s common stock under a share repurchase program, of which $192.6 billion had been utilized. During the three months ended December 26, 2020, the Company repurchased 200 million shares of its common stock for $24.0 billion. The Company’s share repurchase program does not obligate it to acquire any specific number of shares. Under this program, shares may be repurchased in privately negotiated and/or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000320193-21-000010:notes:114]
Comprehensive Income
The Company’s OCI consists of foreign currency translation adjustments from those subsidiaries not using the U.S. dollar as their functional currency, net deferred gains and losses on certain derivative instruments accounted for as hedges, and unrealized gains and losses on marketable debt securities classified as available-for-sale.

[0000320193-21-000010:notes:115]
The following table shows the pre-tax amounts reclassified from AOCI into the Condensed Consolidated Statements of Operations, and the associated financial statement line items, for the three months ended December 26, 2020 and December 28, 2019 (in millions):

[0000320193-21-000010:notes:116]
|  |  |  | Three Months Ended |  |  |
| Comprehensive Income Components |  | Financial Statement Line Items | December 26,2020 |  | December 28,2019 |  |  |  |  |
| Unrealized (gains)/losses on derivative instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Total net sales | $ | 104 |  |  | $ | (97) |  |  |  |  |  |
|  |  | Total cost of sales | 245 |  |  | (171) |  |  |  |  |  |
|  |  | Other income/(expense), net | (628) |  |  | (223) |  |  |  |  |  |
| Interest rate contracts |  | Other income/(expense), net | 3 |  |  | 2 |  |  |  |  |  |
|  |  |  | (276) |  |  | (489) |  |  |  |  |  |
| Unrealized (gains)/losses on marketable debt securities |  | Other income/(expense), net | (118) |  |  | (13) |  |  |  |  |  |
| Total amounts reclassified from AOCI | $ | (394) |  |  | $ | (502) |  |  |  |  |  |

[0000320193-21-000010:notes:117]
The following table shows the changes in AOCI by component for the three months ended December 26, 2020 (in millions):

[0000320193-21-000010:notes:118]
|  | Cumulative ForeignCurrency Translation |  | Unrealized Gains/Losseson Derivative Instruments |  | Unrealized Gains/Losseson Marketable Debt Securities |  | Total |
| Balances as of September 26, 2020 | $ | (1,375) |  |  | $ | (877) |  |  | $ | 1,846 |  |  | $ | (406) |  |
| Other comprehensive income/(loss) before reclassifications | 549 |  |  | (294) |  |  | 708 |  |  | 963 |  |
| Amounts reclassified from AOCI | — |  |  | (276) |  |  | (118) |  |  | (394) |  |
| Tax effect | — |  |  | 83 |  |  | (67) |  |  | 16 |  |
| Other comprehensive income/(loss) | 549 |  |  | (487) |  |  | 523 |  |  | 585 |  |
| Balances as of December 26, 2020 | $ | (826) |  |  | $ | (1,364) |  |  | $ | 2,369 |  |  | $ | 179 |  |


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000320193-21-000010:notes:119]
[same as prior period, unchanged from 0000320193-20-000062:notes:124]

[0000320193-21-000010:notes:120]
The Company had 713 million shares reserved for future issuance under its stock plans as of December 26, 2020. RSUs granted under the Company’s stock plans generally vest over four years, based on continued employment, and are settled upon vesting in shares of the Company’s common stock on a one-for-one basis. RSUs granted under the Company’s stock plans reduce the number of shares available for grant under the plans by a factor of two times the number of RSUs granted. RSUs canceled and shares withheld to satisfy tax withholding obligations increase the number of shares available for grant under the plans utilizing a factor of two times the number of RSUs canceled or shares withheld.

[0000320193-21-000010:notes:121]
[same as prior period, unchanged from 0000320193-20-000062:notes:126]

[0000320193-21-000010:notes:122]
During the three months ended December 26, 2020, Section 16 officers Katherine L. Adams, Timothy D. Cook, Chris Kondo, Luca Maestri, Deirdre O’Brien and Jeffrey Williams had equity trading plans in place in accordance with Rule 10b5-1(c)(1) under the Exchange Act. An equity trading plan is a written document that pre-establishes the amounts, prices and dates (or formula for determining the amounts, prices and dates) of future purchases or sales of the Company’s stock, including shares acquired under the Company’s employee and director equity plans.

[0000320193-21-000010:notes:123]
[same as prior period, unchanged from 0000320193-20-000062:notes:128]

[0000320193-21-000010:notes:124]
A summary of the Company’s RSU activity and related information for the three months ended December 26, 2020 is as follows:

[0000320193-21-000010:notes:125]
|  | Number ofRSUs(in thousands) |  | Weighted-AverageGrant Date FairValue Per RSU |  | AggregateFair Value(in millions) |
| Balance as of September 26, 2020 | 310,778 |  |  | $ | 51.58 |  |  |  |
| RSUs granted | 75,959 |  |  | $ | 112.75 |  |  |  |
| RSUs vested | (68,565) |  |  | $ | 44.91 |  |  |  |
| RSUs canceled | (2,819) |  |  | $ | 61.05 |  |  |  |
| Balance as of December 26, 2020 | 315,353 |  |  | $ | 67.68 |  |  | $ | 41,617 |  |

[0000320193-21-000010:notes:126]
The fair value as of the respective vesting dates of RSUs was $8.5 billion and $4.2 billion for the three months ended December 26, 2020 and December 28, 2019, respectively.

[0000320193-21-000010:notes:127]
[same as prior period, unchanged from 0000320193-20-000062:notes:132]

[0000320193-21-000010:notes:128]
The following table shows share-based compensation expense and the related income tax benefit included in the Condensed Consolidated Statements of Operations for the three months ended December 26, 2020 and December 28, 2019 (in millions):

[0000320193-21-000010:notes:129]
|  | Three Months Ended |  |  |
|  | December 26,2020 |  | December 28,2019 |  |  |  |  |
| Share-based compensation expense | $ | 2,020 |  |  | $ | 1,710 |  |  |  |  |  |
| Income tax benefit related to share-based compensation expense | $ | (1,624) |  |  | $ | (758) |  |  |  |  |  |

[0000320193-21-000010:notes:130]
As of December 26, 2020, the total unrecognized compensation cost related to outstanding RSUs and stock options was $18.2 billion, which the Company expects to recognize over a weighted-average period of 2.9 years.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000320193-21-000010:notes:131]
Commitments and Contingencies
Accrued Warranty and Guarantees

[0000320193-21-000010:notes:132]
The following table shows changes in the Company’s accrued warranties and related costs for the three months ended December 26, 2020 and December 28, 2019 (in millions):

[0000320193-21-000010:notes:133]
|  | Three Months Ended |  |  |
|  | December 26,2020 |  | December 28,2019 |  |  |  |  |
| Beginning accrued warranty and related costs | $ | 3,354 |  |  | $ | 3,570 |  |  |  |  |  |
| Cost of warranty claims | (723) |  |  | (915) |  |  |  |  |  |
| Accruals for product warranty | 1,493 |  |  | 1,218 |  |  |  |  |  |
| Ending accrued warranty and related costs | $ | 4,124 |  |  | $ | 3,873 |  |  |  |  |  |

[0000320193-21-000010:notes:134]
The Company offers an iPhone Upgrade Program, which is available to customers who purchase a qualifying iPhone in the U.S., the U.K. and China mainland. The iPhone Upgrade Program provides customers the right to trade in that iPhone for a specified amount when purchasing a new iPhone, provided certain conditions are met. The Company accounts for the trade-in right as a guarantee liability and recognizes arrangement revenue net of the fair value of such right, with subsequent changes to the guarantee liability recognized within net sales.

[0000320193-21-000010:notes:135]
Concentrations in the Available Sources of Supply of Materials and Product

[0000320193-21-000010:notes:136]
Although most components essential to the Company’s business are generally available from multiple sources, certain components are currently obtained from single or limited sources. The Company also competes for various components with other participants in the markets for smartphones, personal computers, tablets and other electronic devices. Therefore, many components used by the Company, including those that are available from multiple sources, are at times subject to industry-wide shortage and significant commodity pricing fluctuations.

[0000320193-21-000010:notes:137]
The Company uses some custom components that are not commonly used by its competitors, and new products introduced by the Company often utilize custom components available from only one source. When a component or product uses new technologies, initial capacity constraints may exist until the suppliers’ yields have matured or their manufacturing capacities have increased. The continued availability of these components at acceptable prices, or at all, may be affected if suppliers decide to concentrate on the production of common components instead of components customized to meet the Company’s requirements.

[0000320193-21-000010:notes:138]
The Company has entered into agreements for the supply of many components; however, there can be no guarantee that the Company will be able to extend or renew these agreements on similar terms, or at all.

[0000320193-21-000010:notes:139]
Substantially all of the Company’s hardware products are manufactured by outsourcing partners that are located primarily in Asia, with some Mac computers manufactured in the U.S. and Ireland.

[0000320193-21-000010:notes:140]
Unconditional Purchase Obligations

[0000320193-21-000010:notes:141]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of payments for content creation, Internet and telecommunications services and supplier arrangements. As of December 26, 2020, the Company’s total future payments under noncancelable unconditional purchase obligations having a remaining term in excess of one year were $8.1 billion.

[0000320193-21-000010:notes:142]
Contingencies

[0000320193-21-000010:notes:143]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully resolved. The outcome of litigation is inherently uncertain. When a loss related to a legal proceeding or claim is probable and reasonably estimable, the Company accrues its best estimate for the ultimate resolution of the matter. If one or more legal matters were resolved against the Company in a reporting period for amounts above management’s expectations, the Company’s financial condition and operating results for that reporting period could be materially adversely affected. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss greater than a recorded accrual, concerning loss contingencies for asserted legal and other claims, except for the following matters:

[0000320193-21-000010:notes:144]
VirnetX

[0000320193-21-000010:notes:145]
VirnetX, Inc. (“VirnetX”) filed a lawsuit against the Company alleging that certain of the Company’s products infringe on patents owned by VirnetX. On April 11, 2018, a jury returned a verdict against the Company in the U.S. District Court for the Eastern District of Texas (the “Eastern Texas District Court”). The Company appealed the verdict to the U.S. Court of Appeals for the Federal Circuit, which remanded the case back to the Eastern Texas District Court, where a re-trial was held in October 2020. The jury returned a verdict against the Company and awarded damages of $503 million, which the Company intends to appeal. The Company has challenged the validity of the patents at issue in the re-trial at the U.S. Patent and Trademark Office (the “PTO”), and the PTO has declared the patents invalid, subject to further appeal by VirnetX.

[0000320193-21-000010:notes:146]
iOS Performance Management Cases

[0000320193-21-000010:notes:147]
Various civil litigation matters have been filed in state and federal courts in the U.S. and in various international jurisdictions alleging violation of consumer protection laws, fraud, computer intrusion and other causes of action related to the Company’s performance management feature used in its iPhone operating systems, introduced to certain iPhones in iOS updates 10.2.1 and 11.2. The claims seek monetary damages and other non-monetary relief. On April 5, 2018, several U.S. federal actions were consolidated through a Multidistrict Litigation process into a single action in the U.S. District Court for the Northern District of California (the “Northern California District Court”). On February 28, 2020, the parties in the Multidistrict Litigation reached a settlement to resolve the U.S. federal and California state class actions. Under the terms of the settlement, which the Northern California District Court preliminarily approved in May 2020, the Company has agreed to pay up to $500 million in the aggregate to certain U.S. owners of iPhones if certain conditions are met. The final amount of the settlement will be determined based on the number of consumers who file valid claims and the attorneys’ fee award. However, the Company has agreed to pay at least $310 million to settle the claims. In addition to civil litigation, the Company is also responding to governmental investigations and requests for information relating to the performance management feature. On November 18, 2020, the Company reached a settlement with a multi-state group of attorneys general. Under the terms of the settlement, the Company has agreed to pay an aggregate amount of $113 million to resolve civil, statutory claims. The Company continues to believe that its iPhones were not defective, that the performance management feature introduced with iOS updates 10.2.1 and 11.2 was intended to, and did, improve customers’ user experience, and that the Company did not make any misleading statements or fail to disclose any material information.

[0000320193-21-000010:notes:148]
French Competition Authority

[0000320193-21-000010:notes:149]
On March 16, 2020, the French Competition Authority (“FCA”) announced its decision that aspects of the Company’s sales and distribution practices in France violate French competition law and issued a fine of €1.1 billion. The Company strongly disagrees with the FCA’s decision and has appealed.

[0000320193-21-000010:notes:150]
Optis

[0000320193-21-000010:notes:151]
Optis Wireless Technology, LLC and related entities (“Optis”) filed a lawsuit in the U.S. District Court for the Eastern District of Texas against the Company alleging that certain of the Company’s products infringe on patents owned by Optis. On August 11, 2020, a jury returned a verdict against the Company and awarded damages of $506 million. The Company has asked the court to set aside the verdict, where the case remains pending.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000320193-21-000010:notes:152]
[same as prior period, unchanged from 0000320193-20-000062:notes:155]

[0000320193-21-000010:notes:153]
The Company manages its business primarily on a geographic basis. The Company’s reportable segments consist of the Americas, Europe, Greater China, Japan and Rest of Asia Pacific. Americas includes both North and South America. Europe includes European countries, as well as India, the Middle East and Africa. Greater China includes China mainland, Hong Kong and Taiwan. Rest of Asia Pacific includes Australia and those Asian countries not included in the Company’s other reportable segments. Although the reportable segments provide similar hardware and software products and similar services, each one is managed separately to better align with the location of the Company’s customers and distribution partners and the unique market dynamics of each geographic region. The accounting policies of the various segments are the same as those described in Note 1, “Summary of Significant Accounting Policies” of the Notes to Consolidated Financial Statements in Part II, Item 8 of the 2020 Form 10-K.

[0000320193-21-000010:notes:154]
[same as prior period, unchanged from 0000320193-20-000062:notes:157]

[0000320193-21-000010:notes:155]
The following table shows information by reportable segment for the three months ended December 26, 2020 and December 28, 2019 (in millions):

[0000320193-21-000010:notes:156]
|  | Three Months Ended |  |  |
|  | December 26,2020 |  | December 28,2019 |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |
| Net sales | $ | 46,310 |  |  | $ | 41,367 |  |  |  |  |  |
| Operating income | $ | 15,785 |  |  | $ | 13,092 |  |  |  |  |  |
| Europe: |  |  |  |  |  |  |  |
| Net sales | $ | 27,306 |  |  | $ | 23,273 |  |  |  |  |  |
| Operating income | $ | 9,589 |  |  | $ | 7,719 |  |  |  |  |  |
| Greater China: |  |  |  |  |  |  |  |
| Net sales | $ | 21,313 |  |  | $ | 13,578 |  |  |  |  |  |
| Operating income | $ | 8,530 |  |  | $ | 5,363 |  |  |  |  |  |
| Japan: |  |  |  |  |  |  |  |
| Net sales | $ | 8,285 |  |  | $ | 6,223 |  |  |  |  |  |
| Operating income | $ | 3,503 |  |  | $ | 2,778 |  |  |  |  |  |
| Rest of Asia Pacific: |  |  |  |  |  |  |  |
| Net sales | $ | 8,225 |  |  | $ | 7,378 |  |  |  |  |  |
| Operating income | $ | 2,953 |  |  | $ | 2,731 |  |  |  |  |  |

[0000320193-21-000010:notes:157]
A reconciliation of the Company’s segment operating income to the Condensed Consolidated Statements of Operations for the three months ended December 26, 2020 and December 28, 2019 is as follows (in millions):

[0000320193-21-000010:notes:158]
|  | Three Months Ended |  |  |
|  | December 26,2020 |  | December 28,2019 |  |  |  |  |
| Segment operating income | $ | 40,360 |  |  | $ | 31,683 |  |  |  |  |  |
| Research and development expense | (5,163) |  |  | (4,451) |  |  |  |  |  |
| Other corporate expenses, net | (1,663) |  |  | (1,663) |  |  |  |  |  |
| Total operating income | $ | 33,534 |  |  | $ | 25,569 |  |  |  |  |  |
