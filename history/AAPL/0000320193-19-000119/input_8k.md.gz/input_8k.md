# AAPL 8-K — 0000320193-19-000117 filed 2019-10-30

## item codes, every 8-K on or before 2019-10-31

- 2019-10-30 0000320193-19-000117 — 2.02, 9.01
- 2019-09-13 0000320193-19-000093 — 5.02
- 2019-09-11 0001193125-19-242975 — 8.01, 9.01
- 2019-07-30 0000320193-19-000073 — 2.02, 9.01
- 2019-04-30 0000320193-19-000063 — 2.02, 9.01
- 2019-03-04 0000320193-19-000032 — 5.07
- 2019-02-06 0000320193-19-000026 — 5.02
- 2019-01-29 0000320193-19-000007 — 2.02, 9.01
- 2019-01-02 0000320193-19-000002 — 2.02, 9.01
- 2018-11-01 0000320193-18-000142 — 2.02, 9.01
- 2018-07-31 0000320193-18-000098 — 2.02, 9.01
- 2018-05-08 0001193125-18-154948 — 8.01 — amendment of 0001193125-18-154515
- 2018-05-07 0001193125-18-154515 — 8.01, 9.01
- 2018-05-01 0000320193-18-000067 — 2.02, 9.01
- 2018-02-14 0001193125-18-045761 — 5.07, 9.01
- 2018-02-01 0000320193-18-000005 — 2.02, 9.01
- 2017-11-13 0001193125-17-341015 — 8.01, 9.01
- 2017-11-02 0000320193-17-000067 — 2.02, 9.01
- 2017-10-12 0001193125-17-308859 — 5.02
- 2017-09-12 0001193125-17-282809 — 8.01, 9.01
- 2017-08-18 0001193125-17-262261 — 8.01, 9.01
- 2017-08-01 0000320193-17-000006 — 2.02, 9.01
- 2017-06-20 0001193125-17-208226 — 8.01, 9.01
- 2017-05-24 0001193125-17-181867 — 8.01, 9.01
- 2017-05-11 0001193125-17-167400 — 8.01, 9.01
- 2017-05-02 0001628280-17-004663 — 2.02, 9.01
- 2017-03-03 0001193125-17-069853 — 8.01, 9.01
- 2017-03-01 0001193125-17-064019 — 5.07
- 2017-02-09 0001193125-17-036283 — 8.01, 9.01
- 2017-01-31 0001628280-17-000663 — 2.02, 9.01
- 2016-12-15 0001628280-16-022047 — 5.03, 9.01
- 2016-10-25 0001628280-16-020258 — 2.02, 9.01
- 2016-08-04 0001193125-16-672044 — 8.01, 9.01
- 2016-07-26 0001628280-16-017762 — 2.02, 9.01
- 2016-06-22 0001193125-16-628957 — 8.01, 9.01
- 2016-04-26 0001193125-16-556520 — 2.02, 9.01
- 2016-03-24 0001193125-16-516891 — 8.01, 9.01
- 2016-03-01 0001193125-16-488223 — 5.02, 5.07, 9.01
- 2016-02-23 0001193125-16-473562 — 8.01, 9.01
- 2016-01-26 0001193125-16-438421 — 2.02, 9.01
- 2015-12-22 0001193125-15-410853 — 5.03, 9.01
- 2015-12-17 0001193125-15-406279 — 5.02
- 2015-10-27 0001193125-15-354756 — 2.02, 9.01
- 2015-10-02 0001193125-15-336615 — 5.02
- 2015-09-17 0001193125-15-322466 — 8.01, 9.01
- 2015-07-31 0001193125-15-273023 — 8.01, 9.01
- 2015-07-21 0001193125-15-258464 — 2.02, 9.01
- 2015-06-10 0001193125-15-219298 — 8.01, 9.01
- 2015-05-13 0001193125-15-186064 — 8.01, 9.01
- 2015-04-27 0001193125-15-149607 — 7.01, 9.01
- 2015-04-27 0001193125-15-149590 — 2.02, 9.01
- 2015-03-13 0001104659-15-019336 — 5.07, 9.01
- 2015-02-09 0001193125-15-039270 — 8.01, 9.01
- 2015-01-28 0001193125-15-023732 — 8.01, 9.01
- 2015-01-27 0001193125-15-021857 — 2.02, 9.01
- 2014-11-10 0001193125-14-406296 — 8.01, 9.01
- 2014-10-20 0001193125-14-376361 — 2.02, 9.01
- 2014-07-23 0001193125-14-277193 — 8.01, 9.01
- 2014-07-22 0001193125-14-275598 — 2.02, 9.01
- 2014-07-17 0001193125-14-271698 — 5.02
- 2014-06-06 0001193125-14-228798 — 5.03, 9.01
- 2014-05-30 0001181431-14-021923 — 5.02
- 2014-05-06 0001193125-14-184969 — 8.01, 9.01
- 2014-04-23 0001193125-14-154883 — 7.01, 9.01
- 2014-04-23 0001193125-14-154871 — 2.02, 9.01
- 2014-03-05 0001193125-14-084697 — 5.02, 5.03, 5.07, 9.01
- 2014-01-27 0001193125-14-022238 — 2.02, 9.01
- 2013-10-28 0001193125-13-413498 — 2.02, 9.01
- 2013-09-23 0001181431-13-050140 — 8.01
- 2013-07-30 0001181431-13-041847 — 5.02
- 2013-07-23 0001193125-13-298914 — 2.02, 9.01
- 2013-06-21 0001193125-13-267629 — 5.02
- 2013-05-03 0001193125-13-199324 — 8.01, 9.01
- 2013-04-24 0001193125-13-170623 — 8.01, 9.01
- 2013-04-23 0001193125-13-167469 — 7.01, 9.01
- 2013-04-23 0001193125-13-167458 — 2.02, 9.01
- 2013-03-01 0001193125-13-085842 — 5.07
- 2013-01-23 0001193125-13-020783 — 2.02, 9.01
- 2012-10-25 0001193125-12-435506 — 2.02, 9.01
- 2012-07-24 0001193125-12-312355 — 2.02, 9.01
- 2012-06-28 0001181431-12-038301 — 5.02
- 2012-05-24 0001181431-12-032458 — 5.02
- 2012-04-24 0001193125-12-178928 — 2.02, 9.01
- 2012-02-27 0001193125-12-081892 — 5.07
- 2012-01-24 0001193125-12-021833 — 2.02, 9.01
- 2011-11-16 0001181431-11-056354 — 5.02
- 2011-10-18 0001193125-11-273826 — 2.02, 9.01
- 2011-10-06 0001181431-11-051976 — 8.01
- 2011-08-26 0001181431-11-047179 — 5.02
- 2011-07-19 0001193125-11-191368 — 2.02, 9.01
- 2011-06-15 0001181431-11-036782 — 5.02
- 2011-04-20 0001193125-11-103732 — 2.02, 9.01
- 2011-02-24 0001193125-11-045411 — 5.07
- 2011-01-18 0001193125-11-009392 — 2.02, 9.01
- 2011-01-18 0001181431-11-003847 — 5.02
- 2010-11-17 0001181431-10-056327 — 5.02, 5.03, 9.01
- 2010-10-18 0001193125-10-230992 — 2.02, 9.01
- 2010-07-20 0001193125-10-161807 — 2.02, 9.01
- 2010-04-20 0001193125-10-087786 — 2.02, 9.01
- 2010-03-12 0001181431-10-016054 — 5.02
- 2010-03-01 0001193125-10-044765 — 5.02, 5.07, 9.01
- 2010-01-25 0001193125-10-012096 — 2.02, 9.01
- 2009-10-19 0001193125-09-209633 — 2.02, 9.01
- 2009-08-04 0001181431-09-037492 — 5.02
- 2009-07-21 0001193125-09-152290 — 2.02, 9.01
- 2009-06-02 0001181431-09-028400 — 5.03
- 2009-04-22 0001193125-09-084599 — 2.02, 9.01
- 2009-02-27 0001181431-09-012161 — 4.01
- 2009-01-21 0001193125-09-009009 — 2.02, 9.01
- 2009-01-16 0001181431-09-003017 — 5.02
- 2008-10-21 0001193125-08-213642 — 2.02, 9.01
- 2008-08-26 0001181431-08-050059 — 5.03
- 2008-07-21 0001193125-08-154381 — 2.02, 9.01
- 2008-06-09 0001181431-08-037620 — 8.01
- 2008-04-23 0001193125-08-088001 — 2.02, 9.01
- 2008-01-22 0001193125-08-009715 — 2.02, 9.01
- 2008-01-15 0001181431-08-003342 — 2.02, 8.01
- 2008-01-08 0001181431-08-002372 — 5.02
- 2007-10-22 0001104659-07-076142 — 2.02, 9.01
- 2007-07-25 0001104659-07-056111 — 2.02, 9.01
- 2007-05-16 0001104659-07-040672 — 5.02, 9.01
- 2007-04-25 0001104659-07-031354 — 2.02, 9.01
- 2007-04-24 0001104659-07-030938 — 8.01, 9.01
- 2007-02-21 0001104659-07-012760 — 5.03, 9.01
- 2007-01-17 0001104659-07-002905 — 2.02, 9.01
- 2007-01-10 0001104659-07-001648 — 5.03, 9.01
- 2006-10-27 0001104659-06-069015 — 8.01
- 2006-10-18 0001104659-06-067275 — 2.02, 9.01
- 2006-10-04 0001104659-06-064935 — 5.02, 8.01, 9.01
- 2006-09-01 0001104659-06-058808 — 1.01, 5.02, 5.03, 9.01
- 2006-08-11 0001104659-06-054118 — 2.02, 3.01, 9.01
- 2006-08-04 0001104659-06-051302 — 2.02, 4.02, 9.01
- 2006-07-19 0001104659-06-047739 — 2.02, 9.01
- 2006-04-21 0001181431-06-024759 — 1.01
- 2006-04-19 0001104659-06-025992 — 2.02, 9.01
- 2006-01-18 0001104659-06-002690 — 2.02, 9.01
- 2006-01-10 0001104659-06-001428 — 2.02
- 2005-12-19 0001181431-05-067468 — 1.01
- 2005-10-14 0001181431-05-056604 — 5.02
- 2005-10-11 0001104659-05-048094 — 2.02, 9.01
- 2005-08-26 0001181431-05-049163 — 1.01
- 2005-08-15 0001181431-05-046871 — 1.01
- 2005-07-13 0001104659-05-032297 — 2.02, 9.01
- 2005-06-06 0001181431-05-033177 — 8.01
- 2005-04-26 0001181431-05-023450 — 1.01
- 2005-04-13 0001104659-05-016307 — 2.02, 9.01
- 2005-03-02 0001181431-05-013840 — 3.03, 5.03
- 2005-02-11 0001104659-05-005507 — 8.01
- 2005-01-12 0001104659-05-001183 — 2.02, 9.01
- 2005-01-11 0001104659-05-001049 — 2.02
- 2004-10-13 0001104659-04-030400 — 2.02, 9.01
- 2004-07-14 0001104659-04-019574 — 12, 7
- 2004-04-14 0001104659-04-010122 — 12, 7
- 2004-01-14 0001104659-04-000896 — 12, 7
- 2003-10-15 0001104659-03-022879 — 12, 7
- 2003-07-16 0001104659-03-014913 — 7, 9
- 2003-04-16 0001047469-03-013617 — 7, 9
- 2003-03-21 0001104659-03-004649 — 5, 7
- 2002-08-13 0000912057-02-031595 — 5, 7
- 2002-08-05 0000912057-02-029692 — 5, 7
- 2000-01-24 0000912057-00-002128 — 5, 7
- 1999-09-07 0000320193-99-000010 — 2
- 1999-07-16 0000320193-99-000007 — 2
- 1998-12-23 0000320193-98-000010 — 1
- 1998-01-08 0000320193-98-000001 — 2
- 1997-09-25 0000320193-97-000019 — 2
- 1997-09-25 0000320193-97-000018 — 2
- 1997-09-05 0000320193-97-000016 — 2
- 1997-07-28 0000320193-97-000012 — 4
- 1997-04-25 0000320193-97-000009 — 5
- 1997-04-10 0000320193-97-000007 — 7
- 1996-12-24 0000320193-96-000027 — 7
- 1996-12-23 0000320193-96-000025 — 4 — amendment of 0000320193-96-000021
- 1996-12-13 0000320193-96-000021 — 4
- 1996-10-28 0000912057-96-023874 — 5, 7
- 1996-06-17 0000320193-96-000014 — 1
- 1996-04-12 0000320193-96-000006 — 1

## late-filing notifications on or before 2019-10-31

- 2006-12-15 0001104659-06-081617 — NT 10-K, for the period ended 2006-09-30
- 2006-08-11 0001104659-06-053743 — NT 10-Q, for the period ended 2006-07-01

## item 2.02 — earnings release, exhibit 99.1

[0000320193-19-000117:8k_2_02:1]
EX-99.1
2
a8-kexhibit991q4201992.htm
EXHIBIT 99.1

[0000320193-19-000117:8k_2_02:2]
Exhibit

[0000320193-19-000117:8k_2_02:3]
Exhibit 99.1

[0000320193-19-000117:8k_2_02:4]
Apple Reports Fourth Quarter Results

[0000320193-19-000117:8k_2_02:5]
Services Revenue Reaches All-Time High of $12.5 Billion

[0000320193-19-000117:8k_2_02:6]
EPS Sets New Fourth Quarter Record of $3.03

[0000320193-19-000117:8k_2_02:7]
CUPERTINO, California — October 30, 2019 — Apple® today announced financial results for its fiscal 2019 fourth quarter ended September 28, 2019. The Company posted quarterly revenue of $64 billion, an increase of 2 percent from the year-ago quarter, and quarterly earnings per diluted share of $3.03, up 4 percent. International sales accounted for 60 percent of the quarter’s revenue.

[0000320193-19-000117:8k_2_02:8]
“We concluded a groundbreaking fiscal 2019 with our highest Q4 revenue ever, fueled by accelerating growth from Services, Wearables and iPad,” said Tim Cook, Apple’s CEO. “With customers and reviewers raving about the new generation of iPhones, today’s debut of new, noise-cancelling AirPods Pro, the hotly-anticipated arrival of Apple TV+ just two days away, and our best lineup of products and services ever, we’re very optimistic about what the holiday quarter has in store.”

[0000320193-19-000117:8k_2_02:9]
“Our strong business performance drove record Q4 EPS of $3.03 and record Q4 operating cash flow of $19.9 billion,” said Luca Maestri, Apple’s CFO. “We also returned over $21 billion to shareholders, including almost $18 billion in share repurchases and $3.5 billion in dividends and equivalents, as we continue on our path to reaching a net cash neutral position over time.”

[0000320193-19-000117:8k_2_02:10]
Apple is providing the following guidance for its fiscal 2020 first quarter:

[0000320193-19-000117:8k_2_02:11]
| • | revenue between $85.5 billion and $89.5 billion |

[0000320193-19-000117:8k_2_02:12]
| • | gross margin between 37.5 percent and 38.5 percent |

[0000320193-19-000117:8k_2_02:13]
| • | operating expenses between $9.6 billion and $9.8 billion |

[0000320193-19-000117:8k_2_02:14]
| • | other income/(expense) of $200 million |

[0000320193-19-000117:8k_2_02:15]
| • | tax rate of approximately 16.5 percent |

[0000320193-19-000117:8k_2_02:16]
Apple’s board of directors has declared a cash dividend of $0.77 per share of the Company’s common stock. The dividend is payable on November 14, 2019 to shareholders of record as of the close of business on November 11, 2019.

[0000320193-19-000117:8k_2_02:17]
Apple will provide live streaming of its Q4 2019 financial results conference call beginning at 2:00 p.m. PDT on October 30, 2019 at www.apple.com/investor/earnings-call/. This webcast will also be available for replay for approximately two weeks thereafter.

[0000320193-19-000117:8k_2_02:18]
Apple periodically provides information for investors on its corporate website, apple.com, and its investors relations website, investor.apple.com. This includes press releases and other information about financial performance, reports filed or furnished with the SEC, information on corporate governance and details related to its annual meeting of shareholders.

[0000320193-19-000117:8k_2_02:19]
Apple revolutionized personal technology with the introduction of the Macintosh in 1984. Today, Apple leads the world in innovation with iPhone, iPad, Mac, Apple Watch and Apple TV. Apple’s four software platforms — iOS, macOS, watchOS and tvOS — provide seamless experiences across all Apple devices and empower people with breakthrough services including the App Store, Apple Music, Apple Pay and iCloud. Apple’s more than 100,000 employees are dedicated to making the best products on earth, and to leaving the world better than we found it.

[0000320193-19-000117:8k_2_02:20]
Press Contact:

[0000320193-19-000117:8k_2_02:21]
Kristin Huguet

[0000320193-19-000117:8k_2_02:22]
Apple

[0000320193-19-000117:8k_2_02:23]
khuguet@apple.com

[0000320193-19-000117:8k_2_02:24]
(408) 974-2414

[0000320193-19-000117:8k_2_02:25]
Investor Relations Contacts:

[0000320193-19-000117:8k_2_02:26]
Nancy Paxton

[0000320193-19-000117:8k_2_02:27]
Apple

[0000320193-19-000117:8k_2_02:28]
paxton1@apple.com

[0000320193-19-000117:8k_2_02:29]
(408) 974-5420

[0000320193-19-000117:8k_2_02:30]
Tejas Gala

[0000320193-19-000117:8k_2_02:31]
Apple

[0000320193-19-000117:8k_2_02:32]
tgala@apple.com

[0000320193-19-000117:8k_2_02:33]
(669) 227-2402

[0000320193-19-000117:8k_2_02:34]
NOTE TO EDITORS: For additional information visit Apple Newsroom (www.apple.com/newsroom), or call Apple’s Media Helpline at (408) 974-2042.

[0000320193-19-000117:8k_2_02:35]
© 2019 Apple Inc. All rights reserved. Apple and the Apple logo are trademarks of Apple. Other company and product names may be trademarks of their respective owners.

[0000320193-19-000117:8k_2_02:36]
Apple Inc.

[0000320193-19-000117:8k_2_02:37]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS (Unaudited)

[0000320193-19-000117:8k_2_02:38]
(In millions, except number of shares which are reflected in thousands and per share amounts)

[0000320193-19-000117:8k_2_02:39]
|  | Three Months Ended |  | Twelve Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |  | September 28, 2019 |  | September 29, 2018 |
| Net sales: |  |  |  |  |  |  |  |
| Products | $ | 51,529 |  |  | $ | 52,301 |  |  | $ | 213,883 |  |  | $ | 225,847 |  |
| Services | 12,511 |  |  | 10,599 |  |  | 46,291 |  |  | 39,748 |  |
| Total net sales (1) | 64,040 |  |  | 62,900 |  |  | 260,174 |  |  | 265,595 |  |
| Cost of sales: |  |  |  |  |  |  |  |
| Products | 35,238 |  |  | 34,697 |  |  | 144,996 |  |  | 148,164 |  |
| Services | 4,489 |  |  | 4,119 |  |  | 16,786 |  |  | 15,592 |  |
| Total cost of sales | 39,727 |  |  | 38,816 |  |  | 161,782 |  |  | 163,756 |  |
| Gross margin | 24,313 |  |  | 24,084 |  |  | 98,392 |  |  | 101,839 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 4,110 |  |  | 3,750 |  |  | 16,217 |  |  | 14,236 |  |
| Selling, general and administrative | 4,578 |  |  | 4,216 |  |  | 18,245 |  |  | 16,705 |  |
| Total operating expenses | 8,688 |  |  | 7,966 |  |  | 34,462 |  |  | 30,941 |  |
| Operating income | 15,625 |  |  | 16,118 |  |  | 63,930 |  |  | 70,898 |  |
| Other income/(expense), net | 502 |  |  | 303 |  |  | 1,807 |  |  | 2,005 |  |
| Income before provision for income taxes | 16,127 |  |  | 16,421 |  |  | 65,737 |  |  | 72,903 |  |
| Provision for income taxes | 2,441 |  |  | 2,296 |  |  | 10,481 |  |  | 13,372 |  |
| Net income | $ | 13,686 |  |  | $ | 14,125 |  |  | $ | 55,256 |  |  | $ | 59,531 |  |
| Earnings per share: |  |  |  |  |  |  |  |
| Basic | $ | 3.05 |  |  | $ | 2.94 |  |  | $ | 11.97 |  |  | $ | 12.01 |  |
| Diluted | $ | 3.03 |  |  | $ | 2.91 |  |  | $ | 11.89 |  |  | $ | 11.91 |  |
| Shares used in computing earnings per share: |  |  |  |  |  |  |  |
| Basic | 4,490,812 |  |  | 4,801,589 |  |  | 4,617,834 |  |  | 4,955,377 |  |
| Diluted | 4,520,373 |  |  | 4,847,547 |  |  | 4,648,913 |  |  | 5,000,109 |  |
| (1) Net sales by reportable segment: |  |  |  |  |  |  |  |
| Americas | $ | 29,322 |  |  | $ | 27,517 |  |  | $ | 116,914 |  |  | $ | 112,093 |  |
| Europe | 14,946 |  |  | 15,382 |  |  | 60,288 |  |  | 62,420 |  |
| Greater China | 11,134 |  |  | 11,411 |  |  | 43,678 |  |  | 51,942 |  |
| Japan | 4,982 |  |  | 5,161 |  |  | 21,506 |  |  | 21,733 |  |
| Rest of Asia Pacific | 3,656 |  |  | 3,429 |  |  | 17,788 |  |  | 17,407 |  |
| Total net sales | $ | 64,040 |  |  | $ | 62,900 |  |  | $ | 260,174 |  |  | $ | 265,595 |  |
| (1) Net sales by category: |  |  |  |  |  |  |  |
| iPhone | $ | 33,362 |  |  | $ | 36,755 |  |  | $ | 142,381 |  |  | $ | 164,888 |  |
| Mac | 6,991 |  |  | 7,340 |  |  | 25,740 |  |  | 25,198 |  |
| iPad | 4,656 |  |  | 3,983 |  |  | 21,280 |  |  | 18,380 |  |
| Wearables, Home and Accessories | 6,520 |  |  | 4,223 |  |  | 24,482 |  |  | 17,381 |  |
| Services | 12,511 |  |  | 10,599 |  |  | 46,291 |  |  | 39,748 |  |
| Total net sales | $ | 64,040 |  |  | $ | 62,900 |  |  | $ | 260,174 |  |  | $ | 265,595 |  |

[0000320193-19-000117:8k_2_02:40]
Apple Inc.

[0000320193-19-000117:8k_2_02:41]
CONDENSED CONSOLIDATED BALANCE SHEETS (Unaudited)

[0000320193-19-000117:8k_2_02:42]
(In millions, except number of shares which are reflected in thousands and par value)

[0000320193-19-000117:8k_2_02:43]
|  | September 28, 2019 |  | September 29, 2018 |
| ASSETS: |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 48,844 |  |  | $ | 25,913 |  |
| Marketable securities | 51,713 |  |  | 40,388 |  |
| Accounts receivable, net | 22,926 |  |  | 23,186 |  |
| Inventories | 4,106 |  |  | 3,956 |  |
| Vendor non-trade receivables | 22,878 |  |  | 25,809 |  |
| Other current assets | 12,352 |  |  | 12,087 |  |
| Total current assets | 162,819 |  |  | 131,339 |  |
| Non-current assets: |  |  |  |
| Marketable securities | 105,341 |  |  | 170,799 |  |
| Property, plant and equipment, net | 37,378 |  |  | 41,304 |  |
| Other non-current assets | 32,978 |  |  | 22,283 |  |
| Total non-current assets | 175,697 |  |  | 234,386 |  |
| Total assets | $ | 338,516 |  |  | $ | 365,725 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY: |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 46,236 |  |  | $ | 55,888 |  |
| Other current liabilities | 37,720 |  |  | 33,327 |  |
| Deferred revenue | 5,522 |  |  | 5,966 |  |
| Commercial paper | 5,980 |  |  | 11,964 |  |
| Term debt | 10,260 |  |  | 8,784 |  |
| Total current liabilities | 105,718 |  |  | 115,929 |  |
| Non-current liabilities: |  |  |  |
| Term debt | 91,807 |  |  | 93,735 |  |
| Other non-current liabilities | 50,503 |  |  | 48,914 |  |
| Total non-current liabilities | 142,310 |  |  | 142,649 |  |
| Total liabilities | 248,028 |  |  | 258,578 |  |
| Commitments and contingencies |  |  |  |
| Shareholders’ equity: |  |  |  |
| Common stock and additional paid-in capital, $0.00001 par value: 12,600,000 shares authorized; 4,443,236 and 4,754,986 shares issued and outstanding, respectively | 45,174 |  |  | 40,201 |  |
| Retained earnings | 45,898 |  |  | 70,400 |  |
| Accumulated other comprehensive income/(loss) | (584 | ) |  | (3,454 | ) |
| Total shareholders’ equity | 90,488 |  |  | 107,147 |  |
| Total liabilities and shareholders’ equity | $ | 338,516 |  |  | $ | 365,725 |  |

[0000320193-19-000117:8k_2_02:44]
Apple Inc.

[0000320193-19-000117:8k_2_02:45]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (Unaudited)

[0000320193-19-000117:8k_2_02:46]
(In millions)

[0000320193-19-000117:8k_2_02:47]
|  | Twelve Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |
| Cash, cash equivalents and restricted cash, beginning balances | $ | 25,913 |  |  | $ | 20,289 |  |
| Operating activities: |  |  |  |
| Net income | 55,256 |  |  | 59,531 |  |
| Adjustments to reconcile net income to cash generated by operating activities: |  |  |  |
| Depreciation and amortization | 12,547 |  |  | 10,903 |  |
| Share-based compensation expense | 6,068 |  |  | 5,340 |  |
| Deferred income tax benefit | (340 | ) |  | (32,590 | ) |
| Other | (652 | ) |  | (444 | ) |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | 245 |  |  | (5,322 | ) |
| Inventories | (289 | ) |  | 828 |  |
| Vendor non-trade receivables | 2,931 |  |  | (8,010 | ) |
| Other current and non-current assets | 873 |  |  | (423 | ) |
| Accounts payable | (1,923 | ) |  | 9,175 |  |
| Deferred revenue | (625 | ) |  | (3 | ) |
| Other current and non-current liabilities | (4,700 | ) |  | 38,449 |  |
| Cash generated by operating activities | 69,391 |  |  | 77,434 |  |
| Investing activities: |  |  |  |
| Purchases of marketable securities | (39,630 | ) |  | (71,356 | ) |
| Proceeds from maturities of marketable securities | 40,102 |  |  | 55,881 |  |
| Proceeds from sales of marketable securities | 56,988 |  |  | 47,838 |  |
| Payments for acquisition of property, plant and equipment | (10,495 | ) |  | (13,313 | ) |
| Payments made in connection with business acquisitions, net | (624 | ) |  | (721 | ) |
| Purchases of non-marketable securities | (1,001 | ) |  | (1,871 | ) |
| Proceeds from non-marketable securities | 1,634 |  |  | 353 |  |
| Other | (1,078 | ) |  | (745 | ) |
| Cash generated by investing activities | 45,896 |  |  | 16,066 |  |
| Financing activities: |  |  |  |
| Proceeds from issuance of common stock | 781 |  |  | 669 |  |
| Payments for taxes related to net share settlement of equity awards | (2,817 | ) |  | (2,527 | ) |
| Payments for dividends and dividend equivalents | (14,119 | ) |  | (13,712 | ) |
| Repurchases of common stock | (66,897 | ) |  | (72,738 | ) |
| Proceeds from issuance of term debt, net | 6,963 |  |  | 6,969 |  |
| Repayments of term debt | (8,805 | ) |  | (6,500 | ) |
| Repayments of commercial paper, net | (5,977 | ) |  | (37 | ) |
| Other | (105 | ) |  | — |  |
| Cash used in financing activities | (90,976 | ) |  | (87,876 | ) |
| Increase in cash, cash equivalents and restricted cash | 24,311 |  |  | 5,624 |  |
| Cash, cash equivalents and restricted cash, ending balances | $ | 50,224 |  |  | $ | 25,913 |  |
| Supplemental cash flow disclosure: |  |  |  |
| Cash paid for income taxes, net | $ | 15,263 |  |  | $ | 10,417 |  |
| Cash paid for interest | $ | 3,423 |  |  | $ | 3,022 |  |
