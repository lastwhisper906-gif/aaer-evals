# AAPL note change history — 0000320193-19-000066 → 0000320193-19-000076


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-07-31):
[0000320193-19-000076:note_history:1]
The following table shows changes in the Company’s accrued warranties and related costs for the three- and nine-month periods ended June 29, 2019 and June 30, 2018 (in millions):
  (was, 2019-05-01, similarity 0.9318):
[0000320193-19-000066:note_history:1]
The following table shows changes in the Company’s accrued warranties and related costs for the three- and six-month periods ended March 30, 2019 and March 31, 2018 (in millions):

- changed (2019-07-31):
[0000320193-19-000076:note_history:2]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| Beginning accrued warranty and related costs | $ | 3,487 |  |  | $ | 4,030 |  |  | $ | 3,692 |  |  | $ | 3,834 |  |
| Cost of warranty claims | (912 | ) |  | (1,044 | ) |  | (2,823 | ) |  | (2,959 | ) |
| Accruals for product warranty | 548 |  |  | 567 |  |  | 2,254 |  |  | 2,678 |  |
| Ending accrued warranty and related costs | $ | 3,123 |  |  | $ | 3,553 |  |  | $ | 3,123 |  |  | $ | 3,553 |  |
  (was, 2019-05-01, similarity 0.8402):
[0000320193-19-000066:note_history:2]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Beginning accrued warranty and related costs | $ | 3,819 |  |  | $ | 4,323 |  |  | $ | 3,692 |  |  | $ | 3,834 |  |
| Cost of warranty claims | (915 | ) |  | (933 | ) |  | (1,911 | ) |  | (1,915 | ) |
| Accruals for product warranty | 583 |  |  | 640 |  |  | 1,706 |  |  | 2,111 |  |
| Ending accrued warranty and related costs | $ | 3,487 |  |  | $ | 4,030 |  |  | $ | 3,487 |  |  | $ | 4,030 |  |

- changed (2019-07-31):
[0000320193-19-000076:note_history:3]
Agreements entered into by the Company may include indemnification provisions, which may subject the Company to costs and damages in the event of a claim against an indemnified third party. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to indemnification of third parties.
  (was, 2019-05-01, similarity 0.869):
[0000320193-19-000066:note_history:3]
Agreements entered into by the Company may include indemnification provisions, which may subject the Company to costs and damages in the event of a claim against an indemnified third party. Except as disclosed under the heading “Contingencies” below, in the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to indemnification of third parties.

- changed (2019-07-31):
[0000320193-19-000076:note_history:4]
The Company leases various equipment and facilities, including retail space, under noncancelable operating lease arrangements. The Company does not currently utilize any other off–balance sheet financing arrangements. As of June 29, 2019, the Company’s total future minimum lease payments under noncancelable operating leases were $11.1 billion. The Company’s retail store and other facility leases typically have original terms not exceeding 10 years and generally contain multi-year renewal options.
  (was, 2019-05-01, similarity 0.9908):
[0000320193-19-000066:note_history:4]
The Company leases various equipment and facilities, including retail space, under noncancelable operating lease arrangements. The Company does not currently utilize any other off–balance sheet financing arrangements. As of March 30, 2019, the Company’s total future minimum lease payments under noncancelable operating leases were $10.4 billion. The Company’s retail store and other facility leases typically have original terms not exceeding 10 years and generally contain multi-year renewal options.

- changed (2019-07-31):
[0000320193-19-000076:note_history:5]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of payments for supplier arrangements, internet and telecommunication services, intellectual property licenses and content creation. As of June 29, 2019, the Company’s total future payments under noncancelable unconditional purchase obligations having a remaining term in excess of one year were $8.1 billion.
  (was, 2019-05-01, similarity 0.9915):
[0000320193-19-000066:note_history:5]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of payments for supplier arrangements, internet and telecommunication services, intellectual property licenses and content creation. As of March 30, 2019, the Company’s total future payments under noncancelable unconditional purchase obligations having a remaining term in excess of one year were $7.6 billion.

- added (2019-07-31):
[0000320193-19-000076:note_history:6]
VirnetX, Inc. (“VirnetX”) filed two lawsuits in the U.S. District Court for the Eastern District of Texas (the “Eastern Texas District Court”) against the Company alleging that certain Company products infringe four patents (the “VirnetX Patents”) relating to network communications technology (“VirnetX I” and “VirnetX II”). On September 30, 2016, a jury returned a verdict in VirnetX I against the Company and awarded damages of $302 million, which later increased to $440 million in post-trial proceedings. The Company appealed the VirnetX I verdict to the U.S. Court of Appeals for the Federal Circuit (the “Federal Circuit”). On April 11, 2018, a jury returned a verdict in VirnetX II against the Company and awarded damages of $503 million. VirnetX II is currently on appeal. The Company has challenged the validity of the VirnetX Patents at the U.S. Patent and Trademark Office (the “PTO”). In response, the PTO has declared the VirnetX Patents invalid. VirnetX appealed the invalidity decision of the PTO to the Federal Circuit. The Federal Circuit consolidated the Company’s appeal of the Eastern Texas District Court VirnetX I verdict and VirnetX’s appeals from the PTO invalidity proceedings. On January 15, 2019, the Federal Circuit affirmed the VirnetX I verdict, which the Company intends to further appeal. On July 8, 2019, the Federal Circuit remanded one of VirnetX’s appeals of the PTO’s invalidity decisions back to the PTO for further proceedings. VirnetX’s other remaining appeal of the PTO’s invalidity decisions remains pending with the Federal Circuit. The Company has accrued its best estimate for the ultimate resolution of these matters.

- changed (2019-07-31):
[0000320193-19-000076:note_history:7]
On April 16, 2019, the Company and Qualcomm reached a settlement agreement to dismiss all litigation between the two companies worldwide. The companies also reached a multi-year license agreement and a multi-year supply agreement. Under the terms of the settlement agreement, Apple made a payment to Qualcomm to, among other things, resolve disputes over the withheld royalty payments.
  (was, 2019-05-01, similarity 0.9856):
[0000320193-19-000066:note_history:7]
On April 16, 2019, the Company and Qualcomm reached a settlement agreement to dismiss all litigation between the two companies worldwide. The companies also reached a multi-year license agreement and a multi-year supply agreement. Under the terms of the settlement agreement, Apple will make a payment to Qualcomm to, among other things, resolve disputes over the withheld royalty payments.

- added (2019-07-31):
[0000320193-19-000076:note_history:8]
iOS Performance Management Cases

- changed (2019-07-31):
[0000320193-19-000076:note_history:9]
Various civil litigation matters have been filed in state and federal courts in the U.S. and in various international jurisdictions alleging violation of consumer protection laws, fraud, computer intrusion and other causes of action related to the Company’s performance management feature used in its iPhone operating systems, introduced to certain iPhones in iOS updates 10.2.1 and 11.2. The claims seek monetary damages and other non-monetary relief. On April 5, 2018, several U.S. federal actions were consolidated through a Multidistrict Litigation process into a single action in the U.S. District Court for the Northern District of California. In addition to civil litigation, the Company is also responding to governmental investigations and requests for information relating to the performance management feature. The Company believes that its iPhones were not defective, that the performance management feature introduced with iOS updates 10.2.1 and 11.2 was intended to, and did, improve customers’ user experience, and that the Company did not make any misleading statements or fail to disclose any material information. The Company has accrued its best estimate for the ultimate resolution of these matters.
  (was, 2019-05-01, similarity 0.9864):
[0000320193-19-000066:note_history:9]
iOS Performance Management Cases
Various civil litigation matters have been filed in state and federal courts in the U.S. and in various international jurisdictions alleging violation of consumer protection laws, fraud, computer intrusion and other causes of action related to the Company’s performance management feature used in its iPhone operating systems, introduced to certain iPhones in iOS updates 10.2.1 and 11.2. The claims seek monetary damages and other non-monetary relief. On April 5, 2018, several U.S. federal actions were consolidated through a Multidistrict Litigation process into a single action in the U.S. District Court for the Northern District of California. In addition to civil litigation, the Company is also responding to governmental investigations and requests for information relating to the performance management feature. The Company believes that its iPhones were not defective, that the performance management feature introduced with iOS updates 10.2.1 and 11.2 was intended to, and did, improve customers’ user experience, and that the Company did not make any misleading statements or fail to disclose any material information. The Company has accrued its best estimate for the ultimate resolution of these matters.

- removed (2019-07-31):
[0000320193-19-000066:note_history:10]
VirnetX, Inc. filed two lawsuits in the U.S. District Court for the Eastern District of Texas (the “Eastern Texas District Court”) against the Company alleging that certain Company products infringe four patents (the “VirnetX Patents”) relating to network communications technology (“VirnetX I” and “VirnetX II”). On September 30, 2016, a jury returned a verdict in VirnetX I against the Company and awarded damages of $302 million, which later increased to $440 million in post-trial proceedings. The Company appealed the VirnetX I verdict to the U.S. Court of Appeals for the Federal Circuit (the “Federal Circuit”). On April 11, 2018, a jury returned a verdict in VirnetX II against the Company and awarded damages of $503 million. VirnetX II is currently on appeal. The Company has challenged the validity of the VirnetX Patents at the U.S. Patent and Trademark Office (the “PTO”). In response, the PTO has declared the VirnetX Patents invalid. VirnetX appealed the invalidity decision of the PTO to the Federal Circuit. The Federal Circuit consolidated the Company’s appeal of the Eastern Texas District Court VirnetX I verdict and VirnetX’s appeals from the PTO invalidity proceedings. On January 15, 2019, the Federal Circuit affirmed the VirnetX I verdict, which the Company intends to further appeal. The remaining appeals from the PTO proceedings invalidating the VirnetX Patents remain pending. The Company has accrued its best estimate for the ultimate resolution of these matters.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-07-31):
[0000320193-19-000076:note_history:11]
Additionally, beginning in the first quarter of 2019, the Company classified the amortization of the deferred value of Maps, Siri® and free iCloud® services, which are bundled in the sales price of iPhone®, Mac®, iPad® and certain other products, in services net sales. Historically, the Company classified the amortization of these amounts in products net sales consistent with its management reporting framework. As a result, products and services net sales information for the third quarter and first nine months of 2018 was reclassified to conform to the 2019 presentation.
  (was, 2019-05-01, similarity 0.9859):
[0000320193-19-000066:note_history:11]
Additionally, beginning in the first quarter of 2019, the Company classified the amortization of the deferred value of Maps, Siri® and free iCloud® services, which are bundled in the sales price of iPhone®, Mac®, iPad® and certain other products, in services net sales. Historically, the Company classified the amortization of these amounts in products net sales consistent with its management reporting framework. As a result, products and services net sales information for the second quarter and first six months of 2018 was reclassified to conform to the 2019 presentation.

- changed (2019-07-31):
[0000320193-19-000076:note_history:12]
The following table shows the computation of basic and diluted earnings per share for the three- and nine-month periods ended June 29, 2019 and June 30, 2018 (net income in millions and shares in thousands):
  (was, 2019-05-01, similarity 0.9418):
[0000320193-19-000066:note_history:12]
The following table shows the computation of basic and diluted earnings per share for the three- and six-month periods ended March 30, 2019 and March 31, 2018 (net income in millions and shares in thousands):

- changed (2019-07-31):
[0000320193-19-000076:note_history:13]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 10,044 |  |  | $ | 11,519 |  |  | $ | 41,570 |  |  | $ | 45,406 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 4,570,633 |  |  | 4,882,167 |  |  | 4,660,175 |  |  | 5,006,640 |  |
| Effect of dilutive securities | 30,747 |  |  | 44,442 |  |  | 31,584 |  |  | 44,323 |  |
| Weighted-average diluted shares | 4,601,380 |  |  | 4,926,609 |  |  | 4,691,759 |  |  | 5,050,963 |  |
| Basic earnings per share | $ | 2.20 |  |  | $ | 2.36 |  |  | $ | 8.92 |  |  | $ | 9.07 |  |
| Diluted earnings per share | $ | 2.18 |  |  | $ | 2.34 |  |  | $ | 8.86 |  |  | $ | 8.99 |  |
  (was, 2019-05-01, similarity 0.882):
[0000320193-19-000066:note_history:13]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 11,561 |  |  | $ | 13,822 |  |  | $ | 31,526 |  |  | $ | 33,887 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 4,674,071 |  |  | 5,024,877 |  |  | 4,704,945 |  |  | 5,068,877 |  |
| Effect of dilutive securities | 26,575 |  |  | 43,616 |  |  | 32,004 |  |  | 44,263 |  |
| Weighted-average diluted shares | 4,700,646 |  |  | 5,068,493 |  |  | 4,736,949 |  |  | 5,113,140 |  |
| Basic earnings per share | $ | 2.47 |  |  | $ | 2.75 |  |  | $ | 6.70 |  |  | $ | 6.69 |  |
| Diluted earnings per share | $ | 2.46 |  |  | $ | 2.73 |  |  | $ | 6.66 |  |  | $ | 6.63 |  |

- changed (2019-07-31):
[0000320193-19-000076:note_history:14]
Potentially dilutive securities representing 1.5 million and 20.5 million shares of common stock were excluded from the computation of diluted earnings per share for the three- and nine-month periods ended June 29, 2019, respectively, because their effect would have been antidilutive.
  (was, 2019-05-01, similarity 0.9708):
[0000320193-19-000066:note_history:14]
Potentially dilutive securities representing 31.1 million and 30.0 million shares of common stock were excluded from the computation of diluted earnings per share for the three- and six-month periods ended March 30, 2019, respectively, because their effect would have been antidilutive.

- added (2019-07-31):
[0000320193-19-000076:note_history:15]
Restricted Cash and Restricted Marketable Securities

- changed (2019-07-31):
[0000320193-19-000076:note_history:16]
The Company considers cash and marketable securities to be restricted when withdrawal or general use is legally restricted. The Company records restricted cash as other assets in the Condensed Consolidated Balance Sheets, and determines current or non-current classification based on the expected duration of the restriction. The Company records restricted marketable securities as current or non-current marketable securities in the Condensed Consolidated Balance Sheets based on the classification of the underlying securities.
  (was, 2019-05-01, similarity 0.9523):
[0000320193-19-000066:note_history:16]
Restricted Cash and Restricted Marketable Securities
The Company considers cash and marketable securities to be restricted when withdrawal or general use is legally restricted. The Company records restricted cash as other assets in the Condensed Consolidated Balance Sheets, and determines current or non-current classification based on the expected duration of the restriction. The Company records restricted marketable securities as current or non-current marketable securities in the Condensed Consolidated Balance Sheets based on the classification of the underlying securities.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-07-31):
[0000320193-19-000076:note_history:17]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of June 29, 2019 and September 29, 2018, the Company had $10.0 billion and $12.0 billion of Commercial Paper outstanding, respectively, with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 2.49% and 2.18% as of June 29, 2019 and September 29, 2018, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the nine months ended June 29, 2019 and June 30, 2018 (in millions):
  (was, 2019-05-01, similarity 0.7536):
[0000320193-19-000066:note_history:17]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of March 30, 2019 and September 29, 2018, the Company had $11.9 billion and $12.0 billion of Commercial Paper outstanding, respectively, with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 2.56% as of March 30, 2019 and 2.18% as of September 29, 2018. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the six months ended March 30, 2019 and March 31, 2018 (in millions):

- added (2019-07-31):
[0000320193-19-000076:note_history:18]
|  | Nine Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | (3,720 | ) |  | $ | 2,619 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 12,977 |  |  | 9,782 |  |
| Repayments of commercial paper | (11,283 | ) |  | (12,411 | ) |
| Proceeds from/(Repayments of) commercial paper, net | 1,694 |  |  | (2,629 | ) |
| Total repayments of commercial paper, net | $ | (2,026 | ) |  | $ | (10 | ) |

- changed (2019-07-31):
[0000320193-19-000076:note_history:19]
As of June 29, 2019, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $98.3 billion (collectively the “Notes”). The Notes are senior unsecured obligations, and interest is payable in arrears, quarterly for the U.S. dollar–denominated and Australian dollar–denominated floating-rate notes, semi-annually for the U.S. dollar–denominated, Australian dollar–denominated, British pound–denominated, Japanese yen–denominated and Canadian dollar–denominated fixed-rate notes and annually for the euro-denominated and Swiss franc–denominated fixed-rate notes.
  (was, 2019-05-01, similarity 0.9927):
[0000320193-19-000066:note_history:19]
As of March 30, 2019, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $101.2 billion (collectively the “Notes”). The Notes are senior unsecured obligations, and interest is payable in arrears, quarterly for the U.S. dollar–denominated and Australian dollar–denominated floating-rate notes, semi-annually for the U.S. dollar–denominated, Australian dollar–denominated, British pound–denominated, Japanese yen–denominated and Canadian dollar–denominated fixed-rate notes and annually for the euro-denominated and Swiss franc–denominated fixed-rate notes.

- changed (2019-07-31):
[0000320193-19-000076:note_history:20]
The following table provides a summary of the Company’s term debt as of June 29, 2019 and September 29, 2018:
  (was, 2019-05-01, similarity 0.9548):
[0000320193-19-000066:note_history:20]
The following table provides a summary of the Company’s term debt as of March 30, 2019 and September 29, 2018:

- changed (2019-07-31):
[0000320193-19-000076:note_history:21]
|  | Maturities(calendar year) |  | June 29, 2019 |  | September 29, 2018 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 2.400% – 3.850% notes | 2023 | – | 2043 |  | $ | 8,500 |  |  |  | 2.44% | – | 3.91 | % |  | $ | 8,500 |  |  |  | 2.44% | – | 3.91 | % |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | — |  | — |  |  |  |  |  | — | % |  | 1,000 |  |  |  |  |  | 2.64 | % |
| Fixed-rate 2.850% – 4.450% notes | 2021 | – | 2044 |  | 6,500 |  |  |  | 3.12% | – | 4.48 | % |  | 8,500 |  |  |  | 2.64% | – | 4.48 | % |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2020 |  | 1,488 |  |  |  | 1.87% | – | 2.84 | % |  | 1,507 |  |  |  | 1.87% | – | 2.64 | % |
| Fixed-rate 0.350% – 4.375% notes | 2019 | – | 2045 |  | 24,223 |  |  |  | 0.28% | – | 4.51 | % |  | 24,410 |  |  |  | 0.28% | – | 4.51 | % |
| 2016 debt issuances of $24.9 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2021 |  | 850 |  |  |  | 2.71% | – | 3.65 | % |  | 1,350 |  |  |  | 2.48% | – | 3.44 | % |
| Fixed-rate 1.100% – 4.650% notes | 2019 | – | 2046 |  | 22,022 |  |  |  | 1.13% | – | 4.78 | % |  | 23,059 |  |  |  | 1.13% | – | 4.78 | % |
| 2017 debt issuances of $28.7 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2020 | – | 2022 |  | 2,750 |  |  |  | 2.61% | – | 3.06 | % |  | 3,250 |  |  |  | 2.41% | – | 2.84 | % |
| Fixed-rate 0.875% – 4.300% notes | 2019 | – | 2047 |  | 24,989 |  |  |  | 1.54% | – | 4.30 | % |  | 25,617 |  |  |  | 1.54% | – | 4.30 | % |
| 2018 debt issuance of $7.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 1.800% – 3.750% notes | 2019 | – | 2047 |  | 7,000 |  |  |  | 1.83% | – | 3.80 | % |  | 7,000 |  |  |  | 1.83% | – | 3.80 | % |
| Total term debt |  |  |  |  | 98,322 |  |  |  |  |  |  |  | 104,193 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (194 | ) |  |  |  |  |  |  | (218 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | 337 |  |  |  |  |  |  |  | (1,456 | ) |  |  |  |  |  |
| Less: Current portion of term debt |  |  |  |  | (13,529 | ) |  |  |  |  |  |  | (8,784 | ) |  |  |  |  |  |
| Total non-current portion of term debt |  |  |  |  | $ | 84,936 |  |  |  |  |  |  |  | $ | 93,735 |  |  |  |  |  |  |
  (was, 2019-05-01, similarity 0.9849):
[0000320193-19-000066:note_history:21]
|  | Maturities(calendar year) |  | March 30, 2019 |  | September 29, 2018 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 2.400% – 3.850% notes | 2023 | – | 2043 |  | $ | 8,500 |  |  |  | 2.44% | – | 3.91 | % |  | $ | 8,500 |  |  |  | 2.44% | – | 3.91 | % |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2019 |  | 1,000 |  |  |  |  |  | 3.03 | % |  | 1,000 |  |  |  |  |  | 2.64 | % |
| Fixed-rate 2.100% – 4.450% notes | 2019 | – | 2044 |  | 8,500 |  |  |  | 3.03% | – | 4.48 | % |  | 8,500 |  |  |  | 2.64% | – | 4.48 | % |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2020 |  | 1,497 |  |  |  | 1.87% | – | 2.99 | % |  | 1,507 |  |  |  | 1.87% | – | 2.64 | % |
| Fixed-rate 0.350% – 4.375% notes | 2019 | – | 2045 |  | 24,178 |  |  |  | 0.28% | – | 4.51 | % |  | 24,410 |  |  |  | 0.28% | – | 4.51 | % |
| 2016 debt issuances of $24.9 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2021 |  | 850 |  |  |  | 2.88% | – | 3.78 | % |  | 1,350 |  |  |  | 2.48% | – | 3.44 | % |
| Fixed-rate 1.100% – 4.650% notes | 2019 | – | 2046 |  | 22,038 |  |  |  | 1.13% | – | 4.78 | % |  | 23,059 |  |  |  | 1.13% | – | 4.78 | % |
| 2017 debt issuances of $28.7 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2020 | – | 2022 |  | 2,750 |  |  |  | 2.77% | – | 3.20 | % |  | 3,250 |  |  |  | 2.41% | – | 2.84 | % |
| Fixed-rate 0.875% – 4.300% notes | 2019 | – | 2047 |  | 24,929 |  |  |  | 1.54% | – | 4.30 | % |  | 25,617 |  |  |  | 1.54% | – | 4.30 | % |
| 2018 debt issuance of $7.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 1.800% – 3.750% notes | 2019 | – | 2047 |  | 7,000 |  |  |  | 1.83% | – | 3.80 | % |  | 7,000 |  |  |  | 1.83% | – | 3.80 | % |
| Total term debt |  |  |  |  | 101,242 |  |  |  |  |  |  |  | 104,193 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (202 | ) |  |  |  |  |  |  | (218 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | (334 | ) |  |  |  |  |  |  | (1,456 | ) |  |  |  |  |  |
| Less: Current portion of term debt |  |  |  |  | (10,505 | ) |  |  |  |  |  |  | (8,784 | ) |  |  |  |  |  |
| Total non-current portion of term debt |  |  |  |  | $ | 90,201 |  |  |  |  |  |  |  | $ | 93,735 |  |  |  |  |  |  |

- changed (2019-07-31):
[0000320193-19-000076:note_history:22]
A portion of the Company’s Japanese yen–denominated notes is designated as a hedge of the foreign currency exposure of the Company’s net investment in a foreign operation. As of June 29, 2019 and September 29, 2018, the carrying value of the debt designated as a net investment hedge was $1.2 billion and $811 million, respectively. For further discussion regarding the Company’s use of derivative instruments, refer to the Derivative Financial Instruments section of Note 3, “Financial Instruments.”
  (was, 2019-05-01, similarity 0.9907):
[0000320193-19-000066:note_history:22]
A portion of the Company’s Japanese yen–denominated notes is designated as a hedge of the foreign currency exposure of the Company’s net investment in a foreign operation. As of March 30, 2019 and September 29, 2018, the carrying value of the debt designated as a net investment hedge was $1.1 billion and $811 million, respectively. For further discussion regarding the Company’s use of derivative instruments, refer to the Derivative Financial Instruments section of Note 3, “Financial Instruments.”

- changed (2019-07-31):
[0000320193-19-000076:note_history:23]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $790 million and $2.4 billion of interest cost on its term debt for the three- and nine-month periods ended June 29, 2019, respectively. The Company recognized $780 million and $2.2 billion of interest cost on its term debt for the three- and nine-month periods ended June 30, 2018, respectively.
  (was, 2019-05-01, similarity 0.8188):
[0000320193-19-000066:note_history:23]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $828 million and $1.6 billion of interest expense on its term debt for the three- and six-month periods ended March 30, 2019, respectively. The Company recognized $742 million and $1.4 billion of interest expense on its term debt for the three- and six-month periods ended March 31, 2018, respectively.
As of March 30, 2019 and September 29, 2018, the fair value of the Company’s Notes, based on Level 2 inputs, was $103.3 billion and $103.2 billion, respectively.

- added (2019-07-31):
[0000320193-19-000076:note_history:24]
As of June 29, 2019 and September 29, 2018, the fair value of the Company’s Notes, based on Level 2 inputs, was $102.5 billion and $103.2 billion, respectively.

- removed (2019-07-31):
[0000320193-19-000066:note_history:25]
|  | Six Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | (2,484 | ) |  | $ | 4,070 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 10,235 |  |  | 5,550 |  |
| Repayments of commercial paper | (7,787 | ) |  | (9,619 | ) |
| Proceeds from/(Repayments of) commercial paper, net | 2,448 |  |  | (4,069 | ) |
| Total proceeds from/(repayments of) commercial paper, net | $ | (36 | ) |  | $ | 1 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-07-31):
[0000320193-19-000076:note_history:26]
The following table provides a summary of the Company’s term debt as of June 29, 2019 and September 29, 2018:
  (was, 2019-05-01, similarity 0.9548):
[0000320193-19-000066:note_history:26]
The following table provides a summary of the Company’s term debt as of March 30, 2019 and September 29, 2018:

- changed (2019-07-31):
[0000320193-19-000076:note_history:27]
|  | Maturities(calendar year) |  | June 29, 2019 |  | September 29, 2018 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 2.400% – 3.850% notes | 2023 | – | 2043 |  | $ | 8,500 |  |  |  | 2.44% | – | 3.91 | % |  | $ | 8,500 |  |  |  | 2.44% | – | 3.91 | % |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | — |  | — |  |  |  |  |  | — | % |  | 1,000 |  |  |  |  |  | 2.64 | % |
| Fixed-rate 2.850% – 4.450% notes | 2021 | – | 2044 |  | 6,500 |  |  |  | 3.12% | – | 4.48 | % |  | 8,500 |  |  |  | 2.64% | – | 4.48 | % |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2020 |  | 1,488 |  |  |  | 1.87% | – | 2.84 | % |  | 1,507 |  |  |  | 1.87% | – | 2.64 | % |
| Fixed-rate 0.350% – 4.375% notes | 2019 | – | 2045 |  | 24,223 |  |  |  | 0.28% | – | 4.51 | % |  | 24,410 |  |  |  | 0.28% | – | 4.51 | % |
| 2016 debt issuances of $24.9 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2021 |  | 850 |  |  |  | 2.71% | – | 3.65 | % |  | 1,350 |  |  |  | 2.48% | – | 3.44 | % |
| Fixed-rate 1.100% – 4.650% notes | 2019 | – | 2046 |  | 22,022 |  |  |  | 1.13% | – | 4.78 | % |  | 23,059 |  |  |  | 1.13% | – | 4.78 | % |
| 2017 debt issuances of $28.7 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2020 | – | 2022 |  | 2,750 |  |  |  | 2.61% | – | 3.06 | % |  | 3,250 |  |  |  | 2.41% | – | 2.84 | % |
| Fixed-rate 0.875% – 4.300% notes | 2019 | – | 2047 |  | 24,989 |  |  |  | 1.54% | – | 4.30 | % |  | 25,617 |  |  |  | 1.54% | – | 4.30 | % |
| 2018 debt issuance of $7.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 1.800% – 3.750% notes | 2019 | – | 2047 |  | 7,000 |  |  |  | 1.83% | – | 3.80 | % |  | 7,000 |  |  |  | 1.83% | – | 3.80 | % |
| Total term debt |  |  |  |  | 98,322 |  |  |  |  |  |  |  | 104,193 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (194 | ) |  |  |  |  |  |  | (218 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | 337 |  |  |  |  |  |  |  | (1,456 | ) |  |  |  |  |  |
| Less: Current portion of term debt |  |  |  |  | (13,529 | ) |  |  |  |  |  |  | (8,784 | ) |  |  |  |  |  |
| Total non-current portion of term debt |  |  |  |  | $ | 84,936 |  |  |  |  |  |  |  | $ | 93,735 |  |  |  |  |  |  |
  (was, 2019-05-01, similarity 0.9849):
[0000320193-19-000066:note_history:27]
|  | Maturities(calendar year) |  | March 30, 2019 |  | September 29, 2018 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 2.400% – 3.850% notes | 2023 | – | 2043 |  | $ | 8,500 |  |  |  | 2.44% | – | 3.91 | % |  | $ | 8,500 |  |  |  | 2.44% | – | 3.91 | % |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2019 |  | 1,000 |  |  |  |  |  | 3.03 | % |  | 1,000 |  |  |  |  |  | 2.64 | % |
| Fixed-rate 2.100% – 4.450% notes | 2019 | – | 2044 |  | 8,500 |  |  |  | 3.03% | – | 4.48 | % |  | 8,500 |  |  |  | 2.64% | – | 4.48 | % |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2020 |  | 1,497 |  |  |  | 1.87% | – | 2.99 | % |  | 1,507 |  |  |  | 1.87% | – | 2.64 | % |
| Fixed-rate 0.350% – 4.375% notes | 2019 | – | 2045 |  | 24,178 |  |  |  | 0.28% | – | 4.51 | % |  | 24,410 |  |  |  | 0.28% | – | 4.51 | % |
| 2016 debt issuances of $24.9 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2021 |  | 850 |  |  |  | 2.88% | – | 3.78 | % |  | 1,350 |  |  |  | 2.48% | – | 3.44 | % |
| Fixed-rate 1.100% – 4.650% notes | 2019 | – | 2046 |  | 22,038 |  |  |  | 1.13% | – | 4.78 | % |  | 23,059 |  |  |  | 1.13% | – | 4.78 | % |
| 2017 debt issuances of $28.7 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2020 | – | 2022 |  | 2,750 |  |  |  | 2.77% | – | 3.20 | % |  | 3,250 |  |  |  | 2.41% | – | 2.84 | % |
| Fixed-rate 0.875% – 4.300% notes | 2019 | – | 2047 |  | 24,929 |  |  |  | 1.54% | – | 4.30 | % |  | 25,617 |  |  |  | 1.54% | – | 4.30 | % |
| 2018 debt issuance of $7.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 1.800% – 3.750% notes | 2019 | – | 2047 |  | 7,000 |  |  |  | 1.83% | – | 3.80 | % |  | 7,000 |  |  |  | 1.83% | – | 3.80 | % |
| Total term debt |  |  |  |  | 101,242 |  |  |  |  |  |  |  | 104,193 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (202 | ) |  |  |  |  |  |  | (218 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | (334 | ) |  |  |  |  |  |  | (1,456 | ) |  |  |  |  |  |
| Less: Current portion of term debt |  |  |  |  | (10,505 | ) |  |  |  |  |  |  | (8,784 | ) |  |  |  |  |  |
| Total non-current portion of term debt |  |  |  |  | $ | 90,201 |  |  |  |  |  |  |  | $ | 93,735 |  |  |  |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-07-31):
[0000320193-19-000076:note_history:28]
Net sales disaggregated by significant products and services for the three- and nine-month periods ended June 29, 2019 and June 30, 2018 were as follows (in millions):
  (was, 2019-05-01, similarity 0.927):
[0000320193-19-000066:note_history:28]
Net sales disaggregated by significant products and services for the three- and six-month periods ended March 30, 2019 and March 31, 2018 were as follows (in millions):

- changed (2019-07-31):
[0000320193-19-000076:note_history:29]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| iPhone (1) | $ | 25,986 |  |  | $ | 29,470 |  |  | $ | 109,019 |  |  | $ | 128,133 |  |
| Mac (1) | 5,820 |  |  | 5,258 |  |  | 18,749 |  |  | 17,858 |  |
| iPad (1) | 5,023 |  |  | 4,634 |  |  | 16,624 |  |  | 14,397 |  |
| Wearables, Home and Accessories (1)(2) | 5,525 |  |  | 3,733 |  |  | 17,962 |  |  | 13,158 |  |
| Services (3) | 11,455 |  |  | 10,170 |  |  | 33,780 |  |  | 29,149 |  |
| Total net sales (4) | $ | 53,809 |  |  | $ | 53,265 |  |  | $ | 196,134 |  |  | $ | 202,695 |  |
  (was, 2019-05-01, similarity 0.8457):
[0000320193-19-000066:note_history:29]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| iPhone (1) | $ | 31,051 |  |  | $ | 37,559 |  |  | $ | 83,033 |  |  | $ | 98,663 |  |
| Mac (1) | 5,513 |  |  | 5,776 |  |  | 12,929 |  |  | 12,600 |  |
| iPad (1) | 4,872 |  |  | 4,008 |  |  | 11,601 |  |  | 9,763 |  |
| Wearables, Home and Accessories (1)(2) | 5,129 |  |  | 3,944 |  |  | 12,437 |  |  | 9,425 |  |
| Services (3) | 11,450 |  |  | 9,850 |  |  | 22,325 |  |  | 18,979 |  |
| Total net sales (4) | $ | 58,015 |  |  | $ | 61,137 |  |  | $ | 142,325 |  |  | $ | 149,430 |  |

- added (2019-07-31):
[0000320193-19-000076:note_history:30]
(4)

- added (2019-07-31):
[0000320193-19-000076:note_history:31]
Includes $2.0 billion of revenue recognized in the three months ended June 29, 2019 that was included in deferred revenue as of March 30, 2019, $2.0 billion of revenue recognized in the three months ended June 30, 2018 that was included in deferred revenue as of March 31, 2018, $4.9 billion of revenue recognized in the nine months ended June 29, 2019 that was included in deferred revenue as of September 29, 2018, and $4.7 billion of revenue recognized in the nine months ended June 30, 2018 that was included in deferred revenue as of September 30, 2017.

- removed (2019-07-31):
[0000320193-19-000066:note_history:32]
(4)
Includes $1.9 billion and $2.2 billion of revenue recognized in the three months ended March 30, 2019 and March 31, 2018, respectively, and $3.8 billion and $3.5 billion of revenue recognized in the six months ended March 30, 2019 and March 31, 2018, respectively, that was included in deferred revenue at the beginning of each respective period.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2019-07-31):
[0000320193-19-000076:note_history:33]
As of June 29, 2019 and September 29, 2018, the Company had total deferred revenue of $8.0 billion and $8.8 billion, respectively. As of June 29, 2019, the Company expects 68% of total deferred revenue to be realized in less than a year, 25% within one-to-two years, 6% within two-to-three years and 1% in greater than three years.

- changed (2019-07-31):
[0000320193-19-000076:note_history:34]
Net sales disaggregated by significant products and services for the three- and nine-month periods ended June 29, 2019 and June 30, 2018 were as follows (in millions):
  (was, 2019-05-01, similarity 0.927):
[0000320193-19-000066:note_history:34]
Net sales disaggregated by significant products and services for the three- and six-month periods ended March 30, 2019 and March 31, 2018 were as follows (in millions):

- changed (2019-07-31):
[0000320193-19-000076:note_history:35]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| iPhone (1) | $ | 25,986 |  |  | $ | 29,470 |  |  | $ | 109,019 |  |  | $ | 128,133 |  |
| Mac (1) | 5,820 |  |  | 5,258 |  |  | 18,749 |  |  | 17,858 |  |
| iPad (1) | 5,023 |  |  | 4,634 |  |  | 16,624 |  |  | 14,397 |  |
| Wearables, Home and Accessories (1)(2) | 5,525 |  |  | 3,733 |  |  | 17,962 |  |  | 13,158 |  |
| Services (3) | 11,455 |  |  | 10,170 |  |  | 33,780 |  |  | 29,149 |  |
| Total net sales (4) | $ | 53,809 |  |  | $ | 53,265 |  |  | $ | 196,134 |  |  | $ | 202,695 |  |
  (was, 2019-05-01, similarity 0.8457):
[0000320193-19-000066:note_history:35]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| iPhone (1) | $ | 31,051 |  |  | $ | 37,559 |  |  | $ | 83,033 |  |  | $ | 98,663 |  |
| Mac (1) | 5,513 |  |  | 5,776 |  |  | 12,929 |  |  | 12,600 |  |
| iPad (1) | 4,872 |  |  | 4,008 |  |  | 11,601 |  |  | 9,763 |  |
| Wearables, Home and Accessories (1)(2) | 5,129 |  |  | 3,944 |  |  | 12,437 |  |  | 9,425 |  |
| Services (3) | 11,450 |  |  | 9,850 |  |  | 22,325 |  |  | 18,979 |  |
| Total net sales (4) | $ | 58,015 |  |  | $ | 61,137 |  |  | $ | 142,325 |  |  | $ | 149,430 |  |

- added (2019-07-31):
[0000320193-19-000076:note_history:36]
| (4) | Includes $2.0 billion of revenue recognized in the three months ended June 29, 2019 that was included in deferred revenue as of March 30, 2019, $2.0 billion of revenue recognized in the three months ended June 30, 2018 that was included in deferred revenue as of March 31, 2018, $4.9 billion of revenue recognized in the nine months ended June 29, 2019 that was included in deferred revenue as of September 29, 2018, and $4.7 billion of revenue recognized in the nine months ended June 30, 2018 that was included in deferred revenue as of September 30, 2017. |

- changed (2019-07-31):
[0000320193-19-000076:note_history:37]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 11, “Segment Information and Geographic Data” for the three- and nine-month periods ended June 29, 2019 and June 30, 2018.
  (was, 2019-05-01, similarity 0.894):
[0000320193-19-000066:note_history:37]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 11, “Segment Information and Geographic Data” for the three- and six-month periods ended March 30, 2019 and March 31, 2018.

- removed (2019-07-31):
[0000320193-19-000066:note_history:38]
As of March 30, 2019 and September 29, 2018, the Company had total deferred revenue of $8.2 billion and $8.8 billion, respectively. As of March 30, 2019, the Company expects 67% of total deferred revenue to be realized in less than a year, 26% within one-to-two years, 6% within two-to-three years and 1% in greater than three years.

- removed (2019-07-31):
[0000320193-19-000066:note_history:39]
| (4) | Includes $1.9 billion and $2.2 billion of revenue recognized in the three months ended March 30, 2019 and March 31, 2018, respectively, and $3.8 billion and $3.5 billion of revenue recognized in the six months ended March 30, 2019 and March 31, 2018, respectively, that was included in deferred revenue at the beginning of each respective period. |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-07-31):
[0000320193-19-000076:note_history:40]
Net sales consist of revenue from the sale of iPhone, Mac, iPad, services and other products. The Company recognizes revenue at the amount to which it expects to be entitled when control of the products or services is transferred to its customers. Control is generally transferred when the Company has a present right to payment and title and the significant risks and rewards of ownership of products or services are transferred to its customers. For most of the Company’s products net sales, control transfers when products are shipped. For the Company’s services net sales, control transfers over time as services are delivered. Payment for products and services net sales is collected within a short period of time following transfer of control or commencement of delivery of services, as applicable.
  (was, 2019-05-01, similarity 0.8864):
[0000320193-19-000066:note_history:40]
Net sales consist of revenue from the sale of iPhone, Mac, iPad, services and other products. The Company recognizes revenue at the amount to which it expects to be entitled when control of the products or services is transferred to its customers. Control is generally transferred when the Company has a present right to payment and title and the significant risks and rewards of ownership of products or services are transferred to its customers. For most of the Company’s products net sales, control transfers when products are shipped. For the Company’s services net sales, control transfers over time as services are delivered. Payment for products and services net sales is collected within a short period of time following transfer of control or commencement of delivery of services, as applicable.
The Company records reductions to products net sales related to future product returns, price protection and other customer incentive programs based on the Company’s expectations and historical experience.

- added (2019-07-31):
[0000320193-19-000076:note_history:41]
The Company records reductions to products net sales related to future product returns, price protection and other customer incentive programs based on the Company’s expectations and historical experience.

- changed (2019-07-31):
[0000320193-19-000076:note_history:42]
For the sale of third-party products where the Company obtains control of the product before transferring it to the customer, the Company recognizes revenue based on the gross amount billed to customers. The Company considers multiple factors when determining whether it obtains control of third-party products including, but not limited to, evaluating if it has the ability to establish the price of the product, retains inventory risk for tangible products or has the responsibility for ensuring acceptability of the product. For third-party applications sold through the App Store®, Mac App Store and TV App Store and certain digital content sold through the iTunes Store®, the Company does not obtain control of the product before transferring it to the customer. Therefore, the Company accounts for such sales on a net basis by recognizing in services net sales only the commission it retains.
  (was, 2019-05-01, similarity 0.8791):
[0000320193-19-000066:note_history:42]
For the sale of third-party products where the Company obtains control of the product before transferring it to the customer, the Company recognizes revenue based on the gross amount billed to customers. The Company considers multiple factors when determining whether it obtains control of third-party products including, but not limited to, evaluating if it has the ability to establish the price of the product, retains inventory risk for tangible products or has the responsibility for ensuring acceptability of the product. For third-party applications sold through the App Store®, Mac App Store and TV App Store and certain digital content sold through the iTunes Store®, the Company does not obtain control of the product before transferring it to the customer. Therefore, the Company accounts for such sales on a net basis by recognizing in services net sales only the commission it retains.
The Company has elected to record revenue net of taxes collected from customers that are remitted to governmental authorities, with the collected taxes recorded within other current liabilities until remitted to the relevant government authority.

- added (2019-07-31):
[0000320193-19-000076:note_history:43]
The Company has elected to record revenue net of taxes collected from customers that are remitted to governmental authorities, with the collected taxes recorded within other current liabilities until remitted to the relevant government authority.
