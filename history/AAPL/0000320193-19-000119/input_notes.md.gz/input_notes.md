# AAPL notes — 0000320193-19-000119


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000320193-19-000119:notes:1]
Summary of Significant Accounting Policies
Basis of Presentation and Preparation

[0000320193-19-000119:notes:2]
The accompanying consolidated financial statements include the accounts of Apple Inc. and its wholly owned subsidiaries (collectively “Apple” or the “Company”). Intercompany accounts and transactions have been eliminated. In the opinion of the Company’s management, the consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these consolidated financial statements and accompanying notes in conformity with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported. Actual results could differ materially from those estimates. Certain prior period amounts in the consolidated financial statements and accompanying notes have been reclassified to conform to the current period’s presentation.

[0000320193-19-000119:notes:3]
The Company’s fiscal year is the 52- or 53-week period that ends on the last Saturday of September. The Company’s fiscal years 2019 and 2018 spanned 52 weeks each, whereas fiscal year 2017 included 53 weeks. A 14th week was included in the first fiscal quarter of 2017, as is done every five or six years, to realign the Company’s fiscal quarters with calendar quarters. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in September and the associated quarters, months and periods of those fiscal years.

[0000320193-19-000119:notes:4]
Recently Adopted Accounting Pronouncements

[0000320193-19-000119:notes:5]
Revenue Recognition

[0000320193-19-000119:notes:6]
In the first quarter of 2019, the Company adopted the Financial Accounting Standards Board’s (the “FASB”) Accounting Standards Update (“ASU”) No. 2014-09, Revenue from Contracts with Customers (Topic 606) (“ASU 2014-09”), and additional ASUs issued to clarify the guidance in ASU 2014-09 (collectively the “new revenue standard”), which amends the existing accounting standards for revenue recognition. The Company adopted the new revenue standard utilizing the full retrospective transition method. The Company did not restate total net sales in the prior periods presented, as the adoption of the new revenue standard did not have a material impact on previously reported amounts.

[0000320193-19-000119:notes:7]
Additionally, beginning in the first quarter of 2019, the Company classified the amortization of the deferred value of Maps, Siri and free iCloud services, which are bundled in the sales price of iPhone, Mac, iPad and certain other products, in Services net sales. Historically, the Company classified the amortization of these amounts in Products net sales consistent with its management reporting framework. As a result, Products and Services net sales for 2018 and 2017 were reclassified to conform to the 2019 presentation.

[0000320193-19-000119:notes:8]
Financial Instruments

[0000320193-19-000119:notes:9]
In the first quarter of 2019, the Company adopted FASB ASU No. 2016-01, Financial Instruments – Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities (“ASU 2016-01”), which updates certain aspects of the recognition, measurement, presentation and disclosure of financial instruments. The adoption of ASU 2016-01 did not have a material impact on the Company’s consolidated financial statements.

[0000320193-19-000119:notes:10]
Income Taxes

[0000320193-19-000119:notes:11]
In the first quarter of 2019, the Company adopted FASB ASU No. 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory (“ASU 2016-16”), which requires the recognition of the income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. The Company adopted ASU 2016-16 utilizing the modified retrospective transition method. Upon adoption, the Company recorded $2.7 billion of net deferred tax assets, reduced other non-current assets by $128 million, and increased retained earnings by $2.6 billion on its Consolidated Balance Sheet. The Company will recognize incremental deferred income tax expense as these net deferred tax assets are utilized.

[0000320193-19-000119:notes:12]
Restricted Cash

[0000320193-19-000119:notes:13]
In the first quarter of 2019, the Company adopted FASB ASU No. 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash (“ASU 2016-18”), which enhances and clarifies the guidance on the classification and presentation of restricted cash in the statement of cash flows and requires additional disclosures about restricted cash balances.

[0000320193-19-000119:notes:14]
Advertising Costs

[0000320193-19-000119:notes:15]
Advertising costs are expensed as incurred and included in selling, general and administrative expenses.

[0000320193-19-000119:notes:16]
Share-Based Compensation

[0000320193-19-000119:notes:17]
The Company generally measures share-based compensation based on the closing price of the Company’s common stock on the date of grant, and recognizes expense on a straight-line basis for its estimate of equity awards that will ultimately vest. Further information regarding share-based compensation can be found in Note 9, “Benefit Plans.”

[0000320193-19-000119:notes:18]
Earnings Per Share

[0000320193-19-000119:notes:19]
The following table shows the computation of basic and diluted earnings per share for 2019, 2018 and 2017 (net income in millions and shares in thousands):

[0000320193-19-000119:notes:20]
|  | 2019 |  | 2018 |  | 2017 |
| Numerator: |  |  |  |  |  |
| Net income | $ | 55,256 |  |  | $ | 59,531 |  |  | $ | 48,351 |  |
| Denominator: |  |  |  |  |  |
| Weighted-average basic shares outstanding | 4,617,834 |  |  | 4,955,377 |  |  | 5,217,242 |  |
| Effect of dilutive securities | 31,079 |  |  | 44,732 |  |  | 34,450 |  |
| Weighted-average diluted shares | 4,648,913 |  |  | 5,000,109 |  |  | 5,251,692 |  |
| Basic earnings per share | $ | 11.97 |  |  | $ | 12.01 |  |  | $ | 9.27 |  |
| Diluted earnings per share | $ | 11.89 |  |  | $ | 11.91 |  |  | $ | 9.21 |  |

[0000320193-19-000119:notes:21]
The Company applies the treasury stock method to determine the dilutive effect of potentially dilutive securities. Potentially dilutive securities representing 15.5 million shares of common stock were excluded from the computation of diluted earnings per share for 2019 because their effect would have been antidilutive.

[0000320193-19-000119:notes:22]
Cash Equivalents and Marketable Securities

[0000320193-19-000119:notes:23]
All highly liquid investments with maturities of three months or less at the date of purchase are classified as cash equivalents.

[0000320193-19-000119:notes:24]
The Company’s investments in marketable debt securities have been classified and accounted for as available-for-sale. The Company classifies its marketable debt securities as either short-term or long-term based on each instrument’s underlying contractual maturity date. Unrealized gains and losses on marketable debt securities classified as available-for-sale are recognized in other comprehensive income/(loss) (“OCI”).

[0000320193-19-000119:notes:25]
The Company’s investments in marketable equity securities are classified based on the nature of the securities and their availability for use in current operations. The Company’s marketable equity securities are measured at fair value with gains and losses recognized in other income/(expense), net (“OI&E”).

[0000320193-19-000119:notes:26]
The cost of securities sold is determined using the specific identification method.

[0000320193-19-000119:notes:27]
Inventories

[0000320193-19-000119:notes:28]
Inventories are measured using the first-in, first-out method.

[0000320193-19-000119:notes:29]
Property, Plant and Equipment

[0000320193-19-000119:notes:30]
Depreciation on property, plant and equipment is recognized on a straight-line basis over the estimated useful lives of the assets, which for buildings is the lesser of 30 years or the remaining life of the underlying building; between one and five years for machinery and equipment, including product tooling and manufacturing process equipment; and the shorter of lease term or useful life for leasehold improvements. Capitalized costs related to internal-use software are amortized on a straight-line basis over the estimated useful lives of the assets, which range from three to five years. Depreciation and amortization expense on property and equipment was $11.3 billion, $9.3 billion and $8.2 billion during 2019, 2018 and 2017, respectively.

[0000320193-19-000119:notes:31]
Non-cash investing activities involving property, plant and equipment resulted in a net increase/(decrease) to accounts payable and other current liabilities of $(2.9) billion and $3.4 billion during 2019 and 2018, respectively.

[0000320193-19-000119:notes:32]
Non-Marketable Securities

[0000320193-19-000119:notes:33]
The Company has elected to apply the measurement alternative to equity securities without readily determinable fair values. As such, the Company’s non-marketable equity securities are measured at cost, less any impairment, and are adjusted for changes in fair value resulting from observable transactions for identical or similar investments of the same issuer. Gains and losses on non-marketable equity securities are recognized in OI&E.

[0000320193-19-000119:notes:34]
Restricted Cash and Restricted Marketable Securities

[0000320193-19-000119:notes:35]
The Company considers cash and marketable securities to be restricted when withdrawal or general use is legally restricted. The Company records restricted cash as other assets in the Consolidated Balance Sheets, and determines current or non-current classification based on the expected duration of the restriction. The Company records restricted marketable securities as current or non-current marketable securities in the Consolidated Balance Sheets based on the classification of the underlying securities.

[0000320193-19-000119:notes:36]
Fair Value Measurements

[0000320193-19-000119:notes:37]
The fair values of the Company’s money market funds and certain marketable equity securities are based on quoted prices in active markets for identical assets. The valuation techniques used to measure the fair value of the Company’s debt instruments and all other financial instruments, which generally have counterparties with high credit ratings, are based on quoted market prices or model-driven valuations using significant inputs derived from or corroborated by observable market data.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000320193-19-000119:notes:38]
Level 2 fair value estimates are based on observable inputs other than quoted prices in active markets for identical assets and liabilities, quoted prices for identical or similar assets or liabilities in inactive markets, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities.

[0000320193-19-000119:notes:39]
Level 1 fair value estimates are based on quoted prices in active markets for identical assets or liabilities.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0000320193-19-000119:notes:40]
Revenue Recognition
Net sales consist of revenue from the sale of iPhone, Mac, iPad, Services and other products. The Company recognizes revenue at the amount to which it expects to be entitled when control of the products or services is transferred to its customers. Control is generally transferred when the Company has a present right to payment and title and the significant risks and rewards of ownership of products or services are transferred to its customers. For most of the Company’s Products net sales, control transfers when products are shipped. For the Company’s Services net sales, control transfers over time as services are delivered. Payment for Products and Services net sales is collected within a short period following transfer of control or commencement of delivery of services, as applicable.

[0000320193-19-000119:notes:41]
The Company records reductions to Products net sales related to future product returns, price protection and other customer incentive programs based on the Company’s expectations and historical experience.

[0000320193-19-000119:notes:42]
For arrangements with multiple performance obligations, which represent promises within an arrangement that are capable of being distinct, the Company allocates revenue to all distinct performance obligations based on their relative stand-alone selling prices (“SSPs”). When available, the Company uses observable prices to determine SSPs. When observable prices are not available, SSPs are established that reflect the Company’s best estimates of what the selling prices of the performance obligations would be if they were sold regularly on a stand-alone basis. The Company’s process for estimating SSPs without observable prices considers multiple factors that may vary depending upon the unique facts and circumstances related to each performance obligation including, where applicable, prices charged by the Company for similar offerings, market trends in the pricing for similar offerings, product-specific business objectives and the estimated cost to provide the performance obligation.

[0000320193-19-000119:notes:43]
The Company has identified up to three performance obligations regularly included in arrangements involving the sale of iPhone, Mac, iPad and certain other products. The first performance obligation, which represents the substantial portion of the allocated sales price, is the hardware and bundled software delivered at the time of sale. The second performance obligation is the right to receive certain product-related bundled services, which include iCloud, Siri and Maps. The third performance obligation is the right to receive, on a when-and-if-available basis, future unspecified software upgrades relating to the software bundled with each device. The Company allocates revenue and any related discounts to these performance obligations based on their relative SSPs. Because the Company lacks observable prices for the undelivered performance obligations, the allocation of revenue is based on the Company’s estimated SSPs. Revenue allocated to the delivered hardware and bundled software is recognized when control has transferred to the customer, which generally occurs when the product is shipped. Revenue allocated to the product-related bundled services and unspecified software upgrade rights is deferred and recognized on a straight-line basis over the estimated period they are expected to be provided. Cost of sales related to delivered hardware and bundled software, including estimated warranty costs, are recognized at the time of sale. Costs incurred to provide product-related bundled services and unspecified software upgrade rights are recognized as cost of sales as incurred.

[0000320193-19-000119:notes:44]
For certain long-term service arrangements, the Company has performance obligations for services it has not yet delivered. For these arrangements, the Company does not have a right to bill for the undelivered services. The Company has determined that any unbilled consideration relates entirely to the value of the undelivered services. Accordingly, the Company has not recognized revenue, and has elected not to disclose amounts, related to these undelivered services.

[0000320193-19-000119:notes:45]
For the sale of third-party products where the Company obtains control of the product before transferring it to the customer, the Company recognizes revenue based on the gross amount billed to customers. The Company considers multiple factors when determining whether it obtains control of third-party products including, but not limited to, evaluating if it can establish the price of the product, retains inventory risk for tangible products or has the responsibility for ensuring acceptability of the product. For third-party applications sold through the App Store, Mac App Store, TV App Store and Watch App Store and certain digital content sold through the Company’s other digital content stores, the Company does not obtain control of the product before transferring it to the customer. Therefore, the Company accounts for such sales on a net basis by recognizing in Services net sales only the commission it retains.

[0000320193-19-000119:notes:46]
The Company has elected to record revenue net of taxes collected from customers that are remitted to governmental authorities, with the collected taxes recorded within other current liabilities until remitted to the relevant government authority.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000320193-19-000119:notes:47]
Deferred Revenue

[0000320193-19-000119:notes:48]
As of September 28, 2019 and September 29, 2018, the Company had total deferred revenue of $8.1 billion and $8.8 billion, respectively. As of September 28, 2019, the Company expects 68% of total deferred revenue to be realized in less than a year, 25% within one-to-two years, 6% within two-to-three years and 1% in greater than three years.

[0000320193-19-000119:notes:49]
Disaggregated Revenue

[0000320193-19-000119:notes:50]
Net sales disaggregated by significant products and services for 2019, 2018 and 2017 were as follows (in millions):

[0000320193-19-000119:notes:51]
|  | 2019 |  | 2018 |  | 2017 |
| iPhone (1) | $ | 142,381 |  |  | $ | 164,888 |  |  | $ | 139,337 |  |
| Mac (1) | 25,740 |  |  | 25,198 |  |  | 25,569 |  |
| iPad (1) | 21,280 |  |  | 18,380 |  |  | 18,802 |  |
| Wearables, Home and Accessories (1)(2) | 24,482 |  |  | 17,381 |  |  | 12,826 |  |
| Services (3) | 46,291 |  |  | 39,748 |  |  | 32,700 |  |
| Total net sales (4) | $ | 260,174 |  |  | $ | 265,595 |  |  | $ | 229,234 |  |

[0000320193-19-000119:notes:52]
| (1) | Products net sales include amortization of the deferred value of unspecified software upgrade rights, which are bundled in the sales price of the respective product. |

[0000320193-19-000119:notes:53]
| (2) | Wearables, Home and Accessories net sales include sales of AirPods, Apple TV, Apple Watch, Beats products, HomePod, iPod touch and Apple-branded and third-party accessories. |

[0000320193-19-000119:notes:54]
| (3) | Services net sales include sales from the Company’s digital content stores and streaming services, AppleCare, licensing and other services. Services net sales also include amortization of the deferred value of Maps, Siri and free iCloud services, which are bundled in the sales price of certain products. |

[0000320193-19-000119:notes:55]
| (4) | Includes $5.9 billion of revenue recognized in 2019 that was included in deferred revenue as of September 29, 2018, $5.8 billion of revenue recognized in 2018 that was included in deferred revenue as of September 30, 2017, and $6.3 billion of revenue recognized in 2017 that was included in deferred revenue as of September 24, 2016. |

[0000320193-19-000119:notes:56]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 11, “Segment Information and Geographic Data” for 2019, 2018 and 2017.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000320193-19-000119:notes:57]
Financial Instruments
Cash, Cash Equivalents and Marketable Securities

[0000320193-19-000119:notes:58]
The following tables show the Company’s cash and marketable securities by significant investment category as of September 28, 2019 and September 29, 2018 (in millions):

[0000320193-19-000119:notes:59]
|  | 2019 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | Short-TermMarketableSecurities |  | Long-TermMarketableSecurities |
| Cash | $ | 12,204 |  |  | $ | — |  |  | $ | — |  |  | $ | 12,204 |  |  | $ | 12,204 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 15,897 |  |  | — |  |  | — |  |  | 15,897 |  |  | 15,897 |  |  | — |  |  | — |  |
| Subtotal | 15,897 |  |  | — |  |  | — |  |  | 15,897 |  |  | 15,897 |  |  | — |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 30,293 |  |  | 33 |  |  | (62 | ) |  | 30,264 |  |  | 6,165 |  |  | 9,817 |  |  | 14,282 |  |
| U.S. agency securities | 9,767 |  |  | 1 |  |  | (3 | ) |  | 9,765 |  |  | 6,489 |  |  | 2,249 |  |  | 1,027 |  |
| Non-U.S. government securities | 19,821 |  |  | 337 |  |  | (50 | ) |  | 20,108 |  |  | 749 |  |  | 3,168 |  |  | 16,191 |  |
| Certificates of deposit and time deposits | 4,041 |  |  | — |  |  | — |  |  | 4,041 |  |  | 2,024 |  |  | 1,922 |  |  | 95 |  |
| Commercial paper | 12,433 |  |  | — |  |  | — |  |  | 12,433 |  |  | 5,193 |  |  | 7,240 |  |  | — |  |
| Corporate debt securities | 85,383 |  |  | 756 |  |  | (92 | ) |  | 86,047 |  |  | 123 |  |  | 26,127 |  |  | 59,797 |  |
| Municipal securities | 958 |  |  | 8 |  |  | (1 | ) |  | 965 |  |  | — |  |  | 68 |  |  | 897 |  |
| Mortgage- and asset-backed securities | 14,180 |  |  | 67 |  |  | (73 | ) |  | 14,174 |  |  | — |  |  | 1,122 |  |  | 13,052 |  |
| Subtotal | 176,876 |  |  | 1,202 |  |  | (281 | ) |  | 177,797 |  |  | 20,743 |  |  | 51,713 |  |  | 105,341 |  |
| Total (3) | $ | 204,977 |  |  | $ | 1,202 |  |  | $ | (281 | ) |  | $ | 205,898 |  |  | $ | 48,844 |  |  | $ | 51,713 |  |  | $ | 105,341 |  |

[0000320193-19-000119:notes:60]
|  | 2018 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | Short-TermMarketableSecurities |  | Long-TermMarketableSecurities |
| Cash | $ | 11,575 |  |  | $ | — |  |  | $ | — |  |  | $ | 11,575 |  |  | $ | 11,575 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 8,083 |  |  | — |  |  | — |  |  | 8,083 |  |  | 8,083 |  |  | — |  |  | — |  |
| Mutual funds | 799 |  |  | — |  |  | (116 | ) |  | 683 |  |  | — |  |  | 683 |  |  | — |  |
| Subtotal | 8,882 |  |  | — |  |  | (116 | ) |  | 8,766 |  |  | 8,083 |  |  | 683 |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 47,296 |  |  | — |  |  | (1,202 | ) |  | 46,094 |  |  | 1,613 |  |  | 7,606 |  |  | 36,875 |  |
| U.S. agency securities | 4,127 |  |  | — |  |  | (48 | ) |  | 4,079 |  |  | 1,732 |  |  | 360 |  |  | 1,987 |  |
| Non-U.S. government securities | 21,601 |  |  | 49 |  |  | (250 | ) |  | 21,400 |  |  | — |  |  | 3,355 |  |  | 18,045 |  |
| Certificates of deposit and time deposits | 3,074 |  |  | — |  |  | — |  |  | 3,074 |  |  | 1,247 |  |  | 1,330 |  |  | 497 |  |
| Commercial paper | 2,573 |  |  | — |  |  | — |  |  | 2,573 |  |  | 1,663 |  |  | 910 |  |  | — |  |
| Corporate debt securities | 123,001 |  |  | 152 |  |  | (2,038 | ) |  | 121,115 |  |  | — |  |  | 25,162 |  |  | 95,953 |  |
| Municipal securities | 946 |  |  | — |  |  | (12 | ) |  | 934 |  |  | — |  |  | 178 |  |  | 756 |  |
| Mortgage- and asset-backed securities | 18,105 |  |  | 8 |  |  | (623 | ) |  | 17,490 |  |  | — |  |  | 804 |  |  | 16,686 |  |
| Subtotal | 220,723 |  |  | 209 |  |  | (4,173 | ) |  | 216,759 |  |  | 6,255 |  |  | 39,705 |  |  | 170,799 |  |
| Total (3) | $ | 241,180 |  |  | $ | 209 |  |  | $ | (4,289 | ) |  | $ | 237,100 |  |  | $ | 25,913 |  |  | $ | 40,388 |  |  | $ | 170,799 |  |

[0000320193-19-000119:notes:61]
| (1) | Level 1 fair value estimates are based on quoted prices in active markets for identical assets or liabilities. |

[0000320193-19-000119:notes:62]
| (2) | Level 2 fair value estimates are based on observable inputs other than quoted prices in active markets for identical assets and liabilities, quoted prices for identical or similar assets or liabilities in inactive markets, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities. |

[0000320193-19-000119:notes:63]
| (3) | As of September 28, 2019 and September 29, 2018, total cash, cash equivalents and marketable securities included $18.9 billion and $20.3 billion, respectively, that was restricted from general use, related to the State Aid Decision (refer to Note 5, “Income Taxes”) and other agreements. |

[0000320193-19-000119:notes:64]
The Company may sell certain of its marketable debt securities prior to their stated maturities for reasons including, but not limited to, managing liquidity, credit risk, duration and asset allocation. The maturities of the Company’s long-term marketable debt securities generally range from one to five years.

[0000320193-19-000119:notes:65]
The following tables show information about the Company’s marketable securities that had been in a continuous unrealized loss position for less than 12 months and for 12 months or greater as of September 28, 2019 and September 29, 2018 (in millions):

[0000320193-19-000119:notes:66]
|  | 2019 |
|  | Continuous Unrealized Losses |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
| Fair value of marketable debt securities | $ | 28,151 |  |  | $ | 28,167 |  |  | $ | 56,318 |  |
| Unrealized losses | $ | (138 | ) |  | $ | (143 | ) |  | $ | (281 | ) |

[0000320193-19-000119:notes:67]
|  | 2018 |
|  | Continuous Unrealized Losses |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
| Fair value of marketable securities | $ | 126,238 |  |  | $ | 60,599 |  |  | $ | 186,837 |  |
| Unrealized losses | $ | (2,400 | ) |  | $ | (1,889 | ) |  | $ | (4,289 | ) |

[0000320193-19-000119:notes:68]
The Company typically invests in highly rated securities, with the primary objective of minimizing the potential risk of principal loss. The Company’s investment policy generally requires securities to be investment grade and limits the amount of credit exposure to any one issuer. Fair values were determined for each individual security in the investment portfolio. When evaluating a marketable debt security for other-than-temporary impairment, the Company reviews factors such as the duration and extent to which the fair value of the security is less than its cost, the financial condition of the issuer and any changes thereto, and the Company’s intent to sell, or whether it will more likely than not be required to sell, the security before recovery of its amortized cost basis. As of September 28, 2019, the Company does not consider any of its marketable debt securities to be other-than-temporarily impaired.

[0000320193-19-000119:notes:69]
The Company holds non-marketable equity securities of certain privately held companies without readily determinable fair values. As of September 28, 2019, the Company’s non-marketable equity securities had a carrying value of $2.9 billion.

[0000320193-19-000119:notes:70]
A reconciliation of the Company’s cash and cash equivalents in the Consolidated Balance Sheet to cash, cash equivalents and restricted cash in the Consolidated Statement of Cash Flows as of September 28, 2019 is as follows (in millions):

[0000320193-19-000119:notes:71]
|  | 2019 |
| Cash and cash equivalents | $ | 48,844 |  |
| Restricted cash included in other current assets | 23 |  |
| Restricted cash included in other non-current assets | 1,357 |  |
| Cash, cash equivalents and restricted cash | $ | 50,224 |  |

[0000320193-19-000119:notes:72]
The Company’s restricted cash primarily consisted of cash required to be on deposit under a contractual agreement with a bank to support the Company’s iPhone Upgrade Program.

[0000320193-19-000119:notes:73]
Derivative Financial Instruments

[0000320193-19-000119:notes:74]
The Company may use derivatives to partially offset its business exposure to foreign currency and interest rate risk on expected future cash flows, net investments in certain foreign subsidiaries, and certain existing assets and liabilities. However, the Company may choose not to hedge certain exposures for a variety of reasons including, but not limited to, accounting considerations or the prohibitive economic cost of hedging particular exposures. There can be no assurance the hedges will offset more than a portion of the financial impact resulting from movements in foreign currency exchange or interest rates.

[0000320193-19-000119:notes:75]
To protect gross margins from fluctuations in foreign currency exchange rates, certain of the Company’s subsidiaries whose functional currency is the U.S. dollar may hedge a portion of forecasted foreign currency revenue, and subsidiaries whose functional currency is not the U.S. dollar may hedge a portion of forecasted inventory purchases not denominated in the subsidiaries’ functional currencies. The Company may enter into forward contracts, option contracts or other instruments to manage this risk and may designate these instruments as cash flow hedges. The Company generally hedges portions of its forecasted foreign currency exposure associated with revenue and inventory purchases, typically for up to 12 months.

[0000320193-19-000119:notes:76]
To protect the net investment in a foreign operation from fluctuations in foreign currency exchange rates, the Company may enter into foreign currency forward and option contracts to offset a portion of the changes in the carrying amounts of these investments due to fluctuations in foreign currency exchange rates. In addition, the Company may use non-derivative financial instruments, such as its foreign currency–denominated debt, as hedges of its net investments in certain foreign subsidiaries. In both of these cases, the Company designates these instruments as net investment hedges.

[0000320193-19-000119:notes:77]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in foreign currency exchange rates, the Company may enter into forward contracts, cross-currency swaps or other instruments. These instruments may offset a portion of the foreign currency remeasurement gains or losses, or changes in fair value. The Company may designate these instruments as either cash flow or fair value hedges. As of September 28, 2019, the Company’s hedged term debt– and marketable securities–related foreign currency transactions are expected to be recognized within 23 years.

[0000320193-19-000119:notes:78]
The Company may also enter into non-designated foreign currency contracts to offset a portion of the foreign currency exchange gains and losses generated by the remeasurement of certain assets and liabilities denominated in non-functional currencies.

[0000320193-19-000119:notes:79]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in interest rates, the Company may enter into interest rate swaps, options or other instruments. These instruments may offset a portion of the changes in interest income or expense, or changes in fair value. The Company designates these instruments as either cash flow or fair value hedges. As of September 28, 2019, the Company’s hedged interest rate transactions are expected to be recognized within 8 years.

[0000320193-19-000119:notes:80]
Cash Flow Hedges

[0000320193-19-000119:notes:81]
The effective portions of cash flow hedges are recorded in accumulated other comprehensive income/(loss) (“AOCI”) until the hedged item is recognized in earnings. Deferred gains and losses associated with cash flow hedges of foreign currency revenue are recognized as a component of net sales in the same period as the related revenue is recognized, and deferred gains and losses related to cash flow hedges of inventory purchases are recognized as a component of cost of sales in the same period as the related costs are recognized. Deferred gains and losses associated with cash flow hedges of interest income or expense are recognized in OI&E in the same period as the related income or expense is recognized. For options designated as cash flow hedges, changes in the time value are excluded from the assessment of hedge effectiveness. The ineffective portions and amounts excluded from the effectiveness testing of cash flow hedges are recognized in OI&E.

[0000320193-19-000119:notes:82]
Derivative instruments designated as cash flow hedges must be de-designated as hedges when it is probable the forecasted hedged transaction will not occur in the initially identified time period or within a subsequent two-month time period. Deferred gains and losses in AOCI associated with such derivative instruments are reclassified into OI&E in the period of de-designation. Any subsequent changes in fair value of such derivative instruments are reflected in OI&E unless they are re-designated as hedges of other transactions.

[0000320193-19-000119:notes:83]
Net Investment Hedges

[0000320193-19-000119:notes:84]
The effective portions of net investment hedges are recorded in OCI as a part of the cumulative translation adjustment. The ineffective portions and amounts excluded from the effectiveness testing of net investment hedges are recognized in OI&E. For foreign exchange forward contracts designated as net investment hedges, the Company excludes changes in fair value relating to changes in the forward carry component from its assessment of hedge effectiveness. Accordingly, any gains or losses related to this forward carry component are recognized in earnings in the current period.

[0000320193-19-000119:notes:85]
Fair Value Hedges

[0000320193-19-000119:notes:86]
Gains and losses related to changes in fair value hedges are recognized in earnings along with a corresponding loss or gain related to the change in value of the underlying hedged item in the same line in the Consolidated Statements of Operations. For foreign exchange forward contracts designated as fair value hedges, the Company excludes changes in fair value relating to changes in the forward carry component from its assessment of hedge effectiveness. The amount excluded from the effectiveness testing of fair value hedges was a gain of $777 million for 2019, and was recognized in OI&E.

[0000320193-19-000119:notes:87]
Non-Designated Derivatives

[0000320193-19-000119:notes:88]
Derivatives that are not designated as hedging instruments are adjusted to fair value through earnings in the financial statement line item to which the derivative relates.

[0000320193-19-000119:notes:89]
The Company records all derivatives in the Consolidated Balance Sheets at fair value. The Company’s accounting treatment for these derivative instruments is based on its hedge designation. The following tables show the Company’s derivative instruments at gross fair value as of September 28, 2019 and September 29, 2018 (in millions):

[0000320193-19-000119:notes:90]
|  | 2019 |
|  | Fair Value ofDerivatives Designatedas Hedge Instruments |  | Fair Value ofDerivatives Not Designatedas Hedge Instruments |  | TotalFair Value |
| Derivative assets (1): |  |  |  |  |  |
| Foreign exchange contracts | $ | 1,798 |  |  | $ | 323 |  |  | $ | 2,121 |  |
| Interest rate contracts | $ | 685 |  |  | $ | — |  |  | $ | 685 |  |
| Derivative liabilities (2): |  |  |  |  |  |
| Foreign exchange contracts | $ | 1,341 |  |  | $ | 160 |  |  | $ | 1,501 |  |
| Interest rate contracts | $ | 105 |  |  | $ | — |  |  | $ | 105 |  |

[0000320193-19-000119:notes:91]
|  | 2018 |
|  | Fair Value ofDerivatives Designatedas Hedge Instruments |  | Fair Value ofDerivatives Not Designatedas Hedge Instruments |  | TotalFair Value |
| Derivative assets (1): |  |  |  |  |  |
| Foreign exchange contracts | $ | 1,015 |  |  | $ | 259 |  |  | $ | 1,274 |  |
| Derivative liabilities (2): |  |  |  |  |  |
| Foreign exchange contracts | $ | 543 |  |  | $ | 137 |  |  | $ | 680 |  |
| Interest rate contracts | $ | 1,456 |  |  | $ | — |  |  | $ | 1,456 |  |

[0000320193-19-000119:notes:92]
| (1) | The fair value of derivative assets is measured using Level 2 fair value inputs and is recorded as other current assets and other non-current assets in the Consolidated Balance Sheets. |

[0000320193-19-000119:notes:93]
| (2) | The fair value of derivative liabilities is measured using Level 2 fair value inputs and is recorded as other current liabilities and other non-current liabilities in the Consolidated Balance Sheets. |

[0000320193-19-000119:notes:94]
The Company classifies cash flows related to derivative financial instruments as operating activities in its Consolidated Statements of Cash Flows.

[0000320193-19-000119:notes:95]
The following table shows the pre-tax gains and losses of the Company’s derivative and non-derivative instruments designated as cash flow, net investment and fair value hedges in OCI and the Consolidated Statements of Operations for 2019, 2018 and 2017 (in millions):

[0000320193-19-000119:notes:96]
|  | 2019 |  | 2018 |  | 2017 |
| Gains/(Losses) recognized in OCI – effective portion: |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |
| Foreign exchange contracts | $ | (959 | ) |  | $ | 682 |  |  | $ | 1,797 |  |
| Interest rate contracts | — |  |  | 1 |  |  | 7 |  |
| Total | $ | (959 | ) |  | $ | 683 |  |  | $ | 1,804 |  |
| Net investment hedges: |  |  |  |  |  |
| Foreign currency debt | $ | (58 | ) |  | $ | 4 |  |  | $ | 67 |  |
| Gains/(Losses) reclassified from AOCI into net income – effective portion: |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |
| Foreign exchange contracts | $ | (116 | ) |  | $ | (482 | ) |  | $ | 1,958 |  |
| Interest rate contracts | (7 | ) |  | 1 |  |  | (2 | ) |
| Total | $ | (123 | ) |  | $ | (481 | ) |  | $ | 1,956 |  |
| Gains/(Losses) on derivative instruments: |  |  |  |  |  |
| Fair value hedges: |  |  |  |  |  |
| Foreign exchange contracts | $ | 1,020 |  |  | $ | (168 | ) |  | $ | — |  |
| Interest rate contracts | 2,068 |  |  | (1,363 | ) |  | (810 | ) |
| Total | $ | 3,088 |  |  | $ | (1,531 | ) |  | $ | (810 | ) |
| Gains/(Losses) related to hedged items: |  |  |  |  |  |
| Fair value hedges: |  |  |  |  |  |
| Marketable securities | $ | (1,018 | ) |  | $ | 167 |  |  | $ | — |  |
| Fixed-rate debt | (2,068 | ) |  | 1,363 |  |  | 810 |  |
| Total | $ | (3,086 | ) |  | $ | 1,530 |  |  | $ | 810 |  |

[0000320193-19-000119:notes:97]
The following table shows the notional amounts of the Company’s outstanding derivative instruments and credit risk amounts associated with outstanding or unsettled derivative instruments as of September 28, 2019 and September 29, 2018 (in millions):

[0000320193-19-000119:notes:98]
|  | 2019 |  | 2018 |
|  | NotionalAmount |  | Credit RiskAmount |  | NotionalAmount |  | Credit RiskAmount |
| Instruments designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 61,795 |  |  | $ | 1,798 |  |  | $ | 65,368 |  |  | $ | 1,015 |  |
| Interest rate contracts | $ | 31,250 |  |  | $ | 685 |  |  | $ | 33,250 |  |  | $ | — |  |
| Instruments not designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 76,868 |  |  | $ | 323 |  |  | $ | 63,062 |  |  | $ | 259 |  |

[0000320193-19-000119:notes:99]
The notional amounts for outstanding derivative instruments provide one measure of the transaction volume outstanding and do not represent the amount of the Company’s exposure to credit or market loss. The credit risk amounts represent the Company’s gross exposure to potential accounting loss on derivative instruments that are outstanding or unsettled if all counterparties failed to perform according to the terms of the contract, based on then-current currency or interest rates at each respective date. The Company’s exposure to credit loss and market risk will vary over time as currency and interest rates change. Although the table above reflects the notional and credit risk amounts of the Company’s derivative instruments, it does not reflect the gains or losses associated with the exposures and transactions that the instruments are intended to hedge. The amounts ultimately realized upon settlement of these financial instruments, together with the gains and losses on the underlying exposures, will depend on actual market conditions during the remaining life of the instruments.

[0000320193-19-000119:notes:100]
The Company generally enters into master netting arrangements, which are designed to reduce credit risk by permitting net settlement of transactions with the same counterparty. To further limit credit risk, the Company generally enters into collateral security arrangements that provide for collateral to be received or posted when the net fair value of certain financial instruments fluctuates from contractually established thresholds. The Company presents its derivative assets and derivative liabilities at their gross fair values in its Consolidated Balance Sheets. As of September 28, 2019, the net cash collateral received by the Company related to derivative instruments under its collateral security arrangements was $1.6 billion, which was recorded as other current liabilities in the Consolidated Balance Sheet. As of September 29, 2018, the net cash collateral posted by the Company related to derivative instruments under its collateral security arrangements was $1.0 billion, which was recorded as other current assets in the Consolidated Balance Sheet.

[0000320193-19-000119:notes:101]
Under master netting arrangements with the respective counterparties to the Company’s derivative contracts, the Company is allowed to net settle transactions with a single net amount payable by one party to the other. As of September 28, 2019 and September 29, 2018, the potential effects of these rights of set-off associated with the Company’s derivative contracts, including the effects of collateral, would be a reduction to both derivative assets and derivative liabilities of $2.7 billion and $2.1 billion, respectively, resulting in a net derivative liability of $407 million and a net derivative asset of $138 million, respectively.

[0000320193-19-000119:notes:102]
Accounts Receivable

[0000320193-19-000119:notes:103]
Trade Receivables

[0000320193-19-000119:notes:104]
The Company has considerable trade receivables outstanding with its third-party cellular network carriers, wholesalers, retailers, resellers, small and mid-sized businesses and education, enterprise and government customers. The Company generally does not require collateral from its customers; however, the Company will require collateral or third-party credit support in certain instances to limit credit risk. In addition, when possible, the Company attempts to limit credit risk on trade receivables with credit insurance for certain customers or by requiring third-party financing, loans or leases to support credit exposure. These credit-financing arrangements are directly between the third-party financing company and the end customer. As such, the Company generally does not assume any recourse or credit risk sharing related to any of these arrangements.

[0000320193-19-000119:notes:105]
As of September 28, 2019, the Company had no customers that individually represented 10% or more of total trade receivables. As of September 29, 2018, the Company had one customer that represented 10% or more of total trade receivables, which accounted for 10%. The Company’s cellular network carriers accounted for 51% and 59% of total trade receivables as of September 28, 2019 and September 29, 2018, respectively.

[0000320193-19-000119:notes:106]
Vendor Non-Trade Receivables

[0000320193-19-000119:notes:107]
The Company has non-trade receivables from certain of its manufacturing vendors resulting from the sale of components to these vendors who manufacture sub-assemblies or assemble final products for the Company. The Company purchases these components directly from suppliers. As of September 28, 2019, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 59% and 14%. As of September 29, 2018, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 62% and 12%.


## us-gaap:DerivativesPolicyTextBlock

[0000320193-19-000119:notes:108]
The Company records all derivatives in the Consolidated Balance Sheets at fair value. The Company’s accounting treatment for these derivative instruments is based on its hedge designation.
Derivative Financial Instruments


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000320193-19-000119:notes:109]
Consolidated Financial Statement Details
The following tables show the Company’s consolidated financial statement details as of September 28, 2019 and September 29, 2018 (in millions):

[0000320193-19-000119:notes:110]
Property, Plant and Equipment, Net

[0000320193-19-000119:notes:111]
|  | 2019 |  | 2018 |
| Land and buildings | $ | 17,085 |  |  | $ | 16,216 |  |
| Machinery, equipment and internal-use software | 69,797 |  |  | 65,982 |  |
| Leasehold improvements | 9,075 |  |  | 8,205 |  |
| Gross property, plant and equipment | 95,957 |  |  | 90,403 |  |
| Accumulated depreciation and amortization | (58,579 | ) |  | (49,099 | ) |
| Total property, plant and equipment, net | $ | 37,378 |  |  | $ | 41,304 |  |

[0000320193-19-000119:notes:112]
Other Non-Current Liabilities

[0000320193-19-000119:notes:113]
|  | 2019 |  | 2018 |
| Long-term taxes payable | $ | 29,545 |  |  | $ | 33,589 |  |
| Other non-current liabilities | 20,958 |  |  | 15,325 |  |
| Total other non-current liabilities | $ | 50,503 |  |  | $ | 48,914 |  |

[0000320193-19-000119:notes:114]
Other Income/(Expense), Net

[0000320193-19-000119:notes:115]
The following table shows the detail of OI&E for 2019, 2018 and 2017 (in millions):

[0000320193-19-000119:notes:116]
|  | 2019 |  | 2018 |  | 2017 |
| Interest and dividend income | $ | 4,961 |  |  | $ | 5,686 |  |  | $ | 5,201 |  |
| Interest expense | (3,576 | ) |  | (3,240 | ) |  | (2,323 | ) |
| Other income/(expense), net | 422 |  |  | (441 | ) |  | (133 | ) |
| Total other income/(expense), net | $ | 1,807 |  |  | $ | 2,005 |  |  | $ | 2,745 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000320193-19-000119:notes:117]
Income Taxes
U.S. Tax Cuts and Jobs Act

[0000320193-19-000119:notes:118]
On December 22, 2017, the U.S. enacted the Tax Cuts and Jobs Act (the “Act”), which significantly changed U.S. tax law. The Act lowered the Company’s U.S. statutory federal income tax rate from 35% to 21% effective January 1, 2018, while also imposing a deemed repatriation tax on previously deferred foreign income. The Act also created a new minimum tax on certain foreign earnings, for which the Company has elected to record certain deferred tax assets and liabilities. The Company completed its accounting for the income tax effects of the Act during 2019, in accordance with the U.S. Securities and Exchange Commission Staff Accounting Bulletin No. 118.

[0000320193-19-000119:notes:119]
Provision for Income Taxes and Effective Tax Rate

[0000320193-19-000119:notes:120]
The provision for income taxes for 2019, 2018 and 2017, consisted of the following (in millions):

[0000320193-19-000119:notes:121]
|  | 2019 |  | 2018 |  | 2017 |
| Federal: |  |  |  |  |  |
| Current | $ | 6,384 |  |  | $ | 41,425 |  |  | $ | 7,842 |  |
| Deferred | (2,939 | ) |  | (33,819 | ) |  | 5,980 |  |
| Total | 3,445 |  |  | 7,606 |  |  | 13,822 |  |
| State: |  |  |  |  |  |
| Current | 475 |  |  | 551 |  |  | 259 |  |
| Deferred | (67 | ) |  | 48 |  |  | 2 |  |
| Total | 408 |  |  | 599 |  |  | 261 |  |
| Foreign: |  |  |  |  |  |
| Current | 3,962 |  |  | 3,986 |  |  | 1,671 |  |
| Deferred | 2,666 |  |  | 1,181 |  |  | (16 | ) |
| Total | 6,628 |  |  | 5,167 |  |  | 1,655 |  |
| Provision for income taxes | $ | 10,481 |  |  | $ | 13,372 |  |  | $ | 15,738 |  |

[0000320193-19-000119:notes:122]
The foreign provision for income taxes is based on foreign pre-tax earnings of $44.3 billion, $48.0 billion and $44.7 billion in 2019, 2018 and 2017, respectively.

[0000320193-19-000119:notes:123]
A reconciliation of the provision for income taxes, with the amount computed by applying the statutory federal income tax rate (21% in 2019; 24.5% in 2018; 35% in 2017) to income before provision for income taxes for 2019, 2018 and 2017, is as follows (dollars in millions):

[0000320193-19-000119:notes:124]
|  | 2019 |  | 2018 |  | 2017 |
| Computed expected tax | $ | 13,805 |  |  | $ | 17,890 |  |  | $ | 22,431 |  |
| State taxes, net of federal effect | 423 |  |  | 271 |  |  | 185 |  |
| Impacts of the Act | — |  |  | 1,515 |  |  | — |  |
| Earnings of foreign subsidiaries | (2,625 | ) |  | (5,606 | ) |  | (6,135 | ) |
| Research and development credit, net | (548 | ) |  | (560 | ) |  | (678 | ) |
| Excess tax benefits from equity awards | (639 | ) |  | (675 | ) |  | — |  |
| Other | 65 |  |  | 537 |  |  | (65 | ) |
| Provision for income taxes | $ | 10,481 |  |  | $ | 13,372 |  |  | $ | 15,738 |  |
| Effective tax rate | 15.9 | % |  | 18.3 | % |  | 24.6 | % |

[0000320193-19-000119:notes:125]
The Company’s income taxes payable have been reduced by the tax benefits from employee stock plan awards. For restricted stock units (“RSUs”), the Company receives an income tax benefit upon the award’s vesting equal to the tax effect of the underlying stock’s fair market value. Prior to 2018, the Company reflected net excess tax benefits from equity awards as increases to additional paid-in capital, which amounted to $620 million in 2017.

[0000320193-19-000119:notes:126]
Deferred Tax Assets and Liabilities

[0000320193-19-000119:notes:127]
As of September 28, 2019 and September 29, 2018, the significant components of the Company’s deferred tax assets and liabilities were (in millions):

[0000320193-19-000119:notes:128]
|  | 2019 |  | 2018 |
| Deferred tax assets: |  |  |  |
| Amortization and depreciation | $ | 11,433 |  |  | $ | 137 |  |
| Accrued liabilities and other reserves | 5,389 |  |  | 3,151 |  |
| Deferred revenue | 1,372 |  |  | 1,141 |  |
| Share-based compensation | 749 |  |  | 513 |  |
| Unrealized losses | — |  |  | 871 |  |
| Other | 697 |  |  | 797 |  |
| Total deferred tax assets, net | 19,640 |  |  | 6,610 |  |
| Deferred tax liabilities: |  |  |  |
| Minimum tax on foreign earnings | 10,809 |  |  | — |  |
| Earnings of foreign subsidiaries | 330 |  |  | 275 |  |
| Other | 456 |  |  | 501 |  |
| Total deferred tax liabilities | 11,595 |  |  | 776 |  |
| Net deferred tax assets/(liabilities) | $ | 8,045 |  |  | $ | 5,834 |  |

[0000320193-19-000119:notes:129]
Deferred tax assets and liabilities reflect the effects of tax credits and the future income tax effects of temporary differences between the consolidated financial statement carrying amounts of existing assets and liabilities and their respective tax bases, and are measured using enacted tax rates that apply to taxable income in the years in which those temporary differences are expected to be recovered or settled.

[0000320193-19-000119:notes:130]
Uncertain Tax Positions

[0000320193-19-000119:notes:131]
As of September 28, 2019, the total amount of gross unrecognized tax benefits was $15.6 billion, of which $8.6 billion, if recognized, would impact the Company’s effective tax rate. As of September 29, 2018, the total amount of gross unrecognized tax benefits was $9.7 billion, of which $7.4 billion, if recognized, would have impacted the Company’s effective tax rate.

[0000320193-19-000119:notes:132]
The aggregate change in the balance of gross unrecognized tax benefits, which excludes interest and penalties, for 2019, 2018 and 2017, is as follows (in millions):

[0000320193-19-000119:notes:133]
|  | 2019 |  | 2018 |  | 2017 |
| Beginning balances | $ | 9,694 |  |  | $ | 8,407 |  |  | $ | 7,724 |  |
| Increases related to tax positions taken during a prior year | 5,845 |  |  | 2,431 |  |  | 333 |  |
| Decreases related to tax positions taken during a prior year | (686 | ) |  | (2,212 | ) |  | (952 | ) |
| Increases related to tax positions taken during the current year | 1,697 |  |  | 1,824 |  |  | 1,880 |  |
| Decreases related to settlements with taxing authorities | (852 | ) |  | (756 | ) |  | (539 | ) |
| Decreases related to expiration of the statute of limitations | (79 | ) |  | — |  |  | (39 | ) |
| Ending balances | $ | 15,619 |  |  | $ | 9,694 |  |  | $ | 8,407 |  |

[0000320193-19-000119:notes:134]
The Company is subject to taxation and files income tax returns in the U.S. federal jurisdiction and many state and foreign jurisdictions. The U.S. Internal Revenue Service (the “IRS”) concluded its review of the years 2013 through 2015 in 2018, and all years before 2016 are closed. Tax years after 2014 remain open in certain major foreign jurisdictions and are subject to examination by the taxing authorities. The Company believes that an adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax audits cannot be predicted with certainty. If any issues addressed in the Company’s tax audits are resolved in a manner inconsistent with its expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. Although the timing of resolution and/or closure of audits is not certain, the Company believes it is reasonably possible that its gross unrecognized tax benefits could decrease in the next 12 months by as much as $2.0 billion.

[0000320193-19-000119:notes:135]
Interest and Penalties

[0000320193-19-000119:notes:136]
The Company includes interest and penalties related to income tax matters within the provision for income taxes. As of September 28, 2019 and September 29, 2018, the total amount of gross interest and penalties accrued was $1.3 billion and $1.4 billion, respectively. The Company recognized interest and penalty expense in 2019, 2018 and 2017 of $73 million, $489 million and $238 million, respectively.

[0000320193-19-000119:notes:137]
European Commission State Aid Decision

[0000320193-19-000119:notes:138]
On August 30, 2016, the European Commission announced its decision that Ireland granted state aid to the Company by providing tax opinions in 1991 and 2007 concerning the tax allocation of profits of the Irish branches of two subsidiaries of the Company (the “State Aid Decision”). The State Aid Decision ordered Ireland to calculate and recover additional taxes from the Company for the period June 2003 through December 2014. The recovery amount was calculated to be €13.1 billion, plus interest of €1.2 billion. During the fourth quarter of 2019, the Irish Minister for Finance approved the Company’s request to reduce the recovery amount by €190 million due to taxes paid to other countries, resulting in an adjusted recovery amount of €12.9 billion as of September 28, 2019. Irish legislative changes, effective as of January 2015, eliminated the application of the tax opinions from that date forward. The Company believes the State Aid Decision to be without merit and appealed to the General Court of the Court of Justice of the European Union. Ireland has also appealed the State Aid Decision. The Company believes that any incremental Irish corporate income taxes potentially due related to the State Aid Decision would be creditable against U.S. taxes, subject to any foreign tax credit limitations in the Act. As of September 28, 2019, the entire adjusted recovery amount plus interest was funded into escrow, where it will remain restricted from general use pending the conclusion of all appeals. Refer to the Cash, Cash Equivalents and Marketable Securities section of Note 3, “Financial Instruments” for more information.


## us-gaap:IncomeTaxPolicyTextBlock

[0000320193-19-000119:notes:139]
The Company includes interest and penalties related to income tax matters within the provision for income taxes.The Act also created a new minimum tax on certain foreign earnings, for which the Company has elected to record certain deferred tax assets and liabilities.


## us-gaap:DebtDisclosureTextBlock

[0000320193-19-000119:notes:140]
Debt
Commercial Paper

[0000320193-19-000119:notes:141]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of September 28, 2019 and September 29, 2018, the Company had $6.0 billion and $12.0 billion of Commercial Paper outstanding, respectively, with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 2.24% and 2.18% as of September 28, 2019 and September 29, 2018, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for 2019, 2018 and 2017 (in millions):

[0000320193-19-000119:notes:142]
|  | 2019 |  | 2018 |  | 2017 |
| Maturities 90 days or less: |  |  |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | (3,248 | ) |  | $ | 1,044 |  |  | $ | (1,782 | ) |
| Maturities greater than 90 days: |  |  |  |  |  |
| Proceeds from commercial paper | 13,874 |  |  | 14,555 |  |  | 17,932 |  |
| Repayments of commercial paper | (16,603 | ) |  | (15,636 | ) |  | (12,298 | ) |
| Proceeds from/(Repayments of) commercial paper, net | (2,729 | ) |  | (1,081 | ) |  | 5,634 |  |
| Total proceeds from/(repayments of) commercial paper, net | $ | (5,977 | ) |  | $ | (37 | ) |  | $ | 3,852 |  |

[0000320193-19-000119:notes:143]
Term Debt

[0000320193-19-000119:notes:144]
As of September 28, 2019, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $101.7 billion (collectively the “Notes”). The Notes are senior unsecured obligations and interest is payable in arrears. The following table provides a summary of the Company’s term debt as of September 28, 2019 and September 29, 2018:

[0000320193-19-000119:notes:145]
|  | Maturities(calendar year) |  | 2019 |  | 2018 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013–2018 debt issuances: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2020 | – | 2022 |  | $ | 4,250 |  |  |  | 2.25% | – | 3.28 | % |  | $ | 7,107 |  |  |  | 1.87% | – | 3.44 | % |
| Fixed-rate 0.350% – 4.650% notes | 2019 | – | 2047 |  | 90,429 |  |  |  | 0.28% | – | 4.78 | % |  | 97,086 |  |  |  | 0.28% | – | 4.78 | % |
| 2019 debt issuance: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 1.700% – 2.950% notes | 2022 | – | 2049 |  | 7,000 |  |  |  | 1.71% | – | 2.99 | % |  | — |  |  |  |  |  | — | % |
| Total term debt |  |  |  |  | 101,679 |  |  |  |  |  |  |  | 104,193 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (224 | ) |  |  |  |  |  |  | (218 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | 612 |  |  |  |  |  |  |  | (1,456 | ) |  |  |  |  |  |
| Less: Current portion of term debt |  |  |  |  | (10,260 | ) |  |  |  |  |  |  | (8,784 | ) |  |  |  |  |  |
| Total non-current portion of term debt |  |  |  |  | $ | 91,807 |  |  |  |  |  |  |  | $ | 93,735 |  |  |  |  |  |  |

[0000320193-19-000119:notes:146]
To manage interest rate risk on certain of its U.S. dollar–denominated fixed- or floating-rate notes, the Company has entered into interest rate swaps to effectively convert the fixed interest rates to floating interest rates or the floating interest rates to fixed interest rates on a portion of these notes. Additionally, to manage foreign currency risk on certain of its foreign currency–denominated notes, the Company has entered into foreign currency swaps to effectively convert these notes to U.S. dollar–denominated notes.

[0000320193-19-000119:notes:147]
A portion of the Company’s Japanese yen–denominated notes is designated as a hedge of the foreign currency exposure of the Company’s net investment in a foreign operation. As of September 28, 2019 and September 29, 2018, the carrying value of the debt designated as a net investment hedge was $1.0 billion and $811 million, respectively. For further discussion regarding the Company’s use of derivative instruments, refer to the Derivative Financial Instruments section of Note 3, “Financial Instruments.”

[0000320193-19-000119:notes:148]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $3.2 billion, $3.0 billion and $2.2 billion of interest cost on its term debt for 2019, 2018 and 2017, respectively.

[0000320193-19-000119:notes:149]
The future principal payments for the Company’s Notes as of September 28, 2019 are as follows (in millions):

[0000320193-19-000119:notes:150]
| 2020 | $ | 10,270 |  |
| 2021 | 8,750 |  |
| 2022 | 9,528 |  |
| 2023 | 9,290 |  |
| 2024 | 10,039 |  |
| Thereafter | 53,802 |  |
| Total term debt | $ | 101,679 |  |

[0000320193-19-000119:notes:151]
As of September 28, 2019 and September 29, 2018, the fair value of the Company’s Notes, based on Level 2 inputs, was $107.5 billion and $103.2 billion, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000320193-19-000119:notes:152]
Shareholders’ Equity
Share Repurchase Program

[0000320193-19-000119:notes:153]
On April 30, 2019, the Company announced the Board of Directors increased the current share repurchase program authorization from $100 billion to $175 billion of the Company’s common stock, of which $96.1 billion had been utilized as of September 28, 2019. During 2019, the Company repurchased 345.2 million shares of its common stock for $67.1 billion, including 62.0 million shares delivered under a $12.0 billion accelerated share repurchase arrangement dated February 2019, which settled in August 2019. The Company’s share repurchase program does not obligate it to acquire any specific number of shares. Under this program, shares may be repurchased in privately negotiated and/or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).

[0000320193-19-000119:notes:154]
Shares of Common Stock

[0000320193-19-000119:notes:155]
The following table shows the changes in shares of common stock for 2019, 2018 and 2017 (in thousands):

[0000320193-19-000119:notes:156]
|  | 2019 |  | 2018 |  | 2017 |
| Common stock outstanding, beginning balances | 4,754,986 |  |  | 5,126,201 |  |  | 5,336,166 |  |
| Common stock repurchased | (345,205 | ) |  | (405,549 | ) |  | (246,496 | ) |
| Common stock issued, net of shares withheld for employee taxes | 33,455 |  |  | 34,334 |  |  | 36,531 |  |
| Common stock outstanding, ending balances | 4,443,236 |  |  | 4,754,986 |  |  | 5,126,201 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000320193-19-000119:notes:157]
Comprehensive Income
The Company’s OCI consists of foreign currency translation adjustments from those subsidiaries not using the U.S. dollar as their functional currency, net deferred gains and losses on certain derivative instruments accounted for as cash flow hedges and unrealized gains and losses on marketable debt securities classified as available-for-sale.

[0000320193-19-000119:notes:158]
The following table shows the pre-tax amounts reclassified from AOCI into the Consolidated Statements of Operations, and the associated financial statement line item, for 2019 and 2018 (in millions):

[0000320193-19-000119:notes:159]
| Comprehensive Income Components |  | Financial Statement Line Item |  | 2019 |  | 2018 |
| Unrealized (gains)/losses on derivative instruments: |  |  |  |  |  |  |
| Foreign exchange contracts |  | Total net sales |  | $ | (206 | ) |  | $ | 214 |  |
|  |  | Total cost of sales |  | (482 | ) |  | (70 | ) |
|  |  | Other income/(expense), net |  | 784 |  |  | 344 |  |
| Interest rate contracts |  | Other income/(expense), net |  | 7 |  |  | (2 | ) |
|  |  |  |  | 103 |  |  | 486 |  |
| Unrealized (gains)/losses on marketable securities |  | Other income/(expense), net |  | 31 |  |  | (20 | ) |
| Total amounts reclassified from AOCI |  |  |  | $ | 134 |  |  | $ | 466 |  |

[0000320193-19-000119:notes:160]
The following table shows the changes in AOCI by component for 2019 and 2018 (in millions):

[0000320193-19-000119:notes:161]
|  | Cumulative ForeignCurrency Translation |  | Unrealized Gains/Losseson Derivative Instruments |  | Unrealized Gains/Losseson Marketable Securities |  | Total |
| Balances as of September 30, 2017 | $ | (354 | ) |  | $ | (124 | ) |  | $ | 328 |  |  | $ | (150 | ) |
| Other comprehensive income/(loss) before reclassifications | (524 | ) |  | 672 |  |  | (4,563 | ) |  | (4,415 | ) |
| Amounts reclassified from AOCI | — |  |  | 486 |  |  | (20 | ) |  | 466 |  |
| Tax effect | (1 | ) |  | (253 | ) |  | 1,177 |  |  | 923 |  |
| Other comprehensive income/(loss) | (525 | ) |  | 905 |  |  | (3,406 | ) |  | (3,026 | ) |
| Cumulative effect of change in accounting principle | (176 | ) |  | 29 |  |  | (131 | ) |  | (278 | ) |
| Balances as of September 29, 2018 | (1,055 | ) |  | 810 |  |  | (3,209 | ) |  | (3,454 | ) |
| Other comprehensive income/(loss) before reclassifications | (421 | ) |  | (949 | ) |  | 4,854 |  |  | 3,484 |  |
| Amounts reclassified from AOCI | — |  |  | 103 |  |  | 31 |  |  | 134 |  |
| Tax effect | 13 |  |  | 208 |  |  | (1,058 | ) |  | (837 | ) |
| Other comprehensive income/(loss) | (408 | ) |  | (638 | ) |  | 3,827 |  |  | 2,781 |  |
| Cumulative effect of change in accounting principle (1) | — |  |  | — |  |  | 89 |  |  | 89 |  |
| Balances as of September 28, 2019 | $ | (1,463 | ) |  | $ | 172 |  |  | $ | 707 |  |  | $ | (584 | ) |

[0000320193-19-000119:notes:162]
(1)

[0000320193-19-000119:notes:163]
Refer to Note 1, “Summary of Significant Accounting Policies” for more information on the Company’s adoption of ASU 2016-01 in 2019.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000320193-19-000119:notes:164]
Benefit Plans
2014 Employee Stock Plan

[0000320193-19-000119:notes:165]
In the second quarter of 2014, shareholders approved the 2014 Employee Stock Plan (the “2014 Plan”) and terminated the Company’s authority to grant new awards under the 2003 Employee Stock Plan (the “2003 Plan”). The 2014 Plan provides for broad-based equity grants to employees, including executive officers, and permits the granting of RSUs, stock grants, performance-based awards, stock options and stock appreciation rights, as well as cash bonus awards. RSUs granted under the 2014 Plan generally vest over four years, based on continued employment, and are settled upon vesting in shares of the Company’s common stock on a one-for-one basis. RSUs granted under the 2014 Plan reduce the number of shares available for grant under the plan by a factor of two times the number of RSUs granted. RSUs canceled and shares withheld to satisfy tax withholding obligations increase the number of shares available for grant under the 2014 Plan utilizing a factor of two times the number of RSUs canceled or shares withheld. Currently, all RSUs granted under the 2014 Plan have dividend equivalent rights (“DERs”), which entitle holders of RSUs to the same dividend value per share as holders of common stock. DERs are subject to the same vesting and other terms and conditions as the corresponding unvested RSUs. DERs are accumulated and paid when the underlying shares vest. Upon approval of the 2014 Plan, the Company reserved 385 million shares plus the number of shares remaining that were reserved but not issued under the 2003 Plan. Shares subject to outstanding awards under the 2003 Plan that expire, are canceled or otherwise terminate, or are withheld to satisfy tax withholding obligations for RSUs, will also be available for awards under the 2014 Plan. As of September 28, 2019, approximately 246.4 million shares were reserved for future issuance under the 2014 Plan.

[0000320193-19-000119:notes:166]
Apple Inc. Non-Employee Director Stock Plan

[0000320193-19-000119:notes:167]
The Apple Inc. Non-Employee Director Stock Plan (the “Director Plan”) is a shareholder-approved plan that (i) permits the Company to grant awards of RSUs or stock options to the Company’s non-employee directors, (ii) provides for automatic initial grants of RSUs upon a non-employee director joining the Board of Directors and automatic annual grants of RSUs at each annual meeting of shareholders, and (iii) permits the Board of Directors to prospectively change the value and relative mixture of stock options and RSUs for the initial and annual award grants and the methodology for determining the number of shares of the Company’s common stock subject to these grants, in each case within the limits set forth in the Director Plan and without further shareholder approval. RSUs granted under the Director Plan reduce the number of shares available for grant under the plan by a factor of two times the number of RSUs granted. The Director Plan expires on November 12, 2027. All RSUs granted under the Director Plan are entitled to DERs. DERs are subject to the same vesting and other terms and conditions as the corresponding unvested RSUs. DERs are accumulated and paid when the underlying shares vest. As of September 28, 2019, approximately 1.1 million shares were reserved for future issuance under the Director Plan.

[0000320193-19-000119:notes:168]
Rule 10b5-1 Trading Plans

[0000320193-19-000119:notes:169]
During the three months ended September 28, 2019, Section 16 officers Timothy D. Cook, Chris Kondo, Luca Maestri, Deirdre O’Brien and Jeffrey Williams had equity trading plans in place in accordance with Rule 10b5-1(c)(1) under the Exchange Act. An equity trading plan is a written document that pre-establishes the amounts, prices and dates (or formula for determining the amounts, prices and dates) of future purchases or sales of the Company’s stock, including shares acquired under the Company’s employee and director equity plans.

[0000320193-19-000119:notes:170]
Employee Stock Purchase Plan

[0000320193-19-000119:notes:171]
The Employee Stock Purchase Plan (the “Purchase Plan”) is a shareholder-approved plan under which substantially all employees may purchase the Company’s common stock through payroll deductions at a price equal to 85% of the lower of the fair market values of the stock as of the beginning or the end of six-month offering periods. An employee’s payroll deductions under the Purchase Plan are limited to 10% of the employee’s compensation and employees may not purchase more than $25,000 of stock during any calendar year. As of September 28, 2019, approximately 31.1 million shares were reserved for future issuance under the Purchase Plan.

[0000320193-19-000119:notes:172]
401(k) Plan

[0000320193-19-000119:notes:173]
The Company’s 401(k) Plan is a deferred salary arrangement under Section 401(k) of the Internal Revenue Code. Under the 401(k) Plan, participating U.S. employees may defer a portion of their pre-tax earnings, up to the IRS annual contribution limit ($19,000 for calendar year 2019). The Company matches 50% to 100% of each employee’s contributions, depending on length of service, up to a maximum of 6% of the employee’s eligible earnings.

[0000320193-19-000119:notes:174]
Restricted Stock Units

[0000320193-19-000119:notes:175]
A summary of the Company’s RSU activity and related information for 2019, 2018 and 2017, is as follows:

[0000320193-19-000119:notes:176]
|  | Number ofRSUs(in thousands) |  | Weighted-AverageGrant Date FairValue Per RSU |  | AggregateFair Value(in millions) |
| Balance as of September 24, 2016 | 99,089 |  |  | $ | 97.54 |  |  |  |
| RSUs granted | 50,112 |  |  | $ | 121.65 |  |  |  |
| RSUs vested | (45,735 | ) |  | $ | 95.48 |  |  |  |
| RSUs canceled | (5,895 | ) |  | $ | 106.87 |  |  |  |
| Balance as of September 30, 2017 | 97,571 |  |  | $ | 110.33 |  |  |  |
| RSUs granted | 45,351 |  |  | $ | 162.86 |  |  |  |
| RSUs vested | (44,718 | ) |  | $ | 111.24 |  |  |  |
| RSUs canceled | (6,049 | ) |  | $ | 127.82 |  |  |  |
| Balance as of September 29, 2018 | 92,155 |  |  | $ | 134.60 |  |  |  |
| RSUs granted | 36,852 |  |  | $ | 215.95 |  |  |  |
| RSUs vested | (42,088 | ) |  | $ | 135.21 |  |  |  |
| RSUs canceled | (5,402 | ) |  | $ | 162.85 |  |  |  |
| Balance as of September 28, 2019 | 81,517 |  |  | $ | 169.18 |  |  | $ | 17,838 |  |

[0000320193-19-000119:notes:177]
The fair value as of the respective vesting dates of RSUs was $8.6 billion, $7.6 billion and $6.1 billion for 2019, 2018 and 2017, respectively. The majority of RSUs that vested in 2019, 2018 and 2017 were net share settled such that the Company withheld shares with a value equivalent to the employees’ obligation for the applicable income and other employment taxes, and remitted the cash to the appropriate taxing authorities. The total shares withheld were approximately 14.8 million, 16.0 million and 15.4 million for 2019, 2018 and 2017, respectively, and were based on the value of the RSUs on their respective vesting dates as determined by the Company’s closing stock price. Total payments for the employees’ tax obligations to taxing authorities were $3.0 billion, $2.7 billion and $2.0 billion in 2019, 2018 and 2017, respectively. These net share settlements had the effect of share repurchases by the Company as they reduced the number of shares that would have otherwise been issued as a result of the vesting and did not represent an expense to the Company.

[0000320193-19-000119:notes:178]
The following table shows share-based compensation expense and the related income tax benefit included in the Consolidated Statements of Operations for 2019, 2018 and 2017 (in millions):

[0000320193-19-000119:notes:179]
|  | 2019 |  | 2018 |  | 2017 |
| Share-based compensation expense | $ | 6,068 |  |  | $ | 5,340 |  |  | $ | 4,840 |  |
| Income tax benefit related to share-based compensation expense | $ | (1,967 | ) |  | $ | (1,893 | ) |  | $ | (1,632 | ) |

[0000320193-19-000119:notes:180]
As of September 28, 2019, the total unrecognized compensation cost related to outstanding RSUs and stock options was $10.5 billion, which the Company expects to recognize over a weighted-average period of 2.5 years.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000320193-19-000119:notes:181]
Commitments and Contingencies
Accrued Warranty and Guarantees

[0000320193-19-000119:notes:182]
The following table shows changes in the Company’s accrued warranties and related costs for 2019, 2018 and 2017 (in millions):

[0000320193-19-000119:notes:183]
|  | 2019 |  | 2018 |  | 2017 |
| Beginning accrued warranty and related costs | $ | 3,692 |  |  | $ | 3,834 |  |  | $ | 3,702 |  |
| Cost of warranty claims | (3,857 | ) |  | (4,115 | ) |  | (4,322 | ) |
| Accruals for product warranty | 3,735 |  |  | 3,973 |  |  | 4,454 |  |
| Ending accrued warranty and related costs | $ | 3,570 |  |  | $ | 3,692 |  |  | $ | 3,834 |  |

[0000320193-19-000119:notes:184]
The Company offers an iPhone Upgrade Program, which is available to customers who purchase a qualifying iPhone in the U.S., the U.K. and mainland China. The iPhone Upgrade Program provides customers the right to trade in that iPhone for a specified amount when purchasing a new iPhone, provided certain conditions are met. The Company accounts for the trade-in right as a guarantee liability and recognizes arrangement revenue net of the fair value of such right, with subsequent changes to the guarantee liability recognized within net sales.

[0000320193-19-000119:notes:185]
Concentrations in the Available Sources of Supply of Materials and Product

[0000320193-19-000119:notes:186]
Although most components essential to the Company’s business are generally available from multiple sources, certain components are currently obtained from single or limited sources. The Company also competes for various components with other participants in the markets for smartphones, personal computers, tablets and other electronic devices. Therefore, many components used by the Company, including those that are available from multiple sources, are at times subject to industry-wide shortage and significant commodity pricing fluctuations.

[0000320193-19-000119:notes:187]
The Company uses some custom components that are not commonly used by its competitors, and new products introduced by the Company often utilize custom components available from only one source. When a component or product uses new technologies, initial capacity constraints may exist until the suppliers’ yields have matured or their manufacturing capacities have increased. The continued availability of these components at acceptable prices, or at all, may be affected if suppliers decide to concentrate on the production of common components instead of components customized to meet the Company’s requirements.

[0000320193-19-000119:notes:188]
The Company has entered into agreements for the supply of many components; however, there can be no guarantee that the Company will be able to extend or renew these agreements on similar terms, or at all.

[0000320193-19-000119:notes:189]
Substantially all of the Company’s hardware products are manufactured by outsourcing partners that are located primarily in Asia, with some Mac computers manufactured in the U.S. and Ireland.

[0000320193-19-000119:notes:190]
Other Off–Balance Sheet Commitments

[0000320193-19-000119:notes:191]
Operating Leases

[0000320193-19-000119:notes:192]
The Company leases various equipment and facilities, including retail space, under noncancelable operating lease arrangements. The Company does not currently utilize any other off–balance sheet financing arrangements. As of September 28, 2019, the Company’s total future minimum lease payments under noncancelable operating leases were $10.8 billion. The Company’s retail store and other facility leases typically have original terms not exceeding 10 years and generally contain multi-year renewal options.

[0000320193-19-000119:notes:193]
Rent expense under all operating leases, including both cancelable and noncancelable leases, was $1.3 billion, $1.2 billion and $1.1 billion in 2019, 2018 and 2017, respectively. Future minimum lease payments under noncancelable operating leases having initial or remaining terms in excess of one year as of September 28, 2019, are as follows (in millions):

[0000320193-19-000119:notes:194]
| 2020 | $ | 1,306 |  |
| 2021 | 1,276 |  |
| 2022 | 1,137 |  |
| 2023 | 912 |  |
| 2024 | 834 |  |
| Thereafter | 5,373 |  |
| Total | $ | 10,838 |  |

[0000320193-19-000119:notes:195]
Unconditional Purchase Obligations

[0000320193-19-000119:notes:196]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of payments for supplier arrangements, Internet and telecommunication services, intellectual property licenses and content creation. Future payments under noncancelable unconditional purchase obligations having a remaining term in excess of one year as of September 28, 2019, are as follows (in millions):

[0000320193-19-000119:notes:197]
| 2020 | $ | 2,476 |  |
| 2021 | 2,386 |  |
| 2022 | 1,859 |  |
| 2023 | 1,162 |  |
| 2024 | 218 |  |
| Thereafter | 110 |  |
| Total | $ | 8,211 |  |

[0000320193-19-000119:notes:198]
Contingencies

[0000320193-19-000119:notes:199]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully resolved. The outcome of litigation is inherently uncertain. If one or more legal matters were resolved against the Company in a reporting period for amounts above management’s expectations, the Company’s financial condition and operating results for that reporting period could be materially adversely affected. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss greater than a recorded accrual, concerning loss contingencies for asserted legal and other claims, except for the following matters:

[0000320193-19-000119:notes:200]
VirnetX

[0000320193-19-000119:notes:201]
VirnetX, Inc. (“VirnetX”) filed two lawsuits in the U.S. District Court for the Eastern District of Texas (the “Eastern Texas District Court”) against the Company alleging that certain Company products infringe four patents (the “VirnetX Patents”) relating to network communications technology (“VirnetX I” and “VirnetX II”). On September 30, 2016, a jury returned a verdict in VirnetX I against the Company and awarded damages of $302 million, which later increased to $440 million in post-trial proceedings. The Company appealed the VirnetX I verdict to the U.S. Court of Appeals for the Federal Circuit (the “Federal Circuit”). On April 11, 2018, a jury returned a verdict in VirnetX II against the Company and awarded damages of $503 million. VirnetX II is currently on appeal. The Company has challenged the validity of the VirnetX Patents at the U.S. Patent and Trademark Office (the “PTO”). In response, the PTO has declared the VirnetX Patents invalid. VirnetX appealed the invalidity decision of the PTO to the Federal Circuit. The Federal Circuit consolidated the Company’s appeal of the Eastern Texas District Court VirnetX I verdict and VirnetX’s appeals from the PTO invalidity proceedings. On January 15, 2019, the Federal Circuit affirmed the VirnetX I verdict, which the Company intends to further appeal. On July 8, 2019, the Federal Circuit remanded one of VirnetX’s two appeals of the PTO’s invalidity decisions back to the PTO for further proceedings. On August 1, 2019, the Federal Circuit affirmed-in-part, vacated-in-part, and remanded back to the PTO portions of VirnetX’s second appeal. The Company has accrued its best estimate for the ultimate resolution of these matters.

[0000320193-19-000119:notes:202]
Qualcomm

[0000320193-19-000119:notes:203]
On January 20, 2017, the Company filed a lawsuit against Qualcomm Incorporated and affiliated parties (“Qualcomm”) in the U.S. District Court for the Southern District of California seeking, among other things, to enjoin Qualcomm from requiring the Company to pay royalties at the rate demanded by Qualcomm. No Qualcomm-related royalty payments had been remitted by the Company to its contract manufacturers since the beginning of the second quarter of 2017. Following the Company’s lawsuit, Qualcomm filed patent infringement suits against the Company and its affiliates in the U.S. and various international jurisdictions, some of which sought to enjoin the sale of certain of the Company’s products in particular countries.

[0000320193-19-000119:notes:204]
On April 16, 2019, the Company and Qualcomm reached a settlement agreement to dismiss all litigation between the two companies worldwide. The companies also reached a multi-year license agreement and a multi-year supply agreement. Under the terms of the settlement agreement, Apple made a payment to Qualcomm to, among other things, resolve disputes over the withheld royalty payments.

[0000320193-19-000119:notes:205]
iOS Performance Management Cases

[0000320193-19-000119:notes:206]
Various civil litigation matters have been filed in state and federal courts in the U.S. and in various international jurisdictions alleging violation of consumer protection laws, fraud, computer intrusion and other causes of action related to the Company’s performance management feature used in its iPhone operating systems, introduced to certain iPhones in iOS updates 10.2.1 and 11.2. The claims seek monetary damages and other non-monetary relief. On April 5, 2018, several U.S. federal actions were consolidated through a Multidistrict Litigation process into a single action in the U.S. District Court for the Northern District of California. In addition to civil litigation, the Company is also responding to governmental investigations and requests for information relating to the performance management feature. The Company believes that its iPhones were not defective, that the performance management feature introduced with iOS updates 10.2.1 and 11.2 was intended to, and did, improve customers’ user experience, and that the Company did not make any misleading statements or fail to disclose any material information. The Company has accrued its best estimate for the ultimate resolution of these matters.

[0000320193-19-000119:notes:207]
French Competition Authority

[0000320193-19-000119:notes:208]
In June 2019, the French Competition Authority (“FCA”) issued a report alleging that aspects of the Company’s sales and distribution practices in France violate French competition law. The Company vigorously disagrees with the allegations, and a hearing of arguments was held before the FCA on October 15, 2019. The Company is awaiting the decision of the FCA, which may include a fine.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000320193-19-000119:notes:209]
Segment Information and Geographic Data
The Company reports segment information based on the “management” approach. The management approach designates the internal reporting used by management for making decisions and assessing performance as the source of the Company’s reportable segments.

[0000320193-19-000119:notes:210]
The Company manages its business primarily on a geographic basis. The Company’s reportable segments consist of the Americas, Europe, Greater China, Japan and Rest of Asia Pacific. Americas includes both North and South America. Europe includes European countries, as well as India, the Middle East and Africa. Greater China includes China, Hong Kong and Taiwan. Rest of Asia Pacific includes Australia and those Asian countries not included in the Company’s other reportable segments. Although the reportable segments provide similar hardware and software products and similar services, each one is managed separately to better align with the location of the Company’s customers and distribution partners and the unique market dynamics of each geographic region. The accounting policies of the various segments are the same as those described in Note 1, “Summary of Significant Accounting Policies.”

[0000320193-19-000119:notes:211]
The Company evaluates the performance of its reportable segments based on net sales and operating income. Net sales for geographic segments are generally based on the location of customers and sales through the Company’s retail stores located in those geographic locations. Operating income for each segment includes net sales to third parties, related cost of sales and operating expenses directly attributable to the segment. Advertising expenses are generally included in the geographic segment in which the expenditures are incurred. Operating income for each segment excludes other income and expense and certain expenses managed outside the reportable segments. Costs excluded from segment operating income include various corporate expenses such as research and development, corporate marketing expenses, certain share-based compensation expenses, income taxes, various nonrecurring charges and other separately managed general and administrative costs. The Company does not include intercompany transfers between segments for management reporting purposes.

[0000320193-19-000119:notes:212]
The following table shows information by reportable segment for 2019, 2018 and 2017 (in millions):

[0000320193-19-000119:notes:213]
|  | 2019 |  | 2018 |  | 2017 |
| Americas: |  |  |  |  |  |
| Net sales | $ | 116,914 |  |  | $ | 112,093 |  |  | $ | 96,600 |  |
| Operating income | $ | 35,099 |  |  | $ | 34,864 |  |  | $ | 30,684 |  |
| Europe: |  |  |  |  |  |
| Net sales | $ | 60,288 |  |  | $ | 62,420 |  |  | $ | 54,938 |  |
| Operating income | $ | 19,195 |  |  | $ | 19,955 |  |  | $ | 16,514 |  |
| Greater China: |  |  |  |  |  |
| Net sales | $ | 43,678 |  |  | $ | 51,942 |  |  | $ | 44,764 |  |
| Operating income | $ | 16,232 |  |  | $ | 19,742 |  |  | $ | 17,032 |  |
| Japan: |  |  |  |  |  |
| Net sales | $ | 21,506 |  |  | $ | 21,733 |  |  | $ | 17,733 |  |
| Operating income | $ | 9,369 |  |  | $ | 9,500 |  |  | $ | 8,097 |  |
| Rest of Asia Pacific: |  |  |  |  |  |
| Net sales | $ | 17,788 |  |  | $ | 17,407 |  |  | $ | 15,199 |  |
| Operating income | $ | 6,055 |  |  | $ | 6,181 |  |  | $ | 5,304 |  |

[0000320193-19-000119:notes:214]
A reconciliation of the Company’s segment operating income to the Consolidated Statements of Operations for 2019, 2018 and 2017 is as follows (in millions):

[0000320193-19-000119:notes:215]
|  | 2019 |  | 2018 |  | 2017 |
| Segment operating income | $ | 85,950 |  |  | $ | 90,242 |  |  | $ | 77,631 |  |
| Research and development expense | (16,217 | ) |  | (14,236 | ) |  | (11,581 | ) |
| Other corporate expenses, net | (5,803 | ) |  | (5,108 | ) |  | (4,706 | ) |
| Total operating income | $ | 63,930 |  |  | $ | 70,898 |  |  | $ | 61,344 |  |

[0000320193-19-000119:notes:216]
The U.S. and China were the only countries that accounted for more than 10% of the Company’s net sales in 2019, 2018 and 2017. There was no single customer that accounted for more than 10% of net sales in 2019, 2018 and 2017. Net sales for 2019, 2018 and 2017 and long-lived assets as of September 28, 2019 and September 29, 2018 were as follows (in millions):

[0000320193-19-000119:notes:217]
|  | 2019 |  | 2018 |  | 2017 |
| Net sales: |  |  |  |  |  |
| U.S. | $ | 102,266 |  |  | $ | 98,061 |  |  | $ | 84,339 |  |
| China (1) | 43,678 |  |  | 51,942 |  |  | 44,764 |  |
| Other countries | 114,230 |  |  | 115,592 |  |  | 100,131 |  |
| Total net sales | $ | 260,174 |  |  | $ | 265,595 |  |  | $ | 229,234 |  |

[0000320193-19-000119:notes:218]
|  | 2019 |  | 2018 |
| Long-lived assets: |  |  |  |
| U.S. | $ | 24,711 |  |  | $ | 23,963 |  |
| China (1) | 9,064 |  |  | 13,268 |  |
| Other countries | 3,603 |  |  | 4,073 |  |
| Total long-lived assets | $ | 37,378 |  |  | $ | 41,304 |  |

[0000320193-19-000119:notes:219]
China includes Hong Kong and Taiwan. Long-lived assets located in China consist primarily of product tooling and manufacturing process equipment and assets related to retail stores and related infrastructure.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000320193-19-000119:notes:220]
Selected Quarterly Financial Information (Unaudited)
The following tables show a summary of the Company’s quarterly financial information for each of the four quarters of 2019 and 2018 (in millions, except per share amounts):

[0000320193-19-000119:notes:221]
|  | Fourth Quarter |  | Third Quarter |  | Second Quarter |  | First Quarter |
| 2019: |  |  |  |  |  |  |  |
| Total net sales | $ | 64,040 |  |  | $ | 53,809 |  |  | $ | 58,015 |  |  | $ | 84,310 |  |
| Gross margin | $ | 24,313 |  |  | $ | 20,227 |  |  | $ | 21,821 |  |  | $ | 32,031 |  |
| Net income | $ | 13,686 |  |  | $ | 10,044 |  |  | $ | 11,561 |  |  | $ | 19,965 |  |
| Earnings per share (1): |  |  |  |  |  |  |  |
| Basic | $ | 3.05 |  |  | $ | 2.20 |  |  | $ | 2.47 |  |  | $ | 4.22 |  |
| Diluted | $ | 3.03 |  |  | $ | 2.18 |  |  | $ | 2.46 |  |  | $ | 4.18 |  |

[0000320193-19-000119:notes:222]
|  | Fourth Quarter |  | Third Quarter |  | Second Quarter |  | First Quarter |
| 2018: |  |  |  |  |  |  |  |
| Total net sales | $ | 62,900 |  |  | $ | 53,265 |  |  | $ | 61,137 |  |  | $ | 88,293 |  |
| Gross margin | $ | 24,084 |  |  | $ | 20,421 |  |  | $ | 23,422 |  |  | $ | 33,912 |  |
| Net income | $ | 14,125 |  |  | $ | 11,519 |  |  | $ | 13,822 |  |  | $ | 20,065 |  |
| Earnings per share (1): |  |  |  |  |  |  |  |
| Basic | $ | 2.94 |  |  | $ | 2.36 |  |  | $ | 2.75 |  |  | $ | 3.92 |  |
| Diluted | $ | 2.91 |  |  | $ | 2.34 |  |  | $ | 2.73 |  |  | $ | 3.89 |  |

[0000320193-19-000119:notes:223]
Basic and diluted earnings per share are computed independently for each of the quarters presented. Therefore, the sum of quarterly basic and diluted per share information may not equal annual basic and diluted earnings per share.
