# AAPL MD&A — 0000320193-19-000119


## mdna

[0000320193-19-000119:mdna:1]
| Item 7. | Management’s Discussion and Analysis of Financial Condition and Results of Operations |

[0000320193-19-000119:mdna:2]
This section of this Form 10-K generally discusses 2019 and 2018 items and year-to-year comparisons between 2019 and 2018. Discussions of 2017 items and year-to-year comparisons between 2018 and 2017 that are not included in this Form 10-K can be found in “Management’s Discussion and Analysis of Financial Condition and Results of Operations”  in Part II, Item 7 of the Company’s Annual Report on Form 10-K for the fiscal year ended September 29, 2018.

[0000320193-19-000119:mdna:3]
Fiscal Period

[0000320193-19-000119:mdna:4]
The Company’s fiscal year is the 52- or 53-week period that ends on the last Saturday of September. The Company’s fiscal years 2019 and 2018 spanned 52 weeks each, whereas fiscal year 2017 included 53 weeks. A 14th week was included in the first quarter of 2017, as is done every five or six years, to realign the Company’s fiscal quarters with calendar quarters.

[0000320193-19-000119:mdna:5]
Fiscal 2019 Highlights

[0000320193-19-000119:mdna:6]
Total net sales decreased 2% or $5.4 billion during 2019 compared to 2018, driven by lower net sales of iPhone, partially offset by higher net sales of Wearables, Home and Accessories and Services in all geographic operating segments. The weakness in foreign currencies had a significant unfavorable impact on net sales during 2019.

[0000320193-19-000119:mdna:7]
In April 2019, the Company announced an increase to its current share repurchase program authorization from $100 billion to $175 billion and raised its quarterly dividend from $0.73 to $0.77 per share beginning in May 2019. During 2019, the Company repurchased $67.1 billion of its common stock and paid dividends and dividend equivalents of $14.1 billion.

[0000320193-19-000119:mdna:8]
Products and Services Performance

[0000320193-19-000119:mdna:9]
Beginning in the first quarter of 2019, the Company classified the amortization of the deferred value of Maps, Siri and free iCloud services, which are bundled in the sales price of iPhone, Mac, iPad and certain other products, in Services net sales. Historically, the Company classified the amortization of these amounts in Products net sales consistent with its management reporting framework. As a result, Products and Services net sales for 2018 and 2017 were reclassified to conform to the 2019 presentation.

[0000320193-19-000119:mdna:10]
The following table shows net sales by category for 2019, 2018 and 2017 (dollars in millions):

[0000320193-19-000119:mdna:11]
|  | 2019 |  | Change |  | 2018 |  | Change |  | 2017 |
| Net sales by category: |  |  |  |  |  |  |  |  |  |
| iPhone (1) | $ | 142,381 |  |  | (14 | )% |  | $ | 164,888 |  |  | 18 | % |  | $ | 139,337 |  |
| Mac (1) | 25,740 |  |  | 2 | % |  | 25,198 |  |  | (1 | )% |  | 25,569 |  |
| iPad (1) | 21,280 |  |  | 16 | % |  | 18,380 |  |  | (2 | )% |  | 18,802 |  |
| Wearables, Home and Accessories (1)(2) | 24,482 |  |  | 41 | % |  | 17,381 |  |  | 36 | % |  | 12,826 |  |
| Services (3) | 46,291 |  |  | 16 | % |  | 39,748 |  |  | 22 | % |  | 32,700 |  |
| Total net sales | $ | 260,174 |  |  | (2 | )% |  | $ | 265,595 |  |  | 16 | % |  | $ | 229,234 |  |

[0000320193-19-000119:mdna:12]
| (1) | Products net sales include amortization of the deferred value of unspecified software upgrade rights, which are bundled in the sales price of the respective product. |

[0000320193-19-000119:mdna:13]
| (2) | Wearables, Home and Accessories net sales include sales of AirPods, Apple TV, Apple Watch, Beats products, HomePod, iPod touch and Apple-branded and third-party accessories. |

[0000320193-19-000119:mdna:14]
| (3) | Services net sales include sales from the Company’s digital content stores and streaming services, AppleCare, licensing and other services. Services net sales also include amortization of the deferred value of Maps, Siri and free iCloud services, which are bundled in the sales price of certain products. |

[0000320193-19-000119:mdna:15]
iPhone

[0000320193-19-000119:mdna:16]
iPhone net sales decreased during 2019 compared to 2018 due primarily to lower iPhone unit sales.

[0000320193-19-000119:mdna:17]
Mac

[0000320193-19-000119:mdna:18]
Mac net sales increased during 2019 compared to 2018 due primarily to higher net sales of MacBook Air, partially offset by lower net sales of MacBook® and MacBook Pro®.

[0000320193-19-000119:mdna:19]
iPad

[0000320193-19-000119:mdna:20]
iPad net sales increased during 2019 compared to 2018 due primarily to higher net sales of iPad Pro.

[0000320193-19-000119:mdna:21]
Wearables, Home and Accessories

[0000320193-19-000119:mdna:22]
Wearables, Home and Accessories net sales increased during 2019 compared to 2018 due primarily to higher net sales of AirPods and Apple Watch.

[0000320193-19-000119:mdna:23]
Services

[0000320193-19-000119:mdna:24]
Services net sales increased during 2019 compared to 2018 due primarily to higher net sales from the App Store, licensing and AppleCare.

[0000320193-19-000119:mdna:25]
Segment Operating Performance

[0000320193-19-000119:mdna:26]
The Company manages its business primarily on a geographic basis. The Company’s reportable segments consist of the Americas, Europe, Greater China, Japan and Rest of Asia Pacific. Americas includes both North and South America. Europe includes European countries, as well as India, the Middle East and Africa. Greater China includes China, Hong Kong and Taiwan. Rest of Asia Pacific includes Australia and those Asian countries not included in the Company’s other reportable segments. Although the reportable segments provide similar hardware and software products and similar services, each one is managed separately to better align with the location of the Company’s customers and distribution partners and the unique market dynamics of each geographic region. Further information regarding the Company’s reportable segments can be found in Part II, Item 8 of this Form 10-K in the Notes to Consolidated Financial Statements in Note 11, “Segment Information and Geographic Data.”

[0000320193-19-000119:mdna:27]
The following table shows net sales by reportable segment for 2019, 2018 and 2017 (dollars in millions):

[0000320193-19-000119:mdna:28]
|  | 2019 |  | Change |  | 2018 |  | Change |  | 2017 |
| Net sales by reportable segment: |  |  |  |  |  |  |  |  |  |
| Americas | $ | 116,914 |  |  | 4 | % |  | $ | 112,093 |  |  | 16 | % |  | $ | 96,600 |  |
| Europe | 60,288 |  |  | (3 | )% |  | 62,420 |  |  | 14 | % |  | 54,938 |  |
| Greater China | 43,678 |  |  | (16 | )% |  | 51,942 |  |  | 16 | % |  | 44,764 |  |
| Japan | 21,506 |  |  | (1 | )% |  | 21,733 |  |  | 23 | % |  | 17,733 |  |
| Rest of Asia Pacific | 17,788 |  |  | 2 | % |  | 17,407 |  |  | 15 | % |  | 15,199 |  |
| Total net sales | $ | 260,174 |  |  | (2 | )% |  | $ | 265,595 |  |  | 16 | % |  | $ | 229,234 |  |

[0000320193-19-000119:mdna:29]
Americas

[0000320193-19-000119:mdna:30]
Americas net sales increased during 2019 compared to 2018 due primarily to higher Services and Wearables, Home and Accessories net sales, partially offset by lower iPhone net sales. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on Americas net sales during 2019.

[0000320193-19-000119:mdna:31]
Europe

[0000320193-19-000119:mdna:32]
Europe net sales decreased during 2019 compared to 2018 due to lower iPhone net sales, partially offset by higher Wearables, Home and Accessories and Services net sales. The weakness in foreign currencies relative to the U.S. dollar had a significant unfavorable impact on Europe net sales during 2019.

[0000320193-19-000119:mdna:33]
Greater China

[0000320193-19-000119:mdna:34]
Greater China net sales decreased during 2019 compared to 2018 due primarily to lower iPhone net sales, partially offset by higher Wearables, Home and Accessories and Services net sales. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on Greater China net sales during 2019.

[0000320193-19-000119:mdna:35]
Japan

[0000320193-19-000119:mdna:36]
Japan net sales decreased during 2019 compared to 2018 due to lower iPhone net sales, partially offset by higher Services and Wearables, Home and Accessories net sales. The value of the Japanese Yen relative to the U.S. dollar had a favorable impact on Japan net sales during 2019.

[0000320193-19-000119:mdna:37]
Rest of Asia Pacific

[0000320193-19-000119:mdna:38]
Rest of Asia Pacific net sales increased during 2019 compared to 2018 due primarily to higher Wearables, Home and Accessories and Services net sales, partially offset by lower iPhone net sales. The weakness in foreign currencies relative to the U.S. dollar had a significant unfavorable impact on Rest of Asia Pacific net sales during 2019.

[0000320193-19-000119:mdna:39]
Gross Margin

[0000320193-19-000119:mdna:40]
Products and Services gross margin and gross margin percentage for 2019, 2018 and 2017 were as follows (dollars in millions):

[0000320193-19-000119:mdna:41]
|  | 2019 |  | 2018 |  | 2017 |
| Gross margin: |  |  |  |  |  |
| Products | $ | 68,887 |  |  | $ | 77,683 |  |  | $ | 70,197 |  |
| Services | 29,505 |  |  | 24,156 |  |  | 17,989 |  |
| Total gross margin | $ | 98,392 |  |  | $ | 101,839 |  |  | $ | 88,186 |  |
| Gross margin percentage: |  |  |  |  |  |
| Products | 32.2 | % |  | 34.4 | % |  | 35.7 | % |
| Services | 63.7 | % |  | 60.8 | % |  | 55.0 | % |
| Total gross margin percentage | 37.8 | % |  | 38.3 | % |  | 38.5 | % |

[0000320193-19-000119:mdna:42]
Products Gross Margin

[0000320193-19-000119:mdna:43]
Products gross margin and Products gross margin percentage decreased during 2019 compared to 2018 due primarily to lower iPhone unit sales and the weakness in foreign currencies relative to the U.S. dollar.

[0000320193-19-000119:mdna:44]
Products gross margin increased during 2018 compared to 2017 due primarily to a favorable shift in mix of iPhones and the strength in foreign currencies relative to the U.S. dollar, partially offset by higher product cost structures. Year-over-year Products gross margin percentage decreased during 2018 due primarily to higher product cost structures, partially offset by the strength in foreign currencies relative to the U.S. dollar.

[0000320193-19-000119:mdna:45]
Services Gross Margin

[0000320193-19-000119:mdna:46]
Year-over-year Services gross margin increased during 2019 and 2018 due primarily to higher Services net sales and a different services mix. Year-over-year Services gross margin percentage increased during 2019 and 2018 due primarily to a different services mix and leverage of the Company’s services fixed cost structure from higher Services net sales.

[0000320193-19-000119:mdna:47]
The Company’s future gross margins can be impacted by a variety of factors, as set forth in Part I, Item 1A of this Form 10-K under the heading “Risk Factors”. As a result, the Company believes, in general, gross margins will be subject to volatility and remain under downward pressure.

[0000320193-19-000119:mdna:48]
Operating Expenses

[0000320193-19-000119:mdna:49]
Operating expenses for 2019, 2018 and 2017 were as follows (dollars in millions):

[0000320193-19-000119:mdna:50]
|  | 2019 |  | Change |  | 2018 |  | Change |  | 2017 |
| Research and development | $ | 16,217 |  |  | 14 | % |  | $ | 14,236 |  |  | 23 | % |  | $ | 11,581 |  |
| Percentage of total net sales | 6 | % |  |  |  | 5 | % |  |  |  | 5 | % |
| Selling, general and administrative | $ | 18,245 |  |  | 9 | % |  | $ | 16,705 |  |  | 9 | % |  | $ | 15,261 |  |
| Percentage of total net sales | 7 | % |  |  |  | 6 | % |  |  |  | 7 | % |
| Total operating expenses | $ | 34,462 |  |  | 11 | % |  | $ | 30,941 |  |  | 15 | % |  | $ | 26,842 |  |
| Percentage of total net sales | 13 | % |  |  |  | 12 | % |  |  |  | 12 | % |

[0000320193-19-000119:mdna:51]
Research and Development

[0000320193-19-000119:mdna:52]
The year-over-year growth in R&D expense in 2019 was driven primarily by increases in headcount-related expenses. The Company continues to believe that focused investments in R&D are critical to its future growth and competitive position in the marketplace, and to the development of new and updated products and services that are central to the Company’s core business strategy.

[0000320193-19-000119:mdna:53]
Selling, General and Administrative

[0000320193-19-000119:mdna:54]
The year-over-year growth in selling, general and administrative expense in 2019 was driven primarily by increases in headcount-related expenses and higher spending on marketing and advertising and infrastructure-related costs.

[0000320193-19-000119:mdna:55]
Other Income/(Expense), Net

[0000320193-19-000119:mdna:56]
Other income/(expense), net (“OI&E”) for 2019, 2018 and 2017 was as follows (dollars in millions):

[0000320193-19-000119:mdna:57]
|  | 2019 |  | Change |  | 2018 |  | Change |  | 2017 |
| Interest and dividend income | $ | 4,961 |  |  |  |  | $ | 5,686 |  |  |  |  | $ | 5,201 |  |
| Interest expense | (3,576 | ) |  |  |  | (3,240 | ) |  |  |  | (2,323 | ) |
| Other income/(expense), net | 422 |  |  |  |  | (441 | ) |  |  |  | (133 | ) |
| Total other income/(expense), net | $ | 1,807 |  |  | (10 | )% |  | $ | 2,005 |  |  | (27 | )% |  | $ | 2,745 |  |

[0000320193-19-000119:mdna:58]
The year-over-year decrease in OI&E during 2019 was due primarily to lower interest income and higher interest expense, partially offset by the impact of foreign exchange–related items. The weighted-average interest rate earned by the Company on its cash, cash equivalents and marketable securities was 2.19% and 2.16% in 2019 and 2018, respectively.

[0000320193-19-000119:mdna:59]
Provision for Income Taxes

[0000320193-19-000119:mdna:60]
Provision for income taxes, effective tax rate and statutory federal income tax rate for 2019, 2018 and 2017 were as follows (dollars in millions):

[0000320193-19-000119:mdna:61]
|  | 2019 |  | 2018 |  | 2017 |
| Provision for income taxes | $ | 10,481 |  |  | $ | 13,372 |  |  | $ | 15,738 |  |
| Effective tax rate | 15.9 | % |  | 18.3 | % |  | 24.6 | % |
| Statutory federal income tax rate | 21.0 | % |  | 24.5 | % |  | 35.0 | % |

[0000320193-19-000119:mdna:62]
On December 22, 2017, the U.S. enacted the Tax Cuts and Jobs Act (the “Act”), which significantly changed U.S. tax law. The Act lowered the Company’s U.S. statutory federal income tax rate from 35% to 21% effective January 1, 2018, while also imposing a deemed repatriation tax on previously deferred foreign income. By operation of law, the Company applied a blended U.S. statutory federal income tax rate of 24.5% for 2018 (the “2018 blended U.S. tax rate”). The Act also created a new minimum tax on certain foreign earnings.

[0000320193-19-000119:mdna:63]
The Company’s effective tax rate for 2019 was lower than the statutory federal income tax rate due primarily to the lower tax rate on foreign earnings and tax benefits from share-based compensation. The Company’s effective tax rate for 2018 was lower than the 2018 blended U.S. tax rate due primarily to the lower tax rate on foreign earnings, partially offset by the remeasurement of deferred tax assets and liabilities as a result of the Act.

[0000320193-19-000119:mdna:64]
The Company’s effective tax rate for 2019 was lower compared to 2018 due primarily to a lower statutory federal income tax rate in 2019 and the impact of the Act in 2018, partially offset by higher taxes on foreign earnings in 2019.

[0000320193-19-000119:mdna:65]
As of September 28, 2019, the Company had net deferred tax assets arising from deductible temporary differences and tax credits of $14.3 billion and deferred tax liabilities of $6.2 billion. Management believes it is more likely than not that forecasted income, including income that may be generated as a result of certain tax planning strategies, together with future reversals of existing taxable temporary differences, will be sufficient to recover the net deferred tax assets. The Company will continue to evaluate the amount of the valuation allowance, if any, by assessing the realizability of deferred tax assets.

[0000320193-19-000119:mdna:66]
Recent Accounting Pronouncements

[0000320193-19-000119:mdna:67]
Hedging

[0000320193-19-000119:mdna:68]
In August 2017, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) No. 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities (“ASU 2017-12”). ASU 2017-12 expands component and fair value hedging, specifies the presentation of the effects of hedging instruments, and eliminates the separate measurement and presentation of hedge ineffectiveness. The Company will adopt ASU 2017-12 in its first quarter of 2020 utilizing the modified retrospective transition method. Based on the Company’s derivative portfolio and hedging strategies, the adoption of ASU 2017-12 is not expected to have a material impact on its consolidated financial statements.

[0000320193-19-000119:mdna:69]
Financial Instruments

[0000320193-19-000119:mdna:70]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (“ASU 2016-13”), which modifies the measurement of expected credit losses on certain financial instruments. The Company will adopt ASU 2016-13 in its first quarter of 2021 utilizing the modified retrospective transition method. Based on the composition of the Company’s investment portfolio, current market conditions, and historical credit loss activity, the adoption of ASU 2016-13 is not expected to have a material impact on its consolidated financial statements.

[0000320193-19-000119:mdna:71]
Leases

[0000320193-19-000119:mdna:72]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842) (“ASU 2016-02”), which modifies lease accounting for lessees to increase transparency and comparability by recording lease assets and liabilities for operating leases and disclosing key information about leasing arrangements. The Company will adopt ASU 2016-02 utilizing the modified retrospective transition method through a cumulative-effect adjustment at the beginning of its first quarter of 2020. Upon adoption, the Company anticipates recording lease-related assets and liabilities of approximately $8 billion on its Condensed Consolidated Balance Sheet, with no material impact to its Condensed Consolidated Statements of Operations.

[0000320193-19-000119:mdna:73]
Liquidity and Capital Resources

[0000320193-19-000119:mdna:74]
The following table presents selected financial information and statistics as of and for the years ended September 28, 2019, September 29, 2018 and September 30, 2017 (in millions):

[0000320193-19-000119:mdna:75]
|  | 2019 |  | 2018 |  | 2017 |
| Cash, cash equivalents and marketable securities (1) | $ | 205,898 |  |  | $ | 237,100 |  |  | $ | 268,895 |  |
| Property, plant and equipment, net | $ | 37,378 |  |  | $ | 41,304 |  |  | $ | 33,783 |  |
| Commercial paper | $ | 5,980 |  |  | $ | 11,964 |  |  | $ | 11,977 |  |
| Total term debt | $ | 102,067 |  |  | $ | 102,519 |  |  | $ | 103,703 |  |
| Working capital | $ | 57,101 |  |  | $ | 15,410 |  |  | $ | 28,792 |  |
| Cash generated by operating activities | $ | 69,391 |  |  | $ | 77,434 |  |  | $ | 64,225 |  |
| Cash generated by/(used in) investing activities | $ | 45,896 |  |  | $ | 16,066 |  |  | $ | (46,446 | ) |
| Cash used in financing activities | $ | (90,976 | ) |  | $ | (87,876 | ) |  | $ | (17,974 | ) |

[0000320193-19-000119:mdna:76]
| (1) | As of September 28, 2019 and September 29, 2018, total cash, cash equivalents and marketable securities included $18.9 billion and $20.3 billion, respectively, that was restricted from general use, related to the State Aid Decision (refer to Note 5, “Income Taxes” in the Notes to Consolidated Financial Statements in Part II, Item 8 of this Form 10-K) and other agreements. |

[0000320193-19-000119:mdna:77]
The Company believes its existing balances of cash, cash equivalents and marketable securities, along with commercial paper and other short-term liquidity arrangements, will be sufficient to satisfy its working capital needs, capital asset purchases, dividends, share repurchases, debt repayments and other liquidity requirements associated with its existing operations over the next 12 months.

[0000320193-19-000119:mdna:78]
In connection with the State Aid Decision, as of September 28, 2019, the entire adjusted recovery amount of €12.9 billion plus interest of €1.2 billion was funded into escrow, where it will remain restricted from general use pending the conclusion of all appeals. Further information regarding the State Aid Decision can be found in Part II, Item 8 of this Form 10-K in the Notes to Consolidated Financial Statements in Note 5, “Income Taxes.”

[0000320193-19-000119:mdna:79]
The Company’s marketable securities investment portfolio is primarily invested in highly rated securities, with the primary objective of minimizing the potential risk of principal loss. The Company’s investment policy generally requires securities to be investment grade and limits the amount of credit exposure to any one issuer.

[0000320193-19-000119:mdna:80]
During 2019, cash generated by operating activities of $69.4 billion was a result of $55.3 billion of net income and non-cash adjustments to net income of $17.6 billion, partially offset by a decrease in the net change in operating assets and liabilities of $3.5 billion. Cash generated by investing activities of $45.9 billion during 2019 consisted primarily of proceeds from sales and maturities of marketable securities, net of purchases, of $57.5 billion, partially offset by cash used to acquire property, plant and equipment of $10.5 billion. Cash used in financing activities of $91.0 billion during 2019 consisted primarily of cash used to repurchase common stock of $66.9 billion, cash used to pay dividends and dividend equivalents of $14.1 billion, cash used to repay term debt of $8.8 billion and net repayments of commercial paper of $6.0 billion, partially offset by net proceeds from the issuance of term debt of $7.0 billion.

[0000320193-19-000119:mdna:81]
During 2018, cash generated by operating activities of $77.4 billion was a result of $59.5 billion of net income and an increase in the net change in operating assets and liabilities of $34.7 billion, partially offset by non-cash adjustments to net income of $16.8 billion. Cash generated by investing activities of $16.1 billion during 2018 consisted primarily of proceeds from maturities and sales of marketable securities, net of purchases, of $32.4 billion, partially offset by cash used to acquire property, plant and equipment of $13.3 billion. Cash used in financing activities of $87.9 billion during 2018 consisted primarily of cash used to repurchase common stock of $72.7 billion, cash used to pay dividends and dividend equivalents of $13.7 billion and cash used to repay term debt of $6.5 billion, partially offset by net proceeds from the issuance of term debt of $7.0 billion.

[0000320193-19-000119:mdna:82]
Capital Assets

[0000320193-19-000119:mdna:83]
The Company’s capital expenditures were $7.6 billion during 2019, which included product tooling and manufacturing process equipment; data centers; corporate facilities and infrastructure, including information systems hardware, software and enhancements; and retail store facilities.

[0000320193-19-000119:mdna:84]
Debt

[0000320193-19-000119:mdna:85]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses the net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of September 28, 2019, the Company had $6.0 billion of Commercial Paper outstanding, with a weighted-average interest rate of 2.24% and maturities generally less than nine months.

[0000320193-19-000119:mdna:86]
As of September 28, 2019, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $101.7 billion (collectively the “Notes”). During 2019, the Company issued $7.0 billion and repaid $8.8 billion of Notes. The Company has entered, and in the future may enter, into interest rate swaps to manage interest rate risk on the Notes. In addition, the Company has entered, and in the future may enter, into foreign currency swaps to manage foreign currency risk on the Notes.

[0000320193-19-000119:mdna:87]
Further information regarding the Company’s debt issuances and related hedging activity can be found in Part II, Item 8 of this Form 10-K in the Notes to Consolidated Financial Statements in Note 3, “Financial Instruments” and Note 6, “Debt.”

[0000320193-19-000119:mdna:88]
Capital Return Program

[0000320193-19-000119:mdna:89]
On April 30, 2019, the Company announced the Board of Directors increased the current share repurchase program authorization from $100 billion to $175 billion of the Company’s common stock, of which $96.1 billion had been utilized as of September 28, 2019. During 2019, the Company repurchased 345.2 million shares of its common stock for $67.1 billion, including 62.0 million shares delivered under a $12.0 billion ASR dated February 2019, which settled in August 2019. The Company’s share repurchase program does not obligate it to acquire any specific number of shares. Under this program, shares may be repurchased in privately negotiated and/or open market transactions, including under plans complying with Rule 10b5-1 under the Exchange Act.

[0000320193-19-000119:mdna:90]
On April 30, 2019, the Company also announced the Board of Directors raised the Company’s quarterly cash dividend from $0.73 to $0.77 per share, beginning with the dividend paid during the third quarter of 2019. The Company intends to increase its dividend on an annual basis, subject to declaration by the Board of Directors.

[0000320193-19-000119:mdna:91]
Contractual Obligations

[0000320193-19-000119:mdna:92]
The following table presents certain payments due by the Company as of September 28, 2019, and excludes amounts already recorded on the Consolidated Balance Sheet, except for term debt and the deemed repatriation tax payable (in millions):

[0000320193-19-000119:mdna:93]
|  | Payments due in 2020 |  | Payments due in 2021–2022 |  | Payments due in 2023–2024 |  | Payments due after 2024 |  | Total |
| Term debt | $ | 10,270 |  |  | $ | 18,278 |  |  | $ | 19,329 |  |  | $ | 53,802 |  |  | $ | 101,679 |  |
| Operating leases | 1,306 |  |  | 2,413 |  |  | 1,746 |  |  | 5,373 |  |  | 10,838 |  |
| Manufacturing purchase obligations (1) | 40,076 |  |  | 1,974 |  |  | 808 |  |  | 69 |  |  | 42,927 |  |
| Other purchase obligations | 3,744 |  |  | 2,271 |  |  | 572 |  |  | 41 |  |  | 6,628 |  |
| Deemed repatriation tax payable | — |  |  | 4,350 |  |  | 8,501 |  |  | 16,655 |  |  | 29,506 |  |
| Total | $ | 55,396 |  |  | $ | 29,286 |  |  | $ | 30,956 |  |  | $ | 75,940 |  |  | $ | 191,578 |  |

[0000320193-19-000119:mdna:94]
| (1) | Represents amount expected to be paid under manufacturing-related supplier arrangements, which are primarily noncancelable. |

[0000320193-19-000119:mdna:95]
Operating Leases

[0000320193-19-000119:mdna:96]
The Company’s retail store and other facility leases typically have original terms not exceeding 10 years and generally contain multi-year renewal options.

[0000320193-19-000119:mdna:97]
Manufacturing Purchase Obligations

[0000320193-19-000119:mdna:98]
The Company utilizes several outsourcing partners to manufacture sub-assemblies for the Company’s products and to perform final assembly and testing of finished products. These outsourcing partners acquire components and build product based on demand information supplied by the Company, which typically covers periods up to 150 days. The Company also obtains individual components for its products from a wide variety of individual suppliers.

[0000320193-19-000119:mdna:99]
Other Purchase Obligations

[0000320193-19-000119:mdna:100]
The Company’s other purchase obligations consist of noncancelable obligations to acquire capital assets, including product tooling and manufacturing process equipment, and noncancelable obligations related to advertising, licensing, R&D, Internet and telecommunications services, content creation and other activities.

[0000320193-19-000119:mdna:101]
Deemed Repatriation Tax Payable

[0000320193-19-000119:mdna:102]
As of September 28, 2019, a significant portion of the other non-current liabilities in the Company’s Consolidated Balance Sheet consisted of the deemed repatriation tax payable imposed by the Act. The Company plans to pay the deemed repatriation tax payable in installments in accordance with the Act.

[0000320193-19-000119:mdna:103]
Other Non-Current Liabilities

[0000320193-19-000119:mdna:104]
The Company’s remaining other non-current liabilities primarily consist of items for which the Company is unable to make a reasonably reliable estimate of the timing or amount of payments; therefore, such amounts are not included in the above contractual obligation table.

[0000320193-19-000119:mdna:105]
Critical Accounting Policies and Estimates

[0000320193-19-000119:mdna:106]
The preparation of financial statements and related disclosures in conformity with U.S. generally accepted accounting principles (“GAAP”) and the Company’s discussion and analysis of its financial condition and operating results require the Company’s management to make judgments, assumptions and estimates that affect the amounts reported. Note 1, “Summary of Significant Accounting Policies,” of the Notes to Consolidated Financial Statements in Part II, Item 8 of this Form 10-K describes the significant accounting policies and methods used in the preparation of the Company’s consolidated financial statements. Management bases its estimates on historical experience and on various other assumptions it believes to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities. Actual results may differ from these estimates, and such differences may be material.

[0000320193-19-000119:mdna:107]
Management believes the Company’s critical accounting policies and estimates are those related to revenue recognition, valuation of manufacturing-related assets and estimation of inventory purchase commitment cancellation fees, warranty costs, income taxes, and legal and other contingencies. Management considers these policies critical because they are both important to the portrayal of the Company’s financial condition and operating results, and they require management to make judgments and estimates about inherently uncertain matters. The Company’s senior management has reviewed these critical accounting policies and related disclosures with the Audit and Finance Committee of the Company’s Board of Directors.

[0000320193-19-000119:mdna:108]
Revenue Recognition

[0000320193-19-000119:mdna:109]
The Company has identified up to three performance obligations regularly included in arrangements involving the sale of iPhone, Mac, iPad and certain other products. The first performance obligation, which represents the substantial portion of the allocated sales price, is the hardware and bundled software delivered at the time of sale. The second performance obligation is the right to receive certain product-related bundled services, which include iCloud, Siri and Maps. The third performance obligation is the right to receive, on a when-and-if-available basis, future unspecified software upgrades relating to the software bundled with each device. The Company allocates revenue and any related discounts to these performance obligations based on their relative stand-alone selling prices (“SSPs”). Because the Company lacks observable prices for the undelivered performance obligations, the allocation of revenue is based on the Company’s estimated SSPs. Revenue allocated to the product-related bundled services and unspecified software upgrade rights is deferred and recognized on a straight-line basis over the estimated period they are expected to be provided.

[0000320193-19-000119:mdna:110]
The Company’s process for determining estimated SSPs involves management’s judgment and considers multiple factors that may vary over time depending upon the unique facts and circumstances related to each deliverable. Should future facts and circumstances change, the Company’s SSPs and the future rate of related amortization for product-related bundled services and unspecified software upgrade rights related to future sales of these devices could change. Factors subject to change include the nature of the product-related bundled services and unspecified software upgrade rights offered, their estimated value and the estimated period they are expected to be provided.

[0000320193-19-000119:mdna:111]
Valuation of Manufacturing-Related Assets and Estimation of Inventory Purchase Commitment Cancellation Fees

[0000320193-19-000119:mdna:112]
The Company invests in manufacturing-related assets, including capital assets held at its suppliers’ facilities and prepayments provided to certain of its suppliers associated with long-term agreements to secure the supply of inventory. The Company also accrues estimated purchase commitment cancellation fees related to inventory orders that have been canceled or are expected to be canceled. The Company’s estimates of future product development plans and demand for its products are the key inputs in the determination of the recoverability of manufacturing-related assets and the assessment of the adequacy of any purchase commitment cancellation fee accruals. If there is an abrupt and substantial decline in estimated demand for one or more of the Company’s products, a change in the Company’s product development plans, or an unanticipated change in technological requirements for any of the Company’s products, the Company may be required to record write-downs or impairments of manufacturing-related assets or accrue purchase commitment cancellation fees.

[0000320193-19-000119:mdna:113]
Warranty Costs

[0000320193-19-000119:mdna:114]
The Company offers limited warranties on its new hardware products and on parts used to repair its hardware products, and customers may purchase extended service coverage, where available, on many of the Company’s hardware products. The Company accrues the estimated cost of warranties in the period the related revenue is recognized based on historical and projected warranty claim rates, historical and projected cost per claim and knowledge of specific product failures outside the Company’s typical experience. The Company regularly reviews these estimates and adjusts the amounts as necessary. If actual product failure rates or repair costs differ from estimates, revisions to the estimated warranty liabilities would be required.

[0000320193-19-000119:mdna:115]
Income Taxes

[0000320193-19-000119:mdna:116]
The Company recognizes tax benefits from uncertain tax positions only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater-than-50% likelihood of being realized upon ultimate settlement. The calculation of tax liabilities involves significant judgment in estimating the impact of uncertainties in the application of GAAP and complex tax laws. Resolution of these uncertainties in a manner inconsistent with management’s expectations could have a material impact on the Company’s financial condition and operating results.

[0000320193-19-000119:mdna:117]
Legal and Other Contingencies

[0000320193-19-000119:mdna:118]
As discussed in Part I, Item 3 of this Form 10-K under the heading “Legal Proceedings” and in Part II, Item 8 of this Form 10-K in the Notes to Consolidated Financial Statements in Note 10, “Commitments and Contingencies,” the Company is subject to various legal proceedings and claims that arise in the ordinary course of business. The Company records a liability when it is probable that a loss has been incurred and the amount is reasonably estimable, the determination of which requires significant judgment. Except as described in Part II, Item 8 of this Form 10-K in the Notes to Consolidated Financial Statements in Note 10, “Commitments and Contingencies” under the heading “Contingencies,” in the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss greater than a recorded accrual, concerning loss contingencies for asserted legal and other claims.

[0000320193-19-000119:mdna:119]
The outcome of litigation is inherently uncertain. If one or more legal matters were resolved against the Company in a reporting period for amounts above management’s expectations, the Company’s financial condition and operating results for that reporting period could be materially adversely affected.
