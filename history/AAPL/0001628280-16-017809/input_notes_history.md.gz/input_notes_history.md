# AAPL note change history — 0001193125-16-559625 → 0001628280-16-017809


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-07-27):
[0001628280-16-017809:note_history:1]
Commitments and Contingencies
  (was, 2016-04-27, similarity 0.8657):
[0001193125-16-559625:note_history:1]
Note 10 – Commitments and Contingencies

- changed (2016-07-27):
[0001628280-16-017809:note_history:2]
The following table shows changes in the Company’s accrued warranties and related costs for the three- and nine-month periods ended June 25, 2016 and June 27, 2015 (in millions):
  (was, 2016-04-27, similarity 0.9318):
[0001193125-16-559625:note_history:2]
The following table shows changes in the
 Company’s accrued warranties and related costs for the three-
 and six-month periods ended March 26, 2016 and March 28,
 2015 (in millions):

- changed (2016-07-27):
[0001628280-16-017809:note_history:3]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25, 2016 |  | June 27, 2015 |  | June 25, 2016 |  | June 27, 2015 |
| Beginning accrued warranty and related costs | $ | 4,985 |  |  | $ | 5,143 |  |  | $ | 4,780 |  |  | $ | 4,159 |  |
| Cost of warranty claims | (1,110 | ) |  | (1,077 | ) |  | (3,507 | ) |  | (3,151 | ) |
| Accruals for product warranty | 380 |  |  | 1,071 |  |  | 2,982 |  |  | 4,129 |  |
| Ending accrued warranty and related costs | $ | 4,255 |  |  | $ | 5,137 |  |  | $ | 4,255 |  |  | $ | 5,137 |  |
  (was, 2016-04-27, similarity 0.6011):
[0001193125-16-559625:note_history:3]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 26, 2016 |  |  | March 28, 2015 |  |  | March 26, 2016 |  |  | March 28, 2015 |  |
| Beginning accrued warranty and related costs |  | $ | 5,236 |  |  | $ | 5,195 |  |  | $ | 4,780 |  |  | $ | 4,159 |  |
| Cost of warranty claims |  |  | (1,128 | ) |  |  | (1,030 | ) |  |  | (2,397 | ) |  |  | (2,074 | ) |
| Accruals for product warranty |  |  | 877 |  |  |  | 978 |  |  |  | 2,602 |  |  |  | 3,058 |  |
| Ending accrued warranty and related costs |  | $ | 4,985 |  |  | $ | 5,143 |  |  | $ | 4,985 |  |  | $ | 5,143 |  |

- added (2016-07-27):
[0001628280-16-017809:note_history:4]
The Company offers an iPhone Upgrade Program, which is available to customers who purchase an iPhone 6s and 6s Plus in its U.S. retail and online stores and activate the purchased iPhone with one of the four U.S. national carriers. The iPhone Upgrade Program provides customers the right to trade in that iPhone for a new iPhone, provided certain conditions are met. One of the conditions of this program requires the customer to finance the initial purchase price of the iPhone with a third-party lender. Upon exercise of the trade-in right and purchase of a new iPhone, the Company satisfies the customer’s outstanding balance due to the third-party lender on the original device. The Company accounts for the trade-in right as a guarantee liability and recognizes arrangement revenue net of the fair value of such right with subsequent changes to the guarantee liability recognized within revenue.

- added (2016-07-27):
[0001628280-16-017809:note_history:5]
The Company leases various equipment and facilities, including retail space, under noncancelable operating lease arrangements. As of June 25, 2016, the Company’s total future minimum lease payments under noncancelable operating leases were $7.1 billion. The Company's retail store and other facility leases are typically for terms not exceeding 10 years and generally contain multi-year renewal options.

- changed (2016-07-27):
[0001628280-16-017809:note_history:6]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully adjudicated, as further discussed in Part II, Item 1 of this Form 10-Q under the heading “Legal Proceedings” and in Part II, Item 1A of this Form 10-Q under the heading “Risk Factors.” In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to loss contingencies for asserted legal and other claims. However, the outcome of litigation is inherently uncertain. Therefore, although management considers the likelihood of such an outcome to be remote, if one or more of these legal matters were resolved against the Company in a reporting period for amounts in excess of management’s expectations, the Company’s consolidated financial statements for that reporting period could be materially adversely affected.
  (was, 2016-04-27, similarity 0.9848):
[0001193125-16-559625:note_history:6]
The Company is subject to various legal proceedings
 and claims that have arisen in the ordinary course of business and
 that have not been fully adjudicated, certain of which are
 discussed in Part II, Item 1 of this Form 10-Q under the
 heading “Legal Proceedings” and in Part II,
 Item 1A of this Form 10-Q under the heading “Risk
 Factors.” In the opinion of management, there was not at
 least a reasonable possibility the Company may have incurred a
 material loss, or a material loss in excess of a recorded accrual,
 with respect to loss contingencies for asserted legal and other
 claims. However, the outcome of litigation is inherently uncertain.
 Therefore, although management considers the likelihood of such an
 outcome to be remote, if one or more of these legal matters were
 resolved against the Company in a reporting period for amounts in
 excess of management’s expectations, the Company’s
 consolidated financial statements for that reporting period could
 be materially adversely affected.

- removed (2016-07-27):
[0001193125-16-559625:note_history:7]
The Company offers an iPhone Upgrade Program, which
 is available to customers who purchase an iPhone 6s and 6s Plus in
 one of its U.S. physical retail stores and activate the purchased
 iPhone with one of the four national carriers. The iPhone Upgrade
 Program provides customers the right to trade in that iPhone for a
 new iPhone, provided certain conditions are met. One of the
 conditions of this program requires the customer to finance the
 initial purchase price of the iPhone with a third-party lender.
 Upon exercise of the trade-in right and purchase of a new iPhone,
 the Company satisfies the customer’s outstanding balance due
 to the third-party lender on the original device. The Company
 accounts for the trade-in right as a guarantee liability and
 recognizes arrangement revenue net of the fair value of such right
 with subsequent changes to the guarantee liability recognized
 within revenue.

- removed (2016-07-27):
[0001193125-16-559625:note_history:8]
The Company leases various equipment and
 facilities, including retail space, under noncancelable operating
 lease arrangements. The major facility leases are typically for
 terms not exceeding 10 years and generally contain multi-year
 renewal options. As of March 26, 2016, the Company had a total
 of 475 retail stores. Leases for retail space are for terms ranging
 from five to 20 years, the majority of which are for 10 years, and
 often contain multi-year renewal options. As of March 26,
 2016, the Company’s total future minimum lease payments under
 noncancelable operating leases were $6.8 billion, of which $3.9
 billion related to leases for retail space.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-07-27):
[0001628280-16-017809:note_history:9]
Summary of Significant Accounting Policies
  (was, 2016-04-27, similarity 0.9032):
[0001193125-16-559625:note_history:9]
Note 1 – Summary of Significant Accounting
 Policies

- changed (2016-07-27):
[0001628280-16-017809:note_history:10]
These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company's annual consolidated financial statements and the notes thereto included in its Annual Report on Form 10-K for the fiscal year ended September 26, 2015 (the “2015 Form 10-K”). The Company’s fiscal year is the 52 or 53-week period that ends on the last Saturday of September. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal quarters with calendar quarters, which will next occur in the first quarter of fiscal year 2017. The Company’s fiscal years 2016 and 2015 each include 52 weeks. Unless otherwise stated, references to particular years, quarters or months refer to the Company’s fiscal years ended in September and the associated quarters or months of those fiscal years.
  (was, 2016-04-27, similarity 0.6995):
[0001193125-16-559625:note_history:10]
These condensed consolidated financial statements
 and accompanying notes should be read in conjunction with the
 Company’s annual consolidated financial statements and the
 notes thereto included in its Annual Report on Form 10-K for the
 fiscal year ended September 26, 2015 (the “2015 Form
 10-K”). The Company’s fiscal year is the 52 or 53-week
 period that ends on the last Saturday of September. An additional
 week is included in the first fiscal quarter approximately every
 six years to realign fiscal quarters with calendar quarters. The
 Company’s fiscal years 2016 and 2015 each include 52 weeks.
 Unless otherwise stated, references to particular years, quarters
 or months refer to the Company’s fiscal years ended in
 September and the associated quarters or months of those fiscal
 years.

- changed (2016-07-27):
[0001628280-16-017809:note_history:11]
The following table shows the computation of basic and diluted earnings per share for the three- and nine-month periods ended June 25, 2016 and June 27, 2015 (net income in millions and shares in thousands):
  (was, 2016-04-27, similarity 0.9418):
[0001193125-16-559625:note_history:11]
The following table shows the computation of basic
 and diluted earnings per share for the three- and six-month periods
 ended March 26, 2016 and March 28, 2015 (net income in
 millions and shares in thousands):

- added (2016-07-27):
[0001628280-16-017809:note_history:12]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25, 2016 |  | June 27, 2015 |  | June 25, 2016 |  | June 27, 2015 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 7,796 |  |  | $ | 10,677 |  |  | $ | 36,673 |  |  | $ | 42,270 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average shares outstanding | 5,443,058 |  |  | 5,729,886 |  |  | 5,505,456 |  |  | 5,788,922 |  |
| Effect of dilutive securities | 29,723 |  |  | 43,213 |  |  | 30,475 |  |  | 40,998 |  |
| Weighted-average diluted shares | 5,472,781 |  |  | 5,773,099 |  |  | 5,535,931 |  |  | 5,829,920 |  |
| Basic earnings per share | $ | 1.43 |  |  | $ | 1.86 |  |  | $ | 6.66 |  |  | $ | 7.30 |  |
| Diluted earnings per share | $ | 1.42 |  |  | $ | 1.85 |  |  | $ | 6.62 |  |  | $ | 7.25 |  |

- removed (2016-07-27):
[0001193125-16-559625:note_history:13]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 26, 2016 |  |  | March 28, 2015 |  |  | March 26, 2016 |  |  | March 28, 2015 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 10,516 |  |  | $ | 13,569 |  |  | $ | 28,877 |  |  | $ | 31,593 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding |  |  | 5,514,381 |  |  |  | 5,793,799 |  |  |  | 5,536,656 |  |  |  | 5,818,441 |  |
| Effect of dilutive securities |  |  | 26,505 |  |  |  | 41,059 |  |  |  | 30,850 |  |  |  | 39,889 |  |
| Weighted-average diluted shares |  |  | 5,540,886 |  |  |  | 5,834,858 |  |  |  | 5,567,506 |  |  |  | 5,858,330 |  |
| Basic earnings per share |  | $ | 1.91 |  |  | $ | 2.34 |  |  | $ | 5.22 |  |  | $ | 5.43 |  |
| Diluted earnings per share |  | $ | 1.90 |  |  | $ | 2.33 |  |  | $ | 5.19 |  |  | $ | 5.39 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2016-07-27):
[0001628280-16-017809:note_history:14]
Debt

- changed (2016-07-27):
[0001628280-16-017809:note_history:15]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of June 25, 2016 and September 26, 2015, the Company had $12.5 billion and $8.5 billion of Commercial Paper outstanding, respectively, with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 0.42% as of June 25, 2016 and 0.14% as of September 26, 2015.
  (was, 2016-04-27, similarity 0.9835):
[0001193125-16-559625:note_history:15]
The Company issues unsecured short-term promissory
 notes (“Commercial Paper”) pursuant to a commercial
 paper program. The Company uses net proceeds from the commercial
 paper program for general corporate purposes, including dividends
 and share repurchases. As of March 26, 2016 and
 September 26, 2015, the Company had $8.0 billion and $8.5
 billion of Commercial Paper outstanding, respectively, with
 maturities generally less than nine months. The weighted-average
 interest rate of the Company’s Commercial Paper was 0.39% as
 of March 26, 2016 and 0.14% as of September 26, 2015.

- changed (2016-07-27):
[0001628280-16-017809:note_history:16]
The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the nine months ended June 25, 2016 and June 27, 2015 (in millions):
  (was, 2016-04-27, similarity 0.9359):
[0001193125-16-559625:note_history:16]
The following table provides a summary of cash
 flows associated with the issuance and maturities of Commercial
 Paper for the six months ended March 26, 2016 and
 March 28, 2015 (in millions):

- added (2016-07-27):
[0001628280-16-017809:note_history:17]
|  | Nine Months Ended |
|  | June 25, 2016 |  | June 27, 2015 |
| Maturities less than 90 days: |  |  |  |
| Proceeds from (repayments of) commercial paper, net | $ | 4,154 |  |  | $ | 579 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 1,846 |  |  | 2,601 |  |
| Repayments of commercial paper | (2,008 | ) |  | (4,988 | ) |
| Proceeds from (repayments of) commercial paper, net | (162 | ) |  | (2,387 | ) |
| Total change in commercial paper, net | $ | 3,992 |  |  | $ | (1,808 | ) |

- changed (2016-07-27):
[0001628280-16-017809:note_history:18]
As of June 25, 2016, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $71.6 billion (collectively the “Notes”). The Notes are senior unsecured obligations, and interest is payable in arrears, quarterly for the U.S. dollar-denominated and Australian dollar-denominated floating-rate notes, semi-annually for the U.S. dollar-denominated, Australian dollar-denominated, British pound-denominated and Japanese yen-denominated fixed-rate notes and annually for the euro-denominated and Swiss franc-denominated fixed-rate notes. The following table provides a summary of the Company’s term debt as of June 25, 2016 and September 26, 2015:
  (was, 2016-04-27, similarity 0.9869):
[0001193125-16-559625:note_history:18]
As of March 26, 2016, the Company had
 outstanding floating- and fixed-rate notes with varying maturities
 for an aggregate principal amount of $71.3 billion (collectively
 the “Notes”). The Notes are senior unsecured
 obligations, and interest is payable in arrears, quarterly for the
 U.S. dollar-denominated and Australian dollar-denominated
 floating-rate notes, semi-annually for the U.S. dollar-denominated,
 Australian dollar-denominated, British pound-denominated and
 Japanese yen-denominated fixed-rate notes and annually for the
 euro-denominated and Swiss franc-denominated fixed-rate notes. The
 following table provides a summary of the Company’s term debt
 as of March 26, 2016 and September 26, 2015:

- added (2016-07-27):
[0001628280-16-017809:note_history:19]
|  | Maturities |  | June 25, 2016 |  | September 26, 2015 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2018 |  | $ | 2,000 |  |  | 1.10% |  |  | $ | 3,000 |  |  | 0.51% - 1.10% |  |
| Fixed-rate 1.00% - 3.85% notes | 2018 - 2043 |  | 12,500 |  |  | 1.08% - 3.91% |  |  | 14,000 |  |  | 0.51% - 3.91% |  |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2017 - 2019 |  | 2,000 |  |  | 0.70% - 0.93% |  |  | 2,000 |  |  | 0.37% - 0.60% |  |
| Fixed-rate 1.05% - 4.45% notes | 2017 - 2044 |  | 10,000 |  |  | 0.70% - 4.48% |  |  | 10,000 |  |  | 0.37% - 4.48% |  |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2017 - 2020 |  | 1,774 |  |  | 0.68% - 1.87% |  |  | 1,743 |  |  | 0.36% - 1.87% |  |
| Fixed-rate 0.35% - 4.375% notes | 2017 - 2045 |  | 25,347 |  |  | 0.28% - 4.51% |  |  | 24,958 |  |  | 0.28% - 4.51% |  |
| Second quarter 2016 debt issuance of $15.5 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 |  | 500 |  |  | 1.47 | % |  | — |  |  | — |  |
| Floating-rate notes | 2021 |  | 500 |  |  | 1.78 | % |  | — |  |  | — |  |
| Fixed-rate 1.30% notes | 2018 |  | 500 |  |  | 1.32 | % |  | — |  |  | — |  |
| Fixed-rate 1.70% notes | 2019 |  | 1,000 |  |  | 1.71 | % |  | — |  |  | — |  |
| Fixed-rate 2.25% notes | 2021 |  | 3,000 |  |  | 1.80 | % |  | — |  |  | — |  |
| Fixed-rate 2.85% notes | 2023 |  | 1,500 |  |  | 2.50 | % |  | — |  |  | — |  |
| Fixed-rate 3.25% notes | 2026 |  | 3,250 |  |  | 2.40 | % |  | — |  |  | — |  |
| Fixed-rate 4.50% notes | 2036 |  | 1,250 |  |  | 4.54 | % |  | — |  |  | — |  |
| Fixed-rate 4.65% notes | 2046 |  | 4,000 |  |  | 4.58 | % |  | — |  |  | — |  |
| Third quarter 2016 Australian dollar-denominated debt issuance of A$1.4 billion: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 2.65% notes | 2020 |  | 487 |  |  | 1.92 | % |  | — |  |  | — |  |
| Fixed-rate 3.35% notes | 2024 |  | 337 |  |  | 2.61 | % |  | — |  |  | — |  |
| Fixed-rate 3.60% notes | 2026 |  | 243 |  |  | 2.84 | % |  | — |  |  | — |  |
| Third quarter 2016 debt issuance of $1.4 billion: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 4.15% notes | 2046 |  | 1,377 |  |  | 4.15 | % |  | — |  |  | — |  |
| Total term debt |  |  | 71,565 |  |  |  |  | 55,701 |  |  |  |
| Unamortized premium/(discount) |  |  | 14 |  |  |  |  | (114 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 860 |  |  |  |  | 376 |  |  |  |
| Less: Current portion of long-term debt |  |  | (3,500 | ) |  |  |  | (2,500 | ) |  |  |
| Total long-term debt |  |  | $ | 68,939 |  |  |  |  | $ | 53,463 |  |  |  |

- added (2016-07-27):
[0001628280-16-017809:note_history:20]
During the third quarter of 2016, the Company issued $1.4 billion U.S. dollar-denominated notes in Taiwan and A$1.4 billion    Australian dollar-denominated notes. To manage foreign currency risk associated with the Australian dollar-denominated notes, the Company entered into currency swaps with an aggregate notional amount of $1.0 billion, which effectively converted these notes to U.S. dollar-denominated notes.

- changed (2016-07-27):
[0001628280-16-017809:note_history:21]
During the second quarter of 2016, the Company issued $15.5 billion U.S. dollar-denominated notes. To manage interest rate risk on the fixed-rate notes maturing in 2021, 2023 and 2026, the Company entered into interest rate swaps with an aggregate notional amount of  $5.0 billion, which effectively converted a portion of the fixed interest rates on these notes to a floating interest rate.
  (was, 2016-04-27, similarity 0.9686):
[0001193125-16-559625:note_history:21]
During the second quarter of 2016, the Company
 issued $15.5 billion U.S. dollar-denominated notes. To manage
 interest rate risk on the U.S. dollar-denominated fixed-rate notes
 maturing in 2021, 2023 and 2026, the Company entered into interest
 rate swaps with an aggregate notional amount of $5.0 billion, which
 effectively converted a portion of the fixed interest rates on
 these notes to a floating interest rate.

- added (2016-07-27):
[0001628280-16-017809:note_history:22]
As of June 25, 2016, ¥191.0 billion of Japanese yen-denominated notes was designated as a hedge of the foreign currency exposure of its net investment in a foreign operation. The foreign currency transaction gain or loss on the Japanese yen-denominated debt designated as a hedge is recorded in OCI as a part of the cumulative translation adjustment.  As of June 25, 2016 and September 26, 2015, the carrying value of the debt designated as a net investment hedge was $1.8 billion and $2.1 billion, respectively. For further discussion regarding the Company’s use of derivative instruments see the Derivative Financial Instruments section of Note 2, “Financial Instruments.”

- changed (2016-07-27):
[0001628280-16-017809:note_history:23]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount and, if applicable, adjustments related to hedging. The Company recognized $393 million and $975 million of interest expense on its term debt for the three- and nine-month periods ended June 25, 2016, respectively. The Company recognized $197 million and $486 million of interest expense on its term debt for the three- and nine-month periods ended June 27, 2015, respectively.
  (was, 2016-04-27, similarity 0.9655):
[0001193125-16-559625:note_history:23]
The effective interest rates for the Notes include
 the interest on the Notes, amortization of the discount and, if
 applicable, adjustments related to hedging. The Company recognized
 $311 million and $582 million of interest expense on its term debt
 for the three- and six-month periods ended March 26, 2016,
 respectively. The Company recognized $161 million and $289 million
 of interest expense on its term debt for the three- and six-month
 periods ended March 28, 2015, respectively.

- changed (2016-07-27):
[0001628280-16-017809:note_history:24]
As of June 25, 2016 and September 26, 2015, the fair value of the Company’s Notes, based on Level 2 inputs, was $74.1 billion and $54.9 billion, respectively.
  (was, 2016-04-27, similarity 0.9682):
[0001193125-16-559625:note_history:24]
As of March 26, 2016 and September 26,
 2015, the fair value of the Company’s Notes, based on Level 2
 inputs, was $72.4 billion and $54.9 billion, respectively.

- removed (2016-07-27):
[0001193125-16-559625:note_history:25]
Note 6 – Debt

- removed (2016-07-27):
[0001193125-16-559625:note_history:26]
|  |  | Six Months Ended |  |
|  |  | March 26, 2016 |  |  | March 28, 2015 |  |
| Maturities less than 90 days: |  |  |  |  |  |  |  |  |
| Proceeds from (repayments of) commercial paper, net |  | $ | 660 |  |  | $ | 985 |  |
| Maturities greater than 90 days: |  |  |  |  |  |  |  |  |
| Proceeds from commercial paper |  |  | 669 |  |  |  | 547 |  |
| Repayments of commercial paper |  |  | (1,832 | ) |  |  | (4,040 | ) |
| Proceeds from (repayments of) commercial paper, net |  |  | (1,163 | ) |  |  | (3,493 | ) |
| Total change in commercial paper, net |  | $ | (503 | ) |  | $ | (2,508 | ) |

- removed (2016-07-27):
[0001193125-16-559625:note_history:27]
|  |  |  |  |  | March, 26, 2016 |  |  | September 26, 2015 |  |
|  |  | Maturities |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2016 - 2018 |  |  | $ | 3,000 |  |  |  | 0.51% - 1.10% |  |  | $ | 3,000 |  |  |  | 0.51% - 1.10% |  |
| Fixed-rate 0.45% - 3.85% notes |  |  | 2016 - 2043 |  |  |  | 14,000 |  |  |  | 0.51% - 3.91% |  |  |  | 14,000 |  |  |  | 0.51% - 3.91% |  |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2017 - 2019 |  |  |  | 2,000 |  |  |  | 0.69% - 0.92% |  |  |  | 2,000 |  |  |  | 0.37% - 0.60% |  |
| Fixed-rate 1.05% - 4.45% notes |  |  | 2017 - 2044 |  |  |  | 10,000 |  |  |  | 0.69% - 4.48% |  |  |  | 10,000 |  |  |  | 0.37% - 4.48% |  |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2017 - 2020 |  |  |  | 1,781 |  |  |  | 0.67% - 1.87% |  |  |  | 1,743 |  |  |  | 0.36% - 1.87% |  |
| Fixed-rate 0.35% - 4.375% notes |  |  | 2017 - 2045 |  |  |  | 25,063 |  |  |  | 0.28% - 4.51% |  |  |  | 24,958 |  |  |  | 0.28% - 4.51% |  |
| Second quarter 2016 debt issuance of $15.5 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2019 |  |  |  | 500 |  |  |  | 1.44% |  |  |  | 0 |  |  |  | 0 |  |
| Floating-rate notes |  |  | 2021 |  |  |  | 500 |  |  |  | 1.75% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 1.30% notes |  |  | 2018 |  |  |  | 500 |  |  |  | 1.32% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 1.70% notes |  |  | 2019 |  |  |  | 1,000 |  |  |  | 1.71% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.25% notes |  |  | 2021 |  |  |  | 3,000 |  |  |  | 1.80% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.85% notes |  |  | 2023 |  |  |  | 1,500 |  |  |  | 2.48% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 3.25% notes |  |  | 2026 |  |  |  | 3,250 |  |  |  | 2.33% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 4.50% notes |  |  | 2036 |  |  |  | 1,250 |  |  |  | 4.54% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 4.65% notes |  |  | 2046 |  |  |  | 4,000 |  |  |  | 4.58% |  |  |  | 0 |  |  |  | 0 |  |
| Total debt issuance |  |  |  |  |  |  | 15,500 |  |  |  |  |  |  |  | 0 |  |  |  |  |  |
| Total term debt |  |  |  |  |  |  | 71,344 |  |  |  |  |  |  |  | 55,701 |  |  |  |  |  |
| Unamortized premium/(discount) |  |  |  |  |  |  | 15 |  |  |  |  |  |  |  | (114 | ) |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  |  |  | 515 |  |  |  |  |  |  |  | 376 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | (2,500 | ) |  |  |  |  |  |  | (2,500 | ) |  |  |  |  |
| Total long-term debt |  |  |  |  |  | $ | 69,374 |  |  |  |  |  |  | $ | 53,463 |  |  |  |  |  |

- removed (2016-07-27):
[0001193125-16-559625:note_history:28]
As of March 26, 2016, ¥149.3 billion of
 Japanese yen-denominated notes was designated as a hedge of the
 foreign currency exposure of its net investment in a foreign
 operation. The foreign currency transaction gain or loss on the
 Japanese yen-denominated debt designated as a hedge is recorded in
 OCI as a part of the cumulative translation adjustment. As of
 March 26, 2016 and September 26, 2015, the carrying value
 of the debt designated as a net investment hedge was $1.3 billion
 and $2.1 billion, respectively. For further discussion regarding
 the Company’s use of derivative instruments see the
 Derivative Financial Instruments section of Note 2,
 “Financial Instruments.”


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-07-27):
[0001628280-16-017809:note_history:29]
The following table provides a summary of the Company’s term debt as of June 25, 2016 and September 26, 2015:
  (was, 2016-04-27, similarity 0.9548):
[0001193125-16-559625:note_history:29]
The following table provides a summary of the
 Company’s term debt as of March 26, 2016 and
 September 26, 2015:

- added (2016-07-27):
[0001628280-16-017809:note_history:30]
|  | Maturities |  | June 25, 2016 |  | September 26, 2015 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2018 |  | $ | 2,000 |  |  | 1.10% |  |  | $ | 3,000 |  |  | 0.51% - 1.10% |  |
| Fixed-rate 1.00% - 3.85% notes | 2018 - 2043 |  | 12,500 |  |  | 1.08% - 3.91% |  |  | 14,000 |  |  | 0.51% - 3.91% |  |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2017 - 2019 |  | 2,000 |  |  | 0.70% - 0.93% |  |  | 2,000 |  |  | 0.37% - 0.60% |  |
| Fixed-rate 1.05% - 4.45% notes | 2017 - 2044 |  | 10,000 |  |  | 0.70% - 4.48% |  |  | 10,000 |  |  | 0.37% - 4.48% |  |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2017 - 2020 |  | 1,774 |  |  | 0.68% - 1.87% |  |  | 1,743 |  |  | 0.36% - 1.87% |  |
| Fixed-rate 0.35% - 4.375% notes | 2017 - 2045 |  | 25,347 |  |  | 0.28% - 4.51% |  |  | 24,958 |  |  | 0.28% - 4.51% |  |
| Second quarter 2016 debt issuance of $15.5 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 |  | 500 |  |  | 1.47 | % |  | — |  |  | — |  |
| Floating-rate notes | 2021 |  | 500 |  |  | 1.78 | % |  | — |  |  | — |  |
| Fixed-rate 1.30% notes | 2018 |  | 500 |  |  | 1.32 | % |  | — |  |  | — |  |
| Fixed-rate 1.70% notes | 2019 |  | 1,000 |  |  | 1.71 | % |  | — |  |  | — |  |
| Fixed-rate 2.25% notes | 2021 |  | 3,000 |  |  | 1.80 | % |  | — |  |  | — |  |
| Fixed-rate 2.85% notes | 2023 |  | 1,500 |  |  | 2.50 | % |  | — |  |  | — |  |
| Fixed-rate 3.25% notes | 2026 |  | 3,250 |  |  | 2.40 | % |  | — |  |  | — |  |
| Fixed-rate 4.50% notes | 2036 |  | 1,250 |  |  | 4.54 | % |  | — |  |  | — |  |
| Fixed-rate 4.65% notes | 2046 |  | 4,000 |  |  | 4.58 | % |  | — |  |  | — |  |
| Third quarter 2016 Australian dollar-denominated debt issuance of A$1.4 billion: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 2.65% notes | 2020 |  | 487 |  |  | 1.92 | % |  | — |  |  | — |  |
| Fixed-rate 3.35% notes | 2024 |  | 337 |  |  | 2.61 | % |  | — |  |  | — |  |
| Fixed-rate 3.60% notes | 2026 |  | 243 |  |  | 2.84 | % |  | — |  |  | — |  |
| Third quarter 2016 debt issuance of $1.4 billion: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 4.15% notes | 2046 |  | 1,377 |  |  | 4.15 | % |  | — |  |  | — |  |
| Total term debt |  |  | 71,565 |  |  |  |  | 55,701 |  |  |  |
| Unamortized premium/(discount) |  |  | 14 |  |  |  |  | (114 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 860 |  |  |  |  | 376 |  |  |  |
| Less: Current portion of long-term debt |  |  | (3,500 | ) |  |  |  | (2,500 | ) |  |  |
| Total long-term debt |  |  | $ | 68,939 |  |  |  |  | $ | 53,463 |  |  |  |

- removed (2016-07-27):
[0001193125-16-559625:note_history:31]
|  |  |  |  |  | March, 26, 2016 |  |  | September 26, 2015 |  |
|  |  | Maturities |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2016 - 2018 |  |  | $ | 3,000 |  |  |  | 0.51% - 1.10% |  |  | $ | 3,000 |  |  |  | 0.51% - 1.10% |  |
| Fixed-rate 0.45% - 3.85% notes |  |  | 2016 - 2043 |  |  |  | 14,000 |  |  |  | 0.51% - 3.91% |  |  |  | 14,000 |  |  |  | 0.51% - 3.91% |  |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2017 - 2019 |  |  |  | 2,000 |  |  |  | 0.69% - 0.92% |  |  |  | 2,000 |  |  |  | 0.37% - 0.60% |  |
| Fixed-rate 1.05% - 4.45% notes |  |  | 2017 - 2044 |  |  |  | 10,000 |  |  |  | 0.69% - 4.48% |  |  |  | 10,000 |  |  |  | 0.37% - 4.48% |  |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2017 - 2020 |  |  |  | 1,781 |  |  |  | 0.67% - 1.87% |  |  |  | 1,743 |  |  |  | 0.36% - 1.87% |  |
| Fixed-rate 0.35% - 4.375% notes |  |  | 2017 - 2045 |  |  |  | 25,063 |  |  |  | 0.28% - 4.51% |  |  |  | 24,958 |  |  |  | 0.28% - 4.51% |  |
| Second quarter 2016 debt issuance of $15.5 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2019 |  |  |  | 500 |  |  |  | 1.44% |  |  |  | 0 |  |  |  | 0 |  |
| Floating-rate notes |  |  | 2021 |  |  |  | 500 |  |  |  | 1.75% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 1.30% notes |  |  | 2018 |  |  |  | 500 |  |  |  | 1.32% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 1.70% notes |  |  | 2019 |  |  |  | 1,000 |  |  |  | 1.71% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.25% notes |  |  | 2021 |  |  |  | 3,000 |  |  |  | 1.80% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.85% notes |  |  | 2023 |  |  |  | 1,500 |  |  |  | 2.48% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 3.25% notes |  |  | 2026 |  |  |  | 3,250 |  |  |  | 2.33% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 4.50% notes |  |  | 2036 |  |  |  | 1,250 |  |  |  | 4.54% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 4.65% notes |  |  | 2046 |  |  |  | 4,000 |  |  |  | 4.58% |  |  |  | 0 |  |  |  | 0 |  |
| Total debt issuance |  |  |  |  |  |  | 15,500 |  |  |  |  |  |  |  | 0 |  |  |  |  |  |
| Total term debt |  |  |  |  |  |  | 71,344 |  |  |  |  |  |  |  | 55,701 |  |  |  |  |  |
| Unamortized premium/(discount) |  |  |  |  |  |  | 15 |  |  |  |  |  |  |  | (114 | ) |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  |  |  | 515 |  |  |  |  |  |  |  | 376 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | (2,500 | ) |  |  |  |  |  |  | (2,500 | ) |  |  |  |  |
| Total long-term debt |  |  |  |  |  | $ | 69,374 |  |  |  |  |  |  | $ | 53,463 |  |  |  |  |  |
