# AAPL notes — 0001628280-16-017809


## aapl:CommercialPaperCashFlowSummaryTableTextBlock

[0001628280-16-017809:notes:1]
The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the nine months ended June 25, 2016 and June 27, 2015 (in millions):

[0001628280-16-017809:notes:2]
|  | Nine Months Ended |
|  | June 25, 2016 |  | June 27, 2015 |
| Maturities less than 90 days: |  |  |  |
| Proceeds from (repayments of) commercial paper, net | $ | 4,154 |  |  | $ | 579 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 1,846 |  |  | 2,601 |  |
| Repayments of commercial paper | (2,008 | ) |  | (4,988 | ) |
| Proceeds from (repayments of) commercial paper, net | (162 | ) |  | (2,387 | ) |
| Total change in commercial paper, net | $ | 3,992 |  |  | $ | (1,808 | ) |


## aapl:NotionalAndCreditRiskAmountsOfOutstandingDerivativePositionsDisclosureTextBlock

[0001628280-16-017809:notes:3]
The following table shows the notional amounts of the Company’s outstanding derivative instruments and credit risk amounts associated with outstanding or unsettled derivative instruments as of June 25, 2016 and September 26, 2015 (in millions):

[0001628280-16-017809:notes:4]
|  | June 25, 2016 |  | September 26, 2015 |
|  | NotionalAmount |  | Credit RiskAmount |  | NotionalAmount |  | Credit RiskAmount |
| Instruments designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 37,843 |  |  | $ | 391 |  |  | $ | 70,054 |  |  | $ | 1,385 |  |
| Interest rate contracts | $ | 23,050 |  |  | $ | 860 |  |  | $ | 18,750 |  |  | $ | 394 |  |
| Instruments not designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 38,764 |  |  | $ | 115 |  |  | $ | 49,190 |  |  | $ | 109 |  |


## aapl:ScheduleOfCommonStockRepurchasedTableTextBlock

[0001628280-16-017809:notes:5]
Additionally, the Company repurchased shares of its common stock in the open market, which were retired upon repurchase, during the periods presented as follows:

[0001628280-16-017809:notes:6]
|  | Number of Shares(in thousands) |  | Average Repurchase Price Per Share |  | Amount(in millions) |
| 2016: |  |  |  |  |  |
| Third quarter | 41,238 |  |  | $ | 97.00 |  |  | $ | 4,000 |  |
| Second quarter | 71,766 |  |  | $ | 97.54 |  |  | 7,000 |  |
| First quarter | 25,984 |  |  | $ | 115.45 |  |  | 3,000 |  |
| Total open market common stock repurchases | 138,988 |  |  |  |  | $ | 14,000 |  |
| 2015: |  |  |  |  |  |
| Fourth quarter | 121,802 |  |  | $ | 115.15 |  |  | $ | 14,026 |  |
| Third quarter | 31,231 |  |  | $ | 128.08 |  |  | 4,000 |  |
| Second quarter | 56,400 |  |  | $ | 124.11 |  |  | 7,000 |  |
| First quarter | 45,704 |  |  | $ | 109.40 |  |  | 5,000 |  |
| Total open market common stock repurchases | 255,137 |  |  |  |  | $ | 30,026 |  |


## us-gaap:AcceleratedShareRepurchasesTextBlock

[0001628280-16-017809:notes:7]
The following table shows the Company’s ASR activity and related information during the nine months ended June 25, 2016 and the year ended September 26, 2015:

[0001628280-16-017809:notes:8]
|  | Purchase PeriodEnd Date |  | Number of Shares(in thousands) |  | Average RepurchasePrice Per Share |  | ASR Amount(in millions) |
| May 2016 ASR | August 2016 |  | 48,183 |  | (1) | (1) |  |  | $ | 6,000 |  |
| November 2015 ASR | April 2016 |  | 29,122 |  | (2) | $ | 103.02 |  |  | $ | 3,000 |  |
| May 2015 ASR | July 2015 |  | 48,293 |  |  | $ | 124.24 |  |  | $ | 6,000 |  |
| August 2014 ASR | February 2015 |  | 81,525 |  |  | $ | 110.40 |  |  | $ | 9,000 |  |
| January 2014 ASR | December 2014 |  | 134,247 |  |  | $ | 89.39 |  |  | $ | 12,000 |  |

[0001628280-16-017809:notes:9]
| (1) | “Number of Shares” represents those shares delivered in the beginning of the purchase period and does not represent the final number of shares to be delivered under the ASR. The total number of shares ultimately delivered, and therefore the average repurchase price paid per share, will be determined at the end of the applicable purchase period based on the volume-weighted average price of the Company’s common stock during that period. The May 2016 ASR purchase period will end in or before August 2016. |

[0001628280-16-017809:notes:10]
| (2) | Includes 20.4 million shares delivered and retired at the beginning of the purchase period, which began in the first quarter of 2016 and 8.7 million shares delivered and retired at the end of the purchase period, which concluded in the third quarter of 2016. |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001628280-16-017809:notes:11]
Condensed Consolidated Financial Statement Details

[0001628280-16-017809:notes:12]
The following tables show the Company’s condensed consolidated financial statement details as of June 25, 2016 and September 26, 2015 (in millions):

[0001628280-16-017809:notes:13]
Property, Plant and Equipment, Net

[0001628280-16-017809:notes:14]
|  | June 25, 2016 |  | September 26, 2015 |
| Land and buildings | $ | 9,108 |  |  | $ | 6,956 |  |
| Machinery, equipment and internal-use software | 42,550 |  |  | 37,038 |  |
| Leasehold improvements | 6,333 |  |  | 5,263 |  |
| Gross property, plant and equipment | 57,991 |  |  | 49,257 |  |
| Accumulated depreciation and amortization | (32,543 | ) |  | (26,786 | ) |
| Total property, plant and equipment, net | $ | 25,448 |  |  | $ | 22,471 |  |

[0001628280-16-017809:notes:15]
Other Non-Current Liabilities

[0001628280-16-017809:notes:16]
|  | June 25, 2016 |  | September 26, 2015 |
| Deferred tax liabilities | $ | 24,560 |  |  | $ | 24,062 |  |
| Other non-current liabilities | 11,012 |  |  | 9,365 |  |
| Total other non-current liabilities | $ | 35,572 |  |  | $ | 33,427 |  |

[0001628280-16-017809:notes:17]
Other Income/(Expense), Net

[0001628280-16-017809:notes:18]
The following table shows the detail of other income/(expense), net for the three- and nine-month periods ended June 25, 2016 and June 27, 2015 (in millions):

[0001628280-16-017809:notes:19]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25, 2016 |  | June 27, 2015 |  | June 25, 2016 |  | June 27, 2015 |
| Interest and dividend income | $ | 1,036 |  |  | $ | 766 |  |  | $ | 2,963 |  |  | $ | 2,095 |  |
| Interest expense | (409 | ) |  | (201 | ) |  | (1,006 | ) |  | (495 | ) |
| Other expense, net | (263 | ) |  | (175 | ) |  | (1,036 | ) |  | (754 | ) |
| Total other income/(expense), net | $ | 364 |  |  | $ | 390 |  |  | $ | 921 |  |  | $ | 846 |  |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001628280-16-017809:notes:20]
The following tables show the Company’s cash and available-for-sale securities’ adjusted cost, gross unrealized gains, gross unrealized losses and fair value by significant investment category recorded as cash and cash equivalents or short- or long-term marketable securities as of June 25, 2016 and September 26, 2015 (in millions):

[0001628280-16-017809:notes:21]
|  | June 25, 2016 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | Short-TermMarketableSecurities |  | Long-TermMarketableSecurities |
| Cash | $ | 9,118 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,118 |  |  | $ | 9,118 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 3,318 |  |  | — |  |  | — |  |  | 3,318 |  |  | 3,318 |  |  | — |  |  | — |  |
| Mutual funds | 1,772 |  |  | — |  |  | (185 | ) |  | 1,587 |  |  | — |  |  | 1,587 |  |  | — |  |
| Subtotal | 5,090 |  |  | — |  |  | (185 | ) |  | 4,905 |  |  | 3,318 |  |  | 1,587 |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 45,583 |  |  | 416 |  |  | (1 | ) |  | 45,998 |  |  | 833 |  |  | 17,209 |  |  | 27,956 |  |
| U.S. agency securities | 7,490 |  |  | 21 |  |  | — |  |  | 7,511 |  |  | 1,832 |  |  | 2,539 |  |  | 3,140 |  |
| Non-U.S. government securities | 7,101 |  |  | 139 |  |  | (63 | ) |  | 7,177 |  |  | 50 |  |  | 685 |  |  | 6,442 |  |
| Certificates of deposit and time deposits | 3,729 |  |  | — |  |  | — |  |  | 3,729 |  |  | 314 |  |  | 1,493 |  |  | 1,922 |  |
| Commercial paper | 4,708 |  |  | — |  |  | — |  |  | 4,708 |  |  | 2,772 |  |  | 1,936 |  |  | — |  |
| Corporate securities | 128,146 |  |  | 1,185 |  |  | (433 | ) |  | 128,898 |  |  | — |  |  | 17,883 |  |  | 111,015 |  |
| Municipal securities | 952 |  |  | 9 |  |  | — |  |  | 961 |  |  | — |  |  | 127 |  |  | 834 |  |
| Mortgage- and asset-backed securities | 18,333 |  |  | 207 |  |  | (25 | ) |  | 18,515 |  |  | — |  |  | 60 |  |  | 18,455 |  |
| Subtotal | 216,042 |  |  | 1,977 |  |  | (522 | ) |  | 217,497 |  |  | 5,801 |  |  | 41,932 |  |  | 169,764 |  |
| Total | $ | 230,250 |  |  | $ | 1,977 |  |  | $ | (707 | ) |  | $ | 231,520 |  |  | $ | 18,237 |  |  | $ | 43,519 |  |  | $ | 169,764 |  |

[0001628280-16-017809:notes:22]
|  | September 26, 2015 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | Short-TermMarketableSecurities |  | Long-TermMarketableSecurities |
| Cash | $ | 11,389 |  |  | $ | — |  |  | $ | — |  |  | $ | 11,389 |  |  | $ | 11,389 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 1,798 |  |  | — |  |  | — |  |  | 1,798 |  |  | 1,798 |  |  | — |  |  | — |  |
| Mutual funds | 1,772 |  |  | — |  |  | (144 | ) |  | 1,628 |  |  | — |  |  | 1,628 |  |  | — |  |
| Subtotal | 3,570 |  |  | — |  |  | (144 | ) |  | 3,426 |  |  | 1,798 |  |  | 1,628 |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 34,902 |  |  | 181 |  |  | (1 | ) |  | 35,082 |  |  | — |  |  | 3,498 |  |  | 31,584 |  |
| U.S. agency securities | 5,864 |  |  | 14 |  |  | — |  |  | 5,878 |  |  | 841 |  |  | 767 |  |  | 4,270 |  |
| Non-U.S. government securities | 6,356 |  |  | 45 |  |  | (167 | ) |  | 6,234 |  |  | 43 |  |  | 135 |  |  | 6,056 |  |
| Certificates of deposit and time deposits | 4,347 |  |  | — |  |  | — |  |  | 4,347 |  |  | 2,065 |  |  | 1,405 |  |  | 877 |  |
| Commercial paper | 6,016 |  |  | — |  |  | — |  |  | 6,016 |  |  | 4,981 |  |  | 1,035 |  |  | — |  |
| Corporate securities | 116,908 |  |  | 242 |  |  | (985 | ) |  | 116,165 |  |  | 3 |  |  | 11,948 |  |  | 104,214 |  |
| Municipal securities | 947 |  |  | 5 |  |  | — |  |  | 952 |  |  | — |  |  | 48 |  |  | 904 |  |
| Mortgage- and asset-backed securities | 16,121 |  |  | 87 |  |  | (31 | ) |  | 16,177 |  |  | — |  |  | 17 |  |  | 16,160 |  |
| Subtotal | 191,461 |  |  | 574 |  |  | (1,184 | ) |  | 190,851 |  |  | 7,933 |  |  | 18,853 |  |  | 164,065 |  |
| Total | $ | 206,420 |  |  | $ | 574 |  |  | $ | (1,328 | ) |  | $ | 205,666 |  |  | $ | 21,120 |  |  | $ | 20,481 |  |  | $ | 164,065 |  |

[0001628280-16-017809:notes:23]
| (1) | The fair value of Level 1 securities is estimated based on quoted prices in active markets for identical assets or liabilities. |

[0001628280-16-017809:notes:24]
| (2) | The fair value of Level 2 securities is estimated based on observable inputs other than quoted prices in active markets for identical assets and liabilities, quoted prices for identical or similar assets or liabilities in inactive markets, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities. |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001628280-16-017809:notes:25]
[same as prior period, unchanged from 0001193125-16-559625:notes:41]

[0001628280-16-017809:notes:26]
The accompanying condensed consolidated financial statements include the accounts of the Company. Intercompany accounts and transactions have been eliminated. In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements in conformity with U.S. generally accepted accounting principles (“GAAP”) requires management to make estimates and assumptions that affect the amounts reported in these condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. Certain prior period amounts in the condensed consolidated financial statements have been reclassified to conform to the current period’s presentation.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001628280-16-017809:notes:27]
Summary of Significant Accounting Policies

[0001628280-16-017809:notes:28]
Apple Inc. and its wholly-owned subsidiaries (collectively “Apple” or the “Company”) designs, manufactures and markets mobile communication and media devices, personal computers and portable digital music players, and sells a variety of related software, services, accessories, networking solutions and third-party digital content and applications. The Company sells its products worldwide through its retail stores, online stores and direct sales force, as well as through third-party cellular network carriers, wholesalers, retailers and value-added resellers. In addition, the Company sells a variety of third-party Apple-compatible products, including application software and various accessories through its online and retail stores. The Company sells to consumers, small and mid-sized businesses and education, enterprise and government customers.

[0001628280-16-017809:notes:29]
These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company's annual consolidated financial statements and the notes thereto included in its Annual Report on Form 10-K for the fiscal year ended September 26, 2015 (the “2015 Form 10-K”). The Company’s fiscal year is the 52 or 53-week period that ends on the last Saturday of September. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal quarters with calendar quarters, which will next occur in the first quarter of fiscal year 2017. The Company’s fiscal years 2016 and 2015 each include 52 weeks. Unless otherwise stated, references to particular years, quarters or months refer to the Company’s fiscal years ended in September and the associated quarters or months of those fiscal years.

[0001628280-16-017809:notes:30]
During the first quarter of 2016, the Company adopted an accounting standard that simplified the presentation of deferred taxes by requiring deferred tax assets and liabilities be classified as noncurrent in a classified statement of financial position. The Company has adopted this accounting standard prospectively; accordingly, the prior period amounts in the Company’s Condensed Consolidated Balance Sheets within this Quarterly Report on Form 10-Q were not adjusted to conform to the new accounting standard. The adoption of this accounting standard was not material to the Company’s condensed consolidated financial statements.

[0001628280-16-017809:notes:31]
Earnings Per Share

[0001628280-16-017809:notes:32]
Basic earnings per share is computed by dividing income available to common shareholders by the weighted-average number of shares of common stock outstanding during the period. Diluted earnings per share is computed by dividing income available to common shareholders by the weighted-average number of shares of common stock outstanding during the period increased to include the number of additional shares of common stock that would have been outstanding if the potentially dilutive securities had been issued. Potentially dilutive securities include outstanding stock options, shares to be purchased under the Company’s employee stock purchase plan, unvested restricted stock and unvested restricted stock units (“RSUs”). The dilutive effect of potentially dilutive securities is reflected in diluted earnings per share by application of the treasury stock method. Under the treasury stock method, an increase in the fair market value of the Company’s common stock can result in a greater dilutive effect from potentially dilutive securities.

[0001628280-16-017809:notes:33]
The following table shows the computation of basic and diluted earnings per share for the three- and nine-month periods ended June 25, 2016 and June 27, 2015 (net income in millions and shares in thousands):

[0001628280-16-017809:notes:34]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25, 2016 |  | June 27, 2015 |  | June 25, 2016 |  | June 27, 2015 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 7,796 |  |  | $ | 10,677 |  |  | $ | 36,673 |  |  | $ | 42,270 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average shares outstanding | 5,443,058 |  |  | 5,729,886 |  |  | 5,505,456 |  |  | 5,788,922 |  |
| Effect of dilutive securities | 29,723 |  |  | 43,213 |  |  | 30,475 |  |  | 40,998 |  |
| Weighted-average diluted shares | 5,472,781 |  |  | 5,773,099 |  |  | 5,535,931 |  |  | 5,829,920 |  |
| Basic earnings per share | $ | 1.43 |  |  | $ | 1.86 |  |  | $ | 6.66 |  |  | $ | 7.30 |  |
| Diluted earnings per share | $ | 1.42 |  |  | $ | 1.85 |  |  | $ | 6.62 |  |  | $ | 7.25 |  |

[0001628280-16-017809:notes:35]
Potentially dilutive securities whose effect would have been antidilutive are excluded from the computation of diluted earnings per share.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-16-017809:notes:36]
Commitments and Contingencies

[0001628280-16-017809:notes:37]
Accrued Warranty and Indemnification

[0001628280-16-017809:notes:38]
The following table shows changes in the Company’s accrued warranties and related costs for the three- and nine-month periods ended June 25, 2016 and June 27, 2015 (in millions):

[0001628280-16-017809:notes:39]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25, 2016 |  | June 27, 2015 |  | June 25, 2016 |  | June 27, 2015 |
| Beginning accrued warranty and related costs | $ | 4,985 |  |  | $ | 5,143 |  |  | $ | 4,780 |  |  | $ | 4,159 |  |
| Cost of warranty claims | (1,110 | ) |  | (1,077 | ) |  | (3,507 | ) |  | (3,151 | ) |
| Accruals for product warranty | 380 |  |  | 1,071 |  |  | 2,982 |  |  | 4,129 |  |
| Ending accrued warranty and related costs | $ | 4,255 |  |  | $ | 5,137 |  |  | $ | 4,255 |  |  | $ | 5,137 |  |

[0001628280-16-017809:notes:40]
The Company generally does not indemnify end-users of its operating system and application software against legal claims that the software infringes third-party intellectual property rights. Other agreements entered into by the Company sometimes include indemnification provisions under which the Company could be subject to costs and/or damages in the event of an infringement claim against the Company or an indemnified third-party. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss with respect to indemnification of end-users of its operating system or application software for infringement of third-party intellectual property rights.

[0001628280-16-017809:notes:41]
The Company offers an iPhone Upgrade Program, which is available to customers who purchase an iPhone 6s and 6s Plus in its U.S. retail and online stores and activate the purchased iPhone with one of the four U.S. national carriers. The iPhone Upgrade Program provides customers the right to trade in that iPhone for a new iPhone, provided certain conditions are met. One of the conditions of this program requires the customer to finance the initial purchase price of the iPhone with a third-party lender. Upon exercise of the trade-in right and purchase of a new iPhone, the Company satisfies the customer’s outstanding balance due to the third-party lender on the original device. The Company accounts for the trade-in right as a guarantee liability and recognizes arrangement revenue net of the fair value of such right with subsequent changes to the guarantee liability recognized within revenue.

[0001628280-16-017809:notes:42]
The Company has entered into indemnification agreements with its directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, the Company maintains directors and officers liability insurance coverage to reduce its exposure to such obligations.

[0001628280-16-017809:notes:43]
Concentrations in the Available Sources of Supply of Materials and Product

[0001628280-16-017809:notes:44]
Although most components essential to the Company’s business are generally available from multiple sources, a number of components are currently obtained from single or limited sources. In addition, the Company competes for various components with other participants in the markets for mobile communication and media devices and personal computers. Therefore, many components used by the Company, including those that are available from multiple sources, are at times subject to industry-wide shortage and significant pricing fluctuations that could materially adversely affect the Company’s financial condition and operating results.

[0001628280-16-017809:notes:45]
The Company uses some custom components that are not commonly used by its competitors, and new products introduced by the Company often utilize custom components available from only one source. When a component or product uses new technologies, initial capacity constraints may exist until the suppliers’ yields have matured or manufacturing capacity has increased. If the Company’s supply of components for a new or existing product were delayed or constrained, or if an outsourcing partner delayed shipments of completed products to the Company, the Company’s financial condition and operating results could be materially adversely affected. The Company’s business and financial performance could also be materially adversely affected depending on the time required to obtain sufficient quantities from the original source, or to identify and obtain sufficient quantities from an alternative source. Continued availability of these components at acceptable prices, or at all, may be affected if those suppliers concentrated on the production of common components instead of components customized to meet the Company’s requirements.

[0001628280-16-017809:notes:46]
The Company has entered into agreements for the supply of many components; however, there can be no guarantee that the Company will be able to extend or renew these agreements on similar terms, or at all. Therefore, the Company remains subject to significant risks of supply shortages and price increases that could materially adversely affect its financial condition and operating results.

[0001628280-16-017809:notes:47]
Substantially all of the Company’s hardware products are manufactured by outsourcing partners that are located primarily in Asia. A significant concentration of this manufacturing is currently performed by a small number of outsourcing partners, often in single locations. Certain of these outsourcing partners are the sole-sourced suppliers of components and manufacturers for many of the Company’s products. Although the Company works closely with its outsourcing partners on manufacturing schedules, the Company’s operating results could be adversely affected if its outsourcing partners were unable to meet their production commitments. The Company’s purchase commitments typically cover its requirements for periods up to 150 days.

[0001628280-16-017809:notes:48]
Other Off-Balance Sheet Commitments

[0001628280-16-017809:notes:49]
Operating Leases

[0001628280-16-017809:notes:50]
The Company leases various equipment and facilities, including retail space, under noncancelable operating lease arrangements. As of June 25, 2016, the Company’s total future minimum lease payments under noncancelable operating leases were $7.1 billion. The Company's retail store and other facility leases are typically for terms not exceeding 10 years and generally contain multi-year renewal options.

[0001628280-16-017809:notes:51]
Contingencies

[0001628280-16-017809:notes:52]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully adjudicated, as further discussed in Part II, Item 1 of this Form 10-Q under the heading “Legal Proceedings” and in Part II, Item 1A of this Form 10-Q under the heading “Risk Factors.” In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to loss contingencies for asserted legal and other claims. However, the outcome of litigation is inherently uncertain. Therefore, although management considers the likelihood of such an outcome to be remote, if one or more of these legal matters were resolved against the Company in a reporting period for amounts in excess of management’s expectations, the Company’s consolidated financial statements for that reporting period could be materially adversely affected.

[0001628280-16-017809:notes:53]
Apple Inc. v. Samsung Electronics Co., Ltd., et al.

[0001628280-16-017809:notes:54]
On August 24, 2012, a jury returned a verdict awarding the Company $1.05 billion in its lawsuit against Samsung Electronics Co., Ltd. and affiliated parties in the United States District Court, Northern District of California, San Jose Division. On March 6, 2014, the District Court entered final judgment in favor of the Company in the amount of approximately $930 million. On May 18, 2015, the U.S. Court of Appeals for the Federal Circuit affirmed in part, and reversed in part, the decision of the District Court. As a result, the Court of Appeals ordered entry of final judgment on damages in the amount of approximately $548 million, with the District Court to determine supplemental damages and interest, as well as damages owed for products subject to the reversal in part. Samsung paid $548 million to the Company in December 2015, which was included in net sales in the Condensed Consolidated Statement of Operations. Because the case remains subject to further proceedings, the Company has not recognized any further amounts in its results of operations. On March 21, 2016, the United States Supreme Court agreed to hear Samsung’s request for appeal related to the $548 million in damages.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001628280-16-017809:notes:55]
Benefit Plans

[0001628280-16-017809:notes:56]
[same as prior period, unchanged from 0001193125-16-559625:notes:95]

[0001628280-16-017809:notes:57]
The Company had 386.3 million shares reserved for future issuance under its stock plans as of June 25, 2016. RSUs granted generally vest over four years, based on continued employment, and are settled upon vesting in shares of the Company’s common stock on a one-for-one basis. Each share issued with respect to RSUs granted under the Company’s stock plans reduces the number of shares available for grant under the plan by two shares. RSUs cancelled and shares withheld to satisfy tax withholding obligations increase the number of shares available for grant under the plans utilizing a factor of two times the number of RSUs cancelled or shares withheld. Stock options count against the number of shares available for grant on a one-for-one basis.

[0001628280-16-017809:notes:58]
[same as prior period, unchanged from 0001193125-16-559625:notes:97]

[0001628280-16-017809:notes:59]
During the three months ended June 25, 2016, Section 16 officers Timothy D. Cook, Angela Ahrendts, Luca Maestri, Daniel Riccio, Philip Schiller and Jeffrey Williams had equity trading plans in place in accordance with Rule 10b5-1(c)(1) under the Exchange Act. An equity trading plan is a written document that pre-establishes the amounts, prices and dates (or formula for determining the amounts, prices and dates) of future purchases or sales of the Company’s stock, including shares acquired pursuant to the Company’s employee and director equity plans.

[0001628280-16-017809:notes:60]
[same as prior period, unchanged from 0001193125-16-559625:notes:99]

[0001628280-16-017809:notes:61]
A summary of the Company’s RSU activity and related information for the nine months ended June 25, 2016 is as follows:

[0001628280-16-017809:notes:62]
|  | Number of RSUs(in thousands) |  | Weighted-Average Grant Date Fair Value Per Share |  | Aggregate Intrinsic Value(in millions) |
| Balance at September 26, 2015 | 101,467 |  |  | $ | 85.77 |  |  |  |
| RSUs granted | 47,100 |  |  | $ | 109.67 |  |  |  |
| RSUs vested | (41,326 | ) |  | $ | 84.86 |  |  |  |
| RSUs cancelled | (4,250 | ) |  | $ | 95.44 |  |  |  |
| Balance at June 25, 2016 | 102,991 |  |  | $ | 96.57 |  |  | $ | 9,619 |  |

[0001628280-16-017809:notes:63]
RSUs that vested during the three- and nine-month periods ended June 25, 2016 had fair values of $2.0 billion and $4.5 billion, respectively, as of the vesting date. RSUs that vested during the three- and nine-month periods ended June 27, 2015 had fair values of $2.3 billion and $4.3 billion, respectively, as of the vesting date.

[0001628280-16-017809:notes:64]
[same as prior period, unchanged from 0001193125-16-559625:notes:103]

[0001628280-16-017809:notes:65]
The Company had 1.1 million stock options outstanding as of June 25, 2016, with a weighted-average exercise price per share of $15.69 and weighted-average remaining contractual term of 3.4 years, substantially all of which are exercisable. The aggregate intrinsic value of the stock options outstanding as of June 25, 2016 was $84 million, which represents the value of the Company’s closing stock price on the last trading day of the period in excess of the weighted-average exercise price multiplied by the number of options outstanding.

[0001628280-16-017809:notes:66]
[same as prior period, unchanged from 0001193125-16-559625:notes:105]

[0001628280-16-017809:notes:67]
The following table shows a summary of the share-based compensation expense included in the Condensed Consolidated Statements of Operations for the three- and nine-month periods ended June 25, 2016 and June 27, 2015 (in millions):

[0001628280-16-017809:notes:68]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25, 2016 |  | June 27, 2015 |  | June 25, 2016 |  | June 27, 2015 |
| Cost of sales | $ | 188 |  |  | $ | 148 |  |  | $ | 583 |  |  | $ | 430 |  |
| Research and development | 479 |  |  | 388 |  |  | 1,413 |  |  | 1,146 |  |
| Selling, general and administrative | 387 |  |  | 320 |  |  | 1,184 |  |  | 1,095 |  |
| Total share-based compensation expense | $ | 1,054 |  |  | $ | 856 |  |  | $ | 3,180 |  |  | $ | 2,671 |  |

[0001628280-16-017809:notes:69]
The income tax benefit related to share-based compensation expense was $321 million and $1.1 billion for the three- and nine-month periods ended June 25, 2016, respectively, and was $286 million and $948 million for the three- and nine-month periods ended June 27, 2015, respectively. As of June 25, 2016, the total unrecognized compensation cost related to outstanding stock options, RSUs and restricted stock was $8.3 billion, which the Company expects to recognize over a weighted-average period of 2.7 years.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-16-017809:notes:70]
Comprehensive Income

[0001628280-16-017809:notes:71]
Comprehensive income consists of two components, net income and OCI. OCI refers to revenue, expenses, and gains and losses that under GAAP are recorded as an element of shareholders’ equity but are excluded from net income. The Company’s OCI consists of foreign currency translation adjustments from those subsidiaries not using the U.S. dollar as their functional currency, net deferred gains and losses on certain derivative instruments accounted for as cash flow hedges and unrealized gains and losses on marketable securities classified as available-for-sale.

[0001628280-16-017809:notes:72]
The following table shows the pre-tax amounts reclassified from AOCI into the Condensed Consolidated Statements of Operations, and the associated financial statement line item, for the three- and nine-month periods ended June 25, 2016 and June 27, 2015 (in millions):

[0001628280-16-017809:notes:73]
|  |  |  |  | Three Months Ended |  | Nine Months Ended |
| Comprehensive Income Components |  | Financial Statement Line Item |  | June 25, 2016 |  | June 27, 2015 |  | June 25, 2016 |  | June 27, 2015 |
| Unrealized (gains)/losses on derivative instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Revenue |  | $ | (131 | ) |  | $ | (828 | ) |  | $ | (785 | ) |  | $ | (1,835 | ) |
|  |  | Cost of sales |  | 106 |  |  | (529 | ) |  | (419 | ) |  | (1,450 | ) |
|  |  | Other income/(expense), net |  | (112 | ) |  | (116 | ) |  | (123 | ) |  | 327 |  |
| Interest rate contracts |  | Other income/(expense), net |  | 3 |  |  | 5 |  |  | 10 |  |  | 13 |  |
|  |  |  |  | (134 | ) |  | (1,468 | ) |  | (1,317 | ) |  | (2,945 | ) |
| Unrealized (gains)/losses on marketable securities |  | Other income/(expense), net |  | (20 | ) |  | 3 |  |  | 129 |  |  | 37 |  |
| Total amounts reclassified from AOCI |  | $ | (154 | ) |  | $ | (1,465 | ) |  | $ | (1,188 | ) |  | $ | (2,908 | ) |

[0001628280-16-017809:notes:74]
The following table shows the changes in AOCI by component for the nine months ended June 25, 2016 (in millions):

[0001628280-16-017809:notes:75]
|  | Cumulative ForeignCurrency Translation |  | Unrealized Gains/Losseson Derivative Instruments |  | Unrealized Gains/Losseson Marketable Securities |  | Total |
| Balance at September 26, 2015 | $ | (653 | ) |  | $ | 772 |  |  | $ | (464 | ) |  | $ | (345 | ) |
| Other comprehensive income/(loss) before reclassifications | 62 |  |  | (56 | ) |  | 1,880 |  |  | 1,886 |  |
| Amounts reclassified from AOCI | — |  |  | (1,317 | ) |  | 129 |  |  | (1,188 | ) |
| Tax effect | 2 |  |  | 246 |  |  | (708 | ) |  | (460 | ) |
| Other comprehensive income/(loss) | 64 |  |  | (1,127 | ) |  | 1,301 |  |  | 238 |  |
| Balance at June 25, 2016 | $ | (589 | ) |  | $ | (355 | ) |  | $ | 837 |  |  | $ | (107 | ) |


## us-gaap:DebtDisclosureTextBlock

[0001628280-16-017809:notes:76]
Debt

[0001628280-16-017809:notes:77]
Commercial Paper

[0001628280-16-017809:notes:78]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of June 25, 2016 and September 26, 2015, the Company had $12.5 billion and $8.5 billion of Commercial Paper outstanding, respectively, with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 0.42% as of June 25, 2016 and 0.14% as of September 26, 2015.

[0001628280-16-017809:notes:79]
Long-Term Debt

[0001628280-16-017809:notes:80]
As of June 25, 2016, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $71.6 billion (collectively the “Notes”). The Notes are senior unsecured obligations, and interest is payable in arrears, quarterly for the U.S. dollar-denominated and Australian dollar-denominated floating-rate notes, semi-annually for the U.S. dollar-denominated, Australian dollar-denominated, British pound-denominated and Japanese yen-denominated fixed-rate notes and annually for the euro-denominated and Swiss franc-denominated fixed-rate notes. The following table provides a summary of the Company’s term debt as of June 25, 2016 and September 26, 2015:

[0001628280-16-017809:notes:81]
|  | Maturities |  | June 25, 2016 |  | September 26, 2015 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2018 |  | $ | 2,000 |  |  | 1.10% |  |  | $ | 3,000 |  |  | 0.51% - 1.10% |  |
| Fixed-rate 1.00% - 3.85% notes | 2018 - 2043 |  | 12,500 |  |  | 1.08% - 3.91% |  |  | 14,000 |  |  | 0.51% - 3.91% |  |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2017 - 2019 |  | 2,000 |  |  | 0.70% - 0.93% |  |  | 2,000 |  |  | 0.37% - 0.60% |  |
| Fixed-rate 1.05% - 4.45% notes | 2017 - 2044 |  | 10,000 |  |  | 0.70% - 4.48% |  |  | 10,000 |  |  | 0.37% - 4.48% |  |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2017 - 2020 |  | 1,774 |  |  | 0.68% - 1.87% |  |  | 1,743 |  |  | 0.36% - 1.87% |  |
| Fixed-rate 0.35% - 4.375% notes | 2017 - 2045 |  | 25,347 |  |  | 0.28% - 4.51% |  |  | 24,958 |  |  | 0.28% - 4.51% |  |
| Second quarter 2016 debt issuance of $15.5 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 |  | 500 |  |  | 1.47 | % |  | — |  |  | — |  |
| Floating-rate notes | 2021 |  | 500 |  |  | 1.78 | % |  | — |  |  | — |  |
| Fixed-rate 1.30% notes | 2018 |  | 500 |  |  | 1.32 | % |  | — |  |  | — |  |
| Fixed-rate 1.70% notes | 2019 |  | 1,000 |  |  | 1.71 | % |  | — |  |  | — |  |
| Fixed-rate 2.25% notes | 2021 |  | 3,000 |  |  | 1.80 | % |  | — |  |  | — |  |
| Fixed-rate 2.85% notes | 2023 |  | 1,500 |  |  | 2.50 | % |  | — |  |  | — |  |
| Fixed-rate 3.25% notes | 2026 |  | 3,250 |  |  | 2.40 | % |  | — |  |  | — |  |
| Fixed-rate 4.50% notes | 2036 |  | 1,250 |  |  | 4.54 | % |  | — |  |  | — |  |
| Fixed-rate 4.65% notes | 2046 |  | 4,000 |  |  | 4.58 | % |  | — |  |  | — |  |
| Third quarter 2016 Australian dollar-denominated debt issuance of A$1.4 billion: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 2.65% notes | 2020 |  | 487 |  |  | 1.92 | % |  | — |  |  | — |  |
| Fixed-rate 3.35% notes | 2024 |  | 337 |  |  | 2.61 | % |  | — |  |  | — |  |
| Fixed-rate 3.60% notes | 2026 |  | 243 |  |  | 2.84 | % |  | — |  |  | — |  |
| Third quarter 2016 debt issuance of $1.4 billion: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 4.15% notes | 2046 |  | 1,377 |  |  | 4.15 | % |  | — |  |  | — |  |
| Total term debt |  |  | 71,565 |  |  |  |  | 55,701 |  |  |  |
| Unamortized premium/(discount) |  |  | 14 |  |  |  |  | (114 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 860 |  |  |  |  | 376 |  |  |  |
| Less: Current portion of long-term debt |  |  | (3,500 | ) |  |  |  | (2,500 | ) |  |  |
| Total long-term debt |  |  | $ | 68,939 |  |  |  |  | $ | 53,463 |  |  |  |

[0001628280-16-017809:notes:82]
During the third quarter of 2016, the Company issued $1.4 billion U.S. dollar-denominated notes in Taiwan and A$1.4 billion    Australian dollar-denominated notes. To manage foreign currency risk associated with the Australian dollar-denominated notes, the Company entered into currency swaps with an aggregate notional amount of $1.0 billion, which effectively converted these notes to U.S. dollar-denominated notes.

[0001628280-16-017809:notes:83]
During the second quarter of 2016, the Company issued $15.5 billion U.S. dollar-denominated notes. To manage interest rate risk on the fixed-rate notes maturing in 2021, 2023 and 2026, the Company entered into interest rate swaps with an aggregate notional amount of  $5.0 billion, which effectively converted a portion of the fixed interest rates on these notes to a floating interest rate.

[0001628280-16-017809:notes:84]
As of June 25, 2016, ¥191.0 billion of Japanese yen-denominated notes was designated as a hedge of the foreign currency exposure of its net investment in a foreign operation. The foreign currency transaction gain or loss on the Japanese yen-denominated debt designated as a hedge is recorded in OCI as a part of the cumulative translation adjustment.  As of June 25, 2016 and September 26, 2015, the carrying value of the debt designated as a net investment hedge was $1.8 billion and $2.1 billion, respectively. For further discussion regarding the Company’s use of derivative instruments see the Derivative Financial Instruments section of Note 2, “Financial Instruments.”

[0001628280-16-017809:notes:85]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount and, if applicable, adjustments related to hedging. The Company recognized $393 million and $975 million of interest expense on its term debt for the three- and nine-month periods ended June 25, 2016, respectively. The Company recognized $197 million and $486 million of interest expense on its term debt for the three- and nine-month periods ended June 27, 2015, respectively.

[0001628280-16-017809:notes:86]
As of June 25, 2016 and September 26, 2015, the fair value of the Company’s Notes, based on Level 2 inputs, was $74.1 billion and $54.9 billion, respectively.


## us-gaap:DerivativesPolicyTextBlock

[0001628280-16-017809:notes:87]
Derivative Financial Instruments

[0001628280-16-017809:notes:88]
The Company may use derivatives to partially offset its business exposure to foreign currency and interest rate risk on expected future cash flows, on net investments in certain foreign subsidiaries and on certain existing assets and liabilities. However, the Company may choose not to hedge certain exposures for a variety of reasons including, but not limited to, accounting considerations and the prohibitive economic cost of hedging particular exposures. There can be no assurance the hedges will offset more than a portion of the financial impact resulting from movements in foreign currency exchange or interest rates.

[0001628280-16-017809:notes:89]
To help protect gross margins from fluctuations in foreign currency exchange rates, certain of the Company’s subsidiaries whose functional currency is the U.S. dollar may hedge a portion of forecasted foreign currency revenue, and subsidiaries whose functional currency is not the U.S. dollar and who sell in local currencies may hedge a portion of forecasted inventory purchases not denominated in the subsidiaries’ functional currencies. The Company may enter into forward contracts, option contracts or other instruments to manage this risk and may designate these instruments as cash flow hedges. The Company typically hedges portions of its forecasted foreign currency exposure associated with revenue and inventory purchases, typically for up to 12 months.

[0001628280-16-017809:notes:90]
To help protect the net investment in a foreign operation from adverse changes in foreign currency exchange rates, the Company may enter into foreign currency forward and option contracts to offset the changes in the carrying amounts of these investments due to fluctuations in foreign currency exchange rates. In addition, the Company may use non-derivative financial instruments, such as its foreign-currency-denominated debt, as economic hedges of its net investments in certain foreign subsidiaries. In both of these cases, the Company designates these instruments as net investment hedges.

[0001628280-16-017809:notes:91]
The Company may also enter into non-designated foreign currency contracts to partially offset the foreign currency exchange gains and losses generated by the re-measurement of certain assets and liabilities denominated in non-functional currencies.

[0001628280-16-017809:notes:92]
The Company may enter into interest rate swaps, options, or other instruments to manage interest rate risk. These instruments may offset a portion of changes in income or expense, or changes in fair value of the Company’s term debt or investments. The Company designates these instruments as either cash flow or fair value hedges. The Company’s hedged interest rate transactions as of June 25, 2016 are expected to be recognized within ten years.

[0001628280-16-017809:notes:93]
Cash Flow Hedges

[0001628280-16-017809:notes:94]
The effective portions of cash flow hedges are recorded in accumulated other comprehensive income (“AOCI”) until the hedged item is recognized in earnings. Deferred gains and losses associated with cash flow hedges of foreign currency revenue are recognized as a component of net sales in the same period as the related revenue is recognized, and deferred gains and losses related to cash flow hedges of inventory purchases are recognized as a component of cost of sales in the same period as the related costs are recognized. Deferred gains and losses associated with cash flow hedges of interest income or expense are recognized in other income/(expense), net in the same period as the related income or expense is recognized. The ineffective portions and amounts excluded from the effectiveness testing of cash flow hedges are recognized in other income/(expense), net.

[0001628280-16-017809:notes:95]
Derivative instruments designated as cash flow hedges must be de-designated as hedges when it is probable the forecasted hedged transaction will not occur in the initially identified time period or within a subsequent two-month time period. Deferred gains and losses in AOCI associated with such derivative instruments are reclassified immediately into other income/(expense), net. Any subsequent changes in fair value of such derivative instruments are reflected in other income/(expense), net unless they are re-designated as hedges of other transactions.

[0001628280-16-017809:notes:96]
Net Investment Hedges

[0001628280-16-017809:notes:97]
The effective portions of net investment hedges are recorded in other comprehensive income (“OCI”) as a part of the cumulative translation adjustment. The ineffective portions and amounts excluded from the effectiveness testing of net investment hedges are recognized in other income/(expense), net.

[0001628280-16-017809:notes:98]
Fair Value Hedges

[0001628280-16-017809:notes:99]
Gains and losses related to changes in fair value hedges are recognized in earnings along with a corresponding loss or gain related to the change in value of the underlying hedged item.

[0001628280-16-017809:notes:100]
Non-Designated Derivatives

[0001628280-16-017809:notes:101]
Derivatives that are not designated as hedging instruments are adjusted to fair value through earnings in the financial statement line item to which the derivative relates.

[0001628280-16-017809:notes:102]
The Company records all derivatives in the Condensed Consolidated Balance Sheets at fair value. The Company’s accounting treatment for these derivative instruments is based on its hedge designation.


## us-gaap:DividendsDeclaredTableTextBlock

[0001628280-16-017809:notes:103]
The Company declared and paid cash dividends per share during the periods presented as follows:

[0001628280-16-017809:notes:104]
|  | DividendsPer Share |  | Amount(in millions) |
| 2016: |  |  |  |
| Third quarter | $ | 0.57 |  |  | $ | 3,117 |  |
| Second quarter | 0.52 |  |  | 2,879 |  |
| First quarter | 0.52 |  |  | 2,898 |  |
| Total cash dividends declared and paid | $ | 1.61 |  |  | $ | 8,894 |  |
| 2015: |  |  |  |
| Fourth quarter | $ | 0.52 |  |  | $ | 2,950 |  |
| Third quarter | 0.52 |  |  | 2,997 |  |
| Second quarter | 0.47 |  |  | 2,734 |  |
| First quarter | 0.47 |  |  | 2,750 |  |
| Total cash dividends declared and paid | $ | 1.98 |  |  | $ | 11,431 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001628280-16-017809:notes:105]
Financial Instruments

[0001628280-16-017809:notes:106]
[same as prior period, unchanged from 0001193125-16-559625:notes:49]

[0001628280-16-017809:notes:107]
The Company may sell certain of its marketable securities prior to their stated maturities for strategic reasons including, but not limited to, anticipation of credit deterioration and duration management. The maturities of the Company’s long-term marketable securities generally range from one to five years.

[0001628280-16-017809:notes:108]
The Company considers the declines in market value of its marketable securities investment portfolio to be temporary in nature. The Company typically invests in highly-rated securities, and its investment policy generally limits the amount of credit exposure to any one issuer. The policy generally requires investments to be investment grade, with the primary objective of minimizing the potential risk of principal loss. Fair values were determined for each individual security in the investment portfolio. When evaluating an investment for other-than-temporary impairment the Company reviews factors such as the length of time and extent to which fair value has been below its cost basis, the financial condition of the issuer and any changes thereto, changes in market interest rates and the Company’s intent to sell, or whether it is more likely than not it will be required to sell the investment before recovery of the investment’s cost basis. As of June 25, 2016, the Company does not consider any of its investments to be other-than-temporarily impaired.

[0001628280-16-017809:notes:109]
The Company records all derivatives in the Condensed Consolidated Balance Sheets at fair value. The Company’s accounting treatment for these derivative instruments is based on its hedge designation. The following tables show the Company’s derivative instruments at gross fair value as of June 25, 2016 and September 26, 2015 (in millions):

[0001628280-16-017809:notes:110]
|  | June 25, 2016 |
|  | Fair Value of Derivatives Designated as Hedge Instruments |  | Fair Value ofDerivatives Not Designatedas Hedge Instruments |  | TotalFair Value |
| Derivative assets (1): |  |  |  |  |  |
| Foreign exchange contracts | $ | 391 |  |  | $ | 115 |  |  | $ | 506 |  |
| Interest rate contracts | $ | 860 |  |  | $ | — |  |  | $ | 860 |  |
| Derivative liabilities (2): |  |  |  |  |  |
| Foreign exchange contracts | $ | 903 |  |  | $ | 281 |  |  | $ | 1,184 |  |
| Interest rate contracts | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |

[0001628280-16-017809:notes:111]
|  | September 26, 2015 |
|  | Fair Value of Derivatives Designated as Hedge Instruments |  | Fair Value of Derivatives Not Designated as Hedge Instruments |  | TotalFair Value |
| Derivative assets (1): |  |  |  |  |  |
| Foreign exchange contracts | $ | 1,442 |  |  | $ | 109 |  |  | $ | 1,551 |  |
| Interest rate contracts | $ | 394 |  |  | $ | — |  |  | $ | 394 |  |
| Derivative liabilities (2): |  |  |  |  |  |
| Foreign exchange contracts | $ | 905 |  |  | $ | 94 |  |  | $ | 999 |  |
| Interest rate contracts | $ | 13 |  |  | $ | — |  |  | $ | 13 |  |

[0001628280-16-017809:notes:112]
| (1) | The fair value of derivative assets is measured using Level 2 fair value inputs and is recorded as other current assets in the Condensed Consolidated Balance Sheets. |

[0001628280-16-017809:notes:113]
| (2) | The fair value of derivative liabilities is measured using Level 2 fair value inputs and is recorded as accrued expenses in the Condensed Consolidated Balance Sheets. |

[0001628280-16-017809:notes:114]
The following table shows the pre-tax gains and losses of the Company’s derivative and non-derivative instruments designated as cash flow, net investment and fair value hedges on OCI and the Condensed Consolidated Statements of Operations for the three- and nine-month periods ended June 25, 2016 and June 27, 2015 (in millions):

[0001628280-16-017809:notes:115]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25, 2016 |  | June 27, 2015 |  | June 25, 2016 |  | June 27, 2015 |
| Gains/(Losses) recognized in OCI – effective portion: |  |  |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | (170 | ) |  | $ | (34 | ) |  | $ | 18 |  |  | $ | 3,716 |  |
| Interest rate contracts | (11 | ) |  | 1 |  |  | (53 | ) |  | (90 | ) |
| Total | $ | (181 | ) |  | $ | (33 | ) |  | $ | (35 | ) |  | $ | 3,626 |  |
| Net investment hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 55 |  |  | $ | — |  |  | $ | 167 |  |
| Foreign currency debt | (128 | ) |  | (6 | ) |  | (205 | ) |  | (6 | ) |
| Total | $ | (128 | ) |  | $ | 49 |  |  | $ | (205 | ) |  | $ | 161 |  |
| Gains/(Losses) reclassified from AOCI into net income – effective portion: |  |  |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 142 |  |  | $ | 1,420 |  |  | $ | 1,325 |  |  | $ | 2,905 |  |
| Interest rate contracts | (3 | ) |  | (4 | ) |  | (10 | ) |  | (13 | ) |
| Total | $ | 139 |  |  | $ | 1,416 |  |  | $ | 1,315 |  |  | $ | 2,892 |  |
| Gains/(Losses) on derivative instruments: |  |  |  |  |  |  |  |
| Fair value hedges: |  |  |  |  |  |  |  |
| Interest rate contracts | $ | 345 |  |  | $ | (254 | ) |  | $ | 484 |  |  | $ | (15 | ) |
| Gains/(Losses) related to hedged items: |  |  |  |  |  |  |  |
| Fair value hedges: |  |  |  |  |  |  |  |
| Interest rate contracts | $ | (345 | ) |  | $ | 254 |  |  | $ | (484 | ) |  | $ | 15 |  |

[0001628280-16-017809:notes:116]
The notional amounts for outstanding derivative instruments provide one measure of the transaction volume outstanding and do not represent the amount of the Company’s exposure to credit or market loss. The credit risk amounts represent the Company’s gross exposure to potential accounting loss on derivative instruments that are outstanding or unsettled if all counterparties failed to perform according to the terms of the contract, based on then-current currency or interest rates at each respective date. The Company’s exposure to credit loss and market risk will vary over time as currency and interest rates change. Although the table above reflects the notional and credit risk amounts of the Company’s derivative instruments, it does not reflect the gains or losses associated with the exposures and transactions that the instruments are intended to hedge. The amounts ultimately realized upon settlement of these financial instruments, together with the gains and losses on the underlying exposures, will depend on actual market conditions during the remaining life of the instruments.

[0001628280-16-017809:notes:117]
The Company generally enters into master netting arrangements, which are designed to reduce credit risk by permitting net settlement of transactions with the same counterparty. To further limit credit risk, the Company generally enters into collateral security arrangements that provide for collateral to be received or posted when the net fair value of certain financial instruments fluctuates from contractually established thresholds. The Company presents its derivative assets and derivative liabilities at their gross fair values in its Condensed Consolidated Balance Sheets. As of June 25, 2016, the net cash collateral posted by the Company related to derivative instruments under its collateral security arrangements was $175 million, which was recorded as other current assets in the Condensed Consolidated Balance Sheet. As of September 26, 2015, the net cash collateral received by the Company related to derivative instruments under its collateral security arrangements was $1.0 billion, which was recorded as accrued expenses in the Condensed Consolidated Balance Sheet.

[0001628280-16-017809:notes:118]
Under master netting arrangements with the respective counterparties to the Company’s derivative contracts, the Company is allowed to net settle transactions with a single net amount payable by one party to the other. As of June 25, 2016 and September 26, 2015, the potential effects of these rights of set-off associated with the Company’s derivative contracts, including the effects of collateral, would be a reduction to both derivative assets and derivative liabilities of $1.3 billion and $2.2 billion, respectively, resulting in a net derivative asset of $353 million and a net derivative liability of $78 million, respectively.

[0001628280-16-017809:notes:119]
[same as prior period, unchanged from 0001193125-16-559625:notes:77]

[0001628280-16-017809:notes:120]
[same as prior period, unchanged from 0001193125-16-559625:notes:78]

[0001628280-16-017809:notes:121]
The Company has considerable trade receivables outstanding with its third-party cellular network carriers, wholesalers, retailers, value-added resellers, small and mid-sized businesses and education, enterprise and government customers that are not covered by collateral, third-party financing arrangements or credit insurance. As of June 25, 2016 and September 26, 2015, the Company had one customer that represented 11% and 12%, of total trade receivables, respectively. The Company’s cellular network carriers accounted for 59% and 71% of trade receivables as of June 25, 2016 and September 26, 2015, respectively.

[0001628280-16-017809:notes:122]
[same as prior period, unchanged from 0001193125-16-559625:notes:80]

[0001628280-16-017809:notes:123]
The Company has non-trade receivables from certain of its manufacturing vendors resulting from the sale of components to these vendors who manufacture sub-assemblies or assemble final products for the Company. Vendor non-trade receivables from three of the Company’s vendors accounted for 47%, 17% and 16% of total vendor non-trade receivables as of June 25, 2016 and three of the Company’s vendors accounted for 38%, 18% and 14% of total vendor non-trade receivables as of September 26, 2015.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-16-017809:notes:124]
Income Taxes

[0001628280-16-017809:notes:125]
As of June 25, 2016, the Company recorded gross unrecognized tax benefits of $7.6 billion, of which $2.8 billion, if recognized, would affect the Company’s effective tax rate. As of September 26, 2015, the total amount of gross unrecognized tax benefits was $6.9 billion, of which $2.5 billion, if recognized, would have affected the Company’s effective tax rate. The Company’s total gross unrecognized tax benefits are classified as other non-current liabilities in the Condensed Consolidated Balance Sheets. The Company had $1.5 billion and $1.3 billion of gross interest and penalties accrued as of June 25, 2016 and September 26, 2015, respectively, which are classified as other non-current liabilities in the Condensed Consolidated Balance Sheets.

[0001628280-16-017809:notes:126]
Management believes that an adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax audits cannot be predicted with certainty. If any issues addressed in the Company’s tax audits are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. Although timing of the resolution and/or closure of audits is not certain, the Company believes it is reasonably possible that its gross unrecognized tax benefits could decrease (whether by payment, release or a combination of both) in the next 12 months by as much as $800 million.

[0001628280-16-017809:notes:127]
On June 11, 2014, the European Commission issued an opening decision initiating a formal investigation against Ireland for alleged state aid to the Company. The opening decision concerns the allocation of profits for taxation purposes of the Irish branches of two subsidiaries of the Company. The Company believes the European Commission’s assertions are without merit. If the European Commission were to conclude against Ireland, the European Commission could require Ireland to recover from the Company past taxes covering a period of up to 10 years reflective of the disallowed state aid. While such amount could be material, as of June 25, 2016 the Company is unable to estimate the impact.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001628280-16-017809:notes:128]
Acquired Intangible Assets

[0001628280-16-017809:notes:129]
The Company’s acquired intangible assets with definite useful lives primarily consist of patents and licenses and are amortized over periods typically from three to seven years. The following table summarizes the components of gross and net acquired intangible asset balances as of June 25, 2016 and September 26, 2015 (in millions):

[0001628280-16-017809:notes:130]
|  | June 25, 2016 |  | September 26, 2015 |
|  | GrossCarrying Amount |  | AccumulatedAmortization |  | NetCarrying Amount |  | GrossCarrying Amount |  | AccumulatedAmortization |  | NetCarrying Amount |
| Definite-lived and amortizable acquired intangible assets | $ | 8,817 |  |  | $ | (5,411 | ) |  | $ | 3,406 |  |  | $ | 8,125 |  |  | $ | (4,332 | ) |  | $ | 3,793 |  |
| Indefinite-lived and non-amortizable acquired intangible assets | 100 |  |  | — |  |  | 100 |  |  | 100 |  |  | — |  |  | 100 |  |
| Total acquired intangible assets | $ | 8,917 |  |  | $ | (5,411 | ) |  | $ | 3,506 |  |  | $ | 8,225 |  |  | $ | (4,332 | ) |  | $ | 3,893 |  |


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001628280-16-017809:notes:131]
A reconciliation of the Company’s segment operating income to the Condensed Consolidated Statements of Operations for the three- and nine-month periods ended June 25, 2016 and June 27, 2015 is as follows (in millions):

[0001628280-16-017809:notes:132]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25, 2016 |  | June 27, 2015 |  | June 25, 2016 |  | June 27, 2015 |
| Segment operating income | $ | 13,722 |  |  | $ | 17,200 |  |  | $ | 58,928 |  |  | $ | 65,797 |  |
| Research and development expense | (2,560 | ) |  | (2,034 | ) |  | (7,475 | ) |  | (5,847 | ) |
| Other corporate expenses, net | (1,057 | ) |  | (1,083 | ) |  | (3,190 | ) |  | (3,343 | ) |
| Total operating income | $ | 10,105 |  |  | $ | 14,083 |  |  | $ | 48,263 |  |  | $ | 56,607 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001628280-16-017809:notes:133]
The following table shows information by reportable operating segment for the three- and nine-month periods ended June 25, 2016 and June 27, 2015 (in millions):

[0001628280-16-017809:notes:134]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25, 2016 |  | June 27, 2015 |  | June 25, 2016 |  | June 27, 2015 |
| Americas: |  |  |  |  |  |  |  |
| Net sales | $ | 17,963 |  |  | $ | 20,209 |  |  | $ | 66,384 |  |  | $ | 72,091 |  |
| Operating income | $ | 5,453 |  |  | $ | 6,177 |  |  | $ | 21,587 |  |  | $ | 24,064 |  |
| Europe: |  |  |  |  |  |  |  |
| Net sales | $ | 9,643 |  |  | $ | 10,342 |  |  | $ | 39,110 |  |  | $ | 39,760 |  |
| Operating income | $ | 2,666 |  |  | $ | 3,275 |  |  | $ | 12,047 |  |  | $ | 13,269 |  |
| Greater China: |  |  |  |  |  |  |  |
| Net sales | $ | 8,848 |  |  | $ | 13,230 |  |  | $ | 39,707 |  |  | $ | 46,197 |  |
| Operating income | $ | 3,415 |  |  | $ | 5,147 |  |  | $ | 15,809 |  |  | $ | 18,227 |  |
| Japan: |  |  |  |  |  |  |  |
| Net sales | $ | 3,529 |  |  | $ | 2,872 |  |  | $ | 12,604 |  |  | $ | 11,777 |  |
| Operating income | $ | 1,435 |  |  | $ | 1,447 |  |  | $ | 5,605 |  |  | $ | 5,634 |  |
| Rest of Asia Pacific: |  |  |  |  |  |  |  |
| Net sales | $ | 2,375 |  |  | $ | 2,952 |  |  | $ | 10,982 |  |  | $ | 12,389 |  |
| Operating income | $ | 753 |  |  | $ | 1,154 |  |  | $ | 3,880 |  |  | $ | 4,603 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-16-017809:notes:135]
Segment Information and Geographic Data

[0001628280-16-017809:notes:136]
The Company reports segment information based on the “management” approach. The management approach designates the internal reporting used by management for making decisions and assessing performance as the source of the Company’s reportable operating segments.

[0001628280-16-017809:notes:137]
The Company manages its business primarily on a geographic basis. The Company’s reportable operating segments consist of the Americas, Europe, Greater China, Japan and Rest of Asia Pacific. The Americas segment includes both North and South America. The Europe segment includes European countries, as well as India, the Middle East and Africa. The Greater China segment includes China, Hong Kong and Taiwan. The Rest of Asia Pacific segment includes Australia and those Asian countries not included in the Company’s other reportable operating segments. Although the reportable operating segments provide similar hardware and software products and similar services, each one is managed separately to better align with the location of the Company’s customers and distribution partners and the unique market dynamics of each geographic region. The accounting policies of the various segments are the same as those described in Note 1, “Summary of Significant Accounting Policies” of the Notes to Consolidated Financial Statements in Part II, Item 8 of the 2015 Form 10-K.

[0001628280-16-017809:notes:138]
The Company evaluates the performance of its reportable operating segments based on net sales and operating income. Net sales for geographic segments are generally based on the location of customers and sales through the Company’s retail stores located in those geographic locations. Operating income for each segment includes net sales to third parties, related cost of sales and operating expenses directly attributable to the segment. Advertising expenses are generally included in the geographic segment in which the expenditures are incurred. Operating income for each segment excludes other income and expense and certain expenses managed outside the reportable operating segments. Costs excluded from segment operating income include various corporate expenses such as research and development, corporate marketing expenses, certain share-based compensation expenses, income taxes, various nonrecurring charges and other separately managed general and administrative costs. The Company does not include intercompany transfers between segments for management reporting purposes.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-16-017809:notes:139]
Shareholders’ Equity

[0001628280-16-017809:notes:140]
[same as prior period, unchanged from 0001193125-16-559625:notes:119]

[0001628280-16-017809:notes:141]
Future dividends are subject to declaration by the Board of Directors.

[0001628280-16-017809:notes:142]
[same as prior period, unchanged from 0001193125-16-559625:notes:121]

[0001628280-16-017809:notes:143]
In the third quarter of 2016, the Company’s Board of Directors increased the share repurchase authorization to $175 billion of the Company’s common stock, of which $127 billion had been utilized as of June 25, 2016. The Company’s share repurchase program does not obligate it to acquire any specific number of shares. Under the program, shares may be repurchased in privately negotiated and/or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).

[0001628280-16-017809:notes:144]
The Company has entered, and in the future may enter, into accelerated share repurchase arrangements (“ASRs”) with financial institutions. In exchange for up-front payments, the financial institutions deliver shares of the Company’s common stock during the purchase periods of each ASR. The total number of shares ultimately delivered, and therefore the average repurchase price paid per share, is determined at the end of the applicable purchase period of each ASR based on the volume weighted-average price of the Company’s common stock during that period. The shares received are retired in the periods they are delivered, and the up-front payments are accounted for as a reduction to shareholders’ equity in the Company’s Condensed Consolidated Balance Sheets in the periods the payments are made. The Company reflects the ASRs as a repurchase of common stock in the period delivered for purposes of calculating earnings per share and as forward contracts indexed to its own common stock. The ASRs met all of the applicable criteria for equity classification, and therefore were not accounted for as derivative instruments.
