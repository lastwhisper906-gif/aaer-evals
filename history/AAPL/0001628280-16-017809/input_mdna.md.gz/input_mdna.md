# AAPL MD&A — 0001628280-16-017809


## mdna

[0001628280-16-017809:mdna:1]
[same as prior period, unchanged from 0001193125-16-559625:mdna:1]

[0001628280-16-017809:mdna:2]
[same as prior period, unchanged from 0001193125-16-559625:mdna:2]

[0001628280-16-017809:mdna:3]
The Company’s Annual Report on Form 10-K, Quarterly Reports on Form 10-Q, Current Reports on Form 8-K, and amendments to reports filed pursuant to Sections 13(a) and 15(d) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), are filed with the SEC. The Company is subject to the informational requirements of the Exchange Act and files or furnishes reports, proxy statements, and other information with the SEC. Such reports and other information filed by the Company with the SEC are available free of charge on the Company’s website at investor.apple.com/sec.cfm when such reports are available on the SEC’s website. The public may read and copy any materials filed by the Company with the SEC at the SEC’s Public Reference Room at 100 F Street, NE, Room 1580, Washington, DC 20549. The public may obtain information on the operation of the Public Reference Room by calling the SEC at 1-800-SEC-0330. The SEC maintains an internet site that contains reports, proxy and information statements and other information regarding issuers that file electronically with the SEC at www.sec.gov. The contents of websites are not incorporated into this filing. Further, the Company’s references to website URLs are intended to be inactive textual references only.

[0001628280-16-017809:mdna:4]
[same as prior period, unchanged from 0001193125-16-559625:mdna:4]

[0001628280-16-017809:mdna:5]
[same as prior period, unchanged from 0001193125-16-559625:mdna:5]

[0001628280-16-017809:mdna:6]
The Company designs, manufactures and markets mobile communication and media devices, personal computers and portable digital music players, and sells a variety of related software, services, accessories, networking solutions and third-party digital content and applications. The Company’s products and services include iPhone®, iPad®, Mac®, iPod®, Apple Watch®, Apple TV®, a portfolio of consumer and professional software applications, iOS, macOS™, watchOS® and tvOS™ operating systems, iCloud®, Apple Pay® and a variety of accessory, service and support offerings. The Company sells and delivers digital content and applications through the iTunes Store®, App Store®, Mac App Store, TV App Store, iBooks Store™ and Apple Music® (collectively “Internet Services”). The Company sells its products worldwide through its retail stores, online stores and direct sales force, as well as through third-party cellular network carriers, wholesalers, retailers and value-added resellers. In addition, the Company sells a variety of third-party Apple compatible products, including application software and various accessories through its online and retail stores. The Company sells to consumers, small and mid-sized businesses and education, enterprise and government customers.

[0001628280-16-017809:mdna:7]
[same as prior period, unchanged from 0001193125-16-559625:mdna:7]

[0001628280-16-017809:mdna:8]
The Company is committed to bringing the best user experience to its customers through its innovative hardware, software and services. The Company’s business strategy leverages its unique ability to design and develop its own operating systems, hardware, application software and services to provide its customers products and solutions with innovative design, superior ease-of-use and seamless integration. As part of its strategy, the Company continues to expand its platform for the discovery and delivery of digital content and applications through its Internet Services, which allows customers to discover and download digital content, iOS, Mac, Apple Watch and Apple TV applications, and books through either a Mac or Windows-based computer or through iPhone, iPad and iPod touch® devices (“iOS devices”) and Apple Watch. The Company also supports a community for the development of third-party software and hardware products and digital content that complement the Company’s offerings. The Company believes a high-quality buying experience with knowledgeable salespersons who can convey the value of the Company’s products and services greatly enhances its ability to attract and retain customers. Therefore, the Company’s strategy also includes building and expanding its own retail and online stores and its third-party distribution network to effectively reach more customers and provide them with a high-quality sales and post-sales support experience. The Company believes ongoing investment in research and development (“R&D”), marketing and advertising is critical to the development and sale of innovative products and technologies.

[0001628280-16-017809:mdna:9]
23

[0001628280-16-017809:mdna:10]
[same as prior period, unchanged from 0001193125-16-559625:mdna:9]

[0001628280-16-017809:mdna:11]
The Company has historically experienced higher net sales in its first quarter compared to other quarters in its fiscal year due in part to seasonal holiday demand. Additionally, new product introductions can significantly impact net sales, product costs and operating expenses. Product introductions can also impact the Company’s net sales to its indirect distribution channels as these channels are filled with new product inventory following a product introduction, and often, channel inventory of a particular product declines as the next related major product launch approaches. Net sales can also be affected when consumers and distributors anticipate a product introduction. However, neither historical seasonal patterns nor historical patterns of product introductions should be considered reliable indicators of the Company’s future pattern of product introductions, future net sales or financial performance.

[0001628280-16-017809:mdna:12]
Third Quarter Fiscal 2016 Highlights

[0001628280-16-017809:mdna:13]
Net sales decreased 15% or $7.2 billion during the third quarter of 2016 compared to the same quarter in 2015, primarily driven by lower unit sales and a reduction in the average selling price ("ASP") for iPhone. The Company had strong year-over-year net sales growth in Services.

[0001628280-16-017809:mdna:14]
During the third quarter of 2016, the Company began shipping iPhone SE and the 9.7-inch iPad ProTM. Additionally, at its Worldwide Developers Conference in June 2016, the Company announced updates to its operating systems with iOS 10, macOS Sierra, watchOS 3 and the new tvOS, which are expected to be available in the fall of 2016.

[0001628280-16-017809:mdna:15]
The Company utilized $10.0 billion to repurchase shares of its common stock and paid dividends and dividend equivalents of $3.2 billion during the third quarter of 2016. Additionally, the Company issued $1.4 billion of U.S. dollar-denominated and A$1.4 billion of Australian dollar-denominated long-term debt.

[0001628280-16-017809:mdna:16]
[same as prior period, unchanged from 0001193125-16-559625:mdna:14]

[0001628280-16-017809:mdna:17]
The following table shows net sales by operating segment and net sales and unit sales by product for the three- and nine-month periods ended June 25, 2016 and June 27, 2015 (dollars in millions and units in thousands):

[0001628280-16-017809:mdna:18]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25, 2016 |  | June 27, 2015 |  | Change |  | June 25, 2016 |  | June 27, 2015 |  | Change |
| Net Sales by Operating Segment: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 17,963 |  |  | $ | 20,209 |  |  | (11 | )% |  | $ | 66,384 |  |  | $ | 72,091 |  |  | (8 | )% |
| Europe | 9,643 |  |  | 10,342 |  |  | (7 | )% |  | 39,110 |  |  | 39,760 |  |  | (2 | )% |
| Greater China | 8,848 |  |  | 13,230 |  |  | (33 | )% |  | 39,707 |  |  | 46,197 |  |  | (14 | )% |
| Japan | 3,529 |  |  | 2,872 |  |  | 23 | % |  | 12,604 |  |  | 11,777 |  |  | 7 | % |
| Rest of Asia Pacific | 2,375 |  |  | 2,952 |  |  | (20 | )% |  | 10,982 |  |  | 12,389 |  |  | (11 | )% |
| Total net sales | $ | 42,358 |  |  | $ | 49,605 |  |  | (15 | )% |  | $ | 168,787 |  |  | $ | 182,214 |  |  | (7 | )% |
| Net Sales by Product: |  |  |  |  |  |  |  |  |  |  |  |
| iPhone (1) | $ | 24,048 |  |  | $ | 31,368 |  |  | (23 | )% |  | $ | 108,540 |  |  | $ | 122,832 |  |  | (12 | )% |
| iPad (1) | 4,876 |  |  | 4,538 |  |  | 7 | % |  | 16,373 |  |  | 18,951 |  |  | (14 | )% |
| Mac (1) | 5,239 |  |  | 6,030 |  |  | (13 | )% |  | 17,092 |  |  | 18,589 |  |  | (8 | )% |
| Services (2) | 5,976 |  |  | 5,028 |  |  | 19 | % |  | 18,023 |  |  | 14,823 |  |  | 22 | % |
| Other Products (1)(3) | 2,219 |  |  | 2,641 |  |  | (16 | )% |  | 8,759 |  |  | 7,019 |  |  | 25 | % |
| Total net sales | $ | 42,358 |  |  | $ | 49,605 |  |  | (15 | )% |  | $ | 168,787 |  |  | $ | 182,214 |  |  | (7 | )% |
| Unit Sales by Product: |  |  |  |  |  |  |  |  |  |  |  |
| iPhone | 40,399 |  |  | 47,534 |  |  | (15 | )% |  | 166,371 |  |  | 183,172 |  |  | (9 | )% |
| iPad | 9,950 |  |  | 10,931 |  |  | (9 | )% |  | 36,323 |  |  | 44,973 |  |  | (19 | )% |
| Mac | 4,252 |  |  | 4,796 |  |  | (11 | )% |  | 13,598 |  |  | 14,878 |  |  | (9 | )% |

[0001628280-16-017809:mdna:19]
| (1) | Includes deferrals and amortization of related software upgrade rights and non-software services. |

[0001628280-16-017809:mdna:20]
| (2) | Includes revenue from Internet Services, AppleCare®, Apple Pay, licensing and other services. |

[0001628280-16-017809:mdna:21]
| (3) | Includes sales of Apple TV, Apple Watch, Beats® products, iPod and Apple-branded and third-party accessories. |

[0001628280-16-017809:mdna:22]
24

[0001628280-16-017809:mdna:23]
[same as prior period, unchanged from 0001193125-16-559625:mdna:20]

[0001628280-16-017809:mdna:24]
[same as prior period, unchanged from 0001193125-16-559625:mdna:21]

[0001628280-16-017809:mdna:25]
The following table presents iPhone net sales and unit sales information for the three- and nine-month periods ended June 25, 2016 and June 27, 2015 (dollars in millions and units in thousands):

[0001628280-16-017809:mdna:26]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25, 2016 |  | June 27, 2015 |  | Change |  | June 25, 2016 |  | June 27, 2015 |  | Change |
| Net sales | $ | 24,048 |  |  | $ | 31,368 |  |  | (23 | )% |  | $ | 108,540 |  |  | $ | 122,832 |  |  | (12 | )% |
| Percentage of total net sales | 57 | % |  | 63 | % |  |  |  | 64 | % |  | 67 | % |  |  |
| Unit sales | 40,399 |  |  | 47,534 |  |  | (15 | )% |  | 166,371 |  |  | 183,172 |  |  | (9 | )% |

[0001628280-16-017809:mdna:27]
iPhone net sales and unit sales decreased during the third quarter and first nine months of 2016 compared to the same periods in 2015. The Company believes the unit sales decline is due primarily to the acceleration of iPhone upgrades in 2015 and challenging market conditions around the world. ASPs for iPhone were lower year-over-year during the third quarter and first nine months of 2016 due primarily to a shift in the mix of iPhones.

[0001628280-16-017809:mdna:28]
[same as prior period, unchanged from 0001193125-16-559625:mdna:25]

[0001628280-16-017809:mdna:29]
The following table presents iPad net sales and unit sales information for the three- and nine-month periods ended June 25, 2016 and June 27, 2015 (dollars in millions and units in thousands):

[0001628280-16-017809:mdna:30]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25, 2016 |  | June 27, 2015 |  | Change |  | June 25, 2016 |  | June 27, 2015 |  | Change |
| Net sales | $ | 4,876 |  |  | $ | 4,538 |  |  | 7 | % |  | $ | 16,373 |  |  | $ | 18,951 |  |  | (14 | )% |
| Percentage of total net sales | 12 | % |  | 9 | % |  |  |  | 10 | % |  | 10 | % |  |  |
| Unit sales | 9,950 |  |  | 10,931 |  |  | (9 | )% |  | 36,323 |  |  | 44,973 |  |  | (19 | )% |

[0001628280-16-017809:mdna:31]
iPad net sales increased in the third quarter of 2016 compared to the same period in 2015 primarily due to higher ASPs for iPad driven by the launch of the 9.7-inch iPad Pro. iPad net sales decreased during the first nine months of 2016 compared to the same period in 2015 primarily due to lower unit sales and the effect of weakness in most foreign currencies relative to the U.S. dollar, partially offset by higher ASPs for iPad. The Company believes the year-over-year decline in unit sales during the third quarter and first nine months of 2016 is due in part to a longer repurchase cycle for iPads and some level of cannibalization from the Company's other products.

[0001628280-16-017809:mdna:32]
[same as prior period, unchanged from 0001193125-16-559625:mdna:29]

[0001628280-16-017809:mdna:33]
The following table presents Mac net sales and unit sales information for the three- and nine-month periods ended June 25, 2016 and June 27, 2015 (dollars in millions and units in thousands):

[0001628280-16-017809:mdna:34]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25, 2016 |  | June 27, 2015 |  | Change |  | June 25, 2016 |  | June 27, 2015 |  | Change |
| Net sales | $ | 5,239 |  |  | $ | 6,030 |  |  | (13 | )% |  | $ | 17,092 |  |  | $ | 18,589 |  |  | (8 | )% |
| Percentage of total net sales | 12 | % |  | 12 | % |  |  |  | 10 | % |  | 10 | % |  |  |
| Unit sales | 4,252 |  |  | 4,796 |  |  | (11 | )% |  | 13,598 |  |  | 14,878 |  |  | (9 | )% |

[0001628280-16-017809:mdna:35]
Mac net sales and unit sales decreased during the third quarter and first nine months of 2016 compared to the same periods in 2015 similar to the overall market contraction.

[0001628280-16-017809:mdna:36]
25

[0001628280-16-017809:mdna:37]
[same as prior period, unchanged from 0001193125-16-559625:mdna:33]

[0001628280-16-017809:mdna:38]
The following table presents net sales information of Services for the three- and nine-month periods ended June 25, 2016 and June 27, 2015 (dollars in millions):

[0001628280-16-017809:mdna:39]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25, 2016 |  | June 27, 2015 |  | Change |  | June 25, 2016 |  | June 27, 2015 |  | Change |
| Net sales | $ | 5,976 |  |  | $ | 5,028 |  |  | 19 | % |  | $ | 18,023 |  |  | $ | 14,823 |  |  | 22 | % |
| Percentage of total net sales | 14 | % |  | 10 | % |  |  |  | 11 | % |  | 8 | % |  |  |

[0001628280-16-017809:mdna:40]
The year-over-year increase in net sales of Services in the third quarter and first nine months of 2016 was due primarily to growth from App Store, licensing and AppleCare sales. During the first quarter of 2016, the Company received $548 million from Samsung Electronics Co., Ltd. related to its patent infringement lawsuit, which was recorded as licensing net sales within Services.

[0001628280-16-017809:mdna:41]
[same as prior period, unchanged from 0001193125-16-559625:mdna:37]

[0001628280-16-017809:mdna:42]
The Company manages its business primarily on a geographic basis. The Company’s reportable operating segments consist of the Americas, Europe, Greater China, Japan and Rest of Asia Pacific. The Americas segment includes both North and South America. The Europe segment includes European countries, as well as India, the Middle East and Africa. The Greater China segment includes China, Hong Kong and Taiwan. The Rest of Asia Pacific segment includes Australia and those Asian countries not included in the Company’s other reportable operating segments. Although the reportable operating segments provide similar hardware and software products and similar services, each one is managed separately to better align with the location of the Company’s customers and distribution partners and the unique market dynamics of each geographic region. Further information regarding the Company’s reportable operating segments can be found in Part I, Item 1 of this Form 10-Q in the Notes to Condensed Consolidated Financial Statements, in Note 11, “Segment Information and Geographic Data.”

[0001628280-16-017809:mdna:43]
[same as prior period, unchanged from 0001193125-16-559625:mdna:39]

[0001628280-16-017809:mdna:44]
The following table presents Americas net sales information for the three- and nine-month periods ended June 25, 2016 and June 27, 2015 (dollars in millions):

[0001628280-16-017809:mdna:45]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25, 2016 |  | June 27, 2015 |  | Change |  | June 25, 2016 |  | June 27, 2015 |  | Change |
| Net sales | $ | 17,963 |  |  | $ | 20,209 |  |  | (11 | )% |  | $ | 66,384 |  |  | $ | 72,091 |  |  | (8 | )% |
| Percentage of total net sales | 42 | % |  | 41 | % |  |  |  | 39 | % |  | 40 | % |  |  |

[0001628280-16-017809:mdna:46]
Americas net sales decreased during the third quarter and first nine months of 2016 compared to the same periods in 2015 due primarily to lower net sales of iPhone and the effect of weakness in foreign currencies relative to the U.S. dollar.

[0001628280-16-017809:mdna:47]
[same as prior period, unchanged from 0001193125-16-559625:mdna:43]

[0001628280-16-017809:mdna:48]
The following table presents Europe net sales information for the three- and nine-month periods ended June 25, 2016 and June 27, 2015 (dollars in millions):

[0001628280-16-017809:mdna:49]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25, 2016 |  | June 27, 2015 |  | Change |  | June 25, 2016 |  | June 27, 2015 |  | Change |
| Net sales | $ | 9,643 |  |  | $ | 10,342 |  |  | (7 | )% |  | $ | 39,110 |  |  | $ | 39,760 |  |  | (2 | )% |
| Percentage of total net sales | 23 | % |  | 21 | % |  |  |  | 23 | % |  | 22 | % |  |  |

[0001628280-16-017809:mdna:50]
Europe net sales decreased during the third quarter of 2016 compared to the same period in 2015 due primarily to lower net sales of iPhone and the effect of weakness in foreign currencies relative to the U.S. dollar, partially offset by an increase in Services. The year-over-year decrease in Europe net sales during the first nine months of 2016 was driven primarily by the effect of weakness in foreign currencies relative to the U.S. dollar, partially offset by an increase in Services.

[0001628280-16-017809:mdna:51]
[same as prior period, unchanged from 0001193125-16-559625:mdna:47]

[0001628280-16-017809:mdna:52]
The following table presents Greater China net sales information for the three- and nine-month periods ended June 25, 2016 and June 27, 2015 (dollars in millions):

[0001628280-16-017809:mdna:53]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25, 2016 |  | June 27, 2015 |  | Change |  | June 25, 2016 |  | June 27, 2015 |  | Change |
| Net sales | $ | 8,848 |  |  | $ | 13,230 |  |  | (33 | )% |  | $ | 39,707 |  |  | $ | 46,197 |  |  | (14 | )% |
| Percentage of total net sales | 21 | % |  | 27 | % |  |  |  | 24 | % |  | 25 | % |  |  |

[0001628280-16-017809:mdna:54]
Greater China net sales decreased during the third quarter and first nine months of 2016 compared to the same periods in 2015 due primarily to lower net sales of iPhone and the effect of weakness in foreign currencies relative to the U.S. dollar, partially offset by an increase in Services.

[0001628280-16-017809:mdna:55]
[same as prior period, unchanged from 0001193125-16-559625:mdna:51]

[0001628280-16-017809:mdna:56]
The following table presents Japan net sales information for the three- and nine-month periods ended June 25, 2016 and June 27, 2015 (dollars in millions):

[0001628280-16-017809:mdna:57]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25, 2016 |  | June 27, 2015 |  | Change |  | June 25, 2016 |  | June 27, 2015 |  | Change |
| Net sales | $ | 3,529 |  |  | $ | 2,872 |  |  | 23 | % |  | $ | 12,604 |  |  | $ | 11,777 |  |  | 7 | % |
| Percentage of total net sales | 8 | % |  | 6 | % |  |  |  | 7 | % |  | 6 | % |  |  |

[0001628280-16-017809:mdna:58]
The year-over-year increase in Japan net sales during the third quarter of 2016 was due primarily to higher net sales of iPhone and Services, and the effect of strength in the Japanese yen relative to the U.S. dollar. Japan net sales increased during the first nine months of 2016 compared to the same period in 2015 due primarily to higher net sales of Services and iPhone, partially offset by the effect of weakness in the Japanese yen relative to the U.S. dollar.

[0001628280-16-017809:mdna:59]
[same as prior period, unchanged from 0001193125-16-559625:mdna:55]

[0001628280-16-017809:mdna:60]
The following table presents Rest of Asia Pacific net sales information for the three- and nine-month periods ended June 25, 2016 and June 27, 2015 (dollars in millions):

[0001628280-16-017809:mdna:61]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25, 2016 |  | June 27, 2015 |  | Change |  | June 25, 2016 |  | June 27, 2015 |  | Change |
| Net sales | $ | 2,375 |  |  | $ | 2,952 |  |  | (20 | )% |  | $ | 10,982 |  |  | $ | 12,389 |  |  | (11 | )% |
| Percentage of total net sales | 6 | % |  | 6 | % |  |  |  | 7 | % |  | 7 | % |  |  |

[0001628280-16-017809:mdna:62]
Rest of Asia Pacific net sales decreased during the third quarter and first nine months of 2016 compared to the same periods in 2015 due primarily to lower net sales of iPhone and the effect of weakness in foreign currencies relative to the U.S. dollar.

[0001628280-16-017809:mdna:63]
27

[0001628280-16-017809:mdna:64]
[same as prior period, unchanged from 0001193125-16-559625:mdna:59]

[0001628280-16-017809:mdna:65]
Gross margin for the three- and nine-month periods ended June 25, 2016 and June 27, 2015 was as follows (dollars in millions):

[0001628280-16-017809:mdna:66]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25, 2016 |  | June 27, 2015 |  | June 25, 2016 |  | June 27, 2015 |
| Net sales | $ | 42,358 |  |  | $ | 49,605 |  |  | $ | 168,787 |  |  | $ | 182,214 |  |
| Cost of sales | 26,252 |  |  | 29,924 |  |  | 102,337 |  |  | 109,136 |  |
| Gross margin | $ | 16,106 |  |  | $ | 19,681 |  |  | $ | 66,450 |  |  | $ | 73,078 |  |
| Gross margin percentage | 38.0 | % |  | 39.7 | % |  | 39.4 | % |  | 40.1 | % |

[0001628280-16-017809:mdna:67]
Gross margin decreased during the third quarter and first nine months of 2016 compared to the same periods in 2015 due primarily to the effect of weakness in most foreign currencies relative to the U.S. dollar and unfavorable leverage on fixed costs from lower net sales, partially offset by a favorable shift in mix to services.

[0001628280-16-017809:mdna:68]
The Company anticipates gross margin during the fourth quarter of 2016 to be between 37.5% and 38.0%. The foregoing statement regarding the Company’s expected gross margin percentage in the third quarter of 2016 is forward-looking and could differ from actual results. The Company’s future gross margins can be impacted by multiple factors including, but not limited to, those set forth in Part II, Item 1A of this Form 10-Q under the heading “Risk Factors” and those described in this paragraph. In general, the Company believes gross margins will remain under downward pressure due to a variety of factors, including continued industry wide global product pricing pressures, increased competition, compressed product life cycles, product transitions, potential increases in the cost of components, and potential strengthening of the U.S. dollar, as well as potential increases in the costs of outside manufacturing services and a potential shift in the Company’s sales mix towards products with lower gross margins. In response to competitive pressures, the Company expects it will continue to take product pricing actions, which would adversely affect gross margins. Gross margins could also be affected by the Company’s ability to manage product quality and warranty costs effectively and to stimulate demand for certain of its products. Due to the Company’s significant international operations, its financial condition and operating results, including gross margins, could be significantly affected by fluctuations in exchange rates.

[0001628280-16-017809:mdna:69]
[same as prior period, unchanged from 0001193125-16-559625:mdna:64]

[0001628280-16-017809:mdna:70]
Operating expenses for the three- and nine-month periods ended June 25, 2016 and June 27, 2015 were as follows (dollars in millions):

[0001628280-16-017809:mdna:71]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25, 2016 |  | June 27, 2015 |  | June 25, 2016 |  | June 27, 2015 |
| Research and development | $ | 2,560 |  |  | $ | 2,034 |  |  | $ | 7,475 |  |  | $ | 5,847 |  |
| Percentage of total net sales | 6 | % |  | 4 | % |  | 4 | % |  | 3 | % |
| Selling, general and administrative | $ | 3,441 |  |  | $ | 3,564 |  |  | $ | 10,712 |  |  | $ | 10,624 |  |
| Percentage of total net sales | 8 | % |  | 7 | % |  | 6 | % |  | 6 | % |
| Total operating expenses | $ | 6,001 |  |  | $ | 5,598 |  |  | $ | 18,187 |  |  | $ | 16,471 |  |
| Percentage of total net sales | 14 | % |  | 11 | % |  | 11 | % |  | 9 | % |

[0001628280-16-017809:mdna:72]
[same as prior period, unchanged from 0001193125-16-559625:mdna:67]

[0001628280-16-017809:mdna:73]
The growth in R&D expense during the third quarter and first nine months of 2016 compared to the same periods in 2015 was driven primarily by an increase in headcount and related expenses, and material costs to support expanded R&D activities. The Company continues to believe that focused investments in R&D are critical to its future growth and competitive position in the marketplace and the development of new and updated products that are central to the Company’s core business strategy.

[0001628280-16-017809:mdna:74]
[same as prior period, unchanged from 0001193125-16-559625:mdna:69]

[0001628280-16-017809:mdna:75]
The decrease in selling, general and administrative expense during the third quarter of 2016 compared to the same period in 2015 was primarily due to lower spending on marketing and advertising. The year-over-year increase in selling, general and administrative expense during the first nine months of 2016 compared to the same period in 2015 was due primarily to increased headcount and related expenses, partially offset primarily by a decrease in discretionary expenditures.

[0001628280-16-017809:mdna:76]
[same as prior period, unchanged from 0001193125-16-559625:mdna:71]

[0001628280-16-017809:mdna:77]
Other income/(expense), net for the three- and nine-month periods ended June 25, 2016 and June 27, 2015 was as follows (dollars in millions):

[0001628280-16-017809:mdna:78]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | June 25, 2016 |  | June 27, 2015 |  | Change |  | June 25, 2016 |  | June 27, 2015 |  | Change |
| Interest and dividend income | $ | 1,036 |  |  | $ | 766 |  |  |  |  | $ | 2,963 |  |  | $ | 2,095 |  |  |  |
| Interest expense | (409 | ) |  | (201 | ) |  |  |  | (1,006 | ) |  | (495 | ) |  |  |
| Other expense, net | (263 | ) |  | (175 | ) |  |  |  | (1,036 | ) |  | (754 | ) |  |  |
| Total other income/(expense), net | $ | 364 |  |  | $ | 390 |  |  | (7 | )% |  | $ | 921 |  |  | $ | 846 |  |  | 9 | % |

[0001628280-16-017809:mdna:79]
The decrease in other income/(expense), net during the third quarter of 2016 compared to the same period in 2015 was due primarily to higher interest expense on debt and higher expenses associated with foreign exchange activity, partially offset by higher interest income. The increase in other income/(expense), net during the first nine months of 2016 compared to the same period in 2015 was due primarily to higher interest income, partially offset by higher interest expense on debt. The weighted-average interest rate earned by the Company on its cash, cash equivalents and marketable securities was 1.77% and 1.51% in the third quarters of 2016 and 2015, respectively, and 1.72% and 1.45% in the first nine months of 2016 and 2015, respectively.

[0001628280-16-017809:mdna:80]
[same as prior period, unchanged from 0001193125-16-559625:mdna:75]

[0001628280-16-017809:mdna:81]
Provision for income taxes and effective tax rates for the three- and nine-month periods ended June 25, 2016 and June 27, 2015 were as follows (dollars in millions):

[0001628280-16-017809:mdna:82]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25, 2016 |  | June 27, 2015 |  | June 25, 2016 |  | June 27, 2015 |
| Provision for income taxes | $ | 2,673 |  |  | $ | 3,796 |  |  | $ | 12,511 |  |  | $ | 15,183 |  |
| Effective tax rate | 25.5 | % |  | 26.2 | % |  | 25.4 | % |  | 26.4 | % |

[0001628280-16-017809:mdna:83]
The Company’s effective tax rates during the third quarter of 2016 and 2015 differ from the statutory federal income tax rate of 35% due primarily to certain undistributed foreign earnings, a substantial portion of which was generated by subsidiaries organized in Ireland, for which no U.S. taxes are provided when such earnings are intended to be indefinitely reinvested outside the U.S. The lower effective tax rate during the third quarter and first nine months of 2016 compared to the same periods in 2015 was due primarily to a different geographic mix of earnings.

[0001628280-16-017809:mdna:84]
Subsequent to the end of the third quarter of 2016, the Company reached a partial settlement with the U.S. Internal Revenue Service on its examination of the years 2010 through 2012. In connection with this settlement, the Company expects to recognize a tax benefit in the fourth quarter of 2016, which the Company does not believe will be significant to its consolidated financial statements. In addition, the Company is subject to audits by state, local and foreign tax authorities.  Management believes that adequate provisions have been made for any adjustments that may result from tax examinations. However, the outcome of tax audits cannot be predicted with certainty. If any issues addressed in the Company’s tax audits are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs.

[0001628280-16-017809:mdna:85]
On June 11, 2014, the European Commission issued an opening decision initiating a formal investigation against Ireland for alleged state aid to the Company. The opening decision concerns the allocation of profits for taxation purposes of the Irish branches of two subsidiaries of the Company. The Company believes the European Commission’s assertions are without merit. If the European Commission were to conclude against Ireland, the European Commission could require Ireland to recover from the Company past taxes covering a period of up to 10 years reflective of the disallowed state aid. While such amount could be material, as of June 25, 2016 the Company is unable to estimate the impact.

[0001628280-16-017809:mdna:86]
[same as prior period, unchanged from 0001193125-16-559625:mdna:81]

[0001628280-16-017809:mdna:87]
[same as prior period, unchanged from 0001193125-16-559625:mdna:82]

[0001628280-16-017809:mdna:88]
In March 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2016-09, Compensation – Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting (“ASU 2016-09”), which simplified certain aspects of the accounting for share-based payment transactions, including income taxes, classification of awards and classification in the statement of cash flows. ASU 2016-09 will be effective for the Company beginning in its first quarter of 2018. The Company is currently evaluating the impact of adopting ASU 2016-09 on its consolidated financial statements.

[0001628280-16-017809:mdna:89]
[same as prior period, unchanged from 0001193125-16-559625:mdna:84]

[0001628280-16-017809:mdna:90]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842) (“ASU 2016-02”), which modified lease accounting for both lessees and lessors to increase transparency and comparability by recognizing lease assets and lease liabilities by lessees for those leases classified as operating leases under previous accounting standards and disclosing key information about leasing arrangements. ASU 2016-02 will be effective for the Company beginning in its first quarter of 2020 and early adoption is permitted. The Company is currently evaluating the timing of its adoption and the impact of adopting ASU 2016-02 on its consolidated financial statements.

[0001628280-16-017809:mdna:91]
[same as prior period, unchanged from 0001193125-16-559625:mdna:86]

[0001628280-16-017809:mdna:92]
In January 2016, the FASB issued ASU No. 2016-01, Financial Instruments – Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities (“ASU 2016-01”), which updates certain aspects of recognition, measurement, presentation and disclosure of financial instruments. ASU 2016-01 will be effective for the Company beginning in its first quarter of 2019. The Company does not believe the adoption of ASU 2016-01 will have a material impact on its consolidated financial statements.

[0001628280-16-017809:mdna:93]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (“ASU 2016-13”), which modifies the measurement of expected credit losses of certain financial instruments. ASU 2016-13 will be effective for the Company beginning in its first quarter of 2021 and early adoption is permitted. The Company does not believe the adoption of ASU 2016-13 will have a material impact on its consolidated financial statements.

[0001628280-16-017809:mdna:94]
[same as prior period, unchanged from 0001193125-16-559625:mdna:88]

[0001628280-16-017809:mdna:95]
In May 2014, the FASB issued ASU No. 2014-09, Revenue from Contracts with Customers (Topic 606) (“ASU 2014-09”), which amends the existing accounting standards for revenue recognition. ASU 2014-09 is based on principles that govern the recognition of revenue at an amount an entity expects to be entitled when products are transferred to customers. ASU 2014-09 will be effective for the Company beginning in its first quarter of 2019 and early adoption is permitted.

[0001628280-16-017809:mdna:96]
Subsequently, the FASB has issued the following standards related to ASU 2014-09: ASU No. 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (“ASU 2016-08”); ASU No. 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing (“ASU 2016-10”); and ASU No. 2016-12, Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients (“ASU 2016-12”). The Company must adopt ASU 2016-08, ASU 2016-10 and ASU 2016-12 with ASU 2014-09 (collectively, the “new revenue standards”).

[0001628280-16-017809:mdna:97]
The new revenue standards may be applied retrospectively to each prior period presented or retrospectively with the cumulative effect recognized as of the date of adoption. The Company is currently evaluating the timing of its adoption and the impact of adopting the new revenue standards on its consolidated financial statements.

[0001628280-16-017809:mdna:98]
[same as prior period, unchanged from 0001193125-16-559625:mdna:93]

[0001628280-16-017809:mdna:99]
The following tables present selected financial information and statistics as of June 25, 2016 and September 26, 2015 and for the first nine months of 2016 and 2015 (in millions):

[0001628280-16-017809:mdna:100]
|  | June 25, 2016 |  | September 26, 2015 |
| Cash, cash equivalents and marketable securities | $ | 231,520 |  |  | $ | 205,666 |  |
| Property, plant and equipment, net | $ | 25,448 |  |  | $ | 22,471 |  |
| Commercial paper | $ | 12,496 |  |  | $ | 8,499 |  |
| Total term debt | $ | 72,439 |  |  | $ | 55,963 |  |
| Working capital | $ | 22,275 |  |  | $ | 8,768 |  |

[0001628280-16-017809:mdna:101]
|  | Nine Months Ended |
|  | June 25, 2016 |  | June 27, 2015 |
| Cash generated by operating activities | $ | 49,698 |  |  | $ | 67,791 |  |
| Cash used in investing activities | $ | (38,580 | ) |  | $ | (54,899 | ) |
| Cash used in financing activities | $ | (14,001 | ) |  | $ | (11,417 | ) |

[0001628280-16-017809:mdna:102]
The Company believes its existing balances of cash, cash equivalents and marketable securities will be sufficient to satisfy its working capital needs, capital asset purchases, outstanding commitments and other liquidity requirements associated with its existing operations over the next 12 months. The Company currently anticipates the cash used for future dividends, the share repurchase program and debt repayments will come from its current domestic cash, cash generated from on-going U.S. operating activities and from borrowings.

[0001628280-16-017809:mdna:103]
As of June 25, 2016 and September 26, 2015, the Company’s cash, cash equivalents and marketable securities held by foreign subsidiaries were $214.9 billion and $186.9 billion, respectively, and are generally based in U.S. dollar‑denominated holdings. Amounts held by foreign subsidiaries are generally subject to U.S. income taxation on repatriation to the U.S. The Company’s marketable securities investment portfolio is invested primarily in highly-rated securities and its investment policy generally limits the amount of credit exposure to any one issuer. The policy requires investments generally to be investment grade with the objective of minimizing the potential risk of principal loss.

[0001628280-16-017809:mdna:104]
During the nine months ended June 25, 2016, cash generated from operating activities of $49.7 billion was a result of $36.7 billion of net income, non-cash adjustments to net income of $16.3 billion and a decrease in the net change in operating assets and liabilities of $3.3 billion. Cash used in investing activities of $38.6 billion during the nine months ended June 25, 2016 consisted primarily of cash used for purchases of marketable securities, net of sales and maturities, of $27.2 billion and cash used to acquire property, plant and equipment of $8.8 billion. Cash used in financing activities of $14.0 billion during the nine months ended June 25, 2016 consisted primarily of cash used to repurchase common stock of $23.7 billion, cash used to pay dividends and dividend equivalents of $9.1 billion and cash used to repay term debt of $2.5 billion, partially offset by proceeds from issuance of term debt, net of $18.0 billion and proceeds from commercial paper, net of $4.0 billion.

[0001628280-16-017809:mdna:105]
During the nine months ended June 27, 2015, cash generated from operating activities of $67.8 billion was a result of $42.3 billion of net income, non-cash adjustments to net income of $13.6 billion and an increase in the net change in operating assets and liabilities of $11.9 billion. Cash used in investing activities of $54.9 billion during the nine months ended June 27, 2015 consisted primarily of cash used for purchases of marketable securities, net of sales and maturities, of $47.0 billion and cash used to acquire property, plant and equipment of $7.6 billion. Cash used in financing activities of $11.4 billion during the nine months ended June 27, 2015 consisted primarily of cash used to repurchase common stock of $22.0 billion, cash used to pay dividends and dividend equivalents of $8.6 billion and cash used for repayments of commercial paper, net of $1.8 billion, partially offset by proceeds from the issuance of long-term debt, net of $21.3 billion.

[0001628280-16-017809:mdna:106]
[same as prior period, unchanged from 0001193125-16-559625:mdna:100]

[0001628280-16-017809:mdna:107]
The Company’s capital expenditures were $9.3 billion during the first nine months of 2016. The Company anticipates utilizing approximately $13.0 billion for capital expenditures during 2016, which includes product tooling and manufacturing process equipment; data centers; corporate facilities and infrastructure, including information systems hardware, software and enhancements; and retail store facilities.

[0001628280-16-017809:mdna:108]
[same as prior period, unchanged from 0001193125-16-559625:mdna:102]

[0001628280-16-017809:mdna:109]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses the net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of June 25, 2016, the Company had $12.5 billion of Commercial Paper outstanding, with a weighted-average interest rate of 0.42% and maturities generally less than nine months.

[0001628280-16-017809:mdna:110]
As of June 25, 2016, the Company has outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $71.6 billion (collectively the “Notes”). During the third quarter of 2016, the Company repaid $2.5 billion of its Notes. The Company has entered, and in the future may enter, into interest rate swaps to manage interest rate risk on the Notes. In addition, the Company has entered, and in the future may enter, into currency swaps to manage foreign currency risk on the Notes.

[0001628280-16-017809:mdna:111]
Further information regarding the Company’s debt issuances and related hedging activity can be found in Part I, Item 1 of this Form 10-Q in the Notes to Condensed Consolidated Financial Statements, in Note 2, “Financial Instruments” and Note 6, “Debt.”

[0001628280-16-017809:mdna:112]
[same as prior period, unchanged from 0001193125-16-559625:mdna:106]

[0001628280-16-017809:mdna:113]
In April 2016, the Company’s Board of Directors increased the share repurchase program authorization from $140 billion to $175 billion of the Company’s common stock, increasing the expected total size of the capital return program to $250 billion. Additionally in April 2016, the Company announced that the Board of Directors raised the rate of the Company's quarterly cash dividend by 10% to $0.57 per share, beginning with the dividend to be paid during the third quarter of 2016. The Company intends to increase its dividend on an annual basis subject to declaration by the Board of Directors.

[0001628280-16-017809:mdna:114]
As of June 25, 2016, $127 billion of the share repurchase program has been utilized. The Company’s share repurchase program does not obligate it to acquire any specific number of shares. Under the program, shares may be repurchased in privately negotiated or open market transactions, including under plans complying with Rule 10b5-1 under the Exchange Act.

[0001628280-16-017809:mdna:115]
The following table presents the Company’s dividends, dividend equivalents, share repurchases and net share settlement activity from the start of the capital return program in August 2012 through June 25, 2016 (in millions):

[0001628280-16-017809:mdna:116]
|  | Dividends and DividendEquivalents Paid |  | Accelerated ShareRepurchases |  | Open MarketShare Repurchases |  | Taxes Related to Settlement of Equity Awards |  | Total |
| Q3 2016 | $ | 3,187 |  |  | $ | 6,000 |  |  | $ | 4,000 |  |  | $ | 610 |  |  | $ | 13,797 |  |
| Q2 2016 | 2,902 |  |  | — |  |  | 7,000 |  |  | 154 |  |  | 10,056 |  |
| Q1 2016 | 2,969 |  |  | 3,000 |  |  | 3,000 |  |  | 597 |  |  | 9,566 |  |
| 2015 | 11,561 |  |  | 6,000 |  |  | 30,026 |  |  | 1,499 |  |  | 49,086 |  |
| 2014 | 11,126 |  |  | 21,000 |  |  | 24,000 |  |  | 1,158 |  |  | 57,284 |  |
| 2013 | 10,564 |  |  | 13,950 |  |  | 9,000 |  |  | 1,082 |  |  | 34,596 |  |
| 2012 | 2,488 |  |  | — |  |  | — |  |  | 56 |  |  | 2,544 |  |
| Total | $ | 44,797 |  |  | $ | 49,950 |  |  | $ | 77,026 |  |  | $ | 5,156 |  |  | $ | 176,929 |  |

[0001628280-16-017809:mdna:117]
The Company expects to execute its capital return program by the end of March 2018 by paying dividends and dividend equivalents, repurchasing shares and remitting withheld taxes related to net share settlement of restricted stock units. The Company plans to continue to access the domestic and international debt markets to assist in funding its capital return program.

[0001628280-16-017809:mdna:118]
[same as prior period, unchanged from 0001193125-16-559625:mdna:112]

[0001628280-16-017809:mdna:119]
The Company has not entered into any transactions with unconsolidated entities whereby the Company has financial guarantees, subordinated retained interests, derivative instruments, or other contingent arrangements that expose the Company to material continuing risks, contingent liabilities, or any other obligation under a variable interest in an unconsolidated entity that provides financing, liquidity, market risk, or credit risk support to the Company, or engages in leasing, hedging, or R&D services with the Company.

[0001628280-16-017809:mdna:120]
[same as prior period, unchanged from 0001193125-16-559625:mdna:114]

[0001628280-16-017809:mdna:121]
As of June 25, 2016, the Company’s total future minimum lease payments under noncancelable operating leases were $7.1 billion. The Company’s retail store and other facility leases are typically for terms not exceeding 10 years and generally contain multi-year renewal options.

[0001628280-16-017809:mdna:122]
[same as prior period, unchanged from 0001193125-16-559625:mdna:116]

[0001628280-16-017809:mdna:123]
The Company utilizes several outsourcing partners to manufacture sub-assemblies for the Company’s products and to perform final assembly and testing of finished products. These outsourcing partners acquire components and build product based on demand information supplied by the Company, which typically covers periods up to 150 days. The Company also obtains individual components for its products from a wide variety of individual suppliers. Consistent with industry practice, the Company acquires components through a combination of purchase orders, supplier contracts, and open orders based on projected demand information. Where appropriate, the purchases are applied to inventory component prepayments that are outstanding with the respective supplier. As of June 25, 2016, the Company had outstanding off-balance sheet third-party manufacturing commitments and component purchase commitments of $21.0 billion.

[0001628280-16-017809:mdna:124]
[same as prior period, unchanged from 0001193125-16-559625:mdna:118]

[0001628280-16-017809:mdna:125]
In addition to the commitments mentioned above, the Company had other off-balance sheet obligations of $6.2 billion as of June 25, 2016 that consisted of commitments to acquire capital assets, including product tooling and manufacturing process equipment, and commitments related to advertising, licensing, R&D, internet and telecommunications services, energy and other obligations.

[0001628280-16-017809:mdna:126]
The Company’s other non-current liabilities in the Condensed Consolidated Balance Sheets consist primarily of deferred tax liabilities, gross unrecognized tax benefits and the related gross interest and penalties. As of June 25, 2016, the Company had non-current deferred tax liabilities of $24.6 billion. Additionally, as of June 25, 2016, the Company had gross unrecognized tax benefits of $7.6 billion and an additional $1.5 billion for gross interest and penalties classified as non-current liabilities. At this time, the Company is unable to make a reasonably reliable estimate of the timing of payments due to uncertainties in the timing of tax audit outcomes.

[0001628280-16-017809:mdna:127]
[same as prior period, unchanged from 0001193125-16-559625:mdna:121]

[0001628280-16-017809:mdna:128]
The Company generally does not indemnify end-users of its operating system and application software against legal claims that the software infringes third-party intellectual property rights. Other agreements entered into by the Company sometimes include indemnification provisions under which the Company could be subject to costs and/or damages in the event of an infringement claim against the Company or an indemnified third-party. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss with respect to indemnification of end-users of its operating system or application software for infringement of third-party intellectual property rights.

[0001628280-16-017809:mdna:129]
The Company offers an iPhone Upgrade Program, which is available to customers who purchase an iPhone 6s and 6s Plus in its U.S. retail and online stores and activate the purchased iPhone with one of the four U.S. national carriers. The iPhone Upgrade Program provides customers the right to trade in that iPhone for a new iPhone, provided certain conditions are met. One of the conditions of this program requires the customer to finance the initial purchase price of the iPhone with a third-party lender. Upon exercise of the trade-in right and purchase of a new iPhone, the Company satisfies the customer’s outstanding balance due to the third-party lender on the original device. The Company accounts for the trade-in right as a guarantee liability and recognizes arrangement revenue net of the fair value of such right with subsequent changes to the guarantee liability recognized within revenue.

[0001628280-16-017809:mdna:130]
The Company has entered into indemnification agreements with its directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, the Company maintains directors and officers liability insurance coverage to reduce its exposure to such obligations.

[0001628280-16-017809:mdna:131]
[same as prior period, unchanged from 0001193125-16-559625:mdna:125]

[0001628280-16-017809:mdna:132]
The preparation of financial statements and related disclosures in conformity with U.S. generally accepted accounting principles and the Company’s discussion and analysis of its financial condition and operating results require the Company’s management to make judgments, assumptions and estimates that affect the amounts reported in its condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and on various other assumptions it believes to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities. Actual results may differ from these estimates, and such differences may be material.

[0001628280-16-017809:mdna:133]
Note 1, “Summary of Significant Accounting Policies” in Part I, Item 1 of this Form 10-Q and in the Notes to Consolidated Financial Statements in Part II, Item 8 of the 2015 Form 10-K, and “Critical Accounting Policies and Estimates” in Part I, Item 7 of the 2015 Form 10-K describe the significant accounting policies and methods used in the preparation of the Company’s condensed consolidated financial statements. There have been no material changes to the Company’s critical accounting policies and estimates since the 2015 Form 10-K.
