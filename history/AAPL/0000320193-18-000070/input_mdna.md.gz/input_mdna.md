# AAPL MD&A — 0000320193-18-000070


## mdna

[0000320193-18-000070:mdna:1]
[same as prior period, unchanged from 0000320193-18-000007:mdna:1]

[0000320193-18-000070:mdna:2]
[same as prior period, unchanged from 0000320193-18-000007:mdna:2]

[0000320193-18-000070:mdna:3]
The Company’s Annual Reports on Form 10-K, Quarterly Reports on Form 10-Q, Current Reports on Form 8-K, and amendments to reports filed pursuant to Sections 13(a) and 15(d) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), are filed with the SEC. The Company is subject to the informational requirements of the Exchange Act and files or furnishes reports, proxy statements, and other information with the SEC. Such reports and other information filed by the Company with the SEC are available free of charge on the Company’s website at investor.apple.com/sec.cfm when such reports are available on the SEC’s website. The public may read and copy any materials filed by the Company with the SEC at the SEC’s Public Reference Room at 100 F Street, NE, Room 1580, Washington, DC 20549. The public may obtain information on the operation of the Public Reference Room by calling the SEC at 1-800-SEC-0330. The SEC maintains an internet site that contains reports, proxy and information statements and other information regarding issuers that file electronically with the SEC at www.sec.gov. The information contained on the websites referenced in this Form 10-Q is not incorporated by reference into this filing. Further, the Company’s references to website URLs are intended to be inactive textual references only.

[0000320193-18-000070:mdna:4]
[same as prior period, unchanged from 0000320193-18-000007:mdna:4]

[0000320193-18-000070:mdna:5]
The Company designs, manufactures and markets mobile communication and media devices and personal computers, and sells a variety of related software, services, accessories, networking solutions and third-party digital content and applications. The Company’s products and services include iPhone, iPad, Mac, Apple Watch, AirPods, Apple TV, HomePod, a portfolio of consumer and professional software applications, iOS, macOS, watchOS and tvOS operating systems, iCloud, Apple Pay and a variety of other accessory, service and support offerings. The Company sells and delivers digital content and applications through the iTunes Store, App Store, Mac App Store, TV App Store, iBooks Store and Apple Music (collectively “Digital Content and Services”). The Company sells its products worldwide through its retail stores, online stores and direct sales force, as well as through third-party cellular network carriers, wholesalers, retailers and resellers. In addition, the Company sells a variety of third-party Apple-compatible products, including application software and various accessories through its retail and online stores. The Company sells to consumers, small and mid-sized businesses and education, enterprise and government customers.

[0000320193-18-000070:mdna:6]
[same as prior period, unchanged from 0000320193-18-000007:mdna:6]

[0000320193-18-000070:mdna:7]
[same as prior period, unchanged from 0000320193-18-000007:mdna:7]

[0000320193-18-000070:mdna:8]
[same as prior period, unchanged from 0000320193-18-000007:mdna:8]

[0000320193-18-000070:mdna:9]
[same as prior period, unchanged from 0000320193-18-000007:mdna:9]

[0000320193-18-000070:mdna:10]
[same as prior period, unchanged from 0000320193-18-000007:mdna:10]

[0000320193-18-000070:mdna:11]
[same as prior period, unchanged from 0000320193-18-000007:mdna:11]

[0000320193-18-000070:mdna:12]
Second Quarter Fiscal 2018 Highlights

[0000320193-18-000070:mdna:13]
Net sales increased 16% or $8.2 billion during the second quarter of 2018 compared to the same quarter in 2017, primarily driven by higher net sales of iPhone, Services and Other Products. Year-over-year net sales increased in each of the geographic reportable segments. Additionally, the strength in foreign currencies relative to the U.S. dollar had a favorable impact on net sales during the second quarter of 2018 compared to the same quarter in 2017.

[0000320193-18-000070:mdna:14]
The Company began shipping HomePod in February 2018. In March 2018, the Company introduced a new 9.7-inch iPad with Apple Pencil® compatibility, which began shipping at the end of the second quarter of 2018.

[0000320193-18-000070:mdna:15]
The Company spent $23.5 billion to repurchase shares of its common stock and paid dividends and dividend equivalents of $3.2 billion during the second quarter of 2018.

[0000320193-18-000070:mdna:16]
[same as prior period, unchanged from 0000320193-18-000007:mdna:15]

[0000320193-18-000070:mdna:17]
The following table shows net sales by reportable segment and net sales and unit sales by product for the three- and six-month periods ended March 31, 2018 and April 1, 2017 (dollars in millions and units in thousands):

[0000320193-18-000070:mdna:18]
|  | Three Months Ended |  | Six Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | Change |  | March 31, 2018 |  | April 1, 2017 |  | Change |
| Net Sales by Reportable Segment: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 24,841 |  |  | $ | 21,157 |  |  | 17 | % |  | $ | 60,034 |  |  | $ | 53,125 |  |  | 13 | % |
| Europe | 13,846 |  |  | 12,733 |  |  | 9 | % |  | 34,900 |  |  | 31,254 |  |  | 12 | % |
| Greater China | 13,024 |  |  | 10,726 |  |  | 21 | % |  | 30,980 |  |  | 26,959 |  |  | 15 | % |
| Japan | 5,468 |  |  | 4,485 |  |  | 22 | % |  | 12,705 |  |  | 10,251 |  |  | 24 | % |
| Rest of Asia Pacific | 3,958 |  |  | 3,795 |  |  | 4 | % |  | 10,811 |  |  | 9,658 |  |  | 12 | % |
| Total net sales | $ | 61,137 |  |  | $ | 52,896 |  |  | 16 | % |  | $ | 149,430 |  |  | $ | 131,247 |  |  | 14 | % |
| Net Sales by Product: |  |  |  |  |  |  |  |  |  |  |  |
| iPhone (1) | $ | 38,032 |  |  | $ | 33,249 |  |  | 14 | % |  | $ | 99,608 |  |  | $ | 87,627 |  |  | 14 | % |
| iPad (1) | 4,113 |  |  | 3,889 |  |  | 6 | % |  | 9,975 |  |  | 9,422 |  |  | 6 | % |
| Mac (1) | 5,848 |  |  | 5,844 |  |  | — | % |  | 12,743 |  |  | 13,088 |  |  | (3 | )% |
| Services (2) | 9,190 |  |  | 7,041 |  |  | 31 | % |  | 17,661 |  |  | 14,213 |  |  | 24 | % |
| Other Products (1)(3) | 3,954 |  |  | 2,873 |  |  | 38 | % |  | 9,443 |  |  | 6,897 |  |  | 37 | % |
| Total net sales | $ | 61,137 |  |  | $ | 52,896 |  |  | 16 | % |  | $ | 149,430 |  |  | $ | 131,247 |  |  | 14 | % |
| Unit Sales by Product: |  |  |  |  |  |  |  |  |  |  |  |
| iPhone | 52,217 |  |  | 50,763 |  |  | 3 | % |  | 129,533 |  |  | 129,053 |  |  | — | % |
| iPad | 9,113 |  |  | 8,922 |  |  | 2 | % |  | 22,283 |  |  | 22,003 |  |  | 1 | % |
| Mac | 4,078 |  |  | 4,199 |  |  | (3 | )% |  | 9,190 |  |  | 9,573 |  |  | (4 | )% |

[0000320193-18-000070:mdna:19]
[same as prior period, unchanged from 0000320193-18-000007:mdna:18]

[0000320193-18-000070:mdna:20]
[same as prior period, unchanged from 0000320193-18-000007:mdna:19]

[0000320193-18-000070:mdna:21]
| (3) | Includes sales of AirPods, Apple TV, Apple Watch, Beats® products, HomePod, iPod touch and other Apple-branded and third-party accessories. |

[0000320193-18-000070:mdna:22]
[same as prior period, unchanged from 0000320193-18-000007:mdna:21]

[0000320193-18-000070:mdna:23]
[same as prior period, unchanged from 0000320193-18-000007:mdna:22]

[0000320193-18-000070:mdna:24]
The following table presents iPhone net sales and unit sales information for the three- and six-month periods ended March 31, 2018 and April 1, 2017 (dollars in millions and units in thousands):

[0000320193-18-000070:mdna:25]
|  | Three Months Ended |  | Six Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | Change |  | March 31, 2018 |  | April 1, 2017 |  | Change |
| Net sales | $ | 38,032 |  |  | $ | 33,249 |  |  | 14 | % |  | $ | 99,608 |  |  | $ | 87,627 |  |  | 14 | % |
| Percentage of total net sales | 62 | % |  | 63 | % |  |  |  | 67 | % |  | 67 | % |  |  |
| Unit sales | 52,217 |  |  | 50,763 |  |  | 3 | % |  | 129,533 |  |  | 129,053 |  |  | — | % |

[0000320193-18-000070:mdna:26]
iPhone net sales increased during the second quarter and first six months of 2018 compared to the same periods in 2017 due primarily to a different mix of iPhones with higher average selling prices.

[0000320193-18-000070:mdna:27]
[same as prior period, unchanged from 0000320193-18-000007:mdna:26]

[0000320193-18-000070:mdna:28]
The following table presents iPad net sales and unit sales information for the three- and six-month periods ended March 31, 2018 and April 1, 2017 (dollars in millions and units in thousands):

[0000320193-18-000070:mdna:29]
|  | Three Months Ended |  | Six Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | Change |  | March 31, 2018 |  | April 1, 2017 |  | Change |
| Net sales | $ | 4,113 |  |  | $ | 3,889 |  |  | 6 | % |  | $ | 9,975 |  |  | $ | 9,422 |  |  | 6 | % |
| Percentage of total net sales | 7 | % |  | 7 | % |  |  |  | 7 | % |  | 7 | % |  |  |
| Unit sales | 9,113 |  |  | 8,922 |  |  | 2 | % |  | 22,283 |  |  | 22,003 |  |  | 1 | % |

[0000320193-18-000070:mdna:30]
iPad net sales increased during the second quarter and first six months of 2018 compared to the same periods in 2017 due primarily to a different mix of iPads with higher average selling prices.

[0000320193-18-000070:mdna:31]
[same as prior period, unchanged from 0000320193-18-000007:mdna:30]

[0000320193-18-000070:mdna:32]
The following table presents Mac net sales and unit sales information for the three- and six-month periods ended March 31, 2018 and April 1, 2017 (dollars in millions and units in thousands):

[0000320193-18-000070:mdna:33]
|  | Three Months Ended |  | Six Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | Change |  | March 31, 2018 |  | April 1, 2017 |  | Change |
| Net sales | $ | 5,848 |  |  | $ | 5,844 |  |  | — | % |  | $ | 12,743 |  |  | $ | 13,088 |  |  | (3 | )% |
| Percentage of total net sales | 10 | % |  | 11 | % |  |  |  | 9 | % |  | 10 | % |  |  |
| Unit sales | 4,078 |  |  | 4,199 |  |  | (3 | )% |  | 9,190 |  |  | 9,573 |  |  | (4 | )% |

[0000320193-18-000070:mdna:34]
Mac net sales were flat during the second quarter of 2018 and declined during the first six months of 2018 compared to the same periods in 2017 due primarily to lower Mac unit sales. The MacBook Pro® launch during the first quarter of 2017 had a positive impact on the results during the first six months of 2017. The strength in foreign currencies relative to the U.S. dollar had a favorable impact on Mac net sales during the second quarter and first six months of 2018.

[0000320193-18-000070:mdna:35]
[same as prior period, unchanged from 0000320193-18-000007:mdna:34]

[0000320193-18-000070:mdna:36]
The following table presents Services net sales information for the three- and six-month periods ended March 31, 2018 and April 1, 2017 (dollars in millions):

[0000320193-18-000070:mdna:37]
|  | Three Months Ended |  | Six Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | Change |  | March 31, 2018 |  | April 1, 2017 |  | Change |
| Net sales | $ | 9,190 |  |  | $ | 7,041 |  |  | 31 | % |  | $ | 17,661 |  |  | $ | 14,213 |  |  | 24 | % |
| Percentage of total net sales | 15 | % |  | 13 | % |  |  |  | 12 | % |  | 11 | % |  |  |

[0000320193-18-000070:mdna:38]
Services net sales increased during the second quarter of 2018 compared to the same period in 2017 due primarily to licensing, App Store and AppleCare. Year-over-year growth in Services net sales during the first six months of 2018 was due primarily to licensing, App Store and iCloud.

[0000320193-18-000070:mdna:39]
[same as prior period, unchanged from 0000320193-18-000007:mdna:38]

[0000320193-18-000070:mdna:40]
The Company manages its business primarily on a geographic basis. The Company’s reportable segments consist of the Americas, Europe, Greater China, Japan and Rest of Asia Pacific. Americas includes both North and South America. Europe includes European countries, as well as India, the Middle East and Africa. Greater China includes China, Hong Kong and Taiwan. Rest of Asia Pacific includes Australia and those Asian countries not included in the Company’s other reportable segments. Although the reportable segments provide similar hardware and software products and similar services, each one is managed separately to better align with the location of the Company’s customers and distribution partners and the unique market dynamics of each geographic region. Further information regarding the Company’s reportable segments can be found in Part I, Item 1 of this Form 10-Q in the Notes to Condensed Consolidated Financial Statements in Note 10, “Segment Information and Geographic Data.”

[0000320193-18-000070:mdna:41]
[same as prior period, unchanged from 0000320193-18-000007:mdna:40]

[0000320193-18-000070:mdna:42]
The following table presents Americas net sales information for the three- and six-month periods ended March 31, 2018 and April 1, 2017 (dollars in millions):

[0000320193-18-000070:mdna:43]
|  | Three Months Ended |  | Six Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | Change |  | March 31, 2018 |  | April 1, 2017 |  | Change |
| Net sales | $ | 24,841 |  |  | $ | 21,157 |  |  | 17 | % |  | $ | 60,034 |  |  | $ | 53,125 |  |  | 13 | % |
| Percentage of total net sales | 41 | % |  | 40 | % |  |  |  | 40 | % |  | 40 | % |  |  |

[0000320193-18-000070:mdna:44]
Americas net sales increased during the second quarter and first six months of 2018 compared to the same periods in 2017 due primarily to higher net sales of iPhone, Services and Other Products.

[0000320193-18-000070:mdna:45]
[same as prior period, unchanged from 0000320193-18-000007:mdna:44]

[0000320193-18-000070:mdna:46]
The following table presents Europe net sales information for the three- and six-month periods ended March 31, 2018 and April 1, 2017 (dollars in millions):

[0000320193-18-000070:mdna:47]
|  | Three Months Ended |  | Six Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | Change |  | March 31, 2018 |  | April 1, 2017 |  | Change |
| Net sales | $ | 13,846 |  |  | $ | 12,733 |  |  | 9 | % |  | $ | 34,900 |  |  | $ | 31,254 |  |  | 12 | % |
| Percentage of total net sales | 23 | % |  | 24 | % |  |  |  | 23 | % |  | 24 | % |  |  |

[0000320193-18-000070:mdna:48]
The strength in foreign currencies relative to the U.S. dollar had a favorable impact on Europe net sales during the second quarter and first six months of 2018 compared to the same periods in 2017. Additionally, year-over-year Europe net sales increased during the first six months of 2018 due primarily to higher net sales of iPhone and Services.

[0000320193-18-000070:mdna:49]
[same as prior period, unchanged from 0000320193-18-000007:mdna:48]

[0000320193-18-000070:mdna:50]
The following table presents Greater China net sales information for the three- and six-month periods ended March 31, 2018 and April 1, 2017 (dollars in millions):

[0000320193-18-000070:mdna:51]
|  | Three Months Ended |  | Six Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | Change |  | March 31, 2018 |  | April 1, 2017 |  | Change |
| Net sales | $ | 13,024 |  |  | $ | 10,726 |  |  | 21 | % |  | $ | 30,980 |  |  | $ | 26,959 |  |  | 15 | % |
| Percentage of total net sales | 21 | % |  | 20 | % |  |  |  | 21 | % |  | 21 | % |  |  |

[0000320193-18-000070:mdna:52]
Greater China net sales increased during the second quarter and first six months of 2018 compared to the same periods in 2017 due primarily to higher net sales of iPhone and the strength in foreign currencies relative to the U.S. dollar.

[0000320193-18-000070:mdna:53]
[same as prior period, unchanged from 0000320193-18-000007:mdna:52]

[0000320193-18-000070:mdna:54]
The following table presents Japan net sales information for the three- and six-month periods ended March 31, 2018 and April 1, 2017 (dollars in millions):

[0000320193-18-000070:mdna:55]
|  | Three Months Ended |  | Six Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | Change |  | March 31, 2018 |  | April 1, 2017 |  | Change |
| Net sales | $ | 5,468 |  |  | $ | 4,485 |  |  | 22 | % |  | $ | 12,705 |  |  | $ | 10,251 |  |  | 24 | % |
| Percentage of total net sales | 9 | % |  | 8 | % |  |  |  | 9 | % |  | 8 | % |  |  |

[0000320193-18-000070:mdna:56]
Japan net sales increased during the second quarter and first six months of 2018 compared to the same periods in 2017 due primarily to higher net sales of iPhone and Services. Additionally, the value of the Japanese Yen relative to the U.S. dollar had a favorable impact on Japan net sales during the second quarter of 2018 and an unfavorable impact during the first six months of 2018.

[0000320193-18-000070:mdna:57]
[same as prior period, unchanged from 0000320193-18-000007:mdna:56]

[0000320193-18-000070:mdna:58]
The following table presents Rest of Asia Pacific net sales information for the three- and six-month periods ended March 31, 2018 and April 1, 2017 (dollars in millions):

[0000320193-18-000070:mdna:59]
|  | Three Months Ended |  | Six Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | Change |  | March 31, 2018 |  | April 1, 2017 |  | Change |
| Net sales | $ | 3,958 |  |  | $ | 3,795 |  |  | 4 | % |  | $ | 10,811 |  |  | $ | 9,658 |  |  | 12 | % |
| Percentage of total net sales | 6 | % |  | 7 | % |  |  |  | 7 | % |  | 7 | % |  |  |

[0000320193-18-000070:mdna:60]
The strength in foreign currencies relative to the U.S. dollar had a favorable impact on Rest of Asia Pacific net sales during the second quarter and first six months of 2018 compared to the same periods in 2017. Additionally, year-over-year Rest of Asia Pacific net sales increased during the first six months of 2018 due primarily to higher net sales of iPhone and Services.

[0000320193-18-000070:mdna:61]
[same as prior period, unchanged from 0000320193-18-000007:mdna:60]

[0000320193-18-000070:mdna:62]
Gross margin for the three- and six-month periods ended March 31, 2018 and April 1, 2017 was as follows (dollars in millions):

[0000320193-18-000070:mdna:63]
|  | Three Months Ended |  | Six Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |
| Net sales | $ | 61,137 |  |  | $ | 52,896 |  |  | $ | 149,430 |  |  | $ | 131,247 |  |
| Cost of sales | 37,715 |  |  | 32,305 |  |  | 92,096 |  |  | 80,480 |  |
| Gross margin | $ | 23,422 |  |  | $ | 20,591 |  |  | $ | 57,334 |  |  | $ | 50,767 |  |
| Gross margin percentage | 38.3 | % |  | 38.9 | % |  | 38.4 | % |  | 38.7 | % |

[0000320193-18-000070:mdna:64]
Gross margin increased during the second quarter and first six months of 2018 compared to the same periods in 2017 due primarily to a favorable shift in mix of products and Services, partially offset by higher product cost structures. Additionally, to a lesser extent the strength in foreign currencies relative to the U.S. dollar had a favorable impact on gross margin.

[0000320193-18-000070:mdna:65]
Gross margin percentage decreased during the second quarter and first six months of 2018 compared to the same periods in 2017 due primarily to higher product cost structures, partially offset by a favorable shift in mix of products and Services. Additionally, to a lesser extent the strength in foreign currencies relative to the U.S. dollar had a favorable impact on gross margin percentage.

[0000320193-18-000070:mdna:66]
The Company anticipates gross margin percentage during the third quarter of 2018 to be between 38.0% and 38.5%. The foregoing statement regarding the Company’s expected gross margin percentage in the third quarter of 2018 is forward-looking and could differ from actual results. The Company’s future gross margins can be impacted by multiple factors including, but not limited to, those set forth in Part II, Item 1A of this Form 10-Q under the heading “Risk Factors” and those described in this paragraph. In general, the Company believes gross margins will remain under downward pressure due to a variety of factors, including: continued industry-wide global product pricing pressures; increased competition; the Company’s ability to effectively stimulate demand for certain of its products; compressed product life cycles; product transitions; potential increases in the cost of components and outside manufacturing services; the Company’s ability to manage product quality and warranty costs effectively; and a potential shift in the Company’s sales mix towards products with lower gross margins. In response to competitive pressures, the Company expects it will continue to take product pricing actions, which would adversely affect gross margins. Due to the Company’s significant international operations, its financial condition and operating results, including gross margins, could be significantly affected by fluctuations in exchange rates.

[0000320193-18-000070:mdna:67]
[same as prior period, unchanged from 0000320193-18-000007:mdna:65]

[0000320193-18-000070:mdna:68]
Operating expenses for the three- and six-month periods ended March 31, 2018 and April 1, 2017 were as follows (dollars in millions):

[0000320193-18-000070:mdna:69]
|  | Three Months Ended |  | Six Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |
| Research and development | $ | 3,378 |  |  | $ | 2,776 |  |  | $ | 6,785 |  |  | $ | 5,647 |  |
| Percentage of total net sales | 6 | % |  | 5 | % |  | 5 | % |  | 4 | % |
| Selling, general and administrative | $ | 4,150 |  |  | $ | 3,718 |  |  | $ | 8,381 |  |  | $ | 7,664 |  |
| Percentage of total net sales | 7 | % |  | 7 | % |  | 6 | % |  | 6 | % |
| Total operating expenses | $ | 7,528 |  |  | $ | 6,494 |  |  | $ | 15,166 |  |  | $ | 13,311 |  |
| Percentage of total net sales | 12 | % |  | 12 | % |  | 10 | % |  | 10 | % |

[0000320193-18-000070:mdna:70]
[same as prior period, unchanged from 0000320193-18-000007:mdna:68]

[0000320193-18-000070:mdna:71]
The growth in R&D expense during the second quarter and first six months of 2018 compared to the same periods in 2017 was driven primarily by increases in headcount-related expenses and material costs to support expanded R&D activities. The Company continues to believe that focused investments in R&D are critical to its future growth and competitive position in the marketplace, and to the development of new and updated products and services that are central to the Company’s core business strategy.

[0000320193-18-000070:mdna:72]
[same as prior period, unchanged from 0000320193-18-000007:mdna:70]

[0000320193-18-000070:mdna:73]
The growth in selling, general and administrative expense during the second quarter and first six months of 2018 compared to the same periods in 2017 was driven primarily by increases in headcount-related expenses and infrastructure-related costs.

[0000320193-18-000070:mdna:74]
[same as prior period, unchanged from 0000320193-18-000007:mdna:72]

[0000320193-18-000070:mdna:75]
Other income/(expense), net for the three- and six-month periods ended March 31, 2018 and April 1, 2017 was as follows (dollars in millions):

[0000320193-18-000070:mdna:76]
|  | Three Months Ended |  | Six Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | Change |  | March 31, 2018 |  | April 1, 2017 |  | Change |
| Interest and dividend income | $ | 1,505 |  |  | $ | 1,282 |  |  |  |  | $ | 2,957 |  |  | $ | 2,506 |  |  |  |
| Interest expense | (792 | ) |  | (530 | ) |  |  |  | (1,526 | ) |  | (1,055 | ) |  |  |
| Other expense, net | (439 | ) |  | (165 | ) |  |  |  | (401 | ) |  | (43 | ) |  |  |
| Total other income/(expense), net | $ | 274 |  |  | $ | 587 |  |  | (53 | )% |  | $ | 1,030 |  |  | $ | 1,408 |  |  | (27 | )% |

[0000320193-18-000070:mdna:77]
The decrease in other income/(expense), net during the second quarter and first six months of 2018 compared to the same periods in 2017 was due primarily to the impact of foreign exchange–related items and higher interest expense on debt, partially offset by higher interest income. Additionally, the decrease in other income/(expense), net during the first six months of 2018 was partially offset by realized gains on sales of marketable securities. The weighted-average interest rate earned by the Company on its cash, cash equivalents and marketable securities was 2.14% and 1.99% in the second quarter of 2018 and 2017, respectively, and 2.12% and 1.93% in the first six months of 2018 and 2017, respectively.

[0000320193-18-000070:mdna:78]
[same as prior period, unchanged from 0000320193-18-000007:mdna:76]

[0000320193-18-000070:mdna:79]
Provision for income taxes and effective tax rates for the three- and six-month periods ended March 31, 2018 and April 1, 2017 were as follows (dollars in millions):

[0000320193-18-000070:mdna:80]
|  | Three Months Ended |  | Six Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |
| Provision for income taxes | $ | 2,346 |  |  | $ | 3,655 |  |  | $ | 9,311 |  |  | $ | 9,944 |  |
| Effective tax rate | 14.5 | % |  | 24.9 | % |  | 21.6 | % |  | 25.6 | % |

[0000320193-18-000070:mdna:81]
On December 22, 2017, the U.S. enacted the Tax Cuts and Jobs Act (the “Act”), which significantly changed U.S. tax law. The Act lowered the Company’s U.S. statutory federal income tax rate from 35% to 21% effective January 1, 2018, while also imposing a deemed repatriation tax on previously deferred foreign income. By operation of law, the Company will apply a blended U.S. statutory federal income tax rate of 24.5% for 2018 (the “2018 blended U.S. tax rate”). The Act also created a new minimum tax on certain future foreign earnings.

[0000320193-18-000070:mdna:82]
The Company’s effective tax rate of 14.5% for the second quarter of 2018 was lower than the 2018 blended U.S. tax rate due primarily to the lower tax rate on foreign earnings. The Company’s effective tax rate of 21.6% for the first six months of 2018 was lower than the 2018 blended U.S. tax rate due primarily to the lower tax rate on foreign earnings, partially offset by the remeasurement of deferred tax assets and liabilities as a result of the Act.

[0000320193-18-000070:mdna:83]
The Company’s effective tax rate of 14.5% for the second quarter of 2018 was lower than the same period in 2017 due to the lower 2018 blended U.S. tax rate as a result of the Act. The Company’s effective tax rate of 21.6% for the first six months of 2018 was lower than the same period in 2017 due to the lower 2018 blended U.S. tax rate, partially offset by the remeasurement of deferred tax assets and liabilities as a result of the Act.

[0000320193-18-000070:mdna:84]
As a result of adopting Accounting Standards Update (“ASU”) No. 2016-09, Compensation – Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting, in 2018, the Company records any excess tax benefits or deficiencies from its equity awards as part of the provision for income taxes. The Company anticipates that these excess tax benefits or deficiencies will have the greatest impact on its effective tax rates in the first and third quarters, as the majority of the Company’s equity awards vest in those quarters.

[0000320193-18-000070:mdna:85]
[same as prior period, unchanged from 0000320193-18-000007:mdna:83]

[0000320193-18-000070:mdna:86]
On August 30, 2016, the European Commission announced its decision that Ireland granted state aid to the Company by providing tax opinions in 1991 and 2007 concerning the tax allocation of profits of the Irish branches of two subsidiaries of the Company (the “State Aid Decision”). The State Aid Decision orders Ireland to calculate and recover additional taxes from the Company for the period June 2003 through December 2014. Irish legislative changes, effective as of January 2015, eliminated the application of the tax opinions from that date forward. The Company believes the State Aid Decision to be without merit and appealed to the General Court of the Court of Justice of the European Union. Ireland has also appealed the State Aid Decision. Although Ireland is still computing the recovery amount, the Company expects the amount to be in line with the European Commission’s announced recovery amount of €13 billion, plus interest of €1 billion. During the third quarter of 2018, the Company expects to begin funding amounts into escrow, where they will remain pending conclusion of all appeals. The Company believes that any incremental Irish corporate income taxes potentially due related to the State Aid Decision would be creditable against U.S. taxes.

[0000320193-18-000070:mdna:87]
[same as prior period, unchanged from 0000320193-18-000007:mdna:85]

[0000320193-18-000070:mdna:88]
[same as prior period, unchanged from 0000320193-18-000007:mdna:86]

[0000320193-18-000070:mdna:89]
In August 2017, the Financial Accounting Standards Board (the “FASB”) issued ASU No. 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities (“ASU 2017-12”). ASU 2017-12 expands component and fair value hedging, specifies the presentation of the effects of hedging instruments, and eliminates the separate measurement and presentation of hedge ineffectiveness. The Company will adopt ASU 2017-12 in its first quarter of 2020 utilizing the modified retrospective transition method and is currently evaluating the impact of adoption on its consolidated financial statements.

[0000320193-18-000070:mdna:90]
[same as prior period, unchanged from 0000320193-18-000007:mdna:88]

[0000320193-18-000070:mdna:91]
In November 2016, the FASB issued ASU No. 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash (“ASU 2016-18”), which enhances and clarifies the guidance on the classification and presentation of restricted cash in the statement of cash flows. The Company will adopt ASU 2016-18 in its first quarter of 2019 utilizing the retrospective transition method. Currently, the Company’s restricted cash balance is not significant.

[0000320193-18-000070:mdna:92]
[same as prior period, unchanged from 0000320193-18-000007:mdna:90]

[0000320193-18-000070:mdna:93]
In October 2016, the FASB issued ASU No. 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory (“ASU 2016-16”), which requires the recognition of the income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. The Company will adopt ASU 2016-16 in its first quarter of 2019 utilizing the modified retrospective transition method. Currently, the Company estimates recording up to $4 billion of net deferred tax assets on its Condensed Consolidated Balance Sheets upon adoption. However, the ultimate impact of adopting ASU 2016-16 will depend on the balance of intellectual property transferred between its subsidiaries as of the adoption date, as well as the deferred tax impact of the new minimum tax on certain future foreign earnings. The Company will recognize incremental deferred income tax expense thereafter as these net deferred tax assets are utilized.

[0000320193-18-000070:mdna:94]
[same as prior period, unchanged from 0000320193-18-000007:mdna:92]

[0000320193-18-000070:mdna:95]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842) (“ASU 2016-02”), which modifies lease accounting for lessees to increase transparency and comparability by recording lease assets and liabilities for operating leases and disclosing key information about leasing arrangements. The Company will adopt ASU 2016-02 in its first quarter of 2020 utilizing the modified retrospective transition method. While the Company is currently evaluating the impact of adopting ASU 2016-02, based on the lease portfolio as of March 31, 2018, the Company anticipates recording lease assets and liabilities of approximately $9.0 billion on its Condensed Consolidated Balance Sheets, with no material impact to its Condensed Consolidated Statements of Operations. However, the ultimate impact of adopting ASU 2016-02 will depend on the Company’s lease portfolio as of the adoption date.

[0000320193-18-000070:mdna:96]
[same as prior period, unchanged from 0000320193-18-000007:mdna:94]

[0000320193-18-000070:mdna:97]
In January 2016, the FASB issued ASU No. 2016-01, Financial Instruments – Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities (“ASU 2016-01”), which updates certain aspects of recognition, measurement, presentation and disclosure of financial instruments. The Company will adopt ASU 2016-01 in its first quarter of 2019 utilizing the modified retrospective transition method. Based on the composition of the Company’s investment portfolio, the adoption of ASU 2016-01 is not expected to have a material impact on its consolidated financial statements.

[0000320193-18-000070:mdna:98]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (“ASU 2016-13”), which modifies the measurement of expected credit losses of certain financial instruments. The Company will adopt ASU 2016-13 in its first quarter of 2021 utilizing the modified retrospective transition method. Based on the composition of the Company’s investment portfolio, current market conditions, and historical credit loss activity, the adoption of ASU 2016-13 is not expected to have a material impact on its consolidated financial statements.

[0000320193-18-000070:mdna:99]
[same as prior period, unchanged from 0000320193-18-000007:mdna:97]

[0000320193-18-000070:mdna:100]
In May 2014, the FASB issued ASU No. 2014-09, Revenue from Contracts with Customers (Topic 606) (“ASU 2014-09”), which amends the existing accounting standards for revenue recognition. ASU 2014-09 is based on principles that govern the recognition of revenue at an amount an entity expects to be entitled when products are transferred to customers.

[0000320193-18-000070:mdna:101]
Subsequently, the FASB has issued the following standards related to ASU 2014-09: ASU No. 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (“ASU 2016-08”); ASU No. 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing (“ASU 2016-10”); ASU No. 2016-12, Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients (“ASU 2016-12”); and ASU No. 2016-20, Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers (“ASU 2016-20”). The Company must adopt ASU 2016-08, ASU 2016-10, ASU 2016-12 and ASU 2016-20 with ASU 2014-09 (collectively, the “new revenue standards”).

[0000320193-18-000070:mdna:102]
[same as prior period, unchanged from 0000320193-18-000007:mdna:100]

[0000320193-18-000070:mdna:103]
[same as prior period, unchanged from 0000320193-18-000007:mdna:101]

[0000320193-18-000070:mdna:104]
The following tables present selected financial information and statistics as of March 31, 2018 and September 30, 2017 and for the first six months of 2018 and 2017 (in millions):

[0000320193-18-000070:mdna:105]
|  | March 31, 2018 |  | September 30, 2017 |
| Cash, cash equivalents and marketable securities | $ | 267,226 |  |  | $ | 268,895 |  |
| Property, plant and equipment, net | $ | 35,077 |  |  | $ | 33,783 |  |
| Commercial paper | $ | 11,980 |  |  | $ | 11,977 |  |
| Total term debt | $ | 109,860 |  |  | $ | 103,703 |  |
| Working capital | $ | 40,733 |  |  | $ | 27,831 |  |

[0000320193-18-000070:mdna:106]
|  | Six Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |
| Cash generated by operating activities (1) | $ | 43,423 |  |  | $ | 39,804 |  |
| Cash generated by/(used in) investing activities | $ | 15,120 |  |  | $ | (33,324 | ) |
| Cash used in financing activities (1) | $ | (33,773 | ) |  | $ | (11,807 | ) |

[0000320193-18-000070:mdna:107]
| (1) | Refer to Note 1, “Summary of Significant Accounting Polices” in the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Form 10-Q for more information on the prior period reclassification related to the Company’s adoption of ASU 2016-09. |

[0000320193-18-000070:mdna:108]
[same as prior period, unchanged from 0000320193-18-000007:mdna:106]

[0000320193-18-000070:mdna:109]
In connection with the State Aid Decision, although Ireland is still computing the recovery amount, the Company expects the amount to be in line with the European Commission’s announced recovery amount of €13 billion, plus interest of €1 billion. During the third quarter of 2018, the Company expects to begin funding amounts into escrow, where they will remain pending conclusion of all appeals.

[0000320193-18-000070:mdna:110]
[same as prior period, unchanged from 0000320193-18-000007:mdna:108]

[0000320193-18-000070:mdna:111]
During the six months ended March 31, 2018, cash generated by operating activities of $43.4 billion was a result of $33.9 billion of net income and an increase in the net change in operating assets and liabilities of $35.8 billion, partially offset by non-cash adjustments to net income of $26.3 billion. Cash generated by investing activities of $15.1 billion during the six months ended March 31, 2018 consisted primarily of proceeds from sales or maturities of marketable securities, net of purchases, of $22.4 billion, partially offset by cash used to acquire property, plant and equipment of $7.0 billion. Cash used in financing activities of $33.8 billion during the six months ended March 31, 2018 consisted primarily of cash used to repurchase common stock of $32.9 billion and cash used to pay dividends and dividend equivalents of $6.5 billion, partially offset by proceeds from the issuance of term debt, net of $7.0 billion.

[0000320193-18-000070:mdna:112]
During the six months ended April 1, 2017, cash generated by operating activities of $39.8 billion was a result of $28.9 billion of net income, non-cash adjustments to net income of $10.4 billion and an increase in the net change in operating assets and liabilities of $479 million. Cash used in investing activities of $33.3 billion during the six months ended April 1, 2017 consisted primarily of cash used for purchases of marketable securities, net of sales and maturities, of $26.9 billion and cash used to acquire property, plant and equipment of $6.3 billion. Cash used in financing activities of $11.8 billion during the six months ended April 1, 2017 consisted primarily of cash used to repurchase common stock of $18.0 billion and cash used to pay dividends and dividend equivalents of $6.1 billion, partially offset by proceeds from the issuance of term debt, net of $11.0 billion and proceeds from commercial paper, net of $1.9 billion.

[0000320193-18-000070:mdna:113]
[same as prior period, unchanged from 0000320193-18-000007:mdna:111]

[0000320193-18-000070:mdna:114]
The Company’s capital expenditures were $5.8 billion during the first six months of 2018. The Company anticipates utilizing approximately $16.0 billion for capital expenditures during 2018, which includes product tooling and manufacturing process equipment; data centers; corporate facilities and infrastructure, including information systems hardware, software and enhancements; and retail store facilities.

[0000320193-18-000070:mdna:115]
[same as prior period, unchanged from 0000320193-18-000007:mdna:113]

[0000320193-18-000070:mdna:116]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses the net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of March 31, 2018, the Company had $12.0 billion of Commercial Paper outstanding, with a weighted-average interest rate of 1.68% and maturities generally less than nine months.

[0000320193-18-000070:mdna:117]
As of March 31, 2018, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $111.1 billion (collectively the “Notes”). During the second quarter of 2018, the Company repaid $500 million of its Notes. The Company has entered, and in the future may enter, into interest rate swaps to manage interest rate risk on the Notes. In addition, the Company has entered, and in the future may enter, into foreign currency swaps to manage foreign currency risk on the Notes.

[0000320193-18-000070:mdna:118]
Further information regarding the Company’s debt issuances and related hedging activity can be found in Part I, Item 1 of this Form 10-Q in the Notes to Condensed Consolidated Financial Statements in Note 2, “Financial Instruments” and Note 5, “Debt.”

[0000320193-18-000070:mdna:119]
[same as prior period, unchanged from 0000320193-18-000007:mdna:117]

[0000320193-18-000070:mdna:120]
As of March 31, 2018, the Company had an authorized capital return program of $300 billion, which included a share repurchase program of up to $210 billion of the Company’s common stock. As of March 31, 2018, $199.6 billion of the share repurchase program had been utilized.

[0000320193-18-000070:mdna:121]
The following table presents the Company’s dividends, dividend equivalents, share repurchases and net share settlement activity from the start of the capital return program in August 2012 through March 31, 2018 (in millions):

[0000320193-18-000070:mdna:122]
|  | Dividends andDividend Equivalents Paid |  | Accelerated ShareRepurchases |  | Open MarketShare Repurchases |  | Taxes Related to Settlement of Equity Awards |  | Total |
| Q2 2018 | $ | 3,190 |  |  | $ | — |  |  | $ | 23,500 |  |  | $ | 152 |  |  | $ | 26,842 |  |
| Q1 2018 | 3,339 |  |  | 5,000 |  |  | 5,109 |  |  | 1,038 |  |  | 14,486 |  |
| 2017 | 12,769 |  |  | 15,000 |  |  | 18,001 |  |  | 1,874 |  |  | 47,644 |  |
| 2016 | 12,150 |  |  | 12,000 |  |  | 17,000 |  |  | 1,570 |  |  | 42,720 |  |
| 2015 | 11,561 |  |  | 6,000 |  |  | 30,026 |  |  | 1,499 |  |  | 49,086 |  |
| 2014 | 11,126 |  |  | 21,000 |  |  | 24,000 |  |  | 1,158 |  |  | 57,284 |  |
| 2013 | 10,564 |  |  | 13,950 |  |  | 9,000 |  |  | 1,082 |  |  | 34,596 |  |
| 2012 | 2,488 |  |  | — |  |  | — |  |  | 56 |  |  | 2,544 |  |
| Total | $ | 67,187 |  |  | $ | 72,950 |  |  | $ | 126,636 |  |  | $ | 8,429 |  |  | $ | 275,202 |  |

[0000320193-18-000070:mdna:123]
On May 1, 2018, the Company announced that the Board of Directors had authorized a new program to repurchase up to $100 billion of the Company’s common stock. The Company’s share repurchase program does not obligate it to acquire any specific number of shares. Under the program, shares may be repurchased in privately negotiated and/or open market transactions, including under plans complying with Rule 10b5-1 under the Exchange Act. Additionally, the Company announced that the Board of Directors raised the Company’s quarterly cash dividend by 16% from $0.63 to $0.73 per share, beginning with the dividend to be paid during the third quarter of 2018. The Company intends to increase its dividend on an annual basis, subject to declaration by the Board of Directors. The Company plans to use current cash and cash generated from ongoing operating activities to fund its share repurchase program and quarterly cash dividend.

[0000320193-18-000070:mdna:124]
Off–Balance Sheet Arrangements and Contractual Obligations

[0000320193-18-000070:mdna:125]
[same as prior period, unchanged from 0000320193-18-000007:mdna:124]

[0000320193-18-000070:mdna:126]
[same as prior period, unchanged from 0000320193-18-000007:mdna:125]

[0000320193-18-000070:mdna:127]
As of March 31, 2018, the Company’s total future minimum lease payments under noncancelable operating leases were $9.8 billion. The Company’s retail store and other facility leases typically have original terms not exceeding 10 years and generally contain multi-year renewal options.

[0000320193-18-000070:mdna:128]
[same as prior period, unchanged from 0000320193-18-000007:mdna:127]

[0000320193-18-000070:mdna:129]
The Company utilizes several outsourcing partners to manufacture sub-assemblies for the Company’s products and to perform final assembly and testing of finished products. These outsourcing partners acquire components and build product based on demand information supplied by the Company, which typically covers periods up to 150 days. The Company also obtains individual components for its products from a wide variety of individual suppliers. As of March 31, 2018, the Company expects to pay $27.1 billion under manufacturing-related supplier arrangements, substantially all of which is noncancelable.

[0000320193-18-000070:mdna:130]
[same as prior period, unchanged from 0000320193-18-000007:mdna:129]

[0000320193-18-000070:mdna:131]
The Company’s other purchase obligations consist of noncancelable obligations to acquire capital assets, including product tooling and manufacturing process equipment, and noncancelable obligations related to advertising, licensing, R&D, internet and telecommunications services and other obligations. As of March 31, 2018, the Company had other purchase obligations of $8.6 billion.

[0000320193-18-000070:mdna:132]
[same as prior period, unchanged from 0000320193-18-000007:mdna:131]

[0000320193-18-000070:mdna:133]
The Company’s other non-current liabilities in the Condensed Consolidated Balance Sheets consist primarily of long-term taxes payable of $34.9 billion, and net unrecognized tax benefits and related interest and penalties of $7.5 billion. The Company plans to pay the tax payable in installments in accordance with the Act. The Company is unable to make a reasonably reliable estimate of the timing of payments related to unrecognized tax benefits due to uncertainties in the timing of tax audit outcomes.

[0000320193-18-000070:mdna:134]
[same as prior period, unchanged from 0000320193-18-000007:mdna:133]

[0000320193-18-000070:mdna:135]
[same as prior period, unchanged from 0000320193-18-000007:mdna:134]

[0000320193-18-000070:mdna:136]
[same as prior period, unchanged from 0000320193-18-000007:mdna:135]

[0000320193-18-000070:mdna:137]
The Company has entered into indemnification agreements with its directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers of the Company and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. While the Company maintains directors and officers liability insurance coverage, such insurance coverage may be insufficient to cover all losses or all types of claims that may arise.

[0000320193-18-000070:mdna:138]
[same as prior period, unchanged from 0000320193-18-000007:mdna:137]

[0000320193-18-000070:mdna:139]
[same as prior period, unchanged from 0000320193-18-000007:mdna:138]

[0000320193-18-000070:mdna:140]
[same as prior period, unchanged from 0000320193-18-000007:mdna:139]

[0000320193-18-000070:mdna:141]
[same as prior period, unchanged from 0000320193-18-000007:mdna:140]

[0000320193-18-000070:mdna:142]
The Company records a tax provision for the anticipated tax consequences of its reported operating results. The provision for income taxes is computed using the asset and liability method, under which deferred tax assets and liabilities are recognized for the expected future tax consequences of temporary differences between the financial reporting and tax bases of assets and liabilities, and for operating losses and tax credit carryforwards. Deferred tax assets and liabilities are measured using the currently enacted tax rates that will be in effect for the years in which those tax assets and liabilities are expected to be realized or settled. The Company records a valuation allowance to reduce deferred tax assets to the amount that is believed more likely than not to be realized.

[0000320193-18-000070:mdna:143]
[same as prior period, unchanged from 0000320193-18-000007:mdna:142]

[0000320193-18-000070:mdna:144]
[same as prior period, unchanged from 0000320193-18-000007:mdna:143]

[0000320193-18-000070:mdna:145]
On December 22, 2017, the U.S. enacted the Act, which significantly changed U.S. tax law. The Act lowered the Company’s U.S. statutory federal income tax rate from 35% to 21% effective January 1, 2018, while also imposing a deemed repatriation tax on previously deferred foreign income. The Act also created a new minimum tax on certain future foreign earnings. During the first six months of fiscal 2018, the Company recognized income tax expense of $9.3 billion, of which $2.6 billion was a provisional estimate in accordance with the SEC Staff Accounting Bulletin No. 118 and was recognized during the first quarter of 2018. This $2.6 billion provisional estimate included $1.8 billion related to the impact of remeasuring to reduce the Company’s deferred tax balances to reflect the new tax rate, and approximately $800 million associated with the net impact of the deemed repatriation tax. Resolution of the provisional estimates of the Act’s effects different from the assumptions made by the Company could have a material impact on the Company’s financial condition and operating results.
