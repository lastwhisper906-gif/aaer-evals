# AAPL 8-K — 0000320193-18-000067 filed 2018-05-01

## item codes, every 8-K on or before 2018-05-02

- 2018-05-01 0000320193-18-000067 — 2.02, 9.01
- 2018-02-14 0001193125-18-045761 — 5.07, 9.01
- 2018-02-01 0000320193-18-000005 — 2.02, 9.01
- 2017-11-13 0001193125-17-341015 — 8.01, 9.01
- 2017-11-02 0000320193-17-000067 — 2.02, 9.01
- 2017-10-12 0001193125-17-308859 — 5.02
- 2017-09-12 0001193125-17-282809 — 8.01, 9.01
- 2017-08-18 0001193125-17-262261 — 8.01, 9.01
- 2017-08-01 0000320193-17-000006 — 2.02, 9.01
- 2017-06-20 0001193125-17-208226 — 8.01, 9.01
- 2017-05-24 0001193125-17-181867 — 8.01, 9.01
- 2017-05-11 0001193125-17-167400 — 8.01, 9.01
- 2017-05-02 0001628280-17-004663 — 2.02, 9.01
- 2017-03-03 0001193125-17-069853 — 8.01, 9.01
- 2017-03-01 0001193125-17-064019 — 5.07
- 2017-02-09 0001193125-17-036283 — 8.01, 9.01
- 2017-01-31 0001628280-17-000663 — 2.02, 9.01
- 2016-12-15 0001628280-16-022047 — 5.03, 9.01
- 2016-10-25 0001628280-16-020258 — 2.02, 9.01
- 2016-08-04 0001193125-16-672044 — 8.01, 9.01
- 2016-07-26 0001628280-16-017762 — 2.02, 9.01
- 2016-06-22 0001193125-16-628957 — 8.01, 9.01
- 2016-04-26 0001193125-16-556520 — 2.02, 9.01
- 2016-03-24 0001193125-16-516891 — 8.01, 9.01
- 2016-03-01 0001193125-16-488223 — 5.02, 5.07, 9.01
- 2016-02-23 0001193125-16-473562 — 8.01, 9.01
- 2016-01-26 0001193125-16-438421 — 2.02, 9.01
- 2015-12-22 0001193125-15-410853 — 5.03, 9.01
- 2015-12-17 0001193125-15-406279 — 5.02
- 2015-10-27 0001193125-15-354756 — 2.02, 9.01
- 2015-10-02 0001193125-15-336615 — 5.02
- 2015-09-17 0001193125-15-322466 — 8.01, 9.01
- 2015-07-31 0001193125-15-273023 — 8.01, 9.01
- 2015-07-21 0001193125-15-258464 — 2.02, 9.01
- 2015-06-10 0001193125-15-219298 — 8.01, 9.01
- 2015-05-13 0001193125-15-186064 — 8.01, 9.01
- 2015-04-27 0001193125-15-149607 — 7.01, 9.01
- 2015-04-27 0001193125-15-149590 — 2.02, 9.01
- 2015-03-13 0001104659-15-019336 — 5.07, 9.01
- 2015-02-09 0001193125-15-039270 — 8.01, 9.01
- 2015-01-28 0001193125-15-023732 — 8.01, 9.01
- 2015-01-27 0001193125-15-021857 — 2.02, 9.01
- 2014-11-10 0001193125-14-406296 — 8.01, 9.01
- 2014-10-20 0001193125-14-376361 — 2.02, 9.01
- 2014-07-23 0001193125-14-277193 — 8.01, 9.01
- 2014-07-22 0001193125-14-275598 — 2.02, 9.01
- 2014-07-17 0001193125-14-271698 — 5.02
- 2014-06-06 0001193125-14-228798 — 5.03, 9.01
- 2014-05-30 0001181431-14-021923 — 5.02
- 2014-05-06 0001193125-14-184969 — 8.01, 9.01
- 2014-04-23 0001193125-14-154883 — 7.01, 9.01
- 2014-04-23 0001193125-14-154871 — 2.02, 9.01
- 2014-03-05 0001193125-14-084697 — 5.02, 5.03, 5.07, 9.01
- 2014-01-27 0001193125-14-022238 — 2.02, 9.01
- 2013-10-28 0001193125-13-413498 — 2.02, 9.01
- 2013-09-23 0001181431-13-050140 — 8.01
- 2013-07-30 0001181431-13-041847 — 5.02
- 2013-07-23 0001193125-13-298914 — 2.02, 9.01
- 2013-06-21 0001193125-13-267629 — 5.02
- 2013-05-03 0001193125-13-199324 — 8.01, 9.01
- 2013-04-24 0001193125-13-170623 — 8.01, 9.01
- 2013-04-23 0001193125-13-167469 — 7.01, 9.01
- 2013-04-23 0001193125-13-167458 — 2.02, 9.01
- 2013-03-01 0001193125-13-085842 — 5.07
- 2013-01-23 0001193125-13-020783 — 2.02, 9.01
- 2012-10-25 0001193125-12-435506 — 2.02, 9.01
- 2012-07-24 0001193125-12-312355 — 2.02, 9.01
- 2012-06-28 0001181431-12-038301 — 5.02
- 2012-05-24 0001181431-12-032458 — 5.02
- 2012-04-24 0001193125-12-178928 — 2.02, 9.01
- 2012-02-27 0001193125-12-081892 — 5.07
- 2012-01-24 0001193125-12-021833 — 2.02, 9.01
- 2011-11-16 0001181431-11-056354 — 5.02
- 2011-10-18 0001193125-11-273826 — 2.02, 9.01
- 2011-10-06 0001181431-11-051976 — 8.01
- 2011-08-26 0001181431-11-047179 — 5.02
- 2011-07-19 0001193125-11-191368 — 2.02, 9.01
- 2011-06-15 0001181431-11-036782 — 5.02
- 2011-04-20 0001193125-11-103732 — 2.02, 9.01
- 2011-02-24 0001193125-11-045411 — 5.07
- 2011-01-18 0001193125-11-009392 — 2.02, 9.01
- 2011-01-18 0001181431-11-003847 — 5.02
- 2010-11-17 0001181431-10-056327 — 5.02, 5.03, 9.01
- 2010-10-18 0001193125-10-230992 — 2.02, 9.01
- 2010-07-20 0001193125-10-161807 — 2.02, 9.01
- 2010-04-20 0001193125-10-087786 — 2.02, 9.01
- 2010-03-12 0001181431-10-016054 — 5.02
- 2010-03-01 0001193125-10-044765 — 5.02, 5.07, 9.01
- 2010-01-25 0001193125-10-012096 — 2.02, 9.01
- 2009-10-19 0001193125-09-209633 — 2.02, 9.01
- 2009-08-04 0001181431-09-037492 — 5.02
- 2009-07-21 0001193125-09-152290 — 2.02, 9.01
- 2009-06-02 0001181431-09-028400 — 5.03
- 2009-04-22 0001193125-09-084599 — 2.02, 9.01
- 2009-02-27 0001181431-09-012161 — 4.01
- 2009-01-21 0001193125-09-009009 — 2.02, 9.01
- 2009-01-16 0001181431-09-003017 — 5.02
- 2008-10-21 0001193125-08-213642 — 2.02, 9.01
- 2008-08-26 0001181431-08-050059 — 5.03
- 2008-07-21 0001193125-08-154381 — 2.02, 9.01
- 2008-06-09 0001181431-08-037620 — 8.01
- 2008-04-23 0001193125-08-088001 — 2.02, 9.01
- 2008-01-22 0001193125-08-009715 — 2.02, 9.01
- 2008-01-15 0001181431-08-003342 — 2.02, 8.01
- 2008-01-08 0001181431-08-002372 — 5.02
- 2007-10-22 0001104659-07-076142 — 2.02, 9.01
- 2007-07-25 0001104659-07-056111 — 2.02, 9.01
- 2007-05-16 0001104659-07-040672 — 5.02, 9.01
- 2007-04-25 0001104659-07-031354 — 2.02, 9.01
- 2007-04-24 0001104659-07-030938 — 8.01, 9.01
- 2007-02-21 0001104659-07-012760 — 5.03, 9.01
- 2007-01-17 0001104659-07-002905 — 2.02, 9.01
- 2007-01-10 0001104659-07-001648 — 5.03, 9.01
- 2006-10-27 0001104659-06-069015 — 8.01
- 2006-10-18 0001104659-06-067275 — 2.02, 9.01
- 2006-10-04 0001104659-06-064935 — 5.02, 8.01, 9.01
- 2006-09-01 0001104659-06-058808 — 1.01, 5.02, 5.03, 9.01
- 2006-08-11 0001104659-06-054118 — 2.02, 3.01, 9.01
- 2006-08-04 0001104659-06-051302 — 2.02, 4.02, 9.01
- 2006-07-19 0001104659-06-047739 — 2.02, 9.01
- 2006-04-21 0001181431-06-024759 — 1.01
- 2006-04-19 0001104659-06-025992 — 2.02, 9.01
- 2006-01-18 0001104659-06-002690 — 2.02, 9.01
- 2006-01-10 0001104659-06-001428 — 2.02
- 2005-12-19 0001181431-05-067468 — 1.01
- 2005-10-14 0001181431-05-056604 — 5.02
- 2005-10-11 0001104659-05-048094 — 2.02, 9.01
- 2005-08-26 0001181431-05-049163 — 1.01
- 2005-08-15 0001181431-05-046871 — 1.01
- 2005-07-13 0001104659-05-032297 — 2.02, 9.01
- 2005-06-06 0001181431-05-033177 — 8.01
- 2005-04-26 0001181431-05-023450 — 1.01
- 2005-04-13 0001104659-05-016307 — 2.02, 9.01
- 2005-03-02 0001181431-05-013840 — 3.03, 5.03
- 2005-02-11 0001104659-05-005507 — 8.01
- 2005-01-12 0001104659-05-001183 — 2.02, 9.01
- 2005-01-11 0001104659-05-001049 — 2.02
- 2004-10-13 0001104659-04-030400 — 2.02, 9.01
- 2004-07-14 0001104659-04-019574 — 12, 7
- 2004-04-14 0001104659-04-010122 — 12, 7
- 2004-01-14 0001104659-04-000896 — 12, 7
- 2003-10-15 0001104659-03-022879 — 12, 7
- 2003-07-16 0001104659-03-014913 — 7, 9
- 2003-04-16 0001047469-03-013617 — 7, 9
- 2003-03-21 0001104659-03-004649 — 5, 7
- 2002-08-13 0000912057-02-031595 — 5, 7
- 2002-08-05 0000912057-02-029692 — 5, 7
- 2000-01-24 0000912057-00-002128 — 5, 7
- 1999-09-07 0000320193-99-000010 — 2
- 1999-07-16 0000320193-99-000007 — 2
- 1998-12-23 0000320193-98-000010 — 1
- 1998-01-08 0000320193-98-000001 — 2
- 1997-09-25 0000320193-97-000019 — 2
- 1997-09-25 0000320193-97-000018 — 2
- 1997-09-05 0000320193-97-000016 — 2
- 1997-07-28 0000320193-97-000012 — 4
- 1997-04-25 0000320193-97-000009 — 5
- 1997-04-10 0000320193-97-000007 — 7
- 1996-12-24 0000320193-96-000027 — 7
- 1996-12-23 0000320193-96-000025 — 4 — amendment of 0000320193-96-000021
- 1996-12-13 0000320193-96-000021 — 4
- 1996-10-28 0000912057-96-023874 — 5, 7
- 1996-06-17 0000320193-96-000014 — 1
- 1996-04-12 0000320193-96-000006 — 1

## late-filing notifications on or before 2018-05-02

- 2006-12-15 0001104659-06-081617 — NT 10-K, for the period ended 2006-09-30
- 2006-08-11 0001104659-06-053743 — NT 10-Q, for the period ended 2006-07-01

## item 2.02 — earnings release, exhibit 99.1

[0000320193-18-000067:8k_2_02:1]
EX-99.1
2
a8-kexhibit991q220183312018.htm
EXHIBIT 99.1

[0000320193-18-000067:8k_2_02:2]
Exhibit

[0000320193-18-000067:8k_2_02:3]
Exhibit 99.1

[0000320193-18-000067:8k_2_02:4]
Apple Reports Second Quarter Results

[0000320193-18-000067:8k_2_02:5]
Revenue Grows 16 Percent and EPS Grows 30 Percent to New March Quarter Records

[0000320193-18-000067:8k_2_02:6]
New $100 Billion Share Repurchase Authorization Announced, Dividend Raised by 16 Percent

[0000320193-18-000067:8k_2_02:7]
CUPERTINO, California — May 1, 2018 — Apple® today announced financial results for its fiscal 2018 second quarter ended March 31, 2018. The Company posted quarterly revenue of $61.1 billion, an increase of 16 percent from the year-ago quarter, and quarterly earnings per diluted share of $2.73, up 30 percent. International sales accounted for 65 percent of the quarter’s revenue.

[0000320193-18-000067:8k_2_02:8]
“We’re thrilled to report our best March quarter ever, with strong revenue growth in iPhone, Services and Wearables,” said Tim Cook, Apple’s CEO. “Customers chose iPhone X more than any other iPhone each week in the March quarter, just as they did following its launch in the December quarter. We also grew revenue in all of our geographic segments, with over 20% growth in Greater China and Japan.”

[0000320193-18-000067:8k_2_02:9]
“Our business performed extremely well during the March quarter, as we grew earnings per share by 30 percent and generated over $15 billion in operating cash flow,” said Luca Maestri, Apple’s CFO. “With the greater flexibility we now have from access to our global cash, we can more efficiently invest in our US operations and work toward a more optimal capital structure. Given our confidence in Apple’s future, we are very happy to announce that our Board has approved a new $100 billion share repurchase authorization and a 16 percent increase in our quarterly dividend.”

[0000320193-18-000067:8k_2_02:10]
The Company will complete the execution of the previous $210 billion share repurchase authorization during the third fiscal quarter.

[0000320193-18-000067:8k_2_02:11]
Reflecting the approved increase, the Board has declared a cash dividend of $0.73 per share of Apple’s common stock payable on May 17, 2018 to shareholders of record as of the close of business on May 14, 2018.

[0000320193-18-000067:8k_2_02:12]
The Company also expects to continue to net-share-settle vesting restricted stock units.

[0000320193-18-000067:8k_2_02:13]
From the inception of its capital return program in August 2012 through March 2018, Apple has returned $275 billion to shareholders, including $200 billion in share repurchases. The management team and the Board will continue to review each element of the capital return program regularly and plan to provide an update on the program on an annual basis.

[0000320193-18-000067:8k_2_02:14]
Apple is providing the following guidance for its fiscal 2018 third quarter:

[0000320193-18-000067:8k_2_02:15]
| • | revenue between $51.5 billion and $53.5 billion |

[0000320193-18-000067:8k_2_02:16]
| • | gross margin between 38 percent and 38.5 percent |

[0000320193-18-000067:8k_2_02:17]
| • | operating expenses between $7.7 billion and $7.8 billion |

[0000320193-18-000067:8k_2_02:18]
| • | other income/(expense) of $400 million |

[0000320193-18-000067:8k_2_02:19]
| • | tax rate of approximately 14.5 percent |

[0000320193-18-000067:8k_2_02:20]
Apple will provide live streaming of its Q2 2018 financial results conference call beginning at 2:00 p.m. PDT on May 1, 2018 at www.apple.com/investor/earnings-call/. This webcast will also be available for replay for approximately two weeks thereafter.

[0000320193-18-000067:8k_2_02:21]
Apple revolutionized personal technology with the introduction of the Macintosh in 1984. Today, Apple leads the world in innovation with iPhone, iPad, Mac, Apple Watch and Apple TV. Apple’s four software platforms — iOS, macOS, watchOS and tvOS — provide seamless experiences across all Apple devices and empower people with breakthrough services including the App Store, Apple Music, Apple Pay and iCloud. Apple’s more than 100,000 employees are dedicated to making the best products on earth, and to leaving the world better than we found it.

[0000320193-18-000067:8k_2_02:22]
Press Contact:

[0000320193-18-000067:8k_2_02:23]
Kristin Huguet

[0000320193-18-000067:8k_2_02:24]
Apple

[0000320193-18-000067:8k_2_02:25]
khuguet@apple.com

[0000320193-18-000067:8k_2_02:26]
(408) 974-2414

[0000320193-18-000067:8k_2_02:27]
Investor Relations Contacts:

[0000320193-18-000067:8k_2_02:28]
Nancy Paxton

[0000320193-18-000067:8k_2_02:29]
Apple

[0000320193-18-000067:8k_2_02:30]
paxton1@apple.com

[0000320193-18-000067:8k_2_02:31]
(408) 974-5420

[0000320193-18-000067:8k_2_02:32]
Matt Blake

[0000320193-18-000067:8k_2_02:33]
Apple

[0000320193-18-000067:8k_2_02:34]
mattblake@apple.com

[0000320193-18-000067:8k_2_02:35]
(408) 974-7406

[0000320193-18-000067:8k_2_02:36]
NOTE TO EDITORS: For additional information visit Apple Newsroom (www.apple.com/newsroom), or call Apple’s Media Helpline at (408) 974-2042.

[0000320193-18-000067:8k_2_02:37]
© 2018 Apple Inc. All rights reserved. Apple and the Apple logo are trademarks of Apple. Other company and product names may be trademarks of their respective owners.

[0000320193-18-000067:8k_2_02:38]
Apple Inc.

[0000320193-18-000067:8k_2_02:39]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS (Unaudited)

[0000320193-18-000067:8k_2_02:40]
(In millions, except number of shares which are reflected in thousands and per share amounts)

[0000320193-18-000067:8k_2_02:41]
|  | Three Months Ended |  | Six Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |
| Net sales | $ | 61,137 |  |  | $ | 52,896 |  |  | $ | 149,430 |  |  | $ | 131,247 |  |
| Cost of sales (1) | 37,715 |  |  | 32,305 |  |  | 92,096 |  |  | 80,480 |  |
| Gross margin | 23,422 |  |  | 20,591 |  |  | 57,334 |  |  | 50,767 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development (1) | 3,378 |  |  | 2,776 |  |  | 6,785 |  |  | 5,647 |  |
| Selling, general and administrative (1) | 4,150 |  |  | 3,718 |  |  | 8,381 |  |  | 7,664 |  |
| Total operating expenses | 7,528 |  |  | 6,494 |  |  | 15,166 |  |  | 13,311 |  |
| Operating income | 15,894 |  |  | 14,097 |  |  | 42,168 |  |  | 37,456 |  |
| Other income/(expense), net | 274 |  |  | 587 |  |  | 1,030 |  |  | 1,408 |  |
| Income before provision for income taxes | 16,168 |  |  | 14,684 |  |  | 43,198 |  |  | 38,864 |  |
| Provision for income taxes | 2,346 |  |  | 3,655 |  |  | 9,311 |  |  | 9,944 |  |
| Net income | $ | 13,822 |  |  | $ | 11,029 |  |  | $ | 33,887 |  |  | $ | 28,920 |  |
| Earnings per share: |  |  |  |  |  |  |  |
| Basic | $ | 2.75 |  |  | $ | 2.11 |  |  | $ | 6.69 |  |  | $ | 5.50 |  |
| Diluted | $ | 2.73 |  |  | $ | 2.10 |  |  | $ | 6.63 |  |  | $ | 5.46 |  |
| Shares used in computing earnings per share: |  |  |  |  |  |  |  |
| Basic | 5,024,877 |  |  | 5,225,791 |  |  | 5,068,877 |  |  | 5,262,226 |  |
| Diluted | 5,068,493 |  |  | 5,261,688 |  |  | 5,113,140 |  |  | 5,294,841 |  |
| Cash dividends declared per share | $ | 0.63 |  |  | $ | 0.57 |  |  | $ | 1.26 |  |  | $ | 1.14 |  |
| (1) Includes share-based compensation expense as follows: |
| Cost of sales | $ | 257 |  |  | $ | 217 |  |  | $ | 509 |  |  | $ | 446 |  |
| Research and development | $ | 666 |  |  | $ | 575 |  |  | $ | 1,312 |  |  | $ | 1,164 |  |
| Selling, general and administrative | $ | 425 |  |  | $ | 425 |  |  | $ | 823 |  |  | $ | 863 |  |

[0000320193-18-000067:8k_2_02:42]
Apple Inc.

[0000320193-18-000067:8k_2_02:43]
CONDENSED CONSOLIDATED BALANCE SHEETS (Unaudited)

[0000320193-18-000067:8k_2_02:44]
(In millions, except number of shares which are reflected in thousands and par value)

[0000320193-18-000067:8k_2_02:45]
|  | March 31, 2018 |  | September 30, 2017 |
| ASSETS: |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 45,059 |  |  | $ | 20,289 |  |
| Short-term marketable securities | 42,881 |  |  | 53,892 |  |
| Accounts receivable, less allowances of $60 and $58, respectively | 14,324 |  |  | 17,874 |  |
| Inventories | 7,662 |  |  | 4,855 |  |
| Vendor non-trade receivables | 8,084 |  |  | 17,799 |  |
| Other current assets | 12,043 |  |  | 13,936 |  |
| Total current assets | 130,053 |  |  | 128,645 |  |
| Long-term marketable securities | 179,286 |  |  | 194,714 |  |
| Property, plant and equipment, net | 35,077 |  |  | 33,783 |  |
| Other non-current assets | 23,086 |  |  | 18,177 |  |
| Total assets | $ | 367,502 |  |  | $ | 375,319 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY: |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 34,311 |  |  | $ | 49,049 |  |
| Accrued expenses | 26,756 |  |  | 25,744 |  |
| Deferred revenue | 7,775 |  |  | 7,548 |  |
| Commercial paper | 11,980 |  |  | 11,977 |  |
| Current portion of long-term debt | 8,498 |  |  | 6,496 |  |
| Total current liabilities | 89,320 |  |  | 100,814 |  |
| Deferred revenue, non-current | 3,087 |  |  | 2,836 |  |
| Long-term debt | 101,362 |  |  | 97,207 |  |
| Other non-current liabilities | 46,855 |  |  | 40,415 |  |
| Total liabilities | 240,624 |  |  | 241,272 |  |
| Commitments and contingencies |  |  |  |
| Shareholders’ equity: |  |  |  |
| Common stock and additional paid-in capital, $0.00001 par value: 12,600,000 shares authorized; 4,943,282 and 5,126,201 shares issued and outstanding, respectively | 38,044 |  |  | 35,867 |  |
| Retained earnings | 91,898 |  |  | 98,330 |  |
| Accumulated other comprehensive income/(loss) | (3,064 | ) |  | (150 | ) |
| Total shareholders’ equity | 126,878 |  |  | 134,047 |  |
| Total liabilities and shareholders’ equity | $ | 367,502 |  |  | $ | 375,319 |  |

[0000320193-18-000067:8k_2_02:46]
Apple Inc.

[0000320193-18-000067:8k_2_02:47]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (Unaudited)

[0000320193-18-000067:8k_2_02:48]
(In millions)

[0000320193-18-000067:8k_2_02:49]
|  | Six Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |
| Cash and cash equivalents, beginning of the period | $ | 20,289 |  |  | $ | 20,484 |  |
| Operating activities: |  |  |  |
| Net income | 33,887 |  |  | 28,920 |  |
| Adjustments to reconcile net income to cash generated by operating activities: |  |  |  |
| Depreciation and amortization | 5,484 |  |  | 5,319 |  |
| Share-based compensation expense | 2,644 |  |  | 2,473 |  |
| Deferred income tax expense/(benefit) | (34,235 | ) |  | 2,822 |  |
| Other | (151 | ) |  | (209 | ) |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | 3,523 |  |  | 4,183 |  |
| Inventories | (2,807 | ) |  | (778 | ) |
| Vendor non-trade receivables | 9,715 |  |  | 4,512 |  |
| Other current and non-current assets | (1,053 | ) |  | (896 | ) |
| Accounts payable | (13,220 | ) |  | (6,862 | ) |
| Deferred revenue | 478 |  |  | (221 | ) |
| Other current and non-current liabilities | 39,158 |  |  | 541 |  |
| Cash generated by operating activities | 43,423 |  |  | 39,804 |  |
| Investing activities: |  |  |  |
| Purchases of marketable securities | (48,449 | ) |  | (99,821 | ) |
| Proceeds from maturities of marketable securities | 31,884 |  |  | 12,429 |  |
| Proceeds from sales of marketable securities | 38,942 |  |  | 60,454 |  |
| Payments for acquisition of property, plant and equipment | (7,005 | ) |  | (6,309 | ) |
| Payments made in connection with business acquisitions, net | (305 | ) |  | (67 | ) |
| Other | 53 |  |  | (10 | ) |
| Cash generated by/(used in) investing activities | 15,120 |  |  | (33,324 | ) |
| Financing activities: |  |  |  |
| Proceeds from issuance of common stock | 327 |  |  | 273 |  |
| Payments for taxes related to net share settlement of equity awards | (1,190 | ) |  | (788 | ) |
| Payments for dividends and dividend equivalents | (6,529 | ) |  | (6,134 | ) |
| Repurchases of common stock | (32,851 | ) |  | (18,012 | ) |
| Proceeds from issuance of term debt, net | 6,969 |  |  | 10,975 |  |
| Repayments of term debt | (500 | ) |  | — |  |
| Change in commercial paper, net | 1 |  |  | 1,879 |  |
| Cash used in financing activities | (33,773 | ) |  | (11,807 | ) |
| Increase/(Decrease) in cash and cash equivalents | 24,770 |  |  | (5,327 | ) |
| Cash and cash equivalents, end of the period | $ | 45,059 |  |  | $ | 15,157 |  |
| Supplemental cash flow disclosure: |  |  |  |
| Cash paid for income taxes, net | $ | 6,340 |  |  | $ | 6,878 |  |
| Cash paid for interest | $ | 1,356 |  |  | $ | 1,007 |  |
