# AAPL notes — 0000320193-18-000070


## aapl:CashCashEquivalentsandAvailableforSaleSecuritiesTableTextBlock

[0000320193-18-000070:notes:1]
The following tables show the Company’s cash and available-for-sale securities by significant investment category as of March 31, 2018 and September 30, 2017 (in millions):

[0000320193-18-000070:notes:2]
|  | March 31, 2018 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | Short-TermMarketableSecurities |  | Long-TermMarketableSecurities |
| Cash | $ | 9,934 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,934 |  |  | $ | 9,934 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 5,742 |  |  | — |  |  | — |  |  | 5,742 |  |  | 5,742 |  |  | — |  |  | — |  |
| Mutual funds | 800 |  |  | — |  |  | (105 | ) |  | 695 |  |  | — |  |  | 695 |  |  | — |  |
| Subtotal | 6,542 |  |  | — |  |  | (105 | ) |  | 6,437 |  |  | 5,742 |  |  | 695 |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 56,737 |  |  | 1 |  |  | (932 | ) |  | 55,806 |  |  | 6,379 |  |  | 9,106 |  |  | 40,321 |  |
| U.S. agency securities | 5,539 |  |  | — |  |  | (39 | ) |  | 5,500 |  |  | 2,837 |  |  | 588 |  |  | 2,075 |  |
| Non-U.S. government securities | 8,247 |  |  | 88 |  |  | (137 | ) |  | 8,198 |  |  | — |  |  | 477 |  |  | 7,721 |  |
| Certificates of deposit and time deposits | 7,266 |  |  | — |  |  | — |  |  | 7,266 |  |  | 4,611 |  |  | 2,021 |  |  | 634 |  |
| Commercial paper | 17,417 |  |  | — |  |  | — |  |  | 17,417 |  |  | 15,455 |  |  | 1,962 |  |  | — |  |
| Corporate securities | 138,036 |  |  | 176 |  |  | (1,975 | ) |  | 136,237 |  |  | 101 |  |  | 27,431 |  |  | 108,705 |  |
| Municipal securities | 973 |  |  | — |  |  | (11 | ) |  | 962 |  |  | — |  |  | 166 |  |  | 796 |  |
| Mortgage- and asset-backed securities | 19,966 |  |  | 9 |  |  | (506 | ) |  | 19,469 |  |  | — |  |  | 435 |  |  | 19,034 |  |
| Subtotal | 254,181 |  |  | 274 |  |  | (3,600 | ) |  | 250,855 |  |  | 29,383 |  |  | 42,186 |  |  | 179,286 |  |
| Total | $ | 270,657 |  |  | $ | 274 |  |  | $ | (3,705 | ) |  | $ | 267,226 |  |  | $ | 45,059 |  |  | $ | 42,881 |  |  | $ | 179,286 |  |

[0000320193-18-000070:notes:3]
[same as prior period, unchanged from 0000320193-18-000007:notes:3]

[0000320193-18-000070:notes:4]
[same as prior period, unchanged from 0000320193-18-000007:notes:4]

[0000320193-18-000070:notes:5]
[same as prior period, unchanged from 0000320193-18-000007:notes:5]


## aapl:CommercialPaperCashFlowSummaryTableTextBlock

[0000320193-18-000070:notes:6]
The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the six months ended March 31, 2018 and April 1, 2017 (in millions):

[0000320193-18-000070:notes:7]
|  | Six Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | 4,070 |  |  | $ | (1,318 | ) |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 5,550 |  |  | 7,057 |  |
| Repayments of commercial paper | (9,619 | ) |  | (3,860 | ) |
| Proceeds from/(Repayments of) commercial paper, net | (4,069 | ) |  | 3,197 |  |
| Total change in commercial paper, net | $ | 1 |  |  | $ | 1,879 |  |


## aapl:NotionalAndCreditRiskAmountsOfOutstandingDerivativePositionsDisclosureTextBlock

[0000320193-18-000070:notes:8]
The following table shows the notional amounts of the Company’s outstanding derivative instruments and credit risk amounts associated with outstanding or unsettled derivative instruments as of March 31, 2018 and September 30, 2017 (in millions):

[0000320193-18-000070:notes:9]
|  | March 31, 2018 |  | September 30, 2017 |
|  | NotionalAmount |  | Credit RiskAmount |  | NotionalAmount |  | Credit RiskAmount |
| Instruments designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 48,122 |  |  | $ | 1,361 |  |  | $ | 56,156 |  |  | $ | 1,049 |  |
| Interest rate contracts | $ | 35,250 |  |  | $ | 12 |  |  | $ | 33,000 |  |  | $ | 218 |  |
| Instruments not designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 61,179 |  |  | $ | 290 |  |  | $ | 69,774 |  |  | $ | 363 |  |


## aapl:ScheduleOfCommonStockRepurchasedTableTextBlock

[0000320193-18-000070:notes:10]
[same as prior period, unchanged from 0000320193-18-000007:notes:10]

[0000320193-18-000070:notes:11]
|  | Number of Shares(in thousands) |  | Average Repurchase Price Per Share |  | Amount(in millions) |
| 2018: |  |  |  |  |  |
| Second quarter | 137,040 |  |  | $ | 171.48 |  |  | $ | 23,500 |  |
| First quarter | 30,181 |  |  | $ | 169.26 |  |  | 5,109 |  |
| Total open market common stock repurchases | 167,221 |  |  |  |  | $ | 28,609 |  |
| 2017: |  |  |  |  |  |
| Fourth quarter | 29,073 |  |  | $ | 154.78 |  |  | $ | 4,500 |  |
| Third quarter | 30,356 |  |  | $ | 148.24 |  |  | 4,500 |  |
| Second quarter | 31,070 |  |  | $ | 128.74 |  |  | 4,001 |  |
| First quarter | 44,333 |  |  | $ | 112.78 |  |  | 5,000 |  |
| Total open market common stock repurchases | 134,832 |  |  |  |  | $ | 18,001 |  |


## us-gaap:AcceleratedShareRepurchasesTextBlock

[0000320193-18-000070:notes:12]
The following table shows the Company’s ASR activity and related information during the six months ended March 31, 2018 and the year ended September 30, 2017:

[0000320193-18-000070:notes:13]
|  | Purchase PeriodEnd Date |  | Number of Shares(in thousands) |  | Average RepurchasePrice Per Share |  | ASR Amount(in millions) |
| November 2017 ASR | February 2018 |  | 29,269 |  | (1) | $ | 170.84 |  |  | $ | 5,000 |  |
| August 2017 ASR | November 2017 |  | 18,887 |  |  | $ | 158.84 |  |  | $ | 3,000 |  |
| May 2017 ASR | August 2017 |  | 20,108 |  |  | $ | 149.20 |  |  | $ | 3,000 |  |
| February 2017 ASR | May 2017 |  | 20,949 |  |  | $ | 143.20 |  |  | $ | 3,000 |  |
| November 2016 ASR | February 2017 |  | 51,157 |  |  | $ | 117.29 |  |  | $ | 6,000 |  |
| August 2016 ASR | November 2016 |  | 26,850 |  |  | $ | 111.73 |  |  | $ | 3,000 |  |

[0000320193-18-000070:notes:14]
| (1) | Includes 23.6 million shares delivered and retired at the beginning of the purchase period, which began in the first quarter of 2018, and 5.7 million shares delivered and retired at the end of the purchase period, which concluded in the second quarter of 2018. |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000320193-18-000070:notes:15]
[same as prior period, unchanged from 0000320193-18-000007:notes:16]

[0000320193-18-000070:notes:16]
The following tables show the Company’s condensed consolidated financial statement details as of March 31, 2018 and September 30, 2017 (in millions):

[0000320193-18-000070:notes:17]
Inventories

[0000320193-18-000070:notes:18]
|  | March 31, 2018 |  | September 30, 2017 |
| Components | $ | 5,186 |  |  | $ | 3,025 |  |
| Finished goods | 2,476 |  |  | 1,830 |  |
| Total inventories | $ | 7,662 |  |  | $ | 4,855 |  |

[0000320193-18-000070:notes:19]
[same as prior period, unchanged from 0000320193-18-000007:notes:18]

[0000320193-18-000070:notes:20]
|  | March 31, 2018 |  | September 30, 2017 |
| Land and buildings | $ | 14,931 |  |  | $ | 13,587 |  |
| Machinery, equipment and internal-use software | 57,784 |  |  | 54,210 |  |
| Leasehold improvements | 7,787 |  |  | 7,279 |  |
| Gross property, plant and equipment | 80,502 |  |  | 75,076 |  |
| Accumulated depreciation and amortization | (45,425 | ) |  | (41,293 | ) |
| Total property, plant and equipment, net | $ | 35,077 |  |  | $ | 33,783 |  |

[0000320193-18-000070:notes:21]
[same as prior period, unchanged from 0000320193-18-000007:notes:20]

[0000320193-18-000070:notes:22]
|  | March 31, 2018 |  | September 30, 2017 |
| Long-term taxes payable | $ | 34,913 |  |  | $ | 257 |  |
| Deferred tax liabilities | 548 |  |  | 31,504 |  |
| Other non-current liabilities | 11,394 |  |  | 8,654 |  |
| Total other non-current liabilities | $ | 46,855 |  |  | $ | 40,415 |  |

[0000320193-18-000070:notes:23]
[same as prior period, unchanged from 0000320193-18-000007:notes:22]

[0000320193-18-000070:notes:24]
The following table shows the detail of other income/(expense), net for the three- and six-month periods ended March 31, 2018 and April 1, 2017 (in millions):

[0000320193-18-000070:notes:25]
|  | Three Months Ended |  | Six Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |
| Interest and dividend income | $ | 1,505 |  |  | $ | 1,282 |  |  | $ | 2,957 |  |  | $ | 2,506 |  |
| Interest expense | (792 | ) |  | (530 | ) |  | (1,526 | ) |  | (1,055 | ) |
| Other expense, net | (439 | ) |  | (165 | ) |  | (401 | ) |  | (43 | ) |
| Total other income/(expense), net | $ | 274 |  |  | $ | 587 |  |  | $ | 1,030 |  |  | $ | 1,408 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000320193-18-000070:notes:26]
[same as prior period, unchanged from 0000320193-18-000007:notes:25]

[0000320193-18-000070:notes:27]
[same as prior period, unchanged from 0000320193-18-000007:notes:26]


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000320193-18-000070:notes:28]
[same as prior period, unchanged from 0000320193-18-000007:notes:27]

[0000320193-18-000070:notes:29]
Apple Inc. and its wholly-owned subsidiaries (collectively “Apple” or the “Company”) designs, manufactures and markets mobile communication and media devices and personal computers, and sells a variety of related software, services, accessories, networking solutions and third-party digital content and applications. The Company’s products and services include iPhone®, iPad®, Mac®, Apple Watch®, AirPods®, Apple TV®, HomePod™, a portfolio of consumer and professional software applications, iOS, macOS®, watchOS® and tvOS™ operating systems, iCloud®, Apple Pay® and a variety of other accessory, service and support offerings. The Company sells and delivers digital content and applications through the iTunes Store®, App Store®, Mac App Store, TV App Store, iBooks Store® and Apple Music® (collectively “Digital Content and Services”). The Company sells its products worldwide through its retail stores, online stores and direct sales force, as well as through third-party cellular network carriers, wholesalers, retailers and resellers. In addition, the Company sells a variety of third-party Apple-compatible products, including application software and various accessories through its retail and online stores. The Company sells to consumers, small and mid-sized businesses and education, enterprise and government customers.

[0000320193-18-000070:notes:30]
[same as prior period, unchanged from 0000320193-18-000007:notes:29]

[0000320193-18-000070:notes:31]
[same as prior period, unchanged from 0000320193-18-000007:notes:30]

[0000320193-18-000070:notes:32]
During the first quarter of 2018, the Company adopted the Financial Accounting Standards Board’s (the “FASB”) Accounting Standards Update (“ASU”) No. 2016-09, Compensation – Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting (“ASU 2016-09”), which modified certain aspects of the accounting for share-based payment transactions, including income taxes, classification of awards and classification in the statement of cash flows. Historically, excess tax benefits or deficiencies from the Company’s equity awards were recorded as additional paid-in capital in its Condensed Consolidated Balance Sheets and were classified as a financing activity in its Condensed Consolidated Statements of Cash Flows. Beginning in 2018, the Company records any excess tax benefits or deficiencies from its equity awards as part of the provision for income taxes in its Condensed Consolidated Statements of Operations in the reporting periods in which equity vesting occurs. The Company elected to apply the cash flow classification requirements related to excess tax benefits retrospectively to all periods presented, which resulted in an increase to cash generated by operating activities in the Condensed Consolidated Statements of Cash Flows of $225 million for the six months ended April 1, 2017.

[0000320193-18-000070:notes:33]
[same as prior period, unchanged from 0000320193-18-000007:notes:32]

[0000320193-18-000070:notes:34]
The following table shows the computation of basic and diluted earnings per share for the three- and six-month periods ended March 31, 2018 and April 1, 2017 (net income in millions and shares in thousands):

[0000320193-18-000070:notes:35]
|  | Three Months Ended |  | Six Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 13,822 |  |  | $ | 11,029 |  |  | $ | 33,887 |  |  | $ | 28,920 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 5,024,877 |  |  | 5,225,791 |  |  | 5,068,877 |  |  | 5,262,226 |  |
| Effect of dilutive securities | 43,616 |  |  | 35,897 |  |  | 44,263 |  |  | 32,615 |  |
| Weighted-average diluted shares | 5,068,493 |  |  | 5,261,688 |  |  | 5,113,140 |  |  | 5,294,841 |  |
| Basic earnings per share | $ | 2.75 |  |  | $ | 2.11 |  |  | $ | 6.69 |  |  | $ | 5.50 |  |
| Diluted earnings per share | $ | 2.73 |  |  | $ | 2.10 |  |  | $ | 6.63 |  |  | $ | 5.46 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000320193-18-000070:notes:36]
Commitments and Contingencies

[0000320193-18-000070:notes:37]
Accrued Warranty and Indemnification

[0000320193-18-000070:notes:38]
The following table shows changes in the Company’s accrued warranties and related costs for the three- and six-month periods ended March 31, 2018 and April 1, 2017 (in millions):

[0000320193-18-000070:notes:39]
|  | Three Months Ended |  | Six Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |
| Beginning accrued warranty and related costs | $ | 4,323 |  |  | $ | 4,698 |  |  | $ | 3,834 |  |  | $ | 3,702 |  |
| Cost of warranty claims | (933 | ) |  | (1,031 | ) |  | (1,915 | ) |  | (2,368 | ) |
| Accruals for product warranty | 640 |  |  | 1,068 |  |  | 2,111 |  |  | 3,401 |  |
| Ending accrued warranty and related costs | $ | 4,030 |  |  | $ | 4,735 |  |  | $ | 4,030 |  |  | $ | 4,735 |  |

[0000320193-18-000070:notes:40]
Agreements entered into by the Company sometimes include indemnification provisions which may subject the Company to costs and damages in the event of a claim against an indemnified third party. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to indemnification of third parties.

[0000320193-18-000070:notes:41]
The Company offers an iPhone Upgrade Program, which is available to customers who purchase a qualifying iPhone in the U.S., the U.K. and mainland China. The iPhone Upgrade Program provides customers the right to trade in that iPhone for a specified amount when purchasing a new iPhone, provided certain conditions are met. The Company accounts for the trade-in right as a guarantee liability and recognizes arrangement revenue net of the fair value of such right, with subsequent changes to the guarantee liability recognized within revenue.

[0000320193-18-000070:notes:42]
The Company has entered into indemnification agreements with its directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers of the Company and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. While the Company maintains directors and officers liability insurance coverage, such insurance coverage may be insufficient to cover all losses or all types of claims that may arise.

[0000320193-18-000070:notes:43]
Concentrations in the Available Sources of Supply of Materials and Product

[0000320193-18-000070:notes:44]
Although most components essential to the Company’s business are generally available from multiple sources, a few components are currently obtained from single or limited sources. In addition, the Company competes for various components with other participants in the markets for mobile communication and media devices and personal computers. Therefore, many components used by the Company, including those that are available from multiple sources, are at times subject to industry-wide shortage and significant pricing fluctuations that could materially adversely affect the Company’s financial condition and operating results.

[0000320193-18-000070:notes:45]
The Company uses some custom components that are not commonly used by its competitors, and new products introduced by the Company often utilize custom components available from only one source. When a component or product uses new technologies, initial capacity constraints may exist until the suppliers’ yields have matured or manufacturing capacity has increased. If the Company’s supply of components for a new or existing product were delayed or constrained, or if an outsourcing partner delayed shipments of completed products to the Company, the Company’s financial condition and operating results could be materially adversely affected. The Company’s business and financial performance could also be materially adversely affected depending on the time required to obtain sufficient quantities from the original source, or to identify and obtain sufficient quantities from an alternative source. Continued availability of these components at acceptable prices, or at all, may be affected if those suppliers decide to concentrate on the production of common components instead of components customized to meet the Company’s requirements.

[0000320193-18-000070:notes:46]
The Company has entered into agreements for the supply of many components; however, there can be no guarantee that the Company will be able to extend or renew these agreements on similar terms, or at all. Therefore, the Company remains subject to significant risks of supply shortages and price increases that could materially adversely affect its financial condition and operating results.

[0000320193-18-000070:notes:47]
Substantially all of the Company’s hardware products are manufactured by outsourcing partners that are located primarily in Asia, with some Mac computers manufactured in the U.S. and Ireland. A significant concentration of this manufacturing is currently performed by a small number of outsourcing partners, often in single locations. Certain of these outsourcing partners are the sole-sourced suppliers of components and manufacturers for many of the Company’s products. Although the Company works closely with its outsourcing partners on manufacturing schedules, the Company’s operating results could be adversely affected if its outsourcing partners were unable to meet their production commitments. The Company’s manufacturing purchase obligations typically cover its requirements for periods up to 150 days.

[0000320193-18-000070:notes:48]
Other Off–Balance Sheet Commitments

[0000320193-18-000070:notes:49]
Operating Leases

[0000320193-18-000070:notes:50]
The Company leases various equipment and facilities, including retail space, under noncancelable operating lease arrangements. The Company does not currently utilize any other off–balance sheet financing arrangements. As of March 31, 2018, the Company’s total future minimum lease payments under noncancelable operating leases were $9.8 billion. The Company’s retail store and other facility leases typically have original terms not exceeding 10 years and generally contain multi-year renewal options.

[0000320193-18-000070:notes:51]
Unconditional Purchase Obligations

[0000320193-18-000070:notes:52]
The Company has entered into certain off–balance sheet arrangements which require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of payments for supplier arrangements, internet and telecommunication services and intellectual property licenses. As of March 31, 2018, the Company’s total future payments under noncancelable unconditional purchase obligations having a remaining term in excess of one year were $8.3 billion.

[0000320193-18-000070:notes:53]
Contingencies

[0000320193-18-000070:notes:54]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully adjudicated, as further discussed in Part II, Item 1 of this Form 10-Q under the heading “Legal Proceedings” and in Part II, Item 1A of this Form 10-Q under the heading “Risk Factors.” In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to loss contingencies for asserted legal and other claims, except for the following matter:

[0000320193-18-000070:notes:55]
VirnetX

[0000320193-18-000070:notes:56]
VirnetX, Inc. filed two lawsuits in the U.S. District Court for the Eastern District of Texas (the “Eastern Texas District Court”) against the Company alleging that certain Company products infringe four patents (the “VirnetX Patents”) relating to network communications technology (“VirnetX I” and “VirnetX II”). On September 30, 2016, a jury returned a verdict in VirnetX I against the Company and awarded damages of $302 million, which later increased to $440 million in post-trial proceedings. VirnetX I is currently on appeal at the U.S. Court of Appeals for the Federal Circuit (the “Federal Circuit”). On April 11, 2018, a jury returned a verdict in VirnetX II against the Company and awarded damages of $503 million. VirnetX II is currently in post-trial proceedings and is expected to proceed to appeal thereafter. The Company has challenged the validity of the VirnetX Patents at the U.S. Patent and Trademark Office (the “PTO”). In response, the PTO has declared the VirnetX Patents invalid. VirnetX has appealed, and those appeals are currently pending at the Federal Circuit. The Federal Circuit has consolidated the Company’s appeal of the Eastern Texas District Court VirnetX I verdict and VirnetX’s appeals from the PTO invalidity proceedings. The Company believes it will prevail on the merits.

[0000320193-18-000070:notes:57]
The outcome of litigation is inherently uncertain. If one or more legal matters were resolved against the Company in a reporting period for amounts in excess of management’s expectations, the Company’s consolidated financial statements for that reporting period could be materially adversely affected.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000320193-18-000070:notes:58]
[same as prior period, unchanged from 0000320193-18-000007:notes:58]

[0000320193-18-000070:notes:59]
[same as prior period, unchanged from 0000320193-18-000007:notes:59]

[0000320193-18-000070:notes:60]
The Company had 270.0 million shares reserved for future issuance under its stock plans as of March 31, 2018. Restricted stock units (“RSUs”) granted generally vest over four years, based on continued employment, and are settled upon vesting in shares of the Company’s common stock on a one-for-one basis. Each share issued with respect to RSUs granted under the Company’s stock plans reduces the number of shares available for grant under the plans by two shares. RSUs canceled and shares withheld to satisfy tax withholding obligations increase the number of shares available for grant under the plans utilizing a factor of two times the number of RSUs canceled or shares withheld.

[0000320193-18-000070:notes:61]
[same as prior period, unchanged from 0000320193-18-000007:notes:61]

[0000320193-18-000070:notes:62]
During the three months ended March 31, 2018, Section 16 officers Angela Ahrendts, Timothy D. Cook, Luca Maestri, Daniel Riccio, Philip Schiller and Jeffrey Williams had equity trading plans in place in accordance with Rule 10b5-1(c)(1) under the Exchange Act. An equity trading plan is a written document that pre-establishes the amounts, prices and dates (or formula for determining the amounts, prices and dates) of future purchases or sales of the Company’s stock, including shares acquired pursuant to the Company’s employee and director equity plans.

[0000320193-18-000070:notes:63]
[same as prior period, unchanged from 0000320193-18-000007:notes:63]

[0000320193-18-000070:notes:64]
A summary of the Company’s RSU activity and related information for the six months ended March 31, 2018 is as follows:

[0000320193-18-000070:notes:65]
|  | Number ofRSUs(in thousands) |  | Weighted-AverageGrant Date FairValue Per RSU |  | AggregateFair Value(in millions) |
| Balance as of September 30, 2017 | 97,571 |  |  | $ | 110.33 |  |  |  |
| RSUs granted | 40,184 |  |  | $ | 159.25 |  |  |  |
| RSUs vested | (22,348 | ) |  | $ | 103.66 |  |  |  |
| RSUs canceled | (3,023 | ) |  | $ | 123.28 |  |  |  |
| Balance as of March 31, 2018 | 112,384 |  |  | $ | 128.80 |  |  | $ | 18,856 |  |

[0000320193-18-000070:notes:66]
The fair value as of the respective vesting dates of RSUs was $457 million and $3.6 billion for the three- and six-month periods ended March 31, 2018, respectively, and was $460 million and $2.6 billion for the three- and six-month periods ended April 1, 2017, respectively.

[0000320193-18-000070:notes:67]
The following table shows a summary of the share-based compensation expense included in the Condensed Consolidated Statements of Operations for the three- and six-month periods ended March 31, 2018 and April 1, 2017 (in millions):

[0000320193-18-000070:notes:68]
|  | Three Months Ended |  | Six Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |
| Cost of sales | $ | 257 |  |  | $ | 217 |  |  | $ | 509 |  |  | $ | 446 |  |
| Research and development | 666 |  |  | 575 |  |  | 1,312 |  |  | 1,164 |  |
| Selling, general and administrative | 425 |  |  | 425 |  |  | 823 |  |  | 863 |  |
| Total share-based compensation expense | $ | 1,348 |  |  | $ | 1,217 |  |  | $ | 2,644 |  |  | $ | 2,473 |  |

[0000320193-18-000070:notes:69]
The income tax benefit related to share-based compensation expense was $347 million and $1.0 billion for the three- and six-month periods ended March 31, 2018, respectively, and was $424 million and $889 million for the three- and six-month periods ended April 1, 2017, respectively. As of March 31, 2018, the total unrecognized compensation cost related to outstanding RSUs and stock options was $11.4 billion, which the Company expects to recognize over a weighted-average period of 2.8 years.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000320193-18-000070:notes:70]
[same as prior period, unchanged from 0000320193-18-000007:notes:70]

[0000320193-18-000070:notes:71]
[same as prior period, unchanged from 0000320193-18-000007:notes:71]

[0000320193-18-000070:notes:72]
The following table shows the pre-tax amounts reclassified from AOCI into the Condensed Consolidated Statements of Operations, and the associated financial statement line item, for the three- and six-month periods ended March 31, 2018 and April 1, 2017 (in millions):

[0000320193-18-000070:notes:73]
|  |  |  |  | Three Months Ended |  | Six Months Ended |
| Comprehensive Income Components |  | Financial Statement Line Item |  | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |
| Unrealized (gains)/losses on derivative instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Net sales |  | $ | 87 |  |  | $ | (408 | ) |  | $ | 271 |  |  | $ | (509 | ) |
|  |  | Cost of sales |  | 21 |  |  | (570 | ) |  | (6 | ) |  | (557 | ) |
|  |  | Other income/(expense), net |  | (390 | ) |  | (367 | ) |  | (423 | ) |  | 237 |  |
| Interest rate contracts |  | Other income/(expense), net |  | (2 | ) |  | 2 |  |  | (3 | ) |  | 3 |  |
|  |  |  |  | (284 | ) |  | (1,343 | ) |  | (161 | ) |  | (826 | ) |
| Unrealized (gains)/losses on marketable securities |  | Other income/(expense), net |  | 36 |  |  | (20 | ) |  | (80 | ) |  | 11 |  |
| Total amounts reclassified from AOCI |  | $ | (248 | ) |  | $ | (1,363 | ) |  | $ | (241 | ) |  | $ | (815 | ) |

[0000320193-18-000070:notes:74]
The following table shows the changes in AOCI by component for the six months ended March 31, 2018 (in millions):

[0000320193-18-000070:notes:75]
|  | Cumulative ForeignCurrency Translation |  | Unrealized Gains/Losseson Derivative Instruments |  | Unrealized Gains/Losseson Marketable Securities |  | Total |
| Balances as of September 30, 2017 | $ | (354 | ) |  | $ | (124 | ) |  | $ | 328 |  |  | $ | (150 | ) |
| Other comprehensive income/(loss) before reclassifications | 296 |  |  | 191 |  |  | (3,854 | ) |  | (3,367 | ) |
| Amounts reclassified from AOCI | — |  |  | (161 | ) |  | (80 | ) |  | (241 | ) |
| Tax effect | 7 |  |  | (74 | ) |  | 1,039 |  |  | 972 |  |
| Other comprehensive income/(loss) | 303 |  |  | (44 | ) |  | (2,895 | ) |  | (2,636 | ) |
| Cumulative effect of change in accounting principle (1) | (176 | ) |  | 29 |  |  | (131 | ) |  | (278 | ) |
| Balances as of March 31, 2018 | $ | (227 | ) |  | $ | (139 | ) |  | $ | (2,698 | ) |  | $ | (3,064 | ) |

[0000320193-18-000070:notes:76]
| (1) | Refer to Note 4, “Income Taxes” for more information on the Company’s adoption of ASU 2018-02 at the beginning of the second quarter of 2018. |


## us-gaap:DebtDisclosureTextBlock

[0000320193-18-000070:notes:77]
Debt

[0000320193-18-000070:notes:78]
Commercial Paper

[0000320193-18-000070:notes:79]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of both March 31, 2018 and September 30, 2017, the Company had $12.0 billion of Commercial Paper outstanding with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 1.68% as of March 31, 2018 and 1.20% as of September 30, 2017. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the six months ended March 31, 2018 and April 1, 2017 (in millions):

[0000320193-18-000070:notes:80]
Term Debt

[0000320193-18-000070:notes:81]
As of March 31, 2018, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $111.1 billion (collectively the “Notes”). The Notes are senior unsecured obligations, and interest is payable in arrears, quarterly for the U.S. dollar–denominated and Australian dollar–denominated floating-rate notes, semi-annually for the U.S. dollar–denominated, Australian dollar–denominated, British pound–denominated, Japanese yen–denominated and Canadian dollar–denominated fixed-rate notes and annually for the euro-denominated and Swiss franc–denominated fixed-rate notes. The following table provides a summary of the Company’s term debt as of March 31, 2018 and September 30, 2017:

[0000320193-18-000070:notes:82]
|  | Maturities |  | March 31, 2018 |  | September 30, 2017 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2018 |  | 2018 |  | $ | 2,000 |  |  |  | 1.10% |  | 1.10 | % |  | $ | 2,000 |  |  |  | 1.10% |  | 1.10 | % |
| Fixed-rate 1.000% – 3.850% notes | 2018 | – | 2043 |  | 12,500 |  |  |  | 1.08% | – | 3.91 | % |  | 12,500 |  |  |  | 1.08% | – | 3.91 | % |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 |  | 2019 |  | 1,000 |  |  |  | 2.09% |  | 2.09 | % |  | 1,000 |  |  |  | 1.61% |  | 1.61 | % |
| Fixed-rate 2.100% – 4.450% notes | 2019 | – | 2044 |  | 8,500 |  |  |  | 2.09% | – | 4.48 | % |  | 8,500 |  |  |  | 1.61% | – | 4.48 | % |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2020 |  | 1,537 |  |  |  | 1.87% | – | 2.12 | % |  | 1,549 |  |  |  | 1.56% | – | 1.87 | % |
| Fixed-rate 0.350% – 4.375% notes | 2019 | – | 2045 |  | 25,094 |  |  |  | 0.28% | – | 4.51 | % |  | 24,522 |  |  |  | 0.28% | – | 4.51 | % |
| 2016 debt issuances of $24.9 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2021 |  | 1,350 |  |  |  | 1.93% | – | 3.05 | % |  | 1,350 |  |  |  | 1.45% | – | 2.44 | % |
| Fixed-rate 1.100% – 4.650% notes | 2019 | – | 2046 |  | 23,120 |  |  |  | 1.13% | – | 4.78 | % |  | 23,645 |  |  |  | 1.13% | – | 4.78 | % |
| 2017 debt issuances of $28.7 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2022 |  | 3,250 |  |  |  | 1.88% | – | 2.30 | % |  | 3,250 |  |  |  | 1.38% | – | 1.81 | % |
| Fixed-rate 0.875% – 4.300% notes | 2019 | – | 2047 |  | 25,786 |  |  |  | 1.54% | – | 4.30 | % |  | 25,705 |  |  |  | 1.51% | – | 4.30 | % |
| First quarter 2018 debt issuance of $7.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 1.800% notes |  |  | 2019 |  | 1,000 |  |  |  |  |  | 1.83 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.000% notes |  |  | 2020 |  | 1,000 |  |  |  |  |  | 2.03 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.400% notes |  |  | 2023 |  | 750 |  |  |  |  |  | 2.14 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.750% notes |  |  | 2025 |  | 1,500 |  |  |  |  |  | 2.77 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.000% notes |  |  | 2027 |  | 1,500 |  |  |  |  |  | 2.54 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.750% notes |  |  | 2047 |  | 1,250 |  |  |  |  |  | 3.80 | % |  | — |  |  |  |  |  | — | % |
| Total term debt |  |  |  |  | 111,137 |  |  |  |  |  |  |  | 104,021 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (236 | ) |  |  |  |  |  |  | (225 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | (1,041 | ) |  |  |  |  |  |  | (93 | ) |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  |  |  | (8,498 | ) |  |  |  |  |  |  | (6,496 | ) |  |  |  |  |  |
| Total long-term debt |  |  |  |  | $ | 101,362 |  |  |  |  |  |  |  | $ | 97,207 |  |  |  |  |  |  |

[0000320193-18-000070:notes:83]
To manage interest rate risk on certain of its U.S. dollar–denominated fixed- or floating-rate notes, the Company has entered into interest rate swaps to effectively convert the fixed interest rates to floating interest rates or the floating interest rates to fixed interest rates on a portion of these notes. Additionally, to manage foreign currency risk on certain of its foreign currency–denominated notes, the Company has entered into foreign currency swaps to effectively convert these notes to U.S. dollar–denominated notes.

[0000320193-18-000070:notes:84]
A portion of the Company’s Japanese yen–denominated notes is designated as a hedge of the foreign currency exposure of the Company’s net investment in a foreign operation. As of March 31, 2018 and September 30, 2017, the carrying value of the debt designated as a net investment hedge was $518 million and $1.6 billion, respectively. For further discussion regarding the Company’s use of derivative instruments see the Derivative Financial Instruments section of Note 2, “Financial Instruments.”

[0000320193-18-000070:notes:85]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $742 million and $1.4 billion of interest expense on its term debt for the three- and six-month periods ended March 31, 2018, respectively. The Company recognized $507 million and $1.0 billion of interest expense on its term debt for the three- and six-month periods ended April 1, 2017, respectively.

[0000320193-18-000070:notes:86]
As of March 31, 2018 and September 30, 2017, the fair value of the Company’s Notes, based on Level 2 inputs, was $111.1 billion and $106.1 billion, respectively.


## us-gaap:DerivativesPolicyTextBlock

[0000320193-18-000070:notes:87]
[same as prior period, unchanged from 0000320193-18-000007:notes:87]

[0000320193-18-000070:notes:88]
[same as prior period, unchanged from 0000320193-18-000007:notes:88]

[0000320193-18-000070:notes:89]
[same as prior period, unchanged from 0000320193-18-000007:notes:89]

[0000320193-18-000070:notes:90]
To help protect the net investment in a foreign operation from adverse changes in foreign currency exchange rates, the Company may enter into foreign currency forward and option contracts to offset the changes in the carrying amounts of these investments due to fluctuations in foreign currency exchange rates. In addition, the Company may use non-derivative financial instruments, such as its foreign currency–denominated debt, as economic hedges of its net investments in certain foreign subsidiaries. In both of these cases, the Company designates these instruments as net investment hedges.

[0000320193-18-000070:notes:91]
[same as prior period, unchanged from 0000320193-18-000007:notes:91]

[0000320193-18-000070:notes:92]
The Company may enter into interest rate swaps, options or other instruments to manage interest rate risk. These instruments may offset a portion of changes in income or expense, or changes in fair value of the Company’s term debt or investments. The Company designates these instruments as either cash flow or fair value hedges. The Company’s hedged interest rate transactions as of March 31, 2018 are expected to be recognized within 10 years.

[0000320193-18-000070:notes:93]
The Company may enter into foreign currency swaps to manage currency risk on its foreign currency–denominated term debt. These instruments may offset a portion of the foreign currency remeasurement gains or losses on the Company’s term debt and related interest payments. The Company designates these instruments as cash flow hedges. The Company’s hedged term debt–related foreign currency transactions as of March 31, 2018 are expected to be recognized within 24 years.

[0000320193-18-000070:notes:94]
[same as prior period, unchanged from 0000320193-18-000007:notes:94]

[0000320193-18-000070:notes:95]
[same as prior period, unchanged from 0000320193-18-000007:notes:95]

[0000320193-18-000070:notes:96]
[same as prior period, unchanged from 0000320193-18-000007:notes:96]

[0000320193-18-000070:notes:97]
[same as prior period, unchanged from 0000320193-18-000007:notes:97]

[0000320193-18-000070:notes:98]
[same as prior period, unchanged from 0000320193-18-000007:notes:98]

[0000320193-18-000070:notes:99]
[same as prior period, unchanged from 0000320193-18-000007:notes:99]

[0000320193-18-000070:notes:100]
[same as prior period, unchanged from 0000320193-18-000007:notes:100]

[0000320193-18-000070:notes:101]
[same as prior period, unchanged from 0000320193-18-000007:notes:101]

[0000320193-18-000070:notes:102]
[same as prior period, unchanged from 0000320193-18-000007:notes:102]

[0000320193-18-000070:notes:103]
[same as prior period, unchanged from 0000320193-18-000007:notes:86]


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000320193-18-000070:notes:104]
[same as prior period, unchanged from 0000320193-18-000007:notes:106]

[0000320193-18-000070:notes:105]
[same as prior period, unchanged from 0000320193-18-000007:notes:105]


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000320193-18-000070:notes:106]
[same as prior period, unchanged from 0000320193-18-000007:notes:107]

[0000320193-18-000070:notes:107]
[same as prior period, unchanged from 0000320193-18-000007:notes:108]

[0000320193-18-000070:notes:108]
[same as prior period, unchanged from 0000320193-18-000007:notes:109]

[0000320193-18-000070:notes:109]
The following tables show information about the Company’s marketable securities that had been in a continuous unrealized loss position for less than 12 months and for 12 months or greater as of March 31, 2018 and September 30, 2017 (in millions):

[0000320193-18-000070:notes:110]
|  | March 31, 2018 |
|  | Continuous Unrealized Losses |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
| Fair value of marketable securities | $ | 159,198 |  |  | $ | 37,266 |  |  | $ | 196,464 |  |
| Unrealized losses | $ | (2,633 | ) |  | $ | (1,072 | ) |  | $ | (3,705 | ) |

[0000320193-18-000070:notes:111]
|  | September 30, 2017 |
|  | Continuous Unrealized Losses |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
| Fair value of marketable securities | $ | 101,986 |  |  | $ | 8,290 |  |  | $ | 110,276 |  |
| Unrealized losses | $ | (596 | ) |  | $ | (186 | ) |  | $ | (782 | ) |

[0000320193-18-000070:notes:112]
The Company typically invests in highly rated securities, and its investment policy generally limits the amount of credit exposure to any one issuer. The policy generally requires investments to be investment grade, with the primary objective of minimizing the potential risk of principal loss. Fair values were determined for each individual security in the investment portfolio. When evaluating an investment for other-than-temporary impairment, the Company reviews factors such as the length of time and extent to which fair value has been below its cost basis, the financial condition of the issuer and any changes thereto, changes in market interest rates and the Company’s intent to sell, or whether it is more likely than not it will be required to sell the investment before recovery of the investment’s cost basis. As of March 31, 2018, the Company does not consider any of its investments to be other-than-temporarily impaired.

[0000320193-18-000070:notes:113]
Derivatives that are not designated as hedging instruments are adjusted to fair value through earnings in the financial statement line item to which the derivative relates. As a result, during the three- and six-month periods ended March 31, 2018, respectively, the Company recognized losses of $203 million and $142 million in net sales, losses of $247 million and $212 million in cost of sales and losses of $331 million and $373 million in other income/(expense), net. During the three- and six-month periods ended April 1, 2017, respectively, the Company recognized a loss of $67 million and a gain of $206 million in net sales, a loss of $253 million and a gain of $79 million in cost of sales and a loss of $76 million and a gain of $432 million in other income/(expense), net.

[0000320193-18-000070:notes:114]
The Company records all derivatives in the Condensed Consolidated Balance Sheets at fair value. The Company’s accounting treatment for these derivative instruments is based on its hedge designation. The following tables show the Company’s derivative instruments at gross fair value as of March 31, 2018 and September 30, 2017 (in millions):

[0000320193-18-000070:notes:115]
|  | March 31, 2018 |
|  | Fair Value ofDerivatives Designatedas Hedge Instruments |  | Fair Value ofDerivatives Not Designatedas Hedge Instruments |  | TotalFair Value |
| Derivative assets (1): |  |  |  |  |  |
| Foreign exchange contracts | $ | 1,361 |  |  | $ | 290 |  |  | $ | 1,651 |  |
| Interest rate contracts | $ | 12 |  |  | $ | — |  |  | $ | 12 |  |
| Derivative liabilities (2): |  |  |  |  |  |
| Foreign exchange contracts | $ | 651 |  |  | $ | 514 |  |  | $ | 1,165 |  |
| Interest rate contracts | $ | 1,052 |  |  | $ | — |  |  | $ | 1,052 |  |

[0000320193-18-000070:notes:116]
[same as prior period, unchanged from 0000320193-18-000007:notes:114]

[0000320193-18-000070:notes:117]
[same as prior period, unchanged from 0000320193-18-000007:notes:115]

[0000320193-18-000070:notes:118]
[same as prior period, unchanged from 0000320193-18-000007:notes:116]

[0000320193-18-000070:notes:119]
The following table shows the pre-tax gains and losses of the Company’s derivative and non-derivative instruments designated as cash flow, net investment and fair value hedges in OCI and the Condensed Consolidated Statements of Operations for the three- and six-month periods ended March 31, 2018 and April 1, 2017 (in millions):

[0000320193-18-000070:notes:120]
|  | Three Months Ended |  | Six Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |
| Gains/(Losses) recognized in OCI – effective portion: |  |  |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 37 |  |  | $ | (317 | ) |  | $ | 190 |  |  | $ | 1,410 |  |
| Interest rate contracts | — |  |  | 2 |  |  | 1 |  |  | 9 |  |
| Total | $ | 37 |  |  | $ | (315 | ) |  | $ | 191 |  |  | $ | 1,419 |  |
| Net investment hedges: |  |  |  |  |  |  |  |
| Foreign currency debt | $ | (33 | ) |  | $ | (85 | ) |  | $ | (31 | ) |  | $ | 37 |  |
| Gains/(Losses) reclassified from AOCI into net income – effective portion: |  |  |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 287 |  |  | $ | 1,344 |  |  | $ | 163 |  |  | $ | 833 |  |
| Interest rate contracts | 2 |  |  | (2 | ) |  | 3 |  |  | (3 | ) |
| Total | $ | 289 |  |  | $ | 1,342 |  |  | $ | 166 |  |  | $ | 830 |  |
| Gains/(Losses) on derivative instruments: |  |  |  |  |  |  |  |
| Fair value hedges: |  |  |  |  |  |  |  |
| Interest rate contracts | $ | (674 | ) |  | $ | (50 | ) |  | $ | (948 | ) |  | $ | (922 | ) |
| Gains/(Losses) related to hedged items: |  |  |  |  |  |  |  |
| Fair value hedges: |  |  |  |  |  |  |  |
| Fixed-rate debt | $ | 674 |  |  | $ | 50 |  |  | $ | 948 |  |  | $ | 922 |  |

[0000320193-18-000070:notes:121]
[same as prior period, unchanged from 0000320193-18-000007:notes:119]

[0000320193-18-000070:notes:122]
The Company generally enters into master netting arrangements, which are designed to reduce credit risk by permitting net settlement of transactions with the same counterparty. To further limit credit risk, the Company generally enters into collateral security arrangements that provide for collateral to be received or posted when the net fair value of certain financial instruments fluctuates from contractually established thresholds. The Company presents its derivative assets and derivative liabilities at their gross fair values in its Condensed Consolidated Balance Sheets. As of March 31, 2018, the net cash collateral posted by the Company related to derivative instruments under its collateral security arrangements was $241 million, which was recorded as other current assets in the Condensed Consolidated Balance Sheet. As of September 30, 2017, the net cash collateral received by the Company related to derivative instruments under its collateral security arrangements was $35 million, which was recorded as accrued expenses in the Condensed Consolidated Balance Sheet.

[0000320193-18-000070:notes:123]
Under master netting arrangements with the respective counterparties to the Company’s derivative contracts, the Company is allowed to net settle transactions with a single net amount payable by one party to the other. As of March 31, 2018 and September 30, 2017, the potential effects of these rights of set-off associated with the Company’s derivative contracts, including the effects of collateral, would be a reduction to both derivative assets and derivative liabilities of $2.1 billion and $1.4 billion, respectively, resulting in a net derivative liability of $313 million and a net derivative asset of $32 million, respectively.

[0000320193-18-000070:notes:124]
[same as prior period, unchanged from 0000320193-18-000007:notes:122]

[0000320193-18-000070:notes:125]
[same as prior period, unchanged from 0000320193-18-000007:notes:123]

[0000320193-18-000070:notes:126]
The Company has considerable trade receivables outstanding with its third-party cellular network carriers, wholesalers, retailers, resellers, small and mid-sized businesses and education, enterprise and government customers. The Company generally does not require collateral from its customers; however, the Company will require collateral or third-party credit support in certain instances to limit credit risk. In addition, when possible, the Company attempts to limit credit risk on trade receivables with credit insurance for certain customers or by requiring third-party financing, loans or leases to support credit exposure. These credit-financing arrangements are directly between the third-party financing company and the end customer. As such, the Company generally does not assume any recourse or credit risk sharing related to any of these arrangements.

[0000320193-18-000070:notes:127]
The Company had no customers that individually represented 10% or more of total trade receivables as of March 31, 2018. As of September 30, 2017, the Company had two customers that individually represented 10% or more of total trade receivables, each of which accounted for 10%. The Company’s cellular network carriers accounted for 48% and 59% of total trade receivables as of March 31, 2018 and September 30, 2017, respectively.

[0000320193-18-000070:notes:128]
[same as prior period, unchanged from 0000320193-18-000007:notes:126]

[0000320193-18-000070:notes:129]
The Company has non-trade receivables from certain of its manufacturing vendors resulting from the sale of components to these vendors who manufacture sub-assemblies or assemble final products for the Company. The Company purchases these components directly from suppliers. As of March 31, 2018, the Company had three vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 44%, 20% and 11%. As of September 30, 2017, the Company had three vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 42%, 19% and 10%.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000320193-18-000070:notes:130]
[same as prior period, unchanged from 0000320193-18-000007:notes:128]

[0000320193-18-000070:notes:131]
On December 22, 2017, the U.S. enacted the Tax Cuts and Jobs Act (the “Act”), which significantly changed U.S. tax law. The Act lowered the Company’s U.S. statutory federal income tax rate from 35% to 21% effective January 1, 2018, while also imposing a deemed repatriation tax on previously deferred foreign income. The Act also created a new minimum tax on certain future foreign earnings. During the first six months of fiscal 2018, the Company recognized income tax expense of $9.3 billion, of which $2.6 billion was a provisional estimate in accordance with the U.S. Securities and Exchange Commission Staff Accounting Bulletin No. 118 and was recognized during the first quarter of 2018. This $2.6 billion provisional estimate included $1.8 billion related to the impact of remeasuring to reduce the Company’s deferred tax balances to reflect the new tax rate, and approximately $800 million associated with the net impact of the deemed repatriation tax.

[0000320193-18-000070:notes:132]
[same as prior period, unchanged from 0000320193-18-000007:notes:130]

[0000320193-18-000070:notes:133]
As a result of the Act, the Company remeasured certain deferred tax assets and liabilities based on the revised rates at which they are expected to reverse, including items for which the related income tax effects were originally recognized in OCI. In addition, the Company elected to record certain deferred tax assets and liabilities related to the new minimum tax on certain future foreign earnings. The provisional estimate of $1.8 billion noted above incorporates assumptions based upon the best available interpretation of the Act and may change as the Company receives additional clarification and implementation guidance.

[0000320193-18-000070:notes:134]
During the second quarter of 2018, the FASB issued ASU No. 2018-02, Income Statement – Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income (“ASU 2018-02”). ASU 2018-02 allows an entity to elect to reclassify the income tax effects of the Act on items within AOCI to retained earnings. The Company elected to apply the provision of ASU 2018-02 at the beginning of the second quarter of 2018 with a reclassification of net tax benefits related to cumulative foreign currency translation and unrealized gains/losses on derivative instruments and marketable securities, resulting in a $278 million decrease in AOCI and a corresponding increase in retained earnings in the Condensed Consolidated Balance Sheet.

[0000320193-18-000070:notes:135]
[same as prior period, unchanged from 0000320193-18-000007:notes:132]

[0000320193-18-000070:notes:136]
As of September 30, 2017, the Company had a U.S. deferred tax liability of $36.4 billion for deferred foreign income. As a result of the deemed repatriation tax, which is based on the Company’s cumulative post-1986 deferred foreign income, the Company replaced $36.1 billion of its U.S. deferred tax liability with a provisional tax payable of $38.0 billion. This estimate of the deemed repatriation tax is based, in part, on the amount of cash and other specified assets anticipated to be held by the Company’s foreign subsidiaries as of September 29, 2018. Therefore, the tax payable may change as the asset amounts are finalized. The Company plans to pay the tax in installments in accordance with the Act.

[0000320193-18-000070:notes:137]
[same as prior period, unchanged from 0000320193-18-000007:notes:134]

[0000320193-18-000070:notes:138]
As of March 31, 2018, the Company had gross unrecognized tax benefits of $9.5 billion. These gross unrecognized tax benefits have been offset by certain tax deposits and a $1.1 billion reduction for the estimated impact of the deemed repatriation tax, with the net unrecognized tax benefits classified as other non-current liabilities in the Condensed Consolidated Balance Sheet. Upon recognition, $8.2 billion of the unrecognized tax benefits would impact the Company’s effective tax rate. The Company had accrued $1.5 billion of gross interest and penalties as of March 31, 2018, which are also classified as other non-current liabilities in the Condensed Consolidated Balance Sheet.

[0000320193-18-000070:notes:139]
The Company believes that an adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax audits cannot be predicted with certainty. If any issues addressed in the Company’s tax audits are resolved in a manner inconsistent with its expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. Although timing of resolution and/or closure of audits is not certain, the Company believes it is reasonably possible that its gross unrecognized tax benefits could decrease (either by payment, release or a combination of both) in the next 12 months by as much as $3.4 billion.

[0000320193-18-000070:notes:140]
[same as prior period, unchanged from 0000320193-18-000007:notes:137]

[0000320193-18-000070:notes:141]
On August 30, 2016, the European Commission announced its decision that Ireland granted state aid to the Company by providing tax opinions in 1991 and 2007 concerning the tax allocation of profits of the Irish branches of two subsidiaries of the Company (the “State Aid Decision”). The State Aid Decision orders Ireland to calculate and recover additional taxes from the Company for the period June 2003 through December 2014. Irish legislative changes, effective as of January 2015, eliminated the application of the tax opinions from that date forward. The Company believes the State Aid Decision to be without merit and appealed to the General Court of the Court of Justice of the European Union. Ireland has also appealed the State Aid Decision. Although Ireland is still computing the recovery amount, the Company expects the amount to be in line with the European Commission’s announced recovery amount of €13 billion, plus interest of €1 billion. During the third quarter of 2018, the Company expects to begin funding amounts into escrow, where they will remain pending conclusion of all appeals. The Company believes that any incremental Irish corporate income taxes potentially due related to the State Aid Decision would be creditable against U.S. taxes.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0000320193-18-000070:notes:142]
A reconciliation of the Company’s segment operating income to the Condensed Consolidated Statements of Operations for the three- and six-month periods ended March 31, 2018 and April 1, 2017 is as follows (in millions):

[0000320193-18-000070:notes:143]
|  | Three Months Ended |  | Six Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |
| Segment operating income | $ | 20,614 |  |  | $ | 18,089 |  |  | $ | 51,388 |  |  | $ | 45,397 |  |
| Research and development expense | (3,378 | ) |  | (2,776 | ) |  | (6,785 | ) |  | (5,647 | ) |
| Other corporate expenses, net | (1,342 | ) |  | (1,216 | ) |  | (2,435 | ) |  | (2,294 | ) |
| Total operating income | $ | 15,894 |  |  | $ | 14,097 |  |  | $ | 42,168 |  |  | $ | 37,456 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000320193-18-000070:notes:144]
The following table shows information by reportable segment for the three- and six-month periods ended March 31, 2018 and April 1, 2017 (in millions):

[0000320193-18-000070:notes:145]
|  | Three Months Ended |  | Six Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |
| Americas: |  |  |  |  |  |  |  |
| Net sales | $ | 24,841 |  |  | $ | 21,157 |  |  | $ | 60,034 |  |  | $ | 53,125 |  |
| Operating income | $ | 7,768 |  |  | $ | 6,668 |  |  | $ | 19,084 |  |  | $ | 17,162 |  |
| Europe: |  |  |  |  |  |  |  |
| Net sales | $ | 13,846 |  |  | $ | 12,733 |  |  | $ | 34,900 |  |  | $ | 31,254 |  |
| Operating income | $ | 4,259 |  |  | $ | 3,851 |  |  | $ | 11,152 |  |  | $ | 9,587 |  |
| Greater China: |  |  |  |  |  |  |  |
| Net sales | $ | 13,024 |  |  | $ | 10,726 |  |  | $ | 30,980 |  |  | $ | 26,959 |  |
| Operating income | $ | 4,963 |  |  | $ | 4,224 |  |  | $ | 11,871 |  |  | $ | 10,400 |  |
| Japan: |  |  |  |  |  |  |  |
| Net sales | $ | 5,468 |  |  | $ | 4,485 |  |  | $ | 12,705 |  |  | $ | 10,251 |  |
| Operating income | $ | 2,346 |  |  | $ | 2,037 |  |  | $ | 5,428 |  |  | $ | 4,710 |  |
| Rest of Asia Pacific: |  |  |  |  |  |  |  |
| Net sales | $ | 3,958 |  |  | $ | 3,795 |  |  | $ | 10,811 |  |  | $ | 9,658 |  |
| Operating income | $ | 1,278 |  |  | $ | 1,309 |  |  | $ | 3,853 |  |  | $ | 3,538 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000320193-18-000070:notes:146]
[same as prior period, unchanged from 0000320193-18-000007:notes:146]

[0000320193-18-000070:notes:147]
[same as prior period, unchanged from 0000320193-18-000007:notes:147]

[0000320193-18-000070:notes:148]
[same as prior period, unchanged from 0000320193-18-000007:notes:148]

[0000320193-18-000070:notes:149]
[same as prior period, unchanged from 0000320193-18-000007:notes:149]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000320193-18-000070:notes:150]
[same as prior period, unchanged from 0000320193-18-000007:notes:150]

[0000320193-18-000070:notes:151]
[same as prior period, unchanged from 0000320193-18-000007:notes:153]

[0000320193-18-000070:notes:152]
As of March 31, 2018, the Company had an authorized share repurchase program of up to $210 billion of the Company’s common stock, of which $199.6 billion had been utilized.

[0000320193-18-000070:notes:153]
[same as prior period, unchanged from 0000320193-18-000007:notes:155]

[0000320193-18-000070:notes:154]
On May 1, 2018, the Company announced that the Board of Directors had authorized a new program to repurchase up to $100 billion of the Company’s common stock. The Company’s share repurchase program does not obligate it to acquire any specific number of shares. Under the program, shares may be repurchased in privately negotiated and/or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).
