# AAPL 8-K — 0000320193-20-000008 filed 2020-01-28

## item codes, every 8-K on or before 2020-01-29

- 2020-01-28 0000320193-20-000008 — 2.02, 9.01
- 2019-11-15 0001193125-19-292676 — 8.01, 9.01
- 2019-10-30 0000320193-19-000117 — 2.02, 9.01
- 2019-09-13 0000320193-19-000093 — 5.02
- 2019-09-11 0001193125-19-242975 — 8.01, 9.01
- 2019-07-30 0000320193-19-000073 — 2.02, 9.01
- 2019-04-30 0000320193-19-000063 — 2.02, 9.01
- 2019-03-04 0000320193-19-000032 — 5.07
- 2019-02-06 0000320193-19-000026 — 5.02
- 2019-01-29 0000320193-19-000007 — 2.02, 9.01
- 2019-01-02 0000320193-19-000002 — 2.02, 9.01
- 2018-11-01 0000320193-18-000142 — 2.02, 9.01
- 2018-07-31 0000320193-18-000098 — 2.02, 9.01
- 2018-05-08 0001193125-18-154948 — 8.01 — amendment of 0001193125-18-154515
- 2018-05-07 0001193125-18-154515 — 8.01, 9.01
- 2018-05-01 0000320193-18-000067 — 2.02, 9.01
- 2018-02-14 0001193125-18-045761 — 5.07, 9.01
- 2018-02-01 0000320193-18-000005 — 2.02, 9.01
- 2017-11-13 0001193125-17-341015 — 8.01, 9.01
- 2017-11-02 0000320193-17-000067 — 2.02, 9.01
- 2017-10-12 0001193125-17-308859 — 5.02
- 2017-09-12 0001193125-17-282809 — 8.01, 9.01
- 2017-08-18 0001193125-17-262261 — 8.01, 9.01
- 2017-08-01 0000320193-17-000006 — 2.02, 9.01
- 2017-06-20 0001193125-17-208226 — 8.01, 9.01
- 2017-05-24 0001193125-17-181867 — 8.01, 9.01
- 2017-05-11 0001193125-17-167400 — 8.01, 9.01
- 2017-05-02 0001628280-17-004663 — 2.02, 9.01
- 2017-03-03 0001193125-17-069853 — 8.01, 9.01
- 2017-03-01 0001193125-17-064019 — 5.07
- 2017-02-09 0001193125-17-036283 — 8.01, 9.01
- 2017-01-31 0001628280-17-000663 — 2.02, 9.01
- 2016-12-15 0001628280-16-022047 — 5.03, 9.01
- 2016-10-25 0001628280-16-020258 — 2.02, 9.01
- 2016-08-04 0001193125-16-672044 — 8.01, 9.01
- 2016-07-26 0001628280-16-017762 — 2.02, 9.01
- 2016-06-22 0001193125-16-628957 — 8.01, 9.01
- 2016-04-26 0001193125-16-556520 — 2.02, 9.01
- 2016-03-24 0001193125-16-516891 — 8.01, 9.01
- 2016-03-01 0001193125-16-488223 — 5.02, 5.07, 9.01
- 2016-02-23 0001193125-16-473562 — 8.01, 9.01
- 2016-01-26 0001193125-16-438421 — 2.02, 9.01
- 2015-12-22 0001193125-15-410853 — 5.03, 9.01
- 2015-12-17 0001193125-15-406279 — 5.02
- 2015-10-27 0001193125-15-354756 — 2.02, 9.01
- 2015-10-02 0001193125-15-336615 — 5.02
- 2015-09-17 0001193125-15-322466 — 8.01, 9.01
- 2015-07-31 0001193125-15-273023 — 8.01, 9.01
- 2015-07-21 0001193125-15-258464 — 2.02, 9.01
- 2015-06-10 0001193125-15-219298 — 8.01, 9.01
- 2015-05-13 0001193125-15-186064 — 8.01, 9.01
- 2015-04-27 0001193125-15-149607 — 7.01, 9.01
- 2015-04-27 0001193125-15-149590 — 2.02, 9.01
- 2015-03-13 0001104659-15-019336 — 5.07, 9.01
- 2015-02-09 0001193125-15-039270 — 8.01, 9.01
- 2015-01-28 0001193125-15-023732 — 8.01, 9.01
- 2015-01-27 0001193125-15-021857 — 2.02, 9.01
- 2014-11-10 0001193125-14-406296 — 8.01, 9.01
- 2014-10-20 0001193125-14-376361 — 2.02, 9.01
- 2014-07-23 0001193125-14-277193 — 8.01, 9.01
- 2014-07-22 0001193125-14-275598 — 2.02, 9.01
- 2014-07-17 0001193125-14-271698 — 5.02
- 2014-06-06 0001193125-14-228798 — 5.03, 9.01
- 2014-05-30 0001181431-14-021923 — 5.02
- 2014-05-06 0001193125-14-184969 — 8.01, 9.01
- 2014-04-23 0001193125-14-154883 — 7.01, 9.01
- 2014-04-23 0001193125-14-154871 — 2.02, 9.01
- 2014-03-05 0001193125-14-084697 — 5.02, 5.03, 5.07, 9.01
- 2014-01-27 0001193125-14-022238 — 2.02, 9.01
- 2013-10-28 0001193125-13-413498 — 2.02, 9.01
- 2013-09-23 0001181431-13-050140 — 8.01
- 2013-07-30 0001181431-13-041847 — 5.02
- 2013-07-23 0001193125-13-298914 — 2.02, 9.01
- 2013-06-21 0001193125-13-267629 — 5.02
- 2013-05-03 0001193125-13-199324 — 8.01, 9.01
- 2013-04-24 0001193125-13-170623 — 8.01, 9.01
- 2013-04-23 0001193125-13-167469 — 7.01, 9.01
- 2013-04-23 0001193125-13-167458 — 2.02, 9.01
- 2013-03-01 0001193125-13-085842 — 5.07
- 2013-01-23 0001193125-13-020783 — 2.02, 9.01
- 2012-10-25 0001193125-12-435506 — 2.02, 9.01
- 2012-07-24 0001193125-12-312355 — 2.02, 9.01
- 2012-06-28 0001181431-12-038301 — 5.02
- 2012-05-24 0001181431-12-032458 — 5.02
- 2012-04-24 0001193125-12-178928 — 2.02, 9.01
- 2012-02-27 0001193125-12-081892 — 5.07
- 2012-01-24 0001193125-12-021833 — 2.02, 9.01
- 2011-11-16 0001181431-11-056354 — 5.02
- 2011-10-18 0001193125-11-273826 — 2.02, 9.01
- 2011-10-06 0001181431-11-051976 — 8.01
- 2011-08-26 0001181431-11-047179 — 5.02
- 2011-07-19 0001193125-11-191368 — 2.02, 9.01
- 2011-06-15 0001181431-11-036782 — 5.02
- 2011-04-20 0001193125-11-103732 — 2.02, 9.01
- 2011-02-24 0001193125-11-045411 — 5.07
- 2011-01-18 0001193125-11-009392 — 2.02, 9.01
- 2011-01-18 0001181431-11-003847 — 5.02
- 2010-11-17 0001181431-10-056327 — 5.02, 5.03, 9.01
- 2010-10-18 0001193125-10-230992 — 2.02, 9.01
- 2010-07-20 0001193125-10-161807 — 2.02, 9.01
- 2010-04-20 0001193125-10-087786 — 2.02, 9.01
- 2010-03-12 0001181431-10-016054 — 5.02
- 2010-03-01 0001193125-10-044765 — 5.02, 5.07, 9.01
- 2010-01-25 0001193125-10-012096 — 2.02, 9.01
- 2009-10-19 0001193125-09-209633 — 2.02, 9.01
- 2009-08-04 0001181431-09-037492 — 5.02
- 2009-07-21 0001193125-09-152290 — 2.02, 9.01
- 2009-06-02 0001181431-09-028400 — 5.03
- 2009-04-22 0001193125-09-084599 — 2.02, 9.01
- 2009-02-27 0001181431-09-012161 — 4.01
- 2009-01-21 0001193125-09-009009 — 2.02, 9.01
- 2009-01-16 0001181431-09-003017 — 5.02
- 2008-10-21 0001193125-08-213642 — 2.02, 9.01
- 2008-08-26 0001181431-08-050059 — 5.03
- 2008-07-21 0001193125-08-154381 — 2.02, 9.01
- 2008-06-09 0001181431-08-037620 — 8.01
- 2008-04-23 0001193125-08-088001 — 2.02, 9.01
- 2008-01-22 0001193125-08-009715 — 2.02, 9.01
- 2008-01-15 0001181431-08-003342 — 2.02, 8.01
- 2008-01-08 0001181431-08-002372 — 5.02
- 2007-10-22 0001104659-07-076142 — 2.02, 9.01
- 2007-07-25 0001104659-07-056111 — 2.02, 9.01
- 2007-05-16 0001104659-07-040672 — 5.02, 9.01
- 2007-04-25 0001104659-07-031354 — 2.02, 9.01
- 2007-04-24 0001104659-07-030938 — 8.01, 9.01
- 2007-02-21 0001104659-07-012760 — 5.03, 9.01
- 2007-01-17 0001104659-07-002905 — 2.02, 9.01
- 2007-01-10 0001104659-07-001648 — 5.03, 9.01
- 2006-10-27 0001104659-06-069015 — 8.01
- 2006-10-18 0001104659-06-067275 — 2.02, 9.01
- 2006-10-04 0001104659-06-064935 — 5.02, 8.01, 9.01
- 2006-09-01 0001104659-06-058808 — 1.01, 5.02, 5.03, 9.01
- 2006-08-11 0001104659-06-054118 — 2.02, 3.01, 9.01
- 2006-08-04 0001104659-06-051302 — 2.02, 4.02, 9.01
- 2006-07-19 0001104659-06-047739 — 2.02, 9.01
- 2006-04-21 0001181431-06-024759 — 1.01
- 2006-04-19 0001104659-06-025992 — 2.02, 9.01
- 2006-01-18 0001104659-06-002690 — 2.02, 9.01
- 2006-01-10 0001104659-06-001428 — 2.02
- 2005-12-19 0001181431-05-067468 — 1.01
- 2005-10-14 0001181431-05-056604 — 5.02
- 2005-10-11 0001104659-05-048094 — 2.02, 9.01
- 2005-08-26 0001181431-05-049163 — 1.01
- 2005-08-15 0001181431-05-046871 — 1.01
- 2005-07-13 0001104659-05-032297 — 2.02, 9.01
- 2005-06-06 0001181431-05-033177 — 8.01
- 2005-04-26 0001181431-05-023450 — 1.01
- 2005-04-13 0001104659-05-016307 — 2.02, 9.01
- 2005-03-02 0001181431-05-013840 — 3.03, 5.03
- 2005-02-11 0001104659-05-005507 — 8.01
- 2005-01-12 0001104659-05-001183 — 2.02, 9.01
- 2005-01-11 0001104659-05-001049 — 2.02
- 2004-10-13 0001104659-04-030400 — 2.02, 9.01
- 2004-07-14 0001104659-04-019574 — 12, 7
- 2004-04-14 0001104659-04-010122 — 12, 7
- 2004-01-14 0001104659-04-000896 — 12, 7
- 2003-10-15 0001104659-03-022879 — 12, 7
- 2003-07-16 0001104659-03-014913 — 7, 9
- 2003-04-16 0001047469-03-013617 — 7, 9
- 2003-03-21 0001104659-03-004649 — 5, 7
- 2002-08-13 0000912057-02-031595 — 5, 7
- 2002-08-05 0000912057-02-029692 — 5, 7
- 2000-01-24 0000912057-00-002128 — 5, 7
- 1999-09-07 0000320193-99-000010 — 2
- 1999-07-16 0000320193-99-000007 — 2
- 1998-12-23 0000320193-98-000010 — 1
- 1998-01-08 0000320193-98-000001 — 2
- 1997-09-25 0000320193-97-000019 — 2
- 1997-09-25 0000320193-97-000018 — 2
- 1997-09-05 0000320193-97-000016 — 2
- 1997-07-28 0000320193-97-000012 — 4
- 1997-04-25 0000320193-97-000009 — 5
- 1997-04-10 0000320193-97-000007 — 7
- 1996-12-24 0000320193-96-000027 — 7
- 1996-12-23 0000320193-96-000025 — 4 — amendment of 0000320193-96-000021
- 1996-12-13 0000320193-96-000021 — 4
- 1996-10-28 0000912057-96-023874 — 5, 7
- 1996-06-17 0000320193-96-000014 — 1
- 1996-04-12 0000320193-96-000006 — 1

## late-filing notifications on or before 2020-01-29

- 2006-12-15 0001104659-06-081617 — NT 10-K, for the period ended 2006-09-30
- 2006-08-11 0001104659-06-053743 — NT 10-Q, for the period ended 2006-07-01

## item 2.02 — earnings release, exhibit 99.1

[0000320193-20-000008:8k_2_02:1]
EX-99.1
2
a8-kexhibit991q1202012.htm
EXHIBIT 99.1

[0000320193-20-000008:8k_2_02:2]
Exhibit

[0000320193-20-000008:8k_2_02:3]
Exhibit 99.1

[0000320193-20-000008:8k_2_02:4]
Apple Reports Record First Quarter Results

[0000320193-20-000008:8k_2_02:5]
iPhone, Wearables & Services Drive All-Time Record Revenue and Earnings

[0000320193-20-000008:8k_2_02:6]
CUPERTINO, California — January 28, 2020 — Apple® today announced financial results for its fiscal 2020 first quarter ended December 28, 2019. The Company posted quarterly revenue of $91.8 billion, an increase of 9 percent from the year-ago quarter and an all-time record, and quarterly earnings per diluted share of $4.99, up 19 percent, also an all-time record. International sales accounted for 61 percent of the quarter’s revenue.

[0000320193-20-000008:8k_2_02:7]
“We are thrilled to report Apple’s highest quarterly revenue ever, fueled by strong demand for our iPhone 11 and iPhone 11 Pro models, and all-time records for Services and Wearables,” said Tim Cook, Apple’s CEO. “During the holiday quarter our active installed base of devices grew in each of our geographic segments and has now reached over 1.5 billion. We see this as a powerful testament to the satisfaction, engagement and loyalty of our customers — and a great driver of our growth across the board.”

[0000320193-20-000008:8k_2_02:8]
“Our very strong business performance drove an all-time net income record of $22.2 billion and generated operating cash flow of $30.5 billion,” said Luca Maestri, Apple’s CFO. “We also returned nearly $25 billion to shareholders during the quarter, including $20 billion in share repurchases and $3.5 billion in dividends and equivalents, as we maintain our target of reaching a net cash neutral position over time.”

[0000320193-20-000008:8k_2_02:9]
Apple is providing the following guidance for its fiscal 2020 second quarter:

[0000320193-20-000008:8k_2_02:10]
| • | revenue between $63.0 billion and $67.0 billion |

[0000320193-20-000008:8k_2_02:11]
| • | gross margin between 38.0 percent and 39.0 percent |

[0000320193-20-000008:8k_2_02:12]
| • | operating expenses between $9.6 billion and $9.7 billion |

[0000320193-20-000008:8k_2_02:13]
| • | other income/(expense) of $250 million |

[0000320193-20-000008:8k_2_02:14]
| • | tax rate of approximately 16.5 percent |

[0000320193-20-000008:8k_2_02:15]
Apple’s board of directors has declared a cash dividend of $0.77 per share of the Company’s common stock. The dividend is payable on February 13, 2020 to shareholders of record as of the close of business on February 10, 2020.

[0000320193-20-000008:8k_2_02:16]
Apple will provide live streaming of its Q1 2020 financial results conference call beginning at 2:00 p.m. PT on January 28, 2020 at www.apple.com/investor/earnings-call/. This webcast will also be available for replay for approximately two weeks thereafter.

[0000320193-20-000008:8k_2_02:17]
Apple periodically provides information for investors on its corporate website, apple.com, and its investors relations website, investor.apple.com. This includes press releases and other information about financial performance, reports filed or furnished with the SEC, information on corporate governance and details related to its annual meeting of shareholders.

[0000320193-20-000008:8k_2_02:18]
Apple revolutionized personal technology with the introduction of the Macintosh in 1984. Today, Apple leads the world in innovation with iPhone, iPad, Mac, Apple Watch and Apple TV. Apple’s four software platforms — iOS, macOS, watchOS and tvOS — provide seamless experiences across all Apple devices and empower people with breakthrough services including the App Store, Apple Music, Apple Pay and iCloud. Apple’s more than 100,000 employees are dedicated to making the best products on earth, and to leaving the world better than we found it.

[0000320193-20-000008:8k_2_02:19]
Press Contact:

[0000320193-20-000008:8k_2_02:20]
Kristin Huguet Quayle

[0000320193-20-000008:8k_2_02:21]
Apple

[0000320193-20-000008:8k_2_02:22]
khuguet@apple.com

[0000320193-20-000008:8k_2_02:23]
(408) 974-2414

[0000320193-20-000008:8k_2_02:24]
Investor Relations Contact:

[0000320193-20-000008:8k_2_02:25]
Tejas Gala

[0000320193-20-000008:8k_2_02:26]
Apple

[0000320193-20-000008:8k_2_02:27]
tgala@apple.com

[0000320193-20-000008:8k_2_02:28]
(669) 227-2402

[0000320193-20-000008:8k_2_02:29]
NOTE TO EDITORS: For additional information visit Apple Newsroom (www.apple.com/newsroom), or call Apple’s Media Helpline at (408) 974-2042.

[0000320193-20-000008:8k_2_02:30]
© 2020 Apple Inc. All rights reserved. Apple and the Apple logo are trademarks of Apple. Other company and product names may be trademarks of their respective owners.

[0000320193-20-000008:8k_2_02:31]
Apple Inc.

[0000320193-20-000008:8k_2_02:32]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS (Unaudited)

[0000320193-20-000008:8k_2_02:33]
(In millions, except number of shares which are reflected in thousands and per share amounts)

[0000320193-20-000008:8k_2_02:34]
|  | Three Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |
| Net sales: |  |  |  |
| Products | $ | 79,104 |  |  | $ | 73,435 |  |
| Services | 12,715 |  |  | 10,875 |  |
| Total net sales (1) | 91,819 |  |  | 84,310 |  |
| Cost of sales: |  |  |  |
| Products | 52,075 |  |  | 48,238 |  |
| Services | 4,527 |  |  | 4,041 |  |
| Total cost of sales | 56,602 |  |  | 52,279 |  |
| Gross margin | 35,217 |  |  | 32,031 |  |
| Operating expenses: |  |  |  |
| Research and development | 4,451 |  |  | 3,902 |  |
| Selling, general and administrative | 5,197 |  |  | 4,783 |  |
| Total operating expenses | 9,648 |  |  | 8,685 |  |
| Operating income | 25,569 |  |  | 23,346 |  |
| Other income/(expense), net | 349 |  |  | 560 |  |
| Income before provision for income taxes | 25,918 |  |  | 23,906 |  |
| Provision for income taxes | 3,682 |  |  | 3,941 |  |
| Net income | $ | 22,236 |  |  | $ | 19,965 |  |
| Earnings per share: |  |  |  |
| Basic | $ | 5.04 |  |  | $ | 4.22 |  |
| Diluted | $ | 4.99 |  |  | $ | 4.18 |  |
| Shares used in computing earnings per share: |  |  |  |
| Basic | 4,415,040 |  |  | 4,735,820 |  |
| Diluted | 4,454,604 |  |  | 4,773,252 |  |
| (1) Net sales by reportable segment: |  |  |  |
| Americas | $ | 41,367 |  |  | $ | 36,940 |  |
| Europe | 23,273 |  |  | 20,363 |  |
| Greater China | 13,578 |  |  | 13,169 |  |
| Japan | 6,223 |  |  | 6,910 |  |
| Rest of Asia Pacific | 7,378 |  |  | 6,928 |  |
| Total net sales | $ | 91,819 |  |  | $ | 84,310 |  |
| (1) Net sales by category: |  |  |  |
| iPhone | $ | 55,957 |  |  | $ | 51,982 |  |
| Mac | 7,160 |  |  | 7,416 |  |
| iPad | 5,977 |  |  | 6,729 |  |
| Wearables, Home and Accessories | 10,010 |  |  | 7,308 |  |
| Services | 12,715 |  |  | 10,875 |  |
| Total net sales | $ | 91,819 |  |  | $ | 84,310 |  |

[0000320193-20-000008:8k_2_02:35]
Apple Inc.

[0000320193-20-000008:8k_2_02:36]
CONDENSED CONSOLIDATED BALANCE SHEETS (Unaudited)

[0000320193-20-000008:8k_2_02:37]
(In millions, except number of shares which are reflected in thousands and par value)

[0000320193-20-000008:8k_2_02:38]
|  | December 28, 2019 |  | September 28, 2019 |
| ASSETS: |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 39,771 |  |  | $ | 48,844 |  |
| Marketable securities | 67,391 |  |  | 51,713 |  |
| Accounts receivable, net | 20,970 |  |  | 22,926 |  |
| Inventories | 4,097 |  |  | 4,106 |  |
| Vendor non-trade receivables | 18,976 |  |  | 22,878 |  |
| Other current assets | 12,026 |  |  | 12,352 |  |
| Total current assets | 163,231 |  |  | 162,819 |  |
| Non-current assets: |  |  |  |
| Marketable securities | 99,899 |  |  | 105,341 |  |
| Property, plant and equipment, net | 37,031 |  |  | 37,378 |  |
| Other non-current assets | 40,457 |  |  | 32,978 |  |
| Total non-current assets | 177,387 |  |  | 175,697 |  |
| Total assets | $ | 340,618 |  |  | $ | 338,516 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY: |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 45,111 |  |  | $ | 46,236 |  |
| Other current liabilities | 36,263 |  |  | 37,720 |  |
| Deferred revenue | 5,573 |  |  | 5,522 |  |
| Commercial paper | 4,990 |  |  | 5,980 |  |
| Term debt | 10,224 |  |  | 10,260 |  |
| Total current liabilities | 102,161 |  |  | 105,718 |  |
| Non-current liabilities: |  |  |  |
| Term debt | 93,078 |  |  | 91,807 |  |
| Other non-current liabilities | 55,848 |  |  | 50,503 |  |
| Total non-current liabilities | 148,926 |  |  | 142,310 |  |
| Total liabilities | 251,087 |  |  | 248,028 |  |
| Commitments and contingencies |  |  |  |
| Shareholders’ equity: |  |  |  |
| Common stock and additional paid-in capital, $0.00001 par value: 12,600,000 shares authorized; 4,384,959 and 4,443,236 shares issued and outstanding, respectively | 45,972 |  |  | 45,174 |  |
| Retained earnings | 43,977 |  |  | 45,898 |  |
| Accumulated other comprehensive income/(loss) | (418 | ) |  | (584 | ) |
| Total shareholders’ equity | 89,531 |  |  | 90,488 |  |
| Total liabilities and shareholders’ equity | $ | 340,618 |  |  | $ | 338,516 |  |

[0000320193-20-000008:8k_2_02:39]
Apple Inc.

[0000320193-20-000008:8k_2_02:40]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (Unaudited)

[0000320193-20-000008:8k_2_02:41]
(In millions)

[0000320193-20-000008:8k_2_02:42]
|  | Three Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |
| Cash, cash equivalents and restricted cash, beginning balances | $ | 50,224 |  |  | $ | 25,913 |  |
| Operating activities: |  |  |  |
| Net income | 22,236 |  |  | 19,965 |  |
| Adjustments to reconcile net income to cash generated by operating activities: |  |  |  |
| Depreciation and amortization | 2,816 |  |  | 3,395 |  |
| Share-based compensation expense | 1,710 |  |  | 1,559 |  |
| Deferred income tax expense/(benefit) | (349 | ) |  | 53 |  |
| Other | (142 | ) |  | (54 | ) |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | 2,015 |  |  | 5,130 |  |
| Inventories | (28 | ) |  | (1,076 | ) |
| Vendor non-trade receivables | 3,902 |  |  | 6,905 |  |
| Other current and non-current assets | (7,054 | ) |  | (886 | ) |
| Accounts payable | (1,089 | ) |  | (8,501 | ) |
| Deferred revenue | 985 |  |  | (370 | ) |
| Other current and non-current liabilities | 5,514 |  |  | 570 |  |
| Cash generated by operating activities | 30,516 |  |  | 26,690 |  |
| Investing activities: |  |  |  |
| Purchases of marketable securities | (37,416 | ) |  | (7,077 | ) |
| Proceeds from maturities of marketable securities | 19,740 |  |  | 7,203 |  |
| Proceeds from sales of marketable securities | 7,280 |  |  | 9,723 |  |
| Payments for acquisition of property, plant and equipment | (2,107 | ) |  | (3,355 | ) |
| Payments made in connection with business acquisitions, net | (958 | ) |  | (167 | ) |
| Purchases of non-marketable securities | (77 | ) |  | (427 | ) |
| Other | (130 | ) |  | (56 | ) |
| Cash generated by/(used in) investing activities | (13,668 | ) |  | 5,844 |  |
| Financing activities: |  |  |  |
| Proceeds from issuance of common stock | 2 |  |  | — |  |
| Payments for taxes related to net share settlement of equity awards | (1,379 | ) |  | (1,318 | ) |
| Payments for dividends and dividend equivalents | (3,539 | ) |  | (3,568 | ) |
| Repurchases of common stock | (20,706 | ) |  | (8,796 | ) |
| Proceeds from issuance of term debt, net | 2,210 |  |  | — |  |
| Repayments of term debt | (1,000 | ) |  | — |  |
| Proceeds from/(Repayments of) commercial paper, net | (979 | ) |  | 6 |  |
| Other | (16 | ) |  | — |  |
| Cash used in financing activities | (25,407 | ) |  | (13,676 | ) |
| Increase/(Decrease) in cash, cash equivalents and restricted cash | (8,559 | ) |  | 18,858 |  |
| Cash, cash equivalents and restricted cash, ending balances | $ | 41,665 |  |  | $ | 44,771 |  |
| Supplemental cash flow disclosure: |  |  |  |
| Cash paid for income taxes, net | $ | 4,393 |  |  | $ | 4,916 |  |
| Cash paid for interest | $ | 771 |  |  | $ | 836 |  |
