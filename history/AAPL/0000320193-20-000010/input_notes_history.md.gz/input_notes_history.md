# AAPL note change history — 0000320193-19-000076 → 0000320193-20-000010


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-01-29):
[0000320193-20-000010:note_history:1]
Commitments and Contingencies
Accrued Warranty and Guarantees
  (was, 2019-07-31, similarity 0.8346):
[0000320193-19-000076:note_history:1]
Commitments and Contingencies
Accrued Warranty and Indemnification

- changed (2020-01-29):
[0000320193-20-000010:note_history:2]
The following table shows changes in the Company’s accrued warranties and related costs for the three months ended December 28, 2019 and December 29, 2018 (in millions):
  (was, 2019-07-31, similarity 0.8869):
[0000320193-19-000076:note_history:2]
The following table shows changes in the Company’s accrued warranties and related costs for the three- and nine-month periods ended June 29, 2019 and June 30, 2018 (in millions):

- changed (2020-01-29):
[0000320193-20-000010:note_history:3]
|  | Three Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |
| Beginning accrued warranty and related costs | $ | 3,570 |  |  | $ | 3,692 |  |
| Cost of warranty claims | (915 | ) |  | (996 | ) |
| Accruals for product warranty | 1,218 |  |  | 1,123 |  |
| Ending accrued warranty and related costs | $ | 3,873 |  |  | $ | 3,819 |  |
  (was, 2019-07-31, similarity 0.7514):
[0000320193-19-000076:note_history:3]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| Beginning accrued warranty and related costs | $ | 3,487 |  |  | $ | 4,030 |  |  | $ | 3,692 |  |  | $ | 3,834 |  |
| Cost of warranty claims | (912 | ) |  | (1,044 | ) |  | (2,823 | ) |  | (2,959 | ) |
| Accruals for product warranty | 548 |  |  | 567 |  |  | 2,254 |  |  | 2,678 |  |
| Ending accrued warranty and related costs | $ | 3,123 |  |  | $ | 3,553 |  |  | $ | 3,123 |  |  | $ | 3,553 |  |

- changed (2020-01-29):
[0000320193-20-000010:note_history:4]
Although most components essential to the Company’s business are generally available from multiple sources, certain components are currently obtained from single or limited sources. The Company also competes for various components with other participants in the markets for smartphones, personal computers, tablets and other electronic devices. Therefore, many components used by the Company, including those that are available from multiple sources, are at times subject to industry-wide shortage and significant commodity pricing fluctuations.
  (was, 2019-07-31, similarity 0.7916):
[0000320193-19-000076:note_history:4]
Although most components essential to the Company’s business are generally available from multiple sources, certain components are currently obtained from single or limited sources. In addition, the Company competes for various components with other participants in the markets for mobile communication and media devices and personal computers. Therefore, many components used by the Company, including those that are available from multiple sources, are at times subject to industry-wide shortage and significant commodity pricing fluctuations that could materially adversely affect the Company’s financial condition and operating results.

- changed (2020-01-29):
[0000320193-20-000010:note_history:5]
The Company uses some custom components that are not commonly used by its competitors, and new products introduced by the Company often utilize custom components available from only one source. When a component or product uses new technologies, initial capacity constraints may exist until the suppliers’ yields have matured or their manufacturing capacities have increased. The continued availability of these components at acceptable prices, or at all, may be affected if suppliers decide to concentrate on the production of common components instead of components customized to meet the Company’s requirements.
  (was, 2019-07-31, similarity 0.6221):
[0000320193-19-000076:note_history:5]
The Company uses some custom components that are not commonly used by its competitors, and new products introduced by the Company often utilize custom components available from only one source. When a component or product uses new technologies, initial capacity constraints may exist until the suppliers’ yields have matured or manufacturing capacity has increased. If the Company’s supply of components for a new or existing product were delayed or constrained, or if an outsourcing partner delayed shipments of completed products to the Company, the Company’s financial condition and operating results could be materially adversely affected. The Company’s business and financial performance could also be materially adversely affected depending on the time required to obtain sufficient quantities from the original source, or to identify and obtain sufficient quantities from an alternative source. Continued availability of these components at acceptable prices, or at all, may be affected if suppliers decide to concentrate on the production of common components instead of components customized to meet the Company’s requirements.

- changed (2020-01-29):
[0000320193-20-000010:note_history:6]
The Company has entered into agreements for the supply of many components; however, there can be no guarantee that the Company will be able to extend or renew these agreements on similar terms, or at all.
  (was, 2019-07-31, similarity 0.6869):
[0000320193-19-000076:note_history:6]
The Company has entered into agreements for the supply of many components; however, there can be no guarantee that the Company will be able to extend or renew these agreements on similar terms, or at all. Therefore, the Company remains subject to significant risks of supply shortages and price increases that could materially adversely affect its financial condition and operating results.

- added (2020-01-29):
[0000320193-20-000010:note_history:7]
Substantially all of the Company’s hardware products are manufactured by outsourcing partners that are located primarily in Asia, with some Mac computers manufactured in the U.S. and Ireland.

- changed (2020-01-29):
[0000320193-20-000010:note_history:8]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of payments for supplier arrangements, Internet and telecommunication services, intellectual property licenses and content creation. As of December 28, 2019, the Company’s total future payments under noncancelable unconditional purchase obligations having a remaining term in excess of one year were $10.5 billion.
  (was, 2019-07-31, similarity 0.9887):
[0000320193-19-000076:note_history:8]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of payments for supplier arrangements, internet and telecommunication services, intellectual property licenses and content creation. As of June 29, 2019, the Company’s total future payments under noncancelable unconditional purchase obligations having a remaining term in excess of one year were $8.1 billion.

- added (2020-01-29):
[0000320193-20-000010:note_history:9]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully resolved. The outcome of litigation is inherently uncertain. If one or more legal matters were resolved against the Company in a reporting period for amounts above management’s expectations, the Company’s financial condition and operating results for that reporting period could be materially adversely affected. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss greater than a recorded accrual, concerning loss contingencies for asserted legal and other claims, except for the following matters:

- changed (2020-01-29):
[0000320193-20-000010:note_history:10]
VirnetX, Inc. (“VirnetX”) filed two lawsuits in the U.S. District Court for the Eastern District of Texas (the “Eastern Texas District Court”) against the Company alleging that certain Company products infringe four patents (the “VirnetX Patents”) relating to network communications technology (“VirnetX I” and “VirnetX II”). On September 30, 2016, a jury returned a verdict in VirnetX I against the Company and awarded damages of $302 million, which later increased to $440 million in post-trial proceedings. The Company appealed the VirnetX I verdict to the U.S. Court of Appeals for the Federal Circuit (the “Federal Circuit”). On April 11, 2018, a jury returned a verdict in VirnetX II against the Company and awarded damages of $503 million. The Company appealed the VirnetX II verdict to the Federal Circuit, and on November 22, 2019, the Federal Circuit affirmed-in-part, reversed-in-part, and remanded VirnetX II back to the Eastern Texas District Court. The Company has challenged the validity of the VirnetX Patents at the U.S. Patent and Trademark Office (the “PTO”). In response, the PTO has declared the VirnetX Patents invalid. VirnetX appealed the invalidity decision of the PTO to the Federal Circuit. The Federal Circuit consolidated the Company’s appeal of the Eastern Texas District Court VirnetX I verdict and VirnetX’s appeals from the PTO invalidity proceedings. On January 15, 2019, the Federal Circuit affirmed the VirnetX I verdict, which the Company has further appealed. On July 8, 2019, the Federal Circuit remanded one of VirnetX’s two appeals of the PTO’s invalidity decisions back to the PTO for further proceedings. On August 1, 2019, the Federal Circuit affirmed-in-part, vacated-in-part, and remanded back to the PTO portions of VirnetX’s second appeal. The Company has accrued its best estimate for the ultimate resolution of these matters.
  (was, 2019-07-31, similarity 0.7504):
[0000320193-19-000076:note_history:10]
VirnetX, Inc. (“VirnetX”) filed two lawsuits in the U.S. District Court for the Eastern District of Texas (the “Eastern Texas District Court”) against the Company alleging that certain Company products infringe four patents (the “VirnetX Patents”) relating to network communications technology (“VirnetX I” and “VirnetX II”). On September 30, 2016, a jury returned a verdict in VirnetX I against the Company and awarded damages of $302 million, which later increased to $440 million in post-trial proceedings. The Company appealed the VirnetX I verdict to the U.S. Court of Appeals for the Federal Circuit (the “Federal Circuit”). On April 11, 2018, a jury returned a verdict in VirnetX II against the Company and awarded damages of $503 million. VirnetX II is currently on appeal. The Company has challenged the validity of the VirnetX Patents at the U.S. Patent and Trademark Office (the “PTO”). In response, the PTO has declared the VirnetX Patents invalid. VirnetX appealed the invalidity decision of the PTO to the Federal Circuit. The Federal Circuit consolidated the Company’s appeal of the Eastern Texas District Court VirnetX I verdict and VirnetX’s appeals from the PTO invalidity proceedings. On January 15, 2019, the Federal Circuit affirmed the VirnetX I verdict, which the Company intends to further appeal. On July 8, 2019, the Federal Circuit remanded one of VirnetX’s appeals of the PTO’s invalidity decisions back to the PTO for further proceedings. VirnetX’s other remaining appeal of the PTO’s invalidity decisions remains pending with the Federal Circuit. The Company has accrued its best estimate for the ultimate resolution of these matters.

- added (2020-01-29):
[0000320193-20-000010:note_history:11]
French Competition Authority

- added (2020-01-29):
[0000320193-20-000010:note_history:12]
In June 2019, the French Competition Authority (“FCA”) issued a report alleging that aspects of the Company’s sales and distribution practices in France violate French competition law. The Company vigorously disagrees with the allegations, and a hearing of arguments was held before the FCA on October 15, 2019. The Company is awaiting the decision of the FCA, which may include a fine.

- removed (2020-01-29):
[0000320193-19-000076:note_history:13]
Agreements entered into by the Company may include indemnification provisions, which may subject the Company to costs and damages in the event of a claim against an indemnified third party. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to indemnification of third parties.

- removed (2020-01-29):
[0000320193-19-000076:note_history:14]
The Company has entered into indemnification agreements with its directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers of the Company, and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. While the Company maintains directors and officers liability insurance coverage, such insurance coverage may be insufficient to cover all losses or all types of claims that may arise.

- removed (2020-01-29):
[0000320193-19-000076:note_history:15]
Substantially all of the Company’s hardware products are manufactured by outsourcing partners that are located primarily in Asia, with some Mac computers manufactured in the U.S. and Ireland. A significant concentration of this manufacturing is currently performed by a small number of outsourcing partners, often in single locations. Certain of these outsourcing partners are single-sourced suppliers of components and manufacturers for many of the Company’s products. Although the Company works closely with its outsourcing partners on manufacturing schedules, the Company’s financial condition and operating results could be materially adversely affected if its outsourcing partners were unable to meet their production commitments. The Company’s manufacturing purchase obligations typically cover its requirements for periods up to 150 days.

- removed (2020-01-29):
[0000320193-19-000076:note_history:16]
Other Off–Balance Sheet Commitments

- removed (2020-01-29):
[0000320193-19-000076:note_history:17]
Operating Leases

- removed (2020-01-29):
[0000320193-19-000076:note_history:18]
The Company leases various equipment and facilities, including retail space, under noncancelable operating lease arrangements. The Company does not currently utilize any other off–balance sheet financing arrangements. As of June 29, 2019, the Company’s total future minimum lease payments under noncancelable operating leases were $11.1 billion. The Company’s retail store and other facility leases typically have original terms not exceeding 10 years and generally contain multi-year renewal options.

- removed (2020-01-29):
[0000320193-19-000076:note_history:19]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully adjudicated, as further discussed in Part II, Item 1 of this Form 10-Q under the heading “Legal Proceedings” and in Part II, Item 1A of this Form 10-Q under the heading “Risk Factors.” The outcome of litigation is inherently uncertain. If one or more legal matters were resolved against the Company in a reporting period for amounts in excess of management’s expectations, the Company’s financial condition and operating results for that reporting period could be materially adversely affected. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to loss contingencies for asserted legal and other claims, except for the following matters:

- removed (2020-01-29):
[0000320193-19-000076:note_history:20]
Qualcomm

- removed (2020-01-29):
[0000320193-19-000076:note_history:21]
On January 20, 2017, the Company filed a lawsuit against Qualcomm Incorporated and affiliated parties (“Qualcomm”) in the U.S. District Court for the Southern District of California seeking, among other things, to enjoin Qualcomm from requiring the Company to pay royalties at the rate demanded by Qualcomm. No Qualcomm-related royalty payments had been remitted by the Company to its contract manufacturers since the beginning of the second quarter of 2017. Following the Company’s lawsuit, Qualcomm filed patent infringement suits against the Company and its affiliates in the U.S. and various international jurisdictions, some of which sought to enjoin the sale of certain of the Company’s products in particular countries.

- removed (2020-01-29):
[0000320193-19-000076:note_history:22]
On April 16, 2019, the Company and Qualcomm reached a settlement agreement to dismiss all litigation between the two companies worldwide. The companies also reached a multi-year license agreement and a multi-year supply agreement. Under the terms of the settlement agreement, Apple made a payment to Qualcomm to, among other things, resolve disputes over the withheld royalty payments.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-01-29):
[0000320193-20-000010:note_history:23]
The condensed consolidated financial statements include the accounts of Apple Inc. and its wholly owned subsidiaries (collectively “Apple” or the “Company”). Intercompany accounts and transactions have been eliminated. In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements and accompanying notes in conformity with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported. Actual results could differ materially from those estimates. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company’s annual consolidated financial statements and accompanying notes included in its Annual Report on Form 10-K for the fiscal year ended September 28, 2019 (the “2019 Form 10-K”).
  (was, 2019-07-31, similarity 0.8913):
[0000320193-19-000076:note_history:23]
The accompanying condensed consolidated financial statements include the accounts of Apple Inc. and its wholly owned subsidiaries (collectively “Apple” or the “Company”). Intercompany accounts and transactions have been eliminated. In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements and accompanying notes in conformity with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported. Actual results could differ materially from those estimates. Certain prior period amounts in the condensed consolidated financial statements and accompanying notes have been reclassified to conform to the current period’s presentation. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company’s annual consolidated financial statements and the notes thereto included in its Annual Report on Form 10-K for the fiscal year ended September 29, 2018 (the “2018 Form 10-K”).

- added (2020-01-29):
[0000320193-20-000010:note_history:24]
Leases

- added (2020-01-29):
[0000320193-20-000010:note_history:25]
At the beginning of the first quarter of 2020, the Company adopted the Financial Accounting Standards Board’s (the “FASB”) Accounting Standards Update (“ASU”) No. 2016-02, Leases (Topic 842) (“ASU 2016-02”), and additional ASUs issued to clarify and update the guidance in ASU 2016-02 (collectively, the “new leases standard”), which modifies lease accounting for lessees to increase transparency and comparability by recording lease assets and liabilities for operating leases and disclosing key information about leasing arrangements. The Company adopted the new leases standard utilizing the modified retrospective transition method, under which amounts in prior periods presented were not restated. For contracts existing at the time of adoption, the Company elected to not reassess (i) whether any are or contain leases, (ii) lease classification, and (iii) initial direct costs. Upon adoption, the Company recorded $7.5 billion of right-of-use (“ROU”) assets and $8.1 billion of lease liabilities on its Condensed Consolidated Balance Sheet.

- added (2020-01-29):
[0000320193-20-000010:note_history:26]
Hedging

- added (2020-01-29):
[0000320193-20-000010:note_history:27]
At the beginning of the first quarter of 2020, the Company adopted FASB ASU No. 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities (“ASU 2017-12”). ASU 2017-12 expands component and fair value hedging, specifies the presentation of the effects of hedging instruments, eliminates the separate measurement and presentation of hedge ineffectiveness, and updates disclosure requirements related to hedging. The Company adopted ASU 2017-12 utilizing the modified retrospective transition method. Upon adoption, the Company recorded a $136 million increase in accumulated other comprehensive income/(loss) (“AOCI”) and a corresponding decrease in retained earnings in the Condensed Consolidated Statement of Shareholders’ Equity.

- changed (2020-01-29):
[0000320193-20-000010:note_history:28]
The following table shows the computation of basic and diluted earnings per share for the three months ended December 28, 2019 and December 29, 2018 (net income in millions and shares in thousands):
  (was, 2019-07-31, similarity 0.9039):
[0000320193-19-000076:note_history:28]
The following table shows the computation of basic and diluted earnings per share for the three- and nine-month periods ended June 29, 2019 and June 30, 2018 (net income in millions and shares in thousands):

- added (2020-01-29):
[0000320193-20-000010:note_history:29]
|  | Three Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |
| Numerator: |  |  |  |
| Net income | $ | 22,236 |  |  | $ | 19,965 |  |
| Denominator: |  |  |  |
| Weighted-average basic shares outstanding | 4,415,040 |  |  | 4,735,820 |  |
| Effect of dilutive securities | 39,564 |  |  | 37,432 |  |
| Weighted-average diluted shares | 4,454,604 |  |  | 4,773,252 |  |
| Basic earnings per share | $ | 5.04 |  |  | $ | 4.22 |  |
| Diluted earnings per share | $ | 4.99 |  |  | $ | 4.18 |  |

- changed (2020-01-29):
[0000320193-20-000010:note_history:30]
Potentially dilutive securities representing 28.8 million shares of common stock were excluded from the computation of diluted earnings per share for the three months ended December 29, 2018, because their effect would have been antidilutive.
  (was, 2019-07-31, similarity 0.6982):
[0000320193-19-000076:note_history:30]
Potentially dilutive securities representing 1.5 million and 20.5 million shares of common stock were excluded from the computation of diluted earnings per share for the three- and nine-month periods ended June 29, 2019, respectively, because their effect would have been antidilutive.

- removed (2020-01-29):
[0000320193-19-000076:note_history:31]
Revenue Recognition

- removed (2020-01-29):
[0000320193-19-000076:note_history:32]
In the first quarter of 2019, the Company adopted the Financial Accounting Standards Board’s (the “FASB”) Accounting Standards Update (“ASU”) No. 2014-09, Revenue from Contracts with Customers (Topic 606) (“ASU 2014-09”), and additional ASUs issued to clarify the guidance in ASU 2014-09 (collectively the “new revenue standard”), which amends the existing accounting standards for revenue recognition. The Company adopted the new revenue standard utilizing the full retrospective transition method. The Company did not restate total net sales in the prior periods presented, as adoption of the new revenue standard did not have a material impact on previously reported amounts.

- removed (2020-01-29):
[0000320193-19-000076:note_history:33]
Additionally, beginning in the first quarter of 2019, the Company classified the amortization of the deferred value of Maps, Siri® and free iCloud® services, which are bundled in the sales price of iPhone®, Mac®, iPad® and certain other products, in services net sales. Historically, the Company classified the amortization of these amounts in products net sales consistent with its management reporting framework. As a result, products and services net sales information for the third quarter and first nine months of 2018 was reclassified to conform to the 2019 presentation.

- removed (2020-01-29):
[0000320193-19-000076:note_history:34]
Financial Instruments

- removed (2020-01-29):
[0000320193-19-000076:note_history:35]
In the first quarter of 2019, the Company adopted FASB ASU No. 2016-01, Financial Instruments – Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities (“ASU 2016-01”), which updates certain aspects of the recognition, measurement, presentation and disclosure of financial instruments. The adoption of ASU 2016-01 did not have a material impact on the Company’s condensed consolidated financial statements.

- removed (2020-01-29):
[0000320193-19-000076:note_history:36]
Income Taxes

- removed (2020-01-29):
[0000320193-19-000076:note_history:37]
In the first quarter of 2019, the Company adopted FASB ASU No. 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory (“ASU 2016-16”), which requires the recognition of the income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. The Company adopted ASU 2016-16 utilizing the modified retrospective transition method. Upon adoption, the Company recorded $2.7 billion of net deferred tax assets, reduced other non-current assets by $128 million, and increased retained earnings by $2.6 billion on its Condensed Consolidated Balance Sheet. The Company will recognize incremental deferred income tax expense as these net deferred tax assets are utilized.

- removed (2020-01-29):
[0000320193-19-000076:note_history:38]
Restricted Cash

- removed (2020-01-29):
[0000320193-19-000076:note_history:39]
In the first quarter of 2019, the Company adopted FASB ASU No. 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash (“ASU 2016-18”), which enhances and clarifies the guidance on the classification and presentation of restricted cash in the statement of cash flows and requires additional disclosures about restricted cash balances.

- removed (2020-01-29):
[0000320193-19-000076:note_history:40]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 10,044 |  |  | $ | 11,519 |  |  | $ | 41,570 |  |  | $ | 45,406 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 4,570,633 |  |  | 4,882,167 |  |  | 4,660,175 |  |  | 5,006,640 |  |
| Effect of dilutive securities | 30,747 |  |  | 44,442 |  |  | 31,584 |  |  | 44,323 |  |
| Weighted-average diluted shares | 4,601,380 |  |  | 4,926,609 |  |  | 4,691,759 |  |  | 5,050,963 |  |
| Basic earnings per share | $ | 2.20 |  |  | $ | 2.36 |  |  | $ | 8.92 |  |  | $ | 9.07 |  |
| Diluted earnings per share | $ | 2.18 |  |  | $ | 2.34 |  |  | $ | 8.86 |  |  | $ | 8.99 |  |

- removed (2020-01-29):
[0000320193-19-000076:note_history:41]
Restricted Cash and Restricted Marketable Securities

- removed (2020-01-29):
[0000320193-19-000076:note_history:42]
The Company considers cash and marketable securities to be restricted when withdrawal or general use is legally restricted. The Company records restricted cash as other assets in the Condensed Consolidated Balance Sheets, and determines current or non-current classification based on the expected duration of the restriction. The Company records restricted marketable securities as current or non-current marketable securities in the Condensed Consolidated Balance Sheets based on the classification of the underlying securities.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2020-01-29):
[0000320193-20-000010:note_history:43]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of December 28, 2019 and September 28, 2019, the Company had $5.0 billion and $6.0 billion of Commercial Paper outstanding, respectively, with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 1.88% and 2.24% as of December 28, 2019 and September 28, 2019, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the three months ended December 28, 2019 and December 29, 2018 (in millions):

- added (2020-01-29):
[0000320193-20-000010:note_history:44]
|  | Three Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | (175 | ) |  | $ | 2,011 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 1,317 |  |  | 2,166 |  |
| Repayments of commercial paper | (2,121 | ) |  | (4,171 | ) |
| Repayments of commercial paper, net | (804 | ) |  | (2,005 | ) |
| Total proceeds from/(repayments of) commercial paper, net | $ | (979 | ) |  | $ | 6 |  |

- added (2020-01-29):
[0000320193-20-000010:note_history:45]
As of December 28, 2019, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $103.1 billion (collectively the “Notes”). The Notes are senior unsecured obligations and interest is payable in arrears. The following table provides a summary of the Company’s term debt as of December 28, 2019 and September 28, 2019:

- added (2020-01-29):
[0000320193-20-000010:note_history:46]
|  | Maturities(calendar year) |  | December 28, 2019 |  | September 28, 2019 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 – 2019 debt issuances: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2020 | – | 2022 |  | $ | 4,250 |  |  |  | 1.97% | – | 3.04 | % |  | $ | 4,250 |  |  |  | 2.25% | – | 3.28 | % |
| Fixed-rate 0.350% – 4.650% notes | 2020 | – | 2049 |  | 96,610 |  |  |  | 0.28% | – | 4.78 | % |  | 97,429 |  |  |  | 0.28% | – | 4.78 | % |
| First quarter 2020 debt issuance of €2.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.000% – 0.500% notes | 2025 | – | 2031 |  | 2,226 |  |  |  | 0.03% | – | 0.56 | % |  | — |  |  |  |  |  | — | % |
| Total term debt |  |  |  |  | 103,086 |  |  |  |  |  |  |  | 101,679 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (229 | ) |  |  |  |  |  |  | (224 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | 445 |  |  |  |  |  |  |  | 612 |  |  |  |  |  |  |
| Less: Current portion of term debt |  |  |  |  | (10,224 | ) |  |  |  |  |  |  | (10,260 | ) |  |  |  |  |  |
| Total non-current portion of term debt |  |  |  |  | $ | 93,078 |  |  |  |  |  |  |  | $ | 91,807 |  |  |  |  |  |  |

- changed (2020-01-29):
[0000320193-20-000010:note_history:47]
A portion of the Company’s Japanese yen–denominated notes is designated as a hedge of the foreign currency exposure of the Company’s net investment in a foreign operation. As of December 28, 2019 and September 28, 2019, the carrying value of the debt designated as a net investment hedge was $1.2 billion and $1.0 billion, respectively. For further discussion regarding the Company’s use of derivative instruments, refer to the Derivative Financial Instruments section of Note 3, “Financial Instruments.”
  (was, 2019-07-31, similarity 0.786):
[0000320193-19-000076:note_history:47]
A portion of the Company’s Japanese yen–denominated notes is designated as a hedge of the foreign currency exposure of the Company’s net investment in a foreign operation. As of June 29, 2019 and September 29, 2018, the carrying value of the debt designated as a net investment hedge was $1.2 billion and $811 million, respectively. For further discussion regarding the Company’s use of derivative instruments, refer to the Derivative Financial Instruments section of Note 3, “Financial Instruments.”

- added (2020-01-29):
[0000320193-20-000010:note_history:48]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $757 million and $809 million of interest cost on its term debt for the three months ended December 28, 2019 and December 29, 2018, respectively.

- changed (2020-01-29):
[0000320193-20-000010:note_history:49]
As of December 28, 2019 and September 28, 2019, the fair value of the Company’s Notes, based on Level 2 inputs, was $109.1 billion and $107.5 billion, respectively.
  (was, 2019-07-31, similarity 0.965):
[0000320193-19-000076:note_history:49]
As of June 29, 2019 and September 29, 2018, the fair value of the Company’s Notes, based on Level 2 inputs, was $102.5 billion and $103.2 billion, respectively.

- removed (2020-01-29):
[0000320193-19-000076:note_history:50]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of June 29, 2019 and September 29, 2018, the Company had $10.0 billion and $12.0 billion of Commercial Paper outstanding, respectively, with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 2.49% and 2.18% as of June 29, 2019 and September 29, 2018, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the nine months ended June 29, 2019 and June 30, 2018 (in millions):

- removed (2020-01-29):
[0000320193-19-000076:note_history:51]
|  | Nine Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | (3,720 | ) |  | $ | 2,619 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 12,977 |  |  | 9,782 |  |
| Repayments of commercial paper | (11,283 | ) |  | (12,411 | ) |
| Proceeds from/(Repayments of) commercial paper, net | 1,694 |  |  | (2,629 | ) |
| Total repayments of commercial paper, net | $ | (2,026 | ) |  | $ | (10 | ) |

- removed (2020-01-29):
[0000320193-19-000076:note_history:52]
As of June 29, 2019, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $98.3 billion (collectively the “Notes”). The Notes are senior unsecured obligations, and interest is payable in arrears, quarterly for the U.S. dollar–denominated and Australian dollar–denominated floating-rate notes, semi-annually for the U.S. dollar–denominated, Australian dollar–denominated, British pound–denominated, Japanese yen–denominated and Canadian dollar–denominated fixed-rate notes and annually for the euro-denominated and Swiss franc–denominated fixed-rate notes.

- removed (2020-01-29):
[0000320193-19-000076:note_history:53]
The following table provides a summary of the Company’s term debt as of June 29, 2019 and September 29, 2018:

- removed (2020-01-29):
[0000320193-19-000076:note_history:54]
|  | Maturities(calendar year) |  | June 29, 2019 |  | September 29, 2018 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 2.400% – 3.850% notes | 2023 | – | 2043 |  | $ | 8,500 |  |  |  | 2.44% | – | 3.91 | % |  | $ | 8,500 |  |  |  | 2.44% | – | 3.91 | % |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | — |  | — |  |  |  |  |  | — | % |  | 1,000 |  |  |  |  |  | 2.64 | % |
| Fixed-rate 2.850% – 4.450% notes | 2021 | – | 2044 |  | 6,500 |  |  |  | 3.12% | – | 4.48 | % |  | 8,500 |  |  |  | 2.64% | – | 4.48 | % |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2020 |  | 1,488 |  |  |  | 1.87% | – | 2.84 | % |  | 1,507 |  |  |  | 1.87% | – | 2.64 | % |
| Fixed-rate 0.350% – 4.375% notes | 2019 | – | 2045 |  | 24,223 |  |  |  | 0.28% | – | 4.51 | % |  | 24,410 |  |  |  | 0.28% | – | 4.51 | % |
| 2016 debt issuances of $24.9 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2021 |  | 850 |  |  |  | 2.71% | – | 3.65 | % |  | 1,350 |  |  |  | 2.48% | – | 3.44 | % |
| Fixed-rate 1.100% – 4.650% notes | 2019 | – | 2046 |  | 22,022 |  |  |  | 1.13% | – | 4.78 | % |  | 23,059 |  |  |  | 1.13% | – | 4.78 | % |
| 2017 debt issuances of $28.7 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2020 | – | 2022 |  | 2,750 |  |  |  | 2.61% | – | 3.06 | % |  | 3,250 |  |  |  | 2.41% | – | 2.84 | % |
| Fixed-rate 0.875% – 4.300% notes | 2019 | – | 2047 |  | 24,989 |  |  |  | 1.54% | – | 4.30 | % |  | 25,617 |  |  |  | 1.54% | – | 4.30 | % |
| 2018 debt issuance of $7.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 1.800% – 3.750% notes | 2019 | – | 2047 |  | 7,000 |  |  |  | 1.83% | – | 3.80 | % |  | 7,000 |  |  |  | 1.83% | – | 3.80 | % |
| Total term debt |  |  |  |  | 98,322 |  |  |  |  |  |  |  | 104,193 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (194 | ) |  |  |  |  |  |  | (218 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | 337 |  |  |  |  |  |  |  | (1,456 | ) |  |  |  |  |  |
| Less: Current portion of term debt |  |  |  |  | (13,529 | ) |  |  |  |  |  |  | (8,784 | ) |  |  |  |  |  |
| Total non-current portion of term debt |  |  |  |  | $ | 84,936 |  |  |  |  |  |  |  | $ | 93,735 |  |  |  |  |  |  |

- removed (2020-01-29):
[0000320193-19-000076:note_history:55]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $790 million and $2.4 billion of interest cost on its term debt for the three- and nine-month periods ended June 29, 2019, respectively. The Company recognized $780 million and $2.2 billion of interest cost on its term debt for the three- and nine-month periods ended June 30, 2018, respectively.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-01-29):
[0000320193-20-000010:note_history:56]
The following table provides a summary of the Company’s term debt as of December 28, 2019 and September 28, 2019:
  (was, 2019-07-31, similarity 0.9505):
[0000320193-19-000076:note_history:56]
The following table provides a summary of the Company’s term debt as of June 29, 2019 and September 29, 2018:

- added (2020-01-29):
[0000320193-20-000010:note_history:57]
|  | Maturities(calendar year) |  | December 28, 2019 |  | September 28, 2019 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 – 2019 debt issuances: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2020 | – | 2022 |  | $ | 4,250 |  |  |  | 1.97% | – | 3.04 | % |  | $ | 4,250 |  |  |  | 2.25% | – | 3.28 | % |
| Fixed-rate 0.350% – 4.650% notes | 2020 | – | 2049 |  | 96,610 |  |  |  | 0.28% | – | 4.78 | % |  | 97,429 |  |  |  | 0.28% | – | 4.78 | % |
| First quarter 2020 debt issuance of €2.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.000% – 0.500% notes | 2025 | – | 2031 |  | 2,226 |  |  |  | 0.03% | – | 0.56 | % |  | — |  |  |  |  |  | — | % |
| Total term debt |  |  |  |  | 103,086 |  |  |  |  |  |  |  | 101,679 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (229 | ) |  |  |  |  |  |  | (224 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | 445 |  |  |  |  |  |  |  | 612 |  |  |  |  |  |  |
| Less: Current portion of term debt |  |  |  |  | (10,224 | ) |  |  |  |  |  |  | (10,260 | ) |  |  |  |  |  |
| Total non-current portion of term debt |  |  |  |  | $ | 93,078 |  |  |  |  |  |  |  | $ | 91,807 |  |  |  |  |  |  |

- removed (2020-01-29):
[0000320193-19-000076:note_history:58]
|  | Maturities(calendar year) |  | June 29, 2019 |  | September 29, 2018 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 2.400% – 3.850% notes | 2023 | – | 2043 |  | $ | 8,500 |  |  |  | 2.44% | – | 3.91 | % |  | $ | 8,500 |  |  |  | 2.44% | – | 3.91 | % |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | — |  | — |  |  |  |  |  | — | % |  | 1,000 |  |  |  |  |  | 2.64 | % |
| Fixed-rate 2.850% – 4.450% notes | 2021 | – | 2044 |  | 6,500 |  |  |  | 3.12% | – | 4.48 | % |  | 8,500 |  |  |  | 2.64% | – | 4.48 | % |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2020 |  | 1,488 |  |  |  | 1.87% | – | 2.84 | % |  | 1,507 |  |  |  | 1.87% | – | 2.64 | % |
| Fixed-rate 0.350% – 4.375% notes | 2019 | – | 2045 |  | 24,223 |  |  |  | 0.28% | – | 4.51 | % |  | 24,410 |  |  |  | 0.28% | – | 4.51 | % |
| 2016 debt issuances of $24.9 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2021 |  | 850 |  |  |  | 2.71% | – | 3.65 | % |  | 1,350 |  |  |  | 2.48% | – | 3.44 | % |
| Fixed-rate 1.100% – 4.650% notes | 2019 | – | 2046 |  | 22,022 |  |  |  | 1.13% | – | 4.78 | % |  | 23,059 |  |  |  | 1.13% | – | 4.78 | % |
| 2017 debt issuances of $28.7 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2020 | – | 2022 |  | 2,750 |  |  |  | 2.61% | – | 3.06 | % |  | 3,250 |  |  |  | 2.41% | – | 2.84 | % |
| Fixed-rate 0.875% – 4.300% notes | 2019 | – | 2047 |  | 24,989 |  |  |  | 1.54% | – | 4.30 | % |  | 25,617 |  |  |  | 1.54% | – | 4.30 | % |
| 2018 debt issuance of $7.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 1.800% – 3.750% notes | 2019 | – | 2047 |  | 7,000 |  |  |  | 1.83% | – | 3.80 | % |  | 7,000 |  |  |  | 1.83% | – | 3.80 | % |
| Total term debt |  |  |  |  | 98,322 |  |  |  |  |  |  |  | 104,193 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (194 | ) |  |  |  |  |  |  | (218 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | 337 |  |  |  |  |  |  |  | (1,456 | ) |  |  |  |  |  |
| Less: Current portion of term debt |  |  |  |  | (13,529 | ) |  |  |  |  |  |  | (8,784 | ) |  |  |  |  |  |
| Total non-current portion of term debt |  |  |  |  | $ | 84,936 |  |  |  |  |  |  |  | $ | 93,735 |  |  |  |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-01-29):
[0000320193-20-000010:note_history:59]
Net sales disaggregated by significant products and services for the three months ended December 28, 2019 and December 29, 2018 were as follows (in millions):
  (was, 2019-07-31, similarity 0.8787):
[0000320193-19-000076:note_history:59]
Net sales disaggregated by significant products and services for the three- and nine-month periods ended June 29, 2019 and June 30, 2018 were as follows (in millions):

- changed (2020-01-29):
[0000320193-20-000010:note_history:60]
|  | Three Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |
| iPhone (1) | $ | 55,957 |  |  | $ | 51,982 |  |
| Mac (1) | 7,160 |  |  | 7,416 |  |
| iPad (1) | 5,977 |  |  | 6,729 |  |
| Wearables, Home and Accessories (1)(2) | 10,010 |  |  | 7,308 |  |
| Services (3) | 12,715 |  |  | 10,875 |  |
| Total net sales (4) | $ | 91,819 |  |  | $ | 84,310 |  |
  (was, 2019-07-31, similarity 0.7167):
[0000320193-19-000076:note_history:60]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| iPhone (1) | $ | 25,986 |  |  | $ | 29,470 |  |  | $ | 109,019 |  |  | $ | 128,133 |  |
| Mac (1) | 5,820 |  |  | 5,258 |  |  | 18,749 |  |  | 17,858 |  |
| iPad (1) | 5,023 |  |  | 4,634 |  |  | 16,624 |  |  | 14,397 |  |
| Wearables, Home and Accessories (1)(2) | 5,525 |  |  | 3,733 |  |  | 17,962 |  |  | 13,158 |  |
| Services (3) | 11,455 |  |  | 10,170 |  |  | 33,780 |  |  | 29,149 |  |
| Total net sales (4) | $ | 53,809 |  |  | $ | 53,265 |  |  | $ | 196,134 |  |  | $ | 202,695 |  |

- changed (2020-01-29):
[0000320193-20-000010:note_history:61]
| (3) | Services net sales include sales from the Company’s digital content stores and streaming services, AppleCare®, licensing and other services. Services net sales also include amortization of the deferred value of Maps, Siri, and free iCloud and Apple TV + services, which are bundled in the sales price of certain products. |
  (was, 2019-07-31, similarity 0.9088):
[0000320193-19-000076:note_history:61]
| (3) | Services net sales include sales from the Company’s digital content stores and streaming services, AppleCare®, Apple Pay®, licensing and other services. Services net sales also include amortization of the deferred value of Maps, Siri and free iCloud services, which are bundled in the sales price of certain products. |

- added (2020-01-29):
[0000320193-20-000010:note_history:62]
Includes $1.9 billion of revenue recognized in the three months ended December 28, 2019 that was included in deferred revenue as of September 28, 2019 and $2.4 billion of revenue recognized in the three months ended December 29, 2018 that was included in deferred revenue as of September 29, 2018.

- removed (2020-01-29):
[0000320193-19-000076:note_history:63]
Includes $2.0 billion of revenue recognized in the three months ended June 29, 2019 that was included in deferred revenue as of March 30, 2019, $2.0 billion of revenue recognized in the three months ended June 30, 2018 that was included in deferred revenue as of March 31, 2018, $4.9 billion of revenue recognized in the nine months ended June 29, 2019 that was included in deferred revenue as of September 29, 2018, and $4.7 billion of revenue recognized in the nine months ended June 30, 2018 that was included in deferred revenue as of September 30, 2017.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-01-29):
[0000320193-20-000010:note_history:64]
Revenue Recognition
Net sales consist of revenue from the sale of iPhone®, Mac®, iPad®, Services and other products. The Company recognizes revenue at the amount to which it expects to be entitled when control of the products or services is transferred to its customers. Control is generally transferred when the Company has a present right to payment and title and the significant risks and rewards of ownership of products or services are transferred to its customers. For most of the Company’s Products net sales, control transfers when products are shipped. For the Company’s Services net sales, control transfers over time as services are delivered. Payment for Products and Services net sales is collected within a short period following transfer of control or commencement of delivery of services, as applicable.
  (was, 2019-07-31, similarity 0.9933):
[0000320193-19-000076:note_history:64]
Revenue Recognition
Net sales consist of revenue from the sale of iPhone, Mac, iPad, services and other products. The Company recognizes revenue at the amount to which it expects to be entitled when control of the products or services is transferred to its customers. Control is generally transferred when the Company has a present right to payment and title and the significant risks and rewards of ownership of products or services are transferred to its customers. For most of the Company’s products net sales, control transfers when products are shipped. For the Company’s services net sales, control transfers over time as services are delivered. Payment for products and services net sales is collected within a short period of time following transfer of control or commencement of delivery of services, as applicable.

- changed (2020-01-29):
[0000320193-20-000010:note_history:65]
For arrangements with multiple performance obligations, which represent promises within an arrangement that are capable of being distinct, the Company allocates revenue to all distinct performance obligations based on their relative stand-alone selling prices (“SSPs”). When available, the Company uses observable prices to determine SSPs. When observable prices are not available, SSPs are established that reflect the Company’s best estimates of what the selling prices of the performance obligations would be if they were sold regularly on a stand-alone basis. The Company’s process for estimating SSPs without observable prices considers multiple factors that may vary depending upon the unique facts and circumstances related to each performance obligation including, where applicable, prices charged by the Company for similar offerings, market trends in the pricing for similar offerings, product-specific business objectives and the estimated cost to provide the performance obligation.
  (was, 2019-07-31, similarity 0.994):
[0000320193-19-000076:note_history:65]
For arrangements with multiple performance obligations, which represent promises within an arrangement that are capable of being distinct, the Company allocates revenue to all distinct performance obligations based on their relative stand-alone selling prices (“SSP”). When available, the Company uses observable prices to determine the SSP. When observable prices are not available, SSPs are established that reflect the Company’s best estimates of what the selling prices of the performance obligations would be if they were sold regularly on a stand-alone basis. The Company’s process for estimating SSPs without observable prices considers multiple factors that may vary depending upon the unique facts and circumstances related to each performance obligation including, where applicable, prices charged by the Company for similar offerings, market trends in the pricing for similar offerings, product-specific business objectives and the estimated cost to provide the performance obligation.

- changed (2020-01-29):
[0000320193-20-000010:note_history:66]
The Company has identified up to three performance obligations regularly included in arrangements involving the sale of iPhone, Mac, iPad and certain other products. The first performance obligation, which represents the substantial portion of the allocated sales price, is the hardware and bundled software delivered at the time of sale. The second performance obligation is the right to receive certain product-related bundled services, which include iCloud®, Siri® and Maps. The third performance obligation is the right to receive, on a when-and-if-available basis, future unspecified software upgrades relating to the software bundled with each device. The Company allocates revenue and any related discounts to these performance obligations based on their relative SSPs. Because the Company lacks observable prices for the undelivered performance obligations, the allocation of revenue is based on the Company’s estimated SSPs. Revenue allocated to the delivered hardware and bundled software is recognized when control has transferred to the customer, which generally occurs when the product is shipped. Revenue allocated to the product-related bundled services and unspecified software upgrade rights is deferred and recognized on a straight-line basis over the estimated period they are expected to be provided. Cost of sales related to delivered hardware and bundled software, including estimated warranty costs, are recognized at the time of sale. Costs incurred to provide product-related bundled services and unspecified software upgrade rights are recognized as cost of sales as incurred.
  (was, 2019-07-31, similarity 0.9994):
[0000320193-19-000076:note_history:66]
The Company has identified up to three performance obligations regularly included in arrangements involving the sale of iPhone, Mac, iPad and certain other products. The first performance obligation, which represents the substantial portion of the allocated sales price, is the hardware and bundled software delivered at the time of sale. The second performance obligation is the right to receive certain product-related bundled services, which include iCloud, Siri and Maps. The third performance obligation is the right to receive, on a when-and-if-available basis, future unspecified software upgrades relating to the software bundled with each device. The Company allocates revenue and any related discounts to these performance obligations based on their relative SSPs. Because the Company lacks observable prices for the undelivered performance obligations, the allocation of revenue is based on the Company’s estimated SSPs. Revenue allocated to the delivered hardware and bundled software is recognized when control has transferred to the customer, which generally occurs when the product is shipped. Revenue allocated to the product-related bundled services and unspecified software upgrade rights is deferred and recognized on a straight-line basis over the estimated period they are expected to be provided. Cost of sales related to delivered hardware and bundled software, including estimated warranty costs, are recognized at the time of sale. Costs incurred to provide product-related bundled services and unspecified software upgrade rights are recognized as cost of sales as incurred.

- changed (2020-01-29):
[0000320193-20-000010:note_history:67]
For the sale of third-party products where the Company obtains control of the product before transferring it to the customer, the Company recognizes revenue based on the gross amount billed to customers. The Company considers multiple factors when determining whether it obtains control of third-party products including, but not limited to, evaluating if it can establish the price of the product, retains inventory risk for tangible products or has the responsibility for ensuring acceptability of the product. For third-party applications sold through the App Store®, Mac App Store, TV App Store and Watch App Store and certain digital content sold through the Company’s other digital content stores, the Company does not obtain control of the product before transferring it to the customer. Therefore, the Company accounts for such sales on a net basis by recognizing in Services net sales only the commission it retains.
  (was, 2019-07-31, similarity 0.6429):
[0000320193-19-000076:note_history:67]
For the sale of third-party products where the Company obtains control of the product before transferring it to the customer, the Company recognizes revenue based on the gross amount billed to customers. The Company considers multiple factors when determining whether it obtains control of third-party products including, but not limited to, evaluating if it has the ability to establish the price of the product, retains inventory risk for tangible products or has the responsibility for ensuring acceptability of the product. For third-party applications sold through the App Store®, Mac App Store and TV App Store and certain digital content sold through the iTunes Store®, the Company does not obtain control of the product before transferring it to the customer. Therefore, the Company accounts for such sales on a net basis by recognizing in services net sales only the commission it retains.

- added (2020-01-29):
[0000320193-20-000010:note_history:68]
As of December 28, 2019 and September 28, 2019, the Company had total deferred revenue of $9.1 billion and $8.1 billion, respectively. As of December 28, 2019, the Company expects 61% of total deferred revenue to be realized in less than a year, 29% within one-to-two years, 8% within two-to-three years and 2% in greater than three years.

- changed (2020-01-29):
[0000320193-20-000010:note_history:69]
Net sales disaggregated by significant products and services for the three months ended December 28, 2019 and December 29, 2018 were as follows (in millions):
  (was, 2019-07-31, similarity 0.8787):
[0000320193-19-000076:note_history:69]
Net sales disaggregated by significant products and services for the three- and nine-month periods ended June 29, 2019 and June 30, 2018 were as follows (in millions):

- changed (2020-01-29):
[0000320193-20-000010:note_history:70]
|  | Three Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |
| iPhone (1) | $ | 55,957 |  |  | $ | 51,982 |  |
| Mac (1) | 7,160 |  |  | 7,416 |  |
| iPad (1) | 5,977 |  |  | 6,729 |  |
| Wearables, Home and Accessories (1)(2) | 10,010 |  |  | 7,308 |  |
| Services (3) | 12,715 |  |  | 10,875 |  |
| Total net sales (4) | $ | 91,819 |  |  | $ | 84,310 |  |
  (was, 2019-07-31, similarity 0.7167):
[0000320193-19-000076:note_history:70]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| iPhone (1) | $ | 25,986 |  |  | $ | 29,470 |  |  | $ | 109,019 |  |  | $ | 128,133 |  |
| Mac (1) | 5,820 |  |  | 5,258 |  |  | 18,749 |  |  | 17,858 |  |
| iPad (1) | 5,023 |  |  | 4,634 |  |  | 16,624 |  |  | 14,397 |  |
| Wearables, Home and Accessories (1)(2) | 5,525 |  |  | 3,733 |  |  | 17,962 |  |  | 13,158 |  |
| Services (3) | 11,455 |  |  | 10,170 |  |  | 33,780 |  |  | 29,149 |  |
| Total net sales (4) | $ | 53,809 |  |  | $ | 53,265 |  |  | $ | 196,134 |  |  | $ | 202,695 |  |

- changed (2020-01-29):
[0000320193-20-000010:note_history:71]
| (3) | Services net sales include sales from the Company’s digital content stores and streaming services, AppleCare®, licensing and other services. Services net sales also include amortization of the deferred value of Maps, Siri, and free iCloud and Apple TV + services, which are bundled in the sales price of certain products. |
  (was, 2019-07-31, similarity 0.9088):
[0000320193-19-000076:note_history:71]
| (3) | Services net sales include sales from the Company’s digital content stores and streaming services, AppleCare®, Apple Pay®, licensing and other services. Services net sales also include amortization of the deferred value of Maps, Siri and free iCloud services, which are bundled in the sales price of certain products. |

- added (2020-01-29):
[0000320193-20-000010:note_history:72]
| (4) | Includes $1.9 billion of revenue recognized in the three months ended December 28, 2019 that was included in deferred revenue as of September 28, 2019 and $2.4 billion of revenue recognized in the three months ended December 29, 2018 that was included in deferred revenue as of September 29, 2018. |

- changed (2020-01-29):
[0000320193-20-000010:note_history:73]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 11, “Segment Information and Geographic Data” for the three months ended December 28, 2019 and December 29, 2018.
  (was, 2019-07-31, similarity 0.7983):
[0000320193-19-000076:note_history:73]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 11, “Segment Information and Geographic Data” for the three- and nine-month periods ended June 29, 2019 and June 30, 2018.

- removed (2020-01-29):
[0000320193-19-000076:note_history:74]
As of June 29, 2019 and September 29, 2018, the Company had total deferred revenue of $8.0 billion and $8.8 billion, respectively. As of June 29, 2019, the Company expects 68% of total deferred revenue to be realized in less than a year, 25% within one-to-two years, 6% within two-to-three years and 1% in greater than three years.

- removed (2020-01-29):
[0000320193-19-000076:note_history:75]
| (4) | Includes $2.0 billion of revenue recognized in the three months ended June 29, 2019 that was included in deferred revenue as of March 30, 2019, $2.0 billion of revenue recognized in the three months ended June 30, 2018 that was included in deferred revenue as of March 31, 2018, $4.9 billion of revenue recognized in the nine months ended June 29, 2019 that was included in deferred revenue as of September 29, 2018, and $4.7 billion of revenue recognized in the nine months ended June 30, 2018 that was included in deferred revenue as of September 30, 2017. |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-01-29):
[0000320193-20-000010:note_history:76]
Net sales consist of revenue from the sale of iPhone®, Mac®, iPad®, Services and other products. The Company recognizes revenue at the amount to which it expects to be entitled when control of the products or services is transferred to its customers. Control is generally transferred when the Company has a present right to payment and title and the significant risks and rewards of ownership of products or services are transferred to its customers. For most of the Company’s Products net sales, control transfers when products are shipped. For the Company’s Services net sales, control transfers over time as services are delivered. Payment for Products and Services net sales is collected within a short period following transfer of control or commencement of delivery of services, as applicable.
  (was, 2019-07-31, similarity 0.9931):
[0000320193-19-000076:note_history:76]
Net sales consist of revenue from the sale of iPhone, Mac, iPad, services and other products. The Company recognizes revenue at the amount to which it expects to be entitled when control of the products or services is transferred to its customers. Control is generally transferred when the Company has a present right to payment and title and the significant risks and rewards of ownership of products or services are transferred to its customers. For most of the Company’s products net sales, control transfers when products are shipped. For the Company’s services net sales, control transfers over time as services are delivered. Payment for products and services net sales is collected within a short period of time following transfer of control or commencement of delivery of services, as applicable.

- changed (2020-01-29):
[0000320193-20-000010:note_history:77]
For arrangements with multiple performance obligations, which represent promises within an arrangement that are capable of being distinct, the Company allocates revenue to all distinct performance obligations based on their relative stand-alone selling prices (“SSPs”). When available, the Company uses observable prices to determine SSPs. When observable prices are not available, SSPs are established that reflect the Company’s best estimates of what the selling prices of the performance obligations would be if they were sold regularly on a stand-alone basis. The Company’s process for estimating SSPs without observable prices considers multiple factors that may vary depending upon the unique facts and circumstances related to each performance obligation including, where applicable, prices charged by the Company for similar offerings, market trends in the pricing for similar offerings, product-specific business objectives and the estimated cost to provide the performance obligation.
  (was, 2019-07-31, similarity 0.994):
[0000320193-19-000076:note_history:77]
For arrangements with multiple performance obligations, which represent promises within an arrangement that are capable of being distinct, the Company allocates revenue to all distinct performance obligations based on their relative stand-alone selling prices (“SSP”). When available, the Company uses observable prices to determine the SSP. When observable prices are not available, SSPs are established that reflect the Company’s best estimates of what the selling prices of the performance obligations would be if they were sold regularly on a stand-alone basis. The Company’s process for estimating SSPs without observable prices considers multiple factors that may vary depending upon the unique facts and circumstances related to each performance obligation including, where applicable, prices charged by the Company for similar offerings, market trends in the pricing for similar offerings, product-specific business objectives and the estimated cost to provide the performance obligation.

- changed (2020-01-29):
[0000320193-20-000010:note_history:78]
The Company has identified up to three performance obligations regularly included in arrangements involving the sale of iPhone, Mac, iPad and certain other products. The first performance obligation, which represents the substantial portion of the allocated sales price, is the hardware and bundled software delivered at the time of sale. The second performance obligation is the right to receive certain product-related bundled services, which include iCloud®, Siri® and Maps. The third performance obligation is the right to receive, on a when-and-if-available basis, future unspecified software upgrades relating to the software bundled with each device. The Company allocates revenue and any related discounts to these performance obligations based on their relative SSPs. Because the Company lacks observable prices for the undelivered performance obligations, the allocation of revenue is based on the Company’s estimated SSPs. Revenue allocated to the delivered hardware and bundled software is recognized when control has transferred to the customer, which generally occurs when the product is shipped. Revenue allocated to the product-related bundled services and unspecified software upgrade rights is deferred and recognized on a straight-line basis over the estimated period they are expected to be provided. Cost of sales related to delivered hardware and bundled software, including estimated warranty costs, are recognized at the time of sale. Costs incurred to provide product-related bundled services and unspecified software upgrade rights are recognized as cost of sales as incurred.
  (was, 2019-07-31, similarity 0.9994):
[0000320193-19-000076:note_history:78]
The Company has identified up to three performance obligations regularly included in arrangements involving the sale of iPhone, Mac, iPad and certain other products. The first performance obligation, which represents the substantial portion of the allocated sales price, is the hardware and bundled software delivered at the time of sale. The second performance obligation is the right to receive certain product-related bundled services, which include iCloud, Siri and Maps. The third performance obligation is the right to receive, on a when-and-if-available basis, future unspecified software upgrades relating to the software bundled with each device. The Company allocates revenue and any related discounts to these performance obligations based on their relative SSPs. Because the Company lacks observable prices for the undelivered performance obligations, the allocation of revenue is based on the Company’s estimated SSPs. Revenue allocated to the delivered hardware and bundled software is recognized when control has transferred to the customer, which generally occurs when the product is shipped. Revenue allocated to the product-related bundled services and unspecified software upgrade rights is deferred and recognized on a straight-line basis over the estimated period they are expected to be provided. Cost of sales related to delivered hardware and bundled software, including estimated warranty costs, are recognized at the time of sale. Costs incurred to provide product-related bundled services and unspecified software upgrade rights are recognized as cost of sales as incurred.

- changed (2020-01-29):
[0000320193-20-000010:note_history:79]
For the sale of third-party products where the Company obtains control of the product before transferring it to the customer, the Company recognizes revenue based on the gross amount billed to customers. The Company considers multiple factors when determining whether it obtains control of third-party products including, but not limited to, evaluating if it can establish the price of the product, retains inventory risk for tangible products or has the responsibility for ensuring acceptability of the product. For third-party applications sold through the App Store®, Mac App Store, TV App Store and Watch App Store and certain digital content sold through the Company’s other digital content stores, the Company does not obtain control of the product before transferring it to the customer. Therefore, the Company accounts for such sales on a net basis by recognizing in Services net sales only the commission it retains.
  (was, 2019-07-31, similarity 0.6429):
[0000320193-19-000076:note_history:79]
For the sale of third-party products where the Company obtains control of the product before transferring it to the customer, the Company recognizes revenue based on the gross amount billed to customers. The Company considers multiple factors when determining whether it obtains control of third-party products including, but not limited to, evaluating if it has the ability to establish the price of the product, retains inventory risk for tangible products or has the responsibility for ensuring acceptability of the product. For third-party applications sold through the App Store®, Mac App Store and TV App Store and certain digital content sold through the iTunes Store®, the Company does not obtain control of the product before transferring it to the customer. Therefore, the Company accounts for such sales on a net basis by recognizing in services net sales only the commission it retains.
