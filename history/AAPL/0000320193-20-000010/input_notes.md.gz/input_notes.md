# AAPL notes — 0000320193-20-000010


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000320193-20-000010:notes:1]
[same as prior period, unchanged from 0000320193-19-000076:notes:1]

[0000320193-20-000010:notes:2]
The condensed consolidated financial statements include the accounts of Apple Inc. and its wholly owned subsidiaries (collectively “Apple” or the “Company”). Intercompany accounts and transactions have been eliminated. In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements and accompanying notes in conformity with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported. Actual results could differ materially from those estimates. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company’s annual consolidated financial statements and accompanying notes included in its Annual Report on Form 10-K for the fiscal year ended September 28, 2019 (the “2019 Form 10-K”).

[0000320193-20-000010:notes:3]
The Company’s fiscal year is the 52- or 53-week period that ends on the last Saturday of September. A 14th week is included in the first fiscal quarter every five or six years to realign the Company’s fiscal quarters with calendar quarters. The Company’s fiscal years 2020 and 2019 span 52 weeks each. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in September and the associated quarters, months and periods of those fiscal years.

[0000320193-20-000010:notes:4]
Recently Adopted Accounting Pronouncements

[0000320193-20-000010:notes:5]
Leases

[0000320193-20-000010:notes:6]
At the beginning of the first quarter of 2020, the Company adopted the Financial Accounting Standards Board’s (the “FASB”) Accounting Standards Update (“ASU”) No. 2016-02, Leases (Topic 842) (“ASU 2016-02”), and additional ASUs issued to clarify and update the guidance in ASU 2016-02 (collectively, the “new leases standard”), which modifies lease accounting for lessees to increase transparency and comparability by recording lease assets and liabilities for operating leases and disclosing key information about leasing arrangements. The Company adopted the new leases standard utilizing the modified retrospective transition method, under which amounts in prior periods presented were not restated. For contracts existing at the time of adoption, the Company elected to not reassess (i) whether any are or contain leases, (ii) lease classification, and (iii) initial direct costs. Upon adoption, the Company recorded $7.5 billion of right-of-use (“ROU”) assets and $8.1 billion of lease liabilities on its Condensed Consolidated Balance Sheet.

[0000320193-20-000010:notes:7]
Hedging

[0000320193-20-000010:notes:8]
At the beginning of the first quarter of 2020, the Company adopted FASB ASU No. 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities (“ASU 2017-12”). ASU 2017-12 expands component and fair value hedging, specifies the presentation of the effects of hedging instruments, eliminates the separate measurement and presentation of hedge ineffectiveness, and updates disclosure requirements related to hedging. The Company adopted ASU 2017-12 utilizing the modified retrospective transition method. Upon adoption, the Company recorded a $136 million increase in accumulated other comprehensive income/(loss) (“AOCI”) and a corresponding decrease in retained earnings in the Condensed Consolidated Statement of Shareholders’ Equity.

[0000320193-20-000010:notes:9]
[same as prior period, unchanged from 0000320193-19-000076:notes:14]

[0000320193-20-000010:notes:10]
The following table shows the computation of basic and diluted earnings per share for the three months ended December 28, 2019 and December 29, 2018 (net income in millions and shares in thousands):

[0000320193-20-000010:notes:11]
|  | Three Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |
| Numerator: |  |  |  |
| Net income | $ | 22,236 |  |  | $ | 19,965 |  |
| Denominator: |  |  |  |
| Weighted-average basic shares outstanding | 4,415,040 |  |  | 4,735,820 |  |
| Effect of dilutive securities | 39,564 |  |  | 37,432 |  |
| Weighted-average diluted shares | 4,454,604 |  |  | 4,773,252 |  |
| Basic earnings per share | $ | 5.04 |  |  | $ | 4.22 |  |
| Diluted earnings per share | $ | 4.99 |  |  | $ | 4.18 |  |

[0000320193-20-000010:notes:12]
Potentially dilutive securities representing 28.8 million shares of common stock were excluded from the computation of diluted earnings per share for the three months ended December 29, 2018, because their effect would have been antidilutive.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000320193-20-000010:notes:13]
Revenue Recognition
Net sales consist of revenue from the sale of iPhone®, Mac®, iPad®, Services and other products. The Company recognizes revenue at the amount to which it expects to be entitled when control of the products or services is transferred to its customers. Control is generally transferred when the Company has a present right to payment and title and the significant risks and rewards of ownership of products or services are transferred to its customers. For most of the Company’s Products net sales, control transfers when products are shipped. For the Company’s Services net sales, control transfers over time as services are delivered. Payment for Products and Services net sales is collected within a short period following transfer of control or commencement of delivery of services, as applicable.

[0000320193-20-000010:notes:14]
The Company records reductions to Products net sales related to future product returns, price protection and other customer incentive programs based on the Company’s expectations and historical experience.

[0000320193-20-000010:notes:15]
For arrangements with multiple performance obligations, which represent promises within an arrangement that are capable of being distinct, the Company allocates revenue to all distinct performance obligations based on their relative stand-alone selling prices (“SSPs”). When available, the Company uses observable prices to determine SSPs. When observable prices are not available, SSPs are established that reflect the Company’s best estimates of what the selling prices of the performance obligations would be if they were sold regularly on a stand-alone basis. The Company’s process for estimating SSPs without observable prices considers multiple factors that may vary depending upon the unique facts and circumstances related to each performance obligation including, where applicable, prices charged by the Company for similar offerings, market trends in the pricing for similar offerings, product-specific business objectives and the estimated cost to provide the performance obligation.

[0000320193-20-000010:notes:16]
The Company has identified up to three performance obligations regularly included in arrangements involving the sale of iPhone, Mac, iPad and certain other products. The first performance obligation, which represents the substantial portion of the allocated sales price, is the hardware and bundled software delivered at the time of sale. The second performance obligation is the right to receive certain product-related bundled services, which include iCloud®, Siri® and Maps. The third performance obligation is the right to receive, on a when-and-if-available basis, future unspecified software upgrades relating to the software bundled with each device. The Company allocates revenue and any related discounts to these performance obligations based on their relative SSPs. Because the Company lacks observable prices for the undelivered performance obligations, the allocation of revenue is based on the Company’s estimated SSPs. Revenue allocated to the delivered hardware and bundled software is recognized when control has transferred to the customer, which generally occurs when the product is shipped. Revenue allocated to the product-related bundled services and unspecified software upgrade rights is deferred and recognized on a straight-line basis over the estimated period they are expected to be provided. Cost of sales related to delivered hardware and bundled software, including estimated warranty costs, are recognized at the time of sale. Costs incurred to provide product-related bundled services and unspecified software upgrade rights are recognized as cost of sales as incurred.

[0000320193-20-000010:notes:17]
[same as prior period, unchanged from 0000320193-19-000076:notes:24]

[0000320193-20-000010:notes:18]
For the sale of third-party products where the Company obtains control of the product before transferring it to the customer, the Company recognizes revenue based on the gross amount billed to customers. The Company considers multiple factors when determining whether it obtains control of third-party products including, but not limited to, evaluating if it can establish the price of the product, retains inventory risk for tangible products or has the responsibility for ensuring acceptability of the product. For third-party applications sold through the App Store®, Mac App Store, TV App Store and Watch App Store and certain digital content sold through the Company’s other digital content stores, the Company does not obtain control of the product before transferring it to the customer. Therefore, the Company accounts for such sales on a net basis by recognizing in Services net sales only the commission it retains.

[0000320193-20-000010:notes:19]
[same as prior period, unchanged from 0000320193-19-000076:notes:26]

[0000320193-20-000010:notes:20]
[same as prior period, unchanged from 0000320193-19-000076:notes:27]

[0000320193-20-000010:notes:21]
As of December 28, 2019 and September 28, 2019, the Company had total deferred revenue of $9.1 billion and $8.1 billion, respectively. As of December 28, 2019, the Company expects 61% of total deferred revenue to be realized in less than a year, 29% within one-to-two years, 8% within two-to-three years and 2% in greater than three years.

[0000320193-20-000010:notes:22]
[same as prior period, unchanged from 0000320193-19-000076:notes:29]

[0000320193-20-000010:notes:23]
Net sales disaggregated by significant products and services for the three months ended December 28, 2019 and December 29, 2018 were as follows (in millions):

[0000320193-20-000010:notes:24]
|  | Three Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |
| iPhone (1) | $ | 55,957 |  |  | $ | 51,982 |  |
| Mac (1) | 7,160 |  |  | 7,416 |  |
| iPad (1) | 5,977 |  |  | 6,729 |  |
| Wearables, Home and Accessories (1)(2) | 10,010 |  |  | 7,308 |  |
| Services (3) | 12,715 |  |  | 10,875 |  |
| Total net sales (4) | $ | 91,819 |  |  | $ | 84,310 |  |

[0000320193-20-000010:notes:25]
[same as prior period, unchanged from 0000320193-19-000076:notes:32]

[0000320193-20-000010:notes:26]
[same as prior period, unchanged from 0000320193-19-000076:notes:33]

[0000320193-20-000010:notes:27]
| (3) | Services net sales include sales from the Company’s digital content stores and streaming services, AppleCare®, licensing and other services. Services net sales also include amortization of the deferred value of Maps, Siri, and free iCloud and Apple TV + services, which are bundled in the sales price of certain products. |

[0000320193-20-000010:notes:28]
| (4) | Includes $1.9 billion of revenue recognized in the three months ended December 28, 2019 that was included in deferred revenue as of September 28, 2019 and $2.4 billion of revenue recognized in the three months ended December 29, 2018 that was included in deferred revenue as of September 29, 2018. |

[0000320193-20-000010:notes:29]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 11, “Segment Information and Geographic Data” for the three months ended December 28, 2019 and December 29, 2018.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000320193-20-000010:notes:30]
[same as prior period, unchanged from 0000320193-19-000076:notes:37]

[0000320193-20-000010:notes:31]
The following tables show the Company’s cash and marketable securities by significant investment category as of December 28, 2019 and September 28, 2019 (in millions):

[0000320193-20-000010:notes:32]
|  | December 28, 2019 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | CurrentMarketableSecurities |  | Non-CurrentMarketableSecurities |
| Cash | $ | 11,383 |  |  | $ | — |  |  | $ | — |  |  | $ | 11,383 |  |  | $ | 11,383 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 11,535 |  |  | — |  |  | — |  |  | 11,535 |  |  | 11,535 |  |  | — |  |  | — |  |
| Subtotal | 11,535 |  |  | — |  |  | — |  |  | 11,535 |  |  | 11,535 |  |  | — |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 28,600 |  |  | 29 |  |  | (40 | ) |  | 28,589 |  |  | 3,950 |  |  | 11,069 |  |  | 13,570 |  |
| U.S. agency securities | 8,302 |  |  | 2 |  |  | (1 | ) |  | 8,303 |  |  | 3,703 |  |  | 4,095 |  |  | 505 |  |
| Non-U.S. government securities | 18,978 |  |  | 324 |  |  | (92 | ) |  | 19,210 |  |  | 289 |  |  | 2,637 |  |  | 16,284 |  |
| Certificates of deposit and time deposits | 12,916 |  |  | — |  |  | — |  |  | 12,916 |  |  | 4,595 |  |  | 6,777 |  |  | 1,544 |  |
| Commercial paper | 17,823 |  |  | — |  |  | — |  |  | 17,823 |  |  | 4,254 |  |  | 13,569 |  |  | — |  |
| Corporate debt securities | 82,007 |  |  | 876 |  |  | (37 | ) |  | 82,846 |  |  | 62 |  |  | 27,894 |  |  | 54,890 |  |
| Municipal securities | 971 |  |  | 11 |  |  | — |  |  | 982 |  |  | — |  |  | 35 |  |  | 947 |  |
| Mortgage- and asset-backed securities | 13,475 |  |  | 68 |  |  | (69 | ) |  | 13,474 |  |  | — |  |  | 1,315 |  |  | 12,159 |  |
| Subtotal | 183,072 |  |  | 1,310 |  |  | (239 | ) |  | 184,143 |  |  | 16,853 |  |  | 67,391 |  |  | 99,899 |  |
| Total (3) | $ | 205,990 |  |  | $ | 1,310 |  |  | $ | (239 | ) |  | $ | 207,061 |  |  | $ | 39,771 |  |  | $ | 67,391 |  |  | $ | 99,899 |  |

[0000320193-20-000010:notes:33]
|  | September 28, 2019 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | CurrentMarketableSecurities |  | Non-CurrentMarketableSecurities |
| Cash | $ | 12,204 |  |  | $ | — |  |  | $ | — |  |  | $ | 12,204 |  |  | $ | 12,204 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 15,897 |  |  | — |  |  | — |  |  | 15,897 |  |  | 15,897 |  |  | — |  |  | — |  |
| Subtotal | 15,897 |  |  | — |  |  | — |  |  | 15,897 |  |  | 15,897 |  |  | — |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 30,293 |  |  | 33 |  |  | (62 | ) |  | 30,264 |  |  | 6,165 |  |  | 9,817 |  |  | 14,282 |  |
| U.S. agency securities | 9,767 |  |  | 1 |  |  | (3 | ) |  | 9,765 |  |  | 6,489 |  |  | 2,249 |  |  | 1,027 |  |
| Non-U.S. government securities | 19,821 |  |  | 337 |  |  | (50 | ) |  | 20,108 |  |  | 749 |  |  | 3,168 |  |  | 16,191 |  |
| Certificates of deposit and time deposits | 4,041 |  |  | — |  |  | — |  |  | 4,041 |  |  | 2,024 |  |  | 1,922 |  |  | 95 |  |
| Commercial paper | 12,433 |  |  | — |  |  | — |  |  | 12,433 |  |  | 5,193 |  |  | 7,240 |  |  | — |  |
| Corporate debt securities | 85,383 |  |  | 756 |  |  | (92 | ) |  | 86,047 |  |  | 123 |  |  | 26,127 |  |  | 59,797 |  |
| Municipal securities | 958 |  |  | 8 |  |  | (1 | ) |  | 965 |  |  | — |  |  | 68 |  |  | 897 |  |
| Mortgage- and asset-backed securities | 14,180 |  |  | 67 |  |  | (73 | ) |  | 14,174 |  |  | — |  |  | 1,122 |  |  | 13,052 |  |
| Subtotal | 176,876 |  |  | 1,202 |  |  | (281 | ) |  | 177,797 |  |  | 20,743 |  |  | 51,713 |  |  | 105,341 |  |
| Total (3) | $ | 204,977 |  |  | $ | 1,202 |  |  | $ | (281 | ) |  | $ | 205,898 |  |  | $ | 48,844 |  |  | $ | 51,713 |  |  | $ | 105,341 |  |

[0000320193-20-000010:notes:34]
[same as prior period, unchanged from 0000320193-19-000076:notes:43]

[0000320193-20-000010:notes:35]
[same as prior period, unchanged from 0000320193-19-000076:notes:44]

[0000320193-20-000010:notes:36]
| (3) | As of December 28, 2019 and September 28, 2019, total marketable securities included $19.1 billion and $18.9 billion, respectively, that was restricted from general use, related to the State Aid Decision (refer to Note 5, “Income Taxes”) and other agreements. |

[0000320193-20-000010:notes:37]
The Company may sell certain of its marketable debt securities prior to their stated maturities for reasons including, but not limited to, managing liquidity, credit risk, duration and asset allocation. The maturities of the Company’s non-current marketable debt securities generally range from one to five years.

[0000320193-20-000010:notes:38]
The Company typically invests in highly rated securities, with the primary objective of minimizing the potential risk of principal loss. The Company’s investment policy generally requires securities to be investment grade and limits the amount of credit exposure to any one issuer. Fair values were determined for each individual security in the investment portfolio. When evaluating a marketable debt security for other-than-temporary impairment, the Company reviews factors such as the duration and extent to which the fair value of the security is less than its cost, the financial condition of the issuer and any changes thereto, and the Company’s intent to sell, or whether it will more likely than not be required to sell the security before recovery of its amortized cost basis. As of December 28, 2019, the Company does not consider any of its marketable debt securities to be other-than-temporarily impaired.

[0000320193-20-000010:notes:39]
[same as prior period, unchanged from 0000320193-19-000076:notes:51]

[0000320193-20-000010:notes:40]
The Company holds non-marketable equity securities of certain privately held companies without readily determinable fair values. As of both December 28, 2019 and September 28, 2019, the Company’s non-marketable equity securities had a carrying value of $2.9 billion.

[0000320193-20-000010:notes:41]
Restricted Cash

[0000320193-20-000010:notes:42]
A reconciliation of the Company’s cash and cash equivalents in the Condensed Consolidated Balance Sheets to cash, cash equivalents and restricted cash in the Condensed Consolidated Statements of Cash Flows as of December 28, 2019 and September 28, 2019 is as follows (in millions):

[0000320193-20-000010:notes:43]
|  | December 28, 2019 |  | September 28, 2019 |
| Cash and cash equivalents | $ | 39,771 |  |  | $ | 48,844 |  |
| Restricted cash included in other current assets | 68 |  |  | 23 |  |
| Restricted cash included in other non-current assets | 1,826 |  |  | 1,357 |  |
| Cash, cash equivalents and restricted cash | $ | 41,665 |  |  | $ | 50,224 |  |

[0000320193-20-000010:notes:44]
[same as prior period, unchanged from 0000320193-19-000076:notes:55]

[0000320193-20-000010:notes:45]
[same as prior period, unchanged from 0000320193-19-000076:notes:56]

[0000320193-20-000010:notes:46]
[same as prior period, unchanged from 0000320193-19-000076:notes:57]

[0000320193-20-000010:notes:47]
[same as prior period, unchanged from 0000320193-19-000076:notes:58]

[0000320193-20-000010:notes:48]
[same as prior period, unchanged from 0000320193-19-000076:notes:59]

[0000320193-20-000010:notes:49]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in foreign currency exchange rates, the Company may enter into forward contracts, cross-currency swaps or other instruments. These instruments may offset a portion of the foreign currency remeasurement gains or losses, or changes in fair value. The Company may designate these instruments as either cash flow or fair value hedges. As of December 28, 2019, the Company’s hedged term debt– and marketable securities–related foreign currency transactions are expected to be recognized within 23 years.

[0000320193-20-000010:notes:50]
[same as prior period, unchanged from 0000320193-19-000076:notes:61]

[0000320193-20-000010:notes:51]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in interest rates, the Company may enter into interest rate swaps, options or other instruments. These instruments may offset a portion of the changes in interest income or expense, or changes in fair value. The Company designates these instruments as either cash flow or fair value hedges. As of December 28, 2019, the Company’s hedged interest rate transactions are expected to be recognized within 8 years.

[0000320193-20-000010:notes:52]
[same as prior period, unchanged from 0000320193-19-000076:notes:63]

[0000320193-20-000010:notes:53]
Cash flow hedge amounts that are included in the assessment of hedge effectiveness are deferred in AOCI until the hedged item is recognized in earnings. Deferred gains and losses associated with cash flow hedges of foreign currency revenue are recognized as a component of net sales in the same period as the related revenue is recognized, and deferred gains and losses related to cash flow hedges of inventory purchases are recognized as a component of cost of sales in the same period as the related costs are recognized. Deferred gains and losses associated with cash flow hedges of interest income or expense are recognized in other income/(expense), net (“OI&E”) in the same period as the related income or expense is recognized. For options designated as cash flow hedges, the time value is excluded from the assessment of hedge effectiveness and recognized in the financial statement line item to which the hedge relates on a straight-line basis over the life of the hedge. Changes in the fair value of amounts excluded from the assessment of hedge effectiveness are recognized in other comprehensive income/(loss) (“OCI”).

[0000320193-20-000010:notes:54]
Derivative instruments designated as cash flow hedges must be de-designated as hedges when it is probable the forecasted hedged transaction will not occur in the initially identified time period or within a subsequent two-month time period. Deferred gains and losses in AOCI associated with such derivative instruments are reclassified into OI&E in the period of de-designation. Any subsequent changes in fair value of such derivative instruments are reflected in OI&E unless they are re-designated as hedges of other transactions.

[0000320193-20-000010:notes:55]
[same as prior period, unchanged from 0000320193-19-000076:notes:66]

[0000320193-20-000010:notes:56]
Net investment hedge amounts that are included in the assessment of hedge effectiveness are recorded in OCI as a part of the cumulative translation adjustment. For foreign exchange forward contracts designated as net investment hedges, the forward carry component is excluded from the assessment of hedge effectiveness and recognized in OCI on a straight-line basis over the life of the hedge. Changes in the fair value of amounts excluded from the assessment of hedge effectiveness are recognized in OCI.

[0000320193-20-000010:notes:57]
[same as prior period, unchanged from 0000320193-19-000076:notes:68]

[0000320193-20-000010:notes:58]
Fair value hedge gains and losses related to amounts that are included in the assessment of hedge effectiveness are recognized in earnings along with a corresponding loss or gain related to the change in value of the hedged item in the same line in the Condensed Consolidated Statements of Operations. For foreign exchange forward contracts designated as fair value hedges, the forward carry component is excluded from the assessment of hedge effectiveness and recognized in OI&E on a straight-line basis over the life of the hedge. Changes in the fair value of amounts excluded from the assessment of hedge effectiveness are recognized in OCI. The amount excluded from the effectiveness assessment of fair value hedges and recognized in OI&E was a gain of $128 million for the three months ended December 28, 2019.

[0000320193-20-000010:notes:59]
[same as prior period, unchanged from 0000320193-19-000076:notes:70]

[0000320193-20-000010:notes:60]
Derivatives that are not designated as hedging instruments are adjusted to fair value through earnings in the financial statement line item to which the derivative relates.

[0000320193-20-000010:notes:61]
The Company records all derivatives in the Condensed Consolidated Balance Sheets at fair value. The Company’s accounting treatment for these derivative instruments is based on its hedge designation. The following tables show the Company’s derivative instruments at gross fair value as of December 28, 2019 and September 28, 2019 (in millions):

[0000320193-20-000010:notes:62]
|  | December 28, 2019 |
|  | Fair Value ofDerivatives Designatedas Hedge Instruments |  | Fair Value ofDerivatives Not Designatedas Hedge Instruments |  | TotalFair Value |
| Derivative assets (1): |  |  |  |  |  |
| Foreign exchange contracts | $ | 1,625 |  |  | $ | 327 |  |  | $ | 1,952 |  |
| Interest rate contracts | $ | 475 |  |  | $ | — |  |  | $ | 475 |  |
| Derivative liabilities (2): |  |  |  |  |  |
| Foreign exchange contracts | $ | 964 |  |  | $ | 494 |  |  | $ | 1,458 |  |
| Interest rate contracts | $ | 57 |  |  | $ | — |  |  | $ | 57 |  |

[0000320193-20-000010:notes:63]
|  | September 28, 2019 |
|  | Fair Value ofDerivatives Designatedas Hedge Instruments |  | Fair Value ofDerivatives Not Designatedas Hedge Instruments |  | TotalFair Value |
| Derivative assets (1): |  |  |  |  |  |
| Foreign exchange contracts | $ | 1,798 |  |  | $ | 323 |  |  | $ | 2,121 |  |
| Interest rate contracts | $ | 685 |  |  | $ | — |  |  | $ | 685 |  |
| Derivative liabilities (2): |  |  |  |  |  |
| Foreign exchange contracts | $ | 1,341 |  |  | $ | 160 |  |  | $ | 1,501 |  |
| Interest rate contracts | $ | 105 |  |  | $ | — |  |  | $ | 105 |  |

[0000320193-20-000010:notes:64]
| (1) | The fair value of derivative assets is measured using Level 2 fair value inputs and is included in other current assets and other non-current assets in the Condensed Consolidated Balance Sheets. |

[0000320193-20-000010:notes:65]
| (2) | The fair value of derivative liabilities is measured using Level 2 fair value inputs and is included in other current liabilities and other non-current liabilities in the Condensed Consolidated Balance Sheets. |

[0000320193-20-000010:notes:66]
[same as prior period, unchanged from 0000320193-19-000076:notes:77]

[0000320193-20-000010:notes:67]
The following table shows the pre-tax gains and losses of the Company’s derivative and non-derivative instruments designated as cash flow and net investment hedges in OCI and the Condensed Consolidated Statements of Operations for the three months ended December 28, 2019 and December 29, 2018 (in millions):

[0000320193-20-000010:notes:68]
|  | Three Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |
| Gains/(Losses) recognized in OCI – included in effectiveness assessment: |  |  |  |
| Cash flow hedges: |  |  |  |
| Foreign exchange contracts | $ | 271 |  |  | $ | (478 | ) |
| Net investment hedges: |  |  |  |
| Foreign currency debt | $ | 24 |  |  | $ | (16 | ) |
| Gains/(Losses) reclassified from AOCI into net income – included in effectiveness assessment: |  |  |  |
| Cash flow hedges: |  |  |  |
| Foreign exchange contracts | $ | 491 |  |  | $ | (118 | ) |
| Interest rate contracts | (2 | ) |  | (1 | ) |
| Total | $ | 489 |  |  | $ | (119 | ) |

[0000320193-20-000010:notes:69]
The amount excluded from the effectiveness assessment of the Company’s hedges and recognized in OCI was a loss of $89 million for the three months ended December 28, 2019.

[0000320193-20-000010:notes:70]
The following tables show information about the Company’s derivative instruments designated as fair value hedges and the related hedged items for the three months ended December 28, 2019 and December 29, 2018 and as of December 28, 2019 (in millions):

[0000320193-20-000010:notes:71]
|  | Three Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |
| Gains/(Losses) on derivative instruments (1): |  |  |  |
| Foreign exchange contracts | $ | (183 | ) |  | $ | 402 |  |
| Interest rate contracts | (162 | ) |  | 657 |  |
| Total | $ | (345 | ) |  | $ | 1,059 |  |
| Gains/(Losses) related to hedged items (1): |  |  |  |
| Marketable securities | $ | 183 |  |  | $ | (402 | ) |
| Fixed-rate debt | 162 |  |  | (657 | ) |
| Total | $ | 345 |  |  | $ | (1,059 | ) |

[0000320193-20-000010:notes:72]
|  | December 28, 2019 |
| Carrying amounts of hedged assets/(liabilities): |  |
| Marketable securities (2) | $ | 15,544 |  |
| Fixed-rate debt (3) | $ | (28,631 | ) |
| Cumulative hedging adjustments included in the carrying amounts of hedged items: |  |
| Marketable securities carrying amount increases/(decreases) | $ | (594 | ) |
| Fixed-rate debt carrying amount (increases)/decreases | $ | (418 | ) |

[0000320193-20-000010:notes:73]
| (1) | Gains and losses related to fair value hedges are included in OI&E in the Condensed Consolidated Statements of Operations. |

[0000320193-20-000010:notes:74]
| (2) | The carrying amounts of marketable securities that are designated as hedged items in fair value hedges are included in current marketable securities and non-current marketable securities in the Condensed Consolidated Balance Sheet. |

[0000320193-20-000010:notes:75]
| (3) | The carrying amounts of fixed-rate debt instruments that are designated as hedged items in fair value hedges are included in current term debt and non-current term debt in the Condensed Consolidated Balance Sheet. |

[0000320193-20-000010:notes:76]
The following table shows the notional amounts of the Company’s outstanding derivative instruments and credit risk amounts associated with outstanding or unsettled derivative instruments as of December 28, 2019 and September 28, 2019 (in millions):

[0000320193-20-000010:notes:77]
|  | December 28, 2019 |  | September 28, 2019 |
|  | NotionalAmount |  | Credit RiskAmount |  | NotionalAmount |  | Credit RiskAmount |
| Instruments designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 54,215 |  |  | $ | 1,625 |  |  | $ | 61,795 |  |  | $ | 1,798 |  |
| Interest rate contracts | $ | 28,250 |  |  | $ | 475 |  |  | $ | 31,250 |  |  | $ | 685 |  |
| Instruments not designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 96,470 |  |  | $ | 327 |  |  | $ | 76,868 |  |  | $ | 323 |  |

[0000320193-20-000010:notes:78]
[same as prior period, unchanged from 0000320193-19-000076:notes:82]

[0000320193-20-000010:notes:79]
The Company generally enters into master netting arrangements, which are designed to reduce credit risk by permitting net settlement of transactions with the same counterparty. To further limit credit risk, the Company generally enters into collateral security arrangements that provide for collateral to be received or posted when the net fair value of certain financial instruments fluctuates from contractually established thresholds. The Company presents its derivative assets and derivative liabilities at their gross fair values in its Condensed Consolidated Balance Sheets. As of December 28, 2019 and September 28, 2019, the net cash collateral received by the Company related to derivative instruments under its collateral security arrangements was $1.0 billion and $1.6 billion, respectively, which were included in other current liabilities in the Condensed Consolidated Balance Sheets.

[0000320193-20-000010:notes:80]
Under master netting arrangements with the respective counterparties to the Company’s derivative contracts, the Company is allowed to net settle transactions with a single net amount payable by one party to the other. As of December 28, 2019 and September 28, 2019, the potential effects of these rights of set-off associated with the Company’s derivative contracts, including the effects of collateral, would be a reduction to both derivative assets and derivative liabilities of $2.4 billion and $2.7 billion, respectively, resulting in net derivative liabilities of $128 million and $407 million, respectively.

[0000320193-20-000010:notes:81]
[same as prior period, unchanged from 0000320193-19-000076:notes:85]

[0000320193-20-000010:notes:82]
[same as prior period, unchanged from 0000320193-19-000076:notes:86]

[0000320193-20-000010:notes:83]
[same as prior period, unchanged from 0000320193-19-000076:notes:87]

[0000320193-20-000010:notes:84]
As of both December 28, 2019 and September 28, 2019, the Company had no customers that individually represented 10% or more of total trade receivables. The Company’s cellular network carriers accounted for 43% and 51% of total trade receivables as of December 28, 2019 and September 28, 2019, respectively.

[0000320193-20-000010:notes:85]
[same as prior period, unchanged from 0000320193-19-000076:notes:89]

[0000320193-20-000010:notes:86]
The Company has non-trade receivables from certain of its manufacturing vendors resulting from the sale of components to these vendors who manufacture sub-assemblies or assemble final products for the Company. The Company purchases these components directly from suppliers. As of December 28, 2019, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 56% and 17%. As of September 28, 2019, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 59% and 14%.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000320193-20-000010:notes:87]
[same as prior period, unchanged from 0000320193-19-000076:notes:91]

[0000320193-20-000010:notes:88]
[same as prior period, unchanged from 0000320193-19-000076:notes:92]


## us-gaap:DerivativesPolicyTextBlock

[0000320193-20-000010:notes:89]
Derivatives that are not designated as hedging instruments are adjusted to fair value through earnings in the financial statement line item to which the derivative relates.
The Company records all derivatives in the Condensed Consolidated Balance Sheets at fair value. The Company’s accounting treatment for these derivative instruments is based on its hedge designation.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000320193-20-000010:notes:90]
Condensed Consolidated Financial Statement Details
The following tables show the Company’s condensed consolidated financial statement details as of December 28, 2019 and September 28, 2019 (in millions):

[0000320193-20-000010:notes:91]
[same as prior period, unchanged from 0000320193-19-000076:notes:95]

[0000320193-20-000010:notes:92]
|  | December 28, 2019 |  | September 28, 2019 |
| Land and buildings | $ | 17,754 |  |  | $ | 17,085 |  |
| Machinery, equipment and internal-use software | 70,841 |  |  | 69,797 |  |
| Leasehold improvements | 9,395 |  |  | 9,075 |  |
| Gross property, plant and equipment | 97,990 |  |  | 95,957 |  |
| Accumulated depreciation and amortization | (60,959 | ) |  | (58,579 | ) |
| Total property, plant and equipment, net | $ | 37,031 |  |  | $ | 37,378 |  |

[0000320193-20-000010:notes:93]
[same as prior period, unchanged from 0000320193-19-000076:notes:97]

[0000320193-20-000010:notes:94]
|  | December 28, 2019 |  | September 28, 2019 |
| Long-term taxes payable | $ | 28,198 |  |  | $ | 29,545 |  |
| Other non-current liabilities | 27,650 |  |  | 20,958 |  |
| Total other non-current liabilities | $ | 55,848 |  |  | $ | 50,503 |  |

[0000320193-20-000010:notes:95]
[same as prior period, unchanged from 0000320193-19-000076:notes:99]

[0000320193-20-000010:notes:96]
The following table shows the detail of OI&E for the three months ended December 28, 2019 and December 29, 2018 (in millions):

[0000320193-20-000010:notes:97]
|  | Three Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |
| Interest and dividend income | $ | 1,045 |  |  | $ | 1,307 |  |
| Interest expense | (785 | ) |  | (890 | ) |
| Other income, net | 89 |  |  | 143 |  |
| Total other income/(expense), net | $ | 349 |  |  | $ | 560 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000320193-20-000010:notes:98]
[same as prior period, unchanged from 0000320193-19-000076:notes:102]

[0000320193-20-000010:notes:99]
As of December 28, 2019, the total amount of gross unrecognized tax benefits was $16.4 billion, of which $8.9 billion, if recognized, would impact the Company’s effective tax rate. The Company had accrued $1.5 billion of gross interest and penalties related to income tax matters as of December 28, 2019.

[0000320193-20-000010:notes:100]
The Company is subject to taxation and files income tax returns in the U.S. federal jurisdiction and many state and foreign jurisdictions. The U.S. Internal Revenue Service concluded its review of the years 2013 through 2015 in 2018, and all years before 2016 are closed. Tax years after 2014 remain open in certain major foreign jurisdictions and are subject to examination by the taxing authorities. The Company believes that an adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax audits cannot be predicted with certainty. If any issues addressed in the Company’s tax audits are resolved in a manner inconsistent with its expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. Although the timing of resolution and/or closure of audits is not certain, the Company believes it is reasonably possible that its gross unrecognized tax benefits could decrease in the next 12 months by as much as $2.3 billion.

[0000320193-20-000010:notes:101]
[same as prior period, unchanged from 0000320193-19-000076:notes:105]

[0000320193-20-000010:notes:102]
On August 30, 2016, the European Commission announced its decision that Ireland granted state aid to the Company by providing tax opinions in 1991 and 2007 concerning the tax allocation of profits of the Irish branches of two subsidiaries of the Company (the “State Aid Decision”). The State Aid Decision ordered Ireland to calculate and recover additional taxes from the Company for the period June 2003 through December 2014. The recovery amount was calculated to be €13.1 billion, plus interest of €1.2 billion. On an annual basis, the Company may request approval from the Irish Minister for Finance to reduce the recovery amount for certain taxes paid to other countries. As of December 28, 2019, the adjusted recovery amount was €12.9 billion. Irish legislative changes, effective as of January 2015, eliminated the application of the tax opinions from that date forward. The Company believes the State Aid Decision to be without merit and appealed to the General Court of the Court of Justice of the European Union. Ireland has also appealed the State Aid Decision. The Company believes that any incremental Irish corporate income taxes potentially due related to the State Aid Decision would be creditable against U.S. taxes, subject to any foreign tax credit limitations in the U.S. Tax Cuts and Jobs Act. The adjusted recovery amount plus interest is funded into escrow, where it will remain restricted from general use pending the conclusion of all appeals. Refer to the Cash, Cash Equivalents and Marketable Securities section of Note 3, “Financial Instruments” for more information.


## us-gaap:DebtDisclosureTextBlock

[0000320193-20-000010:notes:103]
Debt
Commercial Paper

[0000320193-20-000010:notes:104]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of December 28, 2019 and September 28, 2019, the Company had $5.0 billion and $6.0 billion of Commercial Paper outstanding, respectively, with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 1.88% and 2.24% as of December 28, 2019 and September 28, 2019, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the three months ended December 28, 2019 and December 29, 2018 (in millions):

[0000320193-20-000010:notes:105]
|  | Three Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | (175 | ) |  | $ | 2,011 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 1,317 |  |  | 2,166 |  |
| Repayments of commercial paper | (2,121 | ) |  | (4,171 | ) |
| Repayments of commercial paper, net | (804 | ) |  | (2,005 | ) |
| Total proceeds from/(repayments of) commercial paper, net | $ | (979 | ) |  | $ | 6 |  |

[0000320193-20-000010:notes:106]
Term Debt

[0000320193-20-000010:notes:107]
As of December 28, 2019, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $103.1 billion (collectively the “Notes”). The Notes are senior unsecured obligations and interest is payable in arrears. The following table provides a summary of the Company’s term debt as of December 28, 2019 and September 28, 2019:

[0000320193-20-000010:notes:108]
|  | Maturities(calendar year) |  | December 28, 2019 |  | September 28, 2019 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 – 2019 debt issuances: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2020 | – | 2022 |  | $ | 4,250 |  |  |  | 1.97% | – | 3.04 | % |  | $ | 4,250 |  |  |  | 2.25% | – | 3.28 | % |
| Fixed-rate 0.350% – 4.650% notes | 2020 | – | 2049 |  | 96,610 |  |  |  | 0.28% | – | 4.78 | % |  | 97,429 |  |  |  | 0.28% | – | 4.78 | % |
| First quarter 2020 debt issuance of €2.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.000% – 0.500% notes | 2025 | – | 2031 |  | 2,226 |  |  |  | 0.03% | – | 0.56 | % |  | — |  |  |  |  |  | — | % |
| Total term debt |  |  |  |  | 103,086 |  |  |  |  |  |  |  | 101,679 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (229 | ) |  |  |  |  |  |  | (224 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | 445 |  |  |  |  |  |  |  | 612 |  |  |  |  |  |  |
| Less: Current portion of term debt |  |  |  |  | (10,224 | ) |  |  |  |  |  |  | (10,260 | ) |  |  |  |  |  |
| Total non-current portion of term debt |  |  |  |  | $ | 93,078 |  |  |  |  |  |  |  | $ | 91,807 |  |  |  |  |  |  |

[0000320193-20-000010:notes:109]
To manage interest rate risk on certain of its U.S. dollar–denominated fixed- or floating-rate notes, the Company has entered into interest rate swaps to effectively convert the fixed interest rates to floating interest rates or the floating interest rates to fixed interest rates on a portion of these notes. Additionally, to manage foreign currency risk on certain of its foreign currency–denominated notes, the Company has entered into foreign currency swaps to effectively convert these notes to U.S. dollar–denominated notes.

[0000320193-20-000010:notes:110]
A portion of the Company’s Japanese yen–denominated notes is designated as a hedge of the foreign currency exposure of the Company’s net investment in a foreign operation. As of December 28, 2019 and September 28, 2019, the carrying value of the debt designated as a net investment hedge was $1.2 billion and $1.0 billion, respectively. For further discussion regarding the Company’s use of derivative instruments, refer to the Derivative Financial Instruments section of Note 3, “Financial Instruments.”

[0000320193-20-000010:notes:111]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $757 million and $809 million of interest cost on its term debt for the three months ended December 28, 2019 and December 29, 2018, respectively.

[0000320193-20-000010:notes:112]
As of December 28, 2019 and September 28, 2019, the fair value of the Company’s Notes, based on Level 2 inputs, was $109.1 billion and $107.5 billion, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000320193-20-000010:notes:113]
Shareholders’ Equity
On April 30, 2019, the Company announced the Board of Directors increased the current share repurchase program authorization from $100 billion to $175 billion of the Company’s common stock, of which $116.1 billion had been utilized as of December 28, 2019. During the three months ended December 28, 2019, the Company repurchased 70.4 million shares of its common stock for $20.0 billion, including 30.4 million shares initially delivered under a $10.0 billion accelerated share repurchase arrangement (“ASR”) dated November 2019. The Company’s share repurchase program does not obligate it to acquire any specific number of shares. Under this program, shares may be repurchased in privately negotiated and/or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).

[0000320193-20-000010:notes:114]
Under the Company’s ASR, financial institutions deliver shares of the Company’s common stock during the purchase period in exchange for an up-front payment. The total number of shares ultimately delivered under the ASR, and therefore the average repurchase price paid per share, is determined based on the volume-weighted average price of the Company’s common stock during the purchase period, which will end in or before May 2020. The shares received are retired in the periods they are delivered, and the up-front payment is accounted for as a reduction to retained earnings in the Company’s Condensed Consolidated Statement of Shareholders’ Equity in the period the payment is made.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000320193-20-000010:notes:115]
Comprehensive Income
The Company’s OCI consists of foreign currency translation adjustments from those subsidiaries not using the U.S. dollar as their functional currency, net deferred gains and losses on certain derivative instruments accounted for as hedges and unrealized gains and losses on marketable debt securities classified as available-for-sale.

[0000320193-20-000010:notes:116]
The following table shows the pre-tax amounts reclassified from AOCI into the Condensed Consolidated Statements of Operations, and the associated financial statement line items, for the three months ended December 28, 2019 and December 29, 2018 (in millions):

[0000320193-20-000010:notes:117]
|  |  |  |  | Three Months Ended |
| Comprehensive Income Components |  | Financial Statement Line Items |  | December 28, 2019 |  | December 29, 2018 |
| Unrealized (gains)/losses on derivative instruments: |  |  |  |  |  |  |
| Foreign exchange contracts |  | Total net sales |  | $ | (97 | ) |  | $ | 63 |  |
|  |  | Total cost of sales |  | (171 | ) |  | (375 | ) |
|  |  | Other income/(expense), net |  | (223 | ) |  | 396 |  |
| Interest rate contracts |  | Other income/(expense), net |  | 2 |  |  | 1 |  |
|  |  |  |  | (489 | ) |  | 85 |  |
| Unrealized (gains)/losses on marketable securities |  | Other income/(expense), net |  | (13 | ) |  | 47 |  |
| Total amounts reclassified from AOCI |  | $ | (502 | ) |  | $ | 132 |  |

[0000320193-20-000010:notes:118]
The following table shows the changes in AOCI by component for the three months ended December 28, 2019 (in millions):

[0000320193-20-000010:notes:119]
|  | Cumulative ForeignCurrency Translation |  | Unrealized Gains/Losseson Derivative Instruments |  | Unrealized Gains/Losseson Marketable Securities |  | Total |
| Balances as of September 28, 2019 | $ | (1,463 | ) |  | $ | 172 |  |  | $ | 707 |  |  | $ | (584 | ) |
| Other comprehensive income/(loss) before reclassifications | 207 |  |  | 182 |  |  | 163 |  |  | 552 |  |
| Amounts reclassified from AOCI | — |  |  | (489 | ) |  | (13 | ) |  | (502 | ) |
| Tax effect | (5 | ) |  | 20 |  |  | (35 | ) |  | (20 | ) |
| Other comprehensive income/(loss) | 202 |  |  | (287 | ) |  | 115 |  |  | 30 |  |
| Cumulative effect of change in accounting principle (1) | — |  |  | 136 |  |  | — |  |  | 136 |  |
| Balances as of December 28, 2019 | $ | (1,261 | ) |  | $ | 21 |  |  | $ | 822 |  |  | $ | (418 | ) |

[0000320193-20-000010:notes:120]
[same as prior period, unchanged from 0000320193-19-000076:notes:124]

[0000320193-20-000010:notes:121]
Refer to Note 1, “Summary of Significant Accounting Policies” for more information on the Company’s adoption of ASU 2017-12 at the beginning of the first quarter of 2020.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000320193-20-000010:notes:122]
[same as prior period, unchanged from 0000320193-19-000076:notes:126]

[0000320193-20-000010:notes:123]
The Company had 194.4 million shares reserved for future issuance under its stock plans as of December 28, 2019. Restricted stock units (“RSUs”) granted under the Company’s stock plans generally vest over four years, based on continued employment, and are settled upon vesting in shares of the Company’s common stock on a one-for-one basis. RSUs granted under the Company’s stock plans reduce the number of shares available for grant under the plans by a factor of two times the number of RSUs granted. RSUs canceled and shares withheld to satisfy tax withholding obligations increase the number of shares available for grant under the plans utilizing a factor of two times the number of RSUs canceled or shares withheld.

[0000320193-20-000010:notes:124]
[same as prior period, unchanged from 0000320193-19-000076:notes:128]

[0000320193-20-000010:notes:125]
During the three months ended December 28, 2019, Section 16 officers Timothy D. Cook, Chris Kondo, Luca Maestri, Deirdre O’Brien and Jeffrey Williams had equity trading plans in place in accordance with Rule 10b5-1(c)(1) under the Exchange Act. An equity trading plan is a written document that pre-establishes the amounts, prices and dates (or formula for determining the amounts, prices and dates) of future purchases or sales of the Company’s stock, including shares acquired under the Company’s employee and director equity plans.

[0000320193-20-000010:notes:126]
[same as prior period, unchanged from 0000320193-19-000076:notes:130]

[0000320193-20-000010:notes:127]
A summary of the Company’s RSU activity and related information for the three months ended December 28, 2019 is as follows:

[0000320193-20-000010:notes:128]
|  | Number ofRSUs(in thousands) |  | Weighted-AverageGrant Date FairValue Per RSU |  | AggregateFair Value(in millions) |
| Balance as of September 28, 2019 | 81,517 |  |  | $ | 169.18 |  |  |  |
| RSUs granted | 33,775 |  |  | $ | 220.78 |  |  |  |
| RSUs vested | (17,837 | ) |  | $ | 150.42 |  |  |  |
| RSUs canceled | (1,435 | ) |  | $ | 184.51 |  |  |  |
| Balance as of December 28, 2019 | $ | 96,020 |  |  | $ | 190.59 |  |  | $ | 27,827 |  |

[0000320193-20-000010:notes:129]
The fair value as of the respective vesting dates of RSUs was $4.2 billion and $4.1 billion for the three months ended December 28, 2019 and December 29, 2018, respectively.

[0000320193-20-000010:notes:130]
[same as prior period, unchanged from 0000320193-19-000076:notes:134]

[0000320193-20-000010:notes:131]
The following table shows share-based compensation expense and the related income tax benefit included in the Condensed Consolidated Statements of Operations for the three months ended December 28, 2019 and December 29, 2018 (in millions):

[0000320193-20-000010:notes:132]
|  | Three Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |
| Share-based compensation expense | $ | 1,710 |  |  | $ | 1,559 |  |
| Income tax benefit related to share-based compensation expense | $ | (758 | ) |  | $ | (750 | ) |

[0000320193-20-000010:notes:133]
As of December 28, 2019, the total unrecognized compensation cost related to outstanding RSUs and stock options was $15.7 billion, which the Company expects to recognize over a weighted-average period of 2.9 years.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000320193-20-000010:notes:134]
Commitments and Contingencies
Accrued Warranty and Guarantees

[0000320193-20-000010:notes:135]
The following table shows changes in the Company’s accrued warranties and related costs for the three months ended December 28, 2019 and December 29, 2018 (in millions):

[0000320193-20-000010:notes:136]
|  | Three Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |
| Beginning accrued warranty and related costs | $ | 3,570 |  |  | $ | 3,692 |  |
| Cost of warranty claims | (915 | ) |  | (996 | ) |
| Accruals for product warranty | 1,218 |  |  | 1,123 |  |
| Ending accrued warranty and related costs | $ | 3,873 |  |  | $ | 3,819 |  |

[0000320193-20-000010:notes:137]
The Company offers an iPhone Upgrade Program, which is available to customers who purchase a qualifying iPhone in the U.S., the U.K. and mainland China. The iPhone Upgrade Program provides customers the right to trade in that iPhone for a specified amount when purchasing a new iPhone, provided certain conditions are met. The Company accounts for the trade-in right as a guarantee liability and recognizes arrangement revenue net of the fair value of such right, with subsequent changes to the guarantee liability recognized within net sales.

[0000320193-20-000010:notes:138]
Concentrations in the Available Sources of Supply of Materials and Product

[0000320193-20-000010:notes:139]
Although most components essential to the Company’s business are generally available from multiple sources, certain components are currently obtained from single or limited sources. The Company also competes for various components with other participants in the markets for smartphones, personal computers, tablets and other electronic devices. Therefore, many components used by the Company, including those that are available from multiple sources, are at times subject to industry-wide shortage and significant commodity pricing fluctuations.

[0000320193-20-000010:notes:140]
The Company uses some custom components that are not commonly used by its competitors, and new products introduced by the Company often utilize custom components available from only one source. When a component or product uses new technologies, initial capacity constraints may exist until the suppliers’ yields have matured or their manufacturing capacities have increased. The continued availability of these components at acceptable prices, or at all, may be affected if suppliers decide to concentrate on the production of common components instead of components customized to meet the Company’s requirements.

[0000320193-20-000010:notes:141]
The Company has entered into agreements for the supply of many components; however, there can be no guarantee that the Company will be able to extend or renew these agreements on similar terms, or at all.

[0000320193-20-000010:notes:142]
Substantially all of the Company’s hardware products are manufactured by outsourcing partners that are located primarily in Asia, with some Mac computers manufactured in the U.S. and Ireland.

[0000320193-20-000010:notes:143]
Unconditional Purchase Obligations

[0000320193-20-000010:notes:144]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of payments for supplier arrangements, Internet and telecommunication services, intellectual property licenses and content creation. As of December 28, 2019, the Company’s total future payments under noncancelable unconditional purchase obligations having a remaining term in excess of one year were $10.5 billion.

[0000320193-20-000010:notes:145]
Contingencies

[0000320193-20-000010:notes:146]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully resolved. The outcome of litigation is inherently uncertain. If one or more legal matters were resolved against the Company in a reporting period for amounts above management’s expectations, the Company’s financial condition and operating results for that reporting period could be materially adversely affected. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss greater than a recorded accrual, concerning loss contingencies for asserted legal and other claims, except for the following matters:

[0000320193-20-000010:notes:147]
VirnetX

[0000320193-20-000010:notes:148]
VirnetX, Inc. (“VirnetX”) filed two lawsuits in the U.S. District Court for the Eastern District of Texas (the “Eastern Texas District Court”) against the Company alleging that certain Company products infringe four patents (the “VirnetX Patents”) relating to network communications technology (“VirnetX I” and “VirnetX II”). On September 30, 2016, a jury returned a verdict in VirnetX I against the Company and awarded damages of $302 million, which later increased to $440 million in post-trial proceedings. The Company appealed the VirnetX I verdict to the U.S. Court of Appeals for the Federal Circuit (the “Federal Circuit”). On April 11, 2018, a jury returned a verdict in VirnetX II against the Company and awarded damages of $503 million. The Company appealed the VirnetX II verdict to the Federal Circuit, and on November 22, 2019, the Federal Circuit affirmed-in-part, reversed-in-part, and remanded VirnetX II back to the Eastern Texas District Court. The Company has challenged the validity of the VirnetX Patents at the U.S. Patent and Trademark Office (the “PTO”). In response, the PTO has declared the VirnetX Patents invalid. VirnetX appealed the invalidity decision of the PTO to the Federal Circuit. The Federal Circuit consolidated the Company’s appeal of the Eastern Texas District Court VirnetX I verdict and VirnetX’s appeals from the PTO invalidity proceedings. On January 15, 2019, the Federal Circuit affirmed the VirnetX I verdict, which the Company has further appealed. On July 8, 2019, the Federal Circuit remanded one of VirnetX’s two appeals of the PTO’s invalidity decisions back to the PTO for further proceedings. On August 1, 2019, the Federal Circuit affirmed-in-part, vacated-in-part, and remanded back to the PTO portions of VirnetX’s second appeal. The Company has accrued its best estimate for the ultimate resolution of these matters.

[0000320193-20-000010:notes:149]
iOS Performance Management Cases

[0000320193-20-000010:notes:150]
Various civil litigation matters have been filed in state and federal courts in the U.S. and in various international jurisdictions alleging violation of consumer protection laws, fraud, computer intrusion and other causes of action related to the Company’s performance management feature used in its iPhone operating systems, introduced to certain iPhones in iOS updates 10.2.1 and 11.2. The claims seek monetary damages and other non-monetary relief. On April 5, 2018, several U.S. federal actions were consolidated through a Multidistrict Litigation process into a single action in the U.S. District Court for the Northern District of California. In addition to civil litigation, the Company is also responding to governmental investigations and requests for information relating to the performance management feature. The Company believes that its iPhones were not defective, that the performance management feature introduced with iOS updates 10.2.1 and 11.2 was intended to, and did, improve customers’ user experience, and that the Company did not make any misleading statements or fail to disclose any material information. The Company has accrued its best estimate for the ultimate resolution of these matters.

[0000320193-20-000010:notes:151]
French Competition Authority

[0000320193-20-000010:notes:152]
In June 2019, the French Competition Authority (“FCA”) issued a report alleging that aspects of the Company’s sales and distribution practices in France violate French competition law. The Company vigorously disagrees with the allegations, and a hearing of arguments was held before the FCA on October 15, 2019. The Company is awaiting the decision of the FCA, which may include a fine.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000320193-20-000010:notes:153]
[same as prior period, unchanged from 0000320193-19-000076:notes:163]

[0000320193-20-000010:notes:154]
The Company manages its business primarily on a geographic basis. The Company’s reportable segments consist of the Americas, Europe, Greater China, Japan and Rest of Asia Pacific. Americas includes both North and South America. Europe includes European countries, as well as India, the Middle East and Africa. Greater China includes China, Hong Kong and Taiwan. Rest of Asia Pacific includes Australia and those Asian countries not included in the Company’s other reportable segments. Although the reportable segments provide similar hardware and software products and similar services, each one is managed separately to better align with the location of the Company’s customers and distribution partners and the unique market dynamics of each geographic region. The accounting policies of the various segments are the same as those described in Note 1, “Summary of Significant Accounting Policies” of the Notes to Consolidated Financial Statements in Part II, Item 8 of the 2019 Form 10-K.

[0000320193-20-000010:notes:155]
[same as prior period, unchanged from 0000320193-19-000076:notes:165]

[0000320193-20-000010:notes:156]
The following table shows information by reportable segment for the three months ended December 28, 2019 and December 29, 2018 (in millions):

[0000320193-20-000010:notes:157]
|  | Three Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |
| Americas: |  |  |  |
| Net sales | $ | 41,367 |  |  | $ | 36,940 |  |
| Operating income | $ | 13,092 |  |  | $ | 11,200 |  |
| Europe: |  |  |  |
| Net sales | $ | 23,273 |  |  | $ | 20,363 |  |
| Operating income | $ | 7,719 |  |  | $ | 6,658 |  |
| Greater China: |  |  |  |
| Net sales | $ | 13,578 |  |  | $ | 13,169 |  |
| Operating income | $ | 5,363 |  |  | $ | 5,314 |  |
| Japan: |  |  |  |
| Net sales | $ | 6,223 |  |  | $ | 6,910 |  |
| Operating income | $ | 2,778 |  |  | $ | 3,014 |  |
| Rest of Asia Pacific: |  |  |  |
| Net sales | $ | 7,378 |  |  | $ | 6,928 |  |
| Operating income | $ | 2,731 |  |  | $ | 2,560 |  |

[0000320193-20-000010:notes:158]
A reconciliation of the Company’s segment operating income to the Condensed Consolidated Statements of Operations for the three months ended December 28, 2019 and December 29, 2018 is as follows (in millions):

[0000320193-20-000010:notes:159]
|  | Three Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |
| Segment operating income | $ | 31,683 |  |  | $ | 28,746 |  |
| Research and development expense | (4,451 | ) |  | (3,902 | ) |
| Other corporate expenses, net | (1,663 | ) |  | (1,498 | ) |
| Total operating income | $ | 25,569 |  |  | $ | 23,346 |  |


## us-gaap:LesseeFinanceLeasesTextBlock

[0000320193-20-000010:notes:160]
Note 12 – Leases

[0000320193-20-000010:notes:161]
The Company has lease arrangements for certain equipment and facilities, including retail, corporate, manufacturing and data center space. These leases typically have original terms not exceeding 10 years and generally contain multi-year renewal options, some of which are reasonably certain of exercise. The Company’s lease arrangements may contain both lease and non-lease components. The Company has elected to combine and account for lease and non-lease components as a single lease component for leases of retail, corporate, and data center facilities.

[0000320193-20-000010:notes:162]
Payments under the Company’s lease arrangements may be fixed or variable, and variable lease payments are primarily based on purchases of output of the underlying leased assets. Lease costs associated with fixed payments on the Company’s operating leases were $369 million for the three months ended December 28, 2019. Lease costs associated with variable payments on the Company’s leases were $3.0 billion for the three months ended December 28, 2019.

[0000320193-20-000010:notes:163]
For the three months ended December 28, 2019, the Company made $349 million of fixed cash payments related to operating leases. Non-cash activities involving ROU assets obtained in exchange for lease liabilities were $8.2 billion for the three months ended December 28, 2019, including the impact of adopting the new leases standard.

[0000320193-20-000010:notes:164]
The following table shows ROU assets and lease liabilities, and the associated financial statement line items, as of December 28, 2019 (in millions):

[0000320193-20-000010:notes:165]
| Lease-Related Assets and Liabilities |  | Financial Statement Line Items |  | December 28, 2019 |
| Right-of-use assets: |  |  |  |  |
| Operating leases |  | Other non-current assets |  | $ | 7,262 |  |
| Finance leases |  | Property, plant and equipment, net |  | 629 |  |
| Total right-of-use assets |  |  |  | $ | 7,891 |  |
| Lease liabilities: |  |  |  |  |
| Operating leases |  | Other current liabilities |  | $ | 1,245 |  |
|  |  | Other non-current liabilities |  | 6,573 |  |
| Finance leases |  | Other current liabilities |  | 14 |  |
|  |  | Other non-current liabilities |  | 627 |  |
| Total lease liabilities |  |  |  | $ | 8,459 |  |

[0000320193-20-000010:notes:166]
Lease liability maturities as of December 28, 2019, are as follows (in millions):

[0000320193-20-000010:notes:167]
|  | Operating Leases |  | Finance Leases |  | Total |
| 2020 (remaining nine months) | $ | 1,051 |  |  | $ | 23 |  |  | $ | 1,074 |  |
| 2021 | 1,398 |  |  | 34 |  |  | 1,432 |  |
| 2022 | 1,218 |  |  | 35 |  |  | 1,253 |  |
| 2023 | 966 |  |  | 46 |  |  | 1,012 |  |
| 2024 | 845 |  |  | 25 |  |  | 870 |  |
| Thereafter | 3,579 |  |  | 921 |  |  | 4,500 |  |
| Total undiscounted liabilities | 9,057 |  |  | 1,084 |  |  | 10,141 |  |
| Less: Imputed interest | (1,239 | ) |  | (443 | ) |  | (1,682 | ) |
| Total lease liabilities | $ | 7,818 |  |  | $ | 641 |  |  | $ | 8,459 |  |

[0000320193-20-000010:notes:168]
The weighted-average remaining lease term and discount rate related to the Company’s lease liabilities as of December 28, 2019 were 10.2 years and 2.1%, respectively. The Company’s lease discount rates are generally based on estimates of its incremental borrowing rate, as the discount rates implicit in the Company’s leases cannot be readily determined.

[0000320193-20-000010:notes:169]
As of December 28, 2019, the Company had $2.1 billion of future payments under additional leases, primarily for corporate facilities and retail space, that had not yet commenced. These leases will commence between 2020 and 2022, with lease terms ranging from less than 1 year to 16 years.
