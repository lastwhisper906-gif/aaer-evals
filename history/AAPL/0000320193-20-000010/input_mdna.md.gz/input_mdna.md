# AAPL MD&A — 0000320193-20-000010


## mdna

[0000320193-20-000010:mdna:1]
[same as prior period, unchanged from 0000320193-19-000076:mdna:1]

[0000320193-20-000010:mdna:2]
[same as prior period, unchanged from 0000320193-19-000076:mdna:2]

[0000320193-20-000010:mdna:3]
The Company’s Annual Reports on Form 10-K, Quarterly Reports on Form 10-Q, Current Reports on Form 8-K, and amendments to reports filed pursuant to Sections 13(a) and 15(d) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), are filed with the SEC. The Company is subject to the informational requirements of the Exchange Act and files or furnishes reports, proxy statements and other information with the SEC. Such reports and other information filed by the Company with the SEC are available free of charge at investor.apple.com/investor-relations/sec-filings/default.aspx when such reports are available on the SEC’s website. The SEC maintains an Internet site that contains reports, proxy and information statements, and other information regarding issuers that file electronically with the SEC at www.sec.gov. The Company periodically provides other information for investors on its corporate website, www.apple.com, and its investor relations website, investor.apple.com. This includes press releases and other information about financial performance, information on corporate governance and details related to the Company’s annual meeting of shareholders. The information contained on the websites referenced in this Form 10-Q is not incorporated by reference into this filing. Further, the Company’s references to website URLs are intended to be inactive textual references only.

[0000320193-20-000010:mdna:4]
[same as prior period, unchanged from 0000320193-19-000076:mdna:4]

[0000320193-20-000010:mdna:5]
[same as prior period, unchanged from 0000320193-19-000076:mdna:5]

[0000320193-20-000010:mdna:6]
The Company has historically experienced higher net sales in its first quarter compared to other quarters in its fiscal year due in part to seasonal holiday demand. Additionally, new product and service introductions can significantly impact net sales, cost of sales and operating expenses. The timing of product introductions can also impact the Company’s net sales to its indirect distribution channels as these channels are filled with new inventory following a product launch, and channel inventory of an older product often declines as the launch of a newer product approaches. Net sales can also be affected when consumers and distributors anticipate a product introduction.

[0000320193-20-000010:mdna:7]
First Quarter Fiscal 2020 Highlights

[0000320193-20-000010:mdna:8]
Total net sales increased 9% or $7.5 billion during the first quarter of 2020 compared to the same quarter in 2019, primarily driven by higher iPhone and Wearables, Home and Accessories net sales. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on net sales during the first quarter of 2020.

[0000320193-20-000010:mdna:9]
During the first quarter of 2020, the Company began shipping AirPods Pro™, the new 16-inch MacBook Pro® and the updated Mac Pro®. Additionally, the Company released Apple TV+ as a new service.

[0000320193-20-000010:mdna:10]
The Company repurchased $20.0 billion of its common stock and paid dividends and dividend equivalents of $3.5 billion during the first quarter of 2020.

[0000320193-20-000010:mdna:11]
[same as prior period, unchanged from 0000320193-19-000076:mdna:11]

[0000320193-20-000010:mdna:12]
The following table shows net sales by category for the three months ended December 28, 2019 and December 29, 2018 (dollars in millions):

[0000320193-20-000010:mdna:13]
|  | Three Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |  | Change |
| Net sales by category: |  |  |  |  |  |
| iPhone (1) | $ | 55,957 |  |  | $ | 51,982 |  |  | 8 | % |
| Mac (1) | 7,160 |  |  | 7,416 |  |  | (3 | )% |
| iPad (1) | 5,977 |  |  | 6,729 |  |  | (11 | )% |
| Wearables, Home and Accessories (1)(2) | 10,010 |  |  | 7,308 |  |  | 37 | % |
| Services (3) | 12,715 |  |  | 10,875 |  |  | 17 | % |
| Total net sales | $ | 91,819 |  |  | $ | 84,310 |  |  | 9 | % |

[0000320193-20-000010:mdna:14]
[same as prior period, unchanged from 0000320193-19-000076:mdna:15]

[0000320193-20-000010:mdna:15]
[same as prior period, unchanged from 0000320193-19-000076:mdna:16]

[0000320193-20-000010:mdna:16]
| (3) | Services net sales include sales from the Company’s digital content stores and streaming services, AppleCare, licensing and other services. Services net sales also include amortization of the deferred value of Maps, Siri, and free iCloud and Apple TV + services, which are bundled in the sales price of certain products. |

[0000320193-20-000010:mdna:17]
[same as prior period, unchanged from 0000320193-19-000076:mdna:18]

[0000320193-20-000010:mdna:18]
iPhone net sales increased during the first quarter of 2020 compared to the same quarter in 2019 due primarily to the successful launch of the Company’s new iPhone models.

[0000320193-20-000010:mdna:19]
[same as prior period, unchanged from 0000320193-19-000076:mdna:20]

[0000320193-20-000010:mdna:20]
Mac net sales decreased during the first quarter of 2020 compared to the same quarter in 2019 due primarily to the timing of the MacBook Air® launch in the first quarter of 2019.

[0000320193-20-000010:mdna:21]
[same as prior period, unchanged from 0000320193-19-000076:mdna:22]

[0000320193-20-000010:mdna:22]
iPad net sales decreased during the first quarter of 2020 compared to the same quarter in 2019 due primarily to the timing of the iPad Pro® launch in the first quarter of 2019.

[0000320193-20-000010:mdna:23]
[same as prior period, unchanged from 0000320193-19-000076:mdna:24]

[0000320193-20-000010:mdna:24]
Wearables, Home and Accessories net sales increased during the first quarter of 2020 compared to the same quarter in 2019 due primarily to higher net sales of Wearables, including AirPods and Apple Watch.

[0000320193-20-000010:mdna:25]
[same as prior period, unchanged from 0000320193-19-000076:mdna:26]

[0000320193-20-000010:mdna:26]
Services net sales increased during the first quarter of 2020 compared to the same quarter in 2019 due primarily to higher net sales from AppleCare, the App Store and licensing.

[0000320193-20-000010:mdna:27]
[same as prior period, unchanged from 0000320193-19-000076:mdna:28]

[0000320193-20-000010:mdna:28]
[same as prior period, unchanged from 0000320193-19-000076:mdna:29]

[0000320193-20-000010:mdna:29]
The following table shows net sales by reportable segment for the three months ended December 28, 2019 and December 29, 2018 (dollars in millions):

[0000320193-20-000010:mdna:30]
|  | Three Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |  | Change |
| Net sales by reportable segment: |  |  |  |  |  |
| Americas | $ | 41,367 |  |  | $ | 36,940 |  |  | 12 | % |
| Europe | 23,273 |  |  | 20,363 |  |  | 14 | % |
| Greater China | 13,578 |  |  | 13,169 |  |  | 3 | % |
| Japan | 6,223 |  |  | 6,910 |  |  | (10 | )% |
| Rest of Asia Pacific | 7,378 |  |  | 6,928 |  |  | 6 | % |
| Total net sales | $ | 91,819 |  |  | $ | 84,310 |  |  | 9 | % |

[0000320193-20-000010:mdna:31]
[same as prior period, unchanged from 0000320193-19-000076:mdna:32]

[0000320193-20-000010:mdna:32]
Americas net sales increased during the first quarter of 2020 compared to the same quarter in 2019 due primarily to higher iPhone and Wearables, Home and Accessories net sales.

[0000320193-20-000010:mdna:33]
[same as prior period, unchanged from 0000320193-19-000076:mdna:34]

[0000320193-20-000010:mdna:34]
Europe net sales increased during the first quarter of 2020 compared to the same quarter in 2019 due primarily to higher iPhone and Wearables, Home and Accessories net sales. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on Europe net sales during the first quarter of 2020.

[0000320193-20-000010:mdna:35]
[same as prior period, unchanged from 0000320193-19-000076:mdna:36]

[0000320193-20-000010:mdna:36]
Greater China net sales increased during the first quarter of 2020 compared to the same quarter in 2019 due primarily to higher Wearables, Home and Accessories net sales. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on Greater China net sales during the first quarter of 2020.

[0000320193-20-000010:mdna:37]
[same as prior period, unchanged from 0000320193-19-000076:mdna:38]

[0000320193-20-000010:mdna:38]
Japan net sales decreased during the first quarter of 2020 compared to the same quarter in 2019 due primarily to lower iPhone net sales, partially offset by higher Services net sales. The strength of the Japanese Yen relative to the U.S. dollar had a favorable impact on Japan net sales during the first quarter of 2020.

[0000320193-20-000010:mdna:39]
[same as prior period, unchanged from 0000320193-19-000076:mdna:40]

[0000320193-20-000010:mdna:40]
Rest of Asia Pacific net sales increased during the first quarter of 2020 compared to the same quarter in 2019 due primarily to higher Wearables, Home and Accessories and Services net sales. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on Rest of Asia Pacific net sales during the first quarter of 2020.

[0000320193-20-000010:mdna:41]
[same as prior period, unchanged from 0000320193-19-000076:mdna:42]

[0000320193-20-000010:mdna:42]
Products and Services gross margin and gross margin percentage for the three months ended December 28, 2019 and December 29, 2018 were as follows (dollars in millions):

[0000320193-20-000010:mdna:43]
|  | Three Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |
| Gross margin: |  |  |  |
| Products | $ | 27,029 |  |  | $ | 25,197 |  |
| Services | 8,188 |  |  | 6,834 |  |
| Total gross margin | $ | 35,217 |  |  | $ | 32,031 |  |
| Gross margin percentage: |  |  |  |
| Products | 34.2 | % |  | 34.3 | % |
| Services | 64.4 | % |  | 62.8 | % |
| Total gross margin percentage | 38.4 | % |  | 38.0 | % |

[0000320193-20-000010:mdna:44]
[same as prior period, unchanged from 0000320193-19-000076:mdna:45]

[0000320193-20-000010:mdna:45]
Products gross margin increased during the first quarter of 2020 compared to the same quarter in 2019 due primarily to higher leverage, partially offset by the weakness in foreign currencies relative to the U.S. dollar. Products gross margin percentage during the first quarter of 2020 was relatively flat compared to the same quarter in 2019.

[0000320193-20-000010:mdna:46]
[same as prior period, unchanged from 0000320193-19-000076:mdna:48]

[0000320193-20-000010:mdna:47]
Services gross margin and Services gross margin percentage increased during the first quarter of 2020 compared to the same quarter in 2019 due primarily to a favorable Services mix and higher leverage, partially offset by higher Services costs.

[0000320193-20-000010:mdna:48]
The Company’s future gross margins can be impacted by a variety of factors, as discussed in Part I, Item 1A of the 2019 Form 10-K under the heading “Risk Factors”. As a result, the Company believes, in general, gross margins will be subject to volatility and remain under downward pressure.

[0000320193-20-000010:mdna:49]
[same as prior period, unchanged from 0000320193-19-000076:mdna:51]

[0000320193-20-000010:mdna:50]
Operating expenses for the three months ended December 28, 2019 and December 29, 2018 were as follows (dollars in millions):

[0000320193-20-000010:mdna:51]
|  | Three Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |
| Research and development | $ | 4,451 |  |  | $ | 3,902 |  |
| Percentage of total net sales | 5 | % |  | 5 | % |
| Selling, general and administrative | $ | 5,197 |  |  | $ | 4,783 |  |
| Percentage of total net sales | 6 | % |  | 6 | % |
| Total operating expenses | $ | 9,648 |  |  | $ | 8,685 |  |
| Percentage of total net sales | 11 | % |  | 10 | % |

[0000320193-20-000010:mdna:52]
[same as prior period, unchanged from 0000320193-19-000076:mdna:54]

[0000320193-20-000010:mdna:53]
The growth in research and development (“R&D”) expense during the first quarter of 2020 compared to the same quarter in 2019 was driven primarily by increases in headcount-related expenses. The Company continues to believe that focused investments in R&D are critical to its future growth and competitive position in the marketplace, and to the development of new and updated products and services that are central to the Company’s core business strategy.

[0000320193-20-000010:mdna:54]
[same as prior period, unchanged from 0000320193-19-000076:mdna:56]

[0000320193-20-000010:mdna:55]
The growth in selling, general and administrative expense during the first quarter of 2020 compared to the same quarter in 2019 was driven primarily by higher spending on marketing and advertising and increases in headcount-related expenses.

[0000320193-20-000010:mdna:56]
[same as prior period, unchanged from 0000320193-19-000076:mdna:58]

[0000320193-20-000010:mdna:57]
Other income/(expense), net (“OI&E”) for the three months ended December 28, 2019 and December 29, 2018 was as follows (dollars in millions):

[0000320193-20-000010:mdna:58]
|  | Three Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |  | Change |
| Interest and dividend income | $ | 1,045 |  |  | $ | 1,307 |  |  |  |
| Interest expense | (785 | ) |  | (890 | ) |  |  |
| Other income, net | 89 |  |  | 143 |  |  |  |
| Total other income/(expense), net | $ | 349 |  |  | $ | 560 |  |  | (38 | )% |

[0000320193-20-000010:mdna:59]
The decrease in OI&E during the first quarter of 2020 compared to the same quarter in 2019 was due primarily to lower interest income, partially offset by lower interest expense. The weighted-average interest rate earned by the Company on its cash, cash equivalents and marketable securities was 2.08% and 2.19% in the first quarter of 2020 and 2019, respectively.

[0000320193-20-000010:mdna:60]
[same as prior period, unchanged from 0000320193-19-000076:mdna:62]

[0000320193-20-000010:mdna:61]
Provision for income taxes, effective tax rate and statutory federal income tax rate for the three months ended December 28, 2019 and December 29, 2018 were as follows (dollars in millions):

[0000320193-20-000010:mdna:62]
|  | Three Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |
| Provision for income taxes | $ | 3,682 |  |  | $ | 3,941 |  |
| Effective tax rate | 14.2 | % |  | 16.5 | % |
| Statutory federal income tax rate | 21 | % |  | 21 | % |

[0000320193-20-000010:mdna:63]
The Company’s effective tax rate for the first quarter of 2020 was lower than the statutory federal income tax rate due primarily to lower tax rates on foreign earnings, tax benefits from share-based compensation and a one-time adjustment of U.S. foreign tax credits in response to regulations issued by the U.S. Department of the Treasury in December 2019.

[0000320193-20-000010:mdna:64]
The Company’s effective tax rate for the first quarter of 2020 was lower compared to the same quarter in 2019 due to a one-time adjustment of U.S. foreign tax credits.

[0000320193-20-000010:mdna:65]
[same as prior period, unchanged from 0000320193-19-000076:mdna:67]

[0000320193-20-000010:mdna:66]
[same as prior period, unchanged from 0000320193-19-000076:mdna:70]

[0000320193-20-000010:mdna:67]
In June 2016, the Financial Accounting Standards Board issued Accounting Standards Update No. 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (“ASU 2016-13”), which modifies the measurement of expected credit losses on certain financial instruments. The Company will adopt ASU 2016-13 in its first quarter of 2021 utilizing the modified retrospective transition method. Based on the composition of the Company’s investment portfolio, current market conditions, and historical credit loss activity, the adoption of ASU 2016-13 is not expected to have a material impact on its consolidated financial statements.

[0000320193-20-000010:mdna:68]
[same as prior period, unchanged from 0000320193-19-000076:mdna:74]

[0000320193-20-000010:mdna:69]
The following tables present selected financial information and statistics as of December 28, 2019 and September 28, 2019 and for the first three months of 2020 and 2019 (in millions):

[0000320193-20-000010:mdna:70]
|  | December 28, 2019 |  | September 28, 2019 |
| Cash, cash equivalents and marketable securities (1) | $ | 207,061 |  |  | $ | 205,898 |  |
| Property, plant and equipment, net | $ | 37,031 |  |  | $ | 37,378 |  |
| Commercial paper | $ | 4,990 |  |  | $ | 5,980 |  |
| Total term debt | $ | 103,302 |  |  | $ | 102,067 |  |
| Working capital | $ | 61,070 |  |  | $ | 57,101 |  |

[0000320193-20-000010:mdna:71]
|  | Three Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |
| Cash generated by operating activities | $ | 30,516 |  |  | $ | 26,690 |  |
| Cash generated by/(used in) investing activities | $ | (13,668 | ) |  | $ | 5,844 |  |
| Cash used in financing activities | $ | (25,407 | ) |  | $ | (13,676 | ) |

[0000320193-20-000010:mdna:72]
| (1) | As of December 28, 2019 and September 28, 2019, total marketable securities included $19.1 billion and $18.9 billion, respectively, that was restricted from general use, related to the State Aid Decision (refer to Note 5, “Income Taxes” in the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Form 10-Q) and other agreements. |

[0000320193-20-000010:mdna:73]
[same as prior period, unchanged from 0000320193-19-000076:mdna:79]

[0000320193-20-000010:mdna:74]
In connection with the State Aid Decision, as of December 28, 2019, the adjusted recovery amount of €12.9 billion plus interest of €1.2 billion was funded into escrow, where it will remain restricted from general use pending the conclusion of all appeals.

[0000320193-20-000010:mdna:75]
[same as prior period, unchanged from 0000320193-19-000076:mdna:81]

[0000320193-20-000010:mdna:76]
During the three months ended December 28, 2019, cash generated by operating activities of $30.5 billion was a result of $22.2 billion of net income, non-cash adjustments to net income of $4.0 billion and an increase in the net change in operating assets and liabilities of $4.2 billion. Cash used in investing activities of $13.7 billion during the three months ended December 28, 2019 consisted primarily of cash used for purchases of marketable securities, net of sales and maturities, of $10.4 billion and cash used to acquire property, plant and equipment of $2.1 billion. Cash used in financing activities of $25.4 billion during the three months ended December 28, 2019 consisted primarily of cash used to repurchase common stock of $20.7 billion, cash used to pay dividends and dividend equivalents of $3.5 billion and cash used to repay term debt of $1.0 billion, partially offset by net proceeds from the issuance of term debt of $2.2 billion.

[0000320193-20-000010:mdna:77]
During the three months ended December 29, 2018, cash generated by operating activities of $26.7 billion was a result of $20.0 billion of net income, non-cash adjustments to net income of $5.0 billion and an increase in the net change in operating assets and liabilities of $1.8 billion. Cash generated by investing activities of $5.8 billion during the three months ended December 29, 2018 consisted primarily of proceeds from maturities and sales of marketable securities, net of purchases, of $9.8 billion, partially offset by cash used to acquire property, plant and equipment of $3.4 billion. Cash used in financing activities of $13.7 billion during the three months ended December 29, 2018 consisted primarily of cash used to repurchase common stock of $8.8 billion and cash used to pay dividends and dividend equivalents of $3.6 billion.

[0000320193-20-000010:mdna:78]
[same as prior period, unchanged from 0000320193-19-000076:mdna:86]

[0000320193-20-000010:mdna:79]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses the net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of December 28, 2019, the Company had $5.0 billion of Commercial Paper outstanding, with a weighted-average interest rate of 1.88% and maturities generally less than nine months.

[0000320193-20-000010:mdna:80]
As of December 28, 2019, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $103.1 billion (collectively the “Notes”). During the first three months of 2020, the Company issued $2.2 billion and repaid $1.0 billion of Notes. The Company has entered, and in the future may enter, into interest rate swaps to manage interest rate risk on the Notes. In addition, the Company has entered, and in the future may enter, into foreign currency swaps to manage foreign currency risk on the Notes.

[0000320193-20-000010:mdna:81]
[same as prior period, unchanged from 0000320193-19-000076:mdna:89]

[0000320193-20-000010:mdna:82]
[same as prior period, unchanged from 0000320193-19-000076:mdna:90]

[0000320193-20-000010:mdna:83]
On April 30, 2019, the Company announced the Board of Directors increased the current share repurchase program authorization from $100 billion to $175 billion of the Company’s common stock, of which $116.1 billion had been utilized as of December 28, 2019. During the three months ended December 28, 2019, the Company repurchased 70.4 million shares of its common stock for $20.0 billion, including 30.4 million shares initially delivered under a $10.0 billion accelerated share repurchase arrangement (“ASR”) dated November 2019. The Company’s share repurchase program does not obligate it to acquire any specific number of shares. Under this program, shares may be repurchased in privately negotiated and/or open market transactions, including under plans complying with Rule 10b5-1 under the Exchange Act.

[0000320193-20-000010:mdna:84]
[same as prior period, unchanged from 0000320193-19-000076:mdna:92]

[0000320193-20-000010:mdna:85]
[same as prior period, unchanged from 0000320193-19-000076:mdna:93]

[0000320193-20-000010:mdna:86]
[same as prior period, unchanged from 0000320193-19-000076:mdna:72]

[0000320193-20-000010:mdna:87]
As of December 28, 2019, the Company’s total fixed lease payment obligations were $12.2 billion, of which $7.2 billion was included in other non-current liabilities in the Company’s Condensed Consolidated Balance Sheet. The Company’s leases typically have original terms not exceeding 10 years and generally contain multi-year renewal options.

[0000320193-20-000010:mdna:88]
[same as prior period, unchanged from 0000320193-19-000076:mdna:96]

[0000320193-20-000010:mdna:89]
The Company utilizes several outsourcing partners to manufacture sub-assemblies for the Company’s products and to perform final assembly and testing of finished products. These outsourcing partners acquire components and build product based on demand information supplied by the Company, which typically covers periods up to 150 days. The Company also obtains individual components for its products from a wide variety of individual suppliers. As of December 28, 2019, the Company expects to pay $30.2 billion under manufacturing-related supplier arrangements, which are primarily noncancelable.

[0000320193-20-000010:mdna:90]
[same as prior period, unchanged from 0000320193-19-000076:mdna:98]

[0000320193-20-000010:mdna:91]
The Company’s other purchase obligations consist of noncancelable obligations to acquire capital assets, including product tooling and manufacturing process equipment, and noncancelable obligations related to advertising, licensing, R&D, Internet and telecommunications services, content creation and other activities. As of December 28, 2019, the Company had other purchase obligations of $9.0 billion.

[0000320193-20-000010:mdna:92]
Deemed Repatriation Tax Payable

[0000320193-20-000010:mdna:93]
As of December 28, 2019, the balance of the deemed repatriation tax payable imposed by the U.S. Tax Cuts and Jobs Act (the “Act”) was $28.2 billion, and was included in other non-current liabilities in the Company’s Condensed Consolidated Balance Sheet. The Company plans to pay the deemed repatriation tax payable in installments in accordance with the Act.

[0000320193-20-000010:mdna:94]
[same as prior period, unchanged from 0000320193-19-000076:mdna:100]

[0000320193-20-000010:mdna:95]
The Company’s remaining other non-current liabilities primarily consist of items for which the Company is unable to make a reasonably reliable estimate of the timing or amount of payments.

[0000320193-20-000010:mdna:96]
[same as prior period, unchanged from 0000320193-19-000076:mdna:106]

[0000320193-20-000010:mdna:97]
[same as prior period, unchanged from 0000320193-19-000076:mdna:107]

[0000320193-20-000010:mdna:98]
Note 1, “Summary of Significant Accounting Policies” in Part I, Item 1 of this Form 10-Q and in the Notes to Consolidated Financial Statements in Part II, Item 8 of the 2019 Form 10-K, and “Critical Accounting Policies and Estimates” in Part II, Item 7 of the 2019 Form 10-K describe the significant accounting policies and methods used in the preparation of the Company’s condensed consolidated financial statements. There have been no material changes to the Company’s critical accounting policies and estimates since the 2019 Form 10-K.
