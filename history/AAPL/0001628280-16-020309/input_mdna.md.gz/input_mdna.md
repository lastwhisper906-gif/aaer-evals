# AAPL MD&A — 0001628280-16-020309


## mdna

[0001628280-16-020309:mdna:1]
| Item 7. | Management’s Discussion and Analysis of Financial Condition and Results of Operations |

[0001628280-16-020309:mdna:2]
Overview and Highlights

[0001628280-16-020309:mdna:3]
The Company designs, manufactures and markets mobile communication and media devices, personal computers and portable digital music players, and sells a variety of related software, services, accessories, networking solutions and third-party digital content and applications. The Company’s products and services include iPhone®, iPad®, Mac®, iPod®, Apple Watch®, Apple TV®, a portfolio of consumer and professional software applications, iOS, macOS™, watchOS® and tvOS™ operating systems, iCloud®, Apple Pay® and a variety of accessory, service and support offerings. The Company sells and delivers digital content and applications through the iTunes Store®, App Store®, Mac App Store, TV App Store, iBooks Store™ and Apple Music® (collectively “Internet Services”). The Company sells its products worldwide through its retail stores, online stores and direct sales force, as well as through third-party cellular network carriers, wholesalers, retailers and value-added resellers. In addition, the Company sells a variety of third-party Apple compatible products, including application software and various accessories through its retail and online stores. The Company sells to consumers, small and mid-sized businesses and education, enterprise and government customers.

[0001628280-16-020309:mdna:4]
Fiscal 2016 Highlights

[0001628280-16-020309:mdna:5]
Net sales declined 8% or $18.1 billion during 2016 compared to 2015, primarily driven by a year-over-year decrease in iPhone net sales and the effect of weakness in most foreign currencies relative to the U.S. dollar, partially offset by an increase in Services. In April 2016, the Company announced a significant increase to its capital return program by raising the expected total size of the program from $200 billion to $250 billion through March 2018. This included increasing its share repurchase authorization from $140 billion to $175 billion and raising its quarterly dividend from $0.52 to $0.57 per share beginning in May 2016. During 2016, the Company spent $29.0 billion to repurchase shares of its common stock and paid dividends and dividend equivalents of $12.2 billion. Additionally, the Company issued $23.9 billion of U.S. dollar-denominated term debt and A$1.4 billion of Australian dollar-denominated term debt during 2016.

[0001628280-16-020309:mdna:6]
Fiscal 2015 Highlights

[0001628280-16-020309:mdna:7]
Net sales rose 28% or $50.9 billion during 2015 compared to 2014, driven by a year-over-year increase in iPhone net sales. iPhone net sales and unit sales in 2015 increased in all of the Company’s reportable operating segments. The Company also experienced year-over-year net sales increases in Mac, Services and Other Products. Apple Watch, which launched during the third quarter of 2015, accounted for more than 100% of the year-over-year growth in net sales of Other Products. Net sales growth during 2015 was partially offset by the effect of weakness in most foreign currencies relative to the U.S. dollar and lower iPad net sales. Total net sales increased in each of the Company’s reportable operating segments, with particularly strong growth in Greater China where year-over-year net sales increased 84%.

[0001628280-16-020309:mdna:8]
In April 2015, the Company announced a significant increase to its capital return program by raising the expected total size of the program to $200 billion through March 2017. This included increasing its share repurchase authorization to $140 billion and raising its quarterly dividend to $0.52 per share beginning in May 2015. During 2015, the Company spent $36.0 billion to repurchase shares of its common stock and paid dividends and dividend equivalents of $11.6 billion. Additionally, the Company issued $14.5 billion of U.S. dollar-denominated, €4.8 billion of euro-denominated, SFr1.3 billion of Swiss franc-denominated, £1.3 billion of British pound-denominated, A$2.3 billion of Australian dollar-denominated and ¥250.0 billion of Japanese yen-denominated term debt during 2015.

[0001628280-16-020309:mdna:9]
Sales Data

[0001628280-16-020309:mdna:10]
The following table shows net sales by operating segment and net sales and unit sales by product during 2016, 2015 and 2014 (dollars in millions and units in thousands):

[0001628280-16-020309:mdna:11]
|  | 2016 |  | Change |  | 2015 |  | Change |  | 2014 |
| Net Sales by Operating Segment: |  |  |  |  |  |  |  |  |  |
| Americas | $ | 86,613 |  |  | (8 | )% |  | $ | 93,864 |  |  | 17 | % |  | $ | 80,095 |  |
| Europe | 49,952 |  |  | (1 | )% |  | 50,337 |  |  | 14 | % |  | 44,285 |  |
| Greater China | 48,492 |  |  | (17 | )% |  | 58,715 |  |  | 84 | % |  | 31,853 |  |
| Japan | 16,928 |  |  | 8 | % |  | 15,706 |  |  | 3 | % |  | 15,314 |  |
| Rest of Asia Pacific | 13,654 |  |  | (10 | )% |  | 15,093 |  |  | 34 | % |  | 11,248 |  |
| Total net sales | $ | 215,639 |  |  | (8 | )% |  | $ | 233,715 |  |  | 28 | % |  | $ | 182,795 |  |
| Net Sales by Product: |  |  |  |  |  |  |  |  |  |
| iPhone (1) | $ | 136,700 |  |  | (12 | )% |  | $ | 155,041 |  |  | 52 | % |  | $ | 101,991 |  |
| iPad (1) | 20,628 |  |  | (11 | )% |  | 23,227 |  |  | (23 | )% |  | 30,283 |  |
| Mac (1) | 22,831 |  |  | (10 | )% |  | 25,471 |  |  | 6 | % |  | 24,079 |  |
| Services (2) | 24,348 |  |  | 22 | % |  | 19,909 |  |  | 10 | % |  | 18,063 |  |
| Other Products (1)(3) | 11,132 |  |  | 11 | % |  | 10,067 |  |  | 20 | % |  | 8,379 |  |
| Total net sales | $ | 215,639 |  |  | (8 | )% |  | $ | 233,715 |  |  | 28 | % |  | $ | 182,795 |  |
| Unit Sales by Product: |  |  |  |  |  |  |  |  |  |
| iPhone | 211,884 |  |  | (8 | )% |  | 231,218 |  |  | 37 | % |  | 169,219 |  |
| iPad | 45,590 |  |  | (17 | )% |  | 54,856 |  |  | (19 | )% |  | 67,977 |  |
| Mac | 18,484 |  |  | (10 | )% |  | 20,587 |  |  | 9 | % |  | 18,906 |  |

[0001628280-16-020309:mdna:12]
| (1) | Includes deferrals and amortization of related software upgrade rights and non-software services. |

[0001628280-16-020309:mdna:13]
| (2) | Includes revenue from Internet Services, AppleCare®, Apple Pay, licensing and other services. |

[0001628280-16-020309:mdna:14]
| (3) | Includes sales of Apple TV, Apple Watch, Beats® products, iPod and Apple-branded and third-party accessories. |

[0001628280-16-020309:mdna:15]
Product Performance

[0001628280-16-020309:mdna:16]
iPhone

[0001628280-16-020309:mdna:17]
The following table presents iPhone net sales and unit sales information for 2016, 2015 and 2014 (dollars in millions and units in thousands):

[0001628280-16-020309:mdna:18]
|  | 2016 |  | Change |  | 2015 |  | Change |  | 2014 |
| Net sales | $ | 136,700 |  |  | (12 | )% |  | $ | 155,041 |  |  | 52 | % |  | $ | 101,991 |  |
| Percentage of total net sales | 63 | % |  |  |  |  | 66 | % |  |  |  | 56 | % |
| Unit sales | 211,884 |  |  | (8 | )% |  | 231,218 |  |  | 37 | % |  | 169,219 |  |

[0001628280-16-020309:mdna:19]
iPhone net sales and unit sales decreased during 2016 compared to 2015. The Company believes the sales decline is due primarily to a lower rate of iPhone upgrades during 2016 compared to 2015 and challenging macroeconomic conditions in a number of major markets in 2016. Average selling prices (“ASPs”) for iPhone were lower year-over-year during 2016 due primarily to a different mix of iPhones, including the iPhone SE introduced in 2016, and the effect of weakness in most foreign currencies relative to the U.S. dollar.

[0001628280-16-020309:mdna:20]
The year-over-year growth in iPhone net sales and unit sales during 2015 primarily resulted from strong demand for iPhone 6 and 6 Plus during 2015. Overall ASPs for iPhone increased during 2015 compared to 2014, due primarily to the introduction of iPhone 6 and 6 Plus in September 2014, partially offset by the effect of weakness in most foreign currencies relative to the U.S. dollar.

[0001628280-16-020309:mdna:21]
iPad

[0001628280-16-020309:mdna:22]
The following table presents iPad net sales and unit sales information for 2016, 2015 and 2014 (dollars in millions and units in thousands):

[0001628280-16-020309:mdna:23]
|  | 2016 |  | Change |  | 2015 |  | Change |  | 2014 |
| Net sales | $ | 20,628 |  |  | (11 | )% |  | $ | 23,227 |  |  | (23 | )% |  | $ | 30,283 |  |
| Percentage of total net sales | 10 | % |  |  |  | 10 | % |  |  |  | 17 | % |
| Unit sales | 45,590 |  |  | (17 | )% |  | 54,856 |  |  | (19 | )% |  | 67,977 |  |

[0001628280-16-020309:mdna:24]
iPad net sales decreased during 2016 compared to 2015 primarily due to lower unit sales and the effect of weakness in most foreign currencies relative to the U.S. dollar, partially offset by higher ASPs due to a shift in mix to higher-priced iPads. The Company believes the decline in iPad sales is due in part to a longer repurchase cycle for iPads and some level of cannibalization from the Company's other products.

[0001628280-16-020309:mdna:25]
Net sales and unit sales for iPad declined during 2015 compared to 2014. The Company believes the decline in iPad sales is due in part to a longer repurchase cycle for iPads and some level of cannibalization from the Company's other products. iPad ASPs declined during 2015 compared to 2014, primarily as a result of the effect of weakness in most foreign currencies relative to the U.S. dollar and a shift in mix to lower-priced iPads.

[0001628280-16-020309:mdna:26]
Mac

[0001628280-16-020309:mdna:27]
The following table presents Mac net sales and unit sales information for 2016, 2015 and 2014 (dollars in millions and units in thousands):

[0001628280-16-020309:mdna:28]
|  | 2016 |  | Change |  | 2015 |  | Change |  | 2014 |
| Net sales | $ | 22,831 |  |  | (10 | )% |  | $ | 25,471 |  |  | 6 | % |  | $ | 24,079 |  |
| Percentage of total net sales | 11 | % |  |  |  | 11 | % |  |  |  | 13 | % |
| Unit sales | 18,484 |  |  | (10 | )% |  | 20,587 |  |  | 9 | % |  | 18,906 |  |

[0001628280-16-020309:mdna:29]
Mac net sales and unit sales decreased during 2016 compared to 2015. The year-over-year decline in Mac unit sales during 2016 was at rates similar to the overall market. The effect of weakness in most foreign currencies relative to the U.S. dollar also negatively impacted Mac net sales.

[0001628280-16-020309:mdna:30]
The year-over-year growth in Mac net sales and unit sales during 2015 was driven by strong demand for Mac portables. Mac ASPs declined during 2015 compared to 2014 largely due to the effect of weakness in most foreign currencies relative to the U.S. dollar.

[0001628280-16-020309:mdna:31]
Services

[0001628280-16-020309:mdna:32]
The following table presents net sales information of Services for 2016, 2015 and 2014 (dollars in millions):

[0001628280-16-020309:mdna:33]
|  | 2016 |  | Change |  | 2015 |  | Change |  | 2014 |
| Net sales | $ | 24,348 |  |  | 22 | % |  | $ | 19,909 |  |  | 10 | % |  | $ | 18,063 |  |
| Percentage of total net sales | 11 | % |  |  |  | 9 | % |  |  |  | 10 | % |

[0001628280-16-020309:mdna:34]
The year-over-year increase in net sales of Services in 2016 was due primarily to growth from the App Store, licensing and AppleCare sales, partially offset by the effect of weakness in most foreign currencies relative to the U.S. dollar. During the first quarter of 2016, the Company received $548 million from Samsung Electronics Co., Ltd. related to its patent infringement lawsuit, which was recorded as licensing net sales within Services.

[0001628280-16-020309:mdna:35]
The increase in net sales of Services during 2015 compared to 2014 was primarily due to growth from the App Store and licensing.

[0001628280-16-020309:mdna:36]
Segment Operating Performance

[0001628280-16-020309:mdna:37]
The Company manages its business primarily on a geographic basis. The Company’s reportable operating segments consist of the Americas, Europe, Greater China, Japan and Rest of Asia Pacific. The Americas segment includes both North and South America. The Europe segment includes European countries, as well as India, the Middle East and Africa. The Greater China segment includes China, Hong Kong and Taiwan. The Rest of Asia Pacific segment includes Australia and those Asian countries not included in the Company’s other reportable operating segments. Although the reportable operating segments provide similar hardware and software products and similar services, each one is managed separately to better align with the location of the Company’s customers and distribution partners and the unique market dynamics of each geographic region. Further information regarding the Company’s reportable operating segments can be found in Part II, Item 8 of this Form 10-K in the Notes to Consolidated Financial Statements in Note 11, “Segment Information and Geographic Data.”

[0001628280-16-020309:mdna:38]
Americas

[0001628280-16-020309:mdna:39]
The following table presents Americas net sales information for 2016, 2015 and 2014 (dollars in millions):

[0001628280-16-020309:mdna:40]
|  | 2016 |  | Change |  | 2015 |  | Change |  | 2014 |
| Net sales | $ | 86,613 |  |  | (8 | )% |  | $ | 93,864 |  |  | 17 | % |  | $ | 80,095 |  |
| Percentage of total net sales | 40 | % |  |  |  | 40 | % |  |  |  | 44 | % |

[0001628280-16-020309:mdna:41]
Americas net sales decreased during 2016 compared to 2015 due primarily to lower net sales and unit sales of iPhone.

[0001628280-16-020309:mdna:42]
The year-over-year growth in Americas net sales during 2015 was driven primarily by growth in net sales and unit sales of iPhone, partially offset by a decline in net sales and unit sales of iPad.

[0001628280-16-020309:mdna:43]
Europe

[0001628280-16-020309:mdna:44]
The following table presents Europe net sales information for 2016, 2015 and 2014 (dollars in millions):

[0001628280-16-020309:mdna:45]
|  | 2016 |  | Change |  | 2015 |  | Change |  | 2014 |
| Net sales | $ | 49,952 |  |  | (1 | )% |  | $ | 50,337 |  |  | 14 | % |  | $ | 44,285 |  |
| Percentage of total net sales | 23 | % |  |  |  | 22 | % |  |  |  | 24 | % |

[0001628280-16-020309:mdna:46]
Europe net sales decreased during 2016 compared to 2015 driven primarily by the effect of weakness in foreign currencies relative to the U.S. dollar and a decrease in unit sales of Mac, largely offset by an increase in iPhone unit sales and Services.

[0001628280-16-020309:mdna:47]
The year-over-year increase in Europe net sales during 2015 was driven primarily by growth in net sales and unit sales of iPhone, partially offset by the effect of weakness in foreign currencies relative to the U.S. dollar and a decline in net sales and unit sales of iPad.

[0001628280-16-020309:mdna:48]
Greater China

[0001628280-16-020309:mdna:49]
The following table presents Greater China net sales information for 2016, 2015 and 2014 (dollars in millions):

[0001628280-16-020309:mdna:50]
|  | 2016 |  | Change |  | 2015 |  | Change |  | 2014 |
| Net sales | $ | 48,492 |  |  | (17 | )% |  | $ | 58,715 |  |  | 84 | % |  | $ | 31,853 |  |
| Percentage of total net sales | 22 | % |  |  |  | 25 | % |  |  |  | 17 | % |

[0001628280-16-020309:mdna:51]
Greater China net sales decreased during 2016 compared to 2015 due primarily to lower net sales and unit sales of iPhone and the effect of weakness in foreign currencies relative to the U.S. dollar.

[0001628280-16-020309:mdna:52]
Greater China experienced strong year-over-year increases in net sales during 2015 driven primarily by iPhone sales.

[0001628280-16-020309:mdna:53]
Japan

[0001628280-16-020309:mdna:54]
The following table presents Japan net sales information for 2016, 2015 and 2014 (dollars in millions):

[0001628280-16-020309:mdna:55]
|  | 2016 |  | Change |  | 2015 |  | Change |  | 2014 |
| Net sales | $ | 16,928 |  |  | 8 | % |  | $ | 15,706 |  |  | 3 | % |  | $ | 15,314 |  |
| Percentage of total net sales | 8 | % |  |  |  | 7 | % |  |  |  | 8 | % |

[0001628280-16-020309:mdna:56]
Japan net sales increased during 2016 compared to 2015 due primarily to higher net sales of Services and the strength in the Japanese yen relative to the U.S. dollar.

[0001628280-16-020309:mdna:57]
The year-over-year increase in Japan net sales during 2015 was driven primarily by growth in Services largely associated with strong App Store sales, partially offset by the effect of weakness in the Japanese yen relative to the U.S. dollar.

[0001628280-16-020309:mdna:58]
Rest of Asia Pacific

[0001628280-16-020309:mdna:59]
The following table presents Rest of Asia Pacific net sales information for 2016, 2015 and 2014 (dollars in millions):

[0001628280-16-020309:mdna:60]
|  | 2016 |  | Change |  | 2015 |  | Change |  | 2014 |
| Net sales | $ | 13,654 |  |  | (10 | )% |  | $ | 15,093 |  |  | 34 | % |  | $ | 11,248 |  |
| Percentage of total net sales | 6 | % |  |  |  | 6 | % |  |  |  | 6 | % |

[0001628280-16-020309:mdna:61]
Rest of Asia Pacific net sales decreased during 2016 compared to 2015 due primarily to lower net sales and unit sales of iPhone and the effect of weakness in foreign currencies relative to the U.S. dollar.

[0001628280-16-020309:mdna:62]
The year-over-year increase in Rest of Asia Pacific net sales during 2015 primarily reflects strong growth in net sales and unit sales of iPhone, partially offset by the effect of weakness in foreign currencies relative to the U.S. dollar and a decline in net sales and unit sales of iPad.

[0001628280-16-020309:mdna:63]
Gross Margin

[0001628280-16-020309:mdna:64]
Gross margin for 2016, 2015 and 2014 is as follows (dollars in millions):

[0001628280-16-020309:mdna:65]
|  | 2016 |  | 2015 |  | 2014 |
| Net sales | $ | 215,639 |  |  | $ | 233,715 |  |  | $ | 182,795 |  |
| Cost of sales | 131,376 |  |  | 140,089 |  |  | 112,258 |  |
| Gross margin | $ | 84,263 |  |  | $ | 93,626 |  |  | $ | 70,537 |  |
| Gross margin percentage | 39.1 | % |  | 40.1 | % |  | 38.6 | % |

[0001628280-16-020309:mdna:66]
Gross margin decreased in 2016 compared to 2015 due primarily to the effect of weakness in most foreign currencies relative to the U.S. dollar and, to a lesser extent, unfavorable leverage on fixed costs from lower net sales, partially offset by a favorable shift in mix to Services.

[0001628280-16-020309:mdna:67]
The year-over-year increase in the gross margin percentage in 2015 was driven primarily by a favorable shift in mix to products with higher margins and, to a lesser extent, by improved leverage on fixed costs from higher net sales. These positive factors were partially offset primarily by higher product cost structures and, to a lesser extent, by the effect of weakness in most foreign currencies relative to the U.S. dollar.

[0001628280-16-020309:mdna:68]
The Company anticipates gross margin during the first quarter of 2017 to be between 38% and 38.5%. The foregoing statement regarding the Company’s expected gross margin percentage in the first quarter of 2017 is forward-looking and could differ from actual results. The Company’s future gross margins can be impacted by multiple factors including, but not limited to, those set forth in Part I, Item 1A of this Form 10-K under the heading “Risk Factors” and those described in this paragraph. In general, the Company believes gross margins will remain under downward pressure due to a variety of factors, including continued industry wide global product pricing pressures, increased competition, compressed product life cycles, product transitions, potential increases in the cost of components, and potential strengthening of the U.S. dollar, as well as potential increases in the costs of outside manufacturing services and a potential shift in the Company’s sales mix towards products with lower gross margins. In response to competitive pressures, the Company expects it will continue to take product pricing actions, which would adversely affect gross margins. Gross margins could also be affected by the Company’s ability to manage product quality and warranty costs effectively and to stimulate demand for certain of its products. Due to the Company’s significant international operations, its financial condition and operating results, including gross margins, could be significantly affected by fluctuations in exchange rates.

[0001628280-16-020309:mdna:69]
Operating Expenses

[0001628280-16-020309:mdna:70]
Operating expenses for 2016, 2015 and 2014 are as follows (dollars in millions):

[0001628280-16-020309:mdna:71]
|  | 2016 |  | Change |  | 2015 |  | Change |  | 2014 |
| Research and development | $ | 10,045 |  |  | 25 | % |  | $ | 8,067 |  |  | 34 | % |  | $ | 6,041 |  |
| Percentage of total net sales | 5 | % |  |  |  | 3 | % |  |  |  | 3 | % |
| Selling, general and administrative | $ | 14,194 |  |  | (1 | )% |  | $ | 14,329 |  |  | 19 | % |  | $ | 11,993 |  |
| Percentage of total net sales | 7 | % |  |  |  | 6 | % |  |  |  | 7 | % |
| Total operating expenses | $ | 24,239 |  |  | 8 | % |  | $ | 22,396 |  |  | 24 | % |  | $ | 18,034 |  |
| Percentage of total net sales | 11 | % |  |  |  | 10 | % |  |  |  | 10 | % |

[0001628280-16-020309:mdna:72]
Research and Development

[0001628280-16-020309:mdna:73]
The year-over-year growth in R&D expense in 2016 and 2015 was driven primarily by an increase in headcount and related expenses, and material costs to support expanded R&D activities. The Company continues to believe that focused investments in R&D are critical to its future growth and competitive position in the marketplace, and to the development of new and updated products that are central to the Company’s core business strategy.

[0001628280-16-020309:mdna:74]
Selling, General and Administrative

[0001628280-16-020309:mdna:75]
The decrease in selling, general and administrative expense in 2016 compared to 2015 was due primarily to lower discretionary expenditures and advertising costs, partially offset by an increase in headcount and related expenses. The year-over-year growth in selling, general and administrative expense in 2015 was primarily due to increased headcount and related expenses, and higher spending on marketing and advertising.

[0001628280-16-020309:mdna:76]
Other Income/(Expense), Net

[0001628280-16-020309:mdna:77]
Other income/(expense), net for 2016, 2015 and 2014 are as follows (dollars in millions):

[0001628280-16-020309:mdna:78]
|  | 2016 |  | Change |  | 2015 |  | Change |  | 2014 |
| Interest and dividend income | $ | 3,999 |  |  |  |  | $ | 2,921 |  |  |  |  | $ | 1,795 |  |
| Interest expense | (1,456 | ) |  |  |  | (733 | ) |  |  |  | (384 | ) |
| Other expense, net | (1,195 | ) |  |  |  | (903 | ) |  |  |  | (431 | ) |
| Total other income/(expense), net | $ | 1,348 |  |  | 5 | % |  | $ | 1,285 |  |  | 31 | % |  | $ | 980 |  |

[0001628280-16-020309:mdna:79]
The year-over-year increase in other income/(expense), net during 2016 and 2015 was due primarily to higher interest income, partially offset by higher interest expense on debt and higher expenses associated with foreign exchange activity. The weighted-average interest rate earned by the Company on its cash, cash equivalents and marketable securities was 1.73%, 1.49% and 1.11% in 2016, 2015 and 2014, respectively.

[0001628280-16-020309:mdna:80]
Provision for Income Taxes

[0001628280-16-020309:mdna:81]
Provision for income taxes and effective tax rates for 2016, 2015 and 2014 are as follows (dollars in millions):

[0001628280-16-020309:mdna:82]
|  | 2016 |  | 2015 |  | 2014 |
| Provision for income taxes | 15,685 |  |  | $ | 19,121 |  |  | $ | 13,973 |  |
| Effective tax rate | 25.6 | % |  | 26.4 | % |  | 26.1 | % |

[0001628280-16-020309:mdna:83]
The Company’s effective tax rates for 2016, 2015 and 2014 differ from the statutory federal income tax rate of 35% due primarily to certain undistributed foreign earnings, a substantial portion of which was generated by subsidiaries organized in Ireland, for which no U.S. taxes are provided when such earnings are intended to be indefinitely reinvested outside the U.S. The lower effective tax rate in 2016 compared to 2015 was due primarily to greater R&D tax credits. The higher effective tax rate during 2015 compared to 2014 was due primarily to higher foreign taxes.

[0001628280-16-020309:mdna:84]
As of September 24, 2016, the Company had deferred tax assets arising from deductible temporary differences, tax losses and tax credits of $4.1 billion and deferred tax liabilities of $26.0 billion. Management believes it is more likely than not that forecasted income, including income that may be generated as a result of certain tax planning strategies, together with future reversals of existing taxable temporary differences, will be sufficient to fully recover the deferred tax assets. The Company will continue to evaluate the realizability of deferred tax assets quarterly by assessing the need for and the amount of a valuation allowance.

[0001628280-16-020309:mdna:85]
During the fourth quarter of 2016, the Company reached a partial settlement with the IRS on its examination of the years 2010 through 2012. In connection with this settlement, the Company recognized a tax benefit in the fourth quarter of 2016 that was not significant to its consolidated financial statements. All years prior to 2013 are closed, except for the years 2010 through 2012 relating to R&D tax credits. In addition, the Company is subject to audits by state, local and foreign tax authorities. In major states and major foreign jurisdictions, the years subsequent to 2003 generally remain open and could be subject to examination by the taxing authorities. Management believes that adequate provisions have been made for any adjustments that may result from tax examinations. However, the outcome of tax audits cannot be predicted with certainty. If any issues addressed in the Company’s tax audits are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs.

[0001628280-16-020309:mdna:86]
On August 30, 2016, the European Commission announced its decision that Ireland granted state aid to the Company by providing tax opinions in 1991 and 2007 concerning the tax allocation of profits of the Irish branches of two subsidiaries of the Company (the "State Aid Decision"). The State Aid Decision orders Ireland to calculate and recover additional taxes from the Company for the period June 2003 through September 2014. Irish legislative changes, effective as of the beginning of 2015, eliminated the application of the tax opinions from that date forward. The Company believes the State Aid Decision to be without merit and intends to appeal to the General Court of the Court of Justice of the European Union. Ireland has also announced its intention to appeal the State Aid Decision. While the European Commission announced a recovery amount of up to €13 billion, plus interest, the actual amount of additional taxes subject to recovery is to be calculated by Ireland in accordance with the European Commission's guidance. Once the recovery amount is computed by Ireland, the Company anticipates funding it, including interest, out of foreign cash into escrow, pending conclusion of all appeals. The Company believes that any incremental Irish corporate income taxes potentially due would be creditable against U.S. taxes.

[0001628280-16-020309:mdna:87]
Recent Accounting Pronouncements

[0001628280-16-020309:mdna:88]
Income Taxes

[0001628280-16-020309:mdna:89]
In October 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-16, Income Taxes (Topic 740): Intra-Entity Transfer of Assets Other than Inventory ("ASU 2016-16"), which requires the recognition of the income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. ASU 2016-06 will be effective for the Company in its first quarter of 2019. The Company is currently evaluating the impact of adopting ASU 2016-16 on its consolidated financial statements.

[0001628280-16-020309:mdna:90]
Stock Compensation

[0001628280-16-020309:mdna:91]
In March 2016, the FASB issued ASU No. 2016-09, Compensation – Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting (“ASU 2016-09”), which simplified certain aspects of the accounting for share-based payment transactions, including income taxes, classification of awards and classification on the statement of cash flows. ASU 2016-09 will be effective for the Company beginning in its first quarter of 2018. The Company is currently evaluating the impact of adopting ASU 2016-09 on its consolidated financial statements.

[0001628280-16-020309:mdna:92]
Leases

[0001628280-16-020309:mdna:93]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842) (“ASU 2016-02”), which modified lease accounting for both lessees and lessors to increase transparency and comparability by recognizing lease assets and lease liabilities by lessees for those leases classified as operating leases under previous accounting standards and disclosing key information about leasing arrangements. ASU 2016-02 will be effective for the Company beginning in its first quarter of 2020, and early adoption is permitted. The Company is currently evaluating the timing of its adoption and the impact of adopting ASU 2016-02 on its consolidated financial statements.

[0001628280-16-020309:mdna:94]
Financial Instruments

[0001628280-16-020309:mdna:95]
In January 2016, the FASB issued ASU No. 2016-01, Financial Instruments – Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities (“ASU 2016-01”), which updates certain aspects of recognition, measurement, presentation and disclosure of financial instruments. ASU 2016-01 will be effective for the Company beginning in its first quarter of 2019. The Company does not believe the adoption of ASU 2016-01 will have a material impact on its consolidated financial statements.

[0001628280-16-020309:mdna:96]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (“ASU 2016-13”), which modifies the measurement of expected credit losses of certain financial instruments. ASU 2016-13 will be effective for the Company beginning in its first quarter of 2021 and early adoption is permitted. The Company does not believe the adoption of ASU 2016-13 will have a material impact on its consolidated financial statements.

[0001628280-16-020309:mdna:97]
Revenue Recognition

[0001628280-16-020309:mdna:98]
In May 2014, the FASB issued ASU No. 2014-09, Revenue from Contracts with Customers (Topic 606) (“ASU 2014-09”), which amends the existing accounting standards for revenue recognition. ASU 2014-09 is based on principles that govern the recognition of revenue at an amount an entity expects to be entitled when products are transferred to customers. ASU 2014-09 will be effective for the Company beginning in its first quarter of 2019, and early adoption is permitted.

[0001628280-16-020309:mdna:99]
Subsequently, the FASB has issued the following standards related to ASU 2014-09: ASU No. 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (“ASU 2016-08”); ASU No. 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing (“ASU 2016-10”); and ASU No. 2016-12, Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients (“ASU 2016-12”). The Company must adopt ASU 2016-08, ASU 2016-10 and ASU 2016-12 with ASU 2014-09 (collectively, the “new revenue standards”).

[0001628280-16-020309:mdna:100]
The new revenue standards may be applied retrospectively to each prior period presented or retrospectively with the cumulative effect recognized as of the date of adoption. The Company currently expects to adopt the new revenue standards in its first quarter of 2018 utilizing the full retrospective transition method. The Company does not expect adoption of the new revenue standards to have a material impact on its consolidated financial statements.

[0001628280-16-020309:mdna:101]
Liquidity and Capital Resources

[0001628280-16-020309:mdna:102]
The following table presents selected financial information and statistics as of and for the years ended September 24, 2016, September 26, 2015 and September 27, 2014 (in millions):

[0001628280-16-020309:mdna:103]
|  | 2016 |  | 2015 |  | 2014 |
| Cash, cash equivalents and marketable securities | $ | 237,585 |  |  | $ | 205,666 |  |  | $ | 155,239 |  |
| Property, plant and equipment, net | $ | 27,010 |  |  | $ | 22,471 |  |  | $ | 20,624 |  |
| Commercial paper | $ | 8,105 |  |  | $ | 8,499 |  |  | $ | 6,308 |  |
| Total term debt | $ | 78,927 |  |  | $ | 55,829 |  |  | $ | 28,987 |  |
| Working capital | $ | 27,863 |  |  | $ | 8,768 |  |  | $ | 5,083 |  |
| Cash generated by operating activities | $ | 65,824 |  |  | $ | 81,266 |  |  | $ | 59,713 |  |
| Cash used in investing activities | $ | (45,977 | ) |  | $ | (56,274 | ) |  | $ | (22,579 | ) |
| Cash used in financing activities | $ | (20,483 | ) |  | $ | (17,716 | ) |  | $ | (37,549 | ) |

[0001628280-16-020309:mdna:104]
The Company believes its existing balances of cash, cash equivalents and marketable securities will be sufficient to satisfy its working capital needs, capital asset purchases, outstanding commitments and other liquidity requirements associated with its existing operations over the next 12 months. The Company currently anticipates the cash used for future dividends, the share repurchase program and debt repayments will come from its current domestic cash, cash generated from on-going U.S. operating activities and from borrowings.

[0001628280-16-020309:mdna:105]
As of September 24, 2016 and September 26, 2015, the Company’s cash, cash equivalents and marketable securities held by foreign subsidiaries were $216.0 billion and $186.9 billion, respectively, and are generally based in U.S. dollar-denominated holdings. Amounts held by foreign subsidiaries are generally subject to U.S. income taxation on repatriation to the U.S. In connection with the State Aid Decision, the European Commission announced a recovery amount of up to €13 billion, plus interest. The actual amount of additional taxes subject to recovery is to be calculated by Ireland in accordance with the European Commission's guidance. Once the recovery amount is computed by Ireland, the Company anticipates funding it, including interest, out of foreign cash into escrow, pending conclusion of all appeals.

[0001628280-16-020309:mdna:106]
The Company’s marketable securities investment portfolio is invested primarily in highly-rated securities and its investment policy generally limits the amount of credit exposure to any one issuer. The policy requires investments generally to be investment grade with the objective of minimizing the potential risk of principal loss.

[0001628280-16-020309:mdna:107]
During 2016, cash generated from operating activities of $65.8 billion was a result of $45.7 billion of net income, non-cash adjustments to net income of $19.7 billion and an increase in the net change in operating assets and liabilities of $484 million. Cash used in investing activities of $46.0 billion during 2016 consisted primarily of cash used for purchases of marketable securities, net of sales and maturities, of $30.6 billion and cash used to acquire property, plant and equipment of $12.7 billion. Cash used in financing activities of $20.5 billion during 2016 consisted primarily of cash used to repurchase common stock of $29.7 billion, cash used to pay dividends and dividend equivalents of $12.2 billion and cash used to repay term debt of $2.5 billion, partially offset by net proceeds from the issuance of term debt of $25.0 billion.

[0001628280-16-020309:mdna:108]
During 2015, cash generated from operating activities of $81.3 billion was a result of $53.4 billion of net income, non-cash adjustments to net income of $16.2 billion and an increase in the net change in operating assets and liabilities of $11.6 billion. Cash used in investing activities of $56.3 billion during 2015 consisted primarily of cash used for purchases of marketable securities, net of sales and maturities, of $44.4 billion and cash used to acquire property, plant and equipment of $11.2 billion. Cash used in financing activities of $17.7 billion during 2015 consisted primarily of cash used to repurchase common stock of $35.3 billion and cash used to pay dividends and dividend equivalents of $11.6 billion, partially offset by net proceeds from the issuance of term debt of $27.1 billion.

[0001628280-16-020309:mdna:109]
Capital Assets

[0001628280-16-020309:mdna:110]
The Company’s capital expenditures were $12.8 billion during 2016. The Company anticipates utilizing approximately $16.0 billion for capital expenditures during 2017, which includes product tooling and manufacturing process equipment; data centers; corporate facilities and infrastructure, including information systems hardware, software and enhancements; and retail store facilities.

[0001628280-16-020309:mdna:111]
Debt

[0001628280-16-020309:mdna:112]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses the net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of September 24, 2016, the Company had $8.1 billion of Commercial Paper outstanding, with a weighted-average interest rate of 0.45% and maturities generally less than nine months.

[0001628280-16-020309:mdna:113]
As of September 24, 2016, the Company has outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $78.4 billion (collectively the “Notes”). During 2016, the Company repaid $2.5 billion of its Notes upon maturity. The Company has entered, and in the future may enter, into interest rate swaps to manage interest rate risk on the Notes. In addition, the Company has entered, and in the future may enter, into currency swaps to manage foreign currency risk on the Notes. The future principal payments for the Company’s Notes as of September 24, 2016 are as follows (in millions):

[0001628280-16-020309:mdna:114]
| 2017 | $ | 3,500 |  |
| 2018 | 6,500 |  |
| 2019 | 6,834 |  |
| 2020 | 6,454 |  |
| 2021 | 7,750 |  |
| Thereafter | 47,346 |  |
| Total term debt | $ | 78,384 |  |

[0001628280-16-020309:mdna:115]
Further information regarding the Company’s debt issuances and related hedging activity can be found in Part II, Item 8 of this Form 10-K in the Notes to the Consolidated Financial Statements in Note 2, “Financial Instruments” and Note 6, “Debt.”

[0001628280-16-020309:mdna:116]
Capital Return Program

[0001628280-16-020309:mdna:117]
In April 2016, the Company’s Board of Directors increased the share repurchase program authorization from $140 billion to $175 billion of the Company’s common stock, increasing the expected total size of the capital return program from $200 billion to $250 billion. Additionally in April 2016, the Company announced that the Board of Directors raised the rate of the Company's quarterly cash dividend by 10% from $0.52 to $0.57 per share, beginning with the dividend paid during the third quarter of 2016. The Company intends to increase its dividend on an annual basis subject to declaration by the Board of Directors.

[0001628280-16-020309:mdna:118]
As of September 24, 2016, $133 billion of the share repurchase program has been utilized. The Company’s share repurchase program does not obligate it to acquire any specific number of shares. Under the program, shares may be repurchased in privately negotiated or open market transactions, including under plans complying with Rule 10b5-1 under the Exchange Act.

[0001628280-16-020309:mdna:119]
The following table presents the Company’s dividends, dividend equivalents, share repurchases and net share settlement activity from the start of the capital return program in August 2012 through September 24, 2016 (in millions):

[0001628280-16-020309:mdna:120]
|  | Dividends andDividend Equivalents Paid |  | Accelerated ShareRepurchases |  | Open MarketShare Repurchases |  | Taxes Related to Settlement of Equity Awards |  | Total |
| 2016 | $ | 12,150 |  |  | $ | 12,000 |  |  | $ | 17,000 |  |  | $ | 1,570 |  |  | $ | 42,720 |  |
| 2015 | 11,561 |  |  | 6,000 |  |  | 30,026 |  |  | 1,499 |  |  | 49,086 |  |
| 2014 | 11,126 |  |  | 21,000 |  |  | 24,000 |  |  | 1,158 |  |  | 57,284 |  |
| 2013 | 10,564 |  |  | 13,950 |  |  | 9,000 |  |  | 1,082 |  |  | 34,596 |  |
| 2012 | 2,488 |  |  | — |  |  | — |  |  | 56 |  |  | 2,544 |  |
| Total | $ | 47,889 |  |  | $ | 52,950 |  |  | $ | 80,026 |  |  | $ | 5,365 |  |  | $ | 186,230 |  |

[0001628280-16-020309:mdna:121]
The Company expects to execute its capital return program by the end of March 2018 by paying dividends and dividend equivalents, repurchasing shares and remitting withheld taxes related to net share settlement of restricted stock units. The Company plans to continue to access the domestic and international debt markets to assist in funding its capital return program.

[0001628280-16-020309:mdna:122]
Off-Balance Sheet Arrangements and Contractual Obligations

[0001628280-16-020309:mdna:123]
The Company has not entered into any transactions with unconsolidated entities whereby the Company has financial guarantees, subordinated retained interests, derivative instruments, or other contingent arrangements that expose the Company to material continuing risks, contingent liabilities, or any other obligation under a variable interest in an unconsolidated entity that provides financing, liquidity, market risk, or credit risk support to the Company, or engages in leasing, hedging, or R&D services with the Company.

[0001628280-16-020309:mdna:124]
The following table presents certain payments due by the Company under contractual obligations with minimum firm commitments as of September 24, 2016, and excludes amounts already recorded on the Consolidated Balance Sheet, except for term debt (in millions):

[0001628280-16-020309:mdna:125]
|  | Payments Due in Less Than 1 Year |  | Payments Due in 1-3 Years |  | Payments Due in 4-5 Years |  | Payments Due in More Than 5 Years |  | Total |
| Term debt | $ | 3,500 |  |  | $ | 13,334 |  |  | $ | 14,204 |  |  | $ | 47,346 |  |  | $ | 78,384 |  |
| Operating leases | 929 |  |  | 1,834 |  |  | 1,725 |  |  | 3,139 |  |  | 7,627 |  |
| Manufacturing purchase obligations | 24,695 |  |  | 939 |  |  | 1,830 |  |  | 1,127 |  |  | 28,591 |  |
| Other purchase obligations | 3,503 |  |  | 1,732 |  |  | 653 |  |  | 732 |  |  | 6,620 |  |
| Total | $ | 32,627 |  |  | $ | 17,839 |  |  | $ | 18,412 |  |  | $ | 52,344 |  |  | $ | 121,222 |  |

[0001628280-16-020309:mdna:126]
Operating Leases

[0001628280-16-020309:mdna:127]
As of September 24, 2016, the Company’s total future minimum lease payments under noncancelable operating leases were $7.6 billion. The Company’s retail store and other facility leases are typically for terms not exceeding 10 years and generally contain multi-year renewal options.

[0001628280-16-020309:mdna:128]
Manufacturing Purchase Obligations

[0001628280-16-020309:mdna:129]
The Company utilizes several outsourcing partners to manufacture sub-assemblies for the Company’s products and to perform final assembly and testing of finished products. These outsourcing partners acquire components and build product based on demand information supplied by the Company, which typically covers periods up to 150 days. The Company also obtains individual components for its products from a wide variety of individual suppliers. Consistent with industry practice, the Company acquires components through a combination of purchase orders, supplier contracts, and open orders based on projected demand information. As of September 24, 2016, the Company had manufacturing purchase obligations of $28.6 billion.

[0001628280-16-020309:mdna:130]
Other Purchase Obligations

[0001628280-16-020309:mdna:131]
The Company’s other purchase obligations were comprised of commitments to acquire capital assets, including product tooling and manufacturing process equipment, and commitments related to advertising, licensing, R&D, internet and telecommunications services, energy and other obligations.  As of September 24, 2016, the Company had other purchase obligations of $6.6 billion.

[0001628280-16-020309:mdna:132]
The Company’s other non-current liabilities in the Consolidated Balance Sheets consist primarily of deferred tax liabilities, gross unrecognized tax benefits and the related gross interest and penalties. As of September 24, 2016, the Company had non-current deferred tax liabilities of $26.0 billion. Additionally, as of September 24, 2016, the Company had gross unrecognized tax benefits of $7.7 billion and an additional $1.0 billion for gross interest and penalties classified as non-current liabilities. At this time, the Company is unable to make a reasonably reliable estimate of the timing of payments due to uncertainties in the timing of tax audit outcomes; therefore, such amounts are not included in the above contractual obligation table.

[0001628280-16-020309:mdna:133]
Indemnification

[0001628280-16-020309:mdna:134]
The Company generally does not indemnify end-users of its operating system and application software against legal claims that the software infringes third-party intellectual property rights. Other agreements entered into by the Company sometimes include indemnification provisions under which the Company could be subject to costs and/or damages in the event of an infringement claim against the Company or an indemnified third-party. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss with respect to indemnification of end-users of its operating system or application software for infringement of third-party intellectual property rights.

[0001628280-16-020309:mdna:135]
The Company offers an iPhone Upgrade Program, which is available to customers who purchase a qualifying iPhone in the U.S., the U.K. and mainland China. The iPhone Upgrade Program provides customers the right to trade in that iPhone for a specified amount when purchasing a new iPhone, provided certain conditions are met. The Company accounts for the trade-in right as a guarantee liability and recognizes arrangement revenue net of the fair value of such right with subsequent changes to the guarantee liability recognized within revenue.

[0001628280-16-020309:mdna:136]
The Company has entered into indemnification agreements with its directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, the Company maintains directors and officers liability insurance coverage to reduce its exposure to such obligations.

[0001628280-16-020309:mdna:137]
Critical Accounting Policies and Estimates

[0001628280-16-020309:mdna:138]
The preparation of financial statements and related disclosures in conformity with U.S. generally accepted accounting principles (“GAAP”) and the Company’s discussion and analysis of its financial condition and operating results require the Company’s management to make judgments, assumptions and estimates that affect the amounts reported in its consolidated financial statements and accompanying notes. Note 1, “Summary of Significant Accounting Policies,” of the Notes to Consolidated Financial Statements in Part II, Item 8 of this Form 10-K describes the significant accounting policies and methods used in the preparation of the Company’s consolidated financial statements. Management bases its estimates on historical experience and on various other assumptions it believes to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities. Actual results may differ from these estimates, and such differences may be material.

[0001628280-16-020309:mdna:139]
Management believes the Company’s critical accounting policies and estimates are those related to revenue recognition, valuation and impairment of marketable securities, inventory valuation, valuation of manufacturing-related assets and estimation of purchase commitment cancellation fees, warranty costs, income taxes, and legal and other contingencies. Management considers these policies critical because they are both important to the portrayal of the Company’s financial condition and operating results, and they require management to make judgments and estimates about inherently uncertain matters. The Company’s senior management has reviewed these critical accounting policies and related disclosures with the Audit and Finance Committee of the Company’s Board of Directors.

[0001628280-16-020309:mdna:140]
Revenue Recognition

[0001628280-16-020309:mdna:141]
Net sales consist primarily of revenue from the sale of hardware, software, digital content and applications, accessories, and service and support contracts. The Company recognizes revenue when persuasive evidence of an arrangement exists, delivery has occurred, the sales price is fixed or determinable and collection is probable. Product is considered delivered to the customer once it has been shipped and title, risk of loss and rewards of ownership have been transferred. For most of the Company’s product sales, these criteria are met at the time the product is shipped. For online sales to individuals, for some sales to education customers in the U.S., and for certain other sales, the Company defers revenue until the customer receives the product because the Company retains a portion of the risk of loss on these sales during transit. For payment terms in excess of the Company’s standard payment terms, revenue is recognized as payments become due unless the Company has positive evidence that the sales price is fixed or determinable, such as a successful history of collection, without concession, on comparable arrangements. The Company recognizes revenue from the sale of hardware products, software bundled with hardware that is essential to the functionality of the hardware and third-party digital content sold on the iTunes Store in accordance with general revenue recognition accounting guidance. The Company recognizes revenue in accordance with industry-specific software accounting guidance for the following types of sales transactions: (i) standalone sales of software products, (ii) sales of software upgrades and (iii) sales of software bundled with hardware not essential to the functionality of the hardware.

[0001628280-16-020309:mdna:142]
For multi-element arrangements that include hardware products containing software essential to the hardware product’s functionality, undelivered software elements that relate to the hardware product’s essential software and/or undelivered non-software services, the Company allocates revenue to all deliverables based on their relative selling prices. In such circumstances, the Company uses a hierarchy to determine the selling price to be used for allocating revenue to deliverables: (i) vendor-specific objective evidence of fair value (“VSOE”), (ii) third-party evidence of selling price (“TPE”) and (iii) best estimate of selling price (“ESP”). VSOE generally exists only when the Company sells the deliverable separately and is the price actually charged by the Company for that deliverable. ESPs reflect the Company’s best estimates of what the selling prices of elements would be if they were sold regularly on a stand-alone basis.

[0001628280-16-020309:mdna:143]
For sales of qualifying versions of iOS devices, Mac, Apple Watch and Apple TV, the Company has indicated it may from time to time provide future unspecified software upgrades to the device’s essential software and/or non-software services free of charge. Because the Company has neither VSOE nor TPE for the unspecified software upgrade rights or the non-software services, revenue is allocated to these rights and services based on the Company’s ESPs. Revenue allocated to the unspecified software upgrade rights and non-software services based on the Company’s ESPs is deferred and recognized on a straight-line basis over the estimated period the software upgrades and non-software services are expected to be provided.

[0001628280-16-020309:mdna:144]
The Company’s process for determining ESPs involves management’s judgment and considers multiple factors that may vary over time depending upon the unique facts and circumstances related to each deliverable. Should future facts and circumstances change, the Company’s ESPs and the future rate of related amortization for unspecified software upgrades and non-software services related to future sales of these devices could change. Factors subject to change include the unspecified software upgrade rights and non-software services offered, the estimated value of unspecified software upgrade rights and non-software services and the estimated period unspecified software upgrades and non-software services are expected to be provided.

[0001628280-16-020309:mdna:145]
The Company records reductions to revenue for estimated commitments related to price protection and other customer incentive programs. For transactions involving price protection, the Company recognizes revenue net of the estimated amount to be refunded, provided the refund amount can be reasonably and reliably estimated and the other conditions for revenue recognition have been met. The Company’s policy requires that, if refunds cannot be reliably estimated, revenue is not recognized until reliable estimates can be made or the price protection lapses. For the Company’s other customer incentive programs, the estimated cost is recognized at the later of the date at which the Company has sold the product or the date at which the program is offered. The Company also records reductions to revenue for expected future product returns based on the Company’s historical experience. Future market conditions and product transitions may require the Company to increase customer incentive programs that could result in reductions to future revenue. Additionally, certain customer incentive programs require management to estimate the number of customers who will actually redeem the incentive. Management’s estimates are based on historical experience and the specific terms and conditions of particular incentive programs. If a greater than estimated proportion of customers redeems such incentives, the Company would be required to record additional reductions to revenue, which would have an adverse impact on the Company’s operating results.

[0001628280-16-020309:mdna:146]
Valuation and Impairment of Marketable Securities

[0001628280-16-020309:mdna:147]
The Company’s investments in available-for-sale securities are reported at fair value. Unrealized gains and losses related to changes in the fair value of securities are recognized in accumulated other comprehensive income, net of tax, in the Company’s Consolidated Balance Sheets. Changes in the fair value of available-for-sale securities impact the Company’s net income only when such securities are sold or an other-than-temporary impairment is recognized. Realized gains and losses on the sale of securities are determined by specific identification of each security’s cost basis. The Company regularly reviews its investment portfolio to determine if any security is other-than-temporarily impaired, which would require the Company to record an impairment charge in the period any such determination is made. In making this determination, the Company evaluates, among other things, the duration and extent to which the fair value of a security is less than its cost; the financial condition of the issuer and any changes thereto; and the Company’s intent to sell, or whether it will more likely than not be required to sell, the security before recovery of its amortized cost basis. The Company’s assessment of whether a security is other-than-temporarily impaired could change in the future due to new developments or changes in assumptions related to any particular security, which would have an adverse impact on the Company’s operating results.

[0001628280-16-020309:mdna:148]
Inventory Valuation, Valuation of Manufacturing-Related Assets and Estimation of Purchase Commitment Cancellation Fees

[0001628280-16-020309:mdna:149]
The Company must purchase components and build inventory in advance of product shipments and has invested in manufacturing-related assets, including capital assets held at its suppliers’ facilities. In addition, the Company has made prepayments to certain of its suppliers associated with long-term supply agreements to secure supply of inventory components. The Company records a write-down for inventories of components and products, including third-party products held for resale, which have become obsolete or are in excess of anticipated demand or net realizable value. The Company performs a detailed review of inventory that considers multiple factors including demand forecasts, product life cycle status, product development plans, current sales levels and component cost trends. The Company also reviews its manufacturing-related capital assets and inventory prepayments for impairment whenever events or circumstances indicate the carrying amount of such assets may not be recoverable. If the Company determines that an asset is not recoverable, it records an impairment loss equal to the amount by which the carrying value of such an asset exceeds its fair value.

[0001628280-16-020309:mdna:150]
The industries in which the Company competes are subject to a rapid and unpredictable pace of product and component obsolescence and demand changes. In certain circumstances the Company may be required to record additional write-downs of inventory and/or impairments of manufacturing-related assets or inventory prepayments. These circumstances include future demand or market conditions for the Company’s products being less favorable than forecasted, unforeseen technological changes or changes to the Company’s product development plans that negatively impact the utility of any of these assets, or significant deterioration in the financial condition of one or more of the Company’s suppliers that hold any of the Company’s manufacturing-related assets or to whom the Company has made an inventory prepayment. Such write-downs would adversely affect the Company’s financial condition and operating results in the period when the additional write-downs were recorded.

[0001628280-16-020309:mdna:151]
The Company accrues for estimated purchase commitment cancellation fees related to inventory orders that have been cancelled or are expected to be cancelled. Consistent with industry practice, the Company acquires components through a combination of purchase orders, supplier contracts, and open orders in each case based on projected demand. Manufacturing purchase obligations typically cover the Company’s forecasted component and manufacturing requirements for periods up to 150 days. If there is an abrupt and substantial decline in demand for one or more of the Company’s products, a change in the Company’s product development plans, or an unanticipated change in technological requirements for any of the Company’s products, the Company may be required to record additional accruals for cancellation fees that would adversely affect its results of operations in the period when the cancellation fees were identified and recorded.

[0001628280-16-020309:mdna:152]
Warranty Costs

[0001628280-16-020309:mdna:153]
The Company accrues for the estimated cost of warranties in the period the related revenue is recognized based on historical and projected warranty claim rates, historical and projected cost-per-claim and knowledge of specific product failures that are outside of the Company’s typical experience. The Company regularly reviews these estimates and the current installed base of products subject to warranty protection to assess the appropriateness of its recorded warranty liabilities and adjusts the amounts as necessary. If actual product failure rates or repair costs differ from estimates, revisions to the estimated warranty liabilities would be required and could materially affect the Company’s financial condition and operating results.

[0001628280-16-020309:mdna:154]
Income Taxes

[0001628280-16-020309:mdna:155]
The Company records a tax provision for the anticipated tax consequences of its reported operating results. The provision for income taxes is computed using the asset and liability method, under which deferred tax assets and liabilities are recognized for the expected future tax consequences of temporary differences between the financial reporting and tax bases of assets and liabilities, and for operating losses and tax credit carryforwards. Deferred tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets and liabilities are expected to be realized or settled. The Company records a valuation allowance to reduce deferred tax assets to the amount that is believed more likely than not to be realized.

[0001628280-16-020309:mdna:156]
The Company recognizes tax benefits from uncertain tax positions only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement.

[0001628280-16-020309:mdna:157]
Management believes it is more likely than not that forecasted income, including income that may be generated as a result of certain tax planning strategies, together with future reversals of existing taxable temporary differences, will be sufficient to fully recover the deferred tax assets. In the event that the Company determines all or part of the net deferred tax assets are not realizable in the future, the Company will record an adjustment to the valuation allowance that would be charged to earnings in the period such determination is made. In addition, the calculation of tax liabilities involves significant judgment in estimating the impact of uncertainties in the application of GAAP and complex tax laws. Resolution of these uncertainties in a manner inconsistent with management’s expectations could have a material impact on the Company’s financial condition and operating results.

[0001628280-16-020309:mdna:158]
Legal and Other Contingencies

[0001628280-16-020309:mdna:159]
As discussed in Part I, Item 3 of this Form 10-K under the heading “Legal Proceedings” and in Part II, Item 8 of this Form 10-K in the Notes to Consolidated Financial Statements in Note 10, “Commitments and Contingencies,” the Company is subject to various legal proceedings and claims that arise in the ordinary course of business. The Company records a liability when it is probable that a loss has been incurred and the amount is reasonably estimable, the determination of which requires significant judgment. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to loss contingencies for asserted legal and other claims. However, the outcome of legal proceedings and claims brought against the Company is subject to significant uncertainty. Therefore, although management considers the likelihood of such an outcome to be remote, if one or more of these legal matters were resolved against the Company in a reporting period for amounts in excess of management’s expectations, the Company’s consolidated financial statements for that reporting period could be materially adversely affected.
