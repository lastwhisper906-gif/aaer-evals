# AAPL notes — 0001628280-16-020309


## aapl:CommercialPaperCashFlowSummaryTableTextBlock

[0001628280-16-020309:notes:1]
The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for 2016 and 2015 (in millions):

[0001628280-16-020309:notes:2]
|  | 2016 |  | 2015 |
| Maturities less than 90 days: |  |  |  |
| Proceeds from (repayments of) commercial paper, net | $ | (869 | ) |  | $ | 5,293 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 3,632 |  |  | 3,851 |  |
| Repayments of commercial paper | (3,160 | ) |  | (6,953 | ) |
| Maturities greater than 90 days, net | 472 |  |  | (3,102 | ) |
| Total change in commercial paper, net | $ | (397 | ) |  | $ | 2,191 |  |


## aapl:NotionalAndCreditRiskAmountsOfOutstandingDerivativePositionsDisclosureTextBlock

[0001628280-16-020309:notes:3]
The following table shows the notional amounts of the Company’s outstanding derivative instruments and credit risk amounts associated with outstanding or unsettled derivative instruments as of September 24, 2016 and September 26, 2015 (in millions):

[0001628280-16-020309:notes:4]
|  | 2016 |  | 2015 |
|  | NotionalAmount |  | Credit RiskAmount |  | NotionalAmount |  | Credit RiskAmount |
| Instruments designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 44,678 |  |  | $ | 518 |  |  | $ | 70,054 |  |  | $ | 1,385 |  |
| Interest rate contracts | $ | 24,500 |  |  | $ | 728 |  |  | $ | 18,750 |  |  | $ | 394 |  |
| Instruments not designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 54,305 |  |  | $ | 153 |  |  | $ | 49,190 |  |  | $ | 109 |  |


## aapl:ScheduleOfCommonStockRepurchasedTableTextBlock

[0001628280-16-020309:notes:5]
Additionally, the Company repurchased shares of its common stock in the open market, which were retired upon repurchase, during the periods presented as follows:

[0001628280-16-020309:notes:6]
|  | Number of Shares(in thousands) |  | Average RepurchasePrice Per Share |  | Amount(in millions) |
| 2016: |  |  |  |  |  |
| Fourth quarter | 28,579 |  |  | $ | 104.97 |  |  | $ | 3,000 |  |
| Third quarter | 41,238 |  |  | $ | 97.00 |  |  | 4,000 |  |
| Second quarter | 71,766 |  |  | $ | 97.54 |  |  | 7,000 |  |
| First quarter | 25,984 |  |  | $ | 115.45 |  |  | 3,000 |  |
| Total open market common stock repurchases | 167,567 |  |  |  |  | $ | 17,000 |  |
| 2015: |  |  |  |  |  |
| Fourth quarter | 121,802 |  |  | $ | 115.15 |  |  | $ | 14,026 |  |
| Third quarter | 31,231 |  |  | $ | 128.08 |  |  | 4,000 |  |
| Second quarter | 56,400 |  |  | $ | 124.11 |  |  | 7,000 |  |
| First quarter | 45,704 |  |  | $ | 109.40 |  |  | 5,000 |  |
| Total open market common stock repurchases | 255,137 |  |  |  |  | $ | 30,026 |  |


## us-gaap:AcceleratedShareRepurchasesTextBlock

[0001628280-16-020309:notes:7]
The following table shows the Company’s ASR activity and related information during the years ended September 24, 2016 and September 26, 2015:

[0001628280-16-020309:notes:8]
|  | Purchase Period End Date |  | Number ofShares(in thousands) |  | AverageRepurchasePrice Per Share |  | ASRAmount (in millions) |
| August 2016 ASR | November 2016 |  | 22,468 |  | (1) | (1) |  |  | $ | 3,000 |  |
| May 2016 ASR | August 2016 |  | 60,452 |  | (2) | $ | 99.25 |  |  | $ | 6,000 |  |
| November 2015 ASR | April 2016 |  | 29,122 |  |  | $ | 103.02 |  |  | $ | 3,000 |  |
| May 2015 ASR | July 2015 |  | 48,293 |  |  | $ | 124.24 |  |  | $ | 6,000 |  |
| August 2014 ASR | February 2015 |  | 81,525 |  |  | $ | 110.40 |  |  | $ | 9,000 |  |
| January 2014 ASR | December 2014 |  | 134,247 |  |  | $ | 89.39 |  |  | $ | 12,000 |  |

[0001628280-16-020309:notes:9]
| (1) | “Number of Shares” represents those shares delivered in the beginning of the purchase period and does not represent the final number of shares to be delivered under the ASR. The total number of shares ultimately delivered, and therefore the average repurchase price paid per share, will be determined at the end of the purchase period based on the volume-weighted average price of the Company’s common stock during that period. The August 2016 ASR purchase period will end in or before November 2016. |

[0001628280-16-020309:notes:10]
| (2) | Includes 48.2 million shares delivered and retired at the beginning of the purchase period, which began in the third quarter of 2016, and 12.3 million shares delivered and retired at the end of the purchase period, which concluded in the fourth quarter of 2016. |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001628280-16-020309:notes:11]
Consolidated Financial Statement Details

[0001628280-16-020309:notes:12]
The following tables show the Company’s consolidated financial statement details as of September 24, 2016 and September 26, 2015 (in millions):

[0001628280-16-020309:notes:13]
Property, Plant and Equipment, Net

[0001628280-16-020309:notes:14]
|  | 2016 |  | 2015 |
| Land and buildings | $ | 10,185 |  |  | $ | 6,956 |  |
| Machinery, equipment and internal-use software | 44,543 |  |  | 37,038 |  |
| Leasehold improvements | 6,517 |  |  | 5,263 |  |
| Gross property, plant and equipment | 61,245 |  |  | 49,257 |  |
| Accumulated depreciation and amortization | (34,235 | ) |  | (26,786 | ) |
| Total property, plant and equipment, net | $ | 27,010 |  |  | $ | 22,471 |  |

[0001628280-16-020309:notes:15]
Other Non-Current Liabilities

[0001628280-16-020309:notes:16]
|  | 2016 |  | 2015 |
| Deferred tax liabilities | $ | 26,019 |  |  | $ | 24,062 |  |
| Other non-current liabilities | 10,055 |  |  | 9,365 |  |
| Total other non-current liabilities | $ | 36,074 |  |  | $ | 33,427 |  |

[0001628280-16-020309:notes:17]
Other Income/(Expense), Net

[0001628280-16-020309:notes:18]
The following table shows the detail of other income/(expense), net for 2016, 2015 and 2014 (in millions):

[0001628280-16-020309:notes:19]
|  |  | 2016 |  | 2015 |  | 2014 |
| Interest and dividend income |  | $ | 3,999 |  |  | $ | 2,921 |  |  | $ | 1,795 |  |
| Interest expense |  | (1,456 | ) |  | (733 | ) |  | (384 | ) |
| Other expense, net |  | (1,195 | ) |  | (903 | ) |  | (431 | ) |
| Total other income/(expense), net |  | $ | 1,348 |  |  | $ | 1,285 |  |  | $ | 980 |  |


## us-gaap:AdvertisingCostsPolicyTextBlock

[0001628280-16-020309:notes:20]
Advertising Costs

[0001628280-16-020309:notes:21]
Advertising costs are expensed as incurred and included in selling, general and administrative expenses.


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001628280-16-020309:notes:22]
The following tables show the Company’s cash and available-for-sale securities’ adjusted cost, gross unrealized gains, gross unrealized losses and fair value by significant investment category recorded as cash and cash equivalents or short- or long-term marketable securities as of September 24, 2016 and September 26, 2015 (in millions):

[0001628280-16-020309:notes:23]
|  | 2016 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | Short-TermMarketableSecurities |  | Long-TermMarketableSecurities |
| Cash | $ | 8,601 |  |  | $ | — |  |  | $ | — |  |  | $ | 8,601 |  |  | $ | 8,601 |  |  | $ | — |  |  | $ | — |  |
| Level 1: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 3,666 |  |  | — |  |  | — |  |  | 3,666 |  |  | 3,666 |  |  | — |  |  | — |  |
| Mutual funds | 1,407 |  |  | — |  |  | (146 | ) |  | 1,261 |  |  | — |  |  | 1,261 |  |  | — |  |
| Subtotal | 5,073 |  |  | — |  |  | (146 | ) |  | 4,927 |  |  | 3,666 |  |  | 1,261 |  |  | — |  |
| Level 2: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 41,697 |  |  | 319 |  |  | (4 | ) |  | 42,012 |  |  | 1,527 |  |  | 13,492 |  |  | 26,993 |  |
| U.S. agency securities | 7,543 |  |  | 16 |  |  | — |  |  | 7,559 |  |  | 2,762 |  |  | 2,441 |  |  | 2,356 |  |
| Non-U.S. government securities | 7,609 |  |  | 259 |  |  | (27 | ) |  | 7,841 |  |  | 110 |  |  | 818 |  |  | 6,913 |  |
| Certificates of deposit and time deposits | 6,598 |  |  | — |  |  | — |  |  | 6,598 |  |  | 1,108 |  |  | 3,897 |  |  | 1,593 |  |
| Commercial paper | 7,433 |  |  | — |  |  | — |  |  | 7,433 |  |  | 2,468 |  |  | 4,965 |  |  | — |  |
| Corporate securities | 131,166 |  |  | 1,409 |  |  | (206 | ) |  | 132,369 |  |  | 242 |  |  | 19,599 |  |  | 112,528 |  |
| Municipal securities | 956 |  |  | 5 |  |  | — |  |  | 961 |  |  | — |  |  | 167 |  |  | 794 |  |
| Mortgage- and asset-backed securities | 19,134 |  |  | 178 |  |  | (28 | ) |  | 19,284 |  |  | — |  |  | 31 |  |  | 19,253 |  |
| Subtotal | 222,136 |  |  | 2,186 |  |  | (265 | ) |  | 224,057 |  |  | 8,217 |  |  | 45,410 |  |  | 170,430 |  |
| Total | $ | 235,810 |  |  | $ | 2,186 |  |  | $ | (411 | ) |  | $ | 237,585 |  |  | $ | 20,484 |  |  | $ | 46,671 |  |  | $ | 170,430 |  |

[0001628280-16-020309:notes:24]
|  | 2015 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | Short-TermMarketableSecurities |  | Long-TermMarketableSecurities |
| Cash | $ | 11,389 |  |  | $ | — |  |  | $ | — |  |  | $ | 11,389 |  |  | $ | 11,389 |  |  | $ | — |  |  | $ | — |  |
| Level 1: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 1,798 |  |  | — |  |  | — |  |  | 1,798 |  |  | 1,798 |  |  | — |  |  | — |  |
| Mutual funds | 1,772 |  |  | — |  |  | (144 | ) |  | 1,628 |  |  | — |  |  | 1,628 |  |  | — |  |
| Subtotal | 3,570 |  |  | — |  |  | (144 | ) |  | 3,426 |  |  | 1,798 |  |  | 1,628 |  |  | — |  |
| Level 2: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 34,902 |  |  | 181 |  |  | (1 | ) |  | 35,082 |  |  | — |  |  | 3,498 |  |  | 31,584 |  |
| U.S. agency securities | 5,864 |  |  | 14 |  |  | — |  |  | 5,878 |  |  | 841 |  |  | 767 |  |  | 4,270 |  |
| Non-U.S. government securities | 6,356 |  |  | 45 |  |  | (167 | ) |  | 6,234 |  |  | 43 |  |  | 135 |  |  | 6,056 |  |
| Certificates of deposit and time deposits | 4,347 |  |  | — |  |  | — |  |  | 4,347 |  |  | 2,065 |  |  | 1,405 |  |  | 877 |  |
| Commercial paper | 6,016 |  |  | — |  |  | — |  |  | 6,016 |  |  | 4,981 |  |  | 1,035 |  |  | — |  |
| Corporate securities | 116,908 |  |  | 242 |  |  | (985 | ) |  | 116,165 |  |  | 3 |  |  | 11,948 |  |  | 104,214 |  |
| Municipal securities | 947 |  |  | 5 |  |  | — |  |  | 952 |  |  | — |  |  | 48 |  |  | 904 |  |
| Mortgage- and asset-backed securities | 16,121 |  |  | 87 |  |  | (31 | ) |  | 16,177 |  |  | — |  |  | 17 |  |  | 16,160 |  |
| Subtotal | 191,461 |  |  | 574 |  |  | (1,184 | ) |  | 190,851 |  |  | 7,933 |  |  | 18,853 |  |  | 164,065 |  |
| Total | $ | 206,420 |  |  | $ | 574 |  |  | $ | (1,328 | ) |  | $ | 205,666 |  |  | $ | 21,120 |  |  | $ | 20,481 |  |  | $ | 164,065 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001628280-16-020309:notes:25]
Basis of Presentation and Preparation

[0001628280-16-020309:notes:26]
The accompanying consolidated financial statements include the accounts of the Company. Intercompany accounts and transactions have been eliminated. In the opinion of the Company’s management, the consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these consolidated financial statements in conformity with U.S. generally accepted accounting principles (“GAAP”) requires management to make estimates and assumptions that affect the amounts reported in these consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. Certain prior period amounts in the consolidated financial statements have been reclassified to conform to the current period’s presentation.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001628280-16-020309:notes:27]
Summary of Significant Accounting Policies

[0001628280-16-020309:notes:28]
Apple Inc. and its wholly-owned subsidiaries (collectively “Apple” or the “Company”) designs, manufactures and markets mobile communication and media devices, personal computers and portable digital music players, and sells a variety of related software, services, accessories, networking solutions and third-party digital content and applications. The Company sells its products worldwide through its retail stores, online stores and direct sales force, as well as through third-party cellular network carriers, wholesalers, retailers and value-added resellers. In addition, the Company sells a variety of third-party Apple-compatible products, including application software and various accessories through its retail and online stores. The Company sells to consumers, small and mid-sized businesses and education, enterprise and government customers.

[0001628280-16-020309:notes:29]
The Company’s fiscal year is the 52 or 53-week period that ends on the last Saturday of September. The Company’s fiscal years 2016, 2015 and 2014 ended on September 24, 2016, September 26, 2015 and September 27, 2014, respectively, and each spanned 52 weeks. An additional week is included in the first fiscal quarter approximately every five or six years to realign fiscal quarters with calendar quarters, which will next occur in the first quarter of the Company's fiscal year ending September 30, 2017. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in September and the associated quarters, months and periods of those fiscal years.

[0001628280-16-020309:notes:30]
During 2016, the Company adopted an accounting standard that simplified the presentation of deferred income taxes by requiring deferred tax assets and liabilities be classified as noncurrent in a classified statement of financial position. The Company has adopted this accounting standard prospectively; accordingly, the prior period amounts in the Company’s Consolidated Balance Sheets within this Annual Report on Form 10-K were not adjusted to conform to the new accounting standard. The adoption of this accounting standard was not material to the Company’s consolidated financial statements.

[0001628280-16-020309:notes:31]
Revenue Recognition

[0001628280-16-020309:notes:32]
Net sales consist primarily of revenue from the sale of hardware, software, digital content and applications, accessories, and service and support contracts. The Company recognizes revenue when persuasive evidence of an arrangement exists, delivery has occurred, the sales price is fixed or determinable and collection is probable. Product is considered delivered to the customer once it has been shipped and title, risk of loss and rewards of ownership have been transferred. For most of the Company’s product sales, these criteria are met at the time the product is shipped. For online sales to individuals, for some sales to education customers in the U.S., and for certain other sales, the Company defers revenue until the customer receives the product because the Company retains a portion of the risk of loss on these sales during transit. For payment terms in excess of the Company’s standard payment terms, revenue is recognized as payments become due unless the Company has positive evidence that the sales price is fixed or determinable, such as a successful history of collection, without concession, on comparable arrangements. The Company recognizes revenue from the sale of hardware products, software bundled with hardware that is essential to the functionality of the hardware and third-party digital content sold on the iTunes Store in accordance with general revenue recognition accounting guidance. The Company recognizes revenue in accordance with industry specific software accounting guidance for the following types of sales transactions: (i) standalone sales of software products, (ii) sales of software upgrades and (iii) sales of software bundled with hardware not essential to the functionality of the hardware.

[0001628280-16-020309:notes:33]
For the sale of most third-party products, the Company recognizes revenue based on the gross amount billed to customers because the Company establishes its own pricing for such products, retains related inventory risk for physical products, is the primary obligor to the customer and assumes the credit risk for amounts billed to its customers. For third-party applications sold through the App Store and Mac App Store and certain digital content sold through the iTunes Store, the Company does not determine the selling price of the products and is not the primary obligor to the customer. Therefore, the Company accounts for such sales on a net basis by recognizing in net sales only the commission it retains from each sale. The portion of the gross amount billed to customers that is remitted by the Company to third-party app developers and certain digital content owners is not reflected in the Company’s Consolidated Statements of Operations.

[0001628280-16-020309:notes:34]
The Company records deferred revenue when it receives payments in advance of the delivery of products or the performance of services. This includes amounts that have been deferred for unspecified and specified software upgrade rights and non-software services that are attached to hardware and software products. The Company sells gift cards redeemable at its retail and online stores, and also sells gift cards redeemable on iTunes Store, App Store, Mac App Store, TV App Store and iBooks Store for the purchase of digital content and software. The Company records deferred revenue upon the sale of the card, which is relieved upon redemption of the card by the customer. Revenue from AppleCare service and support contracts is deferred and recognized over the service coverage periods. AppleCare service and support contracts typically include extended phone support, repair services, web-based support resources and diagnostic tools offered under the Company’s standard limited warranty.

[0001628280-16-020309:notes:35]
The Company records reductions to revenue for estimated commitments related to price protection and other customer incentive programs. For transactions involving price protection, the Company recognizes revenue net of the estimated amount to be refunded. For the Company’s other customer incentive programs, the estimated cost of these programs is recognized at the later of the date at which the Company has sold the product or the date at which the program is offered. The Company also records reductions to revenue for expected future product returns based on the Company’s historical experience. Revenue is recorded net of taxes collected from customers that are remitted to governmental authorities, with the collected taxes recorded as current liabilities until remitted to the relevant government authority.

[0001628280-16-020309:notes:36]
Revenue Recognition for Arrangements with Multiple Deliverables

[0001628280-16-020309:notes:37]
For multi-element arrangements that include hardware products containing software essential to the hardware product’s functionality, undelivered software elements that relate to the hardware product’s essential software, and undelivered non-software services, the Company allocates revenue to all deliverables based on their relative selling prices. In such circumstances, the Company uses a hierarchy to determine the selling price to be used for allocating revenue to deliverables: (i) vendor-specific objective evidence of fair value (“VSOE”), (ii) third-party evidence of selling price (“TPE”) and (iii) best estimate of selling price (“ESP”). VSOE generally exists only when the Company sells the deliverable separately and is the price actually charged by the Company for that deliverable. ESPs reflect the Company’s best estimates of what the selling prices of elements would be if they were sold regularly on a stand-alone basis. For multi-element arrangements accounted for in accordance with industry specific software accounting guidance, the Company allocates revenue to all deliverables based on the VSOE of each element, and if VSOE does not exist revenue is recognized when elements lacking VSOE are delivered.

[0001628280-16-020309:notes:38]
For sales of qualifying versions of iPhone, iPad, iPod touch, Mac, Apple Watch and Apple TV, the Company has indicated it may from time to time provide future unspecified software upgrades to the device’s essential software and/or non-software services free of charge. The Company has identified up to three deliverables regularly included in arrangements involving the sale of these devices. The first deliverable, which represents the substantial portion of the allocated sales price, is the hardware and software essential to the functionality of the hardware device delivered at the time of sale. The second deliverable is the embedded right included with qualifying devices to receive on a when-and-if-available basis, future unspecified software upgrades relating to the product’s essential software. The third deliverable is the non-software services to be provided to qualifying devices. The Company allocates revenue between these deliverables using the relative selling price method. Because the Company has neither VSOE nor TPE for these deliverables, the allocation of revenue is based on the Company’s ESPs. Revenue allocated to the delivered hardware and the related essential software is recognized at the time of sale provided the other conditions for revenue recognition have been met. Revenue allocated to the embedded unspecified software upgrade rights and the non-software services is deferred and recognized on a straight-line basis over the estimated period the software upgrades and non-software services are expected to be provided. Cost of sales related to delivered hardware and related essential software, including estimated warranty costs, are recognized at the time of sale. Costs incurred to provide non-software services are recognized as cost of sales as incurred, and engineering and sales and marketing costs are recognized as operating expenses as incurred.

[0001628280-16-020309:notes:39]
The Company’s process for determining its ESP for deliverables without VSOE or TPE considers multiple factors that may vary depending upon the unique facts and circumstances related to each deliverable including, where applicable, prices charged by the Company and market trends in the pricing for similar offerings, product specific business objectives, length of time a particular version of a device has been available, estimated cost to provide the non-software services and the relative ESP of the upgrade rights and non-software services as compared to the total selling price of the product.

[0001628280-16-020309:notes:40]
Shipping Costs

[0001628280-16-020309:notes:41]
Amounts billed to customers related to shipping and handling are classified as revenue, and the Company’s shipping and handling costs are classified as cost of sales.

[0001628280-16-020309:notes:42]
Warranty Costs

[0001628280-16-020309:notes:43]
The Company generally provides for the estimated cost of hardware and software warranties in the period the related revenue is recognized. The Company assesses the adequacy of its accrued warranty liabilities and adjusts the amounts as necessary based on actual experience and changes in future estimates.

[0001628280-16-020309:notes:44]
Software Development Costs

[0001628280-16-020309:notes:45]
Research and development (“R&D”) costs are expensed as incurred. Development costs of computer software to be sold, leased, or otherwise marketed are subject to capitalization beginning when a product’s technological feasibility has been established and ending when a product is available for general release to customers. In most instances, the Company’s products are released soon after technological feasibility has been established and as a result software development costs were expensed as incurred.

[0001628280-16-020309:notes:46]
Share-based Compensation

[0001628280-16-020309:notes:47]
The Company recognizes expense related to share-based payment transactions in which it receives employee services in exchange for (a) equity instruments of the Company or (b) liabilities that are based on the fair value of the Company’s equity instruments or that may be settled by the issuance of such equity instruments. Share-based compensation cost for restricted stock and restricted stock units (“RSUs”) is measured based on the closing fair market value of the Company’s common stock on the date of grant. The Company recognizes share-based compensation cost over the award’s requisite service period on a straight-line basis for time-based RSUs and on a graded basis for RSUs that are contingent on the achievement of performance conditions. The Company recognizes a benefit from share-based compensation in the Consolidated Statements of Shareholders’ Equity if an excess tax benefit is realized. In addition, the Company recognizes the indirect effects of share-based compensation on R&D tax credits, foreign tax credits and domestic manufacturing deductions in the Consolidated Statements of Operations. Further information regarding share-based compensation can be found in Note 9, “Benefit Plans.”

[0001628280-16-020309:notes:48]
Income Taxes

[0001628280-16-020309:notes:49]
The provision for income taxes is computed using the asset and liability method, under which deferred tax assets and liabilities are recognized for the expected future tax consequences of temporary differences between the financial reporting and tax bases of assets and liabilities and for operating losses and tax credit carryforwards. Deferred tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets and liabilities are expected to be realized or settled. The Company records a valuation allowance to reduce deferred tax assets to the amount that is believed more likely than not to be realized.

[0001628280-16-020309:notes:50]
The Company recognizes the tax benefit from an uncertain tax position only if it is more likely than not the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon settlement. See Note 5, “Income Taxes” for additional information.

[0001628280-16-020309:notes:51]
Earnings Per Share

[0001628280-16-020309:notes:52]
Basic earnings per share is computed by dividing income available to common shareholders by the weighted-average number of shares of common stock outstanding during the period. Diluted earnings per share is computed by dividing income available to common shareholders by the weighted-average number of shares of common stock outstanding during the period increased to include the number of additional shares of common stock that would have been outstanding if the potentially dilutive securities had been issued. Potentially dilutive securities include outstanding stock options, shares to be purchased by employees under the Company’s employee stock purchase plan, unvested restricted stock and unvested RSUs. The dilutive effect of potentially dilutive securities is reflected in diluted earnings per share by application of the treasury stock method. Under the treasury stock method, an increase in the fair market value of the Company’s common stock can result in a greater dilutive effect from potentially dilutive securities.

[0001628280-16-020309:notes:53]
The following table shows the computation of basic and diluted earnings per share for 2016, 2015 and 2014 (net income in millions and shares in thousands):

[0001628280-16-020309:notes:54]
|  | 2016 |  | 2015 |  | 2014 |
| Numerator: |  |  |  |  |  |
| Net income | $ | 45,687 |  |  | $ | 53,394 |  |  | $ | 39,510 |  |
| Denominator: |  |  |  |  |  |
| Weighted-average shares outstanding | 5,470,820 |  |  | 5,753,421 |  |  | 6,085,572 |  |
| Effect of dilutive securities | 29,461 |  |  | 39,648 |  |  | 37,091 |  |
| Weighted-average diluted shares | 5,500,281 |  |  | 5,793,069 |  |  | 6,122,663 |  |
| Basic earnings per share | $ | 8.35 |  |  | $ | 9.28 |  |  | $ | 6.49 |  |
| Diluted earnings per share | $ | 8.31 |  |  | $ | 9.22 |  |  | $ | 6.45 |  |

[0001628280-16-020309:notes:55]
Potentially dilutive securities whose effect would have been antidilutive are excluded from the computation of diluted earnings per share.

[0001628280-16-020309:notes:56]
Financial Instruments

[0001628280-16-020309:notes:57]
Cash Equivalents and Marketable Securities

[0001628280-16-020309:notes:58]
All highly liquid investments with maturities of three months or less at the date of purchase are classified as cash equivalents. The Company’s marketable debt and equity securities have been classified and accounted for as available-for-sale. Management determines the appropriate classification of its investments at the time of purchase and reevaluates the classifications at each balance sheet date. The Company classifies its marketable debt securities as either short-term or long-term based on each instrument’s underlying contractual maturity date. Marketable debt securities with maturities of 12 months or less are classified as short-term and marketable debt securities with maturities greater than 12 months are classified as long-term. Marketable equity securities, including mutual funds, are classified as either short-term or long-term based on the nature of each security and its availability for use in current operations. The Company’s marketable debt and equity securities are carried at fair value, with unrealized gains and losses, net of taxes, reported as a component of accumulated other comprehensive income (“AOCI”) in shareholders’ equity, with the exception of unrealized losses believed to be other-than-temporary which are reported in earnings in the current period. The cost of securities sold is based upon the specific identification method.

[0001628280-16-020309:notes:59]
Derivative Financial Instruments

[0001628280-16-020309:notes:60]
The Company accounts for its derivative instruments as either assets or liabilities and carries them at fair value.

[0001628280-16-020309:notes:61]
For derivative instruments that hedge the exposure to variability in expected future cash flows that are designated as cash flow hedges, the effective portion of the gain or loss on the derivative instrument is reported as a component of AOCI in shareholders’ equity and reclassified into earnings in the same period or periods during which the hedged transaction affects earnings. The ineffective portion of the gain or loss on the derivative instrument, if any, is recognized in earnings in the current period. To receive hedge accounting treatment, cash flow hedges must be highly effective in offsetting changes to expected future cash flows on hedged transactions. For options designated as cash flow hedges, changes in the time value are excluded from the assessment of hedge effectiveness and are recognized in earnings.

[0001628280-16-020309:notes:62]
For derivative instruments that hedge the exposure to changes in the fair value of an asset or a liability and that are designated as fair value hedges, both the net gain or loss on the derivative instrument as well as the offsetting gain or loss on the hedged item are recognized in earnings in the current period.

[0001628280-16-020309:notes:63]
For derivative instruments and foreign currency debt that hedge the exposure to changes in foreign currency exchange rates used for translation of the net investment in a foreign operation and that are designated as a net investment hedge, the net gain or loss on the effective portion of the derivative instrument is reported in the same manner as a foreign currency translation adjustment. For forward exchange contracts designated as net investment hedges, the Company excludes changes in fair value relating to changes in the forward carry component from its definition of effectiveness. Accordingly, any gains or losses related to this forward carry component are recognized in earnings in the current period.

[0001628280-16-020309:notes:64]
Derivatives that do not qualify as hedges are adjusted to fair value through earnings in the current period.

[0001628280-16-020309:notes:65]
Allowance for Doubtful Accounts

[0001628280-16-020309:notes:66]
The Company records its allowance for doubtful accounts based upon its assessment of various factors, including historical experience, age of the accounts receivable balances, credit quality of the Company’s customers, current economic conditions and other factors that may affect the customers’ abilities to pay.

[0001628280-16-020309:notes:67]
Inventories

[0001628280-16-020309:notes:68]
Inventories are stated at the lower of cost, computed using the first-in, first-out method and net realizable value. Any adjustments to reduce the cost of inventories to their net realizable value are recognized in earnings in the current period. As of September 24, 2016 and September 26, 2015, the Company’s inventories consist primarily of finished goods.

[0001628280-16-020309:notes:69]
Property, Plant and Equipment

[0001628280-16-020309:notes:70]
Property, plant and equipment are stated at cost. Depreciation is computed by use of the straight-line method over the estimated useful lives of the assets, which for buildings is the lesser of 30 years or the remaining life of the underlying building; between one to five years for machinery and equipment, including product tooling and manufacturing process equipment; and the shorter of lease terms or useful life for leasehold improvements. The Company capitalizes eligible costs to acquire or develop internal-use software that are incurred subsequent to the preliminary project stage. Capitalized costs related to internal-use software are amortized using the straight-line method over the estimated useful lives of the assets, which range from three to five years. Depreciation and amortization expense on property and equipment was $8.3 billion, $9.2 billion and $6.9 billion during 2016, 2015 and 2014, respectively.

[0001628280-16-020309:notes:71]
Long-Lived Assets Including Goodwill and Other Acquired Intangible Assets

[0001628280-16-020309:notes:72]
The Company reviews property, plant and equipment, inventory component prepayments and identifiable intangibles, excluding goodwill and intangible assets with indefinite useful lives, for impairment. Long-lived assets are reviewed for impairment whenever events or changes in circumstances indicate the carrying amount of an asset may not be recoverable. Recoverability of these assets is measured by comparison of their carrying amounts to future undiscounted cash flows the assets are expected to generate. If property, plant and equipment, inventory component prepayments and certain identifiable intangibles are considered to be impaired, the impairment to be recognized equals the amount by which the carrying value of the assets exceeds its fair value.

[0001628280-16-020309:notes:73]
The Company does not amortize goodwill and intangible assets with indefinite useful lives, rather such assets are required to be tested for impairment at least annually or sooner whenever events or changes in circumstances indicate that the assets may be impaired. The Company performs its goodwill and intangible asset impairment tests in the fourth quarter of each year. The Company did not recognize any impairment charges related to goodwill or indefinite lived intangible assets during 2016, 2015 and 2014. For purposes of testing goodwill for impairment, the Company established reporting units based on its current reporting structure. Goodwill has been allocated to these reporting units to the extent it relates to each reporting unit. In 2016 and 2015, the Company’s goodwill was primarily allocated to the Americas and Europe reporting units.

[0001628280-16-020309:notes:74]
The Company amortizes its intangible assets with definite useful lives over their estimated useful lives and reviews these assets for impairment. The Company typically amortizes its acquired intangible assets with definite useful lives over periods from three to seven years.

[0001628280-16-020309:notes:75]
Fair Value Measurements

[0001628280-16-020309:notes:76]
The Company applies fair value accounting for all financial assets and liabilities and non-financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. The Company defines fair value as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities, which are required to be recorded at fair value, the Company considers the principal or most advantageous market in which the Company would transact and the market-based risk measurements or assumptions that market participants would use to price the asset or liability, such as risks inherent in valuation techniques, transfer restrictions and credit risk. Fair value is estimated by applying the following hierarchy, which prioritizes the inputs used to measure fair value into three levels and bases the categorization within the hierarchy upon the lowest level of input that is available and significant to the fair value measurement:

[0001628280-16-020309:notes:77]
Level 1 – Quoted prices in active markets for identical assets or liabilities.

[0001628280-16-020309:notes:78]
Level 2 – Observable inputs other than quoted prices in active markets for identical assets and liabilities, quoted prices for identical or similar assets or liabilities in inactive markets, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities.

[0001628280-16-020309:notes:79]
Level 3 – Inputs that are generally unobservable and typically reflect management’s estimate of assumptions that market participants would use in pricing the asset or liability.

[0001628280-16-020309:notes:80]
The Company’s valuation techniques used to measure the fair value of money market funds and certain marketable equity securities were derived from quoted prices in active markets for identical assets or liabilities. The valuation techniques used to measure the fair value of the Company’s debt instruments and all other financial instruments, all of which have counterparties with high credit ratings, were valued based on quoted market prices or model-driven valuations using significant inputs derived from or corroborated by observable market data.

[0001628280-16-020309:notes:81]
In accordance with the fair value accounting requirements, companies may choose to measure eligible financial instruments and certain other items at fair value. The Company has not elected the fair value option for any eligible financial instruments.

[0001628280-16-020309:notes:82]
Foreign Currency Translation and Remeasurement

[0001628280-16-020309:notes:83]
The Company translates the assets and liabilities of its non-U.S. dollar functional currency subsidiaries into U.S. dollars using exchange rates in effect at the end of each period. Revenue and expenses for these subsidiaries are translated using rates that approximate those in effect during the period. Gains and losses from these translations are recognized in foreign currency translation included in AOCI in shareholders’ equity. The Company’s subsidiaries that use the U.S. dollar as their functional currency remeasure monetary assets and liabilities at exchange rates in effect at the end of each period, and inventories, property and nonmonetary assets and liabilities at historical rates.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-16-020309:notes:84]
Commitments and Contingencies

[0001628280-16-020309:notes:85]
Accrued Warranty and Indemnification

[0001628280-16-020309:notes:86]
The following table shows changes in the Company’s accrued warranties and related costs for 2016, 2015 and 2014 (in millions):

[0001628280-16-020309:notes:87]
|  | 2016 |  | 2015 |  | 2014 |
| Beginning accrued warranty and related costs | $ | 4,780 |  |  | $ | 4,159 |  |  | $ | 2,967 |  |
| Cost of warranty claims | (4,663 | ) |  | (4,401 | ) |  | (3,760 | ) |
| Accruals for product warranty | 3,585 |  |  | 5,022 |  |  | 4,952 |  |
| Ending accrued warranty and related costs | $ | 3,702 |  |  | $ | 4,780 |  |  | $ | 4,159 |  |

[0001628280-16-020309:notes:88]
The Company generally does not indemnify end-users of its operating system and application software against legal claims that the software infringes third-party intellectual property rights. Other agreements entered into by the Company sometimes include indemnification provisions under which the Company could be subject to costs and/or damages in the event of an infringement claim against the Company or an indemnified third-party. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss with respect to indemnification of end-users of its operating system or application software for infringement of third-party intellectual property rights.

[0001628280-16-020309:notes:89]
The Company offers an iPhone Upgrade Program, which is available to customers who purchase a qualifying iPhone in the U.S., the U.K. and mainland China. The iPhone Upgrade Program provides customers the right to trade in that iPhone for a specified amount when purchasing a new iPhone, provided certain conditions are met. The Company accounts for the trade-in right as a guarantee liability and recognizes arrangement revenue net of the fair value of such right with subsequent changes to the guarantee liability recognized within revenue.

[0001628280-16-020309:notes:90]
The Company has entered into indemnification agreements with its directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, the Company maintains directors and officers liability insurance coverage to reduce its exposure to such obligations.

[0001628280-16-020309:notes:91]
Concentrations in the Available Sources of Supply of Materials and Product

[0001628280-16-020309:notes:92]
Although most components essential to the Company’s business are generally available from multiple sources, a number of components are currently obtained from single or limited sources. In addition, the Company competes for various components with other participants in the markets for mobile communication and media devices and personal computers. Therefore, many components used by the Company, including those that are available from multiple sources, are at times subject to industry-wide shortage and significant pricing fluctuations that could materially adversely affect the Company’s financial condition and operating results.

[0001628280-16-020309:notes:93]
The Company uses some custom components that are not commonly used by its competitors, and new products introduced by the Company often utilize custom components available from only one source. When a component or product uses new technologies, initial capacity constraints may exist until the suppliers’ yields have matured or manufacturing capacity has increased. If the Company’s supply of components for a new or existing product were delayed or constrained, or if an outsourcing partner delayed shipments of completed products to the Company, the Company’s financial condition and operating results could be materially adversely affected. The Company’s business and financial performance could also be materially adversely affected depending on the time required to obtain sufficient quantities from the original source, or to identify and obtain sufficient quantities from an alternative source. Continued availability of these components at acceptable prices, or at all, may be affected if those suppliers concentrated on the production of common components instead of components customized to meet the Company’s requirements.

[0001628280-16-020309:notes:94]
The Company has entered into agreements for the supply of many components; however, there can be no guarantee that the Company will be able to extend or renew these agreements on similar terms, or at all. Therefore, the Company remains subject to significant risks of supply shortages and price increases that could materially adversely affect its financial condition and operating results.

[0001628280-16-020309:notes:95]
Substantially all of the Company’s hardware products are manufactured by outsourcing partners that are located primarily in Asia. A significant concentration of this manufacturing is currently performed by a small number of outsourcing partners, often in single locations. Certain of these outsourcing partners are the sole-sourced suppliers of components and manufacturers for many of the Company’s products. Although the Company works closely with its outsourcing partners on manufacturing schedules, the Company’s operating results could be adversely affected if its outsourcing partners were unable to meet their production commitments. The Company’s manufacturing purchase obligations typically cover its requirements for periods up to 150 days.

[0001628280-16-020309:notes:96]
Other Off-Balance Sheet Commitments

[0001628280-16-020309:notes:97]
Operating Leases

[0001628280-16-020309:notes:98]
The Company leases various equipment and facilities, including retail space, under noncancelable operating lease arrangements. The Company does not currently utilize any other off-balance sheet financing arrangements. As of September 24, 2016, the Company’s total future minimum lease payments under noncancelable operating leases were $7.6 billion. The Company's retail store and other facility leases are typically for terms not exceeding 10 years and generally contain multi-year renewal options.

[0001628280-16-020309:notes:99]
Rent expense under all operating leases, including both cancelable and noncancelable leases, was $939 million, $794 million and $717 million in 2016, 2015 and 2014, respectively. Future minimum lease payments under noncancelable operating leases having remaining terms in excess of one year as of September 24, 2016, are as follows (in millions):

[0001628280-16-020309:notes:100]
| 2017 | $ | 929 |  |
| 2018 | 919 |  |
| 2019 | 915 |  |
| 2020 | 889 |  |
| 2021 | 836 |  |
| Thereafter | 3,139 |  |
| Total | $ | 7,627 |  |

[0001628280-16-020309:notes:101]
Contingencies

[0001628280-16-020309:notes:102]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully adjudicated, as further discussed in Part I, Item 1A of this Form 10-K under the heading “Risk Factors” and in Part I, Item 3 of this Form 10-K under the heading “Legal Proceedings.” In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to loss contingencies for asserted legal and other claims. However, the outcome of litigation is inherently uncertain. Therefore, although management considers the likelihood of such an outcome to be remote, if one or more of these legal matters were resolved against the Company in a reporting period for amounts in excess of management’s expectations, the Company’s consolidated financial statements for that reporting period could be materially adversely affected.

[0001628280-16-020309:notes:103]
Apple Inc. v. Samsung Electronics Co., Ltd., et al.

[0001628280-16-020309:notes:104]
On August 24, 2012, a jury returned a verdict awarding the Company $1.05 billion in its lawsuit against Samsung Electronics Co., Ltd. and affiliated parties in the United States District Court, Northern District of California, San Jose Division. On March 6, 2014, the District Court entered final judgment in favor of the Company in the amount of approximately $930 million. On May 18, 2015, the U.S. Court of Appeals for the Federal Circuit affirmed in part, and reversed in part, the decision of the District Court. As a result, the Court of Appeals ordered entry of final judgment on damages in the amount of approximately $548 million, with the District Court to determine supplemental damages and interest, as well as damages owed for products subject to the reversal in part. Samsung paid $548 million to the Company in December 2015, which was included in net sales in the Condensed Consolidated Statement of Operations. Because the case remains subject to further proceedings, the Company has not recognized any further amounts in its results of operations. On October 11, 2016, the United States Supreme Court heard arguments in Samsung’s request for appeal related to the $548 million in damages.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001628280-16-020309:notes:105]
Benefit Plans

[0001628280-16-020309:notes:106]
2014 Employee Stock Plan

[0001628280-16-020309:notes:107]
In the second quarter of 2014, shareholders approved the 2014 Employee Stock Plan (the “2014 Plan”) and terminated the Company’s authority to grant new awards under the 2003 Employee Stock Plan (the “2003 Plan”). The 2014 Plan provides for broad-based equity grants to employees, including executive officers, and permits the granting of RSUs, stock grants, performance-based awards, stock options and stock appreciation rights, as well as cash bonus awards. RSUs granted under the 2014 Plan generally vest over four years, based on continued employment, and are settled upon vesting in shares of the Company’s common stock on a one-for-one basis. Each share issued with respect to RSUs granted under the 2014 Plan reduces the number of shares available for grant under the plan by two shares. RSUs cancelled and shares withheld to satisfy tax withholding obligations increase the number of shares available for grant under the 2014 Plan utilizing a factor of two times the number of RSUs cancelled or shares withheld. Currently, all RSUs granted under the 2014 Plan have dividend equivalent rights (“DERs”), which entitle holders of RSUs to the same dividend value per share as holders of common stock. DERs are subject to the same vesting and other terms and conditions as the corresponding unvested RSUs. DERs are accumulated and paid when the underlying shares vest. Upon approval of the 2014 Plan, the Company reserved 385 million shares plus the number of shares remaining that were reserved but not issued under the 2003 Plan. Shares subject to outstanding awards under the 2003 Plan that expire, are cancelled or otherwise terminate, or are withheld to satisfy tax withholding obligations with respect to RSUs, will also be available for awards under the 2014 Plan. As of September 24, 2016, approximately 386.4 million shares were reserved for future issuance under the 2014 Plan.

[0001628280-16-020309:notes:108]
2003 Employee Stock Plan

[0001628280-16-020309:notes:109]
The 2003 Plan is a shareholder approved plan that provided for broad-based equity grants to employees, including executive officers. The 2003 Plan permitted the granting of incentive stock options, nonstatutory stock options, RSUs, stock appreciation rights, stock purchase rights and performance-based awards. Options granted under the 2003 Plan generally expire seven to ten years after the grant date and generally become exercisable over a period of four years, based on continued employment, with either annual, semi-annual or quarterly vesting. RSUs granted under the 2003 Plan generally vest over two to four years, based on continued employment and are settled upon vesting in shares of the Company’s common stock on a one-for-one basis. All RSUs, other than RSUs held by the Chief Executive Officer, granted under the 2003 Plan have DERs. DERs are subject to the same vesting and other terms and conditions as the corresponding unvested RSUs. DERs are accumulated and paid when the underlying shares vest. In the second quarter of 2014, the Company terminated the authority to grant new awards under the 2003 Plan.

[0001628280-16-020309:notes:110]
1997 Director Stock Plan

[0001628280-16-020309:notes:111]
The 1997 Director Stock Plan (the “Director Plan”) is a shareholder approved plan that (i) permits the Company to grant awards of RSUs or stock options to the Company’s non-employee directors, (ii) provides for automatic initial grants of RSUs upon a non-employee director joining the Board of Directors and automatic annual grants of RSUs at each annual meeting of shareholders, and (iii) permits the Board of Directors to prospectively change the relative mixture of stock options and RSUs for the initial and annual award grants and the methodology for determining the number of shares of the Company’s common stock subject to these grants without shareholder approval. Each share issued with respect to RSUs granted under the Director Plan reduces the number of shares available for grant under the plan by two shares. The Director Plan expires November 9, 2019. All RSUs granted under the Director Plan are entitled to DERs. DERs are subject to the same vesting and other terms and conditions as the corresponding unvested RSUs. DERs are accumulated and paid when the underlying shares vest. As of September 24, 2016, approximately 1.1 million shares were reserved for future issuance under the Director Plan.

[0001628280-16-020309:notes:112]
Rule 10b5-1 Trading Plans

[0001628280-16-020309:notes:113]
During the three months ended September 24, 2016, Section 16 officers Timothy D. Cook, Angela Ahrendts, Luca Maestri, Daniel Riccio, Philip Schiller and Jeffrey Williams had equity trading plans in place in accordance with Rule 10b5-1(c)(1) under the Exchange Act. An equity trading plan is a written document that pre-establishes the amounts, prices and dates (or formula for determining the amounts, prices and dates) of future purchases or sales of the Company’s stock, including shares acquired pursuant to the Company’s employee and director equity plans.

[0001628280-16-020309:notes:114]
Employee Stock Purchase Plan

[0001628280-16-020309:notes:115]
The Employee Stock Purchase Plan (the “Purchase Plan”) is a shareholder approved plan under which substantially all employees may purchase the Company’s common stock through payroll deductions at a price equal to 85% of the lower of the fair market values of the stock as of the beginning or the end of six-month offering periods. An employee’s payroll deductions under the Purchase Plan are limited to 10% of the employee’s compensation and employees may not purchase more than $25,000 of stock during any calendar year. As of September 24, 2016, approximately 47.0 million shares were reserved for future issuance under the Purchase Plan.

[0001628280-16-020309:notes:116]
401(k) Plan

[0001628280-16-020309:notes:117]
The Company’s 401(k) Plan is a deferred salary arrangement under Section 401(k) of the Internal Revenue Code. Under the 401(k) Plan, participating U.S. employees may defer a portion of their pre-tax earnings, up to the IRS annual contribution limit ($18,000 for calendar year 2016). The Company matches 50% to 100% of each employee’s contributions, depending on length of service, up to a maximum 6% of the employee’s eligible earnings.

[0001628280-16-020309:notes:118]
Restricted Stock Units

[0001628280-16-020309:notes:119]
A summary of the Company’s RSU activity and related information for 2016, 2015 and 2014, is as follows:

[0001628280-16-020309:notes:120]
|  | Number ofRSUs(in thousands) |  | Weighted-AverageGrant Date FairValue Per Share |  | Aggregate Intrinsic Value(in millions) |
| Balance at September 28, 2013 | 93,284 |  |  | $ | 62.24 |  |  |  |
| RSUs granted | 59,269 |  |  | $ | 74.54 |  |  |  |
| RSUs vested | (43,111 | ) |  | $ | 57.29 |  |  |  |
| RSUs cancelled | (5,620 | ) |  | $ | 68.47 |  |  |  |
| Balance at September 27, 2014 | 103,822 |  |  | $ | 70.98 |  |  |  |
| RSUs granted | 45,587 |  |  | $ | 105.51 |  |  |  |
| RSUs vested | (41,684 | ) |  | $ | 71.32 |  |  |  |
| RSUs cancelled | (6,258 | ) |  | $ | 80.34 |  |  |  |
| Balance at September 26, 2015 | 101,467 |  |  | $ | 85.77 |  |  |  |
| RSUs granted | 49,468 |  |  | $ | 109.28 |  |  |  |
| RSUs vested | (46,313 | ) |  | $ | 84.44 |  |  |  |
| RSUs cancelled | (5,533 | ) |  | $ | 96.48 |  |  |  |
| Balance at September 24, 2016 | 99,089 |  |  | $ | 97.54 |  |  | $ | 11,168 |  |

[0001628280-16-020309:notes:121]
The fair value as of the respective vesting dates of RSUs was $5.1 billion, $4.8 billion and $3.4 billion for 2016, 2015 and 2014, respectively. The majority of RSUs that vested in 2016, 2015 and 2014 were net-share settled such that the Company withheld shares with value equivalent to the employees’ minimum statutory obligation for the applicable income and other employment taxes, and remitted the cash to the appropriate taxing authorities. The total shares withheld were approximately 15.9 million, 14.1 million and 15.6 million for 2016, 2015 and 2014, respectively, and were based on the value of the RSUs on their respective vesting dates as determined by the Company’s closing stock price. Total payments for the employees’ tax obligations to taxing authorities were $1.7 billion, $1.6 billion and $1.2 billion in 2016, 2015 and 2014, respectively, and are reflected as a financing activity within the Consolidated Statements of Cash Flows. These net-share settlements had the effect of share repurchases by the Company as they reduced the number of shares that would have otherwise been issued as a result of the vesting and did not represent an expense to the Company.

[0001628280-16-020309:notes:122]
The following table shows a summary of the share-based compensation expense included in the Consolidated Statements of Operations for 2016, 2015 and 2014 (in millions):

[0001628280-16-020309:notes:123]
|  | 2016 |  | 2015 |  | 2014 |
| Cost of sales | $ | 769 |  |  | $ | 575 |  |  | $ | 450 |  |
| Research and development | 1,889 |  |  | 1,536 |  |  | 1,216 |  |
| Selling, general and administrative | 1,552 |  |  | 1,475 |  |  | 1,197 |  |
| Total share-based compensation expense | $ | 4,210 |  |  | $ | 3,586 |  |  | $ | 2,863 |  |

[0001628280-16-020309:notes:124]
The income tax benefit related to share-based compensation expense was $1.4 billion, $1.2 billion and $1.0 billion for 2016, 2015 and 2014, respectively. As of September 24, 2016, the total unrecognized compensation cost related to outstanding stock options, RSUs and restricted stock was $7.5 billion, which the Company expects to recognize over a weighted-average period of 2.6 years.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-16-020309:notes:125]
Comprehensive Income

[0001628280-16-020309:notes:126]
Comprehensive income consists of two components, net income and OCI. OCI refers to revenue, expenses, and gains and losses that under GAAP are recorded as an element of shareholders’ equity but are excluded from net income. The Company’s OCI consists of foreign currency translation adjustments from those subsidiaries not using the U.S. dollar as their functional currency, net deferred gains and losses on certain derivative instruments accounted for as cash flow hedges and unrealized gains and losses on marketable securities classified as available-for-sale.

[0001628280-16-020309:notes:127]
The following table shows the pre-tax amounts reclassified from AOCI into the Consolidated Statements of Operations, and the associated financial statement line item, for 2016 and 2015 (in millions):

[0001628280-16-020309:notes:128]
| Comprehensive Income Components |  | Financial Statement Line Item |  | 2016 |  | 2015 |
| Unrealized (gains)/losses on derivative instruments: |  |  |  |  |  |  |
| Foreign exchange contracts |  | Revenue |  | $ | (865 | ) |  | $ | (2,432 | ) |
|  |  | Cost of sales |  | (130 | ) |  | (2,168 | ) |
|  |  | Other income/(expense), net |  | 111 |  |  | 456 |  |
| Interest rate contracts |  | Other income/(expense), net |  | 12 |  |  | 17 |  |
|  |  |  |  | (872 | ) |  | (4,127 | ) |
| Unrealized (gains)/losses on marketable securities |  | Other income/(expense), net |  | 87 |  |  | 91 |  |
| Total amounts reclassified from AOCI |  |  |  | $ | (785 | ) |  | $ | (4,036 | ) |

[0001628280-16-020309:notes:129]
The following table shows the changes in AOCI by component for 2016 and 2015 (in millions):

[0001628280-16-020309:notes:130]
|  | Cumulative ForeignCurrency Translation |  | Unrealized Gains/Losseson Derivative Instruments |  | Unrealized Gains/Losseson Marketable Securities |  | Total |
| Balance at September 27, 2014 | $ | (242 | ) |  | $ | 1,364 |  |  | $ | (40 | ) |  | $ | 1,082 |  |
| Other comprehensive income/(loss) before reclassifications | (612 | ) |  | 3,346 |  |  | (747 | ) |  | 1,987 |  |
| Amounts reclassified from AOCI | — |  |  | (4,127 | ) |  | 91 |  |  | (4,036 | ) |
| Tax effect | 201 |  |  | 189 |  |  | 232 |  |  | 622 |  |
| Other comprehensive income/(loss) | (411 | ) |  | (592 | ) |  | (424 | ) |  | (1,427 | ) |
| Balance at September 26, 2015 | (653 | ) |  | 772 |  |  | (464 | ) |  | (345 | ) |
| Other comprehensive income/(loss) before reclassifications | 67 |  |  | 14 |  |  | 2,445 |  |  | 2,526 |  |
| Amounts reclassified from AOCI | — |  |  | (872 | ) |  | 87 |  |  | (785 | ) |
| Tax effect | 8 |  |  | 124 |  |  | (894 | ) |  | (762 | ) |
| Other comprehensive income/(loss) | 75 |  |  | (734 | ) |  | 1,638 |  |  | 979 |  |
| Balance at September 24, 2016 | $ | (578 | ) |  | $ | 38 |  |  | $ | 1,174 |  |  | $ | 634 |  |


## us-gaap:DebtDisclosureTextBlock

[0001628280-16-020309:notes:131]
Debt

[0001628280-16-020309:notes:132]
Commercial Paper

[0001628280-16-020309:notes:133]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of September 24, 2016 and September 26, 2015, the Company had $8.1 billion and $8.5 billion of Commercial Paper outstanding, respectively, with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 0.45% as of September 24, 2016 and 0.14% as of September 26, 2015.

[0001628280-16-020309:notes:134]
Long-Term Debt

[0001628280-16-020309:notes:135]
As of September 24, 2016, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $78.4 billion (collectively the “Notes”). The Notes are senior unsecured obligations, and interest is payable in arrears, quarterly for the U.S. dollar-denominated and Australian dollar-denominated floating-rate notes, semi-annually for the U.S. dollar-denominated, Australian dollar-denominated, British pound-denominated and Japanese yen-denominated fixed-rate notes and annually for the euro-denominated and Swiss franc-denominated fixed-rate notes.

[0001628280-16-020309:notes:136]
The following table provides a summary of the Company’s term debt as of September 24, 2016 and September 26, 2015:

[0001628280-16-020309:notes:137]
|  | Maturities |  | 2016 |  | 2015 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2018 |  | $ | 2,000 |  |  | 1.10% |  |  | $ | 3,000 |  |  | 0.51% - 1.10% |  |
| Fixed-rate 1.000% - 3.850% notes | 2018 - 2043 |  | 12,500 |  |  | 1.08% - 3.91% |  |  | 14,000 |  |  | 0.51% - 3.91% |  |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2017 - 2019 |  | 2,000 |  |  | 0.86% - 1.09% |  |  | 2,000 |  |  | 0.37% - 0.60% |  |
| Fixed-rate 1.050% - 4.450% notes | 2017 - 2044 |  | 10,000 |  |  | 0.85% - 4.48% |  |  | 10,000 |  |  | 0.37% - 4.48% |  |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2017 - 2020 |  | 1,781 |  |  | 0.87% - 1.87% |  |  | 1,743 |  |  | 0.36% - 1.87% |  |
| Fixed-rate 0.350% - 4.375% notes | 2017 - 2045 |  | 25,144 |  |  | 0.28% - 4.51% |  |  | 24,958 |  |  | 0.28% - 4.51% |  |
| Second quarter 2016 debt issuance of $15.5 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 |  | 500 |  |  | 1.64 | % |  | — |  |  | — |  |
| Floating-rate notes | 2021 |  | 500 |  |  | 1.95 | % |  | — |  |  | — |  |
| Fixed-rate 1.300% notes | 2018 |  | 500 |  |  | 1.32 | % |  | — |  |  | — |  |
| Fixed-rate 1.700% notes | 2019 |  | 1,000 |  |  | 1.71 | % |  | — |  |  | — |  |
| Fixed-rate 2.250% notes | 2021 |  | 3,000 |  |  | 1.91 | % |  | — |  |  | — |  |
| Fixed-rate 2.850% notes | 2023 |  | 1,500 |  |  | 2.58 | % |  | — |  |  | — |  |
| Fixed-rate 3.250% notes | 2026 |  | 3,250 |  |  | 2.51 | % |  | — |  |  | — |  |
| Fixed-rate 4.500% notes | 2036 |  | 1,250 |  |  | 4.54 | % |  | — |  |  | — |  |
| Fixed-rate 4.650% notes | 2046 |  | 4,000 |  |  | 4.58 | % |  | — |  |  | — |  |
| Third quarter 2016 Australian dollar-denominated debt issuance of A$1.4 billion: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 2.650% notes | 2020 |  | 493 |  |  | 1.92 | % |  | — |  |  | — |  |
| Fixed-rate 3.350% notes | 2024 |  | 342 |  |  | 2.61 | % |  | — |  |  | — |  |
| Fixed-rate 3.600% notes | 2026 |  | 247 |  |  | 2.84 | % |  | — |  |  | — |  |
| Third quarter 2016 debt issuance of $1.4 billion: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 4.150% notes | 2046 |  | 1,377 |  |  | 4.15 | % |  | — |  |  | — |  |
| Fourth quarter 2016 debt issuance of $7.0 billion: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 |  | 350 |  |  | 0.91 | % |  | — |  |  | — |  |
| Fixed-rate 1.100% notes | 2019 |  | 1,150 |  |  | 1.13 | % |  | — |  |  | — |  |
| Fixed-rate 1.550% notes | 2021 |  | 1,250 |  |  | 1.40 | % |  | — |  |  | — |  |
| Fixed-rate 2.450% notes | 2026 |  | 2,250 |  |  | 2.15 | % |  | — |  |  | — |  |
| Fixed-rate 3.850% notes | 2046 |  | 2,000 |  |  | 3.86 | % |  | — |  |  | — |  |
| Total term debt |  |  | 78,384 |  |  |  |  | 55,701 |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  | (174 | ) |  |  |  | (248 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 717 |  |  |  |  | 376 |  |  |  |
| Less: Current portion of long-term debt, net |  |  | (3,500 | ) |  |  |  | (2,500 | ) |  |  |
| Total long-term debt |  |  | $ | 75,427 |  |  |  |  | $ | 53,329 |  |  |  |

[0001628280-16-020309:notes:138]
To manage foreign currency risk associated with the Australian dollar-denominated notes issued in the third quarter of 2016, the Company entered into currency swaps with an aggregate notional amount of $1.0 billion, which effectively converted these notes to U.S. dollar-denominated notes.

[0001628280-16-020309:notes:139]
To manage interest rate risk on the U.S. dollar-denominated fixed-rate notes issued in the second quarter of 2016 and maturing in 2021, 2023 and 2026, the Company entered into interest rate swaps with an aggregate notional amount of $5.0 billion. To manage interest rate risk on the U.S. dollar-denominated fixed-rate notes issued in the fourth quarter of 2016 and maturing in 2021 and 2026, the Company entered into interest rate swaps with an aggregate notional amount of $1.8 billion. These interest rate swaps effectively converted a portion of the U.S. dollar-denominated fixed-rate notes to floating interest rate notes.

[0001628280-16-020309:notes:140]
As of September 24, 2016, ¥195.5 billion of the Japanese yen-denominated notes was designated as a hedge of the foreign currency exposure of its net investment in a foreign operation. The foreign currency transaction gain or loss on the Japanese yen-denominated debt designated as a hedge is recorded in OCI as a part of the cumulative translation adjustment. As of September 24, 2016, the carrying value of the debt designated as a net investment hedge was $1.9 billion. For further discussion regarding the Company’s use of derivative instruments see the Derivative Financial Instruments section of Note 2, “Financial Instruments.”

[0001628280-16-020309:notes:141]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount and, if applicable, adjustments related to hedging. The Company recognized $1.4 billion, $722 million and $381 million of interest expense on its term debt for 2016, 2015 and 2014, respectively.

[0001628280-16-020309:notes:142]
The future principal payments for the Company’s Notes as of September 24, 2016 are as follows (in millions):

[0001628280-16-020309:notes:143]
| 2017 | $ | 3,500 |  |
| 2018 | 6,500 |  |
| 2019 | 6,834 |  |
| 2020 | 6,454 |  |
| 2021 | 7,750 |  |
| Thereafter | 47,346 |  |
| Total term debt | $ | 78,384 |  |

[0001628280-16-020309:notes:144]
As of September 24, 2016 and September 26, 2015, the fair value of the Company’s Notes, based on Level 2 inputs, was $81.7 billion and $54.9 billion, respectively.


## us-gaap:DerivativesPolicyTextBlock

[0001628280-16-020309:notes:145]
The Company may use derivatives to partially offset its business exposure to foreign currency and interest rate risk on expected future cash flows, on net investments in certain foreign subsidiaries and on certain existing assets and liabilities. However, the Company may choose not to hedge certain exposures for a variety of reasons including, but not limited to, accounting considerations and the prohibitive economic cost of hedging particular exposures. There can be no assurance the hedges will offset more than a portion of the financial impact resulting from movements in foreign currency exchange or interest rates.

[0001628280-16-020309:notes:146]
To help protect gross margins from fluctuations in foreign currency exchange rates, certain of the Company’s subsidiaries whose functional currency is the U.S. dollar may hedge a portion of forecasted foreign currency revenue, and subsidiaries whose functional currency is not the U.S. dollar and who sell in local currencies may hedge a portion of forecasted inventory purchases not denominated in the subsidiaries’ functional currencies. The Company may enter into forward contracts, option contracts or other instruments to manage this risk and may designate these instruments as cash flow hedges. The Company typically hedges portions of its forecasted foreign currency exposure associated with revenue and inventory purchases, typically for up to 12 months.

[0001628280-16-020309:notes:147]
To help protect the net investment in a foreign operation from adverse changes in foreign currency exchange rates, the Company may enter into foreign currency forward and option contracts to offset the changes in the carrying amounts of these investments due to fluctuations in foreign currency exchange rates. In addition, the Company may use non-derivative financial instruments, such as its foreign currency-denominated debt, as economic hedges of its net investments in certain foreign subsidiaries. In both of these cases, the Company designates these instruments as net investment hedges.

[0001628280-16-020309:notes:148]
The Company may also enter into non-designated foreign currency contracts to partially offset the foreign currency exchange gains and losses generated by the re-measurement of certain assets and liabilities denominated in non-functional currencies.

[0001628280-16-020309:notes:149]
The Company may enter into interest rate swaps, options, or other instruments to manage interest rate risk. These instruments may offset a portion of changes in income or expense, or changes in fair value of the Company’s term debt or investments. The Company designates these instruments as either cash flow or fair value hedges. The Company’s hedged interest rate transactions as of September 24, 2016 are expected to be recognized within 10 years.

[0001628280-16-020309:notes:150]
Cash Flow Hedges

[0001628280-16-020309:notes:151]
The effective portions of cash flow hedges are recorded in AOCI until the hedged item is recognized in earnings. Deferred gains and losses associated with cash flow hedges of foreign currency revenue are recognized as a component of net sales in the same period as the related revenue is recognized, and deferred gains and losses related to cash flow hedges of inventory purchases are recognized as a component of cost of sales in the same period as the related costs are recognized. Deferred gains and losses associated with cash flow hedges of interest income or expense are recognized in other income/(expense), net in the same period as the related income or expense is recognized. The ineffective portions and amounts excluded from the effectiveness testing of cash flow hedges are recognized in other income/(expense), net.

[0001628280-16-020309:notes:152]
Derivative instruments designated as cash flow hedges must be de-designated as hedges when it is probable the forecasted hedged transaction will not occur in the initially identified time period or within a subsequent two-month time period. Deferred gains and losses in AOCI associated with such derivative instruments are reclassified immediately into other income/(expense), net. Any subsequent changes in fair value of such derivative instruments are reflected in other income/(expense), net unless they are re-designated as hedges of other transactions.

[0001628280-16-020309:notes:153]
Net Investment Hedges

[0001628280-16-020309:notes:154]
The effective portions of net investment hedges are recorded in other comprehensive income (“OCI”) as a part of the cumulative translation adjustment. The ineffective portions and amounts excluded from the effectiveness testing of net investment hedges are recognized in other income/(expense), net.

[0001628280-16-020309:notes:155]
Fair Value Hedges

[0001628280-16-020309:notes:156]
Gains and losses related to changes in fair value hedges are recognized in earnings along with a corresponding loss or gain related to the change in value of the underlying hedged item.

[0001628280-16-020309:notes:157]
Non-Designated Derivatives

[0001628280-16-020309:notes:158]
Derivatives that are not designated as hedging instruments are adjusted to fair value through earnings in the financial statement line item to which the derivative relates.

[0001628280-16-020309:notes:159]
The Company records all derivatives in the Consolidated Balance Sheets at fair value. The Company’s accounting treatment for these derivative instruments is based on its hedge designation.


## us-gaap:DividendsDeclaredTableTextBlock

[0001628280-16-020309:notes:160]
The Company declared and paid cash dividends per share during the periods presented as follows:

[0001628280-16-020309:notes:161]
|  | DividendsPer Share |  | Amount(in millions) |
| 2016: |  |  |  |
| Fourth quarter | $ | 0.57 |  |  | $ | 3,071 |  |
| Third quarter | 0.57 |  |  | 3,117 |  |
| Second quarter | 0.52 |  |  | 2,879 |  |
| First quarter | 0.52 |  |  | 2,898 |  |
| Total cash dividends declared and paid | $ | 2.18 |  |  | $ | 11,965 |  |
| 2015: |  |  |  |
| Fourth quarter | $ | 0.52 |  |  | $ | 2,950 |  |
| Third quarter | 0.52 |  |  | 2,997 |  |
| Second quarter | 0.47 |  |  | 2,734 |  |
| First quarter | 0.47 |  |  | 2,750 |  |
| Total cash dividends declared and paid | $ | 1.98 |  |  | $ | 11,431 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001628280-16-020309:notes:162]
Cash, Cash Equivalents and Marketable Securities

[0001628280-16-020309:notes:163]
The Company may sell certain of its marketable securities prior to their stated maturities for strategic reasons including, but not limited to, anticipation of credit deterioration and duration management. The maturities of the Company’s long-term marketable securities generally range from one to five years.

[0001628280-16-020309:notes:164]
The Company considers the declines in market value of its marketable securities investment portfolio to be temporary in nature. The Company typically invests in highly-rated securities, and its investment policy generally limits the amount of credit exposure to any one issuer. The policy generally requires investments to be investment grade, with the primary objective of minimizing the potential risk of principal loss. Fair values were determined for each individual security in the investment portfolio. When evaluating an investment for other-than-temporary impairment the Company reviews factors such as the length of time and extent to which fair value has been below its cost basis, the financial condition of the issuer and any changes thereto, changes in market interest rates and the Company’s intent to sell, or whether it is more likely than not it will be required to sell the investment before recovery of the investment’s cost basis. As of September 24, 2016, the Company does not consider any of its investments to be other-than-temporarily impaired.

[0001628280-16-020309:notes:165]
The Company records all derivatives in the Consolidated Balance Sheets at fair value. The Company’s accounting treatment for these derivative instruments is based on its hedge designation. The following tables show the Company’s derivative instruments at gross fair value as of September 24, 2016 and September 26, 2015 (in millions):

[0001628280-16-020309:notes:166]
|  | 2016 |
|  | Fair Value ofDerivatives Designatedas Hedge Instruments |  | Fair Value ofDerivatives Not Designatedas Hedge Instruments |  | TotalFair Value |
| Derivative assets (1): |  |  |  |  |  |
| Foreign exchange contracts | $ | 518 |  |  | $ | 153 |  |  | $ | 671 |  |
| Interest rate contracts | $ | 728 |  |  | $ | — |  |  | $ | 728 |  |
| Derivative liabilities (2): |  |  |  |  |  |
| Foreign exchange contracts | $ | 935 |  |  | $ | 134 |  |  | $ | 1,069 |  |
| Interest rate contracts | $ | 7 |  |  | $ | — |  |  | $ | 7 |  |

[0001628280-16-020309:notes:167]
|  | 2015 |
|  | Fair Value ofDerivatives Designatedas Hedge Instruments |  | Fair Value ofDerivatives Not Designatedas Hedge Instruments |  | TotalFair Value |
| Derivative assets (1): |  |  |  |
| Foreign exchange contracts | $ | 1,442 |  |  | $ | 109 |  |  | $ | 1,551 |  |
| Interest rate contracts | $ | 394 |  |  | $ | — |  |  | $ | 394 |  |
| Derivative liabilities (2): |  |  |  |  |  |
| Foreign exchange contracts | $ | 905 |  |  | $ | 94 |  |  | $ | 999 |  |
| Interest rate contracts | $ | 13 |  |  | $ | — |  |  | $ | 13 |  |

[0001628280-16-020309:notes:168]
| (1) | The fair value of derivative assets is measured using Level 2 fair value inputs and is recorded as other current assets in the Consolidated Balance Sheets. |

[0001628280-16-020309:notes:169]
| (2) | The fair value of derivative liabilities is measured using Level 2 fair value inputs and is recorded as accrued expenses in the Consolidated Balance Sheets. |

[0001628280-16-020309:notes:170]
The following table shows the pre-tax gains and losses of the Company’s derivative and non-derivative instruments designated as cash flow, net investment and fair value hedges on OCI and the Consolidated Statements of Operations for 2016, 2015 and 2014 (in millions):

[0001628280-16-020309:notes:171]
|  | 2016 |  | 2015 |  | 2014 |
| Gains/(Losses) recognized in OCI – effective portion: |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |
| Foreign exchange contracts | $ | 109 |  |  | $ | 3,592 |  |  | $ | 1,750 |  |
| Interest rate contracts | (57 | ) |  | (111 | ) |  | (15 | ) |
| Total | $ | 52 |  |  | $ | 3,481 |  |  | $ | 1,735 |  |
| Net investment hedges: |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 167 |  |  | $ | 53 |  |
| Foreign currency debt | (258 | ) |  | (71 | ) |  | — |  |
| Total | $ | (258 | ) |  | $ | 96 |  |  | $ | 53 |  |
| Gains/(Losses) reclassified from AOCI into net income – effective portion: |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |
| Foreign exchange contracts | $ | 885 |  |  | $ | 4,092 |  |  | $ | (154 | ) |
| Interest rate contracts | (11 | ) |  | (17 | ) |  | (16 | ) |
| Total | $ | 874 |  |  | $ | 4,075 |  |  | $ | (170 | ) |
| Gains/(Losses) on derivative instruments: |  |  |  |  |  |
| Fair value hedges: |  |  |  |  |  |
| Interest rate contracts | $ | 341 |  |  | $ | 337 |  |  | $ | 39 |  |
| Gains/(Losses) related to hedged items: |  |  |  |  |  |
| Fair value hedges: |  |  |  |  |  |
| Interest rate contracts | $ | (341 | ) |  | $ | (337 | ) |  | $ | (39 | ) |

[0001628280-16-020309:notes:172]
The notional amounts for outstanding derivative instruments provide one measure of the transaction volume outstanding and do not represent the amount of the Company’s exposure to credit or market loss. The credit risk amounts represent the Company’s gross exposure to potential accounting loss on derivative instruments that are outstanding or unsettled if all counterparties failed to perform according to the terms of the contract, based on then-current currency or interest rates at each respective date. The Company’s exposure to credit loss and market risk will vary over time as currency and interest rates change. Although the table above reflects the notional and credit risk amounts of the Company’s derivative instruments, it does not reflect the gains or losses associated with the exposures and transactions that the instruments are intended to hedge. The amounts ultimately realized upon settlement of these financial instruments, together with the gains and losses on the underlying exposures, will depend on actual market conditions during the remaining life of the instruments.

[0001628280-16-020309:notes:173]
The Company generally enters into master netting arrangements, which are designed to reduce credit risk by permitting net settlement of transactions with the same counterparty. To further limit credit risk, the Company generally enters into collateral security arrangements that provide for collateral to be received or posted when the net fair value of certain financial instruments fluctuates from contractually established thresholds. The Company presents its derivative assets and derivative liabilities at their gross fair values in its Consolidated Balance Sheets.  The net cash collateral received by the Company related to derivative instruments under its collateral security arrangements was $163 million as of September 24, 2016 and $1.0 billion as of September 26, 2015, which were recorded as accrued expenses in the Consolidated Balance Sheets.

[0001628280-16-020309:notes:174]
Under master netting arrangements with the respective counterparties to the Company’s derivative contracts, the Company is allowed to net settle transactions with a single net amount payable by one party to the other. As of September 24, 2016 and September 26, 2015, the potential effects of these rights of set-off associated with the Company’s derivative contracts, including the effects of collateral, would be a reduction to both derivative assets and derivative liabilities of $1.5 billion and $2.2 billion, respectively, resulting in a net derivative asset of $160 million and a net derivative liability of $78 million, respectively.

[0001628280-16-020309:notes:175]
Accounts Receivable

[0001628280-16-020309:notes:176]
Trade Receivables

[0001628280-16-020309:notes:177]
The Company has considerable trade receivables outstanding with its third-party cellular network carriers, wholesalers, retailers, value-added resellers, small and mid-sized businesses and education, enterprise and government customers. The Company generally does not require collateral from its customers; however, the Company will require collateral in certain instances to limit credit risk. In addition, when possible, the Company attempts to limit credit risk on trade receivables with credit insurance for certain customers or by requiring third-party financing, loans or leases to support credit exposure. These credit-financing arrangements are directly between the third-party financing company and the end customer. As such, the Company generally does not assume any recourse or credit risk sharing related to any of these arrangements.

[0001628280-16-020309:notes:178]
As of September 24, 2016 and September 26, 2015, the Company had one customer that represented 10% or more of total trade receivables, which accounted for 10% and 12%, respectively. The Company’s cellular network carriers accounted for 63% and 71% of trade receivables as of September 24, 2016 and September 26, 2015, respectively.

[0001628280-16-020309:notes:179]
Vendor Non-Trade Receivables

[0001628280-16-020309:notes:180]
The Company has non-trade receivables from certain of its manufacturing vendors resulting from the sale of components to these vendors who manufacture sub-assemblies or assemble final products for the Company. The Company purchases these components directly from suppliers. Vendor non-trade receivables from two of the Company’s vendors accounted for 47% and 21% of total vendor non-trade receivables as of September 24, 2016 and three of the Company’s vendors accounted for 38%, 18% and 14% of total vendor non-trade receivables as of September 26, 2015.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-16-020309:notes:181]
The provision for income taxes for 2016, 2015 and 2014, consisted of the following (in millions):

[0001628280-16-020309:notes:182]
|  | 2016 |  | 2015 |  | 2014 |
| Federal: |  |  |  |  |  |
| Current | $ | 7,652 |  |  | $ | 11,730 |  |  | $ | 8,624 |  |
| Deferred | 5,043 |  |  | 3,408 |  |  | 3,183 |  |
|  | 12,695 |  |  | 15,138 |  |  | 11,807 |  |
| State: |  |  |  |  |  |
| Current | 990 |  |  | 1,265 |  |  | 855 |  |
| Deferred | (138 | ) |  | (220 | ) |  | (178 | ) |
|  | 852 |  |  | 1,045 |  |  | 677 |  |
| Foreign: |  |  |  |  |  |
| Current | 2,105 |  |  | 4,744 |  |  | 2,147 |  |
| Deferred | 33 |  |  | (1,806 | ) |  | (658 | ) |
|  | 2,138 |  |  | 2,938 |  |  | 1,489 |  |
| Provision for income taxes | $ | 15,685 |  |  | $ | 19,121 |  |  | $ | 13,973 |  |

[0001628280-16-020309:notes:183]
The foreign provision for income taxes is based on foreign pre-tax earnings of $41.1 billion, $47.6 billion and $33.6 billion in 2016, 2015 and 2014, respectively. The Company’s consolidated financial statements provide for any related tax liability on undistributed earnings that the Company does not intend to be indefinitely reinvested outside the U.S. Substantially all of the Company’s undistributed international earnings intended to be indefinitely reinvested in operations outside the U.S. were generated by subsidiaries organized in Ireland, which has a statutory tax rate of 12.5%. As of September 24, 2016, U.S. income taxes have not been provided on a cumulative total of $109.8 billion of such earnings. The amount of unrecognized deferred tax liability related to these temporary differences is estimated to be $35.9 billion.

[0001628280-16-020309:notes:184]
As of September 24, 2016 and September 26, 2015, $216.0 billion and $186.9 billion, respectively, of the Company’s cash, cash equivalents and marketable securities were held by foreign subsidiaries and are generally based in U.S. dollar-denominated holdings. Amounts held by foreign subsidiaries are generally subject to U.S. income taxation on repatriation to the U.S.

[0001628280-16-020309:notes:185]
A reconciliation of the provision for income taxes, with the amount computed by applying the statutory federal income tax rate (35% in 2016, 2015 and 2014) to income before provision for income taxes for 2016, 2015 and 2014, is as follows (dollars in millions):

[0001628280-16-020309:notes:186]
|  | 2016 |  | 2015 |  | 2014 |
| Computed expected tax | $ | 21,480 |  |  | $ | 25,380 |  |  | $ | 18,719 |  |
| State taxes, net of federal effect | 553 |  |  | 680 |  |  | 469 |  |
| Indefinitely invested earnings of foreign subsidiaries | (5,582 | ) |  | (6,470 | ) |  | (4,744 | ) |
| Domestic production activities deduction | (382 | ) |  | (426 | ) |  | (495 | ) |
| Research and development credit, net | (371 | ) |  | (171 | ) |  | (88 | ) |
| Other | (13 | ) |  | 128 |  |  | 112 |  |
| Provision for income taxes | $ | 15,685 |  |  | $ | 19,121 |  |  | $ | 13,973 |  |
| Effective tax rate | 25.6 | % |  | 26.4 | % |  | 26.1 | % |

[0001628280-16-020309:notes:187]
The Company’s income taxes payable have been reduced by the tax benefits from employee stock plan awards. For RSUs, the Company receives an income tax benefit upon the award’s vesting equal to the tax effect of the underlying stock’s fair market value. The Company had net excess tax benefits from equity awards of $379 million, $748 million and $706 million in 2016, 2015 and 2014, respectively, which were reflected as increases to common stock.

[0001628280-16-020309:notes:188]
As of September 24, 2016 and September 26, 2015, the significant components of the Company’s deferred tax assets and liabilities were (in millions):

[0001628280-16-020309:notes:189]
|  | 2016 |  | 2015 |
| Deferred tax assets: |  |  |  |
| Accrued liabilities and other reserves | $ | 4,135 |  |  | $ | 4,205 |  |
| Basis of capital assets | 2,107 |  |  | 2,238 |  |
| Deferred revenue | 1,717 |  |  | 1,941 |  |
| Deferred cost sharing | 667 |  |  | 667 |  |
| Share-based compensation | 601 |  |  | 575 |  |
| Unrealized losses | — |  |  | 564 |  |
| Other | 788 |  |  | 721 |  |
| Total deferred tax assets, net of valuation allowance of $0 | 10,015 |  |  | 10,911 |  |
| Deferred tax liabilities: |  |  |  |
| Unremitted earnings of foreign subsidiaries | 31,436 |  |  | 26,868 |  |
| Other | 485 |  |  | 303 |  |
| Total deferred tax liabilities | 31,921 |  |  | 27,171 |  |
| Net deferred tax liabilities | $ | (21,906 | ) |  | $ | (16,260 | ) |

[0001628280-16-020309:notes:190]
Deferred tax assets and liabilities reflect the effects of tax losses, credits and the future income tax effects of temporary differences between the consolidated financial statement carrying amounts of existing assets and liabilities and their respective tax bases and are measured using enacted tax rates that apply to taxable income in the years in which those temporary differences are expected to be recovered or settled.

[0001628280-16-020309:notes:191]
Uncertain Tax Positions

[0001628280-16-020309:notes:192]
Tax positions are evaluated in a two-step process. The Company first determines whether it is more likely than not that a tax position will be sustained upon examination. If a tax position meets the more-likely-than-not recognition threshold it is then measured to determine the amount of benefit to recognize in the financial statements. The tax position is measured as the largest amount of benefit that is greater than 50% likely of being realized upon ultimate settlement. The Company classifies gross interest and penalties and unrecognized tax benefits that are not expected to result in payment or receipt of cash within one year as non-current liabilities in the Consolidated Balance Sheets.

[0001628280-16-020309:notes:193]
As of September 24, 2016, the total amount of gross unrecognized tax benefits was $7.7 billion, of which $2.8 billion, if recognized, would affect the Company’s effective tax rate.  As of September 26, 2015, the total amount of gross unrecognized tax benefits was $6.9 billion, of which $2.5 billion, if recognized, would affect the Company’s effective tax rate.

[0001628280-16-020309:notes:194]
The aggregate changes in the balance of gross unrecognized tax benefits, which excludes interest and penalties, for 2016, 2015 and 2014, is as follows (in millions):

[0001628280-16-020309:notes:195]
|  | 2016 |  | 2015 |  | 2014 |
| Beginning Balance | $ | 6,900 |  |  | $ | 4,033 |  |  | $ | 2,714 |  |
| Increases related to tax positions taken during a prior year | 1,121 |  |  | 2,056 |  |  | 1,295 |  |
| Decreases related to tax positions taken during a prior year | (257 | ) |  | (345 | ) |  | (280 | ) |
| Increases related to tax positions taken during the current year | 1,578 |  |  | 1,278 |  |  | 882 |  |
| Decreases related to settlements with taxing authorities | (1,618 | ) |  | (109 | ) |  | (574 | ) |
| Decreases related to expiration of statute of limitations | — |  |  | (13 | ) |  | (4 | ) |
| Ending Balance | $ | 7,724 |  |  | $ | 6,900 |  |  | $ | 4,033 |  |

[0001628280-16-020309:notes:196]
The Company includes interest and penalties related to unrecognized tax benefits within the provision for income taxes. As of September 24, 2016 and September 26, 2015, the total amount of gross interest and penalties accrued was $1.0 billion and $1.3 billion, respectively, which is classified as non-current liabilities in the Consolidated Balance Sheets. In connection with tax matters, the Company recognized interest and penalty expense in 2016, 2015 and 2014 of $295 million, $709 million and $40 million, respectively.

[0001628280-16-020309:notes:197]
The Company is subject to taxation and files income tax returns in the U.S. federal jurisdiction and in many state and foreign jurisdictions. During the fourth quarter of 2016, the Company reached a partial settlement with the U.S. Internal Revenue Service (the “IRS”) on its examination of the years 2010 through 2012. In connection with this settlement, the Company recognized a tax benefit in the fourth quarter of 2016 that was not significant to its consolidated financial statements. All years prior to 2013 are closed, except for the years 2010 through 2012 relating to R&D tax credits. In addition, the Company is subject to audits by state, local and foreign tax authorities. In major states and major foreign jurisdictions, the years subsequent to 2003 generally remain open and could be subject to examination by the taxing authorities.

[0001628280-16-020309:notes:198]
The Company believes that an adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax audits cannot be predicted with certainty. If any issues addressed in the Company’s tax audits are resolved in a manner not consistent with its expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. Although timing of the resolution and/or closure of audits is not certain, the Company believes it is reasonably possible that its gross unrecognized tax benefits could decrease (whether by payment, release or a combination of both) in the next 12 months by up to $850 million.

[0001628280-16-020309:notes:199]
On August 30, 2016, the European Commission announced its decision that Ireland granted state aid to the Company by providing tax opinions in 1991 and 2007 concerning the tax allocation of profits of the Irish branches of two subsidiaries of the Company (the "State Aid Decision"). The State Aid Decision orders Ireland to calculate and recover additional taxes from the Company for the period June 2003 through September 2014. Irish legislative changes, effective as of the beginning of 2015, eliminated the application of the tax opinions from that date forward. The Company believes the State Aid Decision to be without merit and intends to appeal to the General Court of the Court of Justice of the European Union. Ireland has also announced its intention to appeal the State Aid Decision. While the European Commission announced a recovery amount of up to €13 billion, plus interest, the actual amount of additional taxes subject to recovery is to be calculated by Ireland in accordance with the European Commission's guidance. Once the recovery amount is computed by Ireland, the Company anticipates funding it, including interest, out of foreign cash into escrow, pending conclusion of all appeals. The Company believes that any incremental Irish corporate income taxes potentially due would be creditable against U.S. taxes.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001628280-16-020309:notes:200]
Acquired Intangible Assets

[0001628280-16-020309:notes:201]
The Company’s acquired intangible assets with definite useful lives primarily consist of patents and licenses. The following table summarizes the components of gross and net acquired intangible asset balances as of September 24, 2016 and September 26, 2015 (in millions):

[0001628280-16-020309:notes:202]
|  | 2016 |  | 2015 |
|  | GrossCarrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |  | GrossCarrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |
| Definite-lived and amortizable acquired intangible assets | $ | 8,912 |  |  | $ | (5,806 | ) |  | $ | 3,106 |  |  | $ | 8,125 |  |  | $ | (4,332 | ) |  | $ | 3,793 |  |
| Indefinite-lived and non-amortizable acquired intangible assets | 100 |  |  | — |  |  | 100 |  |  | 100 |  |  | — |  |  | 100 |  |
| Total acquired intangible assets | $ | 9,012 |  |  | $ | (5,806 | ) |  | $ | 3,206 |  |  | $ | 8,225 |  |  | $ | (4,332 | ) |  | $ | 3,893 |  |

[0001628280-16-020309:notes:203]
Amortization expense related to acquired intangible assets was $1.5 billion, $1.3 billion and $1.1 billion in 2016, 2015 and 2014, respectively. As of September 24, 2016, the remaining weighted-average amortization period for acquired intangible assets is 3.4 years. The expected annual amortization expense related to acquired intangible assets as of September 24, 2016, is as follows (in millions):

[0001628280-16-020309:notes:204]
| 2017 | $ | 1,197 |  |
| 2018 | 902 |  |
| 2019 | 449 |  |
| 2020 | 255 |  |
| 2021 | 175 |  |
| Thereafter | 128 |  |
| Total | $ | 3,106 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001628280-16-020309:notes:205]
Selected Quarterly Financial Information (Unaudited)

[0001628280-16-020309:notes:206]
The following tables show a summary of the Company’s quarterly financial information for each of the four quarters of 2016 and 2015 (in millions, except per share amounts):

[0001628280-16-020309:notes:207]
|  | Fourth Quarter |  | Third Quarter |  | Second Quarter |  | First Quarter |
| 2016: |  |  |  |  |  |  |  |
| Net sales | $ | 46,852 |  |  | $ | 42,358 |  |  | $ | 50,557 |  |  | $ | 75,872 |  |
| Gross margin | $ | 17,813 |  |  | $ | 16,106 |  |  | $ | 19,921 |  |  | $ | 30,423 |  |
| Net income | $ | 9,014 |  |  | $ | 7,796 |  |  | $ | 10,516 |  |  | $ | 18,361 |  |
| Earnings per share (1): |  |  |  |  |  |  |  |
| Basic | $ | 1.68 |  |  | $ | 1.43 |  |  | $ | 1.91 |  |  | $ | 3.30 |  |
| Diluted | $ | 1.67 |  |  | $ | 1.42 |  |  | $ | 1.90 |  |  | $ | 3.28 |  |

[0001628280-16-020309:notes:208]
|  | Fourth Quarter |  | Third Quarter |  | Second Quarter |  | First Quarter |
| 2015: |  |  |  |  |  |  |  |
| Net sales | $ | 51,501 |  |  | $ | 49,605 |  |  | $ | 58,010 |  |  | $ | 74,599 |  |
| Gross margin | $ | 20,548 |  |  | $ | 19,681 |  |  | $ | 23,656 |  |  | $ | 29,741 |  |
| Net income | $ | 11,124 |  |  | $ | 10,677 |  |  | $ | 13,569 |  |  | $ | 18,024 |  |
| Earnings per share (1): |  |  |  |  |  |  |  |
| Basic | $ | 1.97 |  |  | $ | 1.86 |  |  | $ | 2.34 |  |  | $ | 3.08 |  |
| Diluted | $ | 1.96 |  |  | $ | 1.85 |  |  | $ | 2.33 |  |  | $ | 3.06 |  |

[0001628280-16-020309:notes:209]
| (1) | Basic and diluted earnings per share are computed independently for each of the quarters presented. Therefore, the sum of quarterly basic and diluted per share information may not equal annual basic and diluted earnings per share. |


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001628280-16-020309:notes:210]
A reconciliation of the Company’s segment operating income to the Consolidated Statements of Operations for 2016, 2015 and 2014 is as follows (in millions):

[0001628280-16-020309:notes:211]
|  | 2016 |  | 2015 |  | 2014 |
| Segment operating income | $ | 74,301 |  |  | $ | 83,850 |  |  | $ | 62,209 |  |
| Research and development expense | (10,045 | ) |  | (8,067 | ) |  | (6,041 | ) |
| Other corporate expenses, net | (4,232 | ) |  | (4,553 | ) |  | (3,665 | ) |
| Total operating income | $ | 60,024 |  |  | $ | 71,230 |  |  | $ | 52,503 |  |


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001628280-16-020309:notes:212]
Net sales by product for 2016, 2015 and 2014 are as follows (in millions):

[0001628280-16-020309:notes:213]
|  | 2016 |  | 2015 |  | 2014 |
| iPhone (1) | $ | 136,700 |  |  | $ | 155,041 |  |  | $ | 101,991 |  |
| iPad (1) | 20,628 |  |  | 23,227 |  |  | 30,283 |  |
| Mac (1) | 22,831 |  |  | 25,471 |  |  | 24,079 |  |
| Services (2) | 24,348 |  |  | 19,909 |  |  | 18,063 |  |
| Other Products (1)(3) | 11,132 |  |  | 10,067 |  |  | 8,379 |  |
| Total net sales | $ | 215,639 |  |  | $ | 233,715 |  |  | $ | 182,795 |  |

[0001628280-16-020309:notes:214]
| (1) | Includes deferrals and amortization of related software upgrade rights and non-software services. |

[0001628280-16-020309:notes:215]
| (2) | Includes revenue from iTunes Store, App Store, Mac App Store, TV App Store, iBooks Store, Apple Music, AppleCare, Apple Pay, licensing and other services. |

[0001628280-16-020309:notes:216]
| (3) | Includes sales of Apple TV, Apple Watch, Beats products, iPod and Apple-branded and third-party accessories. |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001628280-16-020309:notes:217]
Net sales for 2016, 2015 and 2014 and long-lived assets as of September 24, 2016 and September 26, 2015 are as follows (in millions):

[0001628280-16-020309:notes:218]
|  | 2016 |  | 2015 |  | 2014 |
| Net sales: |  |  |  |  |  |
| U.S. | $ | 75,667 |  |  | $ | 81,732 |  |  | $ | 68,909 |  |
| China (1) | 46,349 |  |  | 56,547 |  |  | 30,638 |  |
| Other countries | 93,623 |  |  | 95,436 |  |  | 83,248 |  |
| Total net sales | $ | 215,639 |  |  | $ | 233,715 |  |  | $ | 182,795 |  |

[0001628280-16-020309:notes:219]
|  | 2016 |  | 2015 |
| Long-lived assets: |  |  |  |
| U.S. | $ | 16,364 |  |  | $ | 12,022 |  |
| China (1) | 7,807 |  |  | 8,722 |  |
| Other countries | 2,839 |  |  | 3,040 |  |
| Total long-lived assets | $ | 27,010 |  |  | $ | 23,784 |  |

[0001628280-16-020309:notes:220]
| (1) | China includes Hong Kong. Long-lived assets located in China consist primarily of product tooling and manufacturing process equipment and assets related to retail stores and related infrastructure. |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001628280-16-020309:notes:221]
The following table shows information by reportable operating segment for 2016, 2015 and 2014 (in millions):

[0001628280-16-020309:notes:222]
|  | 2016 |  | 2015 |  | 2014 |
| Americas: |  |  |  |  |  |
| Net sales | $ | 86,613 |  |  | $ | 93,864 |  |  | $ | 80,095 |  |
| Operating income | $ | 28,172 |  |  | $ | 31,186 |  |  | $ | 26,158 |  |
| Europe: |  |  |  |  |  |
| Net sales | $ | 49,952 |  |  | $ | 50,337 |  |  | $ | 44,285 |  |
| Operating income | $ | 15,348 |  |  | $ | 16,527 |  |  | $ | 14,434 |  |
| Greater China: |  |  |  |  |  |
| Net sales | $ | 48,492 |  |  | $ | 58,715 |  |  | $ | 31,853 |  |
| Operating income | $ | 18,835 |  |  | $ | 23,002 |  |  | $ | 11,039 |  |
| Japan: |  |  |  |  |  |
| Net sales | $ | 16,928 |  |  | $ | 15,706 |  |  | $ | 15,314 |  |
| Operating income | $ | 7,165 |  |  | $ | 7,617 |  |  | $ | 6,904 |  |
| Rest of Asia Pacific: |  |  |  |  |  |
| Net sales | $ | 13,654 |  |  | $ | 15,093 |  |  | $ | 11,248 |  |
| Operating income | $ | 4,781 |  |  | $ | 5,518 |  |  | $ | 3,674 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-16-020309:notes:223]
Segment Information and Geographic Data

[0001628280-16-020309:notes:224]
The Company reports segment information based on the “management” approach. The management approach designates the internal reporting used by management for making decisions and assessing performance as the source of the Company’s reportable operating segments.

[0001628280-16-020309:notes:225]
The Company manages its business primarily on a geographic basis. The Company’s reportable operating segments consist of the Americas, Europe, Greater China, Japan and Rest of Asia Pacific. The Americas segment includes both North and South America. The Europe segment includes European countries, as well as India, the Middle East and Africa. The Greater China segment includes China, Hong Kong and Taiwan. The Rest of Asia Pacific segment includes Australia and those Asian countries not included in the Company’s other reportable operating segments. Although the reportable operating segments provide similar hardware and software products and similar services, each one is managed separately to better align with the location of the Company’s customers and distribution partners and the unique market dynamics of each geographic region. The accounting policies of the various segments are the same as those described in Note 1, “Summary of Significant Accounting Policies.”

[0001628280-16-020309:notes:226]
The Company evaluates the performance of its reportable operating segments based on net sales and operating income. Net sales for geographic segments are generally based on the location of customers and sales through the Company’s retail stores located in those geographic locations. Operating income for each segment includes net sales to third parties, related cost of sales and operating expenses directly attributable to the segment. Advertising expenses are generally included in the geographic segment in which the expenditures are incurred. Operating income for each segment excludes other income and expense and certain expenses managed outside the reportable operating segments. Costs excluded from segment operating income include various corporate expenses such as R&D, corporate marketing expenses, certain share-based compensation expenses, income taxes, various nonrecurring charges and other separately managed general and administrative costs. The Company does not include intercompany transfers between segments for management reporting purposes.

[0001628280-16-020309:notes:227]
The U.S. and China were the only countries that accounted for more than 10% of the Company’s net sales in 2016, 2015 and 2014. There was no single customer that accounted for more than 10% of net sales in 2016, 2015 or 2014. Net sales for 2016, 2015 and 2014 and long-lived assets as of September 24, 2016 and September 26, 2015 are as follows (in millions):


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-16-020309:notes:228]
Shareholders’ Equity

[0001628280-16-020309:notes:229]
Dividends

[0001628280-16-020309:notes:230]
Future dividends are subject to declaration by the Board of Directors.

[0001628280-16-020309:notes:231]
Share Repurchase Program

[0001628280-16-020309:notes:232]
In April 2016, the Company’s Board of Directors increased the share repurchase authorization from $140 billion to $175 billion of the Company’s common stock, of which $133 billion had been utilized as of September 24, 2016. The Company’s share repurchase program does not obligate it to acquire any specific number of shares. Under the program, shares may be repurchased in privately negotiated and/or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).

[0001628280-16-020309:notes:233]
The Company has entered, and in the future may enter, into accelerated share repurchase arrangements (“ASRs”) with financial institutions. In exchange for up-front payments, the financial institutions deliver shares of the Company’s common stock during the purchase periods of each ASR. The total number of shares ultimately delivered, and therefore the average repurchase price paid per share, is determined at the end of the applicable purchase period of each ASR based on the volume weighted-average price of the Company’s common stock during that period. The shares received are retired in the periods they are delivered, and the up-front payments are accounted for as a reduction to shareholders’ equity in the Company’s Consolidated Balance Sheets in the periods the payments are made. The Company reflects the ASRs as a repurchase of common stock in the period delivered for purposes of calculating earnings per share and as forward contracts indexed to its own common stock. The ASRs met all of the applicable criteria for equity classification, and therefore were not accounted for as derivative instruments.
