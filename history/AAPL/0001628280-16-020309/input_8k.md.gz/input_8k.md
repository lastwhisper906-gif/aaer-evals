# AAPL 8-K — 0001628280-16-020258 filed 2016-10-25

## item codes, every 8-K on or before 2016-10-26

- 2016-10-25 0001628280-16-020258 — 2.02, 9.01
- 2016-08-04 0001193125-16-672044 — 8.01, 9.01
- 2016-07-26 0001628280-16-017762 — 2.02, 9.01
- 2016-06-22 0001193125-16-628957 — 8.01, 9.01
- 2016-04-26 0001193125-16-556520 — 2.02, 9.01
- 2016-03-24 0001193125-16-516891 — 8.01, 9.01
- 2016-03-01 0001193125-16-488223 — 5.02, 5.07, 9.01
- 2016-02-23 0001193125-16-473562 — 8.01, 9.01
- 2016-01-26 0001193125-16-438421 — 2.02, 9.01
- 2015-12-22 0001193125-15-410853 — 5.03, 9.01
- 2015-12-17 0001193125-15-406279 — 5.02
- 2015-10-27 0001193125-15-354756 — 2.02, 9.01
- 2015-10-02 0001193125-15-336615 — 5.02
- 2015-09-17 0001193125-15-322466 — 8.01, 9.01
- 2015-07-31 0001193125-15-273023 — 8.01, 9.01
- 2015-07-21 0001193125-15-258464 — 2.02, 9.01
- 2015-06-10 0001193125-15-219298 — 8.01, 9.01
- 2015-05-13 0001193125-15-186064 — 8.01, 9.01
- 2015-04-27 0001193125-15-149607 — 7.01, 9.01
- 2015-04-27 0001193125-15-149590 — 2.02, 9.01
- 2015-03-13 0001104659-15-019336 — 5.07, 9.01
- 2015-02-09 0001193125-15-039270 — 8.01, 9.01
- 2015-01-28 0001193125-15-023732 — 8.01, 9.01
- 2015-01-27 0001193125-15-021857 — 2.02, 9.01
- 2014-11-10 0001193125-14-406296 — 8.01, 9.01
- 2014-10-20 0001193125-14-376361 — 2.02, 9.01
- 2014-07-23 0001193125-14-277193 — 8.01, 9.01
- 2014-07-22 0001193125-14-275598 — 2.02, 9.01
- 2014-07-17 0001193125-14-271698 — 5.02
- 2014-06-06 0001193125-14-228798 — 5.03, 9.01
- 2014-05-30 0001181431-14-021923 — 5.02
- 2014-05-06 0001193125-14-184969 — 8.01, 9.01
- 2014-04-23 0001193125-14-154883 — 7.01, 9.01
- 2014-04-23 0001193125-14-154871 — 2.02, 9.01
- 2014-03-05 0001193125-14-084697 — 5.02, 5.03, 5.07, 9.01
- 2014-01-27 0001193125-14-022238 — 2.02, 9.01
- 2013-10-28 0001193125-13-413498 — 2.02, 9.01
- 2013-09-23 0001181431-13-050140 — 8.01
- 2013-07-30 0001181431-13-041847 — 5.02
- 2013-07-23 0001193125-13-298914 — 2.02, 9.01
- 2013-06-21 0001193125-13-267629 — 5.02
- 2013-05-03 0001193125-13-199324 — 8.01, 9.01
- 2013-04-24 0001193125-13-170623 — 8.01, 9.01
- 2013-04-23 0001193125-13-167469 — 7.01, 9.01
- 2013-04-23 0001193125-13-167458 — 2.02, 9.01
- 2013-03-01 0001193125-13-085842 — 5.07
- 2013-01-23 0001193125-13-020783 — 2.02, 9.01
- 2012-10-25 0001193125-12-435506 — 2.02, 9.01
- 2012-07-24 0001193125-12-312355 — 2.02, 9.01
- 2012-06-28 0001181431-12-038301 — 5.02
- 2012-05-24 0001181431-12-032458 — 5.02
- 2012-04-24 0001193125-12-178928 — 2.02, 9.01
- 2012-02-27 0001193125-12-081892 — 5.07
- 2012-01-24 0001193125-12-021833 — 2.02, 9.01
- 2011-11-16 0001181431-11-056354 — 5.02
- 2011-10-18 0001193125-11-273826 — 2.02, 9.01
- 2011-10-06 0001181431-11-051976 — 8.01
- 2011-08-26 0001181431-11-047179 — 5.02
- 2011-07-19 0001193125-11-191368 — 2.02, 9.01
- 2011-06-15 0001181431-11-036782 — 5.02
- 2011-04-20 0001193125-11-103732 — 2.02, 9.01
- 2011-02-24 0001193125-11-045411 — 5.07
- 2011-01-18 0001193125-11-009392 — 2.02, 9.01
- 2011-01-18 0001181431-11-003847 — 5.02
- 2010-11-17 0001181431-10-056327 — 5.02, 5.03, 9.01
- 2010-10-18 0001193125-10-230992 — 2.02, 9.01
- 2010-07-20 0001193125-10-161807 — 2.02, 9.01
- 2010-04-20 0001193125-10-087786 — 2.02, 9.01
- 2010-03-12 0001181431-10-016054 — 5.02
- 2010-03-01 0001193125-10-044765 — 5.02, 5.07, 9.01
- 2010-01-25 0001193125-10-012096 — 2.02, 9.01
- 2009-10-19 0001193125-09-209633 — 2.02, 9.01
- 2009-08-04 0001181431-09-037492 — 5.02
- 2009-07-21 0001193125-09-152290 — 2.02, 9.01
- 2009-06-02 0001181431-09-028400 — 5.03
- 2009-04-22 0001193125-09-084599 — 2.02, 9.01
- 2009-02-27 0001181431-09-012161 — 4.01
- 2009-01-21 0001193125-09-009009 — 2.02, 9.01
- 2009-01-16 0001181431-09-003017 — 5.02
- 2008-10-21 0001193125-08-213642 — 2.02, 9.01
- 2008-08-26 0001181431-08-050059 — 5.03
- 2008-07-21 0001193125-08-154381 — 2.02, 9.01
- 2008-06-09 0001181431-08-037620 — 8.01
- 2008-04-23 0001193125-08-088001 — 2.02, 9.01
- 2008-01-22 0001193125-08-009715 — 2.02, 9.01
- 2008-01-15 0001181431-08-003342 — 2.02, 8.01
- 2008-01-08 0001181431-08-002372 — 5.02
- 2007-10-22 0001104659-07-076142 — 2.02, 9.01
- 2007-07-25 0001104659-07-056111 — 2.02, 9.01
- 2007-05-16 0001104659-07-040672 — 5.02, 9.01
- 2007-04-25 0001104659-07-031354 — 2.02, 9.01
- 2007-04-24 0001104659-07-030938 — 8.01, 9.01
- 2007-02-21 0001104659-07-012760 — 5.03, 9.01
- 2007-01-17 0001104659-07-002905 — 2.02, 9.01
- 2007-01-10 0001104659-07-001648 — 5.03, 9.01
- 2006-10-27 0001104659-06-069015 — 8.01
- 2006-10-18 0001104659-06-067275 — 2.02, 9.01
- 2006-10-04 0001104659-06-064935 — 5.02, 8.01, 9.01
- 2006-09-01 0001104659-06-058808 — 1.01, 5.02, 5.03, 9.01
- 2006-08-11 0001104659-06-054118 — 2.02, 3.01, 9.01
- 2006-08-04 0001104659-06-051302 — 2.02, 4.02, 9.01
- 2006-07-19 0001104659-06-047739 — 2.02, 9.01
- 2006-04-21 0001181431-06-024759 — 1.01
- 2006-04-19 0001104659-06-025992 — 2.02, 9.01
- 2006-01-18 0001104659-06-002690 — 2.02, 9.01
- 2006-01-10 0001104659-06-001428 — 2.02
- 2005-12-19 0001181431-05-067468 — 1.01
- 2005-10-14 0001181431-05-056604 — 5.02
- 2005-10-11 0001104659-05-048094 — 2.02, 9.01
- 2005-08-26 0001181431-05-049163 — 1.01
- 2005-08-15 0001181431-05-046871 — 1.01
- 2005-07-13 0001104659-05-032297 — 2.02, 9.01
- 2005-06-06 0001181431-05-033177 — 8.01
- 2005-04-26 0001181431-05-023450 — 1.01
- 2005-04-13 0001104659-05-016307 — 2.02, 9.01
- 2005-03-02 0001181431-05-013840 — 3.03, 5.03
- 2005-02-11 0001104659-05-005507 — 8.01
- 2005-01-12 0001104659-05-001183 — 2.02, 9.01
- 2005-01-11 0001104659-05-001049 — 2.02
- 2004-10-13 0001104659-04-030400 — 2.02, 9.01
- 2004-07-14 0001104659-04-019574 — 12, 7
- 2004-04-14 0001104659-04-010122 — 12, 7
- 2004-01-14 0001104659-04-000896 — 12, 7
- 2003-10-15 0001104659-03-022879 — 12, 7
- 2003-07-16 0001104659-03-014913 — 7, 9
- 2003-04-16 0001047469-03-013617 — 7, 9
- 2003-03-21 0001104659-03-004649 — 5, 7
- 2002-08-13 0000912057-02-031595 — 5, 7
- 2002-08-05 0000912057-02-029692 — 5, 7
- 2000-01-24 0000912057-00-002128 — 5, 7
- 1999-09-07 0000320193-99-000010 — 2
- 1999-07-16 0000320193-99-000007 — 2
- 1998-12-23 0000320193-98-000010 — 1
- 1998-01-08 0000320193-98-000001 — 2
- 1997-09-25 0000320193-97-000019 — 2
- 1997-09-25 0000320193-97-000018 — 2
- 1997-09-05 0000320193-97-000016 — 2
- 1997-07-28 0000320193-97-000012 — 4
- 1997-04-25 0000320193-97-000009 — 5
- 1997-04-10 0000320193-97-000007 — 7
- 1996-12-24 0000320193-96-000027 — 7
- 1996-12-23 0000320193-96-000025 — 4 — amendment of 0000320193-96-000021
- 1996-12-13 0000320193-96-000021 — 4
- 1996-10-28 0000912057-96-023874 — 5, 7
- 1996-06-17 0000320193-96-000014 — 1
- 1996-04-12 0000320193-96-000006 — 1

## late-filing notifications on or before 2016-10-26

- 2006-12-15 0001104659-06-081617 — NT 10-K, for the period ended 2006-09-30
- 2006-08-11 0001104659-06-053743 — NT 10-Q, for the period ended 2006-07-01

## item 2.02 — earnings release, exhibit 99.1

[0001628280-16-020258:8k_2_02:1]
EX-99.1
2
a8-kexhibit991q420169242016.htm
EXHIBIT 99.1

[0001628280-16-020258:8k_2_02:2]
Exhibit

[0001628280-16-020258:8k_2_02:3]
Exhibit 99.1

[0001628280-16-020258:8k_2_02:4]
Apple Reports Fourth Quarter Results

[0001628280-16-020258:8k_2_02:5]
Services Revenue Grows 24% to All-Time Quarterly Record of $6.3 Billion

[0001628280-16-020258:8k_2_02:6]
CUPERTINO, California - October 25, 2016 - Apple® today announced financial results for its fiscal 2016 fourth quarter ended September 24, 2016. The Company posted quarterly revenue of $46.9 billion and quarterly net income of $9 billion, or $1.67 per diluted share. These results compare to revenue of $51.5 billion and net income of $11.1 billion, or $1.96 per diluted share, in the year-ago quarter. Gross margin was 38 percent compared to 39.9 percent in the year-ago quarter. International sales accounted for 62 percent of the quarter's revenue.

[0001628280-16-020258:8k_2_02:7]
"Our strong September quarter results cap a very successful fiscal 2016 for Apple," said Tim Cook, Apple's CEO. "We're thrilled with the customer response to iPhone 7, iPhone 7 Plus and Apple Watch Series 2, as well as the incredible momentum of our Services business, where revenue grew 24 percent to set another all-time record."

[0001628280-16-020258:8k_2_02:8]
"We are pleased to have generated $16.1 billion in operating cash flow, a new record for the September quarter," said Luca Maestri, Apple's CFO. "We also returned $9.3 billion to investors through dividends and share repurchases during the quarter and have now completed over $186 billion of our capital return program."

[0001628280-16-020258:8k_2_02:9]
Apple is providing the following guidance for its fiscal 2017 first quarter:

[0001628280-16-020258:8k_2_02:10]
| • | revenue between $76 billion and $78 billion |

[0001628280-16-020258:8k_2_02:11]
| • | gross margin between 38 percent and 38.5 percent |

[0001628280-16-020258:8k_2_02:12]
| • | operating expenses between $6.9 billion and $7 billion |

[0001628280-16-020258:8k_2_02:13]
| • | other income/(expense) of $400 million |

[0001628280-16-020258:8k_2_02:14]
| • | tax rate of 26 percent |

[0001628280-16-020258:8k_2_02:15]
Apple's board of directors has declared a cash dividend of $0.57 per share of the Company's common stock. The dividend is payable on November 10, 2016 to shareholders of record as of the close of business on November 7, 2016.

[0001628280-16-020258:8k_2_02:16]
Apple will provide live streaming of its Q4 2016 financial results conference call beginning at 2:00 p.m. PDT on October 25, 2016 at www.apple.com/investor/earnings-call/. This webcast will also be available for replay for approximately two weeks thereafter.

[0001628280-16-020258:8k_2_02:17]
Apple revolutionized personal technology with the introduction of the Macintosh in 1984. Today, Apple leads the world in innovation with iPhone, iPad, Mac, Apple Watch and Apple TV. Apple's four software platforms - iOS, macOS, watchOS and tvOS - provide seamless experiences across all Apple devices and empower people with breakthrough services including the App Store, Apple Music, Apple Pay and iCloud. Apple's more than 100,000 employees are dedicated to making the best products on earth, and to leaving the world better than we found it.

[0001628280-16-020258:8k_2_02:18]
Press Contact:

[0001628280-16-020258:8k_2_02:19]
Kristin Huguet

[0001628280-16-020258:8k_2_02:20]
Apple

[0001628280-16-020258:8k_2_02:21]
khuguet@apple.com

[0001628280-16-020258:8k_2_02:22]
(408) 974-2414

[0001628280-16-020258:8k_2_02:23]
Investor Relations Contacts:

[0001628280-16-020258:8k_2_02:24]
Nancy Paxton

[0001628280-16-020258:8k_2_02:25]
Apple

[0001628280-16-020258:8k_2_02:26]
paxton1@apple.com

[0001628280-16-020258:8k_2_02:27]
(408) 974-5420

[0001628280-16-020258:8k_2_02:28]
Joan Hoover

[0001628280-16-020258:8k_2_02:29]
Apple

[0001628280-16-020258:8k_2_02:30]
hoover1@apple.com

[0001628280-16-020258:8k_2_02:31]
(408) 974-4570

[0001628280-16-020258:8k_2_02:32]
NOTE TO EDITORS: For additional information visit Apple's PR website (www.apple.com/pr), or call Apple's Media Helpline at (408) 974-2042.

[0001628280-16-020258:8k_2_02:33]
© 2016 Apple Inc. All rights reserved. Apple and the Apple logo are trademarks of Apple. Other company and product names may be trademarks of their respective owners.

[0001628280-16-020258:8k_2_02:34]
Apple Inc.

[0001628280-16-020258:8k_2_02:35]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001628280-16-020258:8k_2_02:36]
(In millions, except number of shares which are reflected in thousands and per share amounts)

[0001628280-16-020258:8k_2_02:37]
|  | Three Months Ended |  | Twelve Months Ended |
|  | September 24, 2016 |  | September 26, 2015 |  | September 24, 2016 |  | September 26, 2015 |
| Net sales | $ | 46,852 |  |  | $ | 51,501 |  |  | $ | 215,639 |  |  | $ | 233,715 |  |
| Cost of sales (1) | 29,039 |  |  | 30,953 |  |  | 131,376 |  |  | 140,089 |  |
| Gross margin | 17,813 |  |  | 20,548 |  |  | 84,263 |  |  | 93,626 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development (1) | 2,570 |  |  | 2,220 |  |  | 10,045 |  |  | 8,067 |  |
| Selling, general and administrative (1) | 3,482 |  |  | 3,705 |  |  | 14,194 |  |  | 14,329 |  |
| Total operating expenses | 6,052 |  |  | 5,925 |  |  | 24,239 |  |  | 22,396 |  |
| Operating income | 11,761 |  |  | 14,623 |  |  | 60,024 |  |  | 71,230 |  |
| Other income/(expense), net | 427 |  |  | 439 |  |  | 1,348 |  |  | 1,285 |  |
| Income before provision for income taxes | 12,188 |  |  | 15,062 |  |  | 61,372 |  |  | 72,515 |  |
| Provision for income taxes | 3,174 |  |  | 3,938 |  |  | 15,685 |  |  | 19,121 |  |
| Net income | $ | 9,014 |  |  | $ | 11,124 |  |  | $ | 45,687 |  |  | $ | 53,394 |  |
| Earnings per share: |  |  |  |  |  |  |  |
| Basic | $ | 1.68 |  |  | $ | 1.97 |  |  | $ | 8.35 |  |  | $ | 9.28 |  |
| Diluted | $ | 1.67 |  |  | $ | 1.96 |  |  | $ | 8.31 |  |  | $ | 9.22 |  |
| Shares used in computing earnings per share: |  |  |  |  |  |  |  |
| Basic | 5,366,912 |  |  | 5,646,916 |  |  | 5,470,820 |  |  | 5,753,421 |  |
| Diluted | 5,393,333 |  |  | 5,682,519 |  |  | 5,500,281 |  |  | 5,793,069 |  |
| Cash dividends declared per share | $ | 0.57 |  |  | $ | 0.52 |  |  | $ | 2.18 |  |  | $ | 1.98 |  |
| (1) Includes share-based compensation expense as follows: |
| Cost of sales | $ | 186 |  |  | $ | 145 |  |  | $ | 769 |  |  | $ | 575 |  |
| Research and development | $ | 476 |  |  | $ | 390 |  |  | $ | 1,889 |  |  | $ | 1,536 |  |
| Selling, general and administrative | $ | 368 |  |  | $ | 380 |  |  | $ | 1,552 |  |  | $ | 1,475 |  |

[0001628280-16-020258:8k_2_02:38]
Apple Inc.

[0001628280-16-020258:8k_2_02:39]
UNAUDITED CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-16-020258:8k_2_02:40]
(In millions, except number of shares which are reflected in thousands and par value)

[0001628280-16-020258:8k_2_02:41]
|  | September 24, 2016 |  | September 26, 2015 |
| ASSETS: |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 20,484 |  |  | $ | 21,120 |  |
| Short-term marketable securities | 46,671 |  |  | 20,481 |  |
| Accounts receivable, less allowances of $53 and $63, respectively | 15,754 |  |  | 16,849 |  |
| Inventories | 2,132 |  |  | 2,349 |  |
| Vendor non-trade receivables | 13,545 |  |  | 13,494 |  |
| Other current assets | 8,283 |  |  | 15,085 |  |
| Total current assets | 106,869 |  |  | 89,378 |  |
| Long-term marketable securities | 170,430 |  |  | 164,065 |  |
| Property, plant and equipment, net | 27,010 |  |  | 22,471 |  |
| Goodwill | 5,414 |  |  | 5,116 |  |
| Acquired intangible assets, net | 3,206 |  |  | 3,893 |  |
| Other non-current assets | 8,757 |  |  | 5,422 |  |
| Total assets | $ | 321,686 |  |  | $ | 290,345 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY: |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 37,294 |  |  | $ | 35,490 |  |
| Accrued expenses | 22,027 |  |  | 25,181 |  |
| Deferred revenue | 8,080 |  |  | 8,940 |  |
| Commercial paper | 8,105 |  |  | 8,499 |  |
| Current portion of long-term debt | 3,500 |  |  | 2,500 |  |
| Total current liabilities | 79,006 |  |  | 80,610 |  |
| Deferred revenue, non-current | 2,930 |  |  | 3,624 |  |
| Long-term debt | 75,427 |  |  | 53,329 |  |
| Other non-current liabilities | 36,074 |  |  | 33,427 |  |
| Total liabilities | 193,437 |  |  | 170,990 |  |
| Commitments and contingencies |  |  |  |
| Shareholders’ equity: |  |  |  |
| Common stock and additional paid-in capital, $0.00001 par value: 12,600,000 shares authorized; 5,336,166 and 5,578,753 shares issued and outstanding, respectively | 31,251 |  |  | 27,416 |  |
| Retained earnings | 96,364 |  |  | 92,284 |  |
| Accumulated other comprehensive income/(loss) | 634 |  |  | (345 | ) |
| Total shareholders’ equity | 128,249 |  |  | 119,355 |  |
| Total liabilities and shareholders’ equity | $ | 321,686 |  |  | $ | 290,345 |  |

[0001628280-16-020258:8k_2_02:42]
Apple Inc.

[0001628280-16-020258:8k_2_02:43]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001628280-16-020258:8k_2_02:44]
(In millions)

[0001628280-16-020258:8k_2_02:45]
|  | Twelve Months Ended |
|  | September 24, 2016 |  | September 26, 2015 |
| Cash and cash equivalents, beginning of the period | $ | 21,120 |  |  | $ | 13,844 |  |
| Operating activities: |  |  |  |
| Net income | 45,687 |  |  | 53,394 |  |
| Adjustments to reconcile net income to cash generated by operating activities: |  |  |  |
| Depreciation and amortization | 10,505 |  |  | 11,257 |  |
| Share-based compensation expense | 4,210 |  |  | 3,586 |  |
| Deferred income tax expense | 4,938 |  |  | 1,382 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | 1,095 |  |  | 611 |  |
| Inventories | 217 |  |  | (238 | ) |
| Vendor non-trade receivables | (51 | ) |  | (3,735 | ) |
| Other current and non-current assets | 1,090 |  |  | (179 | ) |
| Accounts payable | 1,791 |  |  | 5,400 |  |
| Deferred revenue | (1,554 | ) |  | 1,042 |  |
| Other current and non-current liabilities | (2,104 | ) |  | 8,746 |  |
| Cash generated by operating activities | 65,824 |  |  | 81,266 |  |
| Investing activities: |  |  |  |
| Purchases of marketable securities | (142,428 | ) |  | (166,402 | ) |
| Proceeds from maturities of marketable securities | 21,258 |  |  | 14,538 |  |
| Proceeds from sales of marketable securities | 90,536 |  |  | 107,447 |  |
| Payments made in connection with business acquisitions, net | (297 | ) |  | (343 | ) |
| Payments for acquisition of property, plant and equipment | (12,734 | ) |  | (11,247 | ) |
| Payments for acquisition of intangible assets | (814 | ) |  | (241 | ) |
| Payments for strategic investments | (1,388 | ) |  | — |  |
| Other | (110 | ) |  | (26 | ) |
| Cash used in investing activities | (45,977 | ) |  | (56,274 | ) |
| Financing activities: |  |  |  |
| Proceeds from issuance of common stock | 495 |  |  | 543 |  |
| Excess tax benefits from equity awards | 407 |  |  | 749 |  |
| Payments for taxes related to net share settlement of equity awards | (1,570 | ) |  | (1,499 | ) |
| Payments for dividends and dividend equivalents | (12,150 | ) |  | (11,561 | ) |
| Repurchases of common stock | (29,722 | ) |  | (35,253 | ) |
| Proceeds from issuance of term debt, net | 24,954 |  |  | 27,114 |  |
| Repayments of term debt | (2,500 | ) |  | — |  |
| Change in commercial paper, net | (397 | ) |  | 2,191 |  |
| Cash used in financing activities | (20,483 | ) |  | (17,716 | ) |
| Increase/(Decrease) in cash and cash equivalents | (636 | ) |  | 7,276 |  |
| Cash and cash equivalents, end of the period | $ | 20,484 |  |  | $ | 21,120 |  |
| Supplemental cash flow disclosure: |  |  |  |
| Cash paid for income taxes, net | $ | 10,444 |  |  | $ | 13,252 |  |
| Cash paid for interest | $ | 1,316 |  |  | $ | 514 |  |
