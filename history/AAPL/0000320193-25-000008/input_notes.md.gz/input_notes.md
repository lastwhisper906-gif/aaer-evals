# AAPL notes — 0000320193-25-000008


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000320193-25-000008:notes:1]
[same as prior period, unchanged from 0000320193-24-000081:notes:1]

[0000320193-25-000008:notes:2]
The condensed consolidated financial statements include the accounts of Apple Inc. and its wholly owned subsidiaries (collectively “Apple” or the “Company”). In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements and accompanying notes in conformity with U.S. generally accepted accounting principles (“GAAP”) requires the use of management estimates. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company’s annual consolidated financial statements and accompanying notes included in its Annual Report on Form 10-K for the fiscal year ended September 28, 2024 (the “2024 Form 10-K”).

[0000320193-25-000008:notes:3]
The Company’s fiscal year is the 52- or 53-week period that ends on the last Saturday of September. An additional week is included in the first fiscal quarter every five or six years to realign the Company’s fiscal quarters with calendar quarters. The Company’s fiscal years 2025 and 2024 span 52 weeks each. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in September and the associated quarters, months and periods of those fiscal years.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000320193-25-000008:notes:4]
Revenue
Net sales disaggregated by significant products and services for the three months ended December 28, 2024 and December 30, 2023 were as follows (in millions):

[0000320193-25-000008:notes:5]
|  | Three Months Ended |  |  |
|  | December 28,2024 |  | December 30,2023 |  |  |  |  |
| iPhone® | $ | 69,138 |  |  | $ | 69,702 |  |  |  |  |  |
| Mac® | 8,987 |  |  | 7,780 |  |  |  |  |  |
| iPad® | 8,088 |  |  | 7,023 |  |  |  |  |  |
| Wearables, Home and Accessories | 11,747 |  |  | 11,953 |  |  |  |  |  |
| Services | 26,340 |  |  | 23,117 |  |  |  |  |  |
| Total net sales | $ | 124,300 |  |  | $ | 119,575 |  |  |  |  |  |

[0000320193-25-000008:notes:6]
Total net sales include $3.7 billion of revenue recognized in the three months ended December 28, 2024 that was included in deferred revenue as of September 28, 2024 and $3.5 billion of revenue recognized in the three months ended December 30, 2023 that was included in deferred revenue as of September 30, 2023.

[0000320193-25-000008:notes:7]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 10, “Segment Information and Geographic Data” for the three months ended December 28, 2024 and December 30, 2023, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.

[0000320193-25-000008:notes:8]
As of December 28, 2024 and September 28, 2024, the Company had total deferred revenue of $13.2 billion and $12.8 billion, respectively. As of December 28, 2024, the Company expects 64% of total deferred revenue to be realized in less than a year, 25% within one-to-two years, 9% within two-to-three years and 2% in greater than three years.


## us-gaap:EarningsPerShareTextBlock

[0000320193-25-000008:notes:9]
Earnings Per Share
The following table shows the computation of basic and diluted earnings per share for the three months ended December 28, 2024 and December 30, 2023 (net income in millions and shares in thousands):

[0000320193-25-000008:notes:10]
|  | Three Months Ended |  |  |
|  | December 28,2024 |  | December 30,2023 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 36,330 |  |  | $ | 33,916 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 15,081,724 |  |  | 15,509,763 |  |  |  |  |  |
| Effect of dilutive share-based awards | 69,141 |  |  | 66,878 |  |  |  |  |  |
| Weighted-average diluted shares | 15,150,865 |  |  | 15,576,641 |  |  |  |  |  |
| Basic earnings per share | $ | 2.41 |  |  | $ | 2.19 |  |  |  |  |  |
| Diluted earnings per share | $ | 2.40 |  |  | $ | 2.18 |  |  |  |  |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000320193-25-000008:notes:11]
[same as prior period, unchanged from 0000320193-24-000081:notes:12]

[0000320193-25-000008:notes:12]
The following tables show the Company’s cash, cash equivalents and marketable securities by significant investment category as of December 28, 2024 and September 28, 2024 (in millions):

[0000320193-25-000008:notes:13]
|  | December 28, 2024 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | CurrentMarketableSecurities |  | Non-CurrentMarketableSecurities |
| Cash | $ | 27,073 |  |  | $ | — |  |  | $ | — |  |  | $ | 27,073 |  |  | $ | 27,073 |  |  | $ | — |  |  | $ | — |  |
| Level 1: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 937 |  |  | — |  |  | — |  |  | 937 |  |  | 937 |  |  | — |  |  | — |  |
| Mutual funds | 597 |  |  | 109 |  |  | (7) |  |  | 699 |  |  | — |  |  | 699 |  |  | — |  |
| Subtotal | 1,534 |  |  | 109 |  |  | (7) |  |  | 1,636 |  |  | 937 |  |  | 699 |  |  | — |  |
| Level 2 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 15,516 |  |  | 5 |  |  | (616) |  |  | 14,905 |  |  | 903 |  |  | 2,718 |  |  | 11,284 |  |
| U.S. agency securities | 5,570 |  |  | — |  |  | (303) |  |  | 5,267 |  |  | 314 |  |  | 1,683 |  |  | 3,270 |  |
| Non-U.S. government securities | 8,596 |  |  | 22 |  |  | (819) |  |  | 7,799 |  |  | 50 |  |  | 2,524 |  |  | 5,225 |  |
| Certificates of deposit and time deposits | 1,147 |  |  | — |  |  | (13) |  |  | 1,134 |  |  | 874 |  |  | 247 |  |  | 13 |  |
| Commercial paper | 418 |  |  | — |  |  | (19) |  |  | 399 |  |  | 101 |  |  | 298 |  |  | — |  |
| Corporate debt securities | 61,566 |  |  | 96 |  |  | (2,210) |  |  | 59,452 |  |  | 47 |  |  | 14,451 |  |  | 44,954 |  |
| Municipal securities | 355 |  |  | — |  |  | (7) |  |  | 348 |  |  | — |  |  | 189 |  |  | 159 |  |
| Mortgage- and asset-backed securities | 25,313 |  |  | 29 |  |  | (1,987) |  |  | 23,355 |  |  | — |  |  | 667 |  |  | 22,688 |  |
| Subtotal | 118,481 |  |  | 152 |  |  | (5,974) |  |  | 112,659 |  |  | 2,289 |  |  | 22,777 |  |  | 87,593 |  |
| Total (2)(3) | $ | 147,088 |  |  | $ | 261 |  |  | $ | (5,981) |  |  | $ | 141,368 |  |  | $ | 30,299 |  |  | $ | 23,476 |  |  | $ | 87,593 |  |

[0000320193-25-000008:notes:14]
|  | September 28, 2024 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | CurrentMarketableSecurities |  | Non-CurrentMarketableSecurities |
| Cash | $ | 27,199 |  |  | $ | — |  |  | $ | — |  |  | $ | 27,199 |  |  | $ | 27,199 |  |  | $ | — |  |  | $ | — |  |
| Level 1: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 778 |  |  | — |  |  | — |  |  | 778 |  |  | 778 |  |  | — |  |  | — |  |
| Mutual funds | 515 |  |  | 105 |  |  | (3) |  |  | 617 |  |  | — |  |  | 617 |  |  | — |  |
| Subtotal | 1,293 |  |  | 105 |  |  | (3) |  |  | 1,395 |  |  | 778 |  |  | 617 |  |  | — |  |
| Level 2 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 16,150 |  |  | 45 |  |  | (516) |  |  | 15,679 |  |  | 212 |  |  | 4,087 |  |  | 11,380 |  |
| U.S. agency securities | 5,431 |  |  | — |  |  | (272) |  |  | 5,159 |  |  | 155 |  |  | 703 |  |  | 4,301 |  |
| Non-U.S. government securities | 17,959 |  |  | 93 |  |  | (484) |  |  | 17,568 |  |  | 1,158 |  |  | 10,810 |  |  | 5,600 |  |
| Certificates of deposit and time deposits | 873 |  |  | — |  |  | — |  |  | 873 |  |  | 387 |  |  | 478 |  |  | 8 |  |
| Commercial paper | 1,066 |  |  | — |  |  | — |  |  | 1,066 |  |  | 28 |  |  | 1,038 |  |  | — |  |
| Corporate debt securities | 65,622 |  |  | 270 |  |  | (1,953) |  |  | 63,939 |  |  | 26 |  |  | 16,027 |  |  | 47,886 |  |
| Municipal securities | 412 |  |  | — |  |  | (7) |  |  | 405 |  |  | — |  |  | 190 |  |  | 215 |  |
| Mortgage- and asset-backed securities | 24,595 |  |  | 175 |  |  | (1,403) |  |  | 23,367 |  |  | — |  |  | 1,278 |  |  | 22,089 |  |
| Subtotal | 132,108 |  |  | 583 |  |  | (4,635) |  |  | 128,056 |  |  | 1,966 |  |  | 34,611 |  |  | 91,479 |  |
| Total (2)(3) | $ | 160,600 |  |  | $ | 688 |  |  | $ | (4,638) |  |  | $ | 156,650 |  |  | $ | 29,943 |  |  | $ | 35,228 |  |  | $ | 91,479 |  |

[0000320193-25-000008:notes:15]
[same as prior period, unchanged from 0000320193-24-000081:notes:16]

[0000320193-25-000008:notes:16]
(2)As of December 28, 2024 and September 28, 2024, cash and cash equivalents included $126 million and $2.6 billion, respectively, held in escrow and restricted from general use. These restricted cash and cash equivalents are designated to settle the Company’s obligation related to the 2016 European Commission (the “Commission”) decision that Ireland granted state aid to the Company (the “State Aid Decision”), which was confirmed during the fourth quarter of 2024 by the European Court of Justice in a reversal of the 2020 judgment of the European General Court.

[0000320193-25-000008:notes:17]
(3)As of December 28, 2024 and September 28, 2024, current marketable securities included $3.3 billion and $13.2 billion, respectively, held in escrow and restricted from general use. These restricted marketable securities are designated to settle the Company’s obligation related to the State Aid Decision.

[0000320193-25-000008:notes:18]
As of December 28, 2024, 85% of the Company’s non-current marketable debt securities other than mortgage- and asset-backed securities had maturities between 1 and 5 years, 11% between 5 and 10 years, and 4% greater than 10 years. As of December 28, 2024, 13% of the Company’s non-current mortgage- and asset-backed securities had maturities between 1 and 5 years, 10% between 5 and 10 years, and 77% greater than 10 years.

[0000320193-25-000008:notes:19]
[same as prior period, unchanged from 0000320193-24-000081:notes:20]

[0000320193-25-000008:notes:20]
[same as prior period, unchanged from 0000320193-24-000081:notes:21]

[0000320193-25-000008:notes:21]
[same as prior period, unchanged from 0000320193-24-000081:notes:22]

[0000320193-25-000008:notes:22]
[same as prior period, unchanged from 0000320193-24-000081:notes:23]

[0000320193-25-000008:notes:23]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in foreign exchange rates, the Company may use forwards, cross-currency swaps or other instruments. The Company designates these instruments as either cash flow or fair value hedges. As of December 28, 2024, the maximum length of time over which the Company is hedging its exposure to the variability in future cash flows for term debt–related foreign currency transactions is 18 years.

[0000320193-25-000008:notes:24]
[same as prior period, unchanged from 0000320193-24-000081:notes:25]

[0000320193-25-000008:notes:25]
[same as prior period, unchanged from 0000320193-24-000081:notes:26]

[0000320193-25-000008:notes:26]
[same as prior period, unchanged from 0000320193-24-000081:notes:27]

[0000320193-25-000008:notes:27]
The notional amounts of the Company’s outstanding derivative instruments as of December 28, 2024 and September 28, 2024 were as follows (in millions):

[0000320193-25-000008:notes:28]
|  | December 28,2024 |  | September 28,2024 |
| Derivative instruments designated as accounting hedges: |  |  |  |
| Foreign exchange contracts | $ | 47,466 |  |  | $ | 64,069 |  |
| Interest rate contracts | $ | 14,575 |  |  | $ | 14,575 |  |
| Derivative instruments not designated as accounting hedges: |  |  |  |
| Foreign exchange contracts | $ | 96,150 |  |  | $ | 91,493 |  |

[0000320193-25-000008:notes:29]
As of December 28, 2024 and September 28, 2024, the carrying amount of the Company’s current and non-current term debt subject to fair value hedges was $13.3 billion and $13.5 billion, respectively.

[0000320193-25-000008:notes:30]
[same as prior period, unchanged from 0000320193-24-000081:notes:32]

[0000320193-25-000008:notes:31]
[same as prior period, unchanged from 0000320193-24-000081:notes:33]

[0000320193-25-000008:notes:32]
As of December 28, 2024, the Company had two customers that individually represented 10% or more of total trade receivables, which accounted for 18% and 11%. The Company’s third-party cellular network carriers accounted for 33% and 38% of total trade receivables as of December 28, 2024 and September 28, 2024, respectively. The Company requires third-party credit support or collateral from certain customers to limit credit risk.

[0000320193-25-000008:notes:33]
[same as prior period, unchanged from 0000320193-24-000081:notes:35]

[0000320193-25-000008:notes:34]
The Company has non-trade receivables from certain of its manufacturing vendors resulting from the sale of components to these vendors who manufacture subassemblies or assemble final products for the Company. The Company purchases these components directly from suppliers. The Company does not reflect the sale of these components in products net sales. Rather, the Company recognizes any gain on these sales as a reduction of products cost of sales when the related final products are sold by the Company. As of December 28, 2024, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 43% and 24%. As of September 28, 2024, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 44% and 23%.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000320193-25-000008:notes:35]
Condensed Consolidated Financial Statement Details
The following tables show the Company’s condensed consolidated financial statement details as of December 28, 2024 and September 28, 2024 (in millions):

[0000320193-25-000008:notes:36]
Inventories

[0000320193-25-000008:notes:37]
|  | December 28,2024 |  | September 28,2024 |
| Components | $ | 2,792 |  |  | $ | 3,627 |  |
| Finished goods | 4,119 |  |  | 3,659 |  |
| Total inventories | $ | 6,911 |  |  | $ | 7,286 |  |

[0000320193-25-000008:notes:38]
[same as prior period, unchanged from 0000320193-24-000081:notes:38]

[0000320193-25-000008:notes:39]
|  | December 28,2024 |  | September 28,2024 |
| Gross property, plant and equipment | $ | 120,615 |  |  | $ | 119,128 |  |
| Accumulated depreciation | (74,546) |  |  | (73,448) |  |
| Total property, plant and equipment, net | $ | 46,069 |  |  | $ | 45,680 |  |


## us-gaap:DebtDisclosureTextBlock

[0000320193-25-000008:notes:40]
Debt
Commercial Paper

[0000320193-25-000008:notes:41]
The Company issues unsecured short-term promissory notes pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of December 28, 2024 and September 28, 2024, the Company had $2.0 billion and $10.0 billion of commercial paper outstanding, respectively.

[0000320193-25-000008:notes:42]
Term Debt

[0000320193-25-000008:notes:43]
As of December 28, 2024 and September 28, 2024, the Company had outstanding fixed-rate notes with varying maturities for an aggregate carrying amount of $94.8 billion and $96.7 billion, respectively (collectively the “Notes”). As of December 28, 2024 and September 28, 2024, the fair value of the Company’s Notes, based on Level 2 inputs, was $82.7 billion and $88.4 billion, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000320193-25-000008:notes:44]
[same as prior period, unchanged from 0000320193-24-000081:notes:47]

[0000320193-25-000008:notes:45]
During the three months ended December 28, 2024, the Company repurchased 100 million shares of its common stock for $23.3 billion. The Company’s share repurchase program does not obligate the Company to acquire a minimum amount of shares. Under the program, shares may be repurchased in privately negotiated or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000320193-25-000008:notes:46]
[same as prior period, unchanged from 0000320193-24-000081:notes:49]

[0000320193-25-000008:notes:47]
A summary of the Company’s RSU activity and related information for the three months ended December 28, 2024 is as follows:

[0000320193-25-000008:notes:48]
|  | Number ofRSUs(in thousands) |  | Weighted-AverageGrant-Date FairValue Per RSU |
| Balance as of September 28, 2024 | 163,326 |  |  | $ | 158.73 |  |
| RSUs granted | 61,391 |  |  | $ | 228.04 |  |
| RSUs vested | (35,683) |  |  | $ | 147.36 |  |
| RSUs canceled | (2,278) |  |  | $ | 174.77 |  |
| Balance as of December 28, 2024 | 186,756 |  |  | $ | 183.49 |  |

[0000320193-25-000008:notes:49]
The total vesting-date fair value of RSUs was $8.4 billion and $7.7 billion for the three months ended December 28, 2024 and December 30, 2023, respectively.

[0000320193-25-000008:notes:50]
[same as prior period, unchanged from 0000320193-24-000081:notes:53]

[0000320193-25-000008:notes:51]
The following table shows share-based compensation expense and the related income tax benefit included in the Condensed Consolidated Statements of Operations for the three months ended December 28, 2024 and December 30, 2023 (in millions):

[0000320193-25-000008:notes:52]
|  | Three Months Ended |  |  |
|  | December 28,2024 |  | December 30,2023 |  |  |  |  |
| Share-based compensation expense | $ | 3,286 |  |  | $ | 2,997 |  |  |  |  |  |
| Income tax benefit related to share-based compensation expense | $ | (1,332) |  |  | $ | (1,235) |  |  |  |  |  |

[0000320193-25-000008:notes:53]
As of December 28, 2024, the total unrecognized compensation cost related to outstanding RSUs was $29.2 billion, which the Company expects to recognize over a weighted-average period of 2.9 years.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000320193-25-000008:notes:54]
Segment Information and Geographic Data
The following table shows information by reportable segment for the three months ended December 28, 2024 and December 30, 2023 (in millions):

[0000320193-25-000008:notes:55]
|  | Three Months Ended |  |  |
|  | December 28,2024 |  | December 30,2023 |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |
| Net sales | $ | 52,648 |  |  | $ | 50,430 |  |  |  |  |  |
| Operating income | $ | 21,509 |  |  | $ | 20,357 |  |  |  |  |  |
| Europe: |  |  |  |  |  |  |  |
| Net sales | $ | 33,861 |  |  | $ | 30,397 |  |  |  |  |  |
| Operating income | $ | 14,607 |  |  | $ | 12,711 |  |  |  |  |  |
| Greater China: |  |  |  |  |  |  |  |
| Net sales | $ | 18,513 |  |  | $ | 20,819 |  |  |  |  |  |
| Operating income | $ | 8,160 |  |  | $ | 8,622 |  |  |  |  |  |
| Japan: |  |  |  |  |  |  |  |
| Net sales | $ | 8,987 |  |  | $ | 7,767 |  |  |  |  |  |
| Operating income | $ | 4,314 |  |  | $ | 3,819 |  |  |  |  |  |
| Rest of Asia Pacific: |  |  |  |  |  |  |  |
| Net sales | $ | 10,291 |  |  | $ | 10,162 |  |  |  |  |  |
| Operating income | $ | 4,584 |  |  | $ | 4,579 |  |  |  |  |  |

[0000320193-25-000008:notes:56]
A reconciliation of the Company’s segment operating income to the Condensed Consolidated Statements of Operations for the three months ended December 28, 2024 and December 30, 2023 is as follows (in millions):

[0000320193-25-000008:notes:57]
|  | Three Months Ended |  |  |
|  | December 28,2024 |  | December 30,2023 |  |  |  |  |
| Segment operating income | $ | 53,174 |  |  | $ | 50,088 |  |  |  |  |  |
| Research and development expense | (8,268) |  |  | (7,696) |  |  |  |  |  |
| Other corporate expenses, net | (2,074) |  |  | (2,019) |  |  |  |  |  |
| Total operating income | $ | 42,832 |  |  | $ | 40,373 |  |  |  |  |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0000320193-25-000008:notes:58]
On November 6, 2024, Luca Maestri, the Company’s former Senior Vice President and Chief Financial Officer, and current Vice President, Corporate Services, entered into a trading plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act. The plan provides for the sale, subject to certain price limits, of shares vesting between April 1, 2025 and October 15, 2025, pursuant to certain equity awards granted to Mr. Maestri, excluding any shares withheld by the Company to satisfy income tax withholding and remittance obligations. Mr. Maestri’s plan will expire on December 31, 2025, subject to early termination in accordance with the terms of the plan.

[0000320193-25-000008:notes:59]
On November 25, 2024, Kate Adams, the Company’s Senior Vice President, General Counsel and Secretary, entered into a trading plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act. The plan provides for the sale of shares vesting between April 1, 2025 and October 1, 2025, pursuant to certain equity awards granted to Ms. Adams, excluding any shares withheld by the Company to satisfy income tax withholding and remittance obligations. Ms. Adam’s plan will expire on November 1, 2025, subject to early termination in accordance with the terms of the plan.
