# AAPL 10-Q controls and the auditor's report


## item_4_controls

[0000320193-25-000008:item_4_controls:1]
Item 4.    Controls and Procedures

[0000320193-25-000008:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0000320193-25-000008:item_4_controls:3]
Based on an evaluation under the supervision and with the participation of the Company’s management, the Company’s principal executive officer and principal financial officer have concluded that the Company’s disclosure controls and procedures as defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act were effective as of December 28, 2024 to provide reasonable assurance that information required to be disclosed by the Company in reports that it files or submits under the Exchange Act is (i) recorded, processed, summarized and reported within the time periods specified in the SEC rules and forms and (ii) accumulated and communicated to the Company’s management, including its principal executive officer and principal financial officer, as appropriate to allow timely decisions regarding required disclosure.

[0000320193-25-000008:item_4_controls:4]
Apple Inc. | Q1 2025 Form 10-Q | 17

[0000320193-25-000008:item_4_controls:5]
Changes in Internal Control over Financial Reporting

[0000320193-25-000008:item_4_controls:6]
There were no changes in the Company’s internal control over financial reporting during the first quarter of 2025, which were identified in connection with management’s evaluation required by paragraph (d) of Rules 13a-15 and 15d-15 under the Exchange Act, that have materially affected, or are reasonably likely to materially affect, the Company’s internal control over financial reporting.
