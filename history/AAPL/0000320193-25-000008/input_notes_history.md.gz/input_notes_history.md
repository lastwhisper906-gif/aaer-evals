# AAPL note change history — 0000320193-24-000081 → 0000320193-25-000008


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2025-01-31):
[0000320193-25-000008:note_history:1]
The Company’s fiscal year is the 52- or 53-week period that ends on the last Saturday of September. An additional week is included in the first fiscal quarter every five or six years to realign the Company’s fiscal quarters with calendar quarters. The Company’s fiscal years 2025 and 2024 span 52 weeks each. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in September and the associated quarters, months and periods of those fiscal years.

- removed (2025-01-31):
[0000320193-24-000081:note_history:2]
The Company’s fiscal year is the 52- or 53-week period that ends on the last Saturday of September. An additional week is included in the first fiscal quarter every five or six years to realign the Company’s fiscal quarters with calendar quarters, which occurred in the first fiscal quarter of 2023. The Company’s fiscal years 2024 and 2023 span 52 and 53 weeks, respectively. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in September and the associated quarters, months and periods of those fiscal years.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-01-31):
[0000320193-25-000008:note_history:3]
The Company issues unsecured short-term promissory notes pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of December 28, 2024 and September 28, 2024, the Company had $2.0 billion and $10.0 billion of commercial paper outstanding, respectively.
  (was, 2024-08-02, similarity 0.7862):
[0000320193-24-000081:note_history:3]
The Company issues unsecured short-term promissory notes pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of June 29, 2024 and September 30, 2023, the Company had $3.0 billion and $6.0 billion of commercial paper outstanding, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of commercial paper for the nine months ended June 29, 2024 and July 1, 2023 (in millions):

- changed (2025-01-31):
[0000320193-25-000008:note_history:4]
As of December 28, 2024 and September 28, 2024, the Company had outstanding fixed-rate notes with varying maturities for an aggregate carrying amount of $94.8 billion and $96.7 billion, respectively (collectively the “Notes”). As of December 28, 2024 and September 28, 2024, the fair value of the Company’s Notes, based on Level 2 inputs, was $82.7 billion and $88.4 billion, respectively.
  (was, 2024-08-02, similarity 0.9658):
[0000320193-24-000081:note_history:4]
As of June 29, 2024 and September 30, 2023, the Company had outstanding fixed-rate notes with varying maturities for an aggregate carrying amount of $98.3 billion and $105.1 billion, respectively (collectively the “Notes”). As of June 29, 2024 and September 30, 2023, the fair value of the Company’s Notes, based on Level 2 inputs, was $86.2 billion and $90.8 billion, respectively.

- removed (2025-01-31):
[0000320193-24-000081:note_history:5]
|  | Nine Months Ended |
|  | June 29,2024 |  | July 1,2023 |
| Maturities 90 days or less: |  |  |  |
| Repayments of commercial paper, net | $ | (2,985) |  |  | $ | (3,326) |  |
| Maturities greater than 90 days: |  |  |  |
| Repayments of commercial paper | — |  |  | (2,645) |  |
| Total repayments of commercial paper, net | $ | (2,985) |  |  | $ | (5,971) |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-01-31):
[0000320193-25-000008:note_history:6]
Net sales disaggregated by significant products and services for the three months ended December 28, 2024 and December 30, 2023 were as follows (in millions):
  (was, 2024-08-02, similarity 0.8721):
[0000320193-24-000081:note_history:6]
Net sales disaggregated by significant products and services for the three- and nine-month periods ended June 29, 2024 and July 1, 2023 were as follows (in millions):

- changed (2025-01-31):
[0000320193-25-000008:note_history:7]
|  | Three Months Ended |  |  |
|  | December 28,2024 |  | December 30,2023 |  |  |  |  |
| iPhone® | $ | 69,138 |  |  | $ | 69,702 |  |  |  |  |  |
| Mac® | 8,987 |  |  | 7,780 |  |  |  |  |  |
| iPad® | 8,088 |  |  | 7,023 |  |  |  |  |  |
| Wearables, Home and Accessories | 11,747 |  |  | 11,953 |  |  |  |  |  |
| Services | 26,340 |  |  | 23,117 |  |  |  |  |  |
| Total net sales | $ | 124,300 |  |  | $ | 119,575 |  |  |  |  |  |
  (was, 2024-08-02, similarity 0.7444):
[0000320193-24-000081:note_history:7]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29,2024 |  | July 1,2023 |  | June 29,2024 |  | July 1,2023 |
| iPhone® | $ | 39,296 |  |  | $ | 39,669 |  |  | $ | 154,961 |  |  | $ | 156,778 |  |
| Mac® | 7,009 |  |  | 6,840 |  |  | 22,240 |  |  | 21,743 |  |
| iPad® | 7,162 |  |  | 5,791 |  |  | 19,744 |  |  | 21,857 |  |
| Wearables, Home and Accessories | 8,097 |  |  | 8,284 |  |  | 27,963 |  |  | 30,523 |  |
| Services | 24,213 |  |  | 21,213 |  |  | 71,197 |  |  | 62,886 |  |
| Total net sales | $ | 85,777 |  |  | $ | 81,797 |  |  | $ | 296,105 |  |  | $ | 293,787 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-01-31):
[0000320193-25-000008:note_history:8]
Revenue
Net sales disaggregated by significant products and services for the three months ended December 28, 2024 and December 30, 2023 were as follows (in millions):
  (was, 2024-08-02, similarity 0.8785):
[0000320193-24-000081:note_history:8]
Revenue
Net sales disaggregated by significant products and services for the three- and nine-month periods ended June 29, 2024 and July 1, 2023 were as follows (in millions):

- changed (2025-01-31):
[0000320193-25-000008:note_history:9]
|  | Three Months Ended |  |  |
|  | December 28,2024 |  | December 30,2023 |  |  |  |  |
| iPhone® | $ | 69,138 |  |  | $ | 69,702 |  |  |  |  |  |
| Mac® | 8,987 |  |  | 7,780 |  |  |  |  |  |
| iPad® | 8,088 |  |  | 7,023 |  |  |  |  |  |
| Wearables, Home and Accessories | 11,747 |  |  | 11,953 |  |  |  |  |  |
| Services | 26,340 |  |  | 23,117 |  |  |  |  |  |
| Total net sales | $ | 124,300 |  |  | $ | 119,575 |  |  |  |  |  |
  (was, 2024-08-02, similarity 0.7444):
[0000320193-24-000081:note_history:9]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29,2024 |  | July 1,2023 |  | June 29,2024 |  | July 1,2023 |
| iPhone® | $ | 39,296 |  |  | $ | 39,669 |  |  | $ | 154,961 |  |  | $ | 156,778 |  |
| Mac® | 7,009 |  |  | 6,840 |  |  | 22,240 |  |  | 21,743 |  |
| iPad® | 7,162 |  |  | 5,791 |  |  | 19,744 |  |  | 21,857 |  |
| Wearables, Home and Accessories | 8,097 |  |  | 8,284 |  |  | 27,963 |  |  | 30,523 |  |
| Services | 24,213 |  |  | 21,213 |  |  | 71,197 |  |  | 62,886 |  |
| Total net sales | $ | 85,777 |  |  | $ | 81,797 |  |  | $ | 296,105 |  |  | $ | 293,787 |  |

- added (2025-01-31):
[0000320193-25-000008:note_history:10]
Total net sales include $3.7 billion of revenue recognized in the three months ended December 28, 2024 that was included in deferred revenue as of September 28, 2024 and $3.5 billion of revenue recognized in the three months ended December 30, 2023 that was included in deferred revenue as of September 30, 2023.

- changed (2025-01-31):
[0000320193-25-000008:note_history:11]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 10, “Segment Information and Geographic Data” for the three months ended December 28, 2024 and December 30, 2023, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.
  (was, 2024-08-02, similarity 0.8715):
[0000320193-24-000081:note_history:11]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 11, “Segment Information and Geographic Data” for the three- and nine-month periods ended June 29, 2024 and July 1, 2023, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.

- added (2025-01-31):
[0000320193-25-000008:note_history:12]
As of December 28, 2024 and September 28, 2024, the Company had total deferred revenue of $13.2 billion and $12.8 billion, respectively. As of December 28, 2024, the Company expects 64% of total deferred revenue to be realized in less than a year, 25% within one-to-two years, 9% within two-to-three years and 2% in greater than three years.

- removed (2025-01-31):
[0000320193-24-000081:note_history:13]
Total net sales include $3.4 billion of revenue recognized in the three months ended June 29, 2024 that was included in deferred revenue as of March 30, 2024, $3.3 billion of revenue recognized in the three months ended July 1, 2023 that was included in deferred revenue as of April 1, 2023, $6.5 billion of revenue recognized in the nine months ended June 29, 2024 that was included in deferred revenue as of September 30, 2023, and $7.0 billion of revenue recognized in the nine months ended July 1, 2023 that was included in deferred revenue as of September 24, 2022.

- removed (2025-01-31):
[0000320193-24-000081:note_history:14]
As of June 29, 2024 and September 30, 2023, the Company had total deferred revenue of $12.5 billion and $12.1 billion, respectively. As of June 29, 2024, the Company expects 64% of total deferred revenue to be realized in less than a year, 25% within one-to-two years, 9% within two-to-three years and 2% in greater than three years.
