# AAPL MD&A — 0000320193-25-000008


## mdna

[0000320193-25-000008:mdna:1]
[same as prior period, unchanged from 0000320193-24-000081:mdna:1]

[0000320193-25-000008:mdna:2]
[same as prior period, unchanged from 0000320193-24-000081:mdna:2]

[0000320193-25-000008:mdna:3]
The following discussion should be read in conjunction with the 2024 Form 10-K filed with the U.S. Securities and Exchange Commission (the “SEC”) and the condensed consolidated financial statements and accompanying notes included in Part I, Item 1 of this Form 10-Q.

[0000320193-25-000008:mdna:4]
[same as prior period, unchanged from 0000320193-24-000081:mdna:4]

[0000320193-25-000008:mdna:5]
[same as prior period, unchanged from 0000320193-24-000081:mdna:5]

[0000320193-25-000008:mdna:6]
[same as prior period, unchanged from 0000320193-24-000081:mdna:6]

[0000320193-25-000008:mdna:7]
[same as prior period, unchanged from 0000320193-24-000081:mdna:7]

[0000320193-25-000008:mdna:8]
During the first quarter of 2025, the Company announced the following product updates:

[0000320193-25-000008:mdna:9]
•MacBook Pro®

[0000320193-25-000008:mdna:10]
•Mac mini®

[0000320193-25-000008:mdna:11]
•iMac®

[0000320193-25-000008:mdna:12]
•iPad mini®

[0000320193-25-000008:mdna:13]
[same as prior period, unchanged from 0000320193-24-000081:mdna:15]

[0000320193-25-000008:mdna:14]
[same as prior period, unchanged from 0000320193-24-000081:mdna:16]

[0000320193-25-000008:mdna:15]
[same as prior period, unchanged from 0000320193-24-000081:mdna:17]

[0000320193-25-000008:mdna:16]
The following table shows net sales by reportable segment for the three months ended December 28, 2024 and December 30, 2023 (dollars in millions):

[0000320193-25-000008:mdna:17]
|  | Three Months Ended |  |  |
|  | December 28,2024 |  | December 30,2023 |  | Change |  |  |  |  |  |  |
| Americas | $ | 52,648 |  |  | $ | 50,430 |  |  | 4 | % |  |  |  |  |  |  |
| Europe | 33,861 |  |  | 30,397 |  |  | 11 | % |  |  |  |  |  |  |
| Greater China | 18,513 |  |  | 20,819 |  |  | (11) | % |  |  |  |  |  |  |
| Japan | 8,987 |  |  | 7,767 |  |  | 16 | % |  |  |  |  |  |  |
| Rest of Asia Pacific | 10,291 |  |  | 10,162 |  |  | 1 | % |  |  |  |  |  |  |
| Total net sales | $ | 124,300 |  |  | $ | 119,575 |  |  | 4 | % |  |  |  |  |  |  |

[0000320193-25-000008:mdna:18]
[same as prior period, unchanged from 0000320193-24-000081:mdna:20]

[0000320193-25-000008:mdna:19]
Americas net sales increased during the first quarter of 2025 compared to the same quarter in 2024 due primarily to higher net sales of Services and iPhone. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable year-over-year impact on Americas net sales during the first quarter of 2025.

[0000320193-25-000008:mdna:20]
[same as prior period, unchanged from 0000320193-24-000081:mdna:22]

[0000320193-25-000008:mdna:21]
Europe net sales increased during the first quarter of 2025 compared to the same quarter in 2024 due primarily to higher net sales of Services and iPhone. The strength in foreign currencies relative to the U.S. dollar had a net favorable year-over-year impact on Europe net sales during the first quarter of 2025.

[0000320193-25-000008:mdna:22]
[same as prior period, unchanged from 0000320193-24-000081:mdna:24]

[0000320193-25-000008:mdna:23]
Greater China net sales decreased during the first quarter of 2025 compared to the same quarter in 2024 due to lower net sales of iPhone. The strength in the renminbi relative to the U.S. dollar had a favorable year-over-year impact on Greater China net sales during the first quarter of 2025.

[0000320193-25-000008:mdna:24]
[same as prior period, unchanged from 0000320193-24-000081:mdna:26]

[0000320193-25-000008:mdna:25]
Japan net sales increased during the first quarter of 2025 compared to the same quarter in 2024 due primarily to higher net sales of iPhone and Services.

[0000320193-25-000008:mdna:26]
[same as prior period, unchanged from 0000320193-24-000081:mdna:28]

[0000320193-25-000008:mdna:27]
Rest of Asia Pacific net sales were relatively flat during the first quarter of 2025 compared to the same quarter in 2024.

[0000320193-25-000008:mdna:28]
[same as prior period, unchanged from 0000320193-24-000081:mdna:30]

[0000320193-25-000008:mdna:29]
The following table shows net sales by category for the three months ended December 28, 2024 and December 30, 2023 (dollars in millions):

[0000320193-25-000008:mdna:30]
|  | Three Months Ended |  |  |
|  | December 28,2024 |  | December 30,2023 |  | Change |  |  |  |  |  |  |
| iPhone | $ | 69,138 |  |  | $ | 69,702 |  |  | (1) | % |  |  |  |  |  |  |
| Mac | 8,987 |  |  | 7,780 |  |  | 16 | % |  |  |  |  |  |  |
| iPad | 8,088 |  |  | 7,023 |  |  | 15 | % |  |  |  |  |  |  |
| Wearables, Home and Accessories | 11,747 |  |  | 11,953 |  |  | (2) | % |  |  |  |  |  |  |
| Services | 26,340 |  |  | 23,117 |  |  | 14 | % |  |  |  |  |  |  |
| Total net sales | $ | 124,300 |  |  | $ | 119,575 |  |  | 4 | % |  |  |  |  |  |  |

[0000320193-25-000008:mdna:31]
[same as prior period, unchanged from 0000320193-24-000081:mdna:33]

[0000320193-25-000008:mdna:32]
iPhone net sales were relatively flat during the first quarter of 2025 compared to the same quarter in 2024.

[0000320193-25-000008:mdna:33]
[same as prior period, unchanged from 0000320193-24-000081:mdna:35]

[0000320193-25-000008:mdna:34]
Mac net sales increased during the first quarter of 2025 compared to the same quarter in 2024 due primarily to higher net sales of laptops.

[0000320193-25-000008:mdna:35]
[same as prior period, unchanged from 0000320193-24-000081:mdna:37]

[0000320193-25-000008:mdna:36]
iPad net sales increased during the first quarter of 2025 compared to the same quarter in 2024 due primarily to higher net sales of iPad Air®.

[0000320193-25-000008:mdna:37]
[same as prior period, unchanged from 0000320193-24-000081:mdna:39]

[0000320193-25-000008:mdna:38]
Wearables, Home and Accessories net sales decreased during the first quarter of 2025 compared to the same quarter in 2024 due primarily to lower net sales of Wearables.

[0000320193-25-000008:mdna:39]
[same as prior period, unchanged from 0000320193-24-000081:mdna:41]

[0000320193-25-000008:mdna:40]
Services net sales increased during the first quarter of 2025 compared to the same quarter in 2024 due primarily to higher net sales from advertising, the App Store® and cloud services.

[0000320193-25-000008:mdna:41]
[same as prior period, unchanged from 0000320193-24-000081:mdna:43]

[0000320193-25-000008:mdna:42]
Products and Services gross margin and gross margin percentage for the three months ended December 28, 2024 and December 30, 2023 were as follows (dollars in millions):

[0000320193-25-000008:mdna:43]
|  | Three Months Ended |  |  |
|  | December 28,2024 |  | December 30,2023 |  |  |  |  |
| Gross margin: |  |  |  |  |  |  |  |
| Products | $ | 38,513 |  |  | $ | 38,018 |  |  |  |  |  |
| Services | 19,762 |  |  | 16,837 |  |  |  |  |  |
| Total gross margin | $ | 58,275 |  |  | $ | 54,855 |  |  |  |  |  |

[0000320193-25-000008:mdna:44]
| Gross margin percentage: |  |  |  |  |  |  |  |
| Products | 39.3 | % |  | 39.4 | % |  |  |  |  |
| Services | 75.0 | % |  | 72.8 | % |  |  |  |  |
| Total gross margin percentage | 46.9 | % |  | 45.9 | % |  |  |  |  |

[0000320193-25-000008:mdna:45]
[same as prior period, unchanged from 0000320193-24-000081:mdna:47]

[0000320193-25-000008:mdna:46]
Products gross margin and Products gross margin percentage were relatively flat during the first quarter of 2025 compared to the same quarter in 2024.

[0000320193-25-000008:mdna:47]
[same as prior period, unchanged from 0000320193-24-000081:mdna:50]

[0000320193-25-000008:mdna:48]
Services gross margin increased during the first quarter of 2025 compared to the same quarter in 2024 due primarily to higher Services net sales and a different Services mix.

[0000320193-25-000008:mdna:49]
Services gross margin percentage increased during the first quarter of 2025 compared to the same quarter in 2024 due primarily to a different Services mix, partially offset by higher Services costs.

[0000320193-25-000008:mdna:50]
The Company’s future gross margins can be impacted by a variety of factors, as discussed in Part I, Item 1A of the 2024 Form 10-K and Part II, Item 1A of this Form 10-Q, in each case under the heading “Risk Factors.” As a result, the Company believes, in general, gross margins will be subject to volatility and downward pressure.

[0000320193-25-000008:mdna:51]
[same as prior period, unchanged from 0000320193-24-000081:mdna:54]

[0000320193-25-000008:mdna:52]
Operating expenses for the three months ended December 28, 2024 and December 30, 2023 were as follows (dollars in millions):

[0000320193-25-000008:mdna:53]
|  | Three Months Ended |  |  |
|  | December 28,2024 |  | December 30,2023 |  |  |  |  |
| Research and development | $ | 8,268 |  |  | $ | 7,696 |  |  |  |  |  |
| Percentage of total net sales | 7 | % |  | 6 | % |  |  |  |  |
| Selling, general and administrative | $ | 7,175 |  |  | $ | 6,786 |  |  |  |  |  |
| Percentage of total net sales | 6 | % |  | 6 | % |  |  |  |  |
| Total operating expenses | $ | 15,443 |  |  | $ | 14,482 |  |  |  |  |  |
| Percentage of total net sales | 12 | % |  | 12 | % |  |  |  |  |

[0000320193-25-000008:mdna:54]
[same as prior period, unchanged from 0000320193-24-000081:mdna:57]

[0000320193-25-000008:mdna:55]
The growth in research and development expense during the first quarter of 2025 compared to the same quarter in 2024 was driven primarily by increases in headcount-related expenses and infrastructure-related costs.

[0000320193-25-000008:mdna:56]
[same as prior period, unchanged from 0000320193-24-000081:mdna:59]

[0000320193-25-000008:mdna:57]
The growth in selling, general and administrative expense during the first quarter of 2025 compared to the same quarter in 2024 was driven primarily by higher variable selling expenses and increases in headcount-related expenses.

[0000320193-25-000008:mdna:58]
[same as prior period, unchanged from 0000320193-24-000081:mdna:61]

[0000320193-25-000008:mdna:59]
Provision for income taxes, effective tax rate and statutory federal income tax rate for the three months ended December 28, 2024 and December 30, 2023 were as follows (dollars in millions):

[0000320193-25-000008:mdna:60]
|  | Three Months Ended |  |  |
|  | December 28,2024 |  | December 30,2023 |  |  |  |  |
| Provision for income taxes | $ | 6,254 |  |  | $ | 6,407 |  |  |  |  |  |
| Effective tax rate | 14.7 | % |  | 15.9 | % |  |  |  |  |
| Statutory federal income tax rate | 21 | % |  | 21 | % |  |  |  |  |

[0000320193-25-000008:mdna:61]
The Company’s effective tax rate for the first quarter of 2025 was lower than the statutory federal income tax rate due primarily to a lower effective tax rate on foreign earnings, tax benefits from share-based compensation, the impact of foreign currency loss regulations issued by the U.S. Department of the Treasury in December 2024, and the tax impact from foreign currency revaluations related to the State Aid Decision.

[0000320193-25-000008:mdna:62]
The Company’s effective tax rate for the first quarter of 2025 was lower compared to the same quarter in 2024 due primarily to the impact of foreign currency loss regulations issued by the U.S. Department of the Treasury in December 2024 and the tax impact from foreign currency revaluations related to the State Aid Decision, partially offset by a higher effective tax rate on foreign earnings.

[0000320193-25-000008:mdna:63]
[same as prior period, unchanged from 0000320193-24-000081:mdna:66]

[0000320193-25-000008:mdna:64]
The Company believes its balances of unrestricted cash, cash equivalents and marketable securities, along with cash generated by ongoing operations and continued access to debt markets, will be sufficient to satisfy its cash requirements and capital return program over the next 12 months and beyond.

[0000320193-25-000008:mdna:65]
The Company’s contractual cash requirements have not changed materially since the 2024 Form 10-K, except for commercial paper, manufacturing purchase obligations and the State Aid Decision tax payable.

[0000320193-25-000008:mdna:66]
Commercial Paper

[0000320193-25-000008:mdna:67]
The Company issues unsecured short-term promissory notes pursuant to a commercial paper program. As of December 28, 2024, the Company had $2.0 billion of commercial paper outstanding, which was payable within 12 months.

[0000320193-25-000008:mdna:68]
[same as prior period, unchanged from 0000320193-24-000081:mdna:69]

[0000320193-25-000008:mdna:69]
The Company utilizes several outsourcing partners to manufacture subassemblies for the Company’s products and to perform final assembly and testing of finished products. The Company also obtains individual components for its products from a wide variety of individual suppliers. As of December 28, 2024, the Company had manufacturing purchase obligations of $39.8 billion, which were payable within 12 months.

[0000320193-25-000008:mdna:70]
State Aid Decision Tax Payable

[0000320193-25-000008:mdna:71]
During the first quarter of 2025, the Company paid €11.0 billion or $11.9 billion to Ireland in connection with the State Aid Decision. As of December 28, 2024, the Company had a remaining obligation to pay €3.3 billion or $3.4 billion, which was expected to be paid within 12 months. The funds necessary to settle the remaining obligation were held in escrow as of December 28, 2024, and restricted from general use.

[0000320193-25-000008:mdna:72]
[same as prior period, unchanged from 0000320193-24-000081:mdna:71]

[0000320193-25-000008:mdna:73]
In addition to its contractual cash requirements, the Company has an authorized share repurchase program. The program does not obligate the Company to acquire a minimum amount of shares. As of December 28, 2024, the Company’s quarterly cash dividend was $0.25 per share. The Company intends to increase its dividend on an annual basis, subject to declaration by the Board of Directors.

[0000320193-25-000008:mdna:74]
During the first quarter of 2025, the Company repurchased $23.3 billion of its common stock and paid dividends and dividend equivalents of $3.9 billion.

[0000320193-25-000008:mdna:75]
[same as prior period, unchanged from 0000320193-24-000081:mdna:74]

[0000320193-25-000008:mdna:76]
Disaggregation of Income Statement Expenses

[0000320193-25-000008:mdna:77]
In November 2024, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) No. 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses (“ASU 2024-03”) and in January 2025, the FASB issued ASU No. 2025-01, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date, which clarified the effective date of ASU 2024-03. ASU 2024-03 will require the Company to disclose the amounts of purchases of inventory, employee compensation, depreciation and intangible asset amortization, as applicable, included in certain expense captions in the Consolidated Statements of Operations, as well as qualitatively describe remaining amounts included in those captions. ASU 2024-03 will also require the Company to disclose both the amount and the Company’s definition of selling expenses. The Company will adopt ASU 2024-03 in its fourth quarter of 2028 using a prospective transition method.

[0000320193-25-000008:mdna:78]
[same as prior period, unchanged from 0000320193-24-000081:mdna:75]

[0000320193-25-000008:mdna:79]
In December 2023, the FASB issued ASU No. 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures (“ASU 2023-09”), which will require the Company to disclose specified additional information in its income tax rate reconciliation and provide additional information for reconciling items that meet a quantitative threshold. ASU 2023-09 will also require the Company to disaggregate its income taxes paid disclosure by federal, state and foreign taxes, with further disaggregation required for significant individual jurisdictions. The Company will adopt ASU 2023-09 in its fourth quarter of 2026 using a prospective transition method.

[0000320193-25-000008:mdna:80]
[same as prior period, unchanged from 0000320193-24-000081:mdna:77]

[0000320193-25-000008:mdna:81]
In November 2023, the FASB issued ASU No. 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures (“ASU 2023-07”), which will require the Company to disclose segment expenses that are significant and regularly provided to the Company’s chief operating decision maker (“CODM”). In addition, ASU 2023-07 will require the Company to disclose the title and position of its CODM and how the CODM uses segment profit or loss information in assessing segment performance and deciding how to allocate resources. The Company will adopt ASU 2023-07 in its fourth quarter of 2025 using a retrospective transition method.

[0000320193-25-000008:mdna:82]
[same as prior period, unchanged from 0000320193-24-000081:mdna:79]

[0000320193-25-000008:mdna:83]
The preparation of financial statements and related disclosures in conformity with GAAP and the Company’s discussion and analysis of its financial condition and operating results require the Company’s management to make judgments, assumptions and estimates that affect the amounts reported. Note 1, “Summary of Significant Accounting Policies” of the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Form 10-Q and in the Notes to Consolidated Financial Statements in Part II, Item 8 of the 2024 Form 10-K describe the significant accounting policies and methods used in the preparation of the Company’s condensed consolidated financial statements. There have been no material changes to the Company’s critical accounting estimates since the 2024 Form 10-K.
