# AAPL MD&A — 0000320193-22-000007


## mdna

[0000320193-22-000007:mdna:1]
[same as prior period, unchanged from 0000320193-21-000065:mdna:1]

[0000320193-22-000007:mdna:2]
[same as prior period, unchanged from 0000320193-21-000065:mdna:2]

[0000320193-22-000007:mdna:3]
The following discussion should be read in conjunction with the 2021 Form 10-K filed with the U.S. Securities and Exchange Commission (the “SEC”) and the condensed consolidated financial statements and accompanying notes included in Part I, Item 1 of this Form 10-Q.

[0000320193-22-000007:mdna:4]
[same as prior period, unchanged from 0000320193-21-000065:mdna:4]

[0000320193-22-000007:mdna:5]
The Company periodically provides certain information for investors on its corporate website, www.apple.com, and its investor relations website, investor.apple.com. This includes press releases and other information about financial performance, information on environmental, social and corporate governance matters, and details related to the Company’s annual meeting of shareholders. The information contained on the websites referenced in this Form 10-Q is not incorporated by reference into this filing. Further, the Company’s references to website URLs are intended to be inactive textual references only.

[0000320193-22-000007:mdna:6]
[same as prior period, unchanged from 0000320193-21-000065:mdna:6]

[0000320193-22-000007:mdna:7]
[same as prior period, unchanged from 0000320193-21-000065:mdna:7]

[0000320193-22-000007:mdna:8]
[same as prior period, unchanged from 0000320193-21-000065:mdna:8]

[0000320193-22-000007:mdna:9]
[same as prior period, unchanged from 0000320193-21-000065:mdna:9]

[0000320193-22-000007:mdna:10]
The COVID-19 pandemic has had, and continues to have, a significant impact around the world, prompting governments and businesses to take unprecedented measures, such as restrictions on travel and business operations, temporary closures of businesses, and quarantine and shelter-in-place orders. The COVID-19 pandemic has at times significantly curtailed global economic activity and caused significant volatility and disruption in global financial markets. The COVID-19 pandemic and the measures taken by many countries in response have affected and could in the future materially impact the Company’s business, results of operations and financial condition, as well as the price of the Company’s stock.

[0000320193-22-000007:mdna:11]
During the first quarter of 2022, aspects of the Company’s business continued to be affected by the COVID-19 pandemic, with a significant number of the Company’s employees working remotely and certain of the Company’s retail stores operating at limited capacity or temporarily closing at various times. The Company has reopened substantially all of its other facilities, subject to operating restrictions to protect public health and the health and safety of employees, and it continues to work on safely reopening the remainder of its facilities, subject to local rules and regulations. At times, certain of the Company’s component suppliers and logistical service providers have experienced disruptions, resulting in supply shortages that affected sales worldwide. Similar impacts or other disruptions could occur in the future.

[0000320193-22-000007:mdna:12]
The extent of the continuing impact of the COVID-19 pandemic on the Company’s operational and financial performance is uncertain and will depend on many factors outside the Company’s control, including the timing, extent, trajectory and duration of the pandemic, the emergence of new variants, the development, availability, distribution and effectiveness of vaccines and treatments, the imposition of protective public safety measures, and the impact of the pandemic on the global economy and demand for consumer products. Refer to Part I, Item 1A of the 2021 Form 10-K under the heading “Risk Factors” for more information.

[0000320193-22-000007:mdna:13]
First Quarter Fiscal 2022 Highlights

[0000320193-22-000007:mdna:14]
Total net sales increased 11% or $12.5 billion during the first quarter of 2022 compared to the same quarter in 2021, driven primarily by growth in iPhone, Services and Mac.

[0000320193-22-000007:mdna:15]
During the first quarter of 2022, the Company released the following new products:

[0000320193-22-000007:mdna:16]
•MacBook Pro®, available in 14- and 16-inch models and powered by an Apple M1 Pro chip or an Apple M1 Max chip;

[0000320193-22-000007:mdna:17]
•Third generation of AirPods; and

[0000320193-22-000007:mdna:18]
•Apple Watch Series 7.

[0000320193-22-000007:mdna:19]
The Company repurchased $20.4 billion of its common stock and paid dividends and dividend equivalents of $3.7 billion during the first quarter of 2022.

[0000320193-22-000007:mdna:20]
[same as prior period, unchanged from 0000320193-21-000065:mdna:24]

[0000320193-22-000007:mdna:21]
The following table shows net sales by category for the three months ended December 25, 2021 and December 26, 2020 (dollars in millions):

[0000320193-22-000007:mdna:22]
|  | Three Months Ended |  |  |
|  | December 25,2021 |  | December 26,2020 |  | Change |  |  |  |  |  |  |
| Net sales by category: |  |  |  |  |  |  |  |  |  |  |  |
| iPhone (1) | $ | 71,628 |  |  | $ | 65,597 |  |  | 9 | % |  |  |  |  |  |  |
| Mac (1) | 10,852 |  |  | 8,675 |  |  | 25 | % |  |  |  |  |  |  |
| iPad (1) | 7,248 |  |  | 8,435 |  |  | (14) | % |  |  |  |  |  |  |
| Wearables, Home and Accessories (1)(2) | 14,701 |  |  | 12,971 |  |  | 13 | % |  |  |  |  |  |  |
| Services (3) | 19,516 |  |  | 15,761 |  |  | 24 | % |  |  |  |  |  |  |
| Total net sales | $ | 123,945 |  |  | $ | 111,439 |  |  | 11 | % |  |  |  |  |  |  |

[0000320193-22-000007:mdna:23]
[same as prior period, unchanged from 0000320193-21-000065:mdna:27]

[0000320193-22-000007:mdna:24]
(2)Wearables, Home and Accessories net sales include sales of AirPods, Apple TV, Apple Watch, Beats products, HomePod mini, iPod touch and accessories.

[0000320193-22-000007:mdna:25]
(3)Services net sales include sales from the Company’s advertising, AppleCare, cloud, digital content, payment and other services. Services net sales also include amortization of the deferred value of services bundled in the sales price of certain products.

[0000320193-22-000007:mdna:26]
[same as prior period, unchanged from 0000320193-21-000065:mdna:30]

[0000320193-22-000007:mdna:27]
iPhone net sales increased during the first quarter of 2022 compared to the same quarter in 2021 due primarily to higher net sales from the Company’s new iPhone models launched in the fourth quarter of 2021 and a different mix of iPhone sales.

[0000320193-22-000007:mdna:28]
[same as prior period, unchanged from 0000320193-21-000065:mdna:32]

[0000320193-22-000007:mdna:29]
Mac net sales increased during the first quarter of 2022 compared to the same quarter in 2021 due primarily to higher net sales of MacBook Pro and MacBook Air®.

[0000320193-22-000007:mdna:30]
[same as prior period, unchanged from 0000320193-21-000065:mdna:34]

[0000320193-22-000007:mdna:31]
iPad net sales decreased during the first quarter of 2022 compared to the same quarter in 2021 due primarily to lower net sales of the 10-inch version of iPad.

[0000320193-22-000007:mdna:32]
[same as prior period, unchanged from 0000320193-21-000065:mdna:36]

[0000320193-22-000007:mdna:33]
Wearables, Home and Accessories net sales increased during the first quarter of 2022 compared to the same quarter in 2021 due primarily to higher net sales of AirPods, Apple Watch and accessories.

[0000320193-22-000007:mdna:34]
[same as prior period, unchanged from 0000320193-21-000065:mdna:38]

[0000320193-22-000007:mdna:35]
Services net sales increased during the first quarter of 2022 compared to the same quarter in 2021 due primarily to higher net sales from advertising, the App Store® and cloud services.

[0000320193-22-000007:mdna:36]
[same as prior period, unchanged from 0000320193-21-000065:mdna:40]

[0000320193-22-000007:mdna:37]
The Company manages its business primarily on a geographic basis. The Company’s reportable segments consist of the Americas, Europe, Greater China, Japan and Rest of Asia Pacific. Americas includes both North and South America. Europe includes European countries, as well as India, the Middle East and Africa. Greater China includes China mainland, Hong Kong and Taiwan. Rest of Asia Pacific includes Australia and those Asian countries not included in the Company’s other reportable segments. Although the reportable segments provide similar hardware and software products and similar services, each one is managed separately to better align with the location of the Company’s customers and distribution partners and the unique market dynamics of each geographic region. Further information regarding the Company’s reportable segments can be found in Part I, Item 1 of this Form 10-Q in the Notes to Condensed Consolidated Financial Statements in Note 9, “Segment Information and Geographic Data.”

[0000320193-22-000007:mdna:38]
The following table shows net sales by reportable segment for the three months ended December 25, 2021 and December 26, 2020 (dollars in millions):

[0000320193-22-000007:mdna:39]
|  | Three Months Ended |  |  |
|  | December 25,2021 |  | December 26,2020 |  | Change |  |  |  |  |  |  |
| Net sales by reportable segment: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 51,496 |  |  | $ | 46,310 |  |  | 11 | % |  |  |  |  |  |  |
| Europe | 29,749 |  |  | 27,306 |  |  | 9 | % |  |  |  |  |  |  |
| Greater China | 25,783 |  |  | 21,313 |  |  | 21 | % |  |  |  |  |  |  |
| Japan | 7,107 |  |  | 8,285 |  |  | (14) | % |  |  |  |  |  |  |
| Rest of Asia Pacific | 9,810 |  |  | 8,225 |  |  | 19 | % |  |  |  |  |  |  |
| Total net sales | $ | 123,945 |  |  | $ | 111,439 |  |  | 11 | % |  |  |  |  |  |  |

[0000320193-22-000007:mdna:40]
[same as prior period, unchanged from 0000320193-21-000065:mdna:44]

[0000320193-22-000007:mdna:41]
Americas net sales increased during the first quarter of 2022 compared to the same quarter in 2021 due primarily to higher net sales of Services, iPhone, and Wearables, Home and Accessories.

[0000320193-22-000007:mdna:42]
[same as prior period, unchanged from 0000320193-21-000065:mdna:46]

[0000320193-22-000007:mdna:43]
Europe net sales increased during the first quarter of 2022 compared to the same quarter in 2021 due primarily to higher net sales of Services, Mac and iPhone. The movement of foreign currencies in Europe relative to the U.S. dollar had a net favorable impact on Europe net sales during the first quarter of 2022.

[0000320193-22-000007:mdna:44]
[same as prior period, unchanged from 0000320193-21-000065:mdna:48]

[0000320193-22-000007:mdna:45]
Greater China net sales increased during the first quarter of 2022 compared to the same quarter in 2021 due primarily to higher net sales of iPhone and Services. The strength of the Chinese renminbi relative to the U.S. dollar had a favorable impact on Greater China net sales during the first quarter of 2022.

[0000320193-22-000007:mdna:46]
[same as prior period, unchanged from 0000320193-21-000065:mdna:50]

[0000320193-22-000007:mdna:47]
Japan net sales decreased during the first quarter of 2022 compared to the same quarter in 2021 due primarily to lower net sales of iPhone and iPad, partially offset by higher net sales of Services. The weakness of the Japanese yen relative to the U.S. dollar had an unfavorable impact on Japan net sales during the first quarter of 2022.

[0000320193-22-000007:mdna:48]
[same as prior period, unchanged from 0000320193-21-000065:mdna:52]

[0000320193-22-000007:mdna:49]
Rest of Asia Pacific net sales increased during the first quarter of 2022 compared to the same quarter in 2021 due primarily to higher net sales of iPhone, Wearables, Home and Accessories and Mac.

[0000320193-22-000007:mdna:50]
[same as prior period, unchanged from 0000320193-21-000065:mdna:54]

[0000320193-22-000007:mdna:51]
Products and Services gross margin and gross margin percentage for the three months ended December 25, 2021 and December 26, 2020 were as follows (dollars in millions):

[0000320193-22-000007:mdna:52]
|  | Three Months Ended |  |  |
|  | December 25,2021 |  | December 26,2020 |  |  |  |  |
| Gross margin: |  |  |  |  |  |  |  |
| Products | $ | 40,120 |  |  | $ | 33,548 |  |  |  |  |  |
| Services | 14,123 |  |  | 10,780 |  |  |  |  |  |
| Total gross margin | $ | 54,243 |  |  | $ | 44,328 |  |  |  |  |  |

[0000320193-22-000007:mdna:53]
| Gross margin percentage: |  |  |  |  |  |  |  |
| Products | 38.4 | % |  | 35.1 | % |  |  |  |  |
| Services | 72.4 | % |  | 68.4 | % |  |  |  |  |
| Total gross margin percentage | 43.8 | % |  | 39.8 | % |  |  |  |  |

[0000320193-22-000007:mdna:54]
[same as prior period, unchanged from 0000320193-21-000065:mdna:58]

[0000320193-22-000007:mdna:55]
Products gross margin and Products gross margin percentage increased during the first quarter of 2022 compared to the same quarter in 2021 due primarily to a different Products mix and the strength in foreign currencies relative to the U.S. dollar.

[0000320193-22-000007:mdna:56]
[same as prior period, unchanged from 0000320193-21-000065:mdna:61]

[0000320193-22-000007:mdna:57]
Services gross margin increased during the first quarter of 2022 compared to the same quarter in 2021 due primarily to higher Services net sales and a different Services mix. Services gross margin percentage increased during the first quarter of 2022 compared to the same quarter in 2021 due primarily to a different Services mix and leverage, partially offset by higher Services costs.

[0000320193-22-000007:mdna:58]
The Company’s future gross margins can be impacted by a variety of factors, as discussed in Part I, Item 1A of the 2021 Form 10-K under the heading “Risk Factors.” As a result, the Company believes, in general, gross margins will be subject to volatility and downward pressure.

[0000320193-22-000007:mdna:59]
[same as prior period, unchanged from 0000320193-21-000065:mdna:65]

[0000320193-22-000007:mdna:60]
Operating expenses for the three months ended December 25, 2021 and December 26, 2020 were as follows (dollars in millions):

[0000320193-22-000007:mdna:61]
|  | Three Months Ended |  |  |
|  | December 25,2021 |  | December 26,2020 |  |  |  |  |
| Research and development | $ | 6,306 |  |  | $ | 5,163 |  |  |  |  |  |
| Percentage of total net sales | 5 | % |  | 5 | % |  |  |  |  |
| Selling, general and administrative | $ | 6,449 |  |  | $ | 5,631 |  |  |  |  |  |
| Percentage of total net sales | 5 | % |  | 5 | % |  |  |  |  |
| Total operating expenses | $ | 12,755 |  |  | $ | 10,794 |  |  |  |  |  |
| Percentage of total net sales | 10 | % |  | 10 | % |  |  |  |  |

[0000320193-22-000007:mdna:62]
[same as prior period, unchanged from 0000320193-21-000065:mdna:68]

[0000320193-22-000007:mdna:63]
The growth in research and development (“R&D”) expense during the first quarter of 2022 compared to the same quarter in 2021 was driven primarily by increases in headcount-related expenses, engineering program costs and infrastructure-related costs. The Company continues to believe that focused investments in R&D are critical to its future growth and competitive position in the marketplace, and to the development of new and updated products and services that are central to the Company’s core business strategy.

[0000320193-22-000007:mdna:64]
[same as prior period, unchanged from 0000320193-21-000065:mdna:70]

[0000320193-22-000007:mdna:65]
The growth in selling, general and administrative expense during the first quarter of 2022 compared to the same quarter in 2021 was driven primarily by increases in headcount-related expenses, variable selling expenses and professional services.

[0000320193-22-000007:mdna:66]
[same as prior period, unchanged from 0000320193-21-000065:mdna:72]

[0000320193-22-000007:mdna:67]
Other income/(expense), net (“OI&E”) for the three months ended December 25, 2021 and December 26, 2020 was as follows (dollars in millions):

[0000320193-22-000007:mdna:68]
|  | Three Months Ended |  |  |
|  | December 25,2021 |  | December 26,2020 |  | Change |  |  |  |  |  |  |
| Interest and dividend income | $ | 650 |  |  | $ | 747 |  |  |  |  |  |  |  |  |  |
| Interest expense | (694) |  |  | (638) |  |  |  |  |  |  |  |  |  |
| Other expense, net | (203) |  |  | (64) |  |  |  |  |  |  |  |  |  |
| Total other income/(expense), net | $ | (247) |  |  | $ | 45 |  |  | (649) | % |  |  |  |  |  |  |

[0000320193-22-000007:mdna:69]
OI&E decreased during the first quarter of 2022 compared to the same quarter in 2021 due primarily to higher net losses on marketable and non-marketable securities and lower interest income.

[0000320193-22-000007:mdna:70]
[same as prior period, unchanged from 0000320193-21-000065:mdna:77]

[0000320193-22-000007:mdna:71]
Provision for income taxes, effective tax rate and statutory federal income tax rate for the three months ended December 25, 2021 and December 26, 2020 were as follows (dollars in millions):

[0000320193-22-000007:mdna:72]
|  | Three Months Ended |  |  |
|  | December 25,2021 |  | December 26,2020 |  |  |  |  |
| Provision for income taxes | $ | 6,611 |  |  | $ | 4,824 |  |  |  |  |  |
| Effective tax rate | 16.0 | % |  | 14.4 | % |  |  |  |  |
| Statutory federal income tax rate | 21 | % |  | 21 | % |  |  |  |  |

[0000320193-22-000007:mdna:73]
The Company’s effective tax rate for the first quarter of 2022 was lower than the statutory federal income tax rate due primarily to a lower effective tax rate on foreign earnings and tax benefits from share-based compensation.

[0000320193-22-000007:mdna:74]
The Company’s effective tax rate for the first quarter of 2022 was higher compared to the same quarter in 2021 due primarily to lower tax benefits from share-based compensation and a change in geographic mix of earnings.

[0000320193-22-000007:mdna:75]
[same as prior period, unchanged from 0000320193-21-000065:mdna:82]

[0000320193-22-000007:mdna:76]
The Company believes its balances of cash, cash equivalents and unrestricted marketable securities, along with cash generated by ongoing operations and continued access to debt markets, will be sufficient to satisfy its cash requirements and capital return program over the next 12 months and beyond.

[0000320193-22-000007:mdna:77]
The Company’s cash requirements have not changed materially since the 2021 Form 10-K, except for manufacturing purchase obligations.

[0000320193-22-000007:mdna:78]
[same as prior period, unchanged from 0000320193-21-000065:mdna:102]

[0000320193-22-000007:mdna:79]
The Company utilizes several outsourcing partners to manufacture subassemblies for the Company’s products and to perform final assembly and testing of finished products. The Company also obtains individual components for its products from a wide variety of individual suppliers. Outsourcing partners acquire components and build product based on demand information supplied by the Company, which typically covers periods up to 150 days. As of December 25, 2021, the Company had manufacturing purchase obligations of $47.6 billion, with $47.5 billion payable within 12 months. The Company’s manufacturing purchase obligations are primarily noncancelable.

[0000320193-22-000007:mdna:80]
In addition to its cash requirements, the Company has a capital return program authorized by the Board of Directors. The share repurchase program (the “Program”) does not obligate the Company to acquire any specific number of shares. As of December 25, 2021, the Company’s quarterly cash dividend was $0.22 per share. The Company intends to increase its dividend on an annual basis, subject to declaration by the Board of Directors.

[0000320193-22-000007:mdna:81]
Critical Accounting Estimates

[0000320193-22-000007:mdna:82]
The preparation of financial statements and related disclosures in conformity with U.S. generally accepted accounting principles and the Company’s discussion and analysis of its financial condition and operating results require the Company’s management to make judgments, assumptions and estimates that affect the amounts reported. Note 1, “Summary of Significant Accounting Policies” of the Notes to condensed consolidated Financial Statements in Part I, Item 1 of this Form 10-Q and in the Notes to Consolidated Financial Statements in Part II, Item 8 of the 2021 Form 10-K describe the significant accounting policies and methods used in the preparation of the Company’s condensed consolidated financial statements. There have been no material changes to the Company’s critical accounting estimates since the 2021 Form 10-K.
