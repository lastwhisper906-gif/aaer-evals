# AAPL notes — 0000320193-22-000007


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000320193-22-000007:notes:1]
[same as prior period, unchanged from 0000320193-21-000065:notes:1]

[0000320193-22-000007:notes:2]
The condensed consolidated financial statements include the accounts of Apple Inc. and its wholly owned subsidiaries (collectively “Apple” or the “Company”). Intercompany accounts and transactions have been eliminated. In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements and accompanying notes in conformity with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported. Actual results could differ materially from those estimates. Certain prior period amounts in the condensed consolidated financial statements and accompanying notes have been reclassified to conform to the current period’s presentation. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company’s annual consolidated financial statements and accompanying notes included in its Annual Report on Form 10-K for the fiscal year ended September 25, 2021 (the “2021 Form 10-K”).

[0000320193-22-000007:notes:3]
The Company’s fiscal year is the 52- or 53-week period that ends on the last Saturday of September. An additional week is included in the first fiscal quarter every five or six years to realign the Company’s fiscal quarters with calendar quarters. The Company’s fiscal years 2022 and 2021 span 52 weeks each. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in September and the associated quarters, months and periods of those fiscal years.

[0000320193-22-000007:notes:4]
[same as prior period, unchanged from 0000320193-21-000065:notes:9]

[0000320193-22-000007:notes:5]
The following table shows the computation of basic and diluted earnings per share for the three months ended December 25, 2021 and December 26, 2020 (net income in millions and shares in thousands):

[0000320193-22-000007:notes:6]
|  | Three Months Ended |  |  |
|  | December 25,2021 |  | December 26,2020 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 34,630 |  |  | $ | 28,755 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 16,391,724 |  |  | 16,935,119 |  |  |  |  |  |
| Effect of dilutive securities | 127,567 |  |  | 178,569 |  |  |  |  |  |
| Weighted-average diluted shares | 16,519,291 |  |  | 17,113,688 |  |  |  |  |  |
| Basic earnings per share | $ | 2.11 |  |  | $ | 1.70 |  |  |  |  |  |
| Diluted earnings per share | $ | 2.10 |  |  | $ | 1.68 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000320193-22-000007:notes:7]
Revenue
Net sales disaggregated by significant products and services for the three months ended December 25, 2021 and December 26, 2020 were as follows (in millions):

[0000320193-22-000007:notes:8]
|  | Three Months Ended |  |  |
|  | December 25,2021 |  | December 26,2020 |  |  |  |  |
| iPhone® (1) | $ | 71,628 |  |  | $ | 65,597 |  |  |  |  |  |
| Mac® (1) | 10,852 |  |  | 8,675 |  |  |  |  |  |
| iPad® (1) | 7,248 |  |  | 8,435 |  |  |  |  |  |
| Wearables, Home and Accessories (1)(2) | 14,701 |  |  | 12,971 |  |  |  |  |  |
| Services (3) | 19,516 |  |  | 15,761 |  |  |  |  |  |
| Total net sales (4) | $ | 123,945 |  |  | $ | 111,439 |  |  |  |  |  |

[0000320193-22-000007:notes:9]
[same as prior period, unchanged from 0000320193-21-000065:notes:24]

[0000320193-22-000007:notes:10]
(2)Wearables, Home and Accessories net sales include sales of AirPods®, Apple TV®, Apple Watch®, Beats® products, HomePod mini®, iPod touch® and accessories.

[0000320193-22-000007:notes:11]
(3)Services net sales include sales from the Company’s advertising, AppleCare®, cloud, digital content, payment and other services. Services net sales also include amortization of the deferred value of services bundled in the sales price of certain products.

[0000320193-22-000007:notes:12]
(4)Includes $3.0 billion of revenue recognized in the three months ended December 25, 2021 that was included in deferred revenue as of September 25, 2021 and $2.5 billion of revenue recognized in the three months ended December 26, 2020 that was included in deferred revenue as of September 26, 2020.

[0000320193-22-000007:notes:13]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 9, “Segment Information and Geographic Data” for the three months ended December 25, 2021 and December 26, 2020, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.

[0000320193-22-000007:notes:14]
As of December 25, 2021 and September 25, 2021, the Company had total deferred revenue of $12.4 billion and $11.9 billion, respectively. As of December 25, 2021, the Company expects 64% of total deferred revenue to be realized in less than a year, 27% within one-to-two years, 8% within two-to-three years and 1% in greater than three years.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000320193-22-000007:notes:15]
[same as prior period, unchanged from 0000320193-21-000065:notes:29]

[0000320193-22-000007:notes:16]
The following tables show the Company’s cash, cash equivalents and marketable securities by significant investment category as of December 25, 2021 and September 25, 2021 (in millions):

[0000320193-22-000007:notes:17]
|  | December 25, 2021 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | CurrentMarketableSecurities |  | Non-CurrentMarketableSecurities |
| Cash | $ | 17,992 |  |  | $ | — |  |  | $ | — |  |  | $ | 17,992 |  |  | $ | 17,992 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 11,356 |  |  | — |  |  | — |  |  | 11,356 |  |  | 11,356 |  |  | — |  |  | — |  |
| Mutual funds | 215 |  |  | 16 |  |  | (2) |  |  | 229 |  |  | — |  |  | 229 |  |  | — |  |
| Subtotal | 11,571 |  |  | 16 |  |  | (2) |  |  | 11,585 |  |  | 11,356 |  |  | 229 |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities | 1,527 |  |  | — |  |  | (850) |  |  | 677 |  |  | — |  |  | 677 |  |  | — |  |
| U.S. Treasury securities | 29,221 |  |  | 64 |  |  | (171) |  |  | 29,114 |  |  | 3,247 |  |  | 5,775 |  |  | 20,092 |  |
| U.S. agency securities | 7,934 |  |  | 1 |  |  | (116) |  |  | 7,819 |  |  | 1,066 |  |  | 1,581 |  |  | 5,172 |  |
| Non-U.S. government securities | 18,983 |  |  | 160 |  |  | (177) |  |  | 18,966 |  |  | 200 |  |  | 3,279 |  |  | 15,487 |  |
| Certificates of deposit and time deposits | 3,648 |  |  | — |  |  | — |  |  | 3,648 |  |  | 2,527 |  |  | 1,121 |  |  | — |  |
| Commercial paper | 2,261 |  |  | — |  |  | — |  |  | 2,261 |  |  | 702 |  |  | 1,559 |  |  | — |  |
| Corporate debt securities | 88,617 |  |  | 718 |  |  | (754) |  |  | 88,581 |  |  | 29 |  |  | 11,665 |  |  | 76,887 |  |
| Municipal securities | 993 |  |  | 10 |  |  | (1) |  |  | 1,002 |  |  | — |  |  | 150 |  |  | 852 |  |
| Mortgage- and asset-backed securities | 21,072 |  |  | 102 |  |  | (223) |  |  | 20,951 |  |  | — |  |  | 758 |  |  | 20,193 |  |
| Subtotal | 174,256 |  |  | 1,055 |  |  | (2,292) |  |  | 173,019 |  |  | 7,771 |  |  | 26,565 |  |  | 138,683 |  |
| Total (3) | $ | 203,819 |  |  | $ | 1,071 |  |  | $ | (2,294) |  |  | $ | 202,596 |  |  | $ | 37,119 |  |  | $ | 26,794 |  |  | $ | 138,683 |  |

[0000320193-22-000007:notes:18]
|  | September 25, 2021 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | CurrentMarketableSecurities |  | Non-CurrentMarketableSecurities |
| Cash | $ | 17,305 |  |  | $ | — |  |  | $ | — |  |  | $ | 17,305 |  |  | $ | 17,305 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 9,608 |  |  | — |  |  | — |  |  | 9,608 |  |  | 9,608 |  |  | — |  |  | — |  |
| Mutual funds | 175 |  |  | 11 |  |  | (1) |  |  | 185 |  |  | — |  |  | 185 |  |  | — |  |
| Subtotal | 9,783 |  |  | 11 |  |  | (1) |  |  | 9,793 |  |  | 9,608 |  |  | 185 |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities | 1,527 |  |  | — |  |  | (564) |  |  | 963 |  |  | — |  |  | 963 |  |  | — |  |
| U.S. Treasury securities | 22,878 |  |  | 102 |  |  | (77) |  |  | 22,903 |  |  | 3,596 |  |  | 6,625 |  |  | 12,682 |  |
| U.S. agency securities | 8,949 |  |  | 2 |  |  | (64) |  |  | 8,887 |  |  | 1,775 |  |  | 1,930 |  |  | 5,182 |  |
| Non-U.S. government securities | 20,201 |  |  | 211 |  |  | (101) |  |  | 20,311 |  |  | 390 |  |  | 3,091 |  |  | 16,830 |  |
| Certificates of deposit and time deposits | 1,300 |  |  | — |  |  | — |  |  | 1,300 |  |  | 490 |  |  | 810 |  |  | — |  |
| Commercial paper | 2,639 |  |  | — |  |  | — |  |  | 2,639 |  |  | 1,776 |  |  | 863 |  |  | — |  |
| Corporate debt securities | 83,883 |  |  | 1,242 |  |  | (267) |  |  | 84,858 |  |  | — |  |  | 12,327 |  |  | 72,531 |  |
| Municipal securities | 967 |  |  | 14 |  |  | — |  |  | 981 |  |  | — |  |  | 130 |  |  | 851 |  |
| Mortgage- and asset-backed securities | 20,529 |  |  | 171 |  |  | (124) |  |  | 20,576 |  |  | — |  |  | 775 |  |  | 19,801 |  |
| Subtotal | 162,873 |  |  | 1,742 |  |  | (1,197) |  |  | 163,418 |  |  | 8,027 |  |  | 27,514 |  |  | 127,877 |  |
| Total (3) | $ | 189,961 |  |  | $ | 1,753 |  |  | $ | (1,198) |  |  | $ | 190,516 |  |  | $ | 34,940 |  |  | $ | 27,699 |  |  | $ | 127,877 |  |

[0000320193-22-000007:notes:19]
[same as prior period, unchanged from 0000320193-21-000065:notes:33]

[0000320193-22-000007:notes:20]
[same as prior period, unchanged from 0000320193-21-000065:notes:34]

[0000320193-22-000007:notes:21]
(3)As of December 25, 2021 and September 25, 2021, total marketable securities included $16.8 billion and $17.9 billion, respectively, that was restricted from general use, related to the European Commission decision finding that Ireland granted state aid to the Company, and other agreements.

[0000320193-22-000007:notes:22]
The following table shows the fair value of the Company’s non-current marketable debt securities, by contractual maturity, as of December 25, 2021 (in millions):

[0000320193-22-000007:notes:23]
| Due after 1 year through 5 years | $ | 93,206 |  |
| Due after 5 years through 10 years | 25,183 |  |
| Due after 10 years | 20,294 |  |
| Total fair value | $ | 138,683 |  |

[0000320193-22-000007:notes:24]
Derivative Instruments and Hedging

[0000320193-22-000007:notes:25]
The Company may use derivative instruments to partially offset its business exposure to foreign exchange and interest rate risk. However, the Company may choose not to hedge certain exposures for a variety of reasons, including accounting considerations or the prohibitive economic cost of hedging particular exposures. There can be no assurance the hedges will offset more than a portion of the financial impact resulting from movements in foreign exchange or interest rates.

[0000320193-22-000007:notes:26]
Foreign Exchange Risk

[0000320193-22-000007:notes:27]
To protect gross margins from fluctuations in foreign currency exchange rates, the Company may enter into forward contracts, option contracts or other instruments, and may designate these instruments as cash flow hedges. The Company generally hedges portions of its forecasted foreign currency exposure associated with revenue and inventory purchases, typically for up to 12 months.

[0000320193-22-000007:notes:28]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in foreign currency exchange rates, the Company may enter into forward contracts, cross-currency swaps or other instruments. The Company designates these instruments as either cash flow or fair value hedges. As of December 25, 2021, the Company’s hedged term debt– and marketable securities–related foreign currency transactions are expected to be recognized within 21 years.

[0000320193-22-000007:notes:29]
The Company may also enter into derivative instruments that are not designated as accounting hedges to protect gross margins from certain fluctuations in foreign currency exchange rates, as well as to offset a portion of the foreign currency exchange gains and losses generated by the remeasurement of certain assets and liabilities denominated in non-functional currencies.

[0000320193-22-000007:notes:30]
Interest Rate Risk

[0000320193-22-000007:notes:31]
To protect the Company’s term debt or marketable securities from fluctuations in interest rates, the Company may enter into interest rate swaps, options or other instruments. The Company designates these instruments as either cash flow or fair value hedges.

[0000320193-22-000007:notes:32]
The notional amounts of the Company’s outstanding derivative instruments as of December 25, 2021 and September 25, 2021 were as follows (in millions):

[0000320193-22-000007:notes:33]
|  | December 25, 2021 |  | September 25, 2021 |
| Derivative instruments designated as accounting hedges: |  |  |  |
| Foreign exchange contracts | $ | 77,009 |  |  | $ | 76,475 |  |
| Interest rate contracts | $ | 16,875 |  |  | $ | 16,875 |  |
| Derivative instruments not designated as accounting hedges: |  |  |  |
| Foreign exchange contracts | $ | 176,268 |  |  | $ | 126,918 |  |

[0000320193-22-000007:notes:34]
The gross fair values of the Company’s derivative assets and liabilities were not material as of December 25, 2021 and September 25, 2021.

[0000320193-22-000007:notes:35]
The gains and losses recognized in other comprehensive income and amounts reclassified from accumulated other comprehensive income to net income for the Company’s derivative instruments designated as cash flow hedges were not material in the three months ended December 25, 2021 and December 26, 2020.

[0000320193-22-000007:notes:36]
The carrying amounts of the Company’s hedged items in fair value hedges as of December 25, 2021 and September 25, 2021 were as follows (in millions):

[0000320193-22-000007:notes:37]
|  | December 25, 2021 |  | September 25, 2021 |  |  |
| Hedged assets/(liabilities): |  |  |  |  |  |
| Current and non-current marketable securities | $ | 15,322 |  |  | $ | 15,954 |  |  |  |
| Current and non-current term debt | $ | (17,444) |  |  | $ | (17,857) |  |  |  |

[0000320193-22-000007:notes:38]
The gains and losses on the Company’s derivative instruments designated as fair value hedges and the related hedged item adjustments were not material in the three months ended December 25, 2021 and December 26, 2020.

[0000320193-22-000007:notes:39]
[same as prior period, unchanged from 0000320193-21-000065:notes:81]

[0000320193-22-000007:notes:40]
[same as prior period, unchanged from 0000320193-21-000065:notes:82]

[0000320193-22-000007:notes:41]
[same as prior period, unchanged from 0000320193-21-000065:notes:83]

[0000320193-22-000007:notes:42]
The Company’s cellular network carriers accounted for 45% and 42% of total trade receivables as of December 25, 2021 and September 25, 2021, respectively.

[0000320193-22-000007:notes:43]
[same as prior period, unchanged from 0000320193-21-000065:notes:85]

[0000320193-22-000007:notes:44]
The Company has non-trade receivables from certain of its manufacturing vendors resulting from the sale of components to these vendors who manufacture subassemblies or assemble final products for the Company. The Company purchases these components directly from suppliers. As of December 25, 2021, the Company had three vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 54%, 13% and 12%. As of September 25, 2021, the Company had three vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 52%, 11% and 11%.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000320193-22-000007:notes:45]
[same as prior period, unchanged from 0000320193-21-000065:notes:87]


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000320193-22-000007:notes:46]
Condensed Consolidated Financial Statement Details
The following tables show the Company’s condensed consolidated financial statement details as of December 25, 2021 and September 25, 2021 (in millions):

[0000320193-22-000007:notes:47]
[same as prior period, unchanged from 0000320193-21-000065:notes:91]

[0000320193-22-000007:notes:48]
|  | December 25,2021 |  | September 25,2021 |
| Gross property, plant and equipment | $ | 107,699 |  |  | $ | 109,723 |  |
| Accumulated depreciation and amortization | (68,454) |  |  | (70,283) |  |
| Total property, plant and equipment, net | $ | 39,245 |  |  | $ | 39,440 |  |

[0000320193-22-000007:notes:49]
[same as prior period, unchanged from 0000320193-21-000065:notes:93]

[0000320193-22-000007:notes:50]
|  | December 25,2021 |  | September 25,2021 |
| Long-term taxes payable | $ | 24,689 |  |  | $ | 24,689 |  |
| Other non-current liabilities | 30,367 |  |  | 28,636 |  |
| Total other non-current liabilities | $ | 55,056 |  |  | $ | 53,325 |  |

[0000320193-22-000007:notes:51]
[same as prior period, unchanged from 0000320193-21-000065:notes:95]

[0000320193-22-000007:notes:52]
The following table shows the detail of other income/(expense), net for the three months ended December 25, 2021 and December 26, 2020 (in millions):

[0000320193-22-000007:notes:53]
|  | Three Months Ended |  |  |
|  | December 25,2021 |  | December 26,2020 |  |  |  |  |
| Interest and dividend income | $ | 650 |  |  | $ | 747 |  |  |  |  |  |
| Interest expense | (694) |  |  | (638) |  |  |  |  |  |
| Other expense, net | (203) |  |  | (64) |  |  |  |  |  |
| Total other income/(expense), net | $ | (247) |  |  | $ | 45 |  |  |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0000320193-22-000007:notes:54]
Debt
Commercial Paper

[0000320193-22-000007:notes:55]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of December 25, 2021 and September 25, 2021, the Company had $5.0 billion and $6.0 billion of Commercial Paper outstanding, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the three months ended December 25, 2021 and December 26, 2020 (in millions):

[0000320193-22-000007:notes:56]
|  | Three Months Ended |
|  | December 25,2021 |  | December 26,2020 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from commercial paper, net | $ | 1,339 |  |  | $ | 1,439 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 1,191 |  |  | 780 |  |
| Repayments of commercial paper | (3,530) |  |  | (2,197) |  |
| Repayments of commercial paper, net | (2,339) |  |  | (1,417) |  |
| Total proceeds from/(repayments of) commercial paper, net | $ | (1,000) |  |  | $ | 22 |  |

[0000320193-22-000007:notes:57]
Term Debt

[0000320193-22-000007:notes:58]
As of December 25, 2021 and September 25, 2021, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate carrying amount of $117.8 billion and $118.7 billion, respectively (collectively the “Notes”). As of December 25, 2021 and September 25, 2021, the fair value of the Company’s Notes, based on Level 2 inputs, was $123.5 billion and $125.3 billion, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000320193-22-000007:notes:59]
[same as prior period, unchanged from 0000320193-21-000065:notes:114]

[0000320193-22-000007:notes:60]
As of December 25, 2021, the Company was authorized to purchase up to $315 billion of the Company’s common stock under a share repurchase program (the “Program”). During the three months ended December 25, 2021, the Company repurchased 124 million shares of its common stock for $20.4 billion, including 30 million shares initially delivered under accelerated share repurchase agreements (“ASRs”) entered into in November 2021, bringing the total utilization under the Program to $274.5 billion as of December 25, 2021. The Program does not obligate the Company to acquire any specific number of shares. Under the Program, shares may be repurchased in privately negotiated and/or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended.
Under the terms of the Company’s ASRs, two financial institutions committed to deliver shares of the Company’s common stock during the purchase periods in exchange for up-front payments totaling $6.0 billion. The total number of shares ultimately delivered under the ASRs, and therefore the average repurchase price paid per share, is determined based on the volume-weighted average price of the Company’s common stock during the ASRs’ purchase periods, which end in the second quarter of 2022. The shares received are retired in the periods they are delivered, and the up-front payments are accounted for as a reduction to retained earnings in the Company’s Condensed Consolidated Statement of Shareholders’ Equity in the period the payments are made.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000320193-22-000007:notes:61]
Benefit Plans
Restricted Stock Units

[0000320193-22-000007:notes:62]
A summary of the Company’s restricted stock unit (“RSU”) activity and related information for the three months ended December 25, 2021 is as follows:

[0000320193-22-000007:notes:63]
|  | Number ofRSUs(in thousands) |  | Weighted-AverageGrant Date FairValue Per RSU |  | AggregateFair Value(in millions) |
| Balance as of September 25, 2021 | 240,427 |  |  | $ | 75.16 |  |  |  |
| RSUs granted | 67,645 |  |  | $ | 147.33 |  |  |  |
| RSUs vested | (56,649) |  |  | $ | 61.75 |  |  |  |
| RSUs canceled | (4,886) |  |  | $ | 93.21 |  |  |  |
| Balance as of December 25, 2021 | 246,537 |  |  | $ | 97.69 |  |  | $ | 43,460 |  |

[0000320193-22-000007:notes:64]
The fair value as of the respective vesting dates of RSUs was $8.5 billion for the three months ended both December 25, 2021 and December 26, 2020.

[0000320193-22-000007:notes:65]
[same as prior period, unchanged from 0000320193-21-000065:notes:130]

[0000320193-22-000007:notes:66]
The following table shows share-based compensation expense and the related income tax benefit included in the Condensed Consolidated Statements of Operations for the three months ended December 25, 2021 and December 26, 2020 (in millions):

[0000320193-22-000007:notes:67]
|  | Three Months Ended |  |  |
|  | December 25,2021 |  | December 26,2020 |  |  |  |  |
| Share-based compensation expense | $ | 2,265 |  |  | $ | 2,020 |  |  |  |  |  |
| Income tax benefit related to share-based compensation expense | $ | (1,536) |  |  | $ | (1,624) |  |  |  |  |  |

[0000320193-22-000007:notes:68]
As of December 25, 2021, the total unrecognized compensation cost related to outstanding RSUs and stock options was $20.6 billion, which the Company expects to recognize over a weighted-average period of 3.0 years.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000320193-22-000007:notes:69]
Commitments and Contingencies
Accrued Warranty

[0000320193-22-000007:notes:70]
The following table shows changes in the Company’s accrued warranties and related costs for the three months ended December 25, 2021 and December 26, 2020 (in millions):

[0000320193-22-000007:notes:71]
|  | Three Months Ended |  |  |
|  | December 25,2021 |  | December 26,2020 |  |  |  |  |
| Beginning accrued warranty and related costs | $ | 3,364 |  |  | $ | 3,354 |  |  |  |  |  |
| Cost of warranty claims | (672) |  |  | (723) |  |  |  |  |  |
| Accruals for product warranty | 838 |  |  | 1,493 |  |  |  |  |  |
| Ending accrued warranty and related costs | $ | 3,530 |  |  | $ | 4,124 |  |  |  |  |  |

[0000320193-22-000007:notes:72]
Contingencies

[0000320193-22-000007:notes:73]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully resolved. The outcome of litigation is inherently uncertain. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss greater than a recorded accrual, concerning loss contingencies for asserted legal and other claims.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000320193-22-000007:notes:74]
Segment Information and Geographic Data
The following table shows information by reportable segment for the three months ended December 25, 2021 and December 26, 2020 (in millions):

[0000320193-22-000007:notes:75]
|  | Three Months Ended |  |  |
|  | December 25,2021 |  | December 26,2020 |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |
| Net sales | $ | 51,496 |  |  | $ | 46,310 |  |  |  |  |  |
| Operating income | $ | 19,585 |  |  | $ | 15,785 |  |  |  |  |  |
| Europe: |  |  |  |  |  |  |  |
| Net sales | $ | 29,749 |  |  | $ | 27,306 |  |  |  |  |  |
| Operating income | $ | 11,545 |  |  | $ | 9,589 |  |  |  |  |  |
| Greater China: |  |  |  |  |  |  |  |
| Net sales | $ | 25,783 |  |  | $ | 21,313 |  |  |  |  |  |
| Operating income | $ | 11,183 |  |  | $ | 8,530 |  |  |  |  |  |
| Japan: |  |  |  |  |  |  |  |
| Net sales | $ | 7,107 |  |  | $ | 8,285 |  |  |  |  |  |
| Operating income | $ | 3,349 |  |  | $ | 3,503 |  |  |  |  |  |
| Rest of Asia Pacific: |  |  |  |  |  |  |  |
| Net sales | $ | 9,810 |  |  | $ | 8,225 |  |  |  |  |  |
| Operating income | $ | 3,995 |  |  | $ | 2,953 |  |  |  |  |  |

[0000320193-22-000007:notes:76]
A reconciliation of the Company’s segment operating income to the Condensed Consolidated Statements of Operations for the three months ended December 25, 2021 and December 26, 2020 is as follows (in millions):

[0000320193-22-000007:notes:77]
|  | Three Months Ended |  |  |
|  | December 25,2021 |  | December 26,2020 |  |  |  |  |
| Segment operating income | $ | 49,657 |  |  | $ | 40,360 |  |  |  |  |  |
| Research and development expense | (6,306) |  |  | (5,163) |  |  |  |  |  |
| Other corporate expenses, net | (1,863) |  |  | (1,663) |  |  |  |  |  |
| Total operating income | $ | 41,488 |  |  | $ | 33,534 |  |  |  |  |  |
