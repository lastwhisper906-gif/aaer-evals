# AAPL note change history — 0000320193-21-000065 → 0000320193-22-000007


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-01-28):
[0000320193-22-000007:note_history:1]
Commitments and Contingencies
Accrued Warranty
  (was, 2021-07-28, similarity 0.8598):
[0000320193-21-000065:note_history:1]
Commitments and Contingencies
Accrued Warranty and Guarantees

- changed (2022-01-28):
[0000320193-22-000007:note_history:2]
The following table shows changes in the Company’s accrued warranties and related costs for the three months ended December 25, 2021 and December 26, 2020 (in millions):
  (was, 2021-07-28, similarity 0.8869):
[0000320193-21-000065:note_history:2]
The following table shows changes in the Company’s accrued warranties and related costs for the three- and nine-month periods ended June 26, 2021 and June 27, 2020 (in millions):

- changed (2022-01-28):
[0000320193-22-000007:note_history:3]
|  | Three Months Ended |  |  |
|  | December 25,2021 |  | December 26,2020 |  |  |  |  |
| Beginning accrued warranty and related costs | $ | 3,364 |  |  | $ | 3,354 |  |  |  |  |  |
| Cost of warranty claims | (672) |  |  | (723) |  |  |  |  |  |
| Accruals for product warranty | 838 |  |  | 1,493 |  |  |  |  |  |
| Ending accrued warranty and related costs | $ | 3,530 |  |  | $ | 4,124 |  |  |  |  |  |
  (was, 2021-07-28, similarity 0.7736):
[0000320193-21-000065:note_history:3]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2021 |  | June 27,2020 |  | June 26,2021 |  | June 27,2020 |
| Beginning accrued warranty and related costs | $ | 3,784 |  |  | $ | 3,923 |  |  | $ | 3,354 |  |  | $ | 3,570 |  |
| Cost of warranty claims | (636) |  |  | (576) |  |  | (2,008) |  |  | (2,180) |  |
| Accruals for product warranty | 384 |  |  | 557 |  |  | 2,186 |  |  | 2,514 |  |
| Ending accrued warranty and related costs | $ | 3,532 |  |  | $ | 3,904 |  |  | $ | 3,532 |  |  | $ | 3,904 |  |

- added (2022-01-28):
[0000320193-22-000007:note_history:4]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully resolved. The outcome of litigation is inherently uncertain. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss greater than a recorded accrual, concerning loss contingencies for asserted legal and other claims.

- removed (2022-01-28):
[0000320193-21-000065:note_history:5]
The Company offers an iPhone Upgrade Program, which is available to customers who purchase a qualifying iPhone in the U.S., the U.K. and China mainland. The iPhone Upgrade Program provides customers the right to trade in that iPhone for a specified amount when purchasing a new iPhone, provided certain conditions are met. The Company accounts for the trade-in right as a guarantee liability and recognizes arrangement revenue net of the fair value of such right, with subsequent changes to the guarantee liability recognized within net sales.

- removed (2022-01-28):
[0000320193-21-000065:note_history:6]
Concentrations in the Available Sources of Supply of Materials and Product

- removed (2022-01-28):
[0000320193-21-000065:note_history:7]
Although most components essential to the Company’s business are generally available from multiple sources, certain components are currently obtained from single or limited sources. The Company also competes for various components with other participants in the markets for smartphones, personal computers, tablets and other electronic devices. Therefore, many components used by the Company, including those that are available from multiple sources, are at times subject to industry-wide shortage and significant commodity pricing fluctuations.

- removed (2022-01-28):
[0000320193-21-000065:note_history:8]
The Company uses some custom components that are not commonly used by its competitors, and new products introduced by the Company often utilize custom components available from only one source. When a component or product uses new technologies, initial capacity constraints may exist until the suppliers’ yields have matured or their manufacturing capacities have increased. The continued availability of these components at acceptable prices, or at all, may be affected if suppliers decide to concentrate on the production of common components instead of components customized to meet the Company’s requirements.

- removed (2022-01-28):
[0000320193-21-000065:note_history:9]
The Company has entered into agreements for the supply of many components; however, there can be no guarantee that the Company will be able to extend or renew these agreements on similar terms, or at all.

- removed (2022-01-28):
[0000320193-21-000065:note_history:10]
Substantially all of the Company’s hardware products are manufactured by outsourcing partners that are located primarily in Asia, with some Mac computers manufactured in the U.S. and Ireland.

- removed (2022-01-28):
[0000320193-21-000065:note_history:11]
Unconditional Purchase Obligations

- removed (2022-01-28):
[0000320193-21-000065:note_history:12]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of payments for content creation, Internet and telecommunications services and supplier arrangements. As of June 26, 2021, the Company’s total future payments under noncancelable unconditional purchase obligations having a remaining term in excess of one year were $8.8 billion.

- removed (2022-01-28):
[0000320193-21-000065:note_history:13]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully resolved. The outcome of litigation is inherently uncertain. When a loss related to a legal proceeding or claim is probable and reasonably estimable, the Company accrues its best estimate for the ultimate resolution of the matter. If one or more legal matters were resolved against the Company in a reporting period for amounts above management’s expectations, the Company’s financial condition and operating results for that reporting period could be materially adversely affected. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss greater than a recorded accrual, concerning loss contingencies for asserted legal and other claims, except for the following matters:

- removed (2022-01-28):
[0000320193-21-000065:note_history:14]
VirnetX

- removed (2022-01-28):
[0000320193-21-000065:note_history:15]
VirnetX, Inc. (“VirnetX”) filed a lawsuit against the Company alleging that certain of the Company’s products infringe on patents owned by VirnetX. On April 11, 2018, a jury returned a verdict against the Company in the U.S. District Court for the Eastern District of Texas (the “Eastern Texas District Court”). The Company appealed the verdict to the U.S. Court of Appeals for the Federal Circuit, which remanded the case back to the Eastern Texas District Court, where a re-trial was held in October 2020. The jury returned a verdict against the Company and awarded damages of $503 million, which the Company has appealed. The Company has challenged the validity of the patents at issue in the re-trial at the U.S. Patent and Trademark Office (the “PTO”), and the PTO has declared the patents invalid, subject to further appeal by VirnetX.

- removed (2022-01-28):
[0000320193-21-000065:note_history:16]
iOS Performance Management Cases

- removed (2022-01-28):
[0000320193-21-000065:note_history:17]
On April 5, 2018, several U.S. federal actions alleging violation of consumer protection laws, fraud, computer intrusion and other causes of action related to the Company’s performance management feature used in its iPhone operating systems, introduced to certain iPhones in iOS updates 10.2.1 and 11.2, were consolidated through a Multidistrict Litigation process into a single action in the U.S. District Court for the Northern District of California (the “Northern California District Court”). On February 28, 2020, the parties in the Multidistrict Litigation reached a settlement to resolve the U.S. federal and California state class actions. On March 18, 2021, the Northern California District Court granted final approval of the Multidistrict Litigation settlement, which will result in an aggregate payment of $310 million to settle all claims. The Company continues to believe that its iPhones were not defective, that the performance management feature introduced with iOS updates 10.2.1 and 11.2 was intended to, and did, improve customers’ user experience, and that the Company did not make any misleading statements or fail to disclose any material information.

- removed (2022-01-28):
[0000320193-21-000065:note_history:18]
French Competition Authority

- removed (2022-01-28):
[0000320193-21-000065:note_history:19]
On March 16, 2020, the French Competition Authority (“FCA”) announced its decision that aspects of the Company’s sales and distribution practices in France violate French competition law and issued a fine of €1.1 billion. The Company strongly disagrees with the FCA’s decision and has appealed.

- removed (2022-01-28):
[0000320193-21-000065:note_history:20]
Optis

- removed (2022-01-28):
[0000320193-21-000065:note_history:21]
Optis Wireless Technology, LLC and related entities (“Optis”) filed a lawsuit in the U.S. District Court for the Eastern District of Texas against the Company alleging that certain of the Company’s products infringe on patents owned by Optis. On August 11, 2020, a jury returned a verdict against the Company and awarded damages of $506 million. In post-trial proceedings, the damages portion of the verdict was set aside, and a retrial was scheduled for August 2021. The case remains pending further proceedings.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-01-28):
[0000320193-22-000007:note_history:22]
The condensed consolidated financial statements include the accounts of Apple Inc. and its wholly owned subsidiaries (collectively “Apple” or the “Company”). Intercompany accounts and transactions have been eliminated. In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements and accompanying notes in conformity with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported. Actual results could differ materially from those estimates. Certain prior period amounts in the condensed consolidated financial statements and accompanying notes have been reclassified to conform to the current period’s presentation. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company’s annual consolidated financial statements and accompanying notes included in its Annual Report on Form 10-K for the fiscal year ended September 25, 2021 (the “2021 Form 10-K”).
  (was, 2021-07-28, similarity 0.9958):
[0000320193-21-000065:note_history:22]
The condensed consolidated financial statements include the accounts of Apple Inc. and its wholly owned subsidiaries (collectively “Apple” or the “Company”). Intercompany accounts and transactions have been eliminated. In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements and accompanying notes in conformity with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported. Actual results could differ materially from those estimates. Certain prior period amounts in the consolidated financial statements and accompanying notes have been reclassified to conform to the current period’s presentation. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company’s annual consolidated financial statements and accompanying notes included in its Annual Report on Form 10-K for the fiscal year ended September 26, 2020 (the “2020 Form 10-K”).

- changed (2022-01-28):
[0000320193-22-000007:note_history:23]
The following table shows the computation of basic and diluted earnings per share for the three months ended December 25, 2021 and December 26, 2020 (net income in millions and shares in thousands):
  (was, 2021-07-28, similarity 0.9039):
[0000320193-21-000065:note_history:23]
The following table shows the computation of basic and diluted earnings per share for the three- and nine-month periods ended June 26, 2021 and June 27, 2020 (net income in millions and shares in thousands):

- added (2022-01-28):
[0000320193-22-000007:note_history:24]
|  | Three Months Ended |  |  |
|  | December 25,2021 |  | December 26,2020 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 34,630 |  |  | $ | 28,755 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 16,391,724 |  |  | 16,935,119 |  |  |  |  |  |
| Effect of dilutive securities | 127,567 |  |  | 178,569 |  |  |  |  |  |
| Weighted-average diluted shares | 16,519,291 |  |  | 17,113,688 |  |  |  |  |  |
| Basic earnings per share | $ | 2.11 |  |  | $ | 1.70 |  |  |  |  |  |
| Diluted earnings per share | $ | 2.10 |  |  | $ | 1.68 |  |  |  |  |  |

- removed (2022-01-28):
[0000320193-21-000065:note_history:25]
Common Stock Split

- removed (2022-01-28):
[0000320193-21-000065:note_history:26]
On August 28, 2020, the Company effected a four-for-one stock split to shareholders of record as of August 24, 2020. All share, restricted stock unit (“RSU”) and per share or per RSU information has been retroactively adjusted to reflect the stock split.

- removed (2022-01-28):
[0000320193-21-000065:note_history:27]
Recently Adopted Accounting Pronouncements

- removed (2022-01-28):
[0000320193-21-000065:note_history:28]
Financial Instruments – Credit Losses

- removed (2022-01-28):
[0000320193-21-000065:note_history:29]
At the beginning of the first quarter of 2021, the Company adopted the Financial Accounting Standards Board’s Accounting Standards Update No. 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (“ASU 2016-13”), which modifies the measurement of expected credit losses on certain financial instruments. The Company adopted ASU 2016-13 utilizing the modified retrospective transition method. The adoption of ASU 2016-13 did not have a material impact on the Company’s condensed consolidated financial statements.

- removed (2022-01-28):
[0000320193-21-000065:note_history:30]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2021 |  | June 27,2020 |  | June 26,2021 |  | June 27,2020 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 21,744 |  |  | $ | 11,253 |  |  | $ | 74,129 |  |  | $ | 44,738 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 16,629,371 |  |  | 17,250,291 |  |  | 16,772,656 |  |  | 17,450,284 |  |
| Effect of dilutive securities | 152,364 |  |  | 168,863 |  |  | 168,871 |  |  | 168,494 |  |
| Weighted-average diluted shares | 16,781,735 |  |  | 17,419,154 |  |  | 16,941,527 |  |  | 17,618,778 |  |
| Basic earnings per share | $ | 1.31 |  |  | $ | 0.65 |  |  | $ | 4.42 |  |  | $ | 2.56 |  |
| Diluted earnings per share | $ | 1.30 |  |  | $ | 0.65 |  |  | $ | 4.38 |  |  | $ | 2.54 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-01-28):
[0000320193-22-000007:note_history:31]
Debt
Commercial Paper
  (was, 2021-07-28, similarity 0.6176):
[0000320193-21-000065:note_history:31]
Debt
Commercial Paper and Repurchase Agreements

- changed (2022-01-28):
[0000320193-22-000007:note_history:32]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of December 25, 2021 and September 25, 2021, the Company had $5.0 billion and $6.0 billion of Commercial Paper outstanding, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the three months ended December 25, 2021 and December 26, 2020 (in millions):
  (was, 2021-07-28, similarity 0.6835):
[0000320193-21-000065:note_history:32]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of June 26, 2021 and September 26, 2020, the Company had $8.0 billion and $5.0 billion of Commercial Paper outstanding, respectively, with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 0.04% and 0.62% as of June 26, 2021 and September 26, 2020, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the nine months ended June 26, 2021 and June 27, 2020 (in millions):

- added (2022-01-28):
[0000320193-22-000007:note_history:33]
|  | Three Months Ended |
|  | December 25,2021 |  | December 26,2020 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from commercial paper, net | $ | 1,339 |  |  | $ | 1,439 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 1,191 |  |  | 780 |  |
| Repayments of commercial paper | (3,530) |  |  | (2,197) |  |
| Repayments of commercial paper, net | (2,339) |  |  | (1,417) |  |
| Total proceeds from/(repayments of) commercial paper, net | $ | (1,000) |  |  | $ | 22 |  |

- added (2022-01-28):
[0000320193-22-000007:note_history:34]
As of December 25, 2021 and September 25, 2021, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate carrying amount of $117.8 billion and $118.7 billion, respectively (collectively the “Notes”). As of December 25, 2021 and September 25, 2021, the fair value of the Company’s Notes, based on Level 2 inputs, was $123.5 billion and $125.3 billion, respectively.

- removed (2022-01-28):
[0000320193-21-000065:note_history:35]
|  | Nine Months Ended |
|  | June 26,2021 |  | June 27,2020 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from commercial paper, net | $ | 2,745 |  |  | $ | 401 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 3,993 |  |  | 5,373 |  |
| Repayments of commercial paper | (3,716) |  |  | (5,743) |  |
| Proceeds from/(Repayments of) commercial paper, net | 277 |  |  | (370) |  |
| Total proceeds from commercial paper, net | $ | 3,022 |  |  | $ | 31 |  |

- removed (2022-01-28):
[0000320193-21-000065:note_history:36]
In 2020, the Company entered into agreements to sell certain of its marketable securities with a promise to repurchase the securities at a specified time and amount (“Repos”). Due to the Company’s continuing involvement with the marketable securities, the Company accounted for its Repos as collateralized borrowings. As of September 26, 2020, the Repos had been settled.

- removed (2022-01-28):
[0000320193-21-000065:note_history:37]
As of June 26, 2021, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $113.2 billion (collectively the “Notes”). The Notes are senior unsecured obligations and interest is payable in arrears. The following table provides a summary of the Company’s term debt as of June 26, 2021 and September 26, 2020:

- removed (2022-01-28):
[0000320193-21-000065:note_history:38]
|  | Maturities(calendar year) |  | June 26, 2021 |  | September 26, 2020 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 – 2020 debt issuances: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2022 |  | $ | 1,750 |  |  | 0.51% – 0.66% |  | $ | 2,250 |  |  | 0.60% – 1.39% |
| Fixed-rate 0.000% – 4.650% notes | 2021 – 2060 |  | 97,443 |  |  | 0.03% – 4.78% |  | 103,828 |  |  | 0.03% – 4.78% |
| 2021 debt issuance: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.700% – 2.800% notes | 2026 – 2061 |  | 14,000 |  |  | 0.75% – 2.81% |  | — |  |  | — | % |
| Total term debt |  |  | 113,193 |  |  |  |  | 106,078 |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  | (360) |  |  |  |  | (314) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 958 |  |  |  |  | 1,676 |  |  |  |
| Less: Current portion of term debt |  |  | (8,039) |  |  |  |  | (8,773) |  |  |  |
| Total non-current portion of term debt |  |  | $ | 105,752 |  |  |  |  | $ | 98,667 |  |  |  |

- removed (2022-01-28):
[0000320193-21-000065:note_history:39]
To manage interest rate risk on certain of its U.S. dollar–denominated fixed- or floating-rate notes, the Company has entered into interest rate swaps to effectively convert the fixed interest rates to floating interest rates or the floating interest rates to fixed interest rates on a portion of these notes. Additionally, to manage foreign currency risk on certain of its foreign currency–denominated notes, the Company has entered into foreign currency swaps to effectively convert these notes to U.S. dollar–denominated notes.

- removed (2022-01-28):
[0000320193-21-000065:note_history:40]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $657 million and $1.9 billion of interest cost on its term debt for the three- and nine-month periods ended June 26, 2021, respectively. The Company recognized $664 million and $2.1 billion of interest cost on its term debt for the three- and nine-month periods ended June 27, 2020, respectively.

- removed (2022-01-28):
[0000320193-21-000065:note_history:41]
As of June 26, 2021 and September 26, 2020, the fair value of the Company’s Notes, based on Level 2 inputs, was $120.3 billion and $117.1 billion, respectively.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2022-01-28):
[0000320193-21-000065:note_history:42]
The following table provides a summary of the Company’s term debt as of June 26, 2021 and September 26, 2020:

- removed (2022-01-28):
[0000320193-21-000065:note_history:43]
|  | Maturities(calendar year) |  | June 26, 2021 |  | September 26, 2020 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 – 2020 debt issuances: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2022 |  | $ | 1,750 |  |  | 0.51% – 0.66% |  | $ | 2,250 |  |  | 0.60% – 1.39% |
| Fixed-rate 0.000% – 4.650% notes | 2021 – 2060 |  | 97,443 |  |  | 0.03% – 4.78% |  | 103,828 |  |  | 0.03% – 4.78% |
| 2021 debt issuance: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.700% – 2.800% notes | 2026 – 2061 |  | 14,000 |  |  | 0.75% – 2.81% |  | — |  |  | — | % |
| Total term debt |  |  | 113,193 |  |  |  |  | 106,078 |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  | (360) |  |  |  |  | (314) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 958 |  |  |  |  | 1,676 |  |  |  |
| Less: Current portion of term debt |  |  | (8,039) |  |  |  |  | (8,773) |  |  |  |
| Total non-current portion of term debt |  |  | $ | 105,752 |  |  |  |  | $ | 98,667 |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-01-28):
[0000320193-22-000007:note_history:44]
Net sales disaggregated by significant products and services for the three months ended December 25, 2021 and December 26, 2020 were as follows (in millions):
  (was, 2021-07-28, similarity 0.8787):
[0000320193-21-000065:note_history:44]
Net sales disaggregated by significant products and services for the three- and nine-month periods ended June 26, 2021 and June 27, 2020 were as follows (in millions):

- added (2022-01-28):
[0000320193-22-000007:note_history:45]
|  | Three Months Ended |  |  |
|  | December 25,2021 |  | December 26,2020 |  |  |  |  |
| iPhone® (1) | $ | 71,628 |  |  | $ | 65,597 |  |  |  |  |  |
| Mac® (1) | 10,852 |  |  | 8,675 |  |  |  |  |  |
| iPad® (1) | 7,248 |  |  | 8,435 |  |  |  |  |  |
| Wearables, Home and Accessories (1)(2) | 14,701 |  |  | 12,971 |  |  |  |  |  |
| Services (3) | 19,516 |  |  | 15,761 |  |  |  |  |  |
| Total net sales (4) | $ | 123,945 |  |  | $ | 111,439 |  |  |  |  |  |

- changed (2022-01-28):
[0000320193-22-000007:note_history:46]
(2)Wearables, Home and Accessories net sales include sales of AirPods®, Apple TV®, Apple Watch®, Beats® products, HomePod mini®, iPod touch® and accessories.
  (was, 2021-07-28, similarity 0.8968):
[0000320193-21-000065:note_history:46]
(2)Wearables, Home and Accessories net sales include sales of AirPods®, Apple TV®, Apple Watch®, Beats® products, HomePod®, iPod touch® and Apple-branded and third-party accessories.

- changed (2022-01-28):
[0000320193-22-000007:note_history:47]
(3)Services net sales include sales from the Company’s advertising, AppleCare®, cloud, digital content, payment and other services. Services net sales also include amortization of the deferred value of services bundled in the sales price of certain products.
  (was, 2021-07-28, similarity 0.8313):
[0000320193-21-000065:note_history:47]
(3)Services net sales include sales from the Company’s advertising, AppleCare®, digital content and other services. Services net sales also include amortization of the deferred value of Maps, Siri, and free iCloud storage and Apple TV+SM services, which are bundled in the sales price of certain products.

- added (2022-01-28):
[0000320193-22-000007:note_history:48]
(4)Includes $3.0 billion of revenue recognized in the three months ended December 25, 2021 that was included in deferred revenue as of September 25, 2021 and $2.5 billion of revenue recognized in the three months ended December 26, 2020 that was included in deferred revenue as of September 26, 2020.

- removed (2022-01-28):
[0000320193-21-000065:note_history:49]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2021 |  | June 27,2020 |  | June 26,2021 |  | June 27,2020 |
| iPhone (1) | $ | 39,570 |  |  | $ | 26,418 |  |  | $ | 153,105 |  |  | $ | 111,337 |  |
| Mac (1) | 8,235 |  |  | 7,079 |  |  | 26,012 |  |  | 19,590 |  |
| iPad (1) | 7,368 |  |  | 6,582 |  |  | 23,610 |  |  | 16,927 |  |
| Wearables, Home and Accessories (1)(2) | 8,775 |  |  | 6,450 |  |  | 29,582 |  |  | 22,744 |  |
| Services (3) | 17,486 |  |  | 13,156 |  |  | 50,148 |  |  | 39,219 |  |
| Total net sales (4) | $ | 81,434 |  |  | $ | 59,685 |  |  | $ | 282,457 |  |  | $ | 209,817 |  |

- removed (2022-01-28):
[0000320193-21-000065:note_history:50]
(4)Includes $3.0 billion of revenue recognized in the three months ended June 26, 2021 that was included in deferred revenue as of March 27, 2021, $2.1 billion of revenue recognized in the three months ended June 27, 2020 that was included in deferred revenue as of March 28, 2020, $5.5 billion of revenue recognized in the nine months ended June 26, 2021 that was included in deferred revenue as of September 26, 2020, and $4.0 billion of revenue recognized in the nine months ended June 27, 2020 that was included in deferred revenue as of September 28, 2019.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-01-28):
[0000320193-22-000007:note_history:51]
Revenue
Net sales disaggregated by significant products and services for the three months ended December 25, 2021 and December 26, 2020 were as follows (in millions):
  (was, 2021-07-28, similarity 0.8562):
[0000320193-21-000065:note_history:51]
Net sales disaggregated by significant products and services for the three- and nine-month periods ended June 26, 2021 and June 27, 2020 were as follows (in millions):

- added (2022-01-28):
[0000320193-22-000007:note_history:52]
|  | Three Months Ended |  |  |
|  | December 25,2021 |  | December 26,2020 |  |  |  |  |
| iPhone® (1) | $ | 71,628 |  |  | $ | 65,597 |  |  |  |  |  |
| Mac® (1) | 10,852 |  |  | 8,675 |  |  |  |  |  |
| iPad® (1) | 7,248 |  |  | 8,435 |  |  |  |  |  |
| Wearables, Home and Accessories (1)(2) | 14,701 |  |  | 12,971 |  |  |  |  |  |
| Services (3) | 19,516 |  |  | 15,761 |  |  |  |  |  |
| Total net sales (4) | $ | 123,945 |  |  | $ | 111,439 |  |  |  |  |  |

- changed (2022-01-28):
[0000320193-22-000007:note_history:53]
(2)Wearables, Home and Accessories net sales include sales of AirPods®, Apple TV®, Apple Watch®, Beats® products, HomePod mini®, iPod touch® and accessories.
  (was, 2021-07-28, similarity 0.8968):
[0000320193-21-000065:note_history:53]
(2)Wearables, Home and Accessories net sales include sales of AirPods®, Apple TV®, Apple Watch®, Beats® products, HomePod®, iPod touch® and Apple-branded and third-party accessories.

- changed (2022-01-28):
[0000320193-22-000007:note_history:54]
(3)Services net sales include sales from the Company’s advertising, AppleCare®, cloud, digital content, payment and other services. Services net sales also include amortization of the deferred value of services bundled in the sales price of certain products.
  (was, 2021-07-28, similarity 0.8313):
[0000320193-21-000065:note_history:54]
(3)Services net sales include sales from the Company’s advertising, AppleCare®, digital content and other services. Services net sales also include amortization of the deferred value of Maps, Siri, and free iCloud storage and Apple TV+SM services, which are bundled in the sales price of certain products.

- added (2022-01-28):
[0000320193-22-000007:note_history:55]
(4)Includes $3.0 billion of revenue recognized in the three months ended December 25, 2021 that was included in deferred revenue as of September 25, 2021 and $2.5 billion of revenue recognized in the three months ended December 26, 2020 that was included in deferred revenue as of September 26, 2020.

- changed (2022-01-28):
[0000320193-22-000007:note_history:56]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 9, “Segment Information and Geographic Data” for the three months ended December 25, 2021 and December 26, 2020, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.
  (was, 2021-07-28, similarity 0.6551):
[0000320193-21-000065:note_history:56]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 11, “Segment Information and Geographic Data” for the three- and nine-month periods ended June 26, 2021 and June 27, 2020.

- added (2022-01-28):
[0000320193-22-000007:note_history:57]
As of December 25, 2021 and September 25, 2021, the Company had total deferred revenue of $12.4 billion and $11.9 billion, respectively. As of December 25, 2021, the Company expects 64% of total deferred revenue to be realized in less than a year, 27% within one-to-two years, 8% within two-to-three years and 1% in greater than three years.

- removed (2022-01-28):
[0000320193-21-000065:note_history:58]
Revenue Recognition
Net sales consist of revenue from the sale of iPhone®, Mac®, iPad®, Services and other products. The Company recognizes revenue at the amount to which it expects to be entitled when control of the products or services is transferred to its customers. Control is generally transferred when the Company has a present right to payment and title and the significant risks and rewards of ownership of products or services are transferred to its customers. For most of the Company’s Products net sales, control transfers when products are shipped. For the Company’s Services net sales, control transfers over time as services are delivered. Payment for Products and Services net sales is collected within a short period following transfer of control or commencement of delivery of services, as applicable.

- removed (2022-01-28):
[0000320193-21-000065:note_history:59]
The Company records reductions to Products net sales related to future product returns, price protection and other customer incentive programs based on the Company’s expectations and historical experience.

- removed (2022-01-28):
[0000320193-21-000065:note_history:60]
For arrangements with multiple performance obligations, which represent promises within an arrangement that are distinct, the Company allocates revenue to all distinct performance obligations based on their relative stand-alone selling prices (“SSPs”). When available, the Company uses observable prices to determine SSPs. When observable prices are not available, SSPs are established that reflect the Company’s best estimates of what the selling prices of the performance obligations would be if they were sold regularly on a stand-alone basis. The Company’s process for estimating SSPs without observable prices considers multiple factors that may vary depending upon the unique facts and circumstances related to each performance obligation including, where applicable, prices charged by the Company for similar offerings, market trends in the pricing for similar offerings, product-specific business objectives and the estimated cost to provide the performance obligation.

- removed (2022-01-28):
[0000320193-21-000065:note_history:61]
The Company has identified up to three performance obligations regularly included in arrangements involving the sale of iPhone, Mac, iPad and certain other products. The first performance obligation, which represents the substantial portion of the allocated sales price, is the hardware and bundled software delivered at the time of sale. The second performance obligation is the right to receive certain product-related bundled services, which include iCloud®, Siri® and Maps. The third performance obligation is the right to receive, on a when-and-if-available basis, future unspecified software upgrades relating to the software bundled with each device. The Company allocates revenue and any related discounts to these performance obligations based on their relative SSPs. Because the Company lacks observable prices for the undelivered performance obligations, the allocation of revenue is based on the Company’s estimated SSPs. Revenue allocated to the delivered hardware and bundled software is recognized when control has transferred to the customer, which generally occurs when the product is shipped. Revenue allocated to the product-related bundled services and unspecified software upgrade rights is deferred and recognized on a straight-line basis over the estimated period they are expected to be provided. Cost of sales related to delivered hardware and bundled software, including estimated warranty costs, are recognized at the time of sale. Costs incurred to provide product-related bundled services and unspecified software upgrade rights are recognized as cost of sales as incurred.

- removed (2022-01-28):
[0000320193-21-000065:note_history:62]
For certain long-term service arrangements, the Company has performance obligations for services it has not yet delivered. For these arrangements, the Company does not have a right to bill for the undelivered services. The Company has determined that any unbilled consideration relates entirely to the value of the undelivered services. Accordingly, the Company has not recognized revenue, and has elected not to disclose amounts, related to these undelivered services.

- removed (2022-01-28):
[0000320193-21-000065:note_history:63]
For the sale of third-party products where the Company obtains control of the product before transferring it to the customer, the Company recognizes revenue based on the gross amount billed to customers. The Company considers multiple factors when determining whether it obtains control of third-party products including, but not limited to, evaluating if it can establish the price of the product, retains inventory risk for tangible products or has the responsibility for ensuring acceptability of the product. For third-party applications sold through the App Store® and certain digital content sold through the Company’s other digital content stores, the Company does not obtain control of the product before transferring it to the customer. Therefore, the Company accounts for such sales on a net basis by recognizing in Services net sales only the commission it retains.

- removed (2022-01-28):
[0000320193-21-000065:note_history:64]
The Company has elected to record revenue net of taxes collected from customers that are remitted to governmental authorities, with the collected taxes recorded within other current liabilities until remitted to the relevant government authority.

- removed (2022-01-28):
[0000320193-21-000065:note_history:65]
Deferred Revenue

- removed (2022-01-28):
[0000320193-21-000065:note_history:66]
As of June 26, 2021 and September 26, 2020, the Company had total deferred revenue of $12.0 billion and $10.2 billion, respectively. As of June 26, 2021, the Company expects 64% of total deferred revenue to be realized in less than a year, 26% within one-to-two years, 8% within two-to-three years and 2% in greater than three years.

- removed (2022-01-28):
[0000320193-21-000065:note_history:67]
Disaggregated Revenue

- removed (2022-01-28):
[0000320193-21-000065:note_history:68]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2021 |  | June 27,2020 |  | June 26,2021 |  | June 27,2020 |
| iPhone (1) | $ | 39,570 |  |  | $ | 26,418 |  |  | $ | 153,105 |  |  | $ | 111,337 |  |
| Mac (1) | 8,235 |  |  | 7,079 |  |  | 26,012 |  |  | 19,590 |  |
| iPad (1) | 7,368 |  |  | 6,582 |  |  | 23,610 |  |  | 16,927 |  |
| Wearables, Home and Accessories (1)(2) | 8,775 |  |  | 6,450 |  |  | 29,582 |  |  | 22,744 |  |
| Services (3) | 17,486 |  |  | 13,156 |  |  | 50,148 |  |  | 39,219 |  |
| Total net sales (4) | $ | 81,434 |  |  | $ | 59,685 |  |  | $ | 282,457 |  |  | $ | 209,817 |  |

- removed (2022-01-28):
[0000320193-21-000065:note_history:69]
(4)Includes $3.0 billion of revenue recognized in the three months ended June 26, 2021 that was included in deferred revenue as of March 27, 2021, $2.1 billion of revenue recognized in the three months ended June 27, 2020 that was included in deferred revenue as of March 28, 2020, $5.5 billion of revenue recognized in the nine months ended June 26, 2021 that was included in deferred revenue as of September 26, 2020, and $4.0 billion of revenue recognized in the nine months ended June 27, 2020 that was included in deferred revenue as of September 28, 2019.


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: no_current_note, score: 0.0

- removed (2022-01-28):
[0000320193-21-000065:note_history:70]
Net sales consist of revenue from the sale of iPhone®, Mac®, iPad®, Services and other products. The Company recognizes revenue at the amount to which it expects to be entitled when control of the products or services is transferred to its customers. Control is generally transferred when the Company has a present right to payment and title and the significant risks and rewards of ownership of products or services are transferred to its customers. For most of the Company’s Products net sales, control transfers when products are shipped. For the Company’s Services net sales, control transfers over time as services are delivered. Payment for Products and Services net sales is collected within a short period following transfer of control or commencement of delivery of services, as applicable.

- removed (2022-01-28):
[0000320193-21-000065:note_history:71]
The Company records reductions to Products net sales related to future product returns, price protection and other customer incentive programs based on the Company’s expectations and historical experience.

- removed (2022-01-28):
[0000320193-21-000065:note_history:72]
For arrangements with multiple performance obligations, which represent promises within an arrangement that are distinct, the Company allocates revenue to all distinct performance obligations based on their relative stand-alone selling prices (“SSPs”). When available, the Company uses observable prices to determine SSPs. When observable prices are not available, SSPs are established that reflect the Company’s best estimates of what the selling prices of the performance obligations would be if they were sold regularly on a stand-alone basis. The Company’s process for estimating SSPs without observable prices considers multiple factors that may vary depending upon the unique facts and circumstances related to each performance obligation including, where applicable, prices charged by the Company for similar offerings, market trends in the pricing for similar offerings, product-specific business objectives and the estimated cost to provide the performance obligation.

- removed (2022-01-28):
[0000320193-21-000065:note_history:73]
The Company has identified up to three performance obligations regularly included in arrangements involving the sale of iPhone, Mac, iPad and certain other products. The first performance obligation, which represents the substantial portion of the allocated sales price, is the hardware and bundled software delivered at the time of sale. The second performance obligation is the right to receive certain product-related bundled services, which include iCloud®, Siri® and Maps. The third performance obligation is the right to receive, on a when-and-if-available basis, future unspecified software upgrades relating to the software bundled with each device. The Company allocates revenue and any related discounts to these performance obligations based on their relative SSPs. Because the Company lacks observable prices for the undelivered performance obligations, the allocation of revenue is based on the Company’s estimated SSPs. Revenue allocated to the delivered hardware and bundled software is recognized when control has transferred to the customer, which generally occurs when the product is shipped. Revenue allocated to the product-related bundled services and unspecified software upgrade rights is deferred and recognized on a straight-line basis over the estimated period they are expected to be provided. Cost of sales related to delivered hardware and bundled software, including estimated warranty costs, are recognized at the time of sale. Costs incurred to provide product-related bundled services and unspecified software upgrade rights are recognized as cost of sales as incurred.

- removed (2022-01-28):
[0000320193-21-000065:note_history:74]
For certain long-term service arrangements, the Company has performance obligations for services it has not yet delivered. For these arrangements, the Company does not have a right to bill for the undelivered services. The Company has determined that any unbilled consideration relates entirely to the value of the undelivered services. Accordingly, the Company has not recognized revenue, and has elected not to disclose amounts, related to these undelivered services.

- removed (2022-01-28):
[0000320193-21-000065:note_history:75]
For the sale of third-party products where the Company obtains control of the product before transferring it to the customer, the Company recognizes revenue based on the gross amount billed to customers. The Company considers multiple factors when determining whether it obtains control of third-party products including, but not limited to, evaluating if it can establish the price of the product, retains inventory risk for tangible products or has the responsibility for ensuring acceptability of the product. For third-party applications sold through the App Store® and certain digital content sold through the Company’s other digital content stores, the Company does not obtain control of the product before transferring it to the customer. Therefore, the Company accounts for such sales on a net basis by recognizing in Services net sales only the commission it retains.

- removed (2022-01-28):
[0000320193-21-000065:note_history:76]
The Company has elected to record revenue net of taxes collected from customers that are remitted to governmental authorities, with the collected taxes recorded within other current liabilities until remitted to the relevant government authority.
