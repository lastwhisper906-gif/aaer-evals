# AAPL 8-K — 0000320193-22-000006 filed 2022-01-27

## item codes, every 8-K on or before 2022-01-28

- 2022-01-27 0000320193-22-000006 — 2.02, 9.01
- 2021-11-12 0001193125-21-328151 — 5.02, 5.03, 9.01
- 2021-10-28 0000320193-21-000104 — 2.02, 9.01
- 2021-08-05 0001193125-21-237787 — 8.01, 9.01
- 2021-07-27 0000320193-21-000063 — 2.02, 9.01
- 2021-04-28 0000320193-21-000055 — 2.02, 9.01
- 2021-02-24 0001193125-21-054710 — 5.07
- 2021-02-08 0001193125-21-032394 — 8.01, 9.01
- 2021-01-27 0000320193-21-000009 — 2.02, 9.01
- 2021-01-05 0001193125-21-001982 — 5.02
- 2020-10-29 0000320193-20-000094 — 2.02, 9.01
- 2020-08-20 0001193125-20-225672 — 8.01, 9.01
- 2020-08-07 0001193125-20-213158 — 5.03, 9.01
- 2020-07-30 0000320193-20-000060 — 2.02, 9.01
- 2020-05-11 0001193125-20-139112 — 8.01, 9.01
- 2020-04-30 0000320193-20-000050 — 2.02, 9.01
- 2020-02-27 0001193125-20-050884 — 5.07
- 2020-02-18 0001193125-20-039203 — 7.01, 9.01
- 2020-01-28 0000320193-20-000008 — 2.02, 9.01
- 2019-11-15 0001193125-19-292676 — 8.01, 9.01
- 2019-10-30 0000320193-19-000117 — 2.02, 9.01
- 2019-09-13 0000320193-19-000093 — 5.02
- 2019-09-11 0001193125-19-242975 — 8.01, 9.01
- 2019-07-30 0000320193-19-000073 — 2.02, 9.01
- 2019-04-30 0000320193-19-000063 — 2.02, 9.01
- 2019-03-04 0000320193-19-000032 — 5.07
- 2019-02-06 0000320193-19-000026 — 5.02
- 2019-01-29 0000320193-19-000007 — 2.02, 9.01
- 2019-01-02 0000320193-19-000002 — 2.02, 9.01
- 2018-11-01 0000320193-18-000142 — 2.02, 9.01
- 2018-07-31 0000320193-18-000098 — 2.02, 9.01
- 2018-05-08 0001193125-18-154948 — 8.01 — amendment of 0001193125-18-154515
- 2018-05-07 0001193125-18-154515 — 8.01, 9.01
- 2018-05-01 0000320193-18-000067 — 2.02, 9.01
- 2018-02-14 0001193125-18-045761 — 5.07, 9.01
- 2018-02-01 0000320193-18-000005 — 2.02, 9.01
- 2017-11-13 0001193125-17-341015 — 8.01, 9.01
- 2017-11-02 0000320193-17-000067 — 2.02, 9.01
- 2017-10-12 0001193125-17-308859 — 5.02
- 2017-09-12 0001193125-17-282809 — 8.01, 9.01
- 2017-08-18 0001193125-17-262261 — 8.01, 9.01
- 2017-08-01 0000320193-17-000006 — 2.02, 9.01
- 2017-06-20 0001193125-17-208226 — 8.01, 9.01
- 2017-05-24 0001193125-17-181867 — 8.01, 9.01
- 2017-05-11 0001193125-17-167400 — 8.01, 9.01
- 2017-05-02 0001628280-17-004663 — 2.02, 9.01
- 2017-03-03 0001193125-17-069853 — 8.01, 9.01
- 2017-03-01 0001193125-17-064019 — 5.07
- 2017-02-09 0001193125-17-036283 — 8.01, 9.01
- 2017-01-31 0001628280-17-000663 — 2.02, 9.01
- 2016-12-15 0001628280-16-022047 — 5.03, 9.01
- 2016-10-25 0001628280-16-020258 — 2.02, 9.01
- 2016-08-04 0001193125-16-672044 — 8.01, 9.01
- 2016-07-26 0001628280-16-017762 — 2.02, 9.01
- 2016-06-22 0001193125-16-628957 — 8.01, 9.01
- 2016-04-26 0001193125-16-556520 — 2.02, 9.01
- 2016-03-24 0001193125-16-516891 — 8.01, 9.01
- 2016-03-01 0001193125-16-488223 — 5.02, 5.07, 9.01
- 2016-02-23 0001193125-16-473562 — 8.01, 9.01
- 2016-01-26 0001193125-16-438421 — 2.02, 9.01
- 2015-12-22 0001193125-15-410853 — 5.03, 9.01
- 2015-12-17 0001193125-15-406279 — 5.02
- 2015-10-27 0001193125-15-354756 — 2.02, 9.01
- 2015-10-02 0001193125-15-336615 — 5.02
- 2015-09-17 0001193125-15-322466 — 8.01, 9.01
- 2015-07-31 0001193125-15-273023 — 8.01, 9.01
- 2015-07-21 0001193125-15-258464 — 2.02, 9.01
- 2015-06-10 0001193125-15-219298 — 8.01, 9.01
- 2015-05-13 0001193125-15-186064 — 8.01, 9.01
- 2015-04-27 0001193125-15-149607 — 7.01, 9.01
- 2015-04-27 0001193125-15-149590 — 2.02, 9.01
- 2015-03-13 0001104659-15-019336 — 5.07, 9.01
- 2015-02-09 0001193125-15-039270 — 8.01, 9.01
- 2015-01-28 0001193125-15-023732 — 8.01, 9.01
- 2015-01-27 0001193125-15-021857 — 2.02, 9.01
- 2014-11-10 0001193125-14-406296 — 8.01, 9.01
- 2014-10-20 0001193125-14-376361 — 2.02, 9.01
- 2014-07-23 0001193125-14-277193 — 8.01, 9.01
- 2014-07-22 0001193125-14-275598 — 2.02, 9.01
- 2014-07-17 0001193125-14-271698 — 5.02
- 2014-06-06 0001193125-14-228798 — 5.03, 9.01
- 2014-05-30 0001181431-14-021923 — 5.02
- 2014-05-06 0001193125-14-184969 — 8.01, 9.01
- 2014-04-23 0001193125-14-154883 — 7.01, 9.01
- 2014-04-23 0001193125-14-154871 — 2.02, 9.01
- 2014-03-05 0001193125-14-084697 — 5.02, 5.03, 5.07, 9.01
- 2014-01-27 0001193125-14-022238 — 2.02, 9.01
- 2013-10-28 0001193125-13-413498 — 2.02, 9.01
- 2013-09-23 0001181431-13-050140 — 8.01
- 2013-07-30 0001181431-13-041847 — 5.02
- 2013-07-23 0001193125-13-298914 — 2.02, 9.01
- 2013-06-21 0001193125-13-267629 — 5.02
- 2013-05-03 0001193125-13-199324 — 8.01, 9.01
- 2013-04-24 0001193125-13-170623 — 8.01, 9.01
- 2013-04-23 0001193125-13-167469 — 7.01, 9.01
- 2013-04-23 0001193125-13-167458 — 2.02, 9.01
- 2013-03-01 0001193125-13-085842 — 5.07
- 2013-01-23 0001193125-13-020783 — 2.02, 9.01
- 2012-10-25 0001193125-12-435506 — 2.02, 9.01
- 2012-07-24 0001193125-12-312355 — 2.02, 9.01
- 2012-06-28 0001181431-12-038301 — 5.02
- 2012-05-24 0001181431-12-032458 — 5.02
- 2012-04-24 0001193125-12-178928 — 2.02, 9.01
- 2012-02-27 0001193125-12-081892 — 5.07
- 2012-01-24 0001193125-12-021833 — 2.02, 9.01
- 2011-11-16 0001181431-11-056354 — 5.02
- 2011-10-18 0001193125-11-273826 — 2.02, 9.01
- 2011-10-06 0001181431-11-051976 — 8.01
- 2011-08-26 0001181431-11-047179 — 5.02
- 2011-07-19 0001193125-11-191368 — 2.02, 9.01
- 2011-06-15 0001181431-11-036782 — 5.02
- 2011-04-20 0001193125-11-103732 — 2.02, 9.01
- 2011-02-24 0001193125-11-045411 — 5.07
- 2011-01-18 0001193125-11-009392 — 2.02, 9.01
- 2011-01-18 0001181431-11-003847 — 5.02
- 2010-11-17 0001181431-10-056327 — 5.02, 5.03, 9.01
- 2010-10-18 0001193125-10-230992 — 2.02, 9.01
- 2010-07-20 0001193125-10-161807 — 2.02, 9.01
- 2010-04-20 0001193125-10-087786 — 2.02, 9.01
- 2010-03-12 0001181431-10-016054 — 5.02
- 2010-03-01 0001193125-10-044765 — 5.02, 5.07, 9.01
- 2010-01-25 0001193125-10-012096 — 2.02, 9.01
- 2009-10-19 0001193125-09-209633 — 2.02, 9.01
- 2009-08-04 0001181431-09-037492 — 5.02
- 2009-07-21 0001193125-09-152290 — 2.02, 9.01
- 2009-06-02 0001181431-09-028400 — 5.03
- 2009-04-22 0001193125-09-084599 — 2.02, 9.01
- 2009-02-27 0001181431-09-012161 — 4.01
- 2009-01-21 0001193125-09-009009 — 2.02, 9.01
- 2009-01-16 0001181431-09-003017 — 5.02
- 2008-10-21 0001193125-08-213642 — 2.02, 9.01
- 2008-08-26 0001181431-08-050059 — 5.03
- 2008-07-21 0001193125-08-154381 — 2.02, 9.01
- 2008-06-09 0001181431-08-037620 — 8.01
- 2008-04-23 0001193125-08-088001 — 2.02, 9.01
- 2008-01-22 0001193125-08-009715 — 2.02, 9.01
- 2008-01-15 0001181431-08-003342 — 2.02, 8.01
- 2008-01-08 0001181431-08-002372 — 5.02
- 2007-10-22 0001104659-07-076142 — 2.02, 9.01
- 2007-07-25 0001104659-07-056111 — 2.02, 9.01
- 2007-05-16 0001104659-07-040672 — 5.02, 9.01
- 2007-04-25 0001104659-07-031354 — 2.02, 9.01
- 2007-04-24 0001104659-07-030938 — 8.01, 9.01
- 2007-02-21 0001104659-07-012760 — 5.03, 9.01
- 2007-01-17 0001104659-07-002905 — 2.02, 9.01
- 2007-01-10 0001104659-07-001648 — 5.03, 9.01
- 2006-10-27 0001104659-06-069015 — 8.01
- 2006-10-18 0001104659-06-067275 — 2.02, 9.01
- 2006-10-04 0001104659-06-064935 — 5.02, 8.01, 9.01
- 2006-09-01 0001104659-06-058808 — 1.01, 5.02, 5.03, 9.01
- 2006-08-11 0001104659-06-054118 — 2.02, 3.01, 9.01
- 2006-08-04 0001104659-06-051302 — 2.02, 4.02, 9.01
- 2006-07-19 0001104659-06-047739 — 2.02, 9.01
- 2006-04-21 0001181431-06-024759 — 1.01
- 2006-04-19 0001104659-06-025992 — 2.02, 9.01
- 2006-01-18 0001104659-06-002690 — 2.02, 9.01
- 2006-01-10 0001104659-06-001428 — 2.02
- 2005-12-19 0001181431-05-067468 — 1.01
- 2005-10-14 0001181431-05-056604 — 5.02
- 2005-10-11 0001104659-05-048094 — 2.02, 9.01
- 2005-08-26 0001181431-05-049163 — 1.01
- 2005-08-15 0001181431-05-046871 — 1.01
- 2005-07-13 0001104659-05-032297 — 2.02, 9.01
- 2005-06-06 0001181431-05-033177 — 8.01
- 2005-04-26 0001181431-05-023450 — 1.01
- 2005-04-13 0001104659-05-016307 — 2.02, 9.01
- 2005-03-02 0001181431-05-013840 — 3.03, 5.03
- 2005-02-11 0001104659-05-005507 — 8.01
- 2005-01-12 0001104659-05-001183 — 2.02, 9.01
- 2005-01-11 0001104659-05-001049 — 2.02
- 2004-10-13 0001104659-04-030400 — 2.02, 9.01
- 2004-07-14 0001104659-04-019574 — 12, 7
- 2004-04-14 0001104659-04-010122 — 12, 7
- 2004-01-14 0001104659-04-000896 — 12, 7
- 2003-10-15 0001104659-03-022879 — 12, 7
- 2003-07-16 0001104659-03-014913 — 7, 9
- 2003-04-16 0001047469-03-013617 — 7, 9
- 2003-03-21 0001104659-03-004649 — 5, 7
- 2002-08-13 0000912057-02-031595 — 5, 7
- 2002-08-05 0000912057-02-029692 — 5, 7
- 2000-01-24 0000912057-00-002128 — 5, 7
- 1999-09-07 0000320193-99-000010 — 2
- 1999-07-16 0000320193-99-000007 — 2
- 1998-12-23 0000320193-98-000010 — 1
- 1998-01-08 0000320193-98-000001 — 2
- 1997-09-25 0000320193-97-000019 — 2
- 1997-09-25 0000320193-97-000018 — 2
- 1997-09-05 0000320193-97-000016 — 2
- 1997-07-28 0000320193-97-000012 — 4
- 1997-04-25 0000320193-97-000009 — 5
- 1997-04-10 0000320193-97-000007 — 7
- 1996-12-24 0000320193-96-000027 — 7
- 1996-12-23 0000320193-96-000025 — 4 — amendment of 0000320193-96-000021
- 1996-12-13 0000320193-96-000021 — 4
- 1996-10-28 0000912057-96-023874 — 5, 7
- 1996-06-17 0000320193-96-000014 — 1
- 1996-04-12 0000320193-96-000006 — 1

## late-filing notifications on or before 2022-01-28

- 2006-12-15 0001104659-06-081617 — NT 10-K, for the period ended 2006-09-30
- 2006-08-11 0001104659-06-053743 — NT 10-Q, for the period ended 2006-07-01

## item 2.02 — earnings release, exhibit 99.1

[0000320193-22-000006:8k_2_02:1]
EX-99.1
2
a8-kex991q1202212252021.htm
EX-99.1

[0000320193-22-000006:8k_2_02:2]
Document

[0000320193-22-000006:8k_2_02:3]
Exhibit 99.1

[0000320193-22-000006:8k_2_02:4]
Apple Reports First Quarter Results

[0000320193-22-000006:8k_2_02:5]
Revenue up 11 percent to new all-time record

[0000320193-22-000006:8k_2_02:6]
iPhone, Mac, Wearables, and Services revenue reach new all-time highs

[0000320193-22-000006:8k_2_02:7]
CUPERTINO, California — January 27, 2022 — Apple® today announced financial results for its fiscal 2022 first quarter ended December 25, 2021. The Company posted an all-time revenue record of $123.9 billion, up 11 percent year over year, and quarterly earnings per diluted share of $2.10.

[0000320193-22-000006:8k_2_02:8]
“This quarter’s record results were made possible by our most innovative lineup of products and services ever,” said Tim Cook, Apple’s CEO. “We are gratified to see the response from customers around the world at a time when staying connected has never been more important. We are doing all we can to help build a better world — making progress toward our goal of becoming carbon neutral across our supply chain and products by 2030, and pushing forward with our work in education and racial equity and justice.”

[0000320193-22-000006:8k_2_02:9]
“The very strong customer response to our recent launch of new products and services drove double-digit growth in revenue and earnings, and helped set an all-time high for our installed base of active devices,” said Luca Maestri, Apple’s CFO. “These record operating results allowed us to return nearly $27 billion to our shareholders during the quarter, as we maintain our target of reaching a net cash neutral position over time.”

[0000320193-22-000006:8k_2_02:10]
Apple’s board of directors has declared a cash dividend of $0.22 per share of the Company’s common stock. The dividend is payable on February 10, 2022 to shareholders of record as of the close of business on February 7, 2022.

[0000320193-22-000006:8k_2_02:11]
Apple will provide live streaming of its Q1 2022 financial results conference call beginning at 2:00 p.m. PT on January 27, 2022 at apple.com/investor/earnings-call. This webcast will also be available for replay for approximately two weeks thereafter.

[0000320193-22-000006:8k_2_02:12]
Apple periodically provides information for investors on its corporate website, apple.com, and its investor relations website, investor.apple.com. This includes press releases and other information about financial performance, reports filed or furnished with the SEC, information on corporate governance, and details related to its annual meeting of shareholders.

[0000320193-22-000006:8k_2_02:13]
Apple revolutionized personal technology with the introduction of the Macintosh in 1984. Today, Apple leads the world in innovation with iPhone, iPad, Mac, Apple Watch, and Apple TV. Apple’s five software platforms — iOS, iPadOS, macOS, watchOS, and tvOS — provide seamless experiences across all Apple devices and empower people with breakthrough services including the App Store, Apple Music, Apple Pay, and iCloud. Apple’s more than 100,000 employees are dedicated to making the best products on earth, and to leaving the world better than we found it.

[0000320193-22-000006:8k_2_02:14]
Press Contact:

[0000320193-22-000006:8k_2_02:15]
Josh Rosenstock

[0000320193-22-000006:8k_2_02:16]
Apple

[0000320193-22-000006:8k_2_02:17]
jrosenstock@apple.com

[0000320193-22-000006:8k_2_02:18]
(408) 862-1142

[0000320193-22-000006:8k_2_02:19]
Investor Relations Contact:

[0000320193-22-000006:8k_2_02:20]
Tejas Gala

[0000320193-22-000006:8k_2_02:21]
Apple

[0000320193-22-000006:8k_2_02:22]
tgala@apple.com

[0000320193-22-000006:8k_2_02:23]
(669) 227-2402

[0000320193-22-000006:8k_2_02:24]
NOTE TO EDITORS: For additional information visit Apple Newsroom (www.apple.com/newsroom), or call Apple’s Media Helpline at (408) 974-2042.

[0000320193-22-000006:8k_2_02:25]
© 2022 Apple Inc. All rights reserved. Apple and the Apple logo are trademarks of Apple. Other company and product names may be trademarks of their respective owners.

[0000320193-22-000006:8k_2_02:26]
Apple Inc.

[0000320193-22-000006:8k_2_02:27]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS (Unaudited)

[0000320193-22-000006:8k_2_02:28]
(In millions, except number of shares which are reflected in thousands and per share amounts)

[0000320193-22-000006:8k_2_02:29]
|  | Three Months Ended |  |  |
|  | December 25,2021 |  | December 26,2020 |  |  |  |  |
| Net sales: |  |  |  |  |  |  |  |
| Products | $ | 104,429 |  |  | $ | 95,678 |  |  |  |  |  |
| Services | 19,516 |  |  | 15,761 |  |  |  |  |  |
| Total net sales (1) | 123,945 |  |  | 111,439 |  |  |  |  |  |
| Cost of sales: |  |  |  |  |  |  |  |
| Products | 64,309 |  |  | 62,130 |  |  |  |  |  |
| Services | 5,393 |  |  | 4,981 |  |  |  |  |  |
| Total cost of sales | 69,702 |  |  | 67,111 |  |  |  |  |  |
| Gross margin | 54,243 |  |  | 44,328 |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 6,306 |  |  | 5,163 |  |  |  |  |  |
| Selling, general and administrative | 6,449 |  |  | 5,631 |  |  |  |  |  |
| Total operating expenses | 12,755 |  |  | 10,794 |  |  |  |  |  |
| Operating income | 41,488 |  |  | 33,534 |  |  |  |  |  |
| Other income/(expense), net | (247) |  |  | 45 |  |  |  |  |  |
| Income before provision for income taxes | 41,241 |  |  | 33,579 |  |  |  |  |  |
| Provision for income taxes | 6,611 |  |  | 4,824 |  |  |  |  |  |
| Net income | $ | 34,630 |  |  | $ | 28,755 |  |  |  |  |  |
| Earnings per share: |  |  |  |  |  |  |  |
| Basic | $ | 2.11 |  |  | $ | 1.70 |  |  |  |  |  |
| Diluted | $ | 2.10 |  |  | $ | 1.68 |  |  |  |  |  |
| Shares used in computing earnings per share: |  |  |  |  |  |  |  |
| Basic | 16,391,724 |  |  | 16,935,119 |  |  |  |  |  |
| Diluted | 16,519,291 |  |  | 17,113,688 |  |  |  |  |  |
| (1) Net sales by reportable segment: |  |  |  |  |  |  |  |
| Americas | $ | 51,496 |  |  | $ | 46,310 |  |  |  |  |  |
| Europe | 29,749 |  |  | 27,306 |  |  |  |  |  |
| Greater China | 25,783 |  |  | 21,313 |  |  |  |  |  |
| Japan | 7,107 |  |  | 8,285 |  |  |  |  |  |
| Rest of Asia Pacific | 9,810 |  |  | 8,225 |  |  |  |  |  |
| Total net sales | $ | 123,945 |  |  | $ | 111,439 |  |  |  |  |  |
| (1) Net sales by category: |  |  |  |  |  |  |  |
| iPhone | $ | 71,628 |  |  | $ | 65,597 |  |  |  |  |  |
| Mac | 10,852 |  |  | 8,675 |  |  |  |  |  |
| iPad | 7,248 |  |  | 8,435 |  |  |  |  |  |
| Wearables, Home and Accessories | 14,701 |  |  | 12,971 |  |  |  |  |  |
| Services | 19,516 |  |  | 15,761 |  |  |  |  |  |
| Total net sales | $ | 123,945 |  |  | $ | 111,439 |  |  |  |  |  |

[0000320193-22-000006:8k_2_02:30]
Apple Inc.

[0000320193-22-000006:8k_2_02:31]
CONDENSED CONSOLIDATED BALANCE SHEETS (Unaudited)

[0000320193-22-000006:8k_2_02:32]
(In millions, except number of shares which are reflected in thousands and par value)

[0000320193-22-000006:8k_2_02:33]
|  | December 25,2021 |  | September 25,2021 |
| ASSETS: |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 37,119 |  |  | $ | 34,940 |  |
| Marketable securities | 26,794 |  |  | 27,699 |  |
| Accounts receivable, net | 30,213 |  |  | 26,278 |  |
| Inventories | 5,876 |  |  | 6,580 |  |
| Vendor non-trade receivables | 35,040 |  |  | 25,228 |  |
| Other current assets | 18,112 |  |  | 14,111 |  |
| Total current assets | 153,154 |  |  | 134,836 |  |
| Non-current assets: |  |  |  |
| Marketable securities | 138,683 |  |  | 127,877 |  |
| Property, plant and equipment, net | 39,245 |  |  | 39,440 |  |
| Other non-current assets | 50,109 |  |  | 48,849 |  |
| Total non-current assets | 228,037 |  |  | 216,166 |  |
| Total assets | $ | 381,191 |  |  | $ | 351,002 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY: |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 74,362 |  |  | $ | 54,763 |  |
| Other current liabilities | 49,167 |  |  | 47,493 |  |
| Deferred revenue | 7,876 |  |  | 7,612 |  |
| Commercial paper | 5,000 |  |  | 6,000 |  |
| Term debt | 11,169 |  |  | 9,613 |  |
| Total current liabilities | 147,574 |  |  | 125,481 |  |
| Non-current liabilities: |  |  |  |
| Term debt | 106,629 |  |  | 109,106 |  |
| Other non-current liabilities | 55,056 |  |  | 53,325 |  |
| Total non-current liabilities | 161,685 |  |  | 162,431 |  |
| Total liabilities | 309,259 |  |  | 287,912 |  |
| Commitments and contingencies |  |  |  |
| Shareholders’ equity: |  |  |  |
| Common stock and additional paid-in capital, $0.00001 par value: 50,400,000 shares authorized; 16,340,851 and 16,426,786 shares issued and outstanding, respectively | 58,424 |  |  | 57,365 |  |
| Retained earnings | 14,435 |  |  | 5,562 |  |
| Accumulated other comprehensive income/(loss) | (927) |  |  | 163 |  |
| Total shareholders’ equity | 71,932 |  |  | 63,090 |  |
| Total liabilities and shareholders’ equity | $ | 381,191 |  |  | $ | 351,002 |  |

[0000320193-22-000006:8k_2_02:34]
Apple Inc.

[0000320193-22-000006:8k_2_02:35]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (Unaudited)

[0000320193-22-000006:8k_2_02:36]
(In millions)

[0000320193-22-000006:8k_2_02:37]
|  | Three Months Ended |
|  | December 25,2021 |  | December 26,2020 |
| Cash, cash equivalents and restricted cash, beginning balances | $ | 35,929 |  |  | $ | 39,789 |  |
| Operating activities: |  |  |  |
| Net income | 34,630 |  |  | 28,755 |  |
| Adjustments to reconcile net income to cash generated by operating activities: |  |  |  |
| Depreciation and amortization | 2,697 |  |  | 2,666 |  |
| Share-based compensation expense | 2,265 |  |  | 2,020 |  |
| Deferred income tax expense/(benefit) | 682 |  |  | (58) |  |
| Other | 167 |  |  | 25 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | (3,934) |  |  | (10,945) |  |
| Inventories | 681 |  |  | (950) |  |
| Vendor non-trade receivables | (9,812) |  |  | (10,194) |  |
| Other current and non-current assets | (4,921) |  |  | (3,526) |  |
| Accounts payable | 19,813 |  |  | 21,670 |  |
| Deferred revenue | 462 |  |  | 1,341 |  |
| Other current and non-current liabilities | 4,236 |  |  | 7,959 |  |
| Cash generated by operating activities | 46,966 |  |  | 38,763 |  |
| Investing activities: |  |  |  |
| Purchases of marketable securities | (34,913) |  |  | (39,800) |  |
| Proceeds from maturities of marketable securities | 11,309 |  |  | 25,177 |  |
| Proceeds from sales of marketable securities | 10,675 |  |  | 9,344 |  |
| Payments for acquisition of property, plant and equipment | (2,803) |  |  | (3,500) |  |
| Other | (374) |  |  | 195 |  |
| Cash used in investing activities | (16,106) |  |  | (8,584) |  |
| Financing activities: |  |  |  |
| Payments for taxes related to net share settlement of equity awards | (2,888) |  |  | (2,861) |  |
| Payments for dividends and dividend equivalents | (3,732) |  |  | (3,613) |  |
| Repurchases of common stock | (20,478) |  |  | (24,775) |  |
| Repayments of term debt | — |  |  | (1,000) |  |
| Proceeds from/(Repayments of) commercial paper, net | (1,000) |  |  | 22 |  |
| Other | (61) |  |  | (22) |  |
| Cash used in financing activities | (28,159) |  |  | (32,249) |  |
| Increase/(Decrease) in cash, cash equivalents and restricted cash | 2,701 |  |  | (2,070) |  |
| Cash, cash equivalents and restricted cash, ending balances | $ | 38,630 |  |  | $ | 37,719 |  |
| Supplemental cash flow disclosure: |  |  |  |
| Cash paid for income taxes, net | $ | 5,235 |  |  | $ | 1,787 |  |
| Cash paid for interest | $ | 531 |  |  | $ | 619 |  |
