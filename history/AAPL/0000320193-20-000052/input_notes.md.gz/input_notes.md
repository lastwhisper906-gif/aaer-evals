# AAPL notes — 0000320193-20-000052


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000320193-20-000052:notes:1]
[same as prior period, unchanged from 0000320193-20-000010:notes:1]

[0000320193-20-000052:notes:2]
The condensed consolidated financial statements include the accounts of Apple Inc. and its wholly owned subsidiaries (collectively “Apple” or the “Company”). Intercompany accounts and transactions have been eliminated. In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements and accompanying notes in conformity with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported. Actual results could differ materially from those estimates. Certain prior period amounts in the condensed consolidated financial statements and accompanying notes have been reclassified to conform to the current period’s presentation. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company’s annual consolidated financial statements and accompanying notes included in its Annual Report on Form 10-K for the fiscal year ended September 28, 2019 (the “2019 Form 10-K”).

[0000320193-20-000052:notes:3]
[same as prior period, unchanged from 0000320193-20-000010:notes:3]

[0000320193-20-000052:notes:4]
Recently Adopted Accounting Pronouncements

[0000320193-20-000052:notes:5]
[same as prior period, unchanged from 0000320193-20-000010:notes:5]

[0000320193-20-000052:notes:6]
At the beginning of the first quarter of 2020, the Company adopted the Financial Accounting Standards Board’s (the “FASB”) Accounting Standards Update (“ASU”) No. 2016-02, Leases (Topic 842) (“ASU 2016-02”), and additional ASUs issued to clarify and update the guidance in ASU 2016-02 (collectively, the “new leases standard”), which modifies lease accounting for lessees to increase transparency and comparability by recording lease assets and liabilities for operating leases and disclosing key information about leasing arrangements. The Company adopted the new leases standard utilizing the modified retrospective transition method, under which amounts in prior periods presented were not restated. For contracts existing at the time of adoption, the Company elected to not reassess (i) whether any are or contain leases, (ii) lease classification, and (iii) initial direct costs. Upon adoption, the Company recorded $7.5 billion of right-of-use (“ROU”) assets and $8.1 billion of lease liabilities on its Condensed Consolidated Balance Sheet.

[0000320193-20-000052:notes:7]
[same as prior period, unchanged from 0000320193-20-000010:notes:7]

[0000320193-20-000052:notes:8]
At the beginning of the first quarter of 2020, the Company adopted FASB ASU No. 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities (“ASU 2017-12”). ASU 2017-12 expands component and fair value hedging, specifies the presentation of the effects of hedging instruments, eliminates the separate measurement and presentation of hedge ineffectiveness, and updates disclosure requirements related to hedging. The Company adopted ASU 2017-12 utilizing the modified retrospective transition method. Upon adoption, the Company recorded a $136 million increase in accumulated other comprehensive income/(loss) (“AOCI”) and a corresponding decrease in retained earnings in the Condensed Consolidated Statement of Shareholders’ Equity.

[0000320193-20-000052:notes:9]
[same as prior period, unchanged from 0000320193-20-000010:notes:9]

[0000320193-20-000052:notes:10]
The following table shows the computation of basic and diluted earnings per share for the three- and six-month periods ended March 28, 2020 and March 30, 2019 (net income in millions and shares in thousands):

[0000320193-20-000052:notes:11]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 11,249 |  |  | $ | 11,561 |  |  | $ | 33,485 |  |  | $ | 31,526 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 4,360,101 |  |  | 4,674,071 |  |  | 4,387,570 |  |  | 4,704,945 |  |
| Effect of dilutive securities | 44,590 |  |  | 26,575 |  |  | 42,078 |  |  | 32,004 |  |
| Weighted-average diluted shares | 4,404,691 |  |  | 4,700,646 |  |  | 4,429,648 |  |  | 4,736,949 |  |
| Basic earnings per share | $ | 2.58 |  |  | $ | 2.47 |  |  | $ | 7.63 |  |  | $ | 6.70 |  |
| Diluted earnings per share | $ | 2.55 |  |  | $ | 2.46 |  |  | $ | 7.56 |  |  | $ | 6.66 |  |

[0000320193-20-000052:notes:12]
Potentially dilutive securities representing 31.1 million and 30.0 million shares of common stock were excluded from the computation of diluted earnings per share for the three- and six-month periods ended March 30, 2019, respectively, because their effect would have been antidilutive.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000320193-20-000052:notes:13]
[same as prior period, unchanged from 0000320193-20-000010:notes:13]

[0000320193-20-000052:notes:14]
[same as prior period, unchanged from 0000320193-20-000010:notes:14]

[0000320193-20-000052:notes:15]
[same as prior period, unchanged from 0000320193-20-000010:notes:15]

[0000320193-20-000052:notes:16]
[same as prior period, unchanged from 0000320193-20-000010:notes:16]

[0000320193-20-000052:notes:17]
[same as prior period, unchanged from 0000320193-20-000010:notes:17]

[0000320193-20-000052:notes:18]
[same as prior period, unchanged from 0000320193-20-000010:notes:18]

[0000320193-20-000052:notes:19]
[same as prior period, unchanged from 0000320193-20-000010:notes:19]

[0000320193-20-000052:notes:20]
[same as prior period, unchanged from 0000320193-20-000010:notes:20]

[0000320193-20-000052:notes:21]
As of March 28, 2020 and September 28, 2019, the Company had total deferred revenue of $9.4 billion and $8.1 billion, respectively. As of March 28, 2020, the Company expects 63% of total deferred revenue to be realized in less than a year, 28% within one-to-two years, 7% within two-to-three years and 2% in greater than three years.

[0000320193-20-000052:notes:22]
[same as prior period, unchanged from 0000320193-20-000010:notes:22]

[0000320193-20-000052:notes:23]
Net sales disaggregated by significant products and services for the three- and six-month periods ended March 28, 2020 and March 30, 2019 were as follows (in millions):

[0000320193-20-000052:notes:24]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| iPhone (1) | $ | 28,962 |  |  | $ | 31,051 |  |  | $ | 84,919 |  |  | $ | 83,033 |  |
| Mac (1) | 5,351 |  |  | 5,513 |  |  | 12,511 |  |  | 12,929 |  |
| iPad (1) | 4,368 |  |  | 4,872 |  |  | 10,345 |  |  | 11,601 |  |
| Wearables, Home and Accessories (1)(2) | 6,284 |  |  | 5,129 |  |  | 16,294 |  |  | 12,437 |  |
| Services (3) | 13,348 |  |  | 11,450 |  |  | 26,063 |  |  | 22,325 |  |
| Total net sales (4) | $ | 58,313 |  |  | $ | 58,015 |  |  | $ | 150,132 |  |  | $ | 142,325 |  |

[0000320193-20-000052:notes:25]
[same as prior period, unchanged from 0000320193-20-000010:notes:25]

[0000320193-20-000052:notes:26]
[same as prior period, unchanged from 0000320193-20-000010:notes:26]

[0000320193-20-000052:notes:27]
| (3) | Services net sales include sales from the Company’s digital content stores and streaming services, AppleCare®, licensing and other services. Services net sales also include amortization of the deferred value of Maps, Siri, and free iCloud storage and Apple TV + services, which are bundled in the sales price of certain products. |

[0000320193-20-000052:notes:28]
| (4) | Includes $1.9 billion of revenue recognized in the three months ended March 28, 2020 that was included in deferred revenue as of December 28, 2019, $1.9 billion of revenue recognized in the three months ended March 30, 2019 that was included in deferred revenue as of December 29, 2018, $3.0 billion of revenue recognized in the six months ended March 28, 2020 that was included in deferred revenue as of September 28, 2019, and $3.8 billion of revenue recognized in the six months ended March 30, 2019 that was included in deferred revenue as of September 29, 2018. |

[0000320193-20-000052:notes:29]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 11, “Segment Information and Geographic Data” for the three- and six-month periods ended March 28, 2020 and March 30, 2019.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000320193-20-000052:notes:30]
[same as prior period, unchanged from 0000320193-20-000010:notes:30]

[0000320193-20-000052:notes:31]
The following tables show the Company’s cash and marketable securities by significant investment category as of March 28, 2020 and September 28, 2019 (in millions):

[0000320193-20-000052:notes:32]
|  | March 28, 2020 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | CurrentMarketableSecurities |  | Non-CurrentMarketableSecurities |
| Cash | $ | 24,405 |  |  | $ | — |  |  | $ | — |  |  | $ | 24,405 |  |  | $ | 24,405 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 4,473 |  |  | — |  |  | — |  |  | 4,473 |  |  | 4,473 |  |  | — |  |  | — |  |
| Subtotal | 4,473 |  |  | — |  |  | — |  |  | 4,473 |  |  | 4,473 |  |  | — |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 18,755 |  |  | 405 |  |  | — |  |  | 19,160 |  |  | 1,042 |  |  | 6,736 |  |  | 11,382 |  |
| U.S. agency securities | 6,079 |  |  | 12 |  |  | (9 | ) |  | 6,082 |  |  | 129 |  |  | 1,478 |  |  | 4,475 |  |
| Non-U.S. government securities | 18,548 |  |  | 97 |  |  | (693 | ) |  | 17,952 |  |  | 652 |  |  | 2,348 |  |  | 14,952 |  |
| Certificates of deposit and time deposits | 10,616 |  |  | — |  |  | — |  |  | 10,616 |  |  | 3,661 |  |  | 6,319 |  |  | 636 |  |
| Commercial paper | 15,690 |  |  | — |  |  | — |  |  | 15,690 |  |  | 5,653 |  |  | 10,037 |  |  | — |  |
| Corporate debt securities | 82,153 |  |  | 207 |  |  | (2,177 | ) |  | 80,183 |  |  | 159 |  |  | 25,708 |  |  | 54,316 |  |
| Municipal securities | 974 |  |  | 9 |  |  | (1 | ) |  | 982 |  |  | — |  |  | 53 |  |  | 929 |  |
| Mortgage- and asset-backed securities | 13,066 |  |  | 278 |  |  | (43 | ) |  | 13,301 |  |  | — |  |  | 1,198 |  |  | 12,103 |  |
| Subtotal | 165,881 |  |  | 1,008 |  |  | (2,923 | ) |  | 163,966 |  |  | 11,296 |  |  | 53,877 |  |  | 98,793 |  |
| Total (3) | $ | 194,759 |  |  | $ | 1,008 |  |  | $ | (2,923 | ) |  | $ | 192,844 |  |  | $ | 40,174 |  |  | $ | 53,877 |  |  | $ | 98,793 |  |

[0000320193-20-000052:notes:33]
[same as prior period, unchanged from 0000320193-20-000010:notes:33]

[0000320193-20-000052:notes:34]
[same as prior period, unchanged from 0000320193-20-000010:notes:34]

[0000320193-20-000052:notes:35]
[same as prior period, unchanged from 0000320193-20-000010:notes:35]

[0000320193-20-000052:notes:36]
| (3) | As of March 28, 2020 and September 28, 2019, total marketable securities included $17.6 billion and $18.9 billion, respectively, that was restricted from general use, related to the State Aid Decision (refer to Note 5, “Income Taxes”) and other agreements. Additionally, as of March 28, 2020, $2.6 billion of marketable securities were pledged as collateral under a repurchase agreement (refer to Note 6, “Debt”). |

[0000320193-20-000052:notes:37]
[same as prior period, unchanged from 0000320193-20-000010:notes:37]

[0000320193-20-000052:notes:38]
The Company typically invests in highly rated securities, with the primary objective of minimizing the potential risk of principal loss. The Company’s investment policy generally requires securities to be investment grade and limits the amount of credit exposure to any one issuer. Fair values were determined for each individual security in the investment portfolio. When evaluating a marketable debt security for other-than-temporary impairment, the Company reviews factors such as the duration and extent to which the fair value of the security is less than its cost, the financial condition of the issuer and any changes thereto, and the Company’s intent to sell, or whether it will more likely than not be required to sell the security before recovery of its amortized cost basis. As of March 28, 2020, the Company does not consider any of its marketable debt securities to be other-than-temporarily impaired.

[0000320193-20-000052:notes:39]
[same as prior period, unchanged from 0000320193-20-000010:notes:39]

[0000320193-20-000052:notes:40]
The Company holds non-marketable equity securities of certain privately held companies without readily determinable fair values. As of March 28, 2020 and September 28, 2019, the Company’s non-marketable equity securities had a carrying value of $2.8 billion and $2.9 billion, respectively.

[0000320193-20-000052:notes:41]
[same as prior period, unchanged from 0000320193-20-000010:notes:41]

[0000320193-20-000052:notes:42]
A reconciliation of the Company’s cash and cash equivalents in the Condensed Consolidated Balance Sheets to cash, cash equivalents and restricted cash in the Condensed Consolidated Statements of Cash Flows as of March 28, 2020 and September 28, 2019 is as follows (in millions):

[0000320193-20-000052:notes:43]
|  | March 28, 2020 |  | September 28, 2019 |
| Cash and cash equivalents | $ | 40,174 |  |  | $ | 48,844 |  |
| Restricted cash included in other current assets | 1,077 |  |  | 23 |  |
| Restricted cash included in other non-current assets | 1,798 |  |  | 1,357 |  |
| Cash, cash equivalents and restricted cash | $ | 43,049 |  |  | $ | 50,224 |  |

[0000320193-20-000052:notes:44]
The Company’s restricted cash primarily consisted of cash to support the Company’s iPhone Upgrade Program and certain partner agreements.

[0000320193-20-000052:notes:45]
[same as prior period, unchanged from 0000320193-20-000010:notes:45]

[0000320193-20-000052:notes:46]
[same as prior period, unchanged from 0000320193-20-000010:notes:46]

[0000320193-20-000052:notes:47]
[same as prior period, unchanged from 0000320193-20-000010:notes:47]

[0000320193-20-000052:notes:48]
[same as prior period, unchanged from 0000320193-20-000010:notes:48]

[0000320193-20-000052:notes:49]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in foreign currency exchange rates, the Company may enter into forward contracts, cross-currency swaps or other instruments. These instruments may offset a portion of the foreign currency remeasurement gains or losses, or changes in fair value. The Company may designate these instruments as either cash flow or fair value hedges. As of March 28, 2020, the Company’s hedged term debt– and marketable securities–related foreign currency transactions are expected to be recognized within 22 years.

[0000320193-20-000052:notes:50]
[same as prior period, unchanged from 0000320193-20-000010:notes:50]

[0000320193-20-000052:notes:51]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in interest rates, the Company may enter into interest rate swaps, options or other instruments. These instruments may offset a portion of the changes in interest income or expense, or changes in fair value. The Company designates these instruments as either cash flow or fair value hedges. As of March 28, 2020, the Company’s hedged interest rate transactions are expected to be recognized within eight years.

[0000320193-20-000052:notes:52]
[same as prior period, unchanged from 0000320193-20-000010:notes:52]

[0000320193-20-000052:notes:53]
Cash flow hedge amounts that are included in the assessment of hedge effectiveness are deferred in AOCI until the hedged item is recognized in earnings. Deferred gains and losses associated with cash flow hedges of foreign currency revenue are recognized as a component of net sales in the same period as the related revenue is recognized, and deferred gains and losses related to cash flow hedges of inventory purchases are recognized as a component of cost of sales in the same period as the related costs are recognized. Deferred gains and losses associated with cash flow hedges of interest income or expense are recognized in other income/(expense), net (“OI&E”) in the same period as the related income or expense is recognized. Generally, for options designated as cash flow hedges, the time value is excluded from the assessment of hedge effectiveness and recognized in the financial statement line item to which the hedge relates on a straight-line basis over the life of the hedge. Changes in the fair value of amounts excluded from the assessment of hedge effectiveness are recognized in other comprehensive income/(loss) (“OCI”).

[0000320193-20-000052:notes:54]
[same as prior period, unchanged from 0000320193-20-000010:notes:54]

[0000320193-20-000052:notes:55]
[same as prior period, unchanged from 0000320193-20-000010:notes:55]

[0000320193-20-000052:notes:56]
[same as prior period, unchanged from 0000320193-20-000010:notes:56]

[0000320193-20-000052:notes:57]
[same as prior period, unchanged from 0000320193-20-000010:notes:57]

[0000320193-20-000052:notes:58]
Fair value hedge gains and losses related to amounts that are included in the assessment of hedge effectiveness are recognized in earnings along with a corresponding loss or gain related to the change in value of the hedged item in the same line in the Condensed Consolidated Statements of Operations. For foreign exchange forward contracts designated as fair value hedges, the forward carry component is excluded from the assessment of hedge effectiveness and recognized in OI&E on a straight-line basis over the life of the hedge. Changes in the fair value of amounts excluded from the assessment of hedge effectiveness are recognized in OCI. Amounts excluded from the effectiveness assessment of fair value hedges and recognized in OI&E were gains of $126 million and $254 million for the three- and six-month periods ended March 28, 2020, respectively.

[0000320193-20-000052:notes:59]
[same as prior period, unchanged from 0000320193-20-000010:notes:59]

[0000320193-20-000052:notes:60]
[same as prior period, unchanged from 0000320193-20-000010:notes:60]

[0000320193-20-000052:notes:61]
The Company records all derivatives in the Condensed Consolidated Balance Sheets at fair value. The Company’s accounting treatment for these derivative instruments is based on its hedge designation. The following tables show the Company’s derivative instruments at gross fair value as of March 28, 2020 and September 28, 2019 (in millions):

[0000320193-20-000052:notes:62]
|  | March 28, 2020 |
|  | Fair Value ofDerivatives Designatedas Hedge Instruments |  | Fair Value ofDerivatives Not Designatedas Hedge Instruments |  | TotalFair Value |
| Derivative assets (1): |  |  |  |  |  |
| Foreign exchange contracts | $ | 2,803 |  |  | $ | 1,425 |  |  | $ | 4,228 |  |
| Interest rate contracts | $ | 1,709 |  |  | $ | — |  |  | $ | 1,709 |  |
| Derivative liabilities (2): |  |  |  |  |  |
| Foreign exchange contracts | $ | 2,645 |  |  | $ | 1,518 |  |  | $ | 4,163 |  |
| Interest rate contracts | $ | 66 |  |  | $ | — |  |  | $ | 66 |  |

[0000320193-20-000052:notes:63]
[same as prior period, unchanged from 0000320193-20-000010:notes:63]

[0000320193-20-000052:notes:64]
[same as prior period, unchanged from 0000320193-20-000010:notes:64]

[0000320193-20-000052:notes:65]
[same as prior period, unchanged from 0000320193-20-000010:notes:65]

[0000320193-20-000052:notes:66]
[same as prior period, unchanged from 0000320193-20-000010:notes:66]

[0000320193-20-000052:notes:67]
The following table shows the pre-tax gains and losses of the Company’s derivative and non-derivative instruments designated as cash flow and net investment hedges in OCI and the Condensed Consolidated Statements of Operations for the three- and six-month periods ended March 28, 2020 and March 30, 2019 (in millions):

[0000320193-20-000052:notes:68]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| Gains/(Losses) recognized in OCI – included in effectiveness assessment: |  |  |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | (462 | ) |  | $ | (64 | ) |  | $ | (191 | ) |  | $ | (542 | ) |
| Interest rate contracts | (66 | ) |  | — |  |  | (66 | ) |  | — |  |
| Total | $ | (528 | ) |  | $ | (64 | ) |  | $ | (257 | ) |  | $ | (542 | ) |
| Net investment hedges: |  |  |  |  |  |  |  |
| Foreign currency debt | $ | 11 |  |  | $ | (7 | ) |  | $ | 35 |  |  | $ | (23 | ) |
| Gains/(Losses) reclassified from AOCI into net income – included in effectiveness assessment: |  |  |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | (817 | ) |  | $ | 134 |  |  | $ | (326 | ) |  | $ | 16 |  |
| Interest rate contracts | (1 | ) |  | (2 | ) |  | (3 | ) |  | (3 | ) |
| Total | $ | (818 | ) |  | $ | 132 |  |  | $ | (329 | ) |  | $ | 13 |  |

[0000320193-20-000052:notes:69]
Amounts excluded from the effectiveness assessment of the Company’s hedges and recognized in OCI were gains of $258 million and $169 million for the three- and six-month periods ended March 28, 2020, respectively.

[0000320193-20-000052:notes:70]
The following tables show information about the Company’s derivative instruments designated as fair value hedges and the related hedged items for the three- and six-month periods ended March 28, 2020 and March 30, 2019 and as of March 28, 2020 (in millions):

[0000320193-20-000052:notes:71]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| Gains/(Losses) on derivative instruments (1): |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 436 |  |  | $ | 243 |  |  | $ | 253 |  |  | $ | 645 |  |
| Interest rate contracts | 1,290 |  |  | 465 |  |  | 1,128 |  |  | 1,122 |  |
| Total | $ | 1,726 |  |  | $ | 708 |  |  | $ | 1,381 |  |  | $ | 1,767 |  |
| Gains/(Losses) related to hedged items (1): |  |  |  |  |  |  |  |
| Marketable securities | $ | (436 | ) |  | $ | (242 | ) |  | $ | (253 | ) |  | $ | (644 | ) |
| Fixed-rate debt | (1,290 | ) |  | (465 | ) |  | (1,128 | ) |  | (1,122 | ) |
| Total | $ | (1,726 | ) |  | $ | (707 | ) |  | $ | (1,381 | ) |  | $ | (1,766 | ) |

[0000320193-20-000052:notes:72]
|  | March 28, 2020 |
| Carrying amounts of hedged assets/(liabilities): |  |
| Marketable securities (2) | $ | 15,080 |  |
| Fixed-rate debt (3) | $ | (27,439 | ) |
| Cumulative hedging adjustments included in the carrying amounts of hedged items: |  |
| Marketable securities carrying amount increases/(decreases) | $ | (877 | ) |
| Fixed-rate debt carrying amount (increases)/decreases | $ | (1,708 | ) |

[0000320193-20-000052:notes:73]
[same as prior period, unchanged from 0000320193-20-000010:notes:73]

[0000320193-20-000052:notes:74]
[same as prior period, unchanged from 0000320193-20-000010:notes:74]

[0000320193-20-000052:notes:75]
[same as prior period, unchanged from 0000320193-20-000010:notes:75]

[0000320193-20-000052:notes:76]
The following table shows the notional amounts of the Company’s outstanding derivative instruments and credit risk amounts associated with outstanding or unsettled derivative instruments as of March 28, 2020 and September 28, 2019 (in millions):

[0000320193-20-000052:notes:77]
|  | March 28, 2020 |  | September 28, 2019 |
|  | NotionalAmount |  | Credit RiskAmount |  | NotionalAmount |  | Credit RiskAmount |
| Instruments designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 59,198 |  |  | $ | 2,803 |  |  | $ | 61,795 |  |  | $ | 1,798 |  |
| Interest rate contracts | $ | 27,350 |  |  | $ | 1,709 |  |  | $ | 31,250 |  |  | $ | 685 |  |
| Instruments not designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 91,165 |  |  | $ | 1,425 |  |  | $ | 76,868 |  |  | $ | 323 |  |

[0000320193-20-000052:notes:78]
[same as prior period, unchanged from 0000320193-20-000010:notes:78]

[0000320193-20-000052:notes:79]
The Company generally enters into master netting arrangements, which are designed to reduce credit risk by permitting net settlement of transactions with the same counterparty. To further limit credit risk, the Company generally enters into collateral security arrangements that provide for collateral to be received or posted when the net fair value of certain financial instruments fluctuates from contractually established thresholds. The Company presents its derivative assets and derivative liabilities at their gross fair values in its Condensed Consolidated Balance Sheets. As of March 28, 2020 and September 28, 2019, the net cash collateral received by the Company related to derivative instruments under its collateral security arrangements was $2.0 billion and $1.6 billion, respectively, which were included in other current liabilities in the Condensed Consolidated Balance Sheets.

[0000320193-20-000052:notes:80]
Under master netting arrangements with the respective counterparties to the Company’s derivative contracts, the Company is allowed to net settle transactions with a single net amount payable by one party to the other. As of March 28, 2020 and September 28, 2019, the potential effects of these rights of set-off associated with the Company’s derivative contracts, including the effects of collateral, would be a reduction to both derivative assets and derivative liabilities of $6.4 billion and $2.7 billion, respectively, resulting in net derivative liabilities of $279 million and $407 million, respectively.

[0000320193-20-000052:notes:81]
[same as prior period, unchanged from 0000320193-20-000010:notes:81]

[0000320193-20-000052:notes:82]
[same as prior period, unchanged from 0000320193-20-000010:notes:82]

[0000320193-20-000052:notes:83]
[same as prior period, unchanged from 0000320193-20-000010:notes:83]

[0000320193-20-000052:notes:84]
As of both March 28, 2020 and September 28, 2019, the Company had no customers that individually represented 10% or more of total trade receivables. The Company’s cellular network carriers accounted for 41% and 51% of total trade receivables as of March 28, 2020 and September 28, 2019, respectively.

[0000320193-20-000052:notes:85]
[same as prior period, unchanged from 0000320193-20-000010:notes:85]

[0000320193-20-000052:notes:86]
The Company has non-trade receivables from certain of its manufacturing vendors resulting from the sale of components to these vendors who manufacture sub-assemblies or assemble final products for the Company. The Company purchases these components directly from suppliers. As of March 28, 2020, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 53% and 16%. As of September 28, 2019, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 59% and 14%.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000320193-20-000052:notes:87]
[same as prior period, unchanged from 0000320193-20-000010:notes:87]

[0000320193-20-000052:notes:88]
[same as prior period, unchanged from 0000320193-20-000010:notes:88]


## us-gaap:DerivativesPolicyTextBlock

[0000320193-20-000052:notes:89]
Derivatives that are not designated as hedging instruments are adjusted to fair value through earnings in the financial statement line item to which the derivative relates.
The Company records all derivatives in the Condensed Consolidated Balance Sheets at fair value. The Company’s accounting treatment for these derivative instruments is based on its hedge designation.
The Company classifies cash flows related to derivative financial instruments as operating activities in its Condensed Consolidated Statements of Cash Flows.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000320193-20-000052:notes:90]
Condensed Consolidated Financial Statement Details
The following tables show the Company’s condensed consolidated financial statement details as of March 28, 2020 and September 28, 2019 (in millions):

[0000320193-20-000052:notes:91]
[same as prior period, unchanged from 0000320193-20-000010:notes:91]

[0000320193-20-000052:notes:92]
|  | March 28, 2020 |  | September 28, 2019 |
| Land and buildings | $ | 17,856 |  |  | $ | 17,085 |  |
| Machinery, equipment and internal-use software | 71,273 |  |  | 69,797 |  |
| Leasehold improvements | 9,614 |  |  | 9,075 |  |
| Gross property, plant and equipment | 98,743 |  |  | 95,957 |  |
| Accumulated depreciation and amortization | (62,854 | ) |  | (58,579 | ) |
| Total property, plant and equipment, net | $ | 35,889 |  |  | $ | 37,378 |  |

[0000320193-20-000052:notes:93]
[same as prior period, unchanged from 0000320193-20-000010:notes:93]

[0000320193-20-000052:notes:94]
|  | March 28, 2020 |  | September 28, 2019 |
| Long-term taxes payable | $ | 28,188 |  |  | $ | 29,545 |  |
| Other non-current liabilities | 28,607 |  |  | 20,958 |  |
| Total other non-current liabilities | $ | 56,795 |  |  | $ | 50,503 |  |

[0000320193-20-000052:notes:95]
[same as prior period, unchanged from 0000320193-20-000010:notes:95]

[0000320193-20-000052:notes:96]
The following table shows the detail of OI&E for the three- and six-month periods ended March 28, 2020 and March 30, 2019 (in millions):

[0000320193-20-000052:notes:97]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| Interest and dividend income | $ | 1,049 |  |  | $ | 1,358 |  |  | $ | 2,094 |  |  | $ | 2,665 |  |
| Interest expense | (757 | ) |  | (1,010 | ) |  | (1,542 | ) |  | (1,900 | ) |
| Other income/(expense), net | (10 | ) |  | 30 |  |  | 79 |  |  | 173 |  |
| Total other income/(expense), net | $ | 282 |  |  | $ | 378 |  |  | $ | 631 |  |  | $ | 938 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000320193-20-000052:notes:98]
[same as prior period, unchanged from 0000320193-20-000010:notes:98]

[0000320193-20-000052:notes:99]
As of March 28, 2020, the total amount of gross unrecognized tax benefits was $16.7 billion, of which $8.9 billion, if recognized, would impact the Company’s effective tax rate. The Company had accrued $1.3 billion of gross interest and penalties related to income tax matters as of March 28, 2020.

[0000320193-20-000052:notes:100]
[same as prior period, unchanged from 0000320193-20-000010:notes:100]

[0000320193-20-000052:notes:101]
[same as prior period, unchanged from 0000320193-20-000010:notes:101]

[0000320193-20-000052:notes:102]
On August 30, 2016, the European Commission announced its decision that Ireland granted state aid to the Company by providing tax opinions in 1991 and 2007 concerning the tax allocation of profits of the Irish branches of two subsidiaries of the Company (the “State Aid Decision”). The State Aid Decision ordered Ireland to calculate and recover additional taxes from the Company for the period June 2003 through December 2014. The recovery amount was calculated to be €13.1 billion, plus interest of €1.2 billion. On an annual basis, the Company may request approval from the Irish Minister for Finance to reduce the recovery amount for certain taxes paid to other countries. As of March 28, 2020, the adjusted recovery amount was €12.9 billion, excluding interest. Irish legislative changes, effective as of January 2015, eliminated the application of the tax opinions from that date forward. The Company believes the State Aid Decision to be without merit and appealed to the General Court of the Court of Justice of the European Union. Ireland has also appealed the State Aid Decision. The Company believes that any incremental Irish corporate income taxes potentially due related to the State Aid Decision would be creditable against U.S. taxes, subject to any foreign tax credit limitations in the U.S. Tax Cuts and Jobs Act. The adjusted recovery amount plus interest is funded into escrow, where it will remain restricted from general use pending the conclusion of all appeals. Refer to the Cash, Cash Equivalents and Marketable Securities section of Note 3, “Financial Instruments” for more information.


## us-gaap:DebtDisclosureTextBlock

[0000320193-20-000052:notes:103]
Debt
Commercial Paper and Repurchase Agreement

[0000320193-20-000052:notes:104]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of March 28, 2020 and September 28, 2019, the Company had $7.5 billion and $6.0 billion of Commercial Paper outstanding, respectively, with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 1.39% and 2.24% as of March 28, 2020 and September 28, 2019, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the six months ended March 28, 2020 and March 30, 2019 (in millions):

[0000320193-20-000052:notes:105]
|  | Six Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | 1,377 |  |  | $ | (2,484 | ) |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 4,797 |  |  | 10,235 |  |
| Repayments of commercial paper | (4,656 | ) |  | (7,787 | ) |
| Proceeds from commercial paper, net | 141 |  |  | 2,448 |  |
| Total proceeds from/(repayments of) commercial paper, net | $ | 1,518 |  |  | $ | (36 | ) |

[0000320193-20-000052:notes:106]
In the second quarter of 2020, the Company entered into an agreement to sell certain of its marketable securities with a promise to repurchase the securities at a specified time and amount (“Repo”). Due to the Company’s continuing involvement with the marketable securities, the Company accounts for the Repo as a collateralized borrowing. As of March 28, 2020, the Company had a $2.6 billion Repo liability with a maturity of less than six months, and had pledged $2.6 billion of marketable securities as collateral.

[0000320193-20-000052:notes:107]
Term Debt

[0000320193-20-000052:notes:108]
As of March 28, 2020, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $98.0 billion (collectively the “Notes”). The Notes are senior unsecured obligations and interest is payable in arrears. The following table provides a summary of the Company’s term debt as of March 28, 2020 and September 28, 2019:

[0000320193-20-000052:notes:109]
|  | Maturities(calendar year) |  | March 28, 2020 |  | September 28, 2019 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 – 2019 debt issuances: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2020 | – | 2022 |  | $ | 3,250 |  |  |  | 1.80% | – | 2.81 | % |  | $ | 4,250 |  |  |  | 2.25% | – | 3.28 | % |
| Fixed-rate 0.350% – 4.650% notes | 2020 | – | 2049 |  | 92,554 |  |  |  | 0.28% | – | 4.78 | % |  | 97,429 |  |  |  | 0.28% | – | 4.78 | % |
| First quarter 2020 debt issuance of €2.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.000% – 0.500% notes | 2025 | – | 2031 |  | 2,164 |  |  |  | 0.03% | – | 0.56 | % |  | — |  |  |  |  |  | — | % |
| Total term debt |  |  |  |  | 97,968 |  |  |  |  |  |  |  | 101,679 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (220 | ) |  |  |  |  |  |  | (224 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | 1,730 |  |  |  |  |  |  |  | 612 |  |  |  |  |  |  |
| Less: Current portion of term debt |  |  |  |  | (10,392 | ) |  |  |  |  |  |  | (10,260 | ) |  |  |  |  |  |
| Total non-current portion of term debt |  |  |  |  | $ | 89,086 |  |  |  |  |  |  |  | $ | 91,807 |  |  |  |  |  |  |

[0000320193-20-000052:notes:110]
To manage interest rate risk on certain of its U.S. dollar–denominated fixed- or floating-rate notes, the Company has entered into interest rate swaps to effectively convert the fixed interest rates to floating interest rates or the floating interest rates to fixed interest rates on a portion of these notes. Additionally, to manage foreign currency risk on certain of its foreign currency–denominated notes, the Company has entered into foreign currency swaps to effectively convert these notes to U.S. dollar–denominated notes.

[0000320193-20-000052:notes:111]
A portion of the Company’s Japanese yen–denominated notes is designated as a hedge of the foreign currency exposure of the Company’s net investment in a foreign operation. As of March 28, 2020 and September 28, 2019, the carrying value of the debt designated as a net investment hedge was $663 million and $1.0 billion, respectively. For further discussion regarding the Company’s use of derivative instruments, refer to the Derivative Financial Instruments section of Note 3, “Financial Instruments.”

[0000320193-20-000052:notes:112]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $725 million and $1.5 billion of interest cost on its term debt for the three- and six-month periods ended March 28, 2020, respectively. The Company recognized $828 million and $1.6 billion of interest cost on its term debt for the three- and six-month periods ended March 30, 2019, respectively.

[0000320193-20-000052:notes:113]
As of March 28, 2020 and September 28, 2019, the fair value of the Company’s Notes, based on Level 2 inputs, was $105.6 billion and $107.5 billion, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000320193-20-000052:notes:114]
Shareholders’ Equity
As of March 28, 2020, the Company was authorized to purchase up to $175 billion of the Company’s common stock under a share repurchase program, of which $134.6 billion had been utilized. During the six months ended March 28, 2020, the Company repurchased 135.0 million shares of its common stock for $38.5 billion, including 30.4 million shares initially delivered under a $10.0 billion accelerated share repurchase arrangement (“ASR”) dated November 2019. On April 30, 2020, the Company announced the Board of Directors increased the share repurchase program authorization by $50 billion. The Company’s share repurchase program does not obligate it to acquire any specific number of shares. Under this program, shares may be repurchased in privately negotiated and/or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).

[0000320193-20-000052:notes:115]
Under the Company’s ASR, financial institutions deliver shares of the Company’s common stock during the purchase period in exchange for an up-front payment. The total number of shares ultimately delivered under the ASR, and therefore the average repurchase price paid per share, is determined based on the volume-weighted average price of the Company’s common stock during the purchase period, which will end in May 2020. The shares received are retired in the periods they are delivered, and the up-front payment is accounted for as a reduction to retained earnings in the Company’s Condensed Consolidated Statement of Shareholders’ Equity in the period the payment is made.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000320193-20-000052:notes:116]
Comprehensive Income
The Company’s OCI consists of foreign currency translation adjustments from those subsidiaries not using the U.S. dollar as their functional currency, net deferred gains and losses on certain derivative instruments accounted for as hedges, and unrealized gains and losses on marketable debt securities classified as available-for-sale.

[0000320193-20-000052:notes:117]
The following table shows the pre-tax amounts reclassified from AOCI into the Condensed Consolidated Statements of Operations, and the associated financial statement line items, for the three- and six-month periods ended March 28, 2020 and March 30, 2019 (in millions):

[0000320193-20-000052:notes:118]
|  |  |  |  | Three Months Ended |  | Six Months Ended |
| Comprehensive Income Components |  | Financial Statement Line Items |  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| Unrealized (gains)/losses on derivative instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Total net sales |  | $ | 34 |  |  | $ | (97 | ) |  | $ | (63 | ) |  | $ | (34 | ) |
|  |  | Total cost of sales |  | 12 |  |  | (76 | ) |  | (159 | ) |  | (451 | ) |
|  |  | Other income/(expense), net |  | 771 |  |  | 52 |  |  | 548 |  |  | 448 |  |
| Interest rate contracts |  | Other income/(expense), net |  | 1 |  |  | 2 |  |  | 3 |  |  | 3 |  |
|  |  |  |  | 818 |  |  | (119 | ) |  | 329 |  |  | (34 | ) |
| Unrealized (gains)/losses on marketable debt securities |  | Other income/(expense), net |  | 37 |  |  | 36 |  |  | 24 |  |  | 83 |  |
| Total amounts reclassified from AOCI |  | $ | 855 |  |  | $ | (83 | ) |  | $ | 353 |  |  | $ | 49 |  |

[0000320193-20-000052:notes:119]
The following table shows the changes in AOCI by component for the six months ended March 28, 2020 (in millions):

[0000320193-20-000052:notes:120]
|  | Cumulative ForeignCurrency Translation |  | Unrealized Gains/Losseson Derivative Instruments |  | Unrealized Gains/Losseson Marketable Debt Securities |  | Total |
| Balances as of September 28, 2019 | $ | (1,463 | ) |  | $ | 172 |  |  | $ | 707 |  |  | $ | (584 | ) |
| Other comprehensive income/(loss) before reclassifications | (356 | ) |  | (151 | ) |  | (2,860 | ) |  | (3,367 | ) |
| Amounts reclassified from AOCI | — |  |  | 329 |  |  | 24 |  |  | 353 |  |
| Tax effect | (8 | ) |  | 26 |  |  | 655 |  |  | 673 |  |
| Other comprehensive income/(loss) | (364 | ) |  | 204 |  |  | (2,181 | ) |  | (2,341 | ) |
| Cumulative effect of change in accounting principle (1) | — |  |  | 136 |  |  | — |  |  | 136 |  |
| Balances as of March 28, 2020 | $ | (1,827 | ) |  | $ | 512 |  |  | $ | (1,474 | ) |  | $ | (2,789 | ) |

[0000320193-20-000052:notes:121]
[same as prior period, unchanged from 0000320193-20-000010:notes:120]

[0000320193-20-000052:notes:122]
Refer to Note 1, “Summary of Significant Accounting Policies” for more information on the Company’s adoption of ASU 2017-12 at the beginning of the first quarter of 2020.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000320193-20-000052:notes:123]
[same as prior period, unchanged from 0000320193-20-000010:notes:122]

[0000320193-20-000052:notes:124]
The Company had 193.7 million shares reserved for future issuance under its stock plans as of March 28, 2020. Restricted stock units (“RSUs”) granted under the Company’s stock plans generally vest over four years, based on continued employment, and are settled upon vesting in shares of the Company’s common stock on a one-for-one basis. RSUs granted under the Company’s stock plans reduce the number of shares available for grant under the plans by a factor of two times the number of RSUs granted. RSUs canceled and shares withheld to satisfy tax withholding obligations increase the number of shares available for grant under the plans utilizing a factor of two times the number of RSUs canceled or shares withheld.

[0000320193-20-000052:notes:125]
[same as prior period, unchanged from 0000320193-20-000010:notes:124]

[0000320193-20-000052:notes:126]
During the three months ended March 28, 2020, Section 16 officers Timothy D. Cook, Chris Kondo, Luca Maestri, Deirdre O’Brien and Jeffrey Williams had equity trading plans in place in accordance with Rule 10b5-1(c)(1) under the Exchange Act. An equity trading plan is a written document that pre-establishes the amounts, prices and dates (or formula for determining the amounts, prices and dates) of future purchases or sales of the Company’s stock, including shares acquired under the Company’s employee and director equity plans.

[0000320193-20-000052:notes:127]
[same as prior period, unchanged from 0000320193-20-000010:notes:126]

[0000320193-20-000052:notes:128]
A summary of the Company’s RSU activity and related information for the six months ended March 28, 2020 is as follows:

[0000320193-20-000052:notes:129]
|  | Number ofRSUs(in thousands) |  | Weighted-AverageGrant Date FairValue Per RSU |  | AggregateFair Value(in millions) |
| Balance as of September 28, 2019 | 81,517 |  |  | $ | 169.18 |  |  |  |
| RSUs granted | 35,639 |  |  | $ | 225.14 |  |  |  |
| RSUs vested | (19,660 | ) |  | $ | 151.02 |  |  |  |
| RSUs canceled | (2,316 | ) |  | $ | 187.21 |  |  |  |
| Balance as of March 28, 2020 | 95,180 |  |  | $ | 193.45 |  |  | $ | 23,580 |  |

[0000320193-20-000052:notes:130]
The fair value as of the respective vesting dates of RSUs was $558 million and $4.8 billion for the three- and six-month periods ended March 28, 2020, respectively, and was $348 million and $4.4 billion for the three- and six-month periods ended March 30, 2019, respectively.

[0000320193-20-000052:notes:131]
[same as prior period, unchanged from 0000320193-20-000010:notes:130]

[0000320193-20-000052:notes:132]
The following table shows share-based compensation expense and the related income tax benefit included in the Condensed Consolidated Statements of Operations for the three- and six-month periods ended March 28, 2020 and March 30, 2019 (in millions):

[0000320193-20-000052:notes:133]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| Share-based compensation expense | $ | 1,697 |  |  | $ | 1,514 |  |  | $ | 3,407 |  |  | $ | 3,073 |  |
| Income tax benefit related to share-based compensation expense | $ | (444 | ) |  | $ | (331 | ) |  | $ | (1,202 | ) |  | $ | (1,081 | ) |

[0000320193-20-000052:notes:134]
As of March 28, 2020, the total unrecognized compensation cost related to outstanding RSUs and stock options was $14.5 billion, which the Company expects to recognize over a weighted-average period of 2.8 years.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000320193-20-000052:notes:135]
Commitments and Contingencies
Accrued Warranty and Guarantees

[0000320193-20-000052:notes:136]
The following table shows changes in the Company’s accrued warranties and related costs for the three- and six-month periods ended March 28, 2020 and March 30, 2019 (in millions):

[0000320193-20-000052:notes:137]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| Beginning accrued warranty and related costs | $ | 3,873 |  |  | $ | 3,819 |  |  | $ | 3,570 |  |  | $ | 3,692 |  |
| Cost of warranty claims | (689 | ) |  | (915 | ) |  | (1,604 | ) |  | (1,911 | ) |
| Accruals for product warranty | 739 |  |  | 583 |  |  | 1,957 |  |  | 1,706 |  |
| Ending accrued warranty and related costs | $ | 3,923 |  |  | $ | 3,487 |  |  | $ | 3,923 |  |  | $ | 3,487 |  |

[0000320193-20-000052:notes:138]
The Company offers an iPhone Upgrade Program, which is available to customers who purchase a qualifying iPhone in the U.S., the U.K. and mainland China. The iPhone Upgrade Program provides customers the right to trade in that iPhone for a specified amount when purchasing a new iPhone, provided certain conditions are met. The Company accounts for the trade-in right as a guarantee liability and recognizes arrangement revenue net of the fair value of such right, with subsequent changes to the guarantee liability recognized within net sales.

[0000320193-20-000052:notes:139]
Concentrations in the Available Sources of Supply of Materials and Product

[0000320193-20-000052:notes:140]
Although most components essential to the Company’s business are generally available from multiple sources, certain components are currently obtained from single or limited sources. The Company also competes for various components with other participants in the markets for smartphones, personal computers, tablets and other electronic devices. Therefore, many components used by the Company, including those that are available from multiple sources, are at times subject to industry-wide shortage and significant commodity pricing fluctuations.

[0000320193-20-000052:notes:141]
The Company uses some custom components that are not commonly used by its competitors, and new products introduced by the Company often utilize custom components available from only one source. When a component or product uses new technologies, initial capacity constraints may exist until the suppliers’ yields have matured or their manufacturing capacities have increased. The continued availability of these components at acceptable prices, or at all, may be affected if suppliers decide to concentrate on the production of common components instead of components customized to meet the Company’s requirements.

[0000320193-20-000052:notes:142]
The Company has entered into agreements for the supply of many components; however, there can be no guarantee that the Company will be able to extend or renew these agreements on similar terms, or at all.

[0000320193-20-000052:notes:143]
Substantially all of the Company’s hardware products are manufactured by outsourcing partners that are located primarily in Asia, with some Mac computers manufactured in the U.S. and Ireland.

[0000320193-20-000052:notes:144]
Unconditional Purchase Obligations

[0000320193-20-000052:notes:145]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of payments for supplier arrangements, Internet and telecommunication services, intellectual property licenses and content creation. As of March 28, 2020, the Company’s total future payments under noncancelable unconditional purchase obligations having a remaining term in excess of one year were $9.9 billion.

[0000320193-20-000052:notes:146]
Contingencies

[0000320193-20-000052:notes:147]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully resolved. The outcome of litigation is inherently uncertain. If one or more legal matters were resolved against the Company in a reporting period for amounts above management’s expectations, the Company’s financial condition and operating results for that reporting period could be materially adversely affected. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss greater than a recorded accrual, concerning loss contingencies for asserted legal and other claims, except for the following matters:

[0000320193-20-000052:notes:148]
VirnetX

[0000320193-20-000052:notes:149]
VirnetX, Inc. (“VirnetX”) filed two lawsuits in the U.S. District Court for the Eastern District of Texas (the “Eastern Texas District Court”) against the Company alleging that certain Company products infringe four patents (the “VirnetX Patents”) relating to network communications technology (“VirnetX I” and “VirnetX II”). On September 30, 2016, a jury returned a verdict in VirnetX I against the Company and awarded damages of $302 million, which later increased to $440 million in post-trial proceedings. The Company appealed the VirnetX I verdict to the U.S. Court of Appeals for the Federal Circuit (the “Federal Circuit”). On April 11, 2018, a jury returned a verdict in VirnetX II against the Company and awarded damages of $503 million. The Company appealed the VirnetX II verdict to the Federal Circuit, and on November 22, 2019, the Federal Circuit affirmed-in-part, reversed-in-part, and remanded VirnetX II back to the Eastern Texas District Court. The Company has challenged the validity of the VirnetX Patents at the U.S. Patent and Trademark Office (the “PTO”). In response, the PTO has declared the VirnetX Patents invalid. VirnetX appealed the invalidity decision of the PTO to the Federal Circuit. The Federal Circuit consolidated the Company’s appeal of the Eastern Texas District Court VirnetX I verdict and VirnetX’s appeals from the PTO invalidity proceedings. On January 15, 2019, the Federal Circuit affirmed the VirnetX I verdict, which the Company subsequently paid, including damages and interest. On July 8, 2019, the Federal Circuit remanded one of VirnetX’s two appeals of the PTO’s invalidity decisions back to the PTO for further proceedings. On August 1, 2019, the Federal Circuit affirmed-in-part, vacated-in-part, and remanded back to the PTO portions of VirnetX’s second appeal.

[0000320193-20-000052:notes:150]
iOS Performance Management Cases

[0000320193-20-000052:notes:151]
Various civil litigation matters have been filed in state and federal courts in the U.S. and in various international jurisdictions alleging violation of consumer protection laws, fraud, computer intrusion and other causes of action related to the Company’s performance management feature used in its iPhone operating systems, introduced to certain iPhones in iOS updates 10.2.1 and 11.2. The claims seek monetary damages and other non-monetary relief. On April 5, 2018, several U.S. federal actions were consolidated through a Multidistrict Litigation process into a single action in the U.S. District Court for the Northern District of California (the “Northern California District Court”). On February 28, 2020, the parties in the Multidistrict Litigation reached a settlement to resolve the U.S. federal and California state class actions. Under the terms of the settlement, which is subject to the Northern California District Court’s approval, the Company has agreed to pay up to $500 million in the aggregate to certain U.S. owners of iPhones if certain conditions are met. The final amount of the settlement will be determined based on the number of consumers who file valid claims and the attorneys’ fee award. However, the Company has agreed to pay at least $310 million to settle the claims. In addition to civil litigation, the Company is also responding to governmental investigations and requests for information relating to the performance management feature. The Company continues to believe that its iPhones were not defective, that the performance management feature introduced with iOS updates 10.2.1 and 11.2 was intended to, and did, improve customers’ user experience, and that the Company did not make any misleading statements or fail to disclose any material information. The Company has accrued its best estimate for the ultimate resolution of these matters.

[0000320193-20-000052:notes:152]
French Competition Authority

[0000320193-20-000052:notes:153]
On March 16, 2020, the French Competition Authority (“FCA”) announced its decision that aspects of the Company’s sales and distribution practices in France violate French competition law, and issued a fine of €1.1 billion. The Company strongly disagrees with the FCA’s decision, and plans to appeal.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000320193-20-000052:notes:154]
[same as prior period, unchanged from 0000320193-20-000010:notes:153]

[0000320193-20-000052:notes:155]
[same as prior period, unchanged from 0000320193-20-000010:notes:154]

[0000320193-20-000052:notes:156]
[same as prior period, unchanged from 0000320193-20-000010:notes:155]

[0000320193-20-000052:notes:157]
The following table shows information by reportable segment for the three- and six-month periods ended March 28, 2020 and March 30, 2019 (in millions):

[0000320193-20-000052:notes:158]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| Americas: |  |  |  |  |  |  |  |
| Net sales | $ | 25,473 |  |  | $ | 25,596 |  |  | $ | 66,840 |  |  | $ | 62,536 |  |
| Operating income | $ | 7,261 |  |  | $ | 7,687 |  |  | $ | 20,353 |  |  | $ | 18,887 |  |
| Europe: |  |  |  |  |  |  |  |
| Net sales | $ | 14,294 |  |  | $ | 13,054 |  |  | $ | 37,567 |  |  | $ | 33,417 |  |
| Operating income | $ | 4,528 |  |  | $ | 4,026 |  |  | $ | 12,247 |  |  | $ | 10,684 |  |
| Greater China: |  |  |  |  |  |  |  |
| Net sales | $ | 9,455 |  |  | $ | 10,218 |  |  | $ | 23,033 |  |  | $ | 23,387 |  |
| Operating income | $ | 3,758 |  |  | $ | 3,607 |  |  | $ | 9,121 |  |  | $ | 8,921 |  |
| Japan: |  |  |  |  |  |  |  |
| Net sales | $ | 5,206 |  |  | $ | 5,532 |  |  | $ | 11,429 |  |  | $ | 12,442 |  |
| Operating income | $ | 2,236 |  |  | $ | 2,390 |  |  | $ | 5,014 |  |  | $ | 5,404 |  |
| Rest of Asia Pacific: |  |  |  |  |  |  |  |
| Net sales | $ | 3,885 |  |  | $ | 3,615 |  |  | $ | 11,263 |  |  | $ | 10,543 |  |
| Operating income | $ | 1,290 |  |  | $ | 1,096 |  |  | $ | 4,021 |  |  | $ | 3,656 |  |

[0000320193-20-000052:notes:159]
A reconciliation of the Company’s segment operating income to the Condensed Consolidated Statements of Operations for the three- and six-month periods ended March 28, 2020 and March 30, 2019 is as follows (in millions):

[0000320193-20-000052:notes:160]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| Segment operating income | $ | 19,073 |  |  | $ | 18,806 |  |  | $ | 50,756 |  |  | $ | 47,552 |  |
| Research and development expense | (4,565 | ) |  | (3,948 | ) |  | (9,016 | ) |  | (7,850 | ) |
| Other corporate expenses, net | (1,655 | ) |  | (1,443 | ) |  | (3,318 | ) |  | (2,941 | ) |
| Total operating income | $ | 12,853 |  |  | $ | 13,415 |  |  | $ | 38,422 |  |  | $ | 36,761 |  |


## us-gaap:LesseeFinanceLeasesTextBlock

[0000320193-20-000052:notes:161]
[same as prior period, unchanged from 0000320193-20-000010:notes:160]

[0000320193-20-000052:notes:162]
[same as prior period, unchanged from 0000320193-20-000010:notes:161]

[0000320193-20-000052:notes:163]
Payments under the Company’s lease arrangements may be fixed or variable, and variable lease payments are primarily based on purchases of output of the underlying leased assets. Lease costs associated with fixed payments on the Company’s operating leases were $363 million and $732 million for the three- and six-month periods ended March 28, 2020, respectively. Lease costs associated with variable payments on the Company’s leases were $1.9 billion and $4.8 billion for the three- and six-month periods ended March 28, 2020, respectively.

[0000320193-20-000052:notes:164]
For the three- and six-month periods ended March 28, 2020, the Company made $353 million and $702 million of fixed cash payments related to operating leases, respectively. Non-cash activities involving ROU assets obtained in exchange for lease liabilities were $1.2 billion and $9.3 billion for the three- and six-month periods ended March 28, 2020, respectively, including the impact of adopting the new leases standard in the first quarter of 2020.

[0000320193-20-000052:notes:165]
The following table shows ROU assets and lease liabilities, and the associated financial statement line items, as of March 28, 2020 (in millions):

[0000320193-20-000052:notes:166]
| Lease-Related Assets and Liabilities |  | Financial Statement Line Items |  | March 28, 2020 |
| Right-of-use assets: |  |  |  |  |
| Operating leases |  | Other non-current assets |  | $ | 8,097 |  |
| Finance leases |  | Property, plant and equipment, net |  | 631 |  |
| Total right-of-use assets |  |  |  | $ | 8,728 |  |
| Lease liabilities: |  |  |  |  |
| Operating leases |  | Other current liabilities |  | $ | 1,185 |  |
|  |  | Other non-current liabilities |  | 7,421 |  |
| Finance leases |  | Other current liabilities |  | 19 |  |
|  |  | Other non-current liabilities |  | 629 |  |
| Total lease liabilities |  |  |  | $ | 9,254 |  |

[0000320193-20-000052:notes:167]
Lease liability maturities as of March 28, 2020, are as follows (in millions):

[0000320193-20-000052:notes:168]
|  | OperatingLeases |  | FinanceLeases |  | Total |
| 2020 (remaining six months) | $ | 559 |  |  | $ | 14 |  |  | $ | 573 |  |
| 2021 | 1,428 |  |  | 40 |  |  | 1,468 |  |
| 2022 | 1,298 |  |  | 38 |  |  | 1,336 |  |
| 2023 | 1,091 |  |  | 49 |  |  | 1,140 |  |
| 2024 | 951 |  |  | 26 |  |  | 977 |  |
| Thereafter | 4,269 |  |  | 920 |  |  | 5,189 |  |
| Total undiscounted liabilities | 9,596 |  |  | 1,087 |  |  | 10,683 |  |
| Less: Imputed interest | (990 | ) |  | (439 | ) |  | (1,429 | ) |
| Total lease liabilities | $ | 8,606 |  |  | $ | 648 |  |  | $ | 9,254 |  |

[0000320193-20-000052:notes:169]
The weighted-average remaining lease term and discount rate related to the Company’s lease liabilities as of March 28, 2020 were 10.7 years and 2.2%, respectively. The Company’s lease discount rates are generally based on estimates of its incremental borrowing rate, as the discount rates implicit in the Company’s leases cannot be readily determined.

[0000320193-20-000052:notes:170]
As of March 28, 2020, the Company had $1.8 billion of future payments under additional leases, primarily for corporate facilities and retail space, that had not yet commenced. These leases will commence between 2020 and 2022, with lease terms ranging from less than 1 year to 21 years.
