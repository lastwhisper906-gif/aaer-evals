# AAPL note change history — 0000320193-20-000010 → 0000320193-20-000052


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-05-01):
[0000320193-20-000052:note_history:1]
The following table shows changes in the Company’s accrued warranties and related costs for the three- and six-month periods ended March 28, 2020 and March 30, 2019 (in millions):
  (was, 2020-01-29, similarity 0.8963):
[0000320193-20-000010:note_history:1]
The following table shows changes in the Company’s accrued warranties and related costs for the three months ended December 28, 2019 and December 29, 2018 (in millions):

- changed (2020-05-01):
[0000320193-20-000052:note_history:2]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| Beginning accrued warranty and related costs | $ | 3,873 |  |  | $ | 3,819 |  |  | $ | 3,570 |  |  | $ | 3,692 |  |
| Cost of warranty claims | (689 | ) |  | (915 | ) |  | (1,604 | ) |  | (1,911 | ) |
| Accruals for product warranty | 739 |  |  | 583 |  |  | 1,957 |  |  | 1,706 |  |
| Ending accrued warranty and related costs | $ | 3,923 |  |  | $ | 3,487 |  |  | $ | 3,923 |  |  | $ | 3,487 |  |
  (was, 2020-01-29, similarity 0.7204):
[0000320193-20-000010:note_history:2]
|  | Three Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |
| Beginning accrued warranty and related costs | $ | 3,570 |  |  | $ | 3,692 |  |
| Cost of warranty claims | (915 | ) |  | (996 | ) |
| Accruals for product warranty | 1,218 |  |  | 1,123 |  |
| Ending accrued warranty and related costs | $ | 3,873 |  |  | $ | 3,819 |  |

- changed (2020-05-01):
[0000320193-20-000052:note_history:3]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of payments for supplier arrangements, Internet and telecommunication services, intellectual property licenses and content creation. As of March 28, 2020, the Company’s total future payments under noncancelable unconditional purchase obligations having a remaining term in excess of one year were $9.9 billion.
  (was, 2020-01-29, similarity 0.9878):
[0000320193-20-000010:note_history:3]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of payments for supplier arrangements, Internet and telecommunication services, intellectual property licenses and content creation. As of December 28, 2019, the Company’s total future payments under noncancelable unconditional purchase obligations having a remaining term in excess of one year were $10.5 billion.

- changed (2020-05-01):
[0000320193-20-000052:note_history:4]
VirnetX, Inc. (“VirnetX”) filed two lawsuits in the U.S. District Court for the Eastern District of Texas (the “Eastern Texas District Court”) against the Company alleging that certain Company products infringe four patents (the “VirnetX Patents”) relating to network communications technology (“VirnetX I” and “VirnetX II”). On September 30, 2016, a jury returned a verdict in VirnetX I against the Company and awarded damages of $302 million, which later increased to $440 million in post-trial proceedings. The Company appealed the VirnetX I verdict to the U.S. Court of Appeals for the Federal Circuit (the “Federal Circuit”). On April 11, 2018, a jury returned a verdict in VirnetX II against the Company and awarded damages of $503 million. The Company appealed the VirnetX II verdict to the Federal Circuit, and on November 22, 2019, the Federal Circuit affirmed-in-part, reversed-in-part, and remanded VirnetX II back to the Eastern Texas District Court. The Company has challenged the validity of the VirnetX Patents at the U.S. Patent and Trademark Office (the “PTO”). In response, the PTO has declared the VirnetX Patents invalid. VirnetX appealed the invalidity decision of the PTO to the Federal Circuit. The Federal Circuit consolidated the Company’s appeal of the Eastern Texas District Court VirnetX I verdict and VirnetX’s appeals from the PTO invalidity proceedings. On January 15, 2019, the Federal Circuit affirmed the VirnetX I verdict, which the Company subsequently paid, including damages and interest. On July 8, 2019, the Federal Circuit remanded one of VirnetX’s two appeals of the PTO’s invalidity decisions back to the PTO for further proceedings. On August 1, 2019, the Federal Circuit affirmed-in-part, vacated-in-part, and remanded back to the PTO portions of VirnetX’s second appeal.
  (was, 2020-01-29, similarity 0.8042):
[0000320193-20-000010:note_history:4]
VirnetX, Inc. (“VirnetX”) filed two lawsuits in the U.S. District Court for the Eastern District of Texas (the “Eastern Texas District Court”) against the Company alleging that certain Company products infringe four patents (the “VirnetX Patents”) relating to network communications technology (“VirnetX I” and “VirnetX II”). On September 30, 2016, a jury returned a verdict in VirnetX I against the Company and awarded damages of $302 million, which later increased to $440 million in post-trial proceedings. The Company appealed the VirnetX I verdict to the U.S. Court of Appeals for the Federal Circuit (the “Federal Circuit”). On April 11, 2018, a jury returned a verdict in VirnetX II against the Company and awarded damages of $503 million. The Company appealed the VirnetX II verdict to the Federal Circuit, and on November 22, 2019, the Federal Circuit affirmed-in-part, reversed-in-part, and remanded VirnetX II back to the Eastern Texas District Court. The Company has challenged the validity of the VirnetX Patents at the U.S. Patent and Trademark Office (the “PTO”). In response, the PTO has declared the VirnetX Patents invalid. VirnetX appealed the invalidity decision of the PTO to the Federal Circuit. The Federal Circuit consolidated the Company’s appeal of the Eastern Texas District Court VirnetX I verdict and VirnetX’s appeals from the PTO invalidity proceedings. On January 15, 2019, the Federal Circuit affirmed the VirnetX I verdict, which the Company has further appealed. On July 8, 2019, the Federal Circuit remanded one of VirnetX’s two appeals of the PTO’s invalidity decisions back to the PTO for further proceedings. On August 1, 2019, the Federal Circuit affirmed-in-part, vacated-in-part, and remanded back to the PTO portions of VirnetX’s second appeal. The Company has accrued its best estimate for the ultimate resolution of these matters.

- added (2020-05-01):
[0000320193-20-000052:note_history:5]
Various civil litigation matters have been filed in state and federal courts in the U.S. and in various international jurisdictions alleging violation of consumer protection laws, fraud, computer intrusion and other causes of action related to the Company’s performance management feature used in its iPhone operating systems, introduced to certain iPhones in iOS updates 10.2.1 and 11.2. The claims seek monetary damages and other non-monetary relief. On April 5, 2018, several U.S. federal actions were consolidated through a Multidistrict Litigation process into a single action in the U.S. District Court for the Northern District of California (the “Northern California District Court”). On February 28, 2020, the parties in the Multidistrict Litigation reached a settlement to resolve the U.S. federal and California state class actions. Under the terms of the settlement, which is subject to the Northern California District Court’s approval, the Company has agreed to pay up to $500 million in the aggregate to certain U.S. owners of iPhones if certain conditions are met. The final amount of the settlement will be determined based on the number of consumers who file valid claims and the attorneys’ fee award. However, the Company has agreed to pay at least $310 million to settle the claims. In addition to civil litigation, the Company is also responding to governmental investigations and requests for information relating to the performance management feature. The Company continues to believe that its iPhones were not defective, that the performance management feature introduced with iOS updates 10.2.1 and 11.2 was intended to, and did, improve customers’ user experience, and that the Company did not make any misleading statements or fail to disclose any material information. The Company has accrued its best estimate for the ultimate resolution of these matters.

- added (2020-05-01):
[0000320193-20-000052:note_history:6]
On March 16, 2020, the French Competition Authority (“FCA”) announced its decision that aspects of the Company’s sales and distribution practices in France violate French competition law, and issued a fine of €1.1 billion. The Company strongly disagrees with the FCA’s decision, and plans to appeal.

- removed (2020-05-01):
[0000320193-20-000010:note_history:7]
Various civil litigation matters have been filed in state and federal courts in the U.S. and in various international jurisdictions alleging violation of consumer protection laws, fraud, computer intrusion and other causes of action related to the Company’s performance management feature used in its iPhone operating systems, introduced to certain iPhones in iOS updates 10.2.1 and 11.2. The claims seek monetary damages and other non-monetary relief. On April 5, 2018, several U.S. federal actions were consolidated through a Multidistrict Litigation process into a single action in the U.S. District Court for the Northern District of California. In addition to civil litigation, the Company is also responding to governmental investigations and requests for information relating to the performance management feature. The Company believes that its iPhones were not defective, that the performance management feature introduced with iOS updates 10.2.1 and 11.2 was intended to, and did, improve customers’ user experience, and that the Company did not make any misleading statements or fail to disclose any material information. The Company has accrued its best estimate for the ultimate resolution of these matters.

- removed (2020-05-01):
[0000320193-20-000010:note_history:8]
In June 2019, the French Competition Authority (“FCA”) issued a report alleging that aspects of the Company’s sales and distribution practices in France violate French competition law. The Company vigorously disagrees with the allegations, and a hearing of arguments was held before the FCA on October 15, 2019. The Company is awaiting the decision of the FCA, which may include a fine.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-05-01):
[0000320193-20-000052:note_history:9]
The condensed consolidated financial statements include the accounts of Apple Inc. and its wholly owned subsidiaries (collectively “Apple” or the “Company”). Intercompany accounts and transactions have been eliminated. In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements and accompanying notes in conformity with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported. Actual results could differ materially from those estimates. Certain prior period amounts in the condensed consolidated financial statements and accompanying notes have been reclassified to conform to the current period’s presentation. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company’s annual consolidated financial statements and accompanying notes included in its Annual Report on Form 10-K for the fiscal year ended September 28, 2019 (the “2019 Form 10-K”).
  (was, 2020-01-29, similarity 0.9213):
[0000320193-20-000010:note_history:9]
The condensed consolidated financial statements include the accounts of Apple Inc. and its wholly owned subsidiaries (collectively “Apple” or the “Company”). Intercompany accounts and transactions have been eliminated. In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements and accompanying notes in conformity with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported. Actual results could differ materially from those estimates. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company’s annual consolidated financial statements and accompanying notes included in its Annual Report on Form 10-K for the fiscal year ended September 28, 2019 (the “2019 Form 10-K”).

- changed (2020-05-01):
[0000320193-20-000052:note_history:10]
The following table shows the computation of basic and diluted earnings per share for the three- and six-month periods ended March 28, 2020 and March 30, 2019 (net income in millions and shares in thousands):
  (was, 2020-01-29, similarity 0.9119):
[0000320193-20-000010:note_history:10]
The following table shows the computation of basic and diluted earnings per share for the three months ended December 28, 2019 and December 29, 2018 (net income in millions and shares in thousands):

- changed (2020-05-01):
[0000320193-20-000052:note_history:11]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 11,249 |  |  | $ | 11,561 |  |  | $ | 33,485 |  |  | $ | 31,526 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 4,360,101 |  |  | 4,674,071 |  |  | 4,387,570 |  |  | 4,704,945 |  |
| Effect of dilutive securities | 44,590 |  |  | 26,575 |  |  | 42,078 |  |  | 32,004 |  |
| Weighted-average diluted shares | 4,404,691 |  |  | 4,700,646 |  |  | 4,429,648 |  |  | 4,736,949 |  |
| Basic earnings per share | $ | 2.58 |  |  | $ | 2.47 |  |  | $ | 7.63 |  |  | $ | 6.70 |  |
| Diluted earnings per share | $ | 2.55 |  |  | $ | 2.46 |  |  | $ | 7.56 |  |  | $ | 6.66 |  |
  (was, 2020-01-29, similarity 0.7431):
[0000320193-20-000010:note_history:11]
|  | Three Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |
| Numerator: |  |  |  |
| Net income | $ | 22,236 |  |  | $ | 19,965 |  |
| Denominator: |  |  |  |
| Weighted-average basic shares outstanding | 4,415,040 |  |  | 4,735,820 |  |
| Effect of dilutive securities | 39,564 |  |  | 37,432 |  |
| Weighted-average diluted shares | 4,454,604 |  |  | 4,773,252 |  |
| Basic earnings per share | $ | 5.04 |  |  | $ | 4.22 |  |
| Diluted earnings per share | $ | 4.99 |  |  | $ | 4.18 |  |

- added (2020-05-01):
[0000320193-20-000052:note_history:12]
Potentially dilutive securities representing 31.1 million and 30.0 million shares of common stock were excluded from the computation of diluted earnings per share for the three- and six-month periods ended March 30, 2019, respectively, because their effect would have been antidilutive.

- removed (2020-05-01):
[0000320193-20-000010:note_history:13]
Potentially dilutive securities representing 28.8 million shares of common stock were excluded from the computation of diluted earnings per share for the three months ended December 29, 2018, because their effect would have been antidilutive.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-01):
[0000320193-20-000052:note_history:14]
Debt
Commercial Paper and Repurchase Agreement
  (was, 2020-01-29, similarity 0.6269):
[0000320193-20-000010:note_history:14]
Debt
Commercial Paper

- changed (2020-05-01):
[0000320193-20-000052:note_history:15]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of March 28, 2020 and September 28, 2019, the Company had $7.5 billion and $6.0 billion of Commercial Paper outstanding, respectively, with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 1.39% and 2.24% as of March 28, 2020 and September 28, 2019, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the six months ended March 28, 2020 and March 30, 2019 (in millions):
  (was, 2020-01-29, similarity 0.929):
[0000320193-20-000010:note_history:15]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of December 28, 2019 and September 28, 2019, the Company had $5.0 billion and $6.0 billion of Commercial Paper outstanding, respectively, with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 1.88% and 2.24% as of December 28, 2019 and September 28, 2019, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the three months ended December 28, 2019 and December 29, 2018 (in millions):

- added (2020-05-01):
[0000320193-20-000052:note_history:16]
|  | Six Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | 1,377 |  |  | $ | (2,484 | ) |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 4,797 |  |  | 10,235 |  |
| Repayments of commercial paper | (4,656 | ) |  | (7,787 | ) |
| Proceeds from commercial paper, net | 141 |  |  | 2,448 |  |
| Total proceeds from/(repayments of) commercial paper, net | $ | 1,518 |  |  | $ | (36 | ) |

- added (2020-05-01):
[0000320193-20-000052:note_history:17]
In the second quarter of 2020, the Company entered into an agreement to sell certain of its marketable securities with a promise to repurchase the securities at a specified time and amount (“Repo”). Due to the Company’s continuing involvement with the marketable securities, the Company accounts for the Repo as a collateralized borrowing. As of March 28, 2020, the Company had a $2.6 billion Repo liability with a maturity of less than six months, and had pledged $2.6 billion of marketable securities as collateral.

- changed (2020-05-01):
[0000320193-20-000052:note_history:18]
As of March 28, 2020, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $98.0 billion (collectively the “Notes”). The Notes are senior unsecured obligations and interest is payable in arrears. The following table provides a summary of the Company’s term debt as of March 28, 2020 and September 28, 2019:
  (was, 2020-01-29, similarity 0.9636):
[0000320193-20-000010:note_history:18]
As of December 28, 2019, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $103.1 billion (collectively the “Notes”). The Notes are senior unsecured obligations and interest is payable in arrears. The following table provides a summary of the Company’s term debt as of December 28, 2019 and September 28, 2019:

- changed (2020-05-01):
[0000320193-20-000052:note_history:19]
|  | Maturities(calendar year) |  | March 28, 2020 |  | September 28, 2019 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 – 2019 debt issuances: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2020 | – | 2022 |  | $ | 3,250 |  |  |  | 1.80% | – | 2.81 | % |  | $ | 4,250 |  |  |  | 2.25% | – | 3.28 | % |
| Fixed-rate 0.350% – 4.650% notes | 2020 | – | 2049 |  | 92,554 |  |  |  | 0.28% | – | 4.78 | % |  | 97,429 |  |  |  | 0.28% | – | 4.78 | % |
| First quarter 2020 debt issuance of €2.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.000% – 0.500% notes | 2025 | – | 2031 |  | 2,164 |  |  |  | 0.03% | – | 0.56 | % |  | — |  |  |  |  |  | — | % |
| Total term debt |  |  |  |  | 97,968 |  |  |  |  |  |  |  | 101,679 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (220 | ) |  |  |  |  |  |  | (224 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | 1,730 |  |  |  |  |  |  |  | 612 |  |  |  |  |  |  |
| Less: Current portion of term debt |  |  |  |  | (10,392 | ) |  |  |  |  |  |  | (10,260 | ) |  |  |  |  |  |
| Total non-current portion of term debt |  |  |  |  | $ | 89,086 |  |  |  |  |  |  |  | $ | 91,807 |  |  |  |  |  |  |
  (was, 2020-01-29, similarity 0.9938):
[0000320193-20-000010:note_history:19]
|  | Maturities(calendar year) |  | December 28, 2019 |  | September 28, 2019 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 – 2019 debt issuances: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2020 | – | 2022 |  | $ | 4,250 |  |  |  | 1.97% | – | 3.04 | % |  | $ | 4,250 |  |  |  | 2.25% | – | 3.28 | % |
| Fixed-rate 0.350% – 4.650% notes | 2020 | – | 2049 |  | 96,610 |  |  |  | 0.28% | – | 4.78 | % |  | 97,429 |  |  |  | 0.28% | – | 4.78 | % |
| First quarter 2020 debt issuance of €2.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.000% – 0.500% notes | 2025 | – | 2031 |  | 2,226 |  |  |  | 0.03% | – | 0.56 | % |  | — |  |  |  |  |  | — | % |
| Total term debt |  |  |  |  | 103,086 |  |  |  |  |  |  |  | 101,679 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (229 | ) |  |  |  |  |  |  | (224 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | 445 |  |  |  |  |  |  |  | 612 |  |  |  |  |  |  |
| Less: Current portion of term debt |  |  |  |  | (10,224 | ) |  |  |  |  |  |  | (10,260 | ) |  |  |  |  |  |
| Total non-current portion of term debt |  |  |  |  | $ | 93,078 |  |  |  |  |  |  |  | $ | 91,807 |  |  |  |  |  |  |

- changed (2020-05-01):
[0000320193-20-000052:note_history:20]
A portion of the Company’s Japanese yen–denominated notes is designated as a hedge of the foreign currency exposure of the Company’s net investment in a foreign operation. As of March 28, 2020 and September 28, 2019, the carrying value of the debt designated as a net investment hedge was $663 million and $1.0 billion, respectively. For further discussion regarding the Company’s use of derivative instruments, refer to the Derivative Financial Instruments section of Note 3, “Financial Instruments.”
  (was, 2020-01-29, similarity 0.9003):
[0000320193-20-000010:note_history:20]
A portion of the Company’s Japanese yen–denominated notes is designated as a hedge of the foreign currency exposure of the Company’s net investment in a foreign operation. As of December 28, 2019 and September 28, 2019, the carrying value of the debt designated as a net investment hedge was $1.2 billion and $1.0 billion, respectively. For further discussion regarding the Company’s use of derivative instruments, refer to the Derivative Financial Instruments section of Note 3, “Financial Instruments.”

- added (2020-05-01):
[0000320193-20-000052:note_history:21]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $725 million and $1.5 billion of interest cost on its term debt for the three- and six-month periods ended March 28, 2020, respectively. The Company recognized $828 million and $1.6 billion of interest cost on its term debt for the three- and six-month periods ended March 30, 2019, respectively.

- changed (2020-05-01):
[0000320193-20-000052:note_history:22]
As of March 28, 2020 and September 28, 2019, the fair value of the Company’s Notes, based on Level 2 inputs, was $105.6 billion and $107.5 billion, respectively.
  (was, 2020-01-29, similarity 0.9686):
[0000320193-20-000010:note_history:22]
As of December 28, 2019 and September 28, 2019, the fair value of the Company’s Notes, based on Level 2 inputs, was $109.1 billion and $107.5 billion, respectively.

- removed (2020-05-01):
[0000320193-20-000010:note_history:23]
|  | Three Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | (175 | ) |  | $ | 2,011 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 1,317 |  |  | 2,166 |  |
| Repayments of commercial paper | (2,121 | ) |  | (4,171 | ) |
| Repayments of commercial paper, net | (804 | ) |  | (2,005 | ) |
| Total proceeds from/(repayments of) commercial paper, net | $ | (979 | ) |  | $ | 6 |  |

- removed (2020-05-01):
[0000320193-20-000010:note_history:24]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $757 million and $809 million of interest cost on its term debt for the three months ended December 28, 2019 and December 29, 2018, respectively.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-01):
[0000320193-20-000052:note_history:25]
The following table provides a summary of the Company’s term debt as of March 28, 2020 and September 28, 2019:
  (was, 2020-01-29, similarity 0.9557):
[0000320193-20-000010:note_history:25]
The following table provides a summary of the Company’s term debt as of December 28, 2019 and September 28, 2019:

- changed (2020-05-01):
[0000320193-20-000052:note_history:26]
|  | Maturities(calendar year) |  | March 28, 2020 |  | September 28, 2019 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 – 2019 debt issuances: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2020 | – | 2022 |  | $ | 3,250 |  |  |  | 1.80% | – | 2.81 | % |  | $ | 4,250 |  |  |  | 2.25% | – | 3.28 | % |
| Fixed-rate 0.350% – 4.650% notes | 2020 | – | 2049 |  | 92,554 |  |  |  | 0.28% | – | 4.78 | % |  | 97,429 |  |  |  | 0.28% | – | 4.78 | % |
| First quarter 2020 debt issuance of €2.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.000% – 0.500% notes | 2025 | – | 2031 |  | 2,164 |  |  |  | 0.03% | – | 0.56 | % |  | — |  |  |  |  |  | — | % |
| Total term debt |  |  |  |  | 97,968 |  |  |  |  |  |  |  | 101,679 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (220 | ) |  |  |  |  |  |  | (224 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | 1,730 |  |  |  |  |  |  |  | 612 |  |  |  |  |  |  |
| Less: Current portion of term debt |  |  |  |  | (10,392 | ) |  |  |  |  |  |  | (10,260 | ) |  |  |  |  |  |
| Total non-current portion of term debt |  |  |  |  | $ | 89,086 |  |  |  |  |  |  |  | $ | 91,807 |  |  |  |  |  |  |
  (was, 2020-01-29, similarity 0.9938):
[0000320193-20-000010:note_history:26]
|  | Maturities(calendar year) |  | December 28, 2019 |  | September 28, 2019 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 – 2019 debt issuances: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2020 | – | 2022 |  | $ | 4,250 |  |  |  | 1.97% | – | 3.04 | % |  | $ | 4,250 |  |  |  | 2.25% | – | 3.28 | % |
| Fixed-rate 0.350% – 4.650% notes | 2020 | – | 2049 |  | 96,610 |  |  |  | 0.28% | – | 4.78 | % |  | 97,429 |  |  |  | 0.28% | – | 4.78 | % |
| First quarter 2020 debt issuance of €2.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.000% – 0.500% notes | 2025 | – | 2031 |  | 2,226 |  |  |  | 0.03% | – | 0.56 | % |  | — |  |  |  |  |  | — | % |
| Total term debt |  |  |  |  | 103,086 |  |  |  |  |  |  |  | 101,679 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (229 | ) |  |  |  |  |  |  | (224 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | 445 |  |  |  |  |  |  |  | 612 |  |  |  |  |  |  |
| Less: Current portion of term debt |  |  |  |  | (10,224 | ) |  |  |  |  |  |  | (10,260 | ) |  |  |  |  |  |
| Total non-current portion of term debt |  |  |  |  | $ | 93,078 |  |  |  |  |  |  |  | $ | 91,807 |  |  |  |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-05-01):
[0000320193-20-000052:note_history:27]
Net sales disaggregated by significant products and services for the three- and six-month periods ended March 28, 2020 and March 30, 2019 were as follows (in millions):
  (was, 2020-01-29, similarity 0.8889):
[0000320193-20-000010:note_history:27]
Net sales disaggregated by significant products and services for the three months ended December 28, 2019 and December 29, 2018 were as follows (in millions):

- changed (2020-05-01):
[0000320193-20-000052:note_history:28]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| iPhone (1) | $ | 28,962 |  |  | $ | 31,051 |  |  | $ | 84,919 |  |  | $ | 83,033 |  |
| Mac (1) | 5,351 |  |  | 5,513 |  |  | 12,511 |  |  | 12,929 |  |
| iPad (1) | 4,368 |  |  | 4,872 |  |  | 10,345 |  |  | 11,601 |  |
| Wearables, Home and Accessories (1)(2) | 6,284 |  |  | 5,129 |  |  | 16,294 |  |  | 12,437 |  |
| Services (3) | 13,348 |  |  | 11,450 |  |  | 26,063 |  |  | 22,325 |  |
| Total net sales (4) | $ | 58,313 |  |  | $ | 58,015 |  |  | $ | 150,132 |  |  | $ | 142,325 |  |
  (was, 2020-01-29, similarity 0.6916):
[0000320193-20-000010:note_history:28]
|  | Three Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |
| iPhone (1) | $ | 55,957 |  |  | $ | 51,982 |  |
| Mac (1) | 7,160 |  |  | 7,416 |  |
| iPad (1) | 5,977 |  |  | 6,729 |  |
| Wearables, Home and Accessories (1)(2) | 10,010 |  |  | 7,308 |  |
| Services (3) | 12,715 |  |  | 10,875 |  |
| Total net sales (4) | $ | 91,819 |  |  | $ | 84,310 |  |

- changed (2020-05-01):
[0000320193-20-000052:note_history:29]
| (3) | Services net sales include sales from the Company’s digital content stores and streaming services, AppleCare®, licensing and other services. Services net sales also include amortization of the deferred value of Maps, Siri, and free iCloud storage and Apple TV + services, which are bundled in the sales price of certain products. |
  (was, 2020-01-29, similarity 0.9881):
[0000320193-20-000010:note_history:29]
| (3) | Services net sales include sales from the Company’s digital content stores and streaming services, AppleCare®, licensing and other services. Services net sales also include amortization of the deferred value of Maps, Siri, and free iCloud and Apple TV + services, which are bundled in the sales price of certain products. |

- changed (2020-05-01):
[0000320193-20-000052:note_history:30]
Includes $1.9 billion of revenue recognized in the three months ended March 28, 2020 that was included in deferred revenue as of December 28, 2019, $1.9 billion of revenue recognized in the three months ended March 30, 2019 that was included in deferred revenue as of December 29, 2018, $3.0 billion of revenue recognized in the six months ended March 28, 2020 that was included in deferred revenue as of September 28, 2019, and $3.8 billion of revenue recognized in the six months ended March 30, 2019 that was included in deferred revenue as of September 29, 2018.
  (was, 2020-01-29, similarity 0.6081):
[0000320193-20-000010:note_history:30]
Includes $1.9 billion of revenue recognized in the three months ended December 28, 2019 that was included in deferred revenue as of September 28, 2019 and $2.4 billion of revenue recognized in the three months ended December 29, 2018 that was included in deferred revenue as of September 29, 2018.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-05-01):
[0000320193-20-000052:note_history:31]
As of March 28, 2020 and September 28, 2019, the Company had total deferred revenue of $9.4 billion and $8.1 billion, respectively. As of March 28, 2020, the Company expects 63% of total deferred revenue to be realized in less than a year, 28% within one-to-two years, 7% within two-to-three years and 2% in greater than three years.
  (was, 2020-01-29, similarity 0.9585):
[0000320193-20-000010:note_history:31]
As of December 28, 2019 and September 28, 2019, the Company had total deferred revenue of $9.1 billion and $8.1 billion, respectively. As of December 28, 2019, the Company expects 61% of total deferred revenue to be realized in less than a year, 29% within one-to-two years, 8% within two-to-three years and 2% in greater than three years.

- changed (2020-05-01):
[0000320193-20-000052:note_history:32]
Net sales disaggregated by significant products and services for the three- and six-month periods ended March 28, 2020 and March 30, 2019 were as follows (in millions):
  (was, 2020-01-29, similarity 0.8889):
[0000320193-20-000010:note_history:32]
Net sales disaggregated by significant products and services for the three months ended December 28, 2019 and December 29, 2018 were as follows (in millions):

- changed (2020-05-01):
[0000320193-20-000052:note_history:33]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| iPhone (1) | $ | 28,962 |  |  | $ | 31,051 |  |  | $ | 84,919 |  |  | $ | 83,033 |  |
| Mac (1) | 5,351 |  |  | 5,513 |  |  | 12,511 |  |  | 12,929 |  |
| iPad (1) | 4,368 |  |  | 4,872 |  |  | 10,345 |  |  | 11,601 |  |
| Wearables, Home and Accessories (1)(2) | 6,284 |  |  | 5,129 |  |  | 16,294 |  |  | 12,437 |  |
| Services (3) | 13,348 |  |  | 11,450 |  |  | 26,063 |  |  | 22,325 |  |
| Total net sales (4) | $ | 58,313 |  |  | $ | 58,015 |  |  | $ | 150,132 |  |  | $ | 142,325 |  |
  (was, 2020-01-29, similarity 0.6916):
[0000320193-20-000010:note_history:33]
|  | Three Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |
| iPhone (1) | $ | 55,957 |  |  | $ | 51,982 |  |
| Mac (1) | 7,160 |  |  | 7,416 |  |
| iPad (1) | 5,977 |  |  | 6,729 |  |
| Wearables, Home and Accessories (1)(2) | 10,010 |  |  | 7,308 |  |
| Services (3) | 12,715 |  |  | 10,875 |  |
| Total net sales (4) | $ | 91,819 |  |  | $ | 84,310 |  |

- changed (2020-05-01):
[0000320193-20-000052:note_history:34]
| (3) | Services net sales include sales from the Company’s digital content stores and streaming services, AppleCare®, licensing and other services. Services net sales also include amortization of the deferred value of Maps, Siri, and free iCloud storage and Apple TV + services, which are bundled in the sales price of certain products. |
  (was, 2020-01-29, similarity 0.9881):
[0000320193-20-000010:note_history:34]
| (3) | Services net sales include sales from the Company’s digital content stores and streaming services, AppleCare®, licensing and other services. Services net sales also include amortization of the deferred value of Maps, Siri, and free iCloud and Apple TV + services, which are bundled in the sales price of certain products. |

- changed (2020-05-01):
[0000320193-20-000052:note_history:35]
| (4) | Includes $1.9 billion of revenue recognized in the three months ended March 28, 2020 that was included in deferred revenue as of December 28, 2019, $1.9 billion of revenue recognized in the three months ended March 30, 2019 that was included in deferred revenue as of December 29, 2018, $3.0 billion of revenue recognized in the six months ended March 28, 2020 that was included in deferred revenue as of September 28, 2019, and $3.8 billion of revenue recognized in the six months ended March 30, 2019 that was included in deferred revenue as of September 29, 2018. |
  (was, 2020-01-29, similarity 0.6179):
[0000320193-20-000010:note_history:35]
| (4) | Includes $1.9 billion of revenue recognized in the three months ended December 28, 2019 that was included in deferred revenue as of September 28, 2019 and $2.4 billion of revenue recognized in the three months ended December 29, 2018 that was included in deferred revenue as of September 29, 2018. |

- changed (2020-05-01):
[0000320193-20-000052:note_history:36]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 11, “Segment Information and Geographic Data” for the three- and six-month periods ended March 28, 2020 and March 30, 2019.
  (was, 2020-01-29, similarity 0.7966):
[0000320193-20-000010:note_history:36]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 11, “Segment Information and Geographic Data” for the three months ended December 28, 2019 and December 29, 2018.
