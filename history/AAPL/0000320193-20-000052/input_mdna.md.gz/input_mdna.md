# AAPL MD&A — 0000320193-20-000052


## mdna

[0000320193-20-000052:mdna:1]
[same as prior period, unchanged from 0000320193-20-000010:mdna:1]

[0000320193-20-000052:mdna:2]
[same as prior period, unchanged from 0000320193-20-000010:mdna:2]

[0000320193-20-000052:mdna:3]
The Company periodically provides certain information for investors on its corporate website, www.apple.com, and its investor relations website, investor.apple.com. This includes press releases and other information about financial performance, information on corporate governance and details related to the Company’s annual meeting of shareholders. The information contained on the websites referenced in this Form 10-Q is not incorporated by reference into this filing. Further, the Company’s references to website URLs are intended to be inactive textual references only.

[0000320193-20-000052:mdna:4]
[same as prior period, unchanged from 0000320193-20-000010:mdna:4]

[0000320193-20-000052:mdna:5]
[same as prior period, unchanged from 0000320193-20-000010:mdna:5]

[0000320193-20-000052:mdna:6]
[same as prior period, unchanged from 0000320193-20-000010:mdna:6]

[0000320193-20-000052:mdna:7]
COVID-19 Update

[0000320193-20-000052:mdna:8]
A novel strain of coronavirus (“COVID-19”) has spread rapidly throughout the world, prompting governments and businesses to take unprecedented measures in response. Such measures have included restrictions on travel and business operations, temporary closures of businesses, and quarantines and shelter-in-place orders. The COVID-19 pandemic has significantly curtailed global economic activity and caused significant volatility and disruption in global financial markets. The COVID-19 pandemic and the measures taken by many countries in response have adversely affected and could in the future materially adversely impact the Company’s business, results of operations, financial condition and stock price.

[0000320193-20-000052:mdna:9]
During February 2020, following the initial outbreak of the virus in China, the Company experienced disruptions to its manufacturing, supply chain and logistical services provided by outsourcing partners, resulting in temporary iPhone supply shortages that affected sales worldwide. Also, the Company’s sales of its products in China were adversely affected as public health measures and other actions to curb the spread of the virus, including the temporary closure of the Company’s retail stores and channel partner points of sale, were put in place.

[0000320193-20-000052:mdna:10]
The virus spread further around the world as the quarter progressed, and social distancing measures and shelter-in-place orders were introduced in many countries. Effective March 13, 2020, the Company temporarily closed all of its retail stores outside of China. The Company has also required substantially all of its employees in all of its offices outside of China to work remotely. Additionally, many of the Company’s channel partner points of sale outside of China temporarily closed. As a result of the above factors, the Company also experienced weakened demand for its products and services outside of China during the last three weeks of the quarter.

[0000320193-20-000052:mdna:11]
The COVID-19 pandemic has continued to adversely impact demand for certain of the Company’s products and services through April 2020. The full extent of the impact of the COVID-19 pandemic on the Company’s operational and financial performance is currently uncertain and will depend on many factors outside the Company’s control, including, without limitation, the timing, extent, trajectory and duration of the pandemic, the development and availability of effective treatments and vaccines, the imposition of protective public safety measures, and the impact of the pandemic on the global economy and demand for consumer products. See “The Company’s business, results of operations, financial condition and stock price have been adversely affected and could in the future be materially adversely affected by the COVID-19 pandemic” in Part II, Item 1A of this Form 10-Q under the heading “Risk Factors.”

[0000320193-20-000052:mdna:12]
The Company believes its existing balances of cash, cash equivalents and marketable securities, along with commercial paper and other short-term liquidity arrangements, will be sufficient to satisfy its working capital needs, capital asset purchases, dividends, share repurchases, debt repayments and other liquidity requirements associated with its existing operations.

[0000320193-20-000052:mdna:13]
Second Quarter Fiscal 2020 Highlights

[0000320193-20-000052:mdna:14]
Total net sales increased 1% or $298 million during the second quarter of 2020 compared to the same quarter in 2019, primarily driven by higher Services and Wearables, Home and Accessories net sales, partially offset by lower iPhone net sales. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on net sales during the second quarter of 2020.

[0000320193-20-000052:mdna:15]
During the second quarter of 2020, the Company released an updated iPad Pro® and added trackpad support to iPadOS®. Additionally, the Company released an updated MacBook Air®.

[0000320193-20-000052:mdna:16]
The Company repurchased $18.5 billion of its common stock and paid dividends and dividend equivalents of $3.4 billion during the second quarter of 2020.

[0000320193-20-000052:mdna:17]
[same as prior period, unchanged from 0000320193-20-000010:mdna:11]

[0000320193-20-000052:mdna:18]
The following table shows net sales by category for the three- and six-month periods ended March 28, 2020 and March 30, 2019 (dollars in millions):

[0000320193-20-000052:mdna:19]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | Change |  | March 28, 2020 |  | March 30, 2019 |  | Change |
| Net sales by category: |  |  |  |  |  |  |  |  |  |  |  |
| iPhone (1) | $ | 28,962 |  |  | $ | 31,051 |  |  | (7 | )% |  | $ | 84,919 |  |  | $ | 83,033 |  |  | 2 | % |
| Mac (1) | 5,351 |  |  | 5,513 |  |  | (3 | )% |  | 12,511 |  |  | 12,929 |  |  | (3 | )% |
| iPad (1) | 4,368 |  |  | 4,872 |  |  | (10 | )% |  | 10,345 |  |  | 11,601 |  |  | (11 | )% |
| Wearables, Home and Accessories (1)(2) | 6,284 |  |  | 5,129 |  |  | 23 | % |  | 16,294 |  |  | 12,437 |  |  | 31 | % |
| Services (3) | 13,348 |  |  | 11,450 |  |  | 17 | % |  | 26,063 |  |  | 22,325 |  |  | 17 | % |
| Total net sales | $ | 58,313 |  |  | $ | 58,015 |  |  | 1 | % |  | $ | 150,132 |  |  | $ | 142,325 |  |  | 5 | % |

[0000320193-20-000052:mdna:20]
[same as prior period, unchanged from 0000320193-20-000010:mdna:14]

[0000320193-20-000052:mdna:21]
[same as prior period, unchanged from 0000320193-20-000010:mdna:15]

[0000320193-20-000052:mdna:22]
| (3) | Services net sales include sales from the Company’s digital content stores and streaming services, AppleCare, licensing and other services. Services net sales also include amortization of the deferred value of Maps, Siri, and free iCloud storage and Apple TV + services, which are bundled in the sales price of certain products. |

[0000320193-20-000052:mdna:23]
[same as prior period, unchanged from 0000320193-20-000010:mdna:17]

[0000320193-20-000052:mdna:24]
iPhone net sales decreased during the second quarter of 2020 compared to the second quarter of 2019 due primarily to the unfavorable impact of the COVID-19 pandemic. Year-over-year iPhone net sales increased during the first six months of 2020 due primarily to the successful launch of the Company’s new iPhone models during the first quarter of 2020, partially offset by the unfavorable impact of the COVID-19 pandemic during the second quarter of 2020.

[0000320193-20-000052:mdna:25]
[same as prior period, unchanged from 0000320193-20-000010:mdna:19]

[0000320193-20-000052:mdna:26]
Mac net sales decreased during the second quarter and first six months of 2020 compared to the same periods in 2019 due primarily to lower net sales of Mac portable computers and the impact of the COVID-19 pandemic.

[0000320193-20-000052:mdna:27]
[same as prior period, unchanged from 0000320193-20-000010:mdna:21]

[0000320193-20-000052:mdna:28]
iPad net sales decreased during the second quarter and first six months of 2020 compared to the same periods in 2019 due primarily to lower net sales of iPad Pro and the impact of the COVID-19 pandemic.

[0000320193-20-000052:mdna:29]
[same as prior period, unchanged from 0000320193-20-000010:mdna:23]

[0000320193-20-000052:mdna:30]
Wearables, Home and Accessories net sales increased during the second quarter and first six months of 2020 compared to the same periods in 2019, despite the impact of the COVID-19 pandemic, due to higher net sales of Wearables, primarily AirPods.

[0000320193-20-000052:mdna:31]
[same as prior period, unchanged from 0000320193-20-000010:mdna:25]

[0000320193-20-000052:mdna:32]
Services net sales increased during the second quarter of 2020 compared to the second quarter of 2019, despite the impact of the COVID-19 pandemic, due primarily to higher net sales from the App Store, licensing and Cloud Services. Year-over-year Services net sales increased during the first six months of 2020 due primarily to higher net sales from the App Store, licensing and AppleCare.

[0000320193-20-000052:mdna:33]
[same as prior period, unchanged from 0000320193-20-000010:mdna:27]

[0000320193-20-000052:mdna:34]
[same as prior period, unchanged from 0000320193-20-000010:mdna:28]

[0000320193-20-000052:mdna:35]
The following table shows net sales by reportable segment for the three- and six-month periods ended March 28, 2020 and March 30, 2019 (dollars in millions):

[0000320193-20-000052:mdna:36]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | Change |  | March 28, 2020 |  | March 30, 2019 |  | Change |
| Net sales by reportable segment: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 25,473 |  |  | $ | 25,596 |  |  | — | % |  | $ | 66,840 |  |  | $ | 62,536 |  |  | 7 | % |
| Europe | 14,294 |  |  | 13,054 |  |  | 9 | % |  | 37,567 |  |  | 33,417 |  |  | 12 | % |
| Greater China | 9,455 |  |  | 10,218 |  |  | (7 | )% |  | 23,033 |  |  | 23,387 |  |  | (2 | )% |
| Japan | 5,206 |  |  | 5,532 |  |  | (6 | )% |  | 11,429 |  |  | 12,442 |  |  | (8 | )% |
| Rest of Asia Pacific | 3,885 |  |  | 3,615 |  |  | 7 | % |  | 11,263 |  |  | 10,543 |  |  | 7 | % |
| Total net sales | $ | 58,313 |  |  | $ | 58,015 |  |  | 1 | % |  | $ | 150,132 |  |  | $ | 142,325 |  |  | 5 | % |

[0000320193-20-000052:mdna:37]
[same as prior period, unchanged from 0000320193-20-000010:mdna:31]

[0000320193-20-000052:mdna:38]
Americas net sales were flat during the second quarter of 2020 compared to the second quarter of 2019 due primarily to lower iPhone net sales as a result of the COVID-19 pandemic, largely offset by higher Services and Wearables, Home and Accessories net sales. Year-over-year Americas net sales increased during the first six months of 2020 due primarily to higher Services, Wearables, Home and Accessories and iPhone net sales. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on Americas net sales during the second quarter and first six months of 2020.

[0000320193-20-000052:mdna:39]
[same as prior period, unchanged from 0000320193-20-000010:mdna:33]

[0000320193-20-000052:mdna:40]
Europe net sales increased during the second quarter and first six months of 2020 compared to the same periods in 2019, despite the impact of the COVID-19 pandemic, due primarily to higher iPhone and Wearables, Home and Accessories net sales, partially offset by lower iPad net sales. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on Europe net sales during the second quarter and first six months of 2020.

[0000320193-20-000052:mdna:41]
[same as prior period, unchanged from 0000320193-20-000010:mdna:35]

[0000320193-20-000052:mdna:42]
Greater China net sales decreased during the second quarter and first six months of 2020 compared to the same periods in 2019 due primarily to lower iPhone net sales as a result of the COVID-19 pandemic, partially offset by higher Services net sales. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on Greater China net sales during the second quarter and first six months of 2020.

[0000320193-20-000052:mdna:43]
[same as prior period, unchanged from 0000320193-20-000010:mdna:37]

[0000320193-20-000052:mdna:44]
Japan net sales decreased during the second quarter and first six months of 2020 compared to the same periods in 2019 due primarily to lower iPhone net sales attributable to lower carrier subsidies and as a result of the COVID-19 pandemic, partially offset by higher Services net sales. The strength of the Japanese Yen relative to the U.S. dollar had a favorable impact on Japan net sales during the second quarter and first six months of 2020.

[0000320193-20-000052:mdna:45]
[same as prior period, unchanged from 0000320193-20-000010:mdna:39]

[0000320193-20-000052:mdna:46]
Rest of Asia Pacific net sales increased during the second quarter of 2020 compared to the second quarter of 2019, despite the impact of the COVID-19 pandemic, due primarily to higher Wearables, Home and Accessories and iPhone net sales, partially offset by lower iPad net sales. Year-over-year Rest of Asia Pacific net sales increased during the first six months of 2020 due primarily to higher Wearables, Home and Accessories and Services net sales. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on Rest of Asia Pacific net sales during the second quarter and first six months of 2020.

[0000320193-20-000052:mdna:47]
[same as prior period, unchanged from 0000320193-20-000010:mdna:41]

[0000320193-20-000052:mdna:48]
Products and Services gross margin and gross margin percentage for the three- and six-month periods ended March 28, 2020 and March 30, 2019 were as follows (dollars in millions):

[0000320193-20-000052:mdna:49]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| Gross margin: |  |  |  |  |  |  |  |
| Products | $ | 13,644 |  |  | $ | 14,518 |  |  | $ | 40,673 |  |  | $ | 39,715 |  |
| Services | 8,726 |  |  | 7,303 |  |  | 16,914 |  |  | 14,137 |  |
| Total gross margin | $ | 22,370 |  |  | $ | 21,821 |  |  | $ | 57,587 |  |  | $ | 53,852 |  |
| Gross margin percentage: |  |  |  |  |  |  |  |
| Products | 30.3 | % |  | 31.2 | % |  | 32.8 | % |  | 33.1 | % |
| Services | 65.4 | % |  | 63.8 | % |  | 64.9 | % |  | 63.3 | % |
| Total gross margin percentage | 38.4 | % |  | 37.6 | % |  | 38.4 | % |  | 37.8 | % |

[0000320193-20-000052:mdna:50]
[same as prior period, unchanged from 0000320193-20-000010:mdna:44]

[0000320193-20-000052:mdna:51]
Products gross margin and Products gross margin percentage decreased during the second quarter of 2020 compared to the second quarter of 2019 due primarily to the weakness in foreign currencies relative to the U.S. dollar and the impact of the COVID-19 pandemic.

[0000320193-20-000052:mdna:52]
Products gross margin increased during the first six months of 2020 compared to the same period in 2019 due primarily to higher Products volume and favorable Products mix, partially offset by the weakness in foreign currencies relative to the U.S. dollar and the impact of the COVID-19 pandemic. Year-over-year Products gross margin percentage decreased during the first six months of 2020 due primarily to the weakness in foreign currencies relative to the U.S. dollar and the impact of the COVID-19 pandemic, partially offset by higher leverage.

[0000320193-20-000052:mdna:53]
[same as prior period, unchanged from 0000320193-20-000010:mdna:46]

[0000320193-20-000052:mdna:54]
Services gross margin increased during the second quarter and first six months of 2020 compared to the same periods in 2019 due primarily to higher Services net sales. Services gross margin percentage increased during the second quarter and first six months of 2020 compared to the same periods in 2019 due primarily to a favorable Services mix and higher leverage, partially offset by higher Services costs.

[0000320193-20-000052:mdna:55]
The Company’s future gross margins can be impacted by a variety of factors, as discussed in Part I, Item 1A of the 2019 Form 10-K and Part II, Item 1A of this Form 10-Q, in each case under the heading “Risk Factors.” As a result, the Company believes, in general, gross margins will be subject to volatility and remain under downward pressure.

[0000320193-20-000052:mdna:56]
[same as prior period, unchanged from 0000320193-20-000010:mdna:49]

[0000320193-20-000052:mdna:57]
Operating expenses for the three- and six-month periods ended March 28, 2020 and March 30, 2019 were as follows (dollars in millions):

[0000320193-20-000052:mdna:58]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| Research and development | $ | 4,565 |  |  | $ | 3,948 |  |  | $ | 9,016 |  |  | $ | 7,850 |  |
| Percentage of total net sales | 8 | % |  | 7 | % |  | 6 | % |  | 6 | % |
| Selling, general and administrative | $ | 4,952 |  |  | $ | 4,458 |  |  | $ | 10,149 |  |  | $ | 9,241 |  |
| Percentage of total net sales | 8 | % |  | 8 | % |  | 7 | % |  | 6 | % |
| Total operating expenses | $ | 9,517 |  |  | $ | 8,406 |  |  | $ | 19,165 |  |  | $ | 17,091 |  |
| Percentage of total net sales | 16 | % |  | 14 | % |  | 13 | % |  | 12 | % |

[0000320193-20-000052:mdna:59]
[same as prior period, unchanged from 0000320193-20-000010:mdna:52]

[0000320193-20-000052:mdna:60]
The growth in research and development (“R&D”) expense during the second quarter and first six months of 2020 compared to the same periods in 2019 was driven primarily by increases in headcount-related expenses. The Company continues to believe that focused investments in R&D are critical to its future growth and competitive position in the marketplace, and to the development of new and updated products and services that are central to the Company’s core business strategy.

[0000320193-20-000052:mdna:61]
[same as prior period, unchanged from 0000320193-20-000010:mdna:54]

[0000320193-20-000052:mdna:62]
The growth in selling, general and administrative expense during the second quarter and first six months of 2020 compared to the same periods in 2019 was driven primarily by higher spending on marketing and advertising and increases in headcount-related expenses.

[0000320193-20-000052:mdna:63]
[same as prior period, unchanged from 0000320193-20-000010:mdna:56]

[0000320193-20-000052:mdna:64]
Other income/(expense), net (“OI&E”) for the three- and six-month periods ended March 28, 2020 and March 30, 2019 was as follows (dollars in millions):

[0000320193-20-000052:mdna:65]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | Change |  | March 28, 2020 |  | March 30, 2019 |  | Change |
| Interest and dividend income | $ | 1,049 |  |  | $ | 1,358 |  |  |  |  | $ | 2,094 |  |  | $ | 2,665 |  |  |  |
| Interest expense | (757 | ) |  | (1,010 | ) |  |  |  | (1,542 | ) |  | (1,900 | ) |  |  |
| Other income/(expense), net | (10 | ) |  | 30 |  |  |  |  | 79 |  |  | 173 |  |  |  |
| Total other income/(expense), net | $ | 282 |  |  | $ | 378 |  |  | (25 | )% |  | $ | 631 |  |  | $ | 938 |  |  | (33 | )% |

[0000320193-20-000052:mdna:66]
OI&E decreased during the second quarter and first six months of 2020 compared to the same periods in 2019 due primarily to lower interest income, partially offset by lower interest expense. The weighted-average interest rate earned by the Company on its cash, cash equivalents and marketable securities was 2.01% and 2.27% in the second quarter of 2020 and 2019, respectively, and 2.05% and 2.23% in the first six months of 2020 and 2019, respectively.

[0000320193-20-000052:mdna:67]
[same as prior period, unchanged from 0000320193-20-000010:mdna:60]

[0000320193-20-000052:mdna:68]
Provision for income taxes, effective tax rate and statutory federal income tax rate for the three- and six-month periods ended March 28, 2020 and March 30, 2019 were as follows (dollars in millions):

[0000320193-20-000052:mdna:69]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| Provision for income taxes | $ | 1,886 |  |  | $ | 2,232 |  |  | $ | 5,568 |  |  | $ | 6,173 |  |
| Effective tax rate | 14.4 | % |  | 16.2 | % |  | 14.3 | % |  | 16.4 | % |
| Statutory federal income tax rate | 21 | % |  | 21 | % |  | 21 | % |  | 21 | % |

[0000320193-20-000052:mdna:70]
The Company’s effective tax rate for the second quarter and first six months of 2020 was lower than the statutory federal income tax rate due primarily to lower taxes on foreign earnings, including the impact of tax settlements.

[0000320193-20-000052:mdna:71]
The Company’s effective tax rate for the second quarter of 2020 was lower compared to the second quarter of 2019 due to lower taxes on foreign earnings, including the impact of tax settlements. The Company’s effective tax rate for the first six months of 2020 was lower compared to the same period in 2019 due to the one-time adjustment of U.S. foreign tax credits in response to regulations issued by the U.S. Department of the Treasury in December 2019 and lower taxes on foreign earnings, including the impact of tax settlements.

[0000320193-20-000052:mdna:72]
[same as prior period, unchanged from 0000320193-20-000010:mdna:65]

[0000320193-20-000052:mdna:73]
[same as prior period, unchanged from 0000320193-20-000010:mdna:66]

[0000320193-20-000052:mdna:74]
In June 2016, the Financial Accounting Standards Board issued Accounting Standards Update No. 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (“ASU 2016-13”), which modifies the measurement of expected credit losses on certain financial instruments. The Company will adopt ASU 2016-13 in its first quarter of 2021 utilizing the modified retrospective transition method. Based on the composition of the Company’s investment portfolio, current market conditions, and historical credit loss activity, the adoption of ASU 2016-13 is not expected to have a material impact on its consolidated financial statements.

[0000320193-20-000052:mdna:75]
[same as prior period, unchanged from 0000320193-20-000010:mdna:68]

[0000320193-20-000052:mdna:76]
The following tables present selected financial information and statistics as of March 28, 2020 and September 28, 2019 and for the first six months of 2020 and 2019 (in millions):

[0000320193-20-000052:mdna:77]
|  | March 28, 2020 |  | September 28, 2019 |
| Cash, cash equivalents and marketable securities (1) | $ | 192,844 |  |  | $ | 205,898 |  |
| Property, plant and equipment, net | $ | 35,889 |  |  | $ | 37,378 |  |
| Commercial paper and repurchase agreement | $ | 10,029 |  |  | $ | 5,980 |  |
| Total term debt | $ | 99,478 |  |  | $ | 102,067 |  |
| Working capital | $ | 47,659 |  |  | $ | 57,101 |  |

[0000320193-20-000052:mdna:78]
|  | Six Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |
| Cash generated by operating activities | $ | 43,827 |  |  | $ | 37,845 |  |
| Cash generated by/(used in) investing activities | $ | (4,655 | ) |  | $ | 19,192 |  |
| Cash used in financing activities | $ | (46,347 | ) |  | $ | (43,133 | ) |

[0000320193-20-000052:mdna:79]
| (1) | As of March 28, 2020 and September 28, 2019, total marketable securities included $17.6 billion and $18.9 billion, respectively, that was restricted from general use, related to the State Aid Decision (refer to Note 5, “Income Taxes” in the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Form 10-Q) and other agreements. Additionally, as of March 28, 2020, $2.6 billion of marketable securities were pledged as collateral under a repurchase agreement (refer to Note 6, “Debt” in the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Form 10-Q). |

[0000320193-20-000052:mdna:80]
[same as prior period, unchanged from 0000320193-20-000010:mdna:73]

[0000320193-20-000052:mdna:81]
In connection with the State Aid Decision, as of March 28, 2020, the adjusted recovery amount of €12.9 billion plus interest of €1.2 billion was funded into escrow, where it will remain restricted from general use pending the conclusion of all appeals.

[0000320193-20-000052:mdna:82]
[same as prior period, unchanged from 0000320193-20-000010:mdna:75]

[0000320193-20-000052:mdna:83]
During the six months ended March 28, 2020, cash generated by operating activities of $43.8 billion was a result of $33.5 billion of net income, non-cash adjustments to net income of $8.1 billion and an increase in the net change in operating assets and liabilities of $2.2 billion. Cash used in investing activities of $4.7 billion during the six months ended March 28, 2020 consisted primarily of cash used for purchases of marketable securities, net of maturities and sales, of $1.0 billion and cash used to acquire property, plant and equipment of $4.0 billion. Cash used in financing activities of $46.3 billion during the six months ended March 28, 2020 consisted primarily of cash used to repurchase common stock of $39.3 billion, cash used to pay dividends and dividend equivalents of $6.9 billion and cash used to repay or redeem term debt of $5.3 billion, partially offset by net proceeds from commercial paper and repurchase agreement of $4.1 billion and net proceeds from the issuance of term debt of $2.2 billion.

[0000320193-20-000052:mdna:84]
During the six months ended March 30, 2019, cash generated by operating activities of $37.8 billion was a result of $31.5 billion of net income and non-cash adjustments to net income of $9.2 billion, partially offset by a decrease in the net change in operating assets and liabilities of $2.9 billion. Cash generated by investing activities of $19.2 billion during the six months ended March 30, 2019 consisted primarily of proceeds from sales and maturities of marketable securities, net of purchases, of $25.7 billion, partially offset by cash used to acquire property, plant and equipment of $5.7 billion. Cash used in financing activities of $43.1 billion during the six months ended March 30, 2019 consisted primarily of cash used to repurchase common stock of $32.5 billion, cash used to pay dividends and dividend equivalents of $7.0 billion and cash used to repay term debt of $2.5 billion.

[0000320193-20-000052:mdna:85]
[same as prior period, unchanged from 0000320193-20-000010:mdna:78]

[0000320193-20-000052:mdna:86]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses the net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of March 28, 2020, the Company had $7.5 billion of Commercial Paper outstanding, with a weighted-average interest rate of 1.39% and maturities generally less than nine months.

[0000320193-20-000052:mdna:87]
In the second quarter of 2020, the Company entered into an agreement to sell certain of its marketable securities with a promise to repurchase the securities at a specified time and amount (“Repo”). Due to the Company’s continuing involvement with the marketable securities, the Company accounts for the Repo as a collateralized borrowing. As of March 28, 2020, the Company had a $2.6 billion Repo liability with a maturity of less than six months, and had pledged $2.6 billion of marketable securities as collateral.

[0000320193-20-000052:mdna:88]
As of March 28, 2020, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $98.0 billion (collectively the “Notes”). During the first six months of 2020, the Company issued $2.2 billion and repaid or redeemed $5.3 billion of Notes. The Company has entered, and in the future may enter, into interest rate swaps to manage interest rate risk on the Notes. In addition, the Company has entered, and in the future may enter, into foreign currency swaps to manage foreign currency risk on the Notes.

[0000320193-20-000052:mdna:89]
[same as prior period, unchanged from 0000320193-20-000010:mdna:81]

[0000320193-20-000052:mdna:90]
[same as prior period, unchanged from 0000320193-20-000010:mdna:82]

[0000320193-20-000052:mdna:91]
As of March 28, 2020, the Company was authorized to purchase up to $175 billion of the Company’s common stock under a share repurchase program, of which $134.6 billion had been utilized. During the six months ended March 28, 2020, the Company repurchased 135.0 million shares of its common stock for $38.5 billion, including 30.4 million shares initially delivered under a $10.0 billion accelerated share repurchase arrangement dated November 2019. On April 30, 2020, the Company announced the Board of Directors increased the share repurchase program authorization by $50 billion. The Company’s share repurchase program does not obligate it to acquire any specific number of shares. Under this program, shares may be repurchased in privately negotiated and/or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).

[0000320193-20-000052:mdna:92]
On April 30, 2020, the Company also announced the Board of Directors raised the Company’s quarterly cash dividend from $0.77 to $0.82 per share, beginning with the dividend to be paid during the third quarter of 2020. The Company intends to increase its dividend on an annual basis, subject to declaration by the Board of Directors.

[0000320193-20-000052:mdna:93]
[same as prior period, unchanged from 0000320193-20-000010:mdna:85]

[0000320193-20-000052:mdna:94]
[same as prior period, unchanged from 0000320193-20-000010:mdna:86]

[0000320193-20-000052:mdna:95]
As of March 28, 2020, the Company’s total fixed lease payment obligations were $12.5 billion, of which $8.1 billion was included in other non-current liabilities in the Company’s Condensed Consolidated Balance Sheet. The Company’s leases typically have original terms not exceeding 10 years and generally contain multi-year renewal options.

[0000320193-20-000052:mdna:96]
[same as prior period, unchanged from 0000320193-20-000010:mdna:88]

[0000320193-20-000052:mdna:97]
The Company utilizes several outsourcing partners to manufacture sub-assemblies for the Company’s products and to perform final assembly and testing of finished products. These outsourcing partners acquire components and build product based on demand information supplied by the Company, which typically covers periods up to 150 days. The Company also obtains individual components for its products from a wide variety of individual suppliers. As of March 28, 2020, the Company expects to pay $29.3 billion under manufacturing-related supplier arrangements, which are primarily noncancelable.

[0000320193-20-000052:mdna:98]
[same as prior period, unchanged from 0000320193-20-000010:mdna:90]

[0000320193-20-000052:mdna:99]
The Company’s other purchase obligations consist of noncancelable obligations to acquire capital assets, including product tooling and manufacturing process equipment, and noncancelable obligations related to advertising, licensing, R&D, Internet and telecommunications services, content creation and other activities. As of March 28, 2020, the Company had other purchase obligations of $8.7 billion.

[0000320193-20-000052:mdna:100]
[same as prior period, unchanged from 0000320193-20-000010:mdna:92]

[0000320193-20-000052:mdna:101]
As of March 28, 2020, the balance of the deemed repatriation tax payable imposed by the U.S. Tax Cuts and Jobs Act (the “Act”) was $28.2 billion, and was included in other non-current liabilities in the Company’s Condensed Consolidated Balance Sheet. The Company plans to pay the deemed repatriation tax payable in installments in accordance with the Act.

[0000320193-20-000052:mdna:102]
[same as prior period, unchanged from 0000320193-20-000010:mdna:94]

[0000320193-20-000052:mdna:103]
[same as prior period, unchanged from 0000320193-20-000010:mdna:95]

[0000320193-20-000052:mdna:104]
[same as prior period, unchanged from 0000320193-20-000010:mdna:96]

[0000320193-20-000052:mdna:105]
[same as prior period, unchanged from 0000320193-20-000010:mdna:97]

[0000320193-20-000052:mdna:106]
[same as prior period, unchanged from 0000320193-20-000010:mdna:98]
