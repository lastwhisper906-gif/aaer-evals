# AAPL MD&A — 0001193125-14-383437


## mdna

[0001193125-14-383437:mdna:1]
| Item 7. | Management’s Discussion and Analysis of Financial Condition and Results of Operations |
