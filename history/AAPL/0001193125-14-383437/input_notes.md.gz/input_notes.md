# AAPL notes — 0001193125-14-383437


## us-gaap:AdvertisingCostsPolicyTextBlock

[0001193125-14-383437:notes:1]
Advertising Costs

[0001193125-14-383437:notes:2]
Advertising costs are expensed as incurred and
 included in selling, general and administrative expenses.
 Advertising expense was $1.2 billion, $1.1 billion and $1.0 billion
 for 2014, 2013 and 2012, respectively.


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001193125-14-383437:notes:3]
Basis of Presentation and Preparation

[0001193125-14-383437:notes:4]
The accompanying consolidated financial statements
 include the accounts of the Company. Intercompany accounts and
 transactions have been eliminated. The preparation of these
 consolidated financial statements in conformity with U.S. generally
 accepted accounting principles (“GAAP”) requires
 management to make estimates and assumptions that affect the
 amounts reported in these consolidated financial statements and
 accompanying notes. Actual results could differ materially from
 those estimates.

[0001193125-14-383437:notes:5]
The Company’s fiscal year is the 52 or
 53-week period that ends on the last Saturday of September. The
 Company’s fiscal years 2014, 2013 and 2012 ended on
 September 27, 2014, September 28, 2013 and
 September 29, 2012, respectively. An additional week is
 included in the first fiscal quarter approximately every
 six years to realign fiscal quarters with calendar quarters.
 Fiscal years 2014 and 2013 spanned 52 weeks each. Fiscal year 2012
 spanned 53 weeks, with a 14th week included in the first quarter of
 2012. Unless otherwise stated, references to particular years,
 quarters, months and periods refer to the Company’s fiscal
 years ended in September and the associated quarters, months and
 periods of those fiscal years.

[0001193125-14-383437:notes:6]
During the first quarter of 2014, the Company
 adopted updated accounting standards that (i) required
 disclosure of additional information about the amounts reclassified
 out of accumulated other comprehensive income (“AOCI”)
 by component and (ii) required gross and net disclosures about
 offsetting assets and liabilities. The adoption of these updated
 standards only impacted the disclosures in the Notes to
 Consolidated Financial Statements; accordingly, the adoption had no
 impact on the Company’s financial position or results of
 operations. The Company has provided these additional disclosures
 in this Form 10-K in
 Note 8, “Comprehensive Income” and Note 2,
 “Financial Instruments,” respectively.


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001193125-14-383437:notes:7]
The following tables show the Company’s cash
 and available-for-sale
 securities’ adjusted cost, gross unrealized gains, gross
 unrealized losses and fair value by significant investment category
 recorded as cash and cash equivalents or short- or long-term
 marketable securities as of September 27, 2014 and
 September 28, 2013 (in millions):

[0001193125-14-383437:notes:8]
|  |  | 2014 |  |
|  |  | Adjusted Cost |  |  | Unrealized Gains |  |  | Unrealized Losses |  |  | Fair Value |  |  | Cash and Cash Equivalents |  |  | Short-Term Marketable Securities |  |  | Long-Term Marketable Securities |  |
| Cash |  | $ | 10,232 |  |  | $ | 0 |  |  | $ | 0 |  |  | $ | 10,232 |  |  | $ | 10,232 |  |  | $ | 0 |  |  | $ | 0 |  |
| Level 1: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  |  | 1,546 |  |  |  | 0 |  |  |  | 0 |  |  |  | 1,546 |  |  |  | 1,546 |  |  |  | 0 |  |  |  | 0 |  |
| Mutual funds |  |  | 2,531 |  |  |  | 1 |  |  |  | (132 | ) |  |  | 2,400 |  |  |  | 0 |  |  |  | 2,400 |  |  |  | 0 |  |
| Subtotal |  |  | 4,077 |  |  |  | 1 |  |  |  | (132 | ) |  |  | 3,946 |  |  |  | 1,546 |  |  |  | 2,400 |  |  |  | 0 |  |
| Level 2: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities |  |  | 23,140 |  |  |  | 15 |  |  |  | (9 | ) |  |  | 23,146 |  |  |  | 12 |  |  |  | 607 |  |  |  | 22,527 |  |
| U.S. agency securities |  |  | 7,373 |  |  |  | 3 |  |  |  | (11 | ) |  |  | 7,365 |  |  |  | 652 |  |  |  | 157 |  |  |  | 6,556 |  |
| Non-U.S. government securities |  |  | 6,925 |  |  |  | 69 |  |  |  | (69 | ) |  |  | 6,925 |  |  |  | 0 |  |  |  | 204 |  |  |  | 6,721 |  |
| Certificates of deposit and time deposits |  |  | 3,832 |  |  |  | 0 |  |  |  | 0 |  |  |  | 3,832 |  |  |  | 1,230 |  |  |  | 1,233 |  |  |  | 1,369 |  |
| Commercial paper |  |  | 475 |  |  |  | 0 |  |  |  | 0 |  |  |  | 475 |  |  |  | 166 |  |  |  | 309 |  |  |  | 0 |  |
| Corporate securities |  |  | 85,431 |  |  |  | 296 |  |  |  | (241 | ) |  |  | 85,486 |  |  |  | 6 |  |  |  | 6,298 |  |  |  | 79,182 |  |
| Municipal securities |  |  | 940 |  |  |  | 8 |  |  |  | 0 |  |  |  | 948 |  |  |  | 0 |  |  |  | 0 |  |  |  | 948 |  |
| Mortgage- and asset-backed securities |  |  | 12,907 |  |  |  | 26 |  |  |  | (49 | ) |  |  | 12,884 |  |  |  | 0 |  |  |  | 25 |  |  |  | 12,859 |  |
| Subtotal |  |  | 141,023 |  |  |  | 417 |  |  |  | (379 | ) |  |  | 141,061 |  |  |  | 2,066 |  |  |  | 8,833 |  |  |  | 130,162 |  |
| Total |  | $ | 155,332 |  |  | $ | 418 |  |  | $ | (511 | ) |  | $ | 155,239 |  |  | $ | 13,844 |  |  | $ | 11,233 |  |  | $ | 130,162 |  |

[0001193125-14-383437:notes:9]
|  |  | 2013 |  |
|  |  | Adjusted Cost |  |  | Unrealized Gains |  |  | Unrealized Losses |  |  | Fair Value |  |  | Cash and Cash Equivalents |  |  | Short-Term Marketable Securities |  |  | Long-Term Marketable Securities |  |
| Cash |  | $ | 8,705 |  |  | $ | 0 |  |  | $ | 0 |  |  | $ | 8,705 |  |  | $ | 8,705 |  |  | $ | 0 |  |  | $ | 0 |  |
| Level 1: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  |  | 1,793 |  |  |  | 0 |  |  |  | 0 |  |  |  | 1,793 |  |  |  | 1,793 |  |  |  | 0 |  |  |  | 0 |  |
| Mutual funds |  |  | 3,999 |  |  |  | 0 |  |  |  | (197 | ) |  |  | 3,802 |  |  |  | 0 |  |  |  | 3,802 |  |  |  | 0 |  |
| Subtotal |  |  | 5,792 |  |  |  | 0 |  |  |  | (197 | ) |  |  | 5,595 |  |  |  | 1,793 |  |  |  | 3,802 |  |  |  | 0 |  |
| Level 2: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities |  |  | 27,642 |  |  |  | 24 |  |  |  | (47 | ) |  |  | 27,619 |  |  |  | 431 |  |  |  | 7,554 |  |  |  | 19,634 |  |
| U.S. agency securities |  |  | 16,878 |  |  |  | 12 |  |  |  | (52 | ) |  |  | 16,838 |  |  |  | 177 |  |  |  | 3,412 |  |  |  | 13,249 |  |
| Non-U.S. government securities |  |  | 5,545 |  |  |  | 35 |  |  |  | (137 | ) |  |  | 5,443 |  |  |  | 50 |  |  |  | 313 |  |  |  | 5,080 |  |
| Certificates of deposit and time deposits |  |  | 2,344 |  |  |  | 0 |  |  |  | 0 |  |  |  | 2,344 |  |  |  | 1,264 |  |  |  | 844 |  |  |  | 236 |  |
| Commercial paper |  |  | 2,998 |  |  |  | 0 |  |  |  | 0 |  |  |  | 2,998 |  |  |  | 1,835 |  |  |  | 1,163 |  |  |  | 0 |  |
| Corporate securities |  |  | 54,586 |  |  |  | 275 |  |  |  | (252 | ) |  |  | 54,609 |  |  |  | 0 |  |  |  | 8,077 |  |  |  | 46,532 |  |
| Municipal securities |  |  | 6,257 |  |  |  | 45 |  |  |  | (22 | ) |  |  | 6,280 |  |  |  | 4 |  |  |  | 1,114 |  |  |  | 5,162 |  |
| Mortgage- and asset-backed securities |  |  | 16,396 |  |  |  | 23 |  |  |  | (89 | ) |  |  | 16,330 |  |  |  | 0 |  |  |  | 8 |  |  |  | 16,322 |  |
| Subtotal |  |  | 132,646 |  |  |  | 414 |  |  |  | (599 | ) |  |  | 132,461 |  |  |  | 3,761 |  |  |  | 22,485 |  |  |  | 106,215 |  |
| Total |  | $ | 147,143 |  |  | $ | 414 |  |  | $ | (796 | ) |  | $ | 146,761 |  |  | $ | 14,259 |  |  | $ | 26,287 |  |  | $ | 106,215 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-14-383437:notes:10]
Note 10 – Commitments and Contingencies

[0001193125-14-383437:notes:11]
Accrued Warranty and Indemnification

[0001193125-14-383437:notes:12]
The Company offers a basic limited parts and labor
 warranty on its hardware products. The basic warranty period for
 hardware products is typically one year from the date of purchase
 by the end-user. The Company also offers a 90-day basic warranty for its service
 parts used to repair the Company’s hardware products. The
 Company provides currently for the estimated cost that may be
 incurred under its basic limited product warranties at the time
 related revenue is recognized. Factors considered in determining
 appropriate accruals for product warranty obligations include the
 size of the installed base of products subject to warranty
 protection, historical and projected warranty claim rates,
 historical and projected cost-per-claim and knowledge of specific
 product failures that are outside of the Company’s typical
 experience. The Company assesses the adequacy of its pre-existing
 warranty liabilities and adjusts the amounts as necessary based on
 actual experience and changes in future estimates.

[0001193125-14-383437:notes:13]
The following table shows changes in the
 Company’s accrued warranties and related costs for 2014, 2013
 and 2012 (in millions):

[0001193125-14-383437:notes:14]
|  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Beginning accrued warranty and related costs |  | $ | 2,967 |  |  | $ | 1,638 |  |  | $ | 1,240 |  |
| Cost of warranty claims |  |  | (3,760 | ) |  |  | (3,703 | ) |  |  | (1,786 | ) |
| Accruals for product warranty |  |  | 4,952 |  |  |  | 5,032 |  |  |  | 2,184 |  |
| Ending accrued warranty and related costs |  | $ | 4,159 |  |  | $ | 2,967 |  |  | $ | 1,638 |  |

[0001193125-14-383437:notes:15]
The Company generally does not indemnify end-users
 of its operating system and application software against legal
 claims that the software infringes third-party intellectual
 property rights. Other agreements entered into by the Company
 sometimes include indemnification provisions under which the
 Company could be subject to costs and/or damages in the event of an
 infringement claim against the Company or an indemnified
 third-party. However, the Company has not been required to make any
 significant payments resulting from such an infringement claim
 asserted against it or an indemnified third-party. In the opinion
 of management, there was not at least a reasonable possibility the
 Company may have incurred a material loss with respect to
 indemnification of end-users of its operating system or application
 software for infringement of third-party intellectual property
 rights. The Company did not record a liability for infringement
 costs related to indemnification as of September 27, 2014 or
 September 28, 2013.

[0001193125-14-383437:notes:16]
The Company has entered into indemnification
 agreements with its directors and executive officers. Under these
 agreements, the Company has agreed to indemnify such individuals to
 the fullest extent permitted by law against liabilities that arise
 by reason of their status as directors or officers and to advance
 expenses incurred by such individuals in connection with related
 legal proceedings. It is not possible to determine the maximum
 potential amount of payments the Company could be required to make
 under these agreements due to the limited history of prior
 indemnification claims and the unique facts and circumstances
 involved in each claim. However, the Company maintains directors
 and officers liability insurance coverage to reduce its exposure to
 such obligations, and payments made under these agreements
 historically have not been material.

[0001193125-14-383437:notes:17]
Concentrations in the Available Sources of Supply of Materials
 and Product

[0001193125-14-383437:notes:18]
Although most components essential to the
 Company’s business are generally available from multiple
 sources, a number of components are currently obtained from single
 or limited sources. In addition, the Company competes for various
 components with other participants in the markets for mobile
 communication and media devices and personal computers. Therefore,
 many components used by the Company, including those that are
 available from multiple sources, are at times subject to
 industry-wide shortage and significant pricing fluctuations that
 could materially adversely affect the Company’s financial
 condition and operating results.

[0001193125-14-383437:notes:19]
The Company uses some custom components that are
 not commonly used by its competitors, and new products introduced
 by the Company often utilize custom components available from only
 one source. When a component or product uses new technologies,
 initial capacity constraints may exist until the suppliers’
 yields have matured or manufacturing capacity has increased. If the
 Company’s supply of components for a new or existing product
 were delayed or constrained, or if an outsourcing partner delayed
 shipments of completed products to the Company, the Company’s
 financial condition and operating results could be materially
 adversely affected. The Company’s business and financial
 performance could also be materially adversely affected depending
 on the time required to obtain sufficient quantities from the
 original source, or to identify and obtain sufficient quantities
 from an alternative source. Continued availability of these
 components at acceptable prices, or at all, may be affected if
 those suppliers concentrated on the production of common components
 instead of components customized to meet the Company’s
 requirements.

[0001193125-14-383437:notes:20]
The Company has entered into agreements for the
 supply of many components; however, there can be no guarantee that
 the Company will be able to extend or renew these agreements on
 similar terms, or at all. Therefore, the Company remains subject to
 significant risks of supply shortages and price increases that
 could materially adversely affect its financial condition and
 operating results.

[0001193125-14-383437:notes:21]
Substantially all of the Company’s hardware
 products are manufactured by outsourcing partners that are located
 primarily in Asia. A significant concentration of this
 manufacturing is currently performed by a small number of
 outsourcing partners, often in single locations. Certain of these
 outsourcing partners are the sole-sourced suppliers of components
 and manufacturers for many of the Company’s products.
 Although the Company works closely with its outsourcing partners on
 manufacturing schedules, the Company’s operating results
 could be adversely affected if its outsourcing partners were unable
 to meet their production commitments. The Company’s purchase
 commitments typically cover its requirements for periods up to 150
 days.

[0001193125-14-383437:notes:22]
Other Off-Balance Sheet Commitments

[0001193125-14-383437:notes:23]
Operating Leases

[0001193125-14-383437:notes:24]
The Company leases various equipment and
 facilities, including retail space, under noncancelable operating
 lease arrangements. The Company does not currently utilize any
 other off-balance sheet financing arrangements. The major facility
 leases are typically for terms not exceeding 10 years and generally
 contain multi-year renewal options. Leases for retail space are for
 terms ranging from five to 20 years, the majority of which are for
 10 years, and often contain multi-year renewal options. As of
 September 27, 2014, the Company’s total future minimum
 lease payments under noncancelable operating leases were $5.0
 billion, of which $3.6 billion related to leases for retail
 space.

[0001193125-14-383437:notes:25]
Rent expense under all operating leases, including
 both cancelable and noncancelable leases, was $717 million, $645
 million and $488 million in 2014, 2013 and 2012, respectively.
 Future minimum lease payments under noncancelable operating leases
 having remaining terms in excess of one year as of
 September 27, 2014, are as follows (in millions):

[0001193125-14-383437:notes:26]
| 2015 |  | $ | 662 |  |
| 2016 |  |  | 676 |  |
| 2017 |  |  | 645 |  |
| 2018 |  |  | 593 |  |
| 2019 |  |  | 534 |  |
| Thereafter |  |  | 1,877 |  |
| Total |  | $ | 4,987 |  |

[0001193125-14-383437:notes:27]
Other Commitments

[0001193125-14-383437:notes:28]
The Company utilizes several outsourcing partners
 to manufacture sub-assemblies for the Company’s products and
 to perform final assembly and testing of finished products. These
 outsourcing partners acquire components and build product based on
 demand information supplied by the Company, which typically covers
 periods up to 150 days. The Company also obtains individual
 components for its products from a wide variety of individual
 suppliers. Consistent with industry practice, the Company acquires
 components through a combination of purchase orders, supplier
 contracts and open orders based on projected demand information.
 Where appropriate, the purchases are applied
 to inventory component prepayments that
 are outstanding with the respective supplier. As of
 September 27, 2014, the Company had outstanding off-balance
 sheet third-party manufacturing commitments and component purchase
 commitments of $24.5 billion.

[0001193125-14-383437:notes:29]
In addition to the off-balance sheet commitments
 mentioned above, the Company had outstanding obligations of $3.4
 billion as of September 27, 2014, which consisted mainly of
 commitments to acquire capital assets, including product tooling
 and manufacturing process equipment, and commitments related to
 advertising, R&D, Internet and telecommunications services and
 other obligations.

[0001193125-14-383437:notes:30]
Contingencies

[0001193125-14-383437:notes:31]
The Company is subject to various legal proceedings
 and claims that have arisen in the ordinary course of business and
 that have not been fully adjudicated. In the opinion of management,
 there was not at least a reasonable possibility the Company may
 have incurred a material loss, or a material loss in excess of a
 recorded accrual, with respect to loss contingencies. However, the
 outcome of litigation is inherently uncertain. Therefore, although
 management considers the likelihood of such an outcome to be
 remote, if one or more of these legal matters were resolved against
 the Company in a reporting period for amounts in excess of
 management’s expectations, the Company’s consolidated
 financial statements for that reporting period could be materially
 adversely affected.

[0001193125-14-383437:notes:32]
Apple Inc. v. Samsung Electronics Co., Ltd, et al.

[0001193125-14-383437:notes:33]
On August 24, 2012, a jury returned a verdict
 awarding the Company $1.05 billion in its lawsuit against Samsung
 Electronics Co., Ltd and affiliated parties in the United States
 District Court, Northern District of California, San Jose Division.
 On March 6, 2014, the District Court entered final judgment in
 favor of the Company in the amount of approximately $930
 million. Because the award is now subject to appeal, the
 Company has not recognized the award in its results of
 operations.

[0001193125-14-383437:notes:34]
VirnetX, Inc. v. Apple Inc. et al.

[0001193125-14-383437:notes:35]
On August 11, 2010, VirnetX, Inc. filed an
 action against the Company alleging that certain of its products
 infringed on four patents relating to network communications
 technology. On November 6, 2012, a jury returned a verdict
 against the Company, and awarded damages of $368 million. On
 September 16, 2014, the Court of Appeals for the Federal
 Circuit affirmed the District Court’s decision in part,
 reversed in part, and vacated the damages award. The case has been
 remanded for further proceedings.


## us-gaap:DebtDisclosureTextBlock

[0001193125-14-383437:notes:36]
Note 6 – Debt

[0001193125-14-383437:notes:37]
Commercial Paper

[0001193125-14-383437:notes:38]
In April 2014, the Board of Directors authorized
 the Company to issue unsecured short-term promissory notes
 (“Commercial Paper”) pursuant to a commercial paper
 program. The Company intends to use net proceeds from the
 commercial paper program for general corporate purposes, including
 dividends and share repurchases. As of September 27, 2014, the
 Company had $6.3 billion of Commercial Paper outstanding, with a
 weighted-average interest rate of 0.12% and maturities generally
 less than nine months.

[0001193125-14-383437:notes:39]
The following table provides a summary of cash
 flows associated with the issuance and maturities of Commercial
 Paper for 2014 (in millions):

[0001193125-14-383437:notes:40]
| Maturities less than 90 days: |  |  |  |  |
| Proceeds from (repayments of) commercial paper, net |  | $ | 1,865 |  |
| Maturities greater than 90 days: |  |  |  |  |
| Proceeds from commercial paper |  |  | 4,771 |  |
| Repayments of commercial paper |  |  | (330 | ) |
| Maturities greater than 90 days, net |  |  | 4,441 |  |
| Total proceeds from issuance of commercial paper, net |  | $ | 6,306 |  |

[0001193125-14-383437:notes:41]
Long-Term Debt

[0001193125-14-383437:notes:42]
In the third quarter of 2014 and 2013, the Company
 issued $12.0 billion and $17.0 billion of long-term debt,
 respectively. The debt issuances included floating- and fixed-rate
 notes with varying maturities for an aggregate principal amount of
 $29.0 billion (collectively the “Notes”). The Notes are
 senior unsecured obligations, and interest is payable in arrears,
 quarterly for the floating-rate notes and semi-annually for the
 fixed-rate notes.

[0001193125-14-383437:notes:43]
The following table provides a summary of the
 Company’s long-term debt as of September 27, 2014 and
 September 28, 2013:

[0001193125-14-383437:notes:44]
|  |  | 2014 |  |  | 2013 |  |
|  |  | Amount(in millions) |  |  | Effective Interest Rate |  |  | Amount(in millions) |  |  | Effective Interest Rate |  |
| Floating-rate notes due 2016 |  | $ | 1,000 |  |  |  | 0.51% |  |  | $ | 1,000 |  |  |  | 0.51% |  |
| Floating-rate notes due 2017 |  |  | 1,000 |  |  |  | 0.31% |  |  |  | 0 |  |  |  | 0 |  |
| Floating-rate notes due 2018 |  |  | 2,000 |  |  |  | 1.10% |  |  |  | 2,000 |  |  |  | 1.10% |  |
| Floating-rate notes due 2019 |  |  | 1,000 |  |  |  | 0.54% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 0.45% notes due 2016 |  |  | 1,500 |  |  |  | 0.51% |  |  |  | 1,500 |  |  |  | 0.51% |  |
| Fixed-rate 1.05% notes due 2017 |  |  | 1,500 |  |  |  | 0.30% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 1.00% notes due 2018 |  |  | 4,000 |  |  |  | 1.08% |  |  |  | 4,000 |  |  |  | 1.08% |  |
| Fixed-rate 2.10% notes due 2019 |  |  | 2,000 |  |  |  | 0.53% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.85% notes due 2021 |  |  | 3,000 |  |  |  | 0.79% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.40% notes due 2023 |  |  | 5,500 |  |  |  | 2.44% |  |  |  | 5,500 |  |  |  | 2.44% |  |
| Fixed-rate 3.45% notes due 2024 |  |  | 2,500 |  |  |  | 0.90% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 3.85% notes due 2043 |  |  | 3,000 |  |  |  | 3.91% |  |  |  | 3,000 |  |  |  | 3.91% |  |
| Fixed-rate 4.45% notes due 2044 |  |  | 1,000 |  |  |  | 4.48% |  |  |  | 0 |  |  |  | 0 |  |
| Total borrowings |  |  | 29,000 |  |  |  |  |  |  |  | 17,000 |  |  |  |  |  |
| Unamortized discount |  |  | (52 | ) |  |  |  |  |  |  | (40 | ) |  |  |  |  |
| Hedge accounting fair value adjustments |  |  | 39 |  |  |  |  |  |  |  | 0 |  |  |  |  |  |
| Total long-term debt |  | $ | 28,987 |  |  |  |  |  |  | $ | 16,960 |  |  |  |  |  |

[0001193125-14-383437:notes:45]
The Company has entered, and may enter in the
 future, into interest rate swaps to manage interest rate risk on
 the Notes. Such swaps allow the Company to effectively convert
 fixed-rate payments into floating-rate payments or floating-rate
 payments into fixed-rate payments. In the third quarter of 2014,
 the Company entered into interest rate swaps with an aggregate
 notional amount of $9.0 billion, which effectively converted the
 fixed-rate notes due 2017, 2019, 2021 and 2024 into floating-rate
 notes. In the third quarter of 2013, the Company entered into
 interest rate swaps with an aggregate notional amount of $3.0
 billion, which effectively converted the floating-rate notes due
 2016 and 2018 into fixed-rate notes.

[0001193125-14-383437:notes:46]
The effective rates for the Notes include the
 interest on the Notes, amortization of the discount and, if
 applicable, adjustments related to hedging. The Company recognized
 $381 million and $136 million of interest expense on its long-term
 debt for the years ended September 27, 2014 and
 September 28, 2013, respectively. The Company did not have any
 long-term debt in 2012.

[0001193125-14-383437:notes:47]
Future principal payments for the Company’s
 Notes as of September 27, 2014, are as follows (in
 millions):

[0001193125-14-383437:notes:48]
| 2015 |  | $ | 0 |  |
| 2016 |  |  | 2,500 |  |
| 2017 |  |  | 2,500 |  |
| 2018 |  |  | 6,000 |  |
| 2019 |  |  | 3,000 |  |
| Thereafter |  |  | 15,000 |  |
| Total |  | $ | 29,000 |  |

[0001193125-14-383437:notes:49]
As of September 27, 2014 and
 September 28, 2013, the fair value of the Company’s
 Notes, based on Level 2 inputs, was $28.5 billion and $15.9
 billion, respectively.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001193125-14-383437:notes:50]
Earnings Per Share

[0001193125-14-383437:notes:51]
Basic earnings per share is computed by dividing
 income available to common shareholders by the weighted-average
 number of shares of common stock outstanding during the period.
 Diluted earnings per share is computed by dividing income available
 to common shareholders by the weighted-average number of shares of
 common stock outstanding during the period increased to include the
 number of additional shares of common stock that would have been
 outstanding if the potentially dilutive securities had been issued.
 Potentially dilutive securities include outstanding stock options,
 shares to be purchased under the Company’s employee stock
 purchase plan, unvested restricted stock and unvested RSUs. The
 dilutive effect of potentially dilutive securities is reflected in
 diluted earnings per share by application of the treasury stock
 method. Under the treasury stock method, an increase in the fair
 market value of the Company’s common stock can result in a
 greater dilutive effect from potentially dilutive securities.

[0001193125-14-383437:notes:52]
The following table shows the computation of basic
 and diluted earnings per share for 2014, 2013 and 2012 (net income
 in millions and shares in thousands):

[0001193125-14-383437:notes:53]
|  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 39,510 |  |  | $ | 37,037 |  |  | $ | 41,733 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding |  |  | 6,085,572 |  |  |  | 6,477,320 |  |  |  | 6,543,726 |  |
| Effect of dilutive securities |  |  | 37,091 |  |  |  | 44,314 |  |  |  | 73,757 |  |
| Weighted-average diluted shares |  |  | 6,122,663 |  |  |  | 6,521,634 |  |  |  | 6,617,483 |  |
| Basic earnings per share |  | $ | 6.49 |  |  | $ | 5.72 |  |  | $ | 6.38 |  |
| Diluted earnings per share |  | $ | 6.45 |  |  | $ | 5.68 |  |  | $ | 6.31 |  |

[0001193125-14-383437:notes:54]
Potentially dilutive securities, the effect of
 which would have been antidilutive, were not significant for 2014,
 2013 and 2012. The Company excluded these securities from the
 computation of diluted earnings per share.


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0001193125-14-383437:notes:55]
Long-Lived Assets Including Goodwill and Other Acquired
 Intangible Assets

[0001193125-14-383437:notes:56]
The Company reviews property, plant and equipment,
 inventory component prepayments and certain identifiable
 intangibles, excluding goodwill, for impairment. Long-lived assets
 are reviewed for impairment whenever events or changes in
 circumstances indicate the carrying amount of an asset may not be
 recoverable. Recoverability of these assets is measured by
 comparison of their carrying amounts to future undiscounted cash
 flows the assets are expected to generate. If property, plant and
 equipment, inventory component prepayments and certain identifiable
 intangibles are considered to be impaired, the impairment to be
 recognized equals the amount by which the carrying value of the
 assets exceeds its fair value. The Company did not record any
 significant impairments during 2014, 2013 and 2012.

[0001193125-14-383437:notes:57]
The Company does not amortize goodwill and
 intangible assets with indefinite useful lives, rather such assets
 are required to be tested for impairment at least annually or
 sooner whenever events or changes in circumstances indicate that
 the assets may be impaired. The Company performs its goodwill and
 intangible asset impairment tests in the fourth quarter of each
 year. The Company did not recognize any impairment charges related
 to goodwill or indefinite lived intangible assets during 2014, 2013
 and 2012. The Company established reporting units based on its
 current reporting structure. For purposes of testing goodwill for
 impairment, goodwill has been allocated to these reporting units to
 the extent it relates to each reporting unit. In 2014 and 2013, the
 Company’s goodwill was allocated to the Americas and Europe
 reportable operating segments.

[0001193125-14-383437:notes:58]
The Company amortizes its intangible assets with
 definite useful lives over their estimated useful lives and reviews
 these assets for impairment. The Company typically amortizes its
 acquired intangible assets with definite useful lives over periods
 from three to seven years.


## us-gaap:InventoryPolicyTextBlock

[0001193125-14-383437:notes:59]
Inventories

[0001193125-14-383437:notes:60]
Inventories are stated at the lower of cost,
 computed using the first-in, first-out method, or market. If the
 cost of the inventories exceeds their market value, provisions are
 made currently for the difference between the cost and the market
 value.


## us-gaap:ReconciliationOfAssetsFromSegmentToConsolidatedTextBlock

[0001193125-14-383437:notes:61]
The following table shows total assets by segment
 and reconciliation to the Consolidated Balance Sheets as of
 September 27, 2014 and September 28, 2013 (in
 millions):

[0001193125-14-383437:notes:62]
|  |  | 2014 |  |  | 2013 |  |
| Segment assets: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 9,352 |  |  | $ | 5,653 |  |
| Europe |  |  | 4,631 |  |  |  | 3,134 |  |
| Greater China |  |  | 3,172 |  |  |  | 2,943 |  |
| Japan |  |  | 3,106 |  |  |  | 2,932 |  |
| Rest of Asia Pacific |  |  | 908 |  |  |  | 923 |  |
| Retail |  |  | 3,626 |  |  |  | 3,329 |  |
| Total segment assets |  |  | 24,795 |  |  |  | 18,914 |  |
| Corporate assets |  |  | 207,044 |  |  |  | 188,086 |  |
| Total assets |  | $ | 231,839 |  |  | $ | 207,000 |  |


## us-gaap:ScheduleOfEffectiveIncomeTaxRateReconciliationTableTextBlock

[0001193125-14-383437:notes:63]
A reconciliation of the provision for income taxes,
 with the amount computed by applying the statutory federal income
 tax rate (35% in 2014, 2013 and 2012) to income before provision
 for income taxes for 2014, 2013 and 2012, is as follows (dollars in
 millions):

[0001193125-14-383437:notes:64]
|  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Computed expected tax |  | $ | 18,719 |  |  | $ | 17,554 |  |  | $ | 19,517 |  |
| State taxes, net of federal effect |  |  | 469 |  |  |  | 508 |  |  |  | 677 |  |
| Indefinitely invested earnings of foreign subsidiaries |  |  | (4,744 | ) |  |  | (4,614 | ) |  |  | (5,895 | ) |
| Research and development credit, net |  |  | (88 | ) |  |  | (287 | ) |  |  | (103 | ) |
| Domestic production activities deduction |  |  | (495 | ) |  |  | (308 | ) |  |  | (328 | ) |
| Other |  |  | 112 |  |  |  | 265 |  |  |  | 162 |  |
| Provision for income taxes |  | $ | 13,973 |  |  | $ | 13,118 |  |  | $ | 14,030 |  |
| Effective tax rate |  |  | 26.1% |  |  |  | 26.2% |  |  |  | 25.2% |  |


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001193125-14-383437:notes:65]
Long-lived assets
 as of September 27, 2014 and September 28, 2013 are as
 follows (in millions):

[0001193125-14-383437:notes:66]
|  |  | 2014 |  |  | 2013 |  |  |  |  |
| Long-lived assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. |  | $ | 9,108 |  |  | $ | 7,399 |  |  |  |  |  |
| China (1) |  |  | 9,477 |  |  |  | 7,403 |  |  |  |  |  |
| Other countries |  |  | 2,917 |  |  |  | 2,786 |  |  |  |  |  |
| Total long-lived assets |  | $ | 21,502 |  |  | $ | 17,588 |  |  |  |  |  |

[0001193125-14-383437:notes:67]
|  | (1) | China includes Hong Kong. Long-lived assets located in China consist primarily of product tooling and manufacturing process equipment and assets related to retail stores and related infrastructure. |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001193125-14-383437:notes:68]
Note 1 – Summary of Significant Accounting
 Policies

[0001193125-14-383437:notes:69]
Apple Inc. and its wholly-owned subsidiaries
 (collectively “Apple” or the “Company”)
 designs, manufactures and markets mobile communication and media
 devices, personal computers and portable digital music players, and
 sells a variety of related software, services, accessories,
 networking solutions and third-party digital content and
 applications. The Company sells its products worldwide through its
 retail stores, online stores and direct sales force, as well as
 through third-party cellular network carriers, wholesalers,
 retailers and value-added resellers. In addition, the Company sells
 a variety of third-party iPhone, iPad, Mac and iPod compatible
 products, including application software, and various accessories
 through its online and retail stores. The Company sells to
 consumers, small and mid-sized businesses, and education,
 enterprise and government customers.

[0001193125-14-383437:notes:70]
Common Stock Split

[0001193125-14-383437:notes:71]
On June 6, 2014, the Company effected a
 seven-for-one stock split to shareholders of record as of
 June 2, 2014. All share and per share information has been
 retroactively adjusted to reflect the stock split.

[0001193125-14-383437:notes:72]
Revenue Recognition

[0001193125-14-383437:notes:73]
Net sales consist primarily of revenue from the
 sale of hardware, software, digital content and applications,
 accessories and service and support contracts. The Company
 recognizes revenue when persuasive evidence of an arrangement
 exists, delivery has occurred, the sales price is fixed or
 determinable and collection is probable. Product is considered
 delivered to the customer once it has been shipped and title, risk
 of loss and rewards of ownership have been transferred. For most of
 the Company’s product sales, these criteria are met at the
 time the product is shipped. For online sales to individuals, for
 some sales to education customers in the U.S., and for certain
 other sales, the Company defers revenue until the customer receives
 the product because the Company retains a portion of the risk of
 loss on these sales during transit. The Company recognizes revenue
 from the sale of hardware products, software bundled with hardware
 that is essential to the functionality of the hardware, and
 third-party digital content sold on the iTunes Store in accordance
 with general revenue recognition accounting guidance. The Company
 recognizes revenue in accordance with industry specific software
 accounting guidance for the following types of sales transactions:
 (i) standalone sales of software products, (ii) sales of
 software upgrades and (iii) sales of software bundled with
 hardware not essential to the functionality of the hardware.

[0001193125-14-383437:notes:74]
For the sale of most third-party products, the
 Company recognizes revenue based on the gross amount billed to
 customers because the Company establishes its own pricing for such
 products, retains related inventory risk for physical products, is
 the primary obligor to the customer and assumes the credit risk for
 amounts billed to its customers. For third-party applications sold
 through the App Store and Mac App Store and certain digital content
 sold through the iTunes Store, the Company does not determine the
 selling price of the products and is not the primary obligor to the
 customer. Therefore, the Company accounts for such sales on a net
 basis by recognizing in net sales only the commission it retains
 from each sale. The portion of the gross amount billed to customers
 that is remitted by the Company to third-party app developers and
 certain digital content owners is not reflected in the
 Company’s Consolidated Statements of Operations.

[0001193125-14-383437:notes:75]
The Company records deferred revenue when it
 receives payments in advance of the delivery of products or the
 performance of services. This includes amounts that have been
 deferred for unspecified and specified software upgrade rights and
 non-software services that are attached to hardware and software
 products. The Company sells gift cards redeemable at its retail and
 online stores, and also sells gift cards redeemable on the iTunes
 Store for the purchase of digital content and software. The Company
 records deferred revenue upon the sale of the card, which is
 relieved upon redemption of the card by the customer. Revenue from
 AppleCare service and support contracts is deferred and recognized
 over the service coverage periods. AppleCare service and support
 contracts typically include extended phone support, repair
 services, web-based support resources and diagnostic tools offered
 under the Company’s standard limited warranty.

[0001193125-14-383437:notes:76]
The Company records reductions to revenue for
 estimated commitments related to price protection and other
 customer incentive programs. For transactions involving price
 protection, the Company recognizes revenue net of the estimated
 amount to be refunded. For the Company’s other customer
 incentive programs, the estimated cost of these programs is
 recognized at the later of the date at which the Company has sold
 the product or the date at which the program is offered. The
 Company also records reductions to revenue for expected future
 product returns based on the Company’s historical experience.
 Revenue is recorded net of taxes collected from customers that are
 remitted to governmental authorities, with the collected taxes
 recorded as current liabilities until remitted to the relevant
 government authority.

[0001193125-14-383437:notes:77]
Revenue Recognition for Arrangements with Multiple
 Deliverables

[0001193125-14-383437:notes:78]
For multi-element arrangements that include
 hardware products containing software essential to the hardware
 product’s functionality, undelivered software elements that
 relate to the hardware product’s essential software, and
 undelivered non-software services, the Company allocates revenue to
 all deliverables based on their relative selling prices. In such
 circumstances, the Company uses a hierarchy to determine the
 selling price to be used for allocating revenue to deliverables:
 (i) vendor-specific objective evidence of fair value
 (“VSOE”), (ii) third-party evidence of selling
 price (“TPE”) and (iii) best estimate of selling
 price (“ESP”). VSOE generally exists only when the
 Company sells the deliverable separately and is the price actually
 charged by the Company for that deliverable. ESPs reflect the
 Company’s best estimates of what the selling prices of
 elements would be if they were sold regularly on a stand-alone
 basis. For multi-element arrangements accounted for in accordance
 with industry specific software accounting guidance, the Company
 allocates revenue to all deliverables based on the VSOE of each
 element, and if VSOE does not exist revenue is recognized when
 elements lacking VSOE are delivered.

[0001193125-14-383437:notes:79]
For sales of qualifying versions of iPhone, iPad
 and iPod touch (“iOS devices”), Mac and Apple TV, the
 Company has indicated it may from time to time provide future
 unspecified software upgrades and features to the essential
 software bundled with each of these hardware products free of
 charge to customers. Essential software for iOS devices includes
 iOS and related applications and for Mac includes OS X and related
 applications. The Company also provides various non-software
 services to owners of qualifying versions of iOS devices and Mac.
 The Company has identified up to three deliverables regularly
 included in arrangements involving the sale of these devices. The
 first deliverable is the hardware and software essential to the
 functionality of the hardware device delivered at the time of sale.
 The second deliverable is the embedded right included with the
 purchase of iOS devices, Mac and Apple TV to receive on a
 when-and-if-available basis, future unspecified software upgrades
 and features relating to the product’s essential software.
 The third deliverable is the non-software services to be provided
 to qualifying versions of iOS devices and Mac. The Company
 allocates revenue between these deliverables using the relative
 selling price method. Because the Company has neither VSOE nor TPE
 for these deliverables, the allocation of revenue is based on the
 Company’s ESPs. Revenue allocated to the delivered hardware
 and the related essential software is recognized at the time of
 sale provided the other conditions for revenue recognition have
 been met. Revenue allocated to the embedded unspecified software
 upgrade rights and the non-software services is deferred and
 recognized on a straight-line basis over the estimated period the
 software upgrades and non-software services are expected to be
 provided for each of these devices, which ranges from two to four
 years. Cost of sales related to delivered hardware and related
 essential software, including estimated warranty costs, are
 recognized at the time of sale. Costs incurred to provide
 non-software services are recognized as cost of sales as incurred,
 and engineering and sales and marketing costs are recognized as
 operating expenses as incurred.

[0001193125-14-383437:notes:80]
The Company’s process for determining its ESP
 for deliverables without VSOE or TPE considers multiple factors
 that may vary depending upon the unique facts and circumstances
 related to each deliverable. The Company believes its customers
 would be reluctant to buy unspecified software upgrade rights for
 the essential software included with its qualifying hardware
 products. This view is primarily based on the fact that unspecified
 software upgrade rights do not obligate the Company to provide
 upgrades at a particular time or at all, and do not specify to
 customers which upgrades or features will be delivered. The Company
 also believes its customers would be unwilling to pay a significant
 amount for access to the non-software services because other
 companies offer similar services at little or no cost to users.
 Therefore, the Company has concluded that if it were to sell
 upgrade rights or access to the non-software services on a
 standalone basis, including those rights and services attached to
 iOS devices, Mac and Apple TV, the selling prices would be
 relatively low. Key factors considered by the Company in developing
 the ESPs for software upgrade rights include prices charged by the
 Company for similar offerings, market trends in the pricing of
 Apple-branded and third-party Mac and iOS compatible software, the
 nature of the upgrade rights (e.g., unspecified versus specified)
 and the relative ESP of the upgrade rights as compared to the total
 selling price of the product. The Company may also consider
 additional factors as appropriate, including the impact of other
 products and services provided to customers, the pricing of
 competitive alternatives if they exist, product-specific business
 objectives and the length of time a particular version of a device
 has been available. When relevant, the same factors are considered
 by the Company in developing ESPs for offerings such as the
 non-software services with additional consideration given to the
 estimated cost to provide such services.

[0001193125-14-383437:notes:81]
In 2014, 2013 and 2012, the Company’s
 combined ESPs for the unspecified software upgrade rights and the
 rights to receive the non-software services included with its
 qualifying hardware devices have ranged from $5 to $40. As of
 September 27, 2014, the combined ESPs for Mac was $40 and for
 iPhone and iPad ranged from $15 to $25. Revenue allocated to such
 rights is deferred and recognized on a straight-line basis over the
 estimated period the rights are expected to be provided for each
 device, which ranges from two to four years.

[0001193125-14-383437:notes:82]
Shipping Costs

[0001193125-14-383437:notes:83]
For all periods presented, amounts billed to
 customers related to shipping and handling are classified as
 revenue, and the Company’s shipping and handling costs are
 included in cost of sales.

[0001193125-14-383437:notes:84]
Warranty Costs

[0001193125-14-383437:notes:85]
The Company generally provides for the estimated
 cost of hardware and software warranties at the time the related
 revenue is recognized. The Company assesses the adequacy of its
 pre-existing warranty liabilities and adjusts the amounts as
 necessary based on actual experience and changes in future
 estimates.

[0001193125-14-383437:notes:86]
Software Development Costs

[0001193125-14-383437:notes:87]
Research and development (“R&D”)
 costs are expensed as incurred. Development costs of computer
 software to be sold, leased, or otherwise marketed are subject to
 capitalization beginning when a product’s technological
 feasibility has been established and ending when a product is
 available for general release to customers. In most instances, the
 Company’s products are released soon after technological
 feasibility has been established. Costs incurred subsequent to
 achievement of technological feasibility were not significant, and
 software development costs were expensed as incurred during 2014,
 2013 and 2012.

[0001193125-14-383437:notes:88]
Share-based Compensation

[0001193125-14-383437:notes:89]
The Company recognizes expense related to
 share-based payment transactions in which it receives employee
 services in exchange for (a) equity instruments of the Company
 or (b) liabilities that are based on the fair value of the
 enterprise’s equity instruments or that may be settled by the
 issuance of such equity instruments. Share-based compensation cost
 for restricted stock and restricted stock units
 (“RSUs”) is measured based on the closing fair market
 value of the Company’s common stock on the date of grant. The
 Company recognizes share-based compensation cost over the
 award’s requisite service period on a straight-line basis for
 time-based RSUs and on a graded basis for RSUs that are contingent
 on the achievement of performance metrics. The Company recognizes a
 benefit from share-based compensation in the Consolidated
 Statements of Shareholders’ Equity if an incremental tax
 benefit is realized. In addition, the Company recognizes the
 indirect effects of share-based compensation on R&D tax
 credits, foreign tax credits and domestic manufacturing deductions
 in the Consolidated Statements of Operations. Further information
 regarding share-based compensation can be found in Note 9,
 “Benefit Plans” of this Form 10-K.

[0001193125-14-383437:notes:90]
Income Taxes

[0001193125-14-383437:notes:91]
The provision for income taxes is computed using
 the asset and liability method, under which deferred tax assets and
 liabilities are recognized for the expected future tax consequences
 of temporary differences between the financial reporting and tax
 bases of assets and liabilities and for operating losses and tax
 credit carryforwards. Deferred tax assets and liabilities are
 measured using the currently enacted tax rates that apply to
 taxable income in effect for the years in which those tax assets
 are expected to be realized or settled. The Company records a
 valuation allowance to reduce deferred tax assets to the amount
 that is believed more likely than not to be realized.

[0001193125-14-383437:notes:92]
The Company recognizes the tax benefit from an
 uncertain tax position only if it is more likely than not the tax
 position will be sustained on examination by the taxing
 authorities, based on the technical merits of the position. The tax
 benefits recognized in the financial statements from such positions
 are then measured based on the largest benefit that has a greater
 than 50% likelihood of being realized upon settlement. See Note 5,
 “Income Taxes” of this Form 10-K for additional
 information.

[0001193125-14-383437:notes:93]
Financial Instruments

[0001193125-14-383437:notes:94]
Cash Equivalents and Marketable Securities

[0001193125-14-383437:notes:95]
All highly liquid investments with maturities of
 three months or less at the date of purchase are classified as cash
 equivalents. The Company’s marketable debt and equity
 securities have been classified and accounted for as available-for-sale. Management
 determines the appropriate classification of its investments at the
 time of purchase and reevaluates the designations at each balance
 sheet date. The Company classifies its marketable debt securities
 as either short-term or long-term based on each instrument’s
 underlying contractual maturity date. Marketable debt securities
 with maturities of 12 months or less are classified as short-term
 and marketable debt securities with maturities greater than 12
 months are classified as long-term. The Company classifies its
 marketable equity securities, including mutual funds, as either
 short-term or long-term based on the nature of each security and
 its availability for use in current operations. The Company’s
 marketable debt and equity securities are carried at fair value,
 with the unrealized gains and losses, net of taxes, reported as a
 component of shareholders’ equity. The cost of securities
 sold is based upon the specific identification method.

[0001193125-14-383437:notes:96]
Derivative Financial Instruments

[0001193125-14-383437:notes:97]
The Company accounts for its derivative instruments
 as either assets or liabilities and carries them at fair value.

[0001193125-14-383437:notes:98]
For derivative instruments that hedge the exposure
 to variability in expected future cash flows that are designated as
 cash flow hedges, the effective portion of the gain or loss on the
 derivative instrument is reported as a component of AOCI in
 shareholders’ equity and reclassified into income in the same
 period or periods during which the hedged transaction affects
 earnings. The ineffective portion of the gain or loss on the
 derivative instrument, if any, is recognized in current income. To
 receive hedge accounting treatment, cash flow hedges must be highly
 effective in offsetting changes to expected future cash flows on
 hedged transactions. For options designated as cash flow hedges,
 changes in the time value are excluded from the assessment of hedge
 effectiveness and are recognized in income. For derivative
 instruments that hedge the exposure to changes in the fair value of
 an asset or a liability and that are designated as fair value
 hedges, both the net gain or loss on the derivative instrument as
 well as the offsetting gain or loss on the hedged item attributable
 to the hedged risk are recognized in earnings in the current
 period. For derivative instruments designated as a hedge of the
 foreign currency translation exposure of the net investment in a
 foreign operation, the net gain or loss on the effective portion of
 the derivative instrument is reported in the same manner as a
 foreign currency translation adjustment. For forward exchange
 contracts designated as net investment hedges, the Company excludes
 changes in fair value relating to changes in the forward carry
 component from its definition of effectiveness. Accordingly, any
 gains or losses related to this component are recognized in current
 income. Derivatives that do not qualify as hedges are adjusted to
 fair value through current income.

[0001193125-14-383437:notes:99]
Allowance for Doubtful Accounts

[0001193125-14-383437:notes:100]
The Company records its allowance for doubtful
 accounts based upon its assessment of various factors. The Company
 considers historical experience, the age of the accounts receivable
 balances, credit quality of the Company’s customers, current
 economic conditions and other factors that may affect
 customers’ ability to pay.

[0001193125-14-383437:notes:101]
Property, Plant and Equipment

[0001193125-14-383437:notes:102]
Property, plant and equipment are stated at cost.
 Depreciation is computed by use of the straight-line method over the
 estimated useful lives of the assets, which for buildings is the
 lesser of 30 years or the remaining life of the underlying
 building; between two to five years for machinery and equipment,
 including product tooling and manufacturing process equipment; and
 the shorter of lease terms or ten years for leasehold improvements.
 The Company capitalizes eligible costs to acquire or develop
 internal-use software that are incurred subsequent to the
 preliminary project stage. Capitalized costs related to
 internal-use software are amortized using the straight-line method
 over the estimated useful lives of the assets, which range from
 three to five years. Depreciation and amortization expense on
 property and equipment was $6.9 billion, $5.8 billion and $2.6
 billion during 2014, 2013 and 2012, respectively.

[0001193125-14-383437:notes:103]
Fair Value Measurements

[0001193125-14-383437:notes:104]
The Company applies fair value accounting for all
 financial assets and liabilities and non-financial assets and
 liabilities that are recognized or disclosed at fair value in the
 financial statements on a recurring basis. The Company defines fair
 value as the price that would be received from selling an asset or
 paid to transfer a liability in an orderly transaction between
 market participants at the measurement date. When determining the
 fair value measurements for assets and liabilities, which are
 required to be recorded at fair value, the Company considers the
 principal or most advantageous market in which the Company would
 transact and the market-based risk measurements or assumptions that
 market participants would use in pricing the asset or liability,
 such as risks inherent in valuation techniques, transfer
 restrictions and credit risk. Fair value is estimated by applying
 the following hierarchy, which prioritizes the inputs used to
 measure fair value into three levels and bases the categorization
 within the hierarchy upon the lowest level of input that is
 available and significant to the fair value measurement:

[0001193125-14-383437:notes:105]
Level 1 – Quoted prices in active
 markets for identical assets or liabilities.

[0001193125-14-383437:notes:106]
Level 2 – Observable inputs other than
 quoted prices in active markets for identical assets and
 liabilities, quoted prices for identical or similar assets or
 liabilities in inactive markets, or other inputs that are
 observable or can be corroborated by observable market data for
 substantially the full term of the assets or liabilities.

[0001193125-14-383437:notes:107]
Level 3 – Inputs that are generally
 unobservable and typically reflect management’s estimate of
 assumptions that market participants would use in pricing the asset
 or liability.

[0001193125-14-383437:notes:108]
The Company’s valuation techniques used to
 measure the fair value of money market funds and certain marketable
 equity securities were derived from quoted prices in active markets
 for identical assets or liabilities. The valuation techniques used
 to measure the fair value of the Company’s debt instruments
 and all other financial instruments, all of which have
 counterparties with high credit ratings, were valued based on
 quoted market prices or model driven valuations using significant
 inputs derived from or corroborated by observable market data.

[0001193125-14-383437:notes:109]
In accordance with the fair value accounting
 requirements, companies may choose to measure eligible financial
 instruments and certain other items at fair value. The Company has
 not elected the fair value option for any eligible financial
 instruments.

[0001193125-14-383437:notes:110]
Foreign Currency Translation and Remeasurement

[0001193125-14-383437:notes:111]
The Company translates the assets and liabilities
 of its non-U.S. dollar functional currency subsidiaries into U.S.
 dollars using exchange rates in effect at the end of each period.
 Revenue and expenses for these subsidiaries are translated using
 rates that approximate those in effect during the period. Gains and
 losses from these translations are recognized in foreign currency
 translation included in AOCI in shareholders’ equity. The
 Company’s subsidiaries that use the U.S. dollar as their
 functional currency remeasure monetary assets and liabilities at
 exchange rates in effect at the end of each period, and
 inventories, property and nonmonetary assets and liabilities at
 historical rates. Gains and losses from these remeasurements were
 not significant during 2014, 2013 and 2012 and have been included
 in the Company’s results of operations.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-14-383437:notes:112]
Note 4 – Goodwill and Other Intangible Assets

[0001193125-14-383437:notes:113]
On July 31, 2014, the Company completed the
 acquisitions of Beats Music, LLC, which offers a subscription
 streaming music service, and Beats Electronics, LLC, which makes
 Beats®
 headphones, speakers and audio software (collectively,
 “Beats”). The total purchase price consideration for
 these acquisitions was $2.6 billion, which consisted primarily of
 cash, of which $2.2 billion was allocated to goodwill, $636 million
 to acquired intangible assets and $258 million to net liabilities
 assumed. Concurrent with the close of the acquisition, the Company
 repaid $295 million of existing Beats outstanding debt to
 third-party creditors. In conjunction with the Beats acquisitions,
 the Company issued approximately 5.1 million shares of its
 common stock to certain former equity holders of Beats. The
 restricted stock was valued at approximately $485 million based on
 the Company’s common stock on the acquisition date. The
 majority of these shares, valued at approximately $417 million,
 will vest over time based on continued employment with Apple.

[0001193125-14-383437:notes:114]
The Company also completed various other business
 acquisitions during 2014 for an aggregate cash consideration, net
 of cash acquired, of $957 million, of which $828 million was
 allocated to goodwill, $257 million to acquired intangible assets
 and $128 million to net liabilities assumed.

[0001193125-14-383437:notes:115]
The Company completed various business acquisitions
 during 2013 for an aggregate cash consideration, net of cash
 acquired, of $496 million, of which $419 million was allocated to
 goodwill, $179 million to acquired intangible assets and $102
 million to net liabilities assumed.

[0001193125-14-383437:notes:116]
The Company’s gross carrying amount of
 goodwill was $4.6 billion and $1.6 billion as of September 27,
 2014 and September 28, 2013, respectively. The Company did not
 have any goodwill impairments during 2014, 2013 or 2012.

[0001193125-14-383437:notes:117]
The following table summarizes the components of
 gross and net intangible asset balances as of September 27,
 2014 and September 28, 2013 (in millions):

[0001193125-14-383437:notes:118]
|  |  | 2014 |  |  | 2013 |  |
|  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Carrying Amount |  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Carrying Amount |  |
| Definite-lived and amortizable acquired intangible assets |  | $ | 7,127 |  |  | $ | (3,085 | ) |  | $ | 4,042 |  |  | $ | 6,081 |  |  | $ | (2,002 | ) |  | $ | 4,079 |  |
| Indefinite-lived and non-amortizable acquired intangible assets |  |  | 100 |  |  |  | 0 |  |  |  | 100 |  |  |  | 100 |  |  |  | 0 |  |  |  | 100 |  |
| Total acquired intangible assets |  | $ | 7,227 |  |  | $ | (3,085 | ) |  | $ | 4,142 |  |  | $ | 6,181 |  |  | $ | (2,002 | ) |  | $ | 4,179 |  |

[0001193125-14-383437:notes:119]
Amortization expense related to acquired intangible
 assets was $1.1 billion, $960 million and $605 million in 2014,
 2013 and 2012, respectively. As of September 27, 2014, the
 remaining weighted-average amortization period for acquired
 intangible assets is 3.8 years. The expected annual amortization
 expense related to acquired intangible assets as of
 September 27, 2014, is as follows (in millions):

[0001193125-14-383437:notes:120]
| 2015 |  | $ | 1,204 |  |
| 2016 |  |  | 1,083 |  |
| 2017 |  |  | 825 |  |
| 2018 |  |  | 592 |  |
| 2019 |  |  | 175 |  |
| Thereafter |  |  | 163 |  |
| Total |  | $ | 4,042 |  |


## us-gaap:ScheduleOfDerivativeInstrumentsInStatementOfFinancialPositionFairValueTextBlock

[0001193125-14-383437:notes:121]
The following tables show the Company’s
 derivative instruments at gross fair value as reflected in the
 Consolidated Balance Sheets as of September 27, 2014 and
 September 28, 2013 (in millions):

[0001193125-14-383437:notes:122]
|  |  | 2014 |  |
|  |  | Fair Value of Derivatives Designated as Hedge Instruments |  |  | Fair Value of Derivatives Not Designated as Hedge Instruments |  |  | Total Fair Value |  |
| Derivative assets (1): |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 1,332 |  |  | $ | 222 |  |  | $ | 1,554 |  |
| Interest rate contracts |  | $ | 81 |  |  | $ | 0 |  |  | $ | 81 |  |
| Derivative liabilities (2): |  |  |  |  |
| Foreign exchange contracts |  | $ | 41 |  |  | $ | 40 |  |  | $ | 81 |  |

[0001193125-14-383437:notes:123]
|  |  | 2013 |  |
|  |  | Fair Value of Derivatives Designated as Hedge Instruments |  |  | Fair Value of Derivatives Not Designated as Hedge Instruments |  |  | Total Fair Value |  |
| Derivative assets (1): |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 145 |  |  | $ | 25 |  |  | $ | 170 |  |
| Interest rate contracts |  | $ | 44 |  |  | $ | 0 |  |  | $ | 44 |  |
| Derivative liabilities (2): |  |  |  |  |
| Foreign exchange contracts |  | $ | 389 |  |  | $ | 46 |  |  | $ | 435 |  |

[0001193125-14-383437:notes:124]
|  | (1) | The fair value of derivative assets is measured using Level 2 fair value inputs and is recorded as other current assets in the Consolidated Balance Sheets. |  |

[0001193125-14-383437:notes:125]
|  | (2) | The fair value of derivative liabilities is measured using Level 2 fair value inputs and is recorded as accrued expenses in the Consolidated Balance Sheets. |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001193125-14-383437:notes:126]
|  |  | 2014 |  |  | 2013 |  |
| Components |  | $ | 471 |  |  | $ | 683 |  |
| Finished goods |  |  | 1,640 |  |  |  | 1,081 |  |
| Total inventories |  | $ | 2,111 |  |  | $ | 1,764 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-14-383437:notes:127]
Note 11 – Segment Information and Geographic Data

[0001193125-14-383437:notes:128]
The Company reports segment information based on
 the “management” approach. The management approach
 designates the internal reporting used by management for making
 decisions and assessing performance as the source of the
 Company’s reportable segments.

[0001193125-14-383437:notes:129]
The Company manages its business primarily on a
 geographic basis. The Company’s reportable operating segments
 consist of the Americas, Europe, Greater China, Japan, Rest of Asia
 Pacific and Retail operations. The Americas segment includes both
 North and South America. The Europe segment includes European
 countries, as well as India, the Middle East and Africa. The
 Greater China segment includes China, Hong Kong and Taiwan. The
 Rest of Asia Pacific segment includes Australia and Asian
 countries, other than those countries included in the
 Company’s other operating segments. The results of the
 Company’s geographic segments do not include results of the
 Retail segment. Each operating segment provides similar hardware
 and software products and similar services. The accounting policies
 of the various segments are the same as those described in Note 1,
 “Summary of Significant Accounting Policies.”

[0001193125-14-383437:notes:130]
The Company evaluates the performance of its
 operating segments based on net sales and operating income. Net
 sales for geographic segments are generally based on the location
 of customers, while Retail segment net sales are based on sales
 through the Company’s retail stores. Operating income for
 each segment includes net sales to third parties, related cost of
 sales and operating expenses directly attributable to the segment.
 Advertising expenses are generally included in the geographic
 segment in which the expenditures are incurred. Operating income
 for each segment excludes other income and expense and certain
 expenses managed outside the operating segments. Costs excluded
 from segment operating income include various corporate expenses
 such as R&D, corporate marketing expenses, share-based
 compensation expense, income taxes, various nonrecurring charges,
 other separately managed general and administrative costs and
 certain manufacturing period expenses. The Company does not include
 intercompany transfers between segments for management reporting
 purposes.

[0001193125-14-383437:notes:131]
Segment assets include receivables and inventories,
 and for the Retail segment also includes capital assets. Segment
 assets exclude corporate assets, such as cash and cash equivalents,
 short-term and long-term marketable securities, vendor non-trade
 receivables, other long-term investments, manufacturing and
 corporate facilities, product tooling and manufacturing process
 equipment, miscellaneous corporate infrastructure, goodwill and
 other acquired intangible assets. Except for the Retail segment,
 capital asset purchases for long-lived assets are not reported to
 management by segment and therefore are excluded from the
 geographic segment assets and instead included in corporate assets.
 Cash payments for capital asset purchases by the Retail segment
 were $484 million, $495 million and $858 million for 2014, 2013 and
 2012, respectively. The Company’s total depreciation and
 amortization was $7.9 billion, $6.8 billion and $3.3 billion in
 2014, 2013 and 2012, respectively, of which $441 million, $382
 million and $319 million was related to the Retail segment in the
 respective years. Depreciation and amortization on segment assets
 included in the geographic segments was not significant.

[0001193125-14-383437:notes:132]
As the Company continues to expand its business,
 management believes collaboration across its online, Retail and
 indirect channels is integral to better serve its customers and
 optimize its financial results. Beginning in the first quarter of
 2015, management will be assessing business performance and making
 decisions on a geographic basis, including the results of its
 retail stores in each respective geographic segment. Accordingly,
 the Company will be changing its reportable segments to align with
 the way the business is managed. The Company’s reportable
 operating segments will consist of the Americas, Europe, Greater
 China, Japan and Rest of Asia Pacific operations, and the Retail
 segment will no longer be classified as a separate reportable
 segment. The historical segment data for prior periods will be
 reclassified to reflect this change beginning in the Quarterly
 Report on Form 10-Q for the quarter ending December 27,
 2014.

[0001193125-14-383437:notes:133]
The following table shows information by operating
 segment for 2014, 2013 and 2012 (in millions):

[0001193125-14-383437:notes:134]
|  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 65,232 |  |  | $ | 62,739 |  |  | $ | 57,512 |  |
| Operating income |  | $ | 24,316 |  |  | $ | 22,817 |  |  | $ | 23,414 |  |
| Europe: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 40,929 |  |  | $ | 37,883 |  |  | $ | 36,323 |  |
| Operating income |  | $ | 14,771 |  |  | $ | 13,025 |  |  | $ | 14,869 |  |
| Greater China: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 29,846 |  |  | $ | 25,417 |  |  | $ | 22,533 |  |
| Operating income |  | $ | 11,016 |  |  | $ | 8,541 |  |  | $ | 9,843 |  |
| Japan: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 14,982 |  |  | $ | 13,462 |  |  | $ | 10,571 |  |
| Operating income |  | $ | 7,183 |  |  | $ | 6,819 |  |  | $ | 5,861 |  |
| Rest of Asia Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 10,344 |  |  | $ | 11,181 |  |  | $ | 10,741 |  |
| Operating income |  | $ | 3,636 |  |  | $ | 3,753 |  |  | $ | 4,253 |  |
| Retail: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 21,462 |  |  | $ | 20,228 |  |  | $ | 18,828 |  |
| Operating income |  | $ | 4,575 |  |  | $ | 4,025 |  |  | $ | 4,613 |  |

[0001193125-14-383437:notes:135]
A reconciliation of the Company’s segment
 operating income to the Consolidated Statements of Operations for
 2014, 2013 and 2012, is as follows (in millions):

[0001193125-14-383437:notes:136]
|  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Segment operating income |  | $ | 65,497 |  |  | $ | 58,980 |  |  | $ | 62,853 |  |
| Research and development expense (1) |  |  | (4,825 | ) |  |  | (3,558 | ) |  |  | (2,713 | ) |
| Share-based compensation expense |  |  | (2,863 | ) |  |  | (2,253 | ) |  |  | (1,740 | ) |
| Other corporate expenses, net |  |  | (5,306 | ) |  |  | (4,170 | ) |  |  | (3,159 | ) |
| Total operating income |  | $ | 52,503 |  |  | $ | 48,999 |  |  | $ | 55,241 |  |

[0001193125-14-383437:notes:137]
|  | (1) | Amount excludes research and development share-based compensation expense. |  |

[0001193125-14-383437:notes:138]
The U.S. and China were the only countries that
 accounted for more than 10% of the Company’s net sales in
 2014, 2013 and 2012. There was no single customer that accounted
 for more than 10% of net sales in 2014, 2013 or 2012. Net sales for
 2014, 2013 and 2012 and long-lived assets as of September 27,
 2014 and September 28, 2013 are as follows (in millions):

[0001193125-14-383437:notes:139]
|  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Net sales: |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. |  | $ | 68,909 |  |  | $ | 66,197 |  |  | $ | 60,949 |  |
| China (1) |  |  | 30,638 |  |  |  | 25,946 |  |  |  | 22,797 |  |
| Other countries |  |  | 83,248 |  |  |  | 78,767 |  |  |  | 72,762 |  |
| Total net sales |  | $ | 182,795 |  |  | $ | 170,910 |  |  | $ | 156,508 |  |
|  |  | 2014 |  |  | 2013 |  |  |  |  |
| Long-lived assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. |  | $ | 9,108 |  |  | $ | 7,399 |  |  |  |  |  |
| China (1) |  |  | 9,477 |  |  |  | 7,403 |  |  |  |  |  |
| Other countries |  |  | 2,917 |  |  |  | 2,786 |  |  |  |  |  |
| Total long-lived assets |  | $ | 21,502 |  |  | $ | 17,588 |  |  |  |  |  |

[0001193125-14-383437:notes:140]
|  | (1) | China includes Hong Kong. Long-lived assets located in China consist primarily of product tooling and manufacturing process equipment and assets related to retail stores and related infrastructure. |  |

[0001193125-14-383437:notes:141]
Information regarding net sales by product for
 2014, 2013 and 2012, is as follows (in millions):

[0001193125-14-383437:notes:142]
|  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Net Sales by Product: |  |  |  |  |  |  |  |  |  |  |  |  |
| iPhone (1) |  | $ | 101,991 |  |  | $ | 91,279 |  |  | $ | 78,692 |  |
| iPad (1) |  |  | 30,283 |  |  |  | 31,980 |  |  |  | 30,945 |  |
| Mac (1) |  |  | 24,079 |  |  |  | 21,483 |  |  |  | 23,221 |  |
| iPod (1) |  |  | 2,286 |  |  |  | 4,411 |  |  |  | 5,615 |  |
| iTunes, Software and Services (2) |  |  | 18,063 |  |  |  | 16,051 |  |  |  | 12,890 |  |
| Accessories (3) |  |  | 6,093 |  |  |  | 5,706 |  |  |  | 5,145 |  |
| Total net sales |  | $ | 182,795 |  |  | $ | 170,910 |  |  | $ | 156,508 |  |

[0001193125-14-383437:notes:143]
|  | (1) | Includes deferrals and amortization of related non-software services and software upgrade rights. |  |

[0001193125-14-383437:notes:144]
|  | (2) | Includes revenue from the iTunes Store, the App Store, the Mac App Store, the iBooks Store, AppleCare, licensing and other services. |  |

[0001193125-14-383437:notes:145]
|  | (3) | Includes sales of Apple-branded and third-party accessories for iPhone, iPad, Mac and iPod. |  |


## us-gaap:InterestAndOtherIncomeTableTextBlock

[0001193125-14-383437:notes:146]
Other Income and Expense

[0001193125-14-383437:notes:147]
The following table shows the detail of other
 income and expense for 2014, 2013 and 2012 (in millions):

[0001193125-14-383437:notes:148]
|  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Interest and dividend income |  | $ | 1,795 |  |  | $ | 1,616 |  |  | $ | 1,088 |  |
| Interest expense |  |  | (384 | ) |  |  | (136 | ) |  |  | 0 |  |
| Other expense, net |  |  | (431 | ) |  |  | (324 | ) |  |  | (566 | ) |
| Total other income/(expense), net |  | $ | 980 |  |  | $ | 1,156 |  |  | $ | 522 |  |


## us-gaap:OtherNoncurrentLiabilitiesTableTextBlock

[0001193125-14-383437:notes:149]
Non-Current Liabilities

[0001193125-14-383437:notes:150]
|  |  | 2014 |  |  | 2013 |  |
| Deferred tax liabilities |  | $ | 20,259 |  |  | $ | 16,489 |  |
| Other non-current liabilities |  |  | 4,567 |  |  |  | 3,719 |  |
| Total other non-current liabilities |  | $ | 24,826 |  |  | $ | 20,208 |  |


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0001193125-14-383437:notes:151]
The following table shows a summary of the
 share-based compensation expense included in the Consolidated
 Statements of Operations for 2014, 2013 and 2012 (in millions):

[0001193125-14-383437:notes:152]
|  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Cost of sales |  | $ | 450 |  |  | $ | 350 |  |  | $ | 265 |  |
| Research and development |  |  | 1,216 |  |  |  | 917 |  |  |  | 668 |  |
| Selling, general and administrative |  |  | 1,197 |  |  |  | 986 |  |  |  | 807 |  |
| Total share-based compensation expense |  | $ | 2,863 |  |  | $ | 2,253 |  |  | $ | 1,740 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001193125-14-383437:notes:153]
Net sales for 2014, 2013 and 2012 are as follows
 (in millions):

[0001193125-14-383437:notes:154]
|  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Net sales: |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. |  | $ | 68,909 |  |  | $ | 66,197 |  |  | $ | 60,949 |  |
| China (1) |  |  | 30,638 |  |  |  | 25,946 |  |  |  | 22,797 |  |
| Other countries |  |  | 83,248 |  |  |  | 78,767 |  |  |  | 72,762 |  |
| Total net sales |  | $ | 182,795 |  |  | $ | 170,910 |  |  | $ | 156,508 |  |

[0001193125-14-383437:notes:155]
|  | (1) | China includes Hong Kong. |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001193125-14-383437:notes:156]
Note 2 – Financial Instruments

[0001193125-14-383437:notes:157]
Cash, Cash Equivalents and Marketable Securities

[0001193125-14-383437:notes:158]
The Company may sell certain of its marketable
 securities prior to their stated maturities for strategic reasons
 including, but not limited to, anticipation of credit deterioration
 and duration management. The net realized gains or losses
 recognized by the Company, related to such sales, were not
 significant during 2014, 2013 and 2012. The maturities of the
 Company’s long-term marketable securities generally range
 from one to five years.

[0001193125-14-383437:notes:159]
As of September 27, 2014 and
 September 28, 2013, gross unrealized losses related to
 individual securities that had been in a continuous loss position
 for 12 months or longer were not significant.

[0001193125-14-383437:notes:160]
As of September 27, 2014, the Company
 considers the declines in market value of its marketable securities
 investment portfolio to be temporary in nature and does not
 consider any of its investments other-than-temporarily impaired.
 The Company typically invests in highly-rated securities, and its
 investment policy limits the amount of credit exposure to any one
 issuer. The policy generally requires investments to be investment
 grade, with the primary objective of minimizing the potential risk
 of principal loss. Fair values were determined for each individual
 security in the investment portfolio. When evaluating an investment
 for other-than-temporary impairment, the Company reviews factors
 such as the length of time and extent to which fair value has been
 below its cost basis, the financial condition of the issuer and any
 changes thereto, changes in market interest rates, and the
 Company’s intent to sell, or whether it is more likely than
 not it will be required to sell, the investment before recovery of
 the investment’s cost basis. During 2014, 2013 and 2012 the
 Company did not recognize any significant impairment charges.

[0001193125-14-383437:notes:161]
The Company uses derivatives to partially offset
 its business exposure to foreign currency and interest rate risk.
 The Company may enter into forward contracts, option contracts,
 swaps, or other derivative instruments to offset some of the risk
 on expected future cash flows, on net investments in certain
 foreign subsidiaries and on certain existing assets and
 liabilities. However, the Company may choose not to hedge certain
 exposures for a variety of reasons including, but not limited to,
 accounting considerations and the prohibitive economic cost of
 hedging particular exposures. There can be no assurance the hedges
 will offset more than a portion of the financial impact resulting
 from movements in foreign currency exchange or interest rates.

[0001193125-14-383437:notes:162]
To help protect gross margins from fluctuations in
 foreign currency exchange rates, certain of the Company’s
 subsidiaries whose functional currency is the U.S. dollar hedge a
 portion of forecasted foreign currency revenue. The Company’s
 subsidiaries whose functional currency is not the U.S. dollar and
 who sell in local currencies may hedge a portion of forecasted
 inventory purchases not denominated in the subsidiaries’
 functional currencies. The Company typically hedges portions of its
 forecasted foreign currency exposure associated with revenue and
 inventory purchases, typically for up to 12 months.

[0001193125-14-383437:notes:163]
To help protect the net investment in a foreign
 operation from adverse changes in foreign currency exchange rates,
 the Company may enter into foreign currency forward and option
 contracts to offset the changes in the carrying amounts of these
 investments due to fluctuations in foreign currency exchange
 rates.

[0001193125-14-383437:notes:164]
The Company may also enter into foreign currency
 forward contracts and option contracts to partially offset the
 foreign currency exchange gains and losses generated by the
 re-measurement of certain assets and liabilities denominated in
 non-functional currencies.

[0001193125-14-383437:notes:165]
The Company may enter into interest rate swaps,
 options, or other instruments to manage interest rate risk. These
 instruments may offset a portion of changes in income or expense,
 or changes in fair value of the Company’s long-term debt or
 investments.

[0001193125-14-383437:notes:166]
The Company records all derivatives in the
 Consolidated Balance Sheets at fair value. The Company’s
 accounting treatment for these instruments is based on the hedge
 designation. The effective portions of cash flow hedges are
 recorded in AOCI until the hedged item is recognized in earnings.
 Gains and losses related to changes in fair value hedges are
 recognized in earnings along with a corresponding loss or gain
 related to the change in value of the underlying hedged item. The
 effective portions of net investment hedges are recorded in other
 comprehensive income (“OCI”) as a part of the
 cumulative translation adjustment. The ineffective portions of cash
 flow hedges and net investment hedges are recorded in other income
 and expense. Derivatives that are not designated as hedging
 instruments are adjusted to fair value through earnings in the
 financial statement line item to which the derivative relates.

[0001193125-14-383437:notes:167]
Deferred gains and losses associated with cash flow
 hedges of foreign currency revenue are recognized as a component of
 net sales in the same period as the related revenue is recognized,
 and deferred gains and losses related to cash flow hedges of
 inventory purchases are recognized as a component of cost of sales
 in the same period as the related costs are recognized. Deferred
 gains and losses associated with cash flow hedges of interest
 income or expense are recognized as a component of other
 income/(expense), net in the same period as the related income or
 expense is recognized. The Company’s foreign currency and
 interest rate transactions hedged with cash flow hedges as of
 September 27, 2014 are expected to occur within 12 months and
 four years, respectively.

[0001193125-14-383437:notes:168]
Derivative instruments designated as cash flow
 hedges must be de-designated as hedges when it is probable the
 forecasted hedged transaction will not occur in the initially
 identified time period or within a subsequent two-month time
 period. Deferred gains and losses in AOCI associated with such
 derivative instruments are reclassified immediately into other
 income and expense. Any subsequent changes in fair value of such
 derivative instruments are reflected in other income and expense
 unless they are re-designated as hedges of other transactions. The
 Company did not recognize any significant net gains or losses
 related to the loss of hedge designation on discontinued cash flow
 hedges during 2014, 2013 and 2012.

[0001193125-14-383437:notes:169]
The gain/loss recognized in other income and
 expense for foreign currency forward and option contracts not
 designated as hedging instruments was not significant during 2014,
 2013 and 2012. These amounts represent the net gain or loss on the
 derivative contracts and do not include changes in the related
 exposures, which generally offset a portion of the gain or loss on
 the derivative contracts.

[0001193125-14-383437:notes:170]
The following table shows the notional amounts of
 the Company’s outstanding derivative instruments and credit
 risk amounts associated with outstanding or unsettled derivative
 instruments as of September 27, 2014 and September 28,
 2013 (in millions):

[0001193125-14-383437:notes:171]
|  |  | 2014 |  |  | 2013 |  |
|  |  | Notional Amount |  |  | Credit Risk Amounts |  |  | Notional Amount |  |  | Credit Risk Amounts |  |
| Instruments designated as accounting hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 42,945 |  |  | $ | 1,333 |  |  | $ | 35,013 |  |  | $ | 159 |  |
| Interest rate contracts |  | $ | 12,000 |  |  | $ | 89 |  |  | $ | 3,000 |  |  | $ | 44 |  |
| Instruments not designated as accounting hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 38,510 |  |  | $ | 222 |  |  | $ | 16,131 |  |  | $ | 25 |  |

[0001193125-14-383437:notes:172]
The notional amounts for outstanding derivative
 instruments provide one measure of the transaction volume
 outstanding and do not represent the amount of the Company’s
 exposure to credit or market loss. The credit risk amounts
 represent the Company’s gross exposure to potential
 accounting loss on derivative instruments that are outstanding or
 unsettled if all counterparties failed to perform according to the
 terms of the contract, based on then-current currency or interest
 rates at each respective date. The Company’s gross exposure
 on these transactions may be further mitigated by collateral
 received from certain counterparties. The Company’s exposure
 to credit loss and market risk will vary over time as currency and
 interest rates change. Although the table above reflects the
 notional and credit risk amounts of the Company’s derivative
 instruments, it does not reflect the gains or losses associated
 with the exposures and transactions that the instruments are
 intended to hedge. The amounts ultimately realized upon settlement
 of these financial instruments, together with the gains and losses
 on the underlying exposures, will depend on actual market
 conditions during the remaining life of the instruments.

[0001193125-14-383437:notes:173]
The Company generally enters into master netting
 arrangements, which are designed to reduce credit risk by
 permitting net settlement of transactions with the same
 counterparty. To further limit credit risk, the Company generally
 enters into collateral security arrangements that provide for
 collateral to be received or posted when the net fair value of
 certain financial instruments fluctuates from contractually
 established thresholds. The Company presents its derivative assets
 and derivative liabilities at their gross fair values in its
 Consolidated Balance Sheets. As of September 27, 2014, the
 Company received $2.1 billion of cash collateral related to the
 derivative instruments under its collateral security arrangements,
 which were recorded as accrued expenses in the Consolidated Balance
 Sheet. As of September 28, 2013, the Company posted cash
 collateral related to the derivative instruments under its
 collateral security arrangements of $164 million, which were
 recorded as other current assets in the Consolidated Balance
 Sheet. The Company did not have any derivative instruments
 with credit-risk related contingent features that would require it
 to post additional collateral as of September 27, 2014 or
 September 28, 2013.

[0001193125-14-383437:notes:174]
Under master netting arrangements with the
 respective counterparties to the Company’s derivative
 contracts, the Company is allowed to net settle transactions
 with a single net amount payable by one party to the other. As of
 September 27, 2014 and September 28, 2013, the potential
 effects of these rights of set-off associated with the
 Company’s derivative contracts, including the effects of
 collateral, would be a reduction to both derivative assets and
 derivative liabilities of $1.6 billion and $333 million,
 respectively, resulting in net derivative liabilities of
 $549 million and $57 million, respectively.

[0001193125-14-383437:notes:175]
The following tables show the pre-tax effect of the
 Company’s derivative instruments designated as cash flow, net
 investment and fair value hedges on OCI and the Consolidated
 Statements of Operations for 2014, 2013 and 2012 (in millions):

[0001193125-14-383437:notes:176]
|  |  | Gains/(Losses) Recognized in OCI-Effective Portion |  |  | Gains/(Losses) Reclassified from AOCI into Net Income-Effective Portion |  |
|  |  | 2014 |  |  | 2013 |  |  | 2012 |  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Cash flow hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 1,750 |  |  | $ | 891 |  |  | $ | (175 | ) |  | $ | (154 | ) |  | $ | 676 |  |  | $ | 607 |  |
| Interest rate contracts |  |  | (15 | ) |  |  | 12 |  |  |  | 0 |  |  |  | (16 | ) |  |  | (6 | ) |  |  | 0 |  |
| Total |  | $ | 1,735 |  |  | $ | 903 |  |  | $ | (175 | ) |  | $ | (170 | ) |  | $ | 670 |  |  | $ | 607 |  |
| Net investment hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 53 |  |  | $ | 143 |  |  | $ | (5 | ) |  | $ | 0 |  |  | $ | 0 |  |  | $ | 0 |  |
|  |  | Gains/(Losses) On Derivative Instruments |  |  | Gains/(Losses) Related to Hedged Items |  |
|  |  | 2014 |  |  | 2013 |  |  | 2012 |  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Fair value hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate contracts |  | $ | 39 |  |  | $ | 0 |  |  | $ | 0 |  |  | $ | (39 | ) |  | $ | 0 |  |  | $ | 0 |  |

[0001193125-14-383437:notes:177]
The Company recognized a charge of $120 million,
 $301 million and $658 million in other income and expense during
 2014, 2013 and 2012, respectively, for the ineffective portions of
 and amounts excluded from the effectiveness testing of cash flow
 hedges. The ineffective portions of and amounts excluded from the
 effectiveness testing of net investment and fair value hedges
 recognized in other income and expense were not significant during
 2014, 2013 and 2012.

[0001193125-14-383437:notes:178]
Accounts Receivable

[0001193125-14-383437:notes:179]
Trade Receivables

[0001193125-14-383437:notes:180]
The Company has considerable trade receivables
 outstanding with its third-party cellular network carriers,
 wholesalers, retailers, value-added resellers, small and mid-sized
 businesses, and education, enterprise and government customers. The
 Company generally does not require collateral from its customers;
 however, the Company will require collateral in certain instances
 to limit credit risk. In addition, when possible, the Company
 attempts to limit credit risk on trade receivables with credit
 insurance for certain customers or by requiring third-party
 financing, loans or leases to support credit exposure. These
 credit-financing arrangements are directly between the third-party
 financing company and the end customer. As such, the Company
 generally does not assume any recourse or credit risk sharing
 related to any of these arrangements.

[0001193125-14-383437:notes:181]
As of September 27, 2014, the Company had two
 customers that represented 10% or more of total trade receivables,
 one of which accounted for 16% and the other 13%. As of
 September 28, 2013, the Company had two customers that
 represented 10% or more of total trade receivables, one of which
 accounted for 13% and the other 10%. The Company’s cellular
 network carriers accounted for 72% and 68% of trade receivables as
 of September 27, 2014 and September 28, 2013,
 respectively. The additions and write-offs to the Company’s
 allowance for doubtful accounts during 2014, 2013 and 2012 were not
 significant.

[0001193125-14-383437:notes:182]
Vendor Non-Trade Receivables

[0001193125-14-383437:notes:183]
The Company has non-trade receivables from certain
 of its manufacturing vendors resulting from the sale of components
 to these manufacturing vendors who manufacture sub-assemblies or
 assemble final products for the Company. The Company purchases
 these components directly from suppliers. Three of the
 Company’s vendors accounted for 51%, 16% and 14% of total
 vendor non-trade receivables as of September 27, 2014 and
 three of the Company’s vendors accounted for 47%, 21% and 15%
 of total vendor non-trade receivables as of September 28,
 2013. The Company does not reflect the sale of these components in
 net sales and does not recognize any profits on these sales until
 the related products are sold by the Company, at which time any
 profit is recognized as a reduction of cost of sales.


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001193125-14-383437:notes:184]
Accrued Expenses

[0001193125-14-383437:notes:185]
|  |  | 2014 |  |  | 2013 |  |
| Accrued warranty and related costs |  | $ | 4,159 |  |  | $ | 2,967 |  |
| Accrued marketing and selling expenses |  |  | 2,321 |  |  |  | 1,291 |  |
| Accrued taxes |  |  | 1,209 |  |  |  | 1,200 |  |
| Accrued compensation and employee benefits |  |  | 1,209 |  |  |  | 959 |  |
| Deferred margin on component sales |  |  | 1,057 |  |  |  | 1,262 |  |
| Other current liabilities |  |  | 8,498 |  |  |  | 6,177 |  |
| Total accrued expenses |  | $ | 18,453 |  |  | $ | 13,856 |  |


## us-gaap:ScheduleOfComponentsOfIncomeTaxExpenseBenefitTableTextBlock

[0001193125-14-383437:notes:186]
The provision for income taxes for 2014, 2013 and
 2012, consisted of the following (in millions):

[0001193125-14-383437:notes:187]
|  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Federal: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  | $ | 8,624 |  |  | $ | 9,334 |  |  | $ | 7,240 |  |
| Deferred |  |  | 3,183 |  |  |  | 1,878 |  |  |  | 5,018 |  |
|  |  |  | 11,807 |  |  |  | 11,212 |  |  |  | 12,258 |  |
| State: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  |  | 855 |  |  |  | 1,084 |  |  |  | 1,182 |  |
| Deferred |  |  | (178 | ) |  |  | (311 | ) |  |  | (123 | ) |
|  |  |  | 677 |  |  |  | 773 |  |  |  | 1,059 |  |
| Foreign: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  |  | 2,147 |  |  |  | 1,559 |  |  |  | 1,203 |  |
| Deferred |  |  | (658 | ) |  |  | (426 | ) |  |  | (490 | ) |
|  |  |  | 1,489 |  |  |  | 1,133 |  |  |  | 713 |  |
| Provision for income taxes |  | $ | 13,973 |  |  | $ | 13,118 |  |  | $ | 14,030 |  |


## us-gaap:ScheduleOfNonvestedRestrictedStockUnitsActivityTableTextBlock

[0001193125-14-383437:notes:188]
A summary of the Company’s RSU activity and
 related information for 2014, 2013 and 2012, is as follows:

[0001193125-14-383437:notes:189]
|  |  | Number of RSUs (in thousands) |  |  | Weighted-Average Grant Date Fair Value Per Share |  |  | Aggregate Intrinsic Value (in millions) |  |
| Balance at September 24, 2011 |  |  | 101,122 |  |  | $ | 33.07 |  |  |  |  |  |
| RSUs granted |  |  | 54,597 |  |  | $ | 61.62 |  |  |  |  |  |
| RSUs vested |  |  | (44,137 | ) |  | $ | 29.32 |  |  |  |  |  |
| RSUs cancelled |  |  | (6,545 | ) |  | $ | 36.57 |  |  |  |  |  |
| Balance at September 29, 2012 |  |  | 105,037 |  |  | $ | 49.27 |  |  |  |  |  |
| RSUs granted |  |  | 39,415 |  |  | $ | 78.23 |  |  |  |  |  |
| RSUs vested |  |  | (42,291 | ) |  | $ | 45.96 |  |  |  |  |  |
| RSUs cancelled |  |  | (8,877 | ) |  | $ | 57.31 |  |  |  |  |  |
| Balance at September 28, 2013 |  |  | 93,284 |  |  | $ | 62.24 |  |  |  |  |  |
| RSUs granted |  |  | 59,269 |  |  | $ | 74.54 |  |  |  |  |  |
| RSUs vested |  |  | (43,111 | ) |  | $ | 57.29 |  |  |  |  |  |
| RSUs cancelled |  |  | (5,620 | ) |  | $ | 68.47 |  |  |  |  |  |
| Balance at September 27, 2014 |  |  | 103,822 |  |  | $ | 70.98 |  |  | $ | 10,460 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001193125-14-383437:notes:190]
Note 12 – Selected Quarterly Financial Information
 (Unaudited)

[0001193125-14-383437:notes:191]
The following tables show a summary of the
 Company’s quarterly financial information for each of the
 four quarters of 2014 and 2013 (in millions, except per share
 amounts):

[0001193125-14-383437:notes:192]
|  |  | Fourth Quarter |  |  | Third Quarter |  |  | Second Quarter |  |  | First Quarter |  |
| 2014: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 42,123 |  |  | $ | 37,432 |  |  | $ | 45,646 |  |  | $ | 57,594 |  |
| Gross margin |  | $ | 16,009 |  |  | $ | 14,735 |  |  | $ | 17,947 |  |  | $ | 21,846 |  |
| Net income |  | $ | 8,467 |  |  | $ | 7,748 |  |  | $ | 10,223 |  |  | $ | 13,072 |  |
| Earnings per share (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.43 |  |  | $ | 1.29 |  |  | $ | 1.67 |  |  | $ | 2.08 |  |
| Diluted |  | $ | 1.42 |  |  | $ | 1.28 |  |  | $ | 1.66 |  |  | $ | 2.07 |  |
| 2013: |  |  |  |  |
| Net sales |  | $ | 37,472 |  |  | $ | 35,323 |  |  | $ | 43,603 |  |  | $ | 54,512 |  |
| Gross margin |  | $ | 13,871 |  |  | $ | 13,024 |  |  | $ | 16,349 |  |  | $ | 21,060 |  |
| Net income |  | $ | 7,512 |  |  | $ | 6,900 |  |  | $ | 9,547 |  |  | $ | 13,078 |  |
| Earnings per share (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.19 |  |  | $ | 1.07 |  |  | $ | 1.45 |  |  | $ | 1.99 |  |
| Diluted |  | $ | 1.18 |  |  | $ | 1.07 |  |  | $ | 1.44 |  |  | $ | 1.97 |  |

[0001193125-14-383437:notes:193]
|  | (1) | Basic and diluted earnings per share are computed independently for each of the quarters presented. Therefore, the sum of quarterly basic and diluted per share information may not equal annual basic and diluted earnings per share. |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-14-383437:notes:194]
The following table shows the changes in AOCI by
 component for 2014 (in millions):

[0001193125-14-383437:notes:195]
|  |  | Cumulative Foreign Currency Translation |  |  | Unrecognized Gains/Losses on Derivative Instruments |  |  | Unrealized Gains /Losses on Marketable Securities |  |  | Total |  |
| Balance at September 28, 2013 |  | $ | (105 | ) |  | $ | (175 | ) |  | $ | (191 | ) |  | $ | (471 | ) |
| Other comprehensive income/(loss) before reclassifications |  |  | (187 | ) |  |  | 1,687 |  |  |  | 438 |  |  |  | 1,938 |  |
| Amounts reclassified from AOCI |  |  | 0 |  |  |  | 185 |  |  |  | (205 | ) |  |  | (20 | ) |
| Tax effect |  |  | 50 |  |  |  | (333 | ) |  |  | (82 | ) |  |  | (365 | ) |
| Other comprehensive income/(loss) |  |  | (137 | ) |  |  | 1,539 |  |  |  | 151 |  |  |  | 1,553 |  |
| Balance at September 27, 2014 |  | $ | (242 | ) |  | $ | 1,364 |  |  | $ | (40 | ) |  | $ | 1,082 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-14-383437:notes:196]
Note 7 – Shareholders’ Equity

[0001193125-14-383437:notes:197]
Preferred and Common Stock

[0001193125-14-383437:notes:198]
During the second quarter of 2014, the
 Company’s shareholders approved amendments (the
 “Amendments”) to the Company’s Restated Articles
 of Incorporation. The Amendments included the elimination of the
 Board of Directors’ authority to issue preferred stock and
 established a par value for the Company’s common stock of
 $0.00001 per share.

[0001193125-14-383437:notes:199]
Dividends

[0001193125-14-383437:notes:200]
The Company declared and paid cash dividends per
 common share during the periods presented as follows:

[0001193125-14-383437:notes:201]
|  |  | Dividends Per Share |  |  | Amount(in millions) |  |
| 2014: |  |  |  |  |  |  |  |  |
| Fourth quarter |  | $ | 0.47 |  |  | $ | 2,807 |  |
| Third quarter |  |  | 0.47 |  |  |  | 2,830 |  |
| Second quarter |  |  | 0.44 |  |  |  | 2,655 |  |
| First quarter |  |  | 0.44 |  |  |  | 2,739 |  |
| Total |  | $ | 1.82 |  |  | $ | 11,031 |  |
| 2013: |  |  |  |  |  |  |  |  |
| Fourth quarter |  | $ | 0.44 |  |  | $ | 2,763 |  |
| Third quarter |  |  | 0.44 |  |  |  | 2,789 |  |
| Second quarter |  |  | 0.38 |  |  |  | 2,490 |  |
| First quarter |  |  | 0.38 |  |  |  | 2,486 |  |
| Total |  | $ | 1.64 |  |  | $ | 10,528 |  |

[0001193125-14-383437:notes:202]
The Company paid cash dividends of $0.38 per share,
 totaling $2.5 billion, during the fourth quarter of 2012. Future
 dividends are subject to declaration by the Board of Directors.

[0001193125-14-383437:notes:203]
Share Repurchase Program

[0001193125-14-383437:notes:204]
In 2012, the Company’s Board of Directors
 authorized a program to repurchase up to $10 billion of the
 Company’s common stock beginning in 2013. The Company’s
 Board of Directors increased the share repurchase authorization to
 $60 billion in April 2013 and to $90 billion in April 2014. As of
 September 27, 2014, $67.9 billion of the $90 billion had been
 utilized. The Company’s share repurchase program does not
 obligate it to acquire any specific number of shares. Under the
 program, shares may be repurchased in privately negotiated and/or
 open market transactions, including under plans complying with Rule
 10b5-1 under the Securities Exchange Act of 1934, as amended (the
 “Exchange Act”).

[0001193125-14-383437:notes:205]
The Company has entered into four accelerated share
 repurchase arrangements (“ASRs”) with financial
 institutions beginning in August 2012. In exchange for up-front
 payments, the financial institutions deliver shares of the
 Company’s common stock during the purchase periods of each
 ASR. The total number of shares ultimately delivered, and therefore
 the average repurchase price paid per share, will be determined at
 the end of the applicable purchase period of each ASR based on the
 volume weighted-average price of the Company’s common stock
 during that period. The shares received are retired in the periods
 they are delivered, and the up-front payments are accounted for as
 a reduction to shareholders’ equity in the Company’s
 Consolidated Balance Sheet in the periods the payments are made.
 The Company reflects the ASRs as a repurchase of common stock in
 the period delivered for purposes of calculating earnings per share
 and as forward contracts indexed to its own common stock. The ASRs
 met all of the applicable criteria for equity classification, and
 therefore, were not accounted for as derivative instruments.

[0001193125-14-383437:notes:206]
The following table presents the Company’s
 ASRs:

[0001193125-14-383437:notes:207]
|  |  | Purchase Period End Date |  |  | Number of Shares(in thousands) |  |  | Average Repurchase Price Per Share |  |  | ASR Amount(in millions) |  |
| August 2014 ASR |  |  |  | (1) |  |  | 59,924 | (1) |  |  |  | (1) |  | $ | 9,000 |  |
| January 2014 ASR |  |  |  | (1) |  |  | 134,247 | (1) |  |  |  | (1) |  | $ | 12,000 |  |
| April 2013 ASR |  |  | March 2014 |  |  |  | 172,548 | (2) |  | $ | 69.55 |  |  | $ | 12,000 |  |
| August 2012 ASR |  |  | April 2013 |  |  |  | 28,544 |  |  | $ | 68.31 |  |  | $ | 1,950 |  |

[0001193125-14-383437:notes:208]
|  | (1) | “Number of Shares” represents those shares delivered in advance of settlement and does not represent the final number of shares to be delivered under the ASRs. The total number of shares ultimately delivered, and therefore the average repurchase price paid per share, will be determined at the end of the applicable purchase period based on the volume weighted-average price of the Company’s common stock during that period. The August 2014 ASR and January 2014 ASR purchase periods will end in or before February 2015 and December 2014, respectively. |  |

[0001193125-14-383437:notes:209]
|  | (2) | Includes 8.0 million shares that were delivered and retired at the end of the purchase period, which concluded in the second quarter of 2014. |  |

[0001193125-14-383437:notes:210]
Additionally, the Company repurchased shares of its
 common stock in the open market, which were retired upon
 repurchase, during the periods presented as follows:

[0001193125-14-383437:notes:211]
|  |  | Number of Shares(in thousands) |  |  | Average Repurchase Price Per Share |  |  | Amount(in millions) |  |
| 2014: |  |  |  |  |  |  |  |  |  |  |  |  |
| Fourth quarter |  |  | 81,255 |  |  | $ | 98.46 |  |  | $ | 8,000 |  |
| Third quarter |  |  | 58,661 |  |  | $ | 85.23 |  |  |  | 5,000 |  |
| Second quarter |  |  | 79,749 |  |  | $ | 75.24 |  |  |  | 6,000 |  |
| First quarter |  |  | 66,847 |  |  | $ | 74.79 |  |  |  | 5,000 |  |
| Total |  |  | 286,512 |  |  |  |  |  |  | $ | 24,000 |  |
| 2013: |  |  |  |  |  |  |  |  |  |  |  |  |
| Fourth quarter |  |  | 73,064 |  |  | $ | 68.43 |  |  | $ | 5,000 |  |
| Third quarter |  |  | 62,676 |  |  | $ | 63.82 |  |  |  | 4,000 |  |
| Second quarter |  |  | 0 |  |  | $ | 0 |  |  |  | 0 |  |
| First quarter |  |  | 0 |  |  | $ | 0 |  |  |  | 0 |  |
| Total |  |  | 135,740 |  |  |  |  |  |  | $ | 9,000 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-14-383437:notes:212]
Note 5 – Income Taxes

[0001193125-14-383437:notes:213]
The foreign provision for income taxes is based on
 foreign pre-tax earnings of $33.6 billion, $30.5 billion and
 $36.8 billion in 2014, 2013 and 2012, respectively. The
 Company’s consolidated financial statements provide for any
 related tax liability on undistributed earnings that the Company
 does not intend to be indefinitely reinvested outside the U.S.
 Substantially all of the Company’s undistributed
 international earnings intended to be indefinitely reinvested in
 operations outside the U.S. were generated by subsidiaries
 organized in Ireland, which has a statutory tax rate of 12.5%. As
 of September 27, 2014, U.S. income taxes have not been
 provided on a cumulative total of $69.7 billion of such earnings.
 The amount of unrecognized deferred tax liability related to these
 temporary differences is estimated to be approximately $23.3
 billion.

[0001193125-14-383437:notes:214]
As of September 27, 2014 and
 September 28, 2013, $137.1 billion and $111.3 billion,
 respectively, of the Company’s cash, cash equivalents and
 marketable securities were held by foreign subsidiaries and are
 generally based in U.S. dollar-denominated holdings. Amounts
 held by foreign subsidiaries are generally subject to U.S. income
 taxation on repatriation to the U.S.

[0001193125-14-383437:notes:215]
The Company’s income taxes payable have been
 reduced by the tax benefits from employee stock plan awards. For
 stock options, the Company receives an income tax benefit
 calculated as the tax effect of the difference between the fair
 market value of the stock issued at the time of the exercise and
 the exercise price. For RSUs, the Company receives an income
 tax benefit upon the award’s vesting equal to the tax effect
 of the underlying stock’s fair market value. The Company had
 net excess tax benefits from equity awards of $706 million, $643
 million and $1.4 billion in 2014, 2013 and 2012, respectively,
 which were reflected as increases to common stock.

[0001193125-14-383437:notes:216]
As of September 27, 2014 and
 September 28, 2013, the significant components of the
 Company’s deferred tax assets and liabilities were (in
 millions):

[0001193125-14-383437:notes:217]
|  |  | 2014 |  |  | 2013 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |
| Accrued liabilities and other reserves |  | $ | 2,761 |  |  | $ | 1,892 |  |
| Deferred revenue |  |  | 1,787 |  |  |  | 1,475 |  |
| Basis of capital assets and investments |  |  | 898 |  |  |  | 1,020 |  |
| Share-based compensation |  |  | 454 |  |  |  | 458 |  |
| Other |  |  | 644 |  |  |  | 1,029 |  |
| Total deferred tax assets |  |  | 6,544 |  |  |  | 5,874 |  |
| Less valuation allowance |  |  | 0 |  |  |  | 0 |  |
| Deferred tax assets, net of valuation allowance |  |  | 6,544 |  |  |  | 5,874 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |
| Unremitted earnings of foreign subsidiaries |  |  | 21,544 |  |  |  | 18,044 |  |
| Other |  |  | 120 |  |  |  | 112 |  |
| Total deferred tax liabilities |  |  | 21,664 |  |  |  | 18,156 |  |
| Net deferred tax liabilities |  | $ | (15,120 | ) |  | $ | (12,282 | ) |

[0001193125-14-383437:notes:218]
Deferred tax assets and liabilities reflect the
 effects of tax losses, credits and the future income tax effects of
 temporary differences between the consolidated financial statement
 carrying amounts of existing assets and liabilities and their
 respective tax bases and are measured using enacted tax rates that
 apply to taxable income in the years in which those temporary
 differences are expected to be recovered or settled.

[0001193125-14-383437:notes:219]
Uncertain Tax Positions

[0001193125-14-383437:notes:220]
Tax positions are evaluated in a two-step process.
 The Company first determines whether it is more likely than not
 that a tax position will be sustained upon examination. If a tax
 position meets the more-likely-than-not recognition threshold it is
 then measured to determine the amount of benefit to recognize in
 the financial statements. The tax position is measured as the
 largest amount of benefit that is greater than 50% likely of being
 realized upon ultimate settlement. The Company classifies gross
 interest and penalties and unrecognized tax benefits that are not
 expected to result in payment or receipt of cash within one year as
 non-current liabilities in the Consolidated Balance Sheets.

[0001193125-14-383437:notes:221]
As of September 27, 2014, the total amount of
 gross unrecognized tax benefits was $4.0 billion, of which
 $1.4 billion, if recognized, would affect the Company’s
 effective tax rate. As of September 28, 2013, the total amount
 of gross unrecognized tax benefits was $2.7 billion, of which $1.4
 billion, if recognized, would affect the Company’s effective
 tax rate.

[0001193125-14-383437:notes:222]
The aggregate changes in the balance of gross
 unrecognized tax benefits, which excludes interest and penalties,
 for 2014, 2013 and 2012, is as follows (in millions):

[0001193125-14-383437:notes:223]
|  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Beginning Balance |  | $ | 2,714 |  |  | $ | 2,062 |  |  | $ | 1,375 |  |
| Increases related to tax positions taken during a prior year |  |  | 1,295 |  |  |  | 745 |  |  |  | 340 |  |
| Decreases related to tax positions taken during a prior year |  |  | (280 | ) |  |  | (118 | ) |  |  | (107 | ) |
| Increases related to tax positions taken during the current year |  |  | 882 |  |  |  | 626 |  |  |  | 467 |  |
| Decreases related to settlements with taxing authorities |  |  | (574 | ) |  |  | (592 | ) |  |  | (3 | ) |
| Decreases related to expiration of statute of limitations |  |  | (4 | ) |  |  | (9 | ) |  |  | (10 | ) |
| Ending Balance |  | $ | 4,033 |  |  | $ | 2,714 |  |  | $ | 2,062 |  |

[0001193125-14-383437:notes:224]
The Company includes interest and penalties related
 to unrecognized tax benefits within the provision for income taxes.
 As of September 27, 2014 and September 28, 2013, the
 total amount of gross interest and penalties accrued was $630
 million and $590 million, respectively, which is classified as
 non-current liabilities in the Consolidated Balance Sheets. In
 connection with tax matters, the Company recognized interest and
 penalty expense in 2014, 2013 and 2012 of $40 million, $189 million
 and $140 million, respectively.

[0001193125-14-383437:notes:225]
The Company is subject to taxation and files income
 tax returns in the U.S. federal jurisdiction and in many state and
 foreign jurisdictions. During the fiscal year ended
 September 27, 2014, the U.S. Internal Revenue Service
 (“IRS”) concluded its review of the years 2004 through
 2009, which resulted in the Company reducing its gross unrecognized
 tax benefits by $570 million and recognizing a tax benefit of $166
 million. The IRS is currently examining the years 2010 through
 2012. In addition, the Company is also subject to audits by state,
 local and foreign tax authorities. In major states and major
 foreign jurisdictions, the years subsequent to 1996 and 2002,
 respectively, generally remain open and could be subject to
 examination by the taxing authorities.

[0001193125-14-383437:notes:226]
Management believes that an adequate provision has
 been made for any adjustments that may result from tax
 examinations. However, the outcome of tax audits cannot be
 predicted with certainty. If any issues addressed in the
 Company’s tax audits are resolved in a manner not consistent
 with management’s expectations, the Company could be required
 to adjust its provision for income taxes in the period such
 resolution occurs. Although timing of the resolution and/or closure
 of audits is not certain, the Company does not believe it is
 reasonably possible that its unrecognized tax benefits would
 materially change in the next 12 months.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001193125-14-383437:notes:227]
Note 3 – Consolidated Financial Statement Details

[0001193125-14-383437:notes:228]
The following tables show the Company’s
 consolidated balance sheet details as of September 27, 2014
 and September 28, 2013 (in millions):

[0001193125-14-383437:notes:229]
|  |  | 2014 |  |  | 2013 |  |
| Land and buildings |  | $ | 4,863 |  |  | $ | 3,309 |  |
| Machinery, equipment and internal-use software |  |  | 29,639 |  |  |  | 21,242 |  |
| Leasehold improvements |  |  | 4,513 |  |  |  | 3,968 |  |
| Gross property, plant and equipment |  |  | 39,015 |  |  |  | 28,519 |  |
| Accumulated depreciation and amortization |  |  | (18,391 | ) |  |  | (11,922 | ) |
| Net property, plant and equipment |  | $ | 20,624 |  |  | $ | 16,597 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-14-383437:notes:230]
Note 8 – Comprehensive Income

[0001193125-14-383437:notes:231]
Comprehensive income consists of two components,
 net income and OCI. OCI refers to revenue, expenses, and gains and
 losses that under GAAP are recorded as an element of
 shareholders’ equity but are excluded from net income. The
 Company’s OCI consists of foreign currency translation
 adjustments from those subsidiaries not using the U.S. dollar as
 their functional currency, net deferred gains and losses on certain
 derivative instruments accounted for as cash flow hedges and
 unrealized gains and losses on marketable securities classified as
 available-for-sale.

[0001193125-14-383437:notes:232]
The following table shows the gross amounts
 reclassified from AOCI into the Consolidated Statements of
 Operations and the associated financial statement line item for
 2014 (in millions):

[0001193125-14-383437:notes:233]
| Comprehensive Income Components |  | Financial Statement Line Item |  | 2014 |  |
| Unrecognized gains/losses on derivative instruments: |  |  |  |  |  |  |
| Foreign exchange contracts |  | Revenue |  | $ | 449 |  |
|  |  | Cost of sales |  |  | (295 | ) |
|  |  | Other income/expense, net |  |  | 15 |  |
| Interest rate contracts |  | Other income/expense, net |  |  | 16 |  |
|  |  |  |  |  | 185 |  |
| Unrealized gains/losses on marketable securities |  | Other income/expense, net |  |  | (205 | ) |
| Total amounts reclassified from AOCI |  | $ | (20 | ) |


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001193125-14-383437:notes:234]
Note 9 – Benefit Plans

[0001193125-14-383437:notes:235]
Stock Plans

[0001193125-14-383437:notes:236]
2014 Employee Stock Plan

[0001193125-14-383437:notes:237]
In the second quarter of 2014, shareholders
 approved the 2014 Employee Stock Plan (the “2014 Plan”)
 and terminated the Company’s authority to grant new awards
 under the 2003 Employee Stock Plan (the “2003 Plan”).
 The 2014 Plan provides for broad-based equity grants to employees,
 including executive officers, and permits the granting of RSUs,
 stock grants, performance-based awards, stock options and stock
 appreciation rights, as well as cash bonus awards. RSUs granted
 under the 2014 Plan generally vest over four years, based on
 continued employment, and are settled upon vesting in shares of the
 Company’s common stock on a one-for-one basis. Each share
 issued with respect to RSUs granted under the 2014 Plan reduces the
 number of shares available for grant under the plan by two shares.
 RSUs cancelled and shares withheld to satisfy tax withholding
 obligations increase the number of shares available for grant under
 the 2014 Plan utilizing a factor of two times the number of RSUs
 cancelled or shares withheld. Currently, all RSUs granted under the
 2014 Plan have dividend equivalent rights (“DERs”),
 which entitle holders of RSUs to the same dividend value per share
 as holders of common stock. DERs are subject to the same vesting
 and other terms and conditions as the corresponding unvested RSUs.
 DERs are accumulated and paid when the underlying shares vest. Upon
 approval of the 2014 Plan, the Company reserved 385 million
 shares plus the number of shares remaining that were reserved but
 not issued under the 2003 Plan. Shares subject to outstanding
 awards under the 2003 Plan that expire, are cancelled or otherwise
 terminate, or are withheld to satisfy tax withholding obligations
 with respect to RSUs, will also be available for awards under the
 2014 Plan. As of September 27, 2014, approximately
 492.6 million shares were reserved for future issuance under
 the 2014 Plan.

[0001193125-14-383437:notes:238]
2003 Employee Stock Plan

[0001193125-14-383437:notes:239]
The 2003 Plan is a shareholder approved plan that
 provided for broad-based equity grants to employees, including
 executive officers. The 2003 Plan permitted the granting of
 incentive stock options, nonstatutory stock options, RSUs, stock
 appreciation rights, stock purchase rights and performance-based
 awards. Options granted under the 2003 Plan generally expire seven
 to ten years after the grant date and generally become exercisable
 over a period of four years, based on continued employment, with
 either annual, semi-annual or quarterly vesting. RSUs granted under
 the 2003 Plan generally vest over two to four years, based on
 continued employment and are settled upon vesting in shares of the
 Company’s common stock on a one-for-one basis. All RSUs,
 other than RSUs held by the Chief Executive Officer, granted under
 the 2003 Plan have DERs. DERs are subject to the same vesting and
 other terms and conditions as the corresponding unvested RSUs. DERs
 are accumulated and paid when the underlying shares vest. In the
 second quarter of 2014, the Company terminated the authority to
 grant new awards under the 2003 Plan.

[0001193125-14-383437:notes:240]
1997 Director Stock Plan

[0001193125-14-383437:notes:241]
The 1997 Director Stock Plan (the “Director
 Plan”) is a shareholder approved plan that (i) permits
 the Company to grant awards of RSUs or stock options to the
 Company’s non-employee directors, (ii) provides for
 automatic initial grants of RSUs upon a non-employee director
 joining the Board of Directors and automatic annual grants of RSUs
 at each annual meeting of shareholders, and (iii) permits the
 Board of Directors to prospectively change the relative mixture of
 stock options and RSUs for the initial and annual award grants and
 the methodology for determining the number of shares of the
 Company’s common stock subject to these grants without
 shareholder approval. Each share issued with respect to RSUs
 granted under the Director Plan reduces the number of shares
 available for grant under the plan by two shares. The Director Plan
 expires November 9, 2019. All RSUs granted under the Director
 Plan are entitled to DERs. DERs are subject to the same vesting and
 other terms and conditions as the corresponding unvested RSUs. DERs
 are accumulated and paid when the underlying shares vest. As of
 September 27, 2014, approximately 1.2 million shares were
 reserved for future issuance under the Director Plan.

[0001193125-14-383437:notes:242]
Rule 10b5-1 Trading Plans

[0001193125-14-383437:notes:243]
During the fourth quarter of 2014, Section 16
 officers Timothy D. Cook, Luca Maestri, Daniel Riccio, Philip W.
 Schiller, D. Bruce Sewell and Jeffrey E. Williams had equity
 trading plans in place in accordance with Rule 10b5-1(c)(1) under the
 Exchange Act. An equity trading plan is a written document that
 pre-establishes the amounts, prices and dates (or formula for
 determining the amounts, prices and dates) of future purchases or
 sales of the Company’s stock, including shares acquired
 pursuant to the Company’s employee and director equity
 plans.

[0001193125-14-383437:notes:244]
Employee Stock Purchase Plan

[0001193125-14-383437:notes:245]
The Employee Stock Purchase Plan (the
 “Purchase Plan”) is a shareholder approved plan under
 which substantially all employees may purchase the Company’s
 common stock through payroll deductions at a price equal to 85% of
 the lower of the fair market values of the stock as of the
 beginning or the end of six-month offering periods. An
 employee’s payroll deductions under the Purchase Plan are
 limited to 10% of the employee’s compensation and employees
 may not purchase more than $25,000 of stock during any calendar
 year. As of September 27, 2014, approximately 7.6 million
 shares were reserved for future issuance under the Purchase
 Plan.

[0001193125-14-383437:notes:246]
401(k) Plan

[0001193125-14-383437:notes:247]
The Company’s 401(k) Plan is a deferred
 salary arrangement under Section 401(k) of the Internal
 Revenue Code. Under the 401(k) Plan, participating U.S. employees
 may defer a portion of their pre-tax earnings, up to the IRS annual
 contribution limit ($17,500 for calendar year 2014). The Company
 matches 50% to 100% of each employee’s contributions,
 depending on length of service, up to a maximum 6% of the
 employee’s eligible earnings. The Company’s matching
 contributions to the 401(k) Plan were $163 million, $135 million
 and $114 million in 2014, 2013 and 2012, respectively.

[0001193125-14-383437:notes:248]
Restricted Stock Units

[0001193125-14-383437:notes:249]
The fair value as of the respective vesting dates
 of RSUs was $3.4 billion, $3.1 billion and $3.3 billion for 2014,
 2013 and 2012, respectively. The majority of RSUs that vested in
 2014, 2013 and 2012 were net-share settled such that the Company
 withheld shares with value equivalent to the employees’
 minimum statutory obligation for the applicable income and other
 employment taxes, and remitted the cash to the appropriate taxing
 authorities. The total shares withheld were approximately
 15.6 million, 15.5 million and 16.1 million for
 2014, 2013 and 2012, respectively, and were based on the value of
 the RSUs on their respective vesting dates as determined by the
 Company’s closing stock price. Total payments for the
 employees’ tax obligations to taxing authorities were
 $1.2 billion, $1.1 billion and $1.2 billion in 2014, 2013 and
 2012, respectively, and are reflected as a financing activity
 within the Consolidated Statements of Cash Flows. These
 net-share settlements had the effect of share repurchases by the
 Company as they reduced and retired the number of shares that would
 have otherwise been issued as a result of the vesting and did not
 represent an expense to the Company.

[0001193125-14-383437:notes:250]
Stock Options

[0001193125-14-383437:notes:251]
The Company had 6.6 million stock options
 outstanding as of September 27, 2014, with a weighted-average
 exercise price per share of $21.99 and weighted-average remaining
 contractual term of 1.4 years, substantially all of which are
 exercisable. The aggregate intrinsic value of the stock options
 outstanding as of September 27, 2014 was $520 million, which
 represents the value of the Company’s closing stock price on
 the last trading day of the period in excess of the
 weighted-average exercise price multiplied by the number of options
 outstanding. Total intrinsic value of options at time of exercise
 was $1.5 billion, $1.0 billion and $2.3 billion for 2014, 2013 and
 2012, respectively.

[0001193125-14-383437:notes:252]
The income tax benefit related to share-based
 compensation expense was $1.0 billion, $816 million and
 $567 million for 2014, 2013 and 2012, respectively. As of
 September 27, 2014, the total unrecognized compensation cost
 related to outstanding stock options, RSUs and restricted stock was
 $6.3 billion, which the Company expects to recognize over a
 weighted-average period of 2.9 years.
