# AAPL 8-K — 0001193125-14-376361 filed 2014-10-20

## item codes, every 8-K on or before 2014-10-27

- 2014-10-20 0001193125-14-376361 — 2.02, 9.01
- 2014-07-23 0001193125-14-277193 — 8.01, 9.01
- 2014-07-22 0001193125-14-275598 — 2.02, 9.01
- 2014-07-17 0001193125-14-271698 — 5.02
- 2014-06-06 0001193125-14-228798 — 5.03, 9.01
- 2014-05-30 0001181431-14-021923 — 5.02
- 2014-05-06 0001193125-14-184969 — 8.01, 9.01
- 2014-04-23 0001193125-14-154883 — 7.01, 9.01
- 2014-04-23 0001193125-14-154871 — 2.02, 9.01
- 2014-03-05 0001193125-14-084697 — 5.02, 5.03, 5.07, 9.01
- 2014-01-27 0001193125-14-022238 — 2.02, 9.01
- 2013-10-28 0001193125-13-413498 — 2.02, 9.01
- 2013-09-23 0001181431-13-050140 — 8.01
- 2013-07-30 0001181431-13-041847 — 5.02
- 2013-07-23 0001193125-13-298914 — 2.02, 9.01
- 2013-06-21 0001193125-13-267629 — 5.02
- 2013-05-03 0001193125-13-199324 — 8.01, 9.01
- 2013-04-24 0001193125-13-170623 — 8.01, 9.01
- 2013-04-23 0001193125-13-167469 — 7.01, 9.01
- 2013-04-23 0001193125-13-167458 — 2.02, 9.01
- 2013-03-01 0001193125-13-085842 — 5.07
- 2013-01-23 0001193125-13-020783 — 2.02, 9.01
- 2012-10-25 0001193125-12-435506 — 2.02, 9.01
- 2012-07-24 0001193125-12-312355 — 2.02, 9.01
- 2012-06-28 0001181431-12-038301 — 5.02
- 2012-05-24 0001181431-12-032458 — 5.02
- 2012-04-24 0001193125-12-178928 — 2.02, 9.01
- 2012-02-27 0001193125-12-081892 — 5.07
- 2012-01-24 0001193125-12-021833 — 2.02, 9.01
- 2011-11-16 0001181431-11-056354 — 5.02
- 2011-10-18 0001193125-11-273826 — 2.02, 9.01
- 2011-10-06 0001181431-11-051976 — 8.01
- 2011-08-26 0001181431-11-047179 — 5.02
- 2011-07-19 0001193125-11-191368 — 2.02, 9.01
- 2011-06-15 0001181431-11-036782 — 5.02
- 2011-04-20 0001193125-11-103732 — 2.02, 9.01
- 2011-02-24 0001193125-11-045411 — 5.07
- 2011-01-18 0001193125-11-009392 — 2.02, 9.01
- 2011-01-18 0001181431-11-003847 — 5.02
- 2010-11-17 0001181431-10-056327 — 5.02, 5.03, 9.01
- 2010-10-18 0001193125-10-230992 — 2.02, 9.01
- 2010-07-20 0001193125-10-161807 — 2.02, 9.01
- 2010-04-20 0001193125-10-087786 — 2.02, 9.01
- 2010-03-12 0001181431-10-016054 — 5.02
- 2010-03-01 0001193125-10-044765 — 5.02, 5.07, 9.01
- 2010-01-25 0001193125-10-012096 — 2.02, 9.01
- 2009-10-19 0001193125-09-209633 — 2.02, 9.01
- 2009-08-04 0001181431-09-037492 — 5.02
- 2009-07-21 0001193125-09-152290 — 2.02, 9.01
- 2009-06-02 0001181431-09-028400 — 5.03
- 2009-04-22 0001193125-09-084599 — 2.02, 9.01
- 2009-02-27 0001181431-09-012161 — 4.01
- 2009-01-21 0001193125-09-009009 — 2.02, 9.01
- 2009-01-16 0001181431-09-003017 — 5.02
- 2008-10-21 0001193125-08-213642 — 2.02, 9.01
- 2008-08-26 0001181431-08-050059 — 5.03
- 2008-07-21 0001193125-08-154381 — 2.02, 9.01
- 2008-06-09 0001181431-08-037620 — 8.01
- 2008-04-23 0001193125-08-088001 — 2.02, 9.01
- 2008-01-22 0001193125-08-009715 — 2.02, 9.01
- 2008-01-15 0001181431-08-003342 — 2.02, 8.01
- 2008-01-08 0001181431-08-002372 — 5.02
- 2007-10-22 0001104659-07-076142 — 2.02, 9.01
- 2007-07-25 0001104659-07-056111 — 2.02, 9.01
- 2007-05-16 0001104659-07-040672 — 5.02, 9.01
- 2007-04-25 0001104659-07-031354 — 2.02, 9.01
- 2007-04-24 0001104659-07-030938 — 8.01, 9.01
- 2007-02-21 0001104659-07-012760 — 5.03, 9.01
- 2007-01-17 0001104659-07-002905 — 2.02, 9.01
- 2007-01-10 0001104659-07-001648 — 5.03, 9.01
- 2006-10-27 0001104659-06-069015 — 8.01
- 2006-10-18 0001104659-06-067275 — 2.02, 9.01
- 2006-10-04 0001104659-06-064935 — 5.02, 8.01, 9.01
- 2006-09-01 0001104659-06-058808 — 1.01, 5.02, 5.03, 9.01
- 2006-08-11 0001104659-06-054118 — 2.02, 3.01, 9.01
- 2006-08-04 0001104659-06-051302 — 2.02, 4.02, 9.01
- 2006-07-19 0001104659-06-047739 — 2.02, 9.01
- 2006-04-21 0001181431-06-024759 — 1.01
- 2006-04-19 0001104659-06-025992 — 2.02, 9.01
- 2006-01-18 0001104659-06-002690 — 2.02, 9.01
- 2006-01-10 0001104659-06-001428 — 2.02
- 2005-12-19 0001181431-05-067468 — 1.01
- 2005-10-14 0001181431-05-056604 — 5.02
- 2005-10-11 0001104659-05-048094 — 2.02, 9.01
- 2005-08-26 0001181431-05-049163 — 1.01
- 2005-08-15 0001181431-05-046871 — 1.01
- 2005-07-13 0001104659-05-032297 — 2.02, 9.01
- 2005-06-06 0001181431-05-033177 — 8.01
- 2005-04-26 0001181431-05-023450 — 1.01
- 2005-04-13 0001104659-05-016307 — 2.02, 9.01
- 2005-03-02 0001181431-05-013840 — 3.03, 5.03
- 2005-02-11 0001104659-05-005507 — 8.01
- 2005-01-12 0001104659-05-001183 — 2.02, 9.01
- 2005-01-11 0001104659-05-001049 — 2.02
- 2004-10-13 0001104659-04-030400 — 2.02, 9.01
- 2004-07-14 0001104659-04-019574 — 12, 7
- 2004-04-14 0001104659-04-010122 — 12, 7
- 2004-01-14 0001104659-04-000896 — 12, 7
- 2003-10-15 0001104659-03-022879 — 12, 7
- 2003-07-16 0001104659-03-014913 — 7, 9
- 2003-04-16 0001047469-03-013617 — 7, 9
- 2003-03-21 0001104659-03-004649 — 5, 7
- 2002-08-13 0000912057-02-031595 — 5, 7
- 2002-08-05 0000912057-02-029692 — 5, 7
- 2000-01-24 0000912057-00-002128 — 5, 7
- 1999-09-07 0000320193-99-000010 — 2
- 1999-07-16 0000320193-99-000007 — 2
- 1998-12-23 0000320193-98-000010 — 1
- 1998-01-08 0000320193-98-000001 — 2
- 1997-09-25 0000320193-97-000019 — 2
- 1997-09-25 0000320193-97-000018 — 2
- 1997-09-05 0000320193-97-000016 — 2
- 1997-07-28 0000320193-97-000012 — 4
- 1997-04-25 0000320193-97-000009 — 5
- 1997-04-10 0000320193-97-000007 — 7
- 1996-12-24 0000320193-96-000027 — 7
- 1996-12-23 0000320193-96-000025 — 4 — amendment of 0000320193-96-000021
- 1996-12-13 0000320193-96-000021 — 4
- 1996-10-28 0000912057-96-023874 — 5, 7
- 1996-06-17 0000320193-96-000014 — 1
- 1996-04-12 0000320193-96-000006 — 1

## late-filing notifications on or before 2014-10-27

- 2006-12-15 0001104659-06-081617 — NT 10-K, for the period ended 2006-09-30
- 2006-08-11 0001104659-06-053743 — NT 10-Q, for the period ended 2006-07-01

## item 2.02 — earnings release, exhibit 99.1

[0001193125-14-376361:8k_2_02:1]
EX-99.1
2
d806538dex991.htm
EX-99.1

[0001193125-14-376361:8k_2_02:2]
EX-99.1

[0001193125-14-376361:8k_2_02:3]
Exhibit 99.1

[0001193125-14-376361:8k_2_02:4]
Apple Reports Fourth Quarter Results

[0001193125-14-376361:8k_2_02:5]
Strong iPhone, Mac & App
Store Sales Drive Record September Quarter Revenue & Earnings

[0001193125-14-376361:8k_2_02:6]
CUPERTINO, California—October 20, 2014—Apple® today announced financial results for its fiscal 2014 fourth quarter ended September 27, 2014. The Company posted quarterly revenue of $42.1 billion and quarterly net profit of $8.5 billion,
or $1.42 per diluted share. These results compare to revenue of $37.5 billion and net profit of $7.5 billion, or $1.18 per diluted share, in the year-ago quarter. Gross margin was 38 percent compared to 37 percent in the year-ago quarter.
International sales accounted for 60 percent of the quarter’s revenue.

[0001193125-14-376361:8k_2_02:7]
Apple’s board of directors has declared a cash dividend of $.47 per share of the
Company’s common stock. The dividend is payable on November 13, 2014, to shareholders of record as of the close of business on November 10, 2014.

[0001193125-14-376361:8k_2_02:8]
“Our fiscal 2014 was one for the record books, including the biggest iPhone launch ever with iPhone 6 and iPhone 6 Plus,” said Tim Cook, Apple’s CEO.
“With amazing innovations in our new iPhones, iPads and Macs, as well as iOS 8 and OS X Yosemite, we are heading into the holidays with Apple’s strongest product lineup ever. We are also incredibly excited about Apple Watch and other great
products and services in the pipeline for 2015.”

[0001193125-14-376361:8k_2_02:9]
“Our strong business performance drove EPS growth of 20 percent and a record $13.3 billion in cash flow
from operations in the September quarter,” said Luca Maestri, Apple’s CFO. “We continued to execute aggressively against our capital return program, spending over $20 billion in the quarter and bringing cumulative returns to $94
billion.”

[0001193125-14-376361:8k_2_02:10]
Apple is providing the following guidance for its fiscal 2015 first quarter:

[0001193125-14-376361:8k_2_02:11]
| • |  | revenue between $63.5 billion and $66.5 billion |

[0001193125-14-376361:8k_2_02:12]
| • |  | gross margin between 37.5 percent and 38.5 percent |

[0001193125-14-376361:8k_2_02:13]
| • |  | operating expenses between $5.4 billion and $5.5 billion |

[0001193125-14-376361:8k_2_02:14]
| • |  | other income/(expense) of $325 million |

[0001193125-14-376361:8k_2_02:15]
| • |  | tax rate of 26.5 percent |

[0001193125-14-376361:8k_2_02:16]
Apple will provide live streaming of its Q4 2014 financial results conference call beginning at
2:00 p.m. PDT on October 20, 2014 at www.apple.com/quicktime/qtv/earningsq414. This webcast will also be available for replay for approximately two weeks thereafter.

[0001193125-14-376361:8k_2_02:17]
Apple designs Macs, the best personal computers in the world, along with OS X, iLife, iWork and professional software. Apple leads the digital music revolution with its
iPods and iTunes online store. Apple has reinvented the mobile phone with its revolutionary iPhone and App Store, and is defining the future of mobile media and computing devices with iPad.

[0001193125-14-376361:8k_2_02:18]
Press Contact:

[0001193125-14-376361:8k_2_02:19]
Kristin Huguet

[0001193125-14-376361:8k_2_02:20]
Apple

[0001193125-14-376361:8k_2_02:21]
khuguet@apple.com

[0001193125-14-376361:8k_2_02:22]
(408) 974-2414

[0001193125-14-376361:8k_2_02:23]
Investor Relations Contacts:

[0001193125-14-376361:8k_2_02:24]
Nancy Paxton

[0001193125-14-376361:8k_2_02:25]
Apple

[0001193125-14-376361:8k_2_02:26]
paxton1@apple.com

[0001193125-14-376361:8k_2_02:27]
(408) 974-5420

[0001193125-14-376361:8k_2_02:28]
Joan Hoover

[0001193125-14-376361:8k_2_02:29]
Apple

[0001193125-14-376361:8k_2_02:30]
hoover1@apple.com

[0001193125-14-376361:8k_2_02:31]
(408) 974-4570

[0001193125-14-376361:8k_2_02:32]
NOTE TO EDITORS: For additional information visit Apple’s PR website (www.apple.com/pr), or call Apple’s Media Helpline at (408) 974-2042.

[0001193125-14-376361:8k_2_02:33]
© 2014 Apple Inc. All rights reserved. Apple, the Apple logo, Mac, Mac OS and Macintosh are trademarks of
Apple. Other company and product names may be trademarks of their respective owners.

[0001193125-14-376361:8k_2_02:34]
Apple Inc.

[0001193125-14-376361:8k_2_02:35]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-14-376361:8k_2_02:36]
(In millions, except number of shares which are reflected in thousands and per share amounts)

[0001193125-14-376361:8k_2_02:37]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |
|  |  | September 27,2014 |  |  | September 28,2013 |  |  | September 27,2014 |  |  | September 28,2013 |  |
| Net sales |  | $ | 42,123 |  |  | $ | 37,472 |  |  | $ | 182,795 |  |  | $ | 170,910 |  |
| Cost of sales (1) |  |  | 26,114 |  |  |  | 23,601 |  |  |  | 112,258 |  |  |  | 106,606 |  |
| Gross margin |  |  | 16,009 |  |  |  | 13,871 |  |  |  | 70,537 |  |  |  | 64,304 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development (1) |  |  | 1,686 |  |  |  | 1,168 |  |  |  | 6,041 |  |  |  | 4,475 |  |
| Selling, general and administrative (1) |  |  | 3,158 |  |  |  | 2,673 |  |  |  | 11,993 |  |  |  | 10,830 |  |
| Total operating expenses |  |  | 4,844 |  |  |  | 3,841 |  |  |  | 18,034 |  |  |  | 15,305 |  |
| Operating income |  |  | 11,165 |  |  |  | 10,030 |  |  |  | 52,503 |  |  |  | 48,999 |  |
| Other income/(expense), net |  |  | 307 |  |  |  | 113 |  |  |  | 980 |  |  |  | 1,156 |  |
| Income before provision for income taxes |  |  | 11,472 |  |  |  | 10,143 |  |  |  | 53,483 |  |  |  | 50,155 |  |
| Provision for income taxes |  |  | 3,005 |  |  |  | 2,631 |  |  |  | 13,973 |  |  |  | 13,118 |  |
| Net income |  | $ | 8,467 |  |  | $ | 7,512 |  |  | $ | 39,510 |  |  | $ | 37,037 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.43 |  |  | $ | 1.19 |  |  | $ | 6.49 |  |  | $ | 5.72 |  |
| Diluted |  | $ | 1.42 |  |  | $ | 1.18 |  |  | $ | 6.45 |  |  | $ | 5.68 |  |
| Shares used in computing earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 5,933,845 |  |  |  | 6,329,139 |  |  |  | 6,085,572 |  |  |  | 6,477,320 |  |
| Diluted |  |  | 5,972,082 |  |  |  | 6,363,919 |  |  |  | 6,122,663 |  |  |  | 6,521,634 |  |
| Cash dividends declared per common share |  | $ | 0.47 |  |  | $ | 0.44 |  |  | $ | 1.82 |  |  | $ | 1.64 |  |
| (1) Includes share-based compensation expense as follows: |  |
| Cost of sales |  | $ | 116 |  |  | $ | 88 |  |  | $ | 450 |  |  | $ | 350 |  |
| Research and development |  | $ | 314 |  |  | $ | 209 |  |  | $ | 1,216 |  |  | $ | 917 |  |
| Selling, general and administrative |  | $ | 332 |  |  | $ | 258 |  |  | $ | 1,197 |  |  | $ | 986 |  |

[0001193125-14-376361:8k_2_02:38]
Apple Inc.

[0001193125-14-376361:8k_2_02:39]
UNAUDITED CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-14-376361:8k_2_02:40]
(In millions, except number of shares which are reflected in thousands and par value)

[0001193125-14-376361:8k_2_02:41]
|  |  | September 27,2014 |  |  | September 28,2013 |  |
| ASSETS: |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 13,844 |  |  | $ | 14,259 |  |
| Short-term marketable securities |  |  | 11,233 |  |  |  | 26,287 |  |
| Accounts receivable, less allowances of $86 and $99, respectively |  |  | 17,460 |  |  |  | 13,102 |  |
| Inventories |  |  | 2,111 |  |  |  | 1,764 |  |
| Deferred tax assets |  |  | 4,318 |  |  |  | 3,453 |  |
| Vendor non-trade receivables |  |  | 9,759 |  |  |  | 7,539 |  |
| Other current assets |  |  | 9,806 |  |  |  | 6,882 |  |
| Total current assets |  |  | 68,531 |  |  |  | 73,286 |  |
| Long-term marketable securities |  |  | 130,162 |  |  |  | 106,215 |  |
| Property, plant and equipment, net |  |  | 20,624 |  |  |  | 16,597 |  |
| Goodwill |  |  | 4,616 |  |  |  | 1,577 |  |
| Acquired intangible assets, net |  |  | 4,142 |  |  |  | 4,179 |  |
| Other assets |  |  | 3,764 |  |  |  | 5,146 |  |
| Total assets |  | $ | 231,839 |  |  | $ | 207,000 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY: |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 30,196 |  |  | $ | 22,367 |  |
| Accrued expenses |  |  | 18,453 |  |  |  | 13,856 |  |
| Deferred revenue |  |  | 8,491 |  |  |  | 7,435 |  |
| Commercial paper |  |  | 6,308 |  |  |  | 0 |  |
| Total current liabilities |  |  | 63,448 |  |  |  | 43,658 |  |
| Deferred revenue – non-current |  |  | 3,031 |  |  |  | 2,625 |  |
| Long-term debt |  |  | 28,987 |  |  |  | 16,960 |  |
| Other non-current liabilities |  |  | 24,826 |  |  |  | 20,208 |  |
| Total liabilities |  |  | 120,292 |  |  |  | 83,451 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Shareholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock and additional paid-in capital, $0.00001 par value: 12,600,000 shares authorized; 5,866,161 and 6,294,494 shares issued and outstanding, respectively |  |  | 23,313 |  |  |  | 19,764 |  |
| Retained earnings |  |  | 87,152 |  |  |  | 104,256 |  |
| Accumulated other comprehensive income/(loss) |  |  | 1,082 |  |  |  | (471 | ) |
| Total shareholders’ equity |  |  | 111,547 |  |  |  | 123,549 |  |
| Total liabilities and shareholders’ equity |  | $ | 231,839 |  |  | $ | 207,000 |  |

[0001193125-14-376361:8k_2_02:42]
Apple Inc.

[0001193125-14-376361:8k_2_02:43]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-14-376361:8k_2_02:44]
(In millions)

[0001193125-14-376361:8k_2_02:45]
|  |  | Twelve Months Ended |  |
|  |  | September 27,2014 |  |  | September 28,2013 |  |
| Cash and cash equivalents, beginning of the year |  | $ | 14,259 |  |  | $ | 10,746 |  |
| Operating activities: |  |  |  |  |
| Net income |  |  | 39,510 |  |  |  | 37,037 |  |
| Adjustments to reconcile net income to cash generated by operating activities: |  |  |  |  |
| Depreciation and amortization |  |  | 7,946 |  |  |  | 6,757 |  |
| Share-based compensation expense |  |  | 2,863 |  |  |  | 2,253 |  |
| Deferred income tax expense |  |  | 2,347 |  |  |  | 1,141 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  |  | (4,232 | ) |  |  | (2,172 | ) |
| Inventories |  |  | (76 | ) |  |  | (973 | ) |
| Vendor non-trade receivables |  |  | (2,220 | ) |  |  | 223 |  |
| Other current and non-current assets |  |  | 167 |  |  |  | 1,080 |  |
| Accounts payable |  |  | 5,938 |  |  |  | 2,340 |  |
| Deferred revenue |  |  | 1,460 |  |  |  | 1,459 |  |
| Other current and non-current liabilities |  |  | 6,010 |  |  |  | 4,521 |  |
| Cash generated by operating activities |  |  | 59,713 |  |  |  | 53,666 |  |
| Investing activities: |  |  |  |  |
| Purchases of marketable securities |  |  | (217,128 | ) |  |  | (148,489 | ) |
| Proceeds from maturities of marketable securities |  |  | 18,810 |  |  |  | 20,317 |  |
| Proceeds from sales of marketable securities |  |  | 189,301 |  |  |  | 104,130 |  |
| Payments made in connection with business acquisitions, net |  |  | (3,765 | ) |  |  | (496 | ) |
| Payments for acquisition of property, plant and equipment |  |  | (9,571 | ) |  |  | (8,165 | ) |
| Payments for acquisition of intangible assets |  |  | (242 | ) |  |  | (911 | ) |
| Other |  |  | 16 |  |  |  | (160 | ) |
| Cash used in investing activities |  |  | (22,579 | ) |  |  | (33,774 | ) |
| Financing activities: |  |  |  |  |
| Proceeds from issuance of common stock |  |  | 730 |  |  |  | 530 |  |
| Excess tax benefits from equity awards |  |  | 739 |  |  |  | 701 |  |
| Taxes paid related to net share settlement of equity awards |  |  | (1,158 | ) |  |  | (1,082 | ) |
| Dividends and dividend equivalents paid |  |  | (11,126 | ) |  |  | (10,564 | ) |
| Repurchase of common stock |  |  | (45,000 | ) |  |  | (22,860 | ) |
| Proceeds from issuance of long-term debt, net |  |  | 11,960 |  |  |  | 16,896 |  |
| Proceeds from issuance of commercial paper, net |  |  | 6,306 |  |  |  | 0 |  |
| Cash used in financing activities |  |  | (37,549 | ) |  |  | (16,379 | ) |
| Increase/(decrease) in cash and cash equivalents |  |  | (415 | ) |  |  | 3,513 |  |
| Cash and cash equivalents, end of the year |  | $ | 13,844 |  |  | $ | 14,259 |  |
| Supplemental cash flow disclosure: |  |  |  |  |
| Cash paid for income taxes, net |  | $ | 10,026 |  |  | $ | 9,128 |  |
| Cash paid for interest |  | $ | 339 |  |  | $ | 0 |  |
