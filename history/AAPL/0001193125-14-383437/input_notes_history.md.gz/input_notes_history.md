# AAPL note change history — 0001193125-14-157311 → 0001193125-14-277160


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-07-23):
[0001193125-14-277160:note_history:1]
The following
 table shows changes in the Company’s accrued warranties and
 related costs for the three- and nine-month periods ended
 June 28, 2014 and June 29, 2013 (in millions):
  (was, 2014-04-24, similarity 0.9318):
[0001193125-14-157311:note_history:1]
The following
 table shows changes in the Company’s accrued warranties and
 related costs for the three- and six-month periods ended
 March 29, 2014 and March 30, 2013 (in
 millions):

- changed (2014-07-23):
[0001193125-14-277160:note_history:2]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 28, 2014 |  |  | June 29, 2013 |  |  | June 28, 2014 |  |  | June 29, 2013 |  |
| Beginning accrued warranty and related costs |  | $ | 4,368 |  |  | $ | 3,014 |  |  | $ | 2,967 |  |  | $ | 1,638 |  |
| Cost of warranty claims |  |  | (882 | ) |  |  | (1,033 | ) |  |  | (2,811 | ) |  |  | (2,566 | ) |
| Accruals for product warranty |  |  | 756 |  |  |  | 736 |  |  |  | 4,086 |  |  |  | 3,645 |  |
| Ending accrued warranty and related costs |  | $ | 4,242 |  |  | $ | 2,717 |  |  | $ | 4,242 |  |  | $ | 2,717 |  |
  (was, 2014-04-24, similarity 0.8324):
[0001193125-14-157311:note_history:2]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 29, 2014 |  |  | March 30, 2013 |  |  | March 29, 2014 |  |  | March 30, 2013 |  |
| Beginning accrued warranty and related costs |  | $ | 3,980 |  |  | $ | 2,310 |  |  | $ | 2,967 |  |  | $ | 1,638 |  |
| Cost of warranty claims |  |  | (865 | ) |  |  | (847 | ) |  |  | (1,929 | ) |  |  | (1,533 | ) |
| Accruals for product warranty |  |  | 1,253 |  |  |  | 1,551 |  |  |  | 3,330 |  |  |  | 2,909 |  |
| Ending accrued warranty and related costs |  | $ | 4,368 |  |  | $ | 3,014 |  |  | $ | 4,368 |  |  | $ | 3,014 |  |

- changed (2014-07-23):
[0001193125-14-277160:note_history:3]
The Company
 generally does not indemnify end-users of its operating system and
 application software against legal claims that the software
 infringes third-party intellectual property rights. Other
 agreements entered into by the Company sometimes include
 indemnification provisions under which the Company could be subject
 to costs and/or damages in the event of an infringement claim
 against the Company or an indemnified third-party. However, the
 Company has not been required to make any significant payments
 resulting from such an infringement claim asserted against it or an
 indemnified third-party. In the opinion of management, there was
 not at least a reasonable possibility the Company may have incurred
 a material loss with respect to indemnification of end-users of its
 operating system or application software for infringement of
 third-party intellectual property rights. The Company did not
 record a liability for infringement costs related to
 indemnification as of June 28, 2014 or September 28,
 2013.
  (was, 2014-04-24, similarity 0.9955):
[0001193125-14-157311:note_history:3]
The Company
 generally does not indemnify end-users of its operating system and
 application software against legal claims that the software
 infringes third-party intellectual property rights. Other
 agreements entered into by the Company sometimes include
 indemnification provisions under which the Company could be subject
 to costs and/or damages in the event of an infringement claim
 against the Company or an indemnified third-party. However, the
 Company has not been required to make any significant payments
 resulting from such an infringement claim asserted against it or an
 indemnified third-party. In the opinion of management, there was
 not at least a reasonable possibility the Company may have incurred
 a material loss with respect to indemnification of end-users of its
 operating system or application software for infringement of
 third-party intellectual property rights. The Company did not
 record a liability for infringement costs related to
 indemnification as of March 29, 2014 or September 28,
 2013.

- changed (2014-07-23):
[0001193125-14-277160:note_history:4]
Although most
 components essential to the Company’s business are generally
 available from multiple sources, a number of components are
 currently obtained from single or limited sources. In addition, the
 Company competes for various components with other participants in
 the markets for mobile communication and media devices and personal
 computers. Therefore, many components used by the Company,
 including those that are available from multiple sources, are at
 times subject to industry-wide shortage and significant pricing
 fluctuations that could materially adversely affect the
 Company’s financial condition and operating
 results.
  (was, 2014-04-24, similarity 0.9953):
[0001193125-14-157311:note_history:4]
Although most
 components essential to the Company’s business are generally
 available from multiple sources, a number of components are
 currently obtained from single or limited sources. In addition, the
 Company competes for various components with other participants in
 the markets for mobile communication and media devices and personal
 computers. Therefore, many components used by the Company,
 including those that are available from multiple sources, are at
 times subject to industry-wide shortage and significant pricing
 fluctuations that can materially adversely affect the
 Company’s financial condition and operating
 results.

- changed (2014-07-23):
[0001193125-14-277160:note_history:5]
The Company has
 entered into agreements for the supply of many components; however,
 there can be no guarantee that the Company will be able to extend
 or renew these agreements on similar terms, or at all. Therefore,
 the Company remains subject to significant risks of supply
 shortages and price increases that could materially adversely
 affect its financial condition and operating results.
  (was, 2014-04-24, similarity 0.904):
[0001193125-14-157311:note_history:5]
The Company has
 entered into various agreements for the supply of components;
 however, there can be no guarantee that the Company will be able to
 extend or renew these agreements on similar terms, or at all.
 Therefore, the Company remains subject to significant risks of
 supply shortages and price increases that can materially adversely
 affect its financial condition and operating results.

- changed (2014-07-23):
[0001193125-14-277160:note_history:6]
The Company
 leases various equipment and facilities, including retail space,
 under noncancelable operating lease arrangements. The Company does
 not currently utilize any other off-balance sheet financing
 arrangements. The major facility leases are typically for terms not
 exceeding 10 years and generally provide renewal options for terms
 not exceeding five additional years. Leases for retail space are
 for terms ranging from five to 20 years, the majority of which are
 for 10 years, and often contain multi-year renewal options. As of
 June 28, 2014, the Company’s total future minimum lease
 payments under noncancelable operating leases were $5.0 billion, of
 which $3.8 billion related to leases for retail space.
  (was, 2014-04-24, similarity 0.9936):
[0001193125-14-157311:note_history:6]
The Company
 leases various equipment and facilities, including retail space,
 under noncancelable operating lease arrangements. The Company does
 not currently utilize any other off-balance sheet financing
 arrangements. The major facility leases are typically for terms not
 exceeding 10 years and generally provide renewal options for terms
 not exceeding five additional years. Leases for retail space are
 for terms ranging from five to 20 years, the majority of which are
 for 10 years, and often contain multi-year renewal options. As of
 March 29, 2014, the Company’s total future minimum lease
 payments under noncancelable operating leases were $4.8 billion, of
 which $3.6 billion related to leases for retail space.

- changed (2014-07-23):
[0001193125-14-277160:note_history:7]
The Company
 utilizes several outsourcing partners to manufacture sub-assemblies
 for the Company’s products and to perform final assembly and
 testing of finished products. These outsourcing partners acquire
 components and build product based on demand information supplied
 by the Company, which typically covers periods up to 150 days. The
 Company also obtains individual components for its products from a
 wide variety of individual suppliers. Consistent with industry
 practice, the Company acquires components through a combination of
 purchase orders, supplier contracts, and open orders based on
 projected demand information. Where
 appropriate, the purchases are applied to inventory
 component prepayments that are outstanding with
 the respective supplier. As of June 28, 2014, the Company
 had outstanding off-balance sheet third-party manufacturing
 commitments and component purchase commitments of $15.4
 billion.
  (was, 2014-04-24, similarity 0.995):
[0001193125-14-157311:note_history:7]
The Company
 utilizes several outsourcing partners to manufacture sub-assemblies
 for the Company’s products and to perform final assembly and
 testing of finished products. These outsourcing partners acquire
 components and build product based on demand information supplied
 by the Company, which typically covers periods up to 150 days. The
 Company also obtains individual components for its products from a
 wide variety of individual suppliers. Consistent with industry
 practice, the Company acquires components through a combination of
 purchase orders, supplier contracts, and open orders based on
 projected demand information. Where
 appropriate, the purchases are applied to inventory
 component prepayments that are outstanding with
 the respective supplier. As of March 29, 2014, the
 Company had outstanding off-balance sheet third-party manufacturing
 commitments and component purchase commitments of $12.6
 billion.

- changed (2014-07-23):
[0001193125-14-277160:note_history:8]
In addition to
 the commitments mentioned above, the Company had additional
 off-balance sheet obligations of $5.6 billion as of June 28,
 2014, which were comprised mainly of commitments to acquire capital
 assets, including product tooling and manufacturing process
 equipment, and commitments related to advertising, research and
 development, Internet and telecommunications services and other
 obligations.
  (was, 2014-04-24, similarity 0.9887):
[0001193125-14-157311:note_history:8]
In addition to
 the commitments mentioned above, the Company had additional
 off-balance sheet obligations of $2.8 billion as of March 29,
 2014, which were comprised mainly of commitments to acquire capital
 assets, including product tooling and manufacturing process
 equipment, and commitments related to advertising, research and
 development, Internet and telecommunications services and other
 obligations.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-07-23):
[0001193125-14-277160:note_history:9]
These condensed
 consolidated financial statements and accompanying notes should be
 read in conjunction with the Company’s annual consolidated
 financial statements and the notes thereto for the fiscal year
 ended September 28, 2013, included in its Annual Report on
 Form 10-K (the “2013 Form 10-K”). The Company’s
 fiscal year is the 52 or 53-week period that ends on the last
 Saturday of September. An additional week is included in the first
 fiscal quarter approximately every six years to realign fiscal
 quarters with calendar quarters. The Company’s fiscal years
 2014 and 2013 include 52 weeks each. Unless otherwise stated,
 references to particular years, quarters or months refer to the
 Company’s fiscal years ended in September and the associated
 quarters or months of those fiscal years.
  (was, 2014-04-24, similarity 0.9935):
[0001193125-14-157311:note_history:9]
These condensed
 consolidated financial statements and accompanying notes should be
 read in conjunction with the Company’s annual consolidated
 financial statements and the notes thereto for the fiscal year
 ended September 28, 2013, included in its Annual Report on
 Form 10-K (the “2013 Form 10-K”). The Company’s
 fiscal year is the 52 or 53-week period that ends on the last
 Saturday of September. An additional week is included in the first
 fiscal quarter approximately every six years to realign fiscal
 quarters with calendar quarters. The Company’s fiscal years
 2014 and 2013 each include 52 weeks. Unless otherwise stated,
 references to particular years, quarters or months refer to the
 Company’s fiscal years ended in September and the associated
 quarters or months of those fiscal years.

- added (2014-07-23):
[0001193125-14-277160:note_history:10]
Common Stock
 Split

- added (2014-07-23):
[0001193125-14-277160:note_history:11]
On June 6,
 2014, the Company effected a seven-for-one stock split to
 shareholders of record as of June 2, 2014. All share and per
 share information has been retroactively adjusted to reflect the
 stock split.

- changed (2014-07-23):
[0001193125-14-277160:note_history:12]
The following
 table shows the computation of basic and diluted earnings per share
 for the three- and nine-month periods ended June 28, 2014 and
 June 29, 2013 (in thousands, except net income in millions and
 per share amounts):
  (was, 2014-04-24, similarity 0.9007):
[0001193125-14-157311:note_history:12]
The following
 table shows the computation of basic and diluted earnings per share
 for the three- and six-month periods ended March 29, 2014 and
 March 30, 2013 (in thousands, except net income in millions
 and per share amounts):

- changed (2014-07-23):
[0001193125-14-277160:note_history:13]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 28, 2014 |  |  | June 29, 2013 |  |  | June 28, 2014 |  |  | June 29, 2013 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 7,748 |  |  | $ | 6,900 |  |  | $ | 31,043 |  |  | $ | 29,525 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding |  |  | 6,012,635 |  |  |  | 6,430,323 |  |  |  | 6,136,147 |  |  |  | 6,526,714 |  |
| Effect of dilutive securities |  |  | 39,076 |  |  |  | 39,531 |  |  |  | 36,710 |  |  |  | 47,491 |  |
| Weighted-average diluted shares |  |  | 6,051,711 |  |  |  | 6,469,854 |  |  |  | 6,172,857 |  |  |  | 6,574,205 |  |
| Basic earnings per share |  | $ | 1.29 |  |  | $ | 1.07 |  |  | $ | 5.06 |  |  | $ | 4.52 |  |
| Diluted earnings per share |  | $ | 1.28 |  |  | $ | 1.07 |  |  | $ | 5.03 |  |  | $ | 4.49 |  |
  (was, 2014-04-24, similarity 0.8815):
[0001193125-14-157311:note_history:13]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 29, 2014 |  |  | March 30, 2013 |  |  | March 29, 2014 |  |  | March 30, 2013 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 10,223 |  |  | $ | 9,547 |  |  | $ | 23,295 |  |  | $ | 22,625 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding |  |  | 874,757 |  |  |  | 939,629 |  |  |  | 885,415 |  |  |  | 939,273 |  |
| Effect of dilutive securities |  |  | 4,771 |  |  |  | 6,406 |  |  |  | 5,075 |  |  |  | 7,353 |  |
| Weighted-average diluted shares |  |  | 879,528 |  |  |  | 946,035 |  |  |  | 890,490 |  |  |  | 946,626 |  |
| Basic earnings per share |  | $ | 11.69 |  |  | $ | 10.16 |  |  | $ | 26.31 |  |  | $ | 24.09 |  |
| Diluted earnings per share |  | $ | 11.62 |  |  | $ | 10.09 |  |  | $ | 26.16 |  |  | $ | 23.90 |  |

- changed (2014-07-23):
[0001193125-14-277160:note_history:14]
Potentially
 dilutive securities, the effect of which would have been
 antidilutive, were not significant for the three- and nine-month
 periods ended June 28, 2014 and the three- and nine-month
 periods ended June 29, 2013. The Company excluded these
 securities from the computation of diluted earnings per
 share.
  (was, 2014-04-24, similarity 0.7258):
[0001193125-14-157311:note_history:14]
Potentially
 dilutive securities, the effect of which would have been
 antidilutive, were not significant for the three- and six-month
 periods ended March 29, 2014 and the three- and six-month
 periods ended March 30, 2013. The Company excluded these
 securities from the computation of diluted earnings per
 share.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2014-07-23):
[0001193125-14-277160:note_history:15]
Note 6 –
 Debt

- added (2014-07-23):
[0001193125-14-277160:note_history:16]
Commercial
 Paper

- added (2014-07-23):
[0001193125-14-277160:note_history:17]
In April 2014,
 the Board of Directors authorized the Company to issue unsecured
 short-term promissory notes (“Commercial Paper”)
 pursuant to a commercial paper program. The Company intends to use
 net proceeds from the commercial paper program for general
 corporate purposes, including dividends and share repurchases. As
 of June 28, 2014, the Company had $2.0 billion of Commercial
 Paper outstanding, with a weighted average interest rate of 0.09%
 and maturities generally less than nine months.

- added (2014-07-23):
[0001193125-14-277160:note_history:18]
Long-Term
 Debt

- added (2014-07-23):
[0001193125-14-277160:note_history:19]
In the third
 quarter of 2014 and 2013, the Company issued $12.0 billion and
 $17.0 billion of long-term debt, respectively. The debt issuances
 included floating- and fixed-rate notes with varying maturities for
 an aggregate principal amount of $29.0 billion (collectively the
 “Notes”). The Notes are senior unsecured obligations,
 and interest is payable in arrears, quarterly for the floating-rate
 notes and semi-annually for the fixed-rate notes.

- added (2014-07-23):
[0001193125-14-277160:note_history:20]
The following table
 provides a summary of the Company’s long-term debt as of
 June 28, 2014 and September 28, 2013:

- added (2014-07-23):
[0001193125-14-277160:note_history:21]
|  |  | As of June 28, 2014 |  |  | As of September 28, 2013 |  |
|  |  | Amount (in millions) |  |  | Effective Interest Rate |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |
| Floating-rate notes due 2016 |  | $ | 1,000 |  |  |  | 0.51% |  |  | $ | 1,000 |  |  |  | 0.51% |  |
| Floating-rate notes due 2017 |  |  | 1,000 |  |  |  | 0.29% |  |  |  | 0 |  |  |  | 0 |  |
| Floating-rate notes due 2018 |  |  | 2,000 |  |  |  | 1.10% |  |  |  | 2,000 |  |  |  | 1.10% |  |
| Floating-rate notes due 2019 |  |  | 1,000 |  |  |  | 0.52% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 0.45% notes due 2016 |  |  | 1,500 |  |  |  | 0.51% |  |  |  | 1,500 |  |  |  | 0.51% |  |
| Fixed-rate 1.05% notes due 2017 |  |  | 1,500 |  |  |  | 0.29% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 1.00% notes due 2018 |  |  | 4,000 |  |  |  | 1.08% |  |  |  | 4,000 |  |  |  | 1.08% |  |
| Fixed-rate 2.10% notes due 2019 |  |  | 2,000 |  |  |  | 0.52% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.85% notes due 2021 |  |  | 3,000 |  |  |  | 0.77% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.40% notes due 2023 |  |  | 5,500 |  |  |  | 2.44% |  |  |  | 5,500 |  |  |  | 2.44% |  |
| Fixed-rate 3.45% notes due 2024 |  |  | 2,500 |  |  |  | 0.88% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 3.85% notes due 2043 |  |  | 3,000 |  |  |  | 3.91% |  |  |  | 3,000 |  |  |  | 3.91% |  |
| Fixed-rate 4.45% notes due 2044 |  |  | 1,000 |  |  |  | 4.48% |  |  |  | 0 |  |  |  | 0 |  |
| Total |  |  | 29,000 |  |  |  |  |  |  |  | 17,000 |  |  |  |  |  |
| Unamortized discount |  |  | (53 | ) |  |  |  |  |  |  | (40 | ) |  |  |  |  |
| Hedge accounting fair value adjustments |  |  | 83 |  |  |  |  |  |  |  | 0 |  |  |  |  |  |
| Total |  | $ | 29,030 |  |  |  |  |  |  | $ | 16,960 |  |  |  |  |  |

- added (2014-07-23):
[0001193125-14-277160:note_history:22]
The Company has
 entered, and may enter in the future, into interest rate swaps to
 manage interest rate risk on the Notes. Such swaps allow the
 Company to effectively convert fixed-rate payments to floating-rate
 or floating-rate payments into fixed-rate payments. In the third
 quarter of 2013, the Company entered into interest rate
 swaps with an aggregate $3.0 billion notional, which
 effectively converted the floating-rate notes due 2016 and 2018 to
 a fixed interest rate. In the third quarter of 2014, the Company
 entered into interest rate swaps with an aggregate $9.0 billion
 notional, which effectively converted the fixed-rate notes due
 2017, 2019, 2021 and 2024 to a floating interest rate.

- added (2014-07-23):
[0001193125-14-277160:note_history:23]
The effective
 rates for the Notes include the interest on the Notes, amortization
 of the discount and, if applicable, adjustments related to hedging.
 The Company recognized $100 million and $268 million of interest
 expense on its long-term debt for the three- and nine-month periods
 ended June 28, 2014, respectively.

- added (2014-07-23):
[0001193125-14-277160:note_history:24]
Future principal payments
 for the Company’s Notes as of June 28, 2014, are as
 follows (in millions):

- added (2014-07-23):
[0001193125-14-277160:note_history:25]
| 2014 |  | $ | 0 |  |
| 2015 |  |  | 0 |  |
| 2016 |  |  | 2,500 |  |
| 2017 |  |  | 2,500 |  |
| 2018 |  |  | 6,000 |  |
| Thereafter |  |  | 18,000 |  |
| Total |  | $ | 29,000 |  |

- added (2014-07-23):
[0001193125-14-277160:note_history:26]
As of
 June 28, 2014 and September 28, 2013, the fair value of
 the Company’s Notes, based on Level 2 inputs, was $28.5
 billion and $15.9 billion, respectively.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2014-07-23):
[0001193125-14-157311:note_history:27]
Note 6 – Long-Term
 Debt

- removed (2014-07-23):
[0001193125-14-157311:note_history:28]
In May 2013,
 the Company issued floating- and fixed-rate notes with varying
 maturities for an aggregate principal amount of $17.0 billion
 (collectively the “Notes”). The Notes are senior
 unsecured obligations, and interest is payable in arrears,
 quarterly for the floating-rate notes and semi-annually for the
 fixed-rate notes.

- removed (2014-07-23):
[0001193125-14-157311:note_history:29]
The principal amounts and
 associated effective interest rates of the Notes as of
 March 29, 2014, are as follows:

- removed (2014-07-23):
[0001193125-14-157311:note_history:30]
|  |  | Amount (in millions) |  |  | Effective Interest Rate |  |
| Floating-rate notes, due 2016 |  | $ | 1,000 |  |  |  | 0.51 | % |
| Floating-rate notes, due 2018 |  |  | 2,000 |  |  |  | 1.10 | % |
| Fixed-rate 0.45% notes due 2016 |  |  | 1,500 |  |  |  | 0.51 | % |
| Fixed-rate 1.00% notes due 2018 |  |  | 4,000 |  |  |  | 1.08 | % |
| Fixed-rate 2.40% notes due 2023 |  |  | 5,500 |  |  |  | 2.44 | % |
| Fixed-rate 3.85% notes due 2043 |  |  | 3,000 |  |  |  | 3.91 | % |
| Total |  | $ | 17,000 |  |  |  |  |  |

- removed (2014-07-23):
[0001193125-14-157311:note_history:31]
The
 floating-rate notes due 2016 and 2018 bear interest at the
 three-month London InterBank Offered Rate (“LIBOR”)
 plus 0.05% and 0.25%, respectively. To manage the risk of
 fluctuations in interest rates associated with the floating-rate
 notes, the Company entered into interest rate swaps with an
 aggregate notional amount of $3.0 billion designated as cash flow
 hedges of its floating-rate notes. These hedges effectively convert
 the floating interest rate on the floating-rate notes to a fixed
 interest rate. The gains and losses related to changes in the fair
 value of the interest rate swaps are recorded in OCI with a portion
 reclassified to interest expense each period to offset changes in
 interest rates on the floating-rate notes. The effective rates for
 the Notes include the interest on the Notes, amortization of the
 discount and, if applicable, adjustments related to hedging. The
 Company recognized $84 million and $168 million of interest expense
 on its long-term debt for the three- and six-month periods ended
 March 29, 2014, respectively. As of March 29, 2014, the
 aggregate unamortized discount for the Company’s Notes was
 $38 million.

- removed (2014-07-23):
[0001193125-14-157311:note_history:32]
Future
 principal payments for the Company’s Notes as of
 March 29, 2014, are as follows (in millions):

- removed (2014-07-23):
[0001193125-14-157311:note_history:33]
| 2014 |  | $ | 0 |  |
| 2015 |  |  | 0 |  |
| 2016 |  |  | 2,500 |  |
| 2017 |  |  | 0 |  |
| 2018 |  |  | 6,000 |  |
| Thereafter |  |  | 8,500 |  |
| Total |  | $ | 17,000 |  |

- removed (2014-07-23):
[0001193125-14-157311:note_history:34]
As of
 March 29, 2014, the fair value of the Company’s Notes,
 based on Level 2 inputs, was $16.2 billion.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2014-07-23):
[0001193125-14-277160:note_history:35]
The following table
 provides a summary of the Company’s long-term debt as of
 June 28, 2014 and September 28, 2013:

- added (2014-07-23):
[0001193125-14-277160:note_history:36]
|  |  | As of June 28, 2014 |  |  | As of September 28, 2013 |  |
|  |  | Amount (in millions) |  |  | Effective Interest Rate |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |
| Floating-rate notes due 2016 |  | $ | 1,000 |  |  |  | 0.51% |  |  | $ | 1,000 |  |  |  | 0.51% |  |
| Floating-rate notes due 2017 |  |  | 1,000 |  |  |  | 0.29% |  |  |  | 0 |  |  |  | 0 |  |
| Floating-rate notes due 2018 |  |  | 2,000 |  |  |  | 1.10% |  |  |  | 2,000 |  |  |  | 1.10% |  |
| Floating-rate notes due 2019 |  |  | 1,000 |  |  |  | 0.52% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 0.45% notes due 2016 |  |  | 1,500 |  |  |  | 0.51% |  |  |  | 1,500 |  |  |  | 0.51% |  |
| Fixed-rate 1.05% notes due 2017 |  |  | 1,500 |  |  |  | 0.29% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 1.00% notes due 2018 |  |  | 4,000 |  |  |  | 1.08% |  |  |  | 4,000 |  |  |  | 1.08% |  |
| Fixed-rate 2.10% notes due 2019 |  |  | 2,000 |  |  |  | 0.52% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.85% notes due 2021 |  |  | 3,000 |  |  |  | 0.77% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.40% notes due 2023 |  |  | 5,500 |  |  |  | 2.44% |  |  |  | 5,500 |  |  |  | 2.44% |  |
| Fixed-rate 3.45% notes due 2024 |  |  | 2,500 |  |  |  | 0.88% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 3.85% notes due 2043 |  |  | 3,000 |  |  |  | 3.91% |  |  |  | 3,000 |  |  |  | 3.91% |  |
| Fixed-rate 4.45% notes due 2044 |  |  | 1,000 |  |  |  | 4.48% |  |  |  | 0 |  |  |  | 0 |  |
| Total |  |  | 29,000 |  |  |  |  |  |  |  | 17,000 |  |  |  |  |  |
| Unamortized discount |  |  | (53 | ) |  |  |  |  |  |  | (40 | ) |  |  |  |  |
| Hedge accounting fair value adjustments |  |  | 83 |  |  |  |  |  |  |  | 0 |  |  |  |  |  |
| Total |  | $ | 29,030 |  |  |  |  |  |  | $ | 16,960 |  |  |  |  |  |

- removed (2014-07-23):
[0001193125-14-157311:note_history:37]
The principal amounts and
 associated effective interest rates of the Notes as of
 March 29, 2014, are as follows:

- removed (2014-07-23):
[0001193125-14-157311:note_history:38]
|  |  | Amount (in millions) |  |  | Effective Interest Rate |  |
| Floating-rate notes, due 2016 |  | $ | 1,000 |  |  |  | 0.51 | % |
| Floating-rate notes, due 2018 |  |  | 2,000 |  |  |  | 1.10 | % |
| Fixed-rate 0.45% notes due 2016 |  |  | 1,500 |  |  |  | 0.51 | % |
| Fixed-rate 1.00% notes due 2018 |  |  | 4,000 |  |  |  | 1.08 | % |
| Fixed-rate 2.40% notes due 2023 |  |  | 5,500 |  |  |  | 2.44 | % |
| Fixed-rate 3.85% notes due 2043 |  |  | 3,000 |  |  |  | 3.91 | % |
| Total |  | $ | 17,000 |  |  |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-07-23):
[0001193125-14-277160:note_history:39]
Future principal payments
 for the Company’s Notes as of June 28, 2014, are as
 follows (in millions):
  (was, 2014-04-24, similarity 0.9524):
[0001193125-14-157311:note_history:39]
Future
 principal payments for the Company’s Notes as of
 March 29, 2014, are as follows (in millions):
