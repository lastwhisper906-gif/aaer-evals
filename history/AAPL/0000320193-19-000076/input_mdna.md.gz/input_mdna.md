# AAPL MD&A — 0000320193-19-000076


## mdna

[0000320193-19-000076:mdna:1]
[same as prior period, unchanged from 0000320193-19-000066:mdna:1]

[0000320193-19-000076:mdna:2]
[same as prior period, unchanged from 0000320193-19-000066:mdna:2]

[0000320193-19-000076:mdna:3]
[same as prior period, unchanged from 0000320193-19-000066:mdna:3]

[0000320193-19-000076:mdna:4]
[same as prior period, unchanged from 0000320193-19-000066:mdna:4]

[0000320193-19-000076:mdna:5]
[same as prior period, unchanged from 0000320193-19-000066:mdna:5]

[0000320193-19-000076:mdna:6]
[same as prior period, unchanged from 0000320193-19-000066:mdna:6]

[0000320193-19-000076:mdna:7]
Third Quarter Fiscal 2019 Highlights

[0000320193-19-000076:mdna:8]
Total net sales increased 1% or $544 million during the third quarter of 2019 compared to the same quarter in 2018, primarily driven by higher Wearables, Home and Accessories and Services net sales, partially offset by lower iPhone net sales. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on net sales during the third quarter of 2019.

[0000320193-19-000076:mdna:9]
The Company announced iOS 13, macOS® Catalina, watchOS® 6 and tvOS® 13, updates to its existing operating systems, and introduced iPadOS™, a new operating system designed for iPad, all of which are expected to be available in the fall of 2019. The Company also introduced an updated Mac Pro® and an all-new Pro Display XDR, both of which are expected to be available in the fall of 2019.

[0000320193-19-000076:mdna:10]
The Company repurchased $17.0 billion of its common stock and paid dividends and dividend equivalents of $3.6 billion during the third quarter of 2019.

[0000320193-19-000076:mdna:11]
[same as prior period, unchanged from 0000320193-19-000066:mdna:20]

[0000320193-19-000076:mdna:12]
Beginning in the first quarter of 2019, the Company classified the amortization of the deferred value of Maps, Siri and free iCloud services, which are bundled in the sales price of iPhone, Mac, iPad and certain other products, in services net sales. Historically, the Company classified the amortization of these amounts in products net sales consistent with its management reporting framework. As a result, products and services net sales information for the third quarter and first nine months of 2018 was reclassified to conform to the 2019 presentation.

[0000320193-19-000076:mdna:13]
The following table shows net sales by category for the three- and nine-month periods ended June 29, 2019 and June 30, 2018 (dollars in millions):

[0000320193-19-000076:mdna:14]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | Change |  | June 29, 2019 |  | June 30, 2018 |  | Change |
| Net sales by category: |  |  |  |  |  |  |  |  |  |  |  |
| iPhone (1) | $ | 25,986 |  |  | $ | 29,470 |  |  | (12 | )% |  | $ | 109,019 |  |  | $ | 128,133 |  |  | (15 | )% |
| Mac (1) | 5,820 |  |  | 5,258 |  |  | 11 | % |  | 18,749 |  |  | 17,858 |  |  | 5 | % |
| iPad (1) | 5,023 |  |  | 4,634 |  |  | 8 | % |  | 16,624 |  |  | 14,397 |  |  | 15 | % |
| Wearables, Home and Accessories (1)(2) | 5,525 |  |  | 3,733 |  |  | 48 | % |  | 17,962 |  |  | 13,158 |  |  | 37 | % |
| Services (3) | 11,455 |  |  | 10,170 |  |  | 13 | % |  | 33,780 |  |  | 29,149 |  |  | 16 | % |
| Total net sales | $ | 53,809 |  |  | $ | 53,265 |  |  | 1 | % |  | $ | 196,134 |  |  | $ | 202,695 |  |  | (3 | )% |

[0000320193-19-000076:mdna:15]
[same as prior period, unchanged from 0000320193-19-000066:mdna:24]

[0000320193-19-000076:mdna:16]
[same as prior period, unchanged from 0000320193-19-000066:mdna:25]

[0000320193-19-000076:mdna:17]
[same as prior period, unchanged from 0000320193-19-000066:mdna:26]

[0000320193-19-000076:mdna:18]
[same as prior period, unchanged from 0000320193-19-000066:mdna:27]

[0000320193-19-000076:mdna:19]
iPhone net sales decreased during the third quarter and first nine months of 2019 compared to the same periods in 2018 due primarily to lower iPhone unit sales.

[0000320193-19-000076:mdna:20]
[same as prior period, unchanged from 0000320193-19-000066:mdna:29]

[0000320193-19-000076:mdna:21]
Mac net sales increased during the third quarter of 2019 compared to the same quarter in 2018 due primarily to higher net sales of MacBook Air®. Year-over-year Mac net sales increased during the first nine months of 2019 due primarily to higher net sales of MacBook Air, partially offset by lower net sales of MacBook®.

[0000320193-19-000076:mdna:22]
[same as prior period, unchanged from 0000320193-19-000066:mdna:31]

[0000320193-19-000076:mdna:23]
iPad net sales increased during the third quarter and first nine months of 2019 compared to the same periods in 2018 due primarily to higher net sales of iPad Pro®.

[0000320193-19-000076:mdna:24]
[same as prior period, unchanged from 0000320193-19-000066:mdna:33]

[0000320193-19-000076:mdna:25]
Wearables, Home and Accessories net sales increased during the third quarter and first nine months of 2019 compared to the same periods in 2018 due primarily to higher net sales of AirPods and Apple Watch.

[0000320193-19-000076:mdna:26]
[same as prior period, unchanged from 0000320193-19-000066:mdna:35]

[0000320193-19-000076:mdna:27]
Services net sales increased during the third quarter and first nine months of 2019 compared to the same periods in 2018 due primarily to the App Store, licensing and AppleCare.

[0000320193-19-000076:mdna:28]
[same as prior period, unchanged from 0000320193-19-000066:mdna:37]

[0000320193-19-000076:mdna:29]
[same as prior period, unchanged from 0000320193-19-000066:mdna:38]

[0000320193-19-000076:mdna:30]
The following table shows net sales by reportable segment for the three- and nine-month periods ended June 29, 2019 and June 30, 2018 (dollars in millions):

[0000320193-19-000076:mdna:31]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | Change |  | June 29, 2019 |  | June 30, 2018 |  | Change |
| Net sales by reportable segment: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 25,056 |  |  | $ | 24,542 |  |  | 2 | % |  | $ | 87,592 |  |  | $ | 84,576 |  |  | 4 | % |
| Europe | 11,925 |  |  | 12,138 |  |  | (2 | )% |  | 45,342 |  |  | 47,038 |  |  | (4 | )% |
| Greater China | 9,157 |  |  | 9,551 |  |  | (4 | )% |  | 32,544 |  |  | 40,531 |  |  | (20 | )% |
| Japan | 4,082 |  |  | 3,867 |  |  | 6 | % |  | 16,524 |  |  | 16,572 |  |  | — | % |
| Rest of Asia Pacific | 3,589 |  |  | 3,167 |  |  | 13 | % |  | 14,132 |  |  | 13,978 |  |  | 1 | % |
| Total net sales | $ | 53,809 |  |  | $ | 53,265 |  |  | 1 | % |  | $ | 196,134 |  |  | $ | 202,695 |  |  | (3 | )% |

[0000320193-19-000076:mdna:32]
[same as prior period, unchanged from 0000320193-19-000066:mdna:41]

[0000320193-19-000076:mdna:33]
Americas net sales increased during the third quarter and first nine months of 2019 compared to the same periods in 2018 due primarily to higher Wearables, Home and Accessories and Services net sales, partially offset by lower iPhone net sales. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on Americas net sales during the third quarter and first nine months of 2019.

[0000320193-19-000076:mdna:34]
[same as prior period, unchanged from 0000320193-19-000066:mdna:43]

[0000320193-19-000076:mdna:35]
Europe net sales decreased during the third quarter and first nine months of 2019 compared to the same periods in 2018 due primarily to lower iPhone net sales, partially offset by higher Wearables, Home and Accessories and Services net sales. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on Europe net sales during the third quarter and first nine months of 2019.

[0000320193-19-000076:mdna:36]
[same as prior period, unchanged from 0000320193-19-000066:mdna:45]

[0000320193-19-000076:mdna:37]
Greater China net sales decreased during the third quarter and first nine months of 2019 compared to the same periods in 2018 due primarily to lower iPhone net sales, partially offset by higher Wearables, Home and Accessories and Services net sales. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on Greater China net sales during the third quarter and first nine months of 2019.

[0000320193-19-000076:mdna:38]
[same as prior period, unchanged from 0000320193-19-000066:mdna:47]

[0000320193-19-000076:mdna:39]
Japan net sales increased during the third quarter of 2019 compared to the same quarter in 2018 due primarily to higher Services and Wearables, Home and Accessories net sales, partially offset by lower iPhone net sales. Year-over-year Japan net sales during the first nine months of 2019 were relatively flat as lower iPhone net sales were offset primarily by higher Services and Wearables, Home and Accessories net sales. The value of the Japanese Yen relative to the U.S. dollar had an unfavorable impact on Japan net sales during the third quarter and first nine months of 2019.

[0000320193-19-000076:mdna:40]
[same as prior period, unchanged from 0000320193-19-000066:mdna:49]

[0000320193-19-000076:mdna:41]
Rest of Asia Pacific net sales increased during the third quarter of 2019 compared to the same quarter in 2018 due primarily to higher Wearables, Home and Accessories, iPad and Services net sales. Year-over-year Rest of Asia Pacific net sales during the first nine months of 2019 increased due primarily to higher Wearables, Home and Accessories, iPad and Services net sales, partially offset by lower iPhone net sales. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on Rest of Asia Pacific net sales during the third quarter and first nine months of 2019.

[0000320193-19-000076:mdna:42]
[same as prior period, unchanged from 0000320193-19-000066:mdna:51]

[0000320193-19-000076:mdna:43]
Products and services gross margin and gross margin percentage for the three- and nine-month periods ended June 29, 2019 and June 30, 2018 were as follows (dollars in millions):

[0000320193-19-000076:mdna:44]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| Gross margin: |  |  |  |  |  |  |  |
| Products | $ | 12,881 |  |  | $ | 14,139 |  |  | $ | 52,596 |  |  | $ | 60,079 |  |
| Services | 7,346 |  |  | 6,282 |  |  | 21,483 |  |  | 17,676 |  |
| Total gross margin | $ | 20,227 |  |  | $ | 20,421 |  |  | $ | 74,079 |  |  | $ | 77,755 |  |
| Gross margin percentage: |  |  |  |  |  |  |  |
| Products | 30.4 | % |  | 32.8 | % |  | 32.4 | % |  | 34.6 | % |
| Services | 64.1 | % |  | 61.8 | % |  | 63.6 | % |  | 60.6 | % |
| Total gross margin percentage | 37.6 | % |  | 38.3 | % |  | 37.8 | % |  | 38.4 | % |

[0000320193-19-000076:mdna:45]
[same as prior period, unchanged from 0000320193-19-000066:mdna:54]

[0000320193-19-000076:mdna:46]
Products gross margin decreased during the third quarter of 2019 compared to the same quarter in 2018 due primarily to the weakness in foreign currencies relative to the U.S. dollar. Products gross margin decreased during the first nine months of 2019 compared to the same period in 2018 due primarily to lower iPhone unit sales and the weakness in foreign currencies relative to the U.S. dollar.

[0000320193-19-000076:mdna:47]
Year-over-year products gross margin percentage decreased during the third quarter and first nine months of 2019 due primarily to the weakness in foreign currencies relative to the U.S. dollar and the impact of lower iPhone unit sales on the Company’s products fixed cost structure.

[0000320193-19-000076:mdna:48]
[same as prior period, unchanged from 0000320193-19-000066:mdna:56]

[0000320193-19-000076:mdna:49]
Services gross margin increased during the third quarter and first nine months of 2019 compared to the same periods in 2018 due primarily to higher services net sales. Year-over-year services gross margin percentage increased during the third quarter and first nine months of 2019 due primarily to leverage of the Company’s services fixed cost structure from higher services net sales and a different services mix.

[0000320193-19-000076:mdna:50]
The Company anticipates total gross margin percentage during the fourth quarter of 2019 to be between 37.5% and 38.5%. The foregoing statement regarding the Company’s expected total gross margin percentage in the fourth quarter of 2019 is forward-looking and could differ from actual results. The Company’s future gross margins can be impacted by multiple factors including, but not limited to, those set forth in Part II, Item 1A of this Form 10-Q under the heading “Risk Factors” and those described in this paragraph. In general, the Company believes gross margins will be subject to volatility and remain under downward pressure due to a variety of factors, including: continued industry-wide global product pricing pressures and product pricing actions that the Company may take in response to such pressures; increased competition; the Company’s ability to effectively stimulate demand for certain of its products and services; compressed product life cycles; potential increases in the cost of components, outside manufacturing services, and acquiring and delivering content for the Company’s services; the Company’s ability to manage product quality and warranty costs effectively; shifts in the mix of products and services, or in the geographic, currency or channel mix; fluctuations in foreign exchange rates; and costs associated with the Company’s frequent introductions and transitions of products and services.

[0000320193-19-000076:mdna:51]
[same as prior period, unchanged from 0000320193-19-000066:mdna:59]

[0000320193-19-000076:mdna:52]
Operating expenses for the three- and nine-month periods ended June 29, 2019 and June 30, 2018 were as follows (dollars in millions):

[0000320193-19-000076:mdna:53]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| Research and development | $ | 4,257 |  |  | $ | 3,701 |  |  | $ | 12,107 |  |  | $ | 10,486 |  |
| Percentage of total net sales | 8 | % |  | 7 | % |  | 6 | % |  | 5 | % |
| Selling, general and administrative | $ | 4,426 |  |  | $ | 4,108 |  |  | $ | 13,667 |  |  | $ | 12,489 |  |
| Percentage of total net sales | 8 | % |  | 8 | % |  | 7 | % |  | 6 | % |
| Total operating expenses | $ | 8,683 |  |  | $ | 7,809 |  |  | $ | 25,774 |  |  | $ | 22,975 |  |
| Percentage of total net sales | 16 | % |  | 15 | % |  | 13 | % |  | 11 | % |

[0000320193-19-000076:mdna:54]
[same as prior period, unchanged from 0000320193-19-000066:mdna:62]

[0000320193-19-000076:mdna:55]
The growth in research and development (“R&D”) expense during the third quarter of 2019 and first nine months of 2019 compared to the same periods in 2018 was driven primarily by increases in headcount-related expenses. The Company continues to believe that focused investments in R&D are critical to its future growth and competitive position in the marketplace, and to the development of new and updated products and services that are central to the Company’s core business strategy.

[0000320193-19-000076:mdna:56]
[same as prior period, unchanged from 0000320193-19-000066:mdna:64]

[0000320193-19-000076:mdna:57]
The growth in selling, general and administrative expense during the third quarter of 2019 compared to the same quarter in 2018 was driven primarily by higher spending on marketing and advertising and an increase in headcount-related expenses. The year-over-year growth in selling, general and administrative expense during the first nine months of 2019 was driven primarily by an increase in headcount-related expenses and higher spending on marketing and advertising and infrastructure-related costs.

[0000320193-19-000076:mdna:58]
[same as prior period, unchanged from 0000320193-19-000066:mdna:66]

[0000320193-19-000076:mdna:59]
Other income/(expense), net for the three- and nine-month periods ended June 29, 2019 and June 30, 2018 was as follows (dollars in millions):

[0000320193-19-000076:mdna:60]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | Change |  | June 29, 2019 |  | June 30, 2018 |  | Change |
| Interest and dividend income | $ | 1,190 |  |  | $ | 1,418 |  |  |  |  | $ | 3,855 |  |  | $ | 4,375 |  |  |  |
| Interest expense | (866 | ) |  | (846 | ) |  |  |  | (2,766 | ) |  | (2,372 | ) |  |  |
| Other income/(expense), net | 43 |  |  | 100 |  |  |  |  | 216 |  |  | (301 | ) |  |  |
| Total other income/(expense), net | $ | 367 |  |  | $ | 672 |  |  | (45 | )% |  | $ | 1,305 |  |  | $ | 1,702 |  |  | (23 | )% |

[0000320193-19-000076:mdna:61]
The decrease in other income/(expense), net during the third quarter of 2019 compared to the same quarter in 2018 was due to lower interest income and the impact of foreign exchange–related items. The year-over-year decrease in other income/(expense), net during the first nine months of 2019 was due primarily to lower interest income and higher interest expense, partially offset by the impact of foreign exchange–related items. The weighted-average interest rate earned by the Company on its cash, cash equivalents and marketable securities was 2.17% and 2.25% in the third quarters of 2019 and 2018, respectively, and 2.21% and 2.16% in the first nine months of 2019 and 2018, respectively.

[0000320193-19-000076:mdna:62]
[same as prior period, unchanged from 0000320193-19-000066:mdna:70]

[0000320193-19-000076:mdna:63]
Provision for income taxes, effective tax rate and statutory federal income tax rate for the three- and nine-month periods ended June 29, 2019 and June 30, 2018 were as follows (dollars in millions):

[0000320193-19-000076:mdna:64]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| Provision for income taxes | $ | 1,867 |  |  | $ | 1,765 |  |  | $ | 8,040 |  |  | $ | 11,076 |  |
| Effective tax rate | 15.7 | % |  | 13.3 | % |  | 16.2 | % |  | 19.6 | % |
| Statutory federal income tax rate | 21.0 | % |  | 24.5 | % |  | 21.0 | % |  | 24.5 | % |

[0000320193-19-000076:mdna:65]
The Company’s effective tax rate for the third quarter and first nine months of 2019 was lower than the statutory federal income tax rate due primarily to the lower tax rate on foreign earnings and tax benefits from share-based compensation.

[0000320193-19-000076:mdna:66]
The Company’s effective tax rate for the third quarter of 2019 was higher compared to the same quarter in 2018 due primarily to higher taxes on foreign earnings, partially offset by a lower statutory federal income tax rate in 2019. The Company’s effective tax rate for the first nine months of 2019 was lower compared to the same period in 2018 due primarily to a lower statutory federal income tax rate in 2019.

[0000320193-19-000076:mdna:67]
[same as prior period, unchanged from 0000320193-19-000066:mdna:75]

[0000320193-19-000076:mdna:68]
[same as prior period, unchanged from 0000320193-19-000066:mdna:76]

[0000320193-19-000076:mdna:69]
In August 2017, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) No. 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities (“ASU 2017-12”). ASU 2017-12 expands component and fair value hedging, specifies the presentation of the effects of hedging instruments, and eliminates the separate measurement and presentation of hedge ineffectiveness. The Company will adopt ASU 2017-12 in its first quarter of 2020 utilizing the modified retrospective transition method. Based on the Company’s derivative portfolio and hedging strategies, the adoption of ASU 2017-12 is not expected to have a material impact on its consolidated financial statements.

[0000320193-19-000076:mdna:70]
[same as prior period, unchanged from 0000320193-19-000066:mdna:78]

[0000320193-19-000076:mdna:71]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (“ASU 2016-13”), which modifies the measurement of expected credit losses on certain financial instruments. The Company will adopt ASU 2016-13 in its first quarter of 2021 utilizing the modified retrospective transition method. Based on the composition of the Company’s investment portfolio, current market conditions, and historical credit loss activity, the adoption of ASU 2016-13 is not expected to have a material impact on its consolidated financial statements.

[0000320193-19-000076:mdna:72]
[same as prior period, unchanged from 0000320193-19-000066:mdna:80]

[0000320193-19-000076:mdna:73]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842) (“ASU 2016-02”), which modifies lease accounting for lessees to increase transparency and comparability by recording lease assets and liabilities for operating leases and disclosing key information about leasing arrangements. The Company will adopt ASU 2016-02 utilizing the modified retrospective transition method through a cumulative-effect adjustment at the beginning of its first quarter of 2020. While the Company is currently evaluating the impact of adopting ASU 2016-02, based on the lease portfolio as of June 29, 2019, the Company anticipates recording lease assets and liabilities of approximately $9 billion on its Condensed Consolidated Balance Sheets, with no material impact to its Condensed Consolidated Statements of Operations. However, the ultimate impact of adopting ASU 2016-02 will depend on the Company’s lease portfolio as of the adoption date.

[0000320193-19-000076:mdna:74]
[same as prior period, unchanged from 0000320193-19-000066:mdna:82]

[0000320193-19-000076:mdna:75]
The following tables present selected financial information and statistics as of June 29, 2019 and September 29, 2018 and for the first nine months of 2019 and 2018 (in millions):

[0000320193-19-000076:mdna:76]
|  | June 29, 2019 |  | September 29, 2018 |
| Cash, cash equivalents and marketable securities (1) | $ | 210,610 |  |  | $ | 237,100 |  |
| Property, plant and equipment, net | $ | 37,636 |  |  | $ | 41,304 |  |
| Commercial paper | $ | 9,953 |  |  | $ | 11,964 |  |
| Total term debt | $ | 98,465 |  |  | $ | 102,519 |  |
| Working capital | $ | 45,269 |  |  | $ | 15,410 |  |

[0000320193-19-000076:mdna:77]
|  | Nine Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |
| Cash generated by operating activities | $ | 49,481 |  |  | $ | 57,911 |  |
| Cash generated by investing activities | $ | 46,694 |  |  | $ | 19,067 |  |
| Cash used in financing activities | $ | (69,937 | ) |  | $ | (65,296 | ) |

[0000320193-19-000076:mdna:78]
| (1) | As of June 29, 2019 and September 29, 2018, total cash, cash equivalents and marketable securities included $19.5 billion and $20.3 billion, respectively, that was restricted from general use, related to the State Aid Decision (refer to Note 5, “Income Taxes” in the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Form 10-Q) and other agreements. |

[0000320193-19-000076:mdna:79]
[same as prior period, unchanged from 0000320193-19-000066:mdna:87]

[0000320193-19-000076:mdna:80]
In connection with the State Aid Decision, as of June 29, 2019, the entire recovery amount of €13.1 billion plus interest of €1.2 billion was funded into escrow, where it will remain restricted from general use pending conclusion of all appeals.

[0000320193-19-000076:mdna:81]
[same as prior period, unchanged from 0000320193-19-000066:mdna:89]

[0000320193-19-000076:mdna:82]
During the nine months ended June 29, 2019, cash generated by operating activities of $49.5 billion was a result of $41.6 billion of net income and non-cash adjustments to net income of $13.6 billion, partially offset by a decrease in the net change in operating assets and liabilities of $5.6 billion. Cash generated by investing activities of $46.7 billion during the nine months ended June 29, 2019 consisted primarily of proceeds from sales and maturities of marketable securities, net of purchases, of $54.4 billion, partially offset by cash used to acquire property, plant and equipment of $7.7 billion. Cash used in financing activities of $69.9 billion during the nine months ended June 29, 2019 consisted primarily of cash used to repurchase common stock of $49.5 billion, cash used to pay dividends and dividend equivalents of $10.6 billion and cash used to repay term debt of $5.5 billion.

[0000320193-19-000076:mdna:83]
During the nine months ended June 30, 2018, cash generated by operating activities of $57.9 billion was a result of $45.4 billion of net income and an increase in the net change in operating assets and liabilities of $33.9 billion, partially offset by non-cash adjustments to net income of $21.4 billion. Cash generated by investing activities of $19.1 billion during the nine months ended June 30, 2018 consisted primarily of proceeds from maturities and sales of marketable securities, net of purchases, of $31.8 billion, partially offset by cash used to acquire property, plant and equipment of $10.3 billion. Cash used in financing activities of $65.3 billion during the nine months ended June 30, 2018 consisted primarily of cash used to repurchase common stock of $53.6 billion, cash used to pay dividends and dividend equivalents of $10.2 billion and cash used to repay term debt of $6.5 billion, partially offset by net proceeds from the issuance of term debt of $7.0 billion.

[0000320193-19-000076:mdna:84]
[same as prior period, unchanged from 0000320193-19-000066:mdna:92]

[0000320193-19-000076:mdna:85]
The Company’s capital expenditures were $4.9 billion during the first nine months of 2019. The Company anticipates utilizing approximately $10.0 billion for capital expenditures during 2019, which includes product tooling and manufacturing process equipment; data centers; corporate facilities and infrastructure, including information systems hardware, software and enhancements; and retail store facilities.

[0000320193-19-000076:mdna:86]
[same as prior period, unchanged from 0000320193-19-000066:mdna:94]

[0000320193-19-000076:mdna:87]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses the net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of June 29, 2019, the Company had $10.0 billion of Commercial Paper outstanding, with a weighted-average interest rate of 2.49% and maturities generally less than nine months.

[0000320193-19-000076:mdna:88]
As of June 29, 2019, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $98.3 billion (collectively the “Notes”). During the first nine months of 2019, the Company repaid $5.5 billion of its Notes upon maturity. The Company has entered, and in the future may enter, into interest rate swaps to manage interest rate risk on the Notes. In addition, the Company has entered, and in the future may enter, into foreign currency swaps to manage foreign currency risk on the Notes.

[0000320193-19-000076:mdna:89]
[same as prior period, unchanged from 0000320193-19-000066:mdna:97]

[0000320193-19-000076:mdna:90]
[same as prior period, unchanged from 0000320193-19-000066:mdna:98]

[0000320193-19-000076:mdna:91]
On April 30, 2019, the Company announced the Board of Directors increased the current share repurchase program authorization from $100 billion to $175 billion of the Company’s common stock, of which $78.2 billion had been utilized as of June 29, 2019. During the nine months ended June 29, 2019, the Company repurchased 252.6 million shares of its common stock for $49.2 billion, including 55.1 million shares initially delivered under a $12.0 billion accelerated share repurchase arrangement (“ASR”) dated February 2019. The Company’s share repurchase program does not obligate it to acquire any specific number of shares. Under this program, shares may be repurchased in privately negotiated and/or open market transactions, including under plans complying with Rule 10b5-1 under the Exchange Act.

[0000320193-19-000076:mdna:92]
On April 30, 2019, the Company also announced the Board of Directors raised the Company’s quarterly cash dividend from $0.73 to $0.77 per share, beginning with the dividend paid during the third quarter of 2019. The Company intends to increase its dividend on an annual basis, subject to declaration by the Board of Directors.

[0000320193-19-000076:mdna:93]
[same as prior period, unchanged from 0000320193-19-000066:mdna:101]

[0000320193-19-000076:mdna:94]
[same as prior period, unchanged from 0000320193-19-000066:mdna:102]

[0000320193-19-000076:mdna:95]
As of June 29, 2019, the Company’s total future minimum lease payments under noncancelable operating leases were $11.1 billion. The Company’s retail store and other facility leases typically have original terms not exceeding 10 years and generally contain multi-year renewal options.

[0000320193-19-000076:mdna:96]
[same as prior period, unchanged from 0000320193-19-000066:mdna:104]

[0000320193-19-000076:mdna:97]
The Company utilizes several outsourcing partners to manufacture sub-assemblies for the Company’s products and to perform final assembly and testing of finished products. These outsourcing partners acquire components and build product based on demand information supplied by the Company, which typically covers periods up to 150 days. The Company also obtains individual components for its products from a wide variety of individual suppliers. As of June 29, 2019, the Company expects to pay $29.8 billion under manufacturing-related supplier arrangements, which are primarily noncancelable.

[0000320193-19-000076:mdna:98]
[same as prior period, unchanged from 0000320193-19-000066:mdna:106]

[0000320193-19-000076:mdna:99]
The Company’s other purchase obligations consist of noncancelable obligations to acquire capital assets, including product tooling and manufacturing process equipment, and noncancelable obligations related to advertising, licensing, R&D, internet and telecommunications services, content creation and other activities. As of June 29, 2019, the Company had other purchase obligations of $6.3 billion.

[0000320193-19-000076:mdna:100]
[same as prior period, unchanged from 0000320193-19-000066:mdna:108]

[0000320193-19-000076:mdna:101]
As of June 29, 2019, a significant portion of the other non-current liabilities in the Company’s Condensed Consolidated Balance Sheet consisted of the $30.5 billion deemed repatriation tax payable imposed by the U.S. Tax Cuts and Jobs Act (the “Act”). The Company plans to pay the deemed repatriation tax payable in installments in accordance with the Act. The Company’s remaining other non-current liabilities primarily consist of items for which the Company is unable to make a reasonably reliable estimate of the timing of payments.

[0000320193-19-000076:mdna:102]
[same as prior period, unchanged from 0000320193-19-000066:mdna:110]

[0000320193-19-000076:mdna:103]
Agreements entered into by the Company may include indemnification provisions, which may subject the Company to costs and damages in the event of a claim against an indemnified third party. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to indemnification of third parties.

[0000320193-19-000076:mdna:104]
[same as prior period, unchanged from 0000320193-19-000066:mdna:112]

[0000320193-19-000076:mdna:105]
The Company has entered into indemnification agreements with its directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers of the Company, and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. While the Company maintains directors and officers liability insurance coverage, such insurance coverage may be insufficient to cover all losses or all types of claims that may arise.

[0000320193-19-000076:mdna:106]
[same as prior period, unchanged from 0000320193-19-000066:mdna:114]

[0000320193-19-000076:mdna:107]
[same as prior period, unchanged from 0000320193-19-000066:mdna:115]

[0000320193-19-000076:mdna:108]
[same as prior period, unchanged from 0000320193-19-000066:mdna:116]

[0000320193-19-000076:mdna:109]
[same as prior period, unchanged from 0000320193-19-000066:mdna:117]

[0000320193-19-000076:mdna:110]
[same as prior period, unchanged from 0000320193-19-000066:mdna:118]

[0000320193-19-000076:mdna:111]
[same as prior period, unchanged from 0000320193-19-000066:mdna:119]

[0000320193-19-000076:mdna:112]
[same as prior period, unchanged from 0000320193-19-000066:mdna:120]

[0000320193-19-000076:mdna:113]
[same as prior period, unchanged from 0000320193-19-000066:mdna:121]
