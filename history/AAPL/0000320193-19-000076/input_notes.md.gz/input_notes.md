# AAPL notes — 0000320193-19-000076


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000320193-19-000076:notes:1]
[same as prior period, unchanged from 0000320193-19-000066:notes:1]

[0000320193-19-000076:notes:2]
[same as prior period, unchanged from 0000320193-19-000066:notes:2]

[0000320193-19-000076:notes:3]
[same as prior period, unchanged from 0000320193-19-000066:notes:3]

[0000320193-19-000076:notes:4]
Recently Adopted Accounting Pronouncements

[0000320193-19-000076:notes:5]
[same as prior period, unchanged from 0000320193-19-000066:notes:5]

[0000320193-19-000076:notes:6]
In the first quarter of 2019, the Company adopted the Financial Accounting Standards Board’s (the “FASB”) Accounting Standards Update (“ASU”) No. 2014-09, Revenue from Contracts with Customers (Topic 606) (“ASU 2014-09”), and additional ASUs issued to clarify the guidance in ASU 2014-09 (collectively the “new revenue standard”), which amends the existing accounting standards for revenue recognition. The Company adopted the new revenue standard utilizing the full retrospective transition method. The Company did not restate total net sales in the prior periods presented, as adoption of the new revenue standard did not have a material impact on previously reported amounts.

[0000320193-19-000076:notes:7]
Additionally, beginning in the first quarter of 2019, the Company classified the amortization of the deferred value of Maps, Siri® and free iCloud® services, which are bundled in the sales price of iPhone®, Mac®, iPad® and certain other products, in services net sales. Historically, the Company classified the amortization of these amounts in products net sales consistent with its management reporting framework. As a result, products and services net sales information for the third quarter and first nine months of 2018 was reclassified to conform to the 2019 presentation.

[0000320193-19-000076:notes:8]
[same as prior period, unchanged from 0000320193-19-000066:notes:8]

[0000320193-19-000076:notes:9]
In the first quarter of 2019, the Company adopted FASB ASU No. 2016-01, Financial Instruments – Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities (“ASU 2016-01”), which updates certain aspects of the recognition, measurement, presentation and disclosure of financial instruments. The adoption of ASU 2016-01 did not have a material impact on the Company’s condensed consolidated financial statements.

[0000320193-19-000076:notes:10]
[same as prior period, unchanged from 0000320193-19-000066:notes:10]

[0000320193-19-000076:notes:11]
In the first quarter of 2019, the Company adopted FASB ASU No. 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory (“ASU 2016-16”), which requires the recognition of the income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. The Company adopted ASU 2016-16 utilizing the modified retrospective transition method. Upon adoption, the Company recorded $2.7 billion of net deferred tax assets, reduced other non-current assets by $128 million, and increased retained earnings by $2.6 billion on its Condensed Consolidated Balance Sheet. The Company will recognize incremental deferred income tax expense as these net deferred tax assets are utilized.

[0000320193-19-000076:notes:12]
[same as prior period, unchanged from 0000320193-19-000066:notes:12]

[0000320193-19-000076:notes:13]
In the first quarter of 2019, the Company adopted FASB ASU No. 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash (“ASU 2016-18”), which enhances and clarifies the guidance on the classification and presentation of restricted cash in the statement of cash flows and requires additional disclosures about restricted cash balances.

[0000320193-19-000076:notes:14]
[same as prior period, unchanged from 0000320193-19-000066:notes:14]

[0000320193-19-000076:notes:15]
The following table shows the computation of basic and diluted earnings per share for the three- and nine-month periods ended June 29, 2019 and June 30, 2018 (net income in millions and shares in thousands):

[0000320193-19-000076:notes:16]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 10,044 |  |  | $ | 11,519 |  |  | $ | 41,570 |  |  | $ | 45,406 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 4,570,633 |  |  | 4,882,167 |  |  | 4,660,175 |  |  | 5,006,640 |  |
| Effect of dilutive securities | 30,747 |  |  | 44,442 |  |  | 31,584 |  |  | 44,323 |  |
| Weighted-average diluted shares | 4,601,380 |  |  | 4,926,609 |  |  | 4,691,759 |  |  | 5,050,963 |  |
| Basic earnings per share | $ | 2.20 |  |  | $ | 2.36 |  |  | $ | 8.92 |  |  | $ | 9.07 |  |
| Diluted earnings per share | $ | 2.18 |  |  | $ | 2.34 |  |  | $ | 8.86 |  |  | $ | 8.99 |  |

[0000320193-19-000076:notes:17]
Potentially dilutive securities representing 1.5 million and 20.5 million shares of common stock were excluded from the computation of diluted earnings per share for the three- and nine-month periods ended June 29, 2019, respectively, because their effect would have been antidilutive.

[0000320193-19-000076:notes:18]
Restricted Cash and Restricted Marketable Securities

[0000320193-19-000076:notes:19]
The Company considers cash and marketable securities to be restricted when withdrawal or general use is legally restricted. The Company records restricted cash as other assets in the Condensed Consolidated Balance Sheets, and determines current or non-current classification based on the expected duration of the restriction. The Company records restricted marketable securities as current or non-current marketable securities in the Condensed Consolidated Balance Sheets based on the classification of the underlying securities.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000320193-19-000076:notes:20]
[same as prior period, unchanged from 0000320193-19-000066:notes:19]

[0000320193-19-000076:notes:21]
[same as prior period, unchanged from 0000320193-19-000066:notes:20]

[0000320193-19-000076:notes:22]
[same as prior period, unchanged from 0000320193-19-000066:notes:21]

[0000320193-19-000076:notes:23]
[same as prior period, unchanged from 0000320193-19-000066:notes:22]

[0000320193-19-000076:notes:24]
[same as prior period, unchanged from 0000320193-19-000066:notes:23]

[0000320193-19-000076:notes:25]
[same as prior period, unchanged from 0000320193-19-000066:notes:24]

[0000320193-19-000076:notes:26]
[same as prior period, unchanged from 0000320193-19-000066:notes:25]

[0000320193-19-000076:notes:27]
[same as prior period, unchanged from 0000320193-19-000066:notes:26]

[0000320193-19-000076:notes:28]
As of June 29, 2019 and September 29, 2018, the Company had total deferred revenue of $8.0 billion and $8.8 billion, respectively. As of June 29, 2019, the Company expects 68% of total deferred revenue to be realized in less than a year, 25% within one-to-two years, 6% within two-to-three years and 1% in greater than three years.

[0000320193-19-000076:notes:29]
[same as prior period, unchanged from 0000320193-19-000066:notes:28]

[0000320193-19-000076:notes:30]
Net sales disaggregated by significant products and services for the three- and nine-month periods ended June 29, 2019 and June 30, 2018 were as follows (in millions):

[0000320193-19-000076:notes:31]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| iPhone (1) | $ | 25,986 |  |  | $ | 29,470 |  |  | $ | 109,019 |  |  | $ | 128,133 |  |
| Mac (1) | 5,820 |  |  | 5,258 |  |  | 18,749 |  |  | 17,858 |  |
| iPad (1) | 5,023 |  |  | 4,634 |  |  | 16,624 |  |  | 14,397 |  |
| Wearables, Home and Accessories (1)(2) | 5,525 |  |  | 3,733 |  |  | 17,962 |  |  | 13,158 |  |
| Services (3) | 11,455 |  |  | 10,170 |  |  | 33,780 |  |  | 29,149 |  |
| Total net sales (4) | $ | 53,809 |  |  | $ | 53,265 |  |  | $ | 196,134 |  |  | $ | 202,695 |  |

[0000320193-19-000076:notes:32]
[same as prior period, unchanged from 0000320193-19-000066:notes:31]

[0000320193-19-000076:notes:33]
[same as prior period, unchanged from 0000320193-19-000066:notes:32]

[0000320193-19-000076:notes:34]
[same as prior period, unchanged from 0000320193-19-000066:notes:33]

[0000320193-19-000076:notes:35]
| (4) | Includes $2.0 billion of revenue recognized in the three months ended June 29, 2019 that was included in deferred revenue as of March 30, 2019, $2.0 billion of revenue recognized in the three months ended June 30, 2018 that was included in deferred revenue as of March 31, 2018, $4.9 billion of revenue recognized in the nine months ended June 29, 2019 that was included in deferred revenue as of September 29, 2018, and $4.7 billion of revenue recognized in the nine months ended June 30, 2018 that was included in deferred revenue as of September 30, 2017. |

[0000320193-19-000076:notes:36]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 11, “Segment Information and Geographic Data” for the three- and nine-month periods ended June 29, 2019 and June 30, 2018.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000320193-19-000076:notes:37]
[same as prior period, unchanged from 0000320193-19-000066:notes:36]

[0000320193-19-000076:notes:38]
[same as prior period, unchanged from 0000320193-19-000066:notes:37]

[0000320193-19-000076:notes:39]
[same as prior period, unchanged from 0000320193-19-000066:notes:38]

[0000320193-19-000076:notes:40]
The following tables show the Company’s cash and marketable securities by significant investment category as of June 29, 2019 and September 29, 2018 (in millions):

[0000320193-19-000076:notes:41]
|  | June 29, 2019 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | Short-TermMarketableSecurities |  | Long-TermMarketableSecurities |
| Cash | $ | 12,075 |  |  | $ | — |  |  | $ | — |  |  | $ | 12,075 |  |  | $ | 12,075 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 10,558 |  |  | — |  |  | — |  |  | 10,558 |  |  | 10,558 |  |  | — |  |  | — |  |
| Subtotal | 10,558 |  |  | — |  |  | — |  |  | 10,558 |  |  | 10,558 |  |  | — |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 37,307 |  |  | 22 |  |  | (102 | ) |  | 37,227 |  |  | 11,116 |  |  | 8,436 |  |  | 17,675 |  |
| U.S. agency securities | 9,552 |  |  | 1 |  |  | (5 | ) |  | 9,548 |  |  | 7,711 |  |  | 450 |  |  | 1,387 |  |
| Non-U.S. government securities | 20,569 |  |  | 272 |  |  | (63 | ) |  | 20,778 |  |  | 636 |  |  | 3,467 |  |  | 16,675 |  |
| Certificates of deposit and time deposits | 4,838 |  |  | — |  |  | — |  |  | 4,838 |  |  | 3,495 |  |  | 1,273 |  |  | 70 |  |
| Commercial paper | 5,161 |  |  | — |  |  | — |  |  | 5,161 |  |  | 4,930 |  |  | 231 |  |  | — |  |
| Corporate debt securities | 93,896 |  |  | 550 |  |  | (173 | ) |  | 94,273 |  |  | 9 |  |  | 29,027 |  |  | 65,237 |  |
| Municipal securities | 961 |  |  | 9 |  |  | (1 | ) |  | 969 |  |  | — |  |  | 65 |  |  | 904 |  |
| Mortgage- and asset-backed securities | 15,262 |  |  | 38 |  |  | (117 | ) |  | 15,183 |  |  | — |  |  | 1,135 |  |  | 14,048 |  |
| Subtotal | 187,546 |  |  | 892 |  |  | (461 | ) |  | 187,977 |  |  | 27,897 |  |  | 44,084 |  |  | 115,996 |  |
| Total (3) | $ | 210,179 |  |  | $ | 892 |  |  | $ | (461 | ) |  | $ | 210,610 |  |  | $ | 50,530 |  |  | $ | 44,084 |  |  | $ | 115,996 |  |

[0000320193-19-000076:notes:42]
[same as prior period, unchanged from 0000320193-19-000066:notes:41]

[0000320193-19-000076:notes:43]
[same as prior period, unchanged from 0000320193-19-000066:notes:42]

[0000320193-19-000076:notes:44]
[same as prior period, unchanged from 0000320193-19-000066:notes:43]

[0000320193-19-000076:notes:45]
| (3) | As of June 29, 2019 and September 29, 2018, total cash, cash equivalents and marketable securities included $19.5 billion and $20.3 billion, respectively, that was restricted from general use, related to the State Aid Decision (refer to Note 5, “Income Taxes”) and other agreements. |

[0000320193-19-000076:notes:46]
[same as prior period, unchanged from 0000320193-19-000066:notes:45]

[0000320193-19-000076:notes:47]
The following tables show information about the Company’s marketable securities that had been in a continuous unrealized loss position for less than 12 months and for 12 months or greater as of June 29, 2019 and September 29, 2018 (in millions):

[0000320193-19-000076:notes:48]
|  | June 29, 2019 |
|  | Continuous Unrealized Losses |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
| Fair value of marketable debt securities | $ | 11,853 |  |  | $ | 71,984 |  |  | $ | 83,837 |  |
| Unrealized losses | $ | (44 | ) |  | $ | (417 | ) |  | $ | (461 | ) |

[0000320193-19-000076:notes:49]
[same as prior period, unchanged from 0000320193-19-000066:notes:48]

[0000320193-19-000076:notes:50]
The Company typically invests in highly rated securities, with the primary objective of minimizing the potential risk of principal loss. The Company’s investment policy generally requires securities to be investment grade and limits the amount of credit exposure to any one issuer. Fair values were determined for each individual security in the investment portfolio. When evaluating a marketable debt security for other-than-temporary impairment, the Company reviews factors such as the length of time and extent to which fair value has been below its cost basis, the financial condition of the issuer and any changes thereto, changes in market interest rates and the Company’s intent to sell, or whether it is more likely than not it will be required to sell the security before recovery of the security’s cost basis. As of June 29, 2019, the Company does not consider any of its marketable debt securities to be other-than-temporarily impaired.

[0000320193-19-000076:notes:51]
[same as prior period, unchanged from 0000320193-19-000066:notes:50]

[0000320193-19-000076:notes:52]
The Company holds non-marketable equity securities of certain privately held companies without readily determinable fair values, and has elected to apply the measurement alternative. As such, the Company’s non-marketable equity securities are measured at cost, less any impairment, and are adjusted for changes in fair value resulting from observable transactions for identical or similar investments of the same issuer. Gains and losses on non-marketable equity securities are recognized in other income/(expense), net. As of June 29, 2019, the Company’s non-marketable equity securities had a carrying value of $2.4 billion.

[0000320193-19-000076:notes:53]
A reconciliation of the Company’s cash and cash equivalents in the Condensed Consolidated Balance Sheet to cash, cash equivalents and restricted cash in the Condensed Consolidated Statement of Cash Flows as of June 29, 2019 is as follows (in millions):

[0000320193-19-000076:notes:54]
|  | June 29, 2019 |
| Cash and cash equivalents | $ | 50,530 |  |
| Restricted cash included in other current assets | 266 |  |
| Restricted cash included in other non-current assets | 1,355 |  |
| Cash, cash equivalents and restricted cash | $ | 52,151 |  |

[0000320193-19-000076:notes:55]
[same as prior period, unchanged from 0000320193-19-000066:notes:55]

[0000320193-19-000076:notes:56]
[same as prior period, unchanged from 0000320193-19-000066:notes:56]

[0000320193-19-000076:notes:57]
[same as prior period, unchanged from 0000320193-19-000066:notes:57]

[0000320193-19-000076:notes:58]
[same as prior period, unchanged from 0000320193-19-000066:notes:58]

[0000320193-19-000076:notes:59]
[same as prior period, unchanged from 0000320193-19-000066:notes:59]

[0000320193-19-000076:notes:60]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in foreign currency exchange rates, the Company may enter into forward contracts, cross-currency swaps or other instruments. These instruments may offset a portion of the foreign currency remeasurement gains or losses, or changes in fair value. The Company may designate these instruments as either cash flow or fair value hedges. As of June 29, 2019, the Company’s hedged term debt– and marketable securities–related foreign currency transactions are expected to be recognized within 23 years.

[0000320193-19-000076:notes:61]
[same as prior period, unchanged from 0000320193-19-000066:notes:61]

[0000320193-19-000076:notes:62]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in interest rates, the Company may enter into interest rate swaps, options or other instruments. These instruments may offset a portion of the changes in interest income or expense, or changes in fair value. The Company designates these instruments as either cash flow or fair value hedges. As of June 29, 2019, the Company’s hedged interest rate transactions are expected to be recognized within 8 years.

[0000320193-19-000076:notes:63]
[same as prior period, unchanged from 0000320193-19-000066:notes:63]

[0000320193-19-000076:notes:64]
[same as prior period, unchanged from 0000320193-19-000066:notes:64]

[0000320193-19-000076:notes:65]
[same as prior period, unchanged from 0000320193-19-000066:notes:65]

[0000320193-19-000076:notes:66]
[same as prior period, unchanged from 0000320193-19-000066:notes:66]

[0000320193-19-000076:notes:67]
[same as prior period, unchanged from 0000320193-19-000066:notes:67]

[0000320193-19-000076:notes:68]
[same as prior period, unchanged from 0000320193-19-000066:notes:68]

[0000320193-19-000076:notes:69]
Gains and losses related to changes in fair value hedges are recognized in earnings along with a corresponding loss or gain related to the change in value of the underlying hedged item in the same line in the Condensed Consolidated Statements of Operations. For foreign exchange forward contracts designated as fair value hedges, the Company excludes changes in fair value relating to changes in the forward carry component from its assessment of hedge effectiveness. Amounts excluded from the effectiveness testing of fair value hedges were gains of $171 million and $645 million for the three- and nine-month periods ended June 29, 2019, respectively, and were recognized in other income/(expense), net.

[0000320193-19-000076:notes:70]
[same as prior period, unchanged from 0000320193-19-000066:notes:70]

[0000320193-19-000076:notes:71]
Derivatives that are not designated as hedging instruments are adjusted to fair value through earnings in the financial statement line item to which the derivative relates. As a result, during the three- and nine-month periods ended June 29, 2019, respectively, the Company recognized gains of $58 million and $283 million in net sales, gains of $40 million and $108 million in cost of sales and losses of $34 million and $58 million in other income/(expense), net. During the three- and nine-month periods ended June 30, 2018, respectively, the Company recognized a gain of $135 million and a loss of $7 million in net sales, a gain of $151 million and a loss of $61 million in cost of sales and a gain of $132 million and a loss of $241 million in other income/(expense), net.

[0000320193-19-000076:notes:72]
The Company records all derivatives in the Condensed Consolidated Balance Sheets at fair value. The Company’s accounting treatment for these derivative instruments is based on its hedge designation. The following tables show the Company’s derivative instruments at gross fair value as of June 29, 2019 and September 29, 2018 (in millions):

[0000320193-19-000076:notes:73]
|  | June 29, 2019 |
|  | Fair Value ofDerivatives Designatedas Hedge Instruments |  | Fair Value ofDerivatives Not Designatedas Hedge Instruments |  | TotalFair Value |
| Derivative assets (1): |  |  |  |  |  |
| Foreign exchange contracts | $ | 1,179 |  |  | $ | 184 |  |  | $ | 1,363 |  |
| Interest rate contracts | $ | 449 |  |  | $ | — |  |  | $ | 449 |  |
| Derivative liabilities (2): |  |  |  |  |  |
| Foreign exchange contracts | $ | 860 |  |  | $ | 251 |  |  | $ | 1,111 |  |
| Interest rate contracts | $ | 112 |  |  | $ | — |  |  | $ | 112 |  |

[0000320193-19-000076:notes:74]
[same as prior period, unchanged from 0000320193-19-000066:notes:74]

[0000320193-19-000076:notes:75]
[same as prior period, unchanged from 0000320193-19-000066:notes:75]

[0000320193-19-000076:notes:76]
[same as prior period, unchanged from 0000320193-19-000066:notes:76]

[0000320193-19-000076:notes:77]
[same as prior period, unchanged from 0000320193-19-000066:notes:77]

[0000320193-19-000076:notes:78]
The following table shows the pre-tax gains and losses of the Company’s derivative and non-derivative instruments designated as cash flow, net investment and fair value hedges in OCI and the Condensed Consolidated Statements of Operations for the three- and nine-month periods ended June 29, 2019 and June 30, 2018 (in millions):

[0000320193-19-000076:notes:79]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| Gains/(Losses) recognized in OCI – effective portion: |  |  |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | (147 | ) |  | $ | 40 |  |  | $ | (689 | ) |  | $ | 230 |  |
| Interest rate contracts | — |  |  | — |  |  | — |  |  | 1 |  |
| Total | $ | (147 | ) |  | $ | 40 |  |  | $ | (689 | ) |  | $ | 231 |  |
| Net investment hedges: |  |  |  |  |  |  |  |
| Foreign currency debt | $ | (32 | ) |  | $ | 13 |  |  | $ | (55 | ) |  | $ | (18 | ) |
| Gains/(Losses) reclassified from AOCI into net income – effective portion: |  |  |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 53 |  |  | $ | (1,231 | ) |  | $ | 69 |  |  | $ | (1,068 | ) |
| Interest rate contracts | (2 | ) |  | — |  |  | (5 | ) |  | 3 |  |
| Total | $ | 51 |  |  | $ | (1,231 | ) |  | $ | 64 |  |  | $ | (1,065 | ) |
| Gains/(Losses) on derivative instruments: |  |  |  |  |  |  |  |
| Fair value hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | (136 | ) |  | $ | 31 |  |  | $ | 509 |  |  | $ | 31 |  |
| Interest rate contracts | 671 |  |  | (230 | ) |  | 1,793 |  |  | (1,178 | ) |
| Total | $ | 535 |  |  | $ | (199 | ) |  | $ | 2,302 |  |  | $ | (1,147 | ) |
| Gains/(Losses) related to hedged items: |  |  |  |  |  |  |  |
| Fair value hedges: |  |  |  |  |  |  |  |
| Marketable securities | $ | 136 |  |  | $ | (31 | ) |  | $ | (508 | ) |  | $ | (31 | ) |
| Fixed-rate debt | (671 | ) |  | 230 |  |  | (1,793 | ) |  | 1,178 |  |
| Total | $ | (535 | ) |  | $ | 199 |  |  | $ | (2,301 | ) |  | $ | 1,147 |  |

[0000320193-19-000076:notes:80]
The following table shows the notional amounts of the Company’s outstanding derivative instruments and credit risk amounts associated with outstanding or unsettled derivative instruments as of June 29, 2019 and September 29, 2018 (in millions):

[0000320193-19-000076:notes:81]
|  | June 29, 2019 |  | September 29, 2018 |
|  | NotionalAmount |  | Credit RiskAmount |  | NotionalAmount |  | Credit RiskAmount |
| Instruments designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 55,067 |  |  | $ | 1,179 |  |  | $ | 65,368 |  |  | $ | 1,015 |  |
| Interest rate contracts | $ | 31,250 |  |  | $ | 449 |  |  | $ | 33,250 |  |  | $ | — |  |
| Instruments not designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 54,744 |  |  | $ | 184 |  |  | $ | 63,062 |  |  | $ | 259 |  |

[0000320193-19-000076:notes:82]
[same as prior period, unchanged from 0000320193-19-000066:notes:82]

[0000320193-19-000076:notes:83]
The Company generally enters into master netting arrangements, which are designed to reduce credit risk by permitting net settlement of transactions with the same counterparty. To further limit credit risk, the Company generally enters into collateral security arrangements that provide for collateral to be received or posted when the net fair value of certain financial instruments fluctuates from contractually established thresholds. The Company presents its derivative assets and derivative liabilities at their gross fair values in its Condensed Consolidated Balance Sheets. As of June 29, 2019, the net cash collateral received by the Company related to derivative instruments under its collateral security arrangements was $603 million, which was recorded as other current liabilities in the Condensed Consolidated Balance Sheet. As of September 29, 2018, the net cash collateral posted by the Company related to derivative instruments under its collateral security arrangements was $1.0 billion, which was recorded as other current assets in the Condensed Consolidated Balance Sheet.

[0000320193-19-000076:notes:84]
Under master netting arrangements with the respective counterparties to the Company’s derivative contracts, the Company is allowed to net settle transactions with a single net amount payable by one party to the other. As of June 29, 2019 and September 29, 2018, the potential effects of these rights of set-off associated with the Company’s derivative contracts, including the effects of collateral, would be a reduction to both derivative assets and derivative liabilities of $1.8 billion and $2.1 billion, respectively, resulting in a net derivative liability of $14 million and a net derivative asset of $138 million, respectively.

[0000320193-19-000076:notes:85]
[same as prior period, unchanged from 0000320193-19-000066:notes:85]

[0000320193-19-000076:notes:86]
[same as prior period, unchanged from 0000320193-19-000066:notes:86]

[0000320193-19-000076:notes:87]
[same as prior period, unchanged from 0000320193-19-000066:notes:87]

[0000320193-19-000076:notes:88]
As of June 29, 2019, the Company had one customer that represented 10% or more of total trade receivables, which accounted for 11%. As of September 29, 2018, the Company had one customer that represented 10% or more of total trade receivables, which accounted for 10%. The Company’s cellular network carriers accounted for 42% and 59% of total trade receivables as of June 29, 2019 and September 29, 2018, respectively.

[0000320193-19-000076:notes:89]
Vendor Non-Trade Receivables

[0000320193-19-000076:notes:90]
The Company has non-trade receivables from certain of its manufacturing vendors resulting from the sale of components to these vendors who manufacture sub-assemblies or assemble final products for the Company. The Company purchases these components directly from suppliers. As of June 29, 2019, the Company had three vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 57%, 12% and 12%. As of September 29, 2018, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 62% and 12%.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000320193-19-000076:notes:91]
Level 2 fair value estimates are based on observable inputs other than quoted prices in active markets for identical assets and liabilities, quoted prices for identical or similar assets or liabilities in inactive markets, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities.

[0000320193-19-000076:notes:92]
Level 1 fair value estimates are based on quoted prices in active markets for identical assets or liabilities.


## us-gaap:DerivativesPolicyTextBlock

[0000320193-19-000076:notes:93]
Non-Designated Derivatives
Derivatives that are not designated as hedging instruments are adjusted to fair value through earnings in the financial statement line item to which the derivative relates.The Company records all derivatives in the Condensed Consolidated Balance Sheets at fair value. The Company’s accounting treatment for these derivative instruments is based on its hedge designation.
The Company classifies cash flows related to derivative financial instruments as operating activities in its Condensed Consolidated Statements of Cash Flows.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000320193-19-000076:notes:94]
Condensed Consolidated Financial Statement Details
The following tables show the Company’s condensed consolidated financial statement details as of June 29, 2019 and September 29, 2018 (in millions):

[0000320193-19-000076:notes:95]
[same as prior period, unchanged from 0000320193-19-000066:notes:94]

[0000320193-19-000076:notes:96]
|  | June 29, 2019 |  | September 29, 2018 |
| Land and buildings | $ | 16,560 |  |  | $ | 16,216 |  |
| Machinery, equipment and internal-use software | 68,529 |  |  | 65,982 |  |
| Leasehold improvements | 8,895 |  |  | 8,205 |  |
| Gross property, plant and equipment | 93,984 |  |  | 90,403 |  |
| Accumulated depreciation and amortization | (56,348 | ) |  | (49,099 | ) |
| Total property, plant and equipment, net | $ | 37,636 |  |  | $ | 41,304 |  |

[0000320193-19-000076:notes:97]
[same as prior period, unchanged from 0000320193-19-000066:notes:96]

[0000320193-19-000076:notes:98]
|  | June 29, 2019 |  | September 29, 2018 |
| Long-term taxes payable | $ | 30,521 |  |  | $ | 33,589 |  |
| Other non-current liabilities | 20,622 |  |  | 15,325 |  |
| Total other non-current liabilities | $ | 51,143 |  |  | $ | 48,914 |  |

[0000320193-19-000076:notes:99]
[same as prior period, unchanged from 0000320193-19-000066:notes:98]

[0000320193-19-000076:notes:100]
The following table shows the detail of other income/(expense), net for the three- and nine-month periods ended June 29, 2019 and June 30, 2018 (in millions):

[0000320193-19-000076:notes:101]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| Interest and dividend income | $ | 1,190 |  |  | $ | 1,418 |  |  | $ | 3,855 |  |  | $ | 4,375 |  |
| Interest expense | (866 | ) |  | (846 | ) |  | (2,766 | ) |  | (2,372 | ) |
| Other income/(expense), net | 43 |  |  | 100 |  |  | 216 |  |  | (301 | ) |
| Total other income/(expense), net | $ | 367 |  |  | $ | 672 |  |  | $ | 1,305 |  |  | $ | 1,702 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000320193-19-000076:notes:102]
[same as prior period, unchanged from 0000320193-19-000066:notes:101]

[0000320193-19-000076:notes:103]
As of June 29, 2019, the total amount of gross unrecognized tax benefits was $14.8 billion, of which $8.1 billion, if recognized, would impact the Company’s effective tax rate. The Company had accrued $1.3 billion of gross interest and penalties as of June 29, 2019. Both the unrecognized tax benefits and the associated interest and penalties that are not expected to result in payment or receipt of cash within one year are classified as other non-current liabilities in the Condensed Consolidated Balance Sheet.

[0000320193-19-000076:notes:104]
The Company is subject to taxation and files income tax returns in the U.S. federal jurisdiction and in many state and foreign jurisdictions. The U.S. Internal Revenue Service concluded its review of the years 2013 through 2015 in 2018, and all years prior to 2016 are closed. Tax years subsequent to 2006 in certain major U.S. states and subsequent to 2010 in certain major foreign jurisdictions remain open, and could be subject to examination by the taxing authorities. The Company believes that an adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax audits cannot be predicted with certainty. If any issues addressed in the Company’s tax audits are resolved in a manner inconsistent with its expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. Although timing of resolution and/or closure of audits is not certain, the Company believes it is reasonably possible that its gross unrecognized tax benefits could decrease (either by payment, release or a combination of both) in the next 12 months by as much as $400 million.

[0000320193-19-000076:notes:105]
European Commission State Aid Decision

[0000320193-19-000076:notes:106]
On August 30, 2016, the European Commission announced its decision that Ireland granted state aid to the Company by providing tax opinions in 1991 and 2007 concerning the tax allocation of profits of the Irish branches of two subsidiaries of the Company (the “State Aid Decision”). The State Aid Decision ordered Ireland to calculate and recover additional taxes from the Company for the period June 2003 through December 2014. The recovery amount was calculated to be €13.1 billion, plus interest of €1.2 billion. Irish legislative changes, effective as of January 2015, eliminated the application of the tax opinions from that date forward. The Company believes the State Aid Decision to be without merit and appealed to the General Court of the Court of Justice of the European Union. Ireland has also appealed the State Aid Decision. The Company believes that any incremental Irish corporate income taxes potentially due related to the State Aid Decision would be creditable against U.S. taxes, subject to any foreign tax credit limitations in the U.S. Tax Cuts and Jobs Act. As of June 29, 2019, the entire recovery amount plus interest was funded into escrow, where it will remain restricted from general use pending conclusion of all appeals. Refer to Note 3, “Financial Instruments” for more information.


## us-gaap:DebtDisclosureTextBlock

[0000320193-19-000076:notes:107]
Debt
Commercial Paper

[0000320193-19-000076:notes:108]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of June 29, 2019 and September 29, 2018, the Company had $10.0 billion and $12.0 billion of Commercial Paper outstanding, respectively, with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 2.49% and 2.18% as of June 29, 2019 and September 29, 2018, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the nine months ended June 29, 2019 and June 30, 2018 (in millions):

[0000320193-19-000076:notes:109]
|  | Nine Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | (3,720 | ) |  | $ | 2,619 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 12,977 |  |  | 9,782 |  |
| Repayments of commercial paper | (11,283 | ) |  | (12,411 | ) |
| Proceeds from/(Repayments of) commercial paper, net | 1,694 |  |  | (2,629 | ) |
| Total repayments of commercial paper, net | $ | (2,026 | ) |  | $ | (10 | ) |

[0000320193-19-000076:notes:110]
Term Debt

[0000320193-19-000076:notes:111]
As of June 29, 2019, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $98.3 billion (collectively the “Notes”). The Notes are senior unsecured obligations, and interest is payable in arrears, quarterly for the U.S. dollar–denominated and Australian dollar–denominated floating-rate notes, semi-annually for the U.S. dollar–denominated, Australian dollar–denominated, British pound–denominated, Japanese yen–denominated and Canadian dollar–denominated fixed-rate notes and annually for the euro-denominated and Swiss franc–denominated fixed-rate notes.

[0000320193-19-000076:notes:112]
The following table provides a summary of the Company’s term debt as of June 29, 2019 and September 29, 2018:

[0000320193-19-000076:notes:113]
|  | Maturities(calendar year) |  | June 29, 2019 |  | September 29, 2018 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 2.400% – 3.850% notes | 2023 | – | 2043 |  | $ | 8,500 |  |  |  | 2.44% | – | 3.91 | % |  | $ | 8,500 |  |  |  | 2.44% | – | 3.91 | % |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | — |  | — |  |  |  |  |  | — | % |  | 1,000 |  |  |  |  |  | 2.64 | % |
| Fixed-rate 2.850% – 4.450% notes | 2021 | – | 2044 |  | 6,500 |  |  |  | 3.12% | – | 4.48 | % |  | 8,500 |  |  |  | 2.64% | – | 4.48 | % |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2020 |  | 1,488 |  |  |  | 1.87% | – | 2.84 | % |  | 1,507 |  |  |  | 1.87% | – | 2.64 | % |
| Fixed-rate 0.350% – 4.375% notes | 2019 | – | 2045 |  | 24,223 |  |  |  | 0.28% | – | 4.51 | % |  | 24,410 |  |  |  | 0.28% | – | 4.51 | % |
| 2016 debt issuances of $24.9 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2021 |  | 850 |  |  |  | 2.71% | – | 3.65 | % |  | 1,350 |  |  |  | 2.48% | – | 3.44 | % |
| Fixed-rate 1.100% – 4.650% notes | 2019 | – | 2046 |  | 22,022 |  |  |  | 1.13% | – | 4.78 | % |  | 23,059 |  |  |  | 1.13% | – | 4.78 | % |
| 2017 debt issuances of $28.7 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2020 | – | 2022 |  | 2,750 |  |  |  | 2.61% | – | 3.06 | % |  | 3,250 |  |  |  | 2.41% | – | 2.84 | % |
| Fixed-rate 0.875% – 4.300% notes | 2019 | – | 2047 |  | 24,989 |  |  |  | 1.54% | – | 4.30 | % |  | 25,617 |  |  |  | 1.54% | – | 4.30 | % |
| 2018 debt issuance of $7.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 1.800% – 3.750% notes | 2019 | – | 2047 |  | 7,000 |  |  |  | 1.83% | – | 3.80 | % |  | 7,000 |  |  |  | 1.83% | – | 3.80 | % |
| Total term debt |  |  |  |  | 98,322 |  |  |  |  |  |  |  | 104,193 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (194 | ) |  |  |  |  |  |  | (218 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | 337 |  |  |  |  |  |  |  | (1,456 | ) |  |  |  |  |  |
| Less: Current portion of term debt |  |  |  |  | (13,529 | ) |  |  |  |  |  |  | (8,784 | ) |  |  |  |  |  |
| Total non-current portion of term debt |  |  |  |  | $ | 84,936 |  |  |  |  |  |  |  | $ | 93,735 |  |  |  |  |  |  |

[0000320193-19-000076:notes:114]
To manage interest rate risk on certain of its U.S. dollar–denominated fixed- or floating-rate notes, the Company has entered into interest rate swaps to effectively convert the fixed interest rates to floating interest rates or the floating interest rates to fixed interest rates on a portion of these notes. Additionally, to manage foreign currency risk on certain of its foreign currency–denominated notes, the Company has entered into foreign currency swaps to effectively convert these notes to U.S. dollar–denominated notes.

[0000320193-19-000076:notes:115]
A portion of the Company’s Japanese yen–denominated notes is designated as a hedge of the foreign currency exposure of the Company’s net investment in a foreign operation. As of June 29, 2019 and September 29, 2018, the carrying value of the debt designated as a net investment hedge was $1.2 billion and $811 million, respectively. For further discussion regarding the Company’s use of derivative instruments, refer to the Derivative Financial Instruments section of Note 3, “Financial Instruments.”

[0000320193-19-000076:notes:116]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $790 million and $2.4 billion of interest cost on its term debt for the three- and nine-month periods ended June 29, 2019, respectively. The Company recognized $780 million and $2.2 billion of interest cost on its term debt for the three- and nine-month periods ended June 30, 2018, respectively.

[0000320193-19-000076:notes:117]
As of June 29, 2019 and September 29, 2018, the fair value of the Company’s Notes, based on Level 2 inputs, was $102.5 billion and $103.2 billion, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000320193-19-000076:notes:118]
Shareholders’ Equity
On April 30, 2019, the Company announced the Board of Directors increased the current share repurchase program authorization from $100 billion to $175 billion of the Company’s common stock, of which $78.2 billion had been utilized as of June 29, 2019. During the nine months ended June 29, 2019, the Company repurchased 252.6 million shares of its common stock for $49.2 billion, including 55.1 million shares initially delivered under a $12.0 billion accelerated share repurchase arrangement dated February 2019. The Company’s share repurchase program does not obligate it to acquire any specific number of shares. Under this program, shares may be repurchased in privately negotiated and/or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000320193-19-000076:notes:119]
[same as prior period, unchanged from 0000320193-19-000066:notes:116]

[0000320193-19-000076:notes:120]
The following table shows the pre-tax amounts reclassified from AOCI into the Condensed Consolidated Statements of Operations, and the associated financial statement line item, for the three- and nine-month periods ended June 29, 2019 and June 30, 2018 (in millions):

[0000320193-19-000076:notes:121]
|  |  |  |  | Three Months Ended |  | Nine Months Ended |
| Comprehensive Income Components |  | Financial Statement Line Item |  | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| Unrealized (gains)/losses on derivative instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Total net sales |  | $ | (68 | ) |  | $ | 162 |  |  | $ | (102 | ) |  | $ | 433 |  |
|  |  | Total cost of sales |  | 13 |  |  | 206 |  |  | (438 | ) |  | 200 |  |
|  |  | Other income/(expense), net |  | 3 |  |  | 864 |  |  | 451 |  |  | 441 |  |
| Interest rate contracts |  | Other income/(expense), net |  | 2 |  |  | — |  |  | 5 |  |  | (3 | ) |
|  |  |  |  | (50 | ) |  | 1,232 |  |  | (84 | ) |  | 1,071 |  |
| Unrealized (gains)/losses on marketable securities |  | Other income/(expense), net |  | (28 | ) |  | 31 |  |  | 55 |  |  | (49 | ) |
| Total amounts reclassified from AOCI |  | $ | (78 | ) |  | $ | 1,263 |  |  | $ | (29 | ) |  | $ | 1,022 |  |

[0000320193-19-000076:notes:122]
The following table shows the changes in AOCI by component for the nine months ended June 29, 2019 (in millions):

[0000320193-19-000076:notes:123]
|  | Cumulative ForeignCurrency Translation |  | Unrealized Gains/Losseson Derivative Instruments |  | Unrealized Gains/Losseson Marketable Securities |  | Total |
| Balances as of September 29, 2018 | $ | (1,055 | ) |  | $ | 810 |  |  | $ | (3,209 | ) |  | $ | (3,454 | ) |
| Other comprehensive income/(loss) before reclassifications | (136 | ) |  | (678 | ) |  | 4,340 |  |  | 3,526 |  |
| Amounts reclassified from AOCI | — |  |  | (84 | ) |  | 55 |  |  | (29 | ) |
| Tax effect | 13 |  |  | 163 |  |  | (947 | ) |  | (771 | ) |
| Other comprehensive income/(loss) | (123 | ) |  | (599 | ) |  | 3,448 |  |  | 2,726 |  |
| Cumulative effect of change in accounting principle (1) | — |  |  | — |  |  | 89 |  |  | 89 |  |
| Balances as of June 29, 2019 | $ | (1,178 | ) |  | $ | 211 |  |  | $ | 328 |  |  | $ | (639 | ) |

[0000320193-19-000076:notes:124]
(1)

[0000320193-19-000076:notes:125]
Refer to Note 1, “Summary of Significant Accounting Policies” for more information on the Company’s adoption of ASU 2016-01 at the beginning of the first quarter of 2019.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000320193-19-000076:notes:126]
[same as prior period, unchanged from 0000320193-19-000066:notes:122]

[0000320193-19-000076:notes:127]
The Company had 247.8 million shares reserved for future issuance under its stock plans as of June 29, 2019. Restricted stock units (“RSUs”) granted under the Company’s stock plans generally vest over four years, based on continued employment, and are settled upon vesting in shares of the Company’s common stock on a one-for-one basis. Each share issued with respect to RSUs granted under the Company’s stock plans reduces the number of shares available for grant under the plans by two shares. RSUs canceled and shares withheld to satisfy tax withholding obligations increase the number of shares available for grant under the plans utilizing a factor of two times the number of RSUs canceled or shares withheld.

[0000320193-19-000076:notes:128]
[same as prior period, unchanged from 0000320193-19-000066:notes:124]

[0000320193-19-000076:notes:129]
During the three months ended June 29, 2019, Section 16 officers Timothy D. Cook, Chris Kondo, Luca Maestri, Deirdre O’Brien and Jeffrey Williams had equity trading plans in place in accordance with Rule 10b5-1(c)(1) under the Exchange Act. An equity trading plan is a written document that pre-establishes the amounts, prices and dates (or formula for determining the amounts, prices and dates) of future purchases or sales of the Company’s stock, including shares acquired pursuant to the Company’s employee and director equity plans.

[0000320193-19-000076:notes:130]
[same as prior period, unchanged from 0000320193-19-000066:notes:126]

[0000320193-19-000076:notes:131]
A summary of the Company’s RSU activity and related information for the nine months ended June 29, 2019 is as follows:

[0000320193-19-000076:notes:132]
|  | Number ofRSUs(in thousands) |  | Weighted-AverageGrant Date FairValue Per RSU |  | AggregateFair Value(in millions) |
| Balance as of September 29, 2018 | 92,155 |  |  | $ | 134.60 |  |  |  |
| RSUs granted | 34,805 |  |  | $ | 216.40 |  |  |  |
| RSUs vested | (39,440 | ) |  | $ | 135.82 |  |  |  |
| RSUs canceled | (4,478 | ) |  | $ | 161.14 |  |  |  |
| Balance as of June 29, 2019 | 83,042 |  |  | $ | 166.87 |  |  | $ | 16,436 |  |

[0000320193-19-000076:notes:133]
The fair value as of the respective vesting dates of RSUs was $3.7 billion and $8.1 billion for the three- and nine-month periods ended June 29, 2019, respectively, and was $3.3 billion and $6.9 billion for the three- and nine-month periods ended June 30, 2018, respectively.

[0000320193-19-000076:notes:134]
[same as prior period, unchanged from 0000320193-19-000066:notes:130]

[0000320193-19-000076:notes:135]
The following table shows share-based compensation expense and the related income tax benefit included in the Condensed Consolidated Statements of Operations for the three- and nine-month periods ended June 29, 2019 and June 30, 2018 (in millions):

[0000320193-19-000076:notes:136]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| Share-based compensation expense | $ | 1,496 |  |  | $ | 1,351 |  |  | $ | 4,569 |  |  | $ | 3,995 |  |
| Income tax benefit related to share-based compensation expense | $ | (502 | ) |  | $ | (528 | ) |  | $ | (1,583 | ) |  | $ | (1,506 | ) |

[0000320193-19-000076:notes:137]
As of June 29, 2019, the total unrecognized compensation cost related to outstanding RSUs and stock options was $11.6 billion, which the Company expects to recognize over a weighted-average period of 2.6 years.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000320193-19-000076:notes:138]
Commitments and Contingencies
Accrued Warranty and Indemnification

[0000320193-19-000076:notes:139]
The following table shows changes in the Company’s accrued warranties and related costs for the three- and nine-month periods ended June 29, 2019 and June 30, 2018 (in millions):

[0000320193-19-000076:notes:140]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| Beginning accrued warranty and related costs | $ | 3,487 |  |  | $ | 4,030 |  |  | $ | 3,692 |  |  | $ | 3,834 |  |
| Cost of warranty claims | (912 | ) |  | (1,044 | ) |  | (2,823 | ) |  | (2,959 | ) |
| Accruals for product warranty | 548 |  |  | 567 |  |  | 2,254 |  |  | 2,678 |  |
| Ending accrued warranty and related costs | $ | 3,123 |  |  | $ | 3,553 |  |  | $ | 3,123 |  |  | $ | 3,553 |  |

[0000320193-19-000076:notes:141]
Agreements entered into by the Company may include indemnification provisions, which may subject the Company to costs and damages in the event of a claim against an indemnified third party. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to indemnification of third parties.

[0000320193-19-000076:notes:142]
The Company offers an iPhone Upgrade Program, which is available to customers who purchase a qualifying iPhone in the U.S., the U.K. and mainland China. The iPhone Upgrade Program provides customers the right to trade in that iPhone for a specified amount when purchasing a new iPhone, provided certain conditions are met. The Company accounts for the trade-in right as a guarantee liability and recognizes arrangement revenue net of the fair value of such right, with subsequent changes to the guarantee liability recognized within net sales.

[0000320193-19-000076:notes:143]
The Company has entered into indemnification agreements with its directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers of the Company, and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. While the Company maintains directors and officers liability insurance coverage, such insurance coverage may be insufficient to cover all losses or all types of claims that may arise.

[0000320193-19-000076:notes:144]
Concentrations in the Available Sources of Supply of Materials and Product

[0000320193-19-000076:notes:145]
Although most components essential to the Company’s business are generally available from multiple sources, certain components are currently obtained from single or limited sources. In addition, the Company competes for various components with other participants in the markets for mobile communication and media devices and personal computers. Therefore, many components used by the Company, including those that are available from multiple sources, are at times subject to industry-wide shortage and significant commodity pricing fluctuations that could materially adversely affect the Company’s financial condition and operating results.

[0000320193-19-000076:notes:146]
The Company uses some custom components that are not commonly used by its competitors, and new products introduced by the Company often utilize custom components available from only one source. When a component or product uses new technologies, initial capacity constraints may exist until the suppliers’ yields have matured or manufacturing capacity has increased. If the Company’s supply of components for a new or existing product were delayed or constrained, or if an outsourcing partner delayed shipments of completed products to the Company, the Company’s financial condition and operating results could be materially adversely affected. The Company’s business and financial performance could also be materially adversely affected depending on the time required to obtain sufficient quantities from the original source, or to identify and obtain sufficient quantities from an alternative source. Continued availability of these components at acceptable prices, or at all, may be affected if suppliers decide to concentrate on the production of common components instead of components customized to meet the Company’s requirements.

[0000320193-19-000076:notes:147]
The Company has entered into agreements for the supply of many components; however, there can be no guarantee that the Company will be able to extend or renew these agreements on similar terms, or at all. Therefore, the Company remains subject to significant risks of supply shortages and price increases that could materially adversely affect its financial condition and operating results.

[0000320193-19-000076:notes:148]
Substantially all of the Company’s hardware products are manufactured by outsourcing partners that are located primarily in Asia, with some Mac computers manufactured in the U.S. and Ireland. A significant concentration of this manufacturing is currently performed by a small number of outsourcing partners, often in single locations. Certain of these outsourcing partners are single-sourced suppliers of components and manufacturers for many of the Company’s products. Although the Company works closely with its outsourcing partners on manufacturing schedules, the Company’s financial condition and operating results could be materially adversely affected if its outsourcing partners were unable to meet their production commitments. The Company’s manufacturing purchase obligations typically cover its requirements for periods up to 150 days.

[0000320193-19-000076:notes:149]
Other Off–Balance Sheet Commitments

[0000320193-19-000076:notes:150]
Operating Leases

[0000320193-19-000076:notes:151]
The Company leases various equipment and facilities, including retail space, under noncancelable operating lease arrangements. The Company does not currently utilize any other off–balance sheet financing arrangements. As of June 29, 2019, the Company’s total future minimum lease payments under noncancelable operating leases were $11.1 billion. The Company’s retail store and other facility leases typically have original terms not exceeding 10 years and generally contain multi-year renewal options.

[0000320193-19-000076:notes:152]
Unconditional Purchase Obligations

[0000320193-19-000076:notes:153]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of payments for supplier arrangements, internet and telecommunication services, intellectual property licenses and content creation. As of June 29, 2019, the Company’s total future payments under noncancelable unconditional purchase obligations having a remaining term in excess of one year were $8.1 billion.

[0000320193-19-000076:notes:154]
Contingencies

[0000320193-19-000076:notes:155]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully adjudicated, as further discussed in Part II, Item 1 of this Form 10-Q under the heading “Legal Proceedings” and in Part II, Item 1A of this Form 10-Q under the heading “Risk Factors.” The outcome of litigation is inherently uncertain. If one or more legal matters were resolved against the Company in a reporting period for amounts in excess of management’s expectations, the Company’s financial condition and operating results for that reporting period could be materially adversely affected. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to loss contingencies for asserted legal and other claims, except for the following matters:

[0000320193-19-000076:notes:156]
VirnetX

[0000320193-19-000076:notes:157]
VirnetX, Inc. (“VirnetX”) filed two lawsuits in the U.S. District Court for the Eastern District of Texas (the “Eastern Texas District Court”) against the Company alleging that certain Company products infringe four patents (the “VirnetX Patents”) relating to network communications technology (“VirnetX I” and “VirnetX II”). On September 30, 2016, a jury returned a verdict in VirnetX I against the Company and awarded damages of $302 million, which later increased to $440 million in post-trial proceedings. The Company appealed the VirnetX I verdict to the U.S. Court of Appeals for the Federal Circuit (the “Federal Circuit”). On April 11, 2018, a jury returned a verdict in VirnetX II against the Company and awarded damages of $503 million. VirnetX II is currently on appeal. The Company has challenged the validity of the VirnetX Patents at the U.S. Patent and Trademark Office (the “PTO”). In response, the PTO has declared the VirnetX Patents invalid. VirnetX appealed the invalidity decision of the PTO to the Federal Circuit. The Federal Circuit consolidated the Company’s appeal of the Eastern Texas District Court VirnetX I verdict and VirnetX’s appeals from the PTO invalidity proceedings. On January 15, 2019, the Federal Circuit affirmed the VirnetX I verdict, which the Company intends to further appeal. On July 8, 2019, the Federal Circuit remanded one of VirnetX’s appeals of the PTO’s invalidity decisions back to the PTO for further proceedings. VirnetX’s other remaining appeal of the PTO’s invalidity decisions remains pending with the Federal Circuit. The Company has accrued its best estimate for the ultimate resolution of these matters.

[0000320193-19-000076:notes:158]
Qualcomm

[0000320193-19-000076:notes:159]
On January 20, 2017, the Company filed a lawsuit against Qualcomm Incorporated and affiliated parties (“Qualcomm”) in the U.S. District Court for the Southern District of California seeking, among other things, to enjoin Qualcomm from requiring the Company to pay royalties at the rate demanded by Qualcomm. No Qualcomm-related royalty payments had been remitted by the Company to its contract manufacturers since the beginning of the second quarter of 2017. Following the Company’s lawsuit, Qualcomm filed patent infringement suits against the Company and its affiliates in the U.S. and various international jurisdictions, some of which sought to enjoin the sale of certain of the Company’s products in particular countries.

[0000320193-19-000076:notes:160]
On April 16, 2019, the Company and Qualcomm reached a settlement agreement to dismiss all litigation between the two companies worldwide. The companies also reached a multi-year license agreement and a multi-year supply agreement. Under the terms of the settlement agreement, Apple made a payment to Qualcomm to, among other things, resolve disputes over the withheld royalty payments.

[0000320193-19-000076:notes:161]
iOS Performance Management Cases

[0000320193-19-000076:notes:162]
Various civil litigation matters have been filed in state and federal courts in the U.S. and in various international jurisdictions alleging violation of consumer protection laws, fraud, computer intrusion and other causes of action related to the Company’s performance management feature used in its iPhone operating systems, introduced to certain iPhones in iOS updates 10.2.1 and 11.2. The claims seek monetary damages and other non-monetary relief. On April 5, 2018, several U.S. federal actions were consolidated through a Multidistrict Litigation process into a single action in the U.S. District Court for the Northern District of California. In addition to civil litigation, the Company is also responding to governmental investigations and requests for information relating to the performance management feature. The Company believes that its iPhones were not defective, that the performance management feature introduced with iOS updates 10.2.1 and 11.2 was intended to, and did, improve customers’ user experience, and that the Company did not make any misleading statements or fail to disclose any material information. The Company has accrued its best estimate for the ultimate resolution of these matters.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000320193-19-000076:notes:163]
[same as prior period, unchanged from 0000320193-19-000066:notes:158]

[0000320193-19-000076:notes:164]
[same as prior period, unchanged from 0000320193-19-000066:notes:159]

[0000320193-19-000076:notes:165]
[same as prior period, unchanged from 0000320193-19-000066:notes:160]

[0000320193-19-000076:notes:166]
The following table shows information by reportable segment for the three- and nine-month periods ended June 29, 2019 and June 30, 2018 (in millions):

[0000320193-19-000076:notes:167]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| Americas: |  |  |  |  |  |  |  |
| Net sales | $ | 25,056 |  |  | $ | 24,542 |  |  | $ | 87,592 |  |  | $ | 84,576 |  |
| Operating income | $ | 7,442 |  |  | $ | 7,496 |  |  | $ | 26,329 |  |  | $ | 26,580 |  |
| Europe: |  |  |  |  |  |  |  |
| Net sales | $ | 11,925 |  |  | $ | 12,138 |  |  | $ | 45,342 |  |  | $ | 47,038 |  |
| Operating income | $ | 3,687 |  |  | $ | 3,892 |  |  | $ | 14,371 |  |  | $ | 15,044 |  |
| Greater China: |  |  |  |  |  |  |  |
| Net sales | $ | 9,157 |  |  | $ | 9,551 |  |  | $ | 32,544 |  |  | $ | 40,531 |  |
| Operating income | $ | 3,221 |  |  | $ | 3,414 |  |  | $ | 12,142 |  |  | $ | 15,285 |  |
| Japan: |  |  |  |  |  |  |  |
| Net sales | $ | 4,082 |  |  | $ | 3,867 |  |  | $ | 16,524 |  |  | $ | 16,572 |  |
| Operating income | $ | 1,795 |  |  | $ | 1,765 |  |  | $ | 7,199 |  |  | $ | 7,193 |  |
| Rest of Asia Pacific: |  |  |  |  |  |  |  |
| Net sales | $ | 3,589 |  |  | $ | 3,167 |  |  | $ | 14,132 |  |  | $ | 13,978 |  |
| Operating income | $ | 1,155 |  |  | $ | 1,127 |  |  | $ | 4,811 |  |  | $ | 4,980 |  |

[0000320193-19-000076:notes:168]
A reconciliation of the Company’s segment operating income to the Condensed Consolidated Statements of Operations for the three- and nine-month periods ended June 29, 2019 and June 30, 2018 is as follows (in millions):

[0000320193-19-000076:notes:169]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| Segment operating income | $ | 17,300 |  |  | $ | 17,694 |  |  | $ | 64,852 |  |  | $ | 69,082 |  |
| Research and development expense | (4,257 | ) |  | (3,701 | ) |  | (12,107 | ) |  | (10,486 | ) |
| Other corporate expenses, net | (1,499 | ) |  | (1,381 | ) |  | (4,440 | ) |  | (3,816 | ) |
| Total operating income | $ | 11,544 |  |  | $ | 12,612 |  |  | $ | 48,305 |  |  | $ | 54,780 |  |
