# AAPL MD&A — 0000320193-23-000077


## mdna

[0000320193-23-000077:mdna:1]
[same as prior period, unchanged from 0000320193-23-000064:mdna:1]

[0000320193-23-000077:mdna:2]
[same as prior period, unchanged from 0000320193-23-000064:mdna:2]

[0000320193-23-000077:mdna:3]
[same as prior period, unchanged from 0000320193-23-000064:mdna:3]

[0000320193-23-000077:mdna:4]
[same as prior period, unchanged from 0000320193-23-000064:mdna:4]

[0000320193-23-000077:mdna:5]
[same as prior period, unchanged from 0000320193-23-000064:mdna:5]

[0000320193-23-000077:mdna:6]
[same as prior period, unchanged from 0000320193-23-000064:mdna:6]

[0000320193-23-000077:mdna:7]
[same as prior period, unchanged from 0000320193-23-000064:mdna:7]

[0000320193-23-000077:mdna:8]
[same as prior period, unchanged from 0000320193-23-000064:mdna:8]

[0000320193-23-000077:mdna:9]
[same as prior period, unchanged from 0000320193-23-000064:mdna:9]

[0000320193-23-000077:mdna:10]
[same as prior period, unchanged from 0000320193-23-000064:mdna:10]

[0000320193-23-000077:mdna:11]
Weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on the Company’s total net sales, which decreased 1% or $1.2 billion during the third quarter of 2023 compared to the same quarter in 2022. The year-over-year net sales decrease consisted primarily of lower net sales of iPad and iPhone, partially offset by higher net sales of Services.

[0000320193-23-000077:mdna:12]
During the third quarter of 2023, the Company announced the following new products:

[0000320193-23-000077:mdna:13]
•15-inch MacBook Air®, powered by the M2 chip;

[0000320193-23-000077:mdna:14]
•Mac Studio™, powered by the M2 Max chip and the new M2 Ultra chip;

[0000320193-23-000077:mdna:15]
•Mac Pro®, powered by the new M2 Ultra chip; and

[0000320193-23-000077:mdna:16]
•Apple Vision Pro™, the Company’s first spatial computer featuring its new visionOS™, expected to be available in early calendar year 2024.

[0000320193-23-000077:mdna:17]
The Company also announced iOS 17, macOS® Sonoma, iPadOS® 17, tvOS® 17 and watchOS® 10, updates to its operating systems that are expected to be available in the fall of 2023.

[0000320193-23-000077:mdna:18]
The Company repurchased $18.0 billion of its common stock and paid dividends and dividend equivalents of $3.8 billion during the third quarter of 2023.

[0000320193-23-000077:mdna:19]
[same as prior period, unchanged from 0000320193-23-000064:mdna:17]

[0000320193-23-000077:mdna:20]
[same as prior period, unchanged from 0000320193-23-000064:mdna:18]

[0000320193-23-000077:mdna:21]
[same as prior period, unchanged from 0000320193-23-000064:mdna:19]

[0000320193-23-000077:mdna:22]
The following table shows net sales by reportable segment for the three- and nine-month periods ended July 1, 2023 and June 25, 2022 (dollars in millions):

[0000320193-23-000077:mdna:23]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1,2023 |  | June 25,2022 |  | Change |  | July 1,2023 |  | June 25,2022 |  | Change |
| Net sales by reportable segment: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 35,383 |  |  | $ | 37,472 |  |  | (6) | % |  | $ | 122,445 |  |  | $ | 129,850 |  |  | (6) | % |
| Europe | 20,205 |  |  | 19,287 |  |  | 5 | % |  | 71,831 |  |  | 72,323 |  |  | (1) | % |
| Greater China | 15,758 |  |  | 14,604 |  |  | 8 | % |  | 57,475 |  |  | 58,730 |  |  | (2) | % |
| Japan | 4,821 |  |  | 5,446 |  |  | (11) | % |  | 18,752 |  |  | 20,277 |  |  | (8) | % |
| Rest of Asia Pacific | 5,630 |  |  | 6,150 |  |  | (8) | % |  | 23,284 |  |  | 23,002 |  |  | 1 | % |
| Total net sales | $ | 81,797 |  |  | $ | 82,959 |  |  | (1) | % |  | $ | 293,787 |  |  | $ | 304,182 |  |  | (3) | % |

[0000320193-23-000077:mdna:24]
[same as prior period, unchanged from 0000320193-23-000064:mdna:22]

[0000320193-23-000077:mdna:25]
Americas net sales decreased during the third quarter and first nine months of 2023 compared to the same periods in 2022 due primarily to lower net sales of iPhone and Mac, partially offset by higher net sales of Services.

[0000320193-23-000077:mdna:26]
[same as prior period, unchanged from 0000320193-23-000064:mdna:24]

[0000320193-23-000077:mdna:27]
The weakness in foreign currencies relative to the U.S. dollar had a net unfavorable year-over-year impact on Europe net sales during the third quarter and first nine months of 2023. During the third quarter of 2023, the Europe net sales increase consisted primarily of higher net sales of iPhone. During the first nine months of 2023, the Europe net sales decrease consisted primarily of lower net sales of Mac, partially offset by higher net sales of iPhone.

[0000320193-23-000077:mdna:28]
[same as prior period, unchanged from 0000320193-23-000064:mdna:26]

[0000320193-23-000077:mdna:29]
The weakness in the renminbi relative to the U.S. dollar had an unfavorable year-over-year impact on Greater China net sales during the third quarter and first nine months of 2023. During the third quarter of 2023, the Greater China net sales increase consisted primarily of higher net sales of iPhone. During the first nine months of 2023, the Greater China net sales decrease consisted primarily of lower net sales of iPhone.

[0000320193-23-000077:mdna:30]
[same as prior period, unchanged from 0000320193-23-000064:mdna:28]

[0000320193-23-000077:mdna:31]
The weakness in the yen relative to the U.S. dollar had an unfavorable year-over-year impact on Japan net sales during the third quarter and first nine months of 2023. During the third quarter of 2023, the Japan net sales decrease consisted primarily of lower net sales of iPhone. During the first nine months of 2023, the Japan net sales decrease consisted primarily of lower net sales of iPhone, Services and Wearables, Home and Accessories.

[0000320193-23-000077:mdna:32]
[same as prior period, unchanged from 0000320193-23-000064:mdna:30]

[0000320193-23-000077:mdna:33]
The weakness in foreign currencies relative to the U.S. dollar had a net unfavorable year-over-year impact on Rest of Asia Pacific net sales during the third quarter and first nine months of 2023. During the third quarter of 2023, the Rest of Asia Pacific net sales decrease consisted primarily of lower net sales of iPhone and iPad. During the first nine months of 2023, the Rest of Asia Pacific net sales increase consisted primarily of higher net sales of iPhone, partially offset by lower net sales of Mac.

[0000320193-23-000077:mdna:34]
[same as prior period, unchanged from 0000320193-23-000064:mdna:32]

[0000320193-23-000077:mdna:35]
The following table shows net sales by category for the three- and nine-month periods ended July 1, 2023 and June 25, 2022 (dollars in millions):

[0000320193-23-000077:mdna:36]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1,2023 |  | June 25,2022 |  | Change |  | July 1,2023 |  | June 25,2022 |  | Change |
| Net sales by category: |  |  |  |  |  |  |  |  |  |  |  |
| iPhone | $ | 39,669 |  |  | $ | 40,665 |  |  | (2) | % |  | $ | 156,778 |  |  | $ | 162,863 |  |  | (4) | % |
| Mac | 6,840 |  |  | 7,382 |  |  | (7) | % |  | 21,743 |  |  | 28,669 |  |  | (24) | % |
| iPad | 5,791 |  |  | 7,224 |  |  | (20) | % |  | 21,857 |  |  | 22,118 |  |  | (1) | % |
| Wearables, Home and Accessories | 8,284 |  |  | 8,084 |  |  | 2 | % |  | 30,523 |  |  | 31,591 |  |  | (3) | % |
| Services | 21,213 |  |  | 19,604 |  |  | 8 | % |  | 62,886 |  |  | 58,941 |  |  | 7 | % |
| Total net sales | $ | 81,797 |  |  | $ | 82,959 |  |  | (1) | % |  | $ | 293,787 |  |  | $ | 304,182 |  |  | (3) | % |

[0000320193-23-000077:mdna:37]
[same as prior period, unchanged from 0000320193-23-000064:mdna:35]

[0000320193-23-000077:mdna:38]
iPhone net sales decreased during the third quarter and first nine months of 2023 compared to the same periods in 2022 due primarily to lower net sales from certain iPhone models, partially offset by higher net sales of iPhone 14 Pro models.

[0000320193-23-000077:mdna:39]
[same as prior period, unchanged from 0000320193-23-000064:mdna:37]

[0000320193-23-000077:mdna:40]
Mac net sales decreased during the third quarter and first nine months of 2023 compared to the same periods in 2022 due primarily to lower net sales of laptops.

[0000320193-23-000077:mdna:41]
[same as prior period, unchanged from 0000320193-23-000064:mdna:39]

[0000320193-23-000077:mdna:42]
iPad net sales decreased during the third quarter of 2023 compared to the third quarter of 2022 due primarily to lower net sales across most iPad models. Year-over-year iPad net sales were relatively flat during the first nine months of 2023.

[0000320193-23-000077:mdna:43]
[same as prior period, unchanged from 0000320193-23-000064:mdna:41]

[0000320193-23-000077:mdna:44]
Wearables, Home and Accessories net sales increased during the third quarter of 2023 compared to the third quarter of 2022 due primarily to higher net sales of Wearables, which includes AirPods®, Apple Watch® and Beats® products, partially offset by lower net sales of accessories. Year-over-year Wearables, Home and Accessories net sales decreased during the first nine months of 2023 due primarily to lower net sales of Wearables and accessories.

[0000320193-23-000077:mdna:45]
[same as prior period, unchanged from 0000320193-23-000064:mdna:43]

[0000320193-23-000077:mdna:46]
Services net sales increased during the third quarter of 2023 compared to the third quarter of 2022 due primarily to higher net sales from advertising, cloud services and the App Store®. Year-over-year Services net sales increased during the first nine months of 2023 due primarily to higher net sales from cloud services, advertising and music.

[0000320193-23-000077:mdna:47]
[same as prior period, unchanged from 0000320193-23-000064:mdna:45]

[0000320193-23-000077:mdna:48]
Products and Services gross margin and gross margin percentage for the three- and nine-month periods ended July 1, 2023 and June 25, 2022 were as follows (dollars in millions):

[0000320193-23-000077:mdna:49]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1,2023 |  | June 25,2022 |  | July 1,2023 |  | June 25,2022 |
| Gross margin: |  |  |  |  |  |  |  |
| Products | $ | 21,448 |  |  | $ | 21,870 |  |  | $ | 84,205 |  |  | $ | 90,157 |  |
| Services | 14,965 |  |  | 14,015 |  |  | 44,516 |  |  | 42,530 |  |
| Total gross margin | $ | 36,413 |  |  | $ | 35,885 |  |  | $ | 128,721 |  |  | $ | 132,687 |  |

[0000320193-23-000077:mdna:50]
| Gross margin percentage: |  |  |  |  |  |  |  |
| Products | 35.4 | % |  | 34.5 | % |  | 36.5 | % |  | 36.8 | % |
| Services | 70.5 | % |  | 71.5 | % |  | 70.8 | % |  | 72.2 | % |
| Total gross margin percentage | 44.5 | % |  | 43.3 | % |  | 43.8 | % |  | 43.6 | % |

[0000320193-23-000077:mdna:51]
[same as prior period, unchanged from 0000320193-23-000064:mdna:49]

[0000320193-23-000077:mdna:52]
Products gross margin decreased during the third quarter and first nine months of 2023 compared to the same periods in 2022 due primarily to the weakness in foreign currencies relative to the U.S. dollar and lower Products volume, partially offset by cost savings and a different Products mix.

[0000320193-23-000077:mdna:53]
Products gross margin percentage increased during the third quarter of 2023 compared to the third quarter of 2022 due primarily to cost savings and a different Products mix, partially offset by the weakness in foreign currencies relative to the U.S. dollar and decreased leverage. Year-over-year Products gross margin percentage decreased during the first nine months of 2023 due primarily to the weakness in foreign currencies relative to the U.S. dollar and decreased leverage, partially offset by cost savings and a different Products mix.

[0000320193-23-000077:mdna:54]
[same as prior period, unchanged from 0000320193-23-000064:mdna:52]

[0000320193-23-000077:mdna:55]
Services gross margin increased during the third quarter and first nine months of 2023 compared to the same periods in 2022 due primarily to higher Services net sales, partially offset by the weakness in foreign currencies relative to the U.S. dollar and higher Services costs.

[0000320193-23-000077:mdna:56]
Services gross margin percentage decreased during the third quarter of 2023 compared to the third quarter of 2022 due primarily to higher Services costs, partially offset by improved leverage. Year-over-year Services gross margin percentage decreased during the first nine months of 2023 due primarily to higher Services costs and the weakness in foreign currencies relative to the U.S. dollar, partially offset by improved leverage.

[0000320193-23-000077:mdna:57]
[same as prior period, unchanged from 0000320193-23-000064:mdna:55]

[0000320193-23-000077:mdna:58]
[same as prior period, unchanged from 0000320193-23-000064:mdna:56]

[0000320193-23-000077:mdna:59]
Operating expenses for the three- and nine-month periods ended July 1, 2023 and June 25, 2022 were as follows (dollars in millions):

[0000320193-23-000077:mdna:60]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1,2023 |  | June 25,2022 |  | July 1,2023 |  | June 25,2022 |
| Research and development | $ | 7,442 |  |  | $ | 6,797 |  |  | $ | 22,608 |  |  | $ | 19,490 |  |
| Percentage of total net sales | 9 | % |  | 8 | % |  | 8 | % |  | 6 | % |
| Selling, general and administrative | $ | 5,973 |  |  | $ | 6,012 |  |  | $ | 18,781 |  |  | $ | 18,654 |  |
| Percentage of total net sales | 7 | % |  | 7 | % |  | 6 | % |  | 6 | % |
| Total operating expenses | $ | 13,415 |  |  | $ | 12,809 |  |  | $ | 41,389 |  |  | $ | 38,144 |  |
| Percentage of total net sales | 16 | % |  | 15 | % |  | 14 | % |  | 13 | % |

[0000320193-23-000077:mdna:61]
[same as prior period, unchanged from 0000320193-23-000064:mdna:59]

[0000320193-23-000077:mdna:62]
The growth in research and development (“R&D”) expense during the third quarter and first nine months of 2023 compared to the same periods in 2022 was driven primarily by increases in headcount-related expenses.

[0000320193-23-000077:mdna:63]
[same as prior period, unchanged from 0000320193-23-000064:mdna:61]

[0000320193-23-000077:mdna:64]
Selling, general and administrative expense was relatively flat during the third quarter and first nine months of 2023 compared to the same periods in 2022.

[0000320193-23-000077:mdna:65]
[same as prior period, unchanged from 0000320193-23-000064:mdna:63]

[0000320193-23-000077:mdna:66]
Provision for income taxes, effective tax rate and statutory federal income tax rate for the three- and nine-month periods ended July 1, 2023 and June 25, 2022 were as follows (dollars in millions):

[0000320193-23-000077:mdna:67]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1,2023 |  | June 25,2022 |  | July 1,2023 |  | June 25,2022 |
| Provision for income taxes | $ | 2,852 |  |  | $ | 3,624 |  |  | $ | 12,699 |  |  | $ | 15,364 |  |
| Effective tax rate | 12.5 | % |  | 15.7 | % |  | 14.6 | % |  | 16.3 | % |
| Statutory federal income tax rate | 21 | % |  | 21 | % |  | 21 | % |  | 21 | % |

[0000320193-23-000077:mdna:68]
The Company’s effective tax rate for the third quarter and first nine months of 2023 was lower than the statutory federal income tax rate due primarily to a lower effective tax rate on foreign earnings, including the favorable impact of changes in unrecognized tax benefits, tax benefits from share-based compensation, and the U.S. federal R&D credit, partially offset by state income taxes.

[0000320193-23-000077:mdna:69]
The Company’s effective tax rate for the third quarter of 2023 was lower compared to the third quarter of 2022 due primarily to a lower effective tax rate on foreign earnings, including the favorable impact of changes in unrecognized tax benefits, partially offset by lower tax benefits from share-based compensation. The Company’s effective tax rate for the first nine months of 2023 was lower compared to the same period in 2022 due primarily to a lower effective tax rate on foreign earnings and the impact of U.S. foreign tax credit regulations issued by the U.S. Department of the Treasury in 2022, partially offset by lower tax benefits from share-based compensation.

[0000320193-23-000077:mdna:70]
[same as prior period, unchanged from 0000320193-23-000064:mdna:68]

[0000320193-23-000077:mdna:71]
[same as prior period, unchanged from 0000320193-23-000064:mdna:69]

[0000320193-23-000077:mdna:72]
The Company’s contractual cash requirements have not changed materially since the 2022 Form 10-K, except for manufacturing purchase obligations.

[0000320193-23-000077:mdna:73]
[same as prior period, unchanged from 0000320193-23-000064:mdna:73]

[0000320193-23-000077:mdna:74]
The Company utilizes several outsourcing partners to manufacture subassemblies for the Company’s products and to perform final assembly and testing of finished products. The Company also obtains individual components for its products from a wide variety of individual suppliers. Outsourcing partners acquire components and build product based on demand information supplied by the Company, which typically covers periods up to 150 days. As of July 1, 2023, the Company had manufacturing purchase obligations of $38.4 billion, with $38.1 billion payable within 12 months. The Company’s manufacturing purchase obligations are primarily noncancelable.

[0000320193-23-000077:mdna:75]
[same as prior period, unchanged from 0000320193-23-000064:mdna:75]

[0000320193-23-000077:mdna:76]
In addition to its contractual cash requirements, the Company had authorized share repurchase programs as of July 1, 2023. The programs do not obligate the Company to acquire a minimum amount of shares. As of July 1, 2023, the Company’s quarterly cash dividend was $0.24 per share. The Company intends to increase its dividend on an annual basis, subject to declaration by the Board of Directors.

[0000320193-23-000077:mdna:77]
[same as prior period, unchanged from 0000320193-23-000064:mdna:78]

[0000320193-23-000077:mdna:78]
[same as prior period, unchanged from 0000320193-23-000064:mdna:79]
