# AAPL notes — 0000320193-23-000077


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000320193-23-000077:notes:1]
[same as prior period, unchanged from 0000320193-23-000064:notes:1]

[0000320193-23-000077:notes:2]
[same as prior period, unchanged from 0000320193-23-000064:notes:2]

[0000320193-23-000077:notes:3]
[same as prior period, unchanged from 0000320193-23-000064:notes:3]

[0000320193-23-000077:notes:4]
[same as prior period, unchanged from 0000320193-23-000064:notes:4]

[0000320193-23-000077:notes:5]
The following table shows the computation of basic and diluted earnings per share for the three- and nine-month periods ended July 1, 2023 and June 25, 2022 (net income in millions and shares in thousands):

[0000320193-23-000077:notes:6]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1,2023 |  | June 25,2022 |  | July 1,2023 |  | June 25,2022 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 19,881 |  |  | $ | 19,442 |  |  | $ | 74,039 |  |  | $ | 79,082 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 15,697,614 |  |  | 16,162,945 |  |  | 15,792,497 |  |  | 16,277,824 |  |
| Effect of dilutive securities | 77,407 |  |  | 99,258 |  |  | 66,766 |  |  | 117,113 |  |
| Weighted-average diluted shares | 15,775,021 |  |  | 16,262,203 |  |  | 15,859,263 |  |  | 16,394,937 |  |
| Basic earnings per share | $ | 1.27 |  |  | $ | 1.20 |  |  | $ | 4.69 |  |  | $ | 4.86 |  |
| Diluted earnings per share | $ | 1.26 |  |  | $ | 1.20 |  |  | $ | 4.67 |  |  | $ | 4.82 |  |

[0000320193-23-000077:notes:7]
Approximately 32 million restricted stock units (“RSUs”) were excluded from the computation of diluted earnings per share for the nine months ended July 1, 2023 because their effect would have been antidilutive.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000320193-23-000077:notes:8]
Revenue
Net sales disaggregated by significant products and services for the three- and nine-month periods ended July 1, 2023 and June 25, 2022 were as follows (in millions):

[0000320193-23-000077:notes:9]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1,2023 |  | June 25,2022 |  | July 1,2023 |  | June 25,2022 |
| iPhone® | $ | 39,669 |  |  | $ | 40,665 |  |  | $ | 156,778 |  |  | $ | 162,863 |  |
| Mac® | 6,840 |  |  | 7,382 |  |  | 21,743 |  |  | 28,669 |  |
| iPad® | 5,791 |  |  | 7,224 |  |  | 21,857 |  |  | 22,118 |  |
| Wearables, Home and Accessories | 8,284 |  |  | 8,084 |  |  | 30,523 |  |  | 31,591 |  |
| Services | 21,213 |  |  | 19,604 |  |  | 62,886 |  |  | 58,941 |  |
| Total net sales | $ | 81,797 |  |  | $ | 82,959 |  |  | $ | 293,787 |  |  | $ | 304,182 |  |

[0000320193-23-000077:notes:10]
Total net sales include $3.3 billion of revenue recognized in the three months ended July 1, 2023 that was included in deferred revenue as of April 1, 2023, $3.1 billion of revenue recognized in the three months ended June 25, 2022 that was included in deferred revenue as of March 26, 2022, $7.0 billion of revenue recognized in the nine months ended July 1, 2023 that was included in deferred revenue as of September 24, 2022, and $6.3 billion of revenue recognized in the nine months ended June 25, 2022 that was included in deferred revenue as of September 25, 2021.

[0000320193-23-000077:notes:11]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 10, “Segment Information and Geographic Data” for the three- and nine-month periods ended July 1, 2023 and June 25, 2022, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.

[0000320193-23-000077:notes:12]
As of July 1, 2023 and September 24, 2022, the Company had total deferred revenue of $12.2 billion and $12.4 billion, respectively. As of July 1, 2023, the Company expects 67% of total deferred revenue to be realized in less than a year, 26% within one-to-two years, 6% within two-to-three years and 1% in greater than three years.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000320193-23-000077:notes:13]
[same as prior period, unchanged from 0000320193-23-000064:notes:13]

[0000320193-23-000077:notes:14]
The following tables show the Company’s cash, cash equivalents and marketable securities by significant investment category as of July 1, 2023 and September 24, 2022 (in millions):

[0000320193-23-000077:notes:15]
|  | July 1, 2023 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | CurrentMarketableSecurities |  | Non-CurrentMarketableSecurities |
| Cash | $ | 25,337 |  |  | $ | — |  |  | $ | — |  |  | $ | 25,337 |  |  | $ | 25,337 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 1,108 |  |  | — |  |  | — |  |  | 1,108 |  |  | 1,108 |  |  | — |  |  | — |  |
| Mutual funds | 366 |  |  | 15 |  |  | (19) |  |  | 362 |  |  | — |  |  | 362 |  |  | — |  |
| Subtotal | 1,474 |  |  | 15 |  |  | (19) |  |  | 1,470 |  |  | 1,108 |  |  | 362 |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 22,274 |  |  | — |  |  | (1,354) |  |  | 20,920 |  |  | — |  |  | 8,076 |  |  | 12,844 |  |
| U.S. agency securities | 5,709 |  |  | — |  |  | (594) |  |  | 5,115 |  |  | 3 |  |  | 272 |  |  | 4,840 |  |
| Non-U.S. government securities | 17,588 |  |  | 19 |  |  | (927) |  |  | 16,680 |  |  | — |  |  | 11,262 |  |  | 5,418 |  |
| Certificates of deposit and time deposits | 2,315 |  |  | — |  |  | — |  |  | 2,315 |  |  | 1,960 |  |  | 355 |  |  | — |  |
| Commercial paper | 364 |  |  | — |  |  | — |  |  | 364 |  |  | — |  |  | 364 |  |  | — |  |
| Corporate debt securities | 79,621 |  |  | 22 |  |  | (6,079) |  |  | 73,564 |  |  | — |  |  | 13,005 |  |  | 60,559 |  |
| Municipal securities | 713 |  |  | — |  |  | (23) |  |  | 690 |  |  | — |  |  | 213 |  |  | 477 |  |
| Mortgage- and asset-backed securities | 22,383 |  |  | 4 |  |  | (2,299) |  |  | 20,088 |  |  | — |  |  | 165 |  |  | 19,923 |  |
| Subtotal | 150,967 |  |  | 45 |  |  | (11,276) |  |  | 139,736 |  |  | 1,963 |  |  | 33,712 |  |  | 104,061 |  |
| Total (3) | $ | 177,778 |  |  | $ | 60 |  |  | $ | (11,295) |  |  | $ | 166,543 |  |  | $ | 28,408 |  |  | $ | 34,074 |  |  | $ | 104,061 |  |

[0000320193-23-000077:notes:16]
[same as prior period, unchanged from 0000320193-23-000064:notes:16]

[0000320193-23-000077:notes:17]
[same as prior period, unchanged from 0000320193-23-000064:notes:17]

[0000320193-23-000077:notes:18]
[same as prior period, unchanged from 0000320193-23-000064:notes:18]

[0000320193-23-000077:notes:19]
(3)As of July 1, 2023 and September 24, 2022, total marketable securities included $14.1 billion and $12.7 billion, respectively, that were restricted from general use, related to the State Aid Decision (refer to Note 5, “Income Taxes”) and other agreements.

[0000320193-23-000077:notes:20]
The following table shows the fair value of the Company’s non-current marketable debt securities, by contractual maturity, as of July 1, 2023 (in millions):

[0000320193-23-000077:notes:21]
| Due after 1 year through 5 years | $ | 76,267 |  |
| Due after 5 years through 10 years | 11,148 |  |
| Due after 10 years | 16,646 |  |
| Total fair value | $ | 104,061 |  |

[0000320193-23-000077:notes:22]
[same as prior period, unchanged from 0000320193-23-000064:notes:22]

[0000320193-23-000077:notes:23]
[same as prior period, unchanged from 0000320193-23-000064:notes:23]

[0000320193-23-000077:notes:24]
[same as prior period, unchanged from 0000320193-23-000064:notes:24]

[0000320193-23-000077:notes:25]
[same as prior period, unchanged from 0000320193-23-000064:notes:25]

[0000320193-23-000077:notes:26]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in foreign currency exchange rates, the Company may enter into forward contracts, cross-currency swaps or other instruments. The Company designates these instruments as either cash flow or fair value hedges. As of July 1, 2023, the maximum length of time over which the Company is hedging its exposure to the variability in future cash flows for term debt–related foreign currency transactions is 19 years.

[0000320193-23-000077:notes:27]
[same as prior period, unchanged from 0000320193-23-000064:notes:27]

[0000320193-23-000077:notes:28]
[same as prior period, unchanged from 0000320193-23-000064:notes:28]

[0000320193-23-000077:notes:29]
[same as prior period, unchanged from 0000320193-23-000064:notes:29]

[0000320193-23-000077:notes:30]
The notional amounts of the Company’s outstanding derivative instruments as of July 1, 2023 and September 24, 2022 were as follows (in millions):

[0000320193-23-000077:notes:31]
|  | July 1,2023 |  | September 24,2022 |
| Derivative instruments designated as accounting hedges: |  |  |  |
| Foreign exchange contracts | $ | 45,425 |  |  | $ | 102,670 |  |
| Interest rate contracts | $ | 19,375 |  |  | $ | 20,125 |  |
| Derivative instruments not designated as accounting hedges: |  |  |  |
| Foreign exchange contracts | $ | 90,977 |  |  | $ | 185,381 |  |

[0000320193-23-000077:notes:32]
[same as prior period, unchanged from 0000320193-23-000064:notes:32]

[0000320193-23-000077:notes:33]
[same as prior period, unchanged from 0000320193-23-000064:notes:33]

[0000320193-23-000077:notes:34]
[same as prior period, unchanged from 0000320193-23-000064:notes:34]

[0000320193-23-000077:notes:35]
[same as prior period, unchanged from 0000320193-23-000064:notes:35]

[0000320193-23-000077:notes:36]
[same as prior period, unchanged from 0000320193-23-000064:notes:36]

[0000320193-23-000077:notes:37]
The carrying amounts of the Company’s hedged items in fair value hedges as of July 1, 2023 and September 24, 2022 were as follows (in millions):

[0000320193-23-000077:notes:38]
|  | July 1,2023 |  | September 24,2022 |
| Hedged assets/(liabilities): |  |  |  |
| Current and non-current marketable securities | $ | 14,863 |  |  | $ | 13,378 |  |
| Current and non-current term debt | $ | (17,986) |  |  | $ | (18,739) |  |

[0000320193-23-000077:notes:39]
[same as prior period, unchanged from 0000320193-23-000064:notes:39]

[0000320193-23-000077:notes:40]
[same as prior period, unchanged from 0000320193-23-000064:notes:40]

[0000320193-23-000077:notes:41]
[same as prior period, unchanged from 0000320193-23-000064:notes:41]

[0000320193-23-000077:notes:42]
As of September 24, 2022, the Company had one customer that represented 10% or more of total trade receivables, which accounted for 10%. The Company’s cellular network carriers accounted for 44% of total trade receivables as of September 24, 2022.

[0000320193-23-000077:notes:43]
[same as prior period, unchanged from 0000320193-23-000064:notes:43]

[0000320193-23-000077:notes:44]
The Company has non-trade receivables from certain of its manufacturing vendors resulting from the sale of components to these vendors who manufacture subassemblies or assemble final products for the Company. The Company purchases these components directly from suppliers. As of July 1, 2023, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 54% and 14%. As of September 24, 2022, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 54% and 13%.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000320193-23-000077:notes:45]
[same as prior period, unchanged from 0000320193-23-000064:notes:45]


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000320193-23-000077:notes:46]
Condensed Consolidated Financial Statement Details
The following tables show the Company’s condensed consolidated financial statement details as of July 1, 2023 and September 24, 2022 (in millions):

[0000320193-23-000077:notes:47]
[same as prior period, unchanged from 0000320193-23-000064:notes:47]

[0000320193-23-000077:notes:48]
|  | July 1,2023 |  | September 24,2022 |
| Components | $ | 3,788 |  |  | $ | 1,637 |  |
| Finished goods | 3,563 |  |  | 3,309 |  |
| Total inventories | $ | 7,351 |  |  | $ | 4,946 |  |

[0000320193-23-000077:notes:49]
[same as prior period, unchanged from 0000320193-23-000064:notes:49]

[0000320193-23-000077:notes:50]
|  | July 1,2023 |  | September 24,2022 |
| Gross property, plant and equipment | $ | 114,337 |  |  | $ | 114,457 |  |
| Accumulated depreciation and amortization | (70,787) |  |  | (72,340) |  |
| Total property, plant and equipment, net | $ | 43,550 |  |  | $ | 42,117 |  |

[0000320193-23-000077:notes:51]
[same as prior period, unchanged from 0000320193-23-000064:notes:51]

[0000320193-23-000077:notes:52]
The following table shows the detail of other income/(expense), net for the three- and nine-month periods ended July 1, 2023 and June 25, 2022 (in millions):

[0000320193-23-000077:notes:53]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1,2023 |  | June 25,2022 |  | July 1,2023 |  | June 25,2022 |
| Interest and dividend income | $ | 980 |  |  | $ | 722 |  |  | $ | 2,766 |  |  | $ | 2,072 |  |
| Interest expense | (998) |  |  | (719) |  |  | (2,931) |  |  | (2,104) |  |
| Other expense, net | (247) |  |  | (13) |  |  | (429) |  |  | (65) |  |
| Total other income/(expense), net | $ | (265) |  |  | $ | (10) |  |  | $ | (594) |  |  | $ | (97) |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000320193-23-000077:notes:54]
[same as prior period, unchanged from 0000320193-23-000064:notes:54]

[0000320193-23-000077:notes:55]
On August 30, 2016, the European Commission announced its decision that Ireland granted state aid to the Company by providing tax opinions in 1991 and 2007 concerning the tax allocation of profits of the Irish branches of two subsidiaries of the Company (the “State Aid Decision”). The State Aid Decision ordered Ireland to calculate and recover additional taxes from the Company for the period June 2003 through December 2014. Irish legislative changes, effective as of January 2015, eliminated the application of the tax opinions from that date forward. The Company and Ireland appealed the State Aid Decision to the General Court of the Court of Justice of the European Union (the “General Court”). On July 15, 2020, the General Court annulled the State Aid Decision. On September 25, 2020, the European Commission appealed the General Court’s decision to the European Court of Justice (the “ECJ”) and a hearing was held on May 23, 2023. A decision from the ECJ is expected in calendar year 2024. The Company believes it would be eligible to claim a U.S. foreign tax credit for a portion of any incremental Irish corporate income taxes potentially due related to the State Aid Decision.


## us-gaap:DebtDisclosureTextBlock

[0000320193-23-000077:notes:56]
Debt
Commercial Paper

[0000320193-23-000077:notes:57]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of July 1, 2023 and September 24, 2022, the Company had $4.0 billion and $10.0 billion of Commercial Paper outstanding, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the nine months ended July 1, 2023 and June 25, 2022 (in millions):

[0000320193-23-000077:notes:58]
|  | Nine Months Ended |
|  | July 1,2023 |  | June 25,2022 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | (3,326) |  |  | $ | 4,383 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | — |  |  | 5,731 |  |
| Repayments of commercial paper | (2,645) |  |  | (5,144) |  |
| Proceeds from/(Repayments of) commercial paper, net | (2,645) |  |  | 587 |  |
| Total proceeds from/(repayments of) commercial paper, net | $ | (5,971) |  |  | $ | 4,970 |  |

[0000320193-23-000077:notes:59]
Term Debt

[0000320193-23-000077:notes:60]
As of July 1, 2023 and September 24, 2022, the Company had outstanding fixed-rate notes with varying maturities for an aggregate carrying amount of $105.3 billion and $110.1 billion, respectively (collectively the “Notes”). As of July 1, 2023 and September 24, 2022, the fair value of the Company’s Notes, based on Level 2 inputs, was $95.3 billion and $98.8 billion, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000320193-23-000077:notes:61]
[same as prior period, unchanged from 0000320193-23-000064:notes:61]

[0000320193-23-000077:notes:62]
During the nine months ended July 1, 2023, the Company repurchased 365 million shares of its common stock for $56.1 billion, excluding excise tax due under the Inflation Reduction Act of 2022. The Company’s share repurchase programs do not obligate the Company to acquire a minimum amount of shares. Under the programs, shares may be repurchased in privately negotiated or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000320193-23-000077:notes:63]
[same as prior period, unchanged from 0000320193-23-000064:notes:63]

[0000320193-23-000077:notes:64]
A summary of the Company’s RSU activity and related information for the nine months ended July 1, 2023 is as follows:

[0000320193-23-000077:notes:65]
|  | Number ofRSUs(in thousands) |  | Weighted-AverageGrant Date FairValue Per RSU |  | AggregateFair Value(in millions) |
| Balance as of September 24, 2022 | 201,501 |  |  | $ | 109.48 |  |  |  |
| RSUs granted | 86,896 |  |  | $ | 150.23 |  |  |  |
| RSUs vested | (96,681) |  |  | $ | 95.97 |  |  |  |
| RSUs canceled | (7,000) |  |  | $ | 126.48 |  |  |  |
| Balance as of July 1, 2023 | 184,716 |  |  | $ | 135.08 |  |  | $ | 35,829 |  |

[0000320193-23-000077:notes:66]
The fair value as of the respective vesting dates of RSUs was $7.0 billion and $14.9 billion for the three- and nine-month periods ended July 1, 2023, respectively, and was $7.8 billion and $17.3 billion for the three- and nine-month periods ended June 25, 2022, respectively.

[0000320193-23-000077:notes:67]
[same as prior period, unchanged from 0000320193-23-000064:notes:67]

[0000320193-23-000077:notes:68]
The following table shows share-based compensation expense and the related income tax benefit included in the Condensed Consolidated Statements of Operations for the three- and nine-month periods ended July 1, 2023 and June 25, 2022 (in millions):

[0000320193-23-000077:notes:69]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1,2023 |  | June 25,2022 |  | July 1,2023 |  | June 25,2022 |
| Share-based compensation expense | $ | 2,617 |  |  | $ | 2,243 |  |  | $ | 8,208 |  |  | $ | 6,760 |  |
| Income tax benefit related to share-based compensation expense | $ | (993) |  |  | $ | (1,231) |  |  | $ | (2,791) |  |  | $ | (3,416) |  |

[0000320193-23-000077:notes:70]
As of July 1, 2023, the total unrecognized compensation cost related to outstanding RSUs and stock options was $20.9 billion, which the Company expects to recognize over a weighted-average period of 2.7 years.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000320193-23-000077:notes:71]
Commitments and Contingencies
Unconditional Purchase Obligations

[0000320193-23-000077:notes:72]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of supplier arrangements, licensed intellectual property and content, and distribution rights. Future payments under noncancelable unconditional purchase obligations with a remaining term in excess of one year as of July 1, 2023, are as follows (in millions):

[0000320193-23-000077:notes:73]
| 2023 (remaining three months) | $ | 1,260 |  |
| 2024 | 3,417 |  |
| 2025 | 1,990 |  |
| 2026 | 3,079 |  |
| 2027 | 1,013 |  |
| Thereafter | 8,198 |  |
| Total | $ | 18,957 |  |

[0000320193-23-000077:notes:74]
Contingencies

[0000320193-23-000077:notes:75]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully resolved. The outcome of litigation is inherently uncertain. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss greater than a recorded accrual, concerning loss contingencies for asserted legal and other claims.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000320193-23-000077:notes:76]
Segment Information and Geographic Data
The following table shows information by reportable segment for the three- and nine-month periods ended July 1, 2023 and June 25, 2022 (in millions):

[0000320193-23-000077:notes:77]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1,2023 |  | June 25,2022 |  | July 1,2023 |  | June 25,2022 |
| Americas: |  |  |  |  |  |  |  |
| Net sales | $ | 35,383 |  |  | $ | 37,472 |  |  | $ | 122,445 |  |  | $ | 129,850 |  |
| Operating income | $ | 13,117 |  |  | $ | 13,914 |  |  | $ | 44,908 |  |  | $ | 48,778 |  |
| Europe: |  |  |  |  |  |  |  |
| Net sales | $ | 20,205 |  |  | $ | 19,287 |  |  | $ | 71,831 |  |  | $ | 72,323 |  |
| Operating income | $ | 7,995 |  |  | $ | 7,124 |  |  | $ | 27,380 |  |  | $ | 27,174 |  |
| Greater China: |  |  |  |  |  |  |  |
| Net sales | $ | 15,758 |  |  | $ | 14,604 |  |  | $ | 57,475 |  |  | $ | 58,730 |  |
| Operating income | $ | 6,207 |  |  | $ | 5,760 |  |  | $ | 24,175 |  |  | $ | 25,055 |  |
| Japan: |  |  |  |  |  |  |  |
| Net sales | $ | 4,821 |  |  | $ | 5,446 |  |  | $ | 18,752 |  |  | $ | 20,277 |  |
| Operating income | $ | 2,443 |  |  | $ | 2,418 |  |  | $ | 9,073 |  |  | $ | 9,263 |  |
| Rest of Asia Pacific: |  |  |  |  |  |  |  |
| Net sales | $ | 5,630 |  |  | $ | 6,150 |  |  | $ | 23,284 |  |  | $ | 23,002 |  |
| Operating income | $ | 2,328 |  |  | $ | 2,367 |  |  | $ | 9,447 |  |  | $ | 9,185 |  |

[0000320193-23-000077:notes:78]
A reconciliation of the Company’s segment operating income to the Condensed Consolidated Statements of Operations for the three- and nine-month periods ended July 1, 2023 and June 25, 2022 is as follows (in millions):

[0000320193-23-000077:notes:79]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1,2023 |  | June 25,2022 |  | July 1,2023 |  | June 25,2022 |
| Segment operating income | $ | 32,090 |  |  | $ | 31,583 |  |  | $ | 114,983 |  |  | $ | 119,455 |  |
| Research and development expense | (7,442) |  |  | (6,797) |  |  | (22,608) |  |  | (19,490) |  |
| Other corporate expenses, net | (1,650) |  |  | (1,710) |  |  | (5,043) |  |  | (5,422) |  |
| Total operating income | $ | 22,998 |  |  | $ | 23,076 |  |  | $ | 87,332 |  |  | $ | 94,543 |  |
