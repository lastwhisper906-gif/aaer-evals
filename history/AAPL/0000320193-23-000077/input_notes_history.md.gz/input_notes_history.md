# AAPL note change history — 0000320193-23-000064 → 0000320193-23-000077


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-08-04):
[0000320193-23-000077:note_history:1]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of supplier arrangements, licensed intellectual property and content, and distribution rights. Future payments under noncancelable unconditional purchase obligations with a remaining term in excess of one year as of July 1, 2023, are as follows (in millions):
  (was, 2023-05-05, similarity 0.6375):
[0000320193-23-000064:note_history:1]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of supplier arrangements, licensed content and distribution rights. Future payments under noncancelable unconditional purchase obligations with a remaining term in excess of one year as of April 1, 2023, are as follows (in millions):

- changed (2023-08-04):
[0000320193-23-000077:note_history:2]
| 2023 (remaining three months) | $ | 1,260 |  |
| 2024 | 3,417 |  |
| 2025 | 1,990 |  |
| 2026 | 3,079 |  |
| 2027 | 1,013 |  |
| Thereafter | 8,198 |  |
| Total | $ | 18,957 |  |
  (was, 2023-05-05, similarity 0.9688):
[0000320193-23-000064:note_history:2]
| 2023 (remaining six months) | $ | 2,263 |  |
| 2024 | 2,716 |  |
| 2025 | 2,028 |  |
| 2026 | 2,602 |  |
| 2027 | 571 |  |
| Thereafter | 5,897 |  |
| Total | $ | 16,077 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-08-04):
[0000320193-23-000077:note_history:3]
The following table shows the computation of basic and diluted earnings per share for the three- and nine-month periods ended July 1, 2023 and June 25, 2022 (net income in millions and shares in thousands):
  (was, 2023-05-05, similarity 0.9468):
[0000320193-23-000064:note_history:3]
The following table shows the computation of basic and diluted earnings per share for the three- and six-month periods ended April 1, 2023 and March 26, 2022 (net income in millions and shares in thousands):

- changed (2023-08-04):
[0000320193-23-000077:note_history:4]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1,2023 |  | June 25,2022 |  | July 1,2023 |  | June 25,2022 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 19,881 |  |  | $ | 19,442 |  |  | $ | 74,039 |  |  | $ | 79,082 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 15,697,614 |  |  | 16,162,945 |  |  | 15,792,497 |  |  | 16,277,824 |  |
| Effect of dilutive securities | 77,407 |  |  | 99,258 |  |  | 66,766 |  |  | 117,113 |  |
| Weighted-average diluted shares | 15,775,021 |  |  | 16,262,203 |  |  | 15,859,263 |  |  | 16,394,937 |  |
| Basic earnings per share | $ | 1.27 |  |  | $ | 1.20 |  |  | $ | 4.69 |  |  | $ | 4.86 |  |
| Diluted earnings per share | $ | 1.26 |  |  | $ | 1.20 |  |  | $ | 4.67 |  |  | $ | 4.82 |  |
  (was, 2023-05-05, similarity 0.8943):
[0000320193-23-000064:note_history:4]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1,2023 |  | March 26,2022 |  | April 1,2023 |  | March 26,2022 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 24,160 |  |  | $ | 25,010 |  |  | $ | 54,158 |  |  | $ | 59,640 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 15,787,154 |  |  | 16,278,802 |  |  | 15,839,939 |  |  | 16,335,263 |  |
| Effect of dilutive securities | 59,896 |  |  | 124,514 |  |  | 61,445 |  |  | 126,041 |  |
| Weighted-average diluted shares | 15,847,050 |  |  | 16,403,316 |  |  | 15,901,384 |  |  | 16,461,304 |  |
| Basic earnings per share | $ | 1.53 |  |  | $ | 1.54 |  |  | $ | 3.42 |  |  | $ | 3.65 |  |
| Diluted earnings per share | $ | 1.52 |  |  | $ | 1.52 |  |  | $ | 3.41 |  |  | $ | 3.62 |  |

- changed (2023-08-04):
[0000320193-23-000077:note_history:5]
Approximately 32 million restricted stock units (“RSUs”) were excluded from the computation of diluted earnings per share for the nine months ended July 1, 2023 because their effect would have been antidilutive.
  (was, 2023-05-05, similarity 0.8932):
[0000320193-23-000064:note_history:5]
Approximately 48 million restricted stock units (“RSUs”) were excluded from the computation of diluted earnings per share for the six months ended April 1, 2023 because their effect would have been antidilutive.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-08-04):
[0000320193-23-000077:note_history:6]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of July 1, 2023 and September 24, 2022, the Company had $4.0 billion and $10.0 billion of Commercial Paper outstanding, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the nine months ended July 1, 2023 and June 25, 2022 (in millions):
  (was, 2023-05-05, similarity 0.9284):
[0000320193-23-000064:note_history:6]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of April 1, 2023 and September 24, 2022, the Company had $2.0 billion and $10.0 billion of Commercial Paper outstanding, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the six months ended April 1, 2023 and March 26, 2022 (in millions):

- added (2023-08-04):
[0000320193-23-000077:note_history:7]
|  | Nine Months Ended |
|  | July 1,2023 |  | June 25,2022 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | (3,326) |  |  | $ | 4,383 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | — |  |  | 5,731 |  |
| Repayments of commercial paper | (2,645) |  |  | (5,144) |  |
| Proceeds from/(Repayments of) commercial paper, net | (2,645) |  |  | 587 |  |
| Total proceeds from/(repayments of) commercial paper, net | $ | (5,971) |  |  | $ | 4,970 |  |

- changed (2023-08-04):
[0000320193-23-000077:note_history:8]
As of July 1, 2023 and September 24, 2022, the Company had outstanding fixed-rate notes with varying maturities for an aggregate carrying amount of $105.3 billion and $110.1 billion, respectively (collectively the “Notes”). As of July 1, 2023 and September 24, 2022, the fair value of the Company’s Notes, based on Level 2 inputs, was $95.3 billion and $98.8 billion, respectively.
  (was, 2023-05-05, similarity 0.9741):
[0000320193-23-000064:note_history:8]
As of April 1, 2023 and September 24, 2022, the Company had outstanding fixed-rate notes with varying maturities for an aggregate carrying amount of $107.6 billion and $110.1 billion, respectively (collectively the “Notes”). As of April 1, 2023 and September 24, 2022, the fair value of the Company’s Notes, based on Level 2 inputs, was $98.4 billion and $98.8 billion, respectively.

- removed (2023-08-04):
[0000320193-23-000064:note_history:9]
|  | Six Months Ended |
|  | April 1,2023 |  | March 26,2022 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | (5,315) |  |  | $ | 4,952 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | — |  |  | 1,191 |  |
| Repayments of commercial paper | (2,645) |  |  | (5,144) |  |
| Repayments of commercial paper, net | (2,645) |  |  | (3,953) |  |
| Total proceeds from/(repayments of) commercial paper, net | $ | (7,960) |  |  | $ | 999 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-08-04):
[0000320193-23-000077:note_history:10]
Net sales disaggregated by significant products and services for the three- and nine-month periods ended July 1, 2023 and June 25, 2022 were as follows (in millions):
  (was, 2023-05-05, similarity 0.9333):
[0000320193-23-000064:note_history:10]
Net sales disaggregated by significant products and services for the three- and six-month periods ended April 1, 2023 and March 26, 2022 were as follows (in millions):

- changed (2023-08-04):
[0000320193-23-000077:note_history:11]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1,2023 |  | June 25,2022 |  | July 1,2023 |  | June 25,2022 |
| iPhone® | $ | 39,669 |  |  | $ | 40,665 |  |  | $ | 156,778 |  |  | $ | 162,863 |  |
| Mac® | 6,840 |  |  | 7,382 |  |  | 21,743 |  |  | 28,669 |  |
| iPad® | 5,791 |  |  | 7,224 |  |  | 21,857 |  |  | 22,118 |  |
| Wearables, Home and Accessories | 8,284 |  |  | 8,084 |  |  | 30,523 |  |  | 31,591 |  |
| Services | 21,213 |  |  | 19,604 |  |  | 62,886 |  |  | 58,941 |  |
| Total net sales | $ | 81,797 |  |  | $ | 82,959 |  |  | $ | 293,787 |  |  | $ | 304,182 |  |
  (was, 2023-05-05, similarity 0.8508):
[0000320193-23-000064:note_history:11]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1,2023 |  | March 26,2022 |  | April 1,2023 |  | March 26,2022 |
| iPhone® | $ | 51,334 |  |  | $ | 50,570 |  |  | $ | 117,109 |  |  | $ | 122,198 |  |
| Mac® | 7,168 |  |  | 10,435 |  |  | 14,903 |  |  | 21,287 |  |
| iPad® | 6,670 |  |  | 7,646 |  |  | 16,066 |  |  | 14,894 |  |
| Wearables, Home and Accessories | 8,757 |  |  | 8,806 |  |  | 22,239 |  |  | 23,507 |  |
| Services | 20,907 |  |  | 19,821 |  |  | 41,673 |  |  | 39,337 |  |
| Total net sales | $ | 94,836 |  |  | $ | 97,278 |  |  | $ | 211,990 |  |  | $ | 221,223 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-08-04):
[0000320193-23-000077:note_history:12]
Revenue
Net sales disaggregated by significant products and services for the three- and nine-month periods ended July 1, 2023 and June 25, 2022 were as follows (in millions):
  (was, 2023-05-05, similarity 0.9366):
[0000320193-23-000064:note_history:12]
Revenue
Net sales disaggregated by significant products and services for the three- and six-month periods ended April 1, 2023 and March 26, 2022 were as follows (in millions):

- changed (2023-08-04):
[0000320193-23-000077:note_history:13]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1,2023 |  | June 25,2022 |  | July 1,2023 |  | June 25,2022 |
| iPhone® | $ | 39,669 |  |  | $ | 40,665 |  |  | $ | 156,778 |  |  | $ | 162,863 |  |
| Mac® | 6,840 |  |  | 7,382 |  |  | 21,743 |  |  | 28,669 |  |
| iPad® | 5,791 |  |  | 7,224 |  |  | 21,857 |  |  | 22,118 |  |
| Wearables, Home and Accessories | 8,284 |  |  | 8,084 |  |  | 30,523 |  |  | 31,591 |  |
| Services | 21,213 |  |  | 19,604 |  |  | 62,886 |  |  | 58,941 |  |
| Total net sales | $ | 81,797 |  |  | $ | 82,959 |  |  | $ | 293,787 |  |  | $ | 304,182 |  |
  (was, 2023-05-05, similarity 0.8508):
[0000320193-23-000064:note_history:13]
|  | Three Months Ended |  | Six Months Ended |
|  | April 1,2023 |  | March 26,2022 |  | April 1,2023 |  | March 26,2022 |
| iPhone® | $ | 51,334 |  |  | $ | 50,570 |  |  | $ | 117,109 |  |  | $ | 122,198 |  |
| Mac® | 7,168 |  |  | 10,435 |  |  | 14,903 |  |  | 21,287 |  |
| iPad® | 6,670 |  |  | 7,646 |  |  | 16,066 |  |  | 14,894 |  |
| Wearables, Home and Accessories | 8,757 |  |  | 8,806 |  |  | 22,239 |  |  | 23,507 |  |
| Services | 20,907 |  |  | 19,821 |  |  | 41,673 |  |  | 39,337 |  |
| Total net sales | $ | 94,836 |  |  | $ | 97,278 |  |  | $ | 211,990 |  |  | $ | 221,223 |  |

- added (2023-08-04):
[0000320193-23-000077:note_history:14]
Total net sales include $3.3 billion of revenue recognized in the three months ended July 1, 2023 that was included in deferred revenue as of April 1, 2023, $3.1 billion of revenue recognized in the three months ended June 25, 2022 that was included in deferred revenue as of March 26, 2022, $7.0 billion of revenue recognized in the nine months ended July 1, 2023 that was included in deferred revenue as of September 24, 2022, and $6.3 billion of revenue recognized in the nine months ended June 25, 2022 that was included in deferred revenue as of September 25, 2021.

- changed (2023-08-04):
[0000320193-23-000077:note_history:15]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 10, “Segment Information and Geographic Data” for the three- and nine-month periods ended July 1, 2023 and June 25, 2022, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.
  (was, 2023-05-05, similarity 0.7278):
[0000320193-23-000064:note_history:15]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 10, “Segment Information and Geographic Data” for the three- and six-month periods ended April 1, 2023 and March 26, 2022, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.

- added (2023-08-04):
[0000320193-23-000077:note_history:16]
As of July 1, 2023 and September 24, 2022, the Company had total deferred revenue of $12.2 billion and $12.4 billion, respectively. As of July 1, 2023, the Company expects 67% of total deferred revenue to be realized in less than a year, 26% within one-to-two years, 6% within two-to-three years and 1% in greater than three years.

- removed (2023-08-04):
[0000320193-23-000064:note_history:17]
Total net sales include $3.5 billion of revenue recognized in the three months ended April 1, 2023 that was included in deferred revenue as of December 31, 2022, $3.0 billion of revenue recognized in the three months ended March 26, 2022 that was included in deferred revenue as of December 25, 2021, $5.5 billion of revenue recognized in the six months ended April 1, 2023 that was included in deferred revenue as of September 24, 2022, and $4.8 billion of revenue recognized in the six months ended March 26, 2022 that was included in deferred revenue as of September 25, 2021.

- removed (2023-08-04):
[0000320193-23-000064:note_history:18]
As of April 1, 2023 and September 24, 2022, the Company had total deferred revenue of $12.5 billion and $12.4 billion, respectively. As of April 1, 2023, the Company expects 65% of total deferred revenue to be realized in less than a year, 26% within one-to-two years, 7% within two-to-three years and 2% in greater than three years.
