# AAPL note change history — 0000320193-25-000008 → 0000320193-25-000057


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-02):
[0000320193-25-000057:note_history:1]
The Company issues unsecured short-term promissory notes pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of March 29, 2025 and September 28, 2024, the Company had $6.0 billion and $10.0 billion of commercial paper outstanding, respectively.
  (was, 2025-01-31, similarity 0.9458):
[0000320193-25-000008:note_history:1]
The Company issues unsecured short-term promissory notes pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of December 28, 2024 and September 28, 2024, the Company had $2.0 billion and $10.0 billion of commercial paper outstanding, respectively.

- changed (2025-05-02):
[0000320193-25-000057:note_history:2]
As of March 29, 2025 and September 28, 2024, the Company had outstanding fixed-rate notes with varying maturities for an aggregate carrying amount of $92.2 billion and $96.7 billion, respectively (collectively the “Notes”). As of March 29, 2025 and September 28, 2024, the fair value of the Company’s Notes, based on Level 2 inputs, was $80.9 billion and $88.4 billion, respectively.
  (was, 2025-01-31, similarity 0.9631):
[0000320193-25-000008:note_history:2]
As of December 28, 2024 and September 28, 2024, the Company had outstanding fixed-rate notes with varying maturities for an aggregate carrying amount of $94.8 billion and $96.7 billion, respectively (collectively the “Notes”). As of December 28, 2024 and September 28, 2024, the fair value of the Company’s Notes, based on Level 2 inputs, was $82.7 billion and $88.4 billion, respectively.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: no_current_note, score: 0.0

- removed (2025-05-02):
[0000320193-25-000008:note_history:3]
Net sales disaggregated by significant products and services for the three months ended December 28, 2024 and December 30, 2023 were as follows (in millions):

- removed (2025-05-02):
[0000320193-25-000008:note_history:4]
|  | Three Months Ended |  |  |
|  | December 28,2024 |  | December 30,2023 |  |  |  |  |
| iPhone® | $ | 69,138 |  |  | $ | 69,702 |  |  |  |  |  |
| Mac® | 8,987 |  |  | 7,780 |  |  |  |  |  |
| iPad® | 8,088 |  |  | 7,023 |  |  |  |  |  |
| Wearables, Home and Accessories | 11,747 |  |  | 11,953 |  |  |  |  |  |
| Services | 26,340 |  |  | 23,117 |  |  |  |  |  |
| Total net sales | $ | 124,300 |  |  | $ | 119,575 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2025-05-02):
[0000320193-25-000057:note_history:5]
Revenue
The following table shows disaggregated net sales, as well as the portion of total net sales that was previously deferred, for the three- and six-month periods ended March 29, 2025 and March 30, 2024 (in millions):

- changed (2025-05-02):
[0000320193-25-000057:note_history:6]
|  | Three Months Ended |  | Six Months Ended |
|  | March 29,2025 |  | March 30,2024 |  | March 29,2025 |  | March 30,2024 |
| iPhone® | $ | 46,841 |  |  | $ | 45,963 |  |  | $ | 115,979 |  |  | $ | 115,665 |  |
| Mac® | 7,949 |  |  | 7,451 |  |  | 16,936 |  |  | 15,231 |  |
| iPad® | 6,402 |  |  | 5,559 |  |  | 14,490 |  |  | 12,582 |  |
| Wearables, Home and Accessories | 7,522 |  |  | 7,913 |  |  | 19,269 |  |  | 19,866 |  |
| Services | 26,645 |  |  | 23,867 |  |  | 52,985 |  |  | 46,984 |  |
| Total net sales | $ | 95,359 |  |  | $ | 90,753 |  |  | $ | 219,659 |  |  | $ | 210,328 |  |
| Portion of total net sales that was included in deferred revenue as of the beginning of the period | $ | 3,672 |  |  | $ | 3,282 |  |  | $ | 5,440 |  |  | $ | 5,135 |  |
  (was, 2025-01-31, similarity 0.6124):
[0000320193-25-000008:note_history:6]
|  | Three Months Ended |  |  |
|  | December 28,2024 |  | December 30,2023 |  |  |  |  |
| iPhone® | $ | 69,138 |  |  | $ | 69,702 |  |  |  |  |  |
| Mac® | 8,987 |  |  | 7,780 |  |  |  |  |  |
| iPad® | 8,088 |  |  | 7,023 |  |  |  |  |  |
| Wearables, Home and Accessories | 11,747 |  |  | 11,953 |  |  |  |  |  |
| Services | 26,340 |  |  | 23,117 |  |  |  |  |  |
| Total net sales | $ | 124,300 |  |  | $ | 119,575 |  |  |  |  |  |

- changed (2025-05-02):
[0000320193-25-000057:note_history:7]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 10, “Segment Information and Geographic Data” for the three- and six-month periods ended March 29, 2025 and March 30, 2024, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.
  (was, 2025-01-31, similarity 0.8525):
[0000320193-25-000008:note_history:7]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 10, “Segment Information and Geographic Data” for the three months ended December 28, 2024 and December 30, 2023, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.

- changed (2025-05-02):
[0000320193-25-000057:note_history:8]
As of March 29, 2025 and September 28, 2024, the Company had total deferred revenue of $13.6 billion and $12.8 billion, respectively. As of March 29, 2025, the Company expects 66% of total deferred revenue to be realized in less than a year, 24% within one-to-two years, 9% within two-to-three years and 1% in greater than three years.
  (was, 2025-01-31, similarity 0.9585):
[0000320193-25-000008:note_history:8]
As of December 28, 2024 and September 28, 2024, the Company had total deferred revenue of $13.2 billion and $12.8 billion, respectively. As of December 28, 2024, the Company expects 64% of total deferred revenue to be realized in less than a year, 25% within one-to-two years, 9% within two-to-three years and 2% in greater than three years.

- removed (2025-05-02):
[0000320193-25-000008:note_history:9]
Revenue
Net sales disaggregated by significant products and services for the three months ended December 28, 2024 and December 30, 2023 were as follows (in millions):

- removed (2025-05-02):
[0000320193-25-000008:note_history:10]
Total net sales include $3.7 billion of revenue recognized in the three months ended December 28, 2024 that was included in deferred revenue as of September 28, 2024 and $3.5 billion of revenue recognized in the three months ended December 30, 2023 that was included in deferred revenue as of September 30, 2023.
