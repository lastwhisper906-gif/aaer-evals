# AAPL notes — 0000320193-25-000057


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000320193-25-000057:notes:1]
[same as prior period, unchanged from 0000320193-25-000008:notes:1]

[0000320193-25-000057:notes:2]
[same as prior period, unchanged from 0000320193-25-000008:notes:2]

[0000320193-25-000057:notes:3]
[same as prior period, unchanged from 0000320193-25-000008:notes:3]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000320193-25-000057:notes:4]
Revenue
The following table shows disaggregated net sales, as well as the portion of total net sales that was previously deferred, for the three- and six-month periods ended March 29, 2025 and March 30, 2024 (in millions):

[0000320193-25-000057:notes:5]
|  | Three Months Ended |  | Six Months Ended |
|  | March 29,2025 |  | March 30,2024 |  | March 29,2025 |  | March 30,2024 |
| iPhone® | $ | 46,841 |  |  | $ | 45,963 |  |  | $ | 115,979 |  |  | $ | 115,665 |  |
| Mac® | 7,949 |  |  | 7,451 |  |  | 16,936 |  |  | 15,231 |  |
| iPad® | 6,402 |  |  | 5,559 |  |  | 14,490 |  |  | 12,582 |  |
| Wearables, Home and Accessories | 7,522 |  |  | 7,913 |  |  | 19,269 |  |  | 19,866 |  |
| Services | 26,645 |  |  | 23,867 |  |  | 52,985 |  |  | 46,984 |  |
| Total net sales | $ | 95,359 |  |  | $ | 90,753 |  |  | $ | 219,659 |  |  | $ | 210,328 |  |
| Portion of total net sales that was included in deferred revenue as of the beginning of the period | $ | 3,672 |  |  | $ | 3,282 |  |  | $ | 5,440 |  |  | $ | 5,135 |  |

[0000320193-25-000057:notes:6]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 10, “Segment Information and Geographic Data” for the three- and six-month periods ended March 29, 2025 and March 30, 2024, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.

[0000320193-25-000057:notes:7]
As of March 29, 2025 and September 28, 2024, the Company had total deferred revenue of $13.6 billion and $12.8 billion, respectively. As of March 29, 2025, the Company expects 66% of total deferred revenue to be realized in less than a year, 24% within one-to-two years, 9% within two-to-three years and 1% in greater than three years.


## us-gaap:EarningsPerShareTextBlock

[0000320193-25-000057:notes:8]
Earnings Per Share
The following table shows the computation of basic and diluted earnings per share for the three- and six-month periods ended March 29, 2025 and March 30, 2024 (net income in millions and shares in thousands):

[0000320193-25-000057:notes:9]
|  | Three Months Ended |  | Six Months Ended |
|  | March 29,2025 |  | March 30,2024 |  | March 29,2025 |  | March 30,2024 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 24,780 |  |  | $ | 23,636 |  |  | $ | 61,110 |  |  | $ | 57,552 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 14,994,082 |  |  | 15,405,856 |  |  | 15,037,903 |  |  | 15,457,810 |  |
| Effect of dilutive share-based awards | 62,051 |  |  | 58,853 |  |  | 65,596 |  |  | 62,865 |  |
| Weighted-average diluted shares | 15,056,133 |  |  | 15,464,709 |  |  | 15,103,499 |  |  | 15,520,675 |  |
| Basic earnings per share | $ | 1.65 |  |  | $ | 1.53 |  |  | $ | 4.06 |  |  | $ | 3.72 |  |
| Diluted earnings per share | $ | 1.65 |  |  | $ | 1.53 |  |  | $ | 4.05 |  |  | $ | 3.71 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000320193-25-000057:notes:10]
[same as prior period, unchanged from 0000320193-25-000008:notes:11]

[0000320193-25-000057:notes:11]
The following tables show the Company’s cash, cash equivalents and marketable securities by significant investment category as of March 29, 2025 and September 28, 2024 (in millions):

[0000320193-25-000057:notes:12]
|  | March 29, 2025 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | CurrentMarketableSecurities |  | Non-CurrentMarketableSecurities |
| Cash | $ | 25,061 |  |  | $ | — |  |  | $ | — |  |  | $ | 25,061 |  |  | $ | 25,061 |  |  | $ | — |  |  | $ | — |  |
| Level 1: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 1,132 |  |  | — |  |  | — |  |  | 1,132 |  |  | 1,132 |  |  | — |  |  | — |  |
| Mutual funds | 612 |  |  | 81 |  |  | (11) |  |  | 682 |  |  | — |  |  | 682 |  |  | — |  |
| Subtotal | 1,744 |  |  | 81 |  |  | (11) |  |  | 1,814 |  |  | 1,132 |  |  | 682 |  |  | — |  |
| Level 2 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 14,509 |  |  | 24 |  |  | (445) |  |  | 14,088 |  |  | 124 |  |  | 4,088 |  |  | 9,876 |  |
| U.S. agency securities | 4,889 |  |  | — |  |  | (233) |  |  | 4,656 |  |  | 66 |  |  | 2,004 |  |  | 2,586 |  |
| Non-U.S. government securities | 6,351 |  |  | 29 |  |  | (625) |  |  | 5,755 |  |  | — |  |  | 529 |  |  | 5,226 |  |
| Certificates of deposit and time deposits | 1,744 |  |  | — |  |  | — |  |  | 1,744 |  |  | 1,731 |  |  | — |  |  | 13 |  |
| Commercial paper | 2 |  |  | — |  |  | — |  |  | 2 |  |  | — |  |  | 2 |  |  | — |  |
| Corporate debt securities | 55,743 |  |  | 121 |  |  | (1,672) |  |  | 54,192 |  |  | 48 |  |  | 12,412 |  |  | 41,732 |  |
| Municipal securities | 303 |  |  | — |  |  | (5) |  |  | 298 |  |  | — |  |  | 170 |  |  | 128 |  |
| Mortgage- and asset-backed securities | 26,742 |  |  | 121 |  |  | (1,551) |  |  | 25,312 |  |  | — |  |  | 449 |  |  | 24,863 |  |
| Subtotal | 110,283 |  |  | 295 |  |  | (4,531) |  |  | 106,047 |  |  | 1,969 |  |  | 19,654 |  |  | 84,424 |  |
| Total | $ | 137,088 |  |  | $ | 376 |  |  | $ | (4,542) |  |  | $ | 132,922 |  |  | $ | 28,162 |  |  | $ | 20,336 |  |  | $ | 84,424 |  |

[0000320193-25-000057:notes:13]
[same as prior period, unchanged from 0000320193-25-000008:notes:14]

[0000320193-25-000057:notes:14]
[same as prior period, unchanged from 0000320193-25-000008:notes:15]

[0000320193-25-000057:notes:15]
(2)As of September 28, 2024, cash and cash equivalents included $2.6 billion held in escrow and restricted from general use. These restricted cash and cash equivalents were designated to settle the Company’s obligation related to the 2016 European Commission (the “Commission”) decision that Ireland granted state aid to the Company (the “State Aid Decision”), which was confirmed during the fourth quarter of 2024 by the European Court of Justice in a reversal of the 2020 judgment of the European General Court.

[0000320193-25-000057:notes:16]
(3)As of September 28, 2024, current marketable securities included $13.2 billion held in escrow and restricted from general use. These restricted marketable securities were designated to settle the Company’s obligation related to the State Aid Decision.

[0000320193-25-000057:notes:17]
As of March 29, 2025, 83% of the Company’s non-current marketable debt securities other than mortgage- and asset-backed securities had maturities between 1 and 5 years, 13% between 5 and 10 years, and 4% greater than 10 years. As of March 29, 2025, 13% of the Company’s non-current mortgage- and asset-backed securities had maturities between 1 and 5 years, 10% between 5 and 10 years, and 77% greater than 10 years.

[0000320193-25-000057:notes:18]
[same as prior period, unchanged from 0000320193-25-000008:notes:19]

[0000320193-25-000057:notes:19]
[same as prior period, unchanged from 0000320193-25-000008:notes:20]

[0000320193-25-000057:notes:20]
[same as prior period, unchanged from 0000320193-25-000008:notes:21]

[0000320193-25-000057:notes:21]
[same as prior period, unchanged from 0000320193-25-000008:notes:22]

[0000320193-25-000057:notes:22]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in foreign exchange rates, the Company may use forwards, cross-currency swaps or other instruments. The Company designates these instruments as either cash flow or fair value hedges. As of March 29, 2025, the maximum length of time over which the Company is hedging its exposure to the variability in future cash flows for term debt–related foreign currency transactions is 17 years.

[0000320193-25-000057:notes:23]
[same as prior period, unchanged from 0000320193-25-000008:notes:24]

[0000320193-25-000057:notes:24]
[same as prior period, unchanged from 0000320193-25-000008:notes:25]

[0000320193-25-000057:notes:25]
[same as prior period, unchanged from 0000320193-25-000008:notes:26]

[0000320193-25-000057:notes:26]
The notional amounts of the Company’s outstanding derivative instruments as of March 29, 2025 and September 28, 2024 were as follows (in millions):

[0000320193-25-000057:notes:27]
|  | March 29,2025 |  | September 28,2024 |
| Derivative instruments designated as accounting hedges: |  |  |  |
| Foreign exchange contracts | $ | 68,533 |  |  | $ | 64,069 |  |
| Interest rate contracts | $ | 14,575 |  |  | $ | 14,575 |  |
| Derivative instruments not designated as accounting hedges: |  |  |  |
| Foreign exchange contracts | $ | 68,388 |  |  | $ | 91,493 |  |

[0000320193-25-000057:notes:28]
As of March 29, 2025 and September 28, 2024, the carrying amount of the Company’s current and non-current term debt subject to fair value hedges was $13.4 billion and $13.5 billion, respectively.

[0000320193-25-000057:notes:29]
[same as prior period, unchanged from 0000320193-25-000008:notes:30]

[0000320193-25-000057:notes:30]
[same as prior period, unchanged from 0000320193-25-000008:notes:31]

[0000320193-25-000057:notes:31]
The Company’s third-party cellular network carriers accounted for 37% and 38% of total trade receivables as of March 29, 2025 and September 28, 2024, respectively. The Company requires third-party credit support or collateral from certain customers to limit credit risk.

[0000320193-25-000057:notes:32]
[same as prior period, unchanged from 0000320193-25-000008:notes:33]

[0000320193-25-000057:notes:33]
The Company has non-trade receivables from certain of its manufacturing vendors resulting from the sale of components to these vendors who manufacture subassemblies or assemble final products for the Company. The Company purchases these components directly from suppliers. The Company does not reflect the sale of these components in products net sales. Rather, the Company recognizes any gain on these sales as a reduction of products cost of sales when the related final products are sold by the Company. As of March 29, 2025, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 49% and 19%. As of September 28, 2024, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 44% and 23%.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000320193-25-000057:notes:34]
Condensed Consolidated Financial Statement Details
The following tables show the Company’s condensed consolidated financial statement details as of March 29, 2025 and September 28, 2024 (in millions):

[0000320193-25-000057:notes:35]
[same as prior period, unchanged from 0000320193-25-000008:notes:36]

[0000320193-25-000057:notes:36]
|  | March 29,2025 |  | September 28,2024 |
| Components | $ | 2,673 |  |  | $ | 3,627 |  |
| Finished goods | 3,596 |  |  | 3,659 |  |
| Total inventories | $ | 6,269 |  |  | $ | 7,286 |  |

[0000320193-25-000057:notes:37]
[same as prior period, unchanged from 0000320193-25-000008:notes:38]

[0000320193-25-000057:notes:38]
|  | March 29,2025 |  | September 28,2024 |
| Gross property, plant and equipment | $ | 121,179 |  |  | $ | 119,128 |  |
| Accumulated depreciation | (74,303) |  |  | (73,448) |  |
| Total property, plant and equipment, net | $ | 46,876 |  |  | $ | 45,680 |  |


## us-gaap:DebtDisclosureTextBlock

[0000320193-25-000057:notes:39]
Debt
Commercial Paper

[0000320193-25-000057:notes:40]
The Company issues unsecured short-term promissory notes pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of March 29, 2025 and September 28, 2024, the Company had $6.0 billion and $10.0 billion of commercial paper outstanding, respectively.

[0000320193-25-000057:notes:41]
Term Debt

[0000320193-25-000057:notes:42]
As of March 29, 2025 and September 28, 2024, the Company had outstanding fixed-rate notes with varying maturities for an aggregate carrying amount of $92.2 billion and $96.7 billion, respectively (collectively the “Notes”). As of March 29, 2025 and September 28, 2024, the fair value of the Company’s Notes, based on Level 2 inputs, was $80.9 billion and $88.4 billion, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000320193-25-000057:notes:43]
[same as prior period, unchanged from 0000320193-25-000008:notes:44]

[0000320193-25-000057:notes:44]
During the six months ended March 29, 2025, the Company repurchased 208 million shares of its common stock for $48.3 billion. The Company’s share repurchase program does not obligate the Company to acquire a minimum amount of shares. Under the program, shares may be repurchased in privately negotiated or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000320193-25-000057:notes:45]
[same as prior period, unchanged from 0000320193-25-000008:notes:46]

[0000320193-25-000057:notes:46]
A summary of the Company’s RSU activity and related information for the six months ended March 29, 2025 is as follows:

[0000320193-25-000057:notes:47]
|  | Number ofRSUs(in thousands) |  | Weighted-AverageGrant-Date FairValue Per RSU |
| Balance as of September 28, 2024 | 163,326 |  |  | $ | 158.73 |  |
| RSUs granted | 63,378 |  |  | $ | 228.10 |  |
| RSUs vested | (39,177) |  |  | $ | 148.90 |  |
| RSUs canceled | (4,181) |  |  | $ | 177.54 |  |
| Balance as of March 29, 2025 | 183,346 |  |  | $ | 184.38 |  |

[0000320193-25-000057:notes:48]
The total vesting-date fair value of RSUs was $906 million and $9.3 billion for the three- and six-month periods ended March 29, 2025, respectively, and was $821 million and $8.6 billion for the three- and six-month periods ended March 30, 2024, respectively.

[0000320193-25-000057:notes:49]
[same as prior period, unchanged from 0000320193-25-000008:notes:50]

[0000320193-25-000057:notes:50]
The following table shows share-based compensation expense and the related income tax benefit included in the Condensed Consolidated Statements of Operations for the three- and six-month periods ended March 29, 2025 and March 30, 2024 (in millions):

[0000320193-25-000057:notes:51]
|  | Three Months Ended |  | Six Months Ended |
|  | March 29,2025 |  | March 30,2024 |  | March 29,2025 |  | March 30,2024 |
| Share-based compensation expense | $ | 3,226 |  |  | $ | 2,964 |  |  | $ | 6,512 |  |  | $ | 5,961 |  |
| Income tax benefit related to share-based compensation expense | $ | (743) |  |  | $ | (663) |  |  | $ | (2,075) |  |  | $ | (1,898) |  |

[0000320193-25-000057:notes:52]
As of March 29, 2025, the total unrecognized compensation cost related to outstanding RSUs was $26.3 billion, which the Company expects to recognize over a weighted-average period of 2.7 years.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000320193-25-000057:notes:53]
Segment Information and Geographic Data
The following table shows information by reportable segment for the three- and six-month periods ended March 29, 2025 and March 30, 2024 (in millions):

[0000320193-25-000057:notes:54]
|  | Three Months Ended |  | Six Months Ended |
|  | March 29,2025 |  | March 30,2024 |  | March 29,2025 |  | March 30,2024 |
| Americas: |  |  |  |  |  |  |  |
| Net sales | $ | 40,315 |  |  | $ | 37,273 |  |  | $ | 92,963 |  |  | $ | 87,703 |  |
| Operating income | $ | 16,774 |  |  | $ | 15,074 |  |  | $ | 38,283 |  |  | $ | 35,431 |  |
| Europe: |  |  |  |  |  |  |  |
| Net sales | $ | 24,454 |  |  | $ | 24,123 |  |  | $ | 58,315 |  |  | $ | 54,520 |  |
| Operating income | $ | 10,316 |  |  | $ | 9,991 |  |  | $ | 24,923 |  |  | $ | 22,702 |  |
| Greater China: |  |  |  |  |  |  |  |
| Net sales | $ | 16,002 |  |  | $ | 16,372 |  |  | $ | 34,515 |  |  | $ | 37,191 |  |
| Operating income | $ | 6,626 |  |  | $ | 6,700 |  |  | $ | 14,786 |  |  | $ | 15,322 |  |
| Japan: |  |  |  |  |  |  |  |
| Net sales | $ | 7,298 |  |  | $ | 6,262 |  |  | $ | 16,285 |  |  | $ | 14,029 |  |
| Operating income | $ | 3,434 |  |  | $ | 3,135 |  |  | $ | 7,748 |  |  | $ | 6,954 |  |
| Rest of Asia Pacific: |  |  |  |  |  |  |  |
| Net sales | $ | 7,290 |  |  | $ | 6,723 |  |  | $ | 17,581 |  |  | $ | 16,885 |  |
| Operating income | $ | 2,986 |  |  | $ | 2,806 |  |  | $ | 7,570 |  |  | $ | 7,385 |  |

[0000320193-25-000057:notes:55]
A reconciliation of the Company’s segment operating income to the Condensed Consolidated Statements of Operations for the three- and six-month periods ended March 29, 2025 and March 30, 2024 is as follows (in millions):

[0000320193-25-000057:notes:56]
|  | Three Months Ended |  | Six Months Ended |
|  | March 29,2025 |  | March 30,2024 |  | March 29,2025 |  | March 30,2024 |
| Segment operating income | $ | 40,136 |  |  | $ | 37,706 |  |  | $ | 93,310 |  |  | $ | 87,794 |  |
| Research and development expense | (8,550) |  |  | (7,903) |  |  | (16,818) |  |  | (15,599) |  |
| Other corporate expenses, net | (1,997) |  |  | (1,903) |  |  | (4,071) |  |  | (3,922) |  |
| Total operating income | $ | 29,589 |  |  | $ | 27,900 |  |  | $ | 72,421 |  |  | $ | 68,273 |  |
