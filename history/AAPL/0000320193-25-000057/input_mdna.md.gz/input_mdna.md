# AAPL MD&A — 0000320193-25-000057


## mdna

[0000320193-25-000057:mdna:1]
[same as prior period, unchanged from 0000320193-25-000008:mdna:1]

[0000320193-25-000057:mdna:2]
[same as prior period, unchanged from 0000320193-25-000008:mdna:2]

[0000320193-25-000057:mdna:3]
[same as prior period, unchanged from 0000320193-25-000008:mdna:3]

[0000320193-25-000057:mdna:4]
[same as prior period, unchanged from 0000320193-25-000008:mdna:4]

[0000320193-25-000057:mdna:5]
The Company periodically provides certain information for investors on its corporate website, www.apple.com, and its investor relations website, investor.apple.com. This includes press releases and other information about financial performance, information on corporate governance, and details related to the Company’s annual meeting of shareholders. The information contained on the websites referenced in this Form 10-Q is not incorporated by reference into this filing. Further, the Company’s references to website URLs are intended to be inactive textual references only.

[0000320193-25-000057:mdna:6]
[same as prior period, unchanged from 0000320193-25-000008:mdna:6]

[0000320193-25-000057:mdna:7]
[same as prior period, unchanged from 0000320193-25-000008:mdna:7]

[0000320193-25-000057:mdna:8]
During the second quarter of 2025, the Company announced the following new or updated products:

[0000320193-25-000057:mdna:9]
•iPhone 16e

[0000320193-25-000057:mdna:10]
•iPad Air®

[0000320193-25-000057:mdna:11]
•iPad

[0000320193-25-000057:mdna:12]
•MacBook Air®

[0000320193-25-000057:mdna:13]
•Mac Studio®

[0000320193-25-000057:mdna:14]
[same as prior period, unchanged from 0000320193-25-000008:mdna:13]

[0000320193-25-000057:mdna:15]
[same as prior period, unchanged from 0000320193-25-000008:mdna:14]

[0000320193-25-000057:mdna:16]
Tariffs and Other Trade Measures

[0000320193-25-000057:mdna:17]
Beginning in the second quarter of 2025, new tariffs were announced on imports to the U.S. (“U.S. Tariffs”), including additional tariffs on imports from China, India, Japan, South Korea, Taiwan, Vietnam and the European Union (“EU”), among others. In response, several countries have imposed, or threatened to impose, reciprocal tariffs on imports from the U.S. and other retaliatory measures. Various modifications and delays to the U.S. Tariffs have been announced and further changes are expected to be made in the future, which may include additional sector-based tariffs or other measures. For example, the U.S. Department of Commerce has initiated an investigation under Section 232 of the Trade Expansion Act of 1962, as amended, into, among other things, imports of semiconductors, semiconductor manufacturing equipment, and their derivative products, including downstream products that contain semiconductors. Tariffs and other measures that are applied to the Company’s products or their components can have a material adverse impact on the Company’s business, results of operations and financial condition, including impacting the Company’s supply chain, the availability of rare earths and other raw materials and components, pricing and gross margin. The ultimate impact remains uncertain and will depend on several factors, including whether additional or incremental U.S. Tariffs or other measures are announced or imposed, to what extent other countries implement tariffs or other retaliatory measures in response, and the overall magnitude and duration of these measures. Trade and other international disputes can have an adverse impact on the overall macroeconomic environment and result in shifts and reductions in consumer spending and negative consumer sentiment for the Company’s products and services, all of which can further adversely affect the Company’s business and results of operations.

[0000320193-25-000057:mdna:18]
[same as prior period, unchanged from 0000320193-25-000008:mdna:15]

[0000320193-25-000057:mdna:19]
The following table shows net sales by reportable segment for the three- and six-month periods ended March 29, 2025 and March 30, 2024 (dollars in millions):

[0000320193-25-000057:mdna:20]
|  | Three Months Ended |  | Six Months Ended |
|  | March 29,2025 |  | March 30,2024 |  | Change |  | March 29,2025 |  | March 30,2024 |  | Change |
| Americas | $ | 40,315 |  |  | $ | 37,273 |  |  | 8 | % |  | $ | 92,963 |  |  | $ | 87,703 |  |  | 6 | % |
| Europe | 24,454 |  |  | 24,123 |  |  | 1 | % |  | 58,315 |  |  | 54,520 |  |  | 7 | % |
| Greater China | 16,002 |  |  | 16,372 |  |  | (2) | % |  | 34,515 |  |  | 37,191 |  |  | (7) | % |
| Japan | 7,298 |  |  | 6,262 |  |  | 17 | % |  | 16,285 |  |  | 14,029 |  |  | 16 | % |
| Rest of Asia Pacific | 7,290 |  |  | 6,723 |  |  | 8 | % |  | 17,581 |  |  | 16,885 |  |  | 4 | % |
| Total net sales | $ | 95,359 |  |  | $ | 90,753 |  |  | 5 | % |  | $ | 219,659 |  |  | $ | 210,328 |  |  | 4 | % |

[0000320193-25-000057:mdna:21]
[same as prior period, unchanged from 0000320193-25-000008:mdna:18]

[0000320193-25-000057:mdna:22]
Americas net sales increased during the second quarter and first six months of 2025 compared to the same periods in 2024 due primarily to higher net sales of iPhone and Services. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable year-over-year impact on Americas net sales during the second quarter and first six months of 2025.

[0000320193-25-000057:mdna:23]
[same as prior period, unchanged from 0000320193-25-000008:mdna:20]

[0000320193-25-000057:mdna:24]
Europe net sales were relatively flat during the second quarter of 2025 compared to the second quarter of 2024. Year-over-year Europe net sales increased during the first six months of 2025 due primarily to higher net sales of Services, Mac and iPad. The weakness in foreign currencies relative to the U.S. dollar had a net unfavorable year-over-year impact on Europe net sales during the second quarter of 2025.

[0000320193-25-000057:mdna:25]
[same as prior period, unchanged from 0000320193-25-000008:mdna:22]

[0000320193-25-000057:mdna:26]
Greater China net sales decreased during the first six months of 2025 compared to the same period in 2024 due to lower net sales of iPhone. The weakness in the renminbi relative to the U.S. dollar had an unfavorable year-over-year impact on Greater China net sales during the second quarter of 2025.

[0000320193-25-000057:mdna:27]
[same as prior period, unchanged from 0000320193-25-000008:mdna:24]

[0000320193-25-000057:mdna:28]
Japan net sales increased during the second quarter and first six months of 2025 compared to the same periods in 2024 due primarily to higher net sales of iPhone and Services. The weakness in the yen relative to the U.S. dollar had an unfavorable year-over-year impact on Japan net sales during the second quarter and first six months of 2025.

[0000320193-25-000057:mdna:29]
[same as prior period, unchanged from 0000320193-25-000008:mdna:26]

[0000320193-25-000057:mdna:30]
Rest of Asia Pacific net sales increased during the second quarter of 2025 compared to the second quarter of 2024 due primarily to higher net sales of Services and iPhone. Year-over-year Rest of Asia Pacific net sales increased during the first six months of 2025 due primarily to higher net sales of Services. Changes in foreign currencies relative to the U.S. dollar had a net unfavorable year-over-year impact on Rest of Asia Pacific net sales during the second quarter of 2025, while they had a net favorable impact during the first six months of 2025.

[0000320193-25-000057:mdna:31]
[same as prior period, unchanged from 0000320193-25-000008:mdna:28]

[0000320193-25-000057:mdna:32]
The following table shows net sales by category for the three- and six-month periods ended March 29, 2025 and March 30, 2024 (dollars in millions):

[0000320193-25-000057:mdna:33]
|  | Three Months Ended |  | Six Months Ended |
|  | March 29,2025 |  | March 30,2024 |  | Change |  | March 29,2025 |  | March 30,2024 |  | Change |
| iPhone | $ | 46,841 |  |  | $ | 45,963 |  |  | 2 | % |  | $ | 115,979 |  |  | $ | 115,665 |  |  | — | % |
| Mac | 7,949 |  |  | 7,451 |  |  | 7 | % |  | 16,936 |  |  | 15,231 |  |  | 11 | % |
| iPad | 6,402 |  |  | 5,559 |  |  | 15 | % |  | 14,490 |  |  | 12,582 |  |  | 15 | % |
| Wearables, Home and Accessories | 7,522 |  |  | 7,913 |  |  | (5) | % |  | 19,269 |  |  | 19,866 |  |  | (3) | % |
| Services | 26,645 |  |  | 23,867 |  |  | 12 | % |  | 52,985 |  |  | 46,984 |  |  | 13 | % |
| Total net sales | $ | 95,359 |  |  | $ | 90,753 |  |  | 5 | % |  | $ | 219,659 |  |  | $ | 210,328 |  |  | 4 | % |

[0000320193-25-000057:mdna:34]
[same as prior period, unchanged from 0000320193-25-000008:mdna:31]

[0000320193-25-000057:mdna:35]
iPhone net sales increased during the second quarter of 2025 compared to the second quarter of 2024 due primarily to higher net sales of Pro models. Year-over-year iPhone net sales were relatively flat during the first six months of 2025.

[0000320193-25-000057:mdna:36]
[same as prior period, unchanged from 0000320193-25-000008:mdna:33]

[0000320193-25-000057:mdna:37]
Mac net sales increased during the second quarter and first six months of 2025 compared to the same periods in 2024 due primarily to higher net sales of both laptops and desktops.

[0000320193-25-000057:mdna:38]
[same as prior period, unchanged from 0000320193-25-000008:mdna:35]

[0000320193-25-000057:mdna:39]
iPad net sales increased during the second quarter and first six months of 2025 compared to the same periods in 2024 due primarily to higher net sales of iPad Air.

[0000320193-25-000057:mdna:40]
[same as prior period, unchanged from 0000320193-25-000008:mdna:37]

[0000320193-25-000057:mdna:41]
Wearables, Home and Accessories net sales decreased during the second quarter and first six months of 2025 compared to the same periods in 2024 due primarily to lower net sales of Wearables.

[0000320193-25-000057:mdna:42]
[same as prior period, unchanged from 0000320193-25-000008:mdna:39]

[0000320193-25-000057:mdna:43]
Services net sales increased during the second quarter and first six months of 2025 compared to the same periods in 2024 due primarily to higher net sales from advertising, the App Store® and cloud services.

[0000320193-25-000057:mdna:44]
[same as prior period, unchanged from 0000320193-25-000008:mdna:41]

[0000320193-25-000057:mdna:45]
Products and Services gross margin and gross margin percentage for the three- and six-month periods ended March 29, 2025 and March 30, 2024 were as follows (dollars in millions):

[0000320193-25-000057:mdna:46]
|  | Three Months Ended |  | Six Months Ended |
|  | March 29,2025 |  | March 30,2024 |  | March 29,2025 |  | March 30,2024 |
| Gross margin: |  |  |  |  |  |  |  |
| Products | $ | 24,684 |  |  | $ | 24,462 |  |  | $ | 63,197 |  |  | $ | 62,480 |  |
| Services | 20,183 |  |  | 17,809 |  |  | 39,945 |  |  | 34,646 |  |
| Total gross margin | $ | 44,867 |  |  | $ | 42,271 |  |  | $ | 103,142 |  |  | $ | 97,126 |  |

[0000320193-25-000057:mdna:47]
| Gross margin percentage: |  |  |  |  |  |  |  |
| Products | 35.9 | % |  | 36.6 | % |  | 37.9 | % |  | 38.3 | % |
| Services | 75.7 | % |  | 74.6 | % |  | 75.4 | % |  | 73.7 | % |
| Total gross margin percentage | 47.1 | % |  | 46.6 | % |  | 47.0 | % |  | 46.2 | % |

[0000320193-25-000057:mdna:48]
[same as prior period, unchanged from 0000320193-25-000008:mdna:45]

[0000320193-25-000057:mdna:49]
Products gross margin was relatively flat during the second quarter of 2025 compared to the second quarter of 2024. Year-over-year Products gross margin increased during the first six months of 2025 due primarily to favorable costs, partially offset by a different mix of products and weakness in foreign currencies relative to the U.S. dollar.

[0000320193-25-000057:mdna:50]
Products gross margin percentage decreased during the second quarter and first six months of 2025 compared to the same periods in 2024 due primarily to a different mix of products and weakness in foreign currencies relative to the U.S. dollar, partially offset by favorable costs.

[0000320193-25-000057:mdna:51]
[same as prior period, unchanged from 0000320193-25-000008:mdna:47]

[0000320193-25-000057:mdna:52]
Services gross margin increased during the second quarter and first six months of 2025 compared to the same periods in 2024 due primarily to higher Services net sales.

[0000320193-25-000057:mdna:53]
Services gross margin percentage increased during the second quarter and first six months of 2025 compared to the same periods in 2024 due primarily to a different mix of services, partially offset by higher Services costs and weakness in foreign currencies relative to the U.S. dollar.

[0000320193-25-000057:mdna:54]
[same as prior period, unchanged from 0000320193-25-000008:mdna:50]

[0000320193-25-000057:mdna:55]
[same as prior period, unchanged from 0000320193-25-000008:mdna:51]

[0000320193-25-000057:mdna:56]
Operating expenses for the three- and six-month periods ended March 29, 2025 and March 30, 2024 were as follows (dollars in millions):

[0000320193-25-000057:mdna:57]
|  | Three Months Ended |  | Six Months Ended |
|  | March 29,2025 |  | March 30,2024 |  | March 29,2025 |  | March 30,2024 |
| Research and development | $ | 8,550 |  |  | $ | 7,903 |  |  | $ | 16,818 |  |  | $ | 15,599 |  |
| Percentage of total net sales | 9 | % |  | 9 | % |  | 8 | % |  | 7 | % |
| Selling, general and administrative | $ | 6,728 |  |  | $ | 6,468 |  |  | $ | 13,903 |  |  | $ | 13,254 |  |
| Percentage of total net sales | 7 | % |  | 7 | % |  | 6 | % |  | 6 | % |
| Total operating expenses | $ | 15,278 |  |  | $ | 14,371 |  |  | $ | 30,721 |  |  | $ | 28,853 |  |
| Percentage of total net sales | 16 | % |  | 16 | % |  | 14 | % |  | 14 | % |

[0000320193-25-000057:mdna:58]
[same as prior period, unchanged from 0000320193-25-000008:mdna:54]

[0000320193-25-000057:mdna:59]
The growth in research and development expense during the second quarter and first six months of 2025 compared to the same periods in 2024 was driven primarily by increases in headcount-related expenses and infrastructure-related costs.

[0000320193-25-000057:mdna:60]
[same as prior period, unchanged from 0000320193-25-000008:mdna:56]

[0000320193-25-000057:mdna:61]
The growth in selling, general and administrative expense during the second quarter of 2025 compared to the second quarter of 2024 was driven primarily by increases in professional services and headcount-related expenses. Year-over-year selling, general and administrative expense increased during the first six months of 2025 due primarily to increases in variable selling expenses, headcount-related expenses and professional services.

[0000320193-25-000057:mdna:62]
[same as prior period, unchanged from 0000320193-25-000008:mdna:58]

[0000320193-25-000057:mdna:63]
Provision for income taxes, effective tax rate and statutory federal income tax rate for the three- and six-month periods ended March 29, 2025 and March 30, 2024 were as follows (dollars in millions):

[0000320193-25-000057:mdna:64]
|  | Three Months Ended |  | Six Months Ended |
|  | March 29,2025 |  | March 30,2024 |  | March 29,2025 |  | March 30,2024 |
| Provision for income taxes | $ | 4,530 |  |  | $ | 4,422 |  |  | $ | 10,784 |  |  | $ | 10,829 |  |
| Effective tax rate | 15.5 | % |  | 15.8 | % |  | 15.0 | % |  | 15.8 | % |
| Statutory federal income tax rate | 21 | % |  | 21 | % |  | 21 | % |  | 21 | % |

[0000320193-25-000057:mdna:65]
The Company’s effective tax rate for the second quarter of 2025 was lower than the statutory federal income tax rate due primarily to a lower effective tax rate on foreign earnings, including the impact of changes in unrecognized tax benefits, partially offset by state income taxes. The Company’s effective tax rate for the first six months of 2025 was lower than the statutory federal income tax rate due primarily to a lower effective tax rate on foreign earnings, including the impact of changes in unrecognized tax benefits, tax benefits from share-based compensation, the impact of foreign currency loss regulations issued by the U.S. Department of the Treasury in December 2024, and the tax impact from foreign currency revaluations related to the State Aid Decision.

[0000320193-25-000057:mdna:66]
The Company’s effective tax rate for the second quarter of 2025 was lower compared to the second quarter of 2024 due primarily to the impact of changes in unrecognized tax benefits, partially offset by a higher effective tax rate on foreign earnings. The Company’s effective tax rate for the first six months of 2025 was lower compared to the same period in 2024 due primarily to the impact of changes in unrecognized tax benefits, the impact of foreign currency loss regulations issued by the U.S. Department of the Treasury in December 2024, and the tax impact from foreign currency revaluations related to the State Aid Decision, partially offset by a higher effective tax rate on foreign earnings.

[0000320193-25-000057:mdna:67]
[same as prior period, unchanged from 0000320193-25-000008:mdna:63]

[0000320193-25-000057:mdna:68]
The Company believes its balances of cash, cash equivalents and marketable securities, along with cash generated by ongoing operations and continued access to debt markets, will be sufficient to satisfy its cash requirements and capital return program over the next 12 months and beyond.

[0000320193-25-000057:mdna:69]
The Company’s contractual cash requirements have not changed materially since the 2024 Form 10-K, except for manufacturing purchase obligations and the State Aid Decision tax payable.

[0000320193-25-000057:mdna:70]
[same as prior period, unchanged from 0000320193-25-000008:mdna:68]

[0000320193-25-000057:mdna:71]
The Company utilizes several outsourcing partners to manufacture subassemblies for the Company’s products and to perform final assembly and testing of finished products. The Company also obtains individual components for its products from a wide variety of individual suppliers. As of March 29, 2025, the Company had manufacturing purchase obligations of $38.4 billion, which were payable within 12 months.

[0000320193-25-000057:mdna:72]
[same as prior period, unchanged from 0000320193-25-000008:mdna:70]

[0000320193-25-000057:mdna:73]
During the first six months of 2025, the Company released from escrow €14.2 billion or $15.4 billion to Ireland in connection with the State Aid Decision, which fully settled the obligation.

[0000320193-25-000057:mdna:74]
[same as prior period, unchanged from 0000320193-25-000008:mdna:72]

[0000320193-25-000057:mdna:75]
In addition to its contractual cash requirements, the Company has an authorized share repurchase program, under which the remaining availability was $40.8 billion as of March 29, 2025. On May 1, 2025, the Company announced the Board of Directors had authorized an additional program to repurchase up to $100 billion of the Company’s common stock. The programs do not obligate the Company to acquire a minimum amount of shares.

[0000320193-25-000057:mdna:76]
On May 1, 2025, the Company also announced the Board of Directors raised the Company’s quarterly cash dividend from $0.25 to $0.26 per share, beginning with the dividend to be paid during the third quarter of 2025. The Company intends to increase its dividend on an annual basis, subject to declaration by the Board of Directors.

[0000320193-25-000057:mdna:77]
During the second quarter of 2025, the Company repurchased $25.0 billion of its common stock and paid dividends and dividend equivalents of $3.8 billion.

[0000320193-25-000057:mdna:78]
[same as prior period, unchanged from 0000320193-25-000008:mdna:75]

[0000320193-25-000057:mdna:79]
[same as prior period, unchanged from 0000320193-25-000008:mdna:76]

[0000320193-25-000057:mdna:80]
In November 2024, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) No. 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses (“ASU 2024-03”) and in January 2025, the FASB issued ASU No. 2025-01, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date, which clarified the effective date of ASU 2024-03. ASU 2024-03 will require the Company to disclose the amounts of purchases of inventory, employee compensation, depreciation and intangible asset amortization, as applicable, included in certain expense captions in the Consolidated Statements of Operations, as well as qualitatively describe remaining amounts included in those captions. ASU 2024-03 will also require the Company to disclose both the amount and the Company’s definition of selling expenses. The Company will adopt ASU 2024-03 in its fourth quarter of 2028 using a prospective transition method.

[0000320193-25-000057:mdna:81]
[same as prior period, unchanged from 0000320193-25-000008:mdna:78]

[0000320193-25-000057:mdna:82]
In December 2023, the FASB issued ASU No. 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures (“ASU 2023-09”), which will require the Company to disclose specified additional information in its income tax rate reconciliation and provide additional information for reconciling items that meet a quantitative threshold. ASU 2023-09 will also require the Company to disaggregate its income taxes paid disclosure by federal, state and foreign taxes, with further disaggregation required for significant individual jurisdictions. The Company will adopt ASU 2023-09 in its fourth quarter of 2026 using a prospective transition method.

[0000320193-25-000057:mdna:83]
[same as prior period, unchanged from 0000320193-25-000008:mdna:80]

[0000320193-25-000057:mdna:84]
In November 2023, the FASB issued ASU No. 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures (“ASU 2023-07”), which will require the Company to disclose segment expenses that are significant and regularly provided to the Company’s chief operating decision maker (“CODM”). In addition, ASU 2023-07 will require the Company to disclose the title and position of its CODM and how the CODM uses segment profit or loss information in assessing segment performance and deciding how to allocate resources. The Company will adopt ASU 2023-07 in its fourth quarter of 2025 using a retrospective transition method.

[0000320193-25-000057:mdna:85]
[same as prior period, unchanged from 0000320193-25-000008:mdna:82]

[0000320193-25-000057:mdna:86]
[same as prior period, unchanged from 0000320193-25-000008:mdna:83]
