# AAPL MD&A — 0000320193-21-000105


## mdna

[0000320193-21-000105:mdna:1]
Item 7.    Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000320193-21-000105:mdna:2]
The following discussion should be read in conjunction with the consolidated financial statements and accompanying notes included in Part II, Item 8 of this Form 10-K. This section of this Form 10-K generally discusses 2021 and 2020 items and year-to-year comparisons between 2021 and 2020. Discussions of 2019 items and year-to-year comparisons between 2020 and 2019 are not included in this Form 10-K, and can be found in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in Part II, Item 7 of the Company’s Annual Report on Form 10-K for the fiscal year ended September 26, 2020.

[0000320193-21-000105:mdna:3]
Fiscal Year Highlights

[0000320193-21-000105:mdna:4]
COVID-19 Update

[0000320193-21-000105:mdna:5]
The COVID-19 pandemic has had, and continues to have, a significant impact around the world, prompting governments and businesses to take unprecedented measures, such as restrictions on travel and business operations, temporary closures of businesses, and quarantine and shelter-in-place orders. The COVID-19 pandemic has at times significantly curtailed global economic activity and caused significant volatility and disruption in global financial markets. The COVID-19 pandemic and the measures taken by many countries in response have affected and could in the future materially impact the Company’s business, results of operations and financial condition, as well as the price of the Company’s stock.

[0000320193-21-000105:mdna:6]
During 2021, aspects of the Company’s business continued to be affected by the COVID-19 pandemic, with many of the Company’s retail stores, as well as channel partner points of sale, temporarily closed at various times, and a significant number of the Company’s employees working remotely. The Company has reopened all of its retail stores and substantially all of its other facilities, subject to operating restrictions to protect public health and the health and safety of employees and customers, and it continues to work on safely reopening the remainder of its facilities, subject to local rules and regulations. During the fourth quarter of 2021, certain of the Company’s component suppliers and logistical service providers experienced disruptions, resulting in supply shortages that affected sales worldwide. Similar disruptions could occur in the future.

[0000320193-21-000105:mdna:7]
The extent of the continuing impact of the COVID-19 pandemic on the Company’s operational and financial performance is uncertain and will depend on many factors outside the Company’s control, including the timing, extent, trajectory and duration of the pandemic, the emergence of new variants, the development, availability, distribution and effectiveness of vaccines and treatments, the imposition of protective public safety measures, and the impact of the pandemic on the global economy and demand for consumer products. Refer to Part I, Item 1A of this Form 10-K under the heading “Risk Factors” for more information.

[0000320193-21-000105:mdna:8]
Fiscal 2021 Highlights

[0000320193-21-000105:mdna:9]
Total net sales increased 33% or $91.3 billion during 2021 compared to 2020, driven by growth in all Products and Services categories. Year-over-year net sales during 2021 also grew in each of the Company’s reportable segments.

[0000320193-21-000105:mdna:10]
In April 2021, the Company announced an increase to its current share repurchase program authorization from $225 billion to $315 billion and raised its quarterly dividend from $0.205 to $0.22 per share beginning in May 2021. During 2021, the Company repurchased $85.5 billion of its common stock and paid dividends and dividend equivalents of $14.5 billion.

[0000320193-21-000105:mdna:11]
Products and Services Performance

[0000320193-21-000105:mdna:12]
The following table shows net sales by category for 2021, 2020 and 2019 (dollars in millions):

[0000320193-21-000105:mdna:13]
|  | 2021 |  | Change |  | 2020 |  | Change |  | 2019 |
| Net sales by category: |  |  |  |  |  |  |  |  |  |
| iPhone (1) | $ | 191,973 |  |  | 39 | % |  | $ | 137,781 |  |  | (3) | % |  | $ | 142,381 |  |
| Mac (1) | 35,190 |  |  | 23 | % |  | 28,622 |  |  | 11 | % |  | 25,740 |  |
| iPad (1) | 31,862 |  |  | 34 | % |  | 23,724 |  |  | 11 | % |  | 21,280 |  |
| Wearables, Home and Accessories (1)(2) | 38,367 |  |  | 25 | % |  | 30,620 |  |  | 25 | % |  | 24,482 |  |
| Services (3) | 68,425 |  |  | 27 | % |  | 53,768 |  |  | 16 | % |  | 46,291 |  |
| Total net sales | $ | 365,817 |  |  | 33 | % |  | $ | 274,515 |  |  | 6 | % |  | $ | 260,174 |  |

[0000320193-21-000105:mdna:14]
(1)Products net sales include amortization of the deferred value of unspecified software upgrade rights, which are bundled in the sales price of the respective product.

[0000320193-21-000105:mdna:15]
(2)Wearables, Home and Accessories net sales include sales of AirPods, Apple TV, Apple Watch, Beats products, HomePod, iPod touch and accessories.

[0000320193-21-000105:mdna:16]
(3)Services net sales include sales from the Company’s advertising, AppleCare, cloud, digital content, payment and other services. Services net sales also include amortization of the deferred value of services bundled in the sales price of certain products.

[0000320193-21-000105:mdna:17]
iPhone

[0000320193-21-000105:mdna:18]
iPhone net sales increased during 2021 compared to 2020 due primarily to higher net sales from the Company’s new iPhone models launched in the first quarter and fourth quarter of 2021 and a favorable mix of iPhone sales.

[0000320193-21-000105:mdna:19]
Mac

[0000320193-21-000105:mdna:20]
Mac net sales increased during 2021 compared to 2020 due primarily to higher net sales of MacBook Air, MacBook Pro and iMac.

[0000320193-21-000105:mdna:21]
iPad

[0000320193-21-000105:mdna:22]
iPad net sales increased during 2021 compared to 2020 due primarily to higher net sales of iPad Air and iPad Pro.

[0000320193-21-000105:mdna:23]
Wearables, Home and Accessories

[0000320193-21-000105:mdna:24]
Wearables, Home and Accessories net sales increased during 2021 compared to 2020 due primarily to higher net sales of accessories and Apple Watch.

[0000320193-21-000105:mdna:25]
Services

[0000320193-21-000105:mdna:26]
Services net sales increased during 2021 compared to 2020 due primarily to higher net sales from advertising, the App Store and cloud services.

[0000320193-21-000105:mdna:27]
Segment Operating Performance

[0000320193-21-000105:mdna:28]
The Company manages its business primarily on a geographic basis. The Company’s reportable segments consist of the Americas, Europe, Greater China, Japan and Rest of Asia Pacific. Americas includes both North and South America. Europe includes European countries, as well as India, the Middle East and Africa. Greater China includes China mainland, Hong Kong and Taiwan. Rest of Asia Pacific includes Australia and those Asian countries not included in the Company’s other reportable segments. Although the reportable segments provide similar hardware and software products and similar services, each one is managed separately to better align with the location of the Company’s customers and distribution partners and the unique market dynamics of each geographic region. Further information regarding the Company’s reportable segments can be found in Part II, Item 8 of this Form 10-K in the Notes to Consolidated Financial Statements in Note 11, “Segment Information and Geographic Data.”

[0000320193-21-000105:mdna:29]
The following table shows net sales by reportable segment for 2021, 2020 and 2019 (dollars in millions):

[0000320193-21-000105:mdna:30]
|  | 2021 |  | Change |  | 2020 |  | Change |  | 2019 |
| Net sales by reportable segment: |  |  |  |  |  |  |  |  |  |
| Americas | $ | 153,306 |  |  | 23 | % |  | $ | 124,556 |  |  | 7 | % |  | $ | 116,914 |  |
| Europe | 89,307 |  |  | 30 | % |  | 68,640 |  |  | 14 | % |  | 60,288 |  |
| Greater China | 68,366 |  |  | 70 | % |  | 40,308 |  |  | (8) | % |  | 43,678 |  |
| Japan | 28,482 |  |  | 33 | % |  | 21,418 |  |  | — | % |  | 21,506 |  |
| Rest of Asia Pacific | 26,356 |  |  | 35 | % |  | 19,593 |  |  | 10 | % |  | 17,788 |  |
| Total net sales | $ | 365,817 |  |  | 33 | % |  | $ | 274,515 |  |  | 6 | % |  | $ | 260,174 |  |

[0000320193-21-000105:mdna:31]
Americas

[0000320193-21-000105:mdna:32]
Americas net sales increased during 2021 compared to 2020 due primarily to higher net sales of iPhone, Services and Mac.

[0000320193-21-000105:mdna:33]
Europe

[0000320193-21-000105:mdna:34]
Europe net sales increased during 2021 compared to 2020 due primarily to higher net sales of iPhone, Services and iPad. The movement of foreign currencies in Europe relative to the U.S. dollar had a net favorable impact on Europe net sales during 2021.

[0000320193-21-000105:mdna:35]
Greater China

[0000320193-21-000105:mdna:36]
Greater China net sales increased during 2021 compared to 2020 due primarily to higher net sales of iPhone, iPad and Services. The strength of the Chinese renminbi relative to the U.S. dollar had a favorable impact on Greater China net sales during 2021.

[0000320193-21-000105:mdna:37]
Japan

[0000320193-21-000105:mdna:38]
Japan net sales increased during 2021 compared to 2020 due primarily to higher net sales of iPhone and Services.

[0000320193-21-000105:mdna:39]
Rest of Asia Pacific

[0000320193-21-000105:mdna:40]
Rest of Asia Pacific net sales increased during 2021 compared to 2020 due primarily to higher net sales of iPhone, iPad and Services. The movement of foreign currencies in the Rest of Asia Pacific relative to the U.S. dollar had a favorable impact on Rest of Asia Pacific net sales during 2021.

[0000320193-21-000105:mdna:41]
Gross Margin

[0000320193-21-000105:mdna:42]
Products and Services gross margin and gross margin percentage for 2021, 2020 and 2019 were as follows (dollars in millions):

[0000320193-21-000105:mdna:43]
|  | 2021 |  | 2020 |  | 2019 |
| Gross margin: |  |  |  |  |  |
| Products | $ | 105,126 |  |  | $ | 69,461 |  |  | $ | 68,887 |  |
| Services | 47,710 |  |  | 35,495 |  |  | 29,505 |  |
| Total gross margin | $ | 152,836 |  |  | $ | 104,956 |  |  | $ | 98,392 |  |

[0000320193-21-000105:mdna:44]
| Gross margin percentage: |  |  |  |  |  |
| Products | 35.3 | % |  | 31.5 | % |  | 32.2 | % |
| Services | 69.7 | % |  | 66.0 | % |  | 63.7 | % |
| Total gross margin percentage | 41.8 | % |  | 38.2 | % |  | 37.8 | % |

[0000320193-21-000105:mdna:45]
Products Gross Margin

[0000320193-21-000105:mdna:46]
Products gross margin increased during 2021 compared to 2020 due primarily to higher Products volume, a different Products mix and the strength in foreign currencies relative to the U.S. dollar. Products gross margin percentage increased during 2021 compared to 2020 due primarily to a different Products mix, improved leverage and the strength in foreign currencies relative to the U.S. dollar.

[0000320193-21-000105:mdna:47]
Services Gross Margin

[0000320193-21-000105:mdna:48]
Services gross margin increased during 2021 compared to 2020 due primarily to higher Services net sales and a different Services mix. Services gross margin percentage increased during 2021 compared to 2020 due primarily to a different Services mix and improved leverage, partially offset by higher Services costs.

[0000320193-21-000105:mdna:49]
The Company’s future gross margins can be impacted by a variety of factors, as discussed in Part I, Item 1A of this Form 10-K under the heading “Risk Factors.” As a result, the Company believes, in general, gross margins will be subject to volatility and downward pressure.

[0000320193-21-000105:mdna:50]
Operating Expenses

[0000320193-21-000105:mdna:51]
Operating expenses for 2021, 2020 and 2019 were as follows (dollars in millions):

[0000320193-21-000105:mdna:52]
|  | 2021 |  | Change |  | 2020 |  | Change |  | 2019 |
| Research and development | $ | 21,914 |  |  | 17 | % |  | $ | 18,752 |  |  | 16 | % |  | $ | 16,217 |  |
| Percentage of total net sales | 6 | % |  |  |  | 7 | % |  |  |  | 6 | % |
| Selling, general and administrative | $ | 21,973 |  |  | 10 | % |  | $ | 19,916 |  |  | 9 | % |  | $ | 18,245 |  |
| Percentage of total net sales | 6 | % |  |  |  | 7 | % |  |  |  | 7 | % |
| Total operating expenses | $ | 43,887 |  |  | 13 | % |  | $ | 38,668 |  |  | 12 | % |  | $ | 34,462 |  |
| Percentage of total net sales | 12 | % |  |  |  | 14 | % |  |  |  | 13 | % |

[0000320193-21-000105:mdna:53]
Research and Development

[0000320193-21-000105:mdna:54]
The year-over-year growth in R&D expense in 2021 was driven primarily by increases in headcount-related expenses, R&D-related professional services and infrastructure-related costs. The Company continues to believe that focused investments in R&D are critical to its future growth and competitive position in the marketplace, and to the development of new and updated products and services that are central to the Company’s core business strategy.

[0000320193-21-000105:mdna:55]
Selling, General and Administrative

[0000320193-21-000105:mdna:56]
The year-over-year growth in selling, general and administrative expense in 2021 was driven primarily by increases in headcount-related expenses, variable selling expenses and professional services.

[0000320193-21-000105:mdna:57]
Other Income/(Expense), Net

[0000320193-21-000105:mdna:58]
Other income/(expense), net (“OI&E”) for 2021, 2020 and 2019 was as follows (dollars in millions):

[0000320193-21-000105:mdna:59]
|  | 2021 |  | Change |  | 2020 |  | Change |  | 2019 |
| Interest and dividend income | $ | 2,843 |  |  |  |  | $ | 3,763 |  |  |  |  | $ | 4,961 |  |
| Interest expense | (2,645) |  |  |  |  | (2,873) |  |  |  |  | (3,576) |  |
| Other income/(expense), net | 60 |  |  |  |  | (87) |  |  |  |  | 422 |  |
| Total other income/(expense), net | $ | 258 |  |  | (68) | % |  | $ | 803 |  |  | (56) | % |  | $ | 1,807 |  |

[0000320193-21-000105:mdna:60]
The year-over-year decrease in OI&E during 2021 was due primarily to lower interest income and net losses on marketable securities, partially offset by positive fair value adjustments on non-marketable securities and lower interest expense on term debt.

[0000320193-21-000105:mdna:61]
Provision for Income Taxes

[0000320193-21-000105:mdna:62]
Provision for income taxes, effective tax rate and statutory federal income tax rate for 2021, 2020 and 2019 were as follows (dollars in millions):

[0000320193-21-000105:mdna:63]
|  | 2021 |  | 2020 |  | 2019 |
| Provision for income taxes | $ | 14,527 |  |  | $ | 9,680 |  |  | $ | 10,481 |  |
| Effective tax rate | 13.3 | % |  | 14.4 | % |  | 15.9 | % |
| Statutory federal income tax rate | 21 | % |  | 21 | % |  | 21 | % |

[0000320193-21-000105:mdna:64]
The Company’s effective tax rate for 2021 was lower than the statutory federal income tax rate due primarily to a lower effective tax rate on foreign earnings, tax benefits from share-based compensation and foreign-derived intangible income deductions. The Company’s effective tax rate for 2020 was lower than the statutory federal income tax rate due primarily to the lower tax rate on foreign earnings, including the impact of tax settlements, and tax benefits from share-based compensation.

[0000320193-21-000105:mdna:65]
The Company’s effective tax rate for 2021 was lower compared to 2020 due primarily to higher tax benefits from foreign-derived intangible income deductions and share-based compensation and the favorable impact of changes in unrecognized tax benefits, partially offset by a one-time adjustment in 2020 of U.S. foreign tax credits in response to regulations issued by the U.S. Department of the Treasury in December 2019.

[0000320193-21-000105:mdna:66]
During 2021, the Company established deferred tax assets (“DTAs”) for foreign tax credit carryforwards in Ireland and increased DTAs for R&D tax credit carryforwards in California, which resulted in a combined $3.5 billion increase in the valuation allowance on the Company’s DTAs, with no effect on net income. Management believes it is more likely than not that forecasted income, together with future reversals of existing taxable temporary differences, will be sufficient to realize substantially all of the Company’s remaining DTAs.

[0000320193-21-000105:mdna:67]
Liquidity and Capital Resources

[0000320193-21-000105:mdna:68]
The Company believes its balances of cash, cash equivalents and unrestricted marketable securities, which totaled $172.6 billion as of September 25, 2021, along with cash generated by ongoing operations and continued access to debt markets, will be sufficient to satisfy its cash requirements and capital return program over the next 12 months and beyond.

[0000320193-21-000105:mdna:69]
The Company’s material cash requirements include the following contractual and other obligations.

[0000320193-21-000105:mdna:70]
Debt

[0000320193-21-000105:mdna:71]
As of September 25, 2021, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $118.1 billion (collectively the “Notes”), with $9.6 billion payable within 12 months. Future interest payments associated with the Notes total $39.5 billion, with $2.9 billion payable within 12 months.

[0000320193-21-000105:mdna:72]
The Company also issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. As of September 25, 2021, the Company had $6.0 billion of Commercial Paper outstanding, all of which was payable within 12 months.

[0000320193-21-000105:mdna:73]
Leases

[0000320193-21-000105:mdna:74]
The Company has lease arrangements for certain equipment and facilities, including retail, corporate, manufacturing and data center space. As of September 25, 2021, the Company had fixed lease payment obligations of $14.6 billion, with $1.8 billion payable within 12 months.

[0000320193-21-000105:mdna:75]
Manufacturing Purchase Obligations

[0000320193-21-000105:mdna:76]
The Company utilizes several outsourcing partners to manufacture subassemblies for the Company’s products and to perform final assembly and testing of finished products. The Company also obtains individual components for its products from a wide variety of individual suppliers. Outsourcing partners acquire components and build product based on demand information supplied by the Company, which typically covers periods up to 150 days. As of September 25, 2021, the Company had manufacturing purchase obligations of $54.8 billion, with $54.7 billion payable within 12 months. The Company’s manufacturing purchase obligations are primarily noncancelable.

[0000320193-21-000105:mdna:77]
Other Purchase Obligations

[0000320193-21-000105:mdna:78]
The Company’s other purchase obligations primarily consist of noncancelable obligations to acquire capital assets, including product tooling and manufacturing process equipment, and noncancelable obligations related to advertising, content creation and Internet and telecommunications services. As of September 25, 2021, the Company had other purchase obligations of $8.3 billion, with $4.8 billion payable within 12 months.

[0000320193-21-000105:mdna:79]
Deemed Repatriation Tax Payable

[0000320193-21-000105:mdna:80]
As of September 25, 2021, the balance of the deemed repatriation tax payable imposed by the U.S. Tax Cuts and Jobs Act of 2017 (the “Act”) was $24.6 billion, none of which is payable within 12 months.

[0000320193-21-000105:mdna:81]
In addition to its cash requirements, the Company has a capital return program authorized by the Board of Directors. The Program does not obligate the Company to acquire any specific number of shares. As of September 25, 2021, the Company’s quarterly cash dividend was $0.22 per share. The Company intends to increase its dividend on an annual basis, subject to declaration by the Board of Directors.

[0000320193-21-000105:mdna:82]
Critical Accounting Estimates

[0000320193-21-000105:mdna:83]
The preparation of financial statements and related disclosures in conformity with U.S. generally accepted accounting principles (“GAAP”) and the Company’s discussion and analysis of its financial condition and operating results require the Company’s management to make judgments, assumptions and estimates that affect the amounts reported. Note 1, “Summary of Significant Accounting Policies,” of the Notes to Consolidated Financial Statements in Part II, Item 8 of this Form 10-K describes the significant accounting policies and methods used in the preparation of the Company’s consolidated financial statements. Management bases its estimates on historical experience and on various other assumptions it believes to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities.

[0000320193-21-000105:mdna:84]
Uncertain Tax Positions

[0000320193-21-000105:mdna:85]
The Company is subject to income taxes in the U.S. and numerous foreign jurisdictions. The evaluation of the Company’s uncertain tax positions involves significant judgment in the interpretation and application of GAAP and complex domestic and international tax laws, including the Act and matters related to the allocation of international taxation rights between countries. Although management believes the Company’s reserves are reasonable, no assurance can be given that the final tax outcome of these matters will not be different from that which is reflected in the Company’s reserves. Reserves are adjusted considering changing facts and circumstances, such as the closing of a tax examination or the refinement of an estimate. Resolution of these uncertainties in a manner inconsistent with management’s expectations could have a material impact on the Company’s financial condition and operating results.

[0000320193-21-000105:mdna:86]
Legal and Other Contingencies

[0000320193-21-000105:mdna:87]
The Company is subject to various legal proceedings and claims that arise in the ordinary course of business, the outcomes of which are inherently uncertain. The Company records a liability when it is probable that a loss has been incurred and the amount is reasonably estimable, the determination of which requires significant judgment. Resolution of legal matters in a manner inconsistent with management’s expectations could have a material impact on the Company’s financial condition and operating results.
