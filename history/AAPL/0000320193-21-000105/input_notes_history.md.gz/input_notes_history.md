# AAPL note change history — 0000320193-21-000056 → 0000320193-21-000065


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-07-28):
[0000320193-21-000065:note_history:1]
The following table shows changes in the Company’s accrued warranties and related costs for the three- and nine-month periods ended June 26, 2021 and June 27, 2020 (in millions):
  (was, 2021-04-29, similarity 0.9318):
[0000320193-21-000056:note_history:1]
The following table shows changes in the Company’s accrued warranties and related costs for the three- and six-month periods ended March 27, 2021 and March 28, 2020 (in millions):

- changed (2021-07-28):
[0000320193-21-000065:note_history:2]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2021 |  | June 27,2020 |  | June 26,2021 |  | June 27,2020 |
| Beginning accrued warranty and related costs | $ | 3,784 |  |  | $ | 3,923 |  |  | $ | 3,354 |  |  | $ | 3,570 |  |
| Cost of warranty claims | (636) |  |  | (576) |  |  | (2,008) |  |  | (2,180) |  |
| Accruals for product warranty | 384 |  |  | 557 |  |  | 2,186 |  |  | 2,514 |  |
| Ending accrued warranty and related costs | $ | 3,532 |  |  | $ | 3,904 |  |  | $ | 3,532 |  |  | $ | 3,904 |  |
  (was, 2021-04-29, similarity 0.8502):
[0000320193-21-000056:note_history:2]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27,2021 |  | March 28,2020 |  | March 27,2021 |  | March 28,2020 |
| Beginning accrued warranty and related costs | $ | 4,124 |  |  | $ | 3,873 |  |  | $ | 3,354 |  |  | $ | 3,570 |  |
| Cost of warranty claims | (649) |  |  | (689) |  |  | (1,372) |  |  | (1,604) |  |
| Accruals for product warranty | 309 |  |  | 739 |  |  | 1,802 |  |  | 1,957 |  |
| Ending accrued warranty and related costs | $ | 3,784 |  |  | $ | 3,923 |  |  | $ | 3,784 |  |  | $ | 3,923 |  |

- changed (2021-07-28):
[0000320193-21-000065:note_history:3]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of payments for content creation, Internet and telecommunications services and supplier arrangements. As of June 26, 2021, the Company’s total future payments under noncancelable unconditional purchase obligations having a remaining term in excess of one year were $8.8 billion.
  (was, 2021-04-29, similarity 0.991):
[0000320193-21-000056:note_history:3]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of payments for content creation, Internet and telecommunications services and supplier arrangements. As of March 27, 2021, the Company’s total future payments under noncancelable unconditional purchase obligations having a remaining term in excess of one year were $8.2 billion.

- changed (2021-07-28):
[0000320193-21-000065:note_history:4]
Optis Wireless Technology, LLC and related entities (“Optis”) filed a lawsuit in the U.S. District Court for the Eastern District of Texas against the Company alleging that certain of the Company’s products infringe on patents owned by Optis. On August 11, 2020, a jury returned a verdict against the Company and awarded damages of $506 million. In post-trial proceedings, the damages portion of the verdict was set aside, and a retrial was scheduled for August 2021. The case remains pending further proceedings.
  (was, 2021-04-29, similarity 0.9617):
[0000320193-21-000056:note_history:4]
Optis Wireless Technology, LLC and related entities (“Optis”) filed a lawsuit in the U.S. District Court for the Eastern District of Texas against the Company alleging that certain of the Company’s products infringe on patents owned by Optis. On August 11, 2020, a jury returned a verdict against the Company and awarded damages of $506 million. In post-trial proceedings, the damages portion of the verdict was set aside, and the case remains pending further proceedings.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-07-28):
[0000320193-21-000065:note_history:5]
The following table shows the computation of basic and diluted earnings per share for the three- and nine-month periods ended June 26, 2021 and June 27, 2020 (net income in millions and shares in thousands):
  (was, 2021-04-29, similarity 0.9418):
[0000320193-21-000056:note_history:5]
The following table shows the computation of basic and diluted earnings per share for the three- and six-month periods ended March 27, 2021 and March 28, 2020 (net income in millions and shares in thousands):

- changed (2021-07-28):
[0000320193-21-000065:note_history:6]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2021 |  | June 27,2020 |  | June 26,2021 |  | June 27,2020 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 21,744 |  |  | $ | 11,253 |  |  | $ | 74,129 |  |  | $ | 44,738 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 16,629,371 |  |  | 17,250,291 |  |  | 16,772,656 |  |  | 17,450,284 |  |
| Effect of dilutive securities | 152,364 |  |  | 168,863 |  |  | 168,871 |  |  | 168,494 |  |
| Weighted-average diluted shares | 16,781,735 |  |  | 17,419,154 |  |  | 16,941,527 |  |  | 17,618,778 |  |
| Basic earnings per share | $ | 1.31 |  |  | $ | 0.65 |  |  | $ | 4.42 |  |  | $ | 2.56 |  |
| Diluted earnings per share | $ | 1.30 |  |  | $ | 0.65 |  |  | $ | 4.38 |  |  | $ | 2.54 |  |
  (was, 2021-04-29, similarity 0.8908):
[0000320193-21-000056:note_history:6]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27,2021 |  | March 28,2020 |  | March 27,2021 |  | March 28,2020 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 23,630 |  |  | $ | 11,249 |  |  | $ | 52,385 |  |  | $ | 33,485 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 16,753,476 |  |  | 17,440,402 |  |  | 16,844,298 |  |  | 17,550,281 |  |
| Effect of dilutive securities | 175,681 |  |  | 178,363 |  |  | 177,125 |  |  | 168,310 |  |
| Weighted-average diluted shares | 16,929,157 |  |  | 17,618,765 |  |  | 17,021,423 |  |  | 17,718,591 |  |
| Basic earnings per share | $ | 1.41 |  |  | $ | 0.64 |  |  | $ | 3.11 |  |  | $ | 1.91 |  |
| Diluted earnings per share | $ | 1.40 |  |  | $ | 0.64 |  |  | $ | 3.08 |  |  | $ | 1.89 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-07-28):
[0000320193-21-000065:note_history:7]
Debt
Commercial Paper and Repurchase Agreements
  (was, 2021-04-29, similarity 0.9892):
[0000320193-21-000056:note_history:7]
Debt
Commercial Paper and Repurchase Agreement

- changed (2021-07-28):
[0000320193-21-000065:note_history:8]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of June 26, 2021 and September 26, 2020, the Company had $8.0 billion and $5.0 billion of Commercial Paper outstanding, respectively, with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 0.04% and 0.62% as of June 26, 2021 and September 26, 2020, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the nine months ended June 26, 2021 and June 27, 2020 (in millions):
  (was, 2021-04-29, similarity 0.852):
[0000320193-21-000056:note_history:8]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of both March 27, 2021 and September 26, 2020, the Company had $5.0 billion of Commercial Paper outstanding, with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 0.06% and 0.62% as of March 27, 2021 and September 26, 2020, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the six months ended March 27, 2021 and March 28, 2020 (in millions):

- changed (2021-07-28):
[0000320193-21-000065:note_history:9]
|  | Nine Months Ended |
|  | June 26,2021 |  | June 27,2020 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from commercial paper, net | $ | 2,745 |  |  | $ | 401 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 3,993 |  |  | 5,373 |  |
| Repayments of commercial paper | (3,716) |  |  | (5,743) |  |
| Proceeds from/(Repayments of) commercial paper, net | 277 |  |  | (370) |  |
| Total proceeds from commercial paper, net | $ | 3,022 |  |  | $ | 31 |  |
  (was, 2021-04-29, similarity 0.9361):
[0000320193-21-000056:note_history:9]
|  | Six Months Ended |
|  | March 27,2021 |  | March 28,2020 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from commercial paper, net | $ | 2,008 |  |  | $ | 1,377 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 1,368 |  |  | 4,797 |  |
| Repayments of commercial paper | (3,354) |  |  | (4,656) |  |
| Proceeds from/(Repayments of) commercial paper, net | (1,986) |  |  | 141 |  |
| Total proceeds from commercial paper, net | $ | 22 |  |  | $ | 1,518 |  |

- changed (2021-07-28):
[0000320193-21-000065:note_history:10]
In 2020, the Company entered into agreements to sell certain of its marketable securities with a promise to repurchase the securities at a specified time and amount (“Repos”). Due to the Company’s continuing involvement with the marketable securities, the Company accounted for its Repos as collateralized borrowings. As of September 26, 2020, the Repos had been settled.
  (was, 2021-04-29, similarity 0.9274):
[0000320193-21-000056:note_history:10]
In the second quarter of 2020, the Company entered into an agreement to sell certain of its marketable securities with a promise to repurchase the securities at a specified time and amount (“Repo”). Due to the Company’s continuing involvement with the marketable securities, the Company accounted for the Repo as a collateralized borrowing. As of September 26, 2020, the Repo had been settled.

- changed (2021-07-28):
[0000320193-21-000065:note_history:11]
As of June 26, 2021, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $113.2 billion (collectively the “Notes”). The Notes are senior unsecured obligations and interest is payable in arrears. The following table provides a summary of the Company’s term debt as of June 26, 2021 and September 26, 2020:
  (was, 2021-04-29, similarity 0.9745):
[0000320193-21-000056:note_history:11]
As of March 27, 2021, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $116.0 billion (collectively the “Notes”). The Notes are senior unsecured obligations and interest is payable in arrears. The following table provides a summary of the Company’s term debt as of March 27, 2021 and September 26, 2020:

- changed (2021-07-28):
[0000320193-21-000065:note_history:12]
|  | Maturities(calendar year) |  | June 26, 2021 |  | September 26, 2020 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 – 2020 debt issuances: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2022 |  | $ | 1,750 |  |  | 0.51% – 0.66% |  | $ | 2,250 |  |  | 0.60% – 1.39% |
| Fixed-rate 0.000% – 4.650% notes | 2021 – 2060 |  | 97,443 |  |  | 0.03% – 4.78% |  | 103,828 |  |  | 0.03% – 4.78% |
| 2021 debt issuance: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.700% – 2.800% notes | 2026 – 2061 |  | 14,000 |  |  | 0.75% – 2.81% |  | — |  |  | — | % |
| Total term debt |  |  | 113,193 |  |  |  |  | 106,078 |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  | (360) |  |  |  |  | (314) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 958 |  |  |  |  | 1,676 |  |  |  |
| Less: Current portion of term debt |  |  | (8,039) |  |  |  |  | (8,773) |  |  |  |
| Total non-current portion of term debt |  |  | $ | 105,752 |  |  |  |  | $ | 98,667 |  |  |  |
  (was, 2021-04-29, similarity 0.9946):
[0000320193-21-000056:note_history:12]
|  | Maturities(calendar year) |  | March 27, 2021 |  | September 26, 2020 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 – 2020 debt issuances: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2022 |  | $ | 1,750 |  |  | 0.55% – 0.69% |  | $ | 2,250 |  |  | 0.60% – 1.39% |
| Fixed-rate 0.000% – 4.650% notes | 2021 – 2060 |  | 100,255 |  |  | 0.03% – 4.78% |  | 103,828 |  |  | 0.03% – 4.78% |
| 2021 debt issuance: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.700% – 2.800% notes | 2026 – 2061 |  | 14,000 |  |  | 0.75% – 2.81% |  | — |  |  | — | % |
| Total term debt |  |  | 116,005 |  |  |  |  | 106,078 |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  | (371) |  |  |  |  | (314) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 1,011 |  |  |  |  | 1,676 |  |  |  |
| Less: Current portion of term debt |  |  | (8,003) |  |  |  |  | (8,773) |  |  |  |
| Total non-current portion of term debt |  |  | $ | 108,642 |  |  |  |  | $ | 98,667 |  |  |  |

- changed (2021-07-28):
[0000320193-21-000065:note_history:13]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $657 million and $1.9 billion of interest cost on its term debt for the three- and nine-month periods ended June 26, 2021, respectively. The Company recognized $664 million and $2.1 billion of interest cost on its term debt for the three- and nine-month periods ended June 27, 2020, respectively.
  (was, 2021-04-29, similarity 0.9659):
[0000320193-21-000056:note_history:13]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $657 million and $1.3 billion of interest cost on its term debt for the three- and six-month periods ended March 27, 2021, respectively. The Company recognized $725 million and $1.5 billion of interest cost on its term debt for the three- and six-month periods ended March 28, 2020, respectively.

- changed (2021-07-28):
[0000320193-21-000065:note_history:14]
As of June 26, 2021 and September 26, 2020, the fair value of the Company’s Notes, based on Level 2 inputs, was $120.3 billion and $117.1 billion, respectively.
  (was, 2021-04-29, similarity 0.9682):
[0000320193-21-000056:note_history:14]
As of March 27, 2021 and September 26, 2020, the fair value of the Company’s Notes, based on Level 2 inputs, was $121.2 billion and $117.1 billion, respectively.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-07-28):
[0000320193-21-000065:note_history:15]
The following table provides a summary of the Company’s term debt as of June 26, 2021 and September 26, 2020:
  (was, 2021-04-29, similarity 0.9548):
[0000320193-21-000056:note_history:15]
The following table provides a summary of the Company’s term debt as of March 27, 2021 and September 26, 2020:

- changed (2021-07-28):
[0000320193-21-000065:note_history:16]
|  | Maturities(calendar year) |  | June 26, 2021 |  | September 26, 2020 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 – 2020 debt issuances: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2022 |  | $ | 1,750 |  |  | 0.51% – 0.66% |  | $ | 2,250 |  |  | 0.60% – 1.39% |
| Fixed-rate 0.000% – 4.650% notes | 2021 – 2060 |  | 97,443 |  |  | 0.03% – 4.78% |  | 103,828 |  |  | 0.03% – 4.78% |
| 2021 debt issuance: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.700% – 2.800% notes | 2026 – 2061 |  | 14,000 |  |  | 0.75% – 2.81% |  | — |  |  | — | % |
| Total term debt |  |  | 113,193 |  |  |  |  | 106,078 |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  | (360) |  |  |  |  | (314) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 958 |  |  |  |  | 1,676 |  |  |  |
| Less: Current portion of term debt |  |  | (8,039) |  |  |  |  | (8,773) |  |  |  |
| Total non-current portion of term debt |  |  | $ | 105,752 |  |  |  |  | $ | 98,667 |  |  |  |
  (was, 2021-04-29, similarity 0.9946):
[0000320193-21-000056:note_history:16]
|  | Maturities(calendar year) |  | March 27, 2021 |  | September 26, 2020 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 – 2020 debt issuances: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2022 |  | $ | 1,750 |  |  | 0.55% – 0.69% |  | $ | 2,250 |  |  | 0.60% – 1.39% |
| Fixed-rate 0.000% – 4.650% notes | 2021 – 2060 |  | 100,255 |  |  | 0.03% – 4.78% |  | 103,828 |  |  | 0.03% – 4.78% |
| 2021 debt issuance: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.700% – 2.800% notes | 2026 – 2061 |  | 14,000 |  |  | 0.75% – 2.81% |  | — |  |  | — | % |
| Total term debt |  |  | 116,005 |  |  |  |  | 106,078 |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  | (371) |  |  |  |  | (314) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 1,011 |  |  |  |  | 1,676 |  |  |  |
| Less: Current portion of term debt |  |  | (8,003) |  |  |  |  | (8,773) |  |  |  |
| Total non-current portion of term debt |  |  | $ | 108,642 |  |  |  |  | $ | 98,667 |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-07-28):
[0000320193-21-000065:note_history:17]
Net sales disaggregated by significant products and services for the three- and nine-month periods ended June 26, 2021 and June 27, 2020 were as follows (in millions):
  (was, 2021-04-29, similarity 0.927):
[0000320193-21-000056:note_history:17]
Net sales disaggregated by significant products and services for the three- and six-month periods ended March 27, 2021 and March 28, 2020 were as follows (in millions):

- changed (2021-07-28):
[0000320193-21-000065:note_history:18]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2021 |  | June 27,2020 |  | June 26,2021 |  | June 27,2020 |
| iPhone (1) | $ | 39,570 |  |  | $ | 26,418 |  |  | $ | 153,105 |  |  | $ | 111,337 |  |
| Mac (1) | 8,235 |  |  | 7,079 |  |  | 26,012 |  |  | 19,590 |  |
| iPad (1) | 7,368 |  |  | 6,582 |  |  | 23,610 |  |  | 16,927 |  |
| Wearables, Home and Accessories (1)(2) | 8,775 |  |  | 6,450 |  |  | 29,582 |  |  | 22,744 |  |
| Services (3) | 17,486 |  |  | 13,156 |  |  | 50,148 |  |  | 39,219 |  |
| Total net sales (4) | $ | 81,434 |  |  | $ | 59,685 |  |  | $ | 282,457 |  |  | $ | 209,817 |  |
  (was, 2021-04-29, similarity 0.8568):
[0000320193-21-000056:note_history:18]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27,2021 |  | March 28,2020 |  | March 27,2021 |  | March 28,2020 |
| iPhone (1) | $ | 47,938 |  |  | $ | 28,962 |  |  | $ | 113,535 |  |  | $ | 84,919 |  |
| Mac (1) | 9,102 |  |  | 5,351 |  |  | 17,777 |  |  | 12,511 |  |
| iPad (1) | 7,807 |  |  | 4,368 |  |  | 16,242 |  |  | 10,345 |  |
| Wearables, Home and Accessories (1)(2) | 7,836 |  |  | 6,284 |  |  | 20,807 |  |  | 16,294 |  |
| Services (3) | 16,901 |  |  | 13,348 |  |  | 32,662 |  |  | 26,063 |  |
| Total net sales (4) | $ | 89,584 |  |  | $ | 58,313 |  |  | $ | 201,023 |  |  | $ | 150,132 |  |

- changed (2021-07-28):
[0000320193-21-000065:note_history:19]
(4)Includes $3.0 billion of revenue recognized in the three months ended June 26, 2021 that was included in deferred revenue as of March 27, 2021, $2.1 billion of revenue recognized in the three months ended June 27, 2020 that was included in deferred revenue as of March 28, 2020, $5.5 billion of revenue recognized in the nine months ended June 26, 2021 that was included in deferred revenue as of September 26, 2020, and $4.0 billion of revenue recognized in the nine months ended June 27, 2020 that was included in deferred revenue as of September 28, 2019.
  (was, 2021-04-29, similarity 0.8713):
[0000320193-21-000056:note_history:19]
(4)Includes $2.7 billion of revenue recognized in the three months ended March 27, 2021 that was included in deferred revenue as of December 26, 2020, $1.9 billion of revenue recognized in the three months ended March 28, 2020 that was included in deferred revenue as of December 28, 2019, $4.1 billion of revenue recognized in the six months ended March 27, 2021 that was included in deferred revenue as of September 26, 2020, and $3.0 billion of revenue recognized in the six months ended March 28, 2020 that was included in deferred revenue as of September 28, 2019.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2021-07-28):
[0000320193-21-000065:note_history:20]
As of June 26, 2021 and September 26, 2020, the Company had total deferred revenue of $12.0 billion and $10.2 billion, respectively. As of June 26, 2021, the Company expects 64% of total deferred revenue to be realized in less than a year, 26% within one-to-two years, 8% within two-to-three years and 2% in greater than three years.

- changed (2021-07-28):
[0000320193-21-000065:note_history:21]
Net sales disaggregated by significant products and services for the three- and nine-month periods ended June 26, 2021 and June 27, 2020 were as follows (in millions):
  (was, 2021-04-29, similarity 0.927):
[0000320193-21-000056:note_history:21]
Net sales disaggregated by significant products and services for the three- and six-month periods ended March 27, 2021 and March 28, 2020 were as follows (in millions):

- changed (2021-07-28):
[0000320193-21-000065:note_history:22]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2021 |  | June 27,2020 |  | June 26,2021 |  | June 27,2020 |
| iPhone (1) | $ | 39,570 |  |  | $ | 26,418 |  |  | $ | 153,105 |  |  | $ | 111,337 |  |
| Mac (1) | 8,235 |  |  | 7,079 |  |  | 26,012 |  |  | 19,590 |  |
| iPad (1) | 7,368 |  |  | 6,582 |  |  | 23,610 |  |  | 16,927 |  |
| Wearables, Home and Accessories (1)(2) | 8,775 |  |  | 6,450 |  |  | 29,582 |  |  | 22,744 |  |
| Services (3) | 17,486 |  |  | 13,156 |  |  | 50,148 |  |  | 39,219 |  |
| Total net sales (4) | $ | 81,434 |  |  | $ | 59,685 |  |  | $ | 282,457 |  |  | $ | 209,817 |  |
  (was, 2021-04-29, similarity 0.8568):
[0000320193-21-000056:note_history:22]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27,2021 |  | March 28,2020 |  | March 27,2021 |  | March 28,2020 |
| iPhone (1) | $ | 47,938 |  |  | $ | 28,962 |  |  | $ | 113,535 |  |  | $ | 84,919 |  |
| Mac (1) | 9,102 |  |  | 5,351 |  |  | 17,777 |  |  | 12,511 |  |
| iPad (1) | 7,807 |  |  | 4,368 |  |  | 16,242 |  |  | 10,345 |  |
| Wearables, Home and Accessories (1)(2) | 7,836 |  |  | 6,284 |  |  | 20,807 |  |  | 16,294 |  |
| Services (3) | 16,901 |  |  | 13,348 |  |  | 32,662 |  |  | 26,063 |  |
| Total net sales (4) | $ | 89,584 |  |  | $ | 58,313 |  |  | $ | 201,023 |  |  | $ | 150,132 |  |

- changed (2021-07-28):
[0000320193-21-000065:note_history:23]
(4)Includes $3.0 billion of revenue recognized in the three months ended June 26, 2021 that was included in deferred revenue as of March 27, 2021, $2.1 billion of revenue recognized in the three months ended June 27, 2020 that was included in deferred revenue as of March 28, 2020, $5.5 billion of revenue recognized in the nine months ended June 26, 2021 that was included in deferred revenue as of September 26, 2020, and $4.0 billion of revenue recognized in the nine months ended June 27, 2020 that was included in deferred revenue as of September 28, 2019.
  (was, 2021-04-29, similarity 0.8713):
[0000320193-21-000056:note_history:23]
(4)Includes $2.7 billion of revenue recognized in the three months ended March 27, 2021 that was included in deferred revenue as of December 26, 2020, $1.9 billion of revenue recognized in the three months ended March 28, 2020 that was included in deferred revenue as of December 28, 2019, $4.1 billion of revenue recognized in the six months ended March 27, 2021 that was included in deferred revenue as of September 26, 2020, and $3.0 billion of revenue recognized in the six months ended March 28, 2020 that was included in deferred revenue as of September 28, 2019.

- changed (2021-07-28):
[0000320193-21-000065:note_history:24]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 11, “Segment Information and Geographic Data” for the three- and nine-month periods ended June 26, 2021 and June 27, 2020.
  (was, 2021-04-29, similarity 0.894):
[0000320193-21-000056:note_history:24]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 11, “Segment Information and Geographic Data” for the three- and six-month periods ended March 27, 2021 and March 28, 2020.

- removed (2021-07-28):
[0000320193-21-000056:note_history:25]
As of March 27, 2021 and September 26, 2020, the Company had total deferred revenue of $11.9 billion and $10.2 billion, respectively. As of March 27, 2021, the Company expects 64% of total deferred revenue to be realized in less than a year, 26% within one-to-two years, 8% within two-to-three years and 2% in greater than three years.
