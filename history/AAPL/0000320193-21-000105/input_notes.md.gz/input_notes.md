# AAPL notes — 0000320193-21-000105


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000320193-21-000105:notes:1]
Summary of Significant Accounting Policies
Basis of Presentation and Preparation

[0000320193-21-000105:notes:2]
The consolidated financial statements include the accounts of Apple Inc. and its wholly owned subsidiaries (collectively “Apple” or the “Company”). Intercompany accounts and transactions have been eliminated. In the opinion of the Company’s management, the consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these consolidated financial statements and accompanying notes in conformity with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported. Actual results could differ materially from those estimates. Certain prior period amounts in the consolidated financial statements and accompanying notes have been reclassified to conform to the current period’s presentation.

[0000320193-21-000105:notes:3]
The Company’s fiscal year is the 52- or 53-week period that ends on the last Saturday of September. An additional week is included in the first fiscal quarter every five or six years to realign the Company’s fiscal quarters with calendar quarters. The Company’s fiscal years 2021, 2020 and 2019 spanned 52 weeks each. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in September and the associated quarters, months and periods of those fiscal years.

[0000320193-21-000105:notes:4]
Recently Adopted Accounting Pronouncements

[0000320193-21-000105:notes:5]
Financial Instruments – Credit Losses

[0000320193-21-000105:notes:6]
At the beginning of the first quarter of 2021, the Company adopted the Financial Accounting Standards Board’s (the “FASB”) Accounting Standards Update (“ASU”) No. 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (“ASU 2016-13”), which modifies the measurement of expected credit losses on certain financial instruments. The Company adopted ASU 2016-13 utilizing the modified retrospective transition method. The adoption of ASU 2016-13 did not have a material impact on the Company’s condensed consolidated financial statements.

[0000320193-21-000105:notes:7]
Advertising Costs

[0000320193-21-000105:notes:8]
Advertising costs are expensed as incurred and included in selling, general and administrative expenses.

[0000320193-21-000105:notes:9]
Share-Based Compensation

[0000320193-21-000105:notes:10]
The Company generally measures share-based compensation based on the closing price of the Company’s common stock on the date of grant, and recognizes expense on a straight-line basis for its estimate of equity awards that will ultimately vest. Further information regarding share-based compensation can be found in Note 9, “Benefit Plans.”

[0000320193-21-000105:notes:11]
Earnings Per Share

[0000320193-21-000105:notes:12]
The following table shows the computation of basic and diluted earnings per share for 2021, 2020 and 2019 (net income in millions and shares in thousands):

[0000320193-21-000105:notes:13]
|  | 2021 |  | 2020 |  | 2019 |
| Numerator: |  |  |  |  |  |
| Net income | $ | 94,680 |  |  | $ | 57,411 |  |  | $ | 55,256 |  |
| Denominator: |  |  |  |  |  |
| Weighted-average basic shares outstanding | 16,701,272 |  |  | 17,352,119 |  |  | 18,471,336 |  |
| Effect of dilutive securities | 163,647 |  |  | 176,095 |  |  | 124,315 |  |
| Weighted-average diluted shares | 16,864,919 |  |  | 17,528,214 |  |  | 18,595,651 |  |
| Basic earnings per share | $ | 5.67 |  |  | $ | 3.31 |  |  | $ | 2.99 |  |
| Diluted earnings per share | $ | 5.61 |  |  | $ | 3.28 |  |  | $ | 2.97 |  |

[0000320193-21-000105:notes:14]
The Company applies the treasury stock method to determine the dilutive effect of potentially dilutive securities. Potentially dilutive securities representing 62 million shares of common stock were excluded from the computation of diluted earnings per share for 2019 because their effect would have been antidilutive.

[0000320193-21-000105:notes:15]
Cash Equivalents and Marketable Securities

[0000320193-21-000105:notes:16]
All highly liquid investments with maturities of three months or less at the date of purchase are classified as cash equivalents.

[0000320193-21-000105:notes:17]
The Company’s investments in marketable debt securities have been classified and accounted for as available-for-sale. The Company classifies its marketable debt securities as either short-term or long-term based on each instrument’s underlying contractual maturity date. Unrealized gains and losses on marketable debt securities classified as available-for-sale are recognized in other comprehensive income/(loss) (“OCI”).

[0000320193-21-000105:notes:18]
The Company’s investments in marketable equity securities are classified based on the nature of the securities and their availability for use in current operations. The Company’s marketable equity securities are measured at fair value with gains and losses recognized in other income/(expense), net (“OI&E”).

[0000320193-21-000105:notes:19]
The cost of securities sold is determined using the specific identification method.

[0000320193-21-000105:notes:20]
Inventories

[0000320193-21-000105:notes:21]
Inventories are measured using the first-in, first-out method.

[0000320193-21-000105:notes:22]
Property, Plant and Equipment

[0000320193-21-000105:notes:23]
Depreciation on property, plant and equipment is recognized on a straight-line basis over the estimated useful lives of the assets, which for buildings is the lesser of 40 years or the remaining life of the building; between one and five years for machinery and equipment, including product tooling and manufacturing process equipment; and the shorter of lease term or useful life for leasehold improvements. Capitalized costs related to internal-use software are amortized on a straight-line basis over the estimated useful lives of the assets, which range from five to seven years. Depreciation and amortization expense on property and equipment was $9.5 billion, $9.7 billion and $11.3 billion during 2021, 2020 and 2019, respectively.

[0000320193-21-000105:notes:24]
Noncash investing activities involving property, plant and equipment resulted in a net decrease to accounts payable and other current liabilities of $2.9 billion during 2019.

[0000320193-21-000105:notes:25]
Restricted Cash and Restricted Marketable Securities

[0000320193-21-000105:notes:26]
The Company considers cash and marketable securities to be restricted when withdrawal or general use is legally restricted. The Company reports restricted cash as other assets in the Consolidated Balance Sheets, and determines current or non-current classification based on the expected duration of the restriction. The Company reports restricted marketable securities as current or non-current marketable securities in the Consolidated Balance Sheets based on the classification of the underlying securities.

[0000320193-21-000105:notes:27]
Derivative Instruments and Hedging

[0000320193-21-000105:notes:28]
All derivative instruments are recorded in the Consolidated Balance Sheets at fair value. The accounting treatment for derivative gains and losses is based on intended use and hedge designation.

[0000320193-21-000105:notes:29]
Gains and losses arising from amounts that are included in the assessment of cash flow hedge effectiveness are initially deferred in accumulated other comprehensive income/(loss) (“AOCI”) and subsequently reclassified into earnings when the hedged transaction affects earnings, and in the same line item in the Consolidated Statements of Operations. For options designated as cash flow hedges, the Company excludes time value from the assessment of hedge effectiveness and recognizes it on a straight-line basis over the life of the hedge in the Consolidated Statements of Operations line item to which the hedge relates. Changes in the fair value of amounts excluded from the assessment of hedge effectiveness are recognized in OCI.

[0000320193-21-000105:notes:30]
Gains and losses arising from amounts that are included in the assessment of fair value hedge effectiveness are recognized in the Consolidated Statements of Operations line item to which the hedge relates along with offsetting losses and gains related to the change in value of the hedged item. For foreign exchange forward contracts designated as fair value hedges, the Company excludes the forward carry component from the assessment of hedge effectiveness and recognizes it in OI&E on a straight-line basis over the life of the hedge. Changes in the fair value of amounts excluded from the assessment of hedge effectiveness are recognized in OCI.

[0000320193-21-000105:notes:31]
Gains and losses arising from changes in the fair values of derivative instruments that are not designated as accounting hedges are recognized in the Consolidated Statements of Operations line items to which the derivative instruments relate.

[0000320193-21-000105:notes:32]
The Company presents derivative assets and liabilities at their gross fair values in the Consolidated Balance Sheets. The Company classifies cash flows related to derivative instruments as operating activities in the Consolidated Statements of Cash Flows.

[0000320193-21-000105:notes:33]
Fair Value Measurements

[0000320193-21-000105:notes:34]
The fair values of the Company’s money market funds and certain marketable equity securities are based on quoted prices in active markets for identical assets. The valuation techniques used to measure the fair value of the Company’s debt instruments and all other financial instruments, which generally have counterparties with high credit ratings, are based on quoted market prices or model-driven valuations using significant inputs derived from or corroborated by observable market data.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000320193-21-000105:notes:35]
The fair values of the Company’s money market funds and certain marketable equity securities are based on quoted prices in active markets for identical assets. The valuation techniques used to measure the fair value of the Company’s debt instruments and all other financial instruments, which generally have counterparties with high credit ratings, are based on quoted market prices or model-driven valuations using significant inputs derived from or corroborated by observable market data.
Level 1 fair value estimates are based on quoted prices in active markets for identical assets or liabilities.Level 2 fair value estimates are based on observable inputs other than quoted prices in active markets for identical assets and liabilities, quoted prices for identical or similar assets or liabilities in inactive markets, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000320193-21-000105:notes:36]
Revenue Recognition
Net sales consist of revenue from the sale of iPhone, Mac, iPad, Services and other products. The Company recognizes revenue at the amount to which it expects to be entitled when control of the products or services is transferred to its customers. Control is generally transferred when the Company has a present right to payment and title and the significant risks and rewards of ownership of products or services are transferred to its customers. For most of the Company’s Products net sales, control transfers when products are shipped. For the Company’s Services net sales, control transfers over time as services are delivered. Payment for Products and Services net sales is collected within a short period following transfer of control or commencement of delivery of services, as applicable.

[0000320193-21-000105:notes:37]
The Company records reductions to Products net sales related to future product returns, price protection and other customer incentive programs based on the Company’s expectations and historical experience.

[0000320193-21-000105:notes:38]
For arrangements with multiple performance obligations, which represent promises within an arrangement that are distinct, the Company allocates revenue to all distinct performance obligations based on their relative stand-alone selling prices (“SSPs”). When available, the Company uses observable prices to determine SSPs. When observable prices are not available, SSPs are established that reflect the Company’s best estimates of what the selling prices of the performance obligations would be if they were sold regularly on a stand-alone basis. The Company’s process for estimating SSPs without observable prices considers multiple factors that may vary depending upon the unique facts and circumstances related to each performance obligation including, where applicable, prices charged by the Company for similar offerings, market trends in the pricing for similar offerings, product-specific business objectives and the estimated cost to provide the performance obligation.

[0000320193-21-000105:notes:39]
The Company has identified up to three performance obligations regularly included in arrangements involving the sale of iPhone, Mac, iPad and certain other products. The first performance obligation, which represents the substantial portion of the allocated sales price, is the hardware and bundled software delivered at the time of sale. The second performance obligation is the right to receive certain product-related bundled services, which include iCloud®, Siri and Maps. The third performance obligation is the right to receive, on a when-and-if-available basis, future unspecified software upgrades relating to the software bundled with each device. The Company allocates revenue and any related discounts to these performance obligations based on their relative SSPs. Because the Company lacks observable prices for the undelivered performance obligations, the allocation of revenue is based on the Company’s estimated SSPs. Revenue allocated to the delivered hardware and bundled software is recognized when control has transferred to the customer, which generally occurs when the product is shipped. Revenue allocated to the product-related bundled services and unspecified software upgrade rights is deferred and recognized on a straight-line basis over the estimated period they are expected to be provided. Cost of sales related to delivered hardware and bundled software, including estimated warranty costs, are recognized at the time of sale. Costs incurred to provide product-related bundled services and unspecified software upgrade rights are recognized as cost of sales as incurred.

[0000320193-21-000105:notes:40]
For certain long-term service arrangements, the Company has performance obligations for services it has not yet delivered. For these arrangements, the Company does not have a right to bill for the undelivered services. The Company has determined that any unbilled consideration relates entirely to the value of the undelivered services. Accordingly, the Company has not recognized revenue, and has elected not to disclose amounts, related to these undelivered services.

[0000320193-21-000105:notes:41]
For the sale of third-party products where the Company obtains control of the product before transferring it to the customer, the Company recognizes revenue based on the gross amount billed to customers. The Company considers multiple factors when determining whether it obtains control of third-party products including, but not limited to, evaluating if it can establish the price of the product, retains inventory risk for tangible products or has the responsibility for ensuring acceptability of the product. For third-party applications sold through the App Store and certain digital content sold through the Company’s other digital content stores, the Company does not obtain control of the product before transferring it to the customer. Therefore, the Company accounts for such sales on a net basis by recognizing in Services net sales only the commission it retains.

[0000320193-21-000105:notes:42]
The Company has elected to record revenue net of taxes collected from customers that are remitted to governmental authorities, with the collected taxes recorded within other current liabilities until remitted to the relevant government authority.

[0000320193-21-000105:notes:43]
Deferred Revenue

[0000320193-21-000105:notes:44]
As of September 25, 2021 and September 26, 2020, the Company had total deferred revenue of $11.9 billion and $10.2 billion, respectively. As of September 25, 2021, the Company expects 64% of total deferred revenue to be realized in less than a year, 26% within one-to-two years, 8% within two-to-three years and 2% in greater than three years.

[0000320193-21-000105:notes:45]
Disaggregated Revenue

[0000320193-21-000105:notes:46]
Net sales disaggregated by significant products and services for 2021, 2020 and 2019 were as follows (in millions):

[0000320193-21-000105:notes:47]
|  | 2021 |  | 2020 |  | 2019 |
| iPhone (1) | $ | 191,973 |  |  | $ | 137,781 |  |  | $ | 142,381 |  |
| Mac (1) | 35,190 |  |  | 28,622 |  |  | 25,740 |  |
| iPad (1) | 31,862 |  |  | 23,724 |  |  | 21,280 |  |
| Wearables, Home and Accessories (1)(2) | 38,367 |  |  | 30,620 |  |  | 24,482 |  |
| Services (3) | 68,425 |  |  | 53,768 |  |  | 46,291 |  |
| Total net sales (4) | $ | 365,817 |  |  | $ | 274,515 |  |  | $ | 260,174 |  |

[0000320193-21-000105:notes:48]
(1)Products net sales include amortization of the deferred value of unspecified software upgrade rights, which are bundled in the sales price of the respective product.

[0000320193-21-000105:notes:49]
(2)Wearables, Home and Accessories net sales include sales of AirPods, Apple TV, Apple Watch, Beats products, HomePod, iPod touch and accessories.

[0000320193-21-000105:notes:50]
(3)Services net sales include sales from the Company’s advertising, AppleCare, cloud, digital content, payment and other services. Services net sales also include amortization of the deferred value of services bundled in the sales price of certain products.

[0000320193-21-000105:notes:51]
(4)Includes $6.7 billion of revenue recognized in 2021 that was included in deferred revenue as of September 26, 2020, $5.0 billion of revenue recognized in 2020 that was included in deferred revenue as of September 28, 2019, and $5.9 billion of revenue recognized in 2019 that was included in deferred revenue as of September 29, 2018.

[0000320193-21-000105:notes:52]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 11, “Segment Information and Geographic Data” for 2021, 2020 and 2019.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000320193-21-000105:notes:53]
Financial Instruments
Cash, Cash Equivalents and Marketable Securities

[0000320193-21-000105:notes:54]
The following tables show the Company’s cash, cash equivalents and marketable securities by significant investment category as of September 25, 2021 and September 26, 2020 (in millions):

[0000320193-21-000105:notes:55]
|  | 2021 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | CurrentMarketableSecurities |  | Non-CurrentMarketableSecurities |
| Cash | $ | 17,305 |  |  | $ | — |  |  | $ | — |  |  | $ | 17,305 |  |  | $ | 17,305 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 9,608 |  |  | — |  |  | — |  |  | 9,608 |  |  | 9,608 |  |  | — |  |  | — |  |
| Mutual funds | 175 |  |  | 11 |  |  | (1) |  |  | 185 |  |  | — |  |  | 185 |  |  | — |  |
| Subtotal | 9,783 |  |  | 11 |  |  | (1) |  |  | 9,793 |  |  | 9,608 |  |  | 185 |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities | 1,527 |  |  | — |  |  | (564) |  |  | 963 |  |  | — |  |  | 963 |  |  | — |  |
| U.S. Treasury securities | 22,878 |  |  | 102 |  |  | (77) |  |  | 22,903 |  |  | 3,596 |  |  | 6,625 |  |  | 12,682 |  |
| U.S. agency securities | 8,949 |  |  | 2 |  |  | (64) |  |  | 8,887 |  |  | 1,775 |  |  | 1,930 |  |  | 5,182 |  |
| Non-U.S. government securities | 20,201 |  |  | 211 |  |  | (101) |  |  | 20,311 |  |  | 390 |  |  | 3,091 |  |  | 16,830 |  |
| Certificates of deposit and time deposits | 1,300 |  |  | — |  |  | — |  |  | 1,300 |  |  | 490 |  |  | 810 |  |  | — |  |
| Commercial paper | 2,639 |  |  | — |  |  | — |  |  | 2,639 |  |  | 1,776 |  |  | 863 |  |  | — |  |
| Corporate debt securities | 83,883 |  |  | 1,242 |  |  | (267) |  |  | 84,858 |  |  | — |  |  | 12,327 |  |  | 72,531 |  |
| Municipal securities | 967 |  |  | 14 |  |  | — |  |  | 981 |  |  | — |  |  | 130 |  |  | 851 |  |
| Mortgage- and asset-backed securities | 20,529 |  |  | 171 |  |  | (124) |  |  | 20,576 |  |  | — |  |  | 775 |  |  | 19,801 |  |
| Subtotal | 162,873 |  |  | 1,742 |  |  | (1,197) |  |  | 163,418 |  |  | 8,027 |  |  | 27,514 |  |  | 127,877 |  |
| Total (3) | $ | 189,961 |  |  | $ | 1,753 |  |  | $ | (1,198) |  |  | $ | 190,516 |  |  | $ | 34,940 |  |  | $ | 27,699 |  |  | $ | 127,877 |  |

[0000320193-21-000105:notes:56]
|  | 2020 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | CurrentMarketableSecurities |  | Non-CurrentMarketableSecurities |
| Cash | $ | 17,773 |  |  | $ | — |  |  | $ | — |  |  | $ | 17,773 |  |  | $ | 17,773 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): Money market funds | 2,171 |  |  | — |  |  | — |  |  | 2,171 |  |  | 2,171 |  |  | — |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 28,439 |  |  | 331 |  |  | — |  |  | 28,770 |  |  | 8,580 |  |  | 11,972 |  |  | 8,218 |  |
| U.S. agency securities | 8,604 |  |  | 8 |  |  | — |  |  | 8,612 |  |  | 2,009 |  |  | 3,078 |  |  | 3,525 |  |
| Non-U.S. government securities | 19,361 |  |  | 275 |  |  | (186) |  |  | 19,450 |  |  | 255 |  |  | 3,329 |  |  | 15,866 |  |
| Certificates of deposit and time deposits | 10,399 |  |  | — |  |  | — |  |  | 10,399 |  |  | 4,043 |  |  | 6,246 |  |  | 110 |  |
| Commercial paper | 11,226 |  |  | — |  |  | — |  |  | 11,226 |  |  | 3,185 |  |  | 8,041 |  |  | — |  |
| Corporate debt securities | 76,937 |  |  | 1,834 |  |  | (175) |  |  | 78,596 |  |  | — |  |  | 19,687 |  |  | 58,909 |  |
| Municipal securities | 1,001 |  |  | 22 |  |  | — |  |  | 1,023 |  |  | — |  |  | 139 |  |  | 884 |  |
| Mortgage- and asset-backed securities | 13,520 |  |  | 314 |  |  | (24) |  |  | 13,810 |  |  | — |  |  | 435 |  |  | 13,375 |  |
| Subtotal | 169,487 |  |  | 2,784 |  |  | (385) |  |  | 171,886 |  |  | 18,072 |  |  | 52,927 |  |  | 100,887 |  |
| Total (3) | $ | 189,431 |  |  | $ | 2,784 |  |  | $ | (385) |  |  | $ | 191,830 |  |  | $ | 38,016 |  |  | $ | 52,927 |  |  | $ | 100,887 |  |

[0000320193-21-000105:notes:57]
(1)Level 1 fair value estimates are based on quoted prices in active markets for identical assets or liabilities.

[0000320193-21-000105:notes:58]
(2)Level 2 fair value estimates are based on observable inputs other than quoted prices in active markets for identical assets and liabilities, quoted prices for identical or similar assets or liabilities in inactive markets, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities.

[0000320193-21-000105:notes:59]
(3)As of September 25, 2021 and September 26, 2020, total marketable securities included $17.9 billion and $18.6 billion, respectively, that was restricted from general use, related to the State Aid Decision (refer to Note 5, “Income Taxes”) and other agreements.

[0000320193-21-000105:notes:60]
The Company may sell certain of its marketable debt securities prior to their stated maturities for reasons including, but not limited to, managing liquidity, credit risk, duration and asset allocation. The following table shows the fair value of the Company’s non-current marketable debt securities, by contractual maturity, as of September 25, 2021 (in millions):

[0000320193-21-000105:notes:61]
| Due after 1 year through 5 years | $ | 83,755 |  |
| Due after 5 years through 10 years | 23,915 |  |
| Due after 10 years | 20,207 |  |
| Total fair value | $ | 127,877 |  |

[0000320193-21-000105:notes:62]
The Company typically invests in highly rated securities, with the primary objective of minimizing the potential risk of principal loss. The Company’s investment policy generally requires securities to be investment grade and limits the amount of credit exposure to any one issuer. Fair values were determined for each individual security in the investment portfolio.

[0000320193-21-000105:notes:63]
The Company may use derivative instruments to partially offset its business exposure to foreign exchange and interest rate risk. However, the Company may choose not to hedge certain exposures for a variety of reasons including, but not limited to, accounting considerations or the prohibitive economic cost of hedging particular exposures. There can be no assurance the hedges will offset more than a portion of the financial impact resulting from movements in foreign exchange or interest rates.

[0000320193-21-000105:notes:64]
Foreign Exchange Risk

[0000320193-21-000105:notes:65]
To protect gross margins from fluctuations in foreign currency exchange rates, the Company may enter into forward contracts, option contracts or other instruments, and may designate these instruments as cash flow hedges. The Company generally hedges portions of its forecasted foreign currency exposure associated with revenue and inventory purchases, typically for up to 12 months.

[0000320193-21-000105:notes:66]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in foreign currency exchange rates, the Company may enter into forward contracts, cross-currency swaps or other instruments. The Company designates these instruments as either cash flow or fair value hedges. As of September 25, 2021, the Company’s hedged term debt– and marketable securities–related foreign currency transactions are expected to be recognized within 21 years.

[0000320193-21-000105:notes:67]
The Company may also enter into derivative instruments that are not designated as accounting hedges to protect gross margins from certain fluctuations in foreign currency exchange rates, as well as to offset a portion of the foreign currency exchange gains and losses generated by the remeasurement of certain assets and liabilities denominated in non-functional currencies.

[0000320193-21-000105:notes:68]
Interest Rate Risk

[0000320193-21-000105:notes:69]
To protect the Company’s term debt or marketable securities from fluctuations in interest rates, the Company may enter into interest rate swaps, options or other instruments. The Company designates these instruments as either cash flow or fair value hedges.

[0000320193-21-000105:notes:70]
The notional amounts of the Company’s outstanding derivative instruments as of September 25, 2021 and September 26, 2020 were as follows (in millions):

[0000320193-21-000105:notes:71]
|  | 2021 |  | 2020 |
| Derivative instruments designated as accounting hedges: |  |  |  |
| Foreign exchange contracts | $ | 76,475 |  |  | $ | 57,410 |  |
| Interest rate contracts | $ | 16,875 |  |  | $ | 20,700 |  |
| Derivative instruments not designated as accounting hedges: |  |  |  |
| Foreign exchange contracts | $ | 126,918 |  |  | $ | 88,636 |  |

[0000320193-21-000105:notes:72]
The gross fair values of the Company’s derivative assets and liabilities were not material as of September 25, 2021 and September 26, 2020.

[0000320193-21-000105:notes:73]
The gains and losses recognized in OCI and amounts reclassified from AOCI to net income for the Company’s derivative instruments designated as cash flow hedges were not material in 2021, 2020 and 2019.

[0000320193-21-000105:notes:74]
The carrying amounts of the Company’s hedged items in fair value hedges as of September 25, 2021 and September 26, 2020 were as follows (in millions):

[0000320193-21-000105:notes:75]
|  | 2021 |  | 2020 |  |  |
| Hedged assets/(liabilities): |  |  |  |  |  |
| Current and non-current marketable securities | $ | 15,954 |  |  | $ | 16,270 |  |  |  |
| Current and non-current term debt | $ | (17,857) |  |  | $ | (21,033) |  |  |  |

[0000320193-21-000105:notes:76]
The gains and losses on the Company’s derivative instruments designated as fair value hedges and the related hedged item adjustments were not material in 2021, 2020 and 2019.

[0000320193-21-000105:notes:77]
Accounts Receivable

[0000320193-21-000105:notes:78]
Trade Receivables

[0000320193-21-000105:notes:79]
The Company has considerable trade receivables outstanding with its third-party cellular network carriers, wholesalers, retailers, resellers, small and mid-sized businesses and education, enterprise and government customers. The Company generally does not require collateral from its customers; however, the Company will require collateral or third-party credit support in certain instances to limit credit risk. In addition, when possible, the Company attempts to limit credit risk on trade receivables with credit insurance for certain customers or by requiring third-party financing, loans or leases to support credit exposure. These credit-financing arrangements are directly between the third-party financing company and the end customer. As such, the Company generally does not assume any recourse or credit risk sharing related to any of these arrangements.

[0000320193-21-000105:notes:80]
As of both September 25, 2021 and September 26, 2020, the Company had no customers that individually represented 10% or more of total trade receivables. The Company’s cellular network carriers accounted for 42% of total trade receivables as of September 25, 2021.

[0000320193-21-000105:notes:81]
Vendor Non-Trade Receivables

[0000320193-21-000105:notes:82]
The Company has non-trade receivables from certain of its manufacturing vendors resulting from the sale of components to these vendors who manufacture subassemblies or assemble final products for the Company. The Company purchases these components directly from suppliers. As of September 25, 2021, the Company had three vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 52%, 11% and 11%. As of September 26, 2020, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 57% and 11%.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000320193-21-000105:notes:83]
Consolidated Financial Statement Details
The following tables show the Company’s consolidated financial statement details as of September 25, 2021 and September 26, 2020 (in millions):

[0000320193-21-000105:notes:84]
Property, Plant and Equipment, Net

[0000320193-21-000105:notes:85]
|  | 2021 |  | 2020 |
| Land and buildings | $ | 20,041 |  |  | $ | 17,952 |  |
| Machinery, equipment and internal-use software | 78,659 |  |  | 75,291 |  |
| Leasehold improvements | 11,023 |  |  | 10,283 |  |
| Gross property, plant and equipment | 109,723 |  |  | 103,526 |  |
| Accumulated depreciation and amortization | (70,283) |  |  | (66,760) |  |
| Total property, plant and equipment, net | $ | 39,440 |  |  | $ | 36,766 |  |

[0000320193-21-000105:notes:86]
Other Non-Current Liabilities

[0000320193-21-000105:notes:87]
|  | 2021 |  | 2020 |
| Long-term taxes payable | $ | 24,689 |  |  | $ | 28,170 |  |
| Other non-current liabilities | 28,636 |  |  | 26,320 |  |
| Total other non-current liabilities | $ | 53,325 |  |  | $ | 54,490 |  |

[0000320193-21-000105:notes:88]
Other Income/(Expense), Net

[0000320193-21-000105:notes:89]
The following table shows the detail of OI&E for 2021, 2020 and 2019 (in millions):

[0000320193-21-000105:notes:90]
|  | 2021 |  | 2020 |  | 2019 |
| Interest and dividend income | $ | 2,843 |  |  | $ | 3,763 |  |  | $ | 4,961 |  |
| Interest expense | (2,645) |  |  | (2,873) |  |  | (3,576) |  |
| Other income/(expense), net | 60 |  |  | (87) |  |  | 422 |  |
| Total other income/(expense), net | $ | 258 |  |  | $ | 803 |  |  | $ | 1,807 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000320193-21-000105:notes:91]
Income Taxes
Provision for Income Taxes and Effective Tax Rate

[0000320193-21-000105:notes:92]
The provision for income taxes for 2021, 2020 and 2019, consisted of the following (in millions):

[0000320193-21-000105:notes:93]
|  | 2021 |  | 2020 |  | 2019 |
| Federal: |  |  |  |  |  |
| Current | $ | 8,257 |  |  | $ | 6,306 |  |  | $ | 6,384 |  |
| Deferred | (7,176) |  |  | (3,619) |  |  | (2,939) |  |
| Total | 1,081 |  |  | 2,687 |  |  | 3,445 |  |
| State: |  |  |  |  |  |
| Current | 1,620 |  |  | 455 |  |  | 475 |  |
| Deferred | (338) |  |  | 21 |  |  | (67) |  |
| Total | 1,282 |  |  | 476 |  |  | 408 |  |
| Foreign: |  |  |  |  |  |
| Current | 9,424 |  |  | 3,134 |  |  | 3,962 |  |
| Deferred | 2,740 |  |  | 3,383 |  |  | 2,666 |  |
| Total | 12,164 |  |  | 6,517 |  |  | 6,628 |  |
| Provision for income taxes | $ | 14,527 |  |  | $ | 9,680 |  |  | $ | 10,481 |  |

[0000320193-21-000105:notes:94]
The foreign provision for income taxes is based on foreign pretax earnings of $68.7 billion, $38.1 billion and $44.3 billion in 2021, 2020 and 2019, respectively.

[0000320193-21-000105:notes:95]
A reconciliation of the provision for income taxes, with the amount computed by applying the statutory federal income tax rate (21% in 2021, 2020 and 2019) to income before provision for income taxes for 2021, 2020 and 2019, is as follows (dollars in millions):

[0000320193-21-000105:notes:96]
|  | 2021 |  | 2020 |  | 2019 |
| Computed expected tax | $ | 22,933 |  |  | $ | 14,089 |  |  | $ | 13,805 |  |
| State taxes, net of federal effect | 1,151 |  |  | 423 |  |  | 423 |  |
| Impacts of the U.S. Tax Cuts and Jobs Act of 2017 | — |  |  | (582) |  |  | — |  |
| Earnings of foreign subsidiaries | (4,715) |  |  | (2,534) |  |  | (2,625) |  |
| Foreign-derived intangible income deduction | (1,372) |  |  | (169) |  |  | (149) |  |
| Research and development credit, net | (1,033) |  |  | (728) |  |  | (548) |  |
| Excess tax benefits from equity awards | (2,137) |  |  | (930) |  |  | (639) |  |
| Other | (300) |  |  | 111 |  |  | 214 |  |
| Provision for income taxes | $ | 14,527 |  |  | $ | 9,680 |  |  | $ | 10,481 |  |
| Effective tax rate | 13.3 | % |  | 14.4 | % |  | 15.9 | % |

[0000320193-21-000105:notes:97]
Deferred Tax Assets and Liabilities

[0000320193-21-000105:notes:98]
As of September 25, 2021 and September 26, 2020, the significant components of the Company’s deferred tax assets and liabilities were (in millions):

[0000320193-21-000105:notes:99]
|  | 2021 |  | 2020 |
| Deferred tax assets: |  |  |  |
| Amortization and depreciation | $ | 5,575 |  |  | $ | 8,317 |  |
| Accrued liabilities and other reserves | 5,895 |  |  | 4,934 |  |
| Lease liabilities | 2,406 |  |  | 2,038 |  |
| Deferred revenue | 5,399 |  |  | 1,638 |  |
| Tax credit carryforwards | 4,262 |  |  | 797 |  |
| Other | 1,639 |  |  | 1,612 |  |
| Total deferred tax assets | 25,176 |  |  | 19,336 |  |
| Less: Valuation allowance | (4,903) |  |  | (1,041) |  |
| Total deferred tax assets, net | 20,273 |  |  | 18,295 |  |
| Deferred tax liabilities: |  |  |  |
| Minimum tax on foreign earnings | 4,318 |  |  | 7,045 |  |
| Right-of-use assets | 2,167 |  |  | 1,862 |  |
| Unrealized gains | 203 |  |  | 526 |  |
| Other | 512 |  |  | 705 |  |
| Total deferred tax liabilities | 7,200 |  |  | 10,138 |  |
| Net deferred tax assets | $ | 13,073 |  |  | $ | 8,157 |  |

[0000320193-21-000105:notes:100]
Deferred tax assets and liabilities reflect the effects of tax credits and the future income tax effects of temporary differences between the consolidated financial statement carrying amounts of existing assets and liabilities and their respective tax bases, and are measured using enacted tax rates that apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. The Company has elected to record certain deferred tax assets and liabilities in connection with the minimum tax on certain foreign earnings created by the U.S. Tax Cuts and Jobs Act of 2017 (the “Act”).

[0000320193-21-000105:notes:101]
As of September 25, 2021, the Company had $2.6 billion in foreign tax credit carryforwards in Ireland and $1.6 billion in California research and development credit carryforwards, both of which can be carried forward indefinitely. A valuation allowance has been recorded for the tax credit carryforwards and a portion of other temporary differences.

[0000320193-21-000105:notes:102]
Uncertain Tax Positions

[0000320193-21-000105:notes:103]
As of September 25, 2021, the total amount of gross unrecognized tax benefits was $15.5 billion, of which $6.6 billion, if recognized, would impact the Company’s effective tax rate. As of September 26, 2020, the total amount of gross unrecognized tax benefits was $16.5 billion, of which $8.8 billion, if recognized, would have impacted the Company’s effective tax rate.

[0000320193-21-000105:notes:104]
The aggregate change in the balance of gross unrecognized tax benefits, which excludes interest and penalties, for 2021, 2020 and 2019, is as follows (in millions):

[0000320193-21-000105:notes:105]
|  | 2021 |  | 2020 |  | 2019 |
| Beginning balances | $ | 16,475 |  |  | $ | 15,619 |  |  | $ | 9,694 |  |
| Increases related to tax positions taken during a prior year | 816 |  |  | 454 |  |  | 5,845 |  |
| Decreases related to tax positions taken during a prior year | (1,402) |  |  | (791) |  |  | (686) |  |
| Increases related to tax positions taken during the current year | 1,607 |  |  | 1,347 |  |  | 1,697 |  |
| Decreases related to settlements with taxing authorities | (1,838) |  |  | (85) |  |  | (852) |  |
| Decreases related to expiration of the statute of limitations | (181) |  |  | (69) |  |  | (79) |  |
| Ending balances | $ | 15,477 |  |  | $ | 16,475 |  |  | $ | 15,619 |  |

[0000320193-21-000105:notes:106]
The Company is subject to taxation and files income tax returns in the U.S. federal jurisdiction and many state and foreign jurisdictions. Tax years after 2015 for the U.S. federal jurisdiction, and after 2014 in certain major foreign jurisdictions, remain subject to examination. Although the timing of resolution and/or closure of examinations is not certain, the Company believes it is reasonably possible that its gross unrecognized tax benefits could decrease in the next 12 months by as much as $1.2 billion.

[0000320193-21-000105:notes:107]
Interest and Penalties

[0000320193-21-000105:notes:108]
The Company includes interest and penalties related to income tax matters within the provision for income taxes. As of September 25, 2021 and September 26, 2020, the total amount of gross interest and penalties accrued was $1.5 billion and $1.4 billion, respectively. The Company recognized interest and penalty expense of $219 million, $85 million and $73 million in 2021, 2020 and 2019, respectively.

[0000320193-21-000105:notes:109]
European Commission State Aid Decision

[0000320193-21-000105:notes:110]
On August 30, 2016, the European Commission announced its decision that Ireland granted state aid to the Company by providing tax opinions in 1991 and 2007 concerning the tax allocation of profits of the Irish branches of two subsidiaries of the Company (the “State Aid Decision”). The State Aid Decision ordered Ireland to calculate and recover additional taxes from the Company for the period June 2003 through December 2014. Irish legislative changes, effective as of January 2015, eliminated the application of the tax opinions from that date forward. The recovery amount was calculated to be €13.1 billion, plus interest of €1.2 billion. The Company and Ireland appealed the State Aid Decision to the General Court of the Court of Justice of the European Union (the “General Court”). On July 15, 2020, the General Court annulled the State Aid Decision. On September 25, 2020, the European Commission appealed the General Court’s decision to the European Court of Justice. The Company believes that any incremental Irish corporate income taxes potentially due related to the State Aid Decision would be creditable against U.S. taxes, subject to any foreign tax credit limitations in the Act.

[0000320193-21-000105:notes:111]
On an annual basis, the Company may request approval from the Irish Minister for Finance to reduce the recovery amount for certain taxes paid to other countries. As of September 25, 2021, the adjusted recovery amount was €12.7 billion, excluding interest. The adjusted recovery amount plus interest is funded into escrow, where it will remain restricted from general use pending the conclusion of all legal proceedings. Refer to the Cash, Cash Equivalents and Marketable Securities section of Note 3, “Financial Instruments” for more information.


## us-gaap:IncomeTaxPolicyTextBlock

[0000320193-21-000105:notes:112]
The Company has elected to record certain deferred tax assets and liabilities in connection with the minimum tax on certain foreign earnings created by the U.S. Tax Cuts and Jobs Act of 2017 (the “Act”).The Company includes interest and penalties related to income tax matters within the provision for income taxes.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000320193-21-000105:notes:113]
Leases
The Company has lease arrangements for certain equipment and facilities, including retail, corporate, manufacturing and data center space. These leases typically have original terms not exceeding 10 years and generally contain multiyear renewal options, some of which are reasonably certain of exercise. The Company’s lease arrangements may contain both lease and nonlease components. The Company has elected to combine and account for lease and nonlease components as a single lease component for leases of retail, corporate, and data center facilities.

[0000320193-21-000105:notes:114]
Payments under the Company’s lease arrangements may be fixed or variable, and variable lease payments are primarily based on purchases of output of the underlying leased assets. Lease costs associated with fixed payments on the Company’s operating leases were $1.7 billion and $1.5 billion for 2021 and 2020, respectively. Lease costs associated with variable payments on the Company’s leases were $12.9 billion and $9.3 billion for 2021 and 2020, respectively. Rent expense for operating leases, as previously reported under former lease accounting standards, was $1.3 billion in 2019.

[0000320193-21-000105:notes:115]
The Company made $1.4 billion and $1.5 billion of fixed cash payments related to operating leases in 2021 and 2020, respectively. Noncash activities involving right-of-use (“ROU”) assets obtained in exchange for lease liabilities were $3.3 billion for 2021 and $10.5 billion for 2020, including the impact of adopting FASB ASU No. 2016-02, Leases (Topic 842) in the first quarter of 2020.

[0000320193-21-000105:notes:116]
The following table shows ROU assets and lease liabilities, and the associated financial statement line items, as of September 25, 2021 and September 26, 2020 (in millions):

[0000320193-21-000105:notes:117]
| Lease-Related Assets and Liabilities |  | Financial Statement Line Items |  | 2021 |  | 2020 |  |  |
| Right-of-use assets: |  |  |  |  |  |  |  |  |
| Operating leases |  | Other non-current assets |  | $ | 10,087 |  |  | $ | 8,570 |  |  |  |
| Finance leases |  | Property, plant and equipment, net |  | 861 |  |  | 629 |  |  |  |
| Total right-of-use assets |  |  |  | $ | 10,948 |  |  | $ | 9,199 |  |  |  |
| Lease liabilities: |  |  |  |  |  |  |  |  |
| Operating leases |  | Other current liabilities |  | $ | 1,449 |  |  | $ | 1,436 |  |  |  |
|  |  | Other non-current liabilities |  | 9,506 |  |  | 7,745 |  |  |  |
| Finance leases |  | Other current liabilities |  | 79 |  |  | 24 |  |  |  |
|  |  | Other non-current liabilities |  | 769 |  |  | 637 |  |  |  |
| Total lease liabilities |  |  |  | $ | 11,803 |  |  | $ | 9,842 |  |  |  |

[0000320193-21-000105:notes:118]
Lease liability maturities as of September 25, 2021, are as follows (in millions):

[0000320193-21-000105:notes:119]
|  | OperatingLeases |  | FinanceLeases |  | Total |
| 2022 | $ | 1,629 |  |  | $ | 104 |  |  | $ | 1,733 |  |
| 2023 | 1,560 |  |  | 123 |  |  | 1,683 |  |
| 2024 | 1,499 |  |  | 99 |  |  | 1,598 |  |
| 2025 | 1,251 |  |  | 46 |  |  | 1,297 |  |
| 2026 | 1,061 |  |  | 26 |  |  | 1,087 |  |
| Thereafter | 5,187 |  |  | 868 |  |  | 6,055 |  |
| Total undiscounted liabilities | 12,187 |  |  | 1,266 |  |  | 13,453 |  |
| Less: Imputed interest | (1,232) |  |  | (418) |  |  | (1,650) |  |
| Total lease liabilities | $ | 10,955 |  |  | $ | 848 |  |  | $ | 11,803 |  |

[0000320193-21-000105:notes:120]
The weighted-average remaining lease term related to the Company’s lease liabilities as of September 25, 2021 and September 26, 2020 was 10.8 years and 10.3 years, respectively.

[0000320193-21-000105:notes:121]
The discount rate related to the Company’s lease liabilities as of both September 25, 2021 and September 26, 2020 was 2.0%. The discount rates are generally based on estimates of the Company’s incremental borrowing rate, as the discount rates implicit in the Company’s leases cannot be readily determined.

[0000320193-21-000105:notes:122]
As of September 25, 2021, the Company had $1.1 billion of future payments under additional leases, primarily for corporate facilities and retail space, that had not yet commenced. These leases will commence between 2022 and 2023, with lease terms ranging from 3 years to 20 years.


## us-gaap:DebtDisclosureTextBlock

[0000320193-21-000105:notes:123]
Debt
Commercial Paper and Repurchase Agreements

[0000320193-21-000105:notes:124]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of September 25, 2021 and September 26, 2020, the Company had $6.0 billion and $5.0 billion of Commercial Paper outstanding, respectively, with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 0.06% and 0.62% as of September 25, 2021 and September 26, 2020, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for 2021, 2020 and 2019 (in millions):

[0000320193-21-000105:notes:125]
|  | 2021 |  | 2020 |  | 2019 |
| Maturities 90 days or less: |  |  |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | (357) |  |  | $ | 100 |  |  | $ | (3,248) |  |
| Maturities greater than 90 days: |  |  |  |  |  |
| Proceeds from commercial paper | 7,946 |  |  | 6,185 |  |  | 13,874 |  |
| Repayments of commercial paper | (6,567) |  |  | (7,248) |  |  | (16,603) |  |
| Proceeds from/(Repayments of) commercial paper, net | 1,379 |  |  | (1,063) |  |  | (2,729) |  |
| Total proceeds from/(repayments of) commercial paper, net | $ | 1,022 |  |  | $ | (963) |  |  | $ | (5,977) |  |

[0000320193-21-000105:notes:126]
In 2020, the Company entered into agreements to sell certain of its marketable securities with a promise to repurchase the securities at a specified time and amount (“Repos”). Due to the Company’s continuing involvement with the marketable securities, the Company accounted for its Repos as collateralized borrowings. The Company entered into $5.2 billion of Repos during 2020, all of which had been settled as of September 26, 2020.

[0000320193-21-000105:notes:127]
Term Debt

[0000320193-21-000105:notes:128]
As of September 25, 2021, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $118.1 billion (collectively the “Notes”). The Notes are senior unsecured obligations and interest is payable in arrears. The following table provides a summary of the Company’s term debt as of September 25, 2021 and September 26, 2020:

[0000320193-21-000105:notes:129]
|  | Maturities(calendar year) |  | 2021 |  | 2020 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 – 2020 debt issuances: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2022 |  | $ | 1,750 |  |  | 0.48% – 0.63% |  | $ | 2,250 |  |  | 0.60% – 1.39% |
| Fixed-rate 0.000% – 4.650% notes | 2022 – 2060 |  | 95,813 |  |  | 0.03% – 4.78% |  | 103,828 |  |  | 0.03% – 4.78% |
| Second quarter 2021 debt issuance: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.700% – 2.800% notes | 2026 – 2061 |  | 14,000 |  |  | 0.75% – 2.81% |  | — |  |  | — | % |
| Fourth quarter 2021 debt issuance: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 1.400% – 2.850% notes | 2028 – 2061 |  | 6,500 |  |  | 1.43% – 2.86% |  | — |  |  | — | % |
| Total term debt |  |  | 118,063 |  |  |  |  | 106,078 |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  | (380) |  |  |  |  | (314) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 1,036 |  |  |  |  | 1,676 |  |  |  |
| Less: Current portion of term debt |  |  | (9,613) |  |  |  |  | (8,773) |  |  |  |
| Total non-current portion of term debt |  |  | $ | 109,106 |  |  |  |  | $ | 98,667 |  |  |  |

[0000320193-21-000105:notes:130]
To manage interest rate risk on certain of its U.S. dollar–denominated fixed- or floating-rate notes, the Company has entered into interest rate swaps to effectively convert the fixed interest rates to floating interest rates or the floating interest rates to fixed interest rates on a portion of these notes. Additionally, to manage foreign currency risk on certain of its foreign currency–denominated notes, the Company has entered into foreign currency swaps to effectively convert these notes to U.S. dollar–denominated notes.

[0000320193-21-000105:notes:131]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $2.6 billion, $2.8 billion and $3.2 billion of interest expense on its term debt for 2021, 2020 and 2019, respectively.

[0000320193-21-000105:notes:132]
The future principal payments for the Company’s Notes as of September 25, 2021, are as follows (in millions):

[0000320193-21-000105:notes:133]
| 2022 | $ | 9,583 |  |
| 2023 | 11,391 |  |
| 2024 | 10,202 |  |
| 2025 | 10,914 |  |
| 2026 | 11,408 |  |
| Thereafter | 64,565 |  |
| Total term debt | $ | 118,063 |  |

[0000320193-21-000105:notes:134]
As of September 25, 2021 and September 26, 2020, the fair value of the Company’s Notes, based on Level 2 inputs, was $125.3 billion and $117.1 billion, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000320193-21-000105:notes:135]
Shareholders’ Equity
Share Repurchase Program

[0000320193-21-000105:notes:136]
As of September 25, 2021, the Company was authorized to purchase up to $315 billion of the Company’s common stock under a share repurchase program (the “Program”). During 2021, the Company repurchased 656 million shares of its common stock for $85.5 billion, including 36 million shares delivered under a $5.0 billion accelerated share repurchase agreement entered into in May 2021, bringing the total utilization under the Program to $254.1 billion as of September 25, 2021. The Program does not obligate the Company to acquire any specific number of shares. Under the Program, shares may be repurchased in privately negotiated and/or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).

[0000320193-21-000105:notes:137]
Shares of Common Stock

[0000320193-21-000105:notes:138]
The following table shows the changes in shares of common stock for 2021, 2020 and 2019 (in thousands):

[0000320193-21-000105:notes:139]
|  | 2021 |  | 2020 |  | 2019 |
| Common stock outstanding, beginning balances | 16,976,763 |  |  | 17,772,945 |  |  | 19,019,943 |  |
| Common stock repurchased | (656,340) |  |  | (917,270) |  |  | (1,380,819) |  |
| Common stock issued, net of shares withheld for employee taxes | 106,363 |  |  | 121,088 |  |  | 133,821 |  |
| Common stock outstanding, ending balances | 16,426,786 |  |  | 16,976,763 |  |  | 17,772,945 |  |


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000320193-21-000105:notes:140]
Benefit Plans
2014 Employee Stock Plan

[0000320193-21-000105:notes:141]
The 2014 Employee Stock Plan (the “2014 Plan”) is a shareholder-approved plan that provides for broad-based equity grants to employees, including executive officers, and permits the granting of restricted stock units (“RSUs”), stock grants, performance-based awards, stock options and stock appreciation rights, as well as cash bonus awards. RSUs granted under the 2014 Plan generally vest over four years, based on continued employment, and are settled upon vesting in shares of the Company’s common stock on a one-for-one basis. RSUs granted under the 2014 Plan reduce the number of shares available for grant under the plan by a factor of two times the number of RSUs granted. RSUs canceled and shares withheld to satisfy tax withholding obligations increase the number of shares available for grant under the 2014 Plan utilizing a factor of two times the number of RSUs canceled or shares withheld. All RSUs granted under the 2014 Plan have dividend equivalent rights (“DERs”), which entitle holders of RSUs to the same dividend value per share as holders of common stock. DERs are subject to the same vesting and other terms and conditions as the underlying RSUs. As of September 25, 2021, approximately 760 million shares were reserved for future issuance under the 2014 Plan. Shares subject to outstanding awards under the 2003 Employee Stock Plan that expire, are canceled or otherwise terminate, or are withheld to satisfy tax withholding obligations for RSUs, will also be available for awards under the 2014 Plan.

[0000320193-21-000105:notes:142]
Apple Inc. Non-Employee Director Stock Plan

[0000320193-21-000105:notes:143]
The Apple Inc. Non-Employee Director Stock Plan (the “Director Plan”) is a shareholder-approved plan that (i) permits the Company to grant awards of RSUs or stock options to the Company’s non-employee directors, (ii) provides for automatic initial grants of RSUs upon a non-employee director joining the Board of Directors and automatic annual grants of RSUs at each annual meeting of shareholders, and (iii) permits the Board of Directors to prospectively change the value and relative mixture of stock options and RSUs for the initial and annual award grants and the methodology for determining the number of shares of the Company’s common stock subject to these grants, in each case within the limits set forth in the Director Plan and without further shareholder approval. RSUs granted under the Director Plan reduce the number of shares available for grant under the plan by a factor of two times the number of RSUs granted. The Director Plan expires on November 12, 2027. All RSUs granted under the Director Plan are entitled to DERs, which are subject to the same vesting and other terms and conditions as the underlying RSUs. As of September 25, 2021, approximately 4 million shares were reserved for future issuance under the Director Plan.

[0000320193-21-000105:notes:144]
Rule 10b5-1 Trading Plans

[0000320193-21-000105:notes:145]
During the three months ended September 25, 2021, Section 16 officers Katherine L. Adams, Timothy D. Cook, Luca Maestri, Deirdre O’Brien and Jeffrey Williams had equity trading plans in place in accordance with Rule 10b5-1(c)(1) under the Exchange Act. An equity trading plan is a written document that preestablishes the amounts, prices and dates (or formula for determining the amounts, prices and dates) of future purchases or sales of the Company’s stock, including shares acquired under the Company’s employee and director equity plans.

[0000320193-21-000105:notes:146]
Employee Stock Purchase Plan

[0000320193-21-000105:notes:147]
The Employee Stock Purchase Plan (the “Purchase Plan”) is a shareholder-approved plan under which substantially all employees may voluntarily enroll to purchase the Company’s common stock through payroll deductions at a price equal to 85% of the lower of the fair market values of the stock as of the beginning or the end of six-month offering periods. An employee’s payroll deductions under the Purchase Plan are limited to 10% of the employee’s compensation and employees may not purchase more than $25,000 of stock during any calendar year. As of September 25, 2021, approximately 96 million shares were reserved for future issuance under the Purchase Plan.

[0000320193-21-000105:notes:148]
401(k) Plan

[0000320193-21-000105:notes:149]
The Company’s 401(k) Plan is a deferred salary arrangement under Section 401(k) of the Internal Revenue Code. Under the 401(k) Plan, participating U.S. employees may defer a portion of their pretax earnings, up to the U.S. Internal Revenue Service annual contribution limit ($19,500 for calendar year 2021). The Company matches 50% to 100% of each employee’s contributions, depending on length of service, up to a maximum of 6% of the employee’s eligible earnings.

[0000320193-21-000105:notes:150]
Restricted Stock Units

[0000320193-21-000105:notes:151]
A summary of the Company’s RSU activity and related information for 2021, 2020 and 2019, is as follows:

[0000320193-21-000105:notes:152]
|  | Number ofRSUs(in thousands) |  | Weighted-AverageGrant Date FairValue Per RSU |  | AggregateFair Value(in millions) |
| Balance as of September 29, 2018 | 368,618 |  |  | $ | 33.65 |  |  |  |
| RSUs granted | 147,409 |  |  | $ | 53.99 |  |  |  |
| RSUs vested | (168,350) |  |  | $ | 33.80 |  |  |  |
| RSUs canceled | (21,609) |  |  | $ | 40.71 |  |  |  |
| Balance as of September 28, 2019 | 326,068 |  |  | $ | 42.30 |  |  |  |
| RSUs granted | 156,800 |  |  | $ | 59.20 |  |  |  |
| RSUs vested | (157,743) |  |  | $ | 40.29 |  |  |  |
| RSUs canceled | (14,347) |  |  | $ | 48.07 |  |  |  |
| Balance as of September 26, 2020 | 310,778 |  |  | $ | 51.58 |  |  |  |
| RSUs granted | 89,363 |  |  | $ | 116.33 |  |  |  |
| RSUs vested | (145,766) |  |  | $ | 50.71 |  |  |  |
| RSUs canceled | (13,948) |  |  | $ | 68.95 |  |  |  |
| Balance as of September 25, 2021 | 240,427 |  |  | $ | 75.16 |  |  | $ | 35,324 |  |

[0000320193-21-000105:notes:153]
The fair value as of the respective vesting dates of RSUs was $19.0 billion, $10.8 billion and $8.6 billion for 2021, 2020 and 2019, respectively. The majority of RSUs that vested in 2021, 2020 and 2019 were net share settled such that the Company withheld shares with a value equivalent to the employees’ obligation for the applicable income and other employment taxes, and remitted the cash to the appropriate taxing authorities. The total shares withheld were approximately 53 million, 56 million and 59 million for 2021, 2020 and 2019, respectively, and were based on the value of the RSUs on their respective vesting dates as determined by the Company’s closing stock price. Total payments for the employees’ tax obligations to taxing authorities were $6.8 billion, $3.9 billion and $3.0 billion in 2021, 2020 and 2019, respectively.

[0000320193-21-000105:notes:154]
The following table shows share-based compensation expense and the related income tax benefit included in the Consolidated Statements of Operations for 2021, 2020 and 2019 (in millions):

[0000320193-21-000105:notes:155]
|  | 2021 |  | 2020 |  | 2019 |
| Share-based compensation expense | $ | 7,906 |  |  | $ | 6,829 |  |  | $ | 6,068 |  |
| Income tax benefit related to share-based compensation expense | $ | (4,056) |  |  | $ | (2,476) |  |  | $ | (1,967) |  |

[0000320193-21-000105:notes:156]
As of September 25, 2021, the total unrecognized compensation cost related to outstanding RSUs and stock options was $13.6 billion, which the Company expects to recognize over a weighted-average period of 2.5 years.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000320193-21-000105:notes:157]
Commitments and Contingencies
Accrued Warranty and Guarantees

[0000320193-21-000105:notes:158]
The following table shows changes in the Company’s accrued warranties and related costs for 2021, 2020 and 2019 (in millions):

[0000320193-21-000105:notes:159]
|  | 2021 |  | 2020 |  | 2019 |
| Beginning accrued warranty and related costs | $ | 3,354 |  |  | $ | 3,570 |  |  | $ | 3,692 |  |
| Cost of warranty claims | (2,674) |  |  | (2,956) |  |  | (3,857) |  |
| Accruals for product warranty | 2,684 |  |  | 2,740 |  |  | 3,735 |  |
| Ending accrued warranty and related costs | $ | 3,364 |  |  | $ | 3,354 |  |  | $ | 3,570 |  |

[0000320193-21-000105:notes:160]
The Company offers an iPhone Upgrade Program, which is available to customers who purchase a qualifying iPhone in the U.S., the U.K. and China mainland. The iPhone Upgrade Program provides customers the right to trade in that iPhone for a specified amount when purchasing a new iPhone, provided certain conditions are met. The Company accounts for the trade-in right as a guarantee liability and recognizes arrangement revenue net of the fair value of such right, with subsequent changes to the guarantee liability recognized within net sales.

[0000320193-21-000105:notes:161]
Concentrations in the Available Sources of Supply of Materials and Product

[0000320193-21-000105:notes:162]
Although most components essential to the Company’s business are generally available from multiple sources, certain components are currently obtained from single or limited sources. The Company also competes for various components with other participants in the markets for smartphones, personal computers, tablets, wearables and accessories. Therefore, many components used by the Company, including those that are available from multiple sources, are at times subject to industry-wide shortage and significant commodity pricing fluctuations.

[0000320193-21-000105:notes:163]
The Company uses some custom components that are not commonly used by its competitors, and new products introduced by the Company often utilize custom components available from only one source. When a component or product uses new technologies, initial capacity constraints may exist until the suppliers’ yields have matured or their manufacturing capacities have increased. The continued availability of these components at acceptable prices, or at all, may be affected if suppliers decide to concentrate on the production of common components instead of components customized to meet the Company’s requirements.

[0000320193-21-000105:notes:164]
The Company has entered into agreements for the supply of many components; however, there can be no guarantee that the Company will be able to extend or renew these agreements on similar terms, or at all.

[0000320193-21-000105:notes:165]
Substantially all of the Company’s hardware products are manufactured by outsourcing partners that are located primarily in Asia, with some Mac computers manufactured in the U.S. and Ireland.

[0000320193-21-000105:notes:166]
Unconditional Purchase Obligations

[0000320193-21-000105:notes:167]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of payments for content creation, Internet and telecommunications services and supplier arrangements. Future payments under noncancelable unconditional purchase obligations having a remaining term in excess of one year as of September 25, 2021, are as follows (in millions):

[0000320193-21-000105:notes:168]
| 2022 | $ | 4,551 |  |
| 2023 | 2,165 |  |
| 2024 | 984 |  |
| 2025 | 405 |  |
| 2026 | 51 |  |
| Thereafter | 28 |  |
| Total | $ | 8,184 |  |

[0000320193-21-000105:notes:169]
Contingencies

[0000320193-21-000105:notes:170]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully resolved. The outcome of litigation is inherently uncertain. When a loss related to a legal proceeding or claim is probable and reasonably estimable, the Company accrues its best estimate for the ultimate resolution of the matter. If one or more legal matters were resolved against the Company in a reporting period for amounts above management’s expectations, the Company’s financial condition and operating results for that reporting period could be materially adversely affected. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss greater than a recorded accrual, concerning loss contingencies for asserted legal and other claims, except for the following matters:

[0000320193-21-000105:notes:171]
VirnetX

[0000320193-21-000105:notes:172]
VirnetX, Inc. (“VirnetX”) filed a lawsuit against the Company alleging that certain of the Company’s products infringe on patents owned by VirnetX. On April 11, 2018, a jury returned a verdict against the Company in the U.S. District Court for the Eastern District of Texas (the “Eastern Texas District Court”). The Company appealed the verdict to the U.S. Court of Appeals for the Federal Circuit, which remanded the case back to the Eastern Texas District Court, where a retrial was held in October 2020. The jury returned a verdict against the Company and awarded damages of $503 million, which the Company has appealed. The Company has challenged the validity of the patents at issue in the retrial at the U.S. Patent and Trademark Office (the “PTO”), and the PTO has declared the patents invalid, subject to further appeal by VirnetX.

[0000320193-21-000105:notes:173]
iOS Performance Management Cases

[0000320193-21-000105:notes:174]
On April 5, 2018, several U.S. federal actions alleging violation of consumer protection laws, fraud, computer intrusion and other causes of action related to the Company’s performance management feature used in its iPhone operating systems, introduced to certain iPhones in iOS updates 10.2.1 and 11.2, were consolidated through a Multidistrict Litigation process into a single action in the U.S. District Court for the Northern District of California (the “Northern California District Court”). On February 28, 2020, the parties in the Multidistrict Litigation reached a settlement to resolve the U.S. federal and California state class actions. On March 18, 2021, the Northern California District Court granted final approval of the Multidistrict Litigation settlement, which will result in an aggregate payment of $310 million to settle all claims. The Company continues to believe that its iPhones were not defective, that the performance management feature introduced with iOS updates 10.2.1 and 11.2 was intended to, and did, improve customers’ user experience, and that the Company did not make any misleading statements or fail to disclose any material information.

[0000320193-21-000105:notes:175]
French Competition Authority

[0000320193-21-000105:notes:176]
On March 16, 2020, the French Competition Authority (“FCA”) announced its decision that aspects of the Company’s sales and distribution practices in France violate French competition law, and issued a fine of €1.1 billion. The Company strongly disagrees with the FCA’s decision, and has appealed.

[0000320193-21-000105:notes:177]
Optis

[0000320193-21-000105:notes:178]
Optis Wireless Technology, LLC and related entities (“Optis”) filed a lawsuit in the U.S. District Court for the Eastern District of Texas against the Company alleging that certain of the Company’s products infringe on patents owned by Optis. On August 11, 2020, a jury returned a verdict against the Company and awarded damages. In post-trial proceedings, the damages portion of the verdict was set aside. A retrial on damages was held in August 2021 and the jury in that proceeding awarded damages of $300 million against the Company, which the Company plans to appeal.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000320193-21-000105:notes:179]
Segment Information and Geographic Data
The Company reports segment information based on the “management” approach. The management approach designates the internal reporting used by management for making decisions and assessing performance as the source of the Company’s reportable segments.

[0000320193-21-000105:notes:180]
The Company manages its business primarily on a geographic basis. The Company’s reportable segments consist of the Americas, Europe, Greater China, Japan and Rest of Asia Pacific. Americas includes both North and South America. Europe includes European countries, as well as India, the Middle East and Africa. Greater China includes China mainland, Hong Kong and Taiwan. Rest of Asia Pacific includes Australia and those Asian countries not included in the Company’s other reportable segments. Although the reportable segments provide similar hardware and software products and similar services, each one is managed separately to better align with the location of the Company’s customers and distribution partners and the unique market dynamics of each geographic region. The accounting policies of the various segments are the same as those described in Note 1, “Summary of Significant Accounting Policies.”

[0000320193-21-000105:notes:181]
The Company evaluates the performance of its reportable segments based on net sales and operating income. Net sales for geographic segments are generally based on the location of customers and sales through the Company’s retail stores located in those geographic locations. Operating income for each segment includes net sales to third parties, related cost of sales and operating expenses directly attributable to the segment. Advertising expenses are generally included in the geographic segment in which the expenditures are incurred. Operating income for each segment excludes other income and expense and certain expenses managed outside the reportable segments. Costs excluded from segment operating income include various corporate expenses such as research and development, corporate marketing expenses, certain share-based compensation expenses, income taxes, various nonrecurring charges and other separately managed general and administrative costs. The Company does not include intercompany transfers between segments for management reporting purposes.

[0000320193-21-000105:notes:182]
The following table shows information by reportable segment for 2021, 2020 and 2019 (in millions):

[0000320193-21-000105:notes:183]
|  | 2021 |  | 2020 |  | 2019 |
| Americas: |  |  |  |  |  |
| Net sales | $ | 153,306 |  |  | $ | 124,556 |  |  | $ | 116,914 |  |
| Operating income | $ | 53,382 |  |  | $ | 37,722 |  |  | $ | 35,099 |  |
| Europe: |  |  |  |  |  |
| Net sales | $ | 89,307 |  |  | $ | 68,640 |  |  | $ | 60,288 |  |
| Operating income | $ | 32,505 |  |  | $ | 22,170 |  |  | $ | 19,195 |  |
| Greater China: |  |  |  |  |  |
| Net sales | $ | 68,366 |  |  | $ | 40,308 |  |  | $ | 43,678 |  |
| Operating income | $ | 28,504 |  |  | $ | 15,261 |  |  | $ | 16,232 |  |
| Japan: |  |  |  |  |  |
| Net sales | $ | 28,482 |  |  | $ | 21,418 |  |  | $ | 21,506 |  |
| Operating income | $ | 12,798 |  |  | $ | 9,279 |  |  | $ | 9,369 |  |
| Rest of Asia Pacific: |  |  |  |  |  |
| Net sales | $ | 26,356 |  |  | $ | 19,593 |  |  | $ | 17,788 |  |
| Operating income | $ | 9,817 |  |  | $ | 6,808 |  |  | $ | 6,055 |  |

[0000320193-21-000105:notes:184]
A reconciliation of the Company’s segment operating income to the Consolidated Statements of Operations for 2021, 2020 and 2019 is as follows (in millions):

[0000320193-21-000105:notes:185]
|  | 2021 |  | 2020 |  | 2019 |
| Segment operating income | $ | 137,006 |  |  | $ | 91,240 |  |  | $ | 85,950 |  |
| Research and development expense | (21,914) |  |  | (18,752) |  |  | (16,217) |  |
| Other corporate expenses, net | (6,143) |  |  | (6,200) |  |  | (5,803) |  |
| Total operating income | $ | 108,949 |  |  | $ | 66,288 |  |  | $ | 63,930 |  |

[0000320193-21-000105:notes:186]
The U.S. and China were the only countries that accounted for more than 10% of the Company’s net sales in 2021, 2020 and 2019. There was no single customer that accounted for more than 10% of net sales in 2021, 2020 and 2019. Net sales for 2021, 2020 and 2019 and long-lived assets as of September 25, 2021 and September 26, 2020 were as follows (in millions):

[0000320193-21-000105:notes:187]
|  | 2021 |  | 2020 |  | 2019 |
| Net sales: |  |  |  |  |  |
| U.S. | $ | 133,803 |  |  | $ | 109,197 |  |  | $ | 102,266 |  |
| China (1) | 68,366 |  |  | 40,308 |  |  | 43,678 |  |
| Other countries | 163,648 |  |  | 125,010 |  |  | 114,230 |  |
| Total net sales | $ | 365,817 |  |  | $ | 274,515 |  |  | $ | 260,174 |  |

[0000320193-21-000105:notes:188]
|  | 2021 |  | 2020 |
| Long-lived assets: |  |  |  |
| U.S. | $ | 28,203 |  |  | $ | 25,890 |  |
| China (1) | 7,521 |  |  | 7,256 |  |
| Other countries | 3,716 |  |  | 3,620 |  |
| Total long-lived assets | $ | 39,440 |  |  | $ | 36,766 |  |

[0000320193-21-000105:notes:189]
(1)China includes Hong Kong and Taiwan. Long-lived assets located in China consist primarily of product tooling and manufacturing process equipment and assets related to retail stores and related infrastructure.
