# AAPL 10-K controls and the auditor's report


## auditors_report

[0000320193-21-000105:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0000320193-21-000105:auditors_report:2]
To the Shareholders and the Board of Directors of Apple Inc.

[0000320193-21-000105:auditors_report:3]
Opinion on the Financial Statements

[0000320193-21-000105:auditors_report:4]
We have audited the accompanying consolidated balance sheets of Apple Inc. as of September 25, 2021 and September 26, 2020, the related consolidated statements of operations, comprehensive income, shareholders’ equity and cash flows for each of the three years in the period ended September 25, 2021, and the related notes (collectively referred to as the “financial statements”). In our opinion, the financial statements present fairly, in all material respects, the financial position of Apple Inc. at September 25, 2021 and September 26, 2020, and the results of its operations and its cash flows for each of the three years in the period ended September 25, 2021, in conformity with U.S. generally accepted accounting principles.

[0000320193-21-000105:auditors_report:5]
We also have audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (the “PCAOB”), Apple Inc.’s internal control over financial reporting as of September 25, 2021, based on criteria established in Internal Control – Integrated Framework issued by the Committee of Sponsoring Organizations of the Treadway Commission (2013 framework) and our report dated October 28, 2021 expressed an unqualified opinion thereon.

[0000320193-21-000105:auditors_report:6]
Basis for Opinion

[0000320193-21-000105:auditors_report:7]
These financial statements are the responsibility of Apple Inc.’s management. Our responsibility is to express an opinion on Apple Inc.’s financial statements based on our audits. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to Apple Inc. in accordance with the U.S. federal securities laws and the applicable rules and regulations of the U.S. Securities and Exchange Commission and the PCAOB.

[0000320193-21-000105:auditors_report:8]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the financial statements are free of material misstatement, whether due to error or fraud. Our audits included performing procedures to assess the risks of material misstatement of the financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the financial statements. We believe that our audits provide a reasonable basis for our opinion.

[0000320193-21-000105:auditors_report:9]
Critical Audit Matter

[0000320193-21-000105:auditors_report:10]
The critical audit matter communicated below is a matter arising from the current period audit of the financial statements that was communicated or required to be communicated to the audit committee and that: (1) relates to accounts or disclosures that are material to the financial statements and (2) involved our especially challenging, subjective, or complex judgments. The communication of the critical audit matter does not alter in any way our opinion on the financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing a separate opinion on the critical audit matter or on the account or disclosure to which it relates.

[0000320193-21-000105:auditors_report:11]
|  | Uncertain Tax Positions |
| Description of the Matter | As discussed in Note 5 to the financial statements, Apple Inc. is subject to taxation and files income tax returns in the U.S. federal jurisdiction and many state and foreign jurisdictions. As of September 25, 2021, the total amount of gross unrecognized tax benefits was $15.5 billion, of which $6.6 billion, if recognized, would impact Apple Inc.’s effective tax rate. Apple Inc. uses significant judgment in the calculation of tax liabilities in estimating the impact of uncertainties in the application of technical merits and complex tax laws.Auditing management’s evaluation of whether an uncertain tax position is more likely than not to be sustained and the measurement of the benefit of various tax positions can be complex, involves significant judgment, and is based on interpretations of tax laws and legal rulings. |

[0000320193-21-000105:auditors_report:12]
| How We Addressed theMatter in Our Audit | We tested controls relating to the evaluation of uncertain tax positions, including controls over management’s assessment as to whether tax positions are more likely than not to be sustained, management’s process to measure the benefit of its tax positions, and the development of the related disclosures.To evaluate Apple Inc.’s assessment of which tax positions are more likely than not to be sustained, our audit procedures included, among others, reading and evaluating management’s assumptions and analysis, and, as applicable, Apple Inc.’s communications with taxing authorities, that detailed the basis and technical merits of the uncertain tax positions. We involved our tax subject matter resources in assessing the technical merits of certain of Apple Inc.’s tax positions based on our knowledge of relevant tax laws and experience with related taxing authorities. For certain tax positions, we also received external legal counsel confirmation letters and discussed the matters with external advisors and Apple Inc. tax personnel. In addition, we evaluated Apple Inc.’s disclosure in relation to these matters included in Note 5 to the financial statements. |

[0000320193-21-000105:auditors_report:13]
/s/ Ernst & Young LLP

[0000320193-21-000105:auditors_report:14]
We have served as Apple Inc.’s auditor since 2009.

[0000320193-21-000105:auditors_report:15]
San Jose, California

[0000320193-21-000105:auditors_report:16]
October 28, 2021

[0000320193-21-000105:auditors_report:17]
Report of Independent Registered Public Accounting Firm

[0000320193-21-000105:auditors_report:18]
To the Shareholders and the Board of Directors of Apple Inc.

[0000320193-21-000105:auditors_report:19]
Opinion on Internal Control Over Financial Reporting

[0000320193-21-000105:auditors_report:20]
We have audited Apple Inc.’s internal control over financial reporting as of September 25, 2021, based on criteria established in Internal Control – Integrated Framework issued by the Committee of Sponsoring Organizations of the Treadway Commission (2013 framework) (the “COSO criteria”). In our opinion, Apple Inc. maintained, in all material respects, effective internal control over financial reporting as of September 25, 2021, based on the COSO criteria.

[0000320193-21-000105:auditors_report:21]
We also have audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (the “PCAOB”), the consolidated balance sheets of Apple Inc. as of September 25, 2021 and September 26, 2020, the related consolidated statements of operations, comprehensive income, shareholders’ equity and cash flows for each of the three years in the period ended September 25, 2021, and the related notes and our report dated October 28, 2021 expressed an unqualified opinion thereon.

[0000320193-21-000105:auditors_report:22]
Basis for Opinion

[0000320193-21-000105:auditors_report:23]
Apple Inc.’s management is responsible for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting included in the accompanying Management’s Annual Report on Internal Control over Financial Reporting. Our responsibility is to express an opinion on Apple Inc.’s internal control over financial reporting based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to Apple Inc. in accordance with the U.S. federal securities laws and the applicable rules and regulations of the U.S. Securities and Exchange Commission and the PCAOB.

[0000320193-21-000105:auditors_report:24]
We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects.

[0000320193-21-000105:auditors_report:25]
Our audit included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, testing and evaluating the design and operating effectiveness of internal control based on the assessed risk, and performing such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.

[0000320193-21-000105:auditors_report:26]
Definition and Limitations of Internal Control Over Financial Reporting

[0000320193-21-000105:auditors_report:27]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with U.S. generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with U.S. generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0000320193-21-000105:auditors_report:28]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0000320193-21-000105:auditors_report:29]
/s/ Ernst & Young LLP

[0000320193-21-000105:auditors_report:30]
San Jose, California

[0000320193-21-000105:auditors_report:31]
October 28, 2021


## item_9a

[0000320193-21-000105:item_9a:1]
Item 9A.    Controls and Procedures

[0000320193-21-000105:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0000320193-21-000105:item_9a:3]
Based on an evaluation under the supervision and with the participation of the Company’s management, the Company’s principal executive officer and principal financial officer have concluded that the Company’s disclosure controls and procedures as defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act were effective as of September 25, 2021 to provide reasonable assurance that information required to be disclosed by the Company in reports that it files or submits under the Exchange Act is (i) recorded, processed, summarized and reported within the time periods specified in the SEC rules and forms and (ii) accumulated and communicated to the Company’s management, including its principal executive officer and principal financial officer, as appropriate to allow timely decisions regarding required disclosure.

[0000320193-21-000105:item_9a:4]
Inherent Limitations over Internal Controls

[0000320193-21-000105:item_9a:5]
The Company’s internal control over financial reporting is designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with U.S. generally accepted accounting principles (“GAAP”). The Company’s internal control over financial reporting includes those policies and procedures that:

[0000320193-21-000105:item_9a:6]
(i)pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the Company’s assets;

[0000320193-21-000105:item_9a:7]
(ii)provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with GAAP, and that the Company’s receipts and expenditures are being made only in accordance with authorizations of the Company’s management and directors; and

[0000320193-21-000105:item_9a:8]
(iii)provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the Company’s assets that could have a material effect on the financial statements.

[0000320193-21-000105:item_9a:9]
Management, including the Company’s Chief Executive Officer and Chief Financial Officer, does not expect that the Company’s internal controls will prevent or detect all errors and all fraud. A control system, no matter how well designed and operated, can provide only reasonable, not absolute, assurance that the objectives of the control system are met. Further, the design of a control system must reflect the fact that there are resource constraints, and the benefits of controls must be considered relative to their costs. Because of the inherent limitations in all control systems, no evaluation of internal controls can provide absolute assurance that all control issues and instances of fraud, if any, have been detected. Also, any evaluation of the effectiveness of controls in future periods are subject to the risk that those internal controls may become inadequate because of changes in business conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0000320193-21-000105:item_9a:10]
Management’s Annual Report on Internal Control over Financial Reporting

[0000320193-21-000105:item_9a:11]
The Company’s management is responsible for establishing and maintaining adequate internal control over financial reporting (as defined in Rule 13a-15(f) under the Exchange Act). Management conducted an assessment of the effectiveness of the Company’s internal control over financial reporting based on the criteria set forth in Internal Control – Integrated Framework issued by the Committee of Sponsoring Organizations of the Treadway Commission (2013 framework). Based on the Company’s assessment, management has concluded that its internal control over financial reporting was effective as of September 25, 2021 to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements in accordance with GAAP. The Company’s independent registered public accounting firm, Ernst & Young LLP, has issued an audit report on the Company’s internal control over financial reporting, which appears in Part II, Item 8 of this Form 10-K.

[0000320193-21-000105:item_9a:12]
Changes in Internal Control over Financial Reporting

[0000320193-21-000105:item_9a:13]
There were no changes in the Company’s internal control over financial reporting during the fourth quarter of 2021, which were identified in connection with management’s evaluation required by paragraph (d) of Rules 13a-15 and 15d-15 under the Exchange Act, that have materially affected, or are reasonably likely to materially affect, the Company’s internal control over financial reporting.

[0000320193-21-000105:item_9a:14]
Apple Inc. | 2021 Form 10-K | 55
