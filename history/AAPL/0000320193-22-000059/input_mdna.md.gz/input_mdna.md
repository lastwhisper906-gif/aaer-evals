# AAPL MD&A — 0000320193-22-000059


## mdna

[0000320193-22-000059:mdna:1]
[same as prior period, unchanged from 0000320193-22-000007:mdna:1]

[0000320193-22-000059:mdna:2]
[same as prior period, unchanged from 0000320193-22-000007:mdna:2]

[0000320193-22-000059:mdna:3]
[same as prior period, unchanged from 0000320193-22-000007:mdna:3]

[0000320193-22-000059:mdna:4]
[same as prior period, unchanged from 0000320193-22-000007:mdna:4]

[0000320193-22-000059:mdna:5]
[same as prior period, unchanged from 0000320193-22-000007:mdna:5]

[0000320193-22-000059:mdna:6]
[same as prior period, unchanged from 0000320193-22-000007:mdna:7]

[0000320193-22-000059:mdna:7]
[same as prior period, unchanged from 0000320193-22-000007:mdna:8]

[0000320193-22-000059:mdna:8]
[same as prior period, unchanged from 0000320193-22-000007:mdna:6]

[0000320193-22-000059:mdna:9]
Total net sales increased 9% or $7.7 billion during the second quarter of 2022 compared to the same quarter in 2021, driven primarily by growth in Services, iPhone and Mac.

[0000320193-22-000059:mdna:10]
During the second quarter of 2022, the Company released the following products:

[0000320193-22-000059:mdna:11]
•iPhone SE® with 5G technology;

[0000320193-22-000059:mdna:12]
•iPad Air®, powered by the Apple M1 chip;

[0000320193-22-000059:mdna:13]
•All-new Mac Studio™, powered by the Apple M1 Max or the new Apple M1 Ultra chip; and

[0000320193-22-000059:mdna:14]
•All-new Apple Studio Display™.

[0000320193-22-000059:mdna:15]
The Company repurchased $22.9 billion of its common stock and paid dividends and dividend equivalents of $3.6 billion during the second quarter of 2022.

[0000320193-22-000059:mdna:16]
[same as prior period, unchanged from 0000320193-22-000007:mdna:9]

[0000320193-22-000059:mdna:17]
[same as prior period, unchanged from 0000320193-22-000007:mdna:10]

[0000320193-22-000059:mdna:18]
During the second quarter of 2022, aspects of the Company’s business continued to be affected by the COVID-19 pandemic, with a significant number of the Company’s employees working remotely and many of the Company’s retail stores operating at limited capacity or temporarily closing at various times. Substantially all of the Company’s other facilities are open, subject to operating restrictions to protect public health and the health and safety of employees. The Company continues to work on safely reopening the remainder of its facilities, subject to local rules and regulations.

[0000320193-22-000059:mdna:19]
At times, certain of the Company’s outsourcing partners, component suppliers and logistical service providers have experienced disruptions, resulting in supply shortages that could affect sales worldwide. Similar disruptions could occur in the future.

[0000320193-22-000059:mdna:20]
[same as prior period, unchanged from 0000320193-22-000007:mdna:12]

[0000320193-22-000059:mdna:21]
[same as prior period, unchanged from 0000320193-22-000007:mdna:20]

[0000320193-22-000059:mdna:22]
The following table shows net sales by category for the three- and six-month periods ended March 26, 2022 and March 27, 2021 (dollars in millions):

[0000320193-22-000059:mdna:23]
|  | Three Months Ended |  | Six Months Ended |
|  | March 26,2022 |  | March 27,2021 |  | Change |  | March 26,2022 |  | March 27,2021 |  | Change |
| Net sales by category: |  |  |  |  |  |  |  |  |  |  |  |
| iPhone (1) | $ | 50,570 |  |  | $ | 47,938 |  |  | 5 | % |  | $ | 122,198 |  |  | $ | 113,535 |  |  | 8 | % |
| Mac (1) | 10,435 |  |  | 9,102 |  |  | 15 | % |  | 21,287 |  |  | 17,777 |  |  | 20 | % |
| iPad (1) | 7,646 |  |  | 7,807 |  |  | (2) | % |  | 14,894 |  |  | 16,242 |  |  | (8) | % |
| Wearables, Home and Accessories (1)(2) | 8,806 |  |  | 7,836 |  |  | 12 | % |  | 23,507 |  |  | 20,807 |  |  | 13 | % |
| Services (3) | 19,821 |  |  | 16,901 |  |  | 17 | % |  | 39,337 |  |  | 32,662 |  |  | 20 | % |
| Total net sales | $ | 97,278 |  |  | $ | 89,584 |  |  | 9 | % |  | $ | 221,223 |  |  | $ | 201,023 |  |  | 10 | % |

[0000320193-22-000059:mdna:24]
[same as prior period, unchanged from 0000320193-22-000007:mdna:23]

[0000320193-22-000059:mdna:25]
[same as prior period, unchanged from 0000320193-22-000007:mdna:24]

[0000320193-22-000059:mdna:26]
[same as prior period, unchanged from 0000320193-22-000007:mdna:25]

[0000320193-22-000059:mdna:27]
[same as prior period, unchanged from 0000320193-22-000007:mdna:26]

[0000320193-22-000059:mdna:28]
iPhone net sales increased during the second quarter and first six months of 2022 compared to the same periods in 2021 due primarily to higher net sales from the Company’s new iPhone models.

[0000320193-22-000059:mdna:29]
[same as prior period, unchanged from 0000320193-22-000007:mdna:28]

[0000320193-22-000059:mdna:30]
Mac net sales increased during the second quarter and first six months of 2022 compared to the same periods in 2021 due primarily to higher net sales of MacBook Pro®, partially offset by lower net sales of MacBook Air®.

[0000320193-22-000059:mdna:31]
[same as prior period, unchanged from 0000320193-22-000007:mdna:30]

[0000320193-22-000059:mdna:32]
iPad net sales decreased during the second quarter of 2022 compared to the second quarter of 2021 due primarily to lower net sales of the 10-inch version of iPad, offset by higher net sales of iPad Pro® and iPad mini®. Year-over-year iPad net sales decreased during the first six months of 2022 due primarily to lower net sales of the 10-inch version of iPad, partially offset by higher net sales of iPad mini.

[0000320193-22-000059:mdna:33]
[same as prior period, unchanged from 0000320193-22-000007:mdna:32]

[0000320193-22-000059:mdna:34]
Wearables, Home and Accessories net sales increased during the second quarter and first six months of 2022 compared to the same periods in 2021 due primarily to higher net sales of Apple Watch, AirPods and accessories.

[0000320193-22-000059:mdna:35]
[same as prior period, unchanged from 0000320193-22-000007:mdna:34]

[0000320193-22-000059:mdna:36]
Services net sales increased during the second quarter and first six months of 2022 compared to the same periods in 2021 due primarily to higher net sales from advertising, the App Store® and cloud services.

[0000320193-22-000059:mdna:37]
[same as prior period, unchanged from 0000320193-22-000007:mdna:36]

[0000320193-22-000059:mdna:38]
[same as prior period, unchanged from 0000320193-22-000007:mdna:37]

[0000320193-22-000059:mdna:39]
The following table shows net sales by reportable segment for the three- and six-month periods ended March 26, 2022 and March 27, 2021 (dollars in millions):

[0000320193-22-000059:mdna:40]
|  | Three Months Ended |  | Six Months Ended |
|  | March 26,2022 |  | March 27,2021 |  | Change |  | March 26,2022 |  | March 27,2021 |  | Change |
| Net sales by reportable segment: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 40,882 |  |  | $ | 34,306 |  |  | 19 | % |  | $ | 92,378 |  |  | $ | 80,616 |  |  | 15 | % |
| Europe | 23,287 |  |  | 22,264 |  |  | 5 | % |  | 53,036 |  |  | 49,570 |  |  | 7 | % |
| Greater China | 18,343 |  |  | 17,728 |  |  | 3 | % |  | 44,126 |  |  | 39,041 |  |  | 13 | % |
| Japan | 7,724 |  |  | 7,742 |  |  | — | % |  | 14,831 |  |  | 16,027 |  |  | (7) | % |
| Rest of Asia Pacific | 7,042 |  |  | 7,544 |  |  | (7) | % |  | 16,852 |  |  | 15,769 |  |  | 7 | % |
| Total net sales | $ | 97,278 |  |  | $ | 89,584 |  |  | 9 | % |  | $ | 221,223 |  |  | $ | 201,023 |  |  | 10 | % |

[0000320193-22-000059:mdna:41]
[same as prior period, unchanged from 0000320193-22-000007:mdna:40]

[0000320193-22-000059:mdna:42]
Americas net sales increased during the second quarter of 2022 compared to the second quarter of 2021 due primarily to higher net sales of iPhone, Services and Mac. Year-over-year Americas net sales increased during the first six months of 2022 due primarily to higher net sales of iPhone, Services and Wearables, Home and Accessories.

[0000320193-22-000059:mdna:43]
[same as prior period, unchanged from 0000320193-22-000007:mdna:42]

[0000320193-22-000059:mdna:44]
Europe net sales increased during the second quarter and first six months of 2022 compared to the same periods in 2021 due primarily to higher net sales of Services and Mac. The movement of foreign currencies in Europe relative to the U.S. dollar had a net unfavorable impact on Europe net sales during the second quarter and first six months of 2022.

[0000320193-22-000059:mdna:45]
[same as prior period, unchanged from 0000320193-22-000007:mdna:44]

[0000320193-22-000059:mdna:46]
Greater China net sales increased during the second quarter and first six months of 2022 compared to the same periods in 2021 due primarily to higher net sales of iPhone and Services. The strength of the Chinese renminbi relative to the U.S. dollar had a favorable impact on Greater China net sales during the second quarter and first six months of 2022.

[0000320193-22-000059:mdna:47]
[same as prior period, unchanged from 0000320193-22-000007:mdna:46]

[0000320193-22-000059:mdna:48]
Japan net sales were flat during the second quarter of 2022 compared to the second quarter of 2021 due primarily to the weakness of the Japanese yen relative to the U.S. dollar, offset by higher net sales of iPhone and Services. Year-over-year Japan net sales decreased during the first six months of 2022 due primarily to the weakness of the Japanese yen relative to the U.S. dollar.

[0000320193-22-000059:mdna:49]
[same as prior period, unchanged from 0000320193-22-000007:mdna:48]

[0000320193-22-000059:mdna:50]
Rest of Asia Pacific net sales decreased during the second quarter of 2022 compared to the second quarter of 2021 due primarily to lower net sales of iPhone, partially offset by higher net sales of Services and Mac. Year-over-year Rest of Asia Pacific net sales increased during the first six months of 2022 due primarily to higher net sales of Services, Mac and Wearables, Home and Accessories. The movement of foreign currencies in Rest of Asia Pacific relative to the U.S. dollar had a net unfavorable impact on Rest of Asia Pacific net sales during the second quarter and first six months of 2022.

[0000320193-22-000059:mdna:51]
[same as prior period, unchanged from 0000320193-22-000007:mdna:50]

[0000320193-22-000059:mdna:52]
Products and Services gross margin and gross margin percentage for the three- and six-month periods ended March 26, 2022 and March 27, 2021 were as follows (dollars in millions):

[0000320193-22-000059:mdna:53]
|  | Three Months Ended |  | Six Months Ended |
|  | March 26,2022 |  | March 27,2021 |  | March 26,2022 |  | March 27,2021 |
| Gross margin: |  |  |  |  |  |  |  |
| Products | $ | 28,167 |  |  | $ | 26,236 |  |  | $ | 68,287 |  |  | $ | 59,784 |  |
| Services | 14,392 |  |  | 11,843 |  |  | 28,515 |  |  | 22,623 |  |
| Total gross margin | $ | 42,559 |  |  | $ | 38,079 |  |  | $ | 96,802 |  |  | $ | 82,407 |  |

[0000320193-22-000059:mdna:54]
| Gross margin percentage: |  |  |  |  |  |  |  |
| Products | 36.4 | % |  | 36.1 | % |  | 37.5 | % |  | 35.5 | % |
| Services | 72.6 | % |  | 70.1 | % |  | 72.5 | % |  | 69.3 | % |
| Total gross margin percentage | 43.7 | % |  | 42.5 | % |  | 43.8 | % |  | 41.0 | % |

[0000320193-22-000059:mdna:55]
[same as prior period, unchanged from 0000320193-22-000007:mdna:54]

[0000320193-22-000059:mdna:56]
Products gross margin increased during the second quarter of 2022 compared to the second quarter of 2021 due primarily to higher Products volume. Year-over-year Products gross margin increased during the first six months of 2022 due primarily to a different Products mix and higher Products volume.

[0000320193-22-000059:mdna:57]
Products gross margin percentage increased during the second quarter of 2022 compared to the second quarter of 2021 due primarily to improved leverage. Year-over-year Products gross margin percentage increased during the first six months of 2022 due primarily to a different Products mix.

[0000320193-22-000059:mdna:58]
[same as prior period, unchanged from 0000320193-22-000007:mdna:56]

[0000320193-22-000059:mdna:59]
Services gross margin increased during the second quarter and first six months of 2022 compared to the same periods in 2021 due primarily to higher Services net sales and a different Services mix, partially offset by the weakness in foreign currencies relative to the U.S. dollar.

[0000320193-22-000059:mdna:60]
Services gross margin percentage increased during the second quarter and first six months of 2022 compared to the same periods in 2021 due primarily to a different Services mix and improved leverage, partially offset by the weakness in foreign currencies relative to the U.S. dollar.

[0000320193-22-000059:mdna:61]
[same as prior period, unchanged from 0000320193-22-000007:mdna:58]

[0000320193-22-000059:mdna:62]
[same as prior period, unchanged from 0000320193-22-000007:mdna:59]

[0000320193-22-000059:mdna:63]
Operating expenses for the three- and six-month periods ended March 26, 2022 and March 27, 2021 were as follows (dollars in millions):

[0000320193-22-000059:mdna:64]
|  | Three Months Ended |  | Six Months Ended |
|  | March 26,2022 |  | March 27,2021 |  | March 26,2022 |  | March 27,2021 |
| Research and development | $ | 6,387 |  |  | $ | 5,262 |  |  | $ | 12,693 |  |  | $ | 10,425 |  |
| Percentage of total net sales | 7 | % |  | 6 | % |  | 6 | % |  | 5 | % |
| Selling, general and administrative | $ | 6,193 |  |  | $ | 5,314 |  |  | $ | 12,642 |  |  | $ | 10,945 |  |
| Percentage of total net sales | 6 | % |  | 6 | % |  | 6 | % |  | 5 | % |
| Total operating expenses | $ | 12,580 |  |  | $ | 10,576 |  |  | $ | 25,335 |  |  | $ | 21,370 |  |
| Percentage of total net sales | 13 | % |  | 12 | % |  | 11 | % |  | 11 | % |

[0000320193-22-000059:mdna:65]
[same as prior period, unchanged from 0000320193-22-000007:mdna:62]

[0000320193-22-000059:mdna:66]
The growth in research and development (“R&D”) expense during the second quarter and first six months of 2022 compared to the same periods in 2021 was driven primarily by increases in headcount-related expenses, engineering program costs and professional services. The Company continues to believe that focused investments in R&D are critical to its future growth and competitive position in the marketplace, and to the development of new and updated products and services that are central to the Company’s core business strategy.

[0000320193-22-000059:mdna:67]
[same as prior period, unchanged from 0000320193-22-000007:mdna:64]

[0000320193-22-000059:mdna:68]
The growth in selling, general and administrative expense during the second quarter of 2022 compared to the second quarter of 2021 was driven primarily by increases in advertising, headcount-related expenses and professional services. Year-over-year selling, general and administrative expense increased during the first six months of 2022 due primarily to increases in headcount-related expenses, advertising and variable selling expenses.

[0000320193-22-000059:mdna:69]
[same as prior period, unchanged from 0000320193-22-000007:mdna:66]

[0000320193-22-000059:mdna:70]
Other income/(expense), net (“OI&E”) for the three- and six-month periods ended March 26, 2022 and March 27, 2021 was as follows (dollars in millions):

[0000320193-22-000059:mdna:71]
|  | Three Months Ended |  | Six Months Ended |
|  | March 26,2022 |  | March 27,2021 |  | Change |  | March 26,2022 |  | March 27,2021 |  | Change |
| Interest and dividend income | $ | 700 |  |  | $ | 718 |  |  |  |  | $ | 1,350 |  |  | $ | 1,465 |  |  |  |
| Interest expense | (691) |  |  | (670) |  |  |  |  | (1,385) |  |  | (1,308) |  |  |  |
| Other income/(expense), net | 151 |  |  | 460 |  |  |  |  | (52) |  |  | 396 |  |  |  |
| Total other income/(expense), net | $ | 160 |  |  | $ | 508 |  |  | (69) | % |  | $ | (87) |  |  | $ | 553 |  |  | (116) | % |

[0000320193-22-000059:mdna:72]
OI&E decreased during the second quarter and first six months of 2022 compared to the same periods in 2021 due primarily to fair value adjustments on marketable securities, partially offset by foreign exchange gains.

[0000320193-22-000059:mdna:73]
[same as prior period, unchanged from 0000320193-22-000007:mdna:70]

[0000320193-22-000059:mdna:74]
Provision for income taxes, effective tax rate and statutory federal income tax rate for the three- and six-month periods ended March 26, 2022 and March 27, 2021 were as follows (dollars in millions):

[0000320193-22-000059:mdna:75]
|  | Three Months Ended |  | Six Months Ended |
|  | March 26,2022 |  | March 27,2021 |  | March 26,2022 |  | March 27,2021 |
| Provision for income taxes | $ | 5,129 |  |  | $ | 4,381 |  |  | $ | 11,740 |  |  | $ | 9,205 |  |
| Effective tax rate | 17.0 | % |  | 15.6 | % |  | 16.4 | % |  | 14.9 | % |
| Statutory federal income tax rate | 21 | % |  | 21 | % |  | 21 | % |  | 21 | % |

[0000320193-22-000059:mdna:76]
The Company’s effective tax rate for the second quarter of 2022 was lower than the statutory federal income tax rate due primarily to a lower effective tax rate on foreign earnings, including the favorable impact of changes in unrecognized tax benefits, partially offset by the impact to U.S. foreign tax credits as a result of regulations issued by the U.S. Department of the Treasury in January 2022 (the “Regulations”). The Company’s effective tax rate for the first six months of 2022 was lower than the statutory federal income tax rate due primarily to a lower effective tax rate on foreign earnings, including the favorable impact of changes in unrecognized tax benefits.

[0000320193-22-000059:mdna:77]
The Company’s effective tax rate for the second quarter of 2022 was higher compared to the second quarter of 2021 due primarily to the impact to U.S. foreign tax credits as a result of the Regulations, partially offset by a lower effective tax rate on foreign earnings, including the favorable impact of changes in unrecognized tax benefits. The Company’s effective tax rate for the first six months of 2022 was higher compared to the same period in 2021 due primarily to the impact to U.S. foreign tax credits as a result of the Regulations and lower tax benefits from share-based compensation.

[0000320193-22-000059:mdna:78]
[same as prior period, unchanged from 0000320193-22-000007:mdna:75]

[0000320193-22-000059:mdna:79]
[same as prior period, unchanged from 0000320193-22-000007:mdna:76]

[0000320193-22-000059:mdna:80]
The Company’s contractual cash requirements have not changed materially since the 2021 Form 10-K, except for manufacturing purchase obligations.

[0000320193-22-000059:mdna:81]
[same as prior period, unchanged from 0000320193-22-000007:mdna:78]

[0000320193-22-000059:mdna:82]
The Company utilizes several outsourcing partners to manufacture subassemblies for the Company’s products and to perform final assembly and testing of finished products. The Company also obtains individual components for its products from a wide variety of individual suppliers. Outsourcing partners acquire components and build product based on demand information supplied by the Company, which typically covers periods up to 150 days. As of March 26, 2022, the Company had manufacturing purchase obligations of $40.6 billion, with $40.5 billion payable within 12 months. The Company’s manufacturing purchase obligations are primarily noncancelable.

[0000320193-22-000059:mdna:83]
In addition to its contractual cash requirements, the Company has a share repurchase program authorized by the Board of Directors (the “Program”). As of March 26, 2022, the remaining availability under the Program was $17.6 billion. On April 28, 2022, the Company announced the Board of Directors increased the Program authorization by $90 billion. The Program does not obligate the Company to acquire a minimum amount of shares.

[0000320193-22-000059:mdna:84]
On April 28, 2022, the Company also announced the Board of Directors raised the Company’s quarterly cash dividend from $0.22 to $0.23 per share, beginning with the dividend to be paid during the third quarter of 2022. The Company intends to increase its dividend on an annual basis, subject to declaration by the Board of Directors.

[0000320193-22-000059:mdna:85]
[same as prior period, unchanged from 0000320193-22-000007:mdna:81]

[0000320193-22-000059:mdna:86]
[same as prior period, unchanged from 0000320193-22-000007:mdna:82]
