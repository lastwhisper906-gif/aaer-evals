# AAPL notes — 0000320193-22-000059


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000320193-22-000059:notes:1]
[same as prior period, unchanged from 0000320193-22-000007:notes:1]

[0000320193-22-000059:notes:2]
The condensed consolidated financial statements include the accounts of Apple Inc. and its wholly owned subsidiaries (collectively “Apple” or the “Company”). Intercompany accounts and transactions have been eliminated. In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements and accompanying notes in conformity with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported. Actual results could differ materially from those estimates. Certain prior period amounts in the condensed consolidated financial statements and accompanying notes have been reclassified to conform to the current period’s presentation. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company’s annual consolidated financial statements and accompanying notes included in its Annual Report on Form 10-K for the fiscal year ended September 25, 2021.

[0000320193-22-000059:notes:3]
[same as prior period, unchanged from 0000320193-22-000007:notes:3]

[0000320193-22-000059:notes:4]
[same as prior period, unchanged from 0000320193-22-000007:notes:4]

[0000320193-22-000059:notes:5]
The following table shows the computation of basic and diluted earnings per share for the three- and six-month periods ended March 26, 2022 and March 27, 2021 (net income in millions and shares in thousands):

[0000320193-22-000059:notes:6]
|  | Three Months Ended |  | Six Months Ended |
|  | March 26,2022 |  | March 27,2021 |  | March 26,2022 |  | March 27,2021 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 25,010 |  |  | $ | 23,630 |  |  | $ | 59,640 |  |  | $ | 52,385 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 16,278,802 |  |  | 16,753,476 |  |  | 16,335,263 |  |  | 16,844,298 |  |
| Effect of dilutive securities | 124,514 |  |  | 175,681 |  |  | 126,041 |  |  | 177,125 |  |
| Weighted-average diluted shares | 16,403,316 |  |  | 16,929,157 |  |  | 16,461,304 |  |  | 17,021,423 |  |
| Basic earnings per share | $ | 1.54 |  |  | $ | 1.41 |  |  | $ | 3.65 |  |  | $ | 3.11 |  |
| Diluted earnings per share | $ | 1.52 |  |  | $ | 1.40 |  |  | $ | 3.62 |  |  | $ | 3.08 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000320193-22-000059:notes:7]
Revenue
Net sales disaggregated by significant products and services for the three- and six-month periods ended March 26, 2022 and March 27, 2021 were as follows (in millions):

[0000320193-22-000059:notes:8]
|  | Three Months Ended |  | Six Months Ended |
|  | March 26,2022 |  | March 27,2021 |  | March 26,2022 |  | March 27,2021 |
| iPhone® (1) | $ | 50,570 |  |  | $ | 47,938 |  |  | $ | 122,198 |  |  | $ | 113,535 |  |
| Mac® (1) | 10,435 |  |  | 9,102 |  |  | 21,287 |  |  | 17,777 |  |
| iPad® (1) | 7,646 |  |  | 7,807 |  |  | 14,894 |  |  | 16,242 |  |
| Wearables, Home and Accessories (1)(2) | 8,806 |  |  | 7,836 |  |  | 23,507 |  |  | 20,807 |  |
| Services (3) | 19,821 |  |  | 16,901 |  |  | 39,337 |  |  | 32,662 |  |
| Total net sales (4) | $ | 97,278 |  |  | $ | 89,584 |  |  | $ | 221,223 |  |  | $ | 201,023 |  |

[0000320193-22-000059:notes:9]
[same as prior period, unchanged from 0000320193-22-000007:notes:9]

[0000320193-22-000059:notes:10]
[same as prior period, unchanged from 0000320193-22-000007:notes:10]

[0000320193-22-000059:notes:11]
[same as prior period, unchanged from 0000320193-22-000007:notes:11]

[0000320193-22-000059:notes:12]
(4)Includes $3.0 billion of revenue recognized in the three months ended March 26, 2022 that was included in deferred revenue as of December 25, 2021, $2.7 billion of revenue recognized in the three months ended March 27, 2021 that was included in deferred revenue as of December 26, 2020, $4.8 billion of revenue recognized in the six months ended March 26, 2022 that was included in deferred revenue as of September 25, 2021, and $4.1 billion of revenue recognized in the six months ended March 27, 2021 that was included in deferred revenue as of September 26, 2020.

[0000320193-22-000059:notes:13]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 9, “Segment Information and Geographic Data” for the three- and six-month periods ended March 26, 2022 and March 27, 2021, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.

[0000320193-22-000059:notes:14]
As of March 26, 2022 and September 25, 2021, the Company had total deferred revenue of $12.5 billion and $11.9 billion, respectively. As of March 26, 2022, the Company expects 63% of total deferred revenue to be realized in less than a year, 27% within one-to-two years, 8% within two-to-three years and 2% in greater than three years.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000320193-22-000059:notes:15]
[same as prior period, unchanged from 0000320193-22-000007:notes:15]

[0000320193-22-000059:notes:16]
The following tables show the Company’s cash, cash equivalents and marketable securities by significant investment category as of March 26, 2022 and September 25, 2021 (in millions):

[0000320193-22-000059:notes:17]
|  | March 26, 2022 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | CurrentMarketableSecurities |  | Non-CurrentMarketableSecurities |
| Cash | $ | 14,298 |  |  | $ | — |  |  | $ | — |  |  | $ | 14,298 |  |  | $ | 14,298 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 7,653 |  |  | — |  |  | — |  |  | 7,653 |  |  | 7,653 |  |  | — |  |  | — |  |
| Mutual funds | 230 |  |  | 7 |  |  | (9) |  |  | 228 |  |  | — |  |  | 228 |  |  | — |  |
| Subtotal | 7,883 |  |  | 7 |  |  | (9) |  |  | 7,881 |  |  | 7,653 |  |  | 228 |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities | 1,527 |  |  | — |  |  | (1,132) |  |  | 395 |  |  | — |  |  | 395 |  |  | — |  |
| U.S. Treasury securities | 28,711 |  |  | 2 |  |  | (1,037) |  |  | 27,676 |  |  | 2,306 |  |  | 3,554 |  |  | 21,816 |  |
| U.S. agency securities | 6,561 |  |  | — |  |  | (407) |  |  | 6,154 |  |  | 251 |  |  | 683 |  |  | 5,220 |  |
| Non-U.S. government securities | 18,868 |  |  | 44 |  |  | (551) |  |  | 18,361 |  |  | 25 |  |  | 4,526 |  |  | 13,810 |  |
| Certificates of deposit and time deposits | 2,872 |  |  | — |  |  | — |  |  | 2,872 |  |  | 2,221 |  |  | 601 |  |  | 50 |  |
| Commercial paper | 2,913 |  |  | — |  |  | — |  |  | 2,913 |  |  | 1,310 |  |  | 1,603 |  |  | — |  |
| Corporate debt securities | 93,057 |  |  | 94 |  |  | (4,266) |  |  | 88,885 |  |  | 34 |  |  | 11,309 |  |  | 77,542 |  |
| Municipal securities | 990 |  |  | 1 |  |  | (22) |  |  | 969 |  |  | — |  |  | 162 |  |  | 807 |  |
| Mortgage- and asset-backed securities | 23,613 |  |  | 3 |  |  | (1,290) |  |  | 22,326 |  |  | — |  |  | 352 |  |  | 21,974 |  |
| Subtotal | 179,112 |  |  | 144 |  |  | (8,705) |  |  | 170,551 |  |  | 6,147 |  |  | 23,185 |  |  | 141,219 |  |
| Total (3) | $ | 201,293 |  |  | $ | 151 |  |  | $ | (8,714) |  |  | $ | 192,730 |  |  | $ | 28,098 |  |  | $ | 23,413 |  |  | $ | 141,219 |  |

[0000320193-22-000059:notes:18]
[same as prior period, unchanged from 0000320193-22-000007:notes:18]

[0000320193-22-000059:notes:19]
[same as prior period, unchanged from 0000320193-22-000007:notes:19]

[0000320193-22-000059:notes:20]
[same as prior period, unchanged from 0000320193-22-000007:notes:20]

[0000320193-22-000059:notes:21]
(3)As of March 26, 2022 and September 25, 2021, total marketable securities included $15.4 billion and $17.9 billion, respectively, that were restricted from general use, related to the European Commission decision finding that Ireland granted state aid to the Company, and other agreements.

[0000320193-22-000059:notes:22]
The following table shows the fair value of the Company’s non-current marketable debt securities, by contractual maturity, as of March 26, 2022 (in millions):

[0000320193-22-000059:notes:23]
| Due after 1 year through 5 years | $ | 97,603 |  |
| Due after 5 years through 10 years | 22,899 |  |
| Due after 10 years | 20,717 |  |
| Total fair value | $ | 141,219 |  |

[0000320193-22-000059:notes:24]
[same as prior period, unchanged from 0000320193-22-000007:notes:24]

[0000320193-22-000059:notes:25]
[same as prior period, unchanged from 0000320193-22-000007:notes:25]

[0000320193-22-000059:notes:26]
[same as prior period, unchanged from 0000320193-22-000007:notes:26]

[0000320193-22-000059:notes:27]
[same as prior period, unchanged from 0000320193-22-000007:notes:27]

[0000320193-22-000059:notes:28]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in foreign currency exchange rates, the Company may enter into forward contracts, cross-currency swaps or other instruments. The Company designates these instruments as either cash flow or fair value hedges. As of March 26, 2022, the Company’s hedged term debt– and marketable securities–related foreign currency transactions are expected to be recognized within 20 years.

[0000320193-22-000059:notes:29]
[same as prior period, unchanged from 0000320193-22-000007:notes:29]

[0000320193-22-000059:notes:30]
[same as prior period, unchanged from 0000320193-22-000007:notes:30]

[0000320193-22-000059:notes:31]
[same as prior period, unchanged from 0000320193-22-000007:notes:31]

[0000320193-22-000059:notes:32]
The notional amounts of the Company’s outstanding derivative instruments as of March 26, 2022 and September 25, 2021 were as follows (in millions):

[0000320193-22-000059:notes:33]
|  | March 26,2022 |  | September 25,2021 |
| Derivative instruments designated as accounting hedges: |  |  |  |
| Foreign exchange contracts | $ | 65,140 |  |  | $ | 76,475 |  |
| Interest rate contracts | $ | 20,775 |  |  | $ | 16,875 |  |
| Derivative instruments not designated as accounting hedges: |  |  |  |
| Foreign exchange contracts | $ | 110,758 |  |  | $ | 126,918 |  |

[0000320193-22-000059:notes:34]
The gross fair values of the Company’s derivative assets and liabilities were not material as of March 26, 2022 and September 25, 2021.

[0000320193-22-000059:notes:35]
The gains and losses recognized in other comprehensive income/(loss) and amounts reclassified from accumulated other comprehensive income/(loss) to net income for the Company’s derivative instruments designated as cash flow hedges were not material in the three- and six-month periods ended March 26, 2022 and March 27, 2021.

[0000320193-22-000059:notes:36]
The carrying amounts of the Company’s hedged items in fair value hedges as of March 26, 2022 and September 25, 2021 were as follows (in millions):

[0000320193-22-000059:notes:37]
|  | March 26,2022 |  | September 25,2021 |
| Hedged assets/(liabilities): |  |  |  |
| Current and non-current marketable securities | $ | 14,943 |  |  | $ | 15,954 |  |
| Current and non-current term debt | $ | (19,766) |  |  | $ | (17,857) |  |

[0000320193-22-000059:notes:38]
The gains and losses on the Company’s derivative instruments designated as fair value hedges and the related hedged item adjustments were not material in the three- and six-month periods ended March 26, 2022 and March 27, 2021.

[0000320193-22-000059:notes:39]
[same as prior period, unchanged from 0000320193-22-000007:notes:39]

[0000320193-22-000059:notes:40]
[same as prior period, unchanged from 0000320193-22-000007:notes:40]

[0000320193-22-000059:notes:41]
[same as prior period, unchanged from 0000320193-22-000007:notes:41]

[0000320193-22-000059:notes:42]
The Company’s cellular network carriers accounted for 36% and 42% of total trade receivables as of March 26, 2022 and September 25, 2021, respectively.

[0000320193-22-000059:notes:43]
[same as prior period, unchanged from 0000320193-22-000007:notes:43]

[0000320193-22-000059:notes:44]
The Company has non-trade receivables from certain of its manufacturing vendors resulting from the sale of components to these vendors who manufacture subassemblies or assemble final products for the Company. The Company purchases these components directly from suppliers. As of March 26, 2022, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 52% and 12%. As of September 25, 2021, the Company had three vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 52%, 11% and 11%.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000320193-22-000059:notes:45]
[same as prior period, unchanged from 0000320193-22-000007:notes:45]


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000320193-22-000059:notes:46]
Condensed Consolidated Financial Statement Details
The following tables show the Company’s condensed consolidated financial statement details as of March 26, 2022 and September 25, 2021 (in millions):

[0000320193-22-000059:notes:47]
[same as prior period, unchanged from 0000320193-22-000007:notes:47]

[0000320193-22-000059:notes:48]
|  | March 26,2022 |  | September 25,2021 |
| Gross property, plant and equipment | $ | 109,324 |  |  | $ | 109,723 |  |
| Accumulated depreciation and amortization | (70,020) |  |  | (70,283) |  |
| Total property, plant and equipment, net | $ | 39,304 |  |  | $ | 39,440 |  |

[0000320193-22-000059:notes:49]
[same as prior period, unchanged from 0000320193-22-000007:notes:49]

[0000320193-22-000059:notes:50]
|  | March 26,2022 |  | September 25,2021 |
| Long-term taxes payable | $ | 20,711 |  |  | $ | 24,689 |  |
| Other non-current liabilities | 31,721 |  |  | 28,636 |  |
| Total other non-current liabilities | $ | 52,432 |  |  | $ | 53,325 |  |

[0000320193-22-000059:notes:51]
[same as prior period, unchanged from 0000320193-22-000007:notes:51]

[0000320193-22-000059:notes:52]
The following table shows the detail of other income/(expense), net for the three- and six-month periods ended March 26, 2022 and March 27, 2021 (in millions):

[0000320193-22-000059:notes:53]
|  | Three Months Ended |  | Six Months Ended |
|  | March 26,2022 |  | March 27,2021 |  | March 26,2022 |  | March 27,2021 |
| Interest and dividend income | $ | 700 |  |  | $ | 718 |  |  | $ | 1,350 |  |  | $ | 1,465 |  |
| Interest expense | (691) |  |  | (670) |  |  | (1,385) |  |  | (1,308) |  |
| Other income/(expense), net | 151 |  |  | 460 |  |  | (52) |  |  | 396 |  |
| Total other income/(expense), net | $ | 160 |  |  | $ | 508 |  |  | $ | (87) |  |  | $ | 553 |  |


## us-gaap:DebtDisclosureTextBlock

[0000320193-22-000059:notes:54]
Debt
Commercial Paper

[0000320193-22-000059:notes:55]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of March 26, 2022 and September 25, 2021, the Company had $7.0 billion and $6.0 billion of Commercial Paper outstanding, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the six months ended March 26, 2022 and March 27, 2021 (in millions):

[0000320193-22-000059:notes:56]
|  | Six Months Ended |
|  | March 26,2022 |  | March 27,2021 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from commercial paper, net | $ | 4,952 |  |  | $ | 2,008 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 1,191 |  |  | 1,368 |  |
| Repayments of commercial paper | (5,144) |  |  | (3,354) |  |
| Repayments of commercial paper, net | (3,953) |  |  | (1,986) |  |
| Total proceeds from commercial paper, net | $ | 999 |  |  | $ | 22 |  |

[0000320193-22-000059:notes:57]
Term Debt

[0000320193-22-000059:notes:58]
As of March 26, 2022 and September 25, 2021, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate carrying amount of $113.0 billion and $118.7 billion, respectively (collectively the “Notes”). As of March 26, 2022 and September 25, 2021, the fair value of the Company’s Notes, based on Level 2 inputs, was $110.5 billion and $125.3 billion, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000320193-22-000059:notes:59]
[same as prior period, unchanged from 0000320193-22-000007:notes:59]

[0000320193-22-000059:notes:60]
During the six months ended March 26, 2022, the Company repurchased 266 million shares of its common stock for $43.3 billion under a share repurchase program authorized by the Board of Directors (the “Program”), including 35 million shares delivered under accelerated share repurchase agreements totaling $6.0 billion that were entered into in November 2021. The Program does not obligate the Company to acquire a minimum amount of shares. Under the Program, shares may be repurchased in privately negotiated and/or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000320193-22-000059:notes:61]
[same as prior period, unchanged from 0000320193-22-000007:notes:61]

[0000320193-22-000059:notes:62]
A summary of the Company’s restricted stock unit (“RSU”) activity and related information for the six months ended March 26, 2022 is as follows:

[0000320193-22-000059:notes:63]
|  | Number ofRSUs(in thousands) |  | Weighted-AverageGrant Date FairValue Per RSU |  | AggregateFair Value(in millions) |
| Balance as of September 25, 2021 | 240,427 |  |  | $ | 75.16 |  |  |  |
| RSUs granted | 76,920 |  |  | $ | 149.72 |  |  |  |
| RSUs vested | (62,476) |  |  | $ | 62.86 |  |  |  |
| RSUs canceled | (8,407) |  |  | $ | 95.86 |  |  |  |
| Balance as of March 26, 2022 | 246,464 |  |  | $ | 100.84 |  |  | $ | 43,062 |  |

[0000320193-22-000059:notes:64]
The fair value as of the respective vesting dates of RSUs was $1.0 billion and $9.5 billion for the three- and six-month periods ended March 26, 2022, respectively, and was $867 million and $9.4 billion for the three- and six-month periods ended March 27, 2021, respectively.

[0000320193-22-000059:notes:65]
[same as prior period, unchanged from 0000320193-22-000007:notes:65]

[0000320193-22-000059:notes:66]
The following table shows share-based compensation expense and the related income tax benefit included in the Condensed Consolidated Statements of Operations for the three- and six-month periods ended March 26, 2022 and March 27, 2021 (in millions):

[0000320193-22-000059:notes:67]
|  | Three Months Ended |  | Six Months Ended |
|  | March 26,2022 |  | March 27,2021 |  | March 26,2022 |  | March 27,2021 |
| Share-based compensation expense | $ | 2,252 |  |  | $ | 1,981 |  |  | $ | 4,517 |  |  | $ | 4,001 |  |
| Income tax benefit related to share-based compensation expense | $ | (649) |  |  | $ | (575) |  |  | $ | (2,185) |  |  | $ | (2,199) |  |

[0000320193-22-000059:notes:68]
As of March 26, 2022, the total unrecognized compensation cost related to outstanding RSUs and stock options was $19.3 billion, which the Company expects to recognize over a weighted-average period of 2.8 years.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000320193-22-000059:notes:69]
Commitments and Contingencies
Accrued Warranty

[0000320193-22-000059:notes:70]
The following table shows changes in the Company’s accrued warranties and related costs for the three- and six-month periods ended March 26, 2022 and March 27, 2021 (in millions):

[0000320193-22-000059:notes:71]
|  | Three Months Ended |  | Six Months Ended |
|  | March 26,2022 |  | March 27,2021 |  | March 26,2022 |  | March 27,2021 |
| Beginning accrued warranty and related costs | $ | 3,530 |  |  | $ | 4,124 |  |  | $ | 3,364 |  |  | $ | 3,354 |  |
| Cost of warranty claims | (581) |  |  | (649) |  |  | (1,253) |  |  | (1,372) |  |
| Accruals for product warranty | 257 |  |  | 309 |  |  | 1,095 |  |  | 1,802 |  |
| Ending accrued warranty and related costs | $ | 3,206 |  |  | $ | 3,784 |  |  | $ | 3,206 |  |  | $ | 3,784 |  |

[0000320193-22-000059:notes:72]
Contingencies

[0000320193-22-000059:notes:73]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully resolved. The outcome of litigation is inherently uncertain. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss greater than a recorded accrual, concerning loss contingencies for asserted legal and other claims.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000320193-22-000059:notes:74]
Segment Information and Geographic Data
The following table shows information by reportable segment for the three- and six-month periods ended March 26, 2022 and March 27, 2021 (in millions):

[0000320193-22-000059:notes:75]
|  | Three Months Ended |  | Six Months Ended |
|  | March 26,2022 |  | March 27,2021 |  | March 26,2022 |  | March 27,2021 |
| Americas: |  |  |  |  |  |  |  |
| Net sales | $ | 40,882 |  |  | $ | 34,306 |  |  | $ | 92,378 |  |  | $ | 80,616 |  |
| Operating income | $ | 15,279 |  |  | $ | 12,050 |  |  | $ | 34,864 |  |  | $ | 27,835 |  |
| Europe: |  |  |  |  |  |  |  |
| Net sales | $ | 23,287 |  |  | $ | 22,264 |  |  | $ | 53,036 |  |  | $ | 49,570 |  |
| Operating income | $ | 8,505 |  |  | $ | 8,265 |  |  | $ | 20,050 |  |  | $ | 17,854 |  |
| Greater China: |  |  |  |  |  |  |  |
| Net sales | $ | 18,343 |  |  | $ | 17,728 |  |  | $ | 44,126 |  |  | $ | 39,041 |  |
| Operating income | $ | 8,112 |  |  | $ | 7,758 |  |  | $ | 19,295 |  |  | $ | 16,288 |  |
| Japan: |  |  |  |  |  |  |  |
| Net sales | $ | 7,724 |  |  | $ | 7,742 |  |  | $ | 14,831 |  |  | $ | 16,027 |  |
| Operating income | $ | 3,496 |  |  | $ | 3,428 |  |  | $ | 6,845 |  |  | $ | 6,931 |  |
| Rest of Asia Pacific: |  |  |  |  |  |  |  |
| Net sales | $ | 7,042 |  |  | $ | 7,544 |  |  | $ | 16,852 |  |  | $ | 15,769 |  |
| Operating income | $ | 2,823 |  |  | $ | 2,736 |  |  | $ | 6,818 |  |  | $ | 5,689 |  |

[0000320193-22-000059:notes:76]
A reconciliation of the Company’s segment operating income to the Condensed Consolidated Statements of Operations for the three- and six-month periods ended March 26, 2022 and March 27, 2021 is as follows (in millions):

[0000320193-22-000059:notes:77]
|  | Three Months Ended |  | Six Months Ended |
|  | March 26,2022 |  | March 27,2021 |  | March 26,2022 |  | March 27,2021 |
| Segment operating income | $ | 38,215 |  |  | $ | 34,237 |  |  | $ | 87,872 |  |  | $ | 74,597 |  |
| Research and development expense | (6,387) |  |  | (5,262) |  |  | (12,693) |  |  | (10,425) |  |
| Other corporate expenses, net | (1,849) |  |  | (1,472) |  |  | (3,712) |  |  | (3,135) |  |
| Total operating income | $ | 29,979 |  |  | $ | 27,503 |  |  | $ | 71,467 |  |  | $ | 61,037 |  |
