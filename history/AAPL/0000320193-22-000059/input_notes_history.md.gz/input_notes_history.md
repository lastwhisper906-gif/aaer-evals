# AAPL note change history — 0000320193-22-000007 → 0000320193-22-000059


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-04-29):
[0000320193-22-000059:note_history:1]
The following table shows changes in the Company’s accrued warranties and related costs for the three- and six-month periods ended March 26, 2022 and March 27, 2021 (in millions):
  (was, 2022-01-28, similarity 0.8963):
[0000320193-22-000007:note_history:1]
The following table shows changes in the Company’s accrued warranties and related costs for the three months ended December 25, 2021 and December 26, 2020 (in millions):

- changed (2022-04-29):
[0000320193-22-000059:note_history:2]
|  | Three Months Ended |  | Six Months Ended |
|  | March 26,2022 |  | March 27,2021 |  | March 26,2022 |  | March 27,2021 |
| Beginning accrued warranty and related costs | $ | 3,530 |  |  | $ | 4,124 |  |  | $ | 3,364 |  |  | $ | 3,354 |  |
| Cost of warranty claims | (581) |  |  | (649) |  |  | (1,253) |  |  | (1,372) |  |
| Accruals for product warranty | 257 |  |  | 309 |  |  | 1,095 |  |  | 1,802 |  |
| Ending accrued warranty and related costs | $ | 3,206 |  |  | $ | 3,784 |  |  | $ | 3,206 |  |  | $ | 3,784 |  |
  (was, 2022-01-28, similarity 0.7732):
[0000320193-22-000007:note_history:2]
|  | Three Months Ended |  |  |
|  | December 25,2021 |  | December 26,2020 |  |  |  |  |
| Beginning accrued warranty and related costs | $ | 3,364 |  |  | $ | 3,354 |  |  |  |  |  |
| Cost of warranty claims | (672) |  |  | (723) |  |  |  |  |  |
| Accruals for product warranty | 838 |  |  | 1,493 |  |  |  |  |  |
| Ending accrued warranty and related costs | $ | 3,530 |  |  | $ | 4,124 |  |  |  |  |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-04-29):
[0000320193-22-000059:note_history:3]
The condensed consolidated financial statements include the accounts of Apple Inc. and its wholly owned subsidiaries (collectively “Apple” or the “Company”). Intercompany accounts and transactions have been eliminated. In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements and accompanying notes in conformity with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported. Actual results could differ materially from those estimates. Certain prior period amounts in the condensed consolidated financial statements and accompanying notes have been reclassified to conform to the current period’s presentation. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company’s annual consolidated financial statements and accompanying notes included in its Annual Report on Form 10-K for the fiscal year ended September 25, 2021.
  (was, 2022-01-28, similarity 0.9916):
[0000320193-22-000007:note_history:3]
The condensed consolidated financial statements include the accounts of Apple Inc. and its wholly owned subsidiaries (collectively “Apple” or the “Company”). Intercompany accounts and transactions have been eliminated. In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements and accompanying notes in conformity with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported. Actual results could differ materially from those estimates. Certain prior period amounts in the condensed consolidated financial statements and accompanying notes have been reclassified to conform to the current period’s presentation. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company’s annual consolidated financial statements and accompanying notes included in its Annual Report on Form 10-K for the fiscal year ended September 25, 2021 (the “2021 Form 10-K”).

- changed (2022-04-29):
[0000320193-22-000059:note_history:4]
The following table shows the computation of basic and diluted earnings per share for the three- and six-month periods ended March 26, 2022 and March 27, 2021 (net income in millions and shares in thousands):
  (was, 2022-01-28, similarity 0.9119):
[0000320193-22-000007:note_history:4]
The following table shows the computation of basic and diluted earnings per share for the three months ended December 25, 2021 and December 26, 2020 (net income in millions and shares in thousands):

- changed (2022-04-29):
[0000320193-22-000059:note_history:5]
|  | Three Months Ended |  | Six Months Ended |
|  | March 26,2022 |  | March 27,2021 |  | March 26,2022 |  | March 27,2021 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 25,010 |  |  | $ | 23,630 |  |  | $ | 59,640 |  |  | $ | 52,385 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 16,278,802 |  |  | 16,753,476 |  |  | 16,335,263 |  |  | 16,844,298 |  |
| Effect of dilutive securities | 124,514 |  |  | 175,681 |  |  | 126,041 |  |  | 177,125 |  |
| Weighted-average diluted shares | 16,403,316 |  |  | 16,929,157 |  |  | 16,461,304 |  |  | 17,021,423 |  |
| Basic earnings per share | $ | 1.54 |  |  | $ | 1.41 |  |  | $ | 3.65 |  |  | $ | 3.11 |  |
| Diluted earnings per share | $ | 1.52 |  |  | $ | 1.40 |  |  | $ | 3.62 |  |  | $ | 3.08 |  |
  (was, 2022-01-28, similarity 0.8122):
[0000320193-22-000007:note_history:5]
|  | Three Months Ended |  |  |
|  | December 25,2021 |  | December 26,2020 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 34,630 |  |  | $ | 28,755 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 16,391,724 |  |  | 16,935,119 |  |  |  |  |  |
| Effect of dilutive securities | 127,567 |  |  | 178,569 |  |  |  |  |  |
| Weighted-average diluted shares | 16,519,291 |  |  | 17,113,688 |  |  |  |  |  |
| Basic earnings per share | $ | 2.11 |  |  | $ | 1.70 |  |  |  |  |  |
| Diluted earnings per share | $ | 2.10 |  |  | $ | 1.68 |  |  |  |  |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-04-29):
[0000320193-22-000059:note_history:6]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of March 26, 2022 and September 25, 2021, the Company had $7.0 billion and $6.0 billion of Commercial Paper outstanding, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the six months ended March 26, 2022 and March 27, 2021 (in millions):
  (was, 2022-01-28, similarity 0.9178):
[0000320193-22-000007:note_history:6]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of December 25, 2021 and September 25, 2021, the Company had $5.0 billion and $6.0 billion of Commercial Paper outstanding, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the three months ended December 25, 2021 and December 26, 2020 (in millions):

- added (2022-04-29):
[0000320193-22-000059:note_history:7]
|  | Six Months Ended |
|  | March 26,2022 |  | March 27,2021 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from commercial paper, net | $ | 4,952 |  |  | $ | 2,008 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 1,191 |  |  | 1,368 |  |
| Repayments of commercial paper | (5,144) |  |  | (3,354) |  |
| Repayments of commercial paper, net | (3,953) |  |  | (1,986) |  |
| Total proceeds from commercial paper, net | $ | 999 |  |  | $ | 22 |  |

- changed (2022-04-29):
[0000320193-22-000059:note_history:8]
As of March 26, 2022 and September 25, 2021, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate carrying amount of $113.0 billion and $118.7 billion, respectively (collectively the “Notes”). As of March 26, 2022 and September 25, 2021, the fair value of the Company’s Notes, based on Level 2 inputs, was $110.5 billion and $125.3 billion, respectively.
  (was, 2022-01-28, similarity 0.9645):
[0000320193-22-000007:note_history:8]
As of December 25, 2021 and September 25, 2021, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate carrying amount of $117.8 billion and $118.7 billion, respectively (collectively the “Notes”). As of December 25, 2021 and September 25, 2021, the fair value of the Company’s Notes, based on Level 2 inputs, was $123.5 billion and $125.3 billion, respectively.

- removed (2022-04-29):
[0000320193-22-000007:note_history:9]
|  | Three Months Ended |
|  | December 25,2021 |  | December 26,2020 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from commercial paper, net | $ | 1,339 |  |  | $ | 1,439 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 1,191 |  |  | 780 |  |
| Repayments of commercial paper | (3,530) |  |  | (2,197) |  |
| Repayments of commercial paper, net | (2,339) |  |  | (1,417) |  |
| Total proceeds from/(repayments of) commercial paper, net | $ | (1,000) |  |  | $ | 22 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-04-29):
[0000320193-22-000059:note_history:10]
Net sales disaggregated by significant products and services for the three- and six-month periods ended March 26, 2022 and March 27, 2021 were as follows (in millions):
  (was, 2022-01-28, similarity 0.8889):
[0000320193-22-000007:note_history:10]
Net sales disaggregated by significant products and services for the three months ended December 25, 2021 and December 26, 2020 were as follows (in millions):

- changed (2022-04-29):
[0000320193-22-000059:note_history:11]
|  | Three Months Ended |  | Six Months Ended |
|  | March 26,2022 |  | March 27,2021 |  | March 26,2022 |  | March 27,2021 |
| iPhone® (1) | $ | 50,570 |  |  | $ | 47,938 |  |  | $ | 122,198 |  |  | $ | 113,535 |  |
| Mac® (1) | 10,435 |  |  | 9,102 |  |  | 21,287 |  |  | 17,777 |  |
| iPad® (1) | 7,646 |  |  | 7,807 |  |  | 14,894 |  |  | 16,242 |  |
| Wearables, Home and Accessories (1)(2) | 8,806 |  |  | 7,836 |  |  | 23,507 |  |  | 20,807 |  |
| Services (3) | 19,821 |  |  | 16,901 |  |  | 39,337 |  |  | 32,662 |  |
| Total net sales (4) | $ | 97,278 |  |  | $ | 89,584 |  |  | $ | 221,223 |  |  | $ | 201,023 |  |
  (was, 2022-01-28, similarity 0.7568):
[0000320193-22-000007:note_history:11]
|  | Three Months Ended |  |  |
|  | December 25,2021 |  | December 26,2020 |  |  |  |  |
| iPhone® (1) | $ | 71,628 |  |  | $ | 65,597 |  |  |  |  |  |
| Mac® (1) | 10,852 |  |  | 8,675 |  |  |  |  |  |
| iPad® (1) | 7,248 |  |  | 8,435 |  |  |  |  |  |
| Wearables, Home and Accessories (1)(2) | 14,701 |  |  | 12,971 |  |  |  |  |  |
| Services (3) | 19,516 |  |  | 15,761 |  |  |  |  |  |
| Total net sales (4) | $ | 123,945 |  |  | $ | 111,439 |  |  |  |  |  |

- changed (2022-04-29):
[0000320193-22-000059:note_history:12]
(4)Includes $3.0 billion of revenue recognized in the three months ended March 26, 2022 that was included in deferred revenue as of December 25, 2021, $2.7 billion of revenue recognized in the three months ended March 27, 2021 that was included in deferred revenue as of December 26, 2020, $4.8 billion of revenue recognized in the six months ended March 26, 2022 that was included in deferred revenue as of September 25, 2021, and $4.1 billion of revenue recognized in the six months ended March 27, 2021 that was included in deferred revenue as of September 26, 2020.
  (was, 2022-01-28, similarity 0.6111):
[0000320193-22-000007:note_history:12]
(4)Includes $3.0 billion of revenue recognized in the three months ended December 25, 2021 that was included in deferred revenue as of September 25, 2021 and $2.5 billion of revenue recognized in the three months ended December 26, 2020 that was included in deferred revenue as of September 26, 2020.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-04-29):
[0000320193-22-000059:note_history:13]
Revenue
Net sales disaggregated by significant products and services for the three- and six-month periods ended March 26, 2022 and March 27, 2021 were as follows (in millions):
  (was, 2022-01-28, similarity 0.8944):
[0000320193-22-000007:note_history:13]
Revenue
Net sales disaggregated by significant products and services for the three months ended December 25, 2021 and December 26, 2020 were as follows (in millions):

- changed (2022-04-29):
[0000320193-22-000059:note_history:14]
|  | Three Months Ended |  | Six Months Ended |
|  | March 26,2022 |  | March 27,2021 |  | March 26,2022 |  | March 27,2021 |
| iPhone® (1) | $ | 50,570 |  |  | $ | 47,938 |  |  | $ | 122,198 |  |  | $ | 113,535 |  |
| Mac® (1) | 10,435 |  |  | 9,102 |  |  | 21,287 |  |  | 17,777 |  |
| iPad® (1) | 7,646 |  |  | 7,807 |  |  | 14,894 |  |  | 16,242 |  |
| Wearables, Home and Accessories (1)(2) | 8,806 |  |  | 7,836 |  |  | 23,507 |  |  | 20,807 |  |
| Services (3) | 19,821 |  |  | 16,901 |  |  | 39,337 |  |  | 32,662 |  |
| Total net sales (4) | $ | 97,278 |  |  | $ | 89,584 |  |  | $ | 221,223 |  |  | $ | 201,023 |  |
  (was, 2022-01-28, similarity 0.7568):
[0000320193-22-000007:note_history:14]
|  | Three Months Ended |  |  |
|  | December 25,2021 |  | December 26,2020 |  |  |  |  |
| iPhone® (1) | $ | 71,628 |  |  | $ | 65,597 |  |  |  |  |  |
| Mac® (1) | 10,852 |  |  | 8,675 |  |  |  |  |  |
| iPad® (1) | 7,248 |  |  | 8,435 |  |  |  |  |  |
| Wearables, Home and Accessories (1)(2) | 14,701 |  |  | 12,971 |  |  |  |  |  |
| Services (3) | 19,516 |  |  | 15,761 |  |  |  |  |  |
| Total net sales (4) | $ | 123,945 |  |  | $ | 111,439 |  |  |  |  |  |

- changed (2022-04-29):
[0000320193-22-000059:note_history:15]
(4)Includes $3.0 billion of revenue recognized in the three months ended March 26, 2022 that was included in deferred revenue as of December 25, 2021, $2.7 billion of revenue recognized in the three months ended March 27, 2021 that was included in deferred revenue as of December 26, 2020, $4.8 billion of revenue recognized in the six months ended March 26, 2022 that was included in deferred revenue as of September 25, 2021, and $4.1 billion of revenue recognized in the six months ended March 27, 2021 that was included in deferred revenue as of September 26, 2020.
  (was, 2022-01-28, similarity 0.6111):
[0000320193-22-000007:note_history:15]
(4)Includes $3.0 billion of revenue recognized in the three months ended December 25, 2021 that was included in deferred revenue as of September 25, 2021 and $2.5 billion of revenue recognized in the three months ended December 26, 2020 that was included in deferred revenue as of September 26, 2020.

- changed (2022-04-29):
[0000320193-22-000059:note_history:16]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 9, “Segment Information and Geographic Data” for the three- and six-month periods ended March 26, 2022 and March 27, 2021, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.
  (was, 2022-01-28, similarity 0.8525):
[0000320193-22-000007:note_history:16]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 9, “Segment Information and Geographic Data” for the three months ended December 25, 2021 and December 26, 2020, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.

- changed (2022-04-29):
[0000320193-22-000059:note_history:17]
As of March 26, 2022 and September 25, 2021, the Company had total deferred revenue of $12.5 billion and $11.9 billion, respectively. As of March 26, 2022, the Company expects 63% of total deferred revenue to be realized in less than a year, 27% within one-to-two years, 8% within two-to-three years and 2% in greater than three years.
  (was, 2022-01-28, similarity 0.9585):
[0000320193-22-000007:note_history:17]
As of December 25, 2021 and September 25, 2021, the Company had total deferred revenue of $12.4 billion and $11.9 billion, respectively. As of December 25, 2021, the Company expects 64% of total deferred revenue to be realized in less than a year, 27% within one-to-two years, 8% within two-to-three years and 1% in greater than three years.
