# AAPL MD&A — 0000320193-24-000081


## mdna

[0000320193-24-000081:mdna:1]
[same as prior period, unchanged from 0000320193-24-000069:mdna:1]

[0000320193-24-000081:mdna:2]
[same as prior period, unchanged from 0000320193-24-000069:mdna:2]

[0000320193-24-000081:mdna:3]
[same as prior period, unchanged from 0000320193-24-000069:mdna:3]

[0000320193-24-000081:mdna:4]
[same as prior period, unchanged from 0000320193-24-000069:mdna:4]

[0000320193-24-000081:mdna:5]
[same as prior period, unchanged from 0000320193-24-000069:mdna:5]

[0000320193-24-000081:mdna:6]
[same as prior period, unchanged from 0000320193-24-000069:mdna:6]

[0000320193-24-000081:mdna:7]
[same as prior period, unchanged from 0000320193-24-000069:mdna:7]

[0000320193-24-000081:mdna:8]
During the third quarter of 2024, the Company announced the following product and operating system updates:

[0000320193-24-000081:mdna:9]
•iPad Air®;

[0000320193-24-000081:mdna:10]
•iPad Pro®;

[0000320193-24-000081:mdna:11]
•iOS 18, macOS® Sequoia, iPadOS® 18, watchOS® 11, visionOS™ 2 and tvOS® 18.

[0000320193-24-000081:mdna:12]
The Company also announced Apple Intelligence™, a personal intelligence system that uses generative models, which will be available on certain iPhone, Mac and iPad devices. Apple Intelligence is deeply integrated into iOS 18, macOS Sequoia and iPadOS 18.

[0000320193-24-000081:mdna:13]
[same as prior period, unchanged from 0000320193-24-000069:mdna:9]

[0000320193-24-000081:mdna:14]
[same as prior period, unchanged from 0000320193-24-000069:mdna:10]

[0000320193-24-000081:mdna:15]
[same as prior period, unchanged from 0000320193-24-000069:mdna:11]

[0000320193-24-000081:mdna:16]
[same as prior period, unchanged from 0000320193-24-000069:mdna:12]

[0000320193-24-000081:mdna:17]
[same as prior period, unchanged from 0000320193-24-000069:mdna:13]

[0000320193-24-000081:mdna:18]
The following table shows net sales by reportable segment for the three- and nine-month periods ended June 29, 2024 and July 1, 2023 (dollars in millions):

[0000320193-24-000081:mdna:19]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29,2024 |  | July 1,2023 |  | Change |  | June 29,2024 |  | July 1,2023 |  | Change |
| Net sales by reportable segment: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 37,678 |  |  | $ | 35,383 |  |  | 6 | % |  | $ | 125,381 |  |  | $ | 122,445 |  |  | 2 | % |
| Europe | 21,884 |  |  | 20,205 |  |  | 8 | % |  | 76,404 |  |  | 71,831 |  |  | 6 | % |
| Greater China | 14,728 |  |  | 15,758 |  |  | (7) | % |  | 51,919 |  |  | 57,475 |  |  | (10) | % |
| Japan | 5,097 |  |  | 4,821 |  |  | 6 | % |  | 19,126 |  |  | 18,752 |  |  | 2 | % |
| Rest of Asia Pacific | 6,390 |  |  | 5,630 |  |  | 13 | % |  | 23,275 |  |  | 23,284 |  |  | — | % |
| Total net sales | $ | 85,777 |  |  | $ | 81,797 |  |  | 5 | % |  | $ | 296,105 |  |  | $ | 293,787 |  |  | 1 | % |

[0000320193-24-000081:mdna:20]
[same as prior period, unchanged from 0000320193-24-000069:mdna:16]

[0000320193-24-000081:mdna:21]
Americas net sales increased during the third quarter of 2024 compared to the third quarter of 2023 due primarily to higher net sales of Services and iPad. Year-over-year Americas net sales increased during the first nine months of 2024 due primarily to higher net sales of Services, partially offset by lower net sales of iPhone and Wearables, Home and Accessories. The strength in foreign currencies relative to the U.S. dollar had a net favorable year-over-year impact on Americas net sales during the first nine months of 2024.

[0000320193-24-000081:mdna:22]
[same as prior period, unchanged from 0000320193-24-000069:mdna:18]

[0000320193-24-000081:mdna:23]
Europe net sales increased during the third quarter of 2024 compared to the third quarter of 2023 due primarily to higher net sales of Services and iPad. The weakness in foreign currencies relative to the U.S. dollar had a net unfavorable year-over-year impact on Europe net sales during the third quarter of 2024. Year-over-year Europe net sales increased during the first nine months of 2024 due primarily to higher net sales of Services and iPhone, partially offset by lower net sales of Wearables, Home and Accessories.

[0000320193-24-000081:mdna:24]
[same as prior period, unchanged from 0000320193-24-000069:mdna:20]

[0000320193-24-000081:mdna:25]
Greater China net sales decreased during the third quarter of 2024 compared to the third quarter of 2023 due primarily to lower net sales of iPhone. Year-over-year Greater China net sales decreased during the first nine months of 2024 due primarily to lower net sales of iPhone and iPad. The weakness in the renminbi relative to the U.S. dollar had an unfavorable year-over-year impact on Greater China net sales during the third quarter and first nine months of 2024.

[0000320193-24-000081:mdna:26]
[same as prior period, unchanged from 0000320193-24-000069:mdna:22]

[0000320193-24-000081:mdna:27]
Japan net sales increased during the third quarter of 2024 compared to the third quarter of 2023 due primarily to higher net sales of iPhone and iPad. Year-over-year Japan net sales increased during the first nine months of 2024 due primarily to higher net sales of iPhone, partially offset by lower net sales of Wearables, Home and Accessories. The weakness in the yen relative to the U.S. dollar had an unfavorable year-over-year impact on Japan net sales during the third quarter and first nine months of 2024.

[0000320193-24-000081:mdna:28]
[same as prior period, unchanged from 0000320193-24-000069:mdna:24]

[0000320193-24-000081:mdna:29]
Rest of Asia Pacific net sales increased during the third quarter of 2024 compared to the third quarter of 2023 due primarily to higher net sales of Services, iPhone and iPad. Year-over-year Rest of Asia Pacific net sales were relatively flat during the first nine months of 2024. The weakness in foreign currencies relative to the U.S. dollar had a net unfavorable year-over-year impact on Rest of Asia Pacific net sales during the third quarter and first nine months of 2024.

[0000320193-24-000081:mdna:30]
[same as prior period, unchanged from 0000320193-24-000069:mdna:26]

[0000320193-24-000081:mdna:31]
The following table shows net sales by category for the three- and nine-month periods ended June 29, 2024 and July 1, 2023 (dollars in millions):

[0000320193-24-000081:mdna:32]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29,2024 |  | July 1,2023 |  | Change |  | June 29,2024 |  | July 1,2023 |  | Change |
| Net sales by category: |  |  |  |  |  |  |  |  |  |  |  |
| iPhone | $ | 39,296 |  |  | $ | 39,669 |  |  | (1) | % |  | $ | 154,961 |  |  | $ | 156,778 |  |  | (1) | % |
| Mac | 7,009 |  |  | 6,840 |  |  | 2 | % |  | 22,240 |  |  | 21,743 |  |  | 2 | % |
| iPad | 7,162 |  |  | 5,791 |  |  | 24 | % |  | 19,744 |  |  | 21,857 |  |  | (10) | % |
| Wearables, Home and Accessories | 8,097 |  |  | 8,284 |  |  | (2) | % |  | 27,963 |  |  | 30,523 |  |  | (8) | % |
| Services | 24,213 |  |  | 21,213 |  |  | 14 | % |  | 71,197 |  |  | 62,886 |  |  | 13 | % |
| Total net sales | $ | 85,777 |  |  | $ | 81,797 |  |  | 5 | % |  | $ | 296,105 |  |  | $ | 293,787 |  |  | 1 | % |

[0000320193-24-000081:mdna:33]
[same as prior period, unchanged from 0000320193-24-000069:mdna:29]

[0000320193-24-000081:mdna:34]
iPhone net sales were relatively flat during the third quarter and first nine months of 2024 compared to the same periods in 2023.

[0000320193-24-000081:mdna:35]
[same as prior period, unchanged from 0000320193-24-000069:mdna:31]

[0000320193-24-000081:mdna:36]
Mac net sales increased during the third quarter and first nine months of 2024 compared to the same periods in 2023 due to higher net sales of laptops.

[0000320193-24-000081:mdna:37]
[same as prior period, unchanged from 0000320193-24-000069:mdna:33]

[0000320193-24-000081:mdna:38]
iPad net sales increased during the third quarter of 2024 compared to the third quarter of 2023 due primarily to higher net sales of iPad Pro and iPad Air. Year-over-year iPad net sales decreased during the first nine months of 2024 due primarily to lower net sales of iPad 9th generation and iPad Pro, partially offset by higher net sales of iPad 10th generation.

[0000320193-24-000081:mdna:39]
[same as prior period, unchanged from 0000320193-24-000069:mdna:35]

[0000320193-24-000081:mdna:40]
Wearables, Home and Accessories net sales decreased during the third quarter of 2024 compared to the third quarter of 2023 due primarily to lower net sales of Wearables. Year-over-year Wearables, Home and Accessories net sales decreased during the first nine months of 2024 due primarily to lower net sales of Wearables and Accessories.

[0000320193-24-000081:mdna:41]
[same as prior period, unchanged from 0000320193-24-000069:mdna:37]

[0000320193-24-000081:mdna:42]
Services net sales increased during the third quarter and first nine months of 2024 compared to the same periods in 2023 due primarily to higher net sales from advertising, the App Store® and cloud services.

[0000320193-24-000081:mdna:43]
[same as prior period, unchanged from 0000320193-24-000069:mdna:39]

[0000320193-24-000081:mdna:44]
Products and Services gross margin and gross margin percentage for the three- and nine-month periods ended June 29, 2024 and July 1, 2023 were as follows (dollars in millions):

[0000320193-24-000081:mdna:45]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29,2024 |  | July 1,2023 |  | June 29,2024 |  | July 1,2023 |
| Gross margin: |  |  |  |  |  |  |  |
| Products | $ | 21,761 |  |  | $ | 21,448 |  |  | $ | 84,241 |  |  | $ | 84,205 |  |
| Services | 17,917 |  |  | 14,965 |  |  | 52,563 |  |  | 44,516 |  |
| Total gross margin | $ | 39,678 |  |  | $ | 36,413 |  |  | $ | 136,804 |  |  | $ | 128,721 |  |

[0000320193-24-000081:mdna:46]
| Gross margin percentage: |  |  |  |  |  |  |  |
| Products | 35.3 | % |  | 35.4 | % |  | 37.5 | % |  | 36.5 | % |
| Services | 74.0 | % |  | 70.5 | % |  | 73.8 | % |  | 70.8 | % |
| Total gross margin percentage | 46.3 | % |  | 44.5 | % |  | 46.2 | % |  | 43.8 | % |

[0000320193-24-000081:mdna:47]
[same as prior period, unchanged from 0000320193-24-000069:mdna:43]

[0000320193-24-000081:mdna:48]
Products gross margin was relatively flat during the third quarter and first nine months of 2024 compared to the same periods in 2023.

[0000320193-24-000081:mdna:49]
Products gross margin percentage was relatively flat during the third quarter of 2024 compared to the third quarter of 2023. Year-over-year Products gross margin percentage increased during the first nine months of 2024 due primarily to cost savings, partially offset by a different Products mix and the weakness in foreign currencies relative to the U.S. dollar.

[0000320193-24-000081:mdna:50]
[same as prior period, unchanged from 0000320193-24-000069:mdna:46]

[0000320193-24-000081:mdna:51]
Services gross margin increased during the third quarter and first nine months of 2024 compared to the same periods in 2023 due primarily to higher Services net sales.

[0000320193-24-000081:mdna:52]
Services gross margin percentage increased during the third quarter and first nine months of 2024 compared to the same periods in 2023 due primarily to a different Services mix.

[0000320193-24-000081:mdna:53]
The Company’s future gross margins can be impacted by a variety of factors, as discussed in Part I, Item 1A of the 2023 Form 10-K and Part II, Item 1A of this Form 10-Q, in each case under the heading “Risk Factors.” As a result, the Company believes, in general, gross margins will be subject to volatility and downward pressure.

[0000320193-24-000081:mdna:54]
[same as prior period, unchanged from 0000320193-24-000069:mdna:49]

[0000320193-24-000081:mdna:55]
Operating expenses for the three- and nine-month periods ended June 29, 2024 and July 1, 2023 were as follows (dollars in millions):

[0000320193-24-000081:mdna:56]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29,2024 |  | July 1,2023 |  | June 29,2024 |  | July 1,2023 |
| Research and development | $ | 8,006 |  |  | $ | 7,442 |  |  | $ | 23,605 |  |  | $ | 22,608 |  |
| Percentage of total net sales | 9 | % |  | 9 | % |  | 8 | % |  | 8 | % |
| Selling, general and administrative | $ | 6,320 |  |  | $ | 5,973 |  |  | $ | 19,574 |  |  | $ | 18,781 |  |
| Percentage of total net sales | 7 | % |  | 7 | % |  | 7 | % |  | 6 | % |
| Total operating expenses | $ | 14,326 |  |  | $ | 13,415 |  |  | $ | 43,179 |  |  | $ | 41,389 |  |
| Percentage of total net sales | 17 | % |  | 16 | % |  | 15 | % |  | 14 | % |

[0000320193-24-000081:mdna:57]
[same as prior period, unchanged from 0000320193-24-000069:mdna:52]

[0000320193-24-000081:mdna:58]
The growth in research and development (“R&D”) expense during the third quarter and first nine months of 2024 compared to the same periods in 2023 was driven primarily by increases in headcount-related expenses.

[0000320193-24-000081:mdna:59]
[same as prior period, unchanged from 0000320193-24-000069:mdna:54]

[0000320193-24-000081:mdna:60]
Selling, general and administrative expense increased $347 million during the third quarter of 2024 and $793 million during the first nine months of 2024 compared to the same periods in 2023.

[0000320193-24-000081:mdna:61]
[same as prior period, unchanged from 0000320193-24-000069:mdna:56]

[0000320193-24-000081:mdna:62]
Provision for income taxes, effective tax rate and statutory federal income tax rate for the three- and nine-month periods ended June 29, 2024 and July 1, 2023 were as follows (dollars in millions):

[0000320193-24-000081:mdna:63]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29,2024 |  | July 1,2023 |  | June 29,2024 |  | July 1,2023 |
| Provision for income taxes | $ | 4,046 |  |  | $ | 2,852 |  |  | $ | 14,875 |  |  | $ | 12,699 |  |
| Effective tax rate | 15.9 | % |  | 12.5 | % |  | 15.8 | % |  | 14.6 | % |
| Statutory federal income tax rate | 21 | % |  | 21 | % |  | 21 | % |  | 21 | % |

[0000320193-24-000081:mdna:64]
The Company’s effective tax rate for the third quarter and first nine months of 2024 was lower than the statutory federal income tax rate due primarily to a lower effective tax rate on foreign earnings, the impact of the U.S. federal R&D credit, and tax benefits from share-based compensation, partially offset by state income taxes.

[0000320193-24-000081:mdna:65]
The Company’s effective tax rate for the third quarter and first nine months of 2024 was higher compared to the same periods in 2023 due primarily to a higher effective tax rate on foreign earnings and lower tax benefits from share-based compensation, partially offset by lower state income taxes.

[0000320193-24-000081:mdna:66]
[same as prior period, unchanged from 0000320193-24-000069:mdna:61]

[0000320193-24-000081:mdna:67]
[same as prior period, unchanged from 0000320193-24-000069:mdna:62]

[0000320193-24-000081:mdna:68]
[same as prior period, unchanged from 0000320193-24-000069:mdna:63]

[0000320193-24-000081:mdna:69]
[same as prior period, unchanged from 0000320193-24-000069:mdna:64]

[0000320193-24-000081:mdna:70]
The Company utilizes several outsourcing partners to manufacture subassemblies for the Company’s products and to perform final assembly and testing of finished products. The Company also obtains individual components for its products from a wide variety of individual suppliers. As of June 29, 2024, the Company had manufacturing purchase obligations of $38.4 billion, with $38.3 billion payable within 12 months.

[0000320193-24-000081:mdna:71]
[same as prior period, unchanged from 0000320193-24-000069:mdna:66]

[0000320193-24-000081:mdna:72]
In addition to its contractual cash requirements, the Company has authorized share repurchase programs. The programs do not obligate the Company to acquire a minimum amount of shares. As of June 29, 2024, the Company’s quarterly cash dividend was $0.25 per share. The Company intends to increase its dividend on an annual basis, subject to declaration by the Board of Directors.

[0000320193-24-000081:mdna:73]
During the third quarter of 2024, the Company repurchased $26.0 billion of its common stock and paid dividends and dividend equivalents of $3.9 billion.

[0000320193-24-000081:mdna:74]
[same as prior period, unchanged from 0000320193-24-000069:mdna:70]

[0000320193-24-000081:mdna:75]
[same as prior period, unchanged from 0000320193-24-000069:mdna:71]

[0000320193-24-000081:mdna:76]
In December 2023, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) No. 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures (“ASU 2023-09”), which will require the Company to disclose specified additional information in its income tax rate reconciliation and provide additional information for reconciling items that meet a quantitative threshold. ASU 2023-09 will also require the Company to disaggregate its income taxes paid disclosure by federal, state and foreign taxes, with further disaggregation required for significant individual jurisdictions. The Company will adopt ASU 2023-09 in its fourth quarter of 2026 using a prospective transition method.

[0000320193-24-000081:mdna:77]
[same as prior period, unchanged from 0000320193-24-000069:mdna:73]

[0000320193-24-000081:mdna:78]
In November 2023, the FASB issued ASU No. 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures (“ASU 2023-07”), which will require the Company to disclose segment expenses that are significant and regularly provided to the Company’s chief operating decision maker (“CODM”). In addition, ASU 2023-07 will require the Company to disclose the title and position of its CODM and how the CODM uses segment profit or loss information in assessing segment performance and deciding how to allocate resources. The Company will adopt ASU 2023-07 in its fourth quarter of 2025 using a retrospective transition method.

[0000320193-24-000081:mdna:79]
[same as prior period, unchanged from 0000320193-24-000069:mdna:75]

[0000320193-24-000081:mdna:80]
[same as prior period, unchanged from 0000320193-24-000069:mdna:76]
