# AAPL note change history — 0000320193-24-000069 → 0000320193-24-000081


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-08-02):
[0000320193-24-000081:note_history:1]
The Company issues unsecured short-term promissory notes pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of June 29, 2024 and September 30, 2023, the Company had $3.0 billion and $6.0 billion of commercial paper outstanding, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of commercial paper for the nine months ended June 29, 2024 and July 1, 2023 (in millions):
  (was, 2024-05-03, similarity 0.9257):
[0000320193-24-000069:note_history:1]
The Company issues unsecured short-term promissory notes pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of March 30, 2024 and September 30, 2023, the Company had $2.0 billion and $6.0 billion of commercial paper outstanding, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of commercial paper for the six months ended March 30, 2024 and April 1, 2023 (in millions):

- added (2024-08-02):
[0000320193-24-000081:note_history:2]
|  | Nine Months Ended |
|  | June 29,2024 |  | July 1,2023 |
| Maturities 90 days or less: |  |  |  |
| Repayments of commercial paper, net | $ | (2,985) |  |  | $ | (3,326) |  |
| Maturities greater than 90 days: |  |  |  |
| Repayments of commercial paper | — |  |  | (2,645) |  |
| Total repayments of commercial paper, net | $ | (2,985) |  |  | $ | (5,971) |  |

- changed (2024-08-02):
[0000320193-24-000081:note_history:3]
As of June 29, 2024 and September 30, 2023, the Company had outstanding fixed-rate notes with varying maturities for an aggregate carrying amount of $98.3 billion and $105.1 billion, respectively (collectively the “Notes”). As of June 29, 2024 and September 30, 2023, the fair value of the Company’s Notes, based on Level 2 inputs, was $86.2 billion and $90.8 billion, respectively.
  (was, 2024-05-03, similarity 0.9741):
[0000320193-24-000069:note_history:3]
As of March 30, 2024 and September 30, 2023, the Company had outstanding fixed-rate notes with varying maturities for an aggregate carrying amount of $102.6 billion and $105.1 billion, respectively (collectively the “Notes”). As of March 30, 2024 and September 30, 2023, the fair value of the Company’s Notes, based on Level 2 inputs, was $91.6 billion and $90.8 billion, respectively.

- removed (2024-08-02):
[0000320193-24-000069:note_history:4]
|  | Six Months Ended |
|  | March 30,2024 |  | April 1,2023 |
| Maturities 90 days or less: |  |  |  |
| Repayments of commercial paper, net | $ | (3,982) |  |  | $ | (5,315) |  |
| Maturities greater than 90 days: |  |  |  |
| Repayments of commercial paper | — |  |  | (2,645) |  |
| Total repayments of commercial paper, net | $ | (3,982) |  |  | $ | (7,960) |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-08-02):
[0000320193-24-000081:note_history:5]
Net sales disaggregated by significant products and services for the three- and nine-month periods ended June 29, 2024 and July 1, 2023 were as follows (in millions):
  (was, 2024-05-03, similarity 0.9333):
[0000320193-24-000069:note_history:5]
Net sales disaggregated by significant products and services for the three- and six-month periods ended March 30, 2024 and April 1, 2023 were as follows (in millions):

- changed (2024-08-02):
[0000320193-24-000081:note_history:6]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29,2024 |  | July 1,2023 |  | June 29,2024 |  | July 1,2023 |
| iPhone® | $ | 39,296 |  |  | $ | 39,669 |  |  | $ | 154,961 |  |  | $ | 156,778 |  |
| Mac® | 7,009 |  |  | 6,840 |  |  | 22,240 |  |  | 21,743 |  |
| iPad® | 7,162 |  |  | 5,791 |  |  | 19,744 |  |  | 21,857 |  |
| Wearables, Home and Accessories | 8,097 |  |  | 8,284 |  |  | 27,963 |  |  | 30,523 |  |
| Services | 24,213 |  |  | 21,213 |  |  | 71,197 |  |  | 62,886 |  |
| Total net sales | $ | 85,777 |  |  | $ | 81,797 |  |  | $ | 296,105 |  |  | $ | 293,787 |  |
  (was, 2024-05-03, similarity 0.8508):
[0000320193-24-000069:note_history:6]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30,2024 |  | April 1,2023 |  | March 30,2024 |  | April 1,2023 |
| iPhone® | $ | 45,963 |  |  | $ | 51,334 |  |  | $ | 115,665 |  |  | $ | 117,109 |  |
| Mac® | 7,451 |  |  | 7,168 |  |  | 15,231 |  |  | 14,903 |  |
| iPad® | 5,559 |  |  | 6,670 |  |  | 12,582 |  |  | 16,066 |  |
| Wearables, Home and Accessories | 7,913 |  |  | 8,757 |  |  | 19,866 |  |  | 22,239 |  |
| Services | 23,867 |  |  | 20,907 |  |  | 46,984 |  |  | 41,673 |  |
| Total net sales | $ | 90,753 |  |  | $ | 94,836 |  |  | $ | 210,328 |  |  | $ | 211,990 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-08-02):
[0000320193-24-000081:note_history:7]
Revenue
Net sales disaggregated by significant products and services for the three- and nine-month periods ended June 29, 2024 and July 1, 2023 were as follows (in millions):
  (was, 2024-05-03, similarity 0.9366):
[0000320193-24-000069:note_history:7]
Revenue
Net sales disaggregated by significant products and services for the three- and six-month periods ended March 30, 2024 and April 1, 2023 were as follows (in millions):

- changed (2024-08-02):
[0000320193-24-000081:note_history:8]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29,2024 |  | July 1,2023 |  | June 29,2024 |  | July 1,2023 |
| iPhone® | $ | 39,296 |  |  | $ | 39,669 |  |  | $ | 154,961 |  |  | $ | 156,778 |  |
| Mac® | 7,009 |  |  | 6,840 |  |  | 22,240 |  |  | 21,743 |  |
| iPad® | 7,162 |  |  | 5,791 |  |  | 19,744 |  |  | 21,857 |  |
| Wearables, Home and Accessories | 8,097 |  |  | 8,284 |  |  | 27,963 |  |  | 30,523 |  |
| Services | 24,213 |  |  | 21,213 |  |  | 71,197 |  |  | 62,886 |  |
| Total net sales | $ | 85,777 |  |  | $ | 81,797 |  |  | $ | 296,105 |  |  | $ | 293,787 |  |
  (was, 2024-05-03, similarity 0.8508):
[0000320193-24-000069:note_history:8]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30,2024 |  | April 1,2023 |  | March 30,2024 |  | April 1,2023 |
| iPhone® | $ | 45,963 |  |  | $ | 51,334 |  |  | $ | 115,665 |  |  | $ | 117,109 |  |
| Mac® | 7,451 |  |  | 7,168 |  |  | 15,231 |  |  | 14,903 |  |
| iPad® | 5,559 |  |  | 6,670 |  |  | 12,582 |  |  | 16,066 |  |
| Wearables, Home and Accessories | 7,913 |  |  | 8,757 |  |  | 19,866 |  |  | 22,239 |  |
| Services | 23,867 |  |  | 20,907 |  |  | 46,984 |  |  | 41,673 |  |
| Total net sales | $ | 90,753 |  |  | $ | 94,836 |  |  | $ | 210,328 |  |  | $ | 211,990 |  |

- changed (2024-08-02):
[0000320193-24-000081:note_history:9]
Total net sales include $3.4 billion of revenue recognized in the three months ended June 29, 2024 that was included in deferred revenue as of March 30, 2024, $3.3 billion of revenue recognized in the three months ended July 1, 2023 that was included in deferred revenue as of April 1, 2023, $6.5 billion of revenue recognized in the nine months ended June 29, 2024 that was included in deferred revenue as of September 30, 2023, and $7.0 billion of revenue recognized in the nine months ended July 1, 2023 that was included in deferred revenue as of September 24, 2022.
  (was, 2024-05-03, similarity 0.6648):
[0000320193-24-000069:note_history:9]
Total net sales include $3.3 billion of revenue recognized in the three months ended March 30, 2024 that was included in deferred revenue as of December 30, 2023, $3.5 billion of revenue recognized in the three months ended April 1, 2023 that was included in deferred revenue as of December 31, 2022, $5.1 billion of revenue recognized in the six months ended March 30, 2024 that was included in deferred revenue as of September 30, 2023, and $5.5 billion of revenue recognized in the six months ended April 1, 2023 that was included in deferred revenue as of September 24, 2022.

- changed (2024-08-02):
[0000320193-24-000081:note_history:10]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 11, “Segment Information and Geographic Data” for the three- and nine-month periods ended June 29, 2024 and July 1, 2023, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.
  (was, 2024-05-03, similarity 0.7278):
[0000320193-24-000069:note_history:10]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 10, “Segment Information and Geographic Data” for the three- and six-month periods ended March 30, 2024 and April 1, 2023, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.

- added (2024-08-02):
[0000320193-24-000081:note_history:11]
As of June 29, 2024 and September 30, 2023, the Company had total deferred revenue of $12.5 billion and $12.1 billion, respectively. As of June 29, 2024, the Company expects 64% of total deferred revenue to be realized in less than a year, 25% within one-to-two years, 9% within two-to-three years and 2% in greater than three years.

- removed (2024-08-02):
[0000320193-24-000069:note_history:12]
As of March 30, 2024 and September 30, 2023, the Company had total deferred revenue of $12.6 billion and $12.1 billion, respectively. As of March 30, 2024, the Company expects 64% of total deferred revenue to be realized in less than a year, 26% within one-to-two years, 9% within two-to-three years and 1% in greater than three years.
