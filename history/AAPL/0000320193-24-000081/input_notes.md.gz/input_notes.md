# AAPL notes — 0000320193-24-000081


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000320193-24-000081:notes:1]
[same as prior period, unchanged from 0000320193-24-000069:notes:1]

[0000320193-24-000081:notes:2]
[same as prior period, unchanged from 0000320193-24-000069:notes:2]

[0000320193-24-000081:notes:3]
[same as prior period, unchanged from 0000320193-24-000069:notes:3]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000320193-24-000081:notes:4]
Revenue
Net sales disaggregated by significant products and services for the three- and nine-month periods ended June 29, 2024 and July 1, 2023 were as follows (in millions):

[0000320193-24-000081:notes:5]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29,2024 |  | July 1,2023 |  | June 29,2024 |  | July 1,2023 |
| iPhone® | $ | 39,296 |  |  | $ | 39,669 |  |  | $ | 154,961 |  |  | $ | 156,778 |  |
| Mac® | 7,009 |  |  | 6,840 |  |  | 22,240 |  |  | 21,743 |  |
| iPad® | 7,162 |  |  | 5,791 |  |  | 19,744 |  |  | 21,857 |  |
| Wearables, Home and Accessories | 8,097 |  |  | 8,284 |  |  | 27,963 |  |  | 30,523 |  |
| Services | 24,213 |  |  | 21,213 |  |  | 71,197 |  |  | 62,886 |  |
| Total net sales | $ | 85,777 |  |  | $ | 81,797 |  |  | $ | 296,105 |  |  | $ | 293,787 |  |

[0000320193-24-000081:notes:6]
Total net sales include $3.4 billion of revenue recognized in the three months ended June 29, 2024 that was included in deferred revenue as of March 30, 2024, $3.3 billion of revenue recognized in the three months ended July 1, 2023 that was included in deferred revenue as of April 1, 2023, $6.5 billion of revenue recognized in the nine months ended June 29, 2024 that was included in deferred revenue as of September 30, 2023, and $7.0 billion of revenue recognized in the nine months ended July 1, 2023 that was included in deferred revenue as of September 24, 2022.

[0000320193-24-000081:notes:7]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 11, “Segment Information and Geographic Data” for the three- and nine-month periods ended June 29, 2024 and July 1, 2023, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.

[0000320193-24-000081:notes:8]
As of June 29, 2024 and September 30, 2023, the Company had total deferred revenue of $12.5 billion and $12.1 billion, respectively. As of June 29, 2024, the Company expects 64% of total deferred revenue to be realized in less than a year, 25% within one-to-two years, 9% within two-to-three years and 2% in greater than three years.


## us-gaap:EarningsPerShareTextBlock

[0000320193-24-000081:notes:9]
Earnings Per Share
The following table shows the computation of basic and diluted earnings per share for the three- and nine-month periods ended June 29, 2024 and July 1, 2023 (net income in millions and shares in thousands):

[0000320193-24-000081:notes:10]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29,2024 |  | July 1,2023 |  | June 29,2024 |  | July 1,2023 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 21,448 |  |  | $ | 19,881 |  |  | $ | 79,000 |  |  | $ | 74,039 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 15,287,521 |  |  | 15,697,614 |  |  | 15,401,047 |  |  | 15,792,497 |  |
| Effect of dilutive share-based awards | 60,654 |  |  | 77,407 |  |  | 62,128 |  |  | 66,766 |  |
| Weighted-average diluted shares | 15,348,175 |  |  | 15,775,021 |  |  | 15,463,175 |  |  | 15,859,263 |  |
| Basic earnings per share | $ | 1.40 |  |  | $ | 1.27 |  |  | $ | 5.13 |  |  | $ | 4.69 |  |
| Diluted earnings per share | $ | 1.40 |  |  | $ | 1.26 |  |  | $ | 5.11 |  |  | $ | 4.67 |  |

[0000320193-24-000081:notes:11]
Approximately 32 million restricted stock units (“RSUs”) were excluded from the computation of diluted earnings per share for the nine months ended July 1, 2023 because their effect would have been antidilutive.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000320193-24-000081:notes:12]
[same as prior period, unchanged from 0000320193-24-000069:notes:12]

[0000320193-24-000081:notes:13]
The following tables show the Company’s cash, cash equivalents and marketable securities by significant investment category as of June 29, 2024 and September 30, 2023 (in millions):

[0000320193-24-000081:notes:14]
|  | June 29, 2024 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | CurrentMarketableSecurities |  | Non-CurrentMarketableSecurities |
| Cash | $ | 22,866 |  |  | $ | — |  |  | $ | — |  |  | $ | 22,866 |  |  | $ | 22,866 |  |  | $ | — |  |  | $ | — |  |
| Level 1: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 1,648 |  |  | — |  |  | — |  |  | 1,648 |  |  | 1,648 |  |  | — |  |  | — |  |
| Mutual funds | 493 |  |  | 76 |  |  | (7) |  |  | 562 |  |  | — |  |  | 562 |  |  | — |  |
| Subtotal | 2,141 |  |  | 76 |  |  | (7) |  |  | 2,210 |  |  | 1,648 |  |  | 562 |  |  | — |  |
| Level 2 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 16,298 |  |  | 3 |  |  | (855) |  |  | 15,446 |  |  | 138 |  |  | 4,649 |  |  | 10,659 |  |
| U.S. agency securities | 5,500 |  |  | — |  |  | (418) |  |  | 5,082 |  |  | 73 |  |  | 518 |  |  | 4,491 |  |
| Non-U.S. government securities | 17,560 |  |  | 31 |  |  | (680) |  |  | 16,911 |  |  | — |  |  | 11,592 |  |  | 5,319 |  |
| Certificates of deposit and time deposits | 1,337 |  |  | — |  |  | — |  |  | 1,337 |  |  | 838 |  |  | 492 |  |  | 7 |  |
| Commercial paper | 1,346 |  |  | — |  |  | — |  |  | 1,346 |  |  | 2 |  |  | 1,344 |  |  | — |  |
| Corporate debt securities | 68,194 |  |  | 83 |  |  | (3,350) |  |  | 64,927 |  |  | — |  |  | 15,489 |  |  | 49,438 |  |
| Municipal securities | 480 |  |  | — |  |  | (13) |  |  | 467 |  |  | — |  |  | 197 |  |  | 270 |  |
| Mortgage- and asset-backed securities | 24,508 |  |  | 27 |  |  | (2,086) |  |  | 22,449 |  |  | — |  |  | 1,393 |  |  | 21,056 |  |
| Subtotal | 135,223 |  |  | 144 |  |  | (7,402) |  |  | 127,965 |  |  | 1,051 |  |  | 35,674 |  |  | 91,240 |  |
| Total (2) | $ | 160,230 |  |  | $ | 220 |  |  | $ | (7,409) |  |  | $ | 153,041 |  |  | $ | 25,565 |  |  | $ | 36,236 |  |  | $ | 91,240 |  |

[0000320193-24-000081:notes:15]
[same as prior period, unchanged from 0000320193-24-000069:notes:15]

[0000320193-24-000081:notes:16]
[same as prior period, unchanged from 0000320193-24-000069:notes:16]

[0000320193-24-000081:notes:17]
(2)As of June 29, 2024 and September 30, 2023, total marketable securities included $14.1 billion and $13.8 billion, respectively, that were restricted from general use, related to the State Aid Decision (refer to Note 6, “Income Taxes”) and other agreements.

[0000320193-24-000081:notes:18]
The following table shows the fair value of the Company’s non-current marketable debt securities, by contractual maturity, as of June 29, 2024 (in millions):

[0000320193-24-000081:notes:19]
| Due after 1 year through 5 years | $ | 64,209 |  |
| Due after 5 years through 10 years | 8,660 |  |
| Due after 10 years | 18,371 |  |
| Total fair value | $ | 91,240 |  |

[0000320193-24-000081:notes:20]
[same as prior period, unchanged from 0000320193-24-000069:notes:20]

[0000320193-24-000081:notes:21]
[same as prior period, unchanged from 0000320193-24-000069:notes:21]

[0000320193-24-000081:notes:22]
[same as prior period, unchanged from 0000320193-24-000069:notes:22]

[0000320193-24-000081:notes:23]
[same as prior period, unchanged from 0000320193-24-000069:notes:23]

[0000320193-24-000081:notes:24]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in foreign exchange rates, the Company may use forwards, cross-currency swaps or other instruments. The Company designates these instruments as either cash flow or fair value hedges. As of June 29, 2024, the maximum length of time over which the Company is hedging its exposure to the variability in future cash flows for term debt–related foreign currency transactions is 18 years.

[0000320193-24-000081:notes:25]
[same as prior period, unchanged from 0000320193-24-000069:notes:25]

[0000320193-24-000081:notes:26]
[same as prior period, unchanged from 0000320193-24-000069:notes:26]

[0000320193-24-000081:notes:27]
[same as prior period, unchanged from 0000320193-24-000069:notes:27]

[0000320193-24-000081:notes:28]
The notional amounts of the Company’s outstanding derivative instruments as of June 29, 2024 and September 30, 2023 were as follows (in millions):

[0000320193-24-000081:notes:29]
|  | June 29,2024 |  | September 30,2023 |
| Derivative instruments designated as accounting hedges: |  |  |  |
| Foreign exchange contracts | $ | 65,542 |  |  | $ | 74,730 |  |
| Interest rate contracts | $ | 13,875 |  |  | $ | 19,375 |  |
| Derivative instruments not designated as accounting hedges: |  |  |  |
| Foreign exchange contracts | $ | 97,136 |  |  | $ | 104,777 |  |

[0000320193-24-000081:notes:30]
The carrying amounts of the Company’s hedged items in fair value hedges as of June 29, 2024 and September 30, 2023 were as follows (in millions):

[0000320193-24-000081:notes:31]
|  | June 29,2024 |  | September 30,2023 |
| Hedged assets/(liabilities): |  |  |  |
| Current and non-current marketable securities | $ | 15,007 |  |  | $ | 14,433 |  |
| Current and non-current term debt | $ | (13,096) |  |  | $ | (18,247) |  |

[0000320193-24-000081:notes:32]
[same as prior period, unchanged from 0000320193-24-000069:notes:32]

[0000320193-24-000081:notes:33]
[same as prior period, unchanged from 0000320193-24-000069:notes:33]

[0000320193-24-000081:notes:34]
The Company’s third-party cellular network carriers accounted for 32% and 41% of total trade receivables as of June 29, 2024 and September 30, 2023, respectively. The Company requires third-party credit support or collateral from certain customers to limit credit risk.

[0000320193-24-000081:notes:35]
[same as prior period, unchanged from 0000320193-24-000069:notes:35]

[0000320193-24-000081:notes:36]
The Company has non-trade receivables from certain of its manufacturing vendors resulting from the sale of components to these vendors who manufacture subassemblies or assemble final products for the Company. The Company purchases these components directly from suppliers. The Company does not reflect the sale of these components in products net sales. Rather, the Company recognizes any gain on these sales as a reduction of products cost of sales when the related final products are sold by the Company. As of June 29, 2024, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 46% and 18%. As of September 30, 2023, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 48% and 23%.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000320193-24-000081:notes:37]
Condensed Consolidated Financial Statement Details
The following table shows the Company’s condensed consolidated financial statement details as of June 29, 2024 and September 30, 2023 (in millions):

[0000320193-24-000081:notes:38]
[same as prior period, unchanged from 0000320193-24-000069:notes:38]

[0000320193-24-000081:notes:39]
|  | June 29,2024 |  | September 30,2023 |
| Gross property, plant and equipment | $ | 117,129 |  |  | $ | 114,599 |  |
| Accumulated depreciation | (72,627) |  |  | (70,884) |  |
| Total property, plant and equipment, net | $ | 44,502 |  |  | $ | 43,715 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000320193-24-000081:notes:40]
Income Taxes
European Commission State Aid Decision

[0000320193-24-000081:notes:41]
On August 30, 2016, the European Commission (the “Commission”) announced its decision that Ireland granted state aid to the Company by providing tax opinions in 1991 and 2007 concerning the tax allocation of profits of the Irish branches of two subsidiaries of the Company (the “State Aid Decision”). The State Aid Decision ordered Ireland to calculate and recover additional taxes from the Company for the period June 2003 through December 2014. Irish legislative changes, effective as of January 2015, eliminated the application of the tax opinions from that date forward. The Company and Ireland appealed the State Aid Decision to the General Court of the Court of Justice of the European Union (the “General Court”). On July 15, 2020, the General Court annulled the State Aid Decision. On September 25, 2020, the Commission appealed the General Court’s decision to the European Court of Justice (the “ECJ”) and a hearing was held on May 23, 2023. A decision from the ECJ is expected in the fourth quarter of 2024. The Company believes it would be eligible to claim a U.S. foreign tax credit for a portion of any incremental Irish corporate income taxes potentially due related to the State Aid Decision.


## us-gaap:DebtDisclosureTextBlock

[0000320193-24-000081:notes:42]
Debt
Commercial Paper

[0000320193-24-000081:notes:43]
The Company issues unsecured short-term promissory notes pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of June 29, 2024 and September 30, 2023, the Company had $3.0 billion and $6.0 billion of commercial paper outstanding, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of commercial paper for the nine months ended June 29, 2024 and July 1, 2023 (in millions):

[0000320193-24-000081:notes:44]
|  | Nine Months Ended |
|  | June 29,2024 |  | July 1,2023 |
| Maturities 90 days or less: |  |  |  |
| Repayments of commercial paper, net | $ | (2,985) |  |  | $ | (3,326) |  |
| Maturities greater than 90 days: |  |  |  |
| Repayments of commercial paper | — |  |  | (2,645) |  |
| Total repayments of commercial paper, net | $ | (2,985) |  |  | $ | (5,971) |  |

[0000320193-24-000081:notes:45]
Term Debt

[0000320193-24-000081:notes:46]
As of June 29, 2024 and September 30, 2023, the Company had outstanding fixed-rate notes with varying maturities for an aggregate carrying amount of $98.3 billion and $105.1 billion, respectively (collectively the “Notes”). As of June 29, 2024 and September 30, 2023, the fair value of the Company’s Notes, based on Level 2 inputs, was $86.2 billion and $90.8 billion, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000320193-24-000081:notes:47]
[same as prior period, unchanged from 0000320193-24-000069:notes:45]

[0000320193-24-000081:notes:48]
During the nine months ended June 29, 2024, the Company repurchased 387 million shares of its common stock for $70.0 billion. The Company’s share repurchase programs do not obligate the Company to acquire a minimum amount of shares. Under the programs, shares may be repurchased in privately negotiated or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000320193-24-000081:notes:49]
[same as prior period, unchanged from 0000320193-24-000069:notes:47]

[0000320193-24-000081:notes:50]
A summary of the Company’s RSU activity and related information for the nine months ended June 29, 2024 is as follows:

[0000320193-24-000081:notes:51]
|  | Number ofRSUs(in thousands) |  | Weighted-AverageGrant Date FairValue Per RSU |  | AggregateFair Value(in millions) |
| Balance as of September 30, 2023 | 180,247 |  |  | $ | 135.91 |  |  |  |
| RSUs granted | 78,276 |  |  | $ | 172.26 |  |  |  |
| RSUs vested | (83,842) |  |  | $ | 126.47 |  |  |  |
| RSUs canceled | (8,258) |  |  | $ | 137.85 |  |  |  |
| Balance as of June 29, 2024 | 166,423 |  |  | $ | 157.66 |  |  | $ | 35,052 |  |

[0000320193-24-000081:notes:52]
The fair value as of the respective vesting dates of RSUs was $6.4 billion and $15.0 billion for the three- and nine-month periods ended June 29, 2024, respectively, and was $7.0 billion and $14.9 billion for the three- and nine-month periods ended July 1, 2023, respectively.

[0000320193-24-000081:notes:53]
[same as prior period, unchanged from 0000320193-24-000069:notes:51]

[0000320193-24-000081:notes:54]
The following table shows share-based compensation expense and the related income tax benefit included in the Condensed Consolidated Statements of Operations for the three- and nine-month periods ended June 29, 2024 and July 1, 2023 (in millions):

[0000320193-24-000081:notes:55]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29,2024 |  | July 1,2023 |  | June 29,2024 |  | July 1,2023 |
| Share-based compensation expense | $ | 2,869 |  |  | $ | 2,617 |  |  | $ | 8,830 |  |  | $ | 8,208 |  |
| Income tax benefit related to share-based compensation expense | $ | (764) |  |  | $ | (993) |  |  | $ | (2,662) |  |  | $ | (2,791) |  |

[0000320193-24-000081:notes:56]
As of June 29, 2024, the total unrecognized compensation cost related to outstanding RSUs was $21.9 billion, which the Company expects to recognize over a weighted-average period of 2.6 years.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000320193-24-000081:notes:57]
Segment Information and Geographic Data
The following table shows information by reportable segment for the three- and nine-month periods ended June 29, 2024 and July 1, 2023 (in millions):

[0000320193-24-000081:notes:58]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29,2024 |  | July 1,2023 |  | June 29,2024 |  | July 1,2023 |
| Americas: |  |  |  |  |  |  |  |
| Net sales | $ | 37,678 |  |  | $ | 35,383 |  |  | $ | 125,381 |  |  | $ | 122,445 |  |
| Operating income | $ | 15,209 |  |  | $ | 13,117 |  |  | $ | 50,640 |  |  | $ | 44,908 |  |
| Europe: |  |  |  |  |  |  |  |
| Net sales | $ | 21,884 |  |  | $ | 20,205 |  |  | $ | 76,404 |  |  | $ | 71,831 |  |
| Operating income | $ | 9,170 |  |  | $ | 7,995 |  |  | $ | 31,872 |  |  | $ | 27,380 |  |
| Greater China: |  |  |  |  |  |  |  |
| Net sales | $ | 14,728 |  |  | $ | 15,758 |  |  | $ | 51,919 |  |  | $ | 57,475 |  |
| Operating income | $ | 5,562 |  |  | $ | 6,207 |  |  | $ | 20,884 |  |  | $ | 24,175 |  |
| Japan: |  |  |  |  |  |  |  |
| Net sales | $ | 5,097 |  |  | $ | 4,821 |  |  | $ | 19,126 |  |  | $ | 18,752 |  |
| Operating income | $ | 2,544 |  |  | $ | 2,443 |  |  | $ | 9,498 |  |  | $ | 9,073 |  |
| Rest of Asia Pacific: |  |  |  |  |  |  |  |
| Net sales | $ | 6,390 |  |  | $ | 5,630 |  |  | $ | 23,275 |  |  | $ | 23,284 |  |
| Operating income | $ | 2,610 |  |  | $ | 2,328 |  |  | $ | 9,995 |  |  | $ | 9,447 |  |

[0000320193-24-000081:notes:59]
A reconciliation of the Company’s segment operating income to the Condensed Consolidated Statements of Operations for the three- and nine-month periods ended June 29, 2024 and July 1, 2023 is as follows (in millions):

[0000320193-24-000081:notes:60]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29,2024 |  | July 1,2023 |  | June 29,2024 |  | July 1,2023 |
| Segment operating income | $ | 35,095 |  |  | $ | 32,090 |  |  | $ | 122,889 |  |  | $ | 114,983 |  |
| Research and development expense | (8,006) |  |  | (7,442) |  |  | (23,605) |  |  | (22,608) |  |
| Other corporate expenses, net | (1,737) |  |  | (1,650) |  |  | (5,659) |  |  | (5,043) |  |
| Total operating income | $ | 25,352 |  |  | $ | 22,998 |  |  | $ | 93,625 |  |  | $ | 87,332 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0000320193-24-000081:notes:61]
On May 24, 2024, Tim Cook, the Company’s Chief Executive Officer, entered into a trading plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act. The plan provides for the sale, subject to certain price limits, of shares vesting during the duration of the plan pursuant to certain equity awards granted to Mr. Cook, excluding shares withheld by the Company to satisfy income tax withholding and remittance obligations. Mr. Cook’s plan will expire on May 24, 2026, subject to early termination in accordance with the terms of the plan.
