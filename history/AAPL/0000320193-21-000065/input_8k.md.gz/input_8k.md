# AAPL 8-K — 0000320193-21-000063 filed 2021-07-27

## item codes, every 8-K on or before 2021-07-28

- 2021-07-27 0000320193-21-000063 — 2.02, 9.01
- 2021-04-28 0000320193-21-000055 — 2.02, 9.01
- 2021-02-24 0001193125-21-054710 — 5.07
- 2021-02-08 0001193125-21-032394 — 8.01, 9.01
- 2021-01-27 0000320193-21-000009 — 2.02, 9.01
- 2021-01-05 0001193125-21-001982 — 5.02
- 2020-10-29 0000320193-20-000094 — 2.02, 9.01
- 2020-08-20 0001193125-20-225672 — 8.01, 9.01
- 2020-08-07 0001193125-20-213158 — 5.03, 9.01
- 2020-07-30 0000320193-20-000060 — 2.02, 9.01
- 2020-05-11 0001193125-20-139112 — 8.01, 9.01
- 2020-04-30 0000320193-20-000050 — 2.02, 9.01
- 2020-02-27 0001193125-20-050884 — 5.07
- 2020-02-18 0001193125-20-039203 — 7.01, 9.01
- 2020-01-28 0000320193-20-000008 — 2.02, 9.01
- 2019-11-15 0001193125-19-292676 — 8.01, 9.01
- 2019-10-30 0000320193-19-000117 — 2.02, 9.01
- 2019-09-13 0000320193-19-000093 — 5.02
- 2019-09-11 0001193125-19-242975 — 8.01, 9.01
- 2019-07-30 0000320193-19-000073 — 2.02, 9.01
- 2019-04-30 0000320193-19-000063 — 2.02, 9.01
- 2019-03-04 0000320193-19-000032 — 5.07
- 2019-02-06 0000320193-19-000026 — 5.02
- 2019-01-29 0000320193-19-000007 — 2.02, 9.01
- 2019-01-02 0000320193-19-000002 — 2.02, 9.01
- 2018-11-01 0000320193-18-000142 — 2.02, 9.01
- 2018-07-31 0000320193-18-000098 — 2.02, 9.01
- 2018-05-08 0001193125-18-154948 — 8.01 — amendment of 0001193125-18-154515
- 2018-05-07 0001193125-18-154515 — 8.01, 9.01
- 2018-05-01 0000320193-18-000067 — 2.02, 9.01
- 2018-02-14 0001193125-18-045761 — 5.07, 9.01
- 2018-02-01 0000320193-18-000005 — 2.02, 9.01
- 2017-11-13 0001193125-17-341015 — 8.01, 9.01
- 2017-11-02 0000320193-17-000067 — 2.02, 9.01
- 2017-10-12 0001193125-17-308859 — 5.02
- 2017-09-12 0001193125-17-282809 — 8.01, 9.01
- 2017-08-18 0001193125-17-262261 — 8.01, 9.01
- 2017-08-01 0000320193-17-000006 — 2.02, 9.01
- 2017-06-20 0001193125-17-208226 — 8.01, 9.01
- 2017-05-24 0001193125-17-181867 — 8.01, 9.01
- 2017-05-11 0001193125-17-167400 — 8.01, 9.01
- 2017-05-02 0001628280-17-004663 — 2.02, 9.01
- 2017-03-03 0001193125-17-069853 — 8.01, 9.01
- 2017-03-01 0001193125-17-064019 — 5.07
- 2017-02-09 0001193125-17-036283 — 8.01, 9.01
- 2017-01-31 0001628280-17-000663 — 2.02, 9.01
- 2016-12-15 0001628280-16-022047 — 5.03, 9.01
- 2016-10-25 0001628280-16-020258 — 2.02, 9.01
- 2016-08-04 0001193125-16-672044 — 8.01, 9.01
- 2016-07-26 0001628280-16-017762 — 2.02, 9.01
- 2016-06-22 0001193125-16-628957 — 8.01, 9.01
- 2016-04-26 0001193125-16-556520 — 2.02, 9.01
- 2016-03-24 0001193125-16-516891 — 8.01, 9.01
- 2016-03-01 0001193125-16-488223 — 5.02, 5.07, 9.01
- 2016-02-23 0001193125-16-473562 — 8.01, 9.01
- 2016-01-26 0001193125-16-438421 — 2.02, 9.01
- 2015-12-22 0001193125-15-410853 — 5.03, 9.01
- 2015-12-17 0001193125-15-406279 — 5.02
- 2015-10-27 0001193125-15-354756 — 2.02, 9.01
- 2015-10-02 0001193125-15-336615 — 5.02
- 2015-09-17 0001193125-15-322466 — 8.01, 9.01
- 2015-07-31 0001193125-15-273023 — 8.01, 9.01
- 2015-07-21 0001193125-15-258464 — 2.02, 9.01
- 2015-06-10 0001193125-15-219298 — 8.01, 9.01
- 2015-05-13 0001193125-15-186064 — 8.01, 9.01
- 2015-04-27 0001193125-15-149607 — 7.01, 9.01
- 2015-04-27 0001193125-15-149590 — 2.02, 9.01
- 2015-03-13 0001104659-15-019336 — 5.07, 9.01
- 2015-02-09 0001193125-15-039270 — 8.01, 9.01
- 2015-01-28 0001193125-15-023732 — 8.01, 9.01
- 2015-01-27 0001193125-15-021857 — 2.02, 9.01
- 2014-11-10 0001193125-14-406296 — 8.01, 9.01
- 2014-10-20 0001193125-14-376361 — 2.02, 9.01
- 2014-07-23 0001193125-14-277193 — 8.01, 9.01
- 2014-07-22 0001193125-14-275598 — 2.02, 9.01
- 2014-07-17 0001193125-14-271698 — 5.02
- 2014-06-06 0001193125-14-228798 — 5.03, 9.01
- 2014-05-30 0001181431-14-021923 — 5.02
- 2014-05-06 0001193125-14-184969 — 8.01, 9.01
- 2014-04-23 0001193125-14-154883 — 7.01, 9.01
- 2014-04-23 0001193125-14-154871 — 2.02, 9.01
- 2014-03-05 0001193125-14-084697 — 5.02, 5.03, 5.07, 9.01
- 2014-01-27 0001193125-14-022238 — 2.02, 9.01
- 2013-10-28 0001193125-13-413498 — 2.02, 9.01
- 2013-09-23 0001181431-13-050140 — 8.01
- 2013-07-30 0001181431-13-041847 — 5.02
- 2013-07-23 0001193125-13-298914 — 2.02, 9.01
- 2013-06-21 0001193125-13-267629 — 5.02
- 2013-05-03 0001193125-13-199324 — 8.01, 9.01
- 2013-04-24 0001193125-13-170623 — 8.01, 9.01
- 2013-04-23 0001193125-13-167469 — 7.01, 9.01
- 2013-04-23 0001193125-13-167458 — 2.02, 9.01
- 2013-03-01 0001193125-13-085842 — 5.07
- 2013-01-23 0001193125-13-020783 — 2.02, 9.01
- 2012-10-25 0001193125-12-435506 — 2.02, 9.01
- 2012-07-24 0001193125-12-312355 — 2.02, 9.01
- 2012-06-28 0001181431-12-038301 — 5.02
- 2012-05-24 0001181431-12-032458 — 5.02
- 2012-04-24 0001193125-12-178928 — 2.02, 9.01
- 2012-02-27 0001193125-12-081892 — 5.07
- 2012-01-24 0001193125-12-021833 — 2.02, 9.01
- 2011-11-16 0001181431-11-056354 — 5.02
- 2011-10-18 0001193125-11-273826 — 2.02, 9.01
- 2011-10-06 0001181431-11-051976 — 8.01
- 2011-08-26 0001181431-11-047179 — 5.02
- 2011-07-19 0001193125-11-191368 — 2.02, 9.01
- 2011-06-15 0001181431-11-036782 — 5.02
- 2011-04-20 0001193125-11-103732 — 2.02, 9.01
- 2011-02-24 0001193125-11-045411 — 5.07
- 2011-01-18 0001193125-11-009392 — 2.02, 9.01
- 2011-01-18 0001181431-11-003847 — 5.02
- 2010-11-17 0001181431-10-056327 — 5.02, 5.03, 9.01
- 2010-10-18 0001193125-10-230992 — 2.02, 9.01
- 2010-07-20 0001193125-10-161807 — 2.02, 9.01
- 2010-04-20 0001193125-10-087786 — 2.02, 9.01
- 2010-03-12 0001181431-10-016054 — 5.02
- 2010-03-01 0001193125-10-044765 — 5.02, 5.07, 9.01
- 2010-01-25 0001193125-10-012096 — 2.02, 9.01
- 2009-10-19 0001193125-09-209633 — 2.02, 9.01
- 2009-08-04 0001181431-09-037492 — 5.02
- 2009-07-21 0001193125-09-152290 — 2.02, 9.01
- 2009-06-02 0001181431-09-028400 — 5.03
- 2009-04-22 0001193125-09-084599 — 2.02, 9.01
- 2009-02-27 0001181431-09-012161 — 4.01
- 2009-01-21 0001193125-09-009009 — 2.02, 9.01
- 2009-01-16 0001181431-09-003017 — 5.02
- 2008-10-21 0001193125-08-213642 — 2.02, 9.01
- 2008-08-26 0001181431-08-050059 — 5.03
- 2008-07-21 0001193125-08-154381 — 2.02, 9.01
- 2008-06-09 0001181431-08-037620 — 8.01
- 2008-04-23 0001193125-08-088001 — 2.02, 9.01
- 2008-01-22 0001193125-08-009715 — 2.02, 9.01
- 2008-01-15 0001181431-08-003342 — 2.02, 8.01
- 2008-01-08 0001181431-08-002372 — 5.02
- 2007-10-22 0001104659-07-076142 — 2.02, 9.01
- 2007-07-25 0001104659-07-056111 — 2.02, 9.01
- 2007-05-16 0001104659-07-040672 — 5.02, 9.01
- 2007-04-25 0001104659-07-031354 — 2.02, 9.01
- 2007-04-24 0001104659-07-030938 — 8.01, 9.01
- 2007-02-21 0001104659-07-012760 — 5.03, 9.01
- 2007-01-17 0001104659-07-002905 — 2.02, 9.01
- 2007-01-10 0001104659-07-001648 — 5.03, 9.01
- 2006-10-27 0001104659-06-069015 — 8.01
- 2006-10-18 0001104659-06-067275 — 2.02, 9.01
- 2006-10-04 0001104659-06-064935 — 5.02, 8.01, 9.01
- 2006-09-01 0001104659-06-058808 — 1.01, 5.02, 5.03, 9.01
- 2006-08-11 0001104659-06-054118 — 2.02, 3.01, 9.01
- 2006-08-04 0001104659-06-051302 — 2.02, 4.02, 9.01
- 2006-07-19 0001104659-06-047739 — 2.02, 9.01
- 2006-04-21 0001181431-06-024759 — 1.01
- 2006-04-19 0001104659-06-025992 — 2.02, 9.01
- 2006-01-18 0001104659-06-002690 — 2.02, 9.01
- 2006-01-10 0001104659-06-001428 — 2.02
- 2005-12-19 0001181431-05-067468 — 1.01
- 2005-10-14 0001181431-05-056604 — 5.02
- 2005-10-11 0001104659-05-048094 — 2.02, 9.01
- 2005-08-26 0001181431-05-049163 — 1.01
- 2005-08-15 0001181431-05-046871 — 1.01
- 2005-07-13 0001104659-05-032297 — 2.02, 9.01
- 2005-06-06 0001181431-05-033177 — 8.01
- 2005-04-26 0001181431-05-023450 — 1.01
- 2005-04-13 0001104659-05-016307 — 2.02, 9.01
- 2005-03-02 0001181431-05-013840 — 3.03, 5.03
- 2005-02-11 0001104659-05-005507 — 8.01
- 2005-01-12 0001104659-05-001183 — 2.02, 9.01
- 2005-01-11 0001104659-05-001049 — 2.02
- 2004-10-13 0001104659-04-030400 — 2.02, 9.01
- 2004-07-14 0001104659-04-019574 — 12, 7
- 2004-04-14 0001104659-04-010122 — 12, 7
- 2004-01-14 0001104659-04-000896 — 12, 7
- 2003-10-15 0001104659-03-022879 — 12, 7
- 2003-07-16 0001104659-03-014913 — 7, 9
- 2003-04-16 0001047469-03-013617 — 7, 9
- 2003-03-21 0001104659-03-004649 — 5, 7
- 2002-08-13 0000912057-02-031595 — 5, 7
- 2002-08-05 0000912057-02-029692 — 5, 7
- 2000-01-24 0000912057-00-002128 — 5, 7
- 1999-09-07 0000320193-99-000010 — 2
- 1999-07-16 0000320193-99-000007 — 2
- 1998-12-23 0000320193-98-000010 — 1
- 1998-01-08 0000320193-98-000001 — 2
- 1997-09-25 0000320193-97-000019 — 2
- 1997-09-25 0000320193-97-000018 — 2
- 1997-09-05 0000320193-97-000016 — 2
- 1997-07-28 0000320193-97-000012 — 4
- 1997-04-25 0000320193-97-000009 — 5
- 1997-04-10 0000320193-97-000007 — 7
- 1996-12-24 0000320193-96-000027 — 7
- 1996-12-23 0000320193-96-000025 — 4 — amendment of 0000320193-96-000021
- 1996-12-13 0000320193-96-000021 — 4
- 1996-10-28 0000912057-96-023874 — 5, 7
- 1996-06-17 0000320193-96-000014 — 1
- 1996-04-12 0000320193-96-000006 — 1

## late-filing notifications on or before 2021-07-28

- 2006-12-15 0001104659-06-081617 — NT 10-K, for the period ended 2006-09-30
- 2006-08-11 0001104659-06-053743 — NT 10-Q, for the period ended 2006-07-01

## item 2.02 — earnings release, exhibit 99.1

[0000320193-21-000063:8k_2_02:1]
EX-99.1
2
a8-kex991q3202106262021.htm
EX-99.1

[0000320193-21-000063:8k_2_02:2]
Document

[0000320193-21-000063:8k_2_02:3]
Exhibit 99.1

[0000320193-21-000063:8k_2_02:4]
Apple Reports Third Quarter Results

[0000320193-21-000063:8k_2_02:5]
Revenue up 36 percent to new June quarter record

[0000320193-21-000063:8k_2_02:6]
Services revenue reaches new all-time high

[0000320193-21-000063:8k_2_02:7]
CUPERTINO, California — July 27, 2021 — Apple® today announced financial results for its fiscal 2021 third quarter ended June 26, 2021. The Company posted a June quarter record revenue of $81.4 billion, up 36 percent year over year, and quarterly earnings per diluted share of $1.30.

[0000320193-21-000063:8k_2_02:8]
“This quarter, our teams built on a period of unmatched innovation by sharing powerful new products with our users, at a time when using technology to connect people everywhere has never been more important,” said Tim Cook, Apple’s CEO. “We’re continuing to press forward in our work to infuse everything we make with the values that define us — by inspiring a new generation of developers to learn to code, moving closer to our 2030 environment goal, and engaging in the urgent work of building a more equitable future.”

[0000320193-21-000063:8k_2_02:9]
“Our record June quarter operating performance included new revenue records in each of our geographic segments, double-digit growth in each of our product categories, and a new all-time high for our installed base of active devices,” said Luca Maestri, Apple’s CFO. “We generated $21 billion of operating cash flow, returned nearly $29 billion to our shareholders during the quarter, and continued to make significant investments across our business to support our long term growth plans.”

[0000320193-21-000063:8k_2_02:10]
Apple’s board of directors has declared a cash dividend of $0.22 per share of the Company’s common stock. The dividend is payable on August 12, 2021 to shareholders of record as of the close of business on August 9, 2021.

[0000320193-21-000063:8k_2_02:11]
Apple will provide live streaming of its Q3 2021 financial results conference call beginning at 2:00 p.m. PT on July 27, 2021 at apple.com/investor/earnings-call. This webcast will also be available for replay for approximately two weeks thereafter.

[0000320193-21-000063:8k_2_02:12]
Apple periodically provides information for investors on its corporate website, apple.com, and its investor relations website, investor.apple.com. This includes press releases and other information about financial performance, reports filed or furnished with the SEC, information on corporate governance, and details related to its annual meeting of shareholders.

[0000320193-21-000063:8k_2_02:13]
Apple revolutionized personal technology with the introduction of the Macintosh in 1984. Today, Apple leads the world in innovation with iPhone, iPad, Mac, Apple Watch, and Apple TV. Apple’s five software platforms — iOS, iPadOS, macOS, watchOS, and tvOS — provide seamless experiences across all Apple devices and empower people with breakthrough services including the App Store, Apple Music, Apple Pay, and iCloud. Apple’s more than 100,000 employees are dedicated to making the best products on earth, and to leaving the world better than we found it.

[0000320193-21-000063:8k_2_02:14]
Press Contact:

[0000320193-21-000063:8k_2_02:15]
Josh Rosenstock

[0000320193-21-000063:8k_2_02:16]
Apple

[0000320193-21-000063:8k_2_02:17]
jrosenstock@apple.com

[0000320193-21-000063:8k_2_02:18]
(408) 862-1142

[0000320193-21-000063:8k_2_02:19]
Investor Relations Contact:

[0000320193-21-000063:8k_2_02:20]
Tejas Gala

[0000320193-21-000063:8k_2_02:21]
Apple

[0000320193-21-000063:8k_2_02:22]
tgala@apple.com

[0000320193-21-000063:8k_2_02:23]
(669) 227-2402

[0000320193-21-000063:8k_2_02:24]
NOTE TO EDITORS: For additional information visit Apple Newsroom (www.apple.com/newsroom), or call Apple’s Media Helpline at (408) 974-2042.

[0000320193-21-000063:8k_2_02:25]
© 2021 Apple Inc. All rights reserved. Apple and the Apple logo are trademarks of Apple. Other company and product names may be trademarks of their respective owners.

[0000320193-21-000063:8k_2_02:26]
Apple Inc.

[0000320193-21-000063:8k_2_02:27]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS (Unaudited)

[0000320193-21-000063:8k_2_02:28]
(In millions, except number of shares which are reflected in thousands and per share amounts)

[0000320193-21-000063:8k_2_02:29]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2021 |  | June 27,2020 |  | June 26,2021 |  | June 27,2020 |
| Net sales: |  |  |  |  |  |  |  |
| Products | $ | 63,948 |  |  | $ | 46,529 |  |  | $ | 232,309 |  |  | $ | 170,598 |  |
| Services | 17,486 |  |  | 13,156 |  |  | 50,148 |  |  | 39,219 |  |
| Total net sales (1) | 81,434 |  |  | 59,685 |  |  | 282,457 |  |  | 209,817 |  |
| Cost of sales: |  |  |  |  |  |  |  |
| Products | 40,899 |  |  | 32,693 |  |  | 149,476 |  |  | 116,089 |  |
| Services | 5,280 |  |  | 4,312 |  |  | 15,319 |  |  | 13,461 |  |
| Total cost of sales | 46,179 |  |  | 37,005 |  |  | 164,795 |  |  | 129,550 |  |
| Gross margin | 35,255 |  |  | 22,680 |  |  | 117,662 |  |  | 80,267 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 5,717 |  |  | 4,758 |  |  | 16,142 |  |  | 13,774 |  |
| Selling, general and administrative | 5,412 |  |  | 4,831 |  |  | 16,357 |  |  | 14,980 |  |
| Total operating expenses | 11,129 |  |  | 9,589 |  |  | 32,499 |  |  | 28,754 |  |
| Operating income | 24,126 |  |  | 13,091 |  |  | 85,163 |  |  | 51,513 |  |
| Other income/(expense), net | 243 |  |  | 46 |  |  | 796 |  |  | 677 |  |
| Income before provision for income taxes | 24,369 |  |  | 13,137 |  |  | 85,959 |  |  | 52,190 |  |
| Provision for income taxes | 2,625 |  |  | 1,884 |  |  | 11,830 |  |  | 7,452 |  |
| Net income | $ | 21,744 |  |  | $ | 11,253 |  |  | $ | 74,129 |  |  | $ | 44,738 |  |
| Earnings per share: |  |  |  |  |  |  |  |
| Basic | $ | 1.31 |  |  | $ | 0.65 |  |  | $ | 4.42 |  |  | $ | 2.56 |  |
| Diluted | $ | 1.30 |  |  | $ | 0.65 |  |  | $ | 4.38 |  |  | $ | 2.54 |  |
| Shares used in computing earnings per share: |  |  |  |  |  |  |  |
| Basic | 16,629,371 |  |  | 17,250,291 |  |  | 16,772,656 |  |  | 17,450,284 |  |
| Diluted | 16,781,735 |  |  | 17,419,154 |  |  | 16,941,527 |  |  | 17,618,778 |  |
| (1) Net sales by reportable segment: |  |  |  |  |  |  |  |
| Americas | $ | 35,870 |  |  | $ | 27,018 |  |  | $ | 116,486 |  |  | $ | 93,858 |  |
| Europe | 18,943 |  |  | 14,173 |  |  | 68,513 |  |  | 51,740 |  |
| Greater China | 14,762 |  |  | 9,329 |  |  | 53,803 |  |  | 32,362 |  |
| Japan | 6,464 |  |  | 4,966 |  |  | 22,491 |  |  | 16,395 |  |
| Rest of Asia Pacific | 5,395 |  |  | 4,199 |  |  | 21,164 |  |  | 15,462 |  |
| Total net sales | $ | 81,434 |  |  | $ | 59,685 |  |  | $ | 282,457 |  |  | $ | 209,817 |  |
| (1) Net sales by category: |  |  |  |  |  |  |  |
| iPhone | $ | 39,570 |  |  | $ | 26,418 |  |  | $ | 153,105 |  |  | $ | 111,337 |  |
| Mac | 8,235 |  |  | 7,079 |  |  | 26,012 |  |  | 19,590 |  |
| iPad | 7,368 |  |  | 6,582 |  |  | 23,610 |  |  | 16,927 |  |
| Wearables, Home and Accessories | 8,775 |  |  | 6,450 |  |  | 29,582 |  |  | 22,744 |  |
| Services | 17,486 |  |  | 13,156 |  |  | 50,148 |  |  | 39,219 |  |
| Total net sales | $ | 81,434 |  |  | $ | 59,685 |  |  | $ | 282,457 |  |  | $ | 209,817 |  |

[0000320193-21-000063:8k_2_02:30]
Apple Inc.

[0000320193-21-000063:8k_2_02:31]
CONDENSED CONSOLIDATED BALANCE SHEETS (Unaudited)

[0000320193-21-000063:8k_2_02:32]
(In millions, except number of shares which are reflected in thousands and par value)

[0000320193-21-000063:8k_2_02:33]
|  | June 26,2021 |  | September 26,2020 |
| ASSETS: |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 34,050 |  |  | $ | 38,016 |  |
| Marketable securities | 27,646 |  |  | 52,927 |  |
| Accounts receivable, net | 17,475 |  |  | 16,120 |  |
| Inventories | 5,178 |  |  | 4,061 |  |
| Vendor non-trade receivables | 16,433 |  |  | 21,325 |  |
| Other current assets | 13,641 |  |  | 11,264 |  |
| Total current assets | 114,423 |  |  | 143,713 |  |
| Non-current assets: |  |  |  |
| Marketable securities | 131,948 |  |  | 100,887 |  |
| Property, plant and equipment, net | 38,615 |  |  | 36,766 |  |
| Other non-current assets | 44,854 |  |  | 42,522 |  |
| Total non-current assets | 215,417 |  |  | 180,175 |  |
| Total assets | $ | 329,840 |  |  | $ | 323,888 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY: |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 40,409 |  |  | $ | 42,296 |  |
| Other current liabilities | 43,625 |  |  | 42,684 |  |
| Deferred revenue | 7,681 |  |  | 6,643 |  |
| Commercial paper | 8,000 |  |  | 4,996 |  |
| Term debt | 8,039 |  |  | 8,773 |  |
| Total current liabilities | 107,754 |  |  | 105,392 |  |
| Non-current liabilities: |  |  |  |
| Term debt | 105,752 |  |  | 98,667 |  |
| Other non-current liabilities | 52,054 |  |  | 54,490 |  |
| Total non-current liabilities | 157,806 |  |  | 153,157 |  |
| Total liabilities | 265,560 |  |  | 258,549 |  |
| Commitments and contingencies |  |  |  |
| Shareholders’ equity: |  |  |  |
| Common stock and additional paid-in capital, $0.00001 par value: 50,400,000 shares authorized; 16,556,942 and 16,976,763 shares issued and outstanding, respectively | 54,989 |  |  | 50,779 |  |
| Retained earnings | 9,233 |  |  | 14,966 |  |
| Accumulated other comprehensive income/(loss) | 58 |  |  | (406) |  |
| Total shareholders’ equity | 64,280 |  |  | 65,339 |  |
| Total liabilities and shareholders’ equity | $ | 329,840 |  |  | $ | 323,888 |  |

[0000320193-21-000063:8k_2_02:34]
Apple Inc.

[0000320193-21-000063:8k_2_02:35]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (Unaudited)

[0000320193-21-000063:8k_2_02:36]
(In millions)

[0000320193-21-000063:8k_2_02:37]
|  | Nine Months Ended |
|  | June 26,2021 |  | June 27,2020 |
| Cash, cash equivalents and restricted cash, beginning balances | $ | 39,789 |  |  | $ | 50,224 |  |
| Operating activities: |  |  |  |
| Net income | 74,129 |  |  | 44,738 |  |
| Adjustments to reconcile net income to cash generated by operating activities: |  |  |  |
| Depreciation and amortization | 8,295 |  |  | 8,354 |  |
| Share-based compensation expense | 5,961 |  |  | 5,105 |  |
| Deferred income tax expense/(benefit) | (737) |  |  | 182 |  |
| Other | (689) |  |  | (94) |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | (1,316) |  |  | 5,149 |  |
| Inventories | (1,213) |  |  | 10 |  |
| Vendor non-trade receivables | 4,892 |  |  | 8,685 |  |
| Other current and non-current assets | (5,899) |  |  | (6,760) |  |
| Accounts payable | (1,786) |  |  | (10,787) |  |
| Deferred revenue | 1,738 |  |  | 1,649 |  |
| Other current and non-current liabilities | 463 |  |  | 3,867 |  |
| Cash generated by operating activities | 83,838 |  |  | 60,098 |  |
| Investing activities: |  |  |  |
| Purchases of marketable securities | (94,052) |  |  | (96,606) |  |
| Proceeds from maturities of marketable securities | 49,880 |  |  | 54,865 |  |
| Proceeds from sales of marketable securities | 36,745 |  |  | 39,760 |  |
| Payments for acquisition of property, plant and equipment | (7,862) |  |  | (5,525) |  |
| Payments made in connection with business acquisitions, net | (13) |  |  | (1,473) |  |
| Other | (78) |  |  | (841) |  |
| Cash used in investing activities | (15,380) |  |  | (9,820) |  |
| Financing activities: |  |  |  |
| Proceeds from issuance of common stock | 561 |  |  | 430 |  |
| Payments for taxes related to net share settlement of equity awards | (5,855) |  |  | (3,234) |  |
| Payments for dividends and dividend equivalents | (10,827) |  |  | (10,570) |  |
| Repurchases of common stock | (66,223) |  |  | (55,171) |  |
| Proceeds from issuance of term debt, net | 13,923 |  |  | 10,635 |  |
| Repayments of term debt | (7,500) |  |  | (12,629) |  |
| Proceeds from commercial paper, net | 3,022 |  |  | 31 |  |
| Proceeds from repurchase agreements | — |  |  | 5,165 |  |
| Other | (72) |  |  | (120) |  |
| Cash used in financing activities | (72,971) |  |  | (65,463) |  |
| Decrease in cash, cash equivalents and restricted cash | (4,513) |  |  | (15,185) |  |
| Cash, cash equivalents and restricted cash, ending balances | $ | 35,276 |  |  | $ | 35,039 |  |
| Supplemental cash flow disclosure: |  |  |  |
| Cash paid for income taxes, net | $ | 18,536 |  |  | $ | 8,410 |  |
| Cash paid for interest | $ | 1,870 |  |  | $ | 2,275 |  |
