# AAPL notes — 0000320193-21-000065


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000320193-21-000065:notes:1]
[same as prior period, unchanged from 0000320193-21-000056:notes:1]

[0000320193-21-000065:notes:2]
[same as prior period, unchanged from 0000320193-21-000056:notes:2]

[0000320193-21-000065:notes:3]
[same as prior period, unchanged from 0000320193-21-000056:notes:3]

[0000320193-21-000065:notes:4]
[same as prior period, unchanged from 0000320193-21-000056:notes:4]

[0000320193-21-000065:notes:5]
[same as prior period, unchanged from 0000320193-21-000056:notes:5]

[0000320193-21-000065:notes:6]
Recently Adopted Accounting Pronouncements

[0000320193-21-000065:notes:7]
[same as prior period, unchanged from 0000320193-21-000056:notes:7]

[0000320193-21-000065:notes:8]
At the beginning of the first quarter of 2021, the Company adopted the Financial Accounting Standards Board’s Accounting Standards Update No. 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (“ASU 2016-13”), which modifies the measurement of expected credit losses on certain financial instruments. The Company adopted ASU 2016-13 utilizing the modified retrospective transition method. The adoption of ASU 2016-13 did not have a material impact on the Company’s condensed consolidated financial statements.

[0000320193-21-000065:notes:9]
[same as prior period, unchanged from 0000320193-21-000056:notes:9]

[0000320193-21-000065:notes:10]
The following table shows the computation of basic and diluted earnings per share for the three- and nine-month periods ended June 26, 2021 and June 27, 2020 (net income in millions and shares in thousands):

[0000320193-21-000065:notes:11]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2021 |  | June 27,2020 |  | June 26,2021 |  | June 27,2020 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 21,744 |  |  | $ | 11,253 |  |  | $ | 74,129 |  |  | $ | 44,738 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 16,629,371 |  |  | 17,250,291 |  |  | 16,772,656 |  |  | 17,450,284 |  |
| Effect of dilutive securities | 152,364 |  |  | 168,863 |  |  | 168,871 |  |  | 168,494 |  |
| Weighted-average diluted shares | 16,781,735 |  |  | 17,419,154 |  |  | 16,941,527 |  |  | 17,618,778 |  |
| Basic earnings per share | $ | 1.31 |  |  | $ | 0.65 |  |  | $ | 4.42 |  |  | $ | 2.56 |  |
| Diluted earnings per share | $ | 1.30 |  |  | $ | 0.65 |  |  | $ | 4.38 |  |  | $ | 2.54 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000320193-21-000065:notes:12]
[same as prior period, unchanged from 0000320193-21-000056:notes:12]

[0000320193-21-000065:notes:13]
[same as prior period, unchanged from 0000320193-21-000056:notes:13]

[0000320193-21-000065:notes:14]
[same as prior period, unchanged from 0000320193-21-000056:notes:14]

[0000320193-21-000065:notes:15]
[same as prior period, unchanged from 0000320193-21-000056:notes:15]

[0000320193-21-000065:notes:16]
[same as prior period, unchanged from 0000320193-21-000056:notes:16]

[0000320193-21-000065:notes:17]
[same as prior period, unchanged from 0000320193-21-000056:notes:17]

[0000320193-21-000065:notes:18]
[same as prior period, unchanged from 0000320193-21-000056:notes:18]

[0000320193-21-000065:notes:19]
[same as prior period, unchanged from 0000320193-21-000056:notes:19]

[0000320193-21-000065:notes:20]
As of June 26, 2021 and September 26, 2020, the Company had total deferred revenue of $12.0 billion and $10.2 billion, respectively. As of June 26, 2021, the Company expects 64% of total deferred revenue to be realized in less than a year, 26% within one-to-two years, 8% within two-to-three years and 2% in greater than three years.

[0000320193-21-000065:notes:21]
[same as prior period, unchanged from 0000320193-21-000056:notes:21]

[0000320193-21-000065:notes:22]
Net sales disaggregated by significant products and services for the three- and nine-month periods ended June 26, 2021 and June 27, 2020 were as follows (in millions):

[0000320193-21-000065:notes:23]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2021 |  | June 27,2020 |  | June 26,2021 |  | June 27,2020 |
| iPhone (1) | $ | 39,570 |  |  | $ | 26,418 |  |  | $ | 153,105 |  |  | $ | 111,337 |  |
| Mac (1) | 8,235 |  |  | 7,079 |  |  | 26,012 |  |  | 19,590 |  |
| iPad (1) | 7,368 |  |  | 6,582 |  |  | 23,610 |  |  | 16,927 |  |
| Wearables, Home and Accessories (1)(2) | 8,775 |  |  | 6,450 |  |  | 29,582 |  |  | 22,744 |  |
| Services (3) | 17,486 |  |  | 13,156 |  |  | 50,148 |  |  | 39,219 |  |
| Total net sales (4) | $ | 81,434 |  |  | $ | 59,685 |  |  | $ | 282,457 |  |  | $ | 209,817 |  |

[0000320193-21-000065:notes:24]
[same as prior period, unchanged from 0000320193-21-000056:notes:24]

[0000320193-21-000065:notes:25]
[same as prior period, unchanged from 0000320193-21-000056:notes:25]

[0000320193-21-000065:notes:26]
[same as prior period, unchanged from 0000320193-21-000056:notes:26]

[0000320193-21-000065:notes:27]
(4)Includes $3.0 billion of revenue recognized in the three months ended June 26, 2021 that was included in deferred revenue as of March 27, 2021, $2.1 billion of revenue recognized in the three months ended June 27, 2020 that was included in deferred revenue as of March 28, 2020, $5.5 billion of revenue recognized in the nine months ended June 26, 2021 that was included in deferred revenue as of September 26, 2020, and $4.0 billion of revenue recognized in the nine months ended June 27, 2020 that was included in deferred revenue as of September 28, 2019.

[0000320193-21-000065:notes:28]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 11, “Segment Information and Geographic Data” for the three- and nine-month periods ended June 26, 2021 and June 27, 2020.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000320193-21-000065:notes:29]
[same as prior period, unchanged from 0000320193-21-000056:notes:29]

[0000320193-21-000065:notes:30]
The following tables show the Company’s cash, cash equivalents and marketable securities by significant investment category as of June 26, 2021 and September 26, 2020 (in millions):

[0000320193-21-000065:notes:31]
|  | June 26, 2021 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | CurrentMarketableSecurities |  | Non-CurrentMarketableSecurities |
| Cash | $ | 14,853 |  |  | $ | — |  |  | $ | — |  |  | $ | 14,853 |  |  | $ | 14,853 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 9,568 |  |  | — |  |  | — |  |  | 9,568 |  |  | 9,568 |  |  | — |  |  | — |  |
| Mutual funds | 159 |  |  | 8 |  |  | — |  |  | 167 |  |  | — |  |  | 167 |  |  | — |  |
| Subtotal | 9,727 |  |  | 8 |  |  | — |  |  | 9,735 |  |  | 9,568 |  |  | 167 |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 22,582 |  |  | 133 |  |  | (112) |  |  | 22,603 |  |  | 1,602 |  |  | 8,083 |  |  | 12,918 |  |
| U.S. agency securities | 7,542 |  |  | 3 |  |  | (69) |  |  | 7,476 |  |  | 410 |  |  | 1,781 |  |  | 5,285 |  |
| Non-U.S. government securities | 20,007 |  |  | 252 |  |  | (92) |  |  | 20,167 |  |  | 118 |  |  | 3,537 |  |  | 16,512 |  |
| Certificates of deposit and time deposits | 7,099 |  |  | — |  |  | — |  |  | 7,099 |  |  | 6,362 |  |  | 466 |  |  | 271 |  |
| Commercial paper | 2,056 |  |  | — |  |  | — |  |  | 2,056 |  |  | 1,137 |  |  | 919 |  |  | — |  |
| Corporate debt securities | 85,221 |  |  | 1,444 |  |  | (276) |  |  | 86,389 |  |  | — |  |  | 11,903 |  |  | 74,486 |  |
| Municipal securities | 984 |  |  | 15 |  |  | — |  |  | 999 |  |  | — |  |  | 128 |  |  | 871 |  |
| Mortgage- and asset-backed securities | 22,233 |  |  | 191 |  |  | (157) |  |  | 22,267 |  |  | — |  |  | 662 |  |  | 21,605 |  |
| Subtotal | 167,724 |  |  | 2,038 |  |  | (706) |  |  | 169,056 |  |  | 9,629 |  |  | 27,479 |  |  | 131,948 |  |
| Total (3) | $ | 192,304 |  |  | $ | 2,046 |  |  | $ | (706) |  |  | $ | 193,644 |  |  | $ | 34,050 |  |  | $ | 27,646 |  |  | $ | 131,948 |  |

[0000320193-21-000065:notes:32]
[same as prior period, unchanged from 0000320193-21-000056:notes:32]

[0000320193-21-000065:notes:33]
[same as prior period, unchanged from 0000320193-21-000056:notes:33]

[0000320193-21-000065:notes:34]
[same as prior period, unchanged from 0000320193-21-000056:notes:34]

[0000320193-21-000065:notes:35]
(3)As of June 26, 2021 and September 26, 2020, total marketable securities included $18.9 billion and $18.6 billion, respectively, that was restricted from general use, related to the State Aid Decision (refer to Note 5, “Income Taxes”) and other agreements.

[0000320193-21-000065:notes:36]
The Company may sell certain of its marketable debt securities prior to their stated maturities for reasons including, but not limited to, managing liquidity, credit risk, duration and asset allocation. The following table shows the fair value of the Company’s non-current marketable debt securities, by contractual maturity, as of June 26, 2021 (in millions):

[0000320193-21-000065:notes:37]
| Due after 1 year through 5 years | $ | 83,577 |  |
| Due after 5 years through 10 years | 26,324 |  |
| Due after 10 years | 22,047 |  |
| Total fair value | $ | 131,948 |  |

[0000320193-21-000065:notes:38]
[same as prior period, unchanged from 0000320193-21-000056:notes:38]

[0000320193-21-000065:notes:39]
[same as prior period, unchanged from 0000320193-21-000056:notes:39]

[0000320193-21-000065:notes:40]
The Company holds non-marketable equity securities of certain privately held companies without readily determinable fair values. As of both June 26, 2021 and September 26, 2020, the Company’s non-marketable equity securities had a carrying value of $2.8 billion.

[0000320193-21-000065:notes:41]
[same as prior period, unchanged from 0000320193-21-000056:notes:41]

[0000320193-21-000065:notes:42]
A reconciliation of the Company’s cash and cash equivalents in the Condensed Consolidated Balance Sheets to cash, cash equivalents and restricted cash in the Condensed Consolidated Statements of Cash Flows as of June 26, 2021 and September 26, 2020 is as follows (in millions):

[0000320193-21-000065:notes:43]
|  | June 26,2021 |  | September 26,2020 |
| Cash and cash equivalents | $ | 34,050 |  |  | $ | 38,016 |  |
| Restricted cash | 1,226 |  |  | 1,773 |  |
| Cash, cash equivalents and restricted cash | $ | 35,276 |  |  | $ | 39,789 |  |

[0000320193-21-000065:notes:44]
[same as prior period, unchanged from 0000320193-21-000056:notes:44]

[0000320193-21-000065:notes:45]
[same as prior period, unchanged from 0000320193-21-000056:notes:45]

[0000320193-21-000065:notes:46]
[same as prior period, unchanged from 0000320193-21-000056:notes:46]

[0000320193-21-000065:notes:47]
[same as prior period, unchanged from 0000320193-21-000056:notes:47]

[0000320193-21-000065:notes:48]
[same as prior period, unchanged from 0000320193-21-000056:notes:48]

[0000320193-21-000065:notes:49]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in foreign currency exchange rates, the Company may enter into forward contracts, cross-currency swaps or other instruments. These instruments may offset a portion of the foreign currency remeasurement gains or losses, or changes in fair value. The Company may designate these instruments as either cash flow or fair value hedges. As of June 26, 2021, the Company’s hedged term debt– and marketable securities–related foreign currency transactions are expected to be recognized within 21 years.

[0000320193-21-000065:notes:50]
[same as prior period, unchanged from 0000320193-21-000056:notes:50]

[0000320193-21-000065:notes:51]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in interest rates, the Company may enter into interest rate swaps, options or other instruments. These instruments may offset a portion of the changes in interest income or expense, or changes in fair value. The Company designates these instruments as either cash flow or fair value hedges. As of June 26, 2021, the Company’s hedged interest rate transactions are expected to be recognized within six years.

[0000320193-21-000065:notes:52]
[same as prior period, unchanged from 0000320193-21-000056:notes:52]

[0000320193-21-000065:notes:53]
[same as prior period, unchanged from 0000320193-21-000056:notes:53]

[0000320193-21-000065:notes:54]
[same as prior period, unchanged from 0000320193-21-000056:notes:54]

[0000320193-21-000065:notes:55]
[same as prior period, unchanged from 0000320193-21-000056:notes:55]

[0000320193-21-000065:notes:56]
[same as prior period, unchanged from 0000320193-21-000056:notes:56]

[0000320193-21-000065:notes:57]
[same as prior period, unchanged from 0000320193-21-000056:notes:57]

[0000320193-21-000065:notes:58]
Fair value hedge gains and losses related to amounts that are included in the assessment of hedge effectiveness are recognized in earnings along with a corresponding loss or gain related to the change in value of the hedged item in the same line in the Condensed Consolidated Statements of Operations. For foreign exchange forward contracts designated as fair value hedges, the forward carry component is excluded from the assessment of hedge effectiveness and recognized in OI&E on a straight-line basis over the life of the hedge. Amounts excluded from the effectiveness assessment of fair value hedges and recognized in OI&E were gains of $57 million and $199 million for the three- and nine-month periods ended June 26, 2021, respectively, and were gains of $119 million and $373 million for the three- and nine-month periods ended June 27, 2020, respectively. Changes in the fair value of amounts excluded from the assessment of hedge effectiveness are recognized in OCI.

[0000320193-21-000065:notes:59]
[same as prior period, unchanged from 0000320193-21-000056:notes:59]

[0000320193-21-000065:notes:60]
[same as prior period, unchanged from 0000320193-21-000056:notes:60]

[0000320193-21-000065:notes:61]
The Company records all derivatives in the Condensed Consolidated Balance Sheets at fair value. The Company’s accounting treatment for these derivative instruments is based on its hedge designation. The following tables show the Company’s derivative instruments at gross fair value as of June 26, 2021 and September 26, 2020 (in millions):

[0000320193-21-000065:notes:62]
|  | June 26, 2021 |
|  | Fair Value ofDerivatives Designatedas Hedge Instruments |  | Fair Value ofDerivatives Not Designatedas Hedge Instruments |  | TotalFair Value |
| Derivative assets (1): |  |  |  |  |  |
| Foreign exchange contracts | $ | 700 |  |  | $ | 510 |  |  | $ | 1,210 |  |
| Interest rate contracts | $ | 891 |  |  | $ | — |  |  | $ | 891 |  |
| Derivative liabilities (2): |  |  |  |  |  |
| Foreign exchange contracts | $ | 918 |  |  | $ | 601 |  |  | $ | 1,519 |  |

[0000320193-21-000065:notes:63]
[same as prior period, unchanged from 0000320193-21-000056:notes:63]

[0000320193-21-000065:notes:64]
[same as prior period, unchanged from 0000320193-21-000056:notes:64]

[0000320193-21-000065:notes:65]
[same as prior period, unchanged from 0000320193-21-000056:notes:65]

[0000320193-21-000065:notes:66]
[same as prior period, unchanged from 0000320193-21-000056:notes:66]

[0000320193-21-000065:notes:67]
The following table shows the pre-tax gains and losses of the Company’s derivative and non-derivative instruments designated as cash flow and net investment hedges in OCI and the Condensed Consolidated Statements of Operations for the three- and nine-month periods ended June 26, 2021 and June 27, 2020 (in millions):

[0000320193-21-000065:notes:68]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2021 |  | June 27,2020 |  | June 26,2021 |  | June 27,2020 |
| Gains/(Losses) recognized in OCI – included in effectiveness assessment: |  |  |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | (87) |  |  | $ | 366 |  |  | $ | 60 |  |  | $ | 175 |  |
| Interest rate contracts | — |  |  | (6) |  |  | 93 |  |  | (72) |  |
| Total | $ | (87) |  |  | $ | 360 |  |  | $ | 153 |  |  | $ | 103 |  |
| Net investment hedges: |  |  |  |  |  |  |  |
| Foreign currency debt | $ | — |  |  | $ | (20) |  |  | $ | — |  |  | $ | 15 |  |
| Gains/(Losses) reclassified from AOCI into net income – included in effectiveness assessment: |  |  |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 9 |  |  | $ | 1,389 |  |  | $ | (562) |  |  | $ | 1,063 |  |
| Interest rate contracts | (1) |  |  | (3) |  |  | (6) |  |  | (6) |  |
| Total | $ | 8 |  |  | $ | 1,386 |  |  | $ | (568) |  |  | $ | 1,057 |  |

[0000320193-21-000065:notes:69]
Amounts excluded from the effectiveness assessment of the Company’s hedges and recognized in OCI were a gain of $63 million and a loss of $34 million for the three- and nine-month periods ended June 26, 2021, respectively, and were losses of $220 million and $51 million for the three- and nine-month periods ended June 27, 2020, respectively.

[0000320193-21-000065:notes:70]
The following tables show information about the Company’s derivative instruments designated as fair value hedges and the related hedged items for the three- and nine-month periods ended June 26, 2021 and June 27, 2020 and as of June 26, 2021 and September 26, 2020 (in millions):

[0000320193-21-000065:notes:71]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2021 |  | June 27,2020 |  | June 26,2021 |  | June 27,2020 |
| Gains/(Losses) on derivative instruments (1): |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | (130) |  |  | $ | (675) |  |  | $ | (313) |  |  | $ | (422) |  |
| Interest rate contracts | (32) |  |  | 57 |  |  | (650) |  |  | 1,185 |  |
| Total | $ | (162) |  |  | $ | (618) |  |  | $ | (963) |  |  | $ | 763 |  |
| Gains/(Losses) related to hedged items (1): |  |  |  |  |  |  |  |
| Marketable securities | $ | 130 |  |  | $ | 675 |  |  | $ | 313 |  |  | $ | 422 |  |
| Fixed-rate debt | 32 |  |  | (57) |  |  | 650 |  |  | (1,185) |  |
| Total | $ | 162 |  |  | $ | 618 |  |  | $ | 963 |  |  | $ | (763) |  |

[0000320193-21-000065:notes:72]
|  | June 26,2021 |  | September 26,2020 |
| Carrying amounts of hedged assets/(liabilities): |  |  |  |
| Marketable securities (2) | $ | 16,254 |  |  | $ | 16,270 |  |
| Fixed-rate debt (3) | $ | (18,384) |  |  | $ | (21,033) |  |
| Cumulative hedging adjustments included in the carrying amounts of hedged items: |  |  |  |
| Marketable securities carrying amount increases/(decreases) | $ | 538 |  |  | $ | 493 |  |
| Fixed-rate debt carrying amount (increases)/decreases | $ | (891) |  |  | $ | (1,541) |  |

[0000320193-21-000065:notes:73]
[same as prior period, unchanged from 0000320193-21-000056:notes:73]

[0000320193-21-000065:notes:74]
[same as prior period, unchanged from 0000320193-21-000056:notes:74]

[0000320193-21-000065:notes:75]
[same as prior period, unchanged from 0000320193-21-000056:notes:75]

[0000320193-21-000065:notes:76]
The following table shows the notional amounts of the Company’s outstanding derivative instruments and credit risk amounts associated with outstanding or unsettled derivative instruments as of June 26, 2021 and September 26, 2020 (in millions):

[0000320193-21-000065:notes:77]
|  | June 26, 2021 |  | September 26, 2020 |
|  | NotionalAmount |  | Credit RiskAmount |  | NotionalAmount |  | Credit RiskAmount |
| Instruments designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 53,914 |  |  | $ | 700 |  |  | $ | 57,410 |  |  | $ | 749 |  |
| Interest rate contracts | $ | 17,500 |  |  | $ | 891 |  |  | $ | 20,700 |  |  | $ | 1,557 |  |
| Instruments not designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 95,910 |  |  | $ | 510 |  |  | $ | 88,636 |  |  | $ | 303 |  |

[0000320193-21-000065:notes:78]
[same as prior period, unchanged from 0000320193-21-000056:notes:78]

[0000320193-21-000065:notes:79]
The Company generally enters into master netting arrangements, which are designed to reduce credit risk by permitting net settlement of transactions with the same counterparty. To further limit credit risk, the Company generally enters into collateral security arrangements that provide for collateral to be received or posted when the net fair value of certain financial instruments fluctuates from contractually established thresholds. The Company presents its derivative assets and derivative liabilities at their gross fair values in its Condensed Consolidated Balance Sheets. As of June 26, 2021 and September 26, 2020, the net cash collateral received by the Company related to derivative instruments under its collateral security arrangements was $576 million and $875 million, respectively. The Company includes gross collateral posted and received in other current assets and other current liabilities in the Condensed Consolidated Balance Sheets, respectively.

[0000320193-21-000065:notes:80]
Under master netting arrangements with the respective counterparties to the Company’s derivative contracts, the Company is allowed to net settle transactions with a single net amount payable by one party to the other. As of June 26, 2021 and September 26, 2020, the potential effects of these rights of set-off associated with the Company’s derivative contracts, including the effects of collateral, would be a reduction to both derivative assets and derivative liabilities of $2.2 billion and $2.8 billion, respectively, resulting in a net derivative asset of $6 million and a net derivative liability of $312 million, respectively.

[0000320193-21-000065:notes:81]
[same as prior period, unchanged from 0000320193-21-000056:notes:81]

[0000320193-21-000065:notes:82]
[same as prior period, unchanged from 0000320193-21-000056:notes:82]

[0000320193-21-000065:notes:83]
[same as prior period, unchanged from 0000320193-21-000056:notes:83]

[0000320193-21-000065:notes:84]
As of both June 26, 2021 and September 26, 2020, the Company had no customers that individually represented 10% or more of total trade receivables. The Company’s cellular network carriers accounted for 36% of total trade receivables as of June 26, 2021.

[0000320193-21-000065:notes:85]
[same as prior period, unchanged from 0000320193-21-000056:notes:85]

[0000320193-21-000065:notes:86]
The Company has non-trade receivables from certain of its manufacturing vendors resulting from the sale of components to these vendors who manufacture sub-assemblies or assemble final products for the Company. The Company purchases these components directly from suppliers. As of June 26, 2021, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 56% and 13%. As of September 26, 2020, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 57% and 11%.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000320193-21-000065:notes:87]
[same as prior period, unchanged from 0000320193-21-000056:notes:87]


## us-gaap:DerivativesPolicyTextBlock

[0000320193-21-000065:notes:88]
[same as prior period, unchanged from 0000320193-21-000056:notes:88]

[0000320193-21-000065:notes:89]
[same as prior period, unchanged from 0000320193-21-000056:notes:89]


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000320193-21-000065:notes:90]
Condensed Consolidated Financial Statement Details
The following tables show the Company’s condensed consolidated financial statement details as of June 26, 2021 and September 26, 2020 (in millions):

[0000320193-21-000065:notes:91]
[same as prior period, unchanged from 0000320193-21-000056:notes:91]

[0000320193-21-000065:notes:92]
|  | June 26,2021 |  | September 26,2020 |
| Land and buildings | $ | 19,149 |  |  | $ | 17,952 |  |
| Machinery, equipment and internal-use software | 78,981 |  |  | 75,291 |  |
| Leasehold improvements | 10,727 |  |  | 10,283 |  |
| Gross property, plant and equipment | 108,857 |  |  | 103,526 |  |
| Accumulated depreciation and amortization | (70,242) |  |  | (66,760) |  |
| Total property, plant and equipment, net | $ | 38,615 |  |  | $ | 36,766 |  |

[0000320193-21-000065:notes:93]
[same as prior period, unchanged from 0000320193-21-000056:notes:93]

[0000320193-21-000065:notes:94]
|  | June 26,2021 |  | September 26,2020 |
| Long-term taxes payable | $ | 24,923 |  |  | $ | 28,170 |  |
| Other non-current liabilities | 27,131 |  |  | 26,320 |  |
| Total other non-current liabilities | $ | 52,054 |  |  | $ | 54,490 |  |

[0000320193-21-000065:notes:95]
[same as prior period, unchanged from 0000320193-21-000056:notes:95]

[0000320193-21-000065:notes:96]
The following table shows the detail of OI&E for the three- and nine-month periods ended June 26, 2021 and June 27, 2020 (in millions):

[0000320193-21-000065:notes:97]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2021 |  | June 27,2020 |  | June 26,2021 |  | June 27,2020 |
| Interest and dividend income | $ | 719 |  |  | $ | 901 |  |  | $ | 2,184 |  |  | $ | 2,995 |  |
| Interest expense | (665) |  |  | (697) |  |  | (1,973) |  |  | (2,239) |  |
| Other income/(expense), net | 189 |  |  | (158) |  |  | 585 |  |  | (79) |  |
| Total other income/(expense), net | $ | 243 |  |  | $ | 46 |  |  | $ | 796 |  |  | $ | 677 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000320193-21-000065:notes:98]
[same as prior period, unchanged from 0000320193-21-000056:notes:98]

[0000320193-21-000065:notes:99]
As of June 26, 2021, the total amount of gross unrecognized tax benefits was $16.8 billion, of which $7.6 billion, if recognized, would impact the Company’s effective tax rate. The Company had accrued $1.6 billion of gross interest and penalties related to income tax matters as of June 26, 2021.

[0000320193-21-000065:notes:100]
The Company is subject to taxation and files income tax returns in the U.S. federal jurisdiction and many state and foreign jurisdictions. Tax years after 2015 for the U.S. federal jurisdiction, and after 2014 in certain major foreign jurisdictions, remain subject to examination. The Company believes that an adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax examinations cannot be predicted with certainty. If any issues addressed in the Company’s tax examinations are resolved in a manner inconsistent with its expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. Although the timing of resolution and/or closure of examinations is not certain, the Company believes it is reasonably possible that its gross unrecognized tax benefits could decrease in the next 12 months by as much as $2.4 billion.

[0000320193-21-000065:notes:101]
[same as prior period, unchanged from 0000320193-21-000056:notes:101]

[0000320193-21-000065:notes:102]
[same as prior period, unchanged from 0000320193-21-000056:notes:102]

[0000320193-21-000065:notes:103]
On an annual basis, the Company may request approval from the Irish Minister for Finance to reduce the recovery amount for certain taxes paid to other countries. As of June 26, 2021, the adjusted recovery amount was €12.7 billion, excluding interest. The adjusted recovery amount plus interest is funded into escrow, where it will remain restricted from general use pending the conclusion of all legal proceedings. Refer to the Cash, Cash Equivalents and Marketable Securities section of Note 3, “Financial Instruments” for more information.


## us-gaap:DebtDisclosureTextBlock

[0000320193-21-000065:notes:104]
Debt
Commercial Paper and Repurchase Agreements

[0000320193-21-000065:notes:105]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of June 26, 2021 and September 26, 2020, the Company had $8.0 billion and $5.0 billion of Commercial Paper outstanding, respectively, with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 0.04% and 0.62% as of June 26, 2021 and September 26, 2020, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the nine months ended June 26, 2021 and June 27, 2020 (in millions):

[0000320193-21-000065:notes:106]
|  | Nine Months Ended |
|  | June 26,2021 |  | June 27,2020 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from commercial paper, net | $ | 2,745 |  |  | $ | 401 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 3,993 |  |  | 5,373 |  |
| Repayments of commercial paper | (3,716) |  |  | (5,743) |  |
| Proceeds from/(Repayments of) commercial paper, net | 277 |  |  | (370) |  |
| Total proceeds from commercial paper, net | $ | 3,022 |  |  | $ | 31 |  |

[0000320193-21-000065:notes:107]
In 2020, the Company entered into agreements to sell certain of its marketable securities with a promise to repurchase the securities at a specified time and amount (“Repos”). Due to the Company’s continuing involvement with the marketable securities, the Company accounted for its Repos as collateralized borrowings. As of September 26, 2020, the Repos had been settled.

[0000320193-21-000065:notes:108]
Term Debt

[0000320193-21-000065:notes:109]
As of June 26, 2021, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $113.2 billion (collectively the “Notes”). The Notes are senior unsecured obligations and interest is payable in arrears. The following table provides a summary of the Company’s term debt as of June 26, 2021 and September 26, 2020:

[0000320193-21-000065:notes:110]
|  | Maturities(calendar year) |  | June 26, 2021 |  | September 26, 2020 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 – 2020 debt issuances: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2022 |  | $ | 1,750 |  |  | 0.51% – 0.66% |  | $ | 2,250 |  |  | 0.60% – 1.39% |
| Fixed-rate 0.000% – 4.650% notes | 2021 – 2060 |  | 97,443 |  |  | 0.03% – 4.78% |  | 103,828 |  |  | 0.03% – 4.78% |
| 2021 debt issuance: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.700% – 2.800% notes | 2026 – 2061 |  | 14,000 |  |  | 0.75% – 2.81% |  | — |  |  | — | % |
| Total term debt |  |  | 113,193 |  |  |  |  | 106,078 |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  | (360) |  |  |  |  | (314) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 958 |  |  |  |  | 1,676 |  |  |  |
| Less: Current portion of term debt |  |  | (8,039) |  |  |  |  | (8,773) |  |  |  |
| Total non-current portion of term debt |  |  | $ | 105,752 |  |  |  |  | $ | 98,667 |  |  |  |

[0000320193-21-000065:notes:111]
To manage interest rate risk on certain of its U.S. dollar–denominated fixed- or floating-rate notes, the Company has entered into interest rate swaps to effectively convert the fixed interest rates to floating interest rates or the floating interest rates to fixed interest rates on a portion of these notes. Additionally, to manage foreign currency risk on certain of its foreign currency–denominated notes, the Company has entered into foreign currency swaps to effectively convert these notes to U.S. dollar–denominated notes.

[0000320193-21-000065:notes:112]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $657 million and $1.9 billion of interest cost on its term debt for the three- and nine-month periods ended June 26, 2021, respectively. The Company recognized $664 million and $2.1 billion of interest cost on its term debt for the three- and nine-month periods ended June 27, 2020, respectively.

[0000320193-21-000065:notes:113]
As of June 26, 2021 and September 26, 2020, the fair value of the Company’s Notes, based on Level 2 inputs, was $120.3 billion and $117.1 billion, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000320193-21-000065:notes:114]
[same as prior period, unchanged from 0000320193-21-000056:notes:114]

[0000320193-21-000065:notes:115]
As of June 26, 2021, the Company was authorized to purchase up to $315 billion of the Company’s common stock under a share repurchase program (the “Program”). During the nine months ended June 26, 2021, the Company repurchased 515 million shares of its common stock for $65.5 billion, including 32 million shares initially delivered under a May 2021 accelerated share repurchase agreement (“ASR”), bringing the total utilization under the Program to $234.1 billion. The Program does not obligate the Company to acquire any specific number of shares. Under the Program, shares may be repurchased in privately negotiated and/or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).

[0000320193-21-000065:notes:116]
Under the terms of the Company’s May 2021 ASR, a financial institution committed to deliver shares of the Company’s common stock during the purchase period in exchange for an up-front payment of $5.0 billion. The total number of shares ultimately delivered under the ASR, and therefore the average repurchase price paid per share, is determined based on the volume-weighted average price of the Company’s common stock during the ASR’s purchase period, which will end in or before August 2021. The shares received are retired in the periods they are delivered, and the up-front payment is accounted for as a reduction to retained earnings in the Company’s Condensed Consolidated Statement of Shareholders’ Equity in the period the payment is made.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000320193-21-000065:notes:117]
[same as prior period, unchanged from 0000320193-21-000056:notes:116]

[0000320193-21-000065:notes:118]
The following table shows the pre-tax amounts reclassified from AOCI into the Condensed Consolidated Statements of Operations, and the associated financial statement line items, for the three- and nine-month periods ended June 26, 2021 and June 27, 2020 (in millions):

[0000320193-21-000065:notes:119]
|  |  |  |  | Three Months Ended |  | Nine Months Ended |
| Comprehensive Income Components |  | Financial Statement Line Items |  | June 26,2021 |  | June 27,2020 |  | June 26,2021 |  | June 27,2020 |
| Unrealized (gains)/losses on derivative instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Total net sales |  | $ | 60 |  |  | $ | (270) |  |  | $ | 478 |  |  | $ | (333) |  |
|  |  | Total cost of sales |  | 101 |  |  | (362) |  |  | 752 |  |  | (521) |  |
|  |  | Other income/(expense), net |  | (155) |  |  | (760) |  |  | (590) |  |  | (212) |  |
| Interest rate contracts |  | Other income/(expense), net |  | 1 |  |  | 3 |  |  | 6 |  |  | 6 |  |
|  |  |  |  | 7 |  |  | (1,389) |  |  | 646 |  |  | (1,060) |  |
| Unrealized (gains)/losses on marketable debt securities |  | Other income/(expense), net |  | (70) |  |  | (14) |  |  | (284) |  |  | 10 |  |
| Total amounts reclassified from AOCI |  | $ | (63) |  |  | $ | (1,403) |  |  | $ | 362 |  |  | $ | (1,050) |  |

[0000320193-21-000065:notes:120]
The following table shows the changes in AOCI by component for the nine months ended June 26, 2021 (in millions):

[0000320193-21-000065:notes:121]
|  | Cumulative ForeignCurrency Translation |  | Unrealized Gains/Losseson Derivative Instruments |  | Unrealized Gains/Losseson Marketable Debt Securities |  | Total |
| Balances as of September 26, 2020 | $ | (1,375) |  |  | $ | (877) |  |  | $ | 1,846 |  |  | $ | (406) |  |
| Other comprehensive income/(loss) before reclassifications | 659 |  |  | 81 |  |  | (783) |  |  | (43) |  |
| Amounts reclassified from AOCI | — |  |  | 646 |  |  | (284) |  |  | 362 |  |
| Tax effect | — |  |  | (130) |  |  | 275 |  |  | 145 |  |
| Other comprehensive income/(loss) | 659 |  |  | 597 |  |  | (792) |  |  | 464 |  |
| Balances as of June 26, 2021 | $ | (716) |  |  | $ | (280) |  |  | $ | 1,054 |  |  | $ | 58 |  |


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000320193-21-000065:notes:122]
[same as prior period, unchanged from 0000320193-21-000056:notes:121]

[0000320193-21-000065:notes:123]
The Company had 757 million shares reserved for future issuance under its stock plans as of June 26, 2021. RSUs granted under the Company’s stock plans generally vest over four years, based on continued employment, and are settled upon vesting in shares of the Company’s common stock on a one-for-one basis. RSUs granted under the Company’s stock plans reduce the number of shares available for grant under the plans by a factor of two times the number of RSUs granted. RSUs canceled and shares withheld to satisfy tax withholding obligations increase the number of shares available for grant under the plans utilizing a factor of two times the number of RSUs canceled or shares withheld.

[0000320193-21-000065:notes:124]
[same as prior period, unchanged from 0000320193-21-000056:notes:123]

[0000320193-21-000065:notes:125]
During the three months ended June 26, 2021, Section 16 officers Katherine L. Adams, Timothy D. Cook, Luca Maestri, Deirdre O’Brien and Jeffrey Williams had equity trading plans in place in accordance with Rule 10b5-1(c)(1) under the Exchange Act. An equity trading plan is a written document that pre-establishes the amounts, prices and dates (or formula for determining the amounts, prices and dates) of future purchases or sales of the Company’s stock, including shares acquired under the Company’s employee and director equity plans.

[0000320193-21-000065:notes:126]
[same as prior period, unchanged from 0000320193-21-000056:notes:125]

[0000320193-21-000065:notes:127]
A summary of the Company’s RSU activity and related information for the nine months ended June 26, 2021 is as follows:

[0000320193-21-000065:notes:128]
|  | Number ofRSUs(in thousands) |  | Weighted-AverageGrant Date FairValue Per RSU |  | AggregateFair Value(in millions) |
| Balance as of September 26, 2020 | 310,778 |  |  | $ | 51.58 |  |  |  |
| RSUs granted | 85,052 |  |  | $ | 114.68 |  |  |  |
| RSUs vested | (134,462) |  |  | $ | 51.59 |  |  |  |
| RSUs canceled | (10,396) |  |  | $ | 67.08 |  |  |  |
| Balance as of June 26, 2021 | 250,972 |  |  | $ | 72.31 |  |  | $ | 33,407 |  |

[0000320193-21-000065:notes:129]
The fair value as of the respective vesting dates of RSUs was $7.9 billion and $17.3 billion for the three- and nine-month periods ended June 26, 2021, respectively, and was $5.0 billion and $9.8 billion for the three- and nine-month periods ended June 27, 2020, respectively.

[0000320193-21-000065:notes:130]
[same as prior period, unchanged from 0000320193-21-000056:notes:129]

[0000320193-21-000065:notes:131]
The following table shows share-based compensation expense and the related income tax benefit included in the Condensed Consolidated Statements of Operations for the three- and nine-month periods ended June 26, 2021 and June 27, 2020 (in millions):

[0000320193-21-000065:notes:132]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2021 |  | June 27,2020 |  | June 26,2021 |  | June 27,2020 |
| Share-based compensation expense | $ | 1,960 |  |  | $ | 1,698 |  |  | $ | 5,961 |  |  | $ | 5,105 |  |
| Income tax benefit related to share-based compensation expense | $ | (1,319) |  |  | $ | (740) |  |  | $ | (3,518) |  |  | $ | (1,942) |  |

[0000320193-21-000065:notes:133]
As of June 26, 2021, the total unrecognized compensation cost related to outstanding RSUs and stock options was $15.3 billion, which the Company expects to recognize over a weighted-average period of 2.7 years.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000320193-21-000065:notes:134]
Commitments and Contingencies
Accrued Warranty and Guarantees

[0000320193-21-000065:notes:135]
The following table shows changes in the Company’s accrued warranties and related costs for the three- and nine-month periods ended June 26, 2021 and June 27, 2020 (in millions):

[0000320193-21-000065:notes:136]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2021 |  | June 27,2020 |  | June 26,2021 |  | June 27,2020 |
| Beginning accrued warranty and related costs | $ | 3,784 |  |  | $ | 3,923 |  |  | $ | 3,354 |  |  | $ | 3,570 |  |
| Cost of warranty claims | (636) |  |  | (576) |  |  | (2,008) |  |  | (2,180) |  |
| Accruals for product warranty | 384 |  |  | 557 |  |  | 2,186 |  |  | 2,514 |  |
| Ending accrued warranty and related costs | $ | 3,532 |  |  | $ | 3,904 |  |  | $ | 3,532 |  |  | $ | 3,904 |  |

[0000320193-21-000065:notes:137]
The Company offers an iPhone Upgrade Program, which is available to customers who purchase a qualifying iPhone in the U.S., the U.K. and China mainland. The iPhone Upgrade Program provides customers the right to trade in that iPhone for a specified amount when purchasing a new iPhone, provided certain conditions are met. The Company accounts for the trade-in right as a guarantee liability and recognizes arrangement revenue net of the fair value of such right, with subsequent changes to the guarantee liability recognized within net sales.

[0000320193-21-000065:notes:138]
Concentrations in the Available Sources of Supply of Materials and Product

[0000320193-21-000065:notes:139]
Although most components essential to the Company’s business are generally available from multiple sources, certain components are currently obtained from single or limited sources. The Company also competes for various components with other participants in the markets for smartphones, personal computers, tablets and other electronic devices. Therefore, many components used by the Company, including those that are available from multiple sources, are at times subject to industry-wide shortage and significant commodity pricing fluctuations.

[0000320193-21-000065:notes:140]
The Company uses some custom components that are not commonly used by its competitors, and new products introduced by the Company often utilize custom components available from only one source. When a component or product uses new technologies, initial capacity constraints may exist until the suppliers’ yields have matured or their manufacturing capacities have increased. The continued availability of these components at acceptable prices, or at all, may be affected if suppliers decide to concentrate on the production of common components instead of components customized to meet the Company’s requirements.

[0000320193-21-000065:notes:141]
The Company has entered into agreements for the supply of many components; however, there can be no guarantee that the Company will be able to extend or renew these agreements on similar terms, or at all.

[0000320193-21-000065:notes:142]
Substantially all of the Company’s hardware products are manufactured by outsourcing partners that are located primarily in Asia, with some Mac computers manufactured in the U.S. and Ireland.

[0000320193-21-000065:notes:143]
Unconditional Purchase Obligations

[0000320193-21-000065:notes:144]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of payments for content creation, Internet and telecommunications services and supplier arrangements. As of June 26, 2021, the Company’s total future payments under noncancelable unconditional purchase obligations having a remaining term in excess of one year were $8.8 billion.

[0000320193-21-000065:notes:145]
Contingencies

[0000320193-21-000065:notes:146]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully resolved. The outcome of litigation is inherently uncertain. When a loss related to a legal proceeding or claim is probable and reasonably estimable, the Company accrues its best estimate for the ultimate resolution of the matter. If one or more legal matters were resolved against the Company in a reporting period for amounts above management’s expectations, the Company’s financial condition and operating results for that reporting period could be materially adversely affected. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss greater than a recorded accrual, concerning loss contingencies for asserted legal and other claims, except for the following matters:

[0000320193-21-000065:notes:147]
VirnetX

[0000320193-21-000065:notes:148]
VirnetX, Inc. (“VirnetX”) filed a lawsuit against the Company alleging that certain of the Company’s products infringe on patents owned by VirnetX. On April 11, 2018, a jury returned a verdict against the Company in the U.S. District Court for the Eastern District of Texas (the “Eastern Texas District Court”). The Company appealed the verdict to the U.S. Court of Appeals for the Federal Circuit, which remanded the case back to the Eastern Texas District Court, where a re-trial was held in October 2020. The jury returned a verdict against the Company and awarded damages of $503 million, which the Company has appealed. The Company has challenged the validity of the patents at issue in the re-trial at the U.S. Patent and Trademark Office (the “PTO”), and the PTO has declared the patents invalid, subject to further appeal by VirnetX.

[0000320193-21-000065:notes:149]
iOS Performance Management Cases

[0000320193-21-000065:notes:150]
On April 5, 2018, several U.S. federal actions alleging violation of consumer protection laws, fraud, computer intrusion and other causes of action related to the Company’s performance management feature used in its iPhone operating systems, introduced to certain iPhones in iOS updates 10.2.1 and 11.2, were consolidated through a Multidistrict Litigation process into a single action in the U.S. District Court for the Northern District of California (the “Northern California District Court”). On February 28, 2020, the parties in the Multidistrict Litigation reached a settlement to resolve the U.S. federal and California state class actions. On March 18, 2021, the Northern California District Court granted final approval of the Multidistrict Litigation settlement, which will result in an aggregate payment of $310 million to settle all claims. The Company continues to believe that its iPhones were not defective, that the performance management feature introduced with iOS updates 10.2.1 and 11.2 was intended to, and did, improve customers’ user experience, and that the Company did not make any misleading statements or fail to disclose any material information.

[0000320193-21-000065:notes:151]
French Competition Authority

[0000320193-21-000065:notes:152]
On March 16, 2020, the French Competition Authority (“FCA”) announced its decision that aspects of the Company’s sales and distribution practices in France violate French competition law and issued a fine of €1.1 billion. The Company strongly disagrees with the FCA’s decision and has appealed.

[0000320193-21-000065:notes:153]
Optis

[0000320193-21-000065:notes:154]
Optis Wireless Technology, LLC and related entities (“Optis”) filed a lawsuit in the U.S. District Court for the Eastern District of Texas against the Company alleging that certain of the Company’s products infringe on patents owned by Optis. On August 11, 2020, a jury returned a verdict against the Company and awarded damages of $506 million. In post-trial proceedings, the damages portion of the verdict was set aside, and a retrial was scheduled for August 2021. The case remains pending further proceedings.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000320193-21-000065:notes:155]
[same as prior period, unchanged from 0000320193-21-000056:notes:154]

[0000320193-21-000065:notes:156]
[same as prior period, unchanged from 0000320193-21-000056:notes:155]

[0000320193-21-000065:notes:157]
[same as prior period, unchanged from 0000320193-21-000056:notes:156]

[0000320193-21-000065:notes:158]
The following table shows information by reportable segment for the three- and nine-month periods ended June 26, 2021 and June 27, 2020 (in millions):

[0000320193-21-000065:notes:159]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2021 |  | June 27,2020 |  | June 26,2021 |  | June 27,2020 |
| Americas: |  |  |  |  |  |  |  |
| Net sales | $ | 35,870 |  |  | $ | 27,018 |  |  | $ | 116,486 |  |  | $ | 93,858 |  |
| Operating income | $ | 12,916 |  |  | $ | 7,974 |  |  | $ | 40,751 |  |  | $ | 28,327 |  |
| Europe: |  |  |  |  |  |  |  |
| Net sales | $ | 18,943 |  |  | $ | 14,173 |  |  | $ | 68,513 |  |  | $ | 51,740 |  |
| Operating income | $ | 7,085 |  |  | $ | 4,420 |  |  | $ | 24,939 |  |  | $ | 16,667 |  |
| Greater China: |  |  |  |  |  |  |  |
| Net sales | $ | 14,762 |  |  | $ | 9,329 |  |  | $ | 53,803 |  |  | $ | 32,362 |  |
| Operating income | $ | 6,303 |  |  | $ | 3,414 |  |  | $ | 22,591 |  |  | $ | 12,535 |  |
| Japan: |  |  |  |  |  |  |  |
| Net sales | $ | 6,464 |  |  | $ | 4,966 |  |  | $ | 22,491 |  |  | $ | 16,395 |  |
| Operating income | $ | 3,031 |  |  | $ | 2,114 |  |  | $ | 9,962 |  |  | $ | 7,128 |  |
| Rest of Asia Pacific: |  |  |  |  |  |  |  |
| Net sales | $ | 5,395 |  |  | $ | 4,199 |  |  | $ | 21,164 |  |  | $ | 15,462 |  |
| Operating income | $ | 2,116 |  |  | $ | 1,374 |  |  | $ | 7,805 |  |  | $ | 5,395 |  |

[0000320193-21-000065:notes:160]
A reconciliation of the Company’s segment operating income to the Condensed Consolidated Statements of Operations for the three- and nine-month periods ended June 26, 2021 and June 27, 2020 is as follows (in millions):

[0000320193-21-000065:notes:161]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2021 |  | June 27,2020 |  | June 26,2021 |  | June 27,2020 |
| Segment operating income | $ | 31,451 |  |  | $ | 19,296 |  |  | $ | 106,048 |  |  | $ | 70,052 |  |
| Research and development expense | (5,717) |  |  | (4,758) |  |  | (16,142) |  |  | (13,774) |  |
| Other corporate expenses, net | (1,608) |  |  | (1,447) |  |  | (4,743) |  |  | (4,765) |  |
| Total operating income | $ | 24,126 |  |  | $ | 13,091 |  |  | $ | 85,163 |  |  | $ | 51,513 |  |
