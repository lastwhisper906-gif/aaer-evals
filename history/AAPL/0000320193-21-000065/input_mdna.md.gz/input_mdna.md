# AAPL MD&A — 0000320193-21-000065


## mdna

[0000320193-21-000065:mdna:1]
[same as prior period, unchanged from 0000320193-21-000056:mdna:1]

[0000320193-21-000065:mdna:2]
[same as prior period, unchanged from 0000320193-21-000056:mdna:2]

[0000320193-21-000065:mdna:3]
[same as prior period, unchanged from 0000320193-21-000056:mdna:3]

[0000320193-21-000065:mdna:4]
[same as prior period, unchanged from 0000320193-21-000056:mdna:4]

[0000320193-21-000065:mdna:5]
[same as prior period, unchanged from 0000320193-21-000056:mdna:5]

[0000320193-21-000065:mdna:6]
[same as prior period, unchanged from 0000320193-21-000056:mdna:6]

[0000320193-21-000065:mdna:7]
[same as prior period, unchanged from 0000320193-21-000056:mdna:7]

[0000320193-21-000065:mdna:8]
[same as prior period, unchanged from 0000320193-21-000056:mdna:8]

[0000320193-21-000065:mdna:9]
[same as prior period, unchanged from 0000320193-21-000056:mdna:9]

[0000320193-21-000065:mdna:10]
[same as prior period, unchanged from 0000320193-21-000056:mdna:10]

[0000320193-21-000065:mdna:11]
During the third quarter of 2021, aspects of the Company’s business continued to be affected by the COVID-19 pandemic, with many of the Company’s retail stores, as well as channel partner points of sale, temporarily closed at various times, and a significant number of the Company’s employees working remotely. The Company has reopened substantially all of its offices and retail stores, subject to operating restrictions to protect public health and the health and safety of employees and customers, and it continues to work on safely reopening the remainder of its offices and retail stores, subject to local rules and regulations.

[0000320193-21-000065:mdna:12]
The extent of the continuing impact of the COVID-19 pandemic on the Company’s operational and financial performance is uncertain and will depend on many factors outside the Company’s control, including, without limitation, the timing, extent, trajectory and duration of the pandemic; the availability, distribution and effectiveness of vaccines; the imposition of protective public safety measures; and the impact of the pandemic on the global economy and demand for consumer products. Refer to Part I, Item 1A of the 2020 Form 10-K under the heading “Risk Factors,” for more information.

[0000320193-21-000065:mdna:13]
[same as prior period, unchanged from 0000320193-21-000056:mdna:13]

[0000320193-21-000065:mdna:14]
Third Quarter Fiscal 2021 Highlights

[0000320193-21-000065:mdna:15]
Total net sales increased 36% or $21.7 billion during the third quarter of 2021 compared to the same quarter in 2020, driven by growth in all Products and Services categories. Year-over-year net sales during the third quarter of 2021 also grew in each of the Company’s reportable segments.

[0000320193-21-000065:mdna:16]
During the third quarter of 2021, the Company released the following new products and services:

[0000320193-21-000065:mdna:17]
[same as prior period, unchanged from 0000320193-21-000056:mdna:18]

[0000320193-21-000065:mdna:18]
[same as prior period, unchanged from 0000320193-21-000056:mdna:19]

[0000320193-21-000065:mdna:19]
[same as prior period, unchanged from 0000320193-21-000056:mdna:20]

[0000320193-21-000065:mdna:20]
[same as prior period, unchanged from 0000320193-21-000056:mdna:21]

[0000320193-21-000065:mdna:21]
[same as prior period, unchanged from 0000320193-21-000056:mdna:22]

[0000320193-21-000065:mdna:22]
The Company also announced iOS 15, macOS® Monterey, iPadOS® 15 and watchOS® 8, updates to its operating systems that are expected to be available in the fall of 2021.

[0000320193-21-000065:mdna:23]
The Company repurchased $22.5 billion of its common stock and paid dividends and dividend equivalents of $3.8 billion during the third quarter of 2021.

[0000320193-21-000065:mdna:24]
[same as prior period, unchanged from 0000320193-21-000056:mdna:23]

[0000320193-21-000065:mdna:25]
The following table shows net sales by category for the three- and nine-month periods ended June 26, 2021 and June 27, 2020 (dollars in millions):

[0000320193-21-000065:mdna:26]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2021 |  | June 27,2020 |  | Change |  | June 26,2021 |  | June 27,2020 |  | Change |
| Net sales by category: |  |  |  |  |  |  |  |  |  |  |  |
| iPhone (1) | $ | 39,570 |  |  | $ | 26,418 |  |  | 50 | % |  | $ | 153,105 |  |  | $ | 111,337 |  |  | 38 | % |
| Mac (1) | 8,235 |  |  | 7,079 |  |  | 16 | % |  | 26,012 |  |  | 19,590 |  |  | 33 | % |
| iPad (1) | 7,368 |  |  | 6,582 |  |  | 12 | % |  | 23,610 |  |  | 16,927 |  |  | 39 | % |
| Wearables, Home and Accessories (1)(2) | 8,775 |  |  | 6,450 |  |  | 36 | % |  | 29,582 |  |  | 22,744 |  |  | 30 | % |
| Services (3) | 17,486 |  |  | 13,156 |  |  | 33 | % |  | 50,148 |  |  | 39,219 |  |  | 28 | % |
| Total net sales | $ | 81,434 |  |  | $ | 59,685 |  |  | 36 | % |  | $ | 282,457 |  |  | $ | 209,817 |  |  | 35 | % |

[0000320193-21-000065:mdna:27]
[same as prior period, unchanged from 0000320193-21-000056:mdna:26]

[0000320193-21-000065:mdna:28]
[same as prior period, unchanged from 0000320193-21-000056:mdna:27]

[0000320193-21-000065:mdna:29]
[same as prior period, unchanged from 0000320193-21-000056:mdna:28]

[0000320193-21-000065:mdna:30]
[same as prior period, unchanged from 0000320193-21-000056:mdna:29]

[0000320193-21-000065:mdna:31]
iPhone net sales increased during the third quarter and first nine months of 2021 compared to the same periods in 2020 due primarily to higher net sales from the Company’s new iPhone models launched in the first quarter of 2021.

[0000320193-21-000065:mdna:32]
[same as prior period, unchanged from 0000320193-21-000056:mdna:31]

[0000320193-21-000065:mdna:33]
Mac net sales increased during the third quarter of 2021 compared to the third quarter of 2020 due primarily to higher net sales of MacBook Air® and iMac. Year-over-year Mac net sales increased during the first nine months of 2021 due primarily to higher net sales of MacBook Air and MacBook Pro®.

[0000320193-21-000065:mdna:34]
[same as prior period, unchanged from 0000320193-21-000056:mdna:33]

[0000320193-21-000065:mdna:35]
iPad net sales increased during the third quarter of 2021 compared to the third quarter of 2020 due to higher net sales of iPad Air®. Year-over-year iPad net sales increased during the first nine months of 2021 due to higher net sales of iPad Air, iPad Pro and the 10-inch version of iPad.

[0000320193-21-000065:mdna:36]
[same as prior period, unchanged from 0000320193-21-000056:mdna:35]

[0000320193-21-000065:mdna:37]
Wearables, Home and Accessories net sales increased during the third quarter and first nine months of 2021 compared to the same periods in 2020 due primarily to higher net sales of Apple Watch and accessories.

[0000320193-21-000065:mdna:38]
[same as prior period, unchanged from 0000320193-21-000056:mdna:37]

[0000320193-21-000065:mdna:39]
Services net sales increased during the third quarter of 2021 compared to the third quarter of 2020 due primarily to higher net sales from advertising, the App Store and AppleCare. Year-over-year Services net sales increased during the first nine months of 2021 due primarily to higher net sales from advertising, the App Store and cloud services.

[0000320193-21-000065:mdna:40]
[same as prior period, unchanged from 0000320193-21-000056:mdna:39]

[0000320193-21-000065:mdna:41]
[same as prior period, unchanged from 0000320193-21-000056:mdna:40]

[0000320193-21-000065:mdna:42]
The following table shows net sales by reportable segment for the three- and nine-month periods ended June 26, 2021 and June 27, 2020 (dollars in millions):

[0000320193-21-000065:mdna:43]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2021 |  | June 27,2020 |  | Change |  | June 26,2021 |  | June 27,2020 |  | Change |
| Net sales by reportable segment: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 35,870 |  |  | $ | 27,018 |  |  | 33 | % |  | $ | 116,486 |  |  | $ | 93,858 |  |  | 24 | % |
| Europe | 18,943 |  |  | 14,173 |  |  | 34 | % |  | 68,513 |  |  | 51,740 |  |  | 32 | % |
| Greater China | 14,762 |  |  | 9,329 |  |  | 58 | % |  | 53,803 |  |  | 32,362 |  |  | 66 | % |
| Japan | 6,464 |  |  | 4,966 |  |  | 30 | % |  | 22,491 |  |  | 16,395 |  |  | 37 | % |
| Rest of Asia Pacific | 5,395 |  |  | 4,199 |  |  | 28 | % |  | 21,164 |  |  | 15,462 |  |  | 37 | % |
| Total net sales | $ | 81,434 |  |  | $ | 59,685 |  |  | 36 | % |  | $ | 282,457 |  |  | $ | 209,817 |  |  | 35 | % |

[0000320193-21-000065:mdna:44]
[same as prior period, unchanged from 0000320193-21-000056:mdna:43]

[0000320193-21-000065:mdna:45]
Americas net sales increased during the third quarter of 2021 compared to the third quarter of 2020 due primarily to higher net sales of iPhone, Services and Wearables, Home and Accessories. Year-over-year Americas net sales increased during the first nine months of 2021 due primarily to higher net sales of iPhone, Services and Mac.

[0000320193-21-000065:mdna:46]
[same as prior period, unchanged from 0000320193-21-000056:mdna:45]

[0000320193-21-000065:mdna:47]
Europe net sales increased during the third quarter of 2021 compared to the third quarter of 2020 due primarily to higher net sales of iPhone, Services and Wearables, Home and Accessories. Year-over-year Europe net sales increased during the first nine months of 2021 due primarily to higher net sales of iPhone, iPad and Mac. The movement of foreign currencies in Europe relative to the U.S. dollar had a net favorable impact on Europe net sales during the third quarter and first nine months of 2021.

[0000320193-21-000065:mdna:48]
[same as prior period, unchanged from 0000320193-21-000056:mdna:47]

[0000320193-21-000065:mdna:49]
Greater China net sales increased during the third quarter of 2021 compared to the third quarter of 2020 due primarily to higher net sales of iPhone and Services. Year-over-year Greater China net sales increased during the first nine months of 2021 due primarily to higher net sales of iPhone and iPad. The strength of the Chinese renminbi relative to the U.S. dollar had a favorable impact on Greater China net sales during the third quarter and first nine months of 2021.

[0000320193-21-000065:mdna:50]
[same as prior period, unchanged from 0000320193-21-000056:mdna:49]

[0000320193-21-000065:mdna:51]
Japan net sales increased during the third quarter of 2021 compared to the third quarter of 2020 due primarily to higher net sales of iPhone. Year-over-year Japan net sales increased during the first nine months of 2021 due primarily to higher net sales of iPhone and Services. The strength of the Japanese yen relative to the U.S. dollar had a favorable impact on Japan net sales during the first nine months of 2021.

[0000320193-21-000065:mdna:52]
[same as prior period, unchanged from 0000320193-21-000056:mdna:51]

[0000320193-21-000065:mdna:53]
Rest of Asia Pacific net sales increased during the third quarter and first nine months of 2021 compared to the same periods in 2020 due primarily to higher net sales of iPhone, Wearables, Home and Accessories and Services. The movement of foreign currencies in the Rest of Asia Pacific relative to the U.S. dollar had a favorable impact on Rest of Asia Pacific net sales during the third quarter and first nine months of 2021.

[0000320193-21-000065:mdna:54]
[same as prior period, unchanged from 0000320193-21-000056:mdna:53]

[0000320193-21-000065:mdna:55]
Products and Services gross margin and gross margin percentage for the three- and nine-month periods ended June 26, 2021 and June 27, 2020 were as follows (dollars in millions):

[0000320193-21-000065:mdna:56]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2021 |  | June 27,2020 |  | June 26,2021 |  | June 27,2020 |
| Gross margin: |  |  |  |  |  |  |  |
| Products | $ | 23,049 |  |  | $ | 13,836 |  |  | $ | 82,833 |  |  | $ | 54,509 |  |
| Services | 12,206 |  |  | 8,844 |  |  | 34,829 |  |  | 25,758 |  |
| Total gross margin | $ | 35,255 |  |  | $ | 22,680 |  |  | $ | 117,662 |  |  | $ | 80,267 |  |

[0000320193-21-000065:mdna:57]
| Gross margin percentage: |  |  |  |  |  |  |  |
| Products | 36.0 | % |  | 29.7 | % |  | 35.7 | % |  | 32.0 | % |
| Services | 69.8 | % |  | 67.2 | % |  | 69.5 | % |  | 65.7 | % |
| Total gross margin percentage | 43.3 | % |  | 38.0 | % |  | 41.7 | % |  | 38.3 | % |

[0000320193-21-000065:mdna:58]
[same as prior period, unchanged from 0000320193-21-000056:mdna:57]

[0000320193-21-000065:mdna:59]
Products gross margin increased during the third quarter and first nine months of 2021 compared to the same periods in 2020 due primarily to higher Products volume, a different Products mix and the strength in foreign currencies relative to the U.S. dollar.

[0000320193-21-000065:mdna:60]
Products gross margin percentage increased during the third quarter of 2021 compared to the third quarter of 2020 due primarily to a different Products mix, the strength in foreign currencies relative to the U.S. dollar and improved leverage. Year-over-year Products gross margin percentage increased during the first nine months of 2021 due primarily to improved leverage, a different Products mix and the strength in foreign currencies relative to the U.S. dollar.

[0000320193-21-000065:mdna:61]
[same as prior period, unchanged from 0000320193-21-000056:mdna:60]

[0000320193-21-000065:mdna:62]
Services gross margin increased during the third quarter and first nine months of 2021 compared to the same periods in 2020 due primarily to higher Services net sales, a different Services mix and the strength in foreign currencies relative to the U.S. dollar.

[0000320193-21-000065:mdna:63]
Year-over-year Services gross margin percentage increased during the third quarter and first nine months of 2021 due primarily to a different Services mix and improved leverage, partially offset by higher Services costs.

[0000320193-21-000065:mdna:64]
[same as prior period, unchanged from 0000320193-21-000056:mdna:63]

[0000320193-21-000065:mdna:65]
[same as prior period, unchanged from 0000320193-21-000056:mdna:64]

[0000320193-21-000065:mdna:66]
Operating expenses for the three- and nine-month periods ended June 26, 2021 and June 27, 2020 were as follows (dollars in millions):

[0000320193-21-000065:mdna:67]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2021 |  | June 27,2020 |  | June 26,2021 |  | June 27,2020 |
| Research and development | $ | 5,717 |  |  | $ | 4,758 |  |  | $ | 16,142 |  |  | $ | 13,774 |  |
| Percentage of total net sales | 7 | % |  | 8 | % |  | 6 | % |  | 7 | % |
| Selling, general and administrative | $ | 5,412 |  |  | $ | 4,831 |  |  | $ | 16,357 |  |  | $ | 14,980 |  |
| Percentage of total net sales | 7 | % |  | 8 | % |  | 6 | % |  | 7 | % |
| Total operating expenses | $ | 11,129 |  |  | $ | 9,589 |  |  | $ | 32,499 |  |  | $ | 28,754 |  |
| Percentage of total net sales | 14 | % |  | 16 | % |  | 12 | % |  | 14 | % |

[0000320193-21-000065:mdna:68]
[same as prior period, unchanged from 0000320193-21-000056:mdna:67]

[0000320193-21-000065:mdna:69]
The growth in research and development (“R&D”) expense during the third quarter of 2021 compared to the third quarter of 2020 was driven primarily by increases in headcount-related expenses, and material and equipment costs. Year-over-year R&D expense increased during the first nine months of 2021 due primarily to higher headcount-related expenses and R&D-related professional services. The Company continues to believe that focused investments in R&D are critical to its future growth and competitive position in the marketplace, and to the development of new and updated products and services that are central to the Company’s core business strategy.

[0000320193-21-000065:mdna:70]
[same as prior period, unchanged from 0000320193-21-000056:mdna:69]

[0000320193-21-000065:mdna:71]
The growth in selling, general and administrative expense during the third quarter of 2021 compared to the third quarter of 2020 was driven primarily by increases in headcount-related and advertising expenses. Year-over-year selling, general and administrative expense increased during the first nine months of 2021 due primarily to higher headcount-related and variable selling expenses.

[0000320193-21-000065:mdna:72]
[same as prior period, unchanged from 0000320193-21-000056:mdna:71]

[0000320193-21-000065:mdna:73]
Other income/(expense), net (“OI&E”) for the three- and nine-month periods ended June 26, 2021 and June 27, 2020 was as follows (dollars in millions):

[0000320193-21-000065:mdna:74]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2021 |  | June 27,2020 |  | Change |  | June 26,2021 |  | June 27,2020 |  | Change |
| Interest and dividend income | $ | 719 |  |  | $ | 901 |  |  |  |  | $ | 2,184 |  |  | $ | 2,995 |  |  |  |
| Interest expense | (665) |  |  | (697) |  |  |  |  | (1,973) |  |  | (2,239) |  |  |  |
| Other income/(expense), net | 189 |  |  | (158) |  |  |  |  | 585 |  |  | (79) |  |  |  |
| Total other income/(expense), net | $ | 243 |  |  | $ | 46 |  |  | 428 | % |  | $ | 796 |  |  | $ | 677 |  |  | 18 | % |

[0000320193-21-000065:mdna:75]
OI&E increased during the third quarter of 2021 compared to the third quarter of 2020 due primarily to a favorable carrying value adjustment of non-marketable securities and smaller impairments of securities, partially offset by lower interest income. Year-over-year OI&E increased during the first nine months of 2021 due primarily to smaller impairments of securities, lower interest expense and favorable carrying value adjustments of non-marketable securities, partially offset by lower interest income.

[0000320193-21-000065:mdna:76]
The weighted-average interest rate earned by the Company on its cash, cash equivalents and marketable securities was 1.32% and 1.74% in the third quarter of 2021 and 2020, respectively, and 1.40% and 1.95% in the first nine months of 2021 and 2020, respectively.

[0000320193-21-000065:mdna:77]
[same as prior period, unchanged from 0000320193-21-000056:mdna:77]

[0000320193-21-000065:mdna:78]
Provision for income taxes, effective tax rate and statutory federal income tax rate for the three- and nine-month periods ended June 26, 2021 and June 27, 2020 were as follows (dollars in millions):

[0000320193-21-000065:mdna:79]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2021 |  | June 27,2020 |  | June 26,2021 |  | June 27,2020 |
| Provision for income taxes | $ | 2,625 |  |  | $ | 1,884 |  |  | $ | 11,830 |  |  | $ | 7,452 |  |
| Effective tax rate | 10.8 | % |  | 14.3 | % |  | 13.8 | % |  | 14.3 | % |
| Statutory federal income tax rate | 21 | % |  | 21 | % |  | 21 | % |  | 21 | % |

[0000320193-21-000065:mdna:80]
The Company’s effective tax rate for the third quarter and first nine months of 2021 was lower than the statutory federal income tax rate due primarily to a lower effective rate on foreign earnings, tax benefits from share-based compensation, and the favorable impact of changes in unrecognized tax benefits, partially offset by state income taxes.

[0000320193-21-000065:mdna:81]
The Company’s effective tax rate for the third quarter of 2021 was lower compared to the third quarter of 2020 due primarily to the favorable impact of changes in unrecognized tax benefits, a higher mix of foreign earnings, and higher tax benefits from share-based compensation. The Company’s effective tax rate for the first nine months of 2021 was lower compared to the same period in 2020 due primarily to higher tax benefits from share-based compensation, the favorable impact of changes in unrecognized tax benefits, and a higher mix of foreign earnings, partially offset by a one-time adjustment in 2020 of U.S. foreign tax credits in response to regulations issued by the U.S. Department of the Treasury in December 2019.

[0000320193-21-000065:mdna:82]
[same as prior period, unchanged from 0000320193-21-000056:mdna:82]

[0000320193-21-000065:mdna:83]
The following tables present selected financial information and statistics as of June 26, 2021 and September 26, 2020 and for the first nine months of 2021 and 2020 (in millions):

[0000320193-21-000065:mdna:84]
|  | June 26,2021 |  | September 26,2020 |
| Cash, cash equivalents and marketable securities (1) | $ | 193,644 |  |  | $ | 191,830 |  |
| Property, plant and equipment, net | $ | 38,615 |  |  | $ | 36,766 |  |
| Commercial paper | $ | 8,000 |  |  | $ | 4,996 |  |
| Total term debt | $ | 113,791 |  |  | $ | 107,440 |  |
| Working capital | $ | 6,669 |  |  | $ | 38,321 |  |

[0000320193-21-000065:mdna:85]
|  | Nine Months Ended |
|  | June 26,2021 |  | June 27,2020 |
| Cash generated by operating activities | $ | 83,838 |  |  | $ | 60,098 |  |
| Cash used in investing activities | $ | (15,380) |  |  | $ | (9,820) |  |
| Cash used in financing activities | $ | (72,971) |  |  | $ | (65,463) |  |

[0000320193-21-000065:mdna:86]
(1)As of June 26, 2021 and September 26, 2020, total marketable securities included $18.9 billion and $18.6 billion, respectively, that was restricted from general use, related to the State Aid Decision (refer to Note 5, “Income Taxes” in the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Form 10-Q) and other agreements.

[0000320193-21-000065:mdna:87]
[same as prior period, unchanged from 0000320193-21-000056:mdna:87]

[0000320193-21-000065:mdna:88]
In connection with the State Aid Decision, as of June 26, 2021, the adjusted recovery amount of €12.7 billion plus interest of €1.2 billion was funded into escrow, where it will remain restricted from general use pending the conclusion of all legal proceedings. Further information regarding the State Aid Decision can be found in Part I, Item 1 of this Form 10-Q in the Notes to Condensed Consolidated Financial Statements in Note 5, “Income Taxes.”

[0000320193-21-000065:mdna:89]
[same as prior period, unchanged from 0000320193-21-000056:mdna:89]

[0000320193-21-000065:mdna:90]
During the nine months ended June 26, 2021, cash generated by operating activities of $83.8 billion was a result of $74.1 billion of net income, non-cash adjustments to net income of $12.8 billion and a decrease in the net change in operating assets and liabilities of $3.1 billion. Cash used in investing activities of $15.4 billion during the nine months ended June 26, 2021 consisted primarily of cash used for purchases of marketable securities, net of maturities and sales, of $7.4 billion and cash used to acquire property, plant and equipment of $7.9 billion. Cash used in financing activities of $73.0 billion during the nine months ended June 26, 2021 consisted primarily of cash used to repurchase common stock of $66.2 billion, cash used to pay dividends and dividend equivalents of $10.8 billion and cash used to repay or redeem term debt of $7.5 billion, partially offset by net proceeds from issuance of term debt of $13.9 billion.

[0000320193-21-000065:mdna:91]
During the nine months ended June 27, 2020, cash generated by operating activities of $60.1 billion was a result of $44.7 billion of net income, non-cash adjustments to net income of $13.5 billion and an increase in the net change in operating assets and liabilities of $1.8 billion. Cash used in investing activities of $9.8 billion during the nine months ended June 27, 2020 consisted primarily of cash used for purchases of marketable securities, net of maturities and sales, of $2.0 billion and cash used to acquire property, plant and equipment of $5.5 billion. Cash used in financing activities of $65.5 billion during the nine months ended June 27, 2020 consisted primarily of cash used to repurchase common stock of $55.2 billion, cash used to pay dividends and dividend equivalents of $10.6 billion and cash used to repay or redeem term debt of $12.6 billion, partially offset by net proceeds from issuance of term debt of $10.6 billion and proceeds from repurchase agreements of $5.2 billion.

[0000320193-21-000065:mdna:92]
[same as prior period, unchanged from 0000320193-21-000056:mdna:92]

[0000320193-21-000065:mdna:93]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses the net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of June 26, 2021, the Company had $8.0 billion of Commercial Paper outstanding, with a weighted-average interest rate of 0.04% and maturities generally less than nine months.

[0000320193-21-000065:mdna:94]
As of June 26, 2021, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $113.2 billion (collectively the “Notes”). During the first nine months of 2021, the Company issued $13.9 billion and repaid or redeemed $7.5 billion of Notes. The Company has entered, and in the future may enter, into interest rate swaps to manage interest rate risk on the Notes. In addition, the Company has entered, and in the future may enter, into foreign currency swaps to manage foreign currency risk on the Notes.

[0000320193-21-000065:mdna:95]
[same as prior period, unchanged from 0000320193-21-000056:mdna:95]

[0000320193-21-000065:mdna:96]
[same as prior period, unchanged from 0000320193-21-000056:mdna:96]

[0000320193-21-000065:mdna:97]
As of June 26, 2021, the Company was authorized to purchase up to $315 billion of the Company’s common stock under a share repurchase program (the “Program”). During the nine months ended June 26, 2021, the Company repurchased 515 million shares of its common stock for $65.5 billion, including 32 million shares initially delivered under a $5.0 billion accelerated share repurchase agreement (“ASR”) entered into in May 2021, bringing the total utilization under the Program to $234.1 billion. The Program does not obligate the Company to acquire any specific number of shares. Under the Program, shares may be repurchased in privately negotiated and/or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).

[0000320193-21-000065:mdna:98]
As of June 26, 2021, the Company’s quarterly cash dividend was $0.22 per share. The Company intends to increase its dividend on an annual basis, subject to declaration by the Board of Directors.

[0000320193-21-000065:mdna:99]
[same as prior period, unchanged from 0000320193-21-000056:mdna:99]

[0000320193-21-000065:mdna:100]
[same as prior period, unchanged from 0000320193-21-000056:mdna:100]

[0000320193-21-000065:mdna:101]
The Company has lease arrangements for certain equipment and facilities, including retail, corporate, manufacturing and data center space. The Company’s retail store and other facility leases typically have original terms not exceeding 10 years and generally contain multi-year renewal options. The Company’s total fixed lease payment obligation of $13.7 billion as of June 26, 2021 included future payments under leases that had commenced as of June 26, 2021, and were therefore recorded on the Company’s Condensed Consolidated Balance Sheet, as well as leases that had been signed but not yet commenced as of June 26, 2021.

[0000320193-21-000065:mdna:102]
[same as prior period, unchanged from 0000320193-21-000056:mdna:102]

[0000320193-21-000065:mdna:103]
The Company utilizes several outsourcing partners to manufacture sub-assemblies for the Company’s products and to perform final assembly and testing of finished products. These outsourcing partners acquire components and build product based on demand information supplied by the Company, which typically covers periods up to 150 days. The Company also obtains individual components for its products from a wide variety of individual suppliers. As of June 26, 2021, the Company expects to pay $38.2 billion under manufacturing-related supplier arrangements, which are primarily noncancelable.

[0000320193-21-000065:mdna:104]
[same as prior period, unchanged from 0000320193-21-000056:mdna:104]

[0000320193-21-000065:mdna:105]
The Company’s other purchase obligations primarily consist of noncancelable obligations to acquire capital assets, including product tooling and manufacturing process equipment, and noncancelable obligations related to advertising, content creation and Internet and telecommunications services. As of June 26, 2021, the Company had other purchase obligations of $9.1 billion.

[0000320193-21-000065:mdna:106]
[same as prior period, unchanged from 0000320193-21-000056:mdna:106]

[0000320193-21-000065:mdna:107]
As of June 26, 2021, the balance of the deemed repatriation tax payable imposed by the U.S. Tax Cuts and Jobs Act (the “Act”) was $24.9 billion, all of which was included in other non-current liabilities in the Company’s Condensed Consolidated Balance Sheet. The Company pays the deemed repatriation tax payable in installments in accordance with the Act.

[0000320193-21-000065:mdna:108]
[same as prior period, unchanged from 0000320193-21-000056:mdna:108]

[0000320193-21-000065:mdna:109]
[same as prior period, unchanged from 0000320193-21-000056:mdna:109]

[0000320193-21-000065:mdna:110]
[same as prior period, unchanged from 0000320193-21-000056:mdna:110]

[0000320193-21-000065:mdna:111]
[same as prior period, unchanged from 0000320193-21-000056:mdna:111]

[0000320193-21-000065:mdna:112]
[same as prior period, unchanged from 0000320193-21-000056:mdna:112]
