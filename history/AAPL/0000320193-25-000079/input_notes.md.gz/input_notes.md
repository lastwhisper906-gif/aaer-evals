# AAPL notes — 0000320193-25-000079


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000320193-25-000079:notes:1]
Portions of the Registrant’s definitive proxy statement relating to its 2026 annual meeting of shareholders are incorporated by reference into Part III of this Annual Report on Form 10-K where indicated. The Registrant’s definitive proxy statement will be filed with the U.S. Securities and Exchange Commission within 120 days after the end of the fiscal year to which this report relates.


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0000320193-25-000079:notes:2]
The Company’s management, led by its Head of Corporate Information Security, has overall responsibility for identifying, assessing and managing any material risks from cybersecurity threats. The Company’s Head of Corporate Information Security leads a dedicated Information Security team of highly skilled individuals with experience across industries that, among other things, develops and distributes information security policies, standards and procedures; engages in employee cybersecurity training; implements security controls; assesses security risk and compliance posture; monitors and responds to security events; and executes security testing and assessments. The Company’s Head of Corporate Information Security has extensive knowledge and skills gained from over 25 years of experience in the cybersecurity industry, including serving in leadership positions at other large technology companies and leading the Company’s Information Security team since 2016.

[0000320193-25-000079:notes:3]
The Company’s Information Security team coordinates with teams across the Company to prevent, respond to and manage security incidents, and engages third parties, as appropriate, to assess, test or otherwise assist with aspects of its security processes and incident response. A dedicated Supplier Trust team manages information security risks the Company is exposed to through its supplier relationships. The Company has processes to log, track, address, and escalate for further assessment and report, as appropriate, cybersecurity incidents across the Company and its suppliers to senior management and the Audit and Finance Committee (“Audit Committee”) of the Board. The Company’s enterprise risk management program is designed to identify, assess, and monitor the Company’s business risks, including financial, operational, compliance and reputational risks, and reflects management’s assessment of cybersecurity risks.

[0000320193-25-000079:notes:4]
The Audit Committee assists the Board in the oversight and monitoring of cybersecurity matters. The Audit Committee regularly reviews and discusses the Company’s cybersecurity risks with management, including the Company’s Head of Corporate Information Security, its General Counsel and the Heads of Compliance and Business Conduct, Business Assurance, and Internal Audit, and receives updates, as necessary, regarding cybersecurity incidents. The Chair of the Audit Committee regularly reports the substance of such reviews and discussions to the Board, as necessary, and recommends to the Board such actions as the Audit Committee deems appropriate.

[0000320193-25-000079:notes:5]
For a discussion of the Company’s cybersecurity-related risks, see Item 1A of this Form 10-K under the heading “Risk Factors.”


## cyd:CybersecurityRiskManagementExpertiseOfManagementResponsibleTextBlock

[0000320193-25-000079:notes:6]
The Company’s Head of Corporate Information Security leads a dedicated Information Security team of highly skilled individuals with experience across industriesThe Company’s Head of Corporate Information Security has extensive knowledge and skills gained from over 25 years of experience in the cybersecurity industry, including serving in leadership positions at other large technology companies and leading the Company’s Information Security team since 2016.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000320193-25-000079:notes:7]
Summary of Significant Accounting Policies
Basis of Presentation and Preparation

[0000320193-25-000079:notes:8]
The consolidated financial statements include the accounts of Apple Inc. and its wholly owned subsidiaries. The preparation of these consolidated financial statements and accompanying notes in conformity with GAAP requires the use of management estimates. Certain prior period amounts in the notes to consolidated financial statements have been reclassified to conform to the current period’s presentation.

[0000320193-25-000079:notes:9]
The Company’s fiscal year is the 52- or 53-week period that ends on the last Saturday of September. An additional week is included in the first fiscal quarter every five or six years to realign the Company’s fiscal quarters with calendar quarters, which occurred in the first fiscal quarter of 2023. The Company’s fiscal years 2025 and 2024 spanned 52 weeks each, whereas fiscal year 2023 spanned 53 weeks. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in September and the associated quarters, months and periods of those fiscal years.

[0000320193-25-000079:notes:10]
Recently Adopted Accounting Pronouncements

[0000320193-25-000079:notes:11]
Segment Reporting

[0000320193-25-000079:notes:12]
Beginning with the 2025 annual reporting period, the Company adopted the FASB’s ASU No. 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures (“ASU 2023-07”), which requires the Company to disclose segment expenses that are significant and regularly provided to the Company’s chief operating decision maker (“CODM”). In addition, ASU 2023-07 requires the Company to disclose the title and position of its CODM and how the CODM uses segment profit or loss information in assessing segment performance and deciding how to allocate resources. The Company adopted ASU 2023-07 using a retrospective transition method.

[0000320193-25-000079:notes:13]
Revenue

[0000320193-25-000079:notes:14]
The Company records revenue net of taxes collected from customers that are remitted to governmental authorities.

[0000320193-25-000079:notes:15]
Share-Based Compensation

[0000320193-25-000079:notes:16]
The Company recognizes share-based compensation expense on a straight-line basis for its estimate of equity awards that will ultimately vest.

[0000320193-25-000079:notes:17]
Cash Equivalents

[0000320193-25-000079:notes:18]
All highly liquid investments with maturities of three months or less at the date of purchase are treated as cash equivalents.

[0000320193-25-000079:notes:19]
Trade Receivables

[0000320193-25-000079:notes:20]
Trade receivables are stated at transaction price.

[0000320193-25-000079:notes:21]
Marketable Securities

[0000320193-25-000079:notes:22]
The cost of securities sold is determined using the specific identification method.

[0000320193-25-000079:notes:23]
Inventories

[0000320193-25-000079:notes:24]
Inventories are measured using the first-in, first-out method.

[0000320193-25-000079:notes:25]
Property, Plant and Equipment

[0000320193-25-000079:notes:26]
Property, plant and equipment are stated at cost. Depreciation on property, plant and equipment is recognized on a straight-line basis.

[0000320193-25-000079:notes:27]
Derivative Instruments

[0000320193-25-000079:notes:28]
The Company presents derivative assets and liabilities at their gross fair values in the Consolidated Balance Sheets.

[0000320193-25-000079:notes:29]
Income Taxes

[0000320193-25-000079:notes:30]
The Company records certain deferred tax assets and liabilities in connection with the minimum tax on certain foreign earnings created by the TCJA.

[0000320193-25-000079:notes:31]
Leases

[0000320193-25-000079:notes:32]
The Company combines and accounts for lease and nonlease components as a single lease component for leases of corporate and retail facilities.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0000320193-25-000079:notes:33]
The Company recognizes revenue at the amount to which it expects to be entitled when control of products or services is transferred to its customers. Control is generally transferred when the Company has a present right to payment and title and the significant risks and rewards of ownership of products or services are transferred to its customers. For most of the Company’s Products net sales, control transfers when products are shipped. For the Company’s Services net sales, control transfers over time as services are delivered. Payment for Products and Services net sales is collected within a short period following transfer of control or commencement of delivery of services, as applicable.

[0000320193-25-000079:notes:34]
The Company records reductions to Products net sales related to future product returns, price protection and other customer incentive programs based on the Company’s expectations and historical experience.

[0000320193-25-000079:notes:35]
For arrangements with multiple performance obligations, which represent promises within an arrangement that are distinct, the Company allocates revenue to all distinct performance obligations based on their relative stand-alone selling prices (“SSPs”). When available, the Company uses observable prices to determine SSPs. When observable prices are not available, SSPs are established that reflect the Company’s best estimates of what the selling prices of the performance obligations would be if they were sold regularly on a stand-alone basis. The Company’s process for estimating SSPs without observable prices considers multiple factors that may vary depending upon the unique facts and circumstances related to each performance obligation including, where applicable, prices charged by the Company for similar offerings, market trends in the pricing for similar offerings, product-specific business objectives and the estimated cost to provide the performance obligation.

[0000320193-25-000079:notes:36]
The Company has identified the performance obligations regularly included in arrangements involving the sale of iPhone, Mac and iPad. The first material performance obligation, which represents the substantial portion of the allocated sales price, is the hardware and bundled software delivered at the time of sale. The second material performance obligation is the right to receive certain product-related bundled services, which include iCloud®, Siri® and Maps. The Company allocates revenue and any related discounts to all of its performance obligations based on their relative SSPs. Because the Company lacks observable prices for product-related bundled services, the allocation of revenue is based on the Company’s estimated SSPs. Revenue allocated to the delivered hardware and bundled software is recognized when control has transferred to the customer, which generally occurs when the product is shipped. Revenue allocated to product-related bundled services is deferred and recognized on a straight-line basis over the estimated period they are expected to be provided.

[0000320193-25-000079:notes:37]
For certain long-term service arrangements, the Company has performance obligations for services it has not yet delivered. For these arrangements, the Company does not have a right to bill for the undelivered services. The Company has determined that any unbilled consideration relates entirely to the value of the undelivered services. Accordingly, the Company has not recognized revenue, and does not disclose amounts, related to these undelivered services.

[0000320193-25-000079:notes:38]
For the sale of third-party products where the Company obtains control of the product before transferring it to the customer, the Company recognizes revenue based on the gross amount billed to customers. The Company considers multiple factors when determining whether it obtains control of third-party products, including evaluating if it can establish the price of the product, retains inventory risk for tangible products or has the responsibility for ensuring acceptability of the product. For third-party applications sold through the App Store, the Company does not obtain control of the product before transferring it to the customer. Therefore, the Company accounts for all third-party application–related sales on a net basis by recognizing in Services net sales only the commission it retains.


## us-gaap:DerivativesPolicyTextBlock

[0000320193-25-000079:notes:39]
All derivative instruments are recorded in the Consolidated Balance Sheets at fair value. The accounting treatment for derivative gains and losses is based on intended use and hedge designation.

[0000320193-25-000079:notes:40]
Gains and losses arising from amounts that are included in the assessment of cash flow hedge effectiveness are initially deferred in accumulated other comprehensive income/(loss) and subsequently reclassified into earnings when the hedged transaction affects earnings, and in the same line item in the Consolidated Statements of Operations. Gains and losses arising from amounts that are included in the assessment of fair value hedge effectiveness are recognized in the Consolidated Statements of Operations line item to which the hedge relates along with offsetting losses and gains related to the change in value of the hedged item.

[0000320193-25-000079:notes:41]
For derivative instruments designated as cash flow and fair value hedges, amounts excluded from the assessment of hedge effectiveness are recognized on a straight-line basis over the life of the hedge in the Consolidated Statements of Operations line item to which the hedge relates. Changes in the fair value of amounts excluded from the assessment of hedge effectiveness are recognized in other comprehensive income/(loss).

[0000320193-25-000079:notes:42]
Gains and losses arising from changes in the fair values of derivative instruments that are not designated as accounting hedges are recognized in the Consolidated Statements of Operations.

[0000320193-25-000079:notes:43]
The Company classifies cash flows related to derivative instruments in the same section of the Consolidated Statements of Cash Flows as the items being hedged, which are generally classified as operating activities.


## us-gaap:LesseeLeasesPolicyTextBlock

[0000320193-25-000079:notes:44]
The Company combines and accounts for lease and nonlease components as a single lease component for leases of corporate and retail facilities.
The discount rates related to the Company’s lease liabilities are generally based on estimates of the Company’s incremental borrowing rate, as the discount rates implicit in the Company’s leases cannot be readily determined.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000320193-25-000079:notes:45]
Revenue
The Company recognizes revenue at the amount to which it expects to be entitled when control of products or services is transferred to its customers. Control is generally transferred when the Company has a present right to payment and title and the significant risks and rewards of ownership of products or services are transferred to its customers. For most of the Company’s Products net sales, control transfers when products are shipped. For the Company’s Services net sales, control transfers over time as services are delivered. Payment for Products and Services net sales is collected within a short period following transfer of control or commencement of delivery of services, as applicable.

[0000320193-25-000079:notes:46]
The following table shows disaggregated net sales, as well as the portion of total net sales that was previously deferred, for 2025, 2024 and 2023 (in millions):

[0000320193-25-000079:notes:47]
|  | 2025 |  | 2024 |  | 2023 |
| iPhone | $ | 209,586 |  |  | $ | 201,183 |  |  | $ | 200,583 |  |
| Mac | 33,708 |  |  | 29,984 |  |  | 29,357 |  |
| iPad | 28,023 |  |  | 26,694 |  |  | 28,300 |  |
| Wearables, Home and Accessories | 35,686 |  |  | 37,005 |  |  | 39,845 |  |
| Services (1) | 109,158 |  |  | 96,169 |  |  | 85,200 |  |
| Total net sales | $ | 416,161 |  |  | $ | 391,035 |  |  | $ | 383,285 |  |
| Portion of total net sales that was included in deferred revenue as of the beginning of the period | $ | 8,229 |  |  | $ | 7,728 |  |  | $ | 8,169 |  |

[0000320193-25-000079:notes:48]
(1)Services net sales include amortization of the deferred value of services bundled in the sales price of certain products.

[0000320193-25-000079:notes:49]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 13, “Segment Information and Geographic Data” for 2025, 2024 and 2023, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.

[0000320193-25-000079:notes:50]
As of September 27, 2025 and September 28, 2024, the Company had total deferred revenue of $13.7 billion and $12.8 billion, respectively. As of September 27, 2025, the Company expects 66% of total deferred revenue to be realized in less than a year, 23% within one-to-two years, 9% within two-to-three years and 2% in greater than three years.


## us-gaap:EarningsPerShareTextBlock

[0000320193-25-000079:notes:51]
Earnings Per Share
The following table shows the computation of basic and diluted earnings per share for 2025, 2024 and 2023 (net income in millions and shares in thousands):

[0000320193-25-000079:notes:52]
|  | 2025 |  | 2024 |  | 2023 |
| Numerator: |  |  |  |  |  |
| Net income | $ | 112,010 |  |  | $ | 93,736 |  |  | $ | 96,995 |  |
| Denominator: |  |  |  |  |  |
| Weighted-average basic shares outstanding | 14,948,500 |  |  | 15,343,783 |  |  | 15,744,231 |  |
| Effect of dilutive share-based awards | 56,197 |  |  | 64,312 |  |  | 68,316 |  |
| Weighted-average diluted shares | 15,004,697 |  |  | 15,408,095 |  |  | 15,812,547 |  |
| Basic earnings per share | $ | 7.49 |  |  | $ | 6.11 |  |  | $ | 6.16 |  |
| Diluted earnings per share | $ | 7.46 |  |  | $ | 6.08 |  |  | $ | 6.13 |  |

[0000320193-25-000079:notes:53]
Approximately 24 million restricted stock units (“RSUs”) were excluded from the computation of diluted earnings per share for 2023 because their effect would have been antidilutive.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000320193-25-000079:notes:54]
Financial Instruments
Cash, Cash Equivalents and Marketable Securities

[0000320193-25-000079:notes:55]
The following tables show the Company’s cash, cash equivalents and marketable securities by significant investment category as of September 27, 2025 and September 28, 2024 (in millions):

[0000320193-25-000079:notes:56]
|  | 2025 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | CurrentMarketableSecurities |  | Non-CurrentMarketableSecurities |
| Cash | $ | 28,267 |  |  | $ | — |  |  | $ | — |  |  | $ | 28,267 |  |  | $ | 28,267 |  |  | $ | — |  |  | $ | — |  |
| Level 1: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 5,272 |  |  | — |  |  | — |  |  | 5,272 |  |  | 5,272 |  |  | — |  |  | — |  |
| Mutual funds | 679 |  |  | 177 |  |  | (2) |  |  | 854 |  |  | — |  |  | 854 |  |  | — |  |
| Subtotal | 5,951 |  |  | 177 |  |  | (2) |  |  | 6,126 |  |  | 5,272 |  |  | 854 |  |  | — |  |
| Level 2 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 16,074 |  |  | 56 |  |  | (282) |  |  | 15,848 |  |  | 1,190 |  |  | 3,712 |  |  | 10,946 |  |
| U.S. agency securities | 5,269 |  |  | — |  |  | (149) |  |  | 5,120 |  |  | 251 |  |  | 2,456 |  |  | 2,413 |  |
| Non-U.S. government securities | 6,586 |  |  | 111 |  |  | (424) |  |  | 6,273 |  |  | — |  |  | 855 |  |  | 5,418 |  |
| Certificates of deposit and time deposits | 917 |  |  | — |  |  | — |  |  | 917 |  |  | 904 |  |  | — |  |  | 13 |  |
| Commercial paper | 100 |  |  | — |  |  | — |  |  | 100 |  |  | 50 |  |  | 50 |  |  | — |  |
| Corporate debt securities | 47,210 |  |  | 266 |  |  | (916) |  |  | 46,560 |  |  | — |  |  | 10,623 |  |  | 35,937 |  |
| Municipal securities | 207 |  |  | — |  |  | (2) |  |  | 205 |  |  | — |  |  | 119 |  |  | 86 |  |
| Mortgage- and asset-backed securities | 24,130 |  |  | 126 |  |  | (1,252) |  |  | 23,004 |  |  | — |  |  | 94 |  |  | 22,910 |  |
| Subtotal | 100,493 |  |  | 559 |  |  | (3,025) |  |  | 98,027 |  |  | 2,395 |  |  | 17,909 |  |  | 77,723 |  |
| Total | $ | 134,711 |  |  | $ | 736 |  |  | $ | (3,027) |  |  | $ | 132,420 |  |  | $ | 35,934 |  |  | $ | 18,763 |  |  | $ | 77,723 |  |

[0000320193-25-000079:notes:57]
|  | 2024 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | CurrentMarketableSecurities |  | Non-CurrentMarketableSecurities |
| Cash | $ | 27,199 |  |  | $ | — |  |  | $ | — |  |  | $ | 27,199 |  |  | $ | 27,199 |  |  | $ | — |  |  | $ | — |  |
| Level 1: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 778 |  |  | — |  |  | — |  |  | 778 |  |  | 778 |  |  | — |  |  | — |  |
| Mutual funds | 515 |  |  | 105 |  |  | (3) |  |  | 617 |  |  | — |  |  | 617 |  |  | — |  |
| Subtotal | 1,293 |  |  | 105 |  |  | (3) |  |  | 1,395 |  |  | 778 |  |  | 617 |  |  | — |  |
| Level 2 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 16,150 |  |  | 45 |  |  | (516) |  |  | 15,679 |  |  | 212 |  |  | 4,087 |  |  | 11,380 |  |
| U.S. agency securities | 5,431 |  |  | — |  |  | (272) |  |  | 5,159 |  |  | 155 |  |  | 703 |  |  | 4,301 |  |
| Non-U.S. government securities | 17,959 |  |  | 93 |  |  | (484) |  |  | 17,568 |  |  | 1,158 |  |  | 10,810 |  |  | 5,600 |  |
| Certificates of deposit and time deposits | 873 |  |  | — |  |  | — |  |  | 873 |  |  | 387 |  |  | 478 |  |  | 8 |  |
| Commercial paper | 1,066 |  |  | — |  |  | — |  |  | 1,066 |  |  | 28 |  |  | 1,038 |  |  | — |  |
| Corporate debt securities | 65,622 |  |  | 270 |  |  | (1,953) |  |  | 63,939 |  |  | 26 |  |  | 16,027 |  |  | 47,886 |  |
| Municipal securities | 412 |  |  | — |  |  | (7) |  |  | 405 |  |  | — |  |  | 190 |  |  | 215 |  |
| Mortgage- and asset-backed securities | 24,595 |  |  | 175 |  |  | (1,403) |  |  | 23,367 |  |  | — |  |  | 1,278 |  |  | 22,089 |  |
| Subtotal | 132,108 |  |  | 583 |  |  | (4,635) |  |  | 128,056 |  |  | 1,966 |  |  | 34,611 |  |  | 91,479 |  |
| Total (2)(3) | $ | 160,600 |  |  | $ | 688 |  |  | $ | (4,638) |  |  | $ | 156,650 |  |  | $ | 29,943 |  |  | $ | 35,228 |  |  | $ | 91,479 |  |

[0000320193-25-000079:notes:58]
(1)The valuation techniques used to measure the fair values of the Company’s Level 2 financial instruments, which generally have counterparties with high credit ratings, are based on quoted market prices or model-driven valuations using significant inputs derived from or corroborated by observable market data.

[0000320193-25-000079:notes:59]
(2)As of September 28, 2024, cash and cash equivalents included $2.6 billion held in escrow and restricted from general use. These restricted cash and cash equivalents were designated to settle the Company’s obligation related to the State Aid Decision (refer to Note 7, “Income Taxes”).

[0000320193-25-000079:notes:60]
(3)As of September 28, 2024, current marketable securities included $13.2 billion held in escrow and restricted from general use. These restricted marketable securities were designated to settle the Company’s obligation related to the State Aid Decision (refer to Note 7, “Income Taxes”).

[0000320193-25-000079:notes:61]
As of September 27, 2025, 80% of the Company’s non-current marketable debt securities other than mortgage- and asset-backed securities had maturities between 1 and 5 years, 15% between 5 and 10 years, and 5% greater than 10 years. As of September 27, 2025, 13% of the Company’s non-current mortgage- and asset-backed securities had maturities between 1 and 5 years, 14% between 5 and 10 years, and 73% greater than 10 years.

[0000320193-25-000079:notes:62]
The Company’s investments in marketable debt securities have been classified and accounted for as available-for-sale. The Company classifies marketable debt securities as either current or non-current based on each instrument’s underlying maturity.

[0000320193-25-000079:notes:63]
Derivative Instruments and Hedging

[0000320193-25-000079:notes:64]
The Company may use derivative instruments to partially offset its business exposure to foreign exchange and interest rate risk. However, the Company may choose not to hedge certain exposures for a variety of reasons including accounting considerations or the prohibitive economic cost of hedging particular exposures. There can be no assurance the hedges will offset more than a portion of the financial impact resulting from movements in foreign exchange or interest rates.

[0000320193-25-000079:notes:65]
Foreign Exchange Rate Risk

[0000320193-25-000079:notes:66]
To protect gross margins from fluctuations in foreign exchange rates, the Company may use forwards, options or other instruments, and may designate these instruments as cash flow hedges. The Company generally hedges portions of its forecasted foreign currency exposure associated with revenue and inventory purchases, typically for up to 12 months.

[0000320193-25-000079:notes:67]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in foreign exchange rates, the Company may use forwards, cross-currency swaps or other instruments. The Company designates these instruments as either cash flow or fair value hedges. As of September 27, 2025, the maximum length of time over which the Company is hedging its exposure to the variability in future cash flows for term debt–related foreign currency transactions is 17 years.

[0000320193-25-000079:notes:68]
The Company may also use derivative instruments that are not designated as accounting hedges to protect gross margins from certain fluctuations in foreign exchange rates, as well as to offset a portion of the foreign currency gains and losses generated by the remeasurement of certain assets and liabilities denominated in non-functional currencies.

[0000320193-25-000079:notes:69]
Interest Rate Risk

[0000320193-25-000079:notes:70]
To protect the Company’s term debt or marketable securities from fluctuations in interest rates, the Company may use interest rate swaps, options or other instruments. The Company designates these instruments as either cash flow or fair value hedges.

[0000320193-25-000079:notes:71]
The notional amounts of the Company’s outstanding derivative instruments as of September 27, 2025 and September 28, 2024, were as follows (in millions):

[0000320193-25-000079:notes:72]
|  | 2025 |  | 2024 |
| Derivative instruments designated as accounting hedges: |  |  |  |
| Foreign exchange contracts | $ | 62,647 |  |  | $ | 64,069 |  |
| Interest rate contracts | $ | 12,875 |  |  | $ | 14,575 |  |
| Derivative instruments not designated as accounting hedges: |  |  |  |
| Foreign exchange contracts | $ | 109,079 |  |  | $ | 91,493 |  |

[0000320193-25-000079:notes:73]
As of September 27, 2025 and September 28, 2024, the carrying amount of the Company’s current and non-current term debt subject to fair value hedges was $12.6 billion and $13.5 billion, respectively.

[0000320193-25-000079:notes:74]
Accounts Receivable

[0000320193-25-000079:notes:75]
As of September 27, 2025, the Company had one customer that represented 10% or more of total trade receivables, which accounted for 12%. The Company’s third-party cellular network carriers accounted for 34% and 38% of total trade receivables as of September 27, 2025 and September 28, 2024, respectively. The Company requires third-party credit support or collateral from certain customers to limit credit risk.

[0000320193-25-000079:notes:76]
Vendor Non-Trade Receivables

[0000320193-25-000079:notes:77]
The Company has non-trade receivables from certain of its manufacturing vendors resulting from the sale of components to these vendors who manufacture subassemblies or assemble final products for the Company. The Company purchases these components directly from suppliers. The Company does not reflect the sale of these components in products net sales. Rather, the Company recognizes any gain on these sales as a reduction of products cost of sales when the related final products are sold by the Company. As of September 27, 2025, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 46% and 23%. As of September 28, 2024, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 44% and 23%.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000320193-25-000079:notes:78]
Property, Plant and Equipment
The following table shows the Company’s gross property, plant and equipment by major asset class and accumulated depreciation as of September 27, 2025 and September 28, 2024 (in millions):

[0000320193-25-000079:notes:79]
|  | 2025 |  | 2024 |
| Land and buildings | $ | 27,337 |  |  | $ | 24,690 |  |
| Machinery, equipment and internal-use software | 83,420 |  |  | 80,205 |  |
| Leasehold improvements | 15,091 |  |  | 14,233 |  |
| Gross property, plant and equipment | 125,848 |  |  | 119,128 |  |
| Accumulated depreciation | (76,014) |  |  | (73,448) |  |
| Total property, plant and equipment, net | $ | 49,834 |  |  | $ | 45,680 |  |

[0000320193-25-000079:notes:80]
Depreciation expense on property, plant and equipment was $8.0 billion, $8.2 billion and $8.5 billion during 2025, 2024 and 2023, respectively.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000320193-25-000079:notes:81]
Consolidated Financial Statement Details
The following tables show the Company’s consolidated financial statement details as of September 27, 2025 and September 28, 2024 (in millions):

[0000320193-25-000079:notes:82]
Other Non-Current Assets

[0000320193-25-000079:notes:83]
|  | 2025 |  | 2024 |
| Deferred tax assets | $ | 20,777 |  |  | $ | 19,499 |  |
| Other non-current assets | 62,950 |  |  | 55,335 |  |
| Total other non-current assets | $ | 83,727 |  |  | $ | 74,834 |  |

[0000320193-25-000079:notes:84]
Other Current Liabilities

[0000320193-25-000079:notes:85]
|  | 2025 |  | 2024 |
| Income taxes payable | $ | 13,016 |  |  | $ | 26,601 |  |
| Accrued distribution and marketing | 8,919 |  |  | 7,679 |  |
| Other current liabilities | 44,452 |  |  | 44,024 |  |
| Total other current liabilities | $ | 66,387 |  |  | $ | 78,304 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000320193-25-000079:notes:86]
Income Taxes
European Commission State Aid Decision

[0000320193-25-000079:notes:87]
On August 30, 2016, the Commission announced its decision that Ireland granted state aid to the Company by providing tax opinions in 1991 and 2007 concerning the tax allocation of profits of the Irish branches of two subsidiaries of the Company (“State Aid Decision”). The State Aid Decision ordered Ireland to calculate and recover additional taxes from the Company for the period June 2003 through December 2014. Irish legislative changes, effective as of January 2015, eliminated the application of the tax opinions from that date forward.

[0000320193-25-000079:notes:88]
The Company and Ireland appealed the State Aid Decision to the General Court of the Court of Justice of the European Union (“General Court”). On July 15, 2020, the General Court annulled the State Aid Decision. On September 25, 2020, the Commission appealed the General Court’s decision to the European Court of Justice (“ECJ”). On September 10, 2024, the ECJ announced that it had set aside the 2020 judgment of the General Court and confirmed the Commission’s 2016 State Aid Decision. As a result, during the fourth quarter of 2024 the Company recorded a one-time income tax charge of $10.2 billion, net, which represented $15.8 billion payable to Ireland via release of amounts held in escrow, partially offset by a U.S. foreign tax credit of $4.8 billion and a decrease in unrecognized tax benefits of $823 million.

[0000320193-25-000079:notes:89]
Provision for Income Taxes and Effective Tax Rate

[0000320193-25-000079:notes:90]
The provision for income taxes for 2025, 2024 and 2023, consisted of the following (in millions):

[0000320193-25-000079:notes:91]
|  | 2025 |  | 2024 |  | 2023 |
| Federal: |  |  |  |  |  |
| Current | $ | 11,487 |  |  | $ | 5,571 |  |  | $ | 9,445 |  |
| Deferred | (1,804) |  |  | (3,080) |  |  | (3,644) |  |
| Total | 9,683 |  |  | 2,491 |  |  | 5,801 |  |
| State: |  |  |  |  |  |
| Current | 1,680 |  |  | 1,726 |  |  | 1,570 |  |
| Deferred | (139) |  |  | (298) |  |  | (49) |  |
| Total | 1,541 |  |  | 1,428 |  |  | 1,521 |  |
| Foreign: |  |  |  |  |  |
| Current | 8,891 |  |  | 25,483 |  |  | 8,750 |  |
| Deferred | 604 |  |  | 347 |  |  | 669 |  |
| Total | 9,495 |  |  | 25,830 |  |  | 9,419 |  |
| Provision for income taxes | $ | 20,719 |  |  | $ | 29,749 |  |  | $ | 16,741 |  |

[0000320193-25-000079:notes:92]
Foreign pretax earnings were $82.0 billion, $77.3 billion and $72.9 billion in 2025, 2024 and 2023, respectively.

[0000320193-25-000079:notes:93]
A reconciliation of the provision for income taxes to the amount computed by applying the statutory federal income tax rate (21% in 2025, 2024 and 2023) to income before provision for income taxes for 2025, 2024 and 2023 is as follows (dollars in millions):

[0000320193-25-000079:notes:94]
|  | 2025 |  | 2024 |  | 2023 |
| Computed expected tax | $ | 27,873 |  |  | $ | 25,932 |  |  | $ | 23,885 |  |
| Earnings of foreign subsidiaries | (8,120) |  |  | (5,311) |  |  | (5,744) |  |
| Change in valuation allowance | 2,091 |  |  | — |  |  | — |  |
| Research and development credit, net | (1,049) |  |  | (1,397) |  |  | (1,212) |  |
| Impact of the State Aid Decision | (486) |  |  | 10,246 |  |  | — |  |
| Other | 410 |  |  | 279 |  |  | (188) |  |
| Provision for income taxes | $ | 20,719 |  |  | $ | 29,749 |  |  | $ | 16,741 |  |
| Effective tax rate | 15.6 | % |  | 24.1 | % |  | 14.7 | % |

[0000320193-25-000079:notes:95]
Deferred Tax Assets and Liabilities

[0000320193-25-000079:notes:96]
As of September 27, 2025 and September 28, 2024, the significant components of the Company’s deferred tax assets and liabilities were as follows (in millions):

[0000320193-25-000079:notes:97]
|  | 2025 |  | 2024 |
| Deferred tax assets: |  |  |  |
| Capitalized research and development | $ | 15,041 |  |  | $ | 10,739 |  |
| Tax credit carryforwards | 8,643 |  |  | 8,856 |  |
| Accrued liabilities and other reserves | 6,154 |  |  | 6,114 |  |
| Deferred revenue | 2,953 |  |  | 3,413 |  |
| Lease liabilities | 2,577 |  |  | 2,410 |  |
| Other | 3,049 |  |  | 3,341 |  |
| Total deferred tax assets | 38,417 |  |  | 34,873 |  |
| Less: Valuation allowance | (10,966) |  |  | (8,866) |  |
| Total deferred tax assets, net | 27,451 |  |  | 26,007 |  |
| Deferred tax liabilities: |  |  |  |
| Depreciation | 3,276 |  |  | 2,551 |  |
| Right-of-use assets | 2,300 |  |  | 2,125 |  |
| Minimum tax on foreign earnings | 1,217 |  |  | 1,674 |  |
| Other | 678 |  |  | 455 |  |
| Total deferred tax liabilities | 7,471 |  |  | 6,805 |  |
| Net deferred tax assets | $ | 19,980 |  |  | $ | 19,202 |  |

[0000320193-25-000079:notes:98]
As of September 27, 2025, the Company had $4.7 billion in foreign tax credit carryforwards in Ireland and $4.0 billion in California R&D credit carryforwards, both of which can be carried forward indefinitely. A valuation allowance has been recorded for the credit carryforwards and a portion of other temporary differences.

[0000320193-25-000079:notes:99]
Uncertain Tax Positions

[0000320193-25-000079:notes:100]
As of September 27, 2025, the total amount of gross unrecognized tax benefits was $23.2 billion, of which $10.6 billion, if recognized, would impact the Company’s effective tax rate. As of September 28, 2024, the total amount of gross unrecognized tax benefits was $22.0 billion, of which $10.8 billion, if recognized, would have impacted the Company’s effective tax rate.

[0000320193-25-000079:notes:101]
The aggregate change in the balance of gross unrecognized tax benefits, which excludes interest and penalties, for 2025, 2024 and 2023 is as follows (in millions):

[0000320193-25-000079:notes:102]
|  | 2025 |  | 2024 |  | 2023 |
| Beginning balances | $ | 22,038 |  |  | $ | 19,454 |  |  | $ | 16,758 |  |
| Increases related to tax positions taken during a prior year | 1,971 |  |  | 1,727 |  |  | 2,044 |  |
| Decreases related to tax positions taken during a prior year | (71) |  |  | (386) |  |  | (1,463) |  |
| Increases related to tax positions taken during the current year | 3,795 |  |  | 2,542 |  |  | 2,628 |  |
| Decreases related to settlements with taxing authorities | (2,939) |  |  | (1,070) |  |  | (19) |  |
| Decreases related to expiration of the statute of limitations | (1,552) |  |  | (229) |  |  | (494) |  |
| Ending balances | $ | 23,242 |  |  | $ | 22,038 |  |  | $ | 19,454 |  |

[0000320193-25-000079:notes:103]
The Company is subject to taxation and files income tax returns in the U.S. federal jurisdiction and many state and foreign jurisdictions. Tax years 2018 and after 2021 for the U.S. federal jurisdiction, and after 2014 in certain major foreign jurisdictions, remain subject to examination. Although the timing of resolution or closure of examinations is not certain, the Company believes it is reasonably possible that its gross unrecognized tax benefits could decrease as much as $6 billion in the next 12 months.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000320193-25-000079:notes:104]
Leases
The Company has lease arrangements for certain equipment and facilities, including corporate, data center, manufacturing and retail space. These leases typically have original terms not exceeding 10 years and generally contain multiyear renewal options, some of which are reasonably certain of exercise.

[0000320193-25-000079:notes:105]
Payments under the Company’s lease arrangements may be fixed or variable, and variable lease payments are primarily based on purchases of output of the underlying leased assets. Lease costs associated with fixed payments on the Company’s operating leases were $2.1 billion for 2025 and $2.0 billion for both 2024 and 2023. Lease costs associated with variable payments on the Company’s leases were $16.1 billion, $13.8 billion and $13.9 billion for 2025, 2024 and 2023, respectively.

[0000320193-25-000079:notes:106]
The Company made fixed cash payments related to operating leases of $2.1 billion in 2025 and $1.9 billion in both 2024 and 2023. Noncash activities involving right-of-use (“ROU”) assets obtained in exchange for lease liabilities were $2.8 billion, $1.0 billion and $2.1 billion for 2025, 2024 and 2023, respectively.

[0000320193-25-000079:notes:107]
The following table shows ROU assets and lease liabilities, and the associated financial statement line items, as of September 27, 2025 and September 28, 2024 (in millions):

[0000320193-25-000079:notes:108]
| Lease-Related Assets and Liabilities |  | Financial Statement Line Items |  | 2025 |  | 2024 |  |  |
| Right-of-use assets: |  |  |  |  |  |  |  |  |
| Operating leases |  | Other non-current assets |  | $ | 11,205 |  |  | $ | 10,234 |  |  |  |
| Finance leases |  | Property, plant and equipment, net |  | 1,033 |  |  | 1,069 |  |  |  |
| Total right-of-use assets |  |  |  | $ | 12,238 |  |  | $ | 11,303 |  |  |  |
| Lease liabilities: |  |  |  |  |  |  |  |  |
| Operating leases |  | Other current liabilities |  | $ | 1,579 |  |  | $ | 1,488 |  |  |  |
|  |  | Other non-current liabilities |  | 10,911 |  |  | 10,046 |  |  |  |
| Finance leases |  | Other current liabilities |  | 538 |  |  | 144 |  |  |  |
|  |  | Other non-current liabilities |  | 692 |  |  | 752 |  |  |  |
| Total lease liabilities |  |  |  | $ | 13,720 |  |  | $ | 12,430 |  |  |  |

[0000320193-25-000079:notes:109]
Lease liability maturities as of September 27, 2025, are as follows (in millions):

[0000320193-25-000079:notes:110]
|  | OperatingLeases |  | FinanceLeases |  | Total |
| 2026 | $ | 1,967 |  |  | $ | 563 |  |  | $ | 2,530 |  |
| 2027 | 1,988 |  |  | 73 |  |  | 2,061 |  |
| 2028 | 1,848 |  |  | 51 |  |  | 1,899 |  |
| 2029 | 1,585 |  |  | 48 |  |  | 1,633 |  |
| 2030 | 1,381 |  |  | 43 |  |  | 1,424 |  |
| Thereafter | 5,956 |  |  | 801 |  |  | 6,757 |  |
| Total undiscounted liabilities | 14,725 |  |  | 1,579 |  |  | 16,304 |  |
| Less: Imputed interest | (2,235) |  |  | (349) |  |  | (2,584) |  |
| Total lease liabilities | $ | 12,490 |  |  | $ | 1,230 |  |  | $ | 13,720 |  |

[0000320193-25-000079:notes:111]
The weighted-average remaining lease term related to the Company’s lease liabilities as of September 27, 2025 and September 28, 2024 was 9.8 years and 10.3 years, respectively. The discount rate related to the Company’s lease liabilities as of September 27, 2025 and September 28, 2024 was 3.4% and 3.1%, respectively. The discount rates related to the Company’s lease liabilities are generally based on estimates of the Company’s incremental borrowing rate, as the discount rates implicit in the Company’s leases cannot be readily determined.

[0000320193-25-000079:notes:112]
As of September 27, 2025, the Company had $523 million of fixed payment obligations under additional leases, primarily for corporate facilities and retail space, that had not yet commenced. These leases are expected to commence between 2026 and 2027, with lease terms ranging from 1 year to 21 years.


## us-gaap:DebtDisclosureTextBlock

[0000320193-25-000079:notes:113]
Debt
Commercial Paper

[0000320193-25-000079:notes:114]
The Company issues unsecured short-term promissory notes pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of September 27, 2025 and September 28, 2024, the Company had $8.0 billion and $10.0 billion of commercial paper outstanding, respectively, with maturities generally less than nine months. The weighted-average interest rate of the Company’s commercial paper was 4.19% and 5.00% as of September 27, 2025 and September 28, 2024, respectively. The following table provides a summary of cash flows associated with commercial paper for 2025, 2024 and 2023 (in millions):

[0000320193-25-000079:notes:115]
|  | 2025 |  | 2024 |  | 2023 |
| Maturities 90 days or less: |  |  |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | (5,820) |  |  | $ | 3,960 |  |  | $ | (1,333) |  |
| Maturities greater than 90 days: |  |  |  |  |  |
| Proceeds from commercial paper | 5,836 |  |  | — |  |  | — |  |
| Repayments of commercial paper | (2,048) |  |  | — |  |  | (2,645) |  |
| Proceeds from/(Repayments of) commercial paper, net | 3,788 |  |  | — |  |  | (2,645) |  |
| Total proceeds from/(repayments of) commercial paper, net | $ | (2,032) |  |  | $ | 3,960 |  |  | $ | (3,978) |  |

[0000320193-25-000079:notes:116]
Term Debt

[0000320193-25-000079:notes:117]
The Company has outstanding Notes, which are senior unsecured obligations with interest payable in arrears. The following table provides a summary of the Company’s term debt as of September 27, 2025 and September 28, 2024:

[0000320193-25-000079:notes:118]
|  | Maturities(calendar year) |  | 2025 |  | 2024 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 – 2023 debt issuances: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.000% – 4.850% notes | 2025 – 2062 |  | $ | 86,781 |  |  | 0.03% – 5.75% |  | $ | 97,341 |  |  | 0.03% – 6.65% |
| 2025 debt issuance: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 4.000% – 4.750% notes | 2028 – 2035 |  | 4,500 |  |  | 4.07% – 4.83% |  | — |  |  |  |
| Total term debt principal |  |  | 91,281 |  |  |  |  | 97,341 |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  | (309) |  |  |  |  | (321) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (294) |  |  |  |  | (358) |  |  |  |
| Total term debt |  |  | 90,678 |  |  |  |  | 96,662 |  |  |  |
| Less: Current portion of term debt |  |  | (12,350) |  |  |  |  | (10,912) |  |  |  |
| Total non-current portion of term debt |  |  | $ | 78,328 |  |  |  |  | $ | 85,750 |  |  |  |

[0000320193-25-000079:notes:119]
To manage interest rate risk on certain of its U.S. dollar–denominated fixed-rate notes, the Company uses interest rate swaps to effectively convert the fixed interest rates to floating interest rates on a portion of these notes. Additionally, to manage foreign exchange rate risk on certain of its foreign currency–denominated notes, the Company uses cross-currency swaps to effectively convert these notes to U.S. dollar–denominated notes.

[0000320193-25-000079:notes:120]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging.

[0000320193-25-000079:notes:121]
The future principal payments for the Company’s Notes as of September 27, 2025, are as follows (in millions):

[0000320193-25-000079:notes:122]
| 2026 | $ | 12,393 |  |
| 2027 | 10,078 |  |
| 2028 | 9,300 |  |
| 2029 | 5,235 |  |
| 2030 | 4,972 |  |
| Thereafter | 49,303 |  |
| Total term debt principal | $ | 91,281 |  |

[0000320193-25-000079:notes:123]
As of September 27, 2025 and September 28, 2024, the fair value of the Company’s Notes, based on Level 2 inputs, was $80.4 billion and $88.4 billion, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000320193-25-000079:notes:124]
Shareholders’ Equity
Share Repurchase Program

[0000320193-25-000079:notes:125]
During 2025, the Company repurchased 402 million shares of its common stock for $89.3 billion. The Company’s share repurchase programs do not obligate the Company to acquire a minimum amount of shares. Under the programs, shares may be repurchased in privately negotiated or open market transactions, including under plans complying with Rule 10b5-1 under the Exchange Act.

[0000320193-25-000079:notes:126]
Shares of Common Stock

[0000320193-25-000079:notes:127]
The following table shows the changes in shares of common stock for 2025, 2024 and 2023 (in thousands):

[0000320193-25-000079:notes:128]
|  | 2025 |  | 2024 |  | 2023 |
| Common stock outstanding, beginning balances | 15,116,786 |  |  | 15,550,061 |  |  | 15,943,425 |  |
| Common stock repurchased | (401,672) |  |  | (499,372) |  |  | (471,419) |  |
| Common stock issued, net of shares withheld for employee taxes | 58,146 |  |  | 66,097 |  |  | 78,055 |  |
| Common stock outstanding, ending balances | 14,773,260 |  |  | 15,116,786 |  |  | 15,550,061 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000320193-25-000079:notes:129]
Share-Based Compensation
2022 Employee Stock Plan

[0000320193-25-000079:notes:130]
The Apple Inc. 2022 Employee Stock Plan (“2022 Plan”) is a shareholder-approved plan that provides for broad-based equity grants to employees, including executive officers, and permits the granting of RSUs, stock grants, performance-based awards, stock options and stock appreciation rights. RSUs granted under the 2022 Plan generally vest over four years, based on continued employment, and are settled upon vesting in shares of the Company’s common stock on a one-for-one basis. All RSUs granted under the 2022 Plan have dividend equivalent rights, which entitle holders of RSUs to the same dividend value per share as holders of common stock. A maximum of approximately 1.3 billion shares were authorized for issuance pursuant to 2022 Plan awards at the time the plan was approved on March 4, 2022.

[0000320193-25-000079:notes:131]
Restricted Stock Units

[0000320193-25-000079:notes:132]
A summary of the Company’s RSU activity and related information for 2025 is as follows:

[0000320193-25-000079:notes:133]
|  | Number ofRSUs(in thousands) |  | Weighted-AverageGrant-Date FairValue Per RSU |
| Balance as of September 28, 2024 | 163,326 |  |  | $ | 158.73 |  |
| RSUs granted | 73,466 |  |  | $ | 226.68 |  |
| RSUs vested | (76,845) |  |  | $ | 159.85 |  |
| RSUs forfeited | (8,373) |  |  | $ | 183.03 |  |
| Balance as of September 27, 2025 | 151,574 |  |  | $ | 189.75 |  |

[0000320193-25-000079:notes:134]
The weighted-average grant-date fair value of RSUs granted in 2024 and 2023 was $173.78 and $150.87, respectively. The Company estimates the grant-date fair value of RSUs based on the closing price of the Company’s common stock on the date of grant.

[0000320193-25-000079:notes:135]
The total vesting-date fair value of RSUs was $17.1 billion, $15.8 billion and $15.9 billion for 2025, 2024 and 2023, respectively. The majority of RSUs that vested in 2025, 2024 and 2023 were net share settled such that the Company withheld shares with a value equivalent to the employees’ obligation for the applicable income and other employment taxes, and remitted cash to the appropriate taxing authorities. Total payments to taxing authorities for employees’ tax obligations were $6.1 billion in 2025 and $5.6 billion in both 2024 and 2023.

[0000320193-25-000079:notes:136]
The following table shows share-based compensation expense and the related income tax benefit included in the Consolidated Statements of Operations for 2025, 2024 and 2023 (in millions):

[0000320193-25-000079:notes:137]
|  | 2025 |  | 2024 |  | 2023 |
| Share-based compensation expense | $ | 12,863 |  |  | $ | 11,688 |  |  | $ | 10,833 |  |
| Income tax benefit related to share-based compensation expense | $ | (3,602) |  |  | $ | (3,350) |  |  | $ | (3,421) |  |

[0000320193-25-000079:notes:138]
As of September 27, 2025, the total unrecognized compensation cost related to outstanding RSUs was $21.8 billion, which the Company expects to recognize over a weighted-average period of 2.5 years.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000320193-25-000079:notes:139]
Commitments, Contingencies and Supply Concentrations
Unconditional Purchase Obligations

[0000320193-25-000079:notes:140]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of supplier arrangements, licensed intellectual property and content, and distribution rights. Future payments under unconditional purchase obligations with a remaining term in excess of one year as of September 27, 2025, are as follows (in millions):

[0000320193-25-000079:notes:141]
| 2026 | $ | 4,752 |  |
| 2027 | 3,708 |  |
| 2028 | 1,981 |  |
| 2029 | 1,306 |  |
| 2030 | 788 |  |
| Thereafter | 773 |  |
| Total | $ | 13,308 |  |

[0000320193-25-000079:notes:142]
Contingencies

[0000320193-25-000079:notes:143]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully resolved. The outcome of litigation is inherently uncertain. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss greater than a recorded accrual, concerning loss contingencies for asserted legal and other claims.

[0000320193-25-000079:notes:144]
Concentrations in the Available Sources of Supply of Materials and Product

[0000320193-25-000079:notes:145]
Although most components essential to the Company’s business are generally available from multiple sources, certain components are currently obtained from single or limited sources. The Company also competes for various components with other participants in the markets for smartphones, personal computers, tablets, wearables and accessories. Therefore, many components used by the Company, including those that are available from multiple sources, are at times subject to industry-wide shortage and significant commodity pricing fluctuations. Restrictions on international trade can increase the cost or limit the availability of the Company’s products and the components and rare earths and other raw materials that go into them.

[0000320193-25-000079:notes:146]
The Company uses some custom components that are not commonly used by its competitors, and new products introduced by the Company often utilize custom components available from only one source. When a component or product uses new technologies, initial capacity constraints may exist until the suppliers’ yields have matured or their manufacturing capacities have increased. The Company has entered into agreements for the supply of many components; however, the Company may not be able to extend or renew agreements for the supply of components on similar terms, or at all, and may not be successful in obtaining sufficient quantities from its suppliers or in a timely manner, or in identifying and obtaining sufficient quantities from an alternative source. In addition, component suppliers may fail, be subject to consolidation within a particular industry, or decide to concentrate on the production of common components instead of components customized to meet the Company’s requirements, further limiting the Company’s ability to obtain sufficient quantities of components on commercially reasonable terms, or at all.

[0000320193-25-000079:notes:147]
Substantially all of the Company’s hardware products are manufactured by outsourcing partners that are located primarily in China mainland, India, Japan, South Korea, Taiwan and Vietnam.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000320193-25-000079:notes:148]
Segment Information and Geographic Data
The Company manages its business primarily on a geographic basis. The Company’s CEO is its CODM.

[0000320193-25-000079:notes:149]
The Company’s reportable segments consist of the Americas, Europe, Greater China, Japan and Rest of Asia Pacific. Americas includes both North and South America. Europe includes European countries, as well as India, the Middle East and Africa. Greater China includes China mainland, Hong Kong and Taiwan. Rest of Asia Pacific includes Australia, New Zealand and those Asian countries not included in the Company’s other reportable segments. Although the reportable segments provide similar hardware and software products and similar services, each one is managed separately to better align with the location of the Company’s customers and distribution partners and the unique market dynamics of each geographic region.

[0000320193-25-000079:notes:150]
The CODM uses segment net sales and operating income information to make certain decisions, such as product and service pricing, and to decide how to allocate resources related to sales activities and marketing investments. Net sales for geographic segments are generally based on the location of customers and sales through the Company’s retail stores located in those geographic locations. Operating income for each segment consists of net sales to third parties, related cost of sales, and operating expenses directly attributable to the segment. The information provided to the CODM for purposes of making decisions and assessing segment performance excludes asset information.

[0000320193-25-000079:notes:151]
The following tables show information by reportable segment for 2025, 2024 and 2023 (in millions):

[0000320193-25-000079:notes:152]
|  | 2025 |
|  | Americas |  | Europe |  | GreaterChina |  | Japan |  | Rest ofAsia Pacific |  | Corporate |  | Total |
| Net sales | $ | 178,353 |  |  | $ | 111,032 |  |  | $ | 64,377 |  |  | $ | 28,703 |  |  | $ | 33,696 |  |  | $ | — |  |  | $ | 416,161 |  |
| Cost of sales | (95,699) |  |  | (58,617) |  |  | (35,141) |  |  | (13,779) |  |  | (17,724) |  |  | — |  |  | (220,960) |  |
| Research and development | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (34,550) |  |  | (34,550) |  |
| Selling and marketing | (10,174) |  |  | (4,676) |  |  | (2,319) |  |  | (969) |  |  | (1,386) |  |  | — |  |  | (19,524) |  |
| General and administrative | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (8,077) |  |  | (8,077) |  |
| Operating income/(loss) | $ | 72,480 |  |  | $ | 47,739 |  |  | $ | 26,917 |  |  | $ | 13,955 |  |  | $ | 14,586 |  |  | $ | (42,627) |  |  | $ | 133,050 |  |

[0000320193-25-000079:notes:153]
|  | 2024 |
|  | Americas |  | Europe |  | GreaterChina |  | Japan |  | Rest ofAsia Pacific |  | Corporate |  | Total |
| Net sales | $ | 167,045 |  |  | $ | 101,328 |  |  | $ | 66,952 |  |  | $ | 25,052 |  |  | $ | 30,658 |  |  | $ | — |  |  | $ | 391,035 |  |
| Cost of sales | (89,587) |  |  | (55,197) |  |  | (37,519) |  |  | (11,744) |  |  | (16,305) |  |  | — |  |  | (210,352) |  |
| Research and development | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (31,370) |  |  | (31,370) |  |
| Selling and marketing | (9,802) |  |  | (4,341) |  |  | (2,351) |  |  | (854) |  |  | (1,291) |  |  | — |  |  | (18,639) |  |
| General and administrative | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (7,458) |  |  | (7,458) |  |
| Operating income/(loss) | $ | 67,656 |  |  | $ | 41,790 |  |  | $ | 27,082 |  |  | $ | 12,454 |  |  | $ | 13,062 |  |  | $ | (38,828) |  |  | $ | 123,216 |  |

[0000320193-25-000079:notes:154]
|  | 2023 |
|  | Americas |  | Europe |  | GreaterChina |  | Japan |  | Rest ofAsia Pacific |  | Corporate |  | Total |
| Net sales | $ | 162,560 |  |  | $ | 94,294 |  |  | $ | 72,559 |  |  | $ | 24,257 |  |  | $ | 29,615 |  |  | $ | — |  |  | $ | 383,285 |  |
| Cost of sales | (92,394) |  |  | (54,101) |  |  | (39,787) |  |  | (11,542) |  |  | (16,313) |  |  | — |  |  | (214,137) |  |
| Research and development | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (29,915) |  |  | (29,915) |  |
| Selling and marketing | (9,658) |  |  | (4,095) |  |  | (2,444) |  |  | (827) |  |  | (1,236) |  |  | — |  |  | (18,260) |  |
| General and administrative | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (6,672) |  |  | (6,672) |  |
| Operating income/(loss) | $ | 60,508 |  |  | $ | 36,098 |  |  | $ | 30,328 |  |  | $ | 11,888 |  |  | $ | 12,066 |  |  | $ | (36,587) |  |  | $ | 114,301 |  |

[0000320193-25-000079:notes:155]
The following tables show net sales for 2025, 2024 and 2023 and long-lived assets as of September 27, 2025 and September 28, 2024 for countries that individually accounted for 10% or more of the respective totals, as well as aggregate amounts for the remaining countries (in millions):

[0000320193-25-000079:notes:156]
|  | 2025 |  | 2024 |  | 2023 |
| Net sales: |  |  |  |  |  |
| U.S. | $ | 151,790 |  |  | $ | 142,196 |  |  | $ | 138,573 |  |
| China (1) | 64,377 |  |  | 66,952 |  |  | 72,559 |  |
| Other countries | 199,994 |  |  | 181,887 |  |  | 172,153 |  |
| Total net sales | $ | 416,161 |  |  | $ | 391,035 |  |  | $ | 383,285 |  |

[0000320193-25-000079:notes:157]
|  | 2025 |  | 2024 |
| Long-lived assets: |  |  |  |
| U.S. | $ | 40,274 |  |  | $ | 35,664 |  |
| China (1) | 3,617 |  |  | 4,797 |  |
| Other countries | 5,943 |  |  | 5,219 |  |
| Total long-lived assets | $ | 49,834 |  |  | $ | 45,680 |  |

[0000320193-25-000079:notes:158]
(1)China includes Hong Kong and Taiwan.
