# AAPL MD&A — 0000320193-25-000079


## mdna

[0000320193-25-000079:mdna:1]
Item 7.    Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000320193-25-000079:mdna:2]
The following discussion should be read in conjunction with the consolidated financial statements and accompanying notes included in Part II, Item 8 of this Form 10-K. This Item generally discusses 2025 and 2024 items and year-to-year comparisons between 2025 and 2024. Discussions of 2023 items and year-to-year comparisons between 2024 and 2023 are not included, and can be found in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in Part II, Item 7 of the Company’s Annual Report on Form 10-K for the fiscal year ended September 28, 2024.

[0000320193-25-000079:mdna:3]
Product, Service and Software Announcements

[0000320193-25-000079:mdna:4]
The Company announces new product, service and software offerings at various times during the year. Significant announcements during fiscal year 2025 included the following:

[0000320193-25-000079:mdna:5]
First Quarter 2025:

[0000320193-25-000079:mdna:6]
•MacBook Pro

[0000320193-25-000079:mdna:7]
•Mac mini

[0000320193-25-000079:mdna:8]
•iMac

[0000320193-25-000079:mdna:9]
•iPad mini

[0000320193-25-000079:mdna:10]
Second Quarter 2025:

[0000320193-25-000079:mdna:11]
•iPhone 16e

[0000320193-25-000079:mdna:12]
•iPad Air

[0000320193-25-000079:mdna:13]
•iPad

[0000320193-25-000079:mdna:14]
•MacBook Air

[0000320193-25-000079:mdna:15]
•Mac Studio

[0000320193-25-000079:mdna:16]
Third Quarter 2025:

[0000320193-25-000079:mdna:17]
•iOS 26, macOS Tahoe 26, iPadOS 26, watchOS 26, visionOS 26 and tvOS 26

[0000320193-25-000079:mdna:18]
Fourth Quarter 2025:

[0000320193-25-000079:mdna:19]
•iPhone 17, iPhone Air, iPhone 17 Pro and iPhone 17 Pro Max

[0000320193-25-000079:mdna:20]
•Apple Watch Series 11, Apple Watch SE 3 and Apple Watch Ultra 3

[0000320193-25-000079:mdna:21]
•AirPods Pro 3

[0000320193-25-000079:mdna:22]
Fiscal Period

[0000320193-25-000079:mdna:23]
The Company’s fiscal year is the 52- or 53-week period that ends on the last Saturday of September. An additional week is included in the first fiscal quarter every five or six years to realign the Company’s fiscal quarters with calendar quarters, which occurred in the first quarter of 2023. The Company’s fiscal years 2025 and 2024 spanned 52 weeks each, whereas fiscal year 2023 spanned 53 weeks.

[0000320193-25-000079:mdna:24]
Macroeconomic Conditions

[0000320193-25-000079:mdna:25]
Macroeconomic conditions, including inflation, interest rates and currency fluctuations, have directly and indirectly impacted, and could in the future materially impact, the Company’s results of operations and financial condition.

[0000320193-25-000079:mdna:26]
Tariffs and Other Measures

[0000320193-25-000079:mdna:27]
Beginning in the second quarter of 2025, new U.S. Tariffs were announced, including additional tariffs on imports from China, India, Japan, South Korea, Taiwan, Vietnam and the EU, among others. In response, several countries have imposed, or threatened to impose, reciprocal tariffs on imports from the U.S. and other retaliatory measures. Various modifications to the U.S. Tariffs have been announced and further changes could be made in the future, which may include additional sector-based tariffs or other measures. For example, the U.S. Department of Commerce has initiated an investigation under Section 232 of the Trade Expansion Act of 1962, as amended, into, among other things, imports of semiconductors, semiconductor manufacturing equipment, and their derivative products, including downstream products that contain semiconductors. Tariffs and other measures that are applied to the Company’s products or their components can have a material adverse impact on the Company’s business, results of operations and financial condition, including impacting the Company’s supply chain, the availability of rare earths and other raw materials and components, pricing and gross margin. The ultimate impact remains uncertain and will depend on several factors, including whether additional or incremental U.S. Tariffs or other measures are announced or imposed, to what extent other countries implement tariffs or other retaliatory measures in response, and the overall magnitude and duration of these measures. Trade and other international disputes can have an adverse impact on the overall macroeconomic environment and result in shifts and reductions in consumer spending and negative consumer sentiment for the Company’s products and services, all of which can further adversely affect the Company’s business and results of operations.

[0000320193-25-000079:mdna:28]
Segment Operating Performance

[0000320193-25-000079:mdna:29]
The following table shows net sales by reportable segment for 2025, 2024 and 2023 (dollars in millions):

[0000320193-25-000079:mdna:30]
|  | 2025 |  | Change |  | 2024 |  | Change |  | 2023 |
| Americas | $ | 178,353 |  |  | 7 | % |  | $ | 167,045 |  |  | 3 | % |  | $ | 162,560 |  |
| Europe | 111,032 |  |  | 10 | % |  | 101,328 |  |  | 7 | % |  | 94,294 |  |
| Greater China | 64,377 |  |  | (4) | % |  | 66,952 |  |  | (8) | % |  | 72,559 |  |
| Japan | 28,703 |  |  | 15 | % |  | 25,052 |  |  | 3 | % |  | 24,257 |  |
| Rest of Asia Pacific | 33,696 |  |  | 10 | % |  | 30,658 |  |  | 4 | % |  | 29,615 |  |
| Total net sales | $ | 416,161 |  |  | 6 | % |  | $ | 391,035 |  |  | 2 | % |  | $ | 383,285 |  |

[0000320193-25-000079:mdna:31]
Americas

[0000320193-25-000079:mdna:32]
Americas net sales increased during 2025 compared to 2024 primarily due to higher net sales of iPhone and Services. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable year-over-year impact on Americas net sales during 2025.

[0000320193-25-000079:mdna:33]
Europe

[0000320193-25-000079:mdna:34]
Europe net sales increased during 2025 compared to 2024 primarily due to higher net sales of Services, iPhone and Mac.

[0000320193-25-000079:mdna:35]
Greater China

[0000320193-25-000079:mdna:36]
Greater China net sales decreased during 2025 compared to 2024 primarily due to lower net sales of iPhone, partially offset by higher net sales of Mac.

[0000320193-25-000079:mdna:37]
Japan

[0000320193-25-000079:mdna:38]
Japan net sales increased during 2025 compared to 2024 primarily due to higher net sales of iPhone, Services and iPad.

[0000320193-25-000079:mdna:39]
Rest of Asia Pacific

[0000320193-25-000079:mdna:40]
Rest of Asia Pacific net sales increased during 2025 compared to 2024 primarily due to higher net sales of iPhone, Services and Mac.

[0000320193-25-000079:mdna:41]
Products and Services Performance

[0000320193-25-000079:mdna:42]
The following table shows net sales by category for 2025, 2024 and 2023 (dollars in millions):

[0000320193-25-000079:mdna:43]
|  | 2025 |  | Change |  | 2024 |  | Change |  | 2023 |
| iPhone | $ | 209,586 |  |  | 4 | % |  | $ | 201,183 |  |  | — | % |  | $ | 200,583 |  |
| Mac | 33,708 |  |  | 12 | % |  | 29,984 |  |  | 2 | % |  | 29,357 |  |
| iPad | 28,023 |  |  | 5 | % |  | 26,694 |  |  | (6) | % |  | 28,300 |  |
| Wearables, Home and Accessories | 35,686 |  |  | (4) | % |  | 37,005 |  |  | (7) | % |  | 39,845 |  |
| Services (1) | 109,158 |  |  | 14 | % |  | 96,169 |  |  | 13 | % |  | 85,200 |  |
| Total net sales | $ | 416,161 |  |  | 6 | % |  | $ | 391,035 |  |  | 2 | % |  | $ | 383,285 |  |

[0000320193-25-000079:mdna:44]
(1)Services net sales include amortization of the deferred value of services bundled in the sales price of certain products.

[0000320193-25-000079:mdna:45]
iPhone

[0000320193-25-000079:mdna:46]
iPhone net sales increased during 2025 compared to 2024 due to higher net sales of Pro models.

[0000320193-25-000079:mdna:47]
Mac

[0000320193-25-000079:mdna:48]
Mac net sales increased during 2025 compared to 2024 primarily due to higher net sales of laptops and desktops.

[0000320193-25-000079:mdna:49]
iPad

[0000320193-25-000079:mdna:50]
iPad net sales increased during 2025 compared to 2024 primarily due to higher net sales of iPad Air, iPad mini and iPad, partially offset by lower net sales of iPad Pro.

[0000320193-25-000079:mdna:51]
Wearables, Home and Accessories

[0000320193-25-000079:mdna:52]
Wearables, Home and Accessories net sales decreased during 2025 compared to 2024 primarily due to lower net sales of Accessories and Wearables.

[0000320193-25-000079:mdna:53]
Services

[0000320193-25-000079:mdna:54]
Services net sales increased during 2025 compared to 2024 primarily due to higher net sales from advertising, the App Store and cloud services.

[0000320193-25-000079:mdna:55]
Gross Margin

[0000320193-25-000079:mdna:56]
Products and Services gross margin and gross margin percentage for 2025, 2024 and 2023 were as follows (dollars in millions):

[0000320193-25-000079:mdna:57]
|  | 2025 |  | 2024 |  | 2023 |
| Gross margin: |  |  |  |  |  |
| Products | $ | 112,887 |  |  | $ | 109,633 |  |  | $ | 108,803 |  |
| Services | 82,314 |  |  | 71,050 |  |  | 60,345 |  |
| Total gross margin | $ | 195,201 |  |  | $ | 180,683 |  |  | $ | 169,148 |  |

[0000320193-25-000079:mdna:58]
| Gross margin percentage: |  |  |  |  |  |
| Products | 36.8 | % |  | 37.2 | % |  | 36.5 | % |
| Services | 75.4 | % |  | 73.9 | % |  | 70.8 | % |
| Total gross margin percentage | 46.9 | % |  | 46.2 | % |  | 44.1 | % |

[0000320193-25-000079:mdna:59]
Products Gross Margin

[0000320193-25-000079:mdna:60]
Products gross margin increased during 2025 compared to 2024 primarily due to favorable costs and a different mix of products, partially offset by tariff costs.

[0000320193-25-000079:mdna:61]
Products gross margin percentage decreased during 2025 compared to 2024 primarily due to a different mix of products and tariff costs, partially offset by other favorable costs.

[0000320193-25-000079:mdna:62]
Services Gross Margin

[0000320193-25-000079:mdna:63]
Services gross margin increased during 2025 compared to 2024 primarily due to higher Services net sales and a different mix of services.

[0000320193-25-000079:mdna:64]
Services gross margin percentage increased during 2025 compared to 2024 primarily due to a different mix of services, partially offset by higher costs.

[0000320193-25-000079:mdna:65]
The Company’s future gross margins can be impacted by a variety of factors, as discussed in Part I, Item 1A of this Form 10-K under the heading “Risk Factors.” As a result, the Company believes, in general, gross margins will be subject to volatility and downward pressure.

[0000320193-25-000079:mdna:66]
Operating Expenses

[0000320193-25-000079:mdna:67]
Operating expenses for 2025, 2024 and 2023 were as follows (dollars in millions):

[0000320193-25-000079:mdna:68]
|  | 2025 |  | Change |  | 2024 |  | Change |  | 2023 |
| Research and development | $ | 34,550 |  |  | 10 | % |  | $ | 31,370 |  |  | 5 | % |  | $ | 29,915 |  |
| Percentage of total net sales | 8 | % |  |  |  | 8 | % |  |  |  | 8 | % |
| Selling, general and administrative | $ | 27,601 |  |  | 6 | % |  | $ | 26,097 |  |  | 5 | % |  | $ | 24,932 |  |
| Percentage of total net sales | 7 | % |  |  |  | 7 | % |  |  |  | 7 | % |
| Total operating expenses | $ | 62,151 |  |  | 8 | % |  | $ | 57,467 |  |  | 5 | % |  | $ | 54,847 |  |
| Percentage of total net sales | 15 | % |  |  |  | 15 | % |  |  |  | 14 | % |

[0000320193-25-000079:mdna:69]
Research and Development

[0000320193-25-000079:mdna:70]
The growth in R&D expense during 2025 compared to 2024 was primarily driven by increases in headcount-related expenses and infrastructure-related costs.

[0000320193-25-000079:mdna:71]
Selling, General and Administrative

[0000320193-25-000079:mdna:72]
The growth in selling, general and administrative expense during 2025 compared to 2024 was primarily driven by increases in headcount-related expenses and variable selling expenses.

[0000320193-25-000079:mdna:73]
Provision for Income Taxes

[0000320193-25-000079:mdna:74]
Provision for income taxes, effective tax rate and statutory federal income tax rate for 2025, 2024 and 2023 were as follows (dollars in millions):

[0000320193-25-000079:mdna:75]
|  | 2025 |  | 2024 |  | 2023 |
| Provision for income taxes | $ | 20,719 |  |  | $ | 29,749 |  |  | $ | 16,741 |  |
| Effective tax rate | 15.6 | % |  | 24.1 | % |  | 14.7 | % |
| Statutory federal income tax rate | 21 | % |  | 21 | % |  | 21 | % |

[0000320193-25-000079:mdna:76]
The Company’s effective tax rate for 2025 was lower than the statutory federal income tax rate primarily due to a lower effective tax rate on foreign earnings, including the impact of changes in unrecognized tax benefits, the impact of the U.S. federal R&D credit, and tax benefits from share-based compensation, partially offset by a change in valuation allowance and state income taxes.

[0000320193-25-000079:mdna:77]
The Company’s effective tax rate for 2025 was lower compared to 2024 due to a $10.7 billion year-over-year decrease in the provision for income taxes related to the State Aid Decision (refer to Note 7, “Income Taxes” in the Notes to Consolidated Financial Statements in Part II, Item 8 of this Form 10-K) and the impact of changes in unrecognized tax benefits, partially offset by a change in valuation allowance and a higher effective tax rate on foreign earnings.

[0000320193-25-000079:mdna:78]
Liquidity and Capital Resources

[0000320193-25-000079:mdna:79]
The Company believes its balances of cash, cash equivalents and marketable securities, which totaled $132.4 billion as of September 27, 2025, along with cash generated by ongoing operations and continued access to debt markets, will be sufficient to satisfy its cash requirements and capital return program over the next 12 months and beyond.

[0000320193-25-000079:mdna:80]
The Company’s material cash requirements include the following contractual obligations:

[0000320193-25-000079:mdna:81]
Debt

[0000320193-25-000079:mdna:82]
As of September 27, 2025, the Company had outstanding fixed-rate notes with varying maturities for an aggregate principal amount of $91.3 billion (collectively the “Notes”), with $12.4 billion payable within 12 months. Future interest payments associated with the Notes total $37.0 billion, with $2.6 billion payable within 12 months.

[0000320193-25-000079:mdna:83]
The Company also issues unsecured short-term promissory notes pursuant to a commercial paper program. As of September 27, 2025, the Company had $8.0 billion of commercial paper outstanding, which was payable within 12 months.

[0000320193-25-000079:mdna:84]
Leases

[0000320193-25-000079:mdna:85]
The Company has lease arrangements for certain equipment and facilities, including corporate, data center, manufacturing and retail space. As of September 27, 2025, the Company had fixed lease payment obligations of $16.8 billion, with $2.6 billion payable within 12 months.

[0000320193-25-000079:mdna:86]
Manufacturing Purchase Obligations

[0000320193-25-000079:mdna:87]
The Company utilizes several outsourcing partners to manufacture subassemblies for the Company’s products and to perform final assembly and testing of finished products. The Company also obtains individual components for its products from a wide variety of individual suppliers. As of September 27, 2025, the Company had manufacturing purchase obligations of $56.2 billion, with $55.4 billion payable within 12 months.

[0000320193-25-000079:mdna:88]
Other Purchase Obligations

[0000320193-25-000079:mdna:89]
The Company’s other purchase obligations primarily consist of noncancelable obligations to acquire capital assets, including assets related to product manufacturing, and noncancelable obligations related to supplier arrangements, licensed intellectual property and content, and distribution rights. As of September 27, 2025, the Company had other purchase obligations of $14.8 billion, with $7.0 billion payable within 12 months.

[0000320193-25-000079:mdna:90]
Deemed Repatriation Tax Payable

[0000320193-25-000079:mdna:91]
As of September 27, 2025, the balance of the deemed repatriation tax payable imposed by the U.S. Tax Cuts and Jobs Act of 2017 (“TCJA”) was $8.8 billion, which was payable within 12 months.

[0000320193-25-000079:mdna:92]
Capital Return Program

[0000320193-25-000079:mdna:93]
In addition to its contractual cash requirements, the Company has an authorized share repurchase program. The program does not obligate the Company to acquire a minimum amount of shares. As of September 27, 2025, the Company’s quarterly cash dividend was $0.26 per share. The Company intends to increase its dividend on an annual basis, subject to declaration by the Board.

[0000320193-25-000079:mdna:94]
In May 2025, the Company announced a new share repurchase program of up to $100 billion and raised its quarterly dividend from $0.25 to $0.26 per share beginning in May 2025. During 2025, the Company repurchased $89.3 billion of its common stock and paid dividends and dividend equivalents of $15.4 billion.

[0000320193-25-000079:mdna:95]
Recent Accounting Pronouncements

[0000320193-25-000079:mdna:96]
Internal-Use Software

[0000320193-25-000079:mdna:97]
In September 2025, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2025-06, Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software (“ASU 2025-06”), which modernizes the accounting for internal-use software. ASU 2025-06 removes all references to software development stages and requires capitalization of software costs when management has committed to the software project and it is probable the software will be completed and perform its intended use. ASU 2025-06 will be effective for the Company in its first quarter of 2029, and early adoption is permitted. The Company is currently evaluating the timing and method of its adoption of ASU 2025-06.

[0000320193-25-000079:mdna:98]
Disaggregation of Income Statement Expenses

[0000320193-25-000079:mdna:99]
In November 2024, the FASB issued ASU No. 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses (“ASU 2024-03”) and in January 2025, the FASB issued ASU No. 2025-01, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date, which clarified the effective date of ASU 2024-03. ASU 2024-03 will require the Company to disclose the amounts of purchases of inventory, employee compensation, depreciation and intangible asset amortization, as applicable, included in certain expense captions in the Consolidated Statements of Operations, as well as qualitatively describe remaining amounts included in those captions. ASU 2024-03 will also require the Company to disclose both the amount and the Company’s definition of selling expenses. The Company will adopt ASU 2024-03 in its fourth quarter of 2028 using a prospective transition method.

[0000320193-25-000079:mdna:100]
Income Taxes

[0000320193-25-000079:mdna:101]
In December 2023, the FASB issued ASU No. 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures (“ASU 2023-09”), which will require the Company to disclose specified additional information in its income tax rate reconciliation and provide additional information for reconciling items that meet a quantitative threshold. ASU 2023-09 will also require the Company to disaggregate its income taxes paid disclosure by federal, state and foreign taxes, with further disaggregation required for significant individual jurisdictions. The Company will adopt ASU 2023-09 in its fourth quarter of 2026 using a prospective transition method.

[0000320193-25-000079:mdna:102]
Critical Accounting Estimates

[0000320193-25-000079:mdna:103]
The preparation of financial statements and related disclosures in conformity with U.S. generally accepted accounting principles (“GAAP”) and the Company’s discussion and analysis of its financial condition and operating results require the Company’s management to make judgments, assumptions and estimates that affect the amounts reported. Note 1, “Summary of Significant Accounting Policies” of the Notes to Consolidated Financial Statements in Part II, Item 8 of this Form 10-K describes the significant accounting policies and methods used in the preparation of the Company’s consolidated financial statements. Management bases its estimates on historical experience and on various other assumptions it believes to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities.

[0000320193-25-000079:mdna:104]
Uncertain Tax Positions

[0000320193-25-000079:mdna:105]
The Company is subject to income taxes in the U.S. and numerous foreign jurisdictions. The evaluation of the Company’s uncertain tax positions involves significant judgment in the interpretation and application of GAAP and complex domestic and international tax laws, including the TCJA and the allocation of international taxation rights between countries. Although management believes the Company’s reserves are reasonable, no assurance can be given that the final outcome of these uncertainties will not be different from that reflected in the Company’s reserves. Reserves are adjusted considering changing facts and circumstances, such as the closing of a tax examination. Resolution of these uncertainties in a manner inconsistent with management’s expectations could have a material impact on the Company’s financial condition and operating results.

[0000320193-25-000079:mdna:106]
Legal and Other Contingencies

[0000320193-25-000079:mdna:107]
The Company is subject to various legal proceedings and claims that arise in the ordinary course of business, the outcomes of which are inherently uncertain. The Company records a liability when it is probable a loss has been incurred and the amount is reasonably estimable, the determination of which requires significant judgment. Resolution of legal matters in a manner inconsistent with management’s expectations could have a material impact on the Company’s financial condition and operating results.
