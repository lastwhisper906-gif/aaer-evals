# AAPL 8-K — 0000320193-25-000077 filed 2025-10-30

## item codes, every 8-K on or before 2025-10-31

- 2025-10-30 0000320193-25-000077 — 2.02, 9.01
- 2025-07-31 0000320193-25-000071 — 2.02, 9.01
- 2025-07-25 0001140361-25-027340 — 5.02
- 2025-07-09 0001140361-25-025275 — 5.02
- 2025-05-12 0001140361-25-018400 — 8.01, 9.01
- 2025-05-01 0000320193-25-000055 — 2.02, 9.01
- 2025-02-25 0001140361-25-005876 — 5.07
- 2025-01-30 0000320193-25-000007 — 2.02, 9.01
- 2025-01-03 0001140361-25-000228 — 5.02
- 2024-10-31 0000320193-24-000120 — 2.02, 9.01
- 2024-09-10 0001140361-24-040659 — 7.01
- 2024-08-26 0001140361-24-038601 — 5.02
- 2024-08-23 0001140361-24-038403 — 5.03, 9.01
- 2024-08-01 0000320193-24-000080 — 2.02, 9.01
- 2024-05-03 0001140361-24-024352 — 7.01, 9.01
- 2024-05-02 0000320193-24-000067 — 2.02, 9.01
- 2024-02-28 0001140361-24-010155 — 5.07
- 2024-02-01 0000320193-24-000005 — 2.02, 9.01
- 2023-11-02 0000320193-23-000104 — 2.02, 9.01
- 2023-08-03 0000320193-23-000075 — 2.02, 9.01
- 2023-05-10 0001140361-23-023909 — 8.01, 9.01
- 2023-05-04 0000320193-23-000063 — 2.02, 9.01
- 2023-03-10 0001140361-23-011192 — 5.07
- 2023-02-02 0000320193-23-000005 — 2.02, 9.01
- 2022-11-07 0001193125-22-278435 — 7.01, 9.01
- 2022-10-27 0000320193-22-000107 — 2.02, 9.01
- 2022-08-19 0001193125-22-225365 — 5.02, 5.03, 9.01
- 2022-08-08 0001193125-22-214914 — 8.01, 9.01
- 2022-07-28 0000320193-22-000069 — 2.02, 9.01
- 2022-04-28 0000320193-22-000058 — 2.02, 9.01
- 2022-03-04 0001193125-22-066169 — 5.02, 5.07, 9.01
- 2022-01-27 0000320193-22-000006 — 2.02, 9.01
- 2021-11-12 0001193125-21-328151 — 5.02, 5.03, 9.01
- 2021-10-28 0000320193-21-000104 — 2.02, 9.01
- 2021-08-05 0001193125-21-237787 — 8.01, 9.01
- 2021-07-27 0000320193-21-000063 — 2.02, 9.01
- 2021-04-28 0000320193-21-000055 — 2.02, 9.01
- 2021-02-24 0001193125-21-054710 — 5.07
- 2021-02-08 0001193125-21-032394 — 8.01, 9.01
- 2021-01-27 0000320193-21-000009 — 2.02, 9.01
- 2021-01-05 0001193125-21-001982 — 5.02
- 2020-10-29 0000320193-20-000094 — 2.02, 9.01
- 2020-08-20 0001193125-20-225672 — 8.01, 9.01
- 2020-08-07 0001193125-20-213158 — 5.03, 9.01
- 2020-07-30 0000320193-20-000060 — 2.02, 9.01
- 2020-05-11 0001193125-20-139112 — 8.01, 9.01
- 2020-04-30 0000320193-20-000050 — 2.02, 9.01
- 2020-02-27 0001193125-20-050884 — 5.07
- 2020-02-18 0001193125-20-039203 — 7.01, 9.01
- 2020-01-28 0000320193-20-000008 — 2.02, 9.01
- 2019-11-15 0001193125-19-292676 — 8.01, 9.01
- 2019-10-30 0000320193-19-000117 — 2.02, 9.01
- 2019-09-13 0000320193-19-000093 — 5.02
- 2019-09-11 0001193125-19-242975 — 8.01, 9.01
- 2019-07-30 0000320193-19-000073 — 2.02, 9.01
- 2019-04-30 0000320193-19-000063 — 2.02, 9.01
- 2019-03-04 0000320193-19-000032 — 5.07
- 2019-02-06 0000320193-19-000026 — 5.02
- 2019-01-29 0000320193-19-000007 — 2.02, 9.01
- 2019-01-02 0000320193-19-000002 — 2.02, 9.01
- 2018-11-01 0000320193-18-000142 — 2.02, 9.01
- 2018-07-31 0000320193-18-000098 — 2.02, 9.01
- 2018-05-08 0001193125-18-154948 — 8.01 — amendment of 0001193125-18-154515
- 2018-05-07 0001193125-18-154515 — 8.01, 9.01
- 2018-05-01 0000320193-18-000067 — 2.02, 9.01
- 2018-02-14 0001193125-18-045761 — 5.07, 9.01
- 2018-02-01 0000320193-18-000005 — 2.02, 9.01
- 2017-11-13 0001193125-17-341015 — 8.01, 9.01
- 2017-11-02 0000320193-17-000067 — 2.02, 9.01
- 2017-10-12 0001193125-17-308859 — 5.02
- 2017-09-12 0001193125-17-282809 — 8.01, 9.01
- 2017-08-18 0001193125-17-262261 — 8.01, 9.01
- 2017-08-01 0000320193-17-000006 — 2.02, 9.01
- 2017-06-20 0001193125-17-208226 — 8.01, 9.01
- 2017-05-24 0001193125-17-181867 — 8.01, 9.01
- 2017-05-11 0001193125-17-167400 — 8.01, 9.01
- 2017-05-02 0001628280-17-004663 — 2.02, 9.01
- 2017-03-03 0001193125-17-069853 — 8.01, 9.01
- 2017-03-01 0001193125-17-064019 — 5.07
- 2017-02-09 0001193125-17-036283 — 8.01, 9.01
- 2017-01-31 0001628280-17-000663 — 2.02, 9.01
- 2016-12-15 0001628280-16-022047 — 5.03, 9.01
- 2016-10-25 0001628280-16-020258 — 2.02, 9.01
- 2016-08-04 0001193125-16-672044 — 8.01, 9.01
- 2016-07-26 0001628280-16-017762 — 2.02, 9.01
- 2016-06-22 0001193125-16-628957 — 8.01, 9.01
- 2016-04-26 0001193125-16-556520 — 2.02, 9.01
- 2016-03-24 0001193125-16-516891 — 8.01, 9.01
- 2016-03-01 0001193125-16-488223 — 5.02, 5.07, 9.01
- 2016-02-23 0001193125-16-473562 — 8.01, 9.01
- 2016-01-26 0001193125-16-438421 — 2.02, 9.01
- 2015-12-22 0001193125-15-410853 — 5.03, 9.01
- 2015-12-17 0001193125-15-406279 — 5.02
- 2015-10-27 0001193125-15-354756 — 2.02, 9.01
- 2015-10-02 0001193125-15-336615 — 5.02
- 2015-09-17 0001193125-15-322466 — 8.01, 9.01
- 2015-07-31 0001193125-15-273023 — 8.01, 9.01
- 2015-07-21 0001193125-15-258464 — 2.02, 9.01
- 2015-06-10 0001193125-15-219298 — 8.01, 9.01
- 2015-05-13 0001193125-15-186064 — 8.01, 9.01
- 2015-04-27 0001193125-15-149607 — 7.01, 9.01
- 2015-04-27 0001193125-15-149590 — 2.02, 9.01
- 2015-03-13 0001104659-15-019336 — 5.07, 9.01
- 2015-02-09 0001193125-15-039270 — 8.01, 9.01
- 2015-01-28 0001193125-15-023732 — 8.01, 9.01
- 2015-01-27 0001193125-15-021857 — 2.02, 9.01
- 2014-11-10 0001193125-14-406296 — 8.01, 9.01
- 2014-10-20 0001193125-14-376361 — 2.02, 9.01
- 2014-07-23 0001193125-14-277193 — 8.01, 9.01
- 2014-07-22 0001193125-14-275598 — 2.02, 9.01
- 2014-07-17 0001193125-14-271698 — 5.02
- 2014-06-06 0001193125-14-228798 — 5.03, 9.01
- 2014-05-30 0001181431-14-021923 — 5.02
- 2014-05-06 0001193125-14-184969 — 8.01, 9.01
- 2014-04-23 0001193125-14-154883 — 7.01, 9.01
- 2014-04-23 0001193125-14-154871 — 2.02, 9.01
- 2014-03-05 0001193125-14-084697 — 5.02, 5.03, 5.07, 9.01
- 2014-01-27 0001193125-14-022238 — 2.02, 9.01
- 2013-10-28 0001193125-13-413498 — 2.02, 9.01
- 2013-09-23 0001181431-13-050140 — 8.01
- 2013-07-30 0001181431-13-041847 — 5.02
- 2013-07-23 0001193125-13-298914 — 2.02, 9.01
- 2013-06-21 0001193125-13-267629 — 5.02
- 2013-05-03 0001193125-13-199324 — 8.01, 9.01
- 2013-04-24 0001193125-13-170623 — 8.01, 9.01
- 2013-04-23 0001193125-13-167469 — 7.01, 9.01
- 2013-04-23 0001193125-13-167458 — 2.02, 9.01
- 2013-03-01 0001193125-13-085842 — 5.07
- 2013-01-23 0001193125-13-020783 — 2.02, 9.01
- 2012-10-25 0001193125-12-435506 — 2.02, 9.01
- 2012-07-24 0001193125-12-312355 — 2.02, 9.01
- 2012-06-28 0001181431-12-038301 — 5.02
- 2012-05-24 0001181431-12-032458 — 5.02
- 2012-04-24 0001193125-12-178928 — 2.02, 9.01
- 2012-02-27 0001193125-12-081892 — 5.07
- 2012-01-24 0001193125-12-021833 — 2.02, 9.01
- 2011-11-16 0001181431-11-056354 — 5.02
- 2011-10-18 0001193125-11-273826 — 2.02, 9.01
- 2011-10-06 0001181431-11-051976 — 8.01
- 2011-08-26 0001181431-11-047179 — 5.02
- 2011-07-19 0001193125-11-191368 — 2.02, 9.01
- 2011-06-15 0001181431-11-036782 — 5.02
- 2011-04-20 0001193125-11-103732 — 2.02, 9.01
- 2011-02-24 0001193125-11-045411 — 5.07
- 2011-01-18 0001193125-11-009392 — 2.02, 9.01
- 2011-01-18 0001181431-11-003847 — 5.02
- 2010-11-17 0001181431-10-056327 — 5.02, 5.03, 9.01
- 2010-10-18 0001193125-10-230992 — 2.02, 9.01
- 2010-07-20 0001193125-10-161807 — 2.02, 9.01
- 2010-04-20 0001193125-10-087786 — 2.02, 9.01
- 2010-03-12 0001181431-10-016054 — 5.02
- 2010-03-01 0001193125-10-044765 — 5.02, 5.07, 9.01
- 2010-01-25 0001193125-10-012096 — 2.02, 9.01
- 2009-10-19 0001193125-09-209633 — 2.02, 9.01
- 2009-08-04 0001181431-09-037492 — 5.02
- 2009-07-21 0001193125-09-152290 — 2.02, 9.01
- 2009-06-02 0001181431-09-028400 — 5.03
- 2009-04-22 0001193125-09-084599 — 2.02, 9.01
- 2009-02-27 0001181431-09-012161 — 4.01
- 2009-01-21 0001193125-09-009009 — 2.02, 9.01
- 2009-01-16 0001181431-09-003017 — 5.02
- 2008-10-21 0001193125-08-213642 — 2.02, 9.01
- 2008-08-26 0001181431-08-050059 — 5.03
- 2008-07-21 0001193125-08-154381 — 2.02, 9.01
- 2008-06-09 0001181431-08-037620 — 8.01
- 2008-04-23 0001193125-08-088001 — 2.02, 9.01
- 2008-01-22 0001193125-08-009715 — 2.02, 9.01
- 2008-01-15 0001181431-08-003342 — 2.02, 8.01
- 2008-01-08 0001181431-08-002372 — 5.02
- 2007-10-22 0001104659-07-076142 — 2.02, 9.01
- 2007-07-25 0001104659-07-056111 — 2.02, 9.01
- 2007-05-16 0001104659-07-040672 — 5.02, 9.01
- 2007-04-25 0001104659-07-031354 — 2.02, 9.01
- 2007-04-24 0001104659-07-030938 — 8.01, 9.01
- 2007-02-21 0001104659-07-012760 — 5.03, 9.01
- 2007-01-17 0001104659-07-002905 — 2.02, 9.01
- 2007-01-10 0001104659-07-001648 — 5.03, 9.01
- 2006-10-27 0001104659-06-069015 — 8.01
- 2006-10-18 0001104659-06-067275 — 2.02, 9.01
- 2006-10-04 0001104659-06-064935 — 5.02, 8.01, 9.01
- 2006-09-01 0001104659-06-058808 — 1.01, 5.02, 5.03, 9.01
- 2006-08-11 0001104659-06-054118 — 2.02, 3.01, 9.01
- 2006-08-04 0001104659-06-051302 — 2.02, 4.02, 9.01
- 2006-07-19 0001104659-06-047739 — 2.02, 9.01
- 2006-04-21 0001181431-06-024759 — 1.01
- 2006-04-19 0001104659-06-025992 — 2.02, 9.01
- 2006-01-18 0001104659-06-002690 — 2.02, 9.01
- 2006-01-10 0001104659-06-001428 — 2.02
- 2005-12-19 0001181431-05-067468 — 1.01
- 2005-10-14 0001181431-05-056604 — 5.02
- 2005-10-11 0001104659-05-048094 — 2.02, 9.01
- 2005-08-26 0001181431-05-049163 — 1.01
- 2005-08-15 0001181431-05-046871 — 1.01
- 2005-07-13 0001104659-05-032297 — 2.02, 9.01
- 2005-06-06 0001181431-05-033177 — 8.01
- 2005-04-26 0001181431-05-023450 — 1.01
- 2005-04-13 0001104659-05-016307 — 2.02, 9.01
- 2005-03-02 0001181431-05-013840 — 3.03, 5.03
- 2005-02-11 0001104659-05-005507 — 8.01
- 2005-01-12 0001104659-05-001183 — 2.02, 9.01
- 2005-01-11 0001104659-05-001049 — 2.02
- 2004-10-13 0001104659-04-030400 — 2.02, 9.01
- 2004-07-14 0001104659-04-019574 — 12, 7
- 2004-04-14 0001104659-04-010122 — 12, 7
- 2004-01-14 0001104659-04-000896 — 12, 7
- 2003-10-15 0001104659-03-022879 — 12, 7
- 2003-07-16 0001104659-03-014913 — 7, 9
- 2003-04-16 0001047469-03-013617 — 7, 9
- 2003-03-21 0001104659-03-004649 — 5, 7
- 2002-08-13 0000912057-02-031595 — 5, 7
- 2002-08-05 0000912057-02-029692 — 5, 7
- 2000-01-24 0000912057-00-002128 — 5, 7
- 1999-09-07 0000320193-99-000010 — 2
- 1999-07-16 0000320193-99-000007 — 2
- 1998-12-23 0000320193-98-000010 — 1
- 1998-01-08 0000320193-98-000001 — 2
- 1997-09-25 0000320193-97-000019 — 2
- 1997-09-25 0000320193-97-000018 — 2
- 1997-09-05 0000320193-97-000016 — 2
- 1997-07-28 0000320193-97-000012 — 4
- 1997-04-25 0000320193-97-000009 — 5
- 1997-04-10 0000320193-97-000007 — 7
- 1996-12-24 0000320193-96-000027 — 7
- 1996-12-23 0000320193-96-000025 — 4 — amendment of 0000320193-96-000021
- 1996-12-13 0000320193-96-000021 — 4
- 1996-10-28 0000912057-96-023874 — 5, 7
- 1996-06-17 0000320193-96-000014 — 1
- 1996-04-12 0000320193-96-000006 — 1

## late-filing notifications on or before 2025-10-31

- 2006-12-15 0001104659-06-081617 — NT 10-K, for the period ended 2006-09-30
- 2006-08-11 0001104659-06-053743 — NT 10-Q, for the period ended 2006-07-01

## item 2.02 — earnings release, exhibit 99.1

[0000320193-25-000077:8k_2_02:1]
EX-99.1
2
a8-kex991q4202509272025.htm
EX-99.1

[0000320193-25-000077:8k_2_02:2]
Document

[0000320193-25-000077:8k_2_02:3]
Exhibit 99.1

[0000320193-25-000077:8k_2_02:4]
Apple reports fourth quarter results

[0000320193-25-000077:8k_2_02:5]
September quarter records for total company revenue, iPhone revenue and EPS

[0000320193-25-000077:8k_2_02:6]
Services revenue reaches new all-time high

[0000320193-25-000077:8k_2_02:7]
CUPERTINO, CALIFORNIA — Apple® today announced financial results for its fiscal 2025 fourth quarter ended September 27, 2025. The Company posted quarterly revenue of $102.5 billion, up 8 percent year over year. Diluted earnings per share was $1.85, up 13 percent year over year on an adjusted basis.1

[0000320193-25-000077:8k_2_02:8]
“Today, Apple is very proud to report a September quarter revenue record of $102.5 billion, including a September quarter revenue record for iPhone and an all-time revenue record for Services,” said Tim Cook, Apple’s CEO. “In September, we were thrilled to launch our best iPhone lineup ever, including iPhone 17, iPhone 17 Pro and Pro Max, and iPhone Air. In addition, we launched the fantastic AirPods Pro 3 and the all-new Apple Watch lineup. When combined with the recently announced MacBook Pro and iPad Pro with the powerhouse M5 chip, we are excited to be sharing our most extraordinary lineup of products as we head into the holiday season.”

[0000320193-25-000077:8k_2_02:9]
“Our September quarter results capped off a record fiscal year, with revenue reaching $416 billion, as well as double-digit EPS growth,” said Kevan Parekh, Apple’s CFO. “And thanks to our very high levels of customer satisfaction and loyalty, our installed base of active devices also reached a new all-time high across all product categories and geographic segments.”

[0000320193-25-000077:8k_2_02:10]
Apple’s board of directors has declared a cash dividend of $0.26 per share of the Company’s common stock. The dividend is payable on November 13, 2025, to shareholders of record as of the close of business on November 10, 2025.

[0000320193-25-000077:8k_2_02:11]
Apple will provide live streaming of its Q4 2025 financial results conference call beginning at 2:00 p.m. PT on October 30, 2025, at apple.com/investor/earnings-call. The webcast will be available for replay for approximately two weeks thereafter.

[0000320193-25-000077:8k_2_02:12]
Apple periodically provides information for investors on its corporate website, apple.com, and its investor relations website, investor.apple.com. This includes press releases and other information about financial performance, reports filed or furnished with the SEC, information on corporate governance, and details related to its annual meeting of shareholders.

[0000320193-25-000077:8k_2_02:13]
1. Non-GAAP measure excluding the one-time income tax charge recognized during the fourth quarter of 2024 related to the impact of the reversal of the European General Court’s State Aid decision. See the section titled “Reconciliation of 2024 Non-GAAP to GAAP Results of Operations” at the end of the accompanying financial statements.

[0000320193-25-000077:8k_2_02:14]
Apple revolutionized personal technology with the introduction of the Macintosh in 1984. Today, Apple leads the world in innovation with iPhone, iPad, Mac, AirPods, Apple Watch, and Apple Vision Pro. Apple’s six software platforms — iOS, iPadOS, macOS, watchOS, visionOS, and tvOS — provide seamless experiences across all Apple devices and empower people with breakthrough services including the App Store, Apple Music, Apple Pay, iCloud, and Apple TV. Apple’s more than 150,000 employees are dedicated to making the best products on earth and to leaving the world better than we found it.

[0000320193-25-000077:8k_2_02:15]
Press Contact:

[0000320193-25-000077:8k_2_02:16]
Josh Rosenstock

[0000320193-25-000077:8k_2_02:17]
Apple

[0000320193-25-000077:8k_2_02:18]
jrosenstock@apple.com

[0000320193-25-000077:8k_2_02:19]
(408) 862-1142

[0000320193-25-000077:8k_2_02:20]
Investor Relations Contact:

[0000320193-25-000077:8k_2_02:21]
Suhasini Chandramouli

[0000320193-25-000077:8k_2_02:22]
Apple

[0000320193-25-000077:8k_2_02:23]
suhasini@apple.com

[0000320193-25-000077:8k_2_02:24]
(408) 974-3123

[0000320193-25-000077:8k_2_02:25]
NOTE TO EDITORS: For additional information visit Apple Newsroom (www.apple.com/newsroom), or email Apple’s Media Helpline at media.help@apple.com.

[0000320193-25-000077:8k_2_02:26]
© 2025 Apple Inc. All rights reserved. Apple and the Apple logo are trademarks of Apple. Other company and product names may be trademarks of their respective owners.

[0000320193-25-000077:8k_2_02:27]
Apple Inc.

[0000320193-25-000077:8k_2_02:28]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS (Unaudited)

[0000320193-25-000077:8k_2_02:29]
(In millions, except number of shares, which are reflected in thousands, and per-share amounts)

[0000320193-25-000077:8k_2_02:30]
|  | Three Months Ended |  | Twelve Months Ended |
|  | September 27,2025 |  | September 28,2024 |  | September 27,2025 |  | September 28,2024 |
| Net sales: |  |  |  |  |  |  |  |
| Products | $ | 73,716 |  |  | $ | 69,958 |  |  | $ | 307,003 |  |  | $ | 294,866 |  |
| Services | 28,750 |  |  | 24,972 |  |  | 109,158 |  |  | 96,169 |  |
| Total net sales (1) | 102,466 |  |  | 94,930 |  |  | 416,161 |  |  | 391,035 |  |
| Cost of sales: |  |  |  |  |  |  |  |
| Products | 47,019 |  |  | 44,566 |  |  | 194,116 |  |  | 185,233 |  |
| Services | 7,106 |  |  | 6,485 |  |  | 26,844 |  |  | 25,119 |  |
| Total cost of sales | 54,125 |  |  | 51,051 |  |  | 220,960 |  |  | 210,352 |  |
| Gross margin | 48,341 |  |  | 43,879 |  |  | 195,201 |  |  | 180,683 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 8,866 |  |  | 7,765 |  |  | 34,550 |  |  | 31,370 |  |
| Selling, general and administrative | 7,048 |  |  | 6,523 |  |  | 27,601 |  |  | 26,097 |  |
| Total operating expenses | 15,914 |  |  | 14,288 |  |  | 62,151 |  |  | 57,467 |  |
| Operating income | 32,427 |  |  | 29,591 |  |  | 133,050 |  |  | 123,216 |  |
| Other income/(expense), net | 377 |  |  | 19 |  |  | (321) |  |  | 269 |  |
| Income before provision for income taxes | 32,804 |  |  | 29,610 |  |  | 132,729 |  |  | 123,485 |  |
| Provision for income taxes | 5,338 |  |  | 14,874 |  |  | 20,719 |  |  | 29,749 |  |
| Net income | $ | 27,466 |  |  | $ | 14,736 |  |  | $ | 112,010 |  |  | $ | 93,736 |  |
| Earnings per share: |  |  |  |  |  |  |  |
| Basic | $ | 1.85 |  |  | $ | 0.97 |  |  | $ | 7.49 |  |  | $ | 6.11 |  |
| Diluted | $ | 1.85 |  |  | $ | 0.97 |  |  | $ | 7.46 |  |  | $ | 6.08 |  |
| Shares used in computing earnings per share: |  |  |  |  |  |  |  |
| Basic | 14,815,307 |  |  | 15,171,990 |  |  | 14,948,500 |  |  | 15,343,783 |  |
| Diluted | 14,863,609 |  |  | 15,242,853 |  |  | 15,004,697 |  |  | 15,408,095 |  |
| (1) Net sales by reportable segment: |  |  |  |  |  |  |  |
| Americas | $ | 44,192 |  |  | $ | 41,664 |  |  | $ | 178,353 |  |  | $ | 167,045 |  |
| Europe | 28,703 |  |  | 24,924 |  |  | 111,032 |  |  | 101,328 |  |
| Greater China | 14,493 |  |  | 15,033 |  |  | 64,377 |  |  | 66,952 |  |
| Japan | 6,636 |  |  | 5,926 |  |  | 28,703 |  |  | 25,052 |  |
| Rest of Asia Pacific | 8,442 |  |  | 7,383 |  |  | 33,696 |  |  | 30,658 |  |
| Total net sales | $ | 102,466 |  |  | $ | 94,930 |  |  | $ | 416,161 |  |  | $ | 391,035 |  |
| (1) Net sales by category: |  |  |  |  |  |  |  |
| iPhone | $ | 49,025 |  |  | $ | 46,222 |  |  | $ | 209,586 |  |  | $ | 201,183 |  |
| Mac | 8,726 |  |  | 7,744 |  |  | 33,708 |  |  | 29,984 |  |
| iPad | 6,952 |  |  | 6,950 |  |  | 28,023 |  |  | 26,694 |  |
| Wearables, Home and Accessories | 9,013 |  |  | 9,042 |  |  | 35,686 |  |  | 37,005 |  |
| Services | 28,750 |  |  | 24,972 |  |  | 109,158 |  |  | 96,169 |  |
| Total net sales | $ | 102,466 |  |  | $ | 94,930 |  |  | $ | 416,161 |  |  | $ | 391,035 |  |

[0000320193-25-000077:8k_2_02:31]
Apple Inc.

[0000320193-25-000077:8k_2_02:32]
CONDENSED CONSOLIDATED BALANCE SHEETS (Unaudited)

[0000320193-25-000077:8k_2_02:33]
(In millions, except number of shares, which are reflected in thousands, and par value)

[0000320193-25-000077:8k_2_02:34]
|  | September 27,2025 |  | September 28,2024 |
| ASSETS: |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 35,934 |  |  | $ | 29,943 |  |
| Marketable securities | 18,763 |  |  | 35,228 |  |
| Accounts receivable, net | 39,777 |  |  | 33,410 |  |
| Vendor non-trade receivables | 33,180 |  |  | 32,833 |  |
| Inventories | 5,718 |  |  | 7,286 |  |
| Other current assets | 14,585 |  |  | 14,287 |  |
| Total current assets | 147,957 |  |  | 152,987 |  |
| Non-current assets: |  |  |  |
| Marketable securities | 77,723 |  |  | 91,479 |  |
| Property, plant and equipment, net | 49,834 |  |  | 45,680 |  |
| Other non-current assets | 83,727 |  |  | 74,834 |  |
| Total non-current assets | 211,284 |  |  | 211,993 |  |
| Total assets | $ | 359,241 |  |  | $ | 364,980 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY: |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 69,860 |  |  | $ | 68,960 |  |
| Other current liabilities | 66,387 |  |  | 78,304 |  |
| Deferred revenue | 9,055 |  |  | 8,249 |  |
| Commercial paper | 7,979 |  |  | 9,967 |  |
| Term debt | 12,350 |  |  | 10,912 |  |
| Total current liabilities | 165,631 |  |  | 176,392 |  |
| Non-current liabilities: |  |  |  |
| Term debt | 78,328 |  |  | 85,750 |  |
| Other non-current liabilities | 41,549 |  |  | 45,888 |  |
| Total non-current liabilities | 119,877 |  |  | 131,638 |  |
| Total liabilities | 285,508 |  |  | 308,030 |  |
| Commitments and contingencies |  |  |  |
| Shareholders’ equity: |  |  |  |
| Common stock and additional paid-in capital, $0.00001 par value: 50,400,000 shares authorized; 14,773,260 and 15,116,786 shares issued and outstanding, respectively | 93,568 |  |  | 83,276 |  |
| Accumulated deficit | (14,264) |  |  | (19,154) |  |
| Accumulated other comprehensive loss | (5,571) |  |  | (7,172) |  |
| Total shareholders’ equity | 73,733 |  |  | 56,950 |  |
| Total liabilities and shareholders’ equity | $ | 359,241 |  |  | $ | 364,980 |  |

[0000320193-25-000077:8k_2_02:35]
Apple Inc.

[0000320193-25-000077:8k_2_02:36]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (Unaudited)

[0000320193-25-000077:8k_2_02:37]
(In millions)

[0000320193-25-000077:8k_2_02:38]
|  | Twelve Months Ended |
|  | September 27,2025 |  | September 28,2024 |
| Cash, cash equivalents, and restricted cash and cash equivalents, beginning balances | $ | 29,943 |  |  | $ | 30,737 |  |
| Operating activities: |  |  |  |
| Net income | 112,010 |  |  | 93,736 |  |
| Adjustments to reconcile net income to cash generated by operating activities: |  |  |  |
| Depreciation and amortization | 11,698 |  |  | 11,445 |  |
| Share-based compensation expense | 12,863 |  |  | 11,688 |  |
| Other | (89) |  |  | (2,266) |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | (6,682) |  |  | (3,788) |  |
| Vendor non-trade receivables | (347) |  |  | (1,356) |  |
| Inventories | 1,400 |  |  | (1,046) |  |
| Other current and non-current assets | (9,197) |  |  | (11,731) |  |
| Accounts payable | 902 |  |  | 6,020 |  |
| Other current and non-current liabilities | (11,076) |  |  | 15,552 |  |
| Cash generated by operating activities | 111,482 |  |  | 118,254 |  |
| Investing activities: |  |  |  |
| Purchases of marketable securities | (24,407) |  |  | (48,656) |  |
| Proceeds from maturities of marketable securities | 40,907 |  |  | 51,211 |  |
| Proceeds from sales of marketable securities | 12,890 |  |  | 11,135 |  |
| Payments for acquisition of property, plant and equipment | (12,715) |  |  | (9,447) |  |
| Other | (1,480) |  |  | (1,308) |  |
| Cash generated by investing activities | 15,195 |  |  | 2,935 |  |
| Financing activities: |  |  |  |
| Payments for taxes related to net share settlement of equity awards | (5,960) |  |  | (5,441) |  |
| Payments for dividends and dividend equivalents | (15,421) |  |  | (15,234) |  |
| Repurchases of common stock | (90,711) |  |  | (94,949) |  |
| Proceeds from issuance of term debt, net | 4,481 |  |  | — |  |
| Repayments of term debt | (10,932) |  |  | (9,958) |  |
| Proceeds from/(Repayments of) commercial paper, net | (2,032) |  |  | 3,960 |  |
| Other | (111) |  |  | (361) |  |
| Cash used in financing activities | (120,686) |  |  | (121,983) |  |
| Increase/(Decrease) in cash, cash equivalents, and restricted cash and cash equivalents | 5,991 |  |  | (794) |  |
| Cash, cash equivalents, and restricted cash and cash equivalents, ending balances | $ | 35,934 |  |  | $ | 29,943 |  |
| Supplemental cash flow disclosure: |  |  |  |
| Cash paid for income taxes, net | $ | 43,369 |  |  | $ | 26,102 |  |

[0000320193-25-000077:8k_2_02:39]
Apple Inc.

[0000320193-25-000077:8k_2_02:40]
RECONCILIATION OF 2024 NON-GAAP TO GAAP RESULTS OF OPERATIONS (Unaudited)

[0000320193-25-000077:8k_2_02:41]
(In millions, except number of shares, which are reflected in thousands, and per-share amounts)

[0000320193-25-000077:8k_2_02:42]
|  | Three Months Ended |  | Twelve Months Ended |
|  | September 28, 2024 |  | September 28, 2024 |
|  | As Reported (GAAP) |  | Non-GAAP Adjustments | (a) |  | As Adjusted (Non-GAAP) |  | As Reported (GAAP) |  | Non-GAAP Adjustments | (a) |  | As Adjusted (Non-GAAP) |
| Income before provision for income taxes | $ | 29,610 |  |  | $ | — |  |  |  | $ | 29,610 |  |  | $ | 123,485 |  |  | $ | — |  |  |  | $ | 123,485 |  |
| Provision for income taxes | 14,874 |  |  | (10,246) |  | (b) |  | 4,628 |  |  | 29,749 |  |  | (10,246) |  | (b) |  | 19,503 |  |
| Net income | $ | 14,736 |  |  | $ | 10,246 |  | (b) |  | $ | 24,982 |  |  | $ | 93,736 |  |  | $ | 10,246 |  | (b) |  | $ | 103,982 |  |
| Diluted earnings per share | $ | 0.97 |  |  | $ | 0.67 |  | (c) |  | $ | 1.64 |  |  | $ | 6.08 |  |  | $ | 0.67 |  | (c) |  | $ | 6.75 |  |
| Shares used in computing diluted earnings per share | 15,242,853 |  |  | — |  |  |  | 15,242,853 |  |  | 15,408,095 |  |  | — |  |  |  | 15,408,095 |  |

[0000320193-25-000077:8k_2_02:43]
(a)These adjustments reconcile certain of the Company’s GAAP results of operations to its non-GAAP results of operations. The Company believes that the presentation of results excluding the impact of the reversal of the European General Court’s State Aid decision provides meaningful supplemental information to both management and investors that is indicative of the Company’s core operating results and facilitates comparison of operating results across reporting periods. The Company uses these non-GAAP measures when evaluating its financial results as well as for internal planning and forecasting purposes. These non-GAAP measures should not be viewed as a substitute for the Company’s GAAP results.

[0000320193-25-000077:8k_2_02:44]
(b)Non-GAAP adjustments to provision for income taxes and net income to reflect the impact of the reversal of the European General Court’s State Aid decision recognized during the fourth quarter of 2024. On September 10, 2024, the European Court of Justice announced that it had set aside the 2020 judgment of the European General Court and confirmed the European Commission’s 2016 State Aid decision. As a result, during the fourth quarter of 2024 the Company recorded a one-time income tax charge of $10.2 billion, net, which represented $15.8 billion payable to Ireland via release of restricted funds held in escrow, partially offset by a U.S. foreign tax credit of $4.8 billion and a decrease in unrecognized tax benefits of $823 million. For additional information, refer to Note 7, “Income Taxes” of the Notes to Consolidated Financial Statements in Part II, Item 8 of the Company's fiscal 2024 Annual Report on Form 10-K.

[0000320193-25-000077:8k_2_02:45]
(c)Represents the per-share impact of the non-GAAP adjustments to net income.
