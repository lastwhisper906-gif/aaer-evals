# AAPL 8-K — 0000320193-19-000063 filed 2019-04-30

## item codes, every 8-K on or before 2019-05-01

- 2019-04-30 0000320193-19-000063 — 2.02, 9.01
- 2019-03-04 0000320193-19-000032 — 5.07
- 2019-02-06 0000320193-19-000026 — 5.02
- 2019-01-29 0000320193-19-000007 — 2.02, 9.01
- 2019-01-02 0000320193-19-000002 — 2.02, 9.01
- 2018-11-01 0000320193-18-000142 — 2.02, 9.01
- 2018-07-31 0000320193-18-000098 — 2.02, 9.01
- 2018-05-08 0001193125-18-154948 — 8.01 — amendment of 0001193125-18-154515
- 2018-05-07 0001193125-18-154515 — 8.01, 9.01
- 2018-05-01 0000320193-18-000067 — 2.02, 9.01
- 2018-02-14 0001193125-18-045761 — 5.07, 9.01
- 2018-02-01 0000320193-18-000005 — 2.02, 9.01
- 2017-11-13 0001193125-17-341015 — 8.01, 9.01
- 2017-11-02 0000320193-17-000067 — 2.02, 9.01
- 2017-10-12 0001193125-17-308859 — 5.02
- 2017-09-12 0001193125-17-282809 — 8.01, 9.01
- 2017-08-18 0001193125-17-262261 — 8.01, 9.01
- 2017-08-01 0000320193-17-000006 — 2.02, 9.01
- 2017-06-20 0001193125-17-208226 — 8.01, 9.01
- 2017-05-24 0001193125-17-181867 — 8.01, 9.01
- 2017-05-11 0001193125-17-167400 — 8.01, 9.01
- 2017-05-02 0001628280-17-004663 — 2.02, 9.01
- 2017-03-03 0001193125-17-069853 — 8.01, 9.01
- 2017-03-01 0001193125-17-064019 — 5.07
- 2017-02-09 0001193125-17-036283 — 8.01, 9.01
- 2017-01-31 0001628280-17-000663 — 2.02, 9.01
- 2016-12-15 0001628280-16-022047 — 5.03, 9.01
- 2016-10-25 0001628280-16-020258 — 2.02, 9.01
- 2016-08-04 0001193125-16-672044 — 8.01, 9.01
- 2016-07-26 0001628280-16-017762 — 2.02, 9.01
- 2016-06-22 0001193125-16-628957 — 8.01, 9.01
- 2016-04-26 0001193125-16-556520 — 2.02, 9.01
- 2016-03-24 0001193125-16-516891 — 8.01, 9.01
- 2016-03-01 0001193125-16-488223 — 5.02, 5.07, 9.01
- 2016-02-23 0001193125-16-473562 — 8.01, 9.01
- 2016-01-26 0001193125-16-438421 — 2.02, 9.01
- 2015-12-22 0001193125-15-410853 — 5.03, 9.01
- 2015-12-17 0001193125-15-406279 — 5.02
- 2015-10-27 0001193125-15-354756 — 2.02, 9.01
- 2015-10-02 0001193125-15-336615 — 5.02
- 2015-09-17 0001193125-15-322466 — 8.01, 9.01
- 2015-07-31 0001193125-15-273023 — 8.01, 9.01
- 2015-07-21 0001193125-15-258464 — 2.02, 9.01
- 2015-06-10 0001193125-15-219298 — 8.01, 9.01
- 2015-05-13 0001193125-15-186064 — 8.01, 9.01
- 2015-04-27 0001193125-15-149607 — 7.01, 9.01
- 2015-04-27 0001193125-15-149590 — 2.02, 9.01
- 2015-03-13 0001104659-15-019336 — 5.07, 9.01
- 2015-02-09 0001193125-15-039270 — 8.01, 9.01
- 2015-01-28 0001193125-15-023732 — 8.01, 9.01
- 2015-01-27 0001193125-15-021857 — 2.02, 9.01
- 2014-11-10 0001193125-14-406296 — 8.01, 9.01
- 2014-10-20 0001193125-14-376361 — 2.02, 9.01
- 2014-07-23 0001193125-14-277193 — 8.01, 9.01
- 2014-07-22 0001193125-14-275598 — 2.02, 9.01
- 2014-07-17 0001193125-14-271698 — 5.02
- 2014-06-06 0001193125-14-228798 — 5.03, 9.01
- 2014-05-30 0001181431-14-021923 — 5.02
- 2014-05-06 0001193125-14-184969 — 8.01, 9.01
- 2014-04-23 0001193125-14-154883 — 7.01, 9.01
- 2014-04-23 0001193125-14-154871 — 2.02, 9.01
- 2014-03-05 0001193125-14-084697 — 5.02, 5.03, 5.07, 9.01
- 2014-01-27 0001193125-14-022238 — 2.02, 9.01
- 2013-10-28 0001193125-13-413498 — 2.02, 9.01
- 2013-09-23 0001181431-13-050140 — 8.01
- 2013-07-30 0001181431-13-041847 — 5.02
- 2013-07-23 0001193125-13-298914 — 2.02, 9.01
- 2013-06-21 0001193125-13-267629 — 5.02
- 2013-05-03 0001193125-13-199324 — 8.01, 9.01
- 2013-04-24 0001193125-13-170623 — 8.01, 9.01
- 2013-04-23 0001193125-13-167469 — 7.01, 9.01
- 2013-04-23 0001193125-13-167458 — 2.02, 9.01
- 2013-03-01 0001193125-13-085842 — 5.07
- 2013-01-23 0001193125-13-020783 — 2.02, 9.01
- 2012-10-25 0001193125-12-435506 — 2.02, 9.01
- 2012-07-24 0001193125-12-312355 — 2.02, 9.01
- 2012-06-28 0001181431-12-038301 — 5.02
- 2012-05-24 0001181431-12-032458 — 5.02
- 2012-04-24 0001193125-12-178928 — 2.02, 9.01
- 2012-02-27 0001193125-12-081892 — 5.07
- 2012-01-24 0001193125-12-021833 — 2.02, 9.01
- 2011-11-16 0001181431-11-056354 — 5.02
- 2011-10-18 0001193125-11-273826 — 2.02, 9.01
- 2011-10-06 0001181431-11-051976 — 8.01
- 2011-08-26 0001181431-11-047179 — 5.02
- 2011-07-19 0001193125-11-191368 — 2.02, 9.01
- 2011-06-15 0001181431-11-036782 — 5.02
- 2011-04-20 0001193125-11-103732 — 2.02, 9.01
- 2011-02-24 0001193125-11-045411 — 5.07
- 2011-01-18 0001193125-11-009392 — 2.02, 9.01
- 2011-01-18 0001181431-11-003847 — 5.02
- 2010-11-17 0001181431-10-056327 — 5.02, 5.03, 9.01
- 2010-10-18 0001193125-10-230992 — 2.02, 9.01
- 2010-07-20 0001193125-10-161807 — 2.02, 9.01
- 2010-04-20 0001193125-10-087786 — 2.02, 9.01
- 2010-03-12 0001181431-10-016054 — 5.02
- 2010-03-01 0001193125-10-044765 — 5.02, 5.07, 9.01
- 2010-01-25 0001193125-10-012096 — 2.02, 9.01
- 2009-10-19 0001193125-09-209633 — 2.02, 9.01
- 2009-08-04 0001181431-09-037492 — 5.02
- 2009-07-21 0001193125-09-152290 — 2.02, 9.01
- 2009-06-02 0001181431-09-028400 — 5.03
- 2009-04-22 0001193125-09-084599 — 2.02, 9.01
- 2009-02-27 0001181431-09-012161 — 4.01
- 2009-01-21 0001193125-09-009009 — 2.02, 9.01
- 2009-01-16 0001181431-09-003017 — 5.02
- 2008-10-21 0001193125-08-213642 — 2.02, 9.01
- 2008-08-26 0001181431-08-050059 — 5.03
- 2008-07-21 0001193125-08-154381 — 2.02, 9.01
- 2008-06-09 0001181431-08-037620 — 8.01
- 2008-04-23 0001193125-08-088001 — 2.02, 9.01
- 2008-01-22 0001193125-08-009715 — 2.02, 9.01
- 2008-01-15 0001181431-08-003342 — 2.02, 8.01
- 2008-01-08 0001181431-08-002372 — 5.02
- 2007-10-22 0001104659-07-076142 — 2.02, 9.01
- 2007-07-25 0001104659-07-056111 — 2.02, 9.01
- 2007-05-16 0001104659-07-040672 — 5.02, 9.01
- 2007-04-25 0001104659-07-031354 — 2.02, 9.01
- 2007-04-24 0001104659-07-030938 — 8.01, 9.01
- 2007-02-21 0001104659-07-012760 — 5.03, 9.01
- 2007-01-17 0001104659-07-002905 — 2.02, 9.01
- 2007-01-10 0001104659-07-001648 — 5.03, 9.01
- 2006-10-27 0001104659-06-069015 — 8.01
- 2006-10-18 0001104659-06-067275 — 2.02, 9.01
- 2006-10-04 0001104659-06-064935 — 5.02, 8.01, 9.01
- 2006-09-01 0001104659-06-058808 — 1.01, 5.02, 5.03, 9.01
- 2006-08-11 0001104659-06-054118 — 2.02, 3.01, 9.01
- 2006-08-04 0001104659-06-051302 — 2.02, 4.02, 9.01
- 2006-07-19 0001104659-06-047739 — 2.02, 9.01
- 2006-04-21 0001181431-06-024759 — 1.01
- 2006-04-19 0001104659-06-025992 — 2.02, 9.01
- 2006-01-18 0001104659-06-002690 — 2.02, 9.01
- 2006-01-10 0001104659-06-001428 — 2.02
- 2005-12-19 0001181431-05-067468 — 1.01
- 2005-10-14 0001181431-05-056604 — 5.02
- 2005-10-11 0001104659-05-048094 — 2.02, 9.01
- 2005-08-26 0001181431-05-049163 — 1.01
- 2005-08-15 0001181431-05-046871 — 1.01
- 2005-07-13 0001104659-05-032297 — 2.02, 9.01
- 2005-06-06 0001181431-05-033177 — 8.01
- 2005-04-26 0001181431-05-023450 — 1.01
- 2005-04-13 0001104659-05-016307 — 2.02, 9.01
- 2005-03-02 0001181431-05-013840 — 3.03, 5.03
- 2005-02-11 0001104659-05-005507 — 8.01
- 2005-01-12 0001104659-05-001183 — 2.02, 9.01
- 2005-01-11 0001104659-05-001049 — 2.02
- 2004-10-13 0001104659-04-030400 — 2.02, 9.01
- 2004-07-14 0001104659-04-019574 — 12, 7
- 2004-04-14 0001104659-04-010122 — 12, 7
- 2004-01-14 0001104659-04-000896 — 12, 7
- 2003-10-15 0001104659-03-022879 — 12, 7
- 2003-07-16 0001104659-03-014913 — 7, 9
- 2003-04-16 0001047469-03-013617 — 7, 9
- 2003-03-21 0001104659-03-004649 — 5, 7
- 2002-08-13 0000912057-02-031595 — 5, 7
- 2002-08-05 0000912057-02-029692 — 5, 7
- 2000-01-24 0000912057-00-002128 — 5, 7
- 1999-09-07 0000320193-99-000010 — 2
- 1999-07-16 0000320193-99-000007 — 2
- 1998-12-23 0000320193-98-000010 — 1
- 1998-01-08 0000320193-98-000001 — 2
- 1997-09-25 0000320193-97-000019 — 2
- 1997-09-25 0000320193-97-000018 — 2
- 1997-09-05 0000320193-97-000016 — 2
- 1997-07-28 0000320193-97-000012 — 4
- 1997-04-25 0000320193-97-000009 — 5
- 1997-04-10 0000320193-97-000007 — 7
- 1996-12-24 0000320193-96-000027 — 7
- 1996-12-23 0000320193-96-000025 — 4 — amendment of 0000320193-96-000021
- 1996-12-13 0000320193-96-000021 — 4
- 1996-10-28 0000912057-96-023874 — 5, 7
- 1996-06-17 0000320193-96-000014 — 1
- 1996-04-12 0000320193-96-000006 — 1

## late-filing notifications on or before 2019-05-01

- 2006-12-15 0001104659-06-081617 — NT 10-K, for the period ended 2006-09-30
- 2006-08-11 0001104659-06-053743 — NT 10-Q, for the period ended 2006-07-01

## item 2.02 — earnings release, exhibit 99.1

[0000320193-19-000063:8k_2_02:1]
EX-99.1
2
a8-kexhibit991q220193302019.htm
EXHIBIT 99.1

[0000320193-19-000063:8k_2_02:2]
Exhibit

[0000320193-19-000063:8k_2_02:3]
Exhibit 99.1

[0000320193-19-000063:8k_2_02:4]
Apple Reports Second Quarter Results

[0000320193-19-000063:8k_2_02:5]
Services Revenue Reaches New All-Time High of $11.5 Billion

[0000320193-19-000063:8k_2_02:6]
CUPERTINO, California — April 30, 2019 — Apple® today announced financial results for its fiscal 2019 second quarter ended March 30, 2019. The Company posted quarterly revenue of $58 billion, a decline of 5 percent from the year-ago quarter, and quarterly earnings per diluted share of $2.46, down 10 percent. International sales accounted for 61 percent of the quarter’s revenue.

[0000320193-19-000063:8k_2_02:7]
“Our March quarter results show the continued strength of our installed base of over 1.4 billion active devices, as we set an all-time record for Services, and the strong momentum of our Wearables, Home and Accessories category, which set a new March quarter record,” said Tim Cook, Apple’s CEO. “We delivered our strongest iPad growth in six years, and we are as excited as ever about our pipeline of innovative hardware, software and services. We’re looking forward to sharing more with developers and customers at Apple’s 30th annual Worldwide Developers Conference in June.”

[0000320193-19-000063:8k_2_02:8]
“We generated operating cash flow of $11.2 billion in the March quarter and continued to make significant investments in all areas of our business,” said Luca Maestri, Apple’s CFO. “We also returned over $27 billion to shareholders through share repurchases and dividends. Given our confidence in Apple’s future and the value we see in our stock, our Board has authorized an additional $75 billion for share repurchases. We are also raising our quarterly dividend for the seventh time in less than seven years.”

[0000320193-19-000063:8k_2_02:9]
Reflecting the approved increase, Apple’s board of directors has declared a cash dividend of $0.77 per share of the Company’s common stock, an increase of 5 percent. The dividend is payable on May 16, 2019 to shareholders of record as of the close of business on May 13, 2019.

[0000320193-19-000063:8k_2_02:10]
The management team and the Board will continue to review each element of the capital return program regularly and plan to provide an update on the program on an annual basis.

[0000320193-19-000063:8k_2_02:11]
Apple is providing the following guidance for its fiscal 2019 third quarter:

[0000320193-19-000063:8k_2_02:12]
| • | revenue between $52.5 billion and $54.5 billion |

[0000320193-19-000063:8k_2_02:13]
| • | gross margin between 37 percent and 38 percent |

[0000320193-19-000063:8k_2_02:14]
| • | operating expenses between $8.7 billion and $8.8 billion |

[0000320193-19-000063:8k_2_02:15]
| • | other income/(expense) of $250 million |

[0000320193-19-000063:8k_2_02:16]
| • | tax rate of approximately 16.5 percent |

[0000320193-19-000063:8k_2_02:17]
Apple will provide live streaming of its Q2 2019 financial results conference call beginning at 2:00 p.m. PDT on April 30, 2019 at www.apple.com/investor/earnings-call/. This webcast will also be available for replay for approximately two weeks thereafter.

[0000320193-19-000063:8k_2_02:18]
Apple periodically provides information for investors on its corporate website, apple.com, and its investors relations website, investor.apple.com. This includes press releases and other information about financial performance, reports filed or furnished with the SEC, information on corporate governance and details related to its annual meeting of shareholders.

[0000320193-19-000063:8k_2_02:19]
Apple revolutionized personal technology with the introduction of the Macintosh in 1984. Today, Apple leads the world in innovation with iPhone, iPad, Mac, Apple Watch and Apple TV. Apple’s four software platforms — iOS, macOS, watchOS and tvOS — provide seamless experiences across all Apple devices and empower people with breakthrough services including the App Store, Apple Music, Apple Pay and iCloud. Apple’s more than 100,000 employees are dedicated to making the best products on earth, and to leaving the world better than we found it.

[0000320193-19-000063:8k_2_02:20]
Press Contact:

[0000320193-19-000063:8k_2_02:21]
Kristin Huguet

[0000320193-19-000063:8k_2_02:22]
Apple

[0000320193-19-000063:8k_2_02:23]
khuguet@apple.com

[0000320193-19-000063:8k_2_02:24]
(408) 974-2414

[0000320193-19-000063:8k_2_02:25]
Investor Relations Contacts:

[0000320193-19-000063:8k_2_02:26]
Nancy Paxton

[0000320193-19-000063:8k_2_02:27]
Apple

[0000320193-19-000063:8k_2_02:28]
paxton1@apple.com

[0000320193-19-000063:8k_2_02:29]
(408) 974-5420

[0000320193-19-000063:8k_2_02:30]
Matt Blake

[0000320193-19-000063:8k_2_02:31]
Apple

[0000320193-19-000063:8k_2_02:32]
mattblake@apple.com

[0000320193-19-000063:8k_2_02:33]
(408) 974-7406

[0000320193-19-000063:8k_2_02:34]
NOTE TO EDITORS: For additional information visit Apple Newsroom (www.apple.com/newsroom), or call Apple’s Media Helpline at (408) 974-2042.

[0000320193-19-000063:8k_2_02:35]
© 2019 Apple Inc. All rights reserved. Apple and the Apple logo are trademarks of Apple Inc. Other company and product names may be trademarks of their respective owners.

[0000320193-19-000063:8k_2_02:36]
Apple Inc.

[0000320193-19-000063:8k_2_02:37]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS (Unaudited)

[0000320193-19-000063:8k_2_02:38]
(In millions, except number of shares which are reflected in thousands and per share amounts)

[0000320193-19-000063:8k_2_02:39]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Net sales: |  |  |  |  |  |  |  |
| Products | $ | 46,565 |  |  | $ | 51,287 |  |  | $ | 120,000 |  |  | $ | 130,451 |  |
| Services | 11,450 |  |  | 9,850 |  |  | 22,325 |  |  | 18,979 |  |
| Total net sales (1) | 58,015 |  |  | 61,137 |  |  | 142,325 |  |  | 149,430 |  |
| Cost of sales: |  |  |  |  |  |  |  |
| Products | 32,047 |  |  | 33,936 |  |  | 80,285 |  |  | 84,511 |  |
| Services | 4,147 |  |  | 3,779 |  |  | 8,188 |  |  | 7,585 |  |
| Total cost of sales | 36,194 |  |  | 37,715 |  |  | 88,473 |  |  | 92,096 |  |
| Gross margin | 21,821 |  |  | 23,422 |  |  | 53,852 |  |  | 57,334 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 3,948 |  |  | 3,378 |  |  | 7,850 |  |  | 6,785 |  |
| Selling, general and administrative | 4,458 |  |  | 4,150 |  |  | 9,241 |  |  | 8,381 |  |
| Total operating expenses | 8,406 |  |  | 7,528 |  |  | 17,091 |  |  | 15,166 |  |
| Operating income | 13,415 |  |  | 15,894 |  |  | 36,761 |  |  | 42,168 |  |
| Other income/(expense), net | 378 |  |  | 274 |  |  | 938 |  |  | 1,030 |  |
| Income before provision for income taxes | 13,793 |  |  | 16,168 |  |  | 37,699 |  |  | 43,198 |  |
| Provision for income taxes | 2,232 |  |  | 2,346 |  |  | 6,173 |  |  | 9,311 |  |
| Net income | $ | 11,561 |  |  | $ | 13,822 |  |  | $ | 31,526 |  |  | $ | 33,887 |  |
| Earnings per share: |  |  |  |  |  |  |  |
| Basic | $ | 2.47 |  |  | $ | 2.75 |  |  | $ | 6.70 |  |  | $ | 6.69 |  |
| Diluted | $ | 2.46 |  |  | $ | 2.73 |  |  | $ | 6.66 |  |  | $ | 6.63 |  |
| Shares used in computing earnings per share: |  |  |  |  |  |  |  |
| Basic | 4,674,071 |  |  | 5,024,877 |  |  | 4,704,945 |  |  | 5,068,877 |  |
| Diluted | 4,700,646 |  |  | 5,068,493 |  |  | 4,736,949 |  |  | 5,113,140 |  |
| (1) Net sales by reportable segment: |  |  |  |  |  |  |  |
| Americas | $ | 25,596 |  |  | $ | 24,841 |  |  | $ | 62,536 |  |  | $ | 60,034 |  |
| Europe | 13,054 |  |  | 13,846 |  |  | 33,417 |  |  | 34,900 |  |
| Greater China | 10,218 |  |  | 13,024 |  |  | 23,387 |  |  | 30,980 |  |
| Japan | 5,532 |  |  | 5,468 |  |  | 12,442 |  |  | 12,705 |  |
| Rest of Asia Pacific | 3,615 |  |  | 3,958 |  |  | 10,543 |  |  | 10,811 |  |
| Total net sales | $ | 58,015 |  |  | $ | 61,137 |  |  | $ | 142,325 |  |  | $ | 149,430 |  |
| (1) Net sales by category: |  |  |  |  |  |  |  |
| iPhone | $ | 31,051 |  |  | $ | 37,559 |  |  | $ | 83,033 |  |  | $ | 98,663 |  |
| Mac | 5,513 |  |  | 5,776 |  |  | 12,929 |  |  | 12,600 |  |
| iPad | 4,872 |  |  | 4,008 |  |  | 11,601 |  |  | 9,763 |  |
| Wearables, Home and Accessories | 5,129 |  |  | 3,944 |  |  | 12,437 |  |  | 9,425 |  |
| Services | 11,450 |  |  | 9,850 |  |  | 22,325 |  |  | 18,979 |  |
| Total net sales | $ | 58,015 |  |  | $ | 61,137 |  |  | $ | 142,325 |  |  | $ | 149,430 |  |

[0000320193-19-000063:8k_2_02:40]
Apple Inc.

[0000320193-19-000063:8k_2_02:41]
CONDENSED CONSOLIDATED BALANCE SHEETS (Unaudited)

[0000320193-19-000063:8k_2_02:42]
(In millions, except number of shares which are reflected in thousands and par value)

[0000320193-19-000063:8k_2_02:43]
|  | March 30, 2019 |  | September 29, 2018 |
| ASSETS: |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 37,988 |  |  | $ | 25,913 |  |
| Marketable securities | 42,104 |  |  | 40,388 |  |
| Accounts receivable, net | 15,085 |  |  | 23,186 |  |
| Inventories | 4,884 |  |  | 3,956 |  |
| Vendor non-trade receivables | 11,193 |  |  | 25,809 |  |
| Other current assets | 12,092 |  |  | 12,087 |  |
| Total current assets | 123,346 |  |  | 131,339 |  |
| Non-current assets: |  |  |  |
| Marketable securities | 145,319 |  |  | 170,799 |  |
| Property, plant and equipment, net | 38,746 |  |  | 41,304 |  |
| Other non-current assets | 34,587 |  |  | 22,283 |  |
| Total non-current assets | 218,652 |  |  | 234,386 |  |
| Total assets | $ | 341,998 |  |  | $ | 365,725 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY: |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 30,443 |  |  | $ | 55,888 |  |
| Other current liabilities | 35,368 |  |  | 33,327 |  |
| Deferred revenue | 5,532 |  |  | 5,966 |  |
| Commercial paper | 11,924 |  |  | 11,964 |  |
| Term debt | 10,505 |  |  | 8,784 |  |
| Total current liabilities | 93,772 |  |  | 115,929 |  |
| Non-current liabilities: |  |  |  |
| Term debt | 90,201 |  |  | 93,735 |  |
| Other non-current liabilities | 52,165 |  |  | 48,914 |  |
| Total non-current liabilities | 142,366 |  |  | 142,649 |  |
| Total liabilities | 236,138 |  |  | 258,578 |  |
| Commitments and contingencies |  |  |  |
| Shareholders’ equity: |  |  |  |
| Common stock and additional paid-in capital, $0.00001 par value: 12,600,000 shares authorized; 4,607,284 and 4,754,986 shares issued and outstanding, respectively | 42,801 |  |  | 40,201 |  |
| Retained earnings | 64,558 |  |  | 70,400 |  |
| Accumulated other comprehensive income/(loss) | (1,499 | ) |  | (3,454 | ) |
| Total shareholders’ equity | 105,860 |  |  | 107,147 |  |
| Total liabilities and shareholders’ equity | $ | 341,998 |  |  | $ | 365,725 |  |

[0000320193-19-000063:8k_2_02:44]
Apple Inc.

[0000320193-19-000063:8k_2_02:45]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (Unaudited)

[0000320193-19-000063:8k_2_02:46]
(In millions)

[0000320193-19-000063:8k_2_02:47]
|  | Six Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |
| Cash, cash equivalents and restricted cash, beginning balances | $ | 25,913 |  |  | $ | 20,289 |  |
| Operating activities: |  |  |  |
| Net income | 31,526 |  |  | 33,887 |  |
| Adjustments to reconcile net income to cash generated by operating activities: |  |  |  |
| Depreciation and amortization | 6,435 |  |  | 5,484 |  |
| Share-based compensation expense | 3,073 |  |  | 2,644 |  |
| Deferred income tax benefit | (124 | ) |  | (34,235 | ) |
| Other | (215 | ) |  | (151 | ) |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | 8,094 |  |  | 3,523 |  |
| Inventories | (1,006 | ) |  | (2,807 | ) |
| Vendor non-trade receivables | 14,616 |  |  | 9,715 |  |
| Other current and non-current assets | (717 | ) |  | (1,053 | ) |
| Accounts payable | (20,024 | ) |  | (12,004 | ) |
| Deferred revenue | (540 | ) |  | 394 |  |
| Other current and non-current liabilities | (3,273 | ) |  | 38,026 |  |
| Cash generated by operating activities | 37,845 |  |  | 43,423 |  |
| Investing activities: |  |  |  |
| Purchases of marketable securities | (13,854 | ) |  | (48,449 | ) |
| Proceeds from maturities of marketable securities | 16,880 |  |  | 31,884 |  |
| Proceeds from sales of marketable securities | 22,635 |  |  | 38,942 |  |
| Payments for acquisition of property, plant and equipment | (5,718 | ) |  | (7,005 | ) |
| Payments made in connection with business acquisitions, net | (291 | ) |  | (305 | ) |
| Purchases of non-marketable securities | (490 | ) |  | (163 | ) |
| Other | 30 |  |  | 216 |  |
| Cash generated by investing activities | 19,192 |  |  | 15,120 |  |
| Financing activities: |  |  |  |
| Proceeds from issuance of common stock | 390 |  |  | 327 |  |
| Payments for taxes related to net share settlement of equity awards | (1,427 | ) |  | (1,190 | ) |
| Payments for dividends and dividend equivalents | (7,011 | ) |  | (6,529 | ) |
| Repurchases of common stock | (32,498 | ) |  | (32,851 | ) |
| Proceeds from issuance of term debt, net | — |  |  | 6,969 |  |
| Repayments of term debt | (2,500 | ) |  | (500 | ) |
| Other | (87 | ) |  | 1 |  |
| Cash used in financing activities | (43,133 | ) |  | (33,773 | ) |
| Increase in cash, cash equivalents and restricted cash | 13,904 |  |  | 24,770 |  |
| Cash, cash equivalents and restricted cash, ending balances | $ | 39,817 |  |  | $ | 45,059 |  |
| Supplemental cash flow disclosure: |  |  |  |
| Cash paid for income taxes, net | $ | 9,497 |  |  | $ | 6,340 |  |
| Cash paid for interest | $ | 1,762 |  |  | $ | 1,356 |  |
