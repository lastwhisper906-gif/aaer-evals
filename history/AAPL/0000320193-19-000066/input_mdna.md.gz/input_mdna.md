# AAPL MD&A — 0000320193-19-000066


## mdna

[0000320193-19-000066:mdna:1]
[same as prior period, unchanged from 0000320193-19-000010:mdna:1]

[0000320193-19-000066:mdna:2]
[same as prior period, unchanged from 0000320193-19-000010:mdna:2]

[0000320193-19-000066:mdna:3]
[same as prior period, unchanged from 0000320193-19-000010:mdna:3]

[0000320193-19-000066:mdna:4]
Quarterly Highlights

[0000320193-19-000066:mdna:5]
[same as prior period, unchanged from 0000320193-19-000010:mdna:8]

[0000320193-19-000066:mdna:6]
The Company has historically experienced higher net sales in its first quarter compared to other quarters in its fiscal year due in part to seasonal holiday demand. Additionally, new product and service introductions can significantly impact net sales, cost of sales and operating expenses. The timing of product introductions can also impact the Company’s net sales to its indirect distribution channels as these channels are filled with new inventory following a product launch, and channel inventory of an older product often declines as the launch of a newer product approaches. Net sales can also be affected when consumers and distributors anticipate a product introduction. However, neither historical seasonal patterns nor historical patterns of product or service introductions should be considered reliable indicators of the Company’s future pattern of product or service introductions, future net sales or financial performance.

[0000320193-19-000066:mdna:7]
Second Quarter Fiscal 2019 Highlights

[0000320193-19-000066:mdna:8]
Total net sales decreased 5% or $3.1 billion during the second quarter of 2019 compared to the same quarter in 2018, driven by lower iPhone net sales, partially offset by higher Services and Wearables, Home and Accessories net sales. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on net sales during the second quarter of 2019.

[0000320193-19-000066:mdna:9]
During the second quarter of 2019, the Company released the following products:

[0000320193-19-000066:mdna:10]
| • | An iPad Air® and an updated iPad mini®, featuring Retina® displays and Apple Pencil® compatibility. |

[0000320193-19-000066:mdna:11]
| • | An updated iMac® with improved compute and graphics performance. |

[0000320193-19-000066:mdna:12]
| • | Updated AirPods with hands-free “Hey Siri” and the option of a wireless charging case. |

[0000320193-19-000066:mdna:13]
The Company also announced the following new services:

[0000320193-19-000066:mdna:14]
| • | Apple News+, a subscription news and magazine service, available initially in the U.S. and Canada. |

[0000320193-19-000066:mdna:15]
| • | Apple Card™, a new kind of credit card designed for the iPhone, expected to be available to qualified customers in the U.S. in summer 2019. |

[0000320193-19-000066:mdna:16]
| • | Apple Arcade™, a game subscription service, expected to launch in fall 2019. |

[0000320193-19-000066:mdna:17]
| • | New Apple TV app and Apple TV channels, bringing together different ways to access shows, movies, sports and news in one app across devices, and allowing users to subscribe to specific third-party video services, expected to be available starting in May 2019. |

[0000320193-19-000066:mdna:18]
| • | Apple TV+, a new subscription service for exclusive original shows, movies and documentaries, expected to be available in fall 2019. |

[0000320193-19-000066:mdna:19]
The Company repurchased $24.0 billion of its common stock and paid dividends and dividend equivalents of $3.4 billion during the second quarter of 2019.

[0000320193-19-000066:mdna:20]
[same as prior period, unchanged from 0000320193-19-000010:mdna:14]

[0000320193-19-000066:mdna:21]
Beginning in the first quarter of 2019, the Company classified the amortization of the deferred value of Maps, Siri and free iCloud services, which are bundled in the sales price of iPhone, Mac, iPad and certain other products, in services net sales. Historically, the Company classified the amortization of these amounts in products net sales consistent with its management reporting framework. As a result, products and services net sales information for the second quarter and first six months of 2018 was reclassified to conform to the 2019 presentation.

[0000320193-19-000066:mdna:22]
The following table shows net sales by category for the three- and six-month periods ended March 30, 2019 and March 31, 2018 (dollars in millions):

[0000320193-19-000066:mdna:23]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | Change |  | March 30, 2019 |  | March 31, 2018 |  | Change |
| Net sales by category: |  |  |  |  |  |  |  |  |  |  |  |
| iPhone (1) | $ | 31,051 |  |  | $ | 37,559 |  |  | (17 | )% |  | $ | 83,033 |  |  | $ | 98,663 |  |  | (16 | )% |
| Mac (1) | 5,513 |  |  | 5,776 |  |  | (5 | )% |  | 12,929 |  |  | 12,600 |  |  | 3 | % |
| iPad (1) | 4,872 |  |  | 4,008 |  |  | 22 | % |  | 11,601 |  |  | 9,763 |  |  | 19 | % |
| Wearables, Home and Accessories (1)(2) | 5,129 |  |  | 3,944 |  |  | 30 | % |  | 12,437 |  |  | 9,425 |  |  | 32 | % |
| Services (3) | 11,450 |  |  | 9,850 |  |  | 16 | % |  | 22,325 |  |  | 18,979 |  |  | 18 | % |
| Total net sales | $ | 58,015 |  |  | $ | 61,137 |  |  | (5 | )% |  | $ | 142,325 |  |  | $ | 149,430 |  |  | (5 | )% |

[0000320193-19-000066:mdna:24]
[same as prior period, unchanged from 0000320193-19-000010:mdna:18]

[0000320193-19-000066:mdna:25]
[same as prior period, unchanged from 0000320193-19-000010:mdna:19]

[0000320193-19-000066:mdna:26]
| (3) | Services net sales include sales from the Company’s digital content stores and streaming services, AppleCare, Apple Pay, licensing and other services. Services net sales also include amortization of the deferred value of Maps, Siri and free iCloud services, which are bundled in the sales price of certain products. |

[0000320193-19-000066:mdna:27]
[same as prior period, unchanged from 0000320193-19-000010:mdna:21]

[0000320193-19-000066:mdna:28]
iPhone net sales decreased during the second quarter and first six months of 2019 compared to the same periods in 2018 due primarily to lower iPhone unit sales in all the reportable geographic segments.

[0000320193-19-000066:mdna:29]
[same as prior period, unchanged from 0000320193-19-000010:mdna:23]

[0000320193-19-000066:mdna:30]
Mac net sales decreased during the second quarter of 2019 compared to the same quarter in 2018 due primarily to lower net sales of iMac. Year-over-year Mac net sales increased during the first six months of 2019 due primarily to higher net sales of MacBook Air, partially offset by lower net sales of iMac.

[0000320193-19-000066:mdna:31]
[same as prior period, unchanged from 0000320193-19-000010:mdna:25]

[0000320193-19-000066:mdna:32]
iPad net sales increased during the second quarter and first six months of 2019 compared to the same periods in 2018 due primarily to higher net sales of iPad Pro®.

[0000320193-19-000066:mdna:33]
[same as prior period, unchanged from 0000320193-19-000010:mdna:27]

[0000320193-19-000066:mdna:34]
Wearables, Home and Accessories net sales increased during the second quarter and first six months of 2019 compared to the same periods in 2018 due primarily to higher net sales of Apple Watch and AirPods.

[0000320193-19-000066:mdna:35]
[same as prior period, unchanged from 0000320193-19-000010:mdna:29]

[0000320193-19-000066:mdna:36]
Services net sales increased during the second quarter and first six months of 2019 compared to the same periods in 2018 due primarily to the App Store, licensing and AppleCare.

[0000320193-19-000066:mdna:37]
[same as prior period, unchanged from 0000320193-19-000010:mdna:31]

[0000320193-19-000066:mdna:38]
[same as prior period, unchanged from 0000320193-19-000010:mdna:32]

[0000320193-19-000066:mdna:39]
The following table shows net sales by reportable segment for the three- and six-month periods ended March 30, 2019 and March 31, 2018 (dollars in millions):

[0000320193-19-000066:mdna:40]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | Change |  | March 30, 2019 |  | March 31, 2018 |  | Change |
| Net sales by reportable segment: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 25,596 |  |  | $ | 24,841 |  |  | 3 | % |  | $ | 62,536 |  |  | $ | 60,034 |  |  | 4 | % |
| Europe | 13,054 |  |  | 13,846 |  |  | (6 | )% |  | 33,417 |  |  | 34,900 |  |  | (4 | )% |
| Greater China | 10,218 |  |  | 13,024 |  |  | (22 | )% |  | 23,387 |  |  | 30,980 |  |  | (25 | )% |
| Japan | 5,532 |  |  | 5,468 |  |  | 1 | % |  | 12,442 |  |  | 12,705 |  |  | (2 | )% |
| Rest of Asia Pacific | 3,615 |  |  | 3,958 |  |  | (9 | )% |  | 10,543 |  |  | 10,811 |  |  | (2 | )% |
| Total net sales | $ | 58,015 |  |  | $ | 61,137 |  |  | (5 | )% |  | $ | 142,325 |  |  | $ | 149,430 |  |  | (5 | )% |

[0000320193-19-000066:mdna:41]
[same as prior period, unchanged from 0000320193-19-000010:mdna:35]

[0000320193-19-000066:mdna:42]
Americas net sales increased during the second quarter and first six months of 2019 compared to the same periods in 2018 due primarily to higher Services and Wearables, Home and Accessories net sales, partially offset by lower iPhone net sales. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on Americas net sales during the second quarter and first six months of 2019.

[0000320193-19-000066:mdna:43]
[same as prior period, unchanged from 0000320193-19-000010:mdna:37]

[0000320193-19-000066:mdna:44]
Europe net sales decreased during the second quarter and first six months of 2019 compared to the same periods in 2018 due primarily to lower iPhone net sales, partially offset by higher Wearables, Home and Accessories and Services net sales. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on Europe net sales during the second quarter and first six months of 2019.

[0000320193-19-000066:mdna:45]
[same as prior period, unchanged from 0000320193-19-000010:mdna:39]

[0000320193-19-000066:mdna:46]
Greater China net sales decreased during the second quarter and first six months of 2019 compared to the same periods in 2018, driven by lower iPhone net sales. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on Greater China net sales during the second quarter and first six months of 2019.

[0000320193-19-000066:mdna:47]
[same as prior period, unchanged from 0000320193-19-000010:mdna:41]

[0000320193-19-000066:mdna:48]
Japan net sales during the second quarter of 2019 were relatively flat compared to the same quarter in 2018, as higher Services and iPad net sales were primarily offset by lower iPhone net sales. Year-over-year Japan net sales decreased during the first six months of 2019 due primarily to lower iPhone net sales, partially offset by higher Services and iPad net sales. The value of the Japanese Yen relative to the U.S. dollar had a favorable impact on Japan net sales during the second quarter of 2019.

[0000320193-19-000066:mdna:49]
[same as prior period, unchanged from 0000320193-19-000010:mdna:43]

[0000320193-19-000066:mdna:50]
Rest of Asia Pacific net sales decreased during the second quarter and first six months of 2019 compared to the same periods in 2018 due primarily to lower iPhone net sales, partially offset by higher Wearables, Home and Accessories and iPad net sales. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on Rest of Asia Pacific net sales during the second quarter and first six months of 2019.

[0000320193-19-000066:mdna:51]
[same as prior period, unchanged from 0000320193-19-000010:mdna:45]

[0000320193-19-000066:mdna:52]
Products and services gross margin and gross margin percentage for the three- and six-month periods ended March 30, 2019 and March 31, 2018 were as follows (dollars in millions):

[0000320193-19-000066:mdna:53]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Gross margin: |  |  |  |  |  |  |  |
| Products | $ | 14,518 |  |  | $ | 17,351 |  |  | $ | 39,715 |  |  | $ | 45,940 |  |
| Services | 7,303 |  |  | 6,071 |  |  | 14,137 |  |  | 11,394 |  |
| Total gross margin | $ | 21,821 |  |  | $ | 23,422 |  |  | $ | 53,852 |  |  | $ | 57,334 |  |
| Gross margin percentage: |  |  |  |  |  |  |  |
| Products | 31.2 | % |  | 33.8 | % |  | 33.1 | % |  | 35.2 | % |
| Services | 63.8 | % |  | 61.6 | % |  | 63.3 | % |  | 60.0 | % |
| Total gross margin percentage | 37.6 | % |  | 38.3 | % |  | 37.8 | % |  | 38.4 | % |

[0000320193-19-000066:mdna:54]
[same as prior period, unchanged from 0000320193-19-000010:mdna:48]

[0000320193-19-000066:mdna:55]
Products gross margin decreased during the second quarter and first six months of 2019 compared to the same periods in 2018 due primarily to lower iPhone unit sales and the weakness in foreign currencies relative to the U.S. dollar. Year-over-year products gross margin percentage decreased during the second quarter and first six months of 2019 due primarily to the impact of lower iPhone unit sales on the Company’s products fixed cost structure and the weakness in foreign currencies relative to the U.S. dollar.

[0000320193-19-000066:mdna:56]
[same as prior period, unchanged from 0000320193-19-000010:mdna:50]

[0000320193-19-000066:mdna:57]
Services gross margin increased during the second quarter and first six months of 2019 compared to the same periods in 2018 due primarily to a different services mix. Year-over-year services gross margin percentage increased during the second quarter and first six months of 2019 due primarily to a different services mix and leverage of the Company’s services fixed cost structure from higher services net sales, partially offset by the weakness in foreign currencies relative to the U.S. dollar.

[0000320193-19-000066:mdna:58]
The Company anticipates total gross margin percentage during the third quarter of 2019 to be between 37.0% and 38.0%. The foregoing statement regarding the Company’s expected total gross margin percentage in the third quarter of 2019 is forward-looking and could differ from actual results. The Company’s future gross margins can be impacted by multiple factors including, but not limited to, those set forth in Part II, Item 1A of this Form 10-Q under the heading “Risk Factors” and those described in this paragraph. In general, the Company believes gross margins will be subject to volatility and remain under downward pressure due to a variety of factors, including: continued industry-wide global product pricing pressures and product pricing actions that the Company may take in response to such pressures; increased competition; the Company’s ability to effectively stimulate demand for certain of its products and services; compressed product life cycles; potential increases in the cost of components, outside manufacturing services, and acquiring and delivering content for the Company’s services; the Company’s ability to manage product quality and warranty costs effectively; shifts in the mix of products and services, or in the geographic, currency or channel mix; fluctuations in exchange rates; and costs associated with the Company’s frequent introductions and transitions of products and services.

[0000320193-19-000066:mdna:59]
[same as prior period, unchanged from 0000320193-19-000010:mdna:53]

[0000320193-19-000066:mdna:60]
Operating expenses for the three- and six-month periods ended March 30, 2019 and March 31, 2018 were as follows (dollars in millions):

[0000320193-19-000066:mdna:61]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Research and development | $ | 3,948 |  |  | $ | 3,378 |  |  | $ | 7,850 |  |  | $ | 6,785 |  |
| Percentage of total net sales | 7 | % |  | 6 | % |  | 6 | % |  | 5 | % |
| Selling, general and administrative | $ | 4,458 |  |  | $ | 4,150 |  |  | $ | 9,241 |  |  | $ | 8,381 |  |
| Percentage of total net sales | 8 | % |  | 7 | % |  | 6 | % |  | 6 | % |
| Total operating expenses | $ | 8,406 |  |  | $ | 7,528 |  |  | $ | 17,091 |  |  | $ | 15,166 |  |
| Percentage of total net sales | 14 | % |  | 12 | % |  | 12 | % |  | 10 | % |

[0000320193-19-000066:mdna:62]
[same as prior period, unchanged from 0000320193-19-000010:mdna:56]

[0000320193-19-000066:mdna:63]
The growth in research and development (“R&D”) expense during the second quarter and first six months of 2019 compared to the same periods in 2018 was driven primarily by increases in headcount-related expenses and infrastructure-related costs. The Company continues to believe that focused investments in R&D are critical to its future growth and competitive position in the marketplace, and to the development of new and updated products and services that are central to the Company’s core business strategy.

[0000320193-19-000066:mdna:64]
[same as prior period, unchanged from 0000320193-19-000010:mdna:58]

[0000320193-19-000066:mdna:65]
The growth in selling, general and administrative expense during the second quarter of 2019 compared to the same quarter in 2018 was driven primarily by higher spending on marketing and advertising and increases in headcount-related expenses. The year-over-year growth in selling, general and administrative expense during the first six months of 2019 was driven primarily by increases in headcount-related expenses, marketing and advertising spending and infrastructure-related costs.

[0000320193-19-000066:mdna:66]
[same as prior period, unchanged from 0000320193-19-000010:mdna:60]

[0000320193-19-000066:mdna:67]
Other income/(expense), net for the three- and six-month periods ended March 30, 2019 and March 31, 2018 was as follows (dollars in millions):

[0000320193-19-000066:mdna:68]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | Change |  | March 30, 2019 |  | March 31, 2018 |  | Change |
| Interest and dividend income | $ | 1,358 |  |  | $ | 1,505 |  |  |  |  | $ | 2,665 |  |  | $ | 2,957 |  |  |  |
| Interest expense | (1,010 | ) |  | (792 | ) |  |  |  | (1,900 | ) |  | (1,526 | ) |  |  |
| Other income/(expense), net | 30 |  |  | (439 | ) |  |  |  | 173 |  |  | (401 | ) |  |  |
| Total other income/(expense), net | $ | 378 |  |  | $ | 274 |  |  | 38 | % |  | $ | 938 |  |  | $ | 1,030 |  |  | (9 | )% |

[0000320193-19-000066:mdna:69]
The increase in other income/(expense), net during the second quarter of 2019 compared to the same quarter in 2018 was due primarily to the impact of foreign exchange–related items, partially offset by higher interest expense and lower interest income. The year-over-year decrease in other income/(expense), net during the first six months of 2019 was due primarily to higher interest expense, lower interest income and lower investment-related gains, partially offset by the impact of foreign exchange–related items. The weighted-average interest rate earned by the Company on its cash, cash equivalents and marketable securities was 2.27% and 2.14% in the second quarter of 2019 and 2018, respectively, and 2.23% and 2.12% in the first six months of 2019 and 2018, respectively.

[0000320193-19-000066:mdna:70]
[same as prior period, unchanged from 0000320193-19-000010:mdna:64]

[0000320193-19-000066:mdna:71]
Provision for income taxes, effective tax rate and statutory federal income tax rate for the three- and six-month periods ended March 30, 2019 and March 31, 2018 were as follows (dollars in millions):

[0000320193-19-000066:mdna:72]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Provision for income taxes | $ | 2,232 |  |  | $ | 2,346 |  |  | $ | 6,173 |  |  | $ | 9,311 |  |
| Effective tax rate | 16.2 | % |  | 14.5 | % |  | 16.4 | % |  | 21.6 | % |
| Statutory federal income tax rate | 21 | % |  | 24.5 | % |  | 21 | % |  | 24.5 | % |

[0000320193-19-000066:mdna:73]
The Company’s effective tax rate for the second quarter of 2019 was lower than the statutory federal income tax rate due primarily to the lower tax rate on foreign earnings. The Company’s effective tax rate for the first six months of 2019 was lower than the statutory federal income tax rate due primarily to the lower tax rate on foreign earnings and tax benefits from share-based compensation.

[0000320193-19-000066:mdna:74]
The Company’s effective tax rate for the second quarter of 2019 was higher compared to the same quarter in 2018 due primarily to higher taxes on foreign earnings, partially offset by a lower statutory federal income tax rate in 2019. The Company’s effective tax rate for the first six months of 2019 was lower compared to the same period in 2018 due primarily to higher taxes in 2018 arising from the remeasurement of deferred tax assets and liabilities as a result of the Tax Cuts and Jobs Act (the “Act”) and a lower statutory federal income tax rate in 2019, partially offset by higher taxes on foreign earnings in 2019.

[0000320193-19-000066:mdna:75]
[same as prior period, unchanged from 0000320193-19-000010:mdna:69]

[0000320193-19-000066:mdna:76]
[same as prior period, unchanged from 0000320193-19-000010:mdna:70]

[0000320193-19-000066:mdna:77]
In August 2017, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) No. 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities (“ASU 2017-12”). ASU 2017-12 expands component and fair value hedging, specifies the presentation of the effects of hedging instruments, and eliminates the separate measurement and presentation of hedge ineffectiveness. The Company will adopt ASU 2017-12 in its first quarter of 2020 utilizing the modified retrospective transition method. Based on the Company’s derivative portfolio and hedging strategies, the adoption of ASU 2017-12 is not expected to have a material impact on its consolidated financial statements.

[0000320193-19-000066:mdna:78]
[same as prior period, unchanged from 0000320193-19-000010:mdna:72]

[0000320193-19-000066:mdna:79]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (“ASU 2016-13”), which modifies the measurement of expected credit losses on certain financial instruments. The Company will adopt ASU 2016-13 in its first quarter of 2021 utilizing the modified retrospective transition method. Based on the composition of the Company’s investment portfolio, current market conditions, and historical credit loss activity, the adoption of ASU 2016-13 is not expected to have a material impact on its consolidated financial statements.

[0000320193-19-000066:mdna:80]
[same as prior period, unchanged from 0000320193-19-000010:mdna:74]

[0000320193-19-000066:mdna:81]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842) (“ASU 2016-02”), which modifies lease accounting for lessees to increase transparency and comparability by recording lease assets and liabilities for operating leases and disclosing key information about leasing arrangements. The Company will adopt ASU 2016-02 utilizing the modified retrospective transition method through a cumulative-effect adjustment at the beginning of its first quarter of 2020. While the Company is currently evaluating the impact of adopting ASU 2016-02, based on the lease portfolio as of March 30, 2019, the Company anticipates recording lease assets and liabilities of approximately $9 billion on its Condensed Consolidated Balance Sheets, with no material impact to its Condensed Consolidated Statements of Operations. However, the ultimate impact of adopting ASU 2016-02 will depend on the Company’s lease portfolio as of the adoption date.

[0000320193-19-000066:mdna:82]
[same as prior period, unchanged from 0000320193-19-000010:mdna:76]

[0000320193-19-000066:mdna:83]
The following tables present selected financial information and statistics as of March 30, 2019 and September 29, 2018 and for the first six months of 2019 and 2018 (in millions):

[0000320193-19-000066:mdna:84]
|  | March 30, 2019 |  | September 29, 2018 |
| Cash, cash equivalents and marketable securities (1) | $ | 225,411 |  |  | $ | 237,100 |  |
| Property, plant and equipment, net | $ | 38,746 |  |  | $ | 41,304 |  |
| Commercial paper | $ | 11,924 |  |  | $ | 11,964 |  |
| Total term debt | $ | 100,706 |  |  | $ | 102,519 |  |
| Working capital | $ | 29,574 |  |  | $ | 15,410 |  |

[0000320193-19-000066:mdna:85]
|  | Six Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |
| Cash generated by operating activities | $ | 37,845 |  |  | $ | 43,423 |  |
| Cash generated by investing activities | $ | 19,192 |  |  | $ | 15,120 |  |
| Cash used in financing activities | $ | (43,133 | ) |  | $ | (33,773 | ) |

[0000320193-19-000066:mdna:86]
| (1) | As of March 30, 2019 and September 29, 2018, total cash, cash equivalents and marketable securities included $19.3 billion and $20.3 billion, respectively, that was restricted from general use, related to the State Aid Decision (refer to Note 5, “Income Taxes” in the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Form 10-Q) and other agreements. |

[0000320193-19-000066:mdna:87]
[same as prior period, unchanged from 0000320193-19-000010:mdna:81]

[0000320193-19-000066:mdna:88]
In connection with the State Aid Decision, as of March 30, 2019, the entire recovery amount of €13.1 billion plus interest of €1.2 billion was funded into escrow, where it will remain restricted from general use pending conclusion of all appeals.

[0000320193-19-000066:mdna:89]
[same as prior period, unchanged from 0000320193-19-000010:mdna:83]

[0000320193-19-000066:mdna:90]
During the six months ended March 30, 2019, cash generated by operating activities of $37.8 billion was a result of $31.5 billion of net income and non-cash adjustments to net income of $9.2 billion, partially offset by a decrease in the net change in operating assets and liabilities of $2.9 billion. Cash generated by investing activities of $19.2 billion during the six months ended March 30, 2019 consisted primarily of proceeds from sales and maturities of marketable securities, net of purchases, of $25.7 billion, partially offset by cash used to acquire property, plant and equipment of $5.7 billion. Cash used in financing activities of $43.1 billion during the six months ended March 30, 2019 consisted primarily of cash used to repurchase common stock of $32.5 billion, cash used to pay dividends and dividend equivalents of $7.0 billion and cash used to repay term debt of $2.5 billion.

[0000320193-19-000066:mdna:91]
During the six months ended March 31, 2018, cash generated by operating activities of $43.4 billion was a result of $33.9 billion of net income and an increase in the net change in operating assets and liabilities of $35.8 billion, partially offset by non-cash adjustments to net income of $26.3 billion. Cash generated by investing activities of $15.1 billion during the six months ended March 31, 2018 consisted primarily of proceeds from sales and maturities of marketable securities, net of purchases, of $22.4 billion, partially offset by cash used to acquire property, plant and equipment of $7.0 billion. Cash used in financing activities of $33.8 billion during the six months ended March 31, 2018 consisted primarily of cash used to repurchase common stock of $32.9 billion and cash used to pay dividends and dividend equivalents of $6.5 billion, partially offset by net proceeds from the issuance of term debt of $7.0 billion.

[0000320193-19-000066:mdna:92]
[same as prior period, unchanged from 0000320193-19-000010:mdna:86]

[0000320193-19-000066:mdna:93]
The Company’s capital expenditures were $3.3 billion during the first six months of 2019. The Company anticipates utilizing approximately $12.0 billion for capital expenditures during 2019, which includes product tooling and manufacturing process equipment; data centers; corporate facilities and infrastructure, including information systems hardware, software and enhancements; and retail store facilities.

[0000320193-19-000066:mdna:94]
[same as prior period, unchanged from 0000320193-19-000010:mdna:88]

[0000320193-19-000066:mdna:95]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses the net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of March 30, 2019, the Company had $11.9 billion of Commercial Paper outstanding, with a weighted-average interest rate of 2.56% and maturities generally less than nine months.

[0000320193-19-000066:mdna:96]
As of March 30, 2019, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $101.2 billion (collectively the “Notes”). During the first six months of 2019, the Company repaid $2.5 billion of its Notes upon maturity. The Company has entered, and in the future may enter, into interest rate swaps to manage interest rate risk on the Notes. In addition, the Company has entered, and in the future may enter, into foreign currency swaps to manage foreign currency risk on the Notes.

[0000320193-19-000066:mdna:97]
[same as prior period, unchanged from 0000320193-19-000010:mdna:91]

[0000320193-19-000066:mdna:98]
[same as prior period, unchanged from 0000320193-19-000010:mdna:92]

[0000320193-19-000066:mdna:99]
As of March 30, 2019, the Company had an authorized program to repurchase up to $100 billion of the Company’s common stock, of which $61.3 billion had been utilized. During the six months ended March 30, 2019, the Company repurchased 164.7 million shares of its common stock for $32.2 billion, including 55.1 million shares initially delivered under a $12.0 billion accelerated share repurchase arrangement (“ASR”) dated February 2019. On April 30, 2019, the Company announced the Board of Directors increased the share repurchase program authorization from $100 billion to $175 billion. The Company’s share repurchase program does not obligate it to acquire any specific number of shares. Under this program, shares may be repurchased in privately negotiated and/or open market transactions, including under plans complying with Rule 10b5-1 under the Exchange Act.

[0000320193-19-000066:mdna:100]
On April 30, 2019, the Company also announced the Board of Directors raised the Company’s quarterly cash dividend from $0.73 to $0.77 per share, beginning with the dividend to be paid during the third quarter of 2019. The Company intends to increase its dividend on an annual basis, subject to declaration by the Board of Directors.

[0000320193-19-000066:mdna:101]
[same as prior period, unchanged from 0000320193-19-000010:mdna:95]

[0000320193-19-000066:mdna:102]
[same as prior period, unchanged from 0000320193-19-000010:mdna:96]

[0000320193-19-000066:mdna:103]
As of March 30, 2019, the Company’s total future minimum lease payments under noncancelable operating leases were $10.4 billion. The Company’s retail store and other facility leases typically have original terms not exceeding 10 years and generally contain multi-year renewal options.

[0000320193-19-000066:mdna:104]
[same as prior period, unchanged from 0000320193-19-000010:mdna:98]

[0000320193-19-000066:mdna:105]
The Company utilizes several outsourcing partners to manufacture sub-assemblies for the Company’s products and to perform final assembly and testing of finished products. These outsourcing partners acquire components and build product based on demand information supplied by the Company, which typically covers periods up to 150 days. The Company also obtains individual components for its products from a wide variety of individual suppliers. As of March 30, 2019, the Company expects to pay $26.2 billion under manufacturing-related supplier arrangements, which are primarily noncancelable.

[0000320193-19-000066:mdna:106]
[same as prior period, unchanged from 0000320193-19-000010:mdna:100]

[0000320193-19-000066:mdna:107]
The Company’s other purchase obligations consist of noncancelable obligations to acquire capital assets, including product tooling and manufacturing process equipment, and noncancelable obligations related to advertising, licensing, R&D, internet and telecommunications services, content creation and other activities. As of March 30, 2019, the Company had other purchase obligations of $6.7 billion.

[0000320193-19-000066:mdna:108]
[same as prior period, unchanged from 0000320193-19-000010:mdna:102]

[0000320193-19-000066:mdna:109]
As of March 30, 2019, a significant portion of the other non-current liabilities in the Company’s Condensed Consolidated Balance Sheet consisted of the $30.9 billion deemed repatriation tax payable imposed by the Act. The Company plans to pay the deemed repatriation tax payable in installments in accordance with the Act. The Company’s remaining other non-current liabilities primarily consist of items for which the Company is unable to make a reasonably reliable estimate of the timing of payments.

[0000320193-19-000066:mdna:110]
[same as prior period, unchanged from 0000320193-19-000010:mdna:104]

[0000320193-19-000066:mdna:111]
Agreements entered into by the Company may include indemnification provisions, which may subject the Company to costs and damages in the event of a claim against an indemnified third party. Except as disclosed in Part I, Item 1 of this Form 10-Q in the Notes to Condensed Consolidated Financial Statements in Note 10, “Commitments and Contingencies” under the heading “Contingencies,” in the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to indemnification of third parties.

[0000320193-19-000066:mdna:112]
[same as prior period, unchanged from 0000320193-19-000010:mdna:106]

[0000320193-19-000066:mdna:113]
The Company has entered into indemnification agreements with its directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers of the Company, and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. While the Company maintains directors and officers liability insurance coverage, such insurance coverage may be insufficient to cover all losses or all types of claims that may arise.

[0000320193-19-000066:mdna:114]
[same as prior period, unchanged from 0000320193-19-000010:mdna:108]

[0000320193-19-000066:mdna:115]
[same as prior period, unchanged from 0000320193-19-000010:mdna:109]

[0000320193-19-000066:mdna:116]
[same as prior period, unchanged from 0000320193-19-000010:mdna:110]

[0000320193-19-000066:mdna:117]
[same as prior period, unchanged from 0000320193-19-000010:mdna:111]

[0000320193-19-000066:mdna:118]
[same as prior period, unchanged from 0000320193-19-000010:mdna:112]

[0000320193-19-000066:mdna:119]
[same as prior period, unchanged from 0000320193-19-000010:mdna:113]

[0000320193-19-000066:mdna:120]
[same as prior period, unchanged from 0000320193-19-000010:mdna:114]

[0000320193-19-000066:mdna:121]
[same as prior period, unchanged from 0000320193-19-000010:mdna:115]
