# AAPL notes — 0000320193-19-000066


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000320193-19-000066:notes:1]
Summary of Significant Accounting Policies
Basis of Presentation and Preparation

[0000320193-19-000066:notes:2]
The accompanying condensed consolidated financial statements include the accounts of Apple Inc. and its wholly owned subsidiaries (collectively “Apple” or the “Company”). Intercompany accounts and transactions have been eliminated. In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements and accompanying notes in conformity with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported. Actual results could differ materially from those estimates. Certain prior period amounts in the condensed consolidated financial statements and accompanying notes have been reclassified to conform to the current period’s presentation. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company’s annual consolidated financial statements and the notes thereto included in its Annual Report on Form 10-K for the fiscal year ended September 29, 2018 (the “2018 Form 10-K”).

[0000320193-19-000066:notes:3]
[same as prior period, unchanged from 0000320193-19-000010:notes:24]

[0000320193-19-000066:notes:4]
Recently Adopted Accounting Pronouncements

[0000320193-19-000066:notes:5]
[same as prior period, unchanged from 0000320193-19-000010:notes:26]

[0000320193-19-000066:notes:6]
In the first quarter of 2019, the Company adopted the Financial Accounting Standards Board’s (the “FASB”) Accounting Standards Update (“ASU”) No. 2014-09, Revenue from Contracts with Customers (Topic 606) (“ASU 2014-09”), and additional ASUs issued to clarify the guidance in ASU 2014-09 (collectively the “new revenue standard”), which amends the existing accounting standards for revenue recognition. The Company adopted the new revenue standard utilizing the full retrospective transition method. The Company did not restate total net sales in the prior periods presented, as adoption of the new revenue standard did not have a material impact on previously reported amounts.

[0000320193-19-000066:notes:7]
Additionally, beginning in the first quarter of 2019, the Company classified the amortization of the deferred value of Maps, Siri® and free iCloud® services, which are bundled in the sales price of iPhone®, Mac®, iPad® and certain other products, in services net sales. Historically, the Company classified the amortization of these amounts in products net sales consistent with its management reporting framework. As a result, products and services net sales information for the second quarter and first six months of 2018 was reclassified to conform to the 2019 presentation.

[0000320193-19-000066:notes:8]
[same as prior period, unchanged from 0000320193-19-000010:notes:29]

[0000320193-19-000066:notes:9]
In the first quarter of 2019, the Company adopted FASB ASU No. 2016-01, Financial Instruments – Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities (“ASU 2016-01”), which updates certain aspects of the recognition, measurement, presentation and disclosure of financial instruments. The adoption of ASU 2016-01 did not have a material impact on the Company’s condensed consolidated financial statements.

[0000320193-19-000066:notes:10]
[same as prior period, unchanged from 0000320193-19-000010:notes:31]

[0000320193-19-000066:notes:11]
In the first quarter of 2019, the Company adopted FASB ASU No. 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory (“ASU 2016-16”), which requires the recognition of the income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. The Company adopted ASU 2016-16 utilizing the modified retrospective transition method. Upon adoption, the Company recorded $2.7 billion of net deferred tax assets, reduced other non-current assets by $128 million, and increased retained earnings by $2.6 billion on its Condensed Consolidated Balance Sheet. The Company will recognize incremental deferred income tax expense as these net deferred tax assets are utilized.

[0000320193-19-000066:notes:12]
Restricted Cash

[0000320193-19-000066:notes:13]
In the first quarter of 2019, the Company adopted FASB ASU No. 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash (“ASU 2016-18”), which enhances and clarifies the guidance on the classification and presentation of restricted cash in the statement of cash flows and requires additional disclosures about restricted cash balances.

[0000320193-19-000066:notes:14]
[same as prior period, unchanged from 0000320193-19-000010:notes:33]

[0000320193-19-000066:notes:15]
The following table shows the computation of basic and diluted earnings per share for the three- and six-month periods ended March 30, 2019 and March 31, 2018 (net income in millions and shares in thousands):

[0000320193-19-000066:notes:16]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 11,561 |  |  | $ | 13,822 |  |  | $ | 31,526 |  |  | $ | 33,887 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 4,674,071 |  |  | 5,024,877 |  |  | 4,704,945 |  |  | 5,068,877 |  |
| Effect of dilutive securities | 26,575 |  |  | 43,616 |  |  | 32,004 |  |  | 44,263 |  |
| Weighted-average diluted shares | 4,700,646 |  |  | 5,068,493 |  |  | 4,736,949 |  |  | 5,113,140 |  |
| Basic earnings per share | $ | 2.47 |  |  | $ | 2.75 |  |  | $ | 6.70 |  |  | $ | 6.69 |  |
| Diluted earnings per share | $ | 2.46 |  |  | $ | 2.73 |  |  | $ | 6.66 |  |  | $ | 6.63 |  |

[0000320193-19-000066:notes:17]
Potentially dilutive securities representing 31.1 million and 30.0 million shares of common stock were excluded from the computation of diluted earnings per share for the three- and six-month periods ended March 30, 2019, respectively, because their effect would have been antidilutive.

[0000320193-19-000066:notes:18]
Restricted Cash and Restricted Marketable Securities
The Company considers cash and marketable securities to be restricted when withdrawal or general use is legally restricted. The Company records restricted cash as other assets in the Condensed Consolidated Balance Sheets, and determines current or non-current classification based on the expected duration of the restriction. The Company records restricted marketable securities as current or non-current marketable securities in the Condensed Consolidated Balance Sheets based on the classification of the underlying securities.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000320193-19-000066:notes:19]
Revenue Recognition
Net sales consist of revenue from the sale of iPhone, Mac, iPad, services and other products. The Company recognizes revenue at the amount to which it expects to be entitled when control of the products or services is transferred to its customers. Control is generally transferred when the Company has a present right to payment and title and the significant risks and rewards of ownership of products or services are transferred to its customers. For most of the Company’s products net sales, control transfers when products are shipped. For the Company’s services net sales, control transfers over time as services are delivered. Payment for products and services net sales is collected within a short period of time following transfer of control or commencement of delivery of services, as applicable.

[0000320193-19-000066:notes:20]
[same as prior period, unchanged from 0000320193-19-000010:notes:159]

[0000320193-19-000066:notes:21]
[same as prior period, unchanged from 0000320193-19-000010:notes:160]

[0000320193-19-000066:notes:22]
[same as prior period, unchanged from 0000320193-19-000010:notes:161]

[0000320193-19-000066:notes:23]
[same as prior period, unchanged from 0000320193-19-000010:notes:162]

[0000320193-19-000066:notes:24]
For the sale of third-party products where the Company obtains control of the product before transferring it to the customer, the Company recognizes revenue based on the gross amount billed to customers. The Company considers multiple factors when determining whether it obtains control of third-party products including, but not limited to, evaluating if it has the ability to establish the price of the product, retains inventory risk for tangible products or has the responsibility for ensuring acceptability of the product. For third-party applications sold through the App Store®, Mac App Store and TV App Store and certain digital content sold through the iTunes Store®, the Company does not obtain control of the product before transferring it to the customer. Therefore, the Company accounts for such sales on a net basis by recognizing in services net sales only the commission it retains.

[0000320193-19-000066:notes:25]
[same as prior period, unchanged from 0000320193-19-000010:notes:164]

[0000320193-19-000066:notes:26]
[same as prior period, unchanged from 0000320193-19-000010:notes:165]

[0000320193-19-000066:notes:27]
As of March 30, 2019 and September 29, 2018, the Company had total deferred revenue of $8.2 billion and $8.8 billion, respectively. As of March 30, 2019, the Company expects 67% of total deferred revenue to be realized in less than a year, 26% within one-to-two years, 6% within two-to-three years and 1% in greater than three years.

[0000320193-19-000066:notes:28]
[same as prior period, unchanged from 0000320193-19-000010:notes:167]

[0000320193-19-000066:notes:29]
Net sales disaggregated by significant products and services for the three- and six-month periods ended March 30, 2019 and March 31, 2018 were as follows (in millions):

[0000320193-19-000066:notes:30]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| iPhone (1) | $ | 31,051 |  |  | $ | 37,559 |  |  | $ | 83,033 |  |  | $ | 98,663 |  |
| Mac (1) | 5,513 |  |  | 5,776 |  |  | 12,929 |  |  | 12,600 |  |
| iPad (1) | 4,872 |  |  | 4,008 |  |  | 11,601 |  |  | 9,763 |  |
| Wearables, Home and Accessories (1)(2) | 5,129 |  |  | 3,944 |  |  | 12,437 |  |  | 9,425 |  |
| Services (3) | 11,450 |  |  | 9,850 |  |  | 22,325 |  |  | 18,979 |  |
| Total net sales (4) | $ | 58,015 |  |  | $ | 61,137 |  |  | $ | 142,325 |  |  | $ | 149,430 |  |

[0000320193-19-000066:notes:31]
| (1) | Products net sales include amortization of the deferred value of unspecified software upgrade rights, which are bundled in the sales price of the respective product. |

[0000320193-19-000066:notes:32]
| (2) | Wearables, Home and Accessories net sales include sales of AirPods®, Apple TV®, Apple Watch®, Beats® products, HomePod™, iPod touch® and Apple-branded and third-party accessories. |

[0000320193-19-000066:notes:33]
| (3) | Services net sales include sales from the Company’s digital content stores and streaming services, AppleCare®, Apple Pay®, licensing and other services. Services net sales also include amortization of the deferred value of Maps, Siri and free iCloud services, which are bundled in the sales price of certain products. |

[0000320193-19-000066:notes:34]
| (4) | Includes $1.9 billion and $2.2 billion of revenue recognized in the three months ended March 30, 2019 and March 31, 2018, respectively, and $3.8 billion and $3.5 billion of revenue recognized in the six months ended March 30, 2019 and March 31, 2018, respectively, that was included in deferred revenue at the beginning of each respective period. |

[0000320193-19-000066:notes:35]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 11, “Segment Information and Geographic Data” for the three- and six-month periods ended March 30, 2019 and March 31, 2018.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000320193-19-000066:notes:36]
Financial Instruments
Cash, Cash Equivalents and Marketable Securities

[0000320193-19-000066:notes:37]
[same as prior period, unchanged from 0000320193-19-000010:notes:122]

[0000320193-19-000066:notes:38]
The Company’s investments in marketable equity securities are classified based on the nature of the securities and their availability for use in current operations. The Company’s marketable equity securities are measured at fair value with gains and losses recognized in other income/(expense), net.

[0000320193-19-000066:notes:39]
The following tables show the Company’s cash and marketable securities by significant investment category as of March 30, 2019 and September 29, 2018 (in millions):

[0000320193-19-000066:notes:40]
|  | March 30, 2019 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | Short-TermMarketableSecurities |  | Long-TermMarketableSecurities |
| Cash | $ | 11,751 |  |  | $ | — |  |  | $ | — |  |  | $ | 11,751 |  |  | $ | 11,751 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 8,719 |  |  | — |  |  | — |  |  | 8,719 |  |  | 8,719 |  |  | — |  |  | — |  |
| Subtotal | 8,719 |  |  | — |  |  | — |  |  | 8,719 |  |  | 8,719 |  |  | — |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 48,215 |  |  | 6 |  |  | (401 | ) |  | 47,820 |  |  | 8,815 |  |  | 6,957 |  |  | 32,048 |  |
| U.S. agency securities | 6,458 |  |  | — |  |  | (19 | ) |  | 6,439 |  |  | 4,354 |  |  | 526 |  |  | 1,559 |  |
| Non-U.S. government securities | 21,572 |  |  | 132 |  |  | (108 | ) |  | 21,596 |  |  | 243 |  |  | 3,992 |  |  | 17,361 |  |
| Certificates of deposit and time deposits | 3,472 |  |  | — |  |  | — |  |  | 3,472 |  |  | 1,980 |  |  | 1,372 |  |  | 120 |  |
| Commercial paper | 2,150 |  |  | — |  |  | — |  |  | 2,150 |  |  | 2,122 |  |  | 28 |  |  | — |  |
| Corporate debt securities | 106,837 |  |  | 228 |  |  | (730 | ) |  | 106,335 |  |  | 4 |  |  | 28,164 |  |  | 78,167 |  |
| Municipal securities | 946 |  |  | 4 |  |  | (2 | ) |  | 948 |  |  | — |  |  | 75 |  |  | 873 |  |
| Mortgage- and asset-backed securities | 16,438 |  |  | 15 |  |  | (272 | ) |  | 16,181 |  |  | — |  |  | 990 |  |  | 15,191 |  |
| Subtotal | 206,088 |  |  | 385 |  |  | (1,532 | ) |  | 204,941 |  |  | 17,518 |  |  | 42,104 |  |  | 145,319 |  |
| Total (3) | $ | 226,558 |  |  | $ | 385 |  |  | $ | (1,532 | ) |  | $ | 225,411 |  |  | $ | 37,988 |  |  | $ | 42,104 |  |  | $ | 145,319 |  |

[0000320193-19-000066:notes:41]
|  | September 29, 2018 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | Short-TermMarketableSecurities |  | Long-TermMarketableSecurities |
| Cash | $ | 11,575 |  |  | $ | — |  |  | $ | — |  |  | $ | 11,575 |  |  | $ | 11,575 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 8,083 |  |  | — |  |  | — |  |  | 8,083 |  |  | 8,083 |  |  | — |  |  | — |  |
| Mutual funds | 799 |  |  | — |  |  | (116 | ) |  | 683 |  |  | — |  |  | 683 |  |  | — |  |
| Subtotal | 8,882 |  |  | — |  |  | (116 | ) |  | 8,766 |  |  | 8,083 |  |  | 683 |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 47,296 |  |  | — |  |  | (1,202 | ) |  | 46,094 |  |  | 1,613 |  |  | 7,606 |  |  | 36,875 |  |
| U.S. agency securities | 4,127 |  |  | — |  |  | (48 | ) |  | 4,079 |  |  | 1,732 |  |  | 360 |  |  | 1,987 |  |
| Non-U.S. government securities | 21,601 |  |  | 49 |  |  | (250 | ) |  | 21,400 |  |  | — |  |  | 3,355 |  |  | 18,045 |  |
| Certificates of deposit and time deposits | 3,074 |  |  | — |  |  | — |  |  | 3,074 |  |  | 1,247 |  |  | 1,330 |  |  | 497 |  |
| Commercial paper | 2,573 |  |  | — |  |  | — |  |  | 2,573 |  |  | 1,663 |  |  | 910 |  |  | — |  |
| Corporate debt securities | 123,001 |  |  | 152 |  |  | (2,038 | ) |  | 121,115 |  |  | — |  |  | 25,162 |  |  | 95,953 |  |
| Municipal securities | 946 |  |  | — |  |  | (12 | ) |  | 934 |  |  | — |  |  | 178 |  |  | 756 |  |
| Mortgage- and asset-backed securities | 18,105 |  |  | 8 |  |  | (623 | ) |  | 17,490 |  |  | — |  |  | 804 |  |  | 16,686 |  |
| Subtotal | 220,723 |  |  | 209 |  |  | (4,173 | ) |  | 216,759 |  |  | 6,255 |  |  | 39,705 |  |  | 170,799 |  |
| Total (3) | $ | 241,180 |  |  | $ | 209 |  |  | $ | (4,289 | ) |  | $ | 237,100 |  |  | $ | 25,913 |  |  | $ | 40,388 |  |  | $ | 170,799 |  |

[0000320193-19-000066:notes:42]
| (1) | Level 1 fair value estimates are based on quoted prices in active markets for identical assets or liabilities. |

[0000320193-19-000066:notes:43]
| (2) | Level 2 fair value estimates are based on observable inputs other than quoted prices in active markets for identical assets and liabilities, quoted prices for identical or similar assets or liabilities in inactive markets, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities. |

[0000320193-19-000066:notes:44]
| (3) | As of March 30, 2019 and September 29, 2018, total cash, cash equivalents and marketable securities included $19.3 billion and $20.3 billion, respectively, that was restricted from general use, related to the State Aid Decision (refer to Note 5, “Income Taxes”) and other agreements. |

[0000320193-19-000066:notes:45]
[same as prior period, unchanged from 0000320193-19-000010:notes:124]

[0000320193-19-000066:notes:46]
The following tables show information about the Company’s marketable securities that had been in a continuous unrealized loss position for less than 12 months and for 12 months or greater as of March 30, 2019 and September 29, 2018 (in millions):

[0000320193-19-000066:notes:47]
|  | March 30, 2019 |
|  | Continuous Unrealized Losses |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
| Fair value of marketable debt securities | $ | 18,814 |  |  | $ | 131,393 |  |  | $ | 150,207 |  |
| Unrealized losses | $ | (87 | ) |  | $ | (1,445 | ) |  | $ | (1,532 | ) |

[0000320193-19-000066:notes:48]
[same as prior period, unchanged from 0000320193-19-000010:notes:127]

[0000320193-19-000066:notes:49]
The Company typically invests in highly rated securities, with the primary objective of minimizing the potential risk of principal loss. The Company’s investment policy generally requires securities to be investment grade and limits the amount of credit exposure to any one issuer. Fair values were determined for each individual security in the investment portfolio. When evaluating a marketable debt security for other-than-temporary impairment, the Company reviews factors such as the length of time and extent to which fair value has been below its cost basis, the financial condition of the issuer and any changes thereto, changes in market interest rates and the Company’s intent to sell, or whether it is more likely than not it will be required to sell the security before recovery of the security’s cost basis. As of March 30, 2019, the Company does not consider any of its marketable debt securities to be other-than-temporarily impaired.

[0000320193-19-000066:notes:50]
[same as prior period, unchanged from 0000320193-19-000010:notes:129]

[0000320193-19-000066:notes:51]
The Company holds non-marketable equity securities of certain privately held companies without readily determinable fair values, and has elected to apply the measurement alternative. As such, the Company’s non-marketable equity securities are measured at cost, less any impairment, and are adjusted for changes in fair value resulting from observable transactions for identical or similar investments of the same issuer. Gains and losses on non-marketable equity securities are recognized in other income/(expense), net. As of March 30, 2019, the Company’s non-marketable equity securities had a carrying value of $2.3 billion.

[0000320193-19-000066:notes:52]
The Company holds a non-marketable debt security that is classified and accounted for as held-to-maturity. As of March 30, 2019, the Company’s non-marketable debt security had an amortized cost basis and carrying value of $1.5 billion.

[0000320193-19-000066:notes:53]
A reconciliation of the Company’s cash and cash equivalents in the Condensed Consolidated Balance Sheet to cash, cash equivalents and restricted cash in the Condensed Consolidated Statement of Cash Flows as of March 30, 2019 is as follows (in millions):

[0000320193-19-000066:notes:54]
|  | March 30, 2019 |
| Cash and cash equivalents | $ | 37,988 |  |
| Restricted cash included in other current assets | 341 |  |
| Restricted cash included in other non-current assets | 1,488 |  |
| Cash, cash equivalents and restricted cash | $ | 39,817 |  |

[0000320193-19-000066:notes:55]
The Company’s restricted cash primarily consisted of cash required to be on deposit under a contractual agreement with a bank to support the Company’s iPhone Upgrade Program.

[0000320193-19-000066:notes:56]
Derivative Financial Instruments

[0000320193-19-000066:notes:57]
The Company may use derivatives to partially offset its business exposure to foreign currency and interest rate risk on expected future cash flows, net investments in certain foreign subsidiaries, and certain existing assets and liabilities. However, the Company may choose not to hedge certain exposures for a variety of reasons including, but not limited to, accounting considerations or the prohibitive economic cost of hedging particular exposures. There can be no assurance the hedges will offset more than a portion of the financial impact resulting from movements in foreign currency exchange or interest rates.

[0000320193-19-000066:notes:58]
To protect gross margins from fluctuations in foreign currency exchange rates, certain of the Company’s subsidiaries whose functional currency is the U.S. dollar may hedge a portion of forecasted foreign currency revenue, and subsidiaries whose functional currency is not the U.S. dollar may hedge a portion of forecasted inventory purchases not denominated in the subsidiaries’ functional currencies. The Company may enter into forward contracts, option contracts or other instruments to manage this risk and may designate these instruments as cash flow hedges. The Company generally hedges portions of its forecasted foreign currency exposure associated with revenue and inventory purchases, typically for up to 12 months.

[0000320193-19-000066:notes:59]
To protect the net investment in a foreign operation from fluctuations in foreign currency exchange rates, the Company may enter into foreign currency forward and option contracts to offset a portion of the changes in the carrying amounts of these investments due to fluctuations in foreign currency exchange rates. In addition, the Company may use non-derivative financial instruments, such as its foreign currency–denominated debt, as hedges of its net investments in certain foreign subsidiaries. In both of these cases, the Company designates these instruments as net investment hedges.

[0000320193-19-000066:notes:60]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in foreign currency exchange rates, the Company may enter into forward contracts, cross-currency swaps or other instruments. These instruments may offset a portion of the foreign currency remeasurement gains or losses, or changes in fair value. The Company may designate these instruments as either cash flow or fair value hedges. As of March 30, 2019, the Company’s hedged term debt– and marketable securities–related foreign currency transactions are expected to be recognized within 23 years.

[0000320193-19-000066:notes:61]
The Company may also enter into non-designated foreign currency contracts to offset a portion of the foreign currency exchange gains and losses generated by the remeasurement of certain assets and liabilities denominated in non-functional currencies.

[0000320193-19-000066:notes:62]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in interest rates, the Company may enter into interest rate swaps, options or other instruments. These instruments may offset a portion of the changes in interest income or expense, or changes in fair value. The Company designates these instruments as either cash flow or fair value hedges. As of March 30, 2019, the Company’s hedged interest rate transactions are expected to be recognized within 9 years.

[0000320193-19-000066:notes:63]
Cash Flow Hedges

[0000320193-19-000066:notes:64]
The effective portions of cash flow hedges are recorded in accumulated other comprehensive income/(loss) (“AOCI”) until the hedged item is recognized in earnings. Deferred gains and losses associated with cash flow hedges of foreign currency revenue are recognized as a component of net sales in the same period as the related revenue is recognized, and deferred gains and losses related to cash flow hedges of inventory purchases are recognized as a component of cost of sales in the same period as the related costs are recognized. Deferred gains and losses associated with cash flow hedges of interest income or expense are recognized in other income/(expense), net in the same period as the related income or expense is recognized. For options designated as cash flow hedges, changes in the time value are excluded from the assessment of hedge effectiveness. The ineffective portions and amounts excluded from the effectiveness testing of cash flow hedges are recognized in other income/(expense), net.

[0000320193-19-000066:notes:65]
Derivative instruments designated as cash flow hedges must be de-designated as hedges when it is probable the forecasted hedged transaction will not occur in the initially identified time period or within a subsequent two-month time period. Deferred gains and losses in AOCI associated with such derivative instruments are reclassified into other income/(expense), net in the period of de-designation. Any subsequent changes in fair value of such derivative instruments are reflected in other income/(expense), net unless they are re-designated as hedges of other transactions.

[0000320193-19-000066:notes:66]
Net Investment Hedges

[0000320193-19-000066:notes:67]
The effective portions of net investment hedges are recorded in OCI as a part of the cumulative translation adjustment. The ineffective portions and amounts excluded from the effectiveness testing of net investment hedges are recognized in other income/(expense), net. For foreign exchange forward contracts designated as net investment hedges, the Company excludes changes in fair value relating to changes in the forward carry component from its assessment of hedge effectiveness. Accordingly, any gains or losses related to this forward carry component are recognized in earnings in the current period.

[0000320193-19-000066:notes:68]
Fair Value Hedges

[0000320193-19-000066:notes:69]
Gains and losses related to changes in fair value hedges are recognized in earnings along with a corresponding loss or gain related to the change in value of the underlying hedged item in the same line in the Condensed Consolidated Statements of Operations. For foreign exchange forward contracts designated as fair value hedges, the Company excludes changes in fair value relating to changes in the forward carry component from its assessment of hedge effectiveness. Amounts excluded from the effectiveness testing of fair value hedges were gains of $206 million and $474 million for the three- and six-month periods ended March 30, 2019, respectively, and were recognized in other income/(expense), net.

[0000320193-19-000066:notes:70]
Non-Designated Derivatives

[0000320193-19-000066:notes:71]
Derivatives that are not designated as hedging instruments are adjusted to fair value through earnings in the financial statement line item to which the derivative relates. As a result, during the three- and six-month periods ended March 30, 2019, respectively, the Company recognized a loss of $30 million and a gain of $225 million in net sales, a loss of $107 million and a gain of $68 million in cost of sales and losses of $77 million and $24 million in other income/(expense), net. During the three- and six-month periods ended March 31, 2018, respectively, the Company recognized losses of $203 million and $142 million in net sales, losses of $247 million and $212 million in cost of sales and losses of $331 million and $373 million in other income/(expense), net.

[0000320193-19-000066:notes:72]
The Company records all derivatives in the Condensed Consolidated Balance Sheets at fair value. The Company’s accounting treatment for these derivative instruments is based on its hedge designation. The following tables show the Company’s derivative instruments at gross fair value as of March 30, 2019 and September 29, 2018 (in millions):

[0000320193-19-000066:notes:73]
|  | March 30, 2019 |
|  | Fair Value ofDerivatives Designatedas Hedge Instruments |  | Fair Value ofDerivatives Not Designatedas Hedge Instruments |  | TotalFair Value |
| Derivative assets (1): |  |  |  |  |  |
| Foreign exchange contracts | $ | 1,364 |  |  | $ | 216 |  |  | $ | 1,580 |  |
| Interest rate contracts | $ | 68 |  |  | $ | — |  |  | $ | 68 |  |
| Derivative liabilities (2): |  |  |  |  |  |
| Foreign exchange contracts | $ | 649 |  |  | $ | 273 |  |  | $ | 922 |  |
| Interest rate contracts | $ | 402 |  |  | $ | — |  |  | $ | 402 |  |

[0000320193-19-000066:notes:74]
[same as prior period, unchanged from 0000320193-19-000010:notes:135]

[0000320193-19-000066:notes:75]
[same as prior period, unchanged from 0000320193-19-000010:notes:136]

[0000320193-19-000066:notes:76]
[same as prior period, unchanged from 0000320193-19-000010:notes:137]

[0000320193-19-000066:notes:77]
The Company classifies cash flows related to derivative financial instruments as operating activities in its Condensed Consolidated Statements of Cash Flows.

[0000320193-19-000066:notes:78]
The following table shows the pre-tax gains and losses of the Company’s derivative and non-derivative instruments designated as cash flow, net investment and fair value hedges in OCI and the Condensed Consolidated Statements of Operations for the three- and six-month periods ended March 30, 2019 and March 31, 2018 (in millions):

[0000320193-19-000066:notes:79]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Gains/(Losses) recognized in OCI – effective portion: |  |  |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | (64 | ) |  | $ | 37 |  |  | $ | (542 | ) |  | $ | 190 |  |
| Interest rate contracts | — |  |  | — |  |  | — |  |  | 1 |  |
| Total | $ | (64 | ) |  | $ | 37 |  |  | $ | (542 | ) |  | $ | 191 |  |
| Net investment hedges: |  |  |  |  |  |  |  |
| Foreign currency debt | $ | (7 | ) |  | $ | (33 | ) |  | $ | (23 | ) |  | $ | (31 | ) |
| Gains/(Losses) reclassified from AOCI into net income – effective portion: |  |  |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 134 |  |  | $ | 287 |  |  | $ | 16 |  |  | $ | 163 |  |
| Interest rate contracts | (2 | ) |  | 2 |  |  | (3 | ) |  | 3 |  |
| Total | $ | 132 |  |  | $ | 289 |  |  | $ | 13 |  |  | $ | 166 |  |
| Gains/(Losses) on derivative instruments: |  |  |  |  |  |  |  |
| Fair value hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 243 |  |  | $ | — |  |  | $ | 645 |  |  | $ | — |  |
| Interest rate contracts | 465 |  |  | (674 | ) |  | 1,122 |  |  | (948 | ) |
| Total | $ | 708 |  |  | $ | (674 | ) |  | $ | 1,767 |  |  | $ | (948 | ) |
| Gains/(Losses) related to hedged items: |  |  |  |  |  |  |  |
| Fair value hedges: |  |  |  |  |  |  |  |
| Marketable securities | $ | (242 | ) |  | $ | — |  |  | $ | (644 | ) |  | $ | — |  |
| Fixed-rate debt | (465 | ) |  | 674 |  |  | (1,122 | ) |  | 948 |  |
| Total | $ | (707 | ) |  | $ | 674 |  |  | $ | (1,766 | ) |  | $ | 948 |  |

[0000320193-19-000066:notes:80]
The following table shows the notional amounts of the Company’s outstanding derivative instruments and credit risk amounts associated with outstanding or unsettled derivative instruments as of March 30, 2019 and September 29, 2018 (in millions):

[0000320193-19-000066:notes:81]
|  | March 30, 2019 |  | September 29, 2018 |
|  | NotionalAmount |  | Credit RiskAmount |  | NotionalAmount |  | Credit RiskAmount |
| Instruments designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 52,660 |  |  | $ | 1,364 |  |  | $ | 65,368 |  |  | $ | 1,015 |  |
| Interest rate contracts | $ | 33,250 |  |  | $ | 68 |  |  | $ | 33,250 |  |  | $ | — |  |
| Instruments not designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 63,477 |  |  | $ | 216 |  |  | $ | 63,062 |  |  | $ | 259 |  |

[0000320193-19-000066:notes:82]
[same as prior period, unchanged from 0000320193-19-000010:notes:140]

[0000320193-19-000066:notes:83]
The Company generally enters into master netting arrangements, which are designed to reduce credit risk by permitting net settlement of transactions with the same counterparty. To further limit credit risk, the Company generally enters into collateral security arrangements that provide for collateral to be received or posted when the net fair value of certain financial instruments fluctuates from contractually established thresholds. The Company presents its derivative assets and derivative liabilities at their gross fair values in its Condensed Consolidated Balance Sheets. As of March 30, 2019, the net cash collateral received by the Company related to derivative instruments under its collateral security arrangements was $505 million, which was recorded as other current liabilities in the Condensed Consolidated Balance Sheet. As of September 29, 2018, the net cash collateral posted by the Company related to derivative instruments under its collateral security arrangements was $1.0 billion, which was recorded as other current assets in the Condensed Consolidated Balance Sheet.

[0000320193-19-000066:notes:84]
Under master netting arrangements with the respective counterparties to the Company’s derivative contracts, the Company is allowed to net settle transactions with a single net amount payable by one party to the other. As of March 30, 2019 and September 29, 2018, the potential effects of these rights of set-off associated with the Company’s derivative contracts, including the effects of collateral, would be a reduction to both derivative assets and derivative liabilities of $1.7 billion and $2.1 billion, respectively, resulting in a net derivative liability of $181 million and a net derivative asset of $138 million, respectively.

[0000320193-19-000066:notes:85]
[same as prior period, unchanged from 0000320193-19-000010:notes:143]

[0000320193-19-000066:notes:86]
[same as prior period, unchanged from 0000320193-19-000010:notes:144]

[0000320193-19-000066:notes:87]
[same as prior period, unchanged from 0000320193-19-000010:notes:145]

[0000320193-19-000066:notes:88]
As of March 30, 2019, the Company had no customers that individually represented 10% or more of total trade receivables. As of September 29, 2018, the Company had one customer that represented 10% or more of total trade receivables, which accounted for 10%. The Company’s cellular network carriers accounted for 45% and 59% of total trade receivables as of March 30, 2019 and September 29, 2018, respectively.

[0000320193-19-000066:notes:89]
Vendor Non-Trade Receivables
The Company has non-trade receivables from certain of its manufacturing vendors resulting from the sale of components to these vendors who manufacture sub-assemblies or assemble final products for the Company. The Company purchases these components directly from suppliers. As of March 30, 2019, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 56% and 16%. As of September 29, 2018, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 62% and 12%.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000320193-19-000066:notes:90]
Level 2 fair value estimates are based on observable inputs other than quoted prices in active markets for identical assets and liabilities, quoted prices for identical or similar assets or liabilities in inactive markets, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities.Level 1 fair value estimates are based on quoted prices in active markets for identical assets or liabilities.


## us-gaap:DerivativesPolicyTextBlock

[0000320193-19-000066:notes:91]
The Company classifies cash flows related to derivative financial instruments as operating activities in its Condensed Consolidated Statements of Cash Flows.Derivative Financial Instruments
The Company may use derivatives to partially offset its business exposure to foreign currency and interest rate risk on expected future cash flows, net investments in certain foreign subsidiaries, and certain existing assets and liabilities. However, the Company may choose not to hedge certain exposures for a variety of reasons including, but not limited to, accounting considerations or the prohibitive economic cost of hedging particular exposures. There can be no assurance the hedges will offset more than a portion of the financial impact resulting from movements in foreign currency exchange or interest rates.

[0000320193-19-000066:notes:92]
Non-Designated Derivatives
Derivatives that are not designated as hedging instruments are adjusted to fair value through earnings in the financial statement line item to which the derivative relates.The Company records all derivatives in the Condensed Consolidated Balance Sheets at fair value. The Company’s accounting treatment for these derivative instruments is based on its hedge designation.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000320193-19-000066:notes:93]
Condensed Consolidated Financial Statement Details
The following tables show the Company’s condensed consolidated financial statement details as of March 30, 2019 and September 29, 2018 (in millions):

[0000320193-19-000066:notes:94]
[same as prior period, unchanged from 0000320193-19-000010:notes:13]

[0000320193-19-000066:notes:95]
|  | March 30, 2019 |  | September 29, 2018 |
| Land and buildings | $ | 16,308 |  |  | $ | 16,216 |  |
| Machinery, equipment and internal-use software | 68,139 |  |  | 65,982 |  |
| Leasehold improvements | 8,589 |  |  | 8,205 |  |
| Gross property, plant and equipment | 93,036 |  |  | 90,403 |  |
| Accumulated depreciation and amortization | (54,290 | ) |  | (49,099 | ) |
| Total property, plant and equipment, net | $ | 38,746 |  |  | $ | 41,304 |  |

[0000320193-19-000066:notes:96]
[same as prior period, unchanged from 0000320193-19-000010:notes:15]

[0000320193-19-000066:notes:97]
|  | March 30, 2019 |  | September 29, 2018 |
| Long-term taxes payable | $ | 30,986 |  |  | $ | 33,589 |  |
| Other non-current liabilities | 21,179 |  |  | 15,325 |  |
| Total other non-current liabilities | $ | 52,165 |  |  | $ | 48,914 |  |

[0000320193-19-000066:notes:98]
[same as prior period, unchanged from 0000320193-19-000010:notes:17]

[0000320193-19-000066:notes:99]
The following table shows the detail of other income/(expense), net for the three- and six-month periods ended March 30, 2019 and March 31, 2018 (in millions):

[0000320193-19-000066:notes:100]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Interest and dividend income | $ | 1,358 |  |  | $ | 1,505 |  |  | $ | 2,665 |  |  | $ | 2,957 |  |
| Interest expense | (1,010 | ) |  | (792 | ) |  | (1,900 | ) |  | (1,526 | ) |
| Other income/(expense), net | 30 |  |  | (439 | ) |  | 173 |  |  | (401 | ) |
| Total other income/(expense), net | $ | 378 |  |  | $ | 274 |  |  | $ | 938 |  |  | $ | 1,030 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000320193-19-000066:notes:101]
Income Taxes
Uncertain Tax Positions

[0000320193-19-000066:notes:102]
As of March 30, 2019, the total amount of gross unrecognized tax benefits was $14.9 billion, of which $7.3 billion, if recognized, would impact the Company’s effective tax rate. The Company had accrued $1.3 billion of gross interest and penalties as of March 30, 2019. Both the unrecognized tax benefits and the associated interest and penalties that are not expected to result in payment or receipt of cash within one year are classified as other non-current liabilities in the Condensed Consolidated Balance Sheet.

[0000320193-19-000066:notes:103]
[same as prior period, unchanged from 0000320193-19-000010:notes:153]

[0000320193-19-000066:notes:104]
European Commission State Aid Decision
On August 30, 2016, the European Commission announced its decision that Ireland granted state aid to the Company by providing tax opinions in 1991 and 2007 concerning the tax allocation of profits of the Irish branches of two subsidiaries of the Company (the “State Aid Decision”). The State Aid Decision ordered Ireland to calculate and recover additional taxes from the Company for the period June 2003 through December 2014. The recovery amount was calculated to be €13.1 billion, plus interest of €1.2 billion. Irish legislative changes, effective as of January 2015, eliminated the application of the tax opinions from that date forward. The Company believes the State Aid Decision to be without merit and appealed to the General Court of the Court of Justice of the European Union. Ireland has also appealed the State Aid Decision. The Company believes that any incremental Irish corporate income taxes potentially due related to the State Aid Decision would be creditable against U.S. taxes, subject to any foreign tax credit limitations in the U.S. Tax Cuts and Jobs Act. As of March 30, 2019, the entire recovery amount plus interest was funded into escrow, where it will remain restricted from general use pending conclusion of all appeals. Refer to Note 3, “Financial Instruments” for more information.


## us-gaap:DebtDisclosureTextBlock

[0000320193-19-000066:notes:105]
Debt
Commercial Paper

[0000320193-19-000066:notes:106]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of March 30, 2019 and September 29, 2018, the Company had $11.9 billion and $12.0 billion of Commercial Paper outstanding, respectively, with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 2.56% as of March 30, 2019 and 2.18% as of September 29, 2018. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the six months ended March 30, 2019 and March 31, 2018 (in millions):

[0000320193-19-000066:notes:107]
|  | Six Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | (2,484 | ) |  | $ | 4,070 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 10,235 |  |  | 5,550 |  |
| Repayments of commercial paper | (7,787 | ) |  | (9,619 | ) |
| Proceeds from/(Repayments of) commercial paper, net | 2,448 |  |  | (4,069 | ) |
| Total proceeds from/(repayments of) commercial paper, net | $ | (36 | ) |  | $ | 1 |  |

[0000320193-19-000066:notes:108]
Term Debt

[0000320193-19-000066:notes:109]
As of March 30, 2019, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $101.2 billion (collectively the “Notes”). The Notes are senior unsecured obligations, and interest is payable in arrears, quarterly for the U.S. dollar–denominated and Australian dollar–denominated floating-rate notes, semi-annually for the U.S. dollar–denominated, Australian dollar–denominated, British pound–denominated, Japanese yen–denominated and Canadian dollar–denominated fixed-rate notes and annually for the euro-denominated and Swiss franc–denominated fixed-rate notes.

[0000320193-19-000066:notes:110]
The following table provides a summary of the Company’s term debt as of March 30, 2019 and September 29, 2018:

[0000320193-19-000066:notes:111]
|  | Maturities(calendar year) |  | March 30, 2019 |  | September 29, 2018 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 2.400% – 3.850% notes | 2023 | – | 2043 |  | $ | 8,500 |  |  |  | 2.44% | – | 3.91 | % |  | $ | 8,500 |  |  |  | 2.44% | – | 3.91 | % |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2019 |  | 1,000 |  |  |  |  |  | 3.03 | % |  | 1,000 |  |  |  |  |  | 2.64 | % |
| Fixed-rate 2.100% – 4.450% notes | 2019 | – | 2044 |  | 8,500 |  |  |  | 3.03% | – | 4.48 | % |  | 8,500 |  |  |  | 2.64% | – | 4.48 | % |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2020 |  | 1,497 |  |  |  | 1.87% | – | 2.99 | % |  | 1,507 |  |  |  | 1.87% | – | 2.64 | % |
| Fixed-rate 0.350% – 4.375% notes | 2019 | – | 2045 |  | 24,178 |  |  |  | 0.28% | – | 4.51 | % |  | 24,410 |  |  |  | 0.28% | – | 4.51 | % |
| 2016 debt issuances of $24.9 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2021 |  | 850 |  |  |  | 2.88% | – | 3.78 | % |  | 1,350 |  |  |  | 2.48% | – | 3.44 | % |
| Fixed-rate 1.100% – 4.650% notes | 2019 | – | 2046 |  | 22,038 |  |  |  | 1.13% | – | 4.78 | % |  | 23,059 |  |  |  | 1.13% | – | 4.78 | % |
| 2017 debt issuances of $28.7 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2020 | – | 2022 |  | 2,750 |  |  |  | 2.77% | – | 3.20 | % |  | 3,250 |  |  |  | 2.41% | – | 2.84 | % |
| Fixed-rate 0.875% – 4.300% notes | 2019 | – | 2047 |  | 24,929 |  |  |  | 1.54% | – | 4.30 | % |  | 25,617 |  |  |  | 1.54% | – | 4.30 | % |
| 2018 debt issuance of $7.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 1.800% – 3.750% notes | 2019 | – | 2047 |  | 7,000 |  |  |  | 1.83% | – | 3.80 | % |  | 7,000 |  |  |  | 1.83% | – | 3.80 | % |
| Total term debt |  |  |  |  | 101,242 |  |  |  |  |  |  |  | 104,193 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (202 | ) |  |  |  |  |  |  | (218 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | (334 | ) |  |  |  |  |  |  | (1,456 | ) |  |  |  |  |  |
| Less: Current portion of term debt |  |  |  |  | (10,505 | ) |  |  |  |  |  |  | (8,784 | ) |  |  |  |  |  |
| Total non-current portion of term debt |  |  |  |  | $ | 90,201 |  |  |  |  |  |  |  | $ | 93,735 |  |  |  |  |  |  |

[0000320193-19-000066:notes:112]
To manage interest rate risk on certain of its U.S. dollar–denominated fixed- or floating-rate notes, the Company has entered into interest rate swaps to effectively convert the fixed interest rates to floating interest rates or the floating interest rates to fixed interest rates on a portion of these notes. Additionally, to manage foreign currency risk on certain of its foreign currency–denominated notes, the Company has entered into foreign currency swaps to effectively convert these notes to U.S. dollar–denominated notes.

[0000320193-19-000066:notes:113]
A portion of the Company’s Japanese yen–denominated notes is designated as a hedge of the foreign currency exposure of the Company’s net investment in a foreign operation. As of March 30, 2019 and September 29, 2018, the carrying value of the debt designated as a net investment hedge was $1.1 billion and $811 million, respectively. For further discussion regarding the Company’s use of derivative instruments, refer to the Derivative Financial Instruments section of Note 3, “Financial Instruments.”

[0000320193-19-000066:notes:114]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $828 million and $1.6 billion of interest expense on its term debt for the three- and six-month periods ended March 30, 2019, respectively. The Company recognized $742 million and $1.4 billion of interest expense on its term debt for the three- and six-month periods ended March 31, 2018, respectively.
As of March 30, 2019 and September 29, 2018, the fair value of the Company’s Notes, based on Level 2 inputs, was $103.3 billion and $103.2 billion, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000320193-19-000066:notes:115]
Shareholders’ EquityAs of March 30, 2019, the Company had an authorized program to repurchase up to $100 billion of the Company’s common stock, of which $61.3 billion had been utilized. During the six months ended March 30, 2019, the Company repurchased 164.7 million shares of its common stock for $32.2 billion, including 55.1 million shares initially delivered under a $12.0 billion accelerated share repurchase arrangement dated February 2019. On April 30, 2019, the Company announced the Board of Directors increased the share repurchase program authorization from $100 billion to $175 billion. The Company’s share repurchase program does not obligate it to acquire any specific number of shares. Under this program, shares may be repurchased in privately negotiated and/or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000320193-19-000066:notes:116]
Comprehensive Income
The Company’s OCI consists of foreign currency translation adjustments from those subsidiaries not using the U.S. dollar as their functional currency, net deferred gains and losses on certain derivative instruments accounted for as cash flow hedges and unrealized gains and losses on marketable debt securities classified as available-for-sale.

[0000320193-19-000066:notes:117]
The following table shows the pre-tax amounts reclassified from AOCI into the Condensed Consolidated Statements of Operations, and the associated financial statement line item, for the three- and six-month periods ended March 30, 2019 and March 31, 2018 (in millions):

[0000320193-19-000066:notes:118]
|  |  |  |  | Three Months Ended |  | Six Months Ended |
| Comprehensive Income Components |  | Financial Statement Line Item |  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Unrealized (gains)/losses on derivative instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Total net sales |  | $ | (97 | ) |  | $ | 87 |  |  | $ | (34 | ) |  | $ | 271 |  |
|  |  | Total cost of sales |  | (76 | ) |  | 21 |  |  | (451 | ) |  | (6 | ) |
|  |  | Other income/(expense), net |  | 52 |  |  | (390 | ) |  | 448 |  |  | (423 | ) |
| Interest rate contracts |  | Other income/(expense), net |  | 2 |  |  | (2 | ) |  | 3 |  |  | (3 | ) |
|  |  |  |  | (119 | ) |  | (284 | ) |  | (34 | ) |  | (161 | ) |
| Unrealized (gains)/losses on marketable securities |  | Other income/(expense), net |  | 36 |  |  | 36 |  |  | 83 |  |  | (80 | ) |
| Total amounts reclassified from AOCI |  | $ | (83 | ) |  | $ | (248 | ) |  | $ | 49 |  |  | $ | (241 | ) |

[0000320193-19-000066:notes:119]
The following table shows the changes in AOCI by component for the six months ended March 30, 2019 (in millions):

[0000320193-19-000066:notes:120]
|  | Cumulative ForeignCurrency Translation |  | Unrealized Gains/Losseson Derivative Instruments |  | Unrealized Gains/Losseson Marketable Securities |  | Total |
| Balances as of September 29, 2018 | $ | (1,055 | ) |  | $ | 810 |  |  | $ | (3,209 | ) |  | $ | (3,454 | ) |
| Other comprehensive income/(loss) before reclassifications | 90 |  |  | (533 | ) |  | 2,734 |  |  | 2,291 |  |
| Amounts reclassified from AOCI | — |  |  | (34 | ) |  | 83 |  |  | 49 |  |
| Tax effect | 6 |  |  | 120 |  |  | (600 | ) |  | (474 | ) |
| Other comprehensive income/(loss) | 96 |  |  | (447 | ) |  | 2,217 |  |  | 1,866 |  |
| Cumulative effect of change in accounting principle (1) | — |  |  | — |  |  | 89 |  |  | 89 |  |
| Balances as of March 30, 2019 | $ | (959 | ) |  | $ | 363 |  |  | $ | (903 | ) |  | $ | (1,499 | ) |

[0000320193-19-000066:notes:121]
(1)
Refer to Note 1, “Summary of Significant Accounting Policies” for more information on the Company’s adoption of ASU 2016-01 at the beginning of the first quarter of 2019.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000320193-19-000066:notes:122]
Benefit Plans
Stock Plans

[0000320193-19-000066:notes:123]
The Company had 235.5 million shares reserved for future issuance under its stock plans as of March 30, 2019. Restricted stock units (“RSUs”) granted under the Company’s stock plans generally vest over four years, based on continued employment, and are settled upon vesting in shares of the Company’s common stock on a one-for-one basis. Each share issued with respect to RSUs granted under the Company’s stock plans reduces the number of shares available for grant under the plans by two shares. RSUs canceled and shares withheld to satisfy tax withholding obligations increase the number of shares available for grant under the plans utilizing a factor of two times the number of RSUs canceled or shares withheld.

[0000320193-19-000066:notes:124]
[same as prior period, unchanged from 0000320193-19-000010:notes:66]

[0000320193-19-000066:notes:125]
During the three months ended March 30, 2019, Section 16 officers Angela Ahrendts, Timothy D. Cook, Chris Kondo, Luca Maestri and Jeffrey Williams had equity trading plans in place in accordance with Rule 10b5-1(c)(1) under the Exchange Act. An equity trading plan is a written document that pre-establishes the amounts, prices and dates (or formula for determining the amounts, prices and dates) of future purchases or sales of the Company’s stock, including shares acquired pursuant to the Company’s employee and director equity plans.

[0000320193-19-000066:notes:126]
[same as prior period, unchanged from 0000320193-19-000010:notes:68]

[0000320193-19-000066:notes:127]
A summary of the Company’s RSU activity and related information for the six months ended March 30, 2019 is as follows:

[0000320193-19-000066:notes:128]
|  | Number ofRSUs(in thousands) |  | Weighted-AverageGrant Date FairValue Per RSU |  | AggregateFair Value(in millions) |
| Balance as of September 29, 2018 | 92,155 |  |  | $ | 134.60 |  |  |  |
| RSUs granted | 32,252 |  |  | $ | 218.06 |  |  |  |
| RSUs vested | (20,988 | ) |  | $ | 125.84 |  |  |  |
| RSUs canceled | (2,302 | ) |  | $ | 157.83 |  |  |  |
| Balance as of March 30, 2019 | 101,117 |  |  | $ | 162.51 |  |  | $ | 19,207 |  |

[0000320193-19-000066:notes:129]
The fair value as of the respective vesting dates of RSUs was $348 million and $4.4 billion for the three- and six-month periods ended March 30, 2019, respectively, and was $457 million and $3.6 billion for the three- and six-month periods ended March 31, 2018, respectively.

[0000320193-19-000066:notes:130]
[same as prior period, unchanged from 0000320193-19-000010:notes:72]

[0000320193-19-000066:notes:131]
The following table shows share-based compensation expense and the related income tax benefit included in the Condensed Consolidated Statements of Operations for the three- and six-month periods ended March 30, 2019 and March 31, 2018 (in millions):

[0000320193-19-000066:notes:132]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Share-based compensation expense | $ | 1,514 |  |  | $ | 1,348 |  |  | $ | 3,073 |  |  | $ | 2,644 |  |
| Income tax benefit related to share-based compensation expense | $ | (331 | ) |  | $ | (347 | ) |  | $ | (1,081 | ) |  | $ | (978 | ) |

[0000320193-19-000066:notes:133]
As of March 30, 2019, the total unrecognized compensation cost related to outstanding RSUs and stock options was $12.8 billion, which the Company expects to recognize over a weighted-average period of 2.8 years.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000320193-19-000066:notes:134]
Commitments and Contingencies
Accrued Warranty and Indemnification

[0000320193-19-000066:notes:135]
The following table shows changes in the Company’s accrued warranties and related costs for the three- and six-month periods ended March 30, 2019 and March 31, 2018 (in millions):

[0000320193-19-000066:notes:136]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Beginning accrued warranty and related costs | $ | 3,819 |  |  | $ | 4,323 |  |  | $ | 3,692 |  |  | $ | 3,834 |  |
| Cost of warranty claims | (915 | ) |  | (933 | ) |  | (1,911 | ) |  | (1,915 | ) |
| Accruals for product warranty | 583 |  |  | 640 |  |  | 1,706 |  |  | 2,111 |  |
| Ending accrued warranty and related costs | $ | 3,487 |  |  | $ | 4,030 |  |  | $ | 3,487 |  |  | $ | 4,030 |  |

[0000320193-19-000066:notes:137]
Agreements entered into by the Company may include indemnification provisions, which may subject the Company to costs and damages in the event of a claim against an indemnified third party. Except as disclosed under the heading “Contingencies” below, in the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to indemnification of third parties.

[0000320193-19-000066:notes:138]
The Company offers an iPhone Upgrade Program, which is available to customers who purchase a qualifying iPhone in the U.S., the U.K. and mainland China. The iPhone Upgrade Program provides customers the right to trade in that iPhone for a specified amount when purchasing a new iPhone, provided certain conditions are met. The Company accounts for the trade-in right as a guarantee liability and recognizes arrangement revenue net of the fair value of such right, with subsequent changes to the guarantee liability recognized within net sales.

[0000320193-19-000066:notes:139]
The Company has entered into indemnification agreements with its directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers of the Company, and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. While the Company maintains directors and officers liability insurance coverage, such insurance coverage may be insufficient to cover all losses or all types of claims that may arise.

[0000320193-19-000066:notes:140]
Concentrations in the Available Sources of Supply of Materials and Product

[0000320193-19-000066:notes:141]
Although most components essential to the Company’s business are generally available from multiple sources, certain components are currently obtained from single or limited sources. In addition, the Company competes for various components with other participants in the markets for mobile communication and media devices and personal computers. Therefore, many components used by the Company, including those that are available from multiple sources, are at times subject to industry-wide shortage and significant commodity pricing fluctuations that could materially adversely affect the Company’s financial condition and operating results.

[0000320193-19-000066:notes:142]
The Company uses some custom components that are not commonly used by its competitors, and new products introduced by the Company often utilize custom components available from only one source. When a component or product uses new technologies, initial capacity constraints may exist until the suppliers’ yields have matured or manufacturing capacity has increased. If the Company’s supply of components for a new or existing product were delayed or constrained, or if an outsourcing partner delayed shipments of completed products to the Company, the Company’s financial condition and operating results could be materially adversely affected. The Company’s business and financial performance could also be materially adversely affected depending on the time required to obtain sufficient quantities from the original source, or to identify and obtain sufficient quantities from an alternative source. Continued availability of these components at acceptable prices, or at all, may be affected if suppliers decide to concentrate on the production of common components instead of components customized to meet the Company’s requirements.

[0000320193-19-000066:notes:143]
The Company has entered into agreements for the supply of many components; however, there can be no guarantee that the Company will be able to extend or renew these agreements on similar terms, or at all. Therefore, the Company remains subject to significant risks of supply shortages and price increases that could materially adversely affect its financial condition and operating results.

[0000320193-19-000066:notes:144]
Substantially all of the Company’s hardware products are manufactured by outsourcing partners that are located primarily in Asia, with some Mac computers manufactured in the U.S. and Ireland. A significant concentration of this manufacturing is currently performed by a small number of outsourcing partners, often in single locations. Certain of these outsourcing partners are single-sourced suppliers of components and manufacturers for many of the Company’s products. Although the Company works closely with its outsourcing partners on manufacturing schedules, the Company’s financial condition and operating results could be materially adversely affected if its outsourcing partners were unable to meet their production commitments. The Company’s manufacturing purchase obligations typically cover its requirements for periods up to 150 days.

[0000320193-19-000066:notes:145]
Other Off–Balance Sheet Commitments

[0000320193-19-000066:notes:146]
Operating Leases

[0000320193-19-000066:notes:147]
The Company leases various equipment and facilities, including retail space, under noncancelable operating lease arrangements. The Company does not currently utilize any other off–balance sheet financing arrangements. As of March 30, 2019, the Company’s total future minimum lease payments under noncancelable operating leases were $10.4 billion. The Company’s retail store and other facility leases typically have original terms not exceeding 10 years and generally contain multi-year renewal options.

[0000320193-19-000066:notes:148]
Unconditional Purchase Obligations

[0000320193-19-000066:notes:149]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of payments for supplier arrangements, internet and telecommunication services, intellectual property licenses and content creation. As of March 30, 2019, the Company’s total future payments under noncancelable unconditional purchase obligations having a remaining term in excess of one year were $7.6 billion.

[0000320193-19-000066:notes:150]
Contingencies

[0000320193-19-000066:notes:151]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully adjudicated, as further discussed in Part II, Item 1 of this Form 10-Q under the heading “Legal Proceedings” and in Part II, Item 1A of this Form 10-Q under the heading “Risk Factors.” The outcome of litigation is inherently uncertain. If one or more legal matters were resolved against the Company in a reporting period for amounts in excess of management’s expectations, the Company’s financial condition and operating results for that reporting period could be materially adversely affected. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to loss contingencies for asserted legal and other claims, except for the following matters:

[0000320193-19-000066:notes:152]
VirnetX

[0000320193-19-000066:notes:153]
VirnetX, Inc. filed two lawsuits in the U.S. District Court for the Eastern District of Texas (the “Eastern Texas District Court”) against the Company alleging that certain Company products infringe four patents (the “VirnetX Patents”) relating to network communications technology (“VirnetX I” and “VirnetX II”). On September 30, 2016, a jury returned a verdict in VirnetX I against the Company and awarded damages of $302 million, which later increased to $440 million in post-trial proceedings. The Company appealed the VirnetX I verdict to the U.S. Court of Appeals for the Federal Circuit (the “Federal Circuit”). On April 11, 2018, a jury returned a verdict in VirnetX II against the Company and awarded damages of $503 million. VirnetX II is currently on appeal. The Company has challenged the validity of the VirnetX Patents at the U.S. Patent and Trademark Office (the “PTO”). In response, the PTO has declared the VirnetX Patents invalid. VirnetX appealed the invalidity decision of the PTO to the Federal Circuit. The Federal Circuit consolidated the Company’s appeal of the Eastern Texas District Court VirnetX I verdict and VirnetX’s appeals from the PTO invalidity proceedings. On January 15, 2019, the Federal Circuit affirmed the VirnetX I verdict, which the Company intends to further appeal. The remaining appeals from the PTO proceedings invalidating the VirnetX Patents remain pending. The Company has accrued its best estimate for the ultimate resolution of these matters.

[0000320193-19-000066:notes:154]
Qualcomm

[0000320193-19-000066:notes:155]
On January 20, 2017, the Company filed a lawsuit against Qualcomm Incorporated and affiliated parties (“Qualcomm”) in the U.S. District Court for the Southern District of California seeking, among other things, to enjoin Qualcomm from requiring the Company to pay royalties at the rate demanded by Qualcomm. No Qualcomm-related royalty payments had been remitted by the Company to its contract manufacturers since the beginning of the second quarter of 2017. Following the Company’s lawsuit, Qualcomm filed patent infringement suits against the Company and its affiliates in the U.S. and various international jurisdictions, some of which sought to enjoin the sale of certain of the Company’s products in particular countries.

[0000320193-19-000066:notes:156]
On April 16, 2019, the Company and Qualcomm reached a settlement agreement to dismiss all litigation between the two companies worldwide. The companies also reached a multi-year license agreement and a multi-year supply agreement. Under the terms of the settlement agreement, Apple will make a payment to Qualcomm to, among other things, resolve disputes over the withheld royalty payments.

[0000320193-19-000066:notes:157]
iOS Performance Management Cases
Various civil litigation matters have been filed in state and federal courts in the U.S. and in various international jurisdictions alleging violation of consumer protection laws, fraud, computer intrusion and other causes of action related to the Company’s performance management feature used in its iPhone operating systems, introduced to certain iPhones in iOS updates 10.2.1 and 11.2. The claims seek monetary damages and other non-monetary relief. On April 5, 2018, several U.S. federal actions were consolidated through a Multidistrict Litigation process into a single action in the U.S. District Court for the Northern District of California. In addition to civil litigation, the Company is also responding to governmental investigations and requests for information relating to the performance management feature. The Company believes that its iPhones were not defective, that the performance management feature introduced with iOS updates 10.2.1 and 11.2 was intended to, and did, improve customers’ user experience, and that the Company did not make any misleading statements or fail to disclose any material information. The Company has accrued its best estimate for the ultimate resolution of these matters.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000320193-19-000066:notes:158]
Segment Information and Geographic Data
The Company reports segment information based on the “management” approach. The management approach designates the internal reporting used by management for making decisions and assessing performance as the source of the Company’s reportable segments.

[0000320193-19-000066:notes:159]
[same as prior period, unchanged from 0000320193-19-000010:notes:173]

[0000320193-19-000066:notes:160]
[same as prior period, unchanged from 0000320193-19-000010:notes:174]

[0000320193-19-000066:notes:161]
The following table shows information by reportable segment for the three- and six-month periods ended March 30, 2019 and March 31, 2018 (in millions):

[0000320193-19-000066:notes:162]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Americas: |  |  |  |  |  |  |  |
| Net sales | $ | 25,596 |  |  | $ | 24,841 |  |  | $ | 62,536 |  |  | $ | 60,034 |  |
| Operating income | $ | 7,687 |  |  | $ | 7,768 |  |  | $ | 18,887 |  |  | $ | 19,084 |  |
| Europe: |  |  |  |  |  |  |  |
| Net sales | $ | 13,054 |  |  | $ | 13,846 |  |  | $ | 33,417 |  |  | $ | 34,900 |  |
| Operating income | $ | 4,026 |  |  | $ | 4,259 |  |  | $ | 10,684 |  |  | $ | 11,152 |  |
| Greater China: |  |  |  |  |  |  |  |
| Net sales | $ | 10,218 |  |  | $ | 13,024 |  |  | $ | 23,387 |  |  | $ | 30,980 |  |
| Operating income | $ | 3,607 |  |  | $ | 4,963 |  |  | $ | 8,921 |  |  | $ | 11,871 |  |
| Japan: |  |  |  |  |  |  |  |
| Net sales | $ | 5,532 |  |  | $ | 5,468 |  |  | $ | 12,442 |  |  | $ | 12,705 |  |
| Operating income | $ | 2,390 |  |  | $ | 2,346 |  |  | $ | 5,404 |  |  | $ | 5,428 |  |
| Rest of Asia Pacific: |  |  |  |  |  |  |  |
| Net sales | $ | 3,615 |  |  | $ | 3,958 |  |  | $ | 10,543 |  |  | $ | 10,811 |  |
| Operating income | $ | 1,096 |  |  | $ | 1,278 |  |  | $ | 3,656 |  |  | $ | 3,853 |  |

[0000320193-19-000066:notes:163]
A reconciliation of the Company’s segment operating income to the Condensed Consolidated Statements of Operations for the three- and six-month periods ended March 30, 2019 and March 31, 2018 is as follows (in millions):

[0000320193-19-000066:notes:164]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Segment operating income | $ | 18,806 |  |  | $ | 20,614 |  |  | $ | 47,552 |  |  | $ | 51,388 |  |
| Research and development expense | (3,948 | ) |  | (3,378 | ) |  | (7,850 | ) |  | (6,785 | ) |
| Other corporate expenses, net | (1,443 | ) |  | (1,342 | ) |  | (2,941 | ) |  | (2,435 | ) |
| Total operating income | $ | 13,415 |  |  | $ | 15,894 |  |  | $ | 36,761 |  |  | $ | 42,168 |  |
