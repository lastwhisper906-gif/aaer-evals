# AAPL notes — 0000320193-22-000108


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000320193-22-000108:notes:1]
Summary of Significant Accounting Policies
Basis of Presentation and Preparation

[0000320193-22-000108:notes:2]
The consolidated financial statements include the accounts of Apple Inc. and its wholly owned subsidiaries (collectively “Apple” or the “Company”). Intercompany accounts and transactions have been eliminated. The preparation of these consolidated financial statements and accompanying notes in conformity with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported. Actual results could differ materially from those estimates. Certain prior period amounts in the consolidated financial statements and accompanying notes have been reclassified to conform to the current period’s presentation.

[0000320193-22-000108:notes:3]
The Company’s fiscal year is the 52- or 53-week period that ends on the last Saturday of September. An additional week is included in the first fiscal quarter every five or six years to realign the Company’s fiscal quarters with calendar quarters, which will occur in the first quarter of the Company’s fiscal year ending September 30, 2023. The Company’s fiscal years 2022, 2021 and 2020 spanned 52 weeks each. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in September and the associated quarters, months and periods of those fiscal years.

[0000320193-22-000108:notes:4]
Revenue Recognition

[0000320193-22-000108:notes:5]
Net sales consist of revenue from the sale of iPhone, Mac, iPad, Services and other products. The Company recognizes revenue at the amount to which it expects to be entitled when control of the products or services is transferred to its customers. Control is generally transferred when the Company has a present right to payment and title and the significant risks and rewards of ownership of products or services are transferred to its customers. For most of the Company’s Products net sales, control transfers when products are shipped. For the Company’s Services net sales, control transfers over time as services are delivered. Payment for Products and Services net sales is collected within a short period following transfer of control or commencement of delivery of services, as applicable.

[0000320193-22-000108:notes:6]
The Company records reductions to Products net sales related to future product returns, price protection and other customer incentive programs based on the Company’s expectations and historical experience.

[0000320193-22-000108:notes:7]
For arrangements with multiple performance obligations, which represent promises within an arrangement that are distinct, the Company allocates revenue to all distinct performance obligations based on their relative stand-alone selling prices (“SSPs”). When available, the Company uses observable prices to determine SSPs. When observable prices are not available, SSPs are established that reflect the Company’s best estimates of what the selling prices of the performance obligations would be if they were sold regularly on a stand-alone basis. The Company’s process for estimating SSPs without observable prices considers multiple factors that may vary depending upon the unique facts and circumstances related to each performance obligation including, where applicable, prices charged by the Company for similar offerings, market trends in the pricing for similar offerings, product-specific business objectives and the estimated cost to provide the performance obligation.

[0000320193-22-000108:notes:8]
The Company has identified up to three performance obligations regularly included in arrangements involving the sale of iPhone, Mac, iPad and certain other products. The first performance obligation, which represents the substantial portion of the allocated sales price, is the hardware and bundled software delivered at the time of sale. The second performance obligation is the right to receive certain product-related bundled services, which include iCloud®, Siri® and Maps. The third performance obligation is the right to receive, on a when-and-if-available basis, future unspecified software upgrades relating to the software bundled with each device. The Company allocates revenue and any related discounts to these performance obligations based on their relative SSPs. Because the Company lacks observable prices for the undelivered performance obligations, the allocation of revenue is based on the Company’s estimated SSPs. Revenue allocated to the delivered hardware and bundled software is recognized when control has transferred to the customer, which generally occurs when the product is shipped. Revenue allocated to the product-related bundled services and unspecified software upgrade rights is deferred and recognized on a straight-line basis over the estimated period they are expected to be provided. Cost of sales related to delivered hardware and bundled software, including estimated warranty costs, are recognized at the time of sale. Costs incurred to provide product-related bundled services and unspecified software upgrade rights are recognized as cost of sales as incurred.

[0000320193-22-000108:notes:9]
For certain long-term service arrangements, the Company has performance obligations for services it has not yet delivered. For these arrangements, the Company does not have a right to bill for the undelivered services. The Company has determined that any unbilled consideration relates entirely to the value of the undelivered services. Accordingly, the Company has not recognized revenue, and does not disclose amounts, related to these undelivered services.

[0000320193-22-000108:notes:10]
For the sale of third-party products where the Company obtains control of the product before transferring it to the customer, the Company recognizes revenue based on the gross amount billed to customers. The Company considers multiple factors when determining whether it obtains control of third-party products, including evaluating if it can establish the price of the product, retains inventory risk for tangible products or has the responsibility for ensuring acceptability of the product. For third-party applications sold through the App Store and certain digital content sold through the Company’s other digital content stores, the Company does not obtain control of the product before transferring it to the customer. Therefore, the Company accounts for such sales on a net basis by recognizing in Services net sales only the commission it retains.

[0000320193-22-000108:notes:11]
The Company records revenue net of taxes collected from customers that are remitted to governmental authorities, with the collected taxes recorded within other current liabilities until remitted to the relevant government authority.

[0000320193-22-000108:notes:12]
Share-Based Compensation

[0000320193-22-000108:notes:13]
The Company generally measures share-based compensation based on the closing price of the Company’s common stock on the date of grant, and recognizes expense on a straight-line basis for its estimate of equity awards that will ultimately vest. Further information regarding share-based compensation can be found in Note 9, “Benefit Plans.”

[0000320193-22-000108:notes:14]
Earnings Per Share

[0000320193-22-000108:notes:15]
The following table shows the computation of basic and diluted earnings per share for 2022, 2021 and 2020 (net income in millions and shares in thousands):

[0000320193-22-000108:notes:16]
|  | 2022 |  | 2021 |  | 2020 |
| Numerator: |  |  |  |  |  |
| Net income | $ | 99,803 |  |  | $ | 94,680 |  |  | $ | 57,411 |  |
| Denominator: |  |  |  |  |  |
| Weighted-average basic shares outstanding | 16,215,963 |  |  | 16,701,272 |  |  | 17,352,119 |  |
| Effect of dilutive securities | 109,856 |  |  | 163,647 |  |  | 176,095 |  |
| Weighted-average diluted shares | 16,325,819 |  |  | 16,864,919 |  |  | 17,528,214 |  |
| Basic earnings per share | $ | 6.15 |  |  | $ | 5.67 |  |  | $ | 3.31 |  |
| Diluted earnings per share | $ | 6.11 |  |  | $ | 5.61 |  |  | $ | 3.28 |  |

[0000320193-22-000108:notes:17]
The Company applies the treasury stock method to determine the dilutive effect of potentially dilutive securities.

[0000320193-22-000108:notes:18]
Cash Equivalents and Marketable Securities

[0000320193-22-000108:notes:19]
All highly liquid investments with maturities of three months or less at the date of purchase are classified as cash equivalents.

[0000320193-22-000108:notes:20]
The Company’s investments in marketable debt securities have been classified and accounted for as available-for-sale. The Company classifies its marketable debt securities as either short-term or long-term based on each instrument’s underlying contractual maturity date.

[0000320193-22-000108:notes:21]
The Company’s investments in marketable equity securities are classified based on the nature of the securities and their availability for use in current operations.

[0000320193-22-000108:notes:22]
The cost of securities sold is determined using the specific identification method.

[0000320193-22-000108:notes:23]
Inventories

[0000320193-22-000108:notes:24]
Inventories are measured using the first-in, first-out method.

[0000320193-22-000108:notes:25]
Restricted Marketable Securities

[0000320193-22-000108:notes:26]
The Company considers marketable securities to be restricted when withdrawal or general use is legally restricted. The Company reports restricted marketable securities as current or non-current marketable securities in the Consolidated Balance Sheets based on the classification of the underlying securities.

[0000320193-22-000108:notes:27]
Property, Plant and Equipment

[0000320193-22-000108:notes:28]
Depreciation on property, plant and equipment is recognized on a straight-line basis over the estimated useful lives of the assets, which for buildings is the shorter of 40 years or the remaining life of the building; between one and five years for machinery and equipment, including manufacturing equipment; and the shorter of the lease term or useful life for leasehold improvements. Capitalized costs related to internal-use software are amortized on a straight-line basis over the estimated useful lives of the assets, which range from five to seven years. Depreciation and amortization expense on property, plant and equipment was $8.7 billion, $9.5 billion and $9.7 billion during 2022, 2021 and 2020, respectively.

[0000320193-22-000108:notes:29]
Derivative Instruments and Hedging

[0000320193-22-000108:notes:30]
All derivative instruments are recorded in the Consolidated Balance Sheets at fair value. The accounting treatment for derivative gains and losses is based on intended use and hedge designation.

[0000320193-22-000108:notes:31]
Gains and losses arising from amounts that are included in the assessment of cash flow hedge effectiveness are initially deferred in accumulated other comprehensive income/(loss) (“AOCI”) and subsequently reclassified into earnings when the hedged transaction affects earnings, and in the same line item in the Consolidated Statements of Operations. For options designated as cash flow hedges, the Company excludes time value from the assessment of hedge effectiveness and recognizes it on a straight-line basis over the life of the hedge in the Consolidated Statements of Operations line item to which the hedge relates. Changes in the fair value of amounts excluded from the assessment of hedge effectiveness are recognized in other comprehensive income/(loss) (“OCI”).

[0000320193-22-000108:notes:32]
Gains and losses arising from amounts that are included in the assessment of fair value hedge effectiveness are recognized in the Consolidated Statements of Operations line item to which the hedge relates along with offsetting losses and gains related to the change in value of the hedged item. For foreign exchange forward contracts designated as fair value hedges, the Company excludes the forward carry component from the assessment of hedge effectiveness and recognizes it in other income/(expense), net (“OI&E”) on a straight-line basis over the life of the hedge. Changes in the fair value of amounts excluded from the assessment of hedge effectiveness are recognized in OCI.

[0000320193-22-000108:notes:33]
Gains and losses arising from changes in the fair values of derivative instruments that are not designated as accounting hedges are recognized in the Consolidated Statements of Operations line items to which the derivative instruments relate.

[0000320193-22-000108:notes:34]
The Company presents derivative assets and liabilities at their gross fair values in the Consolidated Balance Sheets. The Company classifies cash flows related to derivative instruments as operating activities in the Consolidated Statements of Cash Flows.

[0000320193-22-000108:notes:35]
Fair Value Measurements

[0000320193-22-000108:notes:36]
The fair values of the Company’s money market funds and certain marketable equity securities are based on quoted prices in active markets for identical assets. The valuation techniques used to measure the fair value of the Company’s debt instruments and all other financial instruments, which generally have counterparties with high credit ratings, are based on quoted market prices or model-driven valuations using significant inputs derived from or corroborated by observable market data.

[0000320193-22-000108:notes:37]
Income Taxes

[0000320193-22-000108:notes:38]
The Company records certain deferred tax assets and liabilities in connection with the minimum tax on certain foreign earnings created by the U.S. Tax Cuts and Jobs Act of 2017 (the “Act”).

[0000320193-22-000108:notes:39]
Leases

[0000320193-22-000108:notes:40]
The Company combines and accounts for lease and nonlease components as a single lease component for leases of corporate, data center and retail facilities. The discount rates related to the Company’s lease liabilities are generally based on estimates of the Company’s incremental borrowing rate, as the discount rates implicit in the Company’s leases cannot be readily determined.

[0000320193-22-000108:notes:41]
Segment Reporting

[0000320193-22-000108:notes:42]
The Company reports segment information based on the “management” approach. The management approach designates the internal reporting used by management for making decisions and assessing performance as the source of the Company’s reportable segments.

[0000320193-22-000108:notes:43]
The Company manages its business primarily on a geographic basis. The Company’s reportable segments consist of the Americas, Europe, Greater China, Japan and Rest of Asia Pacific. Americas includes both North and South America. Europe includes European countries, as well as India, the Middle East and Africa. Greater China includes China mainland, Hong Kong and Taiwan. Rest of Asia Pacific includes Australia and those Asian countries not included in the Company’s other reportable segments. Although the reportable segments provide similar hardware and software products and similar services, each one is managed separately to better align with the location of the Company’s customers and distribution partners and the unique market dynamics of each geographic region. The accounting policies of the various segments are the same as those described elsewhere in this Note 1, “Summary of Significant Accounting Policies.”

[0000320193-22-000108:notes:44]
The Company evaluates the performance of its reportable segments based on net sales and operating income. Net sales for geographic segments are generally based on the location of customers and sales through the Company’s retail stores located in those geographic locations. Operating income for each segment includes net sales to third parties, related cost of sales and operating expenses directly attributable to the segment. Advertising expenses are generally included in the geographic segment in which the expenditures are incurred. Operating income for each segment excludes other income and expense and certain expenses managed outside the reportable segments. Costs excluded from segment operating income include various corporate expenses such as research and development (“R&D”), corporate marketing expenses, certain share-based compensation expenses, income taxes, various nonrecurring charges and other separately managed general and administrative costs. The Company does not include intercompany transfers between segments for management reporting purposes.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000320193-22-000108:notes:45]
The fair values of the Company’s money market funds and certain marketable equity securities are based on quoted prices in active markets for identical assets. The valuation techniques used to measure the fair value of the Company’s debt instruments and all other financial instruments, which generally have counterparties with high credit ratings, are based on quoted market prices or model-driven valuations using significant inputs derived from or corroborated by observable market data.
Level 1 fair value estimates are based on quoted prices in active markets for identical assets or liabilities.Level 2 fair value estimates are based on observable inputs other than quoted prices in active markets for identical assets and liabilities, quoted prices for identical or similar assets or liabilities in inactive markets, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000320193-22-000108:notes:46]
Revenue
Net sales disaggregated by significant products and services for 2022, 2021 and 2020 were as follows (in millions):

[0000320193-22-000108:notes:47]
|  | 2022 |  | 2021 |  | 2020 |
| iPhone (1) | $ | 205,489 |  |  | $ | 191,973 |  |  | $ | 137,781 |  |
| Mac (1) | 40,177 |  |  | 35,190 |  |  | 28,622 |  |
| iPad (1) | 29,292 |  |  | 31,862 |  |  | 23,724 |  |
| Wearables, Home and Accessories (1)(2) | 41,241 |  |  | 38,367 |  |  | 30,620 |  |
| Services (3) | 78,129 |  |  | 68,425 |  |  | 53,768 |  |
| Total net sales (4) | $ | 394,328 |  |  | $ | 365,817 |  |  | $ | 274,515 |  |

[0000320193-22-000108:notes:48]
(1)Products net sales include amortization of the deferred value of unspecified software upgrade rights, which are bundled in the sales price of the respective product.

[0000320193-22-000108:notes:49]
(2)Wearables, Home and Accessories net sales include sales of AirPods, Apple TV, Apple Watch, Beats products, HomePod mini and accessories.

[0000320193-22-000108:notes:50]
(3)Services net sales include sales from the Company’s advertising, AppleCare, cloud, digital content, payment and other services. Services net sales also include amortization of the deferred value of services bundled in the sales price of certain products.

[0000320193-22-000108:notes:51]
(4)Includes $7.5 billion of revenue recognized in 2022 that was included in deferred revenue as of September 25, 2021, $6.7 billion of revenue recognized in 2021 that was included in deferred revenue as of September 26, 2020, and $5.0 billion of revenue recognized in 2020 that was included in deferred revenue as of September 28, 2019.

[0000320193-22-000108:notes:52]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 11, “Segment Information and Geographic Data” for 2022, 2021 and 2020, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales in 2022 and 2021.

[0000320193-22-000108:notes:53]
As of September 24, 2022 and September 25, 2021, the Company had total deferred revenue of $12.4 billion and $11.9 billion, respectively. As of September 24, 2022, the Company expects 64% of total deferred revenue to be realized in less than a year, 27% within one-to-two years, 7% within two-to-three years and 2% in greater than three years.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000320193-22-000108:notes:54]
Financial Instruments
Cash, Cash Equivalents and Marketable Securities

[0000320193-22-000108:notes:55]
The following tables show the Company’s cash, cash equivalents and marketable securities by significant investment category as of September 24, 2022 and September 25, 2021 (in millions):

[0000320193-22-000108:notes:56]
|  | 2022 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | CurrentMarketableSecurities |  | Non-CurrentMarketableSecurities |
| Cash | $ | 18,546 |  |  | $ | — |  |  | $ | — |  |  | $ | 18,546 |  |  | $ | 18,546 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 2,929 |  |  | — |  |  | — |  |  | 2,929 |  |  | 2,929 |  |  | — |  |  | — |  |
| Mutual funds | 274 |  |  | — |  |  | (47) |  |  | 227 |  |  | — |  |  | 227 |  |  | — |  |
| Subtotal | 3,203 |  |  | — |  |  | (47) |  |  | 3,156 |  |  | 2,929 |  |  | 227 |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 25,134 |  |  | — |  |  | (1,725) |  |  | 23,409 |  |  | 338 |  |  | 5,091 |  |  | 17,980 |  |
| U.S. agency securities | 5,823 |  |  | — |  |  | (655) |  |  | 5,168 |  |  | — |  |  | 240 |  |  | 4,928 |  |
| Non-U.S. government securities | 16,948 |  |  | 2 |  |  | (1,201) |  |  | 15,749 |  |  | — |  |  | 8,806 |  |  | 6,943 |  |
| Certificates of deposit and time deposits | 2,067 |  |  | — |  |  | — |  |  | 2,067 |  |  | 1,805 |  |  | 262 |  |  | — |  |
| Commercial paper | 718 |  |  | — |  |  | — |  |  | 718 |  |  | 28 |  |  | 690 |  |  | — |  |
| Corporate debt securities | 87,148 |  |  | 9 |  |  | (7,707) |  |  | 79,450 |  |  | — |  |  | 9,023 |  |  | 70,427 |  |
| Municipal securities | 921 |  |  | — |  |  | (35) |  |  | 886 |  |  | — |  |  | 266 |  |  | 620 |  |
| Mortgage- and asset-backed securities | 22,553 |  |  | — |  |  | (2,593) |  |  | 19,960 |  |  | — |  |  | 53 |  |  | 19,907 |  |
| Subtotal | 161,312 |  |  | 11 |  |  | (13,916) |  |  | 147,407 |  |  | 2,171 |  |  | 24,431 |  |  | 120,805 |  |
| Total (3) | $ | 183,061 |  |  | $ | 11 |  |  | $ | (13,963) |  |  | $ | 169,109 |  |  | $ | 23,646 |  |  | $ | 24,658 |  |  | $ | 120,805 |  |

[0000320193-22-000108:notes:57]
|  | 2021 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | CurrentMarketableSecurities |  | Non-CurrentMarketableSecurities |
| Cash | $ | 17,305 |  |  | $ | — |  |  | $ | — |  |  | $ | 17,305 |  |  | $ | 17,305 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 9,608 |  |  | — |  |  | — |  |  | 9,608 |  |  | 9,608 |  |  | — |  |  | — |  |
| Mutual funds | 175 |  |  | 11 |  |  | (1) |  |  | 185 |  |  | — |  |  | 185 |  |  | — |  |
| Subtotal | 9,783 |  |  | 11 |  |  | (1) |  |  | 9,793 |  |  | 9,608 |  |  | 185 |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities | 1,527 |  |  | — |  |  | (564) |  |  | 963 |  |  | — |  |  | 963 |  |  | — |  |
| U.S. Treasury securities | 22,878 |  |  | 102 |  |  | (77) |  |  | 22,903 |  |  | 3,596 |  |  | 6,625 |  |  | 12,682 |  |
| U.S. agency securities | 8,949 |  |  | 2 |  |  | (64) |  |  | 8,887 |  |  | 1,775 |  |  | 1,930 |  |  | 5,182 |  |
| Non-U.S. government securities | 20,201 |  |  | 211 |  |  | (101) |  |  | 20,311 |  |  | 390 |  |  | 3,091 |  |  | 16,830 |  |
| Certificates of deposit and time deposits | 1,300 |  |  | — |  |  | — |  |  | 1,300 |  |  | 490 |  |  | 810 |  |  | — |  |
| Commercial paper | 2,639 |  |  | — |  |  | — |  |  | 2,639 |  |  | 1,776 |  |  | 863 |  |  | — |  |
| Corporate debt securities | 83,883 |  |  | 1,242 |  |  | (267) |  |  | 84,858 |  |  | — |  |  | 12,327 |  |  | 72,531 |  |
| Municipal securities | 967 |  |  | 14 |  |  | — |  |  | 981 |  |  | — |  |  | 130 |  |  | 851 |  |
| Mortgage- and asset-backed securities | 20,529 |  |  | 171 |  |  | (124) |  |  | 20,576 |  |  | — |  |  | 775 |  |  | 19,801 |  |
| Subtotal | 162,873 |  |  | 1,742 |  |  | (1,197) |  |  | 163,418 |  |  | 8,027 |  |  | 27,514 |  |  | 127,877 |  |
| Total (3) | $ | 189,961 |  |  | $ | 1,753 |  |  | $ | (1,198) |  |  | $ | 190,516 |  |  | $ | 34,940 |  |  | $ | 27,699 |  |  | $ | 127,877 |  |

[0000320193-22-000108:notes:58]
(1)Level 1 fair value estimates are based on quoted prices in active markets for identical assets or liabilities.

[0000320193-22-000108:notes:59]
(2)Level 2 fair value estimates are based on observable inputs other than quoted prices in active markets for identical assets and liabilities, quoted prices for identical or similar assets or liabilities in inactive markets, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities.

[0000320193-22-000108:notes:60]
(3)As of September 24, 2022 and September 25, 2021, total marketable securities included $12.7 billion and $17.9 billion, respectively, that were restricted from general use, related to the State Aid Decision (refer to Note 5, “Income Taxes”) and other agreements.

[0000320193-22-000108:notes:61]
The following table shows the fair value of the Company’s non-current marketable debt securities, by contractual maturity, as of September 24, 2022 (in millions):

[0000320193-22-000108:notes:62]
| Due after 1 year through 5 years | $ | 87,031 |  |
| Due after 5 years through 10 years | 16,429 |  |
| Due after 10 years | 17,345 |  |
| Total fair value | $ | 120,805 |  |

[0000320193-22-000108:notes:63]
The Company may use derivative instruments to partially offset its business exposure to foreign exchange and interest rate risk. However, the Company may choose not to hedge certain exposures for a variety of reasons including accounting considerations or the prohibitive economic cost of hedging particular exposures. There can be no assurance the hedges will offset more than a portion of the financial impact resulting from movements in foreign exchange or interest rates.

[0000320193-22-000108:notes:64]
Foreign Exchange Risk

[0000320193-22-000108:notes:65]
To protect gross margins from fluctuations in foreign currency exchange rates, the Company may enter into forward contracts, option contracts or other instruments, and may designate these instruments as cash flow hedges. The Company generally hedges portions of its forecasted foreign currency exposure associated with revenue and inventory purchases, typically for up to 12 months.

[0000320193-22-000108:notes:66]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in foreign currency exchange rates, the Company may enter into forward contracts, cross-currency swaps or other instruments. The Company designates these instruments as either cash flow or fair value hedges. As of September 24, 2022, the maximum length of time over which the Company is hedging its exposure to the variability in future cash flows for term debt–related foreign currency transactions is 20 years.

[0000320193-22-000108:notes:67]
The Company may also enter into derivative instruments that are not designated as accounting hedges to protect gross margins from certain fluctuations in foreign currency exchange rates, as well as to offset a portion of the foreign currency exchange gains and losses generated by the remeasurement of certain assets and liabilities denominated in non-functional currencies.

[0000320193-22-000108:notes:68]
Interest Rate Risk

[0000320193-22-000108:notes:69]
To protect the Company’s term debt or marketable securities from fluctuations in interest rates, the Company may enter into interest rate swaps, options or other instruments. The Company designates these instruments as either cash flow or fair value hedges.

[0000320193-22-000108:notes:70]
The notional amounts of the Company’s outstanding derivative instruments as of September 24, 2022 and September 25, 2021 were as follows (in millions):

[0000320193-22-000108:notes:71]
|  | 2022 |  | 2021 |
| Derivative instruments designated as accounting hedges: |  |  |  |
| Foreign exchange contracts | $ | 102,670 |  |  | $ | 76,475 |  |
| Interest rate contracts | $ | 20,125 |  |  | $ | 16,875 |  |
| Derivative instruments not designated as accounting hedges: |  |  |  |
| Foreign exchange contracts | $ | 185,381 |  |  | $ | 126,918 |  |

[0000320193-22-000108:notes:72]
The gross fair values of the Company’s derivative assets and liabilities as of September 24, 2022 were as follows (in millions):

[0000320193-22-000108:notes:73]
|  | 2022 |
|  | Fair Value ofDerivatives Designatedas Accounting Hedges |  | Fair Value ofDerivatives Not Designatedas Accounting Hedges |  | TotalFair Value |
| Derivative assets (1): |  |  |  |  |  |
| Foreign exchange contracts | $ | 4,317 |  |  | $ | 2,819 |  |  | $ | 7,136 |  |
| Derivative liabilities (2): |  |  |  |  |  |
| Foreign exchange contracts | $ | 2,205 |  |  | $ | 2,547 |  |  | $ | 4,752 |  |
| Interest rate contracts | $ | 1,367 |  |  | $ | — |  |  | $ | 1,367 |  |

[0000320193-22-000108:notes:74]
(1)Derivative assets are measured using Level 2 fair value inputs and are included in other current assets and other non-current assets in the Consolidated Balance Sheets.

[0000320193-22-000108:notes:75]
(2)Derivative liabilities are measured using Level 2 fair value inputs and are included in other current liabilities and other non-current liabilities in the Consolidated Balance Sheets.

[0000320193-22-000108:notes:76]
The derivative assets above represent the Company’s gross credit exposure if all counterparties failed to perform. To mitigate credit risk, the Company generally enters into collateral security arrangements that provide for collateral to be received or posted when the net fair values of certain derivatives fluctuate from contractually established thresholds. To further limit credit risk, the Company generally enters into master netting arrangements with the respective counterparties to the Company’s derivative contracts, under which the Company is allowed to settle transactions with a single net amount payable by one party to the other. As of September 24, 2022, the potential effects of these rights of set-off associated with the Company’s derivative contracts, including the effects of collateral, would be a reduction to both derivative assets and derivative liabilities of $7.8 billion, resulting in a net derivative asset of $412 million.

[0000320193-22-000108:notes:77]
The carrying amounts of the Company’s hedged items in fair value hedges as of September 24, 2022 and September 25, 2021 were as follows (in millions):

[0000320193-22-000108:notes:78]
|  | 2022 |  | 2021 |
| Hedged assets/(liabilities): |  |  |  |
| Current and non-current marketable securities | $ | 13,378 |  |  | $ | 15,954 |  |
| Current and non-current term debt | $ | (18,739) |  |  | $ | (17,857) |  |

[0000320193-22-000108:notes:79]
Accounts Receivable

[0000320193-22-000108:notes:80]
Trade Receivables

[0000320193-22-000108:notes:81]
The Company has considerable trade receivables outstanding with its third-party cellular network carriers, wholesalers, retailers, resellers, small and mid-sized businesses and education, enterprise and government customers. The Company generally does not require collateral from its customers; however, the Company will require collateral or third-party credit support in certain instances to limit credit risk. In addition, when possible, the Company attempts to limit credit risk on trade receivables with credit insurance for certain customers or by requiring third-party financing, loans or leases to support credit exposure. These credit-financing arrangements are directly between the third-party financing company and the end customer. As such, the Company generally does not assume any recourse or credit risk sharing related to any of these arrangements.

[0000320193-22-000108:notes:82]
As of September 24, 2022, the Company had one customer that represented 10% or more of total trade receivables, which accounted for 10%. The Company’s cellular network carriers accounted for 44% and 42% of total trade receivables as of September 24, 2022 and September 25, 2021, respectively.

[0000320193-22-000108:notes:83]
Vendor Non-Trade Receivables

[0000320193-22-000108:notes:84]
The Company has non-trade receivables from certain of its manufacturing vendors resulting from the sale of components to these vendors who manufacture subassemblies or assemble final products for the Company. The Company purchases these components directly from suppliers. As of September 24, 2022, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 54% and 13%. As of September 25, 2021, the Company had three vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 52%, 11% and 11%.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000320193-22-000108:notes:85]
Consolidated Financial Statement Details
The following tables show the Company’s consolidated financial statement details as of September 24, 2022 and September 25, 2021 (in millions):

[0000320193-22-000108:notes:86]
Property, Plant and Equipment, Net

[0000320193-22-000108:notes:87]
|  | 2022 |  | 2021 |
| Land and buildings | $ | 22,126 |  |  | $ | 20,041 |  |
| Machinery, equipment and internal-use software | 81,060 |  |  | 78,659 |  |
| Leasehold improvements | 11,271 |  |  | 11,023 |  |
| Gross property, plant and equipment | 114,457 |  |  | 109,723 |  |
| Accumulated depreciation and amortization | (72,340) |  |  | (70,283) |  |
| Total property, plant and equipment, net | $ | 42,117 |  |  | $ | 39,440 |  |

[0000320193-22-000108:notes:88]
Other Non-Current Liabilities

[0000320193-22-000108:notes:89]
|  | 2022 |  | 2021 |
| Long-term taxes payable | $ | 16,657 |  |  | $ | 24,689 |  |
| Other non-current liabilities | 32,485 |  |  | 28,636 |  |
| Total other non-current liabilities | $ | 49,142 |  |  | $ | 53,325 |  |

[0000320193-22-000108:notes:90]
Other Income/(Expense), Net

[0000320193-22-000108:notes:91]
The following table shows the detail of OI&E for 2022, 2021 and 2020 (in millions):

[0000320193-22-000108:notes:92]
|  | 2022 |  | 2021 |  | 2020 |
| Interest and dividend income | $ | 2,825 |  |  | $ | 2,843 |  |  | $ | 3,763 |  |
| Interest expense | (2,931) |  |  | (2,645) |  |  | (2,873) |  |
| Other income/(expense), net | (228) |  |  | 60 |  |  | (87) |  |
| Total other income/(expense), net | $ | (334) |  |  | $ | 258 |  |  | $ | 803 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000320193-22-000108:notes:93]
Income Taxes
Provision for Income Taxes and Effective Tax Rate

[0000320193-22-000108:notes:94]
The provision for income taxes for 2022, 2021 and 2020, consisted of the following (in millions):

[0000320193-22-000108:notes:95]
|  | 2022 |  | 2021 |  | 2020 |
| Federal: |  |  |  |  |  |
| Current | $ | 7,890 |  |  | $ | 8,257 |  |  | $ | 6,306 |  |
| Deferred | (2,265) |  |  | (7,176) |  |  | (3,619) |  |
| Total | 5,625 |  |  | 1,081 |  |  | 2,687 |  |
| State: |  |  |  |  |  |
| Current | 1,519 |  |  | 1,620 |  |  | 455 |  |
| Deferred | 84 |  |  | (338) |  |  | 21 |  |
| Total | 1,603 |  |  | 1,282 |  |  | 476 |  |
| Foreign: |  |  |  |  |  |
| Current | 8,996 |  |  | 9,424 |  |  | 3,134 |  |
| Deferred | 3,076 |  |  | 2,740 |  |  | 3,383 |  |
| Total | 12,072 |  |  | 12,164 |  |  | 6,517 |  |
| Provision for income taxes | $ | 19,300 |  |  | $ | 14,527 |  |  | $ | 9,680 |  |

[0000320193-22-000108:notes:96]
The foreign provision for income taxes is based on foreign pretax earnings of $71.3 billion, $68.7 billion and $38.1 billion in 2022, 2021 and 2020, respectively.

[0000320193-22-000108:notes:97]
A reconciliation of the provision for income taxes to the amount computed by applying the statutory federal income tax rate (21% in 2022, 2021 and 2020) to income before provision for income taxes for 2022, 2021 and 2020, is as follows (dollars in millions):

[0000320193-22-000108:notes:98]
|  | 2022 |  | 2021 |  | 2020 |
| Computed expected tax | $ | 25,012 |  |  | $ | 22,933 |  |  | $ | 14,089 |  |
| State taxes, net of federal effect | 1,518 |  |  | 1,151 |  |  | 423 |  |
| Impacts of the Act | 542 |  |  | — |  |  | (582) |  |
| Earnings of foreign subsidiaries | (4,366) |  |  | (4,715) |  |  | (2,534) |  |
| Foreign-derived intangible income deduction | (296) |  |  | (1,372) |  |  | (169) |  |
| Research and development credit, net | (1,153) |  |  | (1,033) |  |  | (728) |  |
| Excess tax benefits from equity awards | (1,871) |  |  | (2,137) |  |  | (930) |  |
| Other | (86) |  |  | (300) |  |  | 111 |  |
| Provision for income taxes | $ | 19,300 |  |  | $ | 14,527 |  |  | $ | 9,680 |  |
| Effective tax rate | 16.2 | % |  | 13.3 | % |  | 14.4 | % |

[0000320193-22-000108:notes:99]
Deferred Tax Assets and Liabilities

[0000320193-22-000108:notes:100]
As of September 24, 2022 and September 25, 2021, the significant components of the Company’s deferred tax assets and liabilities were (in millions):

[0000320193-22-000108:notes:101]
|  | 2022 |  | 2021 |
| Deferred tax assets: |  |  |  |
| Amortization and depreciation | $ | 1,496 |  |  | $ | 5,575 |  |
| Accrued liabilities and other reserves | 6,515 |  |  | 5,895 |  |
| Lease liabilities | 2,400 |  |  | 2,406 |  |
| Deferred revenue | 5,742 |  |  | 5,399 |  |
| Unrealized losses | 2,913 |  |  | 53 |  |
| Tax credit carryforwards | 6,962 |  |  | 4,262 |  |
| Other | 1,596 |  |  | 1,639 |  |
| Total deferred tax assets | 27,624 |  |  | 25,229 |  |
| Less: Valuation allowance | (7,530) |  |  | (4,903) |  |
| Total deferred tax assets, net | 20,094 |  |  | 20,326 |  |
| Deferred tax liabilities: |  |  |  |
| Minimum tax on foreign earnings | 1,983 |  |  | 4,318 |  |
| Right-of-use assets | 2,163 |  |  | 2,167 |  |
| Unrealized gains | 942 |  |  | 203 |  |
| Other | 469 |  |  | 565 |  |
| Total deferred tax liabilities | 5,557 |  |  | 7,253 |  |
| Net deferred tax assets | $ | 14,537 |  |  | $ | 13,073 |  |

[0000320193-22-000108:notes:102]
As of September 24, 2022, the Company had $4.4 billion in foreign tax credit carryforwards in Ireland and $2.5 billion in California R&D credit carryforwards, both of which can be carried forward indefinitely. A valuation allowance has been recorded for the credit carryforwards and a portion of other temporary differences.

[0000320193-22-000108:notes:103]
Uncertain Tax Positions

[0000320193-22-000108:notes:104]
As of September 24, 2022, the total amount of gross unrecognized tax benefits was $16.8 billion, of which $8.0 billion, if recognized, would impact the Company’s effective tax rate. As of September 25, 2021, the total amount of gross unrecognized tax benefits was $15.5 billion, of which $6.6 billion, if recognized, would have impacted the Company’s effective tax rate.

[0000320193-22-000108:notes:105]
The aggregate change in the balance of gross unrecognized tax benefits, which excludes interest and penalties, for 2022, 2021 and 2020, is as follows (in millions):

[0000320193-22-000108:notes:106]
|  | 2022 |  | 2021 |  | 2020 |
| Beginning balances | $ | 15,477 |  |  | $ | 16,475 |  |  | $ | 15,619 |  |
| Increases related to tax positions taken during a prior year | 2,284 |  |  | 816 |  |  | 454 |  |
| Decreases related to tax positions taken during a prior year | (1,982) |  |  | (1,402) |  |  | (791) |  |
| Increases related to tax positions taken during the current year | 1,936 |  |  | 1,607 |  |  | 1,347 |  |
| Decreases related to settlements with taxing authorities | (28) |  |  | (1,838) |  |  | (85) |  |
| Decreases related to expiration of the statute of limitations | (929) |  |  | (181) |  |  | (69) |  |
| Ending balances | $ | 16,758 |  |  | $ | 15,477 |  |  | $ | 16,475 |  |

[0000320193-22-000108:notes:107]
The Company is subject to taxation and files income tax returns in the U.S. federal jurisdiction and many state and foreign jurisdictions. Tax years after 2017 for the U.S. federal jurisdiction, and after 2014 in certain major foreign jurisdictions, remain subject to examination. Although the timing of resolution and/or closure of examinations is not certain, the Company believes it is reasonably possible that its gross unrecognized tax benefits could decrease in the next 12 months by as much as $4.8 billion.

[0000320193-22-000108:notes:108]
European Commission State Aid Decision

[0000320193-22-000108:notes:109]
On August 30, 2016, the European Commission announced its decision that Ireland granted state aid to the Company by providing tax opinions in 1991 and 2007 concerning the tax allocation of profits of the Irish branches of two subsidiaries of the Company (the “State Aid Decision”). The State Aid Decision ordered Ireland to calculate and recover additional taxes from the Company for the period June 2003 through December 2014. Irish legislative changes, effective as of January 2015, eliminated the application of the tax opinions from that date forward. The recovery amount was calculated to be €13.1 billion, plus interest of €1.2 billion. The Company and Ireland appealed the State Aid Decision to the General Court of the Court of Justice of the European Union (the “General Court”). On July 15, 2020, the General Court annulled the State Aid Decision. On September 25, 2020, the European Commission appealed the General Court’s decision to the European Court of Justice. The Company believes that any incremental Irish corporate income taxes potentially due related to the State Aid Decision would be creditable against U.S. taxes, subject to any foreign tax credit limitations in the Act.

[0000320193-22-000108:notes:110]
On an annual basis, the Company may request approval from the Irish Minister for Finance to reduce the recovery amount for certain taxes paid to other countries. As of September 24, 2022, the adjusted recovery amount was €12.7 billion, excluding interest. The adjusted recovery amount plus interest is funded into escrow, where it will remain restricted from general use pending the conclusion of all legal proceedings. Refer to the Cash, Cash Equivalents and Marketable Securities section of Note 3, “Financial Instruments” for more information.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000320193-22-000108:notes:111]
Leases
The Company has lease arrangements for certain equipment and facilities, including corporate, data center, manufacturing and retail space. These leases typically have original terms not exceeding 10 years and generally contain multiyear renewal options, some of which are reasonably certain of exercise.

[0000320193-22-000108:notes:112]
Payments under the Company’s lease arrangements may be fixed or variable, and variable lease payments are primarily based on purchases of output of the underlying leased assets. Lease costs associated with fixed payments on the Company’s operating leases were $1.9 billion, $1.7 billion and $1.5 billion for 2022, 2021 and 2020, respectively. Lease costs associated with variable payments on the Company’s leases were $14.9 billion, $12.9 billion and $9.3 billion for 2022, 2021 and 2020, respectively.

[0000320193-22-000108:notes:113]
The Company made $1.8 billion, $1.4 billion and $1.5 billion of fixed cash payments related to operating leases in 2022, 2021 and 2020, respectively. Noncash activities involving right-of-use (“ROU”) assets obtained in exchange for lease liabilities were $2.8 billion for 2022, $3.3 billion for 2021 and $10.5 billion for 2020, including the impact of adopting the Financial Accounting Standards Board’s Accounting Standards Update No. 2016-02, Leases (Topic 842) in the first quarter of 2020.

[0000320193-22-000108:notes:114]
The following table shows ROU assets and lease liabilities, and the associated financial statement line items, as of September 24, 2022 and September 25, 2021 (in millions):

[0000320193-22-000108:notes:115]
| Lease-Related Assets and Liabilities |  | Financial Statement Line Items |  | 2022 |  | 2021 |  |  |
| Right-of-use assets: |  |  |  |  |  |  |  |  |
| Operating leases |  | Other non-current assets |  | $ | 10,417 |  |  | $ | 10,087 |  |  |  |
| Finance leases |  | Property, plant and equipment, net |  | 952 |  |  | 861 |  |  |  |
| Total right-of-use assets |  |  |  | $ | 11,369 |  |  | $ | 10,948 |  |  |  |
| Lease liabilities: |  |  |  |  |  |  |  |  |
| Operating leases |  | Other current liabilities |  | $ | 1,534 |  |  | $ | 1,449 |  |  |  |
|  |  | Other non-current liabilities |  | 9,936 |  |  | 9,506 |  |  |  |
| Finance leases |  | Other current liabilities |  | 129 |  |  | 79 |  |  |  |
|  |  | Other non-current liabilities |  | 812 |  |  | 769 |  |  |  |
| Total lease liabilities |  |  |  | $ | 12,411 |  |  | $ | 11,803 |  |  |  |

[0000320193-22-000108:notes:116]
Lease liability maturities as of September 24, 2022, are as follows (in millions):

[0000320193-22-000108:notes:117]
|  | OperatingLeases |  | FinanceLeases |  | Total |
| 2023 | $ | 1,758 |  |  | $ | 155 |  |  | $ | 1,913 |  |
| 2024 | 1,742 |  |  | 130 |  |  | 1,872 |  |
| 2025 | 1,677 |  |  | 81 |  |  | 1,758 |  |
| 2026 | 1,382 |  |  | 48 |  |  | 1,430 |  |
| 2027 | 1,143 |  |  | 34 |  |  | 1,177 |  |
| Thereafter | 5,080 |  |  | 906 |  |  | 5,986 |  |
| Total undiscounted liabilities | 12,782 |  |  | 1,354 |  |  | 14,136 |  |
| Less: Imputed interest | (1,312) |  |  | (413) |  |  | (1,725) |  |
| Total lease liabilities | $ | 11,470 |  |  | $ | 941 |  |  | $ | 12,411 |  |

[0000320193-22-000108:notes:118]
The weighted-average remaining lease term related to the Company’s lease liabilities as of September 24, 2022 and September 25, 2021 was 10.1 years and 10.8 years, respectively. The discount rate related to the Company’s lease liabilities as of September 24, 2022 and September 25, 2021 was 2.3% and 2.0%, respectively.

[0000320193-22-000108:notes:119]
As of September 24, 2022, the Company had $1.2 billion of future payments under additional leases, primarily for corporate facilities and retail space, that had not yet commenced. These leases will commence between 2023 and 2026, with lease terms ranging from less than 1 year to 21 years.


## us-gaap:DebtDisclosureTextBlock

[0000320193-22-000108:notes:120]
Debt
Commercial Paper and Repurchase Agreements

[0000320193-22-000108:notes:121]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of September 24, 2022 and September 25, 2021, the Company had $10.0 billion and $6.0 billion of Commercial Paper outstanding, respectively, with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 2.31% and 0.06% as of September 24, 2022 and September 25, 2021, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for 2022, 2021 and 2020 (in millions):

[0000320193-22-000108:notes:122]
|  | 2022 |  | 2021 |  | 2020 |
| Maturities 90 days or less: |  |  |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | 5,264 |  |  | $ | (357) |  |  | $ | 100 |  |
| Maturities greater than 90 days: |  |  |  |  |  |
| Proceeds from commercial paper | 5,948 |  |  | 7,946 |  |  | 6,185 |  |
| Repayments of commercial paper | (7,257) |  |  | (6,567) |  |  | (7,248) |  |
| Proceeds from/(Repayments of) commercial paper, net | (1,309) |  |  | 1,379 |  |  | (1,063) |  |
| Total proceeds from/(repayments of) commercial paper, net | $ | 3,955 |  |  | $ | 1,022 |  |  | $ | (963) |  |

[0000320193-22-000108:notes:123]
In 2020, the Company entered into agreements to sell certain of its marketable securities with a promise to repurchase the securities at a specified time and amount (“Repos”). Due to the Company’s continuing involvement with the marketable securities, the Company accounted for its Repos as collateralized borrowings. The Company entered into $5.2 billion of Repos during 2020, all of which had been settled as of September 26, 2020.

[0000320193-22-000108:notes:124]
Term Debt

[0000320193-22-000108:notes:125]
The Company has outstanding fixed-rate notes with varying maturities (collectively the “Notes”). The Notes are senior unsecured obligations and interest is payable in arrears. The following table provides a summary of the Company’s term debt as of September 24, 2022 and September 25, 2021:

[0000320193-22-000108:notes:126]
|  | Maturities(calendar year) |  | 2022 |  | 2021 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 – 2021 debt issuances: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | $ | — |  |  |  |  | $ | 1,750 |  |  | 0.48% – 0.63% |
| Fixed-rate 0.000% – 4.650% notes | 2022 – 2061 |  | 106,324 |  |  | 0.03% – 4.78% |  | 116,313 |  |  | 0.03% – 4.78% |
| Fourth quarter 2022 debt issuance: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 3.250% – 4.100% notes | 2029 – 2062 |  | 5,500 |  |  | 3.27% – 4.12% |  | — |  |  |  |
| Total term debt |  |  | 111,824 |  |  |  |  | 118,063 |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  | (374) |  |  |  |  | (380) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (1,363) |  |  |  |  | 1,036 |  |  |  |
| Less: Current portion of term debt |  |  | (11,128) |  |  |  |  | (9,613) |  |  |  |
| Total non-current portion of term debt |  |  | $ | 98,959 |  |  |  |  | $ | 109,106 |  |  |  |

[0000320193-22-000108:notes:127]
To manage interest rate risk on certain of its U.S. dollar–denominated fixed-rate notes, the Company has entered into interest rate swaps to effectively convert the fixed interest rates to floating interest rates on a portion of these notes. Additionally, to manage foreign currency risk on certain of its foreign currency–denominated notes, the Company has entered into foreign currency swaps to effectively convert these notes to U.S. dollar–denominated notes.

[0000320193-22-000108:notes:128]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $2.8 billion, $2.6 billion and $2.8 billion of interest expense on its term debt for 2022, 2021 and 2020, respectively.

[0000320193-22-000108:notes:129]
The future principal payments for the Company’s Notes as of September 24, 2022, are as follows (in millions):

[0000320193-22-000108:notes:130]
| 2023 | $ | 11,139 |  |
| 2024 | 9,910 |  |
| 2025 | 10,645 |  |
| 2026 | 11,209 |  |
| 2027 | 9,631 |  |
| Thereafter | 59,290 |  |
| Total term debt | $ | 111,824 |  |

[0000320193-22-000108:notes:131]
As of September 24, 2022 and September 25, 2021, the fair value of the Company’s Notes, based on Level 2 inputs, was $98.8 billion and $125.3 billion, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000320193-22-000108:notes:132]
Shareholders’ Equity
Share Repurchase Program

[0000320193-22-000108:notes:133]
During 2022, the Company repurchased 569 million shares of its common stock for $90.2 billion under a share repurchase program authorized by the Board of Directors (the “Program”). The Program does not obligate the Company to acquire a minimum amount of shares. Under the Program, shares may be repurchased in privately negotiated and/or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended.

[0000320193-22-000108:notes:134]
Shares of Common Stock

[0000320193-22-000108:notes:135]
The following table shows the changes in shares of common stock for 2022, 2021 and 2020 (in thousands):

[0000320193-22-000108:notes:136]
|  | 2022 |  | 2021 |  | 2020 |
| Common stock outstanding, beginning balances | 16,426,786 |  |  | 16,976,763 |  |  | 17,772,945 |  |
| Common stock repurchased | (568,589) |  |  | (656,340) |  |  | (917,270) |  |
| Common stock issued, net of shares withheld for employee taxes | 85,228 |  |  | 106,363 |  |  | 121,088 |  |
| Common stock outstanding, ending balances | 15,943,425 |  |  | 16,426,786 |  |  | 16,976,763 |  |


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000320193-22-000108:notes:137]
Benefit Plans
2022 Employee Stock Plan

[0000320193-22-000108:notes:138]
In the second quarter of 2022, shareholders approved the Apple Inc. 2022 Employee Stock Plan (the “2022 Plan”), which provides for broad-based equity grants to employees, including executive officers, and permits the granting of restricted stock units (“RSUs”), stock grants, performance-based awards, stock options and stock appreciation rights. RSUs granted under the 2022 Plan generally vest over four years, based on continued employment, and are settled upon vesting in shares of the Company’s common stock on a one-for-one basis. RSUs granted under the 2022 Plan reduce the number of shares available for grant under the plan by a factor of two times the number of RSUs granted. RSUs canceled and shares withheld to satisfy tax withholding obligations increase the number of shares available for grant under the 2022 Plan utilizing a factor of two times the number of RSUs canceled or shares withheld. All RSUs granted under the 2022 Plan have dividend equivalent rights (“DERs”), which entitle holders of RSUs to the same dividend value per share as holders of common stock. DERs are subject to the same vesting and other terms and conditions as the underlying RSUs. A maximum of approximately 1.3 billion shares were authorized for issuance pursuant to 2022 Plan awards at the time the plan was approved on March 4, 2022.

[0000320193-22-000108:notes:139]
2014 Employee Stock Plan

[0000320193-22-000108:notes:140]
The Apple Inc. 2014 Employee Stock Plan (the “2014 Plan”) is a shareholder-approved plan that provided for broad-based equity grants to employees, including executive officers. The 2014 Plan permitted the granting of substantially the same types of equity awards with substantially the same terms as the 2022 Plan. The 2014 Plan also permitted the granting of cash bonus awards. In the third quarter of 2022, the Company terminated the authority to grant new awards under the 2014 Plan.

[0000320193-22-000108:notes:141]
Apple Inc. Non-Employee Director Stock Plan

[0000320193-22-000108:notes:142]
The Apple Inc. Non-Employee Director Stock Plan (the “Director Plan”) is a shareholder-approved plan that (i) permits the Company to grant awards of RSUs or stock options to the Company’s non-employee directors, (ii) provides for automatic initial grants of RSUs upon a non-employee director joining the Board of Directors and automatic annual grants of RSUs at each annual meeting of shareholders, and (iii) permits the Board of Directors to prospectively change the value and relative mixture of stock options and RSUs for the initial and annual award grants and the methodology for determining the number of shares of the Company’s common stock subject to these grants, in each case within the limits set forth in the Director Plan and without further shareholder approval. RSUs granted under the Director Plan reduce the number of shares available for grant under the plan by a factor of two times the number of RSUs granted. The Director Plan expires on November 12, 2027. All RSUs granted under the Director Plan are entitled to DERs, which are subject to the same vesting and other terms and conditions as the underlying RSUs. A maximum of approximately 45 million shares (split-adjusted) were authorized for issuance pursuant to Director Plan awards at the time the plan was last amended on November 9, 2021.

[0000320193-22-000108:notes:143]
Employee Stock Purchase Plan

[0000320193-22-000108:notes:144]
The Employee Stock Purchase Plan (the “Purchase Plan”) is a shareholder-approved plan under which substantially all employees may voluntarily enroll to purchase the Company’s common stock through payroll deductions at a price equal to 85% of the lower of the fair market values of the stock as of the beginning or the end of six-month offering periods. An employee’s payroll deductions under the Purchase Plan are limited to 10% of the employee’s eligible compensation and employees may not purchase more than $25,000 of stock during any calendar year. A maximum of approximately 230 million shares (split-adjusted) were authorized for issuance under the Purchase Plan at the time the plan was last amended and restated on March 10, 2015.

[0000320193-22-000108:notes:145]
401(k) Plan

[0000320193-22-000108:notes:146]
The Company’s 401(k) Plan is a tax-qualified deferred compensation arrangement under Section 401(k) of the Internal Revenue Code. Under the 401(k) Plan, participating U.S. employees may contribute a portion of their eligible earnings, subject to applicable U.S. Internal Revenue Service and plan limits. The Company matches 50% to 100% of each employee’s contributions, depending on length of service, up to a maximum of 6% of the employee’s eligible earnings.

[0000320193-22-000108:notes:147]
Restricted Stock Units

[0000320193-22-000108:notes:148]
A summary of the Company’s RSU activity and related information for 2022, 2021 and 2020, is as follows:

[0000320193-22-000108:notes:149]
|  | Number ofRSUs(in thousands) |  | Weighted-AverageGrant Date FairValue Per RSU |  | AggregateFair Value(in millions) |
| Balance as of September 28, 2019 | 326,068 |  |  | $ | 42.30 |  |  |  |
| RSUs granted | 156,800 |  |  | $ | 59.20 |  |  |  |
| RSUs vested | (157,743) |  |  | $ | 40.29 |  |  |  |
| RSUs canceled | (14,347) |  |  | $ | 48.07 |  |  |  |
| Balance as of September 26, 2020 | 310,778 |  |  | $ | 51.58 |  |  |  |
| RSUs granted | 89,363 |  |  | $ | 116.33 |  |  |  |
| RSUs vested | (145,766) |  |  | $ | 50.71 |  |  |  |
| RSUs canceled | (13,948) |  |  | $ | 68.95 |  |  |  |
| Balance as of September 25, 2021 | 240,427 |  |  | $ | 75.16 |  |  |  |
| RSUs granted | 91,674 |  |  | $ | 150.70 |  |  |  |
| RSUs vested | (115,861) |  |  | $ | 72.12 |  |  |  |
| RSUs canceled | (14,739) |  |  | $ | 99.77 |  |  |  |
| Balance as of September 24, 2022 | 201,501 |  |  | $ | 109.48 |  |  | $ | 30,312 |  |

[0000320193-22-000108:notes:150]
The fair value as of the respective vesting dates of RSUs was $18.2 billion, $19.0 billion and $10.8 billion for 2022, 2021 and 2020, respectively. The majority of RSUs that vested in 2022, 2021 and 2020 were net share settled such that the Company withheld shares with a value equivalent to the employees’ obligation for the applicable income and other employment taxes, and remitted the cash to the appropriate taxing authorities. The total shares withheld were approximately 41 million, 53 million and 56 million for 2022, 2021 and 2020, respectively, and were based on the value of the RSUs on their respective vesting dates as determined by the Company’s closing stock price. Total payments to taxing authorities for employees’ tax obligations were $6.4 billion, $6.8 billion and $3.9 billion in 2022, 2021 and 2020, respectively.

[0000320193-22-000108:notes:151]
The following table shows share-based compensation expense and the related income tax benefit included in the Consolidated Statements of Operations for 2022, 2021 and 2020 (in millions):

[0000320193-22-000108:notes:152]
|  | 2022 |  | 2021 |  | 2020 |
| Share-based compensation expense | $ | 9,038 |  |  | $ | 7,906 |  |  | $ | 6,829 |  |
| Income tax benefit related to share-based compensation expense | $ | (4,002) |  |  | $ | (4,056) |  |  | $ | (2,476) |  |

[0000320193-22-000108:notes:153]
As of September 24, 2022, the total unrecognized compensation cost related to outstanding RSUs and stock options was $16.7 billion, which the Company expects to recognize over a weighted-average period of 2.6 years.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000320193-22-000108:notes:154]
Commitments and Contingencies
Concentrations in the Available Sources of Supply of Materials and Product

[0000320193-22-000108:notes:155]
Although most components essential to the Company’s business are generally available from multiple sources, certain components are currently obtained from single or limited sources. The Company also competes for various components with other participants in the markets for smartphones, personal computers, tablets, wearables and accessories. Therefore, many components used by the Company, including those that are available from multiple sources, are at times subject to industry-wide shortage and significant commodity pricing fluctuations.

[0000320193-22-000108:notes:156]
The Company uses some custom components that are not commonly used by its competitors, and new products introduced by the Company often utilize custom components available from only one source. When a component or product uses new technologies, initial capacity constraints may exist until the suppliers’ yields have matured or their manufacturing capacities have increased. The continued availability of these components at acceptable prices, or at all, may be affected if suppliers decide to concentrate on the production of common components instead of components customized to meet the Company’s requirements.

[0000320193-22-000108:notes:157]
Substantially all of the Company’s hardware products are manufactured by outsourcing partners that are located primarily in Asia, with some Mac computers manufactured in the U.S. and Ireland.

[0000320193-22-000108:notes:158]
Unconditional Purchase Obligations

[0000320193-22-000108:notes:159]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of payments for supplier arrangements, internet services and content creation. Future payments under noncancelable unconditional purchase obligations with a remaining term in excess of one year as of September 24, 2022, are as follows (in millions):

[0000320193-22-000108:notes:160]
| 2023 | $ | 13,488 |  |
| 2024 | 4,876 |  |
| 2025 | 1,418 |  |
| 2026 | 6,780 |  |
| 2027 | 312 |  |
| Thereafter | 412 |  |
| Total | $ | 27,286 |  |

[0000320193-22-000108:notes:161]
Contingencies

[0000320193-22-000108:notes:162]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully resolved. The outcome of litigation is inherently uncertain. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss greater than a recorded accrual, concerning loss contingencies for asserted legal and other claims.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000320193-22-000108:notes:163]
Segment Information and Geographic Data
The following table shows information by reportable segment for 2022, 2021 and 2020 (in millions):

[0000320193-22-000108:notes:164]
|  | 2022 |  | 2021 |  | 2020 |
| Americas: |  |  |  |  |  |
| Net sales | $ | 169,658 |  |  | $ | 153,306 |  |  | $ | 124,556 |  |
| Operating income | $ | 62,683 |  |  | $ | 53,382 |  |  | $ | 37,722 |  |
| Europe: |  |  |  |  |  |
| Net sales | $ | 95,118 |  |  | $ | 89,307 |  |  | $ | 68,640 |  |
| Operating income | $ | 35,233 |  |  | $ | 32,505 |  |  | $ | 22,170 |  |
| Greater China: |  |  |  |  |  |
| Net sales | $ | 74,200 |  |  | $ | 68,366 |  |  | $ | 40,308 |  |
| Operating income | $ | 31,153 |  |  | $ | 28,504 |  |  | $ | 15,261 |  |
| Japan: |  |  |  |  |  |
| Net sales | $ | 25,977 |  |  | $ | 28,482 |  |  | $ | 21,418 |  |
| Operating income | $ | 12,257 |  |  | $ | 12,798 |  |  | $ | 9,279 |  |
| Rest of Asia Pacific: |  |  |  |  |  |
| Net sales | $ | 29,375 |  |  | $ | 26,356 |  |  | $ | 19,593 |  |
| Operating income | $ | 11,569 |  |  | $ | 9,817 |  |  | $ | 6,808 |  |

[0000320193-22-000108:notes:165]
A reconciliation of the Company’s segment operating income to the Consolidated Statements of Operations for 2022, 2021 and 2020 is as follows (in millions):

[0000320193-22-000108:notes:166]
|  | 2022 |  | 2021 |  | 2020 |
| Segment operating income | $ | 152,895 |  |  | $ | 137,006 |  |  | $ | 91,240 |  |
| Research and development expense | (26,251) |  |  | (21,914) |  |  | (18,752) |  |
| Other corporate expenses, net | (7,207) |  |  | (6,143) |  |  | (6,200) |  |
| Total operating income | $ | 119,437 |  |  | $ | 108,949 |  |  | $ | 66,288 |  |

[0000320193-22-000108:notes:167]
The U.S. and China were the only countries that accounted for more than 10% of the Company’s net sales in 2022, 2021 and 2020. Net sales for 2022, 2021 and 2020 and long-lived assets as of September 24, 2022 and September 25, 2021 were as follows (in millions):

[0000320193-22-000108:notes:168]
|  | 2022 |  | 2021 |  | 2020 |
| Net sales: |  |  |  |  |  |
| U.S. | $ | 147,859 |  |  | $ | 133,803 |  |  | $ | 109,197 |  |
| China (1) | 74,200 |  |  | 68,366 |  |  | 40,308 |  |
| Other countries | 172,269 |  |  | 163,648 |  |  | 125,010 |  |
| Total net sales | $ | 394,328 |  |  | $ | 365,817 |  |  | $ | 274,515 |  |

[0000320193-22-000108:notes:169]
|  | 2022 |  | 2021 |
| Long-lived assets: |  |  |  |
| U.S. | $ | 31,119 |  |  | $ | 28,203 |  |
| China (1) | 7,260 |  |  | 7,521 |  |
| Other countries | 3,738 |  |  | 3,716 |  |
| Total long-lived assets | $ | 42,117 |  |  | $ | 39,440 |  |

[0000320193-22-000108:notes:170]
(1)China includes Hong Kong and Taiwan. Long-lived assets located in China consist primarily of assets related to product manufacturing, retail stores and related infrastructure.
