# AAPL note change history — 0001193125-16-439878 → 0001193125-16-559625


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-04-27):
[0001193125-16-559625:note_history:1]
The following table shows changes in the
 Company’s accrued warranties and related costs for the three-
 and six-month periods ended March 26, 2016 and March 28,
 2015 (in millions):
  (was, 2016-01-27, similarity 0.8963):
[0001193125-16-439878:note_history:1]
The following table shows changes in the
 Company’s accrued warranties and related costs for the three
 months ended December 26, 2015 and December 27, 2014 (in
 millions):

- changed (2016-04-27):
[0001193125-16-559625:note_history:2]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 26, 2016 |  |  | March 28, 2015 |  |  | March 26, 2016 |  |  | March 28, 2015 |  |
| Beginning accrued warranty and related costs |  | $ | 5,236 |  |  | $ | 5,195 |  |  | $ | 4,780 |  |  | $ | 4,159 |  |
| Cost of warranty claims |  |  | (1,128 | ) |  |  | (1,030 | ) |  |  | (2,397 | ) |  |  | (2,074 | ) |
| Accruals for product warranty |  |  | 877 |  |  |  | 978 |  |  |  | 2,602 |  |  |  | 3,058 |  |
| Ending accrued warranty and related costs |  | $ | 4,985 |  |  | $ | 5,143 |  |  | $ | 4,985 |  |  | $ | 5,143 |  |
  (was, 2016-01-27, similarity 0.7439):
[0001193125-16-439878:note_history:2]
|  |  | Three Months Ended |  |
|  |  | December 26, 2015 |  |  | December 27, 2014 |  |
| Beginning accrued warranty and related costs |  | $ | 4,780 |  |  | $ | 4,159 |  |
| Cost of warranty claims |  |  | (1,269 | ) |  |  | (1,044 | ) |
| Accruals for product warranty |  |  | 1,725 |  |  |  | 2,080 |  |
| Ending accrued warranty and related costs |  | $ | 5,236 |  |  | $ | 5,195 |  |

- changed (2016-04-27):
[0001193125-16-559625:note_history:3]
The Company leases various equipment and
 facilities, including retail space, under noncancelable operating
 lease arrangements. The major facility leases are typically for
 terms not exceeding 10 years and generally contain multi-year
 renewal options. As of March 26, 2016, the Company had a total
 of 475 retail stores. Leases for retail space are for terms ranging
 from five to 20 years, the majority of which are for 10 years, and
 often contain multi-year renewal options. As of March 26,
 2016, the Company’s total future minimum lease payments under
 noncancelable operating leases were $6.8 billion, of which $3.9
 billion related to leases for retail space.
  (was, 2016-01-27, similarity 0.9797):
[0001193125-16-439878:note_history:3]
The Company leases various equipment and
 facilities, including retail space, under noncancelable operating
 lease arrangements. The major facility leases are typically for
 terms not exceeding 10 years and generally contain multi-year
 renewal options. As of December 26, 2015, the Company had a
 total of 469 retail stores. Leases for retail space are for terms
 ranging from five to 20 years, the majority of which are for 10
 years, and often contain multi-year renewal options. As of
 December 26, 2015, the Company’s total future minimum
 lease payments under noncancelable operating leases were $6.6
 billion, of which $3.7 billion related to leases for retail
 space.

- changed (2016-04-27):
[0001193125-16-559625:note_history:4]
On August 24, 2012, a jury returned a verdict
 awarding the Company $1.05 billion in its lawsuit against Samsung
 Electronics Co., Ltd. and affiliated parties in the United States
 District Court, Northern District of California, San Jose Division.
 On March 6, 2014, the District Court entered final judgment in
 favor of the Company in the amount of approximately $930
 million. On May 18, 2015, the U.S. Court of Appeals for
 the Federal Circuit affirmed in part, and reversed in part, the
 decision of the District Court. As a result, the Court of Appeals
 ordered entry of final judgment on damages in the amount of
 approximately $548 million, with the District Court to determine
 supplemental damages and interest, as well as damages owed for
 products subject to the reversal in part. Samsung paid $548 million
 to the Company in December 2015, which was included in net sales in
 the Condensed Consolidated Statement of Operations.
 Because the case remains subject to further proceedings, the
 Company has not recognized any further amounts in its results of
 operations. On March 21, 2016, the United States Supreme Court
 agreed to hear Samsung’s request for appeal related to the
 $548 million in damages.
  (was, 2016-01-27, similarity 0.9242):
[0001193125-16-439878:note_history:4]
On August 24, 2012, a jury returned a verdict
 awarding the Company $1.05 billion in its lawsuit against Samsung
 Electronics Co., Ltd. and affiliated parties in the United States
 District Court, Northern District of California, San Jose Division.
 On March 6, 2014, the District Court entered final judgment in
 favor of the Company in the amount of approximately $930
 million. On May 18, 2015, the U.S. Court of Appeals for
 the Federal Circuit affirmed in part, and reversed in part, the
 decision of the District Court. As a result, the Court of Appeals
 ordered entry of final judgment on damages in the amount of
 approximately $548 million, with the District Court to determine
 supplemental damages and interest, as well as damages owed for
 products subject to the reversal in part. Samsung Electronics Co.,
 Ltd. paid $548 million to the Company in December 2015, which was
 included in net sales in the Condensed Consolidated Statement of
 Operations. Because the March 6, 2014 ruling remains
 subject to further proceedings, the Company has not recognized any
 further amounts in its results of operations.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-04-27):
[0001193125-16-559625:note_history:5]
The following table shows the computation of basic
 and diluted earnings per share for the three- and six-month periods
 ended March 26, 2016 and March 28, 2015 (net income in
 millions and shares in thousands):
  (was, 2016-01-27, similarity 0.9119):
[0001193125-16-439878:note_history:5]
The following table shows the computation of basic
 and diluted earnings per share for the three months ended
 December 26, 2015 and December 27, 2014 (net income in
 millions and shares in thousands):

- changed (2016-04-27):
[0001193125-16-559625:note_history:6]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 26, 2016 |  |  | March 28, 2015 |  |  | March 26, 2016 |  |  | March 28, 2015 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 10,516 |  |  | $ | 13,569 |  |  | $ | 28,877 |  |  | $ | 31,593 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding |  |  | 5,514,381 |  |  |  | 5,793,799 |  |  |  | 5,536,656 |  |  |  | 5,818,441 |  |
| Effect of dilutive securities |  |  | 26,505 |  |  |  | 41,059 |  |  |  | 30,850 |  |  |  | 39,889 |  |
| Weighted-average diluted shares |  |  | 5,540,886 |  |  |  | 5,834,858 |  |  |  | 5,567,506 |  |  |  | 5,858,330 |  |
| Basic earnings per share |  | $ | 1.91 |  |  | $ | 2.34 |  |  | $ | 5.22 |  |  | $ | 5.43 |  |
| Diluted earnings per share |  | $ | 1.90 |  |  | $ | 2.33 |  |  | $ | 5.19 |  |  | $ | 5.39 |  |
  (was, 2016-01-27, similarity 0.7354):
[0001193125-16-439878:note_history:6]
|  |  | Three Months Ended |  |
|  |  | December 26, 2015 |  |  | December 27, 2014 |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 18,361 |  |  | $ | 18,024 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding |  |  | 5,558,930 |  |  |  | 5,843,082 |  |
| Effect of dilutive securities |  |  | 35,197 |  |  |  | 38,721 |  |
| Weighted-average diluted shares |  |  | 5,594,127 |  |  |  | 5,881,803 |  |
| Basic earnings per share |  | $ | 3.30 |  |  | $ | 3.08 |  |
| Diluted earnings per share |  | $ | 3.28 |  |  | $ | 3.06 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-04-27):
[0001193125-16-559625:note_history:7]
The Company issues unsecured short-term promissory
 notes (“Commercial Paper”) pursuant to a commercial
 paper program. The Company uses net proceeds from the commercial
 paper program for general corporate purposes, including dividends
 and share repurchases. As of March 26, 2016 and
 September 26, 2015, the Company had $8.0 billion and $8.5
 billion of Commercial Paper outstanding, respectively, with
 maturities generally less than nine months. The weighted-average
 interest rate of the Company’s Commercial Paper was 0.39% as
 of March 26, 2016 and 0.14% as of September 26, 2015.
  (was, 2016-01-27, similarity 0.9527):
[0001193125-16-439878:note_history:7]
The Company issues unsecured short-term promissory
 notes (“Commercial Paper”) pursuant to a commercial
 paper program. The Company uses net proceeds from the commercial
 paper program for general corporate purposes, including dividends
 and share repurchases. As of December 26, 2015 and
 September 26, 2015, the Company had $7.3 billion and $8.5
 billion of Commercial Paper outstanding, respectively, with
 maturities generally less than nine months. The weighted-average
 interest rate of the Company’s Commercial Paper was 0.20% as
 of December 26, 2015 and 0.14% as of September 26,
 2015.

- changed (2016-04-27):
[0001193125-16-559625:note_history:8]
The following table provides a summary of cash
 flows associated with the issuance and maturities of Commercial
 Paper for the six months ended March 26, 2016 and
 March 28, 2015 (in millions):
  (was, 2016-01-27, similarity 0.9293):
[0001193125-16-439878:note_history:8]
The following table provides a summary of cash
 flows associated with the issuance and maturities of Commercial
 Paper for the three months ended December 26, 2015 and
 December 27, 2014 (in millions):

- added (2016-04-27):
[0001193125-16-559625:note_history:9]
|  |  | Six Months Ended |  |
|  |  | March 26, 2016 |  |  | March 28, 2015 |  |
| Maturities less than 90 days: |  |  |  |  |  |  |  |  |
| Proceeds from (repayments of) commercial paper, net |  | $ | 660 |  |  | $ | 985 |  |
| Maturities greater than 90 days: |  |  |  |  |  |  |  |  |
| Proceeds from commercial paper |  |  | 669 |  |  |  | 547 |  |
| Repayments of commercial paper |  |  | (1,832 | ) |  |  | (4,040 | ) |
| Proceeds from (repayments of) commercial paper, net |  |  | (1,163 | ) |  |  | (3,493 | ) |
| Total change in commercial paper, net |  | $ | (503 | ) |  | $ | (2,508 | ) |

- changed (2016-04-27):
[0001193125-16-559625:note_history:10]
As of March 26, 2016, the Company had
 outstanding floating- and fixed-rate notes with varying maturities
 for an aggregate principal amount of $71.3 billion (collectively
 the “Notes”). The Notes are senior unsecured
 obligations, and interest is payable in arrears, quarterly for the
 U.S. dollar-denominated and Australian dollar-denominated
 floating-rate notes, semi-annually for the U.S. dollar-denominated,
 Australian dollar-denominated, British pound-denominated and
 Japanese yen-denominated fixed-rate notes and annually for the
 euro-denominated and Swiss franc-denominated fixed-rate notes. The
 following table provides a summary of the Company’s term debt
 as of March 26, 2016 and September 26, 2015:
  (was, 2016-01-27, similarity 0.9811):
[0001193125-16-439878:note_history:10]
As of December 26, 2015, the Company had
 outstanding floating- and fixed-rate notes with varying maturities
 for an aggregate principal amount of $55.5 billion (collectively
 the “Notes”). The Notes are senior unsecured
 obligations, and interest is payable in arrears, quarterly for the
 U.S. dollar-denominated and Australian dollar-denominated
 floating-rate notes, semi-annually for the U.S. dollar-denominated,
 Australian dollar-denominated, British pound-denominated and
 Japanese yen-denominated fixed-rate notes and annually for the
 euro-denominated and Swiss franc-denominated fixed-rate notes. The
 following table provides a summary of the Company’s term debt
 as of December 26, 2015 and September 26, 2015:

- added (2016-04-27):
[0001193125-16-559625:note_history:11]
|  |  |  |  |  | March, 26, 2016 |  |  | September 26, 2015 |  |
|  |  | Maturities |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2016 - 2018 |  |  | $ | 3,000 |  |  |  | 0.51% - 1.10% |  |  | $ | 3,000 |  |  |  | 0.51% - 1.10% |  |
| Fixed-rate 0.45% - 3.85% notes |  |  | 2016 - 2043 |  |  |  | 14,000 |  |  |  | 0.51% - 3.91% |  |  |  | 14,000 |  |  |  | 0.51% - 3.91% |  |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2017 - 2019 |  |  |  | 2,000 |  |  |  | 0.69% - 0.92% |  |  |  | 2,000 |  |  |  | 0.37% - 0.60% |  |
| Fixed-rate 1.05% - 4.45% notes |  |  | 2017 - 2044 |  |  |  | 10,000 |  |  |  | 0.69% - 4.48% |  |  |  | 10,000 |  |  |  | 0.37% - 4.48% |  |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2017 - 2020 |  |  |  | 1,781 |  |  |  | 0.67% - 1.87% |  |  |  | 1,743 |  |  |  | 0.36% - 1.87% |  |
| Fixed-rate 0.35% - 4.375% notes |  |  | 2017 - 2045 |  |  |  | 25,063 |  |  |  | 0.28% - 4.51% |  |  |  | 24,958 |  |  |  | 0.28% - 4.51% |  |
| Second quarter 2016 debt issuance of $15.5 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2019 |  |  |  | 500 |  |  |  | 1.44% |  |  |  | 0 |  |  |  | 0 |  |
| Floating-rate notes |  |  | 2021 |  |  |  | 500 |  |  |  | 1.75% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 1.30% notes |  |  | 2018 |  |  |  | 500 |  |  |  | 1.32% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 1.70% notes |  |  | 2019 |  |  |  | 1,000 |  |  |  | 1.71% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.25% notes |  |  | 2021 |  |  |  | 3,000 |  |  |  | 1.80% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.85% notes |  |  | 2023 |  |  |  | 1,500 |  |  |  | 2.48% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 3.25% notes |  |  | 2026 |  |  |  | 3,250 |  |  |  | 2.33% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 4.50% notes |  |  | 2036 |  |  |  | 1,250 |  |  |  | 4.54% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 4.65% notes |  |  | 2046 |  |  |  | 4,000 |  |  |  | 4.58% |  |  |  | 0 |  |  |  | 0 |  |
| Total debt issuance |  |  |  |  |  |  | 15,500 |  |  |  |  |  |  |  | 0 |  |  |  |  |  |
| Total term debt |  |  |  |  |  |  | 71,344 |  |  |  |  |  |  |  | 55,701 |  |  |  |  |  |
| Unamortized premium/(discount) |  |  |  |  |  |  | 15 |  |  |  |  |  |  |  | (114 | ) |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  |  |  | 515 |  |  |  |  |  |  |  | 376 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | (2,500 | ) |  |  |  |  |  |  | (2,500 | ) |  |  |  |  |
| Total long-term debt |  |  |  |  |  | $ | 69,374 |  |  |  |  |  |  | $ | 53,463 |  |  |  |  |  |

- added (2016-04-27):
[0001193125-16-559625:note_history:12]
During the second quarter of 2016, the Company
 issued $15.5 billion U.S. dollar-denominated notes. To manage
 interest rate risk on the U.S. dollar-denominated fixed-rate notes
 maturing in 2021, 2023 and 2026, the Company entered into interest
 rate swaps with an aggregate notional amount of $5.0 billion, which
 effectively converted a portion of the fixed interest rates on
 these notes to a floating interest rate.

- changed (2016-04-27):
[0001193125-16-559625:note_history:13]
As of March 26, 2016, ¥149.3 billion of
 Japanese yen-denominated notes was designated as a hedge of the
 foreign currency exposure of its net investment in a foreign
 operation. The foreign currency transaction gain or loss on the
 Japanese yen-denominated debt designated as a hedge is recorded in
 OCI as a part of the cumulative translation adjustment. As of
 March 26, 2016 and September 26, 2015, the carrying value
 of the debt designated as a net investment hedge was $1.3 billion
 and $2.1 billion, respectively. For further discussion regarding
 the Company’s use of derivative instruments see the
 Derivative Financial Instruments section of Note 2,
 “Financial Instruments.”
  (was, 2016-01-27, similarity 0.9801):
[0001193125-16-439878:note_history:13]
As of December 26, 2015, ¥118.0 billion
 of Japanese yen-denominated notes was designated as a hedge of the
 foreign currency exposure of its net investment in a foreign
 operation. The foreign currency transaction gain or loss on the
 Japanese yen-denominated debt designated as a hedge is recorded in
 OCI as a part of the cumulative translation adjustment. As of
 December 26, 2015 and September 26, 2015, the carrying
 value of the debt designated as a net investment hedge was $1.0
 billion and $2.1 billion, respectively. For further discussion
 regarding the Company’s use of derivative instruments see the
 Derivative Financial Instruments section of Note 2,
 “Financial Instruments.”

- changed (2016-04-27):
[0001193125-16-559625:note_history:14]
The effective interest rates for the Notes include
 the interest on the Notes, amortization of the discount and, if
 applicable, adjustments related to hedging. The Company recognized
 $311 million and $582 million of interest expense on its term debt
 for the three- and six-month periods ended March 26, 2016,
 respectively. The Company recognized $161 million and $289 million
 of interest expense on its term debt for the three- and six-month
 periods ended March 28, 2015, respectively.
  (was, 2016-01-27, similarity 0.7086):
[0001193125-16-439878:note_history:14]
The effective interest rates for the Notes include
 the interest on the Notes, amortization of the discount and, if
 applicable, adjustments related to hedging. The Company recognized
 $271 million and $128 million of interest expense on its term debt
 for the three months ended December 26, 2015 and
 December 27, 2014, respectively.

- changed (2016-04-27):
[0001193125-16-559625:note_history:15]
As of March 26, 2016 and September 26,
 2015, the fair value of the Company’s Notes, based on Level 2
 inputs, was $72.4 billion and $54.9 billion, respectively.
  (was, 2016-01-27, similarity 0.9686):
[0001193125-16-439878:note_history:15]
As of December 26, 2015 and September 26,
 2015, the fair value of the Company’s Notes, based on Level 2
 inputs, was $55.1 billion and $54.9 billion, respectively.

- removed (2016-04-27):
[0001193125-16-439878:note_history:16]
|  |  | Three Months Ended |  |
|  |  | December 26, 2015 |  |  | December 27, 2014 |  |
| Maturities less than 90 days: |  |  |  |  |  |  |  |  |
| Proceeds from (repayments of) commercial paper, net |  | $ | (393 | ) |  | $ | 62 |  |
| Maturities greater than 90 days: |  |  |  |  |  |  |  |  |
| Proceeds from commercial paper |  |  | 492 |  |  |  | 197 |  |
| Repayments of commercial paper |  |  | (1,339 | ) |  |  | (2,668 | ) |
| Proceeds from (repayments of) commercial paper, net |  |  | (847 | ) |  |  | (2,471 | ) |
| Total change in commercial paper, net |  | $ | (1,240 | ) |  | $ | (2,409 | ) |

- removed (2016-04-27):
[0001193125-16-439878:note_history:17]
|  |  | Maturities |  |  | December, 26, 2015 |  |  | September 26, 2015 |  |
|  |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2016 - 2018 |  |  | $ | 3,000 |  |  |  | 0.51% - 1.10% |  |  | $ | 3,000 |  |  |  | 0.51% - 1.10% |  |
| Fixed-rate 0.45% - 3.85% notes |  |  | 2016 - 2043 |  |  |  | 14,000 |  |  |  | 0.51% - 3.91% |  |  |  | 14,000 |  |  |  | 0.51% - 3.91% |  |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2017 - 2019 |  |  |  | 2,000 |  |  |  | 0.41% - 0.64% |  |  |  | 2,000 |  |  |  | 0.37% - 0.60% |  |
| Fixed-rate 1.05% - 4.45% notes |  |  | 2017 - 2044 |  |  |  | 10,000 |  |  |  | 0.40% - 4.48% |  |  |  | 10,000 |  |  |  | 0.37% - 4.48% |  |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2017 - 2020 |  |  |  | 1,755 |  |  |  | 0.41% - 1.87% |  |  |  | 1,743 |  |  |  | 0.36% - 1.87% |  |
| Fixed-rate 0.35% - 4.375% notes |  |  | 2017 - 2045 |  |  |  | 24,793 |  |  |  | 0.28% - 4.51% |  |  |  | 24,958 |  |  |  | 0.28% - 4.51% |  |
| Total term debt |  |  |  |  |  |  | 55,548 |  |  |  |  |  |  |  | 55,701 |  |  |  |  |  |
| Unamortized discount |  |  |  |  |  |  | (109 | ) |  |  |  |  |  |  | (114 | ) |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  |  |  | 265 |  |  |  |  |  |  |  | 376 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | (2,500 | ) |  |  |  |  |  |  | (2,500 | ) |  |  |  |  |
| Total long-term debt |  |  |  |  |  | $ | 53,204 |  |  |  |  |  |  | $ | 53,463 |  |  |  |  |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-04-27):
[0001193125-16-559625:note_history:18]
The following table provides a summary of the
 Company’s term debt as of March 26, 2016 and
 September 26, 2015:
  (was, 2016-01-27, similarity 0.9557):
[0001193125-16-439878:note_history:18]
The following table provides a summary of the
 Company’s term debt as of December 26, 2015 and
 September 26, 2015:

- added (2016-04-27):
[0001193125-16-559625:note_history:19]
|  |  |  |  |  | March, 26, 2016 |  |  | September 26, 2015 |  |
|  |  | Maturities |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2016 - 2018 |  |  | $ | 3,000 |  |  |  | 0.51% - 1.10% |  |  | $ | 3,000 |  |  |  | 0.51% - 1.10% |  |
| Fixed-rate 0.45% - 3.85% notes |  |  | 2016 - 2043 |  |  |  | 14,000 |  |  |  | 0.51% - 3.91% |  |  |  | 14,000 |  |  |  | 0.51% - 3.91% |  |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2017 - 2019 |  |  |  | 2,000 |  |  |  | 0.69% - 0.92% |  |  |  | 2,000 |  |  |  | 0.37% - 0.60% |  |
| Fixed-rate 1.05% - 4.45% notes |  |  | 2017 - 2044 |  |  |  | 10,000 |  |  |  | 0.69% - 4.48% |  |  |  | 10,000 |  |  |  | 0.37% - 4.48% |  |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2017 - 2020 |  |  |  | 1,781 |  |  |  | 0.67% - 1.87% |  |  |  | 1,743 |  |  |  | 0.36% - 1.87% |  |
| Fixed-rate 0.35% - 4.375% notes |  |  | 2017 - 2045 |  |  |  | 25,063 |  |  |  | 0.28% - 4.51% |  |  |  | 24,958 |  |  |  | 0.28% - 4.51% |  |
| Second quarter 2016 debt issuance of $15.5 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2019 |  |  |  | 500 |  |  |  | 1.44% |  |  |  | 0 |  |  |  | 0 |  |
| Floating-rate notes |  |  | 2021 |  |  |  | 500 |  |  |  | 1.75% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 1.30% notes |  |  | 2018 |  |  |  | 500 |  |  |  | 1.32% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 1.70% notes |  |  | 2019 |  |  |  | 1,000 |  |  |  | 1.71% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.25% notes |  |  | 2021 |  |  |  | 3,000 |  |  |  | 1.80% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.85% notes |  |  | 2023 |  |  |  | 1,500 |  |  |  | 2.48% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 3.25% notes |  |  | 2026 |  |  |  | 3,250 |  |  |  | 2.33% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 4.50% notes |  |  | 2036 |  |  |  | 1,250 |  |  |  | 4.54% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 4.65% notes |  |  | 2046 |  |  |  | 4,000 |  |  |  | 4.58% |  |  |  | 0 |  |  |  | 0 |  |
| Total debt issuance |  |  |  |  |  |  | 15,500 |  |  |  |  |  |  |  | 0 |  |  |  |  |  |
| Total term debt |  |  |  |  |  |  | 71,344 |  |  |  |  |  |  |  | 55,701 |  |  |  |  |  |
| Unamortized premium/(discount) |  |  |  |  |  |  | 15 |  |  |  |  |  |  |  | (114 | ) |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  |  |  | 515 |  |  |  |  |  |  |  | 376 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | (2,500 | ) |  |  |  |  |  |  | (2,500 | ) |  |  |  |  |
| Total long-term debt |  |  |  |  |  | $ | 69,374 |  |  |  |  |  |  | $ | 53,463 |  |  |  |  |  |

- removed (2016-04-27):
[0001193125-16-439878:note_history:20]
|  |  | Maturities |  |  | December, 26, 2015 |  |  | September 26, 2015 |  |
|  |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2016 - 2018 |  |  | $ | 3,000 |  |  |  | 0.51% - 1.10% |  |  | $ | 3,000 |  |  |  | 0.51% - 1.10% |  |
| Fixed-rate 0.45% - 3.85% notes |  |  | 2016 - 2043 |  |  |  | 14,000 |  |  |  | 0.51% - 3.91% |  |  |  | 14,000 |  |  |  | 0.51% - 3.91% |  |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2017 - 2019 |  |  |  | 2,000 |  |  |  | 0.41% - 0.64% |  |  |  | 2,000 |  |  |  | 0.37% - 0.60% |  |
| Fixed-rate 1.05% - 4.45% notes |  |  | 2017 - 2044 |  |  |  | 10,000 |  |  |  | 0.40% - 4.48% |  |  |  | 10,000 |  |  |  | 0.37% - 4.48% |  |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2017 - 2020 |  |  |  | 1,755 |  |  |  | 0.41% - 1.87% |  |  |  | 1,743 |  |  |  | 0.36% - 1.87% |  |
| Fixed-rate 0.35% - 4.375% notes |  |  | 2017 - 2045 |  |  |  | 24,793 |  |  |  | 0.28% - 4.51% |  |  |  | 24,958 |  |  |  | 0.28% - 4.51% |  |
| Total term debt |  |  |  |  |  |  | 55,548 |  |  |  |  |  |  |  | 55,701 |  |  |  |  |  |
| Unamortized discount |  |  |  |  |  |  | (109 | ) |  |  |  |  |  |  | (114 | ) |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  |  |  | 265 |  |  |  |  |  |  |  | 376 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | (2,500 | ) |  |  |  |  |  |  | (2,500 | ) |  |  |  |  |
| Total long-term debt |  |  |  |  |  | $ | 53,204 |  |  |  |  |  |  | $ | 53,463 |  |  |  |  |  |
