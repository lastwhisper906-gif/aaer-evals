# AAPL notes — 0001193125-16-559625


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-16-559625:notes:1]
[same as prior period, unchanged from 0001193125-16-439878:notes:1]

[0001193125-16-559625:notes:2]
The Company’s acquired intangible assets
 with definite useful lives primarily consist of patents and
 licenses and are amortized over periods typically from three to
 seven years. The following table summarizes the components of gross
 and net acquired intangible asset balances as of March 26,
 2016 and September 26, 2015 (in millions):

[0001193125-16-559625:notes:3]
|  |  | March 26, 2016 |  |  | September 26, 2015 |  |
|  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Carrying Amount |  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Carrying Amount |  |
| Definite-lived and amortizable acquired intangible assets |  | $ | 8,797 |  |  | $ | (5,054 | ) |  | $ | 3,743 |  |  | $ | 8,125 |  |  | $ | (4,332 | ) |  | $ | 3,793 |  |
| Indefinite-lived and non-amortizable acquired intangible assets |  |  | 100 |  |  |  | 0 |  |  |  | 100 |  |  |  | 100 |  |  |  | 0 |  |  |  | 100 |  |
| Total acquired intangible assets |  | $ | 8,897 |  |  | $ | (5,054 | ) |  | $ | 3,843 |  |  | $ | 8,225 |  |  | $ | (4,332 | ) |  | $ | 3,893 |  |


## us-gaap:ScheduleOfDerivativeInstrumentsInStatementOfFinancialPositionFairValueTextBlock

[0001193125-16-559625:notes:4]
The following tables show the Company’s
 derivative instruments at gross fair value as of March 26,
 2016 and September 26, 2015 (in millions):

[0001193125-16-559625:notes:5]
|  |  | March 26, 2016 |  |
|  |  | Fair Value of Derivatives Designated as Hedge Instruments |  |  | Fair Value of Derivatives Not Designated as Hedge Instruments |  |  | Total Fair Value |  |
| Derivative assets (1): |  |  |  |  |
| Foreign exchange contracts |  | $ | 564 |  |  | $ | 69 |  |  | $ | 633 |  |
| Interest rate contracts |  | $ | 557 |  |  | $ | 0 |  |  | $ | 557 |  |
| Derivative liabilities (2): |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 1,033 |  |  | $ | 243 |  |  | $ | 1,276 |  |
| Interest rate contracts |  | $ | 36 |  |  | $ | 0 |  |  | $ | 36 |  |

[0001193125-16-559625:notes:6]
|  |  | September 26, 2015 |  |
|  |  | Fair Value of Derivatives Designated as Hedge Instruments |  |  | Fair Value of Derivatives Not Designated as Hedge Instruments |  |  | Total Fair Value |  |
| Derivative assets (1): |  |  |  |  |
| Foreign exchange contracts |  | $ | 1,442 |  |  | $ | 109 |  |  | $ | 1,551 |  |
| Interest rate contracts |  | $ | 394 |  |  | $ | 0 |  |  | $ | 394 |  |
| Derivative liabilities (2): |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 905 |  |  | $ | 94 |  |  | $ | 999 |  |
| Interest rate contracts |  | $ | 13 |  |  | $ | 0 |  |  | $ | 13 |  |

[0001193125-16-559625:notes:7]
[same as prior period, unchanged from 0001193125-16-439878:notes:7]

[0001193125-16-559625:notes:8]
|  | (2) | The fair value of derivative liabilities is measured using Level 2 fair value inputs and is recorded as accrued expenses in the Condensed Consolidated Balance Sheets. |


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001193125-16-559625:notes:9]
A reconciliation of the Company’s segment
 operating income to the Condensed Consolidated Statements of
 Operations for the three- and six-month periods ended
 March 26, 2016 and March 28, 2015 (in millions):

[0001193125-16-559625:notes:10]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 26, 2016 |  |  | March 28, 2015 |  |  | March 26, 2016 |  |  | March 28, 2015 |  |
| Segment operating income |  | $ | 17,561 |  |  | $ | 21,311 |  |  | $ | 45,206 |  |  | $ | 48,597 |  |
| Research and development expense |  |  | (2,511 | ) |  |  | (1,918 | ) |  |  | (4,915 | ) |  |  | (3,813 | ) |
| Other corporate expenses, net |  |  | (1,063 | ) |  |  | (1,115 | ) |  |  | (2,133 | ) |  |  | (2,260 | ) |
| Total operating income |  | $ | 13,987 |  |  | $ | 18,278 |  |  | $ | 38,158 |  |  | $ | 42,524 |  |


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001193125-16-559625:notes:11]
The following table shows the computation of basic
 and diluted earnings per share for the three- and six-month periods
 ended March 26, 2016 and March 28, 2015 (net income in
 millions and shares in thousands):

[0001193125-16-559625:notes:12]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 26, 2016 |  |  | March 28, 2015 |  |  | March 26, 2016 |  |  | March 28, 2015 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 10,516 |  |  | $ | 13,569 |  |  | $ | 28,877 |  |  | $ | 31,593 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding |  |  | 5,514,381 |  |  |  | 5,793,799 |  |  |  | 5,536,656 |  |  |  | 5,818,441 |  |
| Effect of dilutive securities |  |  | 26,505 |  |  |  | 41,059 |  |  |  | 30,850 |  |  |  | 39,889 |  |
| Weighted-average diluted shares |  |  | 5,540,886 |  |  |  | 5,834,858 |  |  |  | 5,567,506 |  |  |  | 5,858,330 |  |
| Basic earnings per share |  | $ | 1.91 |  |  | $ | 2.34 |  |  | $ | 5.22 |  |  | $ | 5.43 |  |
| Diluted earnings per share |  | $ | 1.90 |  |  | $ | 2.33 |  |  | $ | 5.19 |  |  | $ | 5.39 |  |


## us-gaap:DebtDisclosureTextBlock

[0001193125-16-559625:notes:13]
Note 6 – Debt

[0001193125-16-559625:notes:14]
Commercial Paper

[0001193125-16-559625:notes:15]
The Company issues unsecured short-term promissory
 notes (“Commercial Paper”) pursuant to a commercial
 paper program. The Company uses net proceeds from the commercial
 paper program for general corporate purposes, including dividends
 and share repurchases. As of March 26, 2016 and
 September 26, 2015, the Company had $8.0 billion and $8.5
 billion of Commercial Paper outstanding, respectively, with
 maturities generally less than nine months. The weighted-average
 interest rate of the Company’s Commercial Paper was 0.39% as
 of March 26, 2016 and 0.14% as of September 26, 2015.

[0001193125-16-559625:notes:16]
The following table provides a summary of cash
 flows associated with the issuance and maturities of Commercial
 Paper for the six months ended March 26, 2016 and
 March 28, 2015 (in millions):

[0001193125-16-559625:notes:17]
|  |  | Six Months Ended |  |
|  |  | March 26, 2016 |  |  | March 28, 2015 |  |
| Maturities less than 90 days: |  |  |  |  |  |  |  |  |
| Proceeds from (repayments of) commercial paper, net |  | $ | 660 |  |  | $ | 985 |  |
| Maturities greater than 90 days: |  |  |  |  |  |  |  |  |
| Proceeds from commercial paper |  |  | 669 |  |  |  | 547 |  |
| Repayments of commercial paper |  |  | (1,832 | ) |  |  | (4,040 | ) |
| Proceeds from (repayments of) commercial paper, net |  |  | (1,163 | ) |  |  | (3,493 | ) |
| Total change in commercial paper, net |  | $ | (503 | ) |  | $ | (2,508 | ) |

[0001193125-16-559625:notes:18]
Long-Term Debt

[0001193125-16-559625:notes:19]
As of March 26, 2016, the Company had
 outstanding floating- and fixed-rate notes with varying maturities
 for an aggregate principal amount of $71.3 billion (collectively
 the “Notes”). The Notes are senior unsecured
 obligations, and interest is payable in arrears, quarterly for the
 U.S. dollar-denominated and Australian dollar-denominated
 floating-rate notes, semi-annually for the U.S. dollar-denominated,
 Australian dollar-denominated, British pound-denominated and
 Japanese yen-denominated fixed-rate notes and annually for the
 euro-denominated and Swiss franc-denominated fixed-rate notes. The
 following table provides a summary of the Company’s term debt
 as of March 26, 2016 and September 26, 2015:

[0001193125-16-559625:notes:20]
|  |  |  |  |  | March, 26, 2016 |  |  | September 26, 2015 |  |
|  |  | Maturities |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2016 - 2018 |  |  | $ | 3,000 |  |  |  | 0.51% - 1.10% |  |  | $ | 3,000 |  |  |  | 0.51% - 1.10% |  |
| Fixed-rate 0.45% - 3.85% notes |  |  | 2016 - 2043 |  |  |  | 14,000 |  |  |  | 0.51% - 3.91% |  |  |  | 14,000 |  |  |  | 0.51% - 3.91% |  |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2017 - 2019 |  |  |  | 2,000 |  |  |  | 0.69% - 0.92% |  |  |  | 2,000 |  |  |  | 0.37% - 0.60% |  |
| Fixed-rate 1.05% - 4.45% notes |  |  | 2017 - 2044 |  |  |  | 10,000 |  |  |  | 0.69% - 4.48% |  |  |  | 10,000 |  |  |  | 0.37% - 4.48% |  |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2017 - 2020 |  |  |  | 1,781 |  |  |  | 0.67% - 1.87% |  |  |  | 1,743 |  |  |  | 0.36% - 1.87% |  |
| Fixed-rate 0.35% - 4.375% notes |  |  | 2017 - 2045 |  |  |  | 25,063 |  |  |  | 0.28% - 4.51% |  |  |  | 24,958 |  |  |  | 0.28% - 4.51% |  |
| Second quarter 2016 debt issuance of $15.5 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2019 |  |  |  | 500 |  |  |  | 1.44% |  |  |  | 0 |  |  |  | 0 |  |
| Floating-rate notes |  |  | 2021 |  |  |  | 500 |  |  |  | 1.75% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 1.30% notes |  |  | 2018 |  |  |  | 500 |  |  |  | 1.32% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 1.70% notes |  |  | 2019 |  |  |  | 1,000 |  |  |  | 1.71% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.25% notes |  |  | 2021 |  |  |  | 3,000 |  |  |  | 1.80% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.85% notes |  |  | 2023 |  |  |  | 1,500 |  |  |  | 2.48% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 3.25% notes |  |  | 2026 |  |  |  | 3,250 |  |  |  | 2.33% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 4.50% notes |  |  | 2036 |  |  |  | 1,250 |  |  |  | 4.54% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 4.65% notes |  |  | 2046 |  |  |  | 4,000 |  |  |  | 4.58% |  |  |  | 0 |  |  |  | 0 |  |
| Total debt issuance |  |  |  |  |  |  | 15,500 |  |  |  |  |  |  |  | 0 |  |  |  |  |  |
| Total term debt |  |  |  |  |  |  | 71,344 |  |  |  |  |  |  |  | 55,701 |  |  |  |  |  |
| Unamortized premium/(discount) |  |  |  |  |  |  | 15 |  |  |  |  |  |  |  | (114 | ) |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  |  |  | 515 |  |  |  |  |  |  |  | 376 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | (2,500 | ) |  |  |  |  |  |  | (2,500 | ) |  |  |  |  |
| Total long-term debt |  |  |  |  |  | $ | 69,374 |  |  |  |  |  |  | $ | 53,463 |  |  |  |  |  |

[0001193125-16-559625:notes:21]
During the second quarter of 2016, the Company
 issued $15.5 billion U.S. dollar-denominated notes. To manage
 interest rate risk on the U.S. dollar-denominated fixed-rate notes
 maturing in 2021, 2023 and 2026, the Company entered into interest
 rate swaps with an aggregate notional amount of $5.0 billion, which
 effectively converted a portion of the fixed interest rates on
 these notes to a floating interest rate.

[0001193125-16-559625:notes:22]
As of March 26, 2016, ¥149.3 billion of
 Japanese yen-denominated notes was designated as a hedge of the
 foreign currency exposure of its net investment in a foreign
 operation. The foreign currency transaction gain or loss on the
 Japanese yen-denominated debt designated as a hedge is recorded in
 OCI as a part of the cumulative translation adjustment. As of
 March 26, 2016 and September 26, 2015, the carrying value
 of the debt designated as a net investment hedge was $1.3 billion
 and $2.1 billion, respectively. For further discussion regarding
 the Company’s use of derivative instruments see the
 Derivative Financial Instruments section of Note 2,
 “Financial Instruments.”

[0001193125-16-559625:notes:23]
The effective interest rates for the Notes include
 the interest on the Notes, amortization of the discount and, if
 applicable, adjustments related to hedging. The Company recognized
 $311 million and $582 million of interest expense on its term debt
 for the three- and six-month periods ended March 26, 2016,
 respectively. The Company recognized $161 million and $289 million
 of interest expense on its term debt for the three- and six-month
 periods ended March 28, 2015, respectively.

[0001193125-16-559625:notes:24]
As of March 26, 2016 and September 26,
 2015, the fair value of the Company’s Notes, based on Level 2
 inputs, was $72.4 billion and $54.9 billion, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-16-559625:notes:25]
[same as prior period, unchanged from 0001193125-16-439878:notes:24]

[0001193125-16-559625:notes:26]
[same as prior period, unchanged from 0001193125-16-439878:notes:25]

[0001193125-16-559625:notes:27]
The Company manages its business primarily on a
 geographic basis. The Company’s reportable operating segments
 consist of the Americas, Europe, Greater China, Japan and Rest of
 Asia Pacific. The Americas segment includes both North and South
 America. The Europe segment includes European countries, as well as
 India, the Middle East and Africa. The Greater China segment
 includes China, Hong Kong and Taiwan. The Rest of Asia Pacific
 segment includes Australia and those Asian countries not included
 in the Company’s other reportable operating segments.
 Although the reportable operating segments provide similar hardware
 and software products and similar services, each one is managed
 separately to better align with the location of the Company’s
 customers and distribution partners and the unique market dynamics
 of each geographic region. The accounting policies of the various
 segments are the same as those described in Note 1, “Summary
 of Significant Accounting Policies” of the Notes to
 Consolidated Financial Statements in Part II, Item 8 of the
 2015 Form 10-K.

[0001193125-16-559625:notes:28]
[same as prior period, unchanged from 0001193125-16-439878:notes:27]

[0001193125-16-559625:notes:29]
The following table shows information by reportable
 operating segment for the three- and six-month periods ended
 March 26, 2016 and March 28, 2015 (in millions):

[0001193125-16-559625:notes:30]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 26, 2016 |  |  | March 28, 2015 |  |  | March 26, 2016 |  |  | March 28, 2015 |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 19,096 |  |  | $ | 21,316 |  |  | $ | 48,421 |  |  | $ | 51,882 |  |
| Operating income |  | $ | 6,116 |  |  | $ | 7,186 |  |  | $ | 16,134 |  |  | $ | 17,887 |  |
| Europe: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 11,535 |  |  | $ | 12,204 |  |  | $ | 29,467 |  |  | $ | 29,418 |  |
| Operating income |  | $ | 3,602 |  |  | $ | 4,112 |  |  | $ | 9,381 |  |  | $ | 9,994 |  |
| Greater China: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 12,486 |  |  | $ | 16,823 |  |  | $ | 30,859 |  |  | $ | 32,967 |  |
| Operating income |  | $ | 4,818 |  |  | $ | 6,714 |  |  | $ | 12,394 |  |  | $ | 13,080 |  |
| Japan: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 4,281 |  |  | $ | 3,457 |  |  | $ | 9,075 |  |  | $ | 8,905 |  |
| Operating income |  | $ | 1,930 |  |  | $ | 1,699 |  |  | $ | 4,170 |  |  | $ | 4,187 |  |
| Rest of Asia Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 3,159 |  |  | $ | 4,210 |  |  | $ | 8,607 |  |  | $ | 9,437 |  |
| Operating income |  | $ | 1,095 |  |  | $ | 1,600 |  |  | $ | 3,127 |  |  | $ | 3,449 |  |


## us-gaap:AcceleratedShareRepurchasesTextBlock

[0001193125-16-559625:notes:31]
The following table shows the Company’s ASR
 activity and related information during the six months ended
 March 26, 2016 and the year ended September 26, 2015:

[0001193125-16-559625:notes:32]
[same as prior period, unchanged from 0001193125-16-439878:notes:31]

[0001193125-16-559625:notes:33]
[same as prior period, unchanged from 0001193125-16-439878:notes:32]


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001193125-16-559625:notes:34]
The following tables show the Company’s cash
 and available-for-sale securities’ adjusted
 cost, gross unrealized gains, gross unrealized losses and fair
 value by significant investment category recorded as cash and cash
 equivalents or short- or long-term marketable securities as of
 March 26, 2016 and September 26, 2015 (in millions):

[0001193125-16-559625:notes:35]
|  |  | March 26, 2016 |  |
|  |  | Adjusted Cost |  |  | Unrealized Gains |  |  | Unrealized Losses |  |  | Fair Value |  |  | Cash and Cash Equivalents |  |  | Short-Term Marketable Securities |  |  | Long-Term Marketable Securities |  |
| Cash |  | $ | 10,199 |  |  | $ | 0 |  |  | $ | 0 |  |  | $ | 10,199 |  |  | $ | 10,199 |  |  | $ | 0 |  |  | $ | 0 |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  |  | 2,798 |  |  |  | 0 |  |  |  | 0 |  |  |  | 2,798 |  |  |  | 2,798 |  |  |  | 0 |  |  |  | 0 |  |
| Mutual funds |  |  | 1,772 |  |  |  | 0 |  |  |  | (203 | ) |  |  | 1,569 |  |  |  | 0 |  |  |  | 1,569 |  |  |  | 0 |  |
| Subtotal |  |  | 4,570 |  |  |  | 0 |  |  |  | (203 | ) |  |  | 4,367 |  |  |  | 2,798 |  |  |  | 1,569 |  |  |  | 0 |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities |  |  | 47,883 |  |  |  | 207 |  |  |  | (24 | ) |  |  | 48,066 |  |  |  | 3,753 |  |  |  | 10,614 |  |  |  | 33,699 |  |
| U.S. agency securities |  |  | 6,641 |  |  |  | 12 |  |  |  | (2 | ) |  |  | 6,651 |  |  |  | 465 |  |  |  | 2,703 |  |  |  | 3,483 |  |
| Non-U.S. government securities |  |  | 6,873 |  |  |  | 91 |  |  |  | (121 | ) |  |  | 6,843 |  |  |  | 0 |  |  |  | 696 |  |  |  | 6,147 |  |
| Certificates of deposit and time deposits |  |  | 4,169 |  |  |  | 0 |  |  |  | 0 |  |  |  | 4,169 |  |  |  | 1,529 |  |  |  | 660 |  |  |  | 1,980 |  |
| Commercial paper |  |  | 4,500 |  |  |  | 0 |  |  |  | 0 |  |  |  | 4,500 |  |  |  | 2,681 |  |  |  | 1,819 |  |  |  | 0 |  |
| Corporate securities |  |  | 129,394 |  |  |  | 543 |  |  |  | (1,074 | ) |  |  | 128,863 |  |  |  | 89 |  |  |  | 15,553 |  |  |  | 113,221 |  |
| Municipal securities |  |  | 952 |  |  |  | 6 |  |  |  | 0 |  |  |  | 958 |  |  |  | 0 |  |  |  | 72 |  |  |  | 886 |  |
| Mortgage- and asset-backed securities |  |  | 18,268 |  |  |  | 86 |  |  |  | (42 | ) |  |  | 18,312 |  |  |  | 0 |  |  |  | 83 |  |  |  | 18,229 |  |
| Subtotal |  |  | 218,680 |  |  |  | 945 |  |  |  | (1,263 | ) |  |  | 218,362 |  |  |  | 8,517 |  |  |  | 32,200 |  |  |  | 177,645 |  |
| Total |  | $ | 233,449 |  |  | $ | 945 |  |  | $ | (1,466 | ) |  | $ | 232,928 |  |  | $ | 21,514 |  |  | $ | 33,769 |  |  | $ | 177,645 |  |

[0001193125-16-559625:notes:36]
[same as prior period, unchanged from 0001193125-16-439878:notes:35]

[0001193125-16-559625:notes:37]
[same as prior period, unchanged from 0001193125-16-439878:notes:36]

[0001193125-16-559625:notes:38]
|  | (2) | The fair value of Level 2 securities is estimated based on observable inputs other than quoted prices in active markets for identical assets and liabilities, quoted prices for identical or similar assets or liabilities in inactive markets, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities. |


## us-gaap:DividendsDeclaredTableTextBlock

[0001193125-16-559625:notes:39]
[same as prior period, unchanged from 0001193125-16-439878:notes:38]

[0001193125-16-559625:notes:40]
|  |  | Dividends Per Share |  |  | Amount (in millions) |  |
| 2016: |  |  |  |  |  |  |  |  |
| Second quarter |  | $ | 0.52 |  |  | $ | 2,879 |  |
| First quarter |  |  | 0.52 |  |  |  | 2,898 |  |
| Total cash dividends declared and paid |  | $ | 1.04 |  |  | $ | 5,777 |  |
| 2015: |  |  |  |  |  |  |  |  |
| Fourth quarter |  | $ | 0.52 |  |  | $ | 2,950 |  |
| Third quarter |  |  | 0.52 |  |  |  | 2,997 |  |
| Second quarter |  |  | 0.47 |  |  |  | 2,734 |  |
| First quarter |  |  | 0.47 |  |  |  | 2,750 |  |
| Total cash dividends declared and paid |  | $ | 1.98 |  |  | $ | 11,431 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001193125-16-559625:notes:41]
[same as prior period, unchanged from 0001193125-16-439878:notes:40]

[0001193125-16-559625:notes:42]
[same as prior period, unchanged from 0001193125-16-439878:notes:41]

[0001193125-16-559625:notes:43]
[same as prior period, unchanged from 0001193125-16-439878:notes:42]

[0001193125-16-559625:notes:44]
[same as prior period, unchanged from 0001193125-16-439878:notes:43]


## us-gaap:EarningsPerSharePolicyTextBlock

[0001193125-16-559625:notes:45]
[same as prior period, unchanged from 0001193125-16-439878:notes:44]

[0001193125-16-559625:notes:46]
[same as prior period, unchanged from 0001193125-16-439878:notes:45]

[0001193125-16-559625:notes:47]
[same as prior period, unchanged from 0001193125-16-439878:notes:46]


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001193125-16-559625:notes:48]
[same as prior period, unchanged from 0001193125-16-439878:notes:47]

[0001193125-16-559625:notes:49]
[same as prior period, unchanged from 0001193125-16-439878:notes:48]

[0001193125-16-559625:notes:50]
|  | (2) | The fair value of Level 2 securities is estimated based on observable inputs other than quoted prices in active markets for identical assets and liabilities, quoted prices for identical or similar assets or liabilities in inactive markets, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities. |  |

[0001193125-16-559625:notes:51]
[same as prior period, unchanged from 0001193125-16-439878:notes:49]

[0001193125-16-559625:notes:52]
The Company considers the declines in market value
 of its marketable securities investment portfolio to be temporary
 in nature. The Company typically invests in highly-rated
 securities, and its investment policy generally limits the amount
 of credit exposure to any one issuer. The policy generally requires
 investments to be investment grade, with the primary objective of
 minimizing the potential risk of principal loss. Fair values were
 determined for each individual security in the investment
 portfolio. When evaluating an investment for other-than-temporary
 impairment the Company reviews factors such as the length of time
 and extent to which fair value has been below its cost basis, the
 financial condition of the issuer and any changes thereto, changes
 in market interest rates and the Company’s intent to sell, or
 whether it is more likely than not it will be required to sell the
 investment before recovery of the investment’s cost basis. As
 of March 26, 2016, the Company does not consider any of its
 investments to be other-than-temporarily impaired.

[0001193125-16-559625:notes:53]
[same as prior period, unchanged from 0001193125-16-439878:notes:51]

[0001193125-16-559625:notes:54]
[same as prior period, unchanged from 0001193125-16-439878:notes:52]

[0001193125-16-559625:notes:55]
[same as prior period, unchanged from 0001193125-16-439878:notes:53]

[0001193125-16-559625:notes:56]
[same as prior period, unchanged from 0001193125-16-439878:notes:54]

[0001193125-16-559625:notes:57]
[same as prior period, unchanged from 0001193125-16-439878:notes:55]

[0001193125-16-559625:notes:58]
The Company may enter into interest rate swaps,
 options, or other instruments to manage interest rate risk. These
 instruments may offset a portion of changes in income or expense,
 or changes in fair value of the Company’s term debt or
 investments. The Company designates these instruments as either
 cash flow or fair value hedges. The Company’s hedged interest
 rate transactions as of March 26, 2016 are expected to be
 recognized within ten years.

[0001193125-16-559625:notes:59]
[same as prior period, unchanged from 0001193125-16-439878:notes:57]

[0001193125-16-559625:notes:60]
[same as prior period, unchanged from 0001193125-16-439878:notes:58]

[0001193125-16-559625:notes:61]
[same as prior period, unchanged from 0001193125-16-439878:notes:59]

[0001193125-16-559625:notes:62]
[same as prior period, unchanged from 0001193125-16-439878:notes:60]

[0001193125-16-559625:notes:63]
[same as prior period, unchanged from 0001193125-16-439878:notes:61]

[0001193125-16-559625:notes:64]
[same as prior period, unchanged from 0001193125-16-439878:notes:62]

[0001193125-16-559625:notes:65]
[same as prior period, unchanged from 0001193125-16-439878:notes:63]

[0001193125-16-559625:notes:66]
[same as prior period, unchanged from 0001193125-16-439878:notes:64]

[0001193125-16-559625:notes:67]
[same as prior period, unchanged from 0001193125-16-439878:notes:65]

[0001193125-16-559625:notes:68]
The Company records all derivatives in the
 Condensed Consolidated Balance Sheets at fair value. The
 Company’s accounting treatment for these derivative
 instruments is based on its hedge designation. The following tables
 show the Company’s derivative instruments at gross fair value
 as of March 26, 2016 and September 26, 2015 (in
 millions):

[0001193125-16-559625:notes:69]
|  | (2) | The fair value of derivative liabilities is measured using Level 2 fair value inputs and is recorded as accrued expenses in the Condensed Consolidated Balance Sheets. |  |

[0001193125-16-559625:notes:70]
The following table shows the pre-tax gains and
 losses of the Company’s derivative and non-derivative
 instruments designated as cash flow, net investment and fair value
 hedges on OCI and the Condensed Consolidated Statements of
 Operations for the three- and six-month periods ended
 March 26, 2016 and March 28, 2015 (in millions):

[0001193125-16-559625:notes:71]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 26, 2016 |  |  | March 28, 2015 |  |  | March 26, 2016 |  |  | March 28, 2015 |  |
| Gains/(Losses) recognized in OCI – effective portion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | (138 | ) |  | $ | 1,249 |  |  | $ | 188 |  |  | $ | 3,750 |  |
| Interest rate contracts |  |  | (50 | ) |  |  | (87 | ) |  |  | (42 | ) |  |  | (91 | ) |
| Total |  | $ | (188 | ) |  | $ | 1,162 |  |  | $ | 146 |  |  | $ | 3,659 |  |
| Net investment hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 0 |  |  | $ | (6 | ) |  | $ | 0 |  |  | $ | 112 |  |
| Foreign currency debt |  |  | (87 | ) |  |  | 0 |  |  |  | (77 | ) |  |  | 0 |  |
| Total |  | $ | (87 | ) |  | $ | (6 | ) |  | $ | (77 | ) |  | $ | 112 |  |
| Gains/(Losses) reclassified from AOCI into net income – effective portion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 668 |  |  | $ | 818 |  |  | $ | 1,183 |  |  | $ | 1,485 |  |
| Interest rate contracts |  |  | (3 | ) |  |  | (5 | ) |  |  | (7 | ) |  |  | (9 | ) |
| Total |  | $ | 665 |  |  | $ | 813 |  |  | $ | 1,176 |  |  | $ | 1,476 |  |
| Gains/(Losses) on derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fair value hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate contracts |  | $ | 250 |  |  | $ | 122 |  |  | $ | 139 |  |  | $ | 239 |  |
| Gains/(Losses) related to hedged items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fair value hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate contracts |  | $ | (250 | ) |  | $ | (122 | ) |  | $ | (139 | ) |  | $ | (239 | ) |

[0001193125-16-559625:notes:72]
The following table shows the notional amounts of
 the Company’s outstanding derivative instruments and credit
 risk amounts associated with outstanding or unsettled derivative
 instruments as of March 26, 2016 and September 26, 2015
 (in millions):

[0001193125-16-559625:notes:73]
|  |  | March 26, 2016 |  |  | September 26, 2015 |  |
|  |  | Notional Amount |  |  | Credit Risk Amount |  |  | Notional Amount |  |  | Credit Risk Amount |  |
| Instruments designated as accounting hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 41,996 |  |  | $ | 564 |  |  | $ | 70,054 |  |  | $ | 1,385 |  |
| Interest rate contracts |  | $ | 23,750 |  |  | $ | 557 |  |  | $ | 18,750 |  |  | $ | 394 |  |
| Instruments not designated as accounting hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 30,573 |  |  | $ | 69 |  |  | $ | 49,190 |  |  | $ | 109 |  |

[0001193125-16-559625:notes:74]
The notional amounts for outstanding derivative
 instruments provide one measure of the transaction volume
 outstanding and do not represent the amount of the Company’s
 exposure to credit or market loss. The credit risk amounts
 represent the Company’s gross exposure to potential
 accounting loss on derivative instruments that are outstanding or
 unsettled if all counterparties failed to perform according to the
 terms of the contract, based on then-current currency or interest rates at
 each respective date. The Company’s exposure to credit loss
 and market risk will vary over time as currency and interest rates
 change. Although the table above reflects the notional and credit
 risk amounts of the Company’s derivative instruments, it does
 not reflect the gains or losses associated with the exposures and
 transactions that the instruments are intended to hedge. The
 amounts ultimately realized upon settlement of these financial
 instruments, together with the gains and losses on the underlying
 exposures, will depend on actual market conditions during the
 remaining life of the instruments.

[0001193125-16-559625:notes:75]
The Company generally enters into master netting
 arrangements, which are designed to reduce credit risk by
 permitting net settlement of transactions with the same
 counterparty. To further limit credit risk, the Company generally
 enters into collateral security arrangements that provide for
 collateral to be received or posted when the net fair value of
 certain financial instruments fluctuates from contractually
 established thresholds. The Company presents its derivative assets
 and derivative liabilities at their gross fair values in its
 Condensed Consolidated Balance Sheets. As of March 26, 2016,
 the net cash collateral posted by the Company related to derivative
 instruments under its collateral security arrangements was $3
 million, which was recorded as other current assets in the
 Condensed Consolidated Balance Sheet. As of September 26,
 2015, the net cash collateral received by the Company related to
 derivative instruments under its collateral security arrangements
 was $1.0 billion, which was recorded as accrued expenses in the
 Condensed Consolidated Balance Sheet.

[0001193125-16-559625:notes:76]
Under master netting arrangements with the
 respective counterparties to the Company’s derivative
 contracts, the Company is allowed to net settle transactions
 with a single net amount payable by one party to the other. As of
 March 26, 2016 and September 26, 2015, the potential
 effects of these rights of set-off associated with the
 Company’s derivative contracts, including the effects of
 collateral, would be a reduction to both derivative assets and
 derivative liabilities of $1.4 billion and $2.2 billion,
 respectively, resulting in net derivative liabilities
 of $119 million and $78 million, respectively.

[0001193125-16-559625:notes:77]
[same as prior period, unchanged from 0001193125-16-439878:notes:74]

[0001193125-16-559625:notes:78]
[same as prior period, unchanged from 0001193125-16-439878:notes:75]

[0001193125-16-559625:notes:79]
The Company has considerable trade receivables
 outstanding with its third-party cellular network carriers,
 wholesalers, retailers, value-added resellers, small and mid-sized
 businesses and education, enterprise and government customers that
 are not covered by collateral, third-party financing arrangements
 or credit insurance. As of March 26, 2016 and
 September 26, 2015, the Company had one customer that
 represented 12% of total trade receivables. The Company’s
 cellular network carriers accounted for 55% and 71% of trade
 receivables as of March 26, 2016 and September 26, 2015,
 respectively.

[0001193125-16-559625:notes:80]
[same as prior period, unchanged from 0001193125-16-439878:notes:77]

[0001193125-16-559625:notes:81]
The Company has non-trade receivables from certain
 of its manufacturing vendors resulting from the sale of components
 to these vendors who manufacture sub-assemblies or assemble final
 products for the Company. Vendor non-trade receivables from three
 of the Company’s vendors accounted for 55%, 14% and 11% of
 total vendor non-trade receivables as of March 26, 2016 and
 three of the Company’s vendors accounted for 38%, 18% and 14%
 of total vendor non-trade receivables as of September 26,
 2015.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001193125-16-559625:notes:82]
[same as prior period, unchanged from 0001193125-16-439878:notes:79]

[0001193125-16-559625:notes:83]
[same as prior period, unchanged from 0001193125-16-439878:notes:80]


## us-gaap:OtherNoncurrentLiabilitiesTableTextBlock

[0001193125-16-559625:notes:84]
[same as prior period, unchanged from 0001193125-16-439878:notes:81]

[0001193125-16-559625:notes:85]
|  |  | March 26, 2016 |  |  | September 26, 2015 |  |
| Deferred tax liabilities |  | $ | 22,955 |  |  | $ | 24,062 |  |
| Other non-current liabilities |  |  | 10,904 |  |  |  | 9,365 |  |
| Total other non-current liabilities |  | $ | 33,859 |  |  | $ | 33,427 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001193125-16-559625:notes:86]
[same as prior period, unchanged from 0001193125-16-439878:notes:83]

[0001193125-16-559625:notes:87]
|  |  | March 26, 2016 |  |  | September 26, 2015 |  |
| Land and buildings |  | $ | 8,391 |  |  | $ | 6,956 |  |
| Machinery, equipment and internal-use software |  |  | 39,723 |  |  |  | 37,038 |  |
| Leasehold improvements |  |  | 5,937 |  |  |  | 5,263 |  |
| Gross property, plant and equipment |  |  | 54,051 |  |  |  | 49,257 |  |
| Accumulated depreciation and amortization |  |  | (30,848 | ) |  |  | (26,786 | ) |
| Total property, plant and equipment, net |  | $ | 23,203 |  |  | $ | 22,471 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-16-559625:notes:88]
[same as prior period, unchanged from 0001193125-16-439878:notes:85]

[0001193125-16-559625:notes:89]
[same as prior period, unchanged from 0001193125-16-439878:notes:86]

[0001193125-16-559625:notes:90]
The following table shows the pre-tax amounts
 reclassified from AOCI into the Condensed Consolidated Statements
 of Operations, and the associated financial statement line item,
 for the three- and six-month periods ended March 26, 2016 and
 March 28, 2015 (in millions):

[0001193125-16-559625:notes:91]
|  |  |  |  | Three Months Ended |  |  | Six Months Ended |  |
| Comprehensive Income Components |  | Financial Statement Line Item |  | March 26, 2016 |  |  | March 28, 2015 |  |  | March 26, 2016 |  |  | March 28, 2015 |  |
| Unrealized (gains)/losses on derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Revenue |  | $ | (325 | ) |  | $ | (558 | ) |  | $ | (654 | ) |  | $ | (1,007 | ) |
|  |  | Cost of sales |  |  | (219 | ) |  |  | (608 | ) |  |  | (525 | ) |  |  | (921 | ) |
|  |  | Other income/(expense), net |  |  | (131 | ) |  |  | 348 |  |  |  | (11 | ) |  |  | 443 |  |
| Interest rate contracts |  | Other income/(expense), net |  |  | 3 |  |  |  | 4 |  |  |  | 7 |  |  |  | 8 |  |
|  |  |  |  |  | (672 | ) |  |  | (814 | ) |  |  | (1,183 | ) |  |  | (1,477 | ) |
| Unrealized (gains)/losses on marketable securities |  | Other income/(expense), net |  |  | 76 |  |  |  | 56 |  |  |  | 149 |  |  |  | 34 |  |
| Total amounts reclassified from AOCI |  |  |  | $ | (596 | ) |  | $ | (758 | ) |  | $ | (1,034 | ) |  | $ | (1,443 | ) |

[0001193125-16-559625:notes:92]
The following table shows the changes in AOCI by component for the
 six months ended March 26, 2016 (in millions):

[0001193125-16-559625:notes:93]
|  |  | Cumulative Foreign Currency Translation |  |  | Unrealized Gains/Losses on Derivative Instruments |  |  | Unrealized Gains/Losses on Marketable Securities |  |  | Total |  |
| Balance at September 26, 2015 |  | $ | (653 | ) |  | $ | 772 |  |  | $ | (464 | ) |  | $ | (345 | ) |
| Other comprehensive income/(loss) before reclassifications |  |  | 18 |  |  |  | 146 |  |  |  | 69 |  |  |  | 233 |  |
| Amounts reclassified from AOCI |  |  | 0 |  |  |  | (1,183 | ) |  |  | 149 |  |  |  | (1,034 | ) |
| Tax effect |  |  | 0 |  |  |  | 173 |  |  |  | (75 | ) |  |  | 98 |  |
| Other comprehensive income/(loss) |  |  | 18 |  |  |  | (864 | ) |  |  | 143 |  |  |  | (703 | ) |
| Balance at March 26, 2016 |  | $ | (635 | ) |  | $ | (92 | ) |  | $ | (321 | ) |  | $ | (1,048 | ) |


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001193125-16-559625:notes:94]
[same as prior period, unchanged from 0001193125-16-439878:notes:91]

[0001193125-16-559625:notes:95]
[same as prior period, unchanged from 0001193125-16-439878:notes:92]

[0001193125-16-559625:notes:96]
The Company had 377.3 million shares reserved
 for future issuance under its stock plans as of March 26,
 2016. RSUs granted generally vest over four years, based on
 continued employment, and are settled upon vesting in shares of the
 Company’s common stock on a one-for-one basis. Each share
 issued with respect to RSUs granted under the Company’s stock
 plans reduces the number of shares available for grant under the
 plan by two shares. RSUs cancelled and shares withheld to satisfy
 tax withholding obligations increase the number of shares available
 for grant under the plans utilizing a factor of two times the
 number of RSUs cancelled or shares withheld. Stock options count
 against the number of shares available for grant on a one-for-one
 basis.

[0001193125-16-559625:notes:97]
[same as prior period, unchanged from 0001193125-16-439878:notes:94]

[0001193125-16-559625:notes:98]
During the three months ended March 26, 2016,
 Section 16 officers Timothy D. Cook, Angela Ahrendts, Luca
 Maestri, Daniel Riccio, Philip Schiller and Jeffrey Williams had
 equity trading plans in place in accordance with Rule 10b5-1(c)(1)
 under the Exchange Act. An equity trading plan is a written
 document that pre-establishes the amounts, prices and dates (or
 formula for determining the amounts, prices and dates) of future
 purchases or sales of the Company’s stock, including shares
 acquired pursuant to the Company’s employee and director
 equity plans.

[0001193125-16-559625:notes:99]
[same as prior period, unchanged from 0001193125-16-439878:notes:96]

[0001193125-16-559625:notes:100]
A summary of the Company’s RSU activity and
 related information for the six months ended March 26, 2016 is
 as follows:

[0001193125-16-559625:notes:101]
|  |  | Number of RSUs (in thousands) |  |  | Weighted-Average Grant Date Fair Value Per Share |  |  | Aggregate Intrinsic Value (in millions) |  |
| Balance at September 26, 2015 |  |  | 101,467 |  |  | $ | 85.77 |  |  |  |  |  |
| RSUs granted |  |  | 43,513 |  |  | $ | 110.57 |  |  |  |  |  |
| RSUs vested |  |  | (22,353 | ) |  | $ | 78.86 |  |  |  |  |  |
| RSUs cancelled |  |  | (2,413 | ) |  | $ | 93.43 |  |  |  |  |  |
| Balance at March 26, 2016 |  |  | 120,214 |  |  | $ | 95.80 |  |  | $ | 12,703 |  |

[0001193125-16-559625:notes:102]
RSUs that vested during the three- and six-month
 periods ended March 26, 2016 had fair values of $450 million
 and $2.5 billion, respectively, as of the vesting date. RSUs that
 vested during the three- and six-month periods ended March 28,
 2015 had fair values of $317 million and $2.0 billion,
 respectively, as of the vesting date.

[0001193125-16-559625:notes:103]
[same as prior period, unchanged from 0001193125-16-439878:notes:100]

[0001193125-16-559625:notes:104]
The Company had 1.1 million stock options
 outstanding as of March 26, 2016, with a weighted-average
 exercise price per share of $15.48 and weighted-average remaining
 contractual term of 3.7 years, substantially all of which are
 exercisable. The aggregate intrinsic value of the stock options
 outstanding as of March 26, 2016 was $100 million, which
 represents the value of the Company’s closing stock price on
 the last trading day of the period in excess of the
 weighted-average exercise price multiplied by the number of options
 outstanding.

[0001193125-16-559625:notes:105]
[same as prior period, unchanged from 0001193125-16-439878:notes:102]

[0001193125-16-559625:notes:106]
The following table shows a summary of the
 share-based compensation expense included in the Condensed
 Consolidated Statements of Operations for the three- and six-month
 periods ended March 26, 2016 and March 28, 2015 (in
 millions):

[0001193125-16-559625:notes:107]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 26, 2016 |  |  | March 28, 2015 |  |  | March 26, 2016 |  |  | March 28, 2015 |  |
| Cost of sales |  | $ | 191 |  |  | $ | 142 |  |  | $ | 395 |  |  | $ | 282 |  |
| Research and development |  |  | 468 |  |  |  | 384 |  |  |  | 934 |  |  |  | 758 |  |
| Selling, general and administrative |  |  | 389 |  |  |  | 401 |  |  |  | 797 |  |  |  | 775 |  |
| Total share-based compensation expense |  | $ | 1,048 |  |  | $ | 927 |  |  | $ | 2,126 |  |  | $ | 1,815 |  |

[0001193125-16-559625:notes:108]
The income tax benefit related to share-based
 compensation expense was $347 million and $760 million for the
 three- and six-month periods ended March 26, 2016,
 respectively, and was $311 million and $662 million for the three-
 and six-month periods ended March 28, 2015, respectively. As
 of March 26, 2016, the total unrecognized compensation cost
 related to outstanding stock options, RSUs and restricted stock was
 $9.1 billion, which the Company expects to recognize over a
 weighted-average period of 2.9 years.


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001193125-16-559625:notes:109]
The following table shows changes in the
 Company’s accrued warranties and related costs for the three-
 and six-month periods ended March 26, 2016 and March 28,
 2015 (in millions):

[0001193125-16-559625:notes:110]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 26, 2016 |  |  | March 28, 2015 |  |  | March 26, 2016 |  |  | March 28, 2015 |  |
| Beginning accrued warranty and related costs |  | $ | 5,236 |  |  | $ | 5,195 |  |  | $ | 4,780 |  |  | $ | 4,159 |  |
| Cost of warranty claims |  |  | (1,128 | ) |  |  | (1,030 | ) |  |  | (2,397 | ) |  |  | (2,074 | ) |
| Accruals for product warranty |  |  | 877 |  |  |  | 978 |  |  |  | 2,602 |  |  |  | 3,058 |  |
| Ending accrued warranty and related costs |  | $ | 4,985 |  |  | $ | 5,143 |  |  | $ | 4,985 |  |  | $ | 5,143 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-16-559625:notes:111]
[same as prior period, unchanged from 0001193125-16-439878:notes:108]

[0001193125-16-559625:notes:112]
As of March 26, 2016, the Company recorded
 gross unrecognized tax benefits of $7.5 billion, of which $2.8
 billion, if recognized, would affect the Company’s effective
 tax rate. As of September 26, 2015, the total amount of gross
 unrecognized tax benefits was $6.9 billion, of which $2.5 billion,
 if recognized, would have affected the Company’s effective
 tax rate. The Company’s total gross unrecognized tax benefits
 are classified as other non-current liabilities in the Condensed
 Consolidated Balance Sheets. The Company had $1.5 billion and $1.3
 billion of gross interest and penalties accrued as of
 March 26, 2016 and September 26, 2015, respectively,
 which are classified as other non-current liabilities in the
 Condensed Consolidated Balance Sheets.

[0001193125-16-559625:notes:113]
Management believes that an adequate provision has
 been made for any adjustments that may result from tax
 examinations. However, the outcome of tax audits cannot be
 predicted with certainty. If any issues addressed in the
 Company’s tax audits are resolved in a manner not consistent
 with management’s expectations, the Company could be required
 to adjust its provision for income taxes in the period such
 resolution occurs. Although timing of the resolution and/or closure
 of audits is not certain, the Company believes it is reasonably
 possible that its gross unrecognized tax benefits could decrease
 (whether by payment, release or a combination of both) in the next
 12 months by as much as $800 million.

[0001193125-16-559625:notes:114]
On June 11, 2014, the European Commission
 issued an opening decision initiating a formal investigation
 against Ireland for alleged state aid to the Company. The opening
 decision concerns the allocation of profits for taxation purposes
 of the Irish branches of two subsidiaries of the Company. The
 Company believes the European Commission’s assertions are
 without merit. If the European Commission were to conclude against
 Ireland, the European Commission could require Ireland to recover
 from the Company past taxes covering a period of up to 10 years
 reflective of the disallowed state aid. While such amount could be
 material, as of March 26, 2016 the Company is unable to
 estimate the impact.


## us-gaap:InterestAndOtherIncomeTableTextBlock

[0001193125-16-559625:notes:115]
[same as prior period, unchanged from 0001193125-16-439878:notes:112]

[0001193125-16-559625:notes:116]
The following table shows the detail of other
 income/(expense), net for the three- and six-month periods ended
 March 26, 2016 and March 28, 2015 (in millions):

[0001193125-16-559625:notes:117]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 26, 2016 |  |  | March 28, 2015 |  |  | March 26, 2016 |  |  | March 28, 2015 |  |
| Interest and dividend income |  | $ | 986 |  |  | $ | 675 |  |  | $ | 1,927 |  |  | $ | 1,329 |  |
| Interest expense |  |  | (321 | ) |  |  | (163 | ) |  |  | (597 | ) |  |  | (294 | ) |
| Other expense, net |  |  | (510 | ) |  |  | (226 | ) |  |  | (773 | ) |  |  | (579 | ) |
| Total other income/(expense), net |  | $ | 155 |  |  | $ | 286 |  |  | $ | 557 |  |  | $ | 456 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-16-559625:notes:118]
[same as prior period, unchanged from 0001193125-16-439878:notes:115]

[0001193125-16-559625:notes:119]
[same as prior period, unchanged from 0001193125-16-439878:notes:116]

[0001193125-16-559625:notes:120]
Future dividends are subject to declaration by the Board of
 Directors.

[0001193125-16-559625:notes:121]
[same as prior period, unchanged from 0001193125-16-439878:notes:118]

[0001193125-16-559625:notes:122]
In 2015, the Company’s Board of Directors
 increased the share repurchase authorization to $140 billion of the
 Company’s common stock, of which $117 billion had been
 utilized as of March 26, 2016. The Company’s share
 repurchase program does not obligate it to acquire any specific
 number of shares. Under the program, shares may be repurchased in
 privately negotiated and/or open market transactions, including
 under plans complying with Rule 10b5-1 under the Securities
 Exchange Act of 1934, as amended (the “Exchange
 Act”).

[0001193125-16-559625:notes:123]
[same as prior period, unchanged from 0001193125-16-439878:notes:120]

[0001193125-16-559625:notes:124]
[same as prior period, unchanged from 0001193125-16-439878:notes:121]

[0001193125-16-559625:notes:125]
|  |  | Number of Shares (in thousands) |  |  | Average Repurchase Price Per Share |  |  | Amount (in millions) |  |
| 2016: |  |  |  |  |  |  |  |  |  |  |  |  |
| Second quarter |  |  | 71,766 |  |  | $ | 97.54 |  |  | $ | 7,000 |  |
| First quarter |  |  | 25,984 |  |  | $ | 115.45 |  |  |  | 3,000 |  |
| Total open market common stock repurchases |  |  | 97,750 |  |  |  |  |  |  | $ | 10,000 |  |
| 2015: |  |  |  |  |  |  |  |  |  |  |  |  |
| Fourth quarter |  |  | 121,802 |  |  | $ | 115.15 |  |  | $ | 14,026 |  |
| Third quarter |  |  | 31,231 |  |  | $ | 128.08 |  |  |  | 4,000 |  |
| Second quarter |  |  | 56,400 |  |  | $ | 124.11 |  |  |  | 7,000 |  |
| First quarter |  |  | 45,704 |  |  | $ | 109.40 |  |  |  | 5,000 |  |
| Total open market common stock repurchases |  |  | 255,137 |  |  |  |  |  |  | $ | 30,026 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-16-559625:notes:126]
Note 10 – Commitments and Contingencies

[0001193125-16-559625:notes:127]
Accrued Warranty and Indemnification

[0001193125-16-559625:notes:128]
The Company generally does not indemnify end-users
 of its operating system and application software against legal
 claims that the software infringes third-party intellectual
 property rights. Other agreements entered into by the Company
 sometimes include indemnification provisions under which the
 Company could be subject to costs and/or damages in the event of an
 infringement claim against the Company or an indemnified
 third-party. In the opinion of management, there was not at least a
 reasonable possibility the Company may have incurred a material
 loss with respect to indemnification of end-users of its operating
 system or application software for infringement of third-party
 intellectual property rights.

[0001193125-16-559625:notes:129]
The Company offers an iPhone Upgrade Program, which
 is available to customers who purchase an iPhone 6s and 6s Plus in
 one of its U.S. physical retail stores and activate the purchased
 iPhone with one of the four national carriers. The iPhone Upgrade
 Program provides customers the right to trade in that iPhone for a
 new iPhone, provided certain conditions are met. One of the
 conditions of this program requires the customer to finance the
 initial purchase price of the iPhone with a third-party lender.
 Upon exercise of the trade-in right and purchase of a new iPhone,
 the Company satisfies the customer’s outstanding balance due
 to the third-party lender on the original device. The Company
 accounts for the trade-in right as a guarantee liability and
 recognizes arrangement revenue net of the fair value of such right
 with subsequent changes to the guarantee liability recognized
 within revenue.

[0001193125-16-559625:notes:130]
The Company has entered into indemnification
 agreements with its directors and executive officers. Under these
 agreements, the Company has agreed to indemnify such individuals to
 the fullest extent permitted by law against liabilities that arise
 by reason of their status as directors or officers and to advance
 expenses incurred by such individuals in connection with related
 legal proceedings. It is not possible to determine the maximum
 potential amount of payments the Company could be required to make
 under these agreements due to the limited history of prior
 indemnification claims and the unique facts and circumstances
 involved in each claim. However, the Company maintains directors
 and officers liability insurance coverage to reduce its exposure to
 such obligations.

[0001193125-16-559625:notes:131]
Concentrations in the Available Sources of Supply of Materials
 and Product

[0001193125-16-559625:notes:132]
Although most components essential to the
 Company’s business are generally available from multiple
 sources, a number of components are currently obtained from single
 or limited sources. In addition, the Company competes for various
 components with other participants in the markets for mobile
 communication and media devices and personal computers. Therefore,
 many components used by the Company, including those that are
 available from multiple sources, are at times subject to
 industry-wide shortage and significant pricing fluctuations that
 could materially adversely affect the Company’s financial
 condition and operating results.

[0001193125-16-559625:notes:133]
The Company uses some custom components that are
 not commonly used by its competitors, and new products introduced
 by the Company often utilize custom components available from only
 one source. When a component or product uses new technologies,
 initial capacity constraints may exist until the suppliers’
 yields have matured or manufacturing capacity has increased. If the
 Company’s supply of components for a new or existing product
 were delayed or constrained, or if an outsourcing partner delayed
 shipments of completed products to the Company, the Company’s
 financial condition and operating results could be materially
 adversely affected. The Company’s business and financial
 performance could also be materially adversely affected depending
 on the time required to obtain sufficient quantities from the
 original source, or to identify and obtain sufficient quantities
 from an alternative source. Continued availability of these
 components at acceptable prices, or at all, may be affected if
 those suppliers concentrated on the production of common components
 instead of components customized to meet the Company’s
 requirements.

[0001193125-16-559625:notes:134]
The Company has entered into agreements for the
 supply of many components; however, there can be no guarantee that
 the Company will be able to extend or renew these agreements on
 similar terms, or at all. Therefore, the Company remains subject to
 significant risks of supply shortages and price increases that
 could materially adversely affect its financial condition and
 operating results.

[0001193125-16-559625:notes:135]
Substantially all of the Company’s hardware
 products are manufactured by outsourcing partners that are located
 primarily in Asia. A significant concentration of this
 manufacturing is currently performed by a small number of
 outsourcing partners, often in single locations. Certain of these
 outsourcing partners are the sole-sourced suppliers of components
 and manufacturers for many of the Company’s products.
 Although the Company works closely with its outsourcing partners on
 manufacturing schedules, the Company’s operating results
 could be adversely affected if its outsourcing partners were unable
 to meet their production commitments. The Company’s purchase
 commitments typically cover its requirements for periods up to 150
 days.

[0001193125-16-559625:notes:136]
Other Off-Balance Sheet Commitments

[0001193125-16-559625:notes:137]
Operating Leases

[0001193125-16-559625:notes:138]
The Company leases various equipment and
 facilities, including retail space, under noncancelable operating
 lease arrangements. The major facility leases are typically for
 terms not exceeding 10 years and generally contain multi-year
 renewal options. As of March 26, 2016, the Company had a total
 of 475 retail stores. Leases for retail space are for terms ranging
 from five to 20 years, the majority of which are for 10 years, and
 often contain multi-year renewal options. As of March 26,
 2016, the Company’s total future minimum lease payments under
 noncancelable operating leases were $6.8 billion, of which $3.9
 billion related to leases for retail space.

[0001193125-16-559625:notes:139]
Contingencies

[0001193125-16-559625:notes:140]
The Company is subject to various legal proceedings
 and claims that have arisen in the ordinary course of business and
 that have not been fully adjudicated, certain of which are
 discussed in Part II, Item 1 of this Form 10-Q under the
 heading “Legal Proceedings” and in Part II,
 Item 1A of this Form 10-Q under the heading “Risk
 Factors.” In the opinion of management, there was not at
 least a reasonable possibility the Company may have incurred a
 material loss, or a material loss in excess of a recorded accrual,
 with respect to loss contingencies for asserted legal and other
 claims. However, the outcome of litigation is inherently uncertain.
 Therefore, although management considers the likelihood of such an
 outcome to be remote, if one or more of these legal matters were
 resolved against the Company in a reporting period for amounts in
 excess of management’s expectations, the Company’s
 consolidated financial statements for that reporting period could
 be materially adversely affected.

[0001193125-16-559625:notes:141]
Apple Inc. v. Samsung Electronics Co., Ltd., et al.

[0001193125-16-559625:notes:142]
On August 24, 2012, a jury returned a verdict
 awarding the Company $1.05 billion in its lawsuit against Samsung
 Electronics Co., Ltd. and affiliated parties in the United States
 District Court, Northern District of California, San Jose Division.
 On March 6, 2014, the District Court entered final judgment in
 favor of the Company in the amount of approximately $930
 million. On May 18, 2015, the U.S. Court of Appeals for
 the Federal Circuit affirmed in part, and reversed in part, the
 decision of the District Court. As a result, the Court of Appeals
 ordered entry of final judgment on damages in the amount of
 approximately $548 million, with the District Court to determine
 supplemental damages and interest, as well as damages owed for
 products subject to the reversal in part. Samsung paid $548 million
 to the Company in December 2015, which was included in net sales in
 the Condensed Consolidated Statement of Operations.
 Because the case remains subject to further proceedings, the
 Company has not recognized any further amounts in its results of
 operations. On March 21, 2016, the United States Supreme Court
 agreed to hear Samsung’s request for appeal related to the
 $548 million in damages.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001193125-16-559625:notes:143]
[same as prior period, unchanged from 0001193125-16-439878:notes:140]

[0001193125-16-559625:notes:144]
The following tables show the Company’s
 condensed consolidated financial statement details as of
 March 26, 2016 and September 26, 2015 (in millions):
