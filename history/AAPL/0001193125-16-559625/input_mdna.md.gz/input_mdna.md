# AAPL MD&A — 0001193125-16-559625


## mdna

[0001193125-16-559625:mdna:1]
[same as prior period, unchanged from 0001193125-16-439878:mdna:1]

[0001193125-16-559625:mdna:2]
[same as prior period, unchanged from 0001193125-16-439878:mdna:2]

[0001193125-16-559625:mdna:3]
[same as prior period, unchanged from 0001193125-16-439878:mdna:3]

[0001193125-16-559625:mdna:4]
[same as prior period, unchanged from 0001193125-16-439878:mdna:4]

[0001193125-16-559625:mdna:5]
[same as prior period, unchanged from 0001193125-16-439878:mdna:5]

[0001193125-16-559625:mdna:6]
The Company designs, manufactures and markets mobile communication and media devices, personal computers and portable digital music players, and sells a
variety of related software, services, accessories, networking solutions and third-party digital content and applications. The Company’s products and services include iPhone®, iPad®, Mac®, iPod®, Apple
Watch®, Apple TV®, a portfolio of consumer and professional software applications, iOS, OS X®, watchOS® and tvOS™ operating systems, iCloud®, Apple Pay® and a variety of accessory, service and support offerings. The Company sells and delivers digital content and applications through the iTunes
Store®, App Store®, Mac App Store, TV App Store, iBooks Store™ and Apple Music™ (collectively “Internet Services”).
The Company sells its products worldwide through its retail stores, online stores and direct sales force, as well as through third-party cellular network carriers, wholesalers, retailers and value-added resellers. In addition, the Company sells a
variety of third-party Apple compatible products, including application software and various accessories through its online and retail stores. The Company sells to consumers, small and mid-sized businesses and education, enterprise and government
customers.

[0001193125-16-559625:mdna:7]
[same as prior period, unchanged from 0001193125-16-439878:mdna:7]

[0001193125-16-559625:mdna:8]
The Company is committed to
bringing the best user experience to its customers through its innovative hardware, software and services. The Company’s business strategy leverages its unique ability to design and develop its own operating systems, hardware, application
software and services to provide its customers products and solutions with innovative design, superior ease-of-use and seamless integration. As part of its strategy, the Company continues to expand its platform for the discovery and delivery of
digital content and applications through its Internet Services, which allows customers to discover and download digital content, iOS, Mac, Apple Watch and Apple TV applications, and books through either a Mac or Windows-based computer or through
iPhone, iPad and iPod touch® devices (“iOS devices”) and Apple Watch. The Company also supports a community for the development of third-party software and hardware products and
digital content that complement the Company’s offerings. The Company believes a high-quality buying experience with knowledgeable salespersons who can convey the value of the Company’s products and services greatly enhances its ability to
attract and retain customers. Therefore, the Company’s strategy also includes building and expanding its own retail and online stores and its third-party distribution network to effectively reach more customers and provide them with a
high-quality sales and post-sales support experience. The Company believes ongoing investment in research and development (“R&D”), marketing and advertising is critical to the development and sale of innovative products and
technologies.

[0001193125-16-559625:mdna:9]
[same as prior period, unchanged from 0001193125-16-439878:mdna:9]

[0001193125-16-559625:mdna:10]
[same as prior period, unchanged from 0001193125-16-439878:mdna:10]

[0001193125-16-559625:mdna:11]
Second Quarter Fiscal 2016 Highlights

[0001193125-16-559625:mdna:12]
Net sales decreased 13% or $7.5 billion during the second quarter of 2016 compared to the same quarter in 2015, primarily driven by lower iPhone sales and
the effect of weakness in most foreign currencies relative to the U.S. dollar. The Company had strong year-over-year net sales growth in Services and Other Products. During the second quarter of 2016, the Company introduced iPhone SE and the
9.7-inch iPad Pro™, both of which were available beginning in the third quarter of 2016.

[0001193125-16-559625:mdna:13]
The Company utilized $7.0 billion to repurchase shares
of its common stock and paid dividends and dividend equivalents of $2.9 billion during the second quarter of 2016. Additionally, the Company issued $15.5 billion of U.S. dollar-denominated long-term debt.

[0001193125-16-559625:mdna:14]
[same as prior period, unchanged from 0001193125-16-439878:mdna:14]

[0001193125-16-559625:mdna:15]
The following table shows net sales by operating
segment and net sales and unit sales by product for the three- and six-month periods ended March 26, 2016 and March 28, 2015 (dollars in millions and units in thousands):

[0001193125-16-559625:mdna:16]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 26,2016 |  |  | March 28,2015 |  |  | Change |  |  | March 26,2016 |  |  | March 28,2015 |  |  | Change |  |
| Net Sales by Operating Segment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 19,096 |  |  | $ | 21,316 |  |  |  | (10)% |  |  | $ | 48,421 |  |  | $ | 51,882 |  |  |  | (7)% |  |
| Europe |  |  | 11,535 |  |  |  | 12,204 |  |  |  | (5)% |  |  |  | 29,467 |  |  |  | 29,418 |  |  |  | 0% |  |
| Greater China |  |  | 12,486 |  |  |  | 16,823 |  |  |  | (26)% |  |  |  | 30,859 |  |  |  | 32,967 |  |  |  | (6)% |  |
| Japan |  |  | 4,281 |  |  |  | 3,457 |  |  |  | 24% |  |  |  | 9,075 |  |  |  | 8,905 |  |  |  | 2% |  |
| Rest of Asia Pacific |  |  | 3,159 |  |  |  | 4,210 |  |  |  | (25)% |  |  |  | 8,607 |  |  |  | 9,437 |  |  |  | (9)% |  |
| Total net sales |  | $ | 50,557 |  |  | $ | 58,010 |  |  |  | (13)% |  |  | $ | 126,429 |  |  | $ | 132,609 |  |  |  | (5)% |  |
| Net Sales by Product: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| iPhone (1) |  | $ | 32,857 |  |  | $ | 40,282 |  |  |  | (18)% |  |  | $ | 84,492 |  |  | $ | 91,464 |  |  |  | (8)% |  |
| iPad (1) |  |  | 4,413 |  |  |  | 5,428 |  |  |  | (19)% |  |  |  | 11,497 |  |  |  | 14,413 |  |  |  | (20)% |  |
| Mac (1) |  |  | 5,107 |  |  |  | 5,615 |  |  |  | (9)% |  |  |  | 11,853 |  |  |  | 12,559 |  |  |  | (6)% |  |
| Services (2) |  |  | 5,991 |  |  |  | 4,996 |  |  |  | 20% |  |  |  | 12,047 |  |  |  | 9,795 |  |  |  | 23% |  |
| Other Products (1)(3) |  |  | 2,189 |  |  |  | 1,689 |  |  |  | 30% |  |  |  | 6,540 |  |  |  | 4,378 |  |  |  | 49% |  |
| Total net sales |  | $ | 50,557 |  |  | $ | 58,010 |  |  |  | (13)% |  |  | $ | 126,429 |  |  | $ | 132,609 |  |  |  | (5)% |  |
| Unit Sales by Product: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| iPhone |  |  | 51,193 |  |  |  | 61,170 |  |  |  | (16)% |  |  |  | 125,972 |  |  |  | 135,638 |  |  |  | (7)% |  |
| iPad |  |  | 10,251 |  |  |  | 12,623 |  |  |  | (19)% |  |  |  | 26,373 |  |  |  | 34,042 |  |  |  | (23)% |  |
| Mac |  |  | 4,034 |  |  |  | 4,563 |  |  |  | (12)% |  |  |  | 9,346 |  |  |  | 10,082 |  |  |  | (7)% |  |

[0001193125-16-559625:mdna:17]
[same as prior period, unchanged from 0001193125-16-439878:mdna:17]

[0001193125-16-559625:mdna:18]
[same as prior period, unchanged from 0001193125-16-439878:mdna:18]

[0001193125-16-559625:mdna:19]
[same as prior period, unchanged from 0001193125-16-439878:mdna:19]

[0001193125-16-559625:mdna:20]
[same as prior period, unchanged from 0001193125-16-439878:mdna:20]

[0001193125-16-559625:mdna:21]
[same as prior period, unchanged from 0001193125-16-439878:mdna:21]

[0001193125-16-559625:mdna:22]
The following table presents iPhone net sales and unit sales information for the three- and six-month periods ended March 26, 2016 and
March 28, 2015 (dollars in millions and units in thousands):

[0001193125-16-559625:mdna:23]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 26,2016 |  |  | March 28,2015 |  |  | Change |  |  | March 26,2016 |  |  | March 28,2015 |  |  | Change |  |
| Net sales |  | $ | 32,857 |  |  | $ | 40,282 |  |  |  | (18)% |  |  | $ | 84,492 |  |  | $ | 91,464 |  |  |  | (8)% |  |
| Percentage of total net sales |  |  | 65% |  |  |  | 69% |  |  |  |  |  |  |  | 67% |  |  |  | 69% |  |  |  |  |  |
| Unit sales |  |  | 51,193 |  |  |  | 61,170 |  |  |  | (16)% |  |  |  | 125,972 |  |  |  | 135,638 |  |  |  | (7)% |  |

[0001193125-16-559625:mdna:24]
iPhone net sales and unit sales decreased during the second quarter and first six months of 2016 compared to the same
periods in 2015. The Company believes the unit sales decline is due primarily to the acceleration of iPhone upgrades in the first half of 2015 and challenging macroeconomic conditions around the world. Average selling prices (“ASPs”) for
iPhone were lower year-over-year during the second quarter and first six months of 2016 due to a change in the mix of iPhones and the effect of weakness in foreign currencies relative to the U.S. dollar.

[0001193125-16-559625:mdna:25]
[same as prior period, unchanged from 0001193125-16-439878:mdna:25]

[0001193125-16-559625:mdna:26]
The following table presents iPad net sales and unit
sales information for the three- and six-month periods ended March 26, 2016 and March 28, 2015 (dollars in millions and units in thousands):

[0001193125-16-559625:mdna:27]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 26,2016 |  |  | March 28,2015 |  |  | Change |  |  | March 26,2016 |  |  | March 28,2015 |  |  | Change |  |
| Net sales |  | $ | 4,413 |  |  | $ | 5,428 |  |  |  | (19)% |  |  | $ | 11,497 |  |  | $ | 14,413 |  |  |  | (20)% |  |
| Percentage of total net sales |  |  | 9% |  |  |  | 9% |  |  |  |  |  |  |  | 9% |  |  |  | 11% |  |  |  |  |  |
| Unit sales |  |  | 10,251 |  |  |  | 12,623 |  |  |  | (19)% |  |  |  | 26,373 |  |  |  | 34,042 |  |  |  | (23)% |  |

[0001193125-16-559625:mdna:28]
iPad net sales and unit sales declined during the second quarter and first six months of 2016 compared to the same
periods in 2015. The Company believes the decline in iPad sales is due in part to a longer repurchase cycle for iPads and some level of cannibalization from the Company’s other products. Year-over-year ASPs for iPad were flat during the second
quarter of 2016 and increased 3% during the first six months of 2016 due primarily to a shift in mix to higher-capacity iPads and the launch of iPad Pro, partially offset by the effect of weakness in foreign currencies relative to the U.S. dollar.

[0001193125-16-559625:mdna:29]
[same as prior period, unchanged from 0001193125-16-439878:mdna:29]

[0001193125-16-559625:mdna:30]
The following table presents Mac net sales and unit
sales information for the three- and six-month periods ended March 26, 2016 and March 28, 2015 (dollars in millions and units in thousands):

[0001193125-16-559625:mdna:31]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 26,2016 |  |  | March 28,2015 |  |  | Change |  |  | March 26,2016 |  |  | March 28,2015 |  |  | Change |  |
| Net sales |  | $ | 5,107 |  |  | $ | 5,615 |  |  |  | (9)% |  |  | $ | 11,853 |  |  | $ | 12,559 |  |  |  | (6)% |  |
| Percentage of total net sales |  |  | 10% |  |  |  | 10% |  |  |  |  |  |  |  | 9% |  |  |  | 9% |  |  |  |  |  |
| Unit sales |  |  | 4,034 |  |  |  | 4,563 |  |  |  | (12)% |  |  |  | 9,346 |  |  |  | 10,082 |  |  |  | (7)% |  |

[0001193125-16-559625:mdna:32]
Mac net sales and unit sales declined during the second quarter and first six months of 2016 compared to the same periods
in 2015, similar to the overall market contraction. Mac ASPs increased during the second quarter and first six months of 2016 compared to the same periods in 2015 due primarily to a change in the mix of Macs, partially offset by the effect of
weakness in foreign currencies relative to the U.S. dollar.

[0001193125-16-559625:mdna:33]
[same as prior period, unchanged from 0001193125-16-439878:mdna:33]

[0001193125-16-559625:mdna:34]
The
following table presents net sales information of Services for the three- and six-month periods ended March 26, 2016 and March 28, 2015 (dollars in millions):

[0001193125-16-559625:mdna:35]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 26,2016 |  |  | March 28,2015 |  |  | Change |  |  | March 26,2016 |  |  | March 28,2015 |  |  | Change |  |
| Net sales |  | $ | 5,991 |  |  | $ | 4,996 |  |  |  | 20% |  |  | $ | 12,047 |  |  | $ | 9,795 |  |  |  | 23% |  |
| Percentage of total net sales |  |  | 12% |  |  |  | 9% |  |  |  |  |  |  |  | 10% |  |  |  | 7% |  |  |  |  |  |

[0001193125-16-559625:mdna:36]
The year-over-year increase in net sales of Services in the second quarter and first six months of 2016 was due primarily
to higher App Store, licensing and AppleCare sales. During the first quarter of 2016, the Company received $548 million from Samsung Electronics Co., Ltd. related to its patent infringement lawsuit, which was recorded as licensing net sales within
Services.

[0001193125-16-559625:mdna:37]
[same as prior period, unchanged from 0001193125-16-439878:mdna:37]

[0001193125-16-559625:mdna:38]
The Company
manages its business primarily on a geographic basis. The Company’s reportable operating segments consist of the Americas, Europe, Greater China, Japan and Rest of Asia Pacific. The Americas segment includes both North and South America. The
Europe segment includes European countries, as well as India, the Middle East and Africa. The Greater China segment includes China, Hong Kong and Taiwan. The Rest of Asia Pacific segment includes Australia and those Asian countries not included in
the Company’s other reportable operating segments. Although, the reportable operating segments provide similar hardware and software products and similar services, each one is managed separately to better align with the location of the
Company’s customers and distribution partners and the unique market dynamics of each geographic region. Further information regarding the Company’s reportable operating segments can be found in Part I, Item 1 of this Form 10-Q in the
Notes to Condensed Consolidated Financial Statements, in Note 11, “Segment Information and Geographic Data.”

[0001193125-16-559625:mdna:39]
[same as prior period, unchanged from 0001193125-16-439878:mdna:39]

[0001193125-16-559625:mdna:40]
The following table presents Americas net sales information for the three- and six-month periods ended March 26, 2016 and March 28, 2015
(dollars in millions):

[0001193125-16-559625:mdna:41]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 26,2016 |  |  | March 28,2015 |  |  | Change |  |  | March 26,2016 |  |  | March 28,2015 |  |  | Change |  |
| Net sales |  | $ | 19,096 |  |  | $ | 21,316 |  |  |  | (10)% |  |  | $ | 48,421 |  |  | $ | 51,882 |  |  |  | (7)% |  |
| Percentage of total net sales |  |  | 38% |  |  |  | 37% |  |  |  |  |  |  |  | 38% |  |  |  | 39% |  |  |  |  |  |

[0001193125-16-559625:mdna:42]
Americas net sales decreased during the second quarter and first six months of 2016 compared to the same periods in 2015
due primarily to lower net sales of iPhone and the effect of weakness in foreign currencies relative to the U.S. dollar.

[0001193125-16-559625:mdna:43]
[same as prior period, unchanged from 0001193125-16-439878:mdna:43]

[0001193125-16-559625:mdna:44]
The following table presents Europe net sales information for the three- and six-month periods ended March 26, 2016 and March 28, 2015 (dollars
in millions):

[0001193125-16-559625:mdna:45]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 26,2016 |  |  | March 28,2015 |  |  | Change |  |  | March 26,2016 |  |  | March 28,2015 |  |  | Change |  |
| Net sales |  | $ | 11,535 |  |  | $ | 12,204 |  |  |  | (5)% |  |  | $ | 29,467 |  |  | $ | 29,418 |  |  |  | 0% |  |
| Percentage of total net sales |  |  | 23% |  |  |  | 21% |  |  |  |  |  |  |  | 23% |  |  |  | 22% |  |  |  |  |  |

[0001193125-16-559625:mdna:46]
Europe net sales decreased during the second quarter of 2016 compared to the same period in 2015 due primarily to the
effect of weakness in foreign currencies relative to the U.S. dollar. Year-over-year Europe net sales were flat during the first six months of 2016 due primarily to the effect of weakness in foreign currencies relative to the U.S. dollar, offset by
higher unit sales of iPhone.

[0001193125-16-559625:mdna:47]
[same as prior period, unchanged from 0001193125-16-439878:mdna:47]

[0001193125-16-559625:mdna:48]
The
following table presents Greater China net sales information for the three- and six-month periods ended March 26, 2016 and March 28, 2015 (dollars in millions):

[0001193125-16-559625:mdna:49]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 26,2016 |  |  | March 28,2015 |  |  | Change |  |  | March 26,2016 |  |  | March 28,2015 |  |  | Change |  |
| Net sales |  | $ | 12,486 |  |  | $ | 16,823 |  |  |  | (26)% |  |  | $ | 30,859 |  |  | $ | 32,967 |  |  |  | (6)% |  |
| Percentage of total net sales |  |  | 25% |  |  |  | 29% |  |  |  |  |  |  |  | 24% |  |  |  | 25% |  |  |  |  |  |

[0001193125-16-559625:mdna:50]
Greater China net sales decreased during the second quarter and first six months of 2016 compared to the same periods in
2015 due primarily to lower net sales of iPhone and the effect of weakness in foreign currencies relative to the U.S. dollar.

[0001193125-16-559625:mdna:51]
[same as prior period, unchanged from 0001193125-16-439878:mdna:51]

[0001193125-16-559625:mdna:52]
The following table presents Japan net sales information for the three- and six-month periods ended March 26, 2016 and March 28, 2015 (dollars
in millions):

[0001193125-16-559625:mdna:53]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 26,2016 |  |  | March 28,2015 |  |  | Change |  |  | March 26,2016 |  |  | March 28,2015 |  |  | Change |  |
| Net sales |  | $ | 4,281 |  |  | $ | 3,457 |  |  |  | 24% |  |  | $ | 9,075 |  |  | $ | 8,905 |  |  |  | 2% |  |
| Percentage of total net sales |  |  | 8% |  |  |  | 6% |  |  |  |  |  |  |  | 7% |  |  |  | 7% |  |  |  |  |  |

[0001193125-16-559625:mdna:54]
Japan net sales increased during the second quarter of 2016 compared to the same period in 2015 due primarily to higher
net sales of iPhone and Services. The year-over-year increase in Japan net sales during the first six months of 2016 was due primarily to higher sales of Services, partially offset by the effect of weakness in the Japanese Yen relative to the U.S.
dollar.

[0001193125-16-559625:mdna:55]
Rest of Asia Pacific

[0001193125-16-559625:mdna:56]
The following table presents
Rest of Asia Pacific net sales information for the three- and six-month periods ended March 26, 2016 and March 28, 2015 (dollars in millions):

[0001193125-16-559625:mdna:57]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 26,2016 |  |  | March 28,2015 |  |  | Change |  |  | March 26,2016 |  |  | March 28,2015 |  |  | Change |  |
| Net sales |  | $ | 3,159 |  |  | $ | 4,210 |  |  |  | (25)% |  |  | $ | 8,607 |  |  | $ | 9,437 |  |  |  | (9)% |  |
| Percentage of total net sales |  |  | 6% |  |  |  | 7% |  |  |  |  |  |  |  | 7% |  |  |  | 7% |  |  |  |  |  |

[0001193125-16-559625:mdna:58]
Rest of Asia Pacific net sales decreased during the second quarter and first six months of 2016 compared to the same
periods in 2015 due primarily to lower net sales of iPhone and the effect of weakness in foreign currencies relative to the U.S. dollar.

[0001193125-16-559625:mdna:59]
[same as prior period, unchanged from 0001193125-16-439878:mdna:59]

[0001193125-16-559625:mdna:60]
Gross margin for the three- and six-month periods ended March 26, 2016 and March 28, 2015 was as follows (dollars in millions):

[0001193125-16-559625:mdna:61]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 26,2016 |  |  | March 28,2015 |  |  | March 26,2016 |  |  | March 28,2015 |  |
| Net sales |  | $ | 50,557 |  |  | $ | 58,010 |  |  | $ | 126,429 |  |  | $ | 132,609 |  |
| Cost of sales |  |  | 30,636 |  |  |  | 34,354 |  |  |  | 76,085 |  |  |  | 79,212 |  |
| Gross margin |  | $ | 19,921 |  |  | $ | 23,656 |  |  | $ | 50,344 |  |  | $ | 53,397 |  |
| Gross margin percentage |  |  | 39.4% |  |  |  | 40.8% |  |  |  | 39.8% |  |  |  | 40.3% |  |

[0001193125-16-559625:mdna:62]
The gross margin percentage decreased during the second quarter of 2016 and the first six months of 2016 compared to the
same periods in 2015 due primarily to the effect of weakness in foreign currencies relative to the U.S. dollar and unfavorable leverage on fixed costs from lower net sales, partially offset by a favorable shift in mix to products and services with
higher margins.

[0001193125-16-559625:mdna:63]
The Company anticipates gross margin during the third quarter of 2016 to be between 37.5% and 38.0%. The foregoing statement
regarding the Company’s expected gross margin percentage in the third quarter of 2016 is forward-looking and could differ from actual results. The Company’s future gross margins can be impacted by multiple factors including, but not
limited to, those set forth in Part II, Item 1A of this Form 10-Q under the heading “Risk Factors” and those described in this paragraph. In general, the Company believes gross margins will remain under downward pressure due to a
variety of factors, including continued industry wide global product pricing pressures, increased competition, compressed product life cycles, product transitions, potential increases in the cost of components, and potential strengthening of the
U.S. dollar, as well as potential increases in the costs of outside manufacturing services and a potential shift in the Company’s sales mix towards products with lower gross margins. In response to competitive pressures, the Company expects it
will continue to take product pricing actions, which would adversely affect gross margins. Gross margins could also be affected by the Company’s ability to manage product quality and warranty costs effectively and to stimulate demand for
certain of its products. Due to the Company’s significant international operations, its financial condition and operating results, including gross margins, could be significantly affected by fluctuations in exchange rates.

[0001193125-16-559625:mdna:64]
[same as prior period, unchanged from 0001193125-16-439878:mdna:64]

[0001193125-16-559625:mdna:65]
Operating expenses for the three- and
six-month periods ended March 26, 2016 and March 28, 2015 were as follows (dollars in millions):

[0001193125-16-559625:mdna:66]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 26,2016 |  |  | March 28,2015 |  |  | March 26,2016 |  |  | March 28,2015 |  |
| Research and development |  | $ | 2,511 |  |  | $ | 1,918 |  |  | $ | 4,915 |  |  | $ | 3,813 |  |
| Percentage of total net sales |  |  | 5.0% |  |  |  | 3.3% |  |  |  | 3.9% |  |  |  | 2.9% |  |
| Selling, general and administrative |  | $ | 3,423 |  |  | $ | 3,460 |  |  | $ | 7,271 |  |  | $ | 7,060 |  |
| Percentage of total net sales |  |  | 6.8% |  |  |  | 6.0% |  |  |  | 5.8% |  |  |  | 5.3% |  |
| Total operating expenses |  | $ | 5,934 |  |  | $ | 5,378 |  |  | $ | 12,186 |  |  | $ | 10,873 |  |
| Percentage of total net sales |  |  | 11.7% |  |  |  | 9.3% |  |  |  | 9.6% |  |  |  | 8.2% |  |

[0001193125-16-559625:mdna:67]
[same as prior period, unchanged from 0001193125-16-439878:mdna:67]

[0001193125-16-559625:mdna:68]
The
year-over-year increase in R&D expense during the second quarter and first six months of 2016 compared to the same periods in 2015 was driven primarily by an increase in headcount and related expenses, including share-based compensation costs,
and material costs to support expanded R&D activities. The Company continues to believe that focused investments in R&D are critical to its future growth and competitive position in the marketplace and are directly related to timely
development of new and updated products that are central to the Company’s core business strategy.

[0001193125-16-559625:mdna:69]
[same as prior period, unchanged from 0001193125-16-439878:mdna:69]

[0001193125-16-559625:mdna:70]
The year-over-year decrease in selling, general and administrative expense during the second quarter of 2016 compared to the same period in 2015 was due
primarily to a decrease in advertising and related programs, partially offset by an increase in headcount and related expenses. The year-over-year increase in selling, general and administrative expense during the first six months of 2016 compared
to the same period in 2015 was due primarily to increased headcount and related expenses.

[0001193125-16-559625:mdna:71]
[same as prior period, unchanged from 0001193125-16-439878:mdna:71]

[0001193125-16-559625:mdna:72]
Other income/(expense), net for the three- and six-month periods ended March 26, 2016 and March 28, 2015 was as follows (dollars in millions):

[0001193125-16-559625:mdna:73]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 26,2016 |  |  | March 28,2015 |  |  | Change |  |  | March 26,2016 |  |  | March 28,2015 |  |  | Change |  |
| Interest and dividend income |  | $ | 986 |  |  | $ | 675 |  |  |  |  |  |  | $ | 1,927 |  |  | $ | 1,329 |  |  |  |  |  |
| Interest expense |  |  | (321 | ) |  |  | (163 | ) |  |  |  |  |  |  | (597 | ) |  |  | (294 | ) |  |  |  |  |
| Other expense, net |  |  | (510 | ) |  |  | (226 | ) |  |  |  |  |  |  | (773 | ) |  |  | (579 | ) |  |  |  |  |
| Total other income/(expense), net |  | $ | 155 |  |  | $ | 286 |  |  |  | (46)% |  |  | $ | 557 |  |  | $ | 456 |  |  |  | 22% |  |

[0001193125-16-559625:mdna:74]
The decrease in other income/(expense), net during the second quarter of 2016 compared to the same period in 2015 was due
primarily to higher interest expense on debt and higher expenses associated with foreign exchange activity, partially offset by higher interest income. The increase in other income/(expense), net during the first six months of 2016 compared to the
same period in 2015 was due primarily to higher interest income, partially offset by higher interest expense on debt and losses on marketable securities. The weighted-average interest rate earned by the Company on its cash, cash equivalents and
marketable securities was 1.74% and 1.43% in the second quarter of 2016 and 2015, respectively, and 1.70% and 1.42% in the first six months of 2016 and 2015, respectively.

[0001193125-16-559625:mdna:75]
[same as prior period, unchanged from 0001193125-16-439878:mdna:75]

[0001193125-16-559625:mdna:76]
Provision for income taxes and
effective tax rates for the three- and six-month periods ended March 26, 2016 and March 28, 2015 were as follows (dollars in millions):

[0001193125-16-559625:mdna:77]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 26,2016 |  |  | March 28,2015 |  |  | March 26,2016 |  |  | March 28,2015 |  |
| Provision for income taxes |  | $ | 3,626 |  |  | $ | 4,995 |  |  | $ | 9,838 |  |  | $ | 11,387 |  |
| Effective tax rate |  |  | 25.6% |  |  |  | 26.9% |  |  |  | 25.4% |  |  |  | 26.5% |  |

[0001193125-16-559625:mdna:78]
The Company’s effective tax rates during the second quarter of 2016 and 2015 differ from the statutory federal
income tax rate of 35% due primarily to certain undistributed foreign earnings, a substantial portion of which was generated by subsidiaries organized in Ireland, for which no U.S. taxes are provided when such earnings are intended to be
indefinitely reinvested outside the U.S. The lower effective tax rate during the second quarter and first six months of 2016 compared to the same periods in 2015 was due primarily to a different geographic mix of earnings.

[0001193125-16-559625:mdna:79]
The U.S. Internal Revenue Service is currently examining the years 2010 through 2012, and all years prior to 2010 are closed. In addition, the Company is
subject to audits by state, local and foreign tax authorities. Management believes that adequate provisions have been made for any adjustments that may result from tax examinations. However, the outcome of tax audits cannot be predicted with
certainty. If any issues addressed in the Company’s tax audits are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution
occurs.

[0001193125-16-559625:mdna:80]
On June 11, 2014, the European Commission issued an opening decision initiating a formal investigation against Ireland for alleged
state aid to the Company. The opening decision concerns the allocation of profits for taxation purposes of the Irish branches of two subsidiaries of the Company. The Company believes the European Commission’s assertions are without merit. If
the European Commission were to conclude against Ireland, the European Commission could require Ireland to recover from the Company past taxes covering a period of up to 10 years reflective of the disallowed state aid. While such amount could be
material, as of March 26, 2016 the Company is unable to estimate the impact.

[0001193125-16-559625:mdna:81]
[same as prior period, unchanged from 0001193125-16-439878:mdna:81]

[0001193125-16-559625:mdna:82]
Stock Compensation

[0001193125-16-559625:mdna:83]
In March 2016, the Financial Accounting
Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2016-09, Compensation – Stock Compensation (Topic 718) (“ASU 2016-09”), which simplified certain aspects of the accounting for
share-based payment transactions, including income taxes, classification of awards and classification in the statement of cash flows. ASU 2016-09 will be effective for the Company beginning in its first quarter of 2018. The Company is currently
evaluating the impact of adopting the new stock compensation standard on its consolidated financial statements.

[0001193125-16-559625:mdna:84]
Leases

[0001193125-16-559625:mdna:85]
In
February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842) (“ASU 2016-02”), which modified lease accounting for both lessees and lessors to increase transparency and comparability by recognizing lease assets and lease
liabilities by lessees for those leases classified as operating leases under previous accounting standards and disclosing key information about leasing arrangements. ASU 2016-02 will be effective for the Company beginning in its first quarter of
2020 and early adoption is permitted. The Company is currently evaluating the timing of its adoption and the impact of adopting the new lease standard on its consolidated financial statements.

[0001193125-16-559625:mdna:86]
Financial Instruments

[0001193125-16-559625:mdna:87]
In January 2016, the FASB issued ASU
No. 2016-01, Financial Instruments – Overall (Subtopic 825-10) (“ASU 2016-01”), which updates certain aspects of recognition, measurement, presentation and disclosure of financial instruments. ASU 2016-01 will be effective for
the Company beginning in its first quarter of 2019. The Company does not believe the adoption of the new financial instruments standard will have a material impact on its consolidated financial statements.

[0001193125-16-559625:mdna:88]
Revenue Recognition

[0001193125-16-559625:mdna:89]
In May 2014, the FASB issued ASU
No. 2014-09, Revenue from Contracts with Customers (Topic 606) (“ASU 2014-09”), which amends the existing accounting standards for revenue recognition. ASU 2014-09 is based on principles that govern the recognition of revenue at an
amount an entity expects to be entitled when products are transferred to customers.

[0001193125-16-559625:mdna:90]
The original effective date for ASU 2014-09 would have required
the Company to adopt beginning in its first quarter of 2018. In August 2015, the FASB issued ASU No. 2015-14, Revenue from Contracts with Customers (Topic 606) – Deferral of the Effective Date, which defers the effective date of ASU
2014-09 for one year and permits early adoption as early as the original effective date of ASU 2014-09. Accordingly, the Company may adopt the standard in either its first quarter of 2018 or 2019.

[0001193125-16-559625:mdna:91]
In March 2016, the FASB issued ASU No. 2016-08, Revenue from Contracts with Customers (Topic 606) – Principal versus Agent Considerations
(“ASU 2016-08”), which clarifies the implementation guidance for principal versus agent considerations in ASU 2014-09. In April 2016, the FASB issued ASU No. 2016-10, Revenue from Contracts with Customers (Topic 606) – Identifying
Performance Obligations and Licensing (“ASU 2016-10”), which amends the guidance in ASU 2014-09 related to identifying performance obligations and accounting for licenses of intellectual property. The Company must adopt ASU 2016-08 and ASU
2016-10 with ASU 2014-09.

[0001193125-16-559625:mdna:92]
The new revenue standard may be applied retrospectively to each prior period presented or retrospectively with the
cumulative effect recognized as of the date of adoption. The Company is currently evaluating the timing of its adoption and the impact of adopting the new revenue standard on its consolidated financial statements.

[0001193125-16-559625:mdna:93]
[same as prior period, unchanged from 0001193125-16-439878:mdna:85]

[0001193125-16-559625:mdna:94]
The following tables present
selected financial information and statistics as of March 26, 2016 and September 26, 2015 and for the first six months of 2016 and 2015 (in millions):

[0001193125-16-559625:mdna:95]
|  |  | March 26,2016 |  |  | September 26,2015 |  |
| Cash, cash equivalents and marketable securities |  | $ | 232,928 |  |  | $ | 205,666 |  |
| Property, plant and equipment, net |  | $ | 23,203 |  |  | $ | 22,471 |  |
| Commercial paper |  | $ | 7,998 |  |  | $ | 8,499 |  |
| Total term debt |  | $ | 71,874 |  |  | $ | 55,963 |  |
| Working capital |  | $ | 19,327 |  |  | $ | 8,768 |  |
|  |  | Six Months Ended |  |
|  |  | March 26,2016 |  |  | March 28,2015 |  |
| Cash generated by operating activities |  | $ | 39,064 |  |  | $ | 52,803 |  |
| Cash used in investing activities |  | $ | (34,110 | ) |  | $ | (43,496 | ) |
| Cash used in financing activities |  | $ | (4,560 | ) |  | $ | (8,662 | ) |

[0001193125-16-559625:mdna:96]
[same as prior period, unchanged from 0001193125-16-439878:mdna:88]

[0001193125-16-559625:mdna:97]
As of March 26, 2016 and September 26, 2015, the Company’s cash, cash equivalents and
marketable securities held by foreign subsidiaries were $208.9 billion and $186.9 billion, respectively, and are generally based in U.S. dollar-denominated holdings. Amounts held by foreign subsidiaries are
generally subject to U.S. income taxation on repatriation to the U.S. The Company’s marketable securities investment portfolio is invested primarily in highly-rated securities and its investment policy generally limits the amount of credit
exposure to any one issuer. The policy requires investments generally to be investment grade with the objective of minimizing the potential risk of principal loss.

[0001193125-16-559625:mdna:98]
During the six months ended March 26, 2016, cash generated from operating activities of $39.1 billion was a result of $28.9 billion of net income,
non-cash adjustments to net income of $10.6 billion and a decrease in the net change in operating assets and liabilities of $0.5 billion. Cash used in investing activities of $34.1 billion during the six months ended March 26, 2016 consisted
primarily of cash used for purchases of marketable securities, net of sales and maturities, of $27.0 billion and cash used to acquire property, plant and equipment of $5.9 billion. Cash used in financing activities of $4.6 billion during the six
months ended March 26, 2016 consisted primarily of cash used to repurchase common stock of $13.5 billion, and cash used to pay dividends and dividend equivalents of $5.9 billion, partially offset by proceeds from issuance of term debt, net of
$15.6 billion.

[0001193125-16-559625:mdna:99]
During the six months ended March 28, 2015, cash generated from operating activities of $52.8 billion was a result of $31.6
billion of net income, non-cash adjustments to net income of $8.7 billion and an increase in the net change in operating assets and liabilities of $12.5 billion. Cash used in investing activities of $43.5 billion during the six months ended
March 28, 2015 consisted primarily of cash used for purchases of marketable securities, net of sales and maturities, of $37.7 billion and cash used to acquire property, plant and equipment of $5.6 billion. Cash used in financing activities of
$8.7 billion during the six months ended March 28, 2015 consisted primarily of cash used to repurchase common stock of $12.0 billion, cash used to pay dividends and dividend equivalents of $5.5 billion and cash used for repayments of commercial
paper, net of $2.5 billion, partially offset by proceeds from the issuance of term debt, net of $11.3 billion.

[0001193125-16-559625:mdna:100]
[same as prior period, unchanged from 0001193125-16-439878:mdna:92]

[0001193125-16-559625:mdna:101]
The Company’s capital expenditures were $2.8 billion during the first six months of 2016. The Company anticipates utilizing approximately $15.0
billion for capital expenditures during 2016, which includes product tooling and manufacturing process equipment; data centers; corporate facilities and infrastructure, including information systems hardware, software and enhancements; and retail
store facilities.

[0001193125-16-559625:mdna:102]
[same as prior period, unchanged from 0001193125-16-439878:mdna:94]

[0001193125-16-559625:mdna:103]
The Company issues unsecured
short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses the net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of
March 26, 2016, the Company had $8.0 billion of Commercial Paper outstanding, with a weighted-average interest rate of 0.39% and maturities generally less than nine months.

[0001193125-16-559625:mdna:104]
As of March 26, 2016, the Company has outstanding floating- and fixed-rate notes for an aggregate principal amount of $71.3 billion (collectively
the “Notes”). The Company has entered, and in the future may enter, into interest rate swaps to manage interest rate risk on the Notes. In addition, the Company has entered, and in the future may enter, into currency swaps to manage
foreign currency risk on the Notes.

[0001193125-16-559625:mdna:105]
[same as prior period, unchanged from 0001193125-16-439878:mdna:97]

[0001193125-16-559625:mdna:106]
[same as prior period, unchanged from 0001193125-16-439878:mdna:98]

[0001193125-16-559625:mdna:107]
In April 2015, the Company’s Board
of Directors increased the share repurchase program authorization from $90 billion to $140 billion of the Company’s common stock, increasing the expected total size of the capital return program to $200 billion. As of March 26, 2016, $117
billion of the share repurchase program has been utilized. The Company’s share repurchase program does not obligate it to acquire any specific number of shares. Under the program, shares may be repurchased in privately negotiated or open market
transactions, including under plans complying with Rule 10b5-1 under the Exchange Act.

[0001193125-16-559625:mdna:108]
The following table presents the Company’s dividends, dividend equivalents, share repurchases and net
share settlement activity from the start of the capital return program in August 2012 through March 26, 2016 (in millions):

[0001193125-16-559625:mdna:109]
|  |  | Dividends andDividendEquivalentsPaid |  |  | AcceleratedShareRepurchases |  |  | Open MarketShareRepurchases |  |  | Taxes Relatedto Settlementof EquityAwards |  |  | Total |  |
| Q2 2016 |  | $ | 2,902 |  |  | $ | 0 |  |  | $ | 7,000 |  |  | $ | 154 |  |  | $ | 10,056 |  |
| Q1 2016 |  |  | 2,969 |  |  |  | 3,000 |  |  |  | 3,000 |  |  |  | 597 |  |  |  | 9,566 |  |
| 2015 |  |  | 11,561 |  |  |  | 6,000 |  |  |  | 30,026 |  |  |  | 1,499 |  |  |  | 49,086 |  |
| 2014 |  |  | 11,126 |  |  |  | 21,000 |  |  |  | 24,000 |  |  |  | 1,158 |  |  |  | 57,284 |  |
| 2013 |  |  | 10,564 |  |  |  | 13,950 |  |  |  | 9,000 |  |  |  | 1,082 |  |  |  | 34,596 |  |
| 2012 |  |  | 2,488 |  |  |  | 0 |  |  |  | 0 |  |  |  | 56 |  |  |  | 2,544 |  |
| Total |  | $ | 41,610 |  |  | $ | 43,950 |  |  | $ | 73,026 |  |  | $ | 4,546 |  |  | $ | 163,132 |  |

[0001193125-16-559625:mdna:110]
On April 26, 2016, the Company announced that the Board of Directors increased the total capital return program from $200
billion to $250 billion, which includes an increase in the share repurchase authorization from $140 billion to $175 billion. The Company expects to execute its capital return program by the end of March 2018 by paying dividends and dividend
equivalents, repurchasing shares and remitting withheld taxes related to net share settlement of restricted stock units. The Company plans to continue to access the domestic and international debt markets to assist in funding its capital return
program.

[0001193125-16-559625:mdna:111]
Additionally, the Company announced on April 26, 2016 that the Board of Directors raised the cash dividend by 10% to $0.57 per share,
beginning with the dividend to be paid during the third quarter of 2016. The Company intends to increase its dividend on an annual basis subject to declaration by the Board of Directors.

[0001193125-16-559625:mdna:112]
[same as prior period, unchanged from 0001193125-16-439878:mdna:103]

[0001193125-16-559625:mdna:113]
The
Company has not entered into any transactions with unconsolidated entities whereby the Company has financial guarantees, subordinated retained interests, derivative instruments, or other contingent arrangements that expose the Company to material
continuing risks, contingent liabilities, or any other obligation under a variable interest in an unconsolidated entity that provides financing, liquidity, market risk, or credit risk support to the Company, or engages in leasing, hedging, or
R&D services with the Company.

[0001193125-16-559625:mdna:114]
[same as prior period, unchanged from 0001193125-16-439878:mdna:105]

[0001193125-16-559625:mdna:115]
The
Company’s major facility leases are typically for terms not exceeding 10 years and generally contain multi-year renewal options. As of March 26, 2016, the Company had a total of 475 retail stores. Leases for retail space are for terms
ranging from five to 20 years, the majority of which are for 10 years, and often contain multi-year renewal options. As of March 26, 2016, the Company’s total future minimum lease payments under noncancelable operating leases were $6.8
billion, of which $3.9 billion related to leases for retail space.

[0001193125-16-559625:mdna:116]
[same as prior period, unchanged from 0001193125-16-439878:mdna:107]

[0001193125-16-559625:mdna:117]
The Company utilizes several outsourcing partners to manufacture sub-assemblies for the Company’s products and to perform final assembly and testing
of finished products. These outsourcing partners acquire components and build product based on demand information supplied by the Company, which typically covers periods up to 150 days. The Company also obtains individual components for its products
from a wide variety of individual suppliers. Consistent with industry practice, the Company acquires components through a combination of purchase orders, supplier contracts, and open orders based on projected demand information. Where
appropriate, the purchases are applied to inventory component prepayments that are outstanding with the respective supplier. As of March 26, 2016, the Company had outstanding off-balance sheet third-party
manufacturing commitments and component purchase commitments of $15.5 billion.

[0001193125-16-559625:mdna:118]
[same as prior period, unchanged from 0001193125-16-439878:mdna:109]

[0001193125-16-559625:mdna:119]
In addition to the commitments mentioned above, the Company had other off-balance sheet obligations of $7.2 billion as of March 26, 2016 that
consisted of commitments to acquire capital assets, including product tooling and manufacturing process equipment, and commitments related to inventory prepayments, advertising, licensing, R&D, internet and telecommunications services, energy
and other obligations. Subsequent to March 26, 2016, the Company entered into an additional other off-balance sheet obligation of $4.0 billion.

[0001193125-16-559625:mdna:120]
The Company’s other non-current liabilities in the Condensed Consolidated Balance Sheets consist
primarily of deferred tax liabilities, gross unrecognized tax benefits and the related gross interest and penalties. As of March 26, 2016, the Company had non-current deferred tax liabilities of $23.0 billion. Additionally, as of March 26,
2016, the Company had gross unrecognized tax benefits of $7.5 billion and an additional $1.5 billion for gross interest and penalties classified as non-current liabilities. At this time, the Company is unable to make a reasonably reliable estimate
of the timing of payments due to uncertainties in the timing of tax audit outcomes.

[0001193125-16-559625:mdna:121]
[same as prior period, unchanged from 0001193125-16-439878:mdna:112]

[0001193125-16-559625:mdna:122]
[same as prior period, unchanged from 0001193125-16-439878:mdna:113]

[0001193125-16-559625:mdna:123]
[same as prior period, unchanged from 0001193125-16-439878:mdna:114]

[0001193125-16-559625:mdna:124]
The Company has entered into indemnification agreements with its
directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance
expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of
prior indemnification claims and the unique facts and circumstances involved in each claim. However, the Company maintains directors and officers liability insurance coverage to reduce its exposure to such obligations.

[0001193125-16-559625:mdna:125]
[same as prior period, unchanged from 0001193125-16-439878:mdna:116]

[0001193125-16-559625:mdna:126]
The preparation of
financial statements and related disclosures in conformity with U.S. generally accepted accounting principles (“GAAP”) and the Company’s discussion and analysis of its financial condition and operating results require the
Company’s management to make judgments, assumptions and estimates that affect the amounts reported in its condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and on various
other assumptions it believes to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities. Actual results may differ from these estimates, and such
differences may be material.

[0001193125-16-559625:mdna:127]
Note 1, “Summary of Significant Accounting Policies” in Part I, Item 1 of this Form 10-Q and in the
Notes to Consolidated Financial Statements in Part II, Item 8 of the 2015 Form 10-K, and “Critical Accounting Policies and Estimates” in Part I, Item 7 of the 2015 Form 10-K describe the significant accounting policies and
methods used in the preparation of the Company’s condensed consolidated financial statements. There have been no material changes to the Company’s critical accounting policies and estimates since the 2015 Form 10-K.
