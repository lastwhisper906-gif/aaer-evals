# AAPL MD&A — 0000320193-20-000096


## mdna

[0000320193-20-000096:mdna:1]
Item 7.    Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000320193-20-000096:mdna:2]
The following discussion should be read in conjunction with the consolidated financial statements and accompanying notes included in Part II, Item 8 of this Form 10-K. This section of this Form 10-K generally discusses 2020 and 2019 items and year-to-year comparisons between 2020 and 2019. Discussions of 2018 items and year-to-year comparisons between 2019 and 2018 that are not included in this Form 10-K can be found in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in Part II, Item 7 of the Company’s Annual Report on Form 10-K for the fiscal year ended September 28, 2019.

[0000320193-20-000096:mdna:3]
Fiscal Year Highlights

[0000320193-20-000096:mdna:4]
COVID-19 Update

[0000320193-20-000096:mdna:5]
COVID-19 has spread rapidly throughout the world, prompting governments and businesses to take unprecedented measures in response. Such measures have included restrictions on travel and business operations, temporary closures of businesses, and quarantines and shelter-in-place orders. The COVID-19 pandemic has significantly curtailed global economic activity and caused significant volatility and disruption in global financial markets. The COVID-19 pandemic and the measures taken by many countries in response have adversely affected and could in the future materially adversely impact the Company’s business, results of operations, financial condition and stock price.

[0000320193-20-000096:mdna:6]
During 2020, aspects of the Company’s business were adversely affected by the COVID-19 pandemic, with many of the Company’s retail stores, as well as channel partner points of sale, temporarily closed at various times, and the vast majority of the Company’s employees working remotely. The Company has reopened some of its offices and the majority of its retail stores, subject to operating restrictions to protect public health and the health and safety of employees and customers, and it continues to work on safely re-opening the remainder of its offices and retail stores, subject to local rules and regulations.

[0000320193-20-000096:mdna:7]
The full extent of the future impact of the COVID-19 pandemic on the Company’s operational and financial performance is currently uncertain and will depend on many factors outside the Company’s control, including, without limitation, the timing, extent, trajectory and duration of the pandemic, the development and availability of effective treatments and vaccines, the imposition of protective public safety measures, and the impact of the pandemic on the global economy and demand for consumer products. Refer to Part I, Item 1A of this Form 10-K under the heading “Risk Factors,” for more information.

[0000320193-20-000096:mdna:8]
The Company believes its existing balances of cash, cash equivalents and marketable securities, along with commercial paper and other short-term liquidity arrangements, will be sufficient to satisfy its working capital needs, capital asset purchases, dividends, share repurchases, debt repayments and other liquidity requirements associated with its existing operations.

[0000320193-20-000096:mdna:9]
Fiscal 2020 Highlights

[0000320193-20-000096:mdna:10]
Total net sales increased 6% or $14.3 billion during 2020 compared to 2019, primarily driven by higher net sales of Services and Wearables, Home and Accessories. The weakness in foreign currencies had an unfavorable impact on net sales during 2020.

[0000320193-20-000096:mdna:11]
In April 2020, the Company announced an increase to its current share repurchase program authorization from $175 billion to $225 billion and raised its quarterly dividend from $0.1925 to $0.205 per share beginning in May 2020. During 2020, the Company repurchased $72.5 billion of its common stock and paid dividends and dividend equivalents of $14.1 billion.

[0000320193-20-000096:mdna:12]
On August 28, 2020, the Company effected a four-for-one stock split to shareholders of record as of August 24, 2020. All share, RSU and per share or per RSU information has been retroactively adjusted to reflect the stock split.

[0000320193-20-000096:mdna:13]
Products and Services Performance

[0000320193-20-000096:mdna:14]
The following table shows net sales by category for 2020, 2019 and 2018 (dollars in millions):

[0000320193-20-000096:mdna:15]
|  | 2020 |  | Change |  | 2019 |  | Change |  | 2018 |
| Net sales by category: |  |  |  |  |  |  |  |  |  |
| iPhone (1) | $ | 137,781 |  |  | (3) | % |  | $ | 142,381 |  |  | (14) | % |  | $ | 164,888 |  |
| Mac (1) | 28,622 |  |  | 11 | % |  | 25,740 |  |  | 2 | % |  | 25,198 |  |
| iPad (1) | 23,724 |  |  | 11 | % |  | 21,280 |  |  | 16 | % |  | 18,380 |  |
| Wearables, Home and Accessories (1)(2) | 30,620 |  |  | 25 | % |  | 24,482 |  |  | 41 | % |  | 17,381 |  |
| Services (3) | 53,768 |  |  | 16 | % |  | 46,291 |  |  | 16 | % |  | 39,748 |  |
| Total net sales | $ | 274,515 |  |  | 6 | % |  | $ | 260,174 |  |  | (2) | % |  | $ | 265,595 |  |

[0000320193-20-000096:mdna:16]
(1)Products net sales include amortization of the deferred value of unspecified software upgrade rights, which are bundled in the sales price of the respective product.

[0000320193-20-000096:mdna:17]
(2)Wearables, Home and Accessories net sales include sales of AirPods, Apple TV, Apple Watch, Beats products, HomePod, iPod touch and Apple-branded and third-party accessories.

[0000320193-20-000096:mdna:18]
(3)Services net sales include sales from the Company’s advertising, AppleCare, digital content and other services. Services net sales also include amortization of the deferred value of Maps, Siri, and free iCloud® storage and Apple TV+ services, which are bundled in the sales price of certain products.

[0000320193-20-000096:mdna:19]
iPhone

[0000320193-20-000096:mdna:20]
iPhone net sales decreased during 2020 compared to 2019 due primarily to the absence of new iPhone models in the fourth quarter of 2020 and the weakness in foreign currencies relative to the U.S. dollar, partially offset by the introduction of iPhone SE in the third quarter of 2020.

[0000320193-20-000096:mdna:21]
Mac

[0000320193-20-000096:mdna:22]
Mac net sales increased during 2020 compared to 2019 due primarily to higher net sales of MacBook Pro.

[0000320193-20-000096:mdna:23]
iPad

[0000320193-20-000096:mdna:24]
iPad net sales increased during 2020 compared to 2019 due primarily to higher net sales of 10-inch versions of iPad, iPad Air and iPad Pro.

[0000320193-20-000096:mdna:25]
Wearables, Home and Accessories

[0000320193-20-000096:mdna:26]
Wearables, Home and Accessories net sales increased during 2020 compared to 2019 due primarily to higher net sales of AirPods and Apple Watch.

[0000320193-20-000096:mdna:27]
Services

[0000320193-20-000096:mdna:28]
Services net sales increased during 2020 compared to 2019 due primarily to higher net sales from the App Store, advertising and cloud services.

[0000320193-20-000096:mdna:29]
Segment Operating Performance

[0000320193-20-000096:mdna:30]
The Company manages its business primarily on a geographic basis. The Company’s reportable segments consist of the Americas, Europe, Greater China, Japan and Rest of Asia Pacific. Americas includes both North and South America. Europe includes European countries, as well as India, the Middle East and Africa. Greater China includes China mainland, Hong Kong and Taiwan. Rest of Asia Pacific includes Australia and those Asian countries not included in the Company’s other reportable segments. Although the reportable segments provide similar hardware and software products and similar services, each one is managed separately to better align with the location of the Company’s customers and distribution partners and the unique market dynamics of each geographic region. Further information regarding the Company’s reportable segments can be found in Part II, Item 8 of this Form 10-K in the Notes to Consolidated Financial Statements in Note 11, “Segment Information and Geographic Data.”

[0000320193-20-000096:mdna:31]
The following table shows net sales by reportable segment for 2020, 2019 and 2018 (dollars in millions):

[0000320193-20-000096:mdna:32]
|  | 2020 |  | Change |  | 2019 |  | Change |  | 2018 |
| Net sales by reportable segment: |  |  |  |  |  |  |  |  |  |
| Americas | $ | 124,556 |  |  | 7 | % |  | $ | 116,914 |  |  | 4 | % |  | $ | 112,093 |  |
| Europe | 68,640 |  |  | 14 | % |  | 60,288 |  |  | (3) | % |  | 62,420 |  |
| Greater China | 40,308 |  |  | (8) | % |  | 43,678 |  |  | (16) | % |  | 51,942 |  |
| Japan | 21,418 |  |  | — | % |  | 21,506 |  |  | (1) | % |  | 21,733 |  |
| Rest of Asia Pacific | 19,593 |  |  | 10 | % |  | 17,788 |  |  | 2 | % |  | 17,407 |  |
| Total net sales | $ | 274,515 |  |  | 6 | % |  | $ | 260,174 |  |  | (2) | % |  | $ | 265,595 |  |

[0000320193-20-000096:mdna:33]
Americas

[0000320193-20-000096:mdna:34]
Americas net sales increased during 2020 compared to 2019 due primarily to higher net sales of Services and Wearables, Home and Accessories. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on Americas net sales during 2020.

[0000320193-20-000096:mdna:35]
Europe

[0000320193-20-000096:mdna:36]
Europe net sales increased during 2020 compared to 2019 due primarily to higher net sales of iPhone, Wearables, Home and Accessories and Services. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on Europe net sales during 2020.

[0000320193-20-000096:mdna:37]
Greater China

[0000320193-20-000096:mdna:38]
Greater China net sales decreased during 2020 compared to 2019 due primarily to lower net sales of iPhone, partially offset by higher net sales of Services and iPad. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on Greater China net sales during 2020.

[0000320193-20-000096:mdna:39]
Japan

[0000320193-20-000096:mdna:40]
Japan net sales were flat during 2020 compared to 2019 due primarily to lower net sales of iPhone, offset by higher net sales of Services and Wearables, Home and Accessories. The strength of the Japanese yen relative to the U.S. dollar had a favorable impact on Japan net sales during 2020.

[0000320193-20-000096:mdna:41]
Rest of Asia Pacific

[0000320193-20-000096:mdna:42]
Rest of Asia Pacific net sales increased during 2020 compared to 2019 due primarily to higher net sales of Wearables, Home and Accessories, Services and iPhone. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on Rest of Asia Pacific net sales during 2020.

[0000320193-20-000096:mdna:43]
Gross Margin

[0000320193-20-000096:mdna:44]
Products and Services gross margin and gross margin percentage for 2020, 2019 and 2018 were as follows (dollars in millions):

[0000320193-20-000096:mdna:45]
|  | 2020 |  | 2019 |  | 2018 |
| Gross margin: |  |  |  |  |  |
| Products | $ | 69,461 |  |  | $ | 68,887 |  |  | $ | 77,683 |  |
| Services | 35,495 |  |  | 29,505 |  |  | 24,156 |  |
| Total gross margin | $ | 104,956 |  |  | $ | 98,392 |  |  | $ | 101,839 |  |

[0000320193-20-000096:mdna:46]
| Gross margin percentage: |  |  |  |  |  |
| Products | 31.5 | % |  | 32.2 | % |  | 34.4 | % |
| Services | 66.0 | % |  | 63.7 | % |  | 60.8 | % |
| Total gross margin percentage | 38.2 | % |  | 37.8 | % |  | 38.3 | % |

[0000320193-20-000096:mdna:47]
Products Gross Margin

[0000320193-20-000096:mdna:48]
Products gross margin increased during 2020 compared to 2019 due primarily to higher Products volume and material cost savings, partially offset by the weakness in foreign currencies relative to the U.S. dollar and a different Products mix. Products gross margin percentage decreased during 2020 compared to 2019 due primarily to the weakness in foreign currencies relative to the U.S. dollar and a different Products mix, partially offset by material cost savings and higher leverage.

[0000320193-20-000096:mdna:49]
Services Gross Margin

[0000320193-20-000096:mdna:50]
Services gross margin increased during 2020 compared to 2019 due primarily to higher Services net sales and a different Services mix. Services gross margin percentage increased during 2020 compared to 2019 due primarily to a different Services mix and higher leverage, partially offset by higher Services costs.

[0000320193-20-000096:mdna:51]
The Company’s future gross margins can be impacted by a variety of factors, as set forth in Part I, Item 1A of this Form 10-K under the heading “Risk Factors.” As a result, the Company believes, in general, gross margins will be subject to volatility and remain under downward pressure.

[0000320193-20-000096:mdna:52]
Operating Expenses

[0000320193-20-000096:mdna:53]
Operating expenses for 2020, 2019 and 2018 were as follows (dollars in millions):

[0000320193-20-000096:mdna:54]
|  | 2020 |  | Change |  | 2019 |  | Change |  | 2018 |
| Research and development | $ | 18,752 |  |  | 16 | % |  | $ | 16,217 |  |  | 14 | % |  | $ | 14,236 |  |
| Percentage of total net sales | 7 | % |  |  |  | 6 | % |  |  |  | 5 | % |
| Selling, general and administrative | $ | 19,916 |  |  | 9 | % |  | $ | 18,245 |  |  | 9 | % |  | $ | 16,705 |  |
| Percentage of total net sales | 7 | % |  |  |  | 7 | % |  |  |  | 6 | % |
| Total operating expenses | $ | 38,668 |  |  | 12 | % |  | $ | 34,462 |  |  | 11 | % |  | $ | 30,941 |  |
| Percentage of total net sales | 14 | % |  |  |  | 13 | % |  |  |  | 12 | % |

[0000320193-20-000096:mdna:55]
Research and Development

[0000320193-20-000096:mdna:56]
The year-over-year growth in R&D expense in 2020 was driven primarily by increases in headcount-related expenses. The Company continues to believe that focused investments in R&D are critical to its future growth and competitive position in the marketplace, and to the development of new and updated products and services that are central to the Company’s core business strategy.

[0000320193-20-000096:mdna:57]
Selling, General and Administrative

[0000320193-20-000096:mdna:58]
The year-over-year growth in selling, general and administrative expense in 2020 was driven primarily by increases in headcount-related expenses, higher spending on marketing and advertising, and higher variable selling expenses.

[0000320193-20-000096:mdna:59]
Other Income/(Expense), Net

[0000320193-20-000096:mdna:60]
Other income/(expense), net (“OI&E”) for 2020, 2019 and 2018 was as follows (dollars in millions):

[0000320193-20-000096:mdna:61]
|  | 2020 |  | Change |  | 2019 |  | Change |  | 2018 |
| Interest and dividend income | $ | 3,763 |  |  |  |  | $ | 4,961 |  |  |  |  | $ | 5,686 |  |
| Interest expense | (2,873) |  |  |  |  | (3,576) |  |  |  |  | (3,240) |  |
| Other income/(expense), net | (87) |  |  |  |  | 422 |  |  |  |  | (441) |  |
| Total other income/(expense), net | $ | 803 |  |  | (56) | % |  | $ | 1,807 |  |  | (10) | % |  | $ | 2,005 |  |

[0000320193-20-000096:mdna:62]
The year-over-year decrease in OI&E during 2020 was due primarily to lower interest income and net impairment/gain activity on non-marketable securities, partially offset by lower interest expense. The weighted-average interest rate earned by the Company on its cash, cash equivalents and marketable securities was 1.85% and 2.19% in 2020 and 2019, respectively.

[0000320193-20-000096:mdna:63]
Provision for Income Taxes

[0000320193-20-000096:mdna:64]
Provision for income taxes, effective tax rate and statutory federal income tax rate for 2020, 2019 and 2018 were as follows (dollars in millions):

[0000320193-20-000096:mdna:65]
|  | 2020 |  | 2019 |  | 2018 |
| Provision for income taxes | $ | 9,680 |  |  | $ | 10,481 |  |  | $ | 13,372 |  |
| Effective tax rate | 14.4 | % |  | 15.9 | % |  | 18.3 | % |
| Statutory federal income tax rate | 21 | % |  | 21 | % |  | 24.5 | % |

[0000320193-20-000096:mdna:66]
The Company’s effective tax rate for both 2020 and 2019 was lower than the statutory federal income tax rate due primarily to the lower tax rate on foreign earnings, including the impact of tax settlements, and tax benefits from share-based compensation.

[0000320193-20-000096:mdna:67]
The Company’s effective tax rate for 2020 was lower compared to 2019 due primarily to a one-time adjustment of U.S. foreign tax credits in response to regulations issued by the U.S. Department of the Treasury in December 2019 in connection with the U.S. Tax Cuts and Jobs Act of 2017 (the “Act”) and higher tax benefits from share-based compensation.

[0000320193-20-000096:mdna:68]
As of September 26, 2020, the Company had net deferred tax assets arising from deductible temporary differences and tax credits of $11.0 billion and deferred tax liabilities of $2.8 billion. Management believes it is more likely than not that forecasted income, including income that may be generated as a result of certain tax planning strategies, together with future reversals of existing taxable temporary differences, will be sufficient to recover the net deferred tax assets. The Company will continue to evaluate the amount of the valuation allowance, if any, by assessing the realizability of deferred tax assets.

[0000320193-20-000096:mdna:69]
Recent Accounting Pronouncements

[0000320193-20-000096:mdna:70]
Financial Instruments

[0000320193-20-000096:mdna:71]
In June 2016, the Financial Accounting Standards Board issued Accounting Standards Update No. 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (“ASU 2016-13”), which modifies the measurement of expected credit losses on certain financial instruments. The Company will adopt ASU 2016-13 in its first quarter of 2021 utilizing the modified retrospective transition method. Based on the composition of the Company’s investment portfolio, current market conditions, and historical credit loss activity, the adoption of ASU 2016-13 will not have a material impact on its consolidated financial statements.

[0000320193-20-000096:mdna:72]
Liquidity and Capital Resources

[0000320193-20-000096:mdna:73]
The following table presents selected financial information and statistics as of and for the years ended September 26, 2020, September 28, 2019 and September 29, 2018 (in millions):

[0000320193-20-000096:mdna:74]
|  | 2020 |  | 2019 |  | 2018 |
| Cash, cash equivalents and marketable securities (1) | $ | 191,830 |  |  | $ | 205,898 |  |  | $ | 237,100 |  |
| Property, plant and equipment, net | $ | 36,766 |  |  | $ | 37,378 |  |  | $ | 41,304 |  |
| Commercial paper | $ | 4,996 |  |  | $ | 5,980 |  |  | $ | 11,964 |  |
| Total term debt | $ | 107,440 |  |  | $ | 102,067 |  |  | $ | 102,519 |  |
| Working capital | $ | 38,321 |  |  | $ | 57,101 |  |  | $ | 15,410 |  |
| Cash generated by operating activities | $ | 80,674 |  |  | $ | 69,391 |  |  | $ | 77,434 |  |
| Cash generated by/(used in) investing activities | $ | (4,289) |  |  | $ | 45,896 |  |  | $ | 16,066 |  |
| Cash used in financing activities | $ | (86,820) |  |  | $ | (90,976) |  |  | $ | (87,876) |  |

[0000320193-20-000096:mdna:75]
(1)As of September 26, 2020 and September 28, 2019, total marketable securities included $18.6 billion and $18.9 billion, respectively, that was restricted from general use, related to the State Aid Decision (refer to Note 5, “Income Taxes” in the Notes to Consolidated Financial Statements in Part II, Item 8 of this Form 10-K) and other agreements.

[0000320193-20-000096:mdna:76]
The Company believes its existing balances of cash, cash equivalents and marketable securities, along with commercial paper and other short-term liquidity arrangements, will be sufficient to satisfy its working capital needs, capital asset purchases, dividends, share repurchases, debt repayments and other liquidity requirements associated with its existing operations over the next 12 months.

[0000320193-20-000096:mdna:77]
In connection with the State Aid Decision, as of September 26, 2020, the adjusted recovery amount of €12.9 billion plus interest of €1.2 billion was funded into escrow, where it will remain restricted from general use pending the conclusion of all legal proceedings. Further information regarding the State Aid Decision can be found in Part II, Item 8 of this Form 10-K in the Notes to Consolidated Financial Statements in Note 5, “Income Taxes.”

[0000320193-20-000096:mdna:78]
The Company’s marketable securities investment portfolio is primarily invested in highly rated securities, with the primary objective of minimizing the potential risk of principal loss. The Company’s investment policy generally requires securities to be investment grade and limits the amount of credit exposure to any one issuer.

[0000320193-20-000096:mdna:79]
During 2020, cash generated by operating activities of $80.7 billion was a result of $57.4 billion of net income, non-cash adjustments to net income of $17.6 billion and an increase in the net change in operating assets and liabilities of $5.7 billion. Cash used in investing activities of $4.3 billion during 2020 consisted primarily of cash used to acquire property, plant and equipment of $7.3 billion and cash paid for business acquisitions, net of cash acquired, of $1.5 billion, partially offset by proceeds from maturities and sales of marketable securities, net of purchases, of $5.5 billion. Cash used in financing activities of $86.8 billion during 2020 consisted primarily of cash used to repurchase common stock of $72.4 billion, cash used to pay dividends and dividend equivalents of $14.1 billion, cash used to repay or redeem term debt of $12.6 billion and net repayments of commercial paper of $1.0 billion, partially offset by net proceeds from the issuance of term debt of $16.1 billion.

[0000320193-20-000096:mdna:80]
During 2019, cash generated by operating activities of $69.4 billion was a result of $55.3 billion of net income and non-cash adjustments to net income of $17.6 billion, partially offset by a decrease in the net change in operating assets and liabilities of $3.5 billion. Cash generated by investing activities of $45.9 billion during 2019 consisted primarily of proceeds from sales and maturities of marketable securities, net of purchases, of $57.5 billion, partially offset by cash used to acquire property, plant and equipment of $10.5 billion. Cash used in financing activities of $91.0 billion during 2019 consisted primarily of cash used to repurchase common stock of $66.9 billion, cash used to pay dividends and dividend equivalents of $14.1 billion, cash used to repay term debt of $8.8 billion and net repayments of commercial paper of $6.0 billion, partially offset by net proceeds from the issuance of term debt of $7.0 billion.

[0000320193-20-000096:mdna:81]
Debt

[0000320193-20-000096:mdna:82]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses the net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of September 26, 2020, the Company had $5.0 billion of Commercial Paper outstanding, with a weighted-average interest rate of 0.62% and maturities generally less than nine months.

[0000320193-20-000096:mdna:83]
The Company may enter into agreements to sell certain of its marketable securities with a promise to repurchase the securities at a specified time and amount as an additional short-term liquidity arrangement.

[0000320193-20-000096:mdna:84]
As of September 26, 2020, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $106.1 billion (collectively the “Notes”). During 2020, the Company issued $16.1 billion and repaid or redeemed $12.6 billion of Notes. The Company has entered, and in the future may enter, into interest rate swaps to manage interest rate risk on the Notes. In addition, the Company has entered, and in the future may enter, into foreign currency swaps to manage foreign currency risk on the Notes.

[0000320193-20-000096:mdna:85]
Further information regarding the Company’s debt issuances and related hedging activity can be found in Part II, Item 8 of this Form 10-K in the Notes to Consolidated Financial Statements in Note 3, “Financial Instruments” and Note 6, “Debt.”

[0000320193-20-000096:mdna:86]
Capital Return Program

[0000320193-20-000096:mdna:87]
As of September 26, 2020, the Company was authorized to purchase up to $225 billion of the Company’s common stock under a share repurchase program, of which $168.6 billion had been utilized. During 2020, the Company repurchased 917 million shares of its common stock for $72.5 billion, including 141 million shares delivered under a $10.0 billion November 2019 ASR and 64 million shares delivered under a $6.0 billion May 2020 ASR. The Company’s share repurchase program does not obligate it to acquire any specific number of shares. Under this program, shares may be repurchased in privately negotiated and/or open market transactions, including under plans complying with Rule 10b5-1 under the Exchange Act.

[0000320193-20-000096:mdna:88]
As of September 26, 2020, the Company’s quarterly cash dividend was $0.205 per share. The Company intends to increase its dividend on an annual basis, subject to declaration by the Board of Directors.

[0000320193-20-000096:mdna:89]
Contractual Obligations

[0000320193-20-000096:mdna:90]
The following table presents certain payments due by the Company as of September 26, 2020, and includes amounts already recorded on the Consolidated Balance Sheet, except for manufacturing purchase obligations, other purchase obligations and certain lease obligations (in millions):

[0000320193-20-000096:mdna:91]
|  | Payments due in 2021 |  | Payments due in 2022–2023 |  | Payments due in 2024–2025 |  | Payments due after 2025 |  | Total |
| Term debt | $ | 8,750 |  |  | $ | 20,958 |  |  | $ | 21,029 |  |  | $ | 55,341 |  |  | $ | 106,078 |  |
| Leases | 1,622 |  |  | 3,097 |  |  | 2,352 |  |  | 5,888 |  |  | 12,959 |  |
| Manufacturing purchase obligations (1) | 47,961 |  |  | 1,849 |  |  | 61 |  |  | 40 |  |  | 49,911 |  |
| Other purchase obligations | 6,178 |  |  | 2,736 |  |  | 400 |  |  | 90 |  |  | 9,404 |  |
| Deemed repatriation tax payable | 1,533 |  |  | 5,923 |  |  | 12,955 |  |  | 9,254 |  |  | 29,665 |  |
| Total | $ | 66,044 |  |  | $ | 34,563 |  |  | $ | 36,797 |  |  | $ | 70,613 |  |  | $ | 208,017 |  |

[0000320193-20-000096:mdna:92]
(1)Represents amount expected to be paid under manufacturing-related supplier arrangements, which are primarily noncancelable.

[0000320193-20-000096:mdna:93]
Leases

[0000320193-20-000096:mdna:94]
The Company has lease arrangements for certain equipment and facilities, including retail, corporate, manufacturing and data center space. The Company’s retail store and other facility leases typically have original terms not exceeding 10 years and generally contain multi-year renewal options. The above contractual obligations table includes future payments under leases that had commenced as of September 26, 2020, and were therefore recorded on the Company’s Consolidated Balance Sheet, as well as leases that had been signed but not yet commenced as of September 26, 2020. Further information regarding the Company’s leases can be found in Part II, Item 8 of this Form 10-K in the Notes to Consolidated Financial Statements in Note 12, “Leases.”

[0000320193-20-000096:mdna:95]
Manufacturing Purchase Obligations

[0000320193-20-000096:mdna:96]
The Company utilizes several outsourcing partners to manufacture sub-assemblies for the Company’s products and to perform final assembly and testing of finished products. These outsourcing partners acquire components and build product based on demand information supplied by the Company, which typically covers periods up to 150 days. The Company also obtains individual components for its products from a wide variety of individual suppliers.

[0000320193-20-000096:mdna:97]
Other Purchase Obligations

[0000320193-20-000096:mdna:98]
The Company’s other purchase obligations consist of noncancelable obligations to acquire capital assets, including product tooling and manufacturing process equipment, and noncancelable obligations related to advertising, licensing, R&D, Internet and telecommunications services, content creation and other activities.

[0000320193-20-000096:mdna:99]
Deemed Repatriation Tax Payable

[0000320193-20-000096:mdna:100]
As of September 26, 2020, a significant portion of the other non-current liabilities in the Company’s Consolidated Balance Sheet consisted of the deemed repatriation tax payable imposed by the Act. The Company plans to pay the deemed repatriation tax payable in installments in accordance with the Act.

[0000320193-20-000096:mdna:101]
Other Non-Current Liabilities

[0000320193-20-000096:mdna:102]
The Company’s remaining other non-current liabilities primarily consist of items for which the Company is unable to make a reasonably reliable estimate of the timing or amount of payments; therefore, such amounts are not included in the above contractual obligations table.

[0000320193-20-000096:mdna:103]
Critical Accounting Policies and Estimates

[0000320193-20-000096:mdna:104]
The preparation of financial statements and related disclosures in conformity with U.S. generally accepted accounting principles (“GAAP”) and the Company’s discussion and analysis of its financial condition and operating results require the Company’s management to make judgments, assumptions and estimates that affect the amounts reported. Note 1, “Summary of Significant Accounting Policies,” of the Notes to Consolidated Financial Statements in Part II, Item 8 of this Form 10-K describes the significant accounting policies and methods used in the preparation of the Company’s consolidated financial statements. Management bases its estimates on historical experience and on various other assumptions it believes to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities. Actual results may differ from these estimates, and such differences may be material.

[0000320193-20-000096:mdna:105]
Management believes the Company’s critical accounting policies and estimates are those related to revenue recognition, valuation of manufacturing-related assets and estimation of inventory purchase commitment cancellation fees, warranty costs, income taxes, and legal and other contingencies. Management considers these policies critical because they are both important to the portrayal of the Company’s financial condition and operating results, and they require management to make judgments and estimates about inherently uncertain matters. The Company’s senior management has reviewed these critical accounting policies and related disclosures with the Audit and Finance Committee of the Company’s Board of Directors.

[0000320193-20-000096:mdna:106]
Revenue Recognition

[0000320193-20-000096:mdna:107]
The Company has identified up to three performance obligations regularly included in arrangements involving the sale of iPhone, Mac, iPad and certain other products. The first performance obligation, which represents the substantial portion of the allocated sales price, is the hardware and bundled software delivered at the time of sale. The second performance obligation is the right to receive certain product-related bundled services, which include iCloud, Siri and Maps. The third performance obligation is the right to receive, on a when-and-if-available basis, future unspecified software upgrades relating to the software bundled with each device. The Company allocates revenue and any related discounts to these performance obligations based on their relative stand-alone selling prices (“SSPs”). Because the Company lacks observable prices for the undelivered performance obligations, the allocation of revenue is based on the Company’s estimated SSPs. Revenue allocated to the product-related bundled services and unspecified software upgrade rights is deferred and recognized on a straight-line basis over the estimated period they are expected to be provided.

[0000320193-20-000096:mdna:108]
The Company’s process for determining estimated SSPs involves management’s judgment and considers multiple factors that may vary over time depending upon the unique facts and circumstances related to each deliverable. Should future facts and circumstances change, the Company’s SSPs and the future rate of related amortization for product-related bundled services and unspecified software upgrade rights related to future sales of these devices could change. Factors subject to change include the nature of the product-related bundled services and unspecified software upgrade rights offered, their estimated value and the estimated period they are expected to be provided.

[0000320193-20-000096:mdna:109]
Valuation of Manufacturing-Related Assets and Estimation of Inventory Purchase Commitment Cancellation Fees

[0000320193-20-000096:mdna:110]
The Company invests in manufacturing-related assets, including capital assets held at its suppliers’ facilities and prepayments provided to certain of its suppliers associated with long-term agreements to secure the supply of inventory. The Company also accrues estimated purchase commitment cancellation fees related to inventory orders that have been canceled or are expected to be canceled. The Company’s estimates of future product development plans and demand for its products are key inputs in determining the recoverability of manufacturing-related assets and assessing the adequacy of any purchase commitment cancellation fee accruals. If there is an abrupt and substantial decline in estimated demand for one or more of the Company’s products, a change in the Company’s product development plans, or an unanticipated change in technological requirements for any of the Company’s products, the Company may be required to record write-downs or impairments of manufacturing-related assets or accrue purchase commitment cancellation fees.

[0000320193-20-000096:mdna:111]
Warranty Costs

[0000320193-20-000096:mdna:112]
The Company offers limited warranties on its new and certified refurbished hardware products and on parts used to repair its hardware products, and customers may purchase extended service coverage, where available, on many of the Company’s hardware products. The Company accrues the estimated cost of warranties in the period the related revenue is recognized based on historical and projected warranty claim rates, historical and projected cost per claim and knowledge of specific product failures outside the Company’s typical experience. If actual product failure rates or repair costs differ from estimates, revisions to the estimated warranty liabilities would be required.

[0000320193-20-000096:mdna:113]
Income Taxes

[0000320193-20-000096:mdna:114]
The Company recognizes tax benefits from uncertain tax positions if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such positions are measured based on the largest benefit that has a greater-than-50% likelihood of being realized upon ultimate settlement. The calculation of tax liabilities involves significant judgment in estimating the impact of uncertainties in the application of GAAP and complex tax laws. Resolution of these uncertainties in a manner inconsistent with management’s expectations could have a material impact on the Company’s financial condition and operating results.

[0000320193-20-000096:mdna:115]
Legal and Other Contingencies

[0000320193-20-000096:mdna:116]
As discussed in Part I, Item 3 of this Form 10-K under the heading “Legal Proceedings” and in Part II, Item 8 of this Form 10-K in the Notes to Consolidated Financial Statements in Note 10, “Commitments and Contingencies,” the Company is subject to various legal proceedings and claims that arise in the ordinary course of business. The Company records a liability when it is probable that a loss has been incurred and the amount is reasonably estimable, the determination of which requires significant judgment. Except as described in Part II, Item 8 of this Form 10-K in the Notes to Consolidated Financial Statements in Note 10, “Commitments and Contingencies” under the heading “Contingencies,” in the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss greater than a recorded accrual, concerning loss contingencies for asserted legal and other claims.

[0000320193-20-000096:mdna:117]
The outcome of litigation is inherently uncertain. If one or more legal matters were resolved against the Company in a reporting period for amounts above management’s expectations, the Company’s financial condition and operating results for that reporting period could be materially adversely affected.
