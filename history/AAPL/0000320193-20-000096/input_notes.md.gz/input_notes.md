# AAPL notes — 0000320193-20-000096


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000320193-20-000096:notes:1]
Summary of Significant Accounting Policies
Basis of Presentation and Preparation

[0000320193-20-000096:notes:2]
The consolidated financial statements include the accounts of Apple Inc. and its wholly owned subsidiaries (collectively “Apple” or the “Company”). Intercompany accounts and transactions have been eliminated. In the opinion of the Company’s management, the consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these consolidated financial statements and accompanying notes in conformity with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported. Actual results could differ materially from those estimates. Certain prior period amounts in the consolidated financial statements and accompanying notes have been reclassified to conform to the current period’s presentation.

[0000320193-20-000096:notes:3]
The Company’s fiscal year is the 52- or 53-week period that ends on the last Saturday of September. The Company’s fiscal years 2020, 2019 and 2018 spanned 52 weeks each. An additional week is included in the first fiscal quarter every five or six years to realign the Company’s fiscal quarters with calendar quarters. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in September and the associated quarters, months and periods of those fiscal years.

[0000320193-20-000096:notes:4]
Common Stock Split

[0000320193-20-000096:notes:5]
On August 28, 2020, the Company effected a four-for-one stock split to shareholders of record as of August 24, 2020. All share, restricted stock unit (“RSU”) and per share or per RSU information has been retroactively adjusted to reflect the stock split.

[0000320193-20-000096:notes:6]
Recently Adopted Accounting Pronouncements

[0000320193-20-000096:notes:7]
Leases

[0000320193-20-000096:notes:8]
At the beginning of the first quarter of 2020, the Company adopted the Financial Accounting Standards Board’s (the “FASB”) Accounting Standards Update (“ASU”) No. 2016-02, Leases (Topic 842) (“ASU 2016-02”), and additional ASUs issued to clarify and update the guidance in ASU 2016-02 (collectively, the “new leases standard”), which modifies lease accounting for lessees to increase transparency and comparability by recording lease assets and liabilities for operating leases and disclosing key information about leasing arrangements. The Company adopted the new leases standard utilizing the modified retrospective transition method, under which amounts in prior periods presented were not restated. For contracts existing at the time of adoption, the Company elected to not reassess (i) whether any are or contain leases, (ii) lease classification, and (iii) initial direct costs. Upon adoption, the Company recorded $7.5 billion of right-of-use (“ROU”) assets and $8.1 billion of lease liabilities on its Condensed Consolidated Balance Sheet.

[0000320193-20-000096:notes:9]
Hedging

[0000320193-20-000096:notes:10]
At the beginning of the first quarter of 2020, the Company adopted FASB ASU No. 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities (“ASU 2017-12”). ASU 2017-12 expands component and fair value hedging, specifies the presentation of the effects of hedging instruments, eliminates the separate measurement and presentation of hedge ineffectiveness, and updates disclosure requirements related to hedging. The Company adopted ASU 2017-12 utilizing the modified retrospective transition method. Upon adoption, the Company recorded a $136 million increase in accumulated other comprehensive income/(loss) (“AOCI”) and a corresponding decrease in retained earnings in the Condensed Consolidated Statement of Shareholders’ Equity.

[0000320193-20-000096:notes:11]
Advertising Costs

[0000320193-20-000096:notes:12]
Advertising costs are expensed as incurred and included in selling, general and administrative expenses.

[0000320193-20-000096:notes:13]
Share-Based Compensation

[0000320193-20-000096:notes:14]
The Company generally measures share-based compensation based on the closing price of the Company’s common stock on the date of grant, and recognizes expense on a straight-line basis for its estimate of equity awards that will ultimately vest. Further information regarding share-based compensation can be found in Note 9, “Benefit Plans.”

[0000320193-20-000096:notes:15]
Earnings Per Share

[0000320193-20-000096:notes:16]
The following table shows the computation of basic and diluted earnings per share for 2020, 2019 and 2018 (net income in millions and shares in thousands):

[0000320193-20-000096:notes:17]
|  | 2020 |  | 2019 |  | 2018 |
| Numerator: |  |  |  |  |  |
| Net income | $ | 57,411 |  |  | $ | 55,256 |  |  | $ | 59,531 |  |
| Denominator: |  |  |  |  |  |
| Weighted-average basic shares outstanding | 17,352,119 |  |  | 18,471,336 |  |  | 19,821,510 |  |
| Effect of dilutive securities | 176,095 |  |  | 124,315 |  |  | 178,925 |  |
| Weighted-average diluted shares | 17,528,214 |  |  | 18,595,651 |  |  | 20,000,435 |  |
| Basic earnings per share | $ | 3.31 |  |  | $ | 2.99 |  |  | $ | 3.00 |  |
| Diluted earnings per share | $ | 3.28 |  |  | $ | 2.97 |  |  | $ | 2.98 |  |

[0000320193-20-000096:notes:18]
The Company applies the treasury stock method to determine the dilutive effect of potentially dilutive securities. Potentially dilutive securities representing 62 million shares of common stock were excluded from the computation of diluted earnings per share for 2019 because their effect would have been antidilutive.

[0000320193-20-000096:notes:19]
Cash Equivalents and Marketable Securities

[0000320193-20-000096:notes:20]
All highly liquid investments with maturities of three months or less at the date of purchase are classified as cash equivalents.

[0000320193-20-000096:notes:21]
The Company’s investments in marketable debt securities have been classified and accounted for as available-for-sale. The Company classifies its marketable debt securities as either short-term or long-term based on each instrument’s underlying contractual maturity date. Unrealized gains and losses on marketable debt securities classified as available-for-sale are recognized in other comprehensive income/(loss) (“OCI”).

[0000320193-20-000096:notes:22]
The Company’s investments in marketable equity securities are classified based on the nature of the securities and their availability for use in current operations. The Company’s marketable equity securities are measured at fair value with gains and losses recognized in other income/(expense), net (“OI&E”).

[0000320193-20-000096:notes:23]
The cost of securities sold is determined using the specific identification method.

[0000320193-20-000096:notes:24]
Inventories

[0000320193-20-000096:notes:25]
Inventories are measured using the first-in, first-out method.

[0000320193-20-000096:notes:26]
Property, Plant and Equipment

[0000320193-20-000096:notes:27]
Depreciation on property, plant and equipment is recognized on a straight-line basis over the estimated useful lives of the assets, which for buildings is the lesser of 40 years or the remaining life of the building; between one and five years for machinery and equipment, including product tooling and manufacturing process equipment; and the shorter of lease term or useful life for leasehold improvements. Capitalized costs related to internal-use software are amortized on a straight-line basis over the estimated useful lives of the assets, which range from three to seven years. Depreciation and amortization expense on property and equipment was $9.7 billion, $11.3 billion and $9.3 billion during 2020, 2019 and 2018, respectively.

[0000320193-20-000096:notes:28]
Non-cash investing activities involving property, plant and equipment resulted in a net increase/(decrease) to accounts payable and other current liabilities of $(2.9) billion and $3.4 billion during 2019 and 2018, respectively.

[0000320193-20-000096:notes:29]
Non-Marketable Securities

[0000320193-20-000096:notes:30]
The Company has elected to apply the measurement alternative to equity securities without readily determinable fair values. As such, the Company’s non-marketable equity securities are measured at cost, less any impairment, and are adjusted for changes in fair value resulting from observable transactions for identical or similar investments of the same issuer. Gains and losses on non-marketable equity securities are recognized in OI&E.

[0000320193-20-000096:notes:31]
Restricted Cash and Restricted Marketable Securities

[0000320193-20-000096:notes:32]
The Company considers cash and marketable securities to be restricted when withdrawal or general use is legally restricted. The Company reports restricted cash as other assets in the Consolidated Balance Sheets, and determines current or non-current classification based on the expected duration of the restriction. The Company reports restricted marketable securities as current or non-current marketable securities in the Consolidated Balance Sheets based on the classification of the underlying securities.

[0000320193-20-000096:notes:33]
Fair Value Measurements

[0000320193-20-000096:notes:34]
The fair values of the Company’s money market funds and certain marketable equity securities are based on quoted prices in active markets for identical assets. The valuation techniques used to measure the fair value of the Company’s debt instruments and all other financial instruments, which generally have counterparties with high credit ratings, are based on quoted market prices or model-driven valuations using significant inputs derived from or corroborated by observable market data.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000320193-20-000096:notes:35]
The fair values of the Company’s money market funds and certain marketable equity securities are based on quoted prices in active markets for identical assets. The valuation techniques used to measure the fair value of the Company’s debt instruments and all other financial instruments, which generally have counterparties with high credit ratings, are based on quoted market prices or model-driven valuations using significant inputs derived from or corroborated by observable market data.
Level 1 fair value estimates are based on quoted prices in active markets for identical assets or liabilities.Level 2 fair value estimates are based on observable inputs other than quoted prices in active markets for identical assets and liabilities, quoted prices for identical or similar assets or liabilities in inactive markets, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000320193-20-000096:notes:36]
Revenue Recognition
Net sales consist of revenue from the sale of iPhone, Mac, iPad, Services and other products. The Company recognizes revenue at the amount to which it expects to be entitled when control of the products or services is transferred to its customers. Control is generally transferred when the Company has a present right to payment and title and the significant risks and rewards of ownership of products or services are transferred to its customers. For most of the Company’s Products net sales, control transfers when products are shipped. For the Company’s Services net sales, control transfers over time as services are delivered. Payment for Products and Services net sales is collected within a short period following transfer of control or commencement of delivery of services, as applicable.

[0000320193-20-000096:notes:37]
The Company records reductions to Products net sales related to future product returns, price protection and other customer incentive programs based on the Company’s expectations and historical experience.

[0000320193-20-000096:notes:38]
For arrangements with multiple performance obligations, which represent promises within an arrangement that are distinct, the Company allocates revenue to all distinct performance obligations based on their relative stand-alone selling prices (“SSPs”). When available, the Company uses observable prices to determine SSPs. When observable prices are not available, SSPs are established that reflect the Company’s best estimates of what the selling prices of the performance obligations would be if they were sold regularly on a stand-alone basis. The Company’s process for estimating SSPs without observable prices considers multiple factors that may vary depending upon the unique facts and circumstances related to each performance obligation including, where applicable, prices charged by the Company for similar offerings, market trends in the pricing for similar offerings, product-specific business objectives and the estimated cost to provide the performance obligation.

[0000320193-20-000096:notes:39]
The Company has identified up to three performance obligations regularly included in arrangements involving the sale of iPhone, Mac, iPad and certain other products. The first performance obligation, which represents the substantial portion of the allocated sales price, is the hardware and bundled software delivered at the time of sale. The second performance obligation is the right to receive certain product-related bundled services, which include iCloud, Siri and Maps. The third performance obligation is the right to receive, on a when-and-if-available basis, future unspecified software upgrades relating to the software bundled with each device. The Company allocates revenue and any related discounts to these performance obligations based on their relative SSPs. Because the Company lacks observable prices for the undelivered performance obligations, the allocation of revenue is based on the Company’s estimated SSPs. Revenue allocated to the delivered hardware and bundled software is recognized when control has transferred to the customer, which generally occurs when the product is shipped. Revenue allocated to the product-related bundled services and unspecified software upgrade rights is deferred and recognized on a straight-line basis over the estimated period they are expected to be provided. Cost of sales related to delivered hardware and bundled software, including estimated warranty costs, are recognized at the time of sale. Costs incurred to provide product-related bundled services and unspecified software upgrade rights are recognized as cost of sales as incurred.

[0000320193-20-000096:notes:40]
For certain long-term service arrangements, the Company has performance obligations for services it has not yet delivered. For these arrangements, the Company does not have a right to bill for the undelivered services. The Company has determined that any unbilled consideration relates entirely to the value of the undelivered services. Accordingly, the Company has not recognized revenue, and has elected not to disclose amounts, related to these undelivered services.

[0000320193-20-000096:notes:41]
For the sale of third-party products where the Company obtains control of the product before transferring it to the customer, the Company recognizes revenue based on the gross amount billed to customers. The Company considers multiple factors when determining whether it obtains control of third-party products including, but not limited to, evaluating if it can establish the price of the product, retains inventory risk for tangible products or has the responsibility for ensuring acceptability of the product. For third-party applications sold through the App Store and certain digital content sold through the Company’s other digital content stores, the Company does not obtain control of the product before transferring it to the customer. Therefore, the Company accounts for such sales on a net basis by recognizing in Services net sales only the commission it retains.

[0000320193-20-000096:notes:42]
The Company has elected to record revenue net of taxes collected from customers that are remitted to governmental authorities, with the collected taxes recorded within other current liabilities until remitted to the relevant government authority.

[0000320193-20-000096:notes:43]
Deferred Revenue

[0000320193-20-000096:notes:44]
As of September 26, 2020 and September 28, 2019, the Company had total deferred revenue of $10.2 billion and $8.1 billion, respectively. As of September 26, 2020, the Company expects 65% of total deferred revenue to be realized in less than a year, 25% within one-to-two years, 8% within two-to-three years and 2% in greater than three years.

[0000320193-20-000096:notes:45]
Disaggregated Revenue

[0000320193-20-000096:notes:46]
Net sales disaggregated by significant products and services for 2020, 2019 and 2018 were as follows (in millions):

[0000320193-20-000096:notes:47]
|  | 2020 |  | 2019 |  | 2018 |
| iPhone (1) | $ | 137,781 |  |  | $ | 142,381 |  |  | $ | 164,888 |  |
| Mac (1) | 28,622 |  |  | 25,740 |  |  | 25,198 |  |
| iPad (1) | 23,724 |  |  | 21,280 |  |  | 18,380 |  |
| Wearables, Home and Accessories (1)(2) | 30,620 |  |  | 24,482 |  |  | 17,381 |  |
| Services (3) | 53,768 |  |  | 46,291 |  |  | 39,748 |  |
| Total net sales (4) | $ | 274,515 |  |  | $ | 260,174 |  |  | $ | 265,595 |  |

[0000320193-20-000096:notes:48]
(1)Products net sales include amortization of the deferred value of unspecified software upgrade rights, which are bundled in the sales price of the respective product.

[0000320193-20-000096:notes:49]
(2)Wearables, Home and Accessories net sales include sales of AirPods, Apple TV, Apple Watch, Beats products, HomePod, iPod touch and Apple-branded and third-party accessories.

[0000320193-20-000096:notes:50]
(3)Services net sales include sales from the Company’s advertising, AppleCare, digital content and other services. Services net sales also include amortization of the deferred value of Maps, Siri, and free iCloud storage and Apple TV+ services, which are bundled in the sales price of certain products.

[0000320193-20-000096:notes:51]
(4)Includes $5.0 billion of revenue recognized in 2020 that was included in deferred revenue as of September 28, 2019, $5.9 billion of revenue recognized in 2019 that was included in deferred revenue as of September 29, 2018, and $5.8 billion of revenue recognized in 2018 that was included in deferred revenue as of September 30, 2017.

[0000320193-20-000096:notes:52]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 11, “Segment Information and Geographic Data” for 2020, 2019 and 2018.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000320193-20-000096:notes:53]
Financial Instruments
Cash, Cash Equivalents and Marketable Securities

[0000320193-20-000096:notes:54]
The following tables show the Company’s cash and marketable securities by significant investment category as of September 26, 2020 and September 28, 2019 (in millions):

[0000320193-20-000096:notes:55]
|  | 2020 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | CurrentMarketableSecurities |  | Non-CurrentMarketableSecurities |
| Cash | $ | 17,773 |  |  | $ | — |  |  | $ | — |  |  | $ | 17,773 |  |  | $ | 17,773 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 2,171 |  |  | — |  |  | — |  |  | 2,171 |  |  | 2,171 |  |  | — |  |  | — |  |
| Subtotal | 2,171 |  |  | — |  |  | — |  |  | 2,171 |  |  | 2,171 |  |  | — |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 28,439 |  |  | 331 |  |  | — |  |  | 28,770 |  |  | 8,580 |  |  | 11,972 |  |  | 8,218 |  |
| U.S. agency securities | 8,604 |  |  | 8 |  |  | — |  |  | 8,612 |  |  | 2,009 |  |  | 3,078 |  |  | 3,525 |  |
| Non-U.S. government securities | 19,361 |  |  | 275 |  |  | (186) |  |  | 19,450 |  |  | 255 |  |  | 3,329 |  |  | 15,866 |  |
| Certificates of deposit and time deposits | 10,399 |  |  | — |  |  | — |  |  | 10,399 |  |  | 4,043 |  |  | 6,246 |  |  | 110 |  |
| Commercial paper | 11,226 |  |  | — |  |  | — |  |  | 11,226 |  |  | 3,185 |  |  | 8,041 |  |  | — |  |
| Corporate debt securities | 76,937 |  |  | 1,834 |  |  | (175) |  |  | 78,596 |  |  | — |  |  | 19,687 |  |  | 58,909 |  |
| Municipal securities | 1,001 |  |  | 22 |  |  | — |  |  | 1,023 |  |  | — |  |  | 139 |  |  | 884 |  |
| Mortgage- and asset-backed securities | 13,520 |  |  | 314 |  |  | (24) |  |  | 13,810 |  |  | — |  |  | 435 |  |  | 13,375 |  |
| Subtotal | 169,487 |  |  | 2,784 |  |  | (385) |  |  | 171,886 |  |  | 18,072 |  |  | 52,927 |  |  | 100,887 |  |
| Total (3) | $ | 189,431 |  |  | $ | 2,784 |  |  | $ | (385) |  |  | $ | 191,830 |  |  | $ | 38,016 |  |  | $ | 52,927 |  |  | $ | 100,887 |  |

[0000320193-20-000096:notes:56]
|  | 2019 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | CurrentMarketableSecurities |  | Non-CurrentMarketableSecurities |
| Cash | $ | 12,204 |  |  | $ | — |  |  | $ | — |  |  | $ | 12,204 |  |  | $ | 12,204 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 15,897 |  |  | — |  |  | — |  |  | 15,897 |  |  | 15,897 |  |  | — |  |  | — |  |
| Subtotal | 15,897 |  |  | — |  |  | — |  |  | 15,897 |  |  | 15,897 |  |  | — |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 30,293 |  |  | 33 |  |  | (62) |  |  | 30,264 |  |  | 6,165 |  |  | 9,817 |  |  | 14,282 |  |
| U.S. agency securities | 9,767 |  |  | 1 |  |  | (3) |  |  | 9,765 |  |  | 6,489 |  |  | 2,249 |  |  | 1,027 |  |
| Non-U.S. government securities | 19,821 |  |  | 337 |  |  | (50) |  |  | 20,108 |  |  | 749 |  |  | 3,168 |  |  | 16,191 |  |
| Certificates of deposit and time deposits | 4,041 |  |  | — |  |  | — |  |  | 4,041 |  |  | 2,024 |  |  | 1,922 |  |  | 95 |  |
| Commercial paper | 12,433 |  |  | — |  |  | — |  |  | 12,433 |  |  | 5,193 |  |  | 7,240 |  |  | — |  |
| Corporate debt securities | 85,383 |  |  | 756 |  |  | (92) |  |  | 86,047 |  |  | 123 |  |  | 26,127 |  |  | 59,797 |  |
| Municipal securities | 958 |  |  | 8 |  |  | (1) |  |  | 965 |  |  | — |  |  | 68 |  |  | 897 |  |
| Mortgage- and asset-backed securities | 14,180 |  |  | 67 |  |  | (73) |  |  | 14,174 |  |  | — |  |  | 1,122 |  |  | 13,052 |  |
| Subtotal | 176,876 |  |  | 1,202 |  |  | (281) |  |  | 177,797 |  |  | 20,743 |  |  | 51,713 |  |  | 105,341 |  |
| Total (3) | $ | 204,977 |  |  | $ | 1,202 |  |  | $ | (281) |  |  | $ | 205,898 |  |  | $ | 48,844 |  |  | $ | 51,713 |  |  | $ | 105,341 |  |

[0000320193-20-000096:notes:57]
(1)Level 1 fair value estimates are based on quoted prices in active markets for identical assets or liabilities.

[0000320193-20-000096:notes:58]
(2)Level 2 fair value estimates are based on observable inputs other than quoted prices in active markets for identical assets and liabilities, quoted prices for identical or similar assets or liabilities in inactive markets, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities.

[0000320193-20-000096:notes:59]
(3)As of September 26, 2020 and September 28, 2019, total marketable securities included $18.6 billion and $18.9 billion, respectively, that was restricted from general use, related to the State Aid Decision (refer to Note 5, “Income Taxes”) and other agreements.

[0000320193-20-000096:notes:60]
The Company may sell certain of its marketable debt securities prior to their stated maturities for reasons including, but not limited to, managing liquidity, credit risk, duration and asset allocation. The maturities of the Company’s non-current marketable debt securities generally range from one to five years.

[0000320193-20-000096:notes:61]
The Company typically invests in highly rated securities, with the primary objective of minimizing the potential risk of principal loss. The Company’s investment policy generally requires securities to be investment grade and limits the amount of credit exposure to any one issuer. Fair values were determined for each individual security in the investment portfolio. When evaluating a marketable debt security for other-than-temporary impairment, the Company reviews factors such as the duration and extent to which the fair value of the security is less than its cost, the financial condition of the issuer and any changes thereto, and the Company’s intent to sell, or whether it will more likely than not be required to sell, the security before recovery of its amortized cost basis. As of September 26, 2020, the Company does not consider any of its marketable debt securities to be other-than-temporarily impaired.

[0000320193-20-000096:notes:62]
The Company holds non-marketable equity securities of certain privately held companies without readily determinable fair values. As of September 26, 2020 and September 28, 2019, the Company’s non-marketable equity securities had a carrying value of $2.8 billion and $2.9 billion, respectively.

[0000320193-20-000096:notes:63]
Restricted Cash

[0000320193-20-000096:notes:64]
A reconciliation of the Company’s cash and cash equivalents in the Consolidated Balance Sheets to cash, cash equivalents and restricted cash in the Consolidated Statements of Cash Flows as of September 26, 2020 and September 28, 2019 is as follows (in millions):

[0000320193-20-000096:notes:65]
|  | 2020 |  | 2019 |
| Cash and cash equivalents | $ | 38,016 |  |  | $ | 48,844 |  |
| Restricted cash included in other current assets | 36 |  |  | 23 |  |
| Restricted cash included in other non-current assets | 1,737 |  |  | 1,357 |  |
| Cash, cash equivalents and restricted cash | $ | 39,789 |  |  | $ | 50,224 |  |

[0000320193-20-000096:notes:66]
The Company’s restricted cash primarily consisted of cash to support the Company’s iPhone Upgrade Program.

[0000320193-20-000096:notes:67]
Derivative Financial Instruments

[0000320193-20-000096:notes:68]
The Company may use derivatives to partially offset its business exposure to foreign currency and interest rate risk on expected future cash flows, net investments in certain foreign subsidiaries, and certain existing assets and liabilities. However, the Company may choose not to hedge certain exposures for a variety of reasons including, but not limited to, accounting considerations or the prohibitive economic cost of hedging particular exposures. There can be no assurance the hedges will offset more than a portion of the financial impact resulting from movements in foreign currency exchange or interest rates.

[0000320193-20-000096:notes:69]
To protect gross margins from fluctuations in foreign currency exchange rates, certain of the Company’s subsidiaries whose functional currency is the U.S. dollar may hedge a portion of forecasted foreign currency revenue, and subsidiaries whose functional currency is not the U.S. dollar may hedge a portion of forecasted inventory purchases not denominated in the subsidiaries’ functional currencies. The Company may enter into forward contracts, option contracts or other instruments to manage this risk and may designate these instruments as cash flow hedges. The Company generally hedges portions of its forecasted foreign currency exposure associated with revenue and inventory purchases, typically for up to 12 months.

[0000320193-20-000096:notes:70]
To protect the net investment in a foreign operation from fluctuations in foreign currency exchange rates, the Company may enter into foreign currency forward and option contracts to offset a portion of the changes in the carrying amounts of these investments due to fluctuations in foreign currency exchange rates. In addition, the Company may use non-derivative financial instruments, such as its foreign currency–denominated debt, as hedges of its net investments in certain foreign subsidiaries. In both of these cases, the Company designates these instruments as net investment hedges.

[0000320193-20-000096:notes:71]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in foreign currency exchange rates, the Company may enter into forward contracts, cross-currency swaps or other instruments. These instruments may offset a portion of the foreign currency remeasurement gains or losses, or changes in fair value. The Company may designate these instruments as either cash flow or fair value hedges. As of September 26, 2020, the Company’s hedged term debt– and marketable securities–related foreign currency transactions are expected to be recognized within 22 years.

[0000320193-20-000096:notes:72]
The Company may also enter into non-designated foreign currency contracts to offset a portion of the foreign currency exchange gains and losses generated by the remeasurement of certain assets and liabilities denominated in non-functional currencies.

[0000320193-20-000096:notes:73]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in interest rates, the Company may enter into interest rate swaps, options or other instruments. These instruments may offset a portion of the changes in interest income or expense, or changes in fair value. The Company designates these instruments as either cash flow or fair value hedges. As of September 26, 2020, the Company’s hedged interest rate transactions are expected to be recognized within seven years.

[0000320193-20-000096:notes:74]
Cash Flow Hedges

[0000320193-20-000096:notes:75]
Cash flow hedge amounts that are included in the assessment of hedge effectiveness are deferred in AOCI until the hedged item is recognized in earnings. Deferred gains and losses associated with cash flow hedges of foreign currency revenue are recognized as a component of net sales in the same period as the related revenue is recognized, and deferred gains and losses related to cash flow hedges of inventory purchases are recognized as a component of cost of sales in the same period as the related costs are recognized. Deferred gains and losses associated with cash flow hedges of interest income or expense are recognized in OI&E in the same period as the related income or expense is recognized. For options designated as cash flow hedges, the time value is excluded from the assessment of hedge effectiveness and recognized in the financial statement line item to which the hedge relates on a straight-line basis over the life of the hedge. Changes in the fair value of amounts excluded from the assessment of hedge effectiveness are recognized in OCI.

[0000320193-20-000096:notes:76]
Derivative instruments designated as cash flow hedges must be de-designated as hedges when it is probable the forecasted hedged transaction will not occur in the initially identified time period or within a subsequent two-month time period. Deferred gains and losses in AOCI associated with such derivative instruments are reclassified into OI&E in the period of de-designation. Any subsequent changes in fair value of such derivative instruments are reflected in OI&E unless they are re-designated as hedges of other transactions.

[0000320193-20-000096:notes:77]
Net Investment Hedges

[0000320193-20-000096:notes:78]
Net investment hedge amounts that are included in the assessment of hedge effectiveness are recorded in OCI as a part of the cumulative translation adjustment. For foreign exchange forward contracts designated as net investment hedges, the forward carry component is excluded from the assessment of hedge effectiveness and recognized in OCI on a straight-line basis over the life of the hedge. Changes in the fair value of amounts excluded from the assessment of hedge effectiveness are recognized in OCI.

[0000320193-20-000096:notes:79]
Fair Value Hedges

[0000320193-20-000096:notes:80]
Fair value hedge gains and losses related to amounts that are included in the assessment of hedge effectiveness are recognized in earnings along with a corresponding loss or gain related to the change in value of the hedged item in the same line in the Consolidated Statements of Operations. For foreign exchange forward contracts designated as fair value hedges, the forward carry component is excluded from the assessment of hedge effectiveness and recognized in OI&E on a straight-line basis over the life of the hedge. Amounts excluded from the effectiveness assessment of fair value hedges and recognized in OI&E were gains of $465 million and $777 million for 2020 and 2019, respectively. Changes in the fair value of amounts excluded from the assessment of hedge effectiveness are recognized in OCI.

[0000320193-20-000096:notes:81]
Non-Designated Derivatives

[0000320193-20-000096:notes:82]
Derivatives that are not designated as hedging instruments are adjusted to fair value through earnings in the financial statement line item to which the derivative relates.

[0000320193-20-000096:notes:83]
The Company records all derivatives in the Consolidated Balance Sheets at fair value. The Company’s accounting treatment for these derivative instruments is based on its hedge designation. The following tables show the Company’s derivative instruments at gross fair value as of September 26, 2020 and September 28, 2019 (in millions):

[0000320193-20-000096:notes:84]
|  | 2020 |
|  | Fair Value ofDerivatives Designatedas Hedge Instruments |  | Fair Value ofDerivatives Not Designatedas Hedge Instruments |  | TotalFair Value |
| Derivative assets (1): |  |  |  |  |  |
| Foreign exchange contracts | $ | 749 |  |  | $ | 303 |  |  | $ | 1,052 |  |
| Interest rate contracts | $ | 1,557 |  |  | $ | — |  |  | $ | 1,557 |  |
| Derivative liabilities (2): |  |  |  |  |  |
| Foreign exchange contracts | $ | 1,561 |  |  | $ | 485 |  |  | $ | 2,046 |  |

[0000320193-20-000096:notes:85]
|  | 2019 |
|  | Fair Value ofDerivatives Designatedas Hedge Instruments |  | Fair Value ofDerivatives Not Designatedas Hedge Instruments |  | TotalFair Value |
| Derivative assets (1): |  |  |  |  |  |
| Foreign exchange contracts | $ | 1,798 |  |  | $ | 323 |  |  | $ | 2,121 |  |
| Interest rate contracts | $ | 685 |  |  | $ | — |  |  | $ | 685 |  |
| Derivative liabilities (2): |  |  |  |  |  |
| Foreign exchange contracts | $ | 1,341 |  |  | $ | 160 |  |  | $ | 1,501 |  |
| Interest rate contracts | $ | 105 |  |  | $ | — |  |  | $ | 105 |  |

[0000320193-20-000096:notes:86]
(1)The fair value of derivative assets is measured using Level 2 fair value inputs and is included in other current assets and other non-current assets in the Consolidated Balance Sheets.

[0000320193-20-000096:notes:87]
(2)The fair value of derivative liabilities is measured using Level 2 fair value inputs and is included in other current liabilities and other non-current liabilities in the Consolidated Balance Sheets.

[0000320193-20-000096:notes:88]
The Company classifies cash flows related to derivative financial instruments as operating activities in its Consolidated Statements of Cash Flows.

[0000320193-20-000096:notes:89]
The following table shows the pre-tax gains and losses of the Company’s derivative and non-derivative instruments designated as cash flow and fair value hedges in OCI and the Consolidated Statements of Operations for 2020, 2019 and 2018 (in millions):

[0000320193-20-000096:notes:90]
|  | 2020 |  | 2019 |  | 2018 |
| Gains/(Losses) recognized in OCI – included in effectiveness assessment: |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |
| Foreign exchange contracts | $ | 365 |  |  | $ | (959) |  |  | $ | 682 |  |
| Interest rate contracts | (57) |  |  | — |  |  | 1 |  |
| Total | $ | 308 |  |  | $ | (959) |  |  | $ | 683 |  |
| Net investment hedges: |  |  |  |  |  |
| Foreign currency debt | $ | 15 |  |  | $ | (58) |  |  | $ | 4 |  |
| Gains/(Losses) reclassified from AOCI into net income – included in effectiveness assessment: |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |
| Foreign exchange contracts | $ | 1,553 |  |  | $ | (116) |  |  | $ | (482) |  |
| Interest rate contracts | (8) |  |  | (7) |  |  | 1 |  |
| Total | $ | 1,545 |  |  | $ | (123) |  |  | $ | (481) |  |

[0000320193-20-000096:notes:91]
The amount excluded from the effectiveness assessment of the Company’s hedges and recognized in OCI was a loss of $168 million for 2020.

[0000320193-20-000096:notes:92]
The following tables show information about the Company’s derivative instruments designated as fair value hedges and the related hedged items for 2020, 2019 and 2018 and as of September 26, 2020 (in millions):

[0000320193-20-000096:notes:93]
|  | 2020 |  | 2019 |  | 2018 |
| Gains/(Losses) on derivative instruments (1): |  |  |  |  |  |
| Foreign exchange contracts | $ | (992) |  |  | $ | 1,020 |  |  | $ | (168) |  |
| Interest rate contracts | 1,114 |  |  | 2,068 |  |  | (1,363) |  |
| Total | $ | 122 |  |  | $ | 3,088 |  |  | $ | (1,531) |  |
| Gains/(Losses) related to hedged items (1): |  |  |  |  |  |
| Marketable securities | $ | 991 |  |  | $ | (1,018) |  |  | $ | 167 |  |
| Fixed-rate debt | (1,114) |  |  | (2,068) |  |  | 1,363 |  |
| Total | $ | (123) |  |  | $ | (3,086) |  |  | $ | 1,530 |  |

[0000320193-20-000096:notes:94]
|  | 2020 |  |  |
| Carrying amounts of hedged assets/(liabilities): |  |  |  |
| Marketable securities (2) | $ | 16,270 |  |  |  |
| Fixed-rate debt (3) | $ | (21,033) |  |  |  |
| Cumulative hedging adjustments included in the carrying amounts of hedged items: |  |  |  |
| Marketable securities carrying amount increases/(decreases) | $ | 493 |  |  |  |
| Fixed-rate debt carrying amount (increases)/decreases | $ | (1,541) |  |  |  |

[0000320193-20-000096:notes:95]
(1)Gains and losses related to fair value hedges are included in OI&E in the Consolidated Statements of Operations.

[0000320193-20-000096:notes:96]
(2)The carrying amounts of marketable securities that are designated as hedged items in fair value hedges are included in current marketable securities and non-current marketable securities in the Consolidated Balance Sheet.

[0000320193-20-000096:notes:97]
(3)The carrying amounts of fixed-rate debt instruments that are designated as hedged items in fair value hedges are included in current term debt and non-current term debt in the Consolidated Balance Sheet.

[0000320193-20-000096:notes:98]
The following table shows the notional amounts of the Company’s outstanding derivative instruments and credit risk amounts associated with outstanding or unsettled derivative instruments as of September 26, 2020 and September 28, 2019 (in millions):

[0000320193-20-000096:notes:99]
|  | 2020 |  | 2019 |
|  | NotionalAmount |  | Credit RiskAmount |  | NotionalAmount |  | Credit RiskAmount |
| Instruments designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 57,410 |  |  | $ | 749 |  |  | $ | 61,795 |  |  | $ | 1,798 |  |
| Interest rate contracts | $ | 20,700 |  |  | $ | 1,557 |  |  | $ | 31,250 |  |  | $ | 685 |  |
| Instruments not designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 88,636 |  |  | $ | 303 |  |  | $ | 76,868 |  |  | $ | 323 |  |

[0000320193-20-000096:notes:100]
The notional amounts for outstanding derivative instruments provide one measure of the transaction volume outstanding and do not represent the amount of the Company’s exposure to credit or market loss. The credit risk amounts represent the Company’s gross exposure to potential accounting loss on derivative instruments that are outstanding or unsettled if all counterparties failed to perform according to the terms of the contract, based on then-current currency or interest rates at each respective date. The Company’s exposure to credit loss and market risk will vary over time as currency and interest rates change. Although the table above reflects the notional and credit risk amounts of the Company’s derivative instruments, it does not reflect the gains or losses associated with the exposures and transactions that the instruments are intended to hedge. The amounts ultimately realized upon settlement of these financial instruments, together with the gains and losses on the underlying exposures, will depend on actual market conditions during the remaining life of the instruments.

[0000320193-20-000096:notes:101]
The Company generally enters into master netting arrangements, which are designed to reduce credit risk by permitting net settlement of transactions with the same counterparty. To further limit credit risk, the Company generally enters into collateral security arrangements that provide for collateral to be received or posted when the net fair value of certain financial instruments fluctuates from contractually established thresholds. The Company presents its derivative assets and derivative liabilities at their gross fair values in its Consolidated Balance Sheets. As of September 26, 2020 and September 28, 2019, the net cash collateral received by the Company related to derivative instruments under its collateral security arrangements was $875 million and $1.6 billion, respectively. The Company includes gross collateral posted and received in other current assets and other current liabilities in the Consolidated Balance Sheets, respectively.

[0000320193-20-000096:notes:102]
Under master netting arrangements with the respective counterparties to the Company’s derivative contracts, the Company is allowed to net settle transactions with a single net amount payable by one party to the other. As of September 26, 2020 and September 28, 2019, the potential effects of these rights of set-off associated with the Company’s derivative contracts, including the effects of collateral, would be a reduction to both derivative assets and derivative liabilities of $2.8 billion and $2.7 billion, respectively, resulting in net derivative liabilities of $312 million and $407 million, respectively.

[0000320193-20-000096:notes:103]
Accounts Receivable

[0000320193-20-000096:notes:104]
Trade Receivables

[0000320193-20-000096:notes:105]
The Company has considerable trade receivables outstanding with its third-party cellular network carriers, wholesalers, retailers, resellers, small and mid-sized businesses and education, enterprise and government customers. The Company generally does not require collateral from its customers; however, the Company will require collateral or third-party credit support in certain instances to limit credit risk. In addition, when possible, the Company attempts to limit credit risk on trade receivables with credit insurance for certain customers or by requiring third-party financing, loans or leases to support credit exposure. These credit-financing arrangements are directly between the third-party financing company and the end customer. As such, the Company generally does not assume any recourse or credit risk sharing related to any of these arrangements.

[0000320193-20-000096:notes:106]
As of both September 26, 2020 and September 28, 2019, the Company had no customers that individually represented 10% or more of total trade receivables. The Company’s cellular network carriers accounted for 51% of total trade receivables as of September 28, 2019.

[0000320193-20-000096:notes:107]
Vendor Non-Trade Receivables

[0000320193-20-000096:notes:108]
The Company has non-trade receivables from certain of its manufacturing vendors resulting from the sale of components to these vendors who manufacture sub-assemblies or assemble final products for the Company. The Company purchases these components directly from suppliers. As of September 26, 2020, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 57% and 11%. As of September 28, 2019, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 59% and 14%.


## us-gaap:DerivativesPolicyTextBlock

[0000320193-20-000096:notes:109]
Fair Value Hedges
Fair value hedge gains and losses related to amounts that are included in the assessment of hedge effectiveness are recognized in earnings along with a corresponding loss or gain related to the change in value of the hedged item in the same line in the Consolidated Statements of Operations. For foreign exchange forward contracts designated as fair value hedges, the forward carry component is excluded from the assessment of hedge effectiveness and recognized in OI&E on a straight-line basis over the life of the hedge.Changes in the fair value of amounts excluded from the assessment of hedge effectiveness are recognized in OCI.
Non-Designated Derivatives

[0000320193-20-000096:notes:110]
Derivatives that are not designated as hedging instruments are adjusted to fair value through earnings in the financial statement line item to which the derivative relates.
The Company records all derivatives in the Consolidated Balance Sheets at fair value. The Company’s accounting treatment for these derivative instruments is based on its hedge designation.The Company classifies cash flows related to derivative financial instruments as operating activities in its Consolidated Statements of Cash Flows.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000320193-20-000096:notes:111]
Consolidated Financial Statement Details
The following tables show the Company’s consolidated financial statement details as of September 26, 2020 and September 28, 2019 (in millions):

[0000320193-20-000096:notes:112]
Property, Plant and Equipment, Net

[0000320193-20-000096:notes:113]
|  | 2020 |  | 2019 |
| Land and buildings | $ | 17,952 |  |  | $ | 17,085 |  |
| Machinery, equipment and internal-use software | 75,291 |  |  | 69,797 |  |
| Leasehold improvements | 10,283 |  |  | 9,075 |  |
| Gross property, plant and equipment | 103,526 |  |  | 95,957 |  |
| Accumulated depreciation and amortization | (66,760) |  |  | (58,579) |  |
| Total property, plant and equipment, net | $ | 36,766 |  |  | $ | 37,378 |  |

[0000320193-20-000096:notes:114]
Other Non-Current Liabilities

[0000320193-20-000096:notes:115]
|  | 2020 |  | 2019 |
| Long-term taxes payable | $ | 28,170 |  |  | $ | 29,545 |  |
| Other non-current liabilities | 26,320 |  |  | 20,958 |  |
| Total other non-current liabilities | $ | 54,490 |  |  | $ | 50,503 |  |

[0000320193-20-000096:notes:116]
Other Income/(Expense), Net

[0000320193-20-000096:notes:117]
The following table shows the detail of OI&E for 2020, 2019 and 2018 (in millions):

[0000320193-20-000096:notes:118]
|  | 2020 |  | 2019 |  | 2018 |
| Interest and dividend income | $ | 3,763 |  |  | $ | 4,961 |  |  | $ | 5,686 |  |
| Interest expense | (2,873) |  |  | (3,576) |  |  | (3,240) |  |
| Other income/(expense), net | (87) |  |  | 422 |  |  | (441) |  |
| Total other income/(expense), net | $ | 803 |  |  | $ | 1,807 |  |  | $ | 2,005 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000320193-20-000096:notes:119]
Income Taxes
U.S. Tax Cuts and Jobs Act

[0000320193-20-000096:notes:120]
On December 22, 2017, the U.S. enacted the Tax Cuts and Jobs Act (the “Act”), which significantly changed U.S. tax law. The Act lowered the Company’s U.S. statutory federal income tax rate from 35% to 21% effective January 1, 2018, while also imposing a deemed repatriation tax on previously deferred foreign income. The Act also created a new minimum tax on certain foreign earnings, for which the Company has elected to record certain deferred tax assets and liabilities.

[0000320193-20-000096:notes:121]
Provision for Income Taxes and Effective Tax Rate

[0000320193-20-000096:notes:122]
The provision for income taxes for 2020, 2019 and 2018, consisted of the following (in millions):

[0000320193-20-000096:notes:123]
|  | 2020 |  | 2019 |  | 2018 |
| Federal: |  |  |  |  |  |
| Current | $ | 6,306 |  |  | $ | 6,384 |  |  | $ | 41,425 |  |
| Deferred | (3,619) |  |  | (2,939) |  |  | (33,819) |  |
| Total | 2,687 |  |  | 3,445 |  |  | 7,606 |  |
| State: |  |  |  |  |  |
| Current | 455 |  |  | 475 |  |  | 551 |  |
| Deferred | 21 |  |  | (67) |  |  | 48 |  |
| Total | 476 |  |  | 408 |  |  | 599 |  |
| Foreign: |  |  |  |  |  |
| Current | 3,134 |  |  | 3,962 |  |  | 3,986 |  |
| Deferred | 3,383 |  |  | 2,666 |  |  | 1,181 |  |
| Total | 6,517 |  |  | 6,628 |  |  | 5,167 |  |
| Provision for income taxes | $ | 9,680 |  |  | $ | 10,481 |  |  | $ | 13,372 |  |

[0000320193-20-000096:notes:124]
The foreign provision for income taxes is based on foreign pre-tax earnings of $38.1 billion, $44.3 billion and $48.0 billion in 2020, 2019 and 2018, respectively.

[0000320193-20-000096:notes:125]
A reconciliation of the provision for income taxes, with the amount computed by applying the statutory federal income tax rate (21% in 2020 and 2019; 24.5% in 2018) to income before provision for income taxes for 2020, 2019 and 2018, is as follows (dollars in millions):

[0000320193-20-000096:notes:126]
|  | 2020 |  | 2019 |  | 2018 |
| Computed expected tax | $ | 14,089 |  |  | $ | 13,805 |  |  | $ | 17,890 |  |
| State taxes, net of federal effect | 423 |  |  | 423 |  |  | 271 |  |
| Impacts of the Act | (582) |  |  | — |  |  | 1,515 |  |
| Earnings of foreign subsidiaries | (2,534) |  |  | (2,625) |  |  | (5,606) |  |
| Research and development credit, net | (728) |  |  | (548) |  |  | (560) |  |
| Excess tax benefits from equity awards | (930) |  |  | (639) |  |  | (675) |  |
| Other | (58) |  |  | 65 |  |  | 537 |  |
| Provision for income taxes | $ | 9,680 |  |  | $ | 10,481 |  |  | $ | 13,372 |  |
| Effective tax rate | 14.4 | % |  | 15.9 | % |  | 18.3 | % |

[0000320193-20-000096:notes:127]
Deferred Tax Assets and Liabilities

[0000320193-20-000096:notes:128]
As of September 26, 2020 and September 28, 2019, the significant components of the Company’s deferred tax assets and liabilities were (in millions):

[0000320193-20-000096:notes:129]
|  | 2020 |  | 2019 |
| Deferred tax assets: |  |  |  |
| Amortization and depreciation | $ | 8,317 |  |  | $ | 11,645 |  |
| Accrued liabilities and other reserves | 4,934 |  |  | 5,196 |  |
| Lease liabilities | 2,038 |  |  | — |  |
| Deferred revenue | 1,638 |  |  | 1,372 |  |
| Other | 2,409 |  |  | 2,174 |  |
| Total deferred tax assets | 19,336 |  |  | 20,387 |  |
| Less: Valuation allowance | (1,041) |  |  | (747) |  |
| Total deferred tax assets, net | 18,295 |  |  | 19,640 |  |
| Deferred tax liabilities: |  |  |  |
| Minimum tax on foreign earnings | 7,045 |  |  | 10,809 |  |
| Right-of-use assets | 1,862 |  |  | — |  |
| Unrealized gains | 526 |  |  | 186 |  |
| Other | 705 |  |  | 600 |  |
| Total deferred tax liabilities | 10,138 |  |  | 11,595 |  |
| Net deferred tax assets | $ | 8,157 |  |  | $ | 8,045 |  |

[0000320193-20-000096:notes:130]
Deferred tax assets and liabilities reflect the effects of tax credits and the future income tax effects of temporary differences between the consolidated financial statement carrying amounts of existing assets and liabilities and their respective tax bases, and are measured using enacted tax rates that apply to taxable income in the years in which those temporary differences are expected to be recovered or settled.

[0000320193-20-000096:notes:131]
Uncertain Tax Positions

[0000320193-20-000096:notes:132]
As of September 26, 2020, the total amount of gross unrecognized tax benefits was $16.5 billion, of which $8.8 billion, if recognized, would impact the Company’s effective tax rate. As of September 28, 2019, the total amount of gross unrecognized tax benefits was $15.6 billion, of which $8.6 billion, if recognized, would have impacted the Company’s effective tax rate.

[0000320193-20-000096:notes:133]
The aggregate change in the balance of gross unrecognized tax benefits, which excludes interest and penalties, for 2020, 2019 and 2018, is as follows (in millions):

[0000320193-20-000096:notes:134]
|  | 2020 |  | 2019 |  | 2018 |
| Beginning balances | $ | 15,619 |  |  | $ | 9,694 |  |  | $ | 8,407 |  |
| Increases related to tax positions taken during a prior year | 454 |  |  | 5,845 |  |  | 2,431 |  |
| Decreases related to tax positions taken during a prior year | (791) |  |  | (686) |  |  | (2,212) |  |
| Increases related to tax positions taken during the current year | 1,347 |  |  | 1,697 |  |  | 1,824 |  |
| Decreases related to settlements with taxing authorities | (85) |  |  | (852) |  |  | (756) |  |
| Decreases related to expiration of the statute of limitations | (69) |  |  | (79) |  |  | — |  |
| Ending balances | $ | 16,475 |  |  | $ | 15,619 |  |  | $ | 9,694 |  |

[0000320193-20-000096:notes:135]
The Company is subject to taxation and files income tax returns in the U.S. federal jurisdiction and many state and foreign jurisdictions. The U.S. Internal Revenue Service (the “IRS”) concluded its review of the years 2013 through 2015 in 2018, and all years before 2016 are closed. Tax years after 2014 remain open in certain major foreign jurisdictions and are subject to examination by the taxing authorities. The Company believes that an adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax audits cannot be predicted with certainty. If any issues addressed in the Company’s tax audits are resolved in a manner inconsistent with its expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. Although the timing of resolution and/or closure of audits is not certain, the Company believes it is reasonably possible that its gross unrecognized tax benefits could decrease in the next 12 months by as much as $3.9 billion.

[0000320193-20-000096:notes:136]
Interest and Penalties

[0000320193-20-000096:notes:137]
The Company includes interest and penalties related to income tax matters within the provision for income taxes. As of September 26, 2020 and September 28, 2019, the total amount of gross interest and penalties accrued was $1.4 billion and $1.3 billion, respectively. The Company recognized interest and penalty expense in 2020, 2019 and 2018 of $85 million, $73 million and $489 million, respectively.

[0000320193-20-000096:notes:138]
European Commission State Aid Decision

[0000320193-20-000096:notes:139]
On August 30, 2016, the European Commission announced its decision that Ireland granted state aid to the Company by providing tax opinions in 1991 and 2007 concerning the tax allocation of profits of the Irish branches of two subsidiaries of the Company (the “State Aid Decision”). The State Aid Decision ordered Ireland to calculate and recover additional taxes from the Company for the period June 2003 through December 2014. Irish legislative changes, effective as of January 2015, eliminated the application of the tax opinions from that date forward. The recovery amount was calculated to be €13.1 billion, plus interest of €1.2 billion. The Company and Ireland appealed the State Aid Decision to the General Court of the Court of Justice of the European Union (the “General Court”). On July 15, 2020, the General Court annulled the State Aid Decision. On September 25, 2020, the European Commission appealed the General Court’s decision to the European Court of Justice. The Company believes that any incremental Irish corporate income taxes potentially due related to the State Aid Decision would be creditable against U.S. taxes, subject to any foreign tax credit limitations in the Act.

[0000320193-20-000096:notes:140]
On an annual basis, the Company may request approval from the Irish Minister for Finance to reduce the recovery amount for certain taxes paid to other countries. As of September 26, 2020, the adjusted recovery amount was €12.9 billion, excluding interest. The adjusted recovery amount plus interest is funded into escrow, where it will remain restricted from general use pending the conclusion of all legal proceedings. Refer to the Cash, Cash Equivalents and Marketable Securities section of Note 3, “Financial Instruments” for more information.


## us-gaap:IncomeTaxPolicyTextBlock

[0000320193-20-000096:notes:141]
The Act also created a new minimum tax on certain foreign earnings, for which the Company has elected to record certain deferred tax assets and liabilities.The Company includes interest and penalties related to income tax matters within the provision for income taxes.


## us-gaap:DebtDisclosureTextBlock

[0000320193-20-000096:notes:142]
Debt
Commercial Paper and Repurchase Agreements

[0000320193-20-000096:notes:143]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of September 26, 2020 and September 28, 2019, the Company had $5.0 billion and $6.0 billion of Commercial Paper outstanding, respectively, with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 0.62% and 2.24% as of September 26, 2020 and September 28, 2019, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for 2020, 2019 and 2018 (in millions):

[0000320193-20-000096:notes:144]
|  | 2020 |  | 2019 |  | 2018 |
| Maturities 90 days or less: |  |  |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | 100 |  |  | $ | (3,248) |  |  | $ | 1,044 |  |
| Maturities greater than 90 days: |  |  |  |  |  |
| Proceeds from commercial paper | 6,185 |  |  | 13,874 |  |  | 14,555 |  |
| Repayments of commercial paper | (7,248) |  |  | (16,603) |  |  | (15,636) |  |
| Repayments of commercial paper, net | (1,063) |  |  | (2,729) |  |  | (1,081) |  |
| Total repayments of commercial paper, net | $ | (963) |  |  | $ | (5,977) |  |  | $ | (37) |  |

[0000320193-20-000096:notes:145]
In 2020, the Company entered into agreements to sell certain of its marketable securities with a promise to repurchase the securities at a specified time and amount (“Repos”). Due to the Company’s continuing involvement with the marketable securities, the Company accounted for its Repos as collateralized borrowings. The Company entered into $5.2 billion of Repos during 2020, all of which had been settled as of September 26, 2020.

[0000320193-20-000096:notes:146]
Term Debt

[0000320193-20-000096:notes:147]
As of September 26, 2020, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $106.1 billion (collectively the “Notes”). The Notes are senior unsecured obligations and interest is payable in arrears. The following table provides a summary of the Company’s term debt as of September 26, 2020 and September 28, 2019:

[0000320193-20-000096:notes:148]
|  | Maturities(calendar year) |  | 2020 |  | 2019 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 – 2019 debt issuances: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2021 – 2022 |  | $ | 2,250 |  |  | 0.60% – 1.39% |  | $ | 4,250 |  |  | 2.25% – 3.28% |
| Fixed-rate 0.375% – 4.650% notes | 2020 – 2049 |  | 87,487 |  |  | 0.28% – 4.78% |  | 97,429 |  |  | 0.28% – 4.78% |
| First quarter 2020 debt issuance of €2.0 billion: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.000% – 0.500% notes | 2025 – 2031 |  | 2,341 |  |  | 0.03% – 0.56% |  | — |  |  | — | % |
| Third quarter 2020 debt issuance of $8.5 billion: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.750% – 2.650% notes | 2023 – 2050 |  | 8,500 |  |  | 0.84% – 2.72% |  | — |  |  | — | % |
| Fourth quarter 2020 debt issuance of $5.5 billion: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.550% – 2.550% notes | 2025 – 2060 |  | 5,500 |  |  | 0.60% – 2.59% |  | — |  |  | — | % |
| Total term debt |  |  | 106,078 |  |  |  |  | 101,679 |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  | (314) |  |  |  |  | (224) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 1,676 |  |  |  |  | 612 |  |  |  |
| Less: Current portion of term debt |  |  | (8,773) |  |  |  |  | (10,260) |  |  |  |
| Total non-current portion of term debt |  |  | $ | 98,667 |  |  |  |  | $ | 91,807 |  |  |  |

[0000320193-20-000096:notes:149]
To manage interest rate risk on certain of its U.S. dollar–denominated fixed- or floating-rate notes, the Company has entered into interest rate swaps to effectively convert the fixed interest rates to floating interest rates or the floating interest rates to fixed interest rates on a portion of these notes. Additionally, to manage foreign currency risk on certain of its foreign currency–denominated notes, the Company has entered into foreign currency swaps to effectively convert these notes to U.S. dollar–denominated notes.

[0000320193-20-000096:notes:150]
As of September 28, 2019, a portion of the Company’s Japanese yen–denominated notes with a carrying value of $1.0 billion was designated as a hedge of the foreign currency exposure of the Company’s net investment in a foreign operation. The Company’s Japanese yen–denominated notes matured during 2020 and the associated net investment hedges were terminated. For further discussion regarding the Company’s use of derivative instruments, refer to the Derivative Financial Instruments section of Note 3, “Financial Instruments.”

[0000320193-20-000096:notes:151]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $2.8 billion, $3.2 billion and $3.0 billion of interest cost on its term debt for 2020, 2019 and 2018, respectively.

[0000320193-20-000096:notes:152]
The future principal payments for the Company’s Notes as of September 26, 2020, are as follows (in millions):

[0000320193-20-000096:notes:153]
| 2021 | $ | 8,750 |  |
| 2022 | 9,569 |  |
| 2023 | 11,389 |  |
| 2024 | 10,115 |  |
| 2025 | 10,914 |  |
| Thereafter | 55,341 |  |
| Total term debt | $ | 106,078 |  |

[0000320193-20-000096:notes:154]
As of September 26, 2020 and September 28, 2019, the fair value of the Company’s Notes, based on Level 2 inputs, was $117.1 billion and $107.5 billion, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000320193-20-000096:notes:155]
Shareholders’ Equity
Share Repurchase Program

[0000320193-20-000096:notes:156]
As of September 26, 2020, the Company was authorized to purchase up to $225 billion of the Company’s common stock under a share repurchase program, of which $168.6 billion had been utilized. During 2020, the Company repurchased 917 million shares of its common stock for $72.5 billion, including 141 million shares delivered under a $10.0 billion November 2019 accelerated share repurchase arrangement (“ASR”) and 64 million shares delivered under a $6.0 billion May 2020 ASR. The Company’s share repurchase program does not obligate it to acquire any specific number of shares. Under this program, shares may be repurchased in privately negotiated and/or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).

[0000320193-20-000096:notes:157]
Shares of Common Stock

[0000320193-20-000096:notes:158]
The following table shows the changes in shares of common stock for 2020, 2019 and 2018 (in thousands):

[0000320193-20-000096:notes:159]
|  | 2020 |  | 2019 |  | 2018 |
| Common stock outstanding, beginning balances | 17,772,945 |  |  | 19,019,943 |  |  | 20,504,805 |  |
| Common stock repurchased | (917,270) |  |  | (1,380,819) |  |  | (1,622,198) |  |
| Common stock issued, net of shares withheld for employee taxes | 121,088 |  |  | 133,821 |  |  | 137,336 |  |
| Common stock outstanding, ending balances | 16,976,763 |  |  | 17,772,945 |  |  | 19,019,943 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000320193-20-000096:notes:160]
Comprehensive Income
The Company’s OCI consists of foreign currency translation adjustments from those subsidiaries not using the U.S. dollar as their functional currency, net deferred gains and losses on certain derivative instruments accounted for as cash flow hedges and unrealized gains and losses on marketable debt securities classified as available-for-sale.

[0000320193-20-000096:notes:161]
The following table shows the pre-tax amounts reclassified from AOCI into the Consolidated Statements of Operations, and the associated financial statement line items, for 2020 and 2019 (in millions):

[0000320193-20-000096:notes:162]
| Comprehensive Income Components |  | Financial Statement Line Items |  | 2020 |  | 2019 |
| Unrealized (gains)/losses on derivative instruments: |  |  |  |  |  |  |
| Foreign exchange contracts |  | Total net sales |  | $ | (365) |  |  | $ | (206) |  |
|  |  | Total cost of sales |  | (584) |  |  | (482) |  |
|  |  | Other income/(expense), net |  | (604) |  |  | 784 |  |
| Interest rate contracts |  | Other income/(expense), net |  | 8 |  |  | 7 |  |
|  |  |  |  | (1,545) |  |  | 103 |  |
| Unrealized (gains)/losses on marketable debt securities |  | Other income/(expense), net |  | (82) |  |  | 31 |  |
| Total amounts reclassified from AOCI |  |  |  | $ | (1,627) |  |  | $ | 134 |  |

[0000320193-20-000096:notes:163]
The following table shows the changes in AOCI by component for 2020 and 2019 (in millions):

[0000320193-20-000096:notes:164]
|  | Cumulative ForeignCurrency Translation |  | Unrealized Gains/Losseson Derivative Instruments |  | Unrealized Gains/Losseson Marketable Debt Securities |  | Total |
| Balances as of September 29, 2018 | $ | (1,055) |  |  | $ | 810 |  |  | $ | (3,209) |  |  | $ | (3,454) |  |
| Other comprehensive income/(loss) before reclassifications | (421) |  |  | (949) |  |  | 4,854 |  |  | 3,484 |  |
| Amounts reclassified from AOCI | — |  |  | 103 |  |  | 31 |  |  | 134 |  |
| Tax effect | 13 |  |  | 208 |  |  | (1,058) |  |  | (837) |  |
| Other comprehensive income/(loss) | (408) |  |  | (638) |  |  | 3,827 |  |  | 2,781 |  |
| Cumulative effect of change in accounting principle | — |  |  | — |  |  | 89 |  |  | 89 |  |
| Balances as of September 28, 2019 | (1,463) |  |  | 172 |  |  | 707 |  |  | (584) |  |
| Other comprehensive income/(loss) before reclassifications | 91 |  |  | 115 |  |  | 1,560 |  |  | 1,766 |  |
| Amounts reclassified from AOCI | — |  |  | (1,545) |  |  | (82) |  |  | (1,627) |  |
| Tax effect | (3) |  |  | 245 |  |  | (339) |  |  | (97) |  |
| Other comprehensive income/(loss) | 88 |  |  | (1,185) |  |  | 1,139 |  |  | 42 |  |
| Cumulative effect of change in accounting principle (1) | — |  |  | 136 |  |  | — |  |  | 136 |  |
| Balances as of September 26, 2020 | $ | (1,375) |  |  | $ | (877) |  |  | $ | 1,846 |  |  | $ | (406) |  |

[0000320193-20-000096:notes:165]
(1)Refer to Note 1, “Summary of Significant Accounting Policies” for more information on the Company’s adoption of ASU 2017-12 in 2020.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000320193-20-000096:notes:166]
Benefit Plans
2014 Employee Stock Plan

[0000320193-20-000096:notes:167]
In the second quarter of 2014, shareholders approved the 2014 Employee Stock Plan (the “2014 Plan”) and terminated the Company’s authority to grant new awards under the 2003 Employee Stock Plan (the “2003 Plan”). The 2014 Plan provides for broad-based equity grants to employees, including executive officers, and permits the granting of RSUs, stock grants, performance-based awards, stock options and stock appreciation rights, as well as cash bonus awards. RSUs granted under the 2014 Plan generally vest over four years, based on continued employment, and are settled upon vesting in shares of the Company’s common stock on a one-for-one basis. RSUs granted under the 2014 Plan reduce the number of shares available for grant under the plan by a factor of two times the number of RSUs granted. RSUs canceled and shares withheld to satisfy tax withholding obligations increase the number of shares available for grant under the 2014 Plan utilizing a factor of two times the number of RSUs canceled or shares withheld. Currently, all RSUs granted under the 2014 Plan have dividend equivalent rights (“DERs”), which entitle holders of RSUs to the same dividend value per share as holders of common stock. DERs are subject to the same vesting and other terms and conditions as the corresponding unvested RSUs. DERs are accumulated and paid when the underlying shares vest. Upon approval of the 2014 Plan, the Company reserved 1.54 billion shares plus the number of shares remaining that were reserved but not issued under the 2003 Plan. Shares subject to outstanding awards under the 2003 Plan that expire, are canceled or otherwise terminate, or are withheld to satisfy tax withholding obligations for RSUs, will also be available for awards under the 2014 Plan. As of September 26, 2020, approximately 808 million shares were reserved for future issuance under the 2014 Plan.

[0000320193-20-000096:notes:168]
Apple Inc. Non-Employee Director Stock Plan

[0000320193-20-000096:notes:169]
The Apple Inc. Non-Employee Director Stock Plan (the “Director Plan”) is a shareholder-approved plan that (i) permits the Company to grant awards of RSUs or stock options to the Company’s non-employee directors, (ii) provides for automatic initial grants of RSUs upon a non-employee director joining the Board of Directors and automatic annual grants of RSUs at each annual meeting of shareholders, and (iii) permits the Board of Directors to prospectively change the value and relative mixture of stock options and RSUs for the initial and annual award grants and the methodology for determining the number of shares of the Company’s common stock subject to these grants, in each case within the limits set forth in the Director Plan and without further shareholder approval. RSUs granted under the Director Plan reduce the number of shares available for grant under the plan by a factor of two times the number of RSUs granted. The Director Plan expires on November 12, 2027. All RSUs granted under the Director Plan are entitled to DERs. DERs are subject to the same vesting and other terms and conditions as the corresponding unvested RSUs. DERs are accumulated and paid when the underlying shares vest. As of September 26, 2020, approximately 4 million shares were reserved for future issuance under the Director Plan.

[0000320193-20-000096:notes:170]
Rule 10b5-1 Trading Plans

[0000320193-20-000096:notes:171]
During the three months ended September 26, 2020, Section 16 officers Katherine L. Adams, Timothy D. Cook, Chris Kondo, Luca Maestri, Deirdre O’Brien and Jeffrey Williams had equity trading plans in place in accordance with Rule 10b5-1(c)(1) under the Exchange Act. An equity trading plan is a written document that pre-establishes the amounts, prices and dates (or formula for determining the amounts, prices and dates) of future purchases or sales of the Company’s stock, including shares acquired under the Company’s employee and director equity plans.

[0000320193-20-000096:notes:172]
Employee Stock Purchase Plan

[0000320193-20-000096:notes:173]
The Employee Stock Purchase Plan (the “Purchase Plan”) is a shareholder-approved plan under which substantially all employees may purchase the Company’s common stock through payroll deductions at a price equal to 85% of the lower of the fair market values of the stock as of the beginning or the end of six-month offering periods. An employee’s payroll deductions under the Purchase Plan are limited to 10% of the employee’s compensation and employees may not purchase more than $25,000 of stock during any calendar year. As of September 26, 2020, approximately 107 million shares were reserved for future issuance under the Purchase Plan.

[0000320193-20-000096:notes:174]
401(k) Plan

[0000320193-20-000096:notes:175]
The Company’s 401(k) Plan is a deferred salary arrangement under Section 401(k) of the Internal Revenue Code. Under the 401(k) Plan, participating U.S. employees may defer a portion of their pre-tax earnings, up to the IRS annual contribution limit ($19,500 for calendar year 2020). The Company matches 50% to 100% of each employee’s contributions, depending on length of service, up to a maximum of 6% of the employee’s eligible earnings.

[0000320193-20-000096:notes:176]
Restricted Stock Units

[0000320193-20-000096:notes:177]
A summary of the Company’s RSU activity and related information for 2020, 2019 and 2018, is as follows:

[0000320193-20-000096:notes:178]
|  | Number ofRSUs(in thousands) |  | Weighted-AverageGrant Date FairValue Per RSU |  | AggregateFair Value(in millions) |
| Balance as of September 30, 2017 | 390,284 |  |  | $ | 27.58 |  |  |  |
| RSUs granted | 181,402 |  |  | $ | 40.72 |  |  |  |
| RSUs vested | (178,873) |  |  | $ | 27.81 |  |  |  |
| RSUs canceled | (24,195) |  |  | $ | 31.95 |  |  |  |
| Balance as of September 29, 2018 | 368,618 |  |  | $ | 33.65 |  |  |  |
| RSUs granted | 147,409 |  |  | $ | 53.99 |  |  |  |
| RSUs vested | (168,350) |  |  | $ | 33.80 |  |  |  |
| RSUs canceled | (21,609) |  |  | $ | 40.71 |  |  |  |
| Balance as of September 28, 2019 | 326,068 |  |  | $ | 42.30 |  |  |  |
| RSUs granted | 156,800 |  |  | $ | 59.20 |  |  |  |
| RSUs vested | (157,743) |  |  | $ | 40.29 |  |  |  |
| RSUs canceled | (14,347) |  |  | $ | 48.07 |  |  |  |
| Balance as of September 26, 2020 | 310,778 |  |  | $ | 51.58 |  |  | $ | 34,894 |  |

[0000320193-20-000096:notes:179]
The fair value as of the respective vesting dates of RSUs was $10.8 billion, $8.6 billion and $7.6 billion for 2020, 2019 and 2018, respectively. The majority of RSUs that vested in 2020, 2019 and 2018 were net share settled such that the Company withheld shares with a value equivalent to the employees’ obligation for the applicable income and other employment taxes, and remitted the cash to the appropriate taxing authorities. The total shares withheld were approximately 56 million, 59 million and 64 million for 2020, 2019 and 2018, respectively, and were based on the value of the RSUs on their respective vesting dates as determined by the Company’s closing stock price. Total payments for the employees’ tax obligations to taxing authorities were $3.9 billion, $3.0 billion and $2.7 billion in 2020, 2019 and 2018, respectively.

[0000320193-20-000096:notes:180]
The following table shows share-based compensation expense and the related income tax benefit included in the Consolidated Statements of Operations for 2020, 2019 and 2018 (in millions):

[0000320193-20-000096:notes:181]
|  | 2020 |  | 2019 |  | 2018 |
| Share-based compensation expense | $ | 6,829 |  |  | $ | 6,068 |  |  | $ | 5,340 |  |
| Income tax benefit related to share-based compensation expense | $ | (2,476) |  |  | $ | (1,967) |  |  | $ | (1,893) |  |

[0000320193-20-000096:notes:182]
As of September 26, 2020, the total unrecognized compensation cost related to outstanding RSUs and stock options was $12.2 billion, which the Company expects to recognize over a weighted-average period of 2.6 years.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000320193-20-000096:notes:183]
Commitments and Contingencies
Accrued Warranty and Guarantees

[0000320193-20-000096:notes:184]
The following table shows changes in the Company’s accrued warranties and related costs for 2020, 2019 and 2018 (in millions):

[0000320193-20-000096:notes:185]
|  | 2020 |  | 2019 |  | 2018 |
| Beginning accrued warranty and related costs | $ | 3,570 |  |  | $ | 3,692 |  |  | $ | 3,834 |  |
| Cost of warranty claims | (2,956) |  |  | (3,857) |  |  | (4,115) |  |
| Accruals for product warranty | 2,740 |  |  | 3,735 |  |  | 3,973 |  |
| Ending accrued warranty and related costs | $ | 3,354 |  |  | $ | 3,570 |  |  | $ | 3,692 |  |

[0000320193-20-000096:notes:186]
The Company offers an iPhone Upgrade Program, which is available to customers who purchase a qualifying iPhone in the U.S., the U.K. and China mainland. The iPhone Upgrade Program provides customers the right to trade in that iPhone for a specified amount when purchasing a new iPhone, provided certain conditions are met. The Company accounts for the trade-in right as a guarantee liability and recognizes arrangement revenue net of the fair value of such right, with subsequent changes to the guarantee liability recognized within net sales.

[0000320193-20-000096:notes:187]
Concentrations in the Available Sources of Supply of Materials and Product

[0000320193-20-000096:notes:188]
Although most components essential to the Company’s business are generally available from multiple sources, certain components are currently obtained from single or limited sources. The Company also competes for various components with other participants in the markets for smartphones, personal computers, tablets and other electronic devices. Therefore, many components used by the Company, including those that are available from multiple sources, are at times subject to industry-wide shortage and significant commodity pricing fluctuations.

[0000320193-20-000096:notes:189]
The Company uses some custom components that are not commonly used by its competitors, and new products introduced by the Company often utilize custom components available from only one source. When a component or product uses new technologies, initial capacity constraints may exist until the suppliers’ yields have matured or their manufacturing capacities have increased. The continued availability of these components at acceptable prices, or at all, may be affected if suppliers decide to concentrate on the production of common components instead of components customized to meet the Company’s requirements.

[0000320193-20-000096:notes:190]
The Company has entered into agreements for the supply of many components; however, there can be no guarantee that the Company will be able to extend or renew these agreements on similar terms, or at all.

[0000320193-20-000096:notes:191]
Substantially all of the Company’s hardware products are manufactured by outsourcing partners that are located primarily in Asia, with some Mac computers manufactured in the U.S. and Ireland.

[0000320193-20-000096:notes:192]
Unconditional Purchase Obligations

[0000320193-20-000096:notes:193]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of payments for supplier arrangements, Internet and telecommunication services, intellectual property licenses and content creation. Future payments under noncancelable unconditional purchase obligations having a remaining term in excess of one year as of September 26, 2020, are as follows (in millions):

[0000320193-20-000096:notes:194]
| 2021 | $ | 3,476 |  |
| 2022 | 2,885 |  |
| 2023 | 1,700 |  |
| 2024 | 357 |  |
| 2025 | 104 |  |
| Thereafter | 130 |  |
| Total | $ | 8,652 |  |

[0000320193-20-000096:notes:195]
Contingencies

[0000320193-20-000096:notes:196]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully resolved. The outcome of litigation is inherently uncertain. If one or more legal matters were resolved against the Company in a reporting period for amounts above management’s expectations, the Company’s financial condition and operating results for that reporting period could be materially adversely affected. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss greater than a recorded accrual, concerning loss contingencies for asserted legal and other claims, except for the following matters:

[0000320193-20-000096:notes:197]
VirnetX

[0000320193-20-000096:notes:198]
VirnetX, Inc. (“VirnetX”) filed a lawsuit against the Company alleging that certain of the Company’s products infringe on patents owned by VirnetX. On April 11, 2018, a jury returned a verdict against the Company and awarded damages of $503 million. The Company appealed the verdict to the U.S. Court of Appeals for the Federal Circuit, which remanded the case back to the U.S. District Court for the Eastern District of Texas, where it is scheduled for a re-trial in October 2020. The Company has challenged the validity of the patents at issue in the re-trial at the U.S. Patent and Trademark Office (the “PTO”), and the PTO has declared the patents invalid, subject to further appeal by VirnetX.

[0000320193-20-000096:notes:199]
iOS Performance Management Cases

[0000320193-20-000096:notes:200]
Various civil litigation matters have been filed in state and federal courts in the U.S. and in various international jurisdictions alleging violation of consumer protection laws, fraud, computer intrusion and other causes of action related to the Company’s performance management feature used in its iPhone operating systems, introduced to certain iPhones in iOS updates 10.2.1 and 11.2. The claims seek monetary damages and other non-monetary relief. On April 5, 2018, several U.S. federal actions were consolidated through a Multidistrict Litigation process into a single action in the U.S. District Court for the Northern District of California (the “Northern California District Court”). On February 28, 2020, the parties in the Multidistrict Litigation reached a settlement to resolve the U.S. federal and California state class actions. Under the terms of the settlement, which the Northern California District Court preliminarily approved in May 2020, the Company has agreed to pay up to $500 million in the aggregate to certain U.S. owners of iPhones if certain conditions are met. The final amount of the settlement will be determined based on the number of consumers who file valid claims and the attorneys’ fee award. However, the Company has agreed to pay at least $310 million to settle the claims. In addition to civil litigation, the Company is also responding to governmental investigations and requests for information relating to the performance management feature. The Company continues to believe that its iPhones were not defective, that the performance management feature introduced with iOS updates 10.2.1 and 11.2 was intended to, and did, improve customers’ user experience, and that the Company did not make any misleading statements or fail to disclose any material information. The Company has accrued its best estimate for the ultimate resolution of these matters.

[0000320193-20-000096:notes:201]
French Competition Authority

[0000320193-20-000096:notes:202]
On March 16, 2020, the French Competition Authority (“FCA”) announced its decision that aspects of the Company’s sales and distribution practices in France violate French competition law, and issued a fine of €1.1 billion. The Company strongly disagrees with the FCA’s decision, and has appealed.

[0000320193-20-000096:notes:203]
Optis

[0000320193-20-000096:notes:204]
Optis Wireless Technology, LLC and related entities (“Optis”) filed a lawsuit in the U.S. District Court for the Eastern District of Texas against the Company alleging that certain of the Company’s products infringe on patents owned by Optis. On August 11, 2020, a jury returned a verdict against the Company and awarded damages of $506 million. The Company has asked the court to set aside the verdict, where the case remains pending.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000320193-20-000096:notes:205]
Segment Information and Geographic Data
The Company reports segment information based on the “management” approach. The management approach designates the internal reporting used by management for making decisions and assessing performance as the source of the Company’s reportable segments.

[0000320193-20-000096:notes:206]
The Company manages its business primarily on a geographic basis. The Company’s reportable segments consist of the Americas, Europe, Greater China, Japan and Rest of Asia Pacific. Americas includes both North and South America. Europe includes European countries, as well as India, the Middle East and Africa. Greater China includes China mainland, Hong Kong and Taiwan. Rest of Asia Pacific includes Australia and those Asian countries not included in the Company’s other reportable segments. Although the reportable segments provide similar hardware and software products and similar services, each one is managed separately to better align with the location of the Company’s customers and distribution partners and the unique market dynamics of each geographic region. The accounting policies of the various segments are the same as those described in Note 1, “Summary of Significant Accounting Policies.”

[0000320193-20-000096:notes:207]
The Company evaluates the performance of its reportable segments based on net sales and operating income. Net sales for geographic segments are generally based on the location of customers and sales through the Company’s retail stores located in those geographic locations. Operating income for each segment includes net sales to third parties, related cost of sales and operating expenses directly attributable to the segment. Advertising expenses are generally included in the geographic segment in which the expenditures are incurred. Operating income for each segment excludes other income and expense and certain expenses managed outside the reportable segments. Costs excluded from segment operating income include various corporate expenses such as research and development, corporate marketing expenses, certain share-based compensation expenses, income taxes, various nonrecurring charges and other separately managed general and administrative costs. The Company does not include intercompany transfers between segments for management reporting purposes.

[0000320193-20-000096:notes:208]
The following table shows information by reportable segment for 2020, 2019 and 2018 (in millions):

[0000320193-20-000096:notes:209]
|  | 2020 |  | 2019 |  | 2018 |
| Americas: |  |  |  |  |  |
| Net sales | $ | 124,556 |  |  | $ | 116,914 |  |  | $ | 112,093 |  |
| Operating income | $ | 37,722 |  |  | $ | 35,099 |  |  | $ | 34,864 |  |
| Europe: |  |  |  |  |  |
| Net sales | $ | 68,640 |  |  | $ | 60,288 |  |  | $ | 62,420 |  |
| Operating income | $ | 22,170 |  |  | $ | 19,195 |  |  | $ | 19,955 |  |
| Greater China: |  |  |  |  |  |
| Net sales | $ | 40,308 |  |  | $ | 43,678 |  |  | $ | 51,942 |  |
| Operating income | $ | 15,261 |  |  | $ | 16,232 |  |  | $ | 19,742 |  |
| Japan: |  |  |  |  |  |
| Net sales | $ | 21,418 |  |  | $ | 21,506 |  |  | $ | 21,733 |  |
| Operating income | $ | 9,279 |  |  | $ | 9,369 |  |  | $ | 9,500 |  |
| Rest of Asia Pacific: |  |  |  |  |  |
| Net sales | $ | 19,593 |  |  | $ | 17,788 |  |  | $ | 17,407 |  |
| Operating income | $ | 6,808 |  |  | $ | 6,055 |  |  | $ | 6,181 |  |

[0000320193-20-000096:notes:210]
A reconciliation of the Company’s segment operating income to the Consolidated Statements of Operations for 2020, 2019 and 2018 is as follows (in millions):

[0000320193-20-000096:notes:211]
|  | 2020 |  | 2019 |  | 2018 |
| Segment operating income | $ | 91,240 |  |  | $ | 85,950 |  |  | $ | 90,242 |  |
| Research and development expense | (18,752) |  |  | (16,217) |  |  | (14,236) |  |
| Other corporate expenses, net | (6,200) |  |  | (5,803) |  |  | (5,108) |  |
| Total operating income | $ | 66,288 |  |  | $ | 63,930 |  |  | $ | 70,898 |  |

[0000320193-20-000096:notes:212]
The U.S. and China were the only countries that accounted for more than 10% of the Company’s net sales in 2020, 2019 and 2018. There was no single customer that accounted for more than 10% of net sales in 2020, 2019 and 2018. Net sales for 2020, 2019 and 2018 and long-lived assets as of September 26, 2020 and September 28, 2019 were as follows (in millions):

[0000320193-20-000096:notes:213]
|  | 2020 |  | 2019 |  | 2018 |
| Net sales: |  |  |  |  |  |
| U.S. | $ | 109,197 |  |  | $ | 102,266 |  |  | $ | 98,061 |  |
| China (1) | 40,308 |  |  | 43,678 |  |  | 51,942 |  |
| Other countries | 125,010 |  |  | 114,230 |  |  | 115,592 |  |
| Total net sales | $ | 274,515 |  |  | $ | 260,174 |  |  | $ | 265,595 |  |

[0000320193-20-000096:notes:214]
|  | 2020 |  | 2019 |
| Long-lived assets: |  |  |  |
| U.S. | $ | 25,890 |  |  | $ | 24,711 |  |
| China (1) | 7,256 |  |  | 9,064 |  |
| Other countries | 3,620 |  |  | 3,603 |  |
| Total long-lived assets | $ | 36,766 |  |  | $ | 37,378 |  |

[0000320193-20-000096:notes:215]
(1)China includes Hong Kong and Taiwan. Long-lived assets located in China consist primarily of product tooling and manufacturing process equipment and assets related to retail stores and related infrastructure.


## us-gaap:LesseeFinanceLeasesTextBlock

[0000320193-20-000096:notes:216]
Leases
The Company has lease arrangements for certain equipment and facilities, including retail, corporate, manufacturing and data center space. These leases typically have original terms not exceeding 10 years and generally contain multi-year renewal options, some of which are reasonably certain of exercise. The Company’s lease arrangements may contain both lease and non-lease components. The Company has elected to combine and account for lease and non-lease components as a single lease component for leases of retail, corporate, and data center facilities.

[0000320193-20-000096:notes:217]
Payments under the Company’s lease arrangements may be fixed or variable, and variable lease payments are primarily based on purchases of output of the underlying leased assets. Lease costs associated with fixed payments on the Company’s operating leases were $1.5 billion for 2020. Lease costs associated with variable payments on the Company’s leases were $9.3 billion for 2020. Rent expense for operating leases, as previously reported under former lease accounting standards, was $1.3 billion and $1.2 billion in 2019 and 2018, respectively.

[0000320193-20-000096:notes:218]
For 2020, the Company made $1.5 billion of fixed cash payments related to operating leases. Non-cash activities involving ROU assets obtained in exchange for lease liabilities were $10.5 billion for 2020, including the impact of adopting the new leases standard in the first quarter of 2020.

[0000320193-20-000096:notes:219]
The following table shows ROU assets and lease liabilities, and the associated financial statement line items, as of September 26, 2020 (in millions):

[0000320193-20-000096:notes:220]
| Lease-Related Assets and Liabilities |  | Financial Statement Line Items |  | 2020 |  |  |
| Right-of-use assets: |  |  |  |  |  |  |
| Operating leases |  | Other non-current assets |  | $ | 8,570 |  |  |  |
| Finance leases |  | Property, plant and equipment, net |  | 629 |  |  |  |
| Total right-of-use assets |  |  |  | $ | 9,199 |  |  |  |
| Lease liabilities: |  |  |  |  |  |  |
| Operating leases |  | Other current liabilities |  | $ | 1,436 |  |  |  |
|  |  | Other non-current liabilities |  | 7,745 |  |  |  |
| Finance leases |  | Other current liabilities |  | 24 |  |  |  |
|  |  | Other non-current liabilities |  | 637 |  |  |  |
| Total lease liabilities |  |  |  | $ | 9,842 |  |  |  |

[0000320193-20-000096:notes:221]
Lease liability maturities as of September 26, 2020, are as follows (in millions):

[0000320193-20-000096:notes:222]
|  | OperatingLeases |  | FinanceLeases |  | Total |
| 2021 | $ | 1,493 |  |  | $ | 43 |  |  | $ | 1,536 |  |
| 2022 | 1,461 |  |  | 43 |  |  | 1,504 |  |
| 2023 | 1,317 |  |  | 54 |  |  | 1,371 |  |
| 2024 | 1,068 |  |  | 30 |  |  | 1,098 |  |
| 2025 | 960 |  |  | 25 |  |  | 985 |  |
| Thereafter | 3,845 |  |  | 895 |  |  | 4,740 |  |
| Total undiscounted liabilities | 10,144 |  |  | 1,090 |  |  | 11,234 |  |
| Less: Imputed interest | (963) |  |  | (429) |  |  | (1,392) |  |
| Total lease liabilities | $ | 9,181 |  |  | $ | 661 |  |  | $ | 9,842 |  |

[0000320193-20-000096:notes:223]
The weighted-average remaining lease term and discount rate related to the Company’s lease liabilities as of September 26, 2020 were 10.3 years and 2.0%, respectively. The discount rates are generally based on estimates of the Company’s incremental borrowing rate, as the discount rates implicit in the Company’s leases cannot be readily determined.

[0000320193-20-000096:notes:224]
As of September 26, 2020, the Company had $1.7 billion of future payments under additional leases, primarily for corporate facilities and retail space, that had not yet commenced. These leases will commence between 2021 and 2022, with lease terms ranging from 1 year to 20 years.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000320193-20-000096:notes:225]
Selected Quarterly Financial Information (Unaudited)
The following tables show a summary of the Company’s quarterly financial information for each of the four quarters of 2020 and 2019 (in millions, except per share amounts):

[0000320193-20-000096:notes:226]
|  | Fourth Quarter |  | Third Quarter |  | Second Quarter |  | First Quarter |
| 2020: |  |  |  |  |  |  |  |
| Total net sales | $ | 64,698 |  |  | $ | 59,685 |  |  | $ | 58,313 |  |  | $ | 91,819 |  |
| Gross margin | $ | 24,689 |  |  | $ | 22,680 |  |  | $ | 22,370 |  |  | $ | 35,217 |  |
| Net income | $ | 12,673 |  |  | $ | 11,253 |  |  | $ | 11,249 |  |  | $ | 22,236 |  |
| Earnings per share (1): |  |  |  |  |  |  |  |
| Basic | $ | 0.74 |  |  | $ | 0.65 |  |  | $ | 0.64 |  |  | $ | 1.26 |  |
| Diluted | $ | 0.73 |  |  | $ | 0.65 |  |  | $ | 0.64 |  |  | $ | 1.25 |  |

[0000320193-20-000096:notes:227]
|  | Fourth Quarter |  | Third Quarter |  | Second Quarter |  | First Quarter |
| 2019: |  |  |  |  |  |  |  |
| Total net sales | $ | 64,040 |  |  | $ | 53,809 |  |  | $ | 58,015 |  |  | $ | 84,310 |  |
| Gross margin | $ | 24,313 |  |  | $ | 20,227 |  |  | $ | 21,821 |  |  | $ | 32,031 |  |
| Net income | $ | 13,686 |  |  | $ | 10,044 |  |  | $ | 11,561 |  |  | $ | 19,965 |  |
| Earnings per share (1): |  |  |  |  |  |  |  |
| Basic | $ | 0.76 |  |  | $ | 0.55 |  |  | $ | 0.62 |  |  | $ | 1.05 |  |
| Diluted | $ | 0.76 |  |  | $ | 0.55 |  |  | $ | 0.61 |  |  | $ | 1.05 |  |

[0000320193-20-000096:notes:228]
(1)Basic and diluted earnings per share are computed independently for each of the quarters presented. Therefore, the sum of quarterly basic and diluted per share information may not equal annual basic and diluted earnings per share.
