# AAPL note change history — 0000320193-20-000052 → 0000320193-20-000062


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-07-31):
[0000320193-20-000062:note_history:1]
The following table shows changes in the Company’s accrued warranties and related costs for the three- and nine-month periods ended June 27, 2020 and June 29, 2019 (in millions):
  (was, 2020-05-01, similarity 0.9318):
[0000320193-20-000052:note_history:1]
The following table shows changes in the Company’s accrued warranties and related costs for the three- and six-month periods ended March 28, 2020 and March 30, 2019 (in millions):

- changed (2020-07-31):
[0000320193-20-000062:note_history:2]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | June 27,2020 |  | June 29,2019 |  | June 27,2020 |  | June 29,2019 |
| Beginning accrued warranty and related costs | $ | 3,923 |  |  | $ | 3,487 |  |  | $ | 3,570 |  |  | $ | 3,692 |  |
| Cost of warranty claims | (576) |  |  | (912) |  |  | (2,180) |  |  | (2,823) |  |
| Accruals for product warranty | 557 |  |  | 548 |  |  | 2,514 |  |  | 2,254 |  |
| Ending accrued warranty and related costs | $ | 3,904 |  |  | $ | 3,123 |  |  | $ | 3,904 |  |  | $ | 3,123 |  |
  (was, 2020-05-01, similarity 0.8109):
[0000320193-20-000052:note_history:2]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| Beginning accrued warranty and related costs | $ | 3,873 |  |  | $ | 3,819 |  |  | $ | 3,570 |  |  | $ | 3,692 |  |
| Cost of warranty claims | (689 | ) |  | (915 | ) |  | (1,604 | ) |  | (1,911 | ) |
| Accruals for product warranty | 739 |  |  | 583 |  |  | 1,957 |  |  | 1,706 |  |
| Ending accrued warranty and related costs | $ | 3,923 |  |  | $ | 3,487 |  |  | $ | 3,923 |  |  | $ | 3,487 |  |

- changed (2020-07-31):
[0000320193-20-000062:note_history:3]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of payments for supplier arrangements, Internet and telecommunication services, intellectual property licenses and content creation. As of June 27, 2020, the Company’s total future payments under noncancelable unconditional purchase obligations having a remaining term in excess of one year were $9.2 billion.
  (was, 2020-05-01, similarity 0.9915):
[0000320193-20-000052:note_history:3]
The Company has entered into certain off–balance sheet commitments that require the future purchase of goods or services (“unconditional purchase obligations”). The Company’s unconditional purchase obligations primarily consist of payments for supplier arrangements, Internet and telecommunication services, intellectual property licenses and content creation. As of March 28, 2020, the Company’s total future payments under noncancelable unconditional purchase obligations having a remaining term in excess of one year were $9.9 billion.

- added (2020-07-31):
[0000320193-20-000062:note_history:4]
VirnetX, Inc. (“VirnetX”) filed a lawsuit against the Company alleging that certain of the Company’s products infringe on patents owned by VirnetX. On April 11, 2018, a jury returned a verdict against the Company and awarded damages of $503 million. The Company appealed the verdict to the U.S. Court of Appeals for the Federal Circuit, which remanded the case back to the U.S. District Court for the Eastern District of Texas, where it is scheduled for a re-trial in August 2020. The Company has challenged the validity of the patents at issue in the re-trial at the U.S. Patent and Trademark Office (the “PTO”), and the PTO has declared the patents invalid, subject to further appeal by VirnetX.

- changed (2020-07-31):
[0000320193-20-000062:note_history:5]
Various civil litigation matters have been filed in state and federal courts in the U.S. and in various international jurisdictions alleging violation of consumer protection laws, fraud, computer intrusion and other causes of action related to the Company’s performance management feature used in its iPhone operating systems, introduced to certain iPhones in iOS updates 10.2.1 and 11.2. The claims seek monetary damages and other non-monetary relief. On April 5, 2018, several U.S. federal actions were consolidated through a Multidistrict Litigation process into a single action in the U.S. District Court for the Northern District of California (the “Northern California District Court”). On February 28, 2020, the parties in the Multidistrict Litigation reached a settlement to resolve the U.S. federal and California state class actions. Under the terms of the settlement, which the Northern California District Court preliminarily approved in May 2020, the Company has agreed to pay up to $500 million in the aggregate to certain U.S. owners of iPhones if certain conditions are met. The final amount of the settlement will be determined based on the number of consumers who file valid claims and the attorneys’ fee award. However, the Company has agreed to pay at least $310 million to settle the claims. In addition to civil litigation, the Company is also responding to governmental investigations and requests for information relating to the performance management feature. The Company continues to believe that its iPhones were not defective, that the performance management feature introduced with iOS updates 10.2.1 and 11.2 was intended to, and did, improve customers’ user experience, and that the Company did not make any misleading statements or fail to disclose any material information. The Company has accrued its best estimate for the ultimate resolution of these matters.
  (was, 2020-05-01, similarity 0.9677):
[0000320193-20-000052:note_history:5]
Various civil litigation matters have been filed in state and federal courts in the U.S. and in various international jurisdictions alleging violation of consumer protection laws, fraud, computer intrusion and other causes of action related to the Company’s performance management feature used in its iPhone operating systems, introduced to certain iPhones in iOS updates 10.2.1 and 11.2. The claims seek monetary damages and other non-monetary relief. On April 5, 2018, several U.S. federal actions were consolidated through a Multidistrict Litigation process into a single action in the U.S. District Court for the Northern District of California (the “Northern California District Court”). On February 28, 2020, the parties in the Multidistrict Litigation reached a settlement to resolve the U.S. federal and California state class actions. Under the terms of the settlement, which is subject to the Northern California District Court’s approval, the Company has agreed to pay up to $500 million in the aggregate to certain U.S. owners of iPhones if certain conditions are met. The final amount of the settlement will be determined based on the number of consumers who file valid claims and the attorneys’ fee award. However, the Company has agreed to pay at least $310 million to settle the claims. In addition to civil litigation, the Company is also responding to governmental investigations and requests for information relating to the performance management feature. The Company continues to believe that its iPhones were not defective, that the performance management feature introduced with iOS updates 10.2.1 and 11.2 was intended to, and did, improve customers’ user experience, and that the Company did not make any misleading statements or fail to disclose any material information. The Company has accrued its best estimate for the ultimate resolution of these matters.

- changed (2020-07-31):
[0000320193-20-000062:note_history:6]
On March 16, 2020, the French Competition Authority (“FCA”) announced its decision that aspects of the Company’s sales and distribution practices in France violate French competition law, and issued a fine of €1.1 billion. The Company strongly disagrees with the FCA’s decision, and has appealed.
  (was, 2020-05-01, similarity 0.9534):
[0000320193-20-000052:note_history:6]
On March 16, 2020, the French Competition Authority (“FCA”) announced its decision that aspects of the Company’s sales and distribution practices in France violate French competition law, and issued a fine of €1.1 billion. The Company strongly disagrees with the FCA’s decision, and plans to appeal.

- removed (2020-07-31):
[0000320193-20-000052:note_history:7]
VirnetX, Inc. (“VirnetX”) filed two lawsuits in the U.S. District Court for the Eastern District of Texas (the “Eastern Texas District Court”) against the Company alleging that certain Company products infringe four patents (the “VirnetX Patents”) relating to network communications technology (“VirnetX I” and “VirnetX II”). On September 30, 2016, a jury returned a verdict in VirnetX I against the Company and awarded damages of $302 million, which later increased to $440 million in post-trial proceedings. The Company appealed the VirnetX I verdict to the U.S. Court of Appeals for the Federal Circuit (the “Federal Circuit”). On April 11, 2018, a jury returned a verdict in VirnetX II against the Company and awarded damages of $503 million. The Company appealed the VirnetX II verdict to the Federal Circuit, and on November 22, 2019, the Federal Circuit affirmed-in-part, reversed-in-part, and remanded VirnetX II back to the Eastern Texas District Court. The Company has challenged the validity of the VirnetX Patents at the U.S. Patent and Trademark Office (the “PTO”). In response, the PTO has declared the VirnetX Patents invalid. VirnetX appealed the invalidity decision of the PTO to the Federal Circuit. The Federal Circuit consolidated the Company’s appeal of the Eastern Texas District Court VirnetX I verdict and VirnetX’s appeals from the PTO invalidity proceedings. On January 15, 2019, the Federal Circuit affirmed the VirnetX I verdict, which the Company subsequently paid, including damages and interest. On July 8, 2019, the Federal Circuit remanded one of VirnetX’s two appeals of the PTO’s invalidity decisions back to the PTO for further proceedings. On August 1, 2019, the Federal Circuit affirmed-in-part, vacated-in-part, and remanded back to the PTO portions of VirnetX’s second appeal.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-07-31):
[0000320193-20-000062:note_history:8]
The condensed consolidated financial statements include the accounts of Apple Inc. and its wholly owned subsidiaries (collectively “Apple” or the “Company”). Intercompany accounts and transactions have been eliminated. In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements and accompanying notes in conformity with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported. Actual results could differ materially from those estimates. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company’s annual consolidated financial statements and accompanying notes included in its Annual Report on Form 10-K for the fiscal year ended September 28, 2019 (the “2019 Form 10-K”).
  (was, 2020-05-01, similarity 0.9213):
[0000320193-20-000052:note_history:8]
The condensed consolidated financial statements include the accounts of Apple Inc. and its wholly owned subsidiaries (collectively “Apple” or the “Company”). Intercompany accounts and transactions have been eliminated. In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements and accompanying notes in conformity with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported. Actual results could differ materially from those estimates. Certain prior period amounts in the condensed consolidated financial statements and accompanying notes have been reclassified to conform to the current period’s presentation. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company’s annual consolidated financial statements and accompanying notes included in its Annual Report on Form 10-K for the fiscal year ended September 28, 2019 (the “2019 Form 10-K”).

- changed (2020-07-31):
[0000320193-20-000062:note_history:9]
The following table shows the computation of basic and diluted earnings per share for the three- and nine-month periods ended June 27, 2020 and June 29, 2019 (net income in millions and shares in thousands):
  (was, 2020-05-01, similarity 0.9418):
[0000320193-20-000052:note_history:9]
The following table shows the computation of basic and diluted earnings per share for the three- and six-month periods ended March 28, 2020 and March 30, 2019 (net income in millions and shares in thousands):

- changed (2020-07-31):
[0000320193-20-000062:note_history:10]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | June 27,2020 |  | June 29,2019 |  | June 27,2020 |  | June 29,2019 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 11,253 |  |  | $ | 10,044 |  |  | $ | 44,738 |  |  | $ | 41,570 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 4,312,573 |  |  | 4,570,633 |  |  | 4,362,571 |  |  | 4,660,175 |  |
| Effect of dilutive securities | 42,215 |  |  | 30,747 |  |  | 42,124 |  |  | 31,584 |  |
| Weighted-average diluted shares | 4,354,788 |  |  | 4,601,380 |  |  | 4,404,695 |  |  | 4,691,759 |  |
| Basic earnings per share | $ | 2.61 |  |  | $ | 2.20 |  |  | $ | 10.25 |  |  | $ | 8.92 |  |
| Diluted earnings per share | $ | 2.58 |  |  | $ | 2.18 |  |  | $ | 10.16 |  |  | $ | 8.86 |  |
  (was, 2020-05-01, similarity 0.8786):
[0000320193-20-000052:note_history:10]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 11,249 |  |  | $ | 11,561 |  |  | $ | 33,485 |  |  | $ | 31,526 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 4,360,101 |  |  | 4,674,071 |  |  | 4,387,570 |  |  | 4,704,945 |  |
| Effect of dilutive securities | 44,590 |  |  | 26,575 |  |  | 42,078 |  |  | 32,004 |  |
| Weighted-average diluted shares | 4,404,691 |  |  | 4,700,646 |  |  | 4,429,648 |  |  | 4,736,949 |  |
| Basic earnings per share | $ | 2.58 |  |  | $ | 2.47 |  |  | $ | 7.63 |  |  | $ | 6.70 |  |
| Diluted earnings per share | $ | 2.55 |  |  | $ | 2.46 |  |  | $ | 7.56 |  |  | $ | 6.66 |  |

- changed (2020-07-31):
[0000320193-20-000062:note_history:11]
Potentially dilutive securities representing 1.5 million and 20.5 million shares of common stock were excluded from the computation of diluted earnings per share for the three- and nine-month periods ended June 29, 2019, respectively, because their effect would have been antidilutive.
  (was, 2020-05-01, similarity 0.9708):
[0000320193-20-000052:note_history:11]
Potentially dilutive securities representing 31.1 million and 30.0 million shares of common stock were excluded from the computation of diluted earnings per share for the three- and six-month periods ended March 30, 2019, respectively, because their effect would have been antidilutive.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-07-31):
[0000320193-20-000062:note_history:12]
Debt
Commercial Paper and Repurchase Agreements
  (was, 2020-05-01, similarity 0.9892):
[0000320193-20-000052:note_history:12]
Debt
Commercial Paper and Repurchase Agreement

- changed (2020-07-31):
[0000320193-20-000062:note_history:13]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of both June 27, 2020 and September 28, 2019, the Company had $6.0 billion of Commercial Paper outstanding with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 0.77% and 2.24% as of June 27, 2020 and September 28, 2019, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the nine months ended June 27, 2020 and June 29, 2019 (in millions):
  (was, 2020-05-01, similarity 0.8664):
[0000320193-20-000052:note_history:13]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of March 28, 2020 and September 28, 2019, the Company had $7.5 billion and $6.0 billion of Commercial Paper outstanding, respectively, with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 1.39% and 2.24% as of March 28, 2020 and September 28, 2019, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the six months ended March 28, 2020 and March 30, 2019 (in millions):

- added (2020-07-31):
[0000320193-20-000062:note_history:14]
|  | Nine Months Ended |  |  |
|  | June 27,2020 |  | June 29,2019 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | 401 |  |  | $ | (3,720) |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 5,373 |  |  | 12,977 |  |
| Repayments of commercial paper | (5,743) |  |  | (11,283) |  |
| Proceeds from/(Repayments of) commercial paper, net | (370) |  |  | 1,694 |  |
| Total proceeds from/(repayments of) commercial paper, net | $ | 31 |  |  | $ | (2,026) |  |

- changed (2020-07-31):
[0000320193-20-000062:note_history:15]
In 2020, the Company entered into agreements to sell certain of its marketable securities with a promise to repurchase the securities at a specified time and amount (“Repos”). Due to the Company’s continuing involvement with the marketable securities, the Company accounts for its Repos as collateralized borrowings. As of June 27, 2020, the Company had $5.2 billion of Repo liabilities outstanding with maturities of less than three months, and had pledged $5.3 billion of marketable securities as collateral.
  (was, 2020-05-01, similarity 0.8348):
[0000320193-20-000052:note_history:15]
In the second quarter of 2020, the Company entered into an agreement to sell certain of its marketable securities with a promise to repurchase the securities at a specified time and amount (“Repo”). Due to the Company’s continuing involvement with the marketable securities, the Company accounts for the Repo as a collateralized borrowing. As of March 28, 2020, the Company had a $2.6 billion Repo liability with a maturity of less than six months, and had pledged $2.6 billion of marketable securities as collateral.

- changed (2020-07-31):
[0000320193-20-000062:note_history:16]
As of June 27, 2020, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $100.1 billion (collectively the “Notes”). The Notes are senior unsecured obligations and interest is payable in arrears. The following table provides a summary of the Company’s term debt as of June 27, 2020 and September 28, 2019:
  (was, 2020-05-01, similarity 0.9745):
[0000320193-20-000052:note_history:16]
As of March 28, 2020, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $98.0 billion (collectively the “Notes”). The Notes are senior unsecured obligations and interest is payable in arrears. The following table provides a summary of the Company’s term debt as of March 28, 2020 and September 28, 2019:

- changed (2020-07-31):
[0000320193-20-000062:note_history:17]
|  | Maturities(calendar year) |  | June 27, 2020 |  |  |  | September 28, 2019 |  |  |
|  |  |  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 – 2019 debt issuances: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2021 – 2022 |  | $ | 2,250 |  |  | 0.80% – 1.49% |  | $ | 4,250 |  |  | 2.25% – 3.28% |
| Fixed-rate 0.375% – 4.650% notes | 2020 – 2049 |  | 87,055 |  |  | 0.28% – 4.78% |  | 97,429 |  |  | 0.28% – 4.78% |
| First quarter 2020 debt issuance of €2.0 billion: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.000% – 0.500% notes | 2025 – 2031 |  | 2,260 |  |  | 0.03% – 0.56% |  | — |  |  | — | % |
| Third quarter 2020 debt issuance of $8.5 billion: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.750% – 2.650% notes | 2023 – 2050 |  | 8,500 |  |  | 0.84% – 2.72% |  | — |  |  | — | % |
| Total term debt |  |  | 100,065 |  |  |  |  | 101,679 |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  | (279) |  |  |  |  | (224) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 1,771 |  |  |  |  | 612 |  |  |  |
| Less: Current portion of term debt |  |  | (7,509) |  |  |  |  | (10,260) |  |  |  |
| Total non-current portion of term debt |  |  | $ | 94,048 |  |  |  |  | $ | 91,807 |  |  |  |
  (was, 2020-05-01, similarity 0.7342):
[0000320193-20-000052:note_history:17]
|  | Maturities(calendar year) |  | March 28, 2020 |  | September 28, 2019 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 – 2019 debt issuances: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2020 | – | 2022 |  | $ | 3,250 |  |  |  | 1.80% | – | 2.81 | % |  | $ | 4,250 |  |  |  | 2.25% | – | 3.28 | % |
| Fixed-rate 0.350% – 4.650% notes | 2020 | – | 2049 |  | 92,554 |  |  |  | 0.28% | – | 4.78 | % |  | 97,429 |  |  |  | 0.28% | – | 4.78 | % |
| First quarter 2020 debt issuance of €2.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.000% – 0.500% notes | 2025 | – | 2031 |  | 2,164 |  |  |  | 0.03% | – | 0.56 | % |  | — |  |  |  |  |  | — | % |
| Total term debt |  |  |  |  | 97,968 |  |  |  |  |  |  |  | 101,679 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (220 | ) |  |  |  |  |  |  | (224 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | 1,730 |  |  |  |  |  |  |  | 612 |  |  |  |  |  |  |
| Less: Current portion of term debt |  |  |  |  | (10,392 | ) |  |  |  |  |  |  | (10,260 | ) |  |  |  |  |  |
| Total non-current portion of term debt |  |  |  |  | $ | 89,086 |  |  |  |  |  |  |  | $ | 91,807 |  |  |  |  |  |  |

- added (2020-07-31):
[0000320193-20-000062:note_history:18]
As of September 28, 2019, a portion of the Company’s Japanese yen–denominated notes with a carrying value of $1.0 billion was designated as a hedge of the foreign currency exposure of the Company’s net investment in a foreign operation. The Company’s Japanese yen–denominated notes matured during the third quarter of 2020 and the associated net investment hedges were terminated. For further discussion regarding the Company’s use of derivative instruments, refer to the Derivative Financial Instruments section of Note 3, “Financial Instruments.”

- changed (2020-07-31):
[0000320193-20-000062:note_history:19]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $664 million and $2.1 billion of interest cost on its term debt for the three- and nine-month periods ended June 27, 2020, respectively. The Company recognized $790 million and $2.4 billion of interest cost on its term debt for the three- and nine-month periods ended June 29, 2019, respectively.
  (was, 2020-05-01, similarity 0.9659):
[0000320193-20-000052:note_history:19]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $725 million and $1.5 billion of interest cost on its term debt for the three- and six-month periods ended March 28, 2020, respectively. The Company recognized $828 million and $1.6 billion of interest cost on its term debt for the three- and six-month periods ended March 30, 2019, respectively.

- changed (2020-07-31):
[0000320193-20-000062:note_history:20]
As of June 27, 2020 and September 28, 2019, the fair value of the Company’s Notes, based on Level 2 inputs, was $110.8 billion and $107.5 billion, respectively.
  (was, 2020-05-01, similarity 0.9682):
[0000320193-20-000052:note_history:20]
As of March 28, 2020 and September 28, 2019, the fair value of the Company’s Notes, based on Level 2 inputs, was $105.6 billion and $107.5 billion, respectively.

- removed (2020-07-31):
[0000320193-20-000052:note_history:21]
|  | Six Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | 1,377 |  |  | $ | (2,484 | ) |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 4,797 |  |  | 10,235 |  |
| Repayments of commercial paper | (4,656 | ) |  | (7,787 | ) |
| Proceeds from commercial paper, net | 141 |  |  | 2,448 |  |
| Total proceeds from/(repayments of) commercial paper, net | $ | 1,518 |  |  | $ | (36 | ) |

- removed (2020-07-31):
[0000320193-20-000052:note_history:22]
A portion of the Company’s Japanese yen–denominated notes is designated as a hedge of the foreign currency exposure of the Company’s net investment in a foreign operation. As of March 28, 2020 and September 28, 2019, the carrying value of the debt designated as a net investment hedge was $663 million and $1.0 billion, respectively. For further discussion regarding the Company’s use of derivative instruments, refer to the Derivative Financial Instruments section of Note 3, “Financial Instruments.”


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-07-31):
[0000320193-20-000062:note_history:23]
The following table provides a summary of the Company’s term debt as of June 27, 2020 and September 28, 2019:
  (was, 2020-05-01, similarity 0.9548):
[0000320193-20-000052:note_history:23]
The following table provides a summary of the Company’s term debt as of March 28, 2020 and September 28, 2019:

- changed (2020-07-31):
[0000320193-20-000062:note_history:24]
|  | Maturities(calendar year) |  | June 27, 2020 |  |  |  | September 28, 2019 |  |  |
|  |  |  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 – 2019 debt issuances: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2021 – 2022 |  | $ | 2,250 |  |  | 0.80% – 1.49% |  | $ | 4,250 |  |  | 2.25% – 3.28% |
| Fixed-rate 0.375% – 4.650% notes | 2020 – 2049 |  | 87,055 |  |  | 0.28% – 4.78% |  | 97,429 |  |  | 0.28% – 4.78% |
| First quarter 2020 debt issuance of €2.0 billion: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.000% – 0.500% notes | 2025 – 2031 |  | 2,260 |  |  | 0.03% – 0.56% |  | — |  |  | — | % |
| Third quarter 2020 debt issuance of $8.5 billion: |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.750% – 2.650% notes | 2023 – 2050 |  | 8,500 |  |  | 0.84% – 2.72% |  | — |  |  | — | % |
| Total term debt |  |  | 100,065 |  |  |  |  | 101,679 |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  | (279) |  |  |  |  | (224) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 1,771 |  |  |  |  | 612 |  |  |  |
| Less: Current portion of term debt |  |  | (7,509) |  |  |  |  | (10,260) |  |  |  |
| Total non-current portion of term debt |  |  | $ | 94,048 |  |  |  |  | $ | 91,807 |  |  |  |
  (was, 2020-05-01, similarity 0.7342):
[0000320193-20-000052:note_history:24]
|  | Maturities(calendar year) |  | March 28, 2020 |  | September 28, 2019 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 – 2019 debt issuances: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2020 | – | 2022 |  | $ | 3,250 |  |  |  | 1.80% | – | 2.81 | % |  | $ | 4,250 |  |  |  | 2.25% | – | 3.28 | % |
| Fixed-rate 0.350% – 4.650% notes | 2020 | – | 2049 |  | 92,554 |  |  |  | 0.28% | – | 4.78 | % |  | 97,429 |  |  |  | 0.28% | – | 4.78 | % |
| First quarter 2020 debt issuance of €2.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.000% – 0.500% notes | 2025 | – | 2031 |  | 2,164 |  |  |  | 0.03% | – | 0.56 | % |  | — |  |  |  |  |  | — | % |
| Total term debt |  |  |  |  | 97,968 |  |  |  |  |  |  |  | 101,679 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (220 | ) |  |  |  |  |  |  | (224 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | 1,730 |  |  |  |  |  |  |  | 612 |  |  |  |  |  |  |
| Less: Current portion of term debt |  |  |  |  | (10,392 | ) |  |  |  |  |  |  | (10,260 | ) |  |  |  |  |  |
| Total non-current portion of term debt |  |  |  |  | $ | 89,086 |  |  |  |  |  |  |  | $ | 91,807 |  |  |  |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-07-31):
[0000320193-20-000062:note_history:25]
Net sales disaggregated by significant products and services for the three- and nine-month periods ended June 27, 2020 and June 29, 2019 were as follows (in millions):
  (was, 2020-05-01, similarity 0.927):
[0000320193-20-000052:note_history:25]
Net sales disaggregated by significant products and services for the three- and six-month periods ended March 28, 2020 and March 30, 2019 were as follows (in millions):

- changed (2020-07-31):
[0000320193-20-000062:note_history:26]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | June 27,2020 |  | June 29,2019 |  | June 27,2020 |  | June 29,2019 |
| iPhone (1) | $ | 26,418 |  |  | $ | 25,986 |  |  | $ | 111,337 |  |  | $ | 109,019 |  |
| Mac (1) | 7,079 |  |  | 5,820 |  |  | 19,590 |  |  | 18,749 |  |
| iPad (1) | 6,582 |  |  | 5,023 |  |  | 16,927 |  |  | 16,624 |  |
| Wearables, Home and Accessories (1)(2) | 6,450 |  |  | 5,525 |  |  | 22,744 |  |  | 17,962 |  |
| Services (3) | 13,156 |  |  | 11,455 |  |  | 39,219 |  |  | 33,780 |  |
| Total net sales (4) | $ | 59,685 |  |  | $ | 53,809 |  |  | $ | 209,817 |  |  | $ | 196,134 |  |
  (was, 2020-05-01, similarity 0.8411):
[0000320193-20-000052:note_history:26]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| iPhone (1) | $ | 28,962 |  |  | $ | 31,051 |  |  | $ | 84,919 |  |  | $ | 83,033 |  |
| Mac (1) | 5,351 |  |  | 5,513 |  |  | 12,511 |  |  | 12,929 |  |
| iPad (1) | 4,368 |  |  | 4,872 |  |  | 10,345 |  |  | 11,601 |  |
| Wearables, Home and Accessories (1)(2) | 6,284 |  |  | 5,129 |  |  | 16,294 |  |  | 12,437 |  |
| Services (3) | 13,348 |  |  | 11,450 |  |  | 26,063 |  |  | 22,325 |  |
| Total net sales (4) | $ | 58,313 |  |  | $ | 58,015 |  |  | $ | 150,132 |  |  | $ | 142,325 |  |

- changed (2020-07-31):
[0000320193-20-000062:note_history:27]
(1)Products net sales include amortization of the deferred value of unspecified software upgrade rights, which are bundled in the sales price of the respective product.
  (was, 2020-05-01, similarity 0.9796):
[0000320193-20-000052:note_history:27]
| (1) | Products net sales include amortization of the deferred value of unspecified software upgrade rights, which are bundled in the sales price of the respective product. |

- changed (2020-07-31):
[0000320193-20-000062:note_history:28]
(2)Wearables, Home and Accessories net sales include sales of AirPods®, Apple TV®, Apple Watch®, Beats® products, HomePod®, iPod touch® and Apple-branded and third-party accessories.
  (was, 2020-05-01, similarity 0.9757):
[0000320193-20-000052:note_history:28]
| (2) | Wearables, Home and Accessories net sales include sales of AirPods®, Apple TV®, Apple Watch®, Beats® products, HomePod™, iPod touch® and Apple-branded and third-party accessories. |

- changed (2020-07-31):
[0000320193-20-000062:note_history:29]
(3)Services net sales include sales from the Company’s digital content stores and streaming services, AppleCare®, Advertising and other services. Services net sales also include amortization of the deferred value of Maps, Siri, and free iCloud storage and Apple TV + services, which are bundled in the sales price of certain products.
  (was, 2020-05-01, similarity 0.9718):
[0000320193-20-000052:note_history:29]
| (3) | Services net sales include sales from the Company’s digital content stores and streaming services, AppleCare®, licensing and other services. Services net sales also include amortization of the deferred value of Maps, Siri, and free iCloud storage and Apple TV + services, which are bundled in the sales price of certain products. |

- changed (2020-07-31):
[0000320193-20-000062:note_history:30]
(4)Includes $2.1 billion of revenue recognized in the three months ended June 27, 2020 that was included in deferred revenue as of March 28, 2020, $2.0 billion of revenue recognized in the three months ended June 29, 2019 that was included in deferred revenue as of March 30, 2019, $4.0 billion of revenue recognized in the nine months ended June 27, 2020 that was included in deferred revenue as of September 28, 2019, and $4.9 billion of revenue recognized in the nine months ended June 29, 2019 that was included in deferred revenue as of September 29, 2018.
  (was, 2020-05-01, similarity 0.868):
[0000320193-20-000052:note_history:30]
Includes $1.9 billion of revenue recognized in the three months ended March 28, 2020 that was included in deferred revenue as of December 28, 2019, $1.9 billion of revenue recognized in the three months ended March 30, 2019 that was included in deferred revenue as of December 29, 2018, $3.0 billion of revenue recognized in the six months ended March 28, 2020 that was included in deferred revenue as of September 28, 2019, and $3.8 billion of revenue recognized in the six months ended March 30, 2019 that was included in deferred revenue as of September 29, 2018.

- removed (2020-07-31):
[0000320193-20-000052:note_history:31]
(4)


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2020-07-31):
[0000320193-20-000062:note_history:32]
As of June 27, 2020 and September 28, 2019, the Company had total deferred revenue of $9.8 billion and $8.1 billion, respectively. As of June 27, 2020, the Company expects 65% of total deferred revenue to be realized in less than a year, 26% within one-to-two years, 7% within two-to-three years and 2% in greater than three years.

- changed (2020-07-31):
[0000320193-20-000062:note_history:33]
Net sales disaggregated by significant products and services for the three- and nine-month periods ended June 27, 2020 and June 29, 2019 were as follows (in millions):
  (was, 2020-05-01, similarity 0.927):
[0000320193-20-000052:note_history:33]
Net sales disaggregated by significant products and services for the three- and six-month periods ended March 28, 2020 and March 30, 2019 were as follows (in millions):

- changed (2020-07-31):
[0000320193-20-000062:note_history:34]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | June 27,2020 |  | June 29,2019 |  | June 27,2020 |  | June 29,2019 |
| iPhone (1) | $ | 26,418 |  |  | $ | 25,986 |  |  | $ | 111,337 |  |  | $ | 109,019 |  |
| Mac (1) | 7,079 |  |  | 5,820 |  |  | 19,590 |  |  | 18,749 |  |
| iPad (1) | 6,582 |  |  | 5,023 |  |  | 16,927 |  |  | 16,624 |  |
| Wearables, Home and Accessories (1)(2) | 6,450 |  |  | 5,525 |  |  | 22,744 |  |  | 17,962 |  |
| Services (3) | 13,156 |  |  | 11,455 |  |  | 39,219 |  |  | 33,780 |  |
| Total net sales (4) | $ | 59,685 |  |  | $ | 53,809 |  |  | $ | 209,817 |  |  | $ | 196,134 |  |
  (was, 2020-05-01, similarity 0.8411):
[0000320193-20-000052:note_history:34]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| iPhone (1) | $ | 28,962 |  |  | $ | 31,051 |  |  | $ | 84,919 |  |  | $ | 83,033 |  |
| Mac (1) | 5,351 |  |  | 5,513 |  |  | 12,511 |  |  | 12,929 |  |
| iPad (1) | 4,368 |  |  | 4,872 |  |  | 10,345 |  |  | 11,601 |  |
| Wearables, Home and Accessories (1)(2) | 6,284 |  |  | 5,129 |  |  | 16,294 |  |  | 12,437 |  |
| Services (3) | 13,348 |  |  | 11,450 |  |  | 26,063 |  |  | 22,325 |  |
| Total net sales (4) | $ | 58,313 |  |  | $ | 58,015 |  |  | $ | 150,132 |  |  | $ | 142,325 |  |

- changed (2020-07-31):
[0000320193-20-000062:note_history:35]
(1)Products net sales include amortization of the deferred value of unspecified software upgrade rights, which are bundled in the sales price of the respective product.
  (was, 2020-05-01, similarity 0.9796):
[0000320193-20-000052:note_history:35]
| (1) | Products net sales include amortization of the deferred value of unspecified software upgrade rights, which are bundled in the sales price of the respective product. |

- changed (2020-07-31):
[0000320193-20-000062:note_history:36]
(2)Wearables, Home and Accessories net sales include sales of AirPods®, Apple TV®, Apple Watch®, Beats® products, HomePod®, iPod touch® and Apple-branded and third-party accessories.
  (was, 2020-05-01, similarity 0.9757):
[0000320193-20-000052:note_history:36]
| (2) | Wearables, Home and Accessories net sales include sales of AirPods®, Apple TV®, Apple Watch®, Beats® products, HomePod™, iPod touch® and Apple-branded and third-party accessories. |

- changed (2020-07-31):
[0000320193-20-000062:note_history:37]
(3)Services net sales include sales from the Company’s digital content stores and streaming services, AppleCare®, Advertising and other services. Services net sales also include amortization of the deferred value of Maps, Siri, and free iCloud storage and Apple TV + services, which are bundled in the sales price of certain products.
  (was, 2020-05-01, similarity 0.9718):
[0000320193-20-000052:note_history:37]
| (3) | Services net sales include sales from the Company’s digital content stores and streaming services, AppleCare®, licensing and other services. Services net sales also include amortization of the deferred value of Maps, Siri, and free iCloud storage and Apple TV + services, which are bundled in the sales price of certain products. |

- changed (2020-07-31):
[0000320193-20-000062:note_history:38]
(4)Includes $2.1 billion of revenue recognized in the three months ended June 27, 2020 that was included in deferred revenue as of March 28, 2020, $2.0 billion of revenue recognized in the three months ended June 29, 2019 that was included in deferred revenue as of March 30, 2019, $4.0 billion of revenue recognized in the nine months ended June 27, 2020 that was included in deferred revenue as of September 28, 2019, and $4.9 billion of revenue recognized in the nine months ended June 29, 2019 that was included in deferred revenue as of September 29, 2018.
  (was, 2020-05-01, similarity 0.8654):
[0000320193-20-000052:note_history:38]
| (4) | Includes $1.9 billion of revenue recognized in the three months ended March 28, 2020 that was included in deferred revenue as of December 28, 2019, $1.9 billion of revenue recognized in the three months ended March 30, 2019 that was included in deferred revenue as of December 29, 2018, $3.0 billion of revenue recognized in the six months ended March 28, 2020 that was included in deferred revenue as of September 28, 2019, and $3.8 billion of revenue recognized in the six months ended March 30, 2019 that was included in deferred revenue as of September 29, 2018. |

- changed (2020-07-31):
[0000320193-20-000062:note_history:39]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 11, “Segment Information and Geographic Data” for the three- and nine-month periods ended June 27, 2020 and June 29, 2019.
  (was, 2020-05-01, similarity 0.894):
[0000320193-20-000052:note_history:39]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 11, “Segment Information and Geographic Data” for the three- and six-month periods ended March 28, 2020 and March 30, 2019.

- removed (2020-07-31):
[0000320193-20-000052:note_history:40]
As of March 28, 2020 and September 28, 2019, the Company had total deferred revenue of $9.4 billion and $8.1 billion, respectively. As of March 28, 2020, the Company expects 63% of total deferred revenue to be realized in less than a year, 28% within one-to-two years, 7% within two-to-three years and 2% in greater than three years.
