# AAPL note change history — 0000320193-24-000006 → 0000320193-24-000069


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-05-03):
[0000320193-24-000069:note_history:1]
The condensed consolidated financial statements include the accounts of Apple Inc. and its wholly owned subsidiaries (collectively “Apple” or the “Company”). In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements and accompanying notes in conformity with U.S. generally accepted accounting principles (“GAAP”) requires the use of management estimates. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company’s annual consolidated financial statements and accompanying notes included in its Annual Report on Form 10-K for the fiscal year ended September 30, 2023 (the “2023 Form 10-K”).
  (was, 2024-02-02, similarity 0.9081):
[0000320193-24-000006:note_history:1]
The condensed consolidated financial statements include the accounts of Apple Inc. and its wholly owned subsidiaries (collectively “Apple” or the “Company”). In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements and accompanying notes in conformity with U.S. generally accepted accounting principles (“GAAP”) requires the use of management estimates. Certain prior period amounts in the condensed consolidated financial statements and accompanying notes have been reclassified to conform to the current period’s presentation. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company’s annual consolidated financial statements and accompanying notes included in its Annual Report on Form 10-K for the fiscal year ended September 30, 2023 (the “2023 Form 10-K”).


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-03):
[0000320193-24-000069:note_history:2]
The Company issues unsecured short-term promissory notes pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of March 30, 2024 and September 30, 2023, the Company had $2.0 billion and $6.0 billion of commercial paper outstanding, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of commercial paper for the six months ended March 30, 2024 and April 1, 2023 (in millions):
  (was, 2024-02-02, similarity 0.9146):
[0000320193-24-000006:note_history:2]
The Company issues unsecured short-term promissory notes pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of December 30, 2023 and September 30, 2023, the Company had $2.0 billion and $6.0 billion of commercial paper outstanding, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of commercial paper for the three months ended December 30, 2023 and December 31, 2022 (in millions):

- changed (2024-05-03):
[0000320193-24-000069:note_history:3]
|  | Six Months Ended |
|  | March 30,2024 |  | April 1,2023 |
| Maturities 90 days or less: |  |  |  |
| Repayments of commercial paper, net | $ | (3,982) |  |  | $ | (5,315) |  |
| Maturities greater than 90 days: |  |  |  |
| Repayments of commercial paper | — |  |  | (2,645) |  |
| Total repayments of commercial paper, net | $ | (3,982) |  |  | $ | (7,960) |  |
  (was, 2024-02-02, similarity 0.8719):
[0000320193-24-000006:note_history:3]
|  | Three Months Ended |
|  | December 30,2023 |  | December 31,2022 |
| Maturities 90 days or less: |  |  |  |
| Repayments of commercial paper, net | $ | (3,984) |  |  | $ | (5,569) |  |
| Maturities greater than 90 days: |  |  |  |
| Repayments of commercial paper | — |  |  | (2,645) |  |
| Total repayments of commercial paper, net | $ | (3,984) |  |  | $ | (8,214) |  |

- changed (2024-05-03):
[0000320193-24-000069:note_history:4]
As of March 30, 2024 and September 30, 2023, the Company had outstanding fixed-rate notes with varying maturities for an aggregate carrying amount of $102.6 billion and $105.1 billion, respectively (collectively the “Notes”). As of March 30, 2024 and September 30, 2023, the fair value of the Company’s Notes, based on Level 2 inputs, was $91.6 billion and $90.8 billion, respectively.
  (was, 2024-02-02, similarity 0.9631):
[0000320193-24-000006:note_history:4]
As of December 30, 2023 and September 30, 2023, the Company had outstanding fixed-rate notes with varying maturities for an aggregate carrying amount of $106.0 billion and $105.1 billion, respectively (collectively the “Notes”). As of December 30, 2023 and September 30, 2023, the fair value of the Company’s Notes, based on Level 2 inputs, was $96.7 billion and $90.8 billion, respectively.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-05-03):
[0000320193-24-000069:note_history:5]
Net sales disaggregated by significant products and services for the three- and six-month periods ended March 30, 2024 and April 1, 2023 were as follows (in millions):
  (was, 2024-02-02, similarity 0.8824):
[0000320193-24-000006:note_history:5]
Net sales disaggregated by significant products and services for the three months ended December 30, 2023 and December 31, 2022 were as follows (in millions):

- changed (2024-05-03):
[0000320193-24-000069:note_history:6]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30,2024 |  | April 1,2023 |  | March 30,2024 |  | April 1,2023 |
| iPhone® | $ | 45,963 |  |  | $ | 51,334 |  |  | $ | 115,665 |  |  | $ | 117,109 |  |
| Mac® | 7,451 |  |  | 7,168 |  |  | 15,231 |  |  | 14,903 |  |
| iPad® | 5,559 |  |  | 6,670 |  |  | 12,582 |  |  | 16,066 |  |
| Wearables, Home and Accessories | 7,913 |  |  | 8,757 |  |  | 19,866 |  |  | 22,239 |  |
| Services | 23,867 |  |  | 20,907 |  |  | 46,984 |  |  | 41,673 |  |
| Total net sales | $ | 90,753 |  |  | $ | 94,836 |  |  | $ | 210,328 |  |  | $ | 211,990 |  |
  (was, 2024-02-02, similarity 0.7386):
[0000320193-24-000006:note_history:6]
|  | Three Months Ended |  |  |
|  | December 30,2023 |  | December 31,2022 |  |  |  |  |
| iPhone® | $ | 69,702 |  |  | $ | 65,775 |  |  |  |  |  |
| Mac® | 7,780 |  |  | 7,735 |  |  |  |  |  |
| iPad® | 7,023 |  |  | 9,396 |  |  |  |  |  |
| Wearables, Home and Accessories | 11,953 |  |  | 13,482 |  |  |  |  |  |
| Services | 23,117 |  |  | 20,766 |  |  |  |  |  |
| Total net sales | $ | 119,575 |  |  | $ | 117,154 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-05-03):
[0000320193-24-000069:note_history:7]
Revenue
Net sales disaggregated by significant products and services for the three- and six-month periods ended March 30, 2024 and April 1, 2023 were as follows (in millions):
  (was, 2024-02-02, similarity 0.8882):
[0000320193-24-000006:note_history:7]
Revenue
Net sales disaggregated by significant products and services for the three months ended December 30, 2023 and December 31, 2022 were as follows (in millions):

- changed (2024-05-03):
[0000320193-24-000069:note_history:8]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30,2024 |  | April 1,2023 |  | March 30,2024 |  | April 1,2023 |
| iPhone® | $ | 45,963 |  |  | $ | 51,334 |  |  | $ | 115,665 |  |  | $ | 117,109 |  |
| Mac® | 7,451 |  |  | 7,168 |  |  | 15,231 |  |  | 14,903 |  |
| iPad® | 5,559 |  |  | 6,670 |  |  | 12,582 |  |  | 16,066 |  |
| Wearables, Home and Accessories | 7,913 |  |  | 8,757 |  |  | 19,866 |  |  | 22,239 |  |
| Services | 23,867 |  |  | 20,907 |  |  | 46,984 |  |  | 41,673 |  |
| Total net sales | $ | 90,753 |  |  | $ | 94,836 |  |  | $ | 210,328 |  |  | $ | 211,990 |  |
  (was, 2024-02-02, similarity 0.7386):
[0000320193-24-000006:note_history:8]
|  | Three Months Ended |  |  |
|  | December 30,2023 |  | December 31,2022 |  |  |  |  |
| iPhone® | $ | 69,702 |  |  | $ | 65,775 |  |  |  |  |  |
| Mac® | 7,780 |  |  | 7,735 |  |  |  |  |  |
| iPad® | 7,023 |  |  | 9,396 |  |  |  |  |  |
| Wearables, Home and Accessories | 11,953 |  |  | 13,482 |  |  |  |  |  |
| Services | 23,117 |  |  | 20,766 |  |  |  |  |  |
| Total net sales | $ | 119,575 |  |  | $ | 117,154 |  |  |  |  |  |

- added (2024-05-03):
[0000320193-24-000069:note_history:9]
Total net sales include $3.3 billion of revenue recognized in the three months ended March 30, 2024 that was included in deferred revenue as of December 30, 2023, $3.5 billion of revenue recognized in the three months ended April 1, 2023 that was included in deferred revenue as of December 31, 2022, $5.1 billion of revenue recognized in the six months ended March 30, 2024 that was included in deferred revenue as of September 30, 2023, and $5.5 billion of revenue recognized in the six months ended April 1, 2023 that was included in deferred revenue as of September 24, 2022.

- changed (2024-05-03):
[0000320193-24-000069:note_history:10]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 10, “Segment Information and Geographic Data” for the three- and six-month periods ended March 30, 2024 and April 1, 2023, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.
  (was, 2024-02-02, similarity 0.8525):
[0000320193-24-000006:note_history:10]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 10, “Segment Information and Geographic Data” for the three months ended December 30, 2023 and December 31, 2022, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.

- changed (2024-05-03):
[0000320193-24-000069:note_history:11]
As of March 30, 2024 and September 30, 2023, the Company had total deferred revenue of $12.6 billion and $12.1 billion, respectively. As of March 30, 2024, the Company expects 64% of total deferred revenue to be realized in less than a year, 26% within one-to-two years, 9% within two-to-three years and 1% in greater than three years.
  (was, 2024-02-02, similarity 0.9585):
[0000320193-24-000006:note_history:11]
As of December 30, 2023 and September 30, 2023, the Company had total deferred revenue of $12.5 billion and $12.1 billion, respectively. As of December 30, 2023, the Company expects 66% of total deferred revenue to be realized in less than a year, 26% within one-to-two years, 7% within two-to-three years and 1% in greater than three years.

- removed (2024-05-03):
[0000320193-24-000006:note_history:12]
Total net sales include $3.5 billion of revenue recognized in the three months ended December 30, 2023 that was included in deferred revenue as of September 30, 2023 and $3.4 billion of revenue recognized in the three months ended December 31, 2022 that was included in deferred revenue as of September 24, 2022.
