# AAPL MD&A — 0000320193-24-000069


## mdna

[0000320193-24-000069:mdna:1]
[same as prior period, unchanged from 0000320193-24-000006:mdna:1]

[0000320193-24-000069:mdna:2]
[same as prior period, unchanged from 0000320193-24-000006:mdna:2]

[0000320193-24-000069:mdna:3]
[same as prior period, unchanged from 0000320193-24-000006:mdna:3]

[0000320193-24-000069:mdna:4]
[same as prior period, unchanged from 0000320193-24-000006:mdna:4]

[0000320193-24-000069:mdna:5]
[same as prior period, unchanged from 0000320193-24-000006:mdna:5]

[0000320193-24-000069:mdna:6]
[same as prior period, unchanged from 0000320193-24-000006:mdna:6]

[0000320193-24-000069:mdna:7]
[same as prior period, unchanged from 0000320193-24-000006:mdna:7]

[0000320193-24-000069:mdna:8]
During the second quarter of 2024, the Company announced an updated MacBook Air® 13-in. and MacBook Air 15-in.

[0000320193-24-000069:mdna:9]
[same as prior period, unchanged from 0000320193-24-000006:mdna:8]

[0000320193-24-000069:mdna:10]
[same as prior period, unchanged from 0000320193-24-000006:mdna:9]

[0000320193-24-000069:mdna:11]
[same as prior period, unchanged from 0000320193-24-000006:mdna:15]

[0000320193-24-000069:mdna:12]
Macroeconomic conditions, including inflation, interest rates and currency fluctuations, have directly and indirectly impacted, and could in the future materially impact, the Company’s results of operations and financial condition.

[0000320193-24-000069:mdna:13]
[same as prior period, unchanged from 0000320193-24-000006:mdna:17]

[0000320193-24-000069:mdna:14]
The following table shows net sales by reportable segment for the three- and six-month periods ended March 30, 2024 and April 1, 2023 (dollars in millions):

[0000320193-24-000069:mdna:15]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30,2024 |  | April 1,2023 |  | Change |  | March 30,2024 |  | April 1,2023 |  | Change |
| Net sales by reportable segment: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 37,273 |  |  | $ | 37,784 |  |  | (1) | % |  | $ | 87,703 |  |  | $ | 87,062 |  |  | 1 | % |
| Europe | 24,123 |  |  | 23,945 |  |  | 1 | % |  | 54,520 |  |  | 51,626 |  |  | 6 | % |
| Greater China | 16,372 |  |  | 17,812 |  |  | (8) | % |  | 37,191 |  |  | 41,717 |  |  | (11) | % |
| Japan | 6,262 |  |  | 7,176 |  |  | (13) | % |  | 14,029 |  |  | 13,931 |  |  | 1 | % |
| Rest of Asia Pacific | 6,723 |  |  | 8,119 |  |  | (17) | % |  | 16,885 |  |  | 17,654 |  |  | (4) | % |
| Total net sales | $ | 90,753 |  |  | $ | 94,836 |  |  | (4) | % |  | $ | 210,328 |  |  | $ | 211,990 |  |  | (1) | % |

[0000320193-24-000069:mdna:16]
[same as prior period, unchanged from 0000320193-24-000006:mdna:20]

[0000320193-24-000069:mdna:17]
Americas net sales were relatively flat during the second quarter of 2024 compared to the second quarter of 2023, with lower net sales of iPhone and iPad offset by higher net sales of Services. Year-over-year Americas net sales were relatively flat during the first six months of 2024, with higher net sales of Services offset by lower net sales of iPhone and iPad. The strength in foreign currencies relative to the U.S. dollar had a net favorable year-over-year impact on Americas net sales during the second quarter and first six months of 2024.

[0000320193-24-000069:mdna:18]
[same as prior period, unchanged from 0000320193-24-000006:mdna:22]

[0000320193-24-000069:mdna:19]
Europe net sales were relatively flat during the second quarter of 2024 compared to the second quarter of 2023, with higher net sales of Services offset by lower net sales of iPhone. The weakness in foreign currencies relative to the U.S. dollar had a net unfavorable year-over-year impact on Europe net sales during the second quarter of 2024. Year-over-year Europe net sales increased during the first six months of 2024 due primarily to higher net sales of iPhone and Services, partially offset by lower net sales of iPad.

[0000320193-24-000069:mdna:20]
[same as prior period, unchanged from 0000320193-24-000006:mdna:24]

[0000320193-24-000069:mdna:21]
Greater China net sales decreased during the second quarter and first six months of 2024 compared to the same periods in 2023 due primarily to lower net sales of iPhone and iPad. The weakness in the renminbi relative to the U.S. dollar had an unfavorable year-over-year impact on Greater China net sales during the second quarter and first six months of 2024.

[0000320193-24-000069:mdna:22]
[same as prior period, unchanged from 0000320193-24-000006:mdna:26]

[0000320193-24-000069:mdna:23]
Japan net sales decreased during the second quarter of 2024 compared to the second quarter of 2023 due primarily to lower net sales of iPhone. Year-over-year Japan net sales during the first six months of 2024 were relatively flat. The weakness in the yen relative to the U.S. dollar had an unfavorable year-over-year impact on Japan net sales during the second quarter and first six months of 2024.

[0000320193-24-000069:mdna:24]
[same as prior period, unchanged from 0000320193-24-000006:mdna:28]

[0000320193-24-000069:mdna:25]
Rest of Asia Pacific net sales decreased during the second quarter of 2024 compared to the second quarter of 2023 due primarily to lower net sales of iPhone. Year-over-year Rest of Asia Pacific net sales decreased during the first six months of 2024 due primarily to lower net sales of Wearables, Home and Accessories and iPad.

[0000320193-24-000069:mdna:26]
[same as prior period, unchanged from 0000320193-24-000006:mdna:30]

[0000320193-24-000069:mdna:27]
The following table shows net sales by category for the three- and six-month periods ended March 30, 2024 and April 1, 2023 (dollars in millions):

[0000320193-24-000069:mdna:28]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30,2024 |  | April 1,2023 |  | Change |  | March 30,2024 |  | April 1,2023 |  | Change |
| Net sales by category: |  |  |  |  |  |  |  |  |  |  |  |
| iPhone | $ | 45,963 |  |  | $ | 51,334 |  |  | (10) | % |  | $ | 115,665 |  |  | $ | 117,109 |  |  | (1) | % |
| Mac | 7,451 |  |  | 7,168 |  |  | 4 | % |  | 15,231 |  |  | 14,903 |  |  | 2 | % |
| iPad | 5,559 |  |  | 6,670 |  |  | (17) | % |  | 12,582 |  |  | 16,066 |  |  | (22) | % |
| Wearables, Home and Accessories | 7,913 |  |  | 8,757 |  |  | (10) | % |  | 19,866 |  |  | 22,239 |  |  | (11) | % |
| Services | 23,867 |  |  | 20,907 |  |  | 14 | % |  | 46,984 |  |  | 41,673 |  |  | 13 | % |
| Total net sales | $ | 90,753 |  |  | $ | 94,836 |  |  | (4) | % |  | $ | 210,328 |  |  | $ | 211,990 |  |  | (1) | % |

[0000320193-24-000069:mdna:29]
[same as prior period, unchanged from 0000320193-24-000006:mdna:33]

[0000320193-24-000069:mdna:30]
iPhone net sales decreased during the second quarter of 2024 compared to the second quarter of 2023 due to lower net sales of Pro models. Year-over-year iPhone net sales were relatively flat during the first six months of 2024.

[0000320193-24-000069:mdna:31]
[same as prior period, unchanged from 0000320193-24-000006:mdna:35]

[0000320193-24-000069:mdna:32]
Mac net sales increased during the second quarter and first six months of 2024 compared to the same periods in 2023 due to higher net sales of laptops.

[0000320193-24-000069:mdna:33]
[same as prior period, unchanged from 0000320193-24-000006:mdna:37]

[0000320193-24-000069:mdna:34]
iPad net sales decreased during the second quarter and first six months of 2024 compared to the same periods in 2023 due primarily to lower net sales of iPad Pro® and iPad 9th generation.

[0000320193-24-000069:mdna:35]
[same as prior period, unchanged from 0000320193-24-000006:mdna:39]

[0000320193-24-000069:mdna:36]
Wearables, Home and Accessories net sales decreased during the second quarter and first six months of 2024 compared to the same periods in 2023 due primarily to lower net sales of Wearables and Accessories.

[0000320193-24-000069:mdna:37]
[same as prior period, unchanged from 0000320193-24-000006:mdna:41]

[0000320193-24-000069:mdna:38]
Services net sales increased during the second quarter and first six months of 2024 compared to the same periods in 2023 due primarily to higher net sales from advertising, the App Store® and cloud services.

[0000320193-24-000069:mdna:39]
[same as prior period, unchanged from 0000320193-24-000006:mdna:43]

[0000320193-24-000069:mdna:40]
Products and Services gross margin and gross margin percentage for the three- and six-month periods ended March 30, 2024 and April 1, 2023 were as follows (dollars in millions):

[0000320193-24-000069:mdna:41]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30,2024 |  | April 1,2023 |  | March 30,2024 |  | April 1,2023 |
| Gross margin: |  |  |  |  |  |  |  |
| Products | $ | 24,462 |  |  | $ | 27,134 |  |  | $ | 62,480 |  |  | $ | 62,757 |  |
| Services | 17,809 |  |  | 14,842 |  |  | 34,646 |  |  | 29,551 |  |
| Total gross margin | $ | 42,271 |  |  | $ | 41,976 |  |  | $ | 97,126 |  |  | $ | 92,308 |  |

[0000320193-24-000069:mdna:42]
| Gross margin percentage: |  |  |  |  |  |  |  |
| Products | 36.6 | % |  | 36.7 | % |  | 38.3 | % |  | 36.8 | % |
| Services | 74.6 | % |  | 71.0 | % |  | 73.7 | % |  | 70.9 | % |
| Total gross margin percentage | 46.6 | % |  | 44.3 | % |  | 46.2 | % |  | 43.5 | % |

[0000320193-24-000069:mdna:43]
[same as prior period, unchanged from 0000320193-24-000006:mdna:47]

[0000320193-24-000069:mdna:44]
Products gross margin decreased during the second quarter of 2024 compared to the second quarter of 2023 due primarily to lower Products volume and the weakness in foreign currencies relative to the U.S. dollar. Year-over-year Products gross margin was relatively flat during the first six months of 2024.

[0000320193-24-000069:mdna:45]
Products gross margin percentage was relatively flat during the second quarter of 2024 compared to the second quarter of 2023. Year-over-year Products gross margin percentage increased during the first six months of 2024 due primarily to cost savings, partially offset by the weakness in foreign currencies relative to the U.S. dollar.

[0000320193-24-000069:mdna:46]
[same as prior period, unchanged from 0000320193-24-000006:mdna:50]

[0000320193-24-000069:mdna:47]
Services gross margin and Services gross margin percentage increased during the second quarter and first six months of 2024 compared to the same periods in 2023 due primarily to a different Services mix.

[0000320193-24-000069:mdna:48]
[same as prior period, unchanged from 0000320193-24-000006:mdna:53]

[0000320193-24-000069:mdna:49]
[same as prior period, unchanged from 0000320193-24-000006:mdna:54]

[0000320193-24-000069:mdna:50]
Operating expenses for the three- and six-month periods ended March 30, 2024 and April 1, 2023 were as follows (dollars in millions):

[0000320193-24-000069:mdna:51]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30,2024 |  | April 1,2023 |  | March 30,2024 |  | April 1,2023 |
| Research and development | $ | 7,903 |  |  | $ | 7,457 |  |  | $ | 15,599 |  |  | $ | 15,166 |  |
| Percentage of total net sales | 9 | % |  | 8 | % |  | 7 | % |  | 7 | % |
| Selling, general and administrative | $ | 6,468 |  |  | $ | 6,201 |  |  | $ | 13,254 |  |  | $ | 12,808 |  |
| Percentage of total net sales | 7 | % |  | 7 | % |  | 6 | % |  | 6 | % |
| Total operating expenses | $ | 14,371 |  |  | $ | 13,658 |  |  | $ | 28,853 |  |  | $ | 27,974 |  |
| Percentage of total net sales | 16 | % |  | 14 | % |  | 14 | % |  | 13 | % |

[0000320193-24-000069:mdna:52]
[same as prior period, unchanged from 0000320193-24-000006:mdna:57]

[0000320193-24-000069:mdna:53]
The growth in research and development (“R&D”) expense during the second quarter and first six months of 2024 compared to the same periods in 2023 was driven primarily by increases in headcount-related expenses.

[0000320193-24-000069:mdna:54]
[same as prior period, unchanged from 0000320193-24-000006:mdna:59]

[0000320193-24-000069:mdna:55]
The growth in selling, general and administrative expense during the second quarter and first six months of 2024 compared to the same periods in 2023 was driven in part by higher infrastructure-related costs.

[0000320193-24-000069:mdna:56]
[same as prior period, unchanged from 0000320193-24-000006:mdna:61]

[0000320193-24-000069:mdna:57]
Provision for income taxes, effective tax rate and statutory federal income tax rate for the three- and six-month periods ended March 30, 2024 and April 1, 2023 were as follows (dollars in millions):

[0000320193-24-000069:mdna:58]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30,2024 |  | April 1,2023 |  | March 30,2024 |  | April 1,2023 |
| Provision for income taxes | $ | 4,422 |  |  | $ | 4,222 |  |  | $ | 10,829 |  |  | $ | 9,847 |  |
| Effective tax rate | 15.8 | % |  | 14.9 | % |  | 15.8 | % |  | 15.4 | % |
| Statutory federal income tax rate | 21 | % |  | 21 | % |  | 21 | % |  | 21 | % |

[0000320193-24-000069:mdna:59]
The Company’s effective tax rate for the second quarter and first six months of 2024 was lower than the statutory federal income tax rate due primarily to a lower effective tax rate on foreign earnings, the impact of the U.S. federal R&D credit, and tax benefits from share-based compensation, partially offset by state income taxes.

[0000320193-24-000069:mdna:60]
The Company’s effective tax rate for the second quarter and first six months of 2024 was higher compared to the same periods in 2023 due primarily to a higher effective tax rate on foreign earnings and a lower tax benefit from the U.S. federal R&D credit.

[0000320193-24-000069:mdna:61]
[same as prior period, unchanged from 0000320193-24-000006:mdna:66]

[0000320193-24-000069:mdna:62]
[same as prior period, unchanged from 0000320193-24-000006:mdna:67]

[0000320193-24-000069:mdna:63]
[same as prior period, unchanged from 0000320193-24-000006:mdna:68]

[0000320193-24-000069:mdna:64]
[same as prior period, unchanged from 0000320193-24-000006:mdna:69]

[0000320193-24-000069:mdna:65]
The Company utilizes several outsourcing partners to manufacture subassemblies for the Company’s products and to perform final assembly and testing of finished products. The Company also obtains individual components for its products from a wide variety of individual suppliers. As of March 30, 2024, the Company had manufacturing purchase obligations of $34.2 billion, with $34.1 billion payable within 12 months.

[0000320193-24-000069:mdna:66]
[same as prior period, unchanged from 0000320193-24-000006:mdna:71]

[0000320193-24-000069:mdna:67]
In addition to its contractual cash requirements, the Company has an authorized share repurchase program, under which the remaining availability was $30.1 billion as of March 30, 2024. On May 2, 2024, the Company announced the Board of Directors had authorized an additional program to repurchase up to $110 billion of the Company’s common stock. The programs do not obligate the Company to acquire a minimum amount of shares.

[0000320193-24-000069:mdna:68]
On May 2, 2024, the Company also announced the Board of Directors raised the Company’s quarterly cash dividend from $0.24 to $0.25 per share, beginning with the dividend to be paid during the third quarter of 2024. The Company intends to increase its dividend on an annual basis, subject to declaration by the Board of Directors.

[0000320193-24-000069:mdna:69]
During the second quarter of 2024, the Company repurchased $23.5 billion of its common stock and paid dividends and dividend equivalents of $3.7 billion.

[0000320193-24-000069:mdna:70]
[same as prior period, unchanged from 0000320193-24-000006:mdna:73]

[0000320193-24-000069:mdna:71]
[same as prior period, unchanged from 0000320193-24-000006:mdna:74]

[0000320193-24-000069:mdna:72]
In December 2023, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) No. 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures (“ASU 2023-09”), which will require the Company to disclose specified additional information in its income tax rate reconciliation and provide additional information for reconciling items that meet a quantitative threshold. ASU 2023-09 will also require the Company to disaggregate its income taxes paid disclosure by federal, state and foreign taxes, with further disaggregation required for significant individual jurisdictions. The Company will adopt ASU 2023-09 in its fourth quarter of 2026. ASU 2023-09 allows for adoption using either a prospective or retrospective transition method.

[0000320193-24-000069:mdna:73]
[same as prior period, unchanged from 0000320193-24-000006:mdna:76]

[0000320193-24-000069:mdna:74]
In November 2023, the FASB issued ASU No. 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures (“ASU 2023-07”), which will require the Company to disclose segment expenses that are significant and regularly provided to the Company’s chief operating decision maker (“CODM”). In addition, ASU 2023-07 will require the Company to disclose the title and position of its CODM and how the CODM uses segment profit or loss information in assessing segment performance and deciding how to allocate resources. The Company will adopt ASU 2023-07 in its fourth quarter of 2025 using a retrospective transition method.

[0000320193-24-000069:mdna:75]
[same as prior period, unchanged from 0000320193-24-000006:mdna:78]

[0000320193-24-000069:mdna:76]
[same as prior period, unchanged from 0000320193-24-000006:mdna:79]
