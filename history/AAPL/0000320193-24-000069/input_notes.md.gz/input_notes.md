# AAPL notes — 0000320193-24-000069


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000320193-24-000069:notes:1]
[same as prior period, unchanged from 0000320193-24-000006:notes:1]

[0000320193-24-000069:notes:2]
The condensed consolidated financial statements include the accounts of Apple Inc. and its wholly owned subsidiaries (collectively “Apple” or the “Company”). In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements and accompanying notes in conformity with U.S. generally accepted accounting principles (“GAAP”) requires the use of management estimates. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company’s annual consolidated financial statements and accompanying notes included in its Annual Report on Form 10-K for the fiscal year ended September 30, 2023 (the “2023 Form 10-K”).

[0000320193-24-000069:notes:3]
[same as prior period, unchanged from 0000320193-24-000006:notes:3]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000320193-24-000069:notes:4]
Revenue
Net sales disaggregated by significant products and services for the three- and six-month periods ended March 30, 2024 and April 1, 2023 were as follows (in millions):

[0000320193-24-000069:notes:5]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30,2024 |  | April 1,2023 |  | March 30,2024 |  | April 1,2023 |
| iPhone® | $ | 45,963 |  |  | $ | 51,334 |  |  | $ | 115,665 |  |  | $ | 117,109 |  |
| Mac® | 7,451 |  |  | 7,168 |  |  | 15,231 |  |  | 14,903 |  |
| iPad® | 5,559 |  |  | 6,670 |  |  | 12,582 |  |  | 16,066 |  |
| Wearables, Home and Accessories | 7,913 |  |  | 8,757 |  |  | 19,866 |  |  | 22,239 |  |
| Services | 23,867 |  |  | 20,907 |  |  | 46,984 |  |  | 41,673 |  |
| Total net sales | $ | 90,753 |  |  | $ | 94,836 |  |  | $ | 210,328 |  |  | $ | 211,990 |  |

[0000320193-24-000069:notes:6]
Total net sales include $3.3 billion of revenue recognized in the three months ended March 30, 2024 that was included in deferred revenue as of December 30, 2023, $3.5 billion of revenue recognized in the three months ended April 1, 2023 that was included in deferred revenue as of December 31, 2022, $5.1 billion of revenue recognized in the six months ended March 30, 2024 that was included in deferred revenue as of September 30, 2023, and $5.5 billion of revenue recognized in the six months ended April 1, 2023 that was included in deferred revenue as of September 24, 2022.

[0000320193-24-000069:notes:7]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 10, “Segment Information and Geographic Data” for the three- and six-month periods ended March 30, 2024 and April 1, 2023, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.

[0000320193-24-000069:notes:8]
As of March 30, 2024 and September 30, 2023, the Company had total deferred revenue of $12.6 billion and $12.1 billion, respectively. As of March 30, 2024, the Company expects 64% of total deferred revenue to be realized in less than a year, 26% within one-to-two years, 9% within two-to-three years and 1% in greater than three years.


## us-gaap:EarningsPerShareTextBlock

[0000320193-24-000069:notes:9]
Earnings Per Share
The following table shows the computation of basic and diluted earnings per share for the three- and six-month periods ended March 30, 2024 and April 1, 2023 (net income in millions and shares in thousands):

[0000320193-24-000069:notes:10]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30,2024 |  | April 1,2023 |  | March 30,2024 |  | April 1,2023 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 23,636 |  |  | $ | 24,160 |  |  | $ | 57,552 |  |  | $ | 54,158 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 15,405,856 |  |  | 15,787,154 |  |  | 15,457,810 |  |  | 15,839,939 |  |
| Effect of dilutive share-based awards | 58,853 |  |  | 59,896 |  |  | 62,865 |  |  | 61,445 |  |
| Weighted-average diluted shares | 15,464,709 |  |  | 15,847,050 |  |  | 15,520,675 |  |  | 15,901,384 |  |
| Basic earnings per share | $ | 1.53 |  |  | $ | 1.53 |  |  | $ | 3.72 |  |  | $ | 3.42 |  |
| Diluted earnings per share | $ | 1.53 |  |  | $ | 1.52 |  |  | $ | 3.71 |  |  | $ | 3.41 |  |

[0000320193-24-000069:notes:11]
Approximately 48 million restricted stock units (“RSUs”) were excluded from the computation of diluted earnings per share for the six months ended April 1, 2023 because their effect would have been antidilutive.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000320193-24-000069:notes:12]
[same as prior period, unchanged from 0000320193-24-000006:notes:12]

[0000320193-24-000069:notes:13]
The following tables show the Company’s cash, cash equivalents and marketable securities by significant investment category as of March 30, 2024 and September 30, 2023 (in millions):

[0000320193-24-000069:notes:14]
|  | March 30, 2024 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | CurrentMarketableSecurities |  | Non-CurrentMarketableSecurities |
| Cash | $ | 28,227 |  |  | $ | — |  |  | $ | — |  |  | $ | 28,227 |  |  | $ | 28,227 |  |  | $ | — |  |  | $ | — |  |
| Level 1: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 1,353 |  |  | — |  |  | — |  |  | 1,353 |  |  | 1,353 |  |  | — |  |  | — |  |
| Mutual funds | 464 |  |  | 66 |  |  | (7) |  |  | 523 |  |  | — |  |  | 523 |  |  | — |  |
| Subtotal | 1,817 |  |  | 66 |  |  | (7) |  |  | 1,876 |  |  | 1,353 |  |  | 523 |  |  | — |  |
| Level 2 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 18,150 |  |  | 1 |  |  | (933) |  |  | 17,218 |  |  | 1,895 |  |  | 4,133 |  |  | 11,190 |  |
| U.S. agency securities | 5,775 |  |  | — |  |  | (446) |  |  | 5,329 |  |  | 233 |  |  | 581 |  |  | 4,515 |  |
| Non-U.S. government securities | 17,319 |  |  | 37 |  |  | (666) |  |  | 16,690 |  |  | — |  |  | 11,289 |  |  | 5,401 |  |
| Certificates of deposit and time deposits | 976 |  |  | — |  |  | — |  |  | 976 |  |  | 656 |  |  | 320 |  |  | — |  |
| Commercial paper | 1,482 |  |  | — |  |  | — |  |  | 1,482 |  |  | 274 |  |  | 1,208 |  |  | — |  |
| Corporate debt securities | 71,612 |  |  | 90 |  |  | (3,694) |  |  | 68,008 |  |  | 57 |  |  | 15,096 |  |  | 52,855 |  |
| Municipal securities | 511 |  |  | — |  |  | (15) |  |  | 496 |  |  | — |  |  | 188 |  |  | 308 |  |
| Mortgage- and asset-backed securities | 24,044 |  |  | 37 |  |  | (2,046) |  |  | 22,035 |  |  | — |  |  | 1,117 |  |  | 20,918 |  |
| Subtotal | 139,869 |  |  | 165 |  |  | (7,800) |  |  | 132,234 |  |  | 3,115 |  |  | 33,932 |  |  | 95,187 |  |
| Total (2) | $ | 169,913 |  |  | $ | 231 |  |  | $ | (7,807) |  |  | $ | 162,337 |  |  | $ | 32,695 |  |  | $ | 34,455 |  |  | $ | 95,187 |  |

[0000320193-24-000069:notes:15]
[same as prior period, unchanged from 0000320193-24-000006:notes:15]

[0000320193-24-000069:notes:16]
[same as prior period, unchanged from 0000320193-24-000006:notes:16]

[0000320193-24-000069:notes:17]
(2)As of March 30, 2024 and September 30, 2023, total marketable securities included $14.0 billion and $13.8 billion, respectively, that were restricted from general use, related to the European Commission decision finding that Ireland granted state aid to the Company, and other agreements.

[0000320193-24-000069:notes:18]
The following table shows the fair value of the Company’s non-current marketable debt securities, by contractual maturity, as of March 30, 2024 (in millions):

[0000320193-24-000069:notes:19]
| Due after 1 year through 5 years | $ | 67,987 |  |
| Due after 5 years through 10 years | 9,108 |  |
| Due after 10 years | 18,092 |  |
| Total fair value | $ | 95,187 |  |

[0000320193-24-000069:notes:20]
[same as prior period, unchanged from 0000320193-24-000006:notes:20]

[0000320193-24-000069:notes:21]
[same as prior period, unchanged from 0000320193-24-000006:notes:21]

[0000320193-24-000069:notes:22]
[same as prior period, unchanged from 0000320193-24-000006:notes:22]

[0000320193-24-000069:notes:23]
[same as prior period, unchanged from 0000320193-24-000006:notes:23]

[0000320193-24-000069:notes:24]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in foreign exchange rates, the Company may use forwards, cross-currency swaps or other instruments. The Company designates these instruments as either cash flow or fair value hedges. As of March 30, 2024, the maximum length of time over which the Company is hedging its exposure to the variability in future cash flows for term debt–related foreign currency transactions is 18 years.

[0000320193-24-000069:notes:25]
[same as prior period, unchanged from 0000320193-24-000006:notes:25]

[0000320193-24-000069:notes:26]
[same as prior period, unchanged from 0000320193-24-000006:notes:26]

[0000320193-24-000069:notes:27]
[same as prior period, unchanged from 0000320193-24-000006:notes:27]

[0000320193-24-000069:notes:28]
The notional amounts of the Company’s outstanding derivative instruments as of March 30, 2024 and September 30, 2023 were as follows (in millions):

[0000320193-24-000069:notes:29]
|  | March 30,2024 |  | September 30,2023 |
| Derivative instruments designated as accounting hedges: |  |  |  |
| Foreign exchange contracts | $ | 60,265 |  |  | $ | 74,730 |  |
| Interest rate contracts | $ | 17,625 |  |  | $ | 19,375 |  |
| Derivative instruments not designated as accounting hedges: |  |  |  |
| Foreign exchange contracts | $ | 75,552 |  |  | $ | 104,777 |  |

[0000320193-24-000069:notes:30]
The carrying amounts of the Company’s hedged items in fair value hedges as of March 30, 2024 and September 30, 2023 were as follows (in millions):

[0000320193-24-000069:notes:31]
|  | March 30,2024 |  | September 30,2023 |
| Hedged assets/(liabilities): |  |  |  |
| Current and non-current marketable securities | $ | 15,045 |  |  | $ | 14,433 |  |
| Current and non-current term debt | $ | (16,817) |  |  | $ | (18,247) |  |

[0000320193-24-000069:notes:32]
[same as prior period, unchanged from 0000320193-24-000006:notes:32]

[0000320193-24-000069:notes:33]
[same as prior period, unchanged from 0000320193-24-000006:notes:33]

[0000320193-24-000069:notes:34]
The Company’s third-party cellular network carriers accounted for 34% and 41% of total trade receivables as of March 30, 2024 and September 30, 2023, respectively. The Company requires third-party credit support or collateral from certain customers to limit credit risk.

[0000320193-24-000069:notes:35]
[same as prior period, unchanged from 0000320193-24-000006:notes:35]

[0000320193-24-000069:notes:36]
The Company has non-trade receivables from certain of its manufacturing vendors resulting from the sale of components to these vendors who manufacture subassemblies or assemble final products for the Company. The Company purchases these components directly from suppliers. The Company does not reflect the sale of these components in products net sales. Rather, the Company recognizes any gain on these sales as a reduction of products cost of sales when the related final products are sold by the Company. As of March 30, 2024, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 47% and 19%. As of September 30, 2023, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 48% and 23%.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000320193-24-000069:notes:37]
Condensed Consolidated Financial Statement Details
The following table shows the Company’s condensed consolidated financial statement details as of March 30, 2024 and September 30, 2023 (in millions):

[0000320193-24-000069:notes:38]
[same as prior period, unchanged from 0000320193-24-000006:notes:38]

[0000320193-24-000069:notes:39]
|  | March 30,2024 |  | September 30,2023 |
| Gross property, plant and equipment | $ | 115,243 |  |  | $ | 114,599 |  |
| Accumulated depreciation | (71,697) |  |  | (70,884) |  |
| Total property, plant and equipment, net | $ | 43,546 |  |  | $ | 43,715 |  |


## us-gaap:DebtDisclosureTextBlock

[0000320193-24-000069:notes:40]
Debt
Commercial Paper

[0000320193-24-000069:notes:41]
The Company issues unsecured short-term promissory notes pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of March 30, 2024 and September 30, 2023, the Company had $2.0 billion and $6.0 billion of commercial paper outstanding, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of commercial paper for the six months ended March 30, 2024 and April 1, 2023 (in millions):

[0000320193-24-000069:notes:42]
|  | Six Months Ended |
|  | March 30,2024 |  | April 1,2023 |
| Maturities 90 days or less: |  |  |  |
| Repayments of commercial paper, net | $ | (3,982) |  |  | $ | (5,315) |  |
| Maturities greater than 90 days: |  |  |  |
| Repayments of commercial paper | — |  |  | (2,645) |  |
| Total repayments of commercial paper, net | $ | (3,982) |  |  | $ | (7,960) |  |

[0000320193-24-000069:notes:43]
Term Debt

[0000320193-24-000069:notes:44]
As of March 30, 2024 and September 30, 2023, the Company had outstanding fixed-rate notes with varying maturities for an aggregate carrying amount of $102.6 billion and $105.1 billion, respectively (collectively the “Notes”). As of March 30, 2024 and September 30, 2023, the fair value of the Company’s Notes, based on Level 2 inputs, was $91.6 billion and $90.8 billion, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000320193-24-000069:notes:45]
[same as prior period, unchanged from 0000320193-24-000006:notes:45]

[0000320193-24-000069:notes:46]
During the six months ended March 30, 2024, the Company repurchased 248 million shares of its common stock for $44.0 billion. The Company’s share repurchase program does not obligate the Company to acquire a minimum amount of shares. Under the program, shares may be repurchased in privately negotiated or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000320193-24-000069:notes:47]
[same as prior period, unchanged from 0000320193-24-000006:notes:47]

[0000320193-24-000069:notes:48]
A summary of the Company’s RSU activity and related information for the six months ended March 30, 2024 is as follows:

[0000320193-24-000069:notes:49]
|  | Number ofRSUs(in thousands) |  | Weighted-AverageGrant Date FairValue Per RSU |  | AggregateFair Value(in millions) |
| Balance as of September 30, 2023 | 180,247 |  |  | $ | 135.91 |  |  |  |
| RSUs granted | 75,826 |  |  | $ | 171.78 |  |  |  |
| RSUs vested | (47,027) |  |  | $ | 113.44 |  |  |  |
| RSUs canceled | (5,195) |  |  | $ | 126.83 |  |  |  |
| Balance as of March 30, 2024 | 203,851 |  |  | $ | 154.66 |  |  | $ | 34,956 |  |

[0000320193-24-000069:notes:50]
The fair value as of the respective vesting dates of RSUs was $821 million and $8.6 billion for the three- and six-month periods ended March 30, 2024, respectively, and was $1.1 billion and $8.0 billion for the three- and six-month periods ended April 1, 2023, respectively.

[0000320193-24-000069:notes:51]
[same as prior period, unchanged from 0000320193-24-000006:notes:51]

[0000320193-24-000069:notes:52]
The following table shows share-based compensation expense and the related income tax benefit included in the Condensed Consolidated Statements of Operations for the three- and six-month periods ended March 30, 2024 and April 1, 2023 (in millions):

[0000320193-24-000069:notes:53]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30,2024 |  | April 1,2023 |  | March 30,2024 |  | April 1,2023 |
| Share-based compensation expense | $ | 2,964 |  |  | $ | 2,686 |  |  | $ | 5,961 |  |  | $ | 5,591 |  |
| Income tax benefit related to share-based compensation expense | $ | (663) |  |  | $ | (620) |  |  | $ | (1,898) |  |  | $ | (1,798) |  |

[0000320193-24-000069:notes:54]
As of March 30, 2024, the total unrecognized compensation cost related to outstanding RSUs was $24.7 billion, which the Company expects to recognize over a weighted-average period of 2.7 years.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000320193-24-000069:notes:55]
Segment Information and Geographic Data
The following table shows information by reportable segment for the three- and six-month periods ended March 30, 2024 and April 1, 2023 (in millions):

[0000320193-24-000069:notes:56]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30,2024 |  | April 1,2023 |  | March 30,2024 |  | April 1,2023 |
| Americas: |  |  |  |  |  |  |  |
| Net sales | $ | 37,273 |  |  | $ | 37,784 |  |  | $ | 87,703 |  |  | $ | 87,062 |  |
| Operating income | $ | 15,074 |  |  | $ | 13,927 |  |  | $ | 35,431 |  |  | $ | 31,791 |  |
| Europe: |  |  |  |  |  |  |  |
| Net sales | $ | 24,123 |  |  | $ | 23,945 |  |  | $ | 54,520 |  |  | $ | 51,626 |  |
| Operating income | $ | 9,991 |  |  | $ | 9,368 |  |  | $ | 22,702 |  |  | $ | 19,385 |  |
| Greater China: |  |  |  |  |  |  |  |
| Net sales | $ | 16,372 |  |  | $ | 17,812 |  |  | $ | 37,191 |  |  | $ | 41,717 |  |
| Operating income | $ | 6,700 |  |  | $ | 7,531 |  |  | $ | 15,322 |  |  | $ | 17,968 |  |
| Japan: |  |  |  |  |  |  |  |
| Net sales | $ | 6,262 |  |  | $ | 7,176 |  |  | $ | 14,029 |  |  | $ | 13,931 |  |
| Operating income | $ | 3,135 |  |  | $ | 3,394 |  |  | $ | 6,954 |  |  | $ | 6,630 |  |
| Rest of Asia Pacific: |  |  |  |  |  |  |  |
| Net sales | $ | 6,723 |  |  | $ | 8,119 |  |  | $ | 16,885 |  |  | $ | 17,654 |  |
| Operating income | $ | 2,806 |  |  | $ | 3,268 |  |  | $ | 7,385 |  |  | $ | 7,119 |  |

[0000320193-24-000069:notes:57]
A reconciliation of the Company’s segment operating income to the Condensed Consolidated Statements of Operations for the three- and six-month periods ended March 30, 2024 and April 1, 2023 is as follows (in millions):

[0000320193-24-000069:notes:58]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30,2024 |  | April 1,2023 |  | March 30,2024 |  | April 1,2023 |
| Segment operating income | $ | 37,706 |  |  | $ | 37,488 |  |  | $ | 87,794 |  |  | $ | 82,893 |  |
| Research and development expense | (7,903) |  |  | (7,457) |  |  | (15,599) |  |  | (15,166) |  |
| Other corporate expenses, net | (1,903) |  |  | (1,713) |  |  | (3,922) |  |  | (3,393) |  |
| Total operating income | $ | 27,900 |  |  | $ | 28,318 |  |  | $ | 68,273 |  |  | $ | 64,334 |  |
