# AAPL notes — 0000320193-25-000073


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000320193-25-000073:notes:1]
[same as prior period, unchanged from 0000320193-25-000057:notes:1]

[0000320193-25-000073:notes:2]
[same as prior period, unchanged from 0000320193-25-000057:notes:2]

[0000320193-25-000073:notes:3]
[same as prior period, unchanged from 0000320193-25-000057:notes:3]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000320193-25-000073:notes:4]
Revenue
The following table shows disaggregated net sales, as well as the portion of total net sales that was previously deferred, for the three- and nine-month periods ended June 28, 2025 and June 29, 2024 (in millions):

[0000320193-25-000073:notes:5]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 28,2025 |  | June 29,2024 |  | June 28,2025 |  | June 29,2024 |
| iPhone® | $ | 44,582 |  |  | $ | 39,296 |  |  | $ | 160,561 |  |  | $ | 154,961 |  |
| Mac® | 8,046 |  |  | 7,009 |  |  | 24,982 |  |  | 22,240 |  |
| iPad® | 6,581 |  |  | 7,162 |  |  | 21,071 |  |  | 19,744 |  |
| Wearables, Home and Accessories | 7,404 |  |  | 8,097 |  |  | 26,673 |  |  | 27,963 |  |
| Services | 27,423 |  |  | 24,213 |  |  | 80,408 |  |  | 71,197 |  |
| Total net sales | $ | 94,036 |  |  | $ | 85,777 |  |  | $ | 313,695 |  |  | $ | 296,105 |  |
| Portion of total net sales that was included in deferred revenue as of the beginning of the period | $ | 4,015 |  |  | $ | 3,405 |  |  | $ | 6,958 |  |  | $ | 6,541 |  |

[0000320193-25-000073:notes:6]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 10, “Segment Information and Geographic Data” for the three- and nine-month periods ended June 28, 2025 and June 29, 2024, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.

[0000320193-25-000073:notes:7]
As of June 28, 2025 and September 28, 2024, the Company had total deferred revenue of $13.6 billion and $12.8 billion, respectively. As of June 28, 2025, the Company expects 66% of total deferred revenue to be realized in less than a year, 23% within one-to-two years, 9% within two-to-three years and 2% in greater than three years.


## us-gaap:EarningsPerShareTextBlock

[0000320193-25-000073:notes:8]
Earnings Per Share
The following table shows the computation of basic and diluted earnings per share for the three- and nine-month periods ended June 28, 2025 and June 29, 2024 (net income in millions and shares in thousands):

[0000320193-25-000073:notes:9]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 28,2025 |  | June 29,2024 |  | June 28,2025 |  | June 29,2024 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 23,434 |  |  | $ | 21,448 |  |  | $ | 84,544 |  |  | $ | 79,000 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 14,902,886 |  |  | 15,287,521 |  |  | 14,992,898 |  |  | 15,401,047 |  |
| Effect of dilutive share-based awards | 45,293 |  |  | 60,654 |  |  | 58,828 |  |  | 62,128 |  |
| Weighted-average diluted shares | 14,948,179 |  |  | 15,348,175 |  |  | 15,051,726 |  |  | 15,463,175 |  |
| Basic earnings per share | $ | 1.57 |  |  | $ | 1.40 |  |  | $ | 5.64 |  |  | $ | 5.13 |  |
| Diluted earnings per share | $ | 1.57 |  |  | $ | 1.40 |  |  | $ | 5.62 |  |  | $ | 5.11 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000320193-25-000073:notes:10]
[same as prior period, unchanged from 0000320193-25-000057:notes:10]

[0000320193-25-000073:notes:11]
The following tables show the Company’s cash, cash equivalents and marketable securities by significant investment category as of June 28, 2025 and September 28, 2024 (in millions):

[0000320193-25-000073:notes:12]
|  | June 28, 2025 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | CurrentMarketableSecurities |  | Non-CurrentMarketableSecurities |
| Cash | $ | 26,686 |  |  | $ | — |  |  | $ | — |  |  | $ | 26,686 |  |  | $ | 26,686 |  |  | $ | — |  |  | $ | — |  |
| Level 1: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 3,779 |  |  | — |  |  | — |  |  | 3,779 |  |  | 3,779 |  |  | — |  |  | — |  |
| Mutual funds | 646 |  |  | 134 |  |  | (3) |  |  | 777 |  |  | — |  |  | 777 |  |  | — |  |
| Subtotal | 4,425 |  |  | 134 |  |  | (3) |  |  | 4,556 |  |  | 3,779 |  |  | 777 |  |  | — |  |
| Level 2 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 15,775 |  |  | 46 |  |  | (362) |  |  | 15,459 |  |  | 1,030 |  |  | 3,649 |  |  | 10,780 |  |
| U.S. agency securities | 5,383 |  |  | — |  |  | (189) |  |  | 5,194 |  |  | 647 |  |  | 2,030 |  |  | 2,517 |  |
| Non-U.S. government securities | 6,756 |  |  | 43 |  |  | (567) |  |  | 6,232 |  |  | 297 |  |  | 795 |  |  | 5,140 |  |
| Certificates of deposit and time deposits | 3,177 |  |  | — |  |  | — |  |  | 3,177 |  |  | 3,113 |  |  | 51 |  |  | 13 |  |
| Commercial paper | 710 |  |  | — |  |  | — |  |  | 710 |  |  | 710 |  |  | — |  |  | — |  |
| Corporate debt securities | 49,671 |  |  | 212 |  |  | (1,251) |  |  | 48,632 |  |  | 7 |  |  | 11,576 |  |  | 37,049 |  |
| Municipal securities | 263 |  |  | — |  |  | (3) |  |  | 260 |  |  | — |  |  | 157 |  |  | 103 |  |
| Mortgage- and asset-backed securities | 23,424 |  |  | 90 |  |  | (1,434) |  |  | 22,080 |  |  | — |  |  | 68 |  |  | 22,012 |  |
| Subtotal | 105,159 |  |  | 391 |  |  | (3,806) |  |  | 101,744 |  |  | 5,804 |  |  | 18,326 |  |  | 77,614 |  |
| Total | $ | 136,270 |  |  | $ | 525 |  |  | $ | (3,809) |  |  | $ | 132,986 |  |  | $ | 36,269 |  |  | $ | 19,103 |  |  | $ | 77,614 |  |

[0000320193-25-000073:notes:13]
[same as prior period, unchanged from 0000320193-25-000057:notes:13]

[0000320193-25-000073:notes:14]
[same as prior period, unchanged from 0000320193-25-000057:notes:14]

[0000320193-25-000073:notes:15]
[same as prior period, unchanged from 0000320193-25-000057:notes:15]

[0000320193-25-000073:notes:16]
[same as prior period, unchanged from 0000320193-25-000057:notes:16]

[0000320193-25-000073:notes:17]
As of June 28, 2025, 82% of the Company’s non-current marketable debt securities other than mortgage- and asset-backed securities had maturities between 1 and 5 years, 14% between 5 and 10 years, and 4% greater than 10 years. As of June 28, 2025, 12% of the Company’s non-current mortgage- and asset-backed securities had maturities between 1 and 5 years, 11% between 5 and 10 years, and 77% greater than 10 years.

[0000320193-25-000073:notes:18]
[same as prior period, unchanged from 0000320193-25-000057:notes:18]

[0000320193-25-000073:notes:19]
[same as prior period, unchanged from 0000320193-25-000057:notes:19]

[0000320193-25-000073:notes:20]
[same as prior period, unchanged from 0000320193-25-000057:notes:20]

[0000320193-25-000073:notes:21]
[same as prior period, unchanged from 0000320193-25-000057:notes:21]

[0000320193-25-000073:notes:22]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in foreign exchange rates, the Company may use forwards, cross-currency swaps or other instruments. The Company designates these instruments as either cash flow or fair value hedges. As of June 28, 2025, the maximum length of time over which the Company is hedging its exposure to the variability in future cash flows for term debt–related foreign currency transactions is 17 years.

[0000320193-25-000073:notes:23]
[same as prior period, unchanged from 0000320193-25-000057:notes:23]

[0000320193-25-000073:notes:24]
[same as prior period, unchanged from 0000320193-25-000057:notes:24]

[0000320193-25-000073:notes:25]
[same as prior period, unchanged from 0000320193-25-000057:notes:25]

[0000320193-25-000073:notes:26]
The notional amounts of the Company’s outstanding derivative instruments as of June 28, 2025 and September 28, 2024, were as follows (in millions):

[0000320193-25-000073:notes:27]
|  | June 28,2025 |  | September 28,2024 |
| Derivative instruments designated as accounting hedges: |  |  |  |
| Foreign exchange contracts | $ | 63,212 |  |  | $ | 64,069 |  |
| Interest rate contracts | $ | 12,875 |  |  | $ | 14,575 |  |
| Derivative instruments not designated as accounting hedges: |  |  |  |
| Foreign exchange contracts | $ | 78,649 |  |  | $ | 91,493 |  |

[0000320193-25-000073:notes:28]
As of June 28, 2025 and September 28, 2024, the carrying amount of the Company’s current and non-current term debt subject to fair value hedges was $12.5 billion and $13.5 billion, respectively.

[0000320193-25-000073:notes:29]
[same as prior period, unchanged from 0000320193-25-000057:notes:29]

[0000320193-25-000073:notes:30]
[same as prior period, unchanged from 0000320193-25-000057:notes:30]

[0000320193-25-000073:notes:31]
As of June 28, 2025, the Company had two customers that individually represented 10% or more of total trade receivables, which accounted for 18% and 10%. The Company’s third-party cellular network carriers accounted for 31% and 38% of total trade receivables as of June 28, 2025 and September 28, 2024, respectively. The Company requires third-party credit support or collateral from certain customers to limit credit risk.

[0000320193-25-000073:notes:32]
[same as prior period, unchanged from 0000320193-25-000057:notes:32]

[0000320193-25-000073:notes:33]
The Company has non-trade receivables from certain of its manufacturing vendors resulting from the sale of components to these vendors who manufacture subassemblies or assemble final products for the Company. The Company purchases these components directly from suppliers. The Company does not reflect the sale of these components in products net sales. Rather, the Company recognizes any gain on these sales as a reduction of products cost of sales when the related final products are sold by the Company. As of June 28, 2025, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 48% and 14%. As of September 28, 2024, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 44% and 23%.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000320193-25-000073:notes:34]
Condensed Consolidated Financial Statement Details
The following tables show the Company’s condensed consolidated financial statement details as of June 28, 2025 and September 28, 2024 (in millions):

[0000320193-25-000073:notes:35]
[same as prior period, unchanged from 0000320193-25-000057:notes:35]

[0000320193-25-000073:notes:36]
|  | June 28,2025 |  | September 28,2024 |
| Components | $ | 2,288 |  |  | $ | 3,627 |  |
| Finished goods | 3,637 |  |  | 3,659 |  |
| Total inventories | $ | 5,925 |  |  | $ | 7,286 |  |

[0000320193-25-000073:notes:37]
[same as prior period, unchanged from 0000320193-25-000057:notes:37]

[0000320193-25-000073:notes:38]
|  | June 28,2025 |  | September 28,2024 |
| Gross property, plant and equipment | $ | 124,311 |  |  | $ | 119,128 |  |
| Accumulated depreciation | (75,803) |  |  | (73,448) |  |
| Total property, plant and equipment, net | $ | 48,508 |  |  | $ | 45,680 |  |


## us-gaap:DebtDisclosureTextBlock

[0000320193-25-000073:notes:39]
Debt
Commercial Paper

[0000320193-25-000073:notes:40]
The Company issues unsecured short-term promissory notes pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of June 28, 2025 and September 28, 2024, the Company had $9.9 billion and $10.0 billion of commercial paper outstanding, respectively. The following table provides a summary of cash flows associated with commercial paper for the nine months ended June 28, 2025 and June 29, 2024 (in millions):

[0000320193-25-000073:notes:41]
|  | Nine Months Ended |
|  | June 28,2025 |  | June 29,2024 |
| Maturities 90 days or less: |  |  |  |
| Repayments of commercial paper, net | $ | (5,690) |  |  | $ | (2,985) |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 5,625 |  |  | — |  |
| Total repayments of commercial paper, net | $ | (65) |  |  | $ | (2,985) |  |

[0000320193-25-000073:notes:42]
Term Debt

[0000320193-25-000073:notes:43]
As of June 28, 2025 and September 28, 2024, the Company had outstanding fixed-rate notes with varying maturities for an aggregate carrying amount of $91.8 billion and $96.7 billion, respectively (collectively the “Notes”). As of June 28, 2025 and September 28, 2024, the fair value of the Company’s Notes, based on Level 2 inputs, was $80.4 billion and $88.4 billion, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000320193-25-000073:notes:44]
[same as prior period, unchanged from 0000320193-25-000057:notes:43]

[0000320193-25-000073:notes:45]
During the nine months ended June 28, 2025, the Company repurchased 312 million shares of its common stock for $69.3 billion. The Company’s share repurchase programs do not obligate the Company to acquire a minimum amount of shares. Under the programs, shares may be repurchased in privately negotiated or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000320193-25-000073:notes:46]
[same as prior period, unchanged from 0000320193-25-000057:notes:45]

[0000320193-25-000073:notes:47]
A summary of the Company’s RSU activity and related information for the nine months ended June 28, 2025, is as follows:

[0000320193-25-000073:notes:48]
|  | Number ofRSUs(in thousands) |  | Weighted-AverageGrant-Date FairValue Per RSU |
| Balance as of September 28, 2024 | 163,326 |  |  | $ | 158.73 |  |
| RSUs granted | 66,667 |  |  | $ | 226.87 |  |
| RSUs vested | (73,515) |  |  | $ | 159.29 |  |
| RSUs canceled | (6,502) |  |  | $ | 180.14 |  |
| Balance as of June 28, 2025 | 149,976 |  |  | $ | 187.82 |  |

[0000320193-25-000073:notes:49]
The total vesting-date fair value of RSUs was $7.0 billion and $16.3 billion for the three- and nine-month periods ended June 28, 2025, respectively, and was $6.4 billion and $15.0 billion for the three- and nine-month periods ended June 29, 2024, respectively.

[0000320193-25-000073:notes:50]
[same as prior period, unchanged from 0000320193-25-000057:notes:49]

[0000320193-25-000073:notes:51]
The following table shows share-based compensation expense and the related income tax benefit included in the Condensed Consolidated Statements of Operations for the three- and nine-month periods ended June 28, 2025 and June 29, 2024 (in millions):

[0000320193-25-000073:notes:52]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 28,2025 |  | June 29,2024 |  | June 28,2025 |  | June 29,2024 |
| Share-based compensation expense | $ | 3,168 |  |  | $ | 2,869 |  |  | $ | 9,680 |  |  | $ | 8,830 |  |
| Income tax benefit related to share-based compensation expense | $ | (795) |  |  | $ | (764) |  |  | $ | (2,870) |  |  | $ | (2,662) |  |

[0000320193-25-000073:notes:53]
As of June 28, 2025, the total unrecognized compensation cost related to outstanding RSUs was $23.7 billion, which the Company expects to recognize over a weighted-average period of 2.6 years.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000320193-25-000073:notes:54]
Segment Information and Geographic Data
The following table shows information by reportable segment for the three- and nine-month periods ended June 28, 2025 and June 29, 2024 (in millions):

[0000320193-25-000073:notes:55]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 28,2025 |  | June 29,2024 |  | June 28,2025 |  | June 29,2024 |
| Americas: |  |  |  |  |  |  |  |
| Net sales | $ | 41,198 |  |  | $ | 37,678 |  |  | $ | 134,161 |  |  | $ | 125,381 |  |
| Operating income | $ | 16,511 |  |  | $ | 15,209 |  |  | $ | 54,794 |  |  | $ | 50,640 |  |
| Europe: |  |  |  |  |  |  |  |
| Net sales | $ | 24,014 |  |  | $ | 21,884 |  |  | $ | 82,329 |  |  | $ | 76,404 |  |
| Operating income | $ | 10,501 |  |  | $ | 9,170 |  |  | $ | 35,424 |  |  | $ | 31,872 |  |
| Greater China: |  |  |  |  |  |  |  |
| Net sales | $ | 15,369 |  |  | $ | 14,728 |  |  | $ | 49,884 |  |  | $ | 51,919 |  |
| Operating income | $ | 5,822 |  |  | $ | 5,562 |  |  | $ | 20,608 |  |  | $ | 20,884 |  |
| Japan: |  |  |  |  |  |  |  |
| Net sales | $ | 5,782 |  |  | $ | 5,097 |  |  | $ | 22,067 |  |  | $ | 19,126 |  |
| Operating income | $ | 2,872 |  |  | $ | 2,544 |  |  | $ | 10,620 |  |  | $ | 9,498 |  |
| Rest of Asia Pacific: |  |  |  |  |  |  |  |
| Net sales | $ | 7,673 |  |  | $ | 6,390 |  |  | $ | 25,254 |  |  | $ | 23,275 |  |
| Operating income | $ | 3,243 |  |  | $ | 2,610 |  |  | $ | 10,813 |  |  | $ | 9,995 |  |

[0000320193-25-000073:notes:56]
A reconciliation of the Company’s segment operating income to the Condensed Consolidated Statements of Operations for the three- and nine-month periods ended June 28, 2025 and June 29, 2024, is as follows (in millions):

[0000320193-25-000073:notes:57]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 28,2025 |  | June 29,2024 |  | June 28,2025 |  | June 29,2024 |
| Segment operating income | $ | 38,949 |  |  | $ | 35,095 |  |  | $ | 132,259 |  |  | $ | 122,889 |  |
| Research and development expense | (8,866) |  |  | (8,006) |  |  | (25,684) |  |  | (23,605) |  |
| Other corporate expenses, net | (1,881) |  |  | (1,737) |  |  | (5,952) |  |  | (5,659) |  |
| Total operating income | $ | 28,202 |  |  | $ | 25,352 |  |  | $ | 100,623 |  |  | $ | 93,625 |  |
