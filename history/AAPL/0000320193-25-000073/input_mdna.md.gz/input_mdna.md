# AAPL MD&A — 0000320193-25-000073


## mdna

[0000320193-25-000073:mdna:1]
[same as prior period, unchanged from 0000320193-25-000057:mdna:1]

[0000320193-25-000073:mdna:2]
[same as prior period, unchanged from 0000320193-25-000057:mdna:2]

[0000320193-25-000073:mdna:3]
[same as prior period, unchanged from 0000320193-25-000057:mdna:3]

[0000320193-25-000073:mdna:4]
[same as prior period, unchanged from 0000320193-25-000057:mdna:4]

[0000320193-25-000073:mdna:5]
[same as prior period, unchanged from 0000320193-25-000057:mdna:5]

[0000320193-25-000073:mdna:6]
[same as prior period, unchanged from 0000320193-25-000057:mdna:6]

[0000320193-25-000073:mdna:7]
[same as prior period, unchanged from 0000320193-25-000057:mdna:7]

[0000320193-25-000073:mdna:8]
During the third quarter of 2025, the Company announced iOS 26, macOS® Tahoe 26, iPadOS® 26, watchOS® 26, visionOS® 26 and tvOS® 26.

[0000320193-25-000073:mdna:9]
[same as prior period, unchanged from 0000320193-25-000057:mdna:14]

[0000320193-25-000073:mdna:10]
[same as prior period, unchanged from 0000320193-25-000057:mdna:15]

[0000320193-25-000073:mdna:11]
Tariffs and Other Measures

[0000320193-25-000073:mdna:12]
Beginning in the second quarter of 2025, new tariffs were announced on imports to the U.S. (“U.S. Tariffs”), including additional tariffs on imports from China, India, Japan, South Korea, Taiwan, Vietnam and the European Union (“EU”), among others. In response, several countries have imposed, or threatened to impose, reciprocal tariffs on imports from the U.S. and other retaliatory measures. Various modifications to the U.S. Tariffs have been announced and further changes could be made in the future, which may include additional sector-based tariffs or other measures. For example, the U.S. Department of Commerce has initiated an investigation under Section 232 of the Trade Expansion Act of 1962, as amended, into, among other things, imports of semiconductors, semiconductor manufacturing equipment, and their derivative products, including downstream products that contain semiconductors. Tariffs and other measures that are applied to the Company’s products or their components can have a material adverse impact on the Company’s business, results of operations and financial condition, including impacting the Company’s supply chain, the availability of rare earths and other raw materials and components, pricing and gross margin. The ultimate impact remains uncertain and will depend on several factors, including whether additional or incremental U.S. Tariffs or other measures are announced or imposed, to what extent other countries implement tariffs or other retaliatory measures in response, and the overall magnitude and duration of these measures. Trade and other international disputes can have an adverse impact on the overall macroeconomic environment and result in shifts and reductions in consumer spending and negative consumer sentiment for the Company’s products and services, all of which can further adversely affect the Company’s business and results of operations.

[0000320193-25-000073:mdna:13]
[same as prior period, unchanged from 0000320193-25-000057:mdna:18]

[0000320193-25-000073:mdna:14]
The following table shows net sales by reportable segment for the three- and nine-month periods ended June 28, 2025 and June 29, 2024 (dollars in millions):

[0000320193-25-000073:mdna:15]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 28,2025 |  | June 29,2024 |  | Change |  | June 28,2025 |  | June 29,2024 |  | Change |
| Americas | $ | 41,198 |  |  | $ | 37,678 |  |  | 9 | % |  | $ | 134,161 |  |  | $ | 125,381 |  |  | 7 | % |
| Europe | 24,014 |  |  | 21,884 |  |  | 10 | % |  | 82,329 |  |  | 76,404 |  |  | 8 | % |
| Greater China | 15,369 |  |  | 14,728 |  |  | 4 | % |  | 49,884 |  |  | 51,919 |  |  | (4) | % |
| Japan | 5,782 |  |  | 5,097 |  |  | 13 | % |  | 22,067 |  |  | 19,126 |  |  | 15 | % |
| Rest of Asia Pacific | 7,673 |  |  | 6,390 |  |  | 20 | % |  | 25,254 |  |  | 23,275 |  |  | 9 | % |
| Total net sales | $ | 94,036 |  |  | $ | 85,777 |  |  | 10 | % |  | $ | 313,695 |  |  | $ | 296,105 |  |  | 6 | % |

[0000320193-25-000073:mdna:16]
[same as prior period, unchanged from 0000320193-25-000057:mdna:21]

[0000320193-25-000073:mdna:17]
Americas net sales increased during the third quarter and first nine months of 2025 compared to the same periods in 2024 due primarily to higher net sales of iPhone and Services. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable year-over-year impact on Americas net sales during the third quarter and first nine months of 2025.

[0000320193-25-000073:mdna:18]
[same as prior period, unchanged from 0000320193-25-000057:mdna:23]

[0000320193-25-000073:mdna:19]
Europe net sales increased during the third quarter and first nine months of 2025 compared to the same periods in 2024 due primarily to higher net sales of Services and iPhone.

[0000320193-25-000073:mdna:20]
[same as prior period, unchanged from 0000320193-25-000057:mdna:25]

[0000320193-25-000073:mdna:21]
Greater China net sales increased during the third quarter of 2025 compared to the third quarter of 2024 due primarily to higher net sales of iPhone and Mac. Greater China net sales decreased during the first nine months of 2025 compared to the same period in 2024 due to lower net sales of iPhone, partially offset by higher net sales of Mac.

[0000320193-25-000073:mdna:22]
[same as prior period, unchanged from 0000320193-25-000057:mdna:27]

[0000320193-25-000073:mdna:23]
Japan net sales increased during the third quarter and first nine months of 2025 compared to the same periods in 2024 due primarily to higher net sales of iPhone and Services. The strength in the yen relative to the U.S. dollar had a favorable year-over-year impact on Japan net sales during the third quarter of 2025.

[0000320193-25-000073:mdna:24]
[same as prior period, unchanged from 0000320193-25-000057:mdna:29]

[0000320193-25-000073:mdna:25]
Rest of Asia Pacific net sales increased during the third quarter and first nine months of 2025 compared to the same periods in 2024 due primarily to higher net sales of Services and iPhone.

[0000320193-25-000073:mdna:26]
[same as prior period, unchanged from 0000320193-25-000057:mdna:31]

[0000320193-25-000073:mdna:27]
The following table shows net sales by category for the three- and nine-month periods ended June 28, 2025 and June 29, 2024 (dollars in millions):

[0000320193-25-000073:mdna:28]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 28,2025 |  | June 29,2024 |  | Change |  | June 28,2025 |  | June 29,2024 |  | Change |
| iPhone | $ | 44,582 |  |  | $ | 39,296 |  |  | 13 | % |  | $ | 160,561 |  |  | $ | 154,961 |  |  | 4 | % |
| Mac | 8,046 |  |  | 7,009 |  |  | 15 | % |  | 24,982 |  |  | 22,240 |  |  | 12 | % |
| iPad | 6,581 |  |  | 7,162 |  |  | (8) | % |  | 21,071 |  |  | 19,744 |  |  | 7 | % |
| Wearables, Home and Accessories | 7,404 |  |  | 8,097 |  |  | (9) | % |  | 26,673 |  |  | 27,963 |  |  | (5) | % |
| Services | 27,423 |  |  | 24,213 |  |  | 13 | % |  | 80,408 |  |  | 71,197 |  |  | 13 | % |
| Total net sales | $ | 94,036 |  |  | $ | 85,777 |  |  | 10 | % |  | $ | 313,695 |  |  | $ | 296,105 |  |  | 6 | % |

[0000320193-25-000073:mdna:29]
[same as prior period, unchanged from 0000320193-25-000057:mdna:34]

[0000320193-25-000073:mdna:30]
iPhone net sales increased during the third quarter and first nine months of 2025 compared to the same periods in 2024 due to higher net sales of Pro models.

[0000320193-25-000073:mdna:31]
[same as prior period, unchanged from 0000320193-25-000057:mdna:36]

[0000320193-25-000073:mdna:32]
Mac net sales increased during the third quarter and first nine months of 2025 compared to the same periods in 2024 due to higher net sales of both laptops and desktops.

[0000320193-25-000073:mdna:33]
[same as prior period, unchanged from 0000320193-25-000057:mdna:38]

[0000320193-25-000073:mdna:34]
iPad net sales decreased during the third quarter of 2025 compared to the third quarter of 2024 due to lower net sales of iPad Pro®, partially offset by higher net sales of all other iPad models. iPad net sales increased during the first nine months of 2025 compared to the same period in 2024 due primarily to higher net sales of iPad Air®.

[0000320193-25-000073:mdna:35]
[same as prior period, unchanged from 0000320193-25-000057:mdna:40]

[0000320193-25-000073:mdna:36]
Wearables, Home and Accessories net sales decreased during the third quarter and first nine months of 2025 compared to the same periods in 2024 due primarily to lower net sales of Wearables and Accessories.

[0000320193-25-000073:mdna:37]
[same as prior period, unchanged from 0000320193-25-000057:mdna:42]

[0000320193-25-000073:mdna:38]
Services net sales increased during the third quarter and first nine months of 2025 compared to the same periods in 2024 due primarily to higher net sales from advertising, the App Store® and cloud services.

[0000320193-25-000073:mdna:39]
[same as prior period, unchanged from 0000320193-25-000057:mdna:44]

[0000320193-25-000073:mdna:40]
Products and Services gross margin and gross margin percentage for the three- and nine-month periods ended June 28, 2025 and June 29, 2024, were as follows (dollars in millions):

[0000320193-25-000073:mdna:41]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 28,2025 |  | June 29,2024 |  | June 28,2025 |  | June 29,2024 |
| Gross margin: |  |  |  |  |  |  |  |
| Products | $ | 22,993 |  |  | $ | 21,761 |  |  | $ | 86,190 |  |  | $ | 84,241 |  |
| Services | 20,725 |  |  | 17,917 |  |  | 60,670 |  |  | 52,563 |  |
| Total gross margin | $ | 43,718 |  |  | $ | 39,678 |  |  | $ | 146,860 |  |  | $ | 136,804 |  |

[0000320193-25-000073:mdna:42]
| Gross margin percentage: |  |  |  |  |  |  |  |
| Products | 34.5 | % |  | 35.3 | % |  | 36.9 | % |  | 37.5 | % |
| Services | 75.6 | % |  | 74.0 | % |  | 75.5 | % |  | 73.8 | % |
| Total gross margin percentage | 46.5 | % |  | 46.3 | % |  | 46.8 | % |  | 46.2 | % |

[0000320193-25-000073:mdna:43]
[same as prior period, unchanged from 0000320193-25-000057:mdna:48]

[0000320193-25-000073:mdna:44]
Products gross margin increased during the third quarter of 2025 compared to the third quarter of 2024 due primarily to a different mix of products and favorable costs, partially offset by tariffs. Products gross margin increased during the first nine months of 2025 compared to the same period in 2024 due primarily to favorable costs and a different mix of products, partially offset by tariffs and the weakness in foreign currencies relative to the U.S. dollar.

[0000320193-25-000073:mdna:45]
Products gross margin percentage decreased during the third quarter of 2025 compared to the third quarter of 2024 due primarily to tariffs and a different mix of products, partially offset by favorable costs. Products gross margin percentage decreased during the first nine months of 2025 compared to the same period in 2024 due primarily to a different mix of products and tariffs, partially offset by favorable costs.

[0000320193-25-000073:mdna:46]
[same as prior period, unchanged from 0000320193-25-000057:mdna:51]

[0000320193-25-000073:mdna:47]
Services gross margin increased during the third quarter and first nine months of 2025 compared to the same periods in 2024 due primarily to higher Services net sales and a different mix of services.

[0000320193-25-000073:mdna:48]
Services gross margin percentage increased during the third quarter and first nine months of 2025 compared to the same periods in 2024 due primarily to a different mix of services, partially offset by higher costs.

[0000320193-25-000073:mdna:49]
[same as prior period, unchanged from 0000320193-25-000057:mdna:54]

[0000320193-25-000073:mdna:50]
[same as prior period, unchanged from 0000320193-25-000057:mdna:55]

[0000320193-25-000073:mdna:51]
Operating expenses for the three- and nine-month periods ended June 28, 2025 and June 29, 2024, were as follows (dollars in millions):

[0000320193-25-000073:mdna:52]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 28,2025 |  | June 29,2024 |  | June 28,2025 |  | June 29,2024 |
| Research and development | $ | 8,866 |  |  | $ | 8,006 |  |  | $ | 25,684 |  |  | $ | 23,605 |  |
| Percentage of total net sales | 9 | % |  | 9 | % |  | 8 | % |  | 8 | % |
| Selling, general and administrative | $ | 6,650 |  |  | $ | 6,320 |  |  | $ | 20,553 |  |  | $ | 19,574 |  |
| Percentage of total net sales | 7 | % |  | 7 | % |  | 7 | % |  | 7 | % |
| Total operating expenses | $ | 15,516 |  |  | $ | 14,326 |  |  | $ | 46,237 |  |  | $ | 43,179 |  |
| Percentage of total net sales | 17 | % |  | 17 | % |  | 15 | % |  | 15 | % |

[0000320193-25-000073:mdna:53]
[same as prior period, unchanged from 0000320193-25-000057:mdna:58]

[0000320193-25-000073:mdna:54]
The growth in research and development (“R&D”) expense during the third quarter and first nine months of 2025 compared to the same periods in 2024 was driven primarily by increases in headcount-related expenses and infrastructure-related costs.

[0000320193-25-000073:mdna:55]
[same as prior period, unchanged from 0000320193-25-000057:mdna:60]

[0000320193-25-000073:mdna:56]
The growth in selling, general and administrative expense during the third quarter and first nine months of 2025 compared to the same periods in 2024 was driven primarily by increases in headcount-related expenses and variable selling expenses.

[0000320193-25-000073:mdna:57]
[same as prior period, unchanged from 0000320193-25-000057:mdna:62]

[0000320193-25-000073:mdna:58]
Provision for income taxes, effective tax rate and statutory federal income tax rate for the three- and nine-month periods ended June 28, 2025 and June 29, 2024, were as follows (dollars in millions):

[0000320193-25-000073:mdna:59]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 28,2025 |  | June 29,2024 |  | June 28,2025 |  | June 29,2024 |
| Provision for income taxes | $ | 4,597 |  |  | $ | 4,046 |  |  | $ | 15,381 |  |  | $ | 14,875 |  |
| Effective tax rate | 16.4 | % |  | 15.9 | % |  | 15.4 | % |  | 15.8 | % |
| Statutory federal income tax rate | 21 | % |  | 21 | % |  | 21 | % |  | 21 | % |

[0000320193-25-000073:mdna:60]
The Company’s effective tax rate for the third quarter of 2025 was lower than the statutory federal income tax rate due primarily to a lower effective tax rate on foreign earnings, the impact of the U.S. federal R&D credit, and tax benefits from share-based compensation, partially offset by state income taxes. The Company’s effective tax rate for the first nine months of 2025 was lower than the statutory federal income tax rate due primarily to a lower effective tax rate on foreign earnings, including the impact of changes in unrecognized tax benefits, tax benefits from share-based compensation, and the impact of the U.S. federal R&D credit, partially offset by state income taxes.

[0000320193-25-000073:mdna:61]
The Company’s effective tax rate for the third quarter of 2025 was higher compared to the third quarter of 2024 due primarily to the impact from foreign currency revaluations of unrecognized tax benefits. The Company’s effective tax rate for the first nine months of 2025 was lower compared to the same period in 2024 due primarily to the impact of changes in unrecognized tax benefits, partially offset by a higher effective tax rate on foreign earnings.

[0000320193-25-000073:mdna:62]
[same as prior period, unchanged from 0000320193-25-000057:mdna:67]

[0000320193-25-000073:mdna:63]
[same as prior period, unchanged from 0000320193-25-000057:mdna:68]

[0000320193-25-000073:mdna:64]
[same as prior period, unchanged from 0000320193-25-000057:mdna:69]

[0000320193-25-000073:mdna:65]
[same as prior period, unchanged from 0000320193-25-000057:mdna:70]

[0000320193-25-000073:mdna:66]
The Company utilizes several outsourcing partners to manufacture subassemblies for the Company’s products and to perform final assembly and testing of finished products. The Company also obtains individual components for its products from a wide variety of individual suppliers. As of June 28, 2025, the Company had manufacturing purchase obligations of $44.1 billion, with $43.8 billion payable within 12 months.

[0000320193-25-000073:mdna:67]
[same as prior period, unchanged from 0000320193-25-000057:mdna:72]

[0000320193-25-000073:mdna:68]
During the first nine months of 2025, the Company released from escrow €14.2 billion, or $15.4 billion, to Ireland in connection with the State Aid Decision, which fully settled the obligation.

[0000320193-25-000073:mdna:69]
[same as prior period, unchanged from 0000320193-25-000057:mdna:74]

[0000320193-25-000073:mdna:70]
In addition to its contractual cash requirements, the Company has authorized share repurchase programs. The programs do not obligate the Company to acquire a minimum amount of shares. As of June 28, 2025, the Company’s quarterly cash dividend was $0.26 per share. The Company intends to increase its dividend on an annual basis, subject to declaration by the Board of Directors.

[0000320193-25-000073:mdna:71]
During the third quarter of 2025, the Company repurchased $21.0 billion of its common stock and paid dividends and dividend equivalents of $3.9 billion.

[0000320193-25-000073:mdna:72]
[same as prior period, unchanged from 0000320193-25-000057:mdna:78]

[0000320193-25-000073:mdna:73]
[same as prior period, unchanged from 0000320193-25-000057:mdna:79]

[0000320193-25-000073:mdna:74]
In November 2024, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) No. 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses (“ASU 2024-03”) and in January 2025, the FASB issued ASU No. 2025-01, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date, which clarified the effective date of ASU 2024-03. ASU 2024-03 will require the Company to disclose the amounts of purchases of inventory, employee compensation, depreciation and intangible asset amortization, as applicable, included in certain expense captions in the Consolidated Statements of Operations, as well as qualitatively describe remaining amounts included in those captions. ASU 2024-03 will also require the Company to disclose both the amount and the Company’s definition of selling expenses. The Company will adopt ASU 2024-03 in its fourth quarter of 2028 using a prospective transition method.

[0000320193-25-000073:mdna:75]
[same as prior period, unchanged from 0000320193-25-000057:mdna:81]

[0000320193-25-000073:mdna:76]
In December 2023, the FASB issued ASU No. 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures (“ASU 2023-09”), which will require the Company to disclose specified additional information in its income tax rate reconciliation and provide additional information for reconciling items that meet a quantitative threshold. ASU 2023-09 will also require the Company to disaggregate its income taxes paid disclosure by federal, state and foreign taxes, with further disaggregation required for significant individual jurisdictions. The Company will adopt ASU 2023-09 in its fourth quarter of 2026 using a prospective transition method.

[0000320193-25-000073:mdna:77]
[same as prior period, unchanged from 0000320193-25-000057:mdna:83]

[0000320193-25-000073:mdna:78]
In November 2023, the FASB issued ASU No. 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures (“ASU 2023-07”), which will require the Company to disclose segment expenses that are significant and regularly provided to the Company’s chief operating decision maker (“CODM”). In addition, ASU 2023-07 will require the Company to disclose the title and position of its CODM and how the CODM uses segment profit or loss information in assessing segment performance and deciding how to allocate resources. The Company will adopt ASU 2023-07 in its fourth quarter of 2025 using a retrospective transition method.

[0000320193-25-000073:mdna:79]
[same as prior period, unchanged from 0000320193-25-000057:mdna:85]

[0000320193-25-000073:mdna:80]
[same as prior period, unchanged from 0000320193-25-000057:mdna:86]
