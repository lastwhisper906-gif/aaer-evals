# AAPL note change history — 0000320193-25-000057 → 0000320193-25-000073


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-08-01):
[0000320193-25-000073:note_history:1]
The Company issues unsecured short-term promissory notes pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of June 28, 2025 and September 28, 2024, the Company had $9.9 billion and $10.0 billion of commercial paper outstanding, respectively. The following table provides a summary of cash flows associated with commercial paper for the nine months ended June 28, 2025 and June 29, 2024 (in millions):
  (was, 2025-05-02, similarity 0.8171):
[0000320193-25-000057:note_history:1]
The Company issues unsecured short-term promissory notes pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of March 29, 2025 and September 28, 2024, the Company had $6.0 billion and $10.0 billion of commercial paper outstanding, respectively.

- added (2025-08-01):
[0000320193-25-000073:note_history:2]
|  | Nine Months Ended |
|  | June 28,2025 |  | June 29,2024 |
| Maturities 90 days or less: |  |  |  |
| Repayments of commercial paper, net | $ | (5,690) |  |  | $ | (2,985) |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 5,625 |  |  | — |  |
| Total repayments of commercial paper, net | $ | (65) |  |  | $ | (2,985) |  |

- changed (2025-08-01):
[0000320193-25-000073:note_history:3]
As of June 28, 2025 and September 28, 2024, the Company had outstanding fixed-rate notes with varying maturities for an aggregate carrying amount of $91.8 billion and $96.7 billion, respectively (collectively the “Notes”). As of June 28, 2025 and September 28, 2024, the fair value of the Company’s Notes, based on Level 2 inputs, was $80.4 billion and $88.4 billion, respectively.
  (was, 2025-05-02, similarity 0.9741):
[0000320193-25-000057:note_history:3]
As of March 29, 2025 and September 28, 2024, the Company had outstanding fixed-rate notes with varying maturities for an aggregate carrying amount of $92.2 billion and $96.7 billion, respectively (collectively the “Notes”). As of March 29, 2025 and September 28, 2024, the fair value of the Company’s Notes, based on Level 2 inputs, was $80.9 billion and $88.4 billion, respectively.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-08-01):
[0000320193-25-000073:note_history:4]
Revenue
The following table shows disaggregated net sales, as well as the portion of total net sales that was previously deferred, for the three- and nine-month periods ended June 28, 2025 and June 29, 2024 (in millions):
  (was, 2025-05-02, similarity 0.8983):
[0000320193-25-000057:note_history:4]
Revenue
The following table shows disaggregated net sales, as well as the portion of total net sales that was previously deferred, for the three- and six-month periods ended March 29, 2025 and March 30, 2024 (in millions):

- changed (2025-08-01):
[0000320193-25-000073:note_history:5]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 28,2025 |  | June 29,2024 |  | June 28,2025 |  | June 29,2024 |
| iPhone® | $ | 44,582 |  |  | $ | 39,296 |  |  | $ | 160,561 |  |  | $ | 154,961 |  |
| Mac® | 8,046 |  |  | 7,009 |  |  | 24,982 |  |  | 22,240 |  |
| iPad® | 6,581 |  |  | 7,162 |  |  | 21,071 |  |  | 19,744 |  |
| Wearables, Home and Accessories | 7,404 |  |  | 8,097 |  |  | 26,673 |  |  | 27,963 |  |
| Services | 27,423 |  |  | 24,213 |  |  | 80,408 |  |  | 71,197 |  |
| Total net sales | $ | 94,036 |  |  | $ | 85,777 |  |  | $ | 313,695 |  |  | $ | 296,105 |  |
| Portion of total net sales that was included in deferred revenue as of the beginning of the period | $ | 4,015 |  |  | $ | 3,405 |  |  | $ | 6,958 |  |  | $ | 6,541 |  |
  (was, 2025-05-02, similarity 0.8873):
[0000320193-25-000057:note_history:5]
|  | Three Months Ended |  | Six Months Ended |
|  | March 29,2025 |  | March 30,2024 |  | March 29,2025 |  | March 30,2024 |
| iPhone® | $ | 46,841 |  |  | $ | 45,963 |  |  | $ | 115,979 |  |  | $ | 115,665 |  |
| Mac® | 7,949 |  |  | 7,451 |  |  | 16,936 |  |  | 15,231 |  |
| iPad® | 6,402 |  |  | 5,559 |  |  | 14,490 |  |  | 12,582 |  |
| Wearables, Home and Accessories | 7,522 |  |  | 7,913 |  |  | 19,269 |  |  | 19,866 |  |
| Services | 26,645 |  |  | 23,867 |  |  | 52,985 |  |  | 46,984 |  |
| Total net sales | $ | 95,359 |  |  | $ | 90,753 |  |  | $ | 219,659 |  |  | $ | 210,328 |  |
| Portion of total net sales that was included in deferred revenue as of the beginning of the period | $ | 3,672 |  |  | $ | 3,282 |  |  | $ | 5,440 |  |  | $ | 5,135 |  |

- changed (2025-08-01):
[0000320193-25-000073:note_history:6]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 10, “Segment Information and Geographic Data” for the three- and nine-month periods ended June 28, 2025 and June 29, 2024, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.
  (was, 2025-05-02, similarity 0.7977):
[0000320193-25-000057:note_history:6]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 10, “Segment Information and Geographic Data” for the three- and six-month periods ended March 29, 2025 and March 30, 2024, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.

- added (2025-08-01):
[0000320193-25-000073:note_history:7]
As of June 28, 2025 and September 28, 2024, the Company had total deferred revenue of $13.6 billion and $12.8 billion, respectively. As of June 28, 2025, the Company expects 66% of total deferred revenue to be realized in less than a year, 23% within one-to-two years, 9% within two-to-three years and 2% in greater than three years.

- removed (2025-08-01):
[0000320193-25-000057:note_history:8]
As of March 29, 2025 and September 28, 2024, the Company had total deferred revenue of $13.6 billion and $12.8 billion, respectively. As of March 29, 2025, the Company expects 66% of total deferred revenue to be realized in less than a year, 24% within one-to-two years, 9% within two-to-three years and 1% in greater than three years.
