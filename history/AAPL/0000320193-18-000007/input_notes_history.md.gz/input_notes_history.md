# AAPL note change history — 0000320193-17-000009 → 0000320193-18-000007


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-02-02):
[0000320193-18-000007:note_history:1]
The following table shows changes in the Company’s accrued warranties and related costs for the three months ended December 30, 2017 and December 31, 2016 (in millions):
  (was, 2017-08-02, similarity 0.8807):
[0000320193-17-000009:note_history:1]
The following table shows changes in the Company’s accrued warranties and related costs for the three- and nine-month periods ended July 1, 2017 and June 25, 2016 (in millions):

- changed (2018-02-02):
[0000320193-18-000007:note_history:2]
|  | Three Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |
| Beginning accrued warranty and related costs | $ | 3,834 |  |  | $ | 3,702 |  |
| Cost of warranty claims | (982 | ) |  | (1,337 | ) |
| Accruals for product warranty | 1,471 |  |  | 2,333 |  |
| Ending accrued warranty and related costs | $ | 4,323 |  |  | $ | 4,698 |  |
  (was, 2017-08-02, similarity 0.7514):
[0000320193-17-000009:note_history:2]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1, 2017 |  | June 25, 2016 |  | July 1, 2017 |  | June 25, 2016 |
| Beginning accrued warranty and related costs | $ | 4,735 |  |  | $ | 4,985 |  |  | $ | 3,702 |  |  | $ | 4,780 |  |
| Cost of warranty claims | (932 | ) |  | (1,110 | ) |  | (3,300 | ) |  | (3,507 | ) |
| Accruals for product warranty | 496 |  |  | 380 |  |  | 3,897 |  |  | 2,982 |  |
| Ending accrued warranty and related costs | $ | 4,299 |  |  | $ | 4,255 |  |  | $ | 4,299 |  |  | $ | 4,255 |  |

- changed (2018-02-02):
[0000320193-18-000007:note_history:3]
The Company offers an iPhone Upgrade Program, which is available to customers who purchase a qualifying iPhone in the U.S., the U.K. and mainland China. The iPhone Upgrade Program provides customers the right to trade in that iPhone for a specified amount when purchasing a new iPhone, provided certain conditions are met. The Company accounts for the trade-in right as a guarantee liability and recognizes arrangement revenue net of the fair value of such right, with subsequent changes to the guarantee liability recognized within revenue.
  (was, 2017-08-02, similarity 0.9991):
[0000320193-17-000009:note_history:3]
The Company offers an iPhone Upgrade Program, which is available to customers who purchase a qualifying iPhone in the U.S., the U.K. and mainland China. The iPhone Upgrade Program provides customers the right to trade in that iPhone for a specified amount when purchasing a new iPhone, provided certain conditions are met. The Company accounts for the trade-in right as a guarantee liability and recognizes arrangement revenue net of the fair value of such right with subsequent changes to the guarantee liability recognized within revenue.

- changed (2018-02-02):
[0000320193-18-000007:note_history:4]
Although most components essential to the Company’s business are generally available from multiple sources, a few components are currently obtained from single or limited sources. In addition, the Company competes for various components with other participants in the markets for mobile communication and media devices and personal computers. Therefore, many components used by the Company, including those that are available from multiple sources, are at times subject to industry-wide shortage and significant pricing fluctuations that could materially adversely affect the Company’s financial condition and operating results.
  (was, 2017-08-02, similarity 0.9905):
[0000320193-17-000009:note_history:4]
Although most components essential to the Company’s business are generally available from multiple sources, a number of components are currently obtained from single or limited sources. In addition, the Company competes for various components with other participants in the markets for mobile communication and media devices and personal computers. Therefore, many components used by the Company, including those that are available from multiple sources, are at times subject to industry-wide shortage and significant pricing fluctuations that could materially adversely affect the Company’s financial condition and operating results.

- added (2018-02-02):
[0000320193-18-000007:note_history:5]
Substantially all of the Company’s hardware products are manufactured by outsourcing partners that are located primarily in Asia, with some Mac computers manufactured in the U.S. and Ireland. A significant concentration of this manufacturing is currently performed by a small number of outsourcing partners, often in single locations. Certain of these outsourcing partners are the sole-sourced suppliers of components and manufacturers for many of the Company’s products. Although the Company works closely with its outsourcing partners on manufacturing schedules, the Company’s operating results could be adversely affected if its outsourcing partners were unable to meet their production commitments. The Company’s manufacturing purchase obligations typically cover its requirements for periods up to 150 days.

- changed (2018-02-02):
[0000320193-18-000007:note_history:6]
The Company leases various equipment and facilities, including retail space, under noncancelable operating lease arrangements. The Company does not currently utilize any other off-balance sheet financing arrangements. As of December 30, 2017, the Company’s total future minimum lease payments under noncancelable operating leases were $9.6 billion. The Company’s retail store and other facility leases typically have original terms not exceeding 10 years and generally contain multi-year renewal options.
  (was, 2017-08-02, similarity 0.9469):
[0000320193-17-000009:note_history:6]
The Company leases various equipment and facilities, including retail space, under noncancelable operating lease arrangements. The Company does not currently utilize any other off-balance sheet financing arrangements. As of July 1, 2017, the Company’s total future minimum lease payments under noncancelable operating leases were $8.5 billion. The Company’s retail store and other facility leases are typically for terms not exceeding 10 years and generally contain multi-year renewal options.

- added (2018-02-02):
[0000320193-18-000007:note_history:7]
Unconditional Purchase Obligations

- added (2018-02-02):
[0000320193-18-000007:note_history:8]
The Company has entered into certain off-balance sheet arrangements which require the future purchase of goods or services (“Unconditional Purchase Obligations”). The Company’s Unconditional Purchase Obligations primarily consist of payments for supplier arrangements, internet and telecommunication services and intellectual property licenses. As of December 30, 2017, the Company’s total future payments under noncancelable Unconditional Purchase Obligations having a remaining term in excess of one year were $8.7 billion.

- changed (2018-02-02):
[0000320193-18-000007:note_history:9]
On August 24, 2012, a jury returned a verdict awarding the Company $1.05 billion in its lawsuit against Samsung Electronics Co., Ltd. and affiliated parties in the United States District Court, Northern District of California, San Jose Division. On March 6, 2014, the District Court entered final judgment in favor of the Company in the amount of approximately $930 million. On May 18, 2015, the U.S. Court of Appeals for the Federal Circuit affirmed in part, and reversed in part, the decision of the District Court. As a result, the Court of Appeals ordered entry of final judgment on damages in the amount of approximately $548 million, with the District Court to determine supplemental damages and interest, as well as damages owed for products subject to the reversal in part. Samsung paid $548 million to the Company in December 2015, which was included in net sales in the Condensed Consolidated Statement of Operations. On December 6, 2016, the U.S. Supreme Court remanded the case to the U.S. Court of Appeals for the Federal Circuit for further proceedings related to the $548 million in damages. On February 7, 2017, the U.S. Court of Appeals for the Federal Circuit remanded the case to the District Court to determine what additional proceedings, if any, are needed. On October 22, 2017, on remand from the U.S. Supreme Court, the District Court ordered a new trial on damages.
  (was, 2017-08-02, similarity 0.9172):
[0000320193-17-000009:note_history:9]
On August 24, 2012, a jury returned a verdict awarding the Company $1.05 billion in its lawsuit against Samsung Electronics Co., Ltd. and affiliated parties in the United States District Court, Northern District of California, San Jose Division. On March 6, 2014, the District Court entered final judgment in favor of the Company in the amount of approximately $930 million. On May 18, 2015, the U.S. Court of Appeals for the Federal Circuit affirmed in part, and reversed in part, the decision of the District Court. As a result, the Court of Appeals ordered entry of final judgment on damages in the amount of approximately $548 million, with the District Court to determine supplemental damages and interest, as well as damages owed for products subject to the reversal in part. Samsung paid $548 million to the Company in December 2015, which was included in net sales in the Condensed Consolidated Statement of Operations. On December 6, 2016, the U.S. Supreme Court remanded the case to the U.S. Court of Appeals for the Federal Circuit for further proceedings related to the $548 million in damages. On February 7, 2017, the U.S. Court of Appeals for the Federal Circuit remanded the case to the District Court to determine what additional proceedings, if any, are needed. Because the case remains subject to further proceedings, the Company has not recognized any further amounts in its results of operations.

- removed (2018-02-02):
[0000320193-17-000009:note_history:10]
Substantially all of the Company’s hardware products are manufactured by outsourcing partners that are located primarily in Asia. A significant concentration of this manufacturing is currently performed by a small number of outsourcing partners, often in single locations. Certain of these outsourcing partners are the sole-sourced suppliers of components and manufacturers for many of the Company’s products. Although the Company works closely with its outsourcing partners on manufacturing schedules, the Company’s operating results could be adversely affected if its outsourcing partners were unable to meet their production commitments. The Company’s manufacturing purchase obligations typically cover its requirements for periods up to 150 days.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-02-02):
[0000320193-18-000007:note_history:11]
Apple Inc. and its wholly-owned subsidiaries (collectively “Apple” or the “Company”) designs, manufactures and markets mobile communication and media devices and personal computers, and sells a variety of related software, services, accessories, networking solutions and third-party digital content and applications. The Company’s products and services include iPhone®, iPad®, Mac®, Apple Watch®, Apple TV®, a portfolio of consumer and professional software applications, iOS, macOS®, watchOS® and tvOS™ operating systems, iCloud®, Apple Pay® and a variety of accessory, service and support offerings. The Company sells and delivers digital content and applications through the iTunes Store®, App Store®, Mac App Store, TV App Store, iBooks Store® and Apple Music® (collectively “Digital Content and Services”). The Company sells its products worldwide through its retail stores, online stores and direct sales force, as well as through third-party cellular network carriers, wholesalers, retailers and resellers. In addition, the Company sells a variety of third-party Apple-compatible products, including application software and various accessories through its retail and online stores. The Company sells to consumers, small and mid-sized businesses and education, enterprise and government customers.
  (was, 2017-08-02, similarity 0.9954):
[0000320193-17-000009:note_history:11]
Apple Inc. and its wholly-owned subsidiaries (collectively “Apple” or the “Company”) designs, manufactures and markets mobile communication and media devices and personal computers, and sells a variety of related software, services, accessories, networking solutions and third-party digital content and applications. The Company’s products and services include iPhone®, iPad®, Mac®, Apple Watch®, Apple TV®, a portfolio of consumer and professional software applications, iOS, macOS®, watchOS® and tvOS™ operating systems, iCloud®, Apple Pay® and a variety of accessory, service and support offerings. The Company sells and delivers digital content and applications through the iTunes Store®, App Store®, Mac App Store, TV App Store, iBooks Store® and Apple Music® (collectively “Digital Content and Services”). The Company sells its products worldwide through its retail stores, online stores and direct sales force, as well as through third-party cellular network carriers, wholesalers, retailers and value-added resellers. In addition, the Company sells a variety of third-party Apple-compatible products, including application software and various accessories through its retail and online stores. The Company sells to consumers, small and mid-sized businesses and education, enterprise and government customers.

- changed (2018-02-02):
[0000320193-18-000007:note_history:12]
The accompanying condensed consolidated financial statements include the accounts of the Company. Intercompany accounts and transactions have been eliminated. In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements in conformity with U.S. generally accepted accounting principles (“GAAP”) requires management to make estimates and assumptions that affect the amounts reported in these condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. Certain prior period amounts in the condensed consolidated financial statements and accompanying notes have been reclassified to conform to the current period’s presentation. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company’s annual consolidated financial statements and the notes thereto included in its Annual Report on Form 10-K for the fiscal year ended September 30, 2017 (the “2017 Form 10-K”).
  (was, 2017-08-02, similarity 0.9903):
[0000320193-17-000009:note_history:12]
The accompanying condensed consolidated financial statements include the accounts of the Company. Intercompany accounts and transactions have been eliminated. In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements in conformity with U.S. generally accepted accounting principles (“GAAP”) requires management to make estimates and assumptions that affect the amounts reported in these condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. Certain prior period amounts in the condensed consolidated financial statements have been reclassified to conform to the current period’s presentation. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company’s annual consolidated financial statements and the notes thereto included in its Annual Report on Form 10-K for the fiscal year ended September 24, 2016 (the “2016 Form 10-K”).

- added (2018-02-02):
[0000320193-18-000007:note_history:13]
The Company’s fiscal year is the 52- or 53-week period that ends on the last Saturday of September. The first quarter of 2018 spanned 13 weeks, whereas a 14th week was added to the first fiscal quarter of 2017, as is done every five or six years, to realign the Company’s fiscal quarters with calendar quarters. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in September and the associated quarters, months and periods of those fiscal years.

- added (2018-02-02):
[0000320193-18-000007:note_history:14]
Share-Based Compensation

- added (2018-02-02):
[0000320193-18-000007:note_history:15]
During the first quarter of 2018, the Company adopted the Financial Accounting Standards Board’s (“FASB”) Accounting Standards Update (“ASU”) No. 2016-09, Compensation – Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting (“ASU 2016-09”), which modified certain aspects of the accounting for share-based payment transactions, including income taxes, classification of awards and classification in the statement of cash flows. Historically, excess tax benefits or deficiencies from the Company’s equity awards were recorded as additional paid-in capital in its Condensed Consolidated Balance Sheets and were classified as a financing activity in its Condensed Consolidated Statements of Cash Flows. As a result of adoption, the Company will prospectively record any excess tax benefits or deficiencies from its equity awards as part of its provision for income taxes in its Condensed Consolidated Statements of Operations in the reporting periods in which equity vesting occurs. The Company elected to apply the cash flow classification requirements related to excess tax benefits retrospectively to all periods presented, which resulted in an increase to cash generated by operating activities in the Condensed Consolidated Statements of Cash Flows of $178 million for the three months ended December 31, 2016.

- added (2018-02-02):
[0000320193-18-000007:note_history:16]
Basic earnings per share is computed by dividing income available to common shareholders by the weighted-average number of shares of common stock outstanding during the period. Diluted earnings per share is computed by dividing income available to common shareholders by the weighted-average number of shares of common stock outstanding during the period increased to include the number of additional shares of common stock that would have been outstanding if the potentially dilutive securities had been issued. Potentially dilutive securities include unvested restricted stock units (“RSUs”), unvested restricted stock, outstanding stock options and shares to be purchased by employees under the Company’s employee stock purchase plan. The dilutive effect of potentially dilutive securities is reflected in diluted earnings per share by application of the treasury stock method. Under the treasury stock method, an increase in the fair market value of the Company’s common stock can result in a greater dilutive effect from potentially dilutive securities.

- changed (2018-02-02):
[0000320193-18-000007:note_history:17]
The following table shows the computation of basic and diluted earnings per share for the three months ended December 30, 2017 and December 31, 2016 (net income in millions and shares in thousands):
  (was, 2017-08-02, similarity 0.8987):
[0000320193-17-000009:note_history:17]
The following table shows the computation of basic and diluted earnings per share for the three- and nine-month periods ended July 1, 2017 and June 25, 2016 (net income in millions and shares in thousands):

- changed (2018-02-02):
[0000320193-18-000007:note_history:18]
|  | Three Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |
| Numerator: |  |  |  |
| Net income | $ | 20,065 |  |  | $ | 17,891 |  |
| Denominator: |  |  |  |
| Weighted-average shares outstanding | 5,112,877 |  |  | 5,298,661 |  |
| Effect of dilutive securities | 44,910 |  |  | 29,334 |  |
| Weighted-average diluted shares | 5,157,787 |  |  | 5,327,995 |  |
| Basic earnings per share | $ | 3.92 |  |  | $ | 3.38 |  |
| Diluted earnings per share | $ | 3.89 |  |  | $ | 3.36 |  |
  (was, 2017-08-02, similarity 0.633):
[0000320193-17-000009:note_history:18]
|  | Three Months Ended |  | Nine Months Ended |
|  | July 1, 2017 |  | June 25, 2016 |  | July 1, 2017 |  | June 25, 2016 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 8,717 |  |  | $ | 7,796 |  |  | $ | 37,637 |  |  | $ | 36,673 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average shares outstanding | 5,195,088 |  |  | 5,443,058 |  |  | 5,239,847 |  |  | 5,505,456 |  |
| Effect of dilutive securities | 38,411 |  |  | 29,723 |  |  | 34,547 |  |  | 30,475 |  |
| Weighted-average diluted shares | 5,233,499 |  |  | 5,472,781 |  |  | 5,274,394 |  |  | 5,535,931 |  |
| Basic earnings per share | $ | 1.68 |  |  | $ | 1.43 |  |  | $ | 7.18 |  |  | $ | 6.66 |  |
| Diluted earnings per share | $ | 1.67 |  |  | $ | 1.42 |  |  | $ | 7.14 |  |  | $ | 6.62 |  |

- removed (2018-02-02):
[0000320193-17-000009:note_history:19]
The Company’s fiscal year is the 52 or 53-week period that ends on the last Saturday of September. The Company’s fiscal year 2017 will include 53 weeks and ends on September 30, 2017 and its fiscal year 2016 included 52 weeks and ended on September 24, 2016. A 14th week was included in the first quarter of 2017, as is done every five or six years, to realign fiscal quarters with calendar quarters. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in September and the associated quarters, months and periods of those fiscal years.

- removed (2018-02-02):
[0000320193-17-000009:note_history:20]
Basic earnings per share is computed by dividing income available to common shareholders by the weighted-average number of shares of common stock outstanding during the period. Diluted earnings per share is computed by dividing income available to common shareholders by the weighted-average number of shares of common stock outstanding during the period increased to include the number of additional shares of common stock that would have been outstanding if the potentially dilutive securities had been issued. Potentially dilutive securities include outstanding stock options, shares to be purchased by employees under the Company’s employee stock purchase plan, unvested restricted stock and unvested restricted stock units (“RSUs”). The dilutive effect of potentially dilutive securities is reflected in diluted earnings per share by application of the treasury stock method. Under the treasury stock method, an increase in the fair market value of the Company’s common stock can result in a greater dilutive effect from potentially dilutive securities.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2018-02-02):
[0000320193-18-000007:note_history:21]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of both December 30, 2017 and September 30, 2017, the Company had $12.0 billion of Commercial Paper outstanding with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 1.33% as of December 30, 2017 and 1.20% as of September 30, 2017.

- changed (2018-02-02):
[0000320193-18-000007:note_history:22]
The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the three months ended December 30, 2017 and December 31, 2016 (in millions):
  (was, 2017-08-02, similarity 0.921):
[0000320193-17-000009:note_history:22]
The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the nine months ended July 1, 2017 and June 25, 2016 (in millions):

- added (2018-02-02):
[0000320193-18-000007:note_history:23]
|  | Three Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |
| Maturities less than 90 days: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | 1,621 |  |  | $ | 1,550 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 3,441 |  |  | 2,544 |  |
| Repayments of commercial paper | (5,060 | ) |  | (1,709 | ) |
| Proceeds from/(Repayments of) commercial paper, net | (1,619 | ) |  | 835 |  |
| Total change in commercial paper, net | $ | 2 |  |  | $ | 2,385 |  |

- changed (2018-02-02):
[0000320193-18-000007:note_history:24]
As of December 30, 2017, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $111.0 billion (collectively the “Notes”). The Notes are senior unsecured obligations, and interest is payable in arrears, quarterly for the U.S. dollar-denominated and Australian dollar-denominated floating-rate notes, semi-annually for the U.S. dollar-denominated, Australian dollar-denominated, British pound-denominated, Japanese yen-denominated and Canadian dollar-denominated fixed-rate notes and annually for the euro-denominated and Swiss franc-denominated fixed-rate notes. The following table provides a summary of the Company’s term debt as of December 30, 2017 and September 30, 2017:
  (was, 2017-08-02, similarity 0.7587):
[0000320193-17-000009:note_history:24]
As of July 1, 2017, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $96.6 billion (collectively the “Notes”). The Notes are senior unsecured obligations, and interest is payable in arrears, quarterly for the U.S. dollar-denominated and Australian dollar-denominated floating-rate notes, semi-annually for the U.S. dollar-denominated, Australian dollar-denominated, British pound-denominated and Japanese yen-denominated fixed-rate notes and annually for the euro-denominated and Swiss franc-denominated fixed-rate notes. The following table provides a summary of the Company’s term debt as of July 1, 2017 and September 24, 2016:

- changed (2018-02-02):
[0000320193-18-000007:note_history:25]
|  | Maturities |  | December 30, 2017 |  | September 30, 2017 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2018 |  | 2018 |  | $ | 2,000 |  |  |  | 1.10% |  | 1.10 | % |  | $ | 2,000 |  |  |  | 1.10% |  | 1.10 | % |
| Fixed-rate 1.000% – 3.850% notes | 2018 | – | 2043 |  | 12,500 |  |  |  | 1.08% | – | 3.91 | % |  | 12,500 |  |  |  | 1.08% | – | 3.91 | % |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 |  | 2019 |  | 1,000 |  |  |  | 1.69% |  | 1.69 | % |  | 1,000 |  |  |  | 1.61% |  | 1.61 | % |
| Fixed-rate 2.100% – 4.450% notes | 2019 | – | 2044 |  | 8,500 |  |  |  | 1.69% | – | 4.48 | % |  | 8,500 |  |  |  | 1.61% | – | 4.48 | % |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2020 |  | 1,544 |  |  |  | 1.65% | – | 1.87 | % |  | 1,549 |  |  |  | 1.56% | – | 1.87 | % |
| Fixed-rate 0.350% – 4.375% notes | 2019 | – | 2045 |  | 24,555 |  |  |  | 0.28% | – | 4.51 | % |  | 24,522 |  |  |  | 0.28% | – | 4.51 | % |
| 2016 debt issuances of $24.9 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2021 |  | 1,350 |  |  |  | 1.53% | – | 2.59 | % |  | 1,350 |  |  |  | 1.45% | – | 2.44 | % |
| Fixed-rate 1.100% – 4.650% notes | 2018 | – | 2046 |  | 23,635 |  |  |  | 1.13% | – | 4.78 | % |  | 23,645 |  |  |  | 1.13% | – | 4.78 | % |
| 2017 debt issuances of $28.7 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2022 |  | 3,250 |  |  |  | 1.48% | – | 1.90 | % |  | 3,250 |  |  |  | 1.38% | – | 1.81 | % |
| Fixed-rate 0.875% – 4.300% notes | 2019 | – | 2047 |  | 25,699 |  |  |  | 1.54% | – | 4.30 | % |  | 25,705 |  |  |  | 1.51% | – | 4.30 | % |
| First quarter 2018 debt issuance of $7.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 1.800% notes |  |  | 2019 |  | 1,000 |  |  |  |  |  | 1.83 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.000% notes |  |  | 2020 |  | 1,000 |  |  |  |  |  | 2.03 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.400% notes |  |  | 2023 |  | 750 |  |  |  |  |  | 1.93 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.750% notes |  |  | 2025 |  | 1,500 |  |  |  |  |  | 2.77 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.000% notes |  |  | 2027 |  | 1,500 |  |  |  |  |  | 2.13 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.750% notes |  |  | 2047 |  | 1,250 |  |  |  |  |  | 3.80 | % |  | — |  |  |  |  |  | — | % |
| Total term debt |  |  |  |  | 111,033 |  |  |  |  |  |  |  | 104,021 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (246 | ) |  |  |  |  |  |  | (225 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | (367 | ) |  |  |  |  |  |  | (93 | ) |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  |  |  | (6,498 | ) |  |  |  |  |  |  | (6,496 | ) |  |  |  |  |  |
| Total long-term debt |  |  |  |  | $ | 103,922 |  |  |  |  |  |  |  | $ | 97,207 |  |  |  |  |  |  |
  (was, 2017-08-02, similarity 0.7376):
[0000320193-17-000009:note_history:25]
|  | Maturities |  | July 1, 2017 |  | September 24, 2016 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2018 |  | 2018 |  | $ | 2,000 |  |  |  | 1.10% |  | 1.10 | % |  | $ | 2,000 |  |  |  | 1.10% |  | 1.10 | % |
| Fixed-rate 1.000% – 3.850% notes | 2018 | – | 2043 |  | 12,500 |  |  |  | 1.08% | – | 3.91 | % |  | 12,500 |  |  |  | 1.08% | – | 3.91 | % |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2019 |  | 1,000 |  |  |  | 1.48% |  | 1.48 | % |  | 2,000 |  |  |  | 0.86% | – | 1.09 | % |
| Fixed-rate 2.100% – 4.450% notes | 2019 | – | 2044 |  | 8,500 |  |  |  | 1.48% | – | 4.48 | % |  | 10,000 |  |  |  | 0.85% | – | 4.48 | % |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2020 |  | 1,532 |  |  |  | 1.43% | – | 1.87 | % |  | 1,781 |  |  |  | 0.87% | – | 1.87 | % |
| Fixed-rate 0.350% – 4.375% notes | 2019 | – | 2045 |  | 24,259 |  |  |  | 0.28% | – | 4.51 | % |  | 25,144 |  |  |  | 0.28% | – | 4.51 | % |
| 2016 debt issuances of $24.9 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2021 |  | 1,350 |  |  |  | 1.31% | – | 2.32 | % |  | 1,350 |  |  |  | 0.91% | – | 1.95 | % |
| Fixed-rate 1.100% – 4.650% notes | 2018 | – | 2046 |  | 23,610 |  |  |  | 1.13% | – | 4.78 | % |  | 23,609 |  |  |  | 1.13% | – | 4.58 | % |
| Second quarter 2017 debt issuance of $10.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2019 |  | 500 |  |  |  |  |  | 1.26 | % |  | — |  |  |  |  |  | — | % |
| Floating-rate notes |  |  | 2020 |  | 500 |  |  |  |  |  | 1.38 | % |  | — |  |  |  |  |  | — | % |
| Floating-rate notes |  |  | 2022 |  | 1,000 |  |  |  |  |  | 1.68 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 1.550% notes |  |  | 2019 |  | 500 |  |  |  |  |  | 1.59 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 1.900% notes |  |  | 2020 |  | 1,000 |  |  |  |  |  | 1.38 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.500% notes |  |  | 2022 |  | 1,500 |  |  |  |  |  | 1.67 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.000% notes |  |  | 2024 |  | 1,750 |  |  |  |  |  | 1.98 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.350% notes |  |  | 2027 |  | 2,250 |  |  |  |  |  | 2.12 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 4.250% notes |  |  | 2047 |  | 1,000 |  |  |  |  |  | 4.26 | % |  | — |  |  |  |  |  | — | % |
| Second quarter 2017 debt issuance of $1.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 4.300% notes |  |  | 2047 |  | 1,000 |  |  |  |  |  | 4.30 | % |  | — |  |  |  |  |  | — | % |
| Third quarter 2017 debt issuance of $7.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2020 |  | 500 |  |  |  |  |  | 1.25 | % |  | — |  |  |  |  |  | — | % |
| Floating-rate notes |  |  | 2022 |  | 750 |  |  |  |  |  | 1.53 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 1.800% notes |  |  | 2020 |  | 1,000 |  |  |  |  |  | 1.84 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.300% notes |  |  | 2022 |  | 1,000 |  |  |  |  |  | 2.34 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.850% notes |  |  | 2024 |  | 1,750 |  |  |  |  |  | 2.16 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.200% notes |  |  | 2027 |  | 2,000 |  |  |  |  |  | 2.34 | % |  | — |  |  |  |  |  | — | % |
| Third quarter 2017 euro-denominated debt issuance of €2.5 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.875% notes |  |  | 2025 |  | 1,419 |  |  |  |  |  | 3.03 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 1.375% notes |  |  | 2029 |  | 1,419 |  |  |  |  |  | 3.37 | % |  | — |  |  |  |  |  | — | % |
| Third quarter 2017 debt issuance of $1.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 3.000% notes |  |  | 2027 |  | 1,000 |  |  |  |  |  | 3.03 | % |  | — |  |  |  |  |  | — | % |
| Total term debt |  |  |  |  | 96,589 |  |  |  |  |  |  |  | 78,384 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (210 | ) |  |  |  |  |  |  | (174 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | (20 | ) |  |  |  |  |  |  | 717 |  |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  |  |  | (6,495 | ) |  |  |  |  |  |  | (3,500 | ) |  |  |  |  |  |
| Total long-term debt |  |  |  |  | $ | 89,864 |  |  |  |  |  |  |  | $ | 75,427 |  |  |  |  |  |  |

- added (2018-02-02):
[0000320193-18-000007:note_history:26]
To manage interest rate risk on certain of its U.S. dollar-denominated fixed- or floating-rate notes, the Company has entered into interest rate swaps to effectively convert the fixed interest rates to floating interest rates or the floating interest rates to fixed interest rates on a portion of these notes. Additionally, to manage foreign currency risk on certain of its foreign currency-denominated notes, the Company has entered into foreign currency swaps to effectively convert these notes to U.S. dollar-denominated notes.

- changed (2018-02-02):
[0000320193-18-000007:note_history:27]
A portion of the Company’s Japanese yen-denominated notes is designated as a hedge of the foreign currency exposure of the Company’s net investment in a foreign operation. As of December 30, 2017 and September 30, 2017, the carrying value of the debt designated as a net investment hedge was $1.4 billion and $1.6 billion, respectively. For further discussion regarding the Company’s use of derivative instruments see the Derivative Financial Instruments section of Note 2, “Financial Instruments.”
  (was, 2017-08-02, similarity 0.8257):
[0000320193-17-000009:note_history:27]
A portion of the Company’s Japanese yen-denominated notes is designated as a hedge of the foreign currency exposure of the Company’s net investment in a foreign operation. The foreign currency transaction gain or loss on the Japanese yen-denominated debt designated as a hedge is recorded in OCI as a part of the cumulative translation adjustment. As of July 1, 2017 and September 24, 2016, the carrying value of the debt designated as a net investment hedge was $1.5 billion and $1.9 billion, respectively. For further discussion regarding the Company’s use of derivative instruments see the Derivative Financial Instruments section of Note 2, “Financial Instruments.”

- changed (2018-02-02):
[0000320193-18-000007:note_history:28]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $695 million and $509 million of interest expense on its term debt for the three months ended December 30, 2017 and December 31, 2016, respectively.
  (was, 2017-08-02, similarity 0.7141):
[0000320193-17-000009:note_history:28]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $574 million and $1.6 billion of interest expense on its term debt for the three- and nine-month periods ended July 1, 2017, respectively. The Company recognized $393 million and $975 million of interest expense on its term debt for the three- and nine-month periods ended June 25, 2016, respectively.

- changed (2018-02-02):
[0000320193-18-000007:note_history:29]
As of December 30, 2017 and September 30, 2017, the fair value of the Company’s Notes, based on Level 2 inputs, was $113.5 billion and $106.1 billion, respectively.
  (was, 2017-08-02, similarity 0.958):
[0000320193-17-000009:note_history:29]
As of July 1, 2017 and September 24, 2016, the fair value of the Company’s Notes, based on Level 2 inputs, was $98.3 billion and $81.7 billion, respectively.

- removed (2018-02-02):
[0000320193-17-000009:note_history:30]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of July 1, 2017 and September 24, 2016, the Company had $12.0 billion and $8.1 billion of Commercial Paper outstanding, respectively, with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 1.01% as of July 1, 2017 and 0.45% as of September 24, 2016.

- removed (2018-02-02):
[0000320193-17-000009:note_history:31]
|  | Nine Months Ended |
|  | July 1, 2017 |  | June 25, 2016 |
| Maturities less than 90 days: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | (143 | ) |  | $ | 4,154 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 12,633 |  |  | 1,846 |  |
| Repayments of commercial paper | (8,624 | ) |  | (2,008 | ) |
| Proceeds from/(Repayments of) commercial paper, net | 4,009 |  |  | (162 | ) |
| Total change in commercial paper, net | $ | 3,866 |  |  | $ | 3,992 |  |

- removed (2018-02-02):
[0000320193-17-000009:note_history:32]
To manage interest rate risk on certain of its fixed-rate notes issued during the third quarter of 2017 and maturing in 2024 and 2027, the Company entered into interest rate swaps with an aggregate notional amount of $2.75 billion, which effectively converted the fixed interest rates on a portion of these notes to floating interest rates. The Company also hedged its entire third quarter 2017 issuance of €2.5 billion of euro-denominated notes by entering into foreign currency swaps to effectively convert these notes to U.S. dollar-denominated notes.

- removed (2018-02-02):
[0000320193-17-000009:note_history:33]
To manage interest rate risk on certain of its fixed-rate notes issued during the second quarter of 2017 and maturing in 2020, 2022, 2024 and 2027, the Company entered into interest rate swaps with an aggregate notional amount of $6.5 billion, which effectively converted the fixed interest rates on these notes to floating interest rates.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-02-02):
[0000320193-18-000007:note_history:34]
The following table provides a summary of the Company’s term debt as of December 30, 2017 and September 30, 2017:
  (was, 2017-08-02, similarity 0.9406):
[0000320193-17-000009:note_history:34]
The following table provides a summary of the Company’s term debt as of July 1, 2017 and September 24, 2016:

- changed (2018-02-02):
[0000320193-18-000007:note_history:35]
|  | Maturities |  | December 30, 2017 |  | September 30, 2017 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2018 |  | 2018 |  | $ | 2,000 |  |  |  | 1.10% |  | 1.10 | % |  | $ | 2,000 |  |  |  | 1.10% |  | 1.10 | % |
| Fixed-rate 1.000% – 3.850% notes | 2018 | – | 2043 |  | 12,500 |  |  |  | 1.08% | – | 3.91 | % |  | 12,500 |  |  |  | 1.08% | – | 3.91 | % |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 |  | 2019 |  | 1,000 |  |  |  | 1.69% |  | 1.69 | % |  | 1,000 |  |  |  | 1.61% |  | 1.61 | % |
| Fixed-rate 2.100% – 4.450% notes | 2019 | – | 2044 |  | 8,500 |  |  |  | 1.69% | – | 4.48 | % |  | 8,500 |  |  |  | 1.61% | – | 4.48 | % |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2020 |  | 1,544 |  |  |  | 1.65% | – | 1.87 | % |  | 1,549 |  |  |  | 1.56% | – | 1.87 | % |
| Fixed-rate 0.350% – 4.375% notes | 2019 | – | 2045 |  | 24,555 |  |  |  | 0.28% | – | 4.51 | % |  | 24,522 |  |  |  | 0.28% | – | 4.51 | % |
| 2016 debt issuances of $24.9 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2021 |  | 1,350 |  |  |  | 1.53% | – | 2.59 | % |  | 1,350 |  |  |  | 1.45% | – | 2.44 | % |
| Fixed-rate 1.100% – 4.650% notes | 2018 | – | 2046 |  | 23,635 |  |  |  | 1.13% | – | 4.78 | % |  | 23,645 |  |  |  | 1.13% | – | 4.78 | % |
| 2017 debt issuances of $28.7 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2022 |  | 3,250 |  |  |  | 1.48% | – | 1.90 | % |  | 3,250 |  |  |  | 1.38% | – | 1.81 | % |
| Fixed-rate 0.875% – 4.300% notes | 2019 | – | 2047 |  | 25,699 |  |  |  | 1.54% | – | 4.30 | % |  | 25,705 |  |  |  | 1.51% | – | 4.30 | % |
| First quarter 2018 debt issuance of $7.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 1.800% notes |  |  | 2019 |  | 1,000 |  |  |  |  |  | 1.83 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.000% notes |  |  | 2020 |  | 1,000 |  |  |  |  |  | 2.03 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.400% notes |  |  | 2023 |  | 750 |  |  |  |  |  | 1.93 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.750% notes |  |  | 2025 |  | 1,500 |  |  |  |  |  | 2.77 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.000% notes |  |  | 2027 |  | 1,500 |  |  |  |  |  | 2.13 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.750% notes |  |  | 2047 |  | 1,250 |  |  |  |  |  | 3.80 | % |  | — |  |  |  |  |  | — | % |
| Total term debt |  |  |  |  | 111,033 |  |  |  |  |  |  |  | 104,021 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (246 | ) |  |  |  |  |  |  | (225 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | (367 | ) |  |  |  |  |  |  | (93 | ) |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  |  |  | (6,498 | ) |  |  |  |  |  |  | (6,496 | ) |  |  |  |  |  |
| Total long-term debt |  |  |  |  | $ | 103,922 |  |  |  |  |  |  |  | $ | 97,207 |  |  |  |  |  |  |
  (was, 2017-08-02, similarity 0.7376):
[0000320193-17-000009:note_history:35]
|  | Maturities |  | July 1, 2017 |  | September 24, 2016 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2018 |  | 2018 |  | $ | 2,000 |  |  |  | 1.10% |  | 1.10 | % |  | $ | 2,000 |  |  |  | 1.10% |  | 1.10 | % |
| Fixed-rate 1.000% – 3.850% notes | 2018 | – | 2043 |  | 12,500 |  |  |  | 1.08% | – | 3.91 | % |  | 12,500 |  |  |  | 1.08% | – | 3.91 | % |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2019 |  | 1,000 |  |  |  | 1.48% |  | 1.48 | % |  | 2,000 |  |  |  | 0.86% | – | 1.09 | % |
| Fixed-rate 2.100% – 4.450% notes | 2019 | – | 2044 |  | 8,500 |  |  |  | 1.48% | – | 4.48 | % |  | 10,000 |  |  |  | 0.85% | – | 4.48 | % |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2020 |  | 1,532 |  |  |  | 1.43% | – | 1.87 | % |  | 1,781 |  |  |  | 0.87% | – | 1.87 | % |
| Fixed-rate 0.350% – 4.375% notes | 2019 | – | 2045 |  | 24,259 |  |  |  | 0.28% | – | 4.51 | % |  | 25,144 |  |  |  | 0.28% | – | 4.51 | % |
| 2016 debt issuances of $24.9 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2021 |  | 1,350 |  |  |  | 1.31% | – | 2.32 | % |  | 1,350 |  |  |  | 0.91% | – | 1.95 | % |
| Fixed-rate 1.100% – 4.650% notes | 2018 | – | 2046 |  | 23,610 |  |  |  | 1.13% | – | 4.78 | % |  | 23,609 |  |  |  | 1.13% | – | 4.58 | % |
| Second quarter 2017 debt issuance of $10.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2019 |  | 500 |  |  |  |  |  | 1.26 | % |  | — |  |  |  |  |  | — | % |
| Floating-rate notes |  |  | 2020 |  | 500 |  |  |  |  |  | 1.38 | % |  | — |  |  |  |  |  | — | % |
| Floating-rate notes |  |  | 2022 |  | 1,000 |  |  |  |  |  | 1.68 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 1.550% notes |  |  | 2019 |  | 500 |  |  |  |  |  | 1.59 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 1.900% notes |  |  | 2020 |  | 1,000 |  |  |  |  |  | 1.38 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.500% notes |  |  | 2022 |  | 1,500 |  |  |  |  |  | 1.67 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.000% notes |  |  | 2024 |  | 1,750 |  |  |  |  |  | 1.98 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.350% notes |  |  | 2027 |  | 2,250 |  |  |  |  |  | 2.12 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 4.250% notes |  |  | 2047 |  | 1,000 |  |  |  |  |  | 4.26 | % |  | — |  |  |  |  |  | — | % |
| Second quarter 2017 debt issuance of $1.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 4.300% notes |  |  | 2047 |  | 1,000 |  |  |  |  |  | 4.30 | % |  | — |  |  |  |  |  | — | % |
| Third quarter 2017 debt issuance of $7.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2020 |  | 500 |  |  |  |  |  | 1.25 | % |  | — |  |  |  |  |  | — | % |
| Floating-rate notes |  |  | 2022 |  | 750 |  |  |  |  |  | 1.53 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 1.800% notes |  |  | 2020 |  | 1,000 |  |  |  |  |  | 1.84 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.300% notes |  |  | 2022 |  | 1,000 |  |  |  |  |  | 2.34 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.850% notes |  |  | 2024 |  | 1,750 |  |  |  |  |  | 2.16 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.200% notes |  |  | 2027 |  | 2,000 |  |  |  |  |  | 2.34 | % |  | — |  |  |  |  |  | — | % |
| Third quarter 2017 euro-denominated debt issuance of €2.5 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.875% notes |  |  | 2025 |  | 1,419 |  |  |  |  |  | 3.03 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 1.375% notes |  |  | 2029 |  | 1,419 |  |  |  |  |  | 3.37 | % |  | — |  |  |  |  |  | — | % |
| Third quarter 2017 debt issuance of $1.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 3.000% notes |  |  | 2027 |  | 1,000 |  |  |  |  |  | 3.03 | % |  | — |  |  |  |  |  | — | % |
| Total term debt |  |  |  |  | 96,589 |  |  |  |  |  |  |  | 78,384 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (210 | ) |  |  |  |  |  |  | (174 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | (20 | ) |  |  |  |  |  |  | 717 |  |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  |  |  | (6,495 | ) |  |  |  |  |  |  | (3,500 | ) |  |  |  |  |  |
| Total long-term debt |  |  |  |  | $ | 89,864 |  |  |  |  |  |  |  | $ | 75,427 |  |  |  |  |  |  |
