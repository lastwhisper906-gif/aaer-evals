# AAPL notes — 0000320193-18-000007


## aapl:CashCashEquivalentsandAvailableforSaleSecuritiesTableTextBlock

[0000320193-18-000007:notes:1]
The following tables show the Company’s cash and available-for-sale securities by significant investment category as of December 30, 2017 and September 30, 2017 (in millions):

[0000320193-18-000007:notes:2]
|  | December 30, 2017 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | Short-TermMarketableSecurities |  | Long-TermMarketableSecurities |
| Cash | $ | 9,529 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,529 |  |  | $ | 9,529 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 8,570 |  |  | — |  |  | — |  |  | 8,570 |  |  | 8,570 |  |  | — |  |  | — |  |
| Mutual funds | 800 |  |  | — |  |  | (92 | ) |  | 708 |  |  | — |  |  | 708 |  |  | — |  |
| Subtotal | 9,370 |  |  | — |  |  | (92 | ) |  | 9,278 |  |  | 8,570 |  |  | 708 |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 60,329 |  |  | 4 |  |  | (502 | ) |  | 59,831 |  |  | 2,268 |  |  | 13,661 |  |  | 43,902 |  |
| U.S. agency securities | 5,384 |  |  | — |  |  | (22 | ) |  | 5,362 |  |  | 1,376 |  |  | 1,980 |  |  | 2,006 |  |
| Non-U.S. government securities | 8,651 |  |  | 206 |  |  | (60 | ) |  | 8,797 |  |  | — |  |  | 223 |  |  | 8,574 |  |
| Certificates of deposit and time deposits | 6,307 |  |  | — |  |  | — |  |  | 6,307 |  |  | 2,237 |  |  | 3,064 |  |  | 1,006 |  |
| Commercial paper | 5,384 |  |  | — |  |  | — |  |  | 5,384 |  |  | 3,186 |  |  | 2,198 |  |  | — |  |
| Corporate securities | 157,043 |  |  | 506 |  |  | (681 | ) |  | 156,868 |  |  | 325 |  |  | 27,252 |  |  | 129,291 |  |
| Municipal securities | 971 |  |  | — |  |  | (8 | ) |  | 963 |  |  | — |  |  | 110 |  |  | 853 |  |
| Mortgage- and asset-backed securities | 23,052 |  |  | 17 |  |  | (291 | ) |  | 22,778 |  |  | — |  |  | 466 |  |  | 22,312 |  |
| Subtotal | 267,121 |  |  | 733 |  |  | (1,564 | ) |  | 266,290 |  |  | 9,392 |  |  | 48,954 |  |  | 207,944 |  |
| Total | $ | 286,020 |  |  | $ | 733 |  |  | $ | (1,656 | ) |  | $ | 285,097 |  |  | $ | 27,491 |  |  | $ | 49,662 |  |  | $ | 207,944 |  |

[0000320193-18-000007:notes:3]
|  | September 30, 2017 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | Short-TermMarketableSecurities |  | Long-TermMarketableSecurities |
| Cash | $ | 7,982 |  |  | $ | — |  |  | $ | — |  |  | $ | 7,982 |  |  | $ | 7,982 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 6,534 |  |  | — |  |  | — |  |  | 6,534 |  |  | 6,534 |  |  | — |  |  | — |  |
| Mutual funds | 799 |  |  | — |  |  | (88 | ) |  | 711 |  |  | — |  |  | 711 |  |  | — |  |
| Subtotal | 7,333 |  |  | — |  |  | (88 | ) |  | 7,245 |  |  | 6,534 |  |  | 711 |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 55,254 |  |  | 58 |  |  | (230 | ) |  | 55,082 |  |  | 865 |  |  | 17,228 |  |  | 36,989 |  |
| U.S. agency securities | 5,162 |  |  | 2 |  |  | (9 | ) |  | 5,155 |  |  | 1,439 |  |  | 2,057 |  |  | 1,659 |  |
| Non-U.S. government securities | 7,827 |  |  | 210 |  |  | (37 | ) |  | 8,000 |  |  | 9 |  |  | 123 |  |  | 7,868 |  |
| Certificates of deposit and time deposits | 5,832 |  |  | — |  |  | — |  |  | 5,832 |  |  | 1,142 |  |  | 3,918 |  |  | 772 |  |
| Commercial paper | 3,640 |  |  | — |  |  | — |  |  | 3,640 |  |  | 2,146 |  |  | 1,494 |  |  | — |  |
| Corporate securities | 152,724 |  |  | 969 |  |  | (242 | ) |  | 153,451 |  |  | 172 |  |  | 27,591 |  |  | 125,688 |  |
| Municipal securities | 961 |  |  | 4 |  |  | (1 | ) |  | 964 |  |  | — |  |  | 114 |  |  | 850 |  |
| Mortgage- and asset-backed securities | 21,684 |  |  | 35 |  |  | (175 | ) |  | 21,544 |  |  | — |  |  | 656 |  |  | 20,888 |  |
| Subtotal | 253,084 |  |  | 1,278 |  |  | (694 | ) |  | 253,668 |  |  | 5,773 |  |  | 53,181 |  |  | 194,714 |  |
| Total | $ | 268,399 |  |  | $ | 1,278 |  |  | $ | (782 | ) |  | $ | 268,895 |  |  | $ | 20,289 |  |  | $ | 53,892 |  |  | $ | 194,714 |  |

[0000320193-18-000007:notes:4]
[same as prior period, unchanged from 0000320193-17-000009:notes:4]

[0000320193-18-000007:notes:5]
[same as prior period, unchanged from 0000320193-17-000009:notes:5]


## aapl:CommercialPaperCashFlowSummaryTableTextBlock

[0000320193-18-000007:notes:6]
The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the three months ended December 30, 2017 and December 31, 2016 (in millions):

[0000320193-18-000007:notes:7]
|  | Three Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |
| Maturities less than 90 days: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | 1,621 |  |  | $ | 1,550 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 3,441 |  |  | 2,544 |  |
| Repayments of commercial paper | (5,060 | ) |  | (1,709 | ) |
| Proceeds from/(Repayments of) commercial paper, net | (1,619 | ) |  | 835 |  |
| Total change in commercial paper, net | $ | 2 |  |  | $ | 2,385 |  |


## aapl:NotionalAndCreditRiskAmountsOfOutstandingDerivativePositionsDisclosureTextBlock

[0000320193-18-000007:notes:8]
The following table shows the notional amounts of the Company’s outstanding derivative instruments and credit risk amounts associated with outstanding or unsettled derivative instruments as of December 30, 2017 and September 30, 2017 (in millions):

[0000320193-18-000007:notes:9]
|  | December 30, 2017 |  | September 30, 2017 |
|  | NotionalAmount |  | Credit RiskAmount |  | NotionalAmount |  | Credit RiskAmount |
| Instruments designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 48,337 |  |  | $ | 985 |  |  | $ | 56,156 |  |  | $ | 1,049 |  |
| Interest rate contracts | $ | 35,250 |  |  | $ | 100 |  |  | $ | 33,000 |  |  | $ | 218 |  |
| Instruments not designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 77,059 |  |  | $ | 284 |  |  | $ | 69,774 |  |  | $ | 363 |  |


## aapl:ScheduleOfCommonStockRepurchasedTableTextBlock

[0000320193-18-000007:notes:10]
[same as prior period, unchanged from 0000320193-17-000009:notes:10]

[0000320193-18-000007:notes:11]
|  | Number of Shares(in thousands) |  | Average Repurchase Price Per Share |  | Amount(in millions) |
| 2018: |  |  |  |  |  |
| First quarter | 30,181 |  |  | $ | 169.26 |  |  | $ | 5,109 |  |
| 2017: |  |  |  |  |  |
| Fourth quarter | 29,073 |  |  | $ | 154.78 |  |  | $ | 4,500 |  |
| Third quarter | 30,356 |  |  | $ | 148.24 |  |  | 4,500 |  |
| Second quarter | 31,070 |  |  | $ | 128.74 |  |  | 4,001 |  |
| First quarter | 44,333 |  |  | $ | 112.78 |  |  | 5,000 |  |
| Total open market common stock repurchases | 134,832 |  |  |  |  | $ | 18,001 |  |


## us-gaap:AcceleratedShareRepurchasesTextBlock

[0000320193-18-000007:notes:12]
The following table shows the Company’s ASR activity and related information during the three months ended December 30, 2017 and the year ended September 30, 2017:

[0000320193-18-000007:notes:13]
|  | Purchase PeriodEnd Date |  | Number of Shares(in thousands) |  | Average RepurchasePrice Per Share |  | ASR Amount(in millions) |
| November 2017 ASR | February 2018 |  | 23,602 |  | (1) | (1) |  |  | $ | 5,000 |  |
| August 2017 ASR | November 2017 |  | 18,887 |  | (2) | $ | 158.84 |  |  | $ | 3,000 |  |
| May 2017 ASR | August 2017 |  | 20,108 |  |  | $ | 149.20 |  |  | $ | 3,000 |  |
| February 2017 ASR | May 2017 |  | 20,949 |  |  | $ | 143.20 |  |  | $ | 3,000 |  |
| November 2016 ASR | February 2017 |  | 51,157 |  |  | $ | 117.29 |  |  | $ | 6,000 |  |
| August 2016 ASR | November 2016 |  | 26,850 |  |  | $ | 111.73 |  |  | $ | 3,000 |  |

[0000320193-18-000007:notes:14]
| (1) | “Number of Shares” represents those shares delivered at the beginning of the purchase period and does not represent the final number of shares to be delivered under the ASR. The total number of shares ultimately delivered, and therefore the average repurchase price paid per share, will be determined at the end of the purchase period based on the volume-weighted average price of the Company’s common stock during that period. The November 2017 ASR purchase period will end in February 2018. |

[0000320193-18-000007:notes:15]
| (2) | Includes 15.1 million shares delivered and retired at the beginning of the purchase period, which began in the fourth quarter of 2017, and 3.8 million shares delivered and retired at the end of the purchase period, which concluded in the first quarter of 2018. |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000320193-18-000007:notes:16]
[same as prior period, unchanged from 0000320193-17-000009:notes:16]

[0000320193-18-000007:notes:17]
The following tables show the Company’s condensed consolidated financial statement details as of December 30, 2017 and September 30, 2017 (in millions):

[0000320193-18-000007:notes:18]
[same as prior period, unchanged from 0000320193-17-000009:notes:18]

[0000320193-18-000007:notes:19]
|  | December 30, 2017 |  | September 30, 2017 |
| Land and buildings | $ | 14,189 |  |  | $ | 13,587 |  |
| Machinery, equipment and internal-use software | 55,479 |  |  | 54,210 |  |
| Leasehold improvements | 7,442 |  |  | 7,279 |  |
| Gross property, plant and equipment | 77,110 |  |  | 75,076 |  |
| Accumulated depreciation and amortization | (43,431 | ) |  | (41,293 | ) |
| Total property, plant and equipment, net | $ | 33,679 |  |  | $ | 33,783 |  |

[0000320193-18-000007:notes:20]
[same as prior period, unchanged from 0000320193-17-000009:notes:20]

[0000320193-18-000007:notes:21]
|  | December 30, 2017 |  | September 30, 2017 |
| Long-term taxes payable | $ | 34,913 |  |  | $ | 257 |  |
| Deferred tax liabilities | 548 |  |  | 31,504 |  |
| Other non-current liabilities | 8,293 |  |  | 8,654 |  |
| Total other non-current liabilities | $ | 43,754 |  |  | $ | 40,415 |  |

[0000320193-18-000007:notes:22]
[same as prior period, unchanged from 0000320193-17-000009:notes:22]

[0000320193-18-000007:notes:23]
The following table shows the detail of other income/(expense), net for the three months ended December 30, 2017 and December 31, 2016 (in millions):

[0000320193-18-000007:notes:24]
|  | Three Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |
| Interest and dividend income | $ | 1,452 |  |  | $ | 1,224 |  |
| Interest expense | (734 | ) |  | (525 | ) |
| Other income, net | 38 |  |  | 122 |  |
| Total other income/(expense), net | $ | 756 |  |  | $ | 821 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000320193-18-000007:notes:25]
[same as prior period, unchanged from 0000320193-17-000009:notes:25]

[0000320193-18-000007:notes:26]
The accompanying condensed consolidated financial statements include the accounts of the Company. Intercompany accounts and transactions have been eliminated. In the opinion of the Company’s management, the condensed consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these condensed consolidated financial statements in conformity with U.S. generally accepted accounting principles (“GAAP”) requires management to make estimates and assumptions that affect the amounts reported in these condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. Certain prior period amounts in the condensed consolidated financial statements and accompanying notes have been reclassified to conform to the current period’s presentation. These condensed consolidated financial statements and accompanying notes should be read in conjunction with the Company’s annual consolidated financial statements and the notes thereto included in its Annual Report on Form 10-K for the fiscal year ended September 30, 2017 (the “2017 Form 10-K”).


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000320193-18-000007:notes:27]
[same as prior period, unchanged from 0000320193-17-000009:notes:27]

[0000320193-18-000007:notes:28]
Apple Inc. and its wholly-owned subsidiaries (collectively “Apple” or the “Company”) designs, manufactures and markets mobile communication and media devices and personal computers, and sells a variety of related software, services, accessories, networking solutions and third-party digital content and applications. The Company’s products and services include iPhone®, iPad®, Mac®, Apple Watch®, Apple TV®, a portfolio of consumer and professional software applications, iOS, macOS®, watchOS® and tvOS™ operating systems, iCloud®, Apple Pay® and a variety of accessory, service and support offerings. The Company sells and delivers digital content and applications through the iTunes Store®, App Store®, Mac App Store, TV App Store, iBooks Store® and Apple Music® (collectively “Digital Content and Services”). The Company sells its products worldwide through its retail stores, online stores and direct sales force, as well as through third-party cellular network carriers, wholesalers, retailers and resellers. In addition, the Company sells a variety of third-party Apple-compatible products, including application software and various accessories through its retail and online stores. The Company sells to consumers, small and mid-sized businesses and education, enterprise and government customers.

[0000320193-18-000007:notes:29]
The Company’s fiscal year is the 52- or 53-week period that ends on the last Saturday of September. The first quarter of 2018 spanned 13 weeks, whereas a 14th week was added to the first fiscal quarter of 2017, as is done every five or six years, to realign the Company’s fiscal quarters with calendar quarters. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in September and the associated quarters, months and periods of those fiscal years.

[0000320193-18-000007:notes:30]
Share-Based Compensation

[0000320193-18-000007:notes:31]
During the first quarter of 2018, the Company adopted the Financial Accounting Standards Board’s (“FASB”) Accounting Standards Update (“ASU”) No. 2016-09, Compensation – Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting (“ASU 2016-09”), which modified certain aspects of the accounting for share-based payment transactions, including income taxes, classification of awards and classification in the statement of cash flows. Historically, excess tax benefits or deficiencies from the Company’s equity awards were recorded as additional paid-in capital in its Condensed Consolidated Balance Sheets and were classified as a financing activity in its Condensed Consolidated Statements of Cash Flows. As a result of adoption, the Company will prospectively record any excess tax benefits or deficiencies from its equity awards as part of its provision for income taxes in its Condensed Consolidated Statements of Operations in the reporting periods in which equity vesting occurs. The Company elected to apply the cash flow classification requirements related to excess tax benefits retrospectively to all periods presented, which resulted in an increase to cash generated by operating activities in the Condensed Consolidated Statements of Cash Flows of $178 million for the three months ended December 31, 2016.

[0000320193-18-000007:notes:32]
[same as prior period, unchanged from 0000320193-17-000009:notes:30]

[0000320193-18-000007:notes:33]
Basic earnings per share is computed by dividing income available to common shareholders by the weighted-average number of shares of common stock outstanding during the period. Diluted earnings per share is computed by dividing income available to common shareholders by the weighted-average number of shares of common stock outstanding during the period increased to include the number of additional shares of common stock that would have been outstanding if the potentially dilutive securities had been issued. Potentially dilutive securities include unvested restricted stock units (“RSUs”), unvested restricted stock, outstanding stock options and shares to be purchased by employees under the Company’s employee stock purchase plan. The dilutive effect of potentially dilutive securities is reflected in diluted earnings per share by application of the treasury stock method. Under the treasury stock method, an increase in the fair market value of the Company’s common stock can result in a greater dilutive effect from potentially dilutive securities.

[0000320193-18-000007:notes:34]
The following table shows the computation of basic and diluted earnings per share for the three months ended December 30, 2017 and December 31, 2016 (net income in millions and shares in thousands):

[0000320193-18-000007:notes:35]
|  | Three Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |
| Numerator: |  |  |  |
| Net income | $ | 20,065 |  |  | $ | 17,891 |  |
| Denominator: |  |  |  |
| Weighted-average shares outstanding | 5,112,877 |  |  | 5,298,661 |  |
| Effect of dilutive securities | 44,910 |  |  | 29,334 |  |
| Weighted-average diluted shares | 5,157,787 |  |  | 5,327,995 |  |
| Basic earnings per share | $ | 3.92 |  |  | $ | 3.38 |  |
| Diluted earnings per share | $ | 3.89 |  |  | $ | 3.36 |  |

[0000320193-18-000007:notes:36]
[same as prior period, unchanged from 0000320193-17-000009:notes:34]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000320193-18-000007:notes:37]
Commitments and Contingencies

[0000320193-18-000007:notes:38]
Accrued Warranty and Indemnification

[0000320193-18-000007:notes:39]
The following table shows changes in the Company’s accrued warranties and related costs for the three months ended December 30, 2017 and December 31, 2016 (in millions):

[0000320193-18-000007:notes:40]
|  | Three Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |
| Beginning accrued warranty and related costs | $ | 3,834 |  |  | $ | 3,702 |  |
| Cost of warranty claims | (982 | ) |  | (1,337 | ) |
| Accruals for product warranty | 1,471 |  |  | 2,333 |  |
| Ending accrued warranty and related costs | $ | 4,323 |  |  | $ | 4,698 |  |

[0000320193-18-000007:notes:41]
Agreements entered into by the Company sometimes include indemnification provisions which may subject the Company to costs and damages in the event of a claim against an indemnified third party. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to indemnification of third parties.

[0000320193-18-000007:notes:42]
The Company offers an iPhone Upgrade Program, which is available to customers who purchase a qualifying iPhone in the U.S., the U.K. and mainland China. The iPhone Upgrade Program provides customers the right to trade in that iPhone for a specified amount when purchasing a new iPhone, provided certain conditions are met. The Company accounts for the trade-in right as a guarantee liability and recognizes arrangement revenue net of the fair value of such right, with subsequent changes to the guarantee liability recognized within revenue.

[0000320193-18-000007:notes:43]
The Company has entered into indemnification agreements with its directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers of the Company and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. While the Company maintains directors and officers liability insurance coverage, such insurance coverage may be insufficient to cover all losses or all types of claims that may arise.

[0000320193-18-000007:notes:44]
Concentrations in the Available Sources of Supply of Materials and Product

[0000320193-18-000007:notes:45]
Although most components essential to the Company’s business are generally available from multiple sources, a few components are currently obtained from single or limited sources. In addition, the Company competes for various components with other participants in the markets for mobile communication and media devices and personal computers. Therefore, many components used by the Company, including those that are available from multiple sources, are at times subject to industry-wide shortage and significant pricing fluctuations that could materially adversely affect the Company’s financial condition and operating results.

[0000320193-18-000007:notes:46]
The Company uses some custom components that are not commonly used by its competitors, and new products introduced by the Company often utilize custom components available from only one source. When a component or product uses new technologies, initial capacity constraints may exist until the suppliers’ yields have matured or manufacturing capacity has increased. If the Company’s supply of components for a new or existing product were delayed or constrained, or if an outsourcing partner delayed shipments of completed products to the Company, the Company’s financial condition and operating results could be materially adversely affected. The Company’s business and financial performance could also be materially adversely affected depending on the time required to obtain sufficient quantities from the original source, or to identify and obtain sufficient quantities from an alternative source. Continued availability of these components at acceptable prices, or at all, may be affected if those suppliers decide to concentrate on the production of common components instead of components customized to meet the Company’s requirements.

[0000320193-18-000007:notes:47]
The Company has entered into agreements for the supply of many components; however, there can be no guarantee that the Company will be able to extend or renew these agreements on similar terms, or at all. Therefore, the Company remains subject to significant risks of supply shortages and price increases that could materially adversely affect its financial condition and operating results.

[0000320193-18-000007:notes:48]
Substantially all of the Company’s hardware products are manufactured by outsourcing partners that are located primarily in Asia, with some Mac computers manufactured in the U.S. and Ireland. A significant concentration of this manufacturing is currently performed by a small number of outsourcing partners, often in single locations. Certain of these outsourcing partners are the sole-sourced suppliers of components and manufacturers for many of the Company’s products. Although the Company works closely with its outsourcing partners on manufacturing schedules, the Company’s operating results could be adversely affected if its outsourcing partners were unable to meet their production commitments. The Company’s manufacturing purchase obligations typically cover its requirements for periods up to 150 days.

[0000320193-18-000007:notes:49]
Other Off-Balance Sheet Commitments

[0000320193-18-000007:notes:50]
Operating Leases

[0000320193-18-000007:notes:51]
The Company leases various equipment and facilities, including retail space, under noncancelable operating lease arrangements. The Company does not currently utilize any other off-balance sheet financing arrangements. As of December 30, 2017, the Company’s total future minimum lease payments under noncancelable operating leases were $9.6 billion. The Company’s retail store and other facility leases typically have original terms not exceeding 10 years and generally contain multi-year renewal options.

[0000320193-18-000007:notes:52]
Unconditional Purchase Obligations

[0000320193-18-000007:notes:53]
The Company has entered into certain off-balance sheet arrangements which require the future purchase of goods or services (“Unconditional Purchase Obligations”). The Company’s Unconditional Purchase Obligations primarily consist of payments for supplier arrangements, internet and telecommunication services and intellectual property licenses. As of December 30, 2017, the Company’s total future payments under noncancelable Unconditional Purchase Obligations having a remaining term in excess of one year were $8.7 billion.

[0000320193-18-000007:notes:54]
Contingencies

[0000320193-18-000007:notes:55]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully adjudicated, as further discussed in Part II, Item 1 of this Form 10-Q under the heading “Legal Proceedings” and in Part II, Item 1A of this Form 10-Q under the heading “Risk Factors.” In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to loss contingencies for asserted legal and other claims. However, the outcome of litigation is inherently uncertain. Therefore, although management considers the likelihood of such an outcome to be remote, if one or more of these legal matters were resolved against the Company in a reporting period for amounts in excess of management’s expectations, the Company’s consolidated financial statements for that reporting period could be materially adversely affected.

[0000320193-18-000007:notes:56]
Apple Inc. v. Samsung Electronics Co., Ltd., et al.

[0000320193-18-000007:notes:57]
On August 24, 2012, a jury returned a verdict awarding the Company $1.05 billion in its lawsuit against Samsung Electronics Co., Ltd. and affiliated parties in the United States District Court, Northern District of California, San Jose Division. On March 6, 2014, the District Court entered final judgment in favor of the Company in the amount of approximately $930 million. On May 18, 2015, the U.S. Court of Appeals for the Federal Circuit affirmed in part, and reversed in part, the decision of the District Court. As a result, the Court of Appeals ordered entry of final judgment on damages in the amount of approximately $548 million, with the District Court to determine supplemental damages and interest, as well as damages owed for products subject to the reversal in part. Samsung paid $548 million to the Company in December 2015, which was included in net sales in the Condensed Consolidated Statement of Operations. On December 6, 2016, the U.S. Supreme Court remanded the case to the U.S. Court of Appeals for the Federal Circuit for further proceedings related to the $548 million in damages. On February 7, 2017, the U.S. Court of Appeals for the Federal Circuit remanded the case to the District Court to determine what additional proceedings, if any, are needed. On October 22, 2017, on remand from the U.S. Supreme Court, the District Court ordered a new trial on damages.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000320193-18-000007:notes:58]
[same as prior period, unchanged from 0000320193-17-000009:notes:54]

[0000320193-18-000007:notes:59]
[same as prior period, unchanged from 0000320193-17-000009:notes:55]

[0000320193-18-000007:notes:60]
The Company had 273.4 million shares reserved for future issuance under its stock plans as of December 30, 2017. RSUs granted generally vest over four years, based on continued employment, and are settled upon vesting in shares of the Company’s common stock on a one-for-one basis. Each share issued with respect to RSUs granted under the Company’s stock plans reduces the number of shares available for grant under the plan by two shares. RSUs canceled and shares withheld to satisfy tax withholding obligations increase the number of shares available for grant under the plans utilizing a factor of two times the number of RSUs canceled or shares withheld.

[0000320193-18-000007:notes:61]
[same as prior period, unchanged from 0000320193-17-000009:notes:57]

[0000320193-18-000007:notes:62]
During the three months ended December 30, 2017, Section 16 officers Angela Ahrendts, Timothy D. Cook, Luca Maestri, Daniel Riccio and Philip Schiller had equity trading plans in place in accordance with Rule 10b5-1(c)(1) under the Exchange Act. An equity trading plan is a written document that pre-establishes the amounts, prices and dates (or formula for determining the amounts, prices and dates) of future purchases or sales of the Company’s stock, including shares acquired pursuant to the Company’s employee and director equity plans.

[0000320193-18-000007:notes:63]
[same as prior period, unchanged from 0000320193-17-000009:notes:59]

[0000320193-18-000007:notes:64]
A summary of the Company’s RSU activity and related information for the three months ended December 30, 2017 is as follows:

[0000320193-18-000007:notes:65]
|  | Number ofRSUs(in thousands) |  | Weighted-AverageGrant Date FairValue Per Share |  | AggregateFair Value(in millions) |
| Balance as of September 30, 2017 | 97,571 |  |  | $ | 110.33 |  |  |  |
| RSUs granted | 35,853 |  |  | $ | 157.49 |  |  |  |
| RSUs vested | (19,741 | ) |  | $ | 102.40 |  |  |  |
| RSUs canceled | (1,316 | ) |  | $ | 121.76 |  |  |  |
| Balance as of December 30, 2017 | 112,367 |  |  | $ | 126.64 |  |  | $ | 19,016 |  |

[0000320193-18-000007:notes:66]
The fair value as of the respective vesting dates of RSUs was $3.1 billion and $2.2 billion for the three months ended December 30, 2017 and December 31, 2016, respectively.

[0000320193-18-000007:notes:67]
The following table shows a summary of the share-based compensation expense included in the Condensed Consolidated Statements of Operations for the three months ended December 30, 2017 and December 31, 2016 (in millions):

[0000320193-18-000007:notes:68]
|  | Three Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |
| Cost of sales | $ | 252 |  |  | $ | 229 |  |
| Research and development | 646 |  |  | 589 |  |
| Selling, general and administrative | 398 |  |  | 438 |  |
| Total share-based compensation expense | $ | 1,296 |  |  | $ | 1,256 |  |

[0000320193-18-000007:notes:69]
The income tax benefit related to share-based compensation expense was $631 million and $465 million for the three months ended December 30, 2017 and December 31, 2016, respectively. As of December 30, 2017, the total unrecognized compensation cost related to outstanding RSUs, restricted stock and stock options was $12.1 billion, which the Company expects to recognize over a weighted-average period of 2.9 years.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000320193-18-000007:notes:70]
[same as prior period, unchanged from 0000320193-17-000009:notes:67]

[0000320193-18-000007:notes:71]
[same as prior period, unchanged from 0000320193-17-000009:notes:68]

[0000320193-18-000007:notes:72]
The following table shows the pre-tax amounts reclassified from AOCI into the Condensed Consolidated Statements of Operations, and the associated financial statement line item, for the three months ended December 30, 2017 and December 31, 2016 (in millions):

[0000320193-18-000007:notes:73]
|  |  |  |  | Three Months Ended |
| Comprehensive Income Components |  | Financial Statement Line Item |  | December 30, 2017 |  | December 31, 2016 |
| Unrealized (gains)/losses on derivative instruments: |  |  |  |  |  |  |
| Foreign exchange contracts |  | Net sales |  | $ | 184 |  |  | $ | (101 | ) |
|  |  | Cost of sales |  | (27 | ) |  | 13 |  |
|  |  | Other income/(expense), net |  | (33 | ) |  | 604 |  |
| Interest rate contracts |  | Other income/(expense), net |  | (1 | ) |  | 1 |  |
|  |  |  |  | 123 |  |  | 517 |  |
| Unrealized (gains)/losses on marketable securities |  | Other income/(expense), net |  | (116 | ) |  | 31 |  |
| Total amounts reclassified from AOCI |  | $ | 7 |  |  | $ | 548 |  |

[0000320193-18-000007:notes:74]
The following table shows the changes in AOCI by component for the three months ended December 30, 2017 (in millions):

[0000320193-18-000007:notes:75]
|  | Cumulative ForeignCurrency Translation |  | Unrealized Gains/Losseson Derivative Instruments |  | Unrealized Gains/Losseson Marketable Securities |  | Total |
| Balances as of September 30, 2017 | $ | (354 | ) |  | $ | (124 | ) |  | $ | 328 |  |  | $ | (150 | ) |
| Other comprehensive income/(loss) before reclassifications | 41 |  |  | 154 |  |  | (1,310 | ) |  | (1,115 | ) |
| Amounts reclassified from AOCI | — |  |  | 123 |  |  | (116 | ) |  | 7 |  |
| Tax effect | (1 | ) |  | (87 | ) |  | 505 |  |  | 417 |  |
| Other comprehensive income/(loss) | 40 |  |  | 190 |  |  | (921 | ) |  | (691 | ) |
| Balances as of December 30, 2017 | $ | (314 | ) |  | $ | 66 |  |  | $ | (593 | ) |  | $ | (841 | ) |


## us-gaap:DebtDisclosureTextBlock

[0000320193-18-000007:notes:76]
Debt

[0000320193-18-000007:notes:77]
Commercial Paper

[0000320193-18-000007:notes:78]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of both December 30, 2017 and September 30, 2017, the Company had $12.0 billion of Commercial Paper outstanding with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 1.33% as of December 30, 2017 and 1.20% as of September 30, 2017.

[0000320193-18-000007:notes:79]
Term Debt

[0000320193-18-000007:notes:80]
As of December 30, 2017, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $111.0 billion (collectively the “Notes”). The Notes are senior unsecured obligations, and interest is payable in arrears, quarterly for the U.S. dollar-denominated and Australian dollar-denominated floating-rate notes, semi-annually for the U.S. dollar-denominated, Australian dollar-denominated, British pound-denominated, Japanese yen-denominated and Canadian dollar-denominated fixed-rate notes and annually for the euro-denominated and Swiss franc-denominated fixed-rate notes. The following table provides a summary of the Company’s term debt as of December 30, 2017 and September 30, 2017:

[0000320193-18-000007:notes:81]
|  | Maturities |  | December 30, 2017 |  | September 30, 2017 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2018 |  | 2018 |  | $ | 2,000 |  |  |  | 1.10% |  | 1.10 | % |  | $ | 2,000 |  |  |  | 1.10% |  | 1.10 | % |
| Fixed-rate 1.000% – 3.850% notes | 2018 | – | 2043 |  | 12,500 |  |  |  | 1.08% | – | 3.91 | % |  | 12,500 |  |  |  | 1.08% | – | 3.91 | % |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 |  | 2019 |  | 1,000 |  |  |  | 1.69% |  | 1.69 | % |  | 1,000 |  |  |  | 1.61% |  | 1.61 | % |
| Fixed-rate 2.100% – 4.450% notes | 2019 | – | 2044 |  | 8,500 |  |  |  | 1.69% | – | 4.48 | % |  | 8,500 |  |  |  | 1.61% | – | 4.48 | % |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2020 |  | 1,544 |  |  |  | 1.65% | – | 1.87 | % |  | 1,549 |  |  |  | 1.56% | – | 1.87 | % |
| Fixed-rate 0.350% – 4.375% notes | 2019 | – | 2045 |  | 24,555 |  |  |  | 0.28% | – | 4.51 | % |  | 24,522 |  |  |  | 0.28% | – | 4.51 | % |
| 2016 debt issuances of $24.9 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2021 |  | 1,350 |  |  |  | 1.53% | – | 2.59 | % |  | 1,350 |  |  |  | 1.45% | – | 2.44 | % |
| Fixed-rate 1.100% – 4.650% notes | 2018 | – | 2046 |  | 23,635 |  |  |  | 1.13% | – | 4.78 | % |  | 23,645 |  |  |  | 1.13% | – | 4.78 | % |
| 2017 debt issuances of $28.7 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2022 |  | 3,250 |  |  |  | 1.48% | – | 1.90 | % |  | 3,250 |  |  |  | 1.38% | – | 1.81 | % |
| Fixed-rate 0.875% – 4.300% notes | 2019 | – | 2047 |  | 25,699 |  |  |  | 1.54% | – | 4.30 | % |  | 25,705 |  |  |  | 1.51% | – | 4.30 | % |
| First quarter 2018 debt issuance of $7.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 1.800% notes |  |  | 2019 |  | 1,000 |  |  |  |  |  | 1.83 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.000% notes |  |  | 2020 |  | 1,000 |  |  |  |  |  | 2.03 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.400% notes |  |  | 2023 |  | 750 |  |  |  |  |  | 1.93 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.750% notes |  |  | 2025 |  | 1,500 |  |  |  |  |  | 2.77 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.000% notes |  |  | 2027 |  | 1,500 |  |  |  |  |  | 2.13 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.750% notes |  |  | 2047 |  | 1,250 |  |  |  |  |  | 3.80 | % |  | — |  |  |  |  |  | — | % |
| Total term debt |  |  |  |  | 111,033 |  |  |  |  |  |  |  | 104,021 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (246 | ) |  |  |  |  |  |  | (225 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | (367 | ) |  |  |  |  |  |  | (93 | ) |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  |  |  | (6,498 | ) |  |  |  |  |  |  | (6,496 | ) |  |  |  |  |  |
| Total long-term debt |  |  |  |  | $ | 103,922 |  |  |  |  |  |  |  | $ | 97,207 |  |  |  |  |  |  |

[0000320193-18-000007:notes:82]
To manage interest rate risk on certain of its U.S. dollar-denominated fixed- or floating-rate notes, the Company has entered into interest rate swaps to effectively convert the fixed interest rates to floating interest rates or the floating interest rates to fixed interest rates on a portion of these notes. Additionally, to manage foreign currency risk on certain of its foreign currency-denominated notes, the Company has entered into foreign currency swaps to effectively convert these notes to U.S. dollar-denominated notes.

[0000320193-18-000007:notes:83]
A portion of the Company’s Japanese yen-denominated notes is designated as a hedge of the foreign currency exposure of the Company’s net investment in a foreign operation. As of December 30, 2017 and September 30, 2017, the carrying value of the debt designated as a net investment hedge was $1.4 billion and $1.6 billion, respectively. For further discussion regarding the Company’s use of derivative instruments see the Derivative Financial Instruments section of Note 2, “Financial Instruments.”

[0000320193-18-000007:notes:84]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $695 million and $509 million of interest expense on its term debt for the three months ended December 30, 2017 and December 31, 2016, respectively.

[0000320193-18-000007:notes:85]
As of December 30, 2017 and September 30, 2017, the fair value of the Company’s Notes, based on Level 2 inputs, was $113.5 billion and $106.1 billion, respectively.


## us-gaap:DerivativesPolicyTextBlock

[0000320193-18-000007:notes:86]
[same as prior period, unchanged from 0000320193-17-000009:notes:99]

[0000320193-18-000007:notes:87]
[same as prior period, unchanged from 0000320193-17-000009:notes:84]

[0000320193-18-000007:notes:88]
[same as prior period, unchanged from 0000320193-17-000009:notes:85]

[0000320193-18-000007:notes:89]
[same as prior period, unchanged from 0000320193-17-000009:notes:86]

[0000320193-18-000007:notes:90]
[same as prior period, unchanged from 0000320193-17-000009:notes:87]

[0000320193-18-000007:notes:91]
[same as prior period, unchanged from 0000320193-17-000009:notes:88]

[0000320193-18-000007:notes:92]
The Company may enter into interest rate swaps, options or other instruments to manage interest rate risk. These instruments may offset a portion of changes in income or expense, or changes in fair value of the Company’s term debt or investments. The Company designates these instruments as either cash flow or fair value hedges. The Company’s hedged interest rate transactions as of December 30, 2017 are expected to be recognized within 10 years.

[0000320193-18-000007:notes:93]
The Company may enter into foreign currency swaps to manage currency risk on its foreign currency-denominated term debt. These instruments may offset a portion of the foreign currency remeasurement gains or losses on the Company’s term debt and related interest payments. The Company designates these instruments as cash flow hedges. The Company’s hedged term debt-related foreign currency transactions as of December 30, 2017 are expected to be recognized within 25 years.

[0000320193-18-000007:notes:94]
[same as prior period, unchanged from 0000320193-17-000009:notes:90]

[0000320193-18-000007:notes:95]
The effective portions of cash flow hedges are recorded in accumulated other comprehensive income/(loss) (“AOCI”) until the hedged item is recognized in earnings. Deferred gains and losses associated with cash flow hedges of foreign currency revenue are recognized as a component of net sales in the same period as the related revenue is recognized, and deferred gains and losses related to cash flow hedges of inventory purchases are recognized as a component of cost of sales in the same period as the related costs are recognized. Deferred gains and losses associated with cash flow hedges of interest income or expense are recognized in other income/(expense), net in the same period as the related income or expense is recognized. The ineffective portions and amounts excluded from the effectiveness testing of cash flow hedges are recognized in other income/(expense), net.

[0000320193-18-000007:notes:96]
Derivative instruments designated as cash flow hedges must be de-designated as hedges when it is probable the forecasted hedged transaction will not occur in the initially identified time period or within a subsequent two-month time period. Deferred gains and losses in AOCI associated with such derivative instruments are reclassified into other income/(expense), net in the period of de-designation. Any subsequent changes in fair value of such derivative instruments are reflected in other income/(expense), net unless they are re-designated as hedges of other transactions.

[0000320193-18-000007:notes:97]
[same as prior period, unchanged from 0000320193-17-000009:notes:93]

[0000320193-18-000007:notes:98]
The effective portions of net investment hedges are recorded in other comprehensive income/(loss) (“OCI”) as a part of the cumulative translation adjustment. The ineffective portions and amounts excluded from the effectiveness testing of net investment hedges are recognized in other income/(expense), net.

[0000320193-18-000007:notes:99]
[same as prior period, unchanged from 0000320193-17-000009:notes:95]

[0000320193-18-000007:notes:100]
[same as prior period, unchanged from 0000320193-17-000009:notes:96]

[0000320193-18-000007:notes:101]
[same as prior period, unchanged from 0000320193-17-000009:notes:97]

[0000320193-18-000007:notes:102]
[same as prior period, unchanged from 0000320193-17-000009:notes:98]


## us-gaap:DividendsDeclaredTableTextBlock

[0000320193-18-000007:notes:103]
[same as prior period, unchanged from 0000320193-17-000009:notes:100]

[0000320193-18-000007:notes:104]
|  | DividendsPer Share |  | Amount(in millions) |
| 2018: |  |  |  |
| First quarter | $ | 0.63 |  |  | $ | 3,232 |  |
| 2017: |  |  |  |
| Fourth quarter | $ | 0.63 |  |  | $ | 3,252 |  |
| Third quarter | 0.63 |  |  | 3,281 |  |
| Second quarter | 0.57 |  |  | 2,988 |  |
| First quarter | 0.57 |  |  | 3,042 |  |
| Total cash dividends declared and paid | $ | 2.40 |  |  | $ | 12,563 |  |


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000320193-18-000007:notes:105]
[same as prior period, unchanged from 0000320193-17-000009:notes:102]

[0000320193-18-000007:notes:106]
[same as prior period, unchanged from 0000320193-17-000009:notes:103]


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000320193-18-000007:notes:107]
[same as prior period, unchanged from 0000320193-17-000009:notes:104]

[0000320193-18-000007:notes:108]
[same as prior period, unchanged from 0000320193-17-000009:notes:105]

[0000320193-18-000007:notes:109]
[same as prior period, unchanged from 0000320193-17-000009:notes:106]

[0000320193-18-000007:notes:110]
The Company considers the declines in market value of its marketable securities investment portfolio to be temporary in nature. The Company typically invests in highly rated securities, and its investment policy generally limits the amount of credit exposure to any one issuer. The policy generally requires investments to be investment grade, with the primary objective of minimizing the potential risk of principal loss. Fair values were determined for each individual security in the investment portfolio. When evaluating an investment for other-than-temporary impairment, the Company reviews factors such as the length of time and extent to which fair value has been below its cost basis, the financial condition of the issuer and any changes thereto, changes in market interest rates and the Company’s intent to sell, or whether it is more likely than not it will be required to sell the investment before recovery of the investment’s cost basis. As of December 30, 2017, the Company does not consider any of its investments to be other-than-temporarily impaired.

[0000320193-18-000007:notes:111]
Derivatives that are not designated as hedging instruments are adjusted to fair value through earnings in the financial statement line item to which the derivative relates. Amounts recognized in earnings related to non-designated derivatives were not significant for the three-month period ended December 30, 2017. During the three-month period ended December 31, 2016, the Company recognized gains of $273 million, $332 million and $508 million in net sales, cost of sales and other income/(expense), net, respectively.

[0000320193-18-000007:notes:112]
The Company records all derivatives in the Condensed Consolidated Balance Sheets at fair value. The Company’s accounting treatment for these derivative instruments is based on its hedge designation. The following tables show the Company’s derivative instruments at gross fair value as of December 30, 2017 and September 30, 2017 (in millions):

[0000320193-18-000007:notes:113]
|  | December 30, 2017 |
|  | Fair Value ofDerivatives Designatedas Hedge Instruments |  | Fair Value ofDerivatives Not Designatedas Hedge Instruments |  | TotalFair Value |
| Derivative assets (1): |  |  |  |  |  |
| Foreign exchange contracts | $ | 985 |  |  | $ | 284 |  |  | $ | 1,269 |  |
| Interest rate contracts | $ | 100 |  |  | $ | — |  |  | $ | 100 |  |
| Derivative liabilities (2): |  |  |  |  |  |
| Foreign exchange contracts | $ | 460 |  |  | $ | 283 |  |  | $ | 743 |  |
| Interest rate contracts | $ | 462 |  |  | $ | — |  |  | $ | 462 |  |

[0000320193-18-000007:notes:114]
|  | September 30, 2017 |
|  | Fair Value ofDerivatives Designatedas Hedge Instruments |  | Fair Value ofDerivatives Not Designatedas Hedge Instruments |  | TotalFair Value |
| Derivative assets (1): |  |  |  |  |  |
| Foreign exchange contracts | $ | 1,049 |  |  | $ | 363 |  |  | $ | 1,412 |  |
| Interest rate contracts | $ | 218 |  |  | $ | — |  |  | $ | 218 |  |
| Derivative liabilities (2): |  |  |  |  |  |
| Foreign exchange contracts | $ | 759 |  |  | $ | 501 |  |  | $ | 1,260 |  |
| Interest rate contracts | $ | 303 |  |  | $ | — |  |  | $ | 303 |  |

[0000320193-18-000007:notes:115]
| (1) | The fair value of derivative assets is measured using Level 2 fair value inputs and is recorded as other current assets and other non-current assets in the Condensed Consolidated Balance Sheets. |

[0000320193-18-000007:notes:116]
| (2) | The fair value of derivative liabilities is measured using Level 2 fair value inputs and is recorded as accrued expenses and other non-current liabilities in the Condensed Consolidated Balance Sheets. |

[0000320193-18-000007:notes:117]
The following table shows the pre-tax gains and losses of the Company’s derivative and non-derivative instruments designated as cash flow, net investment and fair value hedges in OCI and the Condensed Consolidated Statements of Operations for the three months ended December 30, 2017 and December 31, 2016 (in millions):

[0000320193-18-000007:notes:118]
|  | Three Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |
| Gains/(Losses) recognized in OCI – effective portion: |  |  |  |
| Cash flow hedges: |  |  |  |
| Foreign exchange contracts | $ | 153 |  |  | $ | 1,727 |  |
| Interest rate contracts | 1 |  |  | 7 |  |
| Total | $ | 154 |  |  | $ | 1,734 |  |
| Net investment hedges: |  |  |  |
| Foreign currency debt | $ | 2 |  |  | $ | 122 |  |
| Gains/(Losses) reclassified from AOCI into net income – effective portion: |  |  |  |
| Cash flow hedges: |  |  |  |
| Foreign exchange contracts | $ | (124 | ) |  | $ | (511 | ) |
| Interest rate contracts | 1 |  |  | (1 | ) |
| Total | $ | (123 | ) |  | $ | (512 | ) |
| Gains/(Losses) on derivative instruments: |  |  |  |
| Fair value hedges: |  |  |  |
| Interest rate contracts | $ | (274 | ) |  | $ | (872 | ) |
| Gains/(Losses) related to hedged items: |  |  |  |
| Fair value hedges: |  |  |  |
| Fixed-rate debt | $ | 274 |  |  | $ | 872 |  |

[0000320193-18-000007:notes:119]
[same as prior period, unchanged from 0000320193-17-000009:notes:116]

[0000320193-18-000007:notes:120]
The Company generally enters into master netting arrangements, which are designed to reduce credit risk by permitting net settlement of transactions with the same counterparty. To further limit credit risk, the Company generally enters into collateral security arrangements that provide for collateral to be received or posted when the net fair value of certain financial instruments fluctuates from contractually established thresholds. The Company presents its derivative assets and derivative liabilities at their gross fair values in its Condensed Consolidated Balance Sheets. The net cash collateral received by the Company related to derivative instruments under its collateral security arrangements was $230 million and $35 million as of December 30, 2017 and September 30, 2017, respectively, which were recorded as accrued expenses in the Condensed Consolidated Balance Sheets.

[0000320193-18-000007:notes:121]
Under master netting arrangements with the respective counterparties to the Company’s derivative contracts, the Company is allowed to net settle transactions with a single net amount payable by one party to the other. As of December 30, 2017 and September 30, 2017, the potential effects of these rights of set-off associated with the Company’s derivative contracts, including the effects of collateral, would be a reduction to both derivative assets and derivative liabilities of $1.3 billion and $1.4 billion, respectively, resulting in a net derivative liability of $66 million and a net derivative asset of $32 million, respectively.

[0000320193-18-000007:notes:122]
[same as prior period, unchanged from 0000320193-17-000009:notes:119]

[0000320193-18-000007:notes:123]
[same as prior period, unchanged from 0000320193-17-000009:notes:120]

[0000320193-18-000007:notes:124]
The Company has considerable trade receivables outstanding with its third-party cellular network carriers, wholesalers, retailers, resellers, small and mid-sized businesses and education, enterprise and government customers. The Company generally does not require collateral from its customers; however, the Company will require collateral in certain instances to limit credit risk. In addition, when possible, the Company attempts to limit credit risk on trade receivables with credit insurance for certain customers or by requiring third-party financing, loans or leases to support credit exposure. These credit-financing arrangements are directly between the third-party financing company and the end customer. As such, the Company generally does not assume any recourse or credit risk sharing related to any of these arrangements.

[0000320193-18-000007:notes:125]
As of December 30, 2017, the Company had one customer that represented 10% or more of total trade receivables, which accounted for 11%. As of September 30, 2017, the Company had two customers that individually represented 10% or more of total trade receivables, each of which accounted for 10%. The Company’s cellular network carriers accounted for 57% and 59% of total trade receivables as of December 30, 2017 and September 30, 2017, respectively.

[0000320193-18-000007:notes:126]
[same as prior period, unchanged from 0000320193-17-000009:notes:123]

[0000320193-18-000007:notes:127]
The Company has non-trade receivables from certain of its manufacturing vendors resulting from the sale of components to these vendors who manufacture sub-assemblies or assemble final products for the Company. The Company purchases these components directly from suppliers. As of December 30, 2017, the Company had one vendor that represented 10% or more of total vendor non-trade receivables, which accounted for 66%. As of September 30, 2017, the Company had three vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 42%, 19% and 10%.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000320193-18-000007:notes:128]
[same as prior period, unchanged from 0000320193-17-000009:notes:125]

[0000320193-18-000007:notes:129]
On December 22, 2017, the U.S. enacted the Tax Cuts and Jobs Act (the “Act”), which significantly changed U.S. tax law. The Act lowered the Company’s U.S. statutory federal income tax rate from 35% to 21% effective January 1, 2018, while also imposing a deemed repatriation tax on deferred foreign income. The Act also created a new minimum tax on certain future foreign earnings. During the first quarter of 2018, the Company recognized a provision for income taxes of $7.0 billion, of which $2.6 billion was considered a provisional estimate under the U.S. Securities and Exchange Commission Staff Accounting Bulletin No. 118. The Company’s provisional estimate of $2.6 billion included $1.8 billion related to the impact of remeasuring the Company’s deferred tax balances to reflect the new tax rate and approximately $800 million, net, associated with the deemed repatriation tax.

[0000320193-18-000007:notes:130]
Deferred Tax Balances

[0000320193-18-000007:notes:131]
The Company remeasured certain deferred tax assets and liabilities based on the rates at which they are expected to reverse. In addition, the Company elected to record certain deferred tax assets and liabilities related to the minimum tax on certain future foreign earnings. The provisional estimate of $1.8 billion incorporates assumptions made based upon the best available interpretation of the Act and may change as the Company receives additional clarification and implementation guidance.

[0000320193-18-000007:notes:132]
Deemed Repatriation Tax

[0000320193-18-000007:notes:133]
As of September 30, 2017, the Company had a U.S. deferred tax liability of $36.4 billion for deferred foreign income. As a result of the deemed repatriation tax, which is based on the Company’s total post-1986 deferred foreign income, the Company replaced $36.1 billion of its U.S. deferred tax liability with a provisional tax payable of $38.0 billion. The estimate of the deemed repatriation tax is based, in part, on the amount of cash and other specified assets anticipated to be held by the Company’s foreign subsidiaries as of September 29, 2018. As a result, the final amount may change as the amounts are finalized. The Company plans to pay the tax payable in installments in accordance with the Act.

[0000320193-18-000007:notes:134]
Unrecognized Tax Benefits

[0000320193-18-000007:notes:135]
As of December 30, 2017, the Company recorded gross unrecognized tax benefits of $9.0 billion. These gross unrecognized tax benefits have been offset by certain tax deposits and a $1.1 billion reduction for the estimated impact of the deemed repatriation tax, with the net unrecognized tax benefits classified as other non-current liabilities in the Condensed Consolidated Balance Sheets. Upon recognition, $7.7 billion of the unrecognized tax benefits would affect the Company’s effective tax rate. The Company had $1.4 billion of gross interest and penalties accrued as of December 30, 2017, which is also classified as other non-current liabilities in the Condensed Consolidated Balance Sheets.

[0000320193-18-000007:notes:136]
The Company believes that an adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax audits cannot be predicted with certainty. If any issues addressed in the Company’s tax audits are resolved in a manner inconsistent with its expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. Although timing of the resolution and/or closure of audits is not certain, the Company believes it is reasonably possible that its gross unrecognized tax benefits could decrease (whether by payment, release or a combination of both) in the next 12 months by as much as $2.9 billion.

[0000320193-18-000007:notes:137]
European Commission State Aid Decision

[0000320193-18-000007:notes:138]
On August 30, 2016, the European Commission announced its decision that Ireland granted state aid to the Company by providing tax opinions in 1991 and 2007 concerning the tax allocation of profits of the Irish branches of two subsidiaries of the Company (the “State Aid Decision”). The State Aid Decision orders Ireland to calculate and recover additional taxes from the Company for the period June 2003 through December 2014. Irish legislative changes, effective as of January 2015, eliminated the application of the tax opinions from that date forward. The Company believes the State Aid Decision to be without merit and appealed to the General Court of the Court of Justice of the European Union. Ireland has also appealed the State Aid Decision. Although Ireland is still computing the recovery amount, the Company expects the amount to be in line with the European Commission’s announced recovery amount of €13 billion, plus interest of €1 billion. Once the recovery amount is finalized by Ireland, the Company anticipates funding it by placing amounts into escrow in 2018, pending conclusion of all appeals. The Company believes that any incremental Irish corporate income taxes potentially due related to the State Aid Decision would be creditable against U.S. taxes.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000320193-18-000007:notes:139]
[same as prior period, unchanged from 0000320193-17-000009:notes:129]

[0000320193-18-000007:notes:140]
The Company’s acquired intangible assets with definite useful lives primarily consist of patents and licenses. The following table summarizes the components of acquired intangible asset balances as of December 30, 2017 and September 30, 2017 (in millions):

[0000320193-18-000007:notes:141]
|  | December 30, 2017 |  | September 30, 2017 |
|  | GrossCarrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |  | GrossCarrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |
| Definite-lived and amortizable acquired intangible assets | $ | 7,540 |  |  | $ | (5,491 | ) |  | $ | 2,049 |  |  | $ | 7,507 |  |  | $ | (5,309 | ) |  | $ | 2,198 |  |
| Indefinite-lived and non-amortizable acquired intangible assets | 100 |  |  | — |  |  | 100 |  |  | 100 |  |  | — |  |  | 100 |  |
| Total acquired intangible assets | $ | 7,640 |  |  | $ | (5,491 | ) |  | $ | 2,149 |  |  | $ | 7,607 |  |  | $ | (5,309 | ) |  | $ | 2,298 |  |


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0000320193-18-000007:notes:142]
A reconciliation of the Company’s segment operating income to the Condensed Consolidated Statements of Operations for the three months ended December 30, 2017 and December 31, 2016 is as follows (in millions):

[0000320193-18-000007:notes:143]
|  | Three Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |
| Segment operating income | $ | 30,774 |  |  | $ | 27,308 |  |
| Research and development expense | (3,407 | ) |  | (2,871 | ) |
| Other corporate expenses, net | (1,093 | ) |  | (1,078 | ) |
| Total operating income | $ | 26,274 |  |  | $ | 23,359 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000320193-18-000007:notes:144]
The following table shows information by reportable segment for the three months ended December 30, 2017 and December 31, 2016 (in millions):

[0000320193-18-000007:notes:145]
|  | Three Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |
| Americas: |  |  |  |
| Net sales | $ | 35,193 |  |  | $ | 31,968 |  |
| Operating income | $ | 11,316 |  |  | $ | 10,494 |  |
| Europe: |  |  |  |
| Net sales | $ | 21,054 |  |  | $ | 18,521 |  |
| Operating income | $ | 6,893 |  |  | $ | 5,736 |  |
| Greater China: |  |  |  |
| Net sales | $ | 17,956 |  |  | $ | 16,233 |  |
| Operating income | $ | 6,908 |  |  | $ | 6,176 |  |
| Japan: |  |  |  |
| Net sales | $ | 7,237 |  |  | $ | 5,766 |  |
| Operating income | $ | 3,082 |  |  | $ | 2,673 |  |
| Rest of Asia Pacific: |  |  |  |
| Net sales | $ | 6,853 |  |  | $ | 5,863 |  |
| Operating income | $ | 2,575 |  |  | $ | 2,229 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000320193-18-000007:notes:146]
[same as prior period, unchanged from 0000320193-17-000009:notes:136]

[0000320193-18-000007:notes:147]
The Company reports segment information based on the “management” approach. The management approach designates the internal reporting used by management for making decisions and assessing performance as the source of the Company’s reportable segments.

[0000320193-18-000007:notes:148]
The Company manages its business primarily on a geographic basis. The Company’s reportable segments consist of the Americas, Europe, Greater China, Japan and Rest of Asia Pacific. Americas includes both North and South America. Europe includes European countries, as well as India, the Middle East and Africa. Greater China includes China, Hong Kong and Taiwan. Rest of Asia Pacific includes Australia and those Asian countries not included in the Company’s other reportable segments. Although the reportable segments provide similar hardware and software products and similar services, each one is managed separately to better align with the location of the Company’s customers and distribution partners and the unique market dynamics of each geographic region. The accounting policies of the various segments are the same as those described in Note 1, “Summary of Significant Accounting Policies” of the Notes to Consolidated Financial Statements in Part II, Item 8 of the 2017 Form 10-K.

[0000320193-18-000007:notes:149]
The Company evaluates the performance of its reportable segments based on net sales and operating income. Net sales for geographic segments are generally based on the location of customers and sales through the Company’s retail stores located in those geographic locations. Operating income for each segment includes net sales to third parties, related cost of sales and operating expenses directly attributable to the segment. Advertising expenses are generally included in the geographic segment in which the expenditures are incurred. Operating income for each segment excludes other income and expense and certain expenses managed outside the reportable segments. Costs excluded from segment operating income include various corporate expenses such as research and development, corporate marketing expenses, certain share-based compensation expenses, income taxes, various nonrecurring charges and other separately managed general and administrative costs. The Company does not include intercompany transfers between segments for management reporting purposes.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000320193-18-000007:notes:150]
[same as prior period, unchanged from 0000320193-17-000009:notes:140]

[0000320193-18-000007:notes:151]
[same as prior period, unchanged from 0000320193-17-000009:notes:141]

[0000320193-18-000007:notes:152]
[same as prior period, unchanged from 0000320193-17-000009:notes:142]

[0000320193-18-000007:notes:153]
[same as prior period, unchanged from 0000320193-17-000009:notes:143]

[0000320193-18-000007:notes:154]
In May 2017, the Company’s Board of Directors increased the share repurchase authorization from $175 billion to $210 billion of the Company’s common stock, of which $176 billion had been utilized as of December 30, 2017. The Company’s share repurchase program does not obligate it to acquire any specific number of shares. Under the program, shares may be repurchased in privately negotiated and/or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).

[0000320193-18-000007:notes:155]
[same as prior period, unchanged from 0000320193-17-000009:notes:145]
