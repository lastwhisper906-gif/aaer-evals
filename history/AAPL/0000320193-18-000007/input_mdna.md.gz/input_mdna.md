# AAPL MD&A — 0000320193-18-000007


## mdna

[0000320193-18-000007:mdna:1]
[same as prior period, unchanged from 0000320193-17-000009:mdna:1]

[0000320193-18-000007:mdna:2]
[same as prior period, unchanged from 0000320193-17-000009:mdna:2]

[0000320193-18-000007:mdna:3]
The Company’s Annual Report on Form 10-K, Quarterly Reports on Form 10-Q, Current Reports on Form 8-K, and amendments to reports filed pursuant to Sections 13(a) and 15(d) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), are filed with the SEC. The Company is subject to the informational requirements of the Exchange Act and files or furnishes reports, proxy statements, and other information with the SEC. Such reports and other information filed by the Company with the SEC are available free of charge on the Company’s website at investor.apple.com/sec.cfm when such reports are available on the SEC’s website. The public may read and copy any materials filed by the Company with the SEC at the SEC’s Public Reference Room at 100 F Street, NE, Room 1580, Washington, DC 20549. The public may obtain information on the operation of the Public Reference Room by calling the SEC at 1-800-SEC-0330. The SEC maintains an internet site that contains reports, proxy and information statements and other information regarding issuers that file electronically with the SEC at www.sec.gov. The information contained on the websites referenced in this Form 10-Q is not incorporated by reference into this filing. Further, the Company’s references to website URLs are intended to be inactive textual references only.

[0000320193-18-000007:mdna:4]
[same as prior period, unchanged from 0000320193-17-000009:mdna:4]

[0000320193-18-000007:mdna:5]
The Company designs, manufactures and markets mobile communication and media devices and personal computers, and sells a variety of related software, services, accessories, networking solutions and third-party digital content and applications. The Company’s products and services include iPhone, iPad, Mac, Apple Watch, Apple TV, a portfolio of consumer and professional software applications, iOS, macOS, watchOS and tvOS operating systems, iCloud, Apple Pay and a variety of accessory, service and support offerings. The Company sells and delivers digital content and applications through the iTunes Store, App Store, Mac App Store, TV App Store, iBooks Store and Apple Music (collectively “Digital Content and Services”). The Company sells its products worldwide through its retail stores, online stores and direct sales force, as well as through third-party cellular network carriers, wholesalers, retailers and resellers. In addition, the Company sells a variety of third-party Apple-compatible products, including application software and various accessories through its retail and online stores. The Company sells to consumers, small and mid-sized businesses and education, enterprise and government customers.

[0000320193-18-000007:mdna:6]
[same as prior period, unchanged from 0000320193-17-000009:mdna:6]

[0000320193-18-000007:mdna:7]
[same as prior period, unchanged from 0000320193-17-000009:mdna:7]

[0000320193-18-000007:mdna:8]
[same as prior period, unchanged from 0000320193-17-000009:mdna:8]

[0000320193-18-000007:mdna:9]
The Company has historically experienced higher net sales in its first quarter compared to other quarters in its fiscal year due in part to seasonal holiday demand. Additionally, new product introductions can significantly impact net sales, product costs and operating expenses. Product introductions can also impact the Company’s net sales to its indirect distribution channels as these channels are filled with new product inventory following a product introduction, and channel inventory of a particular product often declines as the next related major product launch approaches. Net sales can also be affected when consumers and distributors anticipate a product introduction. However, neither historical seasonal patterns nor historical patterns of product introductions should be considered reliable indicators of the Company’s future pattern of product introductions, future net sales or financial performance.

[0000320193-18-000007:mdna:10]
[same as prior period, unchanged from 0000320193-17-000009:mdna:10]

[0000320193-18-000007:mdna:11]
The Company’s fiscal year is the 52- or 53-week period that ends on the last Saturday of September. The first quarter of 2018 spanned 13 weeks, whereas a 14th week was added to the first quarter of 2017, as is done every five or six years, to realign fiscal quarters with calendar quarters.

[0000320193-18-000007:mdna:12]
First Quarter Fiscal 2018 Highlights

[0000320193-18-000007:mdna:13]
Net sales increased 13% or $9.9 billion during the first quarter of 2018 compared to the same quarter in 2017, primarily driven by growth in iPhone, Other Products and Services. The year-over-year increase in net sales reflected growth in all of the Company’s geographic reportable segments. The Company began shipping iPhone X in November 2017 and iMac Pro™ in December 2017.

[0000320193-18-000007:mdna:14]
The Company spent $10.1 billion to repurchase shares of its common stock and paid dividends and dividend equivalents of $3.3 billion during the first quarter of 2018. Additionally, the Company issued $7.0 billion of U.S. dollar-denominated term debt.

[0000320193-18-000007:mdna:15]
[same as prior period, unchanged from 0000320193-17-000009:mdna:16]

[0000320193-18-000007:mdna:16]
The following table shows net sales by reportable segment and net sales and unit sales by product for the three months ended December 30, 2017 and December 31, 2016 (dollars in millions and units in thousands):

[0000320193-18-000007:mdna:17]
|  | Three Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |  | Change |
| Net Sales by Reportable Segment: |  |  |  |  |  |
| Americas | $ | 35,193 |  |  | $ | 31,968 |  |  | 10 | % |
| Europe | 21,054 |  |  | 18,521 |  |  | 14 | % |
| Greater China | 17,956 |  |  | 16,233 |  |  | 11 | % |
| Japan | 7,237 |  |  | 5,766 |  |  | 26 | % |
| Rest of Asia Pacific | 6,853 |  |  | 5,863 |  |  | 17 | % |
| Total net sales | $ | 88,293 |  |  | $ | 78,351 |  |  | 13 | % |
| Net Sales by Product: |  |  |  |  |  |
| iPhone (1) | $ | 61,576 |  |  | $ | 54,378 |  |  | 13 | % |
| iPad (1) | 5,862 |  |  | 5,533 |  |  | 6 | % |
| Mac (1) | 6,895 |  |  | 7,244 |  |  | (5 | )% |
| Services (2) | 8,471 |  |  | 7,172 |  |  | 18 | % |
| Other Products (1)(3) | 5,489 |  |  | 4,024 |  |  | 36 | % |
| Total net sales | $ | 88,293 |  |  | $ | 78,351 |  |  | 13 | % |
| Unit Sales by Product: |  |  |  |  |  |
| iPhone | 77,316 |  |  | 78,290 |  |  | (1 | )% |
| iPad | 13,170 |  |  | 13,081 |  |  | 1 | % |
| Mac | 5,112 |  |  | 5,374 |  |  | (5 | )% |

[0000320193-18-000007:mdna:18]
| (1) | Includes deferrals and amortization of related software upgrade rights and non-software services. |

[0000320193-18-000007:mdna:19]
| (2) | Includes revenue from Digital Content and Services, AppleCare®, Apple Pay, licensing and other services. |

[0000320193-18-000007:mdna:20]
| (3) | Includes sales of Apple TV, Apple Watch, Beats® products, iPod touch and Apple-branded and third-party accessories. |

[0000320193-18-000007:mdna:21]
[same as prior period, unchanged from 0000320193-17-000009:mdna:22]

[0000320193-18-000007:mdna:22]
[same as prior period, unchanged from 0000320193-17-000009:mdna:23]

[0000320193-18-000007:mdna:23]
The following table presents iPhone net sales and unit sales information for the three months ended December 30, 2017 and December 31, 2016 (dollars in millions and units in thousands):

[0000320193-18-000007:mdna:24]
|  | Three Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |  | Change |
| Net sales | $ | 61,576 |  |  | $ | 54,378 |  |  | 13 | % |
| Percentage of total net sales | 70 | % |  | 69 | % |  |  |
| Unit sales | 77,316 |  |  | 78,290 |  |  | (1 | )% |

[0000320193-18-000007:mdna:25]
iPhone net sales increased during the first quarter of 2018 compared to the same quarter in 2017 due primarily to a different mix of iPhones with higher average selling prices.

[0000320193-18-000007:mdna:26]
[same as prior period, unchanged from 0000320193-17-000009:mdna:27]

[0000320193-18-000007:mdna:27]
The following table presents iPad net sales and unit sales information for the three months ended December 30, 2017 and December 31, 2016 (dollars in millions and units in thousands):

[0000320193-18-000007:mdna:28]
|  | Three Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |  | Change |
| Net sales | $ | 5,862 |  |  | $ | 5,533 |  |  | 6 | % |
| Percentage of total net sales | 7 | % |  | 7 | % |  |  |
| Unit sales | 13,170 |  |  | 13,081 |  |  | 1 | % |

[0000320193-18-000007:mdna:29]
iPad net sales increased during the first quarter of 2018 compared to the same quarter in 2017 due primarily to a different mix of iPads with higher average selling prices.

[0000320193-18-000007:mdna:30]
[same as prior period, unchanged from 0000320193-17-000009:mdna:31]

[0000320193-18-000007:mdna:31]
The following table presents Mac net sales and unit sales information for the three months ended December 30, 2017 and December 31, 2016 (dollars in millions and units in thousands):

[0000320193-18-000007:mdna:32]
|  | Three Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |  | Change |
| Net sales | $ | 6,895 |  |  | $ | 7,244 |  |  | (5 | )% |
| Percentage of total net sales | 8 | % |  | 9 | % |  |  |
| Unit sales | 5,112 |  |  | 5,374 |  |  | (5 | )% |

[0000320193-18-000007:mdna:33]
Mac net sales decreased during the first quarter of 2018 compared to the same quarter in 2017 due primarily to lower Mac unit sales given the positive impact of the MacBook Pro® launch during the first quarter of 2017 on that quarter’s results.

[0000320193-18-000007:mdna:34]
[same as prior period, unchanged from 0000320193-17-000009:mdna:35]

[0000320193-18-000007:mdna:35]
The following table presents Services net sales information for the three months ended December 30, 2017 and December 31, 2016 (dollars in millions):

[0000320193-18-000007:mdna:36]
|  | Three Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |  | Change |
| Net sales | $ | 8,471 |  |  | $ | 7,172 |  |  | 18 | % |
| Percentage of total net sales | 10 | % |  | 9 | % |  |  |

[0000320193-18-000007:mdna:37]
The year-over-year growth in Services net sales in the first quarter of 2018 was due primarily to increases in licensing and App Store sales.

[0000320193-18-000007:mdna:38]
[same as prior period, unchanged from 0000320193-17-000009:mdna:39]

[0000320193-18-000007:mdna:39]
The Company manages its business primarily on a geographic basis. The Company’s reportable segments consist of the Americas, Europe, Greater China, Japan and Rest of Asia Pacific. Americas includes both North and South America. Europe includes European countries, as well as India, the Middle East and Africa. Greater China includes China, Hong Kong and Taiwan. Rest of Asia Pacific includes Australia and those Asian countries not included in the Company’s other reportable segments. Although the reportable segments provide similar hardware and software products and similar services, each one is managed separately to better align with the location of the Company’s customers and distribution partners and the unique market dynamics of each geographic region. Further information regarding the Company’s reportable segments can be found in Part I, Item 1 of this Form 10-Q in the Notes to Condensed Consolidated Financial Statements in Note 11, “Segment Information and Geographic Data.”

[0000320193-18-000007:mdna:40]
[same as prior period, unchanged from 0000320193-17-000009:mdna:41]

[0000320193-18-000007:mdna:41]
The following table presents Americas net sales information for the three months ended December 30, 2017 and December 31, 2016 (dollars in millions):

[0000320193-18-000007:mdna:42]
|  | Three Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |  | Change |
| Net sales | $ | 35,193 |  |  | $ | 31,968 |  |  | 10 | % |
| Percentage of total net sales | 40 | % |  | 41 | % |  |  |

[0000320193-18-000007:mdna:43]
Americas net sales increased during the first quarter of 2018 compared to the same quarter in 2017 due primarily to higher net sales of iPhone and Other Products.

[0000320193-18-000007:mdna:44]
[same as prior period, unchanged from 0000320193-17-000009:mdna:45]

[0000320193-18-000007:mdna:45]
The following table presents Europe net sales information for the three months ended December 30, 2017 and December 31, 2016 (dollars in millions):

[0000320193-18-000007:mdna:46]
|  | Three Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |  | Change |
| Net sales | $ | 21,054 |  |  | $ | 18,521 |  |  | 14 | % |
| Percentage of total net sales | 24 | % |  | 24 | % |  |  |

[0000320193-18-000007:mdna:47]
Europe net sales increased during the first quarter of 2018 compared to the same quarter in 2017 due primarily to higher net sales of iPhone and Services. The strength in foreign currencies relative to the U.S. dollar had a favorable year-over-year impact on Europe net sales during the first quarter of 2018.

[0000320193-18-000007:mdna:48]
[same as prior period, unchanged from 0000320193-17-000009:mdna:49]

[0000320193-18-000007:mdna:49]
The following table presents Greater China net sales information for the three months ended December 30, 2017 and December 31, 2016 (dollars in millions):

[0000320193-18-000007:mdna:50]
|  | Three Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |  | Change |
| Net sales | $ | 17,956 |  |  | $ | 16,233 |  |  | 11 | % |
| Percentage of total net sales | 20 | % |  | 21 | % |  |  |

[0000320193-18-000007:mdna:51]
Greater China net sales increased during the first quarter of 2018 compared to the same quarter in 2017 due primarily to higher net sales of iPhone and Services.

[0000320193-18-000007:mdna:52]
[same as prior period, unchanged from 0000320193-17-000009:mdna:53]

[0000320193-18-000007:mdna:53]
The following table presents Japan net sales information for the three months ended December 30, 2017 and December 31, 2016 (dollars in millions):

[0000320193-18-000007:mdna:54]
|  | Three Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |  | Change |
| Net sales | $ | 7,237 |  |  | $ | 5,766 |  |  | 26 | % |
| Percentage of total net sales | 8 | % |  | 7 | % |  |  |

[0000320193-18-000007:mdna:55]
Japan net sales increased during the first quarter of 2018 compared to the same quarter in 2017 due primarily to higher net sales of iPhone, partially offset by the weakness in the Japanese yen relative to the U.S. dollar.

[0000320193-18-000007:mdna:56]
[same as prior period, unchanged from 0000320193-17-000009:mdna:57]

[0000320193-18-000007:mdna:57]
The following table presents Rest of Asia Pacific net sales information for the three months ended December 30, 2017 and December 31, 2016 (dollars in millions):

[0000320193-18-000007:mdna:58]
|  | Three Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |  | Change |
| Net sales | $ | 6,853 |  |  | $ | 5,863 |  |  | 17 | % |
| Percentage of total net sales | 8 | % |  | 7 | % |  |  |

[0000320193-18-000007:mdna:59]
Rest of Asia Pacific net sales increased during the first quarter of 2018 compared to the same quarter in 2017 due primarily to higher net sales of iPhone and Services.

[0000320193-18-000007:mdna:60]
[same as prior period, unchanged from 0000320193-17-000009:mdna:61]

[0000320193-18-000007:mdna:61]
Gross margin for the three months ended December 30, 2017 and December 31, 2016 was as follows (dollars in millions):

[0000320193-18-000007:mdna:62]
|  | Three Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |
| Net sales | $ | 88,293 |  |  | $ | 78,351 |  |
| Cost of sales | 54,381 |  |  | 48,175 |  |
| Gross margin | $ | 33,912 |  |  | $ | 30,176 |  |
| Gross margin percentage | 38.4 | % |  | 38.5 | % |

[0000320193-18-000007:mdna:63]
Gross margin percentage during the first quarter of 2018 compared to the same quarter in 2017 was relatively flat.

[0000320193-18-000007:mdna:64]
The Company anticipates gross margin percentage during the second quarter of 2018 to be between 38.0% and 38.5%. The foregoing statement regarding the Company’s expected gross margin percentage in the second quarter of 2018 is forward-looking and could differ from actual results. The Company’s future gross margins can be impacted by multiple factors including, but not limited to, those set forth in Part II, Item 1A of this Form 10-Q under the heading “Risk Factors” and those described in this paragraph. In general, the Company believes gross margins will remain under downward pressure due to a variety of factors, including: continued industry-wide global product pricing pressures; increased competition; the Company’s ability to effectively stimulate demand for certain of its products; compressed product life cycles; product transitions; potential increases in the cost of components and outside manufacturing services; the Company’s ability to manage product quality and warranty costs effectively; and a potential shift in the Company’s sales mix towards products with lower gross margins. In response to competitive pressures, the Company expects it will continue to take product pricing actions, which would adversely affect gross margins. Due to the Company’s significant international operations, its financial condition and operating results, including gross margins, could be significantly affected by fluctuations in exchange rates.

[0000320193-18-000007:mdna:65]
[same as prior period, unchanged from 0000320193-17-000009:mdna:66]

[0000320193-18-000007:mdna:66]
Operating expenses for the three months ended December 30, 2017 and December 31, 2016 were as follows (dollars in millions):

[0000320193-18-000007:mdna:67]
|  | Three Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |
| Research and development | $ | 3,407 |  |  | $ | 2,871 |  |
| Percentage of total net sales | 4 | % |  | 4 | % |
| Selling, general and administrative | $ | 4,231 |  |  | $ | 3,946 |  |
| Percentage of total net sales | 5 | % |  | 5 | % |
| Total operating expenses | $ | 7,638 |  |  | $ | 6,817 |  |
| Percentage of total net sales | 9 | % |  | 9 | % |

[0000320193-18-000007:mdna:68]
[same as prior period, unchanged from 0000320193-17-000009:mdna:69]

[0000320193-18-000007:mdna:69]
The growth in R&D expense during the first quarter of 2018 compared to the same quarter in 2017 was driven primarily by increases in headcount-related expenses and material costs to support expanded R&D activities. The Company continues to believe that focused investments in R&D are critical to its future growth and competitive position in the marketplace, and to the development of new and updated products and services that are central to the Company’s core business strategy.

[0000320193-18-000007:mdna:70]
[same as prior period, unchanged from 0000320193-17-000009:mdna:71]

[0000320193-18-000007:mdna:71]
The growth in selling, general and administrative expense during the first quarter of 2018 compared to the same quarter in 2017 was driven primarily by higher spending on marketing and advertising, and an increase in infrastructure-related costs.

[0000320193-18-000007:mdna:72]
[same as prior period, unchanged from 0000320193-17-000009:mdna:73]

[0000320193-18-000007:mdna:73]
Other income/(expense), net for the three months ended December 30, 2017 and December 31, 2016 was as follows (dollars in millions):

[0000320193-18-000007:mdna:74]
|  | Three Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |  | Change |
| Interest and dividend income | $ | 1,452 |  |  | $ | 1,224 |  |  |  |
| Interest expense | (734 | ) |  | (525 | ) |  |  |
| Other income, net | 38 |  |  | 122 |  |  |  |
| Total other income/(expense), net | $ | 756 |  |  | $ | 821 |  |  | (8 | )% |

[0000320193-18-000007:mdna:75]
The decrease in other income/(expense), net during the first quarter of 2018 compared to the same quarter in 2017 was due primarily to the impact of foreign exchange-related items and higher interest expense on debt, partially offset by higher interest income and realized gains on sales of marketable securities. The weighted-average interest rate earned by the Company on its cash, cash equivalents and marketable securities was 2.11% and 1.87% in the first quarter of 2018 and 2017, respectively.

[0000320193-18-000007:mdna:76]
[same as prior period, unchanged from 0000320193-17-000009:mdna:77]

[0000320193-18-000007:mdna:77]
Provision for income taxes and effective tax rates for the three months ended December 30, 2017 and December 31, 2016 were as follows (dollars in millions):

[0000320193-18-000007:mdna:78]
|  | Three Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |
| Provision for income taxes | $ | 6,965 |  |  | $ | 6,289 |  |
| Effective tax rate | 25.8 | % |  | 26.0 | % |

[0000320193-18-000007:mdna:79]
On December 22, 2017, the U.S. enacted the Tax Cuts and Jobs Act (the “Act”), which significantly changed U.S. tax law. The Act lowered the Company’s U.S. statutory federal income tax rate from 35% to 21% effective January 1, 2018, while also imposing a deemed repatriation tax on deferred foreign income. By operation of law, the Company will apply a blended U.S. statutory federal income tax rate of 24.5% for 2018. The Act also created a new minimum tax on certain future foreign earnings.

[0000320193-18-000007:mdna:80]
The Company’s effective tax rate of 25.8% for the first quarter of 2018 differs from the blended rate of 24.5% due primarily to the remeasurement of deferred tax assets and liabilities, partially offset by the impact of taxes on foreign earnings. The Company’s effective tax rate for the first quarter of 2018 is slightly lower than the first quarter of 2017 due to the lower U.S. statutory blended tax rate, primarily offset by the remeasurement of deferred tax assets and liabilities.

[0000320193-18-000007:mdna:81]
The Company anticipates its effective tax rate for the remainder of 2018 to be approximately 15%. The foregoing statement regarding the Company’s expected effective tax rate during 2018 is forward-looking and could differ from actual results. The Company’s future expected tax rate can be impacted by multiple factors including, but not limited to, those set forth in Part II, Item 1A of this Form 10-Q under the heading “Risk Factors.”

[0000320193-18-000007:mdna:82]
The Company’s effective tax rate for the first quarter of 2017 differed from the U.S. statutory federal income tax rate of 35% due primarily to certain undistributed foreign earnings, a substantial portion of which was generated by subsidiaries organized in Ireland, for which no U.S. taxes were provided when such earnings were intended to be indefinitely reinvested outside the U.S.

[0000320193-18-000007:mdna:83]
The Company is subject to audits by federal, state, local and foreign tax authorities. Management believes that adequate provisions have been made for any adjustments that may result from tax examinations. However, the outcome of tax audits cannot be predicted with certainty. If any issues addressed in the Company’s tax audits are resolved in a manner inconsistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs.

[0000320193-18-000007:mdna:84]
On August 30, 2016, the European Commission announced its decision that Ireland granted state aid to the Company by providing tax opinions in 1991 and 2007 concerning the tax allocation of profits of the Irish branches of two subsidiaries of the Company (the “State Aid Decision”). The State Aid Decision orders Ireland to calculate and recover additional taxes from the Company for the period June 2003 through December 2014. Irish legislative changes, effective as of January 2015, eliminated the application of the tax opinions from that date forward. The Company believes the State Aid Decision to be without merit and appealed to the General Court of the Court of Justice of the European Union. Ireland has also appealed the State Aid Decision. Although Ireland is still computing the recovery amount, the Company expects the amount to be in line with the European Commission’s announced recovery amount of €13 billion, plus interest of €1 billion. Once the recovery amount is finalized by Ireland, the Company anticipates funding it by placing amounts into escrow in 2018, pending conclusion of all appeals. The Company believes that any incremental Irish corporate income taxes potentially due related to the State Aid Decision would be creditable against U.S. taxes.

[0000320193-18-000007:mdna:85]
[same as prior period, unchanged from 0000320193-17-000009:mdna:83]

[0000320193-18-000007:mdna:86]
Hedging

[0000320193-18-000007:mdna:87]
In August 2017, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities (“ASU 2017-12”). ASU 2017-12 expands component and fair value hedging, specifies the presentation of the effects of hedging instruments, and eliminates the separate measurement and presentation of hedge ineffectiveness. The Company will adopt ASU 2017-12 in its first quarter of 2020 utilizing the modified retrospective transition method and is currently evaluating the impact of adoption on its consolidated financial statements.

[0000320193-18-000007:mdna:88]
[same as prior period, unchanged from 0000320193-17-000009:mdna:84]

[0000320193-18-000007:mdna:89]
In November 2016, the FASB issued ASU No. 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash (“ASU 2016-18”), which enhances and clarifies the guidance on the classification and presentation of restricted cash in the statement of cash flows. The Company will adopt ASU 2016-18 in its first quarter of 2019 utilizing the retrospective transition method. Currently, the Company’s restricted cash balance is not significant.

[0000320193-18-000007:mdna:90]
[same as prior period, unchanged from 0000320193-17-000009:mdna:86]

[0000320193-18-000007:mdna:91]
In October 2016, the FASB issued ASU No. 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory (“ASU 2016-16”), which requires the recognition of the income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. The Company will adopt ASU 2016-16 in its first quarter of 2019 utilizing the modified retrospective transition method. Currently, the Company estimates recording up to $4 billion of net deferred tax assets on its Condensed Consolidated Balance Sheets upon adoption. However, the ultimate impact of adopting ASU 2016-16 will depend on the balance of intellectual property transferred between its subsidiaries as of the adoption date, as well as the deferred tax impact of the minimum tax on certain future foreign earnings. The Company will recognize incremental deferred income tax expense thereafter as these net deferred tax assets are utilized.

[0000320193-18-000007:mdna:92]
[same as prior period, unchanged from 0000320193-17-000009:mdna:90]

[0000320193-18-000007:mdna:93]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842) (“ASU 2016-02”), which modifies lease accounting for lessees to increase transparency and comparability by recording lease assets and liabilities for operating leases and disclosing key information about leasing arrangements. The Company will adopt ASU 2016-02 in its first quarter of 2020 utilizing the modified retrospective transition method. While the Company is currently evaluating the timing and impact of adopting ASU 2016-02, currently the Company anticipates recording lease assets and liabilities in excess of $9.6 billion on its Condensed Consolidated Balance Sheets, with no material impact to its Condensed Consolidated Statements of Operations. However, the ultimate impact of adopting ASU 2016-02 will depend on the Company’s lease portfolio as of the adoption date.

[0000320193-18-000007:mdna:94]
[same as prior period, unchanged from 0000320193-17-000009:mdna:92]

[0000320193-18-000007:mdna:95]
In January 2016, the FASB issued ASU No. 2016-01, Financial Instruments – Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities (“ASU 2016-01”), which updates certain aspects of recognition, measurement, presentation and disclosure of financial instruments. The Company will adopt ASU 2016-01 in its first quarter of 2019 utilizing the modified retrospective transition method. Based on the composition of the Company’s investment portfolio, the adoption of ASU 2016-01 is not expected to have a material impact on its consolidated financial statements.

[0000320193-18-000007:mdna:96]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (“ASU 2016-13”), which modifies the measurement of expected credit losses of certain financial instruments. The Company will adopt ASU 2016-13 in its first quarter of 2021 utilizing the modified retrospective transition method. Based on the composition of the Company’s investment portfolio, current market conditions, and historical credit loss activity, the adoption of ASU 2016-13 is not expected to have a material impact on its consolidated financial statements.

[0000320193-18-000007:mdna:97]
[same as prior period, unchanged from 0000320193-17-000009:mdna:95]

[0000320193-18-000007:mdna:98]
In May 2014, the FASB issued ASU No. 2014-09, Revenue from Contracts with Customers (Topic 606) (“ASU 2014-09”), which amends the existing accounting standards for revenue recognition. ASU 2014-09 is based on principles that govern the recognition of revenue at an amount an entity expects to be entitled when products are transferred to customers.

[0000320193-18-000007:mdna:99]
Subsequently, the FASB has issued the following standards related to ASU 2014-09: ASU No. 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (“ASU 2016-08”); ASU No. 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing (“ASU 2016-10”); ASU No. 2016-12, Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients (“ASU 2016-12”); and ASU No. 2016-20, Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers (“ASU 2016-20”). The Company must adopt ASU 2016-08, ASU 2016-10, ASU 2016-12 and ASU 2016-20 with ASU 2014-09 (collectively, the “new revenue standards”).

[0000320193-18-000007:mdna:100]
The new revenue standards may be applied retrospectively to each prior period presented or retrospectively with the cumulative effect recognized as of the date of adoption. The Company will adopt the new revenue standards in its first quarter of 2019 utilizing the full retrospective transition method. The new revenue standards are not expected to have a material impact on the amount and timing of revenue recognized in the Company’s consolidated financial statements.

[0000320193-18-000007:mdna:101]
[same as prior period, unchanged from 0000320193-17-000009:mdna:99]

[0000320193-18-000007:mdna:102]
The following tables present selected financial information and statistics as of December 30, 2017 and September 30, 2017 and for the first three months of 2018 and 2017 (in millions):

[0000320193-18-000007:mdna:103]
|  | December 30, 2017 |  | September 30, 2017 |
| Cash, cash equivalents and marketable securities | $ | 285,097 |  |  | $ | 268,895 |  |
| Property, plant and equipment, net | $ | 33,679 |  |  | $ | 33,783 |  |
| Commercial paper | $ | 11,980 |  |  | $ | 11,977 |  |
| Total term debt | $ | 110,420 |  |  | $ | 103,703 |  |
| Working capital | $ | 28,022 |  |  | $ | 27,831 |  |

[0000320193-18-000007:mdna:104]
|  | Three Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |
| Cash generated by operating activities (1) | $ | 28,293 |  |  | $ | 27,234 |  |
| Cash used in investing activities | $ | (13,590 | ) |  | $ | (19,122 | ) |
| Cash used in financing activities (1) | $ | (7,501 | ) |  | $ | (12,225 | ) |

[0000320193-18-000007:mdna:105]
| (1) | Refer to Note 1, “Summary of Significant Accounting Polices” in the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Form 10-Q for more information on the prior period reclassification related to the Company’s adoption of ASU 2016-09. |

[0000320193-18-000007:mdna:106]
The Company believes its existing balances of cash, cash equivalents and marketable securities will be sufficient to satisfy its working capital needs, capital asset purchases, outstanding commitments and other liquidity requirements associated with its existing operations over the next 12 months. The Company currently anticipates the cash used for future dividends, the share repurchase program and debt repayments will come from its current cash and cash generated from ongoing operating activities.

[0000320193-18-000007:mdna:107]
In connection with the State Aid Decision, Ireland is still computing the recovery amount. The Company expects the amount to be in line with the European Commission’s announced recovery amount of €13 billion, plus interest of €1 billion. Once the recovery amount is finalized by Ireland, the Company anticipates funding it by placing amounts into escrow in 2018, pending conclusion of all appeals.

[0000320193-18-000007:mdna:108]
The Company’s marketable securities investment portfolio is primarily invested in highly rated securities, and its investment policy generally limits the amount of credit exposure to any one issuer. The policy generally requires investments to be investment grade, with the primary objective of minimizing the potential risk of principal loss.

[0000320193-18-000007:mdna:109]
During the three months ended December 30, 2017, cash generated by operating activities of $28.3 billion was a result of $20.1 billion of net income and an increase in the net change in operating assets and liabilities of $37.9 billion, partially offset by non-cash adjustments to net income of $29.7 billion. Cash used in investing activities of $13.6 billion during the three months ended December 30, 2017 consisted primarily of cash used for purchases of marketable securities, net of sales and maturities, of $10.4 billion and cash used to acquire property, plant and equipment of $2.8 billion. Cash used in financing activities of $7.5 billion during the three months ended December 30, 2017 consisted primarily of cash used to repurchase common stock of $10.1 billion and cash used to pay dividends and dividend equivalents of $3.3 billion, partially offset by proceeds from the issuance of term debt, net of $7.0 billion.

[0000320193-18-000007:mdna:110]
During the three months ended December 31, 2016, cash generated by operating activities of $27.2 billion was a result of $17.9 billion of net income, non-cash adjustments to net income of $5.4 billion and an increase in the net change in operating assets and liabilities of $3.9 billion. Cash used in investing activities of $19.1 billion during the three months ended December 31, 2016 consisted primarily of cash used for purchases of marketable securities, net of sales and maturities, of $15.6 billion and cash used to acquire property, plant and equipment of $3.3 billion. Cash used in financing activities of $12.2 billion during the three months ended December 31, 2016 consisted primarily of cash used to repurchase common stock of $10.9 billion and cash used to pay dividends and dividend equivalents of $3.1 billion, partially offset by proceeds from commercial paper, net of $2.4 billion.

[0000320193-18-000007:mdna:111]
[same as prior period, unchanged from 0000320193-17-000009:mdna:108]

[0000320193-18-000007:mdna:112]
The Company’s capital expenditures were $2.2 billion during the first three months of 2018. The Company anticipates utilizing approximately $16.0 billion for capital expenditures during 2018, which includes product tooling and manufacturing process equipment; data centers; corporate facilities and infrastructure, including information systems hardware, software and enhancements; and retail store facilities.

[0000320193-18-000007:mdna:113]
[same as prior period, unchanged from 0000320193-17-000009:mdna:110]

[0000320193-18-000007:mdna:114]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses the net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of December 30, 2017, the Company had $12.0 billion of Commercial Paper outstanding, with a weighted-average interest rate of 1.33% and maturities generally less than nine months.

[0000320193-18-000007:mdna:115]
As of December 30, 2017, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $111.0 billion (collectively the “Notes”). The Company has entered, and in the future may enter, into interest rate swaps to manage interest rate risk on the Notes. In addition, the Company has entered, and in the future may enter, into foreign currency swaps to manage foreign currency risk on the Notes.

[0000320193-18-000007:mdna:116]
[same as prior period, unchanged from 0000320193-17-000009:mdna:113]

[0000320193-18-000007:mdna:117]
[same as prior period, unchanged from 0000320193-17-000009:mdna:114]

[0000320193-18-000007:mdna:118]
In May 2017, the Company’s Board of Directors increased the total capital return program from $250 billion to $300 billion, which included an increase in the share repurchase authorization from $175 billion to $210 billion of the Company’s common stock. Additionally, the Company announced that the Board of Directors raised the Company’s quarterly cash dividend from $0.57 to $0.63 per share, beginning with the dividend paid during the third quarter of 2017. The Company intends to increase its dividend on an annual basis, subject to declaration by the Board of Directors.

[0000320193-18-000007:mdna:119]
As of December 30, 2017, $176 billion of the share repurchase program had been utilized. The Company’s share repurchase program does not obligate it to acquire any specific number of shares. Under the program, shares may be repurchased in privately negotiated or open market transactions, including under plans complying with Rule 10b5-1 under the Exchange Act.

[0000320193-18-000007:mdna:120]
The following table presents the Company’s dividends, dividend equivalents, share repurchases and net share settlement activity from the start of the capital return program in August 2012 through December 30, 2017 (in millions):

[0000320193-18-000007:mdna:121]
|  | Dividends andDividend Equivalents Paid |  | Accelerated ShareRepurchases |  | Open MarketShare Repurchases |  | Taxes Related to Settlement of Equity Awards |  | Total |
| Q1 2018 | $ | 3,339 |  |  | $ | 5,000 |  |  | $ | 5,109 |  |  | $ | 1,038 |  |  | $ | 14,486 |  |
| 2017 | 12,769 |  |  | 15,000 |  |  | 18,001 |  |  | 1,874 |  |  | 47,644 |  |
| 2016 | 12,150 |  |  | 12,000 |  |  | 17,000 |  |  | 1,570 |  |  | 42,720 |  |
| 2015 | 11,561 |  |  | 6,000 |  |  | 30,026 |  |  | 1,499 |  |  | 49,086 |  |
| 2014 | 11,126 |  |  | 21,000 |  |  | 24,000 |  |  | 1,158 |  |  | 57,284 |  |
| 2013 | 10,564 |  |  | 13,950 |  |  | 9,000 |  |  | 1,082 |  |  | 34,596 |  |
| 2012 | 2,488 |  |  | — |  |  | — |  |  | 56 |  |  | 2,544 |  |
| Total | $ | 63,997 |  |  | $ | 72,950 |  |  | $ | 103,136 |  |  | $ | 8,277 |  |  | $ | 248,360 |  |

[0000320193-18-000007:mdna:122]
The Company expects to execute its capital return program by the end of March 2019 by paying dividends and dividend equivalents, repurchasing shares and remitting withheld taxes related to net share settlement of restricted stock units. The Company plans to use current cash and cash generated from ongoing operating activities to fund its capital return program.

[0000320193-18-000007:mdna:123]
[same as prior period, unchanged from 0000320193-17-000009:mdna:120]

[0000320193-18-000007:mdna:124]
[same as prior period, unchanged from 0000320193-17-000009:mdna:121]

[0000320193-18-000007:mdna:125]
[same as prior period, unchanged from 0000320193-17-000009:mdna:122]

[0000320193-18-000007:mdna:126]
As of December 30, 2017, the Company’s total future minimum lease payments under noncancelable operating leases were $9.6 billion. The Company’s retail store and other facility leases typically have original terms not exceeding 10 years and generally contain multi-year renewal options.

[0000320193-18-000007:mdna:127]
[same as prior period, unchanged from 0000320193-17-000009:mdna:124]

[0000320193-18-000007:mdna:128]
The Company utilizes several outsourcing partners to manufacture sub-assemblies for the Company’s products and to perform final assembly and testing of finished products. These outsourcing partners acquire components and build product based on demand information supplied by the Company, which typically covers periods up to 150 days. The Company also obtains individual components for its products from a wide variety of individual suppliers. As of December 30, 2017, the Company expects to pay $33.5 billion under manufacturing-related supplier arrangements, substantially all of which is noncancelable.

[0000320193-18-000007:mdna:129]
[same as prior period, unchanged from 0000320193-17-000009:mdna:126]

[0000320193-18-000007:mdna:130]
The Company’s other purchase obligations consisted of noncancelable obligations to acquire capital assets, including product tooling and manufacturing process equipment, and noncancelable obligations related to advertising, licensing, R&D, internet and telecommunications services and other obligations. As of December 30, 2017, the Company had other purchase obligations of $7.2 billion.

[0000320193-18-000007:mdna:131]
Other Non-Current Liabilities

[0000320193-18-000007:mdna:132]
The Company’s other non-current liabilities in the Condensed Consolidated Balance Sheets consist primarily of long-term taxes payable of $34.9 billion, and net unrecognized tax benefits and related interest and penalties of $6.8 billion. The Company plans to pay the tax payable in installments in accordance with the Act. The Company is unable to make a reasonably reliable estimate of the timing of payments related to unrecognized tax benefits due to uncertainties in the timing of tax audit outcomes.

[0000320193-18-000007:mdna:133]
[same as prior period, unchanged from 0000320193-17-000009:mdna:129]

[0000320193-18-000007:mdna:134]
[same as prior period, unchanged from 0000320193-17-000009:mdna:130]

[0000320193-18-000007:mdna:135]
The Company offers an iPhone Upgrade Program, which is available to customers who purchase a qualifying iPhone in the U.S., the U.K. and mainland China. The iPhone Upgrade Program provides customers the right to trade in that iPhone for a specified amount when purchasing a new iPhone, provided certain conditions are met. The Company accounts for the trade-in right as a guarantee liability and recognizes arrangement revenue net of the fair value of such right, with subsequent changes to the guarantee liability recognized within revenue.

[0000320193-18-000007:mdna:136]
The Company has entered into indemnification agreements with its directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers of the Company and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. While the Company maintains directors and officers liability insurance coverage, such insurance coverage may be insufficient to cover all losses or all types of claims that may arise.

[0000320193-18-000007:mdna:137]
[same as prior period, unchanged from 0000320193-17-000009:mdna:133]

[0000320193-18-000007:mdna:138]
[same as prior period, unchanged from 0000320193-17-000009:mdna:134]

[0000320193-18-000007:mdna:139]
Note 1, “Summary of Significant Accounting Policies” in Part I, Item 1 of this Form 10-Q and in the Notes to Consolidated Financial Statements in Part II, Item 8 of the 2017 Form 10-K, and “Critical Accounting Policies and Estimates” in Part II, Item 7 of the 2017 Form 10-K describe the significant accounting policies and methods used in the preparation of the Company’s condensed consolidated financial statements. With the exception of Income Taxes, there have been no material changes to the Company’s critical accounting policies and estimates since the 2017 Form 10-K.

[0000320193-18-000007:mdna:140]
Income Taxes

[0000320193-18-000007:mdna:141]
The Company records a tax provision for the anticipated tax consequences of its reported operating results. The provision for income taxes is computed using the asset and liability method, under which deferred tax assets and liabilities are recognized for the expected future tax consequences of temporary differences between the financial reporting and tax bases of assets and liabilities, and for operating losses and tax credit carryforwards. Deferred tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets and liabilities are expected to be realized or settled. The Company records a valuation allowance to reduce deferred tax assets to the amount that is believed more likely than not to be realized.

[0000320193-18-000007:mdna:142]
The Company recognizes tax benefits from uncertain tax positions only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement.

[0000320193-18-000007:mdna:143]
Management believes it is more likely than not that forecasted income, including income that may be generated as a result of certain tax planning strategies, together with future reversals of existing taxable temporary differences, will be sufficient to fully recover the Company’s deferred tax assets. In the event that the Company determines all or part of its net deferred tax assets are not realizable in the future, the Company will record an adjustment to the valuation allowance that would be charged to earnings in the period such determination is made. In addition, the calculation of tax liabilities involves significant judgment in estimating the impact of uncertainties in the application of GAAP and complex tax laws. Resolution of these uncertainties in a manner inconsistent with management’s expectations could have a material impact on the Company’s financial condition and operating results.

[0000320193-18-000007:mdna:144]
On December 22, 2017, the U.S. enacted the Act, which significantly changed U.S. tax law. The Act lowered the Company’s U.S. statutory federal income tax rate from 35% to 21% effective January 1, 2018, while also imposing a deemed repatriation tax on deferred foreign income. The Act also created a new minimum tax on certain future foreign earnings. During the first quarter of 2018, the Company recognized a provision for income taxes of $7.0 billion, of which $2.6 billion was considered a provisional estimate under the SEC Staff Accounting Bulletin No. 118. The Company’s provisional estimate of $2.6 billion included $1.8 billion related to the impact of remeasuring the Company’s deferred tax balances to reflect the new tax rate and approximately $800 million, net, associated with the deemed repatriation tax. Resolution of the provisional estimates of the Act’s effects different from the assumptions made by the Company could have a material impact on the Company’s financial condition and operating results.
