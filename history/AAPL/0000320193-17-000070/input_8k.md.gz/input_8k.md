# AAPL 8-K — 0000320193-17-000067 filed 2017-11-02

## item codes, every 8-K on or before 2017-11-03

- 2017-11-02 0000320193-17-000067 — 2.02, 9.01
- 2017-10-12 0001193125-17-308859 — 5.02
- 2017-09-12 0001193125-17-282809 — 8.01, 9.01
- 2017-08-18 0001193125-17-262261 — 8.01, 9.01
- 2017-08-01 0000320193-17-000006 — 2.02, 9.01
- 2017-06-20 0001193125-17-208226 — 8.01, 9.01
- 2017-05-24 0001193125-17-181867 — 8.01, 9.01
- 2017-05-11 0001193125-17-167400 — 8.01, 9.01
- 2017-05-02 0001628280-17-004663 — 2.02, 9.01
- 2017-03-03 0001193125-17-069853 — 8.01, 9.01
- 2017-03-01 0001193125-17-064019 — 5.07
- 2017-02-09 0001193125-17-036283 — 8.01, 9.01
- 2017-01-31 0001628280-17-000663 — 2.02, 9.01
- 2016-12-15 0001628280-16-022047 — 5.03, 9.01
- 2016-10-25 0001628280-16-020258 — 2.02, 9.01
- 2016-08-04 0001193125-16-672044 — 8.01, 9.01
- 2016-07-26 0001628280-16-017762 — 2.02, 9.01
- 2016-06-22 0001193125-16-628957 — 8.01, 9.01
- 2016-04-26 0001193125-16-556520 — 2.02, 9.01
- 2016-03-24 0001193125-16-516891 — 8.01, 9.01
- 2016-03-01 0001193125-16-488223 — 5.02, 5.07, 9.01
- 2016-02-23 0001193125-16-473562 — 8.01, 9.01
- 2016-01-26 0001193125-16-438421 — 2.02, 9.01
- 2015-12-22 0001193125-15-410853 — 5.03, 9.01
- 2015-12-17 0001193125-15-406279 — 5.02
- 2015-10-27 0001193125-15-354756 — 2.02, 9.01
- 2015-10-02 0001193125-15-336615 — 5.02
- 2015-09-17 0001193125-15-322466 — 8.01, 9.01
- 2015-07-31 0001193125-15-273023 — 8.01, 9.01
- 2015-07-21 0001193125-15-258464 — 2.02, 9.01
- 2015-06-10 0001193125-15-219298 — 8.01, 9.01
- 2015-05-13 0001193125-15-186064 — 8.01, 9.01
- 2015-04-27 0001193125-15-149607 — 7.01, 9.01
- 2015-04-27 0001193125-15-149590 — 2.02, 9.01
- 2015-03-13 0001104659-15-019336 — 5.07, 9.01
- 2015-02-09 0001193125-15-039270 — 8.01, 9.01
- 2015-01-28 0001193125-15-023732 — 8.01, 9.01
- 2015-01-27 0001193125-15-021857 — 2.02, 9.01
- 2014-11-10 0001193125-14-406296 — 8.01, 9.01
- 2014-10-20 0001193125-14-376361 — 2.02, 9.01
- 2014-07-23 0001193125-14-277193 — 8.01, 9.01
- 2014-07-22 0001193125-14-275598 — 2.02, 9.01
- 2014-07-17 0001193125-14-271698 — 5.02
- 2014-06-06 0001193125-14-228798 — 5.03, 9.01
- 2014-05-30 0001181431-14-021923 — 5.02
- 2014-05-06 0001193125-14-184969 — 8.01, 9.01
- 2014-04-23 0001193125-14-154883 — 7.01, 9.01
- 2014-04-23 0001193125-14-154871 — 2.02, 9.01
- 2014-03-05 0001193125-14-084697 — 5.02, 5.03, 5.07, 9.01
- 2014-01-27 0001193125-14-022238 — 2.02, 9.01
- 2013-10-28 0001193125-13-413498 — 2.02, 9.01
- 2013-09-23 0001181431-13-050140 — 8.01
- 2013-07-30 0001181431-13-041847 — 5.02
- 2013-07-23 0001193125-13-298914 — 2.02, 9.01
- 2013-06-21 0001193125-13-267629 — 5.02
- 2013-05-03 0001193125-13-199324 — 8.01, 9.01
- 2013-04-24 0001193125-13-170623 — 8.01, 9.01
- 2013-04-23 0001193125-13-167469 — 7.01, 9.01
- 2013-04-23 0001193125-13-167458 — 2.02, 9.01
- 2013-03-01 0001193125-13-085842 — 5.07
- 2013-01-23 0001193125-13-020783 — 2.02, 9.01
- 2012-10-25 0001193125-12-435506 — 2.02, 9.01
- 2012-07-24 0001193125-12-312355 — 2.02, 9.01
- 2012-06-28 0001181431-12-038301 — 5.02
- 2012-05-24 0001181431-12-032458 — 5.02
- 2012-04-24 0001193125-12-178928 — 2.02, 9.01
- 2012-02-27 0001193125-12-081892 — 5.07
- 2012-01-24 0001193125-12-021833 — 2.02, 9.01
- 2011-11-16 0001181431-11-056354 — 5.02
- 2011-10-18 0001193125-11-273826 — 2.02, 9.01
- 2011-10-06 0001181431-11-051976 — 8.01
- 2011-08-26 0001181431-11-047179 — 5.02
- 2011-07-19 0001193125-11-191368 — 2.02, 9.01
- 2011-06-15 0001181431-11-036782 — 5.02
- 2011-04-20 0001193125-11-103732 — 2.02, 9.01
- 2011-02-24 0001193125-11-045411 — 5.07
- 2011-01-18 0001193125-11-009392 — 2.02, 9.01
- 2011-01-18 0001181431-11-003847 — 5.02
- 2010-11-17 0001181431-10-056327 — 5.02, 5.03, 9.01
- 2010-10-18 0001193125-10-230992 — 2.02, 9.01
- 2010-07-20 0001193125-10-161807 — 2.02, 9.01
- 2010-04-20 0001193125-10-087786 — 2.02, 9.01
- 2010-03-12 0001181431-10-016054 — 5.02
- 2010-03-01 0001193125-10-044765 — 5.02, 5.07, 9.01
- 2010-01-25 0001193125-10-012096 — 2.02, 9.01
- 2009-10-19 0001193125-09-209633 — 2.02, 9.01
- 2009-08-04 0001181431-09-037492 — 5.02
- 2009-07-21 0001193125-09-152290 — 2.02, 9.01
- 2009-06-02 0001181431-09-028400 — 5.03
- 2009-04-22 0001193125-09-084599 — 2.02, 9.01
- 2009-02-27 0001181431-09-012161 — 4.01
- 2009-01-21 0001193125-09-009009 — 2.02, 9.01
- 2009-01-16 0001181431-09-003017 — 5.02
- 2008-10-21 0001193125-08-213642 — 2.02, 9.01
- 2008-08-26 0001181431-08-050059 — 5.03
- 2008-07-21 0001193125-08-154381 — 2.02, 9.01
- 2008-06-09 0001181431-08-037620 — 8.01
- 2008-04-23 0001193125-08-088001 — 2.02, 9.01
- 2008-01-22 0001193125-08-009715 — 2.02, 9.01
- 2008-01-15 0001181431-08-003342 — 2.02, 8.01
- 2008-01-08 0001181431-08-002372 — 5.02
- 2007-10-22 0001104659-07-076142 — 2.02, 9.01
- 2007-07-25 0001104659-07-056111 — 2.02, 9.01
- 2007-05-16 0001104659-07-040672 — 5.02, 9.01
- 2007-04-25 0001104659-07-031354 — 2.02, 9.01
- 2007-04-24 0001104659-07-030938 — 8.01, 9.01
- 2007-02-21 0001104659-07-012760 — 5.03, 9.01
- 2007-01-17 0001104659-07-002905 — 2.02, 9.01
- 2007-01-10 0001104659-07-001648 — 5.03, 9.01
- 2006-10-27 0001104659-06-069015 — 8.01
- 2006-10-18 0001104659-06-067275 — 2.02, 9.01
- 2006-10-04 0001104659-06-064935 — 5.02, 8.01, 9.01
- 2006-09-01 0001104659-06-058808 — 1.01, 5.02, 5.03, 9.01
- 2006-08-11 0001104659-06-054118 — 2.02, 3.01, 9.01
- 2006-08-04 0001104659-06-051302 — 2.02, 4.02, 9.01
- 2006-07-19 0001104659-06-047739 — 2.02, 9.01
- 2006-04-21 0001181431-06-024759 — 1.01
- 2006-04-19 0001104659-06-025992 — 2.02, 9.01
- 2006-01-18 0001104659-06-002690 — 2.02, 9.01
- 2006-01-10 0001104659-06-001428 — 2.02
- 2005-12-19 0001181431-05-067468 — 1.01
- 2005-10-14 0001181431-05-056604 — 5.02
- 2005-10-11 0001104659-05-048094 — 2.02, 9.01
- 2005-08-26 0001181431-05-049163 — 1.01
- 2005-08-15 0001181431-05-046871 — 1.01
- 2005-07-13 0001104659-05-032297 — 2.02, 9.01
- 2005-06-06 0001181431-05-033177 — 8.01
- 2005-04-26 0001181431-05-023450 — 1.01
- 2005-04-13 0001104659-05-016307 — 2.02, 9.01
- 2005-03-02 0001181431-05-013840 — 3.03, 5.03
- 2005-02-11 0001104659-05-005507 — 8.01
- 2005-01-12 0001104659-05-001183 — 2.02, 9.01
- 2005-01-11 0001104659-05-001049 — 2.02
- 2004-10-13 0001104659-04-030400 — 2.02, 9.01
- 2004-07-14 0001104659-04-019574 — 12, 7
- 2004-04-14 0001104659-04-010122 — 12, 7
- 2004-01-14 0001104659-04-000896 — 12, 7
- 2003-10-15 0001104659-03-022879 — 12, 7
- 2003-07-16 0001104659-03-014913 — 7, 9
- 2003-04-16 0001047469-03-013617 — 7, 9
- 2003-03-21 0001104659-03-004649 — 5, 7
- 2002-08-13 0000912057-02-031595 — 5, 7
- 2002-08-05 0000912057-02-029692 — 5, 7
- 2000-01-24 0000912057-00-002128 — 5, 7
- 1999-09-07 0000320193-99-000010 — 2
- 1999-07-16 0000320193-99-000007 — 2
- 1998-12-23 0000320193-98-000010 — 1
- 1998-01-08 0000320193-98-000001 — 2
- 1997-09-25 0000320193-97-000019 — 2
- 1997-09-25 0000320193-97-000018 — 2
- 1997-09-05 0000320193-97-000016 — 2
- 1997-07-28 0000320193-97-000012 — 4
- 1997-04-25 0000320193-97-000009 — 5
- 1997-04-10 0000320193-97-000007 — 7
- 1996-12-24 0000320193-96-000027 — 7
- 1996-12-23 0000320193-96-000025 — 4 — amendment of 0000320193-96-000021
- 1996-12-13 0000320193-96-000021 — 4
- 1996-10-28 0000912057-96-023874 — 5, 7
- 1996-06-17 0000320193-96-000014 — 1
- 1996-04-12 0000320193-96-000006 — 1

## late-filing notifications on or before 2017-11-03

- 2006-12-15 0001104659-06-081617 — NT 10-K, for the period ended 2006-09-30
- 2006-08-11 0001104659-06-053743 — NT 10-Q, for the period ended 2006-07-01

## item 2.02 — earnings release, exhibit 99.1

[0000320193-17-000067:8k_2_02:1]
EX-99.1
2
a8-kexhibit991q420179302017.htm
EXHIBIT 99.1

[0000320193-17-000067:8k_2_02:2]
Exhibit

[0000320193-17-000067:8k_2_02:3]
Exhibit 99.1

[0000320193-17-000067:8k_2_02:4]
Apple Reports Fourth Quarter Results

[0000320193-17-000067:8k_2_02:5]
Revenue Up 12 Percent and EPS Up 24 Percent to New September Quarter Records

[0000320193-17-000067:8k_2_02:6]
Services Revenue Reaches All-Time High

[0000320193-17-000067:8k_2_02:7]
CUPERTINO, California — November 2, 2017 — Apple® today announced financial results for its fiscal 2017 fourth quarter ended September 30, 2017. The Company posted quarterly revenue of $52.6 billion, an increase of 12 percent from the year-ago quarter, and quarterly earnings per diluted share of $2.07, up 24 percent. International sales accounted for 62 percent of the quarter’s revenue.

[0000320193-17-000067:8k_2_02:8]
“We’re happy to report a very strong finish to a great fiscal 2017, with record fourth quarter revenue, year-over-year growth for all our product categories, and our best quarter ever for Services,” said Tim Cook, Apple’s CEO. “With fantastic new products including iPhone 8 and iPhone 8 Plus, Apple Watch Series 3, and Apple TV 4K joining our product lineup, we’re looking forward to a great holiday season, and with the launch of iPhone X getting underway right now, we couldn’t be more excited as we begin to deliver our vision for the future with this stunning device.”

[0000320193-17-000067:8k_2_02:9]
“Apple’s year-over-year revenue growth rate accelerated for the fourth consecutive quarter and drove EPS growth of 24 percent in the September quarter,” said Luca Maestri, Apple’s CFO. “We also generated strong operating cash flow of $15.7 billion and returned $11 billion to investors through our capital return program.”

[0000320193-17-000067:8k_2_02:10]
Apple is providing the following guidance for its fiscal 2018 first quarter:

[0000320193-17-000067:8k_2_02:11]
| • | revenue between $84 billion and $87 billion |

[0000320193-17-000067:8k_2_02:12]
| • | gross margin between 38 percent and 38.5 percent |

[0000320193-17-000067:8k_2_02:13]
| • | operating expenses between $7.65 billion and $7.75 billion |

[0000320193-17-000067:8k_2_02:14]
| • | other income/(expense) of $600 million |

[0000320193-17-000067:8k_2_02:15]
| • | tax rate of 25.5 percent |

[0000320193-17-000067:8k_2_02:16]
Apple’s board of directors has declared a cash dividend of $0.63 per share of the Company’s common stock. The dividend is payable on November 16, 2017 to shareholders of record as of the close of business on November 13, 2017.

[0000320193-17-000067:8k_2_02:17]
Apple will provide live streaming of its Q4 2017 financial results conference call beginning at 2:00 p.m. PDT on November 2, 2017 at www.apple.com/investor/earnings-call/. This webcast will also be available for replay for approximately two weeks thereafter.

[0000320193-17-000067:8k_2_02:18]
Apple revolutionized personal technology with the introduction of the Macintosh in 1984. Today, Apple leads the world in innovation with iPhone, iPad, Mac, Apple Watch and Apple TV. Apple’s four software platforms — iOS, macOS, watchOS and tvOS — provide seamless experiences across all Apple devices and empower people with breakthrough services including the App Store, Apple Music, Apple Pay and iCloud. Apple’s more than 100,000 employees are dedicated to making the best products on earth, and to leaving the world better than we found it.

[0000320193-17-000067:8k_2_02:19]
Press Contact:

[0000320193-17-000067:8k_2_02:20]
Kristin Huguet

[0000320193-17-000067:8k_2_02:21]
Apple

[0000320193-17-000067:8k_2_02:22]
khuguet@apple.com

[0000320193-17-000067:8k_2_02:23]
(408) 974-2414

[0000320193-17-000067:8k_2_02:24]
Investor Relations Contacts:

[0000320193-17-000067:8k_2_02:25]
Nancy Paxton

[0000320193-17-000067:8k_2_02:26]
Apple

[0000320193-17-000067:8k_2_02:27]
paxton1@apple.com

[0000320193-17-000067:8k_2_02:28]
(408) 974-5420

[0000320193-17-000067:8k_2_02:29]
Joan Hoover

[0000320193-17-000067:8k_2_02:30]
Apple

[0000320193-17-000067:8k_2_02:31]
hoover1@apple.com

[0000320193-17-000067:8k_2_02:32]
(408) 974-4570

[0000320193-17-000067:8k_2_02:33]
NOTE TO EDITORS: For additional information visit the Apple Newsroom (www.apple.com/newsroom), or call Apple’s Media Helpline at (408) 974-2042.

[0000320193-17-000067:8k_2_02:34]
© 2017 Apple Inc. All rights reserved. Apple and the Apple logo are trademarks of Apple. Other company and product names may be trademarks of their respective owners.

[0000320193-17-000067:8k_2_02:35]
Apple Inc.

[0000320193-17-000067:8k_2_02:36]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS (Unaudited)

[0000320193-17-000067:8k_2_02:37]
(In millions, except number of shares which are reflected in thousands and per share amounts)

[0000320193-17-000067:8k_2_02:38]
|  | Three Months Ended |  | Twelve Months Ended |
|  | September 30, 2017 |  | September 24, 2016 |  | September 30, 2017 |  | September 24, 2016 |
| Net sales | $ | 52,579 |  |  | $ | 46,852 |  |  | $ | 229,234 |  |  | $ | 215,639 |  |
| Cost of sales (1) | 32,648 |  |  | 29,039 |  |  | 141,048 |  |  | 131,376 |  |
| Gross margin | 19,931 |  |  | 17,813 |  |  | 88,186 |  |  | 84,263 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development (1) | 2,997 |  |  | 2,570 |  |  | 11,581 |  |  | 10,045 |  |
| Selling, general and administrative (1) | 3,814 |  |  | 3,482 |  |  | 15,261 |  |  | 14,194 |  |
| Total operating expenses | 6,811 |  |  | 6,052 |  |  | 26,842 |  |  | 24,239 |  |
| Operating income | 13,120 |  |  | 11,761 |  |  | 61,344 |  |  | 60,024 |  |
| Other income/(expense), net | 797 |  |  | 427 |  |  | 2,745 |  |  | 1,348 |  |
| Income before provision for income taxes | 13,917 |  |  | 12,188 |  |  | 64,089 |  |  | 61,372 |  |
| Provision for income taxes | 3,203 |  |  | 3,174 |  |  | 15,738 |  |  | 15,685 |  |
| Net income | $ | 10,714 |  |  | $ | 9,014 |  |  | $ | 48,351 |  |  | $ | 45,687 |  |
| Earnings per share: |  |  |  |  |  |  |  |
| Basic | $ | 2.08 |  |  | $ | 1.68 |  |  | $ | 9.27 |  |  | $ | 8.35 |  |
| Diluted | $ | 2.07 |  |  | $ | 1.67 |  |  | $ | 9.21 |  |  | $ | 8.31 |  |
| Shares used in computing earnings per share: |  |  |  |  |  |  |  |
| Basic | 5,149,428 |  |  | 5,366,912 |  |  | 5,217,242 |  |  | 5,470,820 |  |
| Diluted | 5,183,585 |  |  | 5,393,333 |  |  | 5,251,692 |  |  | 5,500,281 |  |
| Cash dividends declared per share | $ | 0.63 |  |  | $ | 0.57 |  |  | $ | 2.40 |  |  | $ | 2.18 |  |
| (1) Includes share-based compensation expense as follows: |
| Cost of sales | $ | 215 |  |  | $ | 186 |  |  | $ | 877 |  |  | $ | 769 |  |
| Research and development | $ | 569 |  |  | $ | 476 |  |  | $ | 2,299 |  |  | $ | 1,889 |  |
| Selling, general and administrative | $ | 390 |  |  | $ | 368 |  |  | $ | 1,664 |  |  | $ | 1,552 |  |

[0000320193-17-000067:8k_2_02:39]
Apple Inc.

[0000320193-17-000067:8k_2_02:40]
CONDENSED CONSOLIDATED BALANCE SHEETS (Unaudited)

[0000320193-17-000067:8k_2_02:41]
(In millions, except number of shares which are reflected in thousands and par value)

[0000320193-17-000067:8k_2_02:42]
|  | September 30, 2017 |  | September 24, 2016 |
| ASSETS: |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 20,289 |  |  | $ | 20,484 |  |
| Short-term marketable securities | 53,892 |  |  | 46,671 |  |
| Accounts receivable, less allowances of $58 and $53, respectively | 17,874 |  |  | 15,754 |  |
| Inventories | 4,855 |  |  | 2,132 |  |
| Vendor non-trade receivables | 17,799 |  |  | 13,545 |  |
| Other current assets | 13,936 |  |  | 8,283 |  |
| Total current assets | 128,645 |  |  | 106,869 |  |
| Long-term marketable securities | 194,714 |  |  | 170,430 |  |
| Property, plant and equipment, net | 33,783 |  |  | 27,010 |  |
| Goodwill | 5,717 |  |  | 5,414 |  |
| Acquired intangible assets, net | 2,298 |  |  | 3,206 |  |
| Other non-current assets | 10,162 |  |  | 8,757 |  |
| Total assets | $ | 375,319 |  |  | $ | 321,686 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY: |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 49,049 |  |  | $ | 37,294 |  |
| Accrued expenses | 25,744 |  |  | 22,027 |  |
| Deferred revenue | 7,548 |  |  | 8,080 |  |
| Commercial paper | 11,977 |  |  | 8,105 |  |
| Current portion of long-term debt | 6,496 |  |  | 3,500 |  |
| Total current liabilities | 100,814 |  |  | 79,006 |  |
| Deferred revenue, non-current | 2,836 |  |  | 2,930 |  |
| Long-term debt | 97,207 |  |  | 75,427 |  |
| Other non-current liabilities | 40,415 |  |  | 36,074 |  |
| Total liabilities | 241,272 |  |  | 193,437 |  |
| Commitments and contingencies |  |  |  |
| Shareholders’ equity: |  |  |  |
| Common stock and additional paid-in capital, $0.00001 par value: 12,600,000 shares authorized; 5,126,201 and 5,336,166 shares issued and outstanding, respectively | 35,867 |  |  | 31,251 |  |
| Retained earnings | 98,330 |  |  | 96,364 |  |
| Accumulated other comprehensive income/(loss) | (150 | ) |  | 634 |  |
| Total shareholders’ equity | 134,047 |  |  | 128,249 |  |
| Total liabilities and shareholders’ equity | $ | 375,319 |  |  | $ | 321,686 |  |

[0000320193-17-000067:8k_2_02:43]
Apple Inc.

[0000320193-17-000067:8k_2_02:44]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (Unaudited)

[0000320193-17-000067:8k_2_02:45]
(In millions)

[0000320193-17-000067:8k_2_02:46]
|  | Twelve Months Ended |
|  | September 30, 2017 |  | September 24, 2016 |
| Cash and cash equivalents, beginning of the period | $ | 20,484 |  |  | $ | 21,120 |  |
| Operating activities: |  |  |  |
| Net income | 48,351 |  |  | 45,687 |  |
| Adjustments to reconcile net income to cash generated by operating activities: |  |  |  |
| Depreciation and amortization | 10,157 |  |  | 10,505 |  |
| Share-based compensation expense | 4,840 |  |  | 4,210 |  |
| Deferred income tax expense | 5,966 |  |  | 4,938 |  |
| Other | (166 | ) |  | 486 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | (2,093 | ) |  | 527 |  |
| Inventories | (2,723 | ) |  | 217 |  |
| Vendor non-trade receivables | (4,254 | ) |  | (51 | ) |
| Other current and non-current assets | (5,318 | ) |  | 1,055 |  |
| Accounts payable | 9,618 |  |  | 1,837 |  |
| Deferred revenue | (626 | ) |  | (1,554 | ) |
| Other current and non-current liabilities | (154 | ) |  | (2,033 | ) |
| Cash generated by operating activities | 63,598 |  |  | 65,824 |  |
| Investing activities: |  |  |  |
| Purchases of marketable securities | (159,486 | ) |  | (142,428 | ) |
| Proceeds from maturities of marketable securities | 31,775 |  |  | 21,258 |  |
| Proceeds from sales of marketable securities | 94,564 |  |  | 90,536 |  |
| Payments made in connection with business acquisitions, net | (329 | ) |  | (297 | ) |
| Payments for acquisition of property, plant and equipment | (12,451 | ) |  | (12,734 | ) |
| Payments for acquisition of intangible assets | (344 | ) |  | (814 | ) |
| Payments for strategic investments, net | (395 | ) |  | (1,388 | ) |
| Other | 220 |  |  | (110 | ) |
| Cash used in investing activities | (46,446 | ) |  | (45,977 | ) |
| Financing activities: |  |  |  |
| Proceeds from issuance of common stock | 555 |  |  | 495 |  |
| Excess tax benefits from equity awards | 627 |  |  | 407 |  |
| Payments for taxes related to net share settlement of equity awards | (1,874 | ) |  | (1,570 | ) |
| Payments for dividends and dividend equivalents | (12,769 | ) |  | (12,150 | ) |
| Repurchases of common stock | (32,900 | ) |  | (29,722 | ) |
| Proceeds from issuance of term debt, net | 28,662 |  |  | 24,954 |  |
| Repayments of term debt | (3,500 | ) |  | (2,500 | ) |
| Change in commercial paper, net | 3,852 |  |  | (397 | ) |
| Cash used in financing activities | (17,347 | ) |  | (20,483 | ) |
| Increase/(Decrease) in cash and cash equivalents | (195 | ) |  | (636 | ) |
| Cash and cash equivalents, end of the period | $ | 20,289 |  |  | $ | 20,484 |  |
| Supplemental cash flow disclosure: |  |  |  |
| Cash paid for income taxes, net | $ | 11,591 |  |  | $ | 10,444 |  |
| Cash paid for interest | $ | 2,092 |  |  | $ | 1,316 |  |
