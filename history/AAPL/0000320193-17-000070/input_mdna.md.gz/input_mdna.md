# AAPL MD&A — 0000320193-17-000070


## mdna

[0000320193-17-000070:mdna:1]
| Item 7. | Management’s Discussion and Analysis of Financial Condition and Results of Operations |

[0000320193-17-000070:mdna:2]
Overview and Highlights

[0000320193-17-000070:mdna:3]
The Company designs, manufactures and markets mobile communication and media devices and personal computers, and sells a variety of related software, services, accessories, networking solutions and third-party digital content and applications. The Company’s products and services include iPhone, iPad, Mac, Apple Watch, Apple TV, a portfolio of consumer and professional software applications, iOS, macOS, watchOS and tvOS operating systems, iCloud, Apple Pay and a variety of accessory, service and support offerings. The Company sells and delivers digital content and applications through the iTunes Store, App Store, Mac App Store, TV App Store, iBooks Store and Apple Music (collectively “Digital Content and Services”). The Company sells its products worldwide through its retail stores, online stores and direct sales force, as well as through third-party cellular network carriers, wholesalers, retailers and value-added resellers. In addition, the Company sells a variety of third-party Apple-compatible products, including application software and various accessories through its retail and online stores. The Company sells to consumers, small and mid-sized businesses and education, enterprise and government customers.

[0000320193-17-000070:mdna:4]
Fiscal Period

[0000320193-17-000070:mdna:5]
The Company’s fiscal year is the 52 or 53-week period that ends on the last Saturday of September. The Company’s fiscal year 2017 included 53 weeks and ended on September 30, 2017. A 14th week was included in the first quarter of 2017, as is done every five or six years, to realign the Company’s fiscal quarters with calendar quarters. The Company’s fiscal years 2016 and 2015 ended on September 24, 2016 and September 26, 2015, respectively, and spanned 52 weeks each.

[0000320193-17-000070:mdna:6]
Fiscal 2017 Highlights

[0000320193-17-000070:mdna:7]
Net sales increased 6% or $13.6 billion during 2017 compared to 2016, primarily driven by growth in Services, iPhone and Mac. The year-over-year increase in net sales reflected growth in each of the geographic operating segments, with the exception of Greater China. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on net sales during 2017 compared to 2016. In May 2017, the Company announced an increase to its capital return program by raising the expected total size of the program from $250 billion to $300 billion through March 2019. This included increasing its share repurchase authorization from $175 billion to $210 billion and raising its quarterly dividend from $0.57 to $0.63 per share beginning in May 2017. During 2017, the Company spent $33.0 billion to repurchase shares of its common stock and paid dividends and dividend equivalents of $12.8 billion. Additionally, the Company issued $24.0 billion of U.S. dollar-denominated term debt, €2.5 billion of euro-denominated term debt and C$2.5 billion of Canadian dollar-denominated term debt during 2017.

[0000320193-17-000070:mdna:8]
Fiscal 2016 Highlights

[0000320193-17-000070:mdna:9]
Net sales declined 8% or $18.1 billion during 2016 compared to 2015, primarily driven by a year-over-year decrease in iPhone net sales and the effect of weakness in most foreign currencies relative to the U.S. dollar, partially offset by an increase in Services. In April 2016, the Company announced an increase to its capital return program by raising the expected total size of the program from $200 billion to $250 billion through March 2018. This included increasing its share repurchase authorization from $140 billion to $175 billion and raising its quarterly dividend from $0.52 to $0.57 per share beginning in May 2016. During 2016, the Company spent $29.0 billion to repurchase shares of its common stock and paid dividends and dividend equivalents of $12.2 billion. Additionally, the Company issued $23.9 billion of U.S. dollar-denominated term debt and A$1.4 billion of Australian dollar-denominated term debt during 2016.

[0000320193-17-000070:mdna:10]
Sales Data

[0000320193-17-000070:mdna:11]
The following table shows net sales by operating segment and net sales and unit sales by product for 2017, 2016 and 2015 (dollars in millions and units in thousands):

[0000320193-17-000070:mdna:12]
|  | 2017 |  | Change |  | 2016 |  | Change |  | 2015 |
| Net Sales by Operating Segment: |  |  |  |  |  |  |  |  |  |
| Americas | $ | 96,600 |  |  | 12 | % |  | $ | 86,613 |  |  | (8 | )% |  | $ | 93,864 |  |
| Europe | 54,938 |  |  | 10 | % |  | 49,952 |  |  | (1 | )% |  | 50,337 |  |
| Greater China | 44,764 |  |  | (8 | )% |  | 48,492 |  |  | (17 | )% |  | 58,715 |  |
| Japan | 17,733 |  |  | 5 | % |  | 16,928 |  |  | 8 | % |  | 15,706 |  |
| Rest of Asia Pacific | 15,199 |  |  | 11 | % |  | 13,654 |  |  | (10 | )% |  | 15,093 |  |
| Total net sales | $ | 229,234 |  |  | 6 | % |  | $ | 215,639 |  |  | (8 | )% |  | $ | 233,715 |  |
| Net Sales by Product: |  |  |  |  |  |  |  |  |  |
| iPhone (1) | $ | 141,319 |  |  | 3 | % |  | $ | 136,700 |  |  | (12 | )% |  | $ | 155,041 |  |
| iPad (1) | 19,222 |  |  | (7 | )% |  | 20,628 |  |  | (11 | )% |  | 23,227 |  |
| Mac (1) | 25,850 |  |  | 13 | % |  | 22,831 |  |  | (10 | )% |  | 25,471 |  |
| Services (2) | 29,980 |  |  | 23 | % |  | 24,348 |  |  | 22 | % |  | 19,909 |  |
| Other Products (1)(3) | 12,863 |  |  | 16 | % |  | 11,132 |  |  | 11 | % |  | 10,067 |  |
| Total net sales | $ | 229,234 |  |  | 6 | % |  | $ | 215,639 |  |  | (8 | )% |  | $ | 233,715 |  |
| Unit Sales by Product: |  |  |  |  |  |  |  |  |  |
| iPhone | 216,756 |  |  | 2 | % |  | 211,884 |  |  | (8 | )% |  | 231,218 |  |
| iPad | 43,753 |  |  | (4 | )% |  | 45,590 |  |  | (17 | )% |  | 54,856 |  |
| Mac | 19,251 |  |  | 4 | % |  | 18,484 |  |  | (10 | )% |  | 20,587 |  |

[0000320193-17-000070:mdna:13]
| (1) | Includes deferrals and amortization of related software upgrade rights and non-software services. |

[0000320193-17-000070:mdna:14]
| (2) | Includes revenue from Digital Content and Services, AppleCare, Apple Pay, licensing and other services. Services net sales in the fourth quarter of 2017 included a favorable one-time adjustment of $640 million due to a change in estimate based on the availability of additional supporting information. |

[0000320193-17-000070:mdna:15]
| (3) | Includes sales of Apple TV, Apple Watch, Beats products, iPod touch and Apple-branded and third-party accessories. |

[0000320193-17-000070:mdna:16]
Product Performance

[0000320193-17-000070:mdna:17]
iPhone

[0000320193-17-000070:mdna:18]
The following table presents iPhone net sales and unit sales information for 2017, 2016 and 2015 (dollars in millions and units in thousands):

[0000320193-17-000070:mdna:19]
|  | 2017 |  | Change |  | 2016 |  | Change |  | 2015 |
| Net sales | $ | 141,319 |  |  | 3 | % |  | $ | 136,700 |  |  | (12 | )% |  | $ | 155,041 |  |
| Percentage of total net sales | 62 | % |  |  |  |  | 63 | % |  |  |  | 66 | % |
| Unit sales | 216,756 |  |  | 2 | % |  | 211,884 |  |  | (8 | )% |  | 231,218 |  |

[0000320193-17-000070:mdna:20]
iPhone net sales increased during 2017 compared to 2016 due to higher iPhone unit sales and a different mix of iPhones with higher average selling prices. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on iPhone net sales during 2017 compared to 2016.

[0000320193-17-000070:mdna:21]
iPhone net sales decreased during 2016 compared to 2015. The Company believes the sales decline was due primarily to a lower rate of iPhone upgrades during 2016 compared to 2015 and challenging macroeconomic conditions in a number of major markets in 2016. Average selling prices for iPhone were lower year-over-year during 2016 due primarily to a different mix of iPhones, including the iPhone SE introduced in 2016, and the effect of weakness in most foreign currencies relative to the U.S. dollar.

[0000320193-17-000070:mdna:22]
iPad

[0000320193-17-000070:mdna:23]
The following table presents iPad net sales and unit sales information for 2017, 2016 and 2015 (dollars in millions and units in thousands):

[0000320193-17-000070:mdna:24]
|  | 2017 |  | Change |  | 2016 |  | Change |  | 2015 |
| Net sales | $ | 19,222 |  |  | (7 | )% |  | $ | 20,628 |  |  | (11 | )% |  | $ | 23,227 |  |
| Percentage of total net sales | 8 | % |  |  |  | 10 | % |  |  |  | 10 | % |
| Unit sales | 43,753 |  |  | (4 | )% |  | 45,590 |  |  | (17 | )% |  | 54,856 |  |

[0000320193-17-000070:mdna:25]
iPad net sales decreased during 2017 compared to 2016 due to lower iPad unit sales and a different mix of iPads with lower average selling prices. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on iPad net sales during 2017 compared to 2016.

[0000320193-17-000070:mdna:26]
iPad net sales decreased during 2016 compared to 2015 primarily due to lower unit sales and the effect of weakness in most foreign currencies relative to the U.S. dollar, partially offset by higher average selling price due to a shift in mix to higher-priced iPads.

[0000320193-17-000070:mdna:27]
Mac

[0000320193-17-000070:mdna:28]
The following table presents Mac net sales and unit sales information for 2017, 2016 and 2015 (dollars in millions and units in thousands):

[0000320193-17-000070:mdna:29]
|  | 2017 |  | Change |  | 2016 |  | Change |  | 2015 |
| Net sales | $ | 25,850 |  |  | 13 | % |  | $ | 22,831 |  |  | (10 | )% |  | $ | 25,471 |  |
| Percentage of total net sales | 11 | % |  |  |  | 11 | % |  |  |  | 11 | % |
| Unit sales | 19,251 |  |  | 4 | % |  | 18,484 |  |  | (10 | )% |  | 20,587 |  |

[0000320193-17-000070:mdna:30]
Mac net sales increased during 2017 compared to 2016 due primarily to a different mix of Macs with higher average selling prices and higher Mac unit sales. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on Mac net sales during 2017 compared to 2016.

[0000320193-17-000070:mdna:31]
Mac net sales decreased during 2016 compared to 2015 primarily due to lower year-over-year Mac unit sales, which declined at rates similar to the overall market. The effect of weakness in most foreign currencies relative to the U.S. dollar also negatively impacted Mac net sales.

[0000320193-17-000070:mdna:32]
Services

[0000320193-17-000070:mdna:33]
The following table presents Services net sales information for 2017, 2016 and 2015 (dollars in millions):

[0000320193-17-000070:mdna:34]
|  | 2017 |  | Change |  | 2016 |  | Change |  | 2015 |
| Net sales | $ | 29,980 |  |  | 23 | % |  | $ | 24,348 |  |  | 22 | % |  | $ | 19,909 |  |
| Percentage of total net sales | 13 | % |  |  |  | 11 | % |  |  |  | 9 | % |

[0000320193-17-000070:mdna:35]
The year-over-year growth in Services net sales in 2017 was due primarily to increases in App Store and licensing sales. Services net sales in the fourth quarter of 2017 included a favorable one-time adjustment of $640 million due to a change in estimate based on the availability of additional supporting information.

[0000320193-17-000070:mdna:36]
The year-over-year increase in Services net sales in 2016 was due primarily to growth from the App Store, licensing and AppleCare sales, partially offset by the effect of weakness in most foreign currencies relative to the U.S. dollar. During the first quarter of 2016, the Company received $548 million from Samsung Electronics Co., Ltd. related to its patent infringement lawsuit, which was recorded as licensing net sales within Services.

[0000320193-17-000070:mdna:37]
Segment Operating Performance

[0000320193-17-000070:mdna:38]
The Company manages its business primarily on a geographic basis. The Company’s reportable segments consist of the Americas, Europe, Greater China, Japan and Rest of Asia Pacific. Americas includes both North and South America. Europe includes European countries, as well as India, the Middle East and Africa. Greater China includes China, Hong Kong and Taiwan. Rest of Asia Pacific includes Australia and those Asian countries not included in the Company’s other reportable segments. Although the reportable segments provide similar hardware and software products and similar services, each one is managed separately to better align with the location of the Company’s customers and distribution partners and the unique market dynamics of each geographic region. Further information regarding the Company’s reportable segments can be found in Part II, Item 8 of this Form 10-K in the Notes to Consolidated Financial Statements in Note 11, “Segment Information and Geographic Data.”

[0000320193-17-000070:mdna:39]
Americas

[0000320193-17-000070:mdna:40]
The following table presents Americas net sales information for 2017, 2016 and 2015 (dollars in millions):

[0000320193-17-000070:mdna:41]
|  | 2017 |  | Change |  | 2016 |  | Change |  | 2015 |
| Net sales | $ | 96,600 |  |  | 12 | % |  | $ | 86,613 |  |  | (8 | )% |  | $ | 93,864 |  |
| Percentage of total net sales | 42 | % |  |  |  | 40 | % |  |  |  | 40 | % |

[0000320193-17-000070:mdna:42]
Americas net sales increased during 2017 compared to 2016 due primarily to higher net sales of iPhone, Services and Mac.

[0000320193-17-000070:mdna:43]
Americas net sales decreased during 2016 compared to 2015 due primarily to lower net sales of iPhone.

[0000320193-17-000070:mdna:44]
Europe

[0000320193-17-000070:mdna:45]
The following table presents Europe net sales information for 2017, 2016 and 2015 (dollars in millions):

[0000320193-17-000070:mdna:46]
|  | 2017 |  | Change |  | 2016 |  | Change |  | 2015 |
| Net sales | $ | 54,938 |  |  | 10 | % |  | $ | 49,952 |  |  | (1 | )% |  | $ | 50,337 |  |
| Percentage of total net sales | 24 | % |  |  |  | 23 | % |  |  |  | 22 | % |

[0000320193-17-000070:mdna:47]
Europe net sales increased during 2017 compared to 2016 due primarily to higher net sales of iPhone and Services. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on Europe net sales during 2017 compared to 2016.

[0000320193-17-000070:mdna:48]
Europe net sales decreased during 2016 compared to 2015 driven primarily by the effect of weakness in foreign currencies relative to the U.S. dollar and a decrease in net sales of Mac, largely offset by an increase in iPhone unit sales and Services.

[0000320193-17-000070:mdna:49]
Greater China

[0000320193-17-000070:mdna:50]
The following table presents Greater China net sales information for 2017, 2016 and 2015 (dollars in millions):

[0000320193-17-000070:mdna:51]
|  | 2017 |  | Change |  | 2016 |  | Change |  | 2015 |
| Net sales | $ | 44,764 |  |  | (8 | )% |  | $ | 48,492 |  |  | (17 | )% |  | $ | 58,715 |  |
| Percentage of total net sales | 20 | % |  |  |  | 22 | % |  |  |  | 25 | % |

[0000320193-17-000070:mdna:52]
Greater China net sales decreased during 2017 compared to 2016 due primarily to lower net sales of iPhone, partially offset by higher net sales of Services. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on Greater China net sales during 2017 compared to 2016.

[0000320193-17-000070:mdna:53]
Greater China net sales decreased during 2016 compared to 2015 due primarily to lower net sales of iPhone and the effect of weakness in foreign currencies relative to the U.S. dollar.

[0000320193-17-000070:mdna:54]
Japan

[0000320193-17-000070:mdna:55]
The following table presents Japan net sales information for 2017, 2016 and 2015 (dollars in millions):

[0000320193-17-000070:mdna:56]
|  | 2017 |  | Change |  | 2016 |  | Change |  | 2015 |
| Net sales | $ | 17,733 |  |  | 5 | % |  | $ | 16,928 |  |  | 8 | % |  | $ | 15,706 |  |
| Percentage of total net sales | 8 | % |  |  |  | 8 | % |  |  |  | 7 | % |

[0000320193-17-000070:mdna:57]
The year-over-year increase in Japan net sales in 2017 and 2016 was due primarily to higher net sales of Services and the strength in the Japanese yen relative to the U.S. dollar.

[0000320193-17-000070:mdna:58]
Rest of Asia Pacific

[0000320193-17-000070:mdna:59]
The following table presents Rest of Asia Pacific net sales information for 2017, 2016 and 2015 (dollars in millions):

[0000320193-17-000070:mdna:60]
|  | 2017 |  | Change |  | 2016 |  | Change |  | 2015 |
| Net sales | $ | 15,199 |  |  | 11 | % |  | $ | 13,654 |  |  | (10 | )% |  | $ | 15,093 |  |
| Percentage of total net sales | 7 | % |  |  |  | 6 | % |  |  |  | 6 | % |

[0000320193-17-000070:mdna:61]
Rest of Asia Pacific net sales increased during 2017 compared to 2016 due primarily to higher net sales of iPhone, Services and Mac. The strength in foreign currencies relative to the U.S. dollar had a favorable impact on Rest of Asia Pacific net sales during 2017 compared to 2016.

[0000320193-17-000070:mdna:62]
Rest of Asia Pacific net sales decreased during 2016 compared to 2015 due primarily to lower net sales of iPhone and the effect of weakness in foreign currencies relative to the U.S. dollar.

[0000320193-17-000070:mdna:63]
Gross Margin

[0000320193-17-000070:mdna:64]
Gross margin for 2017, 2016 and 2015 was as follows (dollars in millions):

[0000320193-17-000070:mdna:65]
|  | 2017 |  | 2016 |  | 2015 |
| Net sales | $ | 229,234 |  |  | $ | 215,639 |  |  | $ | 233,715 |  |
| Cost of sales | 141,048 |  |  | 131,376 |  |  | 140,089 |  |
| Gross margin | $ | 88,186 |  |  | $ | 84,263 |  |  | $ | 93,626 |  |
| Gross margin percentage | 38.5 | % |  | 39.1 | % |  | 40.1 | % |

[0000320193-17-000070:mdna:66]
Gross margin percentage decreased in 2017 compared to 2016 due primarily to higher product costs, partially offset by a favorable shift in mix to services. Year-over-year gross margin increased due primarily to a shift in mix to services and an overall increase in product volumes. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on gross margin percentage and gross margin during 2017 compared to 2016.

[0000320193-17-000070:mdna:67]
Gross margin percentage decreased in 2016 compared to 2015 due primarily to the effect of weakness in most foreign currencies relative to the U.S. dollar and, to a lesser extent, unfavorable leverage on fixed costs from lower net sales, partially offset by a favorable shift in mix to services.

[0000320193-17-000070:mdna:68]
The Company anticipates gross margin percentage during the first quarter of 2018 to be between 38.0% and 38.5%. The foregoing statement regarding the Company’s expected gross margin percentage in the first quarter of 2018 is forward-looking and could differ from actual results. The Company’s future gross margins can be impacted by multiple factors including, but not limited to, those set forth in Part I, Item 1A of this Form 10-K under the heading “Risk Factors” and those described in this paragraph. In general, the Company believes gross margins will remain under downward pressure due to a variety of factors, including continued industry-wide global product pricing pressures, increased competition, compressed product life cycles, product transitions, potential increases in the cost of components, and potential strengthening of the U.S. dollar, as well as potential increases in the costs of outside manufacturing services and a potential shift in the Company’s sales mix towards products with lower gross margins. In response to competitive pressures, the Company expects it will continue to take product pricing actions, which would adversely affect gross margins. Gross margins could also be affected by the Company’s ability to manage product quality and warranty costs effectively and to stimulate demand for certain of its products. Due to the Company’s significant international operations, its financial condition and operating results, including gross margins, could be significantly affected by fluctuations in exchange rates.

[0000320193-17-000070:mdna:69]
Operating Expenses

[0000320193-17-000070:mdna:70]
Operating expenses for 2017, 2016 and 2015 were as follows (dollars in millions):

[0000320193-17-000070:mdna:71]
|  | 2017 |  | Change |  | 2016 |  | Change |  | 2015 |
| Research and development | $ | 11,581 |  |  | 15 | % |  | $ | 10,045 |  |  | 25 | % |  | $ | 8,067 |  |
| Percentage of total net sales | 5 | % |  |  |  | 5 | % |  |  |  | 3 | % |
| Selling, general and administrative | $ | 15,261 |  |  | 8 | % |  | $ | 14,194 |  |  | (1 | )% |  | $ | 14,329 |  |
| Percentage of total net sales | 7 | % |  |  |  | 7 | % |  |  |  | 6 | % |
| Total operating expenses | $ | 26,842 |  |  | 11 | % |  | $ | 24,239 |  |  | 8 | % |  | $ | 22,396 |  |
| Percentage of total net sales | 12 | % |  |  |  | 11 | % |  |  |  | 10 | % |

[0000320193-17-000070:mdna:72]
Research and Development

[0000320193-17-000070:mdna:73]
The year-over-year growth in R&D expense in 2017 and 2016 was driven primarily by increases in headcount-related expenses and material costs to support expanded R&D activities. The Company continues to believe that focused investments in R&D are critical to its future growth and competitive position in the marketplace, and to the development of new and updated products and services that are central to the Company’s core business strategy.

[0000320193-17-000070:mdna:74]
Selling, General and Administrative

[0000320193-17-000070:mdna:75]
The year-over-year growth in selling, general and administrative expense in 2017 compared to 2016 was driven primarily by an increase in headcount-related expenses, variable selling expenses and infrastructure-related costs. The decrease in selling, general and administrative expense in 2016 compared to 2015 was due primarily to lower discretionary expenditures and advertising costs, partially offset by an increase in headcount-related expenses.

[0000320193-17-000070:mdna:76]
Other Income/(Expense), Net

[0000320193-17-000070:mdna:77]
Other income/(expense), net for 2017, 2016 and 2015 was as follows (dollars in millions):

[0000320193-17-000070:mdna:78]
|  | 2017 |  | Change |  | 2016 |  | Change |  | 2015 |
| Interest and dividend income | $ | 5,201 |  |  |  |  | $ | 3,999 |  |  |  |  | $ | 2,921 |  |
| Interest expense | (2,323 | ) |  |  |  | (1,456 | ) |  |  |  | (733 | ) |
| Other expense, net | (133 | ) |  |  |  | (1,195 | ) |  |  |  | (903 | ) |
| Total other income/(expense), net | $ | 2,745 |  |  | 104 | % |  | $ | 1,348 |  |  | 5 | % |  | $ | 1,285 |  |

[0000320193-17-000070:mdna:79]
The year-over-year increase in other income/(expense), net during 2017 was due primarily to higher interest income and the favorable impact of foreign exchange-related items, partially offset by higher interest expense on debt. The year-over-year increase in other income/(expense), net during 2016 was due primarily to higher interest income, partially offset by higher interest expense on debt and the unfavorable impact of foreign exchange-related items. The weighted-average interest rate earned by the Company on its cash, cash equivalents and marketable securities was 1.99%, 1.73% and 1.49% in 2017, 2016 and 2015, respectively.

[0000320193-17-000070:mdna:80]
Provision for Income Taxes

[0000320193-17-000070:mdna:81]
Provision for income taxes and effective tax rates for 2017, 2016 and 2015 were as follows (dollars in millions):

[0000320193-17-000070:mdna:82]
|  | 2017 |  | 2016 |  | 2015 |
| Provision for income taxes | $ | 15,738 |  |  | $ | 15,685 |  |  | $ | 19,121 |  |
| Effective tax rate | 24.6 | % |  | 25.6 | % |  | 26.4 | % |

[0000320193-17-000070:mdna:83]
The Company’s effective tax rates for 2017, 2016 and 2015 differ from the statutory federal income tax rate of 35% due primarily to certain undistributed foreign earnings, a substantial portion of which was generated by subsidiaries organized in Ireland, for which no U.S. taxes are provided when such earnings are intended to be indefinitely reinvested outside the U.S. The lower effective tax rate in 2017 compared to 2016 was due to a different geographic mix of earnings and higher U.S. R&D tax credits. The lower effective tax rate in 2016 compared to 2015 was due primarily to greater R&D tax credits.

[0000320193-17-000070:mdna:84]
As of September 30, 2017, the Company had deferred tax assets arising from deductible temporary differences, tax losses and tax credits of $3.9 billion and deferred tax liabilities of $31.5 billion. Management believes it is more likely than not that forecasted income, including income that may be generated as a result of certain tax planning strategies, together with future reversals of existing taxable temporary differences, will be sufficient to fully recover the deferred tax assets. The Company will continue to evaluate the realizability of deferred tax assets quarterly by assessing the need for and the amount of a valuation allowance.

[0000320193-17-000070:mdna:85]
The IRS concluded its review of the years 2010 through 2012 during the third quarter of 2017. All years prior to 2013 are closed, and the IRS is currently examining the years 2013 through 2015. The Company is also subject to audits by state, local and foreign tax authorities. In major states and major foreign jurisdictions, the years subsequent to 2003 generally remain open and could be subject to examination by the taxing authorities. Management believes that adequate provisions have been made for any adjustments that may result from tax examinations. However, the outcome of tax audits cannot be predicted with certainty. If any issues addressed in the Company’s tax audits are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs.

[0000320193-17-000070:mdna:86]
On August 30, 2016, the European Commission announced its decision that Ireland granted state aid to the Company by providing tax opinions in 1991 and 2007 concerning the tax allocation of profits of the Irish branches of two subsidiaries of the Company (the “State Aid Decision”). The State Aid Decision orders Ireland to calculate and recover additional taxes from the Company for the period June 2003 through December 2014. Irish legislative changes, effective as of January 2015, eliminated the application of the tax opinions from that date forward. The Company believes the State Aid Decision to be without merit and appealed to the General Court of the Court of Justice of the European Union. Ireland has also appealed the State Aid Decision. Although Ireland is still computing the recovery amount, the Company expects the amount to be in line with the European Commission’s announced recovery amount of €13 billion, plus interest of €1 billion. Once the recovery amount is finalized by Ireland, the Company anticipates funding it, including interest, out of foreign cash. These amounts are expected to be placed into escrow in 2018, where they will remain pending conclusion of all appeals. The Company believes that any incremental Irish corporate income taxes potentially due related to the State Aid Decision would be creditable against U.S. taxes.

[0000320193-17-000070:mdna:87]
Recent Accounting Pronouncements

[0000320193-17-000070:mdna:88]
Hedging

[0000320193-17-000070:mdna:89]
In August 2017, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities (“ASU 2017-12”). ASU 2017-12 expands component and fair value hedging, specifies the presentation of the effects of hedging instruments, and eliminates the separate measurement and presentation of hedge ineffectiveness. The Company will adopt ASU 2017-12 in its first quarter of 2020 utilizing the modified retrospective transition method and is currently evaluating the impact of adoption on its consolidated financial statements.

[0000320193-17-000070:mdna:90]
Restricted Cash

[0000320193-17-000070:mdna:91]
In November 2016, the FASB issued ASU No. 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash (“ASU 2016-18”), which enhances and clarifies the guidance on the classification and presentation of restricted cash in the statement of cash flows. The Company will adopt ASU 2016-18 in its first quarter of 2019 utilizing the retrospective transition method. Currently, the Company’s restricted cash balance is not significant.

[0000320193-17-000070:mdna:92]
Income Taxes

[0000320193-17-000070:mdna:93]
In October 2016, the FASB issued ASU No. 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory (“ASU 2016-16”), which requires the recognition of the income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. The Company will adopt ASU 2016-16 in its first quarter of 2019 utilizing the modified retrospective transition method. Currently, the Company anticipates recording up to $9 billion of net deferred tax assets on its Consolidated Balance Sheets upon adoption. However, the ultimate impact of adopting ASU 2016-16 will depend on the balance of intellectual property transferred between its subsidiaries as of the adoption date. The Company will recognize incremental deferred income tax expense thereafter as these deferred tax assets are utilized.

[0000320193-17-000070:mdna:94]
Stock Compensation

[0000320193-17-000070:mdna:95]
In March 2016, the FASB issued ASU No. 2016-09, Compensation – Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting (“ASU 2016-09”), which modifies certain aspects of the accounting for share-based payment transactions, including income taxes, classification of awards, and classification in the statement of cash flows. The Company will adopt ASU 2016-09 in its first quarter of 2018. Currently, excess tax benefits or deficiencies from the Company’s equity awards are recorded as additional paid-in capital in its Consolidated Balance Sheets. Upon adoption, the Company will record any excess tax benefits or deficiencies from its equity awards in its Consolidated Statements of Operations in the reporting periods in which vesting occurs. As a result, subsequent to adoption the Company’s income tax expense and associated effective tax rate will be impacted by fluctuations in stock price between the grant dates and vesting dates of equity awards.

[0000320193-17-000070:mdna:96]
Leases

[0000320193-17-000070:mdna:97]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842) (“ASU 2016-02”), which modifies lease accounting for lessees to increase transparency and comparability by recording lease assets and liabilities for operating leases and disclosing key information about leasing arrangements. The Company will adopt ASU 2016-02 in its first quarter of 2020 utilizing the modified retrospective transition method. While the Company is currently evaluating the timing and impact of adopting ASU 2016-02, currently the Company anticipates recording lease assets and liabilities in excess of $9.5 billion on its Consolidated Balance Sheets, with no material impact to its Consolidated Statements of Operations. However, the ultimate impact of adopting ASU 2016-02 will depend on the Company’s lease portfolio as of the adoption date.

[0000320193-17-000070:mdna:98]
Financial Instruments

[0000320193-17-000070:mdna:99]
In January 2016, the FASB issued ASU No. 2016-01, Financial Instruments – Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities (“ASU 2016-01”), which updates certain aspects of recognition, measurement, presentation and disclosure of financial instruments. The Company will adopt ASU 2016-01 in its first quarter of 2019 utilizing the modified retrospective transition method. Based on the composition of the Company’s investment portfolio, the adoption of ASU 2016-01 is not expected to have a material impact on its consolidated financial statements.

[0000320193-17-000070:mdna:100]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (“ASU 2016-13”), which modifies the measurement of expected credit losses of certain financial instruments. The Company will adopt ASU 2016-13 in its first quarter of 2021 utilizing the modified retrospective transition method. Based on the composition of the Company’s investment portfolio, current market conditions, and historical credit loss activity, the adoption of ASU 2016-13 is not expected to have a material impact on its consolidated financial statements.

[0000320193-17-000070:mdna:101]
Revenue Recognition

[0000320193-17-000070:mdna:102]
In May 2014, the FASB issued ASU No. 2014-09, Revenue from Contracts with Customers (Topic 606) (“ASU 2014-09”), which amends the existing accounting standards for revenue recognition. ASU 2014-09 is based on principles that govern the recognition of revenue at an amount an entity expects to be entitled when products are transferred to customers.

[0000320193-17-000070:mdna:103]
Subsequently, the FASB has issued the following standards related to ASU 2014-09: ASU No. 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (“ASU 2016-08”); ASU No. 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing (“ASU 2016-10”); ASU No. 2016-12, Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients (“ASU 2016-12”); and ASU No. 2016-20, Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers (“ASU 2016-20”). The Company must adopt ASU 2016-08, ASU 2016-10, ASU 2016-12 and ASU 2016-20 with ASU 2014-09 (collectively, the “new revenue standards”).

[0000320193-17-000070:mdna:104]
The new revenue standards may be applied retrospectively to each prior period presented or retrospectively with the cumulative effect recognized as of the date of adoption. The Company will adopt the new revenue standards in its first quarter of 2019 utilizing the full retrospective transition method. The new revenue standards are not expected to have a material impact on the amount and timing of revenue recognized in the Company’s consolidated financial statements.

[0000320193-17-000070:mdna:105]
Liquidity and Capital Resources

[0000320193-17-000070:mdna:106]
The following table presents selected financial information and statistics as of and for the years ended September 30, 2017, September 24, 2016 and September 26, 2015 (in millions):

[0000320193-17-000070:mdna:107]
|  | 2017 |  | 2016 |  | 2015 |
| Cash, cash equivalents and marketable securities | $ | 268,895 |  |  | $ | 237,585 |  |  | $ | 205,666 |  |
| Property, plant and equipment, net | $ | 33,783 |  |  | $ | 27,010 |  |  | $ | 22,471 |  |
| Commercial paper | $ | 11,977 |  |  | $ | 8,105 |  |  | $ | 8,499 |  |
| Total term debt | $ | 103,703 |  |  | $ | 78,927 |  |  | $ | 55,829 |  |
| Working capital | $ | 27,831 |  |  | $ | 27,863 |  |  | $ | 8,768 |  |
| Cash generated by operating activities | $ | 63,598 |  |  | $ | 65,824 |  |  | $ | 81,266 |  |
| Cash used in investing activities | $ | (46,446 | ) |  | $ | (45,977 | ) |  | $ | (56,274 | ) |
| Cash used in financing activities | $ | (17,347 | ) |  | $ | (20,483 | ) |  | $ | (17,716 | ) |

[0000320193-17-000070:mdna:108]
The Company believes its existing balances of cash, cash equivalents and marketable securities will be sufficient to satisfy its working capital needs, capital asset purchases, outstanding commitments and other liquidity requirements associated with its existing operations over the next 12 months. The Company currently anticipates the cash used for future dividends, the share repurchase program and debt repayments will come from its current domestic cash, cash generated from ongoing U.S. operating activities and from borrowings.

[0000320193-17-000070:mdna:109]
As of September 30, 2017 and September 24, 2016, the Company’s cash, cash equivalents and marketable securities held by foreign subsidiaries were $252.3 billion and $216.0 billion, respectively, and are generally based in U.S. dollar-denominated holdings. Amounts held by foreign subsidiaries are generally subject to U.S. income taxation on repatriation to the U.S. In connection with the State Aid Decision, Ireland is still computing the recovery amount. The Company expects the amount to be in line with the European Commission’s announced recovery amount of €13 billion, plus interest of €1 billion. Once the recovery amount is finalized by Ireland, the Company anticipates funding it, including interest, out of foreign cash. These amounts are expected to be placed into escrow in 2018, where they will remain pending conclusion of all appeals.

[0000320193-17-000070:mdna:110]
The Company’s marketable securities investment portfolio is primarily invested in highly-rated securities, and its investment policy generally limits the amount of credit exposure to any one issuer. The policy generally requires investments to be investment grade, with the primary objective of minimizing the potential risk of principal loss.

[0000320193-17-000070:mdna:111]
During 2017, cash generated by operating activities of $63.6 billion was a result of $48.4 billion of net income, non-cash adjustments to net income of $20.8 billion and a decrease in the net change in operating assets and liabilities of $5.6 billion, which included a one-time payment of $1.9 billion related to a multi-year license agreement. Cash used in investing activities of $46.4 billion during 2017 consisted primarily of cash used for purchases of marketable securities, net of sales and maturities, of $33.1 billion and cash used to acquire property, plant and equipment of $12.5 billion. Cash used in financing activities of $17.3 billion during 2017 consisted primarily of cash used to repurchase common stock of $32.9 billion, cash used to pay dividends and dividend equivalents of $12.8 billion and cash used to repay term debt of $3.5 billion, partially offset by proceeds from the issuance of term debt, net of $28.7 billion and proceeds from commercial paper, net of $3.9 billion.

[0000320193-17-000070:mdna:112]
During 2016, cash generated by operating activities of $65.8 billion was a result of $45.7 billion of net income and non-cash adjustments to net income of $20.1 billion. Cash used in investing activities of $46.0 billion during 2016 consisted primarily of cash used for purchases of marketable securities, net of sales and maturities, of $30.6 billion and cash used to acquire property, plant and equipment of $12.7 billion. Cash used in financing activities of $20.5 billion during 2016 consisted primarily of cash used to repurchase common stock of $29.7 billion, cash used to pay dividends and dividend equivalents of $12.2 billion and cash used to repay term debt of $2.5 billion, partially offset by proceeds from the issuance of term debt, net of $25.0 billion.

[0000320193-17-000070:mdna:113]
Capital Assets

[0000320193-17-000070:mdna:114]
The Company’s capital expenditures were $14.9 billion during 2017. The Company anticipates utilizing approximately $16.0 billion for capital expenditures during 2018, which includes product tooling and manufacturing process equipment; data centers; corporate facilities and infrastructure, including information systems hardware, software and enhancements; and retail store facilities.

[0000320193-17-000070:mdna:115]
Debt

[0000320193-17-000070:mdna:116]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses the net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of September 30, 2017, the Company had $12.0 billion of Commercial Paper outstanding, with a weighted-average interest rate of 1.20% and maturities generally less than nine months.

[0000320193-17-000070:mdna:117]
As of September 30, 2017, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $104.0 billion (collectively the “Notes”). During 2017, the Company repaid $3.5 billion of its Notes upon maturity. The Company has entered, and in the future may enter, into interest rate swaps to manage interest rate risk on the Notes. In addition, the Company has entered, and in the future may enter, into foreign currency swaps to manage foreign currency risk on the Notes. The future principal payments for the Company’s Notes as of September 30, 2017 are as follows (in millions):

[0000320193-17-000070:mdna:118]
| 2018 | $ | 6,500 |  |
| 2019 | 8,863 |  |
| 2020 | 9,220 |  |
| 2021 | 7,750 |  |
| 2022 | 10,297 |  |
| Thereafter | 61,391 |  |
| Total term debt | $ | 104,021 |  |

[0000320193-17-000070:mdna:119]
Further information regarding the Company’s debt issuances and related hedging activity can be found in Part II, Item 8 of this Form 10-K in the Notes to Consolidated Financial Statements in Note 2, “Financial Instruments” and Note 6, “Debt.”

[0000320193-17-000070:mdna:120]
Capital Return Program

[0000320193-17-000070:mdna:121]
In May 2017, the Company’s Board of Directors increased the total capital return program from $250 billion to $300 billion, which included an increase in the share repurchase authorization from $175 billion to $210 billion of the Company’s common stock. Additionally, the Company announced that the Board of Directors raised the Company’s quarterly cash dividend from $0.57 to $0.63 per share, beginning with the dividend paid during the third quarter of 2017. The Company intends to increase its dividend on an annual basis, subject to declaration by the Board of Directors.

[0000320193-17-000070:mdna:122]
As of September 30, 2017, $166 billion of the share repurchase program had been utilized. The Company’s share repurchase program does not obligate it to acquire any specific number of shares. Under the program, shares may be repurchased in privately negotiated or open market transactions, including under plans complying with Rule 10b5-1 under the Exchange Act.

[0000320193-17-000070:mdna:123]
The following table presents the Company’s dividends, dividend equivalents, share repurchases and net share settlement activity from the start of the capital return program in August 2012 through September 30, 2017 (in millions):

[0000320193-17-000070:mdna:124]
|  | Dividends andDividend Equivalents Paid |  | Accelerated ShareRepurchases |  | Open MarketShare Repurchases |  | Taxes Related to Settlementof Equity Awards |  | Total |
| 2017 | $ | 12,769 |  |  | $ | 15,000 |  |  | $ | 18,001 |  |  | $ | 1,874 |  |  | $ | 47,644 |  |
| 2016 | 12,150 |  |  | 12,000 |  |  | 17,000 |  |  | 1,570 |  |  | 42,720 |  |
| 2015 | 11,561 |  |  | 6,000 |  |  | 30,026 |  |  | 1,499 |  |  | 49,086 |  |
| 2014 | 11,126 |  |  | 21,000 |  |  | 24,000 |  |  | 1,158 |  |  | 57,284 |  |
| 2013 | 10,564 |  |  | 13,950 |  |  | 9,000 |  |  | 1,082 |  |  | 34,596 |  |
| 2012 | 2,488 |  |  | — |  |  | — |  |  | 56 |  |  | 2,544 |  |
| Total | $ | 60,658 |  |  | $ | 67,950 |  |  | $ | 98,027 |  |  | $ | 7,239 |  |  | $ | 233,874 |  |

[0000320193-17-000070:mdna:125]
The Company expects to execute its capital return program by the end of March 2019 by paying dividends and dividend equivalents, repurchasing shares and remitting withheld taxes related to net share settlement of restricted stock units. The Company plans to continue to access the domestic and international debt markets to assist in funding its capital return program.

[0000320193-17-000070:mdna:126]
Off-Balance Sheet Arrangements and Contractual Obligations

[0000320193-17-000070:mdna:127]
The Company has not entered into any transactions with unconsolidated entities whereby the Company has financial guarantees, subordinated retained interests, derivative instruments, or other contingent arrangements that expose the Company to material continuing risks, contingent liabilities, or any other obligation under a variable interest in an unconsolidated entity that provides financing, liquidity, market risk, or credit risk support to the Company, or engages in leasing, hedging, or R&D services with the Company.

[0000320193-17-000070:mdna:128]
The following table presents certain payments due by the Company as of September 30, 2017, and excludes amounts already recorded on the Consolidated Balance Sheet, except for term debt (in millions):

[0000320193-17-000070:mdna:129]
|  | Payments Due in Less Than1 Year |  | Payments Duein 1-3 Years |  | Payments Duein 4-5 Years |  | Payments Duein More Than5 Years |  | Total |
| Term debt | $ | 6,500 |  |  | $ | 18,083 |  |  | $ | 18,047 |  |  | $ | 61,391 |  |  | $ | 104,021 |  |
| Operating leases | 1,223 |  |  | 2,295 |  |  | 1,904 |  |  | 4,123 |  |  | 9,545 |  |
| Manufacturing purchase obligations (1) | 32,787 |  |  | 2,632 |  |  | 2,147 |  |  | — |  |  | 37,566 |  |
| Other purchase obligations | 4,019 |  |  | 1,669 |  |  | 417 |  |  | 14 |  |  | 6,119 |  |
| Total | $ | 44,529 |  |  | $ | 24,679 |  |  | $ | 22,515 |  |  | $ | 65,528 |  |  | $ | 157,251 |  |

[0000320193-17-000070:mdna:130]
| (1) | Represents amount expected to be paid under manufacturing-related supplier arrangements, substantially all of which is noncancelable. |

[0000320193-17-000070:mdna:131]
Operating Leases

[0000320193-17-000070:mdna:132]
As of September 30, 2017, the Company’s total future minimum lease payments under noncancelable operating leases were $9.5 billion. The Company’s retail store and other facility leases typically have original terms not exceeding 10 years and generally contain multi-year renewal options.

[0000320193-17-000070:mdna:133]
Manufacturing Purchase Obligations

[0000320193-17-000070:mdna:134]
The Company utilizes several outsourcing partners to manufacture sub-assemblies for the Company’s products and to perform final assembly and testing of finished products. These outsourcing partners acquire components and build product based on demand information supplied by the Company, which typically covers periods up to 150 days. The Company also obtains individual components for its products from a wide variety of individual suppliers. As of September 30, 2017, the Company expects to pay $37.6 billion under manufacturing-related supplier arrangements, substantially all of which is noncancelable.

[0000320193-17-000070:mdna:135]
Other Purchase Obligations

[0000320193-17-000070:mdna:136]
The Company’s other purchase obligations consisted of noncancelable obligations to acquire capital assets, including product tooling and manufacturing process equipment, and noncancelable obligations related to advertising, licensing, R&D, internet and telecommunications services and other obligations. As of September 30, 2017, the Company had other purchase obligations of $6.1 billion.

[0000320193-17-000070:mdna:137]
The Company’s other non-current liabilities in the Consolidated Balance Sheets consist primarily of deferred tax liabilities, gross unrecognized tax benefits and the related gross interest and penalties. As of September 30, 2017, the Company had deferred tax liabilities of $31.5 billion, gross unrecognized tax benefits of $8.4 billion and an additional $1.2 billion for gross interest and penalties. At this time, the Company is unable to make a reasonably reliable estimate of the timing of payments due to uncertainties in the timing of tax audit outcomes; therefore, such amounts are not included in the above contractual obligation table.

[0000320193-17-000070:mdna:138]
Indemnification

[0000320193-17-000070:mdna:139]
Agreements entered into by the Company sometimes include indemnification provisions which may subject the Company to costs and damages in the event of a claim against an indemnified third party. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to indemnification of third parties.

[0000320193-17-000070:mdna:140]
The Company offers an iPhone Upgrade Program, which is available to customers who purchase a qualifying iPhone in the U.S., the U.K. and mainland China. The iPhone Upgrade Program provides customers the right to trade in that iPhone for a specified amount when purchasing a new iPhone, provided certain conditions are met. The Company accounts for the trade-in right as a guarantee liability and recognizes arrangement revenue net of the fair value of such right, with subsequent changes to the guarantee liability recognized within revenue.

[0000320193-17-000070:mdna:141]
The Company has entered into indemnification agreements with its directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers of the Company and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. While the Company maintains directors and officers liability insurance coverage, such insurance coverage may be insufficient to cover all losses or all types of claims that may arise.

[0000320193-17-000070:mdna:142]
Critical Accounting Policies and Estimates

[0000320193-17-000070:mdna:143]
The preparation of financial statements and related disclosures in conformity with U.S. generally accepted accounting principles (“GAAP”) and the Company’s discussion and analysis of its financial condition and operating results require the Company’s management to make judgments, assumptions and estimates that affect the amounts reported in its consolidated financial statements and accompanying notes. Note 1, “Summary of Significant Accounting Policies,” of the Notes to Consolidated Financial Statements in Part II, Item 8 of this Form 10-K describes the significant accounting policies and methods used in the preparation of the Company’s consolidated financial statements. Management bases its estimates on historical experience and on various other assumptions it believes to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities. Actual results may differ from these estimates, and such differences may be material.

[0000320193-17-000070:mdna:144]
Management believes the Company’s critical accounting policies and estimates are those related to revenue recognition, valuation and impairment of marketable securities, inventory valuation, valuation of manufacturing-related assets and estimation of purchase commitment cancellation fees, warranty costs, income taxes, and legal and other contingencies. Management considers these policies critical because they are both important to the portrayal of the Company’s financial condition and operating results, and they require management to make judgments and estimates about inherently uncertain matters. The Company’s senior management has reviewed these critical accounting policies and related disclosures with the Audit and Finance Committee of the Company’s Board of Directors.

[0000320193-17-000070:mdna:145]
Revenue Recognition

[0000320193-17-000070:mdna:146]
Net sales consist primarily of revenue from the sale of hardware, software, digital content and applications, accessories, and service and support contracts. The Company recognizes revenue when persuasive evidence of an arrangement exists, delivery has occurred, the sales price is fixed or determinable and collection is probable. Product is considered delivered to the customer once it has been shipped and title, risk of loss and rewards of ownership have been transferred. For most of the Company’s product sales, these criteria are met at the time the product is shipped. For online sales to individuals, for some sales to education customers in the U.S., and for certain other sales, the Company defers revenue until the customer receives the product because the Company retains a portion of the risk of loss on these sales during transit. For payment terms in excess of the Company’s standard payment terms, revenue is recognized as payments become due unless the Company has positive evidence that the sales price is fixed or determinable, such as a successful history of collection, without concession, on comparable arrangements. The Company recognizes revenue from the sale of hardware products, software bundled with hardware that is essential to the functionality of the hardware and third-party digital content sold on the iTunes Store in accordance with general revenue recognition accounting guidance. The Company recognizes revenue in accordance with industry-specific software accounting guidance for the following types of sales transactions: (i) standalone sales of software products, (ii) sales of software upgrades and (iii) sales of software bundled with hardware not essential to the functionality of the hardware.

[0000320193-17-000070:mdna:147]
For multi-element arrangements that include hardware products containing software essential to the hardware product’s functionality, undelivered software elements that relate to the hardware product’s essential software and/or undelivered non-software services, the Company allocates revenue to all deliverables based on their relative selling prices. In such circumstances, the Company uses a hierarchy to determine the selling price to be used for allocating revenue to deliverables: (i) vendor-specific objective evidence of fair value (“VSOE”), (ii) third-party evidence of selling price (“TPE”) and (iii) best estimate of selling price (“ESP”). VSOE generally exists only when the Company sells the deliverable separately and is the price actually charged by the Company for that deliverable. ESPs reflect the Company’s best estimates of what the selling prices of elements would be if they were sold regularly on a stand-alone basis.

[0000320193-17-000070:mdna:148]
For sales of qualifying versions of iOS devices, Mac, Apple Watch and Apple TV, the Company has indicated it may from time to time provide future unspecified software upgrades to the device’s essential software and/or non-software services free of charge. Because the Company has neither VSOE nor TPE for the unspecified software upgrade rights or the non-software services, revenue is allocated to these rights and services based on the Company’s ESPs. Revenue allocated to the unspecified software upgrade rights and non-software services based on the Company’s ESPs is deferred and recognized on a straight-line basis over the estimated period the software upgrades and non-software services are expected to be provided.

[0000320193-17-000070:mdna:149]
The Company’s process for determining ESPs involves management’s judgment and considers multiple factors that may vary over time depending upon the unique facts and circumstances related to each deliverable. Should future facts and circumstances change, the Company’s ESPs and the future rate of related amortization for unspecified software upgrades and non-software services related to future sales of these devices could change. Factors subject to change include the unspecified software upgrade rights and non-software services offered, the estimated value of unspecified software upgrade rights and non-software services and the estimated period unspecified software upgrades and non-software services are expected to be provided.

[0000320193-17-000070:mdna:150]
The Company records reductions to revenue for estimated commitments related to price protection and other customer incentive programs. For transactions involving price protection, the Company recognizes revenue net of the estimated amount to be refunded, provided the refund amount can be reasonably and reliably estimated and the other conditions for revenue recognition have been met. The Company’s policy requires that, if refunds cannot be reliably estimated, revenue is not recognized until reliable estimates can be made or the price protection lapses. For the Company’s other customer incentive programs, the estimated cost is recognized at the later of the date at which the Company has sold the product or the date at which the program is offered. The Company also records reductions to revenue for expected future product returns based on the Company’s historical experience. Future market conditions and product transitions may require the Company to increase customer incentive programs that could result in reductions to future revenue. Additionally, certain customer incentive programs require management to estimate the number of customers who will actually redeem the incentive. Management’s estimates are based on historical experience and the specific terms and conditions of particular incentive programs. If a greater than estimated proportion of customers redeems such incentives, the Company would be required to record additional reductions to revenue, which would have an adverse impact on the Company’s operating results.

[0000320193-17-000070:mdna:151]
Valuation and Impairment of Marketable Securities

[0000320193-17-000070:mdna:152]
The Company’s investments in available-for-sale securities are reported at fair value. Unrealized gains and losses related to changes in the fair value of securities are recognized in accumulated other comprehensive income, net of tax, in the Company’s Consolidated Balance Sheets. Changes in the fair value of available-for-sale securities impact the Company’s net income only when such securities are sold or an other-than-temporary impairment is recognized. Realized gains and losses on the sale of securities are determined by specific identification of each security’s cost basis. The Company regularly reviews its investment portfolio to determine if any security is other-than-temporarily impaired, which would require the Company to record an impairment charge in the period any such determination is made. In making this determination, the Company evaluates, among other things, the duration and extent to which the fair value of a security is less than its cost; the financial condition of the issuer and any changes thereto; and the Company’s intent to sell, or whether it will more likely than not be required to sell, the security before recovery of its amortized cost basis. The Company’s assessment of whether a security is other-than-temporarily impaired could change in the future due to new developments or changes in assumptions related to any particular security, which would have an adverse impact on the Company’s financial condition and operating results.

[0000320193-17-000070:mdna:153]
Inventory Valuation, Valuation of Manufacturing-Related Assets and Estimation of Purchase Commitment Cancellation Fees

[0000320193-17-000070:mdna:154]
The Company must purchase components and build inventory in advance of product shipments and has invested in manufacturing-related assets, including capital assets held at its suppliers’ facilities. In addition, the Company has made prepayments to certain of its suppliers associated with long-term supply agreements to secure supply of inventory components. The Company records a write-down for inventories of components and products, including third-party products held for resale, which have become obsolete or are in excess of anticipated demand or net realizable value. The Company performs a regular review of inventory that considers multiple factors including demand forecasts, product life cycle status, product development plans, current sales levels and component cost trends. The Company also reviews its manufacturing-related capital assets and inventory prepayments for impairment whenever events or circumstances indicate the carrying amount of such assets may not be recoverable. If the Company determines that an asset is not recoverable, it records an impairment loss equal to the amount by which the carrying value of such an asset exceeds its fair value.

[0000320193-17-000070:mdna:155]
The industries in which the Company competes are subject to a rapid and unpredictable pace of product and component obsolescence and demand changes. In certain circumstances the Company may be required to record additional write-downs of inventory and/or impairments of manufacturing-related assets or inventory prepayments. These circumstances include future demand or market conditions for the Company’s products being less favorable than forecasted, unforeseen technological changes or changes to the Company’s product development plans that negatively impact the utility of any of these assets, or significant deterioration in the financial condition of one or more of the Company’s suppliers that hold any of the Company’s manufacturing-related assets or to whom the Company has made an inventory prepayment. Such write-downs would adversely affect the Company’s financial condition and operating results in the period when the additional write-downs were recorded.

[0000320193-17-000070:mdna:156]
The Company accrues for estimated purchase commitment cancellation fees related to inventory orders that have been canceled or are expected to be canceled. Manufacturing purchase obligations typically cover the Company’s forecasted component and manufacturing requirements for periods up to 150 days. If there is an abrupt and substantial decline in demand for one or more of the Company’s products, a change in the Company’s product development plans, or an unanticipated change in technological requirements for any of the Company’s products, the Company may be required to record additional accruals for cancellation fees that would adversely affect its results of operations in the period when the cancellation fees were identified and recorded.

[0000320193-17-000070:mdna:157]
Warranty Costs

[0000320193-17-000070:mdna:158]
The Company accrues for the estimated cost of warranties in the period the related revenue is recognized based on historical and projected warranty claim rates, historical and projected cost per claim and knowledge of specific product failures that are outside of the Company’s typical experience. The Company regularly reviews these estimates and the current installed base of products subject to warranty protection to assess the appropriateness of its recorded warranty liabilities and adjusts the amounts as necessary. If actual product failure rates or repair costs differ from estimates, revisions to the estimated warranty liabilities could be required and could materially affect the Company’s financial condition and operating results.

[0000320193-17-000070:mdna:159]
Income Taxes

[0000320193-17-000070:mdna:160]
The Company records a tax provision for the anticipated tax consequences of its reported operating results. The provision for income taxes is computed using the asset and liability method, under which deferred tax assets and liabilities are recognized for the expected future tax consequences of temporary differences between the financial reporting and tax bases of assets and liabilities, and for operating losses and tax credit carryforwards. Deferred tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets and liabilities are expected to be realized or settled. The Company records a valuation allowance to reduce deferred tax assets to the amount that is believed more likely than not to be realized.

[0000320193-17-000070:mdna:161]
The Company recognizes tax benefits from uncertain tax positions only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement.

[0000320193-17-000070:mdna:162]
Management believes it is more likely than not that forecasted income, including income that may be generated as a result of certain tax planning strategies, together with future reversals of existing taxable temporary differences, will be sufficient to fully recover the Company’s deferred tax assets. In the event that the Company determines all or part of its net deferred tax assets are not realizable in the future, the Company will record an adjustment to the valuation allowance that would be charged to earnings in the period such determination is made. In addition, the calculation of tax liabilities involves significant judgment in estimating the impact of uncertainties in the application of GAAP and complex tax laws. Resolution of these uncertainties in a manner inconsistent with management’s expectations could have a material impact on the Company’s financial condition and operating results.

[0000320193-17-000070:mdna:163]
Legal and Other Contingencies

[0000320193-17-000070:mdna:164]
As discussed in Part I, Item 3 of this Form 10-K under the heading “Legal Proceedings” and in Part II, Item 8 of this Form 10-K in the Notes to Consolidated Financial Statements in Note 10, “Commitments and Contingencies,” the Company is subject to various legal proceedings and claims that arise in the ordinary course of business. The Company records a liability when it is probable that a loss has been incurred and the amount is reasonably estimable, the determination of which requires significant judgment. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to loss contingencies for asserted legal and other claims. However, the outcome of legal proceedings and claims brought against the Company is subject to significant uncertainty. Therefore, although management considers the likelihood of such an outcome to be remote, if one or more of these legal matters were resolved against the Company in a reporting period for amounts in excess of management’s expectations, the Company’s consolidated financial statements for that reporting period could be materially adversely affected.
