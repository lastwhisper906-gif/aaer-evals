# AAPL notes — 0000320193-17-000070


## aapl:CashCashEquivalentsandAvailableforSaleSecuritiesTableTextBlock

[0000320193-17-000070:notes:1]
The following tables show the Company’s cash and available-for-sale securities by significant investment category as of September 30, 2017 and September 24, 2016 (in millions):

[0000320193-17-000070:notes:2]
|  | 2017 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | Short-TermMarketableSecurities |  | Long-TermMarketableSecurities |
| Cash | $ | 7,982 |  |  | $ | — |  |  | $ | — |  |  | $ | 7,982 |  |  | $ | 7,982 |  |  | $ | — |  |  | $ | — |  |
| Level 1: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 6,534 |  |  | — |  |  | — |  |  | 6,534 |  |  | 6,534 |  |  | — |  |  | — |  |
| Mutual funds | 799 |  |  | — |  |  | (88 | ) |  | 711 |  |  | — |  |  | 711 |  |  | — |  |
| Subtotal | 7,333 |  |  | — |  |  | (88 | ) |  | 7,245 |  |  | 6,534 |  |  | 711 |  |  | — |  |
| Level 2: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 55,254 |  |  | 58 |  |  | (230 | ) |  | 55,082 |  |  | 865 |  |  | 17,228 |  |  | 36,989 |  |
| U.S. agency securities | 5,162 |  |  | 2 |  |  | (9 | ) |  | 5,155 |  |  | 1,439 |  |  | 2,057 |  |  | 1,659 |  |
| Non-U.S. government securities | 7,827 |  |  | 210 |  |  | (37 | ) |  | 8,000 |  |  | 9 |  |  | 123 |  |  | 7,868 |  |
| Certificates of deposit and time deposits | 5,832 |  |  | — |  |  | — |  |  | 5,832 |  |  | 1,142 |  |  | 3,918 |  |  | 772 |  |
| Commercial paper | 3,640 |  |  | — |  |  | — |  |  | 3,640 |  |  | 2,146 |  |  | 1,494 |  |  | — |  |
| Corporate securities | 152,724 |  |  | 969 |  |  | (242 | ) |  | 153,451 |  |  | 172 |  |  | 27,591 |  |  | 125,688 |  |
| Municipal securities | 961 |  |  | 4 |  |  | (1 | ) |  | 964 |  |  | — |  |  | 114 |  |  | 850 |  |
| Mortgage- and asset-backed securities | 21,684 |  |  | 35 |  |  | (175 | ) |  | 21,544 |  |  | — |  |  | 656 |  |  | 20,888 |  |
| Subtotal | 253,084 |  |  | 1,278 |  |  | (694 | ) |  | 253,668 |  |  | 5,773 |  |  | 53,181 |  |  | 194,714 |  |
| Total | $ | 268,399 |  |  | $ | 1,278 |  |  | $ | (782 | ) |  | $ | 268,895 |  |  | $ | 20,289 |  |  | $ | 53,892 |  |  | $ | 194,714 |  |

[0000320193-17-000070:notes:3]
|  | 2016 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | Short-TermMarketableSecurities |  | Long-TermMarketableSecurities |
| Cash | $ | 8,601 |  |  | $ | — |  |  | $ | — |  |  | $ | 8,601 |  |  | $ | 8,601 |  |  | $ | — |  |  | $ | — |  |
| Level 1: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 3,666 |  |  | — |  |  | — |  |  | 3,666 |  |  | 3,666 |  |  | — |  |  | — |  |
| Mutual funds | 1,407 |  |  | — |  |  | (146 | ) |  | 1,261 |  |  | — |  |  | 1,261 |  |  | — |  |
| Subtotal | 5,073 |  |  | — |  |  | (146 | ) |  | 4,927 |  |  | 3,666 |  |  | 1,261 |  |  | — |  |
| Level 2: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 41,697 |  |  | 319 |  |  | (4 | ) |  | 42,012 |  |  | 1,527 |  |  | 13,492 |  |  | 26,993 |  |
| U.S. agency securities | 7,543 |  |  | 16 |  |  | — |  |  | 7,559 |  |  | 2,762 |  |  | 2,441 |  |  | 2,356 |  |
| Non-U.S. government securities | 7,609 |  |  | 259 |  |  | (27 | ) |  | 7,841 |  |  | 110 |  |  | 818 |  |  | 6,913 |  |
| Certificates of deposit and time deposits | 6,598 |  |  | — |  |  | — |  |  | 6,598 |  |  | 1,108 |  |  | 3,897 |  |  | 1,593 |  |
| Commercial paper | 7,433 |  |  | — |  |  | — |  |  | 7,433 |  |  | 2,468 |  |  | 4,965 |  |  | — |  |
| Corporate securities | 131,166 |  |  | 1,409 |  |  | (206 | ) |  | 132,369 |  |  | 242 |  |  | 19,599 |  |  | 112,528 |  |
| Municipal securities | 956 |  |  | 5 |  |  | — |  |  | 961 |  |  | — |  |  | 167 |  |  | 794 |  |
| Mortgage- and asset-backed securities | 19,134 |  |  | 178 |  |  | (28 | ) |  | 19,284 |  |  | — |  |  | 31 |  |  | 19,253 |  |
| Subtotal | 222,136 |  |  | 2,186 |  |  | (265 | ) |  | 224,057 |  |  | 8,217 |  |  | 45,410 |  |  | 170,430 |  |
| Total | $ | 235,810 |  |  | $ | 2,186 |  |  | $ | (411 | ) |  | $ | 237,585 |  |  | $ | 20,484 |  |  | $ | 46,671 |  |  | $ | 170,430 |  |


## aapl:CommercialPaperCashFlowSummaryTableTextBlock

[0000320193-17-000070:notes:4]
The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for 2017 and 2016 (in millions):

[0000320193-17-000070:notes:5]
|  | 2017 |  | 2016 |
| Maturities less than 90 days: |  |  |  |
| Proceeds from/(Repayments of) commercial paper, net | $ | (1,782 | ) |  | $ | (869 | ) |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 17,932 |  |  | 3,632 |  |
| Repayments of commercial paper | (12,298 | ) |  | (3,160 | ) |
| Proceeds from/(Repayments of) commercial paper, net | 5,634 |  |  | 472 |  |
| Total change in commercial paper, net | $ | 3,852 |  |  | $ | (397 | ) |


## aapl:NotionalAndCreditRiskAmountsOfOutstandingDerivativePositionsDisclosureTextBlock

[0000320193-17-000070:notes:6]
The following table shows the notional amounts of the Company’s outstanding derivative instruments and credit risk amounts associated with outstanding or unsettled derivative instruments as of September 30, 2017 and September 24, 2016 (in millions):

[0000320193-17-000070:notes:7]
|  | 2017 |  | 2016 |
|  | NotionalAmount |  | Credit RiskAmount |  | NotionalAmount |  | Credit RiskAmount |
| Instruments designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 56,156 |  |  | $ | 1,049 |  |  | $ | 44,678 |  |  | $ | 518 |  |
| Interest rate contracts | $ | 33,000 |  |  | $ | 218 |  |  | $ | 24,500 |  |  | $ | 728 |  |
| Instruments not designated as accounting hedges: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 69,774 |  |  | $ | 363 |  |  | $ | 54,305 |  |  | $ | 153 |  |


## aapl:ScheduleOfCommonStockRepurchasedTableTextBlock

[0000320193-17-000070:notes:8]
Additionally, the Company repurchased shares of its common stock in the open market, which were retired upon repurchase, during the periods presented as follows:

[0000320193-17-000070:notes:9]
|  | Number ofShares(in thousands) |  | AverageRepurchasePrice Per Share |  | Amount(in millions) |
| 2017: |  |  |  |  |  |
| Fourth quarter | 29,073 |  |  | $ | 154.78 |  |  | $ | 4,500 |  |
| Third quarter | 30,356 |  |  | $ | 148.24 |  |  | 4,500 |  |
| Second quarter | 31,070 |  |  | $ | 128.74 |  |  | 4,001 |  |
| First quarter | 44,333 |  |  | $ | 112.78 |  |  | 5,000 |  |
| Total open market common stock repurchases | 134,832 |  |  |  |  | $ | 18,001 |  |
| 2016: |  |  |  |  |  |
| Fourth quarter | 28,579 |  |  | $ | 104.97 |  |  | $ | 3,000 |  |
| Third quarter | 41,238 |  |  | $ | 97.00 |  |  | 4,000 |  |
| Second quarter | 71,766 |  |  | $ | 97.54 |  |  | 7,000 |  |
| First quarter | 25,984 |  |  | $ | 115.45 |  |  | 3,000 |  |
| Total open market common stock repurchases | 167,567 |  |  |  |  | $ | 17,000 |  |


## us-gaap:AcceleratedShareRepurchasesTextBlock

[0000320193-17-000070:notes:10]
The following table shows the Company’s ASR activity and related information during the years ended September 30, 2017 and September 24, 2016:

[0000320193-17-000070:notes:11]
|  | Purchase Period End Date |  | Number ofShares(in thousands) |  | AverageRepurchasePrice Per Share |  | ASRAmount(in millions) |
| August 2017 ASR | November 2017 |  | 15,069 |  | (1) | (1) |  |  | $ | 3,000 |  |
| May 2017 ASR | August 2017 |  | 20,108 |  | (2) | $ | 149.20 |  |  | $ | 3,000 |  |
| February 2017 ASR | May 2017 |  | 20,949 |  |  | $ | 143.20 |  |  | $ | 3,000 |  |
| November 2016 ASR | February 2017 |  | 51,157 |  |  | $ | 117.29 |  |  | $ | 6,000 |  |
| August 2016 ASR | November 2016 |  | 26,850 |  |  | $ | 111.73 |  |  | $ | 3,000 |  |
| May 2016 ASR | August 2016 |  | 60,452 |  |  | $ | 99.25 |  |  | $ | 6,000 |  |
| November 2015 ASR | April 2016 |  | 29,122 |  |  | $ | 103.02 |  |  | $ | 3,000 |  |

[0000320193-17-000070:notes:12]
| (1) | “Number of Shares” represents those shares delivered at the beginning of the purchase period and does not represent the final number of shares to be delivered under the ASR. The total number of shares ultimately delivered, and therefore the average repurchase price paid per share, will be determined at the end of the purchase period based on the volume-weighted average price of the Company’s common stock during that period. The August 2017 ASR purchase period will end in November 2017. |

[0000320193-17-000070:notes:13]
| (2) | Includes 15.6 million shares delivered and retired at the beginning of the purchase period, which began in the third quarter of 2017, and 4.5 million shares delivered and retired at the end of the purchase period, which concluded in the fourth quarter of 2017. |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000320193-17-000070:notes:14]
Consolidated Financial Statement Details

[0000320193-17-000070:notes:15]
The following tables show the Company’s consolidated financial statement details as of September 30, 2017 and September 24, 2016 (in millions):

[0000320193-17-000070:notes:16]
Property, Plant and Equipment, Net

[0000320193-17-000070:notes:17]
|  | 2017 |  | 2016 |
| Land and buildings | $ | 13,587 |  |  | $ | 10,185 |  |
| Machinery, equipment and internal-use software | 54,210 |  |  | 44,543 |  |
| Leasehold improvements | 7,279 |  |  | 6,517 |  |
| Gross property, plant and equipment | 75,076 |  |  | 61,245 |  |
| Accumulated depreciation and amortization | (41,293 | ) |  | (34,235 | ) |
| Total property, plant and equipment, net | $ | 33,783 |  |  | $ | 27,010 |  |

[0000320193-17-000070:notes:18]
Other Non-Current Liabilities

[0000320193-17-000070:notes:19]
|  | 2017 |  | 2016 |
| Deferred tax liabilities | $ | 31,504 |  |  | $ | 26,019 |  |
| Other non-current liabilities | 8,911 |  |  | 10,055 |  |
| Total other non-current liabilities | $ | 40,415 |  |  | $ | 36,074 |  |

[0000320193-17-000070:notes:20]
Other Income/(Expense), Net

[0000320193-17-000070:notes:21]
The following table shows the detail of other income/(expense), net for 2017, 2016 and 2015 (in millions):

[0000320193-17-000070:notes:22]
|  | 2017 |  | 2016 |  | 2015 |
| Interest and dividend income | $ | 5,201 |  |  | $ | 3,999 |  |  | $ | 2,921 |  |
| Interest expense | (2,323 | ) |  | (1,456 | ) |  | (733 | ) |
| Other expense, net | (133 | ) |  | (1,195 | ) |  | (903 | ) |
| Total other income/(expense), net | $ | 2,745 |  |  | $ | 1,348 |  |  | $ | 1,285 |  |


## us-gaap:AdvertisingCostsPolicyTextBlock

[0000320193-17-000070:notes:23]
Advertising Costs

[0000320193-17-000070:notes:24]
Advertising costs are expensed as incurred and included in selling, general and administrative expenses.


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000320193-17-000070:notes:25]
Basis of Presentation and Preparation

[0000320193-17-000070:notes:26]
The accompanying consolidated financial statements include the accounts of the Company. Intercompany accounts and transactions have been eliminated. In the opinion of the Company’s management, the consolidated financial statements reflect all adjustments, which are normal and recurring in nature, necessary for fair financial statement presentation. The preparation of these consolidated financial statements in conformity with U.S. generally accepted accounting principles (“GAAP”) requires management to make estimates and assumptions that affect the amounts reported in these consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. Certain prior period amounts in the consolidated financial statements have been reclassified to conform to the current period’s presentation.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000320193-17-000070:notes:27]
Summary of Significant Accounting Policies

[0000320193-17-000070:notes:28]
Apple Inc. and its wholly-owned subsidiaries (collectively “Apple” or the “Company”) designs, manufactures and markets mobile communication and media devices and personal computers, and sells a variety of related software, services, accessories, networking solutions and third-party digital content and applications. The Company’s products and services include iPhone, iPad, Mac, Apple Watch, Apple TV, a portfolio of consumer and professional software applications, iOS, macOS, watchOS and tvOS operating systems, iCloud, Apple Pay and a variety of accessory, service and support offerings. The Company sells and delivers digital content and applications through the iTunes Store, App Store, Mac App Store, TV App Store, iBooks Store and Apple Music (collectively “Digital Content and Services”). The Company sells its products worldwide through its retail stores, online stores and direct sales force, as well as through third-party cellular network carriers, wholesalers, retailers and value-added resellers. In addition, the Company sells a variety of third-party Apple-compatible products, including application software and various accessories through its retail and online stores. The Company sells to consumers, small and mid-sized businesses and education, enterprise and government customers.

[0000320193-17-000070:notes:29]
The Company’s fiscal year is the 52 or 53-week period that ends on the last Saturday of September. The Company’s fiscal year 2017 included 53 weeks and ended on September 30, 2017. A 14th week was included in the first fiscal quarter of 2017, as is done every five or six years, to realign the Company’s fiscal quarters with calendar quarters. The Company’s fiscal years 2016 and 2015 ended on September 24, 2016 and September 26, 2015, respectively, and spanned 52 weeks each. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in September and the associated quarters, months and periods of those fiscal years.

[0000320193-17-000070:notes:30]
Revenue Recognition

[0000320193-17-000070:notes:31]
Net sales consist primarily of revenue from the sale of hardware, software, digital content and applications, accessories, and service and support contracts. The Company recognizes revenue when persuasive evidence of an arrangement exists, delivery has occurred, the sales price is fixed or determinable and collection is probable. Product is considered delivered to the customer once it has been shipped and title, risk of loss and rewards of ownership have been transferred. For most of the Company’s product sales, these criteria are met at the time the product is shipped. For online sales to individuals, for some sales to education customers in the U.S., and for certain other sales, the Company defers revenue until the customer receives the product because the Company retains a portion of the risk of loss on these sales during transit. For payment terms in excess of the Company’s standard payment terms, revenue is recognized as payments become due unless the Company has positive evidence that the sales price is fixed or determinable, such as a successful history of collection, without concession, on comparable arrangements. The Company recognizes revenue from the sale of hardware products, software bundled with hardware that is essential to the functionality of the hardware and third-party digital content sold on the iTunes Store in accordance with general revenue recognition accounting guidance. The Company recognizes revenue in accordance with industry-specific software accounting guidance for the following types of sales transactions: (i) standalone sales of software products, (ii) sales of software upgrades and (iii) sales of software bundled with hardware not essential to the functionality of the hardware.

[0000320193-17-000070:notes:32]
For the sale of most third-party products, the Company recognizes revenue based on the gross amount billed to customers because the Company establishes its own pricing for such products, retains related inventory risk for physical products, is the primary obligor to the customer and assumes the credit risk for amounts billed to its customers. For third-party applications sold through the App Store and Mac App Store and certain digital content sold through the iTunes Store, the Company does not determine the selling price of the products and is not the primary obligor to the customer. Therefore, the Company accounts for such sales on a net basis by recognizing in net sales only the commission it retains from each sale. The portion of the gross amount billed to customers that is remitted by the Company to third-party app developers and certain digital content owners is not reflected in the Company’s Consolidated Statements of Operations.

[0000320193-17-000070:notes:33]
The Company records deferred revenue when it receives payments in advance of the delivery of products or the performance of services. This includes amounts that have been deferred for unspecified and specified software upgrade rights and non-software services that are attached to hardware and software products. The Company sells gift cards redeemable at its retail and online stores, and also sells gift cards redeemable on iTunes Store, App Store, Mac App Store, TV App Store and iBooks Store for the purchase of digital content and software. The Company records deferred revenue upon the sale of the card, which is relieved upon redemption of the card by the customer. Revenue from AppleCare service and support contracts is deferred and recognized over the service coverage periods. AppleCare service and support contracts typically include extended phone support, repair services, web-based support resources and diagnostic tools offered under the Company’s standard limited warranty.

[0000320193-17-000070:notes:34]
The Company records reductions to revenue for estimated commitments related to price protection and other customer incentive programs. For transactions involving price protection, the Company recognizes revenue net of the estimated amount to be refunded. For the Company’s other customer incentive programs, the estimated cost of these programs is recognized at the later of the date at which the Company has sold the product or the date at which the program is offered. The Company also records reductions to revenue for expected future product returns based on the Company’s historical experience. Revenue is recorded net of taxes collected from customers that are remitted to governmental authorities, with the collected taxes recorded as current liabilities until remitted to the relevant government authority.

[0000320193-17-000070:notes:35]
Revenue Recognition for Arrangements with Multiple Deliverables

[0000320193-17-000070:notes:36]
For multi-element arrangements that include hardware products containing software essential to the hardware product’s functionality, undelivered software elements that relate to the hardware product’s essential software, and undelivered non-software services, the Company allocates revenue to all deliverables based on their relative selling prices. In such circumstances, the Company uses a hierarchy to determine the selling price to be used for allocating revenue to deliverables: (i) vendor-specific objective evidence of fair value (“VSOE”), (ii) third-party evidence of selling price (“TPE”) and (iii) best estimate of selling price (“ESP”). VSOE generally exists only when the Company sells the deliverable separately and is the price actually charged by the Company for that deliverable. ESPs reflect the Company’s best estimates of what the selling prices of elements would be if they were sold regularly on a stand-alone basis. For multi-element arrangements accounted for in accordance with industry-specific software accounting guidance, the Company allocates revenue to all deliverables based on the VSOE of each element, and if VSOE does not exist revenue is recognized when elements lacking VSOE are delivered.

[0000320193-17-000070:notes:37]
For sales of qualifying versions of iPhone, iPad, iPod touch, Mac, Apple Watch and Apple TV, the Company has indicated it may from time to time provide future unspecified software upgrades to the device’s essential software and/or non-software services free of charge. The Company has identified up to three deliverables regularly included in arrangements involving the sale of these devices. The first deliverable, which represents the substantial portion of the allocated sales price, is the hardware and software essential to the functionality of the hardware device delivered at the time of sale. The second deliverable is the embedded right included with qualifying devices to receive, on a when-and-if-available basis, future unspecified software upgrades relating to the product’s essential software. The third deliverable is the non-software services to be provided to qualifying devices. The Company allocates revenue between these deliverables using the relative selling price method. Because the Company has neither VSOE nor TPE for these deliverables, the allocation of revenue is based on the Company’s ESPs. Revenue allocated to the delivered hardware and the related essential software is recognized at the time of sale, provided the other conditions for revenue recognition have been met. Revenue allocated to the embedded unspecified software upgrade rights and the non-software services is deferred and recognized on a straight-line basis over the estimated period the software upgrades and non-software services are expected to be provided. Cost of sales related to delivered hardware and related essential software, including estimated warranty costs, are recognized at the time of sale. Costs incurred to provide non-software services are recognized as cost of sales as incurred, and engineering and sales and marketing costs are recognized as operating expenses as incurred.

[0000320193-17-000070:notes:38]
The Company’s process for determining its ESP for deliverables without VSOE or TPE considers multiple factors that may vary depending upon the unique facts and circumstances related to each deliverable including, where applicable, prices charged by the Company and market trends in the pricing for similar offerings, product-specific business objectives, estimated cost to provide the non-software services and the relative ESP of the upgrade rights and non-software services as compared to the total selling price of the product.

[0000320193-17-000070:notes:39]
Shipping Costs

[0000320193-17-000070:notes:40]
Amounts billed to customers related to shipping and handling are classified as revenue, and the Company’s shipping and handling costs are classified as cost of sales.

[0000320193-17-000070:notes:41]
Warranty Costs

[0000320193-17-000070:notes:42]
The Company generally provides for the estimated cost of hardware and software warranties in the period the related revenue is recognized. The Company assesses the adequacy of its accrued warranty liabilities and adjusts the amounts as necessary based on actual experience and changes in future estimates.

[0000320193-17-000070:notes:43]
Software Development Costs

[0000320193-17-000070:notes:44]
Research and development (“R&D”) costs are expensed as incurred. Development costs of computer software to be sold, leased, or otherwise marketed are subject to capitalization beginning when a product’s technological feasibility has been established and ending when a product is available for general release to customers. In most instances, the Company’s products are released soon after technological feasibility has been established and as a result software development costs were expensed as incurred.

[0000320193-17-000070:notes:45]
Share-based Compensation

[0000320193-17-000070:notes:46]
The Company recognizes expense related to share-based payment transactions in which it receives employee services in exchange for (a) equity instruments of the Company or (b) liabilities that are based on the fair value of the Company’s equity instruments or that may be settled by the issuance of such equity instruments. Share-based compensation expense for restricted stock units (“RSUs”) and restricted stock is measured based on the closing fair market value of the Company’s common stock on the date of grant. The Company estimates forfeitures expected to occur and recognizes share-based compensation expense for those equity awards expected to vest. The Company recognizes share-based compensation expense over the award’s requisite service period on a straight-line basis for time-based RSUs and on a graded basis for RSUs that are contingent on the achievement of performance conditions. The Company recognizes a benefit from share-based compensation in the Consolidated Statements of Shareholders’ Equity if an excess tax benefit is realized. In addition, the Company recognizes the indirect effects of share-based compensation on R&D tax credits, foreign tax credits and domestic manufacturing deductions in the Consolidated Statements of Operations. Further information regarding share-based compensation can be found in Note 9, “Benefit Plans.”

[0000320193-17-000070:notes:47]
Income Taxes

[0000320193-17-000070:notes:48]
The provision for income taxes is computed using the asset and liability method, under which deferred tax assets and liabilities are recognized for the expected future tax consequences of temporary differences between the financial reporting and tax bases of assets and liabilities and for operating losses and tax credit carryforwards. Deferred tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets and liabilities are expected to be realized or settled. The Company records a valuation allowance to reduce deferred tax assets to the amount that is believed more likely than not to be realized.

[0000320193-17-000070:notes:49]
The Company recognizes the tax benefit from an uncertain tax position only if it is more likely than not the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon settlement. See Note 5, “Income Taxes” for additional information.

[0000320193-17-000070:notes:50]
Earnings Per Share

[0000320193-17-000070:notes:51]
Basic earnings per share is computed by dividing income available to common shareholders by the weighted-average number of shares of common stock outstanding during the period. Diluted earnings per share is computed by dividing income available to common shareholders by the weighted-average number of shares of common stock outstanding during the period increased to include the number of additional shares of common stock that would have been outstanding if the potentially dilutive securities had been issued. Potentially dilutive securities include unvested RSUs, unvested restricted stock, outstanding stock options and shares to be purchased by employees under the Company’s employee stock purchase plan. The dilutive effect of potentially dilutive securities is reflected in diluted earnings per share by application of the treasury stock method. Under the treasury stock method, an increase in the fair market value of the Company’s common stock can result in a greater dilutive effect from potentially dilutive securities.

[0000320193-17-000070:notes:52]
The following table shows the computation of basic and diluted earnings per share for 2017, 2016 and 2015 (net income in millions and shares in thousands):

[0000320193-17-000070:notes:53]
|  | 2017 |  | 2016 |  | 2015 |
| Numerator: |  |  |  |  |  |
| Net income | $ | 48,351 |  |  | $ | 45,687 |  |  | $ | 53,394 |  |
| Denominator: |  |  |  |  |  |
| Weighted-average shares outstanding | 5,217,242 |  |  | 5,470,820 |  |  | 5,753,421 |  |
| Effect of dilutive securities | 34,450 |  |  | 29,461 |  |  | 39,648 |  |
| Weighted-average diluted shares | 5,251,692 |  |  | 5,500,281 |  |  | 5,793,069 |  |
| Basic earnings per share | $ | 9.27 |  |  | $ | 8.35 |  |  | $ | 9.28 |  |
| Diluted earnings per share | $ | 9.21 |  |  | $ | 8.31 |  |  | $ | 9.22 |  |

[0000320193-17-000070:notes:54]
Potentially dilutive securities whose effect would have been antidilutive are excluded from the computation of diluted earnings per share.

[0000320193-17-000070:notes:55]
Financial Instruments

[0000320193-17-000070:notes:56]
Cash Equivalents and Marketable Securities

[0000320193-17-000070:notes:57]
All highly liquid investments with maturities of three months or less at the date of purchase are classified as cash equivalents. The Company’s marketable debt and equity securities have been classified and accounted for as available-for-sale. Management determines the appropriate classification of its investments at the time of purchase and reevaluates the classifications at each balance sheet date. The Company classifies its marketable debt securities as either short-term or long-term based on each instrument’s underlying contractual maturity date. Marketable debt securities with maturities of 12 months or less are classified as short-term and marketable debt securities with maturities greater than 12 months are classified as long-term. Marketable equity securities, including mutual funds, are classified as either short-term or long-term based on the nature of each security and its availability for use in current operations. The Company’s marketable debt and equity securities are carried at fair value, with unrealized gains and losses, net of taxes, reported as a component of accumulated other comprehensive income/(loss) (“AOCI”) in shareholders’ equity, with the exception of unrealized losses believed to be other-than-temporary which are reported in earnings in the current period. The cost of securities sold is based upon the specific identification method.

[0000320193-17-000070:notes:58]
Derivative Financial Instruments

[0000320193-17-000070:notes:59]
The Company accounts for its derivative instruments as either assets or liabilities and carries them at fair value.

[0000320193-17-000070:notes:60]
For derivative instruments that hedge the exposure to variability in expected future cash flows that are designated as cash flow hedges, the effective portion of the gain or loss on the derivative instrument is reported as a component of AOCI in shareholders’ equity and reclassified into earnings in the same period or periods during which the hedged transaction affects earnings. The ineffective portion of the gain or loss on the derivative instrument, if any, is recognized in earnings in the current period. To receive hedge accounting treatment, cash flow hedges must be highly effective in offsetting changes to expected future cash flows on hedged transactions. For options designated as cash flow hedges, changes in the time value are excluded from the assessment of hedge effectiveness and are recognized in earnings.

[0000320193-17-000070:notes:61]
For derivative instruments that hedge the exposure to changes in the fair value of an asset or a liability and that are designated as fair value hedges, both the net gain or loss on the derivative instrument as well as the offsetting gain or loss on the hedged item are recognized in earnings in the current period.

[0000320193-17-000070:notes:62]
For derivative instruments and foreign currency debt that hedge the exposure to changes in foreign currency exchange rates used for translation of the net investment in a foreign operation and that are designated as a net investment hedge, the net gain or loss on the effective portion of the derivative instrument is reported in the same manner as a foreign currency translation adjustment. For forward exchange contracts designated as net investment hedges, the Company excludes changes in fair value relating to changes in the forward carry component from its definition of effectiveness. Accordingly, any gains or losses related to this forward carry component are recognized in earnings in the current period.

[0000320193-17-000070:notes:63]
Derivatives that do not qualify as hedges are adjusted to fair value through earnings in the current period.

[0000320193-17-000070:notes:64]
Allowance for Doubtful Accounts

[0000320193-17-000070:notes:65]
The Company records its allowance for doubtful accounts based upon its assessment of various factors, including historical experience, age of the accounts receivable balances, credit quality of the Company’s customers, current economic conditions and other factors that may affect the customers’ abilities to pay.

[0000320193-17-000070:notes:66]
Inventories

[0000320193-17-000070:notes:67]
Inventories are stated at the lower of cost, computed using the first-in, first-out method, and net realizable value. Any adjustments to reduce the cost of inventories to their net realizable value are recognized in earnings in the current period.

[0000320193-17-000070:notes:68]
Property, Plant and Equipment

[0000320193-17-000070:notes:69]
Property, plant and equipment are stated at cost. Depreciation is computed by use of the straight-line method over the estimated useful lives of the assets, which for buildings is the lesser of 30 years or the remaining life of the underlying building; between one and five years for machinery and equipment, including product tooling and manufacturing process equipment; and the shorter of lease term or useful life for leasehold improvements. The Company capitalizes eligible costs to acquire or develop internal-use software that are incurred subsequent to the preliminary project stage. Capitalized costs related to internal-use software are amortized using the straight-line method over the estimated useful lives of the assets, which range from three to five years. Depreciation and amortization expense on property and equipment was $8.2 billion, $8.3 billion and $9.2 billion during 2017, 2016 and 2015, respectively.

[0000320193-17-000070:notes:70]
Long-Lived Assets Including Goodwill and Other Acquired Intangible Assets

[0000320193-17-000070:notes:71]
The Company reviews property, plant and equipment, inventory component prepayments and identifiable intangibles, excluding goodwill and intangible assets with indefinite useful lives, for impairment. Long-lived assets are reviewed for impairment whenever events or changes in circumstances indicate the carrying amount of an asset may not be recoverable. Recoverability of these assets is measured by comparison of their carrying amounts to future undiscounted cash flows the assets are expected to generate. If property, plant and equipment, inventory component prepayments and certain identifiable intangibles are considered to be impaired, the impairment to be recognized equals the amount by which the carrying value of the asset exceeds its fair value.

[0000320193-17-000070:notes:72]
The Company does not amortize goodwill and intangible assets with indefinite useful lives; rather, such assets are required to be tested for impairment at least annually or sooner if events or changes in circumstances indicate that the assets may be impaired. The Company performs its goodwill and intangible asset impairment tests in the fourth quarter of each year. The Company did not recognize any impairment charges related to goodwill or indefinite lived intangible assets during 2017, 2016 and 2015. For purposes of testing goodwill for impairment, the Company established reporting units based on its current reporting structure. Goodwill has been allocated to these reporting units to the extent it relates to each reporting unit. In 2017 and 2016, the Company’s goodwill was primarily allocated to the Americas and Europe reporting units.

[0000320193-17-000070:notes:73]
The Company amortizes its intangible assets with definite useful lives over their estimated useful lives and reviews these assets for impairment. The Company typically amortizes its acquired intangible assets with definite useful lives over periods from three to seven years.

[0000320193-17-000070:notes:74]
Fair Value Measurements

[0000320193-17-000070:notes:75]
The Company applies fair value accounting for all financial assets and liabilities and non-financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. The Company defines fair value as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities that are required to be recorded at fair value, the Company considers the principal or most advantageous market in which the Company would transact and the market-based risk measurements or assumptions that market participants would use to price the asset or liability, such as risks inherent in valuation techniques, transfer restrictions and credit risk. Fair value is estimated by applying the following hierarchy, which prioritizes the inputs used to measure fair value into three levels and bases the categorization within the hierarchy upon the lowest level of input that is available and significant to the fair value measurement:

[0000320193-17-000070:notes:76]
Level 1 – Quoted prices in active markets for identical assets or liabilities.

[0000320193-17-000070:notes:77]
Level 2 – Observable inputs other than quoted prices in active markets for identical assets and liabilities, quoted prices for identical or similar assets or liabilities in inactive markets, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities.

[0000320193-17-000070:notes:78]
Level 3 – Inputs that are generally unobservable and typically reflect management’s estimate of assumptions that market participants would use in pricing the asset or liability.

[0000320193-17-000070:notes:79]
The Company’s valuation techniques used to measure the fair value of money market funds and certain marketable equity securities were derived from quoted prices in active markets for identical assets or liabilities. The valuation techniques used to measure the fair value of the Company’s debt instruments and all other financial instruments, all of which have counterparties with high credit ratings, were valued based on quoted market prices or model-driven valuations using significant inputs derived from or corroborated by observable market data.

[0000320193-17-000070:notes:80]
In accordance with the fair value accounting requirements, companies may choose to measure eligible financial instruments and certain other items at fair value. The Company has not elected the fair value option for any eligible financial instruments.

[0000320193-17-000070:notes:81]
Foreign Currency Translation and Remeasurement

[0000320193-17-000070:notes:82]
The Company translates the assets and liabilities of its non-U.S. dollar functional currency subsidiaries into U.S. dollars using exchange rates in effect at the end of each period. Revenue and expenses for these subsidiaries are translated using rates that approximate those in effect during the period. Gains and losses from these translations are recognized in foreign currency translation included in AOCI in shareholders’ equity. The Company’s subsidiaries that use the U.S. dollar as their functional currency remeasure monetary assets and liabilities at exchange rates in effect at the end of each period, and inventories, property and nonmonetary assets and liabilities at historical rates.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000320193-17-000070:notes:83]
Commitments and Contingencies

[0000320193-17-000070:notes:84]
Accrued Warranty and Indemnification

[0000320193-17-000070:notes:85]
The following table shows changes in the Company’s accrued warranties and related costs for 2017, 2016 and 2015 (in millions):

[0000320193-17-000070:notes:86]
|  | 2017 |  | 2016 |  | 2015 |
| Beginning accrued warranty and related costs | $ | 3,702 |  |  | $ | 4,780 |  |  | $ | 4,159 |  |
| Cost of warranty claims | (4,322 | ) |  | (4,663 | ) |  | (4,401 | ) |
| Accruals for product warranty | 4,454 |  |  | 3,585 |  |  | 5,022 |  |
| Ending accrued warranty and related costs | $ | 3,834 |  |  | $ | 3,702 |  |  | $ | 4,780 |  |

[0000320193-17-000070:notes:87]
Agreements entered into by the Company sometimes include indemnification provisions which may subject the Company to costs and damages in the event of a claim against an indemnified third party. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to indemnification of third parties.

[0000320193-17-000070:notes:88]
The Company offers an iPhone Upgrade Program, which is available to customers who purchase a qualifying iPhone in the U.S., the U.K. and mainland China. The iPhone Upgrade Program provides customers the right to trade in that iPhone for a specified amount when purchasing a new iPhone, provided certain conditions are met. The Company accounts for the trade-in right as a guarantee liability and recognizes arrangement revenue net of the fair value of such right, with subsequent changes to the guarantee liability recognized within revenue.

[0000320193-17-000070:notes:89]
The Company has entered into indemnification agreements with its directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers of the Company and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. While the Company maintains directors and officers liability insurance coverage, such insurance coverage may be insufficient to cover all losses or all types of claims that may arise.

[0000320193-17-000070:notes:90]
Concentrations in the Available Sources of Supply of Materials and Product

[0000320193-17-000070:notes:91]
Although most components essential to the Company’s business are generally available from multiple sources, a few components are currently obtained from single or limited sources. In addition, the Company competes for various components with other participants in the markets for mobile communication and media devices and personal computers. Therefore, many components used by the Company, including those that are available from multiple sources, are at times subject to industry-wide shortage and significant pricing fluctuations that could materially adversely affect the Company’s financial condition and operating results.

[0000320193-17-000070:notes:92]
The Company uses some custom components that are not commonly used by its competitors, and new products introduced by the Company often utilize custom components available from only one source. When a component or product uses new technologies, initial capacity constraints may exist until the suppliers’ yields have matured or manufacturing capacity has increased. If the Company’s supply of components for a new or existing product were delayed or constrained, or if an outsourcing partner delayed shipments of completed products to the Company, the Company’s financial condition and operating results could be materially adversely affected. The Company’s business and financial performance could also be materially adversely affected depending on the time required to obtain sufficient quantities from the original source, or to identify and obtain sufficient quantities from an alternative source. Continued availability of these components at acceptable prices, or at all, may be affected if those suppliers decide to concentrate on the production of common components instead of components customized to meet the Company’s requirements.

[0000320193-17-000070:notes:93]
The Company has entered into agreements for the supply of many components; however, there can be no guarantee that the Company will be able to extend or renew these agreements on similar terms, or at all. Therefore, the Company remains subject to significant risks of supply shortages and price increases that could materially adversely affect its financial condition and operating results.

[0000320193-17-000070:notes:94]
Substantially all of the Company’s hardware products are manufactured by outsourcing partners that are located primarily in Asia, with some Mac computers manufactured in the U.S. and Ireland. A significant concentration of this manufacturing is currently performed by a small number of outsourcing partners, often in single locations. Certain of these outsourcing partners are the sole-sourced suppliers of components and manufacturers for many of the Company’s products. Although the Company works closely with its outsourcing partners on manufacturing schedules, the Company’s operating results could be adversely affected if its outsourcing partners were unable to meet their production commitments. The Company’s manufacturing purchase obligations typically cover its requirements for periods up to 150 days.

[0000320193-17-000070:notes:95]
Other Off-Balance Sheet Commitments

[0000320193-17-000070:notes:96]
Operating Leases

[0000320193-17-000070:notes:97]
The Company leases various equipment and facilities, including retail space, under noncancelable operating lease arrangements. The Company does not currently utilize any other off-balance sheet financing arrangements. As of September 30, 2017, the Company’s total future minimum lease payments under noncancelable operating leases were $9.5 billion. The Company’s retail store and other facility leases typically have original terms not exceeding 10 years and generally contain multi-year renewal options.

[0000320193-17-000070:notes:98]
Rent expense under all operating leases, including both cancelable and noncancelable leases, was $1.1 billion, $939 million and $794 million in 2017, 2016 and 2015, respectively. Future minimum lease payments under noncancelable operating leases having initial or remaining terms in excess of one year as of September 30, 2017, are as follows (in millions):

[0000320193-17-000070:notes:99]
| 2018 | $ | 1,223 |  |
| 2019 | 1,187 |  |
| 2020 | 1,108 |  |
| 2021 | 1,033 |  |
| 2022 | 871 |  |
| Thereafter | 4,123 |  |
| Total | $ | 9,545 |  |

[0000320193-17-000070:notes:100]
Unconditional Purchase Obligations

[0000320193-17-000070:notes:101]
The Company has entered into certain off-balance sheet arrangements which require the future purchase of goods or services (“Unconditional Purchase Obligations”). The Company’s Unconditional Purchase Obligations primarily consist of payments for supplier arrangements, internet and telecommunication services and intellectual property licenses. Future payments under noncancelable Unconditional Purchase Obligations having a remaining term in excess of one year as of September 30, 2017, are as follows (in millions):

[0000320193-17-000070:notes:102]
| 2018 | $ | 1,798 |  |
| 2019 | 2,675 |  |
| 2020 | 1,626 |  |
| 2021 | 1,296 |  |
| 2022 | 1,268 |  |
| Thereafter | 14 |  |
| Total | $ | 8,677 |  |

[0000320193-17-000070:notes:103]
Contingencies

[0000320193-17-000070:notes:104]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully adjudicated, as further discussed in Part I, Item 1A of this Form 10-K under the heading “Risk Factors” and in Part I, Item 3 of this Form 10-K under the heading “Legal Proceedings.” In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to loss contingencies for asserted legal and other claims. However, the outcome of litigation is inherently uncertain. Therefore, although management considers the likelihood of such an outcome to be remote, if one or more of these legal matters were resolved against the Company in a reporting period for amounts in excess of management’s expectations, the Company’s consolidated financial statements for that reporting period could be materially adversely affected.

[0000320193-17-000070:notes:105]
Apple Inc. v. Samsung Electronics Co., Ltd., et al.

[0000320193-17-000070:notes:106]
On August 24, 2012, a jury returned a verdict awarding the Company $1.05 billion in its lawsuit against Samsung Electronics Co., Ltd. and affiliated parties in the United States District Court, Northern District of California, San Jose Division. On March 6, 2014, the District Court entered final judgment in favor of the Company in the amount of approximately $930 million. On May 18, 2015, the U.S. Court of Appeals for the Federal Circuit affirmed in part, and reversed in part, the decision of the District Court. As a result, the Court of Appeals ordered entry of final judgment on damages in the amount of approximately $548 million, with the District Court to determine supplemental damages and interest, as well as damages owed for products subject to the reversal in part. Samsung paid $548 million to the Company in December 2015, which was included in net sales in the Consolidated Statement of Operations. On December 6, 2016, the U.S. Supreme Court remanded the case to the U.S. Court of Appeals for the Federal Circuit for further proceedings related to the $548 million in damages. On February 7, 2017, the U.S. Court of Appeals for the Federal Circuit remanded the case to the District Court to determine what additional proceedings, if any, are needed. On October 22, 2017, on remand from the U.S. Supreme Court, the District Court ordered a new trial on damages.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000320193-17-000070:notes:107]
Benefit Plans

[0000320193-17-000070:notes:108]
2014 Employee Stock Plan

[0000320193-17-000070:notes:109]
In the second quarter of 2014, shareholders approved the 2014 Employee Stock Plan (the “2014 Plan”) and terminated the Company’s authority to grant new awards under the 2003 Employee Stock Plan (the “2003 Plan”). The 2014 Plan provides for broad-based equity grants to employees, including executive officers, and permits the granting of RSUs, stock grants, performance-based awards, stock options and stock appreciation rights, as well as cash bonus awards. RSUs granted under the 2014 Plan generally vest over four years, based on continued employment, and are settled upon vesting in shares of the Company’s common stock on a one-for-one basis. Each share issued with respect to RSUs granted under the 2014 Plan reduces the number of shares available for grant under the plan by two shares. RSUs canceled and shares withheld to satisfy tax withholding obligations increase the number of shares available for grant under the 2014 Plan utilizing a factor of two times the number of RSUs canceled or shares withheld. Currently, all RSUs granted under the 2014 Plan have dividend equivalent rights (“DERs”), which entitle holders of RSUs to the same dividend value per share as holders of common stock. DERs are subject to the same vesting and other terms and conditions as the corresponding unvested RSUs. DERs are accumulated and paid when the underlying shares vest. Upon approval of the 2014 Plan, the Company reserved 385 million shares plus the number of shares remaining that were reserved but not issued under the 2003 Plan. Shares subject to outstanding awards under the 2003 Plan that expire, are canceled or otherwise terminate, or are withheld to satisfy tax withholding obligations with respect to RSUs, will also be available for awards under the 2014 Plan. As of September 30, 2017, approximately 327.9 million shares were reserved for future issuance under the 2014 Plan.

[0000320193-17-000070:notes:110]
2003 Employee Stock Plan

[0000320193-17-000070:notes:111]
The 2003 Plan is a shareholder approved plan that provided for broad-based equity grants to employees, including executive officers. The 2003 Plan permitted the granting of incentive stock options, nonstatutory stock options, RSUs, stock appreciation rights, stock purchase rights and performance-based awards. Options granted under the 2003 Plan generally expire seven to ten years after the grant date and generally become exercisable over a period of four years, based on continued employment, with either annual, semi-annual or quarterly vesting. RSUs granted under the 2003 Plan generally vest over two to four years, based on continued employment and are settled upon vesting in shares of the Company’s common stock on a one-for-one basis. All RSUs, other than RSUs held by the Chief Executive Officer, granted under the 2003 Plan have DERs. DERs are subject to the same vesting and other terms and conditions as the corresponding unvested RSUs. DERs are accumulated and paid when the underlying shares vest. In the second quarter of 2014, the Company terminated the authority to grant new awards under the 2003 Plan.

[0000320193-17-000070:notes:112]
1997 Director Stock Plan

[0000320193-17-000070:notes:113]
The 1997 Director Stock Plan (the “Director Plan”) is a shareholder approved plan that (i) permits the Company to grant awards of RSUs or stock options to the Company’s non-employee directors, (ii) provides for automatic initial grants of RSUs upon a non-employee director joining the Board of Directors and automatic annual grants of RSUs at each annual meeting of shareholders, and (iii) permits the Board of Directors to prospectively change the relative mixture of stock options and RSUs for the initial and annual award grants and the methodology for determining the number of shares of the Company’s common stock subject to these grants without shareholder approval. Each share issued with respect to RSUs granted under the Director Plan reduces the number of shares available for grant under the plan by two shares. The Director Plan expires November 9, 2019. All RSUs granted under the Director Plan are entitled to DERs. DERs are subject to the same vesting and other terms and conditions as the corresponding unvested RSUs. DERs are accumulated and paid when the underlying shares vest. As of September 30, 2017, approximately 1.1 million shares were reserved for future issuance under the Director Plan.

[0000320193-17-000070:notes:114]
Rule 10b5-1 Trading Plans

[0000320193-17-000070:notes:115]
During the three months ended September 30, 2017, Section 16 officers Angela Ahrendts, Timothy D. Cook, Luca Maestri, Daniel Riccio and Philip Schiller had equity trading plans in place in accordance with Rule 10b5-1(c)(1) under the Exchange Act. An equity trading plan is a written document that pre-establishes the amounts, prices and dates (or formula for determining the amounts, prices and dates) of future purchases or sales of the Company’s stock, including shares acquired pursuant to the Company’s employee and director equity plans.

[0000320193-17-000070:notes:116]
Employee Stock Purchase Plan

[0000320193-17-000070:notes:117]
The Employee Stock Purchase Plan (the “Purchase Plan”) is a shareholder approved plan under which substantially all employees may purchase the Company’s common stock through payroll deductions at a price equal to 85% of the lower of the fair market values of the stock as of the beginning or the end of six-month offering periods. An employee’s payroll deductions under the Purchase Plan are limited to 10% of the employee’s compensation and employees may not purchase more than $25,000 of stock during any calendar year. As of September 30, 2017, approximately 41.5 million shares were reserved for future issuance under the Purchase Plan.

[0000320193-17-000070:notes:118]
401(k) Plan

[0000320193-17-000070:notes:119]
The Company’s 401(k) Plan is a deferred salary arrangement under Section 401(k) of the Internal Revenue Code. Under the 401(k) Plan, participating U.S. employees may defer a portion of their pre-tax earnings, up to the IRS annual contribution limit ($18,000 for calendar year 2017). The Company matches 50% to 100% of each employee’s contributions, depending on length of service, up to a maximum 6% of the employee’s eligible earnings.

[0000320193-17-000070:notes:120]
Restricted Stock Units

[0000320193-17-000070:notes:121]
A summary of the Company’s RSU activity and related information for 2017, 2016 and 2015, is as follows:

[0000320193-17-000070:notes:122]
|  | Number ofRSUs(in thousands) |  | Weighted-AverageGrant Date FairValue Per Share |  | Aggregate Fair Value(in millions) |
| Balance as of September 27, 2014 | 103,822 |  |  | $ | 70.98 |  |  |  |
| RSUs granted | 45,587 |  |  | $ | 105.51 |  |  |  |
| RSUs vested | (41,684 | ) |  | $ | 71.32 |  |  |  |
| RSUs canceled | (6,258 | ) |  | $ | 80.34 |  |  |  |
| Balance as of September 26, 2015 | 101,467 |  |  | $ | 85.77 |  |  |  |
| RSUs granted | 49,468 |  |  | $ | 109.28 |  |  |  |
| RSUs vested | (46,313 | ) |  | $ | 84.44 |  |  |  |
| RSUs canceled | (5,533 | ) |  | $ | 96.48 |  |  |  |
| Balance as of September 24, 2016 | 99,089 |  |  | $ | 97.54 |  |  |  |
| RSUs granted | 50,112 |  |  | $ | 121.65 |  |  |  |
| RSUs vested | (45,735 | ) |  | $ | 95.48 |  |  |  |
| RSUs canceled | (5,895 | ) |  | $ | 106.87 |  |  |  |
| Balance as of September 30, 2017 | 97,571 |  |  | $ | 110.33 |  |  | $ | 15,038 |  |

[0000320193-17-000070:notes:123]
The fair value as of the respective vesting dates of RSUs was $6.1 billion, $5.1 billion and $4.8 billion for 2017, 2016 and 2015, respectively. The majority of RSUs that vested in 2017, 2016 and 2015 were net share settled such that the Company withheld shares with value equivalent to the employees’ minimum statutory obligation for the applicable income and other employment taxes, and remitted the cash to the appropriate taxing authorities. The total shares withheld were approximately 15.4 million, 15.9 million and 14.1 million for 2017, 2016 and 2015, respectively, and were based on the value of the RSUs on their respective vesting dates as determined by the Company’s closing stock price. Total payments for the employees’ tax obligations to taxing authorities were $2.0 billion, $1.7 billion and $1.6 billion in 2017, 2016 and 2015, respectively, and are reflected as a financing activity within the Consolidated Statements of Cash Flows. These net share settlements had the effect of share repurchases by the Company as they reduced the number of shares that would have otherwise been issued as a result of the vesting and did not represent an expense to the Company.

[0000320193-17-000070:notes:124]
The following table shows a summary of the share-based compensation expense included in the Consolidated Statements of Operations for 2017, 2016 and 2015 (in millions):

[0000320193-17-000070:notes:125]
|  | 2017 |  | 2016 |  | 2015 |
| Cost of sales | $ | 877 |  |  | $ | 769 |  |  | $ | 575 |  |
| Research and development | 2,299 |  |  | 1,889 |  |  | 1,536 |  |
| Selling, general and administrative | 1,664 |  |  | 1,552 |  |  | 1,475 |  |
| Total share-based compensation expense | $ | 4,840 |  |  | $ | 4,210 |  |  | $ | 3,586 |  |

[0000320193-17-000070:notes:126]
The income tax benefit related to share-based compensation expense was $1.6 billion, $1.4 billion and $1.2 billion for 2017, 2016 and 2015, respectively. As of September 30, 2017, the total unrecognized compensation cost related to outstanding RSUs, restricted stock and stock options was $8.1 billion, which the Company expects to recognize over a weighted-average period of 2.5 years.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000320193-17-000070:notes:127]
Comprehensive Income

[0000320193-17-000070:notes:128]
Comprehensive income consists of two components, net income and OCI. OCI refers to revenue, expenses, and gains and losses that under GAAP are recorded as an element of shareholders’ equity but are excluded from net income. The Company’s OCI consists of foreign currency translation adjustments from those subsidiaries not using the U.S. dollar as their functional currency, net deferred gains and losses on certain derivative instruments accounted for as cash flow hedges and unrealized gains and losses on marketable securities classified as available-for-sale.

[0000320193-17-000070:notes:129]
The following table shows the pre-tax amounts reclassified from AOCI into the Consolidated Statements of Operations, and the associated financial statement line item, for 2017 and 2016 (in millions):

[0000320193-17-000070:notes:130]
| Comprehensive Income Components |  | Financial Statement Line Item |  | 2017 |  | 2016 |
| Unrealized (gains)/losses on derivative instruments: |  |  |  |  |  |  |
| Foreign exchange contracts |  | Revenue |  | $ | (662 | ) |  | $ | (865 | ) |
|  |  | Cost of sales |  | (654 | ) |  | (130 | ) |
|  |  | Other income/(expense), net |  | (638 | ) |  | 111 |  |
| Interest rate contracts |  | Other income/(expense), net |  | 2 |  |  | 12 |  |
|  |  |  |  | (1,952 | ) |  | (872 | ) |
| Unrealized (gains)/losses on marketable securities |  | Other income/(expense), net |  | (99 | ) |  | 87 |  |
| Total amounts reclassified from AOCI |  |  |  | $ | (2,051 | ) |  | $ | (785 | ) |

[0000320193-17-000070:notes:131]
The following table shows the changes in AOCI by component for 2017 and 2016 (in millions):

[0000320193-17-000070:notes:132]
|  | Cumulative ForeignCurrency Translation |  | Unrealized Gains/Losseson Derivative Instruments |  | Unrealized Gains/Losseson Marketable Securities |  | Total |
| Balances as of September 26, 2015 | $ | (653 | ) |  | $ | 772 |  |  | $ | (464 | ) |  | $ | (345 | ) |
| Other comprehensive income/(loss) before reclassifications | 67 |  |  | 14 |  |  | 2,445 |  |  | 2,526 |  |
| Amounts reclassified from AOCI | — |  |  | (872 | ) |  | 87 |  |  | (785 | ) |
| Tax effect | 8 |  |  | 124 |  |  | (894 | ) |  | (762 | ) |
| Other comprehensive income/(loss) | 75 |  |  | (734 | ) |  | 1,638 |  |  | 979 |  |
| Balances as of September 24, 2016 | (578 | ) |  | 38 |  |  | 1,174 |  |  | 634 |  |
| Other comprehensive income/(loss) before reclassifications | 301 |  |  | 1,793 |  |  | (1,207 | ) |  | 887 |  |
| Amounts reclassified from AOCI | — |  |  | (1,952 | ) |  | (99 | ) |  | (2,051 | ) |
| Tax effect | (77 | ) |  | (3 | ) |  | 460 |  |  | 380 |  |
| Other comprehensive income/(loss) | 224 |  |  | (162 | ) |  | (846 | ) |  | (784 | ) |
| Balances as of September 30, 2017 | $ | (354 | ) |  | $ | (124 | ) |  | $ | 328 |  |  | $ | (150 | ) |


## us-gaap:DebtDisclosureTextBlock

[0000320193-17-000070:notes:133]
Debt

[0000320193-17-000070:notes:134]
Commercial Paper

[0000320193-17-000070:notes:135]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of September 30, 2017 and September 24, 2016, the Company had $12.0 billion and $8.1 billion of Commercial Paper outstanding, respectively, with maturities generally less than nine months. The weighted-average interest rate of the Company’s Commercial Paper was 1.20% as of September 30, 2017 and 0.45% as of September 24, 2016.

[0000320193-17-000070:notes:136]
Term Debt

[0000320193-17-000070:notes:137]
As of September 30, 2017, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $104.0 billion (collectively the “Notes”). The Notes are senior unsecured obligations, and interest is payable in arrears, quarterly for the U.S. dollar-denominated and Australian dollar-denominated floating-rate notes, semi-annually for the U.S. dollar-denominated, Australian dollar-denominated, British pound-denominated, Japanese yen-denominated and Canadian dollar-denominated fixed-rate notes and annually for the euro-denominated and Swiss franc-denominated fixed-rate notes. The following table provides a summary of the Company’s term debt as of September 30, 2017 and September 24, 2016:

[0000320193-17-000070:notes:138]
|  | Maturities |  | 2017 |  | 2016 |
|  | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2018 |  | 2018 |  | $ | 2,000 |  |  |  | 1.10% |  | 1.10 | % |  | $ | 2,000 |  |  |  | 1.10% |  | 1.10 | % |
| Fixed-rate 1.000% – 3.850% notes | 2018 | – | 2043 |  | 12,500 |  |  |  | 1.08% | – | 3.91 | % |  | 12,500 |  |  |  | 1.08% | – | 3.91 | % |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 |  | 2019 |  | 1,000 |  |  |  | 1.61% |  | 1.61 | % |  | 2,000 |  |  |  | 0.86% | – | 1.09 | % |
| Fixed-rate 2.100% – 4.450% notes | 2019 | – | 2044 |  | 8,500 |  |  |  | 1.61% | – | 4.48 | % |  | 10,000 |  |  |  | 0.85% | – | 4.48 | % |
| 2015 debt issuances of $27.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2020 |  | 1,549 |  |  |  | 1.56% | – | 1.87 | % |  | 1,781 |  |  |  | 0.87% | – | 1.87 | % |
| Fixed-rate 0.350% – 4.375% notes | 2019 | – | 2045 |  | 24,522 |  |  |  | 0.28% | – | 4.51 | % |  | 25,144 |  |  |  | 0.28% | – | 4.51 | % |
| 2016 debt issuances of $24.9 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes | 2019 | – | 2021 |  | 1,350 |  |  |  | 1.45% | – | 2.44 | % |  | 1,350 |  |  |  | 0.91% | – | 1.95 | % |
| Fixed-rate 1.100% – 4.650% notes | 2018 | – | 2046 |  | 23,645 |  |  |  | 1.13% | – | 4.78 | % |  | 23,609 |  |  |  | 1.13% | – | 4.58 | % |

[0000320193-17-000070:notes:139]
|  | Maturities |  | 2017 |  | 2016 |
| (Continued) | Amount(in millions) |  | EffectiveInterest Rate |  | Amount(in millions) |  | EffectiveInterest Rate |
| Second quarter 2017 debt issuance of $10.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2019 |  | 500 |  |  |  |  |  | 1.39 | % |  | — |  |  |  |  |  | — | % |
| Floating-rate notes |  |  | 2020 |  | 500 |  |  |  |  |  | 1.51 | % |  | — |  |  |  |  |  | — | % |
| Floating-rate notes |  |  | 2022 |  | 1,000 |  |  |  |  |  | 1.81 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 1.550% notes |  |  | 2019 |  | 500 |  |  |  |  |  | 1.59 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 1.900% notes |  |  | 2020 |  | 1,000 |  |  |  |  |  | 1.51 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.500% notes |  |  | 2022 |  | 1,500 |  |  |  |  |  | 1.80 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.000% notes |  |  | 2024 |  | 1,750 |  |  |  |  |  | 2.11 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.350% notes |  |  | 2027 |  | 2,250 |  |  |  |  |  | 2.25 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 4.250% notes |  |  | 2047 |  | 1,000 |  |  |  |  |  | 4.26 | % |  | — |  |  |  |  |  | — | % |
| Second quarter 2017 debt issuance of $1.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 4.300% notes |  |  | 2047 |  | 1,000 |  |  |  |  |  | 4.30 | % |  | — |  |  |  |  |  | — | % |
| Third quarter 2017 debt issuance of $7.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2020 |  | 500 |  |  |  |  |  | 1.38 | % |  | — |  |  |  |  |  | — | % |
| Floating-rate notes |  |  | 2022 |  | 750 |  |  |  |  |  | 1.66 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 1.800% notes |  |  | 2020 |  | 1,000 |  |  |  |  |  | 1.84 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.300% notes |  |  | 2022 |  | 1,000 |  |  |  |  |  | 2.34 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.850% notes |  |  | 2024 |  | 1,750 |  |  |  |  |  | 2.25 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.200% notes |  |  | 2027 |  | 2,000 |  |  |  |  |  | 2.43 | % |  | — |  |  |  |  |  | — | % |
| Third quarter 2017 euro-denominated debt issuance of €2.5 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.875% notes |  |  | 2025 |  | 1,469 |  |  |  |  |  | 3.03 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 1.375% notes |  |  | 2029 |  | 1,469 |  |  |  |  |  | 3.37 | % |  | — |  |  |  |  |  | — | % |
| Third quarter 2017 debt issuance of $1.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 3.000% notes |  |  | 2027 |  | 1,000 |  |  |  |  |  | 3.03 | % |  | — |  |  |  |  |  | — | % |
| Fourth quarter 2017 Canadian dollar-denominated debt issuance of C$2.5 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 2.513% notes |  |  | 2024 |  | 2,017 |  |  |  |  |  | 2.66 | % |  | — |  |  |  |  |  | — | % |
| Fourth quarter 2017 debt issuance of $5.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 1.500% notes |  |  | 2019 |  | 1,000 |  |  |  |  |  | 1.54 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.100% notes |  |  | 2022 |  | 1,000 |  |  |  |  |  | 1.92 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 2.900% notes |  |  | 2027 |  | 2,000 |  |  |  |  |  | 2.55 | % |  | — |  |  |  |  |  | — | % |
| Fixed-rate 3.750% notes |  |  | 2047 |  | 1,000 |  |  |  |  |  | 3.78 | % |  | — |  |  |  |  |  | — | % |
| Total term debt |  |  |  |  | 104,021 |  |  |  |  |  |  |  | 78,384 |  |  |  |  |  |  |
| Unamortized premium/(discount) and issuance costs, net |  |  |  |  | (225 | ) |  |  |  |  |  |  | (174 | ) |  |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  | (93 | ) |  |  |  |  |  |  | 717 |  |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  |  |  | (6,496 | ) |  |  |  |  |  |  | (3,500 | ) |  |  |  |  |  |
| Total long-term debt |  |  |  |  | $ | 97,207 |  |  |  |  |  |  |  | $ | 75,427 |  |  |  |  |  |  |

[0000320193-17-000070:notes:140]
To manage interest rate risk on certain of its U.S. dollar-denominated fixed- or floating-rate notes, the Company has entered into interest rate swaps to effectively convert the fixed interest rates to floating interest rates or the floating interest rates to fixed interest rates on a portion of these notes. Additionally, to manage foreign currency risk on certain of its foreign currency-denominated notes, the Company has entered into foreign currency swaps to effectively convert these notes to U.S. dollar-denominated notes.

[0000320193-17-000070:notes:141]
A portion of the Company’s Japanese yen-denominated notes is designated as a hedge of the foreign currency exposure of the Company’s net investment in a foreign operation. As of September 30, 2017 and September 24, 2016, the carrying value of the debt designated as a net investment hedge was $1.6 billion and $1.9 billion, respectively.

[0000320193-17-000070:notes:142]
For further discussion regarding the Company’s use of derivative instruments see the Derivative Financial Instruments section of Note 2, “Financial Instruments.”

[0000320193-17-000070:notes:143]
The effective interest rates for the Notes include the interest on the Notes, amortization of the discount or premium and, if applicable, adjustments related to hedging. The Company recognized $2.2 billion, $1.4 billion and $722 million of interest expense on its term debt for 2017, 2016 and 2015, respectively.

[0000320193-17-000070:notes:144]
The future principal payments for the Company’s Notes as of September 30, 2017 are as follows (in millions):

[0000320193-17-000070:notes:145]
| 2018 | $ | 6,500 |  |
| 2019 | 8,863 |  |
| 2020 | 9,220 |  |
| 2021 | 7,750 |  |
| 2022 | 10,297 |  |
| Thereafter | 61,391 |  |
| Total term debt | $ | 104,021 |  |

[0000320193-17-000070:notes:146]
As of September 30, 2017 and September 24, 2016, the fair value of the Company’s Notes, based on Level 2 inputs, was $106.1 billion and $81.7 billion, respectively.


## us-gaap:DerivativesPolicyTextBlock

[0000320193-17-000070:notes:147]
The Company records all derivatives in the Consolidated Balance Sheets at fair value. The Company’s accounting treatment for these derivative instruments is based on its hedge designation.

[0000320193-17-000070:notes:148]
The Company may use derivatives to partially offset its business exposure to foreign currency and interest rate risk on expected future cash flows, on net investments in certain foreign subsidiaries and on certain existing assets and liabilities. However, the Company may choose not to hedge certain exposures for a variety of reasons including, but not limited to, accounting considerations and the prohibitive economic cost of hedging particular exposures. There can be no assurance the hedges will offset more than a portion of the financial impact resulting from movements in foreign currency exchange or interest rates.

[0000320193-17-000070:notes:149]
To help protect gross margins from fluctuations in foreign currency exchange rates, certain of the Company’s subsidiaries whose functional currency is the U.S. dollar may hedge a portion of forecasted foreign currency revenue, and subsidiaries whose functional currency is not the U.S. dollar and who sell in local currencies may hedge a portion of forecasted inventory purchases not denominated in the subsidiaries’ functional currencies. The Company may enter into forward contracts, option contracts or other instruments to manage this risk and may designate these instruments as cash flow hedges. The Company typically hedges portions of its forecasted foreign currency exposure associated with revenue and inventory purchases, typically for up to 12 months.

[0000320193-17-000070:notes:150]
To help protect the net investment in a foreign operation from adverse changes in foreign currency exchange rates, the Company may enter into foreign currency forward and option contracts to offset the changes in the carrying amounts of these investments due to fluctuations in foreign currency exchange rates. In addition, the Company may use non-derivative financial instruments, such as its foreign currency-denominated debt, as economic hedges of its net investments in certain foreign subsidiaries. In both of these cases, the Company designates these instruments as net investment hedges.

[0000320193-17-000070:notes:151]
The Company may also enter into non-designated foreign currency contracts to partially offset the foreign currency exchange gains and losses generated by the remeasurement of certain assets and liabilities denominated in non-functional currencies.

[0000320193-17-000070:notes:152]
The Company may enter into interest rate swaps, options, or other instruments to manage interest rate risk. These instruments may offset a portion of changes in income or expense, or changes in fair value of the Company’s term debt or investments. The Company designates these instruments as either cash flow or fair value hedges. The Company’s hedged interest rate transactions as of September 30, 2017 are expected to be recognized within 10 years.

[0000320193-17-000070:notes:153]
The Company may enter into foreign currency swaps to manage currency risk on its foreign currency-denominated term debt. These instruments may offset a portion of the foreign currency remeasurement gains or losses on the Company’s term debt and related interest payments. The Company designates these instruments as cash flow hedges. The Company’s hedged term debt-related foreign currency transactions as of September 30, 2017 are expected to be recognized within 25 years.

[0000320193-17-000070:notes:154]
Cash Flow Hedges

[0000320193-17-000070:notes:155]
The effective portions of cash flow hedges are recorded in AOCI until the hedged item is recognized in earnings. Deferred gains and losses associated with cash flow hedges of foreign currency revenue are recognized as a component of net sales in the same period as the related revenue is recognized, and deferred gains and losses related to cash flow hedges of inventory purchases are recognized as a component of cost of sales in the same period as the related costs are recognized. Deferred gains and losses associated with cash flow hedges of interest income or expense are recognized in other income/(expense), net in the same period as the related income or expense is recognized. The ineffective portions and amounts excluded from the effectiveness testing of cash flow hedges are recognized in other income/(expense), net.

[0000320193-17-000070:notes:156]
Derivative instruments designated as cash flow hedges must be de-designated as hedges when it is probable the forecasted hedged transaction will not occur in the initially identified time period or within a subsequent two-month time period. Deferred gains and losses in AOCI associated with such derivative instruments are reclassified into other income/(expense), net in the period of de-designation. Any subsequent changes in fair value of such derivative instruments are reflected in other income/(expense), net unless they are re-designated as hedges of other transactions.

[0000320193-17-000070:notes:157]
Net Investment Hedges

[0000320193-17-000070:notes:158]
The effective portions of net investment hedges are recorded in other comprehensive income/(loss) (“OCI”) as a part of the cumulative translation adjustment. The ineffective portions and amounts excluded from the effectiveness testing of net investment hedges are recognized in other income/(expense), net.

[0000320193-17-000070:notes:159]
Fair Value Hedges

[0000320193-17-000070:notes:160]
Gains and losses related to changes in fair value hedges are recognized in earnings along with a corresponding loss or gain related to the change in value of the underlying hedged item.

[0000320193-17-000070:notes:161]
Non-Designated Derivatives

[0000320193-17-000070:notes:162]
Derivatives that are not designated as hedging instruments are adjusted to fair value through earnings in the financial statement line item to which the derivative relates.


## us-gaap:DividendsDeclaredTableTextBlock

[0000320193-17-000070:notes:163]
The Company declared and paid cash dividends per share during the periods presented as follows:

[0000320193-17-000070:notes:164]
|  | DividendsPer Share |  | Amount(in millions) |
| 2017: |  |  |  |
| Fourth quarter | $ | 0.63 |  |  | $ | 3,252 |  |
| Third quarter | 0.63 |  |  | 3,281 |  |
| Second quarter | 0.57 |  |  | 2,988 |  |
| First quarter | 0.57 |  |  | 3,042 |  |
| Total cash dividends declared and paid | $ | 2.40 |  |  | $ | 12,563 |  |
| 2016: |  |  |  |
| Fourth quarter | $ | 0.57 |  |  | $ | 3,071 |  |
| Third quarter | 0.57 |  |  | 3,117 |  |
| Second quarter | 0.52 |  |  | 2,879 |  |
| First quarter | 0.52 |  |  | 2,898 |  |
| Total cash dividends declared and paid | $ | 2.18 |  |  | $ | 11,965 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000320193-17-000070:notes:165]
Cash, Cash Equivalents and Marketable Securities

[0000320193-17-000070:notes:166]
The Company may sell certain of its marketable securities prior to their stated maturities for strategic reasons including, but not limited to, anticipation of credit deterioration and duration management. The maturities of the Company’s long-term marketable securities generally range from one to five years.

[0000320193-17-000070:notes:167]
The Company considers the declines in market value of its marketable securities investment portfolio to be temporary in nature. The Company typically invests in highly-rated securities, and its investment policy generally limits the amount of credit exposure to any one issuer. The policy generally requires investments to be investment grade, with the primary objective of minimizing the potential risk of principal loss. Fair values were determined for each individual security in the investment portfolio. When evaluating an investment for other-than-temporary impairment, the Company reviews factors such as the length of time and extent to which fair value has been below its cost basis, the financial condition of the issuer and any changes thereto, changes in market interest rates and the Company’s intent to sell, or whether it is more likely than not it will be required to sell the investment before recovery of the investment’s cost basis. As of September 30, 2017, the Company does not consider any of its investments to be other-than-temporarily impaired.

[0000320193-17-000070:notes:168]
Derivatives that are not designated as hedging instruments are adjusted to fair value through earnings in the financial statement line item to which the derivative relates. As a result, the Company recognized a gain of $20 million in net sales, a loss of $40 million in cost of sales and a gain of $606 million in other income/(expense), net for 2017.

[0000320193-17-000070:notes:169]
The Company records all derivatives in the Consolidated Balance Sheets at fair value. The Company’s accounting treatment for these derivative instruments is based on its hedge designation. The following tables show the Company’s derivative instruments at gross fair value as of September 30, 2017 and September 24, 2016 (in millions):

[0000320193-17-000070:notes:170]
|  | 2017 |
|  | Fair Value ofDerivatives Designatedas Hedge Instruments |  | Fair Value ofDerivatives Not Designatedas Hedge Instruments |  | TotalFair Value |
| Derivative assets (1): |  |  |  |  |  |
| Foreign exchange contracts | $ | 1,049 |  |  | $ | 363 |  |  | $ | 1,412 |  |
| Interest rate contracts | $ | 218 |  |  | $ | — |  |  | $ | 218 |  |
| Derivative liabilities (2): |  |  |  |  |  |
| Foreign exchange contracts | $ | 759 |  |  | $ | 501 |  |  | $ | 1,260 |  |
| Interest rate contracts | $ | 303 |  |  | $ | — |  |  | $ | 303 |  |

[0000320193-17-000070:notes:171]
|  | 2016 |
|  | Fair Value ofDerivatives Designatedas Hedge Instruments |  | Fair Value ofDerivatives Not Designatedas Hedge Instruments |  | TotalFair Value |
| Derivative assets (1): |  |  |  |  |  |
| Foreign exchange contracts | $ | 518 |  |  | $ | 153 |  |  | $ | 671 |  |
| Interest rate contracts | $ | 728 |  |  | $ | — |  |  | $ | 728 |  |
| Derivative liabilities (2): |  |  |  |  |  |
| Foreign exchange contracts | $ | 935 |  |  | $ | 134 |  |  | $ | 1,069 |  |
| Interest rate contracts | $ | 7 |  |  | $ | — |  |  | $ | 7 |  |

[0000320193-17-000070:notes:172]
| (1) | The fair value of derivative assets is measured using Level 2 fair value inputs and is recorded as other current assets and other non-current assets in the Consolidated Balance Sheets. |

[0000320193-17-000070:notes:173]
| (2) | The fair value of derivative liabilities is measured using Level 2 fair value inputs and is recorded as accrued expenses and other non-current liabilities in the Consolidated Balance Sheets. |

[0000320193-17-000070:notes:174]
The following table shows the pre-tax gains and losses of the Company’s derivative and non-derivative instruments designated as cash flow, net investment and fair value hedges in OCI and the Consolidated Statements of Operations for 2017, 2016 and 2015 (in millions):

[0000320193-17-000070:notes:175]
|  | 2017 |  | 2016 |  | 2015 |
| Gains/(Losses) recognized in OCI – effective portion: |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |
| Foreign exchange contracts | $ | 1,797 |  |  | $ | 109 |  |  | $ | 3,592 |  |
| Interest rate contracts | 7 |  |  | (57 | ) |  | (111 | ) |
| Total | $ | 1,804 |  |  | $ | 52 |  |  | $ | 3,481 |  |
| Net investment hedges: |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | — |  |  | $ | 167 |  |
| Foreign currency debt | 67 |  |  | (258 | ) |  | (71 | ) |
| Total | $ | 67 |  |  | $ | (258 | ) |  | $ | 96 |  |
| Gains/(Losses) reclassified from AOCI into net income – effective portion: |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |
| Foreign exchange contracts | $ | 1,958 |  |  | $ | 885 |  |  | $ | 4,092 |  |
| Interest rate contracts | (2 | ) |  | (11 | ) |  | (17 | ) |
| Total | $ | 1,956 |  |  | $ | 874 |  |  | $ | 4,075 |  |
| Gains/(Losses) on derivative instruments: |  |  |  |  |  |
| Fair value hedges: |  |  |  |  |  |
| Interest rate contracts | $ | (810 | ) |  | $ | 341 |  |  | $ | 337 |  |
| Gains/(Losses) related to hedged items: |  |  |  |  |  |
| Fair value hedges: |  |  |  |  |  |
| Fixed-rate debt | $ | 810 |  |  | $ | (341 | ) |  | $ | (337 | ) |

[0000320193-17-000070:notes:176]
The notional amounts for outstanding derivative instruments provide one measure of the transaction volume outstanding and do not represent the amount of the Company’s exposure to credit or market loss. The credit risk amounts represent the Company’s gross exposure to potential accounting loss on derivative instruments that are outstanding or unsettled if all counterparties failed to perform according to the terms of the contract, based on then-current currency or interest rates at each respective date. The Company’s exposure to credit loss and market risk will vary over time as currency and interest rates change. Although the table above reflects the notional and credit risk amounts of the Company’s derivative instruments, it does not reflect the gains or losses associated with the exposures and transactions that the instruments are intended to hedge. The amounts ultimately realized upon settlement of these financial instruments, together with the gains and losses on the underlying exposures, will depend on actual market conditions during the remaining life of the instruments.

[0000320193-17-000070:notes:177]
The Company generally enters into master netting arrangements, which are designed to reduce credit risk by permitting net settlement of transactions with the same counterparty. To further limit credit risk, the Company generally enters into collateral security arrangements that provide for collateral to be received or posted when the net fair value of certain financial instruments fluctuates from contractually established thresholds. The Company presents its derivative assets and derivative liabilities at their gross fair values in its Consolidated Balance Sheets. The net cash collateral received by the Company related to derivative instruments under its collateral security arrangements was $35 million and $163 million as of September 30, 2017 and September 24, 2016, respectively, which were recorded as accrued expenses in the Consolidated Balance Sheets.

[0000320193-17-000070:notes:178]
Under master netting arrangements with the respective counterparties to the Company’s derivative contracts, the Company is allowed to net settle transactions with a single net amount payable by one party to the other. As of September 30, 2017 and September 24, 2016, the potential effects of these rights of set-off associated with the Company’s derivative contracts, including the effects of collateral, would be a reduction to both derivative assets and derivative liabilities of $1.4 billion and $1.5 billion, respectively, resulting in net derivative assets of $32 million and $160 million, respectively.

[0000320193-17-000070:notes:179]
Accounts Receivable

[0000320193-17-000070:notes:180]
Trade Receivables

[0000320193-17-000070:notes:181]
The Company has considerable trade receivables outstanding with its third-party cellular network carriers, wholesalers, retailers, value-added resellers, small and mid-sized businesses and education, enterprise and government customers. The Company generally does not require collateral from its customers; however, the Company will require collateral in certain instances to limit credit risk. In addition, when possible, the Company attempts to limit credit risk on trade receivables with credit insurance for certain customers or by requiring third-party financing, loans or leases to support credit exposure. These credit-financing arrangements are directly between the third-party financing company and the end customer. As such, the Company generally does not assume any recourse or credit risk sharing related to any of these arrangements.

[0000320193-17-000070:notes:182]
As of September 30, 2017, the Company had two customers that individually represented 10% or more of total trade receivables, each of which accounted for 10%. As of September 24, 2016, the Company had one customer that represented 10% or more of total trade receivables, which accounted for 10%. The Company’s cellular network carriers accounted for 59% and 63% of trade receivables as of September 30, 2017 and September 24, 2016, respectively.

[0000320193-17-000070:notes:183]
Vendor Non-Trade Receivables

[0000320193-17-000070:notes:184]
The Company has non-trade receivables from certain of its manufacturing vendors resulting from the sale of components to these vendors who manufacture sub-assemblies or assemble final products for the Company. The Company purchases these components directly from suppliers. As of September 30, 2017, the Company had three vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 42%, 19% and 10%. As of September 24, 2016, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 47% and 21%.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000320193-17-000070:notes:185]
The provision for income taxes for 2017, 2016 and 2015, consisted of the following (in millions):

[0000320193-17-000070:notes:186]
|  | 2017 |  | 2016 |  | 2015 |
| Federal: |  |  |  |  |  |
| Current | $ | 7,842 |  |  | $ | 7,652 |  |  | $ | 11,730 |  |
| Deferred | 5,980 |  |  | 5,043 |  |  | 3,408 |  |
| Total (1) | 13,822 |  |  | 12,695 |  |  | 15,138 |  |
| State: |  |  |  |  |  |
| Current | 259 |  |  | 990 |  |  | 1,265 |  |
| Deferred | 2 |  |  | (138 | ) |  | (220 | ) |
| Total | 261 |  |  | 852 |  |  | 1,045 |  |
| Foreign: |  |  |  |  |  |
| Current | 1,671 |  |  | 2,105 |  |  | 4,744 |  |
| Deferred | (16 | ) |  | 33 |  |  | (1,806 | ) |
| Total | 1,655 |  |  | 2,138 |  |  | 2,938 |  |
| Provision for income taxes | $ | 15,738 |  |  | $ | 15,685 |  |  | $ | 19,121 |  |

[0000320193-17-000070:notes:187]
| (1) | Includes taxes of $7.9 billion, $6.7 billion and $7.3 billion provided on foreign pre-tax earnings in 2017, 2016 and 2015, respectively. |

[0000320193-17-000070:notes:188]
The foreign provision for income taxes is based on foreign pre-tax earnings of $44.7 billion, $41.1 billion and $47.6 billion in 2017, 2016 and 2015, respectively. The Company’s consolidated financial statements provide for any related tax liability on undistributed earnings that the Company does not intend to be indefinitely reinvested outside the U.S. Substantially all of the Company’s undistributed international earnings intended to be indefinitely reinvested in operations outside the U.S. were generated by subsidiaries organized in Ireland, which has a statutory tax rate of 12.5%. As of September 30, 2017, U.S. income taxes have not been provided on a cumulative total of $128.7 billion of such earnings. The amount of unrecognized deferred tax liability related to these temporary differences is estimated to be $42.2 billion.

[0000320193-17-000070:notes:189]
As of September 30, 2017 and September 24, 2016, $252.3 billion and $216.0 billion, respectively, of the Company’s cash, cash equivalents and marketable securities were held by foreign subsidiaries and are generally based in U.S. dollar-denominated holdings. Amounts held by foreign subsidiaries are generally subject to U.S. income taxation on repatriation to the U.S.

[0000320193-17-000070:notes:190]
A reconciliation of the provision for income taxes, with the amount computed by applying the statutory federal income tax rate (35% in 2017, 2016 and 2015) to income before provision for income taxes for 2017, 2016 and 2015, is as follows (dollars in millions):

[0000320193-17-000070:notes:191]
|  | 2017 |  | 2016 |  | 2015 |
| Computed expected tax | $ | 22,431 |  |  | $ | 21,480 |  |  | $ | 25,380 |  |
| State taxes, net of federal effect | 185 |  |  | 553 |  |  | 680 |  |
| Indefinitely invested earnings of foreign subsidiaries | (6,135 | ) |  | (5,582 | ) |  | (6,470 | ) |
| Domestic production activities deduction | (209 | ) |  | (382 | ) |  | (426 | ) |
| Research and development credit, net | (678 | ) |  | (371 | ) |  | (171 | ) |
| Other | 144 |  |  | (13 | ) |  | 128 |  |
| Provision for income taxes | $ | 15,738 |  |  | $ | 15,685 |  |  | $ | 19,121 |  |
| Effective tax rate | 24.6 | % |  | 25.6 | % |  | 26.4 | % |

[0000320193-17-000070:notes:192]
The Company’s income taxes payable have been reduced by the tax benefits from employee stock plan awards. For RSUs, the Company receives an income tax benefit upon the award’s vesting equal to the tax effect of the underlying stock’s fair market value. The Company had net excess tax benefits from equity awards of $620 million, $379 million and $748 million in 2017, 2016 and 2015, respectively, which were reflected as increases to common stock.

[0000320193-17-000070:notes:193]
As of September 30, 2017 and September 24, 2016, the significant components of the Company’s deferred tax assets and liabilities were (in millions):

[0000320193-17-000070:notes:194]
|  | 2017 |  | 2016 |
| Deferred tax assets: |  |  |  |
| Accrued liabilities and other reserves | $ | 4,019 |  |  | $ | 4,135 |  |
| Basis of capital assets | 1,230 |  |  | 2,107 |  |
| Deferred revenue | 1,521 |  |  | 1,717 |  |
| Deferred cost sharing | 667 |  |  | 667 |  |
| Share-based compensation | 703 |  |  | 601 |  |
| Other | 834 |  |  | 788 |  |
| Total deferred tax assets, net of valuation allowance of $0 | 8,974 |  |  | 10,015 |  |
| Deferred tax liabilities: |  |  |  |
| Unremitted earnings of foreign subsidiaries | 36,355 |  |  | 31,436 |  |
| Other | 207 |  |  | 485 |  |
| Total deferred tax liabilities | 36,562 |  |  | 31,921 |  |
| Net deferred tax liabilities | $ | (27,588 | ) |  | $ | (21,906 | ) |

[0000320193-17-000070:notes:195]
Deferred tax assets and liabilities reflect the effects of tax losses, credits and the future income tax effects of temporary differences between the consolidated financial statement carrying amounts of existing assets and liabilities and their respective tax bases and are measured using enacted tax rates that apply to taxable income in the years in which those temporary differences are expected to be recovered or settled.

[0000320193-17-000070:notes:196]
Uncertain Tax Positions

[0000320193-17-000070:notes:197]
Tax positions are evaluated in a two-step process. The Company first determines whether it is more likely than not that a tax position will be sustained upon examination. If a tax position meets the more-likely-than-not recognition threshold it is then measured to determine the amount of benefit to recognize in the financial statements. The tax position is measured as the largest amount of benefit that is greater than 50% likely of being realized upon ultimate settlement. The Company classifies gross interest and penalties and unrecognized tax benefits that are not expected to result in payment or receipt of cash within one year as non-current liabilities in the Consolidated Balance Sheets.

[0000320193-17-000070:notes:198]
As of September 30, 2017, the total amount of gross unrecognized tax benefits was $8.4 billion, of which $2.5 billion, if recognized, would affect the Company’s effective tax rate. As of September 24, 2016, the total amount of gross unrecognized tax benefits was $7.7 billion, of which $2.8 billion, if recognized, would have affected the Company’s effective tax rate.

[0000320193-17-000070:notes:199]
The aggregate changes in the balance of gross unrecognized tax benefits, which excludes interest and penalties, for 2017, 2016 and 2015, is as follows (in millions):

[0000320193-17-000070:notes:200]
|  | 2017 |  | 2016 |  | 2015 |
| Beginning balances | $ | 7,724 |  |  | $ | 6,900 |  |  | $ | 4,033 |  |
| Increases related to tax positions taken during a prior year | 333 |  |  | 1,121 |  |  | 2,056 |  |
| Decreases related to tax positions taken during a prior year | (952 | ) |  | (257 | ) |  | (345 | ) |
| Increases related to tax positions taken during the current year | 1,880 |  |  | 1,578 |  |  | 1,278 |  |
| Decreases related to settlements with taxing authorities | (539 | ) |  | (1,618 | ) |  | (109 | ) |
| Decreases related to expiration of statute of limitations | (39 | ) |  | — |  |  | (13 | ) |
| Ending balances | $ | 8,407 |  |  | $ | 7,724 |  |  | $ | 6,900 |  |

[0000320193-17-000070:notes:201]
The Company includes interest and penalties related to unrecognized tax benefits within the provision for income taxes. As of September 30, 2017 and September 24, 2016, the total amount of gross interest and penalties accrued was $1.2 billion and $1.0 billion, respectively, which is classified as non-current liabilities in the Consolidated Balance Sheets. In connection with tax matters, the Company recognized interest and penalty expense in 2017, 2016 and 2015 of $165 million, $295 million and $709 million, respectively.

[0000320193-17-000070:notes:202]
The Company is subject to taxation and files income tax returns in the U.S. federal jurisdiction and in many state and foreign jurisdictions. The U.S. Internal Revenue Service (the “IRS”) concluded its review of the years 2010 through 2012 during the third quarter of 2017. All years prior to 2013 are closed, and the IRS is currently examining the years 2013 through 2015. The Company is also subject to audits by state, local and foreign tax authorities. In major states and major foreign jurisdictions, the years subsequent to 2003 generally remain open and could be subject to examination by the taxing authorities.

[0000320193-17-000070:notes:203]
The Company believes that an adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax audits cannot be predicted with certainty. If any issues addressed in the Company’s tax audits are resolved in a manner not consistent with its expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. Although timing of the resolution and/or closure of audits is not certain, the Company does not believe it is reasonably possible that its gross unrecognized tax benefits would materially change in the next 12 months.

[0000320193-17-000070:notes:204]
On August 30, 2016, the European Commission announced its decision that Ireland granted state aid to the Company by providing tax opinions in 1991 and 2007 concerning the tax allocation of profits of the Irish branches of two subsidiaries of the Company (the “State Aid Decision”). The State Aid Decision orders Ireland to calculate and recover additional taxes from the Company for the period June 2003 through December 2014. Irish legislative changes, effective as of January 2015, eliminated the application of the tax opinions from that date forward. The Company believes the State Aid Decision to be without merit and appealed to the General Court of the Court of Justice of the European Union. Ireland has also appealed the State Aid Decision. Although Ireland is still computing the recovery amount, the Company expects the amount to be in line with the European Commission’s announced recovery amount of €13 billion, plus interest of €1 billion. Once the recovery amount is finalized by Ireland, the Company anticipates funding it, including interest, out of foreign cash. These amounts are expected to be placed into escrow in 2018, where they will remain pending conclusion of all appeals. The Company believes that any incremental Irish corporate income taxes potentially due related to the State Aid Decision would be creditable against U.S. taxes.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000320193-17-000070:notes:205]
Acquired Intangible Assets

[0000320193-17-000070:notes:206]
The Company’s acquired intangible assets with definite useful lives primarily consist of patents and licenses. The following table summarizes the components of acquired intangible asset balances as of September 30, 2017 and September 24, 2016 (in millions):

[0000320193-17-000070:notes:207]
|  | 2017 |  | 2016 |
|  | GrossCarrying Amount |  | AccumulatedAmortization |  | NetCarrying Amount |  | GrossCarrying Amount |  | AccumulatedAmortization |  | NetCarrying Amount |
| Definite-lived and amortizable acquired intangible assets | $ | 7,507 |  |  | $ | (5,309 | ) |  | $ | 2,198 |  |  | $ | 8,912 |  |  | $ | (5,806 | ) |  | $ | 3,106 |  |
| Indefinite-lived and non-amortizable acquired intangible assets | 100 |  |  | — |  |  | 100 |  |  | 100 |  |  | — |  |  | 100 |  |
| Total acquired intangible assets | $ | 7,607 |  |  | $ | (5,309 | ) |  | $ | 2,298 |  |  | $ | 9,012 |  |  | $ | (5,806 | ) |  | $ | 3,206 |  |

[0000320193-17-000070:notes:208]
Amortization expense related to acquired intangible assets was $1.2 billion, $1.5 billion and $1.3 billion in 2017, 2016 and 2015, respectively. As of September 30, 2017, the remaining weighted-average amortization period for acquired intangible assets is 3.4 years. The expected annual amortization expense related to acquired intangible assets as of September 30, 2017, is as follows (in millions):

[0000320193-17-000070:notes:209]
| 2018 | $ | 948 |  |
| 2019 | 505 |  |
| 2020 | 323 |  |
| 2021 | 222 |  |
| 2022 | 131 |  |
| Thereafter | 69 |  |
| Total | $ | 2,198 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000320193-17-000070:notes:210]
Selected Quarterly Financial Information (Unaudited)

[0000320193-17-000070:notes:211]
The following tables show a summary of the Company’s quarterly financial information for each of the four quarters of 2017 and 2016 (in millions, except per share amounts):

[0000320193-17-000070:notes:212]
|  | Fourth Quarter |  | Third Quarter |  | Second Quarter |  | First Quarter |
| 2017: |  |  |  |  |  |  |  |
| Net sales | $ | 52,579 |  |  | $ | 45,408 |  |  | $ | 52,896 |  |  | $ | 78,351 |  |
| Gross margin | $ | 19,931 |  |  | $ | 17,488 |  |  | $ | 20,591 |  |  | $ | 30,176 |  |
| Net income | $ | 10,714 |  |  | $ | 8,717 |  |  | $ | 11,029 |  |  | $ | 17,891 |  |
| Earnings per share (1): |  |  |  |  |  |  |  |
| Basic | $ | 2.08 |  |  | $ | 1.68 |  |  | $ | 2.11 |  |  | $ | 3.38 |  |
| Diluted | $ | 2.07 |  |  | $ | 1.67 |  |  | $ | 2.10 |  |  | $ | 3.36 |  |

[0000320193-17-000070:notes:213]
|  | Fourth Quarter |  | Third Quarter |  | Second Quarter |  | First Quarter |
| 2016: |  |  |  |  |  |  |  |
| Net sales | $ | 46,852 |  |  | $ | 42,358 |  |  | $ | 50,557 |  |  | $ | 75,872 |  |
| Gross margin | $ | 17,813 |  |  | $ | 16,106 |  |  | $ | 19,921 |  |  | $ | 30,423 |  |
| Net income | $ | 9,014 |  |  | $ | 7,796 |  |  | $ | 10,516 |  |  | $ | 18,361 |  |
| Earnings per share (1): |  |  |  |  |  |  |  |
| Basic | $ | 1.68 |  |  | $ | 1.43 |  |  | $ | 1.91 |  |  | $ | 3.30 |  |
| Diluted | $ | 1.67 |  |  | $ | 1.42 |  |  | $ | 1.90 |  |  | $ | 3.28 |  |

[0000320193-17-000070:notes:214]
| (1) | Basic and diluted earnings per share are computed independently for each of the quarters presented. Therefore, the sum of quarterly basic and diluted per share information may not equal annual basic and diluted earnings per share. |


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0000320193-17-000070:notes:215]
A reconciliation of the Company’s segment operating income to the Consolidated Statements of Operations for 2017, 2016 and 2015 is as follows (in millions):

[0000320193-17-000070:notes:216]
|  | 2017 |  | 2016 |  | 2015 |
| Segment operating income | $ | 77,631 |  |  | $ | 74,301 |  |  | $ | 83,850 |  |
| Research and development expense | (11,581 | ) |  | (10,045 | ) |  | (8,067 | ) |
| Other corporate expenses, net | (4,706 | ) |  | (4,232 | ) |  | (4,553 | ) |
| Total operating income | $ | 61,344 |  |  | $ | 60,024 |  |  | $ | 71,230 |  |


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0000320193-17-000070:notes:217]
Net sales by product for 2017, 2016 and 2015 were as follows (in millions):

[0000320193-17-000070:notes:218]
|  | 2017 |  | 2016 |  | 2015 |
| iPhone (1) | $ | 141,319 |  |  | $ | 136,700 |  |  | $ | 155,041 |  |
| iPad (1) | 19,222 |  |  | 20,628 |  |  | 23,227 |  |
| Mac (1) | 25,850 |  |  | 22,831 |  |  | 25,471 |  |
| Services (2) | 29,980 |  |  | 24,348 |  |  | 19,909 |  |
| Other Products (1)(3) | 12,863 |  |  | 11,132 |  |  | 10,067 |  |
| Total net sales | $ | 229,234 |  |  | $ | 215,639 |  |  | $ | 233,715 |  |

[0000320193-17-000070:notes:219]
| (1) | Includes deferrals and amortization of related software upgrade rights and non-software services. |

[0000320193-17-000070:notes:220]
| (2) | Includes revenue from Digital Content and Services, AppleCare, Apple Pay, licensing and other services. Services net sales in the fourth quarter of 2017 included a favorable one-time adjustment of $640 million due to a change in estimate based on the availability of additional supporting information. |

[0000320193-17-000070:notes:221]
| (3) | Includes sales of Apple TV, Apple Watch, Beats products, iPod touch and Apple-branded and third-party accessories. |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0000320193-17-000070:notes:222]
Net sales for 2017, 2016 and 2015 and long-lived assets as of September 30, 2017 and September 24, 2016 were as follows (in millions):

[0000320193-17-000070:notes:223]
|  | 2017 |  | 2016 |  | 2015 |
| Net sales: |  |  |  |  |  |
| U.S. | $ | 84,339 |  |  | $ | 75,667 |  |  | $ | 81,732 |  |
| China (1) | 44,764 |  |  | 48,492 |  |  | 58,715 |  |
| Other countries | 100,131 |  |  | 91,480 |  |  | 93,268 |  |
| Total net sales | $ | 229,234 |  |  | $ | 215,639 |  |  | $ | 233,715 |  |

[0000320193-17-000070:notes:224]
|  | 2017 |  | 2016 |
| Long-lived assets: |  |  |  |
| U.S. | $ | 20,637 |  |  | $ | 16,364 |  |
| China (1) | 10,211 |  |  | 7,875 |  |
| Other countries | 2,935 |  |  | 2,771 |  |
| Total long-lived assets | $ | 33,783 |  |  | $ | 27,010 |  |

[0000320193-17-000070:notes:225]
| (1) | China includes Hong Kong and Taiwan. Long-lived assets located in China consist primarily of product tooling and manufacturing process equipment and assets related to retail stores and related infrastructure. |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000320193-17-000070:notes:226]
The following table shows information by reportable segment for 2017, 2016 and 2015 (in millions):

[0000320193-17-000070:notes:227]
|  | 2017 |  | 2016 |  | 2015 |
| Americas: |  |  |  |  |  |
| Net sales | $ | 96,600 |  |  | $ | 86,613 |  |  | $ | 93,864 |  |
| Operating income | $ | 30,684 |  |  | $ | 28,172 |  |  | $ | 31,186 |  |
| Europe: |  |  |  |  |  |
| Net sales | $ | 54,938 |  |  | $ | 49,952 |  |  | $ | 50,337 |  |
| Operating income | $ | 16,514 |  |  | $ | 15,348 |  |  | $ | 16,527 |  |
| Greater China: |  |  |  |  |  |
| Net sales | $ | 44,764 |  |  | $ | 48,492 |  |  | $ | 58,715 |  |
| Operating income | $ | 17,032 |  |  | $ | 18,835 |  |  | $ | 23,002 |  |
| Japan: |  |  |  |  |  |
| Net sales | $ | 17,733 |  |  | $ | 16,928 |  |  | $ | 15,706 |  |
| Operating income | $ | 8,097 |  |  | $ | 7,165 |  |  | $ | 7,617 |  |
| Rest of Asia Pacific: |  |  |  |  |  |
| Net sales | $ | 15,199 |  |  | $ | 13,654 |  |  | $ | 15,093 |  |
| Operating income | $ | 5,304 |  |  | $ | 4,781 |  |  | $ | 5,518 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000320193-17-000070:notes:228]
Segment Information and Geographic Data

[0000320193-17-000070:notes:229]
The Company reports segment information based on the “management” approach. The management approach designates the internal reporting used by management for making decisions and assessing performance as the source of the Company’s reportable segments.

[0000320193-17-000070:notes:230]
The Company manages its business primarily on a geographic basis. The Company’s reportable segments consist of the Americas, Europe, Greater China, Japan and Rest of Asia Pacific. Americas includes both North and South America. Europe includes European countries, as well as India, the Middle East and Africa. Greater China includes China, Hong Kong and Taiwan. Rest of Asia Pacific includes Australia and those Asian countries not included in the Company’s other reportable segments. Although the reportable segments provide similar hardware and software products and similar services, each one is managed separately to better align with the location of the Company’s customers and distribution partners and the unique market dynamics of each geographic region. The accounting policies of the various segments are the same as those described in Note 1, “Summary of Significant Accounting Policies.”

[0000320193-17-000070:notes:231]
The Company evaluates the performance of its reportable segments based on net sales and operating income. Net sales for geographic segments are generally based on the location of customers and sales through the Company’s retail stores located in those geographic locations. Operating income for each segment includes net sales to third parties, related cost of sales and operating expenses directly attributable to the segment. Advertising expenses are generally included in the geographic segment in which the expenditures are incurred. Operating income for each segment excludes other income and expense and certain expenses managed outside the reportable segments. Costs excluded from segment operating income include various corporate expenses such as R&D, corporate marketing expenses, certain share-based compensation expenses, income taxes, various nonrecurring charges and other separately managed general and administrative costs. The Company does not include intercompany transfers between segments for management reporting purposes.

[0000320193-17-000070:notes:232]
The U.S. and China were the only countries that accounted for more than 10% of the Company’s net sales in 2017, 2016 and 2015. There was no single customer that accounted for more than 10% of net sales in 2017, 2016 and 2015. Net sales for 2017, 2016 and 2015 and long-lived assets as of September 30, 2017 and September 24, 2016 were as follows (in millions):


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000320193-17-000070:notes:233]
Shareholders’ Equity

[0000320193-17-000070:notes:234]
Dividends

[0000320193-17-000070:notes:235]
Future dividends are subject to declaration by the Board of Directors.

[0000320193-17-000070:notes:236]
Share Repurchase Program

[0000320193-17-000070:notes:237]
In May 2017, the Company’s Board of Directors increased the share repurchase authorization from $175 billion to $210 billion of the Company’s common stock, of which $166 billion had been utilized as of September 30, 2017. The Company’s share repurchase program does not obligate it to acquire any specific number of shares. Under the program, shares may be repurchased in privately negotiated and/or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).

[0000320193-17-000070:notes:238]
The Company has entered, and in the future may enter, into accelerated share repurchase arrangements (“ASRs”) with financial institutions. In exchange for up-front payments, the financial institutions deliver shares of the Company’s common stock during the purchase periods of each ASR. The total number of shares ultimately delivered, and therefore the average repurchase price paid per share, is determined at the end of the applicable purchase period of each ASR based on the volume-weighted average price of the Company’s common stock during that period. The shares received are retired in the periods they are delivered, and the up-front payments are accounted for as a reduction to shareholders’ equity in the Company’s Consolidated Balance Sheets in the periods the payments are made. The Company reflects the ASRs as a repurchase of common stock in the period delivered for purposes of calculating earnings per share and as forward contracts indexed to its own common stock. The ASRs met all of the applicable criteria for equity classification, and therefore were not accounted for as derivative instruments.
