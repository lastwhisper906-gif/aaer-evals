# AAPL notes — 0001193125-15-023697


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001193125-15-023697:notes:1]
Basis of Presentation and Preparation

[0001193125-15-023697:notes:2]
The accompanying condensed consolidated financial
 statements include the accounts of the Company. Intercompany
 accounts and transactions have been eliminated. The preparation of
 these condensed consolidated financial statements in conformity
 with U.S. generally accepted accounting principles
 (“GAAP”) requires management to make estimates and
 assumptions that affect the amounts reported in these condensed
 consolidated financial statements and accompanying notes. Actual
 results could differ materially from those estimates.

[0001193125-15-023697:notes:3]
Certain prior period amounts in the notes to the
 condensed consolidated financial statements have been reclassified
 to conform to the current period’s presentation. In the first
 quarter of 2015, the Company changed its reportable operating
 segments and began allocating certain costs to its operating
 segments that were previously included in other corporate expenses.
 The Company has reclassified the corresponding prior period amounts
 to conform to the current period’s presentation as further
 described in Note 11, “Segment Information and Geographic
 Data.”

[0001193125-15-023697:notes:4]
These condensed consolidated financial statements
 and accompanying notes should be read in conjunction with the
 Company’s annual consolidated financial statements and the
 notes thereto for the fiscal year ended September 27, 2014,
 included in its Annual Report on Form 10-K (the “2014 Form
 10-K”). The Company’s fiscal year is the 52 or 53-week
 period that ends on the last Saturday of September. An additional
 week is included in the first fiscal quarter approximately every
 six years to realign fiscal quarters with calendar quarters. The
 Company’s fiscal years 2015 and 2014 each include 52 weeks.
 Unless otherwise stated, references to particular years, quarters
 or months refer to the Company’s fiscal years ended in
 September and the associated quarters or months of those fiscal
 years.


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001193125-15-023697:notes:5]
The following tables show the Company’s cash
 and available-for-sale
 securities’ adjusted cost, gross unrealized gains, gross
 unrealized losses and fair value by significant investment category
 recorded as cash and cash equivalents or short- or long-term
 marketable securities as of December 27, 2014 and
 September 27, 2014 (in millions):

[0001193125-15-023697:notes:6]
|  |  | December 27, 2014 |  |
|  |  | Adjusted Cost |  |  | Unrealized Gains |  |  | Unrealized Losses |  |  | Fair Value |  |  | Cash and Cash Equivalents |  |  | Short-Term Marketable Securities |  |  | Long-Term Marketable Securities |  |
| Cash |  | $ | 13,757 |  |  | $ | 0 |  |  | $ | 0 |  |  | $ | 13,757 |  |  | $ | 13,757 |  |  | $ | 0 |  |  | $ | 0 |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  |  | 3,346 |  |  |  | 0 |  |  |  | 0 |  |  |  | 3,346 |  |  |  | 3,346 |  |  |  | 0 |  |  |  | 0 |  |
| Mutual funds |  |  | 2,544 |  |  |  | 0 |  |  |  | (159 | ) |  |  | 2,385 |  |  |  | 0 |  |  |  | 2,385 |  |  |  | 0 |  |
| Subtotal |  |  | 5,890 |  |  |  | 0 |  |  |  | (159 | ) |  |  | 5,731 |  |  |  | 3,346 |  |  |  | 2,385 |  |  |  | 0 |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities |  |  | 35,107 |  |  |  | 16 |  |  |  | (58 | ) |  |  | 35,065 |  |  |  | 545 |  |  |  | 692 |  |  |  | 33,828 |  |
| U.S. agency securities |  |  | 6,788 |  |  |  | 2 |  |  |  | (11 | ) |  |  | 6,779 |  |  |  | 582 |  |  |  | 291 |  |  |  | 5,906 |  |
| Non-U.S. government securities |  |  | 6,498 |  |  |  | 58 |  |  |  | (105 | ) |  |  | 6,451 |  |  |  | 0 |  |  |  | 177 |  |  |  | 6,274 |  |
| Certificates of deposit and time deposits |  |  | 2,778 |  |  |  | 0 |  |  |  | 0 |  |  |  | 2,778 |  |  |  | 272 |  |  |  | 1,168 |  |  |  | 1,338 |  |
| Commercial paper |  |  | 1,159 |  |  |  | 0 |  |  |  | 0 |  |  |  | 1,159 |  |  |  | 879 |  |  |  | 280 |  |  |  | 0 |  |
| Corporate securities |  |  | 92,371 |  |  |  | 159 |  |  |  | (720 | ) |  |  | 91,810 |  |  |  | 97 |  |  |  | 7,932 |  |  |  | 83,781 |  |
| Municipal securities |  |  | 939 |  |  |  | 4 |  |  |  | (1 | ) |  |  | 942 |  |  |  | 0 |  |  |  | 0 |  |  |  | 942 |  |
| Mortgage- and asset-backed securities |  |  | 13,501 |  |  |  | 32 |  |  |  | (50 | ) |  |  | 13,483 |  |  |  | 0 |  |  |  | 60 |  |  |  | 13,423 |  |
| Subtotal |  |  | 159,141 |  |  |  | 271 |  |  |  | (945 | ) |  |  | 158,467 |  |  |  | 2,375 |  |  |  | 10,600 |  |  |  | 145,492 |  |
| Total |  | $ | 178,788 |  |  | $ | 271 |  |  | $ | (1,104 | ) |  | $ | 177,955 |  |  | $ | 19,478 |  |  | $ | 12,985 |  |  | $ | 145,492 |  |
|  |  | September 27, 2014 |  |
|  |  | Adjusted Cost |  |  | Unrealized Gains |  |  | Unrealized Losses |  |  | Fair Value |  |  | Cash and Cash Equivalents |  |  | Short-Term Marketable Securities |  |  | Long-Term Marketable Securities |  |
| Cash |  | $ | 10,232 |  |  | $ | 0 |  |  | $ | 0 |  |  | $ | 10,232 |  |  | $ | 10,232 |  |  | $ | 0 |  |  | $ | 0 |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  |  | 1,546 |  |  |  | 0 |  |  |  | 0 |  |  |  | 1,546 |  |  |  | 1,546 |  |  |  | 0 |  |  |  | 0 |  |
| Mutual funds |  |  | 2,531 |  |  |  | 1 |  |  |  | (132 | ) |  |  | 2,400 |  |  |  | 0 |  |  |  | 2,400 |  |  |  | 0 |  |
| Subtotal |  |  | 4,077 |  |  |  | 1 |  |  |  | (132 | ) |  |  | 3,946 |  |  |  | 1,546 |  |  |  | 2,400 |  |  |  | 0 |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities |  |  | 23,140 |  |  |  | 15 |  |  |  | (9 | ) |  |  | 23,146 |  |  |  | 12 |  |  |  | 607 |  |  |  | 22,527 |  |
| U.S. agency securities |  |  | 7,373 |  |  |  | 3 |  |  |  | (11 | ) |  |  | 7,365 |  |  |  | 652 |  |  |  | 157 |  |  |  | 6,556 |  |
| Non-U.S. government securities |  |  | 6,925 |  |  |  | 69 |  |  |  | (69 | ) |  |  | 6,925 |  |  |  | 0 |  |  |  | 204 |  |  |  | 6,721 |  |
| Certificates of deposit and time deposits |  |  | 3,832 |  |  |  | 0 |  |  |  | 0 |  |  |  | 3,832 |  |  |  | 1,230 |  |  |  | 1,233 |  |  |  | 1,369 |  |
| Commercial paper |  |  | 475 |  |  |  | 0 |  |  |  | 0 |  |  |  | 475 |  |  |  | 166 |  |  |  | 309 |  |  |  | 0 |  |
| Corporate securities |  |  | 85,431 |  |  |  | 296 |  |  |  | (241 | ) |  |  | 85,486 |  |  |  | 6 |  |  |  | 6,298 |  |  |  | 79,182 |  |
| Municipal securities |  |  | 940 |  |  |  | 8 |  |  |  | 0 |  |  |  | 948 |  |  |  | 0 |  |  |  | 0 |  |  |  | 948 |  |
| Mortgage- and asset-backed securities |  |  | 12,907 |  |  |  | 26 |  |  |  | (49 | ) |  |  | 12,884 |  |  |  | 0 |  |  |  | 25 |  |  |  | 12,859 |  |
| Subtotal |  |  | 141,023 |  |  |  | 417 |  |  |  | (379 | ) |  |  | 141,061 |  |  |  | 2,066 |  |  |  | 8,833 |  |  |  | 130,162 |  |
| Total |  | $ | 155,332 |  |  | $ | 418 |  |  | $ | (511 | ) |  | $ | 155,239 |  |  | $ | 13,844 |  |  | $ | 11,233 |  |  | $ | 130,162 |  |

[0001193125-15-023697:notes:7]
|  | (1) | The fair value of Level 1 securities is estimated based on quoted prices in active markets for identical assets or liabilities. |  |

[0001193125-15-023697:notes:8]
|  | (2) | The fair value of Level 2 securities is estimated based on observable inputs other than quoted prices in active markets for identical assets and liabilities, quoted prices for identical or similar assets or liabilities in inactive markets, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities. |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-15-023697:notes:9]
Note 10 – Commitments and Contingencies

[0001193125-15-023697:notes:10]
Accrued Warranty and Indemnification

[0001193125-15-023697:notes:11]
The following table shows changes in the
 Company’s accrued warranties and related costs for the three
 months ended December 27, 2014 and December 28, 2013 (in
 millions):

[0001193125-15-023697:notes:12]
|  |  | Three Months Ended |  |
|  |  | December 27, 2014 |  |  | December 28, 2013 |  |
| Beginning accrued warranty and related costs |  | $ | 4,159 |  |  | $ | 2,967 |  |
| Cost of warranty claims |  |  | (1,044 | ) |  |  | (1,064 | ) |
| Accruals for product warranty |  |  | 2,080 |  |  |  | 2,077 |  |
| Ending accrued warranty and related costs |  | $ | 5,195 |  |  | $ | 3,980 |  |

[0001193125-15-023697:notes:13]
The Company generally does not indemnify end-users
 of its operating system and application software against legal
 claims that the software infringes third-party intellectual
 property rights. Other agreements entered into by the Company
 sometimes include indemnification provisions under which the
 Company could be subject to costs and/or damages in the event of an
 infringement claim against the Company or an indemnified
 third-party. However, the Company has not been required to make any
 significant payments resulting from such an infringement claim
 asserted against it or an indemnified third-party. In the opinion
 of management, there was not at least a reasonable possibility the
 Company may have incurred a material loss with respect to
 indemnification of end-users of its operating system or application
 software for infringement of third-party intellectual property
 rights. The Company did not record a liability for infringement
 costs related to indemnification as of December 27, 2014 or
 September 27, 2014.

[0001193125-15-023697:notes:14]
The Company has entered into indemnification
 agreements with its directors and executive officers. Under these
 agreements, the Company has agreed to indemnify such individuals to
 the fullest extent permitted by law against liabilities that arise
 by reason of their status as directors or officers and to advance
 expenses incurred by such individuals in connection with related
 legal proceedings. It is not possible to determine the maximum
 potential amount of payments the Company could be required to make
 under these agreements due to the limited history of prior
 indemnification claims and the unique facts and circumstances
 involved in each claim. However, the Company maintains directors
 and officers liability insurance coverage to reduce its exposure to
 such obligations, and payments made under these agreements
 historically have not been material.

[0001193125-15-023697:notes:15]
Concentrations in the Available Sources of Supply of Materials
 and Product

[0001193125-15-023697:notes:16]
Although most components essential to the
 Company’s business are generally available from multiple
 sources, a number of components are currently obtained from single
 or limited sources. In addition, the Company competes for various
 components with other participants in the markets for mobile
 communication and media devices and personal computers. Therefore,
 many components used by the Company, including those that are
 available from multiple sources, are at times subject to
 industry-wide shortage and significant pricing fluctuations that
 could materially adversely affect the Company’s financial
 condition and operating results.

[0001193125-15-023697:notes:17]
The Company uses some custom components that are
 not commonly used by its competitors, and new products introduced
 by the Company often utilize custom components available from only
 one source. When a component or product uses new technologies,
 initial capacity constraints may exist until the suppliers’
 yields have matured or manufacturing capacity has increased. If the
 Company’s supply of components for a new or existing product
 were delayed or constrained, or if an outsourcing partner delayed
 shipments of completed products to the Company, the Company’s
 financial condition and operating results could be materially
 adversely affected. The Company’s business and financial
 performance could also be materially adversely affected depending
 on the time required to obtain sufficient quantities from the
 original source, or to identify and obtain sufficient quantities
 from an alternative source. Continued availability of these
 components at acceptable prices, or at all, may be affected if
 those suppliers concentrated on the production of common components
 instead of components customized to meet the Company’s
 requirements.

[0001193125-15-023697:notes:18]
The Company has entered into agreements for the
 supply of many components; however, there can be no guarantee that
 the Company will be able to extend or renew these agreements on
 similar terms, or at all. Therefore, the Company remains subject to
 significant risks of supply shortages and price increases that
 could materially adversely affect its financial condition and
 operating results.

[0001193125-15-023697:notes:19]
Substantially all of the Company’s hardware
 products are manufactured by outsourcing partners that are located
 primarily in Asia. A significant concentration of this
 manufacturing is currently performed by a small number of
 outsourcing partners, often in single locations. Certain of these
 outsourcing partners are the sole-sourced suppliers of components
 and manufacturers for many of the Company’s products.
 Although the Company works closely with its outsourcing partners on
 manufacturing schedules, the Company’s operating results
 could be adversely affected if its outsourcing partners were unable
 to meet their production commitments. The Company’s purchase
 commitments typically cover its requirements for periods up to 150
 days.

[0001193125-15-023697:notes:20]
Other Off-Balance Sheet Commitments

[0001193125-15-023697:notes:21]
Operating Leases

[0001193125-15-023697:notes:22]
The Company leases various equipment and
 facilities, including retail space, under noncancelable operating
 lease arrangements. The Company does not currently utilize any
 other off-balance sheet financing arrangements. The major facility
 leases are typically for terms not exceeding 10 years and generally
 contain multi-year renewal options. As of December 27, 2014,
 the Company had a total of 447 retail stores. Leases for retail
 space are for terms ranging from five to 20 years, the majority of
 which are for 10 years, and often contain multi-year renewal
 options. As of December 27, 2014, the Company’s total
 future minimum lease payments under noncancelable operating leases
 were $4.8 billion, of which $3.5 billion related to leases for
 retail space.

[0001193125-15-023697:notes:23]
Other Commitments

[0001193125-15-023697:notes:24]
The Company utilizes several outsourcing partners
 to manufacture sub-assemblies for the Company’s products and
 to perform final assembly and testing of finished products. These
 outsourcing partners acquire components and build product based on
 demand information supplied by the Company, which typically covers
 periods up to 150 days. The Company also obtains individual
 components for its products from a wide variety of individual
 suppliers. Consistent with industry practice, the Company acquires
 components through a combination of purchase orders, supplier
 contracts and open orders based on projected demand information.
 Where appropriate, the purchases are applied
 to inventory component prepayments that
 are outstanding with the respective supplier. As of
 December 27, 2014, the Company had outstanding off-balance
 sheet third-party manufacturing commitments and component purchase
 commitments of $21.6 billion.

[0001193125-15-023697:notes:25]
In addition to the commitments mentioned above, the
 Company had other off-balance sheet obligations of $3.9 billion as
 of December 27, 2014, which were comprised of commitments to
 acquire capital assets, including product tooling and manufacturing
 process equipment, and commitments related to advertising, research
 and development (“R&D”), Internet and
 telecommunications services, energy and other obligations.

[0001193125-15-023697:notes:26]
Contingencies

[0001193125-15-023697:notes:27]
The Company is subject to various legal proceedings
 and claims that have arisen in the ordinary course of business and
 that have not been fully adjudicated, certain of which are
 discussed in Part II, Item 1 of this Form 10-Q under the
 heading “Legal Proceedings” and in Part II,
 Item 1A of this Form 10-Q under the heading “Risk
 Factors.” In the opinion of management, there was not at
 least a reasonable possibility the Company may have incurred a
 material loss, or a material loss in excess of a recorded accrual,
 with respect to loss contingencies. However, the outcome of
 litigation is inherently uncertain. Therefore, although management
 considers the likelihood of such an outcome to be remote, if one or
 more of these legal matters were resolved against the Company in a
 reporting period for amounts in excess of management’s
 expectations, the Company’s consolidated financial statements
 for that reporting period could be materially adversely
 affected.

[0001193125-15-023697:notes:28]
Apple Inc. v. Samsung Electronics Co., Ltd, et al.

[0001193125-15-023697:notes:29]
On August 24, 2012, a jury returned a verdict
 awarding the Company $1.05 billion in its lawsuit against Samsung
 Electronics Co., Ltd and affiliated parties in the United States
 District Court, Northern District of California, San Jose Division.
 On March 6, 2014, the District Court entered final judgment in
 favor of the Company in the amount of approximately $930
 million. Because the award is now subject to appeal, the
 Company has not recognized the award in its results of
 operations.


## us-gaap:DebtDisclosureTextBlock

[0001193125-15-023697:notes:30]
Note 6 – Debt

[0001193125-15-023697:notes:31]
Commercial Paper

[0001193125-15-023697:notes:32]
In April 2014, the Board of Directors authorized
 the Company to issue unsecured short-term promissory notes
 (“Commercial Paper”) pursuant to a commercial paper
 program. The Company intends to use net proceeds from the
 commercial paper program for general corporate purposes, including
 dividends and share repurchases. As of December 27, 2014 and
 September 27, 2014, the Company had $3.9 billion and $6.3
 billion of Commercial Paper outstanding, respectively, with a
 weighted-average interest rate of 0.11% and 0.12%, respectively,
 and maturities generally less than nine months.

[0001193125-15-023697:notes:33]
The following table provides a summary of cash
 flows associated with the issuance and maturities of Commercial
 Paper for the three months ended December 27, 2014 (in
 millions):

[0001193125-15-023697:notes:34]
| Maturities less than 90 days: |  |  |  |  |
| Proceeds from (repayments of) commercial paper, net |  | $ | 62 |  |
| Maturities greater than 90 days: |  |  |  |  |
| Proceeds from commercial paper |  |  | 197 |  |
| Repayments of commercial paper |  |  | (2,668 | ) |
| Maturities greater than 90 days, net |  |  | (2,471 | ) |
| Total repayments of commercial paper, net |  | $ | (2,409 | ) |

[0001193125-15-023697:notes:35]
Long-Term Debt

[0001193125-15-023697:notes:36]
As of December 27, 2014, the Company has
 issued floating- and fixed-rate notes with varying maturities for
 an aggregate principal amount of $32.4 billion (collectively the
 “Notes”). The Notes are senior unsecured obligations,
 and interest is payable in arrears, quarterly for the domestic
 floating-rate notes, semi-annually for the domestic fixed-rate
 notes and annually for the foreign fixed-rate notes.

[0001193125-15-023697:notes:37]
The following table provides a summary of the
 Company’s long-term debt as of December 27, 2014 and
 September 27, 2014:

[0001193125-15-023697:notes:38]
|  |  | December 27, 2014 |  |  | September 27, 2014 |  |
|  |  | Amount (in millions) |  |  | Effective Interest Rate |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |
| Floating-rate notes due 2016 (1) |  | $ | 1,000 |  |  |  | 0.51% |  |  | $ | 1,000 |  |  |  | 0.51% |  |
| Floating-rate notes due 2017 (2) |  |  | 1,000 |  |  |  | 0.30% |  |  |  | 1,000 |  |  |  | 0.31% |  |
| Floating-rate notes due 2018 (1) |  |  | 2,000 |  |  |  | 1.10% |  |  |  | 2,000 |  |  |  | 1.10% |  |
| Floating-rate notes due 2019 (2) |  |  | 1,000 |  |  |  | 0.53% |  |  |  | 1,000 |  |  |  | 0.54% |  |
| Fixed-rate 0.45% notes due 2016 (1) |  |  | 1,500 |  |  |  | 0.51% |  |  |  | 1,500 |  |  |  | 0.51% |  |
| Fixed-rate 1.05% notes due 2017 (2) |  |  | 1,500 |  |  |  | 0.30% |  |  |  | 1,500 |  |  |  | 0.30% |  |
| Fixed-rate 1.00% notes due 2018 (1) |  |  | 4,000 |  |  |  | 1.08% |  |  |  | 4,000 |  |  |  | 1.08% |  |
| Fixed-rate 2.10% notes due 2019 (2) |  |  | 2,000 |  |  |  | 0.53% |  |  |  | 2,000 |  |  |  | 0.53% |  |
| Fixed-rate 2.85% notes due 2021 (2) |  |  | 3,000 |  |  |  | 0.78% |  |  |  | 3,000 |  |  |  | 0.79% |  |
| Fixed-rate 1.00% Euro-denominated notes due 2022 (3) |  |  | 1,709 |  |  |  | 2.94% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.40% notes due 2023 (1) |  |  | 5,500 |  |  |  | 2.44% |  |  |  | 5,500 |  |  |  | 2.44% |  |
| Fixed-rate 3.45% notes due 2024 (2) |  |  | 2,500 |  |  |  | 0.89% |  |  |  | 2,500 |  |  |  | 0.90% |  |
| Fixed-rate 1.63% Euro-denominated notes due 2026 (3) |  |  | 1,709 |  |  |  | 3.45% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 3.85% notes due 2043 (1) |  |  | 3,000 |  |  |  | 3.91% |  |  |  | 3,000 |  |  |  | 3.91% |  |
| Fixed-rate 4.45% notes due 2044 (2) |  |  | 1,000 |  |  |  | 4.48% |  |  |  | 1,000 |  |  |  | 4.48% |  |
| Total borrowings |  |  | 32,418 |  |  |  |  |  |  |  | 29,000 |  |  |  |  |  |
| Unamortized discount |  |  | (69 | ) |  |  |  |  |  |  | (52 | ) |  |  |  |  |
| Hedge accounting fair value adjustments |  |  | 155 |  |  |  |  |  |  |  | 39 |  |  |  |  |  |
| Total long-term debt |  | $ | 32,504 |  |  |  |  |  |  | $ | 28,987 |  |  |  |  |  |

[0001193125-15-023697:notes:39]
|  | (1) | Tranche relates to the $17.0 billion debt issuance in the third quarter of 2013. |  |

[0001193125-15-023697:notes:40]
|  | (2) | Tranche relates to the $12.0 billion debt issuance in the third quarter of 2014. |  |

[0001193125-15-023697:notes:41]
|  | (3) | Tranche relates to Euro-denominated debt issuance of €2.8 billion in the first quarter of 2015. |  |

[0001193125-15-023697:notes:42]
The Company has entered, and in the future may
 enter, into interest rate swaps to manage interest rate risk on the
 Notes. Such swaps allow the Company to effectively convert
 fixed-rate payments into floating-rate payments or floating-rate
 payments into fixed-rate payments. In addition, the Company has
 entered, and in the future may enter, into currency swaps to manage
 foreign currency risk on the Notes.

[0001193125-15-023697:notes:43]
In the first quarter of 2015, the Company
 issued €2.8 billion of
 Euro-denominated long-term debt. To manage foreign currency risk
 associated with this issuance, the Company entered into currency
 swaps with an aggregate notional amount of $3.5 billion, which
 effectively converted the Euro-denominated notes to U.S.
 dollar-denominated notes.

[0001193125-15-023697:notes:44]
The effective rates for the Notes include the
 interest on the Notes, amortization of the discount and, if
 applicable, adjustments related to hedging. The Company recognized
 $128 million and $84 million of interest expense on its long-term
 debt for the three months ended December 27, 2014 and
 December 28, 2013, respectively.

[0001193125-15-023697:notes:45]
Future principal payments for the Company’s
 Notes as of December 27, 2014 are as follows (in
 millions):

[0001193125-15-023697:notes:46]
| 2015 |  | $ | 0 |  |
| 2016 |  |  | 2,500 |  |
| 2017 |  |  | 2,500 |  |
| 2018 |  |  | 6,000 |  |
| 2019 |  |  | 3,000 |  |
| Thereafter |  |  | 18,418 |  |
| Total future principal payments |  | $ | 32,418 |  |

[0001193125-15-023697:notes:47]
As of December 27, 2014 and September 27,
 2014, the fair value of the Company’s Notes, based on Level 2
 inputs, was $32.4 billion and $28.5 billion, respectively.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001193125-15-023697:notes:48]
Earnings Per Share

[0001193125-15-023697:notes:49]
Basic earnings per share is computed by dividing
 income available to common shareholders by the weighted-average
 number of shares of common stock outstanding during the period.
 Diluted earnings per share is computed by dividing income available
 to common shareholders by the weighted-average number of shares of
 common stock outstanding during the period increased to include the
 number of additional shares of common stock that would have been
 outstanding if the potentially dilutive securities had been issued.
 Potentially dilutive securities include outstanding stock options,
 shares to be purchased under the Company’s employee stock
 purchase plan, unvested restricted stock and unvested restricted
 stock units (“RSUs”). The dilutive effect of
 potentially dilutive securities is reflected in diluted earnings
 per share by application of the treasury stock method. Under the
 treasury stock method, an increase in the fair market value of the
 Company’s common stock can result in a greater dilutive
 effect from potentially dilutive securities.

[0001193125-15-023697:notes:50]
The following table shows the computation of basic
 and diluted earnings per share for the three months ended
 December 27, 2014 and December 28, 2013 (net income in
 millions and shares in thousands):

[0001193125-15-023697:notes:51]
|  |  | Three Months Ended |  |
|  |  | December 27, 2014 |  |  | December 28, 2013 |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 18,024 |  |  | $ | 13,072 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding |  |  | 5,843,082 |  |  |  | 6,272,504 |  |
| Effect of dilutive securities |  |  | 38,721 |  |  |  | 37,657 |  |
| Weighted-average diluted shares |  |  | 5,881,803 |  |  |  | 6,310,161 |  |
| Basic earnings per share |  | $ | 3.08 |  |  | $ | 2.08 |  |
| Diluted earnings per share |  | $ | 3.06 |  |  | $ | 2.07 |  |

[0001193125-15-023697:notes:52]
Potentially dilutive securities whose effect would
 have been antidilutive were not significant for the three months
 ended December 27, 2014 and December 28, 2013. The
 Company excluded these securities from the computation of diluted
 earnings per share.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001193125-15-023697:notes:53]
Note 1 – Summary of Significant Accounting
 Policies

[0001193125-15-023697:notes:54]
Apple Inc. and its wholly-owned subsidiaries
 (collectively “Apple” or the “Company”)
 designs, manufactures and markets mobile communication and media
 devices, personal computers and portable digital music players, and
 sells a variety of related software, services, accessories,
 networking solutions and third-party digital content and
 applications. The Company sells its products worldwide through its
 retail stores, online stores and direct sales force, as well as
 through third-party cellular network carriers, wholesalers,
 retailers and value-added resellers. In addition, the Company sells
 a variety of third-party iPhone, iPad, Mac and iPod compatible
 products, including application software, and various accessories
 through its online and retail stores. The Company sells to
 consumers, small and mid-sized businesses and education, enterprise
 and government customers.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-15-023697:notes:55]
Note 4 – Goodwill and Other Intangible Assets

[0001193125-15-023697:notes:56]
The Company’s acquired intangible assets
 with definite useful lives primarily consist of patents and
 licenses and are amortized over periods typically from three to
 seven years. The following table summarizes the components of gross
 and net intangible asset balances as of December 27, 2014 and
 September 27, 2014 (in millions):

[0001193125-15-023697:notes:57]
|  |  | December 27, 2014 |  |  | September 27, 2014 |  |
|  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Carrying Amount |  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Carrying Amount |  |
| Definite-lived and amortizable acquired intangible assets |  | $ | 7,641 |  |  | $ | (3,371 | ) |  | $ | 4,270 |  |  | $ | 7,127 |  |  | $ | (3,085 | ) |  | $ | 4,042 |  |
| Indefinite-lived and non-amortizable acquired intangible assets |  |  | 100 |  |  |  | 0 |  |  |  | 100 |  |  |  | 100 |  |  |  | 0 |  |  |  | 100 |  |
| Total acquired intangible assets |  | $ | 7,741 |  |  | $ | (3,371 | ) |  | $ | 4,370 |  |  | $ | 7,227 |  |  | $ | (3,085 | ) |  | $ | 4,142 |  |


## us-gaap:ScheduleOfDerivativeInstrumentsInStatementOfFinancialPositionFairValueTextBlock

[0001193125-15-023697:notes:58]
The following tables show the Company’s
 derivative instruments at gross fair value as of December 27,
 2014 and September 27, 2014 (in millions):

[0001193125-15-023697:notes:59]
|  |  | December 27, 2014 |  |
|  |  | Fair Value of Derivatives Designated as Hedge Instruments |  |  | Fair Value of Derivatives Not Designated as Hedge Instruments |  |  | Total Fair Value |  |
| Derivative assets (1): |  |  |  |  |
| Foreign exchange contracts |  | $ | 3,561 |  |  | $ | 501 |  |  | $ | 4,062 |  |
| Interest rate contracts |  | $ | 201 |  |  | $ | 0 |  |  | $ | 201 |  |
| Derivative liabilities (2): |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 51 |  |  | $ | 119 |  |  | $ | 170 |  |
| Interest rate contracts |  | $ | 87 |  |  | $ | 0 |  |  | $ | 87 |  |
|  |  | September 27, 2014 |  |
|  |  | Fair Value of Derivatives Designated as Hedge Instruments |  |  | Fair Value of Derivatives Not Designated as Hedge Instruments |  |  | Total Fair Value |  |
| Derivative assets (1): |  |  |  |  |
| Foreign exchange contracts |  | $ | 1,332 |  |  | $ | 222 |  |  | $ | 1,554 |  |
| Interest rate contracts |  | $ | 81 |  |  | $ | 0 |  |  | $ | 81 |  |
| Derivative liabilities (2): |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 41 |  |  | $ | 40 |  |  | $ | 81 |  |

[0001193125-15-023697:notes:60]
|  | (1) | The fair value of derivative assets is measured using Level 2 fair value inputs and is recorded as other current assets in the Condensed Consolidated Balance Sheets. |  |

[0001193125-15-023697:notes:61]
|  | (2) | The fair value of derivative liabilities is measured using Level 2 fair value inputs and is recorded as accrued expenses in the Condensed Consolidated Balance Sheets. |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001193125-15-023697:notes:62]
[same as prior period, unchanged from 0001193125-14-277160:notes:64]

[0001193125-15-023697:notes:63]
|  |  | December 27, 2014 |  |  | September 27, 2014 |  |
| Components |  | $ | 228 |  |  | $ | 471 |  |
| Finished goods |  |  | 2,055 |  |  |  | 1,640 |  |
| Total inventories |  | $ | 2,283 |  |  | $ | 2,111 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-15-023697:notes:64]
Note 11 – Segment Information and Geographic Data

[0001193125-15-023697:notes:65]
The Company reports segment information based on
 the “management” approach. The management approach
 designates the internal reporting used by management for making
 decisions and assessing performance as the source of the
 Company’s reportable operating segments.

[0001193125-15-023697:notes:66]
The Company manages its business primarily on a
 geographic basis. As the Company continues to expand its business,
 management believes collaboration across its online, retail and
 indirect channels is integral to better serving its customers and
 optimizing its financial results. In the first quarter of 2015,
 management began reporting business performance and making
 decisions primarily on a geographic basis, including the results of
 its retail stores in each respective geographic segment.
 Accordingly, to align with the way the business is currently
 managed, the Company’s reportable operating segments now
 consist of the Americas, Europe, Greater China, Japan and Rest of
 Asia Pacific. Retail is no longer reported as a separate reportable
 operating segment. The Americas segment includes both North and
 South America. The Europe segment includes European countries, as
 well as India, the Middle East and Africa. The Greater China
 segment includes China, Hong Kong and Taiwan. The Rest of Asia
 Pacific segment includes Australia and Asian countries, other than
 those countries included in the Company’s other operating
 segments. Each operating segment provides similar hardware and
 software products and similar services. The accounting policies of
 the various segments are the same as those described in Note 1,
 “Summary of Significant Accounting Policies” of the
 Notes to Consolidated Financial Statements in Part II, Item 8
 of the 2014 Form 10-K.

[0001193125-15-023697:notes:67]
The Company evaluates the performance of its
 operating segments based on net sales and operating income. Net
 sales for geographic segments are generally based on the location
 of customers and sales through the Company’s retail stores
 located in those geographic locations. Operating income for each
 segment includes net sales to third parties, related cost of sales
 and operating expenses directly attributable to the segment. In the
 first quarter of 2015, the Company also began allocating certain
 costs to its operating segments that were previously included in
 other corporate expenses, including certain share-based
 compensation costs. Advertising expenses are generally included in
 the geographic segment in which the expenditures are incurred.
 Operating income for each segment excludes other income and expense
 and certain expenses managed outside the operating segments. Costs
 excluded from segment operating income include various corporate
 expenses such as R&D, corporate marketing expenses, certain
 share-based compensation expense, income taxes, various
 nonrecurring charges and other separately managed general and
 administrative costs. The Company does not include intercompany
 transfers between segments for management reporting purposes.

[0001193125-15-023697:notes:68]
The following table shows information by operating
 segment for the three months ended December 27, 2014 and
 December 28, 2013 (in millions):

[0001193125-15-023697:notes:69]
|  |  | Three Months Ended |  |
|  |  | December 27, 2014 |  |  | December 28, 2013 |  |
| Americas: |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 30,566 |  |  | $ | 24,789 |  |
| Operating income |  | $ | 10,701 |  |  | $ | 8,069 |  |
| Europe: |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 17,214 |  |  | $ | 14,335 |  |
| Operating income |  | $ | 5,882 |  |  | $ | 4,623 |  |
| Greater China: |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 16,144 |  |  | $ | 9,496 |  |
| Operating income |  | $ | 6,366 |  |  | $ | 3,247 |  |
| Japan: |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 5,448 |  |  | $ | 5,045 |  |
| Operating income |  | $ | 2,488 |  |  | $ | 2,330 |  |
| Rest of Asia Pacific: |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 5,227 |  |  | $ | 3,929 |  |
| Operating income |  | $ | 1,849 |  |  | $ | 1,368 |  |

[0001193125-15-023697:notes:70]
A reconciliation of the Company’s segment
 operating income to the Condensed Consolidated Statements of
 Operations for the three months ended December 27, 2014 and
 December 28, 2013 is as follows (in millions):

[0001193125-15-023697:notes:71]
|  |  | Three Months Ended |  |
|  |  | December 27, 2014 |  |  | December 28, 2013 |  |
| Segment operating income |  | $ | 27,286 |  |  | $ | 19,637 |  |
| Research and development expense |  |  | (1,895 | ) |  |  | (1,330 | ) |
| Other corporate expenses, net |  |  | (1,145 | ) |  |  | (844 | ) |
| Total operating income |  | $ | 24,246 |  |  | $ | 17,463 |  |


## us-gaap:InterestAndOtherIncomeTableTextBlock

[0001193125-15-023697:notes:72]
Other Income/(Expense), Net

[0001193125-15-023697:notes:73]
The following table shows the detail of other
 income/(expense), net for the three months ended December 27,
 2014 and December 28, 2013 (in millions):

[0001193125-15-023697:notes:74]
|  |  | Three Months Ended |  |
|  |  | December 27, 2014 |  |  | December 28, 2013 |  |
| Interest and dividend income |  | $ | 654 |  |  | $ | 427 |  |
| Interest expense |  |  | (131 | ) |  |  | (84 | ) |
| Other expense, net |  |  | (353 | ) |  |  | (97 | ) |
| Total other income/(expense), net |  | $ | 170 |  |  | $ | 246 |  |


## us-gaap:OtherNoncurrentLiabilitiesTableTextBlock

[0001193125-15-023697:notes:75]
Other Non-Current Liabilities

[0001193125-15-023697:notes:76]
|  |  | December 27, 2014 |  |  | September 27, 2014 |  |
| Deferred tax liabilities |  | $ | 23,371 |  |  | $ | 20,259 |  |
| Other non-current liabilities |  |  | 5,600 |  |  |  | 4,567 |  |
| Total other non-current liabilities |  | $ | 28,971 |  |  | $ | 24,826 |  |


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0001193125-15-023697:notes:77]
The following table shows a summary of the
 share-based compensation expense included in the Condensed
 Consolidated Statements of Operations for the three months ended
 December 27, 2014 and December 28, 2013 (in
 millions):

[0001193125-15-023697:notes:78]
|  |  | Three Months Ended |  |
|  |  | December 27, 2014 |  |  | December 28, 2013 |  |
| Cost of sales |  | $ | 140 |  |  | $ | 109 |  |
| Research and development |  |  | 374 |  |  |  | 289 |  |
| Selling, general and administrative |  |  | 374 |  |  |  | 283 |  |
| Total share-based compensation expense |  | $ | 888 |  |  | $ | 681 |  |


## us-gaap:DerivativesPolicyTextBlock

[0001193125-15-023697:notes:79]
Derivative Financial Instruments

[0001193125-15-023697:notes:80]
The Company uses derivatives to partially offset
 its business exposure to foreign currency and interest rate risk on
 expected future cash flows, on net investments in certain foreign
 subsidiaries and on certain existing assets and liabilities.
 However, the Company may choose not to hedge certain exposures for
 a variety of reasons including, but not limited to, accounting
 considerations and the prohibitive economic cost of hedging
 particular exposures. There can be no assurance the hedges will
 offset more than a portion of the financial impact resulting from
 movements in foreign currency exchange or interest rates.

[0001193125-15-023697:notes:81]
To help protect gross margins from fluctuations in
 foreign currency exchange rates, certain of the Company’s
 subsidiaries whose functional currency is the U.S. dollar may hedge
 a portion of forecasted foreign currency revenue, and subsidiaries
 whose functional currency is not the U.S. dollar and who sell in
 local currencies may hedge a portion of forecasted inventory
 purchases not denominated in the subsidiaries’ functional
 currencies. The Company may enter into forward contracts, option
 contracts or other instruments to manage this risk and may
 designate these instruments as cash flow hedges. The Company
 typically hedges portions of its forecasted foreign currency
 exposure associated with revenue and inventory purchases, typically
 for up to 12 months.

[0001193125-15-023697:notes:82]
To help protect the net investment in a foreign
 operation from adverse changes in foreign currency exchange rates,
 the Company may enter into foreign currency forward and option
 contracts to offset the changes in the carrying amounts of these
 investments due to fluctuations in foreign currency exchange rates.
 The Company designates these instruments as net investment
 hedges.

[0001193125-15-023697:notes:83]
The Company may also enter into non-designated
 foreign currency contracts to partially offset the foreign currency
 exchange gains and losses generated by the re-measurement of
 certain assets and liabilities denominated in non-functional
 currencies.

[0001193125-15-023697:notes:84]
The Company may enter into interest rate swaps,
 options, or other instruments to manage interest rate risk. These
 instruments may offset a portion of changes in income or expense,
 or changes in fair value of the Company’s long-term debt or
 investments. The Company designates these instruments as either
 cash flow or fair value hedges. The Company’s hedged interest
 rate transactions as of December 27, 2014 are expected to be
 recognized within twelve years.

[0001193125-15-023697:notes:85]
Cash Flow Hedges

[0001193125-15-023697:notes:86]
The effective portions of cash flow hedges are
 recorded in accumulated other comprehensive income
 (“AOCI”) until the hedged item is recognized in
 earnings. Deferred gains and losses associated with cash flow
 hedges of foreign currency revenue are recognized as a component of
 net sales in the same period as the related revenue is recognized,
 and deferred gains and losses related to cash flow hedges of
 inventory purchases are recognized as a component of cost of sales
 in the same period as the related costs are recognized. Deferred
 gains and losses associated with cash flow hedges of interest
 income or expense are recognized in other income/(expense), net in
 the same period as the related income or expense is recognized.

[0001193125-15-023697:notes:87]
The ineffective portions and amounts excluded from
 the effectiveness testing of cash flow hedges are recognized in
 other income/(expense), net. These amounts were not significant
 during the three months ended December 27, 2014 and
 December 28, 2013.

[0001193125-15-023697:notes:88]
Derivative instruments designated as cash flow
 hedges must be de-designated as hedges when it is probable the
 forecasted hedged transaction will not occur in the initially
 identified time period or within a subsequent two-month time
 period. Deferred gains and losses in AOCI associated with such
 derivative instruments are reclassified immediately into other
 income/(expense), net. Any subsequent changes in fair value of such
 derivative instruments are reflected in other income and expense
 unless they are re-designated as hedges of other transactions. The
 Company did not recognize any significant net gains or losses
 related to the loss of hedge designation on discontinued cash flow
 hedges during the three months ended December 27, 2014 and
 December 28, 2013.

[0001193125-15-023697:notes:89]
Net Investment Hedges

[0001193125-15-023697:notes:90]
The effective portions of net investment hedges are
 recorded in other comprehensive income (“OCI”) as a
 part of the cumulative translation adjustment. The ineffective
 portions and amounts excluded from the effectiveness testing of net
 investment hedges are recognized in other income/(expense), net.
 These amounts were not significant during the three months ended
 December 27, 2014 and December 28, 2013.

[0001193125-15-023697:notes:91]
Fair Value Hedges

[0001193125-15-023697:notes:92]
Gains and losses related to changes in fair value
 hedges are recognized in earnings along with a corresponding loss
 or gain related to the change in value of the underlying hedged
 item. The ineffective portions and amounts excluded from the
 effectiveness testing of fair value hedges recognized were not
 significant during the three months ended December 27, 2014
 and December 28, 2013.

[0001193125-15-023697:notes:93]
Non-Designated Derivatives

[0001193125-15-023697:notes:94]
Derivatives that are not designated as hedging
 instruments are adjusted to fair value through earnings in the
 financial statement line item to which the derivative relates. The
 net gains and losses recognized for foreign currency forward and
 option contracts not designated as hedging instruments was not
 significant during the three months ended December 27, 2014
 and December 28, 2013


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001193125-15-023697:notes:95]
Note 2 – Financial Instruments

[0001193125-15-023697:notes:96]
Cash, Cash Equivalents and Marketable Securities

[0001193125-15-023697:notes:97]
The Company may sell certain of its marketable
 securities prior to their stated maturities for strategic reasons
 including, but not limited to, anticipation of credit deterioration
 and duration management. The net realized gains or losses
 recognized by the Company related to such sales were not
 significant during the three months ended December 27, 2014
 and December 28, 2013. The maturities of the Company’s
 long-term marketable securities generally range from one to five
 years.

[0001193125-15-023697:notes:98]
As of December 27, 2014 and September 27,
 2014, gross unrealized losses related to individual securities that
 had been in a continuous loss position for 12 months or longer were
 not significant.

[0001193125-15-023697:notes:99]
As of December 27, 2014, the Company considers
 the declines in market value of its marketable securities
 investment portfolio to be temporary in nature and does not
 consider any of its investments other-than-temporarily impaired.
 The Company typically invests in highly-rated securities, and its
 investment policy generally limits the amount of credit exposure to
 any one issuer. The policy generally requires investments to be
 investment grade, with the primary objective of minimizing the
 potential risk of principal loss. Fair values were determined for
 each individual security in the investment portfolio. When
 evaluating an investment for other-than-temporary impairment the
 Company reviews factors such as the length of time and extent to
 which fair value has been below its cost basis, the financial
 condition of the issuer and any changes thereto, changes in market
 interest rates and the Company’s intent to sell, or whether
 it is more likely than not it will be required to sell the
 investment before recovery of the investment’s cost basis.
 During the three months ended December 27, 2014 and
 December 28, 2013, the Company did not recognize any
 significant impairment charges.

[0001193125-15-023697:notes:100]
Derivatives that are not designated as hedging
 instruments are adjusted to fair value through earnings in the
 financial statement line item to which the derivative relates. The
 net gains and losses recognized for foreign currency forward and
 option contracts not designated as hedging instruments was not
 significant during the three months ended December 27, 2014
 and December 28, 2013.

[0001193125-15-023697:notes:101]
The Company records all derivatives in the
 Condensed Consolidated Balance Sheets at fair value. The
 Company’s accounting treatment for these derivative
 instruments is based on its hedge designation. The following tables
 show the Company’s derivative instruments at gross fair value
 as of December 27, 2014 and September 27, 2014 (in
 millions):

[0001193125-15-023697:notes:102]
The following tables show the pre-tax effect of the
 Company’s derivative instruments designated as cash flow, net
 investment and fair value hedges on OCI and the Condensed
 Consolidated Statements of Operations for the three months ended
 December 27, 2014 and December 28, 2013 (in
 millions):

[0001193125-15-023697:notes:103]
|  |  | Gains/(Losses) Recognized in OCI – Effective Portion |  |  | Gains/(Losses) Reclassified from AOCI into Net Income – Effective Portion |  |
|  |  | Three Months Ended |  |  | Three Months Ended |  |
|  |  | December 27, 2014 |  |  | December 28, 2013 |  |  | December 27, 2014 |  |  | December 28, 2013 |  |
| Cash flow hedges: |  |  |  |  |
| Foreign exchange contracts |  | $ | 2,585 |  |  | $ | 264 |  |  | $ | 762 |  |  | $ | (74 | ) |
| Interest rate contracts |  |  | (88 | ) |  |  | 21 |  |  |  | (99 | ) |  |  | (4 | ) |
| Total |  | $ | 2,497 |  |  | $ | 285 |  |  | $ | 663 |  |  | $ | (78 | ) |
| Net investment hedges: |  |  |  |  |
| Foreign exchange contracts |  | $ | 118 |  |  | $ | 24 |  |  | $ | 0 |  |  | $ | 0 |  |
|  |  | Gains/(Losses) on Derivative Instruments |  |  | Gains/(Losses) Related to Hedged Items |  |
|  |  | Three Months Ended |  |  | Three Months Ended |  |
|  |  | December 27, 2014 |  |  | December 28, 2013 |  |  | December 27, 2014 |  |  | December 28, 2013 |  |
| Fair value hedges: |  |  |  |  |
| Interest rate contracts |  | $ | 117 |  |  | $ | 0 |  |  | $ | (117 | ) |  | $ | 0 |  |

[0001193125-15-023697:notes:104]
The following table shows the notional amounts of
 the Company’s outstanding derivative instruments and credit
 risk amounts associated with outstanding or unsettled derivative
 instruments as of December 27, 2014 and September 27,
 2014 (in millions):

[0001193125-15-023697:notes:105]
|  |  | December 27, 2014 |  |  | September 27, 2014 |  |
|  |  | Notional Amount |  |  | Credit Risk Amounts |  |  | Notional Amount |  |  | Credit Risk Amounts |  |
| Instruments designated as accounting hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 55,761 |  |  | $ | 3,561 |  |  | $ | 42,945 |  |  | $ | 1,333 |  |
| Interest rate contracts |  | $ | 15,513 |  |  | $ | 201 |  |  | $ | 12,000 |  |  | $ | 89 |  |
| Instruments not designated as accounting hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 39,872 |  |  | $ | 501 |  |  | $ | 38,510 |  |  | $ | 222 |  |

[0001193125-15-023697:notes:106]
The notional amounts for outstanding derivative
 instruments provide one measure of the transaction volume
 outstanding and do not represent the amount of the Company’s
 exposure to credit or market loss. The credit risk amounts
 represent the Company’s gross exposure to potential
 accounting loss on derivative instruments that are outstanding or
 unsettled if all counterparties failed to perform according to the
 terms of the contract, based on then-current currency or interest
 rates at each respective date. The Company’s exposure to
 credit loss and market risk will vary over time as currency and
 interest rates change. Although the table above reflects the
 notional and credit risk amounts of the Company’s derivative
 instruments, it does not reflect the gains or losses associated
 with the exposures and transactions that the instruments are
 intended to hedge. The amounts ultimately realized upon settlement
 of these financial instruments, together with the gains and losses
 on the underlying exposures, will depend on actual market
 conditions during the remaining life of the instruments.

[0001193125-15-023697:notes:107]
The Company generally enters into master netting
 arrangements, which are designed to reduce credit risk by
 permitting net settlement of transactions with the same
 counterparty. To further limit credit risk, the Company generally
 enters into collateral security arrangements that provide for
 collateral to be received or posted when the net fair value of
 certain financial instruments fluctuates from contractually
 established thresholds. The Company presents its derivative assets
 and derivative liabilities at their gross fair values in its
 Condensed Consolidated Balance Sheets. As of December 27, 2014
 and September 27, 2014, the Company received $4.2 billion and
 $2.1 billion, respectively, of cash collateral related to the
 derivative instruments under its collateral security arrangements,
 which were recorded as other current liabilities within accrued
 expenses in the Condensed Consolidated Balance Sheets. The
 Company did not have any derivative instruments with credit-risk
 related contingent features that would require it to post
 additional collateral as of December 27, 2014 and
 September 27, 2014.

[0001193125-15-023697:notes:108]
Under master netting arrangements with the
 respective counterparties to the Company’s derivative
 contracts, the Company is allowed to net settle transactions
 with a single net amount payable by one party to the other. As of
 December 27, 2014 and September 27, 2014, the potential
 effects of these rights of set-off associated with the
 Company’s derivative contracts, including the effects of
 collateral, would be a reduction to both derivative assets and
 derivative liabilities of $4.2 billion and $1.6 billion,
 respectively, resulting in net derivative liabilities
 of $184 million and $549 million, respectively.

[0001193125-15-023697:notes:109]
Accounts Receivable

[0001193125-15-023697:notes:110]
Trade Receivables

[0001193125-15-023697:notes:111]
The Company has considerable trade receivables
 outstanding with its third-party cellular network carriers,
 wholesalers, retailers, value-added resellers, small and mid-sized
 businesses and education, enterprise and government customers that
 are not covered by collateral, third-party financing arrangements
 or credit insurance. As of December 27, 2014, the Company had
 one customer that represented 10% or more of total trade
 receivables, which accounted for 13%. As of September 27,
 2014, the Company had two customers that represented 10% or more of
 total trade receivables, one of which accounted for 16% and the
 other 13%. The Company’s cellular network carriers accounted
 for 63% and 72% of trade receivables as of December 27, 2014
 and September 27, 2014, respectively.

[0001193125-15-023697:notes:112]
Vendor Non-Trade Receivables

[0001193125-15-023697:notes:113]
Additionally, the Company has non-trade receivables
 from certain of its manufacturing vendors resulting from the sale
 of components to these vendors who manufacture sub-assemblies or
 assemble final products for the Company. Vendor non-trade
 receivables from three of the Company’s vendors accounted for
 57%, 14% and 12% of total vendor non-trade receivables as of
 December 27, 2014 and three of the Company’s vendors
 accounted for 51%, 16% and 14% of total vendor non-trade
 receivables as of September 27, 2014.


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001193125-15-023697:notes:114]
Accrued Expenses

[0001193125-15-023697:notes:115]
|  |  | December 27, 2014 |  |  | September 27, 2014 |  |
| Accrued warranty and related costs |  | $ | 5,195 |  |  | $ | 4,159 |  |
| Accrued marketing and selling expenses |  |  | 1,960 |  |  |  | 2,321 |  |
| Accrued taxes |  |  | 1,642 |  |  |  | 1,209 |  |
| Accrued compensation and employee benefits |  |  | 1,316 |  |  |  | 1,209 |  |
| Deferred margin on component sales |  |  | 1,133 |  |  |  | 1,057 |  |
| Other current liabilities |  |  | 11,478 |  |  |  | 8,498 |  |
| Total accrued expenses |  | $ | 22,724 |  |  | $ | 18,453 |  |


## us-gaap:ScheduleOfNonvestedRestrictedStockUnitsActivityTableTextBlock

[0001193125-15-023697:notes:116]
A summary of the Company’s RSU activity and
 related information for the three months ended December 27,
 2014, is as follows:

[0001193125-15-023697:notes:117]
|  |  | Number of RSUs (in thousands) |  |  | Weighted-Average Grant Date Fair Value |  |  | Aggregate Intrinsic Value (in millions) |  |
| Balance at September 27, 2014 |  |  | 103,822 |  |  | $ | 70.98 |  |  |  |  |  |
| RSUs granted |  |  | 36,294 |  |  | $ | 101.41 |  |  |  |  |  |
| RSUs vested |  |  | (16,759 | ) |  | $ | 64.30 |  |  |  |  |  |
| RSUs cancelled |  |  | (1,815 | ) |  | $ | 71.49 |  |  |  |  |  |
| Balance at December 27, 2014 |  |  | 121,542 |  |  | $ | 80.98 |  |  | $ | 13,855 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-15-023697:notes:118]
The following table shows the changes in AOCI by
 component for the three months ended December 27, 2014 (in
 millions):

[0001193125-15-023697:notes:119]
|  |  | Cumulative Foreign Currency Translation |  |  | Unrecognized Gains/Losses on Derivative Instruments |  |  | Unrealized Gains/Losses on Marketable Securities |  |  | Total |  |
| Balance at September 27, 2014 |  | $ | (242 | ) |  | $ | 1,364 |  |  | $ | (40 | ) |  | $ | 1,082 |  |
| Other comprehensive income/(loss) before reclassifications |  |  | (114 | ) |  |  | 2,390 |  |  |  | (707 | ) |  |  | 1,569 |  |
| Amounts reclassified from AOCI |  |  | 0 |  |  |  | (663 | ) |  |  | (22 | ) |  |  | (685 | ) |
| Tax effect |  |  | 48 |  |  |  | (310 | ) |  |  | 259 |  |  |  | (3 | ) |
| Other comprehensive income/(loss) |  |  | (66 | ) |  |  | 1,417 |  |  |  | (470 | ) |  |  | 881 |  |
| Balance at December 27, 2014 |  | $ | (308 | ) |  | $ | 2,781 |  |  | $ | (510 | ) |  | $ | 1,963 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-15-023697:notes:120]
Note 7 – Shareholders’ Equity

[0001193125-15-023697:notes:121]
[same as prior period, unchanged from 0001193125-14-277160:notes:117]

[0001193125-15-023697:notes:122]
The Company declared and paid cash dividends per
 common share during the periods presented as follows:

[0001193125-15-023697:notes:123]
|  |  | Dividends Per Share |  |  | Amount (in millions) |  |
| 2015: |  |  |  |  |  |  |  |  |
| First quarter |  | $ | 0.47 |  |  | $ | 2,750 |  |
| 2014: |  |  |  |  |  |  |  |  |
| Fourth quarter |  | $ | 0.47 |  |  | $ | 2,807 |  |
| Third quarter |  |  | 0.47 |  |  |  | 2,830 |  |
| Second quarter |  |  | 0.44 |  |  |  | 2,655 |  |
| First quarter |  |  | 0.44 |  |  |  | 2,739 |  |
| Total cash dividends declared and paid |  | $ | 1.82 |  |  | $ | 11,031 |  |

[0001193125-15-023697:notes:124]
Future dividends are subject to declaration by the
 Board of Directors.

[0001193125-15-023697:notes:125]
Share Repurchase Program

[0001193125-15-023697:notes:126]
In 2014, the Company’s Board of Directors
 increased the share repurchase authorization to $90 billion of the
 Company’s common stock. As of December 27, 2014, $72.9
 billion of the $90 billion had been utilized. The Company’s
 share repurchase program does not obligate it to acquire any
 specific number of shares. Under the program, shares may be
 repurchased in privately negotiated and/or open market
 transactions, including under plans complying with Rule 10b5-1
 under the Securities Exchange Act of 1934, as amended (the
 “Exchange Act”).

[0001193125-15-023697:notes:127]
The Company has entered, and in the future may
 enter, into accelerated share repurchase arrangements
 (“ASRs”) with financial institutions. In exchange for
 up-front payments, the financial institutions deliver shares of the
 Company’s common stock during the purchase periods of each
 ASR. The total number of shares ultimately delivered, and therefore
 the average repurchase price paid per share, is determined at the
 end of the applicable purchase period of each ASR based on the
 volume weighted-average price of the Company’s common stock
 during that period. The shares received are retired in the periods
 they are delivered, and the up-front payments are accounted for as
 a reduction to shareholders’ equity in the Company’s
 Condensed Consolidated Balance Sheet in the periods the payments
 are made. The Company reflects the ASRs as a repurchase of common
 stock in the period delivered for purposes of calculating earnings
 per share and as forward contracts indexed to its own common stock.
 The ASRs met all of the applicable criteria for equity
 classification, and therefore, were not accounted for as derivative
 instruments.

[0001193125-15-023697:notes:128]
A summary of the Company’s ASR activity and
 related information during the periods presented, is as
 follows:

[0001193125-15-023697:notes:129]
|  |  | Purchase Period End Date |  |  | Number of Shares (in thousands) |  |  | Average Repurchase Price Per Share |  |  | ASR Amount (in millions) |  |
| August 2014 ASR |  |  | (1) |  |  |  | 68,273 (1) |  |  |  | (1) |  |  | $ | 9,000 |  |
| January 2014 ASR |  |  | December 2014 |  |  |  | 134,247 |  |  | $ | 89.39 |  |  | $ | 12,000 |  |
| April 2013 ASR |  |  | March 2014 |  |  |  | 172,548 |  |  | $ | 69.55 |  |  | $ | 12,000 |  |

[0001193125-15-023697:notes:130]
|  | (1) | Includes 8.3 million net shares delivered and retired under the August 2014 ASR in the first quarter of 2015. “Number of Shares” represents those shares delivered in advance of settlement and does not represent the final number of shares to be delivered under the ASRs. The total number of shares ultimately delivered, and therefore the average repurchase price paid per share, will be determined at the end of the applicable purchase period based on the volume weighted-average price of the Company’s common stock during that period. The August 2014 ASR purchase period will end in or before February 2015. |  |

[0001193125-15-023697:notes:131]
Additionally, the Company repurchased shares of its
 common stock in the open market, which were retired upon
 repurchase, during the periods presented as follows:

[0001193125-15-023697:notes:132]
|  |  | Number of Shares (in thousands) |  |  | Average Repurchase Price Per Share |  |  | Amount (in millions) |  |
| 2015: |  |  |  |  |  |  |  |  |  |  |  |  |
| First quarter |  |  | 45,704 |  |  | $ | 109.40 |  |  | $ | 5,000 |  |
| 2014: |  |  |  |  |  |  |  |  |  |  |  |  |
| Fourth quarter |  |  | 81,255 |  |  | $ | 98.46 |  |  | $ | 8,000 |  |
| Third quarter |  |  | 58,661 |  |  | $ | 85.23 |  |  |  | 5,000 |  |
| Second quarter |  |  | 79,749 |  |  | $ | 75.24 |  |  |  | 6,000 |  |
| First quarter |  |  | 66,847 |  |  | $ | 74.79 |  |  |  | 5,000 |  |
| Total open market common stock repurchases |  |  | 286,512 |  |  |  |  |  |  | $ | 24,000 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-15-023697:notes:133]
Note 5 – Income Taxes

[0001193125-15-023697:notes:134]
As of December 27, 2014, the Company recorded
 gross unrecognized tax benefits of $4.4 billion, of which $1.6
 billion, if recognized, would affect the Company’s effective
 tax rate. As of September 27, 2014, the total amount of gross
 unrecognized tax benefits was $4.0 billion, of which $1.4
 billion, if recognized, would have affected the Company’s
 effective tax rate. The Company’s total gross unrecognized
 tax benefits are classified as other non-current liabilities in the
 Condensed Consolidated Balance Sheets. The Company had $821 million
 and $630 million of gross interest and penalties accrued as of
 December 27, 2014 and September 27, 2014, respectively,
 which are classified as other non-current liabilities in the
 Condensed Consolidated Balance Sheets.

[0001193125-15-023697:notes:135]
Management believes that an adequate provision has
 been made for any adjustments that may result from tax
 examinations. However, the outcome of tax audits cannot be
 predicted with certainty. If any issues addressed in the
 Company’s tax audits are resolved in a manner not consistent
 with management’s expectations, the Company could be required
 to adjust its provision for income taxes in the period such
 resolution occurs. Although timing of the resolution and/or closure
 of audits is not certain, the Company does not believe it is
 reasonably possible that its unrecognized tax benefits would
 materially change in the next 12 months.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001193125-15-023697:notes:136]
Note 3 – Condensed Consolidated Financial Statement
 Details

[0001193125-15-023697:notes:137]
The following tables show the Company’s
 condensed consolidated financial statement details as of
 December 27, 2014 and September 27, 2014 (in
 millions):

[0001193125-15-023697:notes:138]
Property, Plant and Equipment, Net

[0001193125-15-023697:notes:139]
|  |  | December 27, 2014 |  |  | September 27, 2014 |  |
| Land and buildings |  | $ | 5,152 |  |  | $ | 4,863 |  |
| Machinery, equipment and internal-use software |  |  | 31,010 |  |  |  | 29,639 |  |
| Leasehold improvements |  |  | 4,585 |  |  |  | 4,513 |  |
| Gross property, plant and equipment |  |  | 40,747 |  |  |  | 39,015 |  |
| Accumulated depreciation and amortization |  |  | (20,355 | ) |  |  | (18,391 | ) |
| Total property, plant and equipment, net |  | $ | 20,392 |  |  | $ | 20,624 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-15-023697:notes:140]
Note 8 – Comprehensive Income

[0001193125-15-023697:notes:141]
Comprehensive income consists of two components,
 net income and OCI. OCI refers to revenue, expenses, and gains and
 losses that under GAAP are recorded as an element of
 shareholders’ equity but are excluded from net income. The
 Company’s OCI consists of foreign currency translation
 adjustments from those subsidiaries not using the U.S. dollar as
 their functional currency, net deferred gains and losses on certain
 derivative instruments accounted for as cash flow hedges and
 unrealized gains and losses on marketable securities classified as
 available-for-sale.

[0001193125-15-023697:notes:142]
The following table shows the gross amounts
 reclassified from AOCI into the Condensed Consolidated Statements
 of Operations and the associated financial statement line item, for
 the three months ended December 27, 2014 and December 28,
 2013 (in millions):

[0001193125-15-023697:notes:143]
| Comprehensive Income Components |  | Financial Statement Line Item |  | December 27, 2014 |  |  | December 28, 2013 |  |
| Unrecognized gains/losses on derivative instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Revenue |  | $ | (449 | ) |  | $ | 184 |  |
|  |  | Cost of sales |  |  | (313 | ) |  |  | (110 | ) |
|  |  | Other income/expense, net |  |  | 0 |  |  |  | 10 |  |
| Interest rate contracts |  | Other income/expense, net |  |  | 99 |  |  |  | 4 |  |
|  |  |  |  |  | (663 | ) |  |  | 88 |  |
| Unrealized gains/losses on marketable securities |  | Other income/expense, net |  |  | (22 | ) |  |  | (17 | ) |
| Total amounts reclassified from AOCI |  |  |  | $ | (685 | ) |  | $ | 71 |  |


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001193125-15-023697:notes:144]
Note 9 – Benefit Plans

[0001193125-15-023697:notes:145]
Stock Plans

[0001193125-15-023697:notes:146]
The Company had 436.9 million shares reserved
 for future issuance under its stock plans as of December 27,
 2014. RSUs granted generally vest over four years, based on
 continued employment, and are settled upon vesting in shares of the
 Company’s common stock on a one-for-one basis. Each share
 issued with respect to RSUs granted under the Company’s stock
 plans reduces the number of shares available for grant under the
 plan by two shares. RSUs cancelled and shares withheld to satisfy
 tax withholding obligations increase the number of shares available
 for grant under the plans utilizing a factor of two times the
 number of RSUs cancelled or shares withheld. Stock options count
 against the number of shares available for grant on a one-for-one
 basis.

[0001193125-15-023697:notes:147]
Rule 10b5-1 Trading Plans

[0001193125-15-023697:notes:148]
During the three months ended December 27,
 2014, Section 16 officers Timothy D. Cook, Angela Ahrendts,
 Luca Maestri and Daniel Riccio had equity trading plans in place in
 accordance with Rule 10b5-1(c)(1) under the Exchange Act. An equity
 trading plan is a written document that pre-establishes the
 amounts, prices and dates (or formula for determining the amounts,
 prices and dates) of future purchases or sales of the
 Company’s stock, including shares acquired pursuant to the
 Company’s employee and director equity plans.

[0001193125-15-023697:notes:149]
Restricted Stock Units

[0001193125-15-023697:notes:150]
RSUs that vested during the three months ended
 December 27, 2014 and December 28, 2013 had a fair value
 of $1.7 billion and $1.1 billion, respectively, as of the
 vesting date.

[0001193125-15-023697:notes:151]
Stock Options

[0001193125-15-023697:notes:152]
The Company had 3.5 million stock options
 outstanding as of December 27, 2014, with a weighted average
 exercise price per share of $19.61 and weighted average remaining
 contractual term of 2.2 years, substantially all of which are
 exercisable. The aggregate intrinsic value of the stock options
 outstanding as of December 27, 2014 was $330 million, which
 represents the value of the Company’s closing stock price on
 the last trading day of the period in excess of the
 weighted-average exercise price multiplied by the number of options
 outstanding.

[0001193125-15-023697:notes:153]
The total intrinsic value of options at the time of
 exercise was $248 million and $559 million for the three months
 ended December 27, 2014 and December 28, 2013,
 respectively.

[0001193125-15-023697:notes:154]
Share-Based Compensation

[0001193125-15-023697:notes:155]
The income tax benefit related to share-based
 compensation expense was $351 million and $265 million for the
 three months ended December 27, 2014 and December 28,
 2013, respectively. As of December 27, 2014, the total
 unrecognized compensation cost related to outstanding stock options
 and RSUs expected to vest was $8.8 billion, which the Company
 expects to recognize over a weighted-average period of 3.1
 years.
