# AAPL MD&A — 0001193125-15-023697


## mdna

[0001193125-15-023697:mdna:1]
| Item 2. | Management’s Discussion and Analysis of Financial Condition and Results of Operations |

[0001193125-15-023697:mdna:2]
[same as prior period, unchanged from 0001193125-14-277160:mdna:2]

[0001193125-15-023697:mdna:3]
The Company’s Annual Report on Form
10-K, Quarterly Reports on Form 10-Q, Current Reports on Form 8-K, and amendments to reports filed pursuant to Sections 13(a) and 15(d) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), are filed with the SEC. The
Company is subject to the informational requirements of the Exchange Act and files or furnishes reports, proxy statements, and other information with the SEC. Such reports and other information filed by the Company with the SEC are available free of
charge on the Company’s website at investor.apple.com/sec.cfm when such reports are available on the SEC’s website. The public may read and copy any materials filed by the Company with the SEC at the SEC’s Public Reference Room
at 100 F Street, NE, Room 1580, Washington, DC 20549. The public may obtain information on the operation of the Public Reference Room by calling the SEC at 1-800-SEC-0330. The SEC maintains an Internet site that contains reports, proxy and
information statements and other information regarding issuers that file electronically with the SEC at www.sec.gov. The contents of these websites are not incorporated into this filing. Further, the Company’s references to the URLs for
these websites are intended to be inactive textual references only.

[0001193125-15-023697:mdna:4]
[same as prior period, unchanged from 0001193125-14-277160:mdna:4]

[0001193125-15-023697:mdna:5]
[same as prior period, unchanged from 0001193125-14-277160:mdna:5]

[0001193125-15-023697:mdna:6]
The Company designs, manufactures and
markets mobile communication and media devices, personal computers and portable digital music players, and sells a variety of related software, services, accessories, networking solutions and third-party digital content and applications. The
Company’s products and services include iPhone®, iPad®, Mac®, iPod®, Apple TV®, a portfolio of consumer and professional software applications, the iOS and OS
X® operating systems, iCloud®, Apple Pay™ and a variety of accessory, service and support offerings. In September 2014, the
Company announced Apple Watch™, which is expected to be available in early calendar year 2015. The Company also sells and delivers digital content and applications through the iTunes
Store®, App Store™, Mac App Store and iBooks Store™ (collectively “iTunes”). The Company sells its products worldwide through its retail stores, online stores and direct
sales force, as well as through third-party cellular network carriers, wholesalers, retailers and value-added resellers. In addition, the Company sells a variety of third-party iPhone, iPad, Mac and iPod compatible products, including application
software, and various accessories through its online and retail stores. The Company sells to consumers, small and mid-sized businesses and education, enterprise and government customers.

[0001193125-15-023697:mdna:7]
[same as prior period, unchanged from 0001193125-14-277160:mdna:7]

[0001193125-15-023697:mdna:8]
The Company is committed to bringing the best user experience to its customers through its innovative hardware, software and services. The Company’s
business strategy leverages its unique ability to design and develop its own operating systems, hardware, application software and services to provide its customers products and solutions with innovative design, superior ease-of-use and seamless
integration. As part of its strategy, the Company continues to expand its platform for the discovery and delivery of digital content and applications through iTunes, which allows customers to discover and download digital content, iOS and Mac
applications, and books through either a Mac or Windows-based computer or through iPhone, iPad and iPod touch® devices (“iOS devices”). The Company also supports a community for the
development of third-party software and hardware products and digital content that complement the Company’s offerings. The Company believes a high-quality buying experience with knowledgeable salespersons who can convey the value of the
Company’s products and services greatly enhances its ability to attract and retain customers. Therefore, the Company’s strategy also includes building and expanding its own retail and online stores and its third-party distribution network
to effectively reach more customers and provide them with a high-quality sales and post-sales support experience. The Company believes ongoing investment in research and development (“R&D”), marketing and advertising is critical to the
development and sale of innovative products and technologies.

[0001193125-15-023697:mdna:9]
[same as prior period, unchanged from 0001193125-14-277160:mdna:9]

[0001193125-15-023697:mdna:10]
The Company has historically experienced higher net sales in its first quarter compared to other quarters in its fiscal year due in part to seasonal
holiday demand. Additionally, new product introductions can significantly impact net sales, product costs and operating expenses. Product introductions can also impact the Company’s net sales to its indirect distribution channels as these
channels are filled with new product inventory following a product introduction, and often, channel inventory of a particular product declines as the next related major product launch approaches. Net sales can also be affected when consumers and
distributors anticipate a product introduction. However, neither historical seasonal patterns nor historical patterns of product introductions should be considered reliable indicators of the Company’s future pattern of product introductions,
future net sales or financial performance.

[0001193125-15-023697:mdna:11]
First Quarter Fiscal 2015 Highlights

[0001193125-15-023697:mdna:12]
Net sales rose 30% or $17.0 billion during the first quarter of 2015 compared to the same quarter in 2014. Net sales and unit sales increased for iPhone
and Mac following the launches of new iPhone and Mac models, and net sales of Services increased primarily due to growth from iOS apps sales and licensing. This growth was partially offset by lower net sales and unit sales of iPad and by weakness in
most foreign currencies relative to the U.S. dollar. Total net sales increased in each of the Company’s operating segments, with particularly strong growth in Greater China where net sales increased 70% year-over-year.

[0001193125-15-023697:mdna:13]
During the first quarter of 2015, the Company introduced iPad Air® 2, iPad mini™ 3, iMac® with Retina® 5K Display and an updated Mac mini; and released OS X Yosemite.

[0001193125-15-023697:mdna:14]
The Company utilized $5.0 billion to repurchase its common stock and paid dividends of $2.8 billion or $0.47 per common share during the first quarter of
2015. Additionally, the Company issued €2.8 billion of Euro-denominated long-term debt.

[0001193125-15-023697:mdna:15]
[same as prior period, unchanged from 0001193125-14-277160:mdna:15]

[0001193125-15-023697:mdna:16]
In the first quarter of 2015, the Company changed its reportable operating segments and categorization of product-level net sales reporting to align with
the way its business is managed and to better reflect its evolving products and services. The following table shows net sales by operating segment and net sales and unit sales by product during the three months ended December 27, 2014 and
December 28, 2013 (dollars in millions and units in thousands):

[0001193125-15-023697:mdna:17]
|  |  | Three Months Ended |  |
|  |  | December 27,2014 |  |  | December 28,2013 |  |  | Change |  |
| Net Sales by Operating Segment: |  |  |  |  |
| Americas |  | $ | 30,566 |  |  | $ | 24,789 |  |  |  | 23% |  |
| Europe |  |  | 17,214 |  |  |  | 14,335 |  |  |  | 20% |  |
| Greater China |  |  | 16,144 |  |  |  | 9,496 |  |  |  | 70% |  |
| Japan |  |  | 5,448 |  |  |  | 5,045 |  |  |  | 8% |  |
| Rest of Asia Pacific |  |  | 5,227 |  |  |  | 3,929 |  |  |  | 33% |  |
| Total net sales |  | $ | 74,599 |  |  | $ | 57,594 |  |  |  | 30% |  |
| Net Sales by Product: |  |  |  |  |
| iPhone (1) |  | $ | 51,182 |  |  | $ | 32,498 |  |  |  | 57% |  |
| iPad (1) |  |  | 8,985 |  |  |  | 11,468 |  |  |  | (22)% |  |
| Mac (1) |  |  | 6,944 |  |  |  | 6,395 |  |  |  | 9% |  |
| Services (2) |  |  | 4,799 |  |  |  | 4,397 |  |  |  | 9% |  |
| Other Products (1)(3) |  |  | 2,689 |  |  |  | 2,836 |  |  |  | (5)% |  |
| Total net sales |  | $ | 74,599 |  |  | $ | 57,594 |  |  |  | 30% |  |
| Unit Sales by Product: |  |  |  |  |
| iPhone |  |  | 74,468 |  |  |  | 51,025 |  |  |  | 46% |  |
| iPad |  |  | 21,419 |  |  |  | 26,035 |  |  |  | (18)% |  |
| Mac |  |  | 5,519 |  |  |  | 4,837 |  |  |  | 14% |  |

[0001193125-15-023697:mdna:18]
|  | (1) | Includes deferrals and amortization of related non-software services and software upgrade rights. |  |

[0001193125-15-023697:mdna:19]
|  | (2) | Includes revenue from iTunes, AppleCare®, Apple Pay, licensing and other services. |  |

[0001193125-15-023697:mdna:20]
|  | (3) | Includes sales of iPod, Apple TV, Beats Electronics and Apple-branded and third-party accessories. |  |

[0001193125-15-023697:mdna:21]
26

[0001193125-15-023697:mdna:22]
[same as prior period, unchanged from 0001193125-14-277160:mdna:23]

[0001193125-15-023697:mdna:23]
[same as prior period, unchanged from 0001193125-14-277160:mdna:24]

[0001193125-15-023697:mdna:24]
The following table presents iPhone net sales and unit
sales information for the first quarter of 2015 and 2014 (dollars in millions and units in thousands):

[0001193125-15-023697:mdna:25]
|  |  | Three Months Ended |  |
|  |  | December 27,2014 |  |  | December 28,2013 |  |  | Change |  |
| Net sales |  | $ | 51,182 |  |  | $ | 32,498 |  |  |  | 57% |  |
| Percentage of total net sales |  |  | 69% |  |  |  | 56% |  |  |  |  |  |
| Unit sales |  |  | 74,468 |  |  |  | 51,025 |  |  |  | 46% |  |

[0001193125-15-023697:mdna:26]
The year-over-year growth in iPhone net sales and unit sales resulted from the launch of new iPhones at the end of 2014
and in the first quarter of 2015; and expanded distribution. Demand for iPhone 6 and 6 Plus was greater than available supply during the first quarter of 2015, and overall iPhone channel inventory decreased slightly from levels at the beginning of
the quarter. Overall average selling prices (“ASPs”) for iPhone increased by 8% in the first quarter of 2015 compared to the first quarter of 2014 due to the introduction of iPhone 6 Plus and an increased mix of higher storage capacity
iPhones, which was partially offset by the effect of weakness in most foreign currencies relative to the U.S. dollar.

[0001193125-15-023697:mdna:27]
[same as prior period, unchanged from 0001193125-14-277160:mdna:28]

[0001193125-15-023697:mdna:28]
The following table presents iPad net sales and unit sales information for the first quarter of 2015 and 2014 (dollars in millions and units in
thousands):

[0001193125-15-023697:mdna:29]
|  |  | Three Months Ended |  |
|  |  | December 27,2014 |  |  | December 28,2013 |  |  | Change |  |
| Net sales |  | $ | 8,985 |  |  | $ | 11,468 |  |  |  | (22)% |  |
| Percentage of total net sales |  |  | 12% |  |  |  | 20% |  |  |  |  |  |
| Unit sales |  |  | 21,419 |  |  |  | 26,035 |  |  |  | (18)% |  |

[0001193125-15-023697:mdna:30]
iPad net sales and unit sales declined on a year-over-year basis. The Company believes the decline in sales is due in
part to a longer repurchase cycle for iPads and some level of cannibalization from the Company’s other products. Additionally, while iPad channel inventory in all of the Company’s operating segments increased from the beginning to the end
of the quarter to support new product introductions and seasonal demand, it was less than the increase in iPad channel inventory during the first quarter of 2014. iPad ASPs declined by 5% during the first quarter of 2015 compared to the first
quarter of 2014 primarily as a result of a shift in mix to lower-priced iPads and the effect of weakness in most foreign currencies relative to the U.S. dollar.

[0001193125-15-023697:mdna:31]
[same as prior period, unchanged from 0001193125-14-277160:mdna:32]

[0001193125-15-023697:mdna:32]
The following table presents Mac net sales and unit sales
information for the first quarter of 2015 and 2014 (dollars in millions and units in thousands):

[0001193125-15-023697:mdna:33]
|  |  | Three Months Ended |  |
|  |  | December 27,2014 |  |  | December 28,2013 |  |  | Change |  |
| Net sales |  | $ | 6,944 |  |  | $ | 6,395 |  |  |  | 9% |  |
| Percentage of total net sales |  |  | 9% |  |  |  | 11% |  |  |  |  |  |
| Unit sales |  |  | 5,519 |  |  |  | 4,837 |  |  |  | 14% |  |

[0001193125-15-023697:mdna:34]
The year-over-year growth in Mac net sales and unit sales was driven by the launch of new Mac desktops and strong demand
for MacBook Air. Mac ASPs declined by 5% during the first quarter of 2015 compared to the first quarter of 2014 primarily as a result of price reductions on Mac portables in the second half of 2014 and the effect of weakness in most foreign
currencies relative to the U.S. dollar.

[0001193125-15-023697:mdna:35]
Services

[0001193125-15-023697:mdna:36]
The
following table presents net sales information of Services for the first quarter of 2015 and 2014 (dollars in millions):

[0001193125-15-023697:mdna:37]
|  |  | Three Months Ended |  |
|  |  | December 27,2014 |  |  | December 28,2013 |  |  | Change |  |
| Net sales |  | $ | 4,799 |  |  | $ | 4,397 |  |  |  | 9% |  |
| Percentage of total net sales |  |  | 6% |  |  |  | 8% |  |  |  |  |  |

[0001193125-15-023697:mdna:38]
The increase in net sales of Services in the first quarter of 2015 compared to the first quarter of 2014 was primarily
due to growth from iTunes and licensing. iTunes generated a total of $2.6 billion in net sales during the first quarter of 2015 compared to $2.4 billion during the first quarter of 2014. Growth from iTunes was driven by increases in revenue from iOS
app sales reflecting continued growth in the installed base of iOS devices, the expansion in third-party iOS apps available, and increased volume of in-app purchases; partially offset by a 7% year-over-year decrease in net sales of digital media
consisting of music, movies, TV shows and books.

[0001193125-15-023697:mdna:39]
[same as prior period, unchanged from 0001193125-14-277160:mdna:40]

[0001193125-15-023697:mdna:40]
The Company manages its business primarily on a geographic basis. As the Company continues to expand its business, management believes collaboration
across its online, retail and indirect channels is integral to better serve its customers and optimize its financial results. In the first quarter of 2015, the Company’s management began reporting business performance and making decisions
primarily on a geographic basis, including the results of its retail stores in each respective geographic segment. Accordingly, to align with the way the business is currently managed, the Company’s reportable operating segments now consist of
the Americas, Europe, Greater China, Japan and Rest of Asia Pacific. Retail is no longer reported as a separate reportable operating segment. The Americas segment includes both North and South America. The Europe segment includes European countries,
as well as India, the Middle East and Africa. The Greater China segment includes China, Hong Kong and Taiwan. The Rest of Asia Pacific segment includes Australia and Asian countries, other than those countries included in the Company’s other
operating segments. Each operating segment provides similar hardware and software products and similar services. Further information regarding the Company’s operating segments may be found in Part I, Item 1 of this Form 10-Q in the Notes
to Condensed Consolidated Financial Statements, in Note 11, “Segment Information and Geographic Data.”

[0001193125-15-023697:mdna:41]
[same as prior period, unchanged from 0001193125-14-277160:mdna:42]

[0001193125-15-023697:mdna:42]
The following table presents Americas net sales information for the first quarter of 2015 and 2014 (dollars in millions):

[0001193125-15-023697:mdna:43]
|  |  | Three Months Ended |  |
|  |  | December 27,2014 |  |  | December 28,2013 |  |  | Change |  |
| Net sales |  | $ | 30,566 |  |  | $ | 24,789 |  |  |  | 23% |  |
| Percentage of total net sales |  |  | 41% |  |  |  | 43% |  |  |  |  |  |

[0001193125-15-023697:mdna:44]
The year-over-year increase in Americas net sales was driven primarily by growth in net sales and unit sales of iPhone
and Mac, partially offset by a decline in net sales and unit sales of iPad and a stronger U.S. dollar, particularly relative to Latin American currencies. Net sales from Services in the Americas increased due to continued strong sales of iOS apps,
partially offset by lower digital media sales.

[0001193125-15-023697:mdna:45]
[same as prior period, unchanged from 0001193125-14-277160:mdna:46]

[0001193125-15-023697:mdna:46]
The following table
presents Europe net sales information for the first quarter of 2015 and 2014 (dollars in millions):

[0001193125-15-023697:mdna:47]
|  |  | Three Months Ended |  |
|  |  | December 27,2014 |  |  | December 28,2013 |  |  | Change |  |
| Net sales |  | $ | 17,214 |  |  | $ | 14,335 |  |  |  | 20% |  |
| Percentage of total net sales |  |  | 23% |  |  |  | 25% |  |  |  |  |  |

[0001193125-15-023697:mdna:48]
The increase in Europe net sales during the first quarter of 2015 compared to the first quarter of 2014 primarily
reflects strong growth in net sales and unit sales in iPhone and Mac, partially offset by a decline in net sales and unit sales of iPad and weaker European currencies relative to the U.S. dollar. iPhone channel inventory declined from the end of
2014 as demand for new iPhones was greater than available supply.

[0001193125-15-023697:mdna:49]
[same as prior period, unchanged from 0001193125-14-277160:mdna:50]

[0001193125-15-023697:mdna:50]
The following table presents Greater China net sales information for the first quarter of 2015 and 2014 (dollars in millions):

[0001193125-15-023697:mdna:51]
|  |  | Three Months Ended |  |
|  |  | December 27,2014 |  |  | December 28,2013 |  |  | Change |  |
| Net sales |  | $ | 16,144 |  |  | $ | 9,496 |  |  |  | 70% |  |
| Percentage of total net sales |  |  | 22% |  |  |  | 16% |  |  |  |  |  |

[0001193125-15-023697:mdna:52]
During the first quarter of 2015, Greater China experienced a year-over-year increase in net sales significantly higher
than those experienced by the Company overall. iPhone and Mac net sales and unit sales grew strongly following the launch of new iPhone models and Mac desktops in Greater China. The addition of a significant new carrier in the second quarter of 2014
also contributed to the higher year-over-year iPhone net sales and unit sales growth. Additionally, Greater China experienced strong growth in net sales from Services primarily due to increased sales of iOS apps. This growth was partially offset by
a decline in net sales and unit sales of iPad.

[0001193125-15-023697:mdna:53]
[same as prior period, unchanged from 0001193125-14-277160:mdna:54]

[0001193125-15-023697:mdna:54]
The
following table presents Japan net sales information for the first quarter of 2015 and 2014 (dollars in millions):

[0001193125-15-023697:mdna:55]
|  |  | Three Months Ended |  |
|  |  | December 27,2014 |  |  | December 28,2013 |  |  | Change |  |
| Net sales |  | $ | 5,448 |  |  | $ | 5,045 |  |  |  | 8% |  |
| Percentage of total net sales |  |  | 7% |  |  |  | 9% |  |  |  |  |  |

[0001193125-15-023697:mdna:56]
The increase in Japan net sales during the first quarter of 2015 compared to the first quarter of 2014 reflects higher
net sales and unit sales of iPhone and iPad following the Company’s recent product launches, partially offset by lower net sales and unit sales of Mac and a significant adverse impact from weakness in the Japanese Yen relative to the U.S.
dollar. iPad net sales and unit sales increased in Japan primarily due to the introduction of new iPad models and strong cellular network carrier performance. The increase in Japan net sales was also driven by strong growth in Services primarily due
to higher sales of iOS apps.

[0001193125-15-023697:mdna:57]
[same as prior period, unchanged from 0001193125-14-277160:mdna:58]

[0001193125-15-023697:mdna:58]
The following table presents Rest of Asia Pacific net sales information for the first quarter of 2015 and 2014 (dollars in millions):

[0001193125-15-023697:mdna:59]
|  |  | Three Months Ended |  |
|  |  | December 27,2014 |  |  | December 28,2013 |  |  | Change |  |
| Net sales |  | $ | 5,227 |  |  | $ | 3,929 |  |  |  | 33% |  |
| Percentage of total net sales |  |  | 7% |  |  |  | 7% |  |  |  |  |  |

[0001193125-15-023697:mdna:60]
The increase in Rest of Asia Pacific net sales during the first quarter of 2015 compared to the first quarter of 2014
primarily reflects strong growth in net sales and unit sales in iPhone and Mac, partially offset by a decline in net sales and unit sales of iPad and weaker foreign currencies relative to the U.S. dollar. iPhone channel inventory increased
sequentially during the quarter to support recent product launches and seasonal demand.

[0001193125-15-023697:mdna:61]
[same as prior period, unchanged from 0001193125-14-277160:mdna:68]

[0001193125-15-023697:mdna:62]
Gross margin for the first quarter of 2015 and 2014 was as follows (dollars in millions):

[0001193125-15-023697:mdna:63]
|  |  | Three Months Ended |  |
|  |  | December 27,2014 |  |  | December 28,2013 |  |
| Net sales |  | $ | 74,599 |  |  | $ | 57,594 |  |
| Cost of sales |  |  | 44,858 |  |  |  | 35,748 |  |
| Gross margin |  | $ | 29,741 |  |  | $ | 21,846 |  |
| Gross margin percentage |  |  | 39.9% |  |  |  | 37.9% |  |

[0001193125-15-023697:mdna:64]
The increase in the gross margin percentage during the first quarter of 2015 compared to the first quarter of 2014 was
driven by multiple factors including a favorable shift in mix to products with higher margins, improved leverage on fixed costs from higher net sales and lower commodity costs for some components, which was partially offset by higher cost structures
on new products and the weakness in most foreign currencies relative to the U.S. dollar.

[0001193125-15-023697:mdna:65]
The Company anticipates gross margin during the second
quarter of 2015 to be between 38.5% and 39.5%. The foregoing statement regarding the Company’s expected gross margin percentage in the second quarter of 2015 is forward-looking and could differ from actual results. The Company’s future
gross margins can be impacted by multiple factors including, but not limited to, those set forth in Part II, Item 1A of this Form 10-Q under the heading “Risk Factors” and those described in this paragraph. In general, the Company
believes gross margins will remain under downward pressure due to a variety of factors, including continued industry wide global product pricing pressures, increased competition, compressed product life cycles, product transitions, potential
increases in the cost of components, and potential strengthening of the U.S. dollar, as well as potential increases in the costs of outside manufacturing services and a potential shift in the Company’s sales mix towards products with lower
gross margins. In response to competitive pressures, the Company expects it will continue to take product pricing actions, which would adversely affect gross margins. Gross margins could also be affected by the Company’s ability to manage
product quality and warranty costs effectively and to stimulate demand for certain of its products. Due to the Company’s significant international operations, financial results can be significantly affected by fluctuations in exchange rates.

[0001193125-15-023697:mdna:66]
[same as prior period, unchanged from 0001193125-14-277160:mdna:73]

[0001193125-15-023697:mdna:67]
Operating expenses for the first quarter of 2015 and 2014 were as follows (dollars in millions):

[0001193125-15-023697:mdna:68]
|  |  | Three Months Ended |  |
|  |  | December 27,2014 |  |  | December 28,2013 |  |  | Change |  |
| Research and development |  | $ | 1,895 |  |  | $ | 1,330 |  |  |  | 42% |  |
| Percentage of total net sales |  |  | 2.5% |  |  |  | 2.3% |  |  |  |  |  |
| Selling, general and administrative |  | $ | 3,600 |  |  | $ | 3,053 |  |  |  | 18% |  |
| Percentage of total net sales |  |  | 4.8% |  |  |  | 5.3% |  |  |  |  |  |
| Total operating expenses |  | $ | 5,495 |  |  | $ | 4,383 |  |  |  | 25% |  |
| Percentage of total net sales |  |  | 7.4% |  |  |  | 7.6% |  |  |  |  |  |

[0001193125-15-023697:mdna:69]
Research and Development

[0001193125-15-023697:mdna:70]
The
growth in R&D expense during the first quarter of 2015 compared to the first quarter of 2014 was driven primarily by an increase in headcount and related expenses, including share-based compensation costs, and machinery and equipment to support
expanded R&D activities. The Company continues to believe that focused investments in R&D are critical to its future growth and competitive position in the marketplace and are directly related to timely development of new and enhanced
products that are central to the Company’s core business strategy. As such, the Company expects to make further investments in R&D to remain competitive.

[0001193125-15-023697:mdna:71]
Selling, General and Administrative

[0001193125-15-023697:mdna:72]
The growth in selling,
general and administrative expense during the first quarter of 2015 compared to the first quarter of 2014 was primarily due to increased headcount and related expenses, including share-based compensation costs; higher spending on marketing and
advertising; and the Company’s continued expansion of its retail stores.

[0001193125-15-023697:mdna:73]
Other Income/(Expense), Net

[0001193125-15-023697:mdna:74]
Other income/(expense), net for the first quarter of 2015 and 2014 was as follows (dollars in millions):

[0001193125-15-023697:mdna:75]
|  |  | Three Months Ended |  |
|  |  | December 27,2014 |  |  | December 28,2013 |  |  | Change |  |
| Interest and dividend income |  | $ | 654 |  |  | $ | 427 |  |  |  |  |  |
| Interest expense |  |  | (131 | ) |  |  | (84 | ) |  |  |  |  |
| Other expense, net |  |  | (353 | ) |  |  | (97 | ) |  |  |  |  |
| Total other income/(expense), net |  | $ | 170 |  |  | $ | 246 |  |  |  | (31)% |  |

[0001193125-15-023697:mdna:76]
The decrease in other income/(expense), net during the first quarter of 2015 compared to the first quarter of 2014 was
due primarily to higher expenses associated with foreign exchange rate movements, higher premium expenses on foreign exchange contracts and higher interest expense on debt, partially offset by higher interest income. The weighted-average interest
rate earned by the Company on its cash, cash equivalents and marketable securities was 1.41% and 1.03% in the first quarter of 2015 and 2014, respectively.

[0001193125-15-023697:mdna:77]
[same as prior period, unchanged from 0001193125-14-277160:mdna:84]

[0001193125-15-023697:mdna:78]
Provision for income taxes and effective tax rates for the first quarter of 2015 and 2014 were as follows (dollars in millions):

[0001193125-15-023697:mdna:79]
|  |  | Three Months Ended |  |
|  |  | December 27,2014 |  |  | December 28,2013 |  |
| Provision for income taxes |  | $ | 6,392 |  |  | $ | 4,637 |  |
| Effective tax rate |  |  | 26.2% |  |  |  | 26.2% |  |

[0001193125-15-023697:mdna:80]
The Company’s effective tax rates for the first quarter of 2015 and 2014 differ from the statutory federal income
tax rate of 35% due primarily to certain undistributed foreign earnings, a substantial portion of which was generated by subsidiaries organized in Ireland, for which no U.S. taxes are provided because such earnings are intended to be indefinitely
reinvested outside the U.S. Additionally, the passage of the Tax Increase Prevention Act of 2014, which temporarily reinstated the research tax credit, reduced the effective tax rate for the first quarter of 2015.

[0001193125-15-023697:mdna:81]
The U.S. Internal Revenue Service is currently examining the years 2010 through 2012. In addition, the Company is subject to audits by state, local and
foreign tax authorities. Management believes that adequate provisions have been made for any adjustments that may result from tax examinations. However, the outcome of tax audits cannot be predicted with certainty. If any issues addressed in
the Company’s tax audits are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs.

[0001193125-15-023697:mdna:82]
[same as prior period, unchanged from 0001193125-14-277160:mdna:89]

[0001193125-15-023697:mdna:83]
In May 2014, the Financial
Accounting Standards Board issued Accounting Standards Update No. 2014-09, Revenue from Contracts with Customers (Topic 606) (“ASU 2014-09”), which amends the existing accounting standards for revenue recognition. ASU 2014-09 is based
on principles that govern the recognition of revenue at an amount an entity expects to be entitled when products are transferred to customers. ASU 2014-09 will be effective for the Company beginning in its first quarter of 2018. Early adoption is
not permitted. The new revenue standard may be applied retrospectively to each prior period presented or retrospectively with the cumulative effect recognized as of the date of adoption. The Company is currently evaluating the impact of adopting the
new revenue standard on its consolidated financial statements.

[0001193125-15-023697:mdna:84]
[same as prior period, unchanged from 0001193125-14-277160:mdna:91]

[0001193125-15-023697:mdna:85]
The following tables present selected financial information and statistics as of and during the three months ended December 27, 2014 and
September 27, 2014 (in millions):

[0001193125-15-023697:mdna:86]
|  |  | December 27,2014 |  |  | September 27,2014 |  |
| Cash, cash equivalents and marketable securities |  | $ | 177,955 |  |  | $ | 155,239 |  |
| Property, plant and equipment, net |  | $ | 20,392 |  |  | $ | 20,624 |  |
| Long-term debt |  | $ | 32,504 |  |  | $ | 28,987 |  |
| Commercial paper |  | $ | 3,899 |  |  | $ | 6,308 |  |
| Working capital |  | $ | 9,792 |  |  | $ | 5,083 |  |
|  |  | Three Months Ended |  |
|  |  | December 27,2014 |  |  | December 28,2013 |  |
| Cash generated by operating activities |  | $ | 33,722 |  |  | $ | 22,670 |  |
| Cash used in investing activities |  | $ | (21,165 | ) |  | $ | (15,103 | ) |
| Cash used in financing activities |  | $ | (6,923 | ) |  | $ | (7,749 | ) |

[0001193125-15-023697:mdna:87]
The Company believes its existing balances of cash, cash equivalents and marketable securities will be sufficient to
satisfy its working capital needs, capital asset purchases, outstanding commitments and other liquidity requirements associated with its existing operations over the next 12 months. The Company currently anticipates the cash used for future
dividends and the share repurchase program will come from its current domestic cash, cash generated from on-going U.S. operating activities and from borrowings.

[0001193125-15-023697:mdna:88]
As of December 27, 2014 and September 27, 2014, $157.8 billion and $137.1 billion,
respectively, of the Company’s cash, cash equivalents and marketable securities were held by foreign subsidiaries and are generally based in U.S. dollar-denominated holdings. Amounts held by foreign
subsidiaries are generally subject to U.S. income taxation on repatriation to the U.S. The Company’s marketable securities investment portfolio is invested primarily in highly-rated securities and its investment policy generally limits the
amount of credit exposure to any one issuer. The policy requires investments generally to be investment grade with the objective of minimizing the potential risk of principal loss.

[0001193125-15-023697:mdna:89]
During the three months ended December 27, 2014, cash generated from operating activities of $33.7 billion was a result of $18.0 billion of net
income, non-cash adjustments to net income of $5.7 billion and an increase in the net change in operating assets and liabilities of $10.0 billion. Cash used in investing activities of $21.2 billion during the three months ended December 27,
2014 consisted primarily of cash used for purchases of marketable securities, net of sales and maturities, of $17.9 billion and cash used to acquire property, plant and equipment of $3.2 billion. Cash used in financing activities of $6.9 billion
during the three months ended December 27, 2014 consisted primarily of cash used to repurchase common stock of $5.0 billion, cash used to pay dividends and dividend equivalents of $2.8 billion and cash used for repayments of commercial paper,
net of proceeds, of $2.4 billion, partially offset by proceeds from the issuance of long-term debt of $3.5 billion.

[0001193125-15-023697:mdna:90]
During the three months ended
December 28, 2013, cash generated from operating activities of $22.7 billion was a result of $13.1 billion of net income, non-cash adjustments to net income of $4.1 billion and an increase in the net change in operating assets and liabilities
of $5.5 billion. Cash used in investing activities of $15.1 billion during the three months ended December 28, 2013 consisted primarily of cash used for purchases of marketable securities, net of sales and maturities, of $12.5 billion and cash
used to acquire property, plant and equipment of $2.0 billion. Cash used in financing activities of $7.7 billion during the three months ended December 28, 2013 consisted primarily of cash used to repurchase common stock of $5.0 billion and
cash used to pay dividends and dividend equivalents of $2.8 billion.

[0001193125-15-023697:mdna:91]
[same as prior period, unchanged from 0001193125-14-277160:mdna:98]

[0001193125-15-023697:mdna:92]
The Company’s capital expenditures were $2.1 billion during the first quarter of 2015. The Company anticipates utilizing approximately $13.0 billion
for capital expenditures during 2015, which includes product tooling and manufacturing process equipment; data centers; corporate facilities and infrastructure, including information systems hardware, software and enhancements; and retail store
facilities.

[0001193125-15-023697:mdna:93]
[same as prior period, unchanged from 0001193125-14-277160:mdna:102]

[0001193125-15-023697:mdna:94]
In April 2014, the Board of Directors
authorized the Company to issue unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company intends to use the net proceeds from the commercial paper program for general corporate
purposes, including dividends and share repurchases. As of December 27, 2014, the Company had $3.9 billion of Commercial Paper outstanding, with a weighted-average interest rate of 0.11% and maturities generally less than nine months.

[0001193125-15-023697:mdna:95]
As of December 27, 2014, the Company has issued floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $32.4
billion (collectively the “Notes”). The Company has entered, and in the future may enter, into interest rate swaps to manage interest rate risk on the Notes. Interest rate swaps allow the Company to effectively convert fixed-rate payments
into floating-rate payments or floating-rate payments into fixed-rate payments. In addition, the Company has entered, and in the future may enter, into currency swaps to manage foreign currency risk on the Notes. In the first quarter of 2015, the
Company issued €2.8 billion of Euro-denominated long-term debt. To manage foreign currency risk associated with this issuance, the Company entered into currency swaps with an aggregate notional
amount of $3.5 billion, which effectively converted the Euro-denominated notes to U.S. dollar-denominated notes.

[0001193125-15-023697:mdna:96]
[same as prior period, unchanged from 0001193125-14-277160:mdna:105]

[0001193125-15-023697:mdna:97]
In April 2014, the Company’s Board of Directors increased the share repurchase program authorization from $60 billion to $90 billion of the
Company’s common stock, of which $72.9 billion had been utilized as of December 27, 2014. The share repurchase program is expected to be completed by the end of December 2015. The Company’s share repurchase program does not obligate
it to acquire any specific number of shares. Under the program, shares may be repurchased in privately negotiated or open market transactions, including under plans complying with Rule 10b5-1 under the Exchange Act.

[0001193125-15-023697:mdna:98]
The increase to the Company’s share repurchase program authorization resulted in a total capital return program of over $130 billion. The Company
expects to complete the capital return program by the end of December 2015 by paying dividends and dividend equivalents, repurchasing shares and remitting withheld taxes related to net share settlement of restricted stock units. To assist in funding
its capital return program, the Company expects to access the debt markets, both domestically and internationally.

[0001193125-15-023697:mdna:99]
The following table presents the
Company’s dividends, dividend equivalents, share repurchases and net share settlement activity from the start of the capital return program in August 2012 through December 2014 (in millions):

[0001193125-15-023697:mdna:100]
|  |  | Dividends andDividendEquivalentsPaid |  |  | AcceleratedShareRepurchases |  |  | Open MarketShareRepurchases |  |  | TaxesRelated toSettlement ofEquity Awards |  |  | Total |  |
| Q1 2015 |  | $ | 2,801 |  |  | $ | 0 |  |  | $ | 5,000 |  |  | $ | 512 |  |  | $ | 8,313 |  |
| 2014 |  |  | 11,126 |  |  |  | 21,000 |  |  |  | 24,000 |  |  |  | 1,158 |  |  |  | 57,284 |  |
| 2013 |  |  | 10,564 |  |  |  | 13,950 |  |  |  | 9,000 |  |  |  | 1,082 |  |  |  | 34,596 |  |
| 2012 |  |  | 2,488 |  |  |  | 0 |  |  |  | 0 |  |  |  | 56 |  |  |  | 2,544 |  |
| Total |  | $ | 26,979 |  |  | $ | 34,950 |  |  | $ | 38,000 |  |  | $ | 2,808 |  |  | $ | 102,737 |  |

[0001193125-15-023697:mdna:101]
In November 2014, the Company paid cash dividends of $0.47 per common share, totaling $2.8 billion. The Company plans to
increase its dividend on an annual basis subject to declaration by the Board of Directors.

[0001193125-15-023697:mdna:102]
[same as prior period, unchanged from 0001193125-14-277160:mdna:112]

[0001193125-15-023697:mdna:103]
The Company has not entered into any transactions with unconsolidated entities whereby the Company has financial guarantees, subordinated retained
interests, derivative instruments, or other contingent arrangements that expose the Company to material continuing risks, contingent liabilities, or any other obligation under a variable interest in an unconsolidated entity that provides financing,
liquidity, market risk, or credit risk support to the Company, or engages in leasing, hedging, or R&D services with the Company.

[0001193125-15-023697:mdna:104]
Operating Leases

[0001193125-15-023697:mdna:105]
The Company’s major facility leases are typically for terms not exceeding 10 years and generally contain multi-year renewal options. As of
December 27, 2014, the Company had a total of 447 retail stores. Leases for retail space are for terms ranging from five to 20 years, the majority of which are for 10 years, and often contain multi-year renewal options. As of December 27,
2014, the Company’s total future minimum lease payments under noncancelable operating leases were $4.8 billion, of which $3.5 billion related to leases for retail space.

[0001193125-15-023697:mdna:106]
Purchase Commitments

[0001193125-15-023697:mdna:107]
The Company utilizes several outsourcing
partners to manufacture sub-assemblies for the Company’s products and to perform final assembly and testing of finished products. These outsourcing partners acquire components and build product based on demand information supplied by the
Company, which typically covers periods up to 150 days. The Company also obtains individual components for its products from a wide variety of individual suppliers. Consistent with industry practice, the Company acquires components through a
combination of purchase orders, supplier contracts, and open orders based on projected demand information. Where appropriate, the purchases are applied to inventory component prepayments that are outstanding with
the respective supplier. As of December 27, 2014, the Company had outstanding off-balance sheet third-party manufacturing commitments and component purchase commitments of $21.6 billion.

[0001193125-15-023697:mdna:108]
[same as prior period, unchanged from 0001193125-14-277160:mdna:118]

[0001193125-15-023697:mdna:109]
In addition to the commitments mentioned above, the Company had other off-balance sheet obligations of $3.9 billion as of December 27, 2014, that
were comprised of commitments to acquire capital assets, including product tooling and manufacturing process equipment, and commitments related to advertising, R&D, Internet and telecommunications services, energy and other obligations.

[0001193125-15-023697:mdna:110]
The Company’s other non-current liabilities in the Condensed Consolidated Balance Sheets consist primarily of deferred tax liabilities, gross
unrecognized tax benefits and the related gross interest and penalties. As of December 27, 2014, the Company had non-current deferred tax liabilities of $23.4 billion. Additionally, as of December 27, 2014, the Company had gross
unrecognized tax benefits of $4.4 billion and an additional $821 million for gross interest and penalties classified as non-current liabilities. At this time, the Company is unable to make a reasonably reliable estimate of the timing of payments due
to uncertainties in the timing of tax audit outcomes.

[0001193125-15-023697:mdna:111]
[same as prior period, unchanged from 0001193125-14-277160:mdna:122]

[0001193125-15-023697:mdna:112]
The Company generally does not indemnify end-users of its operating system and application software against legal claims that the software infringes
third-party intellectual property rights. Other agreements entered into by the Company sometimes include indemnification provisions under which the Company could be subject to costs and/or damages in the event of an infringement claim against the
Company or an indemnified third-party. However, the Company has not been required to make any significant payments resulting from such an infringement claim asserted against it or an indemnified third-party. In the opinion of management, there was
not at least a reasonable possibility the Company may have incurred a material loss with respect to indemnification of end-users of its operating system or application software for infringement of third-party intellectual property rights. The
Company did not record a liability for infringement costs related to indemnification as of December 27, 2014 or September 27, 2014.

[0001193125-15-023697:mdna:113]
The
Company has entered into indemnification agreements with its directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by
reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required
to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, the Company maintains directors and officers liability insurance coverage to reduce its
exposure to such obligations, and payments made under these agreements historically have not been material.

[0001193125-15-023697:mdna:114]
[same as prior period, unchanged from 0001193125-14-277160:mdna:125]

[0001193125-15-023697:mdna:115]
The preparation of financial statements and related disclosures in conformity with U.S. generally accepted accounting principles (“GAAP”) and
the Company’s discussion and analysis of its financial condition and operating results require the Company’s management to make judgments, assumptions, and estimates that affect the amounts reported in its condensed consolidated financial
statements and accompanying notes. Note 1, “Summary of Significant Accounting Policies” in Part I, Item 1 of this Form 10-Q and in the Notes to Consolidated Financial Statements in Part II, Item 8 of the 2014 Form 10-K describes
the significant accounting policies and methods used in the preparation of the Company’s condensed consolidated financial statements. Management bases its estimates on historical experience and on various other assumptions it believes to be
reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities. Actual results may differ from these estimates and such differences may be material.

[0001193125-15-023697:mdna:116]
Management believes the Company’s critical accounting policies and estimates are those related to revenue recognition, valuation and impairment of
marketable securities, inventory valuation and valuation of manufacturing-related assets and estimated purchase commitment cancellation fees, warranty costs, income taxes, and legal and other contingencies. Management considers these policies
critical because they are both important to the portrayal of the Company’s financial condition and operating results, and they require management to make judgments and estimates about inherently uncertain matters. The Company’s senior
management has reviewed these critical accounting policies and related disclosures with the Audit and Finance Committee of the Company’s Board of Directors.

[0001193125-15-023697:mdna:117]
[same as prior period, unchanged from 0001193125-14-277160:mdna:128]

[0001193125-15-023697:mdna:118]
Net sales consist primarily of revenue from the sale of hardware, software, digital content and applications, accessories, and service and support
contracts. The Company recognizes revenue when persuasive evidence of an arrangement exists, delivery has occurred, the sales price is fixed or determinable and collection is probable. Product is considered delivered to the customer once it has been
shipped and title, risk of loss and rewards of ownership have been transferred. For most of the Company’s product sales, these criteria are met at the time the product is shipped. For online sales to individuals, for some sales to education
customers in the U.S., and for certain other sales, the Company defers revenue until the customer receives the product because the Company retains a portion of the risk of loss on these sales during transit. For payment terms in excess of the
Company’s standard payment terms, revenue is recognized as payments become due unless the Company has positive evidence that the sales price is fixed or determinable, such as a successful history of collection, without concession, on comparable
arrangements. The Company recognizes revenue from the sale of hardware products, software bundled with hardware that is essential to the functionality of the hardware and third-party digital content sold on the iTunes Store in accordance with
general revenue recognition accounting guidance. The Company recognizes revenue in accordance with industry specific software accounting guidance for the following types of sales transactions: (i) standalone sales of software products,
(ii) sales of software upgrades and (iii) sales of software bundled with hardware not essential to the functionality of the hardware.

[0001193125-15-023697:mdna:119]
For
multi-element arrangements that include hardware products containing software essential to the hardware product’s functionality, undelivered software elements that relate to the hardware product’s essential software and/or undelivered
non-software services, the Company allocates revenue to all deliverables based on their relative selling prices. In such circumstances, the Company uses a hierarchy to determine the selling price to be used for allocating revenue to deliverables:
(i) vendor-specific objective evidence of fair value (“VSOE”), (ii) third-party evidence of selling price (“TPE”) and (iii) best estimate of selling price (“ESP”). VSOE generally exists only when the
Company sells the deliverable separately and is the price actually charged by the Company for that deliverable. ESPs reflect the Company’s best estimates of what the selling prices of elements would be if they were sold regularly on a
stand-alone basis.

[0001193125-15-023697:mdna:120]
For sales of qualifying versions of iOS devices, Mac and Apple TV, the Company has indicated it may from time to time provide
future unspecified software upgrades and features free of charge to customers. The Company also provides various non-software services to owners of qualifying versions of iOS devices and Mac. Because the Company has neither VSOE nor TPE for the
unspecified software upgrade rights or the non-software services, revenue is allocated to these rights and services based on the Company’s ESPs. Revenue allocated to the unspecified software upgrade rights and non-software services based on the
Company’s ESPs is deferred and recognized on a straight-line basis over the estimated period the software upgrades and non-software services are expected to be provided for each of these devices, which ranges from two to four years.

[0001193125-15-023697:mdna:121]
The Company’s process for determining ESPs involves management’s judgment and considers multiple factors that may vary over time depending upon
the unique facts and circumstances related to each deliverable. Should future facts and circumstances change, the Company’s ESPs and the future rate of related amortization for software upgrades and non-software services related to future sales
of these devices could change. Factors subject to change include the unspecified software upgrade rights offered, the estimated value of unspecified software upgrade rights, the estimated or actual costs incurred to provide non-software services and
the estimated period software upgrades and non-software services are expected to be provided.

[0001193125-15-023697:mdna:122]
The Company records reductions to revenue for
estimated commitments related to price protection and other customer incentive programs. For transactions involving price protection, the Company recognizes revenue net of the estimated amount to be refunded, provided the refund amount can be
reasonably and reliably estimated and the other conditions for revenue recognition have been met. The Company’s policy requires that, if refunds cannot be reliably estimated, revenue is not recognized until reliable estimates can be made or the
price protection lapses. For the Company’s other customer incentive programs, the estimated cost is recognized at the later of the date at which the Company has sold the product or the date at which the program is offered. The Company also
records reductions to revenue for expected future product returns based on the Company’s historical experience. Future market conditions and product transitions may require the Company to increase customer incentive programs that could result
in reductions to future revenue. Additionally, certain customer incentive programs require management to estimate the number of customers who will actually redeem the incentive. Management’s estimates are based on historical experience and the
specific terms and conditions of particular incentive programs. If a greater than estimated proportion of customers redeems such incentives, the Company would be required to record additional reductions to revenue, which would have an adverse impact
on the Company’s results of operations.

[0001193125-15-023697:mdna:123]
[same as prior period, unchanged from 0001193125-14-277160:mdna:134]

[0001193125-15-023697:mdna:124]
The Company’s investments in available-for-sale securities are reported at fair value. Unrealized gains and losses related to changes in the fair
value of securities are recognized in accumulated other comprehensive income, net of tax, in the Company’s Condensed Consolidated Balance Sheets. Changes in the fair value of available-for-sale securities impact the Company’s net income
only when such securities are sold or an other-than-temporary impairment is recognized. Realized gains and losses on the sale of securities are determined by specific identification of each security’s cost basis. The Company regularly reviews
its investment portfolio to determine if any security is other-than-temporarily impaired, which would require the Company to record an impairment charge in the period any such determination is made. In making this judgment, the Company evaluates,
among other things, the duration and extent to which the fair value of a security is less than its cost; the financial condition of the issuer and any changes thereto; and the Company’s intent to sell, or whether it will more likely than not be
required to sell, the security before recovery of its amortized cost basis. The Company’s assessment on whether a security is other-than-temporarily impaired could change in the future due to new developments or changes in assumptions related
to any particular security.

[0001193125-15-023697:mdna:125]
[same as prior period, unchanged from 0001193125-14-277160:mdna:136]

[0001193125-15-023697:mdna:126]
The Company must order components for its products and build inventory in advance of product shipments and has invested in manufacturing process
equipment, including capital assets held at its suppliers’ facilities. In addition, the Company has made prepayments to certain of its suppliers associated with long-term supply agreements to secure supply of inventory components. The Company
records a write-down for inventories of components and products, including third-party products held for resale, which have become obsolete or are in excess of anticipated demand or net realizable value. The Company performs a detailed review of
inventory that considers multiple factors including demand forecasts, product life cycle status, product development plans, current sales levels and component cost trends. The Company also reviews its manufacturing-related capital assets and
inventory prepayments for impairment whenever events or circumstances indicate the carrying amount of such assets may not be recoverable. If the Company determines that an asset is not recoverable, it records an impairment loss equal to the amount
by which the carrying value of such an asset exceeds its fair value.

[0001193125-15-023697:mdna:127]
The industries in which the Company competes are subject to a rapid and
unpredictable pace of product and component obsolescence and demand changes. In certain circumstances the Company may be required to record additional write-downs of inventory, inventory prepayments and/or manufacturing-related capital assets. These
circumstances include future demand or market conditions for the Company’s products being less favorable than forecasted, unforeseen technological changes or changes to the Company’s product development plans that negatively impact the
utility of any of these assets, or significant deterioration in the financial condition of one or more of the Company’s suppliers that hold any of the Company’s manufacturing process equipment or to whom the Company has made an inventory
prepayment. Such write-downs would adversely affect the Company’s results of operations in the period when the write-downs were recorded.

[0001193125-15-023697:mdna:128]
The
Company records accruals for estimated cancellation fees related to component orders that have been cancelled or are expected to be cancelled. Consistent with industry practice, the Company acquires components through a combination of purchase
orders, supplier contracts and open orders in each case based on projected demand. Where appropriate, the purchases are applied to inventory component prepayments that are outstanding with the respective supplier. Purchase
commitments typically cover the Company’s forecasted component and manufacturing requirements for periods up to 150 days. If there is an abrupt and substantial decline in demand for one or more of the Company’s products, if the
Company’s product development plans change, or if there is an unanticipated change in technological requirements for any of the Company’s products, then the Company may be required to record additional accruals for cancellation fees that
would adversely affect its results of operations in the period when the cancellation fees are identified and recorded.

[0001193125-15-023697:mdna:129]
[same as prior period, unchanged from 0001193125-14-277160:mdna:140]

[0001193125-15-023697:mdna:130]
The Company provides for the estimated cost of warranties at the time the related revenue is recognized based on historical and projected warranty claim
rates, historical and projected cost-per-claim and knowledge of specific product failures that are outside of the Company’s typical experience. Each quarter, the Company re-evaluates these estimates to assess the adequacy of its recorded
warranty liabilities considering the size of the installed base of products subject to warranty protection and adjusts the amounts as necessary. If actual product failure rates or repair costs differ from estimates, revisions to the estimated
warranty liabilities would be required and could materially affect the Company’s results of operations.

[0001193125-15-023697:mdna:131]
[same as prior period, unchanged from 0001193125-14-277160:mdna:142]

[0001193125-15-023697:mdna:132]
The Company records a tax provision for the anticipated tax consequences of the reported results of operations. The provision for income taxes is computed
using the asset and liability method, under which deferred tax assets and liabilities are recognized for the expected future tax consequences of temporary differences between the financial reporting and tax bases of assets and liabilities, and for
operating losses and tax credit carryforwards. Deferred tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets are expected to be realized or
settled. The Company records a valuation allowance to reduce deferred tax assets to the amount that is believed more likely than not to be realized.

[0001193125-15-023697:mdna:133]
The Company recognizes tax benefits from uncertain tax positions only if it is more likely than not that the tax position will be sustained on
examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood
of being realized upon ultimate settlement.

[0001193125-15-023697:mdna:134]
Management believes it is more likely than not that forecasted income, including income that may be
generated as a result of certain tax planning strategies, together with future reversals of existing taxable temporary differences, will be sufficient to fully recover the deferred tax assets. In the event that the Company determines all or part of
the net deferred tax assets are not realizable in the future, the Company will make an adjustment to the valuation allowance that would be charged to earnings in the period such determination is made. In addition, the calculation of tax liabilities
involves significant judgment in estimating the impact of uncertainties in the application of GAAP and complex tax laws. Resolution of these uncertainties in a manner inconsistent with management’s expectations could have a material impact on
the Company’s financial condition and operating results.

[0001193125-15-023697:mdna:135]
Legal and Other Contingencies

[0001193125-15-023697:mdna:136]
As discussed in Part II, Item 1 of this Form 10-Q under the heading “Legal Proceedings” and in Part I, Item 1 of this Form 10-Q in the
Notes to Condensed Consolidated Financial Statements, in Note 10, “Commitments and Contingencies,” the Company is subject to various legal proceedings and claims that arise in the ordinary course of business. The Company records a
liability when it is probable that a loss has been incurred and the amount is reasonably estimable. There is significant judgment required in both the probability determination and as to whether an exposure can be reasonably estimated. In the
opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to loss contingencies for legal and other contingencies. However,
the outcome of legal proceedings and claims brought against the Company is subject to significant uncertainty. Therefore, although management considers the likelihood of such an outcome to be remote, if one or more of these legal matters were
resolved against the Company in a reporting period for amounts in excess of management’s expectations, the Company’s consolidated financial statements for that reporting period could be materially adversely affected.
