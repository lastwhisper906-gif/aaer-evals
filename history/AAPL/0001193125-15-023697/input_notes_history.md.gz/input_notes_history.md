# AAPL note change history — 0001193125-14-277160 → 0001193125-15-023697


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-01-28):
[0001193125-15-023697:note_history:1]
The following table shows changes in the
 Company’s accrued warranties and related costs for the three
 months ended December 27, 2014 and December 28, 2013 (in
 millions):
  (was, 2014-07-23, similarity 0.8869):
[0001193125-14-277160:note_history:1]
The following
 table shows changes in the Company’s accrued warranties and
 related costs for the three- and nine-month periods ended
 June 28, 2014 and June 29, 2013 (in millions):

- changed (2015-01-28):
[0001193125-15-023697:note_history:2]
|  |  | Three Months Ended |  |
|  |  | December 27, 2014 |  |  | December 28, 2013 |  |
| Beginning accrued warranty and related costs |  | $ | 4,159 |  |  | $ | 2,967 |  |
| Cost of warranty claims |  |  | (1,044 | ) |  |  | (1,064 | ) |
| Accruals for product warranty |  |  | 2,080 |  |  |  | 2,077 |  |
| Ending accrued warranty and related costs |  | $ | 5,195 |  |  | $ | 3,980 |  |
  (was, 2014-07-23, similarity 0.7442):
[0001193125-14-277160:note_history:2]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 28, 2014 |  |  | June 29, 2013 |  |  | June 28, 2014 |  |  | June 29, 2013 |  |
| Beginning accrued warranty and related costs |  | $ | 4,368 |  |  | $ | 3,014 |  |  | $ | 2,967 |  |  | $ | 1,638 |  |
| Cost of warranty claims |  |  | (882 | ) |  |  | (1,033 | ) |  |  | (2,811 | ) |  |  | (2,566 | ) |
| Accruals for product warranty |  |  | 756 |  |  |  | 736 |  |  |  | 4,086 |  |  |  | 3,645 |  |
| Ending accrued warranty and related costs |  | $ | 4,242 |  |  | $ | 2,717 |  |  | $ | 4,242 |  |  | $ | 2,717 |  |

- changed (2015-01-28):
[0001193125-15-023697:note_history:3]
The Company generally does not indemnify end-users
 of its operating system and application software against legal
 claims that the software infringes third-party intellectual
 property rights. Other agreements entered into by the Company
 sometimes include indemnification provisions under which the
 Company could be subject to costs and/or damages in the event of an
 infringement claim against the Company or an indemnified
 third-party. However, the Company has not been required to make any
 significant payments resulting from such an infringement claim
 asserted against it or an indemnified third-party. In the opinion
 of management, there was not at least a reasonable possibility the
 Company may have incurred a material loss with respect to
 indemnification of end-users of its operating system or application
 software for infringement of third-party intellectual property
 rights. The Company did not record a liability for infringement
 costs related to indemnification as of December 27, 2014 or
 September 27, 2014.
  (was, 2014-07-23, similarity 0.9821):
[0001193125-14-277160:note_history:3]
The Company
 generally does not indemnify end-users of its operating system and
 application software against legal claims that the software
 infringes third-party intellectual property rights. Other
 agreements entered into by the Company sometimes include
 indemnification provisions under which the Company could be subject
 to costs and/or damages in the event of an infringement claim
 against the Company or an indemnified third-party. However, the
 Company has not been required to make any significant payments
 resulting from such an infringement claim asserted against it or an
 indemnified third-party. In the opinion of management, there was
 not at least a reasonable possibility the Company may have incurred
 a material loss with respect to indemnification of end-users of its
 operating system or application software for infringement of
 third-party intellectual property rights. The Company did not
 record a liability for infringement costs related to
 indemnification as of June 28, 2014 or September 28,
 2013.

- added (2015-01-28):
[0001193125-15-023697:note_history:4]
Operating Leases

- changed (2015-01-28):
[0001193125-15-023697:note_history:5]
The Company leases various equipment and
 facilities, including retail space, under noncancelable operating
 lease arrangements. The Company does not currently utilize any
 other off-balance sheet financing arrangements. The major facility
 leases are typically for terms not exceeding 10 years and generally
 contain multi-year renewal options. As of December 27, 2014,
 the Company had a total of 447 retail stores. Leases for retail
 space are for terms ranging from five to 20 years, the majority of
 which are for 10 years, and often contain multi-year renewal
 options. As of December 27, 2014, the Company’s total
 future minimum lease payments under noncancelable operating leases
 were $4.8 billion, of which $3.5 billion related to leases for
 retail space.
  (was, 2014-07-23, similarity 0.7117):
[0001193125-14-277160:note_history:5]
The Company
 leases various equipment and facilities, including retail space,
 under noncancelable operating lease arrangements. The Company does
 not currently utilize any other off-balance sheet financing
 arrangements. The major facility leases are typically for terms not
 exceeding 10 years and generally provide renewal options for terms
 not exceeding five additional years. Leases for retail space are
 for terms ranging from five to 20 years, the majority of which are
 for 10 years, and often contain multi-year renewal options. As of
 June 28, 2014, the Company’s total future minimum lease
 payments under noncancelable operating leases were $5.0 billion, of
 which $3.8 billion related to leases for retail space.

- added (2015-01-28):
[0001193125-15-023697:note_history:6]
Other Commitments

- changed (2015-01-28):
[0001193125-15-023697:note_history:7]
The Company utilizes several outsourcing partners
 to manufacture sub-assemblies for the Company’s products and
 to perform final assembly and testing of finished products. These
 outsourcing partners acquire components and build product based on
 demand information supplied by the Company, which typically covers
 periods up to 150 days. The Company also obtains individual
 components for its products from a wide variety of individual
 suppliers. Consistent with industry practice, the Company acquires
 components through a combination of purchase orders, supplier
 contracts and open orders based on projected demand information.
 Where appropriate, the purchases are applied
 to inventory component prepayments that
 are outstanding with the respective supplier. As of
 December 27, 2014, the Company had outstanding off-balance
 sheet third-party manufacturing commitments and component purchase
 commitments of $21.6 billion.
  (was, 2014-07-23, similarity 0.9928):
[0001193125-14-277160:note_history:7]
The Company
 utilizes several outsourcing partners to manufacture sub-assemblies
 for the Company’s products and to perform final assembly and
 testing of finished products. These outsourcing partners acquire
 components and build product based on demand information supplied
 by the Company, which typically covers periods up to 150 days. The
 Company also obtains individual components for its products from a
 wide variety of individual suppliers. Consistent with industry
 practice, the Company acquires components through a combination of
 purchase orders, supplier contracts, and open orders based on
 projected demand information. Where
 appropriate, the purchases are applied to inventory
 component prepayments that are outstanding with
 the respective supplier. As of June 28, 2014, the Company
 had outstanding off-balance sheet third-party manufacturing
 commitments and component purchase commitments of $15.4
 billion.

- changed (2015-01-28):
[0001193125-15-023697:note_history:8]
In addition to the commitments mentioned above, the
 Company had other off-balance sheet obligations of $3.9 billion as
 of December 27, 2014, which were comprised of commitments to
 acquire capital assets, including product tooling and manufacturing
 process equipment, and commitments related to advertising, research
 and development (“R&D”), Internet and
 telecommunications services, energy and other obligations.
  (was, 2014-07-23, similarity 0.9375):
[0001193125-14-277160:note_history:8]
In addition to
 the commitments mentioned above, the Company had additional
 off-balance sheet obligations of $5.6 billion as of June 28,
 2014, which were comprised mainly of commitments to acquire capital
 assets, including product tooling and manufacturing process
 equipment, and commitments related to advertising, research and
 development, Internet and telecommunications services and other
 obligations.

- changed (2015-01-28):
[0001193125-15-023697:note_history:9]
On August 24, 2012, a jury returned a verdict
 awarding the Company $1.05 billion in its lawsuit against Samsung
 Electronics Co., Ltd and affiliated parties in the United States
 District Court, Northern District of California, San Jose Division.
 On March 6, 2014, the District Court entered final judgment in
 favor of the Company in the amount of approximately $930
 million. Because the award is now subject to appeal, the
 Company has not recognized the award in its results of
 operations.
  (was, 2014-07-23, similarity 0.9904):
[0001193125-14-277160:note_history:9]
On
 August 24, 2012, a jury returned a verdict awarding the
 Company $1.05 billion in its lawsuit against Samsung Electronics
 Co., Ltd and affiliated parties in the United States District
 Court, Northern District of California, San Jose Division. On
 March 6, 2014, the Court entered final judgment in favor of
 the Company in the amount of approximately $930
 million. Because the award is now subject to appeal, the
 Company has not recognized the award in its results of
 operations.

- removed (2015-01-28):
[0001193125-14-277160:note_history:10]
VirnetX, Inc. v. Apple
 Inc. et al.

- removed (2015-01-28):
[0001193125-14-277160:note_history:11]
On
 August 11, 2010, VirnetX, Inc. filed an action against the
 Company alleging that certain of its products infringed on four
 patents relating to network communications technology. On
 November 6, 2012, a jury returned a verdict against the
 Company, and awarded damages of $368 million. On March 3,
 2014, the Court entered a ruling awarding a royalty of 0.98%
 against adjudicated products and products not colorably
 different than those adjudicated at trial. The Company has
 appealed the verdict, believes it has valid defenses and has not
 recorded a loss accrual at this time.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-01-28):
[0001193125-15-023697:note_history:12]
Apple Inc. and its wholly-owned subsidiaries
 (collectively “Apple” or the “Company”)
 designs, manufactures and markets mobile communication and media
 devices, personal computers and portable digital music players, and
 sells a variety of related software, services, accessories,
 networking solutions and third-party digital content and
 applications. The Company sells its products worldwide through its
 retail stores, online stores and direct sales force, as well as
 through third-party cellular network carriers, wholesalers,
 retailers and value-added resellers. In addition, the Company sells
 a variety of third-party iPhone, iPad, Mac and iPod compatible
 products, including application software, and various accessories
 through its online and retail stores. The Company sells to
 consumers, small and mid-sized businesses and education, enterprise
 and government customers.
  (was, 2014-07-23, similarity 0.9841):
[0001193125-14-277160:note_history:12]
Apple Inc. and
 its wholly-owned subsidiaries (collectively “Apple” or
 the “Company”) designs, manufactures, and markets
 mobile communication and media devices, personal computers, and
 portable digital music players, and sells a variety of related
 software, services, peripherals, networking solutions, and
 third-party digital content and applications. The Company sells its
 products worldwide through its retail stores, online stores, and
 direct sales force, as well as through third-party cellular network
 carriers, wholesalers, retailers and value-added resellers. In
 addition, the Company sells a variety of third-party iPhone, iPad,
 Mac, and iPod compatible products, including application software,
 and various accessories through its online and retail stores. The
 Company sells to consumers; small and mid-sized businesses; and
 education, enterprise and government customers.

- added (2015-01-28):
[0001193125-15-023697:note_history:13]
Certain prior period amounts in the notes to the
 condensed consolidated financial statements have been reclassified
 to conform to the current period’s presentation. In the first
 quarter of 2015, the Company changed its reportable operating
 segments and began allocating certain costs to its operating
 segments that were previously included in other corporate expenses.
 The Company has reclassified the corresponding prior period amounts
 to conform to the current period’s presentation as further
 described in Note 11, “Segment Information and Geographic
 Data.”

- changed (2015-01-28):
[0001193125-15-023697:note_history:14]
These condensed consolidated financial statements
 and accompanying notes should be read in conjunction with the
 Company’s annual consolidated financial statements and the
 notes thereto for the fiscal year ended September 27, 2014,
 included in its Annual Report on Form 10-K (the “2014 Form
 10-K”). The Company’s fiscal year is the 52 or 53-week
 period that ends on the last Saturday of September. An additional
 week is included in the first fiscal quarter approximately every
 six years to realign fiscal quarters with calendar quarters. The
 Company’s fiscal years 2015 and 2014 each include 52 weeks.
 Unless otherwise stated, references to particular years, quarters
 or months refer to the Company’s fiscal years ended in
 September and the associated quarters or months of those fiscal
 years.
  (was, 2014-07-23, similarity 0.9935):
[0001193125-14-277160:note_history:14]
These condensed
 consolidated financial statements and accompanying notes should be
 read in conjunction with the Company’s annual consolidated
 financial statements and the notes thereto for the fiscal year
 ended September 28, 2013, included in its Annual Report on
 Form 10-K (the “2013 Form 10-K”). The Company’s
 fiscal year is the 52 or 53-week period that ends on the last
 Saturday of September. An additional week is included in the first
 fiscal quarter approximately every six years to realign fiscal
 quarters with calendar quarters. The Company’s fiscal years
 2014 and 2013 include 52 weeks each. Unless otherwise stated,
 references to particular years, quarters or months refer to the
 Company’s fiscal years ended in September and the associated
 quarters or months of those fiscal years.

- changed (2015-01-28):
[0001193125-15-023697:note_history:15]
Basic earnings per share is computed by dividing
 income available to common shareholders by the weighted-average
 number of shares of common stock outstanding during the period.
 Diluted earnings per share is computed by dividing income available
 to common shareholders by the weighted-average number of shares of
 common stock outstanding during the period increased to include the
 number of additional shares of common stock that would have been
 outstanding if the potentially dilutive securities had been issued.
 Potentially dilutive securities include outstanding stock options,
 shares to be purchased under the Company’s employee stock
 purchase plan, unvested restricted stock and unvested restricted
 stock units (“RSUs”). The dilutive effect of
 potentially dilutive securities is reflected in diluted earnings
 per share by application of the treasury stock method. Under the
 treasury stock method, an increase in the fair market value of the
 Company’s common stock can result in a greater dilutive
 effect from potentially dilutive securities.
  (was, 2014-07-23, similarity 0.9869):
[0001193125-14-277160:note_history:15]
Basic earnings
 per share is computed by dividing income available to common
 shareholders by the weighted-average number of shares of common
 stock outstanding during the period. Diluted earnings per share is
 computed by dividing income available to common shareholders by the
 weighted-average number of shares of common stock outstanding
 during the period increased to include the number of additional
 shares of common stock that would have been outstanding if the
 potentially dilutive securities had been issued. Potentially
 dilutive securities include outstanding stock options, shares to be
 purchased under the Company’s employee stock purchase plan
 and unvested restricted stock units (“RSUs”). The
 dilutive effect of potentially dilutive securities is reflected in
 diluted earnings per share by application of the treasury stock
 method. Under the treasury stock method, an increase in the fair
 market value of the Company’s common stock can result in a
 greater dilutive effect from potentially dilutive
 securities.

- added (2015-01-28):
[0001193125-15-023697:note_history:16]
The following table shows the computation of basic
 and diluted earnings per share for the three months ended
 December 27, 2014 and December 28, 2013 (net income in
 millions and shares in thousands):

- changed (2015-01-28):
[0001193125-15-023697:note_history:17]
|  |  | Three Months Ended |  |
|  |  | December 27, 2014 |  |  | December 28, 2013 |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 18,024 |  |  | $ | 13,072 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding |  |  | 5,843,082 |  |  |  | 6,272,504 |  |
| Effect of dilutive securities |  |  | 38,721 |  |  |  | 37,657 |  |
| Weighted-average diluted shares |  |  | 5,881,803 |  |  |  | 6,310,161 |  |
| Basic earnings per share |  | $ | 3.08 |  |  | $ | 2.08 |  |
| Diluted earnings per share |  | $ | 3.06 |  |  | $ | 2.07 |  |
  (was, 2014-07-23, similarity 0.6313):
[0001193125-14-277160:note_history:17]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 28, 2014 |  |  | June 29, 2013 |  |  | June 28, 2014 |  |  | June 29, 2013 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 7,748 |  |  | $ | 6,900 |  |  | $ | 31,043 |  |  | $ | 29,525 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding |  |  | 6,012,635 |  |  |  | 6,430,323 |  |  |  | 6,136,147 |  |  |  | 6,526,714 |  |
| Effect of dilutive securities |  |  | 39,076 |  |  |  | 39,531 |  |  |  | 36,710 |  |  |  | 47,491 |  |
| Weighted-average diluted shares |  |  | 6,051,711 |  |  |  | 6,469,854 |  |  |  | 6,172,857 |  |  |  | 6,574,205 |  |
| Basic earnings per share |  | $ | 1.29 |  |  | $ | 1.07 |  |  | $ | 5.06 |  |  | $ | 4.52 |  |
| Diluted earnings per share |  | $ | 1.28 |  |  | $ | 1.07 |  |  | $ | 5.03 |  |  | $ | 4.49 |  |

- changed (2015-01-28):
[0001193125-15-023697:note_history:18]
Potentially dilutive securities whose effect would
 have been antidilutive were not significant for the three months
 ended December 27, 2014 and December 28, 2013. The
 Company excluded these securities from the computation of diluted
 earnings per share.
  (was, 2014-07-23, similarity 0.7111):
[0001193125-14-277160:note_history:18]
Potentially
 dilutive securities, the effect of which would have been
 antidilutive, were not significant for the three- and nine-month
 periods ended June 28, 2014 and the three- and nine-month
 periods ended June 29, 2013. The Company excluded these
 securities from the computation of diluted earnings per
 share.

- removed (2015-01-28):
[0001193125-14-277160:note_history:19]
During the
 first quarter of 2014, the Company adopted updated accounting
 standards that (i) required disclosure of additional
 information about the amounts reclassified out of Accumulated Other
 Comprehensive Income (“AOCI”) by component and
 (ii) required gross and net disclosures about offsetting
 assets and liabilities. The adoption of these updated standards
 only impacted the disclosures in the Notes to the Condensed
 Consolidated Financial Statements; accordingly, the adoption had no
 impact on the Company’s financial position or results of
 operations. The Company has provided these additional disclosures
 in this Form 10-Q in Note 8, “Comprehensive Income” and
 Note 2, “Financial Instruments,”
 respectively.

- removed (2015-01-28):
[0001193125-14-277160:note_history:20]
Common Stock
 Split

- removed (2015-01-28):
[0001193125-14-277160:note_history:21]
On June 6,
 2014, the Company effected a seven-for-one stock split to
 shareholders of record as of June 2, 2014. All share and per
 share information has been retroactively adjusted to reflect the
 stock split.

- removed (2015-01-28):
[0001193125-14-277160:note_history:22]
Revenue
 Recognition

- removed (2015-01-28):
[0001193125-14-277160:note_history:23]
In 2013, the
 Company’s combined best estimates of selling price
 (“ESPs”) for the unspecified software upgrade rights
 and the rights to receive the non-software services included with
 its qualifying hardware devices ranged from $5 to $25. Beginning in
 the first quarter of 2014, the Company adjusted the combined ESPs
 for Mac from $20 to $40 to reflect additions to unspecified
 software upgrade rights related to expansion of bundled essential
 software.

- removed (2015-01-28):
[0001193125-14-277160:note_history:24]
The following
 table shows the computation of basic and diluted earnings per share
 for the three- and nine-month periods ended June 28, 2014 and
 June 29, 2013 (in thousands, except net income in millions and
 per share amounts):


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-01-28):
[0001193125-15-023697:note_history:25]
In April 2014, the Board of Directors authorized
 the Company to issue unsecured short-term promissory notes
 (“Commercial Paper”) pursuant to a commercial paper
 program. The Company intends to use net proceeds from the
 commercial paper program for general corporate purposes, including
 dividends and share repurchases. As of December 27, 2014 and
 September 27, 2014, the Company had $3.9 billion and $6.3
 billion of Commercial Paper outstanding, respectively, with a
 weighted-average interest rate of 0.11% and 0.12%, respectively,
 and maturities generally less than nine months.
  (was, 2014-07-23, similarity 0.8848):
[0001193125-14-277160:note_history:25]
In April 2014,
 the Board of Directors authorized the Company to issue unsecured
 short-term promissory notes (“Commercial Paper”)
 pursuant to a commercial paper program. The Company intends to use
 net proceeds from the commercial paper program for general
 corporate purposes, including dividends and share repurchases. As
 of June 28, 2014, the Company had $2.0 billion of Commercial
 Paper outstanding, with a weighted average interest rate of 0.09%
 and maturities generally less than nine months.

- added (2015-01-28):
[0001193125-15-023697:note_history:26]
The following table provides a summary of cash
 flows associated with the issuance and maturities of Commercial
 Paper for the three months ended December 27, 2014 (in
 millions):

- added (2015-01-28):
[0001193125-15-023697:note_history:27]
| Maturities less than 90 days: |  |  |  |  |
| Proceeds from (repayments of) commercial paper, net |  | $ | 62 |  |
| Maturities greater than 90 days: |  |  |  |  |
| Proceeds from commercial paper |  |  | 197 |  |
| Repayments of commercial paper |  |  | (2,668 | ) |
| Maturities greater than 90 days, net |  |  | (2,471 | ) |
| Total repayments of commercial paper, net |  | $ | (2,409 | ) |

- changed (2015-01-28):
[0001193125-15-023697:note_history:28]
As of December 27, 2014, the Company has
 issued floating- and fixed-rate notes with varying maturities for
 an aggregate principal amount of $32.4 billion (collectively the
 “Notes”). The Notes are senior unsecured obligations,
 and interest is payable in arrears, quarterly for the domestic
 floating-rate notes, semi-annually for the domestic fixed-rate
 notes and annually for the foreign fixed-rate notes.
  (was, 2014-07-23, similarity 0.6497):
[0001193125-14-277160:note_history:28]
In the third
 quarter of 2014 and 2013, the Company issued $12.0 billion and
 $17.0 billion of long-term debt, respectively. The debt issuances
 included floating- and fixed-rate notes with varying maturities for
 an aggregate principal amount of $29.0 billion (collectively the
 “Notes”). The Notes are senior unsecured obligations,
 and interest is payable in arrears, quarterly for the floating-rate
 notes and semi-annually for the fixed-rate notes.

- changed (2015-01-28):
[0001193125-15-023697:note_history:29]
The following table provides a summary of the
 Company’s long-term debt as of December 27, 2014 and
 September 27, 2014:
  (was, 2014-07-23, similarity 0.9528):
[0001193125-14-277160:note_history:29]
The following table
 provides a summary of the Company’s long-term debt as of
 June 28, 2014 and September 28, 2013:

- changed (2015-01-28):
[0001193125-15-023697:note_history:30]
|  |  | December 27, 2014 |  |  | September 27, 2014 |  |
|  |  | Amount (in millions) |  |  | Effective Interest Rate |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |
| Floating-rate notes due 2016 (1) |  | $ | 1,000 |  |  |  | 0.51% |  |  | $ | 1,000 |  |  |  | 0.51% |  |
| Floating-rate notes due 2017 (2) |  |  | 1,000 |  |  |  | 0.30% |  |  |  | 1,000 |  |  |  | 0.31% |  |
| Floating-rate notes due 2018 (1) |  |  | 2,000 |  |  |  | 1.10% |  |  |  | 2,000 |  |  |  | 1.10% |  |
| Floating-rate notes due 2019 (2) |  |  | 1,000 |  |  |  | 0.53% |  |  |  | 1,000 |  |  |  | 0.54% |  |
| Fixed-rate 0.45% notes due 2016 (1) |  |  | 1,500 |  |  |  | 0.51% |  |  |  | 1,500 |  |  |  | 0.51% |  |
| Fixed-rate 1.05% notes due 2017 (2) |  |  | 1,500 |  |  |  | 0.30% |  |  |  | 1,500 |  |  |  | 0.30% |  |
| Fixed-rate 1.00% notes due 2018 (1) |  |  | 4,000 |  |  |  | 1.08% |  |  |  | 4,000 |  |  |  | 1.08% |  |
| Fixed-rate 2.10% notes due 2019 (2) |  |  | 2,000 |  |  |  | 0.53% |  |  |  | 2,000 |  |  |  | 0.53% |  |
| Fixed-rate 2.85% notes due 2021 (2) |  |  | 3,000 |  |  |  | 0.78% |  |  |  | 3,000 |  |  |  | 0.79% |  |
| Fixed-rate 1.00% Euro-denominated notes due 2022 (3) |  |  | 1,709 |  |  |  | 2.94% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.40% notes due 2023 (1) |  |  | 5,500 |  |  |  | 2.44% |  |  |  | 5,500 |  |  |  | 2.44% |  |
| Fixed-rate 3.45% notes due 2024 (2) |  |  | 2,500 |  |  |  | 0.89% |  |  |  | 2,500 |  |  |  | 0.90% |  |
| Fixed-rate 1.63% Euro-denominated notes due 2026 (3) |  |  | 1,709 |  |  |  | 3.45% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 3.85% notes due 2043 (1) |  |  | 3,000 |  |  |  | 3.91% |  |  |  | 3,000 |  |  |  | 3.91% |  |
| Fixed-rate 4.45% notes due 2044 (2) |  |  | 1,000 |  |  |  | 4.48% |  |  |  | 1,000 |  |  |  | 4.48% |  |
| Total borrowings |  |  | 32,418 |  |  |  |  |  |  |  | 29,000 |  |  |  |  |  |
| Unamortized discount |  |  | (69 | ) |  |  |  |  |  |  | (52 | ) |  |  |  |  |
| Hedge accounting fair value adjustments |  |  | 155 |  |  |  |  |  |  |  | 39 |  |  |  |  |  |
| Total long-term debt |  | $ | 32,504 |  |  |  |  |  |  | $ | 28,987 |  |  |  |  |  |
  (was, 2014-07-23, similarity 0.6802):
[0001193125-14-277160:note_history:30]
|  |  | As of June 28, 2014 |  |  | As of September 28, 2013 |  |
|  |  | Amount (in millions) |  |  | Effective Interest Rate |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |
| Floating-rate notes due 2016 |  | $ | 1,000 |  |  |  | 0.51% |  |  | $ | 1,000 |  |  |  | 0.51% |  |
| Floating-rate notes due 2017 |  |  | 1,000 |  |  |  | 0.29% |  |  |  | 0 |  |  |  | 0 |  |
| Floating-rate notes due 2018 |  |  | 2,000 |  |  |  | 1.10% |  |  |  | 2,000 |  |  |  | 1.10% |  |
| Floating-rate notes due 2019 |  |  | 1,000 |  |  |  | 0.52% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 0.45% notes due 2016 |  |  | 1,500 |  |  |  | 0.51% |  |  |  | 1,500 |  |  |  | 0.51% |  |
| Fixed-rate 1.05% notes due 2017 |  |  | 1,500 |  |  |  | 0.29% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 1.00% notes due 2018 |  |  | 4,000 |  |  |  | 1.08% |  |  |  | 4,000 |  |  |  | 1.08% |  |
| Fixed-rate 2.10% notes due 2019 |  |  | 2,000 |  |  |  | 0.52% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.85% notes due 2021 |  |  | 3,000 |  |  |  | 0.77% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.40% notes due 2023 |  |  | 5,500 |  |  |  | 2.44% |  |  |  | 5,500 |  |  |  | 2.44% |  |
| Fixed-rate 3.45% notes due 2024 |  |  | 2,500 |  |  |  | 0.88% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 3.85% notes due 2043 |  |  | 3,000 |  |  |  | 3.91% |  |  |  | 3,000 |  |  |  | 3.91% |  |
| Fixed-rate 4.45% notes due 2044 |  |  | 1,000 |  |  |  | 4.48% |  |  |  | 0 |  |  |  | 0 |  |
| Total |  |  | 29,000 |  |  |  |  |  |  |  | 17,000 |  |  |  |  |  |
| Unamortized discount |  |  | (53 | ) |  |  |  |  |  |  | (40 | ) |  |  |  |  |
| Hedge accounting fair value adjustments |  |  | 83 |  |  |  |  |  |  |  | 0 |  |  |  |  |  |
| Total |  | $ | 29,030 |  |  |  |  |  |  | $ | 16,960 |  |  |  |  |  |

- added (2015-01-28):
[0001193125-15-023697:note_history:31]
|  | (1) | Tranche relates to the $17.0 billion debt issuance in the third quarter of 2013. |  |

- added (2015-01-28):
[0001193125-15-023697:note_history:32]
|  | (2) | Tranche relates to the $12.0 billion debt issuance in the third quarter of 2014. |  |

- added (2015-01-28):
[0001193125-15-023697:note_history:33]
|  | (3) | Tranche relates to Euro-denominated debt issuance of €2.8 billion in the first quarter of 2015. |  |

- added (2015-01-28):
[0001193125-15-023697:note_history:34]
The Company has entered, and in the future may
 enter, into interest rate swaps to manage interest rate risk on the
 Notes. Such swaps allow the Company to effectively convert
 fixed-rate payments into floating-rate payments or floating-rate
 payments into fixed-rate payments. In addition, the Company has
 entered, and in the future may enter, into currency swaps to manage
 foreign currency risk on the Notes.

- added (2015-01-28):
[0001193125-15-023697:note_history:35]
In the first quarter of 2015, the Company
 issued €2.8 billion of
 Euro-denominated long-term debt. To manage foreign currency risk
 associated with this issuance, the Company entered into currency
 swaps with an aggregate notional amount of $3.5 billion, which
 effectively converted the Euro-denominated notes to U.S.
 dollar-denominated notes.

- changed (2015-01-28):
[0001193125-15-023697:note_history:36]
The effective rates for the Notes include the
 interest on the Notes, amortization of the discount and, if
 applicable, adjustments related to hedging. The Company recognized
 $128 million and $84 million of interest expense on its long-term
 debt for the three months ended December 27, 2014 and
 December 28, 2013, respectively.
  (was, 2014-07-23, similarity 0.8803):
[0001193125-14-277160:note_history:36]
The effective
 rates for the Notes include the interest on the Notes, amortization
 of the discount and, if applicable, adjustments related to hedging.
 The Company recognized $100 million and $268 million of interest
 expense on its long-term debt for the three- and nine-month periods
 ended June 28, 2014, respectively.

- changed (2015-01-28):
[0001193125-15-023697:note_history:37]
Future principal payments for the Company’s
 Notes as of December 27, 2014 are as follows (in
 millions):
  (was, 2014-07-23, similarity 0.9479):
[0001193125-14-277160:note_history:37]
Future principal payments
 for the Company’s Notes as of June 28, 2014, are as
 follows (in millions):

- changed (2015-01-28):
[0001193125-15-023697:note_history:38]
| 2015 |  | $ | 0 |  |
| 2016 |  |  | 2,500 |  |
| 2017 |  |  | 2,500 |  |
| 2018 |  |  | 6,000 |  |
| 2019 |  |  | 3,000 |  |
| Thereafter |  |  | 18,418 |  |
| Total future principal payments |  | $ | 32,418 |  |
  (was, 2014-07-23, similarity 0.9078):
[0001193125-14-277160:note_history:38]
| 2014 |  | $ | 0 |  |
| 2015 |  |  | 0 |  |
| 2016 |  |  | 2,500 |  |
| 2017 |  |  | 2,500 |  |
| 2018 |  |  | 6,000 |  |
| Thereafter |  |  | 18,000 |  |
| Total |  | $ | 29,000 |  |

- changed (2015-01-28):
[0001193125-15-023697:note_history:39]
As of December 27, 2014 and September 27,
 2014, the fair value of the Company’s Notes, based on Level 2
 inputs, was $32.4 billion and $28.5 billion, respectively.
  (was, 2014-07-23, similarity 0.965):
[0001193125-14-277160:note_history:39]
As of
 June 28, 2014 and September 28, 2013, the fair value of
 the Company’s Notes, based on Level 2 inputs, was $28.5
 billion and $15.9 billion, respectively.

- removed (2015-01-28):
[0001193125-14-277160:note_history:40]
The Company has
 entered, and may enter in the future, into interest rate swaps to
 manage interest rate risk on the Notes. Such swaps allow the
 Company to effectively convert fixed-rate payments to floating-rate
 or floating-rate payments into fixed-rate payments. In the third
 quarter of 2013, the Company entered into interest rate
 swaps with an aggregate $3.0 billion notional, which
 effectively converted the floating-rate notes due 2016 and 2018 to
 a fixed interest rate. In the third quarter of 2014, the Company
 entered into interest rate swaps with an aggregate $9.0 billion
 notional, which effectively converted the fixed-rate notes due
 2017, 2019, 2021 and 2024 to a floating interest rate.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-01-28):
[0001193125-15-023697:note_history:41]
The following table provides a summary of the
 Company’s long-term debt as of December 27, 2014 and
 September 27, 2014:
  (was, 2014-07-23, similarity 0.9528):
[0001193125-14-277160:note_history:41]
The following table
 provides a summary of the Company’s long-term debt as of
 June 28, 2014 and September 28, 2013:

- changed (2015-01-28):
[0001193125-15-023697:note_history:42]
|  |  | December 27, 2014 |  |  | September 27, 2014 |  |
|  |  | Amount (in millions) |  |  | Effective Interest Rate |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |
| Floating-rate notes due 2016 (1) |  | $ | 1,000 |  |  |  | 0.51% |  |  | $ | 1,000 |  |  |  | 0.51% |  |
| Floating-rate notes due 2017 (2) |  |  | 1,000 |  |  |  | 0.30% |  |  |  | 1,000 |  |  |  | 0.31% |  |
| Floating-rate notes due 2018 (1) |  |  | 2,000 |  |  |  | 1.10% |  |  |  | 2,000 |  |  |  | 1.10% |  |
| Floating-rate notes due 2019 (2) |  |  | 1,000 |  |  |  | 0.53% |  |  |  | 1,000 |  |  |  | 0.54% |  |
| Fixed-rate 0.45% notes due 2016 (1) |  |  | 1,500 |  |  |  | 0.51% |  |  |  | 1,500 |  |  |  | 0.51% |  |
| Fixed-rate 1.05% notes due 2017 (2) |  |  | 1,500 |  |  |  | 0.30% |  |  |  | 1,500 |  |  |  | 0.30% |  |
| Fixed-rate 1.00% notes due 2018 (1) |  |  | 4,000 |  |  |  | 1.08% |  |  |  | 4,000 |  |  |  | 1.08% |  |
| Fixed-rate 2.10% notes due 2019 (2) |  |  | 2,000 |  |  |  | 0.53% |  |  |  | 2,000 |  |  |  | 0.53% |  |
| Fixed-rate 2.85% notes due 2021 (2) |  |  | 3,000 |  |  |  | 0.78% |  |  |  | 3,000 |  |  |  | 0.79% |  |
| Fixed-rate 1.00% Euro-denominated notes due 2022 (3) |  |  | 1,709 |  |  |  | 2.94% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.40% notes due 2023 (1) |  |  | 5,500 |  |  |  | 2.44% |  |  |  | 5,500 |  |  |  | 2.44% |  |
| Fixed-rate 3.45% notes due 2024 (2) |  |  | 2,500 |  |  |  | 0.89% |  |  |  | 2,500 |  |  |  | 0.90% |  |
| Fixed-rate 1.63% Euro-denominated notes due 2026 (3) |  |  | 1,709 |  |  |  | 3.45% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 3.85% notes due 2043 (1) |  |  | 3,000 |  |  |  | 3.91% |  |  |  | 3,000 |  |  |  | 3.91% |  |
| Fixed-rate 4.45% notes due 2044 (2) |  |  | 1,000 |  |  |  | 4.48% |  |  |  | 1,000 |  |  |  | 4.48% |  |
| Total borrowings |  |  | 32,418 |  |  |  |  |  |  |  | 29,000 |  |  |  |  |  |
| Unamortized discount |  |  | (69 | ) |  |  |  |  |  |  | (52 | ) |  |  |  |  |
| Hedge accounting fair value adjustments |  |  | 155 |  |  |  |  |  |  |  | 39 |  |  |  |  |  |
| Total long-term debt |  | $ | 32,504 |  |  |  |  |  |  | $ | 28,987 |  |  |  |  |  |
  (was, 2014-07-23, similarity 0.6802):
[0001193125-14-277160:note_history:42]
|  |  | As of June 28, 2014 |  |  | As of September 28, 2013 |  |
|  |  | Amount (in millions) |  |  | Effective Interest Rate |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |
| Floating-rate notes due 2016 |  | $ | 1,000 |  |  |  | 0.51% |  |  | $ | 1,000 |  |  |  | 0.51% |  |
| Floating-rate notes due 2017 |  |  | 1,000 |  |  |  | 0.29% |  |  |  | 0 |  |  |  | 0 |  |
| Floating-rate notes due 2018 |  |  | 2,000 |  |  |  | 1.10% |  |  |  | 2,000 |  |  |  | 1.10% |  |
| Floating-rate notes due 2019 |  |  | 1,000 |  |  |  | 0.52% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 0.45% notes due 2016 |  |  | 1,500 |  |  |  | 0.51% |  |  |  | 1,500 |  |  |  | 0.51% |  |
| Fixed-rate 1.05% notes due 2017 |  |  | 1,500 |  |  |  | 0.29% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 1.00% notes due 2018 |  |  | 4,000 |  |  |  | 1.08% |  |  |  | 4,000 |  |  |  | 1.08% |  |
| Fixed-rate 2.10% notes due 2019 |  |  | 2,000 |  |  |  | 0.52% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.85% notes due 2021 |  |  | 3,000 |  |  |  | 0.77% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.40% notes due 2023 |  |  | 5,500 |  |  |  | 2.44% |  |  |  | 5,500 |  |  |  | 2.44% |  |
| Fixed-rate 3.45% notes due 2024 |  |  | 2,500 |  |  |  | 0.88% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 3.85% notes due 2043 |  |  | 3,000 |  |  |  | 3.91% |  |  |  | 3,000 |  |  |  | 3.91% |  |
| Fixed-rate 4.45% notes due 2044 |  |  | 1,000 |  |  |  | 4.48% |  |  |  | 0 |  |  |  | 0 |  |
| Total |  |  | 29,000 |  |  |  |  |  |  |  | 17,000 |  |  |  |  |  |
| Unamortized discount |  |  | (53 | ) |  |  |  |  |  |  | (40 | ) |  |  |  |  |
| Hedge accounting fair value adjustments |  |  | 83 |  |  |  |  |  |  |  | 0 |  |  |  |  |  |
| Total |  | $ | 29,030 |  |  |  |  |  |  | $ | 16,960 |  |  |  |  |  |

- added (2015-01-28):
[0001193125-15-023697:note_history:43]
|  | (1) | Tranche relates to the $17.0 billion debt issuance in the third quarter of 2013. |  |

- added (2015-01-28):
[0001193125-15-023697:note_history:44]
|  | (2) | Tranche relates to the $12.0 billion debt issuance in the third quarter of 2014. |  |

- added (2015-01-28):
[0001193125-15-023697:note_history:45]
|  | (3) | Tranche relates to Euro-denominated debt issuance of €2.8 billion in the first quarter of 2015. |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-01-28):
[0001193125-15-023697:note_history:46]
Future principal payments for the Company’s
 Notes as of December 27, 2014 are as follows (in
 millions):
  (was, 2014-07-23, similarity 0.9479):
[0001193125-14-277160:note_history:46]
Future principal payments
 for the Company’s Notes as of June 28, 2014, are as
 follows (in millions):

- changed (2015-01-28):
[0001193125-15-023697:note_history:47]
| 2015 |  | $ | 0 |  |
| 2016 |  |  | 2,500 |  |
| 2017 |  |  | 2,500 |  |
| 2018 |  |  | 6,000 |  |
| 2019 |  |  | 3,000 |  |
| Thereafter |  |  | 18,418 |  |
| Total future principal payments |  | $ | 32,418 |  |
  (was, 2014-07-23, similarity 0.9078):
[0001193125-14-277160:note_history:47]
| 2014 |  | $ | 0 |  |
| 2015 |  |  | 0 |  |
| 2016 |  |  | 2,500 |  |
| 2017 |  |  | 2,500 |  |
| 2018 |  |  | 6,000 |  |
| Thereafter |  |  | 18,000 |  |
| Total |  | $ | 29,000 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: no_current_note, score: 0.0

- removed (2015-01-28):
[0001193125-14-277160:note_history:48]
Revenue
 Recognition

- removed (2015-01-28):
[0001193125-14-277160:note_history:49]
In 2013, the
 Company’s combined best estimates of selling price
 (“ESPs”) for the unspecified software upgrade rights
 and the rights to receive the non-software services included with
 its qualifying hardware devices ranged from $5 to $25. Beginning in
 the first quarter of 2014, the Company adjusted the combined ESPs
 for Mac from $20 to $40 to reflect additions to unspecified
 software upgrade rights related to expansion of bundled essential
 software.
