# AAPL 8-K — 0001193125-15-021857 filed 2015-01-27

## item codes, every 8-K on or before 2015-01-28

- 2015-01-28 0001193125-15-023732 — 8.01, 9.01
- 2015-01-27 0001193125-15-021857 — 2.02, 9.01
- 2014-11-10 0001193125-14-406296 — 8.01, 9.01
- 2014-10-20 0001193125-14-376361 — 2.02, 9.01
- 2014-07-23 0001193125-14-277193 — 8.01, 9.01
- 2014-07-22 0001193125-14-275598 — 2.02, 9.01
- 2014-07-17 0001193125-14-271698 — 5.02
- 2014-06-06 0001193125-14-228798 — 5.03, 9.01
- 2014-05-30 0001181431-14-021923 — 5.02
- 2014-05-06 0001193125-14-184969 — 8.01, 9.01
- 2014-04-23 0001193125-14-154883 — 7.01, 9.01
- 2014-04-23 0001193125-14-154871 — 2.02, 9.01
- 2014-03-05 0001193125-14-084697 — 5.02, 5.03, 5.07, 9.01
- 2014-01-27 0001193125-14-022238 — 2.02, 9.01
- 2013-10-28 0001193125-13-413498 — 2.02, 9.01
- 2013-09-23 0001181431-13-050140 — 8.01
- 2013-07-30 0001181431-13-041847 — 5.02
- 2013-07-23 0001193125-13-298914 — 2.02, 9.01
- 2013-06-21 0001193125-13-267629 — 5.02
- 2013-05-03 0001193125-13-199324 — 8.01, 9.01
- 2013-04-24 0001193125-13-170623 — 8.01, 9.01
- 2013-04-23 0001193125-13-167469 — 7.01, 9.01
- 2013-04-23 0001193125-13-167458 — 2.02, 9.01
- 2013-03-01 0001193125-13-085842 — 5.07
- 2013-01-23 0001193125-13-020783 — 2.02, 9.01
- 2012-10-25 0001193125-12-435506 — 2.02, 9.01
- 2012-07-24 0001193125-12-312355 — 2.02, 9.01
- 2012-06-28 0001181431-12-038301 — 5.02
- 2012-05-24 0001181431-12-032458 — 5.02
- 2012-04-24 0001193125-12-178928 — 2.02, 9.01
- 2012-02-27 0001193125-12-081892 — 5.07
- 2012-01-24 0001193125-12-021833 — 2.02, 9.01
- 2011-11-16 0001181431-11-056354 — 5.02
- 2011-10-18 0001193125-11-273826 — 2.02, 9.01
- 2011-10-06 0001181431-11-051976 — 8.01
- 2011-08-26 0001181431-11-047179 — 5.02
- 2011-07-19 0001193125-11-191368 — 2.02, 9.01
- 2011-06-15 0001181431-11-036782 — 5.02
- 2011-04-20 0001193125-11-103732 — 2.02, 9.01
- 2011-02-24 0001193125-11-045411 — 5.07
- 2011-01-18 0001193125-11-009392 — 2.02, 9.01
- 2011-01-18 0001181431-11-003847 — 5.02
- 2010-11-17 0001181431-10-056327 — 5.02, 5.03, 9.01
- 2010-10-18 0001193125-10-230992 — 2.02, 9.01
- 2010-07-20 0001193125-10-161807 — 2.02, 9.01
- 2010-04-20 0001193125-10-087786 — 2.02, 9.01
- 2010-03-12 0001181431-10-016054 — 5.02
- 2010-03-01 0001193125-10-044765 — 5.02, 5.07, 9.01
- 2010-01-25 0001193125-10-012096 — 2.02, 9.01
- 2009-10-19 0001193125-09-209633 — 2.02, 9.01
- 2009-08-04 0001181431-09-037492 — 5.02
- 2009-07-21 0001193125-09-152290 — 2.02, 9.01
- 2009-06-02 0001181431-09-028400 — 5.03
- 2009-04-22 0001193125-09-084599 — 2.02, 9.01
- 2009-02-27 0001181431-09-012161 — 4.01
- 2009-01-21 0001193125-09-009009 — 2.02, 9.01
- 2009-01-16 0001181431-09-003017 — 5.02
- 2008-10-21 0001193125-08-213642 — 2.02, 9.01
- 2008-08-26 0001181431-08-050059 — 5.03
- 2008-07-21 0001193125-08-154381 — 2.02, 9.01
- 2008-06-09 0001181431-08-037620 — 8.01
- 2008-04-23 0001193125-08-088001 — 2.02, 9.01
- 2008-01-22 0001193125-08-009715 — 2.02, 9.01
- 2008-01-15 0001181431-08-003342 — 2.02, 8.01
- 2008-01-08 0001181431-08-002372 — 5.02
- 2007-10-22 0001104659-07-076142 — 2.02, 9.01
- 2007-07-25 0001104659-07-056111 — 2.02, 9.01
- 2007-05-16 0001104659-07-040672 — 5.02, 9.01
- 2007-04-25 0001104659-07-031354 — 2.02, 9.01
- 2007-04-24 0001104659-07-030938 — 8.01, 9.01
- 2007-02-21 0001104659-07-012760 — 5.03, 9.01
- 2007-01-17 0001104659-07-002905 — 2.02, 9.01
- 2007-01-10 0001104659-07-001648 — 5.03, 9.01
- 2006-10-27 0001104659-06-069015 — 8.01
- 2006-10-18 0001104659-06-067275 — 2.02, 9.01
- 2006-10-04 0001104659-06-064935 — 5.02, 8.01, 9.01
- 2006-09-01 0001104659-06-058808 — 1.01, 5.02, 5.03, 9.01
- 2006-08-11 0001104659-06-054118 — 2.02, 3.01, 9.01
- 2006-08-04 0001104659-06-051302 — 2.02, 4.02, 9.01
- 2006-07-19 0001104659-06-047739 — 2.02, 9.01
- 2006-04-21 0001181431-06-024759 — 1.01
- 2006-04-19 0001104659-06-025992 — 2.02, 9.01
- 2006-01-18 0001104659-06-002690 — 2.02, 9.01
- 2006-01-10 0001104659-06-001428 — 2.02
- 2005-12-19 0001181431-05-067468 — 1.01
- 2005-10-14 0001181431-05-056604 — 5.02
- 2005-10-11 0001104659-05-048094 — 2.02, 9.01
- 2005-08-26 0001181431-05-049163 — 1.01
- 2005-08-15 0001181431-05-046871 — 1.01
- 2005-07-13 0001104659-05-032297 — 2.02, 9.01
- 2005-06-06 0001181431-05-033177 — 8.01
- 2005-04-26 0001181431-05-023450 — 1.01
- 2005-04-13 0001104659-05-016307 — 2.02, 9.01
- 2005-03-02 0001181431-05-013840 — 3.03, 5.03
- 2005-02-11 0001104659-05-005507 — 8.01
- 2005-01-12 0001104659-05-001183 — 2.02, 9.01
- 2005-01-11 0001104659-05-001049 — 2.02
- 2004-10-13 0001104659-04-030400 — 2.02, 9.01
- 2004-07-14 0001104659-04-019574 — 12, 7
- 2004-04-14 0001104659-04-010122 — 12, 7
- 2004-01-14 0001104659-04-000896 — 12, 7
- 2003-10-15 0001104659-03-022879 — 12, 7
- 2003-07-16 0001104659-03-014913 — 7, 9
- 2003-04-16 0001047469-03-013617 — 7, 9
- 2003-03-21 0001104659-03-004649 — 5, 7
- 2002-08-13 0000912057-02-031595 — 5, 7
- 2002-08-05 0000912057-02-029692 — 5, 7
- 2000-01-24 0000912057-00-002128 — 5, 7
- 1999-09-07 0000320193-99-000010 — 2
- 1999-07-16 0000320193-99-000007 — 2
- 1998-12-23 0000320193-98-000010 — 1
- 1998-01-08 0000320193-98-000001 — 2
- 1997-09-25 0000320193-97-000019 — 2
- 1997-09-25 0000320193-97-000018 — 2
- 1997-09-05 0000320193-97-000016 — 2
- 1997-07-28 0000320193-97-000012 — 4
- 1997-04-25 0000320193-97-000009 — 5
- 1997-04-10 0000320193-97-000007 — 7
- 1996-12-24 0000320193-96-000027 — 7
- 1996-12-23 0000320193-96-000025 — 4 — amendment of 0000320193-96-000021
- 1996-12-13 0000320193-96-000021 — 4
- 1996-10-28 0000912057-96-023874 — 5, 7
- 1996-06-17 0000320193-96-000014 — 1
- 1996-04-12 0000320193-96-000006 — 1

## late-filing notifications on or before 2015-01-28

- 2006-12-15 0001104659-06-081617 — NT 10-K, for the period ended 2006-09-30
- 2006-08-11 0001104659-06-053743 — NT 10-Q, for the period ended 2006-07-01

## item 2.02 — earnings release, exhibit 99.1

[0001193125-15-021857:8k_2_02:1]
EX-99.1
2
d835619dex991.htm
EX-99.1

[0001193125-15-021857:8k_2_02:2]
EX-99.1

[0001193125-15-021857:8k_2_02:3]
Exhibit 99.1

[0001193125-15-021857:8k_2_02:4]
Apple Reports Record First Quarter Results

[0001193125-15-021857:8k_2_02:5]
Highest-ever revenue &
earnings drive 48% increase in EPS

[0001193125-15-021857:8k_2_02:6]
Growth led by record revenue from iPhone, Mac & App Store

[0001193125-15-021857:8k_2_02:7]
CUPERTINO, California—January 27, 2015—Apple® today announced financial results for
its fiscal 2015 first quarter ended December 27, 2014. The Company posted record quarterly revenue of $74.6 billion and record quarterly net profit of $18 billion, or $3.06 per diluted share. These results compare to revenue of $57.6 billion
and net profit of $13.1 billion, or $2.07 per diluted share, in the year-ago quarter. Gross margin was 39.9 percent compared to 37.9 percent in the year-ago quarter. International sales accounted for 65 percent of the quarter’s revenue.

[0001193125-15-021857:8k_2_02:8]
The results were fueled by all-time record revenue from iPhone® and Mac® sales as well as record performance of the App StoreSM. iPhone unit sales of 74.5 million also set a new record.

[0001193125-15-021857:8k_2_02:9]
“We’d like to thank
our customers for an incredible quarter, which saw demand for Apple products soar to an all-time high,” said Tim Cook, Apple’s CEO. “Our revenue grew 30 percent over last year to $74.6 billion, and the execution by our teams to
achieve these results was simply phenomenal.”

[0001193125-15-021857:8k_2_02:10]
“Our exceptional results produced EPS growth of 48 percent over last year, and $33.7 billion
in operating cash flow during the quarter, an all-time record,” said Luca Maestri, Apple’s CFO. “We spent over $8 billion on our capital return program, bringing total returns to investors to almost $103 billion, over $57 billion of
which occurred in just the last 12 months.”

[0001193125-15-021857:8k_2_02:11]
Apple is providing the following guidance for its fiscal 2015 second quarter:

[0001193125-15-021857:8k_2_02:12]
| • |  | revenue between $52 billion and $55 billion |

[0001193125-15-021857:8k_2_02:13]
| • |  | gross margin between 38.5 percent and 39.5 percent |

[0001193125-15-021857:8k_2_02:14]
| • |  | operating expenses between $5.4 billion and $5.5 billion |

[0001193125-15-021857:8k_2_02:15]
| • |  | other income/(expense) of $350 million |

[0001193125-15-021857:8k_2_02:16]
| • |  | tax rate of 26.3 percent |

[0001193125-15-021857:8k_2_02:17]
Apple’s
board of directors has declared a cash dividend of $.47 per share of the Company’s common stock. The dividend is payable on February 12, 2015, to shareholders of record as of the close of business on February 9, 2015.

[0001193125-15-021857:8k_2_02:18]
Apple will provide live streaming of its Q1 2015 financial results conference call beginning at 2:00 p.m. PST on January 27, 2015 at
www.apple.com/quicktime/qtv/earningsq115. This webcast will also be available for replay for approximately two weeks thereafter.

[0001193125-15-021857:8k_2_02:19]
Apple designs Macs, the best personal computers in the world, along with OS X, iLife, iWork
and professional software. Apple leads the digital music revolution with its iPods and iTunes online store. Apple has reinvented the mobile phone with its revolutionary iPhone and App Store, and is defining the future of mobile media and computing
devices with iPad.

[0001193125-15-021857:8k_2_02:20]
Press Contact:

[0001193125-15-021857:8k_2_02:21]
Kristin Huguet

[0001193125-15-021857:8k_2_02:22]
Apple

[0001193125-15-021857:8k_2_02:23]
khuguet@apple.com

[0001193125-15-021857:8k_2_02:24]
(408) 974-2414

[0001193125-15-021857:8k_2_02:25]
Investor Relations Contacts:

[0001193125-15-021857:8k_2_02:26]
Nancy Paxton

[0001193125-15-021857:8k_2_02:27]
Apple

[0001193125-15-021857:8k_2_02:28]
paxton1@apple.com

[0001193125-15-021857:8k_2_02:29]
(408) 974-5420

[0001193125-15-021857:8k_2_02:30]
Joan Hoover

[0001193125-15-021857:8k_2_02:31]
Apple

[0001193125-15-021857:8k_2_02:32]
hoover1@apple.com

[0001193125-15-021857:8k_2_02:33]
(408) 974-4570

[0001193125-15-021857:8k_2_02:34]
NOTE TO EDITORS: For additional information visit Apple’s PR website (www.apple.com/pr), or call Apple’s Media Helpline at (408) 974-2042.

[0001193125-15-021857:8k_2_02:35]
© 2015 Apple Inc. All rights reserved. Apple, the Apple logo, Mac, Mac OS, Macintosh, iPhone and App Store are trademarks of Apple. Other
company and product names may be trademarks of their respective owners.

[0001193125-15-021857:8k_2_02:36]
Apple Inc.

[0001193125-15-021857:8k_2_02:37]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-15-021857:8k_2_02:38]
(In millions, except number of shares which are reflected in thousands and per share amounts)

[0001193125-15-021857:8k_2_02:39]
|  |  | Three Months Ended |  |
|  |  | December 27,2014 |  |  | December 28,2013 |  |
| Net sales |  | $ | 74,599 |  |  | $ | 57,594 |  |
| Cost of sales (1) |  |  | 44,858 |  |  |  | 35,748 |  |
| Gross margin |  |  | 29,741 |  |  |  | 21,846 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development (1) |  |  | 1,895 |  |  |  | 1,330 |  |
| Selling, general and administrative (1) |  |  | 3,600 |  |  |  | 3,053 |  |
| Total operating expenses |  |  | 5,495 |  |  |  | 4,383 |  |
| Operating income |  |  | 24,246 |  |  |  | 17,463 |  |
| Other income/(expense), net |  |  | 170 |  |  |  | 246 |  |
| Income before provision for income taxes |  |  | 24,416 |  |  |  | 17,709 |  |
| Provision for income taxes |  |  | 6,392 |  |  |  | 4,637 |  |
| Net income |  | $ | 18,024 |  |  | $ | 13,072 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 3.08 |  |  | $ | 2.08 |  |
| Diluted |  | $ | 3.06 |  |  | $ | 2.07 |  |
| Shares used in computing earnings per share: |  |  |  |  |  |  |  |  |
| Basic |  |  | 5,843,082 |  |  |  | 6,272,504 |  |
| Diluted |  |  | 5,881,803 |  |  |  | 6,310,161 |  |
| Cash dividends declared per common share |  | $ | 0.47 |  |  | $ | 0.44 |  |
| (1) Includes share-based compensation expense as follows: |  |
| Cost of sales |  | $ | 140 |  |  | $ | 109 |  |
| Research and development |  | $ | 374 |  |  | $ | 289 |  |
| Selling, general and administrative |  | $ | 374 |  |  | $ | 283 |  |

[0001193125-15-021857:8k_2_02:40]
Apple Inc.

[0001193125-15-021857:8k_2_02:41]
UNAUDITED CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-15-021857:8k_2_02:42]
(In millions, except number of shares which are reflected in thousands and par value)

[0001193125-15-021857:8k_2_02:43]
|  |  | December 27,2014 |  |  | September 27,2014 |  |
| ASSETS: |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 19,478 |  |  | $ | 13,844 |  |
| Short-term marketable securities |  |  | 12,985 |  |  |  | 11,233 |  |
| Accounts receivable, less allowances of $87 and $86, respectively |  |  | 16,709 |  |  |  | 17,460 |  |
| Inventories |  |  | 2,283 |  |  |  | 2,111 |  |
| Deferred tax assets |  |  | 5,046 |  |  |  | 4,318 |  |
| Vendor non-trade receivables |  |  | 13,267 |  |  |  | 9,759 |  |
| Other current assets |  |  | 13,635 |  |  |  | 9,806 |  |
| Total current assets |  |  | 83,403 |  |  |  | 68,531 |  |
| Long-term marketable securities |  |  | 145,492 |  |  |  | 130,162 |  |
| Property, plant and equipment, net |  |  | 20,392 |  |  |  | 20,624 |  |
| Goodwill |  |  | 4,629 |  |  |  | 4,616 |  |
| Acquired intangible assets, net |  |  | 4,370 |  |  |  | 4,142 |  |
| Other assets |  |  | 3,608 |  |  |  | 3,764 |  |
| Total assets |  | $ | 261,894 |  |  | $ | 231,839 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY: |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 38,001 |  |  | $ | 30,196 |  |
| Accrued expenses |  |  | 22,724 |  |  |  | 18,453 |  |
| Deferred revenue |  |  | 8,987 |  |  |  | 8,491 |  |
| Commercial paper |  |  | 3,899 |  |  |  | 6,308 |  |
| Total current liabilities |  |  | 73,611 |  |  |  | 63,448 |  |
| Deferred revenue – non-current |  |  | 3,480 |  |  |  | 3,031 |  |
| Long-term debt |  |  | 32,504 |  |  |  | 28,987 |  |
| Other non-current liabilities |  |  | 28,971 |  |  |  | 24,826 |  |
| Total liabilities |  |  | 138,566 |  |  |  | 120,292 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Shareholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock and additional paid-in capital, $0.00001 par value: 12,600,000 shares authorized; 5,826,419 and 5,866,161 shares issued and outstanding, respectively |  |  | 24,187 |  |  |  | 23,313 |  |
| Retained earnings |  |  | 97,178 |  |  |  | 87,152 |  |
| Accumulated other comprehensive income/(loss) |  |  | 1,963 |  |  |  | 1,082 |  |
| Total shareholders’ equity |  |  | 123,328 |  |  |  | 111,547 |  |
| Total liabilities and shareholders’ equity |  | $ | 261,894 |  |  | $ | 231,839 |  |

[0001193125-15-021857:8k_2_02:44]
Apple Inc.

[0001193125-15-021857:8k_2_02:45]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-15-021857:8k_2_02:46]
(In millions)

[0001193125-15-021857:8k_2_02:47]
|  |  | Three Months Ended |  |
|  |  | December 27,2014 |  |  | December 28,2013 |  |
| Cash and cash equivalents, beginning of the period |  | $ | 13,844 |  |  | $ | 14,259 |  |
| Operating activities: |  |  |  |  |  |  |  |  |
| Net income |  |  | 18,024 |  |  |  | 13,072 |  |
| Adjustments to reconcile net income to cash generated by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 2,575 |  |  |  | 2,144 |  |
| Share-based compensation expense |  |  | 888 |  |  |  | 681 |  |
| Deferred income tax expense |  |  | 2,197 |  |  |  | 1,253 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | 751 |  |  |  | (1,098 | ) |
| Inventories |  |  | (172 | ) |  |  | (358 | ) |
| Vendor non-trade receivables |  |  | (3,508 | ) |  |  | (3,459 | ) |
| Other current and non-current assets |  |  | (1,648 | ) |  |  | (319 | ) |
| Accounts payable |  |  | 9,003 |  |  |  | 8,191 |  |
| Deferred revenue |  |  | 945 |  |  |  | 1,368 |  |
| Other current and non-current liabilities |  |  | 4,667 |  |  |  | 1,195 |  |
| Cash generated by operating activities |  |  | 33,722 |  |  |  | 22,670 |  |
| Investing activities: |  |  |  |  |  |  |  |  |
| Purchases of marketable securities |  |  | (44,915 | ) |  |  | (48,397 | ) |
| Proceeds from maturities of marketable securities |  |  | 2,807 |  |  |  | 5,556 |  |
| Proceeds from sales of marketable securities |  |  | 24,166 |  |  |  | 30,302 |  |
| Payments made in connection with business acquisitions, net |  |  | (23 | ) |  |  | (525 | ) |
| Payments for acquisition of property, plant and equipment |  |  | (3,217 | ) |  |  | (1,985 | ) |
| Payments for acquisition of intangible assets |  |  | (48 | ) |  |  | (59 | ) |
| Other |  |  | 65 |  |  |  | 5 |  |
| Cash used in investing activities |  |  | (21,165 | ) |  |  | (15,103 | ) |
| Financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock |  |  | 80 |  |  |  | 134 |  |
| Excess tax benefits from equity awards |  |  | 264 |  |  |  | 280 |  |
| Taxes paid related to net share settlement of equity awards |  |  | (512 | ) |  |  | (365 | ) |
| Dividends and dividend equivalents paid |  |  | (2,801 | ) |  |  | (2,769 | ) |
| Repurchase of common stock |  |  | (5,030 | ) |  |  | (5,029 | ) |
| Proceeds from issuance of long-term debt, net |  |  | 3,485 |  |  |  | 0 |  |
| Repayments of commercial paper, net |  |  | (2,409 | ) |  |  | 0 |  |
| Cash used in financing activities |  |  | (6,923 | ) |  |  | (7,749 | ) |
| Increase/(decrease) in cash and cash equivalents |  |  | 5,634 |  |  |  | (182 | ) |
| Cash and cash equivalents, end of the period |  | $ | 19,478 |  |  | $ | 14,077 |  |
| Supplemental cash flow disclosure: |  |  |  |  |  |  |  |  |
| Cash paid for income taxes, net |  | $ | 3,869 |  |  | $ | 3,387 |  |
| Cash paid for interest |  | $ | 202 |  |  | $ | 161 |  |
