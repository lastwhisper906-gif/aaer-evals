# AAPL notes — 0000320193-22-000070


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000320193-22-000070:notes:1]
[same as prior period, unchanged from 0000320193-22-000059:notes:1]

[0000320193-22-000070:notes:2]
[same as prior period, unchanged from 0000320193-22-000059:notes:2]

[0000320193-22-000070:notes:3]
[same as prior period, unchanged from 0000320193-22-000059:notes:3]

[0000320193-22-000070:notes:4]
[same as prior period, unchanged from 0000320193-22-000059:notes:4]

[0000320193-22-000070:notes:5]
The following table shows the computation of basic and diluted earnings per share for the three- and nine-month periods ended June 25, 2022 and June 26, 2021 (net income in millions and shares in thousands):

[0000320193-22-000070:notes:6]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25,2022 |  | June 26,2021 |  | June 25,2022 |  | June 26,2021 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 19,442 |  |  | $ | 21,744 |  |  | $ | 79,082 |  |  | $ | 74,129 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 16,162,945 |  |  | 16,629,371 |  |  | 16,277,824 |  |  | 16,772,656 |  |
| Effect of dilutive securities | 99,258 |  |  | 152,364 |  |  | 117,113 |  |  | 168,871 |  |
| Weighted-average diluted shares | 16,262,203 |  |  | 16,781,735 |  |  | 16,394,937 |  |  | 16,941,527 |  |
| Basic earnings per share | $ | 1.20 |  |  | $ | 1.31 |  |  | $ | 4.86 |  |  | $ | 4.42 |  |
| Diluted earnings per share | $ | 1.20 |  |  | $ | 1.30 |  |  | $ | 4.82 |  |  | $ | 4.38 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000320193-22-000070:notes:7]
Revenue
Net sales disaggregated by significant products and services for the three- and nine-month periods ended June 25, 2022 and June 26, 2021 were as follows (in millions):

[0000320193-22-000070:notes:8]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25,2022 |  | June 26,2021 |  | June 25,2022 |  | June 26,2021 |
| iPhone® (1) | $ | 40,665 |  |  | $ | 39,570 |  |  | $ | 162,863 |  |  | $ | 153,105 |  |
| Mac® (1) | 7,382 |  |  | 8,235 |  |  | 28,669 |  |  | 26,012 |  |
| iPad® (1) | 7,224 |  |  | 7,368 |  |  | 22,118 |  |  | 23,610 |  |
| Wearables, Home and Accessories (1)(2) | 8,084 |  |  | 8,775 |  |  | 31,591 |  |  | 29,582 |  |
| Services (3) | 19,604 |  |  | 17,486 |  |  | 58,941 |  |  | 50,148 |  |
| Total net sales (4) | $ | 82,959 |  |  | $ | 81,434 |  |  | $ | 304,182 |  |  | $ | 282,457 |  |

[0000320193-22-000070:notes:9]
[same as prior period, unchanged from 0000320193-22-000059:notes:9]

[0000320193-22-000070:notes:10]
(2)Wearables, Home and Accessories net sales include sales of AirPods®, Apple TV®, Apple Watch®, Beats® products, HomePod mini® and accessories.

[0000320193-22-000070:notes:11]
[same as prior period, unchanged from 0000320193-22-000059:notes:11]

[0000320193-22-000070:notes:12]
(4)Includes $3.1 billion of revenue recognized in the three months ended June 25, 2022 that was included in deferred revenue as of March 26, 2022, $3.0 billion of revenue recognized in the three months ended June 26, 2021 that was included in deferred revenue as of March 27, 2021, $6.3 billion of revenue recognized in the nine months ended June 25, 2022 that was included in deferred revenue as of September 25, 2021, and $5.5 billion of revenue recognized in the nine months ended June 26, 2021 that was included in deferred revenue as of September 26, 2020.

[0000320193-22-000070:notes:13]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 9, “Segment Information and Geographic Data” for the three- and nine-month periods ended June 25, 2022 and June 26, 2021, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.

[0000320193-22-000070:notes:14]
As of June 25, 2022 and September 25, 2021, the Company had total deferred revenue of $12.2 billion and $11.9 billion, respectively. As of June 25, 2022, the Company expects 63% of total deferred revenue to be realized in less than a year, 27% within one-to-two years, 8% within two-to-three years and 2% in greater than three years.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000320193-22-000070:notes:15]
[same as prior period, unchanged from 0000320193-22-000059:notes:15]

[0000320193-22-000070:notes:16]
The following tables show the Company’s cash, cash equivalents and marketable securities by significant investment category as of June 25, 2022 and September 25, 2021 (in millions):

[0000320193-22-000070:notes:17]
|  | June 25, 2022 |
|  | AdjustedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |  | Cash andCashEquivalents |  | CurrentMarketableSecurities |  | Non-CurrentMarketableSecurities |
| Cash | $ | 12,852 |  |  | $ | — |  |  | $ | — |  |  | $ | 12,852 |  |  | $ | 12,852 |  |  | $ | — |  |  | $ | — |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 10,970 |  |  | — |  |  | — |  |  | 10,970 |  |  | 10,970 |  |  | — |  |  | — |  |
| Mutual funds | 252 |  |  | — |  |  | (32) |  |  | 220 |  |  | — |  |  | 220 |  |  | — |  |
| Subtotal | 11,222 |  |  | — |  |  | (32) |  |  | 11,190 |  |  | 10,970 |  |  | 220 |  |  | — |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities | 25,296 |  |  | — |  |  | (1,328) |  |  | 23,968 |  |  | 91 |  |  | 3,511 |  |  | 20,366 |  |
| U.S. agency securities | 5,805 |  |  | — |  |  | (511) |  |  | 5,294 |  |  | 4 |  |  | 240 |  |  | 5,050 |  |
| Non-U.S. government securities | 17,597 |  |  | 6 |  |  | (1,023) |  |  | 16,580 |  |  | — |  |  | 6,336 |  |  | 10,244 |  |
| Certificates of deposit and time deposits | 3,928 |  |  | — |  |  | — |  |  | 3,928 |  |  | 3,374 |  |  | 504 |  |  | 50 |  |
| Commercial paper | 966 |  |  | — |  |  | — |  |  | 966 |  |  | 209 |  |  | 757 |  |  | — |  |
| Corporate debt securities | 88,912 |  |  | 15 |  |  | (6,455) |  |  | 82,472 |  |  | 2 |  |  | 8,738 |  |  | 73,732 |  |
| Municipal securities | 978 |  |  | — |  |  | (26) |  |  | 952 |  |  | — |  |  | 203 |  |  | 749 |  |
| Mortgage- and asset-backed securities | 23,058 |  |  | — |  |  | (1,952) |  |  | 21,106 |  |  | — |  |  | 220 |  |  | 20,886 |  |
| Subtotal | 166,540 |  |  | 21 |  |  | (11,295) |  |  | 155,266 |  |  | 3,680 |  |  | 20,509 |  |  | 131,077 |  |
| Total (3) | $ | 190,614 |  |  | $ | 21 |  |  | $ | (11,327) |  |  | $ | 179,308 |  |  | $ | 27,502 |  |  | $ | 20,729 |  |  | $ | 131,077 |  |

[0000320193-22-000070:notes:18]
[same as prior period, unchanged from 0000320193-22-000059:notes:18]

[0000320193-22-000070:notes:19]
[same as prior period, unchanged from 0000320193-22-000059:notes:19]

[0000320193-22-000070:notes:20]
[same as prior period, unchanged from 0000320193-22-000059:notes:20]

[0000320193-22-000070:notes:21]
(3)As of June 25, 2022 and September 25, 2021, total marketable securities included $14.1 billion and $17.9 billion, respectively, that were restricted from general use, related to the European Commission decision finding that Ireland granted state aid to the Company, and other agreements.

[0000320193-22-000070:notes:22]
The following table shows the fair value of the Company’s non-current marketable debt securities, by contractual maturity, as of June 25, 2022 (in millions):

[0000320193-22-000070:notes:23]
| Due after 1 year through 5 years | $ | 92,970 |  |
| Due after 5 years through 10 years | 19,317 |  |
| Due after 10 years | 18,790 |  |
| Total fair value | $ | 131,077 |  |

[0000320193-22-000070:notes:24]
[same as prior period, unchanged from 0000320193-22-000059:notes:24]

[0000320193-22-000070:notes:25]
[same as prior period, unchanged from 0000320193-22-000059:notes:25]

[0000320193-22-000070:notes:26]
[same as prior period, unchanged from 0000320193-22-000059:notes:26]

[0000320193-22-000070:notes:27]
[same as prior period, unchanged from 0000320193-22-000059:notes:27]

[0000320193-22-000070:notes:28]
To protect the Company’s foreign currency–denominated term debt or marketable securities from fluctuations in foreign currency exchange rates, the Company may enter into forward contracts, cross-currency swaps or other instruments. The Company designates these instruments as either cash flow or fair value hedges. As of June 25, 2022, the Company’s hedged term debt– and marketable securities–related foreign currency transactions are expected to be recognized within 20 years.

[0000320193-22-000070:notes:29]
[same as prior period, unchanged from 0000320193-22-000059:notes:29]

[0000320193-22-000070:notes:30]
[same as prior period, unchanged from 0000320193-22-000059:notes:30]

[0000320193-22-000070:notes:31]
[same as prior period, unchanged from 0000320193-22-000059:notes:31]

[0000320193-22-000070:notes:32]
The notional amounts of the Company’s outstanding derivative instruments as of June 25, 2022 and September 25, 2021 were as follows (in millions):

[0000320193-22-000070:notes:33]
|  | June 25,2022 |  | September 25,2021 |
| Derivative instruments designated as accounting hedges: |  |  |  |
| Foreign exchange contracts | $ | 76,234 |  |  | $ | 76,475 |  |
| Interest rate contracts | $ | 20,775 |  |  | $ | 16,875 |  |
| Derivative instruments not designated as accounting hedges: |  |  |  |
| Foreign exchange contracts | $ | 84,506 |  |  | $ | 126,918 |  |

[0000320193-22-000070:notes:34]
The gross fair values of the Company’s derivative assets and liabilities were not material as of June 25, 2022 and September 25, 2021.

[0000320193-22-000070:notes:35]
The gains and losses recognized in other comprehensive income/(loss) and amounts reclassified from accumulated other comprehensive income/(loss) to net income for the Company’s derivative instruments designated as cash flow hedges were not material in the three- and nine-month periods ended June 25, 2022 and June 26, 2021.

[0000320193-22-000070:notes:36]
The carrying amounts of the Company’s hedged items in fair value hedges as of June 25, 2022 and September 25, 2021 were as follows (in millions):

[0000320193-22-000070:notes:37]
|  | June 25,2022 |  | September 25,2021 |
| Hedged assets/(liabilities): |  |  |  |
| Current and non-current marketable securities | $ | 14,250 |  |  | $ | 15,954 |  |
| Current and non-current term debt | $ | (19,281) |  |  | $ | (17,857) |  |

[0000320193-22-000070:notes:38]
The gains and losses on the Company’s derivative instruments designated as fair value hedges and the related hedged item adjustments were not material in the three- and nine-month periods ended June 25, 2022 and June 26, 2021.

[0000320193-22-000070:notes:39]
[same as prior period, unchanged from 0000320193-22-000059:notes:39]

[0000320193-22-000070:notes:40]
[same as prior period, unchanged from 0000320193-22-000059:notes:40]

[0000320193-22-000070:notes:41]
[same as prior period, unchanged from 0000320193-22-000059:notes:41]

[0000320193-22-000070:notes:42]
The Company’s cellular network carriers accounted for 36% and 42% of total trade receivables as of June 25, 2022 and September 25, 2021, respectively.

[0000320193-22-000070:notes:43]
[same as prior period, unchanged from 0000320193-22-000059:notes:43]

[0000320193-22-000070:notes:44]
The Company has non-trade receivables from certain of its manufacturing vendors resulting from the sale of components to these vendors who manufacture subassemblies or assemble final products for the Company. The Company purchases these components directly from suppliers. As of June 25, 2022, the Company had two vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 54% and 12%. As of September 25, 2021, the Company had three vendors that individually represented 10% or more of total vendor non-trade receivables, which accounted for 52%, 11% and 11%.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000320193-22-000070:notes:45]
[same as prior period, unchanged from 0000320193-22-000059:notes:45]


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000320193-22-000070:notes:46]
Condensed Consolidated Financial Statement Details
The following tables show the Company’s condensed consolidated financial statement details as of June 25, 2022 and September 25, 2021 (in millions):

[0000320193-22-000070:notes:47]
[same as prior period, unchanged from 0000320193-22-000059:notes:47]

[0000320193-22-000070:notes:48]
|  | June 25,2022 |  | September 25,2021 |
| Gross property, plant and equipment | $ | 111,851 |  |  | $ | 109,723 |  |
| Accumulated depreciation and amortization | (71,516) |  |  | (70,283) |  |
| Total property, plant and equipment, net | $ | 40,335 |  |  | $ | 39,440 |  |

[0000320193-22-000070:notes:49]
[same as prior period, unchanged from 0000320193-22-000059:notes:49]

[0000320193-22-000070:notes:50]
|  | June 25,2022 |  | September 25,2021 |
| Long-term taxes payable | $ | 20,699 |  |  | $ | 24,689 |  |
| Other non-current liabilities | 32,930 |  |  | 28,636 |  |
| Total other non-current liabilities | $ | 53,629 |  |  | $ | 53,325 |  |

[0000320193-22-000070:notes:51]
[same as prior period, unchanged from 0000320193-22-000059:notes:51]

[0000320193-22-000070:notes:52]
The following table shows the detail of other income/(expense), net for the three- and nine-month periods ended June 25, 2022 and June 26, 2021 (in millions):

[0000320193-22-000070:notes:53]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25,2022 |  | June 26,2021 |  | June 25,2022 |  | June 26,2021 |
| Interest and dividend income | $ | 722 |  |  | $ | 719 |  |  | $ | 2,072 |  |  | $ | 2,184 |  |
| Interest expense | (719) |  |  | (665) |  |  | (2,104) |  |  | (1,973) |  |
| Other income/(expense), net | (13) |  |  | 189 |  |  | (65) |  |  | 585 |  |
| Total other income/(expense), net | $ | (10) |  |  | $ | 243 |  |  | $ | (97) |  |  | $ | 796 |  |


## us-gaap:DebtDisclosureTextBlock

[0000320193-22-000070:notes:54]
Debt
Commercial Paper

[0000320193-22-000070:notes:55]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of June 25, 2022 and September 25, 2021, the Company had $11.0 billion and $6.0 billion of Commercial Paper outstanding, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the nine months ended June 25, 2022 and June 26, 2021 (in millions):

[0000320193-22-000070:notes:56]
|  | Nine Months Ended |
|  | June 25,2022 |  | June 26,2021 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from commercial paper, net | $ | 4,383 |  |  | $ | 2,745 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 5,731 |  |  | 3,993 |  |
| Repayments of commercial paper | (5,144) |  |  | (3,716) |  |
| Proceeds from commercial paper, net | 587 |  |  | 277 |  |
| Total proceeds from commercial paper, net | $ | 4,970 |  |  | $ | 3,022 |  |

[0000320193-22-000070:notes:57]
Term Debt

[0000320193-22-000070:notes:58]
As of June 25, 2022 and September 25, 2021, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate carrying amount of $108.7 billion and $118.7 billion, respectively (collectively the “Notes”). As of June 25, 2022 and September 25, 2021, the fair value of the Company’s Notes, based on Level 2 inputs, was $101.0 billion and $125.3 billion, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000320193-22-000070:notes:59]
[same as prior period, unchanged from 0000320193-22-000059:notes:59]

[0000320193-22-000070:notes:60]
During the nine months ended June 25, 2022, the Company repurchased 408 million shares of its common stock for $65.0 billion under a share repurchase program authorized by the Board of Directors (the “Program”), including 35 million shares delivered under accelerated share repurchase agreements totaling $6.0 billion that were entered into in November 2021. The Program does not obligate the Company to acquire a minimum amount of shares. Under the Program, shares may be repurchased in privately negotiated and/or open market transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange Act of 1934, as amended.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000320193-22-000070:notes:61]
[same as prior period, unchanged from 0000320193-22-000059:notes:61]

[0000320193-22-000070:notes:62]
A summary of the Company’s restricted stock unit (“RSU”) activity and related information for the nine months ended June 25, 2022 is as follows:

[0000320193-22-000070:notes:63]
|  | Number ofRSUs(in thousands) |  | Weighted-AverageGrant Date FairValue Per RSU |  | AggregateFair Value(in millions) |
| Balance as of September 25, 2021 | 240,427 |  |  | $ | 75.16 |  |  |  |
| RSUs granted | 84,927 |  |  | $ | 150.02 |  |  |  |
| RSUs vested | (109,846) |  |  | $ | 70.96 |  |  |  |
| RSUs canceled | (12,986) |  |  | $ | 98.26 |  |  |  |
| Balance as of June 25, 2022 | 202,522 |  |  | $ | 107.35 |  |  | $ | 28,689 |  |

[0000320193-22-000070:notes:64]
The fair value as of the respective vesting dates of RSUs was $7.8 billion and $17.3 billion for the three- and nine-month periods ended June 25, 2022, respectively, and was $7.9 billion and $17.3 billion for the three- and nine-month periods ended June 26, 2021, respectively.

[0000320193-22-000070:notes:65]
[same as prior period, unchanged from 0000320193-22-000059:notes:65]

[0000320193-22-000070:notes:66]
The following table shows share-based compensation expense and the related income tax benefit included in the Condensed Consolidated Statements of Operations for the three- and nine-month periods ended June 25, 2022 and June 26, 2021 (in millions):

[0000320193-22-000070:notes:67]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25,2022 |  | June 26,2021 |  | June 25,2022 |  | June 26,2021 |
| Share-based compensation expense | $ | 2,243 |  |  | $ | 1,960 |  |  | $ | 6,760 |  |  | $ | 5,961 |  |
| Income tax benefit related to share-based compensation expense | $ | (1,231) |  |  | $ | (1,319) |  |  | $ | (3,416) |  |  | $ | (3,518) |  |

[0000320193-22-000070:notes:68]
As of June 25, 2022, the total unrecognized compensation cost related to outstanding RSUs and stock options was $18.1 billion, which the Company expects to recognize over a weighted-average period of 2.7 years.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000320193-22-000070:notes:69]
Commitments and Contingencies
Accrued Warranty

[0000320193-22-000070:notes:70]
The following table shows changes in the Company’s accrued warranties and related costs for the three- and nine-month periods ended June 25, 2022 and June 26, 2021 (in millions):

[0000320193-22-000070:notes:71]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25,2022 |  | June 26,2021 |  | June 25,2022 |  | June 26,2021 |
| Beginning accrued warranty and related costs | $ | 3,206 |  |  | $ | 3,784 |  |  | $ | 3,364 |  |  | $ | 3,354 |  |
| Cost of warranty claims | (534) |  |  | (636) |  |  | (1,787) |  |  | (2,008) |  |
| Accruals for product warranty | 177 |  |  | 384 |  |  | 1,272 |  |  | 2,186 |  |
| Ending accrued warranty and related costs | $ | 2,849 |  |  | $ | 3,532 |  |  | $ | 2,849 |  |  | $ | 3,532 |  |

[0000320193-22-000070:notes:72]
Contingencies

[0000320193-22-000070:notes:73]
The Company is subject to various legal proceedings and claims that have arisen in the ordinary course of business and that have not been fully resolved. The outcome of litigation is inherently uncertain. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss greater than a recorded accrual, concerning loss contingencies for asserted legal and other claims.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000320193-22-000070:notes:74]
Segment Information and Geographic Data
The following table shows information by reportable segment for the three- and nine-month periods ended June 25, 2022 and June 26, 2021 (in millions):

[0000320193-22-000070:notes:75]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25,2022 |  | June 26,2021 |  | June 25,2022 |  | June 26,2021 |
| Americas: |  |  |  |  |  |  |  |
| Net sales | $ | 37,472 |  |  | $ | 35,870 |  |  | $ | 129,850 |  |  | $ | 116,486 |  |
| Operating income | $ | 13,914 |  |  | $ | 12,916 |  |  | $ | 48,778 |  |  | $ | 40,751 |  |
| Europe: |  |  |  |  |  |  |  |
| Net sales | $ | 19,287 |  |  | $ | 18,943 |  |  | $ | 72,323 |  |  | $ | 68,513 |  |
| Operating income | $ | 7,124 |  |  | $ | 7,085 |  |  | $ | 27,174 |  |  | $ | 24,939 |  |
| Greater China: |  |  |  |  |  |  |  |
| Net sales | $ | 14,604 |  |  | $ | 14,762 |  |  | $ | 58,730 |  |  | $ | 53,803 |  |
| Operating income | $ | 5,760 |  |  | $ | 6,303 |  |  | $ | 25,055 |  |  | $ | 22,591 |  |
| Japan: |  |  |  |  |  |  |  |
| Net sales | $ | 5,446 |  |  | $ | 6,464 |  |  | $ | 20,277 |  |  | $ | 22,491 |  |
| Operating income | $ | 2,418 |  |  | $ | 3,031 |  |  | $ | 9,263 |  |  | $ | 9,962 |  |
| Rest of Asia Pacific: |  |  |  |  |  |  |  |
| Net sales | $ | 6,150 |  |  | $ | 5,395 |  |  | $ | 23,002 |  |  | $ | 21,164 |  |
| Operating income | $ | 2,367 |  |  | $ | 2,116 |  |  | $ | 9,185 |  |  | $ | 7,805 |  |

[0000320193-22-000070:notes:76]
A reconciliation of the Company’s segment operating income to the Condensed Consolidated Statements of Operations for the three- and nine-month periods ended June 25, 2022 and June 26, 2021 is as follows (in millions):

[0000320193-22-000070:notes:77]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25,2022 |  | June 26,2021 |  | June 25,2022 |  | June 26,2021 |
| Segment operating income | $ | 31,583 |  |  | $ | 31,451 |  |  | $ | 119,455 |  |  | $ | 106,048 |  |
| Research and development expense | (6,797) |  |  | (5,717) |  |  | (19,490) |  |  | (16,142) |  |
| Other corporate expenses, net | (1,710) |  |  | (1,608) |  |  | (5,422) |  |  | (4,743) |  |
| Total operating income | $ | 23,076 |  |  | $ | 24,126 |  |  | $ | 94,543 |  |  | $ | 85,163 |  |
