# AAPL MD&A — 0000320193-22-000070


## mdna

[0000320193-22-000070:mdna:1]
[same as prior period, unchanged from 0000320193-22-000059:mdna:1]

[0000320193-22-000070:mdna:2]
[same as prior period, unchanged from 0000320193-22-000059:mdna:2]

[0000320193-22-000070:mdna:3]
[same as prior period, unchanged from 0000320193-22-000059:mdna:3]

[0000320193-22-000070:mdna:4]
[same as prior period, unchanged from 0000320193-22-000059:mdna:4]

[0000320193-22-000070:mdna:5]
[same as prior period, unchanged from 0000320193-22-000059:mdna:5]

[0000320193-22-000070:mdna:6]
[same as prior period, unchanged from 0000320193-22-000059:mdna:6]

[0000320193-22-000070:mdna:7]
[same as prior period, unchanged from 0000320193-22-000059:mdna:7]

[0000320193-22-000070:mdna:8]
[same as prior period, unchanged from 0000320193-22-000059:mdna:8]

[0000320193-22-000070:mdna:9]
Total net sales increased 2% or $1.5 billion during the third quarter of 2022 compared to the same quarter in 2021, driven primarily by higher net sales of Services and iPhone, partially offset by lower net sales of Mac and Wearables, Home and Accessories. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on all Products and Services net sales during the third quarter of 2022.

[0000320193-22-000070:mdna:10]
At the end of the third quarter of 2022, the Company introduced an all-new MacBook Air® and an updated 13-inch MacBook Pro®, both powered by the new Apple M2 chip. The Company also announced iOS 16, macOS® Ventura, iPadOS® 16 and watchOS® 9, updates to its operating systems that are expected to be available in the fall of 2022.

[0000320193-22-000070:mdna:11]
The Company repurchased $21.7 billion of its common stock and paid dividends and dividend equivalents of $3.8 billion during the third quarter of 2022.

[0000320193-22-000070:mdna:12]
COVID-19

[0000320193-22-000070:mdna:13]
The COVID-19 pandemic has had, and continues to have, a significant impact around the world, prompting governments and businesses to take unprecedented measures, such as restrictions on travel and business operations, temporary closures of businesses, and quarantine and shelter-in-place orders. The COVID-19 pandemic has at times significantly curtailed global economic activity and caused significant volatility and disruption in global financial markets. The COVID-19 pandemic and the measures taken by many countries in response have affected and could in the future materially impact the Company’s business, results of operations and financial condition.

[0000320193-22-000070:mdna:14]
Certain of the Company’s outsourcing partners, component suppliers and logistical service providers have experienced disruptions during the COVID-19 pandemic, resulting in supply shortages. Similar disruptions could occur in the future.

[0000320193-22-000070:mdna:15]
[same as prior period, unchanged from 0000320193-22-000059:mdna:21]

[0000320193-22-000070:mdna:16]
The following table shows net sales by category for the three- and nine-month periods ended June 25, 2022 and June 26, 2021 (dollars in millions):

[0000320193-22-000070:mdna:17]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25,2022 |  | June 26,2021 |  | Change |  | June 25,2022 |  | June 26,2021 |  | Change |
| Net sales by category: |  |  |  |  |  |  |  |  |  |  |  |
| iPhone (1) | $ | 40,665 |  |  | $ | 39,570 |  |  | 3 | % |  | $ | 162,863 |  |  | $ | 153,105 |  |  | 6 | % |
| Mac (1) | 7,382 |  |  | 8,235 |  |  | (10) | % |  | 28,669 |  |  | 26,012 |  |  | 10 | % |
| iPad (1) | 7,224 |  |  | 7,368 |  |  | (2) | % |  | 22,118 |  |  | 23,610 |  |  | (6) | % |
| Wearables, Home and Accessories (1)(2) | 8,084 |  |  | 8,775 |  |  | (8) | % |  | 31,591 |  |  | 29,582 |  |  | 7 | % |
| Services (3) | 19,604 |  |  | 17,486 |  |  | 12 | % |  | 58,941 |  |  | 50,148 |  |  | 18 | % |
| Total net sales | $ | 82,959 |  |  | $ | 81,434 |  |  | 2 | % |  | $ | 304,182 |  |  | $ | 282,457 |  |  | 8 | % |

[0000320193-22-000070:mdna:18]
[same as prior period, unchanged from 0000320193-22-000059:mdna:24]

[0000320193-22-000070:mdna:19]
(2)Wearables, Home and Accessories net sales include sales of AirPods, Apple TV, Apple Watch, Beats products, HomePod mini and accessories.

[0000320193-22-000070:mdna:20]
[same as prior period, unchanged from 0000320193-22-000059:mdna:26]

[0000320193-22-000070:mdna:21]
[same as prior period, unchanged from 0000320193-22-000059:mdna:27]

[0000320193-22-000070:mdna:22]
iPhone net sales increased during the third quarter and first nine months of 2022 compared to the same periods in 2021 due primarily to higher net sales from the Company’s new iPhone models.

[0000320193-22-000070:mdna:23]
[same as prior period, unchanged from 0000320193-22-000059:mdna:29]

[0000320193-22-000070:mdna:24]
Mac net sales decreased during the third quarter of 2022 compared to the third quarter of 2021 due primarily to lower net sales of MacBook Air and iMac®, partially offset by higher net sales of MacBook Pro. Year-over-year Mac net sales increased during the first nine months of 2022 due primarily to higher net sales of MacBook Pro, partially offset by lower net sales of MacBook Air.

[0000320193-22-000070:mdna:25]
[same as prior period, unchanged from 0000320193-22-000059:mdna:31]

[0000320193-22-000070:mdna:26]
iPad net sales decreased during the third quarter of 2022 compared to the third quarter of 2021 due primarily to lower net sales of iPad Pro®, partially offset by higher net sales of all other iPad models. Year-over-year iPad net sales decreased during the first nine months of 2022 due primarily to lower net sales of the 10-inch version of iPad and iPad Air®, partially offset by higher net sales of iPad mini®.

[0000320193-22-000070:mdna:27]
[same as prior period, unchanged from 0000320193-22-000059:mdna:33]

[0000320193-22-000070:mdna:28]
Wearables, Home and Accessories net sales decreased during the third quarter of 2022 compared to the third quarter of 2021 due primarily to lower net sales of AirPods and Apple Watch. Year-over-year Wearables, Home and Accessories net sales increased during the first nine months of 2022 due primarily to higher net sales of Apple Watch and AirPods.

[0000320193-22-000070:mdna:29]
[same as prior period, unchanged from 0000320193-22-000059:mdna:35]

[0000320193-22-000070:mdna:30]
Services net sales increased during the third quarter of 2022 compared to the third quarter of 2021 due primarily to higher net sales from advertising, cloud services and AppleCare. Year-over-year Services net sales increased during the first nine months of 2022 due primarily to higher net sales from advertising, the App Store® and cloud services.

[0000320193-22-000070:mdna:31]
[same as prior period, unchanged from 0000320193-22-000059:mdna:37]

[0000320193-22-000070:mdna:32]
[same as prior period, unchanged from 0000320193-22-000059:mdna:38]

[0000320193-22-000070:mdna:33]
The following table shows net sales by reportable segment for the three- and nine-month periods ended June 25, 2022 and June 26, 2021 (dollars in millions):

[0000320193-22-000070:mdna:34]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25,2022 |  | June 26,2021 |  | Change |  | June 25,2022 |  | June 26,2021 |  | Change |
| Net sales by reportable segment: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 37,472 |  |  | $ | 35,870 |  |  | 4 | % |  | $ | 129,850 |  |  | $ | 116,486 |  |  | 11 | % |
| Europe | 19,287 |  |  | 18,943 |  |  | 2 | % |  | 72,323 |  |  | 68,513 |  |  | 6 | % |
| Greater China | 14,604 |  |  | 14,762 |  |  | (1) | % |  | 58,730 |  |  | 53,803 |  |  | 9 | % |
| Japan | 5,446 |  |  | 6,464 |  |  | (16) | % |  | 20,277 |  |  | 22,491 |  |  | (10) | % |
| Rest of Asia Pacific | 6,150 |  |  | 5,395 |  |  | 14 | % |  | 23,002 |  |  | 21,164 |  |  | 9 | % |
| Total net sales | $ | 82,959 |  |  | $ | 81,434 |  |  | 2 | % |  | $ | 304,182 |  |  | $ | 282,457 |  |  | 8 | % |

[0000320193-22-000070:mdna:35]
[same as prior period, unchanged from 0000320193-22-000059:mdna:41]

[0000320193-22-000070:mdna:36]
Americas net sales increased during the third quarter of 2022 compared to the third quarter of 2021 due primarily to higher net sales of Services and iPhone, partially offset by lower net sales of Mac and Wearables, Home and Accessories. Year-over-year Americas net sales increased during the first nine months of 2022 due primarily to higher net sales of iPhone, Services and Wearables, Home and Accessories.

[0000320193-22-000070:mdna:37]
[same as prior period, unchanged from 0000320193-22-000059:mdna:43]

[0000320193-22-000070:mdna:38]
Europe net sales increased during the third quarter of 2022 compared to the third quarter of 2021 due primarily to higher net sales of iPhone, partially offset by lower net sales of Mac. Year-over-year Europe net sales increased during the first nine months of 2022 due primarily to higher net sales of Services and iPhone. The weakness in foreign currencies relative to the U.S. dollar had a net unfavorable impact on Europe net sales during the third quarter and first nine months of 2022.

[0000320193-22-000070:mdna:39]
[same as prior period, unchanged from 0000320193-22-000059:mdna:45]

[0000320193-22-000070:mdna:40]
Greater China net sales decreased during the third quarter of 2022 compared to the third quarter of 2021 due primarily to lower net sales of iPhone, partially offset by higher net sales of Services. Year-over-year Greater China net sales increased during the first nine months of 2022 due primarily to higher net sales of iPhone and Services. The weakness in foreign currencies relative to the U.S. dollar had an unfavorable impact on Greater China net sales during the third quarter of 2022. The strength of the renminbi relative to the U.S. dollar had a favorable impact on Greater China net sales during the first nine months of 2022.

[0000320193-22-000070:mdna:41]
[same as prior period, unchanged from 0000320193-22-000059:mdna:47]

[0000320193-22-000070:mdna:42]
Japan net sales decreased during the third quarter and first nine months of 2022 compared to the same periods in 2021 due primarily to lower net sales of iPhone and iPad. The weakness of the yen relative to the U.S. dollar had an unfavorable impact on Japan net sales during the third quarter and first nine months of 2022.

[0000320193-22-000070:mdna:43]
[same as prior period, unchanged from 0000320193-22-000059:mdna:49]

[0000320193-22-000070:mdna:44]
Rest of Asia Pacific net sales increased during the third quarter of 2022 compared to the third quarter of 2021 due primarily to higher net sales of iPhone and Services. Year-over-year Rest of Asia Pacific net sales increased during the first nine months of 2022 due primarily to higher net sales of Services, iPhone and Mac. The weakness in foreign currencies relative to the U.S. dollar had a net unfavorable impact on Rest of Asia Pacific net sales during the third quarter and first nine months of 2022.

[0000320193-22-000070:mdna:45]
[same as prior period, unchanged from 0000320193-22-000059:mdna:51]

[0000320193-22-000070:mdna:46]
Products and Services gross margin and gross margin percentage for the three- and nine-month periods ended June 25, 2022 and June 26, 2021 were as follows (dollars in millions):

[0000320193-22-000070:mdna:47]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25,2022 |  | June 26,2021 |  | June 25,2022 |  | June 26,2021 |
| Gross margin: |  |  |  |  |  |  |  |
| Products | $ | 21,870 |  |  | $ | 23,049 |  |  | $ | 90,157 |  |  | $ | 82,833 |  |
| Services | 14,015 |  |  | 12,206 |  |  | 42,530 |  |  | 34,829 |  |
| Total gross margin | $ | 35,885 |  |  | $ | 35,255 |  |  | $ | 132,687 |  |  | $ | 117,662 |  |

[0000320193-22-000070:mdna:48]
| Gross margin percentage: |  |  |  |  |  |  |  |
| Products | 34.5 | % |  | 36.0 | % |  | 36.8 | % |  | 35.7 | % |
| Services | 71.5 | % |  | 69.8 | % |  | 72.2 | % |  | 69.5 | % |
| Total gross margin percentage | 43.3 | % |  | 43.3 | % |  | 43.6 | % |  | 41.7 | % |

[0000320193-22-000070:mdna:49]
[same as prior period, unchanged from 0000320193-22-000059:mdna:55]

[0000320193-22-000070:mdna:50]
Products gross margin decreased during the third quarter of 2022 compared to the third quarter of 2021 due primarily to the weakness in foreign currencies relative to the U.S. dollar. Year-over-year Products gross margin increased during the first nine months of 2022 due primarily to a different Products mix and higher Products volume, partially offset by the weakness in foreign currencies relative to the U.S. dollar.

[0000320193-22-000070:mdna:51]
Products gross margin percentage decreased during the third quarter of 2022 compared to the third quarter of 2021 due primarily to the weakness in foreign currencies relative to the U.S. dollar and a different Products mix. Year-over-year Products gross margin percentage increased during the first nine months of 2022 due primarily to a different Products mix.

[0000320193-22-000070:mdna:52]
[same as prior period, unchanged from 0000320193-22-000059:mdna:58]

[0000320193-22-000070:mdna:53]
Services gross margin increased during the third quarter and first nine months of 2022 compared to the same periods in 2021 due primarily to higher Services net sales, partially offset by the weakness in foreign currencies relative to the U.S. dollar.

[0000320193-22-000070:mdna:54]
Services gross margin percentage increased during the third quarter and first nine months of 2022 compared to the same periods in 2021 due primarily to improved leverage and a different Services mix, partially offset by the weakness in foreign currencies relative to the U.S. dollar and higher Services costs.

[0000320193-22-000070:mdna:55]
[same as prior period, unchanged from 0000320193-22-000059:mdna:61]

[0000320193-22-000070:mdna:56]
[same as prior period, unchanged from 0000320193-22-000059:mdna:62]

[0000320193-22-000070:mdna:57]
Operating expenses for the three- and nine-month periods ended June 25, 2022 and June 26, 2021 were as follows (dollars in millions):

[0000320193-22-000070:mdna:58]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25,2022 |  | June 26,2021 |  | June 25,2022 |  | June 26,2021 |
| Research and development | $ | 6,797 |  |  | $ | 5,717 |  |  | $ | 19,490 |  |  | $ | 16,142 |  |
| Percentage of total net sales | 8 | % |  | 7 | % |  | 6 | % |  | 6 | % |
| Selling, general and administrative | $ | 6,012 |  |  | $ | 5,412 |  |  | $ | 18,654 |  |  | $ | 16,357 |  |
| Percentage of total net sales | 7 | % |  | 7 | % |  | 6 | % |  | 6 | % |
| Total operating expenses | $ | 12,809 |  |  | $ | 11,129 |  |  | $ | 38,144 |  |  | $ | 32,499 |  |
| Percentage of total net sales | 15 | % |  | 14 | % |  | 13 | % |  | 12 | % |

[0000320193-22-000070:mdna:59]
[same as prior period, unchanged from 0000320193-22-000059:mdna:65]

[0000320193-22-000070:mdna:60]
The growth in research and development (“R&D”) expense during the third quarter and first nine months of 2022 compared to the same periods in 2021 was driven primarily by increases in headcount-related expenses, engineering program costs and professional services. The Company continues to believe that focused investments in R&D are critical to its future growth and competitive position in the marketplace, and to the development of new and updated products and services that are central to the Company’s core business strategy.

[0000320193-22-000070:mdna:61]
[same as prior period, unchanged from 0000320193-22-000059:mdna:67]

[0000320193-22-000070:mdna:62]
The growth in selling, general and administrative expense during the third quarter and first nine months of 2022 compared to the same periods in 2021 was driven primarily by increases in headcount-related expenses, advertising and professional services.

[0000320193-22-000070:mdna:63]
[same as prior period, unchanged from 0000320193-22-000059:mdna:69]

[0000320193-22-000070:mdna:64]
Other income/(expense), net (“OI&E”) for the three- and nine-month periods ended June 25, 2022 and June 26, 2021 was as follows (dollars in millions):

[0000320193-22-000070:mdna:65]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25,2022 |  | June 26,2021 |  | Change |  | June 25,2022 |  | June 26,2021 |  | Change |
| Interest and dividend income | $ | 722 |  |  | $ | 719 |  |  |  |  | $ | 2,072 |  |  | $ | 2,184 |  |  |  |
| Interest expense | (719) |  |  | (665) |  |  |  |  | (2,104) |  |  | (1,973) |  |  |  |
| Other income/(expense), net | (13) |  |  | 189 |  |  |  |  | (65) |  |  | 585 |  |  |  |
| Total other income/(expense), net | $ | (10) |  |  | $ | 243 |  |  | (104) | % |  | $ | (97) |  |  | $ | 796 |  |  | (112) | % |

[0000320193-22-000070:mdna:66]
OI&E decreased during the third quarter and first nine months of 2022 compared to the same periods in 2021 due primarily to fair value adjustments and realized losses on marketable securities and higher interest expense, partially offset by foreign exchange gains.

[0000320193-22-000070:mdna:67]
[same as prior period, unchanged from 0000320193-22-000059:mdna:73]

[0000320193-22-000070:mdna:68]
Provision for income taxes, effective tax rate and statutory federal income tax rate for the three- and nine-month periods ended June 25, 2022 and June 26, 2021 were as follows (dollars in millions):

[0000320193-22-000070:mdna:69]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25,2022 |  | June 26,2021 |  | June 25,2022 |  | June 26,2021 |
| Provision for income taxes | $ | 3,624 |  |  | $ | 2,625 |  |  | $ | 15,364 |  |  | $ | 11,830 |  |
| Effective tax rate | 15.7 | % |  | 10.8 | % |  | 16.3 | % |  | 13.8 | % |
| Statutory federal income tax rate | 21 | % |  | 21 | % |  | 21 | % |  | 21 | % |

[0000320193-22-000070:mdna:70]
The Company’s effective tax rate for the third quarter and first nine months of 2022 was lower than the statutory federal income tax rate due primarily to a lower effective tax rate on foreign earnings, tax benefits from share-based compensation and the impact of the U.S. federal R&D tax credit, partially offset by state income taxes.

[0000320193-22-000070:mdna:71]
The Company’s effective tax rate for the third quarter of 2022 was higher compared to the third quarter of 2021 due primarily to a higher effective tax rate on foreign earnings and an adjustment to prior years’ foreign-derived intangible income deductions. The Company’s effective tax rate for the first nine months of 2022 was higher compared to the same period in 2021 due primarily to a higher effective tax rate on foreign earnings, lower tax benefits from share-based compensation, and the impact to U.S. foreign tax credits as a result of regulations issued by the U.S. Department of the Treasury in January 2022.

[0000320193-22-000070:mdna:72]
[same as prior period, unchanged from 0000320193-22-000059:mdna:78]

[0000320193-22-000070:mdna:73]
[same as prior period, unchanged from 0000320193-22-000059:mdna:79]

[0000320193-22-000070:mdna:74]
[same as prior period, unchanged from 0000320193-22-000059:mdna:80]

[0000320193-22-000070:mdna:75]
[same as prior period, unchanged from 0000320193-22-000059:mdna:81]

[0000320193-22-000070:mdna:76]
The Company utilizes several outsourcing partners to manufacture subassemblies for the Company’s products and to perform final assembly and testing of finished products. The Company also obtains individual components for its products from a wide variety of individual suppliers. Outsourcing partners acquire components and build product based on demand information supplied by the Company, which typically covers periods up to 150 days. As of June 25, 2022, the Company had manufacturing purchase obligations of $43.1 billion, with $43.0 billion payable within 12 months. The Company’s manufacturing purchase obligations are primarily noncancelable.

[0000320193-22-000070:mdna:77]
In addition to its contractual cash requirements, the Company has a share repurchase program authorized by the Board of Directors (the “Program”). The Program does not obligate the Company to acquire a minimum amount of shares. As of June 25, 2022, the Company’s quarterly cash dividend was $0.23 per share. The Company intends to increase its dividend on an annual basis, subject to declaration by the Board of Directors.

[0000320193-22-000070:mdna:78]
[same as prior period, unchanged from 0000320193-22-000059:mdna:85]

[0000320193-22-000070:mdna:79]
[same as prior period, unchanged from 0000320193-22-000059:mdna:86]
