# AAPL note change history — 0000320193-22-000059 → 0000320193-22-000070


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-07-29):
[0000320193-22-000070:note_history:1]
The following table shows changes in the Company’s accrued warranties and related costs for the three- and nine-month periods ended June 25, 2022 and June 26, 2021 (in millions):
  (was, 2022-04-29, similarity 0.9318):
[0000320193-22-000059:note_history:1]
The following table shows changes in the Company’s accrued warranties and related costs for the three- and six-month periods ended March 26, 2022 and March 27, 2021 (in millions):

- changed (2022-07-29):
[0000320193-22-000070:note_history:2]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25,2022 |  | June 26,2021 |  | June 25,2022 |  | June 26,2021 |
| Beginning accrued warranty and related costs | $ | 3,206 |  |  | $ | 3,784 |  |  | $ | 3,364 |  |  | $ | 3,354 |  |
| Cost of warranty claims | (534) |  |  | (636) |  |  | (1,787) |  |  | (2,008) |  |
| Accruals for product warranty | 177 |  |  | 384 |  |  | 1,272 |  |  | 2,186 |  |
| Ending accrued warranty and related costs | $ | 2,849 |  |  | $ | 3,532 |  |  | $ | 2,849 |  |  | $ | 3,532 |  |
  (was, 2022-04-29, similarity 0.8502):
[0000320193-22-000059:note_history:2]
|  | Three Months Ended |  | Six Months Ended |
|  | March 26,2022 |  | March 27,2021 |  | March 26,2022 |  | March 27,2021 |
| Beginning accrued warranty and related costs | $ | 3,530 |  |  | $ | 4,124 |  |  | $ | 3,364 |  |  | $ | 3,354 |  |
| Cost of warranty claims | (581) |  |  | (649) |  |  | (1,253) |  |  | (1,372) |  |
| Accruals for product warranty | 257 |  |  | 309 |  |  | 1,095 |  |  | 1,802 |  |
| Ending accrued warranty and related costs | $ | 3,206 |  |  | $ | 3,784 |  |  | $ | 3,206 |  |  | $ | 3,784 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-07-29):
[0000320193-22-000070:note_history:3]
The following table shows the computation of basic and diluted earnings per share for the three- and nine-month periods ended June 25, 2022 and June 26, 2021 (net income in millions and shares in thousands):
  (was, 2022-04-29, similarity 0.9418):
[0000320193-22-000059:note_history:3]
The following table shows the computation of basic and diluted earnings per share for the three- and six-month periods ended March 26, 2022 and March 27, 2021 (net income in millions and shares in thousands):

- changed (2022-07-29):
[0000320193-22-000070:note_history:4]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25,2022 |  | June 26,2021 |  | June 25,2022 |  | June 26,2021 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 19,442 |  |  | $ | 21,744 |  |  | $ | 79,082 |  |  | $ | 74,129 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 16,162,945 |  |  | 16,629,371 |  |  | 16,277,824 |  |  | 16,772,656 |  |
| Effect of dilutive securities | 99,258 |  |  | 152,364 |  |  | 117,113 |  |  | 168,871 |  |
| Weighted-average diluted shares | 16,262,203 |  |  | 16,781,735 |  |  | 16,394,937 |  |  | 16,941,527 |  |
| Basic earnings per share | $ | 1.20 |  |  | $ | 1.31 |  |  | $ | 4.86 |  |  | $ | 4.42 |  |
| Diluted earnings per share | $ | 1.20 |  |  | $ | 1.30 |  |  | $ | 4.82 |  |  | $ | 4.38 |  |
  (was, 2022-04-29, similarity 0.8908):
[0000320193-22-000059:note_history:4]
|  | Three Months Ended |  | Six Months Ended |
|  | March 26,2022 |  | March 27,2021 |  | March 26,2022 |  | March 27,2021 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 25,010 |  |  | $ | 23,630 |  |  | $ | 59,640 |  |  | $ | 52,385 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average basic shares outstanding | 16,278,802 |  |  | 16,753,476 |  |  | 16,335,263 |  |  | 16,844,298 |  |
| Effect of dilutive securities | 124,514 |  |  | 175,681 |  |  | 126,041 |  |  | 177,125 |  |
| Weighted-average diluted shares | 16,403,316 |  |  | 16,929,157 |  |  | 16,461,304 |  |  | 17,021,423 |  |
| Basic earnings per share | $ | 1.54 |  |  | $ | 1.41 |  |  | $ | 3.65 |  |  | $ | 3.11 |  |
| Diluted earnings per share | $ | 1.52 |  |  | $ | 1.40 |  |  | $ | 3.62 |  |  | $ | 3.08 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-07-29):
[0000320193-22-000070:note_history:5]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of June 25, 2022 and September 25, 2021, the Company had $11.0 billion and $6.0 billion of Commercial Paper outstanding, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the nine months ended June 25, 2022 and June 26, 2021 (in millions):
  (was, 2022-04-29, similarity 0.9284):
[0000320193-22-000059:note_history:5]
The Company issues unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company uses net proceeds from the commercial paper program for general corporate purposes, including dividends and share repurchases. As of March 26, 2022 and September 25, 2021, the Company had $7.0 billion and $6.0 billion of Commercial Paper outstanding, respectively. The following table provides a summary of cash flows associated with the issuance and maturities of Commercial Paper for the six months ended March 26, 2022 and March 27, 2021 (in millions):

- added (2022-07-29):
[0000320193-22-000070:note_history:6]
|  | Nine Months Ended |
|  | June 25,2022 |  | June 26,2021 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from commercial paper, net | $ | 4,383 |  |  | $ | 2,745 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 5,731 |  |  | 3,993 |  |
| Repayments of commercial paper | (5,144) |  |  | (3,716) |  |
| Proceeds from commercial paper, net | 587 |  |  | 277 |  |
| Total proceeds from commercial paper, net | $ | 4,970 |  |  | $ | 3,022 |  |

- changed (2022-07-29):
[0000320193-22-000070:note_history:7]
As of June 25, 2022 and September 25, 2021, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate carrying amount of $108.7 billion and $118.7 billion, respectively (collectively the “Notes”). As of June 25, 2022 and September 25, 2021, the fair value of the Company’s Notes, based on Level 2 inputs, was $101.0 billion and $125.3 billion, respectively.
  (was, 2022-04-29, similarity 0.9751):
[0000320193-22-000059:note_history:7]
As of March 26, 2022 and September 25, 2021, the Company had outstanding floating- and fixed-rate notes with varying maturities for an aggregate carrying amount of $113.0 billion and $118.7 billion, respectively (collectively the “Notes”). As of March 26, 2022 and September 25, 2021, the fair value of the Company’s Notes, based on Level 2 inputs, was $110.5 billion and $125.3 billion, respectively.

- removed (2022-07-29):
[0000320193-22-000059:note_history:8]
|  | Six Months Ended |
|  | March 26,2022 |  | March 27,2021 |
| Maturities 90 days or less: |  |  |  |
| Proceeds from commercial paper, net | $ | 4,952 |  |  | $ | 2,008 |  |
| Maturities greater than 90 days: |  |  |  |
| Proceeds from commercial paper | 1,191 |  |  | 1,368 |  |
| Repayments of commercial paper | (5,144) |  |  | (3,354) |  |
| Repayments of commercial paper, net | (3,953) |  |  | (1,986) |  |
| Total proceeds from commercial paper, net | $ | 999 |  |  | $ | 22 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-07-29):
[0000320193-22-000070:note_history:9]
Net sales disaggregated by significant products and services for the three- and nine-month periods ended June 25, 2022 and June 26, 2021 were as follows (in millions):
  (was, 2022-04-29, similarity 0.927):
[0000320193-22-000059:note_history:9]
Net sales disaggregated by significant products and services for the three- and six-month periods ended March 26, 2022 and March 27, 2021 were as follows (in millions):

- changed (2022-07-29):
[0000320193-22-000070:note_history:10]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25,2022 |  | June 26,2021 |  | June 25,2022 |  | June 26,2021 |
| iPhone® (1) | $ | 40,665 |  |  | $ | 39,570 |  |  | $ | 162,863 |  |  | $ | 153,105 |  |
| Mac® (1) | 7,382 |  |  | 8,235 |  |  | 28,669 |  |  | 26,012 |  |
| iPad® (1) | 7,224 |  |  | 7,368 |  |  | 22,118 |  |  | 23,610 |  |
| Wearables, Home and Accessories (1)(2) | 8,084 |  |  | 8,775 |  |  | 31,591 |  |  | 29,582 |  |
| Services (3) | 19,604 |  |  | 17,486 |  |  | 58,941 |  |  | 50,148 |  |
| Total net sales (4) | $ | 82,959 |  |  | $ | 81,434 |  |  | $ | 304,182 |  |  | $ | 282,457 |  |
  (was, 2022-04-29, similarity 0.8578):
[0000320193-22-000059:note_history:10]
|  | Three Months Ended |  | Six Months Ended |
|  | March 26,2022 |  | March 27,2021 |  | March 26,2022 |  | March 27,2021 |
| iPhone® (1) | $ | 50,570 |  |  | $ | 47,938 |  |  | $ | 122,198 |  |  | $ | 113,535 |  |
| Mac® (1) | 10,435 |  |  | 9,102 |  |  | 21,287 |  |  | 17,777 |  |
| iPad® (1) | 7,646 |  |  | 7,807 |  |  | 14,894 |  |  | 16,242 |  |
| Wearables, Home and Accessories (1)(2) | 8,806 |  |  | 7,836 |  |  | 23,507 |  |  | 20,807 |  |
| Services (3) | 19,821 |  |  | 16,901 |  |  | 39,337 |  |  | 32,662 |  |
| Total net sales (4) | $ | 97,278 |  |  | $ | 89,584 |  |  | $ | 221,223 |  |  | $ | 201,023 |  |

- changed (2022-07-29):
[0000320193-22-000070:note_history:11]
(2)Wearables, Home and Accessories net sales include sales of AirPods®, Apple TV®, Apple Watch®, Beats® products, HomePod mini® and accessories.
  (was, 2022-04-29, similarity 0.9568):
[0000320193-22-000059:note_history:11]
(2)Wearables, Home and Accessories net sales include sales of AirPods®, Apple TV®, Apple Watch®, Beats® products, HomePod mini®, iPod touch® and accessories.

- changed (2022-07-29):
[0000320193-22-000070:note_history:12]
(4)Includes $3.1 billion of revenue recognized in the three months ended June 25, 2022 that was included in deferred revenue as of March 26, 2022, $3.0 billion of revenue recognized in the three months ended June 26, 2021 that was included in deferred revenue as of March 27, 2021, $6.3 billion of revenue recognized in the nine months ended June 25, 2022 that was included in deferred revenue as of September 25, 2021, and $5.5 billion of revenue recognized in the nine months ended June 26, 2021 that was included in deferred revenue as of September 26, 2020.
  (was, 2022-04-29, similarity 0.8713):
[0000320193-22-000059:note_history:12]
(4)Includes $3.0 billion of revenue recognized in the three months ended March 26, 2022 that was included in deferred revenue as of December 25, 2021, $2.7 billion of revenue recognized in the three months ended March 27, 2021 that was included in deferred revenue as of December 26, 2020, $4.8 billion of revenue recognized in the six months ended March 26, 2022 that was included in deferred revenue as of September 25, 2021, and $4.1 billion of revenue recognized in the six months ended March 27, 2021 that was included in deferred revenue as of September 26, 2020.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-07-29):
[0000320193-22-000070:note_history:13]
Revenue
Net sales disaggregated by significant products and services for the three- and nine-month periods ended June 25, 2022 and June 26, 2021 were as follows (in millions):
  (was, 2022-04-29, similarity 0.9305):
[0000320193-22-000059:note_history:13]
Revenue
Net sales disaggregated by significant products and services for the three- and six-month periods ended March 26, 2022 and March 27, 2021 were as follows (in millions):

- changed (2022-07-29):
[0000320193-22-000070:note_history:14]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25,2022 |  | June 26,2021 |  | June 25,2022 |  | June 26,2021 |
| iPhone® (1) | $ | 40,665 |  |  | $ | 39,570 |  |  | $ | 162,863 |  |  | $ | 153,105 |  |
| Mac® (1) | 7,382 |  |  | 8,235 |  |  | 28,669 |  |  | 26,012 |  |
| iPad® (1) | 7,224 |  |  | 7,368 |  |  | 22,118 |  |  | 23,610 |  |
| Wearables, Home and Accessories (1)(2) | 8,084 |  |  | 8,775 |  |  | 31,591 |  |  | 29,582 |  |
| Services (3) | 19,604 |  |  | 17,486 |  |  | 58,941 |  |  | 50,148 |  |
| Total net sales (4) | $ | 82,959 |  |  | $ | 81,434 |  |  | $ | 304,182 |  |  | $ | 282,457 |  |
  (was, 2022-04-29, similarity 0.8578):
[0000320193-22-000059:note_history:14]
|  | Three Months Ended |  | Six Months Ended |
|  | March 26,2022 |  | March 27,2021 |  | March 26,2022 |  | March 27,2021 |
| iPhone® (1) | $ | 50,570 |  |  | $ | 47,938 |  |  | $ | 122,198 |  |  | $ | 113,535 |  |
| Mac® (1) | 10,435 |  |  | 9,102 |  |  | 21,287 |  |  | 17,777 |  |
| iPad® (1) | 7,646 |  |  | 7,807 |  |  | 14,894 |  |  | 16,242 |  |
| Wearables, Home and Accessories (1)(2) | 8,806 |  |  | 7,836 |  |  | 23,507 |  |  | 20,807 |  |
| Services (3) | 19,821 |  |  | 16,901 |  |  | 39,337 |  |  | 32,662 |  |
| Total net sales (4) | $ | 97,278 |  |  | $ | 89,584 |  |  | $ | 221,223 |  |  | $ | 201,023 |  |

- changed (2022-07-29):
[0000320193-22-000070:note_history:15]
(2)Wearables, Home and Accessories net sales include sales of AirPods®, Apple TV®, Apple Watch®, Beats® products, HomePod mini® and accessories.
  (was, 2022-04-29, similarity 0.9568):
[0000320193-22-000059:note_history:15]
(2)Wearables, Home and Accessories net sales include sales of AirPods®, Apple TV®, Apple Watch®, Beats® products, HomePod mini®, iPod touch® and accessories.

- changed (2022-07-29):
[0000320193-22-000070:note_history:16]
(4)Includes $3.1 billion of revenue recognized in the three months ended June 25, 2022 that was included in deferred revenue as of March 26, 2022, $3.0 billion of revenue recognized in the three months ended June 26, 2021 that was included in deferred revenue as of March 27, 2021, $6.3 billion of revenue recognized in the nine months ended June 25, 2022 that was included in deferred revenue as of September 25, 2021, and $5.5 billion of revenue recognized in the nine months ended June 26, 2021 that was included in deferred revenue as of September 26, 2020.
  (was, 2022-04-29, similarity 0.8713):
[0000320193-22-000059:note_history:16]
(4)Includes $3.0 billion of revenue recognized in the three months ended March 26, 2022 that was included in deferred revenue as of December 25, 2021, $2.7 billion of revenue recognized in the three months ended March 27, 2021 that was included in deferred revenue as of December 26, 2020, $4.8 billion of revenue recognized in the six months ended March 26, 2022 that was included in deferred revenue as of September 25, 2021, and $4.1 billion of revenue recognized in the six months ended March 27, 2021 that was included in deferred revenue as of September 26, 2020.

- changed (2022-07-29):
[0000320193-22-000070:note_history:17]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 9, “Segment Information and Geographic Data” for the three- and nine-month periods ended June 25, 2022 and June 26, 2021, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.
  (was, 2022-04-29, similarity 0.7977):
[0000320193-22-000059:note_history:17]
The Company’s proportion of net sales by disaggregated revenue source was generally consistent for each reportable segment in Note 9, “Segment Information and Geographic Data” for the three- and six-month periods ended March 26, 2022 and March 27, 2021, except in Greater China, where iPhone revenue represented a moderately higher proportion of net sales.

- added (2022-07-29):
[0000320193-22-000070:note_history:18]
As of June 25, 2022 and September 25, 2021, the Company had total deferred revenue of $12.2 billion and $11.9 billion, respectively. As of June 25, 2022, the Company expects 63% of total deferred revenue to be realized in less than a year, 27% within one-to-two years, 8% within two-to-three years and 2% in greater than three years.

- removed (2022-07-29):
[0000320193-22-000059:note_history:19]
As of March 26, 2022 and September 25, 2021, the Company had total deferred revenue of $12.5 billion and $11.9 billion, respectively. As of March 26, 2022, the Company expects 63% of total deferred revenue to be realized in less than a year, 27% within one-to-two years, 8% within two-to-three years and 2% in greater than three years.
