# AAPL notes — 0001193125-15-259935


## us-gaap:ScheduleOfDerivativeInstrumentsInStatementOfFinancialPositionFairValueTextBlock

[0001193125-15-259935:notes:1]
The following tables show the Company’s
 derivative instruments at gross fair value as of June 27, 2015
 and September 27, 2014 (in millions):

[0001193125-15-259935:notes:2]
|  |  | June 27, 2015 |  |
|  |  | Fair Value of Derivatives Designated as Hedge Instruments |  |  | Fair Value of Derivatives Not Designated as Hedge Instruments |  |  | Total Fair Value |  |
| Derivative assets (1): |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 1,747 |  |  | $ | 29 |  |  | $ | 1,776 |  |
| Interest rate contracts |  | $ | 160 |  |  | $ | 0 |  |  | $ | 160 |  |
| Derivative liabilities (2): |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 120 |  |  | $ | 58 |  |  | $ | 178 |  |
| Interest rate contracts |  | $ | 533 |  |  | $ | 0 |  |  | $ | 533 |  |
|  |  | September 27, 2014 |  |
|  |  | Fair Value of Derivatives Designated as Hedge Instruments |  |  | Fair Value of Derivatives Not Designated as Hedge Instruments |  |  | Total Fair Value |  |
| Derivative assets (1): |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 1,332 |  |  | $ | 222 |  |  | $ | 1,554 |  |
| Interest rate contracts |  | $ | 81 |  |  | $ | 0 |  |  | $ | 81 |  |
| Derivative liabilities (2): |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 41 |  |  | $ | 40 |  |  | $ | 81 |  |

[0001193125-15-259935:notes:3]
[same as prior period, unchanged from 0001193125-15-153166:notes:61]

[0001193125-15-259935:notes:4]
[same as prior period, unchanged from 0001193125-15-153166:notes:62]


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001193125-15-259935:notes:5]
A reconciliation of the Company’s segment
 operating income to the Condensed Consolidated Statements of
 Operations for the three- and nine-month periods ended
 June 27, 2015 and June 28, 2014 is as follows (in
 millions):

[0001193125-15-259935:notes:6]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 27, 2015 |  |  | June 28, 2014 |  |  | June 27, 2015 |  |  | June 28, 2014 |  |
| Segment operating income |  | $ | 17,200 |  |  | $ | 12,788 |  |  | $ | 65,797 |  |  | $ | 48,336 |  |
| Research and development expense |  |  | (2,034 | ) |  |  | (1,603 | ) |  |  | (5,847 | ) |  |  | (4,355 | ) |
| Other corporate expenses, net |  |  | (1,083 | ) |  |  | (903 | ) |  |  | (3,343 | ) |  |  | (2,643 | ) |
| Total operating income |  | $ | 14,083 |  |  | $ | 10,282 |  |  | $ | 56,607 |  |  | $ | 41,338 |  |


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001193125-15-259935:notes:7]
The following table shows the computation of basic
 and diluted earnings per share for the three- and nine-month
 periods ended June 27, 2015 and June 28, 2014 (net income
 in millions and shares in thousands):

[0001193125-15-259935:notes:8]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 27, 2015 |  |  | June 28, 2014 |  |  | June 27, 2015 |  |  | June 28, 2014 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 10,677 |  |  | $ | 7,748 |  |  | $ | 42,270 |  |  | $ | 31,043 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding |  |  | 5,729,886 |  |  |  | 6,012,635 |  |  |  | 5,788,922 |  |  |  | 6,136,147 |  |
| Effect of dilutive securities |  |  | 43,213 |  |  |  | 39,076 |  |  |  | 40,998 |  |  |  | 36,710 |  |
| Weighted-average diluted shares |  |  | 5,773,099 |  |  |  | 6,051,711 |  |  |  | 5,829,920 |  |  |  | 6,172,857 |  |
| Basic earnings per share |  | $ | 1.86 |  |  | $ | 1.29 |  |  | $ | 7.30 |  |  | $ | 5.06 |  |
| Diluted earnings per share |  | $ | 1.85 |  |  | $ | 1.28 |  |  | $ | 7.25 |  |  | $ | 5.03 |  |


## us-gaap:DebtDisclosureTextBlock

[0001193125-15-259935:notes:9]
Note 6 – Debt

[0001193125-15-259935:notes:10]
Commercial Paper

[0001193125-15-259935:notes:11]
In 2014, the Board of Directors authorized the
 Company to issue unsecured short-term promissory notes
 (“Commercial Paper”) pursuant to a commercial paper
 program. The Company intends to use net proceeds from the
 commercial paper program for general corporate purposes, including
 dividends and share repurchases. As of June 27, 2015 and
 September 27, 2014, the Company had $4.5 billion and $6.3
 billion of Commercial Paper outstanding, respectively, with a
 weighted-average interest rate of 0.10% and 0.12%, respectively,
 and maturities generally less than nine months.

[0001193125-15-259935:notes:12]
The following table provides a summary of cash
 flows associated with the issuance and maturities of Commercial
 Paper for the nine months ended June 27, 2015 (in
 millions):

[0001193125-15-259935:notes:13]
| Maturities less than 90 days: |  |  |  |  |
| Proceeds from (repayments of) commercial paper, net |  | $ | 579 |  |
| Maturities greater than 90 days: |  |  |  |  |
| Proceeds from commercial paper |  |  | 2,601 |  |
| Repayments of commercial paper |  |  | (4,988 | ) |
| Maturities greater than 90 days, net |  |  | (2,387 | ) |
| Total change in commercial paper, net |  | $ | (1,808 | ) |

[0001193125-15-259935:notes:14]
Long-Term Debt

[0001193125-15-259935:notes:15]
As of June 27, 2015, the Company has
 outstanding floating- and fixed-rate notes with varying maturities
 for an aggregate principal amount of $50.0 billion (collectively
 the “Notes”). The Notes are senior unsecured
 obligations, and interest is payable in arrears, quarterly for the
 U.S. dollar-denominated floating-rate notes, semi-annually for the
 U.S. dollar- and yen-denominated fixed-rate notes and annually for
 the euro- and Swiss franc-denominated fixed-rate notes. The
 following table provides a summary of the Company’s long-term
 debt as of June 27, 2015 and September 27, 2014:

[0001193125-15-259935:notes:16]
|  |  | Maturities |  |  | June 27, 2015 |  |  | September 27, 2014 |  |
|  |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2016 - 2018 |  |  | $ | 3,000 |  |  |  | 0.51% - 1.10% |  |  | $ | 3,000 |  |  |  | 0.51% - 1.10% |  |
| Fixed-rate 0.45% - 3.85% notes |  |  | 2016 - 2043 |  |  |  | 14,000 |  |  |  | 0.51% - 3.91% |  |  |  | 14,000 |  |  |  | 0.51% - 3.91% |  |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2017 - 2019 |  |  |  | 2,000 |  |  |  | 0.35% - 0.58% |  |  |  | 2,000 |  |  |  | 0.31% - 0.54% |  |
| Fixed-rate 1.05% - 4.45% notes |  |  | 2017 - 2044 |  |  |  | 10,000 |  |  |  | 0.34% - 4.48% |  |  |  | 10,000 |  |  |  | 0.30% - 4.48% |  |
| First quarter 2015 euro-denominated debt issuance of €2.8 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 1.00% notes |  |  | 2022 |  |  |  | 1,567 |  |  |  | 2.94% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 1.63% notes |  |  | 2026 |  |  |  | 1,567 |  |  |  | 3.45% |  |  |  | 0 |  |  |  | 0 |  |
| Second quarter 2015 debt issuance of $6.5 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2020 |  |  |  | 500 |  |  |  | 0.53% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 1.55% notes |  |  | 2020 |  |  |  | 1,250 |  |  |  | 0.53% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.15% notes |  |  | 2022 |  |  |  | 1,250 |  |  |  | 0.84% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.50% notes |  |  | 2025 |  |  |  | 1,500 |  |  |  | 2.60% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 3.45% notes |  |  | 2045 |  |  |  | 2,000 |  |  |  | 3.58% |  |  |  | 0 |  |  |  | 0 |  |
| Second quarter 2015 Swiss franc-denominated debt issuance of SFr1.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.38% notes |  |  | 2024 |  |  |  | 939 |  |  |  | 0.28% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 0.75% notes |  |  | 2030 |  |  |  | 403 |  |  |  | 0.74% |  |  |  | 0 |  |  |  | 0 |  |
| Third quarter 2015 debt issuance of $8.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2017 |  |  |  | 250 |  |  |  | 0.33% |  |  |  | 0 |  |  |  | 0 |  |
| Floating-rate notes |  |  | 2020 |  |  |  | 500 |  |  |  | 0.58% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 0.90% notes |  |  | 2017 |  |  |  | 750 |  |  |  | 0.32% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.00% notes |  |  | 2020 |  |  |  | 1,250 |  |  |  | 0.57% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.70% notes |  |  | 2022 |  |  |  | 1,250 |  |  |  | 0.95% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 3.20% notes |  |  | 2025 |  |  |  | 2,000 |  |  |  | 1.18% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 4.38% notes |  |  | 2045 |  |  |  | 2,000 |  |  |  | 4.40% |  |  |  | 0 |  |  |  | 0 |  |
| Third quarter 2015 yen-denominated debt issuance of ¥250.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.35% notes |  |  | 2020 |  |  |  | 2,016 |  |  |  | 0.35% |  |  |  | 0 |  |  |  | 0 |  |
| Total borrowings |  |  |  |  |  |  | 49,992 |  |  |  |  |  |  |  | 29,000 |  |  |  |  |  |
| Unamortized discount |  |  |  |  |  |  | (97 | ) |  |  |  |  |  |  | (52 | ) |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  |  |  | 24 |  |  |  |  |  |  |  | 39 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | (2,500 | ) |  |  |  |  |  |  | 0 |  |  |  |  |  |
| Total long-term debt |  |  |  |  |  | $ | 47,419 |  |  |  |  |  |  | $ | 28,987 |  |  |  |  |  |

[0001193125-15-259935:notes:17]
To manage foreign currency risk associated with the
 euro-denominated notes issued in the first quarter of 2015, the
 Company entered into currency swaps with an aggregate notional
 amount of $3.5 billion, which effectively converted the
 euro-denominated notes to U.S. dollar-denominated notes.

[0001193125-15-259935:notes:18]
To manage interest rate risk on the U.S.
 dollar-denominated fixed-rate notes issued in the second quarter of
 2015 and maturing in 2020 and 2022, the Company entered into
 interest rate swaps with an aggregate notional amount of $2.5
 billion. To manage interest rate risk on the U.S.
 dollar-denominated fixed-rate notes issued in the third quarter of
 2015 and maturing in 2017, 2020, 2022 and 2025, the Company entered
 into interest rate swaps with an aggregate notional amount of $4.3
 billion. These interest rate swaps effectively converted the fixed
 interest rates on the U.S. dollar-denominated notes to a floating
 interest rate.

[0001193125-15-259935:notes:19]
During the third quarter of 2015, the Company
 designated ¥212.4 billion of the ¥250.0 billion of
 yen-denominated notes as a hedge of the foreign currency exposure
 of its net investment in a foreign operation. As a result, the
 foreign currency transaction gain or loss on the portion of the
 yen-denominated debt designated as a hedge is recorded in OCI as a
 part of the cumulative translation adjustment. As of June 27,
 2015, the carrying value of the debt designated as a net investment
 hedge was $1.7 billion.

[0001193125-15-259935:notes:20]
For further discussion regarding the
 Company’s use of derivative instruments see the Derivative
 Financial Instruments section of Note 2, “Financial
 Instruments.”

[0001193125-15-259935:notes:21]
The effective interest rates for the Notes include
 the interest on the Notes, amortization of the discount and, if
 applicable, adjustments related to hedging. The Company recognized
 $197 million and $486 million of interest expense on its long-term
 debt for the three- and nine-month periods ended June 27,
 2015, respectively. The Company recognized $100 million and $268
 million of interest expense on its long-term debt for the three-
 and nine-month periods ended June 28, 2014, respectively.

[0001193125-15-259935:notes:22]
Future principal payments for the Company’s
 Notes as of June 27, 2015 are as follows (in millions):

[0001193125-15-259935:notes:23]
| 2015 |  | $ | 0 |  |
| 2016 |  |  | 2,500 |  |
| 2017 |  |  | 3,500 |  |
| 2018 |  |  | 6,000 |  |
| 2019 |  |  | 3,000 |  |
| Thereafter |  |  | 34,992 |  |
| Total future principal payments |  | $ | 49,992 |  |

[0001193125-15-259935:notes:24]
As of June 27, 2015 and September 27,
 2014, the fair value of the Company’s Notes, based on Level 2
 inputs, was $48.7 billion and $28.5 billion, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-15-259935:notes:25]
[same as prior period, unchanged from 0001193125-15-153166:notes:65]

[0001193125-15-259935:notes:26]
[same as prior period, unchanged from 0001193125-15-153166:notes:66]

[0001193125-15-259935:notes:27]
[same as prior period, unchanged from 0001193125-15-153166:notes:67]

[0001193125-15-259935:notes:28]
[same as prior period, unchanged from 0001193125-15-153166:notes:68]

[0001193125-15-259935:notes:29]
The following table shows information by operating
 segment for the three- and nine-month periods ended June 27,
 2015 and June 28, 2014 (in millions):

[0001193125-15-259935:notes:30]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 27, 2015 |  |  | June 28, 2014 |  |  | June 27, 2015 |  |  | June 28, 2014 |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 20,209 |  |  | $ | 17,574 |  |  | $ | 72,091 |  |  | $ | 60,345 |  |
| Operating income |  | $ | 6,177 |  |  | $ | 5,932 |  |  | $ | 24,064 |  |  | $ | 20,030 |  |
| Europe: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 10,342 |  |  | $ | 8,659 |  |  | $ | 39,760 |  |  | $ | 33,935 |  |
| Operating income |  | $ | 3,275 |  |  | $ | 2,855 |  |  | $ | 13,269 |  |  | $ | 11,083 |  |
| Greater China: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 13,230 |  |  | $ | 6,230 |  |  | $ | 46,197 |  |  | $ | 25,561 |  |
| Operating income |  | $ | 5,147 |  |  | $ | 2,081 |  |  | $ | 18,227 |  |  | $ | 8,869 |  |
| Japan: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 2,872 |  |  | $ | 2,627 |  |  | $ | 11,777 |  |  | $ | 11,719 |  |
| Operating income |  | $ | 1,447 |  |  | $ | 1,214 |  |  | $ | 5,634 |  |  | $ | 5,376 |  |
| Rest of Asia Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 2,952 |  |  | $ | 2,342 |  |  | $ | 12,389 |  |  | $ | 9,112 |  |
| Operating income |  | $ | 1,154 |  |  | $ | 706 |  |  | $ | 4,603 |  |  | $ | 2,978 |  |


## us-gaap:AcceleratedShareRepurchasesTextBlock

[0001193125-15-259935:notes:31]
The following table shows the Company’s ASR
 activity and related information during the nine months ended
 June 27, 2015 and the year ended September 27, 2014:

[0001193125-15-259935:notes:32]
|  |  | Purchase Period End Date |  | Number of Shares(in thousands) |  | Average Repurchase Price Per Share |  | ASR Amount(in millions) |
| May 2015 ASR |  |  | November 2015 |  |  |  | 38,320 (1) |  |  |  | (1) |  |  | $ | 6,000 |  |
| August 2014 ASR |  |  | February 2015 |  |  |  | 81,525 (2) |  |  | $ | 110.40 |  |  | $ | 9,000 |  |
| January 2014 ASR |  |  | December 2014 |  |  |  | 134,247 |  |  | $ | 89.39 |  |  | $ | 12,000 |  |
| April 2013 ASR |  |  | March 2014 |  |  |  | 172,548 |  |  | $ | 69.55 |  |  | $ | 12,000 |  |

[0001193125-15-259935:notes:33]
|  | (1) | The number of shares represents shares delivered in the third quarter of 2015 and does not represent the final number of shares to be delivered under the May 2015 ASR. The total number of shares ultimately delivered under the May 2015 ASR, and therefore the average repurchase price paid per share, will be determined at the end of the applicable purchase period based on the volume weighted-average price of the Company’s common stock during that period. The May 2015 ASR purchase period will end in or before November 2015. |  |

[0001193125-15-259935:notes:34]
|  | (2) | Includes 59.9 million shares delivered and retired at the beginning of the purchase period, which began in the fourth quarter of 2014, 8.3 million net shares delivered and retired in the first quarter of 2015 and 13.3 million shares delivered and retired at the end of the purchase period, which concluded in the second quarter of 2015. |  |


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001193125-15-259935:notes:35]
[same as prior period, unchanged from 0001193125-15-153166:notes:114]

[0001193125-15-259935:notes:36]
|  |  | June 27, 2015 |  |  | September 27, 2014 |  |
| Accrued warranty and related costs |  | $ | 5,137 |  |  | $ | 4,159 |  |
| Accrued marketing and selling expenses |  |  | 1,651 |  |  |  | 2,321 |  |
| Accrued taxes |  |  | 1,566 |  |  |  | 1,209 |  |
| Accrued compensation and employee benefits |  |  | 1,551 |  |  |  | 1,209 |  |
| Deferred margin on component sales |  |  | 1,369 |  |  |  | 1,057 |  |
| Other current liabilities |  |  | 11,450 |  |  |  | 8,498 |  |
| Total accrued expenses |  | $ | 22,724 |  |  | $ | 18,453 |  |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001193125-15-259935:notes:37]
The following tables show the Company’s cash
 and available-for-sale securities’ adjusted
 cost, gross unrealized gains, gross unrealized losses and fair
 value by significant investment category recorded as cash and cash
 equivalents or short- or long-term marketable securities as of
 June 27, 2015 and September 27, 2014 (in millions):

[0001193125-15-259935:notes:38]
|  |  | June 27, 2015 |  |
|  |  | Adjusted Cost |  |  | Unrealized Gains |  |  | Unrealized Losses |  |  | Fair Value |  |  | Cash and Cash Equivalents |  |  | Short-Term Marketable Securities |  |  | Long-Term Marketable Securities |  |
| Cash |  | $ | 10,451 |  |  | $ | 0 |  |  | $ | 0 |  |  | $ | 10,451 |  |  | $ | 10,451 |  |  | $ | 0 |  |  | $ | 0 |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  |  | 1,007 |  |  |  | 0 |  |  |  | 0 |  |  |  | 1,007 |  |  |  | 1,007 |  |  |  | 0 |  |  |  | 0 |  |
| Mutual funds |  |  | 2,100 |  |  |  | 0 |  |  |  | (163 | ) |  |  | 1,937 |  |  |  | 0 |  |  |  | 1,937 |  |  |  | 0 |  |
| Subtotal |  |  | 3,107 |  |  |  | 0 |  |  |  | (163 | ) |  |  | 2,944 |  |  |  | 1,007 |  |  |  | 1,937 |  |  |  | 0 |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities |  |  | 41,788 |  |  |  | 76 |  |  |  | (50 | ) |  |  | 41,814 |  |  |  | 68 |  |  |  | 1,379 |  |  |  | 40,367 |  |
| U.S. agency securities |  |  | 5,719 |  |  |  | 8 |  |  |  | (2 | ) |  |  | 5,725 |  |  |  | 683 |  |  |  | 580 |  |  |  | 4,462 |  |
| Non-U.S. government securities |  |  | 6,662 |  |  |  | 46 |  |  |  | (105 | ) |  |  | 6,603 |  |  |  | 7 |  |  |  | 219 |  |  |  | 6,377 |  |
| Certificates of deposit and time deposits |  |  | 4,367 |  |  |  | 0 |  |  |  | 0 |  |  |  | 4,367 |  |  |  | 1,939 |  |  |  | 1,439 |  |  |  | 989 |  |
| Commercial paper |  |  | 2,997 |  |  |  | 0 |  |  |  | 0 |  |  |  | 2,997 |  |  |  | 1,133 |  |  |  | 1,864 |  |  |  | 0 |  |
| Corporate securities |  |  | 111,128 |  |  |  | 227 |  |  |  | (514 | ) |  |  | 110,841 |  |  |  | 31 |  |  |  | 11,885 |  |  |  | 98,925 |  |
| Municipal securities |  |  | 945 |  |  |  | 3 |  |  |  | (2 | ) |  |  | 946 |  |  |  | 0 |  |  |  | 43 |  |  |  | 903 |  |
| Mortgage- and asset-backed securities |  |  | 16,191 |  |  |  | 35 |  |  |  | (66 | ) |  |  | 16,160 |  |  |  | 0 |  |  |  | 38 |  |  |  | 16,122 |  |
| Subtotal |  |  | 189,797 |  |  |  | 395 |  |  |  | (739 | ) |  |  | 189,453 |  |  |  | 3,861 |  |  |  | 17,447 |  |  |  | 168,145 |  |
| Total |  | $ | 203,355 |  |  | $ | 395 |  |  | $ | (902 | ) |  | $ | 202,848 |  |  | $ | 15,319 |  |  | $ | 19,384 |  |  | $ | 168,145 |  |
|  |  | September 27, 2014 |  |
|  |  | Adjusted Cost |  |  | Unrealized Gains |  |  | Unrealized Losses |  |  | Fair Value |  |  | Cash and Cash Equivalents |  |  | Short-Term Marketable Securities |  |  | Long-Term Marketable Securities |  |
| Cash |  | $ | 10,232 |  |  | $ | 0 |  |  | $ | 0 |  |  | $ | 10,232 |  |  | $ | 10,232 |  |  | $ | 0 |  |  | $ | 0 |  |
| Level 1 (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  |  | 1,546 |  |  |  | 0 |  |  |  | 0 |  |  |  | 1,546 |  |  |  | 1,546 |  |  |  | 0 |  |  |  | 0 |  |
| Mutual funds |  |  | 2,531 |  |  |  | 1 |  |  |  | (132 | ) |  |  | 2,400 |  |  |  | 0 |  |  |  | 2,400 |  |  |  | 0 |  |
| Subtotal |  |  | 4,077 |  |  |  | 1 |  |  |  | (132 | ) |  |  | 3,946 |  |  |  | 1,546 |  |  |  | 2,400 |  |  |  | 0 |  |
| Level 2 (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Treasury securities |  |  | 23,140 |  |  |  | 15 |  |  |  | (9 | ) |  |  | 23,146 |  |  |  | 12 |  |  |  | 607 |  |  |  | 22,527 |  |
| U.S. agency securities |  |  | 7,373 |  |  |  | 3 |  |  |  | (11 | ) |  |  | 7,365 |  |  |  | 652 |  |  |  | 157 |  |  |  | 6,556 |  |
| Non-U.S. government securities |  |  | 6,925 |  |  |  | 69 |  |  |  | (69 | ) |  |  | 6,925 |  |  |  | 0 |  |  |  | 204 |  |  |  | 6,721 |  |
| Certificates of deposit and time deposits |  |  | 3,832 |  |  |  | 0 |  |  |  | 0 |  |  |  | 3,832 |  |  |  | 1,230 |  |  |  | 1,233 |  |  |  | 1,369 |  |
| Commercial paper |  |  | 475 |  |  |  | 0 |  |  |  | 0 |  |  |  | 475 |  |  |  | 166 |  |  |  | 309 |  |  |  | 0 |  |
| Corporate securities |  |  | 85,431 |  |  |  | 296 |  |  |  | (241 | ) |  |  | 85,486 |  |  |  | 6 |  |  |  | 6,298 |  |  |  | 79,182 |  |
| Municipal securities |  |  | 940 |  |  |  | 8 |  |  |  | 0 |  |  |  | 948 |  |  |  | 0 |  |  |  | 0 |  |  |  | 948 |  |
| Mortgage- and asset-backed securities |  |  | 12,907 |  |  |  | 26 |  |  |  | (49 | ) |  |  | 12,884 |  |  |  | 0 |  |  |  | 25 |  |  |  | 12,859 |  |
| Subtotal |  |  | 141,023 |  |  |  | 417 |  |  |  | (379 | ) |  |  | 141,061 |  |  |  | 2,066 |  |  |  | 8,833 |  |  |  | 130,162 |  |
| Total |  | $ | 155,332 |  |  | $ | 418 |  |  | $ | (511 | ) |  | $ | 155,239 |  |  | $ | 13,844 |  |  | $ | 11,233 |  |  | $ | 130,162 |  |

[0001193125-15-259935:notes:39]
[same as prior period, unchanged from 0001193125-15-153166:notes:6]

[0001193125-15-259935:notes:40]
|  | (2) | The fair value of Level 2 securities is estimated based on observable inputs other than quoted prices in active markets for identical assets and liabilities, quoted prices for identical or similar assets or liabilities in inactive markets, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities. |


## us-gaap:DividendsDeclaredTableTextBlock

[0001193125-15-259935:notes:41]
The Company declared and paid cash dividends per share during the
 periods presented as follows:

[0001193125-15-259935:notes:42]
|  |  | Dividends Per Share |  |  | Amount (in millions) |  |
| 2015: |  |  |  |  |  |  |  |  |
| Third quarter |  | $ | 0.52 |  |  | $ | 2,997 |  |
| Second quarter |  |  | 0.47 |  |  |  | 2,734 |  |
| First quarter |  |  | 0.47 |  |  |  | 2,750 |  |
| Total cash dividends declared and paid |  | $ | 1.46 |  |  | $ | 8,481 |  |
| 2014: |  |  |  |  |  |  |  |  |
| Fourth quarter |  | $ | 0.47 |  |  | $ | 2,807 |  |
| Third quarter |  |  | 0.47 |  |  |  | 2,830 |  |
| Second quarter |  |  | 0.44 |  |  |  | 2,655 |  |
| First quarter |  |  | 0.44 |  |  |  | 2,739 |  |
| Total cash dividends declared and paid |  | $ | 1.82 |  |  | $ | 11,031 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001193125-15-259935:notes:43]
[same as prior period, unchanged from 0001193125-15-153166:notes:1]

[0001193125-15-259935:notes:44]
The accompanying condensed consolidated financial
 statements include the accounts of the Company. Intercompany
 accounts and transactions have been eliminated. In the opinion of
 the Company’s management, the condensed consolidated
 financial statements reflect all adjustments, which are normal and
 recurring in nature, necessary for fair financial statement
 presentation. The preparation of these condensed consolidated
 financial statements in conformity with U.S. generally accepted
 accounting principles (“GAAP”) requires management to
 make estimates and assumptions that affect the amounts reported in
 these condensed consolidated financial statements and accompanying
 notes. Actual results could differ materially from those
 estimates.

[0001193125-15-259935:notes:45]
[same as prior period, unchanged from 0001193125-15-153166:notes:3]


## us-gaap:EarningsPerSharePolicyTextBlock

[0001193125-15-259935:notes:46]
[same as prior period, unchanged from 0001193125-15-153166:notes:49]

[0001193125-15-259935:notes:47]
[same as prior period, unchanged from 0001193125-15-153166:notes:50]

[0001193125-15-259935:notes:48]
Potentially dilutive securities whose effect would
 have been antidilutive were not significant for the three- and
 nine-month periods ended June 27, 2015 and June 28, 2014.
 The Company excluded these securities from the computation of
 diluted earnings per share.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001193125-15-259935:notes:49]
[same as prior period, unchanged from 0001193125-15-153166:notes:96]

[0001193125-15-259935:notes:50]
[same as prior period, unchanged from 0001193125-15-153166:notes:97]

[0001193125-15-259935:notes:51]
|  | (2) | The fair value of Level 2 securities is estimated based on observable inputs other than quoted prices in active markets for identical assets and liabilities, quoted prices for identical or similar assets or liabilities in inactive markets, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities. |  |

[0001193125-15-259935:notes:52]
The Company may sell certain of its marketable
 securities prior to their stated maturities for strategic reasons
 including, but not limited to, anticipation of credit deterioration
 and duration management. The net realized gains or losses
 recognized by the Company related to such sales were not
 significant during the three- and nine-month periods ended
 June 27, 2015 and June 28, 2014. The maturities of the
 Company’s long-term marketable securities generally range
 from one to five years.

[0001193125-15-259935:notes:53]
As of June 27, 2015 and September 27,
 2014, gross unrealized losses related to individual securities that
 had been in a continuous loss position for 12 months or longer were
 not significant.

[0001193125-15-259935:notes:54]
During the three- and nine-month periods ended
 June 27, 2015 and June 28, 2014, the Company did not
 recognize any significant impairment charges. As of June 27,
 2015, the Company considers the declines in market value of its
 marketable securities investment portfolio to be temporary in
 nature and does not consider any of its investments
 other-than-temporarily impaired. The Company typically invests in
 highly-rated securities, and its investment policy generally limits
 the amount of credit exposure to any one issuer. The policy
 generally requires investments to be investment grade, with the
 primary objective of minimizing the potential risk of principal
 loss. Fair values were determined for each individual security in
 the investment portfolio. When evaluating an investment for
 other-than-temporary impairment the Company reviews factors such as
 the length of time and extent to which fair value has been below
 its cost basis, the financial condition of the issuer and any
 changes thereto, changes in market interest rates and the
 Company’s intent to sell, or whether it is more likely than
 not it will be required to sell the investment before recovery of
 the investment’s cost basis.

[0001193125-15-259935:notes:55]
Derivative Financial Instruments

[0001193125-15-259935:notes:56]
The Company may use derivatives to partially offset
 its business exposure to foreign currency and interest rate risk on
 expected future cash flows, on net investments in certain foreign
 subsidiaries and on certain existing assets and liabilities.
 However, the Company may choose not to hedge certain exposures for
 a variety of reasons including, but not limited to, accounting
 considerations and the prohibitive economic cost of hedging
 particular exposures. There can be no assurance the hedges will
 offset more than a portion of the financial impact resulting from
 movements in foreign currency exchange or interest rates.

[0001193125-15-259935:notes:57]
To help protect gross margins from fluctuations in
 foreign currency exchange rates, certain of the Company’s
 subsidiaries whose functional currency is the U.S. dollar may hedge
 a portion of forecasted foreign currency revenue, and subsidiaries
 whose functional currency is not the U.S. dollar and who sell in
 local currencies may hedge a portion of forecasted inventory
 purchases not denominated in the subsidiaries’ functional
 currencies. The Company may enter into forward contracts, option
 contracts or other instruments to manage this risk and may
 designate these instruments as cash flow hedges. The Company
 typically hedges portions of its forecasted foreign currency
 exposure associated with revenue and inventory purchases, typically
 for up to 12 months.

[0001193125-15-259935:notes:58]
To help protect the net investment in a foreign
 operation from adverse changes in foreign currency exchange rates,
 the Company may enter into foreign currency forward and option
 contracts to offset the changes in the carrying amounts of these
 investments due to fluctuations in foreign currency exchange rates.
 In addition, the Company may use non-derivative financial
 instruments, such as its foreign-currency-denominated debt, as
 economic hedges of its net investments in certain foreign
 subsidiaries. In both of these cases, the Company designates these
 instruments as net investment hedges.

[0001193125-15-259935:notes:59]
The Company may also enter into non-designated
 foreign currency contracts to partially offset the foreign currency
 exchange gains and losses generated by the re-measurement of
 certain assets and liabilities denominated in non-functional
 currencies.

[0001193125-15-259935:notes:60]
The Company may enter into interest rate swaps,
 options, or other instruments to manage interest rate risk. These
 instruments may offset a portion of changes in income or expense,
 or changes in fair value of the Company’s long-term debt or
 investments. The Company designates these instruments as either
 cash flow or fair value hedges. The Company’s hedged interest
 rate transactions as of June 27, 2015 are expected to be
 recognized within 12 years.

[0001193125-15-259935:notes:61]
Cash Flow Hedges

[0001193125-15-259935:notes:62]
The effective portions of cash flow hedges are
 recorded in accumulated other comprehensive income
 (“AOCI”) until the hedged item is recognized in
 earnings. Deferred gains and losses associated with cash flow
 hedges of foreign currency revenue are recognized as a component of
 net sales in the same period as the related revenue is recognized,
 and deferred gains and losses related to cash flow hedges of
 inventory purchases are recognized as a component of cost of sales
 in the same period as the related costs are recognized. Deferred
 gains and losses associated with cash flow hedges of interest
 income or expense are recognized in other income/(expense), net in
 the same period as the related income or expense is recognized.

[0001193125-15-259935:notes:63]
The ineffective portions and amounts excluded from
 the effectiveness testing of cash flow hedges are recognized in
 other income/(expense), net. These amounts were not significant
 during the three- and nine-month periods ended June 27, 2015
 and June 28, 2014.

[0001193125-15-259935:notes:64]
Derivative instruments designated as cash flow
 hedges must be de-designated as hedges when it is probable the
 forecasted hedged transaction will not occur in the initially
 identified time period or within a subsequent two-month time
 period. Deferred gains and losses in AOCI associated with such
 derivative instruments are reclassified immediately into other
 income/(expense), net. Any subsequent changes in fair value of such
 derivative instruments are reflected in other income/(expense), net
 unless they are re-designated as hedges of other transactions. The
 Company did not recognize any significant net gains or losses
 related to the loss of hedge designation on discontinued cash flow
 hedges during the three- and nine-month periods ended June 27,
 2015 and June 28, 2014.

[0001193125-15-259935:notes:65]
Net Investment Hedges

[0001193125-15-259935:notes:66]
The effective portions of net investment hedges are
 recorded in other comprehensive income (“OCI”) as a
 part of the cumulative translation adjustment. The ineffective
 portions and amounts excluded from the effectiveness testing of net
 investment hedges are recognized in other income/(expense), net and
 were not significant during the three- and nine-month periods ended
 June 27, 2015 and June 28, 2014.

[0001193125-15-259935:notes:67]
Fair Value Hedges

[0001193125-15-259935:notes:68]
Gains and losses related to changes in fair value
 hedges are recognized in earnings along with a corresponding loss
 or gain related to the change in value of the underlying hedged
 item. The ineffective portions and amounts excluded from the
 effectiveness testing of fair value hedges recognized were not
 significant during the three- and nine-month periods ended
 June 27, 2015 and June 28, 2014.

[0001193125-15-259935:notes:69]
Non-Designated Derivatives

[0001193125-15-259935:notes:70]
Derivatives that are not designated as hedging
 instruments are adjusted to fair value through earnings in the
 financial statement line item to which the derivative relates. The
 net gains and losses recognized for foreign currency forward and
 option contracts not designated as hedging instruments were not
 significant during the three- and nine-month periods ended
 June 27, 2015 and June 28, 2014.

[0001193125-15-259935:notes:71]
The Company records all derivatives in the
 Condensed Consolidated Balance Sheets at fair value. The
 Company’s accounting treatment for these derivative
 instruments is based on its hedge designation. The following tables
 show the Company’s derivative instruments at gross fair value
 as of June 27, 2015 and September 27, 2014 (in
 millions):

[0001193125-15-259935:notes:72]
The following tables show the pre-tax gains and
 losses of the Company’s derivative and non-derivative
 instruments designated as cash flow, net investment and fair value
 hedges on OCI and the Condensed Consolidated Statements of
 Operations for the three- and nine-month periods ended
 June 27, 2015 and June 28, 2014 (in millions):

[0001193125-15-259935:notes:73]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 27, 2015 |  |  | June 28, 2014 |  |  | June 27, 2015 |  |  | June 28, 2014 |  |
| Gains/(Losses) recognized in OCI – effective portion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | (39 | ) |  | $ | (73 | ) |  | $ | 4,137 |  |  | $ | 70 |  |
| Interest rate contracts |  |  | 6 |  |  |  | (10 | ) |  |  | (511 | ) |  |  | (16 | ) |
| Total |  | $ | (33 | ) |  | $ | (83 | ) |  | $ | 3,626 |  |  | $ | 54 |  |
| Net investment hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 55 |  |  | $ | (5 | ) |  | $ | 167 |  |  | $ | 0 |  |
| Foreign currency debt |  |  | (6 | ) |  |  | 0 |  |  |  | (6 | ) |  |  | 0 |  |
| Total |  | $ | 49 |  |  | $ | (5 | ) |  | $ | 161 |  |  | $ | 0 |  |
| Gains/(Losses) reclassified from AOCI into net income – effective portion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash flow hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 1,357 |  |  | $ | (29 | ) |  | $ | 3,285 |  |  | $ | (81 | ) |
| Interest rate contracts |  |  | 59 |  |  |  | (4 | ) |  |  | (393 | ) |  |  | (12 | ) |
| Total |  | $ | 1,416 |  |  | $ | (33 | ) |  | $ | 2,892 |  |  | $ | (93 | ) |
| Gains/(Losses) on derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fair value hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate contracts |  | $ | (254 | ) |  | $ | 83 |  |  | $ | (15 | ) |  | $ | 83 |  |
| Gains/(Losses) related to hedged items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fair value hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate contracts |  | $ | 254 |  |  | $ | (83 | ) |  | $ | 15 |  |  | $ | (83 | ) |

[0001193125-15-259935:notes:74]
The following table shows the notional amounts of
 the Company’s outstanding derivative instruments and credit
 risk amounts associated with outstanding or unsettled derivative
 instruments as of June 27, 2015 and September 27, 2014
 (in millions):

[0001193125-15-259935:notes:75]
|  |  | June 27, 2015 |  |  | September 27, 2014 |  |
|  |  | Notional Amount |  |  | Credit Risk Amount |  |  | Notional Amount |  |  | Credit Risk Amount |  |
| Instruments designated as accounting hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 37,433 |  |  | $ | 564 |  |  | $ | 42,945 |  |  | $ | 1,333 |  |
| Interest rate contracts |  | $ | 22,263 |  |  | $ | 160 |  |  | $ | 12,000 |  |  | $ | 89 |  |
| Instruments not designated as accounting hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 27,357 |  |  | $ | 29 |  |  | $ | 38,510 |  |  | $ | 222 |  |

[0001193125-15-259935:notes:76]
The notional amounts for outstanding derivative
 instruments provide one measure of the transaction volume
 outstanding and do not represent the amount of the Company’s
 exposure to credit or market loss. The credit risk amounts
 represent the Company’s gross exposure to potential
 accounting loss on derivative instruments that are outstanding or
 unsettled if all counterparties failed to perform according to the
 terms of the contract, based on then-current currency or interest rates at
 each respective date. The Company’s exposure to credit loss
 and market risk will vary over time as currency and interest rates
 change. Although the table above reflects the notional and credit
 risk amounts of the Company’s derivative instruments, it does
 not reflect the gains or losses associated with the exposures and
 transactions that the instruments are intended to hedge. The
 amounts ultimately realized upon settlement of these financial
 instruments, together with the gains and losses on the underlying
 exposures, will depend on actual market conditions during the
 remaining life of the instruments.

[0001193125-15-259935:notes:77]
The Company generally enters into master netting
 arrangements, which are designed to reduce credit risk by
 permitting net settlement of transactions with the same
 counterparty. To further limit credit risk, the Company generally
 enters into collateral security arrangements that provide for
 collateral to be received or posted when the net fair value of
 certain financial instruments fluctuates from contractually
 established thresholds. The Company presents its derivative assets
 and derivative liabilities at their gross fair values in its
 Condensed Consolidated Balance Sheets. As of June 27, 2015 and
 September 27, 2014, the Company received $2.1 billion of cash
 collateral related to the derivative instruments under its
 collateral security arrangements, which were recorded as other
 current liabilities within accrued expenses in the Condensed
 Consolidated Balance Sheets.

[0001193125-15-259935:notes:78]
Under master netting arrangements with the
 respective counterparties to the Company’s derivative
 contracts, the Company is allowed to net settle transactions
 with a single net amount payable by one party to the other. As of
 June 27, 2015 and September 27, 2014, the potential
 effects of these rights of set-off associated with the
 Company’s derivative contracts, including the effects of
 collateral, would be a reduction to both derivative assets and
 derivative liabilities of $2.2 billion and $1.6 billion,
 respectively, resulting in net derivative liabilities
 of $868 million and $549 million, respectively.

[0001193125-15-259935:notes:79]
[same as prior period, unchanged from 0001193125-15-153166:notes:109]

[0001193125-15-259935:notes:80]
[same as prior period, unchanged from 0001193125-15-153166:notes:110]

[0001193125-15-259935:notes:81]
The Company has considerable trade receivables
 outstanding with its third-party cellular network carriers,
 wholesalers, retailers, value-added resellers, small and mid-sized
 businesses and education, enterprise and government customers that
 are not covered by collateral, third-party financing arrangements
 or credit insurance. As of June 27, 2015, the Company had one
 customer that represented 10% or more of total trade receivables,
 which accounted for 12%. As of September 27, 2014, the Company
 had two customers that represented 10% or more of total trade
 receivables, one of which accounted for 16% and the other 13%. The
 Company’s cellular network carriers accounted for 57% and 72%
 of trade receivables as of June 27, 2015 and
 September 27, 2014, respectively.

[0001193125-15-259935:notes:82]
[same as prior period, unchanged from 0001193125-15-153166:notes:112]

[0001193125-15-259935:notes:83]
Additionally, the Company has non-trade receivables
 from certain of its manufacturing vendors resulting from the sale
 of components to these vendors who manufacture sub-assemblies or
 assemble final products for the Company. Vendor non-trade
 receivables from three of the Company’s vendors accounted for
 47%, 21% and 14% of total vendor non-trade receivables as of
 June 27, 2015 and three of the Company’s vendors
 accounted for 51%, 16% and 14% of total vendor non-trade
 receivables as of September 27, 2014.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001193125-15-259935:notes:84]
[same as prior period, unchanged from 0001193125-15-153166:notes:54]

[0001193125-15-259935:notes:85]
Apple Inc. and its wholly-owned subsidiaries
 (collectively “Apple” or the “Company”)
 designs, manufactures and markets mobile communication and media
 devices, personal computers and portable digital music players, and
 sells a variety of related software, services, accessories,
 networking solutions and third-party digital content and
 applications. The Company sells its products worldwide through its
 retail stores, online stores and direct sales force, as well as
 through third-party cellular network carriers, wholesalers,
 retailers and value-added resellers. In addition, the Company sells
 a variety of third-party Apple compatible products, including
 application software and various accessories through its online and
 retail stores. The Company sells to consumers, small and mid-sized
 businesses and education, enterprise and government customers.


## us-gaap:OtherNoncurrentLiabilitiesTableTextBlock

[0001193125-15-259935:notes:86]
| Other Non-Current Liabilities |  |  |  |  |  |  |  |  |
|  |  | June 27, 2015 |  |  | September 27, 2014 |  |
| Deferred tax liabilities |  | $ | 24,539 |  |  | $ | 20,259 |  |
| Other non-current liabilities |  |  | 6,757 |  |  |  | 4,567 |  |
| Total other non-current liabilities |  | $ | 31,296 |  |  | $ | 24,826 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001193125-15-259935:notes:87]
Property, Plant and Equipment, Net

[0001193125-15-259935:notes:88]
|  |  | June 27, 2015 |  |  | September 27, 2014 |  |
| Land and buildings |  | $ | 6,071 |  |  | $ | 4,863 |  |
| Machinery, equipment and internal-use software |  |  | 34,495 |  |  |  | 29,639 |  |
| Leasehold improvements |  |  | 4,978 |  |  |  | 4,513 |  |
| Gross property, plant and equipment |  |  | 45,544 |  |  |  | 39,015 |  |
| Accumulated depreciation and amortization |  |  | (24,395 | ) |  |  | (18,391 | ) |
| Total property, plant and equipment, net |  | $ | 21,149 |  |  | $ | 20,624 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-15-259935:notes:89]
[same as prior period, unchanged from 0001193125-15-153166:notes:141]

[0001193125-15-259935:notes:90]
[same as prior period, unchanged from 0001193125-15-153166:notes:142]

[0001193125-15-259935:notes:91]
The following table shows the pre-tax amounts
 reclassified from AOCI into the Condensed Consolidated Statements
 of Operations, and the associated financial statement line item,
 for the three- and nine-month periods ended June 27, 2015 and
 June 28, 2014 (in millions):

[0001193125-15-259935:notes:92]
|  |  |  |  | Three Months Ended |  |  | Nine Months Ended |  |
| Comprehensive Income Components |  | Financial Statement Line Item |  | June 27, 2015 |  |  | June 28, 2014 |  |  | June 27, 2015 |  |  | June 28, 2014 |  |
| Unrealized (gains)/losses on derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Revenue |  | $ | (828 | ) |  | $ | 86 |  |  | $ | (1,835 | ) |  | $ | 389 |  |
|  |  | Cost of sales |  |  | (529 | ) |  |  | (57 | ) |  |  | (1,450 | ) |  |  | (308 | ) |
|  |  | Other income/(expense), net |  |  | (52 | ) |  |  | 0 |  |  |  | (53 | ) |  |  | 14 |  |
| Interest rate contracts |  | Other income/(expense), net |  |  | (59 | ) |  |  | 4 |  |  |  | 393 |  |  |  | 12 |  |
|  |  |  |  |  | (1,468 | ) |  |  | 33 |  |  |  | (2,945 | ) |  |  | 107 |  |
| Unrealized (gains)/losses on marketable securities |  | Other income/(expense), net |  |  | 3 |  |  |  | (50 | ) |  |  | 37 |  |  |  | (127 | ) |
| Total amounts reclassified from AOCI |  | $ | (1,465 | ) |  | $ | (17 | ) |  | $ | (2,908 | ) |  | $ | (20 | ) |

[0001193125-15-259935:notes:93]
The following table shows the changes in AOCI by component for the
 nine months ended June 27, 2015 (in millions):

[0001193125-15-259935:notes:94]
|  |  | Cumulative Foreign Currency Translation |  |  | Unrealized Gains/Losses on Derivative Instruments |  |  | Unrealized Gains/Losses on Marketable Securities |  |  | Total |  |
| Balance at September 27, 2014 |  | $ | (242 | ) |  | $ | 1,364 |  |  | $ | (40 | ) |  | $ | 1,082 |  |
| Other comprehensive income/(loss) before reclassifications |  |  | (280 | ) |  |  | 3,471 |  |  |  | (442 | ) |  |  | 2,749 |  |
| Amounts reclassified from AOCI |  |  | 0 |  |  |  | (2,945 | ) |  |  | 37 |  |  |  | (2,908 | ) |
| Tax effect |  |  | 101 |  |  |  | (70 | ) |  |  | 144 |  |  |  | 175 |  |
| Other comprehensive income/(loss) |  |  | (179 | ) |  |  | 456 |  |  |  | (261 | ) |  |  | 16 |  |
| Balance at June 27, 2015 |  | $ | (421 | ) |  | $ | 1,820 |  |  | $ | (301 | ) |  | $ | 1,098 |  |


## us-gaap:ScheduleOfIndefiniteLivedIntangibleAssetsTableTextBlock

[0001193125-15-259935:notes:95]
The following table summarizes the components of
 gross and net intangible asset balances as of June 27, 2015
 and September 27, 2014 (in millions):

[0001193125-15-259935:notes:96]
|  |  | June 27, 2015 |  |  | September 27, 2014 |  |
|  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Carrying Amount |  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Carrying Amount |  |
| Definite-lived and amortizable acquired intangible assets |  | $ | 7,670 |  |  | $ | (3,991 | ) |  | $ | 3,679 |  |  | $ | 7,127 |  |  | $ | (3,085 | ) |  | $ | 4,042 |  |
| Indefinite-lived and non-amortizable acquired intangible assets |  |  | 100 |  |  |  | 0 |  |  |  | 100 |  |  |  | 100 |  |  |  | 0 |  |  |  | 100 |  |
| Total acquired intangible assets |  | $ | 7,770 |  |  | $ | (3,991 | ) |  | $ | 3,779 |  |  | $ | 7,227 |  |  | $ | (3,085 | ) |  | $ | 4,142 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-15-259935:notes:97]
[same as prior period, unchanged from 0001193125-15-153166:notes:56]

[0001193125-15-259935:notes:98]
The Company’s acquired intangible assets
 with definite useful lives primarily consist of patents and
 licenses and are amortized over periods typically from three to
 seven years. The following table summarizes the components of gross
 and net intangible asset balances as of June 27, 2015 and
 September 27, 2014 (in millions):


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001193125-15-259935:notes:99]
[same as prior period, unchanged from 0001193125-15-153166:notes:145]

[0001193125-15-259935:notes:100]
[same as prior period, unchanged from 0001193125-15-153166:notes:146]

[0001193125-15-259935:notes:101]
The Company had 445.2 million shares reserved
 for future issuance under its stock plans as of June 27, 2015.
 RSUs granted generally vest over four years, based on continued
 employment, and are settled upon vesting in shares of the
 Company’s common stock on a one-for-one basis. Each share
 issued with respect to RSUs granted under the Company’s stock
 plans reduces the number of shares available for grant under the
 plan by two shares. RSUs cancelled and shares withheld to satisfy
 tax withholding obligations increase the number of shares available
 for grant under the plans utilizing a factor of two times the
 number of RSUs cancelled or shares withheld. Stock options count
 against the number of shares available for grant on a one-for-one
 basis.

[0001193125-15-259935:notes:102]
[same as prior period, unchanged from 0001193125-15-153166:notes:148]

[0001193125-15-259935:notes:103]
During the three months ended June 27, 2015,
 Section 16 officers Timothy D. Cook, Angela Ahrendts, Luca
 Maestri, Daniel Riccio and Jeffrey Williams had equity trading
 plans in place in accordance with Rule 10b5-1(c)(1) under the
 Exchange Act. An equity trading plan is a written document that
 pre-establishes the amounts, prices and dates (or formula for
 determining the amounts, prices and dates) of future purchases or
 sales of the Company’s stock, including shares acquired
 pursuant to the Company’s employee and director equity
 plans.

[0001193125-15-259935:notes:104]
[same as prior period, unchanged from 0001193125-15-153166:notes:150]

[0001193125-15-259935:notes:105]
A summary of the Company’s RSU activity and related
 information for the nine months ended June 27, 2015 is as
 follows:

[0001193125-15-259935:notes:106]
|  |  | Number of RSUs (in thousands) |  |  | Weighted-Average Grant Date Fair Value |  |  | Aggregate Intrinsic Value (in millions) |  |
| Balance at September 27, 2014 |  |  | 103,822 |  |  | $ | 70.98 |  |  |  |  |  |
| RSUs granted |  |  | 41,679 |  |  | $ | 104.26 |  |  |  |  |  |
| RSUs vested |  |  | (37,495 | ) |  | $ | 71.13 |  |  |  |  |  |
| RSUs cancelled |  |  | (4,461 | ) |  | $ | 77.71 |  |  |  |  |  |
| Balance at June 27, 2015 |  |  | 103,545 |  |  | $ | 84.03 |  |  | $ | 13,124 |  |

[0001193125-15-259935:notes:107]
RSUs that vested during the three- and nine-month
 periods ended June 27, 2015 had fair values of $2.3 billion
 and $4.3 billion, respectively, as of the vesting date. RSUs that
 vested during the three- and nine-month periods ended June 28,
 2014 had fair values of $1.3 billion and $2.6 billion,
 respectively, as of the vesting date.

[0001193125-15-259935:notes:108]
[same as prior period, unchanged from 0001193125-15-153166:notes:152]

[0001193125-15-259935:notes:109]
The Company had 1.6 million stock options
 outstanding as of June 27, 2015, with a weighted-average
 exercise price per share of $16.62 and weighted-average remaining
 contractual term of 3.4 years, substantially all of which are
 exercisable. The aggregate intrinsic value of the stock options
 outstanding as of June 27, 2015 was $177 million, which
 represents the value of the Company’s closing stock price on
 the last trading day of the period in excess of the
 weighted-average exercise price multiplied by the number of options
 outstanding.

[0001193125-15-259935:notes:110]
The total intrinsic value of options at the time of
 exercise was $72 million and $439 million for the three- and
 nine-month periods ended June 27, 2015, respectively, and $271
 million and $978 million for the three- and nine-month periods
 ended June 28, 2014, respectively.

[0001193125-15-259935:notes:111]
[same as prior period, unchanged from 0001193125-15-153166:notes:155]

[0001193125-15-259935:notes:112]
The following table shows a summary of the
 share-based compensation expense included in the Condensed
 Consolidated Statements of Operations for the three- and nine-month
 periods ended June 27, 2015 and June 28, 2014 (in
 millions):

[0001193125-15-259935:notes:113]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 27, 2015 |  |  | June 28, 2014 |  |  | June 27, 2015 |  |  | June 28, 2014 |  |
| Cost of sales |  | $ | 148 |  |  | $ | 115 |  |  | $ | 430 |  |  | $ | 334 |  |
| Research and development |  |  | 388 |  |  |  | 313 |  |  |  | 1,146 |  |  |  | 902 |  |
| Selling, general and administrative |  |  | 320 |  |  |  | 296 |  |  |  | 1,095 |  |  |  | 865 |  |
| Total share-based compensation expense |  | $ | 856 |  |  | $ | 724 |  |  | $ | 2,671 |  |  | $ | 2,101 |  |

[0001193125-15-259935:notes:114]
The income tax benefit related to share-based
 compensation expense was $286 million and $948 million for the
 three- and nine-month periods ended June 27, 2015,
 respectively, and was $260 million and $755 million for the three-
 and nine-month periods ended June 28, 2014, respectively. As
 of June 27, 2015, the total unrecognized compensation cost
 related to outstanding stock options and RSUs expected to vest was
 $7.3 billion, which the Company expects to recognize over a
 weighted-average period of 2.8 years.


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001193125-15-259935:notes:115]
The following table shows changes in the
 Company’s accrued warranties and related costs for the three-
 and nine-month periods ended June 27, 2015 and June 28,
 2014 (in millions):

[0001193125-15-259935:notes:116]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 27, 2015 |  |  | June 28, 2014 |  |  | June 27, 2015 |  |  | June 28, 2014 |  |
| Beginning accrued warranty and related costs |  | $ | 5,143 |  |  | $ | 4,368 |  |  | $ | 4,159 |  |  | $ | 2,967 |  |
| Cost of warranty claims |  |  | (1,077 | ) |  |  | (882 | ) |  |  | (3,151 | ) |  |  | (2,811 | ) |
| Accruals for product warranty |  |  | 1,071 |  |  |  | 756 |  |  |  | 4,129 |  |  |  | 4,086 |  |
| Ending accrued warranty and related costs |  | $ | 5,137 |  |  | $ | 4,242 |  |  | $ | 5,137 |  |  | $ | 4,242 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-15-259935:notes:117]
[same as prior period, unchanged from 0001193125-15-153166:notes:133]

[0001193125-15-259935:notes:118]
As of June 27, 2015, the Company recorded
 gross unrecognized tax benefits of $5.4 billion, of which $2.0
 billion, if recognized, would affect the Company’s effective
 tax rate. As of September 27, 2014, the total amount of gross
 unrecognized tax benefits was $4.0 billion, of which $1.4 billion,
 if recognized, would have affected the Company’s effective
 tax rate. The Company’s total gross unrecognized tax benefits
 are classified as other non-current liabilities in the Condensed
 Consolidated Balance Sheets. The Company had $928 million and $630
 million of gross interest and penalties accrued as of June 27,
 2015 and September 27, 2014, respectively, which are
 classified as other non-current liabilities in the Condensed
 Consolidated Balance Sheets.

[0001193125-15-259935:notes:119]
[same as prior period, unchanged from 0001193125-15-153166:notes:135]

[0001193125-15-259935:notes:120]
On June 11, 2014, the European Commission
 issued an opening decision initiating a formal investigation
 against Ireland for alleged state aid to the Company. The opening
 decision concerns the allocation of profits for taxation purposes
 of the Irish branches of two subsidiaries of the Company. The
 Company believes the European Commission’s assertions are
 without merit. If the European Commission were to conclude against
 Ireland, the European Commission could require Ireland to recover
 from the Company past taxes covering a period of up to 10 years
 reflective of the disallowed state aid. While such amount could be
 material, as of June 27, 2015 the Company is unable to
 estimate the impact.


## us-gaap:InterestAndOtherIncomeTableTextBlock

[0001193125-15-259935:notes:121]
[same as prior period, unchanged from 0001193125-15-153166:notes:73]

[0001193125-15-259935:notes:122]
The following table shows the detail of other
 income/(expense), net for the three- and nine-month periods ended
 June 27, 2015 and June 28, 2014 (in millions):

[0001193125-15-259935:notes:123]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 27, 2015 |  |  | June 28, 2014 |  |  | June 27, 2015 |  |  | June 28, 2014 |  |
| Interest and dividend income |  | $ | 766 |  |  | $ | 439 |  |  | $ | 2,095 |  |  | $ | 1,276 |  |
| Interest expense |  |  | (201 | ) |  |  | (100 | ) |  |  | (495 | ) |  |  | (269 | ) |
| Other expense, net |  |  | (175 | ) |  |  | (137 | ) |  |  | (754 | ) |  |  | (334 | ) |
| Total other income/(expense), net |  | $ | 390 |  |  | $ | 202 |  |  | $ | 846 |  |  | $ | 673 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-15-259935:notes:124]
[same as prior period, unchanged from 0001193125-15-153166:notes:120]

[0001193125-15-259935:notes:125]
[same as prior period, unchanged from 0001193125-15-153166:notes:121]

[0001193125-15-259935:notes:126]
Future dividends are subject to declaration by the
 Board of Directors.

[0001193125-15-259935:notes:127]
[same as prior period, unchanged from 0001193125-15-153166:notes:125]

[0001193125-15-259935:notes:128]
In the third quarter of 2015, the Company’s
 Board of Directors increased the share repurchase authorization to
 $140 billion of the Company’s common stock, of which
 $90.0 billion had been utilized as of June 27, 2015. The
 Company’s share repurchase program does not obligate it to
 acquire any specific number of shares. Under the program, shares
 may be repurchased in privately negotiated and/or open market
 transactions, including under plans complying with Rule 10b5-1 under the Securities Exchange
 Act of 1934, as amended (the “Exchange Act”).

[0001193125-15-259935:notes:129]
The Company has entered, and in the future may
 enter, into accelerated share repurchase arrangements
 (“ASRs”) with financial institutions. In exchange for
 up-front payments, the financial institutions deliver shares of the
 Company’s common stock during the purchase periods of each
 ASR. The total number of shares ultimately delivered, and therefore
 the average repurchase price paid per share, is determined at the
 end of the applicable purchase period of each ASR based on the
 volume weighted-average price of the Company’s common stock
 during that period. The shares received are retired in the periods
 they are delivered, and the up-front payments are accounted for as
 a reduction to shareholders’ equity in the Company’s
 Condensed Consolidated Balance Sheets in the periods the payments
 are made. The Company reflects the ASRs as a repurchase of common
 stock in the period delivered for purposes of calculating earnings
 per share and as forward contracts indexed to its own common stock.
 The ASRs met all of the applicable criteria for equity
 classification, and therefore were not accounted for as derivative
 instruments.

[0001193125-15-259935:notes:130]
[same as prior period, unchanged from 0001193125-15-153166:notes:131]

[0001193125-15-259935:notes:131]
|  |  | Number of Shares (in thousands) |  |  | Average Repurchase Price Per Share |  |  | Amount (in millions) |  |
| 2015: |  |  |  |  |  |  |  |  |  |  |  |  |
| Third quarter |  |  | 31,231 |  |  | $ | 128.08 |  |  | $ | 4,000 |  |
| Second quarter |  |  | 56,400 |  |  | $ | 124.11 |  |  |  | 7,000 |  |
| First quarter |  |  | 45,704 |  |  | $ | 109.40 |  |  |  | 5,000 |  |
| Total open market common stock repurchases |  |  | 133,335 |  |  |  |  |  |  | $ | 16,000 |  |
| 2014: |  |  |  |  |  |  |  |  |  |  |  |  |
| Fourth quarter |  |  | 81,255 |  |  | $ | 98.46 |  |  | $ | 8,000 |  |
| Third quarter |  |  | 58,661 |  |  | $ | 85.23 |  |  |  | 5,000 |  |
| Second quarter |  |  | 79,749 |  |  | $ | 75.24 |  |  |  | 6,000 |  |
| First quarter |  |  | 66,847 |  |  | $ | 74.79 |  |  |  | 5,000 |  |
| Total open market common stock repurchases |  |  | 286,512 |  |  |  |  |  |  | $ | 24,000 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-15-259935:notes:132]
Note 10 – Commitments and Contingencies

[0001193125-15-259935:notes:133]
Accrued Warranty and Indemnification

[0001193125-15-259935:notes:134]
The Company generally does not indemnify end-users
 of its operating system and application software against legal
 claims that the software infringes third-party intellectual
 property rights. Other agreements entered into by the Company
 sometimes include indemnification provisions under which the
 Company could be subject to costs and/or damages in the event of an
 infringement claim against the Company or an indemnified
 third-party. However, the Company has not been required to make any
 significant payments resulting from such an infringement claim
 asserted against it or an indemnified third-party. In the opinion
 of management, there was not at least a reasonable possibility the
 Company may have incurred a material loss with respect to
 indemnification of end-users of its operating system or application
 software for infringement of third-party intellectual property
 rights. The Company did not record a liability for infringement
 costs related to indemnification as of June 27, 2015 or
 September 27, 2014.

[0001193125-15-259935:notes:135]
The Company has entered into indemnification
 agreements with its directors and executive officers. Under these
 agreements, the Company has agreed to indemnify such individuals to
 the fullest extent permitted by law against liabilities that arise
 by reason of their status as directors or officers and to advance
 expenses incurred by such individuals in connection with related
 legal proceedings. It is not possible to determine the maximum
 potential amount of payments the Company could be required to make
 under these agreements due to the limited history of prior
 indemnification claims and the unique facts and circumstances
 involved in each claim. However, the Company maintains directors
 and officers liability insurance coverage to reduce its exposure to
 such obligations, and payments made under these agreements
 historically have not been material.

[0001193125-15-259935:notes:136]
Concentrations in the Available Sources of Supply of Materials
 and Product

[0001193125-15-259935:notes:137]
Although most components essential to the
 Company’s business are generally available from multiple
 sources, a number of components are currently obtained from single
 or limited sources. In addition, the Company competes for various
 components with other participants in the markets for mobile
 communication and media devices and personal computers. Therefore,
 many components used by the Company, including those that are
 available from multiple sources, are at times subject to
 industry-wide shortage and significant pricing fluctuations that
 could materially adversely affect the Company’s financial
 condition and operating results.

[0001193125-15-259935:notes:138]
The Company uses some custom components that are
 not commonly used by its competitors, and new products introduced
 by the Company often utilize custom components available from only
 one source. When a component or product uses new technologies,
 initial capacity constraints may exist until the suppliers’
 yields have matured or manufacturing capacity has increased. If the
 Company’s supply of components for a new or existing product
 were delayed or constrained, or if an outsourcing partner delayed
 shipments of completed products to the Company, the Company’s
 financial condition and operating results could be materially
 adversely affected. The Company’s business and financial
 performance could also be materially adversely affected depending
 on the time required to obtain sufficient quantities from the
 original source, or to identify and obtain sufficient quantities
 from an alternative source. Continued availability of these
 components at acceptable prices, or at all, may be affected if
 those suppliers concentrated on the production of common components
 instead of components customized to meet the Company’s
 requirements.

[0001193125-15-259935:notes:139]
The Company has entered into agreements for the
 supply of many components; however, there can be no guarantee that
 the Company will be able to extend or renew these agreements on
 similar terms, or at all. Therefore, the Company remains subject to
 significant risks of supply shortages and price increases that
 could materially adversely affect its financial condition and
 operating results.

[0001193125-15-259935:notes:140]
Substantially all of the Company’s hardware
 products are manufactured by outsourcing partners that are located
 primarily in Asia. A significant concentration of this
 manufacturing is currently performed by a small number of
 outsourcing partners, often in single locations. Certain of these
 outsourcing partners are the sole-sourced suppliers of components
 and manufacturers for many of the Company’s products.
 Although the Company works closely with its outsourcing partners on
 manufacturing schedules, the Company’s operating results
 could be adversely affected if its outsourcing partners were unable
 to meet their production commitments. The Company’s purchase
 commitments typically cover its requirements for periods up to 150
 days.

[0001193125-15-259935:notes:141]
Other Off-Balance Sheet Commitments

[0001193125-15-259935:notes:142]
Operating Leases

[0001193125-15-259935:notes:143]
The Company leases various equipment and
 facilities, including retail space, under noncancelable operating
 lease arrangements. The Company does not currently utilize any
 other off-balance sheet financing arrangements. The major facility
 leases are typically for terms not exceeding 10 years and generally
 contain multi-year renewal options. As of June 27, 2015, the
 Company had a total of 456 retail stores. Leases for retail space
 are for terms ranging from five to 20 years, the majority of which
 are for 10 years, and often contain multi-year renewal options. As
 of June 27, 2015, the Company’s total future minimum
 lease payments under noncancelable operating leases were $5.0
 billion, of which $3.4 billion related to leases for retail
 space.

[0001193125-15-259935:notes:144]
Other Commitments

[0001193125-15-259935:notes:145]
The Company utilizes several outsourcing partners
 to manufacture sub-assemblies for the Company’s products and
 to perform final assembly and testing of finished products. These
 outsourcing partners acquire components and build product based on
 demand information supplied by the Company, which typically covers
 periods up to 150 days. The Company also obtains individual
 components for its products from a wide variety of individual
 suppliers. Consistent with industry practice, the Company acquires
 components through a combination of purchase orders, supplier
 contracts and open orders based on projected demand information.
 Where appropriate, the purchases are applied
 to inventory component prepayments that
 are outstanding with the respective supplier. As of
 June 27, 2015, the Company had outstanding off-balance sheet
 third-party manufacturing commitments and component purchase
 commitments of $21.7 billion.

[0001193125-15-259935:notes:146]
In addition to the commitments mentioned above, the
 Company had other off-balance sheet obligations of $4.8 billion as
 of June 27, 2015 that consisted of commitments to acquire
 capital assets, including product tooling and manufacturing process
 equipment, and commitments related to advertising, research and
 development (“R&D”), internet and
 telecommunications services, energy and other obligations.
 Subsequent to June 27, 2015, the Company entered into
 additional other off-balance sheet obligations of $2.1 billion.

[0001193125-15-259935:notes:147]
Contingencies

[0001193125-15-259935:notes:148]
The Company is subject to various legal proceedings
 and claims that have arisen in the ordinary course of business and
 that have not been fully adjudicated, certain of which are
 discussed in Part II, Item 1 of this Form 10-Q under the
 heading “Legal Proceedings” and in Part II,
 Item 1A of this Form 10-Q under the heading “Risk
 Factors.” In the opinion of management, there was not at
 least a reasonable possibility the Company may have incurred a
 material loss, or a material loss in excess of a recorded accrual,
 with respect to loss contingencies. However, the outcome of
 litigation is inherently uncertain. Therefore, although management
 considers the likelihood of such an outcome to be remote, if one or
 more of these legal matters were resolved against the Company in a
 reporting period for amounts in excess of management’s
 expectations, the Company’s consolidated financial statements
 for that reporting period could be materially adversely
 affected.

[0001193125-15-259935:notes:149]
Smartflash LLC, et al., v. Apple Inc., et al.

[0001193125-15-259935:notes:150]
On May 29, 2013, Smartflash LLC and Smartflash
 Technologies Limited filed an action against the Company in the
 United States District Court for the Eastern District of Texas,
 Tyler Division, alleging that the Company infringed certain patents
 relating to data storage and access systems. On February 24,
 2015, a jury returned a verdict against the Company, and awarded
 damages of approximately $533 million. On July 7, 2015, the
 District Court vacated the award and ordered a new trial for
 damages. Accordingly, the Company has not recorded a loss accrual
 at this time.

[0001193125-15-259935:notes:151]
Apple Inc. v. Samsung Electronics Co., Ltd, et al.

[0001193125-15-259935:notes:152]
On August 24, 2012, a jury returned a verdict
 awarding the Company $1.05 billion in its lawsuit against Samsung
 Electronics Co., Ltd and affiliated parties in the United States
 District Court, Northern District of California, San Jose Division.
 On March 6, 2014, the District Court entered final judgment in
 favor of the Company in the amount of approximately $930
 million. On May 18, 2015, the U.S. Court of Appeals for
 the Federal Circuit affirmed in part, and reversed in part, the
 decision of the District Court. As a result, the Court of Appeals
 ordered entry of final judgment on damages in the amount of
 approximately $548 million, with the District Court to determine
 supplemental damages and interest, as well as damages owed for
 products subject to the reversal in part. Because the ruling
 remains subject to further proceedings, the Company has not
 recognized the award in its results of operations.


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001193125-15-259935:notes:153]
[same as prior period, unchanged from 0001193125-15-153166:notes:63]

[0001193125-15-259935:notes:154]
|  |  | June 27, 2015 |  |  | September 27, 2014 |  |
| Components |  | $ | 474 |  |  | $ | 471 |  |
| Finished goods |  |  | 1,568 |  |  |  | 1,640 |  |
| Total inventories |  | $ | 2,042 |  |  | $ | 2,111 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001193125-15-259935:notes:155]
[same as prior period, unchanged from 0001193125-15-153166:notes:137]

[0001193125-15-259935:notes:156]
The following tables show the Company’s
 condensed consolidated financial statement details as of
 June 27, 2015 and September 27, 2014 (in millions):

[0001193125-15-259935:notes:157]
|  |  | June 27, 2015 |  |  | September 27, 2014 |  |
| Accrued warranty and related costs |  | $ | 5,137 |  |  | $ | 4,159 |  |
| Accrued marketing and selling expenses |  |  | 1,651 |  |  |  | 2,321 |  |
| Accrued taxes |  |  | 1,566 |  |  |  | 1,209 |  |
| Accrued compensation and employee benefits |  |  | 1,551 |  |  |  | 1,209 |  |
| Deferred margin on component sales |  |  | 1,369 |  |  |  | 1,057 |  |
| Other current liabilities |  |  | 11,450 |  |  |  | 8,498 |  |
| Total accrued expenses |  | $ | 22,724 |  |  | $ | 18,453 |  |
| Other Non-Current Liabilities |  |  |  |  |  |  |  |  |
|  |  | June 27, 2015 |  |  | September 27, 2014 |  |
| Deferred tax liabilities |  | $ | 24,539 |  |  | $ | 20,259 |  |
| Other non-current liabilities |  |  | 6,757 |  |  |  | 4,567 |  |
| Total other non-current liabilities |  | $ | 31,296 |  |  | $ | 24,826 |  |
