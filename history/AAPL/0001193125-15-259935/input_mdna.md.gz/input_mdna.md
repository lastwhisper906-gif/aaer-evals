# AAPL MD&A — 0001193125-15-259935


## mdna

[0001193125-15-259935:mdna:1]
| Item 2. | Management’s Discussion and Analysis of Financial Condition and Results of Operations |

[0001193125-15-259935:mdna:2]
[same as prior period, unchanged from 0001193125-15-153166:mdna:2]

[0001193125-15-259935:mdna:3]
The Company’s Annual Report on Form 10-K, Quarterly Reports on Form 10-Q, Current Reports on Form 8-K, and amendments to reports filed pursuant to
Sections 13(a) and 15(d) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), are filed with the SEC. The Company is subject to the informational requirements of the Exchange Act and files or furnishes reports, proxy
statements, and other information with the SEC. Such reports and other information filed by the Company with the SEC are available free of charge on the Company’s website at investor.apple.com/sec.cfm when such reports are available on
the SEC’s website. The public may read and copy any materials filed by the Company with the SEC at the SEC’s Public Reference Room at 100 F Street, NE, Room 1580, Washington, DC 20549. The public may obtain information on the operation of
the Public Reference Room by calling the SEC at 1-800-SEC-0330. The SEC maintains an internet site that contains reports, proxy and information statements and other information regarding issuers that file electronically with the SEC at
www.sec.gov. The contents of websites are not incorporated into this filing. Further, the Company’s references to website URLs are intended to be inactive textual references only.

[0001193125-15-259935:mdna:4]
[same as prior period, unchanged from 0001193125-15-153166:mdna:4]

[0001193125-15-259935:mdna:5]
[same as prior period, unchanged from 0001193125-15-153166:mdna:5]

[0001193125-15-259935:mdna:6]
The Company designs, manufactures and markets mobile communication and media devices, personal computers and portable digital music players, and sells a
variety of related software, services, accessories, networking solutions and third-party digital content and applications. The Company’s products and services include iPhone®, iPad®, Mac®, iPod®, Apple Watch™, Apple TV®, a portfolio of consumer and professional software applications, iOS, OS X® and watchOS™ operating systems, iCloud®, Apple Pay™ and a variety of accessory, service and support offerings. The Company also sells and delivers digital content and applications through the iTunes Store®, App Store™, Mac App Store, and iBooks Store™ (collectively “iTunes”). The Company sells its products worldwide through its retail stores, online stores and direct sales
force, as well as through third-party cellular network carriers, wholesalers, retailers and value-added resellers. In addition, the Company sells a variety of third-party Apple compatible products, including application software and various
accessories through its online and retail stores. The Company sells to consumers, small and mid-sized businesses and education, enterprise and government customers.

[0001193125-15-259935:mdna:7]
[same as prior period, unchanged from 0001193125-15-153166:mdna:7]

[0001193125-15-259935:mdna:8]
The Company is committed to bringing the best user experience to its customers through its innovative hardware, software and services. The Company’s
business strategy leverages its unique ability to design and develop its own operating systems, hardware, application software and services to provide its customers products and solutions with innovative design, superior ease-of-use and seamless
integration. As part of its strategy, the Company continues to expand its platform for the discovery and delivery of digital content and applications through iTunes®, which allows customers to
discover and download digital content, iOS, Mac and Apple Watch applications, and books through either a Mac or Windows-based computer or through iPhone, iPad and iPod touch® devices
(“iOS devices”) and Apple Watch. The Company also supports a community for the development of third-party software and hardware products and digital content that complement the Company’s offerings. The Company believes a high-quality
buying experience with knowledgeable salespersons who can convey the value of the Company’s products and services greatly enhances its ability to attract and retain customers. Therefore, the Company’s strategy also includes building and
expanding its own retail and online stores and its third-party distribution network to effectively reach more customers and provide them with a high-quality sales and post-sales support experience. The Company believes ongoing investment in research
and development (“R&D”), marketing and advertising is critical to the development and sale of innovative products and technologies.

[0001193125-15-259935:mdna:9]
Business
Seasonality and Product Introductions

[0001193125-15-259935:mdna:10]
The Company has historically experienced higher net sales in its first quarter compared to other quarters
in its fiscal year due in part to seasonal holiday demand. Additionally, new product introductions can significantly impact net sales, product costs and operating expenses. Product introductions can also impact the Company’s net sales to its
indirect distribution channels as these channels are filled with new product inventory following a product introduction, and often, channel inventory of a particular product declines as the next related major product launch approaches. Net sales can
also be affected when consumers and distributors anticipate a product introduction. However, neither historical seasonal patterns nor historical patterns of product introductions should be considered reliable indicators of the Company’s future
pattern of product introductions, future net sales or financial performance.

[0001193125-15-259935:mdna:11]
Third Quarter Fiscal 2015 Highlights

[0001193125-15-259935:mdna:12]
Net sales rose 33% or $12.2 billion during the third quarter of 2015 compared to the same quarter in 2014. Net sales and unit sales increased for iPhone
and Mac due to continued strong demand for iPhone 6 and 6 Plus and for Mac portables following the launches of the new MacBook® and updated models of MacBook Pro®. Net sales of Other Products increased solely due to the launch of Apple Watch, and net sales of Services increased primarily due to growth from iOS app sales and licensing. Net sales growth was
partially offset by lower net sales and unit sales of iPad and the effect of weakness in most foreign currencies relative to the U.S. dollar. Total net sales increased in each of the Company’s reportable operating segments, with particularly
strong growth in Greater China where year-over-year net sales increased 112%.

[0001193125-15-259935:mdna:13]
During the third quarter of 2015, the Company introduced an updated
15” MacBook Pro and 27” iMac® with Retina® 5K display, and began shipping Apple Watch and the new MacBook. Additionally, at
its Worldwide Developers Conference in June 2015, the Company announced Apple Music™, which launched at the end of June 2015, and announced its iOS 9, OS X El Capitan and watchOS 2 operating systems, which are expected to be available in the
fall of 2015.

[0001193125-15-259935:mdna:14]
The Company utilized $10.0 billion to repurchase shares of its common stock and paid dividends and dividend equivalents of $3.1
billion during the third quarter of 2015. Additionally, the Company issued $8.0 billion of U.S. dollar-denominated and ¥250.0 billion of yen-denominated long-term debt.

[0001193125-15-259935:mdna:15]
[same as prior period, unchanged from 0001193125-15-153166:mdna:15]

[0001193125-15-259935:mdna:16]
The following table shows net sales by operating segment and net sales and unit sales by product during the three- and nine-month periods ended
June 27, 2015 and June 28, 2014 (dollars in millions and units in thousands):

[0001193125-15-259935:mdna:17]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 27,2015 |  |  | June 28,2014 |  |  | Change |  |  | June 27,2015 |  |  | June 28,2014 |  |  | Change |  |
| Net Sales by Operating Segment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 20,209 |  |  | $ | 17,574 |  |  |  | 15% |  |  | $ | 72,091 |  |  | $ | 60,345 |  |  |  | 19% |  |
| Europe |  |  | 10,342 |  |  |  | 8,659 |  |  |  | 19% |  |  |  | 39,760 |  |  |  | 33,935 |  |  |  | 17% |  |
| Greater China |  |  | 13,230 |  |  |  | 6,230 |  |  |  | 112% |  |  |  | 46,197 |  |  |  | 25,561 |  |  |  | 81% |  |
| Japan |  |  | 2,872 |  |  |  | 2,627 |  |  |  | 9% |  |  |  | 11,777 |  |  |  | 11,719 |  |  |  | 0% |  |
| Rest of Asia Pacific |  |  | 2,952 |  |  |  | 2,342 |  |  |  | 26% |  |  |  | 12,389 |  |  |  | 9,112 |  |  |  | 36% |  |
| Total net sales |  | $ | 49,605 |  |  | $ | 37,432 |  |  |  | 33% |  |  | $ | 182,214 |  |  | $ | 140,672 |  |  |  | 30% |  |
| Net Sales by Product: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| iPhone (1) |  | $ | 31,368 |  |  | $ | 19,751 |  |  |  | 59% |  |  | $ | 122,832 |  |  | $ | 78,313 |  |  |  | 57% |  |
| iPad (1) |  |  | 4,538 |  |  |  | 5,889 |  |  |  | (23)% |  |  |  | 18,951 |  |  |  | 24,967 |  |  |  | (24)% |  |
| Mac (1) |  |  | 6,030 |  |  |  | 5,540 |  |  |  | 9% |  |  |  | 18,589 |  |  |  | 17,454 |  |  |  | 7% |  |
| Services (2) |  |  | 5,028 |  |  |  | 4,485 |  |  |  | 12% |  |  |  | 14,823 |  |  |  | 13,455 |  |  |  | 10% |  |
| Other Products (1)(3) |  |  | 2,641 |  |  |  | 1,767 |  |  |  | 49% |  |  |  | 7,019 |  |  |  | 6,483 |  |  |  | 8% |  |
| Total net sales |  | $ | 49,605 |  |  | $ | 37,432 |  |  |  | 33% |  |  | $ | 182,214 |  |  | $ | 140,672 |  |  |  | 30% |  |
| Unit Sales by Product: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| iPhone |  |  | 47,534 |  |  |  | 35,203 |  |  |  | 35% |  |  |  | 183,172 |  |  |  | 129,947 |  |  |  | 41% |  |
| iPad |  |  | 10,931 |  |  |  | 13,276 |  |  |  | (18)% |  |  |  | 44,973 |  |  |  | 55,661 |  |  |  | (19)% |  |
| Mac |  |  | 4,796 |  |  |  | 4,413 |  |  |  | 9% |  |  |  | 14,878 |  |  |  | 13,386 |  |  |  | 11% |  |

[0001193125-15-259935:mdna:18]
[same as prior period, unchanged from 0001193125-15-153166:mdna:18]

[0001193125-15-259935:mdna:19]
[same as prior period, unchanged from 0001193125-15-153166:mdna:19]

[0001193125-15-259935:mdna:20]
|  | (3) | Includes sales of Apple TV, Apple Watch, Beats Electronics, iPod and Apple-branded and third-party accessories. |  |

[0001193125-15-259935:mdna:21]
[same as prior period, unchanged from 0001193125-15-153166:mdna:21]

[0001193125-15-259935:mdna:22]
[same as prior period, unchanged from 0001193125-15-153166:mdna:22]

[0001193125-15-259935:mdna:23]
[same as prior period, unchanged from 0001193125-15-153166:mdna:23]

[0001193125-15-259935:mdna:24]
The following table presents iPhone net sales and unit
sales information for the three- and nine-month periods ended June 27, 2015 and June 28, 2014 (dollars in millions and units in thousands):

[0001193125-15-259935:mdna:25]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 27,2015 |  |  | June 28,2014 |  |  | Change |  |  | June 27,2015 |  |  | June 28,2014 |  |  | Change |  |
| Net sales |  | $ | 31,368 |  |  | $ | 19,751 |  |  |  | 59% |  |  | $ | 122,832 |  |  | $ | 78,313 |  |  |  | 57% |  |
| Percentage of total net sales |  |  | 63% |  |  |  | 53% |  |  |  |  |  |  |  | 67% |  |  |  | 56% |  |  |  |  |  |
| Unit sales |  |  | 47,534 |  |  |  | 35,203 |  |  |  | 35% |  |  |  | 183,172 |  |  |  | 129,947 |  |  |  | 41% |  |

[0001193125-15-259935:mdna:26]
The year-over-year growth in iPhone net sales and unit sales in the third quarter and first nine months of 2015 resulted
from the launch of iPhone 6 and 6 Plus. Overall average selling prices (“ASPs”) for iPhone increased by 18% and 11% in the third quarter and first nine months of 2015, respectively, compared to the same periods in 2014, due primarily to a
shift in mix to iPhone 6 and 6 Plus, partially offset by the effect of weakness in most foreign currencies relative to the U.S. dollar.

[0001193125-15-259935:mdna:27]
[same as prior period, unchanged from 0001193125-15-153166:mdna:27]

[0001193125-15-259935:mdna:28]
The following table presents iPad net sales and unit sales information for the three- and nine-month periods ended June 27, 2015 and June 28,
2014 (dollars in millions and units in thousands):

[0001193125-15-259935:mdna:29]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 27,2015 |  |  | June 28,2014 |  |  | Change |  |  | June 27,2015 |  |  | June 28,2014 |  |  | Change |  |
| Net sales |  | $ | 4,538 |  |  | $ | 5,889 |  |  |  | (23)% |  |  | $ | 18,951 |  |  | $ | 24,967 |  |  |  | (24)% |  |
| Percentage of total net sales |  |  | 9% |  |  |  | 16% |  |  |  |  |  |  |  | 10% |  |  |  | 18% |  |  |  |  |  |
| Unit sales |  |  | 10,931 |  |  |  | 13,276 |  |  |  | (18)% |  |  |  | 44,973 |  |  |  | 55,661 |  |  |  | (19)% |  |

[0001193125-15-259935:mdna:30]
Net sales and unit sales for iPad declined in the third quarter and first nine months of 2015 compared to the same
periods in 2014. iPad net sales decreased in each of the Company’s operating segments in the third quarter and first nine months of 2015 compared to the same periods in 2014, with the exception of Japan which had an increase in iPad net sales
and unit sales during the first nine months of 2015. The Company believes the decline in sales is due in part to a longer repurchase cycle for iPads and some level of cannibalization from the Company’s other products. iPad ASPs declined by 6%
during the third quarter and first nine months of 2015, compared to the same periods in 2014, primarily as a result of a shift in mix to lower-priced iPads and the effect of weakness in most foreign currencies relative to the U.S. dollar.

[0001193125-15-259935:mdna:31]
[same as prior period, unchanged from 0001193125-15-153166:mdna:31]

[0001193125-15-259935:mdna:32]
The following table presents Mac net sales and unit sales
information for the three- and nine-month periods ended June 27, 2015 and June 28, 2014 (dollars in millions and units in thousands):

[0001193125-15-259935:mdna:33]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 27,2015 |  |  | June 28,2014 |  |  | Change |  |  | June 27,2015 |  |  | June 28,2014 |  |  | Change |  |
| Net sales |  | $ | 6,030 |  |  | $ | 5,540 |  |  |  | 9% |  |  | $ | 18,589 |  |  | $ | 17,454 |  |  |  | 7% |  |
| Percentage of total net sales |  |  | 12% |  |  |  | 15% |  |  |  |  |  |  |  | 10% |  |  |  | 12% |  |  |  |  |  |
| Unit sales |  |  | 4,796 |  |  |  | 4,413 |  |  |  | 9% |  |  |  | 14,878 |  |  |  | 13,386 |  |  |  | 11% |  |

[0001193125-15-259935:mdna:34]
The year-over-year growth in Mac net sales and unit sales for the third quarter and first nine months of 2015 was driven
by strong demand for updated versions of Mac portables and the launch of the new MacBook in the third quarter of 2015. Mac ASPs were relatively flat during the third quarter compared to the same period in 2014, with a shift in mix to more richly
configured Macs and higher pricing of certain models offset by the effect of weakness in most foreign currencies relative to the U.S. dollar. Mac ASPs declined 4% during the first nine months of 2015 compared to the same period in 2014 largely due
to foreign currency weakness relative to the U.S. dollar.

[0001193125-15-259935:mdna:35]
[same as prior period, unchanged from 0001193125-15-153166:mdna:35]

[0001193125-15-259935:mdna:36]
The
following table presents Services net sales information for the three- and nine-month periods ended June 27, 2015 and June 28, 2014 (dollars in millions):

[0001193125-15-259935:mdna:37]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 27,2015 |  |  | June 28,2014 |  |  | Change |  |  | June 27,2015 |  |  | June 28,2014 |  |  | Change |  |
| Net sales |  | $ | 5,028 |  |  | $ | 4,485 |  |  |  | 12% |  |  | $ | 14,823 |  |  | $ | 13,455 |  |  |  | 10% |  |
| Percentage of total net sales |  |  | 10% |  |  |  | 12% |  |  |  |  |  |  |  | 8% |  |  |  | 10% |  |  |  |  |  |

[0001193125-15-259935:mdna:38]
The increase in net sales of Services in the third quarter and first nine months of 2015 compared to the same periods in
2014 was primarily due to growth from iTunes and licensing. iTunes generated a total of $2.7 billion and $8.1 billion in net sales during the third quarter and first nine months of 2015, respectively, compared to $2.6 billion and $7.6 billion during
the third quarter and first nine months of 2014, respectively.

[0001193125-15-259935:mdna:39]
Segment Operating Performance

[0001193125-15-259935:mdna:40]
The Company manages its business primarily on a geographic basis. Accordingly, the Company determined its reportable operating segments, which are
generally based on the location of its customers, to be the Americas, Europe, Greater China, Japan and Rest of Asia Pacific. The Americas segment includes both North and South America. The Europe segment includes European countries, as well as
India, the Middle East and Africa. The Greater China segment includes China, Hong Kong and Taiwan. The Rest of Asia Pacific segment includes Australia and Asian countries, other than those countries included in the Company’s other operating
segments. Each operating segment provides similar hardware and software products and similar services. Further information regarding the Company’s operating segments may be found in Part I, Item 1 of this Form 10-Q in the Notes to
Condensed Consolidated Financial Statements, in Note 11, “Segment Information and Geographic Data.”

[0001193125-15-259935:mdna:41]
[same as prior period, unchanged from 0001193125-15-153166:mdna:41]

[0001193125-15-259935:mdna:42]
The following table presents Americas net sales information for the three- and nine-month periods ended June 27, 2015 and June 28, 2014 (dollars
in millions):

[0001193125-15-259935:mdna:43]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 27,2015 |  |  | June 28,2014 |  |  | Change |  |  | June 27,2015 |  |  | June 28,2014 |  |  | Change |  |
| Net sales |  | $ | 20,209 |  |  | $ | 17,574 |  |  |  | 15% |  |  | $ | 72,091 |  |  | $ | 60,345 |  |  |  | 19% |  |
| Percentage of total net sales |  |  | 41% |  |  |  | 47% |  |  |  |  |  |  |  | 40% |  |  |  | 43% |  |  |  |  |  |

[0001193125-15-259935:mdna:44]
The year-over-year growth in Americas net sales for the third quarter and first nine months of 2015 was driven primarily
by growth in net sales and unit sales of iPhone. The launch of Apple Watch in the third quarter of 2015 also contributed to the growth of Americas net sales.

[0001193125-15-259935:mdna:45]
[same as prior period, unchanged from 0001193125-15-153166:mdna:45]

[0001193125-15-259935:mdna:46]
The following table presents Europe net sales
information for the three- and nine-month periods ended June 27, 2015 and June 28, 2014 (dollars in millions):

[0001193125-15-259935:mdna:47]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 27,2015 |  |  | June 28,2014 |  |  | Change |  |  | June 27,2015 |  |  | June 28,2014 |  |  | Change |  |
| Net sales |  | $ | 10,342 |  |  | $ | 8,659 |  |  |  | 19% |  |  | $ | 39,760 |  |  | $ | 33,935 |  |  |  | 17% |  |
| Percentage of total net sales |  |  | 21% |  |  |  | 23% |  |  |  |  |  |  |  | 22% |  |  |  | 24% |  |  |  |  |  |

[0001193125-15-259935:mdna:48]
The year-over-year increase in Europe net sales for the third quarter and first nine months of 2015 was driven primarily
by growth in net sales and unit sales of iPhone, partially offset by the effect of weakness in foreign currencies relative to the U.S. dollar. The launch of Apple Watch in the third quarter of 2015 also contributed to the growth of Europe net sales.

[0001193125-15-259935:mdna:49]
[same as prior period, unchanged from 0001193125-15-153166:mdna:49]

[0001193125-15-259935:mdna:50]
The following table presents Greater China net sales information for the three- and nine-month periods ended June 27, 2015 and June 28, 2014
(dollars in millions):

[0001193125-15-259935:mdna:51]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 27, 2015 |  |  | June 28, 2014 |  |  | Change |  |  | June 27, 2015 |  |  | June 28, 2014 |  |  | Change |  |
| Net sales |  | $ | 13,230 |  |  | $ | 6,230 |  |  |  | 112% |  |  | $ | 46,197 |  |  | $ | 25,561 |  |  |  | 81% |  |
| Percentage of total net sales |  |  | 27% |  |  |  | 17% |  |  |  |  |  |  |  | 25% |  |  |  | 18% |  |  |  |  |  |

[0001193125-15-259935:mdna:52]
Greater China experienced year-over-year increases in net sales during the third quarter and first nine months of 2015
that were significantly higher than those experienced by the Company overall. iPhone net sales and unit sales grew strongly following the launch of iPhone 6 and 6 Plus in Greater China. The launch of Apple Watch in the third quarter of 2015 also
contributed to the growth of Greater China net sales.

[0001193125-15-259935:mdna:53]
[same as prior period, unchanged from 0001193125-15-153166:mdna:53]

[0001193125-15-259935:mdna:54]
The following table presents Japan net sales information for the three- and nine-month periods ended June 27, 2015 and June 28, 2014 (dollars in
millions):

[0001193125-15-259935:mdna:55]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 27, 2015 |  |  | June 28, 2014 |  |  | Change |  |  | June 27, 2015 |  |  | June 28, 2014 |  |  | Change |  |
| Net sales |  | $ | 2,872 |  |  | $ | 2,627 |  |  |  | 9% |  |  | $ | 11,777 |  |  | $ | 11,719 |  |  |  | 0% |  |
| Percentage of total net sales |  |  | 6% |  |  |  | 7% |  |  |  |  |  |  |  | 6% |  |  |  | 8% |  |  |  |  |  |

[0001193125-15-259935:mdna:56]
The year-over-year increase in Japan net sales in the third quarter of 2015 was driven primarily by growth in net sales
and unit sales of iPhone, whereas Japan net sales were flat in the first nine months of 2015 compared to the same period in 2014. Japan net sales in the third quarter and first nine months of 2015 were negatively impacted by weakness in the Japanese
yen relative to the U.S. dollar.

[0001193125-15-259935:mdna:57]
[same as prior period, unchanged from 0001193125-15-153166:mdna:57]

[0001193125-15-259935:mdna:58]
The
following table presents Rest of Asia Pacific net sales information for the three- and nine-month periods ended June 27, 2015 and June 28, 2014 (dollars in millions):

[0001193125-15-259935:mdna:59]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 27, 2015 |  |  | June 28, 2014 |  |  | Change |  |  | June 27, 2015 |  |  | June 28, 2014 |  |  | Change |  |
| Net sales |  | $ | 2,952 |  |  | $ | 2,342 |  |  |  | 26% |  |  | $ | 12,389 |  |  | $ | 9,112 |  |  |  | 36% |  |
| Percentage of total net sales |  |  | 6% |  |  |  | 6% |  |  |  |  |  |  |  | 7% |  |  |  | 6% |  |  |  |  |  |

[0001193125-15-259935:mdna:60]
The year-over-year increase in Rest of Asia Pacific net sales for the third quarter and first nine months of 2015
primarily reflects strong growth in net sales and unit sales of iPhone, partially offset by the effect of weakness in foreign currencies relative to the U.S. dollar.

[0001193125-15-259935:mdna:61]
[same as prior period, unchanged from 0001193125-15-153166:mdna:61]

[0001193125-15-259935:mdna:62]
Gross margin for the three- and nine-month periods ended June 27, 2015 and June 28, 2014 was as follows (dollars in millions):

[0001193125-15-259935:mdna:63]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 27,2015 |  |  | June 28,2014 |  |  | June 27,2015 |  |  | June 28,2014 |  |
| Net sales |  | $ | 49,605 |  |  | $ | 37,432 |  |  | $ | 182,214 |  |  | $ | 140,672 |  |
| Cost of sales |  |  | 29,924 |  |  |  | 22,697 |  |  |  | 109,136 |  |  |  | 86,144 |  |
| Gross margin |  | $ | 19,681 |  |  | $ | 14,735 |  |  | $ | 73,078 |  |  | $ | 54,528 |  |
| Gross margin percentage |  |  | 39.7% |  |  |  | 39.4% |  |  |  | 40.1% |  |  |  | 38.8% |  |

[0001193125-15-259935:mdna:64]
The increase in the gross margin percentage during the third quarter and first nine months of 2015 compared to the same
periods in 2014 was driven primarily by a favorable shift in mix to products with higher margins and, to a lesser extent, by improved leverage on fixed costs from higher net sales. These positive factors were partially offset primarily by higher
product cost structures and, to a lesser extent, by the effect of weakness in most foreign currencies relative to the U.S. dollar.

[0001193125-15-259935:mdna:65]
The Company
anticipates gross margin during the fourth quarter of 2015 to be between 38.5% and 39.5%. The foregoing statement regarding the Company’s expected gross margin percentage in the fourth quarter of 2015 is forward-looking and could differ from
actual results. The Company’s future gross margins can be impacted by multiple factors including, but not limited to, those set forth in Part II, Item 1A of this Form 10-Q under the heading “Risk Factors” and those described in
this paragraph. In general, the Company believes gross margins will remain under downward pressure due to a variety of factors, including continued industry wide global product pricing pressures, increased competition, compressed product life
cycles, product transitions, potential increases in the cost of components, and potential strengthening of the U.S. dollar, as well as potential increases in the costs of outside manufacturing services and a potential shift in the Company’s
sales mix towards products with lower gross margins. In response to competitive pressures, the Company expects it will continue to take product pricing actions, which would adversely affect gross margins. Gross margins could also be affected by the
Company’s ability to manage product quality and warranty costs effectively and to stimulate demand for certain of its products. Due to the Company’s significant international operations, its financial condition and operating results,
including gross margins, could be significantly affected by fluctuations in exchange rates.

[0001193125-15-259935:mdna:66]
[same as prior period, unchanged from 0001193125-15-153166:mdna:66]

[0001193125-15-259935:mdna:67]
Operating expenses for the three- and nine-month periods ended June 27, 2015 and June 28, 2014 were as follows (dollars in millions):

[0001193125-15-259935:mdna:68]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 27,2015 |  |  | June 28,2014 |  |  | June 27,2015 |  |  | June 28,2014 |  |
| Research and development |  | $ | 2,034 |  |  | $ | 1,603 |  |  | $ | 5,847 |  |  | $ | 4,355 |  |
| Percentage of total net sales |  |  | 4.1% |  |  |  | 4.3% |  |  |  | 3.2% |  |  |  | 3.1% |  |
| Selling, general and administrative |  | $ | 3,564 |  |  | $ | 2,850 |  |  | $ | 10,624 |  |  | $ | 8,835 |  |
| Percentage of total net sales |  |  | 7.2% |  |  |  | 7.6% |  |  |  | 5.8% |  |  |  | 6.3% |  |
| Total operating expenses |  | $ | 5,598 |  |  | $ | 4,453 |  |  | $ | 16,471 |  |  | $ | 13,190 |  |
| Percentage of total net sales |  |  | 11.3% |  |  |  | 11.9% |  |  |  | 9.0% |  |  |  | 9.4% |  |

[0001193125-15-259935:mdna:69]
[same as prior period, unchanged from 0001193125-15-153166:mdna:69]

[0001193125-15-259935:mdna:70]
The
growth in R&D expense during the third quarter and first nine months of 2015 compared to the same periods in 2014 was driven primarily by an increase in headcount and related expenses, including share-based compensation costs, and material costs
to support expanded R&D activities. The Company continues to believe that focused investments in R&D are critical to its future growth and competitive position in the marketplace and are directly related to timely development of new and
enhanced products that are central to the Company’s core business strategy.

[0001193125-15-259935:mdna:71]
[same as prior period, unchanged from 0001193125-15-153166:mdna:71]

[0001193125-15-259935:mdna:72]
The growth in selling, general and administrative expense during the third quarter and first nine months of 2015 compared to the same periods in 2014 was
primarily due to increased headcount and related expenses, including share-based compensation costs, and higher spending on marketing and advertising.

[0001193125-15-259935:mdna:73]
[same as prior period, unchanged from 0001193125-15-153166:mdna:73]

[0001193125-15-259935:mdna:74]
Other income/(expense), net for the three- and nine-month periods ended June 27, 2015 and June 28, 2014 was as follows (dollars in millions):

[0001193125-15-259935:mdna:75]
|  |  | Three Months Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  |  | June 27,2015 |  |  | June 28,2014 |  |  | Change |  |  | June 27,2015 |  |  | June 28,2014 |  |  | Change |  |
| Interest and dividend income |  | $ | 766 |  |  | $ | 439 |  |  |  |  |  |  | $ | 2,095 |  |  | $ | 1,276 |  |  |  |  |  |
| Interest expense |  |  | (201 | ) |  |  | (100 | ) |  |  |  |  |  |  | (495 | ) |  |  | (269 | ) |  |  |  |  |
| Other expense, net |  |  | (175 | ) |  |  | (137 | ) |  |  |  |  |  |  | (754 | ) |  |  | (334 | ) |  |  |  |  |
| Total other income/(expense), net |  | $ | 390 |  |  | $ | 202 |  |  |  | 93% |  |  | $ | 846 |  |  | $ | 673 |  |  |  | 26% |  |

[0001193125-15-259935:mdna:76]
The increase in other income/(expense), net during the third quarter of 2015 compared to the same period in 2014 was due
primarily to higher interest income, partially offset by higher interest expense on debt and higher premium expenses on foreign exchange contracts. The increase in other income/(expense), net during the first nine months of 2015 compared to the same
period in 2014 was due primarily to higher interest income and a gain on strategic investments, partially offset by higher premium expense on foreign exchange contracts, higher interest expense on debt and higher expenses associated with foreign
exchange movements. The weighted-average interest rate earned by the Company on its cash, cash equivalents and marketable securities was 1.51% and 1.09% in the third quarter of 2015 and 2014, respectively, and 1.45% and 1.05% in the first nine
months of 2015 and 2014, respectively.

[0001193125-15-259935:mdna:77]
[same as prior period, unchanged from 0001193125-15-153166:mdna:77]

[0001193125-15-259935:mdna:78]
Provision for income taxes and effective tax rates for the three- and nine-month periods ended June 27, 2015 and June 28, 2014 were as follows
(dollars in millions):

[0001193125-15-259935:mdna:79]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 27,2015 |  |  | June 28,2014 |  |  | June 27,2015 |  |  | June 28,2014 |  |
| Provision for income taxes |  | $ | 3,796 |  |  | $ | 2,736 |  |  | $ | 15,183 |  |  | $ | 10,968 |  |
| Effective tax rate |  |  | 26.2% |  |  |  | 26.1% |  |  |  | 26.4% |  |  |  | 26.1% |  |

[0001193125-15-259935:mdna:80]
The Company’s effective tax rates for the third quarter and first nine months of 2015 and 2014 differ from the
statutory federal income tax rate of 35% due primarily to certain undistributed foreign earnings, a substantial portion of which was generated by subsidiaries organized in Ireland, for which no U.S. taxes are provided because such earnings are
intended to be indefinitely reinvested outside the U.S. The higher effective tax rates during the third quarter and first nine months of 2015 as compared to the same periods in 2014 are due primarily to higher foreign taxes.

[0001193125-15-259935:mdna:81]
[same as prior period, unchanged from 0001193125-15-153166:mdna:81]

[0001193125-15-259935:mdna:82]
On June 11, 2014, the European Commission issued an opening decision initiating a formal investigation against Ireland for alleged state aid to the
Company. The opening decision concerns the allocation of profits for taxation purposes of the Irish branches of two subsidiaries of the Company. The Company believes the European Commission’s assertions are without merit. If the European
Commission were to conclude against Ireland, the European Commission could require Ireland to recover from the Company past taxes covering a period of up to 10 years reflective of the disallowed state aid. While such amount could be material, as of
June 27, 2015 the Company is unable to estimate the impact.

[0001193125-15-259935:mdna:83]
[same as prior period, unchanged from 0001193125-15-153166:mdna:83]

[0001193125-15-259935:mdna:84]
In May 2014, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update No. 2014-09, Revenue from Contracts with
Customers (Topic 606) (“ASU 2014-09”), which amends the existing accounting standards for revenue recognition. ASU 2014-09 is based on principles that govern the recognition of revenue at an amount an entity expects to be entitled when
products are transferred to customers.

[0001193125-15-259935:mdna:85]
The original effective date for ASU 2014-09 would have required the Company to adopt beginning in its first
quarter of 2018. In July 2015, the FASB voted to amend ASU 2014-09 by approving a one-year deferral of the effective date as well as providing the option to early adopt the standard on the original effective date. Accordingly, the Company may adopt
the standard in either its first quarter of 2018 or 2019. The new revenue standard may be applied retrospectively to each prior period presented or retrospectively with the cumulative effect recognized as of the date of adoption. The Company is
currently evaluating the timing of its adoption and the impact of adopting the new revenue standard on its consolidated financial statements.

[0001193125-15-259935:mdna:86]
Liquidity and
Capital Resources

[0001193125-15-259935:mdna:87]
The following tables present selected financial information and statistics as of June 27, 2015 and September 27, 2014
and during the first nine months of 2015 and 2014 (in millions):

[0001193125-15-259935:mdna:88]
|  |  | June 27, 2015 |  |  | September 27, 2014 |  |
| Cash, cash equivalents and marketable securities |  | $ | 202,848 |  |  | $ | 155,239 |  |
| Property, plant and equipment, net |  | $ | 21,149 |  |  | $ | 20,624 |  |
| Commercial paper |  | $ | 4,499 |  |  | $ | 6,308 |  |
| Total term debt |  | $ | 49,919 |  |  | $ | 28,987 |  |
| Working capital |  | $ | 5,668 |  |  | $ | 5,083 |  |
|  |  | Nine Months Ended |  |
|  |  | June 27, 2015 |  |  | June 28, 2014 |  |
| Cash generated by operating activities |  | $ | 67,791 |  |  | $ | 46,463 |  |
| Cash used in investing activities |  | $ | (54,899 | ) |  | $ | (25,576 | ) |
| Cash used in financing activities |  | $ | (11,417 | ) |  | $ | (22,169 | ) |

[0001193125-15-259935:mdna:89]
[same as prior period, unchanged from 0001193125-15-153166:mdna:89]

[0001193125-15-259935:mdna:90]
As of June 27, 2015 and September 27, 2014, the Company’s cash, cash equivalents and marketable securities held by foreign subsidiaries
were $181.1 billion and $137.1 billion, respectively, and are generally based in U.S. dollar-denominated holdings. Amounts held by foreign subsidiaries are generally subject to U.S. income taxation on
repatriation to the U.S. The Company’s marketable securities investment portfolio is invested primarily in highly-rated securities and its investment policy generally limits the amount of credit exposure to any one issuer. The policy requires
investments generally to be investment grade with the objective of minimizing the potential risk of principal loss.

[0001193125-15-259935:mdna:91]
During the nine months ended
June 27, 2015, cash generated from operating activities of $67.8 billion was a result of $42.3 billion of net income, non-cash adjustments to net income of $13.6 billion and an increase in the net change in operating assets and liabilities of
$11.9 billion. Cash used in investing activities of $54.9 billion during the nine months ended June 27, 2015 consisted primarily of cash used for purchases of marketable securities, net of sales and maturities, of $47.0 billion and cash used to
acquire property, plant and equipment of $7.6 billion. Cash used in financing activities of $11.4 billion during the nine months ended June 27, 2015 consisted primarily of cash used to repurchase common stock of $22.0 billion, cash used to pay
dividends and dividend equivalents of $8.6 billion and cash used for repayments of commercial paper, net of $1.8 billion, partially offset by proceeds from the issuance of long-term debt, net of $21.3 billion.

[0001193125-15-259935:mdna:92]
During the nine months ended June 28, 2014, cash generated from operating activities of $46.5 billion was a result of $31.0 billion of net income,
non-cash adjustments to net income of $11.2 billion and an increase in net change in operating assets and liabilities of $4.2 billion. Cash used in investing activities of $25.6 billion during the nine months ended June 28, 2014 consisted
primarily of cash used for purchases of marketable securities, net of sales and maturities, of $18.7 billion and cash used to acquire property, plant and equipment of $5.7 billion. Cash used in financing activities of $22.2 billion during the nine
months ended June 28, 2014 consisted primarily of cash used to repurchase common stock of $28.0 billion and cash used to pay dividends and dividend equivalents of $8.3 billion, partially offset by proceeds from the issuance of long-term debt
and commercial paper of $12.0 billion and $2.0 billion, respectively.

[0001193125-15-259935:mdna:93]
[same as prior period, unchanged from 0001193125-15-153166:mdna:93]

[0001193125-15-259935:mdna:94]
The Company’s capital expenditures were $7.3 billion during the first nine months of 2015. The Company anticipates utilizing approximately $12.0
billion for capital expenditures during 2015, which includes product tooling and manufacturing process equipment; data centers; corporate facilities and infrastructure, including information systems hardware, software and enhancements; and retail
store facilities.

[0001193125-15-259935:mdna:95]
[same as prior period, unchanged from 0001193125-15-153166:mdna:95]

[0001193125-15-259935:mdna:96]
In 2014, the Board of Directors
authorized the Company to issue unsecured short-term promissory notes (“Commercial Paper”) pursuant to a commercial paper program. The Company intends to use the net proceeds from the commercial paper program for general corporate
purposes, including dividends and share repurchases. As of June 27, 2015, the Company had $4.5 billion of Commercial Paper outstanding, with a weighted-average interest rate of 0.10% and maturities generally less than nine months.

[0001193125-15-259935:mdna:97]
As of June 27, 2015, the Company has outstanding floating- and fixed-rate notes with varying maturities for an aggregate principal amount of $50.0
billion (collectively the “Notes”). The Company has entered, and in the future may enter, into interest rate swaps to manage interest rate risk on the Notes. Interest rate swaps allow the Company to effectively convert fixed-rate payments
into floating-rate payments or floating-rate payments into fixed-rate payments. In addition, the Company has entered, and in the future may enter, into currency swaps to manage foreign currency risk on the Notes. The Company issued €2.8 billion of euro-denominated notes in the first quarter of 2015, $6.5 billion of U.S. dollar-denominated notes and SFr1.3 billion of Swiss franc-denominated notes in the second quarter of 2015 and
$8.0 billion of U.S. dollar-denominated notes and ¥250.0 billion of yen-denominated notes in the third quarter of 2015. To manage foreign currency risk associated with the euro-denominated notes issued in the first quarter of 2015, the Company
entered into currency swaps with an aggregate notional amount of $3.5 billion, which effectively converted the euro-denominated notes to U.S. dollar-denominated notes. To manage interest rate risk on the U.S. dollar-denominated fixed-rate notes
issued in the second quarter of 2015 and maturing in 2020 and 2022, the Company entered into interest rate swaps with an aggregate notional amount of $2.5 billion. To manage interest rate risk on the U.S. dollar-denominated fixed-rate notes issued
in the third quarter of 2015 and maturing in 2017, 2020, 2022 and 2025, the Company entered into interest rate swaps with an aggregate notional amount of $4.3 billion. These interest rate swaps effectively converted the fixed interest rates on the
U.S. dollar-denominated notes to a floating interest rate.

[0001193125-15-259935:mdna:98]
[same as prior period, unchanged from 0001193125-15-153166:mdna:98]

[0001193125-15-259935:mdna:99]
In April 2015, the Company’s Board of Directors increased the share repurchase program authorization from $90 billion to $140 billion of the
Company’s common stock, increasing the size of the total capital return program to $200 billion. The Company expects to execute the capital return program by the end of March 2017 by paying dividends and dividend equivalents, repurchasing
shares and remitting withheld taxes related to net share settlement of restricted stock units. To assist in funding its capital return program, the Company expects to continue to access the debt markets, both domestically and internationally. As of
June 27, 2015, $90.0 billion of the share repurchase program has been utilized. The Company’s share repurchase program does not obligate it to acquire any specific number of shares. Under the program, shares may be repurchased in privately
negotiated or open market transactions, including under plans complying with Rule 10b5-1 under the Exchange Act.

[0001193125-15-259935:mdna:100]
In April 2015, the Company’s
Board of Directors raised the quarterly cash dividend by 11%. The Company paid cash dividends of $0.52 per share, totaling $3.0 billion, in May 2015. The Company plans to increase its dividend on an annual basis subject to declaration by the Board
of Directors.

[0001193125-15-259935:mdna:101]
The following table presents the Company’s dividends, dividend equivalents, share repurchases and net share settlement activity
from the start of the capital return program in August 2012 through June 27, 2015 (in millions):

[0001193125-15-259935:mdna:102]
|  |  | Dividends andDividendEquivalentsPaid |  |  | AcceleratedShareRepurchases |  |  | Open MarketShareRepurchases |  |  | TaxesRelated toSettlement ofEquity Awards |  |  | Total |  |
| Q3 2015 |  | $ | 3,053 |  |  | $ | 6,000 |  |  | $ | 4,000 |  |  | $ | 724 |  |  | $ | 13,777 |  |
| Q2 2015 |  |  | 2,743 |  |  |  | 0 |  |  |  | 7,000 |  |  |  | 96 |  |  |  | 9,839 |  |
| Q1 2015 |  |  | 2,801 |  |  |  | 0 |  |  |  | 5,000 |  |  |  | 512 |  |  |  | 8,313 |  |
| 2014 |  |  | 11,126 |  |  |  | 21,000 |  |  |  | 24,000 |  |  |  | 1,158 |  |  |  | 57,284 |  |
| 2013 |  |  | 10,564 |  |  |  | 13,950 |  |  |  | 9,000 |  |  |  | 1,082 |  |  |  | 34,596 |  |
| 2012 |  |  | 2,488 |  |  |  | 0 |  |  |  | 0 |  |  |  | 56 |  |  |  | 2,544 |  |
| Total |  | $ | 32,775 |  |  | $ | 40,950 |  |  | $ | 49,000 |  |  | $ | 3,628 |  |  | $ | 126,353 |  |

[0001193125-15-259935:mdna:103]
[same as prior period, unchanged from 0001193125-15-153166:mdna:104]

[0001193125-15-259935:mdna:104]
[same as prior period, unchanged from 0001193125-15-153166:mdna:105]

[0001193125-15-259935:mdna:105]
[same as prior period, unchanged from 0001193125-15-153166:mdna:106]

[0001193125-15-259935:mdna:106]
The Company’s major facility leases are typically for terms not exceeding 10 years and generally contain multi-year renewal options. As of
June 27, 2015, the Company had a total of 456 retail stores. Leases for retail space are for terms ranging from five to 20 years, the majority of which are for 10 years, and often contain multi-year renewal options. As of June 27, 2015,
the Company’s total future minimum lease payments under noncancelable operating leases were $5.0 billion, of which $3.4 billion related to leases for retail space.

[0001193125-15-259935:mdna:107]
[same as prior period, unchanged from 0001193125-15-153166:mdna:108]

[0001193125-15-259935:mdna:108]
The Company utilizes several outsourcing
partners to manufacture sub-assemblies for the Company’s products and to perform final assembly and testing of finished products. These outsourcing partners acquire components and build product based on demand information supplied by the
Company, which typically covers periods up to 150 days. The Company also obtains individual components for its products from a wide variety of individual suppliers. Consistent with industry practice, the Company acquires components through a
combination of purchase orders, supplier contracts, and open orders based on projected demand information. Where appropriate, the purchases are applied to inventory component prepayments that are outstanding with
the respective supplier. As of June 27, 2015, the Company had outstanding off-balance sheet third-party manufacturing commitments and component purchase commitments of $21.7 billion.

[0001193125-15-259935:mdna:109]
[same as prior period, unchanged from 0001193125-15-153166:mdna:110]

[0001193125-15-259935:mdna:110]
In addition to the commitments mentioned
above, the Company had other off-balance sheet obligations of $4.8 billion as of June 27, 2015 that consisted of commitments to acquire capital assets, including product tooling and manufacturing process equipment, and commitments related to
advertising, R&D, internet and telecommunications services, energy and other obligations. Subsequent to June 27, 2015, the Company entered into additional other off-balance sheet obligations of $2.1 billion.

[0001193125-15-259935:mdna:111]
The Company’s other non-current liabilities in the Condensed Consolidated Balance Sheets consist primarily of deferred tax liabilities, gross
unrecognized tax benefits and the related gross interest and penalties. As of June 27, 2015, the Company had non-current deferred tax liabilities of $24.5 billion. Additionally, as of June 27, 2015, the Company had gross unrecognized tax
benefits of $5.4 billion and an additional $928 million for gross interest and penalties classified as non-current liabilities. At this time, the Company is unable to make a reasonably reliable estimate of the timing of payments due to uncertainties
in the timing of tax audit outcomes.

[0001193125-15-259935:mdna:112]
[same as prior period, unchanged from 0001193125-15-153166:mdna:113]

[0001193125-15-259935:mdna:113]
The
Company generally does not indemnify end-users of its operating system and application software against legal claims that the software infringes third-party intellectual property rights. Other agreements entered into by the Company sometimes include
indemnification provisions under which the Company could be subject to costs and/or damages in the event of an infringement claim against the Company or an indemnified third-party. However, the Company has not been required to make any significant
payments resulting from such an infringement claim asserted against it or an indemnified third-party. In the opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss with respect to
indemnification of end-users of its operating system or application software for infringement of third-party intellectual property rights. The Company did not record a liability for infringement costs related to indemnification as of June 27,
2015 or September 27, 2014.

[0001193125-15-259935:mdna:114]
The Company has entered into indemnification agreements with its directors and executive officers. Under these
agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in
connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the
unique facts and circumstances involved in each claim. However, the Company maintains directors and officers liability insurance coverage to reduce its exposure to such obligations, and payments made under these agreements historically have not been
material.

[0001193125-15-259935:mdna:115]
[same as prior period, unchanged from 0001193125-15-153166:mdna:116]

[0001193125-15-259935:mdna:116]
[same as prior period, unchanged from 0001193125-15-153166:mdna:117]

[0001193125-15-259935:mdna:117]
Management believes the Company’s critical accounting policies
and estimates are those related to revenue recognition, valuation and impairment of marketable securities, inventory valuation and valuation of manufacturing-related assets and estimated purchase commitment cancellation fees, warranty costs, income
taxes, and legal and other contingencies. Management considers these policies critical because they are both important to the portrayal of the Company’s financial condition and operating results, and they require management to make judgments
and estimates about inherently uncertain matters. The Company’s senior management has reviewed these critical accounting policies and related disclosures with the Audit and Finance Committee of the Company’s Board of Directors.

[0001193125-15-259935:mdna:118]
[same as prior period, unchanged from 0001193125-15-153166:mdna:119]

[0001193125-15-259935:mdna:119]
[same as prior period, unchanged from 0001193125-15-153166:mdna:120]

[0001193125-15-259935:mdna:120]
[same as prior period, unchanged from 0001193125-15-153166:mdna:121]

[0001193125-15-259935:mdna:121]
For sales of
qualifying versions of iOS devices, Mac, Apple Watch and Apple TV, the Company has indicated it may from time to time provide future unspecified software upgrades and features free of charge to customers. The Company also provides various
non-software services to owners of qualifying versions of iOS devices and Mac. Because the Company has neither VSOE nor TPE for the unspecified software upgrade rights or the non-software services, revenue is allocated to these rights and services
based on the Company’s ESPs. Revenue allocated to the unspecified software upgrade rights and non-software services based on the Company’s ESPs is deferred and recognized on a straight-line basis over the estimated period the software
upgrades and non-software services are expected to be provided for each of these devices, which ranges from two to four years.

[0001193125-15-259935:mdna:122]
The Company’s
process for determining ESPs involves management’s judgment and considers multiple factors that may vary over time depending upon the unique facts and circumstances related to each deliverable. Should future facts and circumstances change, the
Company’s ESPs and the future rate of related amortization for software upgrades and non-software services related to future sales of these devices could change. Factors subject to change include the unspecified software upgrade rights offered,
the estimated value of unspecified software upgrade rights, the estimated or actual costs incurred to provide non-software services and the estimated period software upgrades and non-software services are expected to be provided.

[0001193125-15-259935:mdna:123]
[same as prior period, unchanged from 0001193125-15-153166:mdna:124]

[0001193125-15-259935:mdna:124]
[same as prior period, unchanged from 0001193125-15-153166:mdna:125]

[0001193125-15-259935:mdna:125]
[same as prior period, unchanged from 0001193125-15-153166:mdna:126]

[0001193125-15-259935:mdna:126]
[same as prior period, unchanged from 0001193125-15-153166:mdna:127]

[0001193125-15-259935:mdna:127]
[same as prior period, unchanged from 0001193125-15-153166:mdna:128]

[0001193125-15-259935:mdna:128]
The industries in which the Company competes are subject to a rapid and
unpredictable pace of product and component obsolescence and demand changes. In certain circumstances the Company may be required to record additional write-downs of inventory, inventory prepayments and/or manufacturing-related capital assets. These
circumstances include future demand or market conditions for the Company’s products being less favorable than forecasted, unforeseen technological changes or changes to the Company’s product development plans that negatively impact the
utility of any of these assets, or significant deterioration in the financial condition of one or more of the Company’s suppliers that hold any of the Company’s manufacturing process equipment or to whom the Company has made an inventory
prepayment. Such write-downs would adversely affect the Company’s financial condition and operating results in the period when the write-downs were recorded.

[0001193125-15-259935:mdna:129]
The Company records accruals for estimated cancellation fees related to component orders that have been cancelled or are expected to be cancelled.
Consistent with industry practice, the Company acquires components through a combination of purchase orders, supplier contracts, and open orders in each case based on projected demand. Where appropriate, the purchases are applied to inventory
component prepayments that are outstanding with the respective supplier. Purchase commitments typically cover the Company’s forecasted component and manufacturing requirements for periods up to 150 days. If there is an abrupt and
substantial decline in demand for one or more of the Company’s products, if the Company’s product development plans change, or if there is an unanticipated change in technological requirements for any of the Company’s products, then
the Company may be required to record additional accruals for cancellation fees that would adversely affect its results of operations in the period when the cancellation fees are identified and recorded.

[0001193125-15-259935:mdna:130]
[same as prior period, unchanged from 0001193125-15-153166:mdna:131]

[0001193125-15-259935:mdna:131]
The Company provides for the estimated cost of warranties at the time the related revenue is recognized based on historical and projected warranty claim
rates, historical and projected cost-per-claim and knowledge of specific product failures that are outside of the Company’s typical experience. Each quarter, the Company re-evaluates these estimates to assess the adequacy of its recorded
warranty liabilities considering the size of the installed base of products subject to warranty protection and adjusts the amounts as necessary. If actual product failure rates or repair costs differ from estimates, revisions to the estimated
warranty liabilities would be required and could materially affect the Company’s financial condition and operating results.

[0001193125-15-259935:mdna:132]
[same as prior period, unchanged from 0001193125-15-153166:mdna:133]

[0001193125-15-259935:mdna:133]
[same as prior period, unchanged from 0001193125-15-153166:mdna:134]

[0001193125-15-259935:mdna:134]
[same as prior period, unchanged from 0001193125-15-153166:mdna:135]

[0001193125-15-259935:mdna:135]
[same as prior period, unchanged from 0001193125-15-153166:mdna:136]

[0001193125-15-259935:mdna:136]
Legal and Other Contingencies

[0001193125-15-259935:mdna:137]
As discussed in Part II, Item 1 of this Form 10-Q under the heading “Legal Proceedings” and in Part I, Item 1 of this Form 10-Q in the
Notes to Condensed Consolidated Financial Statements, in Note 10, “Commitments and Contingencies,” the Company is subject to various legal proceedings and claims that arise in the ordinary course of business. The Company records a
liability when it is probable that a loss has been incurred and the amount is reasonably estimable. There is significant judgment required in both the probability determination and as to whether an exposure can be reasonably estimated. In the
opinion of management, there was not at least a reasonable possibility the Company may have incurred a material loss, or a material loss in excess of a recorded accrual, with respect to loss contingencies for legal and other contingencies. However,
the outcome of legal proceedings and claims brought against the Company is subject to significant uncertainty. Therefore, although management considers the likelihood of such an outcome to be remote, if one or more of these legal matters were
resolved against the Company in a reporting period for amounts in excess of management’s expectations, the Company’s consolidated financial statements for that reporting period could be materially adversely affected.
