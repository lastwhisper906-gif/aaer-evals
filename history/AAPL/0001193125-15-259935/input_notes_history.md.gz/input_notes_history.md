# AAPL note change history — 0001193125-15-153166 → 0001193125-15-259935


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-07-22):
[0001193125-15-259935:note_history:1]
The following table shows changes in the
 Company’s accrued warranties and related costs for the three-
 and nine-month periods ended June 27, 2015 and June 28,
 2014 (in millions):
  (was, 2015-04-28, similarity 0.9318):
[0001193125-15-153166:note_history:1]
The following table shows changes in the
 Company’s accrued warranties and related costs for the three-
 and six-month periods ended March 28, 2015 and March 29,
 2014 (in millions):

- changed (2015-07-22):
[0001193125-15-259935:note_history:2]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 27, 2015 |  |  | June 28, 2014 |  |  | June 27, 2015 |  |  | June 28, 2014 |  |
| Beginning accrued warranty and related costs |  | $ | 5,143 |  |  | $ | 4,368 |  |  | $ | 4,159 |  |  | $ | 2,967 |  |
| Cost of warranty claims |  |  | (1,077 | ) |  |  | (882 | ) |  |  | (3,151 | ) |  |  | (2,811 | ) |
| Accruals for product warranty |  |  | 1,071 |  |  |  | 756 |  |  |  | 4,129 |  |  |  | 4,086 |  |
| Ending accrued warranty and related costs |  | $ | 5,137 |  |  | $ | 4,242 |  |  | $ | 5,137 |  |  | $ | 4,242 |  |
  (was, 2015-04-28, similarity 0.8324):
[0001193125-15-153166:note_history:2]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 28, 2015 |  |  | March 29, 2014 |  |  | March 28, 2015 |  |  | March 29, 2014 |  |
| Beginning accrued warranty and related costs |  | $ | 5,195 |  |  | $ | 3,980 |  |  | $ | 4,159 |  |  | $ | 2,967 |  |
| Cost of warranty claims |  |  | (1,030 | ) |  |  | (865 | ) |  |  | (2,074 | ) |  |  | (1,929 | ) |
| Accruals for product warranty |  |  | 978 |  |  |  | 1,253 |  |  |  | 3,058 |  |  |  | 3,330 |  |
| Ending accrued warranty and related costs |  | $ | 5,143 |  |  | $ | 4,368 |  |  | $ | 5,143 |  |  | $ | 4,368 |  |

- changed (2015-07-22):
[0001193125-15-259935:note_history:3]
The Company generally does not indemnify end-users
 of its operating system and application software against legal
 claims that the software infringes third-party intellectual
 property rights. Other agreements entered into by the Company
 sometimes include indemnification provisions under which the
 Company could be subject to costs and/or damages in the event of an
 infringement claim against the Company or an indemnified
 third-party. However, the Company has not been required to make any
 significant payments resulting from such an infringement claim
 asserted against it or an indemnified third-party. In the opinion
 of management, there was not at least a reasonable possibility the
 Company may have incurred a material loss with respect to
 indemnification of end-users of its operating system or application
 software for infringement of third-party intellectual property
 rights. The Company did not record a liability for infringement
 costs related to indemnification as of June 27, 2015 or
 September 27, 2014.
  (was, 2015-04-28, similarity 0.9955):
[0001193125-15-153166:note_history:3]
The Company generally does not indemnify end-users
 of its operating system and application software against legal
 claims that the software infringes third-party intellectual
 property rights. Other agreements entered into by the Company
 sometimes include indemnification provisions under which the
 Company could be subject to costs and/or damages in the event of an
 infringement claim against the Company or an indemnified
 third-party. However, the Company has not been required to make any
 significant payments resulting from such an infringement claim
 asserted against it or an indemnified third-party. In the opinion
 of management, there was not at least a reasonable possibility the
 Company may have incurred a material loss with respect to
 indemnification of end-users of its operating system or application
 software for infringement of third-party intellectual property
 rights. The Company did not record a liability for infringement
 costs related to indemnification as of March 28, 2015 or
 September 27, 2014.

- added (2015-07-22):
[0001193125-15-259935:note_history:4]
The Company leases various equipment and
 facilities, including retail space, under noncancelable operating
 lease arrangements. The Company does not currently utilize any
 other off-balance sheet financing arrangements. The major facility
 leases are typically for terms not exceeding 10 years and generally
 contain multi-year renewal options. As of June 27, 2015, the
 Company had a total of 456 retail stores. Leases for retail space
 are for terms ranging from five to 20 years, the majority of which
 are for 10 years, and often contain multi-year renewal options. As
 of June 27, 2015, the Company’s total future minimum
 lease payments under noncancelable operating leases were $5.0
 billion, of which $3.4 billion related to leases for retail
 space.

- changed (2015-07-22):
[0001193125-15-259935:note_history:5]
The Company utilizes several outsourcing partners
 to manufacture sub-assemblies for the Company’s products and
 to perform final assembly and testing of finished products. These
 outsourcing partners acquire components and build product based on
 demand information supplied by the Company, which typically covers
 periods up to 150 days. The Company also obtains individual
 components for its products from a wide variety of individual
 suppliers. Consistent with industry practice, the Company acquires
 components through a combination of purchase orders, supplier
 contracts and open orders based on projected demand information.
 Where appropriate, the purchases are applied
 to inventory component prepayments that
 are outstanding with the respective supplier. As of
 June 27, 2015, the Company had outstanding off-balance sheet
 third-party manufacturing commitments and component purchase
 commitments of $21.7 billion.
  (was, 2015-04-28, similarity 0.995):
[0001193125-15-153166:note_history:5]
The Company utilizes several outsourcing partners
 to manufacture sub-assemblies for the Company’s products and
 to perform final assembly and testing of finished products. These
 outsourcing partners acquire components and build product based on
 demand information supplied by the Company, which typically covers
 periods up to 150 days. The Company also obtains individual
 components for its products from a wide variety of individual
 suppliers. Consistent with industry practice, the Company acquires
 components through a combination of purchase orders, supplier
 contracts and open orders based on projected demand information.
 Where appropriate, the purchases are applied
 to inventory component prepayments that
 are outstanding with the respective supplier. As of
 March 28, 2015, the Company had outstanding off-balance sheet
 third-party manufacturing commitments and component purchase
 commitments of $19.0 billion.

- changed (2015-07-22):
[0001193125-15-259935:note_history:6]
In addition to the commitments mentioned above, the
 Company had other off-balance sheet obligations of $4.8 billion as
 of June 27, 2015 that consisted of commitments to acquire
 capital assets, including product tooling and manufacturing process
 equipment, and commitments related to advertising, research and
 development (“R&D”), internet and
 telecommunications services, energy and other obligations.
 Subsequent to June 27, 2015, the Company entered into
 additional other off-balance sheet obligations of $2.1 billion.
  (was, 2015-04-28, similarity 0.8354):
[0001193125-15-153166:note_history:6]
In addition to the commitments mentioned above, the
 Company had other off-balance sheet obligations of $4.1 billion as
 of March 28, 2015, which were comprised of commitments to
 acquire capital assets, including product tooling and manufacturing
 process equipment, and commitments related to advertising, research
 and development (“R&D”), Internet and
 telecommunications services, energy and other obligations.

- changed (2015-07-22):
[0001193125-15-259935:note_history:7]
On May 29, 2013, Smartflash LLC and Smartflash
 Technologies Limited filed an action against the Company in the
 United States District Court for the Eastern District of Texas,
 Tyler Division, alleging that the Company infringed certain patents
 relating to data storage and access systems. On February 24,
 2015, a jury returned a verdict against the Company, and awarded
 damages of approximately $533 million. On July 7, 2015, the
 District Court vacated the award and ordered a new trial for
 damages. Accordingly, the Company has not recorded a loss accrual
 at this time.
  (was, 2015-04-28, similarity 0.7444):
[0001193125-15-153166:note_history:7]
On May 29, 2013, Smartflash LLC and Smartflash
 Technologies Limited filed an action against the Company in the
 United States District Court for the Eastern District of Texas,
 Tyler Division, alleging that the Company infringed certain patents
 relating to data storage and access systems. On February 24,
 2015, a jury returned a verdict against the Company, and awarded
 damages of approximately $533 million. The Company is challenging
 the verdict, believes it has valid defenses and has not recorded a
 loss accrual at this time.

- added (2015-07-22):
[0001193125-15-259935:note_history:8]
On August 24, 2012, a jury returned a verdict
 awarding the Company $1.05 billion in its lawsuit against Samsung
 Electronics Co., Ltd and affiliated parties in the United States
 District Court, Northern District of California, San Jose Division.
 On March 6, 2014, the District Court entered final judgment in
 favor of the Company in the amount of approximately $930
 million. On May 18, 2015, the U.S. Court of Appeals for
 the Federal Circuit affirmed in part, and reversed in part, the
 decision of the District Court. As a result, the Court of Appeals
 ordered entry of final judgment on damages in the amount of
 approximately $548 million, with the District Court to determine
 supplemental damages and interest, as well as damages owed for
 products subject to the reversal in part. Because the ruling
 remains subject to further proceedings, the Company has not
 recognized the award in its results of operations.

- removed (2015-07-22):
[0001193125-15-153166:note_history:9]
The Company leases various equipment and
 facilities, including retail space, under noncancelable operating
 lease arrangements. The Company does not currently utilize any
 other off-balance sheet financing arrangements. The major facility
 leases are typically for terms not exceeding 10 years and generally
 contain multi-year renewal options. As of March 28, 2015, the
 Company had a total of 453 retail stores. Leases for retail space
 are for terms ranging from five to 20 years, the majority of which
 are for 10 years, and often contain multi-year renewal options. As
 of March 28, 2015, the Company’s total future minimum
 lease payments under noncancelable operating leases were $5.1
 billion, of which $3.4 billion related to leases for retail
 space.

- removed (2015-07-22):
[0001193125-15-153166:note_history:10]
On August 24, 2012, a jury returned a verdict
 awarding the Company $1.05 billion in its lawsuit against Samsung
 Electronics Co., Ltd and affiliated parties in the United States
 District Court, Northern District of California, San Jose Division.
 On March 6, 2014, the District Court entered final judgment in
 favor of the Company in the amount of approximately $930
 million. Because the award is now subject to appeal, the
 Company has not recognized the award in its results of
 operations.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-07-22):
[0001193125-15-259935:note_history:11]
Apple Inc. and its wholly-owned subsidiaries
 (collectively “Apple” or the “Company”)
 designs, manufactures and markets mobile communication and media
 devices, personal computers and portable digital music players, and
 sells a variety of related software, services, accessories,
 networking solutions and third-party digital content and
 applications. The Company sells its products worldwide through its
 retail stores, online stores and direct sales force, as well as
 through third-party cellular network carriers, wholesalers,
 retailers and value-added resellers. In addition, the Company sells
 a variety of third-party Apple compatible products, including
 application software and various accessories through its online and
 retail stores. The Company sells to consumers, small and mid-sized
 businesses and education, enterprise and government customers.
  (was, 2015-04-28, similarity 0.9815):
[0001193125-15-153166:note_history:11]
Apple Inc. and its wholly-owned subsidiaries
 (collectively “Apple” or the “Company”)
 designs, manufactures and markets mobile communication and media
 devices, personal computers and portable digital music players, and
 sells a variety of related software, services, accessories,
 networking solutions and third-party digital content and
 applications. The Company sells its products worldwide through its
 retail stores, online stores and direct sales force, as well as
 through third-party cellular network carriers, wholesalers,
 retailers and value-added resellers. In addition, the Company sells
 a variety of third-party iPhone, iPad, Mac and iPod compatible
 products, including application software, and various accessories
 through its online and retail stores. The Company sells to
 consumers, small and mid-sized businesses and education, enterprise
 and government customers.

- changed (2015-07-22):
[0001193125-15-259935:note_history:12]
The accompanying condensed consolidated financial
 statements include the accounts of the Company. Intercompany
 accounts and transactions have been eliminated. In the opinion of
 the Company’s management, the condensed consolidated
 financial statements reflect all adjustments, which are normal and
 recurring in nature, necessary for fair financial statement
 presentation. The preparation of these condensed consolidated
 financial statements in conformity with U.S. generally accepted
 accounting principles (“GAAP”) requires management to
 make estimates and assumptions that affect the amounts reported in
 these condensed consolidated financial statements and accompanying
 notes. Actual results could differ materially from those
 estimates.
  (was, 2015-04-28, similarity 0.8323):
[0001193125-15-153166:note_history:12]
The accompanying condensed consolidated financial
 statements include the accounts of the Company. Intercompany
 accounts and transactions have been eliminated. The preparation of
 these condensed consolidated financial statements in conformity
 with U.S. generally accepted accounting principles
 (“GAAP”) requires management to make estimates and
 assumptions that affect the amounts reported in these condensed
 consolidated financial statements and accompanying notes. Actual
 results could differ materially from those estimates.

- changed (2015-07-22):
[0001193125-15-259935:note_history:13]
The following table shows the computation of basic
 and diluted earnings per share for the three- and nine-month
 periods ended June 27, 2015 and June 28, 2014 (net income
 in millions and shares in thousands):
  (was, 2015-04-28, similarity 0.9418):
[0001193125-15-153166:note_history:13]
The following table shows the computation of basic
 and diluted earnings per share for the three- and six-month periods
 ended March 28, 2015 and March 29, 2014 (net income in
 millions and shares in thousands):

- changed (2015-07-22):
[0001193125-15-259935:note_history:14]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | June 27, 2015 |  |  | June 28, 2014 |  |  | June 27, 2015 |  |  | June 28, 2014 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 10,677 |  |  | $ | 7,748 |  |  | $ | 42,270 |  |  | $ | 31,043 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding |  |  | 5,729,886 |  |  |  | 6,012,635 |  |  |  | 5,788,922 |  |  |  | 6,136,147 |  |
| Effect of dilutive securities |  |  | 43,213 |  |  |  | 39,076 |  |  |  | 40,998 |  |  |  | 36,710 |  |
| Weighted-average diluted shares |  |  | 5,773,099 |  |  |  | 6,051,711 |  |  |  | 5,829,920 |  |  |  | 6,172,857 |  |
| Basic earnings per share |  | $ | 1.86 |  |  | $ | 1.29 |  |  | $ | 7.30 |  |  | $ | 5.06 |  |
| Diluted earnings per share |  | $ | 1.85 |  |  | $ | 1.28 |  |  | $ | 7.25 |  |  | $ | 5.03 |  |
  (was, 2015-04-28, similarity 0.8815):
[0001193125-15-153166:note_history:14]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | March 28, 2015 |  |  | March 29, 2014 |  |  | March 28, 2015 |  |  | March 29, 2014 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 13,569 |  |  | $ | 10,223 |  |  | $ | 31,593 |  |  | $ | 23,295 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding |  |  | 5,793,799 |  |  |  | 6,123,302 |  |  |  | 5,818,441 |  |  |  | 6,197,903 |  |
| Effect of dilutive securities |  |  | 41,059 |  |  |  | 33,397 |  |  |  | 39,889 |  |  |  | 35,527 |  |
| Weighted-average diluted shares |  |  | 5,834,858 |  |  |  | 6,156,699 |  |  |  | 5,858,330 |  |  |  | 6,233,430 |  |
| Basic earnings per share |  | $ | 2.34 |  |  | $ | 1.67 |  |  | $ | 5.43 |  |  | $ | 3.76 |  |
| Diluted earnings per share |  | $ | 2.33 |  |  | $ | 1.66 |  |  | $ | 5.39 |  |  | $ | 3.74 |  |

- changed (2015-07-22):
[0001193125-15-259935:note_history:15]
Potentially dilutive securities whose effect would
 have been antidilutive were not significant for the three- and
 nine-month periods ended June 27, 2015 and June 28, 2014.
 The Company excluded these securities from the computation of
 diluted earnings per share.
  (was, 2015-04-28, similarity 0.7675):
[0001193125-15-153166:note_history:15]
Potentially dilutive securities, whose effect would
 have been antidilutive, were not significant for the three- and
 six-month periods ended March 28, 2015 and the three- and
 six-month periods ended March 29, 2014. The Company excluded
 these securities from the computation of diluted earnings per
 share.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-07-22):
[0001193125-15-259935:note_history:16]
In 2014, the Board of Directors authorized the
 Company to issue unsecured short-term promissory notes
 (“Commercial Paper”) pursuant to a commercial paper
 program. The Company intends to use net proceeds from the
 commercial paper program for general corporate purposes, including
 dividends and share repurchases. As of June 27, 2015 and
 September 27, 2014, the Company had $4.5 billion and $6.3
 billion of Commercial Paper outstanding, respectively, with a
 weighted-average interest rate of 0.10% and 0.12%, respectively,
 and maturities generally less than nine months.
  (was, 2015-04-28, similarity 0.9917):
[0001193125-15-153166:note_history:16]
In 2014, the Board of Directors authorized the
 Company to issue unsecured short-term promissory notes
 (“Commercial Paper”) pursuant to a commercial paper
 program. The Company intends to use net proceeds from the
 commercial paper program for general corporate purposes, including
 dividends and share repurchases. As of March 28, 2015 and
 September 27, 2014, the Company had $3.8 billion and $6.3
 billion of Commercial Paper outstanding, respectively, with a
 weighted-average interest rate of 0.10% and 0.12%, respectively,
 and maturities generally less than nine months.

- changed (2015-07-22):
[0001193125-15-259935:note_history:17]
The following table provides a summary of cash
 flows associated with the issuance and maturities of Commercial
 Paper for the nine months ended June 27, 2015 (in
 millions):
  (was, 2015-04-28, similarity 0.9578):
[0001193125-15-153166:note_history:17]
The following table provides a summary of cash
 flows associated with the issuance and maturities of Commercial
 Paper for the six months ended March 28, 2015 (in
 millions):

- changed (2015-07-22):
[0001193125-15-259935:note_history:18]
| Maturities less than 90 days: |  |  |  |  |
| Proceeds from (repayments of) commercial paper, net |  | $ | 579 |  |
| Maturities greater than 90 days: |  |  |  |  |
| Proceeds from commercial paper |  |  | 2,601 |  |
| Repayments of commercial paper |  |  | (4,988 | ) |
| Maturities greater than 90 days, net |  |  | (2,387 | ) |
| Total change in commercial paper, net |  | $ | (1,808 | ) |
  (was, 2015-04-28, similarity 0.9692):
[0001193125-15-153166:note_history:18]
| Maturities less than 90 days: |  |  |  |  |
| Proceeds from (repayments of) commercial paper, net |  | $ | 985 |  |
| Maturities greater than 90 days: |  |  |  |  |
| Proceeds from commercial paper |  |  | 547 |  |
| Repayments of commercial paper |  |  | (4,040 | ) |
| Maturities greater than 90 days, net |  |  | (3,493 | ) |
| Total repayments of commercial paper, net |  | $ | (2,508 | ) |

- changed (2015-07-22):
[0001193125-15-259935:note_history:19]
As of June 27, 2015, the Company has
 outstanding floating- and fixed-rate notes with varying maturities
 for an aggregate principal amount of $50.0 billion (collectively
 the “Notes”). The Notes are senior unsecured
 obligations, and interest is payable in arrears, quarterly for the
 U.S. dollar-denominated floating-rate notes, semi-annually for the
 U.S. dollar- and yen-denominated fixed-rate notes and annually for
 the euro- and Swiss franc-denominated fixed-rate notes. The
 following table provides a summary of the Company’s long-term
 debt as of June 27, 2015 and September 27, 2014:
  (was, 2015-04-28, similarity 0.6735):
[0001193125-15-153166:note_history:19]
As of March 28, 2015, the Company has
 outstanding floating- and fixed-rate notes with varying maturities
 for an aggregate principal amount of $39.9 billion (collectively
 the “Notes”). The Notes are senior unsecured
 obligations, and interest is payable in arrears, quarterly for the
 domestic floating-rate notes, semi-annually for the domestic
 fixed-rate notes and annually for the foreign fixed-rate notes. The
 following table provides a summary of the Company’s long-term
 debt as of March 28, 2015 and September 27, 2014:

- added (2015-07-22):
[0001193125-15-259935:note_history:20]
|  |  | Maturities |  |  | June 27, 2015 |  |  | September 27, 2014 |  |
|  |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2016 - 2018 |  |  | $ | 3,000 |  |  |  | 0.51% - 1.10% |  |  | $ | 3,000 |  |  |  | 0.51% - 1.10% |  |
| Fixed-rate 0.45% - 3.85% notes |  |  | 2016 - 2043 |  |  |  | 14,000 |  |  |  | 0.51% - 3.91% |  |  |  | 14,000 |  |  |  | 0.51% - 3.91% |  |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2017 - 2019 |  |  |  | 2,000 |  |  |  | 0.35% - 0.58% |  |  |  | 2,000 |  |  |  | 0.31% - 0.54% |  |
| Fixed-rate 1.05% - 4.45% notes |  |  | 2017 - 2044 |  |  |  | 10,000 |  |  |  | 0.34% - 4.48% |  |  |  | 10,000 |  |  |  | 0.30% - 4.48% |  |
| First quarter 2015 euro-denominated debt issuance of €2.8 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 1.00% notes |  |  | 2022 |  |  |  | 1,567 |  |  |  | 2.94% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 1.63% notes |  |  | 2026 |  |  |  | 1,567 |  |  |  | 3.45% |  |  |  | 0 |  |  |  | 0 |  |
| Second quarter 2015 debt issuance of $6.5 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2020 |  |  |  | 500 |  |  |  | 0.53% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 1.55% notes |  |  | 2020 |  |  |  | 1,250 |  |  |  | 0.53% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.15% notes |  |  | 2022 |  |  |  | 1,250 |  |  |  | 0.84% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.50% notes |  |  | 2025 |  |  |  | 1,500 |  |  |  | 2.60% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 3.45% notes |  |  | 2045 |  |  |  | 2,000 |  |  |  | 3.58% |  |  |  | 0 |  |  |  | 0 |  |
| Second quarter 2015 Swiss franc-denominated debt issuance of SFr1.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.38% notes |  |  | 2024 |  |  |  | 939 |  |  |  | 0.28% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 0.75% notes |  |  | 2030 |  |  |  | 403 |  |  |  | 0.74% |  |  |  | 0 |  |  |  | 0 |  |
| Third quarter 2015 debt issuance of $8.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2017 |  |  |  | 250 |  |  |  | 0.33% |  |  |  | 0 |  |  |  | 0 |  |
| Floating-rate notes |  |  | 2020 |  |  |  | 500 |  |  |  | 0.58% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 0.90% notes |  |  | 2017 |  |  |  | 750 |  |  |  | 0.32% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.00% notes |  |  | 2020 |  |  |  | 1,250 |  |  |  | 0.57% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.70% notes |  |  | 2022 |  |  |  | 1,250 |  |  |  | 0.95% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 3.20% notes |  |  | 2025 |  |  |  | 2,000 |  |  |  | 1.18% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 4.38% notes |  |  | 2045 |  |  |  | 2,000 |  |  |  | 4.40% |  |  |  | 0 |  |  |  | 0 |  |
| Third quarter 2015 yen-denominated debt issuance of ¥250.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.35% notes |  |  | 2020 |  |  |  | 2,016 |  |  |  | 0.35% |  |  |  | 0 |  |  |  | 0 |  |
| Total borrowings |  |  |  |  |  |  | 49,992 |  |  |  |  |  |  |  | 29,000 |  |  |  |  |  |
| Unamortized discount |  |  |  |  |  |  | (97 | ) |  |  |  |  |  |  | (52 | ) |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  |  |  | 24 |  |  |  |  |  |  |  | 39 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | (2,500 | ) |  |  |  |  |  |  | 0 |  |  |  |  |  |
| Total long-term debt |  |  |  |  |  | $ | 47,419 |  |  |  |  |  |  | $ | 28,987 |  |  |  |  |  |

- added (2015-07-22):
[0001193125-15-259935:note_history:21]
To manage foreign currency risk associated with the
 euro-denominated notes issued in the first quarter of 2015, the
 Company entered into currency swaps with an aggregate notional
 amount of $3.5 billion, which effectively converted the
 euro-denominated notes to U.S. dollar-denominated notes.

- added (2015-07-22):
[0001193125-15-259935:note_history:22]
To manage interest rate risk on the U.S.
 dollar-denominated fixed-rate notes issued in the second quarter of
 2015 and maturing in 2020 and 2022, the Company entered into
 interest rate swaps with an aggregate notional amount of $2.5
 billion. To manage interest rate risk on the U.S.
 dollar-denominated fixed-rate notes issued in the third quarter of
 2015 and maturing in 2017, 2020, 2022 and 2025, the Company entered
 into interest rate swaps with an aggregate notional amount of $4.3
 billion. These interest rate swaps effectively converted the fixed
 interest rates on the U.S. dollar-denominated notes to a floating
 interest rate.

- added (2015-07-22):
[0001193125-15-259935:note_history:23]
During the third quarter of 2015, the Company
 designated ¥212.4 billion of the ¥250.0 billion of
 yen-denominated notes as a hedge of the foreign currency exposure
 of its net investment in a foreign operation. As a result, the
 foreign currency transaction gain or loss on the portion of the
 yen-denominated debt designated as a hedge is recorded in OCI as a
 part of the cumulative translation adjustment. As of June 27,
 2015, the carrying value of the debt designated as a net investment
 hedge was $1.7 billion.

- added (2015-07-22):
[0001193125-15-259935:note_history:24]
For further discussion regarding the
 Company’s use of derivative instruments see the Derivative
 Financial Instruments section of Note 2, “Financial
 Instruments.”

- changed (2015-07-22):
[0001193125-15-259935:note_history:25]
The effective interest rates for the Notes include
 the interest on the Notes, amortization of the discount and, if
 applicable, adjustments related to hedging. The Company recognized
 $197 million and $486 million of interest expense on its long-term
 debt for the three- and nine-month periods ended June 27,
 2015, respectively. The Company recognized $100 million and $268
 million of interest expense on its long-term debt for the three-
 and nine-month periods ended June 28, 2014, respectively.
  (was, 2015-04-28, similarity 0.8776):
[0001193125-15-153166:note_history:25]
The effective interest rates for the Notes include
 the interest on the Notes, amortization of the discount and, if
 applicable, adjustments related to hedging. The Company recognized
 $161 million and $289 million of interest expense on its long-term
 debt for the three- and six-month periods ended March 28,
 2015, respectively. The Company recognized $84 million and $168
 million of interest expense on its long-term debt for the three-
 and six-month periods ended March 29, 2014, respectively.

- changed (2015-07-22):
[0001193125-15-259935:note_history:26]
Future principal payments for the Company’s
 Notes as of June 27, 2015 are as follows (in millions):
  (was, 2015-04-28, similarity 0.9524):
[0001193125-15-153166:note_history:26]
Future principal payments for the Company’s
 Notes as of March 28, 2015 are as follows (in millions):

- changed (2015-07-22):
[0001193125-15-259935:note_history:27]
As of June 27, 2015 and September 27,
 2014, the fair value of the Company’s Notes, based on Level 2
 inputs, was $48.7 billion and $28.5 billion, respectively.
  (was, 2015-04-28, similarity 0.9682):
[0001193125-15-153166:note_history:27]
As of March 28, 2015 and September 27,
 2014, the fair value of the Company’s Notes, based on Level 2
 inputs, was $40.2 billion and $28.5 billion, respectively.

- removed (2015-07-22):
[0001193125-15-153166:note_history:28]
|  |  | March 28, 2015 |  |  | September 27, 2014 |  |
|  |  | Amount (in millions) |  |  | Effective Interest Rate |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |
| Floating-rate notes due 2016 (1) |  | $ | 1,000 |  |  |  | 0.51% |  |  | $ | 1,000 |  |  |  | 0.51% |  |
| Floating-rate notes due 2017 (2) |  |  | 1,000 |  |  |  | 0.33% |  |  |  | 1,000 |  |  |  | 0.31% |  |
| Floating-rate notes due 2018 (1) |  |  | 2,000 |  |  |  | 1.10% |  |  |  | 2,000 |  |  |  | 1.10% |  |
| Floating-rate notes due 2019 (2) |  |  | 1,000 |  |  |  | 0.56% |  |  |  | 1,000 |  |  |  | 0.54% |  |
| Floating-rate notes due 2020 (3) |  |  | 500 |  |  |  | 0.51% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 0.45% notes due 2016 (1) |  |  | 1,500 |  |  |  | 0.51% |  |  |  | 1,500 |  |  |  | 0.51% |  |
| Fixed-rate 1.05% notes due 2017 (2) |  |  | 1,500 |  |  |  | 0.32% |  |  |  | 1,500 |  |  |  | 0.30% |  |
| Fixed-rate 1.00% notes due 2018 (1) |  |  | 4,000 |  |  |  | 1.08% |  |  |  | 4,000 |  |  |  | 1.08% |  |
| Fixed-rate 2.10% notes due 2019 (2) |  |  | 2,000 |  |  |  | 0.55% |  |  |  | 2,000 |  |  |  | 0.53% |  |
| Fixed-rate 1.55% notes due 2020 (3) |  |  | 1,250 |  |  |  | 0.50% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.85% notes due 2021 (2) |  |  | 3,000 |  |  |  | 0.81% |  |  |  | 3,000 |  |  |  | 0.79% |  |
| Fixed-rate 2.15% notes due 2022 (3) |  |  | 1,250 |  |  |  | 0.82% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 1.00% Euro-denominated notes due 2022 (4) |  |  | 1,534 |  |  |  | 2.94% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.40% notes due 2023 (1) |  |  | 5,500 |  |  |  | 2.44% |  |  |  | 5,500 |  |  |  | 2.44% |  |
| Fixed-rate 3.45% notes due 2024 (2) |  |  | 2,500 |  |  |  | 0.92% |  |  |  | 2,500 |  |  |  | 0.90% |  |
| Fixed-rate 0.38% Swiss Franc-denominated notes due 2024 (5) |  |  | 915 |  |  |  | 0.28% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.50% notes due 2025 (3) |  |  | 1,500 |  |  |  | 2.60% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 1.63% Euro-denominated notes due 2026 (4) |  |  | 1,534 |  |  |  | 3.45% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 0.75% Swiss Franc-denominated notes due 2030 (5) |  |  | 392 |  |  |  | 0.74% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 3.85% notes due 2043 (1) |  |  | 3,000 |  |  |  | 3.91% |  |  |  | 3,000 |  |  |  | 3.91% |  |
| Fixed-rate 4.45% notes due 2044 (2) |  |  | 1,000 |  |  |  | 4.48% |  |  |  | 1,000 |  |  |  | 4.48% |  |
| Fixed-rate 3.45% notes due 2045 (3) |  |  | 2,000 |  |  |  | 3.58% |  |  |  | 0 |  |  |  | 0 |  |
| Total borrowings |  |  | 39,875 |  |  |  |  |  |  |  | 29,000 |  |  |  |  |  |
| Unamortized discount |  |  | (80 | ) |  |  |  |  |  |  | (52 | ) |  |  |  |  |
| Hedge accounting fair value adjustments |  |  | 277 |  |  |  |  |  |  |  | 39 |  |  |  |  |  |
| Total long-term debt |  | $ | 40,072 |  |  |  |  |  |  | $ | 28,987 |  |  |  |  |  |

- removed (2015-07-22):
[0001193125-15-153166:note_history:29]
|  | (1) | Tranche relates to the $17.0 billion debt issuance in the third quarter of 2013. |  |

- removed (2015-07-22):
[0001193125-15-153166:note_history:30]
|  | (2) | Tranche relates to the $12.0 billion debt issuance in the third quarter of 2014. |  |

- removed (2015-07-22):
[0001193125-15-153166:note_history:31]
|  | (3) | Tranche relates to the $6.5 billion debt issuance in the second quarter of 2015. |  |

- removed (2015-07-22):
[0001193125-15-153166:note_history:32]
|  | (4) | Tranche relates to Euro-denominated debt issuance of €2.8 billion in the first quarter of 2015. |  |

- removed (2015-07-22):
[0001193125-15-153166:note_history:33]
|  | (5) | Tranche relates to Swiss Franc-denominated debt issuance of SFr1.3 billion in the second quarter of 2015. |  |

- removed (2015-07-22):
[0001193125-15-153166:note_history:34]
During the first six months of 2015, the Company
 issued €2.8
 billion of Euro-denominated notes, $6.5 billion of U.S.
 dollar-denominated notes and SFr1.3 billion of Swiss
 Franc-denominated notes. To manage foreign currency risk associated
 with the Euro-denominated notes, the Company entered into currency
 swaps with an aggregate notional amount of $3.5 billion, which
 effectively converted the Euro-denominated notes to U.S.
 dollar-denominated notes. To manage interest rate risk on the U.S.
 dollar-denominated fixed-rate notes maturing in 2020 and 2022, the
 Company entered into interest rate swaps with an aggregate notional
 amount of $2.5 billion, which effectively converted the fixed
 interest rates on these notes to a floating interest rate. For
 further discussion regarding the Company’s use of derivative
 instruments to manage interest rate and foreign currency risk, see
 the Derivative Financial Instruments section of Note 2,
 “Financial Instruments.”


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-07-22):
[0001193125-15-259935:note_history:35]
The following table provides a summary of the
 Company’s long-term debt as of June 27, 2015 and
 September 27, 2014:
  (was, 2015-04-28, similarity 0.9569):
[0001193125-15-153166:note_history:35]
The following table provides a summary of the
 Company’s long-term debt as of March 28, 2015 and
 September 27, 2014:

- added (2015-07-22):
[0001193125-15-259935:note_history:36]
|  |  | Maturities |  |  | June 27, 2015 |  |  | September 27, 2014 |  |
|  |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |
| 2013 debt issuance of $17.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2016 - 2018 |  |  | $ | 3,000 |  |  |  | 0.51% - 1.10% |  |  | $ | 3,000 |  |  |  | 0.51% - 1.10% |  |
| Fixed-rate 0.45% - 3.85% notes |  |  | 2016 - 2043 |  |  |  | 14,000 |  |  |  | 0.51% - 3.91% |  |  |  | 14,000 |  |  |  | 0.51% - 3.91% |  |
| 2014 debt issuance of $12.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2017 - 2019 |  |  |  | 2,000 |  |  |  | 0.35% - 0.58% |  |  |  | 2,000 |  |  |  | 0.31% - 0.54% |  |
| Fixed-rate 1.05% - 4.45% notes |  |  | 2017 - 2044 |  |  |  | 10,000 |  |  |  | 0.34% - 4.48% |  |  |  | 10,000 |  |  |  | 0.30% - 4.48% |  |
| First quarter 2015 euro-denominated debt issuance of €2.8 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 1.00% notes |  |  | 2022 |  |  |  | 1,567 |  |  |  | 2.94% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 1.63% notes |  |  | 2026 |  |  |  | 1,567 |  |  |  | 3.45% |  |  |  | 0 |  |  |  | 0 |  |
| Second quarter 2015 debt issuance of $6.5 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2020 |  |  |  | 500 |  |  |  | 0.53% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 1.55% notes |  |  | 2020 |  |  |  | 1,250 |  |  |  | 0.53% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.15% notes |  |  | 2022 |  |  |  | 1,250 |  |  |  | 0.84% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.50% notes |  |  | 2025 |  |  |  | 1,500 |  |  |  | 2.60% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 3.45% notes |  |  | 2045 |  |  |  | 2,000 |  |  |  | 3.58% |  |  |  | 0 |  |  |  | 0 |  |
| Second quarter 2015 Swiss franc-denominated debt issuance of SFr1.3 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.38% notes |  |  | 2024 |  |  |  | 939 |  |  |  | 0.28% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 0.75% notes |  |  | 2030 |  |  |  | 403 |  |  |  | 0.74% |  |  |  | 0 |  |  |  | 0 |  |
| Third quarter 2015 debt issuance of $8.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Floating-rate notes |  |  | 2017 |  |  |  | 250 |  |  |  | 0.33% |  |  |  | 0 |  |  |  | 0 |  |
| Floating-rate notes |  |  | 2020 |  |  |  | 500 |  |  |  | 0.58% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 0.90% notes |  |  | 2017 |  |  |  | 750 |  |  |  | 0.32% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.00% notes |  |  | 2020 |  |  |  | 1,250 |  |  |  | 0.57% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.70% notes |  |  | 2022 |  |  |  | 1,250 |  |  |  | 0.95% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 3.20% notes |  |  | 2025 |  |  |  | 2,000 |  |  |  | 1.18% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 4.38% notes |  |  | 2045 |  |  |  | 2,000 |  |  |  | 4.40% |  |  |  | 0 |  |  |  | 0 |  |
| Third quarter 2015 yen-denominated debt issuance of ¥250.0 billion: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed-rate 0.35% notes |  |  | 2020 |  |  |  | 2,016 |  |  |  | 0.35% |  |  |  | 0 |  |  |  | 0 |  |
| Total borrowings |  |  |  |  |  |  | 49,992 |  |  |  |  |  |  |  | 29,000 |  |  |  |  |  |
| Unamortized discount |  |  |  |  |  |  | (97 | ) |  |  |  |  |  |  | (52 | ) |  |  |  |  |
| Hedge accounting fair value adjustments |  |  |  |  |  |  | 24 |  |  |  |  |  |  |  | 39 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | (2,500 | ) |  |  |  |  |  |  | 0 |  |  |  |  |  |
| Total long-term debt |  |  |  |  |  | $ | 47,419 |  |  |  |  |  |  | $ | 28,987 |  |  |  |  |  |

- removed (2015-07-22):
[0001193125-15-153166:note_history:37]
|  |  | March 28, 2015 |  |  | September 27, 2014 |  |
|  |  | Amount (in millions) |  |  | Effective Interest Rate |  |  | Amount (in millions) |  |  | Effective Interest Rate |  |
| Floating-rate notes due 2016 (1) |  | $ | 1,000 |  |  |  | 0.51% |  |  | $ | 1,000 |  |  |  | 0.51% |  |
| Floating-rate notes due 2017 (2) |  |  | 1,000 |  |  |  | 0.33% |  |  |  | 1,000 |  |  |  | 0.31% |  |
| Floating-rate notes due 2018 (1) |  |  | 2,000 |  |  |  | 1.10% |  |  |  | 2,000 |  |  |  | 1.10% |  |
| Floating-rate notes due 2019 (2) |  |  | 1,000 |  |  |  | 0.56% |  |  |  | 1,000 |  |  |  | 0.54% |  |
| Floating-rate notes due 2020 (3) |  |  | 500 |  |  |  | 0.51% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 0.45% notes due 2016 (1) |  |  | 1,500 |  |  |  | 0.51% |  |  |  | 1,500 |  |  |  | 0.51% |  |
| Fixed-rate 1.05% notes due 2017 (2) |  |  | 1,500 |  |  |  | 0.32% |  |  |  | 1,500 |  |  |  | 0.30% |  |
| Fixed-rate 1.00% notes due 2018 (1) |  |  | 4,000 |  |  |  | 1.08% |  |  |  | 4,000 |  |  |  | 1.08% |  |
| Fixed-rate 2.10% notes due 2019 (2) |  |  | 2,000 |  |  |  | 0.55% |  |  |  | 2,000 |  |  |  | 0.53% |  |
| Fixed-rate 1.55% notes due 2020 (3) |  |  | 1,250 |  |  |  | 0.50% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.85% notes due 2021 (2) |  |  | 3,000 |  |  |  | 0.81% |  |  |  | 3,000 |  |  |  | 0.79% |  |
| Fixed-rate 2.15% notes due 2022 (3) |  |  | 1,250 |  |  |  | 0.82% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 1.00% Euro-denominated notes due 2022 (4) |  |  | 1,534 |  |  |  | 2.94% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.40% notes due 2023 (1) |  |  | 5,500 |  |  |  | 2.44% |  |  |  | 5,500 |  |  |  | 2.44% |  |
| Fixed-rate 3.45% notes due 2024 (2) |  |  | 2,500 |  |  |  | 0.92% |  |  |  | 2,500 |  |  |  | 0.90% |  |
| Fixed-rate 0.38% Swiss Franc-denominated notes due 2024 (5) |  |  | 915 |  |  |  | 0.28% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 2.50% notes due 2025 (3) |  |  | 1,500 |  |  |  | 2.60% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 1.63% Euro-denominated notes due 2026 (4) |  |  | 1,534 |  |  |  | 3.45% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 0.75% Swiss Franc-denominated notes due 2030 (5) |  |  | 392 |  |  |  | 0.74% |  |  |  | 0 |  |  |  | 0 |  |
| Fixed-rate 3.85% notes due 2043 (1) |  |  | 3,000 |  |  |  | 3.91% |  |  |  | 3,000 |  |  |  | 3.91% |  |
| Fixed-rate 4.45% notes due 2044 (2) |  |  | 1,000 |  |  |  | 4.48% |  |  |  | 1,000 |  |  |  | 4.48% |  |
| Fixed-rate 3.45% notes due 2045 (3) |  |  | 2,000 |  |  |  | 3.58% |  |  |  | 0 |  |  |  | 0 |  |
| Total borrowings |  |  | 39,875 |  |  |  |  |  |  |  | 29,000 |  |  |  |  |  |
| Unamortized discount |  |  | (80 | ) |  |  |  |  |  |  | (52 | ) |  |  |  |  |
| Hedge accounting fair value adjustments |  |  | 277 |  |  |  |  |  |  |  | 39 |  |  |  |  |  |
| Total long-term debt |  | $ | 40,072 |  |  |  |  |  |  | $ | 28,987 |  |  |  |  |  |

- removed (2015-07-22):
[0001193125-15-153166:note_history:38]
|  | (1) | Tranche relates to the $17.0 billion debt issuance in the third quarter of 2013. |  |

- removed (2015-07-22):
[0001193125-15-153166:note_history:39]
|  | (2) | Tranche relates to the $12.0 billion debt issuance in the third quarter of 2014. |  |

- removed (2015-07-22):
[0001193125-15-153166:note_history:40]
|  | (3) | Tranche relates to the $6.5 billion debt issuance in the second quarter of 2015. |  |

- removed (2015-07-22):
[0001193125-15-153166:note_history:41]
|  | (4) | Tranche relates to Euro-denominated debt issuance of €2.8 billion in the first quarter of 2015. |  |

- removed (2015-07-22):
[0001193125-15-153166:note_history:42]
|  | (5) | Tranche relates to Swiss Franc-denominated debt issuance of SFr1.3 billion in the second quarter of 2015. |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-07-22):
[0001193125-15-259935:note_history:43]
Future principal payments for the Company’s
 Notes as of June 27, 2015 are as follows (in millions):
  (was, 2015-04-28, similarity 0.9524):
[0001193125-15-153166:note_history:43]
Future principal payments for the Company’s
 Notes as of March 28, 2015 are as follows (in millions):
