# LITE MD&A — 0001628280-22-001745


## mdna

[0001628280-22-001745:mdna:1]
[same as prior period, unchanged from 0001628280-21-021632:mdna:1]

[0001628280-22-001745:mdna:2]
[same as prior period, unchanged from 0001628280-21-021632:mdna:2]

[0001628280-22-001745:mdna:3]
[same as prior period, unchanged from 0001628280-21-021632:mdna:3]

[0001628280-22-001745:mdna:4]
[same as prior period, unchanged from 0001628280-21-021632:mdna:4]

[0001628280-22-001745:mdna:5]
[same as prior period, unchanged from 0001628280-21-021632:mdna:5]

[0001628280-22-001745:mdna:6]
[same as prior period, unchanged from 0001628280-21-021632:mdna:6]

[0001628280-22-001745:mdna:7]
We believe the global markets in which Lumentum participates have fundamentally robust, long-term trends that increase the need for our optical and photonics products and technologies. We believe the world is becoming more reliant on ever-increasing amounts of data flowing through optical networks and data centers. Lumentum’s products and technology enable the scaling of these optical networks and data centers to higher capacities. We expect the accelerating shift to digital and virtual approaches to all aspects of work and life that is driving staggering amounts of data in the world’s networks and cloud datacenters will continue into the future. Virtual meetings, video calls, and hybrid in-person and virtual environments for work and other aspects of life will continue to drive strong needs for bandwidth growth and present dynamic new technology challenges that our technology addresses. As manufacturers demand higher levels of precision, new materials, and factory and energy efficiency, suppliers of manufacturing tools globally are turning to laser based approaches, including the types of lasers Lumentum supplies. Laser based 3D sensing and LiDAR for security, industrial and automotive applications are rapidly developing markets. The technology enables computer vision applications that enhance security, safety, and new functionality in the electronic devices that people rely on every day. The use of LiDAR and in-cabin 3D sensing in automobile and delivery vehicles over time significantly adds to our long-term market opportunity. Frictionless and contactless biometric security and access control is of increasing focus globally given the world’s experience with the COVID-19 pandemic. Additionally, we expect 3D enabled machine vision solutions to expand significantly in industrial applications in the coming years.

[0001628280-22-001745:mdna:8]
[same as prior period, unchanged from 0001628280-21-021632:mdna:8]

[0001628280-22-001745:mdna:9]
Business Combination

[0001628280-22-001745:mdna:10]
On November 4, 2021, Lumentum and NeoPhotonics Corporation (“NeoPhotonics”) announced a merger agreement (the “Merger Agreement”). Under the terms of the Merger Agreement, NeoPhotonics stockholders will receive $16.00 per share in cash for each NeoPhotonics share they own. As of January 1, 2022, the estimated total transaction consideration is expected to be approximately $918.0 million. The cash consideration will be funded from the combined company’s balance sheet.

[0001628280-22-001745:mdna:11]
On January 14, 2022, Lumentum and NeoPhotonics entered into a credit agreement where Lumentum agreed to make delayed draw term loans (“loans”) to NeoPhotonics in an aggregate principal amount not to exceed $50.0 million to help fund capital expenditures and increased working capital associated with NeoPhotonics’ growth plans. The loans will mature on January 14, 2024 unless earlier repaid or accelerated. The loans bear interest at the Wall Street Journal “prime rate”, payble monthly in arrears on the first day of each month. There have not been any drawdown of the loans.

[0001628280-22-001745:mdna:12]
The Merger Agreement contains certain termination rights for both Lumentum and NeoPhotonics and provides that upon termination of the Merger Agreement under specified circumstances (including termination by NeoPhotonics to accept a superior proposal), NeoPhotonics may be required to pay Lumentum a termination fee of $27.5 million. The Merger Agreement further provides that if the Merger Agreement is terminated for failure to obtain antitrust approval, Lumentum may be required to pay NeoPhotonics a termination fee of $55.1 million; and if Lumentum takes certain specified actions, (including entering into any definitive agreement for an acquisition by stock purchase, merger, consolidation, amalgamation, purchase of assets, license or otherwise of any ownership interest or assets of any Person) that cause a material delay in, or results in the failure of, the consummation of the Merger, Lumentum may be required to pay NeoPhotonics an additional termination fee of $36.7 million.

[0001628280-22-001745:mdna:13]
The Boards of Directors of Lumentum and NeoPhotonics have unanimously approved the transaction and the Merger Agreement. The transaction is subject to customary closing conditions, including the absence of certain legal impediments, the expiration or termination of the required waiting periods under the Hart-Scott-Rodino Antitrust Improvements Act of 1976, as amended, receipt of any required antitrust and regulatory approvals. The transaction was approved by the NeoPhotonics stockholders on February 1, 2022. The transaction is not subject to any financing condition. We expect this transaction to be completed in the second half of calendar year 2022.

[0001628280-22-001745:mdna:14]
[same as prior period, unchanged from 0001628280-21-021632:mdna:9]

[0001628280-22-001745:mdna:15]
[same as prior period, unchanged from 0001628280-21-021632:mdna:10]

[0001628280-22-001745:mdna:16]
In the geographies where we have operations, we have, in general and where applicable, been deemed an essential business and been permitted to continue manufacturing and conducting new product development operations in a more limited capacity during the pandemic. This stems from our critical role in global supply chains for the world’s communications and health-care systems. However, the pandemic continues to affect our suppliers and manufacturers who are experiencing component materials and labor shortages.  Given the continually evolving situation, it is difficult to predict the magnitude and duration of the impact of the COVID-19 pandemic to our markets, its effects, or precisely when our ability to supply our products will return to full capacity. We are continuing to actively monitor the situation and may take further actions altering our business operations that we determine are in the best interests of our employees, customers, communities, business partners, suppliers and stockholders, or as required by federal, state, or local authorities. It is not clear what the potential effects any such alterations or modifications may have on our business, including the effects on our customers, employees and prospects, or on our financial results for fiscal year 2022.

[0001628280-22-001745:mdna:17]
COVID-19 has also created dynamics in the semiconductor component supply chains that have led to shortages of the types of components we and our customers require in our products. These shortages have impacted our ability to meet demand and generate revenue from certain products in early fiscal 2022 and, if our ability to procure needed semiconductor components does not improve, this will impact our ability to supply our products to our customers and may reduce our revenue and profit margin. In addition, if our customers are unable to procure needed semiconductor components, this could reduce their demand for our products and reduce our revenue. The impact of semiconductor component shortages may increase in the near term as supplier and customer buffer inventories and safety stocks are exhausted. Due to the global supply chain constraint, we have had to incur incremental supply and procurement costs in order to increase our ability to fulfill demands from our customers. These costs have increased our inventory balances as of January 1, 2022 and will decrease our gross margin in the near term. We expect component supply to be a challenge at least through the third quarter of fiscal 2022.

[0001628280-22-001745:mdna:18]
[same as prior period, unchanged from 0001628280-21-021632:mdna:14]

[0001628280-22-001745:mdna:19]
[same as prior period, unchanged from 0001628280-21-021632:mdna:15]

[0001628280-22-001745:mdna:20]
[same as prior period, unchanged from 0001628280-21-021632:mdna:16]

[0001628280-22-001745:mdna:21]
[same as prior period, unchanged from 0001628280-21-021632:mdna:17]

[0001628280-22-001745:mdna:22]
[same as prior period, unchanged from 0001628280-21-021632:mdna:18]

[0001628280-22-001745:mdna:23]
[same as prior period, unchanged from 0001628280-21-021632:mdna:19]

[0001628280-22-001745:mdna:24]
[same as prior period, unchanged from 0001628280-21-021632:mdna:20]

[0001628280-22-001745:mdna:25]
•Business Combinations

[0001628280-22-001745:mdna:26]
•Goodwill

[0001628280-22-001745:mdna:27]
On November 4, 2021, we entered into a Merger Agreement with NeoPhotonics, which was unanimously approved by the boards of directors of both companies.  The transaction is subject to customary closing conditions and is expected to close in the second half of calendar 2022.  We have added Business Combinations and Goodwill to our critical accounting policies and estimates in the second quarter of fiscal 2022.

[0001628280-22-001745:mdna:28]
Management’s Discussion and Analysis of Financial Condition and Results of Operations contained in Part II, Item 7 of our Annual Report on Form 10-K for our fiscal year ended July 3, 2021 provides a more complete discussion of our critical accounting policies and estimates. Other than our policies on Business Combinations and Goodwill there have been no significant changes to these policies during the six months ended January 1, 2022.

[0001628280-22-001745:mdna:29]
Business Combinations

[0001628280-22-001745:mdna:30]
In accordance with the guidance for business combinations, we determine whether a transaction or event is a business combination, which requires that the assets acquired and liabilities assumed constitute a business. Each business combination is then accounted for by applying the acquisition method. If the assets acquired are not a business, we account for the transaction or event as an asset acquisition. Under both methods, we recognize the identifiable assets acquired, the liabilities assumed, and any noncontrolling interest in the acquired entity. We capitalize acquisition-related costs and fees associated with asset acquisitions and immediately expense acquisition-related costs and fees associated with business combinations.

[0001628280-22-001745:mdna:31]
We allocate the fair value of purchase consideration to the tangible assets acquired, liabilities assumed and intangible assets acquired based on their estimated fair values. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. When determining the fair values of assets acquired and liabilities assumed, we make significant estimates and assumptions, especially with respect to intangible assets. Critical estimates in valuing certain intangible assets include, but are not limited to, future expected cash flows from customer relationships and acquired developed technology and discount rates. Our estimates of fair value are based upon assumptions believed to be reasonable using best information available. These assumptions are inherently uncertain and unpredictable and, as a result, actual results may differ materially from estimates. Certain estimates associated with the accounting for acquisitions may change as additional information becomes available regarding the assets acquired and liabilities assumed. Any change in facts and circumstances that existed as of the acquisition date and impacts to our preliminary estimates is recorded to goodwill if identified within the measurement period. Subsequent to the measurement period or our final determination of fair value of assets and liabilities, whichever is earlier, the adjustments will affect our earnings.

[0001628280-22-001745:mdna:32]
We estimate the economic lives of certain acquired assets and these lives are used to calculate depreciation and amortization expense. If our estimates of the economic lives change, depreciation or amortization expenses could be accelerated or slowed.

[0001628280-22-001745:mdna:33]
Goodwill

[0001628280-22-001745:mdna:34]
Goodwill represents the excess of the purchase price of an acquired business over the fair value of the identifiable assets acquired and liabilities assumed. We test goodwill impairment on an annual basis in the fiscal fourth quarter and at any other time when events occur or circumstances indicate that the carrying amount of goodwill may not be recoverable.

[0001628280-22-001745:mdna:35]
We have the option to first assess qualitative factors to determine whether it is necessary to perform the quantitative goodwill impairment test. The qualitative factors we assess include long-term prospects of our performance, share price trends and market capitalization, and Company specific events. Unanticipated events and circumstances may occur that affect the accuracy of our assumptions, estimates and judgments. For example, if the price of our common stock were to significantly decrease combined with other adverse changes in market conditions, thus indicating that the underlying fair value of our reporting units may have decreased, we may reassess the value of our goodwill in the period such circumstances were identified.

[0001628280-22-001745:mdna:36]
If we determine that,  as a result of the qualitative assessment, it is more likely than not (i.e., greater than 50% likelihood) that the fair value of a reporting unit is less than its carrying amount, we perform the quantitative test by estimating the fair value of our reporting units. If the carrying value of a reporting unit exceeds its fair value, we record goodwill impairment loss equal to the excess of the carrying value of the reporting unit’s goodwill over its fair value, not to exceed the carrying amount of goodwill. The fair value of each of our goodwill reporting units is generally estimated using a combination of public company multiples and discounted cash flow methodologies.

[0001628280-22-001745:mdna:37]
[same as prior period, unchanged from 0001628280-21-021632:mdna:27]

[0001628280-22-001745:mdna:38]
Recently Issued Accounting Pronouncements

[0001628280-22-001745:mdna:39]
Refer to “Note 2. Recently Issued Accounting Pronouncements” in the notes to condensed consolidated financial statements.

[0001628280-22-001745:mdna:40]
[same as prior period, unchanged from 0001628280-21-021632:mdna:24]

[0001628280-22-001745:mdna:41]
[same as prior period, unchanged from 0001628280-21-021632:mdna:25]

[0001628280-22-001745:mdna:42]
|  | Three Months Ended |  | Six Months Ended |
|  | January 1, 2022 |  | December 26, 2020 |  | January 1, 2022 |  | December 26, 2020 |
| Segment net revenue: |  |  |  |  |  |  |  |
| OpComms | 89.0 | % |  | 93.8 | % |  | 89.8 | % |  | 94.2 | % |
| Lasers | 11.0 |  |  | 6.2 |  |  | 10.2 |  |  | 5.8 |  |
| Net revenue | 100.0 |  |  | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of sales | 50.0 |  |  | 48.9 |  |  | 47.3 |  |  | 50.0 |  |
| Amortization of acquired developed intangibles | 3.6 |  |  | 3.1 |  |  | 3.5 |  |  | 3.2 |  |
| Gross profit | 46.5 |  |  | 48.0 |  |  | 49.1 |  |  | 46.7 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 11.9 |  |  | 11.0 |  |  | 12.0 |  |  | 11.1 |  |
| Selling, general and administrative | 15.4 |  |  | 12.8 |  |  | 14.8 |  |  | 12.6 |  |
| Restructuring and related charges | — |  |  | — |  |  | (0.1) |  |  | — |  |
| Total operating expenses | 27.4 |  |  | 23.9 |  |  | 26.7 |  |  | 23.7 |  |
| Income from operations | 19.1 |  |  | 24.1 |  |  | 22.5 |  |  | 23.0 |  |
| Interest expense | (3.8) |  |  | (3.4) |  |  | (3.8) |  |  | (3.5) |  |
| Other income (expense), net | 0.2 |  |  | (0.2) |  |  | 0.2 |  |  | — |  |
| Income before income taxes | 15.5 |  |  | 20.5 |  |  | 18.8 |  |  | 19.5 |  |
| Provision for income taxes | 2.8 |  |  | 3.1 |  |  | 3.4 |  |  | 3.4 |  |
| Net income | 12.7 | % |  | 17.4 | % |  | 15.4 | % |  | 16.1 | % |

[0001628280-22-001745:mdna:43]
Financial Data for the three and six months ended January 1, 2022 and December 26, 2020

[0001628280-22-001745:mdna:44]
[same as prior period, unchanged from 0001628280-21-021632:mdna:29]

[0001628280-22-001745:mdna:45]
|  | Three Months Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | January 1, 2022 |  | December 26, 2020 |  | Change |  | Percentage Change |  | January 1, 2022 |  | December 26, 2020 |  | Change |  | Percentage Change |
| Segment net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| OpComms | $ | 397.4 |  |  | $ | 449.1 |  |  | $ | (51.7) |  |  | (11.5) | % |  | $ | 803.4 |  |  | $ | 877.6 |  |  | $ | (74.2) |  |  | (8.5) | % |
| Lasers | 49.3 |  |  | 29.7 |  |  | 19.6 |  |  | 66.0 |  |  | 91.7 |  |  | 53.6 |  |  | 38.1 |  |  | 71.1 |  |
| Net revenue | $ | 446.7 |  |  | $ | 478.8 |  |  | $ | (32.1) |  |  | (6.7) | % |  | $ | 895.1 |  |  | $ | 931.2 |  |  | $ | (36.1) |  |  | (3.9) | % |
| Gross profit | $ | 207.5 |  |  | $ | 229.6 |  |  | $ | (22.1) |  |  | (9.6) | % |  | $ | 439.7 |  |  | $ | 435.3 |  |  | $ | 4.4 |  |  | 1.0 | % |
| Gross margin | 46.5 | % |  | 48.0 | % |  |  |  |  |  | 49.1 | % |  | 46.7 | % |  |  |  |  |
| Research and development | $ | 53.2 |  |  | $ | 52.8 |  |  | $ | 0.4 |  |  | 0.8 | % |  | $ | 107.3 |  |  | $ | 103.2 |  |  | $ | 4.1 |  |  | 4.0 | % |
| Percentage of net revenue | 11.9 | % |  | 11.0 | % |  |  |  |  |  | 12.0 | % |  | 11.1 | % |  |  |  |  |
| Selling, general and administrative | $ | 69.0 |  |  | $ | 61.3 |  |  | $ | 7.7 |  |  | 12.6 | % |  | $ | 132.3 |  |  | $ | 117.6 |  |  | $ | 14.7 |  |  | 12.5 | % |
| Percentage of net revenue | 15.4 | % |  | 12.8 | % |  |  |  |  |  | 14.8 | % |  | 12.6 | % |  |  |  |  |
| Restructuring and related charges | $ | 0.1 |  |  | $ | 0.2 |  |  | $ | (0.1) |  |  | (50.0) | % |  | $ | (1.0) |  |  | $ | 0.2 |  |  | $ | (1.2) |  |  | N/A |
| Percentage of net revenue | — | % |  | — | % |  |  |  |  |  | (0.1) | % |  | — | % |  |  |  |  |

[0001628280-22-001745:mdna:46]
[same as prior period, unchanged from 0001628280-21-021632:mdna:31]

[0001628280-22-001745:mdna:47]
Net revenue decreased by $32.1 million, or 6.7%, during the three months ended January 1, 2022 compared to the three months ended December 26, 2020, due to a $51.7 million decrease in OpComms revenue, offset by a $19.6 million increase in Lasers revenue.

[0001628280-22-001745:mdna:48]
OpComms net revenue decreased by $51.7 million, or 11.5%, during the three months ended January 1, 2022 compared to the three months ended December 26, 2020. Within OpComms, Telecom and Datacom decreased by $19.1 million primarily a result of continued material and component shortages for our Telecom products and lower demand due to continued delays in 5G deployments. Industrial and Consumer decreased by $32.6 million due primarily to the timing of customer product releases.

[0001628280-22-001745:mdna:49]
Lasers net revenue increased by $19.6 million, or 66.0%, during the three months ended January 1, 2022 compared to the three months ended December 26, 2020, primarily due to a return in customer demand for our kilowatt class fiber lasers following the recent recovery in industrial production.

[0001628280-22-001745:mdna:50]
Net revenue decreased by $36.1 million, or 3.9%, during the six months ended January 1, 2022 compared to the six months ended December 26, 2020, due to $74.2 million decrease in OpComms revenue, offset by $38.1 million increase in Lasers revenue.

[0001628280-22-001745:mdna:51]
OpComms net revenue decreased by $74.2 million, or 8.5%, during the six months ended January 1, 2022 compared to the six months ended December 26, 2020. Within OpComms, Telecom and Datacom decreased by $64.4 million primarily a result of continued material and component shortages and lower demand due to continued delays in 5G deployments, partially offset by an increase in revenue for our EML product driven by capacity growth to satisfy demand, as well as revenue increases for 10G Tunable, Coherent Component, and Pump Laser products. Industrial and Consumer decreased by $9.8 million due primarily to delays in customer qualification.

[0001628280-22-001745:mdna:52]
Lasers net revenue increased by $38.1 million, or 71.1%, during the six months ended January 1, 2022 compared to the six months ended December 26, 2020, primarily due to a return in customer demand for our kilowatt class fiber lasers following the COVID-19 disruption in fiscal 2021 and improved production utilization.

[0001628280-22-001745:mdna:53]
During the three and six months ended January 1, 2022, our net revenue from a single customer, which represented 10.0% or greater of total net revenue was concentrated with two customers, who collectively accounted for 41% and 46% of our total net revenue, respectively.

[0001628280-22-001745:mdna:54]
During the three and six months ended December 26, 2020, our net revenue from a single customer, which represented 10% or greater of total net revenue was concentrated with two customers, who collectively accounted for 45% of our total net revenue for each period, respectively.

[0001628280-22-001745:mdna:55]
[same as prior period, unchanged from 0001628280-21-021632:mdna:37]

[0001628280-22-001745:mdna:56]
[same as prior period, unchanged from 0001628280-21-021632:mdna:38]

[0001628280-22-001745:mdna:57]
|  | Three Months Ended |  | Six Months Ended |
|  | January 1, 2022 |  | December 26, 2020 |  | January 1, 2022 |  | December 26, 2020 |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 51.0 |  |  | 11.4 | % |  | $ | 39.7 |  |  | 8.3 | % |  | $ | 79.1 |  |  | 8.8 | % |  | $ | 60.0 |  |  | 6.4 | % |
| Mexico | 38.3 |  |  | 8.6 |  |  | 51.3 |  |  | 10.7 |  |  | 71.3 |  |  | 8.0 |  |  | 91.1 |  |  | 9.8 |  |
| Other Americas | 2.7 |  |  | 0.6 |  |  | 4.0 |  |  | 0.8 |  |  | 4.7 |  |  | 0.5 |  |  | 6.8 |  |  | 0.8 |  |
| Total Americas | $ | 92.0 |  |  | 20.6 | % |  | $ | 95.0 |  |  | 19.8 | % |  | $ | 155.1 |  |  | 17.3 | % |  | $ | 157.9 |  |  | 17.0 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 115.0 |  |  | 25.8 | % |  | $ | 148.0 |  |  | 30.9 | % |  | $ | 257.3 |  |  | 28.8 | % |  | $ | 292.4 |  |  | 31.4 | % |
| Philippines | 8.9 |  |  | 2.0 |  |  | 40.6 |  |  | 8.5 |  |  | 18.0 |  |  | 2.0 |  |  | 103.4 |  |  | 11.1 |  |
| South Korea | 77.9 |  |  | 17.4 |  |  | 66.0 |  |  | 13.8 |  |  | 183.0 |  |  | 20.4 |  |  | 122.0 |  |  | 13.1 |  |
| Japan | 46.7 |  |  | 10.5 |  |  | 25.9 |  |  | 5.4 |  |  | 92.8 |  |  | 10.4 |  |  | 48.4 |  |  | 5.2 |  |
| Other Asia-Pacific | 77.0 |  |  | 17.2 |  |  | 68.1 |  |  | 14.2 |  |  | 133.9 |  |  | 15.0 |  |  | 137.2 |  |  | 14.7 |  |
| Total Asia-Pacific | $ | 325.5 |  |  | 72.9 | % |  | $ | 348.6 |  |  | 72.8 | % |  | $ | 685.0 |  |  | 76.5 | % |  | $ | 703.4 |  |  | 75.5 | % |
| EMEA | $ | 29.2 |  |  | 6.5 | % |  | $ | 35.2 |  |  | 7.4 | % |  | $ | 55.0 |  |  | 6.1 | % |  | $ | 69.9 |  |  | 7.5 | % |
| Total net revenue | $ | 446.7 |  |  |  |  | $ | 478.8 |  |  |  |  | $ | 895.1 |  |  |  |  | $ | 931.2 |  |  |  |

[0001628280-22-001745:mdna:58]
For the three and six months ended January 1, 2022, net revenue from customers outside the United States, based on customer shipping location, represented 88.6% and 91.2% of net revenue, respectively. For the three and six months ended December 26, 2020, net revenue from customers outside the United States, based on customer shipping location, represented 91.7% and 93.6% of net revenue, respectively.

[0001628280-22-001745:mdna:59]
[same as prior period, unchanged from 0001628280-21-021632:mdna:41]

[0001628280-22-001745:mdna:60]
38

[0001628280-22-001745:mdna:61]
[same as prior period, unchanged from 0001628280-21-021632:mdna:42]

[0001628280-22-001745:mdna:62]
[same as prior period, unchanged from 0001628280-21-021632:mdna:43]

[0001628280-22-001745:mdna:63]
|  | Three Months Ended |  | Six Months Ended |
|  | Gross Profit |  | Gross Margin |  | Gross Profit |  | Gross Margin |
|  | January 1, 2022 |  | December 26, 2020 |  | January 1, 2022 |  | December 26, 2020 |  | January 1, 2022 |  | December 26, 2020 |  | January 1, 2022 |  | December 26, 2020 |
| OpComms | $ | 201.8 |  |  | $ | 241.8 |  |  | 50.8 | % |  | 53.8 | % |  | $ | 427.7 |  |  | $ | 466.6 |  |  | 53.2 | % |  | 53.2 | % |
| Lasers | 26.2 |  |  | 14.1 |  |  | 53.1 | % |  | 47.5 | % |  | 47.0 |  |  | 24.5 |  |  | 51.3 | % |  | 45.7 | % |
| Segment total | $ | 228.0 |  |  | $ | 255.9 |  |  | 51.0 | % |  | 53.4 | % |  | $ | 474.7 |  |  | $ | 491.1 |  |  | 53.0 | % |  | 52.7 | % |
| Unallocated corporate items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation | (5.2) |  |  | (4.8) |  |  |  |  |  |  | (9.8) |  |  | (8.5) |  |  |  |  |  |
| Amortization of acquired intangibles | (15.9) |  |  | (15.0) |  |  |  |  |  |  | (31.7) |  |  | (30.0) |  |  |  |  |  |
| Inventory and fixed asset write down due to product line exits | (0.1) |  |  | (0.1) |  |  |  |  |  |  | (0.1) |  |  | (0.4) |  |  |  |  |  |
| Other (charges) gains (1) | 0.7 |  |  | (6.4) |  |  |  |  |  |  | 6.6 |  |  | (16.9) |  |  |  |  |  |
| Total | $ | 207.5 |  |  | $ | 229.6 |  |  | 46.5 | % |  | 48.0 | % |  | $ | 439.7 |  |  | $ | 435.3 |  |  | 49.1 | % |  | 46.7 | % |

[0001628280-22-001745:mdna:64]
(1)   Other (charges) gains of unallocated corporate items for the six months ended January 1, 2022 primarily relate to $5.9 million gain during the three months ended October 2, 2021 as a result of selling equipment that was no longer needed after we transferred certain product lines to new production facilities in fiscal 2021.

[0001628280-22-001745:mdna:65]
Other (charges) gains of unallocated corporate items for the three and six months ended December 26, 2020 relate to costs of transferring product lines to new production facilities of $0.4 million and $2.5 million, respectively. We also incurred excess and obsolete inventory charges driven by U.S. trade restrictions and the related decline in demand from Huawei of $0.8 million and $6.7 million during the three and six months ended December 26, 2020, respectively. In addition, during the three months ended December 26, 2020, we incurred $4.6 million impairment charges associated with excess capacity related to our Fiber laser business.

[0001628280-22-001745:mdna:66]
[same as prior period, unchanged from 0001628280-21-021632:mdna:47]

[0001628280-22-001745:mdna:67]
[same as prior period, unchanged from 0001628280-21-021632:mdna:48]

[0001628280-22-001745:mdna:68]
Gross margin for the three months ended January 1, 2022 decreased to 46.5% from 48.0% for the three months ended December 26, 2020. The decrease was primarily driven by lower gross margin from the OpComms as a result of a less profitable mix of products, including lower sales of higher margin 3D sensing products, and an increase of warranty costs of $4.1 million in Telecom and Datacom during the three months ended January 1, 2022.

[0001628280-22-001745:mdna:69]
Gross margin for the six months ended January 1, 2022 increased to 49.1% from 46.7% for the six months ended December 26, 2020 driven by higher gross margin from the Lasers segment due to the higher manufacturing levels as a result of return in customer demand for our kilowatt class fiber products following the recent recovery in industrial production, and lower excess and obsolete inventory charges, as we took charges during the six months ended December 26, 2020 driven by U.S. trade restrictions and the related decline in demand.

[0001628280-22-001745:mdna:70]
[same as prior period, unchanged from 0001628280-21-021632:mdna:50]

[0001628280-22-001745:mdna:71]
Although the magnitude of the impact of COVID-19 on our business operations remains uncertain and difficult to predict, and this remains a highly dynamic situation, we have experienced, and we expect that we may continue to experience disruptions to our and our customers’ businesses that will adversely impact our business, financial condition and results of operations. Due to the global supply chain constraint, we have had to incur incremental supply and procurement costs in order to increase our ability to fulfill demands from our customers. These costs have increased our inventory balances as of January 1, 2022 and will decrease our gross margin in the near term.

[0001628280-22-001745:mdna:72]
[same as prior period, unchanged from 0001628280-21-021632:mdna:52]

[0001628280-22-001745:mdna:73]
[same as prior period, unchanged from 0001628280-21-021632:mdna:53]

[0001628280-22-001745:mdna:74]
OpComms gross margin for the three months ended January 1, 2022 decreased to 50.8% from 53.8% for the three months ended December 26, 2020. The decrease was primarily due to a less profitable mix of products, including lower sales of higher margin 3D sensing products, and increase of warranty costs of $4.1 million in Telecom and Datacom during the three months ended January 1, 2022.

[0001628280-22-001745:mdna:75]
OpComms gross margin for the six months ended January 1, 2022 remained flat at 53.2% from 53.2% for the six months ended December 26, 2020.

[0001628280-22-001745:mdna:76]
[same as prior period, unchanged from 0001628280-21-021632:mdna:55]

[0001628280-22-001745:mdna:77]
Lasers gross margin for the three months ended January 1, 2022 increased to 53.1% from 47.5% for the three months ended December 26, 2020. The increase was primarily due to the higher manufacturing levels related to the return in customer demand for our kilowatt class fiber products, following the COVID-19 disruption in fiscal 2021

[0001628280-22-001745:mdna:78]
Lasers gross margin for the six months ended January 1, 2022 increased to 51.3% from 45.7% for the six months ended December 26, 2020. The increase was primarily due to the higher manufacturing levels related to the return in customer demand for our kilowatt class fiber products, following the COVID-19 disruption in fiscal 2021.

[0001628280-22-001745:mdna:79]
[same as prior period, unchanged from 0001628280-21-021632:mdna:57]

[0001628280-22-001745:mdna:80]
R&D expense increased by $0.4 million, or 0.8%, for the three months ended January 1, 2022 compared to the three months ended December 26, 2020, and increased by $4.1 million, or 4.0%, for the six months ended January 1, 2022 compared to the six months ended December 26, 2020. The increase in R&D expense for the six months ended January 1, 2022 was primarily driven by increased payroll and compensation expenses due to additional headcount and increased costs in supplies and tooling for R&D projects.

[0001628280-22-001745:mdna:81]
We believe that continuing our investments in R&D is critical to attaining our strategic objectives. Despite the uncertainty related to COVID-19 and the global economic outlook, we plan to continue to invest in R&D and new products that we believe will further differentiate us in the marketplace and we expect our investment in R&D to increase in absolute dollars in future quarters.

[0001628280-22-001745:mdna:82]
[same as prior period, unchanged from 0001628280-21-021632:mdna:60]

[0001628280-22-001745:mdna:83]
SG&A expense increased by $7.7 million, or 12.6%, during the three months ended January 1, 2022 compared to the three months ended December 26, 2020, primarily due to $4.6 million legal and advisory fees related to the pending NeoPhotonics acquisition and $2.3 million of professional service fees related to optimizing our international structure.

[0001628280-22-001745:mdna:84]
SG&A expense increased by $14.7 million, or 12.5%, during the six months ended January 1, 2022 compared to the six months ended December 26, 2020, primarily due to $5.0 million of legal and advisory fees related to the pending NeoPhotonics acquisition and $3.5 million of IT and professional service fees related to optimizing our international structure, $6.3 million increase in share based compensation primarily due to increase in stock price and employee headcount.

[0001628280-22-001745:mdna:85]
From time to time, we incur non-recurring expenses, such as mergers and acquisition-related expenses, which will likely increase our SG&A expenses in the near term and potentially impact our profitability expectations in any particular quarter.

[0001628280-22-001745:mdna:86]
[same as prior period, unchanged from 0001628280-21-021632:mdna:63]

[0001628280-22-001745:mdna:87]
[same as prior period, unchanged from 0001628280-21-021632:mdna:64]

[0001628280-22-001745:mdna:88]
During the six months ended January 1, 2022, we recorded a net reversal to our restructuring and related charges of $1.0 million, which was attributable to lower than anticipated employee severance charges primarily as a result of retaining and re-assigning certain employees.

[0001628280-22-001745:mdna:89]
During the three and six months ended December 26, 2020, we recorded $0.2 million for each period in restructuring and related charges in our condensed consolidated statements of operations.

[0001628280-22-001745:mdna:90]
[same as prior period, unchanged from 0001628280-21-021632:mdna:67]

[0001628280-22-001745:mdna:91]
For the three months ended January 1, 2022 and December 26, 2020, we recorded interest expense of $17.1 million and $16.3 million, respectively, driven by the amortization of the debt discount and issuance costs of our 2024 Notes and 2026 Notes.

[0001628280-22-001745:mdna:92]
For the six months ended January 1, 2022 and December 26, 2020, we recorded interest expense of $34.0 million and $32.3 million, respectively, driven by the amortization of the debt discount and issuance costs of our 2024 Notes and 2026 Notes.

[0001628280-22-001745:mdna:93]
[same as prior period, unchanged from 0001628280-21-021632:mdna:69]

[0001628280-22-001745:mdna:94]
[same as prior period, unchanged from 0001628280-21-021632:mdna:70]

[0001628280-22-001745:mdna:95]
|  | Three Months Ended |  | Six Months Ended |  |  |
|  | January 1, 2022 |  | December 26, 2020 |  | January 1, 2022 |  | December 26, 2020 |  |  |
| Foreign exchange gains (losses), net | $ | 0.7 |  |  | $ | (2.8) |  |  | $ | 0.6 |  |  | $ | (5.1) |  |  |  |
| Interest and investment income | 0.6 |  |  | 1.5 |  |  | 1.2 |  |  | 3.9 |  |  |  |
| Other income (expense), net | (0.3) |  |  | 0.4 |  |  | (0.2) |  |  | 0.9 |  |  |  |
| Total other income (expense), net | $ | 1.0 |  |  | $ | (0.9) |  |  | $ | 1.6 |  |  | $ | (0.3) |  |  |  |

[0001628280-22-001745:mdna:96]
For the three months ended January 1, 2022, other income (expense), net increased by $1.9 million in income compared to the three months ended December 26, 2020.  During the three months ended January 1, 2022, we recorded $3.5 million less in foreign exchange losses as compared to the three months ended December 26, 2020 as a result of more stable exchange rates between the U.S. dollar and certain foreign currencies.

[0001628280-22-001745:mdna:97]
For the six months ended January 1, 2022, other income (expense), net increased by $1.9 million in income as compared to the six months ended December 26, 2020, due to $5.7 million less in foreign exchange losses as a result of more stable exchange rates between the U.S. dollar and certain foreign currencies, offset by a $2.7 million decrease in interest and investment income as a result of our cash equivalent and investments acquired before COVID-19 maturing and being reinvested at lower yielding investments, while our average maturity and liquidity profile remained consistent.

[0001628280-22-001745:mdna:98]
[same as prior period, unchanged from 0001628280-21-021632:mdna:73]

[0001628280-22-001745:mdna:99]
| (in millions) | Three Months Ended |  | Six Months Ended |
|  | January 1, 2022 |  | December 26, 2020 |  | January 1, 2022 |  | December 26, 2020 |
| Provision for income taxes | $ | 12.4 |  |  | $ | 14.9 |  |  | $ | 30.5 |  |  | $ | 31.4 |  |

[0001628280-22-001745:mdna:100]
We recorded a tax provision of $12.4 million and $30.5 million for the three and six months ended January 1, 2022, respectively. Our tax provision for the three months ended January 1, 2022  includes a discrete tax benefit of $2.2 million, primarily related to currency re-measurement of certain tax related accounts and excess tax benefit related to stock-based compensation that vested during the quarter. Our estimated effective tax rate for fiscal 2022 differs from the 21% U.S. statutory rate primarily due to the income tax benefit from the earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate and U.S. federal R&D tax credits, partially offset by the income tax expense from the tax effect of Global Intangible Low-Taxed Income (“GILTI”), net of benefit for foreign tax credits, subpart F inclusion and non-deductible stock-based compensation.

[0001628280-22-001745:mdna:101]
[same as prior period, unchanged from 0001628280-21-021632:mdna:76]

[0001628280-22-001745:mdna:102]
[same as prior period, unchanged from 0001628280-21-021632:mdna:77]

[0001628280-22-001745:mdna:103]
As of January 1, 2022 and July 3, 2021, our cash and cash equivalents were $552.0 million and $774.3 million, respectively. As of January 1, 2022 and July 3, 2021, our short-term investments of $1,470.4 million and $1,171.7 million, respectively, were all held in the United States. Cash equivalents and short-term investments are primarily comprised of money market funds, U.S. treasury securities, and Corporate debt securities. Our investment policy and strategy is focused on the preservation of capital and supporting our liquidity requirements.

[0001628280-22-001745:mdna:104]
The total amount of cash outside the United States held by the non-United States entities as of January 1, 2022 and July 3, 2021 was $327.5 million and $113.3 million, respectively, which was primarily held by entities incorporated in the United Kingdom, the British Virgin Islands, Japan, Hong Kong, China, Canada and Thailand. Although the cash currently held in the United States, as well as the cash generated in the United States from future operations, is expected to cover our normal

[0001628280-22-001745:mdna:105]
operating requirements, a substantial amount of additional cash could be required for other purposes, such as capital expenditures to support our business and growth, including costs associated with increasing internal manufacturing capabilities, particularly in our Thailand facility, strategic transactions and partnerships, and future acquisitions.

[0001628280-22-001745:mdna:106]
[same as prior period, unchanged from 0001628280-21-021632:mdna:80]

[0001628280-22-001745:mdna:107]
[same as prior period, unchanged from 0001628280-21-021632:mdna:81]

[0001628280-22-001745:mdna:108]
We believe that our cash and cash equivalents as of January 1, 2022 and cash flows from our operating activities will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months. However, if market conditions are favorable, we may evaluate alternatives to opportunistically pursue additional financing.

[0001628280-22-001745:mdna:109]
[same as prior period, unchanged from 0001628280-21-021632:mdna:83]

[0001628280-22-001745:mdna:110]
[same as prior period, unchanged from 0001628280-21-021632:mdna:84]

[0001628280-22-001745:mdna:111]
[same as prior period, unchanged from 0001628280-21-021632:mdna:85]

[0001628280-22-001745:mdna:112]
[same as prior period, unchanged from 0001628280-21-021632:mdna:86]

[0001628280-22-001745:mdna:113]
[same as prior period, unchanged from 0001628280-21-021632:mdna:87]

[0001628280-22-001745:mdna:114]
[same as prior period, unchanged from 0001628280-21-021632:mdna:88]

[0001628280-22-001745:mdna:115]
[same as prior period, unchanged from 0001628280-21-021632:mdna:89]

[0001628280-22-001745:mdna:116]
[same as prior period, unchanged from 0001628280-21-021632:mdna:90]

[0001628280-22-001745:mdna:117]
[same as prior period, unchanged from 0001628280-21-021632:mdna:91]

[0001628280-22-001745:mdna:118]
[same as prior period, unchanged from 0001628280-21-021632:mdna:92]

[0001628280-22-001745:mdna:119]
[same as prior period, unchanged from 0001628280-21-021632:mdna:93]

[0001628280-22-001745:mdna:120]
[same as prior period, unchanged from 0001628280-21-021632:mdna:94]

[0001628280-22-001745:mdna:121]
[same as prior period, unchanged from 0001628280-21-021632:mdna:95]

[0001628280-22-001745:mdna:122]
[same as prior period, unchanged from 0001628280-21-021632:mdna:96]

[0001628280-22-001745:mdna:123]
[same as prior period, unchanged from 0001628280-21-021632:mdna:97]

[0001628280-22-001745:mdna:124]
•acquisitions, in particular our recently announced acquisition of NeoPhotonics.

[0001628280-22-001745:mdna:125]
The following table summarizes certain of our contractual obligations as of January 1, 2022, and the effect such obligations are expected to have on our liquidity and cash flow over the next five years (in millions):

[0001628280-22-001745:mdna:126]
|  | Payments due by period |
|  | Total |  | Less than 1 year |  | 1 - 3 years |  | 3 - 5 years |  | More than 5 years |
| Contractual Obligations |  |  |  |  |  |  |  |  |  |
| Asset retirement obligations | $ | 4.7 |  |  | $ | 0.1 |  |  | $ | 1.0 |  |  | $ | 1.1 |  |  | $ | 2.5 |  |
| Operating lease liabilities, including imputed interest (1) | 76.2 |  |  | 13.5 |  |  | 24.9 |  |  | 15.7 |  |  | 22.1 |  |
| Pension plan contributions (2) | 0.5 |  |  | 0.5 |  |  | — |  |  | — |  |  | — |  |
| Purchase obligations (3) | 314.5 |  |  | 292.6 |  |  | 21.8 |  |  | 0.1 |  |  | — |  |
| Convertible notes - principal (4) | 1,500.0 |  |  | — |  |  | 450.0 |  |  | 1,050.0 |  |  | — |  |
| Convertible notes - interest (4) | 29.0 |  |  | 6.4 |  |  | 12.1 |  |  | 10.5 |  |  | — |  |
| Total | $ | 1,924.9 |  |  | $ | 313.1 |  |  | $ | 509.8 |  |  | $ | 1,077.4 |  |  | $ | 24.6 |  |

[0001628280-22-001745:mdna:127]
(1) The amounts of operating lease liabilities in the table above do not include any sublease income amounts nor do they include payments for short-term leases or variable lease payments. As of January 1, 2022, we expect to receive sublease income of approximately $2.1 million over the next two years. Refer to “Note 7. Leases” in the notes to condensed consolidated financial statements.

[0001628280-22-001745:mdna:128]
[same as prior period, unchanged from 0001628280-21-021632:mdna:102]

[0001628280-22-001745:mdna:129]
(3) Purchase obligations represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Refer to “Note 14. Commitments and Contingencies” in the notes to condensed consolidated financial statements.

[0001628280-22-001745:mdna:130]
(4) The amount includes principal and interest payment in cash on our 0.25% Convertible Notes due in 2024 (the “2024 Notes”) through March 2024, and principal and interest on our 0.50% Convertible Notes due in 2026 (the “2026 Notes” and together with the 2024 Notes, the “Notes”) through December 2026. The 2024 Notes have a maturity date of March 15, 2024 and the 2026 Notes have a maturity date of December 15, 2026. The principal balances of our Notes are reflected in the payment periods in the table above based on their respective contractual maturities assuming no conversion. Refer to “Note 9. Debt” in the notes to condensed consolidated financial statements.

[0001628280-22-001745:mdna:131]
[same as prior period, unchanged from 0001628280-21-021632:mdna:105]

[0001628280-22-001745:mdna:132]
[same as prior period, unchanged from 0001628280-21-021632:mdna:106]

[0001628280-22-001745:mdna:133]
As of January 1, 2022, the debt component of our 2024 Notes of $401.0 million (principal balance of $450.0 million maturing in 2024) is presented in current liabilities in our condensed consolidated balance sheet since our stock price exceeded $78.80 for 20 of the last 30 trading days of the quarter ended January 1, 2022 and the 2024 Notes are convertible at the option of the holders. During the six months ended January 1, 2022, we received conversion requests for less than $0.1 million principal amount of the 2024 Notes, which were settled in cash in the first half of fiscal 2022.

[0001628280-22-001745:mdna:134]
As of January 1, 2022, the debt component of our 2026 Notes of $810.3 million (principal balance of $1,050.0 million maturing in 2026) is presented in non-current liabilities. If the closing price of our stock exceeds $129.08 for 20 of the last 30 trading days of any future quarter, our 2026 Notes would also become convertible at the option of the holders and the debt component would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-22-001745:mdna:135]
[same as prior period, unchanged from 0001628280-21-021632:mdna:109]

[0001628280-22-001745:mdna:136]
On May 7, 2021, our board of directors approved the 2021 share buyback program, which authorizes us to use up to $700.0 million to purchase our own shares of common stock. The buyback program is authorized for 2 years but may be suspended or terminated by the board of directors at any time. During the six months ended January 1, 2022, we repurchased 1.4 million shares of our common stock at an average price of $84.31 per share for an aggregate purchase price of $121.6 million.

[0001628280-22-001745:mdna:137]
Since the share buyback program was approved by the board of directors, we have repurchased in aggregate, a total of 4.5 million shares of our common stock at an average price of $79.89 per share for total payment of $362.6 million. All repurchased shares were retired immediately. The price, timing, amount, and method of such repurchases will be determined based on the valuation of market conditions and other factors, at prices determined to be attractive and in the best interests of both Lumentum and our stockholders. We recorded the $362.6 million aggregate purchase price as a reduction of retained earnings within our condensed consolidated balance sheet

[0001628280-22-001745:mdna:138]
[same as prior period, unchanged from 0001628280-21-021632:mdna:112]

[0001628280-22-001745:mdna:139]
As of January 1, 2022, our other non-current liabilities also include $25.9 million of unrecognized tax benefit for uncertain tax positions. We are unable to reliably estimate the timing of future payments related to uncertain tax positions.

[0001628280-22-001745:mdna:140]
[same as prior period, unchanged from 0001628280-21-021632:mdna:114]

[0001628280-22-001745:mdna:141]
As of January 1, 2022, our balance of cash and cash equivalents decreased by $222.3 million, to $552.0 million from $774.3 million as of July 3, 2021. The decrease in cash and cash equivalents during the six months ended January 1, 2022 was due to cash used in investing activities of $345.8 million and cash used in financing activities of $144.9 million, offset by cash provided by operating activities of $268.4 million.

[0001628280-22-001745:mdna:142]
[same as prior period, unchanged from 0001628280-21-021632:mdna:116]

[0001628280-22-001745:mdna:143]
Cash provided by operating activities was $268.4 million during the six months ended January 1, 2022, which reflects net income of $138.2 million and non-cash items of $168.4 million for the six months ended January 1, 2022, offset by  $38.2 million change in operating assets and liabilities. Changes in our operating assets and liabilities related primarily to an increase in accounts receivable of $26.4 million, and an increase in inventories of $11.0 million.

[0001628280-22-001745:mdna:144]
Cash provided by operating activities was $233.2 million during the six months ended December 26, 2020, which reflects net income of $150.3 million and non-cash items of $170.4 million for the six months ended December 26, 2020, offset by $87.5 million change in operating assets and liabilities. Changes in our operating assets and liabilities related primarily to an increase in accounts receivable of $43.7 million, an increase in inventories of $16.9 million, and a decrease in accounts payable of $35.8 million.

[0001628280-22-001745:mdna:145]
[same as prior period, unchanged from 0001628280-21-021632:mdna:119]

[0001628280-22-001745:mdna:146]
Cash used in investing activities of $345.8 million during the six months ended January 1, 2022 was attributable to purchases of short-term investments, net of sales and maturities of $307.8 million, and capital expenditures of $44.0 million,  offset by proceeds from the sales of property, plant and equipment of $6.0 million.

[0001628280-22-001745:mdna:147]
Cash used in investing activities of $189.0 million during the six months ended December 26, 2020 was primarily attributable to purchases of short-term investments, net of sales and maturities of $129.8 million, capital expenditures of $50.5 million, and payment for asset acquisition of $10.0 million.

[0001628280-22-001745:mdna:148]
[same as prior period, unchanged from 0001628280-21-021632:mdna:122]

[0001628280-22-001745:mdna:149]
Cash used in financing activities of $144.9 million during the six months ended January 1, 2022 resulted from the repurchase of shares of our common stock of $126.6 million and tax payments related to net share settlement of restricted stock of $24.9 million, offset by proceeds from employee stock plans of $6.6 million.

[0001628280-22-001745:mdna:150]
Cash used in financing activities of $20.9 million during the six months ended December 26, 2020 resulted primarily from tax payments related to net share settlement of restricted stock of $26.2 million, offset by the proceeds from employee stock plans of $5.5 million.
