# LITE notes — 0001628280-22-001745


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001628280-22-001745:notes:1]
[same as prior period, unchanged from 0001628280-21-021632:notes:1]

[0001628280-22-001745:notes:2]
[same as prior period, unchanged from 0001628280-21-021632:notes:2]

[0001628280-22-001745:notes:3]
Lumentum Holdings Inc. (“we,” “us,” “our”, “Lumentum” or the “Company”) is an industry-leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including Optical Communications (“OpComms”) and Commercial Lasers (“Lasers”) for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology, and our volume manufacturing capability, to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be original equipment manufacturers (“OEMs”) that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that network equipment manufacturers (“NEMs”) assemble into communications networking systems, which they sell to network service providers, operators or enterprises with their own networks. Similarly, many of our Lasers products customers incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For 3D sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, gaming, and other applications who then integrate our devices within their products, for eventual resale to consumers and also into other industrial applications.

[0001628280-22-001745:notes:4]
[same as prior period, unchanged from 0001628280-21-021632:notes:4]

[0001628280-22-001745:notes:5]
The accompanying condensed consolidated financial statements have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”), which requires management to make estimates and assumptions that affect the amounts reported in our condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact us in the future, actual results may be different from the estimates. Operating results for the quarter ended January 1, 2022 are not necessarily indicative of the results that may be expected for the fiscal year ending July 2, 2022. In the opinion of the Company’s management, the information presented herein reflects all normal and recurring adjustments necessary for a fair presentation of our results of operations, financial position, stockholders’ equity and cash flows.

[0001628280-22-001745:notes:6]
Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are inventory valuation, revenue recognition, income taxes, long-lived asset valuation, goodwill and business combination.

[0001628280-22-001745:notes:7]
The COVID-19 pandemic has created and may continue to create significant uncertainty in global financial markets, which has disrupted and harmed, and may continue to disrupt and harm, our business, financial condition, and results of operations. The extent of the impact of COVID-19 on our operational and financial performance will depend on certain developments, including but not limited to the duration and spread of the outbreak, duration of local, state and federal issued public health orders in each jurisdiction where we operate or in which our customers and suppliers operate, impact on our customers and our sales cycles, impact on our supply chain and manufacturing partners, impact on our employees and impact on regional and worldwide economies and financial markets in general, all of which are uncertain and cannot be predicted. We assessed the potential impact that this pandemic has on our estimates as of January 1, 2022 and determined that there were no material impacts. However, due to the global supply chain constraint, we have had to incur incremental supply and procurement costs in order to increase our ability to fulfill demands from our customers. These costs have increased our inventory balances as of January 1, 2022 and will decrease our gross margin in the near term.

[0001628280-22-001745:notes:8]
[same as prior period, unchanged from 0001628280-21-021632:notes:8]

[0001628280-22-001745:notes:9]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2022 is a 52-week year ending on July 2, 2022, with the quarter ended January 1, 2022 being a 13-week quarterly period. Our fiscal 2021 was a 53-week year that ended on July 3, 2021, with the quarter ended December 26, 2020 being a 13-week quarterly period.

[0001628280-22-001745:notes:10]
[same as prior period, unchanged from 0001628280-21-021632:notes:10]

[0001628280-22-001745:notes:11]
These interim unaudited condensed consolidated financial statements include the accounts of the Company and its wholly-owned subsidiaries. All inter-company transactions and balances are eliminated in consolidation.

[0001628280-22-001745:notes:12]
Accounting Policies

[0001628280-22-001745:notes:13]
The condensed consolidated financial statements and accompanying related notes should be read in conjunction with the audited consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended July 3, 2021. There have been no significant changes to our accounting policies during the three and six months ended January 1, 2022.

[0001628280-22-001745:notes:14]
Business Combination

[0001628280-22-001745:notes:15]
On November 4, 2021, Lumentum and NeoPhotonics Corporation (“NeoPhotonics”) announced a merger agreement (the “Merger Agreement”). Under the terms of the Merger Agreement, NeoPhotonics stockholders will receive $16.00 per share in cash for each NeoPhotonics share they own. As of January 1, 2022, the estimated total transaction consideration is expected to be approximately $918 million.  The cash consideration will be funded from the combined company’s balance sheet.

[0001628280-22-001745:notes:16]
On January 14, 2022, Lumentum and NeoPhotonics entered into a credit agreement where Lumentum agreed to make delayed draw term loans (“loans”) to NeoPhotonics in an aggregate principal amount not to exceed $50.0 million to help fund capital expenditures and increased working capital associated with NeoPhotonics’ growth plans. The loans will mature on January 14, 2024 unless earlier repaid or accelerated. The loans bear interest at the Wall Street Journal “prime rate”, payable monthly in arrears on the first day of each month. There have not been any drawdown of the loans.

[0001628280-22-001745:notes:17]
The Merger Agreement contains certain termination rights for both Lumentum and NeoPhotonics and provides that upon termination of the Merger Agreement under specified circumstances (including termination by NeoPhotonics to accept a superior proposal), NeoPhotonics may be required to pay Lumentum a termination fee of $27.5 million. The Merger Agreement further provides that if the Merger Agreement is terminated for failure to obtain antitrust approval, Lumentum may be required to pay NeoPhotonics a termination fee of $55.1 million; and if Lumentum takes certain specified actions, (including entering into any definitive agreement for an acquisition by stock purchase, merger, consolidation, amalgamation, purchase of assets, license or otherwise of any ownership interest or assets of any Person) that cause a material delay in, or results in the failure of, the consummation of the Merger, Lumentum may be required to payNeoPhotonics an additional termination fee of $36.7 million.
The Boards of Directors of Lumentum and NeoPhotonics have unanimously approved the transaction and the Merger Agreement. The transaction is subject to customary closing conditions, including the absence of certain legal impediments, the expiration or termination of the required waiting periods under the Hart-Scott-Rodino Antitrust Improvements Act of 1976, as amended, receipt of any required antitrust and regulatory approvals.  The transaction was approved by the NeoPhotonics stockholders on February 1, 2022. The transaction is not subject to any financing condition. We expect this transaction to be completed in the second half of calendar year 2022.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001628280-22-001745:notes:18]
Accounting PoliciesThe condensed consolidated financial statements and accompanying related notes should be read in conjunction with the audited consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended July 3, 2021. 
Accounting Pronouncements Recently Adopted

[0001628280-22-001745:notes:19]
In December 2019, the Financial Accounting Standard Board (“FASB”) issued Accounting Standards Update (“ASU”) 2019-12, Simplifying the Accounting for Income Taxes (Topic 740), which is intended to simplify various aspects related to accounting for income taxes by removing certain exceptions to the general principles in Topic 740 and which also clarifies and amends existing guidance to improve consistent application. ASU 2019-12 is effective for us at the beginning of fiscal year 2022, including interim periods within that reporting period. We adopted ASU 2019-12 in our first quarter of fiscal year 2022 on a prospective basis with no material impact to our condensed consolidated financial statements.

[0001628280-22-001745:notes:20]
Accounting Pronouncements Not Yet Effective

[0001628280-22-001745:notes:21]
In August 2020, FASB issued ASU 2020-06, Debt—Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging—Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity, which simplifies the accounting for convertible instruments by removing the separation models for (i) convertible debt with a cash conversion feature and (ii) convertible instruments with a beneficial conversion feature. As a result, a convertible debt instrument will be accounted for as a single liability measured at its amortized cost. Also, ASU 2020-06 requires the application of the if-converted method for calculating diluted earnings per share and the treasury stock method will be no longer available. The new guidance is effective for fiscal years beginning after December 15, 2021, 
with early adoption permitted no earlier than fiscal years beginning after December 15, 2020. ASU 2020-06 is effective for us in our first quarter of fiscal year 2023. We are currently evaluating the impact of ASU 2020-06 on our consolidated financial statements.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001628280-22-001745:notes:22]
Note 2. Recently Issued Accounting Pronouncements

[0001628280-22-001745:notes:23]
Accounting Pronouncements Recently Adopted


## us-gaap:EarningsPerShareTextBlock

[0001628280-22-001745:notes:24]
[same as prior period, unchanged from 0001628280-21-021632:notes:18]

[0001628280-22-001745:notes:25]
[same as prior period, unchanged from 0001628280-21-021632:notes:19]

[0001628280-22-001745:notes:26]
|  | Three Months Ended |  | Six Months Ended |
|  | January 1, 2022 |  | December 26, 2020 |  | January 1, 2022 |  | December 26, 2020 |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income - basic and diluted | $ | 56.7 |  |  | $ | 83.2 |  |  | $ | 138.2 |  |  | $ | 150.3 |  |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted average common shares outstanding - basic | 72.3 |  |  | 75.6 |  |  | 72.5 |  |  | 75.5 |  |  |
| Effect of dilutive securities from stock-based benefit plans | 0.5 |  |  | 0.7 |  |  | 0.6 |  |  | 0.8 |  |  |
| Shares issuable assuming conversion of the 2024 Notes | 2.5 |  |  | 2.1 |  |  | 2.3 |  |  | 2.0 |  |  |
| Weighted average common shares outstanding - diluted | 75.3 |  |  | 78.4 |  |  | 75.4 |  |  | 78.3 |  |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic | $ | 0.78 |  |  | $ | 1.10 |  |  | $ | 1.91 |  |  | $ | 1.99 |  |  |
| Diluted | $ | 0.75 |  |  | $ | 1.06 |  |  | $ | 1.83 |  |  | $ | 1.92 |  |  |

[0001628280-22-001745:notes:27]
[same as prior period, unchanged from 0001628280-21-021632:notes:21]

[0001628280-22-001745:notes:28]
[same as prior period, unchanged from 0001628280-21-021632:notes:22]

[0001628280-22-001745:notes:29]
[same as prior period, unchanged from 0001628280-21-021632:notes:23]

[0001628280-22-001745:notes:30]
•The potentially dilutive shares resulting from the 2024 Notes (as defined in Note 9) were included in the calculation of diluted income per share for the three and six months ended January 1, 2022 and December 26, 2020, respectively, since the average price of our common stock exceeded the conversion price of $60.62 in both periods.

[0001628280-22-001745:notes:31]
Anti-dilutive potential shares are excluded from the calculation of diluted earnings per share if their exercise price exceeded the average market price during the period or the share-based awards were determined to be anti-dilutive based on applying the treasury stock method. Anti-dilutive shares excluded from the calculation of diluted earnings per share were less than 0.1 million and 0.4 million for the three and six months ended January 1, 2022. Anti-dilutive shares excluded from the calculation of diluted earnings per share were less than 0.1 million and 0.5 million shares for the three and six months ended December 26, 2020, respectively.


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001628280-22-001745:notes:32]
[same as prior period, unchanged from 0001628280-21-021632:notes:26]

[0001628280-22-001745:notes:33]
[same as prior period, unchanged from 0001628280-21-021632:notes:27]

[0001628280-22-001745:notes:34]
|  | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| January 1, 2022: |  |  |  |  |  |  |  |
| Cash | $ | 212.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 212.3 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 16.0 |  |  | — |  |  | — |  |  | 16.0 |  |
| Money market funds | 148.7 |  |  | — |  |  | — |  |  | 148.7 |  |
| U.S. Treasury securities | 175.0 |  |  | — |  |  | — |  |  | 175.0 |  |
| Total cash and cash equivalents | $ | 552.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 552.0 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 15.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 15.4 |  |
| Commercial paper | 93.7 |  |  | — |  |  | — |  |  | 93.7 |  |
| Corporate debt securities | 680.7 |  |  | 0.1 |  |  | (1.8) |  |  | 679.0 |  |
| Municipal bonds | 2.0 |  |  | — |  |  | — |  |  | 2.0 |  |
| U.S. Agency securities | 60.3 |  |  | — |  |  | (0.2) |  |  | 60.1 |  |
| U.S. Treasury securities | 620.9 |  |  | — |  |  | (0.7) |  |  | 620.2 |  |
| Total short-term investments | $ | 1,473.0 |  |  | $ | 0.1 |  |  | $ | (2.7) |  |  | $ | 1,470.4 |  |
| July 3, 2021: |  |  |  |  |  |  |  |
| Cash | $ | 128.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 128.3 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 7.5 |  |  | — |  |  | — |  |  | 7.5 |  |
| Corporate debt securities | 7.0 |  |  | — |  |  | — |  |  | 7.0 |  |
| Money market funds | 631.5 |  |  | — |  |  | — |  |  | 631.5 |  |
| Total cash and cash equivalents | $ | 774.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 774.3 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 28.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 28.5 |  |
| Commercial paper | 136.7 |  |  | — |  |  | — |  |  | 136.7 |  |
| Corporate debt securities | 626.0 |  |  | 0.3 |  |  | (0.4) |  |  | 625.9 |  |
| Municipal bonds | 1.0 |  |  | — |  |  | — |  |  | 1.0 |  |
| U.S. Agency securities | 29.3 |  |  | — |  |  | — |  |  | 29.3 |  |
| U.S. Treasury securities | 350.3 |  |  | — |  |  | — |  |  | 350.3 |  |
| Total short-term investments | $ | 1,171.8 |  |  | $ | 0.3 |  |  | $ | (0.4) |  |  | $ | 1,171.7 |  |

[0001628280-22-001745:notes:35]
We use the specific-identification method to determine any realized gains or losses from the sale of our short-term investments classified as available-for-sale. During the three and six months ended January 1, 2022 and December 26, 2020, we did not realize significant gains or losses on a gross level from the sale of our short-term investments classified as available-for-sale.

[0001628280-22-001745:notes:36]
During the three and six months ended January 1, 2022, our other income (expense), net was $1.0 million income and $1.6 million income, respectively, which includes interest and investment income on cash equivalents and short-term investments of $0.6 million and $1.2 million, respectively. During the three and six months ended December 26, 2020, our other income (expense), net was $0.9 million expense and $0.3 million expense, respectively, which includes interest and investment income on cash equivalents and short-term investments of $1.5 million and $3.9 million, respectively.

[0001628280-22-001745:notes:37]
As of January 1, 2022 and July 3, 2021, we recorded interest receivable of $4.4 million and $4.1 million, respectively, in prepayments and other current assets within the condensed consolidated balance sheets. We did not recognize an allowance for credit losses against interest receivables in any of the periods presented as there were no such losses.

[0001628280-22-001745:notes:38]
As of January 1, 2022 and July 3, 2021, the Company does not have any cash equivalents and short-term investments that have been in a continuous unrealized gain or loss position for more than 12 months as of the periods presented. The following table summarizes unrealized losses on our cash equivalents and short-term investments by category that have been in a continuous unrealized loss position for less than 12 months as of the periods presented (in millions):

[0001628280-22-001745:notes:39]
|  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |
| January 1, 2022: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 60.1 |  |  | (0.2) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | 3.3 |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 83.7 |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 645.9 |  |  | (1.8) |  |  |  |  |  |  |  |  |  |
| Municipal bonds | 2.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 516.3 |  |  | (0.7) |  |  |  |  |  |  |  |  |  |
| Total | $ | 1,311.3 |  |  | $ | (2.7) |  |  |  |  |  |  |  |  |  |
| July 3, 2021: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 28.3 |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | 6.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 43.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 432.3 |  |  | (0.4) |  |  |  |  |  |  |  |  |  |
| Municipal bonds | 1.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 106.9 |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | 617.5 |  |  | $ | (0.4) |  |  |  |  |  |  |  |  |  |

[0001628280-22-001745:notes:40]
[same as prior period, unchanged from 0001628280-21-021632:notes:33]

[0001628280-22-001745:notes:41]
|  | January 1, 2022 |  | July 3, 2021 |
|  | Amortized Cost |  | Fair Value |  | Amortized Cost |  | Fair Value |
| Due in 1 year | $ | 850.9 |  |  | $ | 850.2 |  |  | $ | 587.0 |  |  | $ | 587.1 |  |
| Due in 1 year through 5 years | 622.1 |  |  | 620.2 |  |  | 584.8 |  |  | 584.6 |  |
|  | $ | 1,473.0 |  |  | $ | 1,470.4 |  |  | $ | 1,171.8 |  |  | $ | 1,171.7 |  |

[0001628280-22-001745:notes:42]
[same as prior period, unchanged from 0001628280-21-021632:notes:35]


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-22-001745:notes:43]
[same as prior period, unchanged from 0001628280-21-021632:notes:36]

[0001628280-22-001745:notes:44]
[same as prior period, unchanged from 0001628280-21-021632:notes:37]

[0001628280-22-001745:notes:45]
[same as prior period, unchanged from 0001628280-21-021632:notes:38]

[0001628280-22-001745:notes:46]
[same as prior period, unchanged from 0001628280-21-021632:notes:39]

[0001628280-22-001745:notes:47]
[same as prior period, unchanged from 0001628280-21-021632:notes:40]

[0001628280-22-001745:notes:48]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| January 1, 2022: (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | — |  |  | $ | 16.0 |  |  | $ | — |  |  | $ | 16.0 |  |
| Money market funds | 148.7 |  |  | — |  |  | — |  |  | 148.7 |  |
| U.S. Treasury securities | 175.0 |  |  | — |  |  | — |  |  | 175.0 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 15.4 |  |  | — |  |  | 15.4 |  |
| Commercial paper | — |  |  | 93.7 |  |  | — |  |  | 93.7 |  |
| Asset-backed securities | — |  |  | — |  |  | — |  |  | — |  |
| Corporate debt securities | — |  |  | 679.0 |  |  | — |  |  | 679.0 |  |
| Municipal bonds | — |  |  | 2.0 |  |  | — |  |  | 2.0 |  |
| U.S. Agency securities | — |  |  | 60.1 |  |  | — |  |  | 60.1 |  |
| U.S. Treasury securities | 620.2 |  |  | — |  |  | — |  |  | 620.2 |  |
| Total assets | $ | 943.9 |  |  | $ | 866.2 |  |  | $ | — |  |  | $ | 1,810.1 |  |

[0001628280-22-001745:notes:49]
(1)  Excludes $212.3 million in cash held in our bank accounts as of January 1, 2022.

[0001628280-22-001745:notes:50]
[same as prior period, unchanged from 0001628280-21-021632:notes:43]

[0001628280-22-001745:notes:51]
[same as prior period, unchanged from 0001628280-21-021632:notes:44]

[0001628280-22-001745:notes:52]
[same as prior period, unchanged from 0001628280-21-021632:notes:45]

[0001628280-22-001745:notes:53]
[same as prior period, unchanged from 0001628280-21-021632:notes:46]

[0001628280-22-001745:notes:54]
[same as prior period, unchanged from 0001628280-21-021632:notes:47]

[0001628280-22-001745:notes:55]
|  | January 1, 2022 |  | July 3, 2021 |
|  | Carrying Amount |  | Estimated Fair Value |  | Carrying Amount |  | Estimated Fair Value |
| 2026 Notes | 810.3 |  |  | $ | 1,311.2 |  |  | $ | 789.8 |  |  | $ | 1,146.1 |  |
| 2024 Notes | 401.0 |  |  | 805.5 |  |  | 390.7 |  |  | 669.3 |  |
|  | $ | 1,211.3 |  |  | $ | 2,116.7 |  |  | $ | 1,180.5 |  |  | $ | 1,815.4 |  |

[0001628280-22-001745:notes:56]
[same as prior period, unchanged from 0001628280-21-021632:notes:49]

[0001628280-22-001745:notes:57]
[same as prior period, unchanged from 0001628280-21-021632:notes:50]

[0001628280-22-001745:notes:58]
Management utilizes various valuation methods, including an income approach, a market approach and a cost approach, to estimate the fair value of intangibles and other long-lived assets. During the annual impairment testing performed in the fourth quarter of fiscal 2021, we concluded that our intangible and other long-lived assets were not impaired. We review our intangible and other long-lived assets for impairment at least annually in the fourth quarter of each fiscal year, absent any interim indicators of impairment.  There were no indicators of impairment during the six months ended January 1, 2022.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001628280-22-001745:notes:59]
[same as prior period, unchanged from 0001628280-21-021632:notes:52]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-22-001745:notes:60]
[same as prior period, unchanged from 0001628280-21-021632:notes:53]

[0001628280-22-001745:notes:61]
[same as prior period, unchanged from 0001628280-21-021632:notes:54]

[0001628280-22-001745:notes:62]
We did not have any allowance for credit losses other than our allowance for uncollectible accounts receivable. As of January 1, 2022 and July 3, 2021, the allowance for credit losses on our trade receivables was $0.2 million and $0.4 million, respectively.

[0001628280-22-001745:notes:63]
[same as prior period, unchanged from 0001628280-21-021632:notes:56]

[0001628280-22-001745:notes:64]
[same as prior period, unchanged from 0001628280-21-021632:notes:57]

[0001628280-22-001745:notes:65]
|  | January 1, 2022 |  | July 3, 2021 |
| Raw materials and purchased parts | $ | 71.6 |  |  | $ | 64.4 |  |
| Work in process | 86.9 |  |  | 79.0 |  |
| Finished goods | 49.6 |  |  | 53.0 |  |
| Inventories | $ | 208.1 |  |  | $ | 196.4 |  |

[0001628280-22-001745:notes:66]
[same as prior period, unchanged from 0001628280-21-021632:notes:59]

[0001628280-22-001745:notes:67]
[same as prior period, unchanged from 0001628280-21-021632:notes:60]

[0001628280-22-001745:notes:68]
|  | January 1, 2022 |  | July 3, 2021 |
| Operating lease right-of-use assets | $ | 99.7 |  |  | $ | 87.3 |  |
| Less: accumulated amortization | (24.6) |  |  | (19.9) |  |
| Operating lease right-of-use assets, net | $ | 75.1 |  |  | $ | 67.4 |  |

[0001628280-22-001745:notes:69]
[same as prior period, unchanged from 0001628280-21-021632:notes:62]

[0001628280-22-001745:notes:70]
[same as prior period, unchanged from 0001628280-21-021632:notes:63]

[0001628280-22-001745:notes:71]
|  | January 1, 2022 |  | July 3, 2021 |
| Land | $ | 49.4 |  |  | $ | 38.2 |  |
| Buildings and improvement | 96.0 |  |  | 92.7 |  |
| Machinery and equipment | 532.9 |  |  | 498.3 |  |
| Computer equipment and software | 30.0 |  |  | 28.6 |  |
| Furniture and fixtures | 8.8 |  |  | 8.8 |  |
| Leasehold improvements | 34.6 |  |  | 33.9 |  |
| Finance lease right-of-use assets | — |  |  | 28.1 |  |
| Construction in progress | 37.5 |  |  | 43.4 |  |
|  | 789.2 |  |  | 772.0 |  |
| Less: Accumulated depreciation | (429.6) |  |  | (410.9) |  |
| Property, plant and equipment, net | $ | 359.6 |  |  | $ | 361.1 |  |

[0001628280-22-001745:notes:72]
As of January 1, 2022, finance lease assets are fully amortized and there are no outstanding finance lease liabilities.

[0001628280-22-001745:notes:73]
During the six months ended January 1, 2022, we purchased land and buildings in Thailand and Slovenia with the total fair value of $15.1 million in order to expand our manufacturing capacity.

[0001628280-22-001745:notes:74]
During the three and six months ended January 1, 2022, we recorded depreciation expense of $20.6 million and $41.0 million, respectively. During the three and six months ended December 26, 2020, we recorded depreciation expense of $23.8 million and $47.6 million, respectively.

[0001628280-22-001745:notes:75]
[same as prior period, unchanged from 0001628280-21-021632:notes:66]

[0001628280-22-001745:notes:76]
[same as prior period, unchanged from 0001628280-21-021632:notes:67]

[0001628280-22-001745:notes:77]
[same as prior period, unchanged from 0001628280-21-021632:notes:68]

[0001628280-22-001745:notes:78]
|  | January 1, 2022 |  | July 3, 2021 |
| Restructuring accrual and related charges (1) | $ | 0.3 |  |  | $ | 5.7 |  |
| Warranty accrual (2) | 8.6 |  |  | 5.0 |  |
| Deferred revenue and customer deposits | — |  |  | 0.6 |  |
| Income tax payable (3) | 20.5 |  |  | 43.5 |  |
| Other current liabilities | 4.5 |  |  | 3.0 |  |
| Other current liabilities | $ | 33.9 |  |  | $ | 57.8 |  |

[0001628280-22-001745:notes:79]
[same as prior period, unchanged from 0001628280-21-021632:notes:70]

[0001628280-22-001745:notes:80]
(2) Refer to “Note 14. Commitments and Contingencies.”

[0001628280-22-001745:notes:81]
(3)  Refer to “Note 12. Income Taxes.”

[0001628280-22-001745:notes:82]
[same as prior period, unchanged from 0001628280-21-021632:notes:73]

[0001628280-22-001745:notes:83]
[same as prior period, unchanged from 0001628280-21-021632:notes:74]

[0001628280-22-001745:notes:84]
|  | January 1, 2022 |  | July 3, 2021 |
| Asset retirement obligations | $ | 4.7 |  |  | $ | 4.7 |  |
| Pension and related accrual (1) | 10.9 |  |  | 10.8 |  |
| Unrecognized tax benefit | 25.9 |  |  | 23.0 |  |
| Other non-current liabilities | 0.5 |  |  | 2.4 |  |
| Other non-current liabilities | $ | 42.0 |  |  | $ | 40.9 |  |

[0001628280-22-001745:notes:85]
(1) We have defined benefit pension plans in Japan, Switzerland, and Thailand. As of January 1, 2022, the projected benefit obligations, net of plan assets, in Japan, Switzerland and Thailand were $2.9 million, $4.6 million and $3.4 million, respectively. As of July 3, 2021, the projected benefit obligations, net of plan assets, in Japan, Switzerland and Thailand were $2.9 million, $4.8 million and $3.1 million, respectively. We typically re-evaluate the assumptions related to the fair value of our defined benefit obligations annually and make any updates as necessary.


## us-gaap:LesseeFinanceLeasesTextBlock

[0001628280-22-001745:notes:86]
Note 7. Leases

[0001628280-22-001745:notes:87]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2033. These operating leases are mainly for administrative offices, research-and-development and manufacturing facilities, as well as sales offices in various countries around the world. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. Many leases include one or more options to renew. We do not assume renewals in our determination of the lease term unless the renewals are deemed to be reasonably certain at lease commencement.

[0001628280-22-001745:notes:88]
As of January 1, 2022, we sublease certain floors of our offices in the United Kingdom, the United States, Canada and Japan. These subleases will expire at various dates by fiscal year 2023. We anticipate receiving approximately $2.1 million in sublease income over the next two years.

[0001628280-22-001745:notes:89]
The components of lease costs, lease term and discount rate are as follows:

[0001628280-22-001745:notes:90]
|  | Three Months Ended |  | Six Months Ended |
|  | January 1, 2022 |  | December 26, 2020 |  | January 1, 2022 |  | December 26, 2020 |
| (in millions, except for weighted average data) |  |  |  |  |  |  |  |
| Finance lease cost | $ | — |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 0.3 |  |
| Operating lease cost | 3.3 |  |  | 3.6 |  |  | 6.7 |  |  | 7.2 |  |
| Variable lease cost | 0.4 |  |  | 0.6 |  |  | 0.8 |  |  | 1.0 |  |
| Short-term lease cost | 0.1 |  |  | 0.6 |  |  | 0.2 |  |  | 1.3 |  |
| Sublease income | (0.8) |  |  | (0.7) |  |  | (1.6) |  |  | (1.4) |  |
| Total lease cost | $ | 3.0 |  |  | $ | 4.2 |  |  | $ | 6.1 |  |  | $ | 8.4 |  |
|  |  |  |  |  | January 1, 2022 |  | December 26, 2020 |
| Weighted average remaining lease term (in years): |  |  |  |  |  |  |  |
| Operating leases |  |  |  |  | 7.3 |  | 8.0 |
| Finance leases |  |  |  |  | — |  | 0.5 |
| Weighted average discount rate (in percentages): |  |  |  |  |  |  |  |
| Operating leases |  |  |  |  | 3.2 | % |  | 3.5 | % |
| Finance leases |  |  |  |  | N/A |  | 4.4 | % |

[0001628280-22-001745:notes:91]
As of January 1, 2022, maturities of our operating lease liabilities, which do not include short-term leases and variable lease payments, were as follows (in millions):

[0001628280-22-001745:notes:92]
| Fiscal Years |  | Operating Leases (1) |  |  |  |  |
| Remainder of 2022 |  | $ | 7.1 |  |  |  |  |  |
| 2023 |  | 13.5 |  |  |  |  |  |
| 2024 |  | 12.9 |  |  |  |  |  |
| 2025 |  | 9.5 |  |  |  |  |  |
| 2026 |  | 7.9 |  |  |  |  |  |
| Thereafter |  | 25.3 |  |  |  |  |  |
| Total minimum lease payments |  | $ | 76.2 |  |  |  |  |  |
| Less: amount representing interest |  | (8.1) |  |  |  |  |  |
| Present value of total lease liabilities |  | $ | 68.1 |  |  |  |  |  |

[0001628280-22-001745:notes:93]
(1) Non-cancellable sublease proceeds for fiscal 2022 and 2023 of $1.3 million and $0.8 million, respectively, are not included in the table above.


## us-gaap:GoodwillDisclosureTextBlock

[0001628280-22-001745:notes:94]
[same as prior period, unchanged from 0001628280-21-021632:notes:86]

[0001628280-22-001745:notes:95]
[same as prior period, unchanged from 0001628280-21-021632:notes:87]

[0001628280-22-001745:notes:96]
The following table presents our goodwill balance by reportable segments as of January 1, 2022 and July 3, 2021 (in millions):

[0001628280-22-001745:notes:97]
|  | Optical Communications |  | Commercial Lasers |  | Total |
| Balance as of January 1, 2022 and July 3, 2021 | $ | 363.5 |  |  | $ | 5.4 |  |  | $ | 368.9 |  |

[0001628280-22-001745:notes:98]
[same as prior period, unchanged from 0001628280-21-021632:notes:90]

[0001628280-22-001745:notes:99]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. In the fourth quarter of fiscal 2021, we completed the annual impairment test of goodwill, which indicated there was no goodwill impairment. There were no indicators of goodwill impairment during the three and six months ended January 1, 2022.

[0001628280-22-001745:notes:100]
[same as prior period, unchanged from 0001628280-21-021632:notes:92]

[0001628280-22-001745:notes:101]
[same as prior period, unchanged from 0001628280-21-021632:notes:93]

[0001628280-22-001745:notes:102]
[same as prior period, unchanged from 0001628280-21-021632:notes:94]

[0001628280-22-001745:notes:103]
[same as prior period, unchanged from 0001628280-21-021632:notes:95]

[0001628280-22-001745:notes:104]
| January 1, 2022 | Gross Carrying Amounts |  | Accumulated Amortization |  | Net Carrying Amounts |  | Weighted average remaining amortization period (years) |
| Acquired developed technologies | $ | 390.3 |  |  | $ | (271.3) |  |  | $ | 119.0 |  |  | 2.7 |
| Customer relationships | 145.0 |  |  | (65.7) |  |  | 79.3 |  |  | 4.9 |
| Order backlog | 22.0 |  |  | (22.0) |  |  | — |  |  | — |
| Other intangibles | 2.7 |  |  | (2.7) |  |  | — |  |  | — |
| Total intangible assets | $ | 560.0 |  |  | $ | (361.7) |  |  | $ | 198.3 |  |  |  |

[0001628280-22-001745:notes:105]
[same as prior period, unchanged from 0001628280-21-021632:notes:97]

[0001628280-22-001745:notes:106]
[same as prior period, unchanged from 0001628280-21-021632:notes:98]

[0001628280-22-001745:notes:107]
|  | Three Months Ended |  | Six Months Ended |
|  | January 1, 2022 |  | December 26, 2020 |  | January 1, 2022 |  | December 26, 2020 |
| Cost of sales | $ | 15.9 |  |  | $ | 15.0 |  |  | $ | 31.7 |  |  | $ | 30.0 |  |
| Selling, general and administrative | 5.6 |  |  | 5.9 |  |  | 11.2 |  |  | 11.6 |  |
| Total amortization of intangibles | $ | 21.5 |  |  | $ | 20.9 |  |  | $ | 42.9 |  |  | $ | 41.6 |  |

[0001628280-22-001745:notes:108]
Based on the carrying amount of our acquired developed technologies and other intangibles as of January 1, 2022, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001628280-22-001745:notes:109]
| Fiscal Years |  |
| Remainder of 2022 | $ | 42.4 |  |
| 2023 | 61.9 |  |
| 2024 | 40.5 |  |
| 2025 | 27.7 |  |
| 2026 | 18.1 |  |
| Thereafter | 7.7 |  |
| Total future amortization | $ | 198.3 |  |


## us-gaap:DebtDisclosureTextBlock

[0001628280-22-001745:notes:110]
Note 9. Debt

[0001628280-22-001745:notes:111]
Convertible Notes

[0001628280-22-001745:notes:112]
2026 Notes

[0001628280-22-001745:notes:113]
In December 2019, we issued $1,050.0 million in aggregate principal amount of 0.50% Convertible Notes due in 2026 (“the 2026 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2026 Notes are governed by an indenture between the Company and U.S. Bank National Association (the “2026 Indenture”). We used approximately $196.0 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan credit facility, and a portion of the net proceeds of the offering to purchase approximately $200.0 million of our common stock concurrently with the pricing of the offering in privately negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-22-001745:notes:114]
The 2026 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on June 15, 2020. The 2026 Notes will mature on December 15, 2026, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-22-001745:notes:115]
The initial conversion rate is 10.0711 shares of common stock per $1,000 principal amount of the 2026 Notes (which is equivalent to an initial conversion price of approximately $99.29 per share). The conversion rate is subject to adjustment upon the occurrence of certain specified events, but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2026 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-22-001745:notes:116]
Prior to the close of business on the business day immediately preceding September 15, 2026, holders of the 2026 Notes may convert their 2026 Notes only under certain circumstances discussed in detail in our Annual Report on Form 10-K for the year ended July 3, 2021.

[0001628280-22-001745:notes:117]
2024 Notes

[0001628280-22-001745:notes:118]
In March 2017, we issued $450 million of 0.25% Convertible Notes due in 2024 (the “2024 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank National Association, as trustee (the “2024 Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-22-001745:notes:119]
The 2024 Notes bear interest at a rate of 0.25% per year. Interest on the 2024 Notes is payable semi-annually in arrears on March 15 and September 15 of each year, beginning on September 15, 2017. The 2024 Notes will mature on March 15, 2024, unless earlier repurchased by us or converted pursuant to their terms.

[0001628280-22-001745:notes:120]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share, a 132.5% premium to the fair market value at the date of issuance. Prior to the close of business on the business day immediately preceding December 15, 2023, each holder of the 2024 Notes may convert their 2024 Notes only under certain circumstances discussed in detail in our Annual Report on Form 10-K for the year ended July 3, 2021.

[0001628280-22-001745:notes:121]
During the six months ended January 1, 2022, we received conversion requests for less than $0.1 million principal amount of the 2024 Notes, which were settled in cash in the first half of fiscal 2022.

[0001628280-22-001745:notes:122]
2024 and 2026 Notes

[0001628280-22-001745:notes:123]
Our convertible notes consisted of the following components as of the periods presented (in millions):

[0001628280-22-001745:notes:124]
| Liability component: | January 1, 2022 |  | July 3, 2021 |
|  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2024 Notes |  | 2026 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 450.0 |  |  | $ | 1,050.0 |  |
| Unamortized debt discount and issuance costs | (49.0) |  |  | (239.7) |  |  | (59.3) |  |  | (260.2) |  |
| Net carrying amount of the liability component | $ | 401.0 |  |  | $ | 810.3 |  |  | $ | 390.7 |  |  | $ | 789.8 |  |

[0001628280-22-001745:notes:125]
(1) Since the closing price of our stock exceeded $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of the second quarter of fiscal 2022, the 2024 Notes have become convertible at the option of the holders. Therefore, the debt component of our 2024 Notes as of January 1, 2022 has been classified as current liabilities in our condensed consolidated balance sheet.

[0001628280-22-001745:notes:126]
(2) If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future quarter, our 2026 Notes would also become convertible at the option of the holders and the debt component would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-22-001745:notes:127]
The following table sets forth interest expense information related to the convertible notes for the periods presented (in millions):

[0001628280-22-001745:notes:128]
|  | Three Months Ended |  | Six Months Ended |
|  | January 1, 2022 |  | December 26, 2020 |  | January 1, 2022 |  | December 26, 2020 |
| Contractual interest expense | $ | 1.6 |  |  | $ | 1.6 |  |  | $ | 3.2 |  |  | $ | 3.2 |  |
| Amortization of the debt discount and debt issuance costs | 15.5 |  |  | 14.7 |  |  | 30.8 |  |  | 29.1 |  |
| Total interest expense | $ | 17.1 |  |  | $ | 16.3 |  |  | $ | 34.0 |  |  | $ | 32.3 |  |

[0001628280-22-001745:notes:129]
The future interest and principal payments related to our convertible notes are as follows as of January 1, 2022 (in millions):

[0001628280-22-001745:notes:130]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | Total |
| Remainder of 2022 | $ | 0.5 |  |  | $ | 2.7 |  |  | $ | 3.2 |  |
| 2023 | 1.1 |  |  | 5.3 |  |  | 6.4 |  |
| 2024 | 451.1 |  |  | 5.3 |  |  | 456.4 |  |
| 2025 | — |  |  | 5.3 |  |  | 5.3 |  |
| 2026 | — |  |  | 5.3 |  |  | 5.3 |  |
| Thereafter | — |  |  | 1,052.4 |  |  | 1,052.4 |  |
| Total convertible notes payments | $ | 452.7 |  |  | $ | 1,076.3 |  |  | $ | 1,529.0 |  |

[0001628280-22-001745:notes:131]
The principal balances of our Notes are reflected in the payment periods in the table above based on their respective contractual maturities.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-22-001745:notes:132]
[same as prior period, unchanged from 0001628280-21-021632:notes:124]

[0001628280-22-001745:notes:133]
[same as prior period, unchanged from 0001628280-21-021632:notes:125]

[0001628280-22-001745:notes:134]
[same as prior period, unchanged from 0001628280-21-021632:notes:126]

[0001628280-22-001745:notes:135]
|  | Foreign currency translation adjustments, net of tax (1) |  | Defined benefit obligations, net of tax (2) |  | Unrealized gain (loss) on available-for-sale securities, net of tax |  |  |  | Total |
| Beginning balance as of July 3, 2021 | $ | 9.7 |  |  | $ | (1.4) |  |  | $ | (0.1) |  |  |  |  | $ | 8.2 |  |
| Other comprehensive income | — |  |  | — |  |  | 0.3 |  |  |  |  | 0.3 |  |
| Ending balance as of October 2, 2021 | 9.7 |  |  | (1.4) |  |  | 0.2 |  |  |  |  | 8.5 |  |
| Other comprehensive loss | — |  |  | — |  |  | (2.3) |  |  |  |  | (2.3) |  |
| Ending balance as of January 1, 2022 | $ | 9.7 |  |  | $ | (1.4) |  |  | $ | (2.1) |  |  |  |  | $ | 6.2 |  |
|  | Foreign currency translation adjustments, net of tax (1) |  | Defined benefit obligations, net of tax (2) |  | Unrealized gain (loss) on available-for-sale securities, net of tax |  |  |  | Total |
| Beginning balance as of June 27, 2020 | $ | 9.7 |  |  | $ | (4.2) |  |  | $ | 2.4 |  |  |  |  | $ | 7.9 |  |
| Other comprehensive loss | — |  |  | — |  |  | (1.5) |  |  |  |  | (1.5) |  |
| Ending balance as of September 26, 2020 | 9.7 |  |  | (4.2) |  |  | 0.9 |  |  |  |  | 6.4 |  |
| Other comprehensive loss | — |  |  | — |  |  | (0.4) |  |  |  |  | (0.4) |  |
| Ending balance as of December 26, 2020 | $ | 9.7 |  |  | $ | (4.2) |  |  | $ | 0.5 |  |  |  |  | $ | 6.0 |  |

[0001628280-22-001745:notes:136]
(1) In fiscal 2019, we established the functional currency for our worldwide operations as the U.S. dollar. Translation adjustments reported prior to December 10, 2018 remain as a component of accumulated other comprehensive income in our condensed consolidated balance sheets, until all or a part of the investment in the subsidiaries is sold or liquidated.

[0001628280-22-001745:notes:137]
(2) We re-evaluate the assumptions related to the fair value of our defined benefit obligations annually and make any updates as necessary.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-22-001745:notes:138]
[same as prior period, unchanged from 0001628280-21-021632:notes:130]

[0001628280-22-001745:notes:139]
[same as prior period, unchanged from 0001628280-21-021632:notes:131]

[0001628280-22-001745:notes:140]
[same as prior period, unchanged from 0001628280-21-021632:notes:132]

[0001628280-22-001745:notes:141]
|  | Three Months Ended |  | Six Months Ended |
|  | January 1, 2022 |  | December 26, 2020 |  | January 1, 2022 |  | December 26, 2020 |
| Balance as of beginning of period | $ | 0.8 |  |  | $ | 4.4 |  |  | $ | 5.7 |  |  | $ | 5.2 |  |
| Charges (reversals), net | 0.1 |  |  | 0.2 |  |  | (1.0) |  |  | 0.2 |  |
| Payments | (0.6) |  |  | — |  |  | (4.4) |  |  | (0.8) |  |
| Balance as of end of period | $ | 0.3 |  |  | $ | 4.6 |  |  | $ | 0.3 |  |  | $ | 4.6 |  |

[0001628280-22-001745:notes:142]
During the six months ended January 1, 2022, we recorded a net reversal to our restructuring and related charges of $1.0 million in our condensed consolidated statements of operations which was primarily attributable to lower than anticipated employee severance charges due to retaining and re-assigning certain employees.

[0001628280-22-001745:notes:143]
During the three and six months ended December 26, 2020, we recorded restructuring and related charges of $0.2 million and $0.2 million, respectively, in our condensed consolidated statements of operations.

[0001628280-22-001745:notes:144]
[same as prior period, unchanged from 0001628280-21-021632:notes:136]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-22-001745:notes:145]
[same as prior period, unchanged from 0001628280-21-021632:notes:137]

[0001628280-22-001745:notes:146]
[same as prior period, unchanged from 0001628280-21-021632:notes:138]

[0001628280-22-001745:notes:147]
We recorded a tax provision of $12.4 million and $30.5 million for the three and six months ended January 1, 2022, respectively. Our tax provision for the three months ended January 1, 2022 includes a discrete tax benefit of $2.2 million, primarily related to currency re-measurement of certain tax related accounts and excess tax benefit related to stock-based compensation that vested during the quarter. Our estimated effective tax rate for fiscal 2022 differs from the 21% U.S. statutory rate primarily due to the income tax benefit from the earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate and U.S. federal R&D tax credits, partially offset by the income tax expense from the tax effect of Global Intangible Low-Taxed Income (“GILTI”), net of benefit for foreign tax credits, subpart F inclusion and non-deductible stock-based compensation.

[0001628280-22-001745:notes:148]
As of January 1, 2022, we had $27.2 million of unrecognized tax benefits, which, if recognized, would affect the effective tax rate. We are subject to examination of income tax returns by various domestic and foreign tax authorities. The timing of resolution and closure of tax audits is highly unpredictable. Although it is possible that certain ongoing tax audits may be concluded within the next 12 months, we cannot reasonably estimate the impact to tax expense and net income from tax exams that could be resolved or closed within the next 12 months. Subject to audit timing and uncertainty, we expect the amount of unrecognized tax benefit that would become recognized due to expiration of the statute of limitations and affect the effective tax rate to decrease by $3.6 million over the next 12 months.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-22-001745:notes:149]
[same as prior period, unchanged from 0001628280-21-021632:notes:141]

[0001628280-22-001745:notes:150]
[same as prior period, unchanged from 0001628280-21-021632:notes:142]

[0001628280-22-001745:notes:151]
[same as prior period, unchanged from 0001628280-21-021632:notes:143]

[0001628280-22-001745:notes:152]
On November 19, 2021, our stockholders approved amendments to the Amended and Restated 2015 Equity Incentive Plan (the “2015 Plan”) to (i) increase the number of shares reserved for issuance under the 2015 Plan by an additional 3.0 million shares and (ii) make certain other changes to reflect changes in the law and/or good corporate governance practices.

[0001628280-22-001745:notes:153]
As of January 1, 2022, we had 2.5 million shares subject to restricted stock units and performance stock units issued and outstanding under the 2015 Plan. Restricted stock units and performance stock units are performance-based, time-based or a combination of both. The fair value of these grants is based on the closing market price of our common stock on the date of award.

[0001628280-22-001745:notes:154]
As of January 1, 2022, 4.1 million shares of common stock under the 2015 Plan were available for grant.

[0001628280-22-001745:notes:155]
[same as prior period, unchanged from 0001628280-21-021632:notes:146]

[0001628280-22-001745:notes:156]
[same as prior period, unchanged from 0001628280-21-021632:notes:147]

[0001628280-22-001745:notes:157]
During the six months ended January 1, 2022, our board of directors approved grants of 1.1 million shares which primarily vest over three years.

[0001628280-22-001745:notes:158]
[same as prior period, unchanged from 0001628280-21-021632:notes:149]

[0001628280-22-001745:notes:159]
[same as prior period, unchanged from 0001628280-21-021632:notes:150]

[0001628280-22-001745:notes:160]
During the six months ended January 1, 2022, our board of directors approved a grant of 0.2 million PSUs with an aggregate grant date fair value of $16.7 million to certain executive officers and senior management. These PSUs will vest subject to the achievement of 3-year revenue targets and certain non-financial performance measurement, as well as service conditions.

[0001628280-22-001745:notes:161]
[same as prior period, unchanged from 0001628280-21-021632:notes:152]

[0001628280-22-001745:notes:162]
Our 2015 Employee Stock Purchase Plan (the “2015 Purchase Plan”) provides eligible employees with the opportunity to acquire an ownership interest in the Company through periodic payroll deductions and provides a 15% purchase price discount as well as a 6-month look-back period. The 2015 Purchase Plan is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986, as amended. The 2015 Purchase Plan will terminate upon the date on which all shares available for issuance have been sold. Of the 3.0 million shares authorized under the 2015 Purchase Plan, 1.5 million shares remained available for issuance as of January 1, 2022.

[0001628280-22-001745:notes:163]
[same as prior period, unchanged from 0001628280-21-021632:notes:154]

[0001628280-22-001745:notes:164]
[same as prior period, unchanged from 0001628280-21-021632:notes:155]

[0001628280-22-001745:notes:165]
|  | Three Months Ended |  | Six Months Ended |
|  | January 1, 2022 |  | December 26, 2020 |  | January 1, 2022 |  | December 26, 2020 |
| Cost of sales | $ | 5.2 |  |  | $ | 4.8 |  |  | $ | 9.8 |  |  | $ | 8.5 |  |
| Research and development | 5.4 |  |  | 5.1 |  |  | 10.4 |  |  | 9.5 |  |
| Selling, general and administrative | 16.7 |  |  | 14.2 |  |  | 31.9 |  |  | 25.6 |  |
| Total stock-based compensation | $ | 27.3 |  |  | $ | 24.1 |  |  | $ | 52.1 |  |  | $ | 43.6 |  |

[0001628280-22-001745:notes:166]
Included in stock-based compensation for the three and six months ended January 1, 2022, is $4.6 million and $9.3 million, respectively, of stock-based compensation costs related to PSUs. Included in stock-based compensation for the three and six months ended December 26, 2020, is $4.1 million and $7.2 million, respectively, of stock-based compensation costs related to PSUs. The amount of stock-based compensation expense recognized in any one period related to PSUs can vary based on the achievement or anticipated achievement of the performance conditions. If the performance conditions are not met or not expected to be met, no compensation cost would be recognized on the underlying PSUs, and any previously recognized compensation expense related to those PSUs would be reversed.

[0001628280-22-001745:notes:167]
[same as prior period, unchanged from 0001628280-21-021632:notes:158]

[0001628280-22-001745:notes:168]
|  | Three Months Ended |  | Six Months Ended |
|  | January 1, 2022 |  | December 26, 2020 |  | January 1, 2022 |  | December 26, 2020 |
| Income tax benefit associated with stock-based compensation | $ | 4.2 |  |  | $ | 3.6 |  |  | $ | 8.2 |  |  | $ | 8.8 |  |

[0001628280-22-001745:notes:169]
Approximately $5.3 million and $4.6 million of stock-based compensation was capitalized to inventory as of January 1, 2022 and July 3, 2021, respectively.

[0001628280-22-001745:notes:170]
[same as prior period, unchanged from 0001628280-21-021632:notes:161]

[0001628280-22-001745:notes:171]
The following table summarizes our award activity for the six months ended January 1, 2022 (in millions, except per share amounts):

[0001628280-22-001745:notes:172]
|  |  |  | Restricted Stock Units |  | Performance Stock Units |
|  |  |  |  |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance as of July 3, 2021 |  |  |  |  | 1.8 |  |  | $ | 76.02 |  |  | 0.3 |  |  | $ | 75.68 |  |
| Granted |  |  |  |  | 1.1 |  |  | 87.17 |  |  | 0.2 |  |  | 85.70 |  |
| Vested |  |  |  |  | (0.7) |  |  | 74.63 |  |  | (0.1) |  |  | 76.89 |  |
| Canceled |  |  |  |  | (0.1) |  |  | 75.74 |  |  | — |  |  | 58.62 |  |
| Balance as of January 1, 2022 |  |  |  |  | 2.1 |  |  | $ | 82.47 |  |  | 0.4 |  |  | $ | 80.76 |  |

[0001628280-22-001745:notes:173]
As of January 1, 2022, $151.4 million of stock-based compensation cost related to RSU awards granted to our employees remains to be amortized. That cost is expected to be recognized over an estimated amortization period of 2.1 years.

[0001628280-22-001745:notes:174]
[same as prior period, unchanged from 0001628280-21-021632:notes:165]

[0001628280-22-001745:notes:175]
|  | Awards Available for Grant |
| Balance as of July 3, 2021 | 2.3 |  |
| Authorized | 3.0 |  |
| Granted | (1.3) |  |
| Canceled | 0.1 |  |
| Balance as of January 1, 2022 | 4.1 |  |

[0001628280-22-001745:notes:176]
[same as prior period, unchanged from 0001628280-21-021632:notes:167]

[0001628280-22-001745:notes:177]
The 2015 Purchase Plan expense for the three and six months ended January 1, 2022 was $0.9 million and $2.1 million, respectively. The 2015 Purchase Plan expense for the three and six months ended December 26, 2020 was $1.2 million and $2.3 million, respectively. The expense related to the 2015 Purchase Plan is recorded on a straight-line basis over the relevant subscription period. During the six months ended January 1, 2022, there were 0.1 million shares issued to employees through the 2015 Purchase Plan. During the six months ended December 26, 2020, there were 0.1 million shares issued to employees through the 2015 Purchase Plan.

[0001628280-22-001745:notes:178]
[same as prior period, unchanged from 0001628280-21-021632:notes:169]

[0001628280-22-001745:notes:179]
On May 7, 2021, our board of directors approved the 2021 share buyback program, which authorizes us to use up to $700.0 million to purchase our own shares of common stock. The buyback program is authorized for 2 years, but may be suspended or terminated by the board of directors at any time. During the six months ended January 1, 2022, we repurchased 1.4 million shares of our common stock at an average price of $84.31 per share for an aggregate purchase price of $121.6 million.

[0001628280-22-001745:notes:180]
Since the share buyback program was approved by the board of directors, we have repurchased 4.5 million shares in aggregate at an average price of $79.89 per share for a total payment of $362.6 million. All repurchased shares were retired immediately. The price, timing, amount, and method of such repurchases will be determined based on the valuation of market conditions and other factors, at prices determined to be attractive and in the best interests of both Lumentum and our stockholders. We recorded the $362.6 million aggregate purchase price as a reduction of retained earnings within our condensed consolidated balance sheet.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001628280-22-001745:notes:181]
Note 14. Commitments and Contingencies

[0001628280-22-001745:notes:182]
Purchase Obligations

[0001628280-22-001745:notes:183]
Purchase obligations of $314.5 million as of January 1, 2022, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements.

[0001628280-22-001745:notes:184]
Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001628280-22-001745:notes:185]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with such vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

[0001628280-22-001745:notes:186]
Product Warranties

[0001628280-22-001745:notes:187]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, product components or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001628280-22-001745:notes:188]
The following table presents the changes in our warranty reserve for the periods presented (in millions):

[0001628280-22-001745:notes:189]
|  | Three Months Ended |  | Six Months Ended |
|  | January 1, 2022 |  | December 26, 2020 |  | January 1, 2022 |  | December 26, 2020 |
| Balance as of beginning of period | $ | 5.1 |  |  | $ | 7.6 |  |  | $ | 5.0 |  |  | $ | 5.0 |  |
| Provision for warranty | 3.8 |  |  | 0.2 |  |  | 5.5 |  |  | 4.1 |  |
| Utilization of reserve | (0.3) |  |  | (2.1) |  |  | (1.9) |  |  | (3.4) |  |
| Balance as of end of period | $ | 8.6 |  |  | $ | 5.7 |  |  | $ | 8.6 |  |  | $ | 5.7 |  |

[0001628280-22-001745:notes:190]
Environmental Liabilities

[0001628280-22-001745:notes:191]
Our research and development (“R&D”), manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental, product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001628280-22-001745:notes:192]
Legal Proceedings

[0001628280-22-001745:notes:193]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss.

[0001628280-22-001745:notes:194]
Oclaro Merger Litigation

[0001628280-22-001745:notes:195]
In connection with our acquisition of Oclaro, seven lawsuits were filed by purported stockholders of Oclaro challenging the proposed merger (the “Merger”). Two of the seven suits were putative class actions filed against Oclaro, its directors, Lumentum, Prota Merger Sub, Inc. and Prota Merger, LLC: Nicholas Neinast v. Oclaro, Inc., et al., No. 3:18-cv-03112-VC, in the United States District Court for the Northern District of California (filed May 24, 2018) (the “Neinast Lawsuit”); and Adam Franchi v. Oclaro, Inc., et al., No. 1:18-cv-00817-GMS, in the United States District Court for the District of Delaware (filed June 9, 2018) (the “Franchi Lawsuit”). Both the Neinstat Lawsuit and the Franchi Lawsuit were voluntarily dismissed with prejudice.

[0001628280-22-001745:notes:196]
The other five suits, styled as Gerald F. Wordehoff v. Oclaro, Inc., et al., No. 5:18-cv-03148-NC (the “Wordehoff Lawsuit”), Walter Ryan v. Oclaro, Inc., et al., No. 3:18-cv-03174-VC (the “Ryan Lawsuit”), Jayme Walker v. Oclaro, Inc., et al., No. 5:18-cv-03203-EJD (the “Walker Lawsuit”), Kevin Garcia v. Oclaro, Inc., et al., No. 5:18-cv-03262-VKD (the “Garcia Lawsuit”), and SaiSravan B. Karri v. Oclaro, Inc., et al., No. 3:18-cv-03435-JD (the “Karri Lawsuit” and, together with the other six lawsuits, the “Lawsuits”), were filed in the United States District Court for the Northern District of California on May 25, 2018, May 29, 2018, May 30, 2018, May 31, 2018, and June 9, 2018, respectively. These five Lawsuits named Oclaro and its directors as defendants only and did not name Lumentum. The Wordehoff, Ryan, Walker, and Garcia Lawsuits have been voluntarily dismissed, and the Wordehoff, Ryan, and Walker dismissals were with prejudice. The Karri Lawsuit has not yet been dismissed. The Ryan Lawsuit was, and the Karri Lawsuit is, a putative class action.

[0001628280-22-001745:notes:197]
The Lawsuits generally alleged, among other things, that Oclaro and its directors violated Section 14(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), and Rule 14a-9 promulgated thereunder by disseminating an incomplete and misleading Form S-4, including proxy statement/prospectus. The Lawsuits further alleged that Oclaro’s directors violated Section 20(a) of the Exchange Act by failing to exercise proper control over the person(s) who violated Section 14(a) of the Exchange Act.

[0001628280-22-001745:notes:198]
The remaining Lawsuit (the Karri Lawsuit) currently purports to seek, among other things, damages to be awarded to the plaintiff and any class, if a class is certified, and litigation costs, including attorneys’ fees.  A lead plaintiff and counsel has been selected, and an amended complaint was filed on April 15, 2019, which also named Lumentum as a defendant. A motion to dismiss the amended complaint was granted in part and denied in part by the court on October 8, 2020. On December 1, 2020, defendants answered the amended complaint. On December 23, 2020, defendants filed a motion for leave to file a motion for reconsideration of the Court’s October 8th order on the motion to dismiss, which was denied on January 29, 2021. On June 22, 2021, the Court granted the parties’ stipulation to dismiss Lumentum as a defendant from the action.  On September 17, 2021, lead plaintiff filed a second amended complaint (“SAC”).  Defendants moved to stay discovery in light of the SAC, and on January 11, 2022 the Court struck the SAC as untimely, terminated defendants’ motions to dismiss as moot, and lifted the stay.  The Karri Lawsuit remains pending with the parties currently in discovery. Defendants intend to defend the Karri Lawsuit vigorously.

[0001628280-22-001745:notes:199]
NeoPhotonics Merger Litigation

[0001628280-22-001745:notes:200]
In connection with our planned acquisition of NeoPhotonics Corporation (“NeoPhotonics”) announced in November 2021, ten lawsuits (the “NeoPhotonics Lawsuits”) were filed by purported stockholders of NeoPhotonics challenging the proposed merger (the “NeoPhotonics Merger”).  Four of the NeoPhotonics Lawsuits, styled as Elaine Wang v. NeoPhotonics Corporation, et al., No. 1:21-cv-10338, Heather Smith v. NeoPhotonics Corporation, et al., No. 1:21-cv-10698, Matthew Hopkins v. NeoPhotonics Corporation, et al., No. 1:21-cv-10725, and John Ryan v. NeoPhotonics Corporation, et al., No. 1:22-cv-00046, were filed in the United States District Court for the Southern District of New York on December 3, 2021, December 14, 2021, December 15, 2021, and January 4, 2022, respectively.  Three of the NeoPhotonics Lawsuits, styled as Mengsheng Ku v. NeoPhotonics Corporation, et al., No. 5:21-cv-09479, Stephen Bushansky v. NeoPhotonics Corporation, et al., No. 5:21-cv-09825, and James Parshall v. NeoPhotonics Corporation, et al., No. 5:22-cv-00055, were filed in the United States District Court for the Northern District of New York on December 8, 2021, December 20, 2021, and January 5, 2022, respectively. One NeoPhotonics Lawsuit, styled as James Hendrickson v. NeoPhotonics Corporation, et al., No. 1:21-cv-06919, was filed in the United States District Court for the Eastern District of New York on December 15, 2021. One NeoPhotonics Lawsuit, styled as Alex Ciccotelli v. NeoPhotonics Corporation, et al., No. 2:21-cv-05611, was filed in the United States District Court for the Eastern District of Pennsylvania on December 23, 2021. One NeoPhotonics Lawsuit, styled as Christopher Taylor v. NeoPhotonics Corporation, et al., No. 1:22-cv-00002, was filed in the United States District Court for the District of Delaware on January 3, 2022.

[0001628280-22-001745:notes:201]
These ten NeoPhotonics Lawsuits name NeoPhotonics and its directors as defendants and do not name Lumentum.

[0001628280-22-001745:notes:202]
The NeoPhotonics Lawsuits generally allege, among other things, that NeoPhotonics and its directors violated Section 14(a) of the Exchange Act, Rule 14a-9 promulgated thereunder, and 17 C.F.R. § 244.100 by disseminating an incomplete and misleading Preliminary Proxy Statement on Schedule 14A, filed with the SEC on December 1, 2021 regarding the NeoPhotonics Merger. The NeoPhotonics Lawsuits further allege that NeoPhotonics’ directors violated Section 20(a) of the Exchange Act by failing to exercise proper control over the person(s) who violated Section 14(a) of the Exchange Act.  The complaints seek injunctive relief, rescission or rescissory damages, dissemination of a proxy statement that discloses certain information requested by the plaintiffs, and an award of plaintiffs’ costs, including attorneys’ fees and expenses.

[0001628280-22-001745:notes:203]
Indemnifications

[0001628280-22-001745:notes:204]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future, and we may record charges in the future as a result of these indemnification obligations. As of January 1, 2022, we did not have any material indemnification claims that were probable or reasonably possible.

[0001628280-22-001745:notes:205]
Audit Proceedings

[0001628280-22-001745:notes:206]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-22-001745:notes:207]
[same as prior period, unchanged from 0001628280-21-021632:notes:194]

[0001628280-22-001745:notes:208]
[same as prior period, unchanged from 0001628280-21-021632:notes:195]

[0001628280-22-001745:notes:209]
[same as prior period, unchanged from 0001628280-21-021632:notes:196]

[0001628280-22-001745:notes:210]
[same as prior period, unchanged from 0001628280-21-021632:notes:197]

[0001628280-22-001745:notes:211]
[same as prior period, unchanged from 0001628280-21-021632:notes:198]

[0001628280-22-001745:notes:212]
[same as prior period, unchanged from 0001628280-21-021632:notes:199]

[0001628280-22-001745:notes:213]
[same as prior period, unchanged from 0001628280-21-021632:notes:200]

[0001628280-22-001745:notes:214]
[same as prior period, unchanged from 0001628280-21-021632:notes:201]

[0001628280-22-001745:notes:215]
[same as prior period, unchanged from 0001628280-21-021632:notes:202]

[0001628280-22-001745:notes:216]
[same as prior period, unchanged from 0001628280-21-021632:notes:203]

[0001628280-22-001745:notes:217]
[same as prior period, unchanged from 0001628280-21-021632:notes:204]

[0001628280-22-001745:notes:218]
[same as prior period, unchanged from 0001628280-21-021632:notes:205]

[0001628280-22-001745:notes:219]
|  | Three Months Ended |  | Six Months Ended |
|  | January 1, 2022 |  | December 26, 2020 |  | January 1, 2022 |  | December 26, 2020 |
| Net revenue: |  |  |  |  |  |  |  |
| OpComms | $ | 397.4 |  |  | $ | 449.1 |  |  | $ | 803.4 |  |  | $ | 877.6 |  |
| Lasers | 49.3 |  |  | 29.7 |  |  | 91.7 |  |  | 53.6 |  |
| Net revenue | $ | 446.7 |  |  | $ | 478.8 |  |  | $ | 895.1 |  |  | $ | 931.2 |  |
| Gross profit: |  |  |  |  |  |  |  |
| OpComms | $ | 201.8 |  |  | $ | 241.8 |  |  | $ | 427.7 |  |  | $ | 466.6 |  |
| Lasers | 26.2 |  |  | 14.1 |  |  | 47.0 |  |  | 24.5 |  |
| Total segment gross profit | 228.0 |  |  | 255.9 |  |  | 474.7 |  |  | 491.1 |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Stock-based compensation | (5.2) |  |  | (4.8) |  |  | (9.8) |  |  | (8.5) |  |
| Amortization of acquired intangibles | (15.9) |  |  | (15.0) |  |  | (31.7) |  |  | (30.0) |  |
| Inventory and fixed asset write down due toproduct line exits | (0.1) |  |  | (0.1) |  |  | (0.1) |  |  | (0.4) |  |
| Other (charges) gains (1) | 0.7 |  |  | (6.4) |  |  | 6.6 |  |  | (16.9) |  |
| Gross profit | $ | 207.5 |  |  | $ | 229.6 |  |  | $ | 439.7 |  |  | $ | 435.3 |  |

[0001628280-22-001745:notes:220]
(1)   Other (charges) gains of unallocated corporate items for the six months ended January 1, 2022 primarily relate to $5.9 million gain during the three months ended October 2, 2021 as a result of selling equipment that was no longer needed after we transferred certain product lines to new production facilities in fiscal 2021.

[0001628280-22-001745:notes:221]
Other (charges) gains of unallocated corporate items for the three and six months ended December 26, 2020 relate to costs of transferring product lines to new production facilities of $0.4 million and $2.5 million, respectively. We also incurred excess and obsolete inventory charges driven by U.S. trade restrictions and the related decline in demand from Huawei of $0.8 million and $6.7 million during the three and six months ended December 26, 2020, respectively. In addition, during the three months ended December 26, 2020, we incurred $4.6 million impairment charges associated with excess capacity related to our Fiber laser business.

[0001628280-22-001745:notes:222]
[same as prior period, unchanged from 0001628280-21-021632:notes:208]

[0001628280-22-001745:notes:223]
|  | Three Months Ended |  | Six Months Ended |
|  | January 1, 2022 |  | December 26, 2020 |  | January 1, 2022 |  | December 26, 2020 |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 51.0 |  |  | 11.4 | % |  | $ | 39.7 |  |  | 8.3 | % |  | $ | 79.1 |  |  | 8.8 | % |  | $ | 60.0 |  |  | 6.4 | % |
| Mexico | 38.3 |  |  | 8.6 |  |  | 51.3 |  |  | 10.7 |  |  | 71.3 |  |  | 8.0 |  |  | 91.1 |  |  | 9.8 |  |
| Other Americas | 2.7 |  |  | 0.6 |  |  | 4.0 |  |  | 0.8 |  |  | 4.7 |  |  | 0.5 |  |  | 6.8 |  |  | 0.8 |  |
| Total Americas | $ | 92.0 |  |  | 20.6 | % |  | $ | 95.0 |  |  | 19.8 | % |  | $ | 155.1 |  |  | 17.3 | % |  | $ | 157.9 |  |  | 17.0 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 115.0 |  |  | 25.8 | % |  | $ | 148.0 |  |  | 30.9 | % |  | $ | 257.3 |  |  | 28.8 | % |  | $ | 292.4 |  |  | 31.4 | % |
| Philippines | 8.9 |  |  | 2.0 |  |  | 40.6 |  |  | 8.5 |  |  | 18.0 |  |  | 2.0 |  |  | 103.4 |  |  | 11.1 |  |
| South Korea | 77.9 |  |  | 17.4 |  |  | 66.0 |  |  | 13.8 |  |  | 183.0 |  |  | 20.4 |  |  | 122.0 |  |  | 13.1 |  |
| Japan | 46.7 |  |  | 10.5 |  |  | 25.9 |  |  | 5.4 |  |  | 92.8 |  |  | 10.4 |  |  | 48.4 |  |  | 5.2 |  |
| Other Asia-Pacific | 77.0 |  |  | 17.2 |  |  | 68.1 |  |  | 14.2 |  |  | 133.9 |  |  | 15.0 |  |  | 137.2 |  |  | 14.7 |  |
| Total Asia-Pacific | $ | 325.5 |  |  | 72.9 | % |  | $ | 348.6 |  |  | 72.8 | % |  | $ | 685.0 |  |  | 76.5 | % |  | $ | 703.4 |  |  | 75.5 | % |
| EMEA | $ | 29.2 |  |  | 6.5 | % |  | $ | 35.2 |  |  | 7.4 | % |  | $ | 55.0 |  |  | 6.1 | % |  | $ | 69.9 |  |  | 7.5 | % |
| Total net revenue | $ | 446.7 |  |  |  |  | $ | 478.8 |  |  |  |  | $ | 895.1 |  |  |  |  | $ | 931.2 |  |  |  |

[0001628280-22-001745:notes:224]
During the three and six months ended January 1, 2022 compared to the three and six months ended December 26, 2020, net revenue from South Korea and Japan increased and net revenue from Philippines decreased due to changes in our customers’ chosen module integrator for specific new products.

[0001628280-22-001745:notes:225]
During the three and six months ended January 1, 2022, our net revenue from a single customer, who represented 10% or greater of total net revenue was concentrated with two customers, who collectively accounted for 41% and 46% of our total net revenue, respectively. During the three and six months ended December 26, 2020, our net revenue from a single customer, which represented 10% or greater of total net revenue was concentrated with two customers, who collectively accounted for 45% of our total net revenue for each period, respectively.

[0001628280-22-001745:notes:226]
Our accounts receivable was concentrated with one customer as of January 1, 2022, who represented 11% of gross accounts receivable, compared with two customers as of July 3, 2021, who represented 17% and 14% of gross accounts receivable, respectively.

[0001628280-22-001745:notes:227]
[same as prior period, unchanged from 0001628280-21-021632:notes:213]

[0001628280-22-001745:notes:228]
|  | January 1, 2022 |  | July 3, 2021 |
| Property, plant and equipment, net |  |  |  |
| United States | $ | 110.0 |  |  | $ | 116.7 |  |
| Thailand | 104.1 |  |  | 103.9 |  |
| China | 36.8 |  |  | 41.3 |  |
| Japan | 38.1 |  |  | 36.4 |  |
| Other countries | 70.6 |  |  | 62.8 |  |
| Total property, plant and equipment, net | $ | 359.6 |  |  | $ | 361.1 |  |

[0001628280-22-001745:notes:229]
We purchase a substantial portion of our inventory from contract manufacturers and vendors located primarily in Taiwan, Thailand and Malaysia. During the three and six months ended January 1, 2022, our net inventory purchases from a single contract manufacturer, which represented 10% or greater of total net purchases, were concentrated with two contract manufacturers, who collectively accounted for 58% and 61% of total net inventory purchases, respectively. During the three and six months ended December 26, 2020, our net inventory purchases from a single contract manufacturer, which represented 10% or greater of total net purchases, were concentrated with two contract manufacturers, who collectively accounted for 67% and 65% of total net inventory purchases, respectively.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-22-001745:notes:230]
[same as prior period, unchanged from 0001628280-21-021632:notes:216]

[0001628280-22-001745:notes:231]
[same as prior period, unchanged from 0001628280-21-021632:notes:217]

[0001628280-22-001745:notes:232]
[same as prior period, unchanged from 0001628280-21-021632:notes:218]

[0001628280-22-001745:notes:233]
[same as prior period, unchanged from 0001628280-21-021632:notes:219]

[0001628280-22-001745:notes:234]
|  | Three Months Ended |  | Six Months Ended |
|  | January 1, 2022 |  | December 26, 2020 |  | January 1, 2022 |  | December 26, 2020 |
| OpComms: |  |  |  |  |  |  |  |  |  |  |  |
| Telecom and Datacom | $ | 267.1 |  | 59.8 | % |  | $ | 286.2 |  | 59.8 | % |  | $ | 483.1 |  | 54.0 | % |  | $ | 547.5 |  | 58.8 | % |
| Industrial and Consumer | 130.3 |  | 29.2 |  |  | 162.9 |  | 34.0 |  |  | 320.3 |  | 35.8 |  |  | 330.1 |  | 35.4 |  |
| Total OpComms | $ | 397.4 |  | 89.0 | % |  | $ | 449.1 |  | 93.8 | % |  | $ | 803.4 |  | 89.8 | % |  | $ | 877.6 |  | 94.2 | % |
| Lasers | 49.3 |  | 11.0 | % |  | 29.7 |  | 6.2 | % |  | 91.7 |  | 10.2 |  |  | 53.6 |  | 5.8 |  |
| Net Revenue | $ | 446.7 |  |  |  | $ | 478.8 |  |  |  | $ | 895.1 |  |  |  | $ | 931.2 |  |  |

[0001628280-22-001745:notes:235]
[same as prior period, unchanged from 0001628280-21-021632:notes:221]

[0001628280-22-001745:notes:236]
The following table reflects the changes in contract balances as of January 1, 2022 (in millions, except percentages):

[0001628280-22-001745:notes:237]
| Contract balances |  | Balance sheet location |  | January 1, 2022 |  | July 3, 2021 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 239.2 |  |  | $ | 212.8 |  |  | $ | 26.4 |  |  | 12.4 | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | — |  |  | $ | 0.6 |  |  | $ | (0.6) |  |  | (100.0) | % |
