# LITE 8-K — 0001628280-22-001736 filed 2022-02-03

## item codes, every 8-K on or before 2022-02-03

- 2022-02-03 0001628280-22-001736 — 2.02, 9.01
- 2022-01-21 0001193125-22-014413 — 8.01, 9.01
- 2021-11-23 0001628280-21-024070 — 5.02, 5.07
- 2021-11-05 0001193125-21-321796 — 1.01, 9.01
- 2021-11-04 0001628280-21-021618 — 2.02, 9.01
- 2021-11-04 0001193125-21-319601 — 8.01, 9.01
- 2021-08-18 0001628280-21-017219 — 2.02, 9.01
- 2021-06-08 0001633978-21-000030 — 5.02, 9.01
- 2021-05-12 0001633978-21-000008 — 2.02, 9.01
- 2021-03-10 0001193125-21-075438 — 1.01, 8.01, 9.01
- 2021-02-02 0001633978-21-000002 — 2.02, 9.01
- 2021-01-19 0001104659-21-005024 — 1.01, 2.02, 8.01, 9.01
- 2020-11-24 0001193125-20-302557 — 5.02, 5.07
- 2020-11-02 0001633978-20-000017 — 2.02, 9.01
- 2020-09-18 0001633978-20-000012 — 5.02, 9.01
- 2020-08-11 0001633978-20-000010 — 2.02, 9.01
- 2020-05-05 0001628280-20-006358 — 2.02, 9.01
- 2020-02-04 0001633978-20-000002 — 2.02, 9.01
- 2019-12-12 0001193125-19-312875 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2019-12-04 0001633978-19-000075 — 8.01
- 2019-11-20 0001633978-19-000074 — 5.07
- 2019-10-31 0001633978-19-000070 — 2.02, 9.01
- 2019-08-08 0001633978-19-000068 — 2.02, 9.01
- 2019-05-08 0001633978-19-000031 — 1.01
- 2019-05-07 0001633978-19-000029 — 2.02, 9.01
- 2019-02-15 0001633978-19-000005 — 9.01 — amendment of 0001193125-18-346211
- 2019-02-08 0001193125-19-031591 — 5.02, 9.01
- 2019-02-05 0001633978-19-000001 — 2.02, 9.01
- 2018-12-10 0001193125-18-346211 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-12-06 0001633978-18-000150 — 8.01
- 2018-11-14 0001633978-18-000139 — 5.07
- 2018-11-13 0001633978-18-000136 — 3.02
- 2018-11-13 0001633978-18-000132 — 7.01, 9.01
- 2018-11-01 0001628280-18-013238 — 2.02, 9.01
- 2018-08-08 0001633978-18-000056 — 2.02, 9.01
- 2018-06-08 0001193125-18-188241 — 5.02, 9.01
- 2018-05-02 0001633978-18-000029 — 2.02, 9.01
- 2018-03-12 0001193125-18-078154 — 1.01, 2.01, 8.01, 9.01
- 2018-02-06 0001628280-18-001082 — 2.02, 9.01
- 2017-11-08 0001633978-17-000133 — 5.02, 9.01
- 2017-11-07 0001633978-17-000131 — 5.07
- 2017-11-01 0001633978-17-000117 — 2.02, 9.01
- 2017-08-09 0001633978-17-000058 — 2.02, 9.01
- 2017-05-04 0001633978-17-000035 — 2.02, 9.01
- 2017-03-08 0001193125-17-074740 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2017-03-02 0001193125-17-066769 — 8.01, 9.01
- 2017-02-07 0001633978-17-000005 — 2.02, 9.01
- 2017-01-03 0001628280-17-000018 — 4.01, 9.01
- 2016-11-09 0001628280-16-021143 — 5.02, 5.07, 9.01
- 2016-10-27 0001628280-16-020382 — 2.02, 9.01
- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2022-02-03

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001628280-22-001736:8k_2_02:1]
EX-99.1
2
lite_ex991xq2fy22.htm
EX-99.1

[0001628280-22-001736:8k_2_02:2]
Document

[0001628280-22-001736:8k_2_02:3]
NEWS RELEASE

[0001628280-22-001736:8k_2_02:4]
LUMENTUM ANNOUNCES FISCAL SECOND QUARTER 2022 FINANCIAL RESULTS

[0001628280-22-001736:8k_2_02:5]
•Net revenue of $446.7 million

[0001628280-22-001736:8k_2_02:6]
•GAAP gross margin of 46.5%; Non-GAAP gross margin of 51.0%

[0001628280-22-001736:8k_2_02:7]
•GAAP operating margin of 19.1%; Non-GAAP operating margin of 31.7%

[0001628280-22-001736:8k_2_02:8]
•GAAP diluted net income per share of $0.75; Non-GAAP diluted net income per share of $1.60

[0001628280-22-001736:8k_2_02:9]
San Jose, Calif., February 3, 2022 – Lumentum Holdings Inc. (“Lumentum” or the “Company”) today reported results for its fiscal second quarter ended January 1, 2022.

[0001628280-22-001736:8k_2_02:10]
“Second quarter demand was strong across all major product lines, and our results were above the midpoint of our guidance on all metrics,” said Alan Lowe, President and CEO. “Industry-wide supply shortages have worsened with the recent surge in COVID-19 and are negatively impacting our third quarter revenue guidance by more than $65 million. These shortages come at a time when customer demand is accelerating for our differentiated communications products, which are essential to multi-year expansions in next-generation optical network capacity that are just beginning to be deployed. We continue to work to alleviate supply constraints, and expect fourth quarter revenue to be up from that of the third quarter and supply shortages to improve by the second half of this calendar year.”

[0001628280-22-001736:8k_2_02:11]
Mr. Lowe added, “Looking beyond these near-term supply challenges, I am highly optimistic about our outlook and believe market inflections beneficial to us in all of our addressable markets will drive double-digit revenue growth in fiscal 2023 and beyond not including the pending acquisition of NeoPhotonics.”

[0001628280-22-001736:8k_2_02:12]
Fiscal Second Quarter Highlights:

[0001628280-22-001736:8k_2_02:13]
Net revenue for the fiscal second quarter of 2022 was $446.7 million, with GAAP net income of $56.7 million, or $0.75 per diluted share. Net revenue for the fiscal first quarter of 2022 was $448.4 million, with GAAP net income of $81.5 million, or $1.08 per diluted share. Net revenue for the fiscal second quarter of 2021 was $478.8 million, with GAAP net income of $83.2 million, or $1.06 per diluted share.

[0001628280-22-001736:8k_2_02:14]
Non-GAAP net income for the fiscal second quarter of 2022 was $120.2 million, or $1.60 per diluted share. Non-GAAP net income for the fiscal first quarter of 2022 was $135.1 million, or $1.79 per diluted share. Non-GAAP net income for the fiscal second quarter of 2021 was $145.4 million, or $1.85 per diluted share.

[0001628280-22-001736:8k_2_02:15]
The Company held $2,022.4 million in total cash, cash equivalents, and short-term investments at the end of the fiscal second quarter of 2022, up $137.8 million from the end of the fiscal first quarter of 2022. Cash from operations was $206.5 million, and we used $29.9 million to repurchase 330 thousand shares of our common stock. Since the share buyback program was approved by the board of directors in May 2021, we have repurchased 4.5 million shares in aggregate for a total cash payment of $362.6 million.

[0001628280-22-001736:8k_2_02:16]
Financial Overview – Fiscal Second Quarter Ended January 1, 2022

[0001628280-22-001736:8k_2_02:17]
|  | GAAP Results ($ in millions) |
|  | Q2 |  | Q1 |  | Q2 |  | Change |
|  | FY 2022 |  | FY 2022 |  | FY 2021 |  | Q/Q |  | Y/Y |
| Net revenue | $446.7 |  | $448.4 |  | $478.8 |  | (0.4)% |  | (6.7)% |
| Gross margin | 46.5% |  | 51.8% |  | 48.0% |  | (530)bps |  | (150)bps |
| Operating margin | 19.1% |  | 25.8% |  | 24.1% |  | (670)bps |  | (500)bps |
|  | Non-GAAP Results ($ in millions) |
|  | Q2 |  | Q1 |  | Q2 |  | Change |
|  | FY 2022 |  | FY 2022 |  | FY 2021 |  | Q/Q |  | Y/Y |
| Net revenue | $446.7 |  | $448.4 |  | $478.8 |  | (0.4)% |  | (6.7)% |
| Gross margin | 51.0% |  | 55.0% |  | 53.4% |  | (400)bps |  | (240)bps |
| Operating margin | 31.7% |  | 35.4% |  | 35.5% |  | (370)bps |  | (380)bps |

[0001628280-22-001736:8k_2_02:18]
|  | Net Revenue by Segment ($ in millions) |
|  | Q2 |  | % of |  | Q1 |  | Q2 |  | Change |
|  | FY 2022 |  | Net Revenue |  | FY 2022 |  | FY 2021 |  | Q/Q |  | Y/Y |
| Optical Communications | $ | 397.4 |  |  | 89.0 | % |  | $ | 406.0 |  |  | $ | 449.1 |  |  | (2.1) | % |  | (11.5) | % |
| Lasers | 49.3 |  |  | 11.0 | % |  | 42.4 |  |  | 29.7 |  |  | 16.3 | % |  | 66.0 | % |
| Total | $ | 446.7 |  |  | 100.0 | % |  | $ | 448.4 |  |  | $ | 478.8 |  |  | (0.4) | % |  | (6.7) | % |

[0001628280-22-001736:8k_2_02:19]
The tables above provide comparisons of quarterly results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled “Use of Non-GAAP Financial Measures.”

[0001628280-22-001736:8k_2_02:20]
Business Outlook

[0001628280-22-001736:8k_2_02:21]
Lumentum expects the following for the fiscal third quarter 2022:

[0001628280-22-001736:8k_2_02:22]
•Net revenue in the range of $375 million to $405 million, negatively impacted by more than $65 million due to supply shortages

[0001628280-22-001736:8k_2_02:23]
•Non-GAAP operating margin of 24.0% to 26.0%

[0001628280-22-001736:8k_2_02:24]
•Non-GAAP diluted earnings per share of $1.01 to $1.19

[0001628280-22-001736:8k_2_02:25]
We have not provided reconciliations from GAAP to non-GAAP measures for our outlook. A large portion of non-GAAP adjustments, such as restructuring charges, stock-based compensation, non-cash income tax expense and credits, integration and acquisition related costs, inventory write down due to plans to exit certain product lines and other costs and contingencies unrelated to current and future operations are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future.

[0001628280-22-001736:8k_2_02:26]
Related Announcement and Conference Call

[0001628280-22-001736:8k_2_02:27]
Lumentum will host a conference call today, February 3, 2022, at 5:30 am PT / 8:30 am ET to discuss its fiscal second quarter results.  A live webcast of the call and the replay will be available in the Investors section of the Lumentum website at http://investor.lumentum.com through February 10, 2022, at 8:59 pm PT / 11:59 pm ET. To listen to the live conference call, dial (844) 200-6205 or (929) 526-1599 and reference the passcode 890747. To access the replay, dial (866) 813-9403 or (929) 458-6194 and reference the passcode 160760. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the “Events and Presentations” section concurrently with this earnings press release. Lumentum has used, and intends to continue to use, its Investor Relations website as means of disclosing material nonpublic information and for complying with its disclosure obligations under Regulation FD. This press release is being furnished as an exhibit to a Current Report on Form 8-K filed with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001628280-22-001736:8k_2_02:28]
About Lumentum

[0001628280-22-001736:8k_2_02:29]
Lumentum (NASDAQ: LITE) is a market-leading designer and manufacturer of innovative optical and photonic products enabling optical networking and laser applications worldwide. Lumentum optical components and subsystems are part of virtually every type of telecom, enterprise, and data center network. Lumentum lasers enable advanced manufacturing techniques and diverse applications including next-generation 3D sensing capabilities. Lumentum is headquartered in San Jose, California with R&D, manufacturing, and sales offices worldwide. For more information, visit www.lumentum.com.

[0001628280-22-001736:8k_2_02:30]
Forward-Looking Statements

[0001628280-22-001736:8k_2_02:31]
Contact Information

[0001628280-22-001736:8k_2_02:32]
Investors:    Kathy Ta, 408-750-3853; investor.relations@lumentum.com

[0001628280-22-001736:8k_2_02:33]
Media:        Sean Ogarrio, 408-546-5405; media@lumentum.com

[0001628280-22-001736:8k_2_02:34]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001628280-22-001736:8k_2_02:35]
LUMENTUM HOLDINGS INC.

[0001628280-22-001736:8k_2_02:36]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001628280-22-001736:8k_2_02:37]
(in millions, except per share data)

[0001628280-22-001736:8k_2_02:38]
(unaudited)

[0001628280-22-001736:8k_2_02:39]
|  | Three Months Ended |  | Six Months Ended |
|  | January 1, 2022 |  | December 26, 2020 |  | January 1, 2022 |  | December 26, 2020 |
| Net revenue | $ | 446.7 |  |  | $ | 478.8 |  |  | $ | 895.1 |  |  | $ | 931.2 |  |
| Cost of sales | 223.3 |  |  | 234.2 |  |  | 423.7 |  |  | 465.9 |  |
| Amortization of acquired developed intangibles | 15.9 |  |  | 15.0 |  |  | 31.7 |  |  | 30.0 |  |
| Gross profit | 207.5 |  |  | 229.6 |  |  | 439.7 |  |  | 435.3 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 53.2 |  |  | 52.8 |  |  | 107.3 |  |  | 103.2 |  |
| Selling, general and administrative | 69.0 |  |  | 61.3 |  |  | 132.3 |  |  | 117.6 |  |
| Restructuring and related charges | 0.1 |  |  | 0.2 |  |  | (1.0) |  |  | 0.2 |  |
| Total operating expenses | 122.3 |  |  | 114.3 |  |  | 238.6 |  |  | 221.0 |  |
| Income from operations | 85.2 |  |  | 115.3 |  |  | 201.1 |  |  | 214.3 |  |
| Interest expense | (17.1) |  |  | (16.3) |  |  | (34.0) |  |  | (32.3) |  |
| Other income (expense), net | 1.0 |  |  | (0.9) |  |  | 1.6 |  |  | (0.3) |  |
| Income before income taxes | 69.1 |  |  | 98.1 |  |  | 168.7 |  |  | 181.7 |  |
| Provision for income taxes | 12.4 |  |  | 14.9 |  |  | 30.5 |  |  | 31.4 |  |
| Net income | $ | 56.7 |  |  | $ | 83.2 |  |  | $ | 138.2 |  |  | $ | 150.3 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.78 |  |  | $ | 1.10 |  |  | $ | 1.91 |  |  | $ | 1.99 |  |
| Diluted | $ | 0.75 |  |  | $ | 1.06 |  |  | $ | 1.83 |  |  | $ | 1.92 |  |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |
| Basic | 72.3 |  |  | 75.6 |  |  | 72.5 |  |  | 75.5 |  |
| Diluted | 75.3 |  |  | 78.4 |  |  | 75.4 |  |  | 78.3 |  |

[0001628280-22-001736:8k_2_02:40]
LUMENTUM HOLDINGS INC.

[0001628280-22-001736:8k_2_02:41]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-22-001736:8k_2_02:42]
(in millions, except per share data)

[0001628280-22-001736:8k_2_02:43]
(unaudited)

[0001628280-22-001736:8k_2_02:44]
|  | January 1, 2022 |  | July 3, 2021 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 552.0 |  |  | $ | 774.3 |  |
| Short-term investments | 1,470.4 |  |  | 1,171.7 |  |
| Accounts receivable, net | 239.2 |  |  | 212.8 |  |
| Inventories | 208.1 |  |  | 196.4 |  |
| Prepayments and other current assets | 70.4 |  |  | 81.6 |  |
| Total current assets | 2,540.1 |  |  | 2,436.8 |  |
| Property, plant and equipment, net | 359.6 |  |  | 361.1 |  |
| Operating lease right-of-use assets, net | 75.1 |  |  | 67.4 |  |
| Goodwill | 368.9 |  |  | 368.9 |  |
| Other intangible assets, net | 198.3 |  |  | 241.2 |  |
| Deferred tax asset | 67.2 |  |  | 72.9 |  |
| Other non-current assets | 6.5 |  |  | 3.3 |  |
| Total assets | $ | 3,615.7 |  |  | $ | 3,551.6 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 118.2 |  |  | $ | 116.9 |  |
| Accrued payroll and related expenses | 50.3 |  |  | 54.3 |  |
| Accrued expenses | 41.0 |  |  | 33.1 |  |
| Convertible notes, current | 401.0 |  |  | 390.7 |  |
| Operating lease liabilities, current | 12.3 |  |  | 11.8 |  |
| Other current liabilities | 33.9 |  |  | 57.8 |  |
| Total current liabilities | 656.7 |  |  | 664.6 |  |
| Convertible notes, non-current | 810.3 |  |  | 789.8 |  |
| Operating lease liabilities, non-current | 55.8 |  |  | 47.6 |  |
| Deferred tax liability | 29.0 |  |  | 35.9 |  |
| Other non-current liabilities | 42.0 |  |  | 40.9 |  |
| Total liabilities | 1,593.8 |  |  | 1,578.8 |  |
| Stockholders’ equity: |  |  |  |
| Common stock, $0.001 par value, 990 authorized shares, 72.2 and 73.0 shares issued and outstanding as of January 1, 2022 and July 3, 2021, respectively | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital | 1,778.1 |  |  | 1,743.6 |  |
| Retained earnings | 237.5 |  |  | 220.9 |  |
| Accumulated other comprehensive income | 6.2 |  |  | 8.2 |  |
| Total stockholders’ equity | 2,021.9 |  |  | 1,972.8 |  |
| Total liabilities and stockholders’ equity | $ | 3,615.7 |  |  | $ | 3,551.6 |  |

[0001628280-22-001736:8k_2_02:45]
Use of Non-GAAP Financial Measures

[0001628280-22-001736:8k_2_02:46]
In this press release, Lumentum provides investors with certain non-GAAP financial measures: gross profit, gross margin, research and development expense, selling, general and administrative expense, operating margin, income from operations, interest and other income (expense), net, income before income taxes, provision for income taxes, net income, and net income per share on a non-GAAP basis, as well as the non-GAAP measures of EBITDA and Adjusted EBITDA. Lumentum believes this non-GAAP financial information provides additional insight into the Company’s ongoing business operations and results, as well as cash generation, and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s ongoing operations and enable more meaningful period to period comparisons. In addition, the Company believes that providing certain of these measures allows investors to better understand the Company’s cash flows and, importantly, to evaluate the efficacy of the methodology and information used by management to evaluate and measure such cash flows. However, these measures may be different from non-GAAP measures used by other companies, limiting their usefulness for comparison purposes. The non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP. Investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future. Further, these non-GAAP financial measures may not be comparable to similarly titled measurements reported by other companies.

[0001628280-22-001736:8k_2_02:47]
Our non-GAAP measures used in this press release exclude (i) stock-based compensation, (ii) gain on sale of product lines, (iii) integration related costs, (iv) inventory and fixed asset write down due to product line exits, (v) amortization of acquired intangibles, (vi) restructuring and related charges, (vii) foreign exchange (gains) losses, net, (viii) non-cash interest expense on convertible notes, (ix) non-cash income tax impacts, and (x) other (gains) charges related to non-recurring activities.

[0001628280-22-001736:8k_2_02:48]
A quantitative reconciliation between GAAP and non-GAAP financial data with respect to historical periods is included in the supplemental financial table attached to this press release.

[0001628280-22-001736:8k_2_02:49]
LUMENTUM HOLDINGS INC.

[0001628280-22-001736:8k_2_02:50]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001628280-22-001736:8k_2_02:51]
(in millions, except per share data)

[0001628280-22-001736:8k_2_02:52]
(unaudited)

[0001628280-22-001736:8k_2_02:53]
|  | Three Months Ended |  |  | Six Months Ended |  |
|  | January 1, 2022 |  | October 2, 2021 |  | December 26, 2020 |  |  | January 1, 2022 |  | December 26, 2020 |  |
| Gross profit on GAAP basis | $ | 207.5 |  |  | $ | 232.2 |  |  | $ | 229.6 |  |  |  | $ | 439.7 |  |  | $ | 435.3 |  |  |
| Stock-based compensation | 5.2 |  |  | 4.6 |  |  | 4.8 |  |  |  | 9.8 |  |  | 8.5 |  |  |
| Inventory and fixed asset write down due to product line exits | 0.1 |  |  | — |  |  | 0.1 |  |  |  | 0.1 |  |  | 0.4 |  |  |
| Amortization of acquired intangibles | 15.9 |  |  | 15.8 |  |  | 15.0 |  |  |  | 31.7 |  |  | 30.0 |  |  |
| Other (gains) charges (1) | (0.7) |  |  | (5.9) |  |  | 6.4 |  |  |  | (6.6) |  |  | 16.9 |  |  |
| Gross profit on non-GAAP basis | $ | 228.0 |  |  | $ | 246.7 |  |  | $ | 255.9 |  |  |  | $ | 474.7 |  |  | $ | 491.1 |  |  |
| Gross margin on non-GAAP basis | 51.0 | % |  | 55.0 | % |  | 53.4 | % |  |  | 53.0 | % |  | 52.7 | % |  |
| Research and development on GAAP basis | $ | 53.2 |  |  | $ | 54.1 |  |  | $ | 52.8 |  |  |  | $ | 107.3 |  |  | $ | 103.2 |  |  |
| Stock-based compensation | (5.4) |  |  | (5.0) |  |  | (5.1) |  |  |  | (10.4) |  |  | (9.5) |  |  |
| Other gains (charges) | — |  |  | (0.1) |  |  | 0.1 |  |  |  | (0.1) |  |  | — |  |  |
| Research and development on non-GAAP basis | $ | 47.8 |  |  | $ | 49.0 |  |  | $ | 47.8 |  |  |  | $ | 96.8 |  |  | $ | 93.7 |  |  |
| Selling, general and administrative on GAAP basis | $ | 69.0 |  |  | $ | 63.3 |  |  | $ | 61.3 |  |  |  | $ | 132.3 |  |  | $ | 117.6 |  |  |
| Stock-based compensation | (16.7) |  |  | (15.2) |  |  | (14.2) |  |  |  | (31.9) |  |  | (25.6) |  |  |
| Integration related costs | — |  |  | — |  |  | (0.2) |  |  |  | — |  |  | (0.5) |  |  |
| Amortization of acquired intangibles | (5.6) |  |  | (5.6) |  |  | (5.9) |  |  |  | (11.2) |  |  | (11.6) |  |  |
| Other gains (charges) (2) | (8.1) |  |  | (3.7) |  |  | (2.8) |  |  |  | (11.8) |  |  | (4.9) |  |  |
| Selling, general and administrative on non-GAAP basis | $ | 38.6 |  |  | $ | 38.8 |  |  | $ | 38.2 |  |  |  | $ | 77.4 |  |  | $ | 75.0 |  |  |
| Income from operations on GAAP basis | $ | 85.2 |  |  | $ | 115.9 |  |  | $ | 115.3 |  |  |  | $ | 201.1 |  |  | $ | 214.3 |  |  |
| Stock-based compensation | 27.3 |  |  | 24.8 |  |  | 24.1 |  |  |  | 52.1 |  |  | 43.6 |  |  |
| Inventory and fixed asset write down due to product line exits | 0.1 |  |  | — |  |  | 0.1 |  |  |  | 0.1 |  |  | 0.4 |  |  |
| Integration related costs | — |  |  | — |  |  | 0.2 |  |  |  | — |  |  | 0.5 |  |  |
| Amortization of acquired intangibles | 21.5 |  |  | 21.4 |  |  | 20.9 |  |  |  | 42.9 |  |  | 41.6 |  |  |
| Restructuring and related charges | 0.1 |  |  | (1.1) |  |  | 0.2 |  |  |  | (1.0) |  |  | 0.2 |  |  |
| Other (gains) charges (1) (2) | 7.4 |  |  | (2.1) |  |  | 9.1 |  |  |  | 5.3 |  |  | 21.8 |  |  |
| Income from operations on non-GAAP basis | $ | 141.6 |  |  | $ | 158.9 |  |  | $ | 169.9 |  |  |  | $ | 300.5 |  |  | $ | 322.4 |  |  |
| Operating margin on non-GAAP basis | 31.7 | % |  | 35.4 | % |  | 35.5 | % |  |  | 33.6 | % |  | 34.6 | % |  |
| Interest and other expense, net on GAAP basis | $ | (16.1) |  |  | $ | (16.3) |  |  | $ | (17.2) |  |  |  | $ | (32.4) |  |  | $ | (32.6) |  |  |
| Gain on sale of product lines | — |  |  | — |  |  | (0.1) |  |  |  | — |  |  | (0.5) |  |  |
| Foreign exchange (gains) losses, net | (0.7) |  |  | 0.1 |  |  | 2.8 |  |  |  | (0.6) |  |  | 5.1 |  |  |
| Non-cash interest expense on convertible notes and other expenses | 15.8 |  |  | 15.3 |  |  | 14.7 |  |  |  | 31.1 |  |  | 29.1 |  |  |
| Interest and other income (expense), net on non-GAAP basis | $ | (1.0) |  |  | $ | (0.9) |  |  | $ | 0.2 |  |  |  | $ | (1.9) |  |  | $ | 1.1 |  |  |

[0001628280-22-001736:8k_2_02:54]
| Income before income taxes on GAAP basis | $ | 69.1 |  |  | $ | 99.6 |  |  | $ | 98.1 |  |  |  | $ | 168.7 |  |  | $ | 181.7 |  |  |
| Stock-based compensation | 27.3 |  |  | 24.8 |  |  | 24.1 |  |  |  | 52.1 |  |  | 43.6 |  |  |
| Inventory and fixed asset write down due to product line exits | 0.1 |  |  | — |  |  | 0.1 |  |  |  | 0.1 |  |  | 0.4 |  |  |
| Integration related costs | — |  |  | — |  |  | 0.2 |  |  |  | — |  |  | 0.5 |  |  |
| Amortization of acquired intangibles | 21.5 |  |  | 21.4 |  |  | 20.9 |  |  |  | 42.9 |  |  | 41.6 |  |  |
| Restructuring and related charges | 0.1 |  |  | (1.1) |  |  | 0.2 |  |  |  | (1.0) |  |  | 0.2 |  |  |
| Gain on sale of product lines | — |  |  | — |  |  | (0.1) |  |  |  | — |  |  | (0.5) |  |  |
| Foreign exchange (gains) losses, net | (0.7) |  |  | 0.1 |  |  | 2.8 |  |  |  | (0.6) |  |  | 5.1 |  |  |
| Non-cash interest expense on convertible notes and other expenses | 15.8 |  |  | 15.3 |  |  | 14.7 |  |  |  | 31.1 |  |  | 29.1 |  |  |
| Other (gains) charges (1) (2) | 7.4 |  |  | (2.1) |  |  | 9.1 |  |  |  | 5.3 |  |  | 21.8 |  |  |
| Income before income taxes on non-GAAP basis | $ | 140.6 |  |  | $ | 158.0 |  |  | $ | 170.1 |  |  |  | $ | 298.6 |  |  | $ | 323.5 |  |  |
| Provision for income taxes on GAAP basis | $ | 12.4 |  |  | $ | 18.1 |  |  | $ | 14.9 |  |  |  | $ | 30.5 |  |  | $ | 31.4 |  |  |
| Income tax adjustments (3) | 8.0 |  |  | 4.8 |  |  | 9.8 |  |  |  | 12.8 |  |  | 15.5 |  |  |
| Provision for income taxes on non-GAAP basis | $ | 20.4 |  |  | $ | 22.9 |  |  | $ | 24.7 |  |  |  | $ | 43.3 |  |  | $ | 46.9 |  |  |
| Net income on GAAP basis | $ | 56.7 |  |  | $ | 81.5 |  |  | $ | 83.2 |  |  |  | $ | 138.2 |  |  | $ | 150.3 |  |  |
| Stock-based compensation | 27.3 |  |  | 24.8 |  |  | 24.1 |  |  |  | 52.1 |  |  | 43.6 |  |  |
| Inventory and fixed asset write down due to product line exits | 0.1 |  |  | — |  |  | 0.1 |  |  |  | 0.1 |  |  | 0.4 |  |  |
| Integration related costs | — |  |  | — |  |  | 0.2 |  |  |  | — |  |  | 0.5 |  |  |
| Amortization of acquired intangibles | 21.5 |  |  | 21.4 |  |  | 20.9 |  |  |  | 42.9 |  |  | 41.6 |  |  |
| Restructuring and related charges | 0.1 |  |  | (1.1) |  |  | 0.2 |  |  |  | (1.0) |  |  | 0.2 |  |  |
| Gain on sale of product lines | — |  |  | — |  |  | (0.1) |  |  |  | — |  |  | (0.5) |  |  |
| Foreign exchange (gains) losses, net | (0.7) |  |  | 0.1 |  |  | 2.8 |  |  |  | (0.6) |  |  | 5.1 |  |  |
| Non-cash interest expense on convertible notes and other expenses | 15.8 |  |  | 15.3 |  |  | 14.7 |  |  |  | 31.1 |  |  | 29.1 |  |  |
| Income tax adjustments (3) | (8.0) |  |  | (4.8) |  |  | (9.8) |  |  |  | (12.8) |  |  | (15.5) |  |  |
| Other (gains) charges (1) (2) | 7.4 |  |  | (2.1) |  |  | 9.1 |  |  |  | 5.3 |  |  | 21.8 |  |  |
| Net income on non-GAAP basis | $ | 120.2 |  |  | $ | 135.1 |  |  | $ | 145.4 |  |  |  | $ | 255.3 |  |  | $ | 276.6 |  |  |
| Net income per share on non-GAAP basis | $ | 1.60 |  |  | $ | 1.79 |  |  | $ | 1.85 |  |  |  | $ | 3.39 |  |  | $ | 3.53 |  |  |
| Shares used in per share calculation - diluted on non-GAAP basis | 75.3 |  |  | 75.4 |  |  | 78.4 |  |  |  | 75.4 |  |  | 78.3 |  |  |

[0001628280-22-001736:8k_2_02:55]
(1) Other (gains) charges excluded from gross profit for the six months ended January 1, 2022 primarily relate to $5.9 million gains during the fiscal first quarter from equipment sale in connection with transferring product lines to new production facilities.

[0001628280-22-001736:8k_2_02:56]
(2) During the fiscal second quarter of 2022, other charges excluded from selling, general and administrative expense primarily include $4.6 million of legal and advisory fees related to the pending acquisition of NeoPhotonics and $2.3 million of professional service fees related to optimizing our international structure. During the fiscal first quarter of 2022, other charges excluded from selling, general and administrative expense include $1.2 million of costs related to optimizing our international structure and $1.3 million of exit, moving and other costs incurred in connection with transferring product lines to new production facilities during the first fiscal quarter.

[0001628280-22-001736:8k_2_02:57]
(3) In order to give a more meaningful perspective of our tax burden over a longer-term period, and in accordance with the SEC Non-GAAP Financial Measures Compliance  and  Disclosure  Interpretations,  beginning  in fiscal  fourth  quarter 2021,  Lumentum  changed  its  method  of  calculating  its  non-GAAP income  tax provision.  This change in methodology does not affect the Company’s non-GAAP operating profit, annual cash tax payments, or cash flows, but results in higher reported non-

[0001628280-22-001736:8k_2_02:58]
GAAP tax provisions. As such, income tax adjustments have been revised for the three and six months ended December 26, 2020 in order to be comparable.

[0001628280-22-001736:8k_2_02:59]
LUMENTUM HOLDINGS INC.

[0001628280-22-001736:8k_2_02:60]
RECONCILIATION OF GAAP NET INCOME TO ADJUSTED EBITDA

[0001628280-22-001736:8k_2_02:61]
(in millions, except per share data)

[0001628280-22-001736:8k_2_02:62]
(unaudited)

[0001628280-22-001736:8k_2_02:63]
|  | Three Months Ended |  | Six Months Ended |  |  |
|  | January 1, 2022 |  |  |  | October 2, 2021 |  | December 26, 2020 |  | January 1, 2022 |  | December 26, 2020 |  |  |  |  |
| GAAP Net income | $ | 56.7 |  |  |  |  | $ | 81.5 |  |  | $ | 83.2 |  |  | $ | 138.2 |  |  | $ | 150.3 |  |  |  |  |  |
| Interest and other expense, net | 16.1 |  |  |  |  | 16.3 |  |  | 17.2 |  |  | 32.4 |  |  | 32.6 |  |  |  |  |  |
| Provision for income taxes | 12.4 |  |  |  |  | 18.1 |  |  | 14.9 |  |  | 30.5 |  |  | 31.4 |  |  |  |  |  |
| Depreciation | 20.6 |  |  |  |  | 20.4 |  |  | 23.8 |  |  | 41.0 |  |  | 47.6 |  |  |  |  |  |
| Amortization of acquired intangibles | 21.5 |  |  |  |  | 21.4 |  |  | 20.9 |  |  | 42.9 |  |  | 41.6 |  |  |  |  |  |
| EBITDA | 127.3 |  |  |  |  | 157.7 |  |  | 160.0 |  |  | 285.0 |  |  | 303.5 |  |  |  |  |  |
| Restructuring and related charges | 0.1 |  |  |  |  | (1.1) |  |  | 0.2 |  |  | (1.0) |  |  | 0.2 |  |  |  |  |  |
| Stock-based compensation | 27.3 |  |  |  |  | 24.8 |  |  | 24.1 |  |  | 52.1 |  |  | 43.6 |  |  |  |  |  |
| Inventory and fixed asset write down due to product line exits | 0.1 |  |  |  |  | — |  |  | 0.1 |  |  | 0.1 |  |  | 0.4 |  |  |  |  |  |
| Integration related costs | — |  |  |  |  | — |  |  | 0.2 |  |  | — |  |  | 0.5 |  |  |  |  |  |
| Other (gains) charges | 7.6 |  |  |  |  | (1.9) |  |  | 6.9 |  |  | 5.7 |  |  | 17.0 |  |  |  |  |  |
| Adjusted EBITDA | $ | 162.4 |  |  |  |  | $ | 179.5 |  |  | $ | 191.5 |  |  | $ | 341.9 |  |  | $ | 365.2 |  |  |  |  |  |
