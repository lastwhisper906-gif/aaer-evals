# LITE note change history — 0001628280-21-021632 → 0001628280-22-001745


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-02-03):
[0001628280-22-001745:note_history:1]
Purchase obligations of $314.5 million as of January 1, 2022, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements.
  (was, 2021-11-04, similarity 0.966):
[0001628280-21-021632:note_history:1]
Purchase obligations of $260.4 million as of October 2, 2021, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements.

- added (2022-02-03):
[0001628280-22-001745:note_history:2]
|  | Three Months Ended |  | Six Months Ended |
|  | January 1, 2022 |  | December 26, 2020 |  | January 1, 2022 |  | December 26, 2020 |
| Balance as of beginning of period | $ | 5.1 |  |  | $ | 7.6 |  |  | $ | 5.0 |  |  | $ | 5.0 |  |
| Provision for warranty | 3.8 |  |  | 0.2 |  |  | 5.5 |  |  | 4.1 |  |
| Utilization of reserve | (0.3) |  |  | (2.1) |  |  | (1.9) |  |  | (3.4) |  |
| Balance as of end of period | $ | 8.6 |  |  | $ | 5.7 |  |  | $ | 8.6 |  |  | $ | 5.7 |  |

- changed (2022-02-03):
[0001628280-22-001745:note_history:3]
Oclaro Merger Litigation
  (was, 2021-11-04, similarity 0.8293):
[0001628280-21-021632:note_history:3]
Merger Litigation

- changed (2022-02-03):
[0001628280-22-001745:note_history:4]
The remaining Lawsuit (the Karri Lawsuit) currently purports to seek, among other things, damages to be awarded to the plaintiff and any class, if a class is certified, and litigation costs, including attorneys’ fees.  A lead plaintiff and counsel has been selected, and an amended complaint was filed on April 15, 2019, which also named Lumentum as a defendant. A motion to dismiss the amended complaint was granted in part and denied in part by the court on October 8, 2020. On December 1, 2020, defendants answered the amended complaint. On December 23, 2020, defendants filed a motion for leave to file a motion for reconsideration of the Court’s October 8th order on the motion to dismiss, which was denied on January 29, 2021. On June 22, 2021, the Court granted the parties’ stipulation to dismiss Lumentum as a defendant from the action.  On September 17, 2021, lead plaintiff filed a second amended complaint (“SAC”).  Defendants moved to stay discovery in light of the SAC, and on January 11, 2022 the Court struck the SAC as untimely, terminated defendants’ motions to dismiss as moot, and lifted the stay.  The Karri Lawsuit remains pending with the parties currently in discovery. Defendants intend to defend the Karri Lawsuit vigorously.
  (was, 2021-11-04, similarity 0.7174):
[0001628280-21-021632:note_history:4]
The remaining Lawsuit (the Karri Lawsuit) currently purports to seek, among other things, damages to be awarded to the plaintiff and any class, if a class is certified, and litigation costs, including attorneys’ fees.  A lead plaintiff and counsel has been selected, and an amended complaint was filed on April 15, 2019, which also names Lumentum as a defendant. A motion to dismiss the amended complaint was granted in part and denied in part by the court on October 8, 2020. On December 1, 2020, defendants answered the amended complaint.  On December 23, 2020, defendants filed a motion for leave to file a motion for reconsideration of the Court’s October 8th order on the motion to dismiss, which was denied on January 29, 2021. The Karri Lawsuit remains pending with the parties currently in discovery. Defendants intend to defend the Karri Lawsuit vigorously.

- added (2022-02-03):
[0001628280-22-001745:note_history:5]
NeoPhotonics Merger Litigation

- added (2022-02-03):
[0001628280-22-001745:note_history:6]
In connection with our planned acquisition of NeoPhotonics Corporation (“NeoPhotonics”) announced in November 2021, ten lawsuits (the “NeoPhotonics Lawsuits”) were filed by purported stockholders of NeoPhotonics challenging the proposed merger (the “NeoPhotonics Merger”).  Four of the NeoPhotonics Lawsuits, styled as Elaine Wang v. NeoPhotonics Corporation, et al., No. 1:21-cv-10338, Heather Smith v. NeoPhotonics Corporation, et al., No. 1:21-cv-10698, Matthew Hopkins v. NeoPhotonics Corporation, et al., No. 1:21-cv-10725, and John Ryan v. NeoPhotonics Corporation, et al., No. 1:22-cv-00046, were filed in the United States District Court for the Southern District of New York on December 3, 2021, December 14, 2021, December 15, 2021, and January 4, 2022, respectively.  Three of the NeoPhotonics Lawsuits, styled as Mengsheng Ku v. NeoPhotonics Corporation, et al., No. 5:21-cv-09479, Stephen Bushansky v. NeoPhotonics Corporation, et al., No. 5:21-cv-09825, and James Parshall v. NeoPhotonics Corporation, et al., No. 5:22-cv-00055, were filed in the United States District Court for the Northern District of New York on December 8, 2021, December 20, 2021, and January 5, 2022, respectively. One NeoPhotonics Lawsuit, styled as James Hendrickson v. NeoPhotonics Corporation, et al., No. 1:21-cv-06919, was filed in the United States District Court for the Eastern District of New York on December 15, 2021. One NeoPhotonics Lawsuit, styled as Alex Ciccotelli v. NeoPhotonics Corporation, et al., No. 2:21-cv-05611, was filed in the United States District Court for the Eastern District of Pennsylvania on December 23, 2021. One NeoPhotonics Lawsuit, styled as Christopher Taylor v. NeoPhotonics Corporation, et al., No. 1:22-cv-00002, was filed in the United States District Court for the District of Delaware on January 3, 2022.

- added (2022-02-03):
[0001628280-22-001745:note_history:7]
These ten NeoPhotonics Lawsuits name NeoPhotonics and its directors as defendants and do not name Lumentum.

- added (2022-02-03):
[0001628280-22-001745:note_history:8]
The NeoPhotonics Lawsuits generally allege, among other things, that NeoPhotonics and its directors violated Section 14(a) of the Exchange Act, Rule 14a-9 promulgated thereunder, and 17 C.F.R. § 244.100 by disseminating an incomplete and misleading Preliminary Proxy Statement on Schedule 14A, filed with the SEC on December 1, 2021 regarding the NeoPhotonics Merger. The NeoPhotonics Lawsuits further allege that NeoPhotonics’ directors violated Section 20(a) of the Exchange Act by failing to exercise proper control over the person(s) who violated Section 14(a) of the Exchange Act.  The complaints seek injunctive relief, rescission or rescissory damages, dissemination of a proxy statement that discloses certain information requested by the plaintiffs, and an award of plaintiffs’ costs, including attorneys’ fees and expenses.

- changed (2022-02-03):
[0001628280-22-001745:note_history:9]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future, and we may record charges in the future as a result of these indemnification obligations. As of January 1, 2022, we did not have any material indemnification claims that were probable or reasonably possible.
  (was, 2021-11-04, similarity 0.7943):
[0001628280-21-021632:note_history:9]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of October 2, 2021, we did not have any material indemnification claims that were probable or reasonably possible.

- removed (2022-02-03):
[0001628280-21-021632:note_history:10]
|  | Three Months Ended |  |  |
|  | October 2, 2021 |  | September 26, 2020 |  |  |  |  |
| Balance as of beginning of period | $ | 5.0 |  |  | $ | 5.0 |  |  |  |  |  |
| Provision for warranty | 1.7 |  |  | 3.9 |  |  |  |  |  |
| Utilization of reserve | (1.6) |  |  | (1.3) |  |  |  |  |  |
| Balance as of end of period | $ | 5.1 |  |  | $ | 7.6 |  |  |  |  |  |


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-02-03):
[0001628280-22-001745:note_history:11]
Lumentum Holdings Inc. (“we,” “us,” “our”, “Lumentum” or the “Company”) is an industry-leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including Optical Communications (“OpComms”) and Commercial Lasers (“Lasers”) for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology, and our volume manufacturing capability, to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be original equipment manufacturers (“OEMs”) that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that network equipment manufacturers (“NEMs”) assemble into communications networking systems, which they sell to network service providers, operators or enterprises with their own networks. Similarly, many of our Lasers products customers incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For 3D sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, gaming, and other applications who then integrate our devices within their products, for eventual resale to consumers and also into other industrial applications.
  (was, 2021-11-04, similarity 0.9821):
[0001628280-21-021632:note_history:11]
Lumentum Holdings Inc. (“we,” “us,” “our”, “Lumentum” or the “Company”) is an industry-leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including Optical Communications (“OpComms”) and Commercial Lasers (“Lasers”) for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology, and our volume manufacturing capability, to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be original equipment manufacturers (“OEMs”) that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that network equipment manufacturers (“NEMs”) assemble into communications networking systems, which they sell to network service providers, operators or enterprises with their own networks. Similarly, many of our customers for our Lasers products incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For 3D sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, gaming, and other applications who then integrate our devices within their products, for eventual resale to consumers and also into other industrial applications.

- changed (2022-02-03):
[0001628280-22-001745:note_history:12]
The accompanying condensed consolidated financial statements have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”), which requires management to make estimates and assumptions that affect the amounts reported in our condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact us in the future, actual results may be different from the estimates. Operating results for the quarter ended January 1, 2022 are not necessarily indicative of the results that may be expected for the fiscal year ending July 2, 2022. In the opinion of the Company’s management, the information presented herein reflects all normal and recurring adjustments necessary for a fair presentation of our results of operations, financial position, stockholders’ equity and cash flows.
  (was, 2021-11-04, similarity 0.6801):
[0001628280-21-021632:note_history:12]
The accompanying condensed consolidated financial statements have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”), which requires management to make estimates and assumptions that affect the amounts reported in our condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact us in the future, actual results may be different from the estimates. Operating results for the quarter ended October 2, 2021 are not necessarily indicative of the results that may be expected for the fiscal year ending July 2, 2022. In the opinion of the Company’s management, the information presented herein reflects all normal and recurring adjustments necessary for a fair presentation of our results of operations, financial position, stockholders’ equity and cash flows.

- changed (2022-02-03):
[0001628280-22-001745:note_history:13]
Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are inventory valuation, revenue recognition, income taxes, long-lived asset valuation, goodwill and business combination.
  (was, 2021-11-04, similarity 0.9477):
[0001628280-21-021632:note_history:13]
Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are inventory valuation, revenue recognition, income taxes, long-lived asset valuation and goodwill.

- changed (2022-02-03):
[0001628280-22-001745:note_history:14]
The COVID-19 pandemic has created and may continue to create significant uncertainty in global financial markets, which has disrupted and harmed, and may continue to disrupt and harm, our business, financial condition, and results of operations. The extent of the impact of COVID-19 on our operational and financial performance will depend on certain developments, including but not limited to the duration and spread of the outbreak, duration of local, state and federal issued public health orders in each jurisdiction where we operate or in which our customers and suppliers operate, impact on our customers and our sales cycles, impact on our supply chain and manufacturing partners, impact on our employees and impact on regional and worldwide economies and financial markets in general, all of which are uncertain and cannot be predicted. We assessed the potential impact that this pandemic has on our estimates as of January 1, 2022 and determined that there were no material impacts. However, due to the global supply chain constraint, we have had to incur incremental supply and procurement costs in order to increase our ability to fulfill demands from our customers. These costs have increased our inventory balances as of January 1, 2022 and will decrease our gross margin in the near term.
  (was, 2021-11-04, similarity 0.859):
[0001628280-21-021632:note_history:14]
The COVID-19 pandemic has created and may continue to create significant uncertainty in global financial markets, which has disrupted and harmed, and may continue to disrupt and harm, our business, financial condition, and results of operations. The extent of the impact of COVID-19 on our operational and financial performance will depend on certain developments, including but not limited to the duration and spread of the outbreak, duration of local, state and federal issued public health orders in each jurisdiction where we operate or in which our customers and suppliers operate, impact on our customers and our sales cycles, impact on our supply chain and manufacturing partners, impact on our employees and impact on regional and worldwide economies and financial markets in general, all of which are uncertain and cannot be predicted. We assessed the potential impact that this pandemic has on our estimates as of October 2, 2021 and determined that there were no material impacts.

- changed (2022-02-03):
[0001628280-22-001745:note_history:15]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2022 is a 52-week year ending on July 2, 2022, with the quarter ended January 1, 2022 being a 13-week quarterly period. Our fiscal 2021 was a 53-week year that ended on July 3, 2021, with the quarter ended December 26, 2020 being a 13-week quarterly period.
  (was, 2021-11-04, similarity 0.7456):
[0001628280-21-021632:note_history:15]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2022 is a 52-week year ending on July 2, 2022, with the quarter ended October 2, 2021 being a 13-week quarterly period. Our fiscal 2021 was a 53-week year that ended on July 3, 2021, with the quarter ended September 26, 2020 being a 13-week quarterly period.

- added (2022-02-03):
[0001628280-22-001745:note_history:16]
These interim unaudited condensed consolidated financial statements include the accounts of the Company and its wholly-owned subsidiaries. All inter-company transactions and balances are eliminated in consolidation.

- added (2022-02-03):
[0001628280-22-001745:note_history:17]
Accounting Policies

- changed (2022-02-03):
[0001628280-22-001745:note_history:18]
The condensed consolidated financial statements and accompanying related notes should be read in conjunction with the audited consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended July 3, 2021. There have been no significant changes to our accounting policies during the three and six months ended January 1, 2022.
  (was, 2021-11-04, similarity 0.7073):
[0001628280-21-021632:note_history:18]
These interim unaudited condensed consolidated financial statements include the accounts of the Company and its wholly-owned subsidiaries. All inter-company transactions and balances are eliminated in consolidation. 
Accounting PoliciesThe condensed consolidated financial statements and accompanying related notes should be read in conjunction with the audited consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended July 3, 2021. There have been no significant changes to our accounting policies during the three months ended October 2, 2021.

- added (2022-02-03):
[0001628280-22-001745:note_history:19]
Business Combination

- added (2022-02-03):
[0001628280-22-001745:note_history:20]
On November 4, 2021, Lumentum and NeoPhotonics Corporation (“NeoPhotonics”) announced a merger agreement (the “Merger Agreement”). Under the terms of the Merger Agreement, NeoPhotonics stockholders will receive $16.00 per share in cash for each NeoPhotonics share they own. As of January 1, 2022, the estimated total transaction consideration is expected to be approximately $918 million.  The cash consideration will be funded from the combined company’s balance sheet.

- added (2022-02-03):
[0001628280-22-001745:note_history:21]
On January 14, 2022, Lumentum and NeoPhotonics entered into a credit agreement where Lumentum agreed to make delayed draw term loans (“loans”) to NeoPhotonics in an aggregate principal amount not to exceed $50.0 million to help fund capital expenditures and increased working capital associated with NeoPhotonics’ growth plans. The loans will mature on January 14, 2024 unless earlier repaid or accelerated. The loans bear interest at the Wall Street Journal “prime rate”, payable monthly in arrears on the first day of each month. There have not been any drawdown of the loans.

- added (2022-02-03):
[0001628280-22-001745:note_history:22]
The Merger Agreement contains certain termination rights for both Lumentum and NeoPhotonics and provides that upon termination of the Merger Agreement under specified circumstances (including termination by NeoPhotonics to accept a superior proposal), NeoPhotonics may be required to pay Lumentum a termination fee of $27.5 million. The Merger Agreement further provides that if the Merger Agreement is terminated for failure to obtain antitrust approval, Lumentum may be required to pay NeoPhotonics a termination fee of $55.1 million; and if Lumentum takes certain specified actions, (including entering into any definitive agreement for an acquisition by stock purchase, merger, consolidation, amalgamation, purchase of assets, license or otherwise of any ownership interest or assets of any Person) that cause a material delay in, or results in the failure of, the consummation of the Merger, Lumentum may be required to payNeoPhotonics an additional termination fee of $36.7 million.
The Boards of Directors of Lumentum and NeoPhotonics have unanimously approved the transaction and the Merger Agreement. The transaction is subject to customary closing conditions, including the absence of certain legal impediments, the expiration or termination of the required waiting periods under the Hart-Scott-Rodino Antitrust Improvements Act of 1976, as amended, receipt of any required antitrust and regulatory approvals.  The transaction was approved by the NeoPhotonics stockholders on February 1, 2022. The transaction is not subject to any financing condition. We expect this transaction to be completed in the second half of calendar year 2022.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-02-03):
[0001628280-22-001745:note_history:23]
| Liability component: | January 1, 2022 |  | July 3, 2021 |
|  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2024 Notes |  | 2026 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 450.0 |  |  | $ | 1,050.0 |  |
| Unamortized debt discount and issuance costs | (49.0) |  |  | (239.7) |  |  | (59.3) |  |  | (260.2) |  |
| Net carrying amount of the liability component | $ | 401.0 |  |  | $ | 810.3 |  |  | $ | 390.7 |  |  | $ | 789.8 |  |
  (was, 2021-11-04, similarity 0.9802):
[0001628280-21-021632:note_history:23]
| Liability component: | October 2, 2021 |  | July 3, 2021 |
|  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2024 Notes |  | 2026 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 450.0 |  |  | $ | 1,050.0 |  |
| Unamortized debt discount and issuance costs | (54.2) |  |  | (250.0) |  |  | (59.3) |  |  | (260.2) |  |
| Net carrying amount of the liability component | $ | 395.8 |  |  | $ | 800.0 |  |  | $ | 390.7 |  |  | $ | 789.8 |  |

- changed (2022-02-03):
[0001628280-22-001745:note_history:24]
(1) Since the closing price of our stock exceeded $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of the second quarter of fiscal 2022, the 2024 Notes have become convertible at the option of the holders. Therefore, the debt component of our 2024 Notes as of January 1, 2022 has been classified as current liabilities in our condensed consolidated balance sheet.
  (was, 2021-11-04, similarity 0.9665):
[0001628280-21-021632:note_history:24]
(1) Since the closing price of our stock exceeded $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of the first quarter of fiscal 2022, the 2024 Notes have become convertible at the option of the holders. Therefore, the debt component of our 2024 Notes as of October 2, 2021 has been classified as current liabilities in our condensed consolidated balance sheet.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-02-03):
[0001628280-22-001745:note_history:25]
During the six months ended January 1, 2022, we received conversion requests for less than $0.1 million principal amount of the 2024 Notes, which were settled in cash in the first half of fiscal 2022.
  (was, 2021-11-04, similarity 0.9231):
[0001628280-21-021632:note_history:25]
During the three months ended October 2, 2021, we received conversion requests for less than $0.1 million principal amount of the 2024 Notes, which were settled in cash in the first quarter of fiscal 2022.

- changed (2022-02-03):
[0001628280-22-001745:note_history:26]
| Liability component: | January 1, 2022 |  | July 3, 2021 |
|  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2024 Notes |  | 2026 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 450.0 |  |  | $ | 1,050.0 |  |
| Unamortized debt discount and issuance costs | (49.0) |  |  | (239.7) |  |  | (59.3) |  |  | (260.2) |  |
| Net carrying amount of the liability component | $ | 401.0 |  |  | $ | 810.3 |  |  | $ | 390.7 |  |  | $ | 789.8 |  |
  (was, 2021-11-04, similarity 0.9802):
[0001628280-21-021632:note_history:26]
| Liability component: | October 2, 2021 |  | July 3, 2021 |
|  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2024 Notes |  | 2026 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 450.0 |  |  | $ | 1,050.0 |  |
| Unamortized debt discount and issuance costs | (54.2) |  |  | (250.0) |  |  | (59.3) |  |  | (260.2) |  |
| Net carrying amount of the liability component | $ | 395.8 |  |  | $ | 800.0 |  |  | $ | 390.7 |  |  | $ | 789.8 |  |

- changed (2022-02-03):
[0001628280-22-001745:note_history:27]
(1) Since the closing price of our stock exceeded $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of the second quarter of fiscal 2022, the 2024 Notes have become convertible at the option of the holders. Therefore, the debt component of our 2024 Notes as of January 1, 2022 has been classified as current liabilities in our condensed consolidated balance sheet.
  (was, 2021-11-04, similarity 0.9665):
[0001628280-21-021632:note_history:27]
(1) Since the closing price of our stock exceeded $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of the first quarter of fiscal 2022, the 2024 Notes have become convertible at the option of the holders. Therefore, the debt component of our 2024 Notes as of October 2, 2021 has been classified as current liabilities in our condensed consolidated balance sheet.

- changed (2022-02-03):
[0001628280-22-001745:note_history:28]
|  | Three Months Ended |  | Six Months Ended |
|  | January 1, 2022 |  | December 26, 2020 |  | January 1, 2022 |  | December 26, 2020 |
| Contractual interest expense | $ | 1.6 |  |  | $ | 1.6 |  |  | $ | 3.2 |  |  | $ | 3.2 |  |
| Amortization of the debt discount and debt issuance costs | 15.5 |  |  | 14.7 |  |  | 30.8 |  |  | 29.1 |  |
| Total interest expense | $ | 17.1 |  |  | $ | 16.3 |  |  | $ | 34.0 |  |  | $ | 32.3 |  |
  (was, 2021-11-04, similarity 0.7172):
[0001628280-21-021632:note_history:28]
|  | Three Months Ended |  |  |
|  | October 2, 2021 |  | September 26, 2020 |  |  |  |  |
| Contractual interest expense | $ | 1.6 |  |  | $ | 1.6 |  |  |  |  |  |
| Amortization of the debt discount and debt issuance costs | 15.3 |  |  | 14.4 |  |  |  |  |  |
| Total interest expense | $ | 16.9 |  |  | $ | 16.0 |  |  |  |  |  |

- changed (2022-02-03):
[0001628280-22-001745:note_history:29]
The future interest and principal payments related to our convertible notes are as follows as of January 1, 2022 (in millions):
  (was, 2021-11-04, similarity 0.9512):
[0001628280-21-021632:note_history:29]
The future interest and principal payments related to our convertible notes are as follows as of October 2, 2021 (in millions):


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-02-03):
[0001628280-22-001745:note_history:30]
|  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |
| January 1, 2022: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 60.1 |  |  | (0.2) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | 3.3 |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 83.7 |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 645.9 |  |  | (1.8) |  |  |  |  |  |  |  |  |  |
| Municipal bonds | 2.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 516.3 |  |  | (0.7) |  |  |  |  |  |  |  |  |  |
| Total | $ | 1,311.3 |  |  | $ | (2.7) |  |  |  |  |  |  |  |  |  |
| July 3, 2021: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 28.3 |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | 6.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 43.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 432.3 |  |  | (0.4) |  |  |  |  |  |  |  |  |  |
| Municipal bonds | 1.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 106.9 |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | 617.5 |  |  | $ | (0.4) |  |  |  |  |  |  |  |  |  |
  (was, 2021-11-04, similarity 0.9082):
[0001628280-21-021632:note_history:30]
|  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |
| October 2, 2021: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper | $ | 24.5 |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 329.6 |  |  | (0.2) |  |  |  |  |  |  |  |  |  |
| Municipal bonds | 1.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 338.2 |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | 693.3 |  |  | $ | (0.2) |  |  |  |  |  |  |  |  |  |
| July 3, 2021: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 28.3 |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | 6.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 43.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 432.3 |  |  | (0.4) |  |  |  |  |  |  |  |  |  |
| Municipal bonds | 1.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 106.9 |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | 617.5 |  |  | $ | (0.4) |  |  |  |  |  |  |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-02-03):
[0001628280-22-001745:note_history:31]
The future interest and principal payments related to our convertible notes are as follows as of January 1, 2022 (in millions):
  (was, 2021-11-04, similarity 0.9512):
[0001628280-21-021632:note_history:31]
The future interest and principal payments related to our convertible notes are as follows as of October 2, 2021 (in millions):


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2022-02-03):
[0001628280-22-001745:note_history:32]
|  | Three Months Ended |  | Six Months Ended |
|  | January 1, 2022 |  | December 26, 2020 |  | January 1, 2022 |  | December 26, 2020 |
| OpComms: |  |  |  |  |  |  |  |  |  |  |  |
| Telecom and Datacom | $ | 267.1 |  | 59.8 | % |  | $ | 286.2 |  | 59.8 | % |  | $ | 483.1 |  | 54.0 | % |  | $ | 547.5 |  | 58.8 | % |
| Industrial and Consumer | 130.3 |  | 29.2 |  |  | 162.9 |  | 34.0 |  |  | 320.3 |  | 35.8 |  |  | 330.1 |  | 35.4 |  |
| Total OpComms | $ | 397.4 |  | 89.0 | % |  | $ | 449.1 |  | 93.8 | % |  | $ | 803.4 |  | 89.8 | % |  | $ | 877.6 |  | 94.2 | % |
| Lasers | 49.3 |  | 11.0 | % |  | 29.7 |  | 6.2 | % |  | 91.7 |  | 10.2 |  |  | 53.6 |  | 5.8 |  |
| Net Revenue | $ | 446.7 |  |  |  | $ | 478.8 |  |  |  | $ | 895.1 |  |  |  | $ | 931.2 |  |  |

- changed (2022-02-03):
[0001628280-22-001745:note_history:33]
The following table reflects the changes in contract balances as of January 1, 2022 (in millions, except percentages):
  (was, 2021-11-04, similarity 0.9474):
[0001628280-21-021632:note_history:33]
The following table reflects the changes in contract balances as of October 2, 2021 (in millions, except percentages):

- changed (2022-02-03):
[0001628280-22-001745:note_history:34]
| Contract balances |  | Balance sheet location |  | January 1, 2022 |  | July 3, 2021 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 239.2 |  |  | $ | 212.8 |  |  | $ | 26.4 |  |  | 12.4 | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | — |  |  | $ | 0.6 |  |  | $ | (0.6) |  |  | (100.0) | % |
  (was, 2021-11-04, similarity 0.9466):
[0001628280-21-021632:note_history:34]
| Contract balances |  | Balance sheet location |  | October 2, 2021 |  | July 3, 2021 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 263.2 |  |  | $ | 212.8 |  |  | $ | 50.4 |  |  | 23.7 | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | — |  |  | $ | 0.6 |  |  | $ | (0.6) |  |  | (100.0) | % |

- removed (2022-02-03):
[0001628280-21-021632:note_history:35]
|  | Three Months Ended |  |  |
|  | October 2, 2021 |  | September 26, 2020 |  |  |  |  |
| OpComms: |  |  |  |  |  |  |  |  |  |  |  |
| Telecom and Datacom | $ | 216.0 |  | 48.2 | % |  | $ | 261.3 |  | 57.7 | % |  |  |  |  |  |  |
| Consumer and Industrial | 190.0 |  | 42.3 |  |  | 167.2 |  | 37.0 |  |  |  |  |  |  |  |
| Total OpComms | $ | 406.0 |  | 90.5 | % |  | $ | 428.5 |  | 94.7 | % |  |  |  |  |  |  |
| Lasers | 42.4 |  | 9.5 | % |  | 23.9 |  | 5.3 | % |  |  |  |  |  |  |
| Net Revenue | $ | 448.4 |  |  |  | $ | 452.4 |  |  |  |  |  |  |  |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2022-02-03):
[0001628280-21-021632:note_history:36]
Subsequent Event
On November 4, 2021, Lumentum and NeoPhotonics Corporation (“NeoPhotonics”) announced a merger agreement (the “Merger Agreement”). Under the terms of the Merger Agreement, NeoPhotonics stockholders will receive $16.00 per share in cash for each NeoPhotonics share they own. This equates to a total transaction price of approximately $918 million. Lumentum will provide up to $50 million in interim debt financing to NeoPhotonics to help fund capital expenditures and increased working capital associated with NeoPhotonics’ growth plans. The cash consideration will be funded from the combined company’s balance sheet.

- removed (2022-02-03):
[0001628280-21-021632:note_history:37]
The Merger Agreement contains certain termination rights for both Lumentum and NeoPhotonics and provides that upon termination of the Merger Agreement under specified circumstances (including termination by NeoPhotonics to accept a superior proposal), NeoPhotonics may be required to pay Lumentum a termination fee of $27.5 million. The Merger Agreement further provides that if the Merger Agreement is terminated for failure to obtain antitrust approval, Lumentum may be required to pay NeoPhotonics a termination fee of $55.1 million; and if Lumentum takes certain specified actions, (including entering into any definitive agreement for an acquisition by stock purchase, merger, consolidation, amalgamation, purchase of assets, license or otherwise of any ownership interest or assets of any Person) that cause a material delay in, or results in the failure of, the consummation of the Merger, Lumentum may be required to pay NeoPhotonics an additional termination fee of $36.7 million.
The Boards of Directors of Lumentum and NeoPhotonics have unanimously approved the transaction and the Merger Agreement. The transaction is subject to customary closing conditions, including the absence of certain legal impediments, the expiration or termination of the required waiting periods under the Hart-Scott-Rodino Antitrust Improvements Act of 1976, as amended, receipt of any required antitrust and regulatory approvals, and approval by the holders of a majority of the outstanding shares of NeoPhotonics common stock. The transaction is not subject to any financing condition. The transaction is expected to be completed in the second half of calendar year 2022.
