# LITE MD&A — 0001633978-18-000030


## mdna

[0001633978-18-000030:mdna:1]
[same as prior period, unchanged from 0001628280-18-001086:mdna:1]

[0001633978-18-000030:mdna:2]
[same as prior period, unchanged from 0001628280-18-001086:mdna:2]

[0001633978-18-000030:mdna:3]
[same as prior period, unchanged from 0001628280-18-001086:mdna:3]

[0001633978-18-000030:mdna:4]
[same as prior period, unchanged from 0001628280-18-001086:mdna:4]

[0001633978-18-000030:mdna:5]
[same as prior period, unchanged from 0001628280-18-001086:mdna:5]

[0001633978-18-000030:mdna:6]
On March 11, 2018, we entered into the Merger Agreement with Oclaro, which was unanimously approved by the boards of directors of both companies. Pursuant to the terms of the Merger Agreement, we will acquire all outstanding shares of Oclaro common stock in exchange for consideration of $5.60 in cash and 0.0636 shares of our common stock for each share of Oclaro common stock. The total transaction consideration was approximately $1.8 billion as of the date of the Merger Agreement. Oclaro stockholders will own approximately 16% of the combined company. The Merger Agreement contains certain termination rights for both Lumentum and Oclaro. The Merger Agreement further provides that upon termination of the Merger Agreement under specified circumstances relating to failure to obtain regulatory approvals, we may be required to pay Oclaro a termination fee of $80 million.

[0001633978-18-000030:mdna:7]
The total transaction consideration will be funded by a combination of cash from the combined company of approximately $416 million, $550 million in new debt, and $859 million in Lumentum common stock.

[0001633978-18-000030:mdna:8]
Lumentum entered into a commitment letter with Deutsche Bank, pursuant to which, subject to the terms and conditions set forth therein, Deutsche Bank has committed to provide a senior secured term loan facility in an aggregate principal amount of $550 million, with a provision for additional senior secured term loans in an aggregate principal amount not to exceed $250 million.

[0001633978-18-000030:mdna:9]
The transaction is subject to the approval of Oclaro stockholders and customary regulatory approval. The transaction is not subject to any financing condition. The timing of close is subject to customary closing conditions and is expected to be in the second half of calendar 2018.

[0001633978-18-000030:mdna:10]
[same as prior period, unchanged from 0001628280-18-001086:mdna:6]

[0001633978-18-000030:mdna:11]
[same as prior period, unchanged from 0001628280-18-001086:mdna:7]

[0001633978-18-000030:mdna:12]
[same as prior period, unchanged from 0001628280-18-001086:mdna:8]

[0001633978-18-000030:mdna:13]
[same as prior period, unchanged from 0001628280-18-001086:mdna:9]

[0001633978-18-000030:mdna:14]
[same as prior period, unchanged from 0001628280-18-001086:mdna:10]

[0001633978-18-000030:mdna:15]
[same as prior period, unchanged from 0001628280-18-001086:mdna:11]

[0001633978-18-000030:mdna:16]
[same as prior period, unchanged from 0001628280-18-001086:mdna:12]

[0001633978-18-000030:mdna:17]
[same as prior period, unchanged from 0001628280-18-001086:mdna:13]

[0001633978-18-000030:mdna:18]
[same as prior period, unchanged from 0001628280-18-001086:mdna:17]

[0001633978-18-000030:mdna:19]
• Goodwill

[0001633978-18-000030:mdna:20]
During the first quarter of fiscal 2018, the following policies were removed from the list of critical accounting policies and estimates:

[0001633978-18-000030:mdna:21]
[same as prior period, unchanged from 0001628280-18-001086:mdna:15]

[0001633978-18-000030:mdna:22]
[same as prior period, unchanged from 0001628280-18-001086:mdna:16]

[0001633978-18-000030:mdna:23]
[same as prior period, unchanged from 0001628280-18-001086:mdna:19]

[0001633978-18-000030:mdna:24]
[same as prior period, unchanged from 0001628280-18-001086:mdna:20]

[0001633978-18-000030:mdna:25]
• Business Combinations

[0001633978-18-000030:mdna:26]
• Goodwill and Intangible Assets

[0001633978-18-000030:mdna:27]
On March 11, 2018, we entered into a Merger Agreement with Oclaro, which was unanimously approved by the boards of directors of both companies. The transaction is subject to customary closing conditions and is expected to close in the second half of calendar 2018. We have added Business Combinations and Goodwill to our critical accounting policies and estimates in the third quarter of fiscal 2018.

[0001633978-18-000030:mdna:28]
Business Combinations

[0001633978-18-000030:mdna:29]
In accordance with the guidance for business combinations, we determine whether a transaction or other event is a business combination, which requires that the assets acquired and liabilities assumed constitute a business. Each business combination is then accounted for by applying the acquisition method. If the assets acquired are not a business, we account for the transaction or other event as an asset acquisition. Under both methods, we recognize the identifiable assets acquired, the liabilities assumed, and any noncontrolling interest in the acquired entity. In addition, for transactions that are business combinations, we evaluate the existence of goodwill or a gain from a bargain purchase. We capitalize acquisition-related costs and fees associated with asset acquisitions and immediately expense acquisition-related costs and fees associated with business combinations.

[0001633978-18-000030:mdna:30]
We allocate the fair value of purchase consideration to the tangible assets acquired, liabilities assumed and intangible assets acquired based on their estimated fair values. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. When determining the fair values of assets acquired and liabilities assumed, we make significant estimates and assumptions, especially with respect to intangible assets. Critical estimates in valuing certain intangible assets include, but are not limited to, future expected cash flows from customer relationships and acquired developed technology and discount rates. Our estimates of fair value are based upon assumptions believed to be reasonable, but which are inherently uncertain and unpredictable and, as a result, actual results may differ materially from estimates. Other estimates associated with the accounting for acquisitions may change as additional information becomes available regarding the assets acquired and liabilities assumed. Any change in facts and circumstances that existed as of the acquisition date and impacts our preliminary estimates is recorded to goodwill if identified within the measurement period. Subsequent to the measurement period or our final determination of fair value of assets and liabilities whichever is earlier the adjustments will affect our earnings.

[0001633978-18-000030:mdna:31]
In addition, we estimate the economic lives of certain acquired assets and these lives are used to calculate depreciation and amortization expense. If our estimates of the economic lives change, depreciation or amortization expenses could be accelerated or slowed.

[0001633978-18-000030:mdna:32]
In many cases, the accounting treatment of a particular transaction is specifically dictated by GAAP and does not require management’s judgment in its application. There are also areas in which our judgment in selecting among available alternatives would not produce a materially different result. Our senior management has reviewed our critical accounting policies and related disclosures with the Audit Committee of our board of directors.

[0001633978-18-000030:mdna:33]
Goodwill

[0001633978-18-000030:mdna:34]
Goodwill represents the excess of the purchase price of an acquired business over the fair value of the identifiable assets acquired and liabilities assumed. We test for impairment of goodwill on an annual basis in the fourth quarter and at any other time when events occur or circumstances indicate that the carrying amount of goodwill may not be recoverable.

[0001633978-18-000030:mdna:35]
An entity has the option to first assess qualitative factors to determine whether it is necessary to perform the two-step quantitative goodwill impairment test. If an entity determines that as a result of the qualitative assessment that it is more likely than not (i.e., greater than 50% likelihood) that the fair value of a reporting unit is less than its carrying amount, then the quantitative test is required. Otherwise, no further testing is required. The two-step quantitative goodwill impairment test requires us to estimate the fair value of our reporting units. If the carrying value of a reporting unit exceeds its fair value, the goodwill of that reporting unit is potentially impaired and we proceed to step two of the impairment analysis. In step two of the analysis, we measure and record an impairment loss equal to the excess of the carrying value of the reporting unit’s goodwill over its implied fair value, if any.

[0001633978-18-000030:mdna:36]
Application of the goodwill impairment test requires judgments, including: identification of the reporting units, assigning assets and liabilities to reporting units, assigning goodwill to reporting units, a qualitative assessment to determine whether there are any impairment indicators, and determining the fair value of each reporting unit. We estimate the fair value of a reporting unit using market approach, income approach or a combination of market and income approach. Significant estimates in the market approach include: identifying similar companies with comparable business factors such as size, growth, profitability, risk and return on investment, and assessing comparable revenue and operating income multiples in estimating the fair value of the reporting unit. Significant estimates in the income approach include: future cash flows, discount rates.

[0001633978-18-000030:mdna:37]
We base our estimates on historical experience and on various assumptions about the future that we believe are reasonable based on available information. Unanticipated events and circumstances may occur that affect the accuracy of our assumptions, estimates and judgments. For example, if the price of our common stock were to significantly decrease combined with other adverse changes in market conditions, thus indicating that the underlying fair value of our reporting units may have decreased, we might be required to reassess the value of our goodwill in the period such circumstances were identified.

[0001633978-18-000030:mdna:38]
Recently Issued Accounting Pronouncements

[0001633978-18-000030:mdna:39]
Refer to “Note 2. Recently Issued Accounting Pronouncements” in the Notes to Unaudited Condensed Consolidated Financial Statements.

[0001633978-18-000030:mdna:40]
36

[0001633978-18-000030:mdna:41]
[same as prior period, unchanged from 0001628280-18-001086:mdna:24]

[0001633978-18-000030:mdna:42]
[same as prior period, unchanged from 0001628280-18-001086:mdna:25]

[0001633978-18-000030:mdna:43]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |
| Segment net revenue: |  |  |  |  |  |  |  |
| OpComms | 82.4 | % |  | 84.5 | % |  | 86.0 | % |  | 86.1 | % |
| Lasers | 17.6 |  |  | 15.5 |  |  | 14.0 |  |  | 13.9 |  |
| Net revenue | 100.0 |  |  | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of sales | 67.3 |  |  | 67.2 |  |  | 64.2 |  |  | 67.1 |  |
| Amortization of acquired developed technologies | 0.3 |  |  | 0.7 |  |  | 0.3 |  |  | 0.7 |  |
| Gross profit | 32.5 |  |  | 32.1 |  |  | 35.6 |  |  | 32.2 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 12.8 |  |  | 14.6 |  |  | 12.5 |  |  | 14.5 |  |
| Selling, general and administrative | 11.1 |  |  | 11.0 |  |  | 10.1 |  |  | 10.8 |  |
| Restructuring and related charges | — |  |  | 1.2 |  |  | 0.4 |  |  | 1.3 |  |
| Total operating expenses | 23.9 |  |  | 26.8 |  |  | 23.0 |  |  | 26.6 |  |
| Income from operations | 8.5 |  |  | 5.3 |  |  | 12.6 |  |  | 5.6 |  |
| Unrealized loss on derivative liabilities | (6.9 | ) |  | (22.1 | ) |  | (0.9 | ) |  | (9.6 | ) |
| Interest and other income (expense), net | (0.7 | ) |  | (0.5 | ) |  | (0.9 | ) |  | (0.2 | ) |
| Income (loss) before income taxes | 0.9 |  |  | (17.3 | ) |  | 10.7 |  |  | (4.2 | ) |
| Provision for (benefit from) income taxes | — |  |  | 4.5 |  |  | (11.9 | ) |  | 2.0 |  |
| Net income (loss) | 0.9 | % |  | (21.8 | )% |  | 22.7 | % |  | (6.2 | )% |

[0001633978-18-000030:mdna:44]
Financial Data for the three and nine months ended March 31, 2018 and April 1, 2017

[0001633978-18-000030:mdna:45]
[same as prior period, unchanged from 0001628280-18-001086:mdna:29]

[0001633978-18-000030:mdna:46]
|  | Three Months Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | March 31, 2018 |  | April 1, 2017 |  | Change |  | Percentage Change |  | March 31, 2018 |  | April 1, 2017 |  | Change |  | Percentage Change |
| Segment net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| OpComms | $ | 246.3 |  |  | $ | 216.1 |  |  | $ | 30.2 |  |  | 14.0 | % |  | $ | 814.3 |  |  | $ | 671.0 |  |  | $ | 143.3 |  |  | 21.4 | % |
| Lasers | 52.5 |  |  | 39.7 |  |  | 12.8 |  |  | 32.2 |  |  | 132.3 |  |  | 107.9 |  |  | 24.4 |  |  | 22.6 |  |
| Net revenue | $ | 298.8 |  |  | $ | 255.8 |  |  | $ | 43.0 |  |  | 16.8 | % |  | $ | 946.6 |  |  | $ | 778.9 |  |  | $ | 167.7 |  |  | 21.5 | % |
| Gross profit | $ | 97.0 |  |  | $ | 82.1 |  |  | $ | 14.9 |  |  | 18.1 | % |  | $ | 336.6 |  |  | $ | 250.8 |  |  | $ | 85.8 |  |  | 34.2 | % |
| Gross margin | 32.5 | % |  | 32.1 | % |  |  |  |  |  | 35.6 | % |  | 32.2 | % |  |  |  |  |
| Research and development | $ | 38.2 |  |  | $ | 37.3 |  |  | $ | 0.9 |  |  | 2.4 | % |  | $ | 118.3 |  |  | $ | 112.9 |  |  | $ | 5.4 |  |  | 4.8 | % |
| Percentage of net revenue | 12.8 | % |  | 14.6 | % |  |  |  |  |  | 12.5 | % |  | 14.5 | % |  |  |  |  |
| Selling, general and administrative | $ | 33.2 |  |  | $ | 28.1 |  |  | $ | 5.1 |  |  | 18.1 | % |  | $ | 95.5 |  |  | $ | 84.2 |  |  | $ | 11.3 |  |  | 13.4 | % |
| Percentage of net revenue | 11.1 | % |  | 11.0 | % |  |  |  |  |  | 10.1 | % |  | 10.8 | % |  |  |  |  |
| Restructuring and related charges | $ | 0.1 |  |  | $ | 3.1 |  |  | $ | (3.0 | ) |  | (96.8 | )% |  | $ | 3.8 |  |  | $ | 10.0 |  |  | $ | (6.2 | ) |  | (62.0 | )% |
| Percentage of net revenue | — | % |  | 1.2 | % |  |  |  |  |  | 0.4 | % |  | 1.3 | % |  |  |  |  |

[0001633978-18-000030:mdna:47]
[same as prior period, unchanged from 0001628280-18-001086:mdna:31]

[0001633978-18-000030:mdna:48]
Net revenue increased by $43.0 million, or 16.8%, during the three months ended March 31, 2018 compared to the three months ended April 1, 2017. OpComms net revenue increased by $30.2 million, or 14.0%, during the three months ended March 31, 2018 compared to the three months ended April 1, 2017, driven by increased sales of Consumer and Industrial products of $75.2 million, primarily 3D sensing. This was partially offset by decreased sales of Telecom and Datacom products of $45.0 million. Lasers net revenue increased by $12.8 million, or 32.2%, during the three months ended March 31, 2018 compared to the three months ended April 1, 2017, primarily due to increased sales of solid state laser products.

[0001633978-18-000030:mdna:49]
Net revenue increased by $167.7 million, or 21.5%, during the nine months ended March 31, 2018 compared to the nine months ended April 1, 2017. OpComms net revenue increased by $143.3 million, or 21.4%, during the nine months ended March 31, 2018 compared to the nine months ended April 1, 2017, driven by increased sales of Consumer and Industrial products of $326.1 million, primarily 3D sensing. This was partially offset by decreased sales of Telecom and Datacom products of $182.8 million. Lasers net revenue increased by $24.4 million, or 22.6%, during the nine months ended March 31, 2018 compared to the nine months ended April 1, 2017, primarily due to increased sales of solid state laser products.

[0001633978-18-000030:mdna:50]
38

[0001633978-18-000030:mdna:51]
During the three and nine months ended March 31, 2018 and April 1, 2017, net revenue generated from a single end customer which represented 10% or greater of total net revenue is summarized as follows:

[0001633978-18-000030:mdna:52]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |
| APPLE | 25.0 | % |  | * |  |  | 33.0 | % |  | * |  |
| HUAWEI | 12.0 | % |  | 12.0 | % |  | 11.0 | % |  | 18.0 | % |
| CIENA | 13.0 | % |  | 27.0 | % |  | * |  |  | 20.0 | % |
| CISCO | * |  |  | * |  |  | * |  |  | 12.0 | % |
| *Represents less than 10% of total net revenue |  |  |  |  |  |  |  |

[0001633978-18-000030:mdna:53]
[same as prior period, unchanged from 0001628280-18-001086:mdna:40]

[0001633978-18-000030:mdna:54]
We operate in three geographic regions: Americas, Asia-Pacific and EMEA. Net revenue is assigned to the geographic region and country where our product is initially shipped. For example, certain customers may request shipment of our product to a contract manufacturer in one country, however, the location of the end customers may differ. The following table presents net revenue by the three geographic regions we operate in and net revenue from countries that represented 10% or more of our total net revenue (in millions, except for percentages):

[0001633978-18-000030:mdna:55]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 26.8 |  |  | 9.0 | % |  | $ | 34.7 |  |  | 13.6 | % |  | $ | 86.3 |  |  | 9.1 | % |  | $ | 106.2 |  |  | 13.6 | % |
| Mexico | 41.7 |  |  | 14.0 |  |  | 70.0 |  |  | 27.4 |  |  | 97.1 |  |  | 10.3 |  |  | 158.5 |  |  | 20.3 |  |
| Other Americas | 1.5 |  |  | 0.5 |  |  | 1.5 |  |  | 0.6 |  |  | 5.7 |  |  | 0.6 |  |  | 7.4 |  |  | 1.0 |  |
| Total Americas | $ | 70.0 |  |  | 23.5 | % |  | $ | 106.2 |  |  | 41.6 | % |  | $ | 189.1 |  |  | 20.0 | % |  | $ | 272.1 |  |  | 34.9 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 38.7 |  |  | 13.0 | % |  | $ | 47.2 |  |  | 18.5 | % |  | $ | 133.3 |  |  | 14.1 | % |  | $ | 181.2 |  |  | 23.3 | % |
| China | 47.3 |  |  | 15.8 |  |  | 8.7 |  |  | 3.4 | % |  | 66.8 |  |  | 7.1 | % |  | 28.3 |  |  | 3.6 | % |
| Japan | 34.1 |  |  | 11.4 |  |  | 25.9 |  |  | 10.1 |  |  | 157.6 |  |  | 16.6 |  |  | 78.5 |  |  | 10.1 |  |
| South Korea | 28.8 |  |  | 9.6 |  |  | 2.4 |  |  | 0.9 |  |  | 126.3 |  |  | 13.3 |  |  | 3.5 |  |  | 0.4 |  |
| Other Asia-Pacific | 56.6 |  |  | 18.9 |  |  | 35.3 |  |  | 13.8 |  |  | 199.3 |  |  | 21.1 |  |  | 133.0 |  |  | 17.1 |  |
| Total Asia-Pacific | $ | 205.5 |  |  | 68.7 | % |  | $ | 119.5 |  |  | 46.7 | % |  | $ | 683.3 |  |  | 72.2 | % |  | $ | 424.5 |  |  | 54.5 | % |
| EMEA | $ | 23.3 |  |  | 7.8 | % |  | $ | 30.1 |  |  | 11.8 | % |  | $ | 74.2 |  |  | 7.8 | % |  | $ | 82.3 |  |  | 10.6 | % |
| Total net revenue | $ | 298.8 |  |  |  |  | $ | 255.8 |  |  |  |  | $ | 946.6 |  |  |  |  | $ | 778.9 |  |  |  |

[0001633978-18-000030:mdna:56]
During the three months ended March 31, 2018 and April 1, 2017, net revenue from customers outside the United States, based on customer shipping location, represented 91.0% and 86.4% of net revenue, respectively. During the nine months ended March 31, 2018 and April 1, 2017, net revenue from customers outside the United States, based on customer shipping location, represented 90.9% and 86.4% of net revenue, respectively.

[0001633978-18-000030:mdna:57]
Our net revenue is primarily denominated in U.S. dollars, including our net revenue from customers outside the United States as presented above. We expect revenue from customers outside of the United States to continue to be an important part of our overall net revenue and an increasing focus for net revenue growth opportunities. However, regulatory and enforcement actions by U.S. and other governmental agencies, as well as changes in tax and trade policies and tariffs, may impact net revenue from customers outside the United States in future periods.

[0001633978-18-000030:mdna:58]
[same as prior period, unchanged from 0001628280-18-001086:mdna:45]

[0001633978-18-000030:mdna:59]
The following table summarizes segment gross margin for the three and nine months ended March 31, 2018 and April 1, 2017 (in millions, except for percentages):

[0001633978-18-000030:mdna:60]
|  |  |  |  |  | Gross Margin |  |  |  | Gross Margin |
|  | Three Months Ended |  | Three Months Ended |  | Nine Months Ended |  | Nine Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |
| OpComms | $ | 83.1 |  |  | $ | 71.5 |  |  | 33.7 | % |  | 33.1 | % |  | $ | 317.1 |  |  | $ | 229.2 |  |  | 38.9 | % |  | 34.2 | % |
| Lasers | 25.4 |  |  | 16.4 |  |  | 48.4 | % |  | 41.3 | % |  | 55.9 |  |  | 44.8 |  |  | 42.3 | % |  | 41.5 | % |
| Segment total | $ | 108.5 |  |  | $ | 87.9 |  |  | 36.3 | % |  | 34.4 | % |  | $ | 373.0 |  |  | $ | 274.0 |  |  | 39.4 | % |  | 35.2 | % |
| Unallocated corporate items (1) | (11.5 | ) |  | (5.8 | ) |  |  |  |  |  | (36.4 | ) |  | (23.2 | ) |  |  |  |  |
| Total | $ | 97.0 |  |  | $ | 82.1 |  |  | 32.5 | % |  | 32.1 | % |  | $ | 336.6 |  |  | $ | 250.8 |  |  | 35.6 | % |  | 32.2 | % |

[0001633978-18-000030:mdna:61]
(1) The unallocated corporate items for the years presented include the effects of amortization of acquired developed technology intangible assets, share-based compensation and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments. The increase in unallocated corporate items during the three months ended March 31, 2018 compared to the three months ended April 1, 2017, primarily relates to set-up costs of our facility in Thailand, including costs of transferring product lines to Thailand. The increase during the nine months ended March 31, 2018 compared to the nine months ended April 1, 2017, primarily relates to set-up costs of our facility in Thailand, including costs of transferring product lines to Thailand, as well as inventory write-downs due to canceled programs not allocated to the segments.

[0001633978-18-000030:mdna:62]
[same as prior period, unchanged from 0001628280-18-001086:mdna:49]

[0001633978-18-000030:mdna:63]
Gross margin during the three months ended March 31, 2018 increased by 0.4% to 32.5% from 32.1% in the same period a year ago. This increase was primarily due to increased sales in our 3D sensing and lasers products. The increase was partially offset by set-up costs of our facility in Thailand, including costs of transferring product lines to Thailand.

[0001633978-18-000030:mdna:64]
Gross margin during the nine months ended March 31, 2018 increased by 3.4% to 35.6% from 32.2% in the same period a year ago. This increase was primarily due to increased sales in our 3D sensing and lasers products. The increase was partially offset by underutilized capacity costs due to the decline in Telecom and Datacom demand, higher write-downs of excess and obsolete inventory, as well as set-up costs of our facility in Thailand, including costs of transferring product lines to Thailand.

[0001633978-18-000030:mdna:65]
[same as prior period, unchanged from 0001628280-18-001086:mdna:52]

[0001633978-18-000030:mdna:66]
[same as prior period, unchanged from 0001628280-18-001086:mdna:53]

[0001633978-18-000030:mdna:67]
[same as prior period, unchanged from 0001628280-18-001086:mdna:54]

[0001633978-18-000030:mdna:68]
OpComms gross margin during the three months ended March 31, 2018 increased by 0.6% to 33.7% from 33.1% in the same period a year ago. This increase was primarily due to increased sales of our 3D sensing products.

[0001633978-18-000030:mdna:69]
OpComms gross margin during the nine months ended March 31, 2018 increased by 4.7% to 38.9% from 34.2% in the same period a year ago. This increase was primarily due to increased sales of our 3D sensing products, offset partially by underutilization of manufacturing capacity for our Telecom and Datacom products.

[0001633978-18-000030:mdna:70]
[same as prior period, unchanged from 0001628280-18-001086:mdna:57]

[0001633978-18-000030:mdna:71]
Lasers gross margin during the three months ended March 31, 2018 increased by 7.1% to 48.4% from 41.3% in the same period a year ago. This increase was primarily due to increased sales of solid state lasers products.

[0001633978-18-000030:mdna:72]
Lasers gross margin during the nine months ended March 31, 2018 increased by 0.8% to 42.3% from 41.5% in the same period a year ago. This increase was primarily due to increased sales of solid state lasers products, offset partially by unfavorable product mix and a write-down of excess inventory.

[0001633978-18-000030:mdna:73]
[same as prior period, unchanged from 0001628280-18-001086:mdna:60]

[0001633978-18-000030:mdna:74]
R&D expense increased by $0.9 million, or 2.4%, during the three months ended March 31, 2018 compared to the three months ended April 1, 2017. The increase in R&D expense was primarily due to an increase in stock-based compensation of $0.6 million.

[0001633978-18-000030:mdna:75]
R&D expense increased by $5.4 million, or 4.8%, during the nine months ended March 31, 2018 compared to the nine months ended April 1, 2017. The increase in R&D expense was primarily due to an increase in stock-based compensation of $1.7 million and an increase in payroll related expense of $2.5 million.

[0001633978-18-000030:mdna:76]
[same as prior period, unchanged from 0001628280-18-001086:mdna:63]

[0001633978-18-000030:mdna:77]
[same as prior period, unchanged from 0001628280-18-001086:mdna:64]

[0001633978-18-000030:mdna:78]
SG&A expense increased by $5.1 million, or 18.1%, during the three months ended March 31, 2018 compared to the three months ended April 1, 2017. The increase was primarily attributable to increases in stock based compensation of $1.8 million and acquisition-related costs of $2.7 million.

[0001633978-18-000030:mdna:79]
SG&A expense increased by $11.3 million, or 13.4%, during the nine months ended March 31, 2018 compared to the nine months ended April 1, 2017. The increase was primarily attributable to increases in stock based compensation of $4.9 million, payroll related expense, which includes an increase in variable incentive compensation of $2.8 million, and acquisition-related costs of $2.7 million.

[0001633978-18-000030:mdna:80]
We may experience in the future, certain non-core expenses, such as mergers and acquisition-related expenses and litigation expenses, which could increase our SG&A expenses and potentially impact our profitability expectations in any particular quarter.

[0001633978-18-000030:mdna:81]
[same as prior period, unchanged from 0001628280-18-001086:mdna:68]

[0001633978-18-000030:mdna:82]
We have reduced costs through targeted restructuring efforts intended to consolidate our operations, rationalize the manufacturing of our products and align our business in response to market conditions. Refer to “Note 13. Restructuring and Related Charges” in the Notes to Unaudited Condensed Consolidated Financial Statements.

[0001633978-18-000030:mdna:83]
During the three and nine months ended March 31, 2018, we recorded $0.1 million and $3.8 million, respectively, in restructuring and related charges in the condensed consolidated statements of operations, primarily attributable to costs to vacate facilities, temporary labor and employee related benefits, as well as costs for materials used in set up and production activities. We incurred no additional costs related to severance for the same periods.

[0001633978-18-000030:mdna:84]
During the three and nine months ended April 1, 2017, we recorded $3.1 million and $10.0 million, respectively, in restructuring and related charges in the condensed consolidated statements of operations. Of the $3.1 million and $10.0 million charges recorded during the three and nine months ended April 1, 2017, $0.4 million and $2.2 million, respectively, was related to severance, retention, lease termination costs, and employee benefits; and $2.7 million and $7.8 million, respectively, was related to other restructuring related charges which include relocation costs, temporary labor and employee related benefits, as well as costs for materials used in set up and production activities.

[0001633978-18-000030:mdna:85]
[same as prior period, unchanged from 0001628280-18-001086:mdna:72]

[0001633978-18-000030:mdna:86]
[same as prior period, unchanged from 0001628280-18-001086:mdna:73]

[0001633978-18-000030:mdna:87]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |
| Interest expense | $ | (4.6 | ) |  | $ | (1.1 | ) |  | $ | (13.6 | ) |  | $ | (1.1 | ) |
| Foreign exchange gains (losses), net | (0.1 | ) |  | (0.2 | ) |  | (0.8 | ) |  | 0.3 |  |
| Interest income | 2.5 |  |  | — |  |  | 5.7 |  |  | — |  |
| Other income (expense), net | 0.1 |  |  | (0.1 | ) |  | — |  |  | (0.6 | ) |
| Interest and other income (expense), net | $ | (2.1 | ) |  | $ | (1.4 | ) |  | $ | (8.7 | ) |  | $ | (1.4 | ) |

[0001633978-18-000030:mdna:88]
For the three and nine months ended March 31, 2018, interest and other income (expense) increased compared to the three and nine months ended April 1, 2017, driven by amortization of the debt discount on the 2024 Notes, partially offset by interest income on the short-term investments and cash equivalents. See “Note 10. Convertible Senior Notes” in the Notes to the Unaudited Condensed Consolidated Financial Statements for additional information on the 2024 Notes.

[0001633978-18-000030:mdna:89]
Unrealized Gain (Loss) on Derivative Liabilities

[0001633978-18-000030:mdna:90]
Unrealized loss on Series A Preferred Stock derivative liability amounted to $(20.7) million and $(8.6) million, respectively, for the three and nine months ended March 31, 2018 and $(17.9) million and $(35.8) million, respectively, for the three and nine months ended April 1, 2017. The change is primarily related to the change in the price of our underlying common stock and is reflected in the condensed consolidated statements of operations as “Unrealized gain (loss) on derivative liabilities”. For further discussion of our derivative liability, see “Note 11. Derivative Liability” in the Notes to Unaudited Condensed Consolidated Financial Statements.

[0001633978-18-000030:mdna:91]
Unrealized loss on the derivate liability from the 2024 Notes is also included in the “Unrealized gain (loss) on derivative liabilities” for the three and nine months ended April 1, 2017. On June 29, 2017, we met the requirements to account for the conversion option of the 2024 Notes as equity and the conversion option is no longer marked to market. Refer to “Note 10. Convertible Senior Notes” in the Notes to Unaudited Condensed Consolidated Financial Statements.

[0001633978-18-000030:mdna:92]
[same as prior period, unchanged from 0001628280-18-001086:mdna:79]

[0001633978-18-000030:mdna:93]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |
| Provision for (benefit from) income taxes | $ | — |  |  | $ | 11.6 |  |  | $ | (112.9 | ) |  | $ | 15.4 |  |

[0001633978-18-000030:mdna:94]
[same as prior period, unchanged from 0001628280-18-001086:mdna:81]

[0001633978-18-000030:mdna:95]
[same as prior period, unchanged from 0001628280-18-001086:mdna:82]

[0001633978-18-000030:mdna:96]
We recorded an immaterial tax benefit and a tax benefit of $112.9 million for the three and nine months ended March 31, 2018, respectively. Our tax benefit for the three months ended March 31, 2018 was less than $0.1 million primarily due to a benefit from foreign rate differential, excess windfall benefit from our stock-based compensation tax deduction, offset by the discrete impact of the non-deductible unrealized loss from the embedded derivatives for the Series A Preferred Stock. Our tax benefit for the nine months ended March 31, 2018 was primarily due to the release of our U.S. federal and certain state valuation allowances.  The benefit of this valuation allowance release was partially offset by a non-cash deferred expense associated with the change in the U.S. statutory rate as a result of the Tax Act (discussed further below) which was enacted during our second quarter of fiscal 2018.

[0001633978-18-000030:mdna:97]
We recorded a tax provision of $11.6 million and $15.4 million for the three and nine months ended April 1, 2017, respectively. Our tax provision for the three and nine months ended April 1, 2017 was primarily due to the discrete impact of the non-deductible unrealized loss from the embedded derivatives for the Series A Preferred Stock and the 2024 Notes, non-deductible stock-based compensation and partially offset by foreign rate differential, R&D tax credits and the utilization of U.S. deferred tax assets that were subject to a full valuation allowance.

[0001633978-18-000030:mdna:98]
[same as prior period, unchanged from 0001628280-18-001086:mdna:85]

[0001633978-18-000030:mdna:99]
As of each reporting date, we consider new evidence, both positive and negative, that could affect our view of the future realization of deferred tax assets. As of December 31, 2017, we determined that there is sufficient positive evidence to conclude that it is more-likely-than-not that the deferred tax assets are realizable. We, therefore, released the valuation allowance for the

[0001633978-18-000030:mdna:100]
U.S. federal and certain states and recognized a tax benefit of $207 million as a discrete item for the fiscal second quarter of 2018. Due to the weight of negative evidence, we continue to maintain a full valuation allowance on the California deferred tax assets.

[0001633978-18-000030:mdna:101]
[same as prior period, unchanged from 0001628280-18-001086:mdna:87]

[0001633978-18-000030:mdna:102]
[same as prior period, unchanged from 0001628280-18-001086:mdna:88]

[0001633978-18-000030:mdna:103]
[same as prior period, unchanged from 0001628280-18-001086:mdna:89]

[0001633978-18-000030:mdna:104]
[same as prior period, unchanged from 0001628280-18-001086:mdna:90]

[0001633978-18-000030:mdna:105]
The reduction in the U.S. federal statutory rate is expected to positively impact our federal cash tax liability.  However, the ultimate impact is subject to the effect of other complex provisions in the Tax Act (including BEAT and GILTI), which we are currently reviewing, and it is possible that any impact of BEAT and GILTI could significantly reduce the benefit of the reduction in the U.S. federal statutory rate. Due to the uncertain practical and technical application of many of these provisions, it is currently not possible to reliably estimate whether BEAT and GILTI will apply and, if so, how it would impact us. We will continue to analyze the Tax Act to assess the full effects on our financial results for the June 30, 2018 fiscal year-end.

[0001633978-18-000030:mdna:106]
As of March 31, 2018, we had $10.2 million of unrecognized tax benefits, which, if recognized, would affect the effective tax rate. We are subject to examination of income tax returns by various domestic and foreign tax authorities. The timing of resolutions and closures of tax audits is highly unpredictable. Given the uncertainty, it is reasonably possible that certain tax audits may be concluded within the next 12 months that could materially impact the balance of our gross unrecognized tax benefits. An estimate of the range of increase or decrease that could occur in the next twelve months cannot be made. However, the estimated impact to tax expense and net income from the resolution and closure of tax exams is not expected to be significant within the next 12 months.

[0001633978-18-000030:mdna:107]
We operate under a tax holiday in Thailand, which could be effective through fiscal year 2026, and may be extended if certain additional requirements are satisfied.  The tax holiday is conditional upon our meeting certain employment and investment thresholds. The tax holiday had insignificant impact on our foreign taxes and on net income per share (diluted) for fiscal year ended July 1, 2017 and for the nine months ended March 31, 2018.

[0001633978-18-000030:mdna:108]
For further discussion of our income tax provision, see “Note 14. Income Taxes” in the Notes to Unaudited Condensed Consolidated Financial Statements.

[0001633978-18-000030:mdna:109]
[same as prior period, unchanged from 0001628280-18-001086:mdna:94]

[0001633978-18-000030:mdna:110]
The following table summarizes our contractual obligations as of March 31, 2018, and the effect such obligations are expected to have on our liquidity and cash flow over the next five years (in millions):

[0001633978-18-000030:mdna:111]
|  | Payments due by period |
|  | Total |  | Less than 1 year |  | 1 - 3 years |  | 3 - 5 years |  | More than 5 years |
| Contractual Obligations |  |  |  |  |  |  |  |  |  |
| Asset retirement obligations | $ | 2.7 |  |  | $ | — |  |  | $ | 0.6 |  |  | $ | 0.8 |  |  | $ | 1.3 |  |
| Purchase obligations (1) | 187.1 |  |  | 186.7 |  |  | 0.4 |  |  | — |  |  | — |  |
| Operating lease obligations (1) | 36.8 |  |  | 11.9 |  |  | 16.0 |  |  | 6.8 |  |  | 2.1 |  |
| Capital lease obligation (1) | 12.6 |  |  | 11.7 |  |  | 0.9 |  |  | — |  |  | — |  |
| Pension plan contributions (2) | 0.6 |  |  | 0.6 |  |  | — |  |  | — |  |  |  |
| 0.25% Convertible Senior Notes due 2024 | 450.0 |  |  | — |  |  | — |  |  | — |  |  | 450.0 |  |
| Interest on 2024 Notes (3) | 6.1 |  |  | 1.1 |  |  | 2.2 |  |  | 2.2 |  |  | 0.6 |  |
| Acquisition contingencies (4) | 3.0 |  |  | — |  |  | 3.0 |  |  | — |  |  | — |  |
| Total | $ | 698.9 |  |  | $ | 212.0 |  |  | $ | 23.1 |  |  | $ | 9.8 |  |  | $ | 454.0 |  |

[0001633978-18-000030:mdna:112]
(1) Refer to “Note 16. Commitments and Contingencies” in the Notes to Unaudited Condensed Consolidated Financial Statements.

[0001633978-18-000030:mdna:113]
(2) Represents planned contributions to our pension plan. Although additional future contributions will be required, the amount and timing of these contributions will be affected by actuarial assumptions, the actual rate of returns on plan assets, the level of market interest rates, legislative changes, and the amount of voluntary contributions to the plan. Any contributions for the following fiscal year and later will depend on the value of the plan assets in the future and thus are uncertain. As such, we have not included any amounts beyond 1 year in the table above.

[0001633978-18-000030:mdna:114]
(3) Includes interest on our 0.25% Convertible Senior Notes due 2024 through September 2023 as we have the right to redeem the 2024 Notes in whole or in part at any time on or after March 15, 2024. Refer to “Note 10. Convertible Senior Notes” in the Notes to Unaudited Condensed Consolidated Financial Statements.

[0001633978-18-000030:mdna:115]
(4) Refer to “Note 8. Fair Value Measurements” in the Notes to Unaudited Condensed Consolidated Financial Statements.

[0001633978-18-000030:mdna:116]
[same as prior period, unchanged from 0001628280-18-001086:mdna:99]

[0001633978-18-000030:mdna:117]
As of March 31, 2018, our other non-current liabilities primarily relate to asset retirement obligations and pension which are presented in various lines in the preceding table.

[0001633978-18-000030:mdna:118]
As of March 31, 2018, our other non-current liabilities on the condensed consolidated balance sheet include $10.2 million of unrecognized tax benefit for uncertain tax positions. We are unable to reliably estimate the timing of future payments related to uncertain tax positions and therefore have excluded them from the preceding table.

[0001633978-18-000030:mdna:119]
[same as prior period, unchanged from 0001628280-18-001086:mdna:103]

[0001633978-18-000030:mdna:120]
[same as prior period, unchanged from 0001628280-18-001086:mdna:104]

[0001633978-18-000030:mdna:121]
[same as prior period, unchanged from 0001628280-18-001086:mdna:105]

[0001633978-18-000030:mdna:122]
[same as prior period, unchanged from 0001628280-18-001086:mdna:106]

[0001633978-18-000030:mdna:123]
[same as prior period, unchanged from 0001628280-18-001086:mdna:107]

[0001633978-18-000030:mdna:124]
As of March 31, 2018 and July 1, 2017, our cash and cash equivalents of $176.8 million and $272.9 million, respectively, were held predominantly in the United States. The total amount of cash outside the United States as of March 31, 2018 was $32.4 million, which was primarily held in Cayman Islands, Thailand, Japan, Canada, and China. Although the cash currently held in the United States as well as the cash generated in the United States from future operations is expected to cover our normal operating requirements, a substantial amount of additional cash could be required for other purposes, such as capital expenditures to support our business and growth, including costs associated with increasing internal manufacturing capabilities, such as our new Thailand facility, strategic transactions and partnerships, and acquisitions. Our intent is to indefinitely reinvest funds held outside the United States and our current plans do not demonstrate a need to repatriate them to fund our domestic operations. However, if in the future, we encounter a significant need for liquidity domestically or at a particular location that we cannot fulfill through borrowings, equity offerings, or other internal or external sources, or the cost to bring back the money is insignificant from a tax perspective, we may determine that cash repatriations are necessary. Repatriation could result in additional material taxes. These factors may cause us to have an overall tax rate higher than other companies or higher than our tax rates have been in the past. If conditions warrant, we may seek to obtain additional financing through debt or equity sources. To the extent we issue additional shares, our existing stockholders may be diluted. However, any such financing may not be available on terms favorable to us, or may not be available at all.

[0001633978-18-000030:mdna:125]
As of March 31, 2018, our consolidated balance of cash and cash equivalents decreased by $96.1 million, to $176.8 million from $272.9 million as of July 1, 2017. The decrease in cash and cash equivalents was mainly due to purchases of short-term investments, net of sales of $235.8 million and capital expenditures of $72.9 million, offset by cash provided by operating activities of $209.9 million during the nine months ended March 31, 2018.

[0001633978-18-000030:mdna:126]
[same as prior period, unchanged from 0001628280-18-001086:mdna:111]

[0001633978-18-000030:mdna:127]
Cash provided by operating activities was $209.9 million during the nine months ended March 31, 2018, primarily resulting from $214.6 million of net income, offset by $11.4 million of non-cash items (such as depreciation, stock-based compensation, amortization of intangibles, amortization of discount on the 2024 Notes, net of the release of the valuation allowance), and $6.7 million of changes in our operating assets and liabilities. Changes in our operating assets and liabilities related primarily to an increase in accrued expenses and other current and non-current liabilities of $12.9 million offset by a decrease in accounts payable of $15.9 million.

[0001633978-18-000030:mdna:128]
Cash provided by operating activities was $71.9 million during the nine months ended April 1, 2017, primarily resulting from $47.6 million of net loss and $139.5 million of non-cash items such as depreciation, stock-based compensation, amortization of intangibles, unrealized loss on derivative liabilities, offset by changes in excess tax benefit associated with stock-based compensation, and changes in operating assets and liabilities of $20.0 million. Changes in our operating assets and liabilities related primarily to an increase in accounts receivable of $14.9 million due to the timing of collections, an increase in inventories of $14.0 million, an increase in accounts payable of $18.2 million related to such non-cash items as $15.2 million unpaid property, plant and equipment and $0.9 million issuance costs in accounts payable, offset by an increase in accrued expenses and other current and non-current liabilities of $15.1 million and an increase in income taxes, net of $15.4 million.

[0001633978-18-000030:mdna:129]
[same as prior period, unchanged from 0001628280-18-001086:mdna:114]

[0001633978-18-000030:mdna:130]
Cash used in investing activities of $308.7 million during the nine months ended March 31, 2018 was primarily attributable to capital expenditures of $72.9 million and purchases of short-term investments, net of sales of $235.8 million.

[0001633978-18-000030:mdna:131]
Cash used in investing activities of $105.1 million during the nine months ended April 1, 2017 was primarily attributable to capital expenditures of $100.0 million.

[0001633978-18-000030:mdna:132]
[same as prior period, unchanged from 0001628280-18-001086:mdna:117]

[0001633978-18-000030:mdna:133]
During the nine months ended March 31, 2018 and April 1, 2017, cash provided by financing activities of $1.9 million and $454.7 million, respectively, resulted primarily from the issuance of common stock under the employee stock plan of $4.4 million and the issuance of the 2024 Notes of $443.2 million.

[0001633978-18-000030:mdna:134]
[same as prior period, unchanged from 0001628280-18-001086:mdna:119]

[0001633978-18-000030:mdna:135]
We believe that our cash and cash equivalents as of March 31, 2018, and cash flows from our operating activities will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months. However, if market conditions are favorable, we may evaluate alternatives to opportunistically pursue additional financing.

[0001633978-18-000030:mdna:136]
[same as prior period, unchanged from 0001628280-18-001086:mdna:121]

[0001633978-18-000030:mdna:137]
[same as prior period, unchanged from 0001628280-18-001086:mdna:122]

[0001633978-18-000030:mdna:138]
[same as prior period, unchanged from 0001628280-18-001086:mdna:123]

[0001633978-18-000030:mdna:139]
[same as prior period, unchanged from 0001628280-18-001086:mdna:124]

[0001633978-18-000030:mdna:140]
[same as prior period, unchanged from 0001628280-18-001086:mdna:125]

[0001633978-18-000030:mdna:141]
[same as prior period, unchanged from 0001628280-18-001086:mdna:126]

[0001633978-18-000030:mdna:142]
[same as prior period, unchanged from 0001628280-18-001086:mdna:127]

[0001633978-18-000030:mdna:143]
[same as prior period, unchanged from 0001628280-18-001086:mdna:128]

[0001633978-18-000030:mdna:144]
[same as prior period, unchanged from 0001628280-18-001086:mdna:129]

[0001633978-18-000030:mdna:145]
[same as prior period, unchanged from 0001628280-18-001086:mdna:130]

[0001633978-18-000030:mdna:146]
[same as prior period, unchanged from 0001628280-18-001086:mdna:131]

[0001633978-18-000030:mdna:147]
[same as prior period, unchanged from 0001628280-18-001086:mdna:132]

[0001633978-18-000030:mdna:148]
[same as prior period, unchanged from 0001628280-18-001086:mdna:133]

[0001633978-18-000030:mdna:149]
In March 2018, we entered into the Merger Agreement with Oclaro. According to the Merger Agreement, we will acquire all outstanding shares of Oclaro common stock in exchange for consideration of $5.60 in cash and 0.0636 shares of our common stock for each share of Oclaro common stock. The total transaction consideration was approximately $1.8 billion as of the date of the Merger Agreement and and will be funded by a combination of cash from the combined company of approximately $416 million, $550 million in new debt, and $859 million in Lumentum common stock.  We have entered into a commitment letter with Deutsche Bank, pursuant to which, subject to the terms and conditions set forth therein, Deutsche Bank has committed to provide a senior secured term loan facility in an aggregate principal amount of $550 million, with a provision for additional senior secured term loans in an aggregate principal amount not to exceed $250 million.

[0001633978-18-000030:mdna:150]
46
