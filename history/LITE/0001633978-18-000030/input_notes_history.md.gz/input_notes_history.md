# LITE note change history — 0001628280-18-001086 → 0001633978-18-000030


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-05-02):
[0001633978-18-000030:note_history:1]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2026. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. As of March 31, 2018, the future minimum annual lease payments under non-cancellable operating leases were as follows (in millions):
  (was, 2018-02-06, similarity 0.9838):
[0001628280-18-001086:note_history:1]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2026. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. As of December 30, 2017, the future minimum annual lease payments under non-cancellable operating leases were as follows (in millions):

- changed (2018-05-02):
[0001633978-18-000030:note_history:2]
During the three and nine months ended March 31, 2018, rental expense relating to building and equipment was $2.8 million and $9.2 million, respectively. During the three and nine months ended April 1, 2017, rental expense relating to building and equipment was $2.6 million and $7.0 million, respectively.
  (was, 2018-02-06, similarity 0.8339):
[0001628280-18-001086:note_history:2]
During the three and six months ended December 30, 2017, rental expense relating to building and equipment was $3.0 million and $6.4 million, respectively. During the three and six months ended December 31, 2016, rental expense relating to building and equipment was $2.2 million and $4.4 million, respectively.

- changed (2018-05-02):
[0001633978-18-000030:note_history:3]
As of March 31, 2018, equipment acquired under a capital lease agreement was $15.6 million. Our capital lease asset is included in property, plant and equipment, net in our condensed consolidated balance sheets as of March 31, 2018. Amortization expense on this capital lease asset is recorded as depreciation expense and is included in cost of sales in our condensed consolidated statements of operations for the three and nine months ended March 31, 2018. Our capital lease obligation is recorded at the lesser of the estimated fair market value of the leased property or the net present value of the aggregate future minimum lease payments and is included in other current liabilities and other non-current liabilities in our condensed consolidated balance sheets as of March 31, 2018. Refer to “Note 6. Balance Sheet Details” for capital lease obligation amounts in other current liabilities and other non-current liabilities. Interest on these obligations is included in interest expense in our condensed consolidated statements of operations.
  (was, 2018-02-06, similarity 0.7945):
[0001628280-18-001086:note_history:3]
As of December 30, 2017, equipment acquired under a capital lease agreement was $15.6 million. Our capital lease asset is included in property, plant and equipment, net in our condensed consolidated balance sheets as of December 30, 2017. Amortization expense on this capital lease asset is recorded as depreciation expense and is included in cost of sales in our condensed consolidated statements of operations for the three and six months ended December 30, 2017. Our capital lease obligation is recorded at the lesser of the estimated fair market value of the leased property or the net present value of the aggregate future minimum lease payments and is included in other current liabilities and other non-current liabilities in our condensed consolidated balance sheets as of December 30, 2017. Refer to “Note 5. Balance Sheet Details” for further details. Interest on these obligations is included in interest expense in our condensed consolidated statements of operations.

- changed (2018-05-02):
[0001633978-18-000030:note_history:4]
As of March 31, 2018 the future minimum annual lease payments under our capital lease were as follows (in millions):
  (was, 2018-02-06, similarity 0.96):
[0001628280-18-001086:note_history:4]
As of December 30, 2017 the future minimum annual lease payments under our capital lease were as follows (in millions):

- changed (2018-05-02):
[0001633978-18-000030:note_history:5]
| Fiscal Years |  |
| Remainder of 2018 | $ | 4.7 |  |
| 2019 | 7.5 |  |
| 2020 | 0.4 |  |
| Total minimum capital lease payments | $ | 12.6 |  |
| Less: amount representing interest | $ | (0.3 | ) |
| Present value of capital lease obligation | $ | 12.3 |  |
  (was, 2018-02-06, similarity 0.9563):
[0001628280-18-001086:note_history:5]
| Fiscal Years |  |
| Remainder of 2018 | $ | 7.0 |  |
| 2019 | 7.5 |  |
| 2020 | 0.4 |  |
| Thereafter | — |  |
| Total minimum capital lease payments | $ | 14.9 |  |
| Less: amount representing interest | $ | (0.4 | ) |
| Present value of capital lease obligation | $ | 14.5 |  |

- changed (2018-05-02):
[0001633978-18-000030:note_history:6]
The future interest and principal payments related to the 2024 Notes are as follows as of March 31, 2018:
  (was, 2018-02-06, similarity 0.9543):
[0001628280-18-001086:note_history:6]
The future interest and principal payments related to the 2024 Notes are as follows as of December 30, 2017:

- changed (2018-05-02):
[0001633978-18-000030:note_history:7]
| Fiscal Years |  |
| 2019 | $ | 1.1 |  |
| 2020 | 1.1 |  |
| 2021 | 1.1 |  |
| 2022 | 1.1 |  |
| Thereafter | 451.7 |  |
| Total 2024 Notes payments | $ | 456.1 |  |
  (was, 2018-02-06, similarity 0.911):
[0001628280-18-001086:note_history:7]
| Fiscal Years |  |
| Remainder of 2018 | $ | 0.6 |  |
| 2019 | 1.1 |  |
| 2020 | 1.1 |  |
| 2021 | 1.1 |  |
| 2022 | 1.1 |  |
| Thereafter | 451.7 |  |
| Total 2024 Notes payments | $ | 456.7 |  |

- changed (2018-05-02):
[0001633978-18-000030:note_history:8]
Purchase obligations of $187.1 million as of March 31, 2018, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.
  (was, 2018-02-06, similarity 0.9886):
[0001628280-18-001086:note_history:8]
Purchase obligations of $187.4 million as of December 30, 2017, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

- changed (2018-05-02):
[0001633978-18-000030:note_history:9]
The following table presents the changes in our warranty reserve during the three and nine months ended March 31, 2018 and April 1, 2017 (in millions):
  (was, 2018-02-06, similarity 0.9135):
[0001628280-18-001086:note_history:9]
The following table presents the changes in our warranty reserve during the three and six months ended December 30, 2017 and December 31, 2016 (in millions):

- added (2018-05-02):
[0001633978-18-000030:note_history:10]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |
| Balance as of beginning of period | $ | 9.9 |  |  | $ | 8.7 |  |  | $ | 9.7 |  |  | $ | 2.8 |  |
| Provision for warranty (1) | 2.0 |  |  | 0.6 |  |  | 4.9 |  |  | 9.3 |  |
| Utilization of reserve | (4.9 | ) |  | (1.2 | ) |  | (7.6 | ) |  | (4.0 | ) |
| Balance as of end of period | $ | 7.0 |  |  | $ | 8.1 |  |  | $ | 7.0 |  |  | $ | 8.1 |  |

- added (2018-05-02):
[0001633978-18-000030:note_history:11]
(1) This does not include a settlement payment of $5.1 million received from a vendor for a quality issue during the three months ended March 31, 2018.

- changed (2018-05-02):
[0001633978-18-000030:note_history:12]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss.
  (was, 2018-02-06, similarity 0.7076):
[0001628280-18-001086:note_history:12]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. Were an unfavorable final outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the effect becomes reasonably estimable.

- changed (2018-05-02):
[0001633978-18-000030:note_history:13]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of March 31, 2018, we did not have any material indemnification claims that were probable or reasonably possible.
  (was, 2018-02-06, similarity 0.9857):
[0001628280-18-001086:note_history:13]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of December 30, 2017, we did not have any material indemnification claims that were probable or reasonably possible.

- removed (2018-05-02):
[0001628280-18-001086:note_history:14]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |  | December 30, 2017 |  | December 31, 2016 |
| Balance as of beginning of period | $ | 9.4 |  |  | $ | 5.4 |  |  | $ | 9.7 |  |  | $ | 2.8 |  |
| Provision for warranty | 1.9 |  |  | 4.9 |  |  | 2.9 |  |  | 8.7 |  |
| Utilization of reserve | (1.4 | ) |  | (1.6 | ) |  | (2.7 | ) |  | (2.8 | ) |
| Balance as of end of period | $ | 9.9 |  |  | $ | 8.7 |  |  | $ | 9.9 |  |  | $ | 8.7 |  |


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2018-05-02):
[0001633978-18-000030:note_history:15]
On March 11, 2018, Lumentum and Oclaro, Inc. ("Oclaro") entered into a Merger Agreement (the “Merger Agreement”), unanimously approved by the boards of directors of both companies, under which Lumentum will acquire all outstanding shares of Oclaro common stock. Each share of Oclaro common stock will be exchanged for $5.60 in cash and 0.0636 shares of Lumentum common stock, subject to the terms of the Merger Agreement. The total transaction consideration was approximately $1.8 billion as of the date of the Merger Agreement. Oclaro stockholders will own approximately 16% of the combined company at closing. The Merger Agreement contains certain termination rights for both Lumentum and Oclaro. The Merger Agreement further provides that upon termination of the Merger Agreement under specified circumstances relating to failure to obtain regulatory approvals, Lumentum may be required to pay Oclaro a termination fee of $80 million.

- added (2018-05-02):
[0001633978-18-000030:note_history:16]
The total transaction consideration will be funded by a combination of cash from the combined company of approximately $416 million, $550 million in new debt, and $859 million in Lumentum common stock.

- added (2018-05-02):
[0001633978-18-000030:note_history:17]
Lumentum entered into a commitment letter with Deutsche Bank Securities Inc. and Deutsche Bank AG New York, New York Branch (“Deutsche Bank”), pursuant to which, subject to the terms and conditions set forth therein, Deutsche Bank has committed to provide a senior secured term loan facility in an aggregate principal amount of $550 million, with a provision for additional senior secured term loans in an aggregate principal amount not to exceed $250 million.

- added (2018-05-02):
[0001633978-18-000030:note_history:18]
The transaction is subject to customary closing conditions, including the approval of Oclaro stockholders and antitrust regulatory approval in the United States and China. Under the Hart-Scott-Rodino Antitrust Improvements Act of 1976, as amended (the “HSR Act”), Lumentum and Oclaro are required to make pre-merger notification filings and to await the expiration or early termination of the statutory waiting period prior to completing the Merger.  Lumentum and Oclaro submitted pre-merger notification filings under the HSR Act on March 23, 2018 and received early termination of the waiting period on April 4, 2018. The transaction is not subject to any financing condition. The transaction is expected to be completed in the second half of calendar 2018.

- changed (2018-05-02):
[0001633978-18-000030:note_history:19]
These interim unaudited condensed consolidated financial statements include the accounts of the Company and its wholly-owned subsidiaries. All inter-company transactions and balances have been eliminated in consolidation.
  (was, 2018-02-06, similarity 0.8009):
[0001628280-18-001086:note_history:19]
These interim unaudited condensed consolidated financial statements include the accounts of the Company and its wholly-owned subsidiaries. All intra-company transactions within our business were eliminated.

- changed (2018-05-02):
[0001633978-18-000030:note_history:20]
The accompanying interim unaudited condensed consolidated financial statements and accompanying related notes should be read in conjunction with the audited consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended July 1, 2017.
  (was, 2018-02-06, similarity 0.979):
[0001628280-18-001086:note_history:20]
The accompanying interim unaudited condensed consolidated financial statements and accompanying related notes should be read in conjunction with the condensed consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended July 1, 2017.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-05-02):
[0001633978-18-000030:note_history:21]
As of March 31, 2018, the 2024 Notes consisted of the following (in millions):
  (was, 2018-02-06, similarity 0.9362):
[0001628280-18-001086:note_history:21]
As of December 30, 2017, the 2024 Notes consisted of the following (in millions):

- added (2018-05-02):
[0001633978-18-000030:note_history:22]
| Liability component: | March 31, 2018 |  | July 1, 2017 |
| Principal | $ | 450.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount | (120.1 | ) |  | (132.5 | ) |
| Net carrying amount of the liability component | $ | 329.9 |  |  | $ | 317.5 |  |

- removed (2018-05-02):
[0001628280-18-001086:note_history:23]
| Liability component: | December 30, 2017 |  | July 1, 2017 |
| Principal | $ | 450.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount | (124.3 | ) |  | (132.5 | ) |
| Net carrying amount of the liability component | $ | 325.7 |  |  | $ | 317.5 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-05-02):
[0001633978-18-000030:note_history:24]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. We incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. We amortize the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes is 5.4% per year. As of March 31, 2018, the remaining debt discount amortization period was 71 months.
  (was, 2018-02-06, similarity 0.9942):
[0001628280-18-001086:note_history:24]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. We incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. We amortize the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes is 5.4% per year. As of December 30, 2017, the remaining debt discount amortization period was 74 months.

- changed (2018-05-02):
[0001633978-18-000030:note_history:25]
As of March 31, 2018, the 2024 Notes consisted of the following (in millions):
  (was, 2018-02-06, similarity 0.9362):
[0001628280-18-001086:note_history:25]
As of December 30, 2017, the 2024 Notes consisted of the following (in millions):

- added (2018-05-02):
[0001633978-18-000030:note_history:26]
| Liability component: | March 31, 2018 |  | July 1, 2017 |
| Principal | $ | 450.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount | (120.1 | ) |  | (132.5 | ) |
| Net carrying amount of the liability component | $ | 329.9 |  |  | $ | 317.5 |  |

- changed (2018-05-02):
[0001633978-18-000030:note_history:27]
The following table sets forth interest expense information related to the 2024 Notes for the three and nine months ended March 31, 2018:
  (was, 2018-02-06, similarity 0.9462):
[0001628280-18-001086:note_history:27]
The following table sets forth interest expense information related to the 2024 Notes for the three and six months ended December 30, 2017:

- changed (2018-05-02):
[0001633978-18-000030:note_history:28]
|  | March 31, 2018 |
| (in millions, except percentages) | Three Months Ended |  | Nine Months Ended |
| Contractual interest expense | $ | 0.3 |  |  | $ | 0.9 |  |
| Amortization of the debt discount | 4.2 |  |  | 12.4 |  |
| Total interest expense | $ | 4.5 |  |  | $ | 13.3 |  |
| Effective interest rate on the liability component | 5.4 | % |  | 5.4 | % |
  (was, 2018-02-06, similarity 0.9693):
[0001628280-18-001086:note_history:28]
|  | December 30, 2017 |
| (in millions, except percentages) | Three Months Ended |  | Six Months Ended |
| Contractual interest expense | $ | 0.3 |  |  | $ | 0.6 |  |
| Amortization of the debt discount | 4.1 |  |  | 8.2 |  |
| Total interest expense | $ | 4.4 |  |  | $ | 8.8 |  |
| Effective interest rate on the liability component | 5.4 | % |  | 5.4 | % |

- changed (2018-05-02):
[0001633978-18-000030:note_history:29]
We have the ability and intent to settle the $450 million face value of the debt in cash. Therefore, we use the treasury stock method for calculating the dilutive impact of the debt. The 2024 Notes will have no impact to diluted earnings per share until the average price of our common stock exceeds the conversion price of $60.62.
  (was, 2018-02-06, similarity 0.989):
[0001628280-18-001086:note_history:29]
We have the ability and intent to settle the $450 million face value of the debt in cash. Therefore, we use the treasury stock method for calculating the dilutive impact of the debt. The 2024 Notes will have no impact to diluted earnings per share until the average price of our common stock exceeds the conversion price.

- removed (2018-05-02):
[0001628280-18-001086:note_history:30]
| Liability component: | December 30, 2017 |  | July 1, 2017 |
| Principal | $ | 450.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount | (124.3 | ) |  | (132.5 | ) |
| Net carrying amount of the liability component | $ | 325.7 |  |  | $ | 317.5 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-05-02):
[0001633978-18-000030:note_history:31]
The future interest and principal payments related to the 2024 Notes are as follows as of March 31, 2018:
  (was, 2018-02-06, similarity 0.9543):
[0001628280-18-001086:note_history:31]
The future interest and principal payments related to the 2024 Notes are as follows as of December 30, 2017:

- changed (2018-05-02):
[0001633978-18-000030:note_history:32]
| Fiscal Years |  |
| 2019 | $ | 1.1 |  |
| 2020 | 1.1 |  |
| 2021 | 1.1 |  |
| 2022 | 1.1 |  |
| Thereafter | 451.7 |  |
| Total 2024 Notes payments | $ | 456.1 |  |
  (was, 2018-02-06, similarity 0.911):
[0001628280-18-001086:note_history:32]
| Fiscal Years |  |
| Remainder of 2018 | $ | 0.6 |  |
| 2019 | 1.1 |  |
| 2020 | 1.1 |  |
| 2021 | 1.1 |  |
| 2022 | 1.1 |  |
| Thereafter | 451.7 |  |
| Total 2024 Notes payments | $ | 456.7 |  |
