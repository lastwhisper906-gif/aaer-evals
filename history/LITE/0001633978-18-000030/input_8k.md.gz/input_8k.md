# LITE 8-K — 0001633978-18-000029 filed 2018-05-02

## item codes, every 8-K on or before 2018-05-02

- 2018-05-02 0001633978-18-000029 — 2.02, 9.01
- 2018-03-12 0001193125-18-078154 — 1.01, 2.01, 8.01, 9.01
- 2018-02-06 0001628280-18-001082 — 2.02, 9.01
- 2017-11-08 0001633978-17-000133 — 5.02, 9.01
- 2017-11-07 0001633978-17-000131 — 5.07
- 2017-11-01 0001633978-17-000117 — 2.02, 9.01
- 2017-08-09 0001633978-17-000058 — 2.02, 9.01
- 2017-05-04 0001633978-17-000035 — 2.02, 9.01
- 2017-03-08 0001193125-17-074740 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2017-03-02 0001193125-17-066769 — 8.01, 9.01
- 2017-02-07 0001633978-17-000005 — 2.02, 9.01
- 2017-01-03 0001628280-17-000018 — 4.01, 9.01
- 2016-11-09 0001628280-16-021143 — 5.02, 5.07, 9.01
- 2016-10-27 0001628280-16-020382 — 2.02, 9.01
- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2018-05-02

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001633978-18-000029:8k_2_02:1]
EX-99.1
2
lite_ex991xq3fy18.htm
EXHIBIT 99.1

[0001633978-18-000029:8k_2_02:2]
Exhibit

[0001633978-18-000029:8k_2_02:3]
NEWS RELEASE

[0001633978-18-000029:8k_2_02:4]
LUMENTUM ANNOUNCES FISCAL THIRD QUARTER 2018 RESULTS

[0001633978-18-000029:8k_2_02:5]
Fiscal Third Quarter Highlights

[0001633978-18-000029:8k_2_02:6]
| • | Lumentum achieved Net Revenue of $298.8 million |

[0001633978-18-000029:8k_2_02:7]
| • | GAAP Operating margin of 8.5%; Non-GAAP Operating margin of 16.5% |

[0001633978-18-000029:8k_2_02:8]
| • | GAAP diluted Net income per share of $0.04; Non-GAAP diluted Net income per share of $0.78 |

[0001633978-18-000029:8k_2_02:9]
Milpitas, Calif., May 2, 2018 – Lumentum Holdings Inc. (“Lumentum” or the “Company”) today reported results for its fiscal third quarter ended March 31, 2018.

[0001633978-18-000029:8k_2_02:10]
Net revenue for the fiscal third quarter of 2018 was $298.8 million, with GAAP net income of $2.7 million, or $0.04 per diluted share. Net revenue for fiscal second quarter of 2018 was $404.6 million, with GAAP net income of $204.8 million, or $3.05 per diluted share. Net revenue for the fiscal third quarter of 2017 was $255.8 million, with GAAP net loss of $(56.0) million, or $(0.92) per diluted share.

[0001633978-18-000029:8k_2_02:11]
Non-GAAP net income for the fiscal third quarter of 2018 was $50.6 million, or $0.78 per diluted share. Non-GAAP net income for fiscal second quarter of 2018 was $107.8 million, or $1.67 per diluted share. Non-GAAP net income for the fiscal third quarter of 2017 was $30.8 million, or $0.49 per diluted share.

[0001633978-18-000029:8k_2_02:12]
The Company held $692.8 million in total cash and short-term investments at the end of the fiscal third quarter of 2018.

[0001633978-18-000029:8k_2_02:13]
“Our strategy of investing in differentiated products and technologies, focusing on close relationships with market leading customers, and leveraging our technologies across multiple growing end markets, is working.  Driven by strong customer demand and execution on capacity expansion, in the third quarter we achieved new record Lasers revenues, which increased 18% sequentially, and grew Telecom revenues by more than 11% sequentially, with notable strength in ROADMs, which were up 27% sequentially,” said Alan Lowe, President and CEO, “Though seasonally down, we made good progress on new 3D sensing customer programs and are well positioned for new customer product introductions during FY19. During the third quarter, we announced reaching an agreement to acquire Oclaro and we continue to work with Oclaro on this pending transaction.”

[0001633978-18-000029:8k_2_02:14]
Financial Overview – Fiscal Third Quarter Ended March 31, 2018

[0001633978-18-000029:8k_2_02:15]
|  | GAAP Results ($ in millions) |
|  | Q3 |  | Q2 |  | Q3 |  | Change |
|  | FY 2018 |  | FY 2018 |  | FY 2017 |  | Q/Q |  | Y/Y |
| Net revenue | $298.8 |  | $404.6 |  | $255.8 |  | (26.1)% |  | 16.8% |
| Gross margin | 32.5% |  | 42.3% |  | 32.1% |  | (980)bps |  | 40bps |
| Operating margin | 8.5% |  | 22.4% |  | 5.3% |  | (1,390)bps |  | 320bps |
|  | Non-GAAP Results ($ in millions) |
|  | Q3 |  | Q2 |  | Q3 |  | Change |
|  | FY 2018 |  | FY 2018 |  | FY 2017 |  | Q/Q |  | Y/Y |
| Net revenue | $298.8 |  | $404.6 |  | $255.8 |  | (26.1)% |  | 16.8% |
| Gross margin | 36.3% |  | 44.9% |  | 34.4% |  | (860)bps |  | 190bps |
| Operating margin | 16.5% |  | 28.3% |  | 12.6% |  | (1,180)bps |  | 390bps |

[0001633978-18-000029:8k_2_02:16]
|  | Net Revenue by Segment ($ in millions) |
|  | Q3 |  | % of |  | Q2 |  | Q3 |  | Change |
|  | FY 2018 |  | Net Revenue |  | FY 2018 |  | FY 2017 |  | Q/Q |  | Y/Y |
| Optical Communications | $246.3 |  | 82.4% |  | $360.1 |  | $216.1 |  | (31.6)% |  | 14.0% |
| Lasers | 52.5 |  | 17.6% |  | 44.5 |  | 39.7 |  | 18.0% |  | 32.2% |
| Total | $298.8 |  | 100.0% |  | $404.6 |  | $255.8 |  | (26.1)% |  | 16.8% |

[0001633978-18-000029:8k_2_02:17]
The tables above provide comparisons of quarterly results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled “Use of Non-GAAP Financial Measures.”

[0001633978-18-000029:8k_2_02:18]
Business Outlook

[0001633978-18-000029:8k_2_02:19]
The Company expects the following for the fiscal fourth quarter 2018:

[0001633978-18-000029:8k_2_02:20]
•Net Revenue to be in the range of $275 million to $300 million

[0001633978-18-000029:8k_2_02:21]
•Non-GAAP Operating margin of 14.0% to 16.0%

[0001633978-18-000029:8k_2_02:22]
•Non-GAAP diluted earnings per share of $0.55 to $0.75

[0001633978-18-000029:8k_2_02:23]
Note:  Earnings per share based on approximately 65.3 million shares outstanding on a fully diluted basis

[0001633978-18-000029:8k_2_02:24]
Our projection of 65.3 million shares outstanding does not include the potentially dilutive effect of the convertible notes, as we have the ability and intent to settle the face value in cash; and therefore, we use the treasury stock method for calculating the dilutive impact of the 2024 Notes. The notes will have an impact on our diluted earnings per share when the average price of our common stock exceeds the conversion price of $60.62.

[0001633978-18-000029:8k_2_02:25]
We have not provided reconciliations from GAAP to non-GAAP measures for our outlook. A large portion of non-GAAP adjustments, such as derivative liability adjustments, restructuring charges, stock-based compensation, litigation, acquisition related costs, non-cash income tax expense and credits, and other costs and contingencies unrelated to current and future operations are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future. For example, in the fiscal second quarter of 2018, we had a credit of $207.0 million primarily related to a release of a U.S. valuation allowance, which was offset by a write-down of deferred tax assets in the amount of $83.0 million due to the lower corporate tax rate enacted under the 2017 “Tax Cuts and Jobs Act” reform.

[0001633978-18-000029:8k_2_02:26]
Conference Call

[0001633978-18-000029:8k_2_02:27]
Lumentum will host a conference call on May 2, 2018 at 5:30am PT/8:30am ET. A live webcast of the call and the replay will be available on the Lumentum website at http://investor.lumentum.com through May 9, 2018, 8:59pm PT/11:59pm ET. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the “Events and Presentations” section concurrently with this earnings press release. This press release is being furnished as an exhibit to a Current Report on Form 8-K filed with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001633978-18-000029:8k_2_02:28]
About Lumentum

[0001633978-18-000029:8k_2_02:29]
Lumentum (NASDAQ: LITE) is a market-leading manufacturer of innovative optical and photonic products enabling optical networking and commercial laser customers worldwide. Lumentum’s optical components and subsystems are part of virtually every type of telecom, enterprise, and data center network. Lumentum’s commercial lasers enable advanced manufacturing techniques and diverse applications including next-generation 3D sensing capabilities. Lumentum is headquartered in Milpitas, California with R&D, manufacturing, and sales offices worldwide.  For more information, visit https://www.lumentum.com/en.

[0001633978-18-000029:8k_2_02:30]
Forward-Looking Statements

[0001633978-18-000029:8k_2_02:31]
and our position in that market. These forward-looking statements involve risks and uncertainties that could cause actual results to differ materially from those projected. Among the factors that could cause actual results to differ from those contemplated are: (a) quarter-over-quarter product mix fluctuations which can materially impact profitability measures due to the broad gross margin ranges across our portfolio; (b) continued decline of average selling prices across our businesses; (c) effects of seasonality; (d) the ability of our suppliers and contract manufacturers to meet production and delivery requirements to our forecasted demand; (e) inherent uncertainty related to global markets and the effect of such markets on demand for our products; (f) changes in customer demand; and (g) our ability to attract and retain new customers, particularly in the 3D sensing market, (h) the risk that the Oclaro transaction does not close, due to the failure of one or more conditions to closing or the failure of the businesses (including personnel) to be integrated successfully after closing; (i) the risk that synergies and non-GAAP earnings accretion will not be realized or realized to the extent anticipated; (j) uncertainty as to the market value of the Lumentum merger consideration to be paid in the merger; (k) the risk that required governmental or Oclaro stockholder approvals of the merger (including U.S. or China antitrust approvals) will not be obtained or that such approvals will be delayed beyond current expectations; (l) the risk that following this transaction, Lumentum’s financing or operating strategies will not be successful; (m) litigation in respect of either company or the merger; and (n) disruption from the merger making it more difficult to maintain customer, supplier, key personnel and other strategic relationships. For more information on these and other risks, please refer to the “Risk Factors” section included in the Company’s Quarterly Report on Form 10-Q for the fiscal third quarter ended March 31, 2018 filed with the Securities and Exchange Commission, in the S-4 to be filed by Lumentum with the Securities and Exchange Commission at a future date in connection with the Oclaro transaction and in the documents which are incorporated by reference therein, and in the Company’s other filings with the Securities and Exchange Commission. The forward-looking statements and preliminary financial results contained in this press release are made as of the date hereof and the Company assumes no obligation to update such statements, except as required by applicable law.

[0001633978-18-000029:8k_2_02:32]
Additional Information and Where to Find It

[0001633978-18-000029:8k_2_02:33]
This press release references a proposed business combination involving Lumentum Holdings Inc. and Oclaro, Inc. In connection with the proposed transaction, Lumentum will file with the Securities and Exchange Commission a Registration Statement on Form S-4 that includes the preliminary proxy statement of Oclaro and that will also constitute a prospectus of Lumentum. The information in the preliminary proxy statement/prospectus is not complete and may be changed. Lumentum may not sell the common stock referenced in the proxy statement/prospectus until the Registration Statement on Form S-4 filed with the Securities and Exchange Commission becomes effective. The preliminary proxy statement/prospectus and this press release are not offers to sell Lumentum securities, are not soliciting an offer to buy Lumentum securities in any state where the offer and sale is not permitted and are not a solicitation of any vote or approval.  The definitive proxy statement/prospectus will be mailed to stockholders of Oclaro.

[0001633978-18-000029:8k_2_02:34]
LUMENTUM AND OCLARO URGE INVESTORS AND SECURITY HOLDERS TO READ THE DEFINITIVE PROXY STATEMENT/PROSPECTUS AND OTHER DOCUMENTS FILED WITH THE SECURITIES AND EXCHANGE COMMISSION CAREFULLY AND IN THEIR ENTIRETY WHEN THEY BECOME AVAILABLE BECAUSE THEY WILL CONTAIN IMPORTANT INFORMATION ABOUT THE PROPOSED TRANSACTION.

[0001633978-18-000029:8k_2_02:35]
Investors and security holders will be able to obtain these materials (when they are available) and other documents filed with the Securities and Exchange Commission free of charge at the Securities and Exchange Commission’s website, www.sec.gov. Copies of documents filed with the Securities and Exchange Commission by Lumentum (when they become available) may be obtained free of charge on Lumentum’s website at www.lumentum.com or by directing a written request to Lumentum Holdings Inc., Investor Relations, 400 North McCarthy Boulevard, Milpitas, CA 95035. Copies of documents filed with the Securities and Exchange Commission by Oclaro (when they become available) may be obtained free of charge on Oclaro’s website at www.oclaro.com or by directing a written request to Oclaro, Inc. Investor Relations, 225 Charcot Avenue, San Jose, CA 95131.

[0001633978-18-000029:8k_2_02:36]
Participants in the Merger Solicitation

[0001633978-18-000029:8k_2_02:37]
Each of Lumentum Holdings Inc., Oclaro, Inc. and their respective directors, executive officers and certain other members of management and employees may be deemed to be participants in the solicitation of proxies in respect of the proposed transaction. Information regarding these persons who may, under the rules of the Securities and Exchange Commission, be considered participants in the solicitation of Oclaro stockholders in connection with the proposed transaction is set forth in the proxy statement/prospectus described above filed with the Securities and Exchange Commission. Additional information regarding Lumentum’s executive officers and directors is included in Lumentum’s definitive proxy statement, which was filed with the Securities and Exchange Commission on September 19, 2017. Additional information regarding Oclaro’s executive officers and directors is included in Oclaro’s definitive proxy statement, which was filed with the Securities and Exchange

[0001633978-18-000029:8k_2_02:38]
Commission on September 27, 2017. You can obtain free copies of these documents using the information in the paragraph immediately above.

[0001633978-18-000029:8k_2_02:39]
Contact Information

[0001633978-18-000029:8k_2_02:40]
Investors: Chris Coldren, 408-404-0606; investor.relations@lumentum.com

[0001633978-18-000029:8k_2_02:41]
Press: Greg Kaufman, 408-546-4593; media@lumentum.com

[0001633978-18-000029:8k_2_02:42]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001633978-18-000029:8k_2_02:43]
LUMENTUM HOLDINGS INC.

[0001633978-18-000029:8k_2_02:44]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001633978-18-000029:8k_2_02:45]
(in millions, except per share data)

[0001633978-18-000029:8k_2_02:46]
(unaudited)

[0001633978-18-000029:8k_2_02:47]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |
| Net revenue | $ | 298.8 |  |  | $ | 255.8 |  |  | $ | 946.6 |  |  | $ | 778.9 |  |
| Cost of sales | 201.0 |  |  | 172.0 |  |  | 607.6 |  |  | 523.0 |  |
| Amortization of acquired developed technologies | 0.8 |  |  | 1.7 |  |  | 2.4 |  |  | 5.1 |  |
| Gross profit | 97.0 |  |  | 82.1 |  |  | 336.6 |  |  | 250.8 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 38.2 |  |  | 37.3 |  |  | 118.3 |  |  | 112.9 |  |
| Selling, general and administrative | 33.2 |  |  | 28.1 |  |  | 95.5 |  |  | 84.2 |  |
| Restructuring and related charges | 0.1 |  |  | 3.1 |  |  | 3.8 |  |  | 10.0 |  |
| Total operating expenses | 71.5 |  |  | 68.5 |  |  | 217.6 |  |  | 207.1 |  |
| Income from operations | 25.5 |  |  | 13.6 |  |  | 119.0 |  |  | 43.7 |  |
| Unrealized loss on derivative liabilities | (20.7 | ) |  | (56.6 | ) |  | (8.6 | ) |  | (74.5 | ) |
| Interest and other income (expense), net | (2.1 | ) |  | (1.4 | ) |  | (8.7 | ) |  | (1.4 | ) |
| Income (loss) before income taxes | 2.7 |  |  | (44.4 | ) |  | 101.7 |  |  | (32.2 | ) |
| Provision for (benefit from) income taxes | — |  |  | 11.6 |  |  | (112.9 | ) |  | 15.4 |  |
| Net income (loss) | 2.7 |  |  | (56.0 | ) |  | 214.6 |  |  | (47.6 | ) |
| Items reconciling net income (loss) to net income (loss) attributable to common stockholders: |  |  |  |  |  |  |  |
| Cumulative dividends on Series A Preferred Stock | (0.2 | ) |  | (0.2 | ) |  | (0.7 | ) |  | (0.6 | ) |
| Earnings allocated to Series A Preferred Stock | (0.1 | ) |  | — |  |  | (4.9 | ) |  | — |  |
| Net income (loss) attributable to common stockholders | $ | 2.4 |  |  | $ | (56.2 | ) |  | $ | 209.0 |  |  | $ | (48.2 | ) |
| Net income (loss) per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | $ | 0.04 |  |  | $ | (0.92 | ) |  | $ | 3.37 |  |  | $ | (0.80 | ) |
| Diluted | $ | 0.04 |  |  | $ | (0.92 | ) |  | $ | 3.31 |  |  | $ | (0.80 | ) |
| Shares used in per share calculation: |  |  |  |  |  |  |  |
| Basic | 62.4 |  |  | 61.0 |  |  | 62.1 |  |  | 60.4 |  |
| Diluted shares attributable to common stockholders | 63.3 |  |  | 61.0 |  |  | 63.2 |  |  | 60.4 |  |

[0001633978-18-000029:8k_2_02:48]
LUMENTUM HOLDINGS INC.

[0001633978-18-000029:8k_2_02:49]
CONSOLIDATED BALANCE SHEETS

[0001633978-18-000029:8k_2_02:50]
(in millions, except share and per share data)

[0001633978-18-000029:8k_2_02:51]
(unaudited)

[0001633978-18-000029:8k_2_02:52]
|  | March 31, 2018 |  | July 1, 2017 |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |  |
| Cash and cash equivalents | $ | 176.8 |  |  | $ | 272.9 |  |
| Short-term investments | 516.0 |  |  | 282.4 |  |
| Accounts receivable, net | 164.7 |  |  | 166.3 |  |
| Inventories | 144.2 |  |  | 145.2 |  |
| Prepayments and other current assets | 63.0 |  |  | 63.5 |  |
| Total current assets | 1,064.7 |  |  | 930.3 |  |
| Property, plant and equipment, net | 301.8 |  |  | 273.5 |  |
| Goodwill and intangibles, net | 19.9 |  |  | 21.5 |  |
| Deferred income taxes, net | 128.2 |  |  | 3.9 |  |
| Other non-current assets | 3.6 |  |  | 3.7 |  |
| Total assets | $ | 1,518.2 |  |  | $ | 1,232.9 |  |
| LIABILITIES, REDEEMABLE CONVERTIBLE PREFERRED STOCK, AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 100.9 |  |  | $ | 114.8 |  |
| Accrued payroll and related expenses | 33.2 |  |  | 27.5 |  |
| Income taxes payable | 0.1 |  |  | 0.7 |  |
| Accrued expenses | 36.3 |  |  | 19.3 |  |
| Other current liabilities | 21.0 |  |  | 21.9 |  |
| Total current liabilities | 191.5 |  |  | 184.2 |  |
| Convertible notes | 329.9 |  |  | 317.5 |  |
| Derivative liability | 60.2 |  |  | 51.6 |  |
| Other non-current liabilities | 24.2 |  |  | 25.0 |  |
| Total liabilities | 605.8 |  |  | 578.3 |  |
| Redeemable convertible preferred stock: |  |  |  |
| Non-controlling interest redeemable convertible Series A Preferred Stock, $0.001 par value, 10,000,000 authorized shares; 35,805 shares issued and outstanding as of March 31, 2018 and July 1, 2017 | 35.8 |  |  | 35.8 |  |
| Total redeemable convertible preferred stock | 35.8 |  |  | 35.8 |  |
| Stockholders’ equity: |  |  |  |
| Common stock, $0.001 par value, 990,000,000 authorized shares, 62,588,096 and 61,476,103 shares issued and outstanding as of March 31, 2018 and July 1, 2017, respectively | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital | 736.0 |  |  | 694.5 |  |
| Retained earnings | 133.2 |  |  | (83.2 | ) |
| Accumulated other comprehensive income | 7.3 |  |  | 7.4 |  |
| Total stockholders’ equity | 876.6 |  |  | 618.8 |  |
| Total liabilities, redeemable convertible preferred stock, and stockholders’ equity | $ | 1,518.2 |  |  | $ | 1,232.9 |  |

[0001633978-18-000029:8k_2_02:53]
Use of Non-GAAP Financial Measures

[0001633978-18-000029:8k_2_02:54]
In this press release, Lumentum provides investors with gross margin, operating margin, net income, and net income (loss) per share on a non-GAAP basis. Lumentum believes this non-GAAP financial information provides additional insight into the Company’s on-going performance and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons. Specifically, the Company believes that providing this information allows investors to better understand the Company’s financial performance and, importantly, to evaluate the efficacy of the methodology and information used by management to evaluate and measure such operating performance.  However, these measures may be different from non-GAAP measures used by other companies, limiting their usefulness for comparison purposes. The non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP. Investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future. Further, these non-GAAP financial measures may not be comparable to similarly titled measurements reported by other companies.

[0001633978-18-000029:8k_2_02:55]
Non-GAAP gross margin, non-GAAP operating margin, non-GAAP net income, and non-GAAP net income per share, Adjusted EBITDA, non-GAAP gross profit, non-GAAP operating income, non-GAAP income (loss) before income taxes and non-GAAP expenses exclude (i) workforce related charges such as severance, retention bonuses and employee relocation costs related to formal restructuring plans, (ii) costs for facilities not required for ongoing operations, and costs related to the relocation of certain equipment from these facilities and/or contract manufacturer facilities, (iii) stock-based compensation, (iv) amortization of acquired developed technologies, (v) non-cash interest expense, (vi) unrealized loss on derivative liability, (vii) warranty charges related to our vendor quality issues with expected future recoveries, (viii) release of a U.S. valuation allowance and the write down of deferred tax assets due to the 2017 “Tax Cuts and Jobs Act”, and (ix) other charges comprised mainly of inventory write-downs due to cancelled programs, as well as, acquisition, integration, litigation and other costs and contingencies unrelated to current and future operations. Management does not believe that these non-GAAP items are reflective of the Company’s underlying operating performance. The presentation of these and other similar items in Lumentum’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001633978-18-000029:8k_2_02:56]
A quantitative reconciliation between GAAP and non-GAAP financial data with respect to historical periods is included in the supplemental financial table attached to this press release.

[0001633978-18-000029:8k_2_02:57]
LUMENTUM HOLDINGS INC.

[0001633978-18-000029:8k_2_02:58]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001633978-18-000029:8k_2_02:59]
(in millions, except per share data)

[0001633978-18-000029:8k_2_02:60]
(unaudited)

[0001633978-18-000029:8k_2_02:61]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |
| Gross profit on GAAP basis | $ | 97.0 |  |  | $ | 82.1 |  |  | $ | 336.6 |  |  | $ | 250.8 |  |
| Stock-based compensation | 2.4 |  |  | 1.9 |  |  | 9.5 |  |  | 6.0 |  |
| Other charges related to non-recurring activities (a) | 8.3 |  |  | 2.2 |  |  | 24.5 |  |  | 12.1 |  |
| Amortization of acquired developed technologies | 0.8 |  |  | 1.7 |  |  | 2.4 |  |  | 5.1 |  |
| Gross profit on non-GAAP basis | $ | 108.5 |  |  | $ | 87.9 |  |  | $ | 373.0 |  |  | $ | 274.0 |  |
| Research and development on GAAP basis | $ | 38.2 |  |  | $ | 37.3 |  |  | $ | 118.3 |  |  | $ | 112.9 |  |
| Stock-based compensation | (3.6 | ) |  | (3.0 | ) |  | (10.5 | ) |  | (8.8 | ) |
| Other charges related to non-recurring activities | 0.4 |  |  | (0.1 | ) |  | (1.4 | ) |  | (0.7 | ) |
| Research and development on non-GAAP basis | $ | 35.0 |  |  | $ | 34.2 |  |  | $ | 106.4 |  |  | $ | 103.4 |  |
| Selling, general and administrative on GAAP basis | $ | 33.2 |  |  | $ | 28.1 |  |  | $ | 95.5 |  |  | $ | 84.2 |  |
| Stock-based compensation | (5.0 | ) |  | (3.2 | ) |  | (15.1 | ) |  | (10.1 | ) |
| Other charges related to non-recurring activities | (4.1 | ) |  | (3.3 | ) |  | (6.4 | ) |  | (7.1 | ) |
| Amortization of acquired developed technologies | — |  |  | (0.1 | ) |  | — |  |  | (0.3 | ) |
| Selling, general and administrative on non-GAAP basis | $ | 24.1 |  |  | $ | 21.5 |  |  | $ | 74.0 |  |  | $ | 66.7 |  |
| Income from operations on GAAP basis | $ | 25.5 |  |  | $ | 13.6 |  |  | $ | 119.0 |  |  | $ | 43.7 |  |
| Stock-based compensation | 11.0 |  |  | 8.1 |  |  | 35.1 |  |  | 24.9 |  |
| Other charges related to non-recurring activities (a) | 12.0 |  |  | 5.6 |  |  | 32.3 |  |  | 19.9 |  |
| Amortization of acquired developed technologies | 0.8 |  |  | 1.8 |  |  | 2.4 |  |  | 5.4 |  |
| Restructuring and related charges | 0.1 |  |  | 3.1 |  |  | 3.8 |  |  | 10.0 |  |
| Income from operations on non-GAAP basis | $ | 49.4 |  |  | $ | 32.2 |  |  | $ | 192.6 |  |  | $ | 103.9 |  |
| Interest and other (expense) income, net on GAAP basis | $ | (2.1 | ) |  | $ | (1.4 | ) |  | $ | (8.7 | ) |  | $ | (1.4 | ) |
| Non-cash other income (expense) | (0.1 | ) |  | (0.1 | ) |  | (0.1 | ) |  | (0.3 | ) |
| Effective interest expense on convertible notes | 4.2 |  |  | 1.0 |  |  | 12.4 |  |  | 1.0 |  |
| Interest and other (expense) income, net on non-GAAP basis | $ | 2.0 |  |  | $ | (0.5 | ) |  | $ | 3.6 |  |  | $ | (0.7 | ) |
| Income (loss) before income taxes on GAAP basis | $ | 2.7 |  |  | $ | (44.4 | ) |  | $ | 101.7 |  |  | $ | (32.2 | ) |
| Stock-based compensation | 11.0 |  |  | 8.1 |  |  | 35.1 |  |  | 24.9 |  |
| Other charges related to non-recurring activities (a) | 12.0 |  |  | 5.6 |  |  | 32.3 |  |  | 19.9 |  |
| Amortization of acquired developed technologies | 0.8 |  |  | 1.8 |  |  | 2.4 |  |  | 5.4 |  |
| Restructuring and related charges | 0.1 |  |  | 3.1 |  |  | 3.8 |  |  | 10.0 |  |
| Non-cash other income (expense) | (0.1 | ) |  | (0.1 | ) |  | (0.1 | ) |  | (0.3 | ) |
| Effective interest expense on convertible notes | 4.2 |  |  | 1.0 |  |  | 12.4 |  |  | 1.0 |  |
| Unrealized loss on derivative liabilities | 20.7 |  |  | 56.6 |  |  | 8.6 |  |  | 74.5 |  |
| Income before income taxes on non-GAAP basis | $ | 51.4 |  |  | $ | 31.7 |  |  | $ | 196.2 |  |  | $ | 103.2 |  |

[0001633978-18-000029:8k_2_02:62]
| Provision for (benefit from) income taxes on GAAP basis | $ | — |  |  | $ | 11.6 |  |  | $ | (112.9 | ) |  | $ | 15.4 |  |
| Impact of non-GAAP income tax (benefit) expense (b) | 0.8 |  |  | (10.7 | ) |  | 122.9 |  |  | (9.6 | ) |
| Provision for income taxes on non-GAAP basis | $ | 0.8 |  |  | $ | 0.9 |  |  | $ | 10.0 |  |  | $ | 5.8 |  |
| Net income (loss) on GAAP basis | $ | 2.7 |  |  | $ | (56.0 | ) |  | $ | 214.6 |  |  | $ | (47.6 | ) |
| Stock-based compensation | 11.0 |  |  | 8.1 |  |  | 35.1 |  |  | 24.9 |  |
| Other charges related to non-recurring activities (a) | 12.0 |  |  | 5.6 |  |  | 32.3 |  |  | 19.9 |  |
| Amortization of acquired developed technologies | 0.8 |  |  | 1.8 |  |  | 2.4 |  |  | 5.4 |  |
| Restructuring and related charges | 0.1 |  |  | 3.1 |  |  | 3.8 |  |  | 10.0 |  |
| Non-cash other income (expense) | (0.1 | ) |  | (0.1 | ) |  | (0.1 | ) |  | (0.3 | ) |
| Effective interest expense on convertible notes | 4.2 |  |  | 1.0 |  |  | 12.4 |  |  | 1.0 |  |
| Unrealized loss on derivative liabilities | 20.7 |  |  | 56.6 |  |  | 8.6 |  |  | 74.5 |  |
| Impact of non-GAAP income tax benefit (expense) (b) | (0.8 | ) |  | 10.7 |  |  | (122.9 | ) |  | 9.6 |  |
| Net income on non-GAAP basis | $ | 50.6 |  |  | $ | 30.8 |  |  | $ | 186.2 |  |  | $ | 97.4 |  |
| Net income per share on non-GAAP basis | $ | 0.78 |  |  | $ | 0.49 |  |  | $ | 2.88 |  |  | $ | 1.55 |  |
| Shares used in per share calculation - diluted on GAAP basis | 63.3 |  |  | 61.0 |  |  | 63.2 |  |  | 60.4 |  |
| Non-GAAP adjustment (c) | — |  |  | 0.9 |  |  | — |  |  | 1.0 |  |
| Effect of diluted securities from Series A Preferred Stock (d) | 1.5 |  |  | 1.5 |  |  | 1.5 |  |  | 1.5 |  |
| Shares used in per share calculation - diluted on non-GAAP basis | 64.8 |  |  | 63.4 |  |  | 64.7 |  |  | 62.9 |  |

[0001633978-18-000029:8k_2_02:63]
(a) The increase during the nine months ended March 31, 2018 primarily relates to set-up costs of our Thailand facility, including costs of transferring product lines to Thailand, as well as inventory write-downs due to cancelled programs.

[0001633978-18-000029:8k_2_02:64]
(b) The change during the nine months ended March 31, 2018 is primarily attributable to a credit of $207.0 million related to a release of a U.S. valuation allowance, which was offset by the write down of deferred tax assets due to the 2017 “Tax Cuts and Jobs Act” reform in the amount of $83.0 million.

[0001633978-18-000029:8k_2_02:65]
(c) This adjustment represents weighted-average potentially dilutive securities from our stock-based benefit plans excluded from the computation of diluted net loss per share attributable to common stockholders on a GAAP basis because the effect would have been antidilutive. This adjustment amount is added for the computation of diluted net income per share on a non-GAAP basis as we had a net income on a non-GAAP basis for all periods presented.

[0001633978-18-000029:8k_2_02:66]
(d) For all periods presented, 1.5 million shares related to the potential conversion of the Series A Preferred Stock were added to the calculation of diluted shares available on a non-GAAP basis because their inclusion results in more dilutive earnings per share.

[0001633978-18-000029:8k_2_02:67]
LUMENTUM HOLDINGS INC.

[0001633978-18-000029:8k_2_02:68]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EBITDA

[0001633978-18-000029:8k_2_02:69]
(in millions)

[0001633978-18-000029:8k_2_02:70]
(unaudited)

[0001633978-18-000029:8k_2_02:71]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |
| GAAP net income (loss) | $ | 2.7 |  |  | $ | (56.0 | ) |  | $ | 214.6 |  |  | $ | (47.6 | ) |
| Interest and other expense (income), net | 2.1 |  |  | 1.4 |  |  | 8.7 |  |  | 1.4 |  |
| Provision for (benefit from) income taxes (a) | — |  |  | 11.6 |  |  | (112.9 | ) |  | 15.4 |  |
| Depreciation | 18.4 |  |  | 14.1 |  |  | 53.3 |  |  | 39.1 |  |
| Amortization | 0.8 |  |  | 1.8 |  |  | 2.4 |  |  | 5.4 |  |
| EBITDA | 24.0 |  |  | (27.1 | ) |  | 166.1 |  |  | 13.7 |  |
| Restructuring and related charges | 0.1 |  |  | 3.1 |  |  | 3.8 |  |  | 10.0 |  |
| Stock-based compensation | 11.0 |  |  | 8.1 |  |  | 35.1 |  |  | 24.9 |  |
| Other charges related to non-recurring activities (b) | 12.0 |  |  | 5.6 |  |  | 32.3 |  |  | 19.9 |  |
| Unrealized loss on derivative liabilities | 20.7 |  |  | 56.6 |  |  | 8.6 |  |  | 74.5 |  |
| Adjusted EBITDA | $ | 67.8 |  |  | $ | 46.3 |  |  | $ | 245.9 |  |  | $ | 143.0 |  |

[0001633978-18-000029:8k_2_02:72]
(a) The change during the nine months ended March 31, 2018 is primarily attributable to a credit of $207.0 million related to a release of a U.S. valuation allowance, which was offset by the write-down of deferred tax assets due to the 2017 “Tax Cuts and Jobs Act” reform in the amount of $83.0 million.

[0001633978-18-000029:8k_2_02:73]
(b) The change during the nine months ended March 31, 2018 primarily relates to set-up costs of our Thailand facility, including costs of transferring product lines to Thailand, as well as inventory write-downs due to cancelled programs.
