# LITE notes — 0001633978-18-000030


## lite:AssetAcquisitionDisclosureTextBlock

[0001633978-18-000030:notes:1]
Note 5. Asset Acquisition

[0001633978-18-000030:notes:2]
On March 30, 2018, we entered into a Transition Services Agreement (“TSA”) with one of our contract manufacturers to wind down the production of our products at their facility in China and to facilitate an orderly transition of manufacturing to our manufacturing facility in Thailand, including the purchase of the manufacturing equipment. Under the terms of the TSA, we are required to pay $5.3 million in cash upon completion of certain milestones related to the purchase of equipment.

[0001633978-18-000030:notes:3]
We are also required to share cost of retention and severance, and to reimburse for certain other direct and indirect costs incurred by our contract manufacturer for transition services provided. These costs will be expensed as incurred.


## lite:PropertyPlantandEquipmentNetTableTextBlock

[0001633978-18-000030:notes:4]
[same as prior period, unchanged from 0001628280-18-001086:notes:1]

[0001633978-18-000030:notes:5]
|  | March 31, 2018 |  | July 1, 2017 |
| Land | $ | 10.6 |  |  | $ | 10.6 |  |
| Buildings and improvement | 49.3 |  |  | 37.3 |  |
| Machinery and equipment (1) | 543.2 |  |  | 461.1 |  |
| Computer equipment and software | 37.3 |  |  | 31.2 |  |
| Furniture and fixtures | 4.9 |  |  | 4.6 |  |
| Leasehold improvements | 30.1 |  |  | 30.5 |  |
| Construction in progress | 63.2 |  |  | 84.6 |  |
|  | 738.6 |  |  | 659.9 |  |
| Less: Accumulated depreciation | (436.8 | ) |  | (386.4 | ) |
| Property, plant and equipment, net | $ | 301.8 |  |  | $ | 273.5 |  |

[0001633978-18-000030:notes:6]
(1) In the first quarter of fiscal 2018, we started leasing equipment from a vendor and have accounted for the transaction as a capital lease. Included in the table above is our capital lease asset of $11.9 million, net of depreciation expense of $3.7 million as of March 31, 2018.


## lite:ScheduleOfFairValueAssumptionsForDerivativeLiabilityTableTextBlock

[0001633978-18-000030:notes:7]
The following table summarizes the assumptions used to determine the fair value of the embedded derivative for Series A Preferred Stock:

[0001633978-18-000030:notes:8]
|  | March 31, 2018 |  | July 1, 2017 |
| Stock price | $ | 63.80 |  |  | $ | 57.05 |  |
| Conversion price | $ | 24.63 |  |  | $ | 24.63 |  |
| Expected term (years) | 2.37 |  |  | 3.11 |  |
| Expected annual volatility | 50.0 | % |  | 47.5 | % |
| Risk-free rate | 2.31 | % |  | 1.57 | % |
| Preferred yield | 8.32 | % |  | 7.56 | % |


## lite:ScheduleOfOtherLiabilitiesCurrentTableTextBlock

[0001633978-18-000030:notes:9]
[same as prior period, unchanged from 0001628280-18-001086:notes:4]

[0001633978-18-000030:notes:10]
|  | March 31, 2018 |  | July 1, 2017 |
| Warranty accrual (1) | $ | 7.0 |  |  | $ | 9.7 |  |
| Restructuring accrual and related charges (2) | — |  |  | 3.8 |  |
| Deferred revenue and customer deposits | 2.5 |  |  | 6.9 |  |
| Capital lease obligation (3) | 9.2 |  |  | — |  |
| Other current liabilities | 2.3 |  |  | 1.5 |  |
| Other current liabilities | $ | 21.0 |  |  | $ | 21.9 |  |

[0001633978-18-000030:notes:11]
(1) Refer to “Note 16. Commitments and Contingencies” in the Notes to Unaudited Condensed Consolidated Financial Statements.

[0001633978-18-000030:notes:12]
(2) Refer to “Note 13. Restructuring and Related Charges” in the Notes to Unaudited Condensed Consolidated Financial Statements.

[0001633978-18-000030:notes:13]
(3) As of March 31, 2018, an amount of $2.3 million related to a capital lease was recorded in accounts payable on the condensed consolidated balance sheet. Refer to “Note 16. Commitments and Contingencies” in the Notes to Unaudited Condensed Consolidated Financial Statements.


## lite:ScheduleOfOtherLiabilitiesNoncurrentTableTextBlock

[0001633978-18-000030:notes:14]
[same as prior period, unchanged from 0001628280-18-001086:notes:9]

[0001633978-18-000030:notes:15]
|  | March 31, 2018 |  | July 1, 2017 |
| Asset retirement obligation | $ | 2.7 |  |  | $ | 2.5 |  |
| Pension and related accrual | 3.2 |  |  | 3.9 |  |
| Deferred rent | 3.1 |  |  | 3.3 |  |
| Unrecognized tax benefit | 10.2 |  |  | 10.5 |  |
| Capital lease obligation (1) | 0.8 |  |  | — |  |
| Other non-current liabilities | 4.2 |  |  | 4.8 |  |
| Other non-current liabilities | $ | 24.2 |  |  | $ | 25.0 |  |


## lite:SharebasedCompensationArrangementbySharebasedPaymentAwardNumberofSharesAvailableforGrantTableTextBlock

[0001633978-18-000030:notes:16]
[same as prior period, unchanged from 0001628280-18-001086:notes:12]

[0001633978-18-000030:notes:17]
[same as prior period, unchanged from 0001628280-18-001086:notes:13]


## us-gaap:AvailableForSaleSecuritiesContinuousUnrealizedLossPositionFairValueTableTextBlock

[0001633978-18-000030:notes:18]
The following table summarizes unrealized losses on our cash equivalents and short-term investments by category and length of time the investment has been in a continuous unrealized loss position as of the periods presented (in millions):

[0001633978-18-000030:notes:19]
|  | Less than 12 months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| March 31, 2018: |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 25.4 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 25.4 |  |  | $ | — |  |
| Commercial paper | 39.7 |  |  | — |  |  | — |  |  | — |  |  | 39.7 |  |  | — |  |
| Asset-backed securities | 112.9 |  |  | (0.3 | ) |  | — |  |  | — |  |  | 112.9 |  |  | (0.3 | ) |
| Corporate debt securities | 291.8 |  |  | (1.8 | ) |  | — |  |  | — |  |  | 291.8 |  |  | (1.8 | ) |
| Municipal bonds | 6.2 |  |  | — |  |  | — |  |  | — |  |  | 6.2 |  |  | — |  |
| Mortgage-backed securities | 4.5 |  |  | — |  |  | — |  |  | — |  |  | 4.5 |  |  | — |  |
| U.S. Treasury | 3.0 |  |  | — |  |  | — |  |  | — |  |  | 3.0 |  |  | — |  |
| Foreign government bonds | 8.8 |  |  | — |  |  | — |  |  | — |  |  | 8.8 |  |  | — |  |
| Total | $ | 492.3 |  |  | $ | (2.1 | ) |  | $ | — |  |  | $ | — |  |  | $ | 492.3 |  |  | $ | (2.1 | ) |
| July 1, 2017: |  |  |  |  |  |  |  |  |  |  |  |
| Asset-backed securities | $ | 21.5 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 21.5 |  |  | $ | — |  |
| Corporate debt securities | 29.8 |  |  | — |  |  | — |  |  | — |  |  | 29.8 |  |  | — |  |
| Municipal bonds | 2.9 |  |  | — |  |  | — |  |  | — |  |  | 2.9 |  |  | — |  |
| Foreign government bonds | 1.0 |  |  | — |  |  | — |  |  | — |  |  | 1.0 |  |  | — |  |
| U.S. Treasury | 1.9 |  |  | — |  |  | — |  |  | — |  |  | 1.9 |  |  | — |  |
| Total | $ | 57.1 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 57.1 |  |  | $ | — |  |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001633978-18-000030:notes:20]
The following table summarizes our cash, cash equivalents, and short-term investments by category for the periods presented (in millions):

[0001633978-18-000030:notes:21]
|  | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| March 31, 2018: |  |  |  |  |  |  |  |
| Cash | $ | 82.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 82.6 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 29.1 |  |  | — |  |  | — |  |  | 29.1 |  |
| Corporate debt securities | 26.0 |  |  | — |  |  | — |  |  | 26.0 |  |
| Money market funds | 2.5 |  |  | — |  |  | — |  |  | 2.5 |  |
| Municipal bonds | 1.5 |  |  | — |  |  | — |  |  | 1.5 |  |
| Foreign government bonds | 2.0 |  |  |  |  |  |  | 2.0 |  |
| U.S. Treasury | 26.7 |  |  | — |  |  | — |  |  | 26.7 |  |
| Asset-backed securities | 6.4 |  |  | — |  |  | — |  |  | 6.4 |  |
| Total cash and cash equivalents | $ | 176.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 176.8 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 32.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 32.0 |  |
| Commercial paper | 35.1 |  |  | — |  |  | — |  |  | 35.1 |  |
| Asset-backed securities | 114.3 |  |  | — |  |  | (0.3 | ) |  | 114.0 |  |
| Corporate debt securities | 317.6 |  |  | 0.1 |  |  | (1.8 | ) |  | 315.9 |  |
| Municipal bonds | 6.2 |  |  | — |  |  | — |  |  | 6.2 |  |
| Mortgage-backed securities | 4.8 |  |  | — |  |  | — |  |  | 4.8 |  |
| Foreign government bonds | 8.0 |  |  | — |  |  | — |  |  | 8.0 |  |
| Total short-term investments | $ | 518.0 |  |  | $ | 0.1 |  |  | $ | (2.1 | ) |  | $ | 516.0 |  |
| July 1, 2017: |  |  |  |  |  |  |  |
| Cash | $ | 201.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 201.3 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | 52.1 |  |  | — |  |  | — |  |  | 52.1 |  |
| Commercial paper | 14.7 |  |  | — |  |  | — |  |  | 14.7 |  |
| Money market funds | 4.8 |  |  | — |  |  | — |  |  | 4.8 |  |
| Total cash and cash equivalents | $ | 272.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 272.9 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 202.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 202.1 |  |
| Asset-backed securities | 26.1 |  |  | — |  |  | — |  |  | 26.1 |  |
| Corporate debt securities | 46.4 |  |  | — |  |  | — |  |  | 46.4 |  |
| Municipal bonds | 4.9 |  |  | — |  |  | — |  |  | 4.9 |  |
| Foreign government bonds | 1.0 |  |  | — |  |  | — |  |  | 1.0 |  |
| U.S. Treasury | 1.9 |  |  | — |  |  | — |  |  | 1.9 |  |
| Total short-term investments | $ | 282.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 282.4 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001633978-18-000030:notes:22]
[same as prior period, unchanged from 0001628280-18-001086:notes:18]

[0001633978-18-000030:notes:23]
[same as prior period, unchanged from 0001628280-18-001086:notes:19]


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001633978-18-000030:notes:24]
[same as prior period, unchanged from 0001628280-18-001086:notes:20]

[0001633978-18-000030:notes:25]
[same as prior period, unchanged from 0001628280-18-001086:notes:21]

[0001633978-18-000030:notes:26]
[same as prior period, unchanged from 0001628280-18-001086:notes:22]

[0001633978-18-000030:notes:27]
On March 11, 2018, Lumentum and Oclaro, Inc. ("Oclaro") entered into a Merger Agreement (the “Merger Agreement”), unanimously approved by the boards of directors of both companies, under which Lumentum will acquire all outstanding shares of Oclaro common stock. Each share of Oclaro common stock will be exchanged for $5.60 in cash and 0.0636 shares of Lumentum common stock, subject to the terms of the Merger Agreement. The total transaction consideration was approximately $1.8 billion as of the date of the Merger Agreement. Oclaro stockholders will own approximately 16% of the combined company at closing. The Merger Agreement contains certain termination rights for both Lumentum and Oclaro. The Merger Agreement further provides that upon termination of the Merger Agreement under specified circumstances relating to failure to obtain regulatory approvals, Lumentum may be required to pay Oclaro a termination fee of $80 million.

[0001633978-18-000030:notes:28]
The total transaction consideration will be funded by a combination of cash from the combined company of approximately $416 million, $550 million in new debt, and $859 million in Lumentum common stock.

[0001633978-18-000030:notes:29]
Lumentum entered into a commitment letter with Deutsche Bank Securities Inc. and Deutsche Bank AG New York, New York Branch (“Deutsche Bank”), pursuant to which, subject to the terms and conditions set forth therein, Deutsche Bank has committed to provide a senior secured term loan facility in an aggregate principal amount of $550 million, with a provision for additional senior secured term loans in an aggregate principal amount not to exceed $250 million.

[0001633978-18-000030:notes:30]
The transaction is subject to customary closing conditions, including the approval of Oclaro stockholders and antitrust regulatory approval in the United States and China. Under the Hart-Scott-Rodino Antitrust Improvements Act of 1976, as amended (the “HSR Act”), Lumentum and Oclaro are required to make pre-merger notification filings and to await the expiration or early termination of the statutory waiting period prior to completing the Merger.  Lumentum and Oclaro submitted pre-merger notification filings under the HSR Act on March 23, 2018 and received early termination of the waiting period on April 4, 2018. The transaction is not subject to any financing condition. The transaction is expected to be completed in the second half of calendar 2018.

[0001633978-18-000030:notes:31]
[same as prior period, unchanged from 0001628280-18-001086:notes:23]

[0001633978-18-000030:notes:32]
[same as prior period, unchanged from 0001628280-18-001086:notes:24]

[0001633978-18-000030:notes:33]
[same as prior period, unchanged from 0001628280-18-001086:notes:25]

[0001633978-18-000030:notes:34]
These interim unaudited condensed consolidated financial statements include the accounts of the Company and its wholly-owned subsidiaries. All inter-company transactions and balances have been eliminated in consolidation.

[0001633978-18-000030:notes:35]
[same as prior period, unchanged from 0001628280-18-001086:notes:27]

[0001633978-18-000030:notes:36]
The accompanying interim unaudited condensed consolidated financial statements and accompanying related notes should be read in conjunction with the audited consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended July 1, 2017.

[0001633978-18-000030:notes:37]
Effective July 2, 2017, we adopted Accounting Standards Update (“ASU”) 2016-09, Stock Compensation ASU 718 - Improvements to Employee Share-Based Payment Accounting. As a result of the adoption, in the first quarter of fiscal year 2018, we recorded on a modified retrospective basis a $2.6 million cumulative-effect adjustment to retained earnings for the recognition of excess tax benefits generated by the settlement of share-based awards in prior periods. We elected to account for forfeitures of equity awards when they occur. The change was applied on a modified retrospective basis with a cumulative-effect adjustment of approximately $0.2 million to retained earnings in the fiscal first quarter of 2018.

[0001633978-18-000030:notes:38]
[same as prior period, unchanged from 0001628280-18-001086:notes:30]


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001633978-18-000030:notes:39]
Note 7. Cash, Cash Equivalents, and Short-term Investments

[0001633978-18-000030:notes:40]
[same as prior period, unchanged from 0001628280-18-001086:notes:32]

[0001633978-18-000030:notes:41]
We use the specific-identification method to determine any realized gains or losses from the sale of our short-term investments classified as available-for-sale. During the three and nine months ended March 31, 2018, we did not realize significant gains or losses on a gross level from the sale of our short-term investments classified as available-for-sale.

[0001633978-18-000030:notes:42]
[same as prior period, unchanged from 0001628280-18-001086:notes:38]

[0001633978-18-000030:notes:43]
|  | As of March 31, 2018 |
|  | Amortized Cost |  | Fair Value |
| Due in 1 year | $ | 252.1 |  |  | $ | 251.5 |  |
| Due in 1 year through 5 years | 252.7 |  |  | 251.3 |  |
| Due in 5 years through 10 years | 7.2 |  |  | 7.2 |  |
| Due after 10 years | 6.0 |  |  | 6.0 |  |
|  | $ | 518.0 |  |  | $ | 516.0 |  |

[0001633978-18-000030:notes:44]
[same as prior period, unchanged from 0001628280-18-001086:notes:40]


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001633978-18-000030:notes:45]
Note 16. Commitments and Contingencies

[0001633978-18-000030:notes:46]
Operating Leases

[0001633978-18-000030:notes:47]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2026. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. As of March 31, 2018, the future minimum annual lease payments under non-cancellable operating leases were as follows (in millions):

[0001633978-18-000030:notes:48]
| Fiscal Years |  |
| Remainder of 2018 | $ | 2.9 |  |
| 2019 | 11.9 |  |
| 2020 | 9.0 |  |
| 2021 | 5.2 |  |
| 2022 | 3.5 |  |
| Thereafter | 4.3 |  |
| Total minimum operating lease payments | $ | 36.8 |  |

[0001633978-18-000030:notes:49]
During the three and nine months ended March 31, 2018, rental expense relating to building and equipment was $2.8 million and $9.2 million, respectively. During the three and nine months ended April 1, 2017, rental expense relating to building and equipment was $2.6 million and $7.0 million, respectively.

[0001633978-18-000030:notes:50]
Capital Lease

[0001633978-18-000030:notes:51]
As of March 31, 2018, equipment acquired under a capital lease agreement was $15.6 million. Our capital lease asset is included in property, plant and equipment, net in our condensed consolidated balance sheets as of March 31, 2018. Amortization expense on this capital lease asset is recorded as depreciation expense and is included in cost of sales in our condensed consolidated statements of operations for the three and nine months ended March 31, 2018. Our capital lease obligation is recorded at the lesser of the estimated fair market value of the leased property or the net present value of the aggregate future minimum lease payments and is included in other current liabilities and other non-current liabilities in our condensed consolidated balance sheets as of March 31, 2018. Refer to “Note 6. Balance Sheet Details” for capital lease obligation amounts in other current liabilities and other non-current liabilities. Interest on these obligations is included in interest expense in our condensed consolidated statements of operations.

[0001633978-18-000030:notes:52]
As of March 31, 2018 the future minimum annual lease payments under our capital lease were as follows (in millions):

[0001633978-18-000030:notes:53]
| Fiscal Years |  |
| Remainder of 2018 | $ | 4.7 |  |
| 2019 | 7.5 |  |
| 2020 | 0.4 |  |
| Total minimum capital lease payments | $ | 12.6 |  |
| Less: amount representing interest | $ | (0.3 | ) |
| Present value of capital lease obligation | $ | 12.3 |  |

[0001633978-18-000030:notes:54]
Acquisition Contingencies

[0001633978-18-000030:notes:55]
We incurred liabilities in the amount of $3.6 million in connection with the fiscal 2017 acquisition. The amount of $2.7 million is payable 36 months following the acquisition date contingent upon meeting certain production targets. We retained $0.9 million of the purchase price as security for any potential liabilities of the seller under the representations, warranties and indemnifications included in the purchase agreement, which amount less any amounts required to cover seller’s indemnification obligations is payable to the seller at the 15 month anniversary of the close date.

[0001633978-18-000030:notes:56]
0.25% Convertible Senior Notes due 2024

[0001633978-18-000030:notes:57]
The future interest and principal payments related to the 2024 Notes are as follows as of March 31, 2018:

[0001633978-18-000030:notes:58]
| Fiscal Years |  |
| 2019 | $ | 1.1 |  |
| 2020 | 1.1 |  |
| 2021 | 1.1 |  |
| 2022 | 1.1 |  |
| Thereafter | 451.7 |  |
| Total 2024 Notes payments | $ | 456.1 |  |

[0001633978-18-000030:notes:59]
Purchase Obligations

[0001633978-18-000030:notes:60]
Purchase obligations of $187.1 million as of March 31, 2018, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001633978-18-000030:notes:61]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with such vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

[0001633978-18-000030:notes:62]
Product Warranties

[0001633978-18-000030:notes:63]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, product component or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001633978-18-000030:notes:64]
The following table presents the changes in our warranty reserve during the three and nine months ended March 31, 2018 and April 1, 2017 (in millions):

[0001633978-18-000030:notes:65]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |
| Balance as of beginning of period | $ | 9.9 |  |  | $ | 8.7 |  |  | $ | 9.7 |  |  | $ | 2.8 |  |
| Provision for warranty (1) | 2.0 |  |  | 0.6 |  |  | 4.9 |  |  | 9.3 |  |
| Utilization of reserve | (4.9 | ) |  | (1.2 | ) |  | (7.6 | ) |  | (4.0 | ) |
| Balance as of end of period | $ | 7.0 |  |  | $ | 8.1 |  |  | $ | 7.0 |  |  | $ | 8.1 |  |

[0001633978-18-000030:notes:66]
(1) This does not include a settlement payment of $5.1 million received from a vendor for a quality issue during the three months ended March 31, 2018.

[0001633978-18-000030:notes:67]
Environmental Liabilities

[0001633978-18-000030:notes:68]
Our research and development (“R&D”), manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental, product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001633978-18-000030:notes:69]
In connection with the Separation, we agreed to indemnify Viavi for any liability associated with contamination from past operations at all properties transferred to us from Viavi, to the extent the resulting issues primarily related to our business.

[0001633978-18-000030:notes:70]
Legal Proceedings

[0001633978-18-000030:notes:71]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss.

[0001633978-18-000030:notes:72]
Indemnifications

[0001633978-18-000030:notes:73]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of March 31, 2018, we did not have any material indemnification claims that were probable or reasonably possible.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001633978-18-000030:notes:74]
[same as prior period, unchanged from 0001628280-18-001086:notes:69]

[0001633978-18-000030:notes:75]
[same as prior period, unchanged from 0001628280-18-001086:notes:70]

[0001633978-18-000030:notes:76]
As of March 31, 2018 and July 1, 2017, balances for the components of accumulated other comprehensive income (loss) were as follows (in millions):

[0001633978-18-000030:notes:77]
|  | Foreign currency translation adjustments, net of tax |  | Defined benefit obligation, net of tax |  | Unrealized gain (loss) on available-for-sale securities, net of tax |  | Total |
| Beginning balance as of July 1, 2017 | $ | 10.5 |  |  | $ | (3.1 | ) |  | $ | — |  |  | $ | 7.4 |  |
| Other comprehensive income (loss) | 1.9 |  |  | — |  |  | (2.0 | ) |  | (0.1 | ) |
| Ending balance as of March 31, 2018 | $ | 12.4 |  |  | $ | (3.1 | ) |  | $ | (2.0 | ) |  | $ | 7.3 |  |

[0001633978-18-000030:notes:78]
[same as prior period, unchanged from 0001628280-18-001086:notes:73]


## us-gaap:ConvertibleDebtTableTextBlock

[0001633978-18-000030:notes:79]
As of March 31, 2018, the 2024 Notes consisted of the following (in millions):

[0001633978-18-000030:notes:80]
| Liability component: | March 31, 2018 |  | July 1, 2017 |
| Principal | $ | 450.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount | (120.1 | ) |  | (132.5 | ) |
| Net carrying amount of the liability component | $ | 329.9 |  |  | $ | 317.5 |  |


## us-gaap:DebtDisclosureTextBlock

[0001633978-18-000030:notes:81]
Note 10. Convertible Senior Notes

[0001633978-18-000030:notes:82]
In March 2017, we issued the 2024 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank National Association, as trustee (the “Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001633978-18-000030:notes:83]
The 2024 Notes bear interest at a rate of 0.25% per year. Interest on the 2024 Notes is payable semi-annually in arrears on March 15 and September 15 of each year, beginning on September 15, 2017. The 2024 Notes will mature on March 15, 2024, unless earlier repurchased by us or converted pursuant to their terms.

[0001633978-18-000030:notes:84]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share, a 132.5% premium to the fair market value at the date of issuance. Prior to the close of business on the business day immediately preceding December 15, 2023, the 2024 Notes will be convertible only under the following circumstances: (1) during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price on each applicable trading day; (2) during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of notes for each trading day of such measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day; or (3) upon the occurrence of specified corporate events. On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their notes at any time. In addition, upon the occurrence of a make-whole fundamental change, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert 2024 Notes in connection with such make-whole fundamental change.

[0001633978-18-000030:notes:85]
We may not redeem the 2024 Notes prior to their maturity date and no sinking fund is provided for the 2024 Notes. Upon the occurrence of a fundamental change, holders may require us to repurchase all or a portion of their 2024 Notes for cash at a price equal to 100% of the principal amount of the 2024 Notes to be repurchased, plus any accrued and unpaid interest.

[0001633978-18-000030:notes:86]
We considered the features embedded in the 2024 Notes other than the conversion feature, including the holders’ put feature, our call feature, and the make-whole feature, and concluded that they are not required to be bifurcated and accounted for separately from the host debt instrument.

[0001633978-18-000030:notes:87]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. We incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. We amortize the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes is 5.4% per year. As of March 31, 2018, the remaining debt discount amortization period was 71 months.

[0001633978-18-000030:notes:88]
During the year ended July 1, 2017, we satisfied the TMA settlement conditions. As such, the value of the conversion option will no longer be marked to market and was reclassified to additional paid-in capital within stockholders’ equity on our condensed consolidated balance sheet. The value of the conversion option at the time of issuance will be treated as an original issue discount for purposes of accounting for the debt component of the notes. The debt component will accrete up to the principal amount over the expected term of the debt. These accounting standards do not affect the actual amount we are required to repay, and the amount shown in the table below for the notes is the aggregate principal amount of the notes and does not reflect the debt discount we will be required to recognize.

[0001633978-18-000030:notes:89]
The following table sets forth interest expense information related to the 2024 Notes for the three and nine months ended March 31, 2018:

[0001633978-18-000030:notes:90]
|  | March 31, 2018 |
| (in millions, except percentages) | Three Months Ended |  | Nine Months Ended |
| Contractual interest expense | $ | 0.3 |  |  | $ | 0.9 |  |
| Amortization of the debt discount | 4.2 |  |  | 12.4 |  |
| Total interest expense | $ | 4.5 |  |  | $ | 13.3 |  |
| Effective interest rate on the liability component | 5.4 | % |  | 5.4 | % |

[0001633978-18-000030:notes:91]
We have the ability and intent to settle the $450 million face value of the debt in cash. Therefore, we use the treasury stock method for calculating the dilutive impact of the debt. The 2024 Notes will have no impact to diluted earnings per share until the average price of our common stock exceeds the conversion price of $60.62.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001633978-18-000030:notes:92]
Note 11. Derivative Liability

[0001633978-18-000030:notes:93]
We estimate the fair value of the embedded derivative for the Series A Preferred Stock using the binomial lattice model. We applied the lattice model to value the embedded derivative using a “with-and-without method,” where the value of the Series A Preferred Stock, including the embedded derivative, is defined as the “with”, and the value of the Series A Preferred Stock, excluding the embedded derivative, is defined as the “without”. The lattice model requires the following inputs: (i) the Company's common stock price; (ii) conversion price; (iii) term; (iv) yield; (v) recovery rate for the Series A Preferred Stock; (vi) estimated stock volatility; and (vii) risk-free rate. The fair value of the embedded derivative was determined using Level 3 inputs under the fair value hierarchy (unobservable inputs). Changes in the inputs into this valuation model have a material impact in the estimated fair value of the embedded derivative. For example, a decrease (increase) in the stock price and the volatility results in a decrease (increase) in the estimated fair value of the embedded derivative. The changes in the fair value of the bifurcated embedded derivative for the Series A Preferred Stock are primarily related to the change in the price of our common stock and are reflected in the condensed consolidated statements of operations as “Unrealized gain (loss) on derivative liabilities”. Unrealized loss on derivative liability for the Series A Preferred Stock amounted to $(20.7) million and $(8.6) million for the three and nine months ended March 31, 2018, respectively, and $(17.9) million and $(35.8) million for the three and nine months ended April 1, 2017, respectively.

[0001633978-18-000030:notes:94]
The following table provides a reconciliation of the fair value of the embedded derivative for the Series A Preferred Stock for the three and nine months ended March 31, 2018 and April 1, 2017 (in millions):

[0001633978-18-000030:notes:95]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |
| Balance as of beginning of period | $ | (39.5 | ) |  | $ | (28.2 | ) |  | $ | (51.6 | ) |  | $ | (10.3 | ) |
| Unrealized loss on the Series A Preferred Stock derivative liability | (20.7 | ) |  | (17.9 | ) |  | (8.6 | ) |  | (35.8 | ) |
| Balance as of end of period | $ | (60.2 | ) |  | $ | (46.1 | ) |  | $ | (60.2 | ) |  | $ | (46.1 | ) |

[0001633978-18-000030:notes:96]
Also, during the three and nine months ended April 1, 2017, we recorded an unrealized loss on the derivate liability from the 2024 Notes. On June 29, 2017, we met the requirements to account for the conversion option of the 2024 Notes as equity and the conversion option is no longer marked to market. Refer to “Note 10. Convertible Senior Notes” in the Notes to Unaudited Condensed Consolidated Financial Statements.

[0001633978-18-000030:notes:97]
The following table provides a reconciliation of the fair value of the embedded derivative for the 2024 Notes for the three and nine months ended March 31, 2018 and April 1, 2017 (in millions):

[0001633978-18-000030:notes:98]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |
| Balance as of beginning of period | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Fair value of the embedded derivative for the 2024 Notes at issuance | — |  |  | (129.9 | ) |  | — |  |  | (129.9 | ) |
| Unrealized loss on the 2024 Notes derivative liability | — |  |  | (38.7 | ) |  | — |  |  | (38.7 | ) |
| Balance as of end of period | $ | — |  |  | $ | (168.6 | ) |  | $ | — |  |  | $ | (168.6 | ) |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001633978-18-000030:notes:99]
Note 15. Stock-Based Compensation and Stock Plans

[0001633978-18-000030:notes:100]
[same as prior period, unchanged from 0001628280-18-001086:notes:94]

[0001633978-18-000030:notes:101]
[same as prior period, unchanged from 0001628280-18-001086:notes:95]

[0001633978-18-000030:notes:102]
[same as prior period, unchanged from 0001628280-18-001086:notes:96]

[0001633978-18-000030:notes:103]
On November 4, 2016, our stockholders approved an amendment to increase the number of shares that may be issued under the 2015 Plan by 3.0 million shares, and certain other material terms of the 2015 Plan.

[0001633978-18-000030:notes:104]
As of March 31, 2018, we had 2.1 million shares subject to stock options, restricted stock units, restricted stock awards, and performance stock units issued and outstanding under the 2015 Plan. Restricted stock units, restricted stock awards, and performance stock units are performance-based, time-based or a combination of both and are expected to vest over one to four years. The fair value of these grants is based on the closing market price of our common stock on the date of award.

[0001633978-18-000030:notes:105]
[same as prior period, unchanged from 0001628280-18-001086:notes:99]

[0001633978-18-000030:notes:106]
As of March 31, 2018, 5.7 million shares of common stock under the 2015 Plan were available for grant.

[0001633978-18-000030:notes:107]
[same as prior period, unchanged from 0001628280-18-001086:notes:101]

[0001633978-18-000030:notes:108]
On June 23, 2015, we adopted, and the board of directors of JDSU approved, the 2015 Employee Stock Purchase Plan (the “2015 Purchase Plan”) under which 3.0 million shares of our common stock were authorized for issuance, which was ratified by our board of directors in August 2015. The 2015 Purchase Plan provides eligible employees with the opportunity to acquire an ownership interest in the Company through periodic payroll deductions and provides a 15% purchase price discount as well as a six-month look-back period. The 2015 Purchase Plan is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986. However, the 2015 Purchase Plan is not intended to be a qualified pension, profit sharing or stock bonus plan under Section 401(a) of the Internal Revenue Code of 1986 and is not subject to the provisions of the Employee Retirement Income Security Act of 1974. The 2015 Purchase Plan will terminate upon the date on which all shares available for issuance have been sold. Of the 3.0 million shares authorized under the 2015 Purchase Plan, 2.4 million shares remained available for issuance as of March 31, 2018.

[0001633978-18-000030:notes:109]
[same as prior period, unchanged from 0001628280-18-001086:notes:103]

[0001633978-18-000030:notes:110]
Restricted stock units (“RSUs”) under the 2015 Plan are grants of shares of our common stock valued at fair value based on the closing price of our common stock on the date of grant. RSUs result in a payment to a holder if any performance goals or other vesting criteria are achieved or the awards otherwise vest. Generally, our RSUs have service conditions and are expected to vest over one to four years.

[0001633978-18-000030:notes:111]
[same as prior period, unchanged from 0001628280-18-001086:notes:105]

[0001633978-18-000030:notes:112]
[same as prior period, unchanged from 0001628280-18-001086:notes:106]

[0001633978-18-000030:notes:113]
[same as prior period, unchanged from 0001628280-18-001086:notes:107]

[0001633978-18-000030:notes:114]
Performance stock units (“PSUs”) under the 2015 Plan are grants of shares of our common stock that vest upon the achievement of certain performance and service conditions. We begin recognizing compensation expense when we conclude that it is probable that the performance conditions will be achieved. We reassess the probability of vesting at each reporting period and adjust our compensation cost based on this probability assessment. Our PSUs are subject to risk of forfeiture until performance and service conditions are satisfied and generally vest over three years.

[0001633978-18-000030:notes:115]
During the nine months ended March 31, 2018, we granted 116,788 PSUs to senior members of our management team and recorded $1.6 million expense related to these grants based on the revenue performance condition that is expected to be achieved.   During the three months ended March 31, 2018, we recorded $0.4 million expense related to these grants.

[0001633978-18-000030:notes:116]
[same as prior period, unchanged from 0001628280-18-001086:notes:110]

[0001633978-18-000030:notes:117]
The impact on our results of operations of recording stock-based compensation by function for the three and nine months ended March 31, 2018 and April 1, 2017 was as follows (in millions):

[0001633978-18-000030:notes:118]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |
| Cost of sales | $ | 2.4 |  |  | $ | 1.9 |  |  | $ | 9.5 |  |  | $ | 6.0 |  |
| Research and development | 3.6 |  |  | 3.0 |  |  | 10.5 |  |  | 8.8 |  |
| Selling, general and administrative | 5.0 |  |  | 3.2 |  |  | 15.1 |  |  | 10.2 |  |
|  | $ | 11.0 |  |  | $ | 8.1 |  |  | $ | 35.1 |  |  | $ | 25.0 |  |

[0001633978-18-000030:notes:119]
Approximately $2.1 million and $1.8 million of stock-based compensation was capitalized to inventory as of March 31, 2018 and July 1, 2017, respectively.

[0001633978-18-000030:notes:120]
[same as prior period, unchanged from 0001628280-18-001086:notes:114]

[0001633978-18-000030:notes:121]
We did not grant any stock options during the three and nine months ended March 31, 2018 and April 1, 2017. During the nine months ended March 31, 2018, there were 41,727 options exercised. No options were exercised during the three months ended March 31, 2018.

[0001633978-18-000030:notes:122]
As of March 31, 2018, 3,057 options were outstanding under the 2015 Plan. During the nine months ended March 31, 2018, the total intrinsic value of options exercised by our employees was $0.8 million. The total intrinsic value of options exercised by our employees during the three and nine months ended April 1, 2017 was $1.0 million and $4.6 million, respectively.

[0001633978-18-000030:notes:123]
In connection with these exercises, the tax benefit realized during the three and nine months ended April 1, 2017 was $2.3 million and $5.2 million, respectively. During the three and nine months ended March 31, 2018, due to adoption of ASU 2016-09, all excess tax benefits and deficiencies were recognized in the income tax provision in the condensed consolidated statements of operations, rather than in additional paid-in-capital in the condensed consolidated balance sheets. Refer to “Note 1. Description of Business and Summary of Significant Accounting Policies” in the Notes to Unaudited Condensed Consolidated Financial Statements for further discussion on the impact of the adoption of ASU 2016-09.

[0001633978-18-000030:notes:124]
The following table summarizes our awards activity for the nine months ended March 31, 2018 (in millions, except per share amounts):

[0001633978-18-000030:notes:125]
|  | Restricted Stock Units |  | Restricted Stock Awards |  | Performance Stock Units |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Unvested balance as of beginning of period | 1.9 |  |  | $ | 28.04 |  |  | 0.3 |  |  | $ | 32.51 |  |  | — |  |  | $ | — |  |
| Granted | 1.0 |  |  | 53.35 |  |  | — |  |  | — |  |  | 0.1 |  |  | 52.00 |  |
| Vested | (0.9 | ) |  | 26.60 |  |  | (0.1 | ) |  | 32.51 |  |  | — |  |  | — |  |
| Canceled | (0.2 | ) |  | 38.23 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Unvested balance as of end of period | 1.8 |  |  | $ | 43.08 |  |  | 0.2 |  |  | $ | 32.51 |  |  | 0.1 |  |  | $ | 52.00 |  |

[0001633978-18-000030:notes:126]
As of March 31, 2018, $72.5 million of stock-based compensation cost related to awards granted to our employees remains to be amortized. That cost is expected to be recognized over an estimated amortization period of 1.8 years.

[0001633978-18-000030:notes:127]
[same as prior period, unchanged from 0001628280-18-001086:notes:120]

[0001633978-18-000030:notes:128]
The 2015 Purchase Plan expense for the three and nine months ended March 31, 2018 was $0.8 million and $2.4 million, respectively. The expense related to the 2015 Purchase Plan is recorded on a straight-line basis over the relevant subscription period. During the nine months ended March 31, 2018, there were 93,044 shares issued to employees through the 2015 Purchase Plan in one offering period from May 16, 2017 to November 15, 2017.

[0001633978-18-000030:notes:129]
The 2015 Purchase Plan expense for the three and nine months ended April 1, 2017 was $0.7 million and $2.0 million, respectively. During the nine months ended April 1, 2017, there were 188,864 shares issued to employees through the 2015 Purchase Plan in one offering period from May 16, 2016 to November 15, 2016.

[0001633978-18-000030:notes:130]
We estimate the fair value of the 2015 Purchase Plan shares on the date of grant using the Black-Scholes option-pricing model. The assumptions used to estimate the fair value of the 2015 Purchase Plan shares to be issued during the nine months ended March 31, 2018 and April 1, 2017 were as follows:

[0001633978-18-000030:notes:131]
|  | March 31, 2018 |  | April 1, 2017 |
| Expected term (years) | 0.5 |  |  | 0.5 |  |
| Expected volatility | 49.9 | % |  | 46.0 | % |
| Risk-free interest rate | 1.42 | % |  | 0.62 | % |
| Dividend yield | — | % |  | — | % |


## us-gaap:EarningsPerShareTextBlock

[0001633978-18-000030:notes:132]
[same as prior period, unchanged from 0001628280-18-001086:notes:125]

[0001633978-18-000030:notes:133]
[same as prior period, unchanged from 0001628280-18-001086:notes:126]

[0001633978-18-000030:notes:134]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |
| Basic Earnings per Common Share |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) | $ | 2.7 |  |  | $ | (56.0 | ) |  | $ | 214.6 |  |  | $ | (47.6 | ) |
| Less: Cumulative dividends on Series A Preferred Stock | (0.2 | ) |  | (0.2 | ) |  | (0.7 | ) |  | (0.6 | ) |
| Less: Earnings allocated to Series A Preferred Stock | (0.1 | ) |  | — |  |  | (4.9 | ) |  | — |  |
| Net income (loss) attributable to common stockholders - basic | $ | 2.4 |  |  | $ | (56.2 | ) |  | $ | 209.00 |  |  | $ | (48.2 | ) |
| Weighted average common shares outstanding including Series A Preferred Stock | 63.9 |  |  | 62.5 |  |  | 63.6 |  |  | 61.9 |  |
| Less: Weighted average Series A Preferred Stock | (1.5 | ) |  | (1.5 | ) |  | (1.5 | ) |  | (1.5 | ) |
| Basic weighted average common shares outstanding | 62.4 |  |  | 61.0 |  |  | 62.1 |  |  | 60.4 |  |
| Net income (loss) per share attributable to common stockholders - basic | $ | 0.04 |  |  | $ | (0.92 | ) |  | $ | 3.37 |  |  | $ | (0.80 | ) |
| Diluted Earnings per Common Share |  |  |  |  |  |  |  |
| Net income (loss) attributable to common stockholders - diluted | $ | 2.4 |  |  | $ | (56.2 | ) |  | $ | 209.0 |  |  | $ | (48.2 | ) |
| Weighted average common shares outstanding for basic earnings per common share | 62.4 |  |  | 61.0 |  |  | 62.1 |  |  | 60.4 |  |
| Effect of dilutive securities from stock-based benefit plans | 0.9 |  |  | — |  |  | 1.1 |  |  | — |  |
| Effect of diluted securities from Series A Preferred Stock | — |  |  | — |  |  | — |  |  | — |  |
| Diluted weighted average common shares outstanding | 63.3 |  |  | 61.0 |  |  | 63.2 |  |  | 60.4 |  |
| Net income (loss) per share attributable to common stockholders - diluted | $ | 0.04 |  |  | $ | (0.92 | ) |  | $ | 3.31 |  |  | $ | (0.80 | ) |

[0001633978-18-000030:notes:135]
Our Series A Preferred Stock is considered a participating security, which may participate in undistributed earnings with our common stock. The holders of our Preferred Stock would be entitled to share in dividends, on an as-converted basis, if the holders of our common stock were to receive dividends. We are required to use the two-class method when computing earnings per share as we have a security that qualifies as a participating security. The two-class method is an earnings allocation formula that determines earnings per share for each class of common stock and participating security according to dividends declared (or accumulated) and participation rights in undistributed earnings. In determining the amount of net earnings to allocate to common stockholders, earnings are allocated to both common and participating securities based on their respective weighted-average shares outstanding during the period. Diluted earnings per common share, when applicable, is computed using the more dilutive of the two-class method or the if-converted method. In periods of net loss, no effect is given to participating securities since they do not contractually participate in the losses of the Company.

[0001633978-18-000030:notes:136]
[same as prior period, unchanged from 0001628280-18-001086:notes:129]

[0001633978-18-000030:notes:137]
In March 2017, we issued $450 million in aggregate principal amount of 0.25% Convertible Senior Notes due in 2024 (the “2024 Notes”). We have the ability and intent to settle the $450 million face value of the 2024 Notes in cash. Therefore, we use the treasury stock method for calculating the dilutive impact of the 2024 Notes. The 2024 Notes will have no impact to diluted earnings per share until the average price of our common stock exceeds the conversion price of $60.62. Refer to “Note 10. Convertible Senior Notes” for further discussion.

[0001633978-18-000030:notes:138]
For the three and nine months ended March 31, 2018 and April 1, 2017, the number of shares related to our stock-based benefit plans that were excluded from the calculation of diluted shares was not material.


## us-gaap:FairValueDisclosuresTextBlock

[0001633978-18-000030:notes:139]
Note 8. Fair Value Measurements

[0001633978-18-000030:notes:140]
[same as prior period, unchanged from 0001628280-18-001086:notes:134]

[0001633978-18-000030:notes:141]
[same as prior period, unchanged from 0001628280-18-001086:notes:135]

[0001633978-18-000030:notes:142]
[same as prior period, unchanged from 0001628280-18-001086:notes:136]

[0001633978-18-000030:notes:143]
We estimate the fair value of the embedded derivative for the Series A Preferred Stock using the binomial lattice model. The lattice model requires the various assumptions to be made to determine the fair value of the embedded derivatives. These assumptions represent Level 3 inputs. Refer to “Note 11. Derivative Liability” in the Notes to Unaudited Condensed Consolidated Financial Statements.

[0001633978-18-000030:notes:144]
In February 2017, we completed the acquisition of a privately held company to enhance our manufacturing and vertical integration capabilities for a total purchase consideration of $8.7 million. We estimated the fair value of our Level 3 contingent consideration related to this acquisition at the present value of the expected contingent payments, determined using a probabilistic approach. We are required to reassess the fair value of contingent payments on a periodic basis. During the three months ended April 1, 2017, we estimated the likelihood of meeting the production targets at 90 percent. There was no change in the fair value of our contingent consideration during the three and nine months ended March 31, 2018. The fair value of such contingent consideration is recorded in accrued liabilities on the condensed consolidated balance sheet as of March 31, 2018. This contingent consideration will result in a cash payment of $3.0 million, if and when the production targets are achieved, which we expect to occur within 36 months following the acquisition date.

[0001633978-18-000030:notes:145]
[same as prior period, unchanged from 0001628280-18-001086:notes:139]

[0001633978-18-000030:notes:146]
[same as prior period, unchanged from 0001628280-18-001086:notes:140]

[0001633978-18-000030:notes:147]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| March 31, 2018: |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | — |  |  | $ | 29.1 |  |  | $ | — |  |  | $ | 29.1 |  |
| Corporate debt securities | — |  |  | 26.0 |  |  | — |  |  | 26.0 |  |
| Money market funds | 2.5 |  |  | — |  |  | — |  |  | 2.5 |  |
| Municipal bonds | — |  |  | 1.5 |  |  | — |  |  | 1.5 |  |
| Foreign government bonds | — |  |  | 2.0 |  |  | — |  |  | 2.0 |  |
| U.S. Treasury | 26.7 |  |  | — |  |  | — |  |  | 26.7 |  |
| Asset-backed securities | — |  |  | 6.4 |  |  | — |  |  | 6.4 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 32.0 |  |  | — |  |  | 32.0 |  |
| Commercial paper | — |  |  | 35.1 |  |  | — |  |  | 35.1 |  |
| Asset-backed securities | — |  |  | 114.0 |  |  | — |  |  | 114.0 |  |
| Corporate debt securities | — |  |  | 315.9 |  |  | — |  |  | 315.9 |  |
| Municipal bonds | — |  |  | 6.2 |  |  | — |  |  | 6.2 |  |
| Mortgage-backed securities | — |  |  | 4.8 |  |  | — |  |  | 4.8 |  |
| Foreign government bonds | — |  |  | 8.0 |  |  | — |  |  | 8.0 |  |
| Total assets | $ | 29.2 |  |  | $ | 581.0 |  |  | $ | — |  |  | $ | 610.2 |  |
| Other accrued liabilities: |  |  |  |  |  |  |  |
| Derivative liability | $ | — |  |  | $ | — |  |  | $ | 60.2 |  |  | $ | 60.2 |  |
| Acquisition contingencies | — |  |  | — |  |  | 2.7 |  |  | 2.7 |  |
| Total other accrued liabilities | $ | — |  |  | $ | — |  |  | $ | 62.9 |  |  | $ | 62.9 |  |

[0001633978-18-000030:notes:148]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| July 1, 2017: |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | — |  |  | $ | 52.1 |  |  | $ | — |  |  | $ | 52.1 |  |
| Commercial paper | — |  |  | 14.7 |  |  | — |  |  | 14.7 |  |
| Money market funds | 4.8 |  |  | — |  |  | — |  |  | 4.8 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 202.1 |  |  | — |  |  | 202.1 |  |
| Asset-backed securities | — |  |  | 26.1 |  |  | — |  |  | 26.1 |  |
| Corporate debt securities | — |  |  | 46.4 |  |  | — |  |  | 46.4 |  |
| Municipal bonds | — |  |  | 4.9 |  |  | — |  |  | 4.9 |  |
| Foreign government bonds | — |  |  | 1.0 |  |  | — |  |  | 1.0 |  |
| U.S. Treasury | 1.9 |  |  | — |  |  | — |  |  | 1.9 |  |
| Total assets | $ | 6.7 |  |  | $ | 347.3 |  |  | $ | — |  |  | $ | 354.0 |  |
| Other accrued liabilities: |  |  |  |  |  |  |  |
| Derivative liability | $ | — |  |  | $ | — |  |  | $ | 51.6 |  |  | $ | 51.6 |  |
| Acquisition contingencies | — |  |  | — |  |  | 2.7 |  |  | 2.7 |  |
| Total other accrued liabilities | $ | — |  |  | $ | — |  |  | $ | 54.3 |  |  | $ | 54.3 |  |

[0001633978-18-000030:notes:149]
[same as prior period, unchanged from 0001628280-18-001086:notes:142]

[0001633978-18-000030:notes:150]
[same as prior period, unchanged from 0001628280-18-001086:notes:143]

[0001633978-18-000030:notes:151]
Management utilizes various valuation methods, including an income approach, a market approach and a cost approach, to estimate the fair value of intangible and other long-lived assets. During the annual impairment testing performed in fiscal 2017, all our intangible and other long-lived assets passed Step 1. No impairment charges were recorded in fiscal 2017 or during the three and nine months ended March 31, 2018. Refer to “Note 12. Goodwill and Other Intangible Assets”.


## us-gaap:FiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0001633978-18-000030:notes:152]
The following table presents details of amortization for the periods presented (in millions):

[0001633978-18-000030:notes:153]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |
| Cost of sales | $ | 0.8 |  |  | $ | 1.7 |  |  | $ | 2.4 |  |  | $ | 5.1 |  |
| Operating expenses | — |  |  | 0.1 |  |  | — |  |  | 0.3 |  |
| Total | $ | 0.8 |  |  | $ | 1.8 |  |  | $ | 2.4 |  |  | $ | 5.4 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001633978-18-000030:notes:154]
Note 12. Goodwill and Other Intangible Assets

[0001633978-18-000030:notes:155]
[same as prior period, unchanged from 0001628280-18-001086:notes:149]

[0001633978-18-000030:notes:156]
The following table presents the changes in goodwill by our reportable segments during the nine months ended March 31, 2018 (in millions):

[0001633978-18-000030:notes:157]
|  | Optical Communications |  | Commercial Lasers |  | Total |
| Balance as of beginning of period | $ | 5.9 |  |  | $ | 5.5 |  |  | $ | 11.4 |  |
| Foreign currency translation adjustment | 0.4 |  |  | — |  |  | 0.4 |  |
| Balance as of end of period | $ | 6.3 |  |  | $ | 5.5 |  |  | $ | 11.8 |  |

[0001633978-18-000030:notes:158]
[same as prior period, unchanged from 0001628280-18-001086:notes:152]

[0001633978-18-000030:notes:159]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. In the fourth quarter of fiscal 2017, we completed the annual impairment test of goodwill, which indicated there was no goodwill impairment. During the three and nine months ended March 31, 2018, there have been no events or circumstances that have required us to perform an interim assessment of goodwill for impairment.

[0001633978-18-000030:notes:160]
[same as prior period, unchanged from 0001628280-18-001086:notes:154]

[0001633978-18-000030:notes:161]
The following tables present details of our acquired developed technology and other intangibles (in millions):

[0001633978-18-000030:notes:162]
| As of March 31, 2018 | Gross Carrying Amount |  | Accumulated Amortization |  | Net |
| Acquired developed technology | $ | 105.9 |  |  | $ | (97.8 | ) |  | $ | 8.1 |  |
| Other | 9.4 |  |  | (9.4 | ) |  | — |  |
| Total Intangibles | $ | 115.3 |  |  | $ | (107.2 | ) |  | $ | 8.1 |  |

[0001633978-18-000030:notes:163]
[same as prior period, unchanged from 0001628280-18-001086:notes:157]

[0001633978-18-000030:notes:164]
The amounts in the table above include cumulative foreign currency translation adjustments, reflecting movement in the currencies of the underlying intangibles.

[0001633978-18-000030:notes:165]
During the three and nine months ended March 31, 2018, we recorded $0.8 million and $2.4 million, respectively, of amortization related to acquired developed technology.

[0001633978-18-000030:notes:166]
During the three and nine months ended April 1, 2017, we recorded $1.8 million and $5.4 million, respectively, of amortization related to acquired developed technology and other intangibles.

[0001633978-18-000030:notes:167]
Based on the carrying amount of acquired developed technology and other intangibles as of March 31, 2018, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001633978-18-000030:notes:168]
| Fiscal Years |  |
| Remainder of 2018 | $ | 0.8 |  |
| 2019 | 3.1 |  |
| 2020 | 3.0 |  |
| 2021 | 0.5 |  |
| 2022 | 0.5 |  |
| Thereafter | 0.2 |  |
| Total amortization | $ | 8.1 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001633978-18-000030:notes:169]
Note 14. Income Taxes

[0001633978-18-000030:notes:170]
[same as prior period, unchanged from 0001628280-18-001086:notes:163]

[0001633978-18-000030:notes:171]
[same as prior period, unchanged from 0001628280-18-001086:notes:164]

[0001633978-18-000030:notes:172]
We recorded an immaterial tax benefit and a tax benefit of $112.9 million for the three and nine months ended March 31, 2018, respectively. Our tax benefit for the three months ended March 31, 2018 was less than $0.1 million primarily due to a benefit from foreign rate differential, excess windfall benefit from our stock-based compensation tax deduction, offset by the discrete impact of the non-deductible unrealized loss from the embedded derivatives for the Series A Preferred Stock. Our tax benefit for the nine months ended March 31, 2018 was primarily due to the release of our U.S. federal and certain state valuation allowances.  The benefit of this valuation allowance release was partially offset by a non-cash deferred expense associated with the change in the U.S. statutory rate as a result of the Tax Act (discussed further below) which was enacted during our second quarter of fiscal 2018.

[0001633978-18-000030:notes:173]
We recorded a tax provision of $11.6 million and $15.4 million for the three and nine months ended April 1, 2017, respectively. Our tax provision for the three and nine months ended April 1, 2017 was primarily due to the discrete impact of the non-deductible unrealized loss from the embedded derivatives for the Series A Preferred Stock and the 2024 Notes, non-deductible stock-based compensation and partially offset by foreign rate differential, R&D tax credits and the utilization of U.S. deferred tax assets that were subject to a full valuation allowance.

[0001633978-18-000030:notes:174]
[same as prior period, unchanged from 0001628280-18-001086:notes:167]

[0001633978-18-000030:notes:175]
As of each reporting date, we consider new evidence, both positive and negative, that could affect our view of the future realization of deferred tax assets. As of December 30, 2017, we determined that there is sufficient positive evidence to conclude that it is more-likely-than-not that the deferred tax assets are realizable. We, therefore, released the valuation allowance for the U.S. federal and certain states and recognized a tax benefit of $207 million as a discrete item for the fiscal second quarter of 2018. Due to the weight of negative evidence, we continue to maintain a full valuation allowance on the California deferred tax assets.

[0001633978-18-000030:notes:176]
[same as prior period, unchanged from 0001628280-18-001086:notes:169]

[0001633978-18-000030:notes:177]
[same as prior period, unchanged from 0001628280-18-001086:notes:170]

[0001633978-18-000030:notes:178]
[same as prior period, unchanged from 0001628280-18-001086:notes:171]

[0001633978-18-000030:notes:179]
[same as prior period, unchanged from 0001628280-18-001086:notes:172]

[0001633978-18-000030:notes:180]
The reduction in the U.S. federal statutory rate is expected to positively impact our federal cash tax liability.  However, the ultimate impact is subject to the effect of other complex provisions in the Tax Act (including the BEAT and GILTI), which we are currently reviewing, and it is possible that any impact of BEAT and GILTI could significantly reduce the benefit of the reduction in the U.S. federal statutory rate. Due to the uncertain practical and technical application of many of these provisions, it is currently not possible to reliably estimate whether BEAT and GILTI will apply and, if so, how it would impact us. We will continue to analyze the Tax Act to assess the full effects on our financial results for the June 30, 2018 fiscal year-end.

[0001633978-18-000030:notes:181]
[same as prior period, unchanged from 0001628280-18-001086:notes:174]

[0001633978-18-000030:notes:182]
[same as prior period, unchanged from 0001628280-18-001086:notes:175]

[0001633978-18-000030:notes:183]
[same as prior period, unchanged from 0001628280-18-001086:notes:176]

[0001633978-18-000030:notes:184]
[same as prior period, unchanged from 0001628280-18-001086:notes:177]

[0001633978-18-000030:notes:185]
As of March 31, 2018, we had $10.2 million of unrecognized tax benefits, which, if recognized, would affect the effective tax rate. We are subject to examination of income tax returns by various domestic and foreign tax authorities. The timing of resolutions and closures of tax audits is highly unpredictable. Given the uncertainty, it is reasonably possible that certain tax audits may be concluded within the next 12 months that could materially impact the balance of our gross unrecognized tax benefits. An estimate of the range of increase or decrease that could occur in the next twelve months cannot be made. However, the estimated impact to tax expense and net income from the resolution and closure of tax exams is not expected to be significant within the next 12 months.


## us-gaap:MinorityInterestDisclosureTextBlock

[0001633978-18-000030:notes:186]
Note 9. Non-Controlling Interest Redeemable Convertible Preferred Stock

[0001633978-18-000030:notes:187]
[same as prior period, unchanged from 0001628280-18-001086:notes:180]

[0001633978-18-000030:notes:188]
The Series A Preferred Stock is redeemable at the option of Amada after five years and classified as non-controlling interest redeemable convertible preferred stock in our condensed consolidated balance sheet. The Series A Preferred Stock is measured at its redemption value. The Series A Preferred Stock value of $35.8 million as of March 31, 2018 has not changed from the prior year.

[0001633978-18-000030:notes:189]
The Series A Preferred Stock conversion feature is bifurcated from the Series A Preferred Stock and accounted for separately as a derivative liability. The derivative liability is measured at fair value each reporting period with the change in fair value recorded in the condensed consolidated statements of operations. Refer to “Note 11. Derivative Liability”.

[0001633978-18-000030:notes:190]
[same as prior period, unchanged from 0001628280-18-001086:notes:183]

[0001633978-18-000030:notes:191]
[same as prior period, unchanged from 0001628280-18-001086:notes:184]

[0001633978-18-000030:notes:192]
[same as prior period, unchanged from 0001628280-18-001086:notes:185]

[0001633978-18-000030:notes:193]
[same as prior period, unchanged from 0001628280-18-001086:notes:186]

[0001633978-18-000030:notes:194]
[same as prior period, unchanged from 0001628280-18-001086:notes:187]

[0001633978-18-000030:notes:195]
[same as prior period, unchanged from 0001628280-18-001086:notes:188]

[0001633978-18-000030:notes:196]
[same as prior period, unchanged from 0001628280-18-001086:notes:189]

[0001633978-18-000030:notes:197]
[same as prior period, unchanged from 0001628280-18-001086:notes:190]

[0001633978-18-000030:notes:198]
[same as prior period, unchanged from 0001628280-18-001086:notes:191]

[0001633978-18-000030:notes:199]
[same as prior period, unchanged from 0001628280-18-001086:notes:192]

[0001633978-18-000030:notes:200]
[same as prior period, unchanged from 0001628280-18-001086:notes:193]

[0001633978-18-000030:notes:201]
[same as prior period, unchanged from 0001628280-18-001086:notes:194]

[0001633978-18-000030:notes:202]
[same as prior period, unchanged from 0001628280-18-001086:notes:195]

[0001633978-18-000030:notes:203]
The accrued dividends as of March 31, 2018 and July 1, 2017 were $0.2 million and $0.2 million, respectively.

[0001633978-18-000030:notes:204]
Dividends paid were $0.5 million and $0.7 million for the three and nine months ended March 31, 2018, respectively, and $0.2 million and $0.6 million for the three and nine months ended April 1, 2017, respectively.

[0001633978-18-000030:notes:205]
[same as prior period, unchanged from 0001628280-18-001086:notes:197]

[0001633978-18-000030:notes:206]
[same as prior period, unchanged from 0001628280-18-001086:notes:198]

[0001633978-18-000030:notes:207]
On or after the third anniversary in August 2018, we will have the option to redeem for cash all (but not less than all) of the shares of Series A Preferred Stock at a redemption price equal to the Issuance Value plus the accrued and unpaid dividends on each share and any past due dividends, whether or not authorized or declared.

[0001633978-18-000030:notes:208]
[same as prior period, unchanged from 0001628280-18-001086:notes:200]

[0001633978-18-000030:notes:209]
[same as prior period, unchanged from 0001628280-18-001086:notes:201]


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001633978-18-000030:notes:210]
In January 2017, the Financial Accounting Standards Board (“FASB”) issued ASU 2017-01, Business Combinations (Topic 805), which clarifies the definition of a business. For accounting and financial reporting purposes, businesses are generally comprised of three elements; inputs, processes, and outputs. Integrated sets of assets and activities capable of providing these three elements may not always be considered a business, and the lack of one of the three elements does not always disqualify the set from being a business. The issuance of ASU 2017-01 provides a clarifying screen to determine when a set of assets and activities is not a business. Primarily, the screen requires that when substantially all of the fair value of the gross assets acquired is concentrated in a single identifiable asset or group of similar identifiable assets, the set is not a business. The amendments contained in ASU 2017-01 are effective for annual periods beginning after December 15, 2017, including interim periods within those periods. The accounting standard update will be effective for us beginning in the first quarter of fiscal 2019 and should be applied prospectively. We do not believe the implementation of ASU 2017-01 will have a material impact on our condensed consolidated financial statements.

[0001633978-18-000030:notes:211]
In January 2017, FASB issued ASU 2017-04, Intangibles - Goodwill and Other (Topic 350): Simplifying the Accounting for Goodwill Impairment. ASU 2017-04 removes the requirement to perform a hypothetical purchase price allocation to measure goodwill impairment. A goodwill impairment charge will be the amount by which a reporting unit's carrying value exceeds its fair value, not to exceed the carrying amount of goodwill. The amendments contained in ASU 2017-04 are effective for interim and annual periods beginning after December 15, 2019, with early adoption permitted, which should be applied prospectively. We plan to adopt the accounting standard update in our first quarter of fiscal 2019. We do not believe the implementation of ASU 2017-04 will have a material impact on our condensed consolidated financial statements.

[0001633978-18-000030:notes:212]
In August 2016, FASB issued ASU 2016-15, Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments, which clarifies how companies present and classify certain cash receipts and cash payments in the statement of cash flows. The amendments contained in ASU 2016-15 are effective for interim and annual periods beginning after December 15, 2017. The accounting standard update will be effective for us in the first quarter of fiscal 2019 and will be applied prospectively. If we elect to settle the principal amounts of our 2024 Notes (refer to “Note 10. Convertible Senior Notes”) in cash, the payment will be bifurcated between (i) cash outflows for operating activities of $137.6 million for the portion related to accreted interest attributable to debt discount, and (ii) financing activities for the remainder of $312.4 million.

[0001633978-18-000030:notes:213]
In February 2016, FASB issued ASU 2016-02, Leases. The new guidance generally requires an entity to recognize on its balance sheet operating and financing lease liabilities and corresponding right-of-use assets. The new guidance contained in ASU 2016-02 is effective for annual periods beginning after December 15, 2018, including interim periods within those periods, with early adoption permitted. The standard is effective for us in our first quarter of fiscal 2020 and should be applied prospectively. Based on our current lease portfolio, we estimate the value of leased assets and liabilities that may be recognized will be material. We are continuing to evaluate the impact of ASU 2016-02 and is subject to change.

[0001633978-18-000030:notes:214]
In May 2014, FASB issued ASU 2014-09, Revenue from Contracts with Customers (“ASU 2014-09”), which amended the existing accounting standards for revenue recognition. ASU 2014-09 establishes principles for recognizing revenue upon the transfer of promised goods or services to customers, in an amount that reflects the consideration expected to be received in exchange for those goods or services. The new standard requires that reporting companies disclose the nature, amount, timing and uncertainty of revenue and cash flows arising from contracts with customers. On July 9, 2015, FASB agreed to delay the effective date by one year, and accordingly, the new standard is effective for us at the beginning of the first quarter of fiscal 2019.

[0001633978-18-000030:notes:215]
The guidance to ASU 2014-09 permits two methods of adoption: retrospectively to each prior reporting period presented (full retrospective method), or retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (modified retrospective method). We selected the modified retrospective method. We do not anticipate that the adoption of ASU 2014-09 will have a material impact on our consolidated financial statements including the potential impact of the additional disclosure requirement, primarily because we will continue to recognize most revenue at a point-in-time when control transfers. This is similar to the current revenue recognition model.

[0001633978-18-000030:notes:216]
We currently recognize revenue when all four revenue recognition criteria have been met: (i) persuasive evidence of an arrangement exists, (ii) the product has been delivered or the service has been rendered, (iii) the price is fixed or determinable and (iv) collection is reasonably assured. Revenue from product sales is recorded when all of the foregoing conditions are met and risk of loss and title passes to the customer. Our products typically include a warranty and the estimated cost of product warranty claims, based on historical experience, is recorded at the time the sale is recognized. Sales to customers are generally not subject to price protection or return rights. The majority of our sales are made to OEMs, distributors, resellers and end-users.

[0001633978-18-000030:notes:217]
We are implementing changes to our accounting policies, internal controls, and disclosures to support the new standard; however, these changes will not be material.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001633978-18-000030:notes:218]
Note 13. Restructuring and Related Charges

[0001633978-18-000030:notes:219]
The following table summarizes the activity of restructuring and related charges during the three and nine months ended March 31, 2018 and April 1, 2017 (in millions):

[0001633978-18-000030:notes:220]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |
| Balance as of beginning of period | $ | 0.4 |  |  | $ | 6.0 |  |  | $ | 3.8 |  |  | $ | 5.7 |  |
| Charges | 0.1 |  |  | 3.1 |  |  | 3.8 |  |  | 10.0 |  |
| Payments | (0.5 | ) |  | (3.8 | ) |  | (7.6 | ) |  | (10.4 | ) |
| Balance as of end of period | $ | — |  |  | $ | 5.3 |  |  | $ | — |  |  | $ | 5.3 |  |

[0001633978-18-000030:notes:221]
During the three and nine months ended March 31, 2018, we recorded $0.1 million and $3.8 million, respectively, in restructuring and related charges in the condensed consolidated statements of operations, primarily attributable to costs to vacate facilities, temporary labor and employee related benefits, as well as costs for materials used in set up and production activities. We incurred no additional costs related to severance for the same periods.

[0001633978-18-000030:notes:222]
During the three and nine months ended April 1, 2017, we recorded $3.1 million and $10.0 million, respectively, in restructuring and related charges in the condensed consolidated statements of operations. Of the $3.1 million and $10.0 million charges recorded during the three and nine months ended April 1, 2017, $0.4 million and $2.2 million, respectively, was related to severance, retention, lease termination costs, and employee benefits; and $2.7 million and $7.8 million, respectively, was related to other restructuring related charges which include relocation costs, temporary labor and employee related benefits, as well as costs for materials used in set up and production activities.


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001633978-18-000030:notes:223]
Long-lived assets, namely net property, plant and equipment were identified based on the physical location of the assets in the corresponding geographic areas (in millions):

[0001633978-18-000030:notes:224]
|  | As of |
|  | March 31, 2018 |  | July 1, 2017 |
| Property, Plant and Equipment, net |  |  |  |
| United States | $ | 97.4 |  |  | $ | 88.2 |  |
| China | 76.9 |  |  | 82.5 |  |
| Thailand | 92.9 |  |  | 85.3 |  |
| Other countries | 34.6 |  |  | 17.5 |  |
| Total long-lived assets | $ | 301.8 |  |  | $ | 273.5 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001633978-18-000030:notes:225]
[same as prior period, unchanged from 0001628280-18-001086:notes:215]

[0001633978-18-000030:notes:226]
|  | March 31, 2018 |  | July 1, 2017 |
| Finished goods | $ | 93.2 |  |  | $ | 71.7 |  |
| Work in process | 30.5 |  |  | 49.4 |  |
| Raw materials and purchased parts | 20.5 |  |  | 24.1 |  |
| Inventories | $ | 144.2 |  |  | $ | 145.2 |  |


## us-gaap:ScheduleOfOtherCurrentAssetsTableTextBlock

[0001633978-18-000030:notes:227]
[same as prior period, unchanged from 0001628280-18-001086:notes:217]

[0001633978-18-000030:notes:228]
|  | March 31, 2018 |  | July 1, 2017 |
| Capitalized manufacturing overhead | $ | 23.9 |  |  | $ | 30.1 |  |
| Prepayments | 14.8 |  |  | 12.3 |  |
| Advances to contract manufacturers | 15.0 |  |  | 10.5 |  |
| Other current assets | 9.3 |  |  | 10.6 |  |
| Prepayments and other current assets | $ | 63.0 |  |  | $ | 63.5 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001633978-18-000030:notes:229]
The following table presents net revenue by the three geographic regions we operate in and net revenue from countries that represented 10% of our total net revenue (in millions, except percentage data):

[0001633978-18-000030:notes:230]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 26.8 |  |  | 9.0 | % |  | $ | 34.7 |  |  | 13.6 | % |  | $ | 86.3 |  |  | 9.1 | % |  | $ | 106.2 |  |  | 13.6 | % |
| Mexico | 41.7 |  |  | 14.0 |  |  | 70.0 |  |  | 27.4 |  |  | 97.1 |  |  | 10.3 |  |  | 158.5 |  |  | 20.3 |  |
| Other Americas | 1.5 |  |  | 0.5 |  |  | 1.5 |  |  | 0.6 |  |  | 5.7 |  |  | 0.6 |  |  | 7.4 |  |  | 1.0 |  |
| Total Americas | $ | 70.0 |  |  | 23.5 | % |  | $ | 106.2 |  |  | 41.6 | % |  | $ | 189.1 |  |  | 20.0 | % |  | $ | 272.1 |  |  | 34.9 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 38.7 |  |  | 13.0 | % |  | $ | 47.2 |  |  | 18.5 | % |  | $ | 133.3 |  |  | 14.1 | % |  | $ | 181.2 |  |  | 23.3 | % |
| China | 47.3 |  |  | 15.8 |  |  | 8.7 |  |  | 3.4 |  |  | 66.8 |  |  | 7.1 |  |  | 28.3 |  |  | 3.6 |  |
| Japan | 34.1 |  |  | 11.4 |  |  | 25.9 |  |  | 10.1 |  |  | 157.6 |  |  | 16.6 |  |  | 78.5 |  |  | 10.1 |  |
| South Korea | 28.8 |  |  | 9.6 |  |  | 2.4 |  |  | 0.9 |  |  | 126.3 |  |  | 13.3 |  |  | 3.5 |  |  | 0.4 |  |
| Other Asia-Pacific | 56.6 |  |  | 18.9 |  |  | 35.3 |  |  | 13.8 |  |  | 199.3 |  |  | 21.1 |  |  | 133.0 |  |  | 17.1 |  |
| Total Asia-Pacific | $ | 205.5 |  |  | 68.7 | % |  | $ | 119.5 |  |  | 46.7 | % |  | $ | 683.3 |  |  | 72.2 | % |  | $ | 424.5 |  |  | 54.5 | % |
| EMEA | $ | 23.3 |  |  | 7.8 | % |  | $ | 30.1 |  |  | 11.8 | % |  | $ | 74.2 |  |  | 7.8 | % |  | $ | 82.3 |  |  | 10.6 | % |
| Total net revenue | $ | 298.8 |  |  |  |  | $ | 255.8 |  |  |  |  | $ | 946.6 |  |  |  |  | $ | 778.9 |  |  |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001633978-18-000030:notes:231]
[same as prior period, unchanged from 0001628280-18-001086:notes:221]

[0001633978-18-000030:notes:232]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |
| Net revenue: |  |  |  |  |  |  |  |
| OpComms | $ | 246.3 |  |  | $ | 216.1 |  |  | $ | 814.3 |  |  | $ | 671.0 |  |
| Lasers | 52.5 |  |  | 39.7 |  |  | 132.3 |  |  | 107.9 |  |
| Net revenue | $ | 298.8 |  |  | $ | 255.8 |  |  | $ | 946.6 |  |  | $ | 778.9 |  |
| Gross profit: |  |  |  |  |  |  |  |
| OpComms | 83.1 |  |  | 71.5 |  |  | 317.1 |  |  | 229.2 |  |
| Lasers | 25.4 |  |  | 16.4 |  |  | 55.9 |  |  | 44.8 |  |
| Total segment gross profit | 108.5 |  |  | 87.9 |  |  | 373.0 |  |  | 274.0 |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Stock-based compensation | (2.4 | ) |  | (1.9 | ) |  | (9.5 | ) |  | (6.0 | ) |
| Amortization of intangibles | (0.8 | ) |  | (1.7 | ) |  | (2.4 | ) |  | (5.1 | ) |
| Other charges (1) | (8.3 | ) |  | (2.2 | ) |  | (24.5 | ) |  | (12.1 | ) |
| Gross profit | $ | 97.0 |  |  | $ | 82.1 |  |  | $ | 336.6 |  |  | $ | 250.8 |  |

[0001633978-18-000030:notes:233]
(1) The increase in “Other charges” of unallocated corporate items during the three months ended March 31, 2018 compared to the three months ended April 1, 2017, primarily relates to set-up costs of our facility in Thailand, including costs of transferring product lines to Thailand. The increase in “Other charges” of unallocated corporate items during the nine months ended March 31, 2018 compared to the nine months ended April 1, 2017, primarily relates to set-up costs of our facility in Thailand, including costs of transferring product lines to Thailand, as well as inventory write-downs due to canceled programs not allocated to the segments.


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001633978-18-000030:notes:234]
During the three and nine months ended March 31, 2018 and April 1, 2017, net revenue generated from a single end customer which represented 10% or greater of total net revenue is summarized as follows:

[0001633978-18-000030:notes:235]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |
| Customer A | 25.0 | % |  | * |  |  | 33.0 | % |  | * |  |
| Customer B | 12.0 | % |  | 12.0 | % |  | 11.0 | % |  | 18.0 | % |
| Customer C | 13.0 | % |  | 27.0 | % |  | * |  |  | 20.0 | % |
| Customer D | * |  |  | * |  |  | * |  |  | 12.0 | % |
| *Represents less than 10% of total net revenue |  |  |  |  |  |  |  |

[0001633978-18-000030:notes:236]
During the three and nine months ended March 31, 2018 and April 1, 2017, net inventory purchased from a single contract manufacturer which represented 10% or greater of total net purchases is summarized as follows:

[0001633978-18-000030:notes:237]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |
| Vendor A | 48.0 | % |  | 50.0 | % |  | 42.0 | % |  | 52.0 | % |
| Vendor B | 19.0 | % |  | 26.0 | % |  | 19.0 | % |  | 26.0 | % |
| Vendor C | 18.0 | % |  | * |  |  | 23.0 | % |  | * |  |
| Vendor D | * |  |  | 16.0 | % |  | * |  |  | 14.0 | % |
| *Represents less than 10% of total net purchases |  |  |  |  |  |  |  |

[0001633978-18-000030:notes:238]
The table below discloses the percentage of our total net revenue attributable to each of our two reportable segments. In addition, it discloses the percentage of our total net revenue attributable to our product offerings which serve the Telecom, Datacom and Consumer and Industrial markets which accounted for 10% or more of our total net revenue:

[0001633978-18-000030:notes:239]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |
| OpComms: | 82.4 | % |  | 84.5 | % |  | 86.0 | % |  | 86.1 | % |
| Telecom | 41.0 | % |  | 64.5 | % |  | 36.3 | % |  | 63.0 | % |
| Datacom | 12.1 | % |  | 15.2 | % |  | 12.2 | % |  | 19.4 | % |
| Consumer and Industrial | 29.3 | % |  | 4.8 | % |  | 37.5 | % |  | 3.7 | % |
| Lasers | 17.6 | % |  | 15.5 | % |  | 14.0 | % |  | 13.9 | % |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001633978-18-000030:notes:240]
Note 17. Operating Segments and Geographic Information

[0001633978-18-000030:notes:241]
[same as prior period, unchanged from 0001628280-18-001086:notes:231]

[0001633978-18-000030:notes:242]
[same as prior period, unchanged from 0001628280-18-001086:notes:232]

[0001633978-18-000030:notes:243]
[same as prior period, unchanged from 0001628280-18-001086:notes:233]

[0001633978-18-000030:notes:244]
We operate in three geographic regions: Americas, Asia-Pacific, and EMEA (Europe, Middle East, and Africa). Net revenue is assigned to the geographic region and country where our product is initially shipped. For example, certain customers may request shipment of our product to a contract manufacturer in one country, which may differ from the location of their end customers. The following table presents net revenue by the three geographic regions we operate in and net revenue from countries that represented 10% of our total net revenue (in millions, except percentage data):

[0001633978-18-000030:notes:245]
We purchase a substantial portion of our inventory from contract manufacturers and vendors located primarily in Taiwan, Thailand, and China. During the three and nine months ended March 31, 2018 and April 1, 2017, net inventory purchased from a single contract manufacturer which represented 10% or greater of total net purchases is summarized as follows:


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001633978-18-000030:notes:246]
Note 6. Balance Sheet Details

[0001633978-18-000030:notes:247]
[same as prior period, unchanged from 0001628280-18-001086:notes:237]

[0001633978-18-000030:notes:248]
As of March 31, 2018 and July 1, 2017, our accounts receivable allowance balance was $1.8 million and $1.8 million, respectively.

[0001633978-18-000030:notes:249]
[same as prior period, unchanged from 0001628280-18-001086:notes:239]

[0001633978-18-000030:notes:250]
[same as prior period, unchanged from 0001628280-18-001086:notes:240]

[0001633978-18-000030:notes:251]
[same as prior period, unchanged from 0001628280-18-001086:notes:241]

[0001633978-18-000030:notes:252]
During the three and nine months ended March 31, 2018, we recorded depreciation expense of $18.4 million and $53.3 million, respectively. During the three and nine months ended April 1, 2017, we recorded a depreciation expense of $14.1 million and $39.1 million, respectively.

[0001633978-18-000030:notes:253]
Our construction in progress primarily includes machinery and equipment that were purchased in order to increase our manufacturing capacity. We expect to place these assets in service in the next 12 months.

[0001633978-18-000030:notes:254]
[same as prior period, unchanged from 0001628280-18-001086:notes:244]

[0001633978-18-000030:notes:255]
[same as prior period, unchanged from 0001628280-18-001086:notes:245]
