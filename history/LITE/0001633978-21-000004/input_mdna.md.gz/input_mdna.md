# LITE MD&A — 0001633978-21-000004


## mdna

[0001633978-21-000004:mdna:1]
[same as prior period, unchanged from 0001633978-20-000018:mdna:1]

[0001633978-21-000004:mdna:2]
[same as prior period, unchanged from 0001633978-20-000018:mdna:2]

[0001633978-21-000004:mdna:3]
[same as prior period, unchanged from 0001633978-20-000018:mdna:3]

[0001633978-21-000004:mdna:4]
[same as prior period, unchanged from 0001633978-20-000018:mdna:4]

[0001633978-21-000004:mdna:5]
[same as prior period, unchanged from 0001633978-20-000018:mdna:5]

[0001633978-21-000004:mdna:6]
[same as prior period, unchanged from 0001633978-20-000018:mdna:6]

[0001633978-21-000004:mdna:7]
Acquisition of Coherent

[0001633978-21-000004:mdna:8]
On January 18, 2021, we entered into a merger agreement (the “Merger Agreement”) with Coherent, Inc. (“Coherent”), under which we will acquire all outstanding shares of Coherent common stock. Each share of Coherent common stock will be exchanged for $100 in cash and 1.1851 shares of our common stock, subject to the terms of the Merger Agreement. As of the date of the Merger Agreement, the total transaction consideration is approximately $5.7 billion. Coherent stockholders will own approximately 27% of the combined company at closing.

[0001633978-21-000004:mdna:9]
The total transaction consideration will be funded by a combination of approximately $3.2 billion in our common stock  (based on the closing price of Lumentum common stock on the date preceding the Merger Agreement), $2.1 billion in new debt, and the remaining amount from the cash balances of the combined company. We entered into a commitment letter with Deutsche Bank Securities Inc. and Deutsche Bank AG New York Branch (collectively, “Deutsche Bank”), pursuant to which, subject to the terms and conditions set forth therein, Deutsche Bank has committed to provide a senior secured term loan facility in an aggregate principal amount of up to $2.1 billion.

[0001633978-21-000004:mdna:10]
Our board of directors and the board of directors of Coherent have unanimously approved the transaction and the Merger Agreement. The transaction is subject to customary closing conditions, including regulatory approvals and approval by the stockholders of Coherent and Lumentum, and is expected to be completed in the second half of calendar 2021. The transaction is not subject to any financing condition.

[0001633978-21-000004:mdna:11]
[same as prior period, unchanged from 0001633978-20-000018:mdna:7]

[0001633978-21-000004:mdna:12]
The outbreak of the COVID-19 has been declared a pandemic by the World Health Organization and continues to spread globally. The spread of COVID-19 has caused public health officials to recommend, and governments to enact, precautions to mitigate the spread of the virus, including travel restrictions and bans, extensive social distancing guidelines, closure or restrictions on business and quarantine or other types of “shelter-in-place” orders in many regions of the world and issuing a “shelter-in-place” order in many regions of the world. The pandemic and these related responses have caused, and are expected to continue to cause a global slowdown of economic activity (including a decrease in demand for a broad variety of goods and services), disruptions in global supply chains and significant volatility and disruption of financial markets. We have adopted several measures in response to the COVID-19 outbreak including complying with local, state or federal orders that require employees to work from home, instructing employees to work from home in certain jurisdictions, limiting the number of employees onsite which slowed our manufacturing operations in certain countries, enhanced use of personal protective equipment and restricting non-critical business travel by our employees.

[0001633978-21-000004:mdna:13]
In the geographies we have operations, we have, in general, been deemed an essential business and been permitted to continue manufacturing and new product development operations in a more limited capacity during the pandemic. This stems from our critical role in global supply chains for the world’s communications and health-care systems. Given the rapidly evolving situation, it is difficult to predict the magnitude and duration of the impact of the COVID-19 pandemic to our markets or precisely when our ability to supply our products will return to full capacity. We are continuing to actively monitor the situation and may take further actions altering our business operations that we determine are in the best interests of our employees, customers, communities, business partners, suppliers, and stockholders, or as required by federal, state, or local authorities. It is not clear what the potential effects any such alterations or modifications may have on our business, including the effects on our customers, employees, and prospects, or on our financial results for fiscal year 2021.

[0001633978-21-000004:mdna:14]
While the recent outbreak of the COVID-19 did not have a material adverse effect on our reported results for our second quarter of fiscal 2021, we are actively monitoring the impact of the coronavirus outbreak. The extent to which our operations will be impacted by the outbreak will depend largely on future developments, which are highly uncertain and cannot be accurately predicted, including new information which may emerge concerning the severity of the outbreak, the speed and efficacy of a vaccine distribution, actions by government authorities and private businesses to contain the severity of the outbreak in various geographies and the speed and trajectory of any recovery from the impact of the pandemic, among other things.

[0001633978-21-000004:mdna:15]
[same as prior period, unchanged from 0001633978-20-000018:mdna:11]

[0001633978-21-000004:mdna:16]
[same as prior period, unchanged from 0001633978-20-000018:mdna:12]

[0001633978-21-000004:mdna:17]
[same as prior period, unchanged from 0001633978-20-000018:mdna:13]

[0001633978-21-000004:mdna:18]
[same as prior period, unchanged from 0001633978-20-000018:mdna:14]

[0001633978-21-000004:mdna:19]
[same as prior period, unchanged from 0001633978-20-000018:mdna:15]

[0001633978-21-000004:mdna:20]
•Inventory Valuation

[0001633978-21-000004:mdna:21]
•Revenue Recognition

[0001633978-21-000004:mdna:22]
•Income Taxes

[0001633978-21-000004:mdna:23]
•Goodwill

[0001633978-21-000004:mdna:24]
Management’s Discussion and Analysis of Financial Condition and Results of Operations contained in Part II, Item 7 of our Annual Report on Form 10-K for our fiscal year ended June 27, 2020 provides a more complete discussion of our critical accounting policies and estimates. There have been no significant changes to these policies during the six months ended December 26, 2020, except for the removal of the long-lived asset valuation policy and the updates resulting from the adoption of Topic 326, as discussed in “Note 2. Recently Issued Accounting Pronouncements”.

[0001633978-21-000004:mdna:25]
Recently Issued Accounting Pronouncements

[0001633978-21-000004:mdna:26]
Refer to “Note 2. Recently Issued Accounting Pronouncements” in the notes to condensed consolidated financial statements.

[0001633978-21-000004:mdna:27]
[same as prior period, unchanged from 0001633978-20-000018:mdna:23]

[0001633978-21-000004:mdna:28]
[same as prior period, unchanged from 0001633978-20-000018:mdna:24]

[0001633978-21-000004:mdna:29]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26, 2020 |  | December 28, 2019 |  | December 26, 2020 |  | December 28, 2019 |
| Segment net revenue: |  |  |  |  |  |  |  |
| OpComms | 93.8 | % |  | 89.4 | % |  | 94.2 | % |  | 90.9 | % |
| Lasers | 6.2 |  |  | 10.6 |  |  | 5.8 |  |  | 9.1 |  |
| Net revenue | 100.0 |  |  | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of sales | 48.9 |  |  | 56.0 |  |  | 50.0 |  |  | 57.9 |  |
| Amortization of acquired developed intangibles | 3.1 |  |  | 2.7 |  |  | 3.2 |  |  | 2.7 |  |
| Gross profit | 48.0 |  |  | 41.3 |  |  | 46.7 |  |  | 39.3 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 11.0 |  |  | 11.1 |  |  | 11.1 |  |  | 11.1 |  |
| Selling, general and administrative | 12.8 |  |  | 13.6 |  |  | 12.6 |  |  | 13.1 |  |
| Restructuring and related charges | — |  |  | 0.2 |  |  | — |  |  | 0.2 |  |
| Total operating expenses | 23.9 |  |  | 25.0 |  |  | 23.7 |  |  | 24.5 |  |
| Income from operations | 24.1 |  |  | 16.3 |  |  | 23.0 |  |  | 14.8 |  |
| Interest expense | (3.4) |  |  | (4.0) |  |  | (3.5) |  |  | (3.3) |  |
| Other income (expense), net | (0.2) |  |  | 0.3 |  |  | — |  |  | 0.7 |  |
| Income before income taxes | 20.5 |  |  | 12.6 |  |  | 19.5 |  |  | 12.2 |  |
| Provision for income taxes | 3.1 |  |  | 1.9 |  |  | 3.4 |  |  | 1.6 |  |
| Net income | 17.4 | % |  | 10.7 | % |  | 16.1 | % |  | 10.7 | % |

[0001633978-21-000004:mdna:30]
[same as prior period, unchanged from 0001633978-20-000018:mdna:42]

[0001633978-21-000004:mdna:31]
Financial Data for the three and six months ended December 26, 2020 and December 28, 2019

[0001633978-21-000004:mdna:32]
[same as prior period, unchanged from 0001633978-20-000018:mdna:28]

[0001633978-21-000004:mdna:33]
|  | Three Months Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | December 26, 2020 |  | December 28, 2019 |  | Change |  | Percentage Change |  | December 26, 2020 |  | December 28, 2019 |  | Change |  | Percentage Change |
| Segment net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| OpComms | $ | 449.1 |  |  | $ | 409.4 |  |  | $ | 39.7 |  |  | 9.7 | % |  | $ | 877.6 |  |  | $ | 825.5 |  |  | $ | 52.1 |  |  | 6.3 | % |
| Lasers | 29.7 |  |  | 48.4 |  |  | (18.7) |  |  | (38.6) |  |  | 53.6 |  |  | 82.2 |  |  | (28.6) |  |  | (34.8) |  |
| Net revenue | $ | 478.8 |  |  | $ | 457.8 |  |  | $ | 21.0 |  |  | 4.6 | % |  | $ | 931.2 |  |  | $ | 907.7 |  |  | $ | 23.5 |  |  | 2.6 | % |
| Gross profit | $ | 229.6 |  |  | $ | 189.1 |  |  | $ | 40.5 |  |  | 21.4 | % |  | $ | 435.3 |  |  | $ | 356.8 |  |  | $ | 78.5 |  |  | 22.0 | % |
| Gross margin | 48.0 | % |  | 41.3 | % |  |  |  |  |  | 46.7 | % |  | 39.3 | % |  |  |  |  |
| Research and development | $ | 52.8 |  |  | $ | 51.0 |  |  | $ | 1.8 |  |  | 3.5 | % |  | $ | 103.2 |  |  | $ | 100.9 |  |  | $ | 2.3 |  |  | 2.3 | % |
| Percentage of net revenue | 11.0 | % |  | 11.1 | % |  |  |  |  |  | 11.1 | % |  | 11.1 | % |  |  |  |  |
| Selling, general and administrative | $ | 61.3 |  |  | $ | 62.4 |  |  | $ | (1.1) |  |  | (1.8) | % |  | $ | 117.6 |  |  | $ | 119.1 |  |  | $ | (1.5) |  |  | (1.3) | % |
| Percentage of net revenue | 12.8 | % |  | 13.6 | % |  |  |  |  |  | 12.6 | % |  | 13.1 | % |  |  |  |  |
| Restructuring and related charges | $ | 0.2 |  |  | $ | 0.9 |  |  | $ | (0.7) |  |  | (77.8) | % |  | $ | 0.2 |  |  | $ | 2.2 |  |  | $ | (2.0) |  |  | (90.9) | % |
| Percentage of net revenue | — | % |  | 0.2 | % |  |  |  |  |  | — | % |  | 0.2 | % |  |  |  |  |

[0001633978-21-000004:mdna:34]
[same as prior period, unchanged from 0001633978-20-000018:mdna:30]

[0001633978-21-000004:mdna:35]
Net revenue increased by $21.0 million, or 4.6%, during the three months ended December 26, 2020 compared to the three months ended December 28, 2019. This increase was primarily due to the increased sales of Telecom and Datacom of $19.9 million and Consumer and Industrial of $19.8 million offset by decreased sales of Lasers of $18.7 million.

[0001633978-21-000004:mdna:36]
OpComms net revenue increased by $39.7 million, or 9.7%, during the three months ended December 26, 2020 compared to the three months ended December 28, 2019. This increase was primarily due to increased sales of Telecom, particularly line subsystems, increased sales of Datacom, particularly Datacom chips, and Consumer and Industrial, specifically 3D sensing products. This was offset by lower sales from product lines we are winding down such as Datacom transceiver modules and certain Lithium Niobate product lines.

[0001633978-21-000004:mdna:37]
Lasers net revenue decreased by $18.7 million, or 38.6%, during the three months ended December 26, 2020 compared to the three months ended December 28, 2019, primarily due to lower revenue from kilowatt class fiber lasers.

[0001633978-21-000004:mdna:38]
Net revenue increased by $23.5 million, or 2.6%, during the six months ended December 26, 2020 compared to the six months ended December 28, 2019. This increase was primarily due to the increased sales of Telecom and Datacom of $33.1 million and Consumer and Industrial of $19.0 offset by decreased sales of Lasers of $28.6 million.

[0001633978-21-000004:mdna:39]
OpComms net revenue increased by $52.1 million, or 6.3%, during the six months ended December 26, 2020 compared to the six months ended December 28, 2019. This increase was primarily due to increased sales of Datacom products, particularly Datacom chips, increased sales of Telecom, particularly line subsystems, and 3D sensing products. This was offset by lower sales from product lines we are winding down such as Datacom transceiver modules and certain Lithium Niobate product lines.

[0001633978-21-000004:mdna:40]
Lasers net revenue decreased by $28.6 million, or 34.8%, during the six months ended December 26, 2020 compared to the six months ended December 28, 2019, primarily due to lower revenue from kilowatt class fiber lasers due to COVID-19 impacting demand.

[0001633978-21-000004:mdna:41]
During the three and six months ended December 26, 2020, 45% of our total net revenue for each period, respectively, was concentrated with two customers who were our only customers that represented greater than 10% of our total net revenue.

[0001633978-21-000004:mdna:42]
During the three and six months ended December 28, 2019, 41% and 44% of our total net revenue, respectively, was concentrated with two customers who were our only customers that represented greater than 10% of our total net revenue.

[0001633978-21-000004:mdna:43]
[same as prior period, unchanged from 0001633978-20-000018:mdna:36]

[0001633978-21-000004:mdna:44]
[same as prior period, unchanged from 0001633978-20-000018:mdna:37]

[0001633978-21-000004:mdna:45]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26, 2020 |  | December 28, 2019 |  | December 26, 2020 |  | December 28, 2019 |
| Net revenue: | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 39.7 |  |  | 8.3 | % |  | $ | 43.4 |  |  | 9.5 | % |  | $ | 60.0 |  |  | 6.4 | % |  | $ | 80.3 |  |  | 8.8 | % |
| Mexico | 51.3 |  |  | 10.7 |  |  | 26.2 |  |  | 5.7 |  |  | 91.1 |  |  | 9.8 |  |  | 55.1 |  |  | 6.1 |  |
| Other Americas | 4.0 |  |  | 0.8 |  |  | 0.7 |  |  | 0.2 |  |  | 6.8 |  |  | 0.8 |  |  | 1.8 |  |  | 0.2 |  |
| Total Americas | $ | 95.0 |  |  | 19.8 | % |  | $ | 70.3 |  |  | 15.4 | % |  | $ | 157.9 |  |  | 17.0 | % |  | $ | 137.2 |  |  | 15.1 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 148.0 |  |  | 30.9 | % |  | $ | 144.5 |  |  | 31.6 | % |  | $ | 292.4 |  |  | 31.4 | % |  | $ | 278.3 |  |  | 30.7 | % |
| Philippines | 40.6 |  |  | 8.5 |  |  | 4.8 |  |  | 1.0 |  |  | 103.4 |  |  | 11.1 |  |  | 29.8 |  |  | 3.3 |  |
| South Korea | 66.0 |  |  | 13.8 |  |  | 85.0 |  |  | 18.6 |  |  | 122.0 |  |  | 13.1 |  |  | 176.6 |  |  | 19.5 |  |
| Other Asia-Pacific | 94.0 |  |  | 19.6 |  |  | 116.1 |  |  | 25.4 |  |  | 185.6 |  |  | 19.9 |  |  | 216.4 |  |  | 23.8 |  |
| Total Asia-Pacific | $ | 348.6 |  |  | 72.8 | % |  | $ | 350.4 |  |  | 76.6 | % |  | $ | 703.4 |  |  | 75.5 | % |  | $ | 701.1 |  |  | 77.3 | % |
| EMEA | $ | 35.2 |  |  | 7.4 | % |  | $ | 37.1 |  |  | 8.0 | % |  | $ | 69.9 |  |  | 7.5 | % |  | $ | 69.4 |  |  | 7.6 | % |
| Total net revenue | $ | 478.8 |  |  |  |  | $ | 457.8 |  |  |  |  | $ | 931.2 |  |  |  |  | $ | 907.7 |  |  |  |

[0001633978-21-000004:mdna:46]
For the three and six months ended December 26, 2020, net revenue from customers outside the United States, based on customer shipping location, represented 91.7% and 93.6% of net revenue, respectively.

[0001633978-21-000004:mdna:47]
For the three and six months ended December 28, 2019, net revenue from customers outside the United States, based on customer shipping location, represented 90.5% and 91.2% of net revenue, respectively.

[0001633978-21-000004:mdna:48]
During the three and six months ended December 26, 2020 compared to the three and six months ended December 28, 2019, our net revenue from the Philippines grew due to an introduction of a new product to one of our large customers.

[0001633978-21-000004:mdna:49]
[same as prior period, unchanged from 0001633978-20-000018:mdna:41]

[0001633978-21-000004:mdna:50]
[same as prior period, unchanged from 0001633978-20-000018:mdna:43]

[0001633978-21-000004:mdna:51]
The following table summarizes segment gross margin for the three and six months ended December 26, 2020 and December 28, 2019 (in millions, except for percentages):

[0001633978-21-000004:mdna:52]
|  | Three Months Ended |  | Six Months Ended |
|  | Gross Profit |  | Gross Margin |  | Gross Profit |  | Gross Margin |
|  | December 26, 2020 |  | December 28, 2019 |  | December 26, 2020 |  | December 28, 2019 |  | December 26, 2020 |  | December 28, 2019 |  | December 26, 2020 |  | December 28, 2019 |
| OpComms | $ | 241.8 |  |  | $ | 196.4 |  |  | 53.8 | % |  | 48.0 | % |  | $ | 466.6 |  |  | $ | 388.3 |  |  | 53.2 | % |  | 47.0 | % |
| Lasers | 14.1 |  |  | 20.4 |  |  | 47.5 | % |  | 42.1 | % |  | 24.5 |  |  | 34.6 |  |  | 45.7 | % |  | 42.1 | % |
| Segment total | $ | 255.9 |  |  | $ | 216.8 |  |  | 53.4 | % |  | 47.4 | % |  | $ | 491.1 |  |  | $ | 422.9 |  |  | 52.7 | % |  | 46.6 | % |
| Unallocated corporate items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation | (4.8) |  |  | (4.1) |  |  |  |  |  |  | (8.5) |  |  | (8.3) |  |  |  |  |  |
| Amortization of acquired intangibles | (15.0) |  |  | (12.4) |  |  |  |  |  |  | (30.0) |  |  | (24.9) |  |  |  |  |  |
| Amortization of inventory fair value adjustments | — |  |  | (2.1) |  |  |  |  |  |  | — |  |  | (4.3) |  |  |  |  |  |
| Inventory and fixed asset write down due to product line exits | (0.1) |  |  | (2.6) |  |  |  |  |  |  | (0.4) |  |  | (3.7) |  |  |  |  |  |
| Integration related costs | — |  |  | — |  |  |  |  |  |  | — |  |  | (3.4) |  |  |  |  |  |
| Other charges (1) | (6.4) |  |  | (6.5) |  |  |  |  |  |  | (16.9) |  |  | (21.5) |  |  |  |  |  |
| Total | $ | 229.6 |  |  | $ | 189.1 |  |  | 48.0 | % |  | 41.3 | % |  | $ | 435.3 |  |  | $ | 356.8 |  |  | 46.7 | % |  | 39.3 | % |

[0001633978-21-000004:mdna:53]
(1) “Other charges” of unallocated corporate items for the three and six months ended December 26, 2020 include costs of transferring product lines to new production facilities, including Thailand of $0.4 million and $2.5 million, respectively.  We also incurred excess and obsolete inventory charges driven by U.S. trade restrictions and the related decline in demand from Huawei of $0.8 million and $6.7 million during the three and six months ended December 26, 2020, respectively. In addition, during the three months ended December 26, 2020, we incurred $4.6 million of impairment charges associated with excess capacity related to our Fiber laser business.

[0001633978-21-000004:mdna:54]
“Other charges” of unallocated corporate items for the three and six months ended December 28, 2019 include costs of transferring product lines to new production facilities, including Thailand of $2.0 million and $8.1 million, respectively. We also incurred excess and obsolete inventory charges driven by the decline in demand from Huawei of $6.0 million and $12.7 million during the three and six months ended December 28, 2019.

[0001633978-21-000004:mdna:55]
[same as prior period, unchanged from 0001633978-20-000018:mdna:47]

[0001633978-21-000004:mdna:56]
[same as prior period, unchanged from 0001633978-20-000018:mdna:48]

[0001633978-21-000004:mdna:57]
Gross margin for the three months ended December 26, 2020 increased to 48.0% from 41.3% for the three months ended December 28, 2019. The increase was primarily driven by improved gross margins within Datacom, due to the sale and exit of our Datacom transceiver module business, which had lower than average gross margins, and increased revenue from our higher margin Datacom chip products, which have higher than average gross margins. Although we sold our Datacom transceiver module business in March 2019, we retained and continued to sell transceivers inventory at low gross margin percentages during fiscal year 2020. During the three months ended December 26, 2020, Datacom revenue was primarily from higher margin Datacom chip products. The increase is also attributable to higher 3D sensing revenue for the three months ended December 26, 2020 compared to the three months ended December 28, 2019, which has better than average gross margins.

[0001633978-21-000004:mdna:58]
Gross margin for the six months ended December 26, 2020 increased to 46.7% from 39.3% for the six months ended December 28, 2019. The increase was primarily driven by improved gross margins within Datacom, due to the sale and exit of

[0001633978-21-000004:mdna:59]
our Datacom transceiver module business, which had lower than average gross margins, and increased revenue from our higher margin Datacom chip products, which have higher than average gross margins.

[0001633978-21-000004:mdna:60]
[same as prior period, unchanged from 0001633978-20-000018:mdna:50]

[0001633978-21-000004:mdna:61]
Although the magnitude of the impact of COVID-19 on our business operations remains uncertain and difficult to predict, and this remains a highly dynamic situation, we have experienced, and we expect that we may continue to experience disruptions to our and our customers’ businesses that will adversely impact our business, financial condition and results of operations.

[0001633978-21-000004:mdna:62]
[same as prior period, unchanged from 0001633978-20-000018:mdna:52]

[0001633978-21-000004:mdna:63]
[same as prior period, unchanged from 0001633978-20-000018:mdna:53]

[0001633978-21-000004:mdna:64]
OpComms gross margin for the three months ended December 26, 2020 increased to 53.8% from 48.0% for the three months ended December 28, 2019. The increase was primarily driven by improved gross margins within Datacom, due to the sale and exit of our Datacom transceiver module business in March 2019, which had lower than average gross margins, and increased revenue from our higher margin Datacom chip products, which have higher than average gross margins. The increase is also attributable to higher 3D sensing revenue, which has better than average gross margins.

[0001633978-21-000004:mdna:65]
OpComms gross margin for the six months ended December 26, 2020 increased to 53.2% from 47.0% for the six months ended December 28, 2019. The increase was primarily driven by improved gross margins within Datacom, due to the sale and exit of our Datacom transceiver module business in March 2019, which had lower than average gross margins, and increased revenue from our higher margin Datacom chip products, which have higher than average gross margins.

[0001633978-21-000004:mdna:66]
[same as prior period, unchanged from 0001633978-20-000018:mdna:55]

[0001633978-21-000004:mdna:67]
Lasers gross margin for the three months ended December 26, 2020 increased to 47.5% from 42.1% for the three months ended December 28, 2019. This increase was primarily driven by the streamlining of our manufacturing supply chain related to our kilowatt class fiber products over the past year, offset by the impacts of reduced manufacturing levels due to the slowdown in demand for kilowatt class fiber products.

[0001633978-21-000004:mdna:68]
Lasers gross margin for the six months ended December 26, 2020 increased to 45.7% from 42.1% for the six months ended December 28, 2019. This increase was primarily driven by the streamlining of our manufacturing supply chain related to our kilowatt class fiber products over the past year, offset by the impacts of reduced manufacturing levels due to the slowdown in demand for kilowatt class fiber products.

[0001633978-21-000004:mdna:69]
[same as prior period, unchanged from 0001633978-20-000018:mdna:57]

[0001633978-21-000004:mdna:70]
R&D expense increased by $1.8 million, or 3.5%, for the three months ended December 26, 2020 compared to the three months ended December 28, 2019. The increase in R&D expense was primarily due to an increase in stock-based compensation and payroll related expense, offset by a decrease in R&D materials, as well as a reduction in discretionary travel, primarily due to COVID-19 restrictions.

[0001633978-21-000004:mdna:71]
R&D expense increased by $2.3 million, or 2.3%, for the six months ended December 26, 2020 compared to the six months ended December 28, 2019. The increase in R&D expense was primarily due to an increase in payroll related expense and stock-based compensation, offset by a decrease in R&D materials, as well as a reduction in discretionary travel, primarily due to COVID-19 restrictions.

[0001633978-21-000004:mdna:72]
[same as prior period, unchanged from 0001633978-20-000018:mdna:59]

[0001633978-21-000004:mdna:73]
[same as prior period, unchanged from 0001633978-20-000018:mdna:60]

[0001633978-21-000004:mdna:74]
SG&A expense decreased by $1.1 million, or 1.8%, during the three months ended December 26, 2020 compared to the three months ended December 28, 2019. The decrease in SG&A expense was primarily due to lower discretionary travel and trade shows, primarily due to COVID-19 restrictions, offset by an increase in payroll related expense due to incremental headcount, an increase in stock-based compensation, and an increase in legal costs related to the planned acquisition of Coherent.

[0001633978-21-000004:mdna:75]
SG&A expense decreased by $1.5 million, or 1.3%, during the six months ended December 26, 2020 compared to the six months ended December 28, 2019. The decrease in SG&A expense was primarily due to lower discretionary travel and trade shows, primarily due to COVID-19 restrictions, offset by an increase in payroll related expense due to incremental headcount, an increase in stock-based compensation, and an increase in legal costs related to the planned acquisition of Coherent.

[0001633978-21-000004:mdna:76]
From time to time, we expect to incur non-core expenses, such as mergers and acquisition-related expenses and litigation expenses, which will likely increase our SG&A expenses and potentially impact our profitability expectations in any particular quarter. In particular, we expect additional SG&A expenses related to our pending acquisition of Coherent for the next several periods.

[0001633978-21-000004:mdna:77]
[same as prior period, unchanged from 0001633978-20-000018:mdna:63]

[0001633978-21-000004:mdna:78]
We have initiated various strategic restructuring events primarily intended to reduce costs, consolidate our operations, rationalize the manufacturing of our products and align our business in response to market conditions.

[0001633978-21-000004:mdna:79]
During the three and six months ended December 26, 2020, we recorded $0.2 million for each period in restructuring and related charges in our condensed consolidated statements of operations. During the three and six months ended December 28, 2019, we recorded restructuring and related charges of $0.9 million and $2.2 million, respectively, in restructuring and related charges, which were mainly attributable to severance charges associated with ongoing Oclaro acquisition related synergies.

[0001633978-21-000004:mdna:80]
[same as prior period, unchanged from 0001633978-20-000018:mdna:66]

[0001633978-21-000004:mdna:81]
For the three months ended December 26, 2020 and December 28, 2019, we recorded interest expense of $16.3 million and $18.3 million, respectively.

[0001633978-21-000004:mdna:82]
For the six months ended December 26, 2020 and December 28, 2019, we recorded interest expense of $32.3 million and $29.7 million, respectively. The increase in interest expense was mainly driven by the increase in amortization of the debt discount and contractual interest expense of our 0.50% Convertible Notes due in 2026 (the “2026 Notes”), offset by the decrease in contractual interest expense on our term loan facility which was repaid in full in the three months ended December 28, 2019 and a loss on early extinguishment of debt.

[0001633978-21-000004:mdna:83]
[same as prior period, unchanged from 0001633978-20-000018:mdna:68]

[0001633978-21-000004:mdna:84]
[same as prior period, unchanged from 0001633978-20-000018:mdna:69]

[0001633978-21-000004:mdna:85]
|  | Three Months Ended |  | Six Months Ended |  |  |
|  | December 26, 2020 |  | December 28, 2019 |  | December 26, 2020 |  | December 28, 2019 |  |  |
| Foreign exchange gains (losses), net | $ | (2.8) |  |  | $ | (2.1) |  |  | $ | (5.1) |  |  | $ | (1.0) |  |  |  |
| Interest income | 1.5 |  |  | 3.4 |  |  | 3.9 |  |  | 7.4 |  |  |  |
| Other income (expense), net | 0.4 |  |  | (0.1) |  |  | 0.9 |  |  | (0.2) |  |  |  |
| Total other income (expense), net | $ | (0.9) |  |  | $ | 1.2 |  |  | $ | (0.3) |  |  | $ | 6.2 |  |  |  |

[0001633978-21-000004:mdna:86]
For the three months ended December 26, 2020, other income (expense), net decreased by $2.1 million in income as compared to the three months ended December 28, 2019, mainly driven by lower interest income on our cash equivalents and short-term investments.

[0001633978-21-000004:mdna:87]
For the six months ended December 26, 2020, other income (expense), net decreased by $6.5 million in income as compared to the six months ended December 28, 2019, mainly driven by foreign exchange losses related to the revaluation of non-functional currency denominated balances of our international subsidiaries, as well as lower interest income on our cash equivalents and short-term investments.

[0001633978-21-000004:mdna:88]
[same as prior period, unchanged from 0001633978-20-000018:mdna:72]

[0001633978-21-000004:mdna:89]
| (in millions) | Three Months Ended |  | Six Months Ended |
|  | December 26, 2020 |  | December 28, 2019 |  | December 26, 2020 |  | December 28, 2019 |
| Provision for income taxes | $ | 14.9 |  |  | $ | 8.6 |  |  | $ | 31.4 |  |  | $ | 14.4 |  |

[0001633978-21-000004:mdna:90]
We recorded a tax provision of $14.9 million and $8.6 million for the three months ended December 26, 2020 and December 28, 2019, respectively. Our tax provision for the three months ended December 26, 2020 includes a discrete tax benefit of $2.5 million mainly from the reversal of certain deferred tax liabilities recorded in prior periods and the excess benefit related to certain stock-based compensation that vested during the quarter, partially offset by currency re-measurement of certain tax related accounts. Our estimated effective tax rate for fiscal 2021 differs from the 21% U.S. statutory rate primarily due to the earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate as well as the U.S. federal R&D tax credits, partially offset by the income tax expense from non-deductible stock-based compensation and the tax effect of Global Intangible Low-Taxed Income (“GILTI”), net of a benefit for foreign tax credits, Base Erosion and Anti-Abuse Tax (“BEAT”), and subpart F inclusion.

[0001633978-21-000004:mdna:91]
[same as prior period, unchanged from 0001633978-20-000018:mdna:75]

[0001633978-21-000004:mdna:92]
The following table summarizes our contractual obligations as of December 26, 2020, and the effect such obligations are expected to have on our liquidity and cash flow over the next five years (in millions):

[0001633978-21-000004:mdna:93]
|  | Payments due by period |
|  | Total |  | Less than 1 year |  | 1 - 3 years |  | 3 - 5 years |  | More than 5 years |
| Contractual Obligations |  |  |  |  |  |  |  |  |  |
| Asset retirement obligations | $ | 5.0 |  |  | $ | 0.3 |  |  | $ | 1.1 |  |  | $ | 1.5 |  |  | $ | 2.1 |  |
| Finance lease liabilities, including imputed interest | 0.3 |  |  | 0.3 |  |  | — |  |  | — |  |  | — |  |
| Operating lease liabilities, including imputed interest (1) | 74.8 |  |  | 13.2 |  |  | 23.5 |  |  | 14.7 |  |  | 23.4 |  |
| Pension plan contributions (2) | 0.5 |  |  | 0.5 |  |  | — |  |  | — |  |  | — |  |
| Purchase obligations (3) | 219.8 |  |  | 208.4 |  |  | 11.3 |  |  | 0.1 |  |  | — |  |
| Convertible notes - principal (4) | 1,500.0 |  |  | — |  |  | — |  |  | 450.0 |  |  | 1,050.0 |  |
| Convertible notes - interest (4) | 35.4 |  |  | 6.4 |  |  | 12.7 |  |  | 11.1 |  |  | 5.2 |  |
| Total | $ | 1,835.8 |  |  | $ | 229.1 |  |  | $ | 48.6 |  |  | $ | 477.4 |  |  | $ | 1,080.7 |  |

[0001633978-21-000004:mdna:94]
(1) The amounts of operating lease liabilities in the table above do not include any sublease income amounts nor do they include payments for short-term leases or variable lease payments. As of December 26, 2020, we expect to receive sublease income of approximately $4.4 million over the next two years.  Refer to “Note 7. Leases” in the notes to condensed consolidated financial statements.

[0001633978-21-000004:mdna:95]
[same as prior period, unchanged from 0001633978-20-000018:mdna:79]

[0001633978-21-000004:mdna:96]
(3) Purchase obligations represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Refer to “Note 14. Commitments and Contingencies” in the notes to condensed consolidated financial statements.

[0001633978-21-000004:mdna:97]
(4) Includes principal and interest on our 0.25% Convertible Notes due in 2024 (the “2024 Notes” and together with the 2026 Notes, the “Notes”) through March 2024, and principal and interest on our 0.50% 2026 Notes through December 2026. We have the right to redeem the 2024 Notes and the 2026 Notes in whole or in part at any time on or after March 15, 2024 and on or after December 15, 2026, respectively. The principal balances of our Notes are reflected in the payment periods in the table above based on their respective contractual maturities assuming no conversion. Refer to “Note 9. Debt” in the notes to condensed consolidated financial statements.

[0001633978-21-000004:mdna:98]
As of December 26, 2020, our other non-current liabilities also include $18.9 million of unrecognized tax benefit for uncertain tax positions. We are unable to reliably estimate the timing of future payments related to uncertain tax positions and therefore have excluded them from the preceding table.

[0001633978-21-000004:mdna:99]
[same as prior period, unchanged from 0001633978-20-000018:mdna:83]

[0001633978-21-000004:mdna:100]
[same as prior period, unchanged from 0001633978-20-000018:mdna:84]

[0001633978-21-000004:mdna:101]
[same as prior period, unchanged from 0001633978-20-000018:mdna:85]

[0001633978-21-000004:mdna:102]
[same as prior period, unchanged from 0001633978-20-000018:mdna:86]

[0001633978-21-000004:mdna:103]
As of December 26, 2020 and June 27, 2020, our cash and cash equivalents of $321.3 million and $298.0 million, respectively, were largely held in the United States. As of December 26, 2020 and June 27, 2020, our short-term investments of $1,379.0 million and $1,255.8 million, respectively, were all held in the United States. Cash equivalents and short-term investments are primarily comprised of money market funds, treasuries, agencies, high quality investment grade fixed income securities, certificates of deposit, and commercial paper. Our investment policy and strategy is focused on the preservation of capital and supporting our liquidity requirements.

[0001633978-21-000004:mdna:104]
The total amount of cash and cash equivalents outside the United States held by the non-US entities as of December 26, 2020 was $97.1 million, which was primarily held by entities incorporated in the British Virgin Islands, Canada, China, Hong Kong, Japan, Switzerland, Thailand, and the United Kingdom. Although the cash currently held in the United States as well as the cash generated in the United States from future operations is expected to cover our normal operating requirements, a substantial amount of additional cash could be required for other purposes, such as capital expenditures to support our business and growth, including costs associated with increasing internal manufacturing capabilities, particularly in our Thailand facility, strategic transactions and partnerships, and future acquisitions.

[0001633978-21-000004:mdna:105]
[same as prior period, unchanged from 0001633978-20-000018:mdna:89]

[0001633978-21-000004:mdna:106]
As of December 26, 2020, the debt component of our 2024 Notes of $380.3 million (principal balance of $450 million maturing in 2024) was reclassified to our short-term liabilities since our stock price exceeded $78.80 for 20 of the last 30 trading days of the quarter ended December 26, 2020 and the 2024 Notes have become convertible at the option of the holders. To date, none of the holders of the 2024 Notes have requested to convert their notes. If the closing price of our stock exceeds $129.08 for 20 of the last 30 trading days of any future quarter, our 2026 Notes would also become convertible at the option of the holders and the debt component would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001633978-21-000004:mdna:107]
[same as prior period, unchanged from 0001633978-20-000018:mdna:101]

[0001633978-21-000004:mdna:108]
We believe that our cash and cash equivalents as of December 26, 2020 and cash flows from our operating activities will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months. However, if market conditions are favorable, we may evaluate alternatives to opportunistically pursue additional financing.

[0001633978-21-000004:mdna:109]
[same as prior period, unchanged from 0001633978-20-000018:mdna:103]

[0001633978-21-000004:mdna:110]
•global economic conditions which affect demand for our products and services and impact the financial stability of our suppliers and customers, including the impact of COVID-19;

[0001633978-21-000004:mdna:111]
•fluctuations in demand for our products as a result of changes in regulations, tariffs or other trade barriers, and trade relations in general;

[0001633978-21-000004:mdna:112]
•changes in accounts receivable, inventory or other operating assets and liabilities, which affect our working capital;

[0001633978-21-000004:mdna:113]
•increase in capital expenditures to support our business and growth;

[0001633978-21-000004:mdna:114]
•the tendency of customers to delay payments or to negotiate favorable payment terms to manage their own liquidity positions;

[0001633978-21-000004:mdna:115]
•timing of payments to our suppliers;

[0001633978-21-000004:mdna:116]
•volatility in fixed income and credit, which impact the liquidity and valuation of our investment portfolios;

[0001633978-21-000004:mdna:117]
•volatility in foreign exchange markets, which impacts our financial results;

[0001633978-21-000004:mdna:118]
•possible investments or acquisitions of complementary businesses, products or technologies, or other strategic transactions or partnerships;

[0001633978-21-000004:mdna:119]
•issuance of debt or equity securities, or other financing transactions, including bank debt;

[0001633978-21-000004:mdna:120]
•potential funding of pension liabilities either voluntarily or as required by law or regulation; and

[0001633978-21-000004:mdna:121]
•the settlement of any conversion or redemption of the 2024 Notes and the 2026 Notes in cash.

[0001633978-21-000004:mdna:122]
On January 18, 2021, we and Coherent entered into the Merger Agreement, under which we will acquire all outstanding shares of Coherent common stock, as described above. Each share of Coherent common stock will be exchanged for $100 in cash and 1.1851 shares of our common stock, subject to the terms of the Merger Agreement. As of the date of the Merger Agreement, the total transaction consideration is approximately $5.7 billion. The total transaction consideration will be funded by a combination of approximately $3.2 billion in our common stock (based on the closing price of Lumentum common stock on the date preceding of the Merger Agreement), $2.1 billion in new debt, and the remaining amount from the cash balances of the combined company. We entered into a commitment letter with Deutsche Bank, pursuant to which, subject to the terms and conditions set forth therein, Deutsche Bank has committed to provide a senior secured term loan facility in an aggregate principal amount of up to $2.1 billion.

[0001633978-21-000004:mdna:123]
As of December 26, 2020, our condensed consolidated balance of cash and cash equivalents increased by $23.3 million, to $321.3 million from $298.0 million as of June 27, 2020. The increase in cash and cash equivalents during the six months ended December 26, 2020, was mainly due to cash provided by operating activities of $233.2 million, offset by cash used in investing activities of $189.0 million and cash used in financing activities of $20.9 million.

[0001633978-21-000004:mdna:124]
As of December 28, 2019, our condensed consolidated balance of cash and cash equivalents increased by $652.4 million, to $1,085.0 million from $432.6 million as of June 29, 2019. The increase in cash and cash equivalents was mainly due to cash provided by financing activities of $344.8 million, cash provided by operating activities of $249.8 million, and cash provided by investing activities of $57.8 million during the six months ended December 28, 2019.

[0001633978-21-000004:mdna:125]
[same as prior period, unchanged from 0001633978-20-000018:mdna:92]

[0001633978-21-000004:mdna:126]
Cash provided by operating activities was $233.2 million during the six months ended December 26, 2020. Our net income was $150.3 million for the six months ended December 26, 2020. Cash provided by operating activities was generated primarily from $170.4 million of non-cash items (such as depreciation, stock-based compensation, amortization of intangibles, amortization of debt discount and debt issuance costs on our Notes, and other non-cash charges), offset by $87.5 million of changes in our operating assets and liabilities. Changes in our operating assets and liabilities related primarily to increases in accounts receivable of $43.7 million and inventories of $16.9 million, as well as a decrease in accounts payable of $35.8 million.

[0001633978-21-000004:mdna:127]
Cash provided by operating activities was $249.8 million during the six months ended December 28, 2019. Our net income was $96.7 million for the six months ended December 28, 2019. Cash provided by operating activities was generated primarily from $162.4 million of non-cash items (such as depreciation, stock-based compensation, amortization of intangibles, amortization of debt discount and debt issuance costs on our term loans and our Notes, and other non-cash charges), offset by $9.3 million of changes in our operating assets and liabilities. Changes in our operating assets and liabilities related primarily to an increase in accounts receivable of $54.0 million offset by a decrease in inventories of $44.3 million.

[0001633978-21-000004:mdna:128]
[same as prior period, unchanged from 0001633978-20-000018:mdna:95]

[0001633978-21-000004:mdna:129]
Cash used in investing activities of $189.0 million during the six months ended December 26, 2020 was primarily attributable to purchases of short-term investments, net of sales and maturities of $129.8 million, capital expenditures of $50.5 million, and payment for asset acquisition of $10.0 million.

[0001633978-21-000004:mdna:130]
Cash provided by investing activities of $57.8 million during the six months ended December 28, 2019 was primarily attributable to proceeds from sales of short-term investments, net of purchases of $105.7 million, offset by capital expenditures of $47.4 million and payment for asset acquisition of $3.0 million.

[0001633978-21-000004:mdna:131]
[same as prior period, unchanged from 0001633978-20-000018:mdna:98]

[0001633978-21-000004:mdna:132]
Cash used in financing activities of $20.9 million during the six months ended December 26, 2020 resulted primarily from tax payments related to restricted stock of $26.2 million, offset by the proceeds from employee stock plans of $5.5 million.

[0001633978-21-000004:mdna:133]
Cash provided by financing activities of $344.8 million during the six months ended December 28, 2019 resulted primarily from the proceeds of the issuance of the 2026 Notes of $1,042.9 million, net of issuance costs, offset by the repurchase of shares of our common stock of $200.0 million and repayment of our term loan facility of $497.5 million.
