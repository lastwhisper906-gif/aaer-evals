# LITE notes — 0001633978-21-000004


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001633978-21-000004:notes:1]
[same as prior period, unchanged from 0001633978-20-000018:notes:1]

[0001633978-21-000004:notes:2]
[same as prior period, unchanged from 0001633978-20-000018:notes:2]

[0001633978-21-000004:notes:3]
[same as prior period, unchanged from 0001633978-20-000018:notes:3]

[0001633978-21-000004:notes:4]
[same as prior period, unchanged from 0001633978-20-000018:notes:4]

[0001633978-21-000004:notes:5]
[same as prior period, unchanged from 0001633978-20-000018:notes:5]

[0001633978-21-000004:notes:6]
[same as prior period, unchanged from 0001633978-20-000018:notes:6]

[0001633978-21-000004:notes:7]
[same as prior period, unchanged from 0001633978-20-000018:notes:7]

[0001633978-21-000004:notes:8]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2021 is a 53-week year ending on July 3, 2021, with the quarter ended December 26, 2020 being a 13-week quarterly period and our third quarter ending on April 3, 2021 being a 14-week quarterly period. Our fiscal 2020 was a 52-week year that ended on June 27, 2020, with the quarter ended December 28, 2019 being a 13-week quarterly period.

[0001633978-21-000004:notes:9]
[same as prior period, unchanged from 0001633978-20-000018:notes:9]

[0001633978-21-000004:notes:10]
[same as prior period, unchanged from 0001633978-20-000018:notes:10]

[0001633978-21-000004:notes:11]
Accounting Policies
The accompanying condensed consolidated financial statements and accompanying related notes should be read in conjunction with the audited consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended June 27, 2020. There have been no significant changes to these policies during the six months ended December 26, 2020, except for the removal of the long-lived asset valuation policy and the updates resulting from the adoption of Topic 326, as discussed in “Note 2. Recently Issued Accounting Pronouncements”.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001633978-21-000004:notes:12]
Accounting PoliciesThe accompanying condensed consolidated financial statements and accompanying related notes should be read in conjunction with the audited consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended June 27, 2020. 
Accounting Pronouncements Recently Adopted

[0001633978-21-000004:notes:13]
In August 2018, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2018-13, Fair Value Measurement (Topic 820): Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement. ASU 2018-13 modifies the disclosure requirements on transfers between Level 1 and Level 2, valuation processes of Level 3 fair value measurements, and the categorization by level for items that are not measured at fair value, but for which the fair value is required to be disclosed. We adopted ASU 2018-13 in the first quarter of fiscal 2021 with no impact to our condensed consolidated financial statements.

[0001633978-21-000004:notes:14]
In August 2018, FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Customer's Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract. This standard requires capitalization of the implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software. Further, the standard also requires the Company to expense the capitalized implementation costs of a hosting arrangement over the term of the hosting arrangement. We adopted ASU 2018-15 in the first quarter of fiscal 2021 with no impact to our condensed consolidated financial statements.

[0001633978-21-000004:notes:15]
In June 2016, FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments and a subsequent amendment, ASU 2018-19 (collectively, Topic 326). Topic 326 requires measurement and recognition of expected credit losses for financial assets held. We adopted ASU 2016-13 using the modified-retrospective approach in the first quarter of fiscal 2021 with no material impact to our condensed consolidated financial statements.

[0001633978-21-000004:notes:16]
With the adoption of Topic 326, we are now assessing whether unrealized losses have resulted from a credit loss or other factors. We believe none of our unrealized losses on available-for-sale investments were other-than temporary or were attributable to credit losses as of December 26, 2020 and June 27, 2020. We review our available-for-sale investments on a quarterly basis to identify a potential other-than-temporary impairment. The investments with unrealized losses consisted primarily of corporate debt securities, and given the extent of the unrealized loss positions, the issuers' high credit ratings and the near-term market conditions, we believe our unrealized losses are temporary. We also do not have an intent to sell our investments and would not be required to sell them before they recover.

[0001633978-21-000004:notes:17]
The adoption of Topic 326 did not significantly change our approach to the valuation of trade receivables. We determine whether there is an expected loss on our accounts receivable by reviewing all available data, including our customers' latest available financial statements, their credit standing and historical collection experience, as well as current and future market and economic conditions. As of December 26, 2020 and June 27, 2020, the allowance for credit losses on our trade receivables was $1.7 million and $1.8 million, respectively.

[0001633978-21-000004:notes:18]
Accounting Pronouncements Not Yet Effective

[0001633978-21-000004:notes:19]
In August 2020, FASB issued ASU 2020-06, Debt—Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging—Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity, which simplifies the accounting for convertible instruments by removing the separation models for (1) convertible debt with a cash conversion feature and (2) convertible instruments with a beneficial conversion feature. As a result, a convertible debt instrument will be accounted for as a single liability measured at its amortized cost. Also, ASU 2020-06 requires the application of the if-converted method for calculating diluted earnings per share and the treasury stock method will be no longer available. The new guidance is effective for fiscal years beginning after December 15, 2021, with early adoption permitted no earlier than fiscal years beginning after December 15, 2020. ASU 2020-06 is effective for us in our first quarter of fiscal year 2023. We are currently evaluating the impact of ASU 2020-06 on our condensed consolidated financial statements.

[0001633978-21-000004:notes:20]
In December 2019, FASB issued ASU 2019-12, Simplifying the Accounting for Income Taxes (Topic 740), which is intended to simplify various aspects related to accounting for income taxes by removing certain exceptions to the general principles in Topic 740 and which also clarifies and amends existing guidance to improve consistent application. ASU 2019-12 is effective for us at the beginning of fiscal year 2022, including interim periods within that reporting period, although early adoption is permitted. We are currently evaluating the impact of ASU 2019-12 on our condensed consolidated financial statements. 
In August 2018, FASB issued ASU 2018-14, Compensation-Retirement Benefits-Defined Benefit Plans-General (Topic 715-20): Disclosure Framework-Changes to the Disclosure Requirements for Defined Benefit Plans. ASU 2018-14 modifies the disclosure requirements for defined benefit pension plans and other post-retirement benefit plans. The new guidance is effective for fiscal years ending after December 15, 2020, with early adoption permitted. ASU 2018-14 should be applied retrospectively to all periods presented and is effective for us in our fourth quarter of fiscal year 2021 as ASU 2018-14 does not amend the interim disclosure requirements.


## us-gaap:EarningsPerShareTextBlock

[0001633978-21-000004:notes:21]
[same as prior period, unchanged from 0001633978-20-000018:notes:22]

[0001633978-21-000004:notes:22]
[same as prior period, unchanged from 0001633978-20-000018:notes:23]

[0001633978-21-000004:notes:23]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26, 2020 |  | December 28, 2019 |  | December 26, 2020 |  | December 28, 2019 |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income | $ | 83.2 |  |  | $ | 49.1 |  |  | $ | 150.3 |  |  | $ | 96.7 |  |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Basic weighted average common shares outstanding | 75.6 |  |  | 76.8 |  |  | 75.5 |  |  | 76.9 |  |  |
| Effect of dilutive securities from stock-based benefit plans | 0.7 |  |  | 0.7 |  |  | 0.8 |  |  | 0.7 |  |  |
| Shares issuable assuming conversion of the 2024 Notes | 2.1 |  |  | 0.5 |  |  | 2.0 |  |  | 0.2 |  |  |
| Diluted weighted average common shares outstanding | 78.4 |  |  | 78.0 |  |  | 78.3 |  |  | 77.8 |  |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic | $ | 1.10 |  |  | $ | 0.64 |  |  | $ | 1.99 |  |  | $ | 1.26 |  |  |
| Diluted | $ | 1.06 |  |  | $ | 0.63 |  |  | $ | 1.92 |  |  | $ | 1.24 |  |  |

[0001633978-21-000004:notes:24]
[same as prior period, unchanged from 0001633978-20-000018:notes:25]

[0001633978-21-000004:notes:25]
We have the ability and intent to settle the face value of our convertible notes in cash. Therefore, we use the treasury stock method for calculating the dilutive impact of the convertible notes. The 2026 Notes (as defined in Note 9) will have no impact on diluted earnings per share until the average price of our common stock exceeds the conversion price of $99.29. The potentially dilutive shares resulting from the 2024 Notes (as defined in Note 9) were included in the calculation of diluted income per share for the three and six months ended December 26, 2020 since the average price of our common stock exceeded the conversion price of $60.62. Refer to “Note 9. Debt” for further discussion.

[0001633978-21-000004:notes:26]
Anti-dilutive potential shares are excluded from the calculation of diluted earnings per share if their exercise price exceeded the average market price during the period or the share-based awards were determined to be anti-dilutive based on applying the treasury stock method. Anti-dilutive shares excluded from the calculation of diluted earnings per share were not material and 0.5 million shares for the three and six months ended December 26, 2020, respectively. Anti-dilutive shares excluded from the calculation of diluted earnings per share were not material for the three and six months ended December 28, 2019, respectively.


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001633978-21-000004:notes:27]
[same as prior period, unchanged from 0001633978-20-000018:notes:28]

[0001633978-21-000004:notes:28]
[same as prior period, unchanged from 0001633978-20-000018:notes:29]

[0001633978-21-000004:notes:29]
|  | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| December 26, 2020: |  |  |  |  |  |  |  |
| Cash | $ | 107.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 107.7 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 10.0 |  |  | — |  |  | — |  |  | 10.0 |  |
| Money market funds | 203.6 |  |  | — |  |  | — |  |  | 203.6 |  |
| Total cash and cash equivalents | $ | 321.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 321.3 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 4.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 4.9 |  |
| Commercial paper | 112.8 |  |  | — |  |  | — |  |  | 112.8 |  |
| Corporate debt securities | 523.2 |  |  | 0.5 |  |  | (0.2) |  |  | 523.5 |  |
| U.S. Agency securities | 60.6 |  |  | — |  |  | — |  |  | 60.6 |  |
| U.S. Treasury securities | 677.0 |  |  | 0.2 |  |  | — |  |  | 677.2 |  |
| Total short-term investments | $ | 1,378.5 |  |  | $ | 0.7 |  |  | $ | (0.2) |  |  | $ | 1,379.0 |  |
| June 27, 2020: |  |  |  |  |  |  |  |
| Cash | $ | 114.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 114.2 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | 159.6 |  |  | — |  |  | — |  |  | 159.6 |  |
| U.S. Treasury securities | 24.2 |  |  | — |  |  | — |  |  | 24.2 |  |
| Total cash and cash equivalents | $ | 298.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 298.0 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 12.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 12.9 |  |
| Commercial paper | 179.9 |  |  | 0.3 |  |  | — |  |  | 180.2 |  |
| Corporate debt securities | 435.0 |  |  | 1.7 |  |  | (0.1) |  |  | 436.6 |  |
| Foreign government bonds | 1.7 |  |  | — |  |  | — |  |  | 1.7 |  |
| U.S. Agency securities | 59.5 |  |  | — |  |  | — |  |  | 59.5 |  |
| U.S. Treasury securities | 563.9 |  |  | 1.0 |  |  | — |  |  | 564.9 |  |
| Total short-term investments | $ | 1,252.9 |  |  | $ | 3.0 |  |  | $ | (0.1) |  |  | $ | 1,255.8 |  |

[0001633978-21-000004:notes:30]
We use the specific-identification method to determine any realized gains or losses from the sale of our short-term investments classified as available-for-sale. During the three and six months ended December 26, 2020 and December 28, 2019, we did not realize significant gains or losses on a gross level from the sale of our short-term investments classified as available-for-sale.

[0001633978-21-000004:notes:31]
During the three and six months ended December 26, 2020, our other income (expense), net was $(0.9) million and $(0.3) million, respectively, and includes interest income on cash equivalents and short-term investments of $1.5 million and $3.9 million, respectively. During the three and six months ended December 28, 2019, our other income (expense), net was $1.2 million and $6.2 million, respectively, and includes interest income on cash equivalents and short-term investments of $3.4 million and $7.4 million, respectively.

[0001633978-21-000004:notes:32]
We included $5.2 million and $4.3 million of interest receivable in prepayments and other current assets as of December 26, 2020 and June 27, 2020, respectively. We did not recognize an allowance for credit losses against interest receivable in any of the periods presented as there were no such losses.

[0001633978-21-000004:notes:33]
[same as prior period, unchanged from 0001633978-20-000018:notes:33]

[0001633978-21-000004:notes:34]
|  | Less than 12 months |  |  |  |  |
|  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |
| December 26, 2020: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 36.6 |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 72.6 |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 246.1 |  |  | (0.2) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 151.8 |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | 507.1 |  |  | $ | (0.2) |  |  |  |  |  |  |  |  |  |
| June 27, 2020: |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 3.1 |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 51.1 |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 96.5 |  |  | (0.1) |  |  |  |  |  |  |  |  |  |
| Foreign government bonds | 1.7 |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | 47.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 159.8 |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | 359.2 |  |  | $ | (0.1) |  |  |  |  |  |  |  |  |  |

[0001633978-21-000004:notes:35]
As of December 26, 2020 and June 27, 2020, we have no unrealized loss positions for a period of greater than 12 months on our cash equivalents and short-term investments.

[0001633978-21-000004:notes:36]
[same as prior period, unchanged from 0001633978-20-000018:notes:35]

[0001633978-21-000004:notes:37]
|  | December 26, 2020 |  | June 27, 2020 |
|  | Amortized Cost |  | Fair Value |  | Amortized Cost |  | Fair Value |
| Due in 1 year | $ | 1,036.5 |  |  | $ | 1,036.9 |  |  | $ | 1,237.4 |  |  | $ | 1,239.9 |  |
| Due in 1 year through 5 years | 342.0 |  |  | 342.1 |  |  | 15.5 |  |  | 15.9 |  |
|  | $ | 1,378.5 |  |  | $ | 1,379.0 |  |  | $ | 1,252.9 |  |  | $ | 1,255.8 |  |

[0001633978-21-000004:notes:38]
[same as prior period, unchanged from 0001633978-20-000018:notes:37]


## us-gaap:FairValueDisclosuresTextBlock

[0001633978-21-000004:notes:39]
[same as prior period, unchanged from 0001633978-20-000018:notes:38]

[0001633978-21-000004:notes:40]
[same as prior period, unchanged from 0001633978-20-000018:notes:39]

[0001633978-21-000004:notes:41]
[same as prior period, unchanged from 0001633978-20-000018:notes:40]

[0001633978-21-000004:notes:42]
The fair value of our Level 1 financial instruments, such as money market funds and U.S. Treasury securities, which are traded in active markets, is based on quoted market prices for identical instruments. The fair value of our Level 2 fixed income securities is obtained from an independent pricing service, which may use quoted market prices for identical or comparable instruments or model driven valuations using observable market data or inputs corroborated by observable market data. Our marketable securities are held by custodians who obtain investment prices from a third-party pricing provider that incorporates standard inputs in various asset price models. Our procedures include controls to ensure that appropriate fair values are recorded, including comparing the fair values obtained from our pricing service against fair values obtained from another independent source.

[0001633978-21-000004:notes:43]
[same as prior period, unchanged from 0001633978-20-000018:notes:43]

[0001633978-21-000004:notes:44]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| December 26, 2020: (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | — |  |  | $ | 10.0 |  |  | $ | — |  |  | $ | 10.0 |  |
| Money market funds | 203.6 |  |  | — |  |  | — |  |  | 203.6 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 4.9 |  |  | — |  |  | 4.9 |  |
| Commercial paper | — |  |  | 112.8 |  |  | — |  |  | 112.8 |  |
| Corporate debt securities | — |  |  | 523.5 |  |  | — |  |  | 523.5 |  |
| U.S. Agency securities | — |  |  | 60.6 |  |  | — |  |  | 60.6 |  |
| U.S. Treasury securities | 677.2 |  |  | — |  |  | — |  |  | 677.2 |  |
| Total assets | $ | 880.8 |  |  | $ | 711.8 |  |  | $ | — |  |  | $ | 1,592.6 |  |

[0001633978-21-000004:notes:45]
(1)  Excludes $107.7 million in cash held in our bank accounts at December 26, 2020.

[0001633978-21-000004:notes:46]
[same as prior period, unchanged from 0001633978-20-000018:notes:46]

[0001633978-21-000004:notes:47]
[same as prior period, unchanged from 0001633978-20-000018:notes:47]

[0001633978-21-000004:notes:48]
[same as prior period, unchanged from 0001633978-20-000018:notes:48]

[0001633978-21-000004:notes:49]
[same as prior period, unchanged from 0001633978-20-000018:notes:49]

[0001633978-21-000004:notes:50]
[same as prior period, unchanged from 0001633978-20-000018:notes:50]

[0001633978-21-000004:notes:51]
|  | December 26, 2020 |  | June 27, 2020 |
|  | Carrying Amount |  | Estimated Fair Value |  | Carrying Amount |  | Estimated Fair Value |
| 2026 Notes | $ | 769.1 |  |  | $ | 1,312.5 |  |  | $ | 749.7 |  |  | $ | 1,070.2 |  |
| 2024 Notes | 380.3 |  |  | 765.1 |  |  | 370.6 |  |  | 620.0 |  |
|  | $ | 1,149.4 |  |  | $ | 2,077.6 |  |  | $ | 1,120.3 |  |  | $ | 1,690.2 |  |

[0001633978-21-000004:notes:52]
[same as prior period, unchanged from 0001633978-20-000018:notes:52]

[0001633978-21-000004:notes:53]
[same as prior period, unchanged from 0001633978-20-000018:notes:53]

[0001633978-21-000004:notes:54]
[same as prior period, unchanged from 0001633978-20-000018:notes:54]


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001633978-21-000004:notes:55]
We periodically review our intangible and other long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. Determination of recoverability is based on the lowest level of identifiable estimated undiscounted cash flows resulting from use of the asset and its eventual disposition. If not recoverable, an impairment loss would be calculated based on the excess of the carrying amount over the fair value.
Management utilizes various valuation methods, including an income approach, a market approach and a cost approach, to estimate the fair value of intangibles and other long-lived assets.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001633978-21-000004:notes:56]
[same as prior period, unchanged from 0001633978-20-000018:notes:56]

[0001633978-21-000004:notes:57]
[same as prior period, unchanged from 0001633978-20-000018:notes:57]

[0001633978-21-000004:notes:58]
We did not have any allowance for credit losses other than our allowance for uncollectible accounts receivable. As of December 26, 2020 and June 27, 2020, the allowance for credit losses on our trade receivables was $1.7 million and $1.8 million, respectively.

[0001633978-21-000004:notes:59]
[same as prior period, unchanged from 0001633978-20-000018:notes:59]

[0001633978-21-000004:notes:60]
[same as prior period, unchanged from 0001633978-20-000018:notes:60]

[0001633978-21-000004:notes:61]
|  | December 26, 2020 |  | June 27, 2020 |
| Raw materials and purchased parts | $ | 70.4 |  |  | $ | 57.9 |  |
| Work in process | 84.2 |  |  | 67.6 |  |
| Finished goods | 52.5 |  |  | 63.4 |  |
| Inventories | $ | 207.1 |  |  | $ | 188.9 |  |

[0001633978-21-000004:notes:62]
[same as prior period, unchanged from 0001633978-20-000018:notes:62]

[0001633978-21-000004:notes:63]
[same as prior period, unchanged from 0001633978-20-000018:notes:63]

[0001633978-21-000004:notes:64]
|  | December 26, 2020 |  | June 27, 2020 |
| Operating lease right-of-use assets | $ | 88.7 |  |  | $ | 90.3 |  |
| Less: accumulated amortization | (16.9) |  |  | (11.6) |  |
| Operating lease right-of-use assets, net | $ | 71.8 |  |  | $ | 78.7 |  |

[0001633978-21-000004:notes:65]
[same as prior period, unchanged from 0001633978-20-000018:notes:65]

[0001633978-21-000004:notes:66]
[same as prior period, unchanged from 0001633978-20-000018:notes:66]

[0001633978-21-000004:notes:67]
|  | December 26, 2020 |  | June 27, 2020 |
| Land | $ | 44.1 |  |  | $ | 44.1 |  |
| Buildings and improvement | 118.1 |  |  | 114.8 |  |
| Machinery and equipment | 517.2 |  |  | 487.0 |  |
| Computer equipment and software | 28.7 |  |  | 27.5 |  |
| Furniture and fixtures | 8.6 |  |  | 7.2 |  |
| Leasehold improvements | 29.5 |  |  | 27.8 |  |
| Finance lease right-of-use assets | 28.1 |  |  | 28.1 |  |
| Construction in progress | 45.6 |  |  | 54.7 |  |
|  | 819.9 |  |  | 791.2 |  |
| Less: Accumulated depreciation | (434.1) |  |  | (398.2) |  |
| Property, plant and equipment, net | $ | 385.8 |  |  | $ | 393.0 |  |

[0001633978-21-000004:notes:68]
During the three and six months ended December 26, 2020, we recorded depreciation expense of $23.8 million and $47.6 million, respectively. During the three and six months ended December 28, 2019, we recorded depreciation expense of $28.7 million and $60.3 million, respectively.

[0001633978-21-000004:notes:69]
[same as prior period, unchanged from 0001633978-20-000018:notes:69]

[0001633978-21-000004:notes:70]
[same as prior period, unchanged from 0001633978-20-000018:notes:70]

[0001633978-21-000004:notes:71]
[same as prior period, unchanged from 0001633978-20-000018:notes:71]

[0001633978-21-000004:notes:72]
|  | December 26, 2020 |  | June 27, 2020 |
| Restructuring accrual and related charges (1) | $ | 4.6 |  |  | $ | 5.2 |  |
| Warranty accrual (2) | 5.7 |  |  | 5.0 |  |
| Deferred revenue and customer deposits | 0.5 |  |  | 1.9 |  |
| Finance lease liabilities, current | 0.3 |  |  | 0.6 |  |
| Income tax payable (3) | 51.5 |  |  | 28.8 |  |
| Other current liabilities | 2.7 |  |  | 2.8 |  |
| Other current liabilities | $ | 65.3 |  |  | $ | 44.3 |  |

[0001633978-21-000004:notes:73]
[same as prior period, unchanged from 0001633978-20-000018:notes:73]

[0001633978-21-000004:notes:74]
(2) Refer to “Note 14. Commitments and Contingencies.”

[0001633978-21-000004:notes:75]
[same as prior period, unchanged from 0001633978-20-000018:notes:75]

[0001633978-21-000004:notes:76]
[same as prior period, unchanged from 0001633978-20-000018:notes:76]

[0001633978-21-000004:notes:77]
[same as prior period, unchanged from 0001633978-20-000018:notes:77]

[0001633978-21-000004:notes:78]
|  | December 26, 2020 |  | June 27, 2020 |
| Asset retirement obligations | $ | 4.7 |  |  | $ | 4.6 |  |
| Pension accrual | 12.2 |  |  | 11.8 |  |
| Unrecognized tax benefit | 18.9 |  |  | 17.3 |  |
| Other non-current liabilities | 2.3 |  |  | 2.3 |  |
| Other non-current liabilities | $ | 38.1 |  |  | $ | 36.0 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001633978-21-000004:notes:79]
[same as prior period, unchanged from 0001633978-20-000018:notes:79]

[0001633978-21-000004:notes:80]
[same as prior period, unchanged from 0001633978-20-000018:notes:80]

[0001633978-21-000004:notes:81]
We also have various finance leases of servers and certain other equipment for our operations. These arrangements are typically for two to four years.

[0001633978-21-000004:notes:82]
As of December 26, 2020, we sublease certain floors of our offices in the United Kingdom, the United States, Canada, and Japan. These subleases will expire at various dates by fiscal year 2023. We anticipate receiving approximately $4.4 million in sublease income over the next two years.

[0001633978-21-000004:notes:83]
[same as prior period, unchanged from 0001633978-20-000018:notes:83]

[0001633978-21-000004:notes:84]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26, 2020 |  | December 28, 2019 |  | December 26, 2020 |  | December 28, 2019 |
| Finance lease cost (in millions): |  |  |  |  |  |  |  |
| Amortization of right-of-use assets | $ | 0.1 |  |  | $ | 4.3 |  |  | $ | 0.3 |  |  | $ | 8.2 |  |
| Interest | — |  |  | — |  |  | — |  |  | 0.1 |  |
| Operating lease cost | 3.6 |  |  | 4.0 |  |  | 7.2 |  |  | 8.0 |  |
| Short-term and variable lease costs | 1.2 |  |  | 1.0 |  |  | 2.3 |  |  | 2.1 |  |
| Sublease income | (0.7) |  |  | (0.6) |  |  | (1.4) |  |  | (1.2) |  |
| Total lease cost | $ | 4.2 |  |  | $ | 8.7 |  |  | $ | 8.4 |  |  | $ | 17.2 |  |
|  |  |  |  |  | December 26, 2020 |  | June 27, 2020 |
| Weighted average remaining lease term (in years): |  |  |  |  |  |  |  |
| Operating leases |  |  |  |  | 8.0 |  | 8.6 |
| Finance leases |  |  |  |  | 0.5 |  | 1.0 |
| Weighted average discount rate: |  |  |  |  |  |  |  |
| Operating leases |  |  |  |  | 3.5 | % |  | 3.5 | % |
| Finance leases |  |  |  |  | 4.4 | % |  | 4.4 | % |

[0001633978-21-000004:notes:85]
As of December 26, 2020, maturities of our operating and finance lease liabilities, which do not include short-term leases and variable lease payments, were as follows (in millions):

[0001633978-21-000004:notes:86]
| Fiscal Years |  | Operating Leases (1) |  | Finance Leases |  | Total |
| Remainder of 2021 |  | $ | 6.8 |  |  | $ | 0.3 |  |  | $ | 7.1 |  |
| 2022 |  | 13.1 |  |  | — |  |  | 13.1 |  |
| 2023 |  | 11.8 |  |  | — |  |  | 11.8 |  |
| 2024 |  | 10.1 |  |  | — |  |  | 10.1 |  |
| 2025 |  | 6.7 |  |  | — |  |  | 6.7 |  |
| Thereafter |  | 26.3 |  |  | — |  |  | 26.3 |  |
| Total minimum lease payments |  | $ | 74.8 |  |  | $ | 0.3 |  |  | $ | 75.1 |  |
| Less: amount representing interest |  | (8.9) |  |  | — |  |  | (8.9) |  |
| Present value of total lease liabilities |  | $ | 65.9 |  |  | $ | 0.3 |  |  | $ | 66.2 |  |

[0001633978-21-000004:notes:87]
(1) Non-cancellable sublease proceeds for the remainder of fiscal 2021, and fiscal 2022, and 2023 of $1.5 million, $2.3 million, and $0.6 million, respectively, are not included in the table above.


## us-gaap:GoodwillDisclosureTextBlock

[0001633978-21-000004:notes:88]
[same as prior period, unchanged from 0001633978-20-000018:notes:88]

[0001633978-21-000004:notes:89]
[same as prior period, unchanged from 0001633978-20-000018:notes:89]

[0001633978-21-000004:notes:90]
The following table presents our goodwill balance by the reportable segments as of December 26, 2020 and June 27, 2020 (in millions):

[0001633978-21-000004:notes:91]
|  | Optical Communications |  | Commercial Lasers |  | Total |
| Balance as of December 26, 2020 and June 27, 2020 | $ | 363.5 |  |  | $ | 5.4 |  |  | $ | 368.9 |  |

[0001633978-21-000004:notes:92]
[same as prior period, unchanged from 0001633978-20-000018:notes:92]

[0001633978-21-000004:notes:93]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. In the fourth quarter of fiscal 2020, we completed the annual

[0001633978-21-000004:notes:94]
impairment test of goodwill, which indicated there was no goodwill impairment. There were no indicators of goodwill impairment during the three and six months ended December 26, 2020.

[0001633978-21-000004:notes:95]
[same as prior period, unchanged from 0001633978-20-000018:notes:94]

[0001633978-21-000004:notes:96]
[same as prior period, unchanged from 0001633978-20-000018:notes:95]

[0001633978-21-000004:notes:97]
On October 29, 2020, we purchased intellectual property from the third party for a total consideration of $10.0 million. These intangible assets have an estimated useful life of 5 years.

[0001633978-21-000004:notes:98]
The following tables present details of our other intangibles as of the periods presented (in millions, except for weighted average remaining amortization period):

[0001633978-21-000004:notes:99]
| December 26, 2020 | Gross Carrying Amounts |  | Accumulated Amortization |  | Net Carrying Amounts |  | Weighted average remaining amortization period (years) |
| Acquired developed technologies | $ | 381.5 |  |  | $ | (207.2) |  |  | $ | 174.3 |  |  | 3.4 |
| Customer relationships | 149.3 |  |  | (48.4) |  |  | 100.9 |  |  | 6.0 |
| In-process research and development | 10.0 |  |  | — |  |  | 10.0 |  |  | n/a |
| Order backlog | 22.0 |  |  | (22.0) |  |  | — |  |  | — |
| Other intangibles | 2.7 |  |  | (2.7) |  |  | — |  |  | — |
| Total intangible assets | $ | 565.5 |  |  | $ | (280.3) |  |  | $ | 285.2 |  |  |  |

[0001633978-21-000004:notes:100]
| June 27, 2020 | Gross Carrying Amounts |  | Accumulated Amortization |  | Net Carrying Amounts |  | Weighted average remaining amortization period (years) |
| Acquired developed technologies | $ | 371.5 |  |  | $ | (176.9) |  |  | $ | 194.6 |  |  | 3.7 |
| Customer relationships | 149.3 |  |  | (37.1) |  |  | 112.2 |  |  | 6.5 |
| In-process research and development | 10.0 |  |  | — |  |  | 10.0 |  |  | n/a |
| Order backlog | 22.0 |  |  | (22.0) |  |  | — |  |  | — |
| Other intangibles | 2.7 |  |  | (2.7) |  |  | — |  |  | — |
| Total intangible assets | $ | 555.5 |  |  | $ | (238.7) |  |  | $ | 316.8 |  |  |  |

[0001633978-21-000004:notes:101]
[same as prior period, unchanged from 0001633978-20-000018:notes:99]

[0001633978-21-000004:notes:102]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26, 2020 |  | December 28, 2019 |  | December 26, 2020 |  | December 28, 2019 |
| Cost of sales | $ | 15.0 |  |  | $ | 12.4 |  |  | $ | 30.0 |  |  | $ | 24.9 |  |
| Selling, general and administrative | 5.9 |  |  | 6.2 |  |  | 11.6 |  |  | 12.5 |  |
| Total amortization of intangibles | $ | 20.9 |  |  | $ | 18.6 |  |  | $ | 41.6 |  |  | $ | 37.4 |  |

[0001633978-21-000004:notes:103]
Based on the carrying amount of our acquired developed technologies and other intangibles, excluding IPR&D, as of December 26, 2020, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001633978-21-000004:notes:104]
| Fiscal Years |  |
| Remainder of 2021 | $ | 42.3 |  |
| 2022 | 82.1 |  |
| 2023 | 58.6 |  |
| 2024 | 38.8 |  |
| 2025 | 27.7 |  |
| Thereafter | 25.7 |  |
| Total future amortization | $ | 275.2 |  |


## us-gaap:DebtDisclosureTextBlock

[0001633978-21-000004:notes:105]
Note 9. Debt

[0001633978-21-000004:notes:106]
Convertible Notes

[0001633978-21-000004:notes:107]
2026 Notes

[0001633978-21-000004:notes:108]
In December 2019, we issued $1,050.0 million in aggregate principal amount of the 2026 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2026 Notes are governed by an indenture between the Company and U.S. Bank National Association (the “2026 Indenture”). We used approximately $196 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan credit facility, and a portion of the net proceeds of the offering to purchase approximately $200 million of our common stock concurrently with the pricing of the offering in privately negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001633978-21-000004:notes:109]
The 2026 Notes will bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on June 15, 2020. The 2026 Notes will mature on December 15, 2026, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001633978-21-000004:notes:110]
The initial conversion rate is 10.0711 shares of common stock per $1,000 principal amount of the 2026 Notes (which is equivalent to an initial conversion price of approximately $99.29 per share). The conversion rate is subject to adjustment upon the occurrence of certain specified events but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2026 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001633978-21-000004:notes:111]
Prior to the close of business on the business day immediately preceding September 15, 2026, holders of the 2026 Notes may convert their 2026 Notes only under certain circumstances discussed in detail in our Annual Report on Form 10-K for the year ended June 27, 2020.

[0001633978-21-000004:notes:112]
2024 Notes

[0001633978-21-000004:notes:113]
In March 2017, we issued $450.0 million of the 2024 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank National Association, as trustee (the “2024 Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001633978-21-000004:notes:114]
The 2024 Notes bear interest at a rate of 0.25% per year. Interest on the 2024 Notes is payable semi-annually in arrears on March 15 and September 15 of each year, beginning on September 15, 2017. The 2024 Notes will mature on March 15, 2024, unless earlier repurchased by us or converted pursuant to their terms.

[0001633978-21-000004:notes:115]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share, a 132.5% premium to the fair market value at the date of issuance. Prior to the close of business on the business day immediately preceding December 15, 2023, each holder of the 2024 Notes may convert their 2024 Notes only under certain circumstances discussed in detail in our Annual Report on Form 10-K for the year ended June 27, 2020.

[0001633978-21-000004:notes:116]
Our convertible notes consisted of the following components as of the periods presented (in millions):

[0001633978-21-000004:notes:117]
| Liability component: | December 26, 2020 |  | June 27, 2020 |
|  | 2024 Notes (1) |  | 2026 Notes |  | 2024 Notes (1) |  | 2026 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 450.0 |  |  | $ | 1,050.0 |  |
| Unamortized debt discount and debt issuance costs | (69.7) |  |  | (280.9) |  |  | (79.4) |  |  | (300.3) |  |
| Net carrying amount of the liability component | $ | 380.3 |  |  | $ | 769.1 |  |  | $ | 370.6 |  |  | $ | 749.7 |  |

[0001633978-21-000004:notes:118]
(1) Since the closing price of our stock exceeded $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of the second quarter of fiscal 2021, the 2024 Notes have become convertible at the option of the holders. Therefore, the debt component of our 2024 Notes as of December 26, 2020 was reclassified to current liabilities in our condensed consolidated balance sheet.

[0001633978-21-000004:notes:119]
If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future quarter, our 2026 Notes would also become convertible at the option of the holders and the debt component would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001633978-21-000004:notes:120]
The following table sets forth interest expense information related to the convertible notes for the periods presented (in millions):

[0001633978-21-000004:notes:121]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26, 2020 |  | December 28, 2019 |  | December 26, 2020 |  | December 28, 2019 |
| Contractual interest expense | $ | 1.6 |  |  | $ | 0.5 |  |  | $ | 3.2 |  |  | $ | 0.7 |  |
| Amortization of the debt discount and debt issuance costs | 14.7 |  |  | 6.2 |  |  | 29.1 |  |  | 10.8 |  |
| Total interest expense | $ | 16.3 |  |  | $ | 6.7 |  |  | $ | 32.3 |  |  | $ | 11.5 |  |

[0001633978-21-000004:notes:122]
The future interest and principal payments related to our convertible notes are as follows as of December 26, 2020 (in millions):

[0001633978-21-000004:notes:123]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | Total |
| Remainder of 2021 | $ | 0.6 |  |  | $ | 2.6 |  |  | $ | 3.2 |  |
| 2022 | 1.1 |  |  | 5.3 |  |  | 6.4 |  |
| 2023 | 1.1 |  |  | 5.3 |  |  | 6.4 |  |
| 2024 | 451.1 |  |  | 5.3 |  |  | 456.4 |  |
| 2025 | — |  |  | 5.3 |  |  | 5.3 |  |
| Thereafter | — |  |  | 1,057.7 |  |  | 1,057.7 |  |
| Total convertible notes payments | $ | 453.9 |  |  | $ | 1,081.5 |  |  | $ | 1,535.4 |  |

[0001633978-21-000004:notes:124]
The principal balances of our Notes are reflected in the payment periods in the table above based on their respective contractual maturities assuming no conversion.

[0001633978-21-000004:notes:125]
Term Loan Facility

[0001633978-21-000004:notes:126]
In December 2018, concurrent with the closing of the Oclaro merger, we entered into a credit agreement providing for a term loan facility (the “Term Loan Facility”) in an aggregate principal amount of $500.0 million and we drew in full the term loans available under the Term Loan Facility on the closing date of the Oclaro merger. In the second quarter of fiscal 2020, we repaid, in full, all amounts outstanding under our Term Loan Facility. During the three and six months ended December 28, 2019, we incurred $11.6 million and $18.1 million of interest expense on this Term Loan Facility, which includes $8.0 million loss on early extinguishment of debt for each period, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001633978-21-000004:notes:127]
[same as prior period, unchanged from 0001633978-20-000018:notes:140]

[0001633978-21-000004:notes:128]
[same as prior period, unchanged from 0001633978-20-000018:notes:141]

[0001633978-21-000004:notes:129]
[same as prior period, unchanged from 0001633978-20-000018:notes:142]

[0001633978-21-000004:notes:130]
|  | Foreign currency translation adjustments, net of tax (1) |  | Defined benefit obligations, net of tax (2) |  | Unrealized gain (loss) on available-for-sale securities, net of tax |  |  |  | Total |
| Beginning balance as of June 27, 2020 | $ | 9.7 |  |  | $ | (4.2) |  |  | $ | 2.4 |  |  |  |  | $ | 7.9 |  |
| Other comprehensive loss | — |  |  | — |  |  | (1.5) |  |  |  |  | (1.5) |  |
| Ending balance as of September 26, 2020 | 9.7 |  |  | (4.2) |  |  | 0.9 |  |  |  |  | 6.4 |  |
| Other comprehensive loss (3) | — |  |  | — |  |  | (0.4) |  |  |  |  | (0.4) |  |
| Ending balance as of December 26, 2020 | $ | 9.7 |  |  | $ | (4.2) |  |  | $ | 0.5 |  |  |  |  | $ | 6.0 |  |
| Beginning balance as of June 29, 2019 | $ | 9.7 |  |  | $ | (3.5) |  |  | $ | 0.9 |  |  |  |  | $ | 7.1 |  |
| Other comprehensive income | — |  |  | — |  |  | 0.1 |  |  |  |  | 0.1 |  |
| Ending balance as of September 28, 2019 | 9.7 |  |  | (3.5) |  |  | 1.0 |  |  |  |  | 7.2 |  |
| Other comprehensive loss | — |  |  | — |  |  | (0.2) |  |  |  |  | (0.2) |  |
| Ending balance as of December 28, 2019 | $ | 9.7 |  |  | $ | (3.5) |  |  | $ | 0.8 |  |  |  |  | $ | 7.0 |  |

[0001633978-21-000004:notes:131]
[same as prior period, unchanged from 0001633978-20-000018:notes:144]

[0001633978-21-000004:notes:132]
(2) We evaluate the assumptions over the fair value of our defined benefit obligations annually and make changes as necessary.
(3) Unrealized loss on available-for-sale securities for the three months ended December 26, 2020 is presented net of tax of $0.5 million. Tax impact was not material for the other periods presented.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001633978-21-000004:notes:133]
[same as prior period, unchanged from 0001633978-20-000018:notes:146]

[0001633978-21-000004:notes:134]
In previous years we have initiated various strategic restructuring actions primarily intended to reduce costs, consolidate our operations, rationalize the manufacturing of our products and align our business in response to market conditions.

[0001633978-21-000004:notes:135]
The following table summarizes the activity of restructuring and related charges during the three and six months ended December 26, 2020 and December 28, 2019 (in millions):

[0001633978-21-000004:notes:136]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26, 2020 |  | December 28, 2019 |  | December 26, 2020 |  | December 28, 2019 |
| Balance as of beginning of period | $ | 4.4 |  |  | $ | 10.7 |  |  | $ | 5.2 |  |  | $ | 14.6 |  |
| Charges | 0.2 |  |  | 0.9 |  |  | 0.2 |  |  | 2.2 |  |
| Payments | — |  |  | (6.6) |  |  | (0.8) |  |  | (11.8) |  |
| Balance as of end of period | $ | 4.6 |  |  | $ | 5.0 |  |  | $ | 4.6 |  |  | $ | 5.0 |  |

[0001633978-21-000004:notes:137]
During the three and six months ended December 26, 2020, we recorded restructuring and related charges of $0.2 million for both periods in our condensed consolidated statements of operations. The payments of $0.8 million during the six months ended December 26, 2020 were mainly attributable to previously recognized severance charges associated with the decision to move certain manufacturing from San Jose, California to our facility in Thailand and other third party vendors.

[0001633978-21-000004:notes:138]
During the three and six months ended December 28, 2019, we recorded $0.9 million and $2.2 million, respectively, in restructuring and related charges in our condensed consolidated statements of operations. The charges were mainly attributable to severance charges associated with ongoing acquisition related synergies.

[0001633978-21-000004:notes:139]
[same as prior period, unchanged from 0001633978-20-000018:notes:152]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001633978-21-000004:notes:140]
[same as prior period, unchanged from 0001633978-20-000018:notes:153]

[0001633978-21-000004:notes:141]
[same as prior period, unchanged from 0001633978-20-000018:notes:154]

[0001633978-21-000004:notes:142]
We recorded a tax provision of $14.9 million and $31.4 million for the three and six months ended December 26, 2020, respectively. Our tax provision for the three months ended December 26, 2020 includes a discrete tax benefit of $2.5 million mainly from the reversal of certain deferred tax liabilities recorded in prior periods and the excess benefit related to certain stock-based compensation that vested during the quarter, partially offset by currency re-measurement of certain tax related accounts. Our estimated effective tax rate for fiscal 2021 differs from the 21% U.S. statutory rate primarily due to the earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate as well as the U.S. federal R&D tax credits, partially offset by the income tax expense from non-deductible stock-based compensation and the tax effect of Global Intangible Low-Taxed Income (“GILTI”), net of a benefit for foreign tax credits, Base Erosion and Anti-Abuse Tax (“BEAT”), and subpart F inclusion.

[0001633978-21-000004:notes:143]
As of December 26, 2020, we had $27.6 million of unrecognized tax benefits, which, if recognized, would affect the effective tax rate. We are subject to examination of income tax returns by various domestic and foreign tax authorities. The timing of commencement, resolution and closure of tax audits is highly unpredictable. Although it is possible that certain ongoing tax audits may be concluded within the next 12 months, we cannot reasonably estimate the impact to tax expense and net income from tax exams that could be resolved or closed within the next 12 months. Subject to audit timing and uncertainty, we expect our unrecognized tax benefit amount that could affect the effective tax rate to decrease by $5.3 million over the next 12 months.

[0001633978-21-000004:notes:144]
[same as prior period, unchanged from 0001633978-20-000018:notes:157]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001633978-21-000004:notes:145]
[same as prior period, unchanged from 0001633978-20-000018:notes:158]

[0001633978-21-000004:notes:146]
[same as prior period, unchanged from 0001633978-20-000018:notes:159]

[0001633978-21-000004:notes:147]
[same as prior period, unchanged from 0001633978-20-000018:notes:160]

[0001633978-21-000004:notes:148]
As of December 26, 2020, we had 2.3 million shares subject to restricted stock units and performance stock units issued and outstanding under the 2015 Equity Incentive Plan (the “2015 Plan”). Restricted stock units and performance stock units are performance-based, time-based or a combination of both. The fair value of these grants is based on the closing market price of our common stock on the date of award.

[0001633978-21-000004:notes:149]
As of December 26, 2020, 2.3 million shares of common stock under the 2015 Plan were available for grant.

[0001633978-21-000004:notes:150]
[same as prior period, unchanged from 0001633978-20-000018:notes:163]

[0001633978-21-000004:notes:151]
In connection with the acquisition of Oclaro, we issued equity awards to Oclaro employees (“replacement awards”) in exchange for their Oclaro equity awards. As of December 26, 2020, we had 0.2 million of unvested shares subject to restricted stock units under the replacement awards.

[0001633978-21-000004:notes:152]
[same as prior period, unchanged from 0001633978-20-000018:notes:165]

[0001633978-21-000004:notes:153]
[same as prior period, unchanged from 0001633978-20-000018:notes:166]

[0001633978-21-000004:notes:154]
[same as prior period, unchanged from 0001633978-20-000018:notes:167]

[0001633978-21-000004:notes:155]
[same as prior period, unchanged from 0001633978-20-000018:notes:168]

[0001633978-21-000004:notes:156]
[same as prior period, unchanged from 0001633978-20-000018:notes:169]

[0001633978-21-000004:notes:157]
Our 2015 Employee Stock Purchase Plan (the “2015 Purchase Plan”) provides eligible employees with the opportunity to acquire an ownership interest in the Company through periodic payroll deductions and provides a 15% purchase price discount as well as a 6-month look-back period. The 2015 Purchase Plan is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986, as amended. The 2015 Purchase Plan will terminate upon the date on which all shares available for issuance have been sold. Of the 3.0 million shares authorized under the 2015 Purchase Plan, 1.7 million shares remained available for issuance as of December 26, 2020.

[0001633978-21-000004:notes:158]
[same as prior period, unchanged from 0001633978-20-000018:notes:171]

[0001633978-21-000004:notes:159]
The impact on our results of operations of recording stock-based compensation by function for the three and six months ended December 26, 2020 and December 28, 2019 was as follows (in millions):

[0001633978-21-000004:notes:160]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26, 2020 |  | December 28, 2019 |  | December 26, 2020 |  | December 28, 2019 |
| Cost of sales | $ | 4.8 |  |  | $ | 4.1 |  |  | $ | 8.5 |  |  | $ | 8.3 |  |
| Research and development | 5.1 |  |  | 4.1 |  |  | 9.5 |  |  | 7.9 |  |
| Selling, general and administrative | 14.2 |  |  | 12.0 |  |  | 25.6 |  |  | 20.7 |  |
| Total stock-based compensation | $ | 24.1 |  |  | $ | 20.2 |  |  | $ | 43.6 |  |  | $ | 36.9 |  |

[0001633978-21-000004:notes:161]
[same as prior period, unchanged from 0001633978-20-000018:notes:174]

[0001633978-21-000004:notes:162]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26, 2020 |  | December 28, 2019 |  | December 26, 2020 |  | December 28, 2019 |
| Income tax benefit associated with stock-based compensation | $ | 3.6 |  |  | $ | 3.8 |  |  | $ | 8.8 |  |  | $ | 6.6 |  |

[0001633978-21-000004:notes:163]
Approximately $4.9 million and $3.6 million of stock-based compensation was capitalized to inventory as of December 26, 2020 and June 27, 2020, respectively.

[0001633978-21-000004:notes:164]
[same as prior period, unchanged from 0001633978-20-000018:notes:177]

[0001633978-21-000004:notes:165]
The following table summarizes our awards activity for the six months ended December 26, 2020 (in millions, except per share amounts):

[0001633978-21-000004:notes:166]
|  |  |  | Restricted Stock Units |  | Performance Stock Units |
|  |  |  |  |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance as of June 27, 2020 |  |  |  |  | 1.9 |  |  | $ | 56.6 |  |  | 0.3 |  |  | $ | 60.6 |  |
| Granted |  |  |  |  | 1.1 |  |  | 86.7 |  |  | 0.2 |  |  | 86.7 |  |
| Vested |  |  |  |  | (0.8) |  |  | 56.1 |  |  | (0.1) |  |  | 57.7 |  |
| Canceled |  |  |  |  | (0.1) |  |  | 62.3 |  |  | — |  |  | 71.8 |  |
| Balance as of December 26, 2020 |  |  |  |  | 2.1 |  |  | $ | 72.2 |  |  | 0.4 |  |  | $ | 73.3 |  |

[0001633978-21-000004:notes:167]
As of December 26, 2020, $168.0 million of stock-based compensation cost related to awards granted to our employees remains to be amortized. That cost is expected to be recognized over an estimated amortization period of 2.0 years.

[0001633978-21-000004:notes:168]
[same as prior period, unchanged from 0001633978-20-000018:notes:183]

[0001633978-21-000004:notes:169]
|  | Awards Available for Grant |
| Balance as of June 27, 2020 | 3.5 |  |
| Granted | (1.3) |  |
| Canceled | 0.1 |  |
| Balance as of December 26, 2020 | 2.3 |  |

[0001633978-21-000004:notes:170]
Employee Stock Purchase Plan Activity
The 2015 Purchase Plan expense for the three months ended December 26, 2020 and December 28, 2019 was $1.2 million and $0.8 million, respectively. The 2015 Purchase Plan expense for the six months ended December 26, 2020 and December 28, 2019 was $2.3 million and $1.7 million, respectively. The expense related to the 2015 Purchase Plan is recorded on a straight-line basis over the relevant subscription period. During the three and six months ended December 26, 2020, there were 0.1 million shares issued to employees through the 2015 Purchase Plan.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001633978-21-000004:notes:171]
Note 14. Commitments and Contingencies

[0001633978-21-000004:notes:172]
Purchase Obligations

[0001633978-21-000004:notes:173]
Purchase obligations of $219.8 million as of December 26, 2020, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements.

[0001633978-21-000004:notes:174]
Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001633978-21-000004:notes:175]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-

[0001633978-21-000004:notes:176]
year supply agreements and have no significant long-term guaranteed supply agreements with such vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

[0001633978-21-000004:notes:177]
Product Warranties

[0001633978-21-000004:notes:178]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, product components or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001633978-21-000004:notes:179]
The following table presents the changes in our warranty reserve during the three and six months ended December 26, 2020 and December 28, 2019 (in millions):

[0001633978-21-000004:notes:180]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26, 2020 |  | December 28, 2019 |  | December 26, 2020 |  | December 28, 2019 |
| Balance as of beginning of period | $ | 7.6 |  |  | $ | 7.0 |  |  | $ | 5.0 |  |  | $ | 7.5 |  |
| Provision for warranty | 0.2 |  |  | 0.6 |  |  | 4.1 |  |  | 1.8 |  |
| Utilization of reserve | (2.1) |  |  | (0.8) |  |  | (3.4) |  |  | (2.5) |  |
| Balance as of end of period | $ | 5.7 |  |  | $ | 6.8 |  |  | $ | 5.7 |  |  | $ | 6.8 |  |

[0001633978-21-000004:notes:181]
Environmental Liabilities

[0001633978-21-000004:notes:182]
Our research and development (“R&D”), manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental, product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001633978-21-000004:notes:183]
Legal Proceedings

[0001633978-21-000004:notes:184]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss.

[0001633978-21-000004:notes:185]
Merger Litigation

[0001633978-21-000004:notes:186]
In connection with our acquisition of Oclaro, seven lawsuits were filed by purported stockholders of Oclaro challenging the proposed merger (the “Merger”). Two of the seven suits were putative class actions filed against Oclaro, its directors, Lumentum, Prota Merger Sub, Inc. and Prota Merger, LLC: Nicholas Neinast v. Oclaro, Inc., et al., No. 3:18-cv-03112-VC, in the United States District Court for the Northern District of California (filed May 24, 2018) (the “Neinast Lawsuit”); and Adam Franchi v. Oclaro, Inc., et al., No. 1:18-cv-00817-GMS, in the United States District Court for the District of Delaware (filed June 9, 2018) (the “Franchi Lawsuit”). Both the Neinstat Lawsuit and the Franchi Lawsuit were voluntarily dismissed with prejudice.

[0001633978-21-000004:notes:187]
The other five suits, styled as Gerald F. Wordehoff v. Oclaro, Inc., et al., No. 5:18-cv-03148-NC (the “Wordehoff Lawsuit”), Walter Ryan v. Oclaro, Inc., et al., No. 3:18-cv-03174-VC (the “Ryan Lawsuit”), Jayme Walker v. Oclaro, Inc., et al., No. 5:18-cv-03203-EJD (the “Walker Lawsuit”), Kevin Garcia v. Oclaro, Inc., et al., No. 5:18-cv-03262-VKD (the “Garcia Lawsuit”), and SaiSravan B. Karri v. Oclaro, Inc., et al., No. 3:18-cv-03435-JD (the “Karri Lawsuit” and, together with the other six lawsuits, the “Lawsuits”), were filed in the United States District Court for the Northern District of California on May 25, 2018, May 29, 2018, May 30, 2018, May 31, 2018, and June 9, 2018, respectively. These five Lawsuits named Oclaro and its directors as defendants only and did not name Lumentum. The Wordehoff, Ryan, Walker, and Garcia Lawsuits have been voluntarily dismissed, and the Wordehoff, Ryan, and Walker dismissals were with prejudice. The Karri Lawsuit has not yet been dismissed. The Ryan Lawsuit was, and the Karri Lawsuit is, a putative class action.

[0001633978-21-000004:notes:188]
The Lawsuits generally alleged, among other things, that Oclaro and its directors violated Section 14(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), and Rule 14a-9 promulgated thereunder by disseminating an incomplete and misleading Form S-4, including proxy statement/prospectus. The Lawsuits further alleged that Oclaro’s directors violated Section 20(a) of the Exchange Act by failing to exercise proper control over the person(s) who violated Section 14(a) of the Exchange Act.

[0001633978-21-000004:notes:189]
The remaining Lawsuit (the Karri Lawsuit) currently purports to seek, among other things, damages to be awarded to the plaintiff and any class, if a class is certified, and litigation costs, including attorneys’ fees.  A lead plaintiff and counsel has been selected, and an amended complaint was filed on April 15, 2019, which also names Lumentum as a defendant. A motion to dismiss the amended complaint was granted in part and denied in part by the court on October 8, 2020. On December 1, 2020, defendants answered the amended complaint.  On December 23, 2020, defendants filed a motion for leave to file a motion for reconsideration of the Court’s October 8 order on the motion to dismiss, which was denied on January 29, 2021. The Karri Lawsuit remains pending with the parties currently in discovery. Defendants intend to defend the Karri Lawsuit vigorously.

[0001633978-21-000004:notes:190]
Indemnifications

[0001633978-21-000004:notes:191]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of December 26, 2020, we did not have any material indemnification claims that were probable or reasonably possible.

[0001633978-21-000004:notes:192]
Audit Proceedings

[0001633978-21-000004:notes:193]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001633978-21-000004:notes:194]
[same as prior period, unchanged from 0001633978-20-000018:notes:208]

[0001633978-21-000004:notes:195]
[same as prior period, unchanged from 0001633978-20-000018:notes:209]

[0001633978-21-000004:notes:196]
[same as prior period, unchanged from 0001633978-20-000018:notes:210]

[0001633978-21-000004:notes:197]
[same as prior period, unchanged from 0001633978-20-000018:notes:211]

[0001633978-21-000004:notes:198]
[same as prior period, unchanged from 0001633978-20-000018:notes:212]

[0001633978-21-000004:notes:199]
[same as prior period, unchanged from 0001633978-20-000018:notes:213]

[0001633978-21-000004:notes:200]
[same as prior period, unchanged from 0001633978-20-000018:notes:214]

[0001633978-21-000004:notes:201]
[same as prior period, unchanged from 0001633978-20-000018:notes:215]

[0001633978-21-000004:notes:202]
[same as prior period, unchanged from 0001633978-20-000018:notes:216]

[0001633978-21-000004:notes:203]
[same as prior period, unchanged from 0001633978-20-000018:notes:217]

[0001633978-21-000004:notes:204]
[same as prior period, unchanged from 0001633978-20-000018:notes:218]

[0001633978-21-000004:notes:205]
[same as prior period, unchanged from 0001633978-20-000018:notes:219]

[0001633978-21-000004:notes:206]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26, 2020 |  | December 28, 2019 |  | December 26, 2020 |  | December 28, 2019 |
| Net revenue: |  |  |  |  |  |  |  |
| OpComms | $ | 449.1 |  |  | $ | 409.4 |  |  | $ | 877.6 |  |  | $ | 825.5 |  |
| Lasers | 29.7 |  |  | 48.4 |  |  | 53.6 |  |  | 82.2 |  |
| Net revenue | $ | 478.8 |  |  | $ | 457.8 |  |  | $ | 931.2 |  |  | $ | 907.7 |  |
| Gross profit: |  |  |  |  |  |  |  |
| OpComms | $ | 241.8 |  |  | $ | 196.4 |  |  | $ | 466.6 |  |  | $ | 388.3 |  |
| Lasers | 14.1 |  |  | 20.4 |  |  | 24.5 |  |  | 34.6 |  |
| Total segment gross profit | 255.9 |  |  | 216.8 |  |  | 491.1 |  |  | 422.9 |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Stock-based compensation | (4.8) |  |  | (4.1) |  |  | (8.5) |  |  | (8.3) |  |
| Amortization of acquired intangibles | (15.0) |  |  | (12.4) |  |  | (30.0) |  |  | (24.9) |  |
| Amortization of inventory fair value adjustments | — |  |  | (2.1) |  |  | — |  |  | (4.3) |  |
| Inventory and fixed asset write down due to product line exits | (0.1) |  |  | (2.6) |  |  | (0.4) |  |  | (3.7) |  |
| Integration related costs | — |  |  | — |  |  | — |  |  | (3.4) |  |
| Other charges (1) | (6.4) |  |  | (6.5) |  |  | (16.9) |  |  | (21.5) |  |
| Gross profit | $ | 229.6 |  |  | $ | 189.1 |  |  | $ | 435.3 |  |  | $ | 356.8 |  |

[0001633978-21-000004:notes:207]
(1) “Other charges” of unallocated corporate items for the three and six months ended December 26, 2020 include costs of transferring product lines to new production facilities, including Thailand of $0.4 million and $2.5 million, respectively. We also incurred excess and obsolete inventory charges driven by U.S. trade restrictions and the related decline in demand from Huawei of $0.8 million and $6.7 million during the three and six months ended December 26, 2020, respectively. In addition, during the three months ended December 26, 2020, we incurred $4.6 million of impairment charges associated with excess capacity related to our Fiber laser business.

[0001633978-21-000004:notes:208]
“Other charges” of unallocated corporate items for the three and six months ended December 28, 2019 include costs of transferring product lines to new production facilities, including Thailand of $2.0 million and $8.1 million, respectively. We also incurred excess and obsolete inventory charges driven by the decline in demand from Huawei of $6.0 million and $12.7 million during the three and six months ended December 28, 2019.

[0001633978-21-000004:notes:209]
[same as prior period, unchanged from 0001633978-20-000018:notes:222]

[0001633978-21-000004:notes:210]
[same as prior period, unchanged from 0001633978-20-000018:notes:223]

[0001633978-21-000004:notes:211]
[same as prior period, unchanged from 0001633978-20-000018:notes:224]

[0001633978-21-000004:notes:212]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26, 2020 |  | December 28, 2019 |  | December 26, 2020 |  | December 28, 2019 |
| OpComms: |  |  |  |  |  |  |  |  |  |  |  |
| Telecom and Datacom | $ | 286.2 |  | 59.8 | % |  | $ | 266.3 |  | 58.2 | % |  | $ | 547.5 |  | 58.8 | % |  | $ | 514.4 |  | 56.6 | % |
| Consumer and Industrial | 162.9 |  | 34.0 |  |  | 143.1 |  | 31.2 |  |  | 330.1 |  | 35.4 |  |  | 311.1 |  | 34.3 |  |
| Total OpComms | $ | 449.1 |  | 93.8 | % |  | $ | 409.4 |  | 89.4 | % |  | $ | 877.6 |  | 94.2 | % |  | $ | 825.5 |  | 90.9 | % |
| Lasers | 29.7 |  | 6.2 |  |  | 48.4 |  | 10.6 |  |  | 53.6 |  | 5.8 |  |  | 82.2 |  | 9.1 |  |
| Total Revenue | $ | 478.8 |  |  |  | $ | 457.8 |  |  |  | $ | 931.2 |  |  |  | $ | 907.7 |  |  |

[0001633978-21-000004:notes:213]
[same as prior period, unchanged from 0001633978-20-000018:notes:226]

[0001633978-21-000004:notes:214]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26, 2020 |  | December 28, 2019 |  | December 26, 2020 |  | December 28, 2019 |
| Net revenue: | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 39.7 |  |  | 8.3 | % |  | $ | 43.4 |  |  | 9.5 | % |  | $ | 60.0 |  |  | 6.4 | % |  | $ | 80.3 |  |  | 8.8 | % |
| Mexico | 51.3 |  |  | 10.7 |  |  | 26.2 |  |  | 5.7 |  |  | 91.1 |  |  | 9.8 |  |  | 55.1 |  |  | 6.1 |  |
| Other Americas | 4.0 |  |  | 0.8 |  |  | 0.7 |  |  | 0.2 |  |  | 6.8 |  |  | 0.8 |  |  | 1.8 |  |  | 0.2 |  |
| Total Americas | $ | 95.0 |  |  | 19.8 | % |  | $ | 70.3 |  |  | 15.4 | % |  | $ | 157.9 |  |  | 17.0 | % |  | $ | 137.2 |  |  | 15.1 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 148.0 |  |  | 30.9 | % |  | $ | 144.5 |  |  | 31.6 | % |  | $ | 292.4 |  |  | 31.4 | % |  | $ | 278.3 |  |  | 30.7 | % |
| Philippines | 40.6 |  |  | 8.5 |  |  | 4.8 |  |  | 1.0 |  |  | 103.4 |  |  | 11.1 |  |  | 29.8 |  |  | 3.3 |  |
| South Korea | 66.0 |  |  | 13.8 |  |  | 85.0 |  |  | 18.6 |  |  | 122.0 |  |  | 13.1 |  |  | 176.6 |  |  | 19.5 |  |
| Other Asia-Pacific | 94.0 |  |  | 19.6 |  |  | 116.1 |  |  | 25.4 |  |  | 185.6 |  |  | 19.9 |  |  | 216.4 |  |  | 23.8 |  |
| Total Asia-Pacific | $ | 348.6 |  |  | 72.8 | % |  | $ | 350.4 |  |  | 76.6 | % |  | $ | 703.4 |  |  | 75.5 | % |  | $ | 701.1 |  |  | 77.3 | % |
| EMEA | $ | 35.2 |  |  | 7.4 | % |  | $ | 37.1 |  |  | 8.0 | % |  | $ | 69.9 |  |  | 7.5 | % |  | $ | 69.4 |  |  | 7.6 | % |
| Total net revenue | $ | 478.8 |  |  |  |  | $ | 457.8 |  |  |  |  | $ | 931.2 |  |  |  |  | $ | 907.7 |  |  |  |

[0001633978-21-000004:notes:215]
During the three and six months ended December 26, 2020 compared to the three and six months ended December 28, 2019, our net revenue from the Philippines grew due to an introduction of a new product to one of our large customers.

[0001633978-21-000004:notes:216]
[same as prior period, unchanged from 0001633978-20-000018:notes:229]

[0001633978-21-000004:notes:217]
The following table includes estimated revenue expected to be recognized in the future for backlog related performance obligations that are unsatisfied as of December 26, 2020 (in millions):

[0001633978-21-000004:notes:218]
|  | Less than 1 year | 1-2 years | Greater than 2 years | Total |
| Performance obligations | $475.4 | $2.4 | $— | $477.8 |

[0001633978-21-000004:notes:219]
[same as prior period, unchanged from 0001633978-20-000018:notes:232]

[0001633978-21-000004:notes:220]
The following table reflects the changes in contract balances as of December 26, 2020 (in millions, except percentages):

[0001633978-21-000004:notes:221]
| Contract balances | Balance sheet location | December 26, 2020 |  | June 27, 2020 |  | Change |  | Percentage Change |
| Accounts receivable, net | Accounts receivable, net | $276.7 |  | $233.5 |  | $43.2 |  | 18.5% |
| Deferred revenue and customer deposits | Other current liabilities | $0.5 |  | $1.9 |  | $(1.4) |  | (73.7)% |

[0001633978-21-000004:notes:222]
During the three and six months ended December 26, 2020, our net revenue from a single customer, which represented 10% or greater of total net revenue was concentrated with two customers, who collectively accounted for 45% of our total net revenue for each period, respectively.

[0001633978-21-000004:notes:223]
During the three and six months ended December 28, 2019, our net revenue from a single customer, which represented 10% or greater of total net revenue was concentrated with two customers, who collectively accounted for 41% and 44% of our total net revenue, respectively.

[0001633978-21-000004:notes:224]
As of December 26, 2020, our accounts receivable balance was concentrated with two customers, which individually represented 10% or greater of gross accounts receivable and collectively accounted for 24% of the balance. As of June 27, 2020, one customer represented 10% or greater of gross accounts receivable and accounted for 14% of the balance.

[0001633978-21-000004:notes:225]
[same as prior period, unchanged from 0001633978-20-000018:notes:238]

[0001633978-21-000004:notes:226]
|  | December 26, 2020 |  | June 27, 2020 |
| Property, plant and equipment, net |  |  |  |
| United States | $ | 138.6 |  |  | $ | 139.1 |  |
| Thailand | 112.1 |  |  | 122.6 |  |
| China | 42.5 |  |  | 43.2 |  |
| Japan | 34.5 |  |  | 32.3 |  |
| Other countries | 58.1 |  |  | 55.8 |  |
| Total long-lived assets | $ | 385.8 |  |  | $ | 393.0 |  |

[0001633978-21-000004:notes:227]
We purchase a substantial portion of our inventory from contract manufacturers and vendors located primarily in Taiwan, Thailand, and Malaysia. During the three and six months ended December 26, 2020, our net inventory purchases from a single contract manufacturer, which represented 10% or greater of total net purchases, were concentrated with two contract manufacturers, who collectively accounted for 67% and 65% of total net inventory purchases, respectively. During the three and six months ended December 28, 2019, net inventory purchases which represented 10% or greater of total net purchases, were concentrated with three and two contract manufacturers, who collectively accounted for 87% and 78% of total net inventory purchases, respectively.


## us-gaap:SubsequentEventsTextBlock

[0001633978-21-000004:notes:228]
Subsequent Event
On January 18, 2021, Lumentum and Coherent, Inc. (“Coherent”) entered into a merger agreement (the “Merger Agreement”), under which Lumentum will acquire all outstanding shares of Coherent common stock. Each share of Coherent common stock will be exchanged for $100 in cash and 1.1851 shares of Lumentum common stock, subject to the terms of the Merger Agreement. As of the date of the Merger Agreement, the total transaction consideration is approximately $5.7 billion. Coherent stockholders will own approximately 27% of the combined company at closing.

[0001633978-21-000004:notes:229]
The Merger Agreement contains certain termination rights for both Lumentum and Coherent and provides that upon termination of the Merger Agreement under specified circumstances (including termination by Coherent to accept a superior proposal), Coherent may be required to pay Lumentum a termination fee of $217.6 million. The Merger Agreement further provides that upon termination of the Merger Agreement under specified circumstances (including termination by Lumentum to accept a superior proposal), Lumentum may be required to pay Coherent a termination fee of $337.7 million, and if the Merger Agreement is terminated for failure to obtain antitrust approval from a Chinese governmental entity, Lumentum may be required to pay Coherent a termination fee of $279.0 million.

[0001633978-21-000004:notes:230]
The total transaction consideration will be funded by a combination of approximately $3.2 billion in Lumentum common stock (based on the closing price of Lumentum common stock on the date preceding the Merger Agreement), $2.1 billion in new debt, and the remaining amount from the cash balances of the combined company. Lumentum entered into a commitment letter with Deutsche Bank Securities Inc. and Deutsche Bank AG New York Branch (collectively, “Deutsche Bank”), pursuant to which, subject to the terms and conditions set forth therein, Deutsche Bank has committed to provide a senior secured term loan facility in an aggregate principal amount of up to $2.1 billion.

[0001633978-21-000004:notes:231]
The Boards of Directors of Lumentum and Coherent have unanimously approved the transaction and the Merger Agreement. The transaction is subject to customary closing conditions, including the absence of certain legal impediments, the expiration or termination of the required waiting periods under the Hart-Scott-Rodino Antitrust Improvements Act of 1976, as amended, antitrust approvals in other applicable jurisdictions, including China and South Korea, the effectiveness of a registration statement on Form S-4 registering the shares of Lumentum common stock to be issued in connection with the transaction, and approval by the holders of a majority of the outstanding shares of Lumentum common stock and Coherent common stock. The transaction is not subject to any financing condition. The transaction is expected to be completed in the second half of calendar 2021.
