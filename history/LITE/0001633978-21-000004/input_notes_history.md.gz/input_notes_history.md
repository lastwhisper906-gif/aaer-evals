# LITE note change history — 0001633978-20-000018 → 0001633978-21-000004


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-02-02):
[0001633978-21-000004:note_history:1]
Purchase obligations of $219.8 million as of December 26, 2020, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements.
  (was, 2020-11-02, similarity 0.9831):
[0001633978-20-000018:note_history:1]
Purchase obligations of $257.9 million as of September 26, 2020, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements.

- added (2021-02-02):
[0001633978-21-000004:note_history:2]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-

- changed (2021-02-02):
[0001633978-21-000004:note_history:3]
year supply agreements and have no significant long-term guaranteed supply agreements with such vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.
  (was, 2020-11-02, similarity 0.8411):
[0001633978-20-000018:note_history:3]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with such vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

- changed (2021-02-02):
[0001633978-21-000004:note_history:4]
The following table presents the changes in our warranty reserve during the three and six months ended December 26, 2020 and December 28, 2019 (in millions):
  (was, 2020-11-02, similarity 0.9375):
[0001633978-20-000018:note_history:4]
The following table presents the changes in our warranty reserve during the three months ended September 26, 2020 and September 28, 2019 (in millions):

- added (2021-02-02):
[0001633978-21-000004:note_history:5]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26, 2020 |  | December 28, 2019 |  | December 26, 2020 |  | December 28, 2019 |
| Balance as of beginning of period | $ | 7.6 |  |  | $ | 7.0 |  |  | $ | 5.0 |  |  | $ | 7.5 |  |
| Provision for warranty | 0.2 |  |  | 0.6 |  |  | 4.1 |  |  | 1.8 |  |
| Utilization of reserve | (2.1) |  |  | (0.8) |  |  | (3.4) |  |  | (2.5) |  |
| Balance as of end of period | $ | 5.7 |  |  | $ | 6.8 |  |  | $ | 5.7 |  |  | $ | 6.8 |  |

- changed (2021-02-02):
[0001633978-21-000004:note_history:6]
The remaining Lawsuit (the Karri Lawsuit) currently purports to seek, among other things, damages to be awarded to the plaintiff and any class, if a class is certified, and litigation costs, including attorneys’ fees.  A lead plaintiff and counsel has been selected, and an amended complaint was filed on April 15, 2019, which also names Lumentum as a defendant. A motion to dismiss the amended complaint was granted in part and denied in part by the court on October 8, 2020. On December 1, 2020, defendants answered the amended complaint.  On December 23, 2020, defendants filed a motion for leave to file a motion for reconsideration of the Court’s October 8 order on the motion to dismiss, which was denied on January 29, 2021. The Karri Lawsuit remains pending with the parties currently in discovery. Defendants intend to defend the Karri Lawsuit vigorously.
  (was, 2020-11-02, similarity 0.6599):
[0001633978-20-000018:note_history:6]
The remaining Lawsuit (the Karri Lawsuit) currently purports to seek, among other things, damages to be awarded to the plaintiff and any class, if a class is certified, and litigation costs, including attorneys’ fees.  A lead plaintiff and counsel has been selected, and an amended complaint was filed on April 15, 2019, which also names Lumentum as a defendant. A motion to dismiss the amended complaint was granted in part and denied in part by the court on October 8, 2020. The Karri Lawsuit remains pending, and the court ordered the parties to submit a joint proposed schedule by October 30, 2020. Defendants intend to defend the Karri Lawsuit vigorously.

- changed (2021-02-02):
[0001633978-21-000004:note_history:7]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of December 26, 2020, we did not have any material indemnification claims that were probable or reasonably possible.
  (was, 2020-11-02, similarity 0.9923):
[0001633978-20-000018:note_history:7]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of September 26, 2020, we did not have any material indemnification claims that were probable or reasonably possible.

- removed (2021-02-02):
[0001633978-20-000018:note_history:8]
|  | Three Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |
| Balance as of beginning of period | $ | 5.0 |  |  | $ | 7.5 |  |
| Provision for warranty | 3.9 |  |  | 1.2 |  |
| Utilization of reserve | (1.3 | ) |  | (1.7 | ) |
| Balance as of end of period | $ | 7.6 |  |  | $ | 7.0 |  |


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-02-02):
[0001633978-21-000004:note_history:9]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2021 is a 53-week year ending on July 3, 2021, with the quarter ended December 26, 2020 being a 13-week quarterly period and our third quarter ending on April 3, 2021 being a 14-week quarterly period. Our fiscal 2020 was a 52-week year that ended on June 27, 2020, with the quarter ended December 28, 2019 being a 13-week quarterly period.
  (was, 2020-11-02, similarity 0.7672):
[0001633978-20-000018:note_history:9]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2021 is a 53-week year ending on July 3, 2021, with the quarter ended September 26, 2020 being a 13-week quarterly period. Our fiscal 2020 was a 52-week year that ended on June 27, 2020, with the quarter ended September 28, 2019 being a 13-week quarterly period.

- changed (2021-02-02):
[0001633978-21-000004:note_history:10]
Accounting Policies
The accompanying condensed consolidated financial statements and accompanying related notes should be read in conjunction with the audited consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended June 27, 2020. There have been no significant changes to these policies during the six months ended December 26, 2020, except for the removal of the long-lived asset valuation policy and the updates resulting from the adoption of Topic 326, as discussed in “Note 2. Recently Issued Accounting Pronouncements”.
  (was, 2020-11-02, similarity 0.9441):
[0001633978-20-000018:note_history:10]
The accompanying condensed consolidated financial statements and accompanying related notes should be read in conjunction with the audited consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended June 27, 2020. There have been no significant changes to these policies during the three months ended September 26, 2020, except for the removal of the long-lived asset valuation policy and the updates resulting from the adoption of Topic 326, as discussed in “Note 2. Recently Issued Accounting Pronouncements”.

- removed (2021-02-02):
[0001633978-20-000018:note_history:11]
Accounting Policies


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2021-02-02):
[0001633978-21-000004:note_history:12]
| Liability component: | December 26, 2020 |  | June 27, 2020 |
|  | 2024 Notes (1) |  | 2026 Notes |  | 2024 Notes (1) |  | 2026 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 450.0 |  |  | $ | 1,050.0 |  |
| Unamortized debt discount and debt issuance costs | (69.7) |  |  | (280.9) |  |  | (79.4) |  |  | (300.3) |  |
| Net carrying amount of the liability component | $ | 380.3 |  |  | $ | 769.1 |  |  | $ | 370.6 |  |  | $ | 749.7 |  |

- added (2021-02-02):
[0001633978-21-000004:note_history:13]
(1) Since the closing price of our stock exceeded $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of the second quarter of fiscal 2021, the 2024 Notes have become convertible at the option of the holders. Therefore, the debt component of our 2024 Notes as of December 26, 2020 was reclassified to current liabilities in our condensed consolidated balance sheet.

- removed (2021-02-02):
[0001633978-20-000018:note_history:14]
| Liability component: | September 26, 2020 |  | June 27, 2020 |
|  | 2024 Notes |  | 2026 Notes |  | 2024 Notes | 2026 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 450.0 |  | $ | 1,050.0 |  |
| Unamortized debt discount and debt issuance costs | (74.6 | ) |  | (290.7 | ) |  | (79.4 | ) | (300.3 | ) |
| Net carrying amount of the liability component | $ | 375.4 |  |  | $ | 759.3 |  |  | $ | 370.6 |  | $ | 749.7 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-02-02):
[0001633978-21-000004:note_history:15]
Prior to the close of business on the business day immediately preceding September 15, 2026, holders of the 2026 Notes may convert their 2026 Notes only under certain circumstances discussed in detail in our Annual Report on Form 10-K for the year ended June 27, 2020.
  (was, 2020-11-02, similarity 0.7736):
[0001633978-20-000018:note_history:15]
Prior to the close of business on the business day immediately preceding September 15, 2026, holders of the 2026 Notes may convert their 2026 Notes only under the following circumstances:

- changed (2021-02-02):
[0001633978-21-000004:note_history:16]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share, a 132.5% premium to the fair market value at the date of issuance. Prior to the close of business on the business day immediately preceding December 15, 2023, each holder of the 2024 Notes may convert their 2024 Notes only under certain circumstances discussed in detail in our Annual Report on Form 10-K for the year ended June 27, 2020.
  (was, 2020-11-02, similarity 0.8608):
[0001633978-20-000018:note_history:16]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share, a 132.5% premium to the fair market value at the date of issuance.  Prior to the close of business on the business day immediately preceding December 15, 2023, each holder of the 2024 Notes may convert their 2024 Notes only under the following circumstances:

- added (2021-02-02):
[0001633978-21-000004:note_history:17]
| Liability component: | December 26, 2020 |  | June 27, 2020 |
|  | 2024 Notes (1) |  | 2026 Notes |  | 2024 Notes (1) |  | 2026 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 450.0 |  |  | $ | 1,050.0 |  |
| Unamortized debt discount and debt issuance costs | (69.7) |  |  | (280.9) |  |  | (79.4) |  |  | (300.3) |  |
| Net carrying amount of the liability component | $ | 380.3 |  |  | $ | 769.1 |  |  | $ | 370.6 |  |  | $ | 749.7 |  |

- added (2021-02-02):
[0001633978-21-000004:note_history:18]
(1) Since the closing price of our stock exceeded $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of the second quarter of fiscal 2021, the 2024 Notes have become convertible at the option of the holders. Therefore, the debt component of our 2024 Notes as of December 26, 2020 was reclassified to current liabilities in our condensed consolidated balance sheet.

- added (2021-02-02):
[0001633978-21-000004:note_history:19]
If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future quarter, our 2026 Notes would also become convertible at the option of the holders and the debt component would be reclassified to current liabilities in our condensed consolidated balance sheet.

- added (2021-02-02):
[0001633978-21-000004:note_history:20]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26, 2020 |  | December 28, 2019 |  | December 26, 2020 |  | December 28, 2019 |
| Contractual interest expense | $ | 1.6 |  |  | $ | 0.5 |  |  | $ | 3.2 |  |  | $ | 0.7 |  |
| Amortization of the debt discount and debt issuance costs | 14.7 |  |  | 6.2 |  |  | 29.1 |  |  | 10.8 |  |
| Total interest expense | $ | 16.3 |  |  | $ | 6.7 |  |  | $ | 32.3 |  |  | $ | 11.5 |  |

- changed (2021-02-02):
[0001633978-21-000004:note_history:21]
The future interest and principal payments related to our convertible notes are as follows as of December 26, 2020 (in millions):
  (was, 2020-11-02, similarity 0.9799):
[0001633978-20-000018:note_history:21]
The future interest and principal payments related to our convertible notes are as follows as of September 26, 2020 (in millions):

- added (2021-02-02):
[0001633978-21-000004:note_history:22]
The principal balances of our Notes are reflected in the payment periods in the table above based on their respective contractual maturities assuming no conversion.

- changed (2021-02-02):
[0001633978-21-000004:note_history:23]
In December 2018, concurrent with the closing of the Oclaro merger, we entered into a credit agreement providing for a term loan facility (the “Term Loan Facility”) in an aggregate principal amount of $500.0 million and we drew in full the term loans available under the Term Loan Facility on the closing date of the Oclaro merger. In the second quarter of fiscal 2020, we repaid, in full, all amounts outstanding under our Term Loan Facility. During the three and six months ended December 28, 2019, we incurred $11.6 million and $18.1 million of interest expense on this Term Loan Facility, which includes $8.0 million loss on early extinguishment of debt for each period, respectively.
  (was, 2020-11-02, similarity 0.8521):
[0001633978-20-000018:note_history:23]
In December 2018, concurrent with the closing of the Oclaro merger, we entered into a credit agreement providing for a term loan facility (the “Term Loan Facility”) in an aggregate principal amount of $500.0 million and we drew in full the term loans available under the Term Loan Facility on the closing date of the Oclaro merger. In fiscal 2020, we repaid, in full, all amounts outstanding under our Term Loan Facility. During the three months ended September 28, 2019, we incurred $6.4 million interest expense on this Term Loan Facility.

- removed (2021-02-02):
[0001633978-20-000018:note_history:24]
| • | during any fiscal quarter commencing after the fiscal quarter ended on March 28, 2020 (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price of the 2026 Notes, or $129.08 on each applicable trading day; |

- removed (2021-02-02):
[0001633978-20-000018:note_history:25]
| • | during the five business day period after any five consecutive trading day period (the "2026 measurement period") in which the trading price per $1,000 principal amount of the 2026 Notes for each trading day of the 2026 measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the notes on each such trading day; |

- removed (2021-02-02):
[0001633978-20-000018:note_history:26]
| • | if we call any or all of the 2026 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the relevant redemption date; or |

- removed (2021-02-02):
[0001633978-20-000018:note_history:27]
| • | upon the occurrence of specified corporate events, as specified in each indenture governing the 2026 Notes. |

- removed (2021-02-02):
[0001633978-20-000018:note_history:28]
On or after September 15, 2026 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert the 2026 Notes at any time. Upon conversion, we may satisfy our conversion obligation in cash, shares of common stock or a combination of cash and shares of common stock, at our election.

- removed (2021-02-02):
[0001633978-20-000018:note_history:29]
We may redeem for cash, stock or combination of both for all or any portion of the 2026 Notes, at our option, on or after December 20, 2023, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide a notice of redemption at a redemption price equal to 100% of the principal amount of the 2026 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2026 Notes. Upon the occurrence of a fundamental change (as defined in the 2026 Indenture), holders may require us to repurchase all or a portion of the 2026 Notes for cash at a price equal to 100% of the principal amount of the 2026 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

- removed (2021-02-02):
[0001633978-20-000018:note_history:30]
In accordance with accounting for debt with conversions and other options, we bifurcated the principal amount of the 2026 Notes into liability and equity components. The liability component of the 2026 Notes was valued at $734.8 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 5.8% with the equity component representing the residual amount of the proceeds of $315.2 million, which was recorded as a debt discount.

- removed (2021-02-02):
[0001633978-20-000018:note_history:31]
We incurred approximately $7.8 million in transaction costs in connection with the issuance of the 2026 Notes and these costs were allocated pro rata based on the relative carrying amounts of the liability and equity components. The debt discount and debt issuance costs attributable to the liability component will be amortized to interest expense using an effective interest rate of 5.8% over the expected life of the 2026 Notes. Debt issuance costs attributable to the equity component are netted with the equity component in stockholders’ equity, and the equity component is not remeasured as long as it continues to meet the conditions for equity classification.

- removed (2021-02-02):
[0001633978-20-000018:note_history:32]
| • | during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price, or $78.80 on each applicable trading day; |

- removed (2021-02-02):
[0001633978-20-000018:note_history:33]
| • | during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of notes for each trading day of such measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day; |

- removed (2021-02-02):
[0001633978-20-000018:note_history:34]
| • | upon the occurrence of specified corporate events. |

- removed (2021-02-02):
[0001633978-20-000018:note_history:35]
On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2024 Notes at any time. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2024 Indenture), we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert 2024 Notes in connection with such make-whole fundamental change.

- removed (2021-02-02):
[0001633978-20-000018:note_history:36]
We may not redeem the 2024 Notes prior to their maturity date and no sinking fund is provided for the 2024 Notes. Upon the occurrence of a fundamental change, holders may require us to repurchase all or a portion of their 2024 Notes for cash at a price equal to 100% of the principal amount of the 2024 Notes to be repurchased, plus any accrued and unpaid interest.

- removed (2021-02-02):
[0001633978-20-000018:note_history:37]
We considered the features embedded in the 2024 Notes other than the conversion feature, including the holders’ put feature, our call feature, and the make-whole feature, and concluded that they are not required to be bifurcated and accounted for separately from the host debt instrument.

- removed (2021-02-02):
[0001633978-20-000018:note_history:38]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. We incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. We amortize the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes is 5.4% per year.

- removed (2021-02-02):
[0001633978-20-000018:note_history:39]
During the fiscal year ended July 1, 2017, we satisfied the TMA settlement condition. As such, the value of the conversion option will no longer be marked to market and was reclassified to additional paid-in capital within stockholders’ equity on our condensed consolidated balance sheet. The value of the conversion option at the time of issuance will be treated as an original issue discount for purposes of accounting for the debt component of the notes. The debt component will accrete up to the principal amount over the expected term of the debt.

- removed (2021-02-02):
[0001633978-20-000018:note_history:40]
| Liability component: | September 26, 2020 |  | June 27, 2020 |
|  | 2024 Notes |  | 2026 Notes |  | 2024 Notes | 2026 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 450.0 |  | $ | 1,050.0 |  |
| Unamortized debt discount and debt issuance costs | (74.6 | ) |  | (290.7 | ) |  | (79.4 | ) | (300.3 | ) |
| Net carrying amount of the liability component | $ | 375.4 |  |  | $ | 759.3 |  |  | $ | 370.6 |  | $ | 749.7 |  |

- removed (2021-02-02):
[0001633978-20-000018:note_history:41]
During all periods presented, the debt component of our 2024 Notes was recorded in long-term liabilities. However, if the closing price of our stock exceeds $78.80 for 20 of the last 30 trading days of the second quarter of fiscal 2021, the 2024 Notes would become convertible at the option of the holders. Therefore, the debt component of our 2024 Notes (approximately $375 million as of September 26, 2020) would be reclassified to current liabilities in our condensed consolidated balance sheet.

- removed (2021-02-02):
[0001633978-20-000018:note_history:42]
|  | Three Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |
| Contractual interest expense | $ | 1.6 |  |  | $ | 0.3 |  |
| Amortization of the debt discount and debt issuance costs | 14.4 |  |  | 4.6 |  |
| Total interest expense | $ | 16.0 |  |  | $ | 4.9 |  |

- removed (2021-02-02):
[0001633978-20-000018:note_history:43]
During the three months ended September 28, 2019, we recorded $0.1 million interest expense related to our finance leases.  Refer to “Note 7. Leases”.


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-02-02):
[0001633978-21-000004:note_history:44]
|  | Less than 12 months |  |  |  |  |
|  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |
| December 26, 2020: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 36.6 |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 72.6 |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 246.1 |  |  | (0.2) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 151.8 |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | 507.1 |  |  | $ | (0.2) |  |  |  |  |  |  |  |  |  |
| June 27, 2020: |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 3.1 |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 51.1 |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 96.5 |  |  | (0.1) |  |  |  |  |  |  |  |  |  |
| Foreign government bonds | 1.7 |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | 47.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 159.8 |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | 359.2 |  |  | $ | (0.1) |  |  |  |  |  |  |  |  |  |
  (was, 2020-11-02, similarity 0.6829):
[0001633978-20-000018:note_history:44]
|  | Less than 12 months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| September 26, 2020: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 43.3 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 43.3 |  |  | $ | — |  |
| Commercial paper | 37.2 |  |  | — |  |  | — |  |  | — |  |  | 37.2 |  |  | — |  |
| Corporate debt securities | 167.6 |  |  | (0.2 | ) |  | — |  |  | — |  |  | 167.6 |  |  | (0.2 | ) |
| U.S. government bonds | 99.9 |  |  | — |  |  | — |  |  | — |  |  | 99.9 |  |  | — |  |
| Total | $ | 348.0 |  |  | $ | (0.2 | ) |  | $ | — |  |  | $ | — |  |  | $ | 348.0 |  |  | $ | (0.2 | ) |
| June 27, 2020: |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 3.1 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 3.1 |  |  | $ | — |  |
| Commercial paper | 51.1 |  |  | — |  |  | — |  |  | — |  |  | 51.1 |  |  | — |  |
| Corporate debt securities | 96.5 |  |  | (0.1 | ) |  | — |  |  | — |  |  | 96.5 |  |  | (0.1 | ) |
| Foreign government bonds | 1.7 |  |  | — |  |  | — |  |  | — |  |  | 1.7 |  |  | — |  |
| U.S. Agency securities | 47.0 |  |  | — |  |  | — |  |  | — |  |  | 47.0 |  |  | — |  |
| U.S. government bonds | 159.8 |  |  | — |  |  | — |  |  | — |  |  | 159.8 |  |  | — |  |
| Total | $ | 359.2 |  |  | $ | (0.1 | ) |  | $ | — |  |  | $ | — |  |  | $ | 359.2 |  |  | $ | (0.1 | ) |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-02-02):
[0001633978-21-000004:note_history:45]
The future interest and principal payments related to our convertible notes are as follows as of December 26, 2020 (in millions):
  (was, 2020-11-02, similarity 0.9799):
[0001633978-20-000018:note_history:45]
The future interest and principal payments related to our convertible notes are as follows as of September 26, 2020 (in millions):


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2021-02-02):
[0001633978-21-000004:note_history:46]
Subsequent Event
On January 18, 2021, Lumentum and Coherent, Inc. (“Coherent”) entered into a merger agreement (the “Merger Agreement”), under which Lumentum will acquire all outstanding shares of Coherent common stock. Each share of Coherent common stock will be exchanged for $100 in cash and 1.1851 shares of Lumentum common stock, subject to the terms of the Merger Agreement. As of the date of the Merger Agreement, the total transaction consideration is approximately $5.7 billion. Coherent stockholders will own approximately 27% of the combined company at closing.

- added (2021-02-02):
[0001633978-21-000004:note_history:47]
The Merger Agreement contains certain termination rights for both Lumentum and Coherent and provides that upon termination of the Merger Agreement under specified circumstances (including termination by Coherent to accept a superior proposal), Coherent may be required to pay Lumentum a termination fee of $217.6 million. The Merger Agreement further provides that upon termination of the Merger Agreement under specified circumstances (including termination by Lumentum to accept a superior proposal), Lumentum may be required to pay Coherent a termination fee of $337.7 million, and if the Merger Agreement is terminated for failure to obtain antitrust approval from a Chinese governmental entity, Lumentum may be required to pay Coherent a termination fee of $279.0 million.

- added (2021-02-02):
[0001633978-21-000004:note_history:48]
The total transaction consideration will be funded by a combination of approximately $3.2 billion in Lumentum common stock (based on the closing price of Lumentum common stock on the date preceding the Merger Agreement), $2.1 billion in new debt, and the remaining amount from the cash balances of the combined company. Lumentum entered into a commitment letter with Deutsche Bank Securities Inc. and Deutsche Bank AG New York Branch (collectively, “Deutsche Bank”), pursuant to which, subject to the terms and conditions set forth therein, Deutsche Bank has committed to provide a senior secured term loan facility in an aggregate principal amount of up to $2.1 billion.

- added (2021-02-02):
[0001633978-21-000004:note_history:49]
The Boards of Directors of Lumentum and Coherent have unanimously approved the transaction and the Merger Agreement. The transaction is subject to customary closing conditions, including the absence of certain legal impediments, the expiration or termination of the required waiting periods under the Hart-Scott-Rodino Antitrust Improvements Act of 1976, as amended, antitrust approvals in other applicable jurisdictions, including China and South Korea, the effectiveness of a registration statement on Form S-4 registering the shares of Lumentum common stock to be issued in connection with the transaction, and approval by the holders of a majority of the outstanding shares of Lumentum common stock and Coherent common stock. The transaction is not subject to any financing condition. The transaction is expected to be completed in the second half of calendar 2021.

- removed (2021-02-02):
[0001633978-20-000018:note_history:50]
Note 16. Subsequent Event

- removed (2021-02-02):
[0001633978-20-000018:note_history:51]
On October 29, 2020, we closed a transaction to acquire intellectual property and certain other photonics technology assets for a total consideration of $10.0 million.
