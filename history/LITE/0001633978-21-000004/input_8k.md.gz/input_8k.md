# LITE 8-K — 0001633978-21-000002 filed 2021-02-02

## item codes, every 8-K on or before 2021-02-02

- 2021-02-02 0001633978-21-000002 — 2.02, 9.01
- 2021-01-19 0001104659-21-005024 — 1.01, 2.02, 8.01, 9.01
- 2020-11-24 0001193125-20-302557 — 5.02, 5.07
- 2020-11-02 0001633978-20-000017 — 2.02, 9.01
- 2020-09-18 0001633978-20-000012 — 5.02, 9.01
- 2020-08-11 0001633978-20-000010 — 2.02, 9.01
- 2020-05-05 0001628280-20-006358 — 2.02, 9.01
- 2020-02-04 0001633978-20-000002 — 2.02, 9.01
- 2019-12-12 0001193125-19-312875 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2019-12-04 0001633978-19-000075 — 8.01
- 2019-11-20 0001633978-19-000074 — 5.07
- 2019-10-31 0001633978-19-000070 — 2.02, 9.01
- 2019-08-08 0001633978-19-000068 — 2.02, 9.01
- 2019-05-08 0001633978-19-000031 — 1.01
- 2019-05-07 0001633978-19-000029 — 2.02, 9.01
- 2019-02-15 0001633978-19-000005 — 9.01 — amendment of 0001193125-18-346211
- 2019-02-08 0001193125-19-031591 — 5.02, 9.01
- 2019-02-05 0001633978-19-000001 — 2.02, 9.01
- 2018-12-10 0001193125-18-346211 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-12-06 0001633978-18-000150 — 8.01
- 2018-11-14 0001633978-18-000139 — 5.07
- 2018-11-13 0001633978-18-000136 — 3.02
- 2018-11-13 0001633978-18-000132 — 7.01, 9.01
- 2018-11-01 0001628280-18-013238 — 2.02, 9.01
- 2018-08-08 0001633978-18-000056 — 2.02, 9.01
- 2018-06-08 0001193125-18-188241 — 5.02, 9.01
- 2018-05-02 0001633978-18-000029 — 2.02, 9.01
- 2018-03-12 0001193125-18-078154 — 1.01, 2.01, 8.01, 9.01
- 2018-02-06 0001628280-18-001082 — 2.02, 9.01
- 2017-11-08 0001633978-17-000133 — 5.02, 9.01
- 2017-11-07 0001633978-17-000131 — 5.07
- 2017-11-01 0001633978-17-000117 — 2.02, 9.01
- 2017-08-09 0001633978-17-000058 — 2.02, 9.01
- 2017-05-04 0001633978-17-000035 — 2.02, 9.01
- 2017-03-08 0001193125-17-074740 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2017-03-02 0001193125-17-066769 — 8.01, 9.01
- 2017-02-07 0001633978-17-000005 — 2.02, 9.01
- 2017-01-03 0001628280-17-000018 — 4.01, 9.01
- 2016-11-09 0001628280-16-021143 — 5.02, 5.07, 9.01
- 2016-10-27 0001628280-16-020382 — 2.02, 9.01
- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2021-02-02

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001633978-21-000002:8k_2_02:1]
EX-99.1
2
lite_ex991xq2fy21.htm
EX-99.1

[0001633978-21-000002:8k_2_02:2]
Document

[0001633978-21-000002:8k_2_02:3]
NEWS RELEASE

[0001633978-21-000002:8k_2_02:4]
LUMENTUM ANNOUNCES FISCAL SECOND QUARTER 2021 FINANCIAL RESULTS

[0001633978-21-000002:8k_2_02:5]
•Net revenue of $478.8 million

[0001633978-21-000002:8k_2_02:6]
•GAAP gross margin of 48.0%; Non-GAAP gross margin of 53.4%

[0001633978-21-000002:8k_2_02:7]
•GAAP operating margin of 24.1%; Non-GAAP operating margin of 35.5%

[0001633978-21-000002:8k_2_02:8]
•GAAP diluted net income per share of $1.06; Non-GAAP diluted net income per share of $1.99

[0001633978-21-000002:8k_2_02:9]
San Jose, Calif., February 2, 2021 – Lumentum Holdings Inc. (“Lumentum” or the “Company”) today reported results for its fiscal second quarter of 2021 ended December 26, 2020.

[0001633978-21-000002:8k_2_02:10]
Net revenue for the fiscal second quarter of 2021 was $478.8 million, with GAAP net income of $83.2 million, or $1.06 per diluted share. Net revenue for the fiscal first quarter of 2021 was $452.4 million, with GAAP net income of $67.1 million, or $0.86 per diluted share. Net revenue for the fiscal second quarter of 2020 was $457.8 million, with GAAP net income of $49.1 million, or $0.63 per diluted share.

[0001633978-21-000002:8k_2_02:11]
Non-GAAP net income for the fiscal second quarter of 2021 was $155.7 million, or $1.99 per diluted share. Non-GAAP net income for the fiscal first quarter of 2021 was $139.2 million, or $1.78 per diluted share. Non-GAAP net income for the fiscal second quarter of 2020 was $119.4 million, or $1.53 per diluted share.

[0001633978-21-000002:8k_2_02:12]
The Company held $1,700.3 million in total cash, cash equivalents, and short-term investments at the end of the fiscal second quarter of 2021, up $89.6 million compared to the end of the fiscal first quarter of 2021.

[0001633978-21-000002:8k_2_02:13]
“Combining the positive momentum from the prior quarter, with strengthened demand in Telecom and Lasers, we achieved new record revenue and non-GAAP gross margin, operating margin, and earnings per share in the second quarter,” said Alan Lowe, President and CEO. “We are well positioned to grow revenue and earnings into the future. We have developed a broad portfolio of new products that address upcoming growth catalysts, completed our exit of low margin product lines that would have been a headwind to future growth, and lowered our fixed costs to enable stronger operating leverage and profitability as we grow.”

[0001633978-21-000002:8k_2_02:14]
“We recently announced the Coherent acquisition, which we expect to create significant shareholder value. The transaction will broaden and diversify the customers and markets in our revenue mix and aligns us with important trends in microelectronics for next generation consumer devices, 5G and other communications systems, the transition to electric vehicles, and the need for photonics in the life sciences and aerospace and defense markets. With our proven operational capabilities and track record of execution, we believe the combination will achieve the financial targets we set for Lumentum during our first quarter earnings call last November,” added Mr. Lowe.

[0001633978-21-000002:8k_2_02:15]
Financial Overview – Fiscal Second Quarter Ended December 26, 2020

[0001633978-21-000002:8k_2_02:16]
|  | GAAP Results ($ in millions) |
|  | Q2 |  | Q1 |  | Q2 |  | Change |
|  | FY 2021 |  | FY 2021 |  | FY 2020 |  | Q/Q |  | Y/Y |
| Net revenue | $478.8 |  | $452.4 |  | $457.8 |  | 5.8% |  | 4.6% |
| Gross margin | 48.0% |  | 45.5% |  | 41.3% |  | 250bps |  | 670bps |
| Operating margin | 24.1% |  | 21.9% |  | 16.3% |  | 220bps |  | 780bps |
|  | Non-GAAP Results ($ in millions) |
|  | Q2 |  | Q1 |  | Q2 |  | Change |
|  | FY 2021 |  | FY 2021 |  | FY 2020 |  | Q/Q |  | Y/Y |
| Net revenue | $478.8 |  | $452.4 |  | $457.8 |  | 5.8% |  | 4.6% |
| Gross margin | 53.4% |  | 52.0% |  | 47.4% |  | 140bps |  | 600bps |
| Operating margin | 35.5% |  | 33.7% |  | 28.8% |  | 180bps |  | 670bps |

[0001633978-21-000002:8k_2_02:17]
|  | Net Revenue by Segment ($ in millions) |
|  | Q2 |  | % of |  | Q1 |  | Q2 |  | Change |
|  | FY 2021 |  | Net Revenue |  | FY 2021 |  | FY 2020 |  | Q/Q |  | Y/Y |
| Optical Communications | $ | 449.1 |  |  | 93.8 | % |  | $ | 428.5 |  |  | $ | 409.4 |  |  | 4.8 | % |  | 9.7 | % |
| Lasers | 29.7 |  |  | 6.2 | % |  | 23.9 |  |  | 48.4 |  |  | 24.3 | % |  | (38.6) | % |
| Total | $ | 478.8 |  |  | 100.0 | % |  | $ | 452.4 |  |  | $ | 457.8 |  |  | 5.8 | % |  | 4.6 | % |

[0001633978-21-000002:8k_2_02:18]
The tables above provide comparisons of quarterly results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled “Use of Non-GAAP Financial Measures.”

[0001633978-21-000002:8k_2_02:19]
Business Outlook

[0001633978-21-000002:8k_2_02:20]
Lumentum expects the following for the fiscal third quarter 2021:

[0001633978-21-000002:8k_2_02:21]
•Net revenue in the range of $425 million to $440 million

[0001633978-21-000002:8k_2_02:22]
•Non-GAAP operating margin of 27.5% to 29.5%

[0001633978-21-000002:8k_2_02:23]
•Non-GAAP diluted earnings per share of $1.31 to $1.46

[0001633978-21-000002:8k_2_02:24]
We have not provided reconciliations from GAAP to non-GAAP measures for our outlook. A large portion of non-GAAP adjustments, such as restructuring charges, stock-based compensation, non-cash income tax expense and credits, integration related costs, inventory write down due to plans to exit certain product lines and other costs and contingencies unrelated to current and future operations are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future.

[0001633978-21-000002:8k_2_02:25]
Conference Call

[0001633978-21-000002:8k_2_02:26]
Lumentum will host a conference call today, February 2, 2021, at 5:30 am PT/8:30 am ET. A live webcast of the call and the replay will be available on the Lumentum website at http://investor.lumentum.com through February 9, 2021, at 11:59 pm ET. To listen to the live conference call, dial (844) 802-2439  or (412) 902-4275 and reference the passcode 10151529. To access the replay, dial (877) 344-7529 or (412) 317-0088 and reference the passcode 10151529. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the “Events and Presentations” section concurrently with this earnings press release. Lumentum has used, and intends to continue to use, its Investor Relations website as means of disclosing material nonpublic information and for complying with its disclosure obligations under Regulation FD. This press release is being furnished as an exhibit to a Current Report on Form 8-K filed with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001633978-21-000002:8k_2_02:27]
About Lumentum

[0001633978-21-000002:8k_2_02:28]
Lumentum (NASDAQ: LITE) is a market-leading designer and manufacturer of innovative optical and photonic products enabling optical networking and laser applications worldwide. Lumentum optical components and subsystems are part of virtually every type of telecom, enterprise, and data center network. Lumentum lasers enable advanced manufacturing techniques and diverse applications including next-generation 3D sensing capabilities. Lumentum is headquartered in San Jose, California with R&D, manufacturing, and sales offices worldwide. For more information, visit www.lumentum.com.

[0001633978-21-000002:8k_2_02:29]
Forward-Looking Statements

[0001633978-21-000002:8k_2_02:30]
Additional Information and Where to Find It

[0001633978-21-000002:8k_2_02:31]
This press release references a proposed business combination involving Lumentum Holdings Inc. and Coherent, Inc. In connection with the proposed transaction, Lumentum will file with the Securities and Exchange Commission a Registration Statement on Form S-4 that includes the joint proxy statement of Lumentum and Coherent that will also constitute a prospectus of Lumentum. The information in the preliminary proxy statement/prospectus is not complete and may be changed. When the joint proxy statement/prospectus is finalized, it will be sent to the respective stockholders of Coherent and Lumentum seeking their approval of their respective transaction-related proposals.

[0001633978-21-000002:8k_2_02:32]
Lumentum may not sell the common stock referenced in the proxy statement/prospectus until the Registration Statement on Form S-4 filed with the SEC becomes effective. The preliminary proxy statement/prospectus and this communication are not offers to sell Lumentum securities, are not soliciting an offer to buy Lumentum securities in any state where the offer and sale is not permitted and are not a solicitation of any vote or approval.

[0001633978-21-000002:8k_2_02:33]
LUMENTUM AND COHERENT URGE INVESTORS AND SECURITY HOLDERS TO READ THE REGISTRATION STATEMENT ON FORM S-4, THE RELATED JOINT PROXY STATEMENT/PROSPECTUS INCLUDED THEREIN AND OTHER DOCUMENTS FILED WITH THE SEC CAREFULLY AND IN THEIR ENTIRETY WHEN THEY BECOME AVAILABLE BECAUSE THEY WILL CONTAIN IMPORTANT INFORMATION ABOUT THE PROPOSED TRANSACTION.

[0001633978-21-000002:8k_2_02:34]
Investors and security holders will be able to obtain these materials (when they are available and filed) free of charge at the SEC’s website, www.sec.gov. Copies of documents filed with the SEC by Lumentum (when they become available) may be obtained free of charge on Lumentum’s website at www.lumentum.com or by contacting Lumentum’s Investor Relations Department at investor.relations@lumentum.com. Copies of documents filed with the SEC by Coherent (when they become available) may be obtained free of charge on Coherent’s website at https://investors.coherent.com/ by contacting Coherent’s Investor Relations at investor.relations@coherent.com.

[0001633978-21-000002:8k_2_02:35]
Participants in the Merger Solicitation

[0001633978-21-000002:8k_2_02:36]
Each of Lumentum, Coherent and directors, executive officers and certain other members of management and employees may be deemed to be participants in the solicitation of proxies in respect of the transaction. Information regarding these persons who may, under the rules of the SEC, be considered participants in the solicitation of the respective stockholders of Coherent and Lumentum in connection with the proposed transaction is set forth in the proxy statement/prospectus to be filed with the SEC. Additional information regarding Lumentum’s executive officers and directors is included in Lumentum’s definitive proxy statement, which was filed with the SEC on September 25, 2020. Additional information regarding Coherent’s executive officers and directors is included in Coherent’s definitive proxy statement, which was filed with the SEC on April 6, 2020. You can obtain free copies of these documents using the information in the paragraph immediately above.

[0001633978-21-000002:8k_2_02:37]
Contact Information

[0001633978-21-000002:8k_2_02:38]
Investors:            Jim Fanucchi, 408-404-5400; investor.relations@lumentum.com

[0001633978-21-000002:8k_2_02:39]
Media:         Sean Ogarrio, 408-546-5405; media@lumentum.com

[0001633978-21-000002:8k_2_02:40]
Category:            Financial

[0001633978-21-000002:8k_2_02:41]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001633978-21-000002:8k_2_02:42]
LUMENTUM HOLDINGS INC.

[0001633978-21-000002:8k_2_02:43]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001633978-21-000002:8k_2_02:44]
(in millions, except per share data)

[0001633978-21-000002:8k_2_02:45]
(unaudited)

[0001633978-21-000002:8k_2_02:46]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26, 2020 |  | December 28, 2019 |  | December 26, 2020 |  | December 28, 2019 |
| Net revenue | $ | 478.8 |  |  | $ | 457.8 |  |  | $ | 931.2 |  |  | $ | 907.7 |  |
| Cost of sales | 234.2 |  |  | 256.3 |  |  | 465.9 |  |  | 526.0 |  |
| Amortization of acquired developed intangibles | 15.0 |  |  | 12.4 |  |  | 30.0 |  |  | 24.9 |  |
| Gross profit | 229.6 |  |  | 189.1 |  |  | 435.3 |  |  | 356.8 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 52.8 |  |  | 51.0 |  |  | 103.2 |  |  | 100.9 |  |
| Selling, general and administrative | 61.3 |  |  | 62.4 |  |  | 117.6 |  |  | 119.1 |  |
| Restructuring and related charges | 0.2 |  |  | 0.9 |  |  | 0.2 |  |  | 2.2 |  |
| Total operating expenses | 114.3 |  |  | 114.3 |  |  | 221.0 |  |  | 222.2 |  |
| Income from operations | 115.3 |  |  | 74.8 |  |  | 214.3 |  |  | 134.6 |  |
| Interest expense | (16.3) |  |  | (18.3) |  |  | (32.3) |  |  | (29.7) |  |
| Other income (expense), net | (0.9) |  |  | 1.2 |  |  | (0.3) |  |  | 6.2 |  |
| Income before income taxes | 98.1 |  |  | 57.7 |  |  | 181.7 |  |  | 111.1 |  |
| Provision for income taxes | 14.9 |  |  | 8.6 |  |  | 31.4 |  |  | 14.4 |  |
| Net income | $ | 83.2 |  |  | $ | 49.1 |  |  | $ | 150.3 |  |  | $ | 96.7 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 1.10 |  |  | $ | 0.64 |  |  | $ | 1.99 |  |  | $ | 1.26 |  |
| Diluted | $ | 1.06 |  |  | $ | 0.63 |  |  | $ | 1.92 |  |  | $ | 1.24 |  |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |
| Basic | 75.6 |  |  | 76.8 |  |  | 75.5 |  |  | 76.9 |  |
| Diluted | 78.4 |  |  | 78.0 |  |  | 78.3 |  |  | 77.8 |  |

[0001633978-21-000002:8k_2_02:47]
LUMENTUM HOLDINGS INC.

[0001633978-21-000002:8k_2_02:48]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001633978-21-000002:8k_2_02:49]
(in millions, except per share data)

[0001633978-21-000002:8k_2_02:50]
(unaudited)

[0001633978-21-000002:8k_2_02:51]
|  | December 26, 2020 |  | June 27, 2020 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 321.3 |  |  | $ | 298.0 |  |
| Short-term investments | 1,379.0 |  |  | 1,255.8 |  |
| Accounts receivable, net | 276.7 |  |  | 233.5 |  |
| Inventories | 207.1 |  |  | 188.9 |  |
| Prepayments and other current assets | 82.1 |  |  | 73.8 |  |
| Total current assets | 2,266.2 |  |  | 2,050.0 |  |
| Property, plant and equipment, net | 385.8 |  |  | 393.0 |  |
| Operating lease right-of-use assets, net | 71.8 |  |  | 78.7 |  |
| Goodwill | 368.9 |  |  | 368.9 |  |
| Other intangible assets, net | 285.2 |  |  | 316.8 |  |
| Deferred income taxes | 84.9 |  |  | 81.2 |  |
| Other non-current assets | 5.4 |  |  | 4.0 |  |
| Total assets | $ | 3,468.2 |  |  | $ | 3,292.6 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 111.3 |  |  | $ | 150.8 |  |
| Accrued payroll and related expenses | 46.9 |  |  | 53.4 |  |
| Accrued expenses | 32.7 |  |  | 23.7 |  |
| Convertible notes, current | 380.3 |  |  | — |  |
| Operating lease liabilities, current | 10.8 |  |  | 10.8 |  |
| Other current liabilities | 65.3 |  |  | 44.3 |  |
| Total current liabilities | 647.3 |  |  | 283.0 |  |
| Convertible notes, non-current | 769.1 |  |  | 1,120.3 |  |
| Operating lease liabilities, non-current | 55.1 |  |  | 57.6 |  |
| Deferred tax liability | 36.7 |  |  | 46.5 |  |
| Other non-current liabilities | 38.1 |  |  | 36.0 |  |
| Total liabilities | 1,546.3 |  |  | 1,543.4 |  |
| Commitments and contingencies |  |  |  |
| Stockholders’ equity: |  |  |  |
| Common stock, $0.001 par value, 990 authorized shares, 75.7 and 75.1 shares issued and outstanding as of December 26, 2020 and June 27, 2020, respectively | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital | 1,700.9 |  |  | 1,676.6 |  |
| Retained earnings | 214.9 |  |  | 64.6 |  |
| Accumulated other comprehensive income | 6.0 |  |  | 7.9 |  |
| Total stockholders’ equity | 1,921.9 |  |  | 1,749.2 |  |
| Total liabilities and stockholders’ equity | $ | 3,468.2 |  |  | $ | 3,292.6 |  |

[0001633978-21-000002:8k_2_02:52]
Use of Non-GAAP Financial Measures

[0001633978-21-000002:8k_2_02:53]
In this press release, Lumentum provides investors with gross margin, gross profit, research and development expense, selling, general and administrative expense, operating margin, operating income, interest and other income (expense), net, income before income taxes, provision for taxes, net income, and net income per share on a non-GAAP basis as well as the non-GAAP measures of EBITDA and Adjusted EBITDA. Lumentum believes this non-GAAP financial information provides additional insight into the Company’s on-going business operations and results, as well as cash generation, and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons. In addition, the Company believes that providing certain of these measures allow investors to better understand the Company’s cash flows and, importantly, to evaluate the efficacy of the methodology and information used by management to evaluate and measure such cash flows. However, these measures may be different from non-GAAP measures used by other companies, limiting their usefulness for comparison purposes. The non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP. Investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future. Further, these non-GAAP financial measures may not be comparable to similarly titled measurements reported by other companies.

[0001633978-21-000002:8k_2_02:54]
Non-GAAP gross margin, non-GAAP gross profit, non-GAAP expenses, non-GAAP operating margin, non-GAAP operating income, non-GAAP income before income taxes, non-GAAP net income, and non-GAAP net income per share and Adjusted EBITDA exclude (i) stock-based compensation, (ii) inventory write-downs and fixed asset impairment due to cancelled programs, plans to exit certain lines of business and other costs and contingencies unrelated to current and future operations, (iii) acquisition and disposition related costs, (iv) integration related costs, (v) amortization of acquired intangibles, (vi) amortization of inventory fair value adjustments, (vii) restructuring and related charges, (viii) non-cash interest expense, (ix) foreign exchange (gains) losses, net, (x) transferring product lines to Thailand, (xi) excess and obsolete inventory charges driven by U.S. trade restrictions and the related decline in demand from Huawei, and (xii) non-cash income tax impacts. The presentation of these and other similar items in Lumentum’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001633978-21-000002:8k_2_02:55]
A quantitative reconciliation between GAAP and non-GAAP financial data with respect to historical periods is included in the supplemental financial table attached to this press release.

[0001633978-21-000002:8k_2_02:56]
LUMENTUM HOLDINGS INC.

[0001633978-21-000002:8k_2_02:57]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001633978-21-000002:8k_2_02:58]
(in millions, except per share data)

[0001633978-21-000002:8k_2_02:59]
(unaudited)

[0001633978-21-000002:8k_2_02:60]
|  | Three Months Ended |  |  | Six Months Ended |  |
|  | December 26, 2020 |  | September 26, 2020 |  | December 28, 2019 |  |  | December 26, 2020 |  | December 28, 2019 |  |
| Gross profit on GAAP basis | $ | 229.6 |  |  | $ | 205.7 |  |  | $ | 189.1 |  |  |  | $ | 435.3 |  |  | $ | 356.8 |  |  |
| Stock-based compensation | 4.8 |  |  | 3.7 |  |  | 4.1 |  |  |  | 8.5 |  |  | 8.3 |  |  |
| Inventory and fixed asset write down due to product line exits (1) | 0.1 |  |  | 0.3 |  |  | 2.6 |  |  |  | 0.4 |  |  | 3.7 |  |  |
| Integration related costs | — |  |  | — |  |  | — |  |  |  | — |  |  | 3.4 |  |  |
| Amortization of acquired intangibles | 15.0 |  |  | 15.0 |  |  | 12.4 |  |  |  | 30.0 |  |  | 24.9 |  |  |
| Amortization of inventory fair value adjustments | — |  |  | — |  |  | 2.1 |  |  |  | — |  |  | 4.3 |  |  |
| Other charges (2) | 6.4 |  |  | 10.5 |  |  | 6.5 |  |  |  | 16.9 |  |  | 21.5 |  |  |
| Gross profit on non-GAAP basis | $ | 255.9 |  |  | $ | 235.2 |  |  | $ | 216.8 |  |  |  | $ | 491.1 |  |  | $ | 422.9 |  |  |
| Gross margin on non-GAAP basis | 53.4 | % |  | 52.0 | % |  | 47.4 | % |  |  | 52.7 | % |  | 46.6 | % |  |
| Research and development on GAAP basis | $ | 52.8 |  |  | $ | 50.4 |  |  | $ | 51.0 |  |  |  | $ | 103.2 |  |  | $ | 100.9 |  |  |
| Stock-based compensation | (5.1) |  |  | (4.4) |  |  | (4.1) |  |  |  | (9.5) |  |  | (7.9) |  |  |
| Other charges | 0.1 |  |  | (0.1) |  |  | (0.1) |  |  |  | — |  |  | 0.1 |  |  |
| Research and development on non-GAAP basis | $ | 47.8 |  |  | $ | 45.9 |  |  | $ | 46.8 |  |  |  | $ | 93.7 |  |  | $ | 93.1 |  |  |
| Selling, general and administrative on GAAP basis | $ | 61.3 |  |  | $ | 56.3 |  |  | $ | 62.4 |  |  |  | $ | 117.6 |  |  | $ | 119.1 |  |  |
| Stock-based compensation | (14.2) |  |  | (11.4) |  |  | (12.0) |  |  |  | (25.6) |  |  | (20.7) |  |  |
| Integration related costs | (0.2) |  |  | (0.3) |  |  | (2.9) |  |  |  | (0.5) |  |  | (6.1) |  |  |
| Amortization of acquired intangibles | (5.9) |  |  | (5.7) |  |  | (6.2) |  |  |  | (11.6) |  |  | (12.5) |  |  |
| Other charges (3) | (2.8) |  |  | (2.1) |  |  | (3.3) |  |  |  | (4.9) |  |  | (4.7) |  |  |
| Selling, general and administrative on non-GAAP basis | $ | 38.2 |  |  | $ | 36.8 |  |  | $ | 38.0 |  |  |  | $ | 75.0 |  |  | $ | 75.1 |  |  |
| Income from operations on GAAP basis | $ | 115.3 |  |  | $ | 99.0 |  |  | $ | 74.8 |  |  |  | $ | 214.3 |  |  | $ | 134.6 |  |  |
| Stock-based compensation | 24.1 |  |  | 19.5 |  |  | 20.2 |  |  |  | 43.6 |  |  | 36.9 |  |  |
| Inventory and fixed asset write down due to product line exits (1) | 0.1 |  |  | 0.3 |  |  | 2.6 |  |  |  | 0.4 |  |  | 3.7 |  |  |
| Integration related costs | 0.2 |  |  | 0.3 |  |  | 2.9 |  |  |  | 0.5 |  |  | 9.5 |  |  |
| Amortization of acquired intangibles | 20.9 |  |  | 20.7 |  |  | 18.6 |  |  |  | 41.6 |  |  | 37.4 |  |  |
| Amortization of inventory fair value adjustments | — |  |  | — |  |  | 2.1 |  |  |  | — |  |  | 4.3 |  |  |
| Restructuring and related charges | 0.2 |  |  | — |  |  | 0.9 |  |  |  | 0.2 |  |  | 2.2 |  |  |
| Other charges | 9.1 |  |  | 12.7 |  |  | 9.9 |  |  |  | 21.8 |  |  | 26.1 |  |  |
| Income from operations on non-GAAP basis | $ | 169.9 |  |  | $ | 152.5 |  |  | $ | 132.0 |  |  |  | $ | 322.4 |  |  | $ | 254.7 |  |  |
| Operating margin on non-GAAP basis | 35.5 | % |  | 33.7 | % |  | 28.8 | % |  |  | 34.6 | % |  | 28.1 | % |  |
| Interest and other income (expense), net on GAAP basis | $ | (17.2) |  |  | $ | (15.4) |  |  | $ | (17.1) |  |  |  | $ | (32.6) |  |  | $ | (23.5) |  |  |
| Gain on sale of product lines | (0.1) |  |  | (0.4) |  |  | — |  |  |  | (0.5) |  |  | — |  |  |

[0001633978-21-000002:8k_2_02:61]
| Foreign exchange (gains) losses, net | 2.8 |  |  | 2.3 |  |  | 2.1 |  |  |  | 5.1 |  |  | 1.0 |  |  |
| Non-cash interest expense on convertible notes and term loan | 14.7 |  |  | 14.4 |  |  | 14.4 |  |  |  | 29.1 |  |  | 19.3 |  |  |
| Interest and other income (expense), net on non-GAAP basis | $ | 0.2 |  |  | $ | 0.9 |  |  | $ | (0.6) |  |  |  | $ | 1.1 |  |  | $ | (3.2) |  |  |
| Income before income taxes on GAAP basis | $ | 98.1 |  |  | $ | 83.6 |  |  | $ | 57.7 |  |  |  | $ | 181.7 |  |  | $ | 111.1 |  |  |
| Stock-based compensation | 24.1 |  |  | 19.5 |  |  | 20.2 |  |  |  | 43.6 |  |  | 36.9 |  |  |
| Inventory and fixed asset write down due to product line exits (1) | 0.1 |  |  | 0.3 |  |  | 2.6 |  |  |  | 0.4 |  |  | 3.7 |  |  |
| Integration related costs | 0.2 |  |  | 0.3 |  |  | 2.9 |  |  |  | 0.5 |  |  | 9.5 |  |  |
| Amortization of acquired intangibles | 20.9 |  |  | 20.7 |  |  | 18.6 |  |  |  | 41.6 |  |  | 37.4 |  |  |
| Amortization of inventory fair value adjustments | — |  |  | — |  |  | 2.1 |  |  |  | — |  |  | 4.3 |  |  |
| Restructuring and related charges | 0.2 |  |  | — |  |  | 0.9 |  |  |  | 0.2 |  |  | 2.2 |  |  |
| Gain on sale of product lines | (0.1) |  |  | (0.4) |  |  | — |  |  |  | (0.5) |  |  | — |  |  |
| Foreign exchange (gains) losses, net | 2.8 |  |  | 2.3 |  |  | 2.1 |  |  |  | 5.1 |  |  | 1.0 |  |  |
| Non-cash interest expense on convertible notes and term loan | 14.7 |  |  | 14.4 |  |  | 14.4 |  |  |  | 29.1 |  |  | 19.3 |  |  |
| Other charges | 9.1 |  |  | 12.7 |  |  | 9.9 |  |  |  | 21.8 |  |  | 26.1 |  |  |
| Income before income taxes on non-GAAP basis | $ | 170.1 |  |  | $ | 153.4 |  |  | $ | 131.4 |  |  |  | $ | 323.5 |  |  | $ | 251.5 |  |  |
| Provision for income taxes on GAAP basis | $ | 14.9 |  |  | $ | 16.5 |  |  | $ | 8.6 |  |  |  | $ | 31.4 |  |  | $ | 14.4 |  |  |
| Income tax adjustments | (0.5) |  |  | (2.3) |  |  | 3.4 |  |  |  | (2.8) |  |  | 6.3 |  |  |
| Provision for income taxes on non-GAAP basis | $ | 14.4 |  |  | $ | 14.2 |  |  | $ | 12.0 |  |  |  | $ | 28.6 |  |  | $ | 20.7 |  |  |
| Net income (loss) on GAAP basis | $ | 83.2 |  |  | $ | 67.1 |  |  | $ | 49.1 |  |  |  | $ | 150.3 |  |  | $ | 96.7 |  |  |
| Stock-based compensation | 24.1 |  |  | 19.5 |  |  | 20.2 |  |  |  | 43.6 |  |  | 36.9 |  |  |
| Inventory and fixed asset write down due to product line exits (1) | 0.1 |  |  | 0.3 |  |  | 2.6 |  |  |  | 0.4 |  |  | 3.7 |  |  |
| Integration related costs | 0.2 |  |  | 0.3 |  |  | 2.9 |  |  |  | 0.5 |  |  | 9.5 |  |  |
| Amortization of acquired intangibles | 20.9 |  |  | 20.7 |  |  | 18.6 |  |  |  | 41.6 |  |  | 37.4 |  |  |
| Amortization of inventory fair value adjustments | — |  |  | — |  |  | 2.1 |  |  |  | — |  |  | 4.3 |  |  |
| Restructuring and related charges | 0.2 |  |  | — |  |  | 0.9 |  |  |  | 0.2 |  |  | 2.2 |  |  |
| Gain on sale of product lines | (0.1) |  |  | (0.4) |  |  | — |  |  |  | (0.5) |  |  | — |  |  |
| Foreign exchange (gains) losses, net | 2.8 |  |  | 2.3 |  |  | 2.1 |  |  |  | 5.1 |  |  | 1.0 |  |  |
| Non-cash interest expense on convertible notes and term loan | 14.7 |  |  | 14.4 |  |  | 14.4 |  |  |  | 29.1 |  |  | 19.3 |  |  |
| Income tax adjustments | 0.5 |  |  | 2.3 |  |  | (3.4) |  |  |  | 2.8 |  |  | (6.3) |  |  |
| Other charges | 9.1 |  |  | 12.7 |  |  | 9.9 |  |  |  | 21.8 |  |  | 26.1 |  |  |
| Net income on non-GAAP basis | $ | 155.7 |  |  | $ | 139.2 |  |  | $ | 119.4 |  |  |  | $ | 294.9 |  |  | $ | 230.8 |  |  |
| Net income per share on non-GAAP basis | $ | 1.99 |  |  | $ | 1.78 |  |  | $ | 1.53 |  |  |  | $ | 3.77 |  |  | $ | 2.97 |  |  |
| Shares used in per share calculation - diluted on GAAP and non-GAAP basis | 78.4 |  |  | 78.2 |  |  | 78.0 |  |  |  | 78.3 |  |  | 77.8 |  |  |

[0001633978-21-000002:8k_2_02:62]
(1) For the three months ended December 26, 2020, September 26, 2020, and December 28, 2019, we recorded inventory and fixed asset write down charges of $0.1 million, $0.3 million, and $2.6 million, respectively, related to the decision to exit the Datacom module and Lithium Niobate product lines.

[0001633978-21-000002:8k_2_02:63]
(2) Other charges excluded from gross profit on non-GAAP basis for the three months ended December 26, 2020, September 26, 2020, and December 28, 2019, include costs of transferring product lines to new production facilities, including Thailand of $0.4 million, $2.1 million, and $2.0 million, respectively. We also incurred excess and obsolete inventory charges driven by U.S. trade restrictions and the related decline in demand from Huawei of $0.8 million, $5.9 million, and $6.0 million for the three months ended December 26, 2020, September 26, 2020, and December 28, 2019, respectively. In addition, during the three months ended December 26, 2020, we incurred $4.6 million of impairment charges associated with excess capacity related to our Fiber laser business.

[0001633978-21-000002:8k_2_02:64]
(3) Other charges excluded from SG&A expense on non-GAAP basis for the periods presented are mainly attributable to the acquisitions related costs.

[0001633978-21-000002:8k_2_02:65]
LUMENTUM HOLDINGS INC.

[0001633978-21-000002:8k_2_02:66]
RECONCILIATION OF GAAP NET INCOME TO ADJUSTED EBITDA

[0001633978-21-000002:8k_2_02:67]
(in millions, except per share data)

[0001633978-21-000002:8k_2_02:68]
(unaudited)

[0001633978-21-000002:8k_2_02:69]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26, 2020 |  |  |  | September 26, 2020 |  | December 28, 2019 |  | December 26, 2020 |  | December 28, 2019 |
| GAAP Net income | $ | 83.2 |  |  |  |  | $ | 67.1 |  |  | $ | 49.1 |  |  | $ | 150.3 |  |  | $ | 96.7 |  |
| Interest and other expense (income), net | 17.2 |  |  |  |  | 15.4 |  |  | 17.1 |  |  | 32.6 |  |  | 23.5 |  |
| Provision for income taxes | 14.9 |  |  |  |  | 16.5 |  |  | 8.6 |  |  | 31.4 |  |  | 14.4 |  |
| Depreciation | 23.8 |  |  |  |  | 23.8 |  |  | 28.7 |  |  | 47.6 |  |  | 60.3 |  |
| Amortization of acquired intangibles | 20.9 |  |  |  |  | 20.7 |  |  | 18.6 |  |  | 41.6 |  |  | 37.4 |  |
| EBITDA | 160.0 |  |  |  |  | 143.5 |  |  | 122.1 |  |  | 303.5 |  |  | 232.3 |  |
| Amortization of inventory fair value adjustments | — |  |  |  |  | — |  |  | 2.1 |  |  | — |  |  | 4.3 |  |
| Restructuring and related charges | 0.2 |  |  |  |  | — |  |  | 0.9 |  |  | 0.2 |  |  | 2.2 |  |
| Stock-based compensation | 24.1 |  |  |  |  | 19.5 |  |  | 20.2 |  |  | 43.6 |  |  | 36.9 |  |
| Inventory and fixed asset write down due to product line exits | 0.1 |  |  |  |  | 0.3 |  |  | 2.6 |  |  | 0.4 |  |  | 3.7 |  |
| Integration related costs | 0.2 |  |  |  |  | 0.3 |  |  | 2.9 |  |  | 0.5 |  |  | 9.5 |  |
| Other charges | 9.1 |  |  |  |  | 12.7 |  |  | 9.9 |  |  | 21.8 |  |  | 26.1 |  |
| Adjusted EBITDA | $ | 193.7 |  |  |  |  | $ | 176.3 |  |  | $ | 160.7 |  |  | $ | 370.0 |  |  | $ | 315.0 |  |
