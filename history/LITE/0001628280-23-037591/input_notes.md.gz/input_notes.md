# LITE notes — 0001628280-23-037591


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001628280-23-037591:notes:1]
[same as prior period, unchanged from 0001628280-23-016653:notes:1]

[0001628280-23-037591:notes:2]
[same as prior period, unchanged from 0001628280-23-016653:notes:2]

[0001628280-23-037591:notes:3]
Lumentum Holdings Inc. (“we,” “us,” “our,” “Lumentum” or the “Company”) is an industry-leading provider of optical and photonic products addressing a range of end market applications for manufacturing, inspection, and life-science applications.

[0001628280-23-037591:notes:4]
Our Cloud and Networking products include a wide range of components, modules, and subsystems to support customers including carrier networks for access (local), metro (intracity), long-haul (city-to-city and worldwide) and submarine (undersea) applications. Our  products also address enterprise, cloud, and data center applications, including storage-access networks (“SANs”), local-area networks (“LANs”) and wide-area networks (“WANs”), as well as artificial intelligence and machine learning (“AI/ML”).

[0001628280-23-037591:notes:5]
Our Industrial Tech products include diode laser products such as VCSELs and edge emitting lasers. In the consumer end-market, our laser light sources are integrated into 3D sensing cameras which are used in applications in mobile devices, gaming, payment kiosks, computers, and other consumer electronics devices. Applications include biometric identification, computational photography, virtual and augmented reality, and natural user interfaces, among others. In the industrial end-market, our diode lasers are used primarily as pump sources for pulsed and kilowatt class fiber lasers. Our products also include laser products used in a variety of OEM applications including diode-pumped solid-state, fiber, diode, direct-diode and gas lasers such as argon-ion and helium-neon lasers.

[0001628280-23-037591:notes:6]
[same as prior period, unchanged from 0001628280-23-016653:notes:4]

[0001628280-23-037591:notes:7]
We have prepared the accompanying condensed consolidated financial statements in accordance with U.S. generally accepted accounting principles (“GAAP”), which requires management to make estimates and assumptions that affect the amounts reported in our condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact us in the future, actual results may be different from the estimates. Our interim period operating results do not necessarily indicate the results that may be expected for any other interim period or for the full fiscal year. In the opinion of the Company’s management, the information presented herein reflects all normal and recurring adjustments necessary for a fair presentation of our results of operations, financial position, stockholders’ equity, and cash flows. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective, or complex judgments by management. Those policies are inventory valuation, revenue recognition, income taxes, goodwill, and business combinations.

[0001628280-23-037591:notes:8]
Prior to fiscal year 2024, we operated in two reportable segments consisting of Optical Communications (“OpComms”) and Commercial Lasers (“Lasers”). During the fiscal first quarter of 2024, we changed our organizational structure to better align with trends in our markets and our customer and product mix. Our new operating segments are Cloud & Networking and Industrial Tech. The Cloud & Networking segment includes the Telecom and Datacom product lines that were previously part of the OpComms segment. The Industrial Tech segment includes the previous Lasers segment and the Industrial & Consumer product lines that were previously part of the OpComms segment. Comparative prior period segment information has been recast to conform to the new segment structure and measures. The changes in our operating segments had no impact on our previously reported consolidated results of operations, financial condition, or cash flows. Refer to “Note 15. Operating Segments and Geographic Information”.

[0001628280-23-037591:notes:9]
Our business and operating results depend significantly on general market and economic conditions. The current global macroeconomic environment is volatile and continues to be adversely impacted by inflation, a dynamic supply chain and demand environment, and signs of a weaker macroeconomic environment impacting capital expenditures across our served markets. Additionally, instability in the global credit markets, capital expenditure reductions, unemployment and other labor issues, decline in stock markets, the instability in the geopolitical environment in many parts of the world, and the current global economic challenges continue to put pressure on our business and operating results.

[0001628280-23-037591:notes:10]
We are continuously monitoring both the current developments in the ongoing war between Russia and Ukraine including the related additional export controls and resulting sanctions imposed on Russia and Belarus by the U.S. and other countries, and the recent war between Israel and Hamas. Additional factors, such as increased inflation, escalating energy costs, constrained raw material availability and the related cost increases, could continue to impact the global economy and our business. Although the global implications of the wars are difficult to predict at this time, we do not presently foresee direct material adverse effects on our business.

[0001628280-23-037591:notes:11]
[same as prior period, unchanged from 0001628280-23-016653:notes:9]

[0001628280-23-037591:notes:12]
On August 3, 2022, we completed a merger with NeoPhotonics Corporation (“NeoPhotonics”). On August 15, 2022, we completed a transaction to acquire IPG Photonics’ telecom transmission product lines. We have applied the acquisition method of accounting in accordance with ASC Topic 805, Business Combinations to account for both of the transactions. Refer to “Note 4. Business Combinations”.

[0001628280-23-037591:notes:13]
[same as prior period, unchanged from 0001628280-23-016653:notes:12]

[0001628280-23-037591:notes:14]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2024 is a 52-week year ending on June 29, 2024, with the quarter ended September 30, 2023 being a 13-week quarterly period. Our fiscal 2023 was a 52-week year that ended on July 1, 2023, with the quarter ended October 1, 2022 being a 13-week quarterly period.

[0001628280-23-037591:notes:15]
[same as prior period, unchanged from 0001628280-23-016653:notes:14]

[0001628280-23-037591:notes:16]
The condensed consolidated financial statements include the accounts of Lumentum Holdings Inc. and its wholly owned subsidiaries. All inter-company transactions and balances are eliminated in consolidation.

[0001628280-23-037591:notes:17]
Accounting Policies
The condensed consolidated financial statements and accompanying notes should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the fiscal year ended July 1, 2023. There were no significant changes to our accounting policies during the three months ended September 30, 2023.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001628280-23-037591:notes:18]
Note 2. Recently Issued Accounting Pronouncements

[0001628280-23-037591:notes:19]
Accounting Pronouncements Recently Adopted

[0001628280-23-037591:notes:20]
In October 2021, the Financial Accounting Standards Board (“FASB”) issued ASU 2021-08, Business Combinations (Topic 805)—Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. This ASU clarifies that an acquirer of a business should recognize and measure contract assets and contract liabilities in a business combination in accordance with ASC Topic 606, Revenue from Contracts with Customers. This ASU is expected to improve comparability for both recognition and measurement of acquired revenue contracts with customers at the date of and after a business combination. The new guidance is effective for fiscal years beginning after December 15, 2022, with early adoption permitted. We early adopted the new standard in the first quarter of fiscal 2023 in connection with the merger with NeoPhotonics. There was no material impact to our condensed consolidated financial statements as of and for the three months ended September 30, 2023 and October 1, 2022.

[0001628280-23-037591:notes:21]
In August 2020, the FASB issued ASU 2020-06, Debt—Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging—Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity, which simplifies the accounting for convertible instruments by removing the separation models for (i) convertible debt with a cash conversion feature and (ii) convertible instruments with a beneficial conversion feature. As a result, a convertible debt instrument is accounted for as a single liability measured at its amortized cost. ASU 2020-06 also requires the application of the if-converted method for calculating diluted earnings per share. We adopted the standard as of July 3, 2022, using the modified retrospective approach. Upon adoption, our 2026 Notes and 2028 Notes (as defined below) were accounted for as a single liability measured at amortized cost, resulting in: (i) an increase to the convertible notes liability balance of $433.0 million to reflect the full principal amount of the convertible notes outstanding, net of issuance costs; (ii) a reduction to additional paid-in capital, net of estimated income tax effects, of $426.5 million, to remove the equity component separately recorded for the conversion features associated with the convertible notes; (iii) an increase to deferred tax assets, net of $92.1 million; and (iv) a cumulative-effect adjustment of $85.6 million, net of estimated income tax effects, to decrease the accumulated deficit. In addition, the adoption requires the use of the if-converted method for all convertible notes in the diluted net income per share calculation and the inclusion of the effect of potential share settlement of the convertible notes, if the effect is more dilutive. There was no impact to diluted earnings per share for the three months ended September 30, 2023 and October 1, 2022, as the inclusion of potential shares of common stock related to the convertible notes was anti-dilutive. Refer to “Note 9. Debt” for further information.

[0001628280-23-037591:notes:22]
The following table sets forth the impact upon adoption of ASU 2020-06 as of July 3, 2022 (in millions):

[0001628280-23-037591:notes:23]
|  |  | Short Term Debt - 2024 Notes |  | Long Term Debt - 2026 Notes |  | Long Term Debt - 2028 Notes |  | Additional Paid-In Capital |  | Accumulated Deficit |  | Deferred Tax Asset, Net |
| Balances pre-adoption of ASC 2020-06 |  | $ | 409.9 |  |  | $ | 831.4 |  |  | $ | 634.7 |  |  | $ | 2,003.6 |  |  | $ | 129.1 |  |  | $ | 12.9 |  |
| Reclassify amounts from equity to debt |  | — |  |  | 312.9 |  |  | 229.3 |  |  | (542.2) |  |  | — |  |  | — |  |
| Adjustment for interest accretion |  | — |  |  | (99.5) |  |  | (9.7) |  |  | — |  |  | (109.2) |  |  | — |  |
| Tax effect |  | — |  |  | — |  |  | — |  |  | 115.7 |  |  | 23.6 |  |  | 92.1 |  |
| Balances upon adoption of ASC 2020-06 |  | $ | 409.9 |  |  | $ | 1,044.8 |  |  | $ | 854.3 |  |  | $ | 1,577.1 |  |  | $ | 43.5 |  |  | $ | 105.0 |  |


## us-gaap:EarningsPerShareTextBlock

[0001628280-23-037591:notes:24]
[same as prior period, unchanged from 0001628280-23-016653:notes:24]

[0001628280-23-037591:notes:25]
The following table sets forth the computation of basic and diluted net loss per share (in millions, except per share data):

[0001628280-23-037591:notes:26]
|  | Three Months Ended |  |  |
|  | September 30, 2023 |  | October 1, 2022 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net loss - basic and diluted | $ | (67.9) |  |  | $ | (0.4) |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average common shares outstanding - basic and diluted | 66.7 |  |  | 68.1 |  |  |  |  |  |
| Net loss per share: |  |  |  |  |  |  |  |
| Basic | $ | (1.02) |  |  | $ | (0.01) |  |  |  |  |  |
| Diluted | $ | (1.02) |  |  | $ | (0.01) |  |  |  |  |  |

[0001628280-23-037591:notes:27]
Shares from stock-based benefit plans and shares issuable assuming conversion of our convertible notes are anti-dilutive for the three months ended September 30, 2023 and October 1, 2022, respectively, and are therefore excluded from the calculation of diluted net loss per share as the Company had a net loss for both periods.

[0001628280-23-037591:notes:28]
Anti-dilutive shares excluded from the calculation of diluted net loss per share for the three months ended September 30, 2023 include 31.2 million shares related to the convertible notes, 4.6 million shares issuable under restricted stock units (“RSUs”) and performance stock units (“PSUs”), and 0.2 million shares issuable under the Employee Stock Purchase Plan (the “2015 Purchase Plan”).  Anti-dilutive shares excluded from the calculation of diluted net loss per share for the three months ended October 1, 2022 include 24.5 million shares related to the convertible notes, 4.1 million shares issuable under RSUs and PSUs, and 0.1 million shares issuable under the 2015 Purchase Plan. Refer to “Note 13. Equity”.
Potentially dilutive common shares issuable upon conversion of our outstanding convertible notes are determined using the if-converted method.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001628280-23-037591:notes:29]
[same as prior period, unchanged from 0001628280-23-016653:notes:31]

[0001628280-23-037591:notes:30]
[same as prior period, unchanged from 0001628280-23-016653:notes:32]

[0001628280-23-037591:notes:31]
On November 3, 2021, we entered into an Agreement and Plan of Merger (the “Merger Agreement”) with NeoPhotonics and Neptune Merger Sub, Inc. On August 3, 2022 (the “Closing date”), we completed the acquisition of NeoPhotonics through the consummation of the merger and, accordingly, we acquired all of the issued and outstanding common stock of NeoPhotonics. The addition of NeoPhotonics expands our opportunity in some of the fastest growing markets for optical components used in cloud and telecom network infrastructure.

[0001628280-23-037591:notes:32]
We have applied the acquisition method of accounting in accordance with ASC Topic 805, Business Combinations, with respect to the fair value of purchase price consideration and the identifiable assets and liabilities of NeoPhotonics, which have been measured at estimated fair value as of the Closing date. The following table summarizes our final allocation of the purchase price consideration to the assets acquired and liabilities assumed as of the Closing date (in millions):

[0001628280-23-037591:notes:33]
|  | Fair Value |
| Total purchase price consideration | $ | 934.4 |  |
| Assets acquired |  |
| Cash and cash equivalents | $ | 92.9 |  |
| Accounts receivable, net | 66.8 |  |
| Inventories | 84.3 |  |
| Prepayments and other current assets | 24.2 |  |
| Property, plant and equipment, net | 106.1 |  |
| Operating lease right-of-use assets, net | 16.9 |  |
| Other intangible assets, net (1) | 412.5 |  |
| Deferred tax asset | 5.4 |  |
| Other non-current assets | 1.9 |  |
| Total assets | 811.0 |  |
| Liabilities assumed |  |
| Accounts payable | 79.6 |  |
| Accrued payroll and related expenses | 11.1 |  |
| Accrued expenses | 3.8 |  |
| Other current liabilities | 10.6 |  |
| Operating lease liabilities, current | 2.8 |  |
| Operating lease liabilities, non-current | 13.2 |  |
| Deferred tax liability | 38.3 |  |
| Other non-current liabilities | 32.5 |  |
| Total liabilities | 191.9 |  |
| Goodwill | $ | 315.3 |  |

[0001628280-23-037591:notes:34]
(1) Other intangible assets include customer relationship of $144.5 million, developed technology of $220.0 million, and in-process research and development (“IPR&D”) of $48.0 million. Refer to “Note 8. Goodwill and Other Intangible Assets”.

[0001628280-23-037591:notes:35]
Goodwill of $315.3 million arising from the acquisition is attributed to the expected synergies, including future cost efficiencies and other benefits that are expected to be generated by combining Lumentum and NeoPhotonics. None of the goodwill is expected to be deductible for local tax purposes. At the date of acquisition, the entire goodwill related to the acquisition was assigned to the OpComms segment. As a result of the change of our reportable segments in the fiscal first quarter of 2024, it has been reassigned to the Cloud & Networking segment. Refer to “Note 15. Operating Segments and Geographic Information”.

[0001628280-23-037591:notes:36]
NeoPhotonics contributed $72.8 million of our consolidated net revenue for the three months ended October 1, 2022. Due to our corporate structure and the allocation of selling, general and administrative costs, it was impracticable to determine NeoPhotonics’ contribution to our earnings for the three months ended October 1, 2022. As of September 30, 2023, the operation of NeoPhotonics has been fully integrated to the combined business.

[0001628280-23-037591:notes:37]
The total transaction consideration of $934.4 million was funded by the cash balances of the combined company. We also recorded $28.7 million of merger-related costs, representing professional and other direct acquisition costs. Of the $28.7 million of merger-related costs, $8.3 million was incurred in fiscal year 2022 and $20.4 million was incurred in fiscal year 2023, which was recorded as selling, general and administrative expense in the condensed consolidated statements of operations.

[0001628280-23-037591:notes:38]
[same as prior period, unchanged from 0001628280-23-016653:notes:46]

[0001628280-23-037591:notes:39]
Pro forma net revenue and net income was $530.7 million and $32.4 million, respectively, for the three months ended October 1, 2022, as if the merger was completed at the beginning of fiscal 2022. The pro forma financial information includes adjustments for: (i) additional amortization expense that would have been recognized related to the acquired intangible assets, (ii) additional depreciation expense that would have been recognized related to the acquired property, plant, and equipment, (iii) additional cost of sales related to the inventory valuation adjustment, (iv) acquisition related costs, such as third party transaction costs and restructuring costs, (v) stock-based compensation expense and (vi) the estimated income tax effect on the pro forma adjustments. The pro forma financial information is not necessarily indicative of the financial position or results of operations that would have been realized if the acquisition had been completed on the date indicated, nor does it reflect synergies that might have been achieved, nor is it indicative of future operating results or financial position.

[0001628280-23-037591:notes:40]
[same as prior period, unchanged from 0001628280-23-016653:notes:51]

[0001628280-23-037591:notes:41]
On August 15, 2022 (“IPG Closing date”), we completed a transaction to acquire IPG Photonics’ telecom transmission product lines (“IPG telecom transmission product lines”) that are used to develop and market products for use in telecommunications and datacenter infrastructure, including Digital Signal Processors (DSPs), ASICs and optical transceivers. This acquisition enables us to expand our business in the Cloud & Networking segment (previously to the OpComms segment prior to the change of our reportable segments in the fiscal first quarter of 2024). Refer to “Note 15. Operating Segments and Geographic Information”.

[0001628280-23-037591:notes:42]
We have applied the acquisition method of accounting in accordance with ASC Topic 805, Business Combinations to account for this transaction. The total purchase price of $55.9 million was paid in cash. We have completed the purchase price allocation. Our final allocation of the purchase price consideration includes $29.1 million of in process research and development (“IPR&D”), $8.6 million of developed technology, $2.3 million of customer relationships, and $5.0 million of other net assets and liabilities, resulting in goodwill of $10.9 million, which was assigned to the Cloud & Networking segment.

[0001628280-23-037591:notes:43]
We recorded $2.0 million of merger-related costs, representing professional and other direct acquisition costs. Of the $2.0 million of merger-related costs, $0.4 million was incurred in fiscal year 2022 and $1.6 million was incurred in fiscal year 2023, which was recorded as selling, general and administrative expense in the consolidated statements of operations.

[0001628280-23-037591:notes:44]
The pro forma financial information from the acquisition of the IPG telecom transmission product lines, assuming the acquisition had occurred as of the first day of fiscal 2022, as well as revenue and earnings generated during fiscal 2023, were not material for disclosure purposes.


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001628280-23-037591:notes:45]
[same as prior period, unchanged from 0001628280-23-016653:notes:56]

[0001628280-23-037591:notes:46]
[same as prior period, unchanged from 0001628280-23-016653:notes:57]

[0001628280-23-037591:notes:47]
|  | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| September 30, 2023: |  |  |  |  |  |  |  |
| Cash | $ | 156.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 156.3 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 4.8 |  |  | — |  |  | — |  |  | 4.8 |  |
| Money market funds | 285.3 |  |  | — |  |  | — |  |  | 285.3 |  |
| U.S. Treasury securities | 415.1 |  |  | 0.1 |  |  | — |  |  | 415.2 |  |
| Total cash and cash equivalents | $ | 861.5 |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 861.6 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 29.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 29.6 |  |
| Commercial paper | 119.2 |  |  | — |  |  | (0.1) |  |  | 119.1 |  |
| Corporate debt securities | 459.4 |  |  | — |  |  | (3.2) |  |  | 456.2 |  |
| Municipal bonds | 4.6 |  |  | — |  |  | — |  |  | 4.6 |  |
| U.S. Agency securities | 194.7 |  |  | — |  |  | (1.4) |  |  | 193.3 |  |
| U.S. Treasury securities | 281.4 |  |  | — |  |  | (1.5) |  |  | 279.9 |  |
| Total short-term investments | $ | 1,088.9 |  |  | $ | — |  |  | $ | (6.2) |  |  | $ | 1,082.7 |  |
| July 1, 2023: |  |  |  |  |  |  |  |
| Cash | $ | 254.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 254.3 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | 276.1 |  |  | — |  |  | — |  |  | 276.1 |  |
| U.S. Agency securities | 4.0 |  |  | — |  |  | — |  |  | 4.0 |  |
| U.S. Treasury securities | 324.6 |  |  | — |  |  | — |  |  | 324.6 |  |
| Total cash and cash equivalents | $ | 859.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 859.0 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 16.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 16.5 |  |
| Commercial paper | 132.9 |  |  | — |  |  | (0.2) |  |  | 132.7 |  |
| Corporate debt securities | 472.7 |  |  | — |  |  | (3.9) |  |  | 468.8 |  |
| U.S. Agency securities | 207.9 |  |  | — |  |  | (1.7) |  |  | 206.2 |  |
| U.S. Treasury securities | 332.4 |  |  | — |  |  | (2.0) |  |  | 330.4 |  |
| Total short-term investments | $ | 1,162.4 |  |  | $ | — |  |  | $ | (7.8) |  |  | $ | 1,154.6 |  |

[0001628280-23-037591:notes:48]
We review our investment portfolio to identify and evaluate investments that have indicators of possible impairment. Factors considered in determining whether a loss is other-than-temporary include, but are not limited to, the length of time and extent a security’s fair value has been below its cost, the financial condition and near-term prospects of the investee, the credit quality of the security’s issuer, likelihood of recovery and our intent and ability to hold the security for a period sufficient to allow for any anticipated recovery in value. For the debt instruments we own, we also evaluate whether we have the intent to sell the security or whether it is more likely than not that we will be required to sell the security before recovery of its cost basis. We have not recorded our unrealized losses on our short-term investments into income because we do not intend to sell nor is it more likely than not that we will be required to sell these investments prior to recovery of their amortized cost basis.

[0001628280-23-037591:notes:49]
We use the specific-identification method to determine any realized gains or losses from the sale of our short-term investments classified as available-for-sale. During the three months ended September 30, 2023 and October 1, 2022, we did not realize significant gains or losses on a gross level from the sale of our short-term investments classified as available-for-sale.

[0001628280-23-037591:notes:50]
During the three months ended September 30, 2023 and October 1, 2022, our other income, net was $21.2 million and $13.8 million, respectively, which includes interest and investment income on cash equivalents and short-term investments of $21.7 million and $4.8 million, respectively.

[0001628280-23-037591:notes:51]
As of September 30, 2023 and July 1, 2023, we recorded interest receivables of $8.0 million and $6.7 million, respectively, in prepayments and other current assets within the condensed consolidated balance sheets. We did not recognize an allowance for credit losses against interest receivables in any of the periods presented, as there were no such losses.

[0001628280-23-037591:notes:52]
[same as prior period, unchanged from 0001628280-23-016653:notes:63]

[0001628280-23-037591:notes:53]
|  | Continuous Loss Position for More Than 12 Months |  | Continuous Loss Position for Less Than 12 Months |  | Gross Unrealized Losses |  |  |  |  |  |  |  |  |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |  |
| September 30, 2023: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 159.5 |  |  | $ | (1.2) |  |  | $ | 33.8 |  |  | $ | (0.2) |  |  | $ | (1.4) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | 11.7 |  |  | — |  |  | — |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 89.9 |  |  | (0.1) |  |  | — |  |  | — |  |  | (0.1) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 351.3 |  |  | (2.7) |  |  | 68.7 |  |  | (0.5) |  |  | (3.2) |  |  |  |  |  |  |  |  |  |
| Foreign government bonds | 4.6 |  |  | — |  |  | — |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 215.4 |  |  | (1.3) |  |  | 22.9 |  |  | (0.2) |  |  | (1.5) |  |  |  |  |  |  |  |  |  |
| Total | $ | 832.4 |  |  | $ | (5.3) |  |  | $ | 125.4 |  |  | $ | (0.9) |  |  | $ | (6.2) |  |  |  |  |  |  |  |  |  |
| July 1, 2023: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 39.6 |  |  | $ | (0.4) |  |  | $ | 170.6 |  |  | $ | (1.3) |  |  | $ | (1.7) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | — |  |  | $ | 7.7 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | $ | 128.5 |  |  | (0.2) |  |  | (0.2) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 93.6 |  |  | (1.2) |  |  | $ | 358.9 |  |  | (2.7) |  |  | (3.9) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 50.8 |  |  | (0.6) |  |  | $ | 221.4 |  |  | (1.4) |  |  | (2.0) |  |  |  |  |  |  |  |  |  |
| Total | $ | 184.0 |  |  | $ | (2.2) |  |  | $ | 887.1 |  |  | $ | (5.6) |  |  | $ | (7.8) |  |  |  |  |  |  |  |  |  |

[0001628280-23-037591:notes:54]
[same as prior period, unchanged from 0001628280-23-016653:notes:65]

[0001628280-23-037591:notes:55]
|  | September 30, 2023 |  | July 1, 2023 |
|  | Amortized Cost |  | Fair Value |  | Amortized Cost |  | Fair Value |
| Due in 1 year | $ | 735.8 |  |  | $ | 733.3 |  |  | $ | 762.9 |  |  | $ | 759.1 |  |
| Due in 1 year through 5 years | 353.1 |  |  | 349.4 |  |  | 399.5 |  |  | 395.5 |  |
|  | $ | 1,088.9 |  |  | $ | 1,082.7 |  |  | $ | 1,162.4 |  |  | $ | 1,154.6 |  |

[0001628280-23-037591:notes:56]
[same as prior period, unchanged from 0001628280-23-016653:notes:67]


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-23-037591:notes:57]
[same as prior period, unchanged from 0001628280-23-016653:notes:68]

[0001628280-23-037591:notes:58]
[same as prior period, unchanged from 0001628280-23-016653:notes:69]

[0001628280-23-037591:notes:59]
[same as prior period, unchanged from 0001628280-23-016653:notes:70]

[0001628280-23-037591:notes:60]
[same as prior period, unchanged from 0001628280-23-016653:notes:71]

[0001628280-23-037591:notes:61]
[same as prior period, unchanged from 0001628280-23-016653:notes:72]

[0001628280-23-037591:notes:62]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| September 30, 2023: (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | — |  |  | $ | 4.8 |  |  | $ | — |  |  | $ | 4.8 |  |
| Money market funds | 285.3 |  |  | — |  |  | — |  |  | 285.3 |  |
| U.S. Treasury securities | 415.2 |  |  | — |  |  | — |  |  | 415.2 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 29.6 |  |  | — |  |  | 29.6 |  |
| Commercial paper | — |  |  | 119.1 |  |  | — |  |  | 119.1 |  |
| Corporate debt securities | — |  |  | 456.2 |  |  | — |  |  | 456.2 |  |
| Municipal bonds | — |  |  | 4.6 |  |  | — |  |  | 4.6 |  |
| U.S. Agency securities | — |  |  | 193.3 |  |  | — |  |  | 193.3 |  |
| U.S. Treasury securities | 279.9 |  |  | — |  |  | — |  |  | 279.9 |  |
| Total assets | $ | 980.4 |  |  | $ | 807.6 |  |  | $ | — |  |  | $ | 1,788.0 |  |

[0001628280-23-037591:notes:63]
(1)  Excludes $156.3 million in cash held in our bank accounts as of September 30, 2023.

[0001628280-23-037591:notes:64]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| July 1, 2023: (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 276.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 276.1 |  |
| U.S. Agency securities | — |  |  | 4.0 |  |  | — |  |  | 4.0 |  |
| U.S. Treasury securities | 324.6 |  |  | — |  |  | — |  |  | 324.6 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 16.5 |  |  | — |  |  | 16.5 |  |
| Commercial paper | — |  |  | 132.7 |  |  | — |  |  | 132.7 |  |
| Corporate debt securities | — |  |  | 468.8 |  |  | — |  |  | 468.8 |  |
| U.S. Agency securities | — |  |  | 206.2 |  |  | — |  |  | 206.2 |  |
| U.S. Treasury securities | 330.4 |  |  | — |  |  | — |  |  | 330.4 |  |
| Total assets | $ | 931.1 |  |  | $ | 828.2 |  |  | $ | — |  |  | $ | 1,759.3 |  |

[0001628280-23-037591:notes:65]
(1)  Excludes $254.3 million in cash held in our bank accounts as of July 1, 2023.

[0001628280-23-037591:notes:66]
[same as prior period, unchanged from 0001628280-23-016653:notes:77]

[0001628280-23-037591:notes:67]
We report our financial instruments at fair value with the exception of our convertible notes, refer to “Note 9. Debt”. The estimated fair value of the convertible notes was determined based on the trading price of the convertible notes as of the last day of trading for the period. We consider the fair value of the convertible notes to be a Level 2 measurement as they are not actively traded in markets.

[0001628280-23-037591:notes:68]
The carrying amounts and estimated fair values of the convertible notes are as follows for the periods presented (in millions):

[0001628280-23-037591:notes:69]
|  | September 30, 2023 |  | July 1, 2023 |
|  | Carrying Amount |  | Estimated Fair Value |  | Carrying Amount |  | Estimated Fair Value |
| 2029 Notes | $ | 598.8 |  |  | $ | 553.2 |  |  | $ | 598.6 |  |  | $ | 625.2 |  |
| 2028 Notes | 855.9 |  |  | 630.8 |  |  | 855.5 |  |  | 677.8 |  |
| 2026 Notes | 1,046.2 |  |  | 885.1 |  |  | 1,045.9 |  |  | 933.2 |  |
| 2024 Notes | 315.7 |  |  | 319.1 |  |  | 311.6 |  |  | 345.2 |  |
|  | $ | 2,816.6 |  |  | $ | 2,388.2 |  |  | $ | 2,811.6 |  |  | $ | 2,581.4 |  |

[0001628280-23-037591:notes:70]
[same as prior period, unchanged from 0001628280-23-016653:notes:81]

[0001628280-23-037591:notes:71]
[same as prior period, unchanged from 0001628280-23-016653:notes:82]

[0001628280-23-037591:notes:72]
Management utilizes various valuation methods, including an income approach, a market approach and a cost approach, to estimate the fair value of intangibles and other long-lived assets. During the annual impairment testing performed in the fourth quarter of fiscal 2023, we concluded that our intangible and other long-lived assets were not impaired. We review our intangible and other long-lived assets for impairment at least annually in the fourth quarter of each fiscal year, absent any interim indicators of impairment. There were no indicators of impairment during the three months ended September 30, 2023.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-23-037591:notes:73]
[same as prior period, unchanged from 0001628280-23-016653:notes:84]

[0001628280-23-037591:notes:74]
[same as prior period, unchanged from 0001628280-23-016653:notes:85]

[0001628280-23-037591:notes:75]
We did not have any allowance for credit losses other than our allowance for uncollectible accounts receivable. As of September 30, 2023 and July 1, 2023, the allowance for credit losses on our trade receivables was $0.3 million and less than $0.1 million, respectively.

[0001628280-23-037591:notes:76]
[same as prior period, unchanged from 0001628280-23-016653:notes:87]

[0001628280-23-037591:notes:77]
[same as prior period, unchanged from 0001628280-23-016653:notes:88]

[0001628280-23-037591:notes:78]
|  | September 30, 2023 |  | July 1, 2023 |
| Raw materials and purchased parts | $ | 173.3 |  |  | $ | 170.5 |  |
| Work in process | 113.4 |  |  | 103.2 |  |
| Finished goods | 141.3 |  |  | 134.9 |  |
| Inventories | $ | 428.0 |  |  | $ | 408.6 |  |

[0001628280-23-037591:notes:79]
[same as prior period, unchanged from 0001628280-23-016653:notes:95]

[0001628280-23-037591:notes:80]
[same as prior period, unchanged from 0001628280-23-016653:notes:96]

[0001628280-23-037591:notes:81]
|  | September 30, 2023 |  | July 1, 2023 |
| Land | $ | 75.2 |  |  | $ | 63.5 |  |
| Buildings and improvements | 188.1 |  |  | 170.3 |  |
| Machinery and equipment | 665.8 |  |  | 657.9 |  |
| Computer equipment and software | 42.6 |  |  | 41.4 |  |
| Furniture and fixtures | 11.0 |  |  | 10.2 |  |
| Leasehold improvements | 41.8 |  |  | 49.6 |  |
| Construction in progress | 79.8 |  |  | 69.2 |  |
|  | 1,104.3 |  |  | 1,062.1 |  |
| Less: Accumulated depreciation | (592.7) |  |  | (572.6) |  |
| Property, plant and equipment, net | $ | 511.6 |  |  | $ | 489.5 |  |

[0001628280-23-037591:notes:82]
[same as prior period, unchanged from 0001628280-23-016653:notes:99]

[0001628280-23-037591:notes:83]
In August 2023, we purchased land and buildings that we previously leased in Caswell, United Kingdom for a total purchase price of $23.3 million. Additionally, we capitalized $1.8 million of incremental direct costs for fees paid to third parties. We also recorded a $0.3 million reduction in the carrying value of buildings purchased related to the termination of leases for the purchased buildings. The total carrying value of assets purchased is $24.8 million at the purchase date, of which $11.8 million was allocated to the land and $13.0 million to the buildings.

[0001628280-23-037591:notes:84]
During the three months ended September 30, 2023 and October 1, 2022, we recorded depreciation expense of $28.2 million and $24.5 million, respectively.

[0001628280-23-037591:notes:85]
[same as prior period, unchanged from 0001628280-23-016653:notes:91]

[0001628280-23-037591:notes:86]
[same as prior period, unchanged from 0001628280-23-016653:notes:92]

[0001628280-23-037591:notes:87]
|  | September 30, 2023 |  | July 1, 2023 |
| Operating lease right-of-use assets | $ | 104.1 |  |  | $ | 116.5 |  |
| Less: accumulated amortization | (35.3) |  |  | (39.2) |  |
| Operating lease right-of-use assets, net | $ | 68.8 |  |  | $ | 77.3 |  |

[0001628280-23-037591:notes:88]
In connection with the purchase of land and buildings in Caswell, UK in August 2023, we terminated our leases for the purchased buildings and recorded a $0.3 million of reduction in the carrying value of buildings purchased, as a result of derecognizing $4.8 million of net operating lease right-of-use asset, $2.4 million of operating lease liabilities, current, and $2.7 million of operating lease liabilities, non-current.

[0001628280-23-037591:notes:89]
[same as prior period, unchanged from 0001628280-23-016653:notes:101]

[0001628280-23-037591:notes:90]
[same as prior period, unchanged from 0001628280-23-016653:notes:102]

[0001628280-23-037591:notes:91]
|  | September 30, 2023 |  | July 1, 2023 |
| Restructuring accrual and related charges (1) | $ | 9.3 |  |  | $ | 5.0 |  |
| Warranty accrual (2) | 5.5 |  |  | 6.8 |  |
| Deferred revenue and customer deposits | 1.6 |  |  | 2.1 |  |
| Income tax payable (3) | 10.7 |  |  | 28.0 |  |
| Other current liabilities | 4.2 |  |  | 5.9 |  |
| Other current liabilities | $ | 31.3 |  |  | $ | 47.8 |  |

[0001628280-23-037591:notes:92]
[same as prior period, unchanged from 0001628280-23-016653:notes:104]

[0001628280-23-037591:notes:93]
(2) Refer to “Note 14. Commitments and Contingencies.”

[0001628280-23-037591:notes:94]
(3) Refer to “Note 12. Income Taxes.”

[0001628280-23-037591:notes:95]
[same as prior period, unchanged from 0001628280-23-016653:notes:106]

[0001628280-23-037591:notes:96]
[same as prior period, unchanged from 0001628280-23-016653:notes:107]

[0001628280-23-037591:notes:97]
|  | September 30, 2023 |  | July 1, 2023 |
| Asset retirement obligations | $ | 7.5 |  |  | $ | 8.2 |  |
| Pension and related accruals (1) | 10.1 |  |  | 9.6 |  |
| Unrecognized tax benefit | 59.5 |  |  | 64.4 |  |
| Other non-current liabilities | 8.6 |  |  | 9.2 |  |
| Other non-current liabilities | $ | 85.7 |  |  | $ | 91.4 |  |

[0001628280-23-037591:notes:98]
(1) We have defined benefit pension plans in Japan, Switzerland, and Thailand. Pension and related accrual of $10.1 million as of September 30, 2023 relates to $10.2 million of non-current portion of benefit obligation, offset by $0.1 million of funding for the pension plan in Switzerland. Pension and related accrual of $9.6 million as of July 1, 2023 relates to $10.2 million of non-current portion of benefit obligation, offset by $0.6 million of funding for the pension plan in Switzerland. We typically re-evaluate the assumptions related to the fair value of our defined benefit obligations annually in the fiscal fourth quarter and make any updates as necessary.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001628280-23-037591:notes:99]
[same as prior period, unchanged from 0001628280-23-016653:notes:110]

[0001628280-23-037591:notes:100]
[same as prior period, unchanged from 0001628280-23-016653:notes:111]

[0001628280-23-037591:notes:101]
In August 2022, we completed two acquisitions, our merger with NeoPhotonics and the acquisition of IPG telecom transmission product lines. We recognized goodwill of $315.3 million related to the NeoPhotonics merger and $10.9 million related to the acquisition of the IPG telecom transmission product lines as of  September 30, 2023 and July 1, 2023. At the date of these acquisitions, the entire goodwill related to these acquisitions was assigned to the OpComms segment. As a result of the change of our reportable segments in the fiscal first quarter of 2024, it has been reassigned to the Cloud & Networking segment. Refer to “Note 15. Operating Segments and Geographic Information”.

[0001628280-23-037591:notes:102]
The following table presents our goodwill by reportable segments as of September 30, 2023 and July 1, 2023 (in millions):

[0001628280-23-037591:notes:103]
|  | Cloud & Networking |  | Industrial Tech |  | Total |
| Balances as of September 30, 2023 and July 1, 2023 | $ | 683.9 |  |  | $ | 11.2 |  |  | $ | 695.1 |  |

[0001628280-23-037591:notes:104]
[same as prior period, unchanged from 0001628280-23-016653:notes:117]

[0001628280-23-037591:notes:105]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. In the fourth quarter of fiscal 2023, we completed the annual impairment test of goodwill, which indicated there was no goodwill impairment. There were no indicators of goodwill impairment during the three months ended September 30, 2023.

[0001628280-23-037591:notes:106]
[same as prior period, unchanged from 0001628280-23-016653:notes:119]

[0001628280-23-037591:notes:107]
The intangible assets are amortized on a straight-line basis over the estimated useful lives, except for certain customer relationships, which are amortized using an accelerated method of amortization over the expected customer lives, more accurately reflecting the pattern of realization of economic benefits we expect to derive. Acquired developed technologies are amortized to cost of sales and acquired customer relationships are amortized to selling, general and administrative expenses in the consolidated statement of operations.

[0001628280-23-037591:notes:108]
[same as prior period, unchanged from 0001628280-23-016653:notes:121]

[0001628280-23-037591:notes:109]
During the annual impairment testing performed in the fourth quarter of fiscal 2023, we concluded that our intangible and other long-lived assets were not impaired at the asset group level. We review our intangible and other long-lived assets for impairment at least annually in the fourth quarter of each fiscal year, absent any interim indicators of impairment. There were no indicators of impairment at the asset group level during the three months ended September 30, 2023.

[0001628280-23-037591:notes:110]
In connection with the merger with NeoPhotonics and the acquisition of the IPG telecom transmission product lines, we recorded $452.5 million of intangible assets. Refer to “Note 4. Business Combinations”. The intangible assets acquired from the acquisitions were as follows as of the acquisition date (in millions, except for weighted average amortization period):

[0001628280-23-037591:notes:111]
|  | Fair Value At The Acquisition Date |  | Weighted Average Amortization Period(Years) |
|  | NeoPhotonics |  | IPG Telecom Transmission Product Lines |  | Total Acquired |  |
| Acquired developed technologies | $ | 220.0 |  |  | $ | 8.6 |  |  | $ | 228.6 |  |  | 5.2 |
| Customer relationships | 144.5 |  |  | 2.3 |  |  | 146.8 |  |  | 5.9 |
| In-process research and development | 48.0 |  |  | 29.1 |  |  | 77.1 |  |  | n/a |
| Total intangible assets | $ | 412.5 |  |  | $ | 40.0 |  |  | $ | 452.5 |  |  |  |

[0001628280-23-037591:notes:112]
The following tables present details of all of our intangibles as of the periods presented (in millions, except for weighted average remaining amortization period):

[0001628280-23-037591:notes:113]
| September 30, 2023 | Gross Carrying Amounts |  | Accumulated Amortization |  | Net Carrying Amounts |  | Weighted Average Remaining Amortization Period (Years) |
| Acquired developed technologies | $ | 636.4 |  |  | $ | (404.4) |  |  | $ | 232.0 |  |  | 4.0 |
| Customer relationships | 289.7 |  |  | (126.9) |  |  | 162.8 |  |  | 3.5 |
| In-process research and development | 40.4 |  |  | — |  |  | 40.4 |  |  | n/a |
| Total intangible assets | $ | 966.5 |  |  | $ | (531.3) |  |  | $ | 435.2 |  |  |  |

[0001628280-23-037591:notes:114]
| July 1, 2023 | Gross Carrying Amounts |  | Accumulated Amortization |  | Net Carrying Amounts |  | Weighted Average Remaining Amortization Period (Years) |
| Acquired developed technologies | $ | 630.9 |  |  | $ | (385.5) |  |  | $ | 245.4 |  |  | 4.2 |
| Customer relationships | 289.7 |  |  | (116.8) |  |  | 172.9 |  |  | 3.7 |
| In-process research and development | 40.9 |  |  | — |  |  | 40.9 |  |  | n/a |
| Total intangible assets | $ | 961.5 |  |  | $ | (502.3) |  |  | $ | 459.2 |  |  |  |

[0001628280-23-037591:notes:115]
[same as prior period, unchanged from 0001628280-23-016653:notes:130]

[0001628280-23-037591:notes:116]
|  | Three Months Ended |  |  |
|  | September 30, 2023 |  | October 1, 2022 |  |  |  |  |
| Cost of sales | $ | 18.0 |  |  | $ | 22.9 |  |  |  |  |  |
| Research and development | 0.3 |  |  | — |  |  |  |  |  |
| Selling, general and administrative | 10.7 |  |  | 9.3 |  |  |  |  |  |
| Total amortization of intangibles | $ | 29.0 |  |  | $ | 32.2 |  |  |  |  |  |

[0001628280-23-037591:notes:117]
Based on the carrying amount of our acquired developed technologies and customer relationships as of September 30, 2023, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001628280-23-037591:notes:118]
| Fiscal Years |  |
| Remainder of 2024 | $ | 83.4 |  |
| 2025 | 98.6 |  |
| 2026 | 89.0 |  |
| 2027 | 76.2 |  |
| 2028 | 38.1 |  |
| Thereafter | 9.5 |  |
| Total future amortization | $ | 394.8 |  |


## us-gaap:DebtDisclosureTextBlock

[0001628280-23-037591:notes:119]
Note 9. Debt

[0001628280-23-037591:notes:120]
Convertible Notes

[0001628280-23-037591:notes:121]
2029 Notes

[0001628280-23-037591:notes:122]
On June 16, 2023, we issued $603.7 million in aggregate principal amount of 1.50% convertible notes due in 2029 (“2029 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended. The 2029 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association, (as successor in interest to U.S. Bank National Association), as a trustee (the “2029 Indenture”). The 2029 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-23-037591:notes:123]
The net proceeds from the sale of the 2029 Notes was $599.4 million, after deducting $4.3 million of net issuance costs. In addition, we incurred $0.8 million of professional fees directly related to this transaction. Concurrent with the issuance of the 2029 Notes, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 2024 Notes and $125.0 million of the net proceeds to repurchase our common stock in privately negotiated transactions. We intend to use the remaining net proceeds for general corporate purposes, which may include the repayment of our indebtedness, including any of our existing convertible notes, capital expenditures, working capital and potential acquisitions.

[0001628280-23-037591:notes:124]
The 2029 Notes bear interest at a rate of 1.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on December 15, 2023. The 2029 Notes will mature on December 15, 2029, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-23-037591:notes:125]
The initial conversion rate is 14.3808 shares of common stock per $1,000 principal amount of the 2029 Notes (which is equivalent to an initial conversion price of approximately $69.54 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2029 Indenture but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2029 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-23-037591:notes:126]
Prior to the close of business on the business day immediately preceding September 15, 2029, holders of the 2029 Notes may convert their 2029 Notes only under the following circumstances:

[0001628280-23-037591:notes:127]
•during any fiscal quarter commencing after September 30, 2023 (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% if the applicable conversion price on each applicable trading day;

[0001628280-23-037591:notes:128]
•during the five consecutive business day period after any five consecutive trading day period (the “2029 measurement period”) in which the trading price per $1,000 principal amount of 2029 Notes for each trading day of the 2029 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day;

[0001628280-23-037591:notes:129]
•if we call any or all of the 2029 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the redemption date; or

[0001628280-23-037591:notes:130]
•upon the occurrence of specified corporate events as specified in the 2029 Indenture.

[0001628280-23-037591:notes:131]
On or after September 15, 2029 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2029 Notes at any time. Upon conversion, we will satisfy our conversion obligation in cash, shares of common stock or a combination of cash and shares of common stock, at our election.

[0001628280-23-037591:notes:132]
We may redeem for cash all or any portion of the 2029 Notes, at our option (subject to the partial redemption limitation set forth in the 2029 Indenture), on or after June 22, 2026, if the last reported sale price of our  common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide notice of redemption at a redemption price equal to 100% of the principal amount of the 2029 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2029 Notes. If we elect to redeem fewer than all of the outstanding 2029 Notes, at least $100.0 million aggregate principal amount of the 2029 Notes must be outstanding and not subject to redemption as of the redemption notice date. Upon the occurrence of a fundamental change (as defined in the 2029 Indenture), holders may require us to repurchase all or a portion of their 2029 Notes for cash at a price equal to 100% of the principal amount of the 2029 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-23-037591:notes:133]
The entire 2029 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of September 30, 2023 and July 1, 2023, measured at amortized cost.

[0001628280-23-037591:notes:134]
2028 Notes

[0001628280-23-037591:notes:135]
In March 2022, we issued $861.0 million in aggregate principal amount of 0.50% convertible senior notes due in 2028 (the “2028 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2028 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2028 Indenture”). The 2028 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-23-037591:notes:136]
The net proceeds from the sale of the 2028 Notes was $854.8 million, after deducting $6.2 million in issuance costs. In addition, we incurred $0.7 million in professional fees in connection with this transaction. Concurrent with the issuance of the 2028 Notes, we used $200.0 million of the net proceeds to repurchase our common stock in privately negotiated transactions.

[0001628280-23-037591:notes:137]
The 2028 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on June 15, 2022. The 2028 Notes will mature on June 15, 2028, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-23-037591:notes:138]
The initial conversion rate is 7.6319 shares of common stock per $1,000 principal amount of the 2028 Notes (which is equivalent to an initial conversion price of approximately $131.03 per share). The conversion rate is subject to adjustment upon the occurrence of certain specified events, but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2028 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2028 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-23-037591:notes:139]
Prior to the close of business on the business day immediately preceding March 15, 2028, holders of the 2028 Notes may convert their 2028 Notes only under the following circumstances:

[0001628280-23-037591:notes:140]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price, or $170.34, on each applicable trading day;

[0001628280-23-037591:notes:141]
•during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the 2028 Notes for each trading day of such measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the applicable conversion rate on each such trading day;

[0001628280-23-037591:notes:142]
•if the Company calls any or all of the 2028 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the redemption date; or

[0001628280-23-037591:notes:143]
•upon the occurrence of specified corporate events, as specified in the 2028 Indentures

[0001628280-23-037591:notes:144]
On or after March 15, 2028 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2028 Notes at any time. Upon conversion, we may satisfy our conversion obligation in cash, shares of common stock or a combination of cash and shares of common stock, at our election.

[0001628280-23-037591:notes:145]
We may redeem for cash all or any portion of the 2028 Notes, at our option (subject to the partial redemption limitation set forth in the 2028 Indenture), on or after June 20, 2025, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the 2028 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2028 Notes. If we elect to redeem fewer than all of the outstanding 2028 Notes, at least $100.0 million aggregate principal amount of the 2028 Notes must be outstanding and not subject to redemption as of the redemption notice date. Upon the occurrence of a fundamental change (as defined in the 2028 Indenture), holders may require the Company to repurchase all or a portion of their 2028 Notes for cash at a price equal to 100% of the principal amount of the 2028 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-23-037591:notes:146]
We initially bifurcated the principal amount of the 2028 Notes into liability and equity components. The liability component of the 2028 Notes was initially valued at $629.8 million based on the contractual cash flow discounted at an appropriate comparable market on non-convertible debt borrowing rate at the date of issuance, which was 5.7%, with the equity component representing the residual amount of the proceeds of $231.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2028 Notes were accounted for as a single liability measured at amortized cost. The entire 2028 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of September 30, 2023 and July 1, 2023, measured at amortized cost.

[0001628280-23-037591:notes:147]
2026 Notes

[0001628280-23-037591:notes:148]
In December 2019, we issued $1,050.0 million in aggregate principal amount of 0.50% convertible senior notes due in 2026 (the “2026 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2026 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association, as trustee (the “2026 Indenture”). We used approximately $196.0 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan credit facility, and a portion of the net proceeds of the offering to purchase approximately $200.0 million of our common stock concurrently with the pricing of the offering in privately negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-23-037591:notes:149]
The 2026 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on June 15, 2020. The 2026 Notes will mature on December 15, 2026, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-23-037591:notes:150]
The initial conversion rate is 10.0711 shares of common stock per $1,000 principal amount of the 2026 Notes (which is equivalent to an initial conversion price of approximately $99.29 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2026 Indenture but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2026 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares set forth in the 2026 Indenture or a holder that elects to convert the 2026 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-23-037591:notes:151]
Prior to the close of business on the business day immediately preceding September 15, 2026, holders of the 2026 Notes may convert their 2026 Notes only under the following circumstances:

[0001628280-23-037591:notes:152]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price of the 2026 Notes, or $129.08 on each applicable trading day;

[0001628280-23-037591:notes:153]
•during the five consecutive business day period after any five consecutive trading day period (the “2026 measurement period”) in which the trading price per $1,000 principal amount of the 2026 Notes for each trading day of the 2026 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the 2026 Notes on each such trading day;

[0001628280-23-037591:notes:154]
•if we call any or all of the 2026 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the relevant redemption date; or

[0001628280-23-037591:notes:155]
•upon the occurrence of specified corporate events.

[0001628280-23-037591:notes:156]
On or after September 15, 2026 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2026 Notes at any time. Upon conversion, we may satisfy our conversion obligation in cash, shares of common stock or a combination of cash and shares of common stock, at our election.

[0001628280-23-037591:notes:157]
We may redeem for cash, all or any portion of the 2026 Notes, at our option, on or after December 20, 2023, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide a notice of redemption at a redemption price equal to 100% of the principal amount of the 2026 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2026 Notes. Upon the occurrence of a fundamental change (as defined in the 2026 Indenture), holders may require us to repurchase all or a portion of the 2026 Notes for cash at a price equal to 100% of the principal amount of the 2026 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-23-037591:notes:158]
We initially bifurcated the principal amount of the 2026 Notes into liability and equity components. The liability component of the 2026 Notes was initially valued at $734.8 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 5.8% with the equity component representing the residual amount of the proceeds of $315.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2026 Notes were accounted for as a single liability measured at amortized cost. The entire 2026 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of September 30, 2023 and July 1, 2023, measured at amortized cost.

[0001628280-23-037591:notes:159]
2024 Notes

[0001628280-23-037591:notes:160]
In March 2017, we issued $450.0 million in aggregate principal amount of 0.25% convertible senior notes due in 2024 (the “2024 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2024 Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-23-037591:notes:161]
The 2024 Notes bear interest at a rate of 0.25% per year. Interest on the 2024 Notes is payable semi-annually in arrears on March 15 and September 15 of each year, beginning on September 15, 2017. The 2024 Notes will mature on March 15, 2024, unless earlier repurchased by us or converted pursuant to their terms.

[0001628280-23-037591:notes:162]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share. The conversion rate is subject to adjustment upon the occurrence of certain specified events but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2024 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2024 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-23-037591:notes:163]
Prior to the close of business on the business day immediately preceding December 15, 2023, each holder of the 2024 Notes may convert their 2024 Notes only under the following circumstances:

[0001628280-23-037591:notes:164]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price, or $78.80 on each applicable trading day;

[0001628280-23-037591:notes:165]
•during the five consecutive business day period after any five consecutive trading day period (the “2024 measurement period”) in which the trading price per $1,000 principal amount of 2024 Notes for each trading day of such 2024 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the 2024 Notes on each such trading day; or

[0001628280-23-037591:notes:166]
On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2024 Notes at any time. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2024 Indenture), we will, in certain circumstances, increase the conversion rate by a number of additional shares set forth in the 2024 Indenture for a holder that elects to convert 2024 Notes in connection with such make-whole fundamental change.

[0001628280-23-037591:notes:167]
We may not redeem the 2024 Notes prior to their maturity date and no sinking fund is provided for the 2024 Notes. Upon the occurrence of a fundamental change (as defined in the 2024 Indenture), holders may require us to repurchase all or a portion of their 2024 Notes for cash at a price equal to 100% of the principal amount of the 2024 Notes to be repurchased, plus any accrued and unpaid interest.

[0001628280-23-037591:notes:168]
We considered the features embedded in the 2024 Notes other than the conversion feature, including the holders’ put feature, our call feature, and the make-whole feature, and concluded that they are not required to be bifurcated and accounted for separately from the host debt instrument.

[0001628280-23-037591:notes:169]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. We incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. We amortize the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes is 5.4% per year.

[0001628280-23-037591:notes:170]
During fiscal 2017, we satisfied the TMA settlement condition. As such, the value of the conversion option is no longer marked-to-market and was reclassified to additional paid-in capital within stockholders’ equity on our condensed consolidated balance sheets. The value of the conversion option at the time of issuance is treated as an original issue discount for purposes of accounting for the debt component of the 2024 Notes. The debt component will accrete up to the original amount over the expected term of the debt. The adoption of ASU 2020-06 did not change the presentation of the 2024 Notes, as the conversion feature associated with the 2024 Notes continues to be classified within stockholders’ equity.

[0001628280-23-037591:notes:171]
Concurrent with the issuance of the 2029 Notes in June 2023, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 2024 Notes, which we accounted for as an extinguishment of liability. $13.5 million of the $132.8 million repurchase price was allocated to the conversion feature of the repurchased 2024 Notes, representing the fair value of the conversion feature at the date of the repurchase, and was recognized as a reduction of the stockholders’ equity. Additionally, since issuing the 2024 Notes, we have converted a total of approximately $1.9 million principal amount of the 2024 Notes. The remaining principal amount was $323.1 million as of September 30, 2023 and July 1, 2023, recorded as convertible notes, current in our consolidated balance sheets, as the 2024 Notes will mature on March 15, 2024.

[0001628280-23-037591:notes:172]
Convertible Notes - Additional Disclosures

[0001628280-23-037591:notes:173]
Our convertible notes consisted of the following components as of the periods presented (in millions):

[0001628280-23-037591:notes:174]
| September 30, 2023 | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |  | 2029 Notes (4) |  | Total |  |  |  |  |  |
| Principal | $ | 323.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,837.8 |  |  |  |  |  |  |
| Unamortized debt discount and debt issuance costs | (7.4) |  |  | (3.8) |  |  | (5.1) |  |  | (4.9) |  |  | (21.2) |  |  |  |  |  |  |
| Net carrying amount of the liability component | $ | 315.7 |  |  | $ | 1,046.2 |  |  | $ | 855.9 |  |  | $ | 598.8 |  |  | $ | 2,816.6 |  |  |  |  |  |  |

[0001628280-23-037591:notes:175]
| July 1, 2023 | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |  | 2029 Notes (4) |  | Total |
| Principal | $ | 323.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,837.8 |  |
| Unamortized debt discount and debt issuance costs | (11.5) |  |  | (4.1) |  |  | (5.5) |  |  | (5.1) |  |  | (26.2) |  |
| Net carrying amount of the liability component | $ | 311.6 |  |  | $ | 1,045.9 |  |  | $ | 855.5 |  |  | $ | 598.6 |  |  | $ | 2,811.6 |  |

[0001628280-23-037591:notes:176]
(1) If the closing price of our stock exceeds $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of any future fiscal quarter, our 2024 Notes would become convertible at the option of the holders during the next fiscal quarter. The 2024 Notes are classified as current liabilities as the debt will mature on March 15, 2024.

[0001628280-23-037591:notes:177]
(2) If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future fiscal quarter, our 2026 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-23-037591:notes:178]
(3) If the closing price of our stock exceeds $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of any future fiscal quarter, our 2028 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-23-037591:notes:179]
(4) If the closing price of our stock exceeds $90.40 (or 130% of the conversion price of $69.54) for 20 of the last 30 trading days of any future quarter, the 2029 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our consolidated balance sheets.

[0001628280-23-037591:notes:180]
The following table sets forth interest expense information related to the convertible notes for the periods presented (in millions):

[0001628280-23-037591:notes:181]
|  | Three Months Ended |  |  |
|  | September 30, 2023 |  | October 1, 2022 |  |  |  |  |
| Contractual interest expense | $ | 4.8 |  |  | $ | 2.7 |  |  |  |  |  |
| Amortization of the debt discount and debt issuance costs | 4.9 |  |  | 5.7 |  |  |  |  |  |
| Total interest expense | $ | 9.7 |  |  | $ | 8.4 |  |  |  |  |  |

[0001628280-23-037591:notes:182]
The future interest and principal payments related to our convertible notes are as follows as of September 30, 2023 (in millions):

[0001628280-23-037591:notes:183]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | 2028 Notes |  | 2029 Notes |  | Total |
| 2024 | $ | 323.7 |  |  | $ | 5.3 |  |  | $ | 4.3 |  |  | $ | 9.1 |  |  | $ | 342.4 |  |
| 2025 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.1 |  |  | 18.7 |  |
| 2026 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.1 |  |  | 18.7 |  |
| 2027 | — |  |  | 1,052.5 |  |  | 4.3 |  |  | 9.1 |  |  | 1,065.9 |  |
| 2028 | — |  |  | — |  |  | 865.3 |  |  | 9.1 |  |  | 874.4 |  |
| Thereafter | — |  |  | — |  |  | — |  |  | 617.1 |  |  | 617.1 |  |
| Total payments | $ | 323.7 |  |  | $ | 1,068.4 |  |  | $ | 882.5 |  |  | $ | 662.6 |  |  | $ | 2,937.2 |  |

[0001628280-23-037591:notes:184]
The principal balances of our convertible notes are reflected in the payment periods in the table above based on their respective contractual maturities.

[0001628280-23-037591:notes:185]
Mitsubishi Bank Loans

[0001628280-23-037591:notes:186]
In connection with our merger of NeoPhotonics, we assumed several loan agreements with MUFG Bank, Ltd. (the “Mitsubishi Bank Loans”) for an aggregate fair value of approximately $5.9 million, approximately $0.9 million of which was paid in the fiscal first quarter of 2023 and the remaining balance of approximately $5.0 million was fully paid in the fiscal second quarter of 2023.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-23-037591:notes:187]
[same as prior period, unchanged from 0001628280-23-016653:notes:186]

[0001628280-23-037591:notes:188]
[same as prior period, unchanged from 0001628280-23-016653:notes:187]

[0001628280-23-037591:notes:189]
[same as prior period, unchanged from 0001628280-23-016653:notes:188]

[0001628280-23-037591:notes:190]
|  | Foreign Currency Translation Adjustments, Net of Tax (1) |  | Defined Benefit Obligations, Net of Tax (2) |  | Unrealized Gain (Loss) on Available-for-Sale Securities, Net of Tax (3) |  |  |  | Total |
| Beginning balance as of July 1, 2023 | $ | 10.4 |  |  | $ | (0.4) |  |  | $ | (5.9) |  |  |  |  | $ | 4.1 |  |
| Other comprehensive gain (loss), net | (0.2) |  |  | — |  |  | 1.3 |  |  |  |  | 1.1 |  |
| Ending balance as of September 30, 2023 | $ | 10.2 |  |  | $ | (0.4) |  |  | $ | (4.6) |  |  |  |  | $ | 5.2 |  |
|  | Foreign Currency Translation Adjustments, Net of Tax (1) |  | Defined Benefit Obligations, Net of Tax (2) |  | Unrealized Gain (Loss) on Available-for-Sale Securities, Net of Tax (3) |  |  |  | Total |
| Beginning balance as of July 2, 2022 | $ | 9.7 |  |  | $ | 1.0 |  |  | $ | (10.3) |  |  |  |  | $ | 0.4 |  |
| Other comprehensive loss, net | — |  |  | — |  |  | (0.6) |  |  |  |  | (0.6) |  |
| Ending balance as of October 1, 2022 | $ | 9.7 |  |  | $ | 1.0 |  |  | $ | (10.9) |  |  |  |  | $ | (0.2) |  |

[0001628280-23-037591:notes:191]
(1) In fiscal 2019, we established the functional currency for our worldwide operations as the U.S. dollar. Translation adjustments reported prior to December 10, 2018 remain as a component of accumulated other comprehensive income (loss) in our condensed consolidated balance sheets, until all or a part of the investment in the subsidiaries is sold or liquidated. In fiscal 2023, we acquired IPG telecom transmission product lines. The functional currency of the Brazilian entities acquired as part of this acquisition is the local currency. During the three months ended September 30, 2023, we recorded foreign currency translation adjustments of $0.2 million.

[0001628280-23-037591:notes:192]
(2) We re-evaluate the assumptions related to the fair value of our defined benefit obligations annually in the fiscal fourth quarter and make any updates as necessary.

[0001628280-23-037591:notes:193]
(3) For the three months ended September 30, 2023 and October 1, 2022, our unrealized loss on available-for-sale securities is presented net of tax of $0.4 million and $0.2 million, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-23-037591:notes:194]
[same as prior period, unchanged from 0001628280-23-016653:notes:193]

[0001628280-23-037591:notes:195]
[same as prior period, unchanged from 0001628280-23-016653:notes:194]

[0001628280-23-037591:notes:196]
[same as prior period, unchanged from 0001628280-23-016653:notes:195]

[0001628280-23-037591:notes:197]
|  | Three Months Ended |  |  |
|  | September 30, 2023 |  | October 1, 2022 |  |  |  |  |
| Balance as of beginning of period | $ | 5.0 |  |  | $ | — |  |  |  |  |  |
| Charges | 11.0 |  |  | 9.3 |  |  |  |  |  |
| Payments | (6.7) |  |  | (6.2) |  |  |  |  |  |
| Balance as of end of period | $ | 9.3 |  |  | $ | 3.1 |  |  |  |  |  |

[0001628280-23-037591:notes:198]
During the three months ended September 30, 2023, we recorded restructuring and related charges of $11.0 million in our condensed consolidated statements of operations, which was primarily due to company-wide cost reduction initiatives, as well as our integration efforts as a result of the merger with NeoPhotonics.

[0001628280-23-037591:notes:199]
During the three months ended October 1, 2022, we recorded restructuring and related charges of $9.3 million in our condensed consolidated statements of operations, which was primarily attributable to severance and employee-related benefits associated with NeoPhotonics’ executive severance and retention agreements. These retention agreements provide, under certain circumstances, for payments and benefits upon an involuntary termination of employment.

[0001628280-23-037591:notes:200]
[same as prior period, unchanged from 0001628280-23-016653:notes:201]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-23-037591:notes:201]
[same as prior period, unchanged from 0001628280-23-016653:notes:202]

[0001628280-23-037591:notes:202]
[same as prior period, unchanged from 0001628280-23-016653:notes:203]

[0001628280-23-037591:notes:203]
We recorded a tax benefit of $1.4 million and a tax provision of $19.2 million for the three months ended September 30, 2023 and October 1, 2022, respectively. Our tax provision for the three months ended September 30, 2023 includes a discrete tax benefit of $1.8 million primarily related to the tax benefit from changes in prior year uncertain tax positions, partially offset by the tax expenses related to a shortfall in connection with stock-based compensation vested during the quarter and foreign return to provision differences. Our tax provision for the three months ended October 1, 2022 includes a discrete tax expense of $13.1 million, primarily related to the international restructuring and currency re-measurement of certain tax related accounts, partially offset by the tax benefits from tax rate changes.

[0001628280-23-037591:notes:204]
Our estimated effective tax rate for fiscal 2024 differs from the 21% U.S. statutory rate primarily due to the income tax expense from foreign rate differential, non-deductible stock-based compensation and foreign income inclusions in the U.S., partially offset by the income tax benefit from various income tax credits.

[0001628280-23-037591:notes:205]
As of September 30, 2023, we had $59.5 million of unrecognized tax benefits, which, if recognized, would affect the effective tax rate. We are subject to examination of income tax returns by various domestic and foreign tax authorities. The timing of resolution and closure of these tax examinations is highly unpredictable. Although it is possible that certain ongoing tax examinations may be concluded within the next 12 months, we cannot reasonably estimate the impact to tax expense and net income from tax exams that could be resolved or closed within the next 12 months. Subject to audit timing and uncertainty, we expect the amount of unrecognized tax benefit that would become recognized due to expiration of the statute of limitations and affect the effective tax rate to decrease by $1.9 million over the next 12 months.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-23-037591:notes:206]
[same as prior period, unchanged from 0001628280-23-016653:notes:206]

[0001628280-23-037591:notes:207]
[same as prior period, unchanged from 0001628280-23-016653:notes:207]

[0001628280-23-037591:notes:208]
[same as prior period, unchanged from 0001628280-23-016653:notes:208]

[0001628280-23-037591:notes:209]
[same as prior period, unchanged from 0001628280-23-016653:notes:209]

[0001628280-23-037591:notes:210]
As of September 30, 2023, we had 4.6 million shares subject to restricted stock units, restricted stock awards, and performance stock units issued and outstanding under the 2015 Plan. These grants are performance-based, time-based or a combination of both and are expected to vest within four years. The fair value of these grants is based on the closing market price of our common stock on the date of grant. As of September 30, 2023, 0.4 million shares of common stock under the 2015 Plan were available for grant.

[0001628280-23-037591:notes:211]
[same as prior period, unchanged from 0001628280-23-016653:notes:211]

[0001628280-23-037591:notes:212]
In connection with the merger with NeoPhotonics, we issued equity awards to certain NeoPhotonics employees, consisting of restricted stock units (the “Replacement Awards”) in exchange for their NeoPhotonics equity awards. The terms of these Replacement Awards are substantially similar to the original NeoPhotonics equity awards. The Replacement Awards consisted of 0.4 million restricted stock units with a grant date fair value of $93.4 per share, which represents our closing stock price on the Closing date. The total fair value of these Replacement Awards is $40.2 million, $3.5 million of which is attributable to employee services rendered through August 3, 2022, the merger Closing date, and was recognized as a component of the merger consideration and stock-based compensation in the consolidated statements of stockholders’ equity. The remaining fair value of the Replacement Awards is recorded as stock-based compensation over the remaining vesting period. Refer to “Note 4. Business Combinations.”

[0001628280-23-037591:notes:213]
[same as prior period, unchanged from 0001628280-23-016653:notes:213]

[0001628280-23-037591:notes:214]
Restricted stock units (“RSUs”) under the 2015 Plan are grants of shares of our common stock, the vesting of which is based on the requisite service requirement. Generally, our RSUs are subject to forfeiture and are expected to vest within four years. For annual refresh grants, RSUs generally vest ratably on an annual basis, or combination of annual and quarterly basis, over three years.

[0001628280-23-037591:notes:215]
During the three months ended September 30, 2023, our board of directors approved grants of 1.7 million RSUs, which primarily vest over three years.

[0001628280-23-037591:notes:216]
[same as prior period, unchanged from 0001628280-23-016653:notes:216]

[0001628280-23-037591:notes:217]
Performance stock units (“PSUs”) under the 2015 Plan are grants of shares of our common stock that vest upon the achievement of certain performance and service conditions. We begin recognizing compensation expense when we conclude that it is probable that the performance conditions will be achieved. We reassess the probability of vesting at each reporting period and adjust our compensation cost based on this probability assessment. Our PSUs are subject to risk of forfeiture until performance and service conditions are satisfied and generally vest within three years.

[0001628280-23-037591:notes:218]
During the three months ended September 30, 2023, our board of directors approved a grant of 0.3 million PSUs with an aggregate grant date fair value of $16.0 million to executive and non-executive employees as part of our revised Annual Incentive Plan. These PSUs are subject to performance targets and service conditions, with a vesting period of one year. The board of directors also approved a grant of 0.4 million PSUs with an aggregate grant date fair value of $19.3 million to certain executive officers and senior management. These PSUs will vest subject to the achievement of revenue targets and certain non-financial performance measurements, as well as service conditions, over three years.

[0001628280-23-037591:notes:219]
[same as prior period, unchanged from 0001628280-23-016653:notes:219]

[0001628280-23-037591:notes:220]
Our 2015 Employee Stock Purchase Plan (the “2015 Purchase Plan”) provides eligible employees with the opportunity to acquire an ownership interest in the Company through periodic payroll deductions and provides a 15% purchase price discount as well as a 6-month look-back period. The 2015 Purchase Plan is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986, as amended. The 2015 Purchase Plan will terminate upon the date on which all shares available for issuance have been sold. Of the 3.0 million shares authorized under the 2015 Purchase Plan, 1.1 million shares remained available for issuance as of September 30, 2023.

[0001628280-23-037591:notes:221]
[same as prior period, unchanged from 0001628280-23-016653:notes:221]

[0001628280-23-037591:notes:222]
[same as prior period, unchanged from 0001628280-23-016653:notes:222]

[0001628280-23-037591:notes:223]
|  | Three Months Ended |  |  |
|  | September 30, 2023 |  | October 1, 2022 |  |  |  |  |
| Cost of sales | $ | 6.0 |  |  | $ | 5.5 |  |  |  |  |  |
| Research and development | 10.3 |  |  | 9.6 |  |  |  |  |  |
| Selling, general and administrative | 15.8 |  |  | 31.5 |  |  |  |  |  |
| Total stock-based compensation | $ | 32.1 |  |  | $ | 46.6 |  |  |  |  |  |

[0001628280-23-037591:notes:224]
In connection with the NeoPhotonics merger, we issued replacement equity awards (the “Replacement Awards”) in settlement of certain NeoPhotonics equity awards at the merger Closing date, with the total fair value of $40.2 million based on our closing stock price on the Closing date. The portion of Replacement Awards attributed to pre-merger service is $3.5 million, which was accounted for as part of the consideration transferred and was recorded under stock-based compensation in our consolidated statements of stockholders’ equity as of July 1, 2023. Additionally, certain equity awards for NeoPhotonics employees were accelerated. The total stock-based compensation associated with the acceleration was $11.9 million, of which $9.0 million was settled in cash. We recorded the $11.9 million for the accelerated awards in our consolidated statements of operations during the first quarter of fiscal year 2023.

[0001628280-23-037591:notes:225]
For the three months ended September 30, 2023 and October 1, 2022, $4.7 million and $8.8 million, respectively, of stock-based compensation costs are related to PSUs. The amount of stock-based compensation expense recognized in any one period related to PSUs can vary based on the achievement or anticipated achievement of the performance conditions. If the performance conditions are not met or not expected to be met, no compensation cost would be recognized on the underlying PSUs, and any previously recognized compensation expense related to those PSUs would be reversed.

[0001628280-23-037591:notes:226]
[same as prior period, unchanged from 0001628280-23-016653:notes:226]

[0001628280-23-037591:notes:227]
|  | Three Months Ended |  |  |
|  | September 30, 2023 |  | October 1, 2022 |  |  |  |  |
| Income tax benefit associated with stock-based compensation | $ | 1.9 |  |  | $ | 5.1 |  |  |  |  |  |

[0001628280-23-037591:notes:228]
Approximately $16.9 million and $14.2 million of stock-based compensation was capitalized to inventory as of September 30, 2023 and July 1, 2023, respectively.

[0001628280-23-037591:notes:229]
As of September 30, 2023, $219.3 million of stock-based compensation cost related to RSU awards remains to be amortized, which is expected to be recognized over an estimated amortization period of 2.3 years.

[0001628280-23-037591:notes:230]
[same as prior period, unchanged from 0001628280-23-016653:notes:230]

[0001628280-23-037591:notes:231]
The following table summarizes our award activities for the three months ended September 30, 2023 (in millions, except per share amounts):

[0001628280-23-037591:notes:232]
|  |  |  |  |  | Restricted Stock Units |  | Performance Stock Units |  |  |  |  |
|  |  |  |  |  |  |  |  |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  |  |  |  |
| Balance as of July 1, 2023 |  |  |  |  |  |  |  |  | 2.6 |  |  | $ | 85.0 |  |  | 0.6 |  |  | $ | 89.1 |  |  |  |  |  |
| Granted |  |  |  |  |  |  |  |  | 1.7 |  |  | 52.9 |  |  | 0.7 |  |  | 53.3 |  |  |  |  |  |
| Vested |  |  |  |  |  |  |  |  | (0.7) |  |  | 88.9 |  |  | (0.2) |  |  | 89.5 |  |  |  |  |  |
| Canceled |  |  |  |  |  |  |  |  | (0.1) |  |  | 81.2 |  |  | — |  |  | 90.1 |  |  |  |  |  |
| Balance as of September 30, 2023 |  |  |  |  |  |  |  |  | 3.5 |  |  | $ | 68.0 |  |  | 1.1 |  |  | $ | 65.9 |  |  |  |  |  |

[0001628280-23-037591:notes:233]
[same as prior period, unchanged from 0001628280-23-016653:notes:233]

[0001628280-23-037591:notes:234]
|  | Awards Available for Grant |
| Balance as of July 1, 2023 | 2.7 |  |
| Granted | (2.4) |  |
| Canceled | 0.1 |  |
| Balance as of September 30, 2023 | 0.4 |  |

[0001628280-23-037591:notes:235]
[same as prior period, unchanged from 0001628280-23-016653:notes:235]

[0001628280-23-037591:notes:236]
The 2015 Purchase Plan expense for the three months ended September 30, 2023 and October 1, 2022 was $1.2 million and $1.2 million, respectively. The expense related to the 2015 Purchase Plan is recorded on a straight-line basis over the relevant subscription period.

[0001628280-23-037591:notes:237]
During the three months ended September 30, 2023 and October 1, 2022, there were no shares issued to employees through the 2015 Purchase Plan.

[0001628280-23-037591:notes:238]
[same as prior period, unchanged from 0001628280-23-016653:notes:238]

[0001628280-23-037591:notes:239]
Share Buyback Program

[0001628280-23-037591:notes:240]
We have a share buyback program that authorizes us to utilize up to an aggregate amount of $1.2 billion to purchase our own shares of common stock through May 2025. During the three months ended September 30, 2023, we did not repurchase any shares of our common stock. During the three months ended October 1, 2022, we repurchased 0.3 million shares of our common stock at an average price of $89.80 per share for an aggregate purchase price of $25.7 million. Since the board of directors initially approved the share buyback program, we have repurchased 7.7 million shares in aggregate at an average price of $81.66 per share for a total purchase price of $630.4 million. We recorded the $630.4 million aggregate purchase price as a reduction of retained earnings within our condensed consolidated balance sheet. All repurchased shares were retired immediately. As of September 30, 2023, we have $569.6 million remaining under the share buyback program.

[0001628280-23-037591:notes:241]
[same as prior period, unchanged from 0001628280-23-016653:notes:242]


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001628280-23-037591:notes:242]
Note 14. Commitments and Contingencies

[0001628280-23-037591:notes:243]
Purchase Obligations

[0001628280-23-037591:notes:244]
Our purchase obligations of $395.0 million as of September 30, 2023  represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001628280-23-037591:notes:245]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with these vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

[0001628280-23-037591:notes:246]
Product Warranties

[0001628280-23-037591:notes:247]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve-month warranty for most of our products. However, in some instances depending upon the product, product components or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products, and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001628280-23-037591:notes:248]
The following table presents the changes in our warranty reserve for the periods presented (in millions):

[0001628280-23-037591:notes:249]
|  | Three Months Ended |  |  |
|  | September 30, 2023 |  | October 1, 2022 |  |  |  |  |
| Balance as of beginning of period | $ | 6.8 |  |  | $ | 10.0 |  |  |  |  |  |
| Warranties assumed in NeoPhotonics merger | — |  |  | 0.7 |  |  |  |  |  |
| Provision for warranty | 0.2 |  |  | 1.5 |  |  |  |  |  |
| Utilization of reserve | (1.5) |  |  | (2.1) |  |  |  |  |  |
| Balance as of end of period | $ | 5.5 |  |  | $ | 10.1 |  |  |  |  |  |

[0001628280-23-037591:notes:250]
Environmental Liabilities

[0001628280-23-037591:notes:251]
Our research and development, manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental and product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001628280-23-037591:notes:252]
Legal Proceedings

[0001628280-23-037591:notes:253]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss. During the year ended July 1, 2023, we recorded $7.8 million with respect to the pending settlement of certain non-ordinary course litigation matters under accrued expenses in our consolidated balance sheet, which has not been settled as of September 30, 2023.

[0001628280-23-037591:notes:254]
Oclaro Merger Litigation

[0001628280-23-037591:notes:255]
In connection with our acquisition of Oclaro in 2018, seven lawsuits were filed by purported stockholders of Oclaro challenging the proposed merger (the “Merger”). All but one was voluntarily dismissed after the Oclaro Merger closed. The remaining lawsuit, SaiSravan B. Karri v. Oclaro, Inc., et al., No. 3:18-cv-03435-JD (the “Karri Lawsuit”), was filed in the United States District Court for the Northern District of California and is styled as a class action.

[0001628280-23-037591:notes:256]
The Karri Lawsuit alleges, among other things, that Oclaro and its directors violated Section 14(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), and Rule 14a-9 promulgated thereunder by disseminating an incomplete and misleading Form S-4, including proxy statement/prospectus. The Karri Lawsuit further alleged that Oclaro’s directors violated Section 20(a) of the Exchange Act by failing to exercise proper control over the person(s) who violated Section 14(a) of the Exchange Act. The plaintiff in the Karri Lawsuit seeks, among other things, damages to be awarded to the plaintiff and any class, if a class is certified, and litigation costs, including attorneys’ fees.

[0001628280-23-037591:notes:257]
After the plaintiff in the Karri Lawsuit was appointed as lead plaintiff and his counsel as lead counsel, the plaintiff filed a first amended complaint on April 15, 2019. The first amended complaint, also named Lumentum as a defendant but Lumentum has since been dismissed from the action. On October 8, 2020, the court granted in part and denied in part the defendant’s motion to dismiss the first amended complaint. On December 1, 2020, defendants answered the first amended complaint. On September 17, 2021, lead plaintiff filed a second amended complaint. Defendants moved to stay discovery in light of the second amended complaint. On January 11, 2022, the Court struck the second amended complaint as untimely, terminated defendants’ motions to dismiss as moot, and lifted the stay. The case proceeded through fact and expert discovery.

[0001628280-23-037591:notes:258]
On August 16, 2022, the lead plaintiff moved for class certification and to be appointed class representative. Defendants opposed the motion. The action subsequently was stayed while the parties participated in a mediation. On January 18, 2023, the lead plaintiff filed a Notice of Settlement informing the court of an agreement in principle between the parties for a class-wide settlement of the Karri Lawsuit. On January 24, 2023, in light of the potential settlement, the court vacated all pretrial and trial dates and ordered the lead plaintiff to file a motion for preliminary approval of the settlement by March 17, 2023. The lead plaintiff filed his motion for preliminary approval of the settlement on March 16, 2023, and defendants filed a statement of non-opposition on March 30, 2023. On April 20, 2023, the court held a hearing on lead plaintiff’s motion for preliminary approval of the settlement. The court declined to grant lead plaintiff’s motion for preliminary approval and ordered lead plaintiff to file a revised motion by May 22, 2023. Lead plaintiff filed his Revised Motion for Preliminary Approval of Settlement (the “Amended Motion”) on May 22, 2023, defendants filed a response in support of the Amended Motion on June 5, 2023, and the lead plaintiff submitted his reply on June 12, 2023. The hearing on the Amended Motion took place on August 17, 2023 and the court preliminarily approved the settlement. In the event that the settlement does not go forward for any reason, the defendants intend to continue to defend the Karri Lawsuit vigorously.

[0001628280-23-037591:notes:259]
Indemnifications

[0001628280-23-037591:notes:260]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown, because claims may be made against us in the future, and we may record charges in the future as a result of these indemnification obligations. As of September 30, 2023, we did not have any material indemnification claims that were probable or reasonably possible.

[0001628280-23-037591:notes:261]
Audit Proceedings

[0001628280-23-037591:notes:262]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period when we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-23-037591:notes:263]
[same as prior period, unchanged from 0001628280-23-016653:notes:266]

[0001628280-23-037591:notes:264]
Prior to fiscal year 2024, we operated in two reportable segments consisting of Optical Communications (“OpComms”) and Commercial Lasers (“Lasers”). During the fiscal first quarter of 2024, our chief operating decision maker (“CODM”) implemented changes in how he organizes the business, allocates resources, and assesses performance. We changed our organizational structure to better align with trends in our markets and our customer and product mix. Our new operating segments are Cloud & Networking and Industrial Tech. The Cloud & Networking segment includes the Telecom & Datacom product lines that were previously part of the OpComms segment. The Industrial Tech segment includes previous Lasers segment and the Industrial & Consumer product lines that were previously part of the OpComms segment. The two operating segments were primarily determined based on how the CODM views and evaluates our operations. The CODM regularly reviews operating results to make decisions about resources to be allocated to the segments and to assess their performance.

[0001628280-23-037591:notes:265]
In conjunction with this change, our CODM now evaluates each segment’s performance and allocates resources based on segment revenue and segment profit, instead of gross profit, as our CODM believes segment profit is a more comprehensive profitability measure for each operating segment. Segment profit includes operating expenses directly managed by operating segments, including research and development, and direct sales and marketing expenses. Segment profit does not include stock-based compensation, acquisition or integration related costs, amortization and impairment of acquisition-related intangible assets, restructuring and related charges, and certain other charges. Additionally, we do not allocate corporate marketing and strategic marketing expenses and general and administrative expenses, as these expenses are not directly attributable to our operating segments.

[0001628280-23-037591:notes:266]
Comparative prior period segment information has been recast to conform to the new segment structure and segment profitability measure. The change in our operating segments had no impact on our previously reported consolidated results of operations, financial condition, or cash flows.

[0001628280-23-037591:notes:267]
We do not track all of our property, plant and equipment by operating segments. The geographic identification of these assets is set forth below.

[0001628280-23-037591:notes:268]
Cloud & Networking

[0001628280-23-037591:notes:269]
Our Cloud and Networking products include a wide range of components, modules, and subsystems to support customers including carrier networks for access (local), metro (intracity), long-haul (city-to-city and worldwide) and submarine (undersea) applications. Additionally, our products address enterprise, cloud, and data center applications, including storage-access networks (“SANs”), local-area networks (“LANs”) and wide-area networks (“WANs”), as well as artificial intelligence and machine learning (“AI/ML”). These products enable the transmission and transport of video, audio, and data over high-capacity fiber-optic cables. We maintain leading positions in these fast-growing cloud and networking markets through our extensive product portfolio, including reconfigurable optical add/drop multiplexers (“ROADMs”), coherent dense wavelength division multiplexing (“DWDM”) pluggable transceivers, and tunable small form-factor pluggable transceivers. We also sell laser chips for use in manufacturing of high-speed ethernet transceivers for use inside data centers.

[0001628280-23-037591:notes:270]
Industrial Tech

[0001628280-23-037591:notes:271]
Our Industrial Tech products include diode laser products such as VCSELs and edge emitting lasers. In the consumer end-market, our laser light sources are integrated into 3D sensing cameras which are used in applications in mobile devices, gaming, payment kiosks, computers, and other consumer electronics devices. Applications include biometric identification, computational photography, virtual and augmented reality, and natural user interfaces. Emerging applications for our lasers include automotive safety systems, LiDAR for advanced driver assistance systems in automobiles and autonomous vehicles, self-navigating robotics and drones in industrial applications, and 3D capture of objects coupled with 3D imaging or printing. In the industrial end market, our diode lasers are used primarily as pump sources for pulsed and kilowatt class fiber lasers.

[0001628280-23-037591:notes:272]
Industrial Tech products also include laser products used in a variety of OEM applications including diode-pumped solid-state, fiber, diode, direct-diode and gas lasers such as argon-ion and helium-neon lasers. Fiber lasers provide kW-class output powers combined with excellent beam quality and are used in sheet metal processing and metal welding applications. These applications range in output power from milliwatts to kilowatts and include ultraviolet, visible and infrared wavelengths. Our laser products serve our customers in markets and applications such as sheet metal processing, general manufacturing, solar cell processing, biotechnology, graphics and imaging, remote sensing, and precision machining such as drilling in printed circuit boards, wafer singulation, glass cutting and solar cell scribing. We also provide high-powered and ultrafast lasers for the industrial and scientific markets. Manufacturers use high-power, ultrafast lasers to create micro parts for consumer electronics and to process semiconductor, LED, solar cells, and other types of chips. Use of ultrafast lasers for micromachining applications is being driven primarily by the increasing use of renewable energy, consumer electronics and connected devices globally.

[0001628280-23-037591:notes:273]
[same as prior period, unchanged from 0001628280-23-016653:notes:276]

[0001628280-23-037591:notes:274]
The two operating segments, Cloud & Networking and Industrial Tech, also represent our two reportable segments. Our CODM allocates resources and evaluates segment performance based on segment revenue and segment profit. The following table summarizes segment profit and a reconciliation to the consolidated income (loss) before income taxes for the periods presented (in millions). Comparative prior period segment information has been recast to conform to the new segment structure.

[0001628280-23-037591:notes:275]
|  | Three Months Ended |  |  |
|  | September 30, 2023 |  | October 1, 2022 |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |
| Cloud & Networking | $ | 229.7 |  |  | $ | 360.1 |  |  |  |  |  |
| Industrial Tech | 87.9 |  |  | 146.7 |  |  |  |  |  |
| Net revenue | $ | 317.6 |  |  | $ | 506.8 |  |  |  |  |  |
| Segment profit: |  |  |  |  |  |  |  |
| Cloud & Networking | $ | 23.9 |  |  | $ | 101.7 |  |  |  |  |  |
| Industrial Tech | 15.3 |  |  | 68.8 |  |  |  |  |  |
| Total segment profit | 39.2 |  |  | 170.5 |  |  |  |  |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Selling, general and administrative (1) | (28.6) |  |  | (33.1) |  |  |  |  |  |
| Stock-based compensation | (32.1) |  |  | (34.7) |  |  |  |  |  |
| Stock-based compensation - acquisition related | — |  |  | (11.9) |  |  |  |  |  |
| Amortization of acquired intangibles | (29.0) |  |  | (32.2) |  |  |  |  |  |
| Amortization of acquired inventory fair value adjustments | — |  |  | (4.6) |  |  |  |  |  |
| Acquisition related costs | (4.0) |  |  | (16.2) |  |  |  |  |  |
| Integration related costs | (11.3) |  |  | (0.6) |  |  |  |  |  |
| Restructuring and related charges | (11.0) |  |  | (9.3) |  |  |  |  |  |
| Other charges, net (2) | (4.0) |  |  | (14.4) |  |  |  |  |  |
| Interest expense | (9.7) |  |  | (8.5) |  |  |  |  |  |
| Other income, net (3) | 21.2 |  |  | 13.8 |  |  |  |  |  |
| Consolidated income (loss) before income taxes | $ | (69.3) |  |  | $ | 18.8 |  |  |  |  |  |

[0001628280-23-037591:notes:276]
(1) We do not allocate selling, general and administrative expenses that are not directly attributable to our operating segments.

[0001628280-23-037591:notes:277]
(2)  Other charges, net for  the three months ended September 30, 2023 primarily relate to $2.9 million of incremental costs of sales related to components previously acquired from various brokers to satisfy customer demand. Other charges, net for the three months ended October 1, 2022 primarily relate to $7.3 million of charges to acquire components from various brokers to satisfy customer demand, $3.3 million of legal and professional fees, and $1.2 million of costs related to newly implemented employee benefit program.

[0001628280-23-037591:notes:278]
(3) Other income, net for the three months ended September 30, 2023 includes $21.7 million of interest and investment income, offset by $0.5 million of net foreign exchange losses. Other income, net the three months ended October 1, 2022 includes $9.0 million of net foreign exchange gains and $4.8 million of interest and investment income.

[0001628280-23-037591:notes:279]
[same as prior period, unchanged from 0001628280-23-016653:notes:282]

[0001628280-23-037591:notes:280]
We operate in three geographic regions: Americas, Asia-Pacific, and EMEA (Europe, Middle East, and Africa). Net revenue is assigned to the geographic region and country where our product is initially shipped. For example, certain customers may request shipment of our product to a contract manufacturer in one country, which may differ from the location of their end customers.

[0001628280-23-037591:notes:281]
The following table presents net revenue by the three geographic regions we operate in and net revenue from countries that generally represented 10% or more of our total net revenue (in millions, except percentage data):

[0001628280-23-037591:notes:282]
|  | Three Months Ended |  |
|  | September 30, 2023 |  | October 1, 2022 |  |  |  |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 41.1 |  |  | 12.9 | % |  | $ | 62.2 |  |  | 12.3 | % |  |  |  |  |  |  |  |
| Mexico | 23.7 |  |  | 7.5 |  |  | 57.5 |  |  | 11.3 |  |  |  |  |  |  |  |  |
| Other Americas | 1.2 |  |  | 0.4 |  |  | 2.3 |  |  | 0.5 |  |  |  |  |  |  |  |  |
| Total Americas | $ | 66.0 |  |  | 20.8 | % |  | $ | 122.0 |  |  | 24.1 | % |  |  |  |  |  |  |  |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 64.9 |  |  | 20.4 | % |  | $ | 77.6 |  |  | 15.3 | % |  |  |  |  |  |  |  |
| South Korea | 25.0 |  |  | 7.9 |  |  | 67.7 |  |  | 13.4 |  |  |  |  |  |  |  |  |
| Thailand | 64.2 |  |  | 20.2 |  |  | 57.5 |  |  | 11.3 |  |  |  |  |  |  |  |  |
| Other Asia-Pacific | 64.9 |  |  | 20.4 |  |  | 133.7 |  |  | 26.4 |  |  |  |  |  |  |  |  |
| Total Asia-Pacific | $ | 219.0 |  |  | 68.9 | % |  | $ | 336.5 |  |  | 66.4 | % |  |  |  |  |  |  |  |
| EMEA | $ | 32.6 |  |  | 10.3 | % |  | $ | 48.3 |  |  | 9.5 | % |  |  |  |  |  |  |  |
| Total net revenue | $ | 317.6 |  |  | 100.0 | % |  | $ | 506.8 |  |  | 100.0 | % |  |  |  |  |  |  |  |

[0001628280-23-037591:notes:283]
During the three months ended September 30, 2023, our net revenue from a single customer that represented 10% or greater of the total net revenue was concentrated with three customers, who individually accounted for 15%, 13% and 10% of our total net revenue, respectively. During the three months ended October 1, 2022, our net revenue from a single customer that represented 10% or greater of total net revenue was concentrated with two customers, who individually accounted for 17% and 17% of our total net revenue, respectively.

[0001628280-23-037591:notes:284]
As of September 30, 2023, our accounts receivable from a single customer that represented 10% or greater of the total accounts receivable was concentrated with two customers, who individually accounted for 12% and 11% of gross accounts receivable, respectively. As of July 1, 2023, our accounts receivable from a single customer that represented 10% or greater of the total accounts receivable was concentrated with three customers, who individually accounted for 14%, 12% and 12% of gross accounts receivable, respectively.

[0001628280-23-037591:notes:285]
[same as prior period, unchanged from 0001628280-23-016653:notes:287]

[0001628280-23-037591:notes:286]
|  | September 30, 2023 |  | July 1, 2023 |
| Property, plant and equipment, net |  |  |  |
| United States | $ | 137.3 |  |  | $ | 134.7 |  |
| Thailand | 131.7 |  |  | 132.0 |  |
| Japan | 87.3 |  |  | 93.0 |  |
| United Kingdom | 66.3 |  |  | 38.2 |  |
| China | 38.5 |  |  | 42.1 |  |
| Other countries | 50.5 |  |  | 49.5 |  |
| Total property, plant and equipment, net | $ | 511.6 |  |  | $ | 489.5 |  |

[0001628280-23-037591:notes:287]
We purchase a portion of our inventory from contract manufacturers and vendors located primarily in Taiwan, Thailand and Malaysia. During the three months ended September 30, 2023, our net inventory purchases from a single contract manufacturer that represented 10% or greater of our total net inventory purchases were concentrated with one contract manufacturer, who accounted for 45% of the total net inventory purchases. During the three months ended October 1, 2022, our net inventory purchases from a single contract manufacturer that represented 10% or greater of our total net inventory purchases were concentrated with two contract manufacturers, who collectively accounted for 51% of total net inventory purchases.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-23-037591:notes:288]
[same as prior period, unchanged from 0001628280-23-016653:notes:290]

[0001628280-23-037591:notes:289]
[same as prior period, unchanged from 0001628280-23-016653:notes:291]

[0001628280-23-037591:notes:290]
We disaggregate revenue by segment and by geography. We do not present other levels of disaggregation, such as by type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, as this information is not used by our CODM to manage the business.

[0001628280-23-037591:notes:291]
The table below discloses our total net revenue attributable to each of our two reportable segments (in millions, except percentage data):

[0001628280-23-037591:notes:292]
|  | Three Months Ended |  |  |
|  | September 30, 2023 |  | October 1, 2022 |  |  |  |  |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  |  |  |  |  |  |
| Cloud & Networking | $ | 229.7 |  |  | 72.3 | % |  | $ | 360.1 |  |  | 71.1 | % |  |  |  |  |  |  |
| Industrial Tech | 87.9 |  |  | 27.7 | % |  | 146.7 |  |  | 28.9 | % |  |  |  |  |  |  |
| Net revenue | $ | 317.6 |  |  | 100.0 | % |  | $ | 506.8 |  |  | 100.0 | % |  |  |  |  |  |  |

[0001628280-23-037591:notes:293]
[same as prior period, unchanged from 0001628280-23-016653:notes:295]

[0001628280-23-037591:notes:294]
[same as prior period, unchanged from 0001628280-23-016653:notes:296]

[0001628280-23-037591:notes:295]
| Contract balances |  | Balance sheet location |  | September 30, 2023 |  | July 1, 2023 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 220.0 |  |  | $ | 246.1 |  |  | $ | (26.1) |  |  | (10.6) | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | 1.6 |  |  | $ | 2.1 |  |  | $ | (0.5) |  |  | (23.8) | % |


## us-gaap:SubsequentEventsTextBlock

[0001628280-23-037591:notes:296]
Note 17. Subsequent Event

[0001628280-23-037591:notes:297]
On October 30, 2023, Lumentum and Cloud Light Technology Limited (“Cloud Light”) announced a definitive merger agreement (the “Merger Agreement”), On November 7, 2023 (the “Closing date”), we completed the acquisition of Cloud Light. The acquisition will enable us to be well-positioned to serve the growing needs of cloud and networking customers, particularly those focused on optimizing their data center infrastructure for the demands of AI/ML. The total transaction value is approximately $750.0 million, subject to certain customary adjustments as specified in the Merger Agreement. We paid cash consideration of $706.6 million to shareholders of Cloud Light on the Closing date. Additionally, we converted each of Cloud Light’s outstanding options into options to acquire Lumentum common stock with equivalent value.

[0001628280-23-037591:notes:298]
During the three months ended September 30, 2023, we incurred $3.7 million of transaction costs related to this acquisition, which were recorded under selling, general and administrative expenses in our consolidated statement of operations.

[0001628280-23-037591:notes:299]
The acquisition will be accounted for as a business combination using the acquisition method of accounting, which requires, among other things, certain assets acquired and liabilities assumed be recognized at their fair values as of the acquisition date. We are currently evaluating the purchase accounting for this acquisition.
