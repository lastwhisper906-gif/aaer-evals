# LITE 8-K — 0001628280-23-037563 filed 2023-11-08

## item codes, every 8-K on or before 2023-11-08

- 2023-11-08 0001628280-23-037563 — 2.02, 9.01
- 2023-11-07 0001193125-23-272452 — 2.01, 8.01, 9.01
- 2023-10-30 0001193125-23-265658 — 1.01, 2.02, 9.01
- 2023-08-17 0001628280-23-029741 — 2.02, 9.01
- 2023-06-16 0001193125-23-168966 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2023-05-09 0001628280-23-016629 — 2.02, 9.01
- 2023-04-06 0001628280-23-010935 — 2.02, 8.01, 9.01
- 2023-02-24 0001193125-23-048742 — 5.02, 9.01
- 2023-02-09 0001628280-23-002866 — 2.02, 9.01
- 2022-11-21 0001628280-22-030473 — 5.02, 5.07, 9.01
- 2022-11-08 0001628280-22-028758 — 2.02, 9.01
- 2022-08-16 0001628280-22-022980 — 2.02, 9.01
- 2022-08-03 0001193125-22-210674 — 2.01, 8.01, 9.01
- 2022-07-29 0001193125-22-206587 — 8.01, 9.01
- 2022-05-04 0001628280-22-012145 — 2.02, 9.01
- 2022-03-08 0001193125-22-069350 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2022-02-03 0001628280-22-001736 — 2.02, 9.01
- 2022-01-21 0001193125-22-014413 — 8.01, 9.01
- 2021-11-23 0001628280-21-024070 — 5.02, 5.07
- 2021-11-05 0001193125-21-321796 — 1.01, 9.01
- 2021-11-04 0001628280-21-021618 — 2.02, 9.01
- 2021-11-04 0001193125-21-319601 — 8.01, 9.01
- 2021-08-18 0001628280-21-017219 — 2.02, 9.01
- 2021-06-08 0001633978-21-000030 — 5.02, 9.01
- 2021-05-12 0001633978-21-000008 — 2.02, 9.01
- 2021-03-10 0001193125-21-075438 — 1.01, 8.01, 9.01
- 2021-02-02 0001633978-21-000002 — 2.02, 9.01
- 2021-01-19 0001104659-21-005024 — 1.01, 2.02, 8.01, 9.01
- 2020-11-24 0001193125-20-302557 — 5.02, 5.07
- 2020-11-02 0001633978-20-000017 — 2.02, 9.01
- 2020-09-18 0001633978-20-000012 — 5.02, 9.01
- 2020-08-11 0001633978-20-000010 — 2.02, 9.01
- 2020-05-05 0001628280-20-006358 — 2.02, 9.01
- 2020-02-04 0001633978-20-000002 — 2.02, 9.01
- 2019-12-12 0001193125-19-312875 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2019-12-04 0001633978-19-000075 — 8.01
- 2019-11-20 0001633978-19-000074 — 5.07
- 2019-10-31 0001633978-19-000070 — 2.02, 9.01
- 2019-08-08 0001633978-19-000068 — 2.02, 9.01
- 2019-05-08 0001633978-19-000031 — 1.01
- 2019-05-07 0001633978-19-000029 — 2.02, 9.01
- 2019-02-15 0001633978-19-000005 — 9.01 — amendment of 0001193125-18-346211
- 2019-02-08 0001193125-19-031591 — 5.02, 9.01
- 2019-02-05 0001633978-19-000001 — 2.02, 9.01
- 2018-12-10 0001193125-18-346211 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-12-06 0001633978-18-000150 — 8.01
- 2018-11-14 0001633978-18-000139 — 5.07
- 2018-11-13 0001633978-18-000136 — 3.02
- 2018-11-13 0001633978-18-000132 — 7.01, 9.01
- 2018-11-01 0001628280-18-013238 — 2.02, 9.01
- 2018-08-08 0001633978-18-000056 — 2.02, 9.01
- 2018-06-08 0001193125-18-188241 — 5.02, 9.01
- 2018-05-02 0001633978-18-000029 — 2.02, 9.01
- 2018-03-12 0001193125-18-078154 — 1.01, 2.01, 8.01, 9.01
- 2018-02-06 0001628280-18-001082 — 2.02, 9.01
- 2017-11-08 0001633978-17-000133 — 5.02, 9.01
- 2017-11-07 0001633978-17-000131 — 5.07
- 2017-11-01 0001633978-17-000117 — 2.02, 9.01
- 2017-08-09 0001633978-17-000058 — 2.02, 9.01
- 2017-05-04 0001633978-17-000035 — 2.02, 9.01
- 2017-03-08 0001193125-17-074740 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2017-03-02 0001193125-17-066769 — 8.01, 9.01
- 2017-02-07 0001633978-17-000005 — 2.02, 9.01
- 2017-01-03 0001628280-17-000018 — 4.01, 9.01
- 2016-11-09 0001628280-16-021143 — 5.02, 5.07, 9.01
- 2016-10-27 0001628280-16-020382 — 2.02, 9.01
- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2023-11-08

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001628280-23-037563:8k_2_02:1]
EX-99.1
2
lite_ex991xq1fy24.htm
EX-99.1

[0001628280-23-037563:8k_2_02:2]
Document

[0001628280-23-037563:8k_2_02:3]
NEWS RELEASE

[0001628280-23-037563:8k_2_02:4]
LUMENTUM ANNOUNCES FISCAL FIRST QUARTER 2024 FINANCIAL RESULTS

[0001628280-23-037563:8k_2_02:5]
•Net revenue of $317.6 million

[0001628280-23-037563:8k_2_02:6]
•GAAP gross margin of 24.1%; Non-GAAP gross margin of 34.9%

[0001628280-23-037563:8k_2_02:7]
•GAAP operating loss of 25.4%; Non-GAAP operating margin of 3.3%

[0001628280-23-037563:8k_2_02:8]
•GAAP diluted net loss per share of $1.02; Non-GAAP diluted net income per share of $0.35

[0001628280-23-037563:8k_2_02:9]
San Jose, Calif., November 8, 2023 – Lumentum Holdings Inc. (“Lumentum” or the “Company”) today reported results for its fiscal first quarter ended September 30, 2023.

[0001628280-23-037563:8k_2_02:10]
“We are thrilled to welcome the talented Cloud Light team to Lumentum. In calendar 2024, we expect cloud applications will drive over 30 percent of our Cloud & Networking revenue, both within data centers and for data center interconnect. We anticipate year-over-year Cloud & Networking growth in calendar 2024, driven by accelerating AI compute requirements,” said Alan Lowe, President and CEO.

[0001628280-23-037563:8k_2_02:11]
“As we reported last week, first quarter revenue and EPS results were above the midpoints of our guidance, and we are maintaining tight cost controls. We are delivering as planned on our product roadmaps and synergy attainment.”

[0001628280-23-037563:8k_2_02:12]
Fiscal First Quarter Highlights:

[0001628280-23-037563:8k_2_02:13]
Net revenue for the fiscal first quarter of 2024 was $317.6 million, with GAAP net loss of $67.9 million, or $1.02 per diluted share. Net revenue for the fiscal fourth quarter of 2023 was $370.8 million, with GAAP net loss of $60.2 million, or $0.88 per diluted share. Net revenue for the fiscal first quarter of 2023 was $506.8 million, with GAAP net loss of $0.4 million, or $0.01 per diluted share.

[0001628280-23-037563:8k_2_02:14]
Non-GAAP net income for the fiscal first quarter of 2024 was $23.4 million, or $0.35 per diluted share. Non-GAAP net income for fiscal fourth quarter of 2023 was $40.2 million, or $0.59 per diluted share. Non-GAAP net income for the fiscal first quarter of 2023 was $119.2 million, or $1.69 per diluted share.

[0001628280-23-037563:8k_2_02:15]
The Company held $1,944.3 million in total cash, cash equivalents, and short-term investments at the end of the fiscal first quarter of 2024, down $69.3 million from the end of the fiscal fourth quarter of 2023.

[0001628280-23-037563:8k_2_02:16]
Prior to fiscal year 2024, we operated in two reportable segments consisting of Optical Communications (“OpComms”) and Commercial Lasers (“Lasers”). During the fiscal first quarter of 2024, we changed our organizational structure to better align with trends in our markets and our customer and product mix. Our new operating segments are Cloud & Networking and Industrial Tech. The Cloud & Networking segment includes the Telecom and Datacom product lines that were previously part of the OpComms segment. The Industrial Tech segment includes the previous Lasers segment and the Industrial & Consumer product lines that were previously part of the OpComms segment. Comparative prior period segment information has been recast to conform to the new segment structure and measures. The changes in our operating segments had no impact on our previously reported consolidated results of operations, financial condition, or cash flows.

[0001628280-23-037563:8k_2_02:17]
Financial Overview – Fiscal First Quarter Ended September 30, 2023

[0001628280-23-037563:8k_2_02:18]
|  | GAAP Results ($ in millions) |
|  | Q1 |  | Q4 |  | Q1 |  | Change |
|  | FY 2024 |  | FY 2023 |  | FY 2023 |  | Q/Q |  | Y/Y |
| Net revenue | $ | 317.6 |  |  | $ | 370.8 |  |  | $ | 506.8 |  |  | (14.3)% |  | (37.3)% |
| Gross margin | 24.1 | % |  | 24.2 | % |  | 39.7 | % |  | (10) | bps |  | (1,560) | bps |
| Operating margin (loss) | (25.4) | % |  | (15.1) | % |  | 2.7 | % |  | (1,030) | bps |  | (2,810) | bps |
|  | Non-GAAP Results ($ in millions) |
|  | Q1 |  | Q4 |  | Q1 |  | Change |
|  | FY 2024 |  | FY 2023 |  | FY 2023 |  | Q/Q |  | Y/Y |
| Net revenue | $ | 317.6 |  |  | $ | 370.8 |  |  | $ | 506.8 |  |  | (14.3)% |  | (37.3)% |
| Gross margin | 34.9 | % |  | 36.7 | % |  | 48.2 | % |  | (180) | bps |  | (1,330) | bps |
| Operating margin | 3.3 | % |  | 9.1 | % |  | 27.1 | % |  | (580) | bps |  | (2,380) | bps |

[0001628280-23-037563:8k_2_02:19]
|  | Net Revenue by Segment ($ in millions) |  |  |  |  |
|  | Q1 |  | % of |  | Q4 |  | Q1 |  | Change |  |  |  |  |
|  | FY 2024 |  | Net Revenue |  | FY 2023 (1) |  | FY 2023 (1) |  | Q/Q |  | Y/Y |  |  |  |  |
| Cloud & Networking | $ | 229.7 |  |  | 72.3 | % |  | $ | 286.5 |  |  | $ | 360.1 |  |  | (19.8)% |  | (36.2)% |  |  |  |  |
| Industrial Tech | 87.9 |  |  | 27.7 | % |  | 84.3 |  |  | 146.7 |  |  | 4.3% |  | (40.1)% |  |  |  |  |
| Total | $ | 317.6 |  |  | 100.0 | % |  | $ | 370.8 |  |  | $ | 506.8 |  |  | (14.3)% |  | (37.3)% |  |  |  |  |

[0001628280-23-037563:8k_2_02:20]
(1) Prior period amounts have been recast to conform to the new segment structure effective the fiscal first quarter of 2024.

[0001628280-23-037563:8k_2_02:21]
The tables above provide comparisons of quarterly results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled “Use of Non-GAAP Financial Measures.”

[0001628280-23-037563:8k_2_02:22]
Business Outlook

[0001628280-23-037563:8k_2_02:23]
Lumentum expects the following for the fiscal second quarter 2024:

[0001628280-23-037563:8k_2_02:24]
•Net revenue in the range of $350 million to $380 million

[0001628280-23-037563:8k_2_02:25]
•Non-GAAP operating margin of 2.0% to 4.0%

[0001628280-23-037563:8k_2_02:26]
•Non-GAAP diluted earnings per share of $0.25 to $0.35

[0001628280-23-037563:8k_2_02:27]
On November 7, 2023, we completed the acquisition of Cloud Light Technology Limited (“Cloud Light”). The forecast above includes projected financial results of Cloud Light after the acquisition date. We have not provided reconciliations from GAAP to non-GAAP measures or the equivalent GAAP measure for non-GAAP measures in our outlook, as they cannot be provided without unreasonable effort. A large portion of non-GAAP adjustments, such as restructuring charges, stock-based compensation, non-GAAP income tax reconciling adjustments, acquisition related costs, and other costs and contingencies unrelated to current and future operations are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future.

[0001628280-23-037563:8k_2_02:28]
Related Announcement and Conference Call

[0001628280-23-037563:8k_2_02:29]
Lumentum will host a conference call today, November 8, 2023, at 5:30 am PT / 8:30 am ET to discuss its fiscal first quarter results.  A live webcast of the call and the replay will be available in the Investors section of the Lumentum website at http://investor.lumentum.com through November 15, 2023, at 9:00 pm PT / 12:00 am ET. To listen to the live conference call, dial (888) 575-5163 or (416) 764-8620 and reference the passcode 73024681.To access the replay, dial (877) 674-7070 or (416) 764-8692 and reference the passcode 024681 #. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the “Events and Presentations” section concurrently with this earnings press release. Lumentum has used, and intends to continue to use, its Investor Relations website as means of disclosing material nonpublic information and for complying with its disclosure obligations under Regulation FD. This press release is being furnished as an exhibit to a Current Report on Form 8-K filed with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001628280-23-037563:8k_2_02:30]
About Lumentum

[0001628280-23-037563:8k_2_02:31]
Lumentum (NASDAQ: LITE) is a market-leading designer and manufacturer of innovative optical and photonic products enabling optical networking and laser applications worldwide. Lumentum optical components and subsystems are part of virtually every type of telecom, enterprise, and data center network. Lumentum lasers enable advanced manufacturing techniques and diverse applications including next-generation imaging and sensing capabilities. Lumentum is headquartered in San Jose, California with R&D, manufacturing, and sales offices worldwide. For more information, visit www.lumentum.com and follow Lumentum on LinkedIn, X (formerly known as Twitter), Facebook, Instagram and YouTube.

[0001628280-23-037563:8k_2_02:32]
Forward-Looking Statements

[0001628280-23-037563:8k_2_02:33]
Contact Information

[0001628280-23-037563:8k_2_02:34]
Investors:    Kathy Ta, (408) 750-3853; investor.relations@lumentum.com

[0001628280-23-037563:8k_2_02:35]
Media:        Caroline Pan, (650) 267-4180; media@lumentum.com

[0001628280-23-037563:8k_2_02:36]
Category:    Financial

[0001628280-23-037563:8k_2_02:37]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001628280-23-037563:8k_2_02:38]
LUMENTUM HOLDINGS INC.

[0001628280-23-037563:8k_2_02:39]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001628280-23-037563:8k_2_02:40]
(in millions, except per share data)

[0001628280-23-037563:8k_2_02:41]
(unaudited)

[0001628280-23-037563:8k_2_02:42]
|  | Three Months Ended |  |  |
|  | September 30, 2023 |  | October 1, 2022 |  |  |  |  |
| Net revenue | $ | 317.6 |  |  | $ | 506.8 |  |  |  |  |  |
| Cost of sales | 222.9 |  |  | 282.6 |  |  |  |  |  |
| Amortization of acquired developed intangibles | 18.0 |  |  | 23.0 |  |  |  |  |  |
| Gross profit | 76.7 |  |  | 201.2 |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 73.5 |  |  | 72.7 |  |  |  |  |  |
| Selling, general and administrative | 73.0 |  |  | 105.7 |  |  |  |  |  |
| Restructuring and related charges | 11.0 |  |  | 9.3 |  |  |  |  |  |
| Total operating expenses | 157.5 |  |  | 187.7 |  |  |  |  |  |
| Income (loss) from operations | (80.8) |  |  | 13.5 |  |  |  |  |  |
| Interest expense | (9.7) |  |  | (8.5) |  |  |  |  |  |
| Other income, net | 21.2 |  |  | 13.8 |  |  |  |  |  |
| Income (loss) before income taxes | (69.3) |  |  | 18.8 |  |  |  |  |  |
| Income tax provision (benefit) | (1.4) |  |  | 19.2 |  |  |  |  |  |
| Net loss | $ | (67.9) |  |  | $ | (0.4) |  |  |  |  |  |
| Net loss per share: |  |  |  |  |  |  |  |
| Basic | $ | (1.02) |  |  | $ | (0.01) |  |  |  |  |  |
| Diluted | $ | (1.02) |  |  | $ | (0.01) |  |  |  |  |  |
| Shares used to compute net loss per share: |  |  |  |  |  |  |  |
| Basic | 66.7 |  |  | 68.1 |  |  |  |  |  |
| Diluted | 66.7 |  |  | 68.1 |  |  |  |  |  |

[0001628280-23-037563:8k_2_02:43]
LUMENTUM HOLDINGS INC.

[0001628280-23-037563:8k_2_02:44]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-23-037563:8k_2_02:45]
(in millions, except per share data)

[0001628280-23-037563:8k_2_02:46]
(unaudited)

[0001628280-23-037563:8k_2_02:47]
|  | September 30, 2023 |  | July 1, 2023 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 861.6 |  |  | $ | 859.0 |  |
| Short-term investments | 1,082.7 |  |  | 1,154.6 |  |
| Accounts receivable, net | 220.0 |  |  | 246.1 |  |
| Inventories | 428.0 |  |  | 408.6 |  |
| Prepayments and other current assets | 99.4 |  |  | 109.6 |  |
| Total current assets | 2,691.7 |  |  | 2,777.9 |  |
| Property, plant and equipment, net | 511.6 |  |  | 489.5 |  |
| Operating lease right-of-use assets, net | 68.8 |  |  | 77.3 |  |
| Goodwill | 695.1 |  |  | 695.1 |  |
| Other intangible assets, net | 435.2 |  |  | 459.2 |  |
| Deferred tax asset | 128.0 |  |  | 116.3 |  |
| Other non-current assets | 14.6 |  |  | 16.8 |  |
| Total assets | $ | 4,545.0 |  |  | $ | 4,632.1 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 134.6 |  |  | $ | 169.4 |  |
| Accrued payroll and related expenses | 40.9 |  |  | 39.4 |  |
| Accrued expenses | 59.4 |  |  | 51.2 |  |
| Convertible notes, current | 315.7 |  |  | 311.6 |  |
| Operating lease liabilities, current | 11.8 |  |  | 14.4 |  |
| Other current liabilities | 31.3 |  |  | 47.8 |  |
| Total current liabilities | 593.7 |  |  | 633.8 |  |
| Convertible notes, non-current | 2,500.9 |  |  | 2,500.0 |  |
| Operating lease liabilities, non-current | 41.2 |  |  | 47.7 |  |
| Deferred tax liability | 12.7 |  |  | 3.4 |  |
| Other non-current liabilities | 85.7 |  |  | 91.4 |  |
| Total liabilities | 3,234.2 |  |  | 3,276.3 |  |
| Stockholders’ equity: |  |  |  |
| Common stock, $0.001 par value, 990 authorized shares, 67.0 and 66.4 shares issued and outstanding as of September 30, 2023 and July 1, 2023, respectively | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital | 1,714.0 |  |  | 1,692.2 |  |
| Accumulated deficit | (408.5) |  |  | (340.6) |  |
| Accumulated other comprehensive income | 5.2 |  |  | 4.1 |  |
| Total stockholders’ equity | 1,310.8 |  |  | 1,355.8 |  |
| Total liabilities and stockholders’ equity | $ | 4,545.0 |  |  | $ | 4,632.1 |  |

[0001628280-23-037563:8k_2_02:48]
Use of Non-GAAP Financial Measures

[0001628280-23-037563:8k_2_02:49]
In this press release, Lumentum provides investors with certain non-GAAP financial measures: gross profit, gross margin, research and development expense, selling, general and administrative expense, operating margin, income from operations, interest and other income (expense), net, income before income taxes, provision for income taxes, net income (loss), and net income (loss) per share on a non-GAAP basis, as well as the non-GAAP measures of EBITDA and Adjusted EBITDA. Lumentum believes this non-GAAP financial information provides additional insight into the Company’s on-going business operations and results, as well as cash generation, and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons. In addition, the Company believes that providing certain of these measures allows investors to better understand the Company’s operating performance and cash flows and, importantly, to evaluate the methodology and information used by management to monitor, manage, evaluate and measure the Company’s business, results of operations, and cash flows. However, these measures may be different from non-GAAP measures used by other companies, limiting their usefulness for comparison purposes. The non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP. Investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future. Further, these non-GAAP financial measures may not be comparable to similarly titled measurements reported by other companies.

[0001628280-23-037563:8k_2_02:50]
Our non-GAAP measures used in this press release exclude (i) stock-based compensation, (ii) acquisition related stock-based compensation, (iii) acquisition related costs, (iv) amortization of acquired intangibles, (v) amortization of acquired inventory fair value adjustments, (vi) restructuring and related charges, (vii) foreign exchange (gains) losses, net, (viii) non-cash interest expense on convertible notes, (ix) gain on repurchase of convertible notes, (x) non-recurring expenses related to litigation matters, (xi) intangible assets write-off, (xii) integration related costs, (xiii) non-GAAP income tax reconciling adjustments, and (xiv) other (gains) charges related to non-recurring activities.

[0001628280-23-037563:8k_2_02:51]
A quantitative reconciliation between GAAP and non-GAAP financial data with respect to historical periods is included in the supplemental financial table attached to this press release.

[0001628280-23-037563:8k_2_02:52]
LUMENTUM HOLDINGS INC.

[0001628280-23-037563:8k_2_02:53]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001628280-23-037563:8k_2_02:54]
(in millions, except per share data)

[0001628280-23-037563:8k_2_02:55]
(unaudited)

[0001628280-23-037563:8k_2_02:56]
|  | Three Months Ended |  |  |  |
|  | September 30, 2023 |  | July 1, 2023 |  | October 1, 2022 |  |  |  |  |  |
| Gross profit on GAAP basis | $ | 76.7 |  |  | $ | 89.6 |  |  | $ | 201.2 |  |  |  |  |  |  |
| Stock-based compensation | 6.0 |  |  | 11.0 |  |  | 5.5 |  |  |  |  |  |  |
| Amortization of acquired intangibles | 18.0 |  |  | 18.0 |  |  | 22.9 |  |  |  |  |  |  |
| Amortization of acquired inventory fair value adjustments | — |  |  | — |  |  | 4.6 |  |  |  |  |  |  |
| Integration related costs | 6.8 |  |  | 2.6 |  |  | — |  |  |  |  |  |  |
| Intangible asset write-off | — |  |  | 6.8 |  |  | — |  |  |  |  |  |  |
| Other charges, net (1) | 3.2 |  |  | 8.1 |  |  | 9.9 |  |  |  |  |  |  |
| Gross profit on non-GAAP basis | $ | 110.7 |  |  | $ | 136.1 |  |  | $ | 244.1 |  |  |  |  |  |  |
| Gross margin on non-GAAP basis | 34.9 | % |  | 36.7 | % |  | 48.2 | % |  |  |  |  |  |
| Research and development on GAAP basis | $ | 73.5 |  |  | $ | 73.9 |  |  | $ | 72.7 |  |  |  |  |  |  |
| Stock-based compensation | (10.3) |  |  | (10.2) |  |  | (9.6) |  |  |  |  |  |  |
| Amortization of acquired intangibles | (0.3) |  |  | — |  |  | — |  |  |  |  |  |  |
| Acquisition related costs | (0.3) |  |  | — |  |  | — |  |  |  |  |  |  |
| Integration related costs | (0.9) |  |  | (0.6) |  |  | — |  |  |  |  |  |  |
| Intangible asset write-off | — |  |  | (1.4) |  |  | — |  |  |  |  |  |  |
| Other charges, net | (0.7) |  |  | — |  |  | (2.3) |  |  |  |  |  |  |
| Research and development on non-GAAP basis | $ | 61.0 |  |  | $ | 61.7 |  |  | $ | 60.8 |  |  |  |  |  |  |
| Selling, general and administrative on GAAP basis | $ | 73.0 |  |  | $ | 68.3 |  |  | $ | 105.7 |  |  |  |  |  |  |
| Stock-based compensation | (15.8) |  |  | (10.9) |  |  | (19.6) |  |  |  |  |  |  |
| Stock-based compensation - acquisition related | — |  |  | — |  |  | (11.9) |  |  |  |  |  |  |
| Amortization of acquired intangibles | (10.7) |  |  | (11.4) |  |  | (9.3) |  |  |  |  |  |  |
| Acquisition related (costs) reversal | (3.7) |  |  | 4.7 |  |  | (16.2) |  |  |  |  |  |  |
| Integration related costs | (3.6) |  |  | (6.2) |  |  | (0.6) |  |  |  |  |  |  |
| Intangible asset write-off | — |  |  | (1.6) |  |  | — |  |  |  |  |  |  |
| Other charges, net | (0.1) |  |  | (2.2) |  |  | (2.2) |  |  |  |  |  |  |
| Selling, general and administrative on non-GAAP basis | $ | 39.1 |  |  | $ | 40.7 |  |  | $ | 45.9 |  |  |  |  |  |  |
| Income (Loss) from operations on GAAP basis | $ | (80.8) |  |  | $ | (55.9) |  |  | $ | 13.5 |  |  |  |  |  |  |
| Stock-based compensation | 32.1 |  |  | 32.1 |  |  | 34.7 |  |  |  |  |  |  |
| Stock-based compensation - acquisition related | — |  |  | — |  |  | 11.9 |  |  |  |  |  |  |
| Amortization of acquired intangibles | 29.0 |  |  | 29.4 |  |  | 32.2 |  |  |  |  |  |  |
| Amortization of acquired inventory fair value adjustments | — |  |  | — |  |  | 4.6 |  |  |  |  |  |  |
| Acquisition related costs (reversal) | 4.0 |  |  | (4.7) |  |  | 16.2 |  |  |  |  |  |  |
| Integration related costs | 11.3 |  |  | 9.4 |  |  | 0.6 |  |  |  |  |  |  |
| Restructuring and related charges (2) | 11.0 |  |  | 3.3 |  |  | 9.3 |  |  |  |  |  |  |
| Intangible asset write-off | — |  |  | 9.8 |  |  | — |  |  |  |  |  |  |
| Other charges, net (1) | 4.0 |  |  | 10.3 |  |  | 14.4 |  |  |  |  |  |  |
| Income from operations on non-GAAP basis | $ | 10.6 |  |  | $ | 33.7 |  |  | $ | 137.4 |  |  |  |  |  |  |
| Operating margin on non-GAAP basis | 3.3 | % |  | 9.1 | % |  | 27.1 | % |  |  |  |  |  |
| Interest and other income, net on GAAP basis | $ | 11.5 |  |  | $ | 10.5 |  |  | $ | 5.3 |  |  |  |  |  |  |

[0001628280-23-037563:8k_2_02:57]
| Gain on repurchase of convertible notes | — |  |  | (1.0) |  |  | — |  |  |  |  |  |  |
| Foreign exchange (gains) losses, net | 0.4 |  |  | (2.6) |  |  | (9.0) |  |  |  |  |  |  |
| Non-cash interest expense on convertible notes and other expenses | 4.9 |  |  | 6.4 |  |  | 5.7 |  |  |  |  |  |  |
| Interest and other income, net on non-GAAP basis | $ | 16.8 |  |  | $ | 13.3 |  |  | $ | 2.0 |  |  |  |  |  |  |
| Income (Loss) before income taxes on GAAP basis | $ | (69.3) |  |  | $ | (45.4) |  |  | $ | 18.8 |  |  |  |  |  |  |
| Stock-based compensation | 32.1 |  |  | 32.1 |  |  | 34.7 |  |  |  |  |  |  |
| Stock-based compensation - acquisition related | — |  |  | — |  |  | 11.9 |  |  |  |  |  |  |
| Acquisition related costs (reversal) | 4.0 |  |  | (4.7) |  |  | 16.2 |  |  |  |  |  |  |
| Integration related costs | 11.3 |  |  | 9.4 |  |  | 0.6 |  |  |  |  |  |  |
| Amortization of acquired intangibles | 29.0 |  |  | 29.4 |  |  | 32.2 |  |  |  |  |  |  |
| Amortization of acquired inventory fair value adjustments | — |  |  | — |  |  | 4.6 |  |  |  |  |  |  |
| Restructuring and related charges (2) | 11.0 |  |  | 3.3 |  |  | 9.3 |  |  |  |  |  |  |
| Intangible asset write-off | — |  |  | 9.8 |  |  | — |  |  |  |  |  |  |
| Foreign exchange (gains) losses, net | 0.4 |  |  | (2.6) |  |  | (9.0) |  |  |  |  |  |  |
| Non-cash interest expense on convertible notes and other expenses | 4.9 |  |  | 6.4 |  |  | 5.7 |  |  |  |  |  |  |
| Gain on repurchase of convertible notes | — |  |  | (1.0) |  |  | — |  |  |  |  |  |  |
| Other charges, net (1) | 4.0 |  |  | 10.3 |  |  | 14.4 |  |  |  |  |  |  |
| Income before income taxes on non-GAAP basis | $ | 27.4 |  |  | $ | 47.0 |  |  | $ | 139.4 |  |  |  |  |  |  |
| Income tax provision (benefit) on GAAP basis | $ | (1.4) |  |  | $ | 14.8 |  |  | $ | 19.2 |  |  |  |  |  |  |
| Non-GAAP income tax reconciling adjustments | 5.4 |  |  | (8.0) |  |  | 1.0 |  |  |  |  |  |  |
| Income tax provision on non-GAAP basis | $ | 4.0 |  |  | $ | 6.8 |  |  | $ | 20.2 |  |  |  |  |  |  |
| Net loss on GAAP basis | $ | (67.9) |  |  | $ | (60.2) |  |  | $ | (0.4) |  |  |  |  |  |  |
| Stock-based compensation | 32.1 |  |  | 32.1 |  |  | 34.7 |  |  |  |  |  |  |
| Stock-based compensation - acquisition related | — |  |  | — |  |  | 11.9 |  |  |  |  |  |  |
| Acquisition related costs (reversal) | 4.0 |  |  | (4.7) |  |  | 16.2 |  |  |  |  |  |  |
| Integration related costs | 11.3 |  |  | 9.4 |  |  | 0.6 |  |  |  |  |  |  |
| Amortization of acquired intangibles | 29.0 |  |  | 29.4 |  |  | 32.2 |  |  |  |  |  |  |
| Amortization of acquired inventory fair value adjustments | — |  |  | — |  |  | 4.6 |  |  |  |  |  |  |
| Restructuring and related charges (2) | 11.0 |  |  | 3.3 |  |  | 9.3 |  |  |  |  |  |  |
| Intangible asset write-off | — |  |  | 9.8 |  |  | — |  |  |  |  |  |  |
| Foreign exchange (gains) losses, net | 0.4 |  |  | (2.6) |  |  | (9.0) |  |  |  |  |  |  |
| Gain on repurchase of convertible notes | — |  |  | (1.0) |  |  | — |  |  |  |  |  |  |
| Non-cash interest expense on convertible notes and other expenses | 4.9 |  |  | 6.4 |  |  | 5.7 |  |  |  |  |  |  |
| Non-GAAP income tax reconciling adjustments | (5.4) |  |  | 8.0 |  |  | (1.0) |  |  |  |  |  |  |
| Other charges, net (1) | 4.0 |  |  | 10.3 |  |  | 14.4 |  |  |  |  |  |  |
| Net income on non-GAAP basis | $ | 23.4 |  |  | $ | 40.2 |  |  | $ | 119.2 |  |  |  |  |  |  |
| Net income per share on non-GAAP basis | $ | 0.35 |  |  | $ | 0.59 |  |  | $ | 1.69 |  |  |  |  |  |  |
| Shares used in per share calculation - diluted on GAAP basis | 66.7 |  |  | 68.3 |  |  | 68.1 |  |  |  |  |  |  |
| Non-GAAP adjustment (3) | 0.3 |  |  | 0.3 |  |  | 2.5 |  |  |  |  |  |  |
| Shares used in per share calculation - diluted on non-GAAP basis | 67.0 |  |  | 68.6 |  |  | 70.6 |  |  |  |  |  |  |

[0001628280-23-037563:8k_2_02:58]
(1) Other gains (charges) excluded in deriving non-GAAP gross profit for the three months ended September 30, 2023 primarily relate to $2.9 million of incremental costs of sales related to components acquired prior to fiscal 2024 from various brokers to satisfy customer demand.

[0001628280-23-037563:8k_2_02:59]
(2) During the three months ended September 30, 2023, we recorded restructuring and related charges of $11.0 million in our condensed consolidated statements of operations, which was primarily due to company-wide cost reduction initiatives, as well as our integration efforts as a result of the merger with NeoPhotonics.

[0001628280-23-037563:8k_2_02:60]
(3) Shares used for net income per share on non-GAAP basis include incremental dilutive shares that would occur upon conversion of our convertible notes assuming we settle the face value of the notes in cash as the Company intends, and shares related to restricted stock units (“RSUs”) and shares issuable under our Employee Stock Purchase Plan that are anti-dilutive on GAAP basis.

[0001628280-23-037563:8k_2_02:61]
LUMENTUM HOLDINGS INC.

[0001628280-23-037563:8k_2_02:62]
RECONCILIATION OF GAAP NET INCOME TO ADJUSTED EBITDA

[0001628280-23-037563:8k_2_02:63]
(in millions, except per share data)

[0001628280-23-037563:8k_2_02:64]
(unaudited)

[0001628280-23-037563:8k_2_02:65]
|  | Three Months Ended |  |  |  |  |
|  | September 30, 2023 |  |  |  | July 1, 2023 |  | October 1, 2022 |  |  |  |  |  |  |  |  |
| GAAP net loss | $ | (67.9) |  |  |  |  | $ | (60.2) |  |  | $ | (0.4) |  |  |  |  |  |  |  |  |  |
| Interest and other expense, net | (11.5) |  |  |  |  | (10.5) |  |  | (5.3) |  |  |  |  |  |  |  |  |  |
| Income tax provision (benefit) | (1.4) |  |  |  |  | 14.8 |  |  | 19.2 |  |  |  |  |  |  |  |  |  |
| Depreciation | 28.2 |  |  |  |  | 28.0 |  |  | 24.5 |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangibles | 29.0 |  |  |  |  | 29.4 |  |  | 32.2 |  |  |  |  |  |  |  |  |  |
| EBITDA | (23.6) |  |  |  |  | 1.5 |  |  | 70.2 |  |  |  |  |  |  |  |  |  |
| Amortization of inventory fair value adjustments | — |  |  |  |  | — |  |  | 4.6 |  |  |  |  |  |  |  |  |  |
| Restructuring and related charges | 11.0 |  |  |  |  | 3.3 |  |  | 9.3 |  |  |  |  |  |  |  |  |  |
| Stock-based compensation | 32.1 |  |  |  |  | 32.1 |  |  | 46.6 |  |  |  |  |  |  |  |  |  |
| Acquisition related costs (reversal) | 4.0 |  |  |  |  | (4.7) |  |  | 16.2 |  |  |  |  |  |  |  |  |  |
| Integration related costs | 11.3 |  |  |  |  | 9.4 |  |  | 0.6 |  |  |  |  |  |  |  |  |  |
| Intangible asset write-off | — |  |  |  |  | 9.8 |  |  | — |  |  |  |  |  |  |  |  |  |
| Other charges (gains), net | (0.2) |  |  |  |  | 8.0 |  |  | 14.4 |  |  |  |  |  |  |  |  |  |
| Adjusted EBITDA | $ | 34.6 |  |  |  |  | $ | 59.4 |  |  | $ | 161.9 |  |  |  |  |  |  |  |  |  |

[0001628280-23-037563:8k_2_02:66]
LUMENTUM HOLDINGS INC.

[0001628280-23-037563:8k_2_02:67]
RECAST AND RECONCILIATION OF HISTORICAL SEGMENT MEASURES

[0001628280-23-037563:8k_2_02:68]
(in millions)

[0001628280-23-037563:8k_2_02:69]
(unaudited)

[0001628280-23-037563:8k_2_02:70]
|  | Three Months Ended |  | Twelve Months Ended |  |  |  |  |
|  | July 1, 2023 |  |  |  | April 1, 2023 |  | December 31, 2022 |  | October 1, 2022 |  | July 1, 2023 |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cloud & Networking | $ | 286.5 |  |  |  |  | $ | 293.0 |  |  | $ | 382.9 |  |  | $ | 360.1 |  |  | $ | 1,322.5 |  |  |  |  |  |  |  |  |  |  |  |
| Industrial Tech | 84.3 |  |  |  |  | 90.4 |  |  | 123.1 |  |  | 146.7 |  |  | 444.5 |  |  |  |  |  |  |  |  |  |  |  |
| Consolidated net revenue | $ | 370.8 |  |  |  |  | $ | 383.4 |  |  | $ | 506.0 |  |  | $ | 506.8 |  |  | $ | 1,767.0 |  |  |  |  |  |  |  |  |  |  |  |
| Segment Profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cloud & Networking | $ | 50.6 |  |  |  |  | $ | 61.0 |  |  | $ | 99.9 |  |  | $ | 101.7 |  |  | $ | 313.2 |  |  |  |  |  |  |  |  |  |  |  |
| Industrial Tech | 12.1 |  |  |  |  | 22.1 |  |  | 49.7 |  |  | 68.8 |  |  | 152.7 |  |  |  |  |  |  |  |  |  |  |  |
| Total segment profit | 62.7 |  |  |  |  | 83.1 |  |  | 149.6 |  |  | 170.5 |  |  | 465.9 |  |  |  |  |  |  |  |  |  |  |  |
| Unallocated selling, general and administrative (1) | (29.0) |  |  |  |  | (31.7) |  |  | (32.9) |  |  | (33.1) |  |  | (126.7) |  |  |  |  |  |  |  |  |  |  |  |
| Consolidated income from operations on non-GAAP basis | $ | 33.7 |  |  |  |  | $ | 51.4 |  |  | $ | 116.7 |  |  | $ | 137.4 |  |  | $ | 339.2 |  |  |  |  |  |  |  |  |  |  |  |
| Consolidated income (loss) from operations on GAAP basis | $ | (55.9) |  |  |  |  | $ | (51.4) |  |  | $ | (21.9) |  |  | $ | 13.5 |  |  | $ | (115.7) |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation | 32.1 |  |  |  |  | 33.1 |  |  | 36.6 |  |  | 34.7 |  |  | 136.5 |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation-acquisition related | — |  |  |  |  | — |  |  | — |  |  | 11.9 |  |  | 11.9 |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangibles | 29.4 |  |  |  |  | 30.0 |  |  | 36.1 |  |  | 32.2 |  |  | 127.7 |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired inventory fair value adjustments | — |  |  |  |  | 3.6 |  |  | 9.6 |  |  | 4.6 |  |  | 17.8 |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition related costs (reversal) | (4.7) |  |  |  |  | — |  |  | — |  |  | 16.2 |  |  | 11.5 |  |  |  |  |  |  |  |  |  |  |  |
| Integration related costs | 9.4 |  |  |  |  | 10.6 |  |  | 8.0 |  |  | 0.6 |  |  | 28.6 |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring and related charges | 3.3 |  |  |  | 1.6 |  | 13.9 |  | 9.3 |  | 28.1 |  |  |  |  |  |  |  |  |  |  |
| Litigation matters | — |  |  |  |  | — |  |  | 7.8 |  | — |  |  | 7.8 |  |  |  |  |  |  |  |  |  |  |
| Intangible asset write-off | 9.8 |  |  |  | 11.5 |  | — |  |  | — |  |  | 21.3 |  |  |  |  |  |  |  |  |  |  |
| Other charges, net | 10.3 |  |  |  |  | 12.4 |  |  | 26.6 |  |  | 14.4 |  |  | 63.7 |  |  |  |  |  |  |  |  |  |  |  |
| Consolidated income from operations on non-GAAP basis | $ | 33.7 |  |  |  |  | $ | 51.4 |  |  | $ | 116.7 |  |  | $ | 137.4 |  |  | $ | 339.2 |  |  |  |  |  |  |  |  |  |  |  |

[0001628280-23-037563:8k_2_02:71]
(1) We do not allocate selling, general and administrative expenses that are not directly attributable to our operating segments.
