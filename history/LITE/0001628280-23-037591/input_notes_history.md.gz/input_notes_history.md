# LITE note change history — 0001628280-23-016653 → 0001628280-23-037591


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-11-08):
[0001628280-23-037591:note_history:1]
Our purchase obligations of $395.0 million as of September 30, 2023  represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.
  (was, 2023-05-09, similarity 0.6517):
[0001628280-23-016653:note_history:1]
Our purchase obligations of $379.2 million as of April 1, 2023 represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet our operational requirements. In addition, we assumed certain purchase orders in connection with our merger with NeoPhotonics for the purchase of inventory and other items in the ordinary course of its business.  Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule, and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

- changed (2023-11-08):
[0001628280-23-037591:note_history:2]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with these vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.
  (was, 2023-05-09, similarity 0.9949):
[0001628280-23-016653:note_history:2]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with such vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

- changed (2023-11-08):
[0001628280-23-037591:note_history:3]
|  | Three Months Ended |  |  |
|  | September 30, 2023 |  | October 1, 2022 |  |  |  |  |
| Balance as of beginning of period | $ | 6.8 |  |  | $ | 10.0 |  |  |  |  |  |
| Warranties assumed in NeoPhotonics merger | — |  |  | 0.7 |  |  |  |  |  |
| Provision for warranty | 0.2 |  |  | 1.5 |  |  |  |  |  |
| Utilization of reserve | (1.5) |  |  | (2.1) |  |  |  |  |  |
| Balance as of end of period | $ | 5.5 |  |  | $ | 10.1 |  |  |  |  |  |
  (was, 2023-05-09, similarity 0.7081):
[0001628280-23-016653:note_history:3]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2023 |  | April 2, 2022 |  | April 1, 2023 |  | April 2, 2022 |
| Balance as of beginning of period | $ | 8.4 |  |  | $ | 8.6 |  |  | $ | 10.0 |  |  | $ | 5.0 |  |
| Warranties assumed in NeoPhotonics merger | — |  |  | — |  |  | 0.7 |  |  | — |  |
| Provision for warranty | 1.1 |  |  | 1.5 |  |  | 5.4 |  |  | 7.0 |  |
| Utilization of reserve | (2.7) |  |  | (1.0) |  |  | (9.3) |  |  | (2.9) |  |
| Balance as of end of period | $ | 6.8 |  |  | $ | 9.1 |  |  | $ | 6.8 |  |  | $ | 9.1 |  |

- changed (2023-11-08):
[0001628280-23-037591:note_history:4]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss. During the year ended July 1, 2023, we recorded $7.8 million with respect to the pending settlement of certain non-ordinary course litigation matters under accrued expenses in our consolidated balance sheet, which has not been settled as of September 30, 2023.
  (was, 2023-05-09, similarity 0.9394):
[0001628280-23-016653:note_history:4]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss.  We have recorded $7.8 million with respect to the pending settlement of certain non-ordinary course litigation matters under accrued expenses in our condensed consolidated balance sheet as of April 1, 2023.

- changed (2023-11-08):
[0001628280-23-037591:note_history:5]
On August 16, 2022, the lead plaintiff moved for class certification and to be appointed class representative. Defendants opposed the motion. The action subsequently was stayed while the parties participated in a mediation. On January 18, 2023, the lead plaintiff filed a Notice of Settlement informing the court of an agreement in principle between the parties for a class-wide settlement of the Karri Lawsuit. On January 24, 2023, in light of the potential settlement, the court vacated all pretrial and trial dates and ordered the lead plaintiff to file a motion for preliminary approval of the settlement by March 17, 2023. The lead plaintiff filed his motion for preliminary approval of the settlement on March 16, 2023, and defendants filed a statement of non-opposition on March 30, 2023. On April 20, 2023, the court held a hearing on lead plaintiff’s motion for preliminary approval of the settlement. The court declined to grant lead plaintiff’s motion for preliminary approval and ordered lead plaintiff to file a revised motion by May 22, 2023. Lead plaintiff filed his Revised Motion for Preliminary Approval of Settlement (the “Amended Motion”) on May 22, 2023, defendants filed a response in support of the Amended Motion on June 5, 2023, and the lead plaintiff submitted his reply on June 12, 2023. The hearing on the Amended Motion took place on August 17, 2023 and the court preliminarily approved the settlement. In the event that the settlement does not go forward for any reason, the defendants intend to continue to defend the Karri Lawsuit vigorously.
  (was, 2023-05-09, similarity 0.7638):
[0001628280-23-016653:note_history:5]
On August 16, 2022, the lead plaintiff moved for class certification and to be appointed class representative. Defendants opposed the motion. The action subsequently was stayed while the parties participated in a mediation. On January 18, 2023, the lead plaintiff filed a Notice of Settlement informing the court of an agreement in principle between the parties for a class-wide settlement of the Karri Lawsuit. On January 24, 2023, in light of the potential settlement, the court vacated all pretrial and trial dates and ordered the lead plaintiff to file a motion for preliminary approval of the settlement by March 17, 2023. The lead plaintiff filed his motion for preliminary approval of the settlement on March 16, 2023, and defendants filed a statement of non-opposition on March 30, 2023.  On April 20, 2023, the court held a hearing on lead plaintiff’s motion for preliminary approval of the settlement.  The court declined to grant lead plaintiff’s motion for preliminary approval and ordered lead plaintiff to file a revised motion by May 22, 2023.  In the event that the settlement does not go forward for any reason, the defendants intend to continue to defend the Karri Lawsuit vigorously.

- changed (2023-11-08):
[0001628280-23-037591:note_history:6]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown, because claims may be made against us in the future, and we may record charges in the future as a result of these indemnification obligations. As of September 30, 2023, we did not have any material indemnification claims that were probable or reasonably possible.
  (was, 2023-05-09, similarity 0.9835):
[0001628280-23-016653:note_history:6]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown, because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of April 1, 2023, we did not have any material indemnification claims that were probable or reasonably possible.

- removed (2023-11-08):
[0001628280-23-016653:note_history:7]
NeoPhotonics Merger Litigation

- removed (2023-11-08):
[0001628280-23-016653:note_history:8]
In connection with our acquisition of NeoPhotonics Corporation (“NeoPhotonics”) announced in November 2021, ten lawsuits (the “NeoPhotonics Lawsuits”) were filed by purported stockholders of NeoPhotonics challenging the proposed merger (the “NeoPhotonics Merger”). All of the NeoPhotonics Lawsuits have been dismissed.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2023-11-08):
[0001628280-23-037591:note_history:9]
Lumentum Holdings Inc. (“we,” “us,” “our,” “Lumentum” or the “Company”) is an industry-leading provider of optical and photonic products addressing a range of end market applications for manufacturing, inspection, and life-science applications.

- added (2023-11-08):
[0001628280-23-037591:note_history:10]
Our Cloud and Networking products include a wide range of components, modules, and subsystems to support customers including carrier networks for access (local), metro (intracity), long-haul (city-to-city and worldwide) and submarine (undersea) applications. Our  products also address enterprise, cloud, and data center applications, including storage-access networks (“SANs”), local-area networks (“LANs”) and wide-area networks (“WANs”), as well as artificial intelligence and machine learning (“AI/ML”).

- added (2023-11-08):
[0001628280-23-037591:note_history:11]
Our Industrial Tech products include diode laser products such as VCSELs and edge emitting lasers. In the consumer end-market, our laser light sources are integrated into 3D sensing cameras which are used in applications in mobile devices, gaming, payment kiosks, computers, and other consumer electronics devices. Applications include biometric identification, computational photography, virtual and augmented reality, and natural user interfaces, among others. In the industrial end-market, our diode lasers are used primarily as pump sources for pulsed and kilowatt class fiber lasers. Our products also include laser products used in a variety of OEM applications including diode-pumped solid-state, fiber, diode, direct-diode and gas lasers such as argon-ion and helium-neon lasers.

- added (2023-11-08):
[0001628280-23-037591:note_history:12]
Prior to fiscal year 2024, we operated in two reportable segments consisting of Optical Communications (“OpComms”) and Commercial Lasers (“Lasers”). During the fiscal first quarter of 2024, we changed our organizational structure to better align with trends in our markets and our customer and product mix. Our new operating segments are Cloud & Networking and Industrial Tech. The Cloud & Networking segment includes the Telecom and Datacom product lines that were previously part of the OpComms segment. The Industrial Tech segment includes the previous Lasers segment and the Industrial & Consumer product lines that were previously part of the OpComms segment. Comparative prior period segment information has been recast to conform to the new segment structure and measures. The changes in our operating segments had no impact on our previously reported consolidated results of operations, financial condition, or cash flows. Refer to “Note 15. Operating Segments and Geographic Information”.

- changed (2023-11-08):
[0001628280-23-037591:note_history:13]
Our business and operating results depend significantly on general market and economic conditions. The current global macroeconomic environment is volatile and continues to be adversely impacted by inflation, a dynamic supply chain and demand environment, and signs of a weaker macroeconomic environment impacting capital expenditures across our served markets. Additionally, instability in the global credit markets, capital expenditure reductions, unemployment and other labor issues, decline in stock markets, the instability in the geopolitical environment in many parts of the world, and the current global economic challenges continue to put pressure on our business and operating results.
  (was, 2023-05-09, similarity 0.9475):
[0001628280-23-016653:note_history:13]
Our business and operating results depend significantly on general market and economic conditions. The current global macroeconomic environment is volatile and continues to be adversely impacted by inflation, and a dynamic supply chain and demand environment, and signs of a weaker macroeconomic environment impacting capital expenditures across our served markets. Additionally, instability in the global credit markets, the impact of uncertainty regarding global central bank monetary policy, capital expenditure reductions, unemployment and other labor issues, decline in stock markets, the instability in the geopolitical environment in many parts of the world, and the current global economic challenges continue to put pressure on our business and operating results.

- added (2023-11-08):
[0001628280-23-037591:note_history:14]
We are continuously monitoring both the current developments in the ongoing war between Russia and Ukraine including the related additional export controls and resulting sanctions imposed on Russia and Belarus by the U.S. and other countries, and the recent war between Israel and Hamas. Additional factors, such as increased inflation, escalating energy costs, constrained raw material availability and the related cost increases, could continue to impact the global economy and our business. Although the global implications of the wars are difficult to predict at this time, we do not presently foresee direct material adverse effects on our business.

- added (2023-11-08):
[0001628280-23-037591:note_history:15]
On August 3, 2022, we completed a merger with NeoPhotonics Corporation (“NeoPhotonics”). On August 15, 2022, we completed a transaction to acquire IPG Photonics’ telecom transmission product lines. We have applied the acquisition method of accounting in accordance with ASC Topic 805, Business Combinations to account for both of the transactions. Refer to “Note 4. Business Combinations”.

- changed (2023-11-08):
[0001628280-23-037591:note_history:16]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2024 is a 52-week year ending on June 29, 2024, with the quarter ended September 30, 2023 being a 13-week quarterly period. Our fiscal 2023 was a 52-week year that ended on July 1, 2023, with the quarter ended October 1, 2022 being a 13-week quarterly period.
  (was, 2023-05-09, similarity 0.6791):
[0001628280-23-016653:note_history:16]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2023 is a 52-week year ending on July 1, 2023, with the quarter ended April 1, 2023 being a 13-week quarterly period. Our fiscal 2022 was a 52-week year that ended on July 2, 2022, with the quarter ended April 2, 2022 being a 13-week quarterly period.

- changed (2023-11-08):
[0001628280-23-037591:note_history:17]
The condensed consolidated financial statements include the accounts of Lumentum Holdings Inc. and its wholly owned subsidiaries. All inter-company transactions and balances are eliminated in consolidation.
  (was, 2023-05-09, similarity 0.9951):
[0001628280-23-016653:note_history:17]
The condensed consolidated financial statements include the accounts of Lumentum Holdings Inc. and its wholly-owned subsidiaries. All inter-company transactions and balances are eliminated in consolidation.

- added (2023-11-08):
[0001628280-23-037591:note_history:18]
Accounting Policies
The condensed consolidated financial statements and accompanying notes should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the fiscal year ended July 1, 2023. There were no significant changes to our accounting policies during the three months ended September 30, 2023.

- removed (2023-11-08):
[0001628280-23-016653:note_history:19]
Lumentum Holdings Inc. (“we,” “us,” “our”, “Lumentum” or the “Company”) is an industry-leading provider of optical and photonic products addressing a range of end market applications including Optical Communications (“OpComms”) and Commercial Lasers (“Lasers”) for manufacturing, inspection, and life-science applications. We seek to use our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including imaging and sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers have historically been, and are currently, original equipment manufacturers (“OEMs”) that incorporate our products into their products, which then address end-market applications. For example, we sell fiber optic components that network equipment manufacturers (“NEMs”) assemble into communications networking systems, which they sell to communications service providers, hyperscale cloud operators, and enterprises with their own networks. Similarly, many of our Lasers products customers incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For imaging and sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, gaming, and other applications, including to the automotive industry, who then integrate our devices within their products, for eventual resale to consumers and also into other industrial applications.

- removed (2023-11-08):
[0001628280-23-016653:note_history:20]
While the impact of the COVID-19 pandemic is lessening, the duration and severity of the impact of the pandemic on our business and results of operations in future periods remain uncertain. The extent of the impact of COVID-19 on our operational and financial performance will depend on certain developments, including but not limited to the duration and spread of the pandemic and its variants in geographies where we do business, implementation and duration of local, state and federal issued public health orders in each jurisdiction where we operate or our customers and suppliers operate, impact on our customers and our sales cycles, impact on our supply chain and manufacturing partners, impact on our employees, and impact on regional and worldwide economies and financial markets in general, all of which are uncertain and not predictable. We assessed the potential impact that this pandemic has on our estimates as of April 1, 2023 and determined that there were no material impacts. However, due to the global supply chain constraint, we have had to incur incremental supply and procurement costs in order to fulfill demand from our customers.  As of April 1, 2023, our inventory balance includes $10.8 million of incremental supply and procurement costs.

- removed (2023-11-08):
[0001628280-23-016653:note_history:21]
We are also continuously monitoring the current developments in the ongoing war between Russia and Ukraine including the related export controls and resulting sanctions imposed on Russia by the U.S. and other countries. Additional factors such as increased inflation, escalating energy costs, constrained raw material availability, and related cost increases could continue to impact the global economy and our business. Although the global implications of the Russian and Ukraine war are difficult to predict at this time, we do not presently foresee direct material adverse effects on our business.

- removed (2023-11-08):
[0001628280-23-016653:note_history:22]
On August 3, 2022, we completed a merger with NeoPhotonics Corporation (“NeoPhotonics”). Our condensed consolidated financial statements include the operating results of NeoPhotonics for the period from the date of the closing of the merger through April 1, 2023. We have applied the acquisition method of accounting in accordance with Accounting Standards Codification (“ASC”) Topic 805, Business Combinations to account for this transaction. Refer to “Note 4. Business Combinations” for further discussion of the merger.

- removed (2023-11-08):
[0001628280-23-016653:note_history:23]
On August 15, 2022, we completed a transaction to acquire IPG Photonics’ telecom transmission product lines. Our condensed consolidated financial statements include the operating results of this business unit for the period from the date of the acquisition through April 1, 2023. We have applied the acquisition method of accounting in accordance with ASC Topic 805, Business Combinations to account for this transaction. Refer to “Note 4. Business Combinations” for further discussion of this acquisition.

- removed (2023-11-08):
[0001628280-23-016653:note_history:24]
Accounting Policies

- removed (2023-11-08):
[0001628280-23-016653:note_history:25]
The condensed consolidated financial statements and accompanying notes should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the fiscal year ended July 2, 2022. 
Except for the accounting policies for convertible instruments as a result of our adoption of Accounting Standards Update (“ASU”) 2020-06, Debt—Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging—Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity, described in “Note 2. Recently Issued Accounting Pronouncements”, there have been no significant changes to our accounting policies during the three and nine months ended April 1, 2023.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-11-08):
[0001628280-23-037591:note_history:26]
| September 30, 2023 | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |  | 2029 Notes (4) |  | Total |  |  |  |  |  |
| Principal | $ | 323.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,837.8 |  |  |  |  |  |  |
| Unamortized debt discount and debt issuance costs | (7.4) |  |  | (3.8) |  |  | (5.1) |  |  | (4.9) |  |  | (21.2) |  |  |  |  |  |  |
| Net carrying amount of the liability component | $ | 315.7 |  |  | $ | 1,046.2 |  |  | $ | 855.9 |  |  | $ | 598.8 |  |  | $ | 2,816.6 |  |  |  |  |  |  |

- changed (2023-11-08):
[0001628280-23-037591:note_history:27]
| July 1, 2023 | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |  | 2029 Notes (4) |  | Total |
| Principal | $ | 323.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,837.8 |  |
| Unamortized debt discount and debt issuance costs | (11.5) |  |  | (4.1) |  |  | (5.5) |  |  | (5.1) |  |  | (26.2) |  |
| Net carrying amount of the liability component | $ | 311.6 |  |  | $ | 1,045.9 |  |  | $ | 855.5 |  |  | $ | 598.6 |  |  | $ | 2,811.6 |  |
  (was, 2023-05-09, similarity 0.6525):
[0001628280-23-016653:note_history:27]
| Liability component: | April 1, 2023 |  | July 2, 2022 |
|  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |
| Principal | $ | 448.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 448.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |
| Unamortized debt discount | (20.7) |  |  | — |  |  | — |  |  | (36.1) |  |  | (214.9) |  |  | (221.4) |  |
| Unamortized issuance costs | (1.2) |  |  | (4.4) |  |  | (5.8) |  |  | (2.1) |  |  | (3.7) |  |  | (4.9) |  |
| Net carrying amount of the liability component | $ | 426.2 |  |  | $ | 1,045.6 |  |  | $ | 855.2 |  |  | $ | 409.9 |  |  | $ | 831.4 |  |  | $ | 634.7 |  |

- added (2023-11-08):
[0001628280-23-037591:note_history:28]
(4) If the closing price of our stock exceeds $90.40 (or 130% of the conversion price of $69.54) for 20 of the last 30 trading days of any future quarter, the 2029 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our consolidated balance sheets.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-11-08):
[0001628280-23-037591:note_history:29]
On June 16, 2023, we issued $603.7 million in aggregate principal amount of 1.50% convertible notes due in 2029 (“2029 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended. The 2029 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association, (as successor in interest to U.S. Bank National Association), as a trustee (the “2029 Indenture”). The 2029 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.
  (was, 2023-05-09, similarity 0.7857):
[0001628280-23-016653:note_history:29]
In March 2017, we issued $450.0 million in aggregate principal amount of 0.25% convertible notes due in 2024 (the “2024 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2024 Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

- added (2023-11-08):
[0001628280-23-037591:note_history:30]
The net proceeds from the sale of the 2029 Notes was $599.4 million, after deducting $4.3 million of net issuance costs. In addition, we incurred $0.8 million of professional fees directly related to this transaction. Concurrent with the issuance of the 2029 Notes, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 2024 Notes and $125.0 million of the net proceeds to repurchase our common stock in privately negotiated transactions. We intend to use the remaining net proceeds for general corporate purposes, which may include the repayment of our indebtedness, including any of our existing convertible notes, capital expenditures, working capital and potential acquisitions.

- added (2023-11-08):
[0001628280-23-037591:note_history:31]
The 2029 Notes bear interest at a rate of 1.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on December 15, 2023. The 2029 Notes will mature on December 15, 2029, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

- added (2023-11-08):
[0001628280-23-037591:note_history:32]
The initial conversion rate is 14.3808 shares of common stock per $1,000 principal amount of the 2029 Notes (which is equivalent to an initial conversion price of approximately $69.54 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2029 Indenture but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2029 Notes in connection with such make-whole fundamental change or notice of redemption.

- added (2023-11-08):
[0001628280-23-037591:note_history:33]
•during any fiscal quarter commencing after September 30, 2023 (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% if the applicable conversion price on each applicable trading day;

- added (2023-11-08):
[0001628280-23-037591:note_history:34]
•during the five consecutive business day period after any five consecutive trading day period (the “2029 measurement period”) in which the trading price per $1,000 principal amount of 2029 Notes for each trading day of the 2029 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day;

- added (2023-11-08):
[0001628280-23-037591:note_history:35]
•if we call any or all of the 2029 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the redemption date; or

- added (2023-11-08):
[0001628280-23-037591:note_history:36]
•upon the occurrence of specified corporate events as specified in the 2029 Indenture.

- added (2023-11-08):
[0001628280-23-037591:note_history:37]
On or after September 15, 2029 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2029 Notes at any time. Upon conversion, we will satisfy our conversion obligation in cash, shares of common stock or a combination of cash and shares of common stock, at our election.

- added (2023-11-08):
[0001628280-23-037591:note_history:38]
We may redeem for cash all or any portion of the 2029 Notes, at our option (subject to the partial redemption limitation set forth in the 2029 Indenture), on or after June 22, 2026, if the last reported sale price of our  common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide notice of redemption at a redemption price equal to 100% of the principal amount of the 2029 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2029 Notes. If we elect to redeem fewer than all of the outstanding 2029 Notes, at least $100.0 million aggregate principal amount of the 2029 Notes must be outstanding and not subject to redemption as of the redemption notice date. Upon the occurrence of a fundamental change (as defined in the 2029 Indenture), holders may require us to repurchase all or a portion of their 2029 Notes for cash at a price equal to 100% of the principal amount of the 2029 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

- added (2023-11-08):
[0001628280-23-037591:note_history:39]
The entire 2029 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of September 30, 2023 and July 1, 2023, measured at amortized cost.

- changed (2023-11-08):
[0001628280-23-037591:note_history:40]
In March 2022, we issued $861.0 million in aggregate principal amount of 0.50% convertible senior notes due in 2028 (the “2028 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2028 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2028 Indenture”). The 2028 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.
  (was, 2023-05-09, similarity 0.9947):
[0001628280-23-016653:note_history:40]
In March 2022, we issued $861.0 million in aggregate principal amount of 0.50% convertible notes due in 2028 (the “2028 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2028 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2028 Indenture”). The 2028 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

- changed (2023-11-08):
[0001628280-23-037591:note_history:41]
We initially bifurcated the principal amount of the 2028 Notes into liability and equity components. The liability component of the 2028 Notes was initially valued at $629.8 million based on the contractual cash flow discounted at an appropriate comparable market on non-convertible debt borrowing rate at the date of issuance, which was 5.7%, with the equity component representing the residual amount of the proceeds of $231.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2028 Notes were accounted for as a single liability measured at amortized cost. The entire 2028 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of September 30, 2023 and July 1, 2023, measured at amortized cost.
  (was, 2023-05-09, similarity 0.8286):
[0001628280-23-016653:note_history:41]
We initially bifurcated the principal amount of the 2028 Notes into liability and equity components. The liability component of the 2028 Notes was initially valued at $629.8 million based on the contractual cash flow discounted at an appropriate comparable market on non-convertible debt borrowing rate at the date of issuance, which was 5.7%, with the equity component representing the residual amount of the proceeds of $231.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2028 Notes were accounted for as a single liability measured at amortized cost. Refer to “Note 2. Recently Issued Accounting Pronouncement” for the detailed adoption impact.

- changed (2023-11-08):
[0001628280-23-037591:note_history:42]
In December 2019, we issued $1,050.0 million in aggregate principal amount of 0.50% convertible senior notes due in 2026 (the “2026 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2026 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association, as trustee (the “2026 Indenture”). We used approximately $196.0 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan credit facility, and a portion of the net proceeds of the offering to purchase approximately $200.0 million of our common stock concurrently with the pricing of the offering in privately negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.
  (was, 2023-05-09, similarity 0.9963):
[0001628280-23-016653:note_history:42]
In December 2019, we issued $1,050.0 million in aggregate principal amount of 0.50% convertible notes due in 2026 (the “2026 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2026 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association, as trustee (the “2026 Indenture”). We used approximately $196.0 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan credit facility, and a portion of the net proceeds of the offering to purchase approximately $200.0 million of our common stock concurrently with the pricing of the offering in privately negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

- added (2023-11-08):
[0001628280-23-037591:note_history:43]
Prior to the close of business on the business day immediately preceding September 15, 2026, holders of the 2026 Notes may convert their 2026 Notes only under the following circumstances:

- changed (2023-11-08):
[0001628280-23-037591:note_history:44]
We initially bifurcated the principal amount of the 2026 Notes into liability and equity components. The liability component of the 2026 Notes was initially valued at $734.8 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 5.8% with the equity component representing the residual amount of the proceeds of $315.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2026 Notes were accounted for as a single liability measured at amortized cost. The entire 2026 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of September 30, 2023 and July 1, 2023, measured at amortized cost.
  (was, 2023-05-09, similarity 0.826):
[0001628280-23-016653:note_history:44]
We initially bifurcated the principal amount of the 2026 Notes into liability and equity components. The liability component of the 2026 Notes was initially valued at $734.8 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 5.8% with the equity component representing the residual amount of the proceeds of $315.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2026 Notes were accounted for as a single liability measured at amortized cost.  Refer to “Note 2. Recently Issued Accounting Pronouncement” for the detailed adoption impact.

- added (2023-11-08):
[0001628280-23-037591:note_history:45]
2024 Notes

- added (2023-11-08):
[0001628280-23-037591:note_history:46]
In March 2017, we issued $450.0 million in aggregate principal amount of 0.25% convertible senior notes due in 2024 (the “2024 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2024 Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

- added (2023-11-08):
[0001628280-23-037591:note_history:47]
We considered the features embedded in the 2024 Notes other than the conversion feature, including the holders’ put feature, our call feature, and the make-whole feature, and concluded that they are not required to be bifurcated and accounted for separately from the host debt instrument.

- added (2023-11-08):
[0001628280-23-037591:note_history:48]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. We incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. We amortize the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes is 5.4% per year.

- added (2023-11-08):
[0001628280-23-037591:note_history:49]
During fiscal 2017, we satisfied the TMA settlement condition. As such, the value of the conversion option is no longer marked-to-market and was reclassified to additional paid-in capital within stockholders’ equity on our condensed consolidated balance sheets. The value of the conversion option at the time of issuance is treated as an original issue discount for purposes of accounting for the debt component of the 2024 Notes. The debt component will accrete up to the original amount over the expected term of the debt. The adoption of ASU 2020-06 did not change the presentation of the 2024 Notes, as the conversion feature associated with the 2024 Notes continues to be classified within stockholders’ equity.

- added (2023-11-08):
[0001628280-23-037591:note_history:50]
Concurrent with the issuance of the 2029 Notes in June 2023, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 2024 Notes, which we accounted for as an extinguishment of liability. $13.5 million of the $132.8 million repurchase price was allocated to the conversion feature of the repurchased 2024 Notes, representing the fair value of the conversion feature at the date of the repurchase, and was recognized as a reduction of the stockholders’ equity. Additionally, since issuing the 2024 Notes, we have converted a total of approximately $1.9 million principal amount of the 2024 Notes. The remaining principal amount was $323.1 million as of September 30, 2023 and July 1, 2023, recorded as convertible notes, current in our consolidated balance sheets, as the 2024 Notes will mature on March 15, 2024.

- added (2023-11-08):
[0001628280-23-037591:note_history:51]
| September 30, 2023 | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |  | 2029 Notes (4) |  | Total |  |  |  |  |  |
| Principal | $ | 323.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,837.8 |  |  |  |  |  |  |
| Unamortized debt discount and debt issuance costs | (7.4) |  |  | (3.8) |  |  | (5.1) |  |  | (4.9) |  |  | (21.2) |  |  |  |  |  |  |
| Net carrying amount of the liability component | $ | 315.7 |  |  | $ | 1,046.2 |  |  | $ | 855.9 |  |  | $ | 598.8 |  |  | $ | 2,816.6 |  |  |  |  |  |  |

- changed (2023-11-08):
[0001628280-23-037591:note_history:52]
| July 1, 2023 | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |  | 2029 Notes (4) |  | Total |
| Principal | $ | 323.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,837.8 |  |
| Unamortized debt discount and debt issuance costs | (11.5) |  |  | (4.1) |  |  | (5.5) |  |  | (5.1) |  |  | (26.2) |  |
| Net carrying amount of the liability component | $ | 311.6 |  |  | $ | 1,045.9 |  |  | $ | 855.5 |  |  | $ | 598.6 |  |  | $ | 2,811.6 |  |
  (was, 2023-05-09, similarity 0.6525):
[0001628280-23-016653:note_history:52]
| Liability component: | April 1, 2023 |  | July 2, 2022 |
|  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |
| Principal | $ | 448.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 448.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |
| Unamortized debt discount | (20.7) |  |  | — |  |  | — |  |  | (36.1) |  |  | (214.9) |  |  | (221.4) |  |
| Unamortized issuance costs | (1.2) |  |  | (4.4) |  |  | (5.8) |  |  | (2.1) |  |  | (3.7) |  |  | (4.9) |  |
| Net carrying amount of the liability component | $ | 426.2 |  |  | $ | 1,045.6 |  |  | $ | 855.2 |  |  | $ | 409.9 |  |  | $ | 831.4 |  |  | $ | 634.7 |  |

- added (2023-11-08):
[0001628280-23-037591:note_history:53]
(4) If the closing price of our stock exceeds $90.40 (or 130% of the conversion price of $69.54) for 20 of the last 30 trading days of any future quarter, the 2029 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our consolidated balance sheets.

- added (2023-11-08):
[0001628280-23-037591:note_history:54]
|  | Three Months Ended |  |  |
|  | September 30, 2023 |  | October 1, 2022 |  |  |  |  |
| Contractual interest expense | $ | 4.8 |  |  | $ | 2.7 |  |  |  |  |  |
| Amortization of the debt discount and debt issuance costs | 4.9 |  |  | 5.7 |  |  |  |  |  |
| Total interest expense | $ | 9.7 |  |  | $ | 8.4 |  |  |  |  |  |

- changed (2023-11-08):
[0001628280-23-037591:note_history:55]
The future interest and principal payments related to our convertible notes are as follows as of September 30, 2023 (in millions):
  (was, 2023-05-09, similarity 0.9593):
[0001628280-23-016653:note_history:55]
The future interest and principal payments related to our convertible notes are as follows as of April 1, 2023 (in millions):

- changed (2023-11-08):
[0001628280-23-037591:note_history:56]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | 2028 Notes |  | 2029 Notes |  | Total |
| 2024 | $ | 323.7 |  |  | $ | 5.3 |  |  | $ | 4.3 |  |  | $ | 9.1 |  |  | $ | 342.4 |  |
| 2025 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.1 |  |  | 18.7 |  |
| 2026 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.1 |  |  | 18.7 |  |
| 2027 | — |  |  | 1,052.5 |  |  | 4.3 |  |  | 9.1 |  |  | 1,065.9 |  |
| 2028 | — |  |  | — |  |  | 865.3 |  |  | 9.1 |  |  | 874.4 |  |
| Thereafter | — |  |  | — |  |  | — |  |  | 617.1 |  |  | 617.1 |  |
| Total payments | $ | 323.7 |  |  | $ | 1,068.4 |  |  | $ | 882.5 |  |  | $ | 662.6 |  |  | $ | 2,937.2 |  |
  (was, 2023-05-09, similarity 0.6823):
[0001628280-23-016653:note_history:56]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | 2028 Notes |  | Total |
| Remainder of 2023 | $ | — |  |  | $ | 2.6 |  |  | $ | 2.2 |  |  | $ | 4.8 |  |
| 2024 | 449.3 |  |  | 5.3 |  |  | 4.3 |  |  | 458.9 |  |
| 2025 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.6 |  |
| 2026 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.6 |  |
| 2027 and thereafter | — |  |  | 1,052.5 |  |  | 869.6 |  |  | 1,922.1 |  |
| Total convertible notes payments | $ | 449.3 |  |  | $ | 1,071.0 |  |  | $ | 884.7 |  |  | $ | 2,405.0 |  |

- changed (2023-11-08):
[0001628280-23-037591:note_history:57]
In connection with our merger of NeoPhotonics, we assumed several loan agreements with MUFG Bank, Ltd. (the “Mitsubishi Bank Loans”) for an aggregate fair value of approximately $5.9 million, approximately $0.9 million of which was paid in the fiscal first quarter of 2023 and the remaining balance of approximately $5.0 million was fully paid in the fiscal second quarter of 2023.
  (was, 2023-05-09, similarity 0.6782):
[0001628280-23-016653:note_history:57]
In connection with our merger of NeoPhotonics, we assumed several loan agreements with MUFG Bank, Ltd. (the “Mitsubishi Bank Loans”) for an aggregate fair value of approximately $5.9 million, approximately $0.9 million of which was paid in the fiscal first quarter of 2023.  In October 2022, we fully paid the remaining outstanding amount of the Mitsubishi Bank Loans of approximately $5.0 million. We recorded $0.1 million of interest expense related to the Mitsubishi Bank Loans for the nine months ended April 1, 2023.

- removed (2023-11-08):
[0001628280-23-016653:note_history:58]
During the three and nine months ended April 1, 2023, we received conversion requests of less than $0.1 million principal amount of the 2024 Notes, which we settled with cash in accordance with the 2024 Indenture. Since issuing the 2024 Notes, we have converted a total of approximately $1.9 million principal amount of the 2024 Notes. The remaining principal amount of the 2024 Notes as of April 1, 2023 was $448.1 million.

- removed (2023-11-08):
[0001628280-23-016653:note_history:59]
We considered the features embedded in the 2024 Notes other than the conversion feature, including the holders’ put feature, our call feature, and the make-whole feature, and concluded that they are not required to be bifurcated and accounted for separately from the host debt instrument. Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. During fiscal 2017, we satisfied the TMA settlement condition. As such, the value of the conversion option is no longer marked-to-market and was reclassified to additional paid-in capital within stockholders’ equity on our condensed consolidated balance sheets. The adoption of ASU 2020-06 did not change the presentation of the 2024 Notes, as the conversion feature associated with the 2024 Notes continues to be classified within stockholders’ equity.

- removed (2023-11-08):
[0001628280-23-016653:note_history:60]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2023 |  | April 2, 2022 |  | April 1, 2023 |  | April 2, 2022 |
| Contractual interest expense | $ | 2.7 |  |  | $ | 1.9 |  |  | $ | 8.1 |  |  | $ | 5.1 |  |
| Amortization of the debt discount and debt issuance costs | 6.0 |  |  | 17.8 |  |  | 17.9 |  |  | 48.6 |  |
| Total interest expense | $ | 8.7 |  |  | $ | 19.7 |  |  | $ | 26.0 |  |  | $ | 53.7 |  |


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-11-08):
[0001628280-23-037591:note_history:61]
|  | Continuous Loss Position for More Than 12 Months |  | Continuous Loss Position for Less Than 12 Months |  | Gross Unrealized Losses |  |  |  |  |  |  |  |  |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |  |
| September 30, 2023: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 159.5 |  |  | $ | (1.2) |  |  | $ | 33.8 |  |  | $ | (0.2) |  |  | $ | (1.4) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | 11.7 |  |  | — |  |  | — |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 89.9 |  |  | (0.1) |  |  | — |  |  | — |  |  | (0.1) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 351.3 |  |  | (2.7) |  |  | 68.7 |  |  | (0.5) |  |  | (3.2) |  |  |  |  |  |  |  |  |  |
| Foreign government bonds | 4.6 |  |  | — |  |  | — |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 215.4 |  |  | (1.3) |  |  | 22.9 |  |  | (0.2) |  |  | (1.5) |  |  |  |  |  |  |  |  |  |
| Total | $ | 832.4 |  |  | $ | (5.3) |  |  | $ | 125.4 |  |  | $ | (0.9) |  |  | $ | (6.2) |  |  |  |  |  |  |  |  |  |
| July 1, 2023: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 39.6 |  |  | $ | (0.4) |  |  | $ | 170.6 |  |  | $ | (1.3) |  |  | $ | (1.7) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | — |  |  | $ | 7.7 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | $ | 128.5 |  |  | (0.2) |  |  | (0.2) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 93.6 |  |  | (1.2) |  |  | $ | 358.9 |  |  | (2.7) |  |  | (3.9) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 50.8 |  |  | (0.6) |  |  | $ | 221.4 |  |  | (1.4) |  |  | (2.0) |  |  |  |  |  |  |  |  |  |
| Total | $ | 184.0 |  |  | $ | (2.2) |  |  | $ | 887.1 |  |  | $ | (5.6) |  |  | $ | (7.8) |  |  |  |  |  |  |  |  |  |
  (was, 2023-05-09, similarity 0.8079):
[0001628280-23-016653:note_history:61]
|  | Continuous Loss Position For More Than 12 Months |  | Continuous Loss Position For Less Than 12 Months |  | Gross Unrealized Losses |  |  |  |  |  |  |  |  |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |  |
| April 1, 2023: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 42.2 |  |  | $ | (0.8) |  |  | $ | 82.9 |  |  | $ | (0.2) |  |  | $ | (1.0) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | — |  |  | 12.7 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 112.5 |  |  | (0.2) |  |  | (0.2) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 153.7 |  |  | (1.8) |  |  | 192.8 |  |  | (1.2) |  |  | (3.0) |  |  |  |  |  |  |  |  |  |
| Foreign government bonds | — |  |  | — |  |  | 1.4 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 90.8 |  |  | (1.0) |  |  | 124.6 |  |  | (0.3) |  |  | (1.3) |  |  |  |  |  |  |  |  |  |
| Total | $ | 286.7 |  |  | $ | (3.6) |  |  | $ | 526.9 |  |  | $ | (1.9) |  |  | $ | (5.5) |  |  |  |  |  |  |  |  |  |
| July 2, 2022: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | — |  |  | $ | — |  |  | $ | 73.7 |  |  | $ | (1.4) |  |  | $ | (1.4) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | — |  |  | 16.2 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 130.7 |  |  | (0.4) |  |  | (0.4) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 57.4 |  |  | (0.9) |  |  | 473.2 |  |  | (6.5) |  |  | (7.4) |  |  |  |  |  |  |  |  |  |
| Municipal bonds | — |  |  | — |  |  | 1.0 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | — |  |  | — |  |  | 366.0 |  |  | (4.2) |  |  | (4.2) |  |  |  |  |  |  |  |  |  |
| Total | $ | 57.4 |  |  | $ | (0.9) |  |  | $ | 1,060.8 |  |  | $ | (12.5) |  |  | $ | (13.4) |  |  |  |  |  |  |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-11-08):
[0001628280-23-037591:note_history:62]
The future interest and principal payments related to our convertible notes are as follows as of September 30, 2023 (in millions):
  (was, 2023-05-09, similarity 0.9593):
[0001628280-23-016653:note_history:62]
The future interest and principal payments related to our convertible notes are as follows as of April 1, 2023 (in millions):

- changed (2023-11-08):
[0001628280-23-037591:note_history:63]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | 2028 Notes |  | 2029 Notes |  | Total |
| 2024 | $ | 323.7 |  |  | $ | 5.3 |  |  | $ | 4.3 |  |  | $ | 9.1 |  |  | $ | 342.4 |  |
| 2025 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.1 |  |  | 18.7 |  |
| 2026 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.1 |  |  | 18.7 |  |
| 2027 | — |  |  | 1,052.5 |  |  | 4.3 |  |  | 9.1 |  |  | 1,065.9 |  |
| 2028 | — |  |  | — |  |  | 865.3 |  |  | 9.1 |  |  | 874.4 |  |
| Thereafter | — |  |  | — |  |  | — |  |  | 617.1 |  |  | 617.1 |  |
| Total payments | $ | 323.7 |  |  | $ | 1,068.4 |  |  | $ | 882.5 |  |  | $ | 662.6 |  |  | $ | 2,937.2 |  |
  (was, 2023-05-09, similarity 0.6823):
[0001628280-23-016653:note_history:63]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | 2028 Notes |  | Total |
| Remainder of 2023 | $ | — |  |  | $ | 2.6 |  |  | $ | 2.2 |  |  | $ | 4.8 |  |
| 2024 | 449.3 |  |  | 5.3 |  |  | 4.3 |  |  | 458.9 |  |
| 2025 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.6 |  |
| 2026 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.6 |  |
| 2027 and thereafter | — |  |  | 1,052.5 |  |  | 869.6 |  |  | 1,922.1 |  |
| Total convertible notes payments | $ | 449.3 |  |  | $ | 1,071.0 |  |  | $ | 884.7 |  |  | $ | 2,405.0 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-11-08):
[0001628280-23-037591:note_history:64]
We disaggregate revenue by segment and by geography. We do not present other levels of disaggregation, such as by type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, as this information is not used by our CODM to manage the business.
  (was, 2023-05-09, similarity 0.9801):
[0001628280-23-016653:note_history:64]
We disaggregate revenue by product and by geography. We do not present other levels of disaggregation, such as by type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, as this information is not used by our CODM to manage the business.

- added (2023-11-08):
[0001628280-23-037591:note_history:65]
The table below discloses our total net revenue attributable to each of our two reportable segments (in millions, except percentage data):

- added (2023-11-08):
[0001628280-23-037591:note_history:66]
|  | Three Months Ended |  |  |
|  | September 30, 2023 |  | October 1, 2022 |  |  |  |  |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  |  |  |  |  |  |
| Cloud & Networking | $ | 229.7 |  |  | 72.3 | % |  | $ | 360.1 |  |  | 71.1 | % |  |  |  |  |  |  |
| Industrial Tech | 87.9 |  |  | 27.7 | % |  | 146.7 |  |  | 28.9 | % |  |  |  |  |  |  |
| Net revenue | $ | 317.6 |  |  | 100.0 | % |  | $ | 506.8 |  |  | 100.0 | % |  |  |  |  |  |  |

- added (2023-11-08):
[0001628280-23-037591:note_history:67]
| Contract balances |  | Balance sheet location |  | September 30, 2023 |  | July 1, 2023 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 220.0 |  |  | $ | 246.1 |  |  | $ | (26.1) |  |  | (10.6) | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | 1.6 |  |  | $ | 2.1 |  |  | $ | (0.5) |  |  | (23.8) | % |

- removed (2023-11-08):
[0001628280-23-016653:note_history:68]
The table below discloses our total net revenue attributable to each of our two reportable segments. In addition, the table sets forth the percentage of our total net revenue attributable to our product offerings that serve Telecom and Datacom, and Consumer and Industrial markets, which accounted for 10% or more of our total net revenue during the periods presented (in millions, except percentage data):

- removed (2023-11-08):
[0001628280-23-016653:note_history:69]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2023 |  | April 2, 2022 |  | April 1, 2023 |  | April 2, 2022 |
| OpComms: |  |  |  |  |  |  |  |  |  |  |  |
| Telecom and Datacom | $ | 293.3 |  | 76.5 | % |  | $ | 243.5 |  | 61.6 | % |  | $ | 1,037.6 |  | 74.3 | % |  | $ | 726.6 |  | 56.3 | % |
| Industrial and Consumer | 41.8 |  | 10.9 | % |  | 100.7 |  | 25.5 | % |  | 199.7 |  | 14.3 | % |  | 421.0 |  | 32.6 | % |
| Total OpComms | $ | 335.1 |  | 87.4 | % |  | $ | 344.2 |  | 87.1 | % |  | $ | 1,237.3 |  | 88.6 | % |  | $ | 1,147.6 |  | 88.9 | % |
| Lasers | 48.3 |  | 12.6 | % |  | 51.2 |  | 12.9 | % |  | 158.9 |  | 11.4 | % |  | 142.9 |  | 11.1 | % |
| Net Revenue | $ | 383.4 |  |  |  | $ | 395.4 |  |  |  | $ | 1,396.2 |  |  |  | $ | 1,290.5 |  |  |

- removed (2023-11-08):
[0001628280-23-016653:note_history:70]
| Contract balances |  | Balance sheet location |  | April 1, 2023 |  | July 2, 2022 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 278.0 |  |  | $ | 262.0 |  |  | $ | 16.0 |  |  | 6.1 | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | 3.4 |  |  | $ | — |  |  | $ | 3.4 |  |  | n/a |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2023-11-08):
[0001628280-23-037591:note_history:71]
Note 17. Subsequent Event

- added (2023-11-08):
[0001628280-23-037591:note_history:72]
On October 30, 2023, Lumentum and Cloud Light Technology Limited (“Cloud Light”) announced a definitive merger agreement (the “Merger Agreement”), On November 7, 2023 (the “Closing date”), we completed the acquisition of Cloud Light. The acquisition will enable us to be well-positioned to serve the growing needs of cloud and networking customers, particularly those focused on optimizing their data center infrastructure for the demands of AI/ML. The total transaction value is approximately $750.0 million, subject to certain customary adjustments as specified in the Merger Agreement. We paid cash consideration of $706.6 million to shareholders of Cloud Light on the Closing date. Additionally, we converted each of Cloud Light’s outstanding options into options to acquire Lumentum common stock with equivalent value.

- added (2023-11-08):
[0001628280-23-037591:note_history:73]
During the three months ended September 30, 2023, we incurred $3.7 million of transaction costs related to this acquisition, which were recorded under selling, general and administrative expenses in our consolidated statement of operations.

- added (2023-11-08):
[0001628280-23-037591:note_history:74]
The acquisition will be accounted for as a business combination using the acquisition method of accounting, which requires, among other things, certain assets acquired and liabilities assumed be recognized at their fair values as of the acquisition date. We are currently evaluating the purchase accounting for this acquisition.
