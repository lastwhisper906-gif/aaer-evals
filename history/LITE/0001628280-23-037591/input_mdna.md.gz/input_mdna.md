# LITE MD&A — 0001628280-23-037591


## mdna

[0001628280-23-037591:mdna:1]
[same as prior period, unchanged from 0001628280-23-016653:mdna:1]

[0001628280-23-037591:mdna:2]
[same as prior period, unchanged from 0001628280-23-016653:mdna:2]

[0001628280-23-037591:mdna:3]
[same as prior period, unchanged from 0001628280-23-016653:mdna:3]

[0001628280-23-037591:mdna:4]
[same as prior period, unchanged from 0001628280-23-016653:mdna:4]

[0001628280-23-037591:mdna:5]
We are an industry-leading provider of optical and photonic products defined by revenue and market share, addressing a range of end-market applications for manufacturing, inspection and life-science applications.

[0001628280-23-037591:mdna:6]
We believe the global markets in which Lumentum participates have fundamentally robust, long-term trends that will increase the need for our photonics products and technologies. We believe the world is becoming more reliant on ever-increasing amounts of data flowing through optical networks and data centers. Lumentum’s products and technology enable the scaling of these optical networks and data centers to higher capacities. We expect that the accelerating shift to digital and virtual approaches to many aspects of work and life will continue into the future. Virtual meetings, video calls, and hybrid in-person and virtual environments for work and other aspects of life will continue to drive strong needs for bandwidth growth and present dynamic new challenges that our technology addresses. As manufacturers demand higher levels of precision, new materials, and factory and energy efficiency, suppliers of manufacturing tools globally are turning to laser-based approaches, including the types of lasers Lumentum supplies. Laser-based 3D sensing and LiDAR for security, industrial and automotive applications are rapidly developing markets. The technology enables computer vision applications that enhance security, safety, and new functionality in the electronic devices that people rely on every day. The use of LiDAR and in-cabin 3D sensing in automobile and delivery vehicles over time significantly adds to our long-term market opportunity. Frictionless and contactless biometric security and access control is of increasing focus globally given the world’s experience with the COVID-19 pandemic. Additionally, we expect 3D-enabled machine vision solutions to expand significantly in industrial applications in the coming years.

[0001628280-23-037591:mdna:7]
[same as prior period, unchanged from 0001628280-23-016653:mdna:8]

[0001628280-23-037591:mdna:8]
Prior to fiscal year 2024, we operated in two reportable segments consisting of Optical Communications (“OpComms”) and Commercial Lasers (“Lasers”). During the fiscal first quarter of 2024, our chief operating decision maker (“CODM”) implemented changes in how he organizes the business, allocates resources, and assesses performance. We changed our organizational structure to better align with trends in our markets and our customer and product mix. Our new operating segments are Cloud & Networking and Industrial Tech. The Cloud & Networking segment includes the Telecom & Datacom product lines that were previously part of the OpComms segment. The Industrial Tech segment includes previous Lasers segment and the Industrial & Consumer product lines that were previously part of the OpComms segment. The two operating segments were primarily determined based on how the CODM views and evaluates our operations. The CODM regularly reviews operating results to make decisions about resources to be allocated to the segments and to assess their performance.

[0001628280-23-037591:mdna:9]
In conjunction with this change, our CODM now evaluates each segment’s performance and allocates resources based on segment revenue and segment profit, instead of gross profit, as our CODM believes segment profit is a more comprehensive profitability measure for each operating segment. Segment profit includes operating expenses directly managed by operating segments, including research and development, and direct sales and marketing expenses. Segment profit does not include stock-based compensation, acquisition or integration related costs, amortization and impairment of acquisition-related intangible assets, restructuring and related charges, and certain other charges. Additionally, we do not allocate corporate marketing and strategic marketing expenses and general and administrative expenses, as these expenses are not directly attributable to our operating segments.

[0001628280-23-037591:mdna:10]
Comparative prior period segment information has been recast to conform to the new segment structure and segment profitability measure. The change in our operating segments had no impact on our previously reported consolidated results of operations, financial condition, or cash flows.

[0001628280-23-037591:mdna:11]
Cloud & Networking

[0001628280-23-037591:mdna:12]
Our Cloud and Networking products include a wide range of components, modules, and subsystems to support customers including carrier networks for access (local), metro (intracity), long-haul (city-to-city and worldwide) and submarine (undersea) applications. Additionally, our products address enterprise, cloud, and data center applications, including storage-access networks (“SANs”), local-area networks (“LANs”) and wide-area networks (“WANs”), as well as artificial intelligence and machine learning (“AI/ML”). These products enable the transmission and transport of video, audio, and data over high-capacity fiber-optic cables. We maintain leading positions in these fast-growing cloud and networking markets through our extensive product portfolio, including reconfigurable optical add/drop multiplexers (“ROADMs”), coherent dense wavelength division multiplexing (“DWDM”) pluggable transceivers, and tunable small form-factor pluggable transceivers. We also sell laser chips for use in manufacturing of high-speed ethernet transceivers for use inside data centers.

[0001628280-23-037591:mdna:13]
Industrial Tech

[0001628280-23-037591:mdna:14]
Our Industrial Tech products include diode laser products such as VCSELs and edge emitting lasers. In the consumer end-market, our laser light sources are integrated into 3D sensing cameras which are used in applications in mobile devices, gaming, payment kiosks, computers, and other consumer electronics devices. Applications include biometric identification, computational photography, virtual and augmented reality, and natural user interfaces. Emerging applications for our lasers include automotive safety systems, LiDAR for advanced driver assistance systems in automobiles and autonomous vehicles, self-navigating robotics and drones in industrial applications, and 3D capture of objects coupled with 3D imaging or printing. In the industrial end market, our diode lasers are used primarily as pump sources for pulsed and kilowatt class fiber lasers.

[0001628280-23-037591:mdna:15]
Industrial Tech products also include laser products used in a variety of OEM applications including diode-pumped solid-state, fiber, diode, direct-diode and gas lasers such as argon-ion and helium-neon lasers. Fiber lasers provide kW-class output powers combined with excellent beam quality and are used in sheet metal processing and metal welding applications. These applications range in output power from milliwatts to kilowatts and include ultraviolet, visible and infrared wavelengths. Our laser products serve our customers in markets and applications such as sheet metal processing, general manufacturing, solar cell processing, biotechnology, graphics and imaging, remote sensing, and precision machining such as drilling in printed circuit boards, wafer singulation, glass cutting and solar cell scribing. We also provide high-powered and ultrafast lasers for the industrial and scientific markets. Manufacturers use high-power, ultrafast lasers to create micro parts for consumer electronics and to process semiconductor, LED, solar cells, and other types of chips. Use of ultrafast lasers for micromachining applications is being driven primarily by the increasing use of renewable energy, consumer electronics and connected devices globally.

[0001628280-23-037591:mdna:16]
Merger and Acquisition

[0001628280-23-037591:mdna:17]
Acquisition of Cloud Light

[0001628280-23-037591:mdna:18]
On October 30, 2023, Lumentum and Cloud Light Technology Limited (“Cloud Light”) announced a definitive merger agreement (the “Merger Agreement”), On November 7, 2023 (the “Closing date”), we completed the acquisition of Cloud Light. The acquisition will enable us to be well-positioned to serve the growing needs of cloud and networking customers, particularly those focused on optimizing their data center infrastructure for the demands of AI/ML. The total transaction value is approximately $750.0 million, subject to certain customary adjustments as specified in the Merger Agreement. We paid cash consideration of $706.6 million to shareholders of Cloud Light on the Closing date. Additionally, we converted each of Cloud Light’s outstanding options into options to acquire Lumentum common stock with equivalent value.

[0001628280-23-037591:mdna:19]
During the three months ended September 30, 2023, we incurred $3.7 million of transaction costs related to this acquisition, which were recorded under selling, general and administrative expenses in our consolidated statement of operations.

[0001628280-23-037591:mdna:20]
[same as prior period, unchanged from 0001628280-23-016653:mdna:19]

[0001628280-23-037591:mdna:21]
Supply Chain Constraints and Inventory Management

[0001628280-23-037591:mdna:22]
Our business and our customers’ businesses have been negatively impacted by worldwide logistics and supply chain issues, including constraints on available cargo capabilities and limited availability of once broadly available supplies of both raw materials and finished components. COVID-19 also created dynamics in the semiconductor component supply chains that have led to shortages of the types of components we and our customers require in our products. Although the supply chain constraints improved in the latter half of fiscal 2023, they may impact our ability to supply our products to our customers and may reduce our revenue and profit margin if these shortages happen again in the future. In addition, if our customers are unable to procure needed semiconductor components, their demand for our products will decrease. Due to the global supply chain constraints, we had to incur incremental supply and procurement costs in order to increase our ability to fulfill demands from our customers.

[0001628280-23-037591:mdna:23]
In addition, the impact of semiconductor component shortages has continued in recent periods and may continue in the near term with the exhaustion of supplier and customer buffer inventories and safety stocks. In response to component shortages, certain of our customers accumulated inventory that they are now managing down as supply conditions improve. Accordingly, customer orders have declined in recent periods and certain customers have not taken the shipments we had originally projected due to their inventory management. We expect this trend to continue to impact our business at least through the end of calendar year 2023.

[0001628280-23-037591:mdna:24]
[same as prior period, unchanged from 0001628280-23-016653:mdna:28]

[0001628280-23-037591:mdna:25]
[same as prior period, unchanged from 0001628280-23-016653:mdna:29]

[0001628280-23-037591:mdna:26]
Our condensed and consolidated financial statements are prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) as set forth in the Financial Accounting Standards Board’s Accounting Standards Codification (“ASC”). We also consider the various staff accounting bulletins and other applicable guidance issued by the United States Securities and Exchange Commission (“SEC”). GAAP, as set forth within the ASC, requires us to make certain estimates, judgments and assumptions. We believe that the estimates, judgments and assumptions upon which we rely are reasonable based upon information available to us at the time that these estimates, judgments and assumptions are made. These estimates, judgments and assumptions can affect the reported amounts of assets and liabilities as of the date of the financial statements as well as the reported amounts of revenues and expenses during the periods presented. To the extent there are differences between these estimates, judgments or assumptions and actual results, our financial statements will be affected. The accounting policies that reflect our more significant estimates, judgments and assumptions and which we believe are the most critical to aid in fully understanding and evaluating our reported financial results include the following:

[0001628280-23-037591:mdna:27]
[same as prior period, unchanged from 0001628280-23-016653:mdna:31]

[0001628280-23-037591:mdna:28]
[same as prior period, unchanged from 0001628280-23-016653:mdna:32]

[0001628280-23-037591:mdna:29]
[same as prior period, unchanged from 0001628280-23-016653:mdna:33]

[0001628280-23-037591:mdna:30]
[same as prior period, unchanged from 0001628280-23-016653:mdna:34]

[0001628280-23-037591:mdna:31]
•Goodwill and Intangible Assets - Impairment Assessment

[0001628280-23-037591:mdna:32]
Management’s Discussion and Analysis of Financial Condition and Results of Operations contained in Part II, Item 7 of our Annual Report on Form 10-K for our fiscal year ended July 1, 2023 provides a complete discussion of our critical accounting policies and estimates. There have been no changes to these policies during the three months ended September 30, 2023.

[0001628280-23-037591:mdna:33]
Recently Issued Accounting Pronouncements

[0001628280-23-037591:mdna:34]
Refer to “Note 2. Recently Issued Accounting Pronouncements” in the notes to condensed consolidated financial statements.

[0001628280-23-037591:mdna:35]
[same as prior period, unchanged from 0001628280-23-016653:mdna:39]

[0001628280-23-037591:mdna:36]
Comparative prior period segment information has been recast to conform to the new segment structure and segment profitability measure. The change in our operating segments had no impact on our previously reported consolidated results of operations, financial condition, or cash flows.

[0001628280-23-037591:mdna:37]
[same as prior period, unchanged from 0001628280-23-016653:mdna:40]

[0001628280-23-037591:mdna:38]
|  | Three Months Ended |  |  |
|  | September 30, 2023 |  | October 1, 2022 |  |  |  |  |
| Segment net revenue: |  |  |  |  |  |  |  |
| Cloud & Networking | 72.3 | % |  | 71.0 | % |  |  |  |  |
| Industrial Tech | 27.7 |  |  | 29.0 |  |  |  |  |  |
| Net revenue | 100.0 |  |  | 100.0 |  |  |  |  |  |
| Cost of sales | 70.2 |  |  | 55.8 |  |  |  |  |  |
| Amortization of acquired developed intangibles | 5.7 |  |  | 4.5 |  |  |  |  |  |
| Gross profit | 24.1 |  |  | 39.7 |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 23.1 |  |  | 14.3 |  |  |  |  |  |
| Selling, general and administrative | 23.0 |  |  | 20.9 |  |  |  |  |  |
| Restructuring and related charges | 3.5 |  |  | 1.8 |  |  |  |  |  |
| Total operating expenses | 49.6 |  |  | 37.0 |  |  |  |  |  |
| Income (loss) from operations | (25.4) |  |  | 2.7 |  |  |  |  |  |
| Interest expense | (3.0) |  |  | (1.7) |  |  |  |  |  |
| Other income, net | 6.7 |  |  | 2.7 |  |  |  |  |  |
| Income (loss) before income taxes | (21.8) |  |  | 3.7 |  |  |  |  |  |
| Income tax provision (benefit) | (0.4) |  |  | 3.8 |  |  |  |  |  |
| Net loss | (21.4) | % |  | (0.1) | % |  |  |  |  |

[0001628280-23-037591:mdna:39]
43

[0001628280-23-037591:mdna:40]
Financial data for the three months ended September 30, 2023 and October 1, 2022

[0001628280-23-037591:mdna:41]
[same as prior period, unchanged from 0001628280-23-016653:mdna:44]

[0001628280-23-037591:mdna:42]
|  | Three Months Ended |  |  |  |  |  |  |
|  | September 30, 2023 |  | October 1, 2022 |  | Change |  | Percentage Change |  |  |  |  |  |  |  |  |
| Segment net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cloud & Networking | $ | 229.7 |  |  | $ | 360.1 |  |  | $ | (130.4) |  |  | (36.2) | % |  |  |  |  |  |  |  |  |
| Industrial Tech | 87.9 |  |  | 146.7 |  |  | (58.8) |  |  | (40.1) | % |  |  |  |  |  |  |  |  |
| Net revenue | $ | 317.6 |  |  | $ | 506.8 |  |  | $ | (189.2) |  |  | (37.3) | % |  |  |  |  |  |  |  |  |
| Gross profit | $ | 76.7 |  |  | $ | 201.2 |  |  | $ | (124.5) |  |  | (61.9) | % |  |  |  |  |  |  |  |  |
| Gross margin | 24.1 | % |  | 39.7 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 73.5 |  |  | $ | 72.7 |  |  | $ | 0.8 |  |  | 1.1 | % |  |  |  |  |  |  |  |  |
| Percentage of net revenue | 23.1 | % |  | 14.3 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative | $ | 73.0 |  |  | $ | 105.7 |  |  | $ | (32.7) |  |  | (30.9) | % |  |  |  |  |  |  |  |  |
| Percentage of net revenue | 23.0 | % |  | 20.9 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring and related charges | $ | 11.0 |  |  | $ | 9.3 |  |  | $ | 1.7 |  |  | 18.3 | % |  |  |  |  |  |  |  |  |
| Percentage of net revenue | 3.5 | % |  | 1.8 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0001628280-23-037591:mdna:43]
[same as prior period, unchanged from 0001628280-23-016653:mdna:46]

[0001628280-23-037591:mdna:44]
Net revenue decreased by $189.2 million, or 37.3%, during the three months ended September 30, 2023 compared to the three months ended October 1, 2022, driven by a $130.4 million decrease in Cloud & Networking revenue and a $58.8 million decrease in Industrial Tech revenue. The decrease in Cloud & Networking net revenue is primarily due to reduction in demand associated with inventory management and build-up at our customers. The decrease in Industrial and Tech net revenue is primarily due to higher market competition, which reflects share normalization in the market, as well as reduction in demand associated with inventory management and build-up at our customers.

[0001628280-23-037591:mdna:45]
During the three months ended September 30, 2023, our net revenue from a single customer that represented 10% or greater of the total net revenue was concentrated with three customers, who individually accounted for 15%, 13% and 10% of our total net revenue, respectively. During the three months ended October 1, 2022, our net revenue from a single customer that represented 10% or greater of total net revenue was concentrated with two customers, who individually accounted for 17% and 17% of our total net revenue, respectively.

[0001628280-23-037591:mdna:46]
[same as prior period, unchanged from 0001628280-23-016653:mdna:55]

[0001628280-23-037591:mdna:47]
We operate in three geographic regions: Americas, Asia-Pacific, and EMEA (Europe, Middle East, and Africa). Net revenue is assigned to the geographic region and country where our product is initially shipped. For example, certain customers may request shipment of our product to a contract manufacturer in one country, which may differ from the location of their end customers.

[0001628280-23-037591:mdna:48]
The following table presents net revenue by the three geographic regions we operate in and net revenue from countries that generally represented 10% or more of our total net revenue (in millions, except percentage data):

[0001628280-23-037591:mdna:49]
|  | Three Months Ended |  |  |
|  | September 30, 2023 |  | October 1, 2022 |  |  |  |  |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 41.1 |  |  | 12.9 | % |  | $ | 62.2 |  |  | 12.3 | % |  |  |  |  |  |  |  |  |
| Mexico | 23.7 |  |  | 7.5 |  |  | 57.5 |  |  | 11.3 |  |  |  |  |  |  |  |  |  |
| Other Americas | 1.2 |  |  | 0.4 |  |  | 2.3 |  |  | 0.5 |  |  |  |  |  |  |  |  |  |
| Total Americas | $ | 66.0 |  |  | 20.8 | % |  | $ | 122.0 |  |  | 24.1 | % |  |  |  |  |  |  |  |  |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 64.9 |  |  | 20.4 | % |  | $ | 77.6 |  |  | 15.3 | % |  |  |  |  |  |  |  |  |
| South Korea | 25.0 |  |  | 7.9 |  |  | 67.7 |  |  | 13.4 |  |  |  |  |  |  |  |  |  |
| Thailand | 64.2 |  |  | 20.2 |  |  | 57.5 |  |  | 11.3 |  |  |  |  |  |  |  |  |  |
| Other Asia-Pacific | 64.9 |  |  | 20.4 |  |  | 133.7 |  |  | 26.4 |  |  |  |  |  |  |  |  |  |
| Total Asia-Pacific | $ | 219.0 |  |  | 68.9 | % |  | $ | 336.5 |  |  | 66.4 | % |  |  |  |  |  |  |  |  |
| EMEA | $ | 32.6 |  |  | 10.3 | % |  | $ | 48.3 |  |  | 9.5 | % |  |  |  |  |  |  |  |  |
| Total net revenue | $ | 317.6 |  |  | 100.0 | % |  | $ | 506.8 |  |  | 100.0 | % |  |  |  |  |  |  |  |  |

[0001628280-23-037591:mdna:50]
For the three months ended September 30, 2023 and October 1, 2022, net revenue from customers outside the United States, based on customer shipping location, represented 87.1% and 87.7% of net revenue, respectively.

[0001628280-23-037591:mdna:51]
[same as prior period, unchanged from 0001628280-23-016653:mdna:59]

[0001628280-23-037591:mdna:52]
[same as prior period, unchanged from 0001628280-23-016653:mdna:66]

[0001628280-23-037591:mdna:53]
Gross margin for the three months ended September 30, 2023 decreased to 24.1%  from 39.7% for the three months ended October 1, 2022. The decrease in gross margin was primarily driven by lower revenue as discussed above, a less profitable mix of products, including lower sales of higher margin imaging and sensing products, and an $11.3 million increase in inventory excess and obsolescence charges due to customer demand change and transitions to the next generation of products. Additionally, gross margin was negatively impacted by factory underutilization as a result of a drop in demand as customers work to reduce their elevated inventory levels.

[0001628280-23-037591:mdna:54]
The markets in which we sell products are consolidating, undergoing product, architectural and business model transitions, have high customer concentrations, are highly competitive, are price sensitive and/or are affected by customer seasonal and  variants in buying patterns. We expect these factors to result in variability of our gross margin.

[0001628280-23-037591:mdna:55]
45

[0001628280-23-037591:mdna:56]
Segment Profit

[0001628280-23-037591:mdna:57]
The following table summarizes segment profit and a reconciliation to the consolidated income (loss) before income taxes for the periods presented (in millions). Comparative prior period segment information has been recast to conform to the new segment structure.

[0001628280-23-037591:mdna:58]
|  | Three Months Ended |  |  |
|  | September 30, 2023 |  | October 1, 2022 |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |
| Cloud & Networking | $ | 229.7 |  |  | $ | 360.1 |  |  |  |  |  |
| Industrial Tech | 87.9 |  |  | 146.7 |  |  |  |  |  |
| Net revenue | $ | 317.6 |  |  | $ | 506.8 |  |  |  |  |  |
| Segment profit: |  |  |  |  |  |  |  |
| Cloud & Networking | $ | 23.9 |  |  | $ | 101.7 |  |  |  |  |  |
| Industrial Tech | 15.3 |  |  | 68.8 |  |  |  |  |  |
| Total segment profit | 39.2 |  |  | 170.5 |  |  |  |  |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Selling, general and administrative (1) | (28.6) |  |  | (33.1) |  |  |  |  |  |
| Stock-based compensation | (32.1) |  |  | (34.7) |  |  |  |  |  |
| Stock-based compensation - acquisition related | — |  |  | (11.9) |  |  |  |  |  |
| Amortization of acquired intangibles | (29.0) |  |  | (32.2) |  |  |  |  |  |
| Amortization of acquired inventory fair value adjustments | — |  |  | (4.6) |  |  |  |  |  |
| Acquisition related costs | (4.0) |  |  | (16.2) |  |  |  |  |  |
| Integration related costs | (11.3) |  |  | (0.6) |  |  |  |  |  |
| Restructuring and related charges | (11.0) |  |  | (9.3) |  |  |  |  |  |
| Other charges, net (2) | (4.0) |  |  | (14.4) |  |  |  |  |  |
| Interest expense | (9.7) |  |  | (8.5) |  |  |  |  |  |
| Other income, net (3) | 21.2 |  |  | 13.8 |  |  |  |  |  |
| Consolidated income (loss) before income taxes | $ | (69.3) |  |  | $ | 18.8 |  |  |  |  |  |

[0001628280-23-037591:mdna:59]
(1) We do not allocate selling, general and administrative expenses that are not directly attributable to our operating segments.

[0001628280-23-037591:mdna:60]
(2)  Other charges, net for  the three months ended September 30, 2023 primarily relate to $2.9 million of incremental costs of sales related to components previously acquired from various brokers to satisfy customer demand. Other charges, net for the three months ended October 1, 2022 primarily relate to $7.3 million of charges to acquire components from various brokers to satisfy customer demand, $3.3 million of legal and professional fees, and $1.2 million of costs related to newly implemented employee benefit program.

[0001628280-23-037591:mdna:61]
(3) Other income, net for the three months ended September 30, 2023 includes $21.7 million of interest and investment income, offset by $0.5 million of net foreign exchange losses. Other income, net the three months ended October 1, 2022 includes $9.0 million of net foreign exchange gains and $4.8 million of interest and investment income.

[0001628280-23-037591:mdna:62]
Total segment profit decreased by $131.3 million, or 77.0%, during the three months ended September 30, 2023. Cloud & Networking segment profit decreased by $77.8 million, or 76.5%,  primarily due to lower revenue and the negative impact from factory underutilization as a result of a drop in demand as customers actively work to reduce their elevated inventory levels.  Industrial Tech segment profit decreased by $53.5 million, or 77.8%, primarily due to less profitable mix of products, including lower sales of higher margin imaging and sensing products, and increase in inventory excess and obsolescence charges due to customer demand change and transitions to the next generation of products.

[0001628280-23-037591:mdna:63]
[same as prior period, unchanged from 0001628280-23-016653:mdna:78]

[0001628280-23-037591:mdna:64]
R&D expense for the three months ended September 30, 2023 was generally consistent with the three months ended October 1, 2022, with a slight increase of  $0.8 million, or 1.1%.

[0001628280-23-037591:mdna:65]
We believe that continuing our investments in R&D is critical to attaining our strategic objectives. Despite signs of a challenging macroeconomic environment, we plan to continue to invest in R&D and new products that we believe will further differentiate us in the marketplace.

[0001628280-23-037591:mdna:66]
[same as prior period, unchanged from 0001628280-23-016653:mdna:82]

[0001628280-23-037591:mdna:67]
SG&A expense decreased by $32.7 million, or 30.9%, during the three months ended September 30, 2023 compared to the three months ended October 1, 2022, primarily driven by $15.7 million of lower stock-based compensation and $12.5 million of lower acquisition related costs. The higher stock-based compensation and acquisition related costs in the three months ended October 1, 2022 are primarily due to the NeoPhotonics merger in August 2022. In connection with the merger, certain equity awards for NeoPhotonics employees were accelerated, resulted in $11.9 million of stock-based compensation for the three months ended October 1, 2022.

[0001628280-23-037591:mdna:68]
From time to time, we incur expenses that are not part of our ordinary operations, such as mergers and acquisition-related and litigation expenses, which generally increase our SG&A expenses and potentially impact our profitability expectations in any particular period.

[0001628280-23-037591:mdna:69]
[same as prior period, unchanged from 0001628280-23-016653:mdna:86]

[0001628280-23-037591:mdna:70]
We have initiated various strategic restructuring events primarily intended to reduce costs, consolidate our operations, rationalize the manufacturing of our products, and align our business in response to market conditions and as a result of our merger with NeoPhotonics.

[0001628280-23-037591:mdna:71]
During the three months ended September 30, 2023, we recorded restructuring and related charges of $11.0 million in our condensed consolidated statements of operations, which was primarily due to company-wide  cost reduction initiatives,  as well as our integration efforts as a result of the merger with NeoPhotonics.

[0001628280-23-037591:mdna:72]
During the three months ended October 1, 2022, we recorded restructuring and related charges of $9.3 million, which was primarily attributable to severance and employee-related benefits associated with NeoPhotonics’ executive severance and retention agreements. These retention agreements provide, under certain circumstances, for payments and benefits upon an involuntary termination of employment.

[0001628280-23-037591:mdna:73]
[same as prior period, unchanged from 0001628280-23-016653:mdna:91]

[0001628280-23-037591:mdna:74]
For the three months ended September 30, 2023 and October 1, 2022, we recorded interest expense of $9.7 million and $8.5 million, respectively, related to the amortization of the debt discount and issuance costs of our convertible notes. The increase in interest expense for the three months ended September 30, 2023 is due to our 2029 Notes (as defined below) issued in June 2023.

[0001628280-23-037591:mdna:75]
[same as prior period, unchanged from 0001628280-23-016653:mdna:93]

[0001628280-23-037591:mdna:76]
[same as prior period, unchanged from 0001628280-23-016653:mdna:94]

[0001628280-23-037591:mdna:77]
|  | Three Months Ended |  |  |  |  |
|  | September 30, 2023 |  | October 1, 2022 |  |  |  |  |  |  |
| Foreign exchange gains (losses), net | $ | (0.5) |  |  | $ | 9.0 |  |  |  |  |  |  |  |
| Interest and investment income | 21.7 |  |  | 4.8 |  |  |  |  |  |  |  |
| Total other income, net | $ | 21.2 |  |  | $ | 13.8 |  |  |  |  |  |  |  |

[0001628280-23-037591:mdna:78]
Other income, net for the three months ended September 30, 2023 increased by $7.4 million from the three months ended October 1, 2022,  due to an increase in interest and investment income of $16.9 million driven by an increase in interest rates on our fixed income securities, offset by a decrease in income from foreign exchange of $9.5 million as a result of the weakening of other foreign currencies relative to the U.S. dollar during the three months ended October 1, 2022.

[0001628280-23-037591:mdna:79]
Provision (Benefit) for Income Taxes

[0001628280-23-037591:mdna:80]
The following table summarizes provision (benefit) for income taxes for the periods presented (in millions):

[0001628280-23-037591:mdna:81]
|  | Three Months Ended |  |  |
|  | September 30, 2023 |  | October 1, 2022 |  |  |  |  |
| Income tax provision (benefit) | $ | (1.4) |  |  | $ | 19.2 |  |  |  |  |  |

[0001628280-23-037591:mdna:82]
We recorded a tax benefit of $1.4 million and a tax provision of $19.2 million for the three months ended September 30, 2023 and October 1, 2022, respectively. Our tax provision for the three months ended September 30, 2023 includes a discrete tax benefit of $1.8 million primarily related to a tax benefit from changes in prior year uncertain tax positions, partially offset by the tax expenses related to a shortfall in connection with stock-based compensation vested during the quarter and foreign return to provision differences. Our tax provision for the three months ended October 1, 2022 includes a discrete tax expense of $13.1 million, primarily related to the international restructuring and currency re-measurement of certain tax related accounts, partially offset by the tax benefit from tax rate changes.

[0001628280-23-037591:mdna:83]
Our estimated effective tax rate for fiscal 2024 differs from the 21% U.S. statutory rate primarily due to the income tax expense from foreign rate differential, non-deductible stock-based compensation and foreign income inclusions in the U.S., partially offset by the income tax benefit from various income tax credits.

[0001628280-23-037591:mdna:84]
Our provision for incomes taxes may be impacted by changes in the geographic mix of earnings, acquisitions, changes in the realizability of deferred tax assets, changes in our uncertain tax positions, the results of income tax audits, settlements with tax authorities, the expiration of statutes of limitations, the implementation of tax planning strategies, tax rulings, court decisions, and changes in tax laws and regulations.  It is also possible that significant negative or positive evidence may become available that causes us to change our conclusion regarding whether a valuation allowance is needed on certain of our deferred tax assets, which would affect our income tax provision in the period of such change.

[0001628280-23-037591:mdna:85]
We also evaluate changes to regulations and requirements in the international jurisdictions where we conduct our business. For additional information, refer to Part II Item 1A “Risk Factors”.

[0001628280-23-037591:mdna:86]
[same as prior period, unchanged from 0001628280-23-016653:mdna:104]

[0001628280-23-037591:mdna:87]
[same as prior period, unchanged from 0001628280-23-016653:mdna:105]

[0001628280-23-037591:mdna:88]
As of September 30, 2023 and July 1, 2023, our cash and cash equivalents were $861.6 million and $859.0 million, respectively. As of September 30, 2023 and July 1, 2023, our short-term investments of $1,082.7 million and $1,154.6 million, respectively, were all held in the United States. Cash equivalents and short-term investments are primarily comprised of money market funds, treasuries, agencies, high quality investment grade fixed income securities, certificates of deposit and commercial paper. Our investment policy and strategy provides for diversification of investments and is focused on the preservation of capital and supporting our liquidity requirements.

[0001628280-23-037591:mdna:89]
The total amount of cash held by the non-United States entities as of September 30, 2023 and July 1, 2023 was $234.2 million and $298.4 million, respectively, which was primarily held by entities incorporated in the United Kingdom, the British Virgin Islands, Japan, Hong Kong, China, Switzerland, the Cayman Islands, Thailand and Brazil. Although cash currently held in the United States, as well as cash generated in the United States from future operations, is expected to cover our normal operating requirements, a substantial amount of additional cash could be required for other purposes, such as capital expenditures to support our business and growth, including costs associated with increasing internal manufacturing capabilities, strategic transactions and partnerships, and future acquisitions.

[0001628280-23-037591:mdna:90]
Our intent is to indefinitely reinvest funds held outside the United States. Except for the funds held in the Cayman Islands, the British Virgin Islands, and Hong Kong, as well as certain subsidiaries in China and Japan, our current plans do not demonstrate a need to repatriate them to fund our domestic operations. However, if in the future, we encounter a significant need for liquidity domestically or at a particular location that we cannot fulfill through borrowings, equity offerings, or other internal or external sources, or the cost to bring back the money is not significant from a tax perspective, we may determine that cash repatriations are necessary or desirable. Repatriation could result in additional material taxes. These factors may cause us to have an overall tax rate higher than other companies or higher than our tax rates in the past. Additionally, if conditions warrant, we may seek to obtain additional financing through debt or equity sources. To the extent we issue additional shares, it may create dilution to our existing stockholders. However, any such financing may not be available on terms favorable to us or may not be available at all.

[0001628280-23-037591:mdna:91]
[same as prior period, unchanged from 0001628280-23-016653:mdna:110]

[0001628280-23-037591:mdna:92]
We believe that our cash and cash equivalents as of September 30, 2023 and cash flows from our operating activities will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months.

[0001628280-23-037591:mdna:93]
[same as prior period, unchanged from 0001628280-23-016653:mdna:112]

[0001628280-23-037591:mdna:94]
•global economic conditions which affect demand for our products and services and impact the financial stability of our suppliers and customers, including the impact of uncertainty in the banking and financial services industries;

[0001628280-23-037591:mdna:95]
[same as prior period, unchanged from 0001628280-23-016653:mdna:114]

[0001628280-23-037591:mdna:96]
[same as prior period, unchanged from 0001628280-23-016653:mdna:115]

[0001628280-23-037591:mdna:97]
[same as prior period, unchanged from 0001628280-23-016653:mdna:116]

[0001628280-23-037591:mdna:98]
[same as prior period, unchanged from 0001628280-23-016653:mdna:117]

[0001628280-23-037591:mdna:99]
[same as prior period, unchanged from 0001628280-23-016653:mdna:118]

[0001628280-23-037591:mdna:100]
[same as prior period, unchanged from 0001628280-23-016653:mdna:119]

[0001628280-23-037591:mdna:101]
[same as prior period, unchanged from 0001628280-23-016653:mdna:120]

[0001628280-23-037591:mdna:102]
[same as prior period, unchanged from 0001628280-23-016653:mdna:121]

[0001628280-23-037591:mdna:103]
[same as prior period, unchanged from 0001628280-23-016653:mdna:122]

[0001628280-23-037591:mdna:104]
[same as prior period, unchanged from 0001628280-23-016653:mdna:123]

[0001628280-23-037591:mdna:105]
[same as prior period, unchanged from 0001628280-23-016653:mdna:124]

[0001628280-23-037591:mdna:106]
•acquisitions or strategic transactions, in particular our recently completed acquisition of Cloud Light;

[0001628280-23-037591:mdna:107]
•the settlement of any conversion or redemption of our convertible notes in cash; and

[0001628280-23-037591:mdna:108]
[same as prior period, unchanged from 0001628280-23-016653:mdna:127]

[0001628280-23-037591:mdna:109]
[same as prior period, unchanged from 0001628280-23-016653:mdna:128]

[0001628280-23-037591:mdna:110]
The following table summarizes our contractual obligations as of September 30, 2023, and the effect such obligations are expected to have on our liquidity and cash flow (in millions):

[0001628280-23-037591:mdna:111]
|  | Payments due |
|  | Total |  | Less than 1 year |  | More than 1 year |  |  |  |  |
| Contractual Obligations |  |  |  |  |  |  |  |  |  |
| Asset retirement obligations | $ | 7.5 |  |  | $ | — |  |  | $ | 7.5 |  |  |  |  |  |
| Operating lease liabilities, including imputed interest (1) | 62.8 |  |  | 15.3 |  |  | 47.5 |  |  |  |  |  |
| Pension plan contributions (2) | 2.2 |  |  | 2.2 |  |  | — |  |  |  |  |  |
| Purchase obligations (3) | 395.0 |  |  | 360.6 |  |  | 34.4 |  |  |  |  |  |
| Convertible notes - principal (4) | 2,837.8 |  |  | 323.1 |  |  | 2,514.7 |  |  |  |  |  |
| Convertible notes - interest (4) | 99.4 |  |  | 19.3 |  |  | 80.1 |  |  |  |  |  |
| Total | $ | 3,404.7 |  |  | $ | 720.5 |  |  | $ | 2,684.2 |  |  |  |  |  |

[0001628280-23-037591:mdna:112]
(1) The amounts of operating lease liabilities do not include any sublease income amounts nor do they include payments for short-term leases or variable lease payments. As of September 30, 2023, we expect to receive sublease income of approximately $3.8 million over the sublease periods.

[0001628280-23-037591:mdna:113]
(2) The amount of pension plan contributions represents planned contributions to our defined benefit plans. Although additional future contributions will be required, the amount and timing of these contributions will be affected by actuarial assumptions, the actual rate of returns on plan assets, the level of market interest rates, legislative changes, and the amount of voluntary contributions to the plan. Any contributions for the following fiscal year and later will depend on the value of the plan assets in the future and thus are uncertain. As such, we have not included any amounts beyond one year in the table above.

[0001628280-23-037591:mdna:114]
(3) Purchase obligations represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Refer to “Note 14. Commitments and Contingencies” in the notes to condensed consolidated financial statements.

[0001628280-23-037591:mdna:115]
(4) The amounts related to convertible notes include principal and interest on our 0.25% Convertible Senior Notes due in 2024 (the “2024 Notes”), principal and interest on our 0.50% Convertible Senior Notes due 2026 (the “2026 Notes”), principal and interest on our 0.50% Convertible Senior Notes due 2028 (the “2028 Notes”), and principal and interest on our 1.50% Convertible Senior Notes due 2029 (the “2029 Notes”). The 2024 Notes have a maturity date of March 15, 2024, the 2026 Notes have a maturity date of December 15, 2026, the 2028 Notes have a maturity date of June 15, 2028, and the 2029 Notes have a maturity date of December 15, 2029. The principal balances of our convertible notes are reflected in the payment periods in the table above based on their respective contractual maturities assuming no conversions. Refer to “Note 9. Debt” in the notes to condensed consolidated financial statements.

[0001628280-23-037591:mdna:116]
[same as prior period, unchanged from 0001628280-23-016653:mdna:135]

[0001628280-23-037591:mdna:117]
[same as prior period, unchanged from 0001628280-23-016653:mdna:136]

[0001628280-23-037591:mdna:118]
As of September 30, 2023, the net carrying amount of our 2029 Notes of $598.8 million (principal balance of $603.7 million maturing in 2029) is presented in non-current liabilities. If the closing price of our stock exceeds $90.40 (or 130% of the conversion price of $69.54) for 20 of the last 30 trading days of any future quarter, the 2029 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our consolidated balance sheets.

[0001628280-23-037591:mdna:119]
As of September 30, 2023, our 2028 Notes of $855.9 million (which have an aggregate principal amount of $861.0 million outstanding that matures in 2028) is presented in non-current liabilities in our condensed consolidated balance sheets. If the closing price of our stock exceeds $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of any future fiscal quarter, our 2028 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-23-037591:mdna:120]
As of September 30, 2023, our 2026 Notes of $1,046.2 million (which have an aggregate principal amount of $1,050.0 million outstanding that matures in 2026) is presented in non-current liabilities in our condensed consolidated balance sheets. If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future fiscal quarter, our 2026 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-23-037591:mdna:121]
As of September 30, 2023, our 2024 Notes of $315.7 million (which have an aggregate principal amount of $323.1 million outstanding that matures in 2024) is presented in current liabilities in our condensed consolidated balance sheets, as the debt will mature on March 15, 2024. Since issuing the 2024 Notes, we have converted a total of approximately $1.9 million principal amount of the 2024 Notes.

[0001628280-23-037591:mdna:122]
Share Buyback Program

[0001628280-23-037591:mdna:123]
We have a share buyback program that authorizes us to utilize up to an aggregate amount of $1.2 billion to purchase our own shares of common stock through May 2025. During the three months ended September 30, 2023, we did not repurchase any shares of our common stock. During the three months ended October 1, 2022, we repurchased 0.3 million shares of our common stock at an average price of $89.80 per share for an aggregate purchase price of $25.7 million. Since the board of directors initially approved the share buyback program, we have repurchased 7.7 million shares in aggregate at an average price of $81.66 per share for a total purchase price of $630.4 million. We recorded the $630.4 million aggregate purchase price as a reduction of retained earnings within our condensed consolidated balance sheet. All repurchased shares were retired immediately. As of September 30, 2023, we have $569.6 million remaining under the share buyback program.

[0001628280-23-037591:mdna:124]
The price, timing, amount, and method of future repurchases will be determined based on the valuation of market conditions and other factors, at prices determined to be attractive and in the best interests of both the Company and our stockholders. The stock repurchase program may be suspended or terminated at any time.

[0001628280-23-037591:mdna:125]
[same as prior period, unchanged from 0001628280-23-016653:mdna:146]

[0001628280-23-037591:mdna:126]
As of September 30, 2023 and July 1, 2023, our other non-current liabilities include unrecognized tax benefit for uncertain tax positions of $59.5 million and $64.4 million, respectively. We are unable to reliably estimate the timing of future payments related to uncertain tax positions.

[0001628280-23-037591:mdna:127]
[same as prior period, unchanged from 0001628280-23-016653:mdna:148]

[0001628280-23-037591:mdna:128]
Our balance of cash and cash equivalents increased by $2.6 million from $859.0 million as of July 1, 2023 to $861.6 million as of September 30, 2023. The increase in cash and cash equivalents during the three months ended September 30, 2023 was due to cash from investing activities of $17.8 million, offset by cash used in financing activities of $12.9 million and cash used in operating activities of $2.3 million.

[0001628280-23-037591:mdna:129]
[same as prior period, unchanged from 0001628280-23-016653:mdna:150]

[0001628280-23-037591:mdna:130]
Cash used in operating activities was $2.3 million during the three months ended September 30, 2023, which reflects a net loss of $67.9 million and non-cash items of $89.9 million for the three months ended September 30, 2023, offset by $24.3 million changes in our operating assets and liabilities. Changes in our operating assets and liabilities were mainly driven by an increase in inventories of $16.8 million primarily due to purchases made to support our manufacturing transition and lower shipments than expected, a decrease in accounts payable of $28.0 million primarily due to lower purchases from our contract manufactures and linearity of payments, and a decrease in income taxes of $19.9 million due to annual income tax payment in Japan, offset by a decrease in accounts receivable of $26.1 million due to lower revenue.

[0001628280-23-037591:mdna:131]
Cash provided by operating activities was $20.8 million during the three months ended October 1, 2022, which reflects a net loss of $0.4 million and non-cash items of $111.7 million for the three months ended October 1, 2022, offset by $90.5 million changes in our operating assets and liabilities. Changes in our operating assets and liabilities were mainly driven by an increase in inventory by $24.6 million primarily due to prebuild inventory and safety stock as a result of supply constraints and a decrease in accounts payable by $41.1 million primarily due to lower purchases.

[0001628280-23-037591:mdna:132]
[same as prior period, unchanged from 0001628280-23-016653:mdna:153]

[0001628280-23-037591:mdna:133]
Cash provided by investing activities of $17.8 million during the three months ended September 30, 2023 was attributable to the net proceeds from sales or maturities of short-term investments of $78.6 million partially offset by capital expenditures of $57.8 million and a $3.0 million payment for an intangible asset acquisition.

[0001628280-23-037591:mdna:134]
Cash used in investing activities of $646.6 million during the three months ended October 1, 2022 was attributable to the acquisition of NeoPhotonics and IPG telecom transmission product lines in the amount of $860.8 million, net of cash acquired, and capital expenditures of $22.9 million, partially offset by net proceeds from sales or maturities of short-term investments of $237.1 million.

[0001628280-23-037591:mdna:135]
[same as prior period, unchanged from 0001628280-23-016653:mdna:156]

[0001628280-23-037591:mdna:136]
Cash used in financing activities of $12.9 million during the three months ended September 30, 2023 was attributable to tax payments related to net share settlement of restricted stock of $12.9 million.

[0001628280-23-037591:mdna:137]
Cash used in financing activities of $59.1 million during the three months ended October 1, 2022 was driven by the repurchase of shares of our common stock of $35.8 million and tax payments related to net share settlement of restricted stock of $22.4 million.
