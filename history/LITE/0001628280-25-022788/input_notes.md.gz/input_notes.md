# LITE notes — 0001628280-25-022788


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001628280-25-022788:notes:1]
[same as prior period, unchanged from 0001628280-25-004288:notes:1]

[0001628280-25-022788:notes:2]
[same as prior period, unchanged from 0001628280-25-004288:notes:2]

[0001628280-25-022788:notes:3]
[same as prior period, unchanged from 0001628280-25-004288:notes:3]

[0001628280-25-022788:notes:4]
[same as prior period, unchanged from 0001628280-25-004288:notes:4]

[0001628280-25-022788:notes:5]
[same as prior period, unchanged from 0001628280-25-004288:notes:5]

[0001628280-25-022788:notes:6]
[same as prior period, unchanged from 0001628280-25-004288:notes:6]

[0001628280-25-022788:notes:7]
[same as prior period, unchanged from 0001628280-25-004288:notes:7]

[0001628280-25-022788:notes:8]
Our business and operating results depend significantly on general market and economic conditions. The current global macroeconomic environment is volatile and continues to be adversely impacted by many factors including inflation, a dynamic supply chain and demand environment, trade wars, including heightened, scheduled, or threatened tariffs, trade restrictions including for certain rare earth minerals, and signs of a weaker macroeconomic environment impacting capital expenditures across our served markets. Additionally, instability in the global credit markets, capital expenditure reductions, unemployment and other labor issues, decline in stock markets, the instability in the geopolitical environment in many parts of the world, and the current global economic challenges continue to put pressure on our business and operating results.

[0001628280-25-022788:notes:9]
The Company is actively monitoring and assessing the ongoing global trade environment, particularly with respect to recent changes in tariff regulations. We have assessed the potential impacts of heightened restrictions and tariffs on our allowance for credit losses, the carrying value of our goodwill and other long-lived assets, inventory valuation, and revenue recognition.  While we have determined there was not a material impact to our condensed consolidated financial statements as of March 29, 2025 and for the quarter ended March 29, 2025, import tariffs implemented by the U.S. and other countries, as currently in effect and/or proposed, could have a material impact on our results for the remainder of 2025 and in the future. The impact of tariffs is dependent upon negotiations with customers and suppliers and other mitigation efforts and potential further changes in global trade policies, including higher tariffs in the U.S. or other countries.

[0001628280-25-022788:notes:10]
[same as prior period, unchanged from 0001628280-25-004288:notes:10]

[0001628280-25-022788:notes:11]
[same as prior period, unchanged from 0001628280-25-004288:notes:11]

[0001628280-25-022788:notes:12]
[same as prior period, unchanged from 0001628280-25-004288:notes:12]

[0001628280-25-022788:notes:13]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2025 is a 52-week year ending on June 28, 2025, with the quarter ended March 29, 2025 being a 13-week quarterly period. Our fiscal 2024 was a 52-week year that ended on June 29, 2024, with the quarter ended March 30, 2024 being a 13-week quarterly period.

[0001628280-25-022788:notes:14]
[same as prior period, unchanged from 0001628280-25-004288:notes:14]

[0001628280-25-022788:notes:15]
[same as prior period, unchanged from 0001628280-25-004288:notes:15]

[0001628280-25-022788:notes:16]
[same as prior period, unchanged from 0001628280-25-004288:notes:16]

[0001628280-25-022788:notes:17]
The condensed consolidated financial statements and accompanying notes should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the fiscal year ended June 29, 2024. There were no significant changes to our accounting policies during the nine months ended March 29, 2025.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001628280-25-022788:notes:18]
Note 2. Recently Issued Accounting Pronouncements

[0001628280-25-022788:notes:19]
In November 2024, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2024-03, Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40), which requires disaggregation of certain expense captions into specified categories in disclosures within the footnotes to the financial statements. In January 2025, the FASB issued ASU No. 2025-01, which revises the effective date of ASU 2024-03, to clarify that all public business entities are required to adopt the guidance in annual reporting periods beginning after December 15, 2026, and interim periods within annual reporting periods beginning after December 15, 2027, with early adoption permitted.  We plan to adopt ASU 2024-04 in the first quarter of fiscal year 2027. We are currently evaluating the impact of this ASU on our financial statements and disclosures.

[0001628280-25-022788:notes:20]
In November 2024, the FASB issued ASU No. 2024-04, Debt with Conversion and Other Options (Subtopic 470-20): Induced Conversions of Convertible Debt Instruments, which clarify the requirements related to accounting for the settlement of a debt as an induced conversion. ASU 2024-04 is intended to improve the relevance and consistency in application of the induced conversion guidance in Subtopic 470-20 for convertible debt instruments with cash conversion features and debt instruments that are not currently convertible.  ASU 2024-04 is effective for fiscal years beginning after December 15, 2025, with early adoption permitted. We plan to adopt ASU 2024-04 in the first quarter of fiscal year 2026. We are currently evaluating the impact of this ASU on our financial statements and disclosures.

[0001628280-25-022788:notes:21]
In March 2024, the FASB issued ASU 2024-02: Codification Improvements - Amendments to Remove References to the Concepts Statements, which contains amendments to the Codification that remove references to various FASB Concepts Statements.  ASU 2024-02 is effective for fiscal years beginning after December 15, 2024, with early adoption permitted. We do not expect this ASU to have a material impact on our consolidated financial statements and disclosures.

[0001628280-25-022788:notes:22]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which requires disaggregated information about a reporting entity’s effective tax rate reconciliation as well as information on income tax paid. ASU 2023-09 is effective for fiscal years beginning after December 15, 2024, with early adoption permitted. We are currently evaluating the impact of this ASU on our income tax disclosures within the consolidated financial statements.

[0001628280-25-022788:notes:23]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which updates reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses. ASU 2023-07 does not change how a public entity identifies its operating segments, aggregates those operating segments, or applies quantitative thresholds to determine its reportable segments. The update is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. The amendments should be applied retrospectively to all prior periods presented in the financial statements. We plan to adopt ASU 2023-07 in the fiscal fourth quarter of 2025. We are currently evaluating the impact of adopting this ASU on our consolidated financial statements and disclosures.


## us-gaap:EarningsPerShareTextBlock

[0001628280-25-022788:notes:24]
[same as prior period, unchanged from 0001628280-25-004288:notes:24]

[0001628280-25-022788:notes:25]
[same as prior period, unchanged from 0001628280-25-004288:notes:25]

[0001628280-25-022788:notes:26]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29, 2025 |  | March 30, 2024 |  | March 29, 2025 |  | March 30, 2024 |
| Numerator: |  |  |  |  |  |  |  |
| Net loss - basic and diluted | $ | (44.1) |  |  | $ | (127.0) |  |  | $ | (187.4) |  |  | $ | (294.0) |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average common shares outstanding - basic and diluted | 69.3 |  |  | 67.5 |  |  | 68.8 |  |  | 67.1 |  |
| Net loss per share: |  |  |  |  |  |  |  |
| Basic | $ | (0.64) |  |  | $ | (1.88) |  |  | $ | (2.72) |  |  | $ | (4.38) |  |
| Diluted | $ | (0.64) |  |  | $ | (1.88) |  |  | $ | (2.72) |  |  | $ | (4.38) |  |

[0001628280-25-022788:notes:27]
Anti-dilutive shares excluded from the calculation of diluted net loss per share for the three months ended March 29, 2025 include 4.2 million shares issuable under restricted stock units (“RSUs”) and performance stock units (“PSUs”), 0.1 million shares issuable under the Employee Stock Purchase Plan (the “ESPP”), and 0.8 million shares outstanding related to stock options.  In addition, the calculation of diluted net loss per share excludes the impact of our convertible notes under the if-converted method as we recognized net loss. Average anti-dilutive shares excluded from the calculation of diluted net loss per share for the nine months ended March 29, 2025 include 0.6 million shares related to convertible notes, 4.5 million shares issuable under RSUs and PSUs, 0.1 million shares issuable under the ESPP, and 0.9 million shares outstanding related to stock options. Refer to “Note 13. Equity.”

[0001628280-25-022788:notes:28]
Anti-dilutive shares excluded from the calculation of diluted net loss per share for the three months ended March 30, 2024 include 30.3 million shares related to convertible notes, 3.9 million shares issuable under RSUs and PSUs, 0.2 million shares issuable under the ESPP, and 1.1 million shares outstanding related to stock options. Average anti-dilutive shares excluded from the calculation of diluted net loss per share for the nine months ended March 30, 2024 include 30.9 million shares related to convertible notes, 4.3 million shares issuable under RSUs and PSUs, 0.2 million shares issuable under the ESPP, and 1.1 million shares outstanding related to stock options.
Potentially dilutive common shares issuable upon conversion of our outstanding convertible notes are determined using the if-converted method.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001628280-25-022788:notes:29]
[same as prior period, unchanged from 0001628280-25-004288:notes:29]

[0001628280-25-022788:notes:30]
[same as prior period, unchanged from 0001628280-25-004288:notes:30]

[0001628280-25-022788:notes:31]
[same as prior period, unchanged from 0001628280-25-004288:notes:31]

[0001628280-25-022788:notes:32]
[same as prior period, unchanged from 0001628280-25-004288:notes:32]

[0001628280-25-022788:notes:33]
[same as prior period, unchanged from 0001628280-25-004288:notes:33]

[0001628280-25-022788:notes:34]
[same as prior period, unchanged from 0001628280-25-004288:notes:34]

[0001628280-25-022788:notes:35]
[same as prior period, unchanged from 0001628280-25-004288:notes:35]

[0001628280-25-022788:notes:36]
[same as prior period, unchanged from 0001628280-25-004288:notes:36]

[0001628280-25-022788:notes:37]
We incurred a total of $9.6 million of acquisition-related costs in fiscal year 2024, of which $9.4 million was incurred during the nine months ended March 30, 2024, representing professional and other direct acquisition costs, which are recorded as selling, general and administrative expense in the condensed consolidated statement of operations when incurred.

[0001628280-25-022788:notes:38]
[same as prior period, unchanged from 0001628280-25-004288:notes:38]

[0001628280-25-022788:notes:39]
[same as prior period, unchanged from 0001628280-25-004288:notes:39]

[0001628280-25-022788:notes:40]
[same as prior period, unchanged from 0001628280-25-004288:notes:40]

[0001628280-25-022788:notes:41]
[same as prior period, unchanged from 0001628280-25-004288:notes:41]

[0001628280-25-022788:notes:42]
Due to the integration of the combined businesses, including our sales and customer service organizations, operations teams and manufacturing facilities, it is impracticable to determine Cloud Light’s contribution to our revenue and earnings for the three and nine months ended March 29, 2025.

[0001628280-25-022788:notes:43]
[same as prior period, unchanged from 0001628280-25-004288:notes:43]

[0001628280-25-022788:notes:44]
The following supplemental pro forma information presents the combined results of operations for the three and nine months ended March 29, 2025 and March 30, 2024, as if the acquisition was completed on July 3, 2022, the first day of the fiscal year 2023. The supplemental pro forma financial information presented below is not necessarily indicative of the financial position or results of operations that would have been realized if the acquisition had been completed on the date indicated. The supplemental pro forma financial information does not reflect synergies that might have been achieved, nor is it indicative of future operating results or financial position.

[0001628280-25-022788:notes:45]
[same as prior period, unchanged from 0001628280-25-004288:notes:45]

[0001628280-25-022788:notes:46]
[same as prior period, unchanged from 0001628280-25-004288:notes:46]

[0001628280-25-022788:notes:47]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29, 2025 |  | March 30, 2024 |  | March 29, 2025 |  | March 30, 2024 |
| Net revenue | $ | 425.2 |  |  | $ | 366.5 |  |  | $ | 1,164.3 |  |  | $ | 1,139.6 |  |
| Net loss | $ | (43.9) |  |  | $ | (122.8) |  |  | $ | (181.1) |  |  | $ | (282.7) |  |


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001628280-25-022788:notes:48]
[same as prior period, unchanged from 0001628280-25-004288:notes:48]

[0001628280-25-022788:notes:49]
[same as prior period, unchanged from 0001628280-25-004288:notes:49]

[0001628280-25-022788:notes:50]
|  | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| March 29, 2025: |  |  |  |  |  |  |  |
| Cash | $ | 355.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 355.1 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 1.0 |  |  | — |  |  | — |  |  | 1.0 |  |
| Money market funds | 138.5 |  |  | — |  |  | — |  |  | 138.5 |  |
| U.S. Treasury securities | 21.8 |  |  | — |  |  | — |  |  | 21.8 |  |
| Total cash and cash equivalents | $ | 516.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 516.4 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Commercial paper | $ | 1.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 1.3 |  |
| Corporate debt securities | 211.6 |  |  | 0.3 |  |  | (0.1) |  |  | 211.8 |  |
| U.S. Agency securities | 65.6 |  |  | 0.1 |  |  | (0.1) |  |  | 65.6 |  |
| U.S. Treasury securities | 71.5 |  |  | 0.1 |  |  | — |  |  | 71.6 |  |
| Total short-term investments | $ | 350.0 |  |  | $ | 0.5 |  |  | $ | (0.2) |  |  | $ | 350.3 |  |
| June 29, 2024: |  |  |  |  |  |  |  |
| Cash | $ | 196.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 196.9 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 15.9 |  |  | — |  |  | — |  |  | 15.9 |  |
| Money market funds | 223.9 |  |  | — |  |  | — |  |  | 223.9 |  |
| Total cash and cash equivalents | $ | 436.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 436.7 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 0.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 0.8 |  |
| Commercial paper | 12.6 |  |  | — |  |  | — |  |  | 12.6 |  |
| Corporate debt securities | 244.5 |  |  | — |  |  | (0.6) |  |  | 243.9 |  |
| U.S. Agency securities | 81.2 |  |  | — |  |  | (0.3) |  |  | 80.9 |  |
| U.S. Treasury securities | 112.6 |  |  | — |  |  | (0.5) |  |  | 112.1 |  |
| Total short-term investments | $ | 451.7 |  |  | $ | — |  |  | $ | (1.4) |  |  | $ | 450.3 |  |

[0001628280-25-022788:notes:51]
[same as prior period, unchanged from 0001628280-25-004288:notes:51]

[0001628280-25-022788:notes:52]
We use the specific-identification method to determine any realized gains or losses from the sale of our short-term investments classified as available-for-sale. During the three and nine months ended March 29, 2025 and March 30, 2024, we did not realize significant gains or losses on a gross level from the sale of our short-term investments classified as available-for-sale.

[0001628280-25-022788:notes:53]
During the three and nine months ended March 29, 2025, our other income, net was $4.2 million and $27.8 million, respectively, which includes interest and investment income on cash equivalents and short-term investments of $7.8 million and $26.2 million, respectively.

[0001628280-25-022788:notes:54]
During the three and nine months ended March 30, 2024, our other income, net was $16.2 million and $50.8 million, respectively, which includes interest and investment income on cash equivalents and short-term investments of $12.6 million and $51.4 million, respectively.

[0001628280-25-022788:notes:55]
As of March 29, 2025 and June 29, 2024, we recorded interest receivables of $4.8 million and $5.8 million, respectively, in prepayments and other current assets within the condensed consolidated balance sheets. We did not recognize an allowance for credit losses against interest receivables in any of the periods presented, as there were no such losses.

[0001628280-25-022788:notes:56]
[same as prior period, unchanged from 0001628280-25-004288:notes:56]

[0001628280-25-022788:notes:57]
|  | Continuous Loss Position for More Than 12 Months |  | Continuous Loss Position for Less Than 12 Months |  | Gross Unrealized Losses |  |  |  |  |  |  |  |  |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |  |
| March 29, 2025: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | — |  |  | $ | — |  |  | $ | 26.2 |  |  | $ | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 2.3 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 4.3 |  |  | — |  |  | 72.3 |  |  | (0.1) |  |  | (0.1) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | — |  |  | — |  |  | 29.8 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | 4.3 |  |  | $ | — |  |  | $ | 130.6 |  |  | $ | (0.1) |  |  | $ | (0.1) |  |  |  |  |  |  |  |  |  |
| June 29, 2024: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 62.3 |  |  | $ | (0.3) |  |  | $ | 12.6 |  |  | $ | — |  |  | $ | (0.3) |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 28.6 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 133.7 |  |  | (0.5) |  |  | 90.6 |  |  | (0.2) |  |  | (0.7) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 72.3 |  |  | (0.4) |  |  | 39.7 |  |  | (0.1) |  |  | (0.5) |  |  |  |  |  |  |  |  |  |
| Total | $ | 268.3 |  |  | $ | (1.2) |  |  | $ | 171.5 |  |  | $ | (0.3) |  |  | $ | (1.5) |  |  |  |  |  |  |  |  |  |

[0001628280-25-022788:notes:58]
[same as prior period, unchanged from 0001628280-25-004288:notes:58]

[0001628280-25-022788:notes:59]
|  | March 29, 2025 |  | June 29, 2024 |
|  | Amortized Cost |  | Fair Value |  | Amortized Cost |  | Fair Value |
| Due within 1 year | $ | 161.0 |  |  | $ | 161.1 |  |  | $ | 405.5 |  |  | $ | 404.1 |  |
| Due in 1 year to 5 years | 189.0 |  |  | 189.2 |  |  | 46.2 |  |  | 46.2 |  |
| Total | $ | 350.0 |  |  | $ | 350.3 |  |  | $ | 451.7 |  |  | $ | 450.3 |  |

[0001628280-25-022788:notes:60]
[same as prior period, unchanged from 0001628280-25-004288:notes:60]


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-25-022788:notes:61]
[same as prior period, unchanged from 0001628280-25-004288:notes:61]

[0001628280-25-022788:notes:62]
[same as prior period, unchanged from 0001628280-25-004288:notes:62]

[0001628280-25-022788:notes:63]
[same as prior period, unchanged from 0001628280-25-004288:notes:63]

[0001628280-25-022788:notes:64]
[same as prior period, unchanged from 0001628280-25-004288:notes:64]

[0001628280-25-022788:notes:65]
[same as prior period, unchanged from 0001628280-25-004288:notes:65]

[0001628280-25-022788:notes:66]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| March 29, 2025: (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | — |  |  | $ | 1.0 |  |  | $ | — |  |  | $ | 1.0 |  |
| Money market funds | 138.5 |  |  | — |  |  | — |  |  | 138.5 |  |
| U.S. Treasury securities | 21.8 |  |  | — |  |  | — |  |  | 21.8 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | 1.3 |  |  | — |  |  | 1.3 |  |
| Corporate debt securities | — |  |  | 211.8 |  |  | — |  |  | 211.8 |  |
| U.S. Agency securities | — |  |  | 65.6 |  |  | — |  |  | 65.6 |  |
| U.S. Treasury securities | 71.6 |  |  | — |  |  | — |  |  | 71.6 |  |
| Total assets | $ | 231.9 |  |  | $ | 279.7 |  |  | $ | — |  |  | $ | 511.6 |  |

[0001628280-25-022788:notes:67]
(1)  Excludes $355.1 million in cash held in our bank accounts as of March 29, 2025.

[0001628280-25-022788:notes:68]
[same as prior period, unchanged from 0001628280-25-004288:notes:68]

[0001628280-25-022788:notes:69]
[same as prior period, unchanged from 0001628280-25-004288:notes:69]

[0001628280-25-022788:notes:70]
[same as prior period, unchanged from 0001628280-25-004288:notes:70]

[0001628280-25-022788:notes:71]
[same as prior period, unchanged from 0001628280-25-004288:notes:71]

[0001628280-25-022788:notes:72]
[same as prior period, unchanged from 0001628280-25-004288:notes:72]

[0001628280-25-022788:notes:73]
|  | March 29, 2025 |  | June 29, 2024 |
|  | Carrying Amount |  | Estimated Fair Value |  | Carrying Amount |  | Estimated Fair Value |
| 2029 Notes | $ | 600.1 |  |  | $ | 716.1 |  |  | $ | 599.4 |  |  | $ | 588.8 |  |
| 2028 Notes | 857.4 |  |  | 798.3 |  |  | 856.6 |  |  | 680.2 |  |
| 2026 Notes | 1,048.0 |  |  | 1,091.7 |  |  | 1,047.2 |  |  | 948.3 |  |
|  | $ | 2,505.5 |  |  | $ | 2,606.1 |  |  | $ | 2,503.2 |  |  | $ | 2,217.3 |  |

[0001628280-25-022788:notes:74]
[same as prior period, unchanged from 0001628280-25-004288:notes:74]

[0001628280-25-022788:notes:75]
[same as prior period, unchanged from 0001628280-25-004288:notes:75]

[0001628280-25-022788:notes:76]
Management utilizes various valuation methods, including an income approach, a market approach and a cost approach, to estimate the fair value of intangibles and other long-lived assets. During the annual impairment testing performed in the fourth quarter of fiscal 2024, we concluded that there was no impairment of our intangible and other long-lived assets. We review our intangible and other long-lived assets for impairment at least annually in the fourth quarter of each fiscal year, absent any interim indicators of impairment. There were no indicators of impairment during the three and nine months ended March 29, 2025.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-25-022788:notes:77]
[same as prior period, unchanged from 0001628280-25-004288:notes:77]

[0001628280-25-022788:notes:78]
[same as prior period, unchanged from 0001628280-25-004288:notes:78]

[0001628280-25-022788:notes:79]
We did not have any allowance for credit losses other than our allowance for uncollectible accounts receivable. As of March 29, 2025 and June 29, 2024, the allowance for credit losses on our trade receivables was $3.6 million and $0.2 million, respectively.

[0001628280-25-022788:notes:80]
[same as prior period, unchanged from 0001628280-25-004288:notes:80]

[0001628280-25-022788:notes:81]
[same as prior period, unchanged from 0001628280-25-004288:notes:81]

[0001628280-25-022788:notes:82]
|  | March 29, 2025 |  | June 29, 2024 |
| Raw materials and purchased parts | $ | 227.8 |  |  | $ | 196.9 |  |
| Work in process | 141.2 |  |  | 101.6 |  |
| Finished goods | 53.9 |  |  | 99.9 |  |
| Inventories | $ | 422.9 |  |  | $ | 398.4 |  |

[0001628280-25-022788:notes:83]
[same as prior period, unchanged from 0001628280-25-004288:notes:83]

[0001628280-25-022788:notes:84]
[same as prior period, unchanged from 0001628280-25-004288:notes:84]

[0001628280-25-022788:notes:85]
|  | March 29, 2025 |  | June 29, 2024 |
| Land | $ | 108.6 |  |  | $ | 75.2 |  |
| Buildings and improvements | 241.6 |  |  | 215.1 |  |
| Machinery and equipment | 802.2 |  |  | 772.1 |  |
| Computer equipment and software | 43.2 |  |  | 44.9 |  |
| Furniture and fixtures | 13.9 |  |  | 14.3 |  |
| Leasehold improvements | 44.4 |  |  | 47.5 |  |
| Construction in progress | 167.9 |  |  | 71.1 |  |
|  | 1,421.8 |  |  | 1,240.2 |  |
| Less: Accumulated depreciation | (728.5) |  |  | (667.7) |  |
| Property, plant and equipment, net | $ | 693.3 |  |  | $ | 572.5 |  |

[0001628280-25-022788:notes:86]
[same as prior period, unchanged from 0001628280-25-004288:notes:86]

[0001628280-25-022788:notes:87]
On December 17, 2024, we entered into an agreement to sell our net assets in an entity in Shenzhen, China. On March 5, 2025, we completed the sale and received net proceeds of $47.8 million, which was net of cash of $17.6 million and direct selling costs of $1.1 million. The net assets sold consist primarily of building, building improvements and land rights as of December 17, 2024 with a net carrying value of $12.9 million, and were used by the Cloud and Networking segment for manufacturing and research and development activities. As a result, we recognized a gain on sale of facility of $34.9 million, which was recorded in our condensed consolidated statements of operations for the three and nine months ended March 29, 2025. We paid $4.4 million of withholding taxes on this sale transaction, which is recorded as part of the income tax provision for the three and nine months ended March 29, 2025. We also incurred $0.4 million and $0.7 million of indirect selling expenses related to this transaction, which was recorded as part of selling, general and administrative expenses in our condensed consolidated statements of operations for the three and nine months ended March 29, 2025.

[0001628280-25-022788:notes:88]
[same as prior period, unchanged from 0001628280-25-004288:notes:89]

[0001628280-25-022788:notes:89]
[same as prior period, unchanged from 0001628280-25-004288:notes:90]

[0001628280-25-022788:notes:90]
During the three and nine months ended March 29, 2025, we recorded depreciation expense of $25.0 million and $77.9 million, respectively.

[0001628280-25-022788:notes:91]
[same as prior period, unchanged from 0001628280-25-004288:notes:92]

[0001628280-25-022788:notes:92]
[same as prior period, unchanged from 0001628280-25-004288:notes:93]

[0001628280-25-022788:notes:93]
|  | March 29, 2025 |  | June 29, 2024 |
| Operating lease right-of-use assets | $ | 64.6 |  |  | $ | 112.3 |  |
| Less: accumulated amortization | (32.4) |  |  | (39.5) |  |
| Operating lease right-of-use assets, net | $ | 32.2 |  |  | $ | 72.8 |  |

[0001628280-25-022788:notes:94]
In connection with our integration efforts to consolidate our sites, we recorded restructuring charges for various sites and reduced our operating lease right-of-use assets by $6.2 million during the nine months ended March 29, 2025.

[0001628280-25-022788:notes:95]
[same as prior period, unchanged from 0001628280-25-004288:notes:96]

[0001628280-25-022788:notes:96]
[same as prior period, unchanged from 0001628280-25-004288:notes:97]

[0001628280-25-022788:notes:97]
[same as prior period, unchanged from 0001628280-25-004288:notes:98]

[0001628280-25-022788:notes:98]
[same as prior period, unchanged from 0001628280-25-004288:notes:99]

[0001628280-25-022788:notes:99]
[same as prior period, unchanged from 0001628280-25-004288:notes:100]

[0001628280-25-022788:notes:100]
|  | March 29, 2025 |  | June 29, 2024 |
| Restructuring accrual and related charges (1) | $ | 1.9 |  |  | $ | 11.1 |  |
| Warranty reserve (2) | 13.0 |  |  | 13.2 |  |
| Deferred revenue and customer deposits | 0.7 |  |  | 0.6 |  |
| Income tax payable (3) | 27.1 |  |  | 13.2 |  |
| Other current liabilities | 7.2 |  |  | 3.0 |  |
| Other current liabilities | $ | 49.9 |  |  | $ | 41.1 |  |

[0001628280-25-022788:notes:101]
[same as prior period, unchanged from 0001628280-25-004288:notes:102]

[0001628280-25-022788:notes:102]
(2) Refer to “Note 14. Commitments and Contingencies.”

[0001628280-25-022788:notes:103]
[same as prior period, unchanged from 0001628280-25-004288:notes:104]

[0001628280-25-022788:notes:104]
[same as prior period, unchanged from 0001628280-25-004288:notes:105]

[0001628280-25-022788:notes:105]
[same as prior period, unchanged from 0001628280-25-004288:notes:106]

[0001628280-25-022788:notes:106]
|  | March 29, 2025 |  | June 29, 2024 |
| Asset retirement obligations | $ | 7.0 |  |  | $ | 7.5 |  |
| Pension and related accruals (1) | 6.9 |  |  | 7.5 |  |
| Unrecognized tax benefit (2) | 76.1 |  |  | 83.0 |  |
| Other non-current liabilities (2) | 24.9 |  |  | 5.4 |  |
| Other non-current liabilities | $ | 114.9 |  |  | $ | 103.4 |  |

[0001628280-25-022788:notes:107]
(1) We have defined benefit pension plans in Japan, Switzerland, and Thailand. Pension and related accrual of $6.9 million as of March 29, 2025 represents $8.4 million of non-current portion of benefit obligation, offset by $1.5 million  of funding for the pension plan in Switzerland. Pension and related accrual of $7.5 million as of June 29, 2024 relates to $8.6 million of non-current portion of benefit obligation, offset by $1.2 million of funding for the pension plan in Switzerland. We typically re-evaluate the assumptions related to the fair value of our defined benefit obligations annually in the fiscal fourth quarter and make any updates as necessary. During the three and nine months ended March 29, 2025, our contribution expense to the 401(k) Plan in the United States was $1.1 million and $2.4 million, respectively. During the three and nine months ended March 30, 2024, our contribution expense to the 401(k) Plan in the United States was $1.3 million and $2.8 million, respectively. Our contribution expense to all defined contribution plans outside the United States were $2.3 million and $6.1 million during the three and nine months ended March 29, 2025, respectively. Our contribution expense to all defined contribution plans outside the United States were $2.1 million and $6.0 million during the three and nine months ended March 30, 2024, respectively.
 (2) The Company has reclassified a $21.4 million unrecognized tax position to other non-current liabilities in the condensed consolidated balance sheets as of March 29, 2025 for an indemnification liability related to the sale of certain assets. This does not impact our results of operations for the three months ended March 29, 2025.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001628280-25-022788:notes:108]
[same as prior period, unchanged from 0001628280-25-004288:notes:109]

[0001628280-25-022788:notes:109]
[same as prior period, unchanged from 0001628280-25-004288:notes:110]

[0001628280-25-022788:notes:110]
[same as prior period, unchanged from 0001628280-25-004288:notes:111]

[0001628280-25-022788:notes:111]
The following table presents goodwill by reportable segments as of March 29, 2025 and June 29, 2024 (in millions):

[0001628280-25-022788:notes:112]
|  | Cloud & Networking |  | Industrial Tech |  | Total |
| Balances as of June 29, 2024 | $ | 1,044.6 |  |  | $ | 11.2 |  |  | $ | 1,055.8 |  |
| Acquisition of Cloud Light (1) | 5.1 |  |  | — |  |  | 5.1 |  |
| Balances as of March 29, 2025 | $ | 1,049.7 |  |  | $ | 11.2 |  |  | $ | 1,060.9 |  |

[0001628280-25-022788:notes:113]
(1) During the nine months ended March 29, 2025, prior to the measurement period, we adjusted the purchase price allocation and recorded a $5.1 million increase to goodwill. The primary adjustment to the opening balance sheet relates to income tax liabilities which were not known in previous periods.

[0001628280-25-022788:notes:114]
[same as prior period, unchanged from 0001628280-25-004288:notes:115]

[0001628280-25-022788:notes:115]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. In the fourth quarter of fiscal 2024, we completed the annual impairment test of goodwill, which indicated there was no goodwill impairment. There were no indicators of goodwill impairment during the three and nine months ended March 29, 2025.

[0001628280-25-022788:notes:116]
[same as prior period, unchanged from 0001628280-25-004288:notes:117]

[0001628280-25-022788:notes:117]
[same as prior period, unchanged from 0001628280-25-004288:notes:118]

[0001628280-25-022788:notes:118]
[same as prior period, unchanged from 0001628280-25-004288:notes:119]

[0001628280-25-022788:notes:119]
During the annual impairment testing performed in the fourth quarter of fiscal 2024, we concluded that our intangible and other long-lived assets were not impaired at the asset group level. We review our intangible and other long-lived assets for impairment at least annually in the fourth quarter of each fiscal year, absent any interim indicators of impairment. There were no indicators of impairment at the asset group level during the three and nine months ended March 29, 2025.

[0001628280-25-022788:notes:120]
[same as prior period, unchanged from 0001628280-25-004288:notes:121]

[0001628280-25-022788:notes:121]
[same as prior period, unchanged from 0001628280-25-004288:notes:122]

[0001628280-25-022788:notes:122]
[same as prior period, unchanged from 0001628280-25-004288:notes:123]

[0001628280-25-022788:notes:123]
[same as prior period, unchanged from 0001628280-25-004288:notes:124]

[0001628280-25-022788:notes:124]
| March 29, 2025 | Gross Carrying Amounts |  | Accumulated Amortization |  | Net Carrying Amounts |  | Weighted Average Remaining Amortization Period (Years) |
| Acquired developed technologies | $ | 818.1 |  |  | $ | (538.7) |  |  | $ | 279.4 |  |  | 4.3 |
| Customer relationships | 419.8 |  |  | (212.3) |  |  | 207.5 |  |  | 4.3 |
| In-process research and development | 12.9 |  |  | — |  |  | 12.9 |  |  | n/a |
| Order backlog | 14.0 |  |  | (14.0) |  |  | — |  |  | — |
| Trade name and trademarks | 3.0 |  |  | (3.0) |  |  | — |  |  | — |
| Total intangible assets | $ | 1,267.8 |  |  | $ | (768.0) |  |  | $ | 499.8 |  |  |  |

[0001628280-25-022788:notes:125]
[same as prior period, unchanged from 0001628280-25-004288:notes:126]

[0001628280-25-022788:notes:126]
[same as prior period, unchanged from 0001628280-25-004288:notes:127]

[0001628280-25-022788:notes:127]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29, 2025 |  | March 30, 2024 |  | March 29, 2025 |  | March 30, 2024 |
| Cost of sales | $ | 19.0 |  |  | $ | 22.3 |  |  | $ | 62.9 |  |  | $ | 61.8 |  |
| Research and development | 0.4 |  |  | 0.4 |  |  | 1.2 |  |  | 1.1 |  |
| Selling, general and administrative | 15.0 |  |  | 19.4 |  |  | 51.0 |  |  | 45.8 |  |
| Total amortization of intangibles | $ | 34.4 |  |  | $ | 42.1 |  |  | $ | 115.1 |  |  | $ | 108.7 |  |

[0001628280-25-022788:notes:128]
Based on the carrying amount of our acquired intangible assets except in-process research and development as of March 29, 2025, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001628280-25-022788:notes:129]
| Fiscal Years |  |
| Remainder of 2025 | $ | 34.2 |  |
| 2026 | 133.3 |  |
| 2027 | 121.0 |  |
| 2028 | 81.5 |  |
| 2029 | 51.8 |  |
| Thereafter | 65.1 |  |
| Total future amortization | $ | 486.9 |  |


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0001628280-25-022788:notes:130]
[same as prior period, unchanged from 0001628280-25-004288:notes:131]


## us-gaap:DebtDisclosureTextBlock

[0001628280-25-022788:notes:131]
Note 9. Debt

[0001628280-25-022788:notes:132]
Our debt consists of the following:

[0001628280-25-022788:notes:133]
|  | March 29, 2025 |  | June 29, 2024 |
|  | Short-term |  | Long-term |  | Total |  | Short-term |  | Long-term |  | Total |
| Convertible notes | $ | — |  |  | $ | 2,505.5 |  |  | $ | 2,505.5 |  |  | $ | — |  |  | $ | 2,503.2 |  |  | $ | 2,503.2 |  |
| Term loans | 10.3 |  |  | 56.9 |  |  | 67.2 |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 10.3 |  |  | $ | 2,562.4 |  |  | $ | 2,572.7 |  |  | $ | — |  |  | $ | 2,503.2 |  |  | $ | 2,503.2 |  |

[0001628280-25-022788:notes:134]
Convertible Notes

[0001628280-25-022788:notes:135]
2029 Notes

[0001628280-25-022788:notes:136]
On June 16, 2023, we issued $603.7 million in aggregate principal amount of 1.50% Convertible Senior Notes due in 2029 (“2029 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended. The 2029 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association, (as successor in interest to U.S. Bank National Association), as a trustee (the “2029 Indenture”). The 2029 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-25-022788:notes:137]
The net proceeds from the sale of the 2029 Notes was $599.4 million, after deducting $4.3 million of net issuance costs. In addition, we incurred $0.8 million of professional fees directly related to this transaction. Concurrent with the issuance of the 2029 Notes, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 0.25% convertible senior notes due in 2024 and $125.0 million of the net proceeds to repurchase our common stock in privately negotiated transactions. We intend to use the remaining net proceeds for general corporate purposes, which may include the repayment of our indebtedness, including any of our existing convertible notes, capital expenditures, working capital and potential acquisitions.

[0001628280-25-022788:notes:138]
The 2029 Notes bear interest at a rate of 1.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year. The 2029 Notes will mature on December 15, 2029, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-25-022788:notes:139]
The initial conversion rate is 14.3808 shares of common stock per $1,000 principal amount of the 2029 Notes (which is equivalent to an initial conversion price of approximately $69.54 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2029 Indenture but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2029 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-25-022788:notes:140]
Prior to the close of business on the business day immediately preceding September 15, 2029, holders of the 2029 Notes may convert their 2029 Notes only under the following circumstances:

[0001628280-25-022788:notes:141]
•during any fiscal quarter commencing after September 30, 2023 (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price of the 2029 Notes, or $90.40, on each applicable trading day;

[0001628280-25-022788:notes:142]
•during the five consecutive business day period after any five consecutive trading day period (the “2029 measurement period”) in which the trading price per $1,000 principal amount of 2029 Notes for each trading day of the 2029 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day;

[0001628280-25-022788:notes:143]
•if we call any or all of the 2029 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the redemption date; or

[0001628280-25-022788:notes:144]
•upon the occurrence of specified corporate events as specified in the 2029 Indenture.

[0001628280-25-022788:notes:145]
On or after September 15, 2029 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2029 Notes at any time. Following our irrevocable settlement method election made on September 25, 2024, upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2029 Notes by delivering cash equal to the principal amount of such converted 2029 Notes and cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof.

[0001628280-25-022788:notes:146]
We may redeem for cash all or any portion of the 2029 Notes, at our option (subject to the partial redemption limitation set forth in the 2029 Indenture), on or after June 22, 2026, if the last reported sale price of our  common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide notice of redemption at a redemption price equal to 100% of the principal amount of the 2029 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2029 Notes. If we elect to redeem fewer than all of the outstanding 2029 Notes, at least $100.0 million aggregate principal amount of the 2029 Notes must be outstanding and not subject to redemption as of the redemption notice date. Upon the occurrence of a fundamental change (as defined in the 2029 Indenture), holders may require us to repurchase all or a portion of their 2029 Notes for cash at a price equal to 100% of the principal amount of the 2029 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-25-022788:notes:147]
The entire 2029 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of March 29, 2025 and June 29, 2024, measured at amortized cost.

[0001628280-25-022788:notes:148]
2028 Notes

[0001628280-25-022788:notes:149]
In March 2022, we issued $861.0 million in aggregate principal amount of 0.50% Convertible Senior Notes due in 2028 (the “2028 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2028 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2028 Indenture”). The 2028 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-25-022788:notes:150]
The net proceeds from the sale of the 2028 Notes was $854.8 million, after deducting $6.2 million in issuance costs. In addition, we incurred $0.7 million in professional fees in connection with this transaction. Concurrent with the issuance of the 2028 Notes, we used $200.0 million of the net proceeds to repurchase our common stock in privately negotiated transactions.

[0001628280-25-022788:notes:151]
The 2028 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year. The 2028 Notes will mature on June 15, 2028, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-25-022788:notes:152]
The initial conversion rate is 7.6319 shares of common stock per $1,000 principal amount of the 2028 Notes (which is equivalent to an initial conversion price of approximately $131.03 per share). The conversion rate is subject to adjustment upon the occurrence of certain specified events, but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2028 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2028 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-25-022788:notes:153]
Prior to the close of business on the business day immediately preceding March 15, 2028, holders of the 2028 Notes may convert their 2028 Notes only under the following circumstances:

[0001628280-25-022788:notes:154]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price, or $170.34, on each applicable trading day;

[0001628280-25-022788:notes:155]
•during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the 2028 Notes for each trading day of such measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the applicable conversion rate on each such trading day;

[0001628280-25-022788:notes:156]
•if the Company calls any or all of the 2028 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the redemption date; or

[0001628280-25-022788:notes:157]
•upon the occurrence of specified corporate events, as specified in the 2028 Indenture.

[0001628280-25-022788:notes:158]
On or after March 15, 2028 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2028 Notes at any time. Following our irrevocable settlement method election made on September 25, 2024, upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2028 Notes by delivering cash equal to the principal amount of such converted 2028 Notes and cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof.

[0001628280-25-022788:notes:159]
We may redeem for cash all or any portion of the 2028 Notes, at our option (subject to the partial redemption limitation set forth in the 2028 Indenture), on or after June 20, 2025, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the 2028 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2028 Notes. If we elect to redeem fewer than all of the outstanding 2028 Notes, at least $100.0 million aggregate principal amount of the 2028 Notes must be outstanding and not subject to redemption as of the redemption notice date. Upon the occurrence of a fundamental change (as defined in the 2028 Indenture), holders may require the Company to repurchase all or a portion of their 2028 Notes for cash at a price equal to 100% of the principal amount of the 2028 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-25-022788:notes:160]
We initially bifurcated the principal amount of the 2028 Notes into liability and equity components. The liability component of the 2028 Notes was initially valued at $629.8 million based on the contractual cash flow discounted at an appropriate comparable market on non-convertible debt borrowing rate at the date of issuance, which was 5.7%, with the equity component representing the residual amount of the proceeds of $231.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2028 Notes were accounted for as a single liability measured at amortized cost. The entire 2028 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of March 29, 2025 and June 29, 2024, measured at amortized cost.

[0001628280-25-022788:notes:161]
2026 Notes

[0001628280-25-022788:notes:162]
In December 2019, we issued $1,050.0 million in aggregate principal amount of 0.50% Convertible Senior Notes due in 2026 (the “2026 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2026 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association as successor in interest to U.S. Bank National Association, as trustee (as supplemented by the First Supplemental Indenture, dated as of September 25, 2024, the “2026 Indenture”). We used approximately $196.0 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan credit facility, and a portion of the net proceeds of the offering to purchase approximately $200.0 million of our common stock concurrently with the pricing of the offering in privately negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-25-022788:notes:163]
The 2026 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year. The 2026 Notes will mature on December 15, 2026, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-25-022788:notes:164]
The initial conversion rate is 10.0711 shares of common stock per $1,000 principal amount of the 2026 Notes (which is equivalent to an initial conversion price of approximately $99.29 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2026 Indenture but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2026 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares set forth in the 2026 Indenture or a holder that elects to convert the 2026 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-25-022788:notes:165]
Prior to the close of business on the business day immediately preceding September 15, 2026, holders of the 2026 Notes may convert their 2026 Notes only under the following circumstances:

[0001628280-25-022788:notes:166]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price of the 2026 Notes, or $129.08 on each applicable trading day;

[0001628280-25-022788:notes:167]
•during the five consecutive business day period after any five consecutive trading day period (the “2026 measurement period”) in which the trading price per $1,000 principal amount of the 2026 Notes for each trading day of the 2026 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the 2026 Notes on each such trading day;

[0001628280-25-022788:notes:168]
•if we call any or all of the 2026 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the relevant redemption date; or

[0001628280-25-022788:notes:169]
•upon the occurrence of specified corporate events.

[0001628280-25-022788:notes:170]
On or after September 15, 2026 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2026 Notes at any time. Following our entry into the First Supplemental Indenture, dated as of September 25, 2024, to the 2026 Indenture, upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2026 Notes by delivering cash equal to the principal amount of such converted 2026 Notes and cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof.

[0001628280-25-022788:notes:171]
We may redeem for cash, all or any portion of the 2026 Notes, at our option, on or after December 20, 2023, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide a notice of redemption at a redemption price equal to 100% of the principal amount of the 2026 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2026 Notes. Upon the occurrence of a fundamental change (as defined in the 2026 Indenture), holders may require us to repurchase all or a portion of the 2026 Notes for cash at a price equal to 100% of the principal amount of the 2026 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-25-022788:notes:172]
We initially bifurcated the principal amount of the 2026 Notes into liability and equity components. The liability component of the 2026 Notes was initially valued at $734.8 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 5.8% with the equity component representing the residual amount of the proceeds of $315.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2026 Notes were accounted for as a single liability measured at amortized cost. The entire 2026 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of March 29, 2025 and June 29, 2024, measured at amortized cost.

[0001628280-25-022788:notes:173]
2024 Notes

[0001628280-25-022788:notes:174]
In March 2017, we issued $450.0 million in aggregate principal amount of 0.25% convertible senior notes due in 2024 (the “2024 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes were governed by an indenture between the Company, as the issuer, and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2024 Indenture”). The 2024 Notes were unsecured and did not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-25-022788:notes:175]
The 2024 Notes bore interest at a rate of 0.25% per year. Interest on the 2024 Notes was payable semi-annually in arrears on March 15 and September 15 of each year. The 2024 Notes matured on March 15, 2024.

[0001628280-25-022788:notes:176]
Concurrent with the issuance of the 2029 Notes in June 2023, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 2024 Notes, which we accounted for as an extinguishment of liability. $13.5 million of the $132.8 million repurchase price was allocated to the conversion feature of the repurchased 2024 Notes, representing the fair value of the conversion feature at the date of the repurchase, and was recognized as a reduction of the stockholders’ equity. Additionally, since issuing the 2024 Notes, we converted a total of approximately $1.9 million of principal amount of the 2024 Notes, with less than $0.1 million of principle amount converted during the three and nine months ended March 29, 2025.

[0001628280-25-022788:notes:177]
On March 15, 2024, the 2024 Notes maturity date, we fully repaid the remaining principal amount of $323.1 million. The conversion feature previously classified within stockholder’s equity was fully amortized as of the maturity date.

[0001628280-25-022788:notes:178]
Our convertible notes consisted of the following components as of the periods presented (in millions):

[0001628280-25-022788:notes:179]
| March 29, 2025 |  |  | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | Total |  |  |  |  |  |
| Principal |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,514.7 |  |  |  |  |  |  |
| Unamortized debt discount and debt issuance costs |  |  | (2.0) |  |  | (3.6) |  |  | (3.6) |  |  | (9.2) |  |  |  |  |  |  |
| Net carrying amount of the liability component |  |  | $ | 1,048.0 |  |  | $ | 857.4 |  |  | $ | 600.1 |  |  | $ | 2,505.5 |  |  |  |  |  |  |

[0001628280-25-022788:notes:180]
| June 29, 2024 |  |  | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | Total |
| Principal |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,514.7 |  |
| Unamortized debt discount and debt issuance costs |  |  | (2.8) |  |  | (4.4) |  |  | (4.3) |  |  | (11.5) |  |
| Net carrying amount of the liability component |  |  | $ | 1,047.2 |  |  | $ | 856.6 |  |  | $ | 599.4 |  |  | $ | 2,503.2 |  |

[0001628280-25-022788:notes:181]
(1) If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future fiscal quarter, our 2026 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-25-022788:notes:182]
(2) If the closing price of our stock exceeds $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of any future fiscal quarter, our 2028 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-25-022788:notes:183]
(3) If the closing price of our stock exceeds $90.40 (or 130% of the conversion price of $69.54) for 20 of the last 30 trading days of any future quarter, our 2029 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our consolidated balance sheets.

[0001628280-25-022788:notes:184]
The following table sets forth interest expense information related to the convertible notes for the periods presented (in millions):

[0001628280-25-022788:notes:185]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29, 2025 |  | March 30, 2024 |  | March 29, 2025 |  | March 30, 2024 |
| Contractual interest expense | $ | 4.7 |  |  | $ | 4.9 |  |  | $ | 14.0 |  |  | $ | 14.6 |  |
| Amortization of the debt discount and debt issuance costs | 0.8 |  |  | 4.1 |  |  | 2.3 |  |  | 13.8 |  |
| Total interest expense | $ | 5.5 |  |  | $ | 9.0 |  |  | $ | 16.3 |  |  | $ | 28.4 |  |

[0001628280-25-022788:notes:186]
The future interest and principal payments related to our convertible notes are as follows as of March 29, 2025 (in millions):

[0001628280-25-022788:notes:187]
| Fiscal Years |  |  | 2026 Notes |  | 2028 Notes |  | 2029 Notes |  | Total |
| 2025 |  |  | $ | 2.7 |  |  | $ | 2.2 |  |  | $ | 4.6 |  |  | $ | 9.5 |  |
| 2026 |  |  | 5.3 |  |  | 4.3 |  |  | 9.1 |  |  | 18.7 |  |
| 2027 |  |  | 1,052.5 |  |  | 4.3 |  |  | 9.1 |  |  | 1,065.9 |  |
| 2028 |  |  | — |  |  | 865.3 |  |  | 9.1 |  |  | 874.4 |  |
| 2029 |  |  | — |  |  | — |  |  | 617.1 |  |  | 617.1 |  |
| Total payments |  |  | $ | 1,060.5 |  |  | $ | 876.1 |  |  | $ | 649.0 |  |  | $ | 2,585.6 |  |

[0001628280-25-022788:notes:188]
The principal balances of our convertible notes are reflected in the payment periods in the table above based on their respective contractual maturities.

[0001628280-25-022788:notes:189]
Term Loans

[0001628280-25-022788:notes:190]
SMBC Term Loan

[0001628280-25-022788:notes:191]
On August 9, 2024, the Company entered into a term loan agreement (the “SMBC Term Loan”) with Sumitomo Mitsui Banking Corporation (“SMBC”). The SMBC Term Loan provides an aggregate principal amount of 6.4 billion Japanese yen (“JPY”). The loan requires monthly principal payments of approximately 53.3 million JPY, from August 31, 2024 to June 30, 2029 and interest based on a fixed annual interest rate of 0.88%, with the remaining principal of approximately 3.3 billion JPY due on the loan maturity date of July 31, 2029. Under the loan agreement, the Company cannot prepay the outstanding loan without SMBC’s approval.  In the event the Company prepays the outstanding loan with SMBC’s approval, the Company shall pay SMBC a settlement amount calculated pursuant to the terms of the loan agreement. The SMBC Term Loan is secured by the real estate owned in Sagamihara, Japan.

[0001628280-25-022788:notes:192]
As of March 29, 2025, the Company had $40.2 million in principal amount outstanding, of which the short-term portion of $4.3 million is recorded as current liabilities while the long-term portion of $35.9 million is recorded as long-term debt in the Company’s condensed consolidated balance sheets.

[0001628280-25-022788:notes:193]
Mizuho Term Loan

[0001628280-25-022788:notes:194]
On September 20, 2024, the Company entered into a term loan agreement (the “Mizuho Term Loan”) with Mizuho Bank, Ltd. (“Mizuho”), in order to finance our planned manufacturing expansions. The Mizuho Term Loan provides for borrowings of 4.5 billion JPY with a 5-year term from the funding date September 20, 2024. The loan requires quarterly principal payments of approximately 225.0 million JPY commencing on December 20, 2024 with the final payment on September 20, 2029. The Mizuho Term Loan bears interest at a fixed annual rate of 0.90%. The Mizuho Term Loan is secured by the real estate assets owned by NeoPhotonics Semiconductor GK. The Mizuho Term Loan agreement requires that the Company and certain domestic subsidiaries comply with covenants relating to customary matters, including obtaining approval from Mizuho prior to transferring, creating a security interest, or disposing of the collateral assets; obtaining approval from Mizuho prior to a business transfer, business acquisition, corporate reorganization or changes such as mergers, company splits, share exchanges or share transfers or capital structure changes; obtaining approval from Mizuho prior to changing the Company’s indirect ownership in Lumentum Japan, Inc; and obtaining approval from Mizuho prior to a distribution of dividends by Lumentum Japan, Inc. to its shareholders.

[0001628280-25-022788:notes:195]
As of March 29, 2025, the Company had $27.0 million in principal amount outstanding, of which the short-term portion of $6.0 million is recorded as current liabilities while the long-term portion of $21.0 million is recorded as long-term debt in the Company’s condensed consolidated balance sheets.
The SMBC Term Loan and the Mizuho Term Loan are collectively referred to as Japan Term Loans.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-25-022788:notes:196]
[same as prior period, unchanged from 0001628280-25-004288:notes:207]

[0001628280-25-022788:notes:197]
[same as prior period, unchanged from 0001628280-25-004288:notes:208]

[0001628280-25-022788:notes:198]
[same as prior period, unchanged from 0001628280-25-004288:notes:209]

[0001628280-25-022788:notes:199]
|  | Foreign Currency Translation Adjustments, Net of Tax (1) |  | Defined Benefit Obligations, Net of Tax (2) |  | Unrealized Gain (Loss) on Available-for-Sale Securities, Net of Tax (3) |  |  |  | Total |
| Beginning balance as of June 29, 2024 | $ | 9.8 |  |  | $ | 0.7 |  |  | $ | (1.2) |  |  |  |  | $ | 9.3 |  |
| Other comprehensive gain, net | — |  |  | — |  |  | 2.3 |  |  |  |  | 2.3 |  |
| Ending balance as of September 28, 2024 | $ | 9.8 |  |  | $ | 0.7 |  |  | $ | 1.1 |  |  |  |  | $ | 11.6 |  |
| Other comprehensive loss, net | (0.3) |  |  | — |  |  | (1.1) |  |  |  |  | (1.4) |  |
| Ending balance as of December 28, 2024 | $ | 9.5 |  |  | $ | 0.7 |  |  | $ | — |  |  |  |  | $ | 10.2 |  |
| Other comprehensive gain, net | 0.3 |  |  | — |  |  | 0.6 |  |  |  |  | 0.9 |  |
| Ending balance as of March 29, 2025 | $ | 9.8 |  |  | $ | 0.7 |  |  | $ | 0.6 |  |  |  |  | $ | 11.1 |  |
|  | Foreign Currency Translation Adjustments, Net of Tax (1) |  | Defined Benefit Obligations, Net of Tax (2) |  | Unrealized Gain (Loss) on Available-for-Sale Securities, Net of Tax (3) |  |  |  | Total |
| Beginning balance as of July 1, 2023 | $ | 10.4 |  |  | $ | (0.4) |  |  | $ | (5.9) |  |  |  |  | $ | 4.1 |  |
| Other comprehensive gain (loss), net | (0.2) |  |  | — |  |  | 1.3 |  |  |  |  | 1.1 |  |
| Ending balance as of September 30, 2023 | $ | 10.2 |  |  | $ | (0.4) |  |  | $ | (4.6) |  |  |  |  | $ | 5.2 |  |
| Other comprehensive gain, net | 0.2 |  |  | — |  |  | 3.8 |  |  |  |  | 4.0 |  |
| Ending balance as of December 30, 2023 | $ | 10.4 |  |  | $ | (0.4) |  |  | $ | (0.8) |  |  |  |  | $ | 9.2 |  |
| Other comprehensive loss, net | (0.1) |  |  | — |  |  | (0.3) |  |  |  |  | (0.4) |  |
| Ending balance as of March 30, 2024 | $ | 10.3 |  |  | $ | (0.4) |  |  | $ | (1.1) |  |  |  |  | $ | 8.8 |  |

[0001628280-25-022788:notes:200]
[same as prior period, unchanged from 0001628280-25-004288:notes:211]

[0001628280-25-022788:notes:201]
[same as prior period, unchanged from 0001628280-25-004288:notes:212]

[0001628280-25-022788:notes:202]
(3) For the three months ended March 29, 2025, December 28, 2024, and September 28, 2024, our unrealized loss on available-for-sale securities is presented net of tax of nil for all periods.

[0001628280-25-022788:notes:203]
For the three months ended March 30, 2024, December 30, 2023, and September 30, 2023, our unrealized loss on available-for-sale securities is presented net of tax of  $(0.1) million, $1.0 million, and $0.4 million, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-25-022788:notes:204]
[same as prior period, unchanged from 0001628280-25-004288:notes:215]

[0001628280-25-022788:notes:205]
[same as prior period, unchanged from 0001628280-25-004288:notes:216]

[0001628280-25-022788:notes:206]
[same as prior period, unchanged from 0001628280-25-004288:notes:217]

[0001628280-25-022788:notes:207]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29, 2025 |  | March 30, 2024 |  | March 29, 2025 |  | March 30, 2024 |
| Balance as of beginning of period | $ | 1.5 |  |  | $ | 10.2 |  |  | $ | 11.1 |  |  | $ | 5.0 |  |
| Charges | 7.2 |  |  | 19.2 |  |  | 17.6 |  |  | 36.0 |  |
| Payments and other adjustments | (6.8) |  |  | (11.7) |  |  | (26.8) |  |  | (23.3) |  |
| Balance as of end of period | $ | 1.9 |  |  | $ | 17.7 |  |  | $ | 1.9 |  |  | $ | 17.7 |  |

[0001628280-25-022788:notes:208]
During the three and nine months ended March 29, 2025, we recorded restructuring and related charges of $7.2 million and $17.6 million, respectively mainly due to our integration efforts and cost reduction initiatives. Restructuring charges for  the three months ended March 29, 2025 primarily related to $5.7 million of assets written-off including property, plant and equipment, prepayments and other current assets as well as $1.4 million of charges for other contractual commitments associated with site closures driven by restructuring initiatives announced in April 2025 that will allow us to focus on other market opportunities including cloud and AI markets.

[0001628280-25-022788:notes:209]
Restructuring charges for the nine months ended March 29, 2025 include $12.4 million of assets written-off including property, plant and equipment, prepayments and other current assets primarily due to efforts to consolidate our sites and focus on other market opportunities including cloud and AI markets. In addition, we also recorded $3.0 million of charges related to the discontinuation of our in-house development of coherent Digital Signal Processors (“DSPs”) and Radio Frequency Integrated Circuits (“RFICs”). Refer to Note 17. Subsequent Event for additional details.

[0001628280-25-022788:notes:210]
During the three and nine months ended March 30, 2024, we recorded restructuring and related charges of $19.2 million and $36.0 million, respectively, primarily due to company-wide cost reduction initiatives, as well as our integration efforts to consolidate our manufacturing sites.

[0001628280-25-022788:notes:211]
[same as prior period, unchanged from 0001628280-25-004288:notes:221]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-25-022788:notes:212]
[same as prior period, unchanged from 0001628280-25-004288:notes:222]

[0001628280-25-022788:notes:213]
Our tax provision for interim periods has generally been determined using an estimate of our annual effective tax rate, adjusted for discrete items, if any, that arise during the period.  However, when a reliable estimate cannot be made, the actual tax or benefit applicable may be reported as a discrete item in the interim period. For the three and nine months ended March 29, 2025, we concluded that the use of the discrete method was more appropriate than the annual effective tax rate method, because the estimated annual effective tax rate is not reliable due to its sensitivity to minimal changes in forecasted annual pre-tax earnings.  As a result, we have computed our tax provision using the discrete method as though the nine-month period was the annual period.

[0001628280-25-022788:notes:214]
We recorded a tax provision of $4.9 million and $26.7 million for the three and nine months ended March 29, 2025, respectively. Our tax provision for the three months ended March 29, 2025 is primarily attributable to the income tax expense from uncertain tax positions and withholding taxes, partially offset by the tax benefit from prior year changes in uncertain tax positions. Our tax provision for the nine months ended March 29, 2025 is primarily attributable to the income tax expense from pre-tax earnings, uncertain tax positions, interest on uncertain tax positions, foreign return to provision differences and withholding taxes, partially offset by the tax benefit from prior year changes in uncertain tax positions.

[0001628280-25-022788:notes:215]
We recorded a tax provision of $19.6 million and $15.8 million for the three and nine months ended March 30, 2024, respectively. Our tax provision for the three months ended March 30, 2024 includes a discrete tax expense of $17.6 million, primarily related to the establishment of a partial valuation allowance against certain deferred tax assets, withholding taxes, and changes in prior year uncertain tax positions, partially offset by the tax benefit of tax rate changes. Our tax provision for the nine months ended March 30, 2024 includes a discrete tax expense of $19.2 million, primarily related to the establishment of a partial valuation allowance against certain deferred tax assets, withholding taxes, a shortfall in connection with stock-based compensation vested during the period, and interest on uncertain tax positions, partially offset by the tax benefit from tax rate changes.

[0001628280-25-022788:notes:216]
Our estimated effective tax rate for the nine months ended March 29, 2025 differs from the 21% U.S. statutory rate primarily due to the income tax expense from foreign rate differential, non-deductible stock-based compensation, current year valuation allowance change, and foreign income inclusions in the U.S., partially offset by the income tax benefit from permanent items and U.S. tax credits.

[0001628280-25-022788:notes:217]
We regularly assess our ability to realize our deferred tax assets on a quarterly basis and will establish a valuation allowance if it is more-likely-than-not that some portion of the deferred tax assets will not be realized. As of March 29, 2025, we maintain a full valuation allowance on U.S. federal and state and certain foreign deferred tax assets. We will continue to assess the need for a valuation allowance against our remaining deferred tax assets and may increase or decrease our valuation allowance materially in the future.

[0001628280-25-022788:notes:218]
As of March 29, 2025, we had $76.1 million of unrecognized tax benefits, which, if recognized, would affect the effective tax rate. We are subject to examination of income tax returns by various domestic and foreign tax authorities. The timing of resolution and closure of these tax examinations is highly unpredictable. Although it is possible that certain ongoing tax examinations may be concluded within the next 12 months, we cannot reasonably estimate the impact to tax expense and net income from tax examinations that could be resolved or closed within the next 12 months. Subject to audit timing and uncertainty, we expect the amount of unrecognized tax benefit that would become recognized due to expiration of the statute of limitations and affect the effective tax rate to decrease by $2.4 million over the next 12 months.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-25-022788:notes:219]
[same as prior period, unchanged from 0001628280-25-004288:notes:229]

[0001628280-25-022788:notes:220]
[same as prior period, unchanged from 0001628280-25-004288:notes:230]

[0001628280-25-022788:notes:221]
[same as prior period, unchanged from 0001628280-25-004288:notes:231]

[0001628280-25-022788:notes:222]
[same as prior period, unchanged from 0001628280-25-004288:notes:232]

[0001628280-25-022788:notes:223]
In February 2025, our board of directors approved the 2025 Inducement Equity Incentive Plan (the “Inducement Plan”) in accordance with Listing Rule 5635(c)(4) of the corporate governance rules of the Nasdaq Stock Market, which became effective in February 2025. The Inducement Plan has substantially the same terms and conditions as the 2015 Plan,  however, the Inducement Plan may only be used for grants to new employees and not for existing employees, executives, directors or consultants.

[0001628280-25-022788:notes:224]
As of March 29, 2025, we had 5.0 million shares subject to stock options, restricted stock units, restricted stock awards, and performance stock units issued and outstanding under the 2015 Plan. Restricted stock units, restricted stock awards, and performance stock units are performance-based, time-based or a combination of both and are expected to vest within four years. The fair value of these grants is based on the closing market price of our common stock on the date of grant. The exercise price for stock options is equal to the fair value of the underlying stock at the date of grant. We issue new shares of common stock upon exercise of stock options. Options generally have vesting period of three years. As of March 29, 2025, 2.5 million shares of common stock under the 2015 Plan were available for grant.

[0001628280-25-022788:notes:225]
[same as prior period, unchanged from 0001628280-25-004288:notes:234]

[0001628280-25-022788:notes:226]
In connection with the acquisition of Cloud Light, each of Cloud Light’s outstanding options was exchanged for a combination of cash and options to acquire Lumentum common stock having equivalent value (the “replacement options”) using an exchange ratio of 0.04375 according to the terms in the Merger Agreement. At the Cloud Light Closing Date, the replacement options consisted of 1.1 million options with a weighted average grant date fair value of $34.63. These replacement options have a total fair value of $38.9 million as of the Cloud Light Closing date, of which $23.5 million attributed to pre-acquisition service was recorded as part of purchase price consideration and the remaining $15.4 million will be recorded as post-acquisition stock-based compensation expense over the vesting period of three years from the Cloud Light Closing Date. Refer to “Note 4. Business Combinations.”

[0001628280-25-022788:notes:227]
[same as prior period, unchanged from 0001628280-25-004288:notes:236]

[0001628280-25-022788:notes:228]
[same as prior period, unchanged from 0001628280-25-004288:notes:237]

[0001628280-25-022788:notes:229]
[same as prior period, unchanged from 0001628280-25-004288:notes:238]

[0001628280-25-022788:notes:230]
Restricted stock units (“RSUs”) under the 2015 Plan and the Inducement Plan are grants of shares of our common stock, the vesting of which is based on the requisite service requirement. Generally, our RSUs are subject to forfeiture and are expected to vest within four years. For annual grants to existing employees, RSUs generally vest ratably on an annual basis, or combination of annual and quarterly basis, over three years.

[0001628280-25-022788:notes:231]
During the nine months ended March 29, 2025, our board of directors approved grants of 1.8 million RSUs, which primarily vest over three years.

[0001628280-25-022788:notes:232]
[same as prior period, unchanged from 0001628280-25-004288:notes:241]

[0001628280-25-022788:notes:233]
Performance stock units (“PSUs”) under the 2015 Plan and the Inducement Plan are grants of shares of our common stock that vest upon the achievement of certain performance and service conditions. For PSUs with performance-based conditions, we begin recognizing compensation expense when we conclude that it is probable that the performance conditions will be achieved. We reassess the probability of vesting at each reporting period and adjust our compensation cost based on this probability assessment. For PSUs with market-based conditions, the compensation expense is recognized ratably over the requisite service period regardless of whether or not the market condition is satisfied, provided the requisite service is rendered. Our PSUs are subject to risk of forfeiture until performance and service conditions are satisfied and generally vest within three years.

[0001628280-25-022788:notes:234]
During the nine months ended March 29, 2025, we granted 0.7 million PSUs with an aggregate grant date fair value of $39.8 million to executive and non-executive employees as part of our Annual Incentive Plan (“AIP PSUs”). These AIP PSUs are subject to performance targets and service conditions, with a vesting period of one year. We also granted 0.4 million PSUs with an aggregate grant date fair value of $21.9 million to certain executive officers and senior management. These PSUs will vest subject to the achievement of revenue targets, certain non-financial performance measurements and the Company’s total shareholder return (or “TSR”) relative to a specified peer group, as well as service conditions, over three years. The number of shares may be increased or decreased based on the results of these measurement targets ranging between 0% and 300% in accordance with the terms established at the date of grant. Approximately 25% of the 0.4 million PSUs granted during the nine months ended March 29, 2025 will vest based on the Company’s relative TSR. The Company estimated the grant date fair value of TSR awards using a Monte-Carlo simulation model, which was calculated at $70.57 per share. Additionally, we also granted approximately 0.2 million PSUs with an aggregate grant date fair value of $17.4 million to our new President and Chief Executive Officer. These PSUs will vest subject to the achievement of the Company’s total shareholder return (or “TSR”) relative to a specified peer group, as well as service conditions, over four years. The number of shares may be increased or decreased based on the results of these measurement targets ranging between 0% and 200% in accordance with the terms established at the date of grant. The Company estimated the grant date fair value of TSR awards using a Monte-Carlo simulation model, which was calculated at $107.72 per share.

[0001628280-25-022788:notes:235]
[same as prior period, unchanged from 0001628280-25-004288:notes:244]

[0001628280-25-022788:notes:236]
Our ESPP provides eligible employees with the opportunity to acquire an ownership interest in the Company through periodic payroll deductions and provides a 15% purchase price discount as well as a 6-month look-back period. The ESPP is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986, as amended. The ESPP will terminate upon the date on which all shares available for issuance have been sold. Of the 3.0 million shares authorized under the ESPP, 0.5 million shares remained available for issuance as of March 29, 2025.

[0001628280-25-022788:notes:237]
[same as prior period, unchanged from 0001628280-25-004288:notes:246]

[0001628280-25-022788:notes:238]
[same as prior period, unchanged from 0001628280-25-004288:notes:247]

[0001628280-25-022788:notes:239]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29, 2025 |  | March 30, 2024 |  | March 29, 2025 |  | March 30, 2024 |
| Cost of sales | $ | 9.2 |  |  | $ | 8.5 |  |  | $ | 28.1 |  |  | $ | 23.5 |  |
| Research and development | 11.2 |  |  | 9.8 |  |  | 31.9 |  |  | 30.1 |  |
| Selling, general and administrative | 42.4 |  |  | 13.3 |  |  | 77.2 |  |  | 44.7 |  |
| Total stock-based compensation | $ | 62.8 |  |  | $ | 31.6 |  |  | $ | 137.2 |  |  | $ | 98.3 |  |

[0001628280-25-022788:notes:240]
Our stock-based compensation by equity awards for the periods presented were as follows (in millions):

[0001628280-25-022788:notes:241]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29, 2025 |  | March 30, 2024 |  | March 29, 2025 |  | March 30, 2024 |
| RSUs | $ | 31.5 |  |  | $ | 29.0 |  |  | $ | 80.3 |  |  | $ | 90.8 |  |
| AIP PSUs | 8.3 |  |  | — |  |  | 21.9 |  |  | — |  |
| TSR PSUs | 1.0 |  |  | — |  |  | 1.6 |  |  | — |  |
| Other PSUs | 19.4 |  |  | (0.9) |  |  | 24.7 |  |  | 3.6 |  |
| Total PSUs | 28.7 |  |  | (0.9) |  |  | 48.2 |  |  | 3.6 |  |
| Options | 1.3 |  |  | 1.3 |  |  | 3.9 |  |  | 2.0 |  |
| ESPP | 1.2 |  |  | 1.4 |  |  | 3.4 |  |  | 3.6 |  |
| Sub-total | 62.7 |  |  | 30.8 |  |  | 135.8 |  |  | 100.0 |  |
| Change in stock-based compensation capitalized to inventory | 0.1 |  |  | 0.8 |  |  | 1.4 |  |  | (1.7) |  |
| Total stock-based compensation | $ | 62.8 |  |  | $ | 31.6 |  |  | $ | 137.2 |  |  | $ | 98.3 |  |

[0001628280-25-022788:notes:242]
During the three and nine months ended March 29, 2025, we recorded $28.7 million and $48.2 million of stock-based compensation related to PSUs, respectively, which includes about $18.2 million of additional stock-compensation resulting from modifications as discussed below on both periods. During the three months ended March 30, 2024, we recorded $0.9 million of net reversal of stock-based compensation related to PSUs due to decline in anticipated achievement of performance conditions. During the nine months ended March 30, 2024, we recorded $3.6 million of stock-based compensation related to PSUs. For PSUs with performance-based conditions, the amount of stock-based compensation expense recognized in any one period related to PSUs can vary based on the achievement or anticipated achievement of the performance conditions. If the performance conditions are not met or not expected to be met, no compensation cost would be recognized on the underlying PSUs, and any previously recognized compensation expense related to those PSUs would be reversed.

[0001628280-25-022788:notes:243]
On February 2, 2025, the Company and our former President and Chief Executive Officer mutually agreed to modify the terms of previously granted equity awards by changing the level of remaining service condition required for vesting. In accordance with ASC 718, Compensation - Stock Compensation, the Company accounted for the change as a modification as the Company determined the remaining service conditions were non-substantive. For awards that vested on February 20, 2025, the separation date, we recognized compensation expense equal to the sum of the remaining unrecognized grant-date fair value amounting to $9.0 million during the three months ended March 29, 2025. For awards that will vest on December 15, 2025, the termination date, we recognized compensation expense equal to the sum of the remaining unrecognized grant-date fair value and any incremental fair value resulting from the modification of $19.2 million during the three months ended March 29, 2025. The modification date, for accounting purposes, was determined to be February 2, 2025, the date on which mutual agreement between the Company and employee was achieved. As February 2, 2025 was a non-trading day, the Company used observable market inputs as of January 31, 2025 (the most recent trading day prior to the modification date) to determine the fair value of the modified awards in accordance with fair value measurement principles under ASC 718.

[0001628280-25-022788:notes:244]
[same as prior period, unchanged from 0001628280-25-004288:notes:251]

[0001628280-25-022788:notes:245]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29, 2025 |  | March 30, 2024 |  | March 29, 2025 |  | March 30, 2024 |
| Income tax benefit associated with stock-based compensation | $ | 5.4 |  |  | $ | 3.6 |  |  | $ | 11.5 |  |  | $ | 6.1 |  |

[0001628280-25-022788:notes:246]
Approximately $13.0 million and $14.4 million of stock-based compensation was capitalized to inventory as of March 29, 2025 and June 29, 2024, respectively.

[0001628280-25-022788:notes:247]
As of March 29, 2025, $128.4 million of stock-based compensation cost related to RSU awards remains to be amortized, which is expected to be recognized over a weighted average amortization period of 2.0 years.

[0001628280-25-022788:notes:248]
[same as prior period, unchanged from 0001628280-25-004288:notes:255]

[0001628280-25-022788:notes:249]
The following table summarizes our award activities for the nine months ended March 29, 2025 (in millions):

[0001628280-25-022788:notes:250]
|  | Stock Options |  | Restricted Stock Units |  | Performance Stock Units |  |  |  |  |
|  | Number of Shares |  | Weighted-Average Exercise Price per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  |  |  |  |
| Balance as of June 29, 2024 | 1.1 |  |  | $ | 8.0 |  |  | 2.7 |  |  | $ | 62.5 |  |  | 0.9 |  |  | $ | 65.5 |  |  |  |  |  |
| Granted | — |  |  | — |  |  | 1.8 |  |  | 59.9 |  |  | 1.3 |  |  | 60.8 |  |  |  |  |  |
| Vested/Exercised | (0.3) |  |  | 7.8 |  |  | (1.5) |  |  | 64.4 |  |  | (0.2) |  |  | 83.5 |  |  |  |  |  |
| Canceled | — |  |  | — |  |  | (0.3) |  |  | 60.6 |  |  | (0.5) |  |  | 61.5 |  |  |  |  |  |
| Balance as of March 29, 2025 | 0.8 |  |  | $ | 8.0 |  |  | 2.7 |  |  | $ | 60.0 |  |  | 1.5 |  |  | $ | 61.2 |  |  |  |  |  |

[0001628280-25-022788:notes:251]
[same as prior period, unchanged from 0001628280-25-004288:notes:258]

[0001628280-25-022788:notes:252]
|  | Awards Available for Grant |
| Balance as of June 29, 2024 | 4.3 |  |
| Authorized | 0.5 |  |
| Granted | (3.1) |  |
| Canceled | 0.8 |  |
| Balance as of March 29, 2025 | 2.5 |  |

[0001628280-25-022788:notes:253]
[same as prior period, unchanged from 0001628280-25-004288:notes:260]

[0001628280-25-022788:notes:254]
The ESPP expense for the three and nine months ended March 29, 2025 was $1.2 million and $3.4 million, respectively. The ESPP expense for the three and nine months ended March 30, 2024 was $1.3 million and $3.6 million, respectively. The expense related to the ESPP is recorded on a straight-line basis over the relevant subscription period.

[0001628280-25-022788:notes:255]
During the nine months ended March 29, 2025 and March 30, 2024, there were 0.2 million and 0.2 million shares issued to employees through the ESPP, respectively.

[0001628280-25-022788:notes:256]
[same as prior period, unchanged from 0001628280-25-004288:notes:263]

[0001628280-25-022788:notes:257]
[same as prior period, unchanged from 0001628280-25-004288:notes:264]

[0001628280-25-022788:notes:258]
We have a share buyback program that authorizes us to utilize up to an aggregate amount of $1.2 billion to purchase our own shares of common stock through May 31, 2025. During the nine months ended March 29, 2025 and March 30, 2024, we did not repurchase any shares of our common stock. Since the board of directors initially approved the share buyback program, we have repurchased 7.7 million shares in aggregate at an average price of $81.66 per share for a total purchase price of $630.4 million. We recorded the $630.4 million aggregate purchase price as a reduction of retained earnings within our condensed consolidated balance sheet and immediately retired all repurchased shares. As of March 29, 2025, we have $569.6 million remaining under the share buyback program.

[0001628280-25-022788:notes:259]
The price, timing, amount, and method of future repurchases will be determined based on our evaluation of business and market conditions, alternative investment opportunities, and other factors, at prices determined to be attractive and in the best interests of both the Company and our stockholders. The stock repurchase program may be suspended or terminated at any time.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001628280-25-022788:notes:260]
Note 14. Commitments and Contingencies

[0001628280-25-022788:notes:261]
Purchase Obligations

[0001628280-25-022788:notes:262]
Our purchase obligations of $635.3 million as of March 29, 2025 represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001628280-25-022788:notes:263]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with these vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures. In addition, the imposition of tariffs on certain imported goods and materials may increase our costs and place upward pressure on the cost of goods sold.

[0001628280-25-022788:notes:264]
Product Warranties

[0001628280-25-022788:notes:265]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve-month warranty for most of our products. However, in some instances depending upon the product, product components or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products, and service delivery costs incurred in correcting product failures. In addition, from time-to-time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001628280-25-022788:notes:266]
The following table presents the changes in our warranty reserve for the periods presented (in millions):

[0001628280-25-022788:notes:267]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29, 2025 |  | March 30, 2024 |  | March 29, 2025 |  | March 30, 2024 |
| Balance as of beginning of period | $ | 12.8 |  |  | $ | 10.1 |  |  | $ | 13.2 |  |  | $ | 6.8 |  |
| Warranties assumed in Cloud Light acquisition | — |  |  | 3.0 |  |  | 0.8 |  |  | 8.2 |  |
| Provision for warranty | 1.8 |  |  | 2.6 |  |  | 6.2 |  |  | 3.6 |  |
| Utilization of reserve, net | (1.6) |  |  | (2.2) |  |  | (7.2) |  |  | (5.1) |  |
| Balance as of end of period | $ | 13.0 |  |  | $ | 13.5 |  |  | $ | 13.0 |  |  | $ | 13.5 |  |

[0001628280-25-022788:notes:268]
Environmental Liabilities

[0001628280-25-022788:notes:269]
Our research and development, manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental and product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001628280-25-022788:notes:270]
Legal Proceedings

[0001628280-25-022788:notes:271]
We are subject to a variety of claims and suits that arise from time-to-time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss. As of March 29, 2025, the accrual for expected settlement of litigation matters was not material.

[0001628280-25-022788:notes:272]
Oclaro Merger Litigation

[0001628280-25-022788:notes:273]
In connection with our acquisition of Oclaro in 2018, seven lawsuits were filed by purported stockholders of Oclaro challenging the proposed merger (the “Merger”). All but one was voluntarily dismissed after the Oclaro Merger closed. The remaining lawsuit, SaiSravan B. Karri v. Oclaro, Inc., et al., No. 3:18-cv-03435-JD (the “Karri Lawsuit”), was filed in the United States District Court for the Northern District of California and was styled as a class action.

[0001628280-25-022788:notes:274]
The Karri Lawsuit alleged, among other things, that Oclaro and its directors violated Section 14(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), and Rule 14a-9 promulgated thereunder by disseminating an incomplete and misleading Form S-4, including proxy statement/prospectus. The Karri Lawsuit further alleged that Oclaro’s directors violated Section 20(a) of the Exchange Act by failing to exercise proper control over the person(s) who violated Section 14(a) of the Exchange Act. The plaintiff in the Karri Lawsuit sought, among other things, damages to be awarded to the plaintiff and any class, if a class is certified, and litigation costs, including attorneys’ fees.

[0001628280-25-022788:notes:275]
The case proceeded through fact and expert discovery and the parties subsequently reached an agreement for a class-wide settlement of the Karri Lawsuit that provided for a payment of $15.3 million to the members of the class. On August 17, 2023, the court preliminarily approved the settlement. In March 2024, the court finally approved the settlement.

[0001628280-25-022788:notes:276]
We recorded the court approved settlement amount of $15.3 million as accrued expenses in our condensed consolidated balance sheet as of June 29, 2024, of which $7.5 million represents the amount to be reimbursed by insurance and was recorded as prepayments and other current assets. As of September 28, 2024, this litigation matter was settled and all amounts were paid.

[0001628280-25-022788:notes:277]
Regulatory Matters

[0001628280-25-022788:notes:278]
In August 2024, the Company received inquiries from the Bureau of Industry and Security of the U.S. Department of Commerce (“BIS”) and Department of Justice (“DOJ”) following the Company’s voluntary disclosure to BIS in December 2023, and supplemented in April 2024. The Company continues to cooperate with both agencies on this matter.  The Company is unable to predict the likely outcome of these matters.

[0001628280-25-022788:notes:279]
Indemnifications

[0001628280-25-022788:notes:280]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown, because claims may be made against us in the future, and we may record charges in the future as a result of these indemnification obligations. On March 5, 2025, we completed a sale of assets located in an entity in Shenzhen, China.  The Company has reclassified a $21.4 million unrecognized tax position to other non-current liabilities in the condensed consolidated balance sheets as of March 29, 2025 for an indemnification liability related to the sale of certain assets. This does not impact our results of operations for the three months ended March 29, 2025. We did not have any other material indemnification claims that were probable or reasonably possible.

[0001628280-25-022788:notes:281]
Audit Proceedings

[0001628280-25-022788:notes:282]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period when we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-25-022788:notes:283]
[same as prior period, unchanged from 0001628280-25-004288:notes:290]

[0001628280-25-022788:notes:284]
[same as prior period, unchanged from 0001628280-25-004288:notes:291]

[0001628280-25-022788:notes:285]
[same as prior period, unchanged from 0001628280-25-004288:notes:292]

[0001628280-25-022788:notes:286]
[same as prior period, unchanged from 0001628280-25-004288:notes:293]

[0001628280-25-022788:notes:287]
[same as prior period, unchanged from 0001628280-25-004288:notes:294]

[0001628280-25-022788:notes:288]
[same as prior period, unchanged from 0001628280-25-004288:notes:295]

[0001628280-25-022788:notes:289]
[same as prior period, unchanged from 0001628280-25-004288:notes:296]

[0001628280-25-022788:notes:290]
Our Industrial Tech products include short pulse solid-state lasers, kilowatt-class fiber lasers, ultrafast lasers, diode lasers, and gas lasers,  which address applications in numerous end-markets. In the consumer end-market, our laser light sources are integrated into our customers’ 3D sensing cameras, which are used in mobile devices, payment kiosks, and other consumer electronics devices to enable applications including biometric identification, computational photography and virtual and augmented reality. In the automotive end-market, our lasers are used in our customers’ LiDAR and other optical sensor devices,

[0001628280-25-022788:notes:291]
which are increasingly being used in advanced driver assistance systems (“ADAS”) and in-cabin driver and occupant monitoring systems. In the industrial manufacturing end-market, our lasers are incorporated into our customers’ manufacturing machine tools used for the precision processing of materials in a range of industries including semiconductor device and microelectronics fabrication, electric vehicle and battery production, metal cutting and welding, and advanced manufacturing. Our products can also be used in the industrial end-market in imaging and sensing systems for process feedback and control, quality assurance, and waste reduction. Adoption of our products in the industrial end-market is driven by the needs of customers to advance semiconductor and microelectronics industry roadmaps, and by Industry 4.0/5.0 trends, including increasing manufacturing precision and flexibility and reducing waste and environmental impact. Demand for our products in the industrial end-market is driven by end-customer investments in manufacturing capacity. Our lasers also address certain semiconductor inspection and life-science applications.

[0001628280-25-022788:notes:292]
[same as prior period, unchanged from 0001628280-25-004288:notes:299]

[0001628280-25-022788:notes:293]
[same as prior period, unchanged from 0001628280-25-004288:notes:300]

[0001628280-25-022788:notes:294]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29, 2025 |  | March 30, 2024 |  | March 29, 2025 |  | March 30, 2024 |
| Net revenue: |  |  |  |  |  |  |  |
| Cloud & Networking | $ | 365.2 |  |  | $ | 313.8 |  |  | $ | 986.7 |  |  | $ | 830.2 |  |
| Industrial Tech | 60.0 |  |  | 52.7 |  |  | 177.6 |  |  | 220.7 |  |
| Net revenue | $ | 425.2 |  |  | $ | 366.5 |  |  | $ | 1,164.3 |  |  | $ | 1,050.9 |  |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Cloud & Networking | $ | 73.1 |  |  | $ | 45.9 |  |  | $ | 164.5 |  |  | $ | 98.9 |  |
| Industrial Tech | 2.6 |  |  | (2.7) |  |  | 8.7 |  |  | 25.3 |  |
| Total segment profit | 75.7 |  |  | 43.2 |  |  | $ | 173.2 |  |  | 124.2 |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Selling, general and administrative (1) | (29.6) |  |  | (28.2) |  |  | (85.4) |  |  | (85.6) |  |
| Stock-based compensation | (62.8) |  |  | (31.6) |  |  | (137.2) |  |  | (98.3) |  |
| Amortization of acquired intangibles | (34.4) |  |  | (42.1) |  |  | (115.1) |  |  | (108.7) |  |
| Amortization of acquired inventory fair value adjustments | — |  |  | (4.9) |  |  | — |  |  | (8.3) |  |
| Acquisition related costs | (0.5) |  |  | (0.5) |  |  | (0.5) |  |  | (13.5) |  |
| Integration related costs | (1.4) |  |  | (10.2) |  |  | (7.9) |  |  | (29.7) |  |
| Restructuring and related charges | (7.2) |  |  | (19.2) |  |  | (17.6) |  |  | (36.0) |  |
| Abnormal excess capacity | — |  |  | (11.9) |  |  | — |  |  | (13.7) |  |
| Gain on sale of assets, net | 34.9 |  |  | — |  |  | 34.9 |  |  | — |  |
| Intangible asset write-off | (0.7) |  |  | — |  |  | (2.6) |  |  | — |  |
| Other charges, net | (11.7) |  |  | (9.2) |  |  | (13.5) |  |  | (31.0) |  |
| Interest expense | (5.7) |  |  | (9.0) |  |  | (16.8) |  |  | (28.4) |  |
| Other income, net (2) | 4.2 |  |  | 16.2 |  |  | 27.8 |  |  | 50.8 |  |
| Consolidated loss before income taxes | $ | (39.2) |  |  | $ | (107.4) |  |  | $ | (160.7) |  |  | $ | (278.2) |  |

[0001628280-25-022788:notes:295]
[same as prior period, unchanged from 0001628280-25-004288:notes:302]

[0001628280-25-022788:notes:296]
(2) Other income, net for the three months ended March 29, 2025 includes interest and investment income of $7.8 million, and foreign exchange loss, net of $3.6 million.  Other income, net for the nine months ended March 29, 2025 includes interest and investment income of $26.2 million, and foreign exchange gain, net of $1.6 million.

[0001628280-25-022788:notes:297]
Other income, net for the three months ended March 30, 2024 includes interest and investment income of $12.6 million, offset by foreign exchange and other loss, net of $3.7 million. Other income, net for the nine months ended March 30, 2024 includes interest and investment income of $51.4 million, offset by foreign exchange and other loss, net of $0.5 million.

[0001628280-25-022788:notes:298]
[same as prior period, unchanged from 0001628280-25-004288:notes:305]

[0001628280-25-022788:notes:299]
[same as prior period, unchanged from 0001628280-25-004288:notes:306]

[0001628280-25-022788:notes:300]
[same as prior period, unchanged from 0001628280-25-004288:notes:307]

[0001628280-25-022788:notes:301]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29, 2025 |  | March 30, 2024 |  | March 29, 2025 |  | March 30, 2024 |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 70.5 |  |  | 16.6 | % |  | $ | 129.9 |  |  | 35.4 | % |  | $ | 213.5 |  |  | 18.3 | % |  | $ | 274.0 |  |  | 26.2 | % |
| Mexico | 38.8 |  |  | 9.1 |  |  | 18.9 |  |  | 5.2 |  |  | 110.1 |  |  | 9.5 |  |  | 74.0 |  |  | 7.0 |  |
| Other Americas | 6.4 |  |  | 1.5 |  |  | 0.6 |  |  | 0.2 |  |  | 13.5 |  |  | 1.2 |  |  | 2.6 |  |  | 0.2 |  |
| Total Americas | $ | 115.7 |  |  | 27.2 | % |  | $ | 149.4 |  |  | 40.8 | % |  | $ | 337.1 |  |  | 29.0 | % |  | $ | 350.6 |  |  | 33.4 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 96.5 |  |  | 22.7 | % |  | $ | 62.0 |  |  | 16.9 | % |  | $ | 285.7 |  |  | 24.5 | % |  | $ | 192.6 |  |  | 18.3 | % |
| South Korea | 9.2 |  |  | 2.2 |  |  | 16.2 |  |  | 4.4 |  |  | 24.8 |  |  | 2.1 |  |  | 62.0 |  |  | 5.9 |  |
| Japan | 20.8 |  |  | 4.9 |  |  | 16.6 |  |  | 4.5 |  |  | 56.1 |  |  | 4.8 |  |  | 67.9 |  |  | 6.5 |  |
| Thailand | 79.1 |  |  | 18.6 |  |  | 44.0 |  |  | 12.0 |  |  | 206.3 |  |  | 17.7 |  |  | 147.5 |  |  | 14.0 |  |
| Other Asia-Pacific | 61.6 |  |  | 14.5 |  |  | 46.0 |  |  | 12.6 |  |  | 140.6 |  |  | 12.1 |  |  | 135.0 |  |  | 12.8 |  |
| Total Asia-Pacific | $ | 267.2 |  |  | 62.9 | % |  | $ | 184.8 |  |  | 50.4 | % |  | $ | 713.5 |  |  | 61.2 | % |  | $ | 605.0 |  |  | 57.5 | % |
| EMEA | $ | 42.3 |  |  | 9.9 | % |  | $ | 32.3 |  |  | 8.8 | % |  | $ | 113.7 |  |  | 9.8 | % |  | $ | 95.3 |  |  | 9.1 | % |
| Total net revenue | $ | 425.2 |  |  | 100.0 | % |  | $ | 366.5 |  |  | 100.0 | % |  | $ | 1,164.3 |  |  | 100.0 | % |  | $ | 1,050.9 |  |  | 100.0 | % |

[0001628280-25-022788:notes:302]
During the three months ended March 29, 2025, two customers individually accounted for 17%, and 15% of our total revenue, respectively. During the nine months ended March 29, 2025, three customers individually accounted for 16%, 14% and 10% of our total net revenue, respectively. We had no other customers that represented 10% or greater of our total net revenue.

[0001628280-25-022788:notes:303]
During the three months ended March 30, 2024, one customer individually accounted for 29% of our total revenue. During the nine months ended March 30, 2024, two customers individually accounted for 19% and 12% of our total net revenue, respectively. We had no other customers that represented 10% or greater of our total net revenue.

[0001628280-25-022788:notes:304]
As of March 29, 2025, three customers individually accounted for 15%, 14% and 11% of gross accounts receivable, respectively. As of June 29, 2024, one customer individually accounted for 13% of gross accounts receivable. We had no other customers that represented 10% or greater of our gross accounts receivable.

[0001628280-25-022788:notes:305]
[same as prior period, unchanged from 0001628280-25-004288:notes:312]

[0001628280-25-022788:notes:306]
|  | March 29, 2025 |  | June 29, 2024 |
| Property, plant and equipment, net |  |  |  |
| United States | $ | 123.0 |  |  | $ | 131.0 |  |
| Thailand | 197.1 |  |  | 141.0 |  |
| Japan | 139.5 |  |  | 75.7 |  |
| United Kingdom | 104.5 |  |  | 83.8 |  |
| China | 76.0 |  |  | 85.7 |  |
| Other countries | 53.2 |  |  | 55.3 |  |
| Total property, plant and equipment, net | $ | 693.3 |  |  | $ | 572.5 |  |

[0001628280-25-022788:notes:307]
We purchase a portion of our inventory from contract manufacturers that are located primarily in Thailand, Taiwan, and Malaysia. During the three and nine months ended March 29, 2025, our net inventory purchases from a single contract manufacturer that represented 10% or greater of our total net inventory purchases were concentrated with one contract manufacturer, who accounted for 27% and 27% of the total net inventory purchases, respectively. During the three and nine months ended March 30, 2024, our net inventory purchases from a single contract manufacturer that represented 10% or greater of our total net inventory purchases were concentrated with one contract manufacturer, who accounted for 25% and 31% of the total net inventory purchases, respectively.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-25-022788:notes:308]
[same as prior period, unchanged from 0001628280-25-004288:notes:315]

[0001628280-25-022788:notes:309]
[same as prior period, unchanged from 0001628280-25-004288:notes:316]

[0001628280-25-022788:notes:310]
[same as prior period, unchanged from 0001628280-25-004288:notes:317]

[0001628280-25-022788:notes:311]
[same as prior period, unchanged from 0001628280-25-004288:notes:318]

[0001628280-25-022788:notes:312]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29, 2025 |  | March 30, 2024 |  | March 29, 2025 |  | March 30, 2024 |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Cloud & Networking | $ | 365.2 |  |  | 85.9 | % |  | 313.8 |  |  | 85.6 | % |  | $ | 986.7 |  |  | 84.7 | % |  | $ | 830.2 |  |  | 79.0 | % |
| Industrial Tech | 60.0 |  |  | 14.1 | % |  | 52.7 |  |  | 14.4 | % |  | 177.6 |  |  | 15.3 | % |  | 220.7 |  |  | 21.0 | % |
| Net revenue | $ | 425.2 |  |  | 100.0 | % |  | $ | 366.5 |  |  | 100.0 | % |  | $ | 1,164.3 |  |  | 100.0 | % |  | $ | 1,050.9 |  |  | 100.0 | % |

[0001628280-25-022788:notes:313]
[same as prior period, unchanged from 0001628280-25-004288:notes:320]

[0001628280-25-022788:notes:314]
[same as prior period, unchanged from 0001628280-25-004288:notes:321]

[0001628280-25-022788:notes:315]
| Contract balances |  | Balance sheet location |  | March 29, 2025 |  | June 29, 2024 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 255.7 |  |  | $ | 194.7 |  |  | $ | 61.0 |  |  | 31.3 | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | 0.7 |  |  | $ | 0.6 |  |  | $ | 0.1 |  |  | 16.7 | % |


## us-gaap:SubsequentEventsTextBlock

[0001628280-25-022788:notes:316]
Note 17. Subsequent Event

[0001628280-25-022788:notes:317]
Subsequent to the end of the reporting period, the Company initiated a restructuring plan to reduce headcount and spending in order to focus on other market opportunities including cloud and AI markets. We recognized a charge of approximately $7.1 million during the three months ended March 29, 2025, which is included in the restructuring and related charges in our condensed consolidated statements of operations. These charges primarily consist of $5.7 million of write-off of assets including property, plant and equipment, prepayments and other current assets as well as $1.4 million of charges for other contractual commitments associated with the related site closures. The Company expects to incur further restructuring charges in the fourth quarter of fiscal year 2025 for employee severance and other personnel-related costs as a result of these actions, which we estimate to be about $5.0 million.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001628280-25-022788:notes:318]
On February 11, 2025, Jae Kim, our Senior Vice President, General Counsel, adopted a Rule 10b5-1 trading arrangement providing for the sale from time to time of an aggregate of up to 20,352 shares of our common stock. The actual number of shares sold under the trading arrangement will depend on restricted stock units (“RSUs”) and shares acquired through employee stock purchase plan (the “ESPP”) subject to the trading arrangement and be net of shares withheld for taxes upon vesting and settlement of the RSUs and the ESPP subject to the trading arrangement. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c). The duration of the trading arrangement is until February 11, 2026, or earlier if all transactions under the trading arrangement are completed.

[0001628280-25-022788:notes:319]
On February 11, 2025, Wupen Yuen, our President, Cloud & Networking, adopted a Rule 10b5-1 trading arrangement providing for the sale from time to time, for an aggregate of up to 28,299 shares of our common stock. The actual number of shares sold under the trading arrangement will depend on RSUs and shares acquired through the ESPP subject to the trading arrangement. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c). The duration of the trading arrangement  is until February 11, 2026, or earlier if all transactions under the trading arrangement are completed.
