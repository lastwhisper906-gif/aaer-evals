# LITE 8-K — 0001628280-25-022709 filed 2025-05-06

## item codes, every 8-K on or before 2025-05-07

- 2025-05-06 0001628280-25-022709 — 2.02, 9.01
- 2025-02-06 0001628280-25-004265 — 2.02, 9.01
- 2025-02-03 0001193125-25-019371 — 2.02, 5.02, 9.01
- 2024-12-12 0001193125-24-277338 — 5.02, 9.01
- 2024-11-22 0001628280-24-048886 — 5.02, 5.07, 9.01
- 2024-11-07 0001628280-24-046302 — 2.02, 9.01
- 2024-08-21 0001628280-24-037938 — 2.02, 9.01 — amendment of 0001628280-24-037191
- 2024-08-14 0001628280-24-037191 — 2.02, 9.01
- 2024-05-06 0001628280-24-020640 — 2.02, 9.01
- 2024-02-27 0001628280-24-006936 — 5.02
- 2024-02-08 0001628280-24-003789 — 2.02, 9.01
- 2024-01-18 0001628280-24-001551 — 9.01 — amendment of 0001193125-23-272452
- 2023-11-21 0001628280-23-039654 — 5.02, 5.07
- 2023-11-08 0001628280-23-037563 — 2.02, 9.01
- 2023-11-07 0001193125-23-272452 — 2.01, 8.01, 9.01
- 2023-10-30 0001193125-23-265658 — 1.01, 2.02, 9.01
- 2023-08-17 0001628280-23-029741 — 2.02, 9.01
- 2023-06-16 0001193125-23-168966 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2023-05-09 0001628280-23-016629 — 2.02, 9.01
- 2023-04-06 0001628280-23-010935 — 2.02, 8.01, 9.01
- 2023-02-24 0001193125-23-048742 — 5.02, 9.01
- 2023-02-09 0001628280-23-002866 — 2.02, 9.01
- 2022-11-21 0001628280-22-030473 — 5.02, 5.07, 9.01
- 2022-11-08 0001628280-22-028758 — 2.02, 9.01
- 2022-08-16 0001628280-22-022980 — 2.02, 9.01
- 2022-08-03 0001193125-22-210674 — 2.01, 8.01, 9.01
- 2022-07-29 0001193125-22-206587 — 8.01, 9.01
- 2022-05-04 0001628280-22-012145 — 2.02, 9.01
- 2022-03-08 0001193125-22-069350 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2022-02-03 0001628280-22-001736 — 2.02, 9.01
- 2022-01-21 0001193125-22-014413 — 8.01, 9.01
- 2021-11-23 0001628280-21-024070 — 5.02, 5.07
- 2021-11-05 0001193125-21-321796 — 1.01, 9.01
- 2021-11-04 0001628280-21-021618 — 2.02, 9.01
- 2021-11-04 0001193125-21-319601 — 8.01, 9.01
- 2021-08-18 0001628280-21-017219 — 2.02, 9.01
- 2021-06-08 0001633978-21-000030 — 5.02, 9.01
- 2021-05-12 0001633978-21-000008 — 2.02, 9.01
- 2021-03-10 0001193125-21-075438 — 1.01, 8.01, 9.01
- 2021-02-02 0001633978-21-000002 — 2.02, 9.01
- 2021-01-19 0001104659-21-005024 — 1.01, 2.02, 8.01, 9.01
- 2020-11-24 0001193125-20-302557 — 5.02, 5.07
- 2020-11-02 0001633978-20-000017 — 2.02, 9.01
- 2020-09-18 0001633978-20-000012 — 5.02, 9.01
- 2020-08-11 0001633978-20-000010 — 2.02, 9.01
- 2020-05-05 0001628280-20-006358 — 2.02, 9.01
- 2020-02-04 0001633978-20-000002 — 2.02, 9.01
- 2019-12-12 0001193125-19-312875 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2019-12-04 0001633978-19-000075 — 8.01
- 2019-11-20 0001633978-19-000074 — 5.07
- 2019-10-31 0001633978-19-000070 — 2.02, 9.01
- 2019-08-08 0001633978-19-000068 — 2.02, 9.01
- 2019-05-08 0001633978-19-000031 — 1.01
- 2019-05-07 0001633978-19-000029 — 2.02, 9.01
- 2019-02-15 0001633978-19-000005 — 9.01 — amendment of 0001193125-18-346211
- 2019-02-08 0001193125-19-031591 — 5.02, 9.01
- 2019-02-05 0001633978-19-000001 — 2.02, 9.01
- 2018-12-10 0001193125-18-346211 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-12-06 0001633978-18-000150 — 8.01
- 2018-11-14 0001633978-18-000139 — 5.07
- 2018-11-13 0001633978-18-000136 — 3.02
- 2018-11-13 0001633978-18-000132 — 7.01, 9.01
- 2018-11-01 0001628280-18-013238 — 2.02, 9.01
- 2018-08-08 0001633978-18-000056 — 2.02, 9.01
- 2018-06-08 0001193125-18-188241 — 5.02, 9.01
- 2018-05-02 0001633978-18-000029 — 2.02, 9.01
- 2018-03-12 0001193125-18-078154 — 1.01, 2.01, 8.01, 9.01
- 2018-02-06 0001628280-18-001082 — 2.02, 9.01
- 2017-11-08 0001633978-17-000133 — 5.02, 9.01
- 2017-11-07 0001633978-17-000131 — 5.07
- 2017-11-01 0001633978-17-000117 — 2.02, 9.01
- 2017-08-09 0001633978-17-000058 — 2.02, 9.01
- 2017-05-04 0001633978-17-000035 — 2.02, 9.01
- 2017-03-08 0001193125-17-074740 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2017-03-02 0001193125-17-066769 — 8.01, 9.01
- 2017-02-07 0001633978-17-000005 — 2.02, 9.01
- 2017-01-03 0001628280-17-000018 — 4.01, 9.01
- 2016-11-09 0001628280-16-021143 — 5.02, 5.07, 9.01
- 2016-10-27 0001628280-16-020382 — 2.02, 9.01
- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2025-05-07

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001628280-25-022709:8k_2_02:1]
EX-99.1
2
lite_ex991xq3fy25.htm
EX-99.1

[0001628280-25-022709:8k_2_02:2]
Document

[0001628280-25-022709:8k_2_02:3]
NEWS RELEASE

[0001628280-25-022709:8k_2_02:4]
LUMENTUM ANNOUNCES FISCAL THIRD QUARTER 2025 FINANCIAL RESULTS

[0001628280-25-022709:8k_2_02:5]
•Net revenue of $425.2 million

[0001628280-25-022709:8k_2_02:6]
•GAAP gross margin of 28.8%; Non-GAAP gross margin of 35.2%

[0001628280-25-022709:8k_2_02:7]
•GAAP operating loss of 8.9%; Non-GAAP operating margin of 10.8%

[0001628280-25-022709:8k_2_02:8]
•GAAP diluted net loss per share of $0.64; Non-GAAP diluted net income per share of $0.57

[0001628280-25-022709:8k_2_02:9]
San Jose, Calif., May 6, 2025 – Lumentum Holdings Inc. (“Lumentum” or the “Company”) today reported results for its fiscal third quarter ended March 29, 2025.

[0001628280-25-022709:8k_2_02:10]
“In my first 90 days as CEO, it’s become clear that Lumentum is uniquely positioned to lead as the convergence of optics and electronics accelerates AI data center scaling. Our innovations—from advanced EMLs to ultra-high-power lasers—are driving transformative power efficiencies across cloud, AI, and long-haul networks, making us an essential partner in this next era of connectivity,” said Michael Hurlston, President and CEO.

[0001628280-25-022709:8k_2_02:11]
“In Q3, we exceeded the high end of our guidance for both revenue and EPS, fueled by strong demand from cloud customers and a recovering networking market. Despite ongoing macroeconomic volatility, we believe AI-driven cloud growth will continue to drive our financial momentum into Q4 and beyond,” Hurlston concluded.

[0001628280-25-022709:8k_2_02:12]
Fiscal Third Quarter Highlights:

[0001628280-25-022709:8k_2_02:13]
Net revenue for the fiscal third quarter of 2025 was $425.2 million, with GAAP net loss of $44.1 million, or $0.64 per diluted share. Net revenue for the fiscal second quarter of 2025 was $402.2 million, with GAAP net loss of $60.9 million, or $0.88 per diluted share. Net revenue for the fiscal third quarter of 2024 was $366.5 million, with GAAP net loss of $127.0 million, or $1.88 per diluted share.

[0001628280-25-022709:8k_2_02:14]
Non-GAAP net income for the fiscal third quarter of 2025 was $40.9 million, or $0.57 per diluted share. Non-GAAP net income for the fiscal second quarter of 2025 was $30.0 million, or $0.42 per diluted share. Non-GAAP net income for the third quarter of 2024 was $6.2 million, or $0.09 per diluted share(1).

[0001628280-25-022709:8k_2_02:15]
The Company held $866.7 million in total cash, cash equivalents, and short-term investments at the end of the fiscal third quarter of 2025, down $30.0 million from the end of the fiscal second quarter of 2025.

[0001628280-25-022709:8k_2_02:16]
Financial Overview – Fiscal Third Quarter Ended March 29, 2025

[0001628280-25-022709:8k_2_02:17]
|  | GAAP Results ($ in millions) |
|  | Q3 |  | Q2 |  | Q3 |  | Change |
|  | FY 2025 |  | FY 2025 |  | FY 2024 |  | Q/Q |  | Y/Y |
| Net revenue | $ | 425.2 |  |  | $ | 402.2 |  |  | $ | 366.5 |  |  | 5.7% |  | 16.0% |
| GAAP gross margin | 28.8 | % |  | 24.8 | % |  | 16.2 | % |  | 400 | bps |  | 1,260 | bps |
| GAAP operating loss | (8.9) | % |  | (12.8) | % |  | (31.3) | % |  | 390 | bps |  | 2,240 | bps |
|  | Non-GAAP Results ($ in millions) |
|  | Q3 |  | Q2 |  | Q3 |  | Change |
|  | FY 2025 |  | FY 2025 |  | FY 2024 (1) |  | Q/Q |  | Y/Y |
| Net revenue | $ | 425.2 |  |  | $ | 402.2 |  |  | $ | 366.5 |  |  | 5.7% |  | 16.0% |
| Non-GAAP gross margin | 35.2 | % |  | 32.3 | % |  | 28.7 | % |  | 290 | bps |  | 650 | bps |
| Non-GAAP operating margin | 10.8 | % |  | 7.9 | % |  | (0.2) | % |  | 290 | bps |  | 1,100 | bps |

[0001628280-25-022709:8k_2_02:18]
|  | Net Revenue by Segment ($ in millions) |  |  |  |  |
|  | Q3 |  | % of |  | Q2 |  | Q3 |  | Change |  |  |  |  |
|  | FY 2025 |  | Net Revenue |  | FY 2025 |  | FY 2024 |  | Q/Q |  | Y/Y |  |  |  |  |
| Cloud & Networking | $ | 365.2 |  |  | 85.9 | % |  | $ | 339.2 |  |  | $ | 313.8 |  |  | 7.7% |  | 16.4% |  |  |  |  |
| Industrial Tech | 60.0 |  |  | 14.1 | % |  | 63.0 |  |  | 52.7 |  |  | (4.8)% |  | 13.9% |  |  |  |  |
| Total | $ | 425.2 |  |  | 100.0 | % |  | $ | 402.2 |  |  | $ | 366.5 |  |  | 5.7% |  | 16.0% |  |  |  |  |

[0001628280-25-022709:8k_2_02:19]
(1) During the first fiscal quarter of 2025, the Company refined its methodology to report non-GAAP measures.  The change does not impact the Company’s financial position, cash flows, or GAAP consolidated results of operations. Prior period non-GAAP financial measures presented in this press release have been recast to conform to the current presentation.

[0001628280-25-022709:8k_2_02:20]
The tables above provide comparisons of quarterly results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled “Use of Non-GAAP Financial Measures.”

[0001628280-25-022709:8k_2_02:21]
Business Outlook

[0001628280-25-022709:8k_2_02:22]
Lumentum expects the following for the fiscal fourth quarter 2025:

[0001628280-25-022709:8k_2_02:23]
•Net revenue in the range of $440 million to $470 million

[0001628280-25-022709:8k_2_02:24]
•Non-GAAP operating margin of 13.0% to 14.0%

[0001628280-25-022709:8k_2_02:25]
•Non-GAAP diluted earnings per share of $0.70 to $0.80

[0001628280-25-022709:8k_2_02:26]
We have not provided reconciliations from GAAP to non-GAAP measures or the equivalent GAAP measure for non-GAAP measures in our outlook, as they cannot be provided without unreasonable effort. A large portion of non-GAAP adjustments, such as stock-based compensation, acquisition related costs, integration related costs, restructuring and related charges, foreign exchange gains and losses, net, non-GAAP income tax reconciling adjustments, and other charges or income related to non-recurring activities, are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future.

[0001628280-25-022709:8k_2_02:27]
Related Announcement and Conference Call

[0001628280-25-022709:8k_2_02:28]
Lumentum will host a conference call today, May 6, 2025, at 2:00 pm PT / 5:00 pm ET to discuss its fiscal third quarter results. A live webcast of the call will be available in the Investors section of the Lumentum website at http://investor.lumentum.com. To listen to the live conference call, dial (833) 470-1428 or (404) 975-4839 and reference the conference ID 629794. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the “Events and Presentations” section concurrently with this earnings press release. Lumentum has used, and intends to continue to use, its Investor Relations website as means of disclosing material nonpublic information and for complying with its disclosure obligations under Regulation FD. This press release is being furnished as an exhibit to a Current Report on Form 8-K filed with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001628280-25-022709:8k_2_02:29]
About Lumentum

[0001628280-25-022709:8k_2_02:30]
Lumentum (NASDAQ: LITE) is a market-leading designer and manufacturer of innovative optical and photonic products enabling optical networking and laser applications worldwide. Lumentum optical components and subsystems are part of virtually every type of telecom, enterprise, and data center network. Lumentum lasers enable advanced manufacturing techniques and diverse applications including next-generation imaging and sensing capabilities. Lumentum is headquartered in San Jose, California with R&D, manufacturing, and sales offices worldwide. For more information, visit www.lumentum.com and follow Lumentum on LinkedIn, X (formerly known as Twitter), Facebook, Instagram and YouTube.

[0001628280-25-022709:8k_2_02:31]
Forward-Looking Statements

[0001628280-25-022709:8k_2_02:32]
Contact Information

[0001628280-25-022709:8k_2_02:33]
Investors:    Kathy Ta, (408) 750-3853; investor.relations@lumentum.com

[0001628280-25-022709:8k_2_02:34]
Media:        Noël Bilodeau, 408-439-2140; noel.bilodeau@lumentum.com

[0001628280-25-022709:8k_2_02:35]
Category:    Financial

[0001628280-25-022709:8k_2_02:36]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001628280-25-022709:8k_2_02:37]
LUMENTUM HOLDINGS INC.

[0001628280-25-022709:8k_2_02:38]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001628280-25-022709:8k_2_02:39]
(in millions, except per share data)

[0001628280-25-022709:8k_2_02:40]
(unaudited)

[0001628280-25-022709:8k_2_02:41]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29, 2025 |  | March 30, 2024 |  | March 29, 2025 |  | March 30, 2024 |
| Net revenue | $ | 425.2 |  |  | $ | 366.5 |  |  | $ | 1,164.3 |  |  | $ | 1,050.9 |  |
| Cost of sales | 283.7 |  |  | 284.7 |  |  | 801.4 |  |  | 788.9 |  |
| Amortization of acquired developed intangibles | 19.0 |  |  | 22.3 |  |  | 62.9 |  |  | 61.8 |  |
| Gross profit | 122.5 |  |  | 59.5 |  |  | 300.0 |  |  | 200.2 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 75.9 |  |  | 77.2 |  |  | 224.4 |  |  | 229.0 |  |
| Selling, general and administrative | 112.0 |  |  | 77.7 |  |  | 264.6 |  |  | 235.8 |  |
| Restructuring and related charges | 7.2 |  |  | 19.2 |  |  | 17.6 |  |  | 36.0 |  |
| Gain on sale of facility | (34.9) |  |  | — |  |  | (34.9) |  |  | — |  |
| Total operating expenses | 160.2 |  |  | 174.1 |  |  | 471.7 |  |  | 500.8 |  |
| Loss from operations | (37.7) |  |  | (114.6) |  |  | (171.7) |  |  | (300.6) |  |
| Interest expense | (5.7) |  |  | (9.0) |  |  | (16.8) |  |  | (28.4) |  |
| Other income, net | 4.2 |  |  | 16.2 |  |  | 27.8 |  |  | 50.8 |  |
| Loss before income taxes | (39.2) |  |  | (107.4) |  |  | (160.7) |  |  | (278.2) |  |
| Income tax provision | 4.9 |  |  | 19.6 |  |  | 26.7 |  |  | 15.8 |  |
| Net loss | $ | (44.1) |  |  | $ | (127.0) |  |  | $ | (187.4) |  |  | $ | (294.0) |  |
| Net loss per share: |  |  |  |  |  |  |  |
| Basic | $ | (0.64) |  |  | $ | (1.88) |  |  | $ | (2.72) |  |  | $ | (4.38) |  |
| Diluted | $ | (0.64) |  |  | $ | (1.88) |  |  | $ | (2.72) |  |  | $ | (4.38) |  |
| Shares used to compute net loss per share: |  |  |  |  |  |  |  |
| Basic | 69.3 |  |  | 67.5 |  |  | 68.8 |  |  | 67.1 |  |
| Diluted | 69.3 |  |  | 67.5 |  |  | 68.8 |  |  | 67.1 |  |

[0001628280-25-022709:8k_2_02:42]
LUMENTUM HOLDINGS INC.

[0001628280-25-022709:8k_2_02:43]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-25-022709:8k_2_02:44]
(in millions, except per share data)

[0001628280-25-022709:8k_2_02:45]
(unaudited)

[0001628280-25-022709:8k_2_02:46]
|  | March 29, 2025 |  | June 29, 2024 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 516.4 |  |  | $ | 436.7 |  |
| Short-term investments | 350.3 |  |  | 450.3 |  |
| Accounts receivable, net | 255.7 |  |  | 194.7 |  |
| Inventories | 422.9 |  |  | 398.4 |  |
| Prepayments and other current assets | 122.0 |  |  | 110.0 |  |
| Total current assets | 1,667.3 |  |  | 1,590.1 |  |
| Property, plant and equipment, net | 693.3 |  |  | 572.5 |  |
| Operating lease right-of-use assets, net | 32.2 |  |  | 72.8 |  |
| Goodwill | 1,060.9 |  |  | 1,055.8 |  |
| Other intangible assets, net | 499.8 |  |  | 617.5 |  |
| Deferred tax asset | 12.7 |  |  | 10.7 |  |
| Other non-current assets | 8.8 |  |  | 12.5 |  |
| Total assets | $ | 3,975.0 |  |  | $ | 3,931.9 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 195.2 |  |  | $ | 126.3 |  |
| Accrued payroll and related expenses | 42.8 |  |  | 36.1 |  |
| Accrued expenses | 43.5 |  |  | 52.4 |  |
| Current portion of long-term debt | 10.3 |  |  | — |  |
| Operating lease liabilities, current | 11.3 |  |  | 13.4 |  |
| Other current liabilities | 49.9 |  |  | 41.1 |  |
| Total current liabilities | 353.0 |  |  | 269.3 |  |
| Long-term debt | 2,562.4 |  |  | 2,503.2 |  |
| Operating lease liabilities, non-current | 25.8 |  |  | 43.0 |  |
| Deferred tax liability | 39.4 |  |  | 55.7 |  |
| Other non-current liabilities | 114.9 |  |  | 103.4 |  |
| Total liabilities | 3,095.5 |  |  | 2,974.6 |  |
| Stockholders’ equity: |  |  |  |
| Common stock, $0.001 par value, 990 authorized shares, 69.4 and 67.9 shares issued and outstanding as of March 29, 2025 and June 29, 2024, respectively | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital | 1,942.8 |  |  | 1,835.0 |  |
| Accumulated deficit | (1,074.5) |  |  | (887.1) |  |
| Accumulated other comprehensive income | 11.1 |  |  | 9.3 |  |
| Total stockholders’ equity | 879.5 |  |  | 957.3 |  |
| Total liabilities and stockholders’ equity | $ | 3,975.0 |  |  | $ | 3,931.9 |  |

[0001628280-25-022709:8k_2_02:47]
Use of Non-GAAP Financial Measures

[0001628280-25-022709:8k_2_02:48]
In this press release, Lumentum provides investors with certain non-GAAP financial measures: gross profit, gross margin, research and development expense, selling, general and administrative expense, operating margin, income (loss) from operations, interest and other income (expense), net, income before income taxes, provision for income taxes, net income, and net income per share on a non-GAAP basis, as well as the non-GAAP measures of EBITDA and Adjusted EBITDA. Lumentum believes this non-GAAP financial information provides additional insight into the Company’s on-going business operations and results, and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons. In addition, the Company believes that providing certain of these measures allows investors to better understand the Company’s operating performance and importantly, to evaluate the methodology and information used by management to monitor, manage, evaluate and measure the Company’s business and results of operations. However, these measures may be different from non-GAAP measures used by other companies, limiting their usefulness for comparison purposes. The non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP. Investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future. Further, these non-GAAP financial measures may not be comparable to similarly titled measurements reported by other companies.

[0001628280-25-022709:8k_2_02:49]
Our non-GAAP measures used in this press release exclude (i) stock-based compensation, (ii) acquisition related costs, (iii) amortization of acquired intangibles, (iv) amortization of acquired inventory fair value, (v) restructuring and related charges, (vi) foreign exchange (gains) losses, net, (vii) non-cash interest expense on convertible notes, (viii) intangible assets write-off, (ix) integration related costs, (x) non-GAAP income tax reconciling adjustments, and (xi) other charges or income related to non-recurring activities.

[0001628280-25-022709:8k_2_02:50]
We utilize a long-term projected non-GAAP tax rate to compute our non-GAAP income tax provision. The long-term projected non-GAAP tax rate is based on a multi-year projection of our estimated annual GAAP income tax forecast, adjusted to account for the tax effect of non-GAAP pretax adjustments as well as the effects of significant non-recurring and period specific tax items. Our non-GAAP tax provision for fiscal 2025 is 16.5%. The difference between our GAAP income tax provision and our non-GAAP income tax provision is presented as non-GAAP income tax reconciling adjustments.

[0001628280-25-022709:8k_2_02:51]
A quantitative reconciliation between GAAP and non-GAAP financial data with respect to historical periods is included in the supplemental financial table attached to this press release.

[0001628280-25-022709:8k_2_02:52]
LUMENTUM HOLDINGS INC.

[0001628280-25-022709:8k_2_02:53]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001628280-25-022709:8k_2_02:54]
(in millions, except per share data)

[0001628280-25-022709:8k_2_02:55]
(unaudited)

[0001628280-25-022709:8k_2_02:56]
|  | Three Months Ended |  | Nine Months Ended |  |
|  | March 29, 2025 |  | December 28, 2024 |  | March 30, 2024 (1) |  | March 29, 2025 |  | March 30, 2024 (1) |  |
| Gross profit on GAAP basis | $ | 122.5 |  |  | $ | 99.6 |  |  | $ | 59.5 |  |  | $ | 300.0 |  |  | $ | 200.2 |  |  |
| Stock-based compensation | 9.2 |  |  | 9.2 |  |  | 8.5 |  |  | 28.1 |  |  | 23.5 |  |  |
| Amortization of acquired intangibles | 19.0 |  |  | 21.4 |  |  | 22.3 |  |  | 62.9 |  |  | 61.8 |  |  |
| Amortization of acquired inventory fair value adjustments | — |  |  | — |  |  | 4.9 |  |  | — |  |  | 8.3 |  |  |
| Integration related costs | — |  |  | 1.1 |  |  | 4.6 |  |  | 2.3 |  |  | 16.2 |  |  |
| Other charges (income), net | (1.2) |  |  | (1.3) |  |  | 5.3 |  |  | (3.4) |  |  | 14.5 |  |  |
| Gross profit on non-GAAP basis | $ | 149.5 |  |  | $ | 130.0 |  |  | $ | 105.1 |  |  | $ | 389.9 |  |  | $ | 324.5 |  |  |
| Gross margin on non-GAAP basis | 35.2 | % |  | 32.3 | % |  | 28.7 | % |  | 33.5 | % |  | 30.9 | % |  |
| Research and development on GAAP basis | $ | 75.9 |  |  | $ | 74.2 |  |  | $ | 77.2 |  |  | $ | 224.4 |  |  | $ | 229.0 |  |  |
| Stock-based compensation | (11.2) |  |  | (11.4) |  |  | (9.8) |  |  | (31.9) |  |  | (30.1) |  |  |
| Amortization of acquired intangibles | (0.4) |  |  | (0.4) |  |  | (0.4) |  |  | (1.2) |  |  | (1.1) |  |  |
| Acquisition related costs | — |  |  | — |  |  | — |  |  | — |  |  | (0.4) |  |  |
| Integration related costs | (0.3) |  |  | — |  |  | (0.4) |  |  | (0.3) |  |  | (0.1) |  |  |
| Intangible asset write-off | (0.7) |  |  | — |  |  | — |  |  | (2.6) |  |  | — |  |  |
| Other charges, net | — |  |  | — |  |  | (0.4) |  |  | — |  |  | (1.2) |  |  |
| Research and development on non-GAAP basis | $ | 63.3 |  |  | $ | 62.4 |  |  | $ | 66.2 |  |  | $ | 188.4 |  |  | $ | 196.1 |  |  |
| Selling, general and administrative on GAAP basis | $ | 112.0 |  |  | $ | 76.3 |  |  | $ | 77.7 |  |  | $ | 264.6 |  |  | $ | 235.8 |  |  |
| Stock-based compensation (2) | (42.4) |  |  | (18.2) |  |  | (13.3) |  |  | (77.2) |  |  | (44.7) |  |  |
| Amortization of acquired intangibles | (15.0) |  |  | (17.2) |  |  | (19.4) |  |  | (51.0) |  |  | (45.8) |  |  |
| Acquisition related costs | (0.5) |  |  | — |  |  | (0.5) |  |  | (0.5) |  |  | (13.1) |  |  |
| Integration related costs | (1.1) |  |  | (2.0) |  |  | (2.7) |  |  | (5.3) |  |  | (6.6) |  |  |
| Other charges, net (5) | (12.9) |  |  | (3.0) |  |  | (2.2) |  |  | (16.9) |  |  | (5.4) |  |  |
| Selling, general and administrative on non-GAAP basis | $ | 40.1 |  |  | $ | 35.9 |  |  | $ | 39.6 |  |  | $ | 113.7 |  |  | $ | 120.2 |  |  |
| Loss from operations on GAAP basis | $ | (37.7) |  |  | $ | (51.6) |  |  | $ | (114.6) |  |  | $ | (171.7) |  |  | $ | (300.6) |  |  |
| Stock-based compensation (2) | 62.8 |  |  | 38.8 |  |  | 31.6 |  |  | 137.2 |  |  | 98.3 |  |  |
| Amortization of acquired intangibles | 34.4 |  |  | 39.0 |  |  | 42.1 |  |  | 115.1 |  |  | 108.7 |  |  |
| Amortization of acquired inventory fair value adjustments | — |  |  | — |  |  | 4.9 |  |  | — |  |  | 8.3 |  |  |
| Acquisition related costs | 0.5 |  |  | — |  |  | 0.5 |  |  | 0.5 |  |  | 13.5 |  |  |
| Integration related costs | 1.4 |  |  | 3.1 |  |  | 7.7 |  |  | 7.9 |  |  | 22.9 |  |  |
| Restructuring and related charges (3) | 7.2 |  |  | 0.7 |  |  | 19.2 |  |  | 17.6 |  |  | 36.0 |  |  |
| Intangible asset write-off | 0.7 |  |  | — |  |  | — |  |  | 2.6 |  |  | — |  |  |
| Gain on sale of facility (4) | (34.9) |  |  | — |  |  | — |  |  | (34.9) |  |  | — |  |  |
| Other charges, net (5) | 11.7 |  |  | 1.7 |  |  | 7.9 |  |  | 13.5 |  |  | 21.1 |  |  |
| Income (loss) from operations on non-GAAP basis | $ | 46.1 |  |  | $ | 31.7 |  |  | $ | (0.7) |  |  | $ | 87.8 |  |  | $ | 8.2 |  |  |
| Operating margin on non-GAAP basis | 10.8 | % |  | 7.9 | % |  | (0.2) | % |  | 7.5 | % |  | 0.8 | % |  |
| Interest and other income, net on GAAP basis | $ | (1.5) |  |  | $ | 9.3 |  |  | $ | 7.2 |  |  | $ | 11.0 |  |  | $ | 22.4 |  |  |
| Foreign exchange (gains) losses, net | 3.6 |  |  | (5.9) |  |  | (3.7) |  |  | (1.6) |  |  | 0.5 |  |  |

[0001628280-25-022709:8k_2_02:57]
| Non-cash interest expense on convertible notes and other income and expenses, net | 0.8 |  |  | 0.8 |  |  | 4.5 |  |  | 2.3 |  |  | 14.2 |  |  |
| Interest and other income, net on non-GAAP basis | $ | 2.9 |  |  | $ | 4.2 |  |  | $ | 8.0 |  |  | $ | 11.7 |  |  | $ | 37.1 |  |  |
| Loss before income taxes on GAAP basis | $ | (39.2) |  |  | $ | (42.3) |  |  | $ | (107.4) |  |  | $ | (160.7) |  |  | $ | (278.2) |  |  |
| Stock-based compensation (2) | 62.8 |  |  | 38.8 |  |  | 31.6 |  |  | 137.2 |  |  | 98.3 |  |  |
| Acquisition related costs | 0.5 |  |  | — |  |  | 0.5 |  |  | 0.5 |  |  | 13.5 |  |  |
| Integration related costs | 1.4 |  |  | 3.1 |  |  | 7.7 |  |  | 7.9 |  |  | 22.9 |  |  |
| Amortization of acquired intangibles | 34.4 |  |  | 39.0 |  |  | 42.1 |  |  | 115.1 |  |  | 108.7 |  |  |
| Amortization of acquired inventory fair value adjustments | — |  |  | — |  |  | 4.9 |  |  | — |  |  | 8.3 |  |  |
| Restructuring and related charges (3) | 7.2 |  |  | 0.7 |  |  | 19.2 |  |  | 17.6 |  |  | 36.0 |  |  |
| Gain on sale of facility (4) | (34.9) |  |  | — |  |  | — |  |  | (34.9) |  |  | — |  |  |
| Intangible asset write-off | 0.7 |  |  | — |  |  | — |  |  | 2.6 |  |  | — |  |  |
| Foreign exchange (gains) losses, net | 3.6 |  |  | (5.9) |  |  | (3.7) |  |  | (1.6) |  |  | 0.5 |  |  |
| Non-cash interest expense on convertible notes and other income and expenses, net | 0.8 |  |  | 0.8 |  |  | 4.5 |  |  | 2.3 |  |  | 14.2 |  |  |
| Other charges, net (5) | 11.7 |  |  | 1.7 |  |  | 7.9 |  |  | 13.5 |  |  | 21.1 |  |  |
| Income before income taxes on non-GAAP basis | $ | 49.0 |  |  | $ | 35.9 |  |  | $ | 7.3 |  |  | $ | 99.5 |  |  | $ | 45.3 |  |  |
| Income tax provision on GAAP basis | $ | 4.9 |  |  | $ | 18.6 |  |  | $ | 19.6 |  |  | $ | 26.7 |  |  | $ | 15.8 |  |  |
| Non-GAAP income tax reconciling adjustments | 3.2 |  |  | (12.7) |  |  | (18.5) |  |  | (10.3) |  |  | (9.2) |  |  |
| Income tax provision on non-GAAP basis | $ | 8.1 |  |  | $ | 5.9 |  |  | $ | 1.1 |  |  | $ | 16.4 |  |  | $ | 6.6 |  |  |
| Net loss on GAAP basis | $ | (44.1) |  |  | $ | (60.9) |  |  | $ | (127.0) |  |  | $ | (187.4) |  |  | $ | (294.0) |  |  |
| Stock-based compensation (2) | 62.8 |  |  | 38.8 |  |  | 31.6 |  |  | 137.2 |  |  | 98.3 |  |  |
| Acquisition related costs | 0.5 |  |  | — |  |  | 0.5 |  |  | 0.5 |  |  | 13.5 |  |  |
| Integration related costs | 1.4 |  |  | 3.1 |  |  | 7.7 |  |  | 7.9 |  |  | 22.9 |  |  |
| Amortization of acquired intangibles | 34.4 |  |  | 39.0 |  |  | 42.1 |  |  | 115.1 |  |  | 108.7 |  |  |
| Amortization of acquired inventory fair value adjustments | — |  |  | — |  |  | 4.9 |  |  | — |  |  | 8.3 |  |  |
| Restructuring and related charges (3) | 7.2 |  |  | 0.7 |  |  | 19.2 |  |  | 17.6 |  |  | 36.0 |  |  |
| Intangible asset write-off | 0.7 |  |  | — |  |  | — |  |  | 2.6 |  |  | — |  |  |
| Gain on sale of facility (4) | (34.9) |  |  | — |  |  | — |  |  | (34.9) |  |  | — |  |  |
| Foreign exchange (gains) losses, net | 3.6 |  |  | (5.9) |  |  | (3.7) |  |  | (1.6) |  |  | 0.5 |  |  |
| Non-cash interest expense on convertible notes and other income and expenses, net | 0.8 |  |  | 0.8 |  |  | 4.5 |  |  | 2.3 |  |  | 14.2 |  |  |
| Non-GAAP income tax reconciling adjustments | (3.2) |  |  | 12.7 |  |  | 18.5 |  |  | 10.3 |  |  | 9.2 |  |  |
| Other charges, net (5) | 11.7 |  |  | 1.7 |  |  | 7.9 |  |  | 13.5 |  |  | 21.1 |  |  |
| Net income on non-GAAP basis | $ | 40.9 |  |  | $ | 30.0 |  |  | $ | 6.2 |  |  | $ | 83.1 |  |  | $ | 38.7 |  |  |
| Net income per share on non-GAAP basis | $ | 0.57 |  |  | $ | 0.42 |  |  | $ | 0.09 |  |  | $ | 1.17 |  |  | $ | 0.57 |  |  |
| Shares used in per share calculation - diluted on GAAP basis | 69.3 |  |  | 68.9 |  |  | 67.5 |  |  | 68.8 |  |  | 67.1 |  |  |
| Non-GAAP adjustment (6) | 2.9 |  |  | 2.7 |  |  | 0.6 |  |  | 2.1 |  |  | 0.4 |  |  |
| Shares used in per share calculation - diluted on non-GAAP basis | 72.2 |  |  | 71.6 |  |  | 68.1 |  |  | 70.9 |  |  | 67.5 |  |  |

[0001628280-25-022709:8k_2_02:58]
(1) During the first fiscal quarter of 2025, the Company refined its methodology to report non-GAAP measures.  The change does not impact the Company’s financial position, cash flows, or GAAP consolidated results of operations. Prior period non-GAAP financial measures and the associated GAAP to non-GAAP reconciliations presented in this press release have been recast to conform to the current presentation.

[0001628280-25-022709:8k_2_02:59]
(2) Stock-based compensation for the three and nine months ended March 29, 2025 includes $28.2 million of stock-based compensation expense resulting from equity award modifications for our former President and Chief Executive Officer, which include RSUs and PSUs that were immediately expensed as of the separation date.

[0001628280-25-022709:8k_2_02:60]
(3) Restructuring charges for the three months ended March 29, 2025 primarily relate to $5.7 million of assets written-off  including property, plant and equipment, prepayments and other current assets as well as $1.4 million charges for other contractual commitments associated with site closures driven by restructuring plans initiated in April 2025.

[0001628280-25-022709:8k_2_02:61]
Restructuring charges for the nine months ended March 29, 2025 include $12.4 million of assets written-off including property, plant and equipment, prepayments and other current assets primarily due to efforts to consolidate our sites.  In addition, we also recorded $3.0 million of charges related to the discontinuation of our in-house development of coherent Digital Signal Processors and Radio Frequency Integrated Circuits.

[0001628280-25-022709:8k_2_02:62]
(4) Gain on sale of facility for the three and nine months ended March 29, 2025 represents a gain for net assets sold in an entity in Shenzhen, China, which consist primarily of building, building improvements and land rights.

[0001628280-25-022709:8k_2_02:63]
(5) Other charges, net for the three months ended March 29, 2025 mainly includes $6.1 million of executive transition costs, $3.2 million of bad debt reserve related to the remaining unpaid balances due from Huawei associated with the trade restrictions and $2.7 million of legal and professional fees primarily related to non-ordinary course legal matters, offset by $1.4 million of excess and obsolescence credits related to units sold that were previously reserved.

[0001628280-25-022709:8k_2_02:64]
Other charges, net for the nine months ended March 29, 2025 mainly includes $6.1 million of executive transition costs,  $6.6 million of legal and professional fees primarily related to non-ordinary course legal matters, and $3.2 million of bad debt reserve related to the remaining unpaid balances due from Huawei associated with the trade restrictions, offset by $3.2 million of excess and obsolescence credits related to units sold that were previously reserved.

[0001628280-25-022709:8k_2_02:65]
(6) The adjustment represents the dilutive impact of equity-based compensation awards in accordance with the treasury stock method and dilutive shares from our convertible debt instruments under the if-converted method, which are anti-dilutive for GAAP purposes as we recognized a GAAP net loss.

[0001628280-25-022709:8k_2_02:66]
LUMENTUM HOLDINGS INC.

[0001628280-25-022709:8k_2_02:67]
RECONCILIATION OF GAAP NET INCOME TO ADJUSTED EBITDA

[0001628280-25-022709:8k_2_02:68]
(in millions, except per share data)

[0001628280-25-022709:8k_2_02:69]
(unaudited)

[0001628280-25-022709:8k_2_02:70]
|  | Three Months Ended |  |  |  | Nine Months Ended |
|  | March 29, 2025 |  |  |  | December 28, 2024 |  | March 30, 2024 (1) |  |  |  |  |  | March 29, 2025 |  | March 30, 2024 (1) |
| GAAP net loss | $ | (44.1) |  |  |  |  | $ | (60.9) |  |  | $ | (127.0) |  |  |  |  |  |  | $ | (187.4) |  |  | $ | (294.0) |  |
| Interest and other expense, net | 1.5 |  |  |  |  | (9.3) |  |  | (7.2) |  |  |  |  |  |  | (11.0) |  |  | (22.4) |  |
| Income tax provision | 4.9 |  |  |  |  | 18.6 |  |  | 19.6 |  |  |  |  |  |  | 26.7 |  |  | 15.8 |  |
| Depreciation | 25.0 |  |  |  |  | 25.9 |  |  | 27.0 |  |  |  |  |  |  | 77.9 |  |  | 82.4 |  |
| Amortization of acquired intangibles | 34.4 |  |  |  |  | 39.0 |  |  | 42.1 |  |  |  |  |  |  | 115.1 |  |  | 108.7 |  |
| EBITDA | 21.7 |  |  |  |  | 13.3 |  |  | (45.5) |  |  |  |  |  |  | 21.3 |  |  | (109.5) |  |
| Amortization of inventory fair value adjustments | — |  |  |  |  | — |  |  | 4.9 |  |  |  |  |  |  | — |  |  | 8.3 |  |
| Restructuring and related charges | 7.2 |  |  |  |  | 0.7 |  |  | 19.2 |  |  |  |  |  |  | 17.6 |  |  | 36.0 |  |
| Stock-based compensation | 62.8 |  |  |  |  | 38.8 |  |  | 31.6 |  |  |  |  |  |  | 137.2 |  |  | 98.3 |  |
| Acquisition related costs | 0.5 |  |  |  |  | — |  |  | 0.5 |  |  |  |  |  |  | 0.5 |  |  | 13.5 |  |
| Integration related costs | 1.4 |  |  |  |  | 3.1 |  |  | 7.7 |  |  |  |  |  |  | 7.9 |  |  | 22.9 |  |
| Intangible asset write-off | 0.7 |  |  |  | — |  | — |  |  |  |  |  |  | 2.6 |  |  | — |  |
| Gain on sale of facility | (34.9) |  |  |  |  | — |  |  | — |  |  |  |  |  |  | (34.9) |  |  | — |  |
| Other charges, net | 11.6 |  |  |  |  | 1.7 |  |  | 6.9 |  |  |  |  |  |  | 13.3 |  |  | 14.7 |  |
| Adjusted EBITDA | $ | 71.0 |  |  |  |  | $ | 57.6 |  |  | $ | 25.3 |  |  |  |  |  |  | $ | 165.5 |  |  | $ | 84.2 |  |

[0001628280-25-022709:8k_2_02:71]
(1) During the first fiscal quarter of 2025, the Company refined its methodology to report non-GAAP measures.  The change does not impact the Company’s financial position, cash flows, or GAAP consolidated results of operations. Prior period non-GAAP financial measures and the associated GAAP to non-GAAP reconciliations presented in this press release have been recast to conform to the current presentation.
