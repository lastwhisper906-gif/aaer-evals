# LITE MD&A — 0001628280-25-022788


## mdna

[0001628280-25-022788:mdna:1]
[same as prior period, unchanged from 0001628280-25-004288:mdna:1]

[0001628280-25-022788:mdna:2]
[same as prior period, unchanged from 0001628280-25-004288:mdna:2]

[0001628280-25-022788:mdna:3]
[same as prior period, unchanged from 0001628280-25-004288:mdna:3]

[0001628280-25-022788:mdna:4]
[same as prior period, unchanged from 0001628280-25-004288:mdna:4]

[0001628280-25-022788:mdna:5]
[same as prior period, unchanged from 0001628280-25-004288:mdna:5]

[0001628280-25-022788:mdna:6]
[same as prior period, unchanged from 0001628280-25-004288:mdna:6]

[0001628280-25-022788:mdna:7]
[same as prior period, unchanged from 0001628280-25-004288:mdna:7]

[0001628280-25-022788:mdna:8]
We believe the global markets in which Lumentum participates have fundamentally robust, long-term trends that will increase the need for our photonics products and technologies. We believe the world is becoming more reliant on ever-increasing amounts of data flowing through optical networks and data centers. Lumentum’s products and technology enable the scaling of these optical networks and data centers to higher capacities. AI/ML has caused a dramatic surge in the growing demands on data networking in cloud data centers and accelerated the usage of optical components and modules. We expect that the accelerating shift to digital and virtual approaches to many aspects of work and life will continue into the future. Virtual meetings, video calls, and hybrid in-person and virtual environments for work and other aspects of life will continue to drive strong needs for bandwidth growth and present dynamic new challenges that our technology addresses. As manufacturers demand higher levels of precision, new materials, and factory and energy efficiency, suppliers of manufacturing tools globally are turning to laser-based approaches, including the types of lasers Lumentum supplies. Laser-based 3D sensing and LiDAR for security, industrial and automotive applications are rapidly developing markets. The technology enables computer vision applications that enhance security, safety, and new functionality in the electronic devices that people rely on every day. The use of LiDAR and in-cabin 3D sensing in automobile and delivery vehicles over time significantly adds to our long-term market opportunity. Additionally, we expect 3D-enabled machine vision solutions to expand significantly in industrial applications in the coming years.

[0001628280-25-022788:mdna:9]
[same as prior period, unchanged from 0001628280-25-004288:mdna:9]

[0001628280-25-022788:mdna:10]
[same as prior period, unchanged from 0001628280-25-004288:mdna:10]

[0001628280-25-022788:mdna:11]
[same as prior period, unchanged from 0001628280-25-004288:mdna:11]

[0001628280-25-022788:mdna:12]
[same as prior period, unchanged from 0001628280-25-004288:mdna:12]

[0001628280-25-022788:mdna:13]
Our Industrial Tech products include short pulse solid-state lasers, kilowatt-class fiber lasers, diode lasers, and gas lasers, which address applications in numerous end-markets. In the consumer end-market, our laser light sources are integrated into our customers’ 3D sensing cameras, which are used in mobile devices, payment kiosks, and other consumer electronics devices to enable applications including biometric identification, computational photography and virtual and augmented reality. In the automotive end-market, our lasers are used in our customers’ LiDAR and other optical sensor devices, which are increasingly being used in advanced driver assistance systems (“ADAS”) and in-cabin driver and occupant monitoring systems. In the industrial manufacturing end-market, our lasers are incorporated into our customers’ manufacturing machine tools used for the precision processing of materials in a range of industries including semiconductor device and microelectronics fabrication, electric vehicle and battery production, metal cutting and welding, and advanced manufacturing. Our products can also be used in the industrial end-market in imaging and sensing systems for process feedback and control, quality assurance, and waste reduction. Adoption of our products in the industrial end-market is driven by the needs of customers to advance semiconductor and microelectronics industry roadmaps, and by Industry 4.0/5.0 trends, including increasing manufacturing precision and flexibility and reducing waste and environmental impact. Demand for our products in the industrial end-market is driven by end-customer investments in manufacturing capacity. Our lasers also address certain semiconductor inspection and life-science applications.

[0001628280-25-022788:mdna:14]
[same as prior period, unchanged from 0001628280-25-004288:mdna:15]

[0001628280-25-022788:mdna:15]
[same as prior period, unchanged from 0001628280-25-004288:mdna:16]

[0001628280-25-022788:mdna:16]
[same as prior period, unchanged from 0001628280-25-004288:mdna:17]

[0001628280-25-022788:mdna:17]
[same as prior period, unchanged from 0001628280-25-004288:mdna:18]

[0001628280-25-022788:mdna:18]
Our business and our customers’ businesses were negatively impacted by worldwide logistics and supply chain issues during the COVID-19 pandemic, including constraints on available cargo capabilities and limited availability of once broadly available supplies of both raw materials and finished components. COVID-19 also created dynamics in the semiconductor component supply chains that have led to shortages of the types of components we and our customers require in our products. Although the supply chain constraints started to improve in the latter half of fiscal 2023, we felt its ongoing effects in fiscal 2024, as described below. From time to time, we have had to incur incremental supply and procurement costs in order to increase our ability to fulfill demands from our customers.

[0001628280-25-022788:mdna:19]
In addition, in response to component shortages, certain of our customers accumulated inventory that they began managing down in fiscal year 2024 as supply conditions improved. Customers who had built up large inventories when supply chains were tight brought down inventories as supply chain constraints eased and in some cases these customers delayed projected shipments, which caused our revenue to decline and our margins have been adversely impacted as we have not able to fully recover costs, such as underutilized manufacturing capacity. However, we have recently seen signs of inventory normalization at network equipment manufacturers since the first fiscal quarter of 2025 and have seen continued improvement through the third fiscal quarter of 2025.

[0001628280-25-022788:mdna:20]
The Company is also actively monitoring and assessing the ongoing global trade environment, particularly with respect to recent changes in tariff regulations. The ongoing uncertainty surrounding trading policies, including the potential for additional tariffs or retaliatory measures by foreign governments, continues to create a volatile environment that could disrupt our operations. The imposition of tariffs on certain imported goods and materials may increase our costs and place upward pressure on the cost of goods sold, which, in turn, may reduce our gross margins if we are unable to pass these costs onto customers through price increases.

[0001628280-25-022788:mdna:21]
If these tariff-related cost increases persist or escalate, our financial results could be adversely affected, including lower profitability, reduced market competitiveness and a slowdown in consumer demand. Additionally, changes in the global trade landscape could result in disruptions to our supply chain, including longer lead times, higher shipping costs, or limited availability of key inputs. This may further constrain our ability to meet customer demand in a timely manner, potentially affecting our revenue growth and operational efficiency. The impact of tariffs is dependent upon negotiations with customers and suppliers and other mitigation efforts and potential further changes in global trade policies, including higher tariffs in the U.S. or other countries.

[0001628280-25-022788:mdna:22]
[same as prior period, unchanged from 0001628280-25-004288:mdna:21]

[0001628280-25-022788:mdna:23]
[same as prior period, unchanged from 0001628280-25-004288:mdna:22]

[0001628280-25-022788:mdna:24]
[same as prior period, unchanged from 0001628280-25-004288:mdna:23]

[0001628280-25-022788:mdna:25]
[same as prior period, unchanged from 0001628280-25-004288:mdna:24]

[0001628280-25-022788:mdna:26]
[same as prior period, unchanged from 0001628280-25-004288:mdna:25]

[0001628280-25-022788:mdna:27]
[same as prior period, unchanged from 0001628280-25-004288:mdna:26]

[0001628280-25-022788:mdna:28]
[same as prior period, unchanged from 0001628280-25-004288:mdna:27]

[0001628280-25-022788:mdna:29]
[same as prior period, unchanged from 0001628280-25-004288:mdna:28]

[0001628280-25-022788:mdna:30]
Management’s Discussion and Analysis of Financial Condition and Results of Operations contained in Part II, Item 7 of our Annual Report on Form 10-K for our fiscal year ended June 29, 2024 provides a complete discussion of our critical accounting policies and estimates. There have been no changes to these policies during the three and nine months ended March 29, 2025.

[0001628280-25-022788:mdna:31]
Recently Issued Accounting Pronouncements

[0001628280-25-022788:mdna:32]
Refer to “Note 2. Recently Issued Accounting Pronouncements” in the notes to condensed consolidated financial statements.

[0001628280-25-022788:mdna:33]
[same as prior period, unchanged from 0001628280-25-004288:mdna:32]

[0001628280-25-022788:mdna:34]
[same as prior period, unchanged from 0001628280-25-004288:mdna:33]

[0001628280-25-022788:mdna:35]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29, 2025 |  | March 30, 2024 |  | March 29, 2025 |  | March 30, 2024 |
| Segment net revenue: |  |  |  |  |  |  |  |
| Cloud & Networking | 85.9 | % |  | 85.6 | % |  | 84.7 | % |  | 79.0 | % |
| Industrial Tech | 14.1 |  |  | 14.4 |  |  | 15.3 |  |  | 21.0 |  |
| Net revenue | 100.0 |  |  | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of sales | 66.7 |  |  | 77.7 |  |  | 68.8 |  |  | 75.1 |  |
| Amortization of acquired developed intangibles | 4.5 |  |  | 6.1 |  |  | 5.4 |  |  | 5.9 |  |
| Gross profit | 28.8 |  |  | 16.2 |  |  | 25.8 |  |  | 19.1 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 17.9 |  |  | 21.1 |  |  | 19.3 |  |  | 21.8 |  |
| Selling, general and administrative | 26.3 |  |  | 21.2 |  |  | 22.7 |  |  | 22.4 |  |
| Restructuring and related charges | 1.7 |  |  | 5.2 |  |  | 1.5 |  |  | 3.4 |  |
| Gain on sale of facility | (8.2) |  |  | — |  |  | (3.0) |  |  | — |  |
| Total operating expenses | 37.7 |  |  | 47.5 |  |  | 40.5 |  |  | 47.7 |  |
| Loss from operations | (8.9) |  |  | (31.3) |  |  | (14.7) |  |  | (28.6) |  |
| Interest expense | (1.3) |  |  | (2.5) |  |  | (1.5) |  |  | (2.7) |  |
| Other income, net | 1.0 |  |  | 4.4 |  |  | 2.4 |  |  | 4.8 |  |
| Loss before income taxes | (9.2) |  |  | (29.3) |  |  | (13.8) |  |  | (26.5) |  |
| Income tax provision | 1.2 |  |  | 5.3 |  |  | 2.3 |  |  | 1.5 |  |
| Net loss | (10.4) | % |  | (34.7) | % |  | (16.1) | % |  | (28.0) | % |

[0001628280-25-022788:mdna:36]
[same as prior period, unchanged from 0001628280-25-004288:mdna:35]

[0001628280-25-022788:mdna:37]
Financial data for the three and nine months ended March 29, 2025

[0001628280-25-022788:mdna:38]
[same as prior period, unchanged from 0001628280-25-004288:mdna:37]

[0001628280-25-022788:mdna:39]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29, 2025 |  | March 30, 2024 |  | Change |  | Percentage Change |  | March 29, 2025 |  | March 30, 2024 |  | Change |  | Percentage Change |
| Segment net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cloud & Networking | $ | 365.2 |  |  | 313.8 |  |  | $ | 51.4 |  |  | 16.4 | % |  | $ | 986.7 |  |  | $ | 830.2 |  |  | $ | 156.5 |  |  | 18.9 | % |
| Industrial Tech | 60.0 |  |  | 52.7 |  |  | 7.3 |  |  | 13.9 | % |  | 177.6 |  |  | 220.7 |  |  | (43.1) |  |  | (19.5) | % |
| Net revenue | $ | 425.2 |  |  | $ | 366.5 |  |  | $ | 58.7 |  |  | 16.0 | % |  | $ | 1,164.3 |  |  | $ | 1,050.9 |  |  | $ | 113.4 |  |  | 10.8 | % |
| Gross profit | $ | 122.5 |  |  | $ | 59.5 |  |  | $ | 63.0 |  |  | 105.9 | % |  | $ | 300.0 |  |  | $ | 200.2 |  |  | $ | 99.8 |  |  | 49.9 | % |
| Gross margin | 28.8 | % |  | 16.2 | % |  |  |  |  |  | 25.8 | % |  | 19.1 | % |  |  |  |  |
| Research and development | $ | 75.9 |  |  | $ | 77.2 |  |  | $ | (1.3) |  |  | (1.7) | % |  | $ | 224.4 |  |  | $ | 229.0 |  |  | $ | (4.6) |  |  | (2.0) | % |
| Percentage of net revenue | 17.9 | % |  | 21.1 | % |  |  |  |  |  | 19.3 | % |  | 21.8 | % |  |  |  |  |
| Selling, general and administrative | $ | 112.0 |  |  | $ | 77.7 |  |  | $ | 34.3 |  |  | 44.1 | % |  | $ | 264.6 |  |  | $ | 235.8 |  |  | $ | 28.8 |  |  | 12.2 | % |
| Percentage of net revenue | 26.3 | % |  | 21.2 | % |  |  |  |  |  | 22.7 | % |  | 22.4 | % |  |  |  |  |
| Restructuring and related charges | $ | 7.2 |  |  | $ | 19.2 |  |  | $ | (12.0) |  |  | (62.5) | % |  | $ | 17.6 |  |  | $ | 36.0 |  |  | $ | (18.4) |  |  | (51.1) | % |
| Percentage of net revenue | 1.7 | % |  | 5.2 | % |  |  |  |  |  | 1.5 | % |  | 3.4 | % |  |  |  |  |
| Gain on sale of facility | $ | (34.9) |  |  | $ | — |  |  | $ | (34.9) |  |  | 100.0 | % |  | $ | (34.9) |  |  | $ | — |  |  | $ | (34.9) |  |  | 100.0 | % |
| Percentage of net revenue | (8.2) | % |  | — | % |  |  |  |  |  | (3.0) | % |  | — | % |  |  |  |  |

[0001628280-25-022788:mdna:40]
[same as prior period, unchanged from 0001628280-25-004288:mdna:39]

[0001628280-25-022788:mdna:41]
[same as prior period, unchanged from 0001628280-25-004288:mdna:40]

[0001628280-25-022788:mdna:42]
Net revenue increased by $58.7 million, or 16.0%, during the three months ended March 29, 2025 compared to the three months ended March 30, 2024, driven by a $51.4 million increase in Cloud & Networking revenue and a  $7.3 million increase in Industrial Tech revenue. The increase in Cloud & Networking net revenue is primarily driven by $40.9 million of higher revenue from network equipment manufacturers due to the continued market recovery and related inventory normalization. In addition, we recognized an increase in revenue of $10.5 million from cloud and AI/ML customers. The increase in Industrial Tech net revenue is primarily due to a $12.8 million increase in our laser products driven by higher market demand offset by a $5.6 million decrease for our imaging and sensing products due to higher market competition in the consumer end-market.

[0001628280-25-022788:mdna:43]
Net revenue increased by $113.4 million, or 10.8%, during the nine months ended March 29, 2025 compared to the nine months ended March 30, 2024, driven by a $156.5 million increase in Cloud & Networking revenue offset by a  $43.1 million decrease in Industrial Tech revenue. The increase in Cloud & Networking net revenue is primarily due to higher revenue from cloud and AI/ML customers, which increased by $115.6 million, inclusive of revenue from Cloud Light, which we acquired in the second quarter of fiscal 2024. In addition, we recognized an increase in revenue of $40.9 million from network equipment manufacturers as a result of ongoing market recovery and the related inventory normalization. The decrease in Industrial Tech net revenue is primarily due to a decline in sales of our imaging and sensing products due to higher market competition in the consumer end-market for these products, which is partially offset by an $11.8 million increase in our laser products due to higher market demand.

[0001628280-25-022788:mdna:44]
During the three months ended March 29, 2025, two customers individually accounted for 17%, and 15% of our total revenue, respectively. During the nine months ended March 29, 2025, three customers individually accounted for 16%, 14% and 10% of our total net revenue, respectively. We had no other customers that represented 10% or greater of our total net revenue.

[0001628280-25-022788:mdna:45]
During the three months ended March 30, 2024, one customer individually accounted for 29% of our total revenue. During the nine months ended March 30, 2024, two customers individually accounted for 19% and 12% of our total net revenue, respectively. We had no other customers that represented 10% or greater of our total net revenue.

[0001628280-25-022788:mdna:46]
[same as prior period, unchanged from 0001628280-25-004288:mdna:45]

[0001628280-25-022788:mdna:47]
[same as prior period, unchanged from 0001628280-25-004288:mdna:46]

[0001628280-25-022788:mdna:48]
[same as prior period, unchanged from 0001628280-25-004288:mdna:47]

[0001628280-25-022788:mdna:49]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29, 2025 |  | March 30, 2024 |  | March 29, 2025 |  | March 30, 2024 |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 70.5 |  |  | 16.6 | % |  | $ | 129.9 |  |  | 35.4 | % |  | $ | 213.5 |  |  | 18.3 | % |  | $ | 274.0 |  |  | 26.2 | % |
| Mexico | 38.8 |  |  | 9.1 |  |  | 18.9 |  |  | 5.2 |  |  | 110.1 |  |  | 9.5 |  |  | 74.0 |  |  | 7.0 |  |
| Other Americas | 6.4 |  |  | 1.5 |  |  | 0.6 |  |  | 0.2 |  |  | 13.5 |  |  | 1.2 |  |  | 2.6 |  |  | 0.2 |  |
| Total Americas | $ | 115.7 |  |  | 27.2 | % |  | $ | 149.4 |  |  | 40.8 | % |  | $ | 337.1 |  |  | 29.0 | % |  | $ | 350.6 |  |  | 33.4 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 96.5 |  |  | 22.7 | % |  | $ | 62.0 |  |  | 16.9 | % |  | $ | 285.7 |  |  | 24.5 | % |  | $ | 192.6 |  |  | 18.3 | % |
| South Korea | 9.2 |  |  | 2.2 |  |  | 16.2 |  |  | 4.4 |  |  | 24.8 |  |  | 2.1 |  |  | 62.0 |  |  | 5.9 |  |
| Japan | 20.8 |  |  | 4.9 |  |  | 16.6 |  |  | 4.5 |  |  | 56.1 |  |  | 4.8 |  |  | 67.9 |  |  | 6.5 |  |
| Thailand | 79.1 |  |  | 18.6 |  |  | 44.0 |  |  | 12.0 |  |  | 206.3 |  |  | 17.7 |  |  | 147.5 |  |  | 14.0 |  |
| Other Asia-Pacific | 61.6 |  |  | 14.5 |  |  | 46.0 |  |  | 12.6 |  |  | 140.6 |  |  | 12.1 |  |  | 135.0 |  |  | 12.8 |  |
| Total Asia-Pacific | $ | 267.2 |  |  | 62.9 | % |  | $ | 184.8 |  |  | 50.4 | % |  | $ | 713.5 |  |  | 61.2 | % |  | $ | 605.0 |  |  | 57.5 | % |
| EMEA | $ | 42.3 |  |  | 9.9 | % |  | $ | 32.3 |  |  | 8.8 | % |  | $ | 113.7 |  |  | 9.8 | % |  | $ | 95.3 |  |  | 9.1 | % |
| Total net revenue | $ | 425.2 |  |  | 100.0 | % |  | $ | 366.5 |  |  | 100.0 | % |  | $ | 1,164.3 |  |  | 100.0 | % |  | $ | 1,050.9 |  |  | 100.0 | % |

[0001628280-25-022788:mdna:50]
For the three and nine months ended March 29, 2025, net revenue from customers outside the United States, based on customer shipping location, represented 83.4% and 81.7% of net revenue, respectively.

[0001628280-25-022788:mdna:51]
For the three and nine months ended March 30, 2024, net revenue from customers outside the United States, based on customer shipping location, represented 64.7% and 73.9% of net revenue, respectively.

[0001628280-25-022788:mdna:52]
[same as prior period, unchanged from 0001628280-25-004288:mdna:51]

[0001628280-25-022788:mdna:53]
[same as prior period, unchanged from 0001628280-25-004288:mdna:52]

[0001628280-25-022788:mdna:54]
Gross margin for the three months ended March 29, 2025 increased to 28.8% from 16.2% for the three months ended March 30, 2024. Within our segments, our Cloud & Networking segment gross margin increased by 3.1% during the three months ended March 29, 2025 due primarily to a mix shift to our higher margin products (for cloud and AI/ML applications as well as our transport products). Industrial Tech segment gross margin was approximately flat during the three months ended March 29, 2025 as compared to the three months ended March 30, 2024. In addition to the positive impact of higher revenue, during the three months ended March 29, 2025, charges related to acquisitions, including integration costs, manufacturing consolidations, and amortization of inventory fair value adjustments decreased by $16.0 million compared to the prior period.

[0001628280-25-022788:mdna:55]
There were also abnormal excess capacity charges of $11.9 million during the three months ended March 30, 2024, which we did not incur during the three months ended March 29, 2025.

[0001628280-25-022788:mdna:56]
Gross  margin for the nine months ended March 29, 2025 increased to 25.8% from 19.1% for the nine months ended March 30, 2024. The increase was driven by a $14.0 million reduction in excess and obsolete inventory charges during the nine months ended March 29, 2025 primarily as a result of the U.S. trade restrictions imposed during the three months ended March 30, 2024 whereby we were no longer able to sell certain products to one of our customers. In addition, costs incurred during the nine months ended March 29, 2025 related to the acquisition of Cloud Light, including integration costs and amortization of inventory fair value adjustments were $22.2 million lower compared to the prior year period. Our Cloud & Networking as well as Industrial Tech segment gross margin were both approximately flat year over year.

[0001628280-25-022788:mdna:57]
The markets in which we sell products are undergoing product, architectural and business model transitions, have high customer concentrations, are highly competitive, are price sensitive and/or are affected by customer seasonal and variants in buying patterns. We expect these factors to result in variability of our gross margin and our gross margin may be subject to increasing downward pressure due to these factors.

[0001628280-25-022788:mdna:58]
[same as prior period, unchanged from 0001628280-25-004288:mdna:57]

[0001628280-25-022788:mdna:59]
[same as prior period, unchanged from 0001628280-25-004288:mdna:58]

[0001628280-25-022788:mdna:60]
|  | Three Months Ended |  | Nine Months Ended |  |  |  |  |
|  | March 29, 2025 |  | March 30, 2024 |  | March 29, 2025 |  | March 30, 2024 |  |  |  |  |
| Cloud & Networking | $ | 73.1 |  |  | 45.9 |  |  | $ | 164.5 |  |  | $ | 98.9 |  |  |  |  |  |
| Industrial Tech | 2.6 |  |  | (2.7) |  |  | 8.7 |  |  | 25.3 |  |  |  |  |  |

[0001628280-25-022788:mdna:61]
Cloud & Networking segment profit increased by $27.2 million, or 59.3%, during the three months ended March 29, 2025 as compared to the three months ended March 30, 2024 primarily due to higher sales of our products for cloud and AI/ML applications as well as our transport products. Industrial Tech segment profit increased by $5.3 million, or 196.3%, during the three months ended March 29, 2025 as compared to the three months ended March 30, 2024 primarily due to higher revenue  from our laser products slightly offset by lower revenue from  sales of imaging and sensing products to consumer electronics customers.

[0001628280-25-022788:mdna:62]
Cloud & Networking segment profit increased by $65.6 million, or 66.3%, during the nine months ended March 29, 2025 as compared to the nine months ended March 30, 2024 primarily due to higher sales of our products for both cloud and AI/ML applications. Industrial Tech segment profit decreased by $16.6 million, or 65.6%, during the nine months ended March 29, 2025 as compared to the nine months ended March 30, 2024 primarily due to lower revenue, mainly from sales of imaging and sensing products.

[0001628280-25-022788:mdna:63]
[same as prior period, unchanged from 0001628280-25-004288:mdna:62]

[0001628280-25-022788:mdna:64]
R&D expense decreased by $1.3 million, or 1.7% for the three months ended March 29, 2025 compared to the three months ended March 30, 2024, primarily due to $2.4 million of lower payroll and other compensation related expenses. These lower compensation expenses were driven by lower headcount as a result of restructuring actions primarily due to the discontinuation of our in-house development of coherent Digital Signal Processors (“DSPs”) and Radio Frequency Integrated Circuits (“RFICs”). This was partially offset by higher spending in software and computer supplies used for R&D purposes.

[0001628280-25-022788:mdna:65]
R&D expense decreased by $4.6 million, or 2.0% for the nine months ended March 29, 2025 compared to the nine months ended March 30, 2024. The decrease in R&D expense for the nine months ended March 30, 2024 was primarily driven by $7.1 million of lower payroll and other compensation related expenses due to lower headcount as a result of restructuring actions primarily due to the discontinuation of our in-house development of coherent DSPs and RFICs. This was partially offset by $2.7 million and $1.7 million of higher depreciation expense and stock-based compensation expense, respectively.

[0001628280-25-022788:mdna:66]
[same as prior period, unchanged from 0001628280-25-004288:mdna:65]

[0001628280-25-022788:mdna:67]
[same as prior period, unchanged from 0001628280-25-004288:mdna:66]

[0001628280-25-022788:mdna:68]
SG&A expense increased by $34.3 million, or 44.1%, during the three months ended March 29, 2025 compared to the three months ended March 30, 2024. This is primarily driven by an increase of $29.1 million in stock-based compensation driven by equity award modifications as well as $5.2 million of severance and sign-on payments, all related to executive employee transitions. This was partially offset by a $4.4 million of reduction in amortization of intangible assets as it was fully amortized.

[0001628280-25-022788:mdna:69]
SG&A expense increased by $28.8 million, or 12.2%, during the nine months ended March 29, 2025 compared to the nine months ended March 30, 2024. This is primarily driven by an increase of $32.5 million in stock-based compensation driven by equity award modifications as well as $5.2 million of severance and sign-on payments, all related to executive employee transitions, and a $5.2 million of incremental amortization of intangible assets associated with the Cloud Light acquisition. This was partially offset by $12.6 million of lower acquisition costs related to Cloud Light, which we acquired in second quarter of fiscal year 2024, as well as a reduction in payroll related expenses as a result of restructuring actions in the prior periods.

[0001628280-25-022788:mdna:70]
From time-to-time, we incur expenses that are not part of our ordinary operations, such as mergers and acquisition-related and litigation expenses, which generally increase our SG&A expenses and potentially impact our profitability expectations in any particular period.

[0001628280-25-022788:mdna:71]
[same as prior period, unchanged from 0001628280-25-004288:mdna:70]

[0001628280-25-022788:mdna:72]
[same as prior period, unchanged from 0001628280-25-004288:mdna:71]

[0001628280-25-022788:mdna:73]
During the three and nine months ended March 29, 2025, we recorded restructuring and related charges of $7.2 million and $17.6 million, respectively mainly due to our integration efforts and cost reduction initiatives. Restructuring charges for  the three months ended March 29, 2025 primarily related to $5.7 million of assets written-off including property, plant and equipment, prepayments and other current assets as well as $1.4 million of charges for other contractual commitments associated with site closures driven by restructuring initiatives announced in April 2025 that will allow us to focus on other market opportunities including cloud and AI markets. The Company expects to incur further restructuring charges in the fourth quarter of fiscal year 2025 for employee severance and other personnel-related costs as a result of these actions, which we estimate to be less than $5.0 million.

[0001628280-25-022788:mdna:74]
Restructuring charges for the nine months ended March 29, 2025 include $12.4 million of assets written-off including property, plant and equipment, prepayments and other current assets primarily due to efforts to consolidate our sites and focus on other market opportunities including cloud and AI markets. In addition, we also recorded $3.0 million of charges related to the discontinuation of our in-house development of coherent Digital Signal Processors (“DSPs”) and Radio Frequency Integrated Circuits (“RFICs”).

[0001628280-25-022788:mdna:75]
During the three and nine months ended March 30, 2024, we recorded restructuring and related charges of $19.2 million and $36.0 million, respectively, primarily due to company-wide cost reduction initiatives, as well as our integration efforts as a result of the NeoPhotonics acquisition in August 2022.

[0001628280-25-022788:mdna:76]
Gain on Sale of Facility

[0001628280-25-022788:mdna:77]
On December 17, 2024, we entered into an agreement to sell our net assets in an entity in Shenzhen, China. On March 5, 2025, we completed the sale and received net proceeds of $47.8 million, which was net of cash of $17.6 million and direct selling costs of $1.1 million. The net assets sold consist primarily of building, building improvements and land rights as of December 17, 2024 with a net carrying value of $12.9 million, and were used by the Cloud and Networking segment for manufacturing and research and development activities. As a result, we recognized a gain on sale of facility of $34.9 million, which was recorded in our condensed consolidated statements of operations for the three and nine months ended March 29, 2025. We paid $4.4 million of withholding taxes on this sale transaction, which is recorded as part of the income tax provision for the three and nine months ended March 29, 2025. We also incurred $0.4 million and $0.7 million of indirect selling expenses related to this transaction, which was recorded as part of selling, general and administrative expenses in our condensed consolidated statements of operations for the three and nine months ended March 29, 2025.

[0001628280-25-022788:mdna:78]
[same as prior period, unchanged from 0001628280-25-004288:mdna:74]

[0001628280-25-022788:mdna:79]
For the three months ended March 29, 2025 and March 30, 2024, we recorded interest expense of $5.7 million and $9.0 million, respectively. For the nine months ended March 29, 2025 and March 30, 2024, we recorded interest expense of $16.8 million and $28.4 million, respectively. The decrease in interest expense for the three and nine months ended March 29, 2025 is mainly due to the repayment of our 0.25% convertible senior notes due in 2024 (the “2024 Notes”) upon maturity in March 2024.

[0001628280-25-022788:mdna:80]
[same as prior period, unchanged from 0001628280-25-004288:mdna:76]

[0001628280-25-022788:mdna:81]
[same as prior period, unchanged from 0001628280-25-004288:mdna:77]

[0001628280-25-022788:mdna:82]
|  | Three Months Ended |  | Nine Months Ended |  |  |
|  | March 29, 2025 |  | March 30, 2024 |  | March 29, 2025 |  | March 30, 2024 |  |  |
| Foreign exchange and other gains (losses), net | $ | (3.6) |  |  | $ | 3.7 |  |  | $ | 1.6 |  |  | $ | (0.5) |  |  |  |
| Interest and investment income, net | 7.8 |  |  | 12.6 |  |  | 26.2 |  |  | 51.4 |  |  |  |
| Other income (expense), net | — |  |  | (0.1) |  |  | — |  |  | (0.1) |  |  |  |
| Total other income, net | $ | 4.2 |  |  | $ | 16.2 |  |  | $ | 27.8 |  |  | $ | 50.8 |  |  |  |

[0001628280-25-022788:mdna:83]
Other income, net for the three months ended March 29, 2025 decreased by $12.0 million compared to the three months ended March 30, 2024 primarily due to an increase in net foreign exchange losses of $7.3 million. During the three months ended March 30, 2024, the Company had a net foreign exchange gain of $3.7 million as a result of strengthening other foreign currencies relative to the U.S. dollar as compared to a $3.6 million net foreign exchange loss during the three months ended March 29, 2025 mainly driven by the Japan term loans denominated in Japanese Yen. In addition, interest and investment income decreased by $4.8 million driven by lower short term investment balances primarily due to repayment of the 2024 Notes in March 2024.

[0001628280-25-022788:mdna:84]
Other income, net for the nine months ended March 29, 2025 decreased by $23.0 million from the nine months ended March 30, 2024 due to $25.2 million of decrease in interest and investment income driven by lower short term investment balances, as we used cash to purchase Cloud Light as well as the repayment of the 2024 Notes in March 2024, offset by an increase in net foreign exchange gain of $2.1 million mainly driven by strengthening of other foreign currencies relative to the U.S. dollar during the nine months ended March 29, 2025.

[0001628280-25-022788:mdna:85]
[same as prior period, unchanged from 0001628280-25-004288:mdna:81]

[0001628280-25-022788:mdna:86]
[same as prior period, unchanged from 0001628280-25-004288:mdna:82]

[0001628280-25-022788:mdna:87]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29, 2025 |  | March 30, 2024 |  | March 29, 2025 |  | March 30, 2024 |
| Income tax provision | $ | 4.9 |  |  | $ | 19.6 |  |  | $ | 26.7 |  |  | $ | 15.8 |  |

[0001628280-25-022788:mdna:88]
We recorded a tax provision of $4.9 million and $26.7 million for the three and nine months ended March 29, 2025, respectively. Our tax provision for the three months ended March 29, 2025 is primarily attributable to the income tax expense from uncertain tax positions and withholding taxes, partially offset by the tax benefit from prior year changes in uncertain tax positions. Our tax provision for the nine months ended March 29, 2025 is primarily attributable to the income tax expense from pre-tax earnings, uncertain tax positions, interest on uncertain tax positions, foreign return to provision differences and withholding taxes, partially offset by the tax benefit from prior year changes in uncertain tax positions.

[0001628280-25-022788:mdna:89]
We recorded a tax provision of $19.6 million and $15.8 million for the three and nine months ended March 30, 2024, respectively. Our tax provision for the three months ended March 30, 2024 includes a discrete tax expense of $17.6 million primarily related to the establishment of a partial valuation allowance against certain deferred tax assets, withholding taxes, and changes in prior year uncertain tax positions, partially offset by the tax benefit of tax rate changes. Our tax provision for the nine months ended March 30, 2024 includes a discrete tax expense of $19.2 million, primarily related the establishment of a partial valuation allowance against certain deferred tax assets, withholding taxes, a shortfall in connection with stock-based compensation vested during the period, and interest on uncertain tax positions, partially offset by the tax benefit from tax rate changes.

[0001628280-25-022788:mdna:90]
Our estimated effective tax rate for the nine months ended March 29, 2025 differs from the 21% U.S. statutory rate primarily due to the income tax expense from foreign rate differential, non-deductible stock-based compensation, current year valuation allowance change, and foreign income inclusions in the U.S., partially offset by the income tax benefit from permanent items and U.S. tax credits.

[0001628280-25-022788:mdna:91]
We regularly assess our ability to realize our deferred tax assets on a quarterly basis and will establish a valuation allowance if it is more-likely-than-not that some portion of the deferred tax assets will not be realized. As of March 29, 2025, we maintain a full valuation allowance on U.S. federal and state and certain foreign deferred tax assets. We will continue to assess the need for a valuation allowance against our remaining deferred tax assets and may increase or decrease our valuation allowance materially in the future.

[0001628280-25-022788:mdna:92]
[same as prior period, unchanged from 0001628280-25-004288:mdna:88]

[0001628280-25-022788:mdna:93]
[same as prior period, unchanged from 0001628280-25-004288:mdna:89]

[0001628280-25-022788:mdna:94]
[same as prior period, unchanged from 0001628280-25-004288:mdna:90]

[0001628280-25-022788:mdna:95]
[same as prior period, unchanged from 0001628280-25-004288:mdna:91]

[0001628280-25-022788:mdna:96]
As of March 29, 2025 and June 29, 2024, our cash and cash equivalents were $516.4 million and $436.7 million, respectively. As of March 29, 2025 and June 29, 2024, our short-term investments of $350.3 million and $450.3 million, respectively, were all held in the United States. Cash equivalents and short-term investments are primarily comprised of money market funds, treasuries, agencies, high quality investment grade fixed income securities, certificates of deposit and commercial paper. Our investment policy and strategy provide for diversification of investments and is focused on the preservation of capital and supporting our liquidity requirements.

[0001628280-25-022788:mdna:97]
The total amount of cash held by the non-United States entities as of March 29, 2025 and June 29, 2024 was $314.5 million and $306.9 million, respectively, which was primarily held by entities incorporated in the United Kingdom, Japan, Hong Kong, China, Switzerland, China and Thailand. Although cash currently held in the United States, as well as cash generated in the United States from future operations, is expected to cover our normal operating requirements, a substantial amount of additional cash could be required for other purposes, such as capital expenditures to support our business and growth, including costs associated with increasing internal manufacturing capabilities, strategic transactions and partnerships, and future acquisitions.

[0001628280-25-022788:mdna:98]
[same as prior period, unchanged from 0001628280-25-004288:mdna:94]

[0001628280-25-022788:mdna:99]
[same as prior period, unchanged from 0001628280-25-004288:mdna:95]

[0001628280-25-022788:mdna:100]
We believe that our cash and cash equivalents as of March 29, 2025 and cash flows from our operating activities will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months.

[0001628280-25-022788:mdna:101]
[same as prior period, unchanged from 0001628280-25-004288:mdna:97]

[0001628280-25-022788:mdna:102]
•global economic conditions which affect demand for our products and services and impact the financial stability of our suppliers and customers, including the impact of trade wars, tariffs, trade restrictions including for certain rare earth minerals, and uncertainty in the banking and financial services industries;

[0001628280-25-022788:mdna:103]
[same as prior period, unchanged from 0001628280-25-004288:mdna:99]

[0001628280-25-022788:mdna:104]
[same as prior period, unchanged from 0001628280-25-004288:mdna:100]

[0001628280-25-022788:mdna:105]
[same as prior period, unchanged from 0001628280-25-004288:mdna:101]

[0001628280-25-022788:mdna:106]
[same as prior period, unchanged from 0001628280-25-004288:mdna:102]

[0001628280-25-022788:mdna:107]
[same as prior period, unchanged from 0001628280-25-004288:mdna:103]

[0001628280-25-022788:mdna:108]
[same as prior period, unchanged from 0001628280-25-004288:mdna:104]

[0001628280-25-022788:mdna:109]
[same as prior period, unchanged from 0001628280-25-004288:mdna:105]

[0001628280-25-022788:mdna:110]
[same as prior period, unchanged from 0001628280-25-004288:mdna:106]

[0001628280-25-022788:mdna:111]
[same as prior period, unchanged from 0001628280-25-004288:mdna:107]

[0001628280-25-022788:mdna:112]
[same as prior period, unchanged from 0001628280-25-004288:mdna:108]

[0001628280-25-022788:mdna:113]
[same as prior period, unchanged from 0001628280-25-004288:mdna:109]

[0001628280-25-022788:mdna:114]
•acquisitions or strategic transactions;

[0001628280-25-022788:mdna:115]
[same as prior period, unchanged from 0001628280-25-004288:mdna:111]

[0001628280-25-022788:mdna:116]
•the timing of settlement or other resolution of legal contingencies; and

[0001628280-25-022788:mdna:117]
[same as prior period, unchanged from 0001628280-25-004288:mdna:113]

[0001628280-25-022788:mdna:118]
[same as prior period, unchanged from 0001628280-25-004288:mdna:114]

[0001628280-25-022788:mdna:119]
The following table summarizes our contractual obligations as of March 29, 2025, and the effect such obligations are expected to have on our liquidity and cash flow (in millions):

[0001628280-25-022788:mdna:120]
|  | Payments Due |
|  | Total |  | Less Than 1 Year |  | More Than 1 Year |  |  |  |  |
| Contractual Obligations |  |  |  |  |  |  |  |  |  |
| Asset retirement obligations | $ | 7.6 |  |  | $ | 0.6 |  |  | $ | 7.0 |  |  |  |  |  |
| Operating lease liabilities, including imputed interest (1) | 39.9 |  |  | 12.8 |  |  | 27.1 |  |  |  |  |  |
| Pension plan contributions (2) | 1.6 |  |  | 1.6 |  |  | — |  |  |  |  |  |
| Purchase obligations (3) | 635.3 |  |  | 594.8 |  |  | 40.5 |  |  |  |  |  |
| Term loans - principal (5) | 67.2 |  |  | 10.3 |  |  | 56.9 |  |  |  |  |  |
| Term loans - interest (5) | 1.8 |  |  | 0.6 |  |  | 1.2 |  |  |  |  |  |
| Convertible notes - principal (4) | 2,514.7 |  |  | — |  |  | 2,514.7 |  |  |  |  |  |
| Convertible notes - interest (4) | 70.9 |  |  | 18.7 |  |  | 52.2 |  |  |  |  |  |
| Total | $ | 3,339.0 |  |  | $ | 639.4 |  |  | $ | 2,699.6 |  |  |  |  |  |

[0001628280-25-022788:mdna:121]
(1) The amounts of operating lease liabilities do not include any sublease income amounts nor do they include payments for short-term leases or variable lease payments. As of March 29, 2025, we expect to receive sublease income of approximately $2.4 million over the sublease periods.

[0001628280-25-022788:mdna:122]
[same as prior period, unchanged from 0001628280-25-004288:mdna:118]

[0001628280-25-022788:mdna:123]
(3) Purchase obligations represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Refer to “Note 14. Commitments and Contingencies” in the notes to condensed consolidated financial statements.

[0001628280-25-022788:mdna:124]
(4) The amounts related to convertible notes include principal and interest on our 0.50% Convertible Senior Notes due 2026 (the “2026 Notes”), principal and interest on our 0.50% Convertible Senior Notes due 2028 (the “2028 Notes”), and principal and interest on our 1.50% Convertible Senior Notes due 2029 (the “2029 Notes”). The 2026 Notes have a maturity date of December 15, 2026, the 2028 Notes have a maturity date of June 15, 2028, and the 2029 Notes have a maturity date of December 15, 2029. The principal balances of our convertible notes are reflected in the payment periods in the table above based on their respective contractual maturities assuming no conversions.

[0001628280-25-022788:mdna:125]
(5) The amounts related to term loans include principal and interest on our Sumitomo Mitsui Banking Corporation (“SMBC”) term loan with a fixed annual interest rate of 0.88% and Mizuho Bank, Ltd. (“Mizuho”) term loan with a fixed annual interest rate of 0.90%. The SMBC term loan requires monthly principal payments with the remaining principal due on the loan maturity date of July 31, 2029 while the Mizuho term loan requires quarterly principal payments with the final payment due on September 20, 2029.

[0001628280-25-022788:mdna:126]
[same as prior period, unchanged from 0001628280-25-004288:mdna:122]

[0001628280-25-022788:mdna:127]
[same as prior period, unchanged from 0001628280-25-004288:mdna:123]

[0001628280-25-022788:mdna:128]
As of March 29, 2025, the net carrying amount of our 2029 Notes of $600.1 million (principal balance of $603.7 million maturing in 2029) is presented in non-current liabilities. If the closing price of our stock exceeds $90.40 (or 130% of the conversion price of $69.54) for 20 of the last 30 trading days of any future quarter, our 2029 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our consolidated balance sheets.

[0001628280-25-022788:mdna:129]
As of March 29, 2025, the net carrying amount of our 2028 Notes of $857.4 million (which have an aggregate principal amount of $861.0 million outstanding that matures in 2028) is presented in non-current liabilities in our condensed consolidated balance sheets. If the closing price of our stock exceeds $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of any future fiscal quarter, our 2028 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-25-022788:mdna:130]
As of March 29, 2025, the net carrying amount of our 2026 Notes of $1,048.0 million (which have an aggregate principal amount of $1,050.0 million outstanding that matures in 2026) is presented in non-current liabilities in our condensed consolidated balance sheets. If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future fiscal quarter, our 2026 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-25-022788:mdna:131]
As of March 29, 2025, the Company had $40.2 million in principal amount outstanding on our SMBC term loan, of which the short-term portion of $4.3 million is recorded as current liabilities while the long-term portion of $35.9 million is recorded as long-term debt in the Company’s condensed consolidated balance sheets.

[0001628280-25-022788:mdna:132]
As of March 29, 2025, the Company had $27.0 million in principal amount outstanding on our Mizuho term loan, of which the short-term portion of $6.0 million is recorded as current liabilities while the long-term portion of $21.0 million is recorded as long-term debt in the Company’s condensed consolidated balance sheets.

[0001628280-25-022788:mdna:133]
[same as prior period, unchanged from 0001628280-25-004288:mdna:129]

[0001628280-25-022788:mdna:134]
We have a share buyback program that authorizes us to utilize up to an aggregate amount of $1.2 billion to purchase our own shares of common stock through May 2025. During the nine months ended March 29, 2025, we did not repurchase any shares of our common stock. Since the board of directors initially approved the share buyback program, we have repurchased 7.7 million shares in aggregate at an average price of $81.66 per share for a total purchase price of $630.4 million. We recorded the $630.4 million aggregate purchase price as a reduction of retained earnings within our condensed consolidated balance sheet. All repurchased shares were retired immediately. As of March 29, 2025, we have $569.6 million remaining under the share buyback program.

[0001628280-25-022788:mdna:135]
The price, timing, amount, and method of future repurchases will be determined based on our evaluation of business and market conditions, alternative investment opportunities, and other factors, at prices determined to be attractive and in the best interests of both the Company and our stockholders. The stock repurchase program may be suspended or terminated at any time.

[0001628280-25-022788:mdna:136]
[same as prior period, unchanged from 0001628280-25-004288:mdna:132]

[0001628280-25-022788:mdna:137]
As of March 29, 2025 and June 29, 2024, our other non-current liabilities include unrecognized tax benefit for uncertain tax positions of $76.1 million and $83.0 million, respectively. We are unable to reliably estimate the timing of future payments related to uncertain tax positions.

[0001628280-25-022788:mdna:138]
[same as prior period, unchanged from 0001628280-25-004288:mdna:134]

[0001628280-25-022788:mdna:139]
Our balance of cash and cash equivalents increased by $79.7 million from $436.7 million as of June 29, 2024 to $516.4 million as of March 29, 2025. The increase in cash and cash equivalents during the nine months ended March 29, 2025 was due to cash from operating activities of $62.3 million and cash from financing activities of $42.1 million, offset by cash used in investing activities of $24.7 million.

[0001628280-25-022788:mdna:140]
[same as prior period, unchanged from 0001628280-25-004288:mdna:136]

[0001628280-25-022788:mdna:141]
Cash from operating activities was $62.3 million during the nine months ended March 29, 2025, which reflects a net loss of $187.4 million, offset by non-cash items of $309.4 million and changes in operating assets and liabilities of $59.7 million. Changes in operating assets and liabilities were primarily driven by an increase in accounts payable of $44.9 million primarily due to higher inventory purchases and capital expenditures, an increase of $6.9 million in accrued payroll and related expenses mainly driven by our accrual on employee annual incentive plan, and an increase in income tax liabilities of $16.8 million primarily due to income tax provision for the nine months ended March 29, 2025, offset by an increase in accounts receivable of $64.4 million mainly driven by higher revenue, an increase of $25.7 million in inventories driven by inventory builds to support market demand, an increase of $21.7 million in prepayments and other current and non-current assets related mainly to value-added-tax receivables driven by higher recent capital expenditures and inventory purchases and a decrease of $15.3 million in accrued expenses and other current and non-current liabilities driven by payment of the net settlement amount of the Oclaro merger litigation and restructuring related payments.

[0001628280-25-022788:mdna:142]
Cash used in operating activities was $10.8 million during the nine months ended March 30, 2024, which reflects a net loss of $294.0 million and changes in operating assets and liabilities of $19.1 million, offset by non-cash items of $302.3 million. Changes in operating assets and liabilities were primarily driven by a decrease in accounts payable of $82.8 million primarily due to lower inventory purchases and linearity of payments, and a decrease in income tax liabilities of $37.3 million primarily due to annual income tax payments in Japan, offset by a decrease in accounts receivable of $37.2 million due to lower revenue and a decrease in inventories of $52.5 million primarily due to reduced inventory level in our Cloud & Networking business.

[0001628280-25-022788:mdna:143]
[same as prior period, unchanged from 0001628280-25-004288:mdna:139]

[0001628280-25-022788:mdna:144]
Cash used in investing activities of $24.7 million during the nine months ended March 29, 2025 was attributable to capital expenditures of $177.1 million, offset by net proceeds from sales or maturities of short-term investments of $104.3 million, $47.8 million of proceeds from sale of facility, net of cash transferred and selling costs, and proceeds from sales of property and equipment of $0.3 million.

[0001628280-25-022788:mdna:145]
Cash used in investing activities of $86.8 million during the nine months ended March 30, 2024 was attributable to cash used in the acquisition of Cloud Light of $700.9 million, net of cash acquired, capital expenditures of $108.4 million, and an intangible asset acquisition of $4.0 million, offset by net proceeds from sales or maturities of short-term investments of $727.5 million and proceeds from sales of property and equipment of $0.8 million.

[0001628280-25-022788:mdna:146]
[same as prior period, unchanged from 0001628280-25-004288:mdna:142]

[0001628280-25-022788:mdna:147]
Cash from financing activities of $42.1 million during the nine months ended March 29, 2025 was attributable to $76.5 million of proceeds from SMBC and Mizuho term loans and $8.3 million of proceeds from employee stock plans, offset by tax payments related to net share settlement of restricted stock of $36.3 million, payment for an intangible asset acquisition holdback of $1.0 million and $5.4 million of principal payments on term loans.

[0001628280-25-022788:mdna:148]
Cash used in financing activities of $336.4 million during the nine months ended March 30, 2024 was attributable to $323.1 million of repayment of the principal amount of 2024 Notes upon maturity, tax payments related to net share settlement of restricted stock of $20.6 million, offset by $7.3 million of proceeds from employee stock plans.
