# LITE 8-K — 0001628280-26-055726 filed 2026-08-11

## item codes, every 8-K on or before 2026-08-17

- 2026-08-11 0001628280-26-055726 — 2.02, 9.01
- 2026-07-30 0001628280-26-051078 — 5.02
- 2026-06-01 0001193125-26-249535 — 3.02
- 2026-05-05 0001628280-26-030530 — 2.02, 9.01
- 2026-04-08 0001193125-26-146256 — 3.02
- 2026-03-02 0001193125-26-085412 — 3.02, 5.03, 7.01, 9.01
- 2026-02-03 0001628280-26-005005 — 2.02, 9.01
- 2026-01-05 0001193125-26-002602 — 5.02
- 2025-12-22 0001193125-25-328691 — 1.01, 2.03, 9.01
- 2025-12-15 0001628280-25-057025 — 5.02, 9.01
- 2025-11-24 0001628280-25-053795 — 5.02, 5.07, 9.01
- 2025-11-04 0001628280-25-048860 — 2.02, 9.01
- 2025-09-08 0001193125-25-198329 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2025-08-12 0001628280-25-039896 — 2.02, 9.01
- 2025-06-03 0001628280-25-029086 — 7.01, 9.01
- 2025-05-06 0001628280-25-022709 — 2.02, 9.01
- 2025-02-06 0001628280-25-004265 — 2.02, 9.01
- 2025-02-03 0001193125-25-019371 — 2.02, 5.02, 9.01
- 2024-12-12 0001193125-24-277338 — 5.02, 9.01
- 2024-11-22 0001628280-24-048886 — 5.02, 5.07, 9.01
- 2024-11-07 0001628280-24-046302 — 2.02, 9.01
- 2024-08-21 0001628280-24-037938 — 2.02, 9.01 — amendment of 0001628280-24-037191
- 2024-08-14 0001628280-24-037191 — 2.02, 9.01
- 2024-05-06 0001628280-24-020640 — 2.02, 9.01
- 2024-02-27 0001628280-24-006936 — 5.02
- 2024-02-08 0001628280-24-003789 — 2.02, 9.01
- 2024-01-18 0001628280-24-001551 — 9.01 — amendment of 0001193125-23-272452
- 2023-11-21 0001628280-23-039654 — 5.02, 5.07
- 2023-11-08 0001628280-23-037563 — 2.02, 9.01
- 2023-11-07 0001193125-23-272452 — 2.01, 8.01, 9.01
- 2023-10-30 0001193125-23-265658 — 1.01, 2.02, 9.01
- 2023-08-17 0001628280-23-029741 — 2.02, 9.01
- 2023-06-16 0001193125-23-168966 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2023-05-09 0001628280-23-016629 — 2.02, 9.01
- 2023-04-06 0001628280-23-010935 — 2.02, 8.01, 9.01
- 2023-02-24 0001193125-23-048742 — 5.02, 9.01
- 2023-02-09 0001628280-23-002866 — 2.02, 9.01
- 2022-11-21 0001628280-22-030473 — 5.02, 5.07, 9.01
- 2022-11-08 0001628280-22-028758 — 2.02, 9.01
- 2022-08-16 0001628280-22-022980 — 2.02, 9.01
- 2022-08-03 0001193125-22-210674 — 2.01, 8.01, 9.01
- 2022-07-29 0001193125-22-206587 — 8.01, 9.01
- 2022-05-04 0001628280-22-012145 — 2.02, 9.01
- 2022-03-08 0001193125-22-069350 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2022-02-03 0001628280-22-001736 — 2.02, 9.01
- 2022-01-21 0001193125-22-014413 — 8.01, 9.01
- 2021-11-23 0001628280-21-024070 — 5.02, 5.07
- 2021-11-05 0001193125-21-321796 — 1.01, 9.01
- 2021-11-04 0001628280-21-021618 — 2.02, 9.01
- 2021-11-04 0001193125-21-319601 — 8.01, 9.01
- 2021-08-18 0001628280-21-017219 — 2.02, 9.01
- 2021-06-08 0001633978-21-000030 — 5.02, 9.01
- 2021-05-12 0001633978-21-000008 — 2.02, 9.01
- 2021-03-10 0001193125-21-075438 — 1.01, 8.01, 9.01
- 2021-02-02 0001633978-21-000002 — 2.02, 9.01
- 2021-01-19 0001104659-21-005024 — 1.01, 2.02, 8.01, 9.01
- 2020-11-24 0001193125-20-302557 — 5.02, 5.07
- 2020-11-02 0001633978-20-000017 — 2.02, 9.01
- 2020-09-18 0001633978-20-000012 — 5.02, 9.01
- 2020-08-11 0001633978-20-000010 — 2.02, 9.01
- 2020-05-05 0001628280-20-006358 — 2.02, 9.01
- 2020-02-04 0001633978-20-000002 — 2.02, 9.01
- 2019-12-12 0001193125-19-312875 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2019-12-04 0001633978-19-000075 — 8.01
- 2019-11-20 0001633978-19-000074 — 5.07
- 2019-10-31 0001633978-19-000070 — 2.02, 9.01
- 2019-08-08 0001633978-19-000068 — 2.02, 9.01
- 2019-05-08 0001633978-19-000031 — 1.01
- 2019-05-07 0001633978-19-000029 — 2.02, 9.01
- 2019-02-15 0001633978-19-000005 — 9.01 — amendment of 0001193125-18-346211
- 2019-02-08 0001193125-19-031591 — 5.02, 9.01
- 2019-02-05 0001633978-19-000001 — 2.02, 9.01
- 2018-12-10 0001193125-18-346211 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-12-06 0001633978-18-000150 — 8.01
- 2018-11-14 0001633978-18-000139 — 5.07
- 2018-11-13 0001633978-18-000136 — 3.02
- 2018-11-13 0001633978-18-000132 — 7.01, 9.01
- 2018-11-01 0001628280-18-013238 — 2.02, 9.01
- 2018-08-08 0001633978-18-000056 — 2.02, 9.01
- 2018-06-08 0001193125-18-188241 — 5.02, 9.01
- 2018-05-02 0001633978-18-000029 — 2.02, 9.01
- 2018-03-12 0001193125-18-078154 — 1.01, 2.01, 8.01, 9.01
- 2018-02-06 0001628280-18-001082 — 2.02, 9.01
- 2017-11-08 0001633978-17-000133 — 5.02, 9.01
- 2017-11-07 0001633978-17-000131 — 5.07
- 2017-11-01 0001633978-17-000117 — 2.02, 9.01
- 2017-08-09 0001633978-17-000058 — 2.02, 9.01
- 2017-05-04 0001633978-17-000035 — 2.02, 9.01
- 2017-03-08 0001193125-17-074740 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2017-03-02 0001193125-17-066769 — 8.01, 9.01
- 2017-02-07 0001633978-17-000005 — 2.02, 9.01
- 2017-01-03 0001628280-17-000018 — 4.01, 9.01
- 2016-11-09 0001628280-16-021143 — 5.02, 5.07, 9.01
- 2016-10-27 0001628280-16-020382 — 2.02, 9.01
- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2026-08-17

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001628280-26-055726:8k_2_02:1]
EX-99.1
2
lite_ex991xq4fy26.htm
EX-99.1

[0001628280-26-055726:8k_2_02:2]
Document

[0001628280-26-055726:8k_2_02:3]
NEWS RELEASE

[0001628280-26-055726:8k_2_02:4]
LUMENTUM ANNOUNCES FOURTH QUARTER AND FULL FISCAL YEAR 2026 RESULTS

[0001628280-26-055726:8k_2_02:5]
Fiscal Fourth Quarter Highlights:

[0001628280-26-055726:8k_2_02:6]
•Net revenue of $1.01 billion

[0001628280-26-055726:8k_2_02:7]
•GAAP gross margin of 47.4%; Non-GAAP gross margin of 50.4%

[0001628280-26-055726:8k_2_02:8]
•GAAP operating margin of 27.8%; Non-GAAP operating margin of 36.6%

[0001628280-26-055726:8k_2_02:9]
•Forecasting first quarter of fiscal year 2027 revenue of $1.225 billion to $1.275 billion; Non-GAAP operating margin of 39.5% to 40.5%; and Non-GAAP diluted net income per share of $4.05 to $4.35

[0001628280-26-055726:8k_2_02:10]
San Jose, Calif., August 11, 2026 – Lumentum Holdings Inc. (“Lumentum” or the “Company”) today reported results for its fiscal fourth quarter and full fiscal year ended June 27, 2026.

[0001628280-26-055726:8k_2_02:11]
“Lumentum is positioned at the heart of a secular industry shift. As AI compute workloads increase in both speed and bandwidth, data center architects are turning to optical links as a primary means of connectivity. While our Q4 results demonstrate broad-based traction, key growth drivers such as OCS solutions and our cloud module business, where we are advancing 1.6T adoption, are beginning to layer in. Increasing demand for ultra-high-power CPO lasers, an initial order for ELS modules, as well as our breadth of NPO engagements are the first signs that optics are starting to penetrate in-rack connectivity, significantly upping our optical TAM,” said President and CEO Michael Hurlston.

[0001628280-26-055726:8k_2_02:12]
“Looking ahead, our trajectory continues to accelerate as AI demand drives our Q1 revenue guidance midpoint to $1.25 billion, reaching our target model more than a quarter ahead of schedule.”

[0001628280-26-055726:8k_2_02:13]
Fiscal Fourth Quarter:

[0001628280-26-055726:8k_2_02:14]
Net revenue for the fourth quarter of fiscal year 2026 was $1.01 billion, with GAAP net loss of $7.2 billion, or $84.65 per diluted share. The GAAP net loss was driven by the equitization of certain amounts of our convertible notes in the fourth quarter of fiscal year 2026, which contributed to a one-time, non-cash loss on debt extinguishment of $7.8 billion. Net revenue for the third quarter of fiscal year 2026 was $808.4 million, with GAAP net income of $144.2 million, or $1.50 per diluted share. Net revenue for the fourth quarter of fiscal year 2025 was $480.7 million, with GAAP net income of $213.3 million, or $2.96 per diluted share.

[0001628280-26-055726:8k_2_02:15]
Non-GAAP net income for the fourth quarter of fiscal year 2026 was $326.3 million, or $3.23 per diluted share. Non-GAAP net income for the third quarter of fiscal year 2026 was $225.7 million, or $2.37 per diluted share. Non-GAAP net income for the fourth quarter of fiscal year 2025 was $63.3 million, or $0.88 per diluted share.

[0001628280-26-055726:8k_2_02:16]
The Company held $2.7 billion in total cash, cash equivalents, and short-term investments at the end of the fourth quarter of fiscal year 2026, a decrease of $433.9 million from the end of the third quarter of fiscal year 2026.

[0001628280-26-055726:8k_2_02:17]
Full Fiscal Year 2026:

[0001628280-26-055726:8k_2_02:18]
Net revenue for fiscal year 2026 was $3.01 billion, with GAAP net loss of $6.9 billion, or $92.96 per diluted share. The GAAP net loss was driven by the equitization of certain amounts of our convertible notes in the fourth quarter of fiscal year 2026, which contributed to a one-time, non-cash loss on debt extinguishment of $7.8 billion. Net revenue for fiscal year 2025 was $1.6 billion, with GAAP net income of $25.9 million, or $0.37 per diluted share.

[0001628280-26-055726:8k_2_02:19]
Non-GAAP net income for fiscal year 2026 was $782.3 million, or $8.67 per diluted share. Non-GAAP net income for fiscal year 2025 was $146.4 million, or $2.06 per diluted share.

[0001628280-26-055726:8k_2_02:20]
The Company held $2.7 billion in total cash, cash equivalents, and short-term investments at the end of the fourth quarter of fiscal year 2026, an increase of $1.9 billion from the end of fiscal year 2025.

[0001628280-26-055726:8k_2_02:21]
Financial Overview – Fiscal Fourth Quarter Ended June 27, 2026

[0001628280-26-055726:8k_2_02:22]
|  | GAAP Results ($ in millions) |
|  | Q4 |  | Q3 |  | Q4 |  | Change |
|  | FY 2026 |  | FY 2026 |  | FY 2025 |  | Q/Q |  | Y/Y |
| Net revenue | $ | 1,006.3 |  |  | $ | 808.4 |  |  | $ | 480.7 |  |  | 24.5% |  | 109.3% |
| GAAP gross margin | 47.4 | % |  | 44.2 | % |  | 33.3 | % |  | 320bps |  | 1,410bps |
| GAAP operating margin (loss) | 27.8 | % |  | 21.6 | % |  | (1.7) | % |  | 620bps |  | 2,950bps |
|  | Non-GAAP Results ($ in millions) |
|  | Q4 |  | Q3 |  | Q4 |  | Change |
|  | FY 2026 |  | FY 2026 |  | FY 2025 |  | Q/Q |  | Y/Y |
| Net revenue | $ | 1,006.3 |  |  | $ | 808.4 |  |  | $ | 480.7 |  |  | 24.5% |  | 109.3% |
| Non-GAAP gross margin | 50.4 | % |  | 47.9 | % |  | 37.8 | % |  | 250bps |  | 1,260bps |
| Non-GAAP operating margin | 36.6 | % |  | 32.2 | % |  | 15.0 | % |  | 440bps |  | 2,160bps |

[0001628280-26-055726:8k_2_02:23]
|  | Net Revenue by Product Type ($ in millions) |
|  | Q4 |  | % of |  | Q3 |  | Q4 |  | Change |
|  | FY 2026 |  | Net Revenue |  | FY 2026 |  | FY 2025 |  | Q/Q |  | Y/Y |
| Components | $ | 649.4 |  |  | 64.5 | % |  | $ | 533.3 |  |  | $ | 320.4 |  |  | 21.8 | % |  | 102.7 | % |
| Systems | 356.9 |  |  | 35.5 | % |  | 275.1 |  |  | 160.3 |  |  | 29.7 | % |  | 122.6 | % |
| Total | $ | 1,006.3 |  |  | 100.0 | % |  | $ | 808.4 |  |  | $ | 480.7 |  |  | 24.5 | % |  | 109.3 | % |

[0001628280-26-055726:8k_2_02:24]
Financial Overview – Fiscal Year Ended June 27, 2026

[0001628280-26-055726:8k_2_02:25]
|  | GAAP Results ($ in millions) |
|  | FY 2026 |  | FY 2025 |  | Change Y/Y |  |
| Net revenue | $ | 3,014.0 |  |  | $ | 1,645.0 |  |  | 83.2% |  |
| GAAP Gross margin | 41.7 | % |  | 28.0 | % |  | 1,370bps |  |
| GAAP Operating margin (loss) | 17.4 | % |  | (10.9) | % |  | 2,830bps |  |

[0001628280-26-055726:8k_2_02:26]
|  | Non-GAAP Results ($ in millions) |
|  | FY 2026 |  | FY 2025 |  | Change Y/Y |  |
| Net revenue | $ | 3,014.0 |  |  | $ | 1,645.0 |  |  | 83.2% |  |
| Non-GAAP Gross margin | 46.0 | % |  | 34.7 | % |  | 1,130bps |  |
| Non-GAAP Operating margin | 29.8 | % |  | 9.7 | % |  | 2,010bps |  |

[0001628280-26-055726:8k_2_02:27]
|  | Net Revenue by Product Type ($ in millions) |
|  | FY 2026 |  | FY 2025 |  | Change Y/Y |  |
| Components | $ | 2,005.6 |  |  | $ | 1,116.3 |  |  | 79.7% |  |
| Systems | 1,008.4 |  |  | 528.7 |  |  | 90.7% |  |
| Total | $ | 3,014.0 |  |  | $ | 1,645.0 |  |  | 83.2% |  |

[0001628280-26-055726:8k_2_02:28]
The tables above provide comparisons of quarterly and annual results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP financial measures is contained in this release under the section titled “Use of Non-GAAP Financial Measures”.

[0001628280-26-055726:8k_2_02:29]
Business Outlook

[0001628280-26-055726:8k_2_02:30]
Lumentum expects the following for the first quarter of fiscal year 2027:

[0001628280-26-055726:8k_2_02:31]
•Net revenue in the range of $1.225 billion to $1.275 billion

[0001628280-26-055726:8k_2_02:32]
•Non-GAAP operating margin of 39.5% - 40.5%

[0001628280-26-055726:8k_2_02:33]
•Non-GAAP diluted net income per share of $4.05 to $4.35

[0001628280-26-055726:8k_2_02:34]
We have not provided reconciliations from GAAP to non-GAAP financial measures or the equivalent GAAP measure for non-GAAP financial measures in our outlook, as they cannot be provided without unreasonable effort. A large portion of non-GAAP adjustments, such as stock-based compensation and related payroll expenses, acquisition related costs, net, integration related costs, restructuring and related charges, non-GAAP income tax reconciling adjustments, and other non-GAAP adjustments are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future.

[0001628280-26-055726:8k_2_02:35]
Conference Call

[0001628280-26-055726:8k_2_02:36]
Lumentum will host a conference call today, August 11, 2026, at 2:00 pm PT / 5:00 pm ET to discuss its fiscal fourth quarter and full year results. A live webcast of the call will be available in the Investors section of the Lumentum website at http://investor.lumentum.com. The earnings press release will be posted on http://investor.lumentum.com under the “News Releases” section. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the “Events” section concurrently with this earnings press release. Lumentum has used, and intends to continue to use, its Investor Relations website as means of disclosing material nonpublic information and for complying with its disclosure obligations under Regulation FD. This press release is also being furnished as an exhibit to a Current Report on Form 8-K filed with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001628280-26-055726:8k_2_02:37]
About Lumentum

[0001628280-26-055726:8k_2_02:38]
Lumentum (NASDAQ: LITE) is a global leader in optical and photonic technologies that power the networks and infrastructure behind AI, cloud computing, and next-generation communications. Built on decades of photonics innovation, Lumentum delivers high-performance lasers, modules, and optical subsystems that enable scalable, energy-efficient data center connectivity, advanced telecom networks, industrial manufacturing, and sensing applications. Headquartered in San Jose, California, the company operates R&D, manufacturing, and sales facilities worldwide. Learn more at www.lumentum.com.

[0001628280-26-055726:8k_2_02:39]
Forward-Looking Statements

[0001628280-26-055726:8k_2_02:40]
Contact Information

[0001628280-26-055726:8k_2_02:41]
Investors:     Kathy Ta, +1.408.750.3853; investor.relations@lumentum.com

[0001628280-26-055726:8k_2_02:42]
Media:         Victoria McDonald, +1.408.404.0636; media@lumentum.com

[0001628280-26-055726:8k_2_02:43]
Category:    Financial

[0001628280-26-055726:8k_2_02:44]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001628280-26-055726:8k_2_02:45]
LUMENTUM HOLDINGS INC.

[0001628280-26-055726:8k_2_02:46]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001628280-26-055726:8k_2_02:47]
(in millions, except per share data)

[0001628280-26-055726:8k_2_02:48]
(unaudited)

[0001628280-26-055726:8k_2_02:49]
|  | Three Months Ended |  | Twelve Months Ended |
|  | June 27, 2026 |  | June 28, 2025 |  | June 27, 2026 |  | June 28, 2025 |
| Net revenue | $ | 1,006.3 |  |  | $ | 480.7 |  |  | $ | 3,014.0 |  |  | $ | 1,645.0 |  |
| Cost of sales | 509.8 |  |  | 301.5 |  |  | 1,680.5 |  |  | 1,102.9 |  |
| Amortization of acquired developed intangibles | 19.2 |  |  | 19.3 |  |  | 77.6 |  |  | 82.2 |  |
| Gross profit | 477.3 |  |  | 159.9 |  |  | 1,255.9 |  |  | 459.9 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 104.4 |  |  | 79.5 |  |  | 356.5 |  |  | 303.9 |  |
| Selling, general and administrative | 91.2 |  |  | 83.6 |  |  | 363.2 |  |  | 348.2 |  |
| Restructuring and related charges | 2.4 |  |  | 5.2 |  |  | 11.4 |  |  | 22.8 |  |
| Gain on sale of facility | — |  |  | — |  |  | — |  |  | (34.9) |  |
| Total operating expenses | 198.0 |  |  | 168.3 |  |  | 731.1 |  |  | 640.0 |  |
| Income (loss) from operations | 279.3 |  |  | (8.4) |  |  | 524.8 |  |  | (180.1) |  |
| Loss on debt extinguishment (1) | (7,756.6) |  |  | — |  |  | (7,756.6) |  |  | — |  |
| Escrow settlement | — |  |  | — |  |  | 27.5 |  |  | — |  |
| Interest expense | (3.6) |  |  | (5.4) |  |  | (21.8) |  |  | (22.2) |  |
| Other income, net | 22.6 |  |  | 2.4 |  |  | 53.3 |  |  | 30.2 |  |
| Total other (expense) income, net | (7,737.6) |  |  | (3.0) |  |  | (7,697.6) |  |  | 8.0 |  |
| Loss before income taxes | (7,458.3) |  |  | (11.4) |  |  | (7,172.8) |  |  | (172.1) |  |
| Income tax (benefit) provision | (296.6) |  |  | (224.7) |  |  | (237.7) |  |  | (198.0) |  |
| Net (loss) income (1) | $ | (7,161.7) |  |  | $ | 213.3 |  |  | $ | (6,935.1) |  |  | $ | 25.9 |  |
| Net (loss) income per share: |  |  |  |  |  |  |  |
| Basic | $ | (84.65) |  |  | $ | 3.06 |  |  | $ | (92.96) |  |  | $ | 0.38 |  |
| Diluted | $ | (84.65) |  |  | $ | 2.96 |  |  | $ | (92.96) |  |  | $ | 0.37 |  |
| Shares used to compute net (loss) income per share - common stock and preferred stock assuming conversion: |  |  |  |  |  |  |  |
| Basic | 84.6 |  |  | 69.6 |  |  | 74.6 |  |  | 69.0 |  |
| Diluted | 84.6 |  |  | 72.0 |  |  | 74.6 |  |  | 69.6 |  |

[0001628280-26-055726:8k_2_02:50]
(1) The GAAP net loss for the three and twelve months ended June 27, 2026 was driven by the equitization of certain amounts of our convertible notes in the fourth quarter of fiscal year 2026, which contributed to a one-time, non-cash loss on debt extinguishment of $7.8 billion.

[0001628280-26-055726:8k_2_02:51]
LUMENTUM HOLDINGS INC.

[0001628280-26-055726:8k_2_02:52]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-26-055726:8k_2_02:53]
(in millions, except per share data)

[0001628280-26-055726:8k_2_02:54]
(unaudited)

[0001628280-26-055726:8k_2_02:55]
|  | June 27, 2026 |  | June 28, 2025 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 2,043.5 |  |  | $ | 520.7 |  |
| Short-term investments | 694.9 |  |  | 356.4 |  |
| Accounts receivable, net | 520.3 |  |  | 250.0 |  |
| Inventories | 691.6 |  |  | 470.1 |  |
| Prepayments and other current assets | 211.6 |  |  | 120.1 |  |
| Total current assets | 4,161.9 |  |  | 1,717.3 |  |
| Property, plant and equipment, net | 1,159.1 |  |  | 726.4 |  |
| Operating lease right-of-use assets, net | 29.2 |  |  | 27.9 |  |
| Goodwill | 1,069.3 |  |  | 1,060.9 |  |
| Other intangible assets, net | 326.9 |  |  | 465.1 |  |
| Deferred tax asset | 530.9 |  |  | 210.3 |  |
| Other non-current assets | 30.2 |  |  | 10.8 |  |
| Total assets | $ | 7,307.5 |  |  | $ | 4,218.7 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 567.4 |  |  | $ | 225.2 |  |
| Accrued payroll and related expenses | 146.3 |  |  | 57.9 |  |
| Accrued expenses | 64.9 |  |  | 34.6 |  |
| Current portion of long-term debt | 1,596.9 |  |  | 10.6 |  |
| Operating lease liabilities, current | 13.5 |  |  | 11.4 |  |
| Other current liabilities | 91.5 |  |  | 53.1 |  |
| Total current liabilities | 2,480.5 |  |  | 392.8 |  |
| Long-term debt | 40.5 |  |  | 2,562.6 |  |
| Operating lease liabilities, non-current | 20.3 |  |  | 23.6 |  |
| Deferred tax liability | 7.1 |  |  | 7.2 |  |
| Other non-current liabilities | 115.2 |  |  | 97.8 |  |
| Total liabilities | 2,663.6 |  |  | 3,084.0 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock, $0.001 par value, 10 authorized shares, 2.9 shares and zero shares issued and outstanding as of June 27, 2026 and June 28, 2025, respectively | — |  |  | — |  |
| Common stock, $0.001 par value, 990 authorized shares; 88.6 and 69.8 shares issued and outstanding as of June 27, 2026 and June 28, 2025, respectively | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital | 12,430.1 |  |  | 1,986.8 |  |
| Accumulated deficit | (7,796.3) |  |  | (861.2) |  |
| Accumulated other comprehensive income | 10.0 |  |  | 9.0 |  |
| Total stockholders’ equity | 4,643.9 |  |  | 1,134.7 |  |
| Total liabilities and stockholders’ equity | $ | 7,307.5 |  |  | $ | 4,218.7 |  |

[0001628280-26-055726:8k_2_02:56]
Use of Non-GAAP Financial Measures

[0001628280-26-055726:8k_2_02:57]
In this press release, Lumentum provides investors with certain non-GAAP financial measures: gross profit, gross margin, research and development expense, selling, general and administrative expense, operating margin, income (loss) from operations, total other income (expense), net, income before income taxes, provision (benefit) for income taxes, net income (loss), shares used in per share calculation, and net income (loss) per share on a non-GAAP basis, as well as the non-GAAP measures of EBITDA and Adjusted EBITDA. Lumentum believes this non-GAAP financial information provides additional insight into the Company’s on-going business operations and results, and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons. In addition, the Company believes that providing certain of these measures allows investors to better understand the Company’s operating performance and, importantly, to evaluate the methodology and information used by management to monitor, manage, evaluate and measure the Company’s business and results of operations. However, investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future. Moreover, the non-GAAP financial measures we present may be different from non-GAAP financial measures used by other companies or may not be comparable to similarly titled measurements reported by other companies, limiting their usefulness for comparison purposes. We do not consider non-GAAP financial measures to be a substitute for, or superior to, the information provided by GAAP financial measures, and the non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP.

[0001628280-26-055726:8k_2_02:58]
Our non-GAAP measures used in this press release exclude (i) stock-based compensation and related payroll taxes, (ii) acquisition-related warranty provision, (iii) escrow settlement, (iv) acquisition related costs, net (v) integration related costs, (vi) amortization of acquired intangibles, (vii) restructuring and related charges, (viii) intangible assets write-off, (ix) gain on sale of facility, (x) foreign exchange losses (gains), net, (xi) loss on debt extinguishment, (xii) inducement expense, (xiii) non-cash interest expense, (xiv) other charges or income related to non-recurring activities, and (xv) non-GAAP income tax reconciling adjustments.

[0001628280-26-055726:8k_2_02:59]
We utilize a long-term projected non-GAAP tax rate to compute our non-GAAP income tax provision. The long-term projected non-GAAP tax rate is based on a multi-year projection of our estimated annual GAAP income tax forecast, adjusted to account for the tax effect of non-GAAP pretax adjustments as well as the effects of significant non-recurring and period specific tax items. Our non-GAAP tax provision for fiscal year 2026 is 16.5%. The difference between our GAAP income tax provision and our non-GAAP income tax provision is presented as non-GAAP income tax reconciling adjustments.

[0001628280-26-055726:8k_2_02:60]
A quantitative reconciliation between GAAP and non-GAAP financial data is included in the supplemental financial table attached to this press release.

[0001628280-26-055726:8k_2_02:61]
LUMENTUM HOLDINGS INC.

[0001628280-26-055726:8k_2_02:62]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001628280-26-055726:8k_2_02:63]
(in millions, except per share data)

[0001628280-26-055726:8k_2_02:64]
(unaudited)

[0001628280-26-055726:8k_2_02:65]
|  | Three Months Ended |  | Twelve Months Ended |
|  | June 27, 2026 |  | March 28, 2026 |  | June 28, 2025 |  | June 27, 2026 |  | June 28, 2025 |
| Gross profit on GAAP basis | $ | 477.3 |  |  | $ | 357.0 |  |  | $ | 159.9 |  |  | $ | 1,255.9 |  |  | $ | 459.9 |  |
| Stock-based compensation and related payroll taxes (1) | 10.5 |  |  | 10.5 |  |  | 8.8 |  |  | 44.0 |  |  | 36.9 |  |
| Acquisition-related warranty provision (2) | — |  |  | — |  |  | — |  |  | 9.8 |  |  | — |  |
| Integration related costs | — |  |  | 0.2 |  |  | 0.6 |  |  | 0.2 |  |  | 2.9 |  |
| Amortization of acquired intangibles | 19.2 |  |  | 19.3 |  |  | 19.3 |  |  | 77.6 |  |  | 82.2 |  |
| Other charges, net (7) | (0.1) |  |  | (0.1) |  |  | (7.0) |  |  | (0.8) |  |  | (10.4) |  |
| Gross profit on non-GAAP basis | $ | 506.9 |  |  | $ | 386.9 |  |  | $ | 181.6 |  |  | $ | 1,386.7 |  |  | $ | 571.5 |  |
| Gross margin on non-GAAP basis | 50.4 | % |  | 47.9 | % |  | 37.8 | % |  | 46.0 | % |  | 34.7 | % |
| Research and development on GAAP basis | $ | 104.4 |  |  | $ | 90.6 |  |  | $ | 79.5 |  |  | $ | 356.5 |  |  | $ | 303.9 |  |
| Stock-based compensation and related payroll taxes (1) | (13.5) |  |  | (11.5) |  |  | (11.4) |  |  | (46.8) |  |  | (43.3) |  |
| Integration related costs | — |  |  | (0.2) |  |  | — |  |  | (0.2) |  |  | (0.3) |  |
| Amortization of acquired intangibles | (0.4) |  |  | (0.5) |  |  | (0.4) |  |  | (1.7) |  |  | (1.6) |  |
| Intangible assets write-off | (2.5) |  |  | — |  |  | (0.1) |  |  | (2.5) |  |  | (2.7) |  |
| Other charges, net (7) | (0.5) |  |  | — |  |  | — |  |  | (0.5) |  |  | — |  |
| Research and development on non-GAAP basis | $ | 87.5 |  |  | $ | 78.4 |  |  | $ | 67.6 |  |  | $ | 304.8 |  |  | $ | 256.0 |  |
| Selling, general and administrative on GAAP basis | $ | 91.2 |  |  | $ | 90.8 |  |  | $ | 83.6 |  |  | $ | 363.2 |  |  | $ | 348.2 |  |
| Stock-based compensation and related payroll taxes (1) | (26.1) |  |  | (24.8) |  |  | (19.8) |  |  | (100.5) |  |  | (97.0) |  |
| Acquisition related costs, net (3) | — |  |  | (0.4) |  |  | (0.7) |  |  | (2.1) |  |  | (1.2) |  |
| Integration related costs | (0.5) |  |  | (1.0) |  |  | (0.7) |  |  | (2.0) |  |  | (6.0) |  |
| Amortization of acquired intangibles | (13.9) |  |  | (14.0) |  |  | (14.9) |  |  | (56.4) |  |  | (65.9) |  |
| Other charges, net (7) | (0.1) |  |  | (2.8) |  |  | (5.8) |  |  | (17.3) |  |  | (22.7) |  |
| Selling, general and administrative on non-GAAP basis | $ | 50.6 |  |  | $ | 47.8 |  |  | $ | 41.7 |  |  | $ | 184.9 |  |  | $ | 155.4 |  |
| Income (loss) from operations on GAAP basis | $ | 279.3 |  |  | $ | 174.5 |  |  | $ | (8.4) |  |  | $ | 524.8 |  |  | $ | (180.1) |  |
| Stock-based compensation and related payroll taxes (1) | 50.1 |  |  | 46.8 |  |  | 40.0 |  |  | 191.3 |  |  | 177.2 |  |
| Acquisition-related warranty provision (2) | — |  |  | — |  |  | — |  |  | 9.8 |  |  | — |  |
| Acquisition related costs, net (3) | — |  |  | 0.4 |  |  | 0.7 |  |  | 2.1 |  |  | 1.2 |  |
| Integration related costs | 0.5 |  |  | 1.4 |  |  | 1.3 |  |  | 2.4 |  |  | 9.2 |  |
| Amortization of acquired intangibles | 33.5 |  |  | 33.8 |  |  | 34.6 |  |  | 135.7 |  |  | 149.7 |  |
| Restructuring and related charges (4) | 2.4 |  |  | 1.1 |  |  | 5.2 |  |  | 11.4 |  |  | 22.8 |  |
| Intangible assets write-off | 2.5 |  |  | — |  |  | 0.1 |  |  | 2.5 |  |  | 2.7 |  |
| Gain on sale of facility | — |  |  | — |  |  | — |  |  | — |  |  | (34.9) |  |
| Other charges, net (7) | 0.5 |  |  | 2.7 |  |  | (1.2) |  |  | 17.0 |  |  | 12.3 |  |
| Income from operations on non-GAAP basis | $ | 368.8 |  |  | $ | 260.7 |  |  | $ | 72.3 |  |  | $ | 897.0 |  |  | $ | 160.1 |  |
| Operating margin on non-GAAP basis | 36.6 | % |  | 32.2 | % |  | 15.0 | % |  | 29.8 | % |  | 9.7 | % |
| Total other income (expense), net on GAAP basis | $ | (7,737.6) |  |  | $ | 9.3 |  |  | $ | (3.0) |  |  | $ | (7,697.6) |  |  | $ | 8.0 |  |
| Escrow settlement (2) | — |  |  | — |  |  | — |  |  | (27.5) |  |  | — |  |
| Acquisition related income (3) | — |  |  | — |  |  | — |  |  | (1.8) |  |  | — |  |

[0001628280-26-055726:8k_2_02:66]
| Foreign exchange losses (gains), net | 2.2 |  |  | (0.8) |  |  | 5.8 |  |  | 0.5 |  |  | 4.2 |  |
| Loss on debt extinguishment (5) | 7,756.6 |  |  | — |  |  | — |  |  | 7,756.6 |  |  | — |  |
| Inducement expense (6) | — |  |  | — |  |  | — |  |  | 5.9 |  |  | — |  |
| Non-cash interest expense | 0.8 |  |  | 1.1 |  |  | 0.7 |  |  | 3.8 |  |  | 3.0 |  |
| Total other income, net on non-GAAP basis | $ | 22.0 |  |  | $ | 9.6 |  |  | $ | 3.5 |  |  | $ | 39.9 |  |  | $ | 15.2 |  |
| Income (loss) before income taxes on GAAP basis | $ | (7,458.3) |  |  | $ | 183.8 |  |  | $ | (11.4) |  |  | $ | (7,172.8) |  |  | $ | (172.1) |  |
| Stock-based compensation and related payroll taxes (1) | 50.1 |  |  | 46.8 |  |  | 40.0 |  |  | 191.3 |  |  | 177.2 |  |
| Acquisition-related warranty provision (2) | — |  |  | — |  |  | — |  |  | 9.8 |  |  | — |  |
| Escrow settlement (2) | — |  |  | — |  |  | — |  |  | (27.5) |  |  | — |  |
| Acquisition related costs, net (3) | — |  |  | 0.4 |  |  | 0.7 |  |  | 0.3 |  |  | 1.2 |  |
| Integration related costs | 0.5 |  |  | 1.4 |  |  | 1.3 |  |  | 2.4 |  |  | 9.2 |  |
| Amortization of acquired intangibles | 33.5 |  |  | 33.8 |  |  | 34.6 |  |  | 135.7 |  |  | 149.7 |  |
| Restructuring and related charges (4) | 2.4 |  |  | 1.1 |  |  | 5.2 |  |  | 11.4 |  |  | 22.8 |  |
| Gain on sale of facility | — |  |  | — |  |  | — |  |  | — |  |  | (34.9) |  |
| Intangible assets write-off | 2.5 |  |  | — |  |  | 0.1 |  |  | 2.5 |  |  | 2.7 |  |
| Foreign exchange losses (gains), net | 2.2 |  |  | (0.8) |  |  | 5.8 |  |  | 0.5 |  |  | 4.2 |  |
| Loss on debt extinguishment (5) | 7,756.6 |  |  | — |  |  | — |  |  | 7,756.6 |  |  | — |  |
| Inducement expense (6) | — |  |  | — |  |  | — |  |  | 5.9 |  |  | — |  |
| Non-cash interest expense | 0.8 |  |  | 1.1 |  |  | 0.7 |  |  | 3.8 |  |  | 3.0 |  |
| Other charges, net (7) | 0.5 |  |  | 2.7 |  |  | (1.2) |  |  | 17.0 |  |  | 12.3 |  |
| Income before income taxes on non-GAAP basis | $ | 390.8 |  |  | $ | 270.3 |  |  | $ | 75.8 |  |  | $ | 936.9 |  |  | $ | 175.3 |  |
| Income tax provision (benefit) on GAAP basis | $ | (296.6) |  |  | $ | 39.6 |  |  | $ | (224.7) |  |  | $ | (237.7) |  |  | $ | (198.0) |  |
| Non-GAAP income tax reconciling adjustments | 361.1 |  |  | 5.0 |  |  | 237.2 |  |  | 392.3 |  |  | 226.9 |  |
| Income tax provision on non-GAAP basis | $ | 64.5 |  |  | $ | 44.6 |  |  | $ | 12.5 |  |  | $ | 154.6 |  |  | $ | 28.9 |  |
| Net income (loss) on GAAP basis | $ | (7,161.7) |  |  | $ | 144.2 |  |  | $ | 213.3 |  |  | $ | (6,935.1) |  |  | $ | 25.9 |  |
| Stock-based compensation and related payroll taxes (1) | 50.1 |  |  | 46.8 |  |  | 40.0 |  |  | 191.3 |  |  | 177.2 |  |
| Acquisition-related warranty provision (2) | — |  |  | — |  |  | — |  |  | 9.8 |  |  | — |  |
| Escrow settlement (2) | — |  |  | — |  |  | — |  |  | (27.5) |  |  | — |  |
| Acquisition related costs, net (3) | — |  |  | 0.4 |  |  | 0.7 |  |  | 0.3 |  |  | 1.2 |  |
| Integration related costs | 0.5 |  |  | 1.4 |  |  | 1.3 |  |  | 2.4 |  |  | 9.2 |  |
| Amortization of acquired intangibles | 33.5 |  |  | 33.8 |  |  | 34.6 |  |  | 135.7 |  |  | 149.7 |  |
| Restructuring and related charges (4) | 2.4 |  |  | 1.1 |  |  | 5.2 |  |  | 11.4 |  |  | 22.8 |  |
| Intangible assets write-off | 2.5 |  |  | — |  |  | 0.1 |  |  | 2.5 |  |  | 2.7 |  |
| Gain on sale of facility | — |  |  | — |  |  | — |  |  | — |  |  | (34.9) |  |
| Foreign exchange losses (gains), net | 2.2 |  |  | (0.8) |  |  | 5.8 |  |  | 0.5 |  |  | 4.2 |  |
| Loss on debt extinguishment (5) | 7,756.6 |  |  | — |  |  | — |  |  | 7,756.6 |  |  | — |  |
| Inducement expense (6) | — |  |  | — |  |  | — |  |  | 5.9 |  |  | — |  |
| Non-cash interest expense | 0.8 |  |  | 1.1 |  |  | 0.7 |  |  | 3.8 |  |  | 3.0 |  |
| Other charges (income), net (7) | 0.5 |  |  | 2.7 |  |  | (1.2) |  |  | 17.0 |  |  | 12.3 |  |
| Non-GAAP income tax reconciling adjustments | (361.1) |  |  | (5.0) |  |  | (237.2) |  |  | (392.3) |  |  | (226.9) |  |
| Net income on non-GAAP basis | $ | 326.3 |  |  | $ | 225.7 |  |  | $ | 63.3 |  |  | $ | 782.3 |  |  | $ | 146.4 |  |
| Net income per share on non-GAAP basis | $ | 3.23 |  |  | $ | 2.37 |  |  | $ | 0.88 |  |  | $ | 8.67 |  |  | $ | 2.06 |  |
| Shares used in per share calculation - diluted on GAAP basis | 84.6 |  |  | 96.2 |  |  | 72.0 |  |  | 74.6 |  |  | 69.6 |  |

[0001628280-26-055726:8k_2_02:67]
| Non-GAAP adjustment (8) | 16.5 |  |  | (1.0) |  |  | — |  |  | 15.6 |  |  | 1.6 |  |
| Shares used in per share calculation - diluted on non-GAAP basis | 101.1 |  |  | 95.2 |  |  | 72.0 |  |  | 90.2 |  |  | 71.2 |  |

[0001628280-26-055726:8k_2_02:68]
(1) Stock-based compensation and related payroll taxes for the three and twelve months ended June 27, 2026 includes $9.3 million and $21.1 million of payroll taxes on stock-based compensation, respectively.

[0001628280-26-055726:8k_2_02:69]
(2) During the twelve months ended June 27, 2026, we completed the settlement process with the sellers on the escrow agreement for the acquisition of Cloud Light. We believe the completion of this settlement represents a non-recurring activity as it relates directly to an acquisition. The settlement of $27.5 million, recorded as escrow settlement, for the twelve months ended June 27, 2026 represents the mutually agreed escrow settlement associated with indemnification obligations and working capital adjustments, including warranty adjustments, under the Cloud Light Merger Agreement. Acquisition-related warranty provision of $9.8 million associated with Cloud Light’s legacy products is recorded in cost of sales. As the measurement period for U.S. GAAP expired, these amounts were all included in our condensed consolidated results of operations on a GAAP basis as no further adjustments to the purchase consideration of Cloud Light can be made. Therefore, for non-GAAP reporting purposes, we have removed the net benefit of $17.7 million for the twelve months ended June 27, 2026.

[0001628280-26-055726:8k_2_02:70]
(3) Acquisition related costs, net for the twelve months ended June 27, 2026 represent legal expenses incurred related to the Cloud Light escrow settlement of $1.7 million and $0.4 million of legal expenses and other professional fees incurred related to an acquisition of a business in fiscal year 2026 in selling, general and administrative expenses offset by $1.8 million of interest income from the Cloud Light escrow fund in other income, net.

[0001628280-26-055726:8k_2_02:71]
(4) During the three and twelve months ended June 27, 2026, we recorded restructuring and related charges of  $2.4 million and $11.4 million, respectively, primarily related to a reduction in force during the period in order to enhance operational efficiency and realign our investments toward the most critical initiatives.

[0001628280-26-055726:8k_2_02:72]
(5) Loss on debt extinguishment of $7.8 billion for the three and twelve months ended June 27, 2026 resulted from the equitization of certain amounts of our 2026 Notes, 2028 Notes, and 2029 Notes (collectively “Extinguished Notes”) as we exchanged our common shares to settle these Extinguished Notes. Included in loss on debt extinguishment are $7.8 billion of conversion value in excess of principal amounts, $3.1 million of related transaction costs and $2.9 million of unamortized debt issuance costs, offset by $2.9 million of forfeited interest and $1.6 million of a negotiated exchange discount.

[0001628280-26-055726:8k_2_02:73]
(6) Inducement expense on the partial repurchase of our 2026 Notes for the twelve months ended June 27, 2026 represents the excess of fair value of the total consideration over the fair value of securities issuable pursuant to the original conversion terms, which was recorded during the first quarter of fiscal year 2026.

[0001628280-26-055726:8k_2_02:74]
(7) Other charges, net for the twelve months ended June 27, 2026 mainly includes legal fees of $9.6 million primarily related to non-ordinary course legal matters and an impairment charge of $7.7 million to write-down assets held for sale to fair value less cost to sell in selling, general and administrative expenses.

[0001628280-26-055726:8k_2_02:75]
(8) The adjustment for the three months ended June 27, 2026 represents the impact of potentially dilutive common shares resulting from stock-based benefit plans, which includes the assumed exercise of outstanding stock options, assumed vesting of equity awards, assumed issuance of stock under the ESPP, of about 3.1 million shares, and assumed conversion of our outstanding convertible notes of about 14.0 million shares reduced by 0.6 million shares from the impact of the capped call options. The adjustment for the twelve months ended June 27, 2026 represents the impact of potentially dilutive common shares resulting from stock-based benefit plans, which includes the assumed exercise of outstanding stock options, assumed vesting of equity awards, assumed issuance of stock under the ESPP, of about 2.8 million shares, and assumed conversion of our outstanding convertible notes of 13.6 million shares reduced by 0.8 million shares from the impact of the capped call options. Our outstanding capped call options are anti-dilutive as they are specifically designed to mitigate the dilutive impact of the 2032 Notes, such that no dilution will occur until the capped call price is exceeded. Therefore, we reduced 0.6 million and 0.8 million shares from the capped call in the calculation of non-GAAP diluted shares in the three and twelve months ended June 27, 2026 to provide investors with useful information in evaluating our performance on a per share basis.

[0001628280-26-055726:8k_2_02:76]
We calculate basic net (loss) income per share pursuant to the two-class method as a result of the issuance of the Series A Convertible Preferred Stock (the “Preferred Stock”) in March 2026. Our Preferred Stock represents a second class of common stock for purposes of computing net (loss) income per share under the two-class method as it is entitled to receive dividends on an as-converted basis in the same manner as holders of common stock and does not have any material preferential rights relative to our common stock.

[0001628280-26-055726:8k_2_02:77]
Diluted net (loss) income per share is calculated assuming the Preferred Stock have been converted into common stock, and the related shares are included in diluted weighted-average shares outstanding.

[0001628280-26-055726:8k_2_02:78]
As the Preferred Stock participates on an if-converted basis, and there are no dividends, the (loss) income allocated to the two classes of stock converge and the results are mathematically equal. Thus, basic and diluted net (loss) income per share is calculated assuming the Preferred Stock have been converted into common stock, and the related shares are included in the weighted average shares outstanding.

[0001628280-26-055726:8k_2_02:79]
LUMENTUM HOLDINGS INC.

[0001628280-26-055726:8k_2_02:80]
RECONCILIATION OF GAAP NET (LOSS) INCOME TO ADJUSTED EBITDA

[0001628280-26-055726:8k_2_02:81]
(in millions, except per share data)

[0001628280-26-055726:8k_2_02:82]
(unaudited)

[0001628280-26-055726:8k_2_02:83]
|  | Three Months Ended |  | Twelve Months Ended |
|  | June 27, 2026 |  | March 28, 2026 |  | June 28, 2025 |  | June 27, 2026 |  | June 28, 2025 |
| GAAP net (loss) income | $ | (7,161.7) |  |  | $ | 144.2 |  |  | $ | 213.3 |  |  | $ | (6,935.1) |  |  | $ | 25.9 |  |
| Loss on debt extinguishment | 7,756.6 |  |  | — |  |  | — |  |  | 7,756.6 |  |  | — |  |
| Escrow settlement | — |  |  | — |  |  | — |  |  | (27.5) |  |  | — |  |
| Interest expense | 3.6 |  |  | 6.2 |  |  | 5.4 |  |  | 21.8 |  |  | 22.2 |  |
| Other income, net | (22.6) |  |  | (15.5) |  |  | (2.4) |  |  | (53.3) |  |  | (30.2) |  |
| Income tax (benefit) provision | (296.6) |  |  | 39.6 |  |  | (224.7) |  |  | (237.7) |  |  | (198.0) |  |
| Depreciation expense | 37.6 |  |  | 32.8 |  |  | 26.4 |  |  | 128.8 |  |  | 104.3 |  |
| Amortization of acquired intangibles | 33.5 |  |  | 33.8 |  |  | 34.6 |  |  | 135.7 |  |  | 149.7 |  |
| EBITDA | 350.4 |  |  | 241.1 |  |  | 52.6 |  |  | 789.3 |  |  | 73.9 |  |
| Restructuring and related charges | 2.4 |  |  | 1.1 |  |  | 5.2 |  |  | 11.4 |  |  | 22.8 |  |
| Stock-based compensation and related payroll taxes | 50.1 |  |  | 46.8 |  |  | 40.0 |  |  | 191.3 |  |  | 177.2 |  |
| Acquisition-related warranty provision | — |  |  | — |  |  | — |  |  | 9.8 |  |  | — |  |
| Acquisition related costs, net | — |  |  | 0.4 |  |  | 0.7 |  |  | 2.1 |  |  | 1.2 |  |
| Integration related costs | 0.5 |  |  | 1.4 |  |  | 1.3 |  |  | 2.4 |  |  | 9.2 |  |
| Intangible assets write-off | 2.5 |  |  | — |  | 0.1 |  |  | 2.5 |  |  | 2.7 |  |
| Gain on sale of facility | — |  |  | — |  |  | — |  |  | — |  |  | (34.9) |  |
| Other charges (income), net | 0.5 |  |  | 2.7 |  |  | (1.2) |  |  | 17.0 |  |  | 12.1 |  |
| Adjusted EBITDA | $ | 406.4 |  |  | $ | 293.5 |  |  | $ | 98.7 |  |  | $ | 1,025.8 |  |  | $ | 264.2 |  |
