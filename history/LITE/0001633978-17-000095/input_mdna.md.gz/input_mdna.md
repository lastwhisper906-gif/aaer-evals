# LITE MD&A — 0001633978-17-000095


## mdna

[0001633978-17-000095:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001633978-17-000095:mdna:2]
You should read the following discussion in conjunction with the audited consolidated financial statements and the corresponding notes included elsewhere in this Annual Report. This Management’s Discussion and Analysis of Financial Condition and Results of Operations contains forward-looking statements. The matters discussed in these forward-looking statements are subject to risk, uncertainties and other factors that could cause actual results to differ materially from those made, projected or implied in the forward-looking statements. Please see “Risk Factors” and “Forward-Looking Statements” for a discussion of the uncertainties, risks and assumptions associated with these statements.

[0001633978-17-000095:mdna:3]
Overview

[0001633978-17-000095:mdna:4]
We are an industry leading provider of optical and photonic products defined by revenue and market share addressing a range of end-market applications including optical communications and commercial lasers. We have two operating segments, Optical Communications, which we refer to as OpComms, and Commercial Lasers, which we refer to as Lasers. The two operating segments were primarily determined based on how the Chief Operating Decision Maker (“CODM”) views and evaluates our operations. Operating results are regularly reviewed by the CODM to make decisions about resources to be allocated to the segments and to assess their performance. Other factors, including market separation and customer specific applications, go-to-market channels, products and manufacturing, are considered in determining the formation of these operating segments.

[0001633978-17-000095:mdna:5]
OpComms

[0001633978-17-000095:mdna:6]
Our OpComms products address the following markets: telecommunications (Telecom), data communications (Datacom) and Consumer and Industrial.

[0001633978-17-000095:mdna:7]
Our OpComms products include a wide range of components, modules and subsystems to support and maintain customers in our two primary markets: Telecom and Datacom. The Telecom market includes carrier networks for access (local), metro (intracity), long-haul (city-to-city and worldwide) and submarine (undersea) networks. The Datacom market addresses enterprise, cloud and data center applications, including storage-access networks (“SANs”), local-area networks (“LANs”) and wide-area networks (“WANs”). These products enable the transmission and transport of video, audio and text data over high-capacity fiber-optic cables. We maintain leading positions in the fast growing OpComms markets, including reconfigurable optical add/drop multiplexers (“ROADMs”), tunable 10-gigabit small form-factor pluggable transceivers and tunable small form-factor pluggable transceivers. Our 10G, 40G legacy transceivers and a growing portfolio of 100G pluggable transceivers support LAN/SAN/WAN needs and the cloud for customers building enterprise and hyperscale data center networks.

[0001633978-17-000095:mdna:8]
In the Consumer and Industrial markets, our OpComms products include laser light sources, which are integrated into 3D sensing platforms being used in applications for mobile devices, gaming, computers, virtual and augmented reality, other consumer electronics devices, and industrial segments. These systems simplify the way people interact with technology by enabling the use of natural body gestures, like the wave of a hand, to control a product or application. Systems can also be used for identification, safety, and process efficiency, among numerous other application spaces. Emerging applications for this technology include various mobile device applications, autonomous vehicles, self-navigating robotics and drones in industrial applications and 3D capture of objects coupled with 3D printing. Our laser light sources are also used in a variety of other industrial laser and processing applications.

[0001633978-17-000095:mdna:9]
Our OpComms customers include Ciena, Cisco Systems, Coriant, Fujitsu, Arista, Alphabet (formerly Google), Facebook, Yahoo, Microsoft, Huawei Technologies, FiberHome, Infinera, Microsoft, and Nokia Networks (including Alcatel-Lucent International).

[0001633978-17-000095:mdna:10]
Lasers

[0001633978-17-000095:mdna:11]
Our Lasers products serve our customers in markets and applications such as sheet metal processing, general manufacturing, biotechnology, graphics and imaging, remote sensing, and precision machining such as drilling in printed circuit boards, wafer singulation, glass cutting and solar cell scribing.

[0001633978-17-000095:mdna:12]
Our Lasers products are used in a variety of original equipment manufacturer (“OEM”) applications including diode-pumped solid-state, fiber, diode, direct-diode and gas lasers such as argon-ion and helium-neon lasers. Fiber lasers provide kW-class output powers combined with excellent beam quality and are used in sheet metal processing and metal welding applications. Diode-pumped solid-state lasers provide excellent beam quality, low noise and exceptional reliability and are used in biotechnology, graphics and imaging, remote sensing, materials processing and precision machining applications. Diode and direct-diode lasers address a wide variety of applications, including laser pumping, thermal exposure, illumination, ophthalmology, image recording, printing, plastic welding and selective soldering. Gas lasers such as argon-ion and helium-neon lasers provide a stable, low-cost

[0001633978-17-000095:mdna:13]
and reliable solution over a wide range of operating conditions, making them well suited for complex, high-resolution OEM applications such as flow cytometry, DNA sequencing, graphics and imaging and semiconductor inspection.

[0001633978-17-000095:mdna:14]
Our acquisition of Time-Bandwidth enabled us to provide high-powered and ultrafast lasers for the industrial and scientific markets. Manufacturers use high-power, ultrafast lasers to create micro parts for consumer electronics and to process semiconductor, LED, and other types of chips. Use of ultrafast lasers for micromachining applications is being driven primarily by the increasing use of consumer electronics and connected devices globally.

[0001633978-17-000095:mdna:15]
Our Lasers customers include Amada, ASML Holding, Beckman Coulter, Becton, Dickinson and Company, DISCO, Electro Scientific Industries, EO Technics, and KLA-Tencor.

[0001633978-17-000095:mdna:16]
Separation from JDSU

[0001633978-17-000095:mdna:17]
Lumentum Holdings Inc. was incorporated in Delaware as a wholly owned subsidiary of JDS Uniphase Corporation (“JDSU”) on February 10, 2015 and is comprised of the former communications and commercial optical products (“CCOP”) segment and the WaveReady product lines of JDSU. On August 1, 2015, we became an independent publicly-traded company through the distribution by JDSU to its stockholders of 80.1% of our outstanding common stock (the “Separation”).   Each JDSU stockholder of record as of the close of business on July 27, 2015 received one share of Lumentum common stock for every five shares of JDSU common stock held on the record date. JDSU was renamed Viavi in connection with the Separation and retained ownership of 19.9% of Lumentum’s outstanding shares.

[0001633978-17-000095:mdna:18]
On July 31, 2015, prior to the Separation, Viavi transferred substantially all of the assets and liabilities and operations of the CCOP segment and WaveReady product lines to Lumentum. Our financial statements for periods prior to the Separation were prepared on a stand-alone basis and were derived from Viavi’s consolidated financial statements and accounting records. For the period from June 28, 2015 to August 1, 2015, expenses were allocated to us using estimates that we consider to be a reasonable reflection of the utilization of services provided to or benefits received by us.

[0001633978-17-000095:mdna:19]
The consolidated financial statements include certain assets and liabilities that were historically held at the Viavi level but which were transferred to us in the Separation. Viavi’s debt and related interest expense were not attributed or allocated to us for the periods presented since we are not the legal obligor of the debt and Viavi’s borrowings were not directly attributable to us. Certain intercompany transactions between us and Viavi were considered to be effectively settled in the consolidated financial statements at the time the transactions were recorded. The total net effect of the settlement of these intercompany transactions is reflected in our consolidated statements of cash flows as a financing activity and on the consolidated balance sheets as Viavi net investment.

[0001633978-17-000095:mdna:20]
The consolidated statements of operations includes our direct expenses for cost of sales, R&D, sales and marketing, and administration as well as allocations of expenses arising from shared services and infrastructure provided by Viavi to us through the Separation. These allocated expenses include costs of information technology, human resources, accounting, legal, real estate and facilities, corporate marketing, insurance, treasury and other corporate and infrastructure services. In addition, other costs allocated to us include restructuring and stock-based compensation related to Viavi’s corporate and shared services employees as well as other public company costs. These expenses were allocated to us using estimates that we consider to be a reasonable reflection of the utilization of services provided to or benefits received by our business. The allocation methods include revenue, headcount, square footage, actual consumption and usage of services and others.

[0001633978-17-000095:mdna:21]
Critical Accounting Policies and Estimates

[0001633978-17-000095:mdna:22]
The preparation of the consolidated financial statements in accordance with GAAP in the United States requires management to make estimates and assumptions that affect the amounts reported in our consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact us in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are short-term investments, impairment of marketable and non-marketable securities, inventory valuation, goodwill and intangibles, long-lived asset valuation, pension benefits, revenue recognition,  stock-based compensation, income taxes, restructuring, derivative liabilities,  business combinations, and warranty.

[0001633978-17-000095:mdna:23]
Short-term Investments

[0001633978-17-000095:mdna:24]
We classify our investments in debt as available-for-sale and record these investments at fair value. Investments with an original maturity of three months or less at the date of purchase are considered cash equivalents, while all other investments are classified as short-term based on management’s intent and ability to use the funds in current operations. Unrealized gains and losses are reported as a component of other comprehensive loss. Realized gains and losses are determined based on the specific identification method, and are reflected as interest and other income (expense), net in our Consolidated Statements of Operations. We regularly review our investment portfolio to identify and evaluate investments that have indicators of possible impairment. Factors considered in determining whether a loss is other-than-temporary include, but are not limited to: the length of time and extent a security’s fair value has been below its cost, the financial condition and near-term prospects of the investee, the credit quality of the security’s issuer, likelihood of recovery and our intent and ability to hold the security for a period of time sufficient to allow for any anticipated recovery in value. For our debt instruments, we also evaluate whether we have the intent to sell the security or it is more likely than not that we will be required to sell the security before recovery of its cost basis.

[0001633978-17-000095:mdna:25]
Impairment of Marketable and Non-Marketable Securities

[0001633978-17-000095:mdna:26]
We periodically review our marketable and non-marketable securities for impairment. If we conclude that any of these investments are impaired, we determine whether such impairment is other-than-temporary. We consider factors such as the duration, severity and the reason for the decline in value, the potential recovery period and whether we intend to sell. For marketable debt securities, we also consider whether (i) it is more likely than not that we will be required to sell the debt securities before recovery of their amortized cost basis, and (ii) the amortized cost basis cannot be recovered as a result of credit losses. If any impairment is considered other-than-temporary, we will write-down the security to its fair value.

[0001633978-17-000095:mdna:27]
Inventory Valuation

[0001633978-17-000095:mdna:28]
Inventory is valued at standard cost, which approximates actual cost computed on a first-in, first-out basis, not in excess of net realizable value. We assess the value of our inventory on a quarterly basis and write down those inventories which are obsolete or in excess of our forecasted usage to their estimated realizable value. Our estimates of realizable value are based upon our analysis and assumptions including, but not limited to, forecasted sales levels by product, expected product lifecycle, product development plans and future demand requirements. Our product line management personnel play a key role in our excess review process by providing updated sales forecasts, managing product transitions and working with manufacturing to minimize excess inventory. If actual market conditions are less favorable than our forecasts or actual demand from our customers is lower than our estimates, we may be required to record additional inventory write-downs. If actual market conditions are more favorable than anticipated, inventory previously written down may be sold, resulting in lower cost of sales and higher income from operations than expected in that period.

[0001633978-17-000095:mdna:29]
Goodwill

[0001633978-17-000095:mdna:30]
Goodwill represents the excess of the purchase price of an acquired business over the fair value of the identifiable assets acquired and liabilities assumed. We test for impairment of goodwill on an annual basis in the fourth quarter and at any other time when events occur or circumstances indicate that the carrying amount of goodwill may not be recoverable. Refer to “Note 13. Goodwill and Other Intangible Assets” in the Notes to Consolidated Financial Statements.

[0001633978-17-000095:mdna:31]
An entity has the option to first assess qualitative factors to determine whether it is necessary to perform the two-step quantitative goodwill impairment test. If an entity determines that as a result of the qualitative assessment that it is more likely than not (i.e., greater than 50% likelihood) that the fair value of a reporting unit is less than its carrying amount, then the quantitative test is required. Otherwise, no further testing is required. The two-step quantitative goodwill impairment test requires us to estimate the fair value of our reporting units. If the carrying value of a reporting unit exceeds its fair value, the goodwill of that reporting unit is potentially impaired and we proceed to step two of the impairment analysis. In step two of the analysis, we measure and record an impairment loss equal to the excess of the carrying value of the reporting unit’s goodwill over its implied fair value, if any.

[0001633978-17-000095:mdna:32]
Application of the goodwill impairment test requires judgments, including: identification of the reporting units, assigning assets and liabilities to reporting units, assigning goodwill to reporting units, a qualitative assessment to determine whether there are any impairment indicators, and determining the fair value of each reporting unit. We estimate the fair value of a reporting unit using the market approach, which estimates the fair value based on comparable market prices. Significant estimates in the market approach include: identifying similar companies with comparable business factors such as size, growth, profitability, risk and return on investment, and assessing comparable revenue and operating income multiples in estimating the fair value of the reporting unit.

[0001633978-17-000095:mdna:33]
We base our estimates on historical experience and on various assumptions about the future that we believe are reasonable based on available information. Unanticipated events and circumstances may occur that affect the accuracy of our assumptions,

[0001633978-17-000095:mdna:34]
estimates and judgments. For example, if the price of our common stock were to significantly decrease combined with other adverse changes in market conditions, thus indicating that the underlying fair value of our reporting units may have decreased, we might be required to reassess the value of our goodwill in the period such circumstances were identified.

[0001633978-17-000095:mdna:35]
Intangible Assets

[0001633978-17-000095:mdna:36]
Intangible assets consist primarily of intangible assets purchased  through acquisitions. Purchased intangible assets primarily include acquired developed technologies (developed and core technology). Intangible assets are amortized using the straight-line method over the estimated economic useful lives of the assets, which is the period during which expected cash flows support the fair value of such intangible assets.

[0001633978-17-000095:mdna:37]
Long-lived Asset Valuation (Property, Plant and Equipment and Intangible Assets Subject to Amortization)

[0001633978-17-000095:mdna:38]
We test long-lived assets for recoverability, at the asset group level, when events or changes in circumstances indicate that their carrying amount may not be recoverable. Circumstances which could trigger a review include, but are not limited to: significant decreases in the market price of the asset, significant adverse changes in the business climate or legal factors, accumulation of costs significantly in excess of the amount originally expected for the acquisition or construction of the asset, current period cash flow or operating losses combined with a history of losses or a forecast of continuing losses associated with the use of the asset, or current expectation that the asset will more likely than not be sold or disposed significantly before the end of its estimated useful life.

[0001633978-17-000095:mdna:39]
Recoverability is assessed based on the difference between the carrying amount of the asset and the sum of the undiscounted cash flows expected to result from the use and the eventual disposal of the asset. An impairment loss is recognized when the carrying amount is not recoverable and exceeds fair value.

[0001633978-17-000095:mdna:40]
Revenue Recognition

[0001633978-17-000095:mdna:41]
We recognize revenue when all four revenue recognition criteria have been met: (i) persuasive evidence of an arrangement exists, (ii) the product has been delivered or the service has been rendered, (iii) the price is fixed or determinable and (iv) collection is reasonably assured. Revenue from product sales is recorded when all of the foregoing conditions are met and risk of loss and title passes to the customer. Our products typically include a warranty and the estimated cost of product warranty claims, based on historical experience, is recorded at the time the sale is recognized. Sales to customers are generally not subject to price protection or return rights.

[0001633978-17-000095:mdna:42]
The majority of our sales are made to OEMs, distributors, resellers and end-users.

[0001633978-17-000095:mdna:43]
Stock-based Compensation

[0001633978-17-000095:mdna:44]
Compensation expense related to stock-based transactions, including employee and director restricted stock units (“RSUs”) is measured and recognized in the financial statements based on fair value at the grant date. The fair value of time-based RSUs is based on the closing market price of our common stock on the grant date of the award. The stock-based compensation expense is recognized, net of forfeitures using a straight-line basis over the requisite service periods of the awards, which is generally three to four years.

[0001633978-17-000095:mdna:45]
We estimate the expected forfeiture rate and recognize only expense for those shares expected to vest. When estimating forfeitures, we consider historical forfeiture experiences as well as our expectation about future terminations and workforce reduction programs. The estimated forfeiture rate is trued up to the actual forfeiture rate as the equity awards vest. The total fair value of the equity awards, net of forfeitures, is recorded on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period, except for performance stock units which are amortized on a graded vesting method.

[0001633978-17-000095:mdna:46]
We estimate the fair value of the rights to acquire stock under our Employee Stock Purchase Plan (“ESPP”) using the Black-Scholes option pricing formula. Our ESPP provides for consecutive six-month offering periods. We recognize such compensation expense on a straight-line basis over the requisite service period. We calculate the volatility factor based on our historical stock prices.

[0001633978-17-000095:mdna:47]
We account for the fair value of RSUs using the closing market price of our common stock on the date of grant. For new-hire grants, RSUs generally vest ratably on an annual basis over four years. For annual refresh grants, RSUs generally vest ratably on an annual, or combination of annual and quarterly, basis over three years.

[0001633978-17-000095:mdna:48]
We account for the fair value of performance stock units (“PSUs”) using the closing market price of our common stock on the date of grant. We begin recognizing compensation expense when we conclude that it is probable that the performance conditions will be achieved. We reassess the probability of vesting at each reporting period and adjust our compensation cost based on this probability assessment.

[0001633978-17-000095:mdna:49]
We will continue to use judgment in evaluating the assumptions related to our stock-based compensation on a prospective basis. As we continue to accumulate additional data related to our common stock, we may have refinements to our estimates, which could materially impact our future stock-based compensation expense.

[0001633978-17-000095:mdna:50]
Income Taxes

[0001633978-17-000095:mdna:51]
In accordance with the authoritative guidance on accounting for income taxes, we recognize income taxes using an asset and liability approach. This approach requires the recognition of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in our consolidated financial statements or tax returns. The measurement of current and deferred taxes is based on provisions of the enacted tax law, and the effects of future changes in tax laws or rates are not anticipated.

[0001633978-17-000095:mdna:52]
The authoritative guidance provides for recognition of deferred tax assets if the realization of such deferred tax assets is more likely than not to occur based on an evaluation of both positive and negative evidence and the relative weight of the evidence. With the exception of certain international jurisdictions, we have determined that at this time it is more likely than not that our deferred tax assets will not be realized in the future.  This determination is primarily due to our history of losses which impacts our ability to benefit from our deferred tax assets. Accordingly, we have established a valuation allowance for such deferred tax assets. If there is a change in our ability to realize our deferred tax assets for which a valuation allowance has been established, then our tax provision may decrease in the period in which we determine that realization is more likely than not.

[0001633978-17-000095:mdna:53]
We are subject to income tax audits by the respective tax authorities of the jurisdictions in which we operate. The determination of our income tax liabilities in each of these jurisdictions requires the interpretation and application of complex, and sometimes uncertain, tax laws and regulations. The authoritative guidance on accounting for income taxes prescribes both recognition and measurement criteria that must be met for the benefit of a tax position to be recognized in the financial statements.  If a tax position taken, or expected to be taken, in a tax return does not meet such recognition or measurement criteria, an unrecognized tax benefit liability is recorded.  If we ultimately determine that an unrecognized tax benefit liability is no longer necessary, we reverse the liability and recognize a tax benefit in the period in which it is determined that the unrecognized tax benefit liability is no longer necessary.

[0001633978-17-000095:mdna:54]
The recognition and measurement of current taxes payable or refundable and deferred tax assets and liabilities requires that we make certain estimates and judgments. Changes to these estimates or a change in judgment may have a material impact on our tax provision in a future period.

[0001633978-17-000095:mdna:55]
Restructuring Accrual

[0001633978-17-000095:mdna:56]
Costs associated with restructuring activities are recognized when they are incurred. However, in the case of leases, the expense is estimated and accrued when the property is vacated. Given the significance of, and the timing of the execution of such activities, this process is complex and involves periodic reassessments of estimates made from the time the property was vacated, including evaluating real estate market conditions for expected vacancy periods and sub-lease income. We recognize a liability for post-employment benefits for workforce reductions related to restructuring activities when payment is probable and the amount is reasonably estimable. We continually evaluate the adequacy of the remaining liabilities under our restructuring initiatives. Although we believe that these estimates accurately reflect the costs of our restructuring plans, actual results may differ, thereby requiring us to record additional provisions or reverse a portion of such provisions. Refer to “Note 14. Restructuring and Related Charges” in the Notes to Consolidated Financial Statements.

[0001633978-17-000095:mdna:57]
Derivative Liabilities

[0001633978-17-000095:mdna:58]
The Series A Preferred Stock issued by our subsidiary Lumentum Inc. is redeemable at the option of the holder after five years and classified as non-controlling interest redeemable convertible preferred stock in our consolidated balance sheet and is measured at its redemption value. The Series A Preferred Stock conversion feature is bifurcated from the Series A Preferred Stock and accounted for separately as a derivative liability. In March 2017, we issued $450.0 million in aggregate principal amount of 0.25% Convertible Senior Notes due in March 2024 (the “2024 Notes”), unless earlier repurchased by us or converted pursuant to their terms. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability.

[0001633978-17-000095:mdna:59]
On a quarterly basis, the derivative liabilities are marked to market based on the fair value of the conversion features, with the resulting income or loss recorded as unrealized loss on derivative liabilities on our consolidated statements of operations. The determination of fair value includes various inputs, including volatility and interest rate assumptions. However, the change in the fair value of our common stock has the largest impact to the fair value of the derivatives. During fiscal 2017 and 2016, we recognized a change in value of the derivative liabilities of $104.2 million and $10.3 million, respectively.

[0001633978-17-000095:mdna:60]
Business Combinations

[0001633978-17-000095:mdna:61]
We allocate the fair value of purchase consideration to the tangible assets acquired, liabilities assumed and intangible assets acquired based on their estimated fair values. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. When determining the fair values of assets acquired and liabilities assumed, management makes significant estimates and assumptions, especially with respect to intangible assets. Critical estimates in valuing certain intangible assets include, but are not limited to, future expected cash flows from customer relationships and acquired developed technology and discount rates. Management’s estimates of fair value are based upon assumptions believed to be reasonable, but which are inherently uncertain and unpredictable and, as a result, actual results may differ materially from estimates. Other estimates associated with the accounting for acquisitions may change as additional information becomes available regarding the assets acquired and liabilities assumed.

[0001633978-17-000095:mdna:62]
In many cases, the accounting treatment of a particular transaction is specifically dictated by GAAP and does not require management’s judgment in its application. There are also areas in which management’s judgment in selecting among available alternatives would not produce a materially different result. Our senior management has reviewed our critical accounting policies and related disclosures with the Audit Committee of our board of directors.

[0001633978-17-000095:mdna:63]
Warranty

[0001633978-17-000095:mdna:64]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We estimate the costs of our warranty obligations based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise.

[0001633978-17-000095:mdna:65]
Recently Issued Accounting Pronouncements

[0001633978-17-000095:mdna:66]
Refer to “Note 2. Recently Issued Accounting Pronouncements” in the Notes to Consolidated Financial Statements.

[0001633978-17-000095:mdna:67]
RESULTS OF OPERATIONS

[0001633978-17-000095:mdna:68]
The results of operations for the periods presented are not necessarily indicative of results to be expected for future periods. The following table summarizes selected Consolidated Statements of Operations items as a percentage of net revenue:

[0001633978-17-000095:mdna:69]
|  | Years Ended |
|  | July 1, 2017 |  | July 2, 2016 |  | June 27, 2015 |
| Segment net revenue: |  |  |  |  |  |
| OpComms | 85.6 | % |  | 84.3 | % |  | 82.9 | % |
| Lasers | 14.4 |  |  | 15.7 |  |  | 17.1 |  |
| Net revenue | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of sales | 67.6 |  |  | 68.5 |  |  | 68.3 |  |
| Amortization of acquired technologies | 0.6 |  |  | 0.8 |  |  | 0.9 |  |
| Gross profit | 31.8 |  |  | 30.7 |  |  | 30.8 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 14.8 |  |  | 15.6 |  |  | 16.8 |  |
| Selling, general and administrative | 11.0 |  |  | 13.0 |  |  | 15.4 |  |
| Restructuring and related charges | 1.2 |  |  | 0.8 |  |  | 1.4 |  |
| Total operating expenses | 27.0 |  |  | 29.4 |  |  | 33.6 |  |
| Income (loss) from operations | 4.8 |  |  | 1.3 |  |  | (2.8 | ) |
| Unrealized loss on derivative liabilities | (10.4 | ) |  | (0.1 | ) |  | — |  |
| Interest and other income (expense), net | (0.3 | ) |  | (0.1 | ) |  | (0.1 | ) |
| Income (loss) before income taxes | (5.9 | ) |  | 1.1 |  |  | (2.9 | ) |
| Provision for (benefit from) income tax | 4.3 |  |  | 0.1 |  |  | (2.5 | ) |
| Net income (loss) | (10.2 | )% |  | 1.0 | % |  | (0.4 | )% |

[0001633978-17-000095:mdna:70]
Financial Data for Fiscal 2017, 2016 and 2015

[0001633978-17-000095:mdna:71]
The following table summarizes selected Consolidated Statements of Operations items (in millions, except for percentages):

[0001633978-17-000095:mdna:72]
|  | 2017 |  | 2016 |  | Change |  | Percentage Change |  | 2016 |  | 2015 |  | Change |  | Percentage Change |
| Segment net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| OpComms | $ | 857.8 |  |  | $ | 761.3 |  |  | $ | 96.5 |  |  | 12.7 | % |  | $ | 761.3 |  |  | $ | 694.1 |  |  | $ | 67.2 |  |  | 9.7 | % |
| Lasers | 143.8 |  |  | 141.7 |  |  | 2.1 |  |  | 1.5 |  |  | 141.7 |  |  | 143.0 |  |  | (1.3 | ) |  | (0.9 | ) |
| Net revenue | $ | 1,001.6 |  |  | $ | 903.0 |  |  | $ | 98.6 |  |  | 10.9 | % |  | $ | 903.0 |  |  | $ | 837.1 |  |  | $ | 65.9 |  |  | 7.9 | % |
| Gross profit | $ | 318.1 |  |  | $ | 277.3 |  |  | $ | 40.8 |  |  | 14.7 | % |  | $ | 277.3 |  |  | $ | 257.9 |  |  | $ | 19.4 |  |  | 7.5 | % |
| Gross margin | 31.8 | % |  | 30.7 | % |  |  |  |  |  | 30.7 | % |  | 30.8 | % |  |  |  |  |
| Research and development | $ | 148.3 |  |  | $ | 141.1 |  |  | $ | 7.2 |  |  | 5.1 | % |  | $ | 141.1 |  |  | $ | 140.8 |  |  | $ | 0.3 |  |  | 0.2 | % |
| Percentage of net revenue | 14.8 | % |  | 15.6 | % |  |  |  |  |  | 15.6 | % |  | 16.8 | % |  |  |  |  |
| Selling, general and administrative | $ | 110.2 |  |  | $ | 117.3 |  |  | $ | (7.1 | ) |  | (6.1 | )% |  | $ | 117.3 |  |  | $ | 128.9 |  |  | $ | (11.6 | ) |  | (9.0 | )% |
| Percentage of net revenue | 11.0 | % |  | 13.0 | % |  |  |  |  |  | 13.0 | % |  | 15.4 | % |  |  |  |  |
| Restructuring and related charges | $ | 12.0 |  |  | $ | 7.4 |  |  | $ | 4.6 |  |  | 62.2 | % |  | $ | 7.4 |  |  | $ | 11.6 |  |  | $ | (4.2 | ) |  | (36.2 | )% |
| Percentage of net revenue | 1.2 | % |  | 0.8 | % |  |  |  |  |  | 0.8 | % |  | 1.4 | % |  |  |  |  |

[0001633978-17-000095:mdna:73]
37

[0001633978-17-000095:mdna:74]
Net Revenue

[0001633978-17-000095:mdna:75]
Net revenue increased by $98.6 million, or 10.9% during fiscal 2017 compared to fiscal 2016. This increase was primarily due to an increase in net revenue from our OpComms segment. OpComms net revenue increased $96.5 million, or 12.7%, during fiscal 2017 compared to fiscal 2016 driven by increases from Telecom and 100G Datacom products. Lasers net revenue increased $2.1 million, or 1.5%, in fiscal 2017 compared to fiscal 2016.

[0001633978-17-000095:mdna:76]
Net revenue increased by $65.9 million, or 7.9%, during fiscal 2016 compared to fiscal 2015. This increase was primarily due to an increase in net revenue from our OpComms segment. OpComms net revenue increased $67.2 million, or 9.7%, during fiscal 2016 compared to fiscal 2015 driven by increases from Telecom and 100G Datacom products. Lasers net revenue decreased $1.3 million, or 0.9%, in fiscal 2016 compared to fiscal 2015.

[0001633978-17-000095:mdna:77]
Revenue by Region

[0001633978-17-000095:mdna:78]
We operate in three geographic regions: Americas, Asia-Pacific and EMEA. Net revenue is assigned to the geographic region and country where our product is initially shipped. For example, certain customers may request shipment of our product to a contract manufacturer in one country, however, the location of the end customers may differ. The following table presents net revenue by the three geographic regions we operate in and net revenue from countries that exceeded 10% or more of our total net revenue (in millions, except for percentages):

[0001633978-17-000095:mdna:79]
|  | Years Ended |
|  | July 1, 2017 |  | July 2, 2016 |  | June 27, 2015 |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 147.9 |  |  | 14.8 | % |  | $ | 162.3 |  |  | 18.0 | % |  | $ | 162.4 |  |  | 19.4 | % |
| Mexico | 185.1 |  |  | 18.5 |  |  | 112.9 |  |  | 12.5 |  |  | 112.7 |  |  | 13.5 |  |
| Other Americas | 9.2 |  |  | 0.9 |  |  | 19.6 |  |  | 2.2 |  |  | 31.1 |  |  | 3.6 |  |
| Total Americas | $ | 342.2 |  |  | 34.2 | % |  | $ | 294.8 |  |  | 32.7 | % |  | $ | 306.2 |  |  | 36.5 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 226.7 |  |  | 22.6 | % |  | $ | 214.0 |  |  | 23.7 | % |  | $ | 120.4 |  |  | 14.4 | % |
| Japan | 99.2 |  |  | 9.9 |  |  | 92.9 |  |  | 10.3 |  |  | 106.6 |  |  | 12.7 |  |
| Other Asia-Pacific | 225.4 |  |  | 22.5 |  |  | 177.8 |  |  | 19.6 |  |  | 174.4 |  |  | 20.9 |  |
| Total Asia-Pacific | $ | 551.3 |  |  | 55.0 | % |  | $ | 484.7 |  |  | 53.6 | % |  | $ | 401.4 |  |  | 48.0 | % |
| EMEA | $ | 108.1 |  |  | 10.8 | % |  | $ | 123.5 |  |  | 13.7 | % |  | $ | 129.5 |  |  | 15.5 | % |
| Total net revenue | $ | 1,001.6 |  |  |  |  | $ | 903.0 |  |  |  |  | $ | 837.1 |  |  |  |

[0001633978-17-000095:mdna:80]
During fiscal 2017, 2016 and 2015, net revenue from customers outside the United States, based on customer shipping location, represented 85.2%, 82% and 80.6% of net revenue, respectively. Our net revenue is primarily denominated in U.S. dollars, including our net revenue from customers outside the United States as presented above. We expect revenue from customers outside of the United States to continue to be an important part of our overall net revenue and an increasing focus for net revenue growth opportunities.

[0001633978-17-000095:mdna:81]
Gross Margin and Segment Gross Margin

[0001633978-17-000095:mdna:82]
The following table summarizes segment gross margin for fiscal 2017, 2016 and 2015 (in millions, except for percentages):

[0001633978-17-000095:mdna:83]
|  | Gross Profit |  | Gross Margin |
|  | 2017 |  | 2016 |  | 2015 |  | 2017 |  | 2016 |  | 2015 |
| OpComms | $ | 287.3 |  |  | $ | 236.3 |  |  | $ | 204.8 |  |  | 33.5 | % |  | 31.0 | % |  | 29.5 | % |
| Lasers | 59.9 |  |  | 61.4 |  |  | 67.4 |  |  | 41.7 | % |  | 43.3 | % |  | 47.1 | % |
| Segment total | $ | 347.2 |  |  | $ | 297.7 |  |  | $ | 272.2 |  |  | 34.7 | % |  | 33.0 | % |  | 32.5 | % |
| Unallocated corporate items (1) | (29.1 | ) |  | (20.4 | ) |  | (14.3 | ) |  |  |  |  |  |  |
| Total | $ | 318.1 |  |  | $ | 277.3 |  |  | $ | 257.9 |  |  | 31.8 | % |  | 30.7 | % |  | 30.8 | % |

[0001633978-17-000095:mdna:84]
(1) The unallocated corporate items for the years presented include the effects of amortization of acquired developed technology intangible assets, share-based compensation and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0001633978-17-000095:mdna:85]
Gross Margin

[0001633978-17-000095:mdna:86]
Gross margin in fiscal 2017 increased by 1.1% to 31.8% from 30.7% in fiscal 2016. This increase was primarily due to an increase in OpComms gross margins partially offset by a decrease in Lasers gross margins.

[0001633978-17-000095:mdna:87]
Gross margin in fiscal 2016 was relatively flat compared to fiscal 2015. A decrease in Lasers gross margins was offset by an increase in OpComms gross margins.

[0001633978-17-000095:mdna:88]
As discussed in more detail under “Net Revenue” above, we sell products in certain markets that are consolidating, undergoing product, architectural and business model transitions, have high customer concentrations, are highly competitive (increasingly due to Asia-Pacific-based competition), are price sensitive and/or are affected by customer seasonal and mix variant buying patterns. We expect these factors to continue to result in variability of our gross margin.

[0001633978-17-000095:mdna:89]
Segment Gross Margin

[0001633978-17-000095:mdna:90]
OpComms

[0001633978-17-000095:mdna:91]
OpComms gross margin in fiscal 2017 increased 2.5% to 33.5% from 31.0% in fiscal 2016. This increase was primarily due to higher revenue volume and product mix.

[0001633978-17-000095:mdna:92]
OpComms gross margin in fiscal 2016 increased 1.5% to 31.0% from 29.5% in fiscal 2015. This increase was primarily due to higher revenue volume and cost reductions, partially offset by an inventory write-off related to our legacy 3D sensing product.

[0001633978-17-000095:mdna:93]
Lasers

[0001633978-17-000095:mdna:94]
Lasers gross margin in fiscal 2017 decreased 1.6% to 41.7% from 43.3% in fiscal 2016. This decrease was primarily due to higher manufacturing and warranty costs.

[0001633978-17-000095:mdna:95]
Lasers gross margin in fiscal 2016 decreased 3.8% to 43.3% from 47.1% in fiscal 2015. This decrease was primarily due to lower revenue volume and higher warranty cost due to a component quality issue on our fiber laser product.

[0001633978-17-000095:mdna:96]
Research and Development

[0001633978-17-000095:mdna:97]
R&D expense increased $7.2 million, or 5.1%, in fiscal 2017 compared to fiscal 2016. The increase in R&D expense was primarily due to the increase in the payroll related expense of $8.6 million, which includes an increase of stock-based compensation of $2.6 million. This was partially offset with higher partner reimbursements for development expense.

[0001633978-17-000095:mdna:98]
R&D expense increased $0.3 million, or 0.2%, in fiscal 2016 compared to fiscal 2015. The increase in R&D expense was primarily due to increased investment in new R&D programs, one additional week of spend in fiscal 2016, and increased payroll related expense. This was partially offset by higher partner reimbursements for development expense and a decrease in payroll-related costs resulting from the closure of the Serangoon office in Singapore.

[0001633978-17-000095:mdna:99]
We believe that continuing our investments in R&D is critical to attaining our strategic objectives. We plan to continue to invest in R&D and new products that we believe will further differentiate us in the marketplace and expect our investment to increase in absolute dollars in future quarters.

[0001633978-17-000095:mdna:100]
Selling, General and Administrative

[0001633978-17-000095:mdna:101]
SG&A expense decreased $7.1 million, or 6.1%, in fiscal 2017 compared to fiscal 2016. The decrease was primarily a result of reduced separation related charges and restructuring expenses of $13.6 million.  This decrease was partially offset by an increase in payroll related expense of $7.8 million and an increase in stock-based compensation of $1.8 million.

[0001633978-17-000095:mdna:102]
SG&A expense decreased $11.6 million, or 9.0%, in fiscal 2016 compared to fiscal 2015. Our fiscal 2015 SG&A expense  included allocated expenses from Viavi and therefore was higher as compared to fiscal 2016 which was entirely on a stand-alone basis. This is partially offset by higher payroll related and benefits costs resulting from an additional week in fiscal 2016.

[0001633978-17-000095:mdna:103]
We intend to continue to focus on managing our SG&A expense as a percentage of net revenue. However, we may experience in the future, certain non-core expenses, such as mergers and acquisitions-related expenses and litigation expenses, which could increase our SG&A expense and potentially impact our profitability expectations in any particular quarter.

[0001633978-17-000095:mdna:104]
Restructuring and Related Charges

[0001633978-17-000095:mdna:105]
We have reduced costs through targeted restructuring efforts intended to consolidate our operations, rationalize the manufacturing of our products and align our business in response to market conditions. Refer to “Note 14. Restructuring and Related Charges” in the Notes to Consolidated Financial Statements.

[0001633978-17-000095:mdna:106]
As of July 1, 2017, our total restructuring accrual was $3.8 million. During fiscal 2017, we recorded $12.0 million in restructuring and related charges. Of the $12.0 million charge recorded during fiscal 2017, $2.1 million related to severance, retention and employee benefits.

[0001633978-17-000095:mdna:107]
During fiscal 2016, we recorded $7.7 million in restructuring and related charges.

[0001633978-17-000095:mdna:108]
| • | During the fourth quarter of fiscal 2016, management approved a plan to optimize operations and gain efficiencies throughout the organization. As a result, a restructuring charge of $0.7 million was recorded for severance and employee benefits during fiscal 2016. In total, there were 18 employees in manufacturing, R&D and SG&A functions that were terminated. Payments related to the remaining severance and benefits accrual have been paid in full. |

[0001633978-17-000095:mdna:109]
| • | We also incurred restructuring and related charges of $7.0 million from restructuring plans approved prior to fiscal 2016 primarily related to manufacturing transfer costs for transfer of certain production processes into existing sites in the United States or to contract manufacturers. |

[0001633978-17-000095:mdna:110]
Interest and Other Income (Expense), Net

[0001633978-17-000095:mdna:111]
Interest and other income (expense), net is comprised substantially of gains and losses associated with the re-measurement of non-functional currency denominated monetary assets and liabilities, as well as amortization of the debt discount on the 2024 Notes.  See “Note 11. Convertible Senior Notes” in the Notes to the Consolidated Financial Statements for additional information on the 2024 Notes.

[0001633978-17-000095:mdna:112]
Interest and other income (expense), net was $(3.2) million in fiscal 2017 as compared to $(1.2) million in fiscal 2016. The $2.0 million change was primarily due to interest expense related to the 2024 Notes in fiscal 2017.

[0001633978-17-000095:mdna:113]
Interest and other income (expense), net was $(1.2) million in fiscal 2016 as compared to $(1.1) million in fiscal 2015. The $0.1 million change was primarily due higher foreign exchange losses, offset by a decrease in interest expense in fiscal 2016.

[0001633978-17-000095:mdna:114]
The components of interest and other income (expense), net were as follows (in millions):

[0001633978-17-000095:mdna:115]
|  | Years Ended |
|  | July 1, 2017 |  | July 2, 2016 |  | June 27, 2015 |
| Interest expense | $ | (5.5 | ) |  | $ | (0.1 | ) |  | $ | (0.7 | ) |
| Foreign exchange gains (losses), net | 0.6 |  |  | (0.9 | ) |  | (0.3 | ) |
| Other income (expense), net | 1.7 |  |  | (0.2 | ) |  | (0.1 | ) |
| Interest and other income (expense), net | $ | (3.2 | ) |  | $ | (1.2 | ) |  | $ | (1.1 | ) |

[0001633978-17-000095:mdna:116]
Unrealized gain (loss) on derivative liabilities

[0001633978-17-000095:mdna:117]
Unrealized loss on Series A Preferred Stock derivative liability amounted to $41.3 million and $0.6 million for the fiscal years 2017 and 2016, respectively. Unrealized loss on the 2024 Notes derivative liability during fiscal 2017 was $62.9 million. The change is primarily related to the change in the price of our underlying common stock and is reflected in the consolidated statements of operations as “Unrealized gain (loss) on derivative liabilities”.

[0001633978-17-000095:mdna:118]
For further discussion of our derivative liabilities, see “Note 12. Derivative Liabilities” in the Notes to Consolidated Financial Statements.

[0001633978-17-000095:mdna:119]
Provision for (Benefit from) Income Taxes (in millions)

[0001633978-17-000095:mdna:120]
|  | Years Ended |
|  | July 1, 2017 |  | July 2, 2016 |  | June 27, 2015 |
| Provision for (benefit from) income taxes | $ | 42.7 |  |  | $ | 0.4 |  |  | $ | (21.1 | ) |

[0001633978-17-000095:mdna:121]
We recorded a provision (benefit) for income taxes of $42.7 million, $0.4 million, and $(21.1) million in fiscal 2017, 2016, and 2015, respectively.  Our effective tax rate of (71.4)% in fiscal 2017 differs from the U.S. statutory federal income tax rate of 35%, primarily attributable to non-deductible unrealized losses associated with the embedded derivatives for the Series A Preferred Stock and the 2024 Notes, as well as  unrecognized tax benefits,  non-deductible stock-based compensation, and changes in the valuation allowance against our deferred tax assets.  Our effective tax rate was also impacted by the benefit of our foreign income being taxed at different rates than the U.S. statutory rate, as well as the benefit of research and development tax credits.

[0001633978-17-000095:mdna:122]
Our effective tax rate of 4.1% in fiscal 2016 differs from the U.S. statutory federal income tax rate of 35%, primarily attributable to changes in the valuation allowance against our deferred tax assets and offset by the benefit of our foreign income being taxed at different rates than the U.S. statutory rates.

[0001633978-17-000095:mdna:123]
Our effective tax rate of 86.1% in fiscal 2015 differs from the U.S. statutory federal income tax rate of 35%, primarily attributable to reversal of previously accrued taxes and offset by Subpart F taxes.

[0001633978-17-000095:mdna:124]
As of July 1, 2017, we had net deferred tax assets of $3.6 million which was mainly comprised of tax attribute carryovers in certain foreign jurisdictions. Our federal, state, and Canada deferred tax assets are subject to a valuation allowance to reflect uncertainties about whether we will be able to utilize the deferred tax assets before they expire.

[0001633978-17-000095:mdna:125]
While we believe our current valuation allowance is sufficient, we assess the need for an adjustment to the valuation allowance on a quarterly basis. The assessment is based on our estimates of future sources of taxable income for the jurisdictions in which we operate and the periods over which our deferred tax assets will be realizable. In the event the Company determines that it will be able to realize all or part of its net deferred tax assets in the future, the valuation allowance will be reversed in the period in which the Company makes such determination. The release of a valuation allowance against deferred tax assets may cause greater volatility in the effective tax rate in the periods in which it is reversed. It is reasonably possible that significant positive evidence may become available to reach a conclusion that a significant portion of the valuation allowance will no longer be needed, and as such, we may release a significant portion of our valuation allowance in the next 12 months.  Such a release would result in the recognition of certain deferred tax assets and a decrease in the income tax expense for the period in which the release is recorded.

[0001633978-17-000095:mdna:126]
The income and non-income tax regimes we are subject to or operate under are unsettled and may be subject to significant change. Changes in tax laws or tax rulings, or changes in interpretations of existing laws, could materially affect our financial position and results of operations. Many countries in Europe, as well as a number of other countries and organizations, have recently proposed or recommended changes to existing tax laws or have enacted new laws that could significantly increase our tax obligations in many countries where we do business or require us to change the manner in which we operate our business. The Organization for Economic Cooperation and Development has been working on a Base Erosion and Profit Sharing Project, and issued in 2015, and is expected to continue to issue, guidelines and proposals that may change various aspects of the existing framework under which our tax obligations are determined in many of the countries in which we do business. The European Commission has conducted investigations in multiple countries focusing on whether local country tax rulings or tax legislation provides preferential tax treatment that violates European Union state aid rules and concluded that certain countries. These investigations may result in changes to the tax treatment of our foreign operations. In addition, the current U.S. administration and key members of Congress have made public statements indicating that tax reform is a priority. Certain changes to U.S. tax laws, including limitations on the ability to defer U.S. taxation on earnings outside of the United States until those earnings are repatriated to the United States, could affect the tax treatment of our foreign earnings. Due to our expanding international business activities, many of these types of

[0001633978-17-000095:mdna:127]
changes to the taxation of our activities could increase our worldwide effective tax rate and harm our financial position and results of operations.

[0001633978-17-000095:mdna:128]
For further discussion of our income tax provision, see “Note 15. Income Taxes” in the Notes to Consolidated Financial Statements.

[0001633978-17-000095:mdna:129]
Contractual Obligations

[0001633978-17-000095:mdna:130]
The following table summarizes our contractual obligations at July 1, 2017, and the effect such obligations are expected to have on our liquidity and cash flow over the next five years (in millions):

[0001633978-17-000095:mdna:131]
|  | Payments due by period |
|  | Total |  | Less than 1 year |  | 1 - 3 years |  | 3 - 5 years |  | More than 5 years |
| Contractual Obligations |  |  |  |  |  |  |  |  |  |
| Asset retirement obligations | $ | 2.8 |  |  | $ | 0.3 |  |  | $ | 0.4 |  |  | $ | 0.5 |  |  | $ | 1.6 |  |
| Purchase obligations (1) | 146.2 |  |  | 145.5 |  |  | 0.7 |  |  | — |  |  | — |  |
| Operating lease obligations (1) | 42.8 |  |  | 11.4 |  |  | 19.7 |  |  | 7.7 |  |  | 4.0 |  |
| Pension and post-retirement benefit payments (2) | 3.9 |  |  | 0.5 |  |  | 0.2 |  |  | 0.2 |  |  | 3.0 |  |
| 0.25% Convertible Senior Notes due 2024 | 450.0 |  |  | — |  |  | — |  |  | — |  |  | 450.0 |  |
| Interest on 2024 Notes (3) | 7.3 |  |  | 1.2 |  |  | 2.2 |  |  | 2.2 |  |  | 1.7 |  |
| Acquisition contingencies (4) | 2.7 |  |  | — |  |  | 2.7 |  |  | — |  |  | — |  |
| Total | $ | 655.7 |  |  | $ | 158.9 |  |  | $ | 25.9 |  |  | $ | 10.6 |  |  | $ | 460.3 |  |

[0001633978-17-000095:mdna:132]
(1) Refer to “Note 18. Commitments and Contingencies” in the Notes to Consolidated Financial Statements.

[0001633978-17-000095:mdna:133]
(2) Refer to “Note 17. Employee Benefit Plans” in the Notes to Consolidated Financial Statements.

[0001633978-17-000095:mdna:134]
(3) Includes interest on our 0.25% Convertible Senior Notes due 2024 through September 2023 as we have the right to redeem the 2024 Notes in whole or in part at any time on or after March 15, 2024.

[0001633978-17-000095:mdna:135]
(4) Refer to “Note 6. Mergers and Acquisitions” in the Notes to Consolidated Financial Statements.

[0001633978-17-000095:mdna:136]
Purchase obligations represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements.

[0001633978-17-000095:mdna:137]
As of July 1, 2017, other current liabilities on the consolidated balance sheet include $0.3 million and $0.3 million of asset retirement obligations and operating lease obligations, respectively, in connection with restructuring and related activities, disclosed in the preceding table.

[0001633978-17-000095:mdna:138]
As of July 1, 2017, our other non-current liabilities primarily relate to asset retirement obligations and pension which are presented in various lines in the preceding table.

[0001633978-17-000095:mdna:139]
As of July 1, 2017, our other non-current liabilities on the consolidated balance sheet include $10.5 million of unrecognized tax benefit for uncertain tax positions. We are unable to reliably estimate the timing of future payments related to uncertain tax positions and therefore have excluded them from the preceding table.

[0001633978-17-000095:mdna:140]
The table above does not include potential redemption of our redeemable convertible preferred stock with a $35.8 million face value, plus any accrued and unpaid interest, as there is no set maturity date. If the holder of our redeemable convertible preferred stock does not execute its conversion option, or if it is unable to do so before the third anniversary of the date of issuance, we may choose to redeem the preferred stock for $35.8 million. In addition, on the fifth anniversary date of the issuance, the holder of our redeemable convertible preferred stock may elect to redeem the preferred stock for $35.8 million.

[0001633978-17-000095:mdna:141]
Off-Balance Sheet Arrangements

[0001633978-17-000095:mdna:142]
We do not have any off-balance sheet arrangements, as such term is defined in rules promulgated by the SEC, that have or are reasonably likely to have a current or future effect on our financial condition, changes in financial condition, revenues or expenses, results of operations, liquidity, capital expenditures or capital resources that are material to investors.

[0001633978-17-000095:mdna:143]
Acquisitions

[0001633978-17-000095:mdna:144]
As part of our strategy, we are committed to the ongoing evaluation of strategic opportunities and, where appropriate, the acquisition of additional products, technologies or businesses that are complementary to, or broaden the markets for, our products. We believe we have strengthened our business model by expanding our addressable markets, customer base and expertise, diversifying our product portfolio, and fortifying our core businesses through acquisitions as well as through organic initiatives.

[0001633978-17-000095:mdna:145]
In February 2017, we completed the acquisition of a privately held company to enhance our manufacturing and vertical integration capabilities. We acquired all of the outstanding shares of the company.  In connection with the acquisition, we paid upfront cash consideration of $5.1 million, incurred liabilities of $2.7 million contingent upon the achievement of certain production targets being achieved within 36 months following the acquisition date, and retained $0.9 million of the purchase price as security for the seller’s indemnification obligations under the purchase agreement. This resulted in total purchase consideration of $8.7 million.

[0001633978-17-000095:mdna:146]
Please refer to “Note 6. Mergers and Acquisitions” in the Notes to Consolidated Financial Statements.

[0001633978-17-000095:mdna:147]
Pension Benefits

[0001633978-17-000095:mdna:148]
As a result of acquiring Time-Bandwidth in January 2014, we have a pension plan for certain employees in Switzerland. This plan is open to new participants and additional service costs are being accrued. The Switzerland plan is partially funded. As of July 1, 2017, our pension plan was under funded by $3.9 million since the projected benefit obligation (“PBO”) exceeded the fair value of the plan assets.

[0001633978-17-000095:mdna:149]
We expect to contribute $0.5 million to the Switzerland plan during fiscal 2018.

[0001633978-17-000095:mdna:150]
A key actuarial assumption in calculating the net periodic cost and the PBO is the discount rate. Changes in the discount rate impact the interest cost component of the net periodic benefit cost calculation and PBO due to the fact that the PBO is calculated on a net present value basis. Decreases in the discount rate will generally increase pre-tax cost, recognized expense and the PBO. Increases in the discount rate tend to have the opposite effect. We estimate a 50 basis point decrease or increase in the discount rate would cause a corresponding increase or decrease, respectively, in the PBO of $1.3 million or $(1.1) million, based upon data as of July 1, 2017.

[0001633978-17-000095:mdna:151]
Financial Condition

[0001633978-17-000095:mdna:152]
Liquidity and Capital Resources

[0001633978-17-000095:mdna:153]
As of July 1, 2017 and July 2, 2016, our cash and cash equivalents of $272.9 million and $157.1 million, respectively, were held predominantly in the United States. The total amount of cash outside the United States as of July 1, 2017 is $65.4 million, which is primarily held in Cayman Islands, Thailand, Canada, Switzerland, China and Japan. Although the cash currently held in the United States as well as the cash generated in the United States from future operations is expected to cover our normal operating requirements, a substantial amount of additional cash could be required for other purposes, such as capital expenditures to support our business and growth, including costs associated with increasing internal manufacturing capabilities, strategic transactions and partnerships, acquisitions, dividends that may be declared and future stock repurchase programs. Our intent is to indefinitely reinvest funds held outside the United States and our current plans do not demonstrate a need to repatriate them to fund our domestic operations. However, if in the future, we encounter a significant need for liquidity domestically or at a particular location that we cannot fulfill through borrowings, equity offerings, or other internal or external sources, we may determine that cash repatriations are necessary. Repatriation could result in additional material U.S. federal and state income tax payments in future years. Such adverse consequences would occur, for example, if the transfer of cash into the United States is taxed and no foreign tax credit is available to offset the U.S. tax liability, resulting in higher taxes. These factors may cause us to have an overall tax rate higher than other companies or higher than our tax rates have been in the past. If conditions warrant, we may seek to obtain additional financing through debt or equity sources. To the extent we issue additional shares, our existing stockholders may be diluted. However, any such financing may not be available on terms favorable to us, or may not be available at all.

[0001633978-17-000095:mdna:154]
Fiscal 2017

[0001633978-17-000095:mdna:155]
As of July 1, 2017, our consolidated balance of cash and cash equivalents increased by $115.8 million, to $272.9 million from $157.1 million as of July 2, 2016. The increase in cash and cash equivalents was mainly due to proceeds from the issuance of the 2024 Notes during fiscal 2017, offset by the purchases of short-term investments and property, plant and equipment.

[0001633978-17-000095:mdna:156]
Cash provided by operating activities was $85.0 million for the year ended July 1, 2017, primarily resulting from $102.5 million of net loss and $199.4 million of non-cash items such as depreciation, stock-based compensation, amortization of intangibles and unrealized loss on derivative liabilities, offset by changes in excess tax benefit associated with stock-based compensation. In addition, changes in our operating assets and liabilities of $11.9 million related primarily to an increase in inventories of $41.7 million and a decrease in accounts payable of $16.9 million related to such non-cash items as $10 million unpaid property, plant and equipment, offset by a decrease in deferred taxes, net of $26.8 million and an increase in income taxes payable of $15.9 million.

[0001633978-17-000095:mdna:157]
Cash used in investing activities was mainly for capital expenditures and purchases of short-term investments, net of sales of $138.1 million and $282.5 million, respectively, for the year ended July 1, 2017. Changes in investing cash flow in fiscal 2017 also related to the acquisition of a business for $5.1 million.

[0001633978-17-000095:mdna:158]
Cash provided by financing activities was $456.7 million for the year ended July 1, 2017, consisting primarily from proceeds of $442.3 million from the issuance of the 2024 Notes.

[0001633978-17-000095:mdna:159]
Fiscal 2016

[0001633978-17-000095:mdna:160]
As of July 2, 2016, our consolidated balance of cash and cash equivalents and short-term investments was $157.1 million, an increase of $142.3 million, or 961.5%, as compared to $14.8 million as of June 27, 2015.

[0001633978-17-000095:mdna:161]
Cash provided by operating activities was $86.6 million, primarily resulting from $9.3 million of net income, which included $80.7 million of non-cash items such as depreciation, stock-based compensation, derivative liability, amortization of intangibles and disposal of property, plant and equipment, offset by changes in operating assets and liabilities of $3.4 million. Changes in our operating assets and liabilities related primarily to an increase in accounts payable of $28.9 million, an increase in accounts receivable of $21.8 million, an increase in prepayments, other current and non-currents assets of $12.7 million, an increase in accrued payroll and related expenses of $9.2 million, a decrease in deferred taxes, net of $1.7 million, a decrease in income taxes payable of $1.7 million, an increase in inventories of $3.1 million and a decrease in accrued expenses and other current and non-current liabilities of $0.5 million.

[0001633978-17-000095:mdna:162]
Cash used in investing activities included $82.0 million, of cash used for capital expenditures, primarily to expand our manufacturing capacity.

[0001633978-17-000095:mdna:163]
Cash provided by financing activities was $136.4 million resulting primarily from net transfers from Viavi of $134.2 million at the Separation date.

[0001633978-17-000095:mdna:164]
Fiscal 2015

[0001633978-17-000095:mdna:165]
As of June 27, 2015, our consolidated balance of cash and cash equivalents and short-term investments was $14.8 million, a decrease of $5.4 million, or 26.7%, as compared to $20.2 million as of June 28, 2014.

[0001633978-17-000095:mdna:166]
Cash provided by operating activities was $9.4 million, primarily resulting from $3.4 million of net loss and $69.0 million of non-cash items such as depreciation, stock-based compensation, amortization of intangibles and changes in our deferred tax balances, offset by changes in operating assets and liabilities of $56.2 million. Changes in our operating assets and liabilities related primarily to an increase in accounts receivable of $17.8 million, an increase in other current and non-currents assets of $14.5 million, a decrease in income taxes payable of $10.8 million, an increase in inventories of $6.2 million and a decrease in accrued expenses and other current and non-current liabilities of $6.9 million.

[0001633978-17-000095:mdna:167]
Cash used in investing activities was $53.5 million, primarily resulting from cash used for capital expenditures of $53.7 million.

[0001633978-17-000095:mdna:168]
Cash provided by financing activities was $40.6 million resulting from net transfers from Viavi.

[0001633978-17-000095:mdna:169]
Liquidity and Capital Resources Requirements

[0001633978-17-000095:mdna:170]
We believe that our cash and cash equivalents as of July 1, 2017, and cash flows from our operating activities will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months. However, if market conditions are favorable, we may evaluate alternatives to opportunistically pursue additional financing.

[0001633978-17-000095:mdna:171]
There are a number of factors that could positively or negatively impact our liquidity position, including:

[0001633978-17-000095:mdna:172]
| • | global economic conditions which affect demand for our products and services and impact the financial stability of our suppliers and customers; |

[0001633978-17-000095:mdna:173]
| • | changes in accounts receivable, inventory or other operating assets and liabilities which affect our working capital; |

[0001633978-17-000095:mdna:174]
| • | increase in capital expenditures to support our business and growth; |

[0001633978-17-000095:mdna:175]
| • | the tendency of customers to delay payments or to negotiate favorable payment terms to manage their own liquidity positions; |

[0001633978-17-000095:mdna:176]
| • | timing of payments to our suppliers; |

[0001633978-17-000095:mdna:177]
| • | factoring or sale of accounts receivable; |

[0001633978-17-000095:mdna:178]
| • | volatility in fixed income and credit which impact the liquidity and valuation of our investment portfolios; |

[0001633978-17-000095:mdna:179]
| • | volatility in foreign exchange markets which impacts our financial results; |

[0001633978-17-000095:mdna:180]
| • | possible investments or acquisitions of complementary businesses, products or technologies, or other strategic transactions or partnerships; |

[0001633978-17-000095:mdna:181]
| • | issuance of debt or equity securities, or other financing transactions, including bank debt; |

[0001633978-17-000095:mdna:182]
| • | potential funding of pension liabilities either voluntarily or as required by law or regulation; and |

[0001633978-17-000095:mdna:183]
| • | the settlement of any conversion or redemption of the 2024 Notes in cash. |
