# LITE 8-K — 0001633978-17-000058 filed 2017-08-09

## item codes, every 8-K on or before 2017-08-29

- 2017-08-09 0001633978-17-000058 — 2.02, 9.01
- 2017-05-04 0001633978-17-000035 — 2.02, 9.01
- 2017-03-08 0001193125-17-074740 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2017-03-02 0001193125-17-066769 — 8.01, 9.01
- 2017-02-07 0001633978-17-000005 — 2.02, 9.01
- 2017-01-03 0001628280-17-000018 — 4.01, 9.01
- 2016-11-09 0001628280-16-021143 — 5.02, 5.07, 9.01
- 2016-10-27 0001628280-16-020382 — 2.02, 9.01
- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2017-08-29

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001633978-17-000058:8k_2_02:1]
EX-99.1
2
lite_ex991xq4fy17.htm
EXHIBIT 99.1

[0001633978-17-000058:8k_2_02:2]
Exhibit

[0001633978-17-000058:8k_2_02:3]
NEWS RELEASE

[0001633978-17-000058:8k_2_02:4]
LUMENTUM ANNOUNCES FISCAL FOURTH QUARTER AND FULL YEAR 2017 RESULTS

[0001633978-17-000058:8k_2_02:5]
Fiscal year 2017 record revenue over $1 billion, up 11% from fiscal year 2016

[0001633978-17-000058:8k_2_02:6]
Fiscal Fourth Quarter Highlights

[0001633978-17-000058:8k_2_02:7]
| • | Net Revenue of $222.7 million |

[0001633978-17-000058:8k_2_02:8]
| • | GAAP Operating margin of 1.8%; Non-GAAP Operating margin of 9.2% |

[0001633978-17-000058:8k_2_02:9]
| • | GAAP diluted Net loss per share of $(0.90); Non-GAAP diluted Net income per share of $0.39 |

[0001633978-17-000058:8k_2_02:10]
Milpitas, Calif., August 9, 2017 – Lumentum Holdings Inc. (“Lumentum” or the “Company”) today reported results for its fiscal fourth quarter and full year ended July 1, 2017.

[0001633978-17-000058:8k_2_02:11]
Net revenue for the fiscal fourth quarter 2017 was $222.7 million, with GAAP net loss of $(54.9) million, or $(0.90) per diluted share. Net revenue for fiscal third quarter 2017 was $255.8 million, with GAAP net loss of $(56.0) million, or $(0.92) per diluted share. Net revenue for the fiscal fourth quarter 2016 was $241.7 million, with GAAP net income of $14.3 million, or $0.23 per diluted share.

[0001633978-17-000058:8k_2_02:12]
Non-GAAP net income for the fiscal fourth quarter 2017 was $25.0 million or $0.39 per diluted share. Non-GAAP net income for fiscal third quarter 2017 was $30.8 million, or $0.49 per diluted share. Non-GAAP net income for the fiscal fourth quarter 2016 was $25.4 million, or $0.41 per diluted share. The Company held $555.3 million in total cash and short-term investments at the end of the fiscal fourth quarter 2017.

[0001633978-17-000058:8k_2_02:13]
Net revenue for fiscal year 2017 was $1,001.6 million, with GAAP net loss of $(102.5) million, or $(1.69) per diluted share. Net revenue for fiscal year 2016 was $903.0 million, with GAAP net income of $9.3 million, or $0.15 per diluted share.

[0001633978-17-000058:8k_2_02:14]
Non-GAAP net income for fiscal year 2017 was $122.4 million or $1.94 per diluted share.  Non-GAAP net income for fiscal year 2016 was $78.9 million, or $1.29 per diluted share.

[0001633978-17-000058:8k_2_02:15]
“In our second fiscal year as a stand-alone public company, we exceeded the $1 billion revenue mark and increased non-GAAP net income by more than 50% year-over-year.” said Alan Lowe, president and CEO. “We continue to make excellent progress on our strategic initiatives. Revenue from our 100G QSFP28 transceivers nearly doubled sequentially in the fourth quarter. We began ramping our 3D sensing products to meet our strong customer demand and expect volumes to increase monthly through the end of the calendar year.”

[0001633978-17-000058:8k_2_02:16]
Financial Overview – Fiscal Fourth Quarter Ended July 1, 2017

[0001633978-17-000058:8k_2_02:17]
|  | GAAP Results ($ in millions) |
|  | Q4 |  | Q3 |  | Q4 |  | Change |
|  | FY 2017 |  | FY 2017 |  | FY 2016 |  | Q/Q |  | Y/Y |
| Net revenue | $222.7 |  | $255.8 |  | $241.7 |  | (12.9)% |  | (7.9)% |
| Gross margin | 30.2% |  | 32.1% |  | 32.9% |  | (190)bps |  | (270)bps |
| Operating margin | 1.8% |  | 5.3% |  | 4.2% |  | (350)bps |  | (240)bps |
|  | Non-GAAP Results ($ in millions) |
|  | Q4 |  | Q3 |  | Q4 |  | Change |
|  | FY 2017 |  | FY 2017 |  | FY 2016 |  | Q/Q |  | Y/Y |
| Net revenue | $222.7 |  | $255.8 |  | $241.7 |  | (12.9)% |  | (7.9)% |
| Gross margin | 32.9% |  | 34.4% |  | 34.1% |  | (150)bps |  | (120)bps |
| Operating margin | 9.2% |  | 12.6% |  | 11.6% |  | (340)bps |  | (240)bps |

[0001633978-17-000058:8k_2_02:18]
|  | Net Revenue by Segment ($ in millions) |
|  | Q4 |  | % of |  | Q3 |  | Q4 |  | Change |
|  | FY 2017 |  | Net Revenue |  | FY 2017 |  | FY 2016 |  | Q/Q |  | Y/Y |
| Optical Communications | $186.8 |  | 83.9% |  | $216.1 |  | $201.2 |  | (13.6)% |  | (7.2)% |
| Lasers | 35.9 |  | 16.1% |  | 39.7 |  | 40.5 |  | (9.6)% |  | (11.4)% |
| Total | $222.7 |  | 100.0% |  | $255.8 |  | $241.7 |  | (12.9)% |  | (7.9)% |

[0001633978-17-000058:8k_2_02:19]
Financial Overview – Fiscal Year Ended July 1, 2017

[0001633978-17-000058:8k_2_02:20]
|  | GAAP Results ($ in millions) |
|  | FY 2017 |  | FY 2016 |  | Change Y/Y |  |
| Net revenue | $1,001.6 |  | $903.0 |  | 10.9% |  |
| Gross margin | 31.8% |  | 30.7% |  | 110bps |  |
| Operating margin | 4.8% |  | 1.3% |  | 350bps |  |

[0001633978-17-000058:8k_2_02:21]
|  | Non-GAAP Results ($ in millions) |
|  | FY 2017 |  | FY 2016 |  | Change Y/Y |  |
| Net revenue | $1,001.6 |  | $903.0 |  | 10.9% |  |
| Gross margin | 34.7% |  | 33.0% |  | 170bps |  |
| Operating margin | 12.4% |  | 9.2% |  | 320bps |  |

[0001633978-17-000058:8k_2_02:22]
|  | Net Revenue by Segment ($ in millions) |
|  | FY 2017 |  | FY 2016 |  | Change Y/Y |  |
| Optical Communications | $857.8 |  | $761.3 |  | 12.7% |  |
| Lasers | 143.8 |  | 141.7 |  | 1.5% |  |
| Total | $1,001.6 |  | $903.0 |  | 10.9% |  |

[0001633978-17-000058:8k_2_02:23]
The tables above provide comparisons of quarterly results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled “Use of Non-GAAP Financial Measures.”

[0001633978-17-000058:8k_2_02:24]
Business Outlook

[0001633978-17-000058:8k_2_02:25]
For the fiscal first quarter 2018, the Company expects net revenue to be in the range of $245 million to $265 million, non-GAAP operating margin to be 13.0% to 15.0%, and non-GAAP diluted earnings per share to be $0.50 to $0.60 per share, based on approximately 64.2 million shares outstanding on a fully diluted basis.

[0001633978-17-000058:8k_2_02:26]
We have not provided reconciliations from GAAP to non-GAAP measures for our outlook. A large portion of non-GAAP adjustments, such as derivative liability adjustments, restructuring, stock-based compensation, litigation, and other costs and contingencies unrelated to current and future operations are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future. For example, the unrealized loss on the derivative liabilities for Convertible Senior Notes and Series A Preferred Stock in our fiscal fourth quarter of 2017 was a loss of $29.7 million, as compared to a loss of $56.6 million in the fiscal third quarter of 2017. On June 29, 2017, we met the requirements to account for the conversion option of the Convertible Senior Notes as equity and the conversion option will no longer be marked to market. The unrealized loss on the derivative liability for the conversion option of the Convertible Senior Notes accounted for $24.2 million and $38.6 million of the total unrealized loss on the derivative liabilities in the fiscal fourth and third quarters of 2017, respectively. The Series A Preferred Stock derivative liability is revalued based on the fair market value of our common stock on the last day of each fiscal quarter, which is difficult to predict and subject to change.

[0001633978-17-000058:8k_2_02:27]
Conference Call

[0001633978-17-000058:8k_2_02:28]
Lumentum will host a conference call on August 9, 2017 at 5:30am PT/8:30am ET. A live webcast of the call and the replay will be available on the Lumentum website at http://investor.lumentum.com through August 16, 2017 at 11:30am ET. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the “Events and Presentations” section concurrently with this earnings press release. This press release is being furnished as an

[0001633978-17-000058:8k_2_02:29]
exhibit to a Current Report on Form 8-K with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001633978-17-000058:8k_2_02:30]
About Lumentum

[0001633978-17-000058:8k_2_02:31]
Lumentum (NASDAQ: LITE) is a market-leading manufacturer of innovative optical and photonic products enabling optical networking and commercial laser customers worldwide. Lumentum’s optical components and subsystems are part of virtually every type of telecom, enterprise, and data center network. Lumentum’s commercial lasers enable advanced manufacturing techniques and diverse applications including next-generation 3D sensing capabilities. Lumentum is headquartered in Milpitas, California with R&D, manufacturing, and sales offices worldwide.  For more information, visit https://www.lumentum.com/en.

[0001633978-17-000058:8k_2_02:32]
Forward-Looking Statements

[0001633978-17-000058:8k_2_02:33]
Contact Information

[0001633978-17-000058:8k_2_02:34]
Investors: Chris Coldren, 408-404-0606; investor.relations@lumentum.com

[0001633978-17-000058:8k_2_02:35]
Press: Greg Kaufman, 408-546-4593; media@lumentum.com

[0001633978-17-000058:8k_2_02:36]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001633978-17-000058:8k_2_02:37]
LUMENTUM HOLDINGS INC.

[0001633978-17-000058:8k_2_02:38]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001633978-17-000058:8k_2_02:39]
(in millions, except per share data)

[0001633978-17-000058:8k_2_02:40]
(unaudited)

[0001633978-17-000058:8k_2_02:41]
|  | Three Months Ended |  | Twelve Months Ended |
|  | July 1, 2017 |  | July 2, 2016 |  | July 1, 2017 |  | July 2, 2016 |
| Net revenue | $ | 222.7 |  |  | $ | 241.7 |  |  | $ | 1,001.6 |  |  | $ | 903.0 |  |
| Cost of sales | 154.0 |  |  | 160.5 |  |  | 677.0 |  |  | 618.9 |  |
| Amortization of acquired technologies | 1.4 |  |  | 1.7 |  |  | 6.5 |  |  | 6.8 |  |
| Gross profit | 67.3 |  |  | 79.5 |  |  | 318.1 |  |  | 277.3 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 35.4 |  |  | 36.4 |  |  | 148.3 |  |  | 141.1 |  |
| Selling, general and administrative | 26.0 |  |  | 29.5 |  |  | 110.2 |  |  | 117.3 |  |
| Restructuring and related charges | 2.0 |  |  | 3.5 |  |  | 12.0 |  |  | 7.4 |  |
| Total operating expenses | 63.4 |  |  | 69.4 |  |  | 270.5 |  |  | 265.8 |  |
| Income (loss) from operations | 3.9 |  |  | 10.1 |  |  | 47.6 |  |  | 11.5 |  |
| Unrealized gain (loss) on derivative liability | (29.7 | ) |  | 4.4 |  |  | (104.2 | ) |  | (0.6 | ) |
| Interest and other (expense) income, net | (1.8 | ) |  | (0.1 | ) |  | (3.2 | ) |  | (1.2 | ) |
| Income (loss) before income taxes | (27.6 | ) |  | 14.4 |  |  | (59.8 | ) |  | 9.7 |  |
| Provision for (benefit from) income taxes | 27.3 |  |  | 0.1 |  |  | 42.7 |  |  | 0.4 |  |
| Net income (loss) | (54.9 | ) |  | 14.3 |  |  | (102.5 | ) |  | 9.3 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | (0.90 | ) |  | $ | 0.24 |  |  | $ | (1.69 | ) |  | $ | 0.16 |  |
| Diluted | $ | (0.90 | ) |  | $ | 0.23 |  |  | $ | (1.69 | ) |  | $ | 0.15 |  |
| Items reconciling net income (loss) to net income (loss) available to common stockholders: |  |  |  |  |  |  |  |
| Cumulative dividends on Series A preferred stock | (0.3 | ) |  | (0.2 | ) |  | (0.9 | ) |  | (0.8 | ) |
| Adjustment for Series A preferred stock redemption value | — |  |  | — |  |  | — |  |  | (11.7 | ) |
| Net income (loss) available to common stockholders | $ | (55.2 | ) |  | $ | 14.1 |  |  | $ | (103.4 | ) |  | $ | (3.2 | ) |
| Net income (loss) available to common stockholders per share: |  |  |  |  |  |  |  |
| Basic | $ | (0.90 | ) |  | $ | 0.24 |  |  | $ | (1.71 | ) |  | $ | (0.05 | ) |
| Diluted | $ | (0.90 | ) |  | $ | 0.23 |  |  | $ | (1.71 | ) |  | $ | (0.05 | ) |
| Shares used in per share calculation: |  |  |  |  |  |  |  |
| Basic | 61.3 |  |  | 59.4 |  |  | 60.6 |  |  | 59.1 |  |
| Diluted net income per share | 61.3 |  |  | 61.8 |  |  | 60.6 |  |  | 61.2 |  |
| Diluted net income available to common stockholders | 61.3 |  |  | 61.8 |  |  | 60.6 |  |  | 59.1 |  |

[0001633978-17-000058:8k_2_02:42]
LUMENTUM HOLDINGS INC.

[0001633978-17-000058:8k_2_02:43]
CONSOLIDATED BALANCE SHEETS

[0001633978-17-000058:8k_2_02:44]
(in millions, except share and per share data)

[0001633978-17-000058:8k_2_02:45]
(unaudited)

[0001633978-17-000058:8k_2_02:46]
|  | July 1, 2017 |  | July 2, 2016 |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |  |
| Cash and cash equivalents | $ | 272.9 |  |  | $ | 157.1 |  |
| Short-term investments | 282.4 |  |  | — |  |
| Accounts receivable, net | 166.3 |  |  | 170.5 |  |
| Inventories | 145.2 |  |  | 100.6 |  |
| Prepayments and other current assets | 63.5 |  |  | 61.3 |  |
| Total current assets | 930.3 |  |  | 489.5 |  |
| Property, plant and equipment, net | 273.5 |  |  | 183.4 |  |
| Goodwill and intangibles, net | 21.5 |  |  | 19.9 |  |
| Deferred income taxes, net | 3.9 |  |  | 31.9 |  |
| Other non-current assets | 3.7 |  |  | 1.6 |  |
| Total assets | $ | 1,232.9 |  |  | $ | 726.3 |  |
| LIABILITIES, REDEEMABLE CONVERTIBLE PREFERRED STOCK, AND EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 114.8 |  |  | $ | 118.3 |  |
| Accrued payroll and related expenses | 27.5 |  |  | 26.5 |  |
| Income taxes payable | 0.7 |  |  | 1.9 |  |
| Accrued expenses | 19.3 |  |  | 14.9 |  |
| Other current liabilities | 21.9 |  |  | 12.1 |  |
| Total current liabilities | 184.2 |  |  | 173.7 |  |
| Convertible note | 317.5 |  |  | — |  |
| Derivative liability | 51.6 |  |  | 10.3 |  |
| Other non-current liabilities | 25.0 |  |  | 9.1 |  |
| Total liabilities | 578.3 |  |  | 193.1 |  |
| Redeemable convertible preferred stock: |  |  |  |
| Non-controlling interest redeemable convertible Series A preferred stock, $0.001 par value, 10,000,000 authorized shares; 35,805 shares issued and outstanding as of July 1, 2017 and July 2, 2016 | 35.8 |  |  | 35.8 |  |
| Total redeemable convertible preferred stock | 35.8 |  |  | 35.8 |  |
| Stockholders’ equity: |  |  |  |
| Common stock, $0.001 par value, 990,000,000 authorized shares, 61,476,103 and 59,580,596 shares issued and outstanding as of July 1, 2017 and July 2, 2016, respectively | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital | 694.5 |  |  | 467.7 |  |
| Retained earnings | (83.2 | ) |  | 20.2 |  |
| Accumulated other comprehensive income | 7.4 |  |  | 9.4 |  |
| Total stockholders’ equity | 618.8 |  |  | 497.4 |  |
| Total liabilities and stockholders’ equity | $ | 1,232.9 |  |  | $ | 726.3 |  |

[0001633978-17-000058:8k_2_02:47]
Use of Non-GAAP Financial Measures

[0001633978-17-000058:8k_2_02:48]
In this press release, Lumentum provides investors with gross margin, operating margin, net income, and net income (loss) per share on a non-GAAP basis. Lumentum believes this non-GAAP financial information provides additional insight into the Company’s on-going performance and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons. Specifically, the Company believes that providing this information allows investors to better understand the Company’s financial performance and, importantly, to evaluate the efficacy of the methodology and information used by management to evaluate and measure such operating performance.  However, these measures may be different from non-GAAP measures used by other companies, limiting their usefulness for comparison purposes. The non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP. Investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future. Further, these non-GAAP financial measures may not be comparable to similarly titled measurements reported by other companies.

[0001633978-17-000058:8k_2_02:49]
Non-GAAP gross margin, non-GAAP operating margin, non-GAAP net income, and non-GAAP net income per share, Adjusted EBITDA, non-GAAP gross profit, non-GAAP operating income, non-GAAP income (loss) before income taxes and non-GAAP expenses exclude (i) workforce related charges such as severance, retention bonuses and employee relocation costs related to formal restructuring plans, (ii) costs for facilities not required for ongoing operations, and costs related to the relocation of certain equipment from these facilities and/or contract manufacturer facilities, (iii) stock-based compensation, (iv) amortization of intangibles, (v)amortization of acquired developed technologies, (vi) non-cash interest expense, (vii) unrealized loss on derivative liabilities, and (viii) warranty charges related to our vendor quality issues with expected future recoveries and (ix) other charges comprising mainly of one-time provision for excess and obsolete inventory, acquisition, integration, litigation and other costs and contingencies unrelated to current and future operations including post-separation activities such as small site consolidations, reorganizations, insourcing or outsourcing of activities, severance related costs and transition related costs for the separation from Viavi Solutions Inc. (formerly JDS Uniphase Corporation) on July 31, 2015. In the fiscal third quarter of 2017, the Company issued $450 million in aggregate principal amount of convertible senior notes (the “convertible notes”). During the fourth quarter of 2017, prior to the satisfaction of certain conditions set forth more fully in the indenture governing the convertible notes (the “TMA settlement condition”), the Company would have been required to satisfy its conversion obligation solely in cash. Accordingly, the conversion option of the convertible notes was accounted for as a derivative liability under GAAP and thus, fluctuated with the fair market value of the stock price until the Company satisfied the TMA settlement condition on June 29, 2017. As of the last day of the fourth quarter of 2017, the Company met the requirements to account for the conversion option as equity and the conversion option will no longer be marked to market. Management does not believe that these non-GAAP items are reflective of the Company’s underlying operating performance. The presentation of these and other similar items in Lumentum’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001633978-17-000058:8k_2_02:50]
A quantitative reconciliation between GAAP and non-GAAP financial data with respect to historical periods is included in the supplemental financial table attached to this press release.

[0001633978-17-000058:8k_2_02:51]
LUMENTUM HOLDINGS INC.

[0001633978-17-000058:8k_2_02:52]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001633978-17-000058:8k_2_02:53]
(in millions, except per share data)

[0001633978-17-000058:8k_2_02:54]
(unaudited)

[0001633978-17-000058:8k_2_02:55]
|  | Three Months Ended |  | Twelve Months Ended |
|  | July 1, 2017 |  | July 2, 2016 |  | July 1, 2017 |  | July 2, 2016 |
| Gross profit on GAAP basis | $ | 67.3 |  |  | $ | 79.5 |  |  | $ | 318.1 |  |  | $ | 277.3 |  |
| Stock-based compensation | 1.5 |  |  | 1.2 |  |  | 7.5 |  |  | 6.1 |  |
| Other charges related to non-recurring activities | 3.0 |  |  | — |  |  | 15.1 |  |  | 7.5 |  |
| Amortization of acquired developed technologies | 1.4 |  |  | 1.7 |  |  | 6.5 |  |  | 6.8 |  |
| Gross profit on non-GAAP basis | $ | 73.2 |  |  | $ | 82.4 |  |  | $ | 347.2 |  |  | $ | 297.7 |  |
| Research and development on GAAP basis | $ | 35.4 |  |  | $ | 36.4 |  |  | $ | 148.3 |  |  | $ | 141.1 |  |
| Stock-based compensation | (2.8 | ) |  | (2.3 | ) |  | (11.6 | ) |  | (9.0 | ) |
| Other charges related to non-recurring activities | (0.3 | ) |  | (0.1 | ) |  | (1.0 | ) |  | (0.7 | ) |
| Research and development on non-GAAP basis | $ | 32.3 |  |  | $ | 34.0 |  |  | $ | 135.7 |  |  | $ | 131.4 |  |
| Selling, general and administrative on GAAP basis | $ | 26.0 |  |  | $ | 29.5 |  |  | $ | 110.2 |  |  | $ | 117.3 |  |
| Stock-based compensation | (3.5 | ) |  | (2.5 | ) |  | (13.6 | ) |  | (11.8 | ) |
| Other charges related to non-recurring activities | (2.0 | ) |  | (6.5 | ) |  | (9.1 | ) |  | (21.9 | ) |
| Amortization of acquired developed technologies | — |  |  | (0.1 | ) |  | (0.3 | ) |  | (0.4 | ) |
| Selling, general and administrative on non-GAAP basis | $ | 20.5 |  |  | $ | 20.4 |  |  | $ | 87.2 |  |  | $ | 83.2 |  |
| Income (loss) from operations on GAAP basis | $ | 3.9 |  |  | $ | 10.1 |  |  | $ | 47.6 |  |  | $ | 11.5 |  |
| Stock-based compensation | 7.8 |  |  | 6.0 |  |  | 32.7 |  |  | 26.9 |  |
| Other charges related to non-recurring activities | 5.3 |  |  | 6.6 |  |  | 25.2 |  |  | 30.1 |  |
| Amortization of acquired developed technologies | 1.4 |  |  | 1.8 |  |  | 6.8 |  |  | 7.2 |  |
| Restructuring and related charges | 2.0 |  |  | 3.5 |  |  | 12.0 |  |  | 7.4 |  |
| Income (loss) from operations on non-GAAP basis | $ | 20.4 |  |  | $ | 28.0 |  |  | $ | 124.3 |  |  | $ | 83.1 |  |
| Interest and other (expense) income, net on GAAP basis | $ | (1.8 | ) |  | $ | (0.1 | ) |  | $ | (3.2 | ) |  | $ | (1.2 | ) |
| Non-cash other income | (1.4 | ) |  | — |  |  | (1.7 | ) |  | — |  |
| Effective interest expense on convertible debt | 4.1 |  |  | — |  |  | 5.1 |  |  | — |  |
| Interest and other (expense) income, net on non-GAAP basis | $ | 0.9 |  |  | $ | (0.1 | ) |  | $ | 0.2 |  |  | $ | (1.2 | ) |
| Income (loss) before income taxes on GAAP basis | $ | (27.6 | ) |  | $ | 14.4 |  |  | $ | (59.8 | ) |  | $ | 9.7 |  |
| Stock-based compensation | 7.8 |  |  | 6.0 |  |  | 32.7 |  |  | 26.9 |  |
| Other charges related to non-recurring activities | 5.3 |  |  | 6.6 |  |  | 25.2 |  |  | 30.1 |  |
| Amortization of acquired developed technologies | 1.4 |  |  | 1.8 |  |  | 6.8 |  |  | 7.2 |  |
| Restructuring and related charges | 2.0 |  |  | 3.5 |  |  | 12.0 |  |  | 7.4 |  |
| Non-cash other income | (1.4 | ) |  | — |  |  | (1.7 | ) |  | — |  |
| Effective interest expense on convertible debt | 4.1 |  |  | — |  |  | 5.1 |  |  | — |  |
| Unrealized (gain) loss on derivative liability | 29.7 |  |  | (4.4 | ) |  | 104.2 |  |  | 0.6 |  |
| Income (loss) before income taxes on non-GAAP basis | $ | 21.3 |  |  | $ | 27.9 |  |  | $ | 124.5 |  |  | $ | 81.9 |  |

[0001633978-17-000058:8k_2_02:56]
| Provision for income taxes on GAAP basis | $ | 27.3 |  |  | $ | 0.1 |  |  | $ | 42.7 |  |  | $ | 0.4 |  |
| Impact of non-GAAP income tax (benefit) expense | (31.0 | ) |  | 2.4 |  |  | (40.6 | ) |  | 2.6 |  |
| Provision (benefit) for income taxes on non-GAAP basis | $ | (3.7 | ) |  | $ | 2.5 |  |  | $ | 2.1 |  |  | $ | 3.0 |  |
| Net income (loss) on GAAP basis | $ | (54.9 | ) |  | $ | 14.3 |  |  | $ | (102.5 | ) |  | $ | 9.3 |  |
| Stock-based compensation | 7.8 |  |  | 6.0 |  |  | 32.7 |  |  | 26.9 |  |
| Other charges related to non-recurring activities | 5.3 |  |  | 6.6 |  |  | 25.2 |  |  | 30.1 |  |
| Amortization of acquired developed technologies | 1.4 |  |  | 1.8 |  |  | 6.8 |  |  | 7.2 |  |
| Restructuring and related charges | 2.0 |  |  | 3.5 |  |  | 12.0 |  |  | 7.4 |  |
| Non-cash other income | (1.4 | ) |  | — |  |  | (1.7 | ) |  | — |  |
| Effective interest expense on convertible debt | 4.1 |  |  | — |  |  | 5.1 |  |  | — |  |
| Unrealized (gain) loss on derivative liability | 29.7 |  |  | (4.4 | ) |  | 104.2 |  |  | 0.6 |  |
| Impact of non-GAAP income tax (benefit) expense | 31.0 |  |  | (2.4 | ) |  | 40.6 |  |  | (2.6 | ) |
| Net income on non-GAAP basis | $ | 25.0 |  |  | $ | 25.4 |  |  | $ | 122.4 |  |  | $ | 78.9 |  |
| Net income per share on non-GAAP basis | $ | 0.39 |  |  | $ | 0.41 |  |  | $ | 1.94 |  |  | $ | 1.29 |  |
| Shares used in per share calculation - diluted on GAAP basis | 61.3 |  |  | 61.8 |  |  | 60.6 |  |  | 61.2 |  |
| Non-GAAP adjustment (a) | 2.5 |  |  | — |  |  | 2.5 |  |  | — |  |
| Shares used in per share calculation - diluted on non-GAAP basis | 63.8 |  |  | 61.8 |  |  | 63.1 |  |  | 61.2 |  |

[0001633978-17-000058:8k_2_02:57]
(a) This adjustment represents weighted-average potentially dilutive securities excluded from the computation of diluted net loss per share attributable to common stockholders on a GAAP basis because the effect would have been antidilutive. This adjustment amount is added for the computation of diluted net income per share on a non-GAAP basis as we had net income on a non-GAAP basis for all periods presented.

[0001633978-17-000058:8k_2_02:58]
LUMENTUM HOLDINGS INC.

[0001633978-17-000058:8k_2_02:59]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EBITDA

[0001633978-17-000058:8k_2_02:60]
(in millions)

[0001633978-17-000058:8k_2_02:61]
(unaudited)

[0001633978-17-000058:8k_2_02:62]
|  | Three Months Ended |  | Twelve Months Ended |
|  | July 1, 2017 |  | July 2, 2016 |  | July 1, 2017 |  | July 2, 2016 |
| GAAP net income (loss) | $ | (54.9 | ) |  | $ | 14.3 |  |  | $ | (102.5 | ) |  | $ | 9.3 |  |
| Interest and other expense (income), net | 1.8 |  |  | 0.1 |  |  | 3.2 |  |  | 1.2 |  |
| Provision for income taxes | 27.3 |  |  | 0.1 |  |  | 42.7 |  |  | 0.4 |  |
| Depreciation | 15.1 |  |  | 12.3 |  |  | 54.2 |  |  | 47.4 |  |
| Amortization | 1.4 |  |  | 1.8 |  |  | 6.8 |  |  | 7.2 |  |
| EBITDA | (9.3 | ) |  | 28.6 |  |  | 4.4 |  |  | 65.5 |  |
| Restructuring and related charges | 2.0 |  |  | 3.5 |  |  | 12.0 |  |  | 7.7 |  |
| Stock-based compensation | 7.8 |  |  | 6.0 |  |  | 32.7 |  |  | 26.9 |  |
| Other charges related to non-recurring activities | 5.3 |  |  | 6.6 |  |  | 25.2 |  |  | 29.8 |  |
| Unrealized (gain) loss on derivative liability | 29.7 |  |  | (4.4 | ) |  | 104.2 |  |  | 0.6 |  |
| Adjusted EBITDA | $ | 35.5 |  |  | $ | 40.3 |  |  | $ | 178.5 |  |  | $ | 130.5 |  |
