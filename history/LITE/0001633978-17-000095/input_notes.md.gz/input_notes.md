# LITE notes — 0001633978-17-000095


## lite:ConcentrationOfCreditAndOtherRisksAndAllowanceForDoubtfulAccountsPolicyTextBlock

[0001633978-17-000095:notes:1]
Concentration of Credit and Other Risks

[0001633978-17-000095:notes:2]
Financial instruments that potentially subject our business to concentration of credit risk consist primarily of cash and cash equivalents and trade receivables. We perform credit evaluations of our customers’ financial condition and generally do not require collateral from our customers. These evaluations require significant judgment and are based on a variety of factors including, but not limited to, current economic trends, payment history, bad debt write-off experience, and financial review of the customer.

[0001633978-17-000095:notes:3]
Although the Company deposits its cash with financial institutions that management believes are of high credit quality, its deposits, at times, may exceed federally insured limits. The Company’s investment portfolio consists of investment grade securities diversified amongst security types, industries, and issuers. The Company’s investment policy limits the amount of credit exposure in the investment portfolio to a maximum of 5% to any one issuer, except for Treasury and Government Agencies securities, and the Company believes no significant concentration risk exists with respect to these investments.

[0001633978-17-000095:notes:4]
We maintain an allowance for doubtful accounts for estimated losses resulting from the inability of our customers to make required payments. When we become aware that a specific customer is unable to meet their financial obligations, we record a specific allowance to reflect the level of credit risk in the customer’s outstanding receivable balance. In addition, we record additional allowances based on certain percentages of aged receivable balances. These percentages take into account a variety of factors including, but not limited to, current economic trends, payment history and bad debt write-off experience. We classify bad debt expenses as selling, general and administrative (“SG&A”) expense.

[0001633978-17-000095:notes:5]
We have significant trade receivables concentrated in the telecommunications industry. While our allowance for doubtful accounts balance is based on historical loss experience along with anticipated economic trends, unanticipated financial instability in the telecommunications industry could lead to higher than anticipated losses.

[0001633978-17-000095:notes:6]
During fiscal 2017, 2016 and 2015, several customers generated more than 10% of total net revenue. Refer to “Note 19. Operating Segments and Geographic Information” in the Notes to Consolidated Financial Statements.

[0001633978-17-000095:notes:7]
As of July 1, 2017 and July 2, 2016, one unique customer represented greater than 10% of total accounts receivable, net for each period.

[0001633978-17-000095:notes:8]
We rely on a limited number of suppliers for a number of key components contained in our products. We also rely on a limited number of significant independent contract manufacturers for the production of certain key components and subassemblies contained in our products.

[0001633978-17-000095:notes:9]
We generally use a rolling twelve month forecast based on anticipated product orders, customer forecasts, product order history and backlog to determine our materials requirements. Lead times for the parts and components that we order vary significantly and depend on factors such as the specific supplier, contract terms and demand for a component at a given time. If the forecast does not meet or if it exceeds actual demand, we may have excess or shortfalls of some materials and components, as well as excess inventory purchase commitments. We could experience reduced or delayed product shipments or incur additional inventory write-downs and cancellation charges or penalties, which would increase costs and could have a material adverse impact on our results of operations.


## lite:PropertyPlantandEquipmentNetTableTextBlock

[0001633978-17-000095:notes:10]
The components of property, plant and equipment, net were as follows (in millions):

[0001633978-17-000095:notes:11]
|  | July 1, 2017 |  | July 2, 2016 |
| Land | $ | 10.6 |  |  | $ | 5.9 |  |
| Buildings and improvement | 37.3 |  |  | 28.9 |  |
| Machinery and equipment | 461.1 |  |  | 378.5 |  |
| Furniture and fixtures and software | 35.8 |  |  | 32.2 |  |
| Leasehold improvements | 30.5 |  |  | 28.6 |  |
| Construction in progress | 84.6 |  |  | 44.1 |  |
|  | 659.9 |  |  | 518.2 |  |
| Less: Accumulated depreciation | (386.4 | ) |  | (334.8 | ) |
| Property, plant and equipment, net | $ | 273.5 |  |  | $ | 183.4 |  |


## lite:ScheduleOfOtherLiabilitiesCurrentTableTextBlock

[0001633978-17-000095:notes:12]
The components of other current liabilities were as follows (in millions):

[0001633978-17-000095:notes:13]
|  | July 1, 2017 |  | July 2, 2016 |
| Warranty accrual (1) | $ | 9.7 |  |  | $ | 2.8 |  |
| Restructuring accrual and related charges (2) | 3.8 |  |  | 5.5 |  |
| Deferred revenue | 6.9 |  |  | 2.7 |  |
| Others | 1.5 |  |  | 1.1 |  |
| Other current liabilities | $ | 21.9 |  |  | $ | 12.1 |  |

[0001633978-17-000095:notes:14]
(1) Refer to “Note 18. Commitments and Contingencies” in the Notes to Consolidated Financial Statements.

[0001633978-17-000095:notes:15]
(2) Refer to “Note 14. Restructuring and Related Charges” in the Notes to Consolidated Financial Statements.


## lite:ScheduleOfOtherLiabilitiesNoncurrentTableTextBlock

[0001633978-17-000095:notes:16]
The components of other non-current liabilities were as follows (in millions):

[0001633978-17-000095:notes:17]
|  | July 1, 2017 |  | July 2, 2016 |
| Asset retirement obligation | $ | 2.5 |  |  | $ | 2.3 |  |
| Pension and related accrual | 3.9 |  |  | 3.5 |  |
| Deferred rent | 3.3 |  |  | 1.6 |  |
| Restructuring accrual and related charges (2) | — |  |  | 0.2 |  |
| Unrecognized tax benefit | 10.5 |  |  | 0.1 |  |
| Other non-current liabilities | 4.8 |  |  | 1.4 |  |
| Other non-current liabilities | $ | 25.0 |  |  | $ | 9.1 |  |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001633978-17-000095:notes:18]
The following table summarizes our short-term investments by category (in millions):

[0001633978-17-000095:notes:19]
|  | As of July 1, 2017 |
|  | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposit | $ | 202.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 202.1 |  |
| Asset-backed securities | 26.1 |  |  | — |  |  | — |  |  | 26.1 |  |
| Corporate debt securities | 46.4 |  |  | — |  |  | — |  |  | 46.4 |  |
| Municipal bonds | 4.9 |  |  | — |  |  | — |  |  | 4.9 |  |
| Foreign government bonds | 1.0 |  |  | — |  |  | — |  |  | 1.0 |  |
| U.S. Treasury | 1.9 |  |  | — |  |  | — |  |  | 1.9 |  |
| Total short-term investments | $ | 282.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 282.4 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001633978-17-000095:notes:20]
Basis of Presentation

[0001633978-17-000095:notes:21]
On July 31, 2015, prior to the Separation, Viavi transferred substantially all of the assets and liabilities and operations of the CCOP segment and WaveReady product lines to Lumentum. Financial statements for periods prior to the Separation were prepared on a stand-alone basis and were derived from Viavi’s consolidated financial statements and accounting records. The Company prepared consolidated financial statements for the period from June 28, 2015 to August 1, 2015 where expenses were allocated to us using estimates that we consider to be a reasonable reflection of the utilization of services provided to, or benefits received by, us. From August 1, 2015 to July 2, 2016, the Company prepared consolidated financial statements as an independent stand-alone basis pursuant to the rules and regulations of the SEC and are in conformity with U.S. GAAP. In the opinion of management, these consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments, which are necessary for a fair statement of the consolidated financial statements for the periods shown. The results of operations for such periods are not necessarily indicative of the results expected for the full year or for any future periods.

[0001633978-17-000095:notes:22]
On August 1, 2015, Lumentum became an independent publicly-traded company through the distribution by JDS Uniphase (“JDSU”) to its stockholders of 80.1% of our outstanding common stock (the “Separation”). Each JDSU stockholder of record as of the close of business on July 27, 2015 received one share of Lumentum common stock for every five shares of JDSU common stock held on the record date. JDSU was renamed Viavi and at the time of the distribution retained ownership of 19.9% of Lumentum’s outstanding shares. Lumentum was incorporated in Delaware as a wholly owned subsidiary of Viavi on February 10, 2015 and is comprised of the former communications and commercial optical products (“CCOP”) segment and WaveReady product lines of Viavi. Lumentum’s Registration Statement on Form 10 was declared effective by the SEC on July 16, 2015. Lumentum’s common stock began trading “regular-way” under the ticker “LITE” on the NASDAQ stock market on August 4, 2015.

[0001633978-17-000095:notes:23]
The preparation of the consolidated financial statements in accordance with GAAP in the United States requires management to make estimates and assumptions that affect the amounts reported in our consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, inventory valuation, allocation methods and allocated expenses from Viavi, valuation of goodwill and other intangible assets, valuation of derivative liabilities, stock-based compensation, retirement and post-retirement plan assumptions, restructuring, warranty and accounting for income taxes.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001633978-17-000095:notes:24]
Note 6. Mergers and Acquisitions

[0001633978-17-000095:notes:25]
In February 2017, we completed the acquisition of a privately held company to enhance our manufacturing and vertical integration capabilities. We acquired all of the outstanding shares of the company.  In connection with the acquisition, we paid upfront cash consideration of $5.1 million, incurred liabilities of $2.7 million contingent upon the achievement of certain production targets being achieved within 36 months following the acquisition date, and retained $0.9 million of the purchase price as security for the seller’s indemnification obligations under the purchase agreement. This resulted in total purchase consideration of $8.7 million.

[0001633978-17-000095:notes:26]
The Company estimated the acquisition date fair value of the contingent consideration as the present value of the expected contingent payments, determined using a probabilistic approach. The Company is required to reassess the fair value of contingent payments on a periodic basis. The Company estimated the likelihood of meeting the production targets at 90% and recorded the fair value of such contingent consideration in accrued liabilities on the consolidated balance sheet as of July 1, 2017. This contingent consideration will result in a cash payment of $3.0 million, if and when the production targets are achieved.

[0001633978-17-000095:notes:27]
We recorded the assets acquired and liabilities assumed at their estimated fair values, with the difference between the fair value of the net assets acquired and the purchase consideration reflected in goodwill. The following table reflects the preliminary fair values of assets acquired and liabilities assumed (in millions):

[0001633978-17-000095:notes:28]
| Cash and cash equivalents | $ | — |  |
| Accounts receivable, net | 0.1 |  |
| Inventories | 1.9 |  |
| Prepayments and other current assets | 0.2 |  |
| Property, plant and equipment, net | 0.8 |  |
| Developed technology | 2.4 |  |
| Goodwill | 5.6 |  |
| Accounts payable | (0.4 | ) |
| Accrued expenses and payroll | (0.2 | ) |
| Deferred revenue | (1.1 | ) |
| Deferred tax liability | (0.6 | ) |
| Total value of assets acquired and liabilities assumed | $ | 8.7 |  |

[0001633978-17-000095:notes:29]
As of the acquisition date, developed technology of the acquired business had an estimated useful life of six years. The goodwill is primarily attributed to the synergies expected to be realized following the acquisition and the assembled workforce. Goodwill has been assigned to the Optical Communications segment and is not deductible for tax purposes.

[0001633978-17-000095:notes:30]
Results of operations of the business acquired have been included in our consolidated financial statements subsequent to the date of acquisition. Pro forma statements have not been presented because they are not material to our consolidated results of operations. The revenue and net income earned by the business acquired following the acquisition are not material to our consolidated results of operations.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001633978-17-000095:notes:31]
Note 1. Description of Business and Summary of Significant Accounting Policies

[0001633978-17-000095:notes:32]
Description of Business

[0001633978-17-000095:notes:33]
Lumentum (we, us, our or the Company) is an industry leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including Datacom and Telecom networking and commercial lasers for manufacturing, inspection and life-science applications. We are using our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be OEMs that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that our NEM customers assemble into communications networking systems, which they sell to network service providers or enterprises with their own networks. Similarly, many of our customers for our Lasers products incorporate our products into tools they produce, which are used for manufacturing processes by their customers.

[0001633978-17-000095:notes:34]
See “Note 3. Related Party Transactions” in the Notes to Consolidated Financial Statements regarding the relationships we had with Viavi.

[0001633978-17-000095:notes:35]
Fiscal Years

[0001633978-17-000095:notes:36]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Our fiscal 2017 ended on July 1, 2017 and was a 52-week year. Our fiscal 2016 ended on July 2, 2016 and was a 53-week year. Our fiscal 2015 ended on June 27, 2015 and was a 52-week year.

[0001633978-17-000095:notes:37]
Principles of Consolidation

[0001633978-17-000095:notes:38]
These audited consolidated financial statements include the accounts of the Company and its wholly-owned subsidiaries.

[0001633978-17-000095:notes:39]
All intra-company transactions within our business were eliminated. All material transactions between us and other businesses of Viavi prior to Separation were reflected as net transfers to and from Viavi as a component of financing activities in the consolidated statements of cash flows.

[0001633978-17-000095:notes:40]
Accounting Policies

[0001633978-17-000095:notes:41]
Fair Value of Financial Instruments

[0001633978-17-000095:notes:42]
We define fair value as the price that would be received from selling an asset, or paid to transfer a liability, in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities which are required to be recorded at fair value, we consider the principal or most advantageous market in which to transact and the market-based risk. We apply fair value accounting for all financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. The carrying amounts reported in the consolidated financial statements approximate the fair value for cash and cash equivalents, accounts receivable, accounts payable and accrued liabilities due to their short-term nature.

[0001633978-17-000095:notes:43]
Cash and Cash Equivalents

[0001633978-17-000095:notes:44]
We consider highly-liquid fixed income securities with original maturities of three months or less at the time of purchase to be cash equivalents. As of fiscal year ended July 1, 2017, cash and cash equivalents consist of certificates of deposit, commercial papers, and money market funds. As of fiscal year ended July 2, 2016, our cash and cash equivalents did not include any investments with original maturities of three months or less.

[0001633978-17-000095:notes:45]
Short-term Investments

[0001633978-17-000095:notes:46]
We classify our investments in debt as available-for-sale and record these investments at fair value. Investments with an original maturity of three months or less at the date of purchase are considered cash equivalents, while all other investments are classified as short-term based on management’s intent and ability to use the funds in current operations. Unrealized gains and losses are reported as a component of other comprehensive loss. Realized gains and losses are determined based on the specific identification method, and are reflected as interest and other income (expense), net in our Consolidated Statements of Operations. We regularly review our investment portfolio to identify and evaluate investments that have indicators of possible impairment. Factors considered in determining whether a loss is other-than-temporary include, but are not limited to: the length of time and extent a security’s fair value has been below its cost, the financial condition and near-term prospects of the investee, the credit quality of the security’s issuer, likelihood of recovery and our intent and ability to hold the security for a period of time sufficient to allow for any anticipated recovery in value. For our debt instruments, we also evaluate whether we have the intent to sell the security or it is more likely than not that we will be required to sell the security before recovery of its cost basis.

[0001633978-17-000095:notes:47]
Impairment of Marketable and Non-Marketable Securities

[0001633978-17-000095:notes:48]
We periodically review our marketable and non-marketable securities for impairment. If we conclude that any of these investments are impaired, we determine whether such impairment is other-than-temporary. We consider factors such as the duration, severity and the reason for the decline in value, the potential recovery period and whether we intend to sell. For marketable debt securities, we also consider whether (i) it is more likely than not that we will be required to sell the debt securities before recovery of their amortized cost basis, and (ii) the amortized cost basis cannot be recovered as a result of credit losses. If any impairment is considered other-than-temporary, we will write-down the security to its fair value.

[0001633978-17-000095:notes:49]
Basic and Diluted Net Loss per Common Share

[0001633978-17-000095:notes:50]
Basic income (loss) per share is computed by dividing net income (loss) available to common shareholders by the weighted average number of common shares outstanding during the reporting period. The weighted average number of shares is calculated by taking the number of shares outstanding and weighting them by the amount of time that they were outstanding.  Diluted earnings per share reflects the potential dilution that could occur if stock options, preferred stock, and other commitments to issue common stock were exercised or equity awards vest resulting in the issuance of common stock that could share in the earnings of the Company.

[0001633978-17-000095:notes:51]
Diluted loss per share is the same as basic loss per share during periods where net losses are incurred since the inclusion of the potential common stock equivalents would be anti-dilutive as a result of the net loss.

[0001633978-17-000095:notes:52]
Inventory Valuation

[0001633978-17-000095:notes:53]
Inventory is valued at standard cost, which approximates actual cost computed on a first-in, first-out basis, not in excess of net realizable value. We assess the value of our inventory on a quarterly basis and write down those inventories which are obsolete or in excess of our forecasted usage to their estimated realizable value. Our estimates of realizable value are based upon our analysis and assumptions including, but not limited to, forecasted sales levels by product, expected product lifecycle, product development plans and future demand requirements. Our product line management personnel play a key role in our excess review process by providing updated sales forecasts, managing product transitions and working with manufacturing to minimize excess inventory. If actual market conditions are less favorable than our forecasts or actual demand from our customers is lower than our estimates, we may be required to record additional inventory write-downs. If actual market conditions are more favorable than anticipated, inventory previously written down may be sold, resulting in lower cost of sales and higher income from operations than expected in that period.

[0001633978-17-000095:notes:54]
Property, Plant and Equipment

[0001633978-17-000095:notes:55]
Property, plant and equipment are stated at cost. Depreciation is computed by the straight-line method generally over the following estimated useful lives of the assets: 10 to 50 years for building and improvements, 3 to 5 years for machinery and equipment, and 2 to 5 years for furniture, fixtures, software and office equipment. Leasehold improvements are amortized using the straight-line method over the shorter of the estimated useful lives of the assets or the term of the lease.

[0001633978-17-000095:notes:56]
Goodwill

[0001633978-17-000095:notes:57]
Goodwill represents the excess of the purchase price of an acquired business over the fair value of the identifiable assets acquired and liabilities assumed. We test for impairment of goodwill on an annual basis in the fourth quarter and at any other time when events occur or circumstances indicate that the carrying amount of goodwill may not be recoverable. Refer to “Note 13. Goodwill and Other Intangible Assets” in the Notes to Consolidated Financial Statements.

[0001633978-17-000095:notes:58]
An entity has the option to first assess qualitative factors to determine whether it is necessary to perform the two-step quantitative goodwill impairment test. If an entity determines that as a result of the qualitative assessment that it is more likely than not (i.e., greater than 50% likelihood) that the fair value of a reporting unit is less than its carrying amount, then the quantitative test is required. Otherwise, no further testing is required. The two-step quantitative goodwill impairment test requires us to estimate the fair value of our reporting units. If the carrying value of a reporting unit exceeds its fair value, the goodwill of that reporting unit is potentially impaired and we proceed to step two of the impairment analysis. In step two of the analysis, we measure and record an impairment loss equal to the excess of the carrying value of the reporting unit’s goodwill over its implied fair value, if any.

[0001633978-17-000095:notes:59]
Application of the goodwill impairment test requires judgments, including: identification of the reporting units, assigning assets and liabilities to reporting units, assigning goodwill to reporting units, a qualitative assessment to determine whether there are any impairment indicators, and determining the fair value of each reporting unit. We estimate the fair value of a reporting unit using the market approach, which estimates the fair value based on comparable market prices. Significant estimates in the market approach include: identifying similar companies with comparable business factors such as size, growth, profitability, risk and return on investment, and assessing comparable revenue and operating income multiples in estimating the fair value of the reporting unit.

[0001633978-17-000095:notes:60]
We base our estimates on historical experience and on various assumptions about the future that we believe are reasonable based on available information. Unanticipated events and circumstances may occur that affect the accuracy of our assumptions, estimates and judgments. For example, if the price of our common stock were to significantly decrease combined with other adverse changes in market conditions, thus indicating that the underlying fair value of our reporting units may have decreased, we might be required to reassess the value of our goodwill in the period such circumstances were identified.

[0001633978-17-000095:notes:61]
Intangible Assets

[0001633978-17-000095:notes:62]
Intangible assets consist primarily of intangible assets purchased  through acquisitions. Purchased intangible assets primarily include acquired developed technologies (developed and core technology). Intangible assets are amortized using the straight-line method over the estimated economic useful lives of the assets, which is the period during which expected cash flows support the fair value of such intangible assets.

[0001633978-17-000095:notes:63]
Long-lived Asset Valuation (Property, Plant and Equipment and Intangible Assets Subject to Amortization)

[0001633978-17-000095:notes:64]
We test long-lived assets for recoverability, at the asset group level, when events or changes in circumstances indicate that their carrying amount may not be recoverable. Circumstances which could trigger a review include, but are not limited to: significant decreases in the market price of the asset, significant adverse changes in the business climate or legal factors, accumulation of costs significantly in excess of the amount originally expected for the acquisition or construction of the asset, current period cash flow or operating losses combined with a history of losses or a forecast of continuing losses associated with the use of the asset, or current expectation that the asset will more likely than not be sold or disposed significantly before the end of its estimated useful life.

[0001633978-17-000095:notes:65]
Recoverability is assessed based on the difference between the carrying amount of the asset and the sum of the undiscounted cash flows expected to result from the use and the eventual disposal of the asset. An impairment loss is recognized when the carrying amount is not recoverable and exceeds fair value.

[0001633978-17-000095:notes:66]
Pension Benefits

[0001633978-17-000095:notes:67]
The funded status of our retirement-related benefit plan is measured as the difference between the fair value of plan assets and the benefit obligation at fiscal year end, the measurement date. The funded status of an underfunded benefit plan, of which the fair value of plan assets is less than the benefit obligation, is recognized as a non-current net pension liability in the consolidated balance sheets unless the fair value of plan assets is not sufficient to cover the expected payments to be made over the next year (or operating cycle, if longer) from the measurement date. For defined benefit pension plans, the benefit obligation is the projected benefit obligation (“PBO”) which represents the actuarial present value of benefits expected to be paid upon retirement.

[0001633978-17-000095:notes:68]
Net periodic pension cost (income) (“NPPC”) is recorded in the consolidated statements of operations and includes service cost, interest cost, expected return on plan assets, amortization of prior service cost and (gains) losses previously recognized as a component of accumulated other comprehensive income. Service cost represents the actuarial present value of participant benefits attributed to services rendered by employees in the current year. Interest cost represents the time value of money cost associated with the passage of time. (Gains) losses arise as a result of differences between actual experience and assumptions or as a result of changes in actuarial assumptions. Prior service cost (credit) represents the cost of benefit improvements attributable to prior service granted in plan amendments. (Gains) losses and prior service cost (credit) that arise during the current year are first recognized as a component of accumulated other comprehensive income in the consolidated balances sheets, net of tax. Prior service cost is amortized as a component of NPPC over the average remaining service period of active plan participants starting at the date the plan amendment is adopted. Deferred actuarial (gains) losses are subsequently recognized as a component of NPPC if they exceed the greater of ten percent of PBO or the fair value of plan assets, with the excess amortized over the average remaining service period of active plan participants.

[0001633978-17-000095:notes:69]
The measurement of the benefit obligation and NPPC is based on our estimates and actuarial valuations, provided by third-party actuaries, which are approved by management. These valuations reflect the terms of the plans and use participant-specific information such as compensation, age and years of service, as well as certain assumptions, including estimates of discount rates, expected return on plan assets, rate of compensation increases, and mortality rates. We evaluate these assumptions annually at a minimum. In estimating the expected return on plan assets, we consider historical returns on plan assets, adjusted for forward-looking considerations, inflation assumptions and the impact of the active management of the plan’s invested assets.

[0001633978-17-000095:notes:70]
Foreign Currency Translation

[0001633978-17-000095:notes:71]
Assets and liabilities of non-U.S. subsidiaries that operate in a local currency environment, where that local currency is the functional currency, are translated into U.S. dollars at exchange rates in effect at the balance sheet date, with the resulting translation adjustments directly recorded to a separate component of accumulated other comprehensive income, within the consolidated statements of redeemable convertible preferred stock, stockholders equity, and invested equity. Income and expense accounts are translated at the average exchange rates during the year. Gains and losses from re-measurement of monetary assets and liabilities denominated in currencies other than the respective functional currencies are included in the consolidated statements of operations as a component of interest and other income (expense), net. Net gains or (losses) resulting from foreign currency transactions, including hedging gains and losses that were previously allocated to us by Viavi, are reported in interest and other income (expense), net and was $0.6 million, $(0.9) million and $(0.3) million during fiscal 2017, 2016 and 2015, respectively.

[0001633978-17-000095:notes:72]
Revenue Recognition

[0001633978-17-000095:notes:73]
We recognize revenue when all four revenue recognition criteria have been met: (i) persuasive evidence of an arrangement exists, (ii) the product has been delivered or the service has been rendered, (iii) the price is fixed or determinable and (iv) collection is reasonably assured. Revenue from product sales is recorded when all of the foregoing conditions are met and risk of loss and title passes to the customer. Our products typically include a warranty and the estimated cost of product warranty claims, based on historical experience, is recorded at the time the sale is recognized. Sales to customers are generally not subject to price protection or return rights. The majority of our sales are made to OEMs, distributors, resellers and end-users.

[0001633978-17-000095:notes:74]
Stock-based Compensation

[0001633978-17-000095:notes:75]
Compensation expense related to stock-based transactions, including employee and director restricted stock units (“RSUs”) is measured and recognized in the financial statements based on fair value at the grant date. The fair value of time-based RSUs is based on the closing market price of our common stock on the grant date of the award. The stock-based compensation expense is recognized, net of forfeitures using a straight-line basis over the requisite service periods of the awards, which is generally three to four years.

[0001633978-17-000095:notes:76]
We estimate the expected forfeiture rate and recognize only expense for those shares expected to vest. When estimating forfeitures, we consider historical forfeiture experiences as well as our expectation about future terminations and workforce reduction programs. The estimated forfeiture rate is trued up to the actual forfeiture rate as the equity awards vest. The total fair value of the equity awards, net of forfeitures, is recorded on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period, except for performance stock units which are amortized on a graded vesting method.

[0001633978-17-000095:notes:77]
We estimate the fair value of the rights to acquire stock under our Employee Stock Purchase Plan (“ESPP”) using the Black-Scholes option pricing formula. Our ESPP provides for consecutive six-month offering periods. We recognize such compensation expense on a straight-line basis over the requisite service period. We calculate the volatility factor based on our historical stock prices.

[0001633978-17-000095:notes:78]
We account for the fair value of RSUs using the closing market price of our common stock on the date of grant. For new-hire grants, RSUs generally vest ratably on an annual basis over four years. For annual refresh grants, RSUs generally vest ratably on an annual, or combination of annual and quarterly, basis over three years.

[0001633978-17-000095:notes:79]
We account for the fair value of performance stock units (“PSUs”) using the closing market price of our common stock on the date of grant. We begin recognizing compensation expense when we conclude that it is probable that the performance conditions will be achieved. We reassess the probability of vesting at each reporting period and adjust our compensation cost based on this probability assessment.

[0001633978-17-000095:notes:80]
Income Taxes

[0001633978-17-000095:notes:81]
In accordance with the authoritative guidance on accounting for income taxes, we recognize income taxes using an asset and liability approach. This approach requires the recognition of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in our consolidated financial statements or tax returns. The measurement of current and deferred taxes is based on provisions of the enacted tax law, and the effects of future changes in tax laws or rates are not anticipated.

[0001633978-17-000095:notes:82]
The authoritative guidance provides for recognition of deferred tax assets if the realization of such deferred tax assets is more likely than not to occur based on an evaluation of both positive and negative evidence and the relative weight of the evidence. With the exception of certain international jurisdictions, we have determined that at this time it is more likely than not that our deferred tax assets will not be realized in the future.  This determination is primarily due to our history of losses which impacts our ability to benefit from our deferred tax assets. Accordingly, we have established a valuation allowance for such deferred tax assets. If there is a change in our ability to realize our deferred tax assets for which a valuation allowance has been established, then our tax provision may decrease in the period in which we determine that realization is more likely than not.

[0001633978-17-000095:notes:83]
We are subject to income tax audits by the respective tax authorities of the jurisdictions in which we operate. The determination of our income tax liabilities in each of these jurisdictions requires the interpretation and application of complex, and sometimes uncertain, tax laws and regulations. The authoritative guidance on accounting for income taxes prescribes both recognition and measurement criteria that must be met for the benefit of a tax position to be recognized in the financial statements.  If a tax position taken, or expected to be taken, in a tax return does not meet such recognition or measurement criteria, an unrecognized tax benefit liability is recorded.  If we ultimately determine that an unrecognized tax benefit liability is no longer necessary, we reverse the liability and recognize a tax benefit in the period in which it is determined that the unrecognized tax benefit liability is no longer necessary.

[0001633978-17-000095:notes:84]
The recognition and measurement of current taxes payable or refundable and deferred tax assets and liabilities requires that we make certain estimates and judgments. Changes to these estimates or a change in judgment may have a material impact on our tax provision in a future period.

[0001633978-17-000095:notes:85]
Restructuring Accrual

[0001633978-17-000095:notes:86]
Costs associated with restructuring activities are recognized when they are incurred. However, in the case of leases, the expense is estimated and accrued when the property is vacated. Given the significance of, and the timing of the execution of such activities, this process is complex and involves periodic reassessments of estimates made from the time the property was vacated, including evaluating real estate market conditions for expected vacancy periods and sub-lease income. We recognize a liability for post-employment benefits for workforce reductions related to restructuring activities when payment is probable and the amount is reasonably estimable. We continually evaluate the adequacy of the remaining liabilities under our restructuring initiatives. Although we believe that these estimates accurately reflect the costs of our restructuring plans, actual results may differ, thereby requiring us to record additional provisions or reverse a portion of such provisions. Refer to “Note 14. Restructuring and Related Charges” in the Notes to Consolidated Financial Statements.

[0001633978-17-000095:notes:87]
Derivative Liabilities

[0001633978-17-000095:notes:88]
The Series A Preferred Stock issued by our subsidiary Lumentum Inc. is redeemable at the option of the holder after five years and classified as non-controlling interest redeemable convertible preferred stock in our consolidated balance sheet and is measured at its redemption value. The Series A Preferred Stock conversion feature is bifurcated from the Series A Preferred Stock and accounted for separately as a derivative liability. In March 2017, we issued $450.0 million in aggregate principal amount of 0.25% Convertible Senior Notes due in March 2024 (the “2024 Notes”), unless earlier repurchased by us or converted pursuant to their terms. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability.

[0001633978-17-000095:notes:89]
On a quarterly basis, the derivative liabilities are marked to market based on the fair value of the conversion features, with the resulting income or loss recorded as unrealized loss on derivative liabilities on our consolidated statements of operations. The determination of fair value includes various inputs, including volatility and interest rate assumptions. However, the change in the fair value of our common stock has the largest impact to the fair value of the derivatives. Unrealized loss on derivative liabilities amounted to $104.2 million and $0.6 million for the fiscal year ended July 1, 2017 and July 2, 2016, respectively.

[0001633978-17-000095:notes:90]
Business Combinations

[0001633978-17-000095:notes:91]
We allocate the fair value of purchase consideration to the tangible assets acquired, liabilities assumed and intangible assets acquired based on their estimated fair values. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. When determining the fair values of assets acquired and liabilities assumed, management makes significant estimates and assumptions, especially with respect to intangible assets. Critical estimates in valuing certain intangible assets include, but are not limited to, future expected cash flows from customer relationships and acquired developed technology and discount rates. Management’s estimates of fair value are based upon assumptions believed to be reasonable, but which are inherently uncertain and unpredictable and, as a result, actual results may differ materially from estimates. Other estimates associated with the accounting for acquisitions may change as additional information becomes available regarding the assets acquired and liabilities assumed.

[0001633978-17-000095:notes:92]
Warranty

[0001633978-17-000095:notes:93]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We estimate the costs of our warranty obligations based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise.

[0001633978-17-000095:notes:94]
Shipping and Handling Costs

[0001633978-17-000095:notes:95]
We record shipping and handling costs related to revenue transactions within cost of sales as a period cost for all periods presented.

[0001633978-17-000095:notes:96]
Research and Development (“R&D”) Expense

[0001633978-17-000095:notes:97]
Costs related to R&D, which primarily consists of labor and benefits, supplies, facilities, consulting and outside service fees, are charged to expense as incurred.

[0001633978-17-000095:notes:98]
Loss Contingencies

[0001633978-17-000095:notes:99]
We are subject to the possibility of various loss contingencies arising in the ordinary course of business. We consider the likelihood of loss or impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss in determining loss contingencies. An estimated loss is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate current information available to determine whether such accruals should be adjusted and whether new accruals are required.

[0001633978-17-000095:notes:100]
Asset Retirement Obligations (“ARO”)

[0001633978-17-000095:notes:101]
Our ARO are legal obligations associated with the retirement of long-lived assets pertaining to leasehold improvements. These liabilities are initially recorded at fair value and the related asset retirement costs are capitalized by increasing the carrying amount of the related assets by the same amount as the liability. Asset retirement costs are subsequently depreciated over the useful lives of the related assets. Subsequent to initial recognition, we record period-to-period changes in the ARO liability resulting from the passage of time and revisions to either the timing or the amount of the original estimate of undiscounted cash flows. We derecognize ARO liabilities when the related obligations are settled.


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001633978-17-000095:notes:102]
Note 8. Cash, Cash Equivalents, and Short-term Investments

[0001633978-17-000095:notes:103]
Cash, cash equivalents and short-term investments

[0001633978-17-000095:notes:104]
The following table summarizes our cash and cash equivalents by category (in millions):

[0001633978-17-000095:notes:105]
|  | July 1, 2017 |  | July 2, 2016 |
| Cash and cash equivalents: |  |  |  |
| Cash | $ | 201.3 |  |  | $ | 157.1 |  |
| Certificates of deposit | 52.1 |  |  | — |  |
| Commercial paper | 14.7 |  |  | — |  |
| Money market funds | 4.8 |  |  | — |  |
| Total cash and cash equivalents | $ | 272.9 |  |  | $ | 157.1 |  |

[0001633978-17-000095:notes:106]
For fiscal 2017, we did not incur significant unrealized gains or losses on our short-term investments.

[0001633978-17-000095:notes:107]
We use the specific-identification method to determine any realized gains or losses from the sale of our short-term investments classified as available-for-sale. For fiscal 2017, we did not realize significant gross gains or losses from the sale of our short-term investments classified as available-for-sale.

[0001633978-17-000095:notes:108]
The following table classifies our investments in debt securities by contractual maturities (in millions):

[0001633978-17-000095:notes:109]
|  | As of July 1, 2017 |
| Due in 1 year | $ | 231.6 |  |
| Due in 1 year through 5 years | 48.4 |  |
| Due in 5 years through 10 years | 1.8 |  |
| Due after 10 years | 0.6 |  |
|  | $ | 282.4 |  |

[0001633978-17-000095:notes:110]
All available-for-sale securities have been classified as current, based on management’s intent and ability to use the funds in current operations.


## us-gaap:ChangesInProjectedBenefitObligationsFairValueOfPlanAssetsAndFundedStatusOfPlanTableTextBlock

[0001633978-17-000095:notes:111]
The change in the benefit obligations and plan assets of the pension and benefits plan were as follows (in millions):

[0001633978-17-000095:notes:112]
|  | Pension Benefit Plan |
|  | 2017 |  | 2016 |
| Change in benefit obligation: |  |  |  |
| Benefit obligation at beginning of year | $ | 8.2 |  |  | $ | 6.7 |  |
| Service cost | 0.6 |  |  | 0.4 |  |
| Interest cost | — |  |  | 0.1 |  |
| Plan participants’ contribution | 0.5 |  |  | 0.4 |  |
| Actuarial (gains)/losses | 0.5 |  |  | 0.9 |  |
| Benefits paid | 0.9 |  |  | 0.1 |  |
| Foreign exchange impact | 0.3 |  |  | (0.4 | ) |
| Benefit obligation at end of year | $ | 11.0 |  |  | $ | 8.2 |  |
| Change in plan assets: |  |  |  |
| Fair value of plan assets at beginning of year | $ | 4.7 |  |  | $ | 4.6 |  |
| Actual return on plan assets | 0.1 |  |  | (0.6 | ) |
| Employer contribution | 0.8 |  |  | 0.4 |  |
| Plan participants’ contribution | 0.5 |  |  | 0.4 |  |
| Benefits paid | 0.9 |  |  | 0.1 |  |
| Foreign exchange impact | 0.1 |  |  | (0.2 | ) |
| Fair value of plan assets at end of year | $ | 7.1 |  |  | $ | 4.7 |  |
| Funded status | $ | (3.9 | ) |  | $ | (3.5 | ) |
| Accumulated benefit obligation | $ | 8.2 |  |  | $ | 6.7 |  |


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001633978-17-000095:notes:113]
Note 18. Commitments and Contingencies

[0001633978-17-000095:notes:114]
Operating Leases

[0001633978-17-000095:notes:115]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2026. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. As of July 1, 2017 the future minimum annual lease payments under non-cancellable operating leases were as follows (in millions):

[0001633978-17-000095:notes:116]
| 2018 | $ | 11.4 |  |
| 2019 | 11.3 |  |
| 2020 | 8.4 |  |
| 2021 | 4.6 |  |
| 2022 | 3.1 |  |
| Thereafter | 4.0 |  |
| Total minimum operating lease payments | $ | 42.8 |  |

[0001633978-17-000095:notes:117]
Included in the future minimum lease payments table above is $0.3 million related to lease commitments in connection with our restructuring and related activities. Refer to “Note 14. Restructuring and Related Charges” in the Notes to Consolidated Financial Statements.

[0001633978-17-000095:notes:118]
Rental expense relating to building and equipment was $10.1 million, $7.4 million, and $9.1 million in fiscal 2017, 2016 and 2015, respectively.

[0001633978-17-000095:notes:119]
Acquisition Contingencies

[0001633978-17-000095:notes:120]
The Company incurred liabilities in the amount of $3.6 million in connection with the fiscal 2017 acquisition. The amount of $2.7 million is payable in 36 months following the acquisition date contingent upon meeting certain production targets. The Company retained $0.9 million of the purchase price to cover any potential liabilities under the representations, warranties and indemnifications included in the purchase agreement, the amount is payable at the 15 month anniversary of the close date. Refer to “Note 6. Mergers and Acquisitions”.

[0001633978-17-000095:notes:121]
0.25% Convertible Senior Notes due 2024

[0001633978-17-000095:notes:122]
The future interest and principal payments related to the 2024 Notes are as follows as of July 1, 2017:

[0001633978-17-000095:notes:123]
| 2018 | $ | 1.2 |  |
| 2019 | 1.1 |  |
| 2020 | 1.1 |  |
| 2021 | 1.1 |  |
| 2022 | 1.1 |  |
| Thereafter | 451.7 |  |
| Total 2024 Notes payments | $ | 457.3 |  |

[0001633978-17-000095:notes:124]
Purchase Obligations

[0001633978-17-000095:notes:125]
Purchase obligations of $146.2 million as of July 1, 2017, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001633978-17-000095:notes:126]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with such vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

[0001633978-17-000095:notes:127]
Product Warranties

[0001633978-17-000095:notes:128]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, product component or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001633978-17-000095:notes:129]
The following table presents the changes in our warranty reserve during fiscal 2017 and fiscal 2016 (in millions):

[0001633978-17-000095:notes:130]
|  | Years Ended |
|  | July 1, 2017 |  | July 2, 2016 |
| Balance as of beginning of year | $ | 2.8 |  |  | $ | 2.8 |  |
| Provision for warranty | 14.9 |  |  | 2.9 |  |
| Utilization of reserve | (8.0 | ) |  | (2.9 | ) |
| Balance as of year end | $ | 9.7 |  |  | $ | 2.8 |  |

[0001633978-17-000095:notes:131]
Environmental Liabilities

[0001633978-17-000095:notes:132]
Our research and development (“R&D”), manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental, product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001633978-17-000095:notes:133]
In connection with the Separation, we agreed to indemnify Viavi for any liability associated with contamination from past operations at all properties transferred to us from Viavi, to the extent the resulting issues primarily related to our business.

[0001633978-17-000095:notes:134]
Legal Proceedings

[0001633978-17-000095:notes:135]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. Were an unfavorable final outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the effect becomes reasonably estimable.

[0001633978-17-000095:notes:136]
Indemnifications

[0001633978-17-000095:notes:137]
In the normal course of business, the Company enters into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against the Company in the future and the Company may record charges in the future as a result of these indemnification obligations. As of July 1, 2017, the Company did not have any material indemnification claims that were probable or reasonably possible.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001633978-17-000095:notes:138]
Note 5. Accumulated Other Comprehensive Income (Loss)

[0001633978-17-000095:notes:139]
Our accumulated other comprehensive income (loss) primarily consists of the accumulated net unrealized gains or losses on foreign currency translation adjustments and defined benefit obligation. We did not incur significant unrealized gains or losses on our short-term investments in the fiscal 2017.

[0001633978-17-000095:notes:140]
At July 1, 2017 and July 2, 2016, balances for the components of accumulated other comprehensive income (loss) were as follows (in millions):

[0001633978-17-000095:notes:141]
|  | Foreign currency translation adjustments |  | Defined benefit obligation, net of tax (1) |  | Total |
| Beginning balance as of July 2, 2016 | $ | 11.7 |  |  | $ | (2.3 | ) |  | $ | 9.4 |  |
| Other comprehensive loss | (1.2 | ) |  | (0.8 | ) |  | (2.0 | ) |
| Ending balance as of July 1, 2017 | $ | 10.5 |  |  | $ | (3.1 | ) |  | $ | 7.4 |  |

[0001633978-17-000095:notes:142]
(1) Refer to “Note 17. Employee Benefit Plans” in the Notes to Consolidated Financial Statements on the computation of net periodic cost for pension plans.


## us-gaap:ConvertibleDebtTableTextBlock

[0001633978-17-000095:notes:143]
As of July 1, 2017, the 2024 Notes consisted of the following (in millions):

[0001633978-17-000095:notes:144]
| Liability component: | July 1, 2017 |
| Principal | $ | 450.0 |  |
| Unamortized debt discount | (132.5 | ) |
| Net carrying amount of the liability component | $ | 317.5 |  |
| Carrying amount of the embedded derivative liability | $ | — |  |


## us-gaap:DebtDisclosureTextBlock

[0001633978-17-000095:notes:145]
Note 11. Convertible Senior Notes

[0001633978-17-000095:notes:146]
On March 8, 2017, the Company issued $450 million aggregate principal amount of 0.25% Convertible Senior Notes due in 2024 (the “2024 Notes”), in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank National Association, as trustee (the “Indenture”).  The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by the Company.

[0001633978-17-000095:notes:147]
The 2024 Notes will bear interest at a rate of 0.25% per year.  Interest on the 2024 Notes is payable semi-annually in arrears on March 15 and September 15 of each year, beginning on September 15, 2017. The 2024 Notes will mature on March 15, 2024, unless earlier repurchased by the Company or converted pursuant to their terms.

[0001633978-17-000095:notes:148]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share, a 132.5% premium to the fair market value at the date of issuance. Prior to the close of business on the business day immediately preceding December 15, 2023, the 2024 Notes will be convertible only under the following circumstances: (1) during any fiscal quarter commencing after July 1, 2017 (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price on each applicable trading day; (2) during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of notes for each trading day of such measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the applicable conversion rate on each such trading day; or (3) upon the occurrence of specified corporate events. On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their notes at any time. In addition, upon the occurrence of a make-whole fundamental change, the Company will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert its 2024 Notes in connection with such make-whole fundamental change.

[0001633978-17-000095:notes:149]
Until such time as the Company satisfies the Tax Matters Agreement settlement condition (“TMA settlement condition”, as described below), the Company is required to satisfy its conversion obligation solely in cash.  However, if the Company has satisfied the TMA share settlement condition, the Company may satisfy its conversion obligation in cash, shares of the Company’s common stock or a combination of cash and shares of the Company’s common stock, at the Company’s election.

[0001633978-17-000095:notes:150]
The TMA settlement condition can be met by the Company either receiving (i) an opinion of a nationally recognized accounting firm selected by the Company and Viavi by mutual consent to the effect that the issuance of the 2024 Notes and the shares of Common Stock upon conversion of the 2024 Notes (assuming for each such purpose that Physical Settlement applies and the maximum number of Additional Shares have been added to the Conversion Rate) does not result in the imposition or incurrence of certain taxes upon Viavi, the Company, their respective Affiliates or any third party to which any of Viavi, the Company or their respective Affiliates is or may become liable in connection with the failure of the Separation to qualify as a transaction in which no income, gain or loss is recognized under Section 355 and Section 368(A)(1)(D) of the Internal Revenue Code of 1986, as amended (the “Code”) (including any tax resulting from the application of Section 355(d) or Section 355(e) of the Code to the Separation but only to the extent such tax is not reduced by a tax asset) or (ii) the consent of Viavi to the issuance of the 2024 Notes and the shares of Common Stock upon conversion of the 2024 Notes (assuming for each such purpose that Physical Settlement applies and the maximum number of Additional Shares have been added to the Conversion Rate), in each case, in a manner that the Company has determined satisfies the requirements of the Tax Matters Agreement with Viavi. All capitalized terms not previously defined have the definitions set forth in the Indenture.

[0001633978-17-000095:notes:151]
The Company may not redeem the 2024 Notes prior to their maturity date and no sinking fund is provided for the 2024 Notes. Upon the occurrence of a fundamental change, holders may require the Company to repurchase all or a portion of their 2024 Notes for cash at a price equal to 100% of the principal amount of the 2024 Notes to be repurchased, plus any accrued and unpaid interest.

[0001633978-17-000095:notes:152]
The Company considered the features embedded in the 2024 Notes other than the conversion feature, including the holders’ put feature, the Company’s call feature, and the make-whole feature, and concluded that they are not required to be bifurcated and accounted for separately from the host debt instrument.

[0001633978-17-000095:notes:153]
Prior to TMA settlement, because the Company can only settle the 2024 Notes in cash, the Company determined that the conversion feature meets the definition of a derivative liability.  The Company separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. The Company incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. The Company amortizes the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes is 5.4% per year. As of July 1, 2017, the remaining debt discount amortization period was 80 months.

[0001633978-17-000095:notes:154]
The Company satisfied the TMA settlement conditions on June 29, 2017. As such, the value of the conversion option will no longer be marked to market, and is reclassified to additional paid-in capital within stockholders’ equity on our consolidated balance sheet. The value of the conversion option at the time of issuance will be treated as an original issue discount for purposes of accounting for the debt component of the notes. The debt component will accrete up to the principal amount over the expected term of the debt. These accounting standards do not affect the actual amount we are required to repay, and the amount shown in the table below for the notes is the aggregate principal amount of the notes and does not reflect the debt discount we will be required to recognize.

[0001633978-17-000095:notes:155]
The following table sets forth interest expense information related to the 2024 Notes:

[0001633978-17-000095:notes:156]
| (in millions, except percentages) | July 1, 2017 |
| Contractual interest expense | $ | 0.4 |  |
| Amortization of the debt discount | 5.1 |  |
| Total interest cost | $ | 5.5 |  |
| Effective interest rate on the liability component | 5.4 | % |

[0001633978-17-000095:notes:157]
The Company has the ability and intent to settle the $450 million face value of the debt in cash. Therefore, the Company will use the treasury stock method for calculating the dilutive impact of the debt. The 2024 Notes will have no impact to diluted earnings per share until the average price of our common stock exceeds the conversion price. The Notes are required to be excluded from the calculation of diluted earnings per share, as they would be anti-dilutive.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001633978-17-000095:notes:158]
Note 12. Derivative Liabilities

[0001633978-17-000095:notes:159]
We estimate the fair value of the embedded derivatives for the Series A Preferred Stock and the 2024 Notes  using the binomial lattice model. We applied the lattice model to value the embedded derivatives using a “with-and-without method”, where the value of the Series A Preferred Stock or the 2024 Notes, including the embedded derivative, is defined as the “with”, and the value of the Series A Preferred Stock or the 2024 Notes, excluding the embedded derivative, is defined as the “without”. The lattice model requires the following inputs: (i) the Company’s common stock price; (ii) conversion price; (iii) term; (iv) yield; (v) recovery rate for the Series A Preferred Stock; (vi) estimated stock volatility; and (vii) risk-free rate. The fair value of the embedded derivative was determined using level 3 inputs under the fair value hierarchy (unobservable inputs). Changes in the inputs into this valuation model have a material impact in the estimated fair value of the embedded derivative. For example, a decrease (increase) in the stock price and the volatility results in a decrease (increase) in the estimated fair value of the embedded derivative. The changes in the fair value of the bifurcated embedded derivatives for the Series A Preferred Stock and the 2024 Notes are primarily related to the change in the price of the Company’s underlying common stock and are reflected in the consolidated statements of operations as “Unrealized loss on derivative liabilities”.  Unrealized loss on derivative liabilities amounted to $104.2 million and $0.6 million for the fiscal year ended July 1, 2017 and July 2, 2016, respectively.

[0001633978-17-000095:notes:160]
The following table provides a reconciliation of the fair value of the embedded derivative for the Series A Preferred Stock measured by significant unobservable inputs (Level 3) for the years ended July 1, 2017 and July 2, 2016:

[0001633978-17-000095:notes:161]
| (in millions) | July 1, 2017 |  | July 2, 2016 |
| Balance as of beginning of period | $ | 10.3 |  |  | $ | — |  |
| Issuance of the embedded derivative for the series A preferred stock at fair value | — |  |  | 9.7 |  |
| Unrealized loss on the Series A Preferred Stock derivative liability | 41.3 |  |  | 0.6 |  |
| Balance as of end of period | $ | 51.6 |  |  | $ | 10.3 |  |

[0001633978-17-000095:notes:162]
The Company satisfied the TMA settlement condition for the 2024 Notes on June 29, 2017. Refer to “Note 11. Convertible Senior Notes”. The following table provides a reconciliation of the fair value of the embedded derivative for the 2024 Notes measured by significant unobservable inputs (Level 3) for the years ended July 1, 2017 and July 2, 2016:

[0001633978-17-000095:notes:163]
| (in millions) | July 1, 2017 |  | July 2, 2016 |
| Balance as of beginning of period | $ | — |  |  | $ | — |  |
| Fair value of the embedded derivative for the 2024 Notes at issuance | 129.9 |  |  | — |  |
| Unrealized loss on the 2024 Notes derivative liability | 62.9 |  |  | — |  |
| Reclassification of the 2024 Notes derivative liability in connection with TMA settlement condition | (192.8 | ) |  | — |  |
| Balance as of end of period | $ | — |  |  | $ | — |  |

[0001633978-17-000095:notes:164]
The following table summarizes the assumptions used to determine the fair value of the embedded derivative for the 2024 Notes at the issuance date and as of June 29, 2017 when the Company satisfied the TMA settlement condition:

[0001633978-17-000095:notes:165]
|  | June 29, 2017 |  | March 8, 2017 |
| Stock price | $ | 57.30 |  |  | $ | 45.50 |  |
| Conversion price | $ | 60.62 |  |  | $ | 60.62 |  |
| Expected term (years) | 6.7 |  |  | 7 |  |
| Expected annual volatility | 47.50 | % |  | 45.0 | % |
| Risk-free rate | 2.10 | % |  | 2.40 | % |

[0001633978-17-000095:notes:166]
The following table summarizes the assumptions used to determine the fair value of the embedded derivative for Series A Preferred Stock:

[0001633978-17-000095:notes:167]
|  | July 1, 2017 |  | July 2, 2016 |
| Stock price | $ | 57.05 |  |  | $ | 23.65 |  |
| Conversion price | $ | 24.63 |  |  | $ | 24.63 |  |
| Expected term (years) | 3.11 |  |  | 4.11 |  |
| Expected annual volatility | 47.5 | % |  | 40.0 | % |
| Risk-free rate | 1.57 | % |  | 0.96 | % |
| Preferred yield | 7.56 | % |  | 8.84 | % |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001633978-17-000095:notes:168]
Note 16. Stock-Based Compensation and Stock Plans

[0001633978-17-000095:notes:169]
Description of Lumentum Stock-Based Benefit Plans

[0001633978-17-000095:notes:170]
Stock Option Plans

[0001633978-17-000095:notes:171]
On June 23, 2015, we adopted, and the board of directors of JDS Uniphase Corporation (“JDSU” and, now, Viavi Solutions Inc.) approved, the 2015 Equity Incentive Plan (the “2015 Plan”) under which 8.5 million shares of our Common Stock were authorized for issuance, which was ratified by the Company’s board of directors in August 2015.  In connection with our Separation from JDSU on July 31, 2015, outstanding JDSU equity-based awards held by service providers continuing in service after the Separation were converted into equity-based awards under the 2015 Plan reducing the number of shares remaining available for grant under the 2015 Plan. Immediately following our Separation from JDSU, 2.1 million shares of our Common Stock were reserved pursuant to outstanding equity-based awards under the 2015 Plan that were converted from JDSU equity-based awards.

[0001633978-17-000095:notes:172]
On November 4, 2016, the Company’s stockholders approved an amendment to increase the number of shares that may be issued under the 2015 Plan by 3.0 million shares and to approve the material terms of the 2015 Plan.

[0001633978-17-000095:notes:173]
As of July 1, 2017, the Company had 2.2 million shares of stock options, restricted stock awards, and restricted stock units issued and outstanding to employees and directors under the 2015 Plan. Restricted stock awards and restricted stock units are performance-based, time-based or a combination of both and are expected to vest over one to four years. The fair value of the time-based restricted stock award or restricted stock unit is based on the closing market price of the Company’s common stock on the date of award.

[0001633978-17-000095:notes:174]
The exercise price for stock options is equal to the fair value of the underlying stock at the date of grant. The Company issues new shares of common stock upon exercise of stock options. Options generally become exercisable over a three-year or four-year period and, if not exercised, expire from five to ten years after the date of grant. As of July 1, 2017, 6.6 million shares of common stock under the 2015 Plan were available for grant.

[0001633978-17-000095:notes:175]
Employee Stock Purchase Plan

[0001633978-17-000095:notes:176]
On June 23, 2015, we adopted, and the board of directors of JDSU approved, the 2015 Employee Stock Purchase Plan (the “2015 Purchase Plan”) under which 3.0 million shares of our Common Stock were authorized for issuance, which was ratified by our board of directors in August 2015.  The 2015 Purchase Plan provides eligible employees with the opportunity to acquire an ownership interest in the Company through periodic payroll deductions and provides a 15% purchase price discount as well as a six-month look-back period. The 2015 Purchase Plan is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986. However, the 2015 Purchase Plan is not intended to be a qualified pension, profit sharing or stock bonus plan under Section 401(a) of the Internal Revenue Code of 1986 and is not subject to the provisions of the Employee Retirement Income Security Act of 1974. The 2015 Purchase Plan will terminate upon the date on which all shares available for issuance have been sold. Of the 3.0 million shares authorized under the 2015 Purchase Plan, 2.5 million shares remained available for issuance as of July 1, 2017.

[0001633978-17-000095:notes:177]
Restricted Stock Units

[0001633978-17-000095:notes:178]
Restricted stock units (“RSUs”) under the 2015 Plan are grants of shares of our common stock valued at fair value based on the closing price of our common stock on the date of grant. RSUs result in a payment to a holder if any performance goals or other vesting criteria are achieved or the awards otherwise vest. Generally, our RSUs have service conditions, performance conditions, or a combination of both and are expected to vest over one to four years. The fair value of the time-based RSUs is based on the closing market price of the common stock on the date of award.

[0001633978-17-000095:notes:179]
Restricted Stock Awards

[0001633978-17-000095:notes:180]
Restricted stock awards (“RSAs”) under the 2015 Plan are grants of shares of our common stock that are subject to various restrictions, including restrictions on transferability and forfeiture provisions. RSAs are expected to vest over one to four years, and the shares acquired may not be transferred by the holder until the vesting conditions (if any) are satisfied.

[0001633978-17-000095:notes:181]
Stock-Based Compensation

[0001633978-17-000095:notes:182]
The impact on our results of operations of recording stock-based compensation by function for fiscal 2017, 2016 and 2015 was as follows (in millions):

[0001633978-17-000095:notes:183]
|  | Years Ended |
|  | July 1, 2017 |  | July 2, 2016 |  | June 27, 2015 |
| Cost of sales | $ | 7.5 |  |  | $ | 6.1 |  |  | $ | 5.1 |  |
| Research and development | 11.6 |  |  | 9.0 |  |  | 7.3 |  |
| Selling, general and administrative | 13.6 |  |  | 11.8 |  |  | 14.7 |  |
|  | $ | 32.7 |  |  | $ | 26.9 |  |  | $ | 27.1 |  |

[0001633978-17-000095:notes:184]
Approximately $1.8 million and $1.2 million of stock-based compensation was capitalized to inventory as of July 1, 2017 and July 2, 2016. The table above includes allocated stock-based compensation from Viavi of $2.0 million and $8.9 million for fiscal 2016 and 2015, respectively. There were no allocations to stock-based compensation from Viavi during the year ended July 1, 2017. Refer to “Note 3. Related Party Transactions” in the Notes to Consolidated Financial Statements.

[0001633978-17-000095:notes:185]
Stock Option and Restricted Stock Units Activity

[0001633978-17-000095:notes:186]
We did not grant any stock options during fiscal 2017 and 2016. As of July 1, 2017 and July 2, 2016, the total intrinsic value of options exercised by our employees was $5.6 million and $1.0 million, respectively. In connection with these exercises, the tax benefit realized during the year ended July 1, 2017 was $3.8 million. For the year ended July 2, 2016 there was no tax benefit related to options exercised.

[0001633978-17-000095:notes:187]
As of July 1, 2017, $48.4 million of stock-based compensation cost related to RSUs and RSAs granted to our employees remains to be amortized. That cost is expected to be recognized over an estimated amortization period of 2.0 years.

[0001633978-17-000095:notes:188]
The following table summarizes our stock option, RSA, and RSU activities in fiscal 2017 (amount in millions except per share amounts):

[0001633978-17-000095:notes:189]
|  |  |  | Options Outstanding |  | Restricted Stock Units/Awards Outstanding |
|  | Available for Grant |  | Number of Shares |  | Weighted-Average Exercise Price |  | Number of Shares (MSU/PSU) |  | Number of Shares(RSU/RSA) |  | Weighted-Average Grant Date Fair Value |
| Outstanding as of June 27, 2015 |  |  | 0.5 |  |  | $ | 19.01 |  |  | 0.2 |  |  | 1.5 |  |  | $ | 22.70 |  |
| Authorized | 8.5 |  |  |  |  |  |  |  |  |  |  |  |
| Granted | (4.0 | ) |  | — |  |  | — |  |  | — |  |  | 1.9 |  |  | 20.39 |  |
| Exercised / Vested | — |  |  | (0.2 | ) |  | 15.21 |  |  | (0.1 | ) |  | (0.7 | ) |  | 22.60 |  |
| Canceled | 0.2 |  |  | — |  |  | — |  |  | — |  |  | (0.2 | ) |  | 21.85 |  |
| Outstanding as of July 2, 2016 | 4.7 |  |  | 0.3 |  |  | $ | 17.83 |  |  | 0.1 |  |  | 2.5 |  |  | $ | 21.04 |  |
| Authorized | 3.0 |  |  |  |  |  |  |  |  |  |  |  |
| Granted | (1.3 | ) |  | — |  |  | — |  |  | — |  |  | 1.3 |  |  | 34.86 |  |
| Exercised / Vested | — |  |  | (0.3 | ) |  | 14.29 |  |  | (0.1 | ) |  | (1.4 | ) |  | 21.74 |  |
| Canceled | 0.2 |  |  | — |  |  | — |  |  | — |  |  | (0.2 | ) |  | 23.78 |  |
| Outstanding as of July 1, 2017 | 6.6 |  |  | — |  |  | $ | — |  |  | — |  |  | 2.2 |  |  | $ | 28.51 |  |
| Vested and expected to vest |  |  | — |  |  | $ | — |  |  | — |  |  | 2.1 |  |  | $ | 28.61 |  |

[0001633978-17-000095:notes:190]
Employee Stock Purchase Plan (“ESPP”) Activity

[0001633978-17-000095:notes:191]
The ESPP expense for the years ended July 1, 2017 and July 2, 2016 was $2.7 million and $1.3 million, respectively. The expense related to the ESPP is recorded on a straight-line basis over the relevant subscription period. During fiscal 2017 and 2016, 314,800 shares and 202,479 shares were issued to our employees with the average fair market value at the purchase date of $25.64 and $15.46 , respectively.


## us-gaap:EarningsPerShareTextBlock

[0001633978-17-000095:notes:192]
Note 4. Earnings Per Share

[0001633978-17-000095:notes:193]
The following table sets forth the computation of basic and diluted net income (loss) attributable to common stockholders per share (in millions, except per share data):

[0001633978-17-000095:notes:194]
|  | Years Ended |
|  | July 1, 2017 |  | July 2, 2016 |  | June 27, 2015 |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income (loss) | $ | (102.5 | ) |  | $ | 9.3 |  |  | $ | (3.4 | ) |
| Less: Cumulative dividends on Series A Preferred Stock | (0.9 | ) |  | (0.8 | ) |  | — |  |
| Less: Accretion of Series A Preferred Stock | — |  |  | (11.7 | ) |  | — |  |
| Net income (loss) attributable to common stockholders | $ | (103.4 | ) |  | $ | (3.2 | ) |  | $ | (3.4 | ) |
| Denominator: |  |  |  |  |  |
| Weighted-average number of common shares outstanding |  |  |  |  |  |
| Basic | 60.6 |  |  | 59.1 |  |  | 58.8 |  |
| Effect of dilutive securities from stock-based benefit plans | — |  |  | — |  |  | — |  |
| Diluted | 60.6 |  |  | 59.1 |  |  | 58.8 |  |
| Net income (loss) per share attributable to common stockholders: |  |  |  |  |  |
| Basic | $ | (1.71 | ) |  | $ | (0.05 | ) |  | $ | (0.06 | ) |
| Diluted | $ | (1.71 | ) |  | $ | (0.05 | ) |  | $ | (0.06 | ) |

[0001633978-17-000095:notes:195]
On August 1, 2015, JDSU distributed 47.1 million shares, or 80.1% of the outstanding shares of the Company’s common stock to existing holders of JDSU common stock. The weighted average number of common stock outstanding is calculated as the number of shares of common stock outstanding immediately following the Separation, and the weighted average number of shares outstanding following the Separation through July 1, 2017. Diluted earnings (loss) per share is calculated by dividing net income for the period by the weighted average number of shares of common stock and potentially dilutive common stock outstanding for the period beginning after the Separation. Basic and diluted net income (loss) per share for the twelve months ended June 27, 2015 is calculated using the shares of the Company’s common stock outstanding on August 1, 2015, as if such shares were outstanding for the entire period.

[0001633978-17-000095:notes:196]
The dilutive effect of stock-based awards is reflected in diluted earnings per share by application of the treasury stock method, which includes consideration of unamortized share-based compensation expense, the tax benefits or shortfalls recorded to additional paid-in capital and the dilutive effect of in-the-money options and non-vested restricted stock units. Under the treasury stock method, the amount the employee must pay for exercising stock options and unamortized share-based compensation expense and tax benefits or shortfalls collectively are assumed proceeds to be used to repurchase hypothetical shares. An increase in the fair value of the Company’s common stock can result in a greater dilutive effect from potentially dilutive awards.

[0001633978-17-000095:notes:197]
The dilutive effect of the redeemable convertible preferred stock is reflected in diluted earnings per share by the application of the if-converted method. The number of shares is increased for the assumed conversion of the instrument. Additionally, cumulative dividends and accretion from measuring the instrument at its redemption value are added back to net income (loss).

[0001633978-17-000095:notes:198]
The Company has the ability and intent to settle the $450 million face value of the 2024 Notes in cash. Therefore, the Company will use the treasury stock method for calculating the dilutive impact of the 2024 Notes. The 2024 Notes will have no impact to diluted earnings per share until the average price of our common stock exceeds the conversion price. Refer to “Note 11. Convertible Senior Notes” for further discussion.

[0001633978-17-000095:notes:199]
For the year ended July 1, 2017, 7.4 million shares related to the potential conversion of the 2024 Notes were excluded from the calculation of diluted shares because their inclusion would have been antidilutive. For the year ended July 1, 2017, the number of shares related to our 2015 Plan that were excluded from the calculation of diluted shares was not material.

[0001633978-17-000095:notes:200]
For the year ended July 2, 2016, 1.2 million weighted average shares related to our 2015 Plan were excluded from the calculation of diluted shares because their inclusion would have been antidilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0001633978-17-000095:notes:201]
Note 9. Fair Value Measurements

[0001633978-17-000095:notes:202]
We determine fair value based on the fair value hierarchy, which requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs when measuring fair value. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. The fair value assumes that the transaction to sell the asset or transfer the liability occurs in the principal or most advantageous market for the asset or liability and establishes that the fair value of an asset or liability shall be determined based on the assumptions that market participants would use in pricing the asset or liability. The classification of a financial asset or liability within the hierarchy is based upon the lowest level input that is significant to the fair value measurement. The fair value hierarchy prioritizes the inputs into three levels that may be used to measure fair value:

[0001633978-17-000095:notes:203]
| Level 1: | Inputs are unadjusted quoted prices in active markets for identical assets or liabilities. |
| Level 2: | Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the asset or liability, either directly or indirectly through market corroboration, for substantially the full term of the financial instrument. |
| Level 3: | Inputs are unobservable inputs based on our assumptions. |

[0001633978-17-000095:notes:204]
The fair value of the Company’s Level 1 financial instruments, such as money market funds, which are traded in active markets, is based on quoted market prices for identical instruments. The fair value of the Company’s Level 2 fixed income securities is obtained from an independent pricing service, which may use quoted market prices for identical or comparable instruments or model driven valuations using observable market data or inputs corroborated by observable market data. Our marketable securities are held by custodians who obtain investment prices from a third-party pricing provider that incorporates standard inputs in various asset price models. The Company’s procedures include controls to ensure that appropriate fair values are recorded, including comparing the fair values obtained from the Company’s pricing service against fair values obtained from another independent source.

[0001633978-17-000095:notes:205]
We estimate the fair value of the embedded derivative for the Series A Preferred Stock using the binomial lattice model. The lattice model requires the various assumptions to be made to determine the fair value of the embedded derivatives. These assumptions represent Level 3 inputs. Refer to “Note 12. Derivative Liabilities” in the Notes to Consolidated Financial Statements.

[0001633978-17-000095:notes:206]
We estimated the acquisition date fair value of our Level 3 contingent consideration as the present value of the expected contingent payments, determined using a probabilistic approach. We are required to reassess the fair value of contingent payments on a periodic basis. We estimated the likelihood of meeting the production targets at 90 percent and recorded the fair value of such contingent consideration in accrued liabilities on the consolidated balance sheet as of July 1, 2017. This contingent consideration will result in a cash payment of $3.0 million, if and when the production targets are achieved. Refer to “Note 6. Mergers and Acquisitions” in the Notes to Consolidated Financial Statements.

[0001633978-17-000095:notes:207]
Our pension assets consist of multiple institutional funds (“pension funds”) of which the fair values are based on the quoted prices of the underlying funds. Pension funds are classified as Level 2 assets since such funds are not directly traded in active markets. Refer to “Note 17. Employee Benefit Plans” in the Notes to Consolidated Financial Statements.

[0001633978-17-000095:notes:208]
Financial assets and liabilities measured at fair value on a recurring basis are summarized below (in millions):

[0001633978-17-000095:notes:209]
|  | As of July 1, 2017 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | — |  |  | $ | 52.1 |  |  | $ | — |  |  | $ | 52.1 |  |
| Commercial paper | — |  |  | 14.7 |  |  | — |  |  | 14.7 |  |
| Money market funds | 4.8 |  |  | — |  |  | — |  |  | 4.8 |  |
| Marketable securities: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 202.1 |  |  | — |  |  | 202.1 |  |
| Asset-backed securities | — |  |  | 26.1 |  |  | — |  |  | 26.1 |  |
| Corporate debt securities | — |  |  | 46.4 |  |  | — |  |  | 46.4 |  |
| Municipal bonds | — |  |  | 4.9 |  |  | — |  |  | 4.9 |  |
| Foreign government bonds | — |  |  | 1.0 |  |  | — |  |  | 1.0 |  |
| U.S. Treasury | 1.9 |  |  | — |  |  | — |  |  | 1.9 |  |
| Total cash equivalents and marketable securities | $ | 6.7 |  |  | $ | 347.3 |  |  | $ | — |  |  | $ | 354.0 |  |
| Other accrued liabilities: |  |  |  |  |  |  |  |
| Derivative liability | $ | — |  |  | $ | — |  |  | $ | 51.6 |  |  | $ | 51.6 |  |
| Acquisition contingencies | — |  |  | — |  |  | 2.7 |  |  | 2.7 |  |
| Pension and post-retirement benefit accrual | — |  |  | 3.9 |  |  | — |  |  | 3.9 |  |
| Total other accrued liabilities | $ | — |  |  | $ | 3.9 |  |  | $ | 54.3 |  |  | $ | 58.2 |  |

[0001633978-17-000095:notes:210]
Assets Measured at Fair Value on a Non-Recurring Basis

[0001633978-17-000095:notes:211]
We periodically review our intangible and other long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. Determination of recoverability is based on the lowest level of identifiable estimated undiscounted cash flows resulting from use of the asset and its eventual disposition. If not recoverable, an impairment loss would be calculated based on the excess of the carrying amount over the fair value.

[0001633978-17-000095:notes:212]
Management utilizes various valuation methods, including an income approach, a market approach and a cost approach, to estimate the fair value of intangible and other long-lived assets. The inputs used are classified as Level 3 within the fair value hierarchy due to the significance of unobservable inputs using company-specific information.  During the annual impairment testing performed in fiscal 2017, all our intangible and other long-lived assets passed Step 1. No impairment charges were recorded in fiscal 2017 or 2016. Refer to “Note 13. Goodwill and Other Intangible Assets”.

[0001633978-17-000095:notes:213]
Additionally, we have a restructuring liability related to certain real estate facilities which was calculated based on the present value of future lease payments, less estimated sublease income, discounted at a rate commensurate with our current cost of financing. This non-recurring fair value measurement is considered to be a Level 3 measurement due to the use of significant unobservable inputs. To the extent that actual sublease income or the timing of subleasing these facilities is different than initial estimates, we will adjust the restructuring liability in the period during which such information becomes known. Refer to “Note 14. Restructuring and Related Charges”.


## us-gaap:FiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0001633978-17-000095:notes:214]
The following table presents details of our amortization (in millions):

[0001633978-17-000095:notes:215]
|  | Years Ended |
|  | July 1, 2017 |  | July 2, 2016 |  | June 27, 2015 |
| Cost of sales | $ | 6.5 |  |  | $ | 6.8 |  |  | $ | 7.6 |  |
| Operating expense | 0.3 |  |  | 0.4 |  |  | 0.4 |  |
| Total | $ | 6.8 |  |  | $ | 7.2 |  |  | $ | 8.0 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001633978-17-000095:notes:216]
Note 13. Goodwill and Other Intangible Assets

[0001633978-17-000095:notes:217]
The following table presents the changes in goodwill by operating segments during the year ended July 1, 2017 (in millions):

[0001633978-17-000095:notes:218]
|  |  | Optical Communications |  | Commercial Lasers |  | Total |
| Balance as of June 27, 2015 | $ | — |  |  | $ | 5.6 |  |  | $ | 5.6 |  |
|  | Currency translation | — |  |  | (0.2 | ) |  | (0.2 | ) |
| Balance as of July 2, 2016 | $ | — |  |  | $ | 5.4 |  |  | $ | 5.4 |  |
|  | Acquisition of a business | 5.6 |  |  | — |  |  | 5.6 |  |
|  | Currency translation | 0.3 |  |  | 0.1 |  |  | 0.4 |  |
| Balance as of July 1, 2017 | $ | 5.9 |  |  | $ | 5.5 |  |  | $ | 11.4 |  |

[0001633978-17-000095:notes:219]
Impairment of Goodwill

[0001633978-17-000095:notes:220]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. In the fourth quarter of fiscal 2017, we completed the annual impairment test of goodwill, which indicated there was no goodwill impairment. During fiscal 2017, there have been no events or circumstances that have required us to perform an interim assessment of goodwill for impairment.

[0001633978-17-000095:notes:221]
Acquired Developed Technology and Other Intangibles

[0001633978-17-000095:notes:222]
We allocated acquired developed technology and other intangibles resulting from past acquisitions to our Commercial Lasers operating segment.

[0001633978-17-000095:notes:223]
In fiscal 2017, we completed the acquisition of a privately held company to enhance our manufacturing processes with $2.4 million acquired developed technology which was allocated to Optical Communications operating segment. The following tables present details of our acquired developed technology and other intangibles (in millions):

[0001633978-17-000095:notes:224]
| As of July 1, 2017 | Gross Carrying Amount |  | Accumulated Amortization |  | Net |
| Acquired developed technology | $ | 105.5 |  |  | $ | (95.4 | ) |  | $ | 10.1 |  |
| Other | 9.4 |  |  | (9.4 | ) |  | — |  |
| Total Intangibles | $ | 114.9 |  |  | $ | (104.8 | ) |  | $ | 10.1 |  |

[0001633978-17-000095:notes:225]
| As of July 2, 2016 | Gross Carrying Amount |  | Accumulated Amortization |  | Net |
| Acquired developed technology | $ | 103.0 |  |  | $ | (88.9 | ) |  | $ | 14.1 |  |
| Other | 9.4 |  |  | (9.0 | ) |  | 0.4 |  |
| Total Intangibles | $ | 112.4 |  |  | $ | (97.9 | ) |  | $ | 14.5 |  |

[0001633978-17-000095:notes:226]
During fiscal 2017, 2016 and 2015, we recorded $6.8 million, $7.2 million, and $8.0 million, respectively, of amortization related to acquired developed technology and other intangibles. The following table presents details of our amortization (in millions):

[0001633978-17-000095:notes:227]
Based on the carrying amount of acquired developed technology and other intangibles as of July 1, 2017, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001633978-17-000095:notes:228]
| Fiscal Years |  |
| 2018 | $ | 3.2 |  |
| 2019 | 3.0 |  |
| 2020 | 2.8 |  |
| 2021 | 1.1 |  |
| Thereafter | — |  |
| Total amortization | $ | 10.1 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001633978-17-000095:notes:229]
Note 15. Income Taxes

[0001633978-17-000095:notes:230]
Our income (loss) before income taxes consisted of the following (in millions):

[0001633978-17-000095:notes:231]
|  | Years Ended |
|  | July 1, 2017 |  | July 2, 2016 |  | June 27, 2015 |
| Domestic | $ | (78.4 | ) |  | $ | 60.7 |  |  | $ | (58.7 | ) |
| Foreign | 18.6 |  |  | (51.0 | ) |  | 34.2 |  |
| Income (loss) before income taxes | $ | (59.8 | ) |  | $ | 9.7 |  |  | $ | (24.5 | ) |

[0001633978-17-000095:notes:232]
Our income tax (benefit) expense consisted of the following (in millions):

[0001633978-17-000095:notes:233]
|  | Years Ended |
|  | July 1, 2017 |  | July 2, 2016 |  | June 27, 2015 |
| Federal: |  |  |  |  |  |
| Current | $ | 13.7 |  |  | $ | 1.6 |  |  | $ | — |  |
| Deferred | — |  |  | — |  |  | — |  |
|  | 13.7 |  |  | 1.6 |  |  | — |  |
| State: |  |  |  |  |  |
| Current | 0.1 |  |  | 0.2 |  |  | 0.1 |  |
| Deferred | — |  |  | — |  |  | — |  |
|  | 0.1 |  |  | 0.2 |  |  | 0.1 |  |
| Foreign: |  |  |  |  |  |
| Current | 2.1 |  |  | 1.2 |  |  | (20.3 | ) |
| Deferred | 26.8 |  |  | (2.6 | ) |  | (0.9 | ) |
|  | 28.9 |  |  | (1.4 | ) |  | (21.2 | ) |
| Total income tax (benefit) expense | $ | 42.7 |  |  | $ | 0.4 |  |  | $ | (21.1 | ) |

[0001633978-17-000095:notes:234]
The Company’s effective tax rate differs from the U.S. Federal statutory income tax rate as follows (in millions):

[0001633978-17-000095:notes:235]
|  | Years Ended |
|  | July 1, 2017 |  | July 2, 2016 |  | June 27, 2015 |
| Income tax (benefit) expense computed at federal statutory rate | $ | (20.9 | ) |  | $ | 3.4 |  |  | $ | (8.6 | ) |
| State taxes, net of federal benefit | 0.1 |  |  | 0.1 |  |  | — |  |
| Foreign rate differential | (4.8 | ) |  | 21.3 |  |  | 0.2 |  |
| Change in valuation allowance | 21.5 |  |  | (29.4 | ) |  | (2.2 | ) |
| Reversal of previously accrued taxes | — |  |  | — |  |  | (21.8 | ) |
| Research and experimentation benefits and other tax credits | (2.9 | ) |  | (4.4 | ) |  | (3.1 | ) |
| Permanent items | 0.3 |  |  | 0.7 |  |  | (0.7 | ) |
| Stock-based compensation | 4.9 |  |  | 4.3 |  |  | 1.2 |  |
| Fair value adjustment | 36.5 |  |  | — |  |  | — |  |
| Subpart F | — |  |  | 4.0 |  |  | 12.7 |  |
| Unrecognized tax benefits | 8.4 |  |  | — |  |  | 1.0 |  |
| Other | (0.4 | ) |  | 0.4 |  |  | 0.2 |  |
| Total income tax (benefit) expense | $ | 42.7 |  |  | $ | 0.4 |  |  | $ | (21.1 | ) |

[0001633978-17-000095:notes:236]
The components of our net deferred taxes consisted of the following (in millions):

[0001633978-17-000095:notes:237]
|  | Years Ended |
|  | July 1, 2017 |  | July 2, 2016 |  | June 27, 2015 |
| Gross deferred tax assets: |  |  |  |  |  |
| Intangibles | $ | 217.4 |  |  | $ | 230.2 |  |  | $ | — |  |
| Tax credit carryforwards | 34.9 |  |  | 43.8 |  |  | 41.6 |  |
| Net operating loss carryforwards | 11.5 |  |  | 16.1 |  |  | 61.0 |  |
| Inventories | 11.7 |  |  | 10.9 |  |  | 7.7 |  |
| Accruals and reserves | 19.7 |  |  | 9.9 |  |  | 4.1 |  |
| Fixed assets | 11.4 |  |  | 11.1 |  |  | 21.7 |  |
| Capital loss carryforwards | 12.4 |  |  | 11.9 |  |  | 12.4 |  |
| Unclaimed research and experimental development expenditure | 23.0 |  |  | 19.5 |  |  | 16.7 |  |
| Other | 0.4 |  |  | 0.6 |  |  | 5.4 |  |
| Stock-based compensation | 3.1 |  |  | — |  |  | — |  |
| Acquisition-related items | — |  |  | — |  |  | 29.4 |  |
| Gross deferred tax assets | 345.5 |  |  | 354.0 |  |  | 200.0 |  |
| Valuation allowance | (296.4 | ) |  | (321.4 | ) |  | (160.0 | ) |
| Deferred tax assets | 49.1 |  |  | 32.6 |  |  | 40.0 |  |
| Gross deferred tax liabilities: |  |  |  |  |  |
| Intangible amortization | (1.1 | ) |  | (1.0 | ) |  | (6.7 | ) |
| Convertible note | (44.4 | ) |  | — |  |  | — |  |
| Undistributed foreign earnings | — |  |  | — |  |  | (2.6 | ) |
| Other | — |  |  | — |  |  | (1.2 | ) |
| Deferred tax liabilities | (45.5 | ) |  | (1.0 | ) |  | (10.5 | ) |
| Total net deferred tax assets | $ | 3.6 |  |  | $ | 31.6 |  |  | $ | 29.5 |  |

[0001633978-17-000095:notes:238]
The Realization of deferred tax assets is dependent upon the generation of sufficient taxable income of the appropriate character in future periods. The Company regularly assesses the ability to realize its deferred tax assets and establishes a valuation allowance if it is more-likely-than-not that some portion of the deferred tax assets will not be realized. The Company weighs all available positive and negative evidence, including its earnings history and results of recent operations, scheduled reversals of deferred tax liabilities, projected future taxable income, and tax planning strategies. Due to the weight of objectively verifiable negative evidence, including its history of losses in certain jurisdictions, the Company believes that it is more likely than not that its U.S. federal, state, and Canadian deferred tax assets will not be realized as of July 1, 2017. Accordingly, the Company has recorded a valuation allowance on such deferred tax assets.

[0001633978-17-000095:notes:239]
The amount of the deferred tax asset considered realizable, however, could be adjusted if estimates of future taxable income during the carryforward period are reduced or increased or if objective negative evidence in the form of cumulative losses is no longer present and additional weight may be given to subjective evidence such as our projections for growth. In the event the Company determines that it will be able to realize all or part of its net deferred tax assets in the future, the valuation allowance against deferred tax assets will be reversed in the period in which the Company makes such determination. The release of a valuation allowance against deferred tax assets may cause greater volatility in the effective tax rate in the periods in which the valuation allowance is released. It is reasonably possible that significant positive evidence may become available to reach a conclusion that a significant portion of the valuation allowance will no longer be needed, and as such, we may release a significant portion of our valuation allowance in the next 12 months.

[0001633978-17-000095:notes:240]
The valuation allowance against our various deferred tax assets decreased by $25.0 million in fiscal 2017, and increased by $161.4 million in fiscal 2016. The decrease in the valuation allowance during fiscal 2017 was primarily related to the amortization of intangible assets, utilization of tax attributes, and the tax effects of the Convertible Senior Notes. The increase during fiscal 2016 was primarily due to a step up in the tax basis of intangible assets, which was offset by a valuation allowance. The step-up was the result of the Separation from Viavi, and consequently, a significant portion of the change in the valuation allowance had no impact on the effective tax rate.

[0001633978-17-000095:notes:241]
As of July 1, 2017, the Company had federal and foreign tax net operating loss carryforwards of $6.9 million and $35.9 million, respectively.  These carryforwards will begin to expire in the fiscal years ending 2022 and 2025,  respectively. The federal net operating loss carryforwards are subject to Internal Revenue Code Section 382 which imposes limitations on annual utilization after a change of ownership.

[0001633978-17-000095:notes:242]
Additionally, the Company has federal, state, and foreign research and other tax credit carryforwards of $4.3 million, $7.2 million, and $43.0 million, respectively. A portion of the federal credits will begin to expire in the fiscal year ending 2036 and California credits can be carried forward indefinitely. The foreign tax credits will begin to expire in the fiscal year ending 2020.

[0001633978-17-000095:notes:243]
As a result of certain realization requirements of ASC 718, the table of deferred tax assets and liabilities does not include certain deferred tax assets that arose directly from (or the use of which was postponed by) tax deductions related to equity compensation that are greater than the compensation recognized for financial reporting. Equity will be increased by $2.5 million if and when such deferred tax assets are ultimately realized. We use ASC 740 ordering when determining when excess tax benefits have been realized.

[0001633978-17-000095:notes:244]
U.S. income and foreign withholding taxes associated with the repatriation of earnings of foreign subsidiaries have not been provided on $0.6 million of undistributed earnings for certain foreign subsidiaries. We intend to reinvest these earnings indefinitely outside of the United States. We estimate that an additional $0.1 million of U.S. income or foreign withholding taxes would have to be provided if these earnings were repatriated back to the U.S. federal statutory rate.

[0001633978-17-000095:notes:245]
A reconciliation of unrecognized tax benefits between June 27, 2015 and July 1, 2017 is as follows (in millions):

[0001633978-17-000095:notes:246]
| Balance at June 27, 2015 | $ | 0.2 |  |
| Reductions based on the tax positions related to the prior year | (0.1 | ) |
| Additions based on tax positions related to current year | 2.1 |  |
| Balance at July 2, 2016 | $ | 2.2 |  |
| Additions based on the tax positions related to the prior year | 1.6 |  |
| Additions based on tax positions related to current year | 9.5 |  |
| Balance at July 1, 2017 | $ | 13.3 |  |

[0001633978-17-000095:notes:247]
Included in the balance of unrecognized tax benefits as of July 1, 2017 is $3.6 million of tax benefits that, if recognized, would result in adjustments to the valuation allowance. Also, included in the balance of unrecognized tax benefits as of July 1, 2017 is $10.5 million of tax benefits that, if recognized, would impact the effective tax rate.

[0001633978-17-000095:notes:248]
Our policy is to recognize accrued interest and penalties related to unrecognized tax benefits within the income tax provision. The amount of interest and penalties accrued as of July 1, 2017 and July 2, 2016 were $0.9 million and $0.1 million, respectively.  During fiscal 2017, accrued interest and penalties increased by $0.8 million.

[0001633978-17-000095:notes:249]
The Company files income tax returns in the US federal jurisdiction as well as many US states and foreign jurisdictions. The Company’s major tax jurisdictions are the U.S. federal government, the state of California, and Canada. The U.S. federal corporation income tax returns beginning with the 2000 tax year remain subject to examination by the Internal Revenue Service, or IRS. The California corporation income tax returns beginning with the fiscal year 2016 will remain subject to examination by the California Franchise Tax Board. The Canada corporation income tax returns beginning with the 2009 year remain subject to examination by the Canadian tax authorities. Fiscal years outside the normal statute of limitation remain open to audit by tax authorities due to tax attributes generated in those early years which have been carried forward and may be audited in subsequent years when utilized.

[0001633978-17-000095:notes:250]
The Company is subject to the continuous examination of income tax returns by various foreign tax authorities. The timing of resolutions and closures of tax audits is highly unpredictable. Given the uncertainty, it is reasonably possible that certain tax audits may be concluded within the next 12 months that could materially impact the balance of our gross unrecognized tax benefits. An estimate of the range of increase or decrease that could occur in the next twelve months cannot be made. However, the estimated impact to tax expense and net income from the resolution and closure of tax exams is not expected to be significant within the next 12 months.


## us-gaap:MinorityInterestDisclosureTextBlock

[0001633978-17-000095:notes:251]
Note 10. Non-Controlling Interest Redeemable Convertible Preferred Stock

[0001633978-17-000095:notes:252]
On July 31, 2015, our wholly-owned subsidiary, Lumentum Inc., issued 40,000 shares of its Series A Preferred Stock to Viavi. Pursuant to a securities purchase agreement between the Company, Viavi and Amada, 35,805 shares of Series A Preferred Stock were sold by Viavi to Amada in August 2015. The remaining 4,195 shares of the Series A Preferred Stock were canceled. The Series A Preferred Stock is referred to as our Non-Controlling Interest Redeemable Convertible Preferred Stock within these consolidated financial statements.

[0001633978-17-000095:notes:253]
The Series A Preferred Stock is redeemable at the option of Amada after five years and classified as non-controlling interest redeemable convertible preferred stock in our consolidated balance sheet. The Series A Preferred Stock is measured at its redemption value.  We recognized a $9.7 million increase in the value of the Series A Preferred Stock during the fiscal year ended July 2, 2016 to accrete to the redemption value of $35.8 million with a reduction to additional paid-in capital. The Series A Preferred Stock value of $35.8 million as of July 1, 2017 has not changed from prior year.

[0001633978-17-000095:notes:254]
The Series A Preferred Stock conversion feature is bifurcated from the Series A Preferred Stock and accounted for separately as a derivative liability.  The derivative liability is measured at fair value each reporting period with the change in fair value recorded in the consolidated statements of operations.

[0001633978-17-000095:notes:255]
The following paragraphs describe the terms and conditions of the Series A Preferred Stock:

[0001633978-17-000095:notes:256]
Conversion

[0001633978-17-000095:notes:257]
The Series A Preferred Stock is convertible, at the option of the holder, into shares of our common stock commencing on the second anniversary of the closing of the securities purchase (absent a change of control of us or similar event) using a conversion price of $24.63, which is equal to 125% of the volume weighted average price per share of our common stock in the five “regular-way” trading days following the Separation.

[0001633978-17-000095:notes:258]
Liquidation

[0001633978-17-000095:notes:259]
Upon any liquidation, dissolution, or winding up of our business, whether voluntary or involuntary, holders of Series A Preferred Stock will be entitled to receive, in preference to holders of common stock or any other class or series of our outstanding capital stock ranking in any such event junior to the Series A Preferred Stock, an amount per share equal to the greater of (i) the Issuance Value of $1,000 per share for Series A Preferred Stock plus all accrued and unpaid dividends thereon (whether or not authorized or declared) through the date of payment and (ii) the amount as would have been payable had all Series A Preferred Stock been converted into common stock immediately prior to such liquidation event.

[0001633978-17-000095:notes:260]
If upon occurrence of any such event, our assets legally available for distribution are insufficient to permit payment of the aforementioned preferential amounts, then all of our assets legally available for distribution will be distributed ratably to the holders of the Series A Preferred Stock and to the holders of any other class or series of our capital stock ranking on parity with the Series A Preferred Stock.

[0001633978-17-000095:notes:261]
Voting Rights

[0001633978-17-000095:notes:262]
The Series A Preferred Stock have no voting rights except as follows:

[0001633978-17-000095:notes:263]
| • | Authorize, approve, or make any change to the powers, preferences, privileges or rights of the Series A Preferred Stock; |

[0001633978-17-000095:notes:264]
| • | Authorize or issue any additional shares of Series A Preferred Stock or reduce the number of shares of Series A Preferred Stock; or |

[0001633978-17-000095:notes:265]
| • | Create, or hold capital stock in, any subsidiary that is not wholly-owned by the Company. |

[0001633978-17-000095:notes:266]
Dividends

[0001633978-17-000095:notes:267]
Holders of Series A Preferred Stock, in preference to holders of common stock or any other class or series of our outstanding capital stock ranking in any such event junior to the Series A Preferred Stock, are entitled to receive, when and as declared by the board of directors, quarterly cumulative cash dividends at the annual rate of 2.5% of the Issuance Value per share on each outstanding share of Series A Preferred Stock. The accrued dividends are payable on March 31, June 30, September 30 and December 31 of each year commencing on September 30, 2015.

[0001633978-17-000095:notes:268]
The accrued dividend as of July 1, 2017 and July 2, 2016 is $0.2 million and $0.2 million, respectively. During fiscal 2017, we paid $0.9 million in dividends to the holder of Series A Preferred Stock.

[0001633978-17-000095:notes:269]
Redemption

[0001633978-17-000095:notes:270]
Optional redemption by the Company

[0001633978-17-000095:notes:271]
On or after the third anniversary, we will have the option to redeem for cash all (but not less than all) of the shares of Series A Preferred Stock at a redemption price equal to the Issuance Value plus the accrued and unpaid dividends on each share and any past due dividends, whether or not authorized or declared.

[0001633978-17-000095:notes:272]
Optional redemption by holders

[0001633978-17-000095:notes:273]
Commencing on the fifth anniversary of the Issuance Date, each holder of Series A Preferred Stock may cause the Company to redeem for cash any number of shares of Series A Preferred Stock on any date at a redemption price for share redeemed equal to the Issuance Value plus the accrued and unpaid dividends on each share and any past due dividends, whether or not authorized or declared.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001633978-17-000095:notes:274]
In October 2016, FASB issued ASU 2016-16, Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets other than Inventory. The new guidance removes the prohibition in ASC 740 against the immediate recognition of the current and deferred income tax effects of intra-entity transfers of assets other than inventory. The new guidance will be effective for us in our first quarter of fiscal 2019. We do not believe that the adoption of this standard will have a material impact to our financial statements.

[0001633978-17-000095:notes:275]
In August 2016, FASB issued ASU 2016-15, Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments, which clarifies how companies present and classify certain cash receipts and cash payments in the statement of cash flows. ASU 2016-15 is effective for us in our first quarter of fiscal 2019 and earlier adoption is permitted. We are currently evaluating the impact of our pending adoption of ASU 2016-15 on our consolidated financial statements.

[0001633978-17-000095:notes:276]
In March 2016, FASB issued ASU 2016-09, Stock Compensation ASU 718 - Improvements to Employee Share-Based Payment Accounting. This guidance simplifies various aspects related to how share-based payments are accounted for and presented in the financial statements. This guidance is effective for fiscal years, and interim periods within those years, beginning after December 15, 2016. The Company will adopt this standard in in the first quarter of fiscal year 2018 by recording the cumulative impact of applying this guidance to retained earnings, which we estimate will increase by approximately $2.5 million.

[0001633978-17-000095:notes:277]
In February 2016, FASB issued ASU 2016-02, Leases. The new guidance generally requires an entity to recognize on its balance sheet operating and financing lease liabilities and corresponding right-of-use assets. The standard is effective for us in our first quarter of fiscal 2020 and early adoption is permitted. The Company is currently evaluating the impact of the adoption of ASU 2016-02 on its consolidated financial statements.

[0001633978-17-000095:notes:278]
In January 2016, FASB issued ASU 2016-01, Recognition and Measurement of Financial Assets and Financial Liabilities (Subtopic 825-10). The new standard provides guidance for the recognition, measurement, presentation and disclosure of financial instruments. This guidance is effective for annual and interim periods beginning after December 15, 2017 and early adoption is not permitted. The Company is currently evaluating the impact of the adoption of ASU 2016-01 on its consolidated financial statements.

[0001633978-17-000095:notes:279]
In May 2014, FASB issued ASU 2014-09, Revenue from Contracts with Customers, which amended the existing accounting standards for revenue recognition. ASU 2014-09 establishes principles for recognizing revenue upon the transfer of promised goods or services to customers, in an amount that reflects the consideration expected to be received in exchange for those goods or services. The new standard requires that reporting companies disclose the nature, amount, timing and uncertainty of revenue and cash flows arising from contracts with customers. On July 9, 2015, FASB agreed to delay the effective date by one year and, accordingly, the new standard is effective for the Company beginning in the first quarter of fiscal 2018. Early adoption is permitted, but not before the original effective date of the standard. The new standard is required to be applied retrospectively to each prior reporting period presented or retrospectively with the cumulative effect of initially applying it recognized at the date of initial application. The standard is effective for us for our first quarter of fiscal 2019. The Company is currently evaluating the impact of the adoption of ASU 2014-09 on its consolidated financial statements.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001633978-17-000095:notes:280]
Note 17. Employee Benefit Plans

[0001633978-17-000095:notes:281]
Employee Retirement Plans

[0001633978-17-000095:notes:282]
In the United States, the Company sponsors the Lumentum 401(k) Retirement Plan (the “401(k) Plan”) , a defined contribution plan under ERISA, which provides retirement benefits for its eligible employees through tax deferred salary deductions. The 401(k) Plan allows employees to contribute up to 50% of their annual compensation, with contributions limited to $18,000 in calendar year 2017 as set by the Internal Revenue Service.

[0001633978-17-000095:notes:283]
In Canada, the Company sponsors the Group Registered Retirement Savings (the “RRSP”) and Deferred Profit Sharing Plan (the “DPSP”), a defined contribution plan which provides retirement benefits for its eligible employees through tax deferred salary deductions.  The Plan allows employees to contribute up to 5% of their eligible earnings in a pay period, with contributions limited to in calendar year 2017 up to $20,062 (1) for the RRSP and $10,116 (2) for the DPSP, per Canada Revenue Agency. The RRSP contributions in excess of 5% of earnings are not subject to an employer’s contributions.

[0001633978-17-000095:notes:284]
The Company also makes a matching contribution equal to 100% of employees before-tax contributions up to 3% of their compensation and 50% of employees before-tax contributions to the next 2% of their compensation.  The Company match is contributed on a per-pay-period basis and is based on employees before-tax contributions and compensation each pay period for both the United Stated and Canada retirement plans.

[0001633978-17-000095:notes:285]
Employees are eligible for match contributions after completing 180 days of service.  All matching contributions are made in cash and vest immediately under both retirement plans. In fiscal 2017 and 2016, we made matching contributions to the 401(k) Plan in the amount of $4.0 million and $2.7 million, respectively. In fiscal 2017 and 2016, we made matching contributions in the amount of $0.7 million and $0.7 million under our Canada retirement plan.

[0001633978-17-000095:notes:286]
Employee Defined Benefit Plans

[0001633978-17-000095:notes:287]
During the third quarter of fiscal 2014, we assumed a defined benefit plan in connection with the acquisition of Time-Bandwidth. Prior to the third quarter of fiscal 2014, we did not have any significant defined benefit plans. This plan, which covers certain Swiss employees, is open to new participants and additional service costs are being accrued. Benefits are generally based upon age and compensation. As of July 1, 2017, the plan was partially funded. Our policy for partially funded plans is to make contributions equal to or greater than the requirements prescribed by law or regulation. Future estimated benefit payments are summarized below. No other required contributions to this defined benefit plan are expected in fiscal 2018, but we can, at our discretion, make contributions to the plan.

[0001633978-17-000095:notes:288]
We account for our obligations under this pension plan in accordance with the authoritative guidance which requires us to record our obligation to the participants, as well as the corresponding net periodic cost. We determine our obligation to the participants and our net periodic cost principally using actuarial valuations provided by third-party actuaries. The net obligation of $3.9 million as of July 1, 2017 is recorded in our consolidated balance sheets as non-current liabilities and is reflective of the total PBO less the fair value of plan assets.

[0001633978-17-000095:notes:289]
(1) CA$26,010 converted to U.S. dollars using the applicable exchange rate on July 1, 2017 (i.e., $0.7713), the last business day of fiscal 2017.

[0001633978-17-000095:notes:290]
(2) CA$13,115 converted to U.S. dollars using the applicable exchange rate on July 1, 2017 (i.e., $0.7713), the last business day of fiscal 2017.

[0001633978-17-000095:notes:291]
Assumptions

[0001633978-17-000095:notes:292]
Underlying both the calculation of the PBO and net periodic cost are actuarial valuations. These valuations use participant-specific information such as salary, age and assumptions about interest rates, compensation increases and other factors. At a minimum, we evaluate these assumptions annually and make changes as necessary.

[0001633978-17-000095:notes:293]
The discount rate reflects the estimated rate at which the pension benefits could be effectively settled. In developing the discount rate, we consider the yield available on an appropriate AA corporate bond index, adjusted to reflect the term of the scheme’s liabilities.

[0001633978-17-000095:notes:294]
The expected return on assets was estimated by using the weighted average of the real expected long-term return (net of inflation) on the relevant classes of assets based on the target asset mix and adding the chosen inflation assumption.

[0001633978-17-000095:notes:295]
The following table summarizes the assumptions used to determine net periodic cost and benefit obligation for the pension plan:

[0001633978-17-000095:notes:296]
|  | Pension Benefit Plans |
|  | 2017 |  | 2016 |
| Assumptions used to determine net periodic cost: |  |  |  |
| Discount rate | 0.2 | % |  | 1.1 | % |
| Expected long-term return on plan assets | 3.2 | % |  | 3.3 | % |
| Rate of pension increase | 2.3 | % |  | 2.3 | % |
| Assumptions used to determine benefit obligation at end of year: |  |  |  |
| Discount rate | 0.7 | % |  | 0.2 | % |
| Rate of pension increase | 2.3 | % |  | 2.3 | % |

[0001633978-17-000095:notes:297]
Fair Value Measurement of Plan Assets

[0001633978-17-000095:notes:298]
The following table sets forth the plan’s assets at fair value and the percentage of assets allocations as of July 1, 2017 (in millions, except percentage data).

[0001633978-17-000095:notes:299]
|  |  |  |  |  |  | Fair value measurement as of July 1, 2017 |
|  | Target Allocation | Total |  | Percentage of Plan Asset |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs (Level 2) |
| Assets: |  |  |  |  |  |  |  |  |  |
| Global equity | 24 | % |  | $ | 1.7 |  |  | 24 | % |  | $ | — |  |  | $ | 1.7 |  |
| Fixed income | 35 | % |  | 2.5 |  |  | 35 | % |  | — |  |  | 2.5 |  |
| Alternative Investment | 15 | % |  | 1.6 |  |  | 23 | % |  | — |  |  | 1.6 |  |
| Cash | 1 | % |  | 0.1 |  |  | 1 | % |  | 0.1 |  |  | — |  |
| Other | 25 | % |  | 1.2 |  |  | 17 | % |  | — |  |  | 1.2 |  |
| Total Assets |  |  | $ | 7.1 |  |  | 100 | % |  | $ | 0.1 |  |  | $ | 7.0 |  |

[0001633978-17-000095:notes:300]
The following table sets forth the plan’s assets at fair value and the percentage of assets allocations as of July 2, 2016 (in millions, except percentage data).

[0001633978-17-000095:notes:301]
|  |  |  |  |  |  | Fair value measurement as of July 2, 2016 |
|  | Target Allocation | Total |  | Percentage of Plan Asset |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs (Level 2) |
| Assets: |  |  |  |  |  |  |  |  |  |
| Global equity | 26 | % |  | $ | 1.2 |  |  | 26 | % |  | $ | — |  |  | $ | 1.2 |  |
| Fixed income | 37 | % |  | 1.7 |  |  | 36 | % |  | — |  |  | 1.7 |  |
| Alternative Investment | 19 | % |  | 0.9 |  |  | 19 | % |  | — |  |  | 0.9 |  |
| Cash | 1 | % |  | 0.1 |  |  | 2 | % |  | 0.1 |  |  | — |  |
| Other | 17 | % |  | 0.8 |  |  | 17 | % |  | — |  |  | 0.8 |  |
| Total Assets |  |  | $ | 4.7 |  |  | 100 | % |  | $ | 0.1 |  |  | $ | 4.6 |  |

[0001633978-17-000095:notes:302]
Our pension assets consist of multiple institutional funds (“pension funds”) of which the fair values are based on the quoted prices of the underlying funds. Pension funds are classified as Level 2 assets since such funds are not directly traded in active markets. Global equity consists of several funds that invest primarily in Swiss and Foreign equities; Fixed income consists of several funds that invest primarily in investment grade domestic and overseas bonds; Other consists of several funds that primarily invest in hedge fund, private equity, global real estate and infrastructure funds.

[0001633978-17-000095:notes:303]
Future Benefit Payments

[0001633978-17-000095:notes:304]
We estimate our expected benefit payments to defined benefit pension plan participants based on the same assumptions used to measure our PBO at year end which includes benefits attributable to estimated future compensation increases. Based on this approach, we expect to make payments of $0.9 million during the five year period between fiscal 2018 and fiscal 2022 and the remaining $3.0 million of payments in fiscal years subsequent to fiscal 2022.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001633978-17-000095:notes:305]
Note 20. Quarterly Financial Information (unaudited)

[0001633978-17-000095:notes:306]
The following table presents our quarterly consolidated statements of operations for fiscal 2017 and 2016 (in millions, except per share data):

[0001633978-17-000095:notes:307]
|  | July 1, 2017 |  | April 1, 2017 |  | December 31, 2016 |  | October 1, 2016 |  | July 2, 2016 (2) |  | April 2, 2016 (2) |  | December 26, 2015 (2) |  | September 26, 2015 (2) |
| Net revenue | $ | 222.7 |  |  | $ | 255.8 |  |  | $ | 265.0 |  |  | $ | 258.1 |  |  | $ | 241.7 |  |  | $ | 230.4 |  |  | $ | 218.3 |  |  | $ | 212.6 |  |
| Cost of sales | 154.0 |  |  | 172.0 |  |  | 176.3 |  |  | 174.7 |  |  | 160.5 |  |  | 165.9 |  |  | 148.5 |  |  | 144.0 |  |
| Amortization of acquired technologies | 1.4 |  |  | 1.7 |  |  | 1.7 |  |  | 1.7 |  |  | 1.7 |  |  | 1.7 |  |  | 1.7 |  |  | 1.7 |  |
| Gross profit | 67.3 |  |  | 82.1 |  |  | 87.0 |  |  | 81.7 |  |  | 79.5 |  |  | 62.8 |  |  | 68.1 |  |  | 66.9 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 35.4 |  |  | 37.3 |  |  | 38.7 |  |  | 36.9 |  |  | 36.4 |  |  | 35.3 |  |  | 35.0 |  |  | 34.4 |  |
| Selling, general and administrative | 26.0 |  |  | 28.1 |  |  | 31.0 |  |  | 25.1 |  |  | 29.5 |  |  | 28.0 |  |  | 25.8 |  |  | 34.0 |  |
| Restructuring and related charges | 2.0 |  |  | 3.1 |  |  | 4.0 |  |  | 2.9 |  |  | 3.5 |  |  | 1.8 |  |  | 1.1 |  |  | 1.0 |  |
| Total operating expenses | 63.4 |  |  | 68.5 |  |  | 73.7 |  |  | 64.9 |  |  | 69.4 |  |  | 65.1 |  |  | 61.9 |  |  | 69.4 |  |
| Income (loss) from operations | 3.9 |  |  | 13.6 |  |  | 13.3 |  |  | 16.8 |  |  | 10.1 |  |  | (2.3 | ) |  | 6.2 |  |  | (2.5 | ) |
| Unrealized (gain) loss on derivative liabilities | (29.7 | ) |  | (56.6 | ) |  | 4.8 |  |  | (22.7 | ) |  | 4.4 |  |  | (4.8 | ) |  | (2.4 | ) |  | 2.2 |  |
| Interest and other income (expense), net | (1.8 | ) |  | (1.4 | ) |  | (0.2 | ) |  | 0.2 |  |  | (0.1 | ) |  | (0.4 | ) |  | (0.5 | ) |  | (0.2 | ) |
| Income (loss) before income taxes | (27.6 | ) |  | (44.4 | ) |  | 17.9 |  |  | (5.7 | ) |  | 14.4 |  |  | (7.5 | ) |  | 3.3 |  |  | (0.5 | ) |
| (Benefit from) provisions for income taxes | 27.3 |  |  | 11.6 |  |  | 6.1 |  |  | (2.3 | ) |  | 0.1 |  |  | 0.1 |  |  | 0.5 |  |  | (0.3 | ) |
| Net income (loss) | $ | (54.9 | ) |  | $ | (56.0 | ) |  | $ | 11.8 |  |  | $ | (3.4 | ) |  | $ | 14.3 |  |  | $ | (7.6 | ) |  | $ | 2.8 |  |  | $ | (0.2 | ) |
| Net income (loss) attributable to common stockholders |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) per share attributable to common stockholders(1) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | (0.90 | ) |  | $ | (0.92 | ) |  | $ | 0.20 |  |  | $ | (0.06 | ) |  | $ | 0.24 |  |  | $ | (0.13 | ) |  | $ | 0.05 |  |  | $ | — |  |
| Diluted | $ | (0.90 | ) |  | $ | (0.92 | ) |  | $ | 0.19 |  |  | $ | (0.06 | ) |  | $ | 0.23 |  |  | $ | (0.13 | ) |  | $ | 0.05 |  |  | $ | — |  |
| Shares used in per share calculation attributable to common stockholders: (1) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | 61.3 |  |  | 61.0 |  |  | 60.3 |  |  | 59.9 |  |  | 59.4 |  |  | 59.2 |  |  | 59.0 |  |  | 58.8 |  |
| Diluted | 61.3 |  |  | 61.0 |  |  | 62.7 |  |  | 59.9 |  |  | 61.8 |  |  | 59.2 |  |  | 59.2 |  |  | 58.8 |  |

[0001633978-17-000095:notes:308]
| (1) | On August 1, 2015, JDSU distributed 47.1 million shares, or 80.1% of the outstanding shares of Lumentum common stock to existing holders of JDSU common stock. JDSU was renamed Viavi and at the time of the distribution, retained 11.7 million shares, or 19.9% of Lumentum’s outstanding shares. Basic and diluted net income (loss) income per share for all periods through June 27, 2015 is calculated using the shares of Lumentum common stock outstanding on August 1, 2015. Refer to “Note 4. Earnings Per Share” in the Notes to Consolidated Financial Statements. |

[0001633978-17-000095:notes:309]
| (2) | During the three months ended July 2, 2016 we corrected an error relating to the understatement of the restructuring expense of $0.2 million, $0.2 million and $0.4 million for the three months ended September 26, 2015, December 26, 2015 and April 2, 2016, respectively, resulting in the overstatement of restructuring expense of $0.8 million for the three months ended July 2, 2016. During the three months ended April 2, 2016, we corrected an error relating to stock-based compensation expense for the three months ended December 26, 2015 in which stock-based compensation expense of $1.0 million was excluded for a specific restricted stock grant, resulting in the overstatement of stock-based compensation expense of $1.0 million for the three months ended April 2, 2016. Additionally during the three months ended April 2, 2016, we corrected an error relating to the overstatement of sales and use tax expense of $0.2 million and $0.3 million for the three months ended September 26, 2015 and December 26, 2015, respectively, resulting in the understatement of sales and use tax expense of $0.5 million for the three months ended April 2, 2016. During the three months ended December 26, 2015, we corrected an error relating to the determination of the accretion amount of Series A preferred stock for the three months ended September 26, 2015 in which the accretion of the discount related to issuance cost of $2.0 million was excluded, resulting in the overstatement of the accretion of Series A preferred stock of $2.0 million for the three months ended December 26, 2015. |

[0001633978-17-000095:notes:310]
As a result, our net loss attributable to common stockholders and basic and diluted net loss per share attributable to common stockholders included in our quarterly report on Form 10-Q (“Form 10-Q”) for the three months ended September 26, 2015 was understated by $2.0 million and $0.03 per basic and diluted share, respectively. Our net income attributable to common stockholders and basic and diluted net income per share attributable to common stockholders included in Form 10-Q for the three months ended December 26, 2015 was understated by $0.9 million and $0.02 per basic and diluted share, respectively.  Our net loss attributable to common stockholders included in Form 10-Q for the three months ended April 2, 2016 was understated by $0.1 million, there was no impact to earnings per share, both basic and diluted. Our net income attributable to common stockholders and basic and diluted net loss per share attributable to common stockholders for the three months ended July 2, 2016 was overstated by $0.8 million and $0.01 per basic and diluted share, respectively.

[0001633978-17-000095:notes:311]
We assessed the materiality of these errors and determined that the above errors were not material to our unaudited consolidated financial statements as of each of the periods mentioned above.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001633978-17-000095:notes:312]
Note 3. Related Party Transactions

[0001633978-17-000095:notes:313]
Transactions with Viavi

[0001633978-17-000095:notes:314]
During the fiscal year ended July 1, 2017, the Company recognized revenue of $3.6 million from products sold to Viavi. During the fiscal year ended July 1, 2017, the Company recorded $0.5 million in research and development cost reimbursement and $0.7 million in sublease rental income. As of July 1, 2017, the Company had $0.1 million in trade accounts receivable due from Viavi and $0.5 million in other receivables from Viavi. As of July 1, 2017, the Company had $0.2 million in trade payables due to Viavi.

[0001633978-17-000095:notes:315]
During the fiscal year ended July 1, 2017, the Company recorded $0.6 million in other income, which resulted from a tax indemnification agreement between Lumentum and Viavi.  As a result, the Company had $0.6 million in other non-current assets due  from Viavi as of July 1, 2017.

[0001633978-17-000095:notes:316]
During the fiscal year ended July 2, 2016, the Company recognized revenue of $3.3 million from products sold to Viavi. During the fiscal year ended July 2, 2016, the Company recorded $2.3 million in research and development cost reimbursement and $0.7 million in sublease rental income. As of July 2, 2016, the Company had $1.1 million in accounts receivable due from Viavi.

[0001633978-17-000095:notes:317]
On July 31, 2015, the Company also entered into the following agreements with Viavi:

[0001633978-17-000095:notes:318]
| a) | Contribution Agreement which identified the assets transferred, the liabilities assumed and the contracts assigned and it provided for when and how these transfers, assumptions and assignments would occur. |

[0001633978-17-000095:notes:319]
| b) | Separation and Distribution Agreement which governs the Separation of the Lumentum business and other matters related to Lumentum’s relationship with Viavi. |

[0001633978-17-000095:notes:320]
| c) | Tax Matters Agreement which governs the respective rights, responsibilities and obligations of Lumentum and Viavi with respect to tax liabilities and benefits, attributes, proceedings, returns and certain other tax matters. |

[0001633978-17-000095:notes:321]
| d) | Employee Matters Agreement which governs the compensation and employee benefit obligations with respect to the current and former employees of Lumentum and Viavi, the treatment of equity based compensation and generally allocates liabilities and responsibilities relating to employee compensation, benefit plans and programs. The Employee Matters Agreement provides that employees of Lumentum will participate in benefit plans sponsored or maintained by Lumentum. |

[0001633978-17-000095:notes:322]
| e) | Securities Purchase Agreement, which also includes Amada Holdings Co., Ltd. (“Amada”), a customer of the Company, as a party, which sets forth the terms for the sale by Viavi to Amada of shares of Series A Preferred Stock (the “Series A Preferred Stock”) of Lumentum Inc., our wholly-owned subsidiary, following the Separation. |

[0001633978-17-000095:notes:323]
| f) | Intellectual Property Matters Agreement which outlines the intellectual property rights of Lumentum and Viavi following the Separation, as well as non-compete restrictions between Viavi and Lumentum. |

[0001633978-17-000095:notes:324]
Allocated Costs

[0001633978-17-000095:notes:325]
From June 28, 2015 to August 1, 2015, the Separation date, the consolidated statements of operations included our direct expenses for cost of sales, research and development, sales and marketing, and administration as well as allocations of expenses arising from shared services and infrastructure provided by Viavi to us. These allocated expenses include costs of information technology, human resources, accounting, legal, real estate and facilities, corporate marketing, insurance, treasury and other corporate and infrastructure services. In addition, other costs allocated to us include restructuring and stock-based compensation related to Viavi’s corporate and shared services employees and are included in the table below. These expenses were allocated to us using estimates that we consider to be a reasonable reflection of the utilization of services or benefits received by our business. The allocation methods include revenue, headcount, square footage, actual consumption and usage of services and others.

[0001633978-17-000095:notes:326]
There were no allocations of expenses from Viavi for the fiscal year ended July 1, 2017. During the fiscal years ended July 2, 2016 and June 27, 2015, allocated costs from Viavi included in the accompanying consolidated statements of operations were as follows (in millions):

[0001633978-17-000095:notes:327]
|  | Years Ended |
|  | July 2, 2016 |  | June 27, 2015 |
| Research and development | $ | — |  |  | $ | 0.4 |  |
| Selling, general and administrative | 11.7 |  |  | 82.5 |  |
| Restructuring and related charges | — |  |  | 3.9 |  |
| Interest and other (income) expenses, net | (0.1 | ) |  | 0.4 |  |
| Interest expense | 0.1 |  |  | 0.7 |  |
| Total allocated costs | $ | 11.7 |  |  | $ | 87.9 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001633978-17-000095:notes:328]
Note 14. Restructuring and Related Charges

[0001633978-17-000095:notes:329]
We have initiated various strategic restructuring events primarily intended to reduce costs, consolidate our operations, rationalize the manufacturing of our products and align our business in response to the market conditions. As of July 1, 2017 and July 2, 2016, our total restructuring accrual was $3.8 million and $5.7 million, respectively. During fiscal 2017, 2016 and 2015, we recorded $12.0 million, $7.7 million and $11.6 million, respectively, in restructuring and related charges in the consolidated statements of operations. Of the $12.0 million and $7.7 million charge recorded during fiscal 2017 and fiscal 2016, $2.1 million and $2.1 million, respectively, related to severance, retention and employee benefits and there were no costs allocated to us by Viavi. Of the $11.6 million charge recorded during fiscal 2015, $3.9 million related to costs allocated to us by Viavi for plans impacting Viavi’s corporate and shared services employees. Our restructuring charges include severance and benefit costs to eliminate a specified number of positions, facilities and equipment costs to vacate facilities and consolidate operations, and lease termination costs. The timing of associated cash payments is dependent upon the type of restructuring charge and can extend over multiple periods.

[0001633978-17-000095:notes:330]
Summary of Restructuring Plans

[0001633978-17-000095:notes:331]
The adjustments to the restructuring accrual related to all of our restructuring plans described below as of July 1, 2017, were as follows (in millions):

[0001633978-17-000095:notes:332]
|  | Fiscal 2015 Restructuring Plan |  | Fiscal 2016 Restructuring Plan |  |  |
|  | Restructuring Charges |  | Exit Costs |  | Restructuring Charges |  | Other Charges |  | Total |
| Liability as of July 2, 2016 | $ | 4.5 |  |  | $ | 0.5 |  |  | $ | 0.7 |  |  | $ | — |  |  | $ | 5.7 |  |
| Charges | 2.1 |  |  | — |  |  | — |  |  | 9.9 |  |  | 12.0 |  |
| Payments | (3.2 | ) |  | (0.1 | ) |  | (0.7 | ) |  | (9.9 | ) |  | (13.9 | ) |
| Liability as of July 1, 2017 | $ | 3.4 |  |  | $ | 0.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 3.8 |  |

[0001633978-17-000095:notes:333]
As of July 1, 2017, our restructuring liability includes $3.8 million in other current liabilities. There is no non-current liabilities related to restructuring on our consolidated balance sheet as of July 1, 2017.

[0001633978-17-000095:notes:334]
As of July 2, 2016, our restructuring liability includes $5.5 million in other current liabilities and $0.2 million in other non-current liabilities on the consolidated balance sheet.

[0001633978-17-000095:notes:335]
Fiscal 2016 Plan

[0001633978-17-000095:notes:336]
In the fourth quarter of 2016, our management approved and commenced the 2016 Restructuring Program primarily intended to reduce costs, consolidate our operations, rationalize the manufacturing of our products and align our business in response to the market conditions.

[0001633978-17-000095:notes:337]
Fiscal 2015 Plans

[0001633978-17-000095:notes:338]
Separation Restructuring Plan

[0001633978-17-000095:notes:339]
During the second and fourth quarters of fiscal 2015, management approved restructuring plans impacting our OpComms segment to optimize operations and gain efficiencies by closing the Bloomfield, Connecticut site and consolidating roles and responsibilities across functions as we moved forward with our Separation plan. As a result, a restructuring charge of $4.6 million was recorded for severance and employee benefits during fiscal 2015. In total approximately 200 employees in manufacturing, R&D and SG&A functions located in North America, Europe and Asia were impacted. Payments related to the remaining severance and benefits accrual have been paid in full in fiscal 2017.

[0001633978-17-000095:notes:340]
Robbinsville Closure Plan

[0001633978-17-000095:notes:341]
During the first quarter of fiscal 2015, management approved a plan impacting our OpComms segment to optimize operations and gain efficiencies by closing the Robbinsville, New Jersey site and consolidating roles and responsibilities across North America.  As a result, a restructuring charge of $1.5 million was recorded for severance and benefits during fiscal 2015. In total approximately 30 employees in manufacturing, R&D and SG&A functions located in North America were impacted.

[0001633978-17-000095:notes:342]
Ottawa Lease Exit Costs

[0001633978-17-000095:notes:343]
During fiscal 2008, we recorded lease exit charges, net of assumed sub-lease income related to our Ottawa facility which was included in selling, general and administrative expenses as the space was never occupied and we had no need for the space in the foreseeable future due to changes in business requirements.

[0001633978-17-000095:notes:344]
For the fiscal year ended July 1, 2017, we had cash settlements of $0.1 million. The fair value of the remaining contractual obligations, net of sublease income is $0.4 million and $0.5 million, as of July 1, 2017 and July 2, 2016, respectively. As of July 1, 2017 and July 2, 2016, $0.4 million and $0.3 million was included in other current liabilities on the consolidated balance sheets. As of July 2, 2016, $0.2 million was included in other non-current liabilities on the consolidated balance sheets. There were no other non-current liabilities on the consolidated balance sheets as of year ended July 1, 2017. The payments related to these lease costs are expected to be paid by the end of the third quarter of fiscal 2018.

[0001633978-17-000095:notes:345]
In the third quarter of fiscal 2015, we released $0.9 million of accrued lease exit charges for reusing certain spaces of our Ottawa facility. During fiscal 2015, we recorded $0.7 million benefit in the SG&A charges, plus we had cash settlements of $1.0 million and other non-cash benefits of $0.3 million.


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001633978-17-000095:notes:346]
Long-lived assets, namely net property, plant and equipment were identified based on the operations in the corresponding geographic areas (in millions):

[0001633978-17-000095:notes:347]
|  | Years Ended |
|  | July 1, 2017 |  | July 2, 2016 |
| Property, Plant and Equipment, net |  |  |  |
| United States | $ | 88.2 |  |  | $ | 69.0 |  |
| Canada | 13.8 |  |  | 21.4 |  |
| China | 82.5 |  |  | 46.6 |  |
| Thailand | 85.3 |  |  | 43.8 |  |
| Other Asia-Pacific | 1.9 |  |  | 0.2 |  |
| EMEA | 1.8 |  |  | 2.4 |  |
| Total long-lived assets | $ | 273.5 |  |  | $ | 183.4 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001633978-17-000095:notes:348]
The components of inventories were as follows (in millions):

[0001633978-17-000095:notes:349]
|  | July 1, 2017 |  | July 2, 2016 |
| Finished goods | $ | 71.7 |  |  | $ | 46.1 |  |
| Work in process | 49.4 |  |  | 25.5 |  |
| Raw materials and purchased parts | 24.1 |  |  | 29.0 |  |
| Inventories | $ | 145.2 |  |  | $ | 100.6 |  |


## us-gaap:ScheduleOfOtherCurrentAssetsTableTextBlock

[0001633978-17-000095:notes:350]
The components of prepayments and other current assets were as follows (in millions):

[0001633978-17-000095:notes:351]
|  | July 1, 2017 |  | July 2, 2016 |
| Capitalized manufacturing overhead | $ | 30.1 |  |  | $ | 27.3 |  |
| Prepayments | 12.3 |  |  | 6.4 |  |
| Advances to contract manufacturers | 10.5 |  |  | 10.3 |  |
| Due from Viavi, net | 0.5 |  |  | 2.0 |  |
| Other current assets | 10.1 |  |  | 15.3 |  |
| Prepayments and other current assets | $ | 63.5 |  |  | $ | 61.3 |  |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001633978-17-000095:notes:352]
During fiscal 2017, 2016 and 2015, net revenue generated from a single customer which represented 10% or greater of total net revenue is summarized as follows:

[0001633978-17-000095:notes:353]
|  | Years Ended |
|  | July 1, 2017 |  | July 2, 2016 |  | June 27, 2015 |
| Customer A | 18.5 | % |  | 17.1 | % |  | 14.4 | % |
| Customer B | 16.7 | % |  | 17.1 | % |  | * |  |
| Customer C | 12.4 | % |  | 13.0 | % |  | 11.8 | % |
| *Represents less than 10% of total net revenue |  |  |  |  |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001633978-17-000095:notes:354]
The following table presents net revenue by the three geographic regions we operate in and net revenue from countries that exceeded 10% of our total net revenue (in millions, except percentage data):

[0001633978-17-000095:notes:355]
|  | Years Ended |
|  | July 1, 2017 |  | July 2, 2016 |  | June 27, 2015 |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 147.9 |  |  | 14.8 | % |  | $ | 162.3 |  |  | 18.0 | % |  | $ | 162.4 |  |  | 19.4 | % |
| Mexico | 185.1 |  |  | 18.5 |  |  | 112.9 |  |  | 12.5 |  |  | 112.7 |  |  | 13.5 |  |
| Other Americas | 9.2 |  |  | 0.9 |  |  | 19.6 |  |  | 2.2 |  |  | 31.1 |  |  | 3.6 |  |
| Total Americas | $ | 342.2 |  |  | 34.2 | % |  | $ | 294.8 |  |  | 32.7 | % |  | $ | 306.2 |  |  | 36.5 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 226.7 |  |  | 22.6 | % |  | $ | 214.0 |  |  | 23.7 | % |  | $ | 120.4 |  |  | 14.4 | % |
| Japan | 99.2 |  |  | 9.9 |  |  | 92.9 |  |  | 10.3 |  |  | 106.6 |  |  | 12.7 |  |
| Other Asia-Pacific | 225.4 |  |  | 22.5 |  |  | 177.8 |  |  | 19.6 |  |  | 174.4 |  |  | 20.9 |  |
| Total Asia-Pacific | $ | 551.3 |  |  | 55.0 | % |  | $ | 484.7 |  |  | 53.6 | % |  | $ | 401.4 |  |  | 48.0 | % |
| EMEA | $ | 108.1 |  |  | 10.8 | % |  | $ | 123.5 |  |  | 13.7 | % |  | $ | 129.5 |  |  | 15.5 | % |
| Total net revenue | $ | 1,001.6 |  |  |  |  | $ | 903.0 |  |  |  |  | $ | 837.1 |  |  |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001633978-17-000095:notes:356]
Information on reportable segments utilized by our CODM is as follows (in millions):

[0001633978-17-000095:notes:357]
|  | Years Ended |
|  | July 1, 2017 |  | July 2, 2016 |  | June 27, 2015 |
| Net revenue: |  |  |  |  |  |
| OpComms | $ | 857.8 |  |  | $ | 761.3 |  |  | $ | 694.1 |  |
| Lasers | 143.8 |  |  | 141.7 |  |  | 143.0 |  |
| Net revenue | $ | 1,001.6 |  |  | $ | 903.0 |  |  | $ | 837.1 |  |
| Gross profit: |  |  |  |  |  |
| OpComms | 287.3 |  |  | 236.3 |  |  | 204.8 |  |
| Lasers | 59.9 |  |  | 61.4 |  |  | 67.4 |  |
| Total segment gross profit | 347.2 |  |  | 297.7 |  |  | 272.2 |  |
| Unallocated amounts: |  |  |  |  |  |
| Stock-based compensation | (7.5 | ) |  | (6.1 | ) |  | (5.1 | ) |
| Amortization of intangibles | (6.5 | ) |  | (6.8 | ) |  | (7.6 | ) |
| Other charges | (15.1 | ) |  | (7.5 | ) |  | (1.6 | ) |
| Gross profit | $ | 318.1 |  |  | $ | 277.3 |  |  | $ | 257.9 |  |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001633978-17-000095:notes:358]
The following additional financial statement schedules should be considered in conjunction with our consolidated financial statements. All other financial statement schedules have been omitted because the required information is not present in amounts sufficient to require submission of the schedule, not applicable, or because the required information is included in the Consolidated Financial Statements or Notes thereto.

[0001633978-17-000095:notes:359]
LUMENTUM HOLDINGS INC.

[0001633978-17-000095:notes:360]
FINANCIAL STATEMENT SCHEDULES

[0001633978-17-000095:notes:361]
SCHEDULE II - VALUATION AND QUALIFYING ACCOUNTS

[0001633978-17-000095:notes:362]
|  | (in millions) |
|  | Balance atBeginningof Period |  | Increase (decrease) toCosts andExpenses |  | WriteOffs |  | Balanceat End ofPeriod |
| Accounts receivable allowance: |  |  |  |  |  |  |  |
| Fiscal year ended July 1, 2017 | $ | 0.9 |  |  | $ | 1.0 |  |  | $ | (0.1 | ) |  | $ | 1.8 |  |
| Fiscal year ended July 2, 2016 | $ | 1.2 |  |  | $ | 0.6 |  |  | $ | (0.9 | ) |  | $ | 0.9 |  |

[0001633978-17-000095:notes:363]
|  |  | (in millions) |
| Description |  | Balance at Beginning of Period |  | Additions Charged to Expenses or Other Accounts* |  | Deductions Credited to Expenses or Other Accounts** |  | Balance at End of Period |
| 2017 |  |  |  |  |  |  |  |  |
| Deferred tax valuation allowance |  | $ | 321.4 |  |  | $ | 16.7 |  |  | $ | (41.7 | ) |  | $ | 296.4 |  |
| 2016 |  |  |  |  |  |  |  |  |
| Deferred tax valuation allowance |  | $ | 160.0 |  |  | $ | 214.3 |  |  | $ | (52.9 | ) |  | $ | 321.4 |  |
| 2015 |  |  |  |  |  |  |  |  |
| Deferred tax valuation allowance |  | $ | 184.6 |  |  | $ | 3.4 |  |  | $ | (28.0 | ) |  | $ | 160.0 |  |

[0001633978-17-000095:notes:364]
*    Additions include current year additions charged to expenses and current year build due to increases in net deferred tax assets, return to provision true-ups, other adjustments to deferred taxes.

[0001633978-17-000095:notes:365]
**    Deductions include current year releases credited to expenses and current year reductions due to decreases in net deferred tax assets, return to provision true-ups, other adjustments to deferred taxes.


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001633978-17-000095:notes:366]
The table below discloses the percentage of our total net revenue attributable to each of our two reportable segments. In addition, it discloses the percentage of our total net revenue attributable to our product offerings which serve the Telecom, Datacom and consumer and industrial (“Consumer and Industrial”) markets which accounted for more than 10% or more of our total net revenue during the last three fiscal years:

[0001633978-17-000095:notes:367]
|  | Years Ended |
|  | July 1, 2017 |  | July 2, 2016 |  | June 27, 2015 |
| OpComms: |  | 85.6 | % |  |  | 84.3 | % |  |  | 82.9 | % |
| Telecom |  | 61.0 | % |  |  | 61.5 | % |  |  | 60.6 | % |
| Datacom |  | 20.1 | % |  |  | 18.1 | % |  |  | 17.4 | % |
| Consumer and Industrial |  | 4.5 | % |  |  | 4.7 | % |  |  | 4.9 | % |
| Lasers |  | 14.4 | % |  |  | 15.7 | % |  |  | 17.1 | % |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001633978-17-000095:notes:368]
Note 19. Operating Segments and Geographic Information

[0001633978-17-000095:notes:369]
Our chief executive officer is our Chief Operating Decision Maker (“CODM”). The CODM allocates resources to the segments based on their business prospects, competitive factors, net revenue and gross margin.

[0001633978-17-000095:notes:370]
We are an industry leading provider of optical and photonic products defined by revenue and market share addressing a range of end-market applications including optical communications and commercial lasers. We have two operating segments, Optical Communications, which we refer to as OpComms, and Commercial Lasers, which we refer to as Lasers. The two operating segments were primarily determined based on how the CODM views and evaluates our operations. Operating results are regularly reviewed by the CODM to make decisions about resources to be allocated to the segments and to assess their performance. Other factors, including market separation and customer specific applications, go-to-market channels, products and manufacturing, are considered in determining the formation of these operating segments.

[0001633978-17-000095:notes:371]
OpComms

[0001633978-17-000095:notes:372]
Our OpComms products address the following markets: telecommunications (Telecom), data communications (Datacom) and Consumer and Industrial.

[0001633978-17-000095:notes:373]
Our OpComms products include a wide range of components, modules and subsystems to support and maintain customers in our two primary markets: Telecom and Datacom. The Telecom market includes carrier networks for access (local), metro (intracity), long-haul (city-to-city and worldwide) and submarine (undersea) networks. The Datacom market addresses enterprise, cloud and data center applications, including storage-access networks (“SANs”), local-area networks (“LANs”) and wide-area networks (“WANs”). These products enable the transmission and transport of video, audio and text data over high-capacity fiber-optic cables. We maintain leading positions in the fast growing OpComms markets, including reconfigurable optical add/drop multiplexers (“ROADMs”), tunable 10-gigabit small form-factor pluggable transceivers and tunable small form-factor pluggable transceivers. Our 10G, 40G legacy transceivers and a growing portfolio of 100G pluggable transceivers support LAN/SAN/WAN needs and the cloud for customers building enterprise and hyperscale data center networks.

[0001633978-17-000095:notes:374]
In the Consumer and Industrial markets, our OpComms products include laser light sources, which are integrated into 3D sensing platforms being used in applications for mobile devices, gaming, computers, virtual and augmented reality, other consumer electronics devices, and industrial segments. These systems simplify the way people interact with technology by enabling the use of natural body gestures, like the wave of a hand, to control a product or application. Systems can also be used for identification, safety, and process efficiency, among numerous other application spaces. Emerging applications for this technology include various mobile device applications, autonomous vehicles, self-navigating robotics and drones in industrial applications and 3D capture of objects coupled with 3D printing. Our laser light sources are also used in a variety of other industrial laser and processing applications.

[0001633978-17-000095:notes:375]
Lasers

[0001633978-17-000095:notes:376]
Our Lasers products serve our customers in markets and applications such as sheet metal processing, general manufacturing, biotechnology, graphics and imaging, remote sensing, and precision machining such as drilling in printed circuit boards, wafer singulation, glass cutting and solar cell scribing.

[0001633978-17-000095:notes:377]
Our Lasers products are used in a variety of original equipment manufacturer (“OEM”) applications including diode-pumped solid-state, fiber, diode, direct-diode and gas lasers such as argon-ion and helium-neon lasers. Fiber lasers provide kW-class output powers combined with excellent beam quality and are used in sheet metal processing and metal welding applications. Diode-pumped solid-state lasers provide excellent beam quality, low noise and exceptional reliability and are used in biotechnology, graphics and imaging, remote sensing, materials processing and precision machining applications. Diode and direct-diode lasers address a wide variety of applications, including laser pumping, thermal exposure, illumination, ophthalmology, image recording, printing, plastic welding and selective soldering. Gas lasers such as argon-ion and helium-neon lasers provide a stable, low-cost and reliable solution over a wide range of operating conditions, making them well suited for complex, high-resolution OEM applications such as flow cytometry, DNA sequencing, graphics and imaging and semiconductor inspection.

[0001633978-17-000095:notes:378]
Our acquisition of Time-Bandwidth enabled us to provide high-powered and ultrafast lasers for the industrial and scientific markets. Manufacturers use high-power, ultrafast lasers to create micro parts for consumer electronics and to process semiconductor, LED, and other types of chips. Use of ultrafast lasers for micromachining applications is being driven primarily by the increasing use of consumer electronics and connected devices globally.

[0001633978-17-000095:notes:379]
We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments because management does not include the information in its measurement of the performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, stock-based compensation and certain other charges impacting the gross margin of each segment because management does not include this information in its measurement of the performance of the operating segments. Other charges are primarily warranty expenses that were accrued and which are expected to be reimbursed by the manufacturer.

[0001633978-17-000095:notes:380]
We operate in three geographic regions: Americas, Asia-Pacific, and EMEA (Europe, Middle East, and Africa). Net revenue is assigned to the geographic region and country where our product is initially shipped. For example, certain customers may request shipment of our product to a contract manufacturer in one country, which may differ from the location of their end customers. The following table presents net revenue by the three geographic regions we operate in and net revenue from countries that exceeded 10% of our total net revenue (in millions, except percentage data):

[0001633978-17-000095:notes:381]
In March 2017, we completed the purchase of a property in Thailand for approximately $9.9 million in cash. This property will provide additional manufacturing capacity for future growth. The building was valued at $5.5 million and the land was valued at $4.4 million.

[0001633978-17-000095:notes:382]
We purchase a substantial portion of our inventory from contract manufacturers and vendors located primarily in Thailand and China. For the fiscal year ended 2017, 50% total inventory was purchased from a single contract manufacturer, 27% and 14%, respectively, were purchased from two other contract manufacturers.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001633978-17-000095:notes:383]
Note 7. Balance Sheet Details

[0001633978-17-000095:notes:384]
Accounts receivable allowances

[0001633978-17-000095:notes:385]
As of July 1, 2017 and July 2, 2016, our accounts receivable allowance balance was $1.8 million and $0.9 million, respectively.

[0001633978-17-000095:notes:386]
Inventories

[0001633978-17-000095:notes:387]
Prepayments and other current assets

[0001633978-17-000095:notes:388]
Amount due from Viavi, net represents certain obligations to be reimbursed from Viavi pursuant to the Separation and Distribution Agreement and Contribution Agreement.

[0001633978-17-000095:notes:389]
Property, plant and equipment, net

[0001633978-17-000095:notes:390]
During fiscal 2017, 2016 and 2015, we recorded depreciation expense of $54.2 million, $47.4 million and $43.0 million, respectively. Our construction in progress includes primarily machinery and equipment that was purchased to increase our manufacturing capacity. We expect to place these assets in service in the next 12 months.

[0001633978-17-000095:notes:391]
Other current liabilities

[0001633978-17-000095:notes:392]
Other non-current liabilities
