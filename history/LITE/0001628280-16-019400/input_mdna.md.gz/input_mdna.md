# LITE MD&A — 0001628280-16-019400


## mdna

[0001628280-16-019400:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001628280-16-019400:mdna:2]
You should read the following discussion in conjunction with the audited consolidated financial statements and the corresponding notes included elsewhere in this Annual Report. This Management's Discussion and Analysis of Financial Condition and Results of Operations contains forward-looking statements. The matters discussed in these forward-looking statements are subject to risk, uncertainties and other factors that could cause actual results to differ materially from those made, projected or implied in the forward-looking statements. Please see "Risk Factors" and "Forward-Looking Statements" for a discussion of the uncertainties, risks and assumptions associated with these statements.

[0001628280-16-019400:mdna:3]
Overview

[0001628280-16-019400:mdna:4]
We are an industry leading provider of optical and photonic products defined by revenue and market share addressing a range of end-market applications including optical communications and commercial lasers. We have two operating segments, Optical Communications, which we refer to as OpComms, and Commercial Lasers, which we refer to as Lasers. The two operating segments were primarily determined based on how the Chief Operating Decision Mater (“CODM”) views and evaluates our operations. Operating results are regularly reviewed by the CODM to make decisions about resources to be allocated to the segments and to assess their performance. Other factors, including market separation and customer specific applications, go-to-market channels, products and manufacturing, are considered in determining the formation of these operating segments.

[0001628280-16-019400:mdna:5]
OpComms

[0001628280-16-019400:mdna:6]
Our OpComms products address the following markets: telecommunications (Telecom), data communications (Datacom) and Consumer and Industrial.

[0001628280-16-019400:mdna:7]
Our OpComms products include a wide range of components, modules and subsystems to support and maintain customers in our two primary markets: Telecom and Datacom. The Telecom market includes carrier networks for access (local), metro (intracity), long-haul (city-to-city and worldwide) and submarine (undersea) networks. The Datacom market addresses enterprise, cloud and data center applications, including storage-access networks (“SANs”), local-area networks (“LANs”) and wide-area networks (“WANs”). These products enable the transmission and transport of video, audio and text data over high-capacity fiber-optic cables. We maintain leading positions in the fastest-growing OpComms markets, including reconfigurable optical add/drop multiplexers (“ROADMs”), tunable 10-gigabit small form-factor pluggable transceivers and tunable small form-factor pluggables. Our 10G, 40G legacy transceivers and a growing portfolio of 100G pluggable transceivers support LAN/SAN/WAN needs and the cloud for customers building enterprise and hyperscale data center networks.

[0001628280-16-019400:mdna:8]
Our products for 3-D sensing applications include our light source product. Customer solutions containing our 3-D sensing lasers employ our laser technology in mobile, computing, industrial and automotive applications. Emerging 3-D sensing systems simplify the way people interact with technology and were first used in applications for gaming platforms.

[0001628280-16-019400:mdna:9]
In the Consumer and Industrial markets, our OpComms products include our light source product which is integrated into 3-D sensing platforms being used in applications for gaming, computing, mobile and industrial segments. These systems simplify the way people interact with technology by enabling the use of natural body gestures, like the wave of a hand, to control a product or application. Emerging applications for this technology include various mobile device applications, autonomous vehicles, self-navigating robotics and drones in industrial applications and 3-D capture of objects coupled with 3-D printing.

[0001628280-16-019400:mdna:10]
Our OpComms customers include Ciena Corporation, Cisco Systems, Inc., Coriant GmbH, Fujitsu, Alphabet Inc. (formerly Google), Huawei Technologies Co. Ltd., Microsoft Corporation and Nokia Networks (including Alcatel-Lucent International).

[0001628280-16-019400:mdna:11]
Lasers

[0001628280-16-019400:mdna:12]
Our Lasers products serve our customers in markets and applications such as manufacturing, biotechnology, graphics and imaging, remote sensing, and precision machining such as drilling in printed circuit boards, wafer singulation and solar cell scribing. Our Lasers products are used in a variety of original equipment manufacturer (“OEM”) applications.

[0001628280-16-019400:mdna:13]
Our Laser products are used in a variety of OEM applications including diode-pumped solid-state, fiber, diode, direct-diode and gas lasers such as argon-ion and helium-neon lasers. Diode-pumped solid-state and fiber lasers provide excellent beam quality, low noise and exceptional reliability and are used in biotechnology, graphics and imaging, remote sensing, materials processing and precision machining applications. Diode and direct-diode lasers address a wide variety of applications, including laser pumping, thermal exposure, illumination, ophthalmology, image recording, printing, plastic welding and selective soldering. Gas lasers such as argon-ion and helium-neon lasers provide a stable, low-cost and reliable solution over a wide range of operating conditions, making them well suited for complex, high-resolution OEM applications such as flow cytometry, DNA sequencing, graphics and imaging and semiconductor inspection.

[0001628280-16-019400:mdna:14]
Our acquisition of Time-Bandwidth enabled us to provide high-powered and ultrafast lasers for the industrial and scientific markets. Manufacturers use high-power, ultrafast lasers to create micro parts for consumer electronics and to process semiconductor, LED, and other types of chips. Use of ultrafast lasers for micromachining applications is being driven primarily by the increasing use of consumer electronics and connected devices globally.

[0001628280-16-019400:mdna:15]
Our Lasers customers include Amada Co., Ltd., ASML Holding N.V., Beckman Coulter, Inc., Becton, Dickinson and Company, DISCO Corporation, Electro Scientific Industries, Inc., EO Technics Co., Ltd. and KLA-Tencor Corporation.

[0001628280-16-019400:mdna:16]
Separation from JDSU

[0001628280-16-019400:mdna:17]
Lumentum Holdings Inc. was incorporated in Delaware as a wholly owned subsidiary of JDS Uniphase Corporation (“JDSU”) on February 10, 2015 and is comprised of the former communications and commercial optical products (“CCOP”) segment and the WaveReady product lines of JDSU. On August 1, 2015, we became an independent publicly-traded company through the distribution by JDSU to its stockholders of 80.1% of our outstanding common stock (the “Separation”).   Each JDSU stockholder of record as of the close of business on July 27, 2015 received one share of Lumentum common stock for every five shares of JDSU common stock held on the record date. JDSU was renamed Viavi in connection with the Separation and retained ownership of 19.9% of Lumentum’s outstanding shares.

[0001628280-16-019400:mdna:18]
On July 31, 2015, prior to the Separation, Viavi transferred substantially all of the assets and liabilities and operations of the CCOP segment and WaveReady product lines to Lumentum. Our financial statements for periods prior to the Separation were prepared on a stand-alone basis and were derived from Viavi’s consolidated financial statements and accounting records. For the period from June 28, 2015 to August 1, 2015, expenses were allocated to us using estimates that we consider to be a reasonable reflection of the utilization of services provided to or benefits received by us.

[0001628280-16-019400:mdna:19]
The consolidated financial statements include certain assets and liabilities that were historically held at the Viavi level but which were transferred to us in the Separation. Viavi’s debt and related interest expense were not attributed or allocated to us for the periods presented since we are not the legal obligor of the debt and Viavi’s borrowings were not directly attributable to us. Certain intercompany transactions between us and Viavi were considered to be effectively settled in the consolidated financial statements at the time the transactions were recorded. The total net effect of the settlement of these intercompany transactions is reflected in our consolidated statements of cash flows as a financing activity and on the consolidated balance sheets as Viavi net investment.

[0001628280-16-019400:mdna:20]
The consolidated statements of operations includes our direct expenses for cost of sales, R&D, sales and marketing, and administration as well as allocations of expenses arising from shared services and infrastructure provided by Viavi to us through the Separation. These allocated expenses include costs of information technology, human resources, accounting, legal, real estate and facilities, corporate marketing, insurance, treasury and other corporate and infrastructure services. In addition, other costs allocated to us include restructuring and stock-based compensation related to Viavi’s corporate and shared services employees as well as other public company costs. These expenses were allocated to us using estimates that we consider to be a reasonable reflection of the utilization of services provided to or benefits received by our business. The allocation methods include revenue, headcount, square footage, actual consumption and usage of services and others.

[0001628280-16-019400:mdna:21]
Critical Accounting Policies and Estimates

[0001628280-16-019400:mdna:22]
The preparation of the consolidated financial statements in accordance with GAAP in the United States requires management to make estimates and assumptions that affect the amounts reported in our consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact us in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, inventory valuation, allocation methods and allocated expenses from Viavi, valuation of goodwill and other intangible assets, stock-based compensation, retirement and post-retirement plan assumptions, restructuring and accounting for income taxes.

[0001628280-16-019400:mdna:23]
Revenue Recognition

[0001628280-16-019400:mdna:24]
We recognize revenue when all four revenue recognition criteria have been met: (i) persuasive evidence of an arrangement exists, (ii) the product has been delivered or the service has been rendered, (iii) the price is fixed or determinable and (iv) collection is reasonably assured. Revenue from product sales is recorded when all of the foregoing conditions are met and risk of loss and title passes to the customer. Our products typically include a warranty and the estimated cost of product warranty claims, based on historical experience, is recorded at the time the sale is recognized. Sales to customers are generally not subject to price protection or return rights.

[0001628280-16-019400:mdna:25]
The majority of our sales are made to OEMs, distributors, resellers and end-users. These sales do not require installation of the products by us and are not subject to other post-delivery obligations. Additionally, our sales to distributors, resellers and end-user customers typically do not have customer acceptance provisions.

[0001628280-16-019400:mdna:26]
Inventory Valuation

[0001628280-16-019400:mdna:27]
We assess the value of our inventory on a quarterly basis and write down those inventories which are obsolete or in excess of our forecasted usage to their estimated realizable value. Our estimates of realizable value are based upon our analysis and assumptions including, but not limited to, forecasted sales levels by product, expected product lifecycle, product development plans and future demand requirements. Our product line management personnel play a key role in our excess review process by providing updated sales forecasts, managing product transitions and working with manufacturing to maximize recovery of excess inventory. If actual market conditions are less favorable than our forecasts or actual demand from our customers is lower than our estimates, we may be required to record additional inventory write-downs. If actual market conditions are more favorable than anticipated, inventory previously written down may be sold, resulting in lower cost of sales and higher income from operations than expected in that period.

[0001628280-16-019400:mdna:28]
Allocations

[0001628280-16-019400:mdna:29]
Prior to Separation, Viavi allocated certain expenses that arise from shared services and infrastructure provided by Viavi to us such as the costs of information technology, human resources, accounting, legal, real estate and facilities, corporate marketing, insurance, treasury and other corporate and infrastructure services. In addition, other costs allocated to us include restructuring and stock-based compensation related to Viavi's corporate and shared services employees. These expenses are allocated to us using estimates that we consider to be a reasonable reflection of the utilization of services provided to or benefits received by our business. The allocation methods included revenue, headcount, square footage, actual consumption and usage of services and others.

[0001628280-16-019400:mdna:30]
Stock-Based Compensation

[0001628280-16-019400:mdna:31]
Stock-based compensation is measured at grant date, based on the fair value of the award, and recognized as compensation over the requisite service period. The fair value of time-based restricted units ("RSUs") is based on the closing market price of our common stock on the grant date of the award. For awards granted prior to the Separation, the fair value of time-based RSUs was based on the closing market price of Viavi common stock on the grant date of the award. We estimate the fair value of employee stock purchase plan ("ESPP") shares using the Black-Scholes Merton option-pricing model. These valuation models require the input of highly subjective assumptions, including the award's expected life, the price volatility of the underlying stock and the average volatility of peer companies.

[0001628280-16-019400:mdna:32]
We estimate the expected forfeiture rate and recognize only expense for those shares expected to vest. When estimating forfeitures, we consider historical forfeiture experiences as well as our expectation about future terminations and workforce reduction programs. Estimated forfeiture is trued up to actual forfeiture as the equity awards vest. The total fair value of the equity awards, net of forfeiture, is recorded on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period, except for performance stock units which are amortized on a graded vesting method.

[0001628280-16-019400:mdna:33]
Goodwill

[0001628280-16-019400:mdna:34]
We test goodwill for possible impairment on an annual basis in our fourth quarter and at any other time if events occur or circumstances indicate that the carrying amount of goodwill may not be recoverable. Circumstances that could trigger an impairment test include, but are not limited to: a significant adverse change in the business climate or legal factors, an adverse action or assessment by a regulator, changes in customers, target markets and strategy, unanticipated competition, loss of key personnel, or the likelihood that a reporting unit or significant portion of a reporting unit will be sold or otherwise disposed.

[0001628280-16-019400:mdna:35]
An entity has the option to first assess qualitative factors to determine whether it is necessary to perform the two-step quantitative goodwill impairment test. If an entity determines that as a result of the qualitative assessment that it is more likely than not (i.e., greater than 50% likelihood) that the fair value of a reporting unit is less than its carrying amount, then the quantitative test is required. Otherwise, no further testing is required. The two-step quantitative goodwill impairment test requires us to estimate the fair value of our reporting units. If the carrying value of a reporting unit exceeds its fair value, the goodwill of that reporting unit is potentially impaired and we proceed to step two of the impairment analysis. In step two of the analysis, we measure and record an impairment loss equal to the excess of the carrying value of the reporting unit's goodwill over its implied fair value, if any.

[0001628280-16-019400:mdna:36]
Application of the goodwill impairment test requires judgments, including: identification of the reporting units, assigning assets and liabilities to reporting units, assigning goodwill to reporting units, a qualitative assessment to determine whether there are any impairment indicators, and determining the fair value of each reporting unit. We historically estimated the fair value of a reporting unit using the market approach, which estimates the fair value based on comparable market prices. Significant estimates in the market approach include: identifying similar companies with comparable business factors such as size, growth, profitability, risk and return on investment, and assessing comparable revenue and operating income multiples in estimating the fair value of the reporting unit.

[0001628280-16-019400:mdna:37]
We base our estimates on historical experience and on various assumptions about the future that we believe are reasonable based on available information. Unanticipated events and circumstances may occur that affect the accuracy of our assumptions, estimates and judgments. For example, if the price of our common stock were to significantly decrease combined with other adverse changes in market conditions, thus indicating that the underlying fair value of our reporting units may have decreased, we might be required to reassess the value of our goodwill in the period such circumstances were identified.

[0001628280-16-019400:mdna:38]
Long-lived Asset Valuation (Property, Plant and Equipment and Intangible Assets Subject to Amortization)

[0001628280-16-019400:mdna:39]
We test long-lived assets for recoverability, at the asset group level, when events or changes in circumstances indicate that their carrying amounts may not be recoverable. Circumstances which could trigger a review include, but are not limited to: significant decreases in the market price of the asset; significant adverse changes in the business climate or legal factors; accumulation of costs significantly in excess of the amount originally expected for the acquisition or construction of the asset; current period cash flow or operating losses combined with a history of losses or a forecast of continuing losses associated with the use of the asset; and current expectation that the asset will more likely than not be sold or disposed of significantly before the end of its estimated useful life.

[0001628280-16-019400:mdna:40]
Recoverability is assessed based on the carrying amounts of the long-lived assets or asset groups and its fair value which is generally determined based on the sum of the undiscounted cash flows expected to result from the use and the eventual disposal of the asset, as well as specific appraisals in certain instances. An impairment loss is recognized when the carrying amount is not recoverable and exceeds fair value.

[0001628280-16-019400:mdna:41]
Income Taxes

[0001628280-16-019400:mdna:42]
Prior to the Separation, our operations in the United States were transacted within the same Viavi U.S. legal entities as the other Viavi businesses which have filed U.S. and state income tax returns on that basis. Accordingly, we were not able to retain many of the tax attributes attributable to our business as a matter of U.S. tax law. Therefore, we have not reflected on the balance sheet deferred tax assets and the corresponding valuation allowance related to certain federal net operating losses and credits generated before the Separation.

[0001628280-16-019400:mdna:43]
In accordance with the authoritative guidance on accounting for income taxes, we recognize income taxes using an asset and liability approach. This approach requires the recognition of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in our consolidated financial statements or tax returns. The measurement of current and deferred taxes is based on provisions of the enacted tax law, and the effects of future changes in tax laws or rates are not anticipated.

[0001628280-16-019400:mdna:44]
The authoritative guidance provides for recognition of deferred tax assets if the realization of such deferred tax assets is more likely than not to occur based on an evaluation of both positive and negative evidence and the relative weight of the evidence. With the exception of certain international jurisdictions, we have determined that at this time it is more likely than not that deferred tax assets attributable to the remaining jurisdictions will not be realized, primarily due to uncertainties related to our ability to utilize our net operating loss carryforwards before they expire. Accordingly, we have established a valuation allowance for such deferred tax assets. If there is a change in our ability to realize our deferred tax assets for which a valuation allowance has been established, then our tax provision may decrease in the period in which we determine that realization is more likely than not. Likewise, if we determine that it is not more likely than not that deferred tax assets will be realized, then a valuation allowance may be established for such deferred tax assets and our tax provision may increase in the period in which we make the determination.

[0001628280-16-019400:mdna:45]
The authoritative guidance on accounting for uncertainty in income taxes clarifies the accounting for uncertainty in income taxes recognized in an entity's financial statements, and prescribes the recognition threshold and measurement attributes for financial statements recognition and measurement of a tax position taken or expected to be taken in a tax return. Additionally, it provides guidance on recognition, classification, and disclosure of tax positions. We are subject to income tax audits by the respective tax authorities in all of the jurisdictions in which we operate. The determination of tax liabilities in each of these jurisdictions requires the interpretation and application of complex and sometimes uncertain tax laws and regulations. We recognize liabilities based on our estimate of whether, and the extent to which, additional tax liabilities are more likely than not. If we ultimately determine that the payment of such a liability is not necessary, then we reverse the liability and recognize a tax benefit during the period in which the determination is made that the liability is no longer necessary.

[0001628280-16-019400:mdna:46]
The recognition and measurement of current taxes payable or refundable and deferred tax assets and liabilities requires that we make certain estimates and judgments. Changes to these estimates or a change in judgment may have a material impact on our tax provision in a future period.

[0001628280-16-019400:mdna:47]
Restructuring Accrual

[0001628280-16-019400:mdna:48]
Costs associated with restructuring activities are recognized when they are incurred. However, in the case of leases, the expense is estimated and accrued when the property is vacated. Given the significance of, and the timing of the execution of such activities, this process is complex and involves periodic reassessments of estimates made from the time the property was vacated, including evaluating real estate market conditions for expected vacancy periods and sub-lease income. We recognize a liability for post-employment benefits for workforce reductions related to restructuring activities when payment is probable and the amount is reasonably estimable. We continually evaluate the adequacy of the remaining liabilities under our restructuring initiatives. Although we believe that these estimates accurately reflect the costs of our restructuring plans, actual results may differ, thereby requiring us to record additional provisions or reverse a portion of such provisions. In addition to the restructuring plans directly attributable to us, a portion of restructuring and related charges related to corporate and shared services employees was allocated by Viavi to us. Refer to "Note 3. Related Party Transactions" and "Note 11. Restructuring and Related Charges" in the Notes to Consolidated Financial Statements.

[0001628280-16-019400:mdna:49]
Recently Issued Accounting Pronouncements

[0001628280-16-019400:mdna:50]
Refer to "Note 2. Recently Issued Accounting Pronouncements"  in the Notes to Consolidated Financial Statements.

[0001628280-16-019400:mdna:51]
RESULTS OF OPERATIONS

[0001628280-16-019400:mdna:52]
The results of operations for the periods presented are not necessarily indicative of results to be expected for future periods. The following table summarizes selected Consolidated Statements of Operations items as a percentage of net revenue:

[0001628280-16-019400:mdna:53]
|  | Years Ended |
|  | July 2, 2016 |  | June 27, 2015 |  | June 28, 2014 |
| Segment net revenue: |  |  |  |  |  |
| OpComms | 84.3 | % |  | 82.9 | % |  | 85.0 | % |
| Lasers | 15.7 |  |  | 17.1 |  |  | 15.0 |  |
| Net revenue | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of sales | 68.5 |  |  | 68.3 |  |  | 67.5 |  |
| Amortization of acquired technologies | 0.8 |  |  | 0.9 |  |  | 1.1 |  |
| Gross profit | 30.7 |  |  | 30.8 |  |  | 31.4 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 15.6 |  |  | 16.8 |  |  | 16.5 |  |
| Selling, general and administrative | 13.0 |  |  | 15.4 |  |  | 13.2 |  |
| Restructuring and related charges | 0.8 |  |  | 1.4 |  |  | 0.6 |  |
| Total operating expenses | 29.4 |  |  | 33.6 |  |  | 30.3 |  |
| Income (loss) from operations | 1.3 |  |  | (2.8 | ) |  | 1.1 |  |
| Unrealized gain (loss) on derivative liabilities | (0.1 | ) |  | — |  |  | — |  |
| Interest and other income (expense), net | (0.1 | ) |  | (0.1 | ) |  | 0.1 |  |
| Income (loss) before income taxes | 1.1 |  |  | (2.9 | ) |  | 1.2 |  |
| Provision for (benefit from) income tax | 0.1 |  |  | (2.5 | ) |  | (0.1 | ) |
| Net income (loss) | 1.0 | % |  | (0.4 | )% |  | 1.3 | % |

[0001628280-16-019400:mdna:54]
Financial Data for Fiscal 2016, 2015 and 2014

[0001628280-16-019400:mdna:55]
The following table summarizes selected Consolidated Statements of Operations items (in millions, except for percentages):

[0001628280-16-019400:mdna:56]
|  | 2016 |  | 2015 |  | Change |  | Percentage Change |  | 2015 |  | 2014 |  | Change |  | Percentage Change |
| Segment net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| OpComms | $ | 761.3 |  |  | $ | 694.1 |  |  | $ | 67.2 |  |  | 9.7 | % |  | $ | 694.1 |  |  | $ | 695.1 |  |  | $ | (1.0 | ) |  | (0.1 | )% |
| Lasers | 141.7 |  |  | 143.0 |  |  | (1.3 | ) |  | (0.9 | ) |  | 143.0 |  |  | 122.8 |  |  | 20.2 |  |  | 16.4 |  |
| Net revenue | $ | 903.0 |  |  | $ | 837.1 |  |  | $ | 65.9 |  |  | 7.9 | % |  | $ | 837.1 |  |  | $ | 817.9 |  |  | $ | 19.2 |  |  | 2.3 | % |
| Gross profit | $ | 277.3 |  |  | $ | 257.9 |  |  | $ | 19.4 |  |  | 7.5 | % |  | $ | 257.9 |  |  | $ | 256.6 |  |  | $ | 1.3 |  |  | 0.5 | % |
| Gross margin | 30.7 | % |  | 30.8 | % |  |  |  |  |  | 30.8 | % |  | 31.4 | % |  |  |  |  |
| Research and development | 141.1 |  |  | 140.8 |  |  | 0.3 |  |  | 0.2 | % |  | 140.8 |  |  | 134.9 |  |  | 5.9 |  |  | 4.4 | % |
| Percentage of net revenue | 15.6 | % |  | 16.8 | % |  |  |  |  |  | 16.8 | % |  | 16.5 | % |  |  |  |  |
| Selling, general and administrative | 117.3 |  |  | 128.9 |  |  | (11.6 | ) |  | (9.0 | )% |  | 128.9 |  |  | 108.2 |  |  | 20.7 |  |  | 19.1 | % |
| Percentage of net revenue | 13.0 | % |  | 15.4 | % |  |  |  |  |  | 15.4 | % |  | 13.2 | % |  |  |  |  |
| Restructuring and related charges | 7.4 |  |  | 11.6 |  |  | (4.2 | ) |  | (36.2 | )% |  | 11.6 |  |  | 4.8 |  |  | 6.8 |  |  | 141.7 | % |
| Percentage of net revenue | 0.8 | % |  | 1.4 | % |  |  |  |  |  | 1.4 | % |  | 0.6 | % |  |  |  |  |

[0001628280-16-019400:mdna:57]
38

[0001628280-16-019400:mdna:58]
Net Revenue

[0001628280-16-019400:mdna:59]
Net revenue increased by $65.9 million, or 7.9%, during fiscal 2016 compared to fiscal 2015. This increase was primarily due to an increase in net revenue from our OpComms segment. OpComms net revenue increased $67.2 million, or 9.7%, during fiscal 2016 compared to fiscal 2015 driven by increases from Telecom and 100G Datacom products. Lasers net revenue decreased $1.3 million, or 0.9%, in fiscal 2016 compared to fiscal 2015.

[0001628280-16-019400:mdna:60]
Net revenue increased by $19.2 million, or 2.3%, during fiscal 2015 compared to fiscal 2014. This increase was primarily due to an increase in net revenue from our Lasers segment. OpComms net revenue decreased $1.0 million, or 0.1%, during fiscal 2015 compared to fiscal 2014. This was driven by $40.9 million of net revenue decreases from products addressing the Consumer and Industrial market, primarily due to lower demand from a key customer for 3D sensing products in 2015 compared to 2014 when this customer launched its next generation gaming console.  This decrease was almost entirely offset by $39.9 million of net revenue increases driven by increased sales of new products for the Datacom market and higher demand for our Telecom products. Lasers net revenue increased $20.2 million, or 16.4%, in fiscal 2015 compared to fiscal 2014. This increase was primarily driven by increased revenue from our next generation products, coupled with incremental net revenue from our acquisition of Time-Bandwidth in the third quarter of fiscal 2014. This was partially offset by decreased revenue from lower demand for other Laser products.

[0001628280-16-019400:mdna:61]
Revenue by Region

[0001628280-16-019400:mdna:62]
We operate in three geographic regions: Americas, Asia-Pacific and EMEA. Net revenue is assigned to the geographic region and country where our product is initially shipped. For example, certain customers may request shipment of our product to a contract manufacturer in one country, however, the location of the end customers may differ. The following table presents net revenue by the three geographic regions we operate in and net revenue from countries that exceeded 10% or more of our total net revenue (in millions, except for percentages):

[0001628280-16-019400:mdna:63]
|  | Years Ended |
|  | July 2, 2016 |  | June 27, 2015 |  | June 28, 2014 |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 162.3 |  |  | 18.0 | % |  | $ | 162.4 |  |  | 19.4 | % |  | $ | 177.5 |  |  | 21.7 | % |
| Mexico | 112.9 |  |  | 12.5 |  |  | 112.7 |  |  | 13.5 |  |  | 111.3 |  |  | 13.6 |  |
| Other Americas | 19.6 |  |  | 2.2 |  |  | 31.1 |  |  | 3.6 |  |  | 30.3 |  |  | 3.7 |  |
| Total Americas | $ | 294.8 |  |  | 32.7 | % |  | $ | 306.2 |  |  | 36.5 | % |  | $ | 319.1 |  |  | 39.0 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 214.0 |  |  | 23.7 | % |  | $ | 120.4 |  |  | 14.4 | % |  | $ | 128.7 |  |  | 15.8 | % |
| Japan | 92.9 |  |  | 10.3 |  |  | 106.6 |  |  | 12.7 |  |  | 97.6 |  |  | 11.9 |  |
| Other Asia-Pacific | 177.8 |  |  | 19.6 |  |  | 174.4 |  |  | 20.9 |  |  | 138.6 |  |  | 16.9 |  |
| Total Asia-Pacific | $ | 484.7 |  |  | 53.6 | % |  | $ | 401.4 |  |  | 48.0 | % |  | $ | 364.9 |  |  | 44.6 | % |
| EMEA | $ | 123.5 |  |  | 13.7 | % |  | $ | 129.5 |  |  | 15.5 | % |  | $ | 133.9 |  |  | 16.4 | % |
| Total net revenue | $ | 903.0 |  |  |  |  | $ | 837.1 |  |  |  |  | $ | 817.9 |  |  |  |

[0001628280-16-019400:mdna:64]
During fiscal 2016, 2015 and 2014, net revenue from customers outside the United States, based on customer shipping location, represented 82%, 81% and 78% of net revenue, respectively. Our net revenue is primarily denominated in U.S. dollars, including our net revenue from customers outside the United States as presented above. We expect revenue from customers outside of the United States to continue to be an important part of our overall net revenue and an increasing focus for net revenue growth opportunities.

[0001628280-16-019400:mdna:65]
Gross Margin and Segment Gross Margin

[0001628280-16-019400:mdna:66]
The following table summarizes segment gross margin for fiscal 2016, 2015 and 2014 (in millions, except for percentages):

[0001628280-16-019400:mdna:67]
|  | Gross Profit |  | Gross Margin |
|  | 2016 |  | 2015 |  | 2014 |  | 2016 |  | 2015 |  | 2014 |
| OpComms | $ | 236.3 |  |  | $ | 204.8 |  |  | $ | 212.3 |  |  | 31.0 | % |  | 29.5 | % |  | 30.5 | % |
| Lasers | 61.4 |  |  | 67.4 |  |  | 59.8 |  |  | 43.3 | % |  | 47.1 | % |  | 48.7 | % |
| Segment total | $ | 297.7 |  |  | $ | 272.2 |  |  | $ | 272.1 |  |  | 33.0 | % |  | 32.5 | % |  | 33.3 | % |
| Unallocated corporate items (1) | (20.4 | ) |  | (14.3 | ) |  | (15.5 | ) |  |  |  |  |  |  |
| Total | $ | 277.3 |  |  | $ | 257.9 |  |  | $ | 256.6 |  |  | 30.7 | % |  | 30.8 | % |  | 31.4 | % |

[0001628280-16-019400:mdna:68]
(1) The unallocated corporate items for the years presented include the effects of amortization of acquired developed technology intangible assets, share-based compensation and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0001628280-16-019400:mdna:69]
Gross Margin

[0001628280-16-019400:mdna:70]
Gross margin in fiscal 2016 was relatively flat compared to fiscal 2015. Lower Lasers gross margins was offset by an increase in OpComms gross margins.

[0001628280-16-019400:mdna:71]
Gross margin in fiscal 2015 decreased 0.6 percentage points to 30.8% from 31.4% in fiscal 2014. This decrease was primarily due to decreases in OpComms and Lasers gross margins as discussed below, partially offset by a reduction in amortization of developed technology driven by certain significant intangible assets becoming fully amortized in the second half of fiscal 2014.

[0001628280-16-019400:mdna:72]
As discussed in more detail under "Net Revenue" above, we sell products in certain markets that are consolidating, undergoing product, architectural and business model transitions, have high customer concentrations, are highly competitive (increasingly due to Asia-Pacific-based competition), are price sensitive and/or are affected by customer seasonal and mix variant buying patterns. We expect these factors to continue to result in variability of our gross margin.

[0001628280-16-019400:mdna:73]
Segment Gross Margin

[0001628280-16-019400:mdna:74]
OpComms

[0001628280-16-019400:mdna:75]
OpComms gross margin in fiscal 2016 increased 1.5 percentage points to 31.0% from 29.5% in fiscal 2015. This increase was primarily due to higher revenue volume and cost reductions, partially offset by an inventory write-off related to our 3-D sensing product.

[0001628280-16-019400:mdna:76]
OpComms gross margin in fiscal 2015 decreased 1.0 percentage points to 29.5% from 30.5% in fiscal 2014. This decrease was primarily due to low gross margin products comprising a larger portion of our overall product mix.

[0001628280-16-019400:mdna:77]
Lasers

[0001628280-16-019400:mdna:78]
Lasers gross margin in fiscal 2016 decreased 3.8 percentage points to 43.3% from 47.1% in fiscal 2015. This decrease was primarily due to lower revenue volume and higher warranty cost due to a component quality issue on our fiber laser product.

[0001628280-16-019400:mdna:79]
Lasers gross margin in fiscal 2015 decreased 1.6 percentage points to 47.1% from 48.7% in fiscal 2014. This decrease was primarily due to low gross margin products comprising a larger portion of our overall product mix in the Lasers market.

[0001628280-16-019400:mdna:80]
Research and Development

[0001628280-16-019400:mdna:81]
R&D expense increased $0.3 million, or 0.2%, in fiscal 2016 compared to fiscal 2015. The increase in R&D expense was primarily due to increased investment in new R&D programs, one additional week of spend in fiscal 2016, and increased employee compensation expense.  This was partially offset by higher R&D credits and a decrease in employee-related costs resulting from the closure of the Serangoon office in Singapore.

[0001628280-16-019400:mdna:82]
R&D expense increased $5.9 million, or 4.4%, in fiscal 2015 compared to fiscal 2014 as we increased our investment in new R&D programs in order to develop new technologies and products, and our employee compensation expense increased by $5.8 million primarily for additional headcount to support our various R&D programs.

[0001628280-16-019400:mdna:83]
We believe that continuing our investments in R&D is critical to attaining our strategic objectives. We plan to continue to invest in R&D and new products that we believe will further differentiate us in the marketplace and expect our investment to increase in absolute dollars in future quarters.

[0001628280-16-019400:mdna:84]
Selling, General and Administrative

[0001628280-16-019400:mdna:85]
SG&A expense decreased $11.6 million, or 9.0%, in fiscal 2016 compared to fiscal 2015. Our fiscal 2015 SG&A expense  included allocated expenses from Viavi and therefore was higher as compared to fiscal 2016 which was entirely on a stand-alone basis. This is partially offset by higher labor and benefits costs resulting from an additional week in fiscal 2016.

[0001628280-16-019400:mdna:86]
SG&A expense increased $20.7 million, or 19.1%, in fiscal 2015 compared to fiscal 2014. This increase was primarily driven by a $19.0 million increase in corporate allocations by Viavi primarily related to pre-Separation costs for advisory services.

[0001628280-16-019400:mdna:87]
We intend to continue to focus on managing our SG&A expense as a percentage of net revenue. However, we may experience in the future, certain non-core expenses, such as mergers and acquisitions-related expenses and litigation expenses, which could increase our SG&A expenses and potentially impact our profitability expectations in any particular quarter.

[0001628280-16-019400:mdna:88]
Restructuring and Related Charges

[0001628280-16-019400:mdna:89]
We have reduced costs through targeted restructuring efforts intended to consolidate our operations, rationalize the manufacturing of our products and align our business in response to market conditions. We estimate annualized cost savings of $15.2 million excluding any one-time charge as a result of the restructuring activities below. Refer to "Note 11. Restructuring and Related Charges" in the Notes to Consolidated Financial Statements.

[0001628280-16-019400:mdna:90]
As of July 2, 2016, our total restructuring accrual was $5.7 million.

[0001628280-16-019400:mdna:91]
During fiscal 2016, we recorded $7.7 million in restructuring and related charges.

[0001628280-16-019400:mdna:92]
| • | During the fourth quarter of fiscal 2016, management approved a plan to optimize operations and gain efficiencies throughout the organization. As a result, a restructuring charge of $0.7 million was recorded for severance and employee benefits during fiscal 2016. In total 18 employees in manufacturing, R&D and SG&A functions located around the world were terminated. Payments related to the remaining severance and benefits accrual are expected to be paid by the end of fiscal 2017. |

[0001628280-16-019400:mdna:93]
| • | We also incurred restructuring and related charges of $7.0 million from restructuring plans approved prior to fiscal 2016 primarily related to manufacturing transfer costs for transfer of certain production processes into existing sites in the United States or to contract manufacturers. |

[0001628280-16-019400:mdna:94]
As of June 27, 2015, our total restructuring accrual was $6.0 million.

[0001628280-16-019400:mdna:95]
| • | During the second and fourth quarters of fiscal 2015, management approved restructuring plans to optimize operations and gain efficiencies by closing our Bloomfield, Connecticut site and consolidating roles and responsibilities across functions in connection with the Separation. As a result, a restructuring charge of $5.1 million was recorded for severance and employee benefits during fiscal 2015. Payments related to the remaining severance and benefits accrual are expected to be paid by the end of the second quarter of fiscal 2017. |

[0001628280-16-019400:mdna:96]
| • | During the first quarter of fiscal 2015, management approved a plan to optimize operations and gain efficiencies by closing the Robbinsville, New Jersey site and consolidating roles and responsibilities across North America. As a result, a restructuring charge of $1.5 million was recorded for severance and employee benefits during fiscal 2015. In total approximately 30 employees in manufacturing, R&D and SG&A functions located in North America were impacted. Payments related to the remaining severance and benefits accrual are expected to be paid by the end of the second quarter of fiscal 2017 |

[0001628280-16-019400:mdna:97]
| • | The accompanying audited annual consolidated statements of operations include allocated cost of $5.0 million for restructuring and related charges related to Viavi's corporate and shared services employees. |

[0001628280-16-019400:mdna:98]
Interest and Other Income (Expense), Net

[0001628280-16-019400:mdna:99]
Interest and other income (expense), net is comprised substantially of gains and losses associated with the re-measurement of non-functional currency denominated monetary assets and liabilities, as well as other transactions outside of the normal course of business. Fiscal 2015 also included an allocation from Viavi of gains and losses on the foreign currency forward contracts utilized in Viavi's balance sheet hedging program.

[0001628280-16-019400:mdna:100]
Interest and other income (expense), net was $(1.2) million in fiscal 2016 as compared to $(1.1) million in fiscal 2015. The $0.1 million change was primarily due higher foreign exchange losses, offset by a decrease in interest expense in fiscal 2016.

[0001628280-16-019400:mdna:101]
Interest and other income (expense), net was $(1.1) million in fiscal 2015 as compared to $1.1 million in fiscal 2014. The $2.2 million change was primarily due to a foreign exchange loss of $0.3 million in fiscal 2015 compared to a foreign exchange gain of $1.6 million in fiscal 2014, both of which include the offsetting impact allocated to us from Viavi's balance sheet hedging program.

[0001628280-16-019400:mdna:102]
Provision for (Benefit from) Income Taxes (in millions)

[0001628280-16-019400:mdna:103]
|  | Years Ended |
|  | July 2, 2016 |  | June 27, 2015 |  | June 28, 2014 |
| Provision for (benefit from) income taxes | $ | 0.4 |  |  | $ | (21.1 | ) |  | $ | (0.9 | ) |

[0001628280-16-019400:mdna:104]
We recorded a provision (benefit) for income taxes of $0.4 million, $(21.1) million and $(0.9) million in fiscal 2016, 2015 and 2014, respectively.  Our effective tax rate in fiscal 2016 was lower than the U.S. statutory federal income tax rate of 35%, primarily attributable to the difference in foreign tax rates, utilization of U.S. tax attributes that were subject to a full valuation allowances, and the benefit of foreign tax incentives.

[0001628280-16-019400:mdna:105]
As of July 2, 2016, we had net deferred tax assets of $31.6 million which was mainly comprised of foreign net operating loss and credit carryovers in profitable jurisdictions.  Our federal and state deferred tax assets are subject to a full valuation allowance to reflect uncertainties about whether we will be able to utilize the deferred tax assets before they expire.

[0001628280-16-019400:mdna:106]
While we believe our current valuation allowance is sufficient, we could in the future be required to increase the valuation allowance to take into account additional deferred tax assets that we may be unable to realize. We assess the need for an adjustment to the valuation allowance on a quarterly basis. The assessment is based on our estimates of future sources of taxable income for the jurisdictions in which we operate and the periods over which our deferred tax assets will be realizable.

[0001628280-16-019400:mdna:107]
For further discussion of our income tax provision, see "Note 12. Income Taxes" in the Notes to Consolidated Financial Statements.

[0001628280-16-019400:mdna:108]
Contractual Obligations

[0001628280-16-019400:mdna:109]
The following table summarizes our contractual obligations at July 2, 2016, and the effect such obligations are expected to have on our liquidity and cash flow over the next five years (in millions):

[0001628280-16-019400:mdna:110]
|  | Payments due by period |
|  | Total |  | Less than 1 year |  | 1 - 3 years |  | 3 - 5 years |  | More than 5 years |
| Contractual Obligations |  |  |  |  |  |  |  |  |  |
| Asset retirement obligations—expected cash payments | $ | 2.3 |  |  | $ | — |  |  | $ | 0.6 |  |  | $ | 0.5 |  |  | $ | 1.2 |  |
| Purchase obligations (1) | 117.5 |  |  | 112.8 |  |  | 4.7 |  |  | — |  |  | — |  |
| Operating lease obligations (1) | 24.6 |  |  | 6.7 |  |  | 9.5 |  |  | 4.5 |  |  | 3.9 |  |
| Pension and post-retirement benefit payments (2) | 3.5 |  |  | — |  |  | — |  |  | 0.2 |  |  | 3.3 |  |
| Total | $ | 147.9 |  |  | $ | 119.5 |  |  | $ | 14.8 |  |  | $ | 5.2 |  |  | $ | 8.4 |  |

[0001628280-16-019400:mdna:111]
(1) Refer to "Note 15. Commitments and Contingencies" in the Notes to Consolidated Financial Statements.

[0001628280-16-019400:mdna:112]
(2) Refer to "Note 14. Employee Benefit Plans" in the Notes to Consolidated Financial Statements.

[0001628280-16-019400:mdna:113]
As of July 2, 2016, other current liabilities and other non-current liabilities on the consolidated balance sheet include $0.3 million and $0.2 million, respectively, for restructuring and related activities in connection with our operating lease obligations disclosed above.

[0001628280-16-019400:mdna:114]
Purchase obligations represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements.

[0001628280-16-019400:mdna:115]
As of July 2, 2016, our other non-current liabilities primarily relate to asset retirement obligations and pension which are presented in various lines in the preceding table.

[0001628280-16-019400:mdna:116]
The table above does not include potential redemption of our redeemable convertible preferred stock with a $35.8 million face value, plus any accrued and unpaid interest, as there is no set maturity date. If the holder of our redeemable convertible preferred stock does not execute its conversion option, or if it is unable to do so before the third anniversary of the date of issuance, we may choose to redeem the preferred stock for $35.8 million. In addition, on the fifth anniversary date of the issuance, the holder of our redeemable convertible preferred stock may elect to redeem the preferred stock for $35.8 million.

[0001628280-16-019400:mdna:117]
Off-Balance Sheet Arrangements

[0001628280-16-019400:mdna:118]
We do not have any off-balance sheet arrangements, as such term is defined in rules promulgated by the SEC, that have or are reasonably likely to have a current or future effect on our financial condition, changes in financial condition, revenues or expenses, results of operations, liquidity, capital expenditures or capital resources that are material to investors.

[0001628280-16-019400:mdna:119]
Acquisitions

[0001628280-16-019400:mdna:120]
As part of our strategy, we are committed to the ongoing evaluation of strategic opportunities and, where appropriate, the acquisition of additional products, technologies or businesses that are complementary to, or broaden the markets for, our products. We believe we have strengthened our business model by expanding our addressable markets, customer base and expertise, diversifying our product portfolio, and fortifying our core businesses through acquisition as well as through organic initiatives.

[0001628280-16-019400:mdna:121]
On January 27, 2014, Viavi completed the acquisition of Time-Bandwidth, a privately-held provider of high powered and ultrafast lasers for industrial and scientific markets. Use of ultrafast lasers for micromachining applications is being driven primarily by the increasing use of consumer electronics and connected devices globally. Viavi acquired all outstanding shares of Time-Bandwidth for a total purchase price of $15.0 million in cash, including a holdback amount of $2.3 million which had been withheld to satisfy potential indemnification claims by Viavi in relation to the Time-Bandwidth acquisition. During the first quarter of fiscal 2016, we released the holdback amount of $2.3 million.

[0001628280-16-019400:mdna:122]
Please refer to "Note 6. Mergers and Acquisitions" in the Notes to Consolidated Financial Statements.

[0001628280-16-019400:mdna:123]
Pension Benefits

[0001628280-16-019400:mdna:124]
As a result of acquiring Time-Bandwidth in January 2014, we have a pension plan for certain employees in Switzerland. This plan is open to new participants and additional service costs are being accrued. The Switzerland plan is partially funded. As of July 2, 2016, our pension plan was under funded by $3.5 million since the projected benefit obligation ("PBO") exceeded the fair value of the plan assets.

[0001628280-16-019400:mdna:125]
We expect to contribute $0.4 million to the Switzerland plan during fiscal 2017.

[0001628280-16-019400:mdna:126]
A key actuarial assumption in calculating the net periodic cost and the PBO is the discount rate. Changes in the discount rate impact the interest cost component of the net periodic benefit cost calculation and PBO due to the fact that the PBO is calculated on a net present value basis. Decreases in the discount rate will generally increase pre-tax cost, recognized expense and the PBO. Increases in the discount rate tend to have the opposite effect. We estimate a 50 basis point decrease or increase in the discount rate would cause a corresponding increase or decrease, respectively, in the PBO of $0.7 million based upon data as of July 2, 2016.

[0001628280-16-019400:mdna:127]
Financial Condition

[0001628280-16-019400:mdna:128]
Liquidity and Capital Resources

[0001628280-16-019400:mdna:129]
As of July 2, 2016 and June 27, 2015, our cash and cash equivalents of $157.1 million and $14.5 million, respectively, were held predominantly in the United States, Cayman Islands, Canada, China and Japan. Although the cash generated in the United States from future operations is expected to cover our normal operating requirements, a substantial amount of additional cash could be required for other purposes, such as dividends that may be declared, future stock repurchase programs or acquisitions. Our intent is to indefinitely reinvest funds held outside the United States and our current plans do not demonstrate a need to repatriate them to fund our domestic operations. However, if in the future, we encounter a significant need for liquidity domestically or at a particular location that we cannot fulfill through borrowings, equity offerings, or other internal or external sources, we may determine that cash repatriations are necessary. Repatriation could result in additional material U.S. federal and state income tax payments in future years. Such adverse consequences would occur, for example, if the transfer of cash into the United States is taxed and no foreign tax credit is available to offset the U.S. tax liability, resulting in higher taxes. These factors may cause us to have an overall tax rate higher than other companies or higher than our tax rates have been in the past.

[0001628280-16-019400:mdna:130]
Fiscal 2016

[0001628280-16-019400:mdna:131]
As of July 2, 2016, our consolidated balance of cash and cash equivalents and short-term investments was $157.1 million, an increase of $142.3 million, or 961.5%, as compared to $14.8 million as of June 27, 2015.

[0001628280-16-019400:mdna:132]
Cash provided by operating activities was $86.6 million, primarily resulting from $9.3 million of net income, which included $80.7 million of non-cash items such as depreciation, stock-based compensation, derivative liability, amortization of intangibles and disposal of property, plant and equipment, offset by changes in operating assets and liabilities of $3.4 million. Changes in our operating assets and liabilities related primarily to an increase in accounts payable of $28.9 million, an increase in accounts receivable of $21.8 million, an increase in prepayments, other current and non-currents assets of $12.7 million, an increase in accrued payroll and related expenses of $9.2 million, a decrease in deferred taxes, net of $1.7 million, a decrease in income taxes payable of $1.7 million, an increase in inventories of $3.1 million and a decrease in accrued expenses and other current and non-current liabilities of $0.5 million.

[0001628280-16-019400:mdna:133]
Cash used in investing activities included $82.0 million, of cash used for capital expenditures, primarily to expand our manufacturing capacity.

[0001628280-16-019400:mdna:134]
Cash provided by financing activities was $136.4 million resulting primarily from net transfers from Viavi of $134.2 million at the Separation date.

[0001628280-16-019400:mdna:135]
Fiscal 2015

[0001628280-16-019400:mdna:136]
As of June 27, 2015, our consolidated balance of cash and cash equivalents and short-term investments was $14.8 million, a decrease of $5.4 million, or 26.7%, as compared to $20.2 million as of June 28, 2014.

[0001628280-16-019400:mdna:137]
Cash provided by operating activities was $9.4 million, primarily resulting from $3.4 million of net loss and $69.0 million of non-cash items such as depreciation, stock-based compensation, amortization of intangibles and changes in our deferred tax balances, offset by changes in operating assets and liabilities of $56.2 million. Changes in our operating assets and liabilities related primarily to an increase in accounts receivable of $17.8 million, an increase in other current and non-currents assets of $14.5 million, a decrease in income taxes payable of $10.8 million, an increase in inventories of $6.2 million and a decrease in accrued expenses and other current and non-current liabilities of $6.9 million.

[0001628280-16-019400:mdna:138]
Cash used in investing activities was $53.5 million, primarily resulting from cash used for capital expenditures of $53.7 million.

[0001628280-16-019400:mdna:139]
Cash provided by financing activities was $40.6 million resulting from net transfers from Viavi.

[0001628280-16-019400:mdna:140]
Fiscal 2014

[0001628280-16-019400:mdna:141]
As of June 28, 2014, our consolidated balance of cash and cash equivalents and short-term investments was $20.2 million, an increase of $12.1 million, or $149.4%, as compared to $8.1 million as of June 29, 2013.

[0001628280-16-019400:mdna:142]
Cash provided by operating activities was $62.8 million, primarily resulting from $10.7 million of net income and $59.4 million of non-cash items such as depreciation, stock-based compensation, amortization of intangibles and changes in our deferred tax balances, offset by changes in operating assets and liabilities of $7.3 million. Changes in our operating assets and liabilities related primarily to an increase in accounts receivable of $15.1 million, an increase in inventories of $13.5 million and a decrease in accrued expenses and other current and non-current liabilities of $1.0 million. This was partially offset by an increase in accounts payable of $18.7 million due to timing of payments and a decrease in other current and non-currents assets of $3.5 million.

[0001628280-16-019400:mdna:143]
Cash used in investing activities was $76.9 million, primarily resulting from cash used for capital expenditures of $64.2 million, including the purchase of a wafer fabrication facility in California that we previously leased, and $12.8 million for the acquisition of Time-Bandwidth.

[0001628280-16-019400:mdna:144]
Cash provided by financing activities was $26.2 million resulting from net transfers of cash from Viavi.

[0001628280-16-019400:mdna:145]
Liquidity and Capital Resources Requirement

[0001628280-16-019400:mdna:146]
Our primary liquidity and capital spending requirements over at least the next 12 months will be the funding of our operating activities and capital expenditures. We believe that our cash and cash equivalents as of July 2, 2016, and cash flows from our operating activities will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months. However, there are a number of factors that could positively or negatively impact our liquidity position, including:

[0001628280-16-019400:mdna:147]
| • | global economic conditions which affect demand for our products and services and impact the financial stability of our suppliers and customers; |

[0001628280-16-019400:mdna:148]
| • | changes in accounts receivable, inventory or other operating assets and liabilities which affect our working capital; |

[0001628280-16-019400:mdna:149]
| • | increase in capital expenditures to support the revenue growth opportunity of our business; |

[0001628280-16-019400:mdna:150]
| • | the tendency of customers to delay payments or to negotiate favorable payment terms to manage their own liquidity positions; |

[0001628280-16-019400:mdna:151]
| • | timing of payments to our suppliers; |

[0001628280-16-019400:mdna:152]
| • | factoring or sale of accounts receivable; |

[0001628280-16-019400:mdna:153]
| • | volatility in fixed income and credit which impact the liquidity and valuation of our investment portfolios; |

[0001628280-16-019400:mdna:154]
| • | volatility in foreign exchange markets which impacts our financial results; |

[0001628280-16-019400:mdna:155]
| • | possible investments or acquisitions of complementary businesses, products or technologies; |

[0001628280-16-019400:mdna:156]
| • | issuance of debt or equity securities; and |

[0001628280-16-019400:mdna:157]
| • | potential funding of pension liabilities either voluntarily or as required by law or regulation. |

[0001628280-16-019400:mdna:158]
45
