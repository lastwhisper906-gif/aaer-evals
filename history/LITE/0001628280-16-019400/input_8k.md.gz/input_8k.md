# LITE 8-K — 0001628280-16-018811 filed 2016-08-09

## item codes, every 8-K on or before 2016-09-02

- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2016-09-02

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001628280-16-018811:8k_2_02:1]
EX-99.1
2
lite_ex991xq4fy16.htm
EXHIBIT 99.1

[0001628280-16-018811:8k_2_02:2]
Exhibit

[0001628280-16-018811:8k_2_02:3]
NEWS RELEASE

[0001628280-16-018811:8k_2_02:4]
LUMENTUM ANNOUNCES FISCAL FOURTH QUARTER AND FULL YEAR 2016 RESULTS

[0001628280-16-018811:8k_2_02:5]
Fourth Fiscal Quarter Highlights

[0001628280-16-018811:8k_2_02:6]
| • | Net Revenue of $241.7 million at high-end of guidance |

[0001628280-16-018811:8k_2_02:7]
| • | GAAP Operating margin of 4.2%; Non-GAAP Operating margin of 11.6% exceeded high-end of guidance |

[0001628280-16-018811:8k_2_02:8]
| • | GAAP diluted Net income per share of $0.23; Non-GAAP diluted Net income per share of $0.41 exceeded high-end of guidance |

[0001628280-16-018811:8k_2_02:9]
Milpitas, Calif., August 9, 2016 – Lumentum Holdings Inc. (“Lumentum” or the “Company”) today reported results for its fiscal fourth quarter and year ended July 2, 2016.

[0001628280-16-018811:8k_2_02:10]
Net revenue for the fiscal fourth quarter 2016 was $241.7 million, with GAAP net income of 14.3 million, or $0.23 per diluted share. Net revenue for fiscal third quarter 2016, which was a fourteen week quarter, was $230.4 million, with GAAP net loss of $(7.6) million, or $(0.13) per diluted share. Net revenue for the fiscal fourth quarter 2015 was $208.9 million, with GAAP net loss of $(15.8) million, or $(0.27) per diluted share.

[0001628280-16-018811:8k_2_02:11]
Non-GAAP net income for the fiscal fourth quarter 2016 was $25.4 million or $0.41 per diluted share. Non-GAAP net income for fiscal third quarter 2016 was $19.7 million, or $0.32 per diluted share. Non-GAAP net income for the fiscal fourth quarter 2015 was $9.1 million, or $0.15 per diluted share. The Company held $157.1 million in total cash at the end of the fiscal fourth quarter 2016, which decreased by $0.1 million sequentially, and the Company remains debt-free.

[0001628280-16-018811:8k_2_02:12]
“Fiscal fourth quarter results were driven by strong growth in newer products, combined with operating leverage,” said Alan Lowe, president and CEO. “We achieved record revenues that grew approximately 16% over the same period last year; our 100G Datacom revenue was up 40% sequentially and 241% year-over-year; TrueFlex® ROADM revenue was up 21% sequentially, and 226% from last year; and, Commercial Lasers was up 22% sequentially and 35% from last year. The book-to-bill ratio was greater than one, as North America metro deployments begin to ramp, hyperscale data centers ready themselves for the shift to 100G, customer demand for fiber lasers is strengthening, and demand in China remains robust.”

[0001628280-16-018811:8k_2_02:13]
Financial Overview – Fiscal Fourth Quarter Ended July 2, 2016

[0001628280-16-018811:8k_2_02:14]
|  | GAAP Results ($ in millions) |
|  | Q4 |  | Q3 |  | Q4 |  | Change |
|  | FY 2016 |  | FY 2016 |  | FY 2015 |  | Q/Q |  | Y/Y |
| Net revenue | $ | 241.7 |  |  | $ | 230.4 |  |  | $ | 208.9 |  |  | 4.9 | % |  | 15.7 | % |
| Gross margin | 32.9 | % |  | 27.3 | % |  | 30.4 | % |  | 560bps |  |  | 250bps |  |
| Operating margin | 4.2 | % |  | (1.0 | )% |  | (7.0 | )% |  | 520bps |  |  | 1,120bps |  |
|  | Non-GAAP Results ($ in millions) |
|  | Q4 |  | Q3 |  | Q4 |  | Change |
|  | FY 2016 |  | FY 2016 |  | FY 2015 |  | Q/Q |  | Y/Y |
| Net revenue | $ | 241.7 |  |  | $ | 230.4 |  |  | $ | 208.9 |  |  | 4.9 | % |  | 15.7 | % |
| Gross margin | 34.1 | % |  | 32.2 | % |  | 32.0 | % |  | 190bps |  |  | 210bps |  |
| Operating margin | 11.6 | % |  | 8.8 | % |  | 4.4 | % |  | 280bps |  |  | 720bps |  |

[0001628280-16-018811:8k_2_02:15]
|  | Net Revenue by Segment ($ in millions) |
|  | Q4 |  | % of |  | Q3 |  | Q4 |  | Change |
|  | FY 2016 |  | Net Revenue |  | FY 2016 |  | FY 2015 |  | Q/Q |  | Y/Y |
| Optical Communications | $ | 201.2 |  |  | 83.2 | % |  | $ | 197.2 |  |  | $ | 178.9 |  |  | 2.0 | % |  | 12.5 | % |
| Lasers | 40.5 |  |  | 16.8 | % |  | 33.2 |  |  | 30.0 |  |  | 22.0 | % |  | 35.0 | % |
| Total | $ | 241.7 |  |  | 100.0 | % |  | $ | 230.4 |  |  | $ | 208.9 |  |  | 4.9 | % |  | 15.7 | % |

[0001628280-16-018811:8k_2_02:16]
Financial Overview – Fiscal Year Ended July 2, 2016

[0001628280-16-018811:8k_2_02:17]
|  | GAAP Results ($ in millions) |
|  | FY 2016 |  | FY2015 |  | Change Y/Y |
| Net revenue | $ | 903.0 |  |  | $ | 837.1 |  |  | 7.9 | % |
| Gross margin | 30.7 | % |  | 30.8 | % |  | (10)bps |  |
| Operating margin | 1.3 | % |  | (2.8 | )% |  | 410bps |  |
|  | Non-GAAP Results ($ in millions) |
|  | FY 2016 |  | FY2015 |  | Change Y/Y |
| Net revenue | $ | 903.0 |  |  | $ | 837.1 |  |  | 7.9 | % |
| Gross margin | 33.0 | % |  | 32.5 | % |  | 50bps |  |
| Operating margin | 9.2 | % |  | 5.4 | % |  | 380bps |  |

[0001628280-16-018811:8k_2_02:18]
|  | Net Revenue by Segment ($ in millions) |
|  | Q4 |  | % of |  | Q4 |  | Change |
|  | FY 2016 |  | Net Revenue |  | FY 2015 |  | Y/Y |
| Optical Communications | $ | 761.3 |  |  | 84.3 | % |  | $ | 694.1 |  |  | 9.7 | % |
| Lasers | 141.7 |  |  | 15.7 | % |  | 143.0 |  |  | (0.9 | )% |
| Total | $ | 903.0 |  |  | 100.0 | % |  | $ | 837.1 |  |  | 7.9 | % |

[0001628280-16-018811:8k_2_02:19]
The tables above provide comparisons of quarterly results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled “Use of Non-GAAP Financial Measures.”

[0001628280-16-018811:8k_2_02:20]
Business Outlook

[0001628280-16-018811:8k_2_02:21]
For the fiscal first quarter 2017, the Company expects net revenue to be in the range of $245 million to $255 million, non-GAAP operating margin to be 11.0% to 12.5%, and non-GAAP diluted earnings per share to be $0.40 to $0.46 per share, based on approximately 62.5 million shares outstanding on a fully diluted basis.

[0001628280-16-018811:8k_2_02:22]
We have not provided reconciliations from GAAP to non-GAAP measures for our outlook. A large portion of non-GAAP adjustments, such as derivative liability adjustments, restructuring, stock-based compensation, litigation, and other costs and contingencies unrelated to current and future operations are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future.  For example, the unrealized gain or loss on the derivative liability for Series A Preferred Stock is revalued based on the fair market value of our common stock on the last day of the fiscal quarter, which is difficult to predict and subject to constant change.

[0001628280-16-018811:8k_2_02:23]
Conference Call

[0001628280-16-018811:8k_2_02:24]
Lumentum will host a conference call on August 9, 2016 at 1:30pm PT/4:30pm ET. A live webcast of the call and the replay will be available on the Lumentum website at http://investor.lumentum.com. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the “Events and Presentations” section concurrently with this earnings press release. This press release is being furnished as a Current Report on Form 8-K with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001628280-16-018811:8k_2_02:25]
About Lumentum

[0001628280-16-018811:8k_2_02:26]
Lumentum (NASDAQ: LITE) is a market-leading manufacturer of innovative optical and photonic products enabling optical networking and commercial laser customers worldwide. Lumentum’s optical components and subsystems are part of virtually every type of telecom, enterprise, and data center network. Lumentum’s commercial lasers enable advanced manufacturing techniques and diverse applications including next-generation 3D sensing capabilities. Lumentum is headquartered in Milpitas, California with R&D, manufacturing, and sales offices worldwide.  For more information, visit https://www.lumentum.com/en.

[0001628280-16-018811:8k_2_02:27]
Forward-Looking Statements

[0001628280-16-018811:8k_2_02:28]
Contact Information

[0001628280-16-018811:8k_2_02:29]
Investors: Chris Coldren, 408-404-0606; investor.relations@lumentum.com

[0001628280-16-018811:8k_2_02:30]
Press: Greg Kaufman, 408-546-4235; media@lumentum.com

[0001628280-16-018811:8k_2_02:31]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001628280-16-018811:8k_2_02:32]
LUMENTUM HOLDINGS INC.

[0001628280-16-018811:8k_2_02:33]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001628280-16-018811:8k_2_02:34]
(in millions, except per share data)

[0001628280-16-018811:8k_2_02:35]
(unaudited)

[0001628280-16-018811:8k_2_02:36]
|  | Three Months Ended |  | Twelve Months Ended |
|  | July 2, 2016 |  | June 27, 2015 |  | July 2, 2016 |  | June 27, 2015 |
| Net revenue | $ | 241.7 |  |  | $ | 208.9 |  |  | $ | 903.0 |  |  | $ | 837.1 |  |
| Cost of sales | 160.5 |  |  | 143.4 |  |  | 618.9 |  |  | 571.6 |  |
| Amortization of acquired technologies | 1.7 |  |  | 1.9 |  |  | 6.8 |  |  | 7.6 |  |
| Gross profit | 79.5 |  |  | 63.6 |  |  | 277.3 |  |  | 257.9 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 36.4 |  |  | 35.7 |  |  | 141.1 |  |  | 140.8 |  |
| Selling, general and administrative | 29.5 |  |  | 37.6 |  |  | 117.3 |  |  | 128.9 |  |
| Restructuring and related charges | 3.5 |  |  | 4.9 |  |  | 7.4 |  |  | 11.6 |  |
| Total operating expenses | 69.4 |  |  | 78.2 |  |  | 265.8 |  |  | 281.3 |  |
| Income (loss) from operations | 10.1 |  |  | (14.6 | ) |  | 11.5 |  |  | (23.4 | ) |
| Unrealized gain (loss) on derivative liability | 4.4 |  |  | — |  |  | (0.6 | ) |  | — |  |
| Interest and other (expense) income, net | (0.1 | ) |  | (0.3 | ) |  | (1.2 | ) |  | (1.1 | ) |
| Income (loss) before income taxes | 14.4 |  |  | (14.9 | ) |  | 9.7 |  |  | (24.5 | ) |
| Provision for (benefit from) income taxes | 0.1 |  |  | 0.9 |  |  | 0.4 |  |  | (21.1 | ) |
| Net income (loss) | 14.3 |  |  | (15.8 | ) |  | 9.3 |  |  | (3.4 | ) |
| Net income (loss) per share:(a) |  |  |  |  |  |  |  |
| Basic | $ | 0.24 |  |  | $ | (0.27 | ) |  | $ | 0.16 |  |  | $ | (0.06 | ) |
| Diluted | $ | 0.23 |  |  | $ | (0.27 | ) |  | $ | 0.15 |  |  | $ | (0.06 | ) |
| Items reconciling net income (loss) to net income (loss) available to common shareholders: |  |  |  |  |  |  |  |
| Cumulative dividends on Series A preferred stock | (0.2 | ) |  | — |  |  | (0.8 | ) |  | — |  |
| Adjustment for Series A preferred stock redemption value | — |  |  | — |  |  | (11.7 | ) |  | — |  |
| Net income (loss) available to common shareholders | $ | 14.1 |  |  | $ | (15.8 | ) |  | $ | (3.2 | ) |  | $ | (3.4 | ) |
| Net income (loss) available to common shareholders per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.24 |  |  | $ | (0.27 | ) |  | $ | (0.05 | ) |  | $ | (0.06 | ) |
| Diluted | $ | 0.23 |  |  | $ | (0.27 | ) |  | $ | (0.05 | ) |  | $ | (0.06 | ) |
| Shares used in per share calculation:(a) |  |  |  |  |  |  |  |
| Basic | 59.4 |  |  | 58.8 |  |  | 59.1 |  |  | 58.8 |  |
| Diluted | 61.8 |  |  | 58.8 |  |  | 61.2 |  |  | 58.8 |  |

[0001628280-16-018811:8k_2_02:37]
| (a) | On August 1, 2015, JDSU distributed 47.1 million shares, or 80.1% of the outstanding shares of common stock of Lumentum to existing holders of JDSU common stock. JDSU was renamed Viavi Solutions Inc. and at the time of the distribution, retained 11.7 million shares, or 19.9% of Lumentum’s outstanding shares. Basic and diluted net income (loss) per share for the three and twelve months ended June 27, 2015 are calculated using the shares of Lumentum common stock outstanding on August 1, 2015. |

[0001628280-16-018811:8k_2_02:38]
LUMENTUM HOLDINGS INC.

[0001628280-16-018811:8k_2_02:39]
CONSOLIDATED BALANCE SHEETS

[0001628280-16-018811:8k_2_02:40]
(in millions, except share and per share data)

[0001628280-16-018811:8k_2_02:41]
(unaudited)

[0001628280-16-018811:8k_2_02:42]
|  | July 2, 2016 |  | June 27, 2015 |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |  |
| Cash and cash equivalents | $ | 157.1 |  |  | $ | 14.5 |  |
| Accounts receivable, net | 170.5 |  |  | 150.5 |  |
| Inventories | 100.6 |  |  | 99.7 |  |
| Prepayments and other current assets | 61.3 |  |  | 46.1 |  |
| Total current assets | 489.5 |  |  | 310.8 |  |
| Property, plant and equipment, net | 183.4 |  |  | 143.2 |  |
| Goodwill and intangibles, net | 19.9 |  |  | 27.4 |  |
| Deferred income taxes, net | 31.9 |  |  | 30.3 |  |
| Other non-current assets | 1.6 |  |  | 0.9 |  |
| Total assets | $ | 726.3 |  |  | $ | 512.6 |  |
| LIABILITIES, MEZZANINE EQUITY AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 118.3 |  |  | $ | 77.9 |  |
| Accrued payroll and related expenses | 26.5 |  |  | 17.7 |  |
| Income taxes payable | 1.9 |  |  | 3.7 |  |
| Accrued expenses | 14.9 |  |  | 11.5 |  |
| Other current liabilities | 12.1 |  |  | 11.4 |  |
| Total current liabilities | 173.7 |  |  | 122.2 |  |
| Derivative liability | 10.3 |  |  | — |  |
| Other non-current liabilities | 9.1 |  |  | 9.8 |  |
| Total liabilities | 193.1 |  |  | 132.0 |  |
| Mezzanine equity: |  |  |  |
| Non-controlling interest redeemable convertible Series A preferred stock, $0.001 par value, 10,000,000 authorized shares; 35,805 shares issued and outstanding as of July 2, 2016, and no shares issued and outstanding as of June 27, 2015 | 35.8 |  |  | — |  |
| Total mezzanine equity | 35.8 |  |  | — |  |
| Stockholders’ equity: |  |  |  |
| Viavi net investment | — |  |  | 368.1 |  |
| Common stock, $0.001 par value, 990,000,000 authorized shares, 59,580,596 shares issued and outstanding as of July 2, 2016, and no shares issued and outstanding as of June 27, 2015 | 0.1 |  |  | — |  |
| Additional paid-in capital | 467.7 |  |  | — |  |
| Retained earnings | 20.2 |  |  | — |  |
| Accumulated other comprehensive income | 9.4 |  |  | 12.5 |  |
| Total stockholders’ equity | 497.4 |  |  | 380.6 |  |
| Total liabilities, mezzanine equity and stockholders’ equity | $ | 726.3 |  |  | $ | 512.6 |  |

[0001628280-16-018811:8k_2_02:43]
Use of Non-GAAP Financial Measures

[0001628280-16-018811:8k_2_02:44]
In this press release, Lumentum provides investors with gross margin, operating margin, net income, and net income (loss) per share on a non-GAAP basis. Lumentum believes this non-GAAP financial information provides additional insight into the Company's on-going performance and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company's on-going operations and enable more meaningful period to period comparisons. Specifically, the Company believes that providing this information allows investors to better understand the Company’s financial performance and, importantly, to evaluate the efficacy of the methodology and information used by management to evaluate and measure such operating performance.  However, these measures may be different from non-GAAP measures used by other companies, limiting their usefulness for comparison purposes. The non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP. Investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future.

[0001628280-16-018811:8k_2_02:45]
Non-GAAP gross margin, non-GAAP operating margin, non-GAAP net income (loss), and non-GAAP net income (loss) per share, and Adjusted EBITDA exclude (i) workforce related charges such as severance, retention bonuses and employee relocation costs related to formal restructuring plans, (ii) costs for facilities not required for ongoing operations, and costs related to the relocation of certain equipment from these facilities and/or contract manufacturer facilities, (iii) stock-based compensation, (iv) amortization of intangibles, and (v) other non-recurring charges comprising mainly of one-time provision for excess and obsolete inventory, acquisition, integration, litigation and other costs and contingencies unrelated to current and future operations including post-separation activities such as small site consolidations, reorganizations, insourcing or outsourcing of activities, severance related costs and transition related costs for the separation from Viavi. Beginning in the third fiscal quarter 2016, we began to exclude unrealized gain or loss on derivative liability for the Series A Preferred Stock to Adjusted EBITDA and prior periods have been adjusted. Management does not believe that these items are reflective of the Company's underlying operating performance. The presentation of these and other similar items in Lumentum's non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001628280-16-018811:8k_2_02:46]
A quantitative reconciliation between GAAP and non-GAAP financial data with respect to historical periods is included in the supplemental financial table attached to this press release. The Company has not reconciled its projections of non-GAAP earnings per share.  As items that impact net loss are out of the Company's control and/or cannot be reasonably predicted, Lumentum has determined that a quantitative reconciliation of forward-looking non-GAAP financial measures to their most directly comparable GAAP financial measures cannot be provided without unreasonable efforts.

[0001628280-16-018811:8k_2_02:47]
LUMENTUM HOLDINGS INC.

[0001628280-16-018811:8k_2_02:48]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001628280-16-018811:8k_2_02:49]
(in millions, except per share data)

[0001628280-16-018811:8k_2_02:50]
(unaudited)

[0001628280-16-018811:8k_2_02:51]
|  | Three Months Ended |  | Twelve Months Ended |
|  | July 2, 2016 |  | June 27, 2015 |  | July 2, 2016 |  | June 27, 2015 |
| Gross profit on GAAP basis | $ | 79.5 |  |  | $ | 63.6 |  |  | $ | 277.3 |  |  | $ | 257.9 |  |
| Stock-based compensation | 1.2 |  |  | 1.2 |  |  | 6.1 |  |  | 5.1 |  |
| Other charges related to non-recurring activities (b) | — |  |  | 0.2 |  |  | 7.2 |  |  | 1.6 |  |
| Amortization of acquired developed technologies | 1.7 |  |  | 1.9 |  |  | 6.8 |  |  | 7.6 |  |
| Restructuring and related charges | — |  |  | — |  |  | 0.3 |  |  | — |  |
| Gross profit on non-GAAP basis | $ | 82.4 |  |  | $ | 66.9 |  |  | $ | 297.7 |  |  | $ | 272.2 |  |
| Research and development on GAAP basis | $ | 36.4 |  |  | $ | 35.7 |  |  | $ | 141.1 |  |  | $ | 140.8 |  |
| Stock-based compensation | (2.3 | ) |  | (1.8 | ) |  | (9.0 | ) |  | (7.4 | ) |
| Other charges related to non-recurring activities (b) | (0.1 | ) |  | — |  |  | (0.7 | ) |  | (0.2 | ) |
| Research and development on non-GAAP basis | $ | 34.0 |  |  | $ | 33.9 |  |  | $ | 131.4 |  |  | $ | 133.2 |  |
| Selling, general and administrative on GAAP basis | $ | 29.5 |  |  | $ | 37.6 |  |  | $ | 117.3 |  |  | $ | 128.9 |  |
| Stock-based compensation | (2.5 | ) |  | (3.1 | ) |  | (11.8 | ) |  | (14.7 | ) |
| Other charges related to non-recurring activities (b) | (6.5 | ) |  | (10.5 | ) |  | (21.9 | ) |  | (19.8 | ) |
| Amortization of intangibles | (0.1 | ) |  | (0.1 | ) |  | (0.4 | ) |  | (0.4 | ) |
| Selling, general and administrative on non-GAAP basis | $ | 20.4 |  |  | $ | 23.9 |  |  | $ | 83.2 |  |  | $ | 94.0 |  |
| Income (loss) from operations on GAAP basis | $ | 10.1 |  |  | $ | (14.6 | ) |  | $ | 11.5 |  |  | $ | (23.4 | ) |
| Stock-based compensation | 6.0 |  |  | 6.1 |  |  | 26.9 |  |  | 27.2 |  |
| Other charges related to non-recurring activities (b) | 6.6 |  |  | 10.7 |  |  | 29.8 |  |  | 21.6 |  |
| Amortization of intangibles | 1.8 |  |  | 2.0 |  |  | 7.2 |  |  | 8.0 |  |
| Restructuring and related charges | 3.5 |  |  | 4.9 |  |  | 7.7 |  |  | 11.6 |  |
| Income (loss) from operations on non-GAAP basis | $ | 28.0 |  |  | $ | 9.1 |  |  | $ | 83.1 |  |  | $ | 45.0 |  |
| Income (loss) before income taxes on GAAP basis | $ | 14.4 |  |  | $ | (14.9 | ) |  | $ | 9.7 |  |  | $ | (24.5 | ) |
| Stock-based compensation | 6.0 |  |  | 6.1 |  |  | 26.9 |  |  | 27.2 |  |
| Other charges related to non-recurring activities (b) | 6.6 |  |  | 10.7 |  |  | 29.8 |  |  | 21.6 |  |
| Amortization of intangibles | 1.8 |  |  | 2.0 |  |  | 7.2 |  |  | 8.0 |  |
| Restructuring and related charges | 3.5 |  |  | 4.9 |  |  | 7.7 |  |  | 11.6 |  |
| Unrealized (gain) loss on derivative liability | (4.4 | ) |  | — |  |  | 0.6 |  |  | — |  |
| Income (loss) before income taxes on non-GAAP basis | $ | 27.9 |  |  | $ | 8.8 |  |  | $ | 81.9 |  |  | $ | 43.9 |  |
| Provision for income taxes on GAAP basis | $ | 0.1 |  |  | $ | 0.9 |  |  | $ | 0.4 |  |  | $ | (21.1 | ) |
| Non-cash income tax (benefit) expense | 2.4 |  |  | (1.2 | ) |  | 2.6 |  |  | 19.1 |  |
| Provision (benefit) for income taxes on non-GAAP basis | $ | 2.5 |  |  | $ | (0.3 | ) |  | $ | 3.0 |  |  | $ | (2.0 | ) |
| Net income (loss) on GAAP basis | $ | 14.3 |  |  | $ | (15.8 | ) |  | $ | 9.3 |  |  | $ | (3.4 | ) |
| Stock-based compensation | 6.0 |  |  | 6.1 |  |  | 26.9 |  |  | 27.2 |  |

[0001628280-16-018811:8k_2_02:52]
| Other charges related to non-recurring activities (b) | 6.6 |  |  | 10.7 |  |  | 29.8 |  |  | 21.6 |  |
| Amortization of intangibles | 1.8 |  |  | 2.0 |  |  | 7.2 |  |  | 8.0 |  |
| Restructuring and related charges | 3.5 |  |  | 4.9 |  |  | 7.7 |  |  | 11.6 |  |
| Unrealized (gain) loss on derivative liability | (4.4 | ) |  | — |  |  | 0.6 |  |  | — |  |
| Non-cash income tax (benefit) expense | (2.4 | ) |  | 1.2 |  |  | (2.6 | ) |  | (19.1 | ) |
| Net income on non-GAAP basis | $ | 25.4 |  |  | $ | 9.1 |  |  | $ | 78.9 |  |  | $ | 45.9 |  |
| Net income per share on non-GAAP basis | $ | 0.41 |  |  | $ | 0.15 |  |  | $ | 1.29 |  |  | $ | 0.78 |  |
| Shares used in per share calculation - diluted on GAAP and non-GAAP basis | 61.8 |  |  | 58.8 |  |  | 61.2 |  |  | 58.8 |  |

[0001628280-16-018811:8k_2_02:53]
| (b) | Other charges related to non-recurring activities for the twelve months ended July 2, 2016 include provision for excess and obsolete inventory relating to certain 3D sensing products, acquisition, integration, litigation and other costs and contingencies unrelated to current and future operations including post-separation activities such as small site consolidations, reorganizations, insourcing or outsourcing of activities, severance related costs and transition related costs for the separation from Viavi. |

[0001628280-16-018811:8k_2_02:54]
LUMENTUM HOLDINGS INC.

[0001628280-16-018811:8k_2_02:55]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EBITDA

[0001628280-16-018811:8k_2_02:56]
(in millions)

[0001628280-16-018811:8k_2_02:57]
(unaudited)

[0001628280-16-018811:8k_2_02:58]
|  | Three Months Ended |  | Twelve Months Ended |
|  | July 2, 2016 |  | June 27, 2015 |  | July 2, 2016 |  | June 27, 2015 |
| GAAP net income (loss) | $ | 14.3 |  |  | $ | (15.8 | ) |  | $ | 9.3 |  |  | $ | (3.4 | ) |
| Interest and other (expense) income, net | 0.1 |  |  | 0.3 |  |  | 1.2 |  |  | 1.1 |  |
| Provision for income taxes | 0.1 |  |  | 0.9 |  |  | 0.4 |  |  | (21.1 | ) |
| Depreciation | 12.3 |  |  | 10.9 |  |  | 47.4 |  |  | 43.0 |  |
| Amortization | 1.8 |  |  | 2.0 |  |  | 7.2 |  |  | 8.0 |  |
| EBITDA | 28.6 |  |  | (1.7 | ) |  | 65.5 |  |  | 27.6 |  |
| Costs related to restructuring and related charges | 3.5 |  |  | 4.9 |  |  | 7.7 |  |  | 11.6 |  |
| Costs related to stock-based compensation | 6.0 |  |  | 6.1 |  |  | 26.9 |  |  | 27.2 |  |
| Costs related to other non-recurring activities (b) | 6.6 |  |  | 10.7 |  |  | 29.8 |  |  | 21.6 |  |
| Unrealized (gain) loss on derivative liability | (4.4 | ) |  | — |  |  | 0.6 |  |  | — |  |
| Adjusted EBITDA | $ | 40.3 |  |  | $ | 20.0 |  |  | $ | 130.5 |  |  | $ | 88.0 |  |
