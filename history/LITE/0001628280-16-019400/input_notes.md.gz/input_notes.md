# LITE notes — 0001628280-16-019400


## lite:ConcentrationOfCreditAndOtherRisksAndAllowanceForDoubtfulAccountsPolicyTextBlock

[0001628280-16-019400:notes:1]
Concentration of Credit and Other Risks

[0001628280-16-019400:notes:2]
Financial instruments that potentially subject our business to concentration of credit risk consist primarily of cash and cash equivalents and trade receivables. We perform credit evaluations of our customers' financial condition and generally do not require collateral from our customers. These evaluations require significant judgment and are based on a variety of factors including, but not limited to, current economic trends, payment history, bad debt write-off experience, and financial review of the customer.

[0001628280-16-019400:notes:3]
We maintain an allowance for doubtful accounts for estimated losses resulting from the inability of our customers to make required payments. When we become aware that a specific customer is unable to meet their financial obligations, we record a specific allowance to reflect the level of credit risk in the customer's outstanding receivable balance. In addition, we record additional allowances based on certain percentages of aged receivable balances. These percentages take into account a variety of factors including, but not limited to, current economic trends, payment history and bad debt write-off experience. We classify bad debt expenses as selling, general and administrative ("SG&A") expense.

[0001628280-16-019400:notes:4]
We have significant trade receivables concentrated in the telecommunications industry. While our allowance for doubtful accounts balance is based on historical loss experience along with anticipated economic trends, unanticipated financial instability in the telecommunications industry could lead to higher than anticipated losses.

[0001628280-16-019400:notes:5]
During fiscal 2016, 2015 and 2014, several customers generated more than 10% of total net revenue. Refer to "Note 16. Operating Segments and Geographic Information" in the Notes to Consolidated Financial Statements.

[0001628280-16-019400:notes:6]
As of July 2, 2016, Huawei Technologies Co., Ltd represented greater than 10% of total account receivable, net and as of June 27, 2015, no customers represented greater than 10% of our total accounts receivable, net.

[0001628280-16-019400:notes:7]
We rely on a limited number of suppliers for a number of key components contained in our products. We also rely on a limited number of significant independent contract manufacturers for the production of certain key components and subassemblies contained in our products.

[0001628280-16-019400:notes:8]
We generally use a rolling twelve month forecast based on anticipated product orders, customer forecasts, product order history and backlog to determine our materials requirements. Lead times for the parts and components that we order vary significantly and depend on factors such as the specific supplier, contract terms and demand for a component at a given time. If the forecast does not meet or if it exceeds actual demand, we may have excess or shortfalls of some materials and components, as well as excess inventory purchase commitments. We could experience reduced or delayed product shipments or incur additional inventory write-downs and cancellation charges or penalties, which would increase costs and could have a material adverse impact on our results of operations.


## lite:PropertyPlantandEquipmentNetTableTextBlock

[0001628280-16-019400:notes:9]
The components of property, plant and equipment, net were as follows (in millions):

[0001628280-16-019400:notes:10]
|  | July 2, 2016 |  | June 27, 2015 |
| Land | $ | 5.9 |  |  | $ | 5.9 |  |
| Buildings and improvement | 28.9 |  |  | 28.6 |  |
| Machinery and equipment | 378.5 |  |  | 326.4 |  |
| Furniture and fixtures and software | 32.2 |  |  | 8.0 |  |
| Leasehold improvements | 28.6 |  |  | 20.5 |  |
| Construction in progress | 44.1 |  |  | 26.8 |  |
|  | 518.2 |  |  | 416.2 |  |
| Less: Accumulated depreciation | (334.8 | ) |  | (273.0 | ) |
| Property, plant and equipment, net | $ | 183.4 |  |  | $ | 143.2 |  |


## lite:ScheduleOfOtherLiabilitiesCurrentTableTextBlock

[0001628280-16-019400:notes:11]
The components of other current liabilities were as follows (in millions):

[0001628280-16-019400:notes:12]
|  | July 2, 2016 |  | June 27, 2015 |
| Warranty accrual | $ | 2.8 |  |  | $ | 2.8 |  |
| Restructuring accrual and related charges | 5.5 |  |  | 3.8 |  |
| Others | 3.8 |  |  | 4.8 |  |
| Other current liabilities | $ | 12.1 |  |  | $ | 11.4 |  |


## lite:ScheduleOfOtherLiabilitiesNoncurrentTableTextBlock

[0001628280-16-019400:notes:13]
The components of other non-current liabilities were as follows (in millions):

[0001628280-16-019400:notes:14]
|  | July 2, 2016 |  | June 27, 2015 |
| Asset retirement obligation | $ | 2.3 |  |  | $ | 1.8 |  |
| Pension and related accrual | 3.5 |  |  | 2.1 |  |
| Deferred rent | 1.6 |  |  | 1.7 |  |
| Restructuring accrual and related charges | 0.2 |  |  | 2.2 |  |
| Other non-current liabilities | 1.5 |  |  | 2.0 |  |
| Other non-current liabilities | $ | 9.1 |  |  | $ | 9.8 |  |


## lite:ScheduleOfPurchasePriceAllocationsTableTextBlock

[0001628280-16-019400:notes:15]
The purchase price was allocated as follows (in millions):

[0001628280-16-019400:notes:16]
| Net tangible assets acquired | $ | 2.0 |  |
| Intangible assets acquired: |  |
| Developed technology | 6.7 |  |
| Customer relationships | 0.5 |  |
| Goodwill | 5.8 |  |
| Total purchase price | $ | 15.0 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001628280-16-019400:notes:17]
Note 7. Balance Sheet and Other Details

[0001628280-16-019400:notes:18]
Accounts receivable allowances

[0001628280-16-019400:notes:19]
As of July 2, 2016, our accounts receivable allowance was $0.9 million. Our accounts receivable allowance balance as of June 27, 2015 was 1.2 million.

[0001628280-16-019400:notes:20]
Inventories

[0001628280-16-019400:notes:21]
The components of inventories were as follows (in millions):

[0001628280-16-019400:notes:22]
|  | July 2, 2016 |  | June 27, 2015 |
| Finished goods | $ | 46.1 |  |  | $ | 60.1 |  |
| Work in process | 25.5 |  |  | 23.4 |  |
| Raw materials and purchased parts | 29.0 |  |  | 16.2 |  |
| Inventories | $ | 100.6 |  |  | $ | 99.7 |  |

[0001628280-16-019400:notes:23]
Prepayments and other current assets

[0001628280-16-019400:notes:24]
The components of prepayments and other current assets were as follows (in millions):

[0001628280-16-019400:notes:25]
|  | July 2, 2016 |  | June 27, 2015 |
| Prepayments | $ | 33.7 |  |  | $ | 20.4 |  |
| Advances to contract manufacturers | 10.3 |  |  | 9.5 |  |
| Due from Viavi, net | 2.0 |  |  |  |
| Other current assets | 15.3 |  |  | 16.2 |  |
| Prepayments and other current assets | $ | 61.3 |  |  | $ | 46.1 |  |

[0001628280-16-019400:notes:26]
Amount due from Viavi, net represents certain obligations to be reimbursed from Viavi pursuant to the Separation and Distribution Agreement and Contribution Agreement.

[0001628280-16-019400:notes:27]
Property, plant and equipment, net

[0001628280-16-019400:notes:28]
During fiscal 2016, 2015 and 2014, we recorded depreciation expense of $47.4 million, $43.0 million and $35.5 million, respectively.

[0001628280-16-019400:notes:29]
Other current liabilities

[0001628280-16-019400:notes:30]
Other non-current liabilities

[0001628280-16-019400:notes:31]
Interest and other income (expense), net

[0001628280-16-019400:notes:32]
The components of interest and other income (expense), net were as follows (in millions):

[0001628280-16-019400:notes:33]
|  | Years Ended |
|  | July 2, 2016 |  | June 27, 2015 |  | June 28, 2014 |
| Interest expense | $ | (0.1 | ) |  | $ | (0.7 | ) |  | $ | (0.2 | ) |
| Foreign exchange gains (losses), net | $ | (0.9 | ) |  | $ | (0.3 | ) |  | $ | 1.6 |  |
| Other income (expense), net | (0.2 | ) |  | (0.1 | ) |  | (0.3 | ) |
| Interest and other income (expense), net | $ | (1.2 | ) |  | $ | (1.1 | ) |  | $ | 1.1 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001628280-16-019400:notes:34]
Basis of Presentation

[0001628280-16-019400:notes:35]
On July 31, 2015, prior to the Separation, Viavi transferred substantially all of the assets and liabilities and operations of the CCOP segment and WaveReady product lines to Lumentum (the “Separation"). Financial statements for periods prior to the Separation were prepared on a stand-alone basis and were derived from Viavi’s consolidated financial statements and accounting records. The Company prepared consolidated financial statements for the period from June 28, 2015 to August 1, 2015 where expenses were allocated to us using estimates that we consider to be a reasonable reflection of the utilization of services provided to, or benefits received by, us. From August 1, 2015 to July 2, 2016, the Company prepared consolidated financial statements as an independent stand-alone basis pursuant to the rules and regulations of the SEC and are in conformity with U.S. GAAP. In the opinion of management, these consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments, which are necessary for a fair statement of the consolidated financial statements for the periods shown. The results of operations for such periods are not necessarily indicative of the results expected for the full year or for any future periods.

[0001628280-16-019400:notes:36]
On August 1, 2015, Lumentum became an independent publicly-traded company through the distribution by JDS Uniphase ("JDSU") to its stockholders of  80.1% of our outstanding common stock (the “Separation”). Each JDSU stockholder of record as of the close of business on July 27, 2015 received one share of Lumentum common stock for every five shares of JDSU common stock held on the record date. JDSU was renamed Viavi and at the time of the distribution retained ownership of 19.9% of Lumentum’s outstanding shares. Lumentum was incorporated in Delaware as a wholly owned subsidiary of Viavi on February 10, 2015 and is comprised of the former communications and commercial optical products (“CCOP”) segment and WaveReady product lines of Viavi. Lumentum’s Registration Statement on Form 10 was declared effective by the SEC on July 16, 2015. Lumentum’s common stock began trading “regular-way” under the ticker “LITE” on the NASDAQ stock market on August 4, 2015.

[0001628280-16-019400:notes:37]
The preparation of the consolidated financial statements in accordance with GAAP in the United States requires management to make estimates and assumptions that affect the amounts reported in our consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, inventory valuation, allocation methods and allocated expenses from Viavi, valuation of goodwill and other intangible assets, stock-based compensation, retirement and post-retirement plan assumptions, restructuring, warranty and accounting for income taxes.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001628280-16-019400:notes:38]
Note 6. Mergers and Acquisitions

[0001628280-16-019400:notes:39]
Time-Bandwidth

[0001628280-16-019400:notes:40]
On January 27, 2014, we completed the acquisition of Time-Bandwidth, a privately-held company headquartered in Switzerland. Time-Bandwidth is a provider of high-powered and ultrafast lasers for industrial and scientific markets. We acquired all outstanding shares of Time-Bandwidth for a purchase price consideration of $15.0 million in cash, including a holdback amount of $2.3 million which had been withheld to satisfy potential breaches of representations and warranties. During the first quarter of fiscal 2016, and after the Separation from Viavi, we released the holdback amount of $2.3 million following the eighteen-month anniversary of the Time-Bandwidth Closing Date. The payment is classified as a financing activity within the consolidated statements of cash flows for the year ended  July 2, 2016.

[0001628280-16-019400:notes:41]
Time-Bandwidth provides innovative high-powered and ultrafast laser technology that can rapidly and precisely process parts at high volumes during the manufacturing process. Use of ultrafast lasers for micromachining applications is being driven primarily by increasing use of consumer electronics and connected devices globally. Manufacturers are taking advantage of high-power and ultrafast lasers to create quality micro parts for consumer electronics and to process semiconductor chips for consumer devices. Time-Bandwidth's technology complements our current laser portfolio, while enabling Time-Bandwidth to use Lumentum's high volume and low-cost manufacturing model, global sales team and channel relationships. Time-Bandwidth was integrated into our Lasers segment.

[0001628280-16-019400:notes:42]
We accounted for the transaction in accordance with the authoritative guidance on business combinations; therefore, the tangible and intangible assets acquired and liabilities assumed were recorded at fair value on the acquisition date.

[0001628280-16-019400:notes:43]
The following table summarizes the components of the net tangible assets acquired at fair value (in millions):

[0001628280-16-019400:notes:44]
| Accounts receivable | $ | 1.4 |  |
| Inventories | 5.0 |  |
| Property and equipment | 1.5 |  |
| Accounts payable | (0.6 | ) |
| Accrued expenses and other liabilities, net of other assets | (3.5 | ) |
| Deferred tax liabilities, net | (1.8 | ) |
| Net tangible assets acquired | $ | 2.0 |  |

[0001628280-16-019400:notes:45]
The fair value of acquired developed technology and customer relationships was determined based on an income approach using the discounted cash flow method. The acquired developed technology and customer relationships are being amortized over their estimated useful lives of eight and three years, respectively.

[0001628280-16-019400:notes:46]
The goodwill arising from this acquisition is primarily attributed to sales of future products and services and the assembled workforce of Time-Bandwidth. Goodwill has been assigned to the Lasers segment and is not deductible for tax purposes. Goodwill is not amortized, but reviewed annually for impairment or more frequently if impairment indicators arise.

[0001628280-16-019400:notes:47]
Time-Bandwidth's results of operations have been included in our consolidated financial statements subsequent to the date of acquisition.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001628280-16-019400:notes:48]
Note 1. Description of Business and Summary of Significant Accounting Policies

[0001628280-16-019400:notes:49]
Description of Business

[0001628280-16-019400:notes:50]
Lumentum is an industry leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including Datacom and Telecom networking and commercial lasers for manufacturing, inspection and life-science applications. We are using our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including 3-D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be OEMs that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that our NEM customers assemble into communications networking systems, which they sell to network service providers or enterprises with their own networks. Similarly, many of our customers for our Lasers products incorporate our products into tools they produce, which are used for manufacturing processes by their customers.

[0001628280-16-019400:notes:51]
See "Note 3. Related Party Transactions" in the Notes to Consolidated Financial Statements regarding the relationships we had with Viavi.

[0001628280-16-019400:notes:52]
Fiscal Years

[0001628280-16-019400:notes:53]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Our fiscal 2016 ended on July 2, 2016 and was a 53-week year. Our fiscal 2015 ended on June 27, 2015 and was a 52-week year. Our fiscal 2014 ended on June 28, 2014 and was a 52-week year.

[0001628280-16-019400:notes:54]
Principles of Consolidation

[0001628280-16-019400:notes:55]
The consolidated financial statements include certain assets and liabilities that were historically held at the Viavi level which were specifically identifiable or otherwise attributable to us. All intra-company transactions within our business were eliminated. All material transactions between us and other businesses of Viavi prior to Separation were reflected as net transfers to and from Viavi as a component of financing activities in the consolidated statements of cash flows.

[0001628280-16-019400:notes:56]
Use of Estimates

[0001628280-16-019400:notes:57]
The preparation of our consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amount of assets and liabilities at the date of the financial statements, the reported amount of net revenue and expenses and the disclosure of commitments and contingencies during the reporting periods. We base estimates on historical experience and on various assumptions about the future believed to be reasonable based on available information. Our reported financial position or results of operations may be materially different under changed conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies. If estimates or assumptions differ from actual results, subsequent periods are adjusted to reflect more current information.

[0001628280-16-019400:notes:58]
Accounting Policies

[0001628280-16-019400:notes:59]
Cash and Cash Equivalents

[0001628280-16-019400:notes:60]
We consider highly-liquid instruments such as money market funds with original maturities of 90 days or less at the time of purchase to be cash equivalents. As of fiscal year ended July 2, 2016 and June 27, 2015, our cash and cash equivalents do not include money market funds or other investments.

[0001628280-16-019400:notes:61]
Inventory is valued at standard cost, which approximates actual cost computed on a first-in, first-out basis, not in excess of net realizable value. We assess the valuation on a quarterly basis and write down the value for estimated excess and obsolete inventory based upon estimates of future demand. Our inventories include material, labor, and manufacturing overhead costs.

[0001628280-16-019400:notes:62]
Property, Plant and Equipment

[0001628280-16-019400:notes:63]
Property, plant and equipment are stated at cost. Depreciation is computed by the straight-line method generally over the following estimated useful lives of the assets: 10 to 50 years for building and improvements, 3 to 5 years for machinery and equipment, and 2 to 5 years for furniture, fixtures, software and office equipment. Leasehold improvements are amortized using the straight-line method over the shorter of the estimated useful lives of the assets or the term of the lease.

[0001628280-16-019400:notes:64]
Goodwill

[0001628280-16-019400:notes:65]
Goodwill represents the excess of the purchase price of an acquired business over the fair value of the identifiable assets acquired and liabilities assumed. We test for impairment of goodwill on an annual basis in the fourth quarter and at any other time when events occur or circumstances indicate that the carrying amount of goodwill may not be recoverable. Refer to "Note 10. Goodwill and Other Intangible Assets" in the Notes to Consolidated Financial Statements.

[0001628280-16-019400:notes:66]
Circumstances that could trigger an impairment test include, but are not limited to: a significant adverse change in the business climate or legal factors, an adverse action or assessment by a regulator, change in customer, target market and strategy, unanticipated competition, loss of key personnel, or the likelihood that a reporting unit or significant portion of a reporting unit will be sold or otherwise disposed.

[0001628280-16-019400:notes:67]
An assessment of qualitative factors may be performed to determine whether it is necessary to perform the two-step quantitative goodwill impairment test. If the result of the qualitative assessment is that it is more likely than not (i.e., greater than 50% likelihood) that the fair value of a reporting unit is less than its carrying amount, then the quantitative test is required. Otherwise, no further testing is required.

[0001628280-16-019400:notes:68]
Under the quantitative test, if the carrying amount of the reporting unit goodwill exceeds the implied fair value of that goodwill, an impairment loss is recorded in the consolidated statements of operations. We historically estimated the fair value of a reporting unit using the market approach, which estimates the fair value based on comparable market prices. Significant estimates in the market approach include: identifying similar companies with comparable business factors such as size, growth, profitability, risk and return on investment, and assessing comparable revenue and operating income multiples in estimating the fair value of the reporting unit.

[0001628280-16-019400:notes:69]
Intangible Assets

[0001628280-16-019400:notes:70]
Intangible assets consist primarily of purchased intangible assets through acquisitions. Purchased intangible assets primarily include acquired developed technologies (developed and core technology). Intangible assets are amortized using the straight-line method over the estimated economic useful lives of the assets, which is the period during which expected cash flows support the fair value of such intangible assets.

[0001628280-16-019400:notes:71]
Long-lived Asset Valuation (Property, Plant and Equipment and Intangible Assets Subject to Amortization)

[0001628280-16-019400:notes:72]
We test long-lived assets for recoverability, at the asset group level, when events or changes in circumstances indicate that their carrying amount may not be recoverable. Circumstances which could trigger a review include, but are not limited to: significant decreases in the market price of the asset, significant adverse changes in the business climate or legal factors, accumulation of costs significantly in excess of the amount originally expected for the acquisition or construction of the asset, current period cash flow or operating losses combined with a history of losses or a forecast of continuing losses associated with the use of the asset, or current expectation that the asset will more likely than not be sold or disposed significantly before the end of its estimated useful life.

[0001628280-16-019400:notes:73]
Recoverability is assessed based on the difference between the carrying amount of the asset and the sum of the undiscounted cash flows expected to result from the use and the eventual disposal of the asset. An impairment loss is recognized when the carrying amount is not recoverable and exceeds fair value.

[0001628280-16-019400:notes:74]
Pension Benefits

[0001628280-16-019400:notes:75]
The funded status of our retirement-related benefit plans is measured as the difference between the fair value of plan assets and the benefit obligation at fiscal year end, the measurement date. The funded status of a underfunded benefit plan, of which the fair value of plan assets is less than the benefit obligation, is recognized as a non-current net pension liability in the consolidated balance sheets unless the fair value of plan assets is not sufficient to cover the expected payments to be made over the next year (or operating cycle, if longer) from the measurement date. For defined benefit pension plans, the benefit obligation is the projected benefit obligation ("PBO") which represents the actuarial present value of benefits expected to be paid upon retirement.

[0001628280-16-019400:notes:76]
Net periodic pension cost (income) ("NPPC") is recorded in the consolidated statements of operations and includes service cost, interest cost, expected return on plan assets, amortization of prior service cost and (gains) losses previously recognized as a component of accumulated other comprehensive income. Service cost represents the actuarial present value of participant benefits attributed to services rendered by employees in the current year. Interest cost represents the time value of money cost associated with the passage of time. (Gains) losses arise as a result of differences between actual experience and assumptions or as a result of changes in actuarial assumptions. Prior service cost (credit) represents the cost of benefit improvements attributable to prior service granted in plan amendments. (Gains) losses and prior service cost (credit) that arise during the current year are first recognized as a component of accumulated other comprehensive income in the consolidated balances sheets, net of tax. Prior service cost is amortized as a component of NPPC over the average remaining service period of active plan participants starting at the date the plan amendment is adopted. Deferred actuarial (gains) losses are subsequently recognized as a component of NPPC if they exceed the greater of ten percent of PBO or the fair value of plan assets, with the excess amortized over the average remaining service period of active plan participants.

[0001628280-16-019400:notes:77]
The measurement of the benefit obligation and NPPC is based on our estimates and actuarial valuations, provided by third-party actuaries, which are approved by management. These valuations reflect the terms of the plans and use participant-specific information such as compensation, age and years of service, as well as certain assumptions, including estimates of discount rates, expected return on plan assets, rate of compensation increases, and mortality rates. We evaluate these assumptions annually at a minimum. In estimating the expected return on plan assets, we consider historical returns on plan assets, adjusted for forward-looking considerations, inflation assumptions and the impact of the active management of the plan's invested assets.

[0001628280-16-019400:notes:78]
Foreign Currency Translation

[0001628280-16-019400:notes:79]
Assets and liabilities of non-U.S. subsidiaries that operate in a local currency environment, where that local currency is the functional currency, are translated into U.S. dollars at exchange rates in effect at the balance sheet date, with the resulting translation adjustments directly recorded to a separate component of accumulated other comprehensive income, within the consolidated statements of redeemable convertible preferred stock, stock holders equity, and invested equity. Income and expense accounts are translated at the prior month balance sheet exchange rates, which are deemed to approximate average monthly rate. Gains and losses from re-measurement of monetary assets and liabilities denominated in currencies other than the respective functional currencies are included in the consolidated statements of operations as a component of interest and other income (expense), net. Net gains or (losses) resulting from foreign currency transactions, including hedging gains and losses that were previously allocated to us by Viavi, are reported in interest and other income (expense), net and was  $(0.9) million, $(0.3) million and $1.6 million during fiscal 2016, 2015 and 2014, respectively.

[0001628280-16-019400:notes:80]
Revenue Recognition

[0001628280-16-019400:notes:81]
We recognize revenue when all four revenue recognition criteria have been met: (i) persuasive evidence of an arrangement exists, (ii) the product has been delivered or the service has been rendered, (iii) the price is fixed or determinable and (iv) collection is reasonably assured. Revenue from product sales is recorded when all of the foregoing conditions are met and risk of loss and title passes to the customer. Our products typically include a warranty and the estimated cost of product warranty claims, based on historical experience, is recorded at the time the sale is recognized. Sales to customers are generally not subject to price protection or return rights.

[0001628280-16-019400:notes:82]
The majority of our sales are made to OEMs, distributors, resellers and end-users. These sales do not require installation of the products by us and are not subject to other post-delivery obligations. Additionally, our sales to distributors, resellers and end-user customers typically do not have customer acceptance provisions.

[0001628280-16-019400:notes:83]
Warranty

[0001628280-16-019400:notes:84]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We estimate the costs of our warranty obligations based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise.

[0001628280-16-019400:notes:85]
Shipping and Handling Costs

[0001628280-16-019400:notes:86]
We record costs related to shipping and handling of revenue in cost of sales for all periods presented.

[0001628280-16-019400:notes:87]
Research and Development ("R&D") Expense

[0001628280-16-019400:notes:88]
Costs related to R&D, which primarily consists of labor and benefits, supplies, facilities, consulting and outside service fees, are charged to expense as incurred.

[0001628280-16-019400:notes:89]
Invested Equity

[0001628280-16-019400:notes:90]
This balance represents the accumulation of our net earnings over time, through the date of the Separation including stock-based compensation recorded, cash transferred to and from Viavi, and net intercompany between us and Viavi.

[0001628280-16-019400:notes:91]
Stock-Based Compensation

[0001628280-16-019400:notes:92]
Stock-based compensation is measured at grant date, based on the fair value of the award, and recognized as compensation over the requisite service period. The fair value of time-based restricted units ("RSUs") is based on the closing market price of our common stock on the grant date of the award. For awards granted prior to the Separation, the fair value of time-based RSUs was based on the closing market price of Viavi common stock on the grant date of the award. We estimate the fair value of employee stock purchase plan ("ESPP") shares using the Black-Scholes Merton option-pricing model. These valuation models require the input of highly subjective assumptions, including the award's expected life, the price volatility of the underlying stock and the average volatility of peer companies.

[0001628280-16-019400:notes:93]
We estimate the expected forfeiture rate and recognize only expense for those shares expected to vest. When estimating forfeitures, we consider historical forfeiture experiences as well as our expectation about future terminations and workforce reduction programs. Estimated forfeiture is trued up to actual forfeiture as the equity awards vest. The total fair value of the equity awards, net of forfeiture, is recorded on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period, except for performance stock units which are amortized on a graded vesting method.

[0001628280-16-019400:notes:94]
Income Taxes

[0001628280-16-019400:notes:95]
Prior to the Separation, our operations in the United States were transacted within the same Viavi U.S. legal entities as the other Viavi businesses which have filed U.S. and state income tax returns on that basis. Accordingly, we were not able to retain many of the tax attributes attributable to our business as a matter of U.S. tax law. Therefore, we have not reflected on the balance sheet deferred tax assets and the corresponding valuation allowance related to certain federal net operating losses and credits generated before the Separation.

[0001628280-16-019400:notes:96]
In accordance with the authoritative guidance on accounting for income taxes, we recognize income taxes using an asset and liability approach. This approach requires the recognition of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in our consolidated financial statements or tax returns. The measurement of current and deferred taxes is based on provisions of the enacted tax law, and the effects of future changes in tax laws or rates are not anticipated.

[0001628280-16-019400:notes:97]
The authoritative guidance provides for recognition of deferred tax assets if the realization of such deferred tax assets is more likely than not to occur based on an evaluation of both positive and negative evidence and the relative weight of the evidence. With the exception of certain international jurisdictions, we have determined that at this time it is more likely than not that deferred tax assets attributable to the remaining jurisdictions will not be realized, primarily due to uncertainties related to our ability to utilize our net operating loss carryforwards before they expire. Accordingly, we have established a valuation allowance for such deferred tax assets. If there is a change in our ability to realize our deferred tax assets for which a valuation allowance has been established, then our tax provision may decrease in the period in which we determine that realization is more likely than not. Likewise, if we determine that it is not more likely than not that deferred tax assets will be realized, then a valuation allowance may be established for such deferred tax assets and our tax provision may increase in the period in which we make the determination.

[0001628280-16-019400:notes:98]
The authoritative guidance on accounting for uncertainty in income taxes clarifies the accounting for uncertainty in income taxes recognized in an entity's financial statements, and prescribes the recognition threshold and measurement attributes for financial statements recognition and measurement of a tax position taken or expected to be taken in a tax return. Additionally, it provides guidance on recognition, classification, and disclosure of tax positions. We are subject to income tax audits by the respective tax authorities in all of the jurisdictions in which we operate. The determination of tax liabilities in each of these jurisdictions requires the interpretation and application of complex and sometimes uncertain tax laws and regulations. We recognize liabilities based on our estimate of whether, and the extent to which, additional tax liabilities are more likely than not. If we ultimately determine that the payment of such a liability is not necessary, then we reverse the liability and recognize a tax benefit during the period in which the determination is made that the liability is no longer necessary.

[0001628280-16-019400:notes:99]
The recognition and measurement of current taxes payable or refundable and deferred tax assets and liabilities requires that we make certain estimates and judgments. Changes to these estimates or a change in judgment may have a material impact on our tax provision in a future period.

[0001628280-16-019400:notes:100]
Restructuring Accrual

[0001628280-16-019400:notes:101]
We recognize a liability for post-employment benefits for workforce reductions related to restructuring activities when payment is probable and the amount is reasonably estimable. In the case of leases, the expense is estimated and accrued when the property is vacated. We continually evaluate the adequacy of the remaining liabilities under our restructuring initiatives. Although we believe that these estimates accurately reflect the costs of our restructuring plans, actual results may differ, thereby requiring us to record additional provisions or reverse a portion of such provisions.

[0001628280-16-019400:notes:102]
In addition to the restructuring plans directly attributable to us, a portion of restructuring and related charges related to corporate and shared services employees was allocated by Viavi to us for restructuring activities prior to the Separation date. Refer to "Note 3. Related Party Transactions" and "Note 11. Restructuring and Related Charges" in the Notes to Consolidated Financial Statements.

[0001628280-16-019400:notes:103]
Loss Contingencies

[0001628280-16-019400:notes:104]
We are subject to the possibility of various loss contingencies arising in the ordinary course of business. We consider the likelihood of loss or impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss in determining loss contingencies. An estimated loss is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate current information available to determine whether such accruals should be adjusted and whether new accruals are required.

[0001628280-16-019400:notes:105]
Asset Retirement Obligations ("ARO")

[0001628280-16-019400:notes:106]
Our ARO are legal obligations associated with the retirement of long-lived assets pertaining to leasehold improvements. These liabilities are initially recorded at fair value and the related asset retirement costs are capitalized by increasing the carrying amount of the related assets by the same amount as the liability. Asset retirement costs are subsequently depreciated over the useful lives of the related assets. Subsequent to initial recognition, we record period-to-period changes in the ARO liability resulting from the passage of time and revisions to either the timing or the amount of the original estimate of undiscounted cash flows. We derecognize ARO liabilities when the related obligations are settled. As of July 2, 2016, the consolidated balance sheets included ARO of zero in other current liabilities and $2.3 million in other non-current liabilities. As of June 27, 2015, the consolidated balance sheet included ARO of $0.3 million in other current liabilities and $1.8 million in other non-current liabilities.


## us-gaap:ChangesInProjectedBenefitObligationsFairValueOfPlanAssetsAndFundedStatusOfPlanTableTextBlock

[0001628280-16-019400:notes:107]
The change in the benefit obligations and plan assets of the pension and benefits plan were as follows (in millions):

[0001628280-16-019400:notes:108]
|  | Pension Benefit Plans |
|  | 2016 |  | 2015 |
| Change in benefit obligation: |  |  |  |
| Benefit obligation at beginning of year | $ | 6.7 |  |  | $ | 4.6 |  |
| Service cost | 0.4 |  |  | 0.3 |  |
| Interest cost | 0.1 |  |  | 0.1 |  |
| Plan participants' contribution | 0.4 |  |  | 0.3 |  |
| Actuarial (gains)/losses | 0.9 |  |  | 1.2 |  |
| Benefits paid | 0.1 |  |  | 0.4 |  |
| Foreign exchange impact | (0.4 | ) |  | (0.2 | ) |
| Benefit obligation at end of year | $ | 8.2 |  |  | $ | 6.7 |  |
| Change in plan assets: |  |  |  |
| Fair value of plan assets at beginning of year | $ | 4.6 |  |  | $ | 3.0 |  |
| Actual return on plan assets | (0.6 | ) |  | 0.2 |  |
| Employer contribution | 0.4 |  |  | 0.8 |  |
| Plan participants' contribution | 0.4 |  |  | 0.3 |  |
| Benefits paid | 0.1 |  |  | 0.4 |  |
| Foreign exchange impact | (0.2 | ) |  | (0.1 | ) |
| Fair value of plan assets at end of year | $ | 4.7 |  |  | $ | 4.6 |  |
| Funded status | $ | (3.5 | ) |  | $ | (2.1 | ) |
| Accumulated benefit obligation | $ | 6.7 |  |  | $ | 5.6 |  |


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001628280-16-019400:notes:109]
Note 15. Commitments and Contingencies

[0001628280-16-019400:notes:110]
Operating Leases

[0001628280-16-019400:notes:111]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2026. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. As of July 2, 2016 the future minimum annual lease payments under non-cancellable operating leases were as follows (in millions):

[0001628280-16-019400:notes:112]
| 2017 | $ | 6.7 |  |
| 2018 | 5.6 |  |
| 2019 | 3.9 |  |
| 2020 | 2.8 |  |
| 2021 | 1.7 |  |
| Thereafter | 3.9 |  |
| Total minimum operating lease payments | $ | 24.6 |  |

[0001628280-16-019400:notes:113]
Included in the future minimum lease payments table above is $0.5 million related to lease commitments in connection with our restructuring and related activities. Refer to "Note 11. Restructuring and Related Charges" in the Notes to Consolidated Financial Statements.

[0001628280-16-019400:notes:114]
Rental expense relating to building and equipment was $7.4 million, $9.1 million and $10.0 million in fiscal 2016, 2015 and 2014, respectively.

[0001628280-16-019400:notes:115]
Purchase Obligations

[0001628280-16-019400:notes:116]
Purchase obligations of $117.5 million as of July 2, 2016, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001628280-16-019400:notes:117]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with such vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

[0001628280-16-019400:notes:118]
Product Warranties

[0001628280-16-019400:notes:119]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, product component or application of our products by the end customer, our warranties can vary and generally range from six up to sixty months or 5 years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001628280-16-019400:notes:120]
The following table presents the changes in our warranty reserve during fiscal 2016 and fiscal 2015 (in millions):

[0001628280-16-019400:notes:121]
|  | Years Ended |
|  | July 2, 2016 |  | June 27, 2015 |
| Balance as of beginning of year | $ | 2.8 |  |  | $ | 2.7 |  |
| Provision for warranty | 2.9 |  |  | 3.5 |  |
| Utilization of reserve | (2.9 | ) |  | (3.4 | ) |
| Balance as of year end | $ | 2.8 |  |  | $ | 2.8 |  |

[0001628280-16-019400:notes:122]
Environmental Liabilities

[0001628280-16-019400:notes:123]
Our R&D, manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental, product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001628280-16-019400:notes:124]
In connection with the Separation, we agreed to indemnify Viavi for any liability associated with contamination from past operations at all properties transferred to us from Viavi, to the extent the resulting issues primarily related to our business.

[0001628280-16-019400:notes:125]
Legal Proceedings

[0001628280-16-019400:notes:126]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management's view of these matters may change in the future. Were an unfavorable final outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the effect becomes reasonably estimable.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-16-019400:notes:127]
Note 5. Accumulated Other Comprehensive Income (Loss)

[0001628280-16-019400:notes:128]
Our accumulated other comprehensive income (loss) consists of the accumulated net unrealized gains or losses on foreign currency translation adjustments and defined benefit obligation.

[0001628280-16-019400:notes:129]
At July 2, 2016 and June 27, 2015, balances for the components of accumulated other comprehensive income were as follows (in millions):

[0001628280-16-019400:notes:130]
|  | Foreign currency translation adjustments |  | Defined benefit obligation, net of tax (1) |  | Total |
| Beginning balance as of June 27, 2015 | $ | 13.7 |  |  | $ | (1.2 | ) |  | $ | 12.5 |  |
| Other comprehensive loss | (2.0 | ) |  | (1.1 | ) |  | (3.1 | ) |
| Ending balance as of July 2, 2016 | $ | 11.7 |  |  | $ | (2.3 | ) |  | $ | 9.4 |  |

[0001628280-16-019400:notes:131]
(1) Refer to "Note 14. Employee Benefit Plans" in the Notes to Consolidated Financial Statements on the computation of net periodic cost for pension plans.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001628280-16-019400:notes:132]
Note 9. Derivative Liability

[0001628280-16-019400:notes:133]
We estimate the fair value of the embedded derivative for the Series A Preferred Stock using the binomial lattice model. We applied the binomial lattice model to value the embedded derivative using a "with-and-without method," where the value of the Series A Preferred Stock including the embedded derivative, is defined as the "with", and the value of the Series A Preferred Stock excluding the embedded derivative, is defined as the "without". This method estimates the value of the embedded derivative by looking at the difference in the values between the Series A Preferred Stock with the embedded derivative and the value of the Series A Preferred Stock without the embedded derivative. The lattice model requires the following inputs: (i) the Company's common stock price; (ii) conversion price; (iii) term; (iv) yield; (v) recovery rate; (vi) estimated stock volatility; and (vii) risk-free rate. The fair value of the embedded derivative was determined using level 3 inputs under the fair value hierarchy (unobservable inputs). Changes in the inputs into this valuation model have a material impact in the estimated fair value of the embedded derivative. For example, a decrease (increase) in the stock price results in a decrease (increase) in the estimated fair value of the embedded derivative. The changes in the fair value of the bifurcated embedded derivative of $0.6 million for the fiscal year ended July 2, 2016 is primarily related to the change in the price of the Company's underlying common stock and is reflected in the consolidated statements of operations as "Unrealized loss on derivative liability".

[0001628280-16-019400:notes:134]
The following table provides a reconciliation of the fair value of the embedded derivative for the Series A Preferred Stock measured by significant unobservable inputs (Level 3) for the year ended July 2, 2016:

[0001628280-16-019400:notes:135]
|  |  | Balance as of (in millions) |
|  |  | July 2, 2016 |
| Balance as of beginning of period |  | $ | — |  |
| Fair value of the embedded derivative for the Series A Preferred Stock at issuance |  | 9.7 |  |
| Unrealized loss included in net income |  | 0.6 |  |
| Balance as of end of period |  | 10.3 |  |

[0001628280-16-019400:notes:136]
|  |  | July 2, 2016 |
| Stock price |  | $ | 23.65 |  |
| Conversion price |  | $ | 24.63 |  |
| Expected term (years) |  | 4.11 |  |
| Expected annual volatility |  | 40.00 | % |
| Risk-free rate |  | 0.96 | % |
| Expected common dividend yield |  | — | % |
| Preferred yield |  | 8.84 | % |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-16-019400:notes:137]
Note 13. Stock-Based Compensation and Stock Plans

[0001628280-16-019400:notes:138]
Description of Lumentum Stock-Based Benefit Plans

[0001628280-16-019400:notes:139]
Stock Option Plans

[0001628280-16-019400:notes:140]
On June 23, 2015, we adopted, and the board of directors of JDS Uniphase Corporation (“JDSU” and, now, Viavi Solutions Inc.) approved, the 2015 Equity Incentive Plan (the "2015 Plan") under which 8.5 million shares of our Common Stock were authorized for issuance, which was ratified by the Company’s board of directors in August 2015.  In connection with our Separation from JDSU on July 31, 2015, outstanding JDSU equity-based awards held by service providers continuing in service after the Separation were converted into equity-based awards under the 2015 Plan reducing the number of shares remaining available for grant under the 2015 Plan.  As of immediately following our Separation from JDSU, 2.1 million shares of our Common Stock were reserved pursuant to outstanding equity-based awards under the 2015 Plan that were converted from JDSU equity-based awards.

[0001628280-16-019400:notes:141]
As of July 2, 2016, the Company had 2.9 million shares of stock options, performance stock units and restricted stock units issued and outstanding to employees and directors under the 2015 Plan. Performance stock units and restricted stock units are performance-based, time-based or a combination of both and are expected to vest over one to four years. The fair value of the time-based performance stock units or restricted stock units is based on the closing market price of the Company’s common stock on the date of award.

[0001628280-16-019400:notes:142]
The exercise price for stock options is equal to the fair value of the underlying stock at the date of grant. The Company issues new shares of common stock upon exercise of stock options. Options generally become exercisable over a three-year or four-year period and, if not exercised, expire from five to ten years after the date of grant. As of July 2, 2016, 5.0 million shares of common stock under the 2015 Plan were available for grant.

[0001628280-16-019400:notes:143]
Employee Stock Purchase Plan

[0001628280-16-019400:notes:144]
On June 23, 2015, we adopted, and the board of directors of JDSU approved, the 2015 Employee Stock Purchase Plan (the “2015 Purchase Plan”) under which 3.0 million shares of our Common Stock were authorized for issuance, which was ratified by our board of directors in August 2015.  The 2015 Purchase Plan provides eligible employees with the opportunity to acquire an ownership interest in the Company through periodic payroll deductions and provides a discounted purchase price as well as a look-back period. The 2015 Purchase Plan is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986. However, the 2015 Purchase Plan is not intended to be a qualified pension, profit sharing or stock bonus plan under Section 401(a) of the Internal Revenue Code of 1986 and is not subject to the provisions of the Employee Retirement Income Security Act of 1974. The 2015 Purchase Plan will terminate upon the date on which all shares available for issuance have been sold. Of the 3.0 million shares authorized under the 2015 Purchase Plan, 2.8 million shares remained available for issuance as of July 2, 2016. The 2015 Purchase Plan provides a 15% discount and a six month look-back period.

[0001628280-16-019400:notes:145]
Restricted Stock Units

[0001628280-16-019400:notes:146]
RSUs are granted with the exercise price equal to zero and converted to shares immediately upon vesting. These RSUs have service conditions, performance conditions, or a combination of both and are expected to vest over one to four years. The fair value of the time-based RSUs was based on the closing market price of the common stock on the date of award.

[0001628280-16-019400:notes:147]
The impact on our results of operations of recording stock-based compensation by function for fiscal 2016, 2015 and 2014 was as follows (in millions):

[0001628280-16-019400:notes:148]
|  | Years Ended |
|  | July 2, 2016 |  | June 27, 2015 |  | June 28, 2014 |
| Cost of sales | $ | 6.1 |  |  | $ | 5.1 |  |  | $ | 5.6 |  |
| Research and development | 9.0 |  |  | 7.3 |  |  | 7.3 |  |
| Selling, general and administrative | 11.8 |  |  | 14.7 |  |  | 12.9 |  |
|  | 26.9 |  |  | 27.1 |  |  | 25.8 |  |

[0001628280-16-019400:notes:149]
Approximately $1.2 million of stock-based compensation was capitalized to inventory as of July 2, 2016. The table above includes allocated stock-based compensation from Viavi of $2.0 million, $8.9 million, and $7.3 million for fiscal 2016, 2015 and 2014, respectively. Refer to "Note 3. Related Party Transactions" in the Notes to Consolidated Financial Statements.

[0001628280-16-019400:notes:150]
Stock Option and Restricted Stock Units Activity

[0001628280-16-019400:notes:151]
We granted no stock options during fiscal 2016 and 2015. As of July 2, 2016, the total intrinsic value of options exercised by our employees during the year ended July 2, 2016 was $1.0 million. In connection with these exercises, the tax benefit realized by us was immaterial due to the fact that Lumentum has no material tax benefit in foreign jurisdictions and a full valuation allowance on its domestic deferred tax assets.

[0001628280-16-019400:notes:152]
As of July 2, 2016, we have $36.9 million of stock-based compensation cost related to RSUs granted to our employees remain to be amortized. That cost is expected to be recognized over an estimated amortization period of 2.0 years.

[0001628280-16-019400:notes:153]
The following table summarizes our stock options activities in fiscal 2016 (amount in millions except per share amounts):

[0001628280-16-019400:notes:154]
|  | Options Outstanding |  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Exercise Price |  | Number of Shares (MSU/PSU) |  | Number of Shares(RSU) |  | Weighted-Average Grant Date Fair Value |
| Outstanding as of June 28, 2014 | 1.2 |  |  | $ | 9.97 |  |  | 0.3 |  |  | 2.7 |  |  | $ | 13.17 |  |
| Granted | — |  |  |  |  | 0.2 |  |  | 1.6 |  |  | 11.77 |  |
| Exercised / Vested | (0.4 | ) |  | 8.56 |  |  | (0.1 | ) |  | (1.4 | ) |  | 12.99 |  |
| Canceled | — |  |  |  |  | (0.1 | ) |  | (0.4 | ) |  | 14.28 |  |
| Outstanding as of June 27, 2015 | 0.8 |  |  | 10.37 |  |  | 0.3 |  |  | 2.5 |  |  | 12.42 |  |
| Outstanding as of June 27, 2015, as converted | 0.5 |  |  | 19.01 |  |  | 0.2 |  |  | 1.5 |  |  | 22.70 |  |
| Granted | — |  |  |  |  | — |  |  | 1.9 |  |  | 20.39 |  |
| Exercised / Vested | (0.2 | ) |  | 15.21 |  |  | (0.1 | ) |  | (0.7 | ) |  | 22.60 |  |
| Canceled | — |  |  |  |  | — |  |  | (0.2 | ) |  | 21.85 |  |
| Outstanding as of July 2, 2016 | 0.3 |  |  | $ | 17.83 |  |  | 0.1 |  |  | 2.5 |  |  | 21.04 |  |
| Vested and expected to vest | 0.3 |  |  | $ | 17.83 |  |  | 0.1 |  |  | 2.2 |  |  | 21.02 |  |

[0001628280-16-019400:notes:155]
The following table summarizes significant ranges of our outstanding and exercisable options as of July 2, 2016:

[0001628280-16-019400:notes:156]
|  |  | Options Outstanding |  | Options Exercisable |
| Range ofExercise Prices |  | Numberof Shares |  | Weighted Average Remaining Contractual Life(in years) |  | Weighted Average Exercise Price |  | Aggregate Intrinsic Value (in millions) |  | Numberof Shares |  | Weighted Average Remaining Contractual Life(in years) |  | Weighted Average Exercise Price |  | Aggregate Intrinsic Value (in millions) |
| $6.53 - 6.53 |  | 27,004 |  |  | 0.6 |  | $ | 6.53 |  |  | $ | 0.5 |  |  | 27,004 |  |  | 0.6 |  | $ | 6.53 |  |  | $ | 0.5 |  |
| 10.76 - 10.76 |  | 96,971 |  |  | 1.1 |  | 10.76 |  |  | 1.2 |  |  | 96,971 |  |  | 1.1 |  | 10.76 |  |  | 1.2 |  |
| 18.82 - 45.89 |  | 160,562 |  |  | 2.2 |  | 24.00 |  |  | 0.6 |  |  | 160,562 |  |  | 2.2 |  | 24.00 |  |  | 0.6 |  |
|  |  | 284,537 |  |  | 1.7 |  | 17.83 |  |  | $ | 2.3 |  |  | 284,537 |  |  | 1.7 |  | 17.83 |  |  | $ | 2.3 |  |

[0001628280-16-019400:notes:157]
The aggregate intrinsic value in the table above represents the total pre-tax intrinsic value, based on Lumentum's closing stock price of $23.65 as of July 2, 2016, which would have been received by the option holders had all option holders exercised their options as of that date. The total number of in-the-money options exercisable as of July 2, 2016 was $0.3 million.

[0001628280-16-019400:notes:158]
Employee Stock Purchase Plan Activity

[0001628280-16-019400:notes:159]
The ESPP expense we recorded for the year ended July 2, 2016 was $1.3 million. The expense related to the plan is recorded on a straight-line basis over the relevant subscription period. During fiscal 2016, 202,479 shares were issued to our employees with the fair market value at the purchase date of $15.46 through the ESPP program.


## us-gaap:EarningsPerShareTextBlock

[0001628280-16-019400:notes:160]
Note 4. Earnings Per Share

[0001628280-16-019400:notes:161]
The following table sets forth the computation of basic and diluted net income (loss) per share (in millions, except per share data):

[0001628280-16-019400:notes:162]
|  | Years Ended |
|  | July 2, 2016 |  | June 27, 2015 |  | June 28, 2014 |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income (loss) | $ | 9.3 |  |  | $ | (3.4 | ) |  | $ | 10.7 |  |
| Less: Cumulative dividends on Series A Preferred Stock | (0.8 | ) |  | — |  |  | — |  |
| Less: Accretion of Series A Preferred Stock | (11.7 | ) |  | — |  |  | — |  |
| Net income (loss) attributable to common stockholders | (3.2 | ) |  | (3.4 | ) |  | 10.7 |  |
| Denominator: |  |  |  |  |  |
| Weighted-average number of common shares outstanding |  |  |  |  |  |
| Basic | 59.1 |  |  | 58.8 |  |  | 58.8 |  |
| Effect of dilutive securities from stock-based benefit plans | — |  |  | — |  |  | — |  |
| Diluted | 59.1 |  |  | 58.8 |  |  | 58.8 |  |
| Net income (loss) per share attributable to common stockholders: |  |  |  |  |  |
| Basic | $ | (0.05 | ) |  | $ | (0.06 | ) |  | $ | 0.18 |  |
| Diluted | $ | (0.05 | ) |  | $ | (0.06 | ) |  | $ | 0.18 |  |

[0001628280-16-019400:notes:163]
On August 1, 2015, JDSU distributed 47.1 million shares, or 80.1% of the outstanding shares of  the Company's common stock to existing holders of JDSU common stock. The weighted average number of common stock outstanding is calculated as the number of shares of common stock outstanding immediately following the Separation, and the weighted average number of shares outstanding following the Separation through July 2, 2016. Diluted earnings per share is calculated by dividing net income for the period by the weighted average number of shares of common stock and potentially dilutive common stock outstanding for the period beginning after the Separation. Basic and diluted net income per share for the twelve months ended June 27, 2015 and June 28, 2014 is calculated using the shares of the Company's common stock outstanding on August 1, 2015, as if such shares were outstanding for the entire period.

[0001628280-16-019400:notes:164]
The dilutive effect of stock-based awards is reflected in diluted earnings per share by application of the treasury stock method, which includes consideration of unamortized share-based compensation expense, the tax benefits or shortfalls recorded to additional paid-in capital and the dilutive effect of in-the-money options and non-vested restricted stock units. Under the treasury stock method, the amount the employee must pay for exercising stock options and unamortized share-based compensation expense and tax benefits or shortfalls collectively are assumed proceeds to be used to repurchase hypothetical shares. An increase in the fair value of the Company's common stock can result in a greater dilutive effect from potentially dilutive awards.

[0001628280-16-019400:notes:165]
The dilutive effect of the redeemable convertible preferred stock is reflected in diluted earnings per share by the application of the if-converted method. The number of shares is increased for the assumed conversion of the instrument. Additionally, cumulative dividends and accretion from measuring the instrument at its redemption value are added back to net income (loss).

[0001628280-16-019400:notes:166]
For the year ended July 2, 2016, 1.2 million weighted average shares were excluded from the calculation of diluted shares because their inclusion would have been antidilutive.


## us-gaap:FiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0001628280-16-019400:notes:167]
The following table presents details of our amortization (in millions):

[0001628280-16-019400:notes:168]
|  | Years Ended |
|  | July 2, 2016 |  | June 27, 2015 |  | June 28, 2014 |
| Cost of sales | $ | 6.8 |  |  | $ | 7.6 |  |  | $ | 9.0 |  |
| Operating expense | 0.4 |  |  | 0.4 |  |  | 0.3 |  |
| Total | $ | 7.2 |  |  | $ | 8.0 |  |  | $ | 9.3 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001628280-16-019400:notes:169]
Note 10. Goodwill and Other Intangible Assets

[0001628280-16-019400:notes:170]
The following table presents the changes in goodwill by operating segments during the year ended July 2, 2016 (in millions):

[0001628280-16-019400:notes:171]
|  |  | Optical Communications |  | Commercial Lasers |  | Total |
| Balance as of June 28, 2014 (1) | $ | — |  |  | $ | 5.9 |  |  | $ | 5.9 |  |
|  | Currency translation | — |  |  | (0.3 | ) |  | (0.3 | ) |
| Balance as of June 27, 2015 | $ | — |  |  | $ | 5.6 |  |  | $ | 5.6 |  |
|  | Currency translation | $ | — |  |  | $ | (0.2 | ) |  | $ | (0.2 | ) |
| Balance as of July 2, 2016 | $ | — |  |  | $ | 5.4 |  |  | $ | 5.4 |  |

[0001628280-16-019400:notes:172]
(1)  Refer to “Note 6. Mergers and Acquisitions” for more information.

[0001628280-16-019400:notes:173]
Impairment of Goodwill

[0001628280-16-019400:notes:174]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. In the fourth quarter of fiscal 2016, we completed the annual impairment test of goodwill, which indicated there was no goodwill impairment. During the fiscal year ended July 2, 2016, there have been no events or circumstances that have required us to perform an interim assessment of goodwill for impairment.

[0001628280-16-019400:notes:175]
Acquired Developed Technology and Other Intangibles

[0001628280-16-019400:notes:176]
The following tables present details of our acquired developed technology and other intangibles (in millions):

[0001628280-16-019400:notes:177]
| As of July 2, 2016 | Gross Carrying Amount |  | Accumulated Amortization |  | Net |
| Acquired developed technology | $ | 103.0 |  |  | $ | (88.9 | ) |  | $ | 14.1 |  |
| Other | 9.4 |  |  | (9.0 | ) |  | 0.4 |  |
| Total Intangibles | $ | 112.4 |  |  | $ | (97.9 | ) |  | $ | 14.5 |  |

[0001628280-16-019400:notes:178]
| As of June 27, 2015 | Gross Carrying Amount |  | Accumulated Amortization |  | Net |
| Acquired developed technology | $ | 103.2 |  |  | $ | (82.2 | ) |  | $ | 21.0 |  |
| Other | 9.4 |  |  | (8.6 | ) |  | 0.8 |  |
| Total Intangibles | $ | 112.6 |  |  | $ | (90.8 | ) |  | $ | 21.8 |  |

[0001628280-16-019400:notes:179]
During fiscal 2016, 2015 and 2014, we recorded $7.2 million, $8.0 million, and $9.3 million, respectively, of amortization related to acquired developed technology and other intangibles. The following table presents details of our amortization (in millions):

[0001628280-16-019400:notes:180]
Based on the carrying amount of acquired developed technology and other intangibles as of July 2, 2016, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001628280-16-019400:notes:181]
| Fiscal Years |  |
| 2017 | $ | 6.7 |  |
| 2018 | 2.8 |  |
| 2019 | 2.6 |  |
| 2020 | 2.4 |  |
| Thereafter | — |  |
| Total amortization | $ | 14.5 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-16-019400:notes:182]
Note 12. Income Taxes

[0001628280-16-019400:notes:183]
Our income before income taxes consisted of the following (in millions):

[0001628280-16-019400:notes:184]
|  | Years Ended |
|  | July 2, 2016 |  | June 27, 2015 |  | June 28, 2014 |
| Domestic | $ | 60.7 |  |  | $ | (58.7 | ) |  | $ | (0.3 | ) |
| Foreign | (51.0 | ) |  | 34.2 |  |  | 10.1 |  |
| Income before income taxes | $ | 9.7 |  |  | $ | (24.5 | ) |  | $ | 9.8 |  |

[0001628280-16-019400:notes:185]
Our income tax (benefit) expense consisted of the following (in millions):

[0001628280-16-019400:notes:186]
|  | Years Ended |
|  | July 2, 2016 |  | June 27, 2015 |  | June 28, 2014 |
| Federal: |  |  |  |  |  |
| Current | $ | 1.6 |  |  | $ | — |  |  | $ | (0.2 | ) |
| Deferred | — |  |  | — |  |  | — |  |
|  | 1.6 |  |  | — |  |  | (0.2 | ) |
| State: |  |  |  |  |  |
| Current | 0.2 |  |  | 0.1 |  |  | — |  |
| Deferred | — |  |  | — |  |  | — |  |
|  | 0.2 |  |  | 0.1 |  |  | — |  |
| Foreign: |  |  |  |  |  |
| Current | 1.2 |  |  | (20.3 | ) |  | 2.3 |  |
| Deferred | (2.6 | ) |  | (0.9 | ) |  | (3.0 | ) |
|  | (1.4 | ) |  | (21.2 | ) |  | (0.7 | ) |
| Total income tax (benefit) expense | $ | 0.4 |  |  | $ | (21.1 | ) |  | $ | (0.9 | ) |

[0001628280-16-019400:notes:187]
The Company's effective tax rate differs from the U.S. Federal statutory income tax rate as follows (in millions):

[0001628280-16-019400:notes:188]
|  | Years Ended |
|  | July 2, 2016 |  | June 27, 2015 |  | June 28, 2014 |
| Income tax (benefit) expense computed at federal statutory rate | $ | 3.4 |  |  | $ | (8.6 | ) |  | $ | 3.4 |  |
| State taxes, net of federal benefit | 0.1 |  |  | — |  |  | — |  |
| Foreign rate differential | 21.3 |  |  | 0.2 |  |  | — |  |
| Change in Valuation allowance | (29.4 | ) |  | (2.2 | ) |  | (2.4 | ) |
| Reversal of previously accrued taxes | — |  |  | (21.8 | ) |  | (0.3 | ) |
| Research and experimentation benefits and other tax credits | (4.4 | ) |  | (3.1 | ) |  | (4.4 | ) |
| Permanent items | 0.7 |  |  | (0.7 | ) |  | 1.9 |  |
| Stock-Based Compensation | 4.3 |  |  | 1.2 |  |  | — |  |
| SubpartF | 4.0 |  |  | 12.7 |  |  | — |  |
| Unrecognized tax benefits | — |  |  | 1.0 |  |  | 0.9 |  |
| Other | 0.4 |  |  | 0.2 |  |  | — |  |
| Total income tax (benefit) expense | $ | 0.4 |  |  | $ | (21.1 | ) |  | $ | (0.9 | ) |

[0001628280-16-019400:notes:189]
The components of our net deferred taxes consisted of the following (in millions):

[0001628280-16-019400:notes:190]
|  | Years Ended |
|  | July 2, 2016 |  | June 27, 2015 |  | June 28, 2014 |
| Gross deferred tax assets: |  |  |  |  |  |
| Intangibles | $ | 230.2 |  |  | $ | — |  |  | $ | — |  |
| Tax credit carryforwards | 43.8 |  |  | 41.6 |  |  | 33.8 |  |
| Net operating loss carryforwards | 16.1 |  |  | 61.0 |  |  | 91.4 |  |
| Inventories | 10.9 |  |  | 7.7 |  |  | 6.7 |  |
| Accruals and reserves | 9.9 |  |  | 4.1 |  |  | 4.2 |  |
| Fixed assets | 11.1 |  |  | 21.7 |  |  | 24.2 |  |
| Capital loss carryforwards | 11.9 |  |  | 12.4 |  |  | 14.3 |  |
| Unclaimed research and experimental development expenditure | 19.5 |  |  | 16.7 |  |  | 15.5 |  |
| Other | 0.6 |  |  | 5.4 |  |  | 7.0 |  |
| Acquisition-related items | — |  |  | 29.4 |  |  | 32.6 |  |
| Gross deferred tax assets | 354.0 |  |  | 200.0 |  |  | 229.7 |  |
| Valuation allowance | (321.4 | ) |  | (160.0 | ) |  | (184.6 | ) |
| Deferred tax assets | 32.6 |  |  | 40.0 |  |  | 45.1 |  |
| Gross deferred tax liabilities: |  |  |  |  |  |
| Acquisition-related items | (1.0 | ) |  | (6.7 | ) |  | (9.4 | ) |
| Undistributed foreign earnings | — |  |  | (2.6 | ) |  | (2.4 | ) |
| Other | — |  |  | (1.2 | ) |  | (0.9 | ) |
| Deferred tax liabilities | (1.0 | ) |  | (10.5 | ) |  | (12.7 | ) |
| Total net deferred tax assets | $ | 31.6 |  |  | $ | 29.5 |  |  | $ | 32.4 |  |

[0001628280-16-019400:notes:191]
Realization of deferred tax assets is dependent on the generation of sufficient future taxable income.  Due to the history of losses the Company has generated in the past in certain jurisdictions, the Company believes that it is more likely than not that federal, California and certain international deferred tax assets will not be realized as of July 2, 2016. Accordingly, the Company has recorded a valuation allowance on such deferred tax assets.

[0001628280-16-019400:notes:192]
The valuation allowance increased by $161.4 million in fiscal 2016, and decreased by $24.6 million in fiscal 2015. The increase in the valuation allowance during fiscal 2016 was primarily related to the increased tax basis for $704.4 million US federal intangible assets resulting from a taxable separation transaction from Viavi, and partially offset by the usage of net operating loss.  The decrease during fiscal 2015 was primarily related to the decrease in the deferred tax assets as a result of the use and expiration of foreign net operating losses.

[0001628280-16-019400:notes:193]
The Company regularly assesses the realizability of its deferred tax assets and establishes a valuation allowance if it is more-likely-than-not that some portion of the deferred tax assets will not be realized. The Company weighs all available positive and negative evidence, including earnings history and results of recent operations, scheduled reversals of deferred tax liabilities, projected future taxable income, and tax planning strategies. In the event the Company determines that it would not be able to realize all or part of its net deferred tax assets in the future, a valuation allowance will be established against deferred tax assets in the period in which the Company makes such determination. The need to establish a valuation allowance against deferred tax assets may cause greater volatility in the effective tax rate. To the extent the Company is in the process of evaluating its international operational footprint, it is reasonably possible that any such adjustment would materially change in the next 12 months.

[0001628280-16-019400:notes:194]
As of July 2, 2016, the Company had federal, state, and foreign tax net operating loss carryforwards of $8.2 million, $3.3 million, and $48.5 million, respectively. These carryforwards begin to expire in the fiscal years ending 2022, 2036 and 2025, respectively.

[0001628280-16-019400:notes:195]
The U.S. net operating loss carryforwards are subject to Internal Revenue Code Section 382 which imposes limitations on annual utilization after a change of ownership.

[0001628280-16-019400:notes:196]
Additionally, the Company has federal, state, and foreign research and other tax credit carryforwards of $2.7 million, $2 million, and $42.2 million, respectively.  A portion of the federal credits will begin to expire in the fiscal year ending 2036 and California credits can be carried forward indefinitely.  The foreign tax credits will begin to expire in the fiscal year ending 2020.

[0001628280-16-019400:notes:197]
U.S. income and foreign withholding taxes associated with the repatriation of earnings of foreign subsidiaries have not been provided on $0.6 million of undistributed earnings for certain foreign subsidiaries. We intend to reinvest these earnings indefinitely outside of the United States. We estimate that an additional $0.1 million of U.S. income or foreign withholding taxes would have to be provided if these earnings were repatriated back to the United States.

[0001628280-16-019400:notes:198]
In addition, the Company is in the process of evaluating its international operational footprint, which could result in future changes to the Company’s legal entity structure and operating model.  A wholly-owned foreign subsidiary of the Company acquired certain rights to sell the existing products and also those products to be developed or licensed in the future and will also share in the research and development cost.  The existing rights were transferred to its wholly-owned foreign subsidiary prior to the Separation.  As a result of these changes, the Company expects that an increasing percentage of its consolidated pre-tax income will be derived from, and reinvested in, its foreign operations.  The Company anticipates that this pre-tax income will be subject to foreign tax at relatively lower tax rates when compared to the U. S. federal statutory tax rate and as a consequence, the Company’s effective income tax rate is expected to be lower than the U. S. federal statutory rate.

[0001628280-16-019400:notes:199]
A reconciliation of unrecognized tax benefits between June 28, 2014 and July 2, 2016 is as follows (in millions):

[0001628280-16-019400:notes:200]
| Balance at June 28, 2014 | 21.9 |  |
| Reductions based on the tax positions related to the prior year | (21.8 | ) |
| Additions based on tax positions related to current year | 0.1 |  |
| Balance at June 27, 2015 | $ | 0.2 |  |
| Reductions based on the tax positions related to the prior year | $ | (0.1 | ) |
| Additions based on tax positions related to current year | $ | 2.1 |  |
| Balance at July 2, 2016 | $ | 2.2 |  |

[0001628280-16-019400:notes:201]
Included in the balance of unrecognized tax benefits at July 2, 2016 are $2.1 million of tax benefits that, if recognized, would result in adjustments to the valuation allowance.  Also included in the balance of unrecognized tax benefits at July 2, 2016 are $0.1 million of tax benefits that, if recognized, would impact the effective tax rate.

[0001628280-16-019400:notes:202]
Our policy is to recognize accrued interest and penalties related to unrecognized tax benefits within the income tax provision. The amount of interest and penalties accrued as of July 2, 2016 and June 27, 2015 was less than $0.1 million.

[0001628280-16-019400:notes:203]
The Company files income tax returns in the US federal jurisdiction as well as many US states and foreign jurisdictions.

[0001628280-16-019400:notes:204]
The Company’s major tax jurisdictions are the U.S. federal government, the state of California, and Canada. The U.S. federal corporation income tax returns beginning with the 2000 tax year remain subject to examination by the Internal Revenue Service, or IRS. The California corporation income tax returns beginning with the current fiscal will year remain subject to examination by the California Franchise Tax Board. The Canada corporation income tax returns beginning with the 2009 year remain subject to examination by the Canadian tax authorities.

[0001628280-16-019400:notes:205]
Fiscal years outside the normal statute of limitation remain open to audit by tax authorities due to tax attributes generated in those early years which have been carried forward and may be audited in subsequent years when utilized.

[0001628280-16-019400:notes:206]
The Company is subject to the continuous examination of income tax returns by various foreign tax authorities. The timing of resolutions and closures of tax audits is highly unpredictable. Given the uncertainty, it is reasonably possible that certain tax audits may be concluded within the next 12 months that could materially impact the balance of our gross unrecognized tax benefits. An estimate of the range of increase or decrease that could occur in the next twelve months cannot be made. However, the estimated impact to tax expense and net income from the resolution and closure of tax exams is not expected to be significant within the next 12 months.

[0001628280-16-019400:notes:207]
In November 2015, the FASB issued ASU 2015-17, “Balance Sheet Classification of Deferred Taxes”, which simplifies the presentation of deferred income taxes. This ASU requires that deferred tax assets and liabilities be classified as non-current in a statement of financial position. We early adopted ASU 2015-17 effective December 26, 2015 on a prospective basis. Adoption of this ASU resulted in the reclassification of our net current deferred tax asset of $0.1 million to the net non-current deferred tax asset, and current deferred tax liability of $0.5 million to the non-current deferred tax liability on our Consolidated Balance Sheet as of December 26, 2015.


## us-gaap:MinorityInterestDisclosureTextBlock

[0001628280-16-019400:notes:208]
Note 8. Non-Controlling Interest Redeemable Convertible Preferred Stock

[0001628280-16-019400:notes:209]
On July 31, 2015, our wholly-owned subsidiary, Lumentum Inc., issued 40,000 shares of its Series A Preferred Stock to Viavi. Pursuant to a securities purchase agreement between the Company, Viavi and Amada, 35,805 shares of Series A Preferred Stock were sold by Viavi to Amada in August 2015. The remaining 4,195 shares of the Series A Preferred Stock were canceled. The Series A Preferred Stock is referred to as our Non-Controlling Interest Redeemable Convertible Preferred Stock within these consolidated financial statements.

[0001628280-16-019400:notes:210]
The Series A Preferred Stock is redeemable at the option of Amada after five years and classified as mezzanine equity in our consolidated balance sheet.  The Series A Preferred Stock is measured at its redemption value.  We recognized a $9.7 million increase in the value of the Series A Preferred Stock during the fiscal year ended July 2, 2016 to accrete to the redemption value of $35.8 million with a reduction to additional paid-in capital. The Series A Preferred Stock conversion feature is bifurcated from the Series A Preferred Stock and accounted for separately as a derivative liability.  The derivative liability is measured at fair value each reporting period with the change in fair value recorded in the consolidated statements of operations.

[0001628280-16-019400:notes:211]
The following paragraphs describe the terms and conditions of the Series A Preferred Stock:

[0001628280-16-019400:notes:212]
Conversion

[0001628280-16-019400:notes:213]
The Series A Preferred Stock is convertible, at the option of the holder, into shares of our common stock commencing on the second anniversary of the closing of the securities purchase (absent a change of control of us or similar event) using a conversion price of $24.63, which is equal to 125% of the volume weighted average price per share of our common stock in the five “regular-way” trading days following the Separation.

[0001628280-16-019400:notes:214]
Liquidation

[0001628280-16-019400:notes:215]
Upon any liquidation, dissolution, or winding up of our business, whether voluntary or involuntary, holders of Series A Preferred Stock will be entitled to receive, in preference to holders of common stock or any other class or series of our outstanding capital stock ranking in any such event junior to the Series A Preferred Stock, an amount per share equal to the greater of (i) the Issuance Value of $1,000 per share for Series A Preferred Stock plus all accrued and unpaid dividends thereon (whether or not authorized or declared) through the date of payment and (ii) the amount as would have been payable had all Series A Preferred Stock been converted into common stock immediately prior to such liquidation event.

[0001628280-16-019400:notes:216]
If upon occurrence of any such event, our assets legally available for distribution are insufficient to permit payment of the aforementioned preferential amounts, then all of our assets legally available for distribution will be distributed ratably to the holders of the Series A Preferred Stock and to the holders of any other class or series of our capital stock ranking on parity with the Series A Preferred Stock.

[0001628280-16-019400:notes:217]
Voting Rights

[0001628280-16-019400:notes:218]
| • | The Series A Preferred Stock have no voting rights except as follows: |

[0001628280-16-019400:notes:219]
| • | Authorize, approve, or make any change to the powers, preferences, privileges or rights of the Series A Preferred Stock; |

[0001628280-16-019400:notes:220]
| • | Authorize or issue any additional shares of Series A Preferred Stock or reduce the number of shares of Series A Preferred Stock; or |

[0001628280-16-019400:notes:221]
| • | Create, or hold capital stock in, any subsidiary that is not wholly-owned by the Company. |

[0001628280-16-019400:notes:222]
Dividends

[0001628280-16-019400:notes:223]
Holders of Series A Preferred Stock, in preference to holders of common stock or any other class or series of our outstanding capital stock ranking in any such event junior to the Series A Preferred Stock, are entitled to receive, when and as declared by the board of directors, quarterly cumulative cash dividends at the annual rate of 2.5% of the Issuance Value per share on each outstanding share of Series A Preferred Stock. The accrued dividends are payable on March 31, June 30, September 30 and December 31 of each year commencing on September 30, 2015.

[0001628280-16-019400:notes:224]
The accrued dividend for the fiscal year ended July 2, 2016 is $0.2 million.

[0001628280-16-019400:notes:225]
Redemption

[0001628280-16-019400:notes:226]
Optional redemption by the Company

[0001628280-16-019400:notes:227]
On or after the third anniversary, we will have the option to redeem for cash all (but not less than all) of the shares of Series A Preferred Stock at a redemption price equal to the Issuance Value plus the accrued and unpaid dividends on each share and any past due dividends, whether or not authorized or declared.

[0001628280-16-019400:notes:228]
Optional redemption by holders

[0001628280-16-019400:notes:229]
Commencing on the fifth anniversary of the Issuance Date, each holder of Series A Preferred Stock may cause the Company to redeem for cash any number of shares of Series A Preferred Stock on any date at a redemption price for share redeemed equal to the Issuance Value plus the accrued and unpaid dividends on each share and any past due dividends, whether or not authorized or declared.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001628280-16-019400:notes:230]
In June 2016, the FASB issued ASU 2016-13 - Financial Instruments - Credit Losses: Measurement of Credit Losses on Financial Instruments ("ASU 2016-13"). ASU 2016-13 amends the impairment model to utilize an expected loss methodology in place of the currently used incurred loss methodology, which will result in the more timely recognition of losses. The new standard applies to financial assets measured at amortized cost basis, including receivables that result from revenue transactions and held-to-maturity debt securities. The new guidance will be effective for the Company starting in the first quarter of fiscal 2021. Early adoption is permitted starting in the first quarter of fiscal 2020. The Company is in the process of determining the effects the adoption will have on its consolidated financial  statements as well as whether to adopt the new guidance early.

[0001628280-16-019400:notes:231]
In March 2016, FASB issued Accounting Standards Update No. ASU 2016-9, Stock Compensation (“ASU 718”) - Improvements to Employee Share-Based Payment Accounting.” This guidance simplifies various aspects related to how share-based payments are accounted for and presented in the financial statements. This guidance is effective for fiscal years, and interim periods within those years, beginning after December 15, 2016. The Company will adopt this standard in fiscal year 2018. The Company has not yet determined the effect, that the adoption of this standard will have on its consolidated financial statements or results of operations.

[0001628280-16-019400:notes:232]
In February 2016, FASB issued Accounting Standards Update No. 2016-02, Leases (“ASU 2016-02”). The new guidance generally requires an entity to recognize on its balance sheet operating and financing lease liabilities and corresponding right-of-use assets. The standard will be effective for the first interim period within annual reporting periods beginning after December 15, 2018 and early adoption is permitted. The Company is currently evaluating the impact of the adoption of ASU 2016-02 on its consolidated financial statements.

[0001628280-16-019400:notes:233]
In January 2016, FASB issued Accounting Standards Update 2016-01, Recognition and Measurement of Financial Assets and Financial Liabilities (Subtopic 825-10) (“ASU 2016-01”). The new standard provides guidance for the recognition, measurement, presentation and disclosure of financial instruments. This guidance is effective for annual and interim periods beginning after December 15, 2017, and early adoption is not permitted. The Company is currently evaluating the impact of the adoption of ASU 2016-01 on its consolidated financial statements.

[0001628280-16-019400:notes:234]
In November 2015, the FASB issued Accounting Standards Update No. 2015-17, Balance Sheet Classification of Deferred Taxes (“ASU 2015-17”), which simplifies the presentation of deferred income taxes by eliminating the need for entities to separate deferred income tax liabilities and assets into current and noncurrent amounts in a classified statement of financial position. We early adopted this guidance effective December 26, 2015 on a prospective basis. No prior periods were retrospectively adjusted. Refer to "Note 12. Income Taxes"  in the Notes to Consolidated Financial Statements.

[0001628280-16-019400:notes:235]
In April 2015, the FASB issued Accounting Standards Update No. 2015-04 Compensation-Retirement Benefits, ("ASU 2015-04") to provide a practical expedient that permits the entity to measure defined benefit plan assets and obligations using the month-end that is closest to the entity’s fiscal year-end and apply that practical expedient consistently from year to year. This guidance is effective for us in the first quarter of fiscal 2017. Prospective application is required, and early adoption is permitted. We are evaluating the impact of adopting this new accounting guidance on our consolidated financial statements.

[0001628280-16-019400:notes:236]
In May 2014, FASB issued Accounting Standards Update No. 2014-09, Revenue from Contracts with Customers (“ASU 2014-09”), which amended the existing accounting standards for revenue recognition. ASU 2014-09 establishes principles for recognizing revenue upon the transfer of promised goods or services to customers, in an amount that reflects the consideration expected to be received in exchange for those goods or services. The new standard requires that reporting companies disclose the nature, amount, timing and uncertainty of revenue and cash flows arising from contracts with customers. On July 9, 2015, FASB agreed to delay the effective date by one year and, accordingly, the new standard is effective for the Company beginning in the first quarter of fiscal 2018. Early adoption is permitted, but not before the original effective date of the standard. The new standard is required to be applied retrospectively to each prior reporting period presented or retrospectively with the cumulative effect of initially applying it recognized at the date of initial application. The Company has not yet selected a transition method nor has it determined the impact of the new standard on its consolidated financial statements.

[0001628280-16-019400:notes:237]
In March 2016, the Financial Accounting Standards Board (“FASB”) issued guidance to clarify the two aspects of authoritative guidance related to the new revenue recognition guidance issued in May 2014: identifying performance obligations and the licensing implementation guidance. The effective date and transition requirements for the amendments in the guidance are the same as the effective date and transition requirements in the new revenue recognition guidance issued in May 2014. We are evaluating the impact of adopting this new accounting guidance on our consolidated financial statements.

[0001628280-16-019400:notes:238]
On August 27, 2014, the FASB issued ASU No. 2014-15, Presentation of Financial Statements-Going Concern (Subtopic 205-40): Disclosure of Uncertainties about an Entity’s Ability to Continue as a Going Concern. The new guidance requires management of public and private companies to evaluate whether there is substantial doubt about the entity’s ability to continue as a going concern and, if so, disclose that fact. Management will also be required to evaluate and disclose whether its plans alleviate that doubt. The standard will be effective for the Company beginning in the first quarter of fiscal 2018. Early adoption is permitted. We do not expect that the requirement will have an impact on our financial position, results of operations or cash flows.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001628280-16-019400:notes:239]
Note 14. Employee Benefit Plans

[0001628280-16-019400:notes:240]
Employee 401(k) Plans

[0001628280-16-019400:notes:241]
The Company sponsors the Lumentum 401(k) Retirement Plan (the “401(k) Plan”, a defined contribution plan under ERISA, which provides retirement benefits for its eligible employees through tax deferred salary deductions. The 401(k) Plan allows employees to contribute up to 50% of their annual compensation, with contributions limited to $18,000 in calendar year 2016 as set by the Internal Revenue Service.

[0001628280-16-019400:notes:242]
The Company also makes a matching contribution equal to 100% of employees before-tax contributions up to 3% of their compensation and 50% of employees before-tax contributions to the next 2% of their compensation.  The Company match is contributed on a per-pay-period basis and is based on employees before-tax contributions and compensation each pay period.

[0001628280-16-019400:notes:243]
Employees are eligible for match contributions after completing 180 days of service.  All matching contributions are made in cash & vest immediately.  We made matching contributions to the 401(k) Plan in the amount of $3.5 million in fiscal 2016. Viavi made matching contributions on our behalf to the 401(k) Plan in the amount of $2.6 million and $2.5 million in fiscal 2015, and 2014, respectively.

[0001628280-16-019400:notes:244]
Employee Defined Benefit Plans

[0001628280-16-019400:notes:245]
During the third quarter of fiscal 2014, we assumed a defined benefit plan in connection with the acquisition of Time-Bandwidth. Prior to the third quarter of fiscal 2014, we did not have any significant defined benefit plans. This plan, which covers certain Swiss employees, is open to new participants and additional service costs are being accrued. Benefits are generally based upon age and compensation. As of July 2, 2016, the plan was partially funded. Our policy for partially funded plans is to make contributions equal to or greater than the requirements prescribed by law or regulation. Future estimated benefit payments are summarized below. No other required contributions to this defined benefit plan are expected in fiscal 2017, but we can, at our discretion, make contributions to the plan.

[0001628280-16-019400:notes:246]
We account for our obligations under this pension plan in accordance with the authoritative guidance which requires us to record our obligation to the participants, as well as the corresponding net periodic cost. We determine our obligation to the participants and our net periodic cost principally using actuarial valuations provided by third-party actuaries. The net obligation of $3.5 million as of July 2, 2016 is recorded in our consolidated balance sheets as non-current liabilities and is reflective of the total PBO less the fair value of plan assets.

[0001628280-16-019400:notes:247]
Assumptions

[0001628280-16-019400:notes:248]
Underlying both the calculation of the PBO and net periodic cost are actuarial valuations. These valuations use participant-specific information such as salary, age and assumptions about interest rates, compensation increases and other factors. At a minimum, we evaluate these assumptions annually and make changes as necessary.

[0001628280-16-019400:notes:249]
The discount rate reflects the estimated rate at which the pension benefits could be effectively settled. In developing the discount rate, we consider the yield available on an appropriate AA corporate bond index, adjusted to reflect the term of the scheme's liabilities.

[0001628280-16-019400:notes:250]
The expected return on assets was estimated by using the weighted average of the real expected long-term return (net of inflation) on the relevant classes of assets based on the target asset mix and adding the chosen inflation assumption.

[0001628280-16-019400:notes:251]
The following table summarizes the assumptions used to determine net periodic cost and benefit obligation for the pension plan:

[0001628280-16-019400:notes:252]
|  | Pension Benefit Plans |
|  | 2016 |  | 2015 |
| Assumptions used to determine net periodic cost: |  |  |  |
| Discount rate | 1.1 | % |  | 2.0 | % |
| Expected long-term return on plan assets | 3.3 | % |  | 3.2 | % |
| Rate of pension increase | 2.3 | % |  | 2.3 | % |
| Assumptions used to determine benefit obligation at end of year: |  |  |  |
| Discount rate | 0.2 | % |  | 1.1 | % |
| Rate of pension increase | 2.3 | % |  | 2.3 | % |

[0001628280-16-019400:notes:253]
Fair Value Measurement of Plan Assets

[0001628280-16-019400:notes:254]
The following table sets forth the plan's assets at fair value and the percentage of assets allocations as of July 2, 2016 (in millions, except percentage data).

[0001628280-16-019400:notes:255]
|  |  |  |  |  |  | Fair value measurement as of July 2, 2016 |
|  | Target Allocation | Total |  | Percentage of Plan Asset |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs (Level 2) |
| Assets: |  |  |  |  |  |  |  |  |  |
| Global equity | 26 | % |  | $ | 1.2 |  |  | 25.5 | % |  | $ | — |  |  | $ | 1.2 |  |
| Fixed income | 37 | % |  | 1.7 |  |  | 36.2 | % |  | — |  |  | 1.7 |  |
| Alternative Investment | 19 | % |  | 0.9 |  |  | 19.1 | % |  | — |  |  | 0.9 |  |
| Cash | 1 | % |  | 0.1 |  |  | 2.1 | % |  | 0.1 |  |  | — |  |
| Other | 17 | % |  | 0.8 |  |  | 17.1 | % |  | — |  |  | 0.8 |  |
| Total Assets |  |  | $ | 4.7 |  |  | 100.0 | % |  | $ | 0.1 |  |  | $ | 4.6 |  |

[0001628280-16-019400:notes:256]
The following table sets forth the plan's assets at fair value and the percentage of assets allocations as of June 27, 2015 (in millions, except percentage data).

[0001628280-16-019400:notes:257]
|  |  |  |  |  |  | Fair value measurement as of June 27, 2015 |
|  | Target Allocation | Total |  | Percentage of Plan Asset |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs (Level 2) |
| Assets: |  |  |  |  |  |  |  |  |  |
| Global equity | 23 | % |  | $ | 1.3 |  |  | 28.3 | % |  | $ | — |  |  | $ | 1.3 |  |
| Fixed income | 36 | % |  | 1.6 |  |  | 34.8 | % |  | — |  |  | 1.6 |  |
| Alternative Investment | 22 | % |  | 0.9 |  |  | 19.6 | % |  |  |  | 0.9 |  |
| Cash | 1 | % |  | 0.1 |  |  | 2.2 | % |  | 0.1 |  |  | — |  |
| Other | 18 | % |  | 0.7 |  |  | 15.1 | % |  | — |  |  | 0.7 |  |
| Total Assets |  |  | $ | 4.6 |  |  | 100.0 | % |  | $ | 0.1 |  |  | $ | 4.5 |  |

[0001628280-16-019400:notes:258]
Our pension assets consist of multiple institutional funds ("pension funds") of which the fair values are based on the quoted prices of the underlying funds. Pension funds are classified as Level 2 assets since such funds are not directly traded in active markets. Global equity consists of several funds that invest primarily in Swiss and Foreign equities; Fixed income consists of several funds that invest primarily in investment grade domestic and overseas bonds; Other consists of several funds that primarily invest in hedge fund, private equity, global real estate and infrastructure funds.

[0001628280-16-019400:notes:259]
Future Benefit Payments

[0001628280-16-019400:notes:260]
We estimate our expected benefit payments to defined benefit pension plan participants based on the same assumptions used to measure our PBO at year end which includes benefits attributable to estimated future compensation increases. Based on this approach, we expect to make payments of $0.7 million during the five year period between fiscal 2017 and fiscal 2021 and the remaining $2.8 million of payments in fiscal years subsequent to fiscal 2020.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001628280-16-019400:notes:261]
Note 17. Quarterly Financial Information (unaudited)

[0001628280-16-019400:notes:262]
The following table presents our quarterly consolidated statements of operations for fiscal 2016 and 2015 (in millions, except per share data):

[0001628280-16-019400:notes:263]
|  | July 2, 2016 (3) |  | April 2, 2016 (3) |  | December 26, 2015 (3) |  | September 26, 2015 (3) |  | June 27, 2015 |  | March 28, 2015 |  | December 27, 2014 |  | September 27, 2014 |
| Net revenue | 241.7 |  |  | 230.4 |  |  | 218.3 |  |  | 212.6 |  |  | 208.9 |  |  | 198.7 |  |  | 210.5 |  |  | 219.0 |  |
| Cost of sales | 160.5 |  |  | 165.9 |  |  | 148.5 |  |  | 144.0 |  |  | 143.4 |  |  | 139.7 |  |  | 141.7 |  |  | 146.8 |  |
| Amortization of acquired technologies | 1.7 |  |  | 1.7 |  |  | 1.7 |  |  | 1.7 |  |  | 1.9 |  |  | 1.9 |  |  | 1.9 |  |  | 1.9 |  |
| Gross profit | 79.5 |  |  | 62.8 |  |  | 68.1 |  |  | 66.9 |  |  | 63.6 |  |  | 57.1 |  |  | 66.9 |  |  | 70.3 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 36.4 |  |  | 35.3 |  |  | 35.0 |  |  | 34.4 |  |  | 35.7 |  |  | 35.0 |  |  | 35.1 |  |  | 35.0 |  |
| Selling, general and administrative | 29.5 |  |  | 28.0 |  |  | 25.8 |  |  | 34.0 |  |  | 37.6 |  |  | 31.8 |  |  | 31.2 |  |  | 28.3 |  |
| Restructuring and related charges | 3.5 |  |  | 1.8 |  |  | 1.1 |  |  | 1.0 |  |  | 4.9 |  |  | 1.1 |  |  | 3.8 |  |  | 1.8 |  |
| Total operating expenses | 69.4 |  |  | 65.1 |  |  | 61.9 |  |  | 69.4 |  |  | 78.2 |  |  | 67.9 |  |  | 70.1 |  |  | 65.1 |  |
| Income (Loss) from operations | 10.1 |  |  | (2.3 | ) |  | 6.2 |  |  | (2.5 | ) |  | (14.6 | ) |  | (10.8 | ) |  | (3.2 | ) |  | 5.2 |  |
| Unrealized (gain) loss on derivative liabilities | 4.4 |  |  | (4.8 | ) |  | (2.4 | ) |  | 2.2 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Interest and other income (expense), net | (0.1 | ) |  | (0.4 | ) |  | (0.5 | ) |  | (0.2 | ) |  | (0.3 | ) |  | (0.4 | ) |  | (0.1 | ) |  | (0.3 | ) |
| Income (loss) before income taxes | 14.4 |  |  | (7.5 | ) |  | 3.3 |  |  | (0.5 | ) |  | (14.9 | ) |  | (11.2 | ) |  | (3.3 | ) |  | 4.9 |  |
| (Benefit from) provisions for income taxes (2) | 0.1 |  |  | 0.1 |  |  | 0.5 |  |  | (0.3 | ) |  | 0.9 |  |  | (23.4 | ) |  | 0.8 |  |  | 0.6 |  |
| Net income (loss) | 14.3 |  |  | (7.6 | ) |  | 2.8 |  |  | (0.2 | ) |  | (15.8 | ) |  | 12.2 |  |  | (4.1 | ) |  | 4.3 |  |
| Net income (loss) attributable to common stockholders |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) per share attributable to common stockholders(1) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | 0.24 |  |  | (0.13 | ) |  | 0.05 |  |  | — |  |  | (0.27 | ) |  | 0.21 |  |  | (0.07 | ) |  | 0.07 |  |
| Diluted | 0.23 |  |  | (0.13 | ) |  | 0.05 |  |  | — |  |  | (0.27 | ) |  | 0.21 |  |  | (0.07 | ) |  | 0.07 |  |
| Shares used in per share calculation attributable to common stockholders: (1) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | 59.4 |  |  | 59.2 |  |  | 59.0 |  |  | 58.8 |  |  | 58.8 |  |  | 58.8 |  |  | 58.8 |  |  | 58.8 |  |
| Diluted | 61.8 |  |  | 59.2 |  |  | 59.2 |  |  | 58.8 |  |  | 58.8 |  |  | 58.8 |  |  | 58.8 |  |  | 58.8 |  |

[0001628280-16-019400:notes:264]
| (1) | On August 1, 2015, JDSU distributed 47.1 million shares, or 80.1% of the outstanding shares of Lumentum common stock to existing holders of JDSU common stock. JDSU was renamed Viavi and at the time of the distribution, retained 11.7 million shares, or 19.9% of Lumentum's outstanding shares. Basic and diluted net income (loss) income per share for all periods through June 27, 2015 is calculated using the shares of Lumentum common stock outstanding on August 1, 2015. Refer to "Note 4. Earnings Per Share" in the Notes to Consolidated Financial Statements. |

[0001628280-16-019400:notes:265]
| (2) | During the third quarter of fiscal 2015, we recognized a $21.8 million tax benefit upon the settlement of an audit in a non-US jurisdiction. |

[0001628280-16-019400:notes:266]
| (3) | During the three months ended July 2, 2016 we corrected an error relating to the understatement of the restructuring expense of $0.2 million, $0.2 million and $0.4 million for the three months ended September 26, 2015, December 26, 2015 and April 2, 2016, respectively, resulting in the overstatement of restructuring expense of $0.8 million for the three months ended July 2, 2016. During the three months ended April 2, 2016, we corrected an error relating to stock-based compensation expense for the three months ended December 26, 2015 in which stock-based compensation expense of $1.0 million was excluded for a specific restricted stock grant, resulting in the overstatement of stock-based compensation expense of $1.0 million for the three months ended April 2, 2016. Additionally during the three months ended April 2, 2016, we corrected an error relating to the overstatement of sales and use tax expense of $0.2 million and $0.3 million for the three months ended September 26, 2015 and December 26, 2015, respectively, resulting in the understatement of sales and use tax expense of $0.5 million for the three months ended April 2, 2016. During the three months ended December 26, 2015, we corrected an error relating to the determination of the accretion amount of Series A preferred stock for the three months ended September 26, 2015 in which the accretion of the discount related to issuance cost of $2.0 million was excluded, resulting in the overstatement of the accretion of Series A preferred stock of $2.0 million for the three months ended December 25, 2015. |

[0001628280-16-019400:notes:267]
As a result, our net loss attributable to common stockholders and basic and diluted net loss per share attributable to common stockholders included in our quarterly report on Form 10-Q ("Form 10-Q") for the three months ended September 26, 2015 was understated by $2.0 million and $0.03 per basic and diluted share, respectively. Our net income attributable to common stockholders and basic and diluted net income per share attributable to common stockholders included in Form 10-Q for the three months ended December 26, 2015 was understated by $0.9 million and $0.02 per basic and diluted share, respectively.  Our net loss attributable to common stockholders included in Form 10-Q for the three months ended April 2, 2016 was understated by $0.1 million, there was no impact to earnings per share, both basic and diluted. Our net income attributable to common stockholders and basic and diluted net loss per share attributable to common stockholders for the three months ended July 2, 2016 was overstated by $0.8 million and $0.01 per basic and diluted share, respectively.

[0001628280-16-019400:notes:268]
We assessed the materiality of these errors and determined that the above errors were not material to our unaudited consolidated financial statements as of each of the periods mentioned above.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001628280-16-019400:notes:269]
Note 3. Related Party Transactions

[0001628280-16-019400:notes:270]
Transactions with Viavi

[0001628280-16-019400:notes:271]
Agreements with Viavi

[0001628280-16-019400:notes:272]
On July 31, 2015, the Company entered into a Supply Agreement with Viavi providing that each party will supply certain products at pre-determined prices, and providing Viavi with research and development services at cost plus a specified markup. The Company also agreed to supply office space via a sublease agreement to Viavi. The sublease income and research and development cost reimbursements are each recorded as reduction to operating expenses in the Consolidated Statements of Operations for fiscal year ended July 2, 2016.

[0001628280-16-019400:notes:273]
The Supply Agreement contains a $15.0 million purchase commitment with Viavi for certain products, and the Company   fulfilled the commitment during fiscal year ended July 2, 2016.

[0001628280-16-019400:notes:274]
During the fiscal year ended July 2, 2016, the Company recognized revenue of $3.3 million from products sold to Viavi. During the fiscal year ended July 2, 2016, the Company recorded $2.3 million in research and development cost reimbursement and $0.7 million in sublease rental income. As of July 2, 2016, the Company had $1.1 million in accounts receivable due from Viavi.

[0001628280-16-019400:notes:275]
On July 31, 2015, the Company also entered into the following agreements with Viavi:

[0001628280-16-019400:notes:276]
| a) | Contribution Agreement which identified the assets transferred, the liabilities assumed and the contracts assigned and it provided for when and how these transfers, assumptions and assignments would occur. |

[0001628280-16-019400:notes:277]
| b) | Separation and Distribution Agreement which governs the Separation of the Lumentum business and other matters related to Lumentum’s relationship with Viavi. |

[0001628280-16-019400:notes:278]
| c) | Tax Matters Agreement which governs the respective rights, responsibilities and obligations of Lumentum and Viavi with respect to tax liabilities and benefits, attributes, proceedings, returns and certain other tax matters. |

[0001628280-16-019400:notes:279]
| d) | Employee Matters Agreement which governs the compensation and employee benefit obligations with respect to the current and former employees of Lumentum and Viavi, the treatment of equity based compensation and generally allocates liabilities and responsibilities relating to employee compensation, benefit plans and programs. The Employee Matters Agreement provides that employees of Lumentum will participate in benefit plans sponsored or maintained by Lumentum. |

[0001628280-16-019400:notes:280]
| e) | Securities Purchase Agreement, which also includes Amada Holdings Co., Ltd. (“Amada”) as a party, which sets forth the terms for the sale by Viavi to Amada of shares of Series A Preferred Stock (the "Series A Preferred Stock") of Lumentum Inc., our wholly-owned subsidiary, following the Separation. |

[0001628280-16-019400:notes:281]
| f) | Intellectual Property Matters Agreement which outlines the intellectual property rights of Lumentum and Viavi following the Separation, as well as non-compete restrictions between Viavi and Lumentum. |

[0001628280-16-019400:notes:282]
Allocated Costs

[0001628280-16-019400:notes:283]
From June 28, 2015 to August 1, 2015, the Separation date, the consolidated statements of operations included our direct expenses for cost of sales, research and development, sales and marketing, and administration as well as allocations of expenses arising from shared services and infrastructure provided by Viavi to us. These allocated expenses include costs of information technology, human resources, accounting, legal, real estate and facilities, corporate marketing, insurance, treasury and other corporate and infrastructure services. In addition, other costs allocated to us include restructuring and stock-based compensation related to Viavi’s corporate and shared services employees and are included in the table below. These expenses were allocated to us using estimates that we consider to be a reasonable reflection of the utilization of services or benefits received by our business. The allocation methods include revenue, headcount, square footage, actual consumption and usage of services and others.

[0001628280-16-019400:notes:284]
Allocated costs included in the accompanying consolidated statements of operations are as follows (in millions):

[0001628280-16-019400:notes:285]
|  | Years Ended |
|  | July 2, 2016 |  | June 27, 2015 |  | June 28, 2014 |
| Research and development | $ | — |  |  | $ | 0.4 |  |  | $ | — |  |
| Selling, general and administrative | $ | 11.7 |  |  | $ | 82.5 |  |  | $ | 63.5 |  |
| Restructuring and related charges | — |  |  | 3.9 |  |  | 2.3 |  |
| Interest and other (income) expenses, net | (0.1 | ) |  | 0.4 |  |  | (1.3 | ) |
| Interest expense | 0.1 |  |  | 0.7 |  |  | 0.2 |  |
| Total allocated costs | $ | 11.7 |  |  | $ | 87.9 |  |  | $ | 64.7 |  |

[0001628280-16-019400:notes:286]
Other Agreements

[0001628280-16-019400:notes:287]
We shared and operated under agreements executed by Viavi with third parties, including but not limited to purchasing, manufacturing, and freight agreements; use of facilities owned, leased, and managed by Viavi; and software, technology and other intellectual property agreements.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-16-019400:notes:288]
Note 11. Restructuring and Related Charges

[0001628280-16-019400:notes:289]
We have initiated various strategic restructuring events primarily intended to reduce costs, consolidate our operations, rationalize the manufacturing of our products and align our business in response to the market conditions. As of July 2, 2016 and June 27, 2015, our total restructuring accrual was $5.7 million and $6.0 million, respectively. During fiscal 2016, 2015 and 2014, we recorded $7.7 million, $11.6 million and $4.8 million, respectively, in restructuring and related charges in the consolidated statements of operations. Of the $7.7 million charge recorded during fiscal 2016, $2.1 million related to severance, retention and employee benefits and there were no costs allocated to us by Viavi. Of the$11.6 million charge recorded during fiscal 2015, $3.9 million related to costs allocated to us by Viavi for plans impacting Viavi's corporate and shared services employees. Of the $4.8 million charge recorded during fiscal 2014, $2.3 million related to costs allocated to us by Viavi for plans impacting Viavi's corporate and shared services employees. Our restructuring charges include severance and benefit costs to eliminate a specified number of positions, facilities and equipment costs to vacate facilities and consolidate operations, and lease termination costs. The timing of associated cash payments is dependent upon the type of restructuring charge and can extend over multiple periods.

[0001628280-16-019400:notes:290]
Summary of Restructuring Plans

[0001628280-16-019400:notes:291]
The adjustments to the restructuring accrual related to all of our restructuring plans described below as of July 2, 2016, were as follows (in millions):

[0001628280-16-019400:notes:292]
|  | Fiscal 2015 Restructuring Plan |  | Fiscal 2016 Restructuring Plan |  |  |
|  | Restructuring Charges |  | Exit Costs |  | Restructuring Charges |  | Other Charges |  | Total |
| Liability as of June 27, 2015 | $ | 4.9 |  |  | $ | 1.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 6.0 |  |
| Charges | 1.4 |  |  | — |  |  | 0.7 |  |  | 5.6 |  |  | 7.7 |  |
| Payments | (1.8 | ) |  | (0.6 | ) |  | — |  |  | (5.6 | ) |  | (8.0 | ) |
| Liability as of July 2, 2016 | $ | 4.5 |  |  | $ | 0.5 |  |  | $ | 0.7 |  |  | $ | — |  |  | $ | 5.7 |  |

[0001628280-16-019400:notes:293]
As of  July 2, 2016, our restructuring liability includes $5.5 million in short-term other current liabilities and $0.2 million in other non-current liabilities on the consolidated balance sheets.

[0001628280-16-019400:notes:294]
As of June 27, 2015, our restructuring liability includes $3.8 million in short-term other current liabilities and $2.2 million in other non-current liabilities on the consolidated balance sheets.

[0001628280-16-019400:notes:295]
Fiscal 2016 Plan

[0001628280-16-019400:notes:296]
In the fourth quarter of 2016, our management approved and commenced the 2016 Restructuring Program primarily intended to reduce costs, consolidate our operations, rationalize the manufacturing of our products and align our business in response to the market conditions.

[0001628280-16-019400:notes:297]
Fiscal 2015 Plans

[0001628280-16-019400:notes:298]
Separation Restructuring Plan

[0001628280-16-019400:notes:299]
During the second and fourth quarter of fiscal 2015, management approved restructuring plans impacting our OpComms segment to optimize operations and gain efficiencies by closing the Bloomfield, Connecticut site and consolidating roles and responsibilities across functions as we move forward with our Separation plan. As a result, a restructuring charge of $4.6 million was recorded for severance and employee benefits during fiscal 2015. In total approximately 200 employees in manufacturing, R&D and SG&A functions located in North America, Europe and Asia were impacted. Payments related to the remaining severance and benefits accrual are expected to be paid by the end of the second quarter of fiscal 2017.

[0001628280-16-019400:notes:300]
Robbinsville Closure Plan

[0001628280-16-019400:notes:301]
During the first quarter of fiscal 2015, management approved a plan impacting our OpComms segment to optimize operations and gain efficiencies by closing the Robbinsville, New Jersey site and consolidating roles and responsibilities across North America.  As a result, a restructuring charge of $1.5 million was recorded for severance and benefits during fiscal 2015. In total approximately 30 employees in manufacturing, R&D and SG&A functions located in North America were impacted.

[0001628280-16-019400:notes:302]
Fiscal 2014 Plans

[0001628280-16-019400:notes:303]
Serangoon Closure Plan

[0001628280-16-019400:notes:304]
During the fourth quarter of fiscal 2014, management approved a plan impacting our OpComms segment to close the Serangoon office located in Singapore and move to a lower cost region in order to reduce manufacturing and R&D expenses. As a result, approximately 40 employees primarily in manufacturing and R&D functions were impacted.

[0001628280-16-019400:notes:305]
Ottawa Lease Exit Costs

[0001628280-16-019400:notes:306]
During fiscal 2008, we recorded lease exit charges, net of assumed sub-lease income related to our Ottawa facility which was included in selling, general and administrative expenses as the space was never occupied and we had no need for the space in the foreseeable future due to changes in business requirements.

[0001628280-16-019400:notes:307]
For the fiscal year ended July 2, 2016, we had cash settlements of $0.6 million. The fair value of the remaining contractual obligations, net of sublease income is $0.5 million and $1.1 million, as of July 2, 2016, and June 27, 2015, respectively. As of July 2, 2016 and June 27, 2015, $0.3 million and $0.6 million was included in other current liabilities, and $0.2 million and $0.5 million in other non-current liabilities, respectively, on the consolidated balance sheets. The payments related to these lease costs are expected to be paid by the end of the third quarter of fiscal 2018.

[0001628280-16-019400:notes:308]
In the third quarter of fiscal 2015, we released  $0.9 million of accrued lease exit charges for reusing certain spaces of our Ottawa facility. During fiscal 2015, we recorded $0.7 million benefit in the SG&A charges, plus we had cash settlements of $1.0 million and other non-cash benefits of $0.3 million.


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001628280-16-019400:notes:309]
Long-lived assets, namely net property, plant and equipment were identified based on the operations in the corresponding geographic areas (in millions):

[0001628280-16-019400:notes:310]
|  | Years Ended |
|  | July 2, 2016 |  | June 27, 2015 |
| Property, Plant and Equipment, net |  |  |  |
| United States | $ | 69.0 |  |  | $ | 63.0 |  |
| Canada | 21.4 |  |  | 13.5 |  |
| China | 46.6 |  |  | 34.4 |  |
| Thailand | 43.8 |  |  | 29.0 |  |
| Other Asia-Pacific | 0.2 |  |  | 1.2 |  |
| EMEA | 2.4 |  |  | 2.1 |  |
| Total long-lived assets | $ | 183.4 |  |  | $ | 143.2 |  |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001628280-16-019400:notes:311]
During fiscal 2016, 2015 and 2014, net revenue generated from a single customer which represented 10% greater of total net revenue is summarized as follows:

[0001628280-16-019400:notes:312]
|  | Years Ended |
|  | July 2, 2016 |  | June 27, 2015 |  | June 28, 2014 |
| Huawei Technologies. Co. Ltd. | 17.1 | % |  | * |  |  | * |  |
| Ciena Corporation | 17.1 | % |  | 14.4 | % |  | 15.9 | % |
| Alphabet Inc. (formerly Google) | * |  |  | * |  |  | 10.3 | % |
| Cisco Systems, Inc. | 13.0 | % |  | 11.8 | % |  | * |  |
| *Represents less than 10% of total net revenue |  |  |  |  |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001628280-16-019400:notes:313]
The following table presents net revenue by the three geographic regions we operate in and net revenue from countries that exceeded 10% of our total net revenue (in millions, except percentage data):

[0001628280-16-019400:notes:314]
|  | Years Ended |
|  | July 2, 2016 |  | June 27, 2015 |  | June 28, 2014 |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 162.3 |  |  | 18.0 | % |  | $ | 162.4 |  |  | 19.4 | % |  | $ | 177.5 |  |  | 21.7 | % |
| Mexico | 112.9 |  |  | 12.5 |  |  | 112.7 |  |  | 13.5 |  |  | 111.3 |  |  | 13.6 |  |
| Other Americas | 19.6 |  |  | 2.2 |  |  | 31.1 |  |  | 3.6 |  |  | 30.3 |  |  | 3.7 |  |
| Total Americas | $ | 294.8 |  |  | 32.7 | % |  | $ | 306.2 |  |  | 36.5 | % |  | $ | 319.1 |  |  | 39.0 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 214.0 |  |  | 23.7 | % |  | $ | 120.4 |  |  | 14.4 | % |  | $ | 128.7 |  |  | 15.8 | % |
| Japan | 92.9 |  |  | 10.3 |  |  | 106.6 |  |  | 12.7 |  |  | 97.6 |  |  | 11.9 |  |
| Other Asia-Pacific | 177.8 |  |  | 19.6 |  |  | 174.4 |  |  | 20.9 |  |  | 138.6 |  |  | 16.9 |  |
| Total Asia-Pacific | $ | 484.7 |  |  | 53.6 | % |  | $ | 401.4 |  |  | 48.0 | % |  | $ | 364.9 |  |  | 44.6 | % |
| EMEA | $ | 123.5 |  |  | 13.7 | % |  | $ | 129.5 |  |  | 15.5 | % |  | $ | 133.9 |  |  | 16.4 | % |
| Total net revenue | $ | 903.0 |  |  |  |  | $ | 837.1 |  |  |  |  | $ | 817.9 |  |  |  |
| * Represents less than 10% of total net revenue |  |  |  |  |  |  |  |  |  |  |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001628280-16-019400:notes:315]
Information on reportable segments utilized by our CODM is as follows (in millions):

[0001628280-16-019400:notes:316]
|  | Years Ended |
|  | July 2, 2016 |  | June 27, 2015 |  | June 28, 2014 |
| Net revenue: |  |  |  |  |  |
| OpComms | $ | 761.3 |  |  | $ | 694.1 |  |  | $ | 695.1 |  |
| Lasers | 141.7 |  |  | 143.0 |  |  | 122.8 |  |
| Net revenue | $ | 903.0 |  |  | $ | 837.1 |  |  | $ | 817.9 |  |
| Gross profit: |  |  |  |  |  |
| OpComms | 236.3 |  |  | 204.8 |  |  | 212.3 |  |
| Lasers | 61.4 |  |  | 67.4 |  |  | 59.8 |  |
| Total segment gross profit | 297.7 |  |  | 272.2 |  |  | 272.1 |  |
| Unallocated amounts: |  |  |  |  |  |
| Stock-based compensation | (6.1 | ) |  | (5.1 | ) |  | (5.6 | ) |
| Amortization of intangibles | (6.8 | ) |  | (7.6 | ) |  | (9.0 | ) |
| Other charges | (7.5 | ) |  | (1.6 | ) |  | (0.9 | ) |
| Gross profit | $ | 277.3 |  |  | $ | 257.9 |  |  | $ | 256.6 |  |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001628280-16-019400:notes:317]
The following additional financial statement schedules should be considered in conjunction with our consolidated financial statements. All other financial statement schedules have been omitted because the required information is not present in amounts sufficient to require submission of the schedule, not applicable, or because the required information is included in the Consolidated Financial Statements or Notes thereto.

[0001628280-16-019400:notes:318]
LUMENTUM HOLDINGS INC.

[0001628280-16-019400:notes:319]
FINANCIAL STATEMENT SCHEDULES

[0001628280-16-019400:notes:320]
SCHEDULE II - VALUATION AND QUALIFYING ACCOUNTS

[0001628280-16-019400:notes:321]
|  | (in millions) |
|  | Balance atBeginningof Period |  | Increase (decrease) toCosts andExpenses |  | WriteOffs |  | ReversalBenefit toRevenue |  | Balanceat End ofPeriod |
| Allowance for doubtful accounts: |  |  |  |  |  |  |  |  |  |
| Fiscal year ended July 2, 2016 | $ | 1.2 |  |  | $ | 0.6 |  |  | $ | (0.9 | ) |  | $ | — |  |  | $ | 0.9 |  |

[0001628280-16-019400:notes:322]
|  |  | (in millions) |
| Description |  | Balance at Beginning of Period |  | Additions Charged to Expenses or Other Accounts* |  | Deductions Credited to Expenses or Other Accounts** |  | Balance at End of Period |
| 2016 |  |  |  |  |  |  |  |  |
| Deferred tax valuation allowance |  | $ | 160.0 |  |  | $ | 214.3 |  |  | $ | (52.9 | ) |  | $ | 321.4 |  |
| 2015 |  |  |  |  |  |  |  |  |
| Deferred tax valuation allowance |  | 184.6 |  |  | 3.4 |  |  | (28.0 | ) |  | 160.0 |  |
| 2014 |  |  |  |  |  |  |  |  |
| Deferred tax valuation allowance |  | 215.3 |  |  | 1.5 |  |  | (32.2 | ) |  | 184.6 |  |
| 2013 |  |  |  |  |  |  |  |  |
| Deferred tax valuation allowance |  | 255.3 |  |  | 1.5 |  |  | (41.5 | ) |  | 215.3 |  |

[0001628280-16-019400:notes:323]
*    Additions include current year additions charged to expenses and current year build due to increases in net deferred tax assets, return to provision true-ups, other adjustments to deferred taxes.

[0001628280-16-019400:notes:324]
**    Deductions include current year releases credited to expenses and current year reductions due to decreases in net deferred tax assets, return to provision true-ups, other adjustments to deferred taxes.


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001628280-16-019400:notes:325]
The table below discloses the percentage of our total net revenue attributable to each of our two reportable segments. In addition, it discloses the percentage of our total net revenue attributable to our product offerings which serve the Telecom, Datacom and consumer and industrial ("Consumer and Industrial") markets which accounted for more than 10% or more of our total net revenue during the last three fiscal years:

[0001628280-16-019400:notes:326]
|  |  | Years Ended |
|  |  | July 2, 2016 |  | June 27, 2015 |  | June 28, 2014 |
| OpComms: |  |  | 84.3 | % |  |  | 82.9 | % |  |  | 85.0 | % |
| Telecom |  |  | 61.5 | % |  |  | 60.6 | % |  |  | 60.6 | % |
| Datacom |  |  | 18.1 | % |  |  | 17.4 | % |  |  | 14.3 | % |
| Consumer and Industrial |  |  | 4.7 | % |  |  | 4.9 | % |  |  | 10.1 | % |
| Lasers |  |  | 15.7 | % |  |  | 17.1 | % |  |  | 15.0 | % |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-16-019400:notes:327]
Note 16. Operating Segments and Geographic Information

[0001628280-16-019400:notes:328]
Our chief executive officer is our Chief Operating Decision Maker ("CODM"). The CODM allocates resources to the segments based on their business prospects, competitive factors, net revenue and gross margin.

[0001628280-16-019400:notes:329]
We are an industry leading provider of optical and photonic products defined by revenue and market share addressing a range of end-market applications including optical communications and commercial lasers. We have two operating segments, Optical Communications, which we refer to as OpComms, and Commercial Lasers, which we refer to as Lasers. The two operating segments were primarily determined based on how the Chief Operating Decision Mater (“CODM”) views and evaluates our operations. Operating results are regularly reviewed by the CODM to make decisions about resources to be allocated to the segments and to assess their performance. Other factors, including market separation and customer specific applications, go-to-market channels, products and manufacturing, are considered in determining the formation of these operating segments.

[0001628280-16-019400:notes:330]
OpComms

[0001628280-16-019400:notes:331]
Our OpComms products address the following markets: telecommunications (Telecom), data communications (Datacom) and Consumer and Industrial.

[0001628280-16-019400:notes:332]
Our OpComms products include a wide range of components, modules and subsystems to support and maintain customers in our two primary markets: Telecom and Datacom. The Telecom market includes carrier networks for access (local), metro (intracity), long-haul (city-to-city and worldwide) and submarine (undersea) networks. The Datacom market addresses enterprise, cloud and data center applications, including storage-access networks (“SANs”), local-area networks (“LANs”) and wide-area networks (“WANs”). These products enable the transmission and transport of video, audio and text data over high-capacity fiber-optic cables. We maintain leading positions in the fastest-growing OpComms markets, including reconfigurable optical add/drop multiplexers (“ROADMs”), tunable 10-gigabit small form-factor pluggable transceivers and tunable small form-factor pluggables. Our 10G, 40G legacy transceivers and a growing portfolio of 100G pluggable transceivers support LAN/SAN/WAN needs and the cloud for customers building enterprise and hyperscale data center networks.

[0001628280-16-019400:notes:333]
Our products for 3-D sensing applications include our light source product. Customer solutions containing our 3-D sensing lasers employ our laser technology in mobile, computing, industrial and automotive applications. Emerging 3-D sensing systems simplify the way people interact with technology and were first used in applications for gaming platforms.

[0001628280-16-019400:notes:334]
Lasers

[0001628280-16-019400:notes:335]
Our Lasers products serve our customers in markets and applications such as manufacturing, biotechnology, graphics and imaging, remote sensing, and precision machining such as drilling in printed circuit boards, wafer singulation and solar cell scribing. Our Lasers products are used in a variety of original equipment manufacturer (“OEM”) applications.

[0001628280-16-019400:notes:336]
Our Laser products are used in a variety of OEM applications including diode-pumped solid-state, fiber, diode, direct-diode and gas lasers such as argon-ion and helium-neon lasers. Diode-pumped solid-state and fiber lasers provide excellent beam quality, low noise and exceptional reliability and are used in biotechnology, graphics and imaging, remote sensing, materials processing and precision machining applications. Diode and direct-diode lasers address a wide variety of applications, including laser pumping, thermal exposure, illumination, ophthalmology, image recording, printing, plastic welding and selective soldering. Gas lasers such as argon-ion and helium-neon lasers provide a stable, low-cost and reliable solution over a wide range of operating conditions, making them well suited for complex, high-resolution OEM applications such as flow cytometry, DNA sequencing, graphics and imaging and semiconductor inspection.

[0001628280-16-019400:notes:337]
Our acquisition of Time-Bandwidth enabled us to provide high-powered and ultrafast lasers for the industrial and scientific markets. Manufacturers use high-power, ultrafast lasers to create micro parts for consumer electronics and to process semiconductor, LED, and other types of chips. Use of ultrafast lasers for micromachining applications is being driven primarily by the increasing use of consumer electronics and connected devices globally.

[0001628280-16-019400:notes:338]
We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments because management does not include the information in its measurement of the performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, stock-based compensation and certain other charges impacting the gross margin of each segment because management does not include this information in its measurement of the performance of the operating segments.

[0001628280-16-019400:notes:339]
We operate in three geographic regions: Americas, Asia-Pacific, and EMEA (Europe Middle East and Africa). Net revenue is assigned to the geographic region and country where our product is initially shipped. For example, certain customers may request shipment of our product to a contract manufacturer in one country, which may differ from the location of their end customers. The following table presents net revenue by the three geographic regions we operate in and net revenue from countries that exceeded 10% of our total net revenue (in millions, except percentage data):

[0001628280-16-019400:notes:340]
During fiscal 2016, 2015 and 2014, net revenue from customers outside the United States, based on customer shipping location, represented 82%, 81% and 78% of net revenue, respectively. Our net revenue is primarily denominated in U.S. dollars, including our net revenue from customers outside the United States as presented above.
