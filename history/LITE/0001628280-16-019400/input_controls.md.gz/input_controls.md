# LITE 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 2 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001628280-16-019400:item_9a:1]
ITEM 9A.    CONTROLS AND PROCEDURES

[0001628280-16-019400:item_9a:2]
(a)   EVALUATION OF DISCLOSURE CONTROLS AND PROCEDURES

[0001628280-16-019400:item_9a:3]
Under the supervision and with the participation of our management, including our Chief Executive Officer and Chief Financial Officer, we conducted an evaluation of the effectiveness of our disclosure controls and procedures, as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended (the “Act”), as of the end of the period covered by this Annual Report on Form 10-K (the “Evaluation Date”).

[0001628280-16-019400:item_9a:4]
The purpose of this evaluation is to determine if, as of the Evaluation Date, our disclosure controls and procedures are effective such that the information required to be disclosed in the reports we file or submit under the Act (i) is recorded, processed, summarized, and reported within the time periods specified in SEC rules and forms and (ii) is accumulated and communicated to our management, including our Chief Executive Officer and Chief Financial Officer, as appropriate, to allow timely decisions regarding required disclosure.

[0001628280-16-019400:item_9a:5]
Based on this evaluation, our Chief Executive Officer and Chief Financial Officer concluded that, as of the Evaluation Date, our disclosure controls and procedures were effective.

[0001628280-16-019400:item_9a:6]
(b)   MANAGEMENT'S REPORT ON INTERNAL CONTROL OVER FINANCIAL REPORTING

[0001628280-16-019400:item_9a:7]
This Annual Report does not include a report of management's assessment regarding internal control over financial reporting or an attestation report of our independent registered public accounting firm due to a transition period established by rules of the SEC for newly public companies.

[0001628280-16-019400:item_9a:8]
(c)   CHANGES IN INTERNAL CONTROL OVER FINANCIAL REPORTING

[0001628280-16-019400:item_9a:9]
There were no changes in our internal control over financial reporting as defined in Exchange Act Rule 13a-15(f) that occurred during our most recently completed fiscal quarter that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001628280-16-019400:item_9a:10]
INHERENT LIMITATIONS ON EFFECTIVENESS OF CONTROLS

[0001628280-16-019400:item_9a:11]
Our management, including the CEO and CFO, recognizes that our disclosure controls and procedures or our internal control over financial reporting cannot prevent or detect all possible instances of errors and all fraud. A control system, no matter how well designed and operated, can provide only reasonable, not absolute, assurance that the control system's objectives will be met. The design of a control system must reflect the fact that there are resource constraints, and the benefits of controls must be considered relative to their costs.
