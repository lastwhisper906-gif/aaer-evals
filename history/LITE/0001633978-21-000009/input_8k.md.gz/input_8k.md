# LITE 8-K — 0001633978-21-000008 filed 2021-05-12

## item codes, every 8-K on or before 2021-05-12

- 2021-05-12 0001633978-21-000008 — 2.02, 9.01
- 2021-03-10 0001193125-21-075438 — 1.01, 8.01, 9.01
- 2021-02-02 0001633978-21-000002 — 2.02, 9.01
- 2021-01-19 0001104659-21-005024 — 1.01, 2.02, 8.01, 9.01
- 2020-11-24 0001193125-20-302557 — 5.02, 5.07
- 2020-11-02 0001633978-20-000017 — 2.02, 9.01
- 2020-09-18 0001633978-20-000012 — 5.02, 9.01
- 2020-08-11 0001633978-20-000010 — 2.02, 9.01
- 2020-05-05 0001628280-20-006358 — 2.02, 9.01
- 2020-02-04 0001633978-20-000002 — 2.02, 9.01
- 2019-12-12 0001193125-19-312875 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2019-12-04 0001633978-19-000075 — 8.01
- 2019-11-20 0001633978-19-000074 — 5.07
- 2019-10-31 0001633978-19-000070 — 2.02, 9.01
- 2019-08-08 0001633978-19-000068 — 2.02, 9.01
- 2019-05-08 0001633978-19-000031 — 1.01
- 2019-05-07 0001633978-19-000029 — 2.02, 9.01
- 2019-02-15 0001633978-19-000005 — 9.01 — amendment of 0001193125-18-346211
- 2019-02-08 0001193125-19-031591 — 5.02, 9.01
- 2019-02-05 0001633978-19-000001 — 2.02, 9.01
- 2018-12-10 0001193125-18-346211 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-12-06 0001633978-18-000150 — 8.01
- 2018-11-14 0001633978-18-000139 — 5.07
- 2018-11-13 0001633978-18-000136 — 3.02
- 2018-11-13 0001633978-18-000132 — 7.01, 9.01
- 2018-11-01 0001628280-18-013238 — 2.02, 9.01
- 2018-08-08 0001633978-18-000056 — 2.02, 9.01
- 2018-06-08 0001193125-18-188241 — 5.02, 9.01
- 2018-05-02 0001633978-18-000029 — 2.02, 9.01
- 2018-03-12 0001193125-18-078154 — 1.01, 2.01, 8.01, 9.01
- 2018-02-06 0001628280-18-001082 — 2.02, 9.01
- 2017-11-08 0001633978-17-000133 — 5.02, 9.01
- 2017-11-07 0001633978-17-000131 — 5.07
- 2017-11-01 0001633978-17-000117 — 2.02, 9.01
- 2017-08-09 0001633978-17-000058 — 2.02, 9.01
- 2017-05-04 0001633978-17-000035 — 2.02, 9.01
- 2017-03-08 0001193125-17-074740 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2017-03-02 0001193125-17-066769 — 8.01, 9.01
- 2017-02-07 0001633978-17-000005 — 2.02, 9.01
- 2017-01-03 0001628280-17-000018 — 4.01, 9.01
- 2016-11-09 0001628280-16-021143 — 5.02, 5.07, 9.01
- 2016-10-27 0001628280-16-020382 — 2.02, 9.01
- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2021-05-12

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001633978-21-000008:8k_2_02:1]
EX-99.1
2
lite_ex991xq3fy21.htm
EX-99.1

[0001633978-21-000008:8k_2_02:2]
Document

[0001633978-21-000008:8k_2_02:3]
NEWS RELEASE

[0001633978-21-000008:8k_2_02:4]
LUMENTUM ANNOUNCES FISCAL THIRD QUARTER 2021 FINANCIAL RESULTS

[0001633978-21-000008:8k_2_02:5]
•Net revenue of $419.5 million; deferred $14.8 million due to delays of 5G deployments in China

[0001633978-21-000008:8k_2_02:6]
•GAAP gross margin of 44.1%; Non-GAAP gross margin of 49.9%

[0001633978-21-000008:8k_2_02:7]
•GAAP operating margin of 63.6%; Non-GAAP operating margin of 27.9%

[0001633978-21-000008:8k_2_02:8]
•GAAP diluted net income per share of $2.85; Non-GAAP diluted net income per share of $1.40

[0001633978-21-000008:8k_2_02:9]
San Jose, Calif., May 12, 2021 – Lumentum Holdings Inc. (“Lumentum” or the “Company”) today reported results for its fiscal third quarter ended April 3, 2021, which was a 14-week period.

[0001633978-21-000008:8k_2_02:10]
Net revenue for the fiscal third quarter of 2021, which was reduced by $14.8 million that was deferred, was $419.5 million, with GAAP net income of $225.5 million, or $2.85 per diluted share. Net revenue for the fiscal second quarter of 2021 was $478.8 million, with GAAP net income of $83.2 million, or $1.06 per diluted share. Net revenue for the fiscal third quarter of 2020 was $402.8 million, with GAAP net income of $43.4 million, or $0.56 per diluted share.

[0001633978-21-000008:8k_2_02:11]
Non-GAAP net income for the fiscal third quarter of 2021 was $110.6 million, or $1.40 per diluted share. Non-GAAP net income for the fiscal second quarter of 2021 was $155.7 million, or $1.99 per diluted share. Non-GAAP net income for the fiscal third quarter of 2020 was $98.0 million, or $1.26 per diluted share.

[0001633978-21-000008:8k_2_02:12]
The Company held $2,054.6 million in total cash, cash equivalents, and short-term investments at the end of the fiscal third quarter of 2021, up $354.3 million compared to the end of the fiscal second quarter of 2021.

[0001633978-21-000008:8k_2_02:13]
“The strong year on year margin improvements in our third quarter results highlight a product portfolio increasingly rich in new and differentiated products that are aligned with multi-year favorable market trends and the impact of continuous improvement in our operations,” said Alan Lowe, President and CEO. “Out of an abundance of caution, we deferred $14.8 million of revenue due to delays in 5G deployments in China, which decreased our reported revenue accordingly. Despite the lower revenue, due to the strength of our financial model we achieved approximately 50% non-GAAP gross margin, and strong non-GAAP operating margin and EPS, both of which were within our guidance ranges. Between our product and technology portfolio, our design-wins with market leading customers, and the positive changes in our business model and the industry over the past several years, I believe the future continues to be very bright at Lumentum.”

[0001633978-21-000008:8k_2_02:14]
“Based on confidence in our long-term outlook, and our cash balance having increased by more than $600 million over the past 12 months through strong cash generation, the Lumentum Board of Directors has approved a share buyback program of up to $700 million over the next two years,” said Wajid Ali, Executive Vice President and CFO. “Despite short-term headwinds in our industry, our guidance is consistent with our historical seasonality when normalizing for the revenue we deferred and the recent 14-week quarter.”

[0001633978-21-000008:8k_2_02:15]
Financial Overview – Fiscal Third Quarter Ended April 3, 2021

[0001633978-21-000008:8k_2_02:16]
|  | GAAP Results ($ in millions) |
|  | Q3 |  | Q2 |  | Q3 |  | Change |
|  | FY 2021 |  | FY 2021 |  | FY 2020 |  | Q/Q |  | Y/Y |
| Net revenue | $419.5 |  | $478.8 |  | $402.8 |  | (12.4)% |  | 4.1% |
| Gross margin | 44.1% |  | 48.0% |  | 39.2% |  | (390)bps |  | 490bps |
| Operating margin | 63.6% |  | 24.1% |  | 10.6% |  | 3,950bps |  | 5,300bps |
|  | Non-GAAP Results ($ in millions) |
|  | Q3 |  | Q2 |  | Q3 |  | Change |
|  | FY 2021 |  | FY 2021 |  | FY 2020 |  | Q/Q |  | Y/Y |
| Net revenue | $419.5 |  | $478.8 |  | $402.8 |  | (12.4)% |  | 4.1% |
| Gross margin | 49.9% |  | 53.4% |  | 45.5% |  | (350)bps |  | 440bps |
| Operating margin | 27.9% |  | 35.5% |  | 25.0% |  | (760)bps |  | 290bps |

[0001633978-21-000008:8k_2_02:17]
|  | Net Revenue by Segment ($ in millions) |
|  | Q3 |  | % of |  | Q2 |  | Q3 |  | Change |
|  | FY 2021 |  | Net Revenue |  | FY 2021 |  | FY 2020 |  | Q/Q |  | Y/Y |
| Optical Communications | $ | 387.9 |  |  | 92.5 | % |  | $ | 449.1 |  |  | $ | 359.3 |  |  | (13.6) | % |  | 8.0 | % |
| Lasers | 31.6 |  |  | 7.5 | % |  | 29.7 |  |  | 43.5 |  |  | 6.4 | % |  | (27.4) | % |
| Total | $ | 419.5 |  |  | 100.0 | % |  | $ | 478.8 |  |  | $ | 402.8 |  |  | (12.4) | % |  | 4.1 | % |

[0001633978-21-000008:8k_2_02:18]
The tables above provide comparisons of quarterly results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled “Use of Non-GAAP Financial Measures.”

[0001633978-21-000008:8k_2_02:19]
Business Outlook

[0001633978-21-000008:8k_2_02:20]
Lumentum expects the following for the fiscal fourth quarter 2021:

[0001633978-21-000008:8k_2_02:21]
•Net revenue in the range of $360 million to $400 million

[0001633978-21-000008:8k_2_02:22]
•Non-GAAP operating margin of 22.5% to 25.0%

[0001633978-21-000008:8k_2_02:23]
•Non-GAAP diluted earnings per share of $0.92 to $1.14

[0001633978-21-000008:8k_2_02:24]
We have not provided reconciliations from GAAP to non-GAAP measures for our outlook. A large portion of non-GAAP adjustments, such as restructuring charges, stock-based compensation, non-cash income tax expense and credits, integration related costs, inventory write down due to plans to exit certain product lines and other costs and contingencies unrelated to current and future operations are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future.

[0001633978-21-000008:8k_2_02:25]
Conference Call

[0001633978-21-000008:8k_2_02:26]
Lumentum will host a conference call today, May 12, 2021, at 5:30 am PT/8:30 am ET. A live webcast of the call and the replay will be available on the Lumentum website at http://investor.lumentum.com through May 19, 2021, at 11:59 pm ET. To listen to the live conference call, dial (844) 802-2439 or (412) 902-4275 and reference the passcode 10155696. To access the replay, dial (877) 344-7529 or (412) 317-0088 and reference the passcode 10155696. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the “Events and Presentations” section concurrently with this earnings press release. Lumentum has used, and intends to continue to use, its Investor Relations website as means of disclosing material nonpublic information and for complying with its disclosure obligations under Regulation FD. This press release is being furnished as an exhibit to a Current Report on Form 8-K filed with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001633978-21-000008:8k_2_02:27]
About Lumentum

[0001633978-21-000008:8k_2_02:28]
Lumentum (NASDAQ: LITE) is a market-leading designer and manufacturer of innovative optical and photonic products enabling optical networking and laser applications worldwide. Lumentum optical components and subsystems are part of virtually every type of telecom, enterprise, and data center network. Lumentum lasers enable advanced manufacturing techniques and diverse applications including next-generation 3D sensing capabilities. Lumentum is headquartered in San Jose, California with R&D, manufacturing, and sales offices worldwide. For more information, visit www.lumentum.com.

[0001633978-21-000008:8k_2_02:29]
Forward-Looking Statements

[0001633978-21-000008:8k_2_02:30]
Contact Information

[0001633978-21-000008:8k_2_02:31]
Investors:            Jim Fanucchi, 408-404-5400; investor.relations@lumentum.com

[0001633978-21-000008:8k_2_02:32]
Media:         Sean Ogarrio, 408-546-5405; media@lumentum.com

[0001633978-21-000008:8k_2_02:33]
Category:            Financial

[0001633978-21-000008:8k_2_02:34]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001633978-21-000008:8k_2_02:35]
LUMENTUM HOLDINGS INC.

[0001633978-21-000008:8k_2_02:36]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001633978-21-000008:8k_2_02:37]
(in millions, except per share data)

[0001633978-21-000008:8k_2_02:38]
(unaudited)

[0001633978-21-000008:8k_2_02:39]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 3, 2021 |  | March 28, 2020 |  | April 3, 2021 |  | March 28, 2020 |
| Net revenue | $ | 419.5 |  |  | $ | 402.8 |  |  | $ | 1,350.7 |  |  | $ | 1,310.5 |  |
| Cost of sales | 218.7 |  |  | 231.2 |  |  | 684.6 |  |  | 757.2 |  |
| Amortization of acquired developed intangibles | 15.8 |  |  | 13.9 |  |  | 45.8 |  |  | 38.8 |  |
| Gross profit | 185.0 |  |  | 157.7 |  |  | 620.3 |  |  | 514.5 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 57.2 |  |  | 48.7 |  |  | 160.4 |  |  | 149.6 |  |
| Selling, general and administrative | 65.5 |  |  | 61.3 |  |  | 183.1 |  |  | 180.4 |  |
| Restructuring and related charges | 2.9 |  |  | 2.7 |  |  | 3.1 |  |  | 4.9 |  |
| Merger termination fee and related costs, net | (207.5) |  |  | — |  |  | (207.5) |  |  | — |  |
| Impairment charges | — |  |  | 2.5 |  |  | — |  |  | 2.5 |  |
| Total operating expenses (income) | (81.9) |  |  | 115.2 |  |  | 139.1 |  |  | 337.4 |  |
| Income from operations | 266.9 |  |  | 42.5 |  |  | 481.2 |  |  | 177.1 |  |
| Interest expense | (16.4) |  |  | (15.6) |  |  | (48.7) |  |  | (45.3) |  |
| Other income (expense), net | 2.4 |  |  | 21.7 |  |  | 2.1 |  |  | 27.9 |  |
| Income before income taxes | 252.9 |  |  | 48.6 |  |  | 434.6 |  |  | 159.7 |  |
| Provision for income taxes | 27.4 |  |  | 5.2 |  |  | 58.8 |  |  | 19.6 |  |
| Net income | $ | 225.5 |  |  | $ | 43.4 |  |  | $ | 375.8 |  |  | $ | 140.1 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 2.97 |  |  | $ | 0.58 |  |  | $ | 4.97 |  |  | $ | 1.84 |  |
| Diluted | $ | 2.85 |  |  | $ | 0.56 |  |  | $ | 4.78 |  |  | $ | 1.80 |  |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |
| Basic | 75.8 |  |  | 74.8 |  |  | 75.6 |  |  | 76.2 |  |
| Diluted | 79.2 |  |  | 77.5 |  |  | 78.6 |  |  | 77.7 |  |

[0001633978-21-000008:8k_2_02:40]
LUMENTUM HOLDINGS INC.

[0001633978-21-000008:8k_2_02:41]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001633978-21-000008:8k_2_02:42]
(in millions, except per share data)

[0001633978-21-000008:8k_2_02:43]
(unaudited)

[0001633978-21-000008:8k_2_02:44]
|  | April 3, 2021 |  | June 27, 2020 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 687.7 |  |  | $ | 298.0 |  |
| Short-term investments | 1,366.9 |  |  | 1,255.8 |  |
| Accounts receivable, net | 224.8 |  |  | 233.5 |  |
| Inventories | 210.7 |  |  | 188.9 |  |
| Prepayments and other current assets | 79.7 |  |  | 73.8 |  |
| Total current assets | 2,569.8 |  |  | 2,050.0 |  |
| Property, plant and equipment, net | 378.0 |  |  | 393.0 |  |
| Operating lease right-of-use assets, net | 70.3 |  |  | 78.7 |  |
| Goodwill | 368.9 |  |  | 368.9 |  |
| Other intangible assets, net | 263.2 |  |  | 316.8 |  |
| Deferred income taxes | 89.9 |  |  | 81.2 |  |
| Other non-current assets | 5.8 |  |  | 4.0 |  |
| Total assets | $ | 3,745.9 |  |  | $ | 3,292.6 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 104.7 |  |  | $ | 150.8 |  |
| Accrued payroll and related expenses | 45.9 |  |  | 53.4 |  |
| Accrued expenses | 39.5 |  |  | 23.7 |  |
| Convertible notes, current | 385.3 |  |  | — |  |
| Operating lease liabilities, current | 11.8 |  |  | 10.8 |  |
| Other current liabilities | 87.0 |  |  | 44.3 |  |
| Total current liabilities | 674.2 |  |  | 283.0 |  |
| Convertible notes, non-current | 778.9 |  |  | 1,120.3 |  |
| Operating lease liabilities, non-current | 50.5 |  |  | 57.6 |  |
| Deferred tax liability | 31.6 |  |  | 46.5 |  |
| Other non-current liabilities | 45.7 |  |  | 36.0 |  |
| Total liabilities | 1,580.9 |  |  | 1,543.4 |  |
| Commitments and contingencies |  |  |  |
| Stockholders’ equity: |  |  |  |
| Common stock, $0.001 par value, 990 authorized shares, 75.8 and 75.1 shares issued and outstanding as of April 3, 2021 and June 27, 2020, respectively | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital | 1,718.8 |  |  | 1,676.6 |  |
| Retained earnings | 440.4 |  |  | 64.6 |  |
| Accumulated other comprehensive income | 5.7 |  |  | 7.9 |  |
| Total stockholders’ equity | 2,165.0 |  |  | 1,749.2 |  |
| Total liabilities and stockholders’ equity | $ | 3,745.9 |  |  | $ | 3,292.6 |  |

[0001633978-21-000008:8k_2_02:45]
Use of Non-GAAP Financial Measures

[0001633978-21-000008:8k_2_02:46]
In this press release, Lumentum provides investors with gross margin, gross profit, research and development expense, selling, general and administrative expense, operating margin, operating income, interest and other income (expense), net, income before income taxes, provision for taxes, net income, and net income per share on a non-GAAP basis as well as the non-GAAP measures of EBITDA and Adjusted EBITDA. Lumentum believes this non-GAAP financial information provides additional insight into the Company’s on-going business operations and results, as well as cash generation, and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons. In addition, the Company believes that providing certain of these measures allow investors to better understand the Company’s cash flows and, importantly, to evaluate the efficacy of the methodology and information used by management to evaluate and measure such cash flows. However, these measures may be different from non-GAAP measures used by other companies, limiting their usefulness for comparison purposes. The non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP. Investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future. Further, these non-GAAP financial measures may not be comparable to similarly titled measurements reported by other companies.

[0001633978-21-000008:8k_2_02:47]
Non-GAAP gross margin, non-GAAP gross profit, non-GAAP expenses, non-GAAP operating margin, non-GAAP operating income, non-GAAP income before income taxes, non-GAAP net income, and non-GAAP net income per share and Adjusted EBITDA exclude (i) stock-based compensation, (ii) inventory write-downs and fixed asset impairment due to cancelled programs, plans to exit certain lines of business and other costs and contingencies unrelated to current and future operations, (iii) acquisition and disposition related costs, (iv) integration related costs, (v) amortization of acquired intangibles, (vi) amortization of inventory fair value adjustments, (vii) restructuring and related charges, (viii) non-cash interest expense, (ix) foreign exchange (gains) losses, net, (x) transferring product lines to Thailand, (xi) excess and obsolete inventory charges driven by U.S. trade restrictions and the related decline in demand from Huawei, (xii) non-cash income tax impacts and the incremental cash income tax attributable to the Coherent termination fee, net of transaction costs, and (xiii) the termination fee we received in connection with the termination of our proposed merger agreement with Coherent, net of acquisition related charges. The presentation of these and other similar items in Lumentum’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001633978-21-000008:8k_2_02:48]
A quantitative reconciliation between GAAP and non-GAAP financial data with respect to historical periods is included in the supplemental financial table attached to this press release.

[0001633978-21-000008:8k_2_02:49]
LUMENTUM HOLDINGS INC.

[0001633978-21-000008:8k_2_02:50]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001633978-21-000008:8k_2_02:51]
(in millions, except per share data)

[0001633978-21-000008:8k_2_02:52]
(unaudited)

[0001633978-21-000008:8k_2_02:53]
|  | Three Months Ended |  |  | Nine Months Ended |  |
|  | April 3, 2021 |  | December 26, 2020 |  | March 28, 2020 |  |  | April 3, 2021 |  | March 28, 2020 |  |
| Gross profit on GAAP basis | $ | 185.0 |  |  | $ | 229.6 |  |  | $ | 157.7 |  |  |  | $ | 620.3 |  |  | $ | 514.5 |  |  |
| Stock-based compensation | 5.3 |  |  | 4.8 |  |  | 4.3 |  |  |  | 13.8 |  |  | 12.6 |  |  |
| Inventory and fixed asset write down due to product line exits (1) | — |  |  | 0.1 |  |  | 2.3 |  |  |  | 0.4 |  |  | 6.0 |  |  |
| Integration related costs | — |  |  | — |  |  | (0.3) |  |  |  | — |  |  | 3.1 |  |  |
| Amortization of acquired intangibles | 15.8 |  |  | 15.0 |  |  | 13.9 |  |  |  | 45.8 |  |  | 38.8 |  |  |
| Amortization of inventory fair value adjustments | — |  |  | — |  |  | 1.5 |  |  |  | — |  |  | 5.8 |  |  |
| Other charges (2) | 3.1 |  |  | 6.4 |  |  | 4.0 |  |  |  | 20.0 |  |  | 25.5 |  |  |
| Gross profit on non-GAAP basis | $ | 209.2 |  |  | $ | 255.9 |  |  | $ | 183.4 |  |  |  | $ | 700.3 |  |  | $ | 606.3 |  |  |
| Gross margin on non-GAAP basis | 49.9 | % |  | 53.4 | % |  | 45.5 | % |  |  | 51.8 | % |  | 46.3 | % |  |
| Research and development on GAAP basis | $ | 57.2 |  |  | $ | 52.8 |  |  | $ | 48.7 |  |  |  | $ | 160.4 |  |  | $ | 149.6 |  |  |
| Stock-based compensation | (5.3) |  |  | (5.1) |  |  | (4.2) |  |  |  | (14.8) |  |  | (12.1) |  |  |
| Other charges | (0.6) |  |  | 0.1 |  |  | (0.2) |  |  |  | (0.6) |  |  | (0.1) |  |  |
| Research and development on non-GAAP basis | $ | 51.3 |  |  | $ | 47.8 |  |  | $ | 44.3 |  |  |  | $ | 145.0 |  |  | $ | 137.4 |  |  |
| Selling, general and administrative on GAAP basis | $ | 65.5 |  |  | $ | 61.3 |  |  | $ | 61.3 |  |  |  | $ | 183.1 |  |  | $ | 180.4 |  |  |
| Stock-based compensation | (14.5) |  |  | (14.2) |  |  | (10.7) |  |  |  | (40.1) |  |  | (31.4) |  |  |
| Integration related costs | (0.2) |  |  | (0.2) |  |  | (5.0) |  |  |  | (0.7) |  |  | (11.1) |  |  |
| Amortization of acquired intangibles | (6.2) |  |  | (5.9) |  |  | (6.1) |  |  |  | (17.8) |  |  | (18.6) |  |  |
| Other charges | (3.8) |  |  | (2.8) |  |  | (1.1) |  |  |  | (8.7) |  |  | (5.8) |  |  |
| Selling, general and administrative on non-GAAP basis | $ | 40.8 |  |  | $ | 38.2 |  |  | $ | 38.4 |  |  |  | $ | 115.8 |  |  | $ | 113.5 |  |  |
| Income from operations on GAAP basis | $ | 266.9 |  |  | $ | 115.3 |  |  | $ | 42.5 |  |  |  | $ | 481.2 |  |  | $ | 177.1 |  |  |
| Stock-based compensation | 25.1 |  |  | 24.1 |  |  | 19.2 |  |  |  | 68.7 |  |  | 56.1 |  |  |
| Inventory and fixed asset write down due to product line exits (1) | — |  |  | 0.1 |  |  | 2.3 |  |  |  | 0.4 |  |  | 6.0 |  |  |
| Integration related costs | 0.2 |  |  | 0.2 |  |  | 4.7 |  |  |  | 0.7 |  |  | 14.2 |  |  |
| Amortization of acquired intangibles | 22.0 |  |  | 20.9 |  |  | 20.0 |  |  |  | 63.6 |  |  | 57.4 |  |  |
| Amortization of inventory fair value adjustments | — |  |  | — |  |  | 1.5 |  |  |  | — |  |  | 5.8 |  |  |
| Restructuring and related charges | 2.9 |  |  | 0.2 |  |  | 2.7 |  |  |  | 3.1 |  |  | 4.9 |  |  |
| Merger termination fee and related costs, net (3) | (207.5) |  |  | — |  |  | — |  |  |  | (207.5) |  |  | — |  |  |
| Impairment charges (4) | — |  |  | — |  |  | 2.5 |  |  |  | — |  |  | 2.5 |  |  |
| Other charges | 7.5 |  |  | 9.1 |  |  | 5.3 |  |  |  | 29.3 |  |  | 31.4 |  |  |
| Income from operations on non-GAAP basis | $ | 117.1 |  |  | $ | 169.9 |  |  | $ | 100.7 |  |  |  | $ | 439.5 |  |  | $ | 355.4 |  |  |
| Operating margin on non-GAAP basis | 27.9 | % |  | 35.5 | % |  | 25.0 | % |  |  | 32.5 | % |  | 27.1 | % |  |
| Interest and other income (expense), net on GAAP basis | $ | (14.0) |  |  | $ | (17.2) |  |  | $ | 6.1 |  |  |  | $ | (46.6) |  |  | $ | (17.4) |  |  |

[0001633978-21-000008:8k_2_02:54]
| Other (income) expense adjustments | — |  |  | — |  |  | (2.0) |  |  |  | — |  |  | (2.0) |  |  |
| Gain on sale of product lines | — |  |  | (0.1) |  |  | (13.8) |  |  |  | (0.5) |  |  | (13.8) |  |  |
| Foreign exchange (gains) losses, net | (1.3) |  |  | 2.8 |  |  | (0.7) |  |  |  | 3.8 |  |  | 0.3 |  |  |
| Non-cash interest expense on convertible notes and term loan | 14.8 |  |  | 14.7 |  |  | 14.0 |  |  |  | 43.9 |  |  | 33.3 |  |  |
| Interest and other income (expense), net on non-GAAP basis | $ | (0.5) |  |  | $ | 0.2 |  |  | $ | 3.6 |  |  |  | $ | 0.6 |  |  | $ | 0.4 |  |  |
| Income before income taxes on GAAP basis | $ | 252.9 |  |  | $ | 98.1 |  |  | $ | 48.6 |  |  |  | $ | 434.6 |  |  | $ | 159.7 |  |  |
| Stock-based compensation | 25.1 |  |  | 24.1 |  |  | 19.2 |  |  |  | 68.7 |  |  | 56.1 |  |  |
| Inventory and fixed asset write down due to product line exits (1) | — |  |  | 0.1 |  |  | 2.3 |  |  |  | 0.4 |  |  | 6.0 |  |  |
| Integration related costs | 0.2 |  |  | 0.2 |  |  | 4.7 |  |  |  | 0.7 |  |  | 14.2 |  |  |
| Amortization of acquired intangibles | 22.0 |  |  | 20.9 |  |  | 20.0 |  |  |  | 63.6 |  |  | 57.4 |  |  |
| Amortization of inventory fair value adjustments | — |  |  | — |  |  | 1.5 |  |  |  | — |  |  | 5.8 |  |  |
| Restructuring and related charges | 2.9 |  |  | 0.2 |  |  | 2.7 |  |  |  | 3.1 |  |  | 4.9 |  |  |
| Merger termination fee and related costs, net (3) | (207.5) |  |  | — |  |  | — |  |  |  | (207.5) |  |  | — |  |  |
| Impairment charges (4) | — |  |  | — |  |  | 2.5 |  |  |  | — |  |  | 2.5 |  |  |
| Other (income) expense adjustments | — |  |  | — |  |  | (2.0) |  |  |  | — |  |  | (2.0) |  |  |
| Gain on sale of product lines | — |  |  | (0.1) |  |  | (13.8) |  |  |  | (0.5) |  |  | (13.8) |  |  |
| Foreign exchange (gains) losses, net | (1.3) |  |  | 2.8 |  |  | (0.7) |  |  |  | 3.8 |  |  | 0.3 |  |  |
| Non-cash interest expense on convertible notes and term loan | 14.8 |  |  | 14.7 |  |  | 14.0 |  |  |  | 43.9 |  |  | 33.3 |  |  |
| Other charges | 7.5 |  |  | 9.1 |  |  | 5.3 |  |  |  | 29.3 |  |  | 31.4 |  |  |
| Income before income taxes on non-GAAP basis | $ | 116.6 |  |  | $ | 170.1 |  |  | $ | 104.3 |  |  |  | $ | 440.1 |  |  | $ | 355.8 |  |  |
| Provision for income taxes on GAAP basis | $ | 27.4 |  |  | $ | 14.9 |  |  | $ | 5.2 |  |  |  | $ | 58.8 |  |  | $ | 19.6 |  |  |
| Income tax adjustments | (21.4) |  |  | (0.5) |  |  | 1.1 |  |  |  | (24.2) |  |  | 7.4 |  |  |
| Provision for income taxes on non-GAAP basis | $ | 6.0 |  |  | $ | 14.4 |  |  | $ | 6.3 |  |  |  | $ | 34.6 |  |  | $ | 27.0 |  |  |
| Net income on GAAP basis | $ | 225.5 |  |  | $ | 83.2 |  |  | $ | 43.4 |  |  |  | $ | 375.8 |  |  | $ | 140.1 |  |  |
| Stock-based compensation | 25.1 |  |  | 24.1 |  |  | 19.2 |  |  |  | 68.7 |  |  | 56.1 |  |  |
| Inventory and fixed asset write down due to product line exits (1) | — |  |  | 0.1 |  |  | 2.3 |  |  |  | 0.4 |  |  | 6.0 |  |  |
| Acquisition related costs | — |  |  | 1.1 |  |  | — |  |  |  | — |  |  | — |  |  |
| Integration related costs | 0.2 |  |  | 0.2 |  |  | 4.7 |  |  |  | 0.7 |  |  | 14.2 |  |  |
| Amortization of acquired intangibles | 22.0 |  |  | 20.9 |  |  | 20.0 |  |  |  | 63.6 |  |  | 57.4 |  |  |
| Amortization of inventory fair value adjustments | — |  |  | — |  |  | 1.5 |  |  |  | — |  |  | 5.8 |  |  |
| Restructuring and related charges | 2.9 |  |  | 0.2 |  |  | 2.7 |  |  |  | 3.1 |  |  | 4.9 |  |  |
| Merger termination fee and related costs, net (3) | (207.5) |  |  | — |  |  | — |  |  |  | (207.5) |  |  | — |  |  |
| Impairment charges (4) | — |  |  | — |  |  | 2.5 |  |  |  | — |  |  | 2.5 |  |  |
| Other (income) expense adjustments | — |  |  | — |  |  | (2.0) |  |  |  | — |  |  | (2.0) |  |  |
| Gain on sale of product lines | — |  |  | (0.1) |  |  | (13.8) |  |  |  | (0.5) |  |  | (13.8) |  |  |
| Foreign exchange (gains) losses, net | (1.3) |  |  | 2.8 |  |  | (0.7) |  |  |  | 3.8 |  |  | 0.3 |  |  |
| Non-cash interest expense on convertible notes and term loan | 14.8 |  |  | 14.7 |  |  | 14.0 |  |  |  | 43.9 |  |  | 33.3 |  |  |
| Income tax adjustments | 21.4 |  |  | 0.5 |  |  | (1.1) |  |  |  | 24.2 |  |  | (7.4) |  |  |
| Other charges | 7.5 |  |  | 8.0 |  |  | 5.3 |  |  |  | 29.3 |  |  | 31.4 |  |  |

[0001633978-21-000008:8k_2_02:55]
| Net income on non-GAAP basis | $ | 110.6 |  |  | $ | 155.7 |  |  | $ | 98.0 |  |  |  | $ | 405.5 |  |  | $ | 328.8 |  |  |
| Net income per share on non-GAAP basis | $ | 1.40 |  |  | $ | 1.99 |  |  | $ | 1.26 |  |  |  | $ | 5.16 |  |  | $ | 4.23 |  |  |
| Shares used in per share calculation - diluted on GAAP and non-GAAP basis | 79.2 |  |  | 78.4 |  |  | 77.5 |  |  |  | 78.6 |  |  | 77.7 |  |  |

[0001633978-21-000008:8k_2_02:56]
(1) For the three months ended December 26, 2020 and March 28, 2020, we recorded inventory and fixed asset write down charges of $0.1 million and $2.3 million, respectively, related to the decision to exit the Datacom module and Lithium Niobate product lines. For the nine months ended April 3, 2021 and March 28, 2020, we recorded inventory and fixed asset write down charges of $0.4 million and $6.0 million, respectively, related to the decision to exit the Datacom module and Lithium Niobate product lines.

[0001633978-21-000008:8k_2_02:57]
(2) Other charges excluded from gross profit on non-GAAP basis for the three and nine months ended April 3, 2021 include costs of transferring product lines to new production facilities, including Thailand of $1.4 million and $6.5 million, respectively. We also incurred excess and obsolete inventory charges driven by U.S. trade restrictions and the related decline in demand from Huawei of $1.0 million and $7.7 million during the three and nine months ended April 3, 2021, respectively. Our excess and obsolete inventory charges related to Huawei were offset by $2.1 million of sale of inventory previously written down during the three and nine months ended April 3, 2021. During the nine months ended April 3, 2021, there was also a $5.0 million impairment charge associated with excess capacity related to our Fiber laser business.

[0001633978-21-000008:8k_2_02:58]
Other charges excluded from gross profit on non-GAAP basis for the three months ended December 26, 2020 include costs of transferring product lines to new production facilities, including Thailand of $0.4 million, excess and obsolete inventory charges driven by U.S. trade restrictions and the related decline in demand from Huawei of $0.8 million, and impairment charges associated with excess capacity related to our Fiber laser business of $4.6 million.

[0001633978-21-000008:8k_2_02:59]
(3) For each of the three and nine months ended April 3, 2021, we recorded $217.6 million gain related to the receipt of a termination fee from Coherent in March 2021 as a result of the termination of our merger agreement. This gain was offset by $10.1 million of Coherent acquisition related charges.

[0001633978-21-000008:8k_2_02:60]
(4) For each of the three and nine months ended March 28, 2020, we recorded impairment charges of $2.5 million of property, plant and equipment related to the decision to exit the Datacom module product line.

[0001633978-21-000008:8k_2_02:61]
LUMENTUM HOLDINGS INC.

[0001633978-21-000008:8k_2_02:62]
RECONCILIATION OF GAAP NET INCOME TO ADJUSTED EBITDA

[0001633978-21-000008:8k_2_02:63]
(in millions, except per share data)

[0001633978-21-000008:8k_2_02:64]
(unaudited)

[0001633978-21-000008:8k_2_02:65]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 3, 2021 |  |  |  | December 26, 2020 |  | March 28, 2020 |  | April 3, 2021 |  | March 28, 2020 |
| GAAP Net income | $ | 225.5 |  |  |  |  | $ | 83.2 |  |  | $ | 43.4 |  |  | $ | 375.8 |  |  | $ | 140.1 |  |
| Interest and other expense (income), net | 14.0 |  |  |  |  | 17.2 |  |  | (6.1) |  |  | 46.6 |  |  | 17.4 |  |
| Provision for income taxes | 27.4 |  |  |  |  | 14.9 |  |  | 5.2 |  |  | 58.8 |  |  | 19.6 |  |
| Depreciation | 22.8 |  |  |  |  | 23.8 |  |  | 27.5 |  |  | 70.4 |  |  | 87.8 |  |
| Amortization of acquired intangibles | 22.0 |  |  |  |  | 20.9 |  |  | 20.0 |  |  | 63.6 |  |  | 57.4 |  |
| EBITDA | 311.7 |  |  |  |  | 160.0 |  |  | 90.0 |  |  | 615.2 |  |  | 322.3 |  |
| Amortization of inventory fair value adjustments | — |  |  |  |  | — |  |  | 1.5 |  |  | — |  |  | 5.8 |  |
| Restructuring and related charges | 2.9 |  |  |  |  | 0.2 |  |  | 2.7 |  |  | 3.1 |  |  | 4.9 |  |
| Stock-based compensation | 25.1 |  |  |  |  | 24.1 |  |  | 19.2 |  |  | 68.7 |  |  | 56.1 |  |
| Inventory and fixed asset write down due to product line exits | — |  |  |  |  | 0.1 |  |  | 2.3 |  |  | 0.4 |  |  | 6.0 |  |
| Integration related costs | 0.2 |  |  |  |  | 0.2 |  |  | 4.7 |  |  | 0.7 |  |  | 14.2 |  |
| Merger termination fee and related costs, net | (207.5) |  |  |  |  | — |  |  | — |  |  | (207.5) |  |  | — |  |
| Impairment charges | — |  |  |  |  | — |  |  | 2.5 |  |  | — |  |  | 2.5 |  |
| Other charges | 7.5 |  |  |  |  | 9.1 |  |  | 5.3 |  |  | 29.3 |  |  | 31.4 |  |
| Adjusted EBITDA | $ | 139.9 |  |  |  |  | $ | 193.7 |  |  | $ | 128.2 |  |  | $ | 509.9 |  |  | $ | 443.2 |  |
