# LITE note change history — 0001633978-21-000004 → 0001633978-21-000009


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-05-12):
[0001633978-21-000009:note_history:1]
Purchase obligations of $224.9 million as of April 3, 2021, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements.
  (was, 2021-02-02, similarity 0.9684):
[0001633978-21-000004:note_history:1]
Purchase obligations of $219.8 million as of December 26, 2020, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements.

- added (2021-05-12):
[0001633978-21-000009:note_history:2]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with such vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

- changed (2021-05-12):
[0001633978-21-000009:note_history:3]
The following table presents the changes in our warranty reserve during the three and nine months ended April 3, 2021 and March 28, 2020 (in millions):
  (was, 2021-02-02, similarity 0.9135):
[0001633978-21-000004:note_history:3]
The following table presents the changes in our warranty reserve during the three and six months ended December 26, 2020 and December 28, 2019 (in millions):

- added (2021-05-12):
[0001633978-21-000009:note_history:4]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 3, 2021 |  | March 28, 2020 |  | April 3, 2021 |  | March 28, 2020 |
| Balance as of beginning of period | $ | 5.7 |  |  | $ | 6.8 |  |  | $ | 5.0 |  |  | $ | 7.5 |  |
| Provision for warranty | 1.7 |  |  | 0.7 |  |  | 5.8 |  |  | 2.5 |  |
| Utilization of reserve | (1.8) |  |  | (2.1) |  |  | (5.2) |  |  | (4.6) |  |
| Balance as of end of period | $ | 5.6 |  |  | $ | 5.4 |  |  | $ | 5.6 |  |  | $ | 5.4 |  |

- changed (2021-05-12):
[0001633978-21-000009:note_history:5]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of April 3, 2021, we did not have any material indemnification claims that were probable or reasonably possible.
  (was, 2021-02-02, similarity 0.796):
[0001633978-21-000004:note_history:5]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of December 26, 2020, we did not have any material indemnification claims that were probable or reasonably possible.

- removed (2021-05-12):
[0001633978-21-000004:note_history:6]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-

- removed (2021-05-12):
[0001633978-21-000004:note_history:7]
year supply agreements and have no significant long-term guaranteed supply agreements with such vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

- removed (2021-05-12):
[0001633978-21-000004:note_history:8]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26, 2020 |  | December 28, 2019 |  | December 26, 2020 |  | December 28, 2019 |
| Balance as of beginning of period | $ | 7.6 |  |  | $ | 7.0 |  |  | $ | 5.0 |  |  | $ | 7.5 |  |
| Provision for warranty | 0.2 |  |  | 0.6 |  |  | 4.1 |  |  | 1.8 |  |
| Utilization of reserve | (2.1) |  |  | (0.8) |  |  | (3.4) |  |  | (2.5) |  |
| Balance as of end of period | $ | 5.7 |  |  | $ | 6.8 |  |  | $ | 5.7 |  |  | $ | 6.8 |  |


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2021-05-12):
[0001633978-21-000009:note_history:9]
Termination of Coherent Merger Agreement

- added (2021-05-12):
[0001633978-21-000009:note_history:10]
On January 18, 2021, Lumentum and Coherent, Inc. (“Coherent”) entered into a merger agreement (the “merger agreement”), under which Lumentum would acquire all outstanding shares of Coherent common stock. As of the date of the merger agreement, the total transaction consideration was approximately $5.7 billion. In March 2021, Coherent terminated the merger agreement and paid Lumentum a termination fee of $217.6 million in accordance with the merger agreement. This gain was offset by $10.1 million of acquisition related expenses and the net amount is presented as “merger termination fee and related costs, net” in our condensed consolidated statements of operations for the three and nine months ended April 3, 2021.

- changed (2021-05-12):
[0001633978-21-000009:note_history:11]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2021 is a 53-week year ending on July 3, 2021, with the quarter ended April 3, 2021 being a 14-week quarterly period. Our fiscal 2020 was a 52-week year that ended on June 27, 2020, with the quarter ended March 28, 2020 being a 13-week quarterly period.
  (was, 2021-02-02, similarity 0.9038):
[0001633978-21-000004:note_history:11]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2021 is a 53-week year ending on July 3, 2021, with the quarter ended December 26, 2020 being a 13-week quarterly period and our third quarter ending on April 3, 2021 being a 14-week quarterly period. Our fiscal 2020 was a 52-week year that ended on June 27, 2020, with the quarter ended December 28, 2019 being a 13-week quarterly period.

- changed (2021-05-12):
[0001633978-21-000009:note_history:12]
These interim unaudited condensed consolidated financial statements include the accounts of the Company and its wholly-owned subsidiaries. All inter-company transactions and balances have been eliminated in consolidation. 
Accounting PoliciesThe accompanying condensed consolidated financial statements and accompanying related notes should be read in conjunction with the audited consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended June 27, 2020. There have been no significant changes to these policies during the nine months ended April 3, 2021, except for the removal of the long-lived asset valuation policy and the updates resulting from the adoption of Topic 326, as discussed in “Note 2. Recently Issued Accounting Pronouncements”.
  (was, 2021-02-02, similarity 0.7733):
[0001633978-21-000004:note_history:12]
Accounting Policies
The accompanying condensed consolidated financial statements and accompanying related notes should be read in conjunction with the audited consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended June 27, 2020. There have been no significant changes to these policies during the six months ended December 26, 2020, except for the removal of the long-lived asset valuation policy and the updates resulting from the adoption of Topic 326, as discussed in “Note 2. Recently Issued Accounting Pronouncements”.

- removed (2021-05-12):
[0001633978-21-000004:note_history:13]
These interim unaudited condensed consolidated financial statements include the accounts of the Company and its wholly-owned subsidiaries. All inter-company transactions and balances have been eliminated in consolidation.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2021-05-12):
[0001633978-21-000009:note_history:14]
| Liability component: | April 3, 2021 |  | June 27, 2020 |
|  | 2024 Notes (1) |  | 2026 Notes |  | 2024 Notes (1) |  | 2026 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 450.0 |  |  | $ | 1,050.0 |  |
| Unamortized debt discount and debt issuance costs | (64.7) |  |  | (271.1) |  |  | (79.4) |  |  | (300.3) |  |
| Net carrying amount of the liability component | $ | 385.3 |  |  | $ | 778.9 |  |  | $ | 370.6 |  |  | $ | 749.7 |  |

- changed (2021-05-12):
[0001633978-21-000009:note_history:15]
(1) Since the closing price of our stock exceeded $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of the third quarter of fiscal 2021, the 2024 Notes have become convertible at the option of the holders. Therefore, the debt component of our 2024 Notes as of April 3, 2021 has been classified as current liabilities in our condensed consolidated balance sheet.
  (was, 2021-02-02, similarity 0.9017):
[0001633978-21-000004:note_history:15]
(1) Since the closing price of our stock exceeded $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of the second quarter of fiscal 2021, the 2024 Notes have become convertible at the option of the holders. Therefore, the debt component of our 2024 Notes as of December 26, 2020 was reclassified to current liabilities in our condensed consolidated balance sheet.

- removed (2021-05-12):
[0001633978-21-000004:note_history:16]
| Liability component: | December 26, 2020 |  | June 27, 2020 |
|  | 2024 Notes (1) |  | 2026 Notes |  | 2024 Notes (1) |  | 2026 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 450.0 |  |  | $ | 1,050.0 |  |
| Unamortized debt discount and debt issuance costs | (69.7) |  |  | (280.9) |  |  | (79.4) |  |  | (300.3) |  |
| Net carrying amount of the liability component | $ | 380.3 |  |  | $ | 769.1 |  |  | $ | 370.6 |  |  | $ | 749.7 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2021-05-12):
[0001633978-21-000009:note_history:17]
| Liability component: | April 3, 2021 |  | June 27, 2020 |
|  | 2024 Notes (1) |  | 2026 Notes |  | 2024 Notes (1) |  | 2026 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 450.0 |  |  | $ | 1,050.0 |  |
| Unamortized debt discount and debt issuance costs | (64.7) |  |  | (271.1) |  |  | (79.4) |  |  | (300.3) |  |
| Net carrying amount of the liability component | $ | 385.3 |  |  | $ | 778.9 |  |  | $ | 370.6 |  |  | $ | 749.7 |  |

- changed (2021-05-12):
[0001633978-21-000009:note_history:18]
(1) Since the closing price of our stock exceeded $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of the third quarter of fiscal 2021, the 2024 Notes have become convertible at the option of the holders. Therefore, the debt component of our 2024 Notes as of April 3, 2021 has been classified as current liabilities in our condensed consolidated balance sheet.
  (was, 2021-02-02, similarity 0.9017):
[0001633978-21-000004:note_history:18]
(1) Since the closing price of our stock exceeded $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of the second quarter of fiscal 2021, the 2024 Notes have become convertible at the option of the holders. Therefore, the debt component of our 2024 Notes as of December 26, 2020 was reclassified to current liabilities in our condensed consolidated balance sheet.

- changed (2021-05-12):
[0001633978-21-000009:note_history:19]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 3, 2021 |  | March 28, 2020 |  | April 3, 2021 |  | March 28, 2020 |
| Contractual interest expense | $ | 1.6 |  |  | $ | 1.6 |  |  | $ | 4.8 |  |  | $ | 2.3 |  |
| Amortization of the debt discount and debt issuance costs | 14.8 |  |  | 14.0 |  |  | 43.9 |  |  | 24.8 |  |
| Total interest expense | $ | 16.4 |  |  | $ | 15.6 |  |  | $ | 48.7 |  |  | $ | 27.1 |  |
  (was, 2021-02-02, similarity 0.8402):
[0001633978-21-000004:note_history:19]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26, 2020 |  | December 28, 2019 |  | December 26, 2020 |  | December 28, 2019 |
| Contractual interest expense | $ | 1.6 |  |  | $ | 0.5 |  |  | $ | 3.2 |  |  | $ | 0.7 |  |
| Amortization of the debt discount and debt issuance costs | 14.7 |  |  | 6.2 |  |  | 29.1 |  |  | 10.8 |  |
| Total interest expense | $ | 16.3 |  |  | $ | 6.7 |  |  | $ | 32.3 |  |  | $ | 11.5 |  |

- changed (2021-05-12):
[0001633978-21-000009:note_history:20]
The future interest and principal payments related to our convertible notes are as follows as of April 3, 2021 (in millions):
  (was, 2021-02-02, similarity 0.9551):
[0001633978-21-000004:note_history:20]
The future interest and principal payments related to our convertible notes are as follows as of December 26, 2020 (in millions):

- changed (2021-05-12):
[0001633978-21-000009:note_history:21]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | Total |
| Remainder of 2021 | $ | — |  |  | $ | 2.6 |  |  | $ | 2.6 |  |
| 2022 | 1.1 |  |  | 5.3 |  |  | 6.4 |  |
| 2023 | 1.1 |  |  | 5.3 |  |  | 6.4 |  |
| 2024 | 451.2 |  |  | 5.3 |  |  | 456.5 |  |
| 2025 | — |  |  | 5.3 |  |  | 5.3 |  |
| Thereafter | — |  |  | 1,057.7 |  |  | 1,057.7 |  |
| Total convertible notes payments | $ | 453.4 |  |  | $ | 1,081.5 |  |  | $ | 1,534.9 |  |
  (was, 2021-02-02, similarity 0.9969):
[0001633978-21-000004:note_history:21]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | Total |
| Remainder of 2021 | $ | 0.6 |  |  | $ | 2.6 |  |  | $ | 3.2 |  |
| 2022 | 1.1 |  |  | 5.3 |  |  | 6.4 |  |
| 2023 | 1.1 |  |  | 5.3 |  |  | 6.4 |  |
| 2024 | 451.1 |  |  | 5.3 |  |  | 456.4 |  |
| 2025 | — |  |  | 5.3 |  |  | 5.3 |  |
| Thereafter | — |  |  | 1,057.7 |  |  | 1,057.7 |  |
| Total convertible notes payments | $ | 453.9 |  |  | $ | 1,081.5 |  |  | $ | 1,535.4 |  |

- changed (2021-05-12):
[0001633978-21-000009:note_history:22]
The principal balances of our Notes are reflected in the payment periods in the table above based on their respective contractual maturities. During the three and nine months ended April 3, 2021, we received conversion requests for less than $0.1 million principal amount of the 2024 Notes, which will be settled in cash in the fourth quarter of fiscal 2021.
  (was, 2021-02-02, similarity 0.626):
[0001633978-21-000004:note_history:22]
The principal balances of our Notes are reflected in the payment periods in the table above based on their respective contractual maturities assuming no conversion.

- changed (2021-05-12):
[0001633978-21-000009:note_history:23]
In December 2018, concurrent with the closing of the Oclaro merger, we entered into a credit agreement providing for a term loan facility (the “Term Loan Facility”) in an aggregate principal amount of $500.0 million and we drew in full the term loans available under the Term Loan Facility on the closing date of the Oclaro merger. In the second quarter of fiscal 2020, we repaid, in full, all amounts outstanding under our Term Loan Facility. During the nine months ended March 28, 2020, we incurred $18.1 million of interest expense on this Term Loan Facility, which includes an $8.0 million loss on the early extinguishment of debt.
  (was, 2021-02-02, similarity 0.9137):
[0001633978-21-000004:note_history:23]
In December 2018, concurrent with the closing of the Oclaro merger, we entered into a credit agreement providing for a term loan facility (the “Term Loan Facility”) in an aggregate principal amount of $500.0 million and we drew in full the term loans available under the Term Loan Facility on the closing date of the Oclaro merger. In the second quarter of fiscal 2020, we repaid, in full, all amounts outstanding under our Term Loan Facility. During the three and six months ended December 28, 2019, we incurred $11.6 million and $18.1 million of interest expense on this Term Loan Facility, which includes $8.0 million loss on early extinguishment of debt for each period, respectively.

- added (2021-05-12):
[0001633978-21-000009:note_history:24]
Other Interest Expense

- added (2021-05-12):
[0001633978-21-000009:note_history:25]
For the nine months ended March 28, 2020, we also recorded $0.1 million interest expense related to our finance leases.

- removed (2021-05-12):
[0001633978-21-000004:note_history:26]
| Liability component: | December 26, 2020 |  | June 27, 2020 |
|  | 2024 Notes (1) |  | 2026 Notes |  | 2024 Notes (1) |  | 2026 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 450.0 |  |  | $ | 1,050.0 |  |
| Unamortized debt discount and debt issuance costs | (69.7) |  |  | (280.9) |  |  | (79.4) |  |  | (300.3) |  |
| Net carrying amount of the liability component | $ | 380.3 |  |  | $ | 769.1 |  |  | $ | 370.6 |  |  | $ | 749.7 |  |


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-05-12):
[0001633978-21-000009:note_history:27]
|  | Less than 12 months |  |  |  |  |
|  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |
| April 3, 2021: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 34.4 |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | 4.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 129.5 |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 310.4 |  |  | (0.3) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 47.9 |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | 526.2 |  |  | $ | (0.3) |  |  |  |  |  |  |  |  |  |
| June 27, 2020: |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 3.1 |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 51.1 |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 96.5 |  |  | (0.1) |  |  |  |  |  |  |  |  |  |
| Foreign government bonds | 1.7 |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | 47.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 159.8 |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | 359.2 |  |  | $ | (0.1) |  |  |  |  |  |  |  |  |  |
  (was, 2021-02-02, similarity 0.9595):
[0001633978-21-000004:note_history:27]
|  | Less than 12 months |  |  |  |  |
|  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |
| December 26, 2020: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 36.6 |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 72.6 |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 246.1 |  |  | (0.2) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 151.8 |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | 507.1 |  |  | $ | (0.2) |  |  |  |  |  |  |  |  |  |
| June 27, 2020: |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 3.1 |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 51.1 |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 96.5 |  |  | (0.1) |  |  |  |  |  |  |  |  |  |
| Foreign government bonds | 1.7 |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | 47.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 159.8 |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | 359.2 |  |  | $ | (0.1) |  |  |  |  |  |  |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-05-12):
[0001633978-21-000009:note_history:28]
The future interest and principal payments related to our convertible notes are as follows as of April 3, 2021 (in millions):
  (was, 2021-02-02, similarity 0.9551):
[0001633978-21-000004:note_history:28]
The future interest and principal payments related to our convertible notes are as follows as of December 26, 2020 (in millions):

- changed (2021-05-12):
[0001633978-21-000009:note_history:29]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | Total |
| Remainder of 2021 | $ | — |  |  | $ | 2.6 |  |  | $ | 2.6 |  |
| 2022 | 1.1 |  |  | 5.3 |  |  | 6.4 |  |
| 2023 | 1.1 |  |  | 5.3 |  |  | 6.4 |  |
| 2024 | 451.2 |  |  | 5.3 |  |  | 456.5 |  |
| 2025 | — |  |  | 5.3 |  |  | 5.3 |  |
| Thereafter | — |  |  | 1,057.7 |  |  | 1,057.7 |  |
| Total convertible notes payments | $ | 453.4 |  |  | $ | 1,081.5 |  |  | $ | 1,534.9 |  |
  (was, 2021-02-02, similarity 0.9969):
[0001633978-21-000004:note_history:29]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | Total |
| Remainder of 2021 | $ | 0.6 |  |  | $ | 2.6 |  |  | $ | 3.2 |  |
| 2022 | 1.1 |  |  | 5.3 |  |  | 6.4 |  |
| 2023 | 1.1 |  |  | 5.3 |  |  | 6.4 |  |
| 2024 | 451.1 |  |  | 5.3 |  |  | 456.4 |  |
| 2025 | — |  |  | 5.3 |  |  | 5.3 |  |
| Thereafter | — |  |  | 1,057.7 |  |  | 1,057.7 |  |
| Total convertible notes payments | $ | 453.9 |  |  | $ | 1,081.5 |  |  | $ | 1,535.4 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2021-05-12):
[0001633978-21-000009:note_history:30]
Subsequent EventOn May 7, 2021, our board of directors approved the 2021 share buyback program, which authorizes us to use up to $700 million to purchase our own shares of common stock. The repurchase program is authorized for 2 years but may be suspended or terminated by the board of directors at any time.

- removed (2021-05-12):
[0001633978-21-000004:note_history:31]
Subsequent Event
On January 18, 2021, Lumentum and Coherent, Inc. (“Coherent”) entered into a merger agreement (the “Merger Agreement”), under which Lumentum will acquire all outstanding shares of Coherent common stock. Each share of Coherent common stock will be exchanged for $100 in cash and 1.1851 shares of Lumentum common stock, subject to the terms of the Merger Agreement. As of the date of the Merger Agreement, the total transaction consideration is approximately $5.7 billion. Coherent stockholders will own approximately 27% of the combined company at closing.

- removed (2021-05-12):
[0001633978-21-000004:note_history:32]
The Merger Agreement contains certain termination rights for both Lumentum and Coherent and provides that upon termination of the Merger Agreement under specified circumstances (including termination by Coherent to accept a superior proposal), Coherent may be required to pay Lumentum a termination fee of $217.6 million. The Merger Agreement further provides that upon termination of the Merger Agreement under specified circumstances (including termination by Lumentum to accept a superior proposal), Lumentum may be required to pay Coherent a termination fee of $337.7 million, and if the Merger Agreement is terminated for failure to obtain antitrust approval from a Chinese governmental entity, Lumentum may be required to pay Coherent a termination fee of $279.0 million.

- removed (2021-05-12):
[0001633978-21-000004:note_history:33]
The total transaction consideration will be funded by a combination of approximately $3.2 billion in Lumentum common stock (based on the closing price of Lumentum common stock on the date preceding the Merger Agreement), $2.1 billion in new debt, and the remaining amount from the cash balances of the combined company. Lumentum entered into a commitment letter with Deutsche Bank Securities Inc. and Deutsche Bank AG New York Branch (collectively, “Deutsche Bank”), pursuant to which, subject to the terms and conditions set forth therein, Deutsche Bank has committed to provide a senior secured term loan facility in an aggregate principal amount of up to $2.1 billion.

- removed (2021-05-12):
[0001633978-21-000004:note_history:34]
The Boards of Directors of Lumentum and Coherent have unanimously approved the transaction and the Merger Agreement. The transaction is subject to customary closing conditions, including the absence of certain legal impediments, the expiration or termination of the required waiting periods under the Hart-Scott-Rodino Antitrust Improvements Act of 1976, as amended, antitrust approvals in other applicable jurisdictions, including China and South Korea, the effectiveness of a registration statement on Form S-4 registering the shares of Lumentum common stock to be issued in connection with the transaction, and approval by the holders of a majority of the outstanding shares of Lumentum common stock and Coherent common stock. The transaction is not subject to any financing condition. The transaction is expected to be completed in the second half of calendar 2021.
