# LITE notes — 0001633978-21-000009


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001633978-21-000009:notes:1]
[same as prior period, unchanged from 0001633978-21-000004:notes:1]

[0001633978-21-000009:notes:2]
[same as prior period, unchanged from 0001633978-21-000004:notes:2]

[0001633978-21-000009:notes:3]
[same as prior period, unchanged from 0001633978-21-000004:notes:3]

[0001633978-21-000009:notes:4]
[same as prior period, unchanged from 0001633978-21-000004:notes:4]

[0001633978-21-000009:notes:5]
[same as prior period, unchanged from 0001633978-21-000004:notes:5]

[0001633978-21-000009:notes:6]
[same as prior period, unchanged from 0001633978-21-000004:notes:6]

[0001633978-21-000009:notes:7]
Termination of Coherent Merger Agreement

[0001633978-21-000009:notes:8]
On January 18, 2021, Lumentum and Coherent, Inc. (“Coherent”) entered into a merger agreement (the “merger agreement”), under which Lumentum would acquire all outstanding shares of Coherent common stock. As of the date of the merger agreement, the total transaction consideration was approximately $5.7 billion. In March 2021, Coherent terminated the merger agreement and paid Lumentum a termination fee of $217.6 million in accordance with the merger agreement. This gain was offset by $10.1 million of acquisition related expenses and the net amount is presented as “merger termination fee and related costs, net” in our condensed consolidated statements of operations for the three and nine months ended April 3, 2021.

[0001633978-21-000009:notes:9]
[same as prior period, unchanged from 0001633978-21-000004:notes:7]

[0001633978-21-000009:notes:10]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2021 is a 53-week year ending on July 3, 2021, with the quarter ended April 3, 2021 being a 14-week quarterly period. Our fiscal 2020 was a 52-week year that ended on June 27, 2020, with the quarter ended March 28, 2020 being a 13-week quarterly period.

[0001633978-21-000009:notes:11]
[same as prior period, unchanged from 0001633978-21-000004:notes:9]

[0001633978-21-000009:notes:12]
These interim unaudited condensed consolidated financial statements include the accounts of the Company and its wholly-owned subsidiaries. All inter-company transactions and balances have been eliminated in consolidation. 
Accounting PoliciesThe accompanying condensed consolidated financial statements and accompanying related notes should be read in conjunction with the audited consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended June 27, 2020. There have been no significant changes to these policies during the nine months ended April 3, 2021, except for the removal of the long-lived asset valuation policy and the updates resulting from the adoption of Topic 326, as discussed in “Note 2. Recently Issued Accounting Pronouncements”.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001633978-21-000009:notes:13]
Accounting PoliciesThe accompanying condensed consolidated financial statements and accompanying related notes should be read in conjunction with the audited consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended June 27, 2020. 
Accounting Pronouncements Recently Adopted

[0001633978-21-000009:notes:14]
In August 2018, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2018-13, Fair Value Measurement (Topic 820): Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement. ASU 2018-13 modifies the disclosure requirements on transfers between Level 1 and Level 2, valuation processes of Level 3 fair value measurements, and the categorization by level for items that are not measured at fair value, but for which the fair value is required to be disclosed. We adopted ASU 2018-13 in the first quarter of fiscal 2021 with no impact to our condensed consolidated financial statements.

[0001633978-21-000009:notes:15]
In August 2018, FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Customer's Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract. This standard requires capitalization of the implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software. Further, the standard also requires the Company to expense the capitalized implementation costs of a hosting arrangement over the term of the hosting arrangement. We adopted ASU 2018-15 in the first quarter of fiscal 2021 with no impact to our condensed consolidated financial statements.

[0001633978-21-000009:notes:16]
In June 2016, FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments and a subsequent amendment, ASU 2018-19 (collectively, Topic 326). Topic 326 requires measurement and recognition of expected credit losses for financial assets held. We adopted ASU 2016-13 using the modified-retrospective approach in the first quarter of fiscal 2021 with no material impact to our condensed consolidated financial statements.

[0001633978-21-000009:notes:17]
With the adoption of Topic 326, we are now assessing whether unrealized losses have resulted from a credit loss or other factors. We believe none of our unrealized losses on available-for-sale investments were other-than temporary or were attributable to credit losses as of April 3, 2021 and June 27, 2020. We review our available-for-sale investments on a quarterly basis to identify a potential other-than-temporary impairment. The investments with unrealized losses consisted primarily of corporate debt securities, and given the extent of the unrealized loss positions, the issuers' high credit ratings and the near-term market conditions, we believe our unrealized losses are temporary. We also do not have an intent to sell our investments and would not be required to sell them before they recover.

[0001633978-21-000009:notes:18]
The adoption of Topic 326 did not significantly change our approach to the valuation of trade receivables. We determine whether there is an expected loss on our accounts receivable by reviewing all available data, including our customers' latest available financial statements, their credit standing and historical collection experience, as well as current and future market and economic conditions. As of April 3, 2021 and June 27, 2020, the allowance for credit losses on our trade receivables was $1.8 million and $1.8 million, respectively.

[0001633978-21-000009:notes:19]
Accounting Pronouncements Not Yet Effective

[0001633978-21-000009:notes:20]
In August 2020, FASB issued ASU 2020-06, Debt—Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging—Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity, which simplifies the accounting for convertible instruments by removing the separation models for (1) convertible debt with a cash conversion feature and (2) convertible instruments with a beneficial conversion feature. As a result, a convertible debt instrument will be accounted for as a single liability measured at its amortized cost. Also, ASU 2020-06 requires the application of the if-converted method for calculating diluted earnings per share and the treasury stock method will be no longer available. The new guidance is effective for fiscal years beginning after December 15, 2021, with early adoption permitted no earlier than fiscal years beginning after December 15, 2020. ASU 2020-06 is effective for us in our first quarter of fiscal year 2023. We are currently evaluating the impact of ASU 2020-06 on our condensed consolidated financial statements.
In December 2019, FASB issued ASU 2019-12, Simplifying the Accounting for Income Taxes (Topic 740), which is intended to simplify various aspects related to accounting for income taxes by removing certain exceptions to the general principles in Topic 740 and which also clarifies and amends existing guidance to improve consistent application. ASU 2019-12 is effective for us at the beginning of fiscal year 2022, including interim periods within that reporting period, although early adoption is permitted. We are currently evaluating the impact of ASU 2019-12 on our condensed consolidated financial statements. In August 2018, FASB issued ASU 2018-14, Compensation-Retirement Benefits-Defined Benefit Plans-General (Topic 715-20): Disclosure Framework-Changes to the Disclosure Requirements for Defined Benefit Plans. ASU 2018-14 modifies the disclosure requirements for defined benefit pension plans and other post-retirement benefit plans. The new guidance is effective for fiscal years ending after December 15, 2020, with early adoption permitted. ASU 2018-14 should be applied retrospectively to all periods presented and is effective for us in our fourth quarter of fiscal year 2021 as ASU 2018-14 does not amend the interim disclosure requirements.


## us-gaap:EarningsPerShareTextBlock

[0001633978-21-000009:notes:21]
[same as prior period, unchanged from 0001633978-21-000004:notes:21]

[0001633978-21-000009:notes:22]
[same as prior period, unchanged from 0001633978-21-000004:notes:22]

[0001633978-21-000009:notes:23]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 3, 2021 |  | March 28, 2020 |  | April 3, 2021 |  | March 28, 2020 |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income | $ | 225.5 |  |  | $ | 43.4 |  |  | $ | 375.8 |  |  | $ | 140.1 |  |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Basic weighted average common shares outstanding | 75.8 |  |  | 74.8 |  |  | 75.6 |  |  | 76.2 |  |  |
| Effect of dilutive securities from stock-based benefit plans | 0.8 |  |  | 1.0 |  |  | 0.8 |  |  | 0.8 |  |  |
| Shares issuable assuming conversion of the 2024 Notes | 2.6 |  |  | 1.7 |  |  | 2.2 |  |  | 0.7 |  |  |
| Diluted weighted average common shares outstanding | 79.2 |  |  | 77.5 |  |  | 78.6 |  |  | 77.7 |  |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic | $ | 2.97 |  |  | $ | 0.58 |  |  | $ | 4.97 |  |  | $ | 1.84 |  |  |
| Diluted | $ | 2.85 |  |  | $ | 0.56 |  |  | $ | 4.78 |  |  | $ | 1.80 |  |  |

[0001633978-21-000009:notes:24]
[same as prior period, unchanged from 0001633978-21-000004:notes:24]

[0001633978-21-000009:notes:25]
We have the ability and intent to settle the face value of our convertible notes in cash. Therefore, we use the treasury stock method for calculating the dilutive impact of the convertible notes. The 2026 Notes (as defined in Note 9) will have no impact on diluted earnings per share until the average price of our common stock exceeds the conversion price of $99.29. The potentially dilutive shares resulting from the 2024 Notes (as defined in Note 9) were included in the calculation of diluted income per share for the three and nine months ended April 3, 2021 since the average price of our common stock exceeded the conversion price of $60.62. Refer to “Note 9. Debt” for further discussion.

[0001633978-21-000009:notes:26]
Anti-dilutive potential shares are excluded from the calculation of diluted earnings per share if their exercise price exceeded the average market price during the period or the share-based awards were determined to be anti-dilutive based on applying the treasury stock method. Anti-dilutive shares excluded from the calculation of diluted earnings per share were not material and were 0.5 million shares for the three and nine months ended April 3, 2021, respectively. Anti-dilutive shares excluded from the calculation of diluted earnings per share were not material for each of the three and nine months ended March 28, 2020, respectively.


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001633978-21-000009:notes:27]
[same as prior period, unchanged from 0001633978-21-000004:notes:27]

[0001633978-21-000009:notes:28]
[same as prior period, unchanged from 0001633978-21-000004:notes:28]

[0001633978-21-000009:notes:29]
|  | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| April 3, 2021: |  |  |  |  |  |  |  |
| Cash | $ | 114.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 114.8 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 36.0 |  |  | — |  |  | — |  |  | 36.0 |  |
| Corporate debt securities | 7.5 |  |  | — |  |  | — |  |  | 7.5 |  |
| Money market funds | 504.4 |  |  | — |  |  | — |  |  | 504.4 |  |
| U.S. Treasury securities | 25.0 |  |  | — |  |  | — |  |  | 25.0 |  |
| Total cash and cash equivalents | $ | 687.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 687.7 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 19.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 19.3 |  |
| Commercial paper | 176.6 |  |  | — |  |  | — |  |  | 176.6 |  |
| Corporate debt securities | 450.0 |  |  | 0.3 |  |  | (0.3) |  |  | 450.0 |  |
| U.S. Agency securities | 46.5 |  |  | — |  |  | — |  |  | 46.5 |  |
| U.S. Treasury securities | 674.4 |  |  | 0.1 |  |  | — |  |  | 674.5 |  |
| Total short-term investments | $ | 1,366.8 |  |  | $ | 0.4 |  |  | $ | (0.3) |  |  | $ | 1,366.9 |  |
| June 27, 2020: |  |  |  |  |  |  |  |
| Cash | $ | 114.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 114.2 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | 159.6 |  |  | — |  |  | — |  |  | 159.6 |  |
| U.S. Treasury securities | 24.2 |  |  | — |  |  | — |  |  | 24.2 |  |
| Total cash and cash equivalents | $ | 298.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 298.0 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 12.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 12.9 |  |
| Commercial paper | 179.9 |  |  | 0.3 |  |  | — |  |  | 180.2 |  |
| Corporate debt securities | 435.0 |  |  | 1.7 |  |  | (0.1) |  |  | 436.6 |  |
| Foreign government bonds | 1.7 |  |  | — |  |  | — |  |  | 1.7 |  |
| U.S. Agency securities | 59.5 |  |  | — |  |  | — |  |  | 59.5 |  |
| U.S. Treasury securities | 563.9 |  |  | 1.0 |  |  | — |  |  | 564.9 |  |
| Total short-term investments | $ | 1,252.9 |  |  | $ | 3.0 |  |  | $ | (0.1) |  |  | $ | 1,255.8 |  |

[0001633978-21-000009:notes:30]
We use the specific-identification method to determine any realized gains or losses from the sale of our short-term investments classified as available-for-sale. During the three and nine months ended April 3, 2021 and March 28, 2020, we did not realize significant gains or losses on a gross level from the sale of our short-term investments classified as available-for-sale.

[0001633978-21-000009:notes:31]
During the three and nine months ended April 3, 2021, our other income (expense), net was $2.4 million and $2.1 million, respectively, and includes interest income on cash equivalents and short-term investments of $1.0 million and $4.9 million, respectively. During the three and nine months ended March 28, 2020, our other income (expense), net was $21.7 million and $27.9 million, respectively, and includes interest income on cash equivalents and short-term investments of $5.2 million and $12.6 million, respectively, and a gain on the sale of Lithium Niobate modulators business of $13.8 million for both periods presented.

[0001633978-21-000009:notes:32]
We included $3.5 million and $4.3 million of interest receivable in prepayments and other current assets as of April 3, 2021 and June 27, 2020, respectively. We did not recognize an allowance for credit losses against interest receivable in any of the periods presented as there were no such losses.

[0001633978-21-000009:notes:33]
[same as prior period, unchanged from 0001633978-21-000004:notes:33]

[0001633978-21-000009:notes:34]
|  | Less than 12 months |  |  |  |  |
|  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |
| April 3, 2021: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 34.4 |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | 4.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 129.5 |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 310.4 |  |  | (0.3) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 47.9 |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | 526.2 |  |  | $ | (0.3) |  |  |  |  |  |  |  |  |  |
| June 27, 2020: |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 3.1 |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 51.1 |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 96.5 |  |  | (0.1) |  |  |  |  |  |  |  |  |  |
| Foreign government bonds | 1.7 |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | 47.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 159.8 |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | 359.2 |  |  | $ | (0.1) |  |  |  |  |  |  |  |  |  |

[0001633978-21-000009:notes:35]
As of April 3, 2021 and June 27, 2020, we have no unrealized loss positions for a period of greater than 12 months on our cash equivalents and short-term investments.

[0001633978-21-000009:notes:36]
[same as prior period, unchanged from 0001633978-21-000004:notes:36]

[0001633978-21-000009:notes:37]
|  | April 3, 2021 |  | June 27, 2020 |
|  | Amortized Cost |  | Fair Value |  | Amortized Cost |  | Fair Value |
| Due in 1 year | $ | 926.7 |  |  | $ | 926.8 |  |  | $ | 1,237.4 |  |  | $ | 1,239.9 |  |
| Due in 1 year through 5 years | 440.1 |  |  | 440.1 |  |  | 15.5 |  |  | 15.9 |  |
|  | $ | 1,366.8 |  |  | $ | 1,366.9 |  |  | $ | 1,252.9 |  |  | $ | 1,255.8 |  |

[0001633978-21-000009:notes:38]
[same as prior period, unchanged from 0001633978-21-000004:notes:38]


## us-gaap:FairValueDisclosuresTextBlock

[0001633978-21-000009:notes:39]
[same as prior period, unchanged from 0001633978-21-000004:notes:39]

[0001633978-21-000009:notes:40]
[same as prior period, unchanged from 0001633978-21-000004:notes:40]

[0001633978-21-000009:notes:41]
[same as prior period, unchanged from 0001633978-21-000004:notes:41]

[0001633978-21-000009:notes:42]
[same as prior period, unchanged from 0001633978-21-000004:notes:42]

[0001633978-21-000009:notes:43]
[same as prior period, unchanged from 0001633978-21-000004:notes:43]

[0001633978-21-000009:notes:44]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| April 3, 2021: (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | — |  |  | $ | 36.0 |  |  | $ | — |  |  | $ | 36.0 |  |
| Corporate debt securities | — |  |  | 7.5 |  |  | — |  |  | 7.5 |  |
| Money market funds | 504.4 |  |  | — |  |  | — |  |  | 504.4 |  |
| U.S. Treasury securities | 25.0 |  |  | — |  |  | — |  |  | 25.0 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 19.3 |  |  | — |  |  | 19.3 |  |
| Commercial paper | — |  |  | 176.6 |  |  | — |  |  | 176.6 |  |
| Corporate debt securities | — |  |  | 450.0 |  |  | — |  |  | 450.0 |  |
| U.S. Agency securities | — |  |  | 46.5 |  |  | — |  |  | 46.5 |  |
| U.S. Treasury securities | 674.5 |  |  | — |  |  | — |  |  | 674.5 |  |
| Total assets | $ | 1,203.9 |  |  | $ | 735.9 |  |  | $ | — |  |  | $ | 1,939.8 |  |

[0001633978-21-000009:notes:45]
(1)  Excludes $114.8 million in cash held in our bank accounts at April 3, 2021.

[0001633978-21-000009:notes:46]
[same as prior period, unchanged from 0001633978-21-000004:notes:46]

[0001633978-21-000009:notes:47]
[same as prior period, unchanged from 0001633978-21-000004:notes:47]

[0001633978-21-000009:notes:48]
[same as prior period, unchanged from 0001633978-21-000004:notes:48]

[0001633978-21-000009:notes:49]
[same as prior period, unchanged from 0001633978-21-000004:notes:49]

[0001633978-21-000009:notes:50]
[same as prior period, unchanged from 0001633978-21-000004:notes:50]

[0001633978-21-000009:notes:51]
|  | April 3, 2021 |  | June 27, 2020 |
|  | Carrying Amount |  | Estimated Fair Value |  | Carrying Amount |  | Estimated Fair Value |
| 2026 Notes | $ | 778.9 |  |  | $ | 1,240.5 |  |  | $ | 749.7 |  |  | $ | 1,070.2 |  |
| 2024 Notes | 385.3 |  |  | 730.9 |  |  | 370.6 |  |  | 620.0 |  |
|  | $ | 1,164.2 |  |  | $ | 1,971.4 |  |  | $ | 1,120.3 |  |  | $ | 1,690.2 |  |

[0001633978-21-000009:notes:52]
[same as prior period, unchanged from 0001633978-21-000004:notes:52]

[0001633978-21-000009:notes:53]
[same as prior period, unchanged from 0001633978-21-000004:notes:53]

[0001633978-21-000009:notes:54]
[same as prior period, unchanged from 0001633978-21-000004:notes:54]


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001633978-21-000009:notes:55]
[same as prior period, unchanged from 0001633978-21-000004:notes:55]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001633978-21-000009:notes:56]
[same as prior period, unchanged from 0001633978-21-000004:notes:56]

[0001633978-21-000009:notes:57]
[same as prior period, unchanged from 0001633978-21-000004:notes:57]

[0001633978-21-000009:notes:58]
We did not have any allowance for credit losses other than our allowance for uncollectible accounts receivable. As of April 3, 2021 and June 27, 2020, the allowance for credit losses on our trade receivables was $1.8 million and $1.8 million, respectively.

[0001633978-21-000009:notes:59]
[same as prior period, unchanged from 0001633978-21-000004:notes:59]

[0001633978-21-000009:notes:60]
[same as prior period, unchanged from 0001633978-21-000004:notes:60]

[0001633978-21-000009:notes:61]
|  | April 3, 2021 |  | June 27, 2020 |
| Raw materials and purchased parts | $ | 69.4 |  |  | $ | 57.9 |  |
| Work in process | 82.5 |  |  | 67.6 |  |
| Finished goods | 58.8 |  |  | 63.4 |  |
| Inventories | $ | 210.7 |  |  | $ | 188.9 |  |

[0001633978-21-000009:notes:62]
[same as prior period, unchanged from 0001633978-21-000004:notes:62]

[0001633978-21-000009:notes:63]
[same as prior period, unchanged from 0001633978-21-000004:notes:63]

[0001633978-21-000009:notes:64]
|  | April 3, 2021 |  | June 27, 2020 |
| Operating lease right-of-use assets | $ | 87.3 |  |  | $ | 90.3 |  |
| Less: accumulated amortization | (17.0) |  |  | (11.6) |  |
| Operating lease right-of-use assets, net | $ | 70.3 |  |  | $ | 78.7 |  |

[0001633978-21-000009:notes:65]
[same as prior period, unchanged from 0001633978-21-000004:notes:65]

[0001633978-21-000009:notes:66]
[same as prior period, unchanged from 0001633978-21-000004:notes:66]

[0001633978-21-000009:notes:67]
|  | April 3, 2021 |  | June 27, 2020 |
| Land | $ | 44.1 |  |  | $ | 44.1 |  |
| Buildings and improvement | 125.7 |  |  | 114.8 |  |
| Machinery and equipment | 526.8 |  |  | 487.0 |  |
| Computer equipment and software | 29.0 |  |  | 27.5 |  |
| Furniture and fixtures | 8.8 |  |  | 7.2 |  |
| Leasehold improvements | 32.0 |  |  | 27.8 |  |
| Finance lease right-of-use assets | 28.1 |  |  | 28.1 |  |
| Construction in progress | 36.8 |  |  | 54.7 |  |
|  | 831.3 |  |  | 791.2 |  |
| Less: Accumulated depreciation | (453.3) |  |  | (398.2) |  |
| Property, plant and equipment, net | $ | 378.0 |  |  | $ | 393.0 |  |

[0001633978-21-000009:notes:68]
During the three and nine months ended April 3, 2021, we recorded depreciation expense of $22.8 million and $70.4 million, respectively. During the three and nine months ended March 28, 2020, we recorded depreciation expense of $27.5 million and $87.8 million, respectively.

[0001633978-21-000009:notes:69]
[same as prior period, unchanged from 0001633978-21-000004:notes:69]

[0001633978-21-000009:notes:70]
[same as prior period, unchanged from 0001633978-21-000004:notes:70]

[0001633978-21-000009:notes:71]
[same as prior period, unchanged from 0001633978-21-000004:notes:71]

[0001633978-21-000009:notes:72]
|  | April 3, 2021 |  | June 27, 2020 |
| Restructuring accrual and related charges (1) | $ | 4.2 |  |  | $ | 5.2 |  |
| Warranty accrual (2) | 5.6 |  |  | 5.0 |  |
| Deferred revenue and customer deposits | 1.8 |  |  | 1.9 |  |
| Finance lease liabilities, current | 0.1 |  |  | 0.6 |  |
| Income tax payable (3) | 73.1 |  |  | 28.8 |  |
| Other current liabilities | 2.2 |  |  | 2.8 |  |
| Other current liabilities | $ | 87.0 |  |  | $ | 44.3 |  |

[0001633978-21-000009:notes:73]
[same as prior period, unchanged from 0001633978-21-000004:notes:73]

[0001633978-21-000009:notes:74]
(2) Refer to “Note 14. Commitments and Contingencies.”

[0001633978-21-000009:notes:75]
[same as prior period, unchanged from 0001633978-21-000004:notes:75]

[0001633978-21-000009:notes:76]
[same as prior period, unchanged from 0001633978-21-000004:notes:76]

[0001633978-21-000009:notes:77]
[same as prior period, unchanged from 0001633978-21-000004:notes:77]

[0001633978-21-000009:notes:78]
|  | April 3, 2021 |  | June 27, 2020 |
| Asset retirement obligations | $ | 4.7 |  |  | $ | 4.6 |  |
| Pension accrual | 12.0 |  |  | 11.8 |  |
| Unrecognized tax benefit | 26.6 |  |  | 17.3 |  |
| Other non-current liabilities | 2.4 |  |  | 2.3 |  |
| Other non-current liabilities | $ | 45.7 |  |  | $ | 36.0 |  |


## us-gaap:LesseeFinanceLeasesTextBlock

[0001633978-21-000009:notes:79]
Note 7. Leases

[0001633978-21-000009:notes:80]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2033. These operating leases are mainly for administrative offices, research-and-development and manufacturing facilities, as well as sales offices in various countries around the world. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. Many leases include one or more options to renew. We do not assume renewals in our determination of the lease term unless the renewals are deemed to be reasonably assured at lease commencement.

[0001633978-21-000009:notes:81]
We also have various finance leases of servers and certain other equipment for our operations. These arrangements are typically for two to four years.

[0001633978-21-000009:notes:82]
As of April 3, 2021, we sublease certain floors of our offices in the United Kingdom, the United States, Canada, and Japan. These subleases will expire at various dates by fiscal year 2023. We anticipate receiving approximately $3.6 million in sublease income over the next two years.

[0001633978-21-000009:notes:83]
The components of lease costs, lease term, and discount rate are as follows:

[0001633978-21-000009:notes:84]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 3, 2021 |  | March 28, 2020 |  | April 3, 2021 |  | March 28, 2020 |
| Finance lease cost (in millions): |  |  |  |  |  |  |  |
| Amortization of right-of-use assets | $ | 0.1 |  |  | $ | 4.8 |  |  | $ | 0.4 |  |  | $ | 13.0 |  |
| Interest | — |  |  | — |  |  | — |  |  | 0.1 |  |
| Operating lease cost | 3.4 |  |  | 3.9 |  |  | 10.6 |  |  | 11.9 |  |
| Short-term and variable lease costs | 1.1 |  |  | 1.1 |  |  | 3.4 |  |  | 3.2 |  |
| Sublease income | (0.7) |  |  | (0.7) |  |  | (2.1) |  |  | (1.9) |  |
| Total lease cost | $ | 3.9 |  |  | $ | 9.1 |  |  | $ | 12.3 |  |  | $ | 26.3 |  |
|  |  |  |  |  | April 3, 2021 |  | June 27, 2020 |
| Weighted average remaining lease term (in years): |  |  |  |  |  |  |  |
| Operating leases |  |  |  |  | 7.6 |  | 8.6 |
| Finance leases |  |  |  |  | 0.3 |  | 1.0 |
| Weighted average discount rate: |  |  |  |  |  |  |  |
| Operating leases |  |  |  |  | 3.5 | % |  | 3.5 | % |
| Finance leases |  |  |  |  | 4.4 | % |  | 4.4 | % |

[0001633978-21-000009:notes:85]
As of April 3, 2021, maturities of our operating and finance lease liabilities, which do not include short-term leases and variable lease payments, were as follows (in millions):

[0001633978-21-000009:notes:86]
| Fiscal Years |  | Operating Leases (1) |  | Finance Leases |  | Total |
| Remainder of 2021 |  | $ | 3.9 |  |  | $ | 0.1 |  |  | $ | 4.0 |  |
| 2022 |  | 13.8 |  |  | — |  |  | 13.8 |  |
| 2023 |  | 11.2 |  |  | — |  |  | 11.2 |  |
| 2024 |  | 9.9 |  |  | — |  |  | 9.9 |  |
| 2025 |  | 6.5 |  |  | — |  |  | 6.5 |  |
| Thereafter |  | 25.4 |  |  | — |  |  | 25.4 |  |
| Total minimum lease payments |  | $ | 70.7 |  |  | $ | 0.1 |  |  | $ | 70.8 |  |
| Less: amount representing interest |  | (8.4) |  |  | — |  |  | (8.4) |  |
| Present value of total lease liabilities |  | $ | 62.3 |  |  | $ | 0.1 |  |  | $ | 62.4 |  |

[0001633978-21-000009:notes:87]
(1) Non-cancellable sublease proceeds for the remainder of fiscal 2021, and fiscal 2022, and 2023 of $0.7 million, $2.3 million, and $0.6 million, respectively, are not included in the table above.


## us-gaap:GoodwillDisclosureTextBlock

[0001633978-21-000009:notes:88]
[same as prior period, unchanged from 0001633978-21-000004:notes:88]

[0001633978-21-000009:notes:89]
[same as prior period, unchanged from 0001633978-21-000004:notes:89]

[0001633978-21-000009:notes:90]
The following table presents our goodwill balance by the reportable segments as of April 3, 2021 and June 27, 2020 (in millions):

[0001633978-21-000009:notes:91]
|  | Optical Communications |  | Commercial Lasers |  | Total |
| Balance as of April 3, 2021 and June 27, 2020 | $ | 363.5 |  |  | $ | 5.4 |  |  | $ | 368.9 |  |

[0001633978-21-000009:notes:92]
[same as prior period, unchanged from 0001633978-21-000004:notes:92]

[0001633978-21-000009:notes:93]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. In the fourth quarter of fiscal 2020, we completed the annual impairment test of goodwill, which indicated there was no goodwill impairment. There were no indicators of goodwill impairment during the three and nine months ended April 3, 2021.

[0001633978-21-000009:notes:94]
[same as prior period, unchanged from 0001633978-21-000004:notes:95]

[0001633978-21-000009:notes:95]
The intangible assets are amortized on a straight-line basis over the estimated useful lives, except for customer relationships and order backlog, which are amortized using an accelerated method of amortization over the expected customer lives, which more accurately reflects the pattern of realization of economic benefits expected to be obtained. Acquired developed technologies and order backlog are amortized to cost of sales and customer relationships is amortized to selling, general and administrative. In-process research and development (“IPR&D”) is initially capitalized at fair value as an intangible asset with an indefinite life and assessed for impairment thereafter. When an IPR&D project is completed, the IPR&D is reclassified as an amortizable purchased intangible asset and amortized over the asset’s estimated useful life.

[0001633978-21-000009:notes:96]
[same as prior period, unchanged from 0001633978-21-000004:notes:98]

[0001633978-21-000009:notes:97]
| April 3, 2021 | Gross Carrying Amounts |  | Accumulated Amortization |  | Net Carrying Amounts |  | Weighted average remaining amortization period (years) |
| Acquired developed technologies | $ | 390.3 |  |  | $ | (222.3) |  |  | $ | 168.0 |  |  | 3.2 |
| Customer relationships | 145.0 |  |  | (49.8) |  |  | 95.2 |  |  | 5.7 |
| Order backlog | 22.0 |  |  | (22.0) |  |  | — |  |  | — |
| Other intangibles | 2.7 |  |  | (2.7) |  |  | — |  |  | — |
| Total intangible assets | $ | 560.0 |  |  | $ | (296.8) |  |  | $ | 263.2 |  |  |  |

[0001633978-21-000009:notes:98]
The table above excludes fully amortized intangibles of $5.5 million that were written off against accumulated amortization during the three and nine months ended April 3, 2021.

[0001633978-21-000009:notes:99]
During the three and nine months ended April 3, 2021, we completed our remaining IPR&D projects and therefore reclassified $10 million from IPR&D to acquired developed technologies. This amount will be amortized over the assets’ estimated useful life of 3 years.

[0001633978-21-000009:notes:100]
During the nine months ended April 3, 2021, we purchased intellectual property from a third party for a total consideration of $10 million. These intangible assets have an estimated useful life of 5 years.

[0001633978-21-000009:notes:101]
[same as prior period, unchanged from 0001633978-21-000004:notes:100]

[0001633978-21-000009:notes:102]
[same as prior period, unchanged from 0001633978-21-000004:notes:101]

[0001633978-21-000009:notes:103]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 3, 2021 |  | March 28, 2020 |  | April 3, 2021 |  | March 28, 2020 |
| Cost of sales | $ | 15.8 |  |  | $ | 13.9 |  |  | $ | 45.8 |  |  | $ | 38.8 |  |
| Selling, general and administrative | 6.2 |  |  | 6.1 |  |  | 17.8 |  |  | 18.6 |  |
| Total amortization of intangibles | $ | 22.0 |  |  | $ | 20.0 |  |  | $ | 63.6 |  |  | $ | 57.4 |  |

[0001633978-21-000009:notes:104]
Based on the carrying amount of our acquired developed technologies and other intangibles as of April 3, 2021, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001633978-21-000009:notes:105]
| Fiscal Years |  |
| Remainder of 2021 | $ | 22.0 |  |
| 2022 | 85.4 |  |
| 2023 | 61.9 |  |
| 2024 | 40.5 |  |
| 2025 | 27.7 |  |
| Thereafter | 25.7 |  |
| Total future amortization | $ | 263.2 |  |


## us-gaap:DebtDisclosureTextBlock

[0001633978-21-000009:notes:106]
Note 9. Debt

[0001633978-21-000009:notes:107]
Convertible Notes

[0001633978-21-000009:notes:108]
2026 Notes

[0001633978-21-000009:notes:109]
In December 2019, we issued $1,050 million in aggregate principal amount of the 2026 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2026 Notes are governed by an indenture between the Company and U.S. Bank National Association (the “2026 Indenture”). We used approximately $196 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan credit facility, and a portion of the net proceeds of the offering to purchase approximately $200 million of our common stock concurrently with the pricing of the offering in privately negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001633978-21-000009:notes:110]
The 2026 Notes will bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on June 15, 2020. The 2026 Notes will mature on December 15, 2026, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001633978-21-000009:notes:111]
The initial conversion rate is 10.0711 shares of common stock per $1,000 principal amount of the 2026 Notes (which is equivalent to an initial conversion price of approximately $99.29 per share). The conversion rate is subject to adjustment upon the occurrence of certain specified events but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2026 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001633978-21-000009:notes:112]
Prior to the close of business on the business day immediately preceding September 15, 2026, holders of the 2026 Notes may convert their 2026 Notes only under certain circumstances discussed in detail in our Annual Report on Form 10-K for the year ended June 27, 2020.

[0001633978-21-000009:notes:113]
2024 Notes

[0001633978-21-000009:notes:114]
In March 2017, we issued $450 million of the 2024 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank National Association, as trustee (the “2024 Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001633978-21-000009:notes:115]
The 2024 Notes bear interest at a rate of 0.25% per year. Interest on the 2024 Notes is payable semi-annually in arrears on March 15 and September 15 of each year, beginning on September 15, 2017. The 2024 Notes will mature on March 15, 2024, unless earlier repurchased by us or converted pursuant to their terms.

[0001633978-21-000009:notes:116]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share, a 132.5% premium to the fair market value at the date of issuance. Prior to the close of business on the business day immediately preceding December 15, 2023, each holder of the 2024 Notes may convert their 2024 Notes only under certain circumstances discussed in detail in our Annual Report on Form 10-K for the year ended June 27, 2020.

[0001633978-21-000009:notes:117]
Our convertible notes consisted of the following components as of the periods presented (in millions):

[0001633978-21-000009:notes:118]
| Liability component: | April 3, 2021 |  | June 27, 2020 |
|  | 2024 Notes (1) |  | 2026 Notes |  | 2024 Notes (1) |  | 2026 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 450.0 |  |  | $ | 1,050.0 |  |
| Unamortized debt discount and debt issuance costs | (64.7) |  |  | (271.1) |  |  | (79.4) |  |  | (300.3) |  |
| Net carrying amount of the liability component | $ | 385.3 |  |  | $ | 778.9 |  |  | $ | 370.6 |  |  | $ | 749.7 |  |

[0001633978-21-000009:notes:119]
(1) Since the closing price of our stock exceeded $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of the third quarter of fiscal 2021, the 2024 Notes have become convertible at the option of the holders. Therefore, the debt component of our 2024 Notes as of April 3, 2021 has been classified as current liabilities in our condensed consolidated balance sheet.

[0001633978-21-000009:notes:120]
If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future quarter, our 2026 Notes would also become convertible at the option of the holders and the debt component would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001633978-21-000009:notes:121]
The following table sets forth interest expense information related to the convertible notes for the periods presented (in millions):

[0001633978-21-000009:notes:122]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 3, 2021 |  | March 28, 2020 |  | April 3, 2021 |  | March 28, 2020 |
| Contractual interest expense | $ | 1.6 |  |  | $ | 1.6 |  |  | $ | 4.8 |  |  | $ | 2.3 |  |
| Amortization of the debt discount and debt issuance costs | 14.8 |  |  | 14.0 |  |  | 43.9 |  |  | 24.8 |  |
| Total interest expense | $ | 16.4 |  |  | $ | 15.6 |  |  | $ | 48.7 |  |  | $ | 27.1 |  |

[0001633978-21-000009:notes:123]
The future interest and principal payments related to our convertible notes are as follows as of April 3, 2021 (in millions):

[0001633978-21-000009:notes:124]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | Total |
| Remainder of 2021 | $ | — |  |  | $ | 2.6 |  |  | $ | 2.6 |  |
| 2022 | 1.1 |  |  | 5.3 |  |  | 6.4 |  |
| 2023 | 1.1 |  |  | 5.3 |  |  | 6.4 |  |
| 2024 | 451.2 |  |  | 5.3 |  |  | 456.5 |  |
| 2025 | — |  |  | 5.3 |  |  | 5.3 |  |
| Thereafter | — |  |  | 1,057.7 |  |  | 1,057.7 |  |
| Total convertible notes payments | $ | 453.4 |  |  | $ | 1,081.5 |  |  | $ | 1,534.9 |  |

[0001633978-21-000009:notes:125]
The principal balances of our Notes are reflected in the payment periods in the table above based on their respective contractual maturities. During the three and nine months ended April 3, 2021, we received conversion requests for less than $0.1 million principal amount of the 2024 Notes, which will be settled in cash in the fourth quarter of fiscal 2021.

[0001633978-21-000009:notes:126]
Term Loan Facility

[0001633978-21-000009:notes:127]
In December 2018, concurrent with the closing of the Oclaro merger, we entered into a credit agreement providing for a term loan facility (the “Term Loan Facility”) in an aggregate principal amount of $500.0 million and we drew in full the term loans available under the Term Loan Facility on the closing date of the Oclaro merger. In the second quarter of fiscal 2020, we repaid, in full, all amounts outstanding under our Term Loan Facility. During the nine months ended March 28, 2020, we incurred $18.1 million of interest expense on this Term Loan Facility, which includes an $8.0 million loss on the early extinguishment of debt.

[0001633978-21-000009:notes:128]
Other Interest Expense

[0001633978-21-000009:notes:129]
For the nine months ended March 28, 2020, we also recorded $0.1 million interest expense related to our finance leases.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001633978-21-000009:notes:130]
[same as prior period, unchanged from 0001633978-21-000004:notes:127]

[0001633978-21-000009:notes:131]
[same as prior period, unchanged from 0001633978-21-000004:notes:128]

[0001633978-21-000009:notes:132]
[same as prior period, unchanged from 0001633978-21-000004:notes:129]

[0001633978-21-000009:notes:133]
|  | Foreign currency translation adjustments, net of tax (1) |  | Defined benefit obligations, net of tax (2) |  | Unrealized gain (loss) on available-for-sale securities, net of tax (3) |  |  |  | Total |
| Beginning balance as of June 27, 2020 | $ | 9.7 |  |  | $ | (4.2) |  |  | $ | 2.4 |  |  |  |  | $ | 7.9 |  |
| Other comprehensive loss | — |  |  | — |  |  | (1.5) |  |  |  |  | (1.5) |  |
| Ending balance as of September 26, 2020 | 9.7 |  |  | (4.2) |  |  | 0.9 |  |  |  |  | 6.4 |  |
| Other comprehensive loss | — |  |  | — |  |  | (0.4) |  |  |  |  | (0.4) |  |
| Ending balance as of December 26, 2020 | $ | 9.7 |  |  | $ | (4.2) |  |  | $ | 0.5 |  |  |  |  | $ | 6.0 |  |
| Other comprehensive loss | — |  |  | — |  |  | (0.3) |  |  |  |  | (0.3) |  |
| Ending balance as of April 3, 2021 | $ | 9.7 |  |  | $ | (4.2) |  |  | $ | 0.2 |  |  |  |  | $ | 5.7 |  |
|  | Foreign currency translation adjustments, net of tax (1) |  | Defined benefit obligations, net of tax (2) |  | Unrealized gain (loss) on available-for-sale securities, net of tax (3) |  |  |  | Total |
| Beginning balance as of June 29, 2019 | $ | 9.7 |  |  | $ | (3.5) |  |  | $ | 0.9 |  |  |  |  | $ | 7.1 |  |
| Other comprehensive income | — |  |  | — |  |  | 0.1 |  |  |  |  | 0.1 |  |
| Ending balance as of September 28, 2019 | 9.7 |  |  | (3.5) |  |  | 1.0 |  |  |  |  | 7.2 |  |
| Other comprehensive loss | — |  |  | — |  |  | (0.2) |  |  |  |  | (0.2) |  |
| Ending balance as of December 28, 2019 | $ | 9.7 |  |  | $ | (3.5) |  |  | $ | 0.8 |  |  |  |  | $ | 7.0 |  |
| Other comprehensive loss | — |  |  | — |  |  | (1.2) |  |  |  |  | (1.2) |  |
| Ending balance as of March 28, 2020 | $ | 9.7 |  |  | $ | (3.5) |  |  | $ | (0.4) |  |  |  |  | $ | 5.8 |  |

[0001633978-21-000009:notes:134]
(1) In fiscal 2019, as a result of significant changes in economic facts and circumstances, primarily due to the acquisition of Oclaro, we established the functional currency for our worldwide operations as the U.S. dollar. Translation adjustments reported prior to December 10, 2018, remain as a component of accumulated other comprehensive income in our condensed consolidated balance sheets, until all or a part of the investment in the subsidiaries is sold or liquidated.
(2) We evaluate the assumptions over the fair value of our defined benefit obligations annually and make changes as necessary.(3) Unrealized loss on available-for-sale securities for the three and nine months ended April 3, 2021 is presented net of tax of $0.1 million and $0.6 million, respectively. Tax impact was not material for the other periods presented.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001633978-21-000009:notes:135]
[same as prior period, unchanged from 0001633978-21-000004:notes:133]

[0001633978-21-000009:notes:136]
We have initiated various strategic restructuring actions primarily intended to reduce costs, consolidate our operations, rationalize the manufacturing of our products and align our business in response to market conditions.

[0001633978-21-000009:notes:137]
The following table summarizes the activity of restructuring and related charges during the three and nine months ended April 3, 2021 and March 28, 2020 (in millions):

[0001633978-21-000009:notes:138]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 3, 2021 |  | March 28, 2020 |  | April 3, 2021 |  | March 28, 2020 |
| Balance as of beginning of period | $ | 4.6 |  |  | $ | 5.0 |  |  | $ | 5.2 |  |  | $ | 14.6 |  |
| Charges | 2.9 |  |  | 2.7 |  |  | 3.1 |  |  | 4.9 |  |
| Payments | (3.3) |  |  | (5.1) |  |  | (4.1) |  |  | (16.9) |  |
| Balance as of end of period | $ | 4.2 |  |  | $ | 2.6 |  |  | $ | 4.2 |  |  | $ | 2.6 |  |

[0001633978-21-000009:notes:139]
During the three and nine months ended April 3, 2021, we recorded restructuring and related charges of $2.9 million and $3.1 million, respectively, in our condensed consolidated statements of operations. The charges were mainly attributable to severance charges associated with the decision to cease manufacturing of certain products in San Jose, California.

[0001633978-21-000009:notes:140]
During the three and nine months ended March 28, 2020, we recorded $2.7 million and $4.9 million, respectively, in restructuring and related charges in our condensed consolidated statements of operations. The charges were mainly attributable to severance charges associated with the decision to move certain manufacturing from San Jose, California to our facility in Thailand and other third party vendors.

[0001633978-21-000009:notes:141]
[same as prior period, unchanged from 0001633978-21-000004:notes:139]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001633978-21-000009:notes:142]
[same as prior period, unchanged from 0001633978-21-000004:notes:140]

[0001633978-21-000009:notes:143]
[same as prior period, unchanged from 0001633978-21-000004:notes:141]

[0001633978-21-000009:notes:144]
We recorded a tax provision of $27.4 million and $58.8 million for the three and nine months ended April 3, 2021, respectively. Our tax provision for the three months ended April 3, 2021 includes a discrete tax expense of $16.8 million mainly associated with the Coherent termination fee, partially offset by currency re-measurement of certain tax related accounts and return-to-provision differences. Our estimated effective tax rate for fiscal 2021 differs from the 21% U.S. statutory rate primarily due to the earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate as well as the U.S. federal R&D tax credits, partially offset by the income tax expense from non-deductible stock-based compensation and the tax effect of Global Intangible Low-Taxed Income (“GILTI”), net of benefit for foreign tax credits, and subpart F inclusion.

[0001633978-21-000009:notes:145]
As of April 3, 2021, we had $26.9 million of unrecognized tax benefits, which, if recognized, would affect the effective tax rate. We are subject to examination of income tax returns by various domestic and foreign tax authorities. The timing of commencement, resolution and closure of tax audits is highly unpredictable. Although it is possible that certain ongoing tax audits may be concluded within the next 12 months, we cannot reasonably estimate the impact to tax expense and net income from tax exams that could be resolved or closed within the next 12 months. Subject to audit timing and uncertainty, we expect our unrecognized tax benefit amount that could affect the effective tax rate to decrease by $4.8 million over the next 12 months.

[0001633978-21-000009:notes:146]
[same as prior period, unchanged from 0001633978-21-000004:notes:144]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001633978-21-000009:notes:147]
[same as prior period, unchanged from 0001633978-21-000004:notes:145]

[0001633978-21-000009:notes:148]
[same as prior period, unchanged from 0001633978-21-000004:notes:146]

[0001633978-21-000009:notes:149]
[same as prior period, unchanged from 0001633978-21-000004:notes:147]

[0001633978-21-000009:notes:150]
As of April 3, 2021, we had 2.2 million shares subject to restricted stock units and performance stock units issued and outstanding under the 2015 Equity Incentive Plan (the “2015 Plan”). Restricted stock units and performance stock units are performance-based, time-based or a combination of both. The fair value of these grants is based on the closing market price of our common stock on the date of award.

[0001633978-21-000009:notes:151]
As of April 3, 2021, 2.3 million shares of common stock under the 2015 Plan were available for grant.

[0001633978-21-000009:notes:152]
[same as prior period, unchanged from 0001633978-21-000004:notes:150]

[0001633978-21-000009:notes:153]
In connection with the acquisition of Oclaro, we issued equity awards to Oclaro employees (“replacement awards”) in exchange for their Oclaro equity awards. As of April 3, 2021, we had 0.1 million of unvested shares subject to restricted stock units under the replacement awards.

[0001633978-21-000009:notes:154]
[same as prior period, unchanged from 0001633978-21-000004:notes:152]

[0001633978-21-000009:notes:155]
[same as prior period, unchanged from 0001633978-21-000004:notes:153]

[0001633978-21-000009:notes:156]
[same as prior period, unchanged from 0001633978-21-000004:notes:154]

[0001633978-21-000009:notes:157]
[same as prior period, unchanged from 0001633978-21-000004:notes:155]

[0001633978-21-000009:notes:158]
[same as prior period, unchanged from 0001633978-21-000004:notes:156]

[0001633978-21-000009:notes:159]
Our 2015 Employee Stock Purchase Plan (the “2015 Purchase Plan”) provides eligible employees with the opportunity to acquire an ownership interest in the Company through periodic payroll deductions and provides a 15% purchase price discount as well as a 6-month look-back period. The 2015 Purchase Plan is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986, as amended. The 2015 Purchase Plan will terminate upon the date on which all shares available for issuance have been sold. Of the 3.0 million shares authorized under the 2015 Purchase Plan, 1.7 million shares remained available for issuance as of April 3, 2021.

[0001633978-21-000009:notes:160]
[same as prior period, unchanged from 0001633978-21-000004:notes:158]

[0001633978-21-000009:notes:161]
The impact on our results of operations of recording stock-based compensation by function for the three and nine months ended April 3, 2021 and March 28, 2020 was as follows (in millions):

[0001633978-21-000009:notes:162]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 3, 2021 |  | March 28, 2020 |  | April 3, 2021 |  | March 28, 2020 |
| Cost of sales | $ | 5.3 |  |  | $ | 4.3 |  |  | $ | 13.8 |  |  | $ | 12.6 |  |
| Research and development | 5.3 |  |  | 4.2 |  |  | 14.8 |  |  | 12.1 |  |
| Selling, general and administrative | 14.5 |  |  | 10.7 |  |  | 40.1 |  |  | 31.4 |  |
| Total stock-based compensation | $ | 25.1 |  |  | $ | 19.2 |  |  | $ | 68.7 |  |  | $ | 56.1 |  |

[0001633978-21-000009:notes:163]
[same as prior period, unchanged from 0001633978-21-000004:notes:161]

[0001633978-21-000009:notes:164]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 3, 2021 |  | March 28, 2020 |  | April 3, 2021 |  | March 28, 2020 |
| Income tax benefit associated with stock-based compensation | $ | 3.4 |  |  | $ | 2.4 |  |  | $ | 12.2 |  |  | $ | 9.0 |  |

[0001633978-21-000009:notes:165]
Approximately $5.2 million and $3.6 million of stock-based compensation was capitalized to inventory as of April 3, 2021 and June 27, 2020, respectively.

[0001633978-21-000009:notes:166]
[same as prior period, unchanged from 0001633978-21-000004:notes:164]

[0001633978-21-000009:notes:167]
The following table summarizes our awards activity for the nine months ended April 3, 2021 (in millions, except per share amounts):

[0001633978-21-000009:notes:168]
|  |  |  | Restricted Stock Units |  | Performance Stock Units |
|  |  |  |  |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance as of June 27, 2020 |  |  |  |  | 1.9 |  |  | $ | 56.6 |  |  | 0.3 |  |  | $ | 60.6 |  |
| Granted |  |  |  |  | 1.2 |  |  | 87.0 |  |  | 0.1 |  |  | 86.7 |  |
| Vested |  |  |  |  | (1.0) |  |  | 56.2 |  |  | (0.1) |  |  | 57.8 |  |
| Canceled |  |  |  |  | (0.1) |  |  | 64.1 |  |  | — |  |  | 70.8 |  |
| Balance as of April 3, 2021 |  |  |  |  | 2.0 |  |  | $ | 74.1 |  |  | 0.3 |  |  | $ | 74.4 |  |

[0001633978-21-000009:notes:169]
As of April 3, 2021, $147.2 million of stock-based compensation cost related to awards granted to our employees remains to be amortized. That cost is expected to be recognized over an estimated amortization period of 1.9 years.

[0001633978-21-000009:notes:170]
[same as prior period, unchanged from 0001633978-21-000004:notes:168]

[0001633978-21-000009:notes:171]
|  | Awards Available for Grant |
| Balance as of June 27, 2020 | 3.5 |  |
| Granted | (1.3) |  |
| Canceled | 0.1 |  |
| Balance as of April 3, 2021 | 2.3 |  |

[0001633978-21-000009:notes:172]
Employee Stock Purchase Plan Activity
The 2015 Purchase Plan expense for the three months ended April 3, 2021 and March 28, 2020 was $1.2 million and $0.8 million, respectively. The 2015 Purchase Plan expense for the nine months ended April 3, 2021 and March 28, 2020 was $3.5 million and $2.5 million, respectively. The expense related to the 2015 Purchase Plan is recorded on a straight-line basis over the relevant subscription period. During the three and nine months ended April 3, 2021, there were 0.1 million shares issued to employees through the 2015 Purchase Plan.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001633978-21-000009:notes:173]
Note 14. Commitments and Contingencies

[0001633978-21-000009:notes:174]
Purchase Obligations

[0001633978-21-000009:notes:175]
Purchase obligations of $224.9 million as of April 3, 2021, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements.

[0001633978-21-000009:notes:176]
Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001633978-21-000009:notes:177]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with such vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

[0001633978-21-000009:notes:178]
Product Warranties

[0001633978-21-000009:notes:179]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, product components or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001633978-21-000009:notes:180]
The following table presents the changes in our warranty reserve during the three and nine months ended April 3, 2021 and March 28, 2020 (in millions):

[0001633978-21-000009:notes:181]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 3, 2021 |  | March 28, 2020 |  | April 3, 2021 |  | March 28, 2020 |
| Balance as of beginning of period | $ | 5.7 |  |  | $ | 6.8 |  |  | $ | 5.0 |  |  | $ | 7.5 |  |
| Provision for warranty | 1.7 |  |  | 0.7 |  |  | 5.8 |  |  | 2.5 |  |
| Utilization of reserve | (1.8) |  |  | (2.1) |  |  | (5.2) |  |  | (4.6) |  |
| Balance as of end of period | $ | 5.6 |  |  | $ | 5.4 |  |  | $ | 5.6 |  |  | $ | 5.4 |  |

[0001633978-21-000009:notes:182]
Environmental Liabilities

[0001633978-21-000009:notes:183]
Our research and development (“R&D”), manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental, product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001633978-21-000009:notes:184]
Legal Proceedings

[0001633978-21-000009:notes:185]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss.

[0001633978-21-000009:notes:186]
Merger Litigation

[0001633978-21-000009:notes:187]
In connection with our acquisition of Oclaro, seven lawsuits were filed by purported stockholders of Oclaro challenging the proposed merger (the “Merger”). Two of the seven suits were putative class actions filed against Oclaro, its directors, Lumentum, Prota Merger Sub, Inc. and Prota Merger, LLC: Nicholas Neinast v. Oclaro, Inc., et al., No. 3:18-cv-03112-VC, in the United States District Court for the Northern District of California (filed May 24, 2018) (the “Neinast Lawsuit”); and Adam Franchi v. Oclaro, Inc., et al., No. 1:18-cv-00817-GMS, in the United States District Court for the District of Delaware (filed June 9, 2018) (the “Franchi Lawsuit”). Both the Neinstat Lawsuit and the Franchi Lawsuit were voluntarily dismissed with prejudice.

[0001633978-21-000009:notes:188]
The other five suits, styled as Gerald F. Wordehoff v. Oclaro, Inc., et al., No. 5:18-cv-03148-NC (the “Wordehoff Lawsuit”), Walter Ryan v. Oclaro, Inc., et al., No. 3:18-cv-03174-VC (the “Ryan Lawsuit”), Jayme Walker v. Oclaro, Inc., et al., No. 5:18-cv-03203-EJD (the “Walker Lawsuit”), Kevin Garcia v. Oclaro, Inc., et al., No. 5:18-cv-03262-VKD (the “Garcia Lawsuit”), and SaiSravan B. Karri v. Oclaro, Inc., et al., No. 3:18-cv-03435-JD (the “Karri Lawsuit” and, together with the other six lawsuits, the “Lawsuits”), were filed in the United States District Court for the Northern District of California on May 25, 2018, May 29, 2018, May 30, 2018, May 31, 2018, and June 9, 2018, respectively. These five Lawsuits named Oclaro and its directors as defendants only and did not name Lumentum. The Wordehoff, Ryan, Walker, and Garcia Lawsuits have been voluntarily dismissed, and the Wordehoff, Ryan, and Walker dismissals were with prejudice. The Karri Lawsuit has not yet been dismissed. The Ryan Lawsuit was, and the Karri Lawsuit is, a putative class action.

[0001633978-21-000009:notes:189]
The Lawsuits generally alleged, among other things, that Oclaro and its directors violated Section 14(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), and Rule 14a-9 promulgated thereunder by disseminating an incomplete and misleading Form S-4, including proxy statement/prospectus. The Lawsuits further alleged that Oclaro’s directors violated Section 20(a) of the Exchange Act by failing to exercise proper control over the person(s) who violated Section 14(a) of the Exchange Act.

[0001633978-21-000009:notes:190]
The remaining Lawsuit (the Karri Lawsuit) currently purports to seek, among other things, damages to be awarded to the plaintiff and any class, if a class is certified, and litigation costs, including attorneys’ fees.  A lead plaintiff and counsel has been selected, and an amended complaint was filed on April 15, 2019, which also names Lumentum as a defendant. A motion to dismiss the amended complaint was granted in part and denied in part by the court on October 8, 2020. On December 1, 2020, defendants answered the amended complaint.  On December 23, 2020, defendants filed a motion for leave to file a motion for reconsideration of the Court’s October 8 order on the motion to dismiss, which was denied on January 29, 2021. The Karri Lawsuit remains pending with the parties currently in discovery. Defendants intend to defend the Karri Lawsuit vigorously.

[0001633978-21-000009:notes:191]
Indemnifications

[0001633978-21-000009:notes:192]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of April 3, 2021, we did not have any material indemnification claims that were probable or reasonably possible.

[0001633978-21-000009:notes:193]
Audit Proceedings

[0001633978-21-000009:notes:194]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001633978-21-000009:notes:195]
[same as prior period, unchanged from 0001633978-21-000004:notes:194]

[0001633978-21-000009:notes:196]
[same as prior period, unchanged from 0001633978-21-000004:notes:195]

[0001633978-21-000009:notes:197]
[same as prior period, unchanged from 0001633978-21-000004:notes:196]

[0001633978-21-000009:notes:198]
[same as prior period, unchanged from 0001633978-21-000004:notes:197]

[0001633978-21-000009:notes:199]
[same as prior period, unchanged from 0001633978-21-000004:notes:198]

[0001633978-21-000009:notes:200]
[same as prior period, unchanged from 0001633978-21-000004:notes:199]

[0001633978-21-000009:notes:201]
[same as prior period, unchanged from 0001633978-21-000004:notes:200]

[0001633978-21-000009:notes:202]
[same as prior period, unchanged from 0001633978-21-000004:notes:201]

[0001633978-21-000009:notes:203]
[same as prior period, unchanged from 0001633978-21-000004:notes:202]

[0001633978-21-000009:notes:204]
[same as prior period, unchanged from 0001633978-21-000004:notes:203]

[0001633978-21-000009:notes:205]
[same as prior period, unchanged from 0001633978-21-000004:notes:204]

[0001633978-21-000009:notes:206]
[same as prior period, unchanged from 0001633978-21-000004:notes:205]

[0001633978-21-000009:notes:207]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 3, 2021 |  | March 28, 2020 |  | April 3, 2021 |  | March 28, 2020 |
| Net revenue: |  |  |  |  |  |  |  |
| OpComms | $ | 387.9 |  |  | $ | 359.3 |  |  | $ | 1,265.5 |  |  | $ | 1,184.8 |  |
| Lasers | 31.6 |  |  | 43.5 |  |  | 85.2 |  |  | 125.7 |  |
| Net revenue | $ | 419.5 |  |  | $ | 402.8 |  |  | $ | 1,350.7 |  |  | $ | 1,310.5 |  |
| Gross profit: |  |  |  |  |  |  |  |
| OpComms | $ | 194.3 |  |  | $ | 161.8 |  |  | $ | 660.9 |  |  | $ | 550.1 |  |
| Lasers | 14.9 |  |  | 21.6 |  |  | 39.4 |  |  | 56.2 |  |
| Total segment gross profit | 209.2 |  |  | 183.4 |  |  | 700.3 |  |  | 606.3 |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Stock-based compensation | (5.3) |  |  | (4.3) |  |  | (13.8) |  |  | (12.6) |  |
| Amortization of acquired intangibles | (15.8) |  |  | (13.9) |  |  | (45.8) |  |  | (38.8) |  |
| Amortization of inventory fair value adjustments | — |  |  | (1.5) |  |  | — |  |  | (5.8) |  |
| Inventory and fixed asset write down due to product line exits | — |  |  | (2.3) |  |  | (0.4) |  |  | (6.0) |  |
| Integration related costs | — |  |  | 0.3 |  |  | — |  |  | (3.1) |  |
| Other charges (1) | (3.1) |  |  | (4.0) |  |  | (20.0) |  |  | (25.5) |  |
| Gross profit | $ | 185.0 |  |  | $ | 157.7 |  |  | $ | 620.3 |  |  | $ | 514.5 |  |

[0001633978-21-000009:notes:208]
(1) “Other charges” of unallocated corporate items for the three and nine months ended April 3, 2021 include costs of transferring product lines to new production facilities, including Thailand of $1.4 million and $6.5 million, respectively. We also incurred excess and obsolete inventory charges driven by U.S. trade restrictions and the related decline in demand from Huawei of $1.0 million and $7.7 million during the three and nine months ended April 3, 2021, respectively. Our excess and obsolete inventory charges related to Huawei were offset by $2.1 million of sale of inventory previously written down during the three and nine months ended April 3, 2021. During the nine months ended April 3, 2021, there was also a $5.0 million impairment charge associated with excess capacity related to our Fiber laser business.

[0001633978-21-000009:notes:209]
“Other charges” of unallocated corporate items for the three and nine months ended March 28, 2020 primarily include costs of transferring product lines to new production facilities, including Thailand of $0.4 million and $8.5 million, respectively. We also incurred excess and obsolete inventory charges driven by the decline in demand from Huawei of $0.1 million and $12.8 million during the three and nine months ended March 28, 2020. In addition, there were expenses of $1.6 million related to the COVID-19 outbreak during the three and nine months ended March 28, 2020.

[0001633978-21-000009:notes:210]
[same as prior period, unchanged from 0001633978-21-000004:notes:209]

[0001633978-21-000009:notes:211]
[same as prior period, unchanged from 0001633978-21-000004:notes:210]

[0001633978-21-000009:notes:212]
[same as prior period, unchanged from 0001633978-21-000004:notes:211]

[0001633978-21-000009:notes:213]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 3, 2021 |  | March 28, 2020 |  | April 3, 2021 |  | March 28, 2020 |
| OpComms: |  |  |  |  |  |  |  |  |  |  |  |
| Telecom and Datacom | $ | 255.8 |  | 61.0 | % |  | $ | 251.0 |  | 62.3 | % |  | $ | 803.3 |  | 59.5 | % |  | $ | 765.4 |  | 58.4 | % |
| Consumer and Industrial | 132.1 |  | 31.5 |  |  | 108.3 |  | 26.9 |  |  | 462.2 |  | 34.2 |  |  | 419.4 |  | 32.0 |  |
| Total OpComms | $ | 387.9 |  | 92.5 | % |  | $ | 359.3 |  | 89.2 | % |  | $ | 1,265.5 |  | 93.7 | % |  | $ | 1,184.8 |  | 90.4 | % |
| Lasers | 31.6 |  | 7.5 |  |  | 43.5 |  | 10.8 |  |  | 85.2 |  | 6.3 |  |  | 125.7 |  | 9.6 |  |
| Total Revenue | $ | 419.5 |  |  |  | $ | 402.8 |  |  |  | $ | 1,350.7 |  |  |  | $ | 1,310.5 |  |  |

[0001633978-21-000009:notes:214]
[same as prior period, unchanged from 0001633978-21-000004:notes:213]

[0001633978-21-000009:notes:215]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 3, 2021 |  | March 28, 2020 |  | April 3, 2021 |  | March 28, 2020 |
| Net revenue: | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 38.2 |  |  | 9.1 | % |  | $ | 38.6 |  |  | 9.6 | % |  | $ | 98.2 |  |  | 7.3 | % |  | $ | 118.9 |  |  | 9.1 | % |
| Mexico | 16.3 |  |  | 3.9 |  |  | 33.2 |  |  | 8.2 |  |  | 107.4 |  |  | 8.0 |  |  | 88.3 |  |  | 6.7 |  |
| Other Americas | 3.7 |  |  | 0.9 |  |  | 1.4 |  |  | 0.3 |  |  | 10.5 |  |  | 0.7 |  |  | 3.2 |  |  | 0.3 |  |
| Total Americas | $ | 58.2 |  |  | 13.9 | % |  | $ | 73.2 |  |  | 18.1 | % |  | $ | 216.1 |  |  | 16.0 | % |  | $ | 210.4 |  |  | 16.1 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 134.2 |  |  | 32.0 | % |  | $ | 125.9 |  |  | 31.3 | % |  | $ | 426.6 |  |  | 31.6 | % |  | $ | 404.2 |  |  | 30.8 | % |
| Philippines | 30.9 |  |  | 7.4 |  |  | 14.3 |  |  | 3.6 |  |  | 134.3 |  |  | 9.9 |  |  | 44.1 |  |  | 3.4 |  |
| South Korea | 63.3 |  |  | 15.1 |  |  | 63.3 |  |  | 15.7 |  |  | 185.3 |  |  | 13.7 |  |  | 239.9 |  |  | 18.3 |  |
| Other Asia-Pacific | 96.6 |  |  | 22.9 |  |  | 98.7 |  |  | 24.5 |  |  | 282.2 |  |  | 20.9 |  |  | 315.1 |  |  | 24.0 |  |
| Total Asia-Pacific | $ | 325.0 |  |  | 77.4 | % |  | $ | 302.2 |  |  | 75.1 | % |  | $ | 1,028.4 |  |  | 76.1 | % |  | $ | 1,003.3 |  |  | 76.5 | % |
| EMEA | $ | 36.3 |  |  | 8.7 | % |  | $ | 27.4 |  |  | 6.8 | % |  | $ | 106.2 |  |  | 7.9 | % |  | $ | 96.8 |  |  | 7.4 | % |
| Total net revenue | $ | 419.5 |  |  |  |  | $ | 402.8 |  |  |  |  | $ | 1,350.7 |  |  |  |  | $ | 1,310.5 |  |  |  |

[0001633978-21-000009:notes:216]
During the three and nine months ended April 3, 2021 compared to the three and nine months ended March 28, 2020, our net revenue from the Philippines grew due to an introduction of a new product to one of our large customers.

[0001633978-21-000009:notes:217]
[same as prior period, unchanged from 0001633978-21-000004:notes:216]

[0001633978-21-000009:notes:218]
The following table includes estimated revenue expected to be recognized in the future for backlog related performance obligations that are unsatisfied as of April 3, 2021 (in millions):

[0001633978-21-000009:notes:219]
|  | Less than 1 year | 1-2 years | Greater than 2 years | Total |
| Performance obligations | $415.2 | $11.4 | $— | $426.6 |

[0001633978-21-000009:notes:220]
[same as prior period, unchanged from 0001633978-21-000004:notes:219]

[0001633978-21-000009:notes:221]
The following table reflects the changes in contract balances as of April 3, 2021 (in millions, except percentages):

[0001633978-21-000009:notes:222]
| Contract balances | Balance sheet location | April 3, 2021 |  | June 27, 2020 |  | Change |  | Percentage Change |
| Accounts receivable, net | Accounts receivable, net | $224.8 |  | $233.5 |  | $(8.7) |  | (3.7)% |
| Deferred revenue and customer deposits | Other current liabilities | $1.8 |  | $1.9 |  | $(0.1) |  | (5.3)% |

[0001633978-21-000009:notes:223]
During the three and nine months ended April 3, 2021, our net revenue from a single customer, which represented 10% or greater of total net revenue was concentrated with two and three customers, who collectively accounted for 44% and 53% of our total net revenue, respectively.

[0001633978-21-000009:notes:224]
During the three and nine months ended March 28, 2020, our net revenue from a single customer, which represented 10% or greater of total net revenue was concentrated with two customers, who collectively accounted for 37% and 42% of our total net revenue, respectively.

[0001633978-21-000009:notes:225]
As of April 3, 2021, our accounts receivable balance was concentrated with two customers, which individually represented 10% or greater of gross accounts receivable and collectively accounted for 27% of the balance. As of June 27, 2020, one customer represented 10% or greater of gross accounts receivable and accounted for 14% of the balance.

[0001633978-21-000009:notes:226]
Long-lived assets, namely property, plant and equipment, net, were identified based on the physical location of the assets in the corresponding geographic areas as of the periods indicated (in millions):

[0001633978-21-000009:notes:227]
|  | April 3, 2021 |  | June 27, 2020 |
| Property, plant and equipment, net |  |  |  |
| United States | $ | 135.5 |  |  | $ | 139.1 |  |
| Thailand | 107.7 |  |  | 122.6 |  |
| China | 40.7 |  |  | 43.2 |  |
| Japan | 34.4 |  |  | 32.3 |  |
| Other countries | 59.7 |  |  | 55.8 |  |
| Total property, plant and equipment, net | $ | 378.0 |  |  | $ | 393.0 |  |

[0001633978-21-000009:notes:228]
We purchase a substantial portion of our inventory from contract manufacturers and vendors located primarily in Taiwan, Thailand, and Malaysia. During the three and nine months ended April 3, 2021, our net inventory purchases from a single contract manufacturer, which represented 10% or greater of total net purchases, were concentrated with two contract manufacturers, who collectively accounted for 62% and 64% of total net inventory purchases, respectively. During the three and nine months ended March 28, 2020, net inventory purchases which represented 10% or greater of total net purchases, were concentrated with three and two contract manufacturers, who collectively accounted for 88% and 85% of total net inventory purchases, respectively.


## us-gaap:SubsequentEventsTextBlock

[0001633978-21-000009:notes:229]
Subsequent EventOn May 7, 2021, our board of directors approved the 2021 share buyback program, which authorizes us to use up to $700 million to purchase our own shares of common stock. The repurchase program is authorized for 2 years but may be suspended or terminated by the board of directors at any time.
