# LITE MD&A — 0001633978-21-000009


## mdna

[0001633978-21-000009:mdna:1]
[same as prior period, unchanged from 0001633978-21-000004:mdna:1]

[0001633978-21-000009:mdna:2]
[same as prior period, unchanged from 0001633978-21-000004:mdna:2]

[0001633978-21-000009:mdna:3]
[same as prior period, unchanged from 0001633978-21-000004:mdna:3]

[0001633978-21-000009:mdna:4]
[same as prior period, unchanged from 0001633978-21-000004:mdna:4]

[0001633978-21-000009:mdna:5]
We are an industry-leading provider of optical and photonic products, defined by revenue and market share, addressing a range of end-market applications including Optical Communications, which we refer to as OpComms, and Lasers for manufacturing, inspection and life-science applications. We have two operating segments, OpComms and Lasers. The two operating segments were primarily determined based on how the Chief Operating Decision Maker (“CODM”) views and evaluates our operations. Operating results are regularly reviewed by the CODM to make decisions about resources to be allocated to the segments and to assess their performance. Other factors, including market separation and customer specific applications, go-to-market channels, products and manufacturing, are considered in determining the formation of these operating segments.

[0001633978-21-000009:mdna:6]
We believe the global markets in which Lumentum participates have fundamentally robust, long-term trends that increase the need for our photonics products and technologies. We believe the world is becoming more reliant on ever-increasing amounts of data flowing through optical networks and data centers. Lumentum’s products and technology enable the scaling of these optical networks and data centers to higher capacities. We expect the accelerating shift to digital and virtual approaches to all aspects of work and life that is driving staggering amounts of data in the world’s networks and cloud datacenters will continue into the future. Virtual meetings, video calls, and hybrid in-person and virtual environments for work and other aspects of life will continue to drive strong needs for bandwidth growth and present dynamic new technology challenges that our technology addresses. As manufacturers demand higher levels of precision, new materials, and factory and energy efficiency, suppliers of manufacturing tools globally are turning to laser based approaches, including the types of lasers Lumentum supplies. Laser based 3D sensing and LiDAR is a rapidly developing market. The technology enables computer vision applications that enhance security, safety, and new functionality in the electronic devices that people rely on every day. The use of LiDAR and in-cabin 3D sensing in automobile and delivery vehicles over time significantly adds to our long-term market opportunity. Frictionless and contactless biometric security and access control is of increasing focus globally given the world’s experience with COVID-19. Additionally, we expect 3D enabled machine vision solutions to expand significantly in industrial applications in the coming years.

[0001633978-21-000009:mdna:7]
To maintain and grow our market and technology leadership positions, we are continually investing in new and differentiated products and technologies and customer programs that address both nearer-term and longer-term growth opportunities, as well as continually improving and optimizing our operations. Over many years, we have developed close relationships with market leading customers. We seek to use our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide.

[0001633978-21-000009:mdna:8]
Termination of Coherent Merger Agreement

[0001633978-21-000009:mdna:9]
On January 18, 2021, we entered into a merger agreement with Coherent, under which we would acquire all outstanding shares of Coherent common stock. In March 2021, Coherent terminated the merger agreement and paid us a termination fee of $217.6 million in accordance with the merger agreement. This gain was offset by $10.1 million of acquisition related expenses and the net amount is presented as “merger termination fee and related costs, net” in our condensed consolidated statements of operations for the three and nine months ended April 3, 2021.

[0001633978-21-000009:mdna:10]
[same as prior period, unchanged from 0001633978-21-000004:mdna:11]

[0001633978-21-000009:mdna:11]
The COVID-19 pandemic has caused public health officials to recommend, and governments to enact, precautions to mitigate the spread of the virus, including travel restrictions and bans, extensive social distancing guidelines, closure or restrictions on business and quarantine or other types of “shelter-in-place” orders in many regions of the world. The pandemic and these related responses have caused, and are expected to continue to cause a global slowdown of economic activity (including a decrease in demand for a broad variety of goods and services), disruptions in global supply chains and significant volatility and potential disruption of financial markets. We have adopted several measures in response to the COVID-19 outbreak including complying with local, state or federal orders that require employees to work from home, instructing employees to work from home in certain jurisdictions, limiting the number of employees onsite which slowed our manufacturing operations in certain countries, enhanced use of personal protective equipment and restricting non-critical business travel by our employees.

[0001633978-21-000009:mdna:12]
[same as prior period, unchanged from 0001633978-21-000004:mdna:13]

[0001633978-21-000009:mdna:13]
While the recent outbreak of the COVID-19 did not have a material adverse effect on our reported results for our third quarter of fiscal 2021, we are actively monitoring the impact of the coronavirus outbreak. The extent to which our operations will be impacted by the outbreak will depend largely on future developments, which are highly uncertain and cannot be accurately predicted, including new information which may emerge concerning the severity of the outbreak, the speed, efficacy, and acceptance of vaccine distributions, actions by government authorities and private businesses to contain the severity of the outbreak in various geographies and the speed and trajectory of any recovery from the impact of the pandemic, among other things.

[0001633978-21-000009:mdna:14]
COVID-19 has also created dynamics in the semiconductor component supply chains that have led to shortages of the types of components we and our customers require in our products. If we are unable to procure needed semiconductor components, this will impact our ability to supply our products to our customers and may reduce our revenue. If our customers are unable to procure needed semiconductor components, this could reduce their demand for our products and reduce our revenue. The impact of semiconductor component shortages may increase in the near term as supplier and customer buffer inventories and safety stocks are exhausted.

[0001633978-21-000009:mdna:15]
[same as prior period, unchanged from 0001633978-21-000004:mdna:15]

[0001633978-21-000009:mdna:16]
[same as prior period, unchanged from 0001633978-21-000004:mdna:17]

[0001633978-21-000009:mdna:17]
[same as prior period, unchanged from 0001633978-21-000004:mdna:18]

[0001633978-21-000009:mdna:18]
[same as prior period, unchanged from 0001633978-21-000004:mdna:19]

[0001633978-21-000009:mdna:19]
[same as prior period, unchanged from 0001633978-21-000004:mdna:20]

[0001633978-21-000009:mdna:20]
[same as prior period, unchanged from 0001633978-21-000004:mdna:21]

[0001633978-21-000009:mdna:21]
[same as prior period, unchanged from 0001633978-21-000004:mdna:22]

[0001633978-21-000009:mdna:22]
[same as prior period, unchanged from 0001633978-21-000004:mdna:23]

[0001633978-21-000009:mdna:23]
Management’s Discussion and Analysis of Financial Condition and Results of Operations contained in Part II, Item 7 of our Annual Report on Form 10-K for our fiscal year ended June 27, 2020 provides a more complete discussion of our critical accounting policies and estimates. There have been no significant changes to these policies during the nine months ended April 3, 2021, except for the removal of the long-lived asset valuation policy and the updates resulting from the adoption of Topic 326, as discussed in “Note 2. Recently Issued Accounting Pronouncements”.

[0001633978-21-000009:mdna:24]
Recently Issued Accounting Pronouncements

[0001633978-21-000009:mdna:25]
Refer to “Note 2. Recently Issued Accounting Pronouncements” in the notes to condensed consolidated financial statements.

[0001633978-21-000009:mdna:26]
[same as prior period, unchanged from 0001633978-21-000004:mdna:27]

[0001633978-21-000009:mdna:27]
[same as prior period, unchanged from 0001633978-21-000004:mdna:28]

[0001633978-21-000009:mdna:28]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 3, 2021 |  | March 28, 2020 |  | April 3, 2021 |  | March 28, 2020 |
| Segment net revenue: |  |  |  |  |  |  |  |
| OpComms | 92.5 | % |  | 89.2 | % |  | 93.7 | % |  | 90.4 | % |
| Lasers | 7.5 |  |  | 10.8 |  |  | 6.3 |  |  | 9.6 |  |
| Net revenue | 100.0 |  |  | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of sales | 52.1 |  |  | 57.4 |  |  | 50.7 |  |  | 57.8 |  |
| Amortization of acquired developed intangibles | 3.8 |  |  | 3.5 |  |  | 3.4 |  |  | 3.0 |  |
| Gross profit | 44.1 |  |  | 39.2 |  |  | 45.9 |  |  | 39.3 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 13.6 |  |  | 12.1 |  |  | 11.9 |  |  | 11.4 |  |
| Selling, general and administrative | 15.6 |  |  | 15.2 |  |  | 13.6 |  |  | 13.8 |  |
| Restructuring and related charges | 0.7 |  |  | 0.7 |  |  | 0.2 |  |  | 0.4 |  |
| Merger termination fee and related costs, net | (49.5) |  |  | — |  |  | (15.4) |  |  | — |  |
| Impairment charges | — |  |  | 0.6 |  |  | — |  |  | 0.2 |  |
| Total operating expenses (income) | (19.5) |  |  | 28.6 |  |  | 10.3 |  |  | 25.7 |  |
| Income from operations | 63.6 |  |  | 10.6 |  |  | 35.6 |  |  | 13.5 |  |
| Interest expense | (3.9) |  |  | (3.9) |  |  | (3.6) |  |  | (3.5) |  |
| Other income (expense), net | 0.6 |  |  | 5.4 |  |  | 0.2 |  |  | 2.1 |  |
| Income before income taxes | 60.3 |  |  | 12.1 |  |  | 32.2 |  |  | 12.2 |  |
| Provision for income taxes | 6.5 |  |  | 1.3 |  |  | 4.4 |  |  | 1.5 |  |
| Net income | 53.8 | % |  | 10.8 | % |  | 27.8 | % |  | 10.7 | % |

[0001633978-21-000009:mdna:29]
36

[0001633978-21-000009:mdna:30]
Financial Data for the three and nine months ended April 3, 2021 and March 28, 2020

[0001633978-21-000009:mdna:31]
[same as prior period, unchanged from 0001633978-21-000004:mdna:32]

[0001633978-21-000009:mdna:32]
|  | Three Months Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | April 3, 2021 |  | March 28, 2020 |  | Change |  | Percentage Change |  | April 3, 2021 |  | March 28, 2020 |  | Change |  | Percentage Change |
| Segment net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| OpComms | $ | 387.9 |  |  | $ | 359.3 |  |  | $ | 28.6 |  |  | 8.0 | % |  | $ | 1,265.5 |  |  | $ | 1,184.8 |  |  | $ | 80.7 |  |  | 6.8 | % |
| Lasers | 31.6 |  |  | 43.5 |  |  | (11.9) |  |  | (27.4) |  |  | 85.2 |  |  | 125.7 |  |  | (40.5) |  |  | (32.2) |  |
| Net revenue | $ | 419.5 |  |  | $ | 402.8 |  |  | $ | 16.7 |  |  | 4.1 | % |  | $ | 1,350.7 |  |  | $ | 1,310.5 |  |  | $ | 40.2 |  |  | 3.1 | % |
| Gross profit | $ | 185.0 |  |  | $ | 157.7 |  |  | $ | 27.3 |  |  | 17.3 | % |  | $ | 620.3 |  |  | $ | 514.5 |  |  | $ | 105.8 |  |  | 20.6 | % |
| Gross margin | 44.1 | % |  | 39.2 | % |  |  |  |  |  | 45.9 | % |  | 39.3 | % |  |  |  |  |
| Research and development | $ | 57.2 |  |  | $ | 48.7 |  |  | $ | 8.5 |  |  | 17.5 | % |  | $ | 160.4 |  |  | $ | 149.6 |  |  | $ | 10.8 |  |  | 7.2 | % |
| Percentage of net revenue | 13.6 | % |  | 12.1 | % |  |  |  |  |  | 11.9 | % |  | 11.4 | % |  |  |  |  |
| Selling, general and administrative | $ | 65.5 |  |  | $ | 61.3 |  |  | $ | 4.2 |  |  | 6.9 | % |  | $ | 183.1 |  |  | $ | 180.4 |  |  | $ | 2.7 |  |  | 1.5 | % |
| Percentage of net revenue | 15.6 | % |  | 15.2 | % |  |  |  |  |  | 13.6 | % |  | 13.8 | % |  |  |  |  |
| Restructuring and related charges | $ | 2.9 |  |  | $ | 2.7 |  |  | $ | 0.2 |  |  | 7.4 | % |  | $ | 3.1 |  |  | $ | 4.9 |  |  | $ | (1.8) |  |  | (36.7) | % |
| Percentage of net revenue | 0.7 | % |  | 0.7 | % |  |  |  |  |  | 0.2 | % |  | 0.4 | % |  |  |  |  |
| Merger termination fee and related costs, net | $ | (207.5) |  |  | $ | — |  |  | $ | (207.5) |  |  | N/A |  | $ | (207.5) |  |  | $ | — |  |  | $ | (207.5) |  |  | N/A |
| Percentage of net revenue | (49.5) | % |  | — | % |  |  |  |  |  | (15.4) | % |  | — | % |  |  |  |  |
| Impairment charges | $ | — |  |  | $ | 2.5 |  |  | $ | (2.5) |  |  | (100.0) | % |  | $ | — |  |  | $ | 2.5 |  |  | $ | (2.5) |  |  | (100.0) | % |
| Percentage of net revenue | — | % |  | 0.6 | % |  |  |  |  |  | — | % |  | 0.2 | % |  |  |  |  |

[0001633978-21-000009:mdna:33]
[same as prior period, unchanged from 0001633978-21-000004:mdna:34]

[0001633978-21-000009:mdna:34]
Net revenue increased by $16.7 million, or 4.1%, during the three months ended April 3, 2021 compared to the three months ended March 28, 2020. This increase was primarily due to increased revenue in OpComms of $28.6 million, offset by decreased sales of Lasers of $11.9 million. These results include a deferral of $14.8 million of revenue due to delays in 5G deployments in China.

[0001633978-21-000009:mdna:35]
OpComms net revenue increased by $28.6 million, or 8.0%, during the three months ended April 3, 2021 compared to the three months ended March 28, 2020. Within Opcomms, Telecom and Datacom increased by $4.8 million primarily due to the extra week in the third quarter of fiscal 2021. These results include a deferral of $14.8 million of revenue due to delays in 5G deployments in China. Industrial and Consumer increased by $23.8 million due to the extra week and an expansion of the available market due to an increased dollar content of 3D sensing lasers and higher adoption rates of 3D sensing in consumer electronic devices compared with the prior year. Within Telecom and Datacom, sales of Datacom transceiver products and Lithium Niobate modulators, products, which we are winding down, decreased by $12.8 million.

[0001633978-21-000009:mdna:36]
Lasers net revenue decreased by $11.9 million, or 27.4%, during the three months ended April 3, 2021 compared to the three months ended March 28, 2020, primarily due to COVID-19 reducing customer demand for our kilowatt class fiber lasers.

[0001633978-21-000009:mdna:37]
Net revenue increased by $40.2 million, or 3.1%, during the nine months ended April 3, 2021 compared to the nine months ended March 28, 2020. This increase was primarily due to $80.7 million higher OpComms net revenue, offset by $40.5 million lower sales of Lasers.

[0001633978-21-000009:mdna:38]
OpComms net revenue increased by $80.7 million, or 6.8%, during the nine months ended April 3, 2021 compared to the nine months ended March 28, 2020. Within OpComms, sales of Telecom and Datacom increased by $37.9 million and Industrial and Consumer increased by $42.8 million. The Telecom and Datacom increase was primarily due to increased sales of Datacom chips due to market share gains and increased sales of Telecom due to market growth and recovery from the impact of COVID-19 supply constraints, which more than offset the $52.2 million lower sales from product lines we are winding down, such as Datacom transceiver modules and certain Lithium Niobate product lines. These results include a deferral of $14.8 million of revenue due to delays in 5G deployments in China. The Industrial and Consumer increase was primarily driven by an expansion of the available market due to an increased dollar content of 3D sensing lasers and higher adoption rates of 3D sensing in consumer electronic devices compared with the prior comparable period.

[0001633978-21-000009:mdna:39]
Lasers net revenue decreased by $40.5 million, or 32.2%, during the nine months ended April 3, 2021 compared to the nine months ended March 28, 2020, primarily due to COVID-19 reducing customer demand for our kilowatt class fiber lasers.

[0001633978-21-000009:mdna:40]
During the three and nine months ended April 3, 2021, our net revenue from a single customer, which represented 10% or greater of total net revenue was concentrated with two and three customers, who collectively accounted for 44% and 53% of our total net revenue, respectively.

[0001633978-21-000009:mdna:41]
During the three and nine months ended March 28, 2020, our net revenue from a single customer, which represented 10% or greater of total net revenue was concentrated with two customers, who collectively accounted for 37% and 42% of our total net revenue, respectively.

[0001633978-21-000009:mdna:42]
[same as prior period, unchanged from 0001633978-21-000004:mdna:43]

[0001633978-21-000009:mdna:43]
[same as prior period, unchanged from 0001633978-21-000004:mdna:44]

[0001633978-21-000009:mdna:44]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 3, 2021 |  | March 28, 2020 |  | April 3, 2021 |  | March 28, 2020 |
| Net revenue: | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 38.2 |  |  | 9.1 | % |  | $ | 38.6 |  |  | 9.6 | % |  | $ | 98.2 |  |  | 7.3 | % |  | $ | 118.9 |  |  | 9.1 | % |
| Mexico | 16.3 |  |  | 3.9 |  |  | 33.2 |  |  | 8.2 |  |  | 107.4 |  |  | 8.0 |  |  | 88.3 |  |  | 6.7 |  |
| Other Americas | 3.7 |  |  | 0.9 |  |  | 1.4 |  |  | 0.3 |  |  | 10.5 |  |  | 0.7 |  |  | 3.2 |  |  | 0.3 |  |
| Total Americas | $ | 58.2 |  |  | 13.9 | % |  | $ | 73.2 |  |  | 18.1 | % |  | $ | 216.1 |  |  | 16.0 | % |  | $ | 210.4 |  |  | 16.1 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 134.2 |  |  | 32.0 | % |  | $ | 125.9 |  |  | 31.3 | % |  | $ | 426.6 |  |  | 31.6 | % |  | $ | 404.2 |  |  | 30.8 | % |
| Philippines | 30.9 |  |  | 7.4 |  |  | 14.3 |  |  | 3.6 |  |  | 134.3 |  |  | 9.9 |  |  | 44.1 |  |  | 3.4 |  |
| South Korea | 63.3 |  |  | 15.1 |  |  | 63.3 |  |  | 15.7 |  |  | 185.3 |  |  | 13.7 |  |  | 239.9 |  |  | 18.3 |  |
| Other Asia-Pacific | 96.6 |  |  | 22.9 |  |  | 98.7 |  |  | 24.5 |  |  | 282.2 |  |  | 20.9 |  |  | 315.1 |  |  | 24.0 |  |
| Total Asia-Pacific | $ | 325.0 |  |  | 77.4 | % |  | $ | 302.2 |  |  | 75.1 | % |  | $ | 1,028.4 |  |  | 76.1 | % |  | $ | 1,003.3 |  |  | 76.5 | % |
| EMEA | $ | 36.3 |  |  | 8.7 | % |  | $ | 27.4 |  |  | 6.8 | % |  | $ | 106.2 |  |  | 7.9 | % |  | $ | 96.8 |  |  | 7.4 | % |
| Total net revenue | $ | 419.5 |  |  |  |  | $ | 402.8 |  |  |  |  | $ | 1,350.7 |  |  |  |  | $ | 1,310.5 |  |  |  |

[0001633978-21-000009:mdna:45]
For the three and nine months ended April 3, 2021, net revenue from customers outside the United States, based on customer shipping location, represented 90.9% and 92.7% of net revenue, respectively.

[0001633978-21-000009:mdna:46]
For the three and nine months ended March 28, 2020, net revenue from customers outside the United States, based on customer shipping location, represented 90.4% and 90.9% of net revenue, respectively.

[0001633978-21-000009:mdna:47]
During the three and nine months ended April 3, 2021 compared to the three and nine months ended March 28, 2020, our net revenue from the Philippines grew due to an introduction of a new product to one of our large customers.

[0001633978-21-000009:mdna:48]
[same as prior period, unchanged from 0001633978-21-000004:mdna:49]

[0001633978-21-000009:mdna:49]
[same as prior period, unchanged from 0001633978-21-000004:mdna:50]

[0001633978-21-000009:mdna:50]
The following table summarizes segment gross margin for the three and nine months ended April 3, 2021 and March 28, 2020 (in millions, except for percentages):

[0001633978-21-000009:mdna:51]
|  | Three Months Ended |  | Nine Months Ended |
|  | Gross Profit |  | Gross Margin |  | Gross Profit |  | Gross Margin |
|  | April 3, 2021 |  | March 28, 2020 |  | April 3, 2021 |  | March 28, 2020 |  | April 3, 2021 |  | March 28, 2020 |  | April 3, 2021 |  | March 28, 2020 |
| OpComms | $ | 194.3 |  |  | $ | 161.8 |  |  | 50.1 | % |  | 45.0 | % |  | $ | 660.9 |  |  | $ | 550.1 |  |  | 52.2 | % |  | 46.4 | % |
| Lasers | 14.9 |  |  | 21.6 |  |  | 47.2 | % |  | 49.7 | % |  | 39.4 |  |  | 56.2 |  |  | 46.2 | % |  | 44.7 | % |
| Segment total | $ | 209.2 |  |  | $ | 183.4 |  |  | 49.9 | % |  | 45.5 | % |  | $ | 700.3 |  |  | $ | 606.3 |  |  | 51.8 | % |  | 46.3 | % |
| Unallocated corporate items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation | (5.3) |  |  | (4.3) |  |  |  |  |  |  | (13.8) |  |  | (12.6) |  |  |  |  |  |
| Amortization of acquired intangibles | (15.8) |  |  | (13.9) |  |  |  |  |  |  | (45.8) |  |  | (38.8) |  |  |  |  |  |
| Amortization of inventory fair value adjustments | — |  |  | (1.5) |  |  |  |  |  |  | — |  |  | (5.8) |  |  |  |  |  |
| Inventory and fixed asset write down due to product line exits | — |  |  | (2.3) |  |  |  |  |  |  | (0.4) |  |  | (6.0) |  |  |  |  |  |
| Integration related costs | — |  |  | 0.3 |  |  |  |  |  |  | — |  |  | (3.1) |  |  |  |  |  |
| Other charges (1) | (3.1) |  |  | (4.0) |  |  |  |  |  |  | (20.0) |  |  | (25.5) |  |  |  |  |  |
| Total | $ | 185.0 |  |  | $ | 157.7 |  |  | 44.1 | % |  | 39.2 | % |  | $ | 620.3 |  |  | $ | 514.5 |  |  | 45.9 | % |  | 39.3 | % |

[0001633978-21-000009:mdna:52]
(1) “Other charges” of unallocated corporate items for the three and nine months ended April 3, 2021 include costs of transferring product lines to new production facilities, including Thailand of $1.4 million and $6.5 million, respectively. We also incurred excess and obsolete inventory charges driven by U.S. trade restrictions and the related decline in demand from Huawei of $1.0 million and $7.7 million during the three and nine months ended April 3, 2021, respectively. Our excess and obsolete inventory charges related to Huawei were offset by $2.1 million of sale of inventory previously written down during the three and nine months ended April 3, 2021. During the nine months ended April 3, 2021, there was also a $5.0 million impairment charge associated with excess capacity related to our Fiber laser business.

[0001633978-21-000009:mdna:53]
“Other charges” of unallocated corporate items for the three and nine months ended March 28, 2020 primarily include costs of transferring product lines to new production facilities, including Thailand of $0.4 million and $8.5 million, respectively. We also incurred excess and obsolete inventory charges driven by the decline in demand from Huawei of $0.1 million and $12.8 million during the three and nine months ended March 28, 2020. In addition, there were expenses of $1.6 million related to the COVID-19 outbreak during the three and nine months ended March 28, 2020.

[0001633978-21-000009:mdna:54]
[same as prior period, unchanged from 0001633978-21-000004:mdna:55]

[0001633978-21-000009:mdna:55]
[same as prior period, unchanged from 0001633978-21-000004:mdna:56]

[0001633978-21-000009:mdna:56]
Gross margin for the three months ended April 3, 2021 increased to 44.1% from 39.2% for the three months ended March 28, 2020. The increase was primarily driven by higher OpComms segment gross margins for the three months ended April 3, 2021 compared to the three months ended March 28, 2020, which more than offset lower Lasers segment gross margins.

[0001633978-21-000009:mdna:57]
Gross margin for the nine months ended April 3, 2021 increased to 45.9% from 39.3% for the nine months ended March 28, 2020. The increase in gross margin was due to both higher OpComms and Lasers segment gross margins.

[0001633978-21-000009:mdna:58]
[same as prior period, unchanged from 0001633978-21-000004:mdna:60]

[0001633978-21-000009:mdna:59]
[same as prior period, unchanged from 0001633978-21-000004:mdna:61]

[0001633978-21-000009:mdna:60]
[same as prior period, unchanged from 0001633978-21-000004:mdna:62]

[0001633978-21-000009:mdna:61]
[same as prior period, unchanged from 0001633978-21-000004:mdna:63]

[0001633978-21-000009:mdna:62]
OpComms gross margin for the three months ended April 3, 2021 increased to 50.1% from 45.0% for the three months ended March 28, 2020. The increase was primarily due to higher manufacturing volumes, a more profitable mix of products, including higher sales of higher margin 3D sensing and lower sales of lower margin Datacom transceiver module and Lithium Niobate modulator products, and the benefits from ongoing operational improvements.

[0001633978-21-000009:mdna:63]
OpComms gross margin for the nine months ended April 3, 2021 increased to 52.2% from 46.4% for the nine months ended March 28, 2020. The increase was primarily due to higher manufacturing volumes, a more profitable mix of products, including higher sales of higher margin 3D sensing and lower sales of lower margin Datacom transceiver module and Lithium Niobate modulator products, and the benefits from ongoing operational improvements.

[0001633978-21-000009:mdna:64]
[same as prior period, unchanged from 0001633978-21-000004:mdna:66]

[0001633978-21-000009:mdna:65]
Lasers gross margin for the three months ended April 3, 2021 decreased to 47.2% from 49.7% for the three months ended March 28, 2020. This decrease was primarily due to the lower manufacturing levels related to COVID-19 reducing customer demand for our kilowatt class fiber products.

[0001633978-21-000009:mdna:66]
Lasers gross margin for the nine months ended April 3, 2021 increased to 46.2% from 44.7% for the nine months ended March 28, 2020. This increase was primarily driven by the streamlining of our manufacturing supply chain related to our kilowatt class fiber products over the past year, offset by the impact of lower manufacturing levels related to COVID-19 reducing customer demand for our kilowatt class fiber products.

[0001633978-21-000009:mdna:67]
[same as prior period, unchanged from 0001633978-21-000004:mdna:69]

[0001633978-21-000009:mdna:68]
R&D expense increased by $8.5 million, or 17.5%, for the three months ended April 3, 2021 compared to the three months ended March 28, 2020. The increase in R&D expense was primarily due to incremental headcount as well as one additional week in the three months ended April 3, 2021, which resulted in an increase in payroll related expense, stock-based compensation, and R&D materials, offset by a reduction in discretionary travel, primarily due to COVID-19 restrictions.

[0001633978-21-000009:mdna:69]
R&D expense increased by $10.8 million, or 7.2%, for the nine months ended April 3, 2021 compared to the nine months ended March 28, 2020. The increase in R&D expense was primarily due to an increase in payroll related expense and stock-based compensation, offset by a decrease in R&D materials, as well as a reduction in discretionary travel, primarily due to COVID-19 restrictions.

[0001633978-21-000009:mdna:70]
[same as prior period, unchanged from 0001633978-21-000004:mdna:72]

[0001633978-21-000009:mdna:71]
[same as prior period, unchanged from 0001633978-21-000004:mdna:73]

[0001633978-21-000009:mdna:72]
SG&A expense increased by $4.2 million, or 6.9%, during the three months ended April 3, 2021 compared to the three months ended March 28, 2020. The increase in SG&A expense was primarily attributable to an increase in stock-based compensation and payroll related expense due to incremental headcount and one additional week in the three months ended April 3, 2021, as well as an increase in acquisition related costs.

[0001633978-21-000009:mdna:73]
SG&A expense increased by $2.7 million, or 1.5%, during the nine months ended April 3, 2021 compared to the nine months ended March 28, 2020. The increase in SG&A expense was primarily due to an increase in payroll related expense due to incremental headcount, an increase in stock-based compensation, an increase in acquisition related costs, offset by lower discretionary travel and trade shows, primarily due to COVID-19 restrictions.

[0001633978-21-000009:mdna:74]
From time to time, we incur non-core expenses, such as mergers and acquisition-related expenses and litigation expenses, which will likely increase our SG&A expenses and potentially impact our profitability expectations in any particular quarter.

[0001633978-21-000009:mdna:75]
[same as prior period, unchanged from 0001633978-21-000004:mdna:77]

[0001633978-21-000009:mdna:76]
[same as prior period, unchanged from 0001633978-21-000004:mdna:78]

[0001633978-21-000009:mdna:77]
During the three and nine months ended April 3, 2021, we recorded restructuring and related charges of $2.9 million and $3.1 million, respectively, in our condensed consolidated statements of operations. The charges were mainly attributable to severance charges associated with the decision to cease manufacturing of certain products in San Jose, California.

[0001633978-21-000009:mdna:78]
During the three and nine months ended March 28, 2020, we recorded $2.7 million and $4.9 million, respectively, in restructuring and related charges in our condensed consolidated statements of operations. The charges were mainly attributable to severance charges associated with the decision to move certain manufacturing from San Jose, California to our facility in Thailand and other third party vendors.

[0001633978-21-000009:mdna:79]
Merger Termination Fee and Related Costs, Net

[0001633978-21-000009:mdna:80]
On January 18, 2021, we entered into a merger agreement with Coherent, under which we would acquire all outstanding shares of Coherent common stock. In March 2021, Coherent terminated the merger agreement and paid us a termination fee of $217.6 million in accordance with the merger agreement. For each of the three and nine months ended April 3, 2021, we recorded $217.6 million gain related to the receipt of a termination fee from Coherent in March 2021 as a result of the termination of our merger agreement. This gain was offset by $10.1 million of Coherent acquisition related charges and presented as “merger termination fee and related costs, net” in our condensed consolidated statements of operations for the three and nine months ended April 3, 2021.

[0001633978-21-000009:mdna:81]
Impairment Charges

[0001633978-21-000009:mdna:82]
For each of the three and nine months ended March 28, 2020, we recorded impairment charges of $2.5 million of property, plant and equipment related to the decision to exit the Datacom transceiver modules product line. We have had no impairments in fiscal 2021 related to this exit.

[0001633978-21-000009:mdna:83]
[same as prior period, unchanged from 0001633978-21-000004:mdna:80]

[0001633978-21-000009:mdna:84]
For the three months ended April 3, 2021 and March 28, 2020, we recorded interest expense of $16.4 million and $15.6 million, respectively.

[0001633978-21-000009:mdna:85]
For the nine months ended April 3, 2021 and March 28, 2020, we recorded interest expense of $48.7 million and $45.3 million, respectively. The increase in interest expense was mainly driven by the increase in amortization of the debt discount and contractual interest expense of our 2026 Notes (as defined below) issued in fiscal 2020, offset by the decrease in contractual interest expense on our term loan facility (which we repaid in full in the second quarter of fiscal 2020) and a loss on early extinguishment of debt.

[0001633978-21-000009:mdna:86]
[same as prior period, unchanged from 0001633978-21-000004:mdna:83]

[0001633978-21-000009:mdna:87]
[same as prior period, unchanged from 0001633978-21-000004:mdna:84]

[0001633978-21-000009:mdna:88]
|  | Three Months Ended |  | Nine Months Ended |  |  |
|  | April 3, 2021 |  | March 28, 2020 |  | April 3, 2021 |  | March 28, 2020 |  |  |
| Foreign exchange gains (losses), net | $ | 1.3 |  |  | $ | 0.7 |  |  | $ | (3.8) |  |  | $ | (0.3) |  |  |  |
| Interest income | 1.0 |  |  | 5.2 |  |  | 4.9 |  |  | 12.6 |  |  |  |
| Other income (expense), net | 0.1 |  |  | 15.8 |  |  | 1.0 |  |  | 15.6 |  |  |  |
| Total other income (expense), net | $ | 2.4 |  |  | $ | 21.7 |  |  | $ | 2.1 |  |  | $ | 27.9 |  |  |  |

[0001633978-21-000009:mdna:89]
For the three and nine months ended April 3, 2021, other income, net decreased by $19.3 million and $25.8 million, respectively, as compared to the three and nine months ended March 28, 2020, mainly driven by a gain on the sale of Lithium Niobate modulators business of $13.8 million recognized in fiscal 2020.

[0001633978-21-000009:mdna:90]
[same as prior period, unchanged from 0001633978-21-000004:mdna:88]

[0001633978-21-000009:mdna:91]
| (in millions) | Three Months Ended |  | Nine Months Ended |
|  | April 3, 2021 |  | March 28, 2020 |  | April 3, 2021 |  | March 28, 2020 |
| Provision for income taxes | $ | 27.4 |  |  | $ | 5.2 |  |  | $ | 58.8 |  |  | $ | 19.6 |  |

[0001633978-21-000009:mdna:92]
We recorded a tax provision of $27.4 million and $5.2 million for the three months ended April 3, 2021 and March 28, 2020, respectively. Our tax provision for the three months ended April 3, 2021 includes a discrete tax expense of $16.8 million mainly from the tax expense associated with the Coherent termination fee partially offset by currency re-measurement of certain tax related accounts and return-to-provision differences. Our estimated effective tax rate for fiscal 2021 differs from the 21% U.S. statutory rate primarily due to the earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate as well as the U.S. federal R&D tax credits, partially offset by the income tax expense from non-deductible stock-based compensation and the tax effect of Global Intangible Low-Taxed Income (“GILTI”), net of benefit for foreign tax credits, and subpart F inclusion.

[0001633978-21-000009:mdna:93]
[same as prior period, unchanged from 0001633978-21-000004:mdna:91]

[0001633978-21-000009:mdna:94]
The following table summarizes our contractual obligations as of April 3, 2021, and the effect such obligations are expected to have on our liquidity and cash flow over the next five years (in millions):

[0001633978-21-000009:mdna:95]
|  | Payments due by period |
|  | Total |  | Less than 1 year |  | 1 - 3 years |  | 3 - 5 years |  | More than 5 years |
| Contractual Obligations |  |  |  |  |  |  |  |  |  |
| Asset retirement obligations | $ | 4.7 |  |  | $ | — |  |  | $ | 0.9 |  |  | $ | 2.3 |  |  | $ | 1.5 |  |
| Finance lease liabilities, including imputed interest | 0.1 |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |
| Operating lease liabilities, including imputed interest (1) | 70.7 |  |  | 14.0 |  |  | 22.4 |  |  | 13.3 |  |  | 21.0 |  |
| Pension plan contributions (2) | 0.5 |  |  | 0.5 |  |  | — |  |  | — |  |  | — |  |
| Purchase obligations (3) | 224.9 |  |  | 222.0 |  |  | 2.8 |  |  | 0.1 |  |  | — |  |
| Convertible notes - principal (4) | 1,500.0 |  |  | — |  |  | 450.0 |  |  | — |  |  | 1,050.0 |  |
| Convertible notes - interest (4) | 34.9 |  |  | 6.4 |  |  | 12.7 |  |  | 10.5 |  |  | 5.3 |  |
| Total | $ | 1,835.8 |  |  | $ | 243.0 |  |  | $ | 488.8 |  |  | $ | 26.2 |  |  | $ | 1,077.8 |  |

[0001633978-21-000009:mdna:96]
(1) The amounts of operating lease liabilities in the table above do not include any sublease income amounts nor do they include payments for short-term leases or variable lease payments. As of April 3, 2021, we expect to receive sublease income of approximately $3.6 million over the next two years. Refer to “Note 7. Leases” in the notes to condensed consolidated financial statements.

[0001633978-21-000009:mdna:97]
[same as prior period, unchanged from 0001633978-21-000004:mdna:95]

[0001633978-21-000009:mdna:98]
(3) Purchase obligations represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Refer to “Note 14. Commitments and Contingencies” in the notes to condensed consolidated financial statements.

[0001633978-21-000009:mdna:99]
(4) Includes principal and interest on our 0.25% Convertible Notes due in 2024 (the “2024 Notes”) through March 2024, and principal and interest on our 0.50% Convertible Notes due in 2026 (the “2026 Notes” and together with the 2024 Notes, the “Notes”) through December 2026. We have the right to redeem the 2024 Notes and the 2026 Notes in whole or in part at any time on or after March 15, 2024 and on or after December 15, 2026, respectively. The principal balances of our Notes are reflected in the payment periods in the table above based on their respective contractual maturities assuming no conversion. Refer to “Note 9. Debt” in the notes to condensed consolidated financial statements.

[0001633978-21-000009:mdna:100]
As of April 3, 2021, our other non-current liabilities also include $26.6 million of unrecognized tax benefit for uncertain tax positions. We are unable to reliably estimate the timing of future payments related to uncertain tax positions and therefore have excluded them from the preceding table.

[0001633978-21-000009:mdna:101]
[same as prior period, unchanged from 0001633978-21-000004:mdna:99]

[0001633978-21-000009:mdna:102]
[same as prior period, unchanged from 0001633978-21-000004:mdna:100]

[0001633978-21-000009:mdna:103]
[same as prior period, unchanged from 0001633978-21-000004:mdna:101]

[0001633978-21-000009:mdna:104]
[same as prior period, unchanged from 0001633978-21-000004:mdna:102]

[0001633978-21-000009:mdna:105]
As of April 3, 2021 and June 27, 2020, our cash and cash equivalents of $687.7 million and $298.0 million, respectively, were largely held in the United States. As of April 3, 2021 and June 27, 2020, our short-term investments of $1,366.9 million and $1,255.8 million, respectively, were all held in the United States. Cash equivalents and short-term investments are primarily comprised of money market funds, treasuries, agencies, high quality investment grade fixed income securities, certificates of deposit, and commercial paper. Our investment policy and strategy is focused on the preservation of capital and supporting our liquidity requirements.

[0001633978-21-000009:mdna:106]
The total amount of cash outside the United States held by the non-US entities as of April 3, 2021 was $100.3 million, which was primarily held by entities incorporated in the United Kingdom, the British Virgin Islands, Japan, Hong Kong, China, Canada, and Thailand. Although the cash currently held in the United States as well as the cash generated in the United States from future operations is expected to cover our normal operating requirements, a substantial amount of additional cash could be required for other purposes, such as capital expenditures to support our business and growth, including costs associated with increasing internal manufacturing capabilities, particularly in our Thailand facility, strategic transactions and partnerships, and future acquisitions.

[0001633978-21-000009:mdna:107]
Our intent is to indefinitely reinvest funds held outside the United States and, except for the funds held in the Cayman Islands, the British Virgin Islands, Japan and Hong Kong, our current plans do not demonstrate a need to repatriate them to fund our domestic operations. However, if in the future, we encounter a significant need for liquidity domestically or at a particular location that we cannot fulfill through borrowings, equity offerings, or other internal or external sources, or the cost to bring back the money is not significant from a tax perspective, we may determine that cash repatriations are necessary or desirable. Repatriation could result in additional material taxes. These factors may cause us to have an overall tax rate higher than other companies or higher than our tax rates have been in the past. Additionally, if conditions warrant, we may seek to obtain additional financing through debt or equity sources. To the extent we issue additional shares, our existing stockholders may be diluted. However, any such financing may not be available on terms favorable to us, or may not be available at all.

[0001633978-21-000009:mdna:108]
As of April 3, 2021, the debt component of our 2024 Notes of $385.3 million (principal balance of $450 million maturing in 2024) is presented in short-term liabilities since our stock price exceeded $78.80 for 20 of the last 30 trading days of the quarter ended April 3, 2021 and the 2024 Notes are convertible at the option of the holders. During the three and nine months ended April 3, 2021, we received conversion requests for less than $0.1 million principal amount of the 2024 Notes, which will be settled in cash in the fourth quarter of fiscal 2021. If the closing price of our stock exceeds $129.08 for 20 of the last 30 trading days of any future quarter, our 2026 Notes would also become convertible at the option of the holders and the debt component would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001633978-21-000009:mdna:109]
On May 7, 2021, our board of directors approved the 2 year share buyback program, which authorizes us to use up to $700 million to purchase our own shares of common stock. The price, timing, amount, and method of such repurchases will be determined based on the valuation of market conditions and other factors, at prices determined to be attractive and in the best interests of both Lumentum and our stockholders.

[0001633978-21-000009:mdna:110]
[same as prior period, unchanged from 0001633978-21-000004:mdna:107]

[0001633978-21-000009:mdna:111]
We believe that our cash and cash equivalents as of April 3, 2021 and cash flows from our operating activities will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months. However, if market conditions are favorable, we may evaluate alternatives to opportunistically pursue additional financing.

[0001633978-21-000009:mdna:112]
[same as prior period, unchanged from 0001633978-21-000004:mdna:109]

[0001633978-21-000009:mdna:113]
[same as prior period, unchanged from 0001633978-21-000004:mdna:110]

[0001633978-21-000009:mdna:114]
[same as prior period, unchanged from 0001633978-21-000004:mdna:111]

[0001633978-21-000009:mdna:115]
[same as prior period, unchanged from 0001633978-21-000004:mdna:112]

[0001633978-21-000009:mdna:116]
[same as prior period, unchanged from 0001633978-21-000004:mdna:113]

[0001633978-21-000009:mdna:117]
[same as prior period, unchanged from 0001633978-21-000004:mdna:114]

[0001633978-21-000009:mdna:118]
[same as prior period, unchanged from 0001633978-21-000004:mdna:115]

[0001633978-21-000009:mdna:119]
[same as prior period, unchanged from 0001633978-21-000004:mdna:116]

[0001633978-21-000009:mdna:120]
[same as prior period, unchanged from 0001633978-21-000004:mdna:117]

[0001633978-21-000009:mdna:121]
[same as prior period, unchanged from 0001633978-21-000004:mdna:118]

[0001633978-21-000009:mdna:122]
[same as prior period, unchanged from 0001633978-21-000004:mdna:119]

[0001633978-21-000009:mdna:123]
[same as prior period, unchanged from 0001633978-21-000004:mdna:120]

[0001633978-21-000009:mdna:124]
[same as prior period, unchanged from 0001633978-21-000004:mdna:121]

[0001633978-21-000009:mdna:125]
As of April 3, 2021, our balance of cash and cash equivalents increased by $389.7 million, to $687.7 million from $298.0 million as of June 27, 2020. The increase in cash and cash equivalents during the nine months ended April 3, 2021 was mainly due to cash provided by operating activities of $614.5 million, including the merger termination fee paid by Coherent of $217.6 million, offset by cash used in investing activities of $196.3 million and cash used in financing activities of $28.5 million.

[0001633978-21-000009:mdna:126]
As of March 28, 2020, our balance of cash, cash equivalents, and restricted cash increased by $256.2 million, to $688.8 million from $432.6 million as of June 29, 2019. The increase in cash, cash equivalents, and restricted cash was mainly due to cash provided by operating activities of $401.6 million and cash provided by financing activities of $332.5 million, offset by cash used in investing activities of $477.9 million during the nine months ended March 28, 2020.

[0001633978-21-000009:mdna:127]
[same as prior period, unchanged from 0001633978-21-000004:mdna:125]

[0001633978-21-000009:mdna:128]
Cash provided by operating activities was $614.5 million during the nine months ended April 3, 2021. Our net income was $375.8 million for the nine months ended April 3, 2021 and included the merger termination fee paid by Coherent, net of related costs of $207.5 million. Cash provided by operating activities was also generated from $258.8 million of non-cash items (such as depreciation, stock-based compensation, amortization of intangibles, amortization of debt discount and debt issuance costs on our Notes, and other non-cash charges), offset by $20.1 million of changes in our operating assets and liabilities. Changes in our operating assets and liabilities related primarily to an increase in inventories of $20.2 million and a decrease in accounts payable of $41.6 million, offset by an increase in income taxes, net of $28.2 million.

[0001633978-21-000009:mdna:129]
Cash provided by operating activities was $401.6 million during the nine months ended March 28, 2020. Our net income was $140.1 million for the nine months ended March 28, 2020. Cash provided by operating activities was generated primarily from $232.8 million of non-cash items (such as depreciation, stock-based compensation, amortization of intangibles, amortization of debt discount and debt issuance costs on our term loans and convertible notes, and other non-cash charges), and $28.7 million of changes in our operating assets and liabilities. Changes in our operating assets and liabilities related primarily to a decrease in inventories of $48.3 million offset by an increase in accounts receivable of $23.8 million.

[0001633978-21-000009:mdna:130]
[same as prior period, unchanged from 0001633978-21-000004:mdna:128]

[0001633978-21-000009:mdna:131]
Cash used in investing activities of $196.3 million during the nine months ended April 3, 2021 was primarily attributable to purchases of short-term investments, net of sales and maturities of $121.2 million, capital expenditures of $66.4 million, and payment for asset acquisition of $10.0 million.

[0001633978-21-000009:mdna:132]
Cash used in investing activities of $477.9 million during the nine months ended March 28, 2020 was primarily attributable to purchases of short-term investments, net of sales and maturities of $427.9 million, capital expenditures of $64.9 million, and payment for asset acquisition of $4.0 million, offset by proceeds from sale of product lines of $18.9 million.

[0001633978-21-000009:mdna:133]
[same as prior period, unchanged from 0001633978-21-000004:mdna:131]

[0001633978-21-000009:mdna:134]
Cash used in financing activities of $28.5 million during the nine months ended April 3, 2021 resulted primarily from tax payments related to restricted stock of $33.8 million, offset by the proceeds from employee stock plans of $5.5 million.

[0001633978-21-000009:mdna:135]
Cash provided by financing activities of $332.5 million during the nine months ended March 28, 2020 resulted primarily from the proceeds of the issuance of the 2026 Notes of $1,042.4 million, net of issuance costs, offset by the repurchase of shares of our common stock of $200.0 million and repayment of our term loan facility of $497.5 million.
