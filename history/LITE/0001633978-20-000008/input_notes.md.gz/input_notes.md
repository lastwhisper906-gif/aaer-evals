# LITE notes — 0001633978-20-000008


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001633978-20-000008:notes:1]
[same as prior period, unchanged from 0001633978-20-000003:notes:1]

[0001633978-20-000008:notes:2]
[same as prior period, unchanged from 0001633978-20-000003:notes:2]

[0001633978-20-000008:notes:3]
[same as prior period, unchanged from 0001633978-20-000003:notes:3]

[0001633978-20-000008:notes:4]
[same as prior period, unchanged from 0001633978-20-000003:notes:4]

[0001633978-20-000008:notes:5]
[same as prior period, unchanged from 0001633978-20-000003:notes:5]

[0001633978-20-000008:notes:6]
[same as prior period, unchanged from 0001633978-20-000003:notes:6]

[0001633978-20-000008:notes:7]
The COVID-19 pandemic has created and may continue to create significant uncertainty in global financial markets, which has disrupted and harmed, and may continue to disrupt and harm, the Company's business, financial condition, and results of operations. The extent of the impact of COVID-19 on the Company's operational and financial performance will depend on certain developments, including but not limited to the duration and spread of the outbreak, duration of local, state and federal issued public health orders in each jurisdiction where we operate or in which our customers and suppliers operate, impact on our customers and our sales cycles, impact on our supply chain and manufacturing partners, impact on our employees and impact on regional and worldwide economies and financial markets in general, all of which are uncertain and cannot be predicted.

[0001633978-20-000008:notes:8]
[same as prior period, unchanged from 0001633978-20-000003:notes:7]

[0001633978-20-000008:notes:9]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2021 will be a 53-week year. Our fiscal 2020 is a 52-week year ending on June 27, 2020, with the quarter ended March 28, 2020 being a 13-week quarterly period. Our fiscal 2019 was a 52-week year that ended on June 29, 2019, with the quarter ended March 30, 2019 being a 13-week quarterly period.

[0001633978-20-000008:notes:10]
[same as prior period, unchanged from 0001633978-20-000003:notes:9]

[0001633978-20-000008:notes:11]
[same as prior period, unchanged from 0001633978-20-000003:notes:10]

[0001633978-20-000008:notes:12]
Certain prior period amounts have been reclassified to conform to the current period presentation, including the reclassification of capital lease obligations that existed as of June 29, 2019 to finance lease liabilities within other current liabilities and other non-current liabilities in our condensed consolidated balance sheets, as a result of the adoption of the new accounting guidance for leases. Refer to “Note 2. Recently Issued Accounting Pronouncements” for details. The reclassification of the prior period amounts did not impact previously reported condensed consolidated financial statements.

[0001633978-20-000008:notes:13]
[same as prior period, unchanged from 0001633978-20-000003:notes:12]

[0001633978-20-000008:notes:14]
[same as prior period, unchanged from 0001633978-20-000003:notes:13]

[0001633978-20-000008:notes:15]
Except for the accounting policies for lease accounting as a result of the adoption of Accounting Standards Update (“ASU”) 2016-02, Leases (Topic 842), there have been no significant changes to our significant accounting policies as of and for the three months ended March 28, 2020, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the year ended June 29, 2019.

[0001633978-20-000008:notes:16]
[same as prior period, unchanged from 0001633978-20-000003:notes:15]

[0001633978-20-000008:notes:17]
On June 30, 2019, the first day of fiscal year 2020, we adopted Topic 842, using the modified retrospective transition approach. Refer to “Note 2. Recently Issued Accounting Pronouncements” regarding the impact of adoption.

[0001633978-20-000008:notes:18]
[same as prior period, unchanged from 0001633978-20-000003:notes:17]

[0001633978-20-000008:notes:19]
[same as prior period, unchanged from 0001633978-20-000003:notes:18]

[0001633978-20-000008:notes:20]
[same as prior period, unchanged from 0001633978-20-000003:notes:19]

[0001633978-20-000008:notes:21]
[same as prior period, unchanged from 0001633978-20-000003:notes:20]


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001633978-20-000008:notes:22]
Accounting Pronouncements Recently Adopted

[0001633978-20-000008:notes:23]
Effective June 30, 2019, we adopted Topic 842, using the modified retrospective transition approach. We applied the new guidance to all leases existing as of the date of adoption. Our reported results beginning with the first quarter of fiscal 2020 reflect the application of Topic 842, while prior period amounts have not been adjusted and continue to be reported in accordance with our historical accounting under Topic 840.

[0001633978-20-000008:notes:24]
We elected the practical expedient package permitted under the transition approach. As such, we did not reassess whether any expired or existing contracts are or contain leases, we did not reassess our historical lease classification, and we did not reassess our initial direct costs for any leases that existed prior to June 30, 2019. We have also elected to combine lease and non-lease components at a portfolio level for our operating leases of buildings and not to report leases with an initial term of 12 months or less on our balance sheet.

[0001633978-20-000008:notes:25]
As of the date of adoption, we recognized operating lease assets of $91.5 million, with corresponding operating lease liabilities of $81.5 million on the condensed consolidated balance sheets. The difference between the operating lease right-of-use assets and operating lease liabilities primarily represents the existing asset recognized in relation to the favorable terms of an operating lease acquired through a business combination offset by our deferred rent and ASC 420 “cease-use” balances.

[0001633978-20-000008:notes:26]
All existing leases that were classified as capital leases under Topic 840 are classified as finance leases under the new guidance. As of adoption, we recognized finance lease assets of $12.4 million in property, plant and equipment, net, with corresponding finance lease liabilities of $12.4 million on the condensed consolidated balance sheets. For further information regarding the impact of Topic 842 adoption, see “Note 1. Description of Business and Summary of Significant Accounting Policies” and “Note 9. Leases”.

[0001633978-20-000008:notes:27]
In February 2018, FASB issued ASU 2018-02, Income Statement-Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which allows companies to reclassify stranded tax effects resulting from the U.S. Tax Cuts and Jobs Act of 2017 (the “Tax Act”), from accumulated other comprehensive income to retained earnings. The guidance also requires certain new disclosures regardless of the election. The amendments in ASU 2018-02 are effective for all entities for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years. We adopted ASU 2018-02 in the first quarter of fiscal 2020 with no impact to our condensed consolidated financial statements.

[0001633978-20-000008:notes:28]
In January 2017, FASB issued ASU 2017-04, Intangibles - Goodwill and Other (Topic 350): Simplifying the Accounting for Goodwill Impairment. ASU 2017-04 removes the requirement to perform a hypothetical purchase price allocation to measure goodwill impairment. A goodwill impairment charge will be the amount by which a reporting unit's carrying value exceeds its fair value, not to exceed the carrying amount of goodwill. The amendments contained in ASU 2017-04 are effective for interim and annual periods beginning after December 15, 2019, with early adoption permitted, which should be applied prospectively. We early adopted ASU 2017-04 in our first quarter of fiscal 2020. The implementation of ASU 2017-04 did not have an impact on our condensed consolidated financial statements.

[0001633978-20-000008:notes:29]
Accounting Pronouncements Not Yet Effective

[0001633978-20-000008:notes:30]
In December 2019, FASB issued ASU 2019-12, Simplifying the Accounting for Income Taxes (Topic 740), which is intended to simplify various aspects related to accounting for income taxes by removing certain exceptions to the general principles in Topic 740 and which also clarifies and amends existing guidance to improve consistent application. ASU 2019-12 is effective for us at the beginning of fiscal 2022, including interim periods within that reporting period, although early adoption is permitted. We are currently evaluating the impact of ASU 2019-12 on our condensed consolidated financial statements.

[0001633978-20-000008:notes:31]
In August 2018, FASB issued ASU 2018-14, Compensation-Retirement Benefits-Defined Benefit Plans-General (Topic 715-20): Disclosure Framework-Changes to the Disclosure Requirements for Defined Benefit Plans. ASU 2018-14 modifies the disclosure requirements for defined benefit pension plans and other post-retirement benefit plans. The new guidance is effective for fiscal years ending after December 15, 2020, with early adoption permitted. ASU 2018-14 should be applied retrospectively to all periods presented and is effective for us in our first quarter of fiscal 2022. We are currently evaluating the impact of ASU 2018-14 on our condensed consolidated financial statements.

[0001633978-20-000008:notes:32]
In August 2018, FASB issued ASU 2018-13, Fair Value Measurement (Topic 820): Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement. ASU 2018-13 modifies the disclosure requirements for fair value measurements. The new guidance is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, with early adoption permitted. ASU 2018-13 requires that certain of the amendments be applied prospectively, while other amendments should be applied retrospectively to all periods presented. ASU 2018-13 is effective for us in our first quarter of fiscal 2021. We are currently evaluating the impact of ASU 2018-13 on our condensed consolidated financial statements and related disclosures.

[0001633978-20-000008:notes:33]
In August 2018, FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Customer's Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract. This standard requires capitalization of the implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software. Further, the standard also requires the Company to expense the capitalized implementation costs of a hosting arrangement over the term of the hosting arrangement. This standard is effective for us in our first quarter of fiscal 2021. Early adoption is permitted. The adoption of this standard is not expected to have a significant impact on our consolidated financial statements.

[0001633978-20-000008:notes:34]
In June 2016, FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments and a subsequent amendment, ASU 2018-19 (collectively, Topic 326). Topic 326 requires measurement and recognition of expected credit losses for financial assets held. Topic 326 is effective for annual periods beginning after December 15, 2019, including interim periods within those periods, with early adoption permitted. ASU 2016-13 is effective for us in our first quarter of fiscal 2021. We are currently evaluating the impact of our pending adoption of Topic 326 on our condensed consolidated financial statements.


## us-gaap:EarningsPerShareTextBlock

[0001633978-20-000008:notes:35]
[same as prior period, unchanged from 0001633978-20-000003:notes:33]

[0001633978-20-000008:notes:36]
[same as prior period, unchanged from 0001633978-20-000003:notes:34]

[0001633978-20-000008:notes:37]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| Basic Earnings per Common Share |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) | $ | 43.4 |  |  | $ | (74.3 | ) |  | $ | 140.1 |  |  | $ | (10.6 | ) |
| Less: Cumulative dividends on Series A Preferred Stock | — |  |  | — |  |  | — |  |  | (0.3 | ) |
| Less: Earnings allocated to Series A Preferred Stock | — |  |  | — |  |  | — |  |  | (1.2 | ) |
| Net income (loss) attributable to common stockholders - Basic | $ | 43.4 |  |  | $ | (74.3 | ) |  | $ | 140.1 |  |  | $ | (12.1 | ) |
| Weighted average common shares outstanding including Series A Preferred Stock | 74.8 |  |  | 76.2 |  |  | 76.2 |  |  | 69.4 |  |
| Less: Weighted average Series A Preferred Stock | — |  |  | — |  |  | — |  |  | (0.7 | ) |
| Basic weighted average common shares outstanding | 74.8 |  |  | 76.2 |  |  | 76.2 |  |  | 68.7 |  |
| Net income (loss) per share attributable to common stockholders - Basic | $ | 0.58 |  |  | $ | (0.98 | ) |  | $ | 1.84 |  |  | $ | (0.18 | ) |
| Diluted Earnings per Common Share |  |  |  |  |  |  |  |
| Net income (loss) attributable to common stockholders - Basic | $ | 43.4 |  |  | $ | (74.3 | ) |  | $ | 140.1 |  |  | $ | (12.1 | ) |
| Net income (loss) attributable to common stockholders - Diluted | $ | 43.4 |  |  | $ | (74.3 | ) |  | $ | 140.1 |  |  | $ | (12.1 | ) |
| Weighted average common shares outstanding for basic earnings per common share | 74.8 |  |  | 76.2 |  |  | 76.2 |  |  | 68.7 |  |
| Effect of dilutive securities from 2015 Equity Incentive Plan | 1.0 |  |  | — |  |  | 0.8 |  |  | — |  |
| Shares issuable assuming conversion of the 2024 Notes | 1.7 |  |  | — |  |  | 0.7 |  |  | — |  |
| Diluted weighted average common shares outstanding | 77.5 |  |  | 76.2 |  |  | 77.7 |  |  | 68.7 |  |
| Net income (loss) per share attributable to common stockholders - Diluted | $ | 0.56 |  |  | $ | (0.98 | ) |  | $ | 1.80 |  |  | $ | (0.18 | ) |

[0001633978-20-000008:notes:38]
[same as prior period, unchanged from 0001633978-20-000003:notes:36]

[0001633978-20-000008:notes:39]
[same as prior period, unchanged from 0001633978-20-000003:notes:37]

[0001633978-20-000008:notes:40]
We have the ability and intent to settle the face value of our convertible notes in cash. Therefore, we use the treasury stock method for calculating the dilutive impact of the convertible notes. The 2026 Notes will have no impact on diluted earnings per share until the average price of our common stock exceeds the conversion price of $99.29. The potentially dilutive shares resulting from the 2024 Notes were included in the calculation of diluted income per share for the three and nine months ended March 28, 2020 since the average price of our common stock exceeded the conversion price of $60.62. Refer to “Note 12. Debt” for further discussion.

[0001633978-20-000008:notes:41]
Anti-dilutive potential shares from the 2015 Equity Incentive Plan are excluded from the calculation of diluted earnings per share if their exercise price exceeded the average market price during the period or the share-based awards were determined to be anti-dilutive based on applying the treasury stock method. Anti-dilutive shares excluded from the calculation of diluted earnings per share were not material for the three and nine months ended March 28, 2020, respectively. Anti-dilutive shares excluded from the calculation of diluted earnings per share were 0.7 million shares and 0.6 million shares, respectively, for the three and nine months ended March 30, 2019, respectively.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0001633978-20-000008:notes:42]
[same as prior period, unchanged from 0001633978-20-000003:notes:40]

[0001633978-20-000008:notes:43]
[same as prior period, unchanged from 0001633978-20-000003:notes:41]

[0001633978-20-000008:notes:44]
[same as prior period, unchanged from 0001633978-20-000003:notes:42]

[0001633978-20-000008:notes:45]
[same as prior period, unchanged from 0001633978-20-000003:notes:43]

[0001633978-20-000008:notes:46]
[same as prior period, unchanged from 0001633978-20-000003:notes:44]

[0001633978-20-000008:notes:47]
[same as prior period, unchanged from 0001633978-20-000003:notes:45]

[0001633978-20-000008:notes:48]
[same as prior period, unchanged from 0001633978-20-000003:notes:46]

[0001633978-20-000008:notes:49]
The amounts presented in the table above pertained to the preliminary purchase price allocation reported in our Form 10-K for the year ended June 29, 2019, filed with the Securities and Exchange Commission on August 27, 2019. There have been no measurement period adjustments during the three and nine months ended March 28, 2020.

[0001633978-20-000008:notes:50]
[same as prior period, unchanged from 0001633978-20-000003:notes:48]

[0001633978-20-000008:notes:51]
[same as prior period, unchanged from 0001633978-20-000003:notes:49]

[0001633978-20-000008:notes:52]
[same as prior period, unchanged from 0001633978-20-000003:notes:50]

[0001633978-20-000008:notes:53]
The following supplemental pro forma information presents the combined results of operations for the nine months ended March 30, 2019, as if Oclaro had been acquired as of the beginning of fiscal year 2018. The supplemental pro forma information includes adjustments to amortization and depreciation for acquired intangible assets and property and equipment, adjustments to share-based compensation expense, the fair value adjustments on the inventories acquired, transaction costs, interest expense and amortization of the term loan debt issuance costs.

[0001633978-20-000008:notes:54]
[same as prior period, unchanged from 0001633978-20-000003:notes:52]

[0001633978-20-000008:notes:55]
|  | Nine Months Ended |
|  | March 30, 2019 |
| Net revenue | $ | 1,374.8 |  |
| Net loss | (18.2 | ) |


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001633978-20-000008:notes:56]
[same as prior period, unchanged from 0001633978-20-000003:notes:54]

[0001633978-20-000008:notes:57]
We continually evaluate our existing portfolio of businesses to maximize long-term shareholder value. We consider assets and liabilities as held-for-sale when management approves and commits to a plan to actively market assets or a group of assets for sale. Assets held-for-sale are recorded initially at the lower of its carrying value or its estimated fair value, less estimated costs to sell. Upon designation as an asset held-for-sale, we discontinue recording depreciation expense on such asset.

[0001633978-20-000008:notes:58]
Lithium Niobate modulators

[0001633978-20-000008:notes:59]
Following our acquisition of Oclaro, we announced our plan to discontinue development and manufacturing of Lithium Niobate modulators and wind down these operations in our San Donato, Italy site. In the second quarter of fiscal year 2020, we entered into an agreement with Advanced Fiber Resources (Zhuhai) Ltd. ("AFR"), a leading provider of passive optical components, to sell the assets associated with certain Lithium Niobate product lines manufactured by our San Donato site for $17 million. This sale was completed in the third quarter of fiscal year 2020, and we received the final proceeds of $16.9 million, net of $0.1 million retainer from AFR. The assets sold of $6.6 million primarily consisted of property, plant and equipment, net, inventory, and operating lease right-of-use assets, net, offset by liabilities transferred of $3.5 million primarily attributable to operating lease liabilities. During the three months ended March 28, 2020, we recognized a gain of $13.8 million, which was recorded in our other income (expense), net in the condensed consolidated statements of operations. With the close of this transaction, our telecom transmission product strategy is now focused on Indium Phosphide photonic integrated circuits, as well as components and modules that incorporate these Indium Phosphide photonic integrated circuits.

[0001633978-20-000008:notes:60]
Datacom transceiver modules
 As of June 29, 2019, we had $4.9 million of long-lived assets related to our plan to discontinue the development of future Datacom transceiver modules. As these assets were not deemed to be useful, we retired them from active use and classified them as held-for-sale on our balance sheet. This is a result of the strategic change we made in the third quarter of fiscal year 2019 when we announced the exit from the Datacom transceiver modules and investments in the new Datacom chips development. In the third quarter of fiscal year 2020, we sold $2.0 million and impaired $1.6 million of these assets held-for-sale. As of March 28, 2020, the remaining balance of $1.3 million is expected to be sold in the subsequent quarters.


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001633978-20-000008:notes:61]
[same as prior period, unchanged from 0001633978-20-000003:notes:61]

[0001633978-20-000008:notes:62]
[same as prior period, unchanged from 0001633978-20-000003:notes:62]

[0001633978-20-000008:notes:63]
|  | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| March 28, 2020: |  |  |  |  |  |  |  |
| Cash | $ | 121.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 121.3 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 72.6 |  |  | — |  |  | — |  |  | 72.6 |  |
| Corporate debt securities | 3.0 |  |  | — |  |  | — |  |  | 3.0 |  |
| Money market funds | 426.2 |  |  | — |  |  | — |  |  | 426.2 |  |
| U.S. Treasury securities | 65.1 |  |  | 0.1 |  |  | — |  |  | 65.2 |  |
| Total cash and cash equivalents | $ | 688.2 |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 688.3 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 4.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 4.4 |  |
| Commercial paper | 88.1 |  |  | — |  |  | — |  |  | 88.1 |  |
| Corporate debt securities | 343.2 |  |  | 0.2 |  |  | (2.5 | ) |  | 340.9 |  |
| Foreign government bonds | 4.0 |  |  | — |  |  | — |  |  | 4.0 |  |
| U.S. Agency securities | 23.0 |  |  | 0.1 |  |  | — |  |  | 23.1 |  |
| U.S. Treasury securities | 300.7 |  |  | 1.9 |  |  | — |  |  | 302.6 |  |
| Total short-term investments | $ | 763.4 |  |  | $ | 2.2 |  |  | $ | (2.5 | ) |  | $ | 763.1 |  |
| June 29, 2019: |  |  |  |  |  |  |  |
| Cash | $ | 213.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 213.8 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 37.4 |  |  | — |  |  | — |  |  | 37.4 |  |
| Money market funds | 168.1 |  |  | — |  |  | — |  |  | 168.1 |  |
| U.S. Treasury securities | 13.3 |  |  | — |  |  | — |  |  | 13.3 |  |
| Total cash and cash equivalents | $ | 432.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 432.6 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 1.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 1.9 |  |
| Commercial paper | 22.3 |  |  | — |  |  | — |  |  | 22.3 |  |
| Asset-backed securities | 54.9 |  |  | 0.2 |  |  | — |  |  | 55.1 |  |
| Corporate debt securities | 207.6 |  |  | 0.9 |  |  | (0.1 | ) |  | 208.4 |  |
| Municipal bonds | 1.3 |  |  | — |  |  | — |  |  | 1.3 |  |
| Mortgage-backed securities | 6.6 |  |  | — |  |  | — |  |  | 6.6 |  |
| Foreign government bonds | 6.2 |  |  | — |  |  | — |  |  | 6.2 |  |
| U.S. Agency securities | 4.6 |  |  | — |  |  | — |  |  | 4.6 |  |
| U.S. Treasury securities | 29.4 |  |  | 0.1 |  |  | — |  |  | 29.5 |  |
| Total short-term investments | $ | 334.8 |  |  | $ | 1.2 |  |  | $ | (0.1 | ) |  | $ | 335.9 |  |

[0001633978-20-000008:notes:64]
We use the specific-identification method to determine any realized gains or losses from the sale of our short-term investments classified as available-for-sale. During the three and nine months ended March 28, 2020 and March 30, 2019, we did not realize significant gains or losses on a gross level from the sale of our short-term investments classified as available-for-sale.

[0001633978-20-000008:notes:65]
During the three and nine months ended March 28, 2020, our other income (expense), net was $21.7 million and $27.9 million, respectively, and includes interest income on cash equivalents and short-term investments of $5.2 million and $12.6 million, respectively. During the three and nine months ended March 30, 2019, our other income (expense), net was $5.2 million and $11.7 million, respectively, and includes interest income on cash equivalents and short-term investments of $3.9 million and $10.0 million, respectively.

[0001633978-20-000008:notes:66]
[same as prior period, unchanged from 0001633978-20-000003:notes:66]

[0001633978-20-000008:notes:67]
|  | Less than 12 months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| March 28, 2020: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 8.0 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 8.0 |  |  | $ | — |  |
| Certificates of deposit | 2.5 |  |  | — |  |  | — |  |  | — |  |  | 2.5 |  |  | — |  |
| Commercial paper | 55.2 |  |  | — |  |  | — |  |  | — |  |  | 55.2 |  |  | — |  |
| Corporate debt securities | 301.1 |  |  | (2.5 | ) |  | — |  |  | — |  |  | 301.1 |  |  | (2.5 | ) |
| Total | $ | 366.8 |  |  | $ | (2.5 | ) |  | $ | — |  |  | $ | — |  |  | $ | 366.8 |  |  | $ | (2.5 | ) |
| June 29, 2019: |  |  |  |  |  |  |  |  |  |  |  |
| Asset-backed securities | $ | 4.2 |  |  | $ | — |  |  | $ | 5.9 |  |  | $ | — |  |  | $ | 10.1 |  |  | $ | — |  |
| Corporate debt securities | 9.6 |  |  | — |  |  | 35.9 |  |  | (0.1 | ) |  | 45.5 |  |  | (0.1 | ) |
| Foreign government bonds | — |  |  | — |  |  | 2.1 |  |  | — |  |  | 2.1 |  |  | — |  |
| U.S. government bonds | 6.9 |  |  | — |  |  | — |  |  | — |  |  | 6.9 |  |  | — |  |
| Total | $ | 20.7 |  |  | $ | — |  |  | $ | 43.9 |  |  | $ | (0.1 | ) |  | $ | 64.6 |  |  | $ | (0.1 | ) |

[0001633978-20-000008:notes:68]
[same as prior period, unchanged from 0001633978-20-000003:notes:68]

[0001633978-20-000008:notes:69]
|  | March 28, 2020 |  | June 29, 2019 |
|  | Amortized Cost |  | Fair Value |  | Amortized Cost |  | Fair Value |
| Due in 1 year | $ | 720.1 |  |  | $ | 720.0 |  |  | $ | 178.9 |  |  | $ | 179.1 |  |
| Due in 1 year through 5 years | 43.3 |  |  | 43.1 |  |  | 148.1 |  |  | 149.0 |  |
| Due in 5 years through 10 years | — |  |  | — |  |  | 6.0 |  |  | 6.0 |  |
| Due after 10 years | — |  |  | — |  |  | 1.8 |  |  | 1.8 |  |
|  | $ | 763.4 |  |  | $ | 763.1 |  |  | $ | 334.8 |  |  | $ | 335.9 |  |

[0001633978-20-000008:notes:70]
[same as prior period, unchanged from 0001633978-20-000003:notes:70]


## us-gaap:FairValueDisclosuresTextBlock

[0001633978-20-000008:notes:71]
[same as prior period, unchanged from 0001633978-20-000003:notes:71]

[0001633978-20-000008:notes:72]
[same as prior period, unchanged from 0001633978-20-000003:notes:72]

[0001633978-20-000008:notes:73]
[same as prior period, unchanged from 0001633978-20-000003:notes:73]

[0001633978-20-000008:notes:74]
[same as prior period, unchanged from 0001633978-20-000003:notes:74]

[0001633978-20-000008:notes:75]
Based on quoted market prices as of March 28, 2020, the fair values of the 2026 Notes and the 2024 Notes (refer to “Note 12. Debt”) were approximately $1.0 billion and $581.0 million, respectively, determined using Level 2 inputs as they are not actively traded in markets.

[0001633978-20-000008:notes:76]
[same as prior period, unchanged from 0001633978-20-000003:notes:77]

[0001633978-20-000008:notes:77]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| March 28, 2020: (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | — |  |  | $ | 72.6 |  |  | $ | — |  |  | $ | 72.6 |  |
| Corporate debt securities | — |  |  | 3.0 |  |  | — |  |  | 3.0 |  |
| Money market funds | 426.2 |  |  | — |  |  | — |  |  | 426.2 |  |
| U.S. Treasury securities | 65.2 |  |  | — |  |  | — |  |  | 65.2 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 4.4 |  |  | — |  |  | 4.4 |  |
| Commercial paper | — |  |  | 88.1 |  |  | — |  |  | 88.1 |  |
| Corporate debt securities | — |  |  | 340.9 |  |  | — |  |  | 340.9 |  |
| Foreign government bonds | — |  |  | 4.0 |  |  | — |  |  | 4.0 |  |
| U.S. Agency securities | — |  |  | 23.1 |  |  | — |  |  | 23.1 |  |
| U.S. Treasury securities | 302.6 |  |  | — |  |  | — |  |  | 302.6 |  |
| Total assets | $ | 794.0 |  |  | $ | 536.1 |  |  | $ | — |  |  | $ | 1,330.1 |  |

[0001633978-20-000008:notes:78]
(1)  Excludes $121.3 million in cash held in our bank accounts at March 28, 2020.

[0001633978-20-000008:notes:79]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| June 29, 2019: (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | — |  |  | $ | 37.4 |  |  | $ | — |  |  | $ | 37.4 |  |
| Money market funds | 168.1 |  |  | — |  |  | — |  |  | 168.1 |  |
| U.S. Treasury securities | 13.3 |  |  | — |  |  | — |  |  | 13.3 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 1.9 |  |  | — |  |  | 1.9 |  |
| Commercial paper | — |  |  | 22.3 |  |  | — |  |  | 22.3 |  |
| Asset-backed securities | — |  |  | 55.1 |  |  | — |  |  | 55.1 |  |
| Corporate debt securities | — |  |  | 208.4 |  |  | — |  |  | 208.4 |  |
| Municipal bonds | — |  |  | 1.3 |  |  | — |  |  | 1.3 |  |
| Mortgage-backed securities | — |  |  | 6.6 |  |  | — |  |  | 6.6 |  |
| Foreign government bonds | — |  |  | 6.2 |  |  | — |  |  | 6.2 |  |
| U.S. Agency securities | — |  |  | 4.6 |  |  | — |  |  | 4.6 |  |
| U.S. Treasury securities | 29.5 |  |  | — |  |  | — |  |  | 29.5 |  |
| Total assets | $ | 210.9 |  |  | $ | 343.8 |  |  | $ | — |  |  | $ | 554.7 |  |
| Other accrued liabilities: |  |  |  |  |  |  |  |
| Acquisition contingency | $ | — |  |  | $ | — |  |  | $ | 2.7 |  |  | $ | 2.7 |  |
| Total other accrued liabilities | $ | — |  |  | $ | — |  |  | $ | 2.7 |  |  | $ | 2.7 |  |

[0001633978-20-000008:notes:80]
[same as prior period, unchanged from 0001633978-20-000003:notes:81]

[0001633978-20-000008:notes:81]
[same as prior period, unchanged from 0001633978-20-000003:notes:82]

[0001633978-20-000008:notes:82]
[same as prior period, unchanged from 0001633978-20-000003:notes:83]

[0001633978-20-000008:notes:83]
[same as prior period, unchanged from 0001633978-20-000003:notes:84]

[0001633978-20-000008:notes:84]
No impairment charges were recorded during the three and nine months ended March 28, 2020 and March 30, 2019. Refer to “Note 10. Goodwill and Other Intangible Assets”.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001633978-20-000008:notes:85]
We periodically review our intangible and other long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. Determination of recoverability is based on the lowest level of identifiable estimated undiscounted cash flows resulting from use of the asset and its eventual disposition. If not recoverable, an impairment loss would be calculated based on the excess of the carrying amount over the fair value.
Management utilizes various valuation methods, including an income approach, a market approach and a cost approach, to estimate the fair value of intangible and other long-lived assets.
We determine fair value based on the fair value hierarchy, which requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs when measuring fair value. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. The fair value assumes that the transaction to sell the asset or transfer the liability occurs in the principal or most advantageous market for the asset or liability and establishes that the fair value of an asset or liability shall be determined based on the assumptions that market participants would use in pricing the asset or liability. The classification of a financial asset or liability within the hierarchy is based upon the lowest level input that is significant to the fair value measurement. The fair value hierarchy prioritizes the inputs into three levels that may be used to measure fair value:


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001633978-20-000008:notes:86]
[same as prior period, unchanged from 0001633978-20-000003:notes:87]

[0001633978-20-000008:notes:87]
[same as prior period, unchanged from 0001633978-20-000003:notes:88]

[0001633978-20-000008:notes:88]
As of March 28, 2020 and June 29, 2019, our accounts receivable allowance balance was $1.7 million and $4.5 million, respectively.

[0001633978-20-000008:notes:89]
[same as prior period, unchanged from 0001633978-20-000003:notes:90]

[0001633978-20-000008:notes:90]
[same as prior period, unchanged from 0001633978-20-000003:notes:91]

[0001633978-20-000008:notes:91]
|  | March 28, 2020 |  | June 29, 2019 |
| Raw materials and purchased parts | $ | 55.4 |  |  | $ | 78.3 |  |
| Work in process | 67.9 |  |  | 72.5 |  |
| Finished goods | 49.4 |  |  | 78.0 |  |
| Inventories (1) | $ | 172.7 |  |  | $ | 228.8 |  |

[0001633978-20-000008:notes:92]
(1) The inventory balance as of June 29, 2019 includes $5.7 million, net of amortization, related to the inventory step-up adjustment from the Oclaro acquisition. As of March 28, 2020, the inventory step-up adjustment from the Oclaro acquisition was fully amortized.

[0001633978-20-000008:notes:93]
[same as prior period, unchanged from 0001633978-20-000003:notes:94]

[0001633978-20-000008:notes:94]
[same as prior period, unchanged from 0001633978-20-000003:notes:95]

[0001633978-20-000008:notes:95]
|  | March 28, 2020 |  | June 29, 2019 |
| Prepayments | $ | 29.7 |  |  | $ | 32.4 |  |
| Vendor receivable | 29.8 |  |  | 36.3 |  |
| Value added tax receivable | 11.5 |  |  | 11.9 |  |
| Advances to contract manufacturers | — |  |  | 8.7 |  |
| Assets held-for-sale | 1.3 |  |  | 4.9 |  |
| Other current assets | 4.8 |  |  | 3.3 |  |
| Prepayments and other current assets | $ | 77.1 |  |  | $ | 97.5 |  |

[0001633978-20-000008:notes:96]
[same as prior period, unchanged from 0001633978-20-000003:notes:97]

[0001633978-20-000008:notes:97]
[same as prior period, unchanged from 0001633978-20-000003:notes:98]

[0001633978-20-000008:notes:98]
|  | March 28, 2020 |
| Operating lease right-of-use assets | $ | 90.3 |  |
| Less: accumulated amortization | (8.6 | ) |
| Operating lease right-of-use assets, net | $ | 81.7 |  |

[0001633978-20-000008:notes:99]
[same as prior period, unchanged from 0001633978-20-000003:notes:100]

[0001633978-20-000008:notes:100]
[same as prior period, unchanged from 0001633978-20-000003:notes:101]

[0001633978-20-000008:notes:101]
|  | March 28, 2020 |  | June 29, 2019 |
| Land | $ | 44.2 |  |  | $ | 44.2 |  |
| Buildings and improvement | 112.9 |  |  | 103.7 |  |
| Machinery and equipment (1) | 514.1 |  |  | 500.5 |  |
| Computer equipment and software | 25.6 |  |  | 25.4 |  |
| Furniture and fixtures | 6.6 |  |  | 4.9 |  |
| Leasehold improvements | 28.1 |  |  | 31.2 |  |
| Finance lease right-of-use assets (1) | 28.1 |  |  | 16.0 |  |
| Construction in progress | 53.0 |  |  | 46.8 |  |
|  | 812.6 |  |  | 772.7 |  |
| Less: Accumulated depreciation (1) | (402.5 | ) |  | (339.4 | ) |
| Property, plant and equipment, net | $ | 410.1 |  |  | $ | 433.3 |  |

[0001633978-20-000008:notes:102]
(1) Included in the table above is our equipment acquired under finance leases. As of March 28, 2020 and June 29, 2019, the accumulated depreciation of finance lease right-of-use assets was $24.2 million and $11.2 million, respectively. For fiscal 2019 in accordance with Topic 842, we have reclassified $16.0 million of equipment acquired under finance leases from machinery and equipment to finance lease right-of-use assets to conform to current period presentation.

[0001633978-20-000008:notes:103]
During the three and nine months ended March 28, 2020, we recorded depreciation expense of $27.5 million and $87.8 million, respectively. During the three and nine months ended March 30, 2019, we recorded depreciation expense of $29.0 million and $74.7 million, respectively.

[0001633978-20-000008:notes:104]
Included in these amounts were depreciation expense for equipment acquired under finance leases in the amount of $4.8 million and $13.0 million for the three and nine months ended March 28, 2020, respectively, and $1.5 million and $4.6 million for the three and nine months ended March 30, 2019, respectively.

[0001633978-20-000008:notes:105]
[same as prior period, unchanged from 0001633978-20-000003:notes:106]

[0001633978-20-000008:notes:106]
[same as prior period, unchanged from 0001633978-20-000003:notes:107]

[0001633978-20-000008:notes:107]
[same as prior period, unchanged from 0001633978-20-000003:notes:108]

[0001633978-20-000008:notes:108]
[same as prior period, unchanged from 0001633978-20-000003:notes:109]

[0001633978-20-000008:notes:109]
|  | March 28, 2020 |  | June 29, 2019 |
| Restructuring accrual and related charges (1) | $ | 2.6 |  |  | $ | 14.6 |  |
| Warranty accrual (2) | 5.4 |  |  | 7.5 |  |
| Deferred revenue and customer deposits | 1.7 |  |  | 2.9 |  |
| Finance lease liabilities, current (3) | 3.9 |  |  | 0.4 |  |
| Income tax payable | 30.4 |  |  | 8.7 |  |
| Other current liabilities | 2.8 |  |  | 5.1 |  |
| Other current liabilities | $ | 46.8 |  |  | $ | 39.2 |  |

[0001633978-20-000008:notes:110]
[same as prior period, unchanged from 0001633978-20-000003:notes:111]

[0001633978-20-000008:notes:111]
(2) Refer to “Note 17. Commitments and Contingencies.”

[0001633978-20-000008:notes:112]
(3) For fiscal 2019 in accordance with Topic 842, we have reclassified amounts from capital lease obligations to finance lease liabilities to conform to current period presentation. In addition to the $3.9 million of finance lease liabilities recorded within other current liabilities as of March 28, 2020, we also recorded $0.1 million within other non-current liabilities in the condensed consolidated balance sheet. Refer to “Note 9. Leases.”

[0001633978-20-000008:notes:113]
[same as prior period, unchanged from 0001633978-20-000003:notes:115]

[0001633978-20-000008:notes:114]
[same as prior period, unchanged from 0001633978-20-000003:notes:116]

[0001633978-20-000008:notes:115]
|  | March 28, 2020 |  | June 29, 2019 |
| Asset retirement obligations | $ | 4.9 |  |  | $ | 4.5 |  |
| Pension and related accrual (1) | 10.0 |  |  | 7.9 |  |
| Deferred rent | — |  |  | 2.2 |  |
| Unrecognized tax benefit | 18.1 |  |  | 18.7 |  |
| Finance lease liabilities, non-current | 0.1 |  |  | — |  |
| Other non-current liabilities | 0.6 |  |  | 0.4 |  |
| Other non-current liabilities | $ | 33.7 |  |  | $ | 33.7 |  |

[0001633978-20-000008:notes:116]
(1) We have defined benefit pension plans in Japan, Switzerland, and Thailand. As of March 28, 2020, the projected benefit obligations in Japan, Switzerland, and Thailand were $2.8 million, $4.7 million, and $2.5 million, respectively. As of June 29, 2019, the projected benefit obligations for Japan and Switzerland were $2.8 million and $5.0 million, respectively. Pension and related accruals as of June 29, 2019 also include $0.1 million attributable to post-retirement benefits for executives.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001633978-20-000008:notes:117]
[same as prior period, unchanged from 0001633978-20-000003:notes:119]

[0001633978-20-000008:notes:118]
[same as prior period, unchanged from 0001633978-20-000003:notes:120]

[0001633978-20-000008:notes:119]
[same as prior period, unchanged from 0001633978-20-000003:notes:121]

[0001633978-20-000008:notes:120]
As of March 28, 2020, we sublease certain floors of our offices in the United Kingdom, the United States, Canada, and Japan. These subleases will expire at various dates by fiscal year 2023. We anticipate receiving approximately $5.9 million in sublease income over the next three years.

[0001633978-20-000008:notes:121]
[same as prior period, unchanged from 0001633978-20-000003:notes:123]

[0001633978-20-000008:notes:122]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2020 |  | March 28, 2020 |
| Finance lease cost (in millions): |  |  |  |
| Amortization of right-of-use assets | $ | 4.8 |  |  | $ | 13.0 |  |
| Interest | — |  |  | 0.1 |  |
| Operating lease cost | 3.9 |  |  | 11.9 |  |
| Variable lease cost | 0.4 |  |  | 1.5 |  |
| Short-term lease cost | 0.7 |  |  | 1.7 |  |
| Sublease income | (0.7 | ) |  | (1.9 | ) |
| Total lease cost | $ | 9.1 |  |  | $ | 26.3 |  |
| Weighted average remaining lease term (in years): |  |  |  |
| Operating leases |  |  | 8.9 |  |
| Finance leases |  |  | 0.7 |  |
| Weighted average discount rate: |  |  |  |
| Operating leases |  |  | 3.65 | % |
| Finance leases |  |  | 4.38 | % |

[0001633978-20-000008:notes:123]
As of March 28, 2020, maturities of our operating and finance lease liabilities, which do not include short-term leases and variable lease payments, were as follows (in millions):

[0001633978-20-000008:notes:124]
| Fiscal Years |  | Operating Leases (1) |  | Finance Leases |  | Total |
| Remainder of 2020 |  | $ | 3.3 |  |  | $ | 3.4 |  |  | $ | 6.7 |  |
| 2021 |  | 13.1 |  |  | 0.6 |  |  | 13.7 |  |
| 2022 |  | 12.3 |  |  | — |  |  | 12.3 |  |
| 2023 |  | 11.1 |  |  | — |  |  | 11.1 |  |
| 2024 |  | 9.4 |  |  | — |  |  | 9.4 |  |
| Thereafter |  | 31.4 |  |  | — |  |  | 31.4 |  |
| Total minimum lease payments |  | $ | 80.6 |  |  | $ | 4.0 |  |  | $ | 84.6 |  |
| Less: amount representing interest |  | (10.0 | ) |  | — |  |  | (10.0 | ) |
| Present value of total lease liabilities |  | $ | 70.6 |  |  | $ | 4.0 |  |  | $ | 74.6 |  |

[0001633978-20-000008:notes:125]
(1) Non-cancellable sublease proceeds for the remainder of fiscal 2020, and fiscal 2021, 2022, and 2023 of $0.7 million, $2.4 million, $2.2 million, and $0.6 million, respectively, are not included in the table above.

[0001633978-20-000008:notes:126]
[same as prior period, unchanged from 0001633978-20-000003:notes:128]

[0001633978-20-000008:notes:127]
[same as prior period, unchanged from 0001633978-20-000003:notes:129]


## us-gaap:GoodwillDisclosureTextBlock

[0001633978-20-000008:notes:128]
[same as prior period, unchanged from 0001633978-20-000003:notes:130]

[0001633978-20-000008:notes:129]
[same as prior period, unchanged from 0001633978-20-000003:notes:131]

[0001633978-20-000008:notes:130]
On December 10, 2018, we completed the acquisition of Oclaro. We recognized goodwill in the amount of $357.6 million for the acquisition of Oclaro and allocated it to our OpComms segment. There have been no measurement periods or other adjustments to goodwill during the three and nine months ended March 28, 2020. The following table presents our goodwill balance by the reportable segments as of March 28, 2020 (in millions):

[0001633978-20-000008:notes:131]
|  | Optical Communications |  | Commercial Lasers |  | Total |
| Balance as of March 28, 2020 | $ | 363.5 |  |  | $ | 5.4 |  |  | $ | 368.9 |  |

[0001633978-20-000008:notes:132]
[same as prior period, unchanged from 0001633978-20-000003:notes:134]

[0001633978-20-000008:notes:133]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. In the fourth quarter of fiscal 2019, we completed the annual impairment test of goodwill, which indicated there was no goodwill impairment.

[0001633978-20-000008:notes:134]
We considered the impacts of COVID-19 pandemic on our business and determined that there were no indicators of goodwill impairment  as of March 28, 2020.

[0001633978-20-000008:notes:135]
[same as prior period, unchanged from 0001633978-20-000003:notes:136]

[0001633978-20-000008:notes:136]
[same as prior period, unchanged from 0001633978-20-000003:notes:137]

[0001633978-20-000008:notes:137]
[same as prior period, unchanged from 0001633978-20-000003:notes:138]

[0001633978-20-000008:notes:138]
[same as prior period, unchanged from 0001633978-20-000003:notes:139]

[0001633978-20-000008:notes:139]
| March 28, 2020 | Gross Carrying Amounts |  | Accumulated Amortization |  | Net Carrying Amounts |  | Weighted average remaining amortization period (years) |
| Acquired developed technologies (1) | $ | 346.5 |  |  | $ | (161.9 | ) |  | $ | 184.6 |  |  | 3.5 |
| Customer relationships | 149.3 |  |  | (30.9 | ) |  | 118.4 |  |  | 6.7 |
| In-process research and development (1) | 35.0 |  |  | — |  |  | 35.0 |  |  | n/a |
| Order backlog | 22.0 |  |  | (22.0 | ) |  | — |  |  | — |
| Other intangibles | 2.7 |  |  | (2.7 | ) |  | — |  |  | — |
| Total intangible assets | $ | 555.5 |  |  | $ | (217.5 | ) |  | $ | 338.0 |  |  |  |

[0001633978-20-000008:notes:140]
(1) During the three and nine months ended March 28, 2020, we completed $7 million and $59 million of IPR&D projects, respectively, and reclassified the value assigned to them to acquired developed technologies. The amount will be amortized over the assets’ estimated useful life of 4 to 5 years.

[0001633978-20-000008:notes:141]
[same as prior period, unchanged from 0001633978-20-000003:notes:142]

[0001633978-20-000008:notes:142]
[same as prior period, unchanged from 0001633978-20-000003:notes:143]

[0001633978-20-000008:notes:143]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| Cost of sales | $ | 13.9 |  |  | $ | 28.1 |  |  | $ | 38.8 |  |  | $ | 33.3 |  |
| Selling, general and administrative | 6.1 |  |  | 3.6 |  |  | 18.6 |  |  | 4.4 |  |
| Total amortization of intangibles | $ | 20.0 |  |  | $ | 31.7 |  |  | $ | 57.4 |  |  | $ | 37.7 |  |

[0001633978-20-000008:notes:144]
Based on the carrying amount of our acquired developed technologies and other intangibles, excluding IPR&D, as of March 28, 2020, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001633978-20-000008:notes:145]
| Fiscal Years |  |
| Remainder of 2020 | $ | 20.3 |  |
| 2021 | 78.9 |  |
| 2022 | 76.4 |  |
| 2023 | 52.9 |  |
| 2024 | 33.1 |  |
| Thereafter | 41.4 |  |
| Total future amortization | $ | 303.0 |  |


## lite:NoncontrollingInterestAndDerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001633978-20-000008:notes:146]
[same as prior period, unchanged from 0001633978-20-000003:notes:147]

[0001633978-20-000008:notes:147]
[same as prior period, unchanged from 0001633978-20-000003:notes:148]

[0001633978-20-000008:notes:148]
[same as prior period, unchanged from 0001633978-20-000003:notes:149]

[0001633978-20-000008:notes:149]
[same as prior period, unchanged from 0001633978-20-000003:notes:150]

[0001633978-20-000008:notes:150]
[same as prior period, unchanged from 0001633978-20-000003:notes:151]

[0001633978-20-000008:notes:151]
Through the date of conversion, holders of Series A Preferred Stock, in preference to holders of common stock or any other class or series of our outstanding capital stock ranking in any such event junior to the Series A Preferred Stock, were entitled to

[0001633978-20-000008:notes:152]
receive, when and as declared by the board of directors, quarterly cumulative cash dividends at the annual rate of 2.5% of the Issuance Value per share on each outstanding share of Series A Preferred Stock. The accrued dividends were payable on March 31, June 30, September 30 and December 31 of each year commencing on September 30, 2015. The accrued dividends as of November 2, 2018, the effective date of the conversion of all outstanding Series A Preferred Stock, was $0.3 million. During the three months ended March 30, 2019, we paid $0.4 million in dividends to the holders of Series A Preferred Stock.

[0001633978-20-000008:notes:153]
In connection with the conversion of the Series A Preferred Stock on November 2, 2018, we recorded $79.4 million in additional paid in capital which is reflected within the condensed consolidated balance sheets as of March 28, 2020 and June 29, 2019. For the nine months ended March 30, 2019, we recorded $8.8 million unrealized gain to our condensed consolidated statements of operations.


## us-gaap:DebtDisclosureTextBlock

[0001633978-20-000008:notes:154]
Note 12. Debt

[0001633978-20-000008:notes:155]
Convertible Notes

[0001633978-20-000008:notes:156]
2026 Notes

[0001633978-20-000008:notes:157]
In December 2019, we issued $1,050.0 million in aggregate principal amount of the 2026 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2026 Notes are governed by an indenture between the Company and U.S. Bank National Association (the “2026 Indenture”). We used approximately $196 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan credit facility, and a portion of the net proceeds of the offering to purchase approximately $200 million of our common stock concurrently with the pricing of the offering in privately negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001633978-20-000008:notes:158]
The 2026 Notes will bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on June 15, 2020. The 2026 Notes will mature on December 15, 2026, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001633978-20-000008:notes:159]
The initial conversion rate is 10.0711 shares of common stock per $1,000 principal amount of the 2026 Notes (which is equivalent to an initial conversion price of approximately $99.29 per share). The conversion rate is subject to adjustment upon the occurrence of certain specified events but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2026 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001633978-20-000008:notes:160]
Prior to the close of business on the business day immediately preceding September 15, 2026, holders of the 2026 Notes may convert their 2026 Notes only under the following circumstances:

[0001633978-20-000008:notes:161]
| • | during any fiscal quarter commencing after the fiscal quarter ended on March 28, 2020 (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price of the 2026 Notes on each applicable trading day; |

[0001633978-20-000008:notes:162]
| • | during the five business day period after any five consecutive trading day period (the "2026 measurement period") in which the trading price per $1,000 principal amount of the 2026 Notes for each trading day of the 2026 measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the notes on each such trading day; |

[0001633978-20-000008:notes:163]
| • | if we call any or all of the 2026 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the relevant redemption date; or |

[0001633978-20-000008:notes:164]
| • | upon the occurrence of specified corporate events, as specified in each indenture governing the 2026 Notes. |

[0001633978-20-000008:notes:165]
On or after September 15, 2026 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert the 2026 Notes at any time. Upon conversion, we may satisfy our conversion obligation in cash, shares of common stock or a combination of cash and shares of common stock, at our election.

[0001633978-20-000008:notes:166]
We may redeem for cash, stock or combination of both for all or any portion of the 2026 Notes, at our option, on or after December 20, 2023, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect

[0001633978-20-000008:notes:167]
for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide a notice of redemption at a redemption price equal to 100% of the principal amount of the 2026 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2026 Notes. Upon the occurrence of a fundamental change (as defined in the 2026 Indenture), holders may require us to repurchase all or a portion of the 2026 Notes for cash at a price equal to 100% of the principal amount of the 2026 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001633978-20-000008:notes:168]
In accordance with accounting for debt with conversions and other options, we bifurcated the principal amount of the 2026 Notes into liability and equity components. The liability component of the 2026 Notes was valued at $734.8 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 5.8% with the equity component representing the residual amount of the proceeds of $315.2 million, which was recorded as a debt discount.

[0001633978-20-000008:notes:169]
We incurred approximately $7.8 million in transaction costs in connection with the issuance of the 2026 Notes and these costs were allocated pro rata based on the relative carrying amounts of the liability and equity components. The debt discount and debt issuance costs attributable to the liability component will be amortized to interest expense using an effective interest rate of 5.8% over the expected life of the 2026 Notes. Debt issuance costs attributable to the equity component are netted with the equity component in stockholders’ equity, and the equity component is not remeasured as long as it continues to meet the conditions for equity classification.

[0001633978-20-000008:notes:170]
2024 Notes

[0001633978-20-000008:notes:171]
In March 2017, we issued $450.0 million of the 2024 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank National Association, as trustee (the “2024 Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001633978-20-000008:notes:172]
The 2024 Notes bear interest at a rate of 0.25% per year. Interest on the 2024 Notes is payable semi-annually in arrears on March 15 and September 15 of each year, beginning on September 15, 2017. The 2024 Notes will mature on March 15, 2024, unless earlier repurchased by us or converted pursuant to their terms.

[0001633978-20-000008:notes:173]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share, a 132.5% premium to the fair market value at the date of issuance.

[0001633978-20-000008:notes:174]
Prior to the close of business on the business day immediately preceding December 15, 2023, each holder of the 2024 Notes may convert their 2024 Notes only under the following circumstances:

[0001633978-20-000008:notes:175]
| • | during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price, or $78.80 on each applicable trading day; |

[0001633978-20-000008:notes:176]
| • | during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of notes for each trading day of such measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day; or |

[0001633978-20-000008:notes:177]
| • | upon the occurrence of specified corporate events. |

[0001633978-20-000008:notes:178]
On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2024 Notes at any time. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2024 Indenture), we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert 2024 Notes in connection with such make-whole fundamental change.

[0001633978-20-000008:notes:179]
We may not redeem the 2024 Notes prior to their maturity date and no sinking fund is provided for the 2024 Notes. Upon the occurrence of a fundamental change, holders may require us to repurchase all or a portion of their 2024 Notes for cash at a price equal to 100% of the principal amount of the 2024 Notes to be repurchased, plus any accrued and unpaid interest.

[0001633978-20-000008:notes:180]
We considered the features embedded in the 2024 Notes other than the conversion feature, including the holders’ put feature, our call feature, and the make-whole feature, and concluded that they are not required to be bifurcated and accounted for separately from the host debt instrument.

[0001633978-20-000008:notes:181]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. We incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. We amortize the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes is 5.4% per year.

[0001633978-20-000008:notes:182]
During the fiscal year ended July 1, 2017, we satisfied the TMA settlement condition. As such, the value of the conversion option will no longer be marked to market and was reclassified to additional paid-in capital within stockholders’ equity on our condensed consolidated balance sheet. The value of the conversion option at the time of issuance will be treated as an original issue discount for purposes of accounting for the debt component of the 2024 Notes. The debt component will accrete up to the principal amount over the expected term of the debt.

[0001633978-20-000008:notes:183]
Our convertible notes consisted of the following components as of the periods presented (in millions):

[0001633978-20-000008:notes:184]
| Liability component: | March 28, 2020 |  | June 29, 2019 |
|  | 2024 Notes |  | 2026 Notes |  | 2024 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount and debt issuance costs | (84.2 | ) |  | (309.8 | ) |  | (98.1 | ) |
| Net carrying amount of the liability component | $ | 365.8 |  |  | $ | 740.2 |  |  | $ | 351.9 |  |

[0001633978-20-000008:notes:185]
The following table sets forth interest expense information related to the convertible notes for the periods presented (in millions):

[0001633978-20-000008:notes:186]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| Contractual interest expense | $ | 1.6 |  |  | $ | 0.3 |  |  | $ | 2.3 |  |  | $ | 0.9 |  |
| Amortization of the debt discount and debt issuance costs | 14.0 |  |  | 4.5 |  |  | 24.8 |  |  | 13.2 |  |
| Total interest expense | $ | 15.6 |  |  | $ | 4.8 |  |  | $ | 27.1 |  |  | $ | 14.1 |  |

[0001633978-20-000008:notes:187]
The future interest and principal payments related to our convertible notes are as follows as of March 28, 2020 (in millions):

[0001633978-20-000008:notes:188]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | Total |
| Remainder of 2020 | $ | — |  |  | $ | 2.7 |  |  | $ | 2.7 |  |
| 2021 | 1.1 |  |  | 5.2 |  |  | 6.3 |  |
| 2022 | 1.1 |  |  | 5.3 |  |  | 6.4 |  |
| 2023 | 1.1 |  |  | 5.2 |  |  | 6.3 |  |
| 2024 | 451.2 |  |  | 5.3 |  |  | 456.5 |  |
| Thereafter | — |  |  | 1,063.1 |  |  | 1,063.1 |  |
| Total convertible notes payments | $ | 454.5 |  |  | $ | 1,086.8 |  |  | $ | 1,541.3 |  |

[0001633978-20-000008:notes:189]
Term Loan Facility

[0001633978-20-000008:notes:190]
On December 10, 2018 (the “Closing Date”), concurrent with the closing of the Oclaro merger, we entered into a Credit and Guarantee Agreement (the “Credit Agreement”), by and among us, certain of our subsidiaries, the lenders party thereto, and

[0001633978-20-000008:notes:191]
Deutsche Bank, as administrative agent and collateral agent for the lenders. The Credit Agreement provides for a senior secured term loan facility (the “Term Loan Facility”) in an aggregate principal amount of $500.0 million. The term loans available under the Term Loan Facility were fully drawn on the Closing Date and the proceeds of the term loans were used to consummate the merger and pay fees and expenses in connection with the merger and the Term Loan Facility.

[0001633978-20-000008:notes:192]
In fiscal 2019, we incurred $9.3 million of debt issuance costs in connection with the Term Loan Facility which were capitalized and recorded as a contra liability in our condensed consolidated balance sheet. These costs were amortized to interest expense using the effective interest rate method from the issuance date of December 10, 2018.

[0001633978-20-000008:notes:193]
In fiscal 2020, we repaid, in full, all amounts outstanding under our Term Loan Facility. During the nine months ended March 28, 2020, we incurred an $8.0 million loss for the unamortized debt issuance costs as a result of this full repayment.

[0001633978-20-000008:notes:194]
The following table sets forth interest expense information related to the term loan for the periods presented (in millions):

[0001633978-20-000008:notes:195]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| Contractual interest expense | $ | — |  |  | $ | 6.2 |  |  | $ | 9.6 |  |  | $ | 10.2 |  |
| Amortization of the debt issuance costs | — |  |  | 0.4 |  |  | 0.5 |  |  | 0.5 |  |
| Loss on early extinguishment of debt | — |  |  | — |  |  | 8.0 |  |  | — |  |
| Total interest expense | $ | — |  |  | $ | 6.6 |  |  | $ | 18.1 |  |  | $ | 10.7 |  |

[0001633978-20-000008:notes:196]
For the nine months ended March 28, 2020, we also recorded $0.1 million interest expense related to our finance leases.

[0001633978-20-000008:notes:197]
The following table sets forth balance sheet information related to the term loan as of the periods presented (in millions):

[0001633978-20-000008:notes:198]
|  | March 28, 2020 |  | June 29, 2019 |
| Principal | $ | 497.5 |  |  | $ | 500.0 |  |
| Repayment of principal | (497.5 | ) |  | (2.5 | ) |
| Unamortized value of the debt issuance costs | — |  |  | (8.5 | ) |
| Net carrying value | $ | — |  |  | $ | 489.0 |  |
| Term loan, current | $ | — |  |  | $ | 5.0 |  |
| Term loan, non-current | $ | — |  |  | $ | 484.0 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001633978-20-000008:notes:199]
[same as prior period, unchanged from 0001633978-20-000003:notes:198]

[0001633978-20-000008:notes:200]
[same as prior period, unchanged from 0001633978-20-000003:notes:199]

[0001633978-20-000008:notes:201]
[same as prior period, unchanged from 0001633978-20-000003:notes:200]

[0001633978-20-000008:notes:202]
|  | Foreign currency translation adjustments, net of tax (1) |  | Defined benefit obligations, net of tax (2) |  | Unrealized gain (loss) on available-for-sale securities, net of tax (3) |  | Total |
| Beginning balance as of June 29, 2019 (3) | $ | 9.7 |  |  | $ | (3.5 | ) |  | $ | 0.9 |  |  | $ | 7.1 |  |
| Other comprehensive income | — |  |  | — |  |  | 0.1 |  |  | 0.1 |  |
| Ending balance as of September 28, 2019 (3) | 9.7 |  |  | (3.5 | ) |  | 1.0 |  |  | 7.2 |  |
| Other comprehensive loss | — |  |  | — |  |  | (0.2 | ) |  | (0.2 | ) |
| Ending balance as of December 28, 2019 (3) | 9.7 |  |  | (3.5 | ) |  | 0.8 |  |  | 7.0 |  |
| Other comprehensive loss | — |  |  | — |  |  | (1.2 | ) |  | (1.2 | ) |
| Ending balance as of March 28, 2020 (3) | $ | 9.7 |  |  | $ | (3.5 | ) |  | $ | (0.4 | ) |  | $ | 5.8 |  |
| Beginning balance as of June 30, 2018 | $ | 10.3 |  |  | $ | (2.3 | ) |  | $ | (1.6 | ) |  | $ | 6.4 |  |
| Other comprehensive income | 0.1 |  |  | — |  |  | 0.4 |  |  | 0.5 |  |
| Ending balance as of September 29, 2018 | 10.4 |  |  | (2.3 | ) |  | (1.2 | ) |  | 6.9 |  |
| Other comprehensive income (loss) | (0.7 | ) |  | (0.1 | ) |  | 0.1 |  |  | (0.7 | ) |
| Ending balance as of December 29, 2018 | 9.7 |  |  | (2.4 | ) |  | (1.1 | ) |  | 6.2 |  |
| Other comprehensive income | — |  |  | — |  |  | 1.3 |  |  | 1.3 |  |
| Ending balance as of March 30, 2019 | $ | 9.7 |  |  | $ | (2.4 | ) |  | $ | 0.2 |  |  | $ | 7.5 |  |

[0001633978-20-000008:notes:203]
(1) In fiscal 2019, as a result of significant changes in economic facts and circumstances, primarily due to the acquisition of Oclaro, we established the functional currency for our worldwide operations as the U.S. dollar. Translation adjustments reported prior to December 10, 2018, remain as a component of accumulated other comprehensive income in our condensed consolidated balance sheets, until all or a part of the investment in the subsidiaries is sold or liquidated.

[0001633978-20-000008:notes:204]
(2) We evaluate the assumptions over the fair value of our defined benefit obligations annually and make changes as necessary.
(3) Fiscal 2020 balances of unrealized gain (loss) on available-for-sale securities are net of tax of $0.2 million.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001633978-20-000008:notes:205]
[same as prior period, unchanged from 0001633978-20-000003:notes:206]

[0001633978-20-000008:notes:206]
[same as prior period, unchanged from 0001633978-20-000003:notes:207]

[0001633978-20-000008:notes:207]
The following table summarizes the activity of restructuring and related charges during the three and nine months ended March 28, 2020 and March 30, 2019 (in millions):

[0001633978-20-000008:notes:208]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| Balance as of beginning of period | $ | 5.0 |  |  | $ | 3.5 |  |  | $ | 14.6 |  |  | $ | 1.9 |  |
| Charges | 2.7 |  |  | 21.1 |  |  | 4.9 |  |  | 30.2 |  |
| Payments | (5.1 | ) |  | (6.6 | ) |  | (16.9 | ) |  | (14.1 | ) |
| Balance as of end of period | $ | 2.6 |  |  | $ | 18.0 |  |  | $ | 2.6 |  |  | $ | 18.0 |  |

[0001633978-20-000008:notes:209]
During the three and nine months ended March 28, 2020, we recorded $2.7 million and $4.9 million, respectively, in restructuring and related charges in our condensed consolidated statements of operations. The charges were mainly attributable to severance charges associated with the decision to move certain manufacturing from San Jose, California to our facility in Thailand.

[0001633978-20-000008:notes:210]
During the three and nine months ended March 30, 2019, we recorded $21.1 million and $30.2 million, respectively, in restructuring and related charges in our condensed consolidated statements of operations, primarily attributable to severance and employee related benefits associated with the wind down of operations for Lithium Niobate modulators and Datacom modules

[0001633978-20-000008:notes:211]
resulting in $18.0 million of severance charges and $1.6 million  of lease restructuring charges.  During the three and nine months ended March 30, 2019, we also recorded restructuring charges primarily associated with acquisition related synergies.  In addition, the nine month period charges included severance and employee related benefits associated with Oclaro’s executive severance and retention agreements. These retention agreements provided, under certain circumstances, for payments and benefits upon an involuntary termination of employment.

[0001633978-20-000008:notes:212]
[same as prior period, unchanged from 0001633978-20-000003:notes:213]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001633978-20-000008:notes:213]
[same as prior period, unchanged from 0001633978-20-000003:notes:214]

[0001633978-20-000008:notes:214]
[same as prior period, unchanged from 0001633978-20-000003:notes:215]

[0001633978-20-000008:notes:215]
We recorded a tax provision of $5.2 million and $19.6 million for the three and nine months ended March 28, 2020, respectively. We recognized a discrete tax benefit of $4.1 million during the three months ended March 28, 2020 from the release of uncertain tax positions related to the fiscal 2016 U.S. federal income tax return as a result of the expiration of statute of limitations during the quarter. Our estimated effective tax rate for fiscal 2020 differs from the 21% U.S. statutory rate primarily due to the income tax benefit of the earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate as well as the U.S. federal R&D and foreign  tax credits, partially offset by the income tax expense from non-deductible stock-based compensation and the tax effect of Global Intangible Low-Taxed Income (“GILTI”), Base Erosion and Anti-Abuse Tax (“BEAT”), and subpart F inclusion.

[0001633978-20-000008:notes:216]
As of March 28, 2020, we had $18.1 million of unrecognized tax benefits, which, if recognized, would affect the effective tax rate. We are subject to examination of income tax returns by various domestic and foreign tax authorities. The timing of commencement, resolution and closure of tax audits is highly unpredictable. Although it is possible that certain ongoing tax audits may be concluded within the next 12 months, we cannot reasonably estimate the impact to tax expense and net income from tax exams that could be resolved or closed within the next 12 months. Subject to audit timing and uncertainty, we expect our unrecognized tax benefit amount that could affect the effective tax rate to decrease by $1.2 million over the next 12 months.

[0001633978-20-000008:notes:217]
[same as prior period, unchanged from 0001633978-20-000003:notes:218]

[0001633978-20-000008:notes:218]
[same as prior period, unchanged from 0001633978-20-000003:notes:219]

[0001633978-20-000008:notes:219]
On March 27, 2020, the Coronavirus Aid, Relief, and Economic Security Act (“CARES Act”) was enacted in response to the COVID-19 pandemic. The CARES Act, among other things, permits NOL carryovers and carrybacks to offset 100% of taxable income for taxable years beginning before 2021. In addition, the CARES Act contains modifications on the limitation of business interest for tax years beginning in 2019 and 2020 and accelerates a corporation’s ability to recover AMT refundable credits. The Company is currently evaluating the impact of the CARES Act, but at present does not expect that the provisions of the CARES Act would result in a material cash benefit.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001633978-20-000008:notes:220]
[same as prior period, unchanged from 0001633978-20-000003:notes:220]

[0001633978-20-000008:notes:221]
[same as prior period, unchanged from 0001633978-20-000003:notes:221]

[0001633978-20-000008:notes:222]
[same as prior period, unchanged from 0001633978-20-000003:notes:222]

[0001633978-20-000008:notes:223]
As of March 28, 2020, we had 2.4 million shares subject to stock options, restricted stock units, restricted stock awards, and performance stock units issued and outstanding under the 2015 Equity Incentive Plan (the “2015 Plan”).

[0001633978-20-000008:notes:224]
[same as prior period, unchanged from 0001633978-20-000003:notes:224]

[0001633978-20-000008:notes:225]
As of March 28, 2020, 3.6 million shares of common stock under the 2015 Plan were available for grant.

[0001633978-20-000008:notes:226]
[same as prior period, unchanged from 0001633978-20-000003:notes:226]

[0001633978-20-000008:notes:227]
[same as prior period, unchanged from 0001633978-20-000003:notes:227]

[0001633978-20-000008:notes:228]
[same as prior period, unchanged from 0001633978-20-000003:notes:228]

[0001633978-20-000008:notes:229]
[same as prior period, unchanged from 0001633978-20-000003:notes:229]

[0001633978-20-000008:notes:230]
[same as prior period, unchanged from 0001633978-20-000003:notes:230]

[0001633978-20-000008:notes:231]
[same as prior period, unchanged from 0001633978-20-000003:notes:231]

[0001633978-20-000008:notes:232]
[same as prior period, unchanged from 0001633978-20-000003:notes:232]

[0001633978-20-000008:notes:233]
Our 2015 Employee Stock Purchase Plan (the “2015 Purchase Plan”) provides eligible employees with the opportunity to acquire an ownership interest in the Company through periodic payroll deductions and provides a 15% purchase price discount as well as a six-month look-back period. The 2015 Purchase Plan is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986. The 2015 Purchase Plan will terminate upon the date on which all shares available for issuance have been sold. Of the 3.0 million shares authorized under the 2015 Purchase Plan, 1.9 million shares remained available for issuance as of March 28, 2020.

[0001633978-20-000008:notes:234]
[same as prior period, unchanged from 0001633978-20-000003:notes:234]

[0001633978-20-000008:notes:235]
The impact on our results of operations of recording stock-based compensation by function for the three and nine months ended March 28, 2020 was as follows (in millions):

[0001633978-20-000008:notes:236]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| Cost of sales | $ | 4.3 |  |  | $ | 3.2 |  |  | $ | 12.6 |  |  | $ | 11.7 |  |
| Research and development | 4.2 |  |  | 4.5 |  |  | 12.1 |  |  | 10.7 |  |
| Selling, general and administrative | 10.7 |  |  | 8.3 |  |  | 31.4 |  |  | 34.1 |  |
| Total stock-based compensation | $ | 19.2 |  |  | $ | 16.0 |  |  | $ | 56.1 |  |  | $ | 56.5 |  |

[0001633978-20-000008:notes:237]
[same as prior period, unchanged from 0001633978-20-000003:notes:237]

[0001633978-20-000008:notes:238]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| Income tax benefit associated with stock-based compensation | $ | 2.4 |  |  | $ | 2.1 |  |  | $ | 9.0 |  |  | $ | 8.8 |  |

[0001633978-20-000008:notes:239]
Approximately $3.0 million and $3.5 million of stock-based compensation was capitalized to inventory as of March 28, 2020 and June 29, 2019, respectively.

[0001633978-20-000008:notes:240]
[same as prior period, unchanged from 0001633978-20-000003:notes:240]

[0001633978-20-000008:notes:241]
The following table summarizes our awards activity for the nine months ended March 28, 2020 (in millions, except per share amounts):

[0001633978-20-000008:notes:242]
|  |  | Restricted Stock Units |  | Restricted Stock Awards |  | Performance Stock Units |
|  |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance as of June 29, 2019 |  | 2.2 |  |  | $ | 52.4 |  |  | — |  |  | $ | 32.5 |  |  | 0.2 |  |  | $ | 56.0 |  |
| Granted |  | 1.0 |  |  | 59.3 |  |  | — |  |  | — |  |  | 0.2 |  |  | 61.9 |  |
| Vested/Exercised |  | (1.0 | ) |  | 52.1 |  |  | — |  |  | 32.5 |  |  | (0.1 | ) |  | 54.6 |  |
| Canceled |  | (0.2 | ) |  | 51.7 |  |  | — |  |  | — |  |  | — |  |  | 57.3 |  |
| Balance as of March 28, 2020 |  | 2.0 |  |  | $ | 55.6 |  |  | — |  |  | $ | — |  |  | 0.3 |  |  | $ | 60.2 |  |

[0001633978-20-000008:notes:243]
As of March 28, 2020, $111.6 million of stock-based compensation cost related to awards granted to our employees remains to be amortized. That cost is expected to be recognized over an estimated amortization period of 1.9 years.

[0001633978-20-000008:notes:244]
[same as prior period, unchanged from 0001633978-20-000003:notes:244]

[0001633978-20-000008:notes:245]
|  | Awards Available for Grant |
| Balance as of June 29, 2019 | 4.7 |  |
| Granted | (1.2 | ) |
| Canceled | 0.1 |  |
| Balance as of March 28, 2020 | 3.6 |  |

[0001633978-20-000008:notes:246]
[same as prior period, unchanged from 0001633978-20-000003:notes:246]

[0001633978-20-000008:notes:247]
The 2015 Purchase Plan expense for each of the three months ended March 28, 2020 and March 30, 2019 was $0.8 million and $1.1 million, respectively.  The 2015 Purchase Plan expense for the nine months ended March 28, 2020 and March 30, 2019 was $2.5 million and $2.9 million, respectively.  The expense related to the 2015 Purchase Plan is recorded on a straight-line basis over the relevant subscription period. During the three and nine months ended March 28, 2020 there were 0.1 million shares issued to employees through the 2015 Purchase Plan.

[0001633978-20-000008:notes:248]
We estimate the fair value of the 2015 Purchase Plan shares on the date of grant using the Black-Scholes option-pricing model. During each of the three and nine months ended March 28, 2020 and March 30, 2019, the assumptions used to estimate the fair value of the 2015 Purchase Plan shares to be issued were as follows:

[0001633978-20-000008:notes:249]
|  | March 28, 2020 |  | March 30, 2019 |
| Expected term (years) | 0.5 |  |  | 0.5 |  |
| Expected volatility | 44.6 | % |  | 71.3 | % |
| Risk-free interest rate | 1.59 | % |  | 2.52 | % |
| Dividend yield | — | % |  | — | % |

[0001633978-20-000008:notes:250]
[same as prior period, unchanged from 0001633978-20-000003:notes:250]

[0001633978-20-000008:notes:251]
In December 2019, concurrently with the issuance of the 2026 Notes, we repurchased 2.9 million shares of our common stock in privately negotiated transactions at an average price of $69.68 per share for an aggregate purchase price of $200 million. These shares were retired immediately.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001633978-20-000008:notes:252]
Note 17. Commitments and Contingencies

[0001633978-20-000008:notes:253]
Purchase Obligations

[0001633978-20-000008:notes:254]
Purchase obligations of $257.2 million as of March 28, 2020, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements.

[0001633978-20-000008:notes:255]
Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001633978-20-000008:notes:256]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with such vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

[0001633978-20-000008:notes:257]
Product Warranties

[0001633978-20-000008:notes:258]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, product components or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001633978-20-000008:notes:259]
The following table presents the changes in our warranty reserve during the three and nine months ended March 28, 2020 and March 30, 2019 (in millions):

[0001633978-20-000008:notes:260]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| Balance as of beginning of period | $ | 6.8 |  |  | $ | 9.7 |  |  | $ | 7.5 |  |  | $ | 6.6 |  |
| Warranties assumed in Oclaro acquisition | — |  |  | — |  |  | — |  |  | 3.8 |  |
| Provision for warranty | 0.7 |  |  | 1.5 |  |  | 2.5 |  |  | 3.4 |  |
| Utilization of reserve | (2.1 | ) |  | (1.4 | ) |  | (4.6 | ) |  | (4.0 | ) |
| Balance as of end of period | $ | 5.4 |  |  | $ | 9.8 |  |  | $ | 5.4 |  |  | $ | 9.8 |  |

[0001633978-20-000008:notes:261]
Environmental Liabilities

[0001633978-20-000008:notes:262]
Our research and development (“R&D”), manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental, product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001633978-20-000008:notes:263]
Legal Proceedings

[0001633978-20-000008:notes:264]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse

[0001633978-20-000008:notes:265]
impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss. We have recorded $1.0 million of litigation contingency in other current liabilities on the condensed consolidated balance sheet as of March 28, 2020.

[0001633978-20-000008:notes:266]
Merger Litigation

[0001633978-20-000008:notes:267]
In connection with our acquisition of Oclaro, seven lawsuits were filed by purported stockholders of Oclaro challenging the proposed merger (the “Merger”). Two of the seven suits were putative class actions filed against Oclaro, its directors, Lumentum, Prota Merger Sub, Inc. and Prota Merger, LLC: Nicholas Neinast v. Oclaro, Inc., et al., No. 3:18-cv-03112-VC, in the United States District Court for the Northern District of California (filed May 24, 2018) (the “Neinast Lawsuit”); and Adam Franchi v. Oclaro, Inc., et al., No. 1:18-cv-00817-GMS, in the United States District Court for the District of Delaware (filed June 9, 2018) (the “Franchi Lawsuit”). Both the Neinstat Lawsuit and the Franchi Lawsuit were voluntarily dismissed with prejudice.

[0001633978-20-000008:notes:268]
The other five suits, styled as Gerald F. Wordehoff v. Oclaro, Inc., et al., No. 5:18-cv-03148-NC (the “Wordehoff Lawsuit”), Walter Ryan v. Oclaro, Inc., et al., No. 3:18-cv-03174-VC (the “Ryan Lawsuit”), Jayme Walker v. Oclaro, Inc., et al., No. 5:18-cv-03203-EJD (the “Walker Lawsuit”), Kevin Garcia v. Oclaro, Inc., et al., No. 5:18-cv-03262-VKD (the “Garcia Lawsuit”), and SaiSravan B. Karri v. Oclaro, Inc., et al., No. 3:18-cv-03435-JD (the “Karri Lawsuit” and, together with the other six lawsuits, the “Lawsuits”), were filed in the United States District Court for the Northern District of California on May 25, 2018, May 29, 2018, May 30, 2018, May 31, 2018, and June 9, 2018, respectively. These five Lawsuits named Oclaro and its directors as defendants only and did not name Lumentum. The Wordehoff, Ryan, Walker, and Garcia Lawsuits have been voluntarily dismissed, and the Wordehoff, Ryan, and Walker dismissals were with prejudice. The Karri Lawsuit has not yet been dismissed. The Ryan Lawsuit was, and the Karri Lawsuit is, a putative class action.

[0001633978-20-000008:notes:269]
The Lawsuits generally alleged, among other things, that Oclaro and its directors violated Section 14(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), and Rule 14a-9 promulgated thereunder by disseminating an incomplete and misleading Form S-4, including proxy statement/prospectus. The Lawsuits further alleged that Oclaro’s directors violated Section 20(a) of the Exchange Act by failing to exercise proper control over the person(s) who violated Section 14(a) of the Exchange Act.

[0001633978-20-000008:notes:270]
The remaining Lawsuit (the Karri Lawsuit) currently purports to seek, among other things, damages to be awarded to the plaintiff and any class, if a class is certified, and litigation costs, including attorneys’ fees.  A lead plaintiff and counsel has been selected, and an amended complaint was filed on April 15, 2019, which also names Lumentum as a defendant.  A motion to dismiss the amended complaint has been fully briefed and is currently pending, and defendants intend to defend the Karri Lawsuit vigorously.

[0001633978-20-000008:notes:271]
Indemnifications

[0001633978-20-000008:notes:272]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of March 28, 2020, we did not have any material indemnification claims that were probable or reasonably possible.

[0001633978-20-000008:notes:273]
Audit Proceedings

[0001633978-20-000008:notes:274]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.
In connection with our acquisition of Oclaro, we recorded $1.1 million in Malaysia Goods and Services Tax (“GST”) refund claims within prepaid expenses and other current assets in our condensed consolidated balance sheet. The refund claim represents an initial claim of $2.5 million of GST, net of reserves, that was previously denied by the Malaysian tax authorities in 2016. During the nine months ended March 28, 2020, we were able to favorably resolve this audit and received refunds for all of our outstanding GST claims.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001633978-20-000008:notes:275]
[same as prior period, unchanged from 0001633978-20-000003:notes:277]

[0001633978-20-000008:notes:276]
[same as prior period, unchanged from 0001633978-20-000003:notes:278]

[0001633978-20-000008:notes:277]
[same as prior period, unchanged from 0001633978-20-000003:notes:279]

[0001633978-20-000008:notes:278]
[same as prior period, unchanged from 0001633978-20-000003:notes:280]

[0001633978-20-000008:notes:279]
[same as prior period, unchanged from 0001633978-20-000003:notes:281]

[0001633978-20-000008:notes:280]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| Net revenue: |  |  |  |  |  |  |  |
| OpComms | $ | 359.3 |  |  | $ | 377.9 |  |  | $ | 1,184.8 |  |  | $ | 1,013.4 |  |
| Lasers | 43.5 |  |  | 55.0 |  |  | 125.7 |  |  | 147.3 |  |
| Net revenue | $ | 402.8 |  |  | $ | 432.9 |  |  | $ | 1,310.5 |  |  | $ | 1,160.7 |  |
| Gross profit: |  |  |  |  |  |  |  |
| OpComms | $ | 161.8 |  |  | $ | 143.5 |  |  | $ | 550.1 |  |  | $ | 397.5 |  |
| Lasers | 21.6 |  |  | 25.3 |  |  | 56.2 |  |  | 63.6 |  |
| Total segment gross profit | 183.4 |  |  | 168.8 |  |  | 606.3 |  |  | 461.1 |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Stock-based compensation | (4.3 | ) |  | (3.2 | ) |  | (12.6 | ) |  | (11.7 | ) |
| Amortization of acquired intangibles | (13.9 | ) |  | (28.1 | ) |  | (38.8 | ) |  | (33.3 | ) |
| Amortization of fair value adjustments | (1.5 | ) |  | (14.5 | ) |  | (5.8 | ) |  | (15.8 | ) |
| Inventory and fixed asset write down due to product lines exit | (2.3 | ) |  | (19.4 | ) |  | (6.0 | ) |  | (19.4 | ) |
| Integration related costs | 0.3 |  |  | (2.8 | ) |  | (3.1 | ) |  | (2.8 | ) |
| Other charges (1) | (4.0 | ) |  | (12.5 | ) |  | (25.5 | ) |  | (39.0 | ) |
| Gross profit | $ | 157.7 |  |  | $ | 88.3 |  |  | $ | 514.5 |  |  | $ | 339.1 |  |

[0001633978-20-000008:notes:281]
(1) “Other charges” of unallocated corporate items for the three and nine months ended March 28, 2020 primarily include costs of transferring product lines to new production facilities, including Thailand of $0.4 million and $8.5 million, respectively. We also incurred excess and obsolete inventory charges driven by the decline in demand from Huawei of $0.1 million and $12.8 million during the three and nine months ended March 28, 2020. In addition, there were expenses of $1.6 million related to COVID-19 outbreak during the three and nine months ended March 28, 2020, which include incremental costs for payroll expense such as overtime pay, facilities costs such as gloves, masks and temperature gauges, and under-utilized capacity at certain facilities, in which manufacturing output was impacted. These COVID-19 related costs are offset by benefits realized from government credits for employers’ payroll tax.

[0001633978-20-000008:notes:282]
During the three and nine months ended March 30, 2019, “other charges” of unallocated corporate items included costs of transferring product lines to Thailand of $12.0 million and $38.7 million, respectively.

[0001633978-20-000008:notes:283]
[same as prior period, unchanged from 0001633978-20-000003:notes:284]

[0001633978-20-000008:notes:284]
[same as prior period, unchanged from 0001633978-20-000003:notes:285]

[0001633978-20-000008:notes:285]
[same as prior period, unchanged from 0001633978-20-000003:notes:286]

[0001633978-20-000008:notes:286]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| OpComms: |  |  |  |  |  |  |  |  |  |  |  |
| Telecom and Datacom | $ | 251.0 |  | 62.3 | % |  | $ | 300.7 |  | 69.5 | % |  | $ | 765.4 |  | 58.4 | % |  | $ | 683.7 |  | 58.9 | % |
| Consumer and Industrial | 108.3 |  | 26.9 |  |  | 77.2 |  | 17.8 |  |  | 419.4 |  | 32.0 |  |  | 329.7 |  | 28.4 |  |
| Total OpComms | $ | 359.3 |  | 89.2 | % |  | $ | 377.9 |  | 87.3 | % |  | $ | 1,184.8 |  | 90.4 | % |  | $ | 1,013.4 |  | 87.3 | % |
| Lasers | 43.5 |  | 10.8 |  |  | 55.0 |  | 12.7 |  |  | 125.7 |  | 9.6 |  |  | 147.3 |  | 12.7 |  |
| Total Revenue | $ | 402.8 |  |  |  |  | $ | 432.9 |  |  |  | $ | 1,310.5 |  |  |  | $ | 1,160.7 |  |  |

[0001633978-20-000008:notes:287]
[same as prior period, unchanged from 0001633978-20-000003:notes:288]

[0001633978-20-000008:notes:288]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 38.6 |  |  | 9.6 | % |  | $ | 29.7 |  |  | 6.9 | % |  | $ | 118.9 |  |  | 9.1 | % |  | $ | 72.3 |  |  | 6.3 | % |
| Mexico | 33.2 |  |  | 8.2 |  |  | 53.5 |  |  | 12.3 |  |  | 88.3 |  |  | 6.7 |  |  | 164.8 |  |  | 14.2 |  |
| Other Americas | 1.4 |  |  | 0.3 |  |  | 0.9 |  |  | 0.2 |  |  | 3.2 |  |  | 0.3 |  |  | 2.7 |  |  | 0.2 |  |
| Total Americas | $ | 73.2 |  |  | 18.1 | % |  | $ | 84.1 |  |  | 19.4 | % |  | $ | 210.4 |  |  | 16.1 | % |  | $ | 239.8 |  |  | 20.7 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 125.9 |  |  | 31.3 | % |  | $ | 124.1 |  |  | 28.6 | % |  | $ | 404.2 |  |  | 30.8 | % |  | $ | 289.6 |  |  | 25.0 | % |
| South Korea | 63.3 |  |  | 15.7 |  |  | 23.6 |  |  | 5.5 |  |  | 239.9 |  |  | 18.3 |  |  | 154.9 |  |  | 13.3 |  |
| Japan | 35.8 |  |  | 8.9 |  |  | 50.0 |  |  | 11.6 |  |  | 110.4 |  |  | 8.4 |  |  | 129.2 |  |  | 11.1 |  |
| Other Asia-Pacific | 77.2 |  |  | 19.2 |  |  | 98.4 |  |  | 22.7 |  |  | 248.8 |  |  | 19.0 |  |  | 234.4 |  |  | 20.2 |  |
| Total Asia-Pacific | $ | 302.2 |  |  | 75.1 | % |  | $ | 296.1 |  |  | 68.4 | % |  | $ | 1,003.3 |  |  | 76.5 | % |  | $ | 808.1 |  |  | 69.6 | % |
| EMEA | $ | 27.4 |  |  | 6.8 | % |  | $ | 52.7 |  |  | 12.2 | % |  | $ | 96.8 |  |  | 7.4 | % |  | $ | 112.8 |  |  | 9.7 | % |
| Total net revenue | $ | 402.8 |  |  |  |  |  | $ | 432.9 |  |  |  |  |  | $ | 1,310.5 |  |  |  |  |  | $ | 1,160.7 |  |  |  |  |

[0001633978-20-000008:notes:289]
During the three and nine months ended March 28, 2020, net revenue from customers outside the United States, based on customer shipping location, represented 90.4% and 90.9% of net revenue, respectively.

[0001633978-20-000008:notes:290]
During the three and nine months ended March 30, 2019, net revenue from customers outside the United States, based on customer shipping location, represented 93.1% and 93.7% of net revenue, respectively.

[0001633978-20-000008:notes:291]
The increase in our net revenue from the United States during the nine months ended March 28, 2020 compared to the nine months ended March 30, 2019 is mainly due to the acquisition of Oclaro, which had a higher concentration of customers who manufacture in the United States, as well as a change in shipment destination for some shipments to one of our large customers from Mexico to the United States. During the nine months ended March 28, 2020, our net revenue from South Korea increased due to higher demand in 3D sensing products, while net revenue from Hong Kong increased as a result of higher sales of 3D sensing products and Datacom chips.

[0001633978-20-000008:notes:292]
[same as prior period, unchanged from 0001633978-20-000003:notes:292]

[0001633978-20-000008:notes:293]
The following table includes estimated revenue expected to be recognized in the future for backlog related performance obligations that are unsatisfied as of March 28, 2020 (in millions):

[0001633978-20-000008:notes:294]
|  | Less than 1 year | 1-2 years | Greater than 2 years | Total |
| Performance obligations | $513.9 | $32.7 | $— | $546.6 |

[0001633978-20-000008:notes:295]
[same as prior period, unchanged from 0001633978-20-000003:notes:295]

[0001633978-20-000008:notes:296]
The following table reflects the changes in contract balances as of March 28, 2020 (in millions, except percentages):

[0001633978-20-000008:notes:297]
| Contract balances | Balance sheet location | March 28, 2020 |  | June 29, 2019 |  | Change |  | Percentage Change |
| Accounts receivable, net | Accounts receivable, net | $261.8 |  | $238.0 |  | $23.8 |  | 10.0% |
| Deferred revenue and customer deposits | Other current liabilities | $1.7 |  | $2.9 |  | $(1.2) |  | (41.4)% |

[0001633978-20-000008:notes:298]
During the three and nine months ended March 28, 2020, our net revenue was concentrated with two customers, who collectively accounted for 37% and 42% of our total net revenue, respectively.

[0001633978-20-000008:notes:299]
During the three and nine months ended March 30, 2019, our net revenue was concentrated with three customers, who collectively accounted for 44% and 52% of our total net revenue, respectively.

[0001633978-20-000008:notes:300]
As of March 28, 2020 and June 29, 2019, our accounts receivable balance was concentrated with two and three customers, who collectively represented 27% and 44% of gross accounts receivable, respectively.

[0001633978-20-000008:notes:301]
[same as prior period, unchanged from 0001633978-20-000003:notes:301]

[0001633978-20-000008:notes:302]
|  | March 28, 2020 |  | June 29, 2019 |
| Property, plant and equipment, net |  |  |  |
| United States | $ | 145.8 |  |  | $ | 156.2 |  |
| Thailand | 135.3 |  |  | 157.1 |  |
| China | 43.3 |  |  | 33.5 |  |
| Japan | 29.2 |  |  | 28.3 |  |
| Other countries | 56.5 |  |  | 58.2 |  |
| Total long-lived assets | $ | 410.1 |  |  | $ | 433.3 |  |

[0001633978-20-000008:notes:303]
We purchase a substantial portion of our inventory from contract manufacturers and vendors located primarily in Taiwan, Thailand, and Malaysia. During the three and nine months ended March 28, 2020, net inventory purchases which represented 10% or greater of total net purchases, were concentrated with two contract manufacturers, who collectively accounted for 88% and 85% of total net inventory purchases, respectively. During the three and nine months ended March 30, 2019, net inventory purchases were concentrated with three contract manufacturers, who collectively accounted for 85% and 85% of total net inventory purchases, respectively.
