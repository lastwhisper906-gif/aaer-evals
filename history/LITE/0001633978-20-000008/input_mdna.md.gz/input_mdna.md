# LITE MD&A — 0001633978-20-000008


## mdna

[0001633978-20-000008:mdna:1]
[same as prior period, unchanged from 0001633978-20-000003:mdna:1]

[0001633978-20-000008:mdna:2]
[same as prior period, unchanged from 0001633978-20-000003:mdna:2]

[0001633978-20-000008:mdna:3]
[same as prior period, unchanged from 0001633978-20-000003:mdna:3]

[0001633978-20-000008:mdna:4]
[same as prior period, unchanged from 0001633978-20-000003:mdna:5]

[0001633978-20-000008:mdna:5]
[same as prior period, unchanged from 0001633978-20-000003:mdna:6]

[0001633978-20-000008:mdna:6]
[same as prior period, unchanged from 0001633978-20-000003:mdna:7]

[0001633978-20-000008:mdna:7]
On December 10, 2018, we completed the acquisition of Oclaro, a provider of optical components and modules for the long-haul, metro and data center markets. Refer to “Note 4. Business Combinations” in the notes to condensed consolidated financial statements for further discussion of the merger.

[0001633978-20-000008:mdna:8]
Following the acquisition of Oclaro, during our fiscal 2019, we began making several strategic changes to our OpComms business to better position it for growth and profitability. These changes include attaining acquisition cost synergies related to redundant capabilities, the discontinuing of Telecom Lithium Niobate modulators and Datacom transceiver modules because of their muted growth and profitability trends.  We expect actions related to these changes to be completed in fiscal 2021. We don’t believe we are diminishing our profit potential in discontinuing and/or selling these product lines. We expect our Indium Phosphide photonic integrated circuits will continue to replace Lithium Niobate modulators over time and focusing on the development and sale of Datacom chips will enable to profitably participate in the growth in the Datacom and 5G wireless markets.

[0001633978-20-000008:mdna:9]
Related to the strategic changes in our OpComms business, we entered into two strategic transactions to sell some of the discontinued product lines.  In the second quarter of fiscal year 2020, we entered into an agreement with Advanced Fiber Resources (Zhuhai) Ltd. (“AFR”), a leading provider of passive optical components, to acquire the assets associated with certain Lithium Niobate product lines manufactured by our San Donato site for $17 million. The transaction was closed in the third quarter of fiscal year 2020. For further information regarding this transaction, refer to “Note 5. Assets and Liabilities Held For Sale” in the notes to condensed consolidated financial statements. On April 18, 2019, we closed a transaction selling many of our Datacom transceiver module product lines to Cambridge Industries Group (“CIG”). For further information regarding this transaction, refer to “Note 4. Business Combinations” in the notes to condensed consolidated financial statements.

[0001633978-20-000008:mdna:10]
Impact of COVID-19 to our Business

[0001633978-20-000008:mdna:11]
The outbreak of the COVID-19 has been declared a pandemic by the World Health Organization and continues to spread globally. The spread of COVID-19 has caused public health officials to recommend, and governments to enact, precautions to mitigate the spread of the virus, including travel restrictions and bans, extensive social distancing guidelines and issuing a “shelter-in-place” order in many regions of the world. The pandemic and these related responses have caused, and are expected to continue to cause a global slowdown of economic activity (including the decrease in demand for a broad variety of goods and services), disruptions in global supply chains and significant volatility and disruption of financial markets  We have adopted several measures in response to the COVID-19 outbreak including complying with local, state or federal orders that require employees to work from home, instructing employees to work from home in certain jurisdictions, limiting the number of employees onsite which slowed our manufacturing operations in certain countries, enhanced use of personal protective equipment and restricting non-critical business travel by our employees.

[0001633978-20-000008:mdna:12]
In the geographies we have operations, we have in general been deemed an essential business and been permitted to continue manufacturing and new product development operations in a more limited capacity during the pandemic. This stems from our critical role in global supply chains for the world’s communications and health-care systems. Given the rapidly evolving situation, it is difficult to predict precisely when our ability to supply our products will improve or the magnitude and duration of the impact of the COVID-19 pandemic to our markets. The Company will continue to actively monitor the situation and may take further actions altering our business operations that we determine are in the best interests of our employees, customers, communities, business partners, suppliers, and stockholders, or as required by federal, state, or local authorities. It is not clear what the potential

[0001633978-20-000008:mdna:13]
effects any such alterations or modifications may have on our business, including the effects on the Company's customers, employees, and prospects, or on our financial results for the remainder of fiscal year 2020.

[0001633978-20-000008:mdna:14]
While the recent outbreak of the COVID-19 did not have a material adverse effect on our reported results for our third quarter, we are actively monitoring the impact of the coronavirus outbreak. Due to the severity of COVID-19 in the United States and the timing of the most significant responses thereto in March, we believe the impact on our business in the fourth quarter and beyond will be greater than it was in the third quarter of 2020. The extent to which our operations will be impacted by the outbreak will depend largely on future developments, which are highly uncertain and cannot be accurately predicted, including new information which may emerge concerning the severity of the outbreak and actions by government authorities and private businesses to contain the outbreak or recover from its impact, among other things.

[0001633978-20-000008:mdna:15]
Our primary strategic focus for several years has been technology and product leadership combined with close customer relationships in long-term healthy and growing markets. We believe this strategy is even more apt, and our long-term opportunity is not diminished with COVID-19. We believe there may be long-term opportunities, as the world’s experience with COVID-19 could drive an increasingly digital and virtual world touching all aspects of life and work that increasingly emphasizes communications systems, cloud services, augmented and virtual reality, and enhanced security. Additionally, ever advancing electronic devices are needed to consume, produce, and communicate digital and virtual content. All these trends could drive the need for higher volumes of higher performing optical devices that we could supply. As such, we expect to continue to invest strongly in new products, technology, and customer programs.

[0001633978-20-000008:mdna:16]
For more information on risks associated with the COVID-19 outbreak, see the section titled “Risk Factors” in Item 1A of Part II.

[0001633978-20-000008:mdna:17]
[same as prior period, unchanged from 0001633978-20-000003:mdna:13]

[0001633978-20-000008:mdna:18]
Our condensed consolidated financial statements are prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) as set forth in the Financial Accounting Standards Board’s Accounting Standards Codification (“ASC”), and we consider the various staff accounting bulletins and other applicable guidance issued by the United States Securities and Exchange Commission (“SEC”). GAAP, as set forth within the ASC, requires us to make certain estimates, judgments and assumptions. We believe that the estimates, judgments and assumptions upon which we rely are reasonable based upon information available to us at the time that these estimates, judgments and assumptions are made. These estimates, judgments and assumptions can affect the reported amounts of assets and liabilities as of the date of the financial statements as well as the reported amounts of revenues and expenses during the periods presented. To the extent there are differences between these estimates, judgments or assumptions and actual results, our financial statements will be affected. Our management does not believe COVID-19 will have a significant impact on our critical accounting policies. The accounting policies that reflect our more significant estimates, judgments and assumptions and which we believe are the most critical to aid in fully understanding and evaluating our reported financial results include the following:

[0001633978-20-000008:mdna:19]
[same as prior period, unchanged from 0001633978-20-000003:mdna:15]

[0001633978-20-000008:mdna:20]
[same as prior period, unchanged from 0001633978-20-000003:mdna:16]

[0001633978-20-000008:mdna:21]
[same as prior period, unchanged from 0001633978-20-000003:mdna:17]

[0001633978-20-000008:mdna:22]
[same as prior period, unchanged from 0001633978-20-000003:mdna:18]

[0001633978-20-000008:mdna:23]
[same as prior period, unchanged from 0001633978-20-000003:mdna:19]

[0001633978-20-000008:mdna:24]
[same as prior period, unchanged from 0001633978-20-000003:mdna:20]

[0001633978-20-000008:mdna:25]
Except for the adoption of ASU 2016-02, Leases (Topic 842) and the resulting changes in our accounting policies and disclosures for lease accounting, there have been no significant changes to our significant accounting policies as of and for the three months ended March 28, 2020, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the year ended June 29, 2019. Refer to “Note 1. Description of Business and Summary of Significant Accounting Policies” for the details of ASU 2016-02 (Topic 842) adoption. Management’s Discussion and Analysis of Financial Condition and Results of Operations contained in Part II, Item 7 of our Annual Report on Form 10-K for our fiscal year ended June 29, 2019 provides a more complete discussion of our critical accounting policies and estimates.

[0001633978-20-000008:mdna:26]
Recently Issued Accounting Pronouncements

[0001633978-20-000008:mdna:27]
Refer to “Note 2. Recently Issued Accounting Pronouncements” in the notes to condensed consolidated financial statements.

[0001633978-20-000008:mdna:28]
[same as prior period, unchanged from 0001633978-20-000003:mdna:24]

[0001633978-20-000008:mdna:29]
[same as prior period, unchanged from 0001633978-20-000003:mdna:25]

[0001633978-20-000008:mdna:30]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| Segment net revenue: |  |  |  |  |  |  |  |
| OpComms | 89.2 | % |  | 87.3 | % |  | 90.4 | % |  | 87.3 | % |
| Lasers | 10.8 |  |  | 12.7 |  |  | 9.6 |  |  | 12.7 |  |
| Net revenue | 100.0 |  |  | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of sales | 57.4 |  |  | 73.1 |  |  | 57.8 |  |  | 67.9 |  |
| Amortization of acquired developed technologies | 3.5 |  |  | 6.5 |  |  | 3.0 |  |  | 2.9 |  |
| Gross profit | 39.2 |  |  | 20.4 |  |  | 39.3 |  |  | 29.2 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 12.1 |  |  | 13.3 |  |  | 11.4 |  |  | 11.6 |  |
| Selling, general and administrative | 15.2 |  |  | 12.8 |  |  | 13.8 |  |  | 13.0 |  |
| Restructuring and related charges | 0.7 |  |  | 4.9 |  |  | 0.4 |  |  | 2.6 |  |
| Impairment charges | 0.6 |  |  | 7.0 |  |  | 0.2 |  |  | 2.7 |  |
| Total operating expenses | 28.6 |  |  | 38.0 |  |  | 25.7 |  |  | 29.9 |  |
| Income (loss) from operations | 10.6 |  |  | (17.6 | ) |  | 13.5 |  |  | (0.7 | ) |
| Unrealized gain on derivative liability | — |  |  | — |  |  | — |  |  | 0.8 |  |
| Interest expense | (3.9 | ) |  | (2.6 | ) |  | (3.5 | ) |  | (2.1 | ) |
| Other income (expense), net | 5.4 |  |  | 1.2 |  |  | 2.1 |  |  | 1.0 |  |
| Income (loss) before income taxes | 12.1 |  |  | (19.0 | ) |  | 12.2 |  |  | (1.0 | ) |
| Provision for (benefit from) income taxes | 1.3 |  |  | (1.9 | ) |  | 1.5 |  |  | (0.1 | ) |
| Net income (loss) | 10.8 | % |  | (17.1 | )% |  | 10.7 | % |  | (0.9 | )% |

[0001633978-20-000008:mdna:31]
43

[0001633978-20-000008:mdna:32]
Financial Data for the three and nine months ended March 28, 2020 and March 30, 2019

[0001633978-20-000008:mdna:33]
[same as prior period, unchanged from 0001633978-20-000003:mdna:29]

[0001633978-20-000008:mdna:34]
|  | Three Months Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | March 28, 2020 |  | March 30, 2019 |  | Change |  | Percentage Change |  | March 28, 2020 |  | March 30, 2019 |  | Change |  | Percentage Change |
| Segment net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| OpComms | $ | 359.3 |  |  | $ | 377.9 |  |  | $ | (18.6 | ) |  | (4.9 | )% |  | $ | 1,184.8 |  |  | $ | 1,013.4 |  |  | $ | 171.4 |  |  | 16.9 | % |
| Lasers | 43.5 |  |  | 55.0 |  |  | (11.5 | ) |  | (20.9 | ) |  | 125.7 |  |  | 147.3 |  |  | (21.6 | ) |  | (14.7 | ) |
| Net revenue | $ | 402.8 |  |  | $ | 432.9 |  |  | $ | (30.1 | ) |  | (7.0 | )% |  | $ | 1,310.5 |  |  | $ | 1,160.7 |  |  | $ | 149.8 |  |  | 12.9 | % |
| Gross profit | $ | 157.7 |  |  | $ | 88.3 |  |  | $ | 69.4 |  |  | 78.6 | % |  | $ | 514.5 |  |  | $ | 339.1 |  |  | $ | 175.4 |  |  | 51.7 | % |
| Gross margin | 39.2 | % |  | 20.4 | % |  |  |  |  |  | 39.3 | % |  | 29.2 | % |  |  |  |  |
| Research and development | $ | 48.7 |  |  | $ | 57.7 |  |  | $ | (9.0 | ) |  | (15.6 | )% |  | $ | 149.6 |  |  | $ | 135.1 |  |  | $ | 14.5 |  |  | 10.7 | % |
| Percentage of net revenue | 12.1 | % |  | 13.3 | % |  |  |  |  |  | 11.4 | % |  | 11.6 | % |  |  |  |  |
| Selling, general and administrative | $ | 61.3 |  |  | $ | 55.2 |  |  | $ | 6.1 |  |  | 11.1 | % |  | $ | 180.4 |  |  | $ | 150.9 |  |  | $ | 29.5 |  |  | 19.5 | % |
| Percentage of net revenue | 15.2 | % |  | 12.8 | % |  |  |  |  |  | 13.8 | % |  | 13.0 | % |  |  |  |  |
| Restructuring and related charges | $ | 2.7 |  |  | $ | 21.1 |  |  | $ | (18.4 | ) |  | (87.2 | )% |  | $ | 4.9 |  |  | $ | 30.2 |  |  | $ | (25.3 | ) |  | (83.8 | )% |
| Percentage of net revenue | 0.7 | % |  | 4.9 | % |  |  |  |  |  | 0.4 | % |  | 2.6 | % |  |  |  |  |
| Impairment charge | $ | 2.5 |  |  | $ | 30.7 |  |  | $ | (28.2 | ) |  | (91.9 | )% |  | $ | 2.5 |  |  | $ | 30.7 |  |  | $ | (28.2 | ) |  | (91.9 | )% |
| Percentage of net revenue | 0.6 | % |  | 7.0 | % |  |  |  |  |  | 0.2 | % |  | 2.6 | % |  |  |  |  |

[0001633978-20-000008:mdna:35]
[same as prior period, unchanged from 0001633978-20-000003:mdna:31]

[0001633978-20-000008:mdna:36]
Net revenue decreased by $30.1 million, or 7.0%, during the three months ended March 28, 2020 compared to the three months ended March 30, 2019. This decrease was primarily due to the decreased sales of Telecom and Datacom of $49.7 million and Lasers of $11.5 million, offset by increased sales of Consumer and Industrial of $31.1 million.

[0001633978-20-000008:mdna:37]
OpComms net revenue decreased by $18.6 million, or 4.9%, during the three months ended March 28, 2020 compared to the three months ended March 30, 2019. This decrease was primarily due to decreased sales of Telecom products partially offset by higher sales of 3D sensing products for mobile devices. Our Datacom sales slightly decreased, due to the sale of our Datacom transceiver module business, but such decrease was offset by significant increase in sales of Datacom chips.

[0001633978-20-000008:mdna:38]
Lasers net revenue decreased by $11.5 million, or 20.9%, during the three months ended March 28, 2020 compared to the three months ended March 30, 2019, primarily due to lower revenue from kilowatt class fiber lasers.

[0001633978-20-000008:mdna:39]
Net revenue increased by $149.8 million, or 12.9%, during the nine months ended March 28, 2020 compared to the nine months ended March 30, 2019. This increase was primarily due to the increased sales of Telecom and Datacom of $81.7 million  and Consumer and Industrial of $89.7 million, offset by decreased sales of Lasers of $21.6 million.

[0001633978-20-000008:mdna:40]
OpComms net revenue increased by $171.4 million, or 16.9%, during the nine months ended March 28, 2020 compared to the nine months ended March 30, 2019. This increase was primarily due to increased sales in Telecom products, driven by the acquisition of Oclaro, as well as increased sales in 3D sensing products for mobile devices.

[0001633978-20-000008:mdna:41]
Lasers net revenue decreased by $21.6 million, or 14.7%, during the nine months ended March 28, 2020 compared to the nine months ended March 30, 2019, primarily due to decreased sales of our kilowatt class fiber lasers.

[0001633978-20-000008:mdna:42]
During the three and nine months ended March 28, 2020, our net revenue was concentrated with two customers, who collectively accounted for 37% and 42% of our total net revenue, respectively.

[0001633978-20-000008:mdna:43]
During the three and nine months ended March 30, 2019, our net revenue was concentrated with three customers, who collectively accounted for 44% and 52% of our total net revenue, respectively.

[0001633978-20-000008:mdna:44]
Although the magnitude of the impact of COVID-19 on our business operations remains uncertain and difficult to predict, and this remains a highly dynamic situation, we have experienced and will continue to experience in subsequent periods, disruptions to our and our customers’ businesses that will adversely impact our business, financial condition and results of operations.

[0001633978-20-000008:mdna:45]
[same as prior period, unchanged from 0001633978-20-000003:mdna:40]

[0001633978-20-000008:mdna:46]
[same as prior period, unchanged from 0001633978-20-000003:mdna:41]

[0001633978-20-000008:mdna:47]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 38.6 |  |  | 9.6 | % |  | $ | 29.7 |  |  | 6.9 | % |  | $ | 118.9 |  |  | 9.1 | % |  | $ | 72.3 |  |  | 6.3 | % |
| Mexico | 33.2 |  |  | 8.2 |  |  | 53.5 |  |  | 12.3 |  |  | 88.3 |  |  | 6.7 |  |  | 164.8 |  |  | 14.2 |  |
| Other Americas | 1.4 |  |  | 0.3 |  |  | 0.9 |  |  | 0.2 |  |  | 3.2 |  |  | 0.3 |  |  | 2.7 |  |  | 0.2 |  |
| Total Americas | $ | 73.2 |  |  | 18.1 | % |  | $ | 84.1 |  |  | 19.4 | % |  | $ | 210.4 |  |  | 16.1 | % |  | $ | 239.8 |  |  | 20.7 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 125.9 |  |  | 31.3 | % |  | $ | 124.1 |  |  | 28.6 | % |  | $ | 404.2 |  |  | 30.8 | % |  | $ | 289.6 |  |  | 25.0 | % |
| South Korea | 63.3 |  |  | 15.7 |  |  | 23.6 |  |  | 5.5 |  |  | 239.9 |  |  | 18.3 |  |  | 154.9 |  |  | 13.3 |  |
| Japan | 35.8 |  |  | 8.9 |  |  | 50.0 |  |  | 11.6 |  |  | 110.4 |  |  | 8.4 |  |  | 129.2 |  |  | 11.1 |  |
| Other Asia-Pacific | 77.2 |  |  | 19.2 |  |  | 98.4 |  |  | 22.7 |  |  | 248.8 |  |  | 19.0 |  |  | 234.4 |  |  | 20.2 |  |
| Total Asia-Pacific | $ | 302.2 |  |  | 75.1 | % |  | $ | 296.1 |  |  | 68.4 | % |  | $ | 1,003.3 |  |  | 76.5 | % |  | $ | 808.1 |  |  | 69.6 | % |
| EMEA | $ | 27.4 |  |  | 6.8 | % |  | $ | 52.7 |  |  | 12.2 | % |  | $ | 96.8 |  |  | 7.4 | % |  | $ | 112.8 |  |  | 9.7 | % |
| Total net revenue | $ | 402.8 |  |  |  |  |  | $ | 432.9 |  |  |  |  |  | $ | 1,310.5 |  |  |  |  |  | $ | 1,160.7 |  |  |  |  |

[0001633978-20-000008:mdna:48]
For the three and nine months ended March 28, 2020, net revenue from customers outside the United States, based on customer shipping location, represented 90.4% and 90.9% of net revenue, respectively.

[0001633978-20-000008:mdna:49]
For the three and nine months ended March 30, 2019, net revenue from customers outside the United States, based on customer shipping location, represented 93.1% and 93.7% of net revenue, respectively.

[0001633978-20-000008:mdna:50]
The increase in our net revenue from the United States during the nine months ended March 28, 2020 compared to the nine months ended March 30, 2019 is mainly due to the acquisition of Oclaro, which had a higher concentration of customers who manufacture in the United States, as well as a change in shipment destination for some shipments to one of our large customers from Mexico to the United States. During the nine months ended March 28, 2020, our net revenue from South Korea increased due to higher demand in 3D sensing products, while net revenue from Hong Kong increased as a result of higher sales of 3D sensing products and Datacom chips.

[0001633978-20-000008:mdna:51]
[same as prior period, unchanged from 0001633978-20-000003:mdna:45]

[0001633978-20-000008:mdna:52]
[same as prior period, unchanged from 0001633978-20-000003:mdna:46]

[0001633978-20-000008:mdna:53]
The following table summarizes segment gross margin for the three and nine months ended March 28, 2020 and March 30, 2019 (in millions, except for percentages):

[0001633978-20-000008:mdna:54]
|  | Three Months Ended |  | Nine Months Ended |
|  | Gross Profit |  | Gross Margin |  | Gross Profit |  | Gross Margin |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| OpComms | $ | 161.8 |  |  | $ | 143.5 |  |  | 45.0 | % |  | 38.0 | % |  | $ | 550.1 |  |  | $ | 397.5 |  |  | 46.4 | % |  | 39.2 | % |
| Lasers | 21.6 |  |  | 25.3 |  |  | 49.7 | % |  | 46.0 | % |  | 56.2 |  |  | 63.6 |  |  | 44.7 | % |  | 43.2 | % |
| Segment total | $ | 183.4 |  |  | $ | 168.8 |  |  | 45.5 | % |  | 39.0 | % |  | $ | 606.3 |  |  | $ | 461.1 |  |  | 46.3 | % |  | 39.7 | % |
| Unallocated corporate items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation | (4.3 | ) |  | (3.2 | ) |  |  |  |  |  | (12.6 | ) |  | (11.7 | ) |  |  |  |  |
| Amortization of acquired intangibles | (13.9 | ) |  | (28.1 | ) |  |  |  |  |  | (38.8 | ) |  | (33.3 | ) |  |  |  |  |
| Amortization of fair value adjustments | (1.5 | ) |  | (14.5 | ) |  |  |  |  |  | (5.8 | ) |  | (15.8 | ) |  |  |  |  |
| Inventory and fixed asset write down due to product lines exit | (2.3 | ) |  | (19.4 | ) |  |  |  |  |  | (6.0 | ) |  | (19.4 | ) |  |  |  |  |
| Integration related costs | 0.3 |  |  | (2.8 | ) |  |  |  |  |  | (3.1 | ) |  | (2.8 | ) |  |  |  |  |
| Other charges (1) | (4.0 | ) |  | (12.5 | ) |  |  |  |  |  | (25.5 | ) |  | (39.0 | ) |  |  |  |  |
| Total | $ | 157.7 |  |  | $ | 88.3 |  |  | 39.2 | % |  | 20.4 | % |  | $ | 514.5 |  |  | $ | 339.1 |  |  | 39.3 | % |  | 29.2 | % |

[0001633978-20-000008:mdna:55]
(1) “Other charges” of unallocated corporate items for the three and nine months ended March 28, 2020 primarily include costs of transferring product lines to new production facilities, including Thailand of $0.4 million and $8.5 million, respectively. We also incurred excess and obsolete inventory charges driven by the decline in demand from Huawei of $0.1 million and $12.8 million during the three and nine months ended March 28, 2020. In addition, there were expenses of $1.6 million related to COVID-19 outbreak during the three and nine months ended March 28, 2020, which include incremental costs for payroll expense such as overtime pay, facilities costs such as gloves, masks and temperature gauges, and under-utilized capacity at certain facilities, in which manufacturing output was impacted. These COVID-19 related costs are offset by benefits realized from government credits for employers’ payroll tax. During the three and nine months ended March 30, 2019, “other charges” of unallocated corporate items included costs of transferring product lines to Thailand of $12.0 million and $38.7 million, respectively.

[0001633978-20-000008:mdna:56]
[same as prior period, unchanged from 0001633978-20-000003:mdna:50]

[0001633978-20-000008:mdna:57]
[same as prior period, unchanged from 0001633978-20-000003:mdna:51]

[0001633978-20-000008:mdna:58]
Gross margin for the three months ended March 28, 2020 increased to 39.2% from 20.4% for the three months ended March 30, 2019. The increase was primarily driven by better gross margins within Datacom, due to the sale of our Datacom transceiver module business, which had lower margins, and increased revenue from our Datacom chip products, as well as increased revenue from 3D sensing products for mobile devices. In addition, for the three months ended March 28, 2020, we had lower acquisition related costs such as amortization of acquired intangibles of $14.2 million and amortization of fair value adjustments of $13.0 million, as well as lower inventory and fixed asset write down charges due to product lines exit of $17.1 million.

[0001633978-20-000008:mdna:59]
46

[0001633978-20-000008:mdna:60]
Gross margin for the nine months ended March 28, 2020 increased to 39.3% from 29.2% for the nine months ended March 30, 2019. The increase was primarily driven by better gross margins within Telecom, due to the acquisition of Oclaro, better gross margins within Datacom, due to the sale of our Datacom transceiver module business and increased revenue of our Datacom chip products, which have higher margins, and increased revenue of 3D sensing products for mobile devices. In addition, for the nine months ended March 28, 2020, we had lower amortization of fair value adjustments related to the Oclaro acquisition of $10.0 million, as well as lower inventory and fixed asset write down charges due to product lines exit of $13.4 million.

[0001633978-20-000008:mdna:61]
[same as prior period, unchanged from 0001633978-20-000003:mdna:54]

[0001633978-20-000008:mdna:62]
Although the magnitude of the impact of COVID-19 on our business operations remains uncertain and difficult to predict, and this remains a highly dynamic situation, we have experienced and will continue to experience in subsequent periods, disruptions to our and our customers’ businesses that will adversely impact our business, financial condition and results of operations.

[0001633978-20-000008:mdna:63]
[same as prior period, unchanged from 0001633978-20-000003:mdna:55]

[0001633978-20-000008:mdna:64]
[same as prior period, unchanged from 0001633978-20-000003:mdna:56]

[0001633978-20-000008:mdna:65]
OpComms gross margin for the three months ended March 28, 2020 increased to 45.0% from 38.0% for the three months ended March 30, 2019. The increase was primarily driven by better gross margins within Datacom, due to the sale of our Datacom transceiver module business, which had lower than average gross margins, and increased revenue from our higher margin Datacom chip products, which have higher than average gross margins, and increased revenue of 3D sensing products for mobile devices.

[0001633978-20-000008:mdna:66]
OpComms gross margin for the nine months ended March 28, 2020 increased to 46.4% from 39.2% for the nine months ended March 30, 2019. The increase was primarily driven by better gross margins within Telecom, due to the acquisition of Oclaro, better gross margins within Datacom, due to the sale of our lower margin Datacom transceiver module business and increased revenue of our higher margin Datacom chip products, and increased revenue of 3D sensing products for mobile devices.

[0001633978-20-000008:mdna:67]
[same as prior period, unchanged from 0001633978-20-000003:mdna:59]

[0001633978-20-000008:mdna:68]
Lasers gross margin for the three months ended March 28, 2020 increased to 49.7% from 46.0% for the three months ended March 30, 2019. This increase was primarily driven by the streamlining of our manufacturing supply chain related to our kilowatt class fiber products.

[0001633978-20-000008:mdna:69]
Lasers gross margin for the nine months ended March 28, 2020 increased to 44.7% from 43.2% for the nine months ended March 30, 2019. This increase was primarily driven by the streamlining of our manufacturing supply chain related to our kilowatt class fiber products.

[0001633978-20-000008:mdna:70]
[same as prior period, unchanged from 0001633978-20-000003:mdna:62]

[0001633978-20-000008:mdna:71]
R&D expense decreased by $9.0 million, or 15.6%, for the three months ended March 28, 2020 compared to the three months ended March 30, 2019. The decrease in R&D expense was primarily due to the decrease in payroll related expense of $1.9 million and the decrease in R&D materials of $2.3 million, as a result of the sale of our Datacom transceiver module business. In addition, we had $1.8 million increase in non-recurring engineering credits from customers.

[0001633978-20-000008:mdna:72]
R&D expense increased by $14.5 million, or 10.7%, for the nine months ended March 28, 2020 compared to the nine months ended March 30, 2019. The increase in R&D expense was primarily due to the increase of $9.1 million in investments in key product lines and R&D materials. In addition, payroll related expense increased by $8.5 million mainly due to the acquisition of Oclaro, partially offset by the sale of our Datacom transceiver module business. These increases were offset by $2.4 million higher non-recurring engineering credits from customers.

[0001633978-20-000008:mdna:73]
We believe that continuing our investments in R&D is critical to attaining our strategic objectives. Despite the uncertainty related to COVID-19 and the global economic outlook, we currently plan to continue to invest in R&D and new products that we believe will further differentiate us in the marketplace and expect our investment in R&D to increase in absolute dollars in future quarters.

[0001633978-20-000008:mdna:74]
[same as prior period, unchanged from 0001633978-20-000003:mdna:66]

[0001633978-20-000008:mdna:75]
SG&A expense increased by $6.1 million, or 11.1%, during the three months ended March 28, 2020 compared to the three months ended March 30, 2019. The increase in SG&A expense was primarily due to the increase in payroll related expense of $2.8 million, stock-based compensation of $2.4 million, integration related costs of $3.7 million, offset by lower discretionary travel and trade shows of $2.0 million, primarily due to COVID-19 restrictions.

[0001633978-20-000008:mdna:76]
SG&A expense increased by $29.5 million, or 19.5%, during the nine months ended March 28, 2020 compared to the nine months ended March 30, 2019. The increase in SG&A expense was primarily due to the increase in amortization of intangibles of $14.2 million and integration related costs of $9.8 million as a result of Oclaro acquisition, as well as the increase in payroll related expense of $13.8 million, offset by lower discretionary travel and trade shows, primarily due to COVID-19 restrictions in the three months ended March 28, 2020.

[0001633978-20-000008:mdna:77]
From time to time, we expect to incur non-core expenses, such as mergers and acquisition-related expenses and litigation expenses, which will likely increase our SG&A expenses and potentially impact our profitability expectations in any particular quarter.

[0001633978-20-000008:mdna:78]
[same as prior period, unchanged from 0001633978-20-000003:mdna:70]

[0001633978-20-000008:mdna:79]
[same as prior period, unchanged from 0001633978-20-000003:mdna:71]

[0001633978-20-000008:mdna:80]
During the three and nine months ended March 28, 2020, we recorded $2.7 million and $4.9 million, respectively, in restructuring and related charges in our condensed consolidated statements of operations. The charges were mainly attributable to severance charges associated with the decision to move certain manufacturing activities from San Jose, California to our facility in Thailand.

[0001633978-20-000008:mdna:81]
During the three and nine months ended March 30, 2019, we recorded $21.1 million and $30.2 million, respectively, in restructuring and related charges in our condensed consolidated statements of operations, primarily attributable to severance and employee related benefits associated with the wind down of operations for Lithium Niobate modulators and Datacom modules resulting in $18.0 million of severance charges and $1.6 million of lease restructuring charges. During the three and nine months ended March 30, 2019, we also recorded restructuring charges primarily associated with acquisition related synergies. In addition, the nine month period charges included severance and employee related benefits associated with Oclaro’s executive severance and retention agreements. These retention agreements provided, under certain circumstances, for payments and benefits upon an involuntary termination of employment.

[0001633978-20-000008:mdna:82]
[same as prior period, unchanged from 0001633978-20-000003:mdna:74]

[0001633978-20-000008:mdna:83]
Impairment charges

[0001633978-20-000008:mdna:84]
In the third quarter of fiscal 2019, we announced our plan to discontinue the development of future Datacom transceiver modules which impacted the Milpitas and Shenzhen Datacom module teams. While we expect strong growth in Datacom volumes in the future, gross margins at the transceiver market level are lower due to extreme competition. Following the Oclaro acquisition, we have a differentiated leadership position across a range of photonic chips on which the Datacom, wireless, and access markets critically rely.

[0001633978-20-000008:mdna:85]
During the three and nine months ended March 28, 2020 and March 30, 2019, we recorded $2.5 million, $2.5 million, $30.7 million, and $30.7 million, respectively, in long-lived asset impairment charges in connection with the above plan.

[0001633978-20-000008:mdna:86]
[same as prior period, unchanged from 0001633978-20-000003:mdna:75]

[0001633978-20-000008:mdna:87]
For the three months ended March 28, 2020 and March 30, 2019, we recorded interest expense of $15.6 million and $11.3 million, respectively. The increase in interest expense during the three months ended March 28, 2020 as compared to the three months ended March 30, 2019 was mainly driven by the increase in amortization of the debt discount and contractual interest expense of $10.8 million due to the issuance of our 0.50% Convertible Notes due in 2026 (the “2026 Notes”), offset by the decrease in contractual interest expense on our term loan facility of $6.2 million, which was fully repaid in the second quarter of fiscal 2020.

[0001633978-20-000008:mdna:88]
For the nine months ended March 28, 2020 and March 30, 2019, we recorded interest expense of $45.3 million and $24.9 million, respectively. The increase in interest expense during the nine months ended March 28, 2020 as compared to the nine months ended March 30, 2019 was mainly driven by amortization of the debt discount and contractual interest expense incurred from our 2026 Notes, as well as the loss on early extinguishment of debt of $8.0 million, which represents the write-off of the issuance costs in conjunction with payback of our term loan facility in the second quarter of fiscal 2020.

[0001633978-20-000008:mdna:89]
[same as prior period, unchanged from 0001633978-20-000003:mdna:78]

[0001633978-20-000008:mdna:90]
[same as prior period, unchanged from 0001633978-20-000003:mdna:79]

[0001633978-20-000008:mdna:91]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| Foreign exchange gains (losses), net | $ | 0.7 |  |  | $ | (1.0 | ) |  | $ | (0.3 | ) |  | $ | (1.0 | ) |
| Interest income | 5.2 |  |  | 3.9 |  |  | 12.6 |  |  | 10.0 |  |
| Other income (expense), net | 15.8 |  |  | 2.3 |  |  | 15.6 |  |  | 2.7 |  |
| Total other income (expense), net | $ | 21.7 |  |  | $ | 5.2 |  |  | $ | 27.9 |  |  | $ | 11.7 |  |

[0001633978-20-000008:mdna:92]
For the three and nine months ended March 28, 2020, other income, net increased by $16.5 million and $16.2 million, respectively, as compared to the three and nine months ended March 30, 2019, mainly driven by a gain on the sale of Lithium Niobate modulators business of $13.8 million. The transaction was completed in the third quarter of fiscal year 2020.

[0001633978-20-000008:mdna:93]
[same as prior period, unchanged from 0001633978-20-000003:mdna:83]

[0001633978-20-000008:mdna:94]
We recorded $8.8 million of unrealized gain on Series A Preferred Stock derivative liability for the nine months ended March 30, 2019. On November 2, 2018, all 35,805 shares of our Series A Preferred Stock were converted to common stock with the outstanding balance of the embedded derivative liability reclassified to additional paid in capital. There will be no further adjustments to “unrealized gain (loss) on derivative liability” due to this conversion. For further discussion of our derivative liability, see “Note 11. Non-Controlling Interest Redeemable Convertible Preferred Stock and Derivative Liability” in the notes to condensed consolidated financial statements.

[0001633978-20-000008:mdna:95]
Provision for (Benefit from) Income Taxes

[0001633978-20-000008:mdna:96]
| (in millions) | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| Provision for (benefit from) income taxes | $ | 5.2 |  |  | $ | (8.2 | ) |  | $ | 19.6 |  |  | $ | (1.6 | ) |

[0001633978-20-000008:mdna:97]
We recorded a tax provision (benefit) of $5.2 million and $(8.2) million for the three months ended March 28, 2020 and March 30, 2019, respectively, and $19.6 million and $(1.6) million for the nine months ended March 28, 2020 and March 30, 2019, respectively. We recognized a discrete tax benefit of $4.1 million during the three months ended March 28, 2020 from the release of uncertain tax positions related to the fiscal 2016 U.S. federal income tax return as a result of the expiration of statute of limitations during the quarter. Our estimated effective tax rate for fiscal 2020 differs from the 21% U.S. statutory rate primarily due to the income tax benefit of the earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate as well as the U.S. federal R&D and foreign tax credits, partially offset by the income tax expense from non-deductible stock-based compensation and the tax effect of Global Intangible Low-Taxed Income (“GILTI”), Base Erosion and Anti-Abuse Tax (“BEAT”) and subpart F inclusion.

[0001633978-20-000008:mdna:98]
[same as prior period, unchanged from 0001633978-20-000003:mdna:88]

[0001633978-20-000008:mdna:99]
The following table summarizes our contractual obligations as of March 28, 2020, and the effect such obligations are expected to have on our liquidity and cash flow over the next five years (in millions):

[0001633978-20-000008:mdna:100]
|  | Payments due by period |
|  | Total |  | Less than 1 year |  | 1 - 3 years |  | 3 - 5 years |  | More than 5 years |
| Contractual Obligations |  |  |  |  |  |  |  |  |  |
| Asset retirement obligations | $ | 4.9 |  |  | $ | — |  |  | $ | 1.0 |  |  | $ | 1.8 |  |  | $ | 2.1 |  |
| Finance lease liabilities, including imputed interest | 4.0 |  |  | 3.9 |  |  | 0.1 |  |  | — |  |  | — |  |
| Operating lease liabilities, including imputed interest (1) | 80.6 |  |  | 13.5 |  |  | 24.0 |  |  | 16.5 |  |  | 26.6 |  |
| Pension plan contributions (2) | 0.5 |  |  | 0.5 |  |  | — |  |  | — |  |  | — |  |
| Purchase obligations (3) | 257.2 |  |  | 255.3 |  |  | 1.9 |  |  | — |  |  | — |  |
| Convertible notes - principal (4) | 1,500.0 |  |  | — |  |  | — |  |  | 450.0 |  |  | 1,050.0 |  |
| Convertible notes - interest (4) | 41.3 |  |  | 5.9 |  |  | 12.7 |  |  | 12.2 |  |  | 10.5 |  |
| Total | $ | 1,888.5 |  |  | $ | 279.1 |  |  | $ | 39.7 |  |  | $ | 480.5 |  |  | $ | 1,089.2 |  |

[0001633978-20-000008:mdna:101]
(1) The amounts of operating lease liabilities in the table above do not include any sublease income amounts nor do they include payments for short-term leases or variable lease payments. As of March 28, 2020, we expect to receive sublease income of approximately $5.9 million over the next three years.

[0001633978-20-000008:mdna:102]
(2) The amount in the preceding table represents planned contributions to our defined benefit plans. Although additional future contributions will be required, the amount and timing of these contributions will be affected by actuarial assumptions, the actual rate of returns on plan assets, the level of market interest rates, legislative changes, and the amount of voluntary contributions to the plan. Any contributions for the following fiscal year and later will depend on the value of the plan assets in the future and thus are uncertain. As such, we have not included any amounts beyond one year in the table above.

[0001633978-20-000008:mdna:103]
(3) Purchase obligations represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Refer to “Note 17. Commitments and Contingencies” in the notes to condensed consolidated financial statements.

[0001633978-20-000008:mdna:104]
(4) Includes principal and interest on our 0.25% Convertible Notes due in 2024 (the “2024 Notes” and together with the 2026 Notes, the “Notes”) through March 2024, and principal and interest on our 2026 Notes through December 2026. We have the right to redeem the 2024 Notes and the 2026 Notes in whole or in part at any time on or after March 15, 2024 and on or after December 15, 2026, respectively. Refer to “Note 12. Debt” in the notes to condensed consolidated financial statements.

[0001633978-20-000008:mdna:105]
As of March 28, 2020, our other non-current liabilities also include $18.1 million of unrecognized tax benefit for uncertain tax positions. We are unable to reliably estimate the timing of future payments related to uncertain tax positions and therefore have excluded them from the preceding table.

[0001633978-20-000008:mdna:106]
[same as prior period, unchanged from 0001633978-20-000003:mdna:98]

[0001633978-20-000008:mdna:107]
[same as prior period, unchanged from 0001633978-20-000003:mdna:99]

[0001633978-20-000008:mdna:108]
[same as prior period, unchanged from 0001633978-20-000003:mdna:100]

[0001633978-20-000008:mdna:109]
[same as prior period, unchanged from 0001633978-20-000003:mdna:101]

[0001633978-20-000008:mdna:110]
As of March 28, 2020 and June 29, 2019, our cash and cash equivalents of $688.3 million and $432.6 million, respectively, were largely held in the United States. The total amount of cash outside the United States as of March 28, 2020 was $84.7 million, which was primarily held by entities incorporated in Japan, the United Kingdom, the British Virgin Islands, Hong Kong, and Thailand. Although the cash currently held in the United States as well as the cash generated in the United States from future operations is expected to cover our normal operating requirements, a substantial amount of additional cash could be required for other purposes, such as capital expenditures to support our business and growth, including costs associated with increasing internal manufacturing capabilities, particularly in our Thailand facility, strategic transactions and partnerships, and future acquisitions. Our intent is to indefinitely reinvest funds held outside the United States, except for the funds held in the Cayman Islands, Japan and Hong Kong, and our current plans do not demonstrate a need to repatriate them to fund our domestic operations. However, if in the future, we encounter a significant need for liquidity domestically or at a particular location that we cannot fulfill through borrowings, equity offerings, or other internal or external sources, or the cost to bring back the money is insignificant from a tax perspective, we may determine that cash repatriations are necessary or desirable. Repatriation could result in additional material taxes. These factors may cause us to have an overall tax rate higher than other companies or higher than our tax rates have been in the past. If conditions warrant, we may seek to obtain additional financing through debt or equity sources. To the extent we issue additional shares, our existing stockholders may be diluted. However, any such financing may not be available on terms favorable to us, or may not be available at all.

[0001633978-20-000008:mdna:111]
As of March 28, 2020, our condensed consolidated balance of cash, cash equivalents, and restricted cash increased by $256.2 million, to $688.8 million from $432.6 million as of June 29, 2019. The increase in cash, cash equivalents, and restricted cash was mainly due to cash provided by operating activities of $401.6 million and cash provided by financing activities of $332.5 million, offset by cash used in investing activities of $477.9 million during the nine months ended March 28, 2020.

[0001633978-20-000008:mdna:112]
As of March 30, 2019, our consolidated balance of cash and cash equivalents, including cash classified within assets held-for-sale, decreased by $39.0 million, to $358.3 million from $397.3 million as of June 30, 2018. The decrease in cash and cash equivalents was mainly due to cash used in investing activities of $725.3 million, principally related to cash used to acquire Oclaro; partially offset by cash provided by financing activities of $484.1 million, primarily related to $490.8 million in proceeds from a term loan, net of debt issuance costs, used to fund the Oclaro acquisition, and cash provided by operating activities of $202.4 million during the nine months ended March 30, 2019.

[0001633978-20-000008:mdna:113]
[same as prior period, unchanged from 0001633978-20-000003:mdna:105]

[0001633978-20-000008:mdna:114]
Cash provided by operating activities was $401.6 million during the nine months ended March 28, 2020. Our net income was $140.1 million for the nine months ended March 28, 2020. Cash provided by operating activities was generated primarily from $232.8 million of non-cash items (such as depreciation, stock-based compensation, amortization of intangibles, amortization

[0001633978-20-000008:mdna:115]
of debt discount and debt issuance costs on our term loans and convertible notes, and other non-cash charges), and $28.7 million of changes in our operating assets and liabilities. Changes in our operating assets and liabilities related primarily to a decrease in inventories of $48.3 million offset by an increase in accounts receivable of $23.8 million.

[0001633978-20-000008:mdna:116]
Cash provided by operating activities was $202.4 million during the nine months ended March 30, 2019. Our net loss was $10.6 million for the nine months ended March 30, 2019. Cash provided by operating activities was generated primarily from $210.0 million of non-cash items (such as depreciation, stock-based compensation, unrealized (gain) loss on derivative liability, amortization of intangibles, amortization of discount on the 2024 Notes, amortization of the debt issuance costs on the term loan, amortization of fair value adjustment in connection with the acquisition of Oclaro, net amortization of discounts and premium on investments, and impairment charges and others), and $3.0 million of changes in our operating assets and liabilities.

[0001633978-20-000008:mdna:117]
[same as prior period, unchanged from 0001633978-20-000003:mdna:109]

[0001633978-20-000008:mdna:118]
Cash used in investing activities of $477.9 million during the nine months ended March 28, 2020 was primarily attributable to purchases of short-term investments, net of sales and maturities of $427.9 million, capital expenditures of $64.9 million, and payment for asset acquisition of $4.0 million, offset by proceeds from sale of product lines of $18.9 million.

[0001633978-20-000008:mdna:119]
Cash used in investing activities of $725.3 million during the nine months ended March 30, 2019, was primarily attributable to $619.8 million in cash payments to acquire all outstanding shares of common stock of Oclaro, net of cash received through the acquisition of Oclaro. In addition we had capital expenditures of $80.5 million, payment for asset acquisition of $1.3 million, and purchase of short-term investments, net of sales of $23.7 million.

[0001633978-20-000008:mdna:120]
[same as prior period, unchanged from 0001633978-20-000003:mdna:112]

[0001633978-20-000008:mdna:121]
Cash provided by financing activities of $332.5 million during the nine months ended March 28, 2020 resulted primarily from the proceeds of the issuance of the 2026 Notes of $1,042.4 million, net of issuance costs, offset by the repurchase of shares of our common stock of $200.0 million and repayment of our term loan facility of $497.5 million.

[0001633978-20-000008:mdna:122]
Cash provided by financing activities of $484.1 million during the nine months ended March 30, 2019, primarily resulted from $490.8 million of proceeds from a term loan, net of debt issuance costs, used to partially finance the Oclaro acquisition, $4.7 million from the issuance of common stock under the employee stock plan; partially offset by the repayment of capital lease obligations of $6.1 million, tax payments related to restricted stock of $2.4 million, a payment of an acquisition related holdback of $1.0 million, and dividend payments on our Series A Preferred Stock of $0.7 million.

[0001633978-20-000008:mdna:123]
[same as prior period, unchanged from 0001633978-20-000003:mdna:115]

[0001633978-20-000008:mdna:124]
We believe that our cash and cash equivalents as of March 28, 2020 and cash flows from our operating activities will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months. However, if market conditions are favorable, we may evaluate alternatives to opportunistically pursue additional financing.

[0001633978-20-000008:mdna:125]
[same as prior period, unchanged from 0001633978-20-000003:mdna:117]

[0001633978-20-000008:mdna:126]
| • | global economic conditions which affect demand for our products and services and impact the financial stability of our suppliers and customers, including the impact of COVID-19; |

[0001633978-20-000008:mdna:127]
[same as prior period, unchanged from 0001633978-20-000003:mdna:119]

[0001633978-20-000008:mdna:128]
[same as prior period, unchanged from 0001633978-20-000003:mdna:120]

[0001633978-20-000008:mdna:129]
[same as prior period, unchanged from 0001633978-20-000003:mdna:121]

[0001633978-20-000008:mdna:130]
[same as prior period, unchanged from 0001633978-20-000003:mdna:122]

[0001633978-20-000008:mdna:131]
[same as prior period, unchanged from 0001633978-20-000003:mdna:123]

[0001633978-20-000008:mdna:132]
[same as prior period, unchanged from 0001633978-20-000003:mdna:124]

[0001633978-20-000008:mdna:133]
[same as prior period, unchanged from 0001633978-20-000003:mdna:125]

[0001633978-20-000008:mdna:134]
[same as prior period, unchanged from 0001633978-20-000003:mdna:126]

[0001633978-20-000008:mdna:135]
[same as prior period, unchanged from 0001633978-20-000003:mdna:127]

[0001633978-20-000008:mdna:136]
[same as prior period, unchanged from 0001633978-20-000003:mdna:128]

[0001633978-20-000008:mdna:137]
[same as prior period, unchanged from 0001633978-20-000003:mdna:129]

[0001633978-20-000008:mdna:138]
[same as prior period, unchanged from 0001633978-20-000003:mdna:130]

[0001633978-20-000008:mdna:139]
52
