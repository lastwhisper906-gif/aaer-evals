# LITE 8-K — 0001628280-20-006358 filed 2020-05-05

## item codes, every 8-K on or before 2020-05-05

- 2020-05-05 0001628280-20-006358 — 2.02, 9.01
- 2020-02-04 0001633978-20-000002 — 2.02, 9.01
- 2019-12-12 0001193125-19-312875 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2019-12-04 0001633978-19-000075 — 8.01
- 2019-11-20 0001633978-19-000074 — 5.07
- 2019-10-31 0001633978-19-000070 — 2.02, 9.01
- 2019-08-08 0001633978-19-000068 — 2.02, 9.01
- 2019-05-08 0001633978-19-000031 — 1.01
- 2019-05-07 0001633978-19-000029 — 2.02, 9.01
- 2019-02-15 0001633978-19-000005 — 9.01 — amendment of 0001193125-18-346211
- 2019-02-08 0001193125-19-031591 — 5.02, 9.01
- 2019-02-05 0001633978-19-000001 — 2.02, 9.01
- 2018-12-10 0001193125-18-346211 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-12-06 0001633978-18-000150 — 8.01
- 2018-11-14 0001633978-18-000139 — 5.07
- 2018-11-13 0001633978-18-000136 — 3.02
- 2018-11-13 0001633978-18-000132 — 7.01, 9.01
- 2018-11-01 0001628280-18-013238 — 2.02, 9.01
- 2018-08-08 0001633978-18-000056 — 2.02, 9.01
- 2018-06-08 0001193125-18-188241 — 5.02, 9.01
- 2018-05-02 0001633978-18-000029 — 2.02, 9.01
- 2018-03-12 0001193125-18-078154 — 1.01, 2.01, 8.01, 9.01
- 2018-02-06 0001628280-18-001082 — 2.02, 9.01
- 2017-11-08 0001633978-17-000133 — 5.02, 9.01
- 2017-11-07 0001633978-17-000131 — 5.07
- 2017-11-01 0001633978-17-000117 — 2.02, 9.01
- 2017-08-09 0001633978-17-000058 — 2.02, 9.01
- 2017-05-04 0001633978-17-000035 — 2.02, 9.01
- 2017-03-08 0001193125-17-074740 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2017-03-02 0001193125-17-066769 — 8.01, 9.01
- 2017-02-07 0001633978-17-000005 — 2.02, 9.01
- 2017-01-03 0001628280-17-000018 — 4.01, 9.01
- 2016-11-09 0001628280-16-021143 — 5.02, 5.07, 9.01
- 2016-10-27 0001628280-16-020382 — 2.02, 9.01
- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2020-05-05

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001628280-20-006358:8k_2_02:1]
EX-99.1
2
liteex991q3fy20.htm
EXHIBIT 99.1

[0001628280-20-006358:8k_2_02:2]
Exhibit

[0001628280-20-006358:8k_2_02:3]
NEWS RELEASE

[0001628280-20-006358:8k_2_02:4]
LUMENTUM ANNOUNCES FISCAL THIRD QUARTER 2020 FINANCIAL RESULTS

[0001628280-20-006358:8k_2_02:5]
| • | Net revenue of $402.8 million |

[0001628280-20-006358:8k_2_02:6]
| • | GAAP operating margin of 10.6%; Non-GAAP operating margin of 25.0% |

[0001628280-20-006358:8k_2_02:7]
| • | GAAP diluted net income per share of $0.56; Non-GAAP diluted net income per share of $1.26 |

[0001628280-20-006358:8k_2_02:8]
| • | COVID-19 revenue impact was more than $10 million higher than in prior guidance due to the spread beyond China late in the third quarter |

[0001628280-20-006358:8k_2_02:9]
San Jose, Calif., May 5, 2020 – Lumentum Holdings Inc. (“Lumentum” or the “Company”) today reported results for its fiscal third quarter of 2020 ended March 28, 2020.

[0001628280-20-006358:8k_2_02:10]
Net revenue for the fiscal third quarter of 2020 was $402.8 million, with GAAP net income of $43.4 million, or $0.56 per diluted share. Net revenue for the fiscal second quarter of 2020 was $457.8 million, with GAAP net income of $49.1 million, or $0.63 per diluted share. Net revenue for the fiscal third quarter of 2019 was $432.9 million, with GAAP net loss of $(74.3) million, or $(0.98) per diluted share.

[0001628280-20-006358:8k_2_02:11]
Non-GAAP net income for the fiscal third quarter of 2020 was $98.0 million, or $1.26 per diluted share. Non-GAAP net income for the fiscal second quarter of 2020 was $119.4 million, or $1.53 per diluted share. Non-GAAP net income for the fiscal third quarter of 2019 was $70.9 million, or $0.92 per diluted share.

[0001628280-20-006358:8k_2_02:12]
The Company held $1,451.4 million in total cash and short-term investments at the end of the fiscal third quarter of 2020, up $135.8 million compared to the fiscal second quarter of 2020.

[0001628280-20-006358:8k_2_02:13]
“While the COVID-19 pandemic is currently impacting our ability to satisfy strong customer demand for our communications products, we believe the world’s experience with COVID-19 will accelerate the shift to increasingly digital and virtual approaches to work, education, health care, entertainment, social interaction, and commerce, creating even more opportunity for Lumentum over the long-term”, said Alan Lowe, President and CEO. “Our strategy of technology and product leadership in close alignment with market leading customers is even more apt in these times. The market and technology leadership positions and financial strength we have attained to date, with this strategy, position us well for the future.”

[0001628280-20-006358:8k_2_02:14]
Financial Overview – Fiscal Third Quarter Ended March 28, 2020

[0001628280-20-006358:8k_2_02:15]
|  | GAAP Results ($ in millions) |
|  | Q3 |  | Q2 |  | Q3 |  | Change |
|  | FY 2020 |  | FY 2020 |  | FY 2019 |  | Q/Q |  | Y/Y |
| Net revenue | $402.8 |  | $457.8 |  | $432.9 |  | (12.0)% |  | (7.0)% |
| Gross margin | 39.2% |  | 41.3% |  | 20.4% |  | (210)bps |  | 1,880bps |
| Operating margin (loss) | 10.6% |  | 16.3% |  | (17.6)% |  | (570)bps |  | 2,820bps |
|  | Non-GAAP Results ($ in millions) |
|  | Q3 |  | Q2 |  | Q3 |  | Change |
|  | FY 2020 |  | FY 2020 |  | FY 2019 |  | Q/Q |  | Y/Y |
| Net revenue | $402.8 |  | $457.8 |  | $432.9 |  | (12.0)% |  | (7.0)% |
| Gross margin | 45.5% |  | 47.4% |  | 39.0% |  | (190)bps |  | 650bps |
| Operating margin | 25.0% |  | 28.8% |  | 17.8% |  | (380)bps |  | 720bps |

[0001628280-20-006358:8k_2_02:16]
|  | Net Revenue by Segment ($ in millions) |
|  | Q3 |  | % of |  | Q2 |  | Q3 |  | Change |
|  | FY 2020 |  | Net Revenue |  | FY 2020 |  | FY 2019 |  | Q/Q |  | Y/Y |
| Optical Communications | $ | 359.3 |  |  | 89.2 | % |  | $ | 409.4 |  |  | $ | 377.9 |  |  | (12.2 | )% |  | (4.9 | )% |
| Lasers | 43.5 |  |  | 10.8 | % |  | 48.4 |  |  | 55.0 |  |  | (10.1 | )% |  | (20.9 | )% |
| Total | $ | 402.8 |  |  | 100.0 | % |  | $ | 457.8 |  |  | $ | 432.9 |  |  | (12.0 | )% |  | (7.0 | )% |

[0001628280-20-006358:8k_2_02:17]
The tables above provide comparisons of quarterly results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled “Use of Non-GAAP Financial Measures.”

[0001628280-20-006358:8k_2_02:18]
Effective June 30, 2019, we adopted Topic 842, using the modified retrospective transition approach. We applied the new guidance to all leases existing as of the date of adoption. Our reported results for the nine months ended March 28, 2020 reflect the application of Topic 842, while fiscal 2019 amounts have not been adjusted and continue to be reported in accordance with our historical accounting under Topic 840.

[0001628280-20-006358:8k_2_02:19]
Third quarter results were impacted by the COVID-19 pandemic due to limitations on our ability to supply products to our customers. As the outbreak spread outside of China late in the quarter, we experienced supply disruptions in excess of our prior assumptions. The supply of certain products produced in Malaysia was significantly disrupted as the Malaysian government issued a movement control order on March 16, 2020. As we provide an essential service under the order, we have been able to slowly increase production in Malaysia from zero when the movement control order was issued and expect to reach near 100% production levels in the coming weeks. The third quarter was also impacted by limitations in component supply from third parties. We have implemented measures to protect the health and well-being of our employees at our sites in other regions, including work from home programs for nearly all of our non-manufacturing employees around the world, social distancing protocols, and enhanced use of personal protective equipment for manufacturing and other employees performing essential operations for our essential business functions.

[0001628280-20-006358:8k_2_02:20]
Business Outlook

[0001628280-20-006358:8k_2_02:21]
The projections we are providing today incorporate our expectations considering the significant impact of the COVID-19 pandemic on our ability to supply our products and market demand in the fiscal fourth quarter. This includes on-going component supply challenges and limited production in Malaysia in the first half of the quarter. We are providing a wider than normal revenue range to incorporate uncertainty around our assumptions on the impact of COVID-19.

[0001628280-20-006358:8k_2_02:22]
Lumentum expects the following for the fiscal fourth quarter 2020:

[0001628280-20-006358:8k_2_02:23]
| • | Net revenue in the range of $325 million to $365 million |

[0001628280-20-006358:8k_2_02:24]
| • | Non-GAAP operating margin of 18% to 21% |

[0001628280-20-006358:8k_2_02:25]
| • | Non-GAAP diluted earnings per share of $0.70 to $0.90 |

[0001628280-20-006358:8k_2_02:26]
| • | Estimated fourth quarter impact from COVID-19 is a reduction in revenue of more than $90 million and a reduction in non-GAAP diluted earnings per share of more than $0.50 |

[0001628280-20-006358:8k_2_02:27]
We have not provided reconciliations from GAAP to non-GAAP measures for our outlook. A large portion of non-GAAP adjustments, such as restructuring charges, stock-based compensation, acquisition-related costs, non-cash income tax expense and credits, amortization of fair value adjustments, integration related costs, impairment charges, inventory write down due to plans to exit certain product lines and other costs and contingencies unrelated to current and future operations are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future.

[0001628280-20-006358:8k_2_02:28]
Conference Call

[0001628280-20-006358:8k_2_02:29]
Lumentum will host a conference call on May 5, 2020, at 5:30 am PT/8:30 am ET. A live webcast of the call and the replay will be available on the Lumentum website at http://investor.lumentum.com through May 12, 2020, at 11:59 pm ET. To listen to the live conference call, dial (833) 287-7900 or (647) 689-4464 and reference the passcode 6697949. A replay of the conference call will be available through May 12, 2020. To access the replay, dial (800) 585-8367 or (416) 621-4642. The passcode for the replay is 6697949. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the “Events and Presentations” section concurrently with this earnings press release. Lumentum has used, and intends to continue to use, its Investor Relations website as means of disclosing material nonpublic information and

[0001628280-20-006358:8k_2_02:30]
for complying with its disclosure obligations under Regulation FD. This press release is being furnished as an exhibit to a Current Report on Form 8-K filed with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001628280-20-006358:8k_2_02:31]
About Lumentum

[0001628280-20-006358:8k_2_02:32]
Lumentum (NASDAQ: LITE) is a market-leading designer and manufacturer of innovative optical and photonic products enabling optical networking and laser applications worldwide. Lumentum’s optical components and subsystems are part of virtually every type of telecom, enterprise, and data center network. Lumentum’s lasers enable advanced manufacturing techniques and diverse applications including next-generation 3D sensing capabilities. Lumentum is headquartered in San Jose, California with R&D, manufacturing, and sales offices worldwide. For more information, visit www.lumentum.com.

[0001628280-20-006358:8k_2_02:33]
Forward-Looking Statements

[0001628280-20-006358:8k_2_02:34]
Contact Information

[0001628280-20-006358:8k_2_02:35]
Investors:            Jim Fanucchi, 408-404-5400; investor.relations@lumentum.com

[0001628280-20-006358:8k_2_02:36]
Media:         Sean Ogarrio, 408-546-5405; media@lumentum.com

[0001628280-20-006358:8k_2_02:37]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001628280-20-006358:8k_2_02:38]
LUMENTUM HOLDINGS INC.

[0001628280-20-006358:8k_2_02:39]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001628280-20-006358:8k_2_02:40]
(in millions, except per share data)

[0001628280-20-006358:8k_2_02:41]
(unaudited)

[0001628280-20-006358:8k_2_02:42]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| Net revenue | $ | 402.8 |  |  | $ | 432.9 |  |  | $ | 1,310.5 |  |  | $ | 1,160.7 |  |
| Cost of sales | 231.2 |  |  | 316.5 |  |  | 757.2 |  |  | 788.3 |  |
| Amortization of acquired developed intangibles | 13.9 |  |  | 28.1 |  |  | 38.8 |  |  | 33.3 |  |
| Gross profit | 157.7 |  |  | 88.3 |  |  | 514.5 |  |  | 339.1 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 48.7 |  |  | 57.7 |  |  | 149.6 |  |  | 135.1 |  |
| Selling, general and administrative | 61.3 |  |  | 55.2 |  |  | 180.4 |  |  | 150.9 |  |
| Restructuring and related charges | 2.7 |  |  | 21.1 |  |  | 4.9 |  |  | 30.2 |  |
| Impairment charges | 2.5 |  |  | 30.7 |  |  | 2.5 |  |  | 30.7 |  |
| Total operating expenses | 115.2 |  |  | 164.7 |  |  | 337.4 |  |  | 346.9 |  |
| Income (loss) from operations | 42.5 |  |  | (76.4 | ) |  | 177.1 |  |  | (7.8 | ) |
| Unrealized gain on derivative liability | — |  |  | — |  |  | — |  |  | 8.8 |  |
| Interest expense | (15.6 | ) |  | (11.3 | ) |  | (45.3 | ) |  | (24.9 | ) |
| Other income (expense), net | 21.7 |  |  | 5.2 |  |  | 27.9 |  |  | 11.7 |  |
| Income (loss) before income taxes | 48.6 |  |  | (82.5 | ) |  | 159.7 |  |  | (12.2 | ) |
| Provision for (benefit from) income taxes | 5.2 |  |  | (8.2 | ) |  | 19.6 |  |  | (1.6 | ) |
| Net income (loss) | $ | 43.4 |  |  | $ | (74.3 | ) |  | $ | 140.1 |  |  | $ | (10.6 | ) |
| Items reconciling net income to net income attributable to common stockholders: |  |  |  |  |  |  |  |
| Less: Cumulative dividends on Series A Preferred Stock | — |  |  | — |  |  | — |  |  | (0.3 | ) |
| Less: Earnings allocated to Series A Preferred Stock | — |  |  | — |  |  | — |  |  | (1.2 | ) |
| Net income (loss) attributable to common stockholders - Basic | $ | 43.4 |  |  | $ | (74.3 | ) |  | $ | 140.1 |  |  | $ | (12.1 | ) |
| Net income (loss) attributable to common stockholders - Diluted | $ | 43.4 |  |  | $ | (74.3 | ) |  | $ | 140.1 |  |  | $ | (12.1 | ) |
| Net income (loss) per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | $ | 0.58 |  |  | $ | (0.98 | ) |  | $ | 1.84 |  |  | $ | (0.18 | ) |
| Diluted | $ | 0.56 |  |  | $ | (0.98 | ) |  | $ | 1.80 |  |  | $ | (0.18 | ) |
| Shares used to compute net income (loss) per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | 74.8 |  |  | 76.2 |  |  | 76.2 |  |  | 68.7 |  |
| Diluted | 77.5 |  |  | 76.2 |  |  | 77.7 |  |  | 68.7 |  |

[0001628280-20-006358:8k_2_02:43]
LUMENTUM HOLDINGS INC.

[0001628280-20-006358:8k_2_02:44]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-20-006358:8k_2_02:45]
(in millions, except share and per share data)

[0001628280-20-006358:8k_2_02:46]
|  | March 28, 2020 |  | June 29, 2019 |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |  |
| Cash and cash equivalents | $ | 688.3 |  |  | $ | 432.6 |  |
| Short-term investments | 763.1 |  |  | 335.9 |  |
| Accounts receivable, net | 261.8 |  |  | 238.0 |  |
| Inventories | 172.7 |  |  | 228.8 |  |
| Prepayments and other current assets | 77.1 |  |  | 97.5 |  |
| Total current assets | 1,963.0 |  |  | 1,332.8 |  |
| Property, plant and equipment, net | 410.1 |  |  | 433.3 |  |
| Operating lease right-of-use assets, net | 81.7 |  |  | — |  |
| Goodwill | 368.9 |  |  | 368.9 |  |
| Other intangible assets, net | 338.0 |  |  | 395.4 |  |
| Deferred income taxes | 102.7 |  |  | 169.6 |  |
| Other non-current assets | 4.3 |  |  | 16.6 |  |
| Total assets | $ | 3,268.7 |  |  | $ | 2,716.6 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 144.6 |  |  | $ | 160.8 |  |
| Accrued payroll and related expenses | 50.9 |  |  | 42.3 |  |
| Accrued expenses | 32.9 |  |  | 46.7 |  |
| Term loan, current | — |  |  | 5.0 |  |
| Operating lease liabilities, current | 11.5 |  |  | — |  |
| Other current liabilities | 46.8 |  |  | 39.2 |  |
| Total current liabilities | 286.7 |  |  | 294.0 |  |
| Convertible notes | 1,106.0 |  |  | 351.9 |  |
| Term loan, non-current | — |  |  | 484.0 |  |
| Operating lease liabilities, non-current | 59.1 |  |  | — |  |
| Deferred tax liability | 49.0 |  |  | 55.9 |  |
| Other non-current liabilities | 33.7 |  |  | 33.7 |  |
| Total liabilities | 1,534.5 |  |  | 1,219.5 |  |
| Commitments and contingencies |  |  |  |
| Stockholders’ equity: |  |  |  |
| Common stock, $0.001 par value, 990,000,000 authorized shares, 74,874,176 and 76,653,478 shares issued and outstanding as of March 28, 2020 and June 29, 2019, respectively | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital | 1,659.1 |  |  | 1,360.8 |  |
| Retained earnings | 69.2 |  |  | 129.1 |  |
| Accumulated other comprehensive income | 5.8 |  |  | 7.1 |  |
| Total stockholders’ equity | 1,734.2 |  |  | 1,497.1 |  |
| Total liabilities and stockholders’ equity | $ | 3,268.7 |  |  | $ | 2,716.6 |  |

[0001628280-20-006358:8k_2_02:47]
Use of Non-GAAP Financial Measures

[0001628280-20-006358:8k_2_02:48]
In this press release, Lumentum provides investors with gross margin, gross profit, research and development expense, selling, general and administrative expense, operating margin, operating income, interest and other income (expense), net, income before income taxes and certain expenses, provision for taxes, net income, and net income per share on a non-GAAP basis as well as the non-GAAP measure of Adjusted EBITDA. Lumentum believes this non-GAAP financial information provides additional insight into the Company’s on-going business operations and results, as well as cash generation, and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons. Specifically, the Company believes that providing this information allows investors to better understand the Company’s cash flows and, importantly, to evaluate the efficacy of the methodology and information used by management to evaluate and measure such cash flows. However, these measures may be different from non-GAAP measures used by other companies, limiting their usefulness for comparison purposes. The non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP. Investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future. Further, these non-GAAP financial measures may not be comparable to similarly titled measurements reported by other companies.

[0001628280-20-006358:8k_2_02:49]
Non-GAAP gross margin, non-GAAP gross profit, non-GAAP expenses, non-GAAP operating margin, non-GAAP operating income, non-GAAP income before income taxes, non-GAAP net income, and non-GAAP net income per share exclude (i) stock-based compensation, (ii) inventory write-downs and fixed asset impairment due to cancelled programs, plans to exit certain lines of business and other costs and contingencies unrelated to current and future operations, (iii) acquisition related costs, (iv) integration related costs, (v) amortization of acquired intangibles, (vi) amortization of fair value adjustments, (vii) restructuring and related charges, (viii) non-cash interest expense, (ix) foreign exchange (gains) losses, net, (x) impairment charges, (xi) transferring product lines to Thailand, (xii) excess and obsolete inventory charges driven by the decline in demand from Huawei, (xiii) expenses related to COVID-19 outbreak, and (xiv) non-cash income tax provision impacts. The presentation of these and other similar items in Lumentum’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001628280-20-006358:8k_2_02:50]
A quantitative reconciliation between GAAP and non-GAAP financial data with respect to historical periods is included in the supplemental financial table attached to this press release.

[0001628280-20-006358:8k_2_02:51]
LUMENTUM HOLDINGS INC.

[0001628280-20-006358:8k_2_02:52]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001628280-20-006358:8k_2_02:53]
(in millions, except per share data)

[0001628280-20-006358:8k_2_02:54]
(unaudited)

[0001628280-20-006358:8k_2_02:55]
|  | Three Months Ended |  | Nine Months Ended |  |
|  | March 28, 2020 |  | December 28, 2019 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |  |
| Gross profit on GAAP basis | $ | 157.7 |  |  | $ | 189.1 |  |  | $ | 88.3 |  |  | $ | 514.5 |  |  | $ | 339.1 |  |  |
| Stock-based compensation | 4.3 |  |  | 4.1 |  |  | 3.2 |  |  | 12.6 |  |  | 11.7 |  |  |
| Inventory and fixed asset write down due to product lines exit (1) | 2.3 |  |  | 2.6 |  |  | 19.4 |  |  | 6.0 |  |  | 19.4 |  |  |
| Integration related costs | (0.3 | ) |  | — |  |  | 2.8 |  |  | 3.1 |  |  | 2.8 |  |  |
| Amortization of acquired intangibles | 13.9 |  |  | 12.4 |  |  | 28.1 |  |  | 38.8 |  |  | 33.3 |  |  |
| Amortization of fair value adjustments (2) | 1.5 |  |  | 2.1 |  |  | 14.5 |  |  | 5.8 |  |  | 15.8 |  |  |
| Other charges (3) | 4.0 |  |  | 6.5 |  |  | 12.5 |  |  | 25.5 |  |  | 39.0 |  |  |
| Gross profit on non-GAAP basis | $ | 183.4 |  |  | $ | 216.8 |  |  | $ | 168.8 |  |  | $ | 606.3 |  |  | $ | 461.1 |  |  |
| Gross margin on non-GAAP basis | 45.5 | % |  | 47.4 | % |  | 39.0 | % |  | 46.3 | % |  | 39.7 | % |  |
| Research and development on GAAP basis | $ | 48.7 |  |  | $ | 51.0 |  |  | $ | 57.7 |  |  | $ | 149.6 |  |  | $ | 135.1 |  |  |
| Stock-based compensation | (4.2 | ) |  | (4.1 | ) |  | (4.5 | ) |  | (12.1 | ) |  | (10.7 | ) |  |
| Other charges | (0.2 | ) |  | (0.1 | ) |  | (0.4 | ) |  | (0.1 | ) |  | (0.7 | ) |  |
| Research and development on non-GAAP basis | $ | 44.3 |  |  | $ | 46.8 |  |  | $ | 52.8 |  |  | $ | 137.4 |  |  | $ | 123.7 |  |  |
| Selling, general and administrative on GAAP basis | $ | 61.3 |  |  | $ | 62.4 |  |  | $ | 55.2 |  |  | $ | 180.4 |  |  | $ | 150.9 |  |  |
| Stock-based compensation | (10.7 | ) |  | (12.0 | ) |  | (8.3 | ) |  | (31.4 | ) |  | (34.1 | ) |  |
| Acquisition related costs | — |  |  | — |  |  | (2.2 | ) |  | — |  |  | (15.3 | ) |  |
| Integration related costs | (5.0 | ) |  | (2.9 | ) |  | (1.3 | ) |  | (11.1 | ) |  | (1.3 | ) |  |
| Amortization of acquired intangibles | (6.1 | ) |  | (6.2 | ) |  | (3.6 | ) |  | (18.6 | ) |  | (4.4 | ) |  |
| Other charges | (1.1 | ) |  | (3.3 | ) |  | (0.8 | ) |  | (5.8 | ) |  | (2.3 | ) |  |
| Selling, general and administrative on non-GAAP basis | $ | 38.4 |  |  | $ | 38.0 |  |  | $ | 39.0 |  |  | $ | 113.5 |  |  | $ | 93.5 |  |  |
| Income from operations on GAAP basis | $ | 42.5 |  |  | $ | 74.8 |  |  | $ | (76.4 | ) |  | $ | 177.1 |  |  | $ | (7.8 | ) |  |
| Stock-based compensation | 19.2 |  |  | 20.2 |  |  | 16.0 |  |  | 56.1 |  |  | 56.5 |  |  |
| Inventory and fixed asset write down due to product lines exit (1) | 2.3 |  |  | 2.6 |  |  | 19.4 |  |  | 6.0 |  |  | 19.4 |  |  |
| Acquisition related costs | — |  |  | — |  |  | 2.2 |  |  | — |  |  | 15.3 |  |  |
| Integration related costs | 4.7 |  |  | 2.9 |  |  | 4.1 |  |  | 14.2 |  |  | 4.1 |  |  |
| Amortization of acquired intangibles | 20.0 |  |  | 18.6 |  |  | 31.7 |  |  | 57.4 |  |  | 37.7 |  |  |
| Amortization of fair value adjustments (2) | 1.5 |  |  | 2.1 |  |  | 14.5 |  |  | 5.8 |  |  | 15.8 |  |  |
| Restructuring and related charges | 2.7 |  |  | 0.9 |  |  | 21.1 |  |  | 4.9 |  |  | 30.2 |  |  |
| Impairment charges (4) | 2.5 |  |  | — |  |  | 30.7 |  |  | 2.5 |  |  | 30.7 |  |  |
| Other charges | 5.3 |  |  | 9.9 |  |  | 13.7 |  |  | 31.4 |  |  | 42.0 |  |  |
| Income from operations on non-GAAP basis | $ | 100.7 |  |  | $ | 132.0 |  |  | $ | 77.0 |  |  | $ | 355.4 |  |  | $ | 243.9 |  |  |
| Operating margin on non-GAAP basis | 25.0 | % |  | 28.8 | % |  | 17.8 | % |  | 27.1 | % |  | 21.0 | % |  |

[0001628280-20-006358:8k_2_02:56]
| Interest and other income (expense), net on GAAP basis | $ | 6.1 |  |  | $ | (17.1 | ) |  | $ | (6.1 | ) |  | $ | (17.4 | ) |  | $ | (13.2 | ) |  |
| Other interest and (income) expense adjustments | (2.0 | ) |  | — |  |  | (2.5 | ) |  | (2.0 | ) |  | (0.5 | ) |  |
| Gain on sale of product lines | (13.8 | ) |  | — |  |  | — |  |  | (13.8 | ) |  | — |  |  |
| Foreign exchange (gains) losses, net (5) | (0.7 | ) |  | 2.1 |  |  | 1.0 |  |  | 0.3 |  |  | 1.0 |  |  |
| Non-cash interest expense on convertible notes and term loan | 14.0 |  |  | 14.4 |  |  | 4.8 |  |  | 33.3 |  |  | 13.6 |  |  |
| Interest and other income (expense), net on non-GAAP basis | $ | 3.6 |  |  | $ | (0.6 | ) |  | $ | (2.8 | ) |  | $ | 0.4 |  |  | $ | 0.9 |  |  |
| Income before income taxes on GAAP basis | $ | 48.6 |  |  | $ | 57.7 |  |  | $ | (82.5 | ) |  | $ | 159.7 |  |  | $ | (12.2 | ) |  |
| Stock-based compensation | 19.2 |  |  | 20.2 |  |  | 16.0 |  |  | 56.1 |  |  | 56.5 |  |  |
| Inventory and fixed asset write down due to product lines exit (1) | 2.3 |  |  | 2.6 |  |  | 19.4 |  |  | 6.0 |  |  | 19.4 |  |  |
| Acquisition related costs | — |  |  | — |  |  | 2.2 |  |  | — |  |  | 15.3 |  |  |
| Integration related costs | 4.7 |  |  | 2.9 |  |  | 4.1 |  |  | 14.2 |  |  | 4.1 |  |  |
| Amortization of acquired intangibles | 20.0 |  |  | 18.6 |  |  | 31.7 |  |  | 57.4 |  |  | 37.7 |  |  |
| Amortization of fair value adjustments (2) | 1.5 |  |  | 2.1 |  |  | 14.5 |  |  | 5.8 |  |  | 15.8 |  |  |
| Restructuring and related charges | 2.7 |  |  | 0.9 |  |  | 21.1 |  |  | 4.9 |  |  | 30.2 |  |  |
| Impairment charges (4) | 2.5 |  |  | — |  |  | 30.7 |  |  | 2.5 |  |  | 30.7 |  |  |
| Other interest and (income) expense adjustments | (2.0 | ) |  | — |  |  | (2.5 | ) |  | (2.0 | ) |  | (0.5 | ) |  |
| Gain on sale of product lines | (13.8 | ) |  | — |  |  | — |  |  | (13.8 | ) |  | — |  |  |
| Foreign exchange (gains) losses, net (5) | (0.7 | ) |  | 2.1 |  |  | 1.0 |  |  | 0.3 |  |  | 1.0 |  |  |
| Non-cash interest expense on convertible notes and term loan | 14.0 |  |  | 14.4 |  |  | 4.8 |  |  | 33.3 |  |  | 13.6 |  |  |
| Unrealized gain on derivative liability | — |  |  | — |  |  | — |  |  | — |  |  | (8.8 | ) |  |
| Other charges | 5.3 |  |  | 9.9 |  |  | 13.7 |  |  | 31.4 |  |  | 42.0 |  |  |
| Income before income taxes on non-GAAP basis | $ | 104.3 |  |  | $ | 131.4 |  |  | $ | 74.2 |  |  | $ | 355.8 |  |  | $ | 244.8 |  |  |
| Provision for (benefit from) income taxes on GAAP basis | $ | 5.2 |  |  | $ | 8.6 |  |  | $ | (8.2 | ) |  | $ | 19.6 |  |  | $ | (1.6 | ) |  |
| Income tax adjustments | 1.1 |  |  | 3.4 |  |  | 11.5 |  |  | 7.4 |  |  | 11.4 |  |  |
| Provision for income taxes on non-GAAP basis | $ | 6.3 |  |  | $ | 12.0 |  |  | $ | 3.3 |  |  | $ | 27.0 |  |  | $ | 9.8 |  |  |
| Net income on GAAP basis | $ | 43.4 |  |  | $ | 49.1 |  |  | $ | (74.3 | ) |  | $ | 140.1 |  |  | $ | (10.6 | ) |  |
| Stock-based compensation | 19.2 |  |  | 20.2 |  |  | 16.0 |  |  | 56.1 |  |  | 56.5 |  |  |
| Inventory and fixed asset write down due to product lines exit (1) | 2.3 |  |  | 2.6 |  |  | 19.4 |  |  | 6.0 |  |  | 19.4 |  |  |
| Acquisition related costs | — |  |  | — |  |  | 2.2 |  |  | — |  |  | 15.3 |  |  |
| Integration related costs | 4.7 |  |  | 2.9 |  |  | 4.1 |  |  | 14.2 |  |  | 4.1 |  |  |
| Amortization of acquired intangibles | 20.0 |  |  | 18.6 |  |  | 31.7 |  |  | 57.4 |  |  | 37.7 |  |  |
| Amortization of fair value adjustments (2) | 1.5 |  |  | 2.1 |  |  | 14.5 |  |  | 5.8 |  |  | 15.8 |  |  |
| Restructuring and related charges | 2.7 |  |  | 0.9 |  |  | 21.1 |  |  | 4.9 |  |  | 30.2 |  |  |
| Impairment charges (4) | 2.5 |  |  | — |  |  | 30.7 |  |  | 2.5 |  |  | 30.7 |  |  |
| Other interest and (income) expense adjustments | (2.0 | ) |  | — |  |  | (2.5 | ) |  | (2.0 | ) |  | (0.5 | ) |  |
| Gain on sale of product lines | (13.8 | ) |  | — |  |  | — |  |  | (13.8 | ) |  | — |  |  |

[0001628280-20-006358:8k_2_02:57]
| Foreign exchange (gains) losses, net (5) | (0.7 | ) |  | 2.1 |  |  | 1.0 |  |  | 0.3 |  |  | 1.0 |  |  |
| Non-cash interest expense on convertible notes and term loan | 14.0 |  |  | 14.4 |  |  | 4.8 |  |  | 33.3 |  |  | 13.6 |  |  |
| Unrealized gain on derivative liability | — |  |  | — |  |  | — |  |  | — |  |  | (8.8 | ) |  |
| Other charges | 5.3 |  |  | 9.9 |  |  | 13.7 |  |  | 31.4 |  |  | 42.0 |  |  |
| Income tax adjustments | (1.1 | ) |  | (3.4 | ) |  | (11.5 | ) |  | (7.4 | ) |  | (11.4 | ) |  |
| Net income on non-GAAP basis | $ | 98.0 |  |  | $ | 119.4 |  |  | $ | 70.9 |  | (5) | $ | 328.8 |  |  | $ | 235.0 |  | (5) |
| Net income per share on non-GAAP basis | $ | 1.26 |  |  | $ | 1.53 |  |  | $ | 0.92 |  | (5) | $ | 4.23 |  |  | $ | 3.36 |  | (5) |
| Shares used in per share calculation - diluted on GAAP basis | 77.5 |  |  | 78.0 |  |  | 76.2 |  |  | 77.7 |  |  | 68.7 |  |  |
| Non-GAAP adjustment (6) | — |  |  | — |  |  | 0.5 |  |  | — |  |  | 0.6 |  |  |
| Effect of diluted securities from Series A Preferred Stock | — |  |  | — |  |  | — |  |  | — |  |  | 0.7 |  |  |
| Shares used in per share calculation - diluted on non-GAAP basis | 77.5 |  |  | 78.0 |  |  | 76.7 |  |  | 77.7 |  |  | 70.0 |  |  |

[0001628280-20-006358:8k_2_02:58]
(1) For the three and nine months ended March 28, 2020, we recorded an inventory and fixed assets write down charges of $2.3 million and $6.0 million, respectively, related to the decision to exit the Datacom module and Lithium Niobate product lines.

[0001628280-20-006358:8k_2_02:59]
(2) In connection with the acquisition of Oclaro in fiscal 2019, we recorded a fair value adjustment of $60.3 million to inventory, resulting in $1.5 million and $5.8 million of amortization expense of the fair value adjustment during the three and nine months ended March 28, 2020, respectively.

[0001628280-20-006358:8k_2_02:60]
(3) Other charges of the gross profit on non-GAAP basis for the three and nine months ended March 28, 2020, primarily include costs of transferring product lines to new production facilities, including Thailand of $0.4 million and $8.5 million, respectively. We also incurred excess and obsolete inventory charges driven by the decline in demand from Huawei of $0.1 million and $12.8 million during the three and nine months ended March 28, 2020. In addition, there were expenses of $1.6 million related to COVID-19 outbreak during the three and nine months ended March 28, 2020, which include incremental costs for payroll expense such as overtime pay, facilities costs such as gloves, masks and temperature gauges, and under-utilized capacity at certain facilities, in which manufacturing output was impacted. These COVID-19 related costs are offset by benefits realized from government credits for employers’ payroll tax. Other charges of the gross profit on non-GAAP basis for the three and nine months ended March 30, 2019, included costs of transferring product lines to Thailand of $12.0 million and $38.7 million, respectively.

[0001628280-20-006358:8k_2_02:61]
(4) For each of the three and nine months ended March 28, 2020 and the three and nine months ended March 30, 2019, we recorded an impairment charges of $2.5 million and $30.7 million, respectively, of Property Plant and Equipment related to the decision to exit the Datacom module product line.

[0001628280-20-006358:8k_2_02:62]
(5) The non-GAAP financial measures for the three and nine months ended March 30, 2019 have been adjusted to conform to the current period presentation, by removing foreign exchange (gains) losses, net.

[0001628280-20-006358:8k_2_02:63]
(6) This adjustment represents weighted-average potentially dilutive securities from our stock-based benefit plans excluded from the computation of diluted net loss per share attributable to common stockholders on a GAAP basis because the effect would have been anti-dilutive. This adjustment amount is added for the computation of diluted net income per share on a non-GAAP basis as we had a net income on a non-GAAP basis.

[0001628280-20-006358:8k_2_02:64]
LUMENTUM HOLDINGS INC.

[0001628280-20-006358:8k_2_02:65]
RECONCILIATION OF GAAP NET INCOME TO ADJUSTED EBITDA

[0001628280-20-006358:8k_2_02:66]
(in millions, except per share data)

[0001628280-20-006358:8k_2_02:67]
(unaudited)

[0001628280-20-006358:8k_2_02:68]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2020 |  | December 28, 2019 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| GAAP Net income | $ | 43.4 |  |  | $ | 49.1 |  |  | $ | (74.3 | ) |  | $ | 140.1 |  |  | $ | (10.6 | ) |
| Interest and other expense (income), net | (6.1 | ) |  | 17.1 |  |  | 6.1 |  |  | 17.4 |  |  | 13.2 |  |
| Provision for (benefit from) income taxes | 5.2 |  |  | 8.6 |  |  | (8.2 | ) |  | 19.6 |  |  | (1.6 | ) |
| Depreciation | 27.5 |  |  | 28.7 |  |  | 29.0 |  |  | 87.8 |  |  | 74.7 |  |
| Amortization of acquired intangibles | 20.0 |  |  | 18.6 |  |  | 31.7 |  |  | 57.4 |  |  | 37.7 |  |
| EBITDA | 90.0 |  |  | 122.1 |  |  | (15.7 | ) |  | 322.3 |  |  | 113.4 |  |
| Amortization of fair value adjustments | 1.5 |  |  | 2.1 |  |  | 14.5 |  |  | 5.8 |  |  | 15.8 |  |
| Restructuring and related charges | 2.7 |  |  | 0.9 |  |  | 21.1 |  |  | 4.9 |  |  | 30.2 |  |
| Stock-based compensation | 19.2 |  |  | 20.2 |  |  | 16.0 |  |  | 56.1 |  |  | 56.5 |  |
| Acquisition related costs | — |  |  | — |  |  | 2.2 |  |  | — |  |  | 15.3 |  |
| Unrealized gain on derivative liability | — |  |  | — |  |  | — |  |  | — |  |  | (8.8 | ) |
| Inventory and fixed asset write down due to product lines exit | 2.3 |  |  | 2.6 |  |  | 19.4 |  |  | 6.0 |  |  | 19.4 |  |
| Integration related costs | 4.7 |  |  | 2.9 |  |  | 4.1 |  |  | 14.2 |  |  | 4.1 |  |
| Impairment charges | 2.5 |  |  | — |  |  | 30.7 |  |  | 2.5 |  |  | 30.7 |  |
| Other charges | 5.3 |  |  | 9.9 |  |  | 13.7 |  |  | 31.4 |  |  | 42.0 |  |
| Adjusted EBITDA | $ | 128.2 |  |  | $ | 160.7 |  |  | $ | 106.0 |  |  | $ | 443.2 |  |  | $ | 318.6 |  |
