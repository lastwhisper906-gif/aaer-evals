# LITE note change history — 0001633978-20-000003 → 0001633978-20-000008


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-05-05):
[0001633978-20-000008:note_history:1]
Purchase obligations of $257.2 million as of March 28, 2020, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements.
  (was, 2020-02-04, similarity 0.9684):
[0001633978-20-000003:note_history:1]
Purchase obligations of $289.5 million as of December 28, 2019, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements.

- changed (2020-05-05):
[0001633978-20-000008:note_history:2]
The following table presents the changes in our warranty reserve during the three and nine months ended March 28, 2020 and March 30, 2019 (in millions):
  (was, 2020-02-04, similarity 0.9204):
[0001633978-20-000003:note_history:2]
The following table presents the changes in our warranty reserve during the three and six months ended December 28, 2019 and December 29, 2018 (in millions):

- changed (2020-05-05):
[0001633978-20-000008:note_history:3]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| Balance as of beginning of period | $ | 6.8 |  |  | $ | 9.7 |  |  | $ | 7.5 |  |  | $ | 6.6 |  |
| Warranties assumed in Oclaro acquisition | — |  |  | — |  |  | — |  |  | 3.8 |  |
| Provision for warranty | 0.7 |  |  | 1.5 |  |  | 2.5 |  |  | 3.4 |  |
| Utilization of reserve | (2.1 | ) |  | (1.4 | ) |  | (4.6 | ) |  | (4.0 | ) |
| Balance as of end of period | $ | 5.4 |  |  | $ | 9.8 |  |  | $ | 5.4 |  |  | $ | 9.8 |  |
  (was, 2020-02-04, similarity 0.8635):
[0001633978-20-000003:note_history:3]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |  | December 28, 2019 |  | December 29, 2018 |
| Balance as of beginning of period | $ | 7.0 |  |  | $ | 6.6 |  |  | $ | 7.5 |  |  | $ | 6.6 |  |
| Warranties assumed in Oclaro acquisition | — |  |  | 3.8 |  |  | — |  |  | 3.8 |  |
| Provision for warranty | 0.6 |  |  | 0.7 |  |  | 1.8 |  |  | 1.9 |  |
| Utilization of reserve | (0.8 | ) |  | (1.4 | ) |  | (2.5 | ) |  | (2.6 | ) |
| Balance as of end of period | $ | 6.8 |  |  | $ | 9.7 |  |  | $ | 6.8 |  |  | $ | 9.7 |  |

- added (2020-05-05):
[0001633978-20-000008:note_history:4]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse

- changed (2020-05-05):
[0001633978-20-000008:note_history:5]
impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss. We have recorded $1.0 million of litigation contingency in other current liabilities on the condensed consolidated balance sheet as of March 28, 2020.
  (was, 2020-02-04, similarity 0.6026):
[0001633978-20-000003:note_history:5]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss. As of December 28, 2019, we did not have any material claims or proceedings that were probable or reasonably possible.

- changed (2020-05-05):
[0001633978-20-000008:note_history:6]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of March 28, 2020, we did not have any material indemnification claims that were probable or reasonably possible.
  (was, 2020-02-04, similarity 0.9857):
[0001633978-20-000003:note_history:6]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of December 28, 2019, we did not have any material indemnification claims that were probable or reasonably possible.

- changed (2020-05-05):
[0001633978-20-000008:note_history:7]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.
In connection with our acquisition of Oclaro, we recorded $1.1 million in Malaysia Goods and Services Tax (“GST”) refund claims within prepaid expenses and other current assets in our condensed consolidated balance sheet. The refund claim represents an initial claim of $2.5 million of GST, net of reserves, that was previously denied by the Malaysian tax authorities in 2016. During the nine months ended March 28, 2020, we were able to favorably resolve this audit and received refunds for all of our outstanding GST claims.
  (was, 2020-02-04, similarity 0.7831):
[0001633978-20-000003:note_history:7]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.

- removed (2020-05-05):
[0001633978-20-000003:note_history:8]
Acquisition Contingencies

- removed (2020-05-05):
[0001633978-20-000003:note_history:9]
In February 2017, as a result of the acquisition of a privately held company, we incurred the contingent liability of $3.0 million. This liability is recorded in other current liabilities within our condensed consolidated balance sheet as of December 28, 2019.

- removed (2020-05-05):
[0001633978-20-000003:note_history:10]
In connection with our acquisition of Oclaro, we recorded $1.1 million in Malaysia Goods and Services Tax (“GST”) refund claims within prepaid expenses and other current assets in our condensed consolidated balance sheet. The refund claim represents an initial claim of $2.5 million of GST, net of reserves, that were previously denied by the Malaysian tax authorities in 2016. 
During the six months ended December 28, 2019, we were able to favorably resolve this audit and received refunds for all of our outstanding GST claims.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2020-05-05):
[0001633978-20-000008:note_history:11]
The COVID-19 pandemic has created and may continue to create significant uncertainty in global financial markets, which has disrupted and harmed, and may continue to disrupt and harm, the Company's business, financial condition, and results of operations. The extent of the impact of COVID-19 on the Company's operational and financial performance will depend on certain developments, including but not limited to the duration and spread of the outbreak, duration of local, state and federal issued public health orders in each jurisdiction where we operate or in which our customers and suppliers operate, impact on our customers and our sales cycles, impact on our supply chain and manufacturing partners, impact on our employees and impact on regional and worldwide economies and financial markets in general, all of which are uncertain and cannot be predicted.

- changed (2020-05-05):
[0001633978-20-000008:note_history:12]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2021 will be a 53-week year. Our fiscal 2020 is a 52-week year ending on June 27, 2020, with the quarter ended March 28, 2020 being a 13-week quarterly period. Our fiscal 2019 was a 52-week year that ended on June 29, 2019, with the quarter ended March 30, 2019 being a 13-week quarterly period.
  (was, 2020-02-04, similarity 0.9595):
[0001633978-20-000003:note_history:12]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2021 will be a 53-week year. Our fiscal 2020 is a 52-week year ending on June 27, 2020, with the quarter ended December 28, 2019 being a 13-week quarterly period. Our fiscal 2019 was a 52-week year that ended on June 29, 2019, with the quarter ended December 29, 2018 being a 13-week quarterly period.

- changed (2020-05-05):
[0001633978-20-000008:note_history:13]
Except for the accounting policies for lease accounting as a result of the adoption of Accounting Standards Update (“ASU”) 2016-02, Leases (Topic 842), there have been no significant changes to our significant accounting policies as of and for the three months ended March 28, 2020, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the year ended June 29, 2019.
  (was, 2020-02-04, similarity 0.986):
[0001633978-20-000003:note_history:13]
Except for the accounting policies for lease accounting as a result of the adoption of Accounting Standards Update (“ASU”) 2016-02, Leases (Topic 842), there have been no significant changes to our significant accounting policies as of and for the three months ended December 28, 2019, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the year ended June 29, 2019.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2020-05-05):
[0001633978-20-000008:note_history:14]
| Liability component: | March 28, 2020 |  | June 29, 2019 |
|  | 2024 Notes |  | 2026 Notes |  | 2024 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount and debt issuance costs | (84.2 | ) |  | (309.8 | ) |  | (98.1 | ) |
| Net carrying amount of the liability component | $ | 365.8 |  |  | $ | 740.2 |  |  | $ | 351.9 |  |

- removed (2020-05-05):
[0001633978-20-000003:note_history:15]
| Liability component: | December 28, 2019 |  | June 29, 2019 |
|  | 2024 Notes |  | 2026 Notes |  | 2024 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount and debt issuance costs | (88.9 | ) |  | (319.1 | ) |  | (98.1 | ) |
| Net carrying amount of the liability component | $ | 361.1 |  |  | $ | 730.9 |  |  | $ | 351.9 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2020-05-05):
[0001633978-20-000008:note_history:16]
We may redeem for cash, stock or combination of both for all or any portion of the 2026 Notes, at our option, on or after December 20, 2023, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect

- changed (2020-05-05):
[0001633978-20-000008:note_history:17]
for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide a notice of redemption at a redemption price equal to 100% of the principal amount of the 2026 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2026 Notes. Upon the occurrence of a fundamental change (as defined in the 2026 Indenture), holders may require us to repurchase all or a portion of the 2026 Notes for cash at a price equal to 100% of the principal amount of the 2026 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.
  (was, 2020-02-04, similarity 0.8681):
[0001633978-20-000003:note_history:17]
We may redeem for cash, stock or combination of both for all or any portion of the 2026 Notes, at our option, on or after December 20, 2023, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide a notice of redemption at a redemption price equal to 100% of the principal amount of the 2026 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2026 Notes. Upon the occurrence of a fundamental change (as defined in the 2026 Indenture), holders may require us to repurchase all or a portion of the 2026 Notes for cash at a price equal to 100% of the principal amount of the 2026 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

- changed (2020-05-05):
[0001633978-20-000008:note_history:18]
In March 2017, we issued $450.0 million of the 2024 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank National Association, as trustee (the “2024 Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.
  (was, 2020-02-04, similarity 0.9855):
[0001633978-20-000003:note_history:18]
In March 2017, we issued the 2024 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank National Association, as trustee (the “2024 Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

- changed (2020-05-05):
[0001633978-20-000008:note_history:19]
On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2024 Notes at any time. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2024 Indenture), we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert 2024 Notes in connection with such make-whole fundamental change.
  (was, 2020-02-04, similarity 0.6676):
[0001633978-20-000003:note_history:19]
On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2024 Notes at any time. In addition, upon the occurrence of a make-whole fundamental

- added (2020-05-05):
[0001633978-20-000008:note_history:20]
| Liability component: | March 28, 2020 |  | June 29, 2019 |
|  | 2024 Notes |  | 2026 Notes |  | 2024 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount and debt issuance costs | (84.2 | ) |  | (309.8 | ) |  | (98.1 | ) |
| Net carrying amount of the liability component | $ | 365.8 |  |  | $ | 740.2 |  |  | $ | 351.9 |  |

- changed (2020-05-05):
[0001633978-20-000008:note_history:21]
The following table sets forth interest expense information related to the convertible notes for the periods presented (in millions):
  (was, 2020-02-04, similarity 0.9301):
[0001633978-20-000003:note_history:21]
The following table sets forth interest expense information related to the convertible notes for the periods presented (in millions, except percentages):

- changed (2020-05-05):
[0001633978-20-000008:note_history:22]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| Contractual interest expense | $ | 1.6 |  |  | $ | 0.3 |  |  | $ | 2.3 |  |  | $ | 0.9 |  |
| Amortization of the debt discount and debt issuance costs | 14.0 |  |  | 4.5 |  |  | 24.8 |  |  | 13.2 |  |
| Total interest expense | $ | 15.6 |  |  | $ | 4.8 |  |  | $ | 27.1 |  |  | $ | 14.1 |  |
  (was, 2020-02-04, similarity 0.8402):
[0001633978-20-000003:note_history:22]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |  | December 28, 2019 |  | December 29, 2018 |
| Contractual interest expense | $ | 0.5 |  |  | $ | 0.3 |  |  | $ | 0.7 |  |  | $ | 0.6 |  |
| Amortization of the debt discount and debt issuance costs | 6.2 |  |  | 4.4 |  |  | 10.8 |  |  | 8.7 |  |
| Total interest expense | $ | 6.7 |  |  | $ | 4.7 |  |  | $ | 11.5 |  |  | $ | 9.3 |  |

- changed (2020-05-05):
[0001633978-20-000008:note_history:23]
The future interest and principal payments related to our convertible notes are as follows as of March 28, 2020 (in millions):
  (was, 2020-02-04, similarity 0.9633):
[0001633978-20-000003:note_history:23]
The future interest and principal payments related to our convertible notes are as follows as of December 28, 2019 (in millions):

- changed (2020-05-05):
[0001633978-20-000008:note_history:24]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | Total |
| Remainder of 2020 | $ | — |  |  | $ | 2.7 |  |  | $ | 2.7 |  |
| 2021 | 1.1 |  |  | 5.2 |  |  | 6.3 |  |
| 2022 | 1.1 |  |  | 5.3 |  |  | 6.4 |  |
| 2023 | 1.1 |  |  | 5.2 |  |  | 6.3 |  |
| 2024 | 451.2 |  |  | 5.3 |  |  | 456.5 |  |
| Thereafter | — |  |  | 1,063.1 |  |  | 1,063.1 |  |
| Total convertible notes payments | $ | 454.5 |  |  | $ | 1,086.8 |  |  | $ | 1,541.3 |  |
  (was, 2020-02-04, similarity 0.9969):
[0001633978-20-000003:note_history:24]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | Total |
| Remainder of 2020 | $ | 0.5 |  |  | $ | 2.7 |  |  | $ | 3.2 |  |
| 2021 | 1.1 |  |  | 5.2 |  |  | 6.3 |  |
| 2022 | 1.1 |  |  | 5.3 |  |  | 6.4 |  |
| 2023 | 1.1 |  |  | 5.2 |  |  | 6.3 |  |
| 2024 | 451.2 |  |  | 5.3 |  |  | 456.5 |  |
| Thereafter | — |  |  | 1,063.1 |  |  | 1,063.1 |  |
| Total convertible notes payments | $ | 455.0 |  |  | $ | 1,086.8 |  |  | $ | 1,541.8 |  |

- added (2020-05-05):
[0001633978-20-000008:note_history:25]
On December 10, 2018 (the “Closing Date”), concurrent with the closing of the Oclaro merger, we entered into a Credit and Guarantee Agreement (the “Credit Agreement”), by and among us, certain of our subsidiaries, the lenders party thereto, and

- changed (2020-05-05):
[0001633978-20-000008:note_history:26]
Deutsche Bank, as administrative agent and collateral agent for the lenders. The Credit Agreement provides for a senior secured term loan facility (the “Term Loan Facility”) in an aggregate principal amount of $500.0 million. The term loans available under the Term Loan Facility were fully drawn on the Closing Date and the proceeds of the term loans were used to consummate the merger and pay fees and expenses in connection with the merger and the Term Loan Facility.
  (was, 2020-02-04, similarity 0.7952):
[0001633978-20-000003:note_history:26]
On December 10, 2018 (the “Closing Date”), concurrent with the closing of the Oclaro merger, we entered into a Credit and Guarantee Agreement (the “Credit Agreement”), by and among us, certain of our subsidiaries, the lenders party thereto, and Deutsche Bank, as administrative agent and collateral agent for the lenders. The Credit Agreement provides for a senior secured term loan facility (the “Term Loan Facility”) in an aggregate principal amount of $500.0 million. The term loans available under the Term Loan Facility were fully drawn on the Closing Date and the proceeds of the term loans were used to consummate the merger and pay fees and expenses in connection with the merger and the Term Loan Facility.

- changed (2020-05-05):
[0001633978-20-000008:note_history:27]
In fiscal 2020, we repaid, in full, all amounts outstanding under our Term Loan Facility. During the nine months ended March 28, 2020, we incurred an $8.0 million loss for the unamortized debt issuance costs as a result of this full repayment.
  (was, 2020-02-04, similarity 0.8552):
[0001633978-20-000003:note_history:27]
In the second quarter of fiscal 2020, we repaid, in full, all amounts outstanding under our Term Loan Facility. We incurred $8.0 million loss for the unamortized debt issuance costs as a result of this full repayment.

- changed (2020-05-05):
[0001633978-20-000008:note_history:28]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| Contractual interest expense | $ | — |  |  | $ | 6.2 |  |  | $ | 9.6 |  |  | $ | 10.2 |  |
| Amortization of the debt issuance costs | — |  |  | 0.4 |  |  | 0.5 |  |  | 0.5 |  |
| Loss on early extinguishment of debt | — |  |  | — |  |  | 8.0 |  |  | — |  |
| Total interest expense | $ | — |  |  | $ | 6.6 |  |  | $ | 18.1 |  |  | $ | 10.7 |  |
  (was, 2020-02-04, similarity 0.7528):
[0001633978-20-000003:note_history:28]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |  | December 28, 2019 |  | December 29, 2018 |
| Contractual interest expense | $ | 3.4 |  |  | $ | 3.7 |  |  | $ | 9.6 |  |  | $ | 4.1 |  |
| Amortization of the debt issuance costs | 0.2 |  |  | 0.1 |  |  | 0.5 |  |  | 0.1 |  |
| Loss on early extinguishment of debt | 8.0 |  |  | — |  |  | 8.0 |  |  | — |  |
| Total interest expense | $ | 11.6 |  |  | $ | 3.8 |  |  | $ | 18.1 |  |  | $ | 4.2 |  |

- changed (2020-05-05):
[0001633978-20-000008:note_history:29]
For the nine months ended March 28, 2020, we also recorded $0.1 million interest expense related to our finance leases.
  (was, 2020-02-04, similarity 0.9375):
[0001633978-20-000003:note_history:29]
For the six months ended December 28, 2019, we also recorded $0.1 million interest expense related to our finance leases.

- changed (2020-05-05):
[0001633978-20-000008:note_history:30]
|  | March 28, 2020 |  | June 29, 2019 |
| Principal | $ | 497.5 |  |  | $ | 500.0 |  |
| Repayment of principal | (497.5 | ) |  | (2.5 | ) |
| Unamortized value of the debt issuance costs | — |  |  | (8.5 | ) |
| Net carrying value | $ | — |  |  | $ | 489.0 |  |
| Term loan, current | $ | — |  |  | $ | 5.0 |  |
| Term loan, non-current | $ | — |  |  | $ | 484.0 |  |
  (was, 2020-02-04, similarity 0.9795):
[0001633978-20-000003:note_history:30]
|  | December 28, 2019 |  | June 29, 2019 |
| Principal | $ | 497.5 |  |  | $ | 500.0 |  |
| Repayment of principal | (497.5 | ) |  | (2.5 | ) |
| Unamortized value of the debt issuance costs | — |  |  | (8.5 | ) |
| Net carrying value | $ | — |  |  | $ | 489.0 |  |
| Term loan, current | $ | — |  |  | $ | 5.0 |  |
| Term loan, non-current | $ | — |  |  | $ | 484.0 |  |

- removed (2020-05-05):
[0001633978-20-000003:note_history:31]
change  (as defined in the 2024 Indenture), we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert 2024 Notes in connection with such make-whole fundamental change.

- removed (2020-05-05):
[0001633978-20-000003:note_history:32]
| Liability component: | December 28, 2019 |  | June 29, 2019 |
|  | 2024 Notes |  | 2026 Notes |  | 2024 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount and debt issuance costs | (88.9 | ) |  | (319.1 | ) |  | (98.1 | ) |
| Net carrying amount of the liability component | $ | 361.1 |  |  | $ | 730.9 |  |  | $ | 351.9 |  |


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-05):
[0001633978-20-000008:note_history:33]
|  | Less than 12 months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| March 28, 2020: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 8.0 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 8.0 |  |  | $ | — |  |
| Certificates of deposit | 2.5 |  |  | — |  |  | — |  |  | — |  |  | 2.5 |  |  | — |  |
| Commercial paper | 55.2 |  |  | — |  |  | — |  |  | — |  |  | 55.2 |  |  | — |  |
| Corporate debt securities | 301.1 |  |  | (2.5 | ) |  | — |  |  | — |  |  | 301.1 |  |  | (2.5 | ) |
| Total | $ | 366.8 |  |  | $ | (2.5 | ) |  | $ | — |  |  | $ | — |  |  | $ | 366.8 |  |  | $ | (2.5 | ) |
| June 29, 2019: |  |  |  |  |  |  |  |  |  |  |  |
| Asset-backed securities | $ | 4.2 |  |  | $ | — |  |  | $ | 5.9 |  |  | $ | — |  |  | $ | 10.1 |  |  | $ | — |  |
| Corporate debt securities | 9.6 |  |  | — |  |  | 35.9 |  |  | (0.1 | ) |  | 45.5 |  |  | (0.1 | ) |
| Foreign government bonds | — |  |  | — |  |  | 2.1 |  |  | — |  |  | 2.1 |  |  | — |  |
| U.S. government bonds | 6.9 |  |  | — |  |  | — |  |  | — |  |  | 6.9 |  |  | — |  |
| Total | $ | 20.7 |  |  | $ | — |  |  | $ | 43.9 |  |  | $ | (0.1 | ) |  | $ | 64.6 |  |  | $ | (0.1 | ) |
  (was, 2020-02-04, similarity 0.6252):
[0001633978-20-000003:note_history:33]
|  | Less than 12 months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| December 28, 2019: |  |  |  |  |  |  |  |  |  |  |  |
| Asset-backed securities | $ | 2.3 |  |  | $ | — |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 2.4 |  |  | $ | — |  |
| Corporate debt securities | 17.3 |  |  | — |  |  | — |  |  | — |  |  | 17.3 |  |  | — |  |
| Total | $ | 19.6 |  |  | $ | — |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 19.7 |  |  | $ | — |  |
| June 29, 2019: |  |  |  |  |  |  |  |  |  |  |  |
| Asset-backed securities | $ | 4.2 |  |  | $ | — |  |  | $ | 5.9 |  |  | $ | — |  |  | $ | 10.1 |  |  | $ | — |  |
| Corporate debt securities | 9.6 |  |  | — |  |  | 35.9 |  |  | (0.1 | ) |  | 45.5 |  |  | (0.1 | ) |
| Foreign government bonds | — |  |  | — |  |  | 2.1 |  |  | — |  |  | 2.1 |  |  | — |  |
| U.S. government bonds | 6.9 |  |  | — |  |  | — |  |  | — |  |  | 6.9 |  |  | — |  |
| Total | $ | 20.7 |  |  | $ | — |  |  | $ | 43.9 |  |  | $ | (0.1 | ) |  | $ | 64.6 |  |  | $ | (0.1 | ) |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-05):
[0001633978-20-000008:note_history:34]
|  | March 28, 2020 |  | June 29, 2019 |
| Principal | $ | 497.5 |  |  | $ | 500.0 |  |
| Repayment of principal | (497.5 | ) |  | (2.5 | ) |
| Unamortized value of the debt issuance costs | — |  |  | (8.5 | ) |
| Net carrying value | $ | — |  |  | $ | 489.0 |  |
| Term loan, current | $ | — |  |  | $ | 5.0 |  |
| Term loan, non-current | $ | — |  |  | $ | 484.0 |  |
  (was, 2020-02-04, similarity 0.9795):
[0001633978-20-000003:note_history:34]
|  | December 28, 2019 |  | June 29, 2019 |
| Principal | $ | 497.5 |  |  | $ | 500.0 |  |
| Repayment of principal | (497.5 | ) |  | (2.5 | ) |
| Unamortized value of the debt issuance costs | — |  |  | (8.5 | ) |
| Net carrying value | $ | — |  |  | $ | 489.0 |  |
| Term loan, current | $ | — |  |  | $ | 5.0 |  |
| Term loan, non-current | $ | — |  |  | $ | 484.0 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-05):
[0001633978-20-000008:note_history:35]
The future interest and principal payments related to our convertible notes are as follows as of March 28, 2020 (in millions):
  (was, 2020-02-04, similarity 0.9633):
[0001633978-20-000003:note_history:35]
The future interest and principal payments related to our convertible notes are as follows as of December 28, 2019 (in millions):

- changed (2020-05-05):
[0001633978-20-000008:note_history:36]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | Total |
| Remainder of 2020 | $ | — |  |  | $ | 2.7 |  |  | $ | 2.7 |  |
| 2021 | 1.1 |  |  | 5.2 |  |  | 6.3 |  |
| 2022 | 1.1 |  |  | 5.3 |  |  | 6.4 |  |
| 2023 | 1.1 |  |  | 5.2 |  |  | 6.3 |  |
| 2024 | 451.2 |  |  | 5.3 |  |  | 456.5 |  |
| Thereafter | — |  |  | 1,063.1 |  |  | 1,063.1 |  |
| Total convertible notes payments | $ | 454.5 |  |  | $ | 1,086.8 |  |  | $ | 1,541.3 |  |
  (was, 2020-02-04, similarity 0.9969):
[0001633978-20-000003:note_history:36]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | Total |
| Remainder of 2020 | $ | 0.5 |  |  | $ | 2.7 |  |  | $ | 3.2 |  |
| 2021 | 1.1 |  |  | 5.2 |  |  | 6.3 |  |
| 2022 | 1.1 |  |  | 5.3 |  |  | 6.4 |  |
| 2023 | 1.1 |  |  | 5.2 |  |  | 6.3 |  |
| 2024 | 451.2 |  |  | 5.3 |  |  | 456.5 |  |
| Thereafter | — |  |  | 1,063.1 |  |  | 1,063.1 |  |
| Total convertible notes payments | $ | 455.0 |  |  | $ | 1,086.8 |  |  | $ | 1,541.8 |  |
