# LITE notes — 0001628280-26-005129


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001628280-26-005129:notes:1]
[same as prior period, unchanged from 0001628280-25-049073:notes:3]

[0001628280-26-005129:notes:2]
[same as prior period, unchanged from 0001628280-25-049073:notes:4]

[0001628280-26-005129:notes:3]
[same as prior period, unchanged from 0001628280-25-049073:notes:5]

[0001628280-26-005129:notes:4]
[same as prior period, unchanged from 0001628280-25-049073:notes:6]

[0001628280-26-005129:notes:5]
[same as prior period, unchanged from 0001628280-25-049073:notes:7]

[0001628280-26-005129:notes:6]
[same as prior period, unchanged from 0001628280-25-049073:notes:8]

[0001628280-26-005129:notes:7]
[same as prior period, unchanged from 0001628280-25-049073:notes:9]

[0001628280-26-005129:notes:8]
[same as prior period, unchanged from 0001628280-25-049073:notes:10]

[0001628280-26-005129:notes:9]
Prior to fiscal year 2026, we operated in two reportable segments consisting of Cloud & Networking and Industrial Tech. During the first quarter of fiscal year 2026, we implemented a re-organization, and we are now managed as a single, integrated enterprise, with a unified management team overseeing operations across the entire company, rather than through discrete operating segments. The chief operating decision maker (“CODM”) is the Company’s Chief Executive Officer, who reviews financial information presented as a single enterprise for purposes of allocating resources and evaluating financial performance. Accordingly, following the reorganization, we determined we operate in a single reporting segment. Comparative prior period segment information has been updated to reflect the new segment structure and measures. The changes in our operating segments had no impact on our previously reported consolidated results of operations, financial position or cash flows. Refer to “Note 15. Operating Segments and Geographic Information” for more details.

[0001628280-26-005129:notes:10]
[same as prior period, unchanged from 0001628280-25-049073:notes:12]

[0001628280-26-005129:notes:11]
The Company is actively monitoring and assessing the ongoing global trade environment, particularly with respect to recent changes in trade restrictions and tariff regulations. We have assessed the potential impacts of heightened restrictions and tariffs on our allowance for credit losses, the carrying value of our goodwill and other long-lived assets, inventory valuation, and revenue recognition. While we have determined there was not a material impact to our condensed consolidated financial statements as of December 27, 2025 and for the three and six months ended December 27, 2025, import tariffs implemented by the U.S. and other countries, as currently in effect and/or proposed, could have a material impact on our results for the remainder of fiscal year 2026 and in the future. The impact of tariffs is dependent upon negotiations with customers and suppliers and other mitigation efforts and potential further changes in global trade policies, including higher tariffs in the U.S. or other countries.

[0001628280-26-005129:notes:12]
During the three months ended December 27, 2025, the last reported sale price of the Company’s common stock was at least 130% of the applicable conversion price of each series of our convertible notes, which includes 2032 Notes, 2029 Notes, 2028 Notes, and 2026 Notes (collectively referred to as the “Notes”) for at least 20 trading days during the 30 consecutive trading-day period ended on December 27, 2025. Therefore, the Notes are convertible at the option of the holders, and we are required to satisfy the conversion obligation with respect to any such converted series of Notes by paying cash equal to the principal amount of such converted series of Notes, and paying or delivering, as the case maybe, cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof. Accordingly, pursuant to ASC 470-20 under U.S. GAAP, although the applicable contractual maturity dates of these Notes extend beyond 12 months from the balance sheet date, we are required to classify our 2028 Notes, 2029 Notes and 2032 Notes, that have an aggregate carrying value of $2,714.2 million, as current portion of long-term debt as of December 27, 2025.  Only the 2026 Notes with carrying value of $468.3 million mature within the next 12 months.

[0001628280-26-005129:notes:13]
The carrying amounts and estimated fair values of the convertible notes are as follows for the periods presented (in millions):

[0001628280-26-005129:notes:14]
|  | December 27, 2025 |  | June 28, 2025 |
|  | Carrying Amount |  | Estimated Fair Value |  | Carrying Amount |  | Estimated Fair Value |
| 2032 Notes | $ | 1,255.3 |  |  | $ | 2,840.8 |  |  | $ | — |  |  | $ | — |  |
| 2029 Notes | 600.6 |  |  | 3,400.1 |  |  | 600.2 |  |  | 925.5 |  |
| 2028 Notes | 858.3 |  |  | 2,584.6 |  |  | 857.7 |  |  | 890.2 |  |
| 2026 Notes | 468.3 |  |  | 1,844.6 |  |  | 1,048.3 |  |  | 1,233.3 |  |
|  | $ | 3,182.5 |  |  | $ | 10,670.1 |  |  | $ | 2,506.2 |  |  | $ | 3,049.0 |  |

[0001628280-26-005129:notes:15]
The 2028 Notes, 2029 Notes and 2032 Notes are held by more than 60 unique holders and no holders had individual aggregate principal values greater than $505.0 million at December 27, 2025. To the extent Note holders elect to convert all or a significant portion of the Notes within a short period of time, our liquidity would be adversely impacted, and the Note holders’ ability to exercise their conversion right raises a substantial doubt that we could continue as a going concern. If we receive a significant number of requests for early conversion of Notes, we would utilize existing cash, cash equivalents and short-term investments, together with available borrowings under our existing revolving credit facility, cash flows from operations, and proceeds from one or more potential new financings to settle the principal amount of such converted Notes in cash, with any excess conversion value thereof to be settled in cash, shares of common stock, or a combination of cash and shares of common stock, at our election.

[0001628280-26-005129:notes:16]
However, the fair value of the Notes, which would be the estimated value the holders would receive if they sell their Notes in the bond market, is generally higher than the value the holders would receive upon early conversion. The fair value is generally higher than the conversion value due to the embedded call option in the Notes which has time left until the Notes mature.  Conversion also requires a holder to be subject to a holding period in which they are subject to further volatility. Therefore, historically, the holders’ requests for early conversion of our Notes have not been significant prior to the three-month period immediately preceding maturity.

[0001628280-26-005129:notes:17]
[same as prior period, unchanged from 0001628280-25-049073:notes:14]

[0001628280-26-005129:notes:18]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal year 2026 is a 52-week year ending on June 27, 2026, with the quarter ended December 27, 2025 being a 13-week quarterly period. Our fiscal year 2025 was a 52-week year that ended on June 28, 2025, with the quarter ended December 28, 2024 being a 13-week quarterly period.

[0001628280-26-005129:notes:19]
[same as prior period, unchanged from 0001628280-25-049073:notes:16]

[0001628280-26-005129:notes:20]
[same as prior period, unchanged from 0001628280-25-049073:notes:17]

[0001628280-26-005129:notes:21]
[same as prior period, unchanged from 0001628280-25-049073:notes:18]

[0001628280-26-005129:notes:22]
The condensed consolidated financial statements and accompanying notes should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the fiscal year ended June 28, 2025. There were no significant changes to our accounting policies during the six months ended December 27, 2025, except as noted below:

[0001628280-26-005129:notes:23]
[same as prior period, unchanged from 0001628280-25-049073:notes:20]

[0001628280-26-005129:notes:24]
[same as prior period, unchanged from 0001628280-25-049073:notes:21]

[0001628280-26-005129:notes:25]
[same as prior period, unchanged from 0001628280-25-049073:notes:22]

[0001628280-26-005129:notes:26]
[same as prior period, unchanged from 0001628280-25-049073:notes:23]

[0001628280-26-005129:notes:27]
In the fourth quarter of fiscal year 2025, we released $153.1 million of valuation allowances on our UK deferred tax assets after we considered all available positive and negative evidence related to our UK subsidiary. We analyzed the UK subsidiary’s historical operating results, projected future taxable income, tax planning strategies, and reversals of deferred tax liabilities, and determined that the weight of available objectively verifiable positive evidence supported the realizability of the UK deferred tax assets. In weighing the available evidence, more weight was placed upon our forecasts of future taxable income than on the history of pre-tax losses as such losses were generated under our prior UK business operating model which will no longer be in effect beginning with fiscal year 2026, and the guarantee of a positive operating margin as we effectuated an internal restructuring at the end of fiscal year 2025. Further, the most significant deferred tax asset in the UK is the net operating loss carryforward. Under UK tax law, net operating losses may be carried forward indefinitely, and we have considered the indefinite carryforward period to be positive evidence.

[0001628280-26-005129:notes:28]
[same as prior period, unchanged from 0001628280-25-049073:notes:25]

[0001628280-26-005129:notes:29]
[same as prior period, unchanged from 0001628280-25-049073:notes:26]

[0001628280-26-005129:notes:30]
[same as prior period, unchanged from 0001628280-25-049073:notes:27]


## us-gaap:ConvertibleDebtTableTextBlock

[0001628280-26-005129:notes:31]
The table below summarizes the applicable conversion price and the equivalent 130% of the conversion price of each series of Notes  (per share amount):

[0001628280-26-005129:notes:32]
|  | Conversion Price |  | 130% of Conversion Price |
| 2032 Notes | $ | 187.77 |  |  | $ | 244.10 |  |
| 2029 Notes | 69.54 |  |  | 90.40 |  |
| 2028 Notes | 131.03 |  |  | 170.34 |  |
| 2026 Notes | 99.29 |  |  | 129.08 |  |

[0001628280-26-005129:notes:33]
Our convertible notes consisted of the following components as of the periods presented (in millions):

[0001628280-26-005129:notes:34]
| December 27, 2025 | 2026 Notes |  | 2028 Notes |  | 2029 Notes |  | 2032 Notes |  | Total |  |  |  |  |  |
| Principal | $ | 468.8 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 1,265.0 |  |  | $ | 3,198.5 |  |  |  |  |  |  |
| Unamortized debt issuance costs | (0.5) |  |  | (2.7) |  |  | (3.1) |  |  | (9.7) |  |  | (16.0) |  |  |  |  |  |  |
| Net carrying amount of the liability component | $ | 468.3 |  |  | $ | 858.3 |  |  | $ | 600.6 |  |  | $ | 1,255.3 |  |  | $ | 3,182.5 |  |  |  |  |  |  |

[0001628280-26-005129:notes:35]
| June 28, 2025 |  |  | 2026 Notes |  | 2028 Notes |  | 2029 Notes |  | Total |
| Principal |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,514.7 |  |
| Unamortized debt issuance costs |  |  | (1.7) |  |  | (3.3) |  |  | (3.5) |  |  | (8.5) |  |
| Net carrying amount of the liability component |  |  | $ | 1,048.3 |  |  | $ | 857.7 |  |  | $ | 600.2 |  |  | $ | 2,506.2 |  |


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001628280-26-005129:notes:36]
Note 2. Recently Issued Accounting Pronouncements

[0001628280-26-005129:notes:37]
Accounting Pronouncements Recently Adopted

[0001628280-26-005129:notes:38]
In November 2024, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2024-04, Debt with Conversion and Other Options (Subtopic 470-20): Induced Conversions of Convertible Debt Instruments, which clarifies the requirements related to accounting for the settlement of a debt as an induced conversion. ASU No. 2024-04 is intended to improve the relevance and consistency in application of the induced conversion guidance in Subtopic 470-20 for convertible debt instruments with cash conversion features and debt instruments that are not currently convertible, when the face value of the debt is settled in cash. We have early adopted ASU No. 2024-04 in the first quarter of fiscal year 2026 and applied the accounting in the partial repurchase of our 2026 Notes in September 2025. Refer to “Note 9. Debt” for detailed discussion of this transaction.

[0001628280-26-005129:notes:39]
In December 2023, the FASB issued ASU No. 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which requires disaggregated information about a reporting entity’s effective tax rate reconciliation as well as information on income tax paid. ASU No. 2023-09 is effective for fiscal years beginning after December 15, 2024, with early adoption permitted. We have adopted ASU No. 2023-09 beginning in fiscal year 2026; however, it has no material impact on our condensed consolidated financial statements and disclosures for the three and six months ended December 27, 2025.

[0001628280-26-005129:notes:40]
In March 2024, the FASB issued ASU No. 2024-02: Codification Improvements - Amendments to Remove References to the Concepts Statements, which contains amendments to the Codification that remove references to various FASB Concepts Statements. We have adopted ASU No. 2024-02 in the first quarter of fiscal year 2026 and it did not have a material impact on our condensed consolidated financial statements and disclosures as a result of the adoption.

[0001628280-26-005129:notes:41]
Accounting Pronouncements Not Yet Effective

[0001628280-26-005129:notes:42]
In December 2025, the FASB issued ASU No. 2025-12, Codification Improvements, the purpose of which is to update the codification for a broad range of topics arising from technical corrections, unintended applications of the codification, clarifications, and other minor improvements. ASU No. 2025-12 is effective for fiscal years beginning after December 15, 2026,  with early adoption permitted. We plan to adopt ASU No. 2025-12 in the first quarter of fiscal year 2028. We are currently evaluating the impact of this ASU on our financial statements and disclosures.

[0001628280-26-005129:notes:43]
In December 2025, the FASB issued ASU No. 2025-11, Interim Reporting (Topic 270), which is intended to improve the navigability of the interim reporting guidance in ASC 270 and clarify when it applies. ASU No. 2025-11 is effective for fiscal years beginning after December 15, 2027, with early adoption permitted. We plan to adopt ASU No. 2025-11 in the first quarter of fiscal year 2029. We are currently evaluating the impact of this ASU on our financial statements and disclosures.

[0001628280-26-005129:notes:44]
In December 2025, the FASB issued ASU No. 2025-10, Government Grants (Topic 832), which adds guidance to ASC 832 on the recognition, measurement, and presentation of government grants. ASU No. 2025-10 is effective for fiscal years beginning after December 15, 2028, with early adoption permitted. We are currently evaluating the impact of this ASU on our financial statements and disclosures.

[0001628280-26-005129:notes:45]
In November 2025, the FASB issued ASU No. 2025-09, Derivatives and Hedging (Topic 815), which amends certain aspects of the hedge accounting guidance in ASC 815, including the risk assessment for cash flow hedges, hedging forecasted interest payments on choose-your-rate debt instruments, cash flow hedges of nonfinancial forecasted transactions, net written options as hedging instruments, and dual hedges of foreign currency denominated debt instruments. ASU No. 2025-09 is effective for fiscal years beginning after December 15, 2026, with early adoption permitted. We plan to adopt ASU No. 2025-09 in the first quarter of fiscal year 2028. We are currently evaluating the impact of this ASU on our financial statements and disclosures.

[0001628280-26-005129:notes:46]
In November 2025, the FASB issued ASU No. 2025-08, Financial Instruments—Credit Losses (Topic 326), which amends the guidance in ASC 326 on the accounting for certain purchased loans. ASU No. 2025-08 is effective for fiscal years beginning after December 15, 2026, with early adoption permitted. We plan to adopt ASU No. 2025-08 in the first quarter of fiscal year 2028. We are currently evaluating the impact of this ASU on our financial statements and disclosures.

[0001628280-26-005129:notes:47]
In September 2025, the FASB issued ASU No. 2025-07, Derivatives and Hedging (Topic 815) and Revenue from Contracts with Customers (Topic 606), which refines the scope of the guidance on derivatives in ASC 815 and clarifies the guidance on share-based payments from a customer in ASC 606. ASU No. 2025-07 is effective for fiscal years beginning after December 15, 2026, with early adoption permitted. We plan to adopt ASU No. 2025-07 in the first quarter of fiscal year 2028. We are currently evaluating the impact of this ASU on our financial statements and disclosures.

[0001628280-26-005129:notes:48]
In September 2025, the FASB issued ASU No. 2025-06, Intangibles—Goodwill and Other—Internal-Use Software (Sub-topic 350-40), Targeted Improvements to the Accounting for Internal-Use Software, which amends certain aspects of the accounting for and disclosure of software costs under ASC 350-40. The amendments also supersede the guidance on Web site development costs in ASC 350-50 and relocate that guidance, along with the recognition requirements for development costs specific to Web sites, to ASC 350-40. ASU No. 2025-06 is effective for fiscal years beginning after December 15, 2027, with early adoption permitted. We plan to adopt ASU No. 2025-06 in the first quarter of fiscal year 2029. We are currently evaluating the impact of this ASU on our financial statements and disclosures.

[0001628280-26-005129:notes:49]
In July 2025, the FASB issued ASU No. 2025-05, Financial Instruments - Credit Losses (Topic 326), Measurement of Credit Losses for Accounts Receivable and Contract Assets, which amends ASC 326-20 to provide a practical expedient for all entities, related to the estimation of expected credit losses for current accounts receivable and current contract assets that arise from transactions accounted for under ASC 606. ASU No. 2025-05 is effective for fiscal years beginning after December 15, 2025, with early adoption permitted. We plan to adopt ASU No. 2025-05 in the first quarter of fiscal year 2027. We are currently evaluating the impact of this ASU on our financial statements and disclosures.

[0001628280-26-005129:notes:50]
In May 2025, the FASB issued ASU No. 2025-04, Compensation - Stock Compensation (Topic 718) and Revenue from Contracts with Customers (Topic 606), which is intended to reduce diversity in practice and improve existing guidance, primarily by revising the definition of a “performance condition” and eliminating forfeiture policy election for service conditions associated with share-based consideration payable to a customer. In addition, ASU No. 2025-04 clarifies that the guidance in ASC 606 on the variable consideration constraints does not apply to share-based consideration payable to a customer regardless of whether an award’s grant date has occurred (as determined under ASC 718). ASU No. 2025-04 is effective for fiscal years beginning after December 15, 2026, with early adoption permitted. We plan to adopt ASU No. 2025-04 in the first quarter of fiscal year 2028. We are currently evaluating the impact of this ASU on our financial statements and disclosures.

[0001628280-26-005129:notes:51]
In May 2025, the FASB issued ASU No. 2025-03, Business Combinations (Topic 805) and Consolidation (Topic 810), which revises the guidance in ASC 805 to clarify that, in determining the accounting acquirer in a business combination that is effected primarily by exchanging equity interests in which a VIE is acquired, an entity would be required to consider the factors in ASC 805-10-55-12 through 55-15. Previously, the accounting acquirer in such transactions was always the primarily beneficiary. ASU No. 2025-03 is effective for fiscal years beginning after December 15, 2026, with early adoption permitted. We plan to adopt ASU No. 2025-04 in the first quarter of fiscal year 2028. We are currently evaluating the impact of this ASU on our financial statements and disclosures.

[0001628280-26-005129:notes:52]
In November 2024, the FASB issued ASU No. 2024-03, Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40), which requires disaggregation of certain expense captions into specified categories in disclosures within the footnotes to the financial statements. In January 2025, the FASB issued ASU No. 2025-01, which revises the effective date of ASU No. 2024-03, to clarify that all public business entities are required to adopt the guidance in annual reporting periods beginning after December 15, 2026, and interim periods within annual reporting periods beginning after December 15, 2027, with early adoption permitted. We plan to adopt ASU No. 2024-04 in the first quarter of fiscal year 2028. We are currently evaluating the impact of this ASU on our financial statements and disclosures.


## us-gaap:EarningsPerShareTextBlock

[0001628280-26-005129:notes:53]
[same as prior period, unchanged from 0001628280-25-049073:notes:39]

[0001628280-26-005129:notes:54]
[same as prior period, unchanged from 0001628280-25-049073:notes:40]

[0001628280-26-005129:notes:55]
|  | Three Months Ended |  | Six Months Ended |
|  | December 27, 2025 |  | December 28, 2024 |  | December 27, 2025 |  | December 28, 2024 |
| Numerator: |  |  |  |  |  |  |  |
| Net income (loss) - basic and diluted | $ | 78.2 |  |  | $ | (60.9) |  |  | $ | 82.4 |  |  | $ | (143.3) |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average common shares outstanding - basic | 71.1 |  |  | 68.9 |  |  | 70.7 |  |  | 68.6 |  |
| Effect of dilutive securities from ESPP | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |
| Effect of dilutive securities from stock options | 0.3 |  |  | — |  |  | 0.4 |  |  | — |  |
| Effect of dilutive securities from RSUs and PSUs | 2.5 |  |  | — |  |  | 2.1 |  |  | — |  |
| Shares issuable assuming conversion of the convertible notes | 13.8 |  |  | — |  |  | 9.8 |  |  | — |  |
| Weighted average common shares outstanding - diluted | 87.8 |  |  | 68.9 |  |  | 83.1 |  |  | 68.6 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | 1.10 |  |  | $ | (0.88) |  |  | $ | 1.17 |  |  | $ | (2.09) |  |
| Diluted | $ | 0.89 |  |  | $ | (0.88) |  |  | $ | 0.99 |  |  | $ | (2.09) |  |

[0001628280-26-005129:notes:56]
[same as prior period, unchanged from 0001628280-25-049073:notes:42]

[0001628280-26-005129:notes:57]
Potentially dilutive common shares issuable upon conversion of our outstanding convertible notes are determined using the if-converted method. Under each series of Notes, we are required to satisfy our conversion obligation with respect to converted Notes by paying cash equal to the principal amount of such converted Notes and paying or delivering, as the case may be, cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof. Refer to “Note 9. Debt” for more details.

[0001628280-26-005129:notes:58]
Our outstanding capped call options are anti-dilutive under GAAP as they are specifically designed to mitigate the dilutive impact of the 2032 Notes, such that no dilution will occur until the capped call price is exceeded. Refer to “Note 9. Debt” for more details. There were no other material anti-dilutive shares excluded from the calculation of diluted net income per share during the three and six months ended December 27, 2025.

[0001628280-26-005129:notes:59]
Average anti-dilutive shares excluded from the calculation of diluted net loss per share for the three months ended December 28, 2024 include 4.4 million shares issuable under restricted stock units (“RSUs”) and performance stock units (“PSUs”), 0.1 million shares issuable under the Employee Stock Purchase Plan (the “ESPP”), and 0.8 million shares outstanding related to stock options. Average anti-dilutive shares excluded from the calculation of diluted net loss per share for the six months ended December 28, 2024 include 0.5 million shares related to convertible notes, 4.6 million shares issuable under RSUs and PSUs, 0.1 million shares issuable under the ESPP, and 0.9 million shares outstanding related to stock options. Refer to “Note 13. Equity.”


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001628280-26-005129:notes:60]
Note 4. Business Combinations

[0001628280-26-005129:notes:61]
Cloud Light Acquisition
On November 7, 2023, we completed the acquisition of Cloud Light Technology Limited (“Cloud Light”). In accordance with a definitive merger agreement, dated as of October 29, 2023, between the Company and Cloud Light, cash consideration included $75.8 million of cash held in an escrow fund to support Cloud Light’s indemnification obligations and customary adjustment for working capital. In November 2025, the Company and the former shareholders of Cloud Light mutually agreed to settle outstanding indemnification claims for $27.5 million and signed a settlement agreement releasing the balance of the escrow fund to the former Cloud Light shareholders and releasing them of their indemnification obligations. Since the measurement period expired, we recorded the settlement amount of $27.5 million as other income, net in our condensed consolidated statements of operations during the three and six months ended December 27, 2025.


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001628280-26-005129:notes:62]
Note 5. Cash, Cash Equivalents and Short-term Investments

[0001628280-26-005129:notes:63]
[same as prior period, unchanged from 0001628280-25-049073:notes:46]

[0001628280-26-005129:notes:64]
|  | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| December 27, 2025: |  |  |  |  |  |  |  |
| Cash | $ | 460.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 460.1 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | 31.3 |  |  | — |  |  | — |  |  | 31.3 |  |
| Money market funds | 74.6 |  |  | — |  |  | — |  |  | 74.6 |  |
| U.S. Treasury securities | 91.7 |  |  | — |  |  | — |  |  | 91.7 |  |
| Total cash and cash equivalents | $ | 657.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 657.7 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Commercial paper | 24.6 |  |  | — |  |  | — |  |  | 24.6 |  |
| Corporate debt securities | 275.3 |  |  | 0.8 |  |  | (0.1) |  |  | 276.0 |  |
| U.S. Agency securities | 137.0 |  |  | 0.2 |  |  | — |  |  | 137.2 |  |
| U.S. Treasury securities | 59.6 |  |  | 0.2 |  |  | — |  |  | 59.8 |  |
| Total short-term investments | $ | 496.5 |  |  | $ | 1.2 |  |  | $ | (0.1) |  |  | $ | 497.6 |  |
| June 28, 2025: |  |  |  |  |  |  |  |
| Cash | $ | 349.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 349.5 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 2.5 |  |  | — |  |  | — |  |  | 2.5 |  |
| Money market funds | 161.7 |  |  | — |  |  | — |  |  | 161.7 |  |
| U.S. Treasury securities | 7.0 |  |  | — |  |  | — |  |  | 7.0 |  |
| Total cash and cash equivalents | $ | 520.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 520.7 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Commercial paper | $ | 2.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 2.7 |  |
| Corporate debt securities | 210.9 |  |  | 0.3 |  |  | (0.1) |  |  | 211.1 |  |
| U.S. Agency securities | 67.6 |  |  | 0.1 |  |  | — |  |  | 67.7 |  |
| U.S. Treasury securities | 74.8 |  |  | 0.1 |  |  | — |  |  | 74.9 |  |
| Total short-term investments | $ | 356.0 |  |  | $ | 0.5 |  |  | $ | (0.1) |  |  | $ | 356.4 |  |

[0001628280-26-005129:notes:65]
We review our investment portfolio to identify and evaluate investments that have indicators of possible impairment. Factors considered in determining whether a loss is other-than-temporary include, but are not limited to, the length of time and extent a security’s fair value has been below its cost, the financial condition and near-term prospects of the investee, the credit quality of the security’s issuer, likelihood of recovery and our intent and ability to hold the security for a period sufficient to allow for any anticipated recovery in value. For the debt instruments we own, we also evaluate whether we have the intent to sell the security or whether it is more likely than not that we will be required to sell the security before recovery of its cost basis. We have not recorded our unrealized losses on our short-term investments into our results of operations because we do not intend to sell nor is it more likely than not that we will be required to sell these investments prior to recovery of their amortized cost basis.

[0001628280-26-005129:notes:66]
We use the specific-identification method to determine any realized gains or losses from the sale of our short-term investments classified as available-for-sale. During the three and six months ended December 27, 2025, we did not realize significant gains or losses on a gross level from the sale of our short-term investments classified as available-for-sale.

[0001628280-26-005129:notes:67]
During the three and six months ended December 27, 2025, our other income, net was $11.0 million and $15.2 million, respectively, which includes interest and investment income on cash equivalents and short-term investments of $11.6 million and $20.2 million, respectively.

[0001628280-26-005129:notes:68]
During the three and six months ended December 28, 2024, our other income, net was $14.9 million and $23.6 million, respectively, which includes interest and investment income on cash equivalents and short-term investments of $9.0 million and $18.4 million, respectively.

[0001628280-26-005129:notes:69]
As of December 27, 2025 and June 28, 2025, we recorded interest receivables of $6.3 million and $5.2 million, respectively, included in prepayments and other current assets within the condensed consolidated balance sheets. We did not recognize an allowance for credit losses against interest receivables in any of the periods presented.

[0001628280-26-005129:notes:70]
[same as prior period, unchanged from 0001628280-25-049073:notes:52]

[0001628280-26-005129:notes:71]
|  | Continuous Loss Position for More Than 12 Months |  | Continuous Loss Position for Less Than 12 Months |  | Gross Unrealized Losses |  |  |  |  |  |  |  |  |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |  |
| December 27, 2025: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | — |  |  | $ | — |  |  | $ | 68.4 |  |  | $ | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 9.9 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 1.0 |  |  | — |  |  | 69.2 |  |  | (0.1) |  |  | (0.1) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | — |  |  | — |  |  | 3.5 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | 1.0 |  |  | $ | — |  |  | $ | 151.0 |  |  | $ | (0.1) |  |  | $ | (0.1) |  |  |  |  |  |  |  |  |  |
| June 28, 2025: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | — |  |  | $ | — |  |  | $ | 24.5 |  |  | $ | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 5.2 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | — |  |  | — |  |  | 73.8 |  |  | (0.1) |  |  | (0.1) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | — |  |  | — |  |  | 35.3 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | — |  |  | $ | — |  |  | $ | 138.8 |  |  | $ | (0.1) |  |  | $ | (0.1) |  |  |  |  |  |  |  |  |  |

[0001628280-26-005129:notes:72]
[same as prior period, unchanged from 0001628280-25-049073:notes:54]

[0001628280-26-005129:notes:73]
|  | December 27, 2025 |  | June 28, 2025 |
|  | Amortized Cost |  | Fair Value |  | Amortized Cost |  | Fair Value |
| Due within 1 year | $ | 171.7 |  |  | $ | 171.9 |  |  | $ | 139.9 |  |  | $ | 140.0 |  |
| Due in 1 year to 5 years | 324.8 |  |  | 325.7 |  |  | 216.1 |  |  | 216.4 |  |
| Total | $ | 496.5 |  |  | $ | 497.6 |  |  | $ | 356.0 |  |  | $ | 356.4 |  |

[0001628280-26-005129:notes:74]
[same as prior period, unchanged from 0001628280-25-049073:notes:56]


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-26-005129:notes:75]
Note 6. Fair Value Measurements

[0001628280-26-005129:notes:76]
[same as prior period, unchanged from 0001628280-25-049073:notes:58]

[0001628280-26-005129:notes:77]
[same as prior period, unchanged from 0001628280-25-049073:notes:59]

[0001628280-26-005129:notes:78]
[same as prior period, unchanged from 0001628280-25-049073:notes:60]

[0001628280-26-005129:notes:79]
[same as prior period, unchanged from 0001628280-25-049073:notes:61]

[0001628280-26-005129:notes:80]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| December 27, 2025: (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 31.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 31.3 |  |
| Money market funds | 74.6 |  |  | — |  |  | — |  |  | 74.6 |  |
| U.S. Treasury securities | 91.7 |  |  | — |  |  | — |  |  | 91.7 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | 24.6 |  |  | — |  |  | 24.6 |  |
| Corporate debt securities | — |  |  | 276.0 |  |  | — |  |  | 276.0 |  |
| U.S. Agency securities | — |  |  | 137.2 |  |  | — |  |  | 137.2 |  |
| U.S. Treasury securities | 59.8 |  |  | — |  |  | — |  |  | 59.8 |  |
| Total assets | $ | 257.4 |  |  | $ | 437.8 |  |  | $ | — |  |  | $ | 695.2 |  |

[0001628280-26-005129:notes:81]
(1)  Excludes $460.1 million in cash held in our bank accounts as of December 27, 2025.

[0001628280-26-005129:notes:82]
[same as prior period, unchanged from 0001628280-25-049073:notes:64]

[0001628280-26-005129:notes:83]
[same as prior period, unchanged from 0001628280-25-049073:notes:65]

[0001628280-26-005129:notes:84]
[same as prior period, unchanged from 0001628280-25-049073:notes:66]

[0001628280-26-005129:notes:85]
We report our financial instruments at fair value with the exception of our convertible notes, refer to “Note 9. Debt”. The estimated fair value of the convertible notes was determined based on the trading price of the convertible notes as of the last day of trading for the period. We consider the fair value of the convertible notes to be a Level 2 measurement as they are not actively traded in markets.

[0001628280-26-005129:notes:86]
As of December 27, 2025, the fair value of our Japan term loans in aggregate is lower than the carrying value by approximately $1.2 million.

[0001628280-26-005129:notes:87]
[same as prior period, unchanged from 0001628280-25-049073:notes:71]

[0001628280-26-005129:notes:88]
[same as prior period, unchanged from 0001628280-25-049073:notes:72]

[0001628280-26-005129:notes:89]
Management utilizes various valuation methods, including an income approach, a market approach and a cost approach, to estimate the fair value of intangibles and other long-lived assets. During the annual impairment testing performed in the fourth quarter of fiscal year 2025, we concluded that there was no impairment of our intangible and other long-lived assets. We review our intangible and other long-lived assets for impairment at least annually in the fourth quarter of each fiscal year, absent any interim indicators of impairment. During the three and six months ended December 27, 2025, we recorded an $11.7 million impairment charge to write-down certain assets held for sale to fair value less cost to sell in our condensed consolidated statements of operations. There were no other indicators of impairment during the three and six months ended December 27, 2025.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-26-005129:notes:90]
Note 7. Balance Sheet Details

[0001628280-26-005129:notes:91]
[same as prior period, unchanged from 0001628280-25-049073:notes:75]

[0001628280-26-005129:notes:92]
We did not have any allowance for credit losses other than our allowance for uncollectible accounts receivable. As of December 27, 2025 and June 28, 2025, the allowance for credit losses on our trade receivables was $3.4 million and $3.5 million, respectively.

[0001628280-26-005129:notes:93]
[same as prior period, unchanged from 0001628280-25-049073:notes:77]

[0001628280-26-005129:notes:94]
[same as prior period, unchanged from 0001628280-25-049073:notes:78]

[0001628280-26-005129:notes:95]
|  | December 27, 2025 |  | June 28, 2025 |
| Raw materials and purchased parts | $ | 263.6 |  |  | $ | 253.2 |  |
| Work in process | 211.4 |  |  | 159.1 |  |
| Finished goods | 95.4 |  |  | 57.8 |  |
| Inventories | $ | 570.4 |  |  | $ | 470.1 |  |

[0001628280-26-005129:notes:96]
[same as prior period, unchanged from 0001628280-25-049073:notes:80]

[0001628280-26-005129:notes:97]
[same as prior period, unchanged from 0001628280-25-049073:notes:81]

[0001628280-26-005129:notes:98]
|  | December 27, 2025 |  | June 28, 2025 |
| Land | $ | 90.1 |  |  | $ | 108.6 |  |
| Buildings and improvements | 267.6 |  |  | 270.4 |  |
| Machinery and equipment | 975.4 |  |  | 848.8 |  |
| Computer equipment and software | 42.2 |  |  | 39.1 |  |
| Furniture and fixtures | 12.8 |  |  | 14.7 |  |
| Leasehold improvements | 46.6 |  |  | 45.9 |  |
| Construction in progress | 180.8 |  |  | 152.3 |  |
|  | 1,615.5 |  |  | 1,479.8 |  |
| Less: Accumulated depreciation | (802.0) |  |  | (753.4) |  |
| Property, plant and equipment, net | $ | 813.5 |  |  | $ | 726.4 |  |

[0001628280-26-005129:notes:99]
[same as prior period, unchanged from 0001628280-25-049073:notes:83]

[0001628280-26-005129:notes:100]
In January 2026, the Company entered into a definitive Purchase and Sale Agreement to sell two commercial real estate properties located in San Jose, California. The properties consist of commercial buildings used by the Company for office, research and development and manufacturing support activities. The agreement provides for a cash purchase price of $43.0 million, subject to customary closing conditions, and includes a short-term rental arrangement under which the Company will continue to occupy the properties through July 1, 2026, with the ability to surrender portions thereof earlier without penalty.

[0001628280-26-005129:notes:101]
The net book value of the assets was $49.1 million, and the total estimated costs to sell were $1.4 million. As of December 27, 2025, the assets met the criteria to be classified as assets held for sale. Accordingly, the assets have been reclassified to assets held for sale, which are included in prepayments and other current assets in our condensed consolidated balance sheets. Based on the agreed purchase price and estimated selling costs, the Company determined that the carrying value exceeded the fair value less costs to sell and recorded an impairment charge of $7.5 million, which is included in the selling, general and administrative expenses in our condensed consolidated statements of operations during the three and six months ended December 27, 2025.

[0001628280-26-005129:notes:102]
The Company expects the transactions to close in the remainder of fiscal year 2026, subject to the satisfaction of customary closing conditions. Upon completion of the sale, the Company will derecognize the assets and record the final loss on sale, which may differ from the amounts currently estimated due to changes in closing costs or other adjustments.

[0001628280-26-005129:notes:103]
[same as prior period, unchanged from 0001628280-25-049073:notes:84]

[0001628280-26-005129:notes:104]
[same as prior period, unchanged from 0001628280-25-049073:notes:85]

[0001628280-26-005129:notes:105]
In addition, in connection with the sale of our Brazilian entities, we recorded a gain on sale of approximately $1.6 million recorded in selling, general and administrative expenses in our condensed consolidated statements of operations during the six months ended December 27, 2025.

[0001628280-26-005129:notes:106]
During the three and six months ended December 27, 2025, we recorded depreciation expense of $30.6 million and $58.4 million, respectively.

[0001628280-26-005129:notes:107]
[same as prior period, unchanged from 0001628280-25-049073:notes:88]

[0001628280-26-005129:notes:108]
[same as prior period, unchanged from 0001628280-25-049073:notes:89]

[0001628280-26-005129:notes:109]
|  | December 27, 2025 |  | June 28, 2025 |
| Operating lease right-of-use assets | $ | 58.7 |  |  | $ | 54.4 |  |
| Less: accumulated amortization | (29.1) |  |  | (26.5) |  |
| Operating lease right-of-use assets, net | $ | 29.6 |  |  | $ | 27.9 |  |

[0001628280-26-005129:notes:110]
[same as prior period, unchanged from 0001628280-25-049073:notes:91]

[0001628280-26-005129:notes:111]
[same as prior period, unchanged from 0001628280-25-049073:notes:92]

[0001628280-26-005129:notes:112]
[same as prior period, unchanged from 0001628280-25-049073:notes:93]

[0001628280-26-005129:notes:113]
|  | December 27, 2025 |  | June 28, 2025 |
| Restructuring accrual and related charges (1) | $ | 2.2 |  |  | $ | 2.5 |  |
| Warranty reserve (2) | 22.7 |  |  | 14.4 |  |
| Deferred revenue and customer deposits | 2.1 |  |  | 0.7 |  |
| Income tax payable (3) | 12.2 |  |  | 29.1 |  |
| Other current liabilities | 3.6 |  |  | 6.4 |  |
| Other current liabilities | $ | 42.8 |  |  | $ | 53.1 |  |

[0001628280-26-005129:notes:114]
(1) Refer to “Note 11. Restructuring and Related Charges (Reversals).”

[0001628280-26-005129:notes:115]
(2) Refer to “Note 14. Commitments and Contingencies.”

[0001628280-26-005129:notes:116]
(3) Refer to “Note 12. Income Taxes.”

[0001628280-26-005129:notes:117]
[same as prior period, unchanged from 0001628280-25-049073:notes:98]

[0001628280-26-005129:notes:118]
[same as prior period, unchanged from 0001628280-25-049073:notes:99]

[0001628280-26-005129:notes:119]
|  | December 27, 2025 |  | June 28, 2025 |
| Asset retirement obligations | $ | 7.1 |  |  | $ | 7.1 |  |
| Pension and related accruals (1) | 11.2 |  |  | 9.7 |  |
| Unrecognized tax benefit (2) | 60.4 |  |  | 55.6 |  |
| Other non-current liabilities (2) | 37.0 |  |  | 25.4 |  |
| Other non-current liabilities | $ | 115.7 |  |  | $ | 97.8 |  |

[0001628280-26-005129:notes:120]
(1) We have defined benefit pension plans in Japan, Switzerland, and Thailand. Pension and related accrual of $11.2 million as of December 27, 2025 represents $11.9 million of non-current portion of benefit obligation, offset by $0.7 million of funding for the pension plan in Switzerland. Pension and related accrual of $9.7 million as of June 28, 2025 relates to $11.0 million of non-current portion of benefit obligation, offset by $1.3 million of funding for the pension plan in Switzerland. We typically re-evaluate the assumptions related to the fair value of our defined benefit obligations annually in the fiscal fourth quarter and make any updates as necessary. During the three and six months ended December 27, 2025, our contribution expense to the 401(k) Plan in the United States was $0.4 million and $1.1 million, respectively. During the three and six months ended December 28, 2024, our contribution expense to the 401(k) Plan in the United States was $0.4 million and $1.2 million, respectively. Our contribution expense to all defined contribution plans outside the United States was $2.5 million and $5.2 million during the three and six months ended December 27, 2025, respectively. Our contribution expense to all defined contribution plans outside the United States were $2.0 million and $3.8 million during the three and six months ended December 28, 2024, respectively.
 (2) The Company has reclassified a $21.4 million unrecognized tax position to other non-current liabilities in the condensed consolidated balance sheets as of the year ended June 28, 2025 for an indemnification liability related to the sale of certain assets. This does not impact our results of operations for the year ended June 28, 2025.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001628280-26-005129:notes:121]
Note 8. Goodwill and Other Intangible Assets

[0001628280-26-005129:notes:122]
[same as prior period, unchanged from 0001628280-25-049073:notes:103]

[0001628280-26-005129:notes:123]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. In the fourth quarter of fiscal year 2025, we completed the annual impairment test of goodwill, which indicated there was no goodwill impairment. There were no indicators of goodwill impairment during the three and six months ended December 27, 2025.

[0001628280-26-005129:notes:124]
[same as prior period, unchanged from 0001628280-25-049073:notes:105]

[0001628280-26-005129:notes:125]
[same as prior period, unchanged from 0001628280-25-049073:notes:106]

[0001628280-26-005129:notes:126]
[same as prior period, unchanged from 0001628280-25-049073:notes:107]

[0001628280-26-005129:notes:127]
During the annual impairment testing performed in the fourth quarter of fiscal year 2025, we concluded that our intangible and other long-lived assets were not impaired at the asset group level. We review our intangible and other long-lived assets for impairment at least annually in the fourth quarter of each fiscal year, absent any interim indicators of impairment. There were no indicators of impairment at the asset group level during the three and six months ended December 27, 2025.

[0001628280-26-005129:notes:128]
[same as prior period, unchanged from 0001628280-25-049073:notes:109]

[0001628280-26-005129:notes:129]
| December 27, 2025 | Gross Carrying Amounts |  | Accumulated Amortization |  | Net Carrying Amounts |  | Weighted Average Remaining Amortization Period (Years) |
| Acquired developed technologies | $ | 828.4 |  |  | $ | (599.3) |  |  | $ | 229.1 |  |  | 3.8 |
| Customer relationships | 419.5 |  |  | (254.4) |  |  | 165.1 |  |  | 3.7 |
| In-process research and development | 2.5 |  |  | — |  |  | 2.5 |  |  | n/a |
| Order backlog | 14.0 |  |  | (14.0) |  |  | — |  |  | — |
| Trade name and trademarks | 3.0 |  |  | (3.0) |  |  | — |  |  | — |
| Total intangible assets | $ | 1,267.4 |  |  | $ | (870.7) |  |  | $ | 396.7 |  |  |  |

[0001628280-26-005129:notes:130]
[same as prior period, unchanged from 0001628280-25-049073:notes:111]

[0001628280-26-005129:notes:131]
[same as prior period, unchanged from 0001628280-25-049073:notes:112]

[0001628280-26-005129:notes:132]
|  | Three Months Ended |  | Six Months Ended |
|  | December 27, 2025 |  | December 28, 2024 |  | December 27, 2025 |  | December 28, 2024 |
| Cost of sales | $ | 19.6 |  |  | $ | 21.4 |  |  | $ | 39.1 |  |  | $ | 43.9 |  |
| Research and development | 0.4 |  |  | 0.4 |  |  | 0.8 |  |  | 0.8 |  |
| Selling, general and administrative | 14.0 |  |  | 17.2 |  |  | 28.5 |  |  | 36.0 |  |
| Total amortization of intangibles | $ | 34.0 |  |  | $ | 39.0 |  |  | $ | 68.4 |  |  | $ | 80.7 |  |

[0001628280-26-005129:notes:133]
Based on the carrying amount of our acquired intangible assets except in-process research and development as of December 27, 2025, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001628280-26-005129:notes:134]
| Fiscal Years |  |
| Remainder of 2026 | $ | 67.3 |  |
| 2027 | 123.6 |  |
| 2028 | 83.0 |  |
| 2029 | 52.6 |  |
| 2030 | 46.5 |  |
| Thereafter | 21.2 |  |
| Total future amortization | $ | 394.2 |  |


## us-gaap:DebtDisclosureTextBlock

[0001628280-26-005129:notes:135]
Note 9. Debt

[0001628280-26-005129:notes:136]
Our debt consists of the following:

[0001628280-26-005129:notes:137]
|  | December 27, 2025 |  | June 28, 2025 |
|  | Short-term |  | Long-term |  | Total |  | Short-term |  | Long-term |  | Total |
| Convertible notes (1) | $ | 3,182.5 |  |  | $ | — |  |  | $ | 3,182.5 |  |  | $ | — |  |  | $ | 2,506.2 |  |  | $ | 2,506.2 |  |
| Term loans | 57.7 |  |  | 47.1 |  |  | 104.8 |  |  | 10.6 |  |  | 56.4 |  |  | 67.0 |  |
| Total | $ | 3,240.2 |  |  | $ | 47.1 |  |  | $ | 3,287.3 |  |  | $ | 10.6 |  |  | $ | 2,562.6 |  |  | $ | 2,573.2 |  |

[0001628280-26-005129:notes:138]
(1) Since the closing price of our stock was at least 130% of the applicable conversion price for each series of Notes for 20 of the last 30 trading days of our second quarter of fiscal year 2026, all of our Notes became convertible at the option of the holders during the third quarter of fiscal year 2026. The outstanding Notes are recorded as short-term debt, which is presented as current liabilities in our condensed consolidated balance sheets as of December 27, 2025, net of unamortized debt issuance costs. If the Notes are converted by holders, we are required to satisfy our conversion obligations with respect to each series of converted Notes by paying cash equal to the principal amount of such series of converted Notes and paying or delivering, as the case may be, cash, shares of common stock, or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof. The outstanding Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of June 28, 2025, net of unamortized debt issuance costs.

[0001628280-26-005129:notes:139]
Convertible Notes

[0001628280-26-005129:notes:140]
2032 Notes

[0001628280-26-005129:notes:141]
On September 8, 2025, we issued $1,265.0 million in aggregate principal amount of 0.375% Convertible Senior Notes due in 2032 (“2032 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2032 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association, as trustee (the “2032 Indenture”). The 2032 Notes are unsecured, rank equally with all of the Company’s existing senior unsecured indebtedness, including the Company’s outstanding 0.50% Convertible Senior Notes due 2026, 0.50% Convertible Senior Notes due 2028, and 1.50% Convertible Senior Notes due 2029, and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-26-005129:notes:142]
The net proceeds from the sale of the 2032 Notes was approximately $1,254.7 million, after deducting $10.3 million of debt issuance costs. Concurrent with the issuance of the 2032 Notes, we used $843.1 million of the net proceeds to repurchase $581.1 million aggregate principal amount of the 0.50% Convertible Senior Notes due in 2026 and $102.0 million of the net proceeds to pay the cost of the 2032 Capped Call Options. We intend to use the remaining net proceeds for general corporate purposes, which may include the repayment or repurchase of our indebtedness, including any of our existing convertible notes, capital expenditures, working capital and potential acquisitions.

[0001628280-26-005129:notes:143]
The 2032 Notes bear interest at a rate of 0.375% per year, payable semi-annually in arrears on March 15 and September 15 of each year, beginning on March 15, 2026. The 2032 Notes will mature on March 15, 2032, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-26-005129:notes:144]
The initial conversion rate is 5.3257 shares of common stock per $1,000 principal amount of the 2032 Notes (which is equivalent to an initial conversion price of approximately $187.77 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2032 Indenture but will not be adjusted for any accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2032 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2032 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-26-005129:notes:145]
Prior to the close of business on the business day immediately preceding December 15, 2031, holders of the 2032 Notes may convert their 2032 Notes only under the following circumstances:

[0001628280-26-005129:notes:146]
•during any fiscal quarter commencing after December 27, 2025 (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price of the 2032 Notes, or $244.10, on each applicable trading day;

[0001628280-26-005129:notes:147]
•during the five consecutive business day period after any five consecutive trading day period (the “2032 measurement period”) in which the trading price per $1,000 principal amount of 2032 Notes for each trading day of the 2032 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day;

[0001628280-26-005129:notes:148]
•if we call any or all of the 2032 Notes for redemption, at any time prior to the close of business on the second scheduled trading day immediately preceding the redemption date; or

[0001628280-26-005129:notes:149]
•upon the occurrence of specified corporate events as specified in the 2032 Indenture.

[0001628280-26-005129:notes:150]
On or after December 15, 2031 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2032 Notes at any time. Upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2032 Notes by paying cash equal to the principal amount of such converted 2032 Notes and paying or delivering, as the case may be, cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof, if any.

[0001628280-26-005129:notes:151]
We may redeem for cash all or any portion of the 2032 Notes, at our option (subject to the partial redemption limitation set forth in the 2032 Indenture), on or after March 20, 2029, if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide notice of redemption at a redemption price equal to 100% of the principal amount of the 2032 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2032 Notes. If we elect to redeem fewer than all of the outstanding 2032 Notes, at least $100.0 million aggregate principal amount of the 2032 Notes must be outstanding and not subject to redemption as of the redemption notice date. Upon the occurrence of a fundamental change (as defined in the 2032 Indenture), holders may require us to repurchase all or a portion of their 2032 Notes for cash at a price equal to 100% of the principal amount of the 2032 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-26-005129:notes:152]
Since the closing price of our stock exceeded $244.10 (or 130% of the conversion price of $187.77) for 20 of the last 30 trading days of our second quarter of fiscal year 2026, our 2032 Notes became convertible at the option of the holders during the third quarter of fiscal year 2026. Upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2032 Notes by paying cash equal to the principal amount of such converted 2032 Notes and paying or delivering, as the case may be, cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof, if any. Therefore, the entire aggregate principal amount of the 2032 Notes outstanding is recorded as short-term debt, which is presented as a current liability in our consolidated balance sheets as of December 27, 2025, net of unamortized debt issuance costs.

[0001628280-26-005129:notes:153]
2032 Capped Call Options

[0001628280-26-005129:notes:154]
In September 2025, in connection with the issuances of the 2032 Notes, the Company entered into privately negotiated capped call transactions (the “2032 Capped Call Options”) with certain financial institutions (the “2032 Capped Call Counterparties”). The 2032 Capped Call Options cover, subject to anti-dilution adjustments substantially similar to those applicable to the 2032 Notes, the number of shares of our common stock that initially underlie the 2032 Notes and are generally expected to reduce potential dilution to the Company’s common stock upon any conversion of 2032 Notes and/or offset any cash payments the Company would be required to make in excess of the principal amount of converted 2032 Notes, as the case may be, with such reduction and/or offset subject to a cap. The cap price of the 2032 Capped Call Options was initially $268.24 per share, and is subject to certain adjustments under the terms of the 2032 Capped Call Options. If the market price per share of our common stock, as measured under the terms of the 2032 Capped Call Options, exceeds the cap price of the 2032 Capped Call Options, there would be dilution and/or there would not be an offset of any potential cash payments in excess of the principal amount of converted 2032 Notes, in each case, to the extent that such market price exceeds the cap price of the 2032 Capped Call Options.

[0001628280-26-005129:notes:155]
Each of the 2032 Capped Call Options was executed pursuant to a separate agreement entered into by the Company and each of the 2032 Capped Call Counterparties. The 2032 Capped Call Options are not part of the terms of the 2032 Notes and will not affect any holder’s rights under the 2032 Notes. Holders of the 2032 Notes will not have any rights with respect to the 2032 Capped Call Options. The Company concluded that the 2032 Capped Call Options met the criteria for equity classification because they were indexed to the Company’s common stock and the Company has the discretion to settle the 2032 Capped Call Options by the Company receiving shares or cash subsequent to March 20, 2029. As a result, the $102.0 million amount paid was recorded as a reduction to additional paid-in capital within the Company’s condensed consolidated balance sheets as of December 27, 2025, along with the offsetting associated current tax impact of $1.1 million.

[0001628280-26-005129:notes:156]
The Company made a tax election to integrate the 2032 Notes and the 2032 Capped Call Options for federal income tax purposes pursuant to applicable U.S. Treasury Regulations. Accordingly, the $102.0 million gross cost of the purchased 2032 Capped Call Options will be deductible for income tax purposes as original issue discount interest over the term of the 2032 Notes. As a result, the Company established a deferred income tax asset of $24.5 million at inception, with a corresponding valuation allowance as it is not more-likely-than-not that our U.S. deferred tax assets are realizable in the future. As of December 27, 2025, we have recognized a current tax impact of $1.1 million at issuance, which is recorded as an increase to additional paid-in capital within the Company’s condensed consolidated balance sheets.

[0001628280-26-005129:notes:157]
2029 Notes

[0001628280-26-005129:notes:158]
On June 16, 2023, we issued $603.7 million in aggregate principal amount of 1.50% Convertible Senior Notes due in 2029 (“2029 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2029 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association, as trustee (the “2029 Indenture”). The 2029 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-26-005129:notes:159]
The 2029 Notes bear interest at a rate of 1.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year. The 2029 Notes will mature on December 15, 2029, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-26-005129:notes:160]
The initial conversion rate is 14.3808 shares of common stock per $1,000 principal amount of the 2029 Notes (which is equivalent to an initial conversion price of approximately $69.54 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2029 Indenture but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2029 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2029 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-26-005129:notes:161]
Prior to the close of business on the business day immediately preceding September 15, 2029, holders of the 2029 Notes may convert their 2029 Notes only under the following circumstances:

[0001628280-26-005129:notes:162]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price of the 2029 Notes, or $90.40, on each applicable trading day;

[0001628280-26-005129:notes:163]
•during the five consecutive business day period after any five consecutive trading day period (the “2029 measurement period”) in which the trading price per $1,000 principal amount of 2029 Notes for each trading day of the 2029 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day;

[0001628280-26-005129:notes:164]
•if we call any or all of the 2029 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the redemption date; or

[0001628280-26-005129:notes:165]
•upon the occurrence of specified corporate events as specified in the 2029 Indenture.

[0001628280-26-005129:notes:166]
On or after September 15, 2029 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2029 Notes at any time. Following our irrevocable settlement method election made on September 25, 2024, upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2029 Notes by delivering cash equal to the principal amount of such converted 2029 Notes and cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof.

[0001628280-26-005129:notes:167]
We may redeem for cash all or any portion of the 2029 Notes, at our option (subject to the partial redemption limitation set forth in the 2029 Indenture), on or after June 22, 2026, if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide notice of redemption at a redemption price equal to 100% of the principal amount of the 2029 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2029 Notes. If we elect to redeem fewer than all of the outstanding 2029 Notes, at least $100.0 million aggregate principal amount of the 2029 Notes must be outstanding and not subject to redemption as of the redemption notice date. Upon the occurrence of a fundamental change (as defined in the 2029 Indenture), holders may require us to repurchase all or a portion of their 2029 Notes for cash at a price equal to 100% of the principal amount of the 2029 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-26-005129:notes:168]
Since the closing price of our stock exceeded $90.40 (or 130% of the conversion price of $69.54) for 20 of the last 30 trading days of our first and second quarters of fiscal year 2026, our 2029 Notes became convertible at the option of the holders during the second and third quarters of fiscal year 2026. Following our irrevocable settlement method election made on September 25, 2024, upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2029 Notes by paying cash equal to the principal amount of such converted 2029 Notes and paying or delivering, as the case may be, cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof. Therefore, the entire aggregate principal amount of the 2029 Notes outstanding is recorded as short-term debt, which is presented as a current liability in our consolidated balance sheets as of December 27, 2025, net of unamortized debt issuance costs, while the entire aggregate principal amount of the 2029 Notes outstanding is recorded as convertible notes, non-current in our consolidated balance sheets as of June 28, 2025, net of unamortized debt issuance costs.

[0001628280-26-005129:notes:169]
2028 Notes

[0001628280-26-005129:notes:170]
In March 2022, we issued $861.0 million in aggregate principal amount of 0.50% Convertible Senior Notes due in 2028 (the “2028 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2028 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association, as trustee (the “2028 Indenture”). The 2028 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-26-005129:notes:171]
The 2028 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year. The 2028 Notes will mature on June 15, 2028, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-26-005129:notes:172]
The initial conversion rate is 7.6319 shares of common stock per $1,000 principal amount of the 2028 Notes (which is equivalent to an initial conversion price of approximately $131.03 per share). The conversion rate is subject to adjustment upon the occurrence of certain specified events, but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2028 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2028 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-26-005129:notes:173]
Prior to the close of business on the business day immediately preceding March 15, 2028, holders of the 2028 Notes may convert their 2028 Notes only under the following circumstances:

[0001628280-26-005129:notes:174]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price, or $170.34, on each applicable trading day;

[0001628280-26-005129:notes:175]
•during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the 2028 Notes for each trading day of such measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the applicable conversion rate on each such trading day;

[0001628280-26-005129:notes:176]
•if the Company calls any or all of the 2028 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the redemption date; or

[0001628280-26-005129:notes:177]
•upon the occurrence of specified corporate events, as specified in the 2028 Indenture.

[0001628280-26-005129:notes:178]
On or after March 15, 2028 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2028 Notes at any time. Following our irrevocable settlement method election made on September 25, 2024, upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2028 Notes by paying cash equal to the principal amount of such converted 2028 Notes and paying or delivering, as the case may be, cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof, if any.

[0001628280-26-005129:notes:179]
We may redeem for cash all or any portion of the 2028 Notes, at our option (subject to the partial redemption limitation set forth in the 2028 Indenture), on or after June 20, 2025, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the 2028 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2028 Notes. If we elect to redeem fewer than all of the outstanding 2028 Notes, at least $100.0 million aggregate principal amount of the 2028 Notes must be outstanding and not subject to redemption as of the redemption notice date. Upon the occurrence of a fundamental change (as defined in the 2028 Indenture), holders may require the Company to repurchase all or a portion of their 2028 Notes for cash at a price equal to 100% of the principal amount of the 2028 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-26-005129:notes:180]
We initially bifurcated the principal amount of the 2028 Notes into liability and equity components. The liability component of the 2028 Notes was initially valued at $629.8 million based on the contractual cash flow discounted at an appropriate comparable market on non-convertible debt borrowing rate at the date of issuance, which was 5.7%, with the equity component representing the residual amount of the proceeds of $231.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal year 2023, our 2028 Notes were accounted for as a single liability, net of unamortized debt issuance costs.

[0001628280-26-005129:notes:181]
Since the closing price of our stock exceeded $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of our second quarter of fiscal year 2026, our 2028 Notes became convertible at the option of the holders during the third quarter of fiscal year 2026. Following our irrevocable settlement method election made on September 25, 2024, upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2028 Notes by paying cash equal to the principal amount of such converted 2028 Notes and paying or delivering, as the case may be, cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof, if any. Therefore, the entire aggregate principal amount of the 2028 Notes outstanding is recorded as short-term debt, which is presented as a current liability in our consolidated balance sheets as of December 27, 2025, net of unamortized debt issuance costs, while the entire aggregate principal amount of the 2028 Notes outstanding is recorded as convertible notes, non-current in our consolidated balance sheets as of June 28, 2025, net of unamortized debt issuance costs.

[0001628280-26-005129:notes:182]
2026 Notes

[0001628280-26-005129:notes:183]
In December 2019, we issued $1,050.0 million in aggregate principal amount of 0.50% Convertible Senior Notes due in 2026 (the “2026 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2026 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association (as successor in interest to U.S. Bank National Association), as trustee (as supplemented by the First Supplemental Indenture, dated as of September 25, 2024, the “2026 Indenture”). The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-26-005129:notes:184]
The 2026 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year. The 2026 Notes will mature on December 15, 2026, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-26-005129:notes:185]
The initial conversion rate is 10.0711 shares of common stock per $1,000 principal amount of the 2026 Notes (which is equivalent to an initial conversion price of approximately $99.29 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2026 Indenture but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2026 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares set forth in the 2026 Indenture or a holder that elects to convert the 2026 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-26-005129:notes:186]
Prior to the close of business on the business day immediately preceding September 15, 2026, holders of the 2026 Notes may convert their 2026 Notes only under the following circumstances:

[0001628280-26-005129:notes:187]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price of the 2026 Notes, or $129.08 on each applicable trading day;

[0001628280-26-005129:notes:188]
•during the five consecutive business day period after any five consecutive trading day period (the “2026 measurement period”) in which the trading price per $1,000 principal amount of the 2026 Notes for each trading day of the 2026 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the 2026 Notes on each such trading day;

[0001628280-26-005129:notes:189]
•if we call any or all of the 2026 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the relevant redemption date; or

[0001628280-26-005129:notes:190]
•upon the occurrence of specified corporate events.

[0001628280-26-005129:notes:191]
On or after September 15, 2026 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2026 Notes at any time. Following our entry into the First Supplemental Indenture, dated as of September 25, 2024, to the 2026 Indenture, upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2026 Notes by paying cash equal to the principal amount of such converted 2026 Notes and paying or delivering, as the case may be, cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof, if any.

[0001628280-26-005129:notes:192]
We may redeem for cash, all or any portion of the 2026 Notes, at our option, on or after December 20, 2023, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide a notice of redemption at a redemption price equal to 100% of the principal amount of the 2026 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2026 Notes. Upon the occurrence of a fundamental change (as defined in the 2026 Indenture), holders may require us to repurchase all or a portion of the 2026 Notes for cash at a price equal to 100% of the principal amount of the 2026 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-26-005129:notes:193]
During the quarter ended December 27, 2025, we received conversion requests of $0.1 million of principal for the 2026 Notes, which we settled with a combination of $0.1 million of cash and an immaterial number of shares of our common stock in accordance with the 2026 Indenture.

[0001628280-26-005129:notes:194]
We initially bifurcated the principal amount of the 2026 Notes into liability and equity components. The liability component of the 2026 Notes was initially valued at $734.8 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 5.8% with the equity component representing the residual amount of the proceeds of $315.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal year 2023, our 2026 Notes were accounted for as a single liability, net of unamortized debt issuance costs.

[0001628280-26-005129:notes:195]
Concurrent with the issuance of the 2032 Notes, we used approximately $843.1 million of the net proceeds to repurchase $581.1 million aggregate principal amount of the 2026 Notes. We also paid $0.7 million of the related accrued interest. We have adopted and applied ASU 2024-04, Debt with Conversion and Other Options: Induced Conversions of Convertible Debt Instruments. We determined that this transaction met the requirements for the settlement of debt as an induced conversion. Accordingly, we recorded $256.9 million, which represents the fair value increase in the fair value of the debt, as a reduction to additional paid-in capital within the Company’s consolidated Balance Sheets as of December 27, 2025, and recognized an inducement expense of $5.9 million in our consolidated statements of operations during the three and six months ended December 27, 2025, which represents the excess of fair value of the total consideration over the fair value of securities issuable pursuant to the original conversion terms.

[0001628280-26-005129:notes:196]
Since the closing price of our stock exceeded $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of our first and second quarters of fiscal year 2026, our 2026 Notes became convertible at the option of the holders during the second and third quarters of fiscal year 2026. Following our entry into the First Supplemental Indenture, dated as of September 25, 2024, to the 2026 Indenture, upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2026 Notes by paying cash equal to the principal amount of such converted 2026 Notes and paying or delivering, as the case may be, cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof, if any. Therefore, the remaining 2026 Notes outstanding are recorded as short-term debt, which is presented as current liabilities in our consolidated balance sheets as of December 27, 2025, net of unamortized debt issuance costs. The entire aggregate amount of the 2026 Notes outstanding is recorded as convertible notes, non-current in our consolidated balance sheets as of June 28, 2025, net of unamortized debt issuance costs.

[0001628280-26-005129:notes:197]
The following table sets forth interest expense information related to the convertible notes for the periods presented (in millions):

[0001628280-26-005129:notes:198]
|  | Three Months Ended |  | Six Months Ended |
|  | December 27, 2025 |  | December 28, 2024 |  | December 27, 2025 |  | December 28, 2024 |
| Contractual interest expense | $ | 5.0 |  |  | $ | 4.6 |  |  | $ | 9.7 |  |  | $ | 9.3 |  |
| Amortization of debt issuance costs | 1.1 |  |  | 0.8 |  |  | 1.9 |  |  | 1.5 |  |
| Total interest expense | $ | 6.1 |  |  | $ | 5.4 |  |  | $ | 11.6 |  |  | $ | 10.8 |  |

[0001628280-26-005129:notes:199]
The future interest and principal payments related to our convertible notes are as follows as of December 27, 2025 (in millions):

[0001628280-26-005129:notes:200]
| Fiscal Years | 2026 Notes |  | 2028 Notes |  | 2029 Notes |  | 2032 Notes |  | Total |
| 2026 | $ | 1.2 |  |  | $ | 2.2 |  |  | $ | 4.5 |  |  | $ | 2.4 |  |  | $ | 10.3 |  |
| 2027 | 469.8 |  |  | 4.3 |  |  | 9.1 |  |  | 4.7 |  |  | 487.9 |  |
| 2028 | — |  |  | 865.3 |  |  | 9.1 |  |  | 4.7 |  |  | 879.1 |  |
| 2029 | — |  |  | — |  |  | 9.1 |  |  | 4.7 |  |  | 13.8 |  |
| 2030 | — |  |  | — |  |  | 608.1 |  |  | 4.7 |  |  | 612.8 |  |
| Thereafter | — |  |  | — |  |  | — |  |  | 1,274.7 |  |  | 1,274.7 |  |
| Total payments | $ | 471.0 |  |  | $ | 871.8 |  |  | $ | 639.9 |  |  | $ | 1,295.9 |  |  | $ | 3,278.6 |  |

[0001628280-26-005129:notes:201]
The principal balances of our convertible notes are reflected in the payment periods in the table above based on their respective contractual maturities.

[0001628280-26-005129:notes:202]
Term Loans

[0001628280-26-005129:notes:203]
SMBC Term Loan

[0001628280-26-005129:notes:204]
On August 9, 2024, the Company entered into a term loan agreement (the “SMBC 2029 Term Loan”) with Sumitomo Mitsui Banking Corporation (“SMBC”). The SMBC Term Loan provides an aggregate principal amount of 6.4 billion Japanese yen (“JPY”). The loan requires monthly principal payments of approximately 53.3 million JPY, from August 31, 2024 to June 30, 2029 and interest based on a fixed annual interest rate of 0.88%, with the remaining principal of approximately 3.3 billion JPY due on the loan maturity date of July 31, 2029. Under the loan agreement, the Company cannot prepay the outstanding loan without SMBC’s approval. In the event the Company prepays the outstanding loan with SMBC’s approval, the Company shall pay SMBC a settlement amount calculated pursuant to the terms of the loan agreement. The SMBC Term Loan is secured by the real estate owned in Sagamihara, Japan.

[0001628280-26-005129:notes:205]
On December 18, 2025, the Company entered into another term loan agreement (the “SMBC 2026 Term Loan”) with SMBC. The SMBC 2026 Term Loan provides an aggregate principal amount of 7.5 billion JPY. The loan requires monthly principal payments of 125.0 million JPY and interest based on a fixed annual interest rate of 1.44%, with the remaining principal of approximately 6.1 billion JPY due on the loan maturity date of December 19, 2026, subject to repayment pitch of 60 months. Under the loan agreement, the Company cannot prepay the outstanding loan without SMBC’s approval. In the event the Company prepays the outstanding loan with SMBC’s approval, the Company shall pay SMBC a settlement amount calculated pursuant to the terms of the loan agreement. The SMBC Term Loan is secured by the real estate owned in Sagamihara, Japan.

[0001628280-26-005129:notes:206]
The SMBC 2029 Term Loan and the SMBC 2026 Term Loan are collectively referred to as SMBC Term Loans. The SMBC Term Loans require the Company to maintain a debt service coverage ratio of at least 1.2 for its Japan entity for fiscal year 2026. The SMBC 2026 Term Loan requires the Company to maintain a U.S. dollar deposit account with a balance, translated into JPY, equal to or greater than the outstanding principal amount of the SMBC 2026 Term Loan.

[0001628280-26-005129:notes:207]
As of December 27, 2025, the Company had $83.3 million in principal amount outstanding in SMBC Term Loans, of which the short-term portion of $52.0 million is recorded as current liabilities while the long-term portion of $31.3 million is recorded as long-term debt in the Company’s condensed consolidated balance sheets.

[0001628280-26-005129:notes:208]
Mizuho Term Loan

[0001628280-26-005129:notes:209]
On September 20, 2024, the Company entered into a term loan agreement (the “Mizuho Term Loan”) with Mizuho Bank, Ltd. (“Mizuho”), in order to finance our planned manufacturing expansions. The Mizuho Term Loan provides for borrowings of 4.5 billion JPY with a 5-year term from the funding date September 20, 2024. The loan requires quarterly principal payments of approximately 225.0 million JPY commencing on December 20, 2024 with the final payment on September 20, 2029. The Mizuho Term Loan bears interest at a fixed annual rate of 0.90%. The Mizuho Term Loan is secured by the real estate assets owned by NeoPhotonics Semiconductor GK. The Mizuho Term Loan agreement requires that the Company and certain domestic subsidiaries comply with covenants relating to customary matters, including obtaining approval from Mizuho prior to transferring, creating a security interest, or disposing of the collateral assets; obtaining approval from Mizuho prior to a business transfer, business acquisition, corporate reorganization or changes such as mergers, company splits, share exchanges or share transfers or capital structure changes; obtaining approval from Mizuho prior to changing the Company’s indirect ownership in Lumentum Japan, Inc; and obtaining approval from Mizuho prior to a distribution of dividends by Lumentum Japan, Inc. to its shareholders. In addition, under the Mizuho Term Loan, the Company is committed to maintain a certain balance in U.S. dollar time and savings deposit accounts.

[0001628280-26-005129:notes:210]
As of December 27, 2025, the Company had $21.5 million in principal amount outstanding, of which the short-term portion of $5.7 million is recorded as current liabilities while the long-term portion of $15.8 million is recorded as long-term debt in the Company’s condensed consolidated balance sheets.

[0001628280-26-005129:notes:211]
The SMBC Term Loan and the Mizuho Term Loan are collectively referred to as Japan Term Loans.

[0001628280-26-005129:notes:212]
Revolving Credit Facility

[0001628280-26-005129:notes:213]
On December 19, 2025, the Company entered into a credit agreement (the “Credit Agreement”) with the lenders party thereto and Wells Fargo Bank, National Association, as administrative and collateral agent. The Credit Agreement provides for a senior secured revolving credit facility in an aggregate principal amount of $400.0 million, including a $23.0 million sublimit for the issuance of letters of credit. The Credit Agreement provides that the Company has the right at any time and from time to time to incur one or more incremental revolving commitments and/or incremental term loans up to an unlimited amount, subject to certain customary conditions precedent and other requirements. The proceeds of the loans under the Credit Agreement may be used for working capital and general corporate purposes.

[0001628280-26-005129:notes:214]
Revolving loans under the Credit Agreement may be borrowed, repaid and reborrowed, without premium or penalty (subject to customary breakage costs), until their maturity date under the Credit Agreement, at which time all amounts borrowed must be repaid. Revolving loans under the Credit Agreement will mature on December 19, 2030, subject to earlier maturity on the date that is 91 days prior to the final scheduled maturity date of the Company’s existing outstanding convertible notes, if on such date, the Company is unable to satisfy certain liquidity and/or total net leverage requirements.

[0001628280-26-005129:notes:215]
At the Company’s option, borrowings bear interest at either a base rate plus an applicable margin ranging from 0.50% to 1.50%, or a term Secured Overnight Financing Rate (“SOFR”) plus a margin ranging from 1.50% to 2.50%, in each case with such margin based upon the Company’s secured net leverage ratio, as determined in accordance with the terms of the Credit Agreement. Interest is payable quarterly in arrears with respect to borrowings bearing interest at the alternate base rate or on the last day of an interest period, but at least every three months, with respect to borrowings bearing interest at a term SOFR rate. The Company is required to pay to the Administrative Agent for the account of each Lender a commitment fee on a quarterly basis in an amount equal to 0.15% to 0.35% (depending on the Company’s secured net leverage ratio) of unused availability under the revolving facility. The Company is also obligated to pay other fees customary for revolving credit facilities of this size and type.

[0001628280-26-005129:notes:216]
The Credit Agreement contains customary representations, warranties, affirmative and negative covenants, and events of default. The negative covenants include, among others, restrictions on liens, investments, indebtedness, fundamental changes, restricted payments, transactions with affiliates and prepayments of subordinated debt, all subject to certain exceptions. In addition, the Credit Agreement contains financial covenants, tested at the end of each fiscal quarter, requiring the Company to maintain a secured net leverage ratio of less than or equal to 3.25:1.00, subject to a 0.50:1.00 step-up for four fiscal quarters in connection with a material acquisition, and an interest coverage ratio of no less than 3.00:1.00.

[0001628280-26-005129:notes:217]
The obligations under the Credit Agreement are required to be guaranteed by certain of the Company’s material domestic subsidiaries and are secured by substantially all assets of the Company and such subsidiary guarantors, subject to customary exceptions.

[0001628280-26-005129:notes:218]
As of December 27, 2025, there were no borrowings outstanding under the revolving credit facility.

[0001628280-26-005129:notes:219]
The Company incurred financing costs of about $2.5 million in connection with the revolving credit facility, which was presented as other non-current assets in the Company’s condensed consolidated balance sheets as of December 27, 2025 and are amortized to interest expense over the term of the facility.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-26-005129:notes:220]
Note 10. Accumulated Other Comprehensive Income (Loss)

[0001628280-26-005129:notes:221]
[same as prior period, unchanged from 0001628280-25-049073:notes:195]

[0001628280-26-005129:notes:222]
[same as prior period, unchanged from 0001628280-25-049073:notes:196]

[0001628280-26-005129:notes:223]
|  | Foreign Currency Translation Adjustments, Net of Tax (1) |  | Defined Benefit Obligations, Net of Tax (2) |  | Unrealized Gain on Available-for-Sale Securities, Net of Tax (3) |  |  |  | Total |
| Beginning balance as of June 28, 2025 | $ | 9.9 |  |  | $ | (1.6) |  |  | $ | 0.7 |  |  |  |  | $ | 9.0 |  |
| Other comprehensive gain (loss), net | (0.3) |  |  | — |  |  | 0.4 |  |  |  |  | 0.1 |  |
| Ending balance as of September 27, 2025 | $ | 9.6 |  |  | $ | (1.6) |  |  | $ | 1.1 |  |  |  |  | $ | 9.1 |  |
| Other comprehensive gain, net | — |  |  | — |  |  | 0.3 |  |  |  |  | 0.3 |  |
| Ending balance as of December 27, 2025 | $ | 9.6 |  |  | $ | (1.6) |  |  | $ | 1.4 |  |  |  |  | $ | 9.4 |  |
|  | Foreign Currency Translation Adjustments, Net of Tax (1) |  | Defined Benefit Obligations, Net of Tax (2) |  | Unrealized Gain (Loss) on Available-for-Sale Securities, Net of Tax (3) |  |  |  | Total |
| Beginning balance as of June 29, 2024 | $ | 9.8 |  |  | $ | 0.7 |  |  | $ | (1.2) |  |  |  |  | $ | 9.3 |  |
| Other comprehensive gain, net | — |  |  | — |  |  | 2.3 |  |  |  |  | 2.3 |  |
| Ending balance as of September 28, 2024 | $ | 9.8 |  |  | $ | 0.7 |  |  | $ | 1.1 |  |  |  |  | $ | 11.6 |  |
| Other comprehensive loss, net | (0.3) |  |  | — |  |  | (1.1) |  |  |  |  | (1.4) |  |
| Ending balance as of December 28, 2024 | $ | 9.5 |  |  | $ | 0.7 |  |  | $ | — |  |  |  |  | $ | 10.2 |  |

[0001628280-26-005129:notes:224]
(1) In fiscal year 2019, we established the functional currency for our worldwide operations as the U.S. dollar. Translation adjustments reported prior to December 2018 remain as a component of accumulated other comprehensive income (loss) in our condensed consolidated balance sheets, until all or a part of the investment in the subsidiaries is sold or liquidated.

[0001628280-26-005129:notes:225]
(2) We re-evaluate the assumptions related to the fair value of our defined benefit obligations annually in the fiscal fourth quarter and make any updates as necessary.

[0001628280-26-005129:notes:226]
(3) For the three and six months ended December 27, 2025, our unrealized gain on available-for-sale securities is presented net of tax of nil for both periods.

[0001628280-26-005129:notes:227]
For the three and six months ended December 28, 2024, our unrealized gain (loss) on available-for-sale securities is presented net of tax of nil for both periods.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-26-005129:notes:228]
Note 11. Restructuring and Related Charges (Reversals)

[0001628280-26-005129:notes:229]
[same as prior period, unchanged from 0001628280-25-049073:notes:201]

[0001628280-26-005129:notes:230]
[same as prior period, unchanged from 0001628280-25-049073:notes:202]

[0001628280-26-005129:notes:231]
|  | Three Months Ended |  | Six Months Ended |
|  | December 27, 2025 |  | December 28, 2024 |  | December 27, 2025 |  | December 28, 2024 |
| Balance as of beginning of period | $ | 5.9 |  |  | $ | 6.3 |  |  | $ | 2.5 |  |  | $ | 11.1 |  |
| Charges (reversals) | (0.4) |  |  | 0.7 |  |  | 7.9 |  |  | 10.4 |  |
| Payments and other adjustments | (3.3) |  |  | (5.5) |  |  | (8.2) |  |  | (20.0) |  |
| Balance as of end of period | $ | 2.2 |  |  | $ | 1.5 |  |  | $ | 2.2 |  |  | $ | 1.5 |  |

[0001628280-26-005129:notes:232]
During the three months ended December 27, 2025, we recorded a net reversal to our restructuring and related charges of  $0.4 million attributable to lower than previously recorded employee severance and wind-down charges. During the six months ended December 27, 2025, we recorded $7.9 million of restructuring and related charges related to a reduction in force during the period in order to enhance operational efficiency and realign our investments toward the most critical initiatives.

[0001628280-26-005129:notes:233]
During the three and six months ended December 28, 2024, we recorded restructuring and related charges of $0.7 million and $10.4 million, respectively mainly due to our integration efforts and cost reduction initiatives. Restructuring charges for the six months ended December 28, 2024 includes $6.2 million of asset write-offs primarily due to integration efforts to consolidate our sites, $3.0 million of charges related to the discontinuation of our in-house development of coherent Digital Signal Processors (“DSPs”) and Radio Frequency Integrated Circuits (“RFICs”) and the remaining restructuring charges due to company-wide cost reduction initiatives.

[0001628280-26-005129:notes:234]
[same as prior period, unchanged from 0001628280-25-049073:notes:206]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-26-005129:notes:235]
Note 12. Income Taxes

[0001628280-26-005129:notes:236]
Our tax provision for interim periods has generally been determined using an estimate of our annual effective tax rate, adjusted for discrete items, if any, that arise during the period. Each quarter, we update our estimate of the annual effective tax rate, and if the estimated annual effective tax rate changes, we make a cumulative adjustment in such period. Our quarterly tax provision and estimate of our annual effective tax rate are subject to variation due to several factors, including variability in pre-tax income (or loss), the mix of jurisdictions to which such income relates, changes in how we do business, and tax law developments.

[0001628280-26-005129:notes:237]
We recorded a tax provision of $18.3 million and $19.3 million for the three and six months ended December 27, 2025. Our tax provision for the three months ended December 27, 2025 includes a discrete tax expense of 1.1 million primarily related to the tax expense associated with income from a claim settlement, partially offset by the tax benefit from the revaluation of deferred tax balances, a windfall in connection with stock-based compensation vested during the quarter, and currency re-measurement of certain tax-related accounts. Our tax provision for the six months ended December 27, 2025 includes a discrete tax expense of $0.5 million, primarily related to the tax expense associated with income from a claim settlement, currency re-measurement of certain tax-related accounts, and interest accrual on uncertain tax positions, partially offset by the tax benefit from a windfall in connection with stock-based compensation vested during the periods, revaluation of deferred tax balances, and foreign return to provision differences.

[0001628280-26-005129:notes:238]
We recorded a tax provision of $18.6 million and $21.8 million for the three and six months ended December 28, 2024, respectively. Our tax provision for the three months ended December 28, 2024 is primarily attributable to the income tax expense from pre-tax earnings, interest on uncertain tax positions and withholding taxes, partially offset by the tax benefit from prior year changes in uncertain tax positions. Our tax provision for the six months ended December 28, 2024 is primarily attributable to the income tax expense from pre-tax earnings, interest on uncertain tax positions, foreign return to provision differences and withholding taxes, partially offset by the tax benefit from prior year changes in uncertain tax positions.

[0001628280-26-005129:notes:239]
Our estimated effective tax rate for the six months ended December 27, 2025 differs from the 21% U.S. statutory rate primarily due to the income tax expense from foreign income inclusions in the U.S., current year valuation allowance change, and changes in unrecognized tax benefits, partially offset by the income tax benefit from foreign rate differential and various income tax credits.

[0001628280-26-005129:notes:240]
We regularly assess our ability to realize our deferred tax assets on a quarterly basis and will establish a valuation allowance if it is more-likely-than-not that some portion of the deferred tax assets will not be realized. As of December 27, 2025, we maintain a full valuation allowance on U.S. federal and state and certain foreign deferred tax assets. We will continue to assess the need for a valuation allowance against our remaining deferred tax assets and may increase or decrease our valuation allowance materially in the future.

[0001628280-26-005129:notes:241]
As of December 27, 2025, we had $63.2 million of unrecognized tax benefits, which, if recognized, would affect the effective tax rate. We are subject to examination of income tax returns by various domestic and foreign tax authorities. The timing of resolution and closure of these tax examinations is highly unpredictable. Although it is possible that certain ongoing tax examinations may be concluded within the next 12 months, we cannot reasonably estimate the impact to tax expense and net income from tax examinations that could be resolved or closed within the next 12 months. Subject to audit timing and uncertainty, we expect the amount of unrecognized tax benefit that would become recognized due to expiration of the statute of limitations and affect the effective tax rate to decrease by $3.3 million over the next 12 months.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-26-005129:notes:242]
Note 13. Equity

[0001628280-26-005129:notes:243]
[same as prior period, unchanged from 0001628280-25-049073:notes:215]

[0001628280-26-005129:notes:244]
Equity Incentive Plans

[0001628280-26-005129:notes:245]
We adopted the 2015 Equity Incentive Plan (the “2015 Plan”) in connection with our separation from JDS Uniphase Corporation (“JDSU” and now, Viavi Solutions Inc.) in July 2015. Initially, 8.5 million shares of our common stock were authorized for issuance under the 2015 Plan. We amended and restated the 2015 Plan to (among other changes) increase the number of shares authorize for issuance, including increases approved by our stockholders of 3.0 million shares in 2016, 3.0 million shares in 2021 and 0.9 million shares in 2022, and most recently, on November 17, 2023, our stockholders approved amendments to the 2015 Plan to increase the number of shares of common stock reserved for issuance by an additional 3.0 million shares. On November 20, 2024, our stockholders approved an amendment to the 2015 Plan to extend the expiration date of the 2015 Plan by one year until June 23, 2026. The 2015 Plan provided for the grant of incentive stock options, within the meaning of Section 422 of the Internal Revenue Code, to our employees and any parent and subsidiary corporations’ employees, and for the grant of nonstatutory stock options (“stock options”), restricted stock awards (“RSAs”), restricted stock units (“RSUs”), stock appreciation rights (“SARs”), performance units (“PSUs”) and performance shares to our employees, directors and consultants and any parent or subsidiary corporations’ employees and consultants.

[0001628280-26-005129:notes:246]
On November 28, 2023, we adopted and assumed the Amended and Restated Share Option Scheme of Cloud Light Optoelectronics Limited (the “Cloud Light Scheme” and together with the 2015 Plan, the “Prior Plans”) in connection with the Cloud Light acquisition and we have reserved a total of 1.5 million shares of common stock for issuance thereunder. The Cloud Light Scheme provides for the grant of stock options, RSAs, RSUs, SARs, and performance shares to eligible employees and other service providers.

[0001628280-26-005129:notes:247]
In February 2025, our board of directors approved the 2025 Inducement Equity Incentive Plan (the “Inducement Plan”) in accordance with Listing Rule 5635(c)(4) of the corporate governance rules of the Nasdaq Stock Market, which became effective in February 2025. The Inducement Plan has substantially the same terms and conditions as the 2015 Plan, however, the Inducement Plan may only be used for grants to new employees and not for existing employees, executives, directors or consultants. The Inducement Plan provides for the grant of stock options, RSAs, RSUs, SARs, PSUs and performance shares to eligible employees and other service providers.

[0001628280-26-005129:notes:248]
On November 19, 2025, our stockholders approved the 2025 Equity Incentive Plan (the “2025 Plan”), under which the number of shares of common stock reserved for issuance was 3.2 million shares plus up to 3.9 million shares subject to awards granted under Prior Plans that, after the effective date of the 2025 Plan: (x) are forfeited, canceled or expire (whether voluntarily or involuntarily) or settled in cash, or (y) issued under the Prior Plans pursuant to an award that is forfeited, or repurchased by us as unvested, for an amount not greater than the original purchase price. The 2025 Plan became effective upon receiving stockholder approval. Upon the effective date of the 2025 Plan, the 2015 Plan and the Cloud Light Scheme terminated and no further grants will be made thereunder, but such plans continue to govern the terms of outstanding awards previously granted under such plans. The 2025 Plan has substantially the same terms and conditions as the 2015 Plan. The 2015 Plan, the Inducement Plan, the Cloud Light Scheme and the 2025 Plan are collectively referred to as the “Equity Incentive Plans.”

[0001628280-26-005129:notes:249]
As of December 27, 2025, we had 3.6 million shares subject to stock options, RSUs, RSAs, and PSUs issued and outstanding under the Equity Incentive Plans. RSUs and PSUs are performance-based, market-based and time-based or any combination thereof and are expected to vest within four years. As of December 27, 2025, 3.4 million shares of common stock under the Equity Incentive Plans were available for grant.

[0001628280-26-005129:notes:250]
[same as prior period, unchanged from 0001628280-25-049073:notes:220]

[0001628280-26-005129:notes:251]
[same as prior period, unchanged from 0001628280-25-049073:notes:221]

[0001628280-26-005129:notes:252]
[same as prior period, unchanged from 0001628280-25-049073:notes:222]

[0001628280-26-005129:notes:253]
RSUs under the Equity Incentive Plans are grants of shares of our common stock, the vesting of which is based on the requisite service requirement. The fair value of these grants is based on the closing market price of our common stock on the date of grant. Generally, our RSUs are subject to forfeiture and are expected to vest within four years. For annual grants to existing employees, RSUs generally vest ratably on an annual basis, or combination of annual and quarterly basis, over three years.

[0001628280-26-005129:notes:254]
During the six months ended December 27, 2025, our board of directors approved grants of 1.0 million RSUs, which primarily vest over three years. The fair value of these grants is based on the closing market price of our common stock on the grant date.

[0001628280-26-005129:notes:255]
[same as prior period, unchanged from 0001628280-25-049073:notes:225]

[0001628280-26-005129:notes:256]
PSUs under the Equity Incentive Plans are grants of shares of our common stock that vest upon the achievement of certain performance and service conditions. For PSUs with performance-based conditions, the fair value of these grants is based on the closing market price of our common stock on the date of grant, and we begin recognizing compensation expense when we conclude that it is probable that the performance conditions will be achieved. We reassess the probability of vesting at each reporting period and adjust our compensation cost based on this probability assessment. For PSUs with market-based conditions, the fair value of these grants is estimated using a Monte-Carlo simulation model, and the compensation expense is recognized ratably over the requisite service period regardless of whether or not the market condition is satisfied, provided the requisite service is rendered. Our PSUs are subject to risk of forfeiture until performance and service conditions are satisfied and generally vest within three years.

[0001628280-26-005129:notes:257]
During the six months ended December 27, 2025, our board of directors granted 0.1 million PSUs with an aggregate grant date fair value of $13.7 million to certain executive officers and senior management. These PSUs will vest subject to the achievement of earnings per share targets, as well as service conditions, over three years. The number of shares may be increased or decreased based on the results of these measurement targets ranging between 0% and 200% in accordance with the terms established at the date of grant. In addition, the board of directors also approved a grant of 0.1 million PSUs with an aggregate grant date fair value of $33.0 million to certain executive officers and senior management. These PSUs will vest subject to the achievement of the Company’s total shareholder return (or “TSR”) relative to specified peer group, as well as service conditions, over three years. The number of shares that ultimately vest may be increased or decreased based on the results of these measurement targets ranging between 0% and 200% in accordance with the terms established at the date of grant. The Company estimated the grant date fair value of these PSU awards using a Monte-Carlo simulation model, which was calculated at $282.85 per share.

[0001628280-26-005129:notes:258]
Stock-based compensation expense related to PSUs are categorized as AIP PSUs, TSR PSUs and Other PSUs. AIP PSUs relates to the shares granted to executive and non-executive employees as part of our Annual Incentive Plan (“AIP PSUs”) during fiscal year 2025, which were subject to performance targets and service conditions and vested in August 2025. TSR PSUs relate to shares granted to certain executive officers and senior management, which will vest subject to the achievement of the Company’s TSR relative to specified peer group while Other PSUs relate to shares granted to certain executive officers and senior management, which are subject to financial performance targets (such as revenue and EPS) and service conditions. Refer to the table below for a presentation of stock-based compensation expense by equity awards for more details.

[0001628280-26-005129:notes:259]
[same as prior period, unchanged from 0001628280-25-049073:notes:228]

[0001628280-26-005129:notes:260]
Our ESPP provides eligible employees with the opportunity to acquire an ownership interest in the Company through periodic payroll deductions and provides a 15% purchase price discount as well as a 6-month look-back period. The ESPP is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986, as amended. The ESPP will terminate upon the date on which all shares available for issuance have been sold. We estimate the fair value of the ESPP shares on the date of grant using the Black-Scholes option-pricing model. Of the 3.0 million shares authorized under the ESPP, 0.3 million shares remained available for issuance as of December 27, 2025.

[0001628280-26-005129:notes:261]
[same as prior period, unchanged from 0001628280-25-049073:notes:230]

[0001628280-26-005129:notes:262]
[same as prior period, unchanged from 0001628280-25-049073:notes:231]

[0001628280-26-005129:notes:263]
|  | Three Months Ended |  | Six Months Ended |
|  | December 27, 2025 |  | December 28, 2024 |  | December 27, 2025 |  | December 28, 2024 |
| Cost of sales | $ | 12.9 |  |  | $ | 9.2 |  |  | $ | 21.5 |  |  | $ | 18.9 |  |
| Research and development | 9.3 |  |  | 11.4 |  |  | 19.6 |  |  | 20.7 |  |
| Selling, general and administrative | 23.2 |  |  | 18.2 |  |  | 46.7 |  |  | 34.8 |  |
| Total stock-based compensation | $ | 45.4 |  |  | $ | 38.8 |  |  | $ | 87.8 |  |  | $ | 74.4 |  |

[0001628280-26-005129:notes:264]
[same as prior period, unchanged from 0001628280-25-049073:notes:233]

[0001628280-26-005129:notes:265]
|  | Three Months Ended |  | Six Months Ended |
|  | December 27, 2025 |  | December 28, 2024 |  | December 27, 2025 |  | December 28, 2024 |
| RSUs | $ | 27.0 |  |  | $ | 24.8 |  |  | $ | 52.6 |  |  | $ | 48.8 |  |
| AIP PSUs | — |  |  | 9.4 |  |  | 4.8 |  |  | 13.5 |  |
| TSR PSUs | 4.6 |  |  | 0.5 |  |  | 7.5 |  |  | 0.7 |  |
| Other PSUs | 5.5 |  |  | 2.3 |  |  | 15.4 |  |  | 5.3 |  |
| Total PSUs | 10.1 |  |  | 12.2 |  |  | 27.7 |  |  | 19.5 |  |
| Options | 1.0 |  |  | 1.3 |  |  | 2.6 |  |  | 2.6 |  |
| ESPP | 1.2 |  |  | 1.0 |  |  | 2.8 |  |  | 2.2 |  |
| Sub-total | 39.3 |  |  | 39.3 |  |  | 85.7 |  |  | 73.1 |  |
| Change in stock-based compensation capitalized to inventory | 6.1 |  |  | (0.5) |  |  | 2.1 |  |  | 1.3 |  |
| Total stock-based compensation | $ | 45.4 |  |  | $ | 38.8 |  |  | $ | 87.8 |  |  | $ | 74.4 |  |

[0001628280-26-005129:notes:266]
During the three and six months ended December 27, 2025, we recorded $10.1 million and $27.7 million of stock-based compensation related to PSUs, respectively. During the three and six months ended December 28, 2024, we recorded $12.2 million and $19.5 million of stock-based compensation related to PSUs, respectively. The amount of stock-based compensation expense recognized in any one period related to PSUs with performance-based conditions can vary based on the achievement or anticipated achievement of the performance conditions. If the performance conditions are not met or not expected to be met, no compensation expense would be recognized on the underlying PSUs, and any previously recognized compensation expense related to those PSUs would be reversed.

[0001628280-26-005129:notes:267]
[same as prior period, unchanged from 0001628280-25-049073:notes:236]

[0001628280-26-005129:notes:268]
|  | Three Months Ended |  | Six Months Ended |
|  | December 27, 2025 |  | December 28, 2024 |  | December 27, 2025 |  | December 28, 2024 |
| Income tax benefit associated with stock-based compensation | $ | 2.3 |  |  | $ | 4.7 |  |  | $ | 10.3 |  |  | $ | 6.1 |  |

[0001628280-26-005129:notes:269]
Approximately $12.4 million and $14.6 million of stock-based compensation was capitalized to inventory as of December 27, 2025 and June 28, 2025, respectively.

[0001628280-26-005129:notes:270]
The table below summarizes the unrecognized stock-based compensation cost related to unvested shares and the weighted-average period over which it is expected to be recognized as of December 27, 2025:

[0001628280-26-005129:notes:271]
|  | Unrecognized stock-based compensation (in millions) |  | Weighted-average period(in years) |
| RSUs | $ | 181.0 |  |  | 2.0 |
| PSUs | 95.9 |  |  | 2.4 |
| Stock options | 3.3 |  |  | 0.9 |
| ESPP | 2.2 |  |  | 0.4 |

[0001628280-26-005129:notes:272]
[same as prior period, unchanged from 0001628280-25-049073:notes:241]

[0001628280-26-005129:notes:273]
The following table summarizes our award activities for the six months ended December 27, 2025 (in millions):

[0001628280-26-005129:notes:274]
|  | Stock Options |  | Restricted Stock Units |  | Performance Stock Units |  |  |  |  |
|  | Number of Shares |  | Weighted-Average Exercise Price per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  |  |  |  |
| Balance as of June 28, 2025 | 0.6 |  |  | $ | 8.1 |  |  | 2.6 |  |  | $ | 59.9 |  |  | 1.6 |  |  | $ | 61.0 |  |  |  |  |  |
| Granted | — |  |  | — |  |  | 1.0 |  |  | 125.9 |  |  | 0.2 |  |  | 120.9 |  |  |  |  |  |
| Vested/Exercised | (0.3) |  |  | 7.9 |  |  | (1.0) |  |  | 61.1 |  |  | (0.9) |  |  | 57.1 |  |  |  |  |  |
| Canceled/Forfeited | — |  |  | — |  |  | (0.1) |  |  | 64.9 |  |  | (0.1) |  |  | 85.9 |  |  |  |  |  |
| Balance as of December 27, 2025 | 0.3 |  |  | $ | 8.1 |  |  | 2.5 |  |  | $ | 86.2 |  |  | 0.8 |  |  | $ | 82.0 |  |  |  |  |  |

[0001628280-26-005129:notes:275]
[same as prior period, unchanged from 0001628280-25-049073:notes:244]

[0001628280-26-005129:notes:276]
|  | Awards Available for Grant |
| Balance as of June 28, 2025 | 2.6 |  |
| Authorized | 3.2 |  |
| Removed | (1.4) |  |
| Granted | (1.2) |  |
| Canceled/Forfeited | 0.2 |  |
| Balance as of December 27, 2025 | 3.4 |  |

[0001628280-26-005129:notes:277]
[same as prior period, unchanged from 0001628280-25-049073:notes:246]

[0001628280-26-005129:notes:278]
The ESPP expense for the three and six months ended December 27, 2025 was $1.2 million and $2.8 million, respectively. The expense related to the ESPP is recorded on a straight-line basis over the relevant subscription period. 
During the three and six months ended December 28, 2024, there were $1.0 million and $2.2 million shares issued to employees through the ESPP


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001628280-26-005129:notes:279]
Note 14. Commitments and Contingencies

[0001628280-26-005129:notes:280]
Purchase Obligations

[0001628280-26-005129:notes:281]
Our purchase obligations of $1,086.0 million as of December 27, 2025 represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001628280-26-005129:notes:282]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with these vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures. In addition, the imposition of tariffs on certain imported goods and materials may increase our costs and place upward pressure on the cost of sales.

[0001628280-26-005129:notes:283]
Product Warranties

[0001628280-26-005129:notes:284]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve-month warranty for most of our products. However, in some instances depending upon the product, product components or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products, and service delivery costs incurred in correcting product failures. In addition, from time-to-time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001628280-26-005129:notes:285]
The following table presents the changes in our warranty reserve for the periods presented (in millions):

[0001628280-26-005129:notes:286]
|  | Three Months Ended |  | Six Months Ended |
|  | December 27, 2025 |  | December 28, 2024 |  | December 27, 2025 |  | December 28, 2024 |
| Balance as of beginning of period | $ | 13.1 |  |  | $ | 13.2 |  |  | $ | 14.4 |  |  | $ | 13.2 |  |
| Measurement period adjustment | — |  |  | — |  |  | — |  |  | 0.8 |  |
| Provision for warranty (1) | 13.5 |  |  | 2.0 |  |  | 16.3 |  |  | 4.4 |  |
| Utilization of reserve, net | (3.9) |  |  | (2.4) |  |  | (8.0) |  |  | (5.6) |  |
| Balance as of end of period | $ | 22.7 |  |  | $ | 12.8 |  |  | $ | 22.7 |  |  | $ | 12.8 |  |

[0001628280-26-005129:notes:287]
(1) During the three and six months ended December 27, 2025, we recorded $9.8 million of warranty expense associated with Cloud Light’s legacy products in our condensed consolidated statements of operations.

[0001628280-26-005129:notes:288]
Environmental Liabilities

[0001628280-26-005129:notes:289]
Our research and development, manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental and product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001628280-26-005129:notes:290]
Legal Proceedings

[0001628280-26-005129:notes:291]
We are subject to a variety of claims and suits that arise from time-to-time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss. As of December 27, 2025, the accrual for expected settlement of litigation matters was not material.

[0001628280-26-005129:notes:292]
Regulatory Matters

[0001628280-26-005129:notes:293]
In August 2024, the Company received inquiries from the Bureau of Industry and Security of the U.S. Department of Commerce (“BIS”) and Department of Justice (“DOJ”) following the Company’s voluntary disclosure to BIS in December 2023, and supplemented in April 2024. The Company continues to cooperate with both agencies on this matter. The Company is unable to predict the likely outcome of these matters.

[0001628280-26-005129:notes:294]
Indemnifications

[0001628280-26-005129:notes:295]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown, because claims may be made against us in the future, and we may record charges in the future as a result of these indemnification obligations.

[0001628280-26-005129:notes:296]
On March 5, 2025, we completed a sale of net assets located in an entity in Shenzhen, China. The Company has reclassified a $21.4 million unrecognized tax position to other non-current liabilities in the condensed consolidated balance sheets as of June 28, 2025 for an indemnification liability related to the sale of certain assets. This does not impact our results of operations for the year ended June 28, 2025. We did not have any other material indemnification claims that were probable or reasonably possible.

[0001628280-26-005129:notes:297]
Audit Proceedings

[0001628280-26-005129:notes:298]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period when we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-26-005129:notes:299]
Note 15. Operating Segments and Geographic Information

[0001628280-26-005129:notes:300]
Prior to fiscal year 2026, we operated in two reportable segments consisting of Cloud & Networking and Industrial Tech. During the first quarter of fiscal year 2026, we implemented a re-organization, and we are now managed as a single, integrated enterprise, with a unified management team overseeing operations across the entire company, rather than through discrete operating segments. The chief operating decision maker (“CODM”) is the Company’s Chief Executive Officer, who reviews financial information presented as a single enterprise for purposes of allocating resources and evaluating financial performance.

[0001628280-26-005129:notes:301]
The CODM assesses the performance of the single segment and allocates resources based on consolidated net income (loss) included in the Company’s condensed consolidated statements of operations. The CODM uses consolidated net income (loss) to set budgets, evaluate performance, review actual results and in deciding whether to reinvest profits into our business, pursue acquisitions, or make any other capital management decisions. The significant segment expenses are reflected in the Company’s condensed consolidated statements of operations and the condensed consolidated statements of cash flows. The measure of the single segment assets is the consolidated assets included in the condensed consolidated balance sheets. Accordingly, following the reorganization, we determined we operate in a single reporting segment. Comparative prior period segment information has been updated to reflect the new segment structure and measures. The changes in our operating segments had no impact on our previously reported consolidated results of operations, financial position or cash flows.

[0001628280-26-005129:notes:302]
Refer to “Note 16. Revenue Recognition” for a presentation of disaggregated revenue by type of product.

[0001628280-26-005129:notes:303]
[same as prior period, unchanged from 0001628280-25-049073:notes:273]

[0001628280-26-005129:notes:304]
[same as prior period, unchanged from 0001628280-25-049073:notes:274]

[0001628280-26-005129:notes:305]
The following table presents net revenue by the three geographic regions we operate in and net revenue from countries that generally represented 10% or more of our total net revenue based on customer shipping locations (in millions, except percentage data):

[0001628280-26-005129:notes:306]
|  | Three Months Ended |  | Six Months Ended |
|  | December 27, 2025 |  | December 28, 2024 |  | December 27, 2025 |  | December 28, 2024 |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 144.7 |  |  | 21.7 | % |  | $ | 77.6 |  |  | 19.3 | % |  | $ | 238.4 |  |  | 19.9 | % |  | $ | 143.0 |  |  | 19.3 | % |
| Mexico | 102.6 |  |  | 15.4 |  |  | 37.4 |  |  | 9.3 |  |  | 176.2 |  |  | 14.7 |  |  | 71.3 |  |  | 9.6 |  |
| Other Americas | 2.0 |  |  | 0.3 |  |  | 4.2 |  |  | 1.0 |  |  | 10.6 |  |  | 0.9 |  |  | 7.1 |  |  | 1.0 |  |
| Total Americas | $ | 249.3 |  |  | 37.4 | % |  | $ | 119.2 |  |  | 29.6 | % |  | $ | 425.2 |  |  | 35.5 | % |  | $ | 221.4 |  |  | 29.9 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 118.9 |  |  | 17.9 | % |  | $ | 100.5 |  |  | 25.0 | % |  | $ | 211.8 |  |  | 17.7 | % |  | $ | 189.2 |  |  | 25.6 | % |
| Thailand | 123.0 |  |  | 18.5 |  |  | 74.7 |  |  | 18.6 |  |  | 232.1 |  |  | 19.3 |  |  | 127.2 |  |  | 17.2 |  |
| China | 54.6 |  |  | 8.2 |  |  | 18.1 |  |  | 4.5 |  |  | 103.9 |  |  | 8.7 |  |  | 32.7 |  |  | 4.4 |  |
| Japan | 23.8 |  |  | 3.6 |  |  | 18.4 |  |  | 4.5 |  |  | 44.8 |  |  | 3.7 |  |  | 35.3 |  |  | 4.8 |  |
| Other Asia-Pacific | 55.8 |  |  | 8.4 |  |  | 30.5 |  |  | 7.6 |  |  | 105.2 |  |  | 8.7 |  |  | 61.9 |  |  | 8.4 |  |
| Total Asia-Pacific | $ | 376.1 |  |  | 56.6 | % |  | $ | 242.2 |  |  | 60.2 | % |  | $ | 697.8 |  |  | 58.1 | % |  | $ | 446.3 |  |  | 60.4 | % |
| EMEA | $ | 40.1 |  |  | 6.0 | % |  | $ | 40.8 |  |  | 10.2 | % |  | $ | 76.3 |  |  | 6.4 | % |  | $ | 71.4 |  |  | 9.7 | % |
| Total net revenue | $ | 665.5 |  |  | 100.0 | % |  | $ | 402.2 |  |  | 100.0 | % |  | $ | 1,199.3 |  |  | 100.0 | % |  | $ | 739.1 |  |  | 100.0 | % |

[0001628280-26-005129:notes:307]
During the three months ended December 27, 2025, two customers individually accounted for 24% and 17% of our total revenue, respectively. During the six months ended December 27, 2025, two customers individually accounted for 23% and 19% of our total net revenue, respectively. We had no other customers that represented 10% or greater of our total net revenue.

[0001628280-26-005129:notes:308]
During the three months ended December 28, 2024, three customers individually accounted for 16%, 14%, and 11% of our total revenue, respectively. During the six months ended December 28, 2024, three customers individually accounted for 15%, 13%, and 10% of our total net revenue, respectively. We had no other customers that represented 10% or greater of our total net revenue.

[0001628280-26-005129:notes:309]
As of December 27, 2025, two customers individually accounted for 20% and 12% of gross accounts receivable, respectively. As of June 28, 2025, two customers individually accounted for 13% and 11% of gross accounts receivable, respectively. We had no other customers that represented 10% or greater of our gross accounts receivable.

[0001628280-26-005129:notes:310]
[same as prior period, unchanged from 0001628280-25-049073:notes:279]

[0001628280-26-005129:notes:311]
|  | December 27, 2025 |  | June 28, 2025 |
| Property, plant and equipment, net |  |  |  |
| United States | $ | 80.1 |  |  | $ | 123.0 |  |
| Thailand | 266.0 |  |  | 218.6 |  |
| Japan | 182.9 |  |  | 144.3 |  |
| United Kingdom | 121.9 |  |  | 109.4 |  |
| China | 111.4 |  |  | 76.8 |  |
| Other countries | 51.2 |  |  | 54.3 |  |
| Total property, plant and equipment, net | $ | 813.5 |  |  | $ | 726.4 |  |

[0001628280-26-005129:notes:312]
We purchase a portion of our inventory from contract manufacturers that are located primarily in Thailand, Taiwan, and Malaysia. During the three and six months ended December 27, 2025, our net inventory purchases from a single contract manufacturer that represented 10% or greater of our total net inventory purchases were concentrated with one contract manufacturer, who accounted for 19% and 20% of the total net inventory purchases, respectively. During the three and six months ended December 28, 2024, our net inventory purchases from a single contract manufacturer that represented 10% or greater of our total net inventory purchases were concentrated with one contract manufacturer, who accounted for 27% and 27% of the total net inventory purchases, respectively.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-26-005129:notes:313]
Note 16. Revenue Recognition

[0001628280-26-005129:notes:314]
[same as prior period, unchanged from 0001628280-25-049073:notes:283]

[0001628280-26-005129:notes:315]
[same as prior period, unchanged from 0001628280-25-049073:notes:284]

[0001628280-26-005129:notes:316]
[same as prior period, unchanged from 0001628280-25-049073:notes:285]

[0001628280-26-005129:notes:317]
|  | Three Months Ended |  | Six Months Ended |
|  | December 27, 2025 |  | December 28, 2024 |  | December 27, 2025 |  | December 28, 2024 |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Components | 443.7 |  |  | 66.7 | % |  | 263.7 |  |  | 65.6 | % |  | 822.9 |  |  | 68.6 | % |  | $ | 495.1 |  |  | 67.0 | % |
| Systems | 221.8 |  |  | 33.3 | % |  | 138.5 |  |  | 34.4 | % |  | 376.4 |  |  | 31.4 | % |  | 244.0 |  |  | 33.0 | % |
| Net revenue | $ | 665.5 |  |  | 100.0 | % |  | $ | 402.2 |  |  | 100.0 | % |  | $ | 1,199.3 |  |  | 100.0 | % |  | $ | 739.1 |  |  | 100.0 | % |

[0001628280-26-005129:notes:318]
Refer to “Note 15. Operating Segments and Geographic Information” for a presentation of disaggregated revenue by geography.

[0001628280-26-005129:notes:319]
[same as prior period, unchanged from 0001628280-25-049073:notes:288]

[0001628280-26-005129:notes:320]
We record accounts receivable when we have an unconditional right to consideration. Contract liabilities are recorded when cash payments are received or due in advance of performance. Contract liabilities consist of advance payments and deferred revenue, where we have unsatisfied performance obligations. Contract liabilities are classified as deferred revenue and customer deposits and are included in other current and non-current liabilities within our condensed consolidated balance sheets. Payment terms vary by customer. The time between invoicing and when payment is due is not significant.

[0001628280-26-005129:notes:321]
[same as prior period, unchanged from 0001628280-25-049073:notes:290]

[0001628280-26-005129:notes:322]
| Contract balances |  | Balance sheet location |  | December 27, 2025 |  | June 28, 2025 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 376.8 |  |  | $ | 250.0 |  |  | $ | 126.8 |  |  | 50.7 | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | 2.1 |  |  | $ | 0.7 |  |  | $ | 1.4 |  |  | 200.0 | % |
| Deferred revenue and customer deposits |  | Other non-current liabilities |  | $ | 1.5 |  |  | $ | — |  |  | $ | 1.5 |  |  | n/a |


## ecd:MtrlTermsOfTrdArrTextBlock

[0001628280-26-005129:notes:323]
On November 5, 2025, Wupen Yuen, our President, Global Business Units, adopted a Rule 10b5-1 trading arrangement providing for the sale from time to time of an aggregate of up to 28,522 shares of our common stock (based on PSUs vesting at target). The actual number of shares sold under the trading arrangement will depend on achievement of performance targets applicable to the PSUs subject to the trading arrangement, be subject to vesting of the PSUs and RSUs subject to the trading arrangement, and be net of shares withheld for taxes upon vesting and settlement of the PSUs and RSUs subject to the trading arrangement. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c). The duration of the trading arrangement  is until December 31, 2026, or earlier if all transactions under the trading arrangement are completed.

[0001628280-26-005129:notes:324]
On November 13, 2025, Vince Retort, our President, Modules R&D and New Product Design and Development, adopted a Rule 10b5-1 trading arrangement providing for the sale from time to time of an aggregate up to 105,445 shares of our common stock (based on PSUs vesting at target). The actual number of shares sold under the trading arrangement will depend on achievement of performance targets applicable to the PSUs subject to the trading arrangement, be subject to vesting of the PSUs and RSUs subject to the trading arrangement, and be net of shares withheld for taxes upon vesting and settlement of the PSUs and RSUs subject to the trading arrangement. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c). The duration of the trading arrangement is until November 20, 2026, or earlier if all transactions under the trading arrangement are completed.

[0001628280-26-005129:notes:325]
On November 28, 2025, Wajid Ali, our Chief Financial Officer, adopted a Rule 10b5-1 trading arrangement providing for the sale from time to time of an aggregate of up to 66,265 shares of our common stock (based on PSUs vesting at target). The actual number of shares sold under the trading arrangement will depend on achievement of performance targets applicable to the PSUs subject to the trading arrangement, be subject to vesting of the PSUs and RSUs subject to the trading arrangement, and be net of shares withheld for taxes upon vesting and settlement of the PSUs and RSUs subject to the trading arrangement. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c). The duration of the trading arrangement is until November 30, 2026, or earlier if all transactions under the trading arrangement are completed.
