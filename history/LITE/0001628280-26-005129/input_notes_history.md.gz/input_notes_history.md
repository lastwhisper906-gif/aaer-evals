# LITE note change history — 0001628280-25-049073 → 0001628280-26-005129


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2026-02-04):
[0001628280-26-005129:note_history:1]
Our purchase obligations of $1,086.0 million as of December 27, 2025 represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.
  (was, 2025-11-05, similarity 0.9939):
[0001628280-25-049073:note_history:1]
Our purchase obligations of $875.3 million as of September 27, 2025 represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

- added (2026-02-04):
[0001628280-26-005129:note_history:2]
|  | Three Months Ended |  | Six Months Ended |
|  | December 27, 2025 |  | December 28, 2024 |  | December 27, 2025 |  | December 28, 2024 |
| Balance as of beginning of period | $ | 13.1 |  |  | $ | 13.2 |  |  | $ | 14.4 |  |  | $ | 13.2 |  |
| Measurement period adjustment | — |  |  | — |  |  | — |  |  | 0.8 |  |
| Provision for warranty (1) | 13.5 |  |  | 2.0 |  |  | 16.3 |  |  | 4.4 |  |
| Utilization of reserve, net | (3.9) |  |  | (2.4) |  |  | (8.0) |  |  | (5.6) |  |
| Balance as of end of period | $ | 22.7 |  |  | $ | 12.8 |  |  | $ | 22.7 |  |  | $ | 12.8 |  |

- added (2026-02-04):
[0001628280-26-005129:note_history:3]
(1) During the three and six months ended December 27, 2025, we recorded $9.8 million of warranty expense associated with Cloud Light’s legacy products in our condensed consolidated statements of operations.

- changed (2026-02-04):
[0001628280-26-005129:note_history:4]
We are subject to a variety of claims and suits that arise from time-to-time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss. As of December 27, 2025, the accrual for expected settlement of litigation matters was not material.
  (was, 2025-11-05, similarity 0.9951):
[0001628280-25-049073:note_history:4]
We are subject to a variety of claims and suits that arise from time-to-time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss. As of September 27, 2025, the accrual for expected settlement of litigation matters was not material.

- removed (2026-02-04):
[0001628280-25-049073:note_history:5]
|  | Three Months Ended |  |  |
|  | September 27, 2025 |  | September 28, 2024 |  |  |  |  |
| Balance as of beginning of period | $ | 14.4 |  |  | $ | 13.2 |  |  |  |  |  |
| Measurement period adjustment | — |  |  | 0.8 |  |  |  |  |  |
| Provision for warranty | 2.8 |  |  | 2.4 |  |  |  |  |  |
| Utilization of reserve, net | (4.1) |  |  | (3.2) |  |  |  |  |  |
| Balance as of end of period | $ | 13.1 |  |  | $ | 13.2 |  |  |  |  |  |

- removed (2026-02-04):
[0001628280-25-049073:note_history:6]
On November 7, 2023, we completed the acquisition of Cloud Light. In accordance with the Merger Agreement, cash consideration included $75.8 million of cash held in an escrow fund to support Cloud Light’s indemnification obligations and customary adjustment for working capital.  Since the measurement period expired, any future adjustments will be included in our earnings. No amount of escrow funds have been released as the parties have not mutually agreed on the indemnification obligation and working capital adjustment.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2026-02-04):
[0001628280-26-005129:note_history:7]
Prior to fiscal year 2026, we operated in two reportable segments consisting of Cloud & Networking and Industrial Tech. During the first quarter of fiscal year 2026, we implemented a re-organization, and we are now managed as a single, integrated enterprise, with a unified management team overseeing operations across the entire company, rather than through discrete operating segments. The chief operating decision maker (“CODM”) is the Company’s Chief Executive Officer, who reviews financial information presented as a single enterprise for purposes of allocating resources and evaluating financial performance. Accordingly, following the reorganization, we determined we operate in a single reporting segment. Comparative prior period segment information has been updated to reflect the new segment structure and measures. The changes in our operating segments had no impact on our previously reported consolidated results of operations, financial position or cash flows. Refer to “Note 15. Operating Segments and Geographic Information” for more details.

- changed (2026-02-04):
[0001628280-26-005129:note_history:8]
The Company is actively monitoring and assessing the ongoing global trade environment, particularly with respect to recent changes in trade restrictions and tariff regulations. We have assessed the potential impacts of heightened restrictions and tariffs on our allowance for credit losses, the carrying value of our goodwill and other long-lived assets, inventory valuation, and revenue recognition. While we have determined there was not a material impact to our condensed consolidated financial statements as of December 27, 2025 and for the three and six months ended December 27, 2025, import tariffs implemented by the U.S. and other countries, as currently in effect and/or proposed, could have a material impact on our results for the remainder of fiscal year 2026 and in the future. The impact of tariffs is dependent upon negotiations with customers and suppliers and other mitigation efforts and potential further changes in global trade policies, including higher tariffs in the U.S. or other countries.
  (was, 2025-11-05, similarity 0.9724):
[0001628280-25-049073:note_history:8]
The Company is actively monitoring and assessing the ongoing global trade environment, particularly with respect to recent changes in trade restrictions and tariff regulations. We have assessed the potential impacts of heightened restrictions and tariffs on our allowance for credit losses, the carrying value of our goodwill and other long-lived assets, inventory valuation, and revenue recognition.  While we have determined there was not a material impact to our condensed consolidated financial statements as of September 27, 2025 and for the quarter ended September 27, 2025, import tariffs implemented by the U.S. and other countries, as currently in effect and/or proposed, could have a material impact on our results for the remainder of fiscal year 2026 and in the future. The impact of tariffs is dependent upon negotiations with customers and suppliers and other mitigation efforts and potential further changes in global trade policies, including higher tariffs in the U.S. or other countries.

- added (2026-02-04):
[0001628280-26-005129:note_history:9]
During the three months ended December 27, 2025, the last reported sale price of the Company’s common stock was at least 130% of the applicable conversion price of each series of our convertible notes, which includes 2032 Notes, 2029 Notes, 2028 Notes, and 2026 Notes (collectively referred to as the “Notes”) for at least 20 trading days during the 30 consecutive trading-day period ended on December 27, 2025. Therefore, the Notes are convertible at the option of the holders, and we are required to satisfy the conversion obligation with respect to any such converted series of Notes by paying cash equal to the principal amount of such converted series of Notes, and paying or delivering, as the case maybe, cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof. Accordingly, pursuant to ASC 470-20 under U.S. GAAP, although the applicable contractual maturity dates of these Notes extend beyond 12 months from the balance sheet date, we are required to classify our 2028 Notes, 2029 Notes and 2032 Notes, that have an aggregate carrying value of $2,714.2 million, as current portion of long-term debt as of December 27, 2025.  Only the 2026 Notes with carrying value of $468.3 million mature within the next 12 months.

- added (2026-02-04):
[0001628280-26-005129:note_history:10]
The carrying amounts and estimated fair values of the convertible notes are as follows for the periods presented (in millions):

- added (2026-02-04):
[0001628280-26-005129:note_history:11]
|  | December 27, 2025 |  | June 28, 2025 |
|  | Carrying Amount |  | Estimated Fair Value |  | Carrying Amount |  | Estimated Fair Value |
| 2032 Notes | $ | 1,255.3 |  |  | $ | 2,840.8 |  |  | $ | — |  |  | $ | — |  |
| 2029 Notes | 600.6 |  |  | 3,400.1 |  |  | 600.2 |  |  | 925.5 |  |
| 2028 Notes | 858.3 |  |  | 2,584.6 |  |  | 857.7 |  |  | 890.2 |  |
| 2026 Notes | 468.3 |  |  | 1,844.6 |  |  | 1,048.3 |  |  | 1,233.3 |  |
|  | $ | 3,182.5 |  |  | $ | 10,670.1 |  |  | $ | 2,506.2 |  |  | $ | 3,049.0 |  |

- added (2026-02-04):
[0001628280-26-005129:note_history:12]
The 2028 Notes, 2029 Notes and 2032 Notes are held by more than 60 unique holders and no holders had individual aggregate principal values greater than $505.0 million at December 27, 2025. To the extent Note holders elect to convert all or a significant portion of the Notes within a short period of time, our liquidity would be adversely impacted, and the Note holders’ ability to exercise their conversion right raises a substantial doubt that we could continue as a going concern. If we receive a significant number of requests for early conversion of Notes, we would utilize existing cash, cash equivalents and short-term investments, together with available borrowings under our existing revolving credit facility, cash flows from operations, and proceeds from one or more potential new financings to settle the principal amount of such converted Notes in cash, with any excess conversion value thereof to be settled in cash, shares of common stock, or a combination of cash and shares of common stock, at our election.

- added (2026-02-04):
[0001628280-26-005129:note_history:13]
However, the fair value of the Notes, which would be the estimated value the holders would receive if they sell their Notes in the bond market, is generally higher than the value the holders would receive upon early conversion. The fair value is generally higher than the conversion value due to the embedded call option in the Notes which has time left until the Notes mature.  Conversion also requires a holder to be subject to a holding period in which they are subject to further volatility. Therefore, historically, the holders’ requests for early conversion of our Notes have not been significant prior to the three-month period immediately preceding maturity.

- changed (2026-02-04):
[0001628280-26-005129:note_history:14]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal year 2026 is a 52-week year ending on June 27, 2026, with the quarter ended December 27, 2025 being a 13-week quarterly period. Our fiscal year 2025 was a 52-week year that ended on June 28, 2025, with the quarter ended December 28, 2024 being a 13-week quarterly period.
  (was, 2025-11-05, similarity 0.9756):
[0001628280-25-049073:note_history:14]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2026 is a 52-week year ending on June 27, 2026, with the quarter ended September 27, 2025 being a 13-week quarterly period. Our fiscal 2025 was a 52-week year that ended on June 28, 2025, with the quarter ended September 28, 2024 being a 13-week quarterly period.

- changed (2026-02-04):
[0001628280-26-005129:note_history:15]
The condensed consolidated financial statements and accompanying notes should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the fiscal year ended June 28, 2025. There were no significant changes to our accounting policies during the six months ended December 27, 2025, except as noted below:
  (was, 2025-11-05, similarity 0.943):
[0001628280-25-049073:note_history:15]
The condensed consolidated financial statements and accompanying notes should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the fiscal year ended June 28, 2025. There were no significant changes to our accounting policies during the three months ended September 27, 2025, except as noted below:

- changed (2026-02-04):
[0001628280-26-005129:note_history:16]
In the fourth quarter of fiscal year 2025, we released $153.1 million of valuation allowances on our UK deferred tax assets after we considered all available positive and negative evidence related to our UK subsidiary. We analyzed the UK subsidiary’s historical operating results, projected future taxable income, tax planning strategies, and reversals of deferred tax liabilities, and determined that the weight of available objectively verifiable positive evidence supported the realizability of the UK deferred tax assets. In weighing the available evidence, more weight was placed upon our forecasts of future taxable income than on the history of pre-tax losses as such losses were generated under our prior UK business operating model which will no longer be in effect beginning with fiscal year 2026, and the guarantee of a positive operating margin as we effectuated an internal restructuring at the end of fiscal year 2025. Further, the most significant deferred tax asset in the UK is the net operating loss carryforward. Under UK tax law, net operating losses may be carried forward indefinitely, and we have considered the indefinite carryforward period to be positive evidence.
  (was, 2025-11-05, similarity 0.9979):
[0001628280-25-049073:note_history:16]
In the fourth quarter of fiscal 2025, we released $153.1 million of valuation allowances on our UK deferred tax assets after we considered all available positive and negative evidence related to our UK subsidiary.  We analyzed the UK subsidiary’s historical operating results, projected future taxable income, tax planning strategies, and reversals of deferred tax liabilities, and determined that the weight of available objectively verifiable positive evidence supported the realizability of the UK deferred tax assets. In weighing the available evidence, more weight was placed upon our forecasts of future taxable income than on the history of pre-tax losses as such losses were generated under our prior UK business operating model which will no longer be in effect beginning with fiscal year 2026, and the guarantee of a positive operating margin as we effectuated an internal restructuring at the end of fiscal year 2025. Further, the most significant deferred tax asset in the UK is the net operating loss carryforward. Under UK tax law, net operating losses may be carried forward indefinitely, and we have considered the indefinite carryforward period to be positive evidence.

- removed (2026-02-04):
[0001628280-25-049073:note_history:17]
Prior to fiscal year 2026, we operated in two reportable segments consisting of Cloud & Networking and Industrial Tech. During the first quarter of fiscal year 2026, the Company implemented a re-organization, under which it will be managed as a single, integrated enterprise, with a unified management team overseeing operations across the entire company, rather than through discrete operating segments. The chief operating decision maker (“CODM”) is the Company’s Chief Executive Officer, who reviews financial information presented as a single enterprise for purposes of allocating resources and evaluating financial performance. Accordingly, we determined we operate in a single reporting segment. Comparative prior period segment information has been updated to reflect the new segment structure and measures. The changes in our operating segments had no impact on our previously reported consolidated results of operations, financial position or cash flows. Refer to “Note 14. Operating Segments and Geographic Information” for more details.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2026-02-04):
[0001628280-26-005129:note_history:18]
The carrying amounts and estimated fair values of the convertible notes are as follows for the periods presented (in millions):

- added (2026-02-04):
[0001628280-26-005129:note_history:19]
|  | December 27, 2025 |  | June 28, 2025 |
|  | Carrying Amount |  | Estimated Fair Value |  | Carrying Amount |  | Estimated Fair Value |
| 2032 Notes | $ | 1,255.3 |  |  | $ | 2,840.8 |  |  | $ | — |  |  | $ | — |  |
| 2029 Notes | 600.6 |  |  | 3,400.1 |  |  | 600.2 |  |  | 925.5 |  |
| 2028 Notes | 858.3 |  |  | 2,584.6 |  |  | 857.7 |  |  | 890.2 |  |
| 2026 Notes | 468.3 |  |  | 1,844.6 |  |  | 1,048.3 |  |  | 1,233.3 |  |
|  | $ | 3,182.5 |  |  | $ | 10,670.1 |  |  | $ | 2,506.2 |  |  | $ | 3,049.0 |  |

- added (2026-02-04):
[0001628280-26-005129:note_history:20]
The table below summarizes the applicable conversion price and the equivalent 130% of the conversion price of each series of Notes  (per share amount):

- added (2026-02-04):
[0001628280-26-005129:note_history:21]
|  | Conversion Price |  | 130% of Conversion Price |
| 2032 Notes | $ | 187.77 |  |  | $ | 244.10 |  |
| 2029 Notes | 69.54 |  |  | 90.40 |  |
| 2028 Notes | 131.03 |  |  | 170.34 |  |
| 2026 Notes | 99.29 |  |  | 129.08 |  |

- changed (2026-02-04):
[0001628280-26-005129:note_history:22]
| December 27, 2025 | 2026 Notes |  | 2028 Notes |  | 2029 Notes |  | 2032 Notes |  | Total |  |  |  |  |  |
| Principal | $ | 468.8 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 1,265.0 |  |  | $ | 3,198.5 |  |  |  |  |  |  |
| Unamortized debt issuance costs | (0.5) |  |  | (2.7) |  |  | (3.1) |  |  | (9.7) |  |  | (16.0) |  |  |  |  |  |  |
| Net carrying amount of the liability component | $ | 468.3 |  |  | $ | 858.3 |  |  | $ | 600.6 |  |  | $ | 1,255.3 |  |  | $ | 3,182.5 |  |  |  |  |  |  |
  (was, 2025-11-05, similarity 0.8593):
[0001628280-25-049073:note_history:22]
| September 27, 2025 | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | 2032 Notes (4) |  | Total |  |  |  |  |  |
| Principal | $ | 468.9 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 1,265.0 |  |  | $ | 3,198.6 |  |  |  |  |  |  |
| Unamortized debt discount and debt issuance costs | (0.6) |  |  | (3.0) |  |  | (3.3) |  |  | (10.4) |  |  | (17.3) |  |  |  |  |  |  |
| Net carrying amount of the liability component | $ | 468.3 |  |  | $ | 858.0 |  |  | $ | 600.4 |  |  | $ | 1,254.6 |  |  | $ | 3,181.3 |  |  |  |  |  |  |

- changed (2026-02-04):
[0001628280-26-005129:note_history:23]
| June 28, 2025 |  |  | 2026 Notes |  | 2028 Notes |  | 2029 Notes |  | Total |
| Principal |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,514.7 |  |
| Unamortized debt issuance costs |  |  | (1.7) |  |  | (3.3) |  |  | (3.5) |  |  | (8.5) |  |
| Net carrying amount of the liability component |  |  | $ | 1,048.3 |  |  | $ | 857.7 |  |  | $ | 600.2 |  |  | $ | 2,506.2 |  |
  (was, 2025-11-05, similarity 0.8805):
[0001628280-25-049073:note_history:23]
| June 28, 2025 |  |  | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | Total |
| Principal |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,514.7 |  |
| Unamortized debt discount and debt issuance costs |  |  | (1.7) |  |  | (3.3) |  |  | (3.5) |  |  | (8.5) |  |
| Net carrying amount of the liability component |  |  | $ | 1,048.3 |  |  | $ | 857.7 |  |  | $ | 600.2 |  |  | $ | 2,506.2 |  |

- removed (2026-02-04):
[0001628280-25-049073:note_history:24]
(1) If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future fiscal quarter, our 2026 Notes would become convertible at the option of the holders during the subsequent fiscal quarter, which was the case as of the end of the first quarter of fiscal year 2026, and therefore, the debt was reclassified to current liabilities in our condensed consolidated balance sheets.

- removed (2026-02-04):
[0001628280-25-049073:note_history:25]
(2) If the closing price of our stock exceeds $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of any future fiscal quarter, our 2028 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheets.

- removed (2026-02-04):
[0001628280-25-049073:note_history:26]
(3) If the closing price of our stock exceeds $90.40 (or 130% of the conversion price of $69.54) for 20 of the last 30 trading days of any future quarter, our 2029 Notes would become convertible at the option of the holders during the subsequent fiscal quarter, which was the case as of the end of the first quarter of fiscal year 2026, and therefore, the debt was reclassified to current liabilities in our consolidated balance sheets.

- removed (2026-02-04):
[0001628280-25-049073:note_history:27]
(4) If the closing price of our stock exceeds $244.10 (or 130% of the conversion price of $187.77) for 20 of the last 30 trading days of any future quarter, our 2032 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our consolidated balance sheets.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-02-04):
[0001628280-26-005129:note_history:28]
|  | December 27, 2025 |  | June 28, 2025 |
|  | Short-term |  | Long-term |  | Total |  | Short-term |  | Long-term |  | Total |
| Convertible notes (1) | $ | 3,182.5 |  |  | $ | — |  |  | $ | 3,182.5 |  |  | $ | — |  |  | $ | 2,506.2 |  |  | $ | 2,506.2 |  |
| Term loans | 57.7 |  |  | 47.1 |  |  | 104.8 |  |  | 10.6 |  |  | 56.4 |  |  | 67.0 |  |
| Total | $ | 3,240.2 |  |  | $ | 47.1 |  |  | $ | 3,287.3 |  |  | $ | 10.6 |  |  | $ | 2,562.6 |  |  | $ | 2,573.2 |  |
  (was, 2025-11-05, similarity 0.9177):
[0001628280-25-049073:note_history:28]
|  | September 27, 2025 |  | June 28, 2025 |
|  | Short-term |  | Long-term |  | Total |  | Short-term |  | Long-term |  | Total |
| Convertible notes | $ | 1,068.7 |  |  | $ | 2,112.6 |  |  | $ | 3,181.3 |  |  | $ | — |  |  | $ | 2,506.2 |  |  | $ | 2,506.2 |  |
| Term loans | 10.3 |  |  | 51.9 |  |  | 62.2 |  |  | 10.6 |  |  | 56.4 |  |  | 67.0 |  |
| Total | $ | 1,079.0 |  |  | $ | 2,164.5 |  |  | $ | 3,243.5 |  |  | $ | 10.6 |  |  | $ | 2,562.6 |  |  | $ | 2,573.2 |  |

- added (2026-02-04):
[0001628280-26-005129:note_history:29]
(1) Since the closing price of our stock was at least 130% of the applicable conversion price for each series of Notes for 20 of the last 30 trading days of our second quarter of fiscal year 2026, all of our Notes became convertible at the option of the holders during the third quarter of fiscal year 2026. The outstanding Notes are recorded as short-term debt, which is presented as current liabilities in our condensed consolidated balance sheets as of December 27, 2025, net of unamortized debt issuance costs. If the Notes are converted by holders, we are required to satisfy our conversion obligations with respect to each series of converted Notes by paying cash equal to the principal amount of such series of converted Notes and paying or delivering, as the case may be, cash, shares of common stock, or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof. The outstanding Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of June 28, 2025, net of unamortized debt issuance costs.

- added (2026-02-04):
[0001628280-26-005129:note_history:30]
The table below summarizes the applicable conversion price and the equivalent 130% of the conversion price of each series of Notes  (per share amount):

- added (2026-02-04):
[0001628280-26-005129:note_history:31]
|  | Conversion Price |  | 130% of Conversion Price |
| 2032 Notes | $ | 187.77 |  |  | $ | 244.10 |  |
| 2029 Notes | 69.54 |  |  | 90.40 |  |
| 2028 Notes | 131.03 |  |  | 170.34 |  |
| 2026 Notes | 99.29 |  |  | 129.08 |  |

- changed (2026-02-04):
[0001628280-26-005129:note_history:32]
On September 8, 2025, we issued $1,265.0 million in aggregate principal amount of 0.375% Convertible Senior Notes due in 2032 (“2032 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2032 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association, as trustee (the “2032 Indenture”). The 2032 Notes are unsecured, rank equally with all of the Company’s existing senior unsecured indebtedness, including the Company’s outstanding 0.50% Convertible Senior Notes due 2026, 0.50% Convertible Senior Notes due 2028, and 1.50% Convertible Senior Notes due 2029, and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.
  (was, 2025-11-05, similarity 0.8197):
[0001628280-25-049073:note_history:32]
On September 8, 2025, we issued $1,265.0 million in aggregate principal amount of 0.375% Convertible Senior Notes due in 2032 (“2032 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended. The 2032 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association, as trustee (the “2032 Indenture”). The 2032 Notes are unsecured, rank equally with all of the Company’s existing senior unsecured indebtedness, including the Company’s outstanding 0.50% Convertible Senior Notes due 2026, 0.50% Convertible Senior Notes due 2028, and 1.50% Convertible Senior Notes due 2029, and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

- changed (2026-02-04):
[0001628280-26-005129:note_history:33]
The net proceeds from the sale of the 2032 Notes was approximately $1,254.7 million, after deducting $10.3 million of debt issuance costs. Concurrent with the issuance of the 2032 Notes, we used $843.1 million of the net proceeds to repurchase $581.1 million aggregate principal amount of the 0.50% Convertible Senior Notes due in 2026 and $102.0 million of the net proceeds to pay the cost of the 2032 Capped Call Options. We intend to use the remaining net proceeds for general corporate purposes, which may include the repayment or repurchase of our indebtedness, including any of our existing convertible notes, capital expenditures, working capital and potential acquisitions.
  (was, 2025-11-05, similarity 0.8369):
[0001628280-25-049073:note_history:33]
The net proceeds from the sale of the 2032 Notes was approximately $1,255.7 million, after deducting $9.3 million of net issuance costs. In addition, we incurred $1.1 million of professional fees directly related to this transaction, which was recorded as part of accrued expenses in our condensed consolidated balance sheets as of September 27, 2025. Concurrent with the issuance of the 2032 Notes, we used $843.1 million of the net proceeds to repurchase $581.1 million aggregate principal amount of the 0.50% Convertible Senior Notes due in 2026 and $102.0 million of the net proceeds to pay the cost of the 2032 Capped Call Options. We intend to use the remaining net proceeds for general corporate purposes, which may include the repayment or repurchase of our indebtedness, including any of our existing convertible notes, capital expenditures, working capital and potential acquisitions.

- added (2026-02-04):
[0001628280-26-005129:note_history:34]
Since the closing price of our stock exceeded $244.10 (or 130% of the conversion price of $187.77) for 20 of the last 30 trading days of our second quarter of fiscal year 2026, our 2032 Notes became convertible at the option of the holders during the third quarter of fiscal year 2026. Upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2032 Notes by paying cash equal to the principal amount of such converted 2032 Notes and paying or delivering, as the case may be, cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof, if any. Therefore, the entire aggregate principal amount of the 2032 Notes outstanding is recorded as short-term debt, which is presented as a current liability in our consolidated balance sheets as of December 27, 2025, net of unamortized debt issuance costs.

- changed (2026-02-04):
[0001628280-26-005129:note_history:35]
Each of the 2032 Capped Call Options was executed pursuant to a separate agreement entered into by the Company and each of the 2032 Capped Call Counterparties. The 2032 Capped Call Options are not part of the terms of the 2032 Notes and will not affect any holder’s rights under the 2032 Notes. Holders of the 2032 Notes will not have any rights with respect to the 2032 Capped Call Options. The Company concluded that the 2032 Capped Call Options met the criteria for equity classification because they were indexed to the Company’s common stock and the Company has the discretion to settle the 2032 Capped Call Options by the Company receiving shares or cash subsequent to March 20, 2029. As a result, the $102.0 million amount paid was recorded as a reduction to additional paid-in capital within the Company’s condensed consolidated balance sheets as of December 27, 2025, along with the offsetting associated current tax impact of $1.1 million.
  (was, 2025-11-05, similarity 0.6916):
[0001628280-25-049073:note_history:35]
Each of the 2032 Capped Call Options was executed pursuant to a separate agreement entered into by the Company and each of the 2032 Capped Call Counterparties. The 2032 Capped Call Options are not part of the terms of the 2032 Notes and will not affect any holder’s rights under the 2032 Notes. Holders of the 2032 Notes will not have any rights with respect to the 2032 Capped Call Options. The Company concluded that the 2032 Capped Call Options met the criteria for equity classification because they were indexed to the Company’s common stock and the Company has the discretion to settle the 2032 Capped Call Options in shares or cash. As a result, the $102.0 million amount paid was recorded as a reduction to additional paid-in capital within the Company’s condensed consolidated balance sheets as of September 27, 2025, along with the offsetting associated current tax impact of $0.2 million.

- changed (2026-02-04):
[0001628280-26-005129:note_history:36]
The Company made a tax election to integrate the 2032 Notes and the 2032 Capped Call Options for federal income tax purposes pursuant to applicable U.S. Treasury Regulations. Accordingly, the $102.0 million gross cost of the purchased 2032 Capped Call Options will be deductible for income tax purposes as original issue discount interest over the term of the 2032 Notes. As a result, the Company established a deferred income tax asset of $24.5 million at inception, with a corresponding valuation allowance as it is not more-likely-than-not that our U.S. deferred tax assets are realizable in the future. As of December 27, 2025, we have recognized a current tax impact of $1.1 million at issuance, which is recorded as an increase to additional paid-in capital within the Company’s condensed consolidated balance sheets.
  (was, 2025-11-05, similarity 0.9956):
[0001628280-25-049073:note_history:36]
The Company made a tax election to integrate the 2032 Notes and the 2032 Capped Call Options for federal income tax purposes pursuant to applicable U.S. Treasury Regulations. Accordingly, the $102.0 million gross cost of the purchased 2032 Capped Call Options will be deductible for income tax purposes as original issue discount interest over the term of the 2032 Notes. As a result, the Company established a deferred income tax asset of $21.4 million at inception, with a corresponding valuation allowance as it is not more-likely-than-not that our U.S. deferred tax assets are realizable in the future. As of September 27, 2025, we have recognized a current tax impact of  $0.2 million at issuance, which is recorded as an increase to additional paid-in capital within the Company’s condensed consolidated balance sheets.

- changed (2026-02-04):
[0001628280-26-005129:note_history:37]
On June 16, 2023, we issued $603.7 million in aggregate principal amount of 1.50% Convertible Senior Notes due in 2029 (“2029 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2029 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association, as trustee (the “2029 Indenture”). The 2029 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.
  (was, 2025-11-05, similarity 0.9859):
[0001628280-25-049073:note_history:37]
On June 16, 2023, we issued $603.7 million in aggregate principal amount of 1.50% Convertible Senior Notes due in 2029 (“2029 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended. The 2029 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association, as trustee (the “2029 Indenture”). The 2029 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

- added (2026-02-04):
[0001628280-26-005129:note_history:38]
Since the closing price of our stock exceeded $90.40 (or 130% of the conversion price of $69.54) for 20 of the last 30 trading days of our first and second quarters of fiscal year 2026, our 2029 Notes became convertible at the option of the holders during the second and third quarters of fiscal year 2026. Following our irrevocable settlement method election made on September 25, 2024, upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2029 Notes by paying cash equal to the principal amount of such converted 2029 Notes and paying or delivering, as the case may be, cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof. Therefore, the entire aggregate principal amount of the 2029 Notes outstanding is recorded as short-term debt, which is presented as a current liability in our consolidated balance sheets as of December 27, 2025, net of unamortized debt issuance costs, while the entire aggregate principal amount of the 2029 Notes outstanding is recorded as convertible notes, non-current in our consolidated balance sheets as of June 28, 2025, net of unamortized debt issuance costs.

- changed (2026-02-04):
[0001628280-26-005129:note_history:39]
In March 2022, we issued $861.0 million in aggregate principal amount of 0.50% Convertible Senior Notes due in 2028 (the “2028 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2028 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association, as trustee (the “2028 Indenture”). The 2028 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.
  (was, 2025-11-05, similarity 0.6822):
[0001628280-25-049073:note_history:39]
In March 2022, we issued $861.0 million in aggregate principal amount of 0.50% Convertible Senior Notes due in 2028 (the “2028 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2028 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association, as trustee (the “2028 Indenture”). The 2028 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

- changed (2026-02-04):
[0001628280-26-005129:note_history:40]
On or after March 15, 2028 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2028 Notes at any time. Following our irrevocable settlement method election made on September 25, 2024, upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2028 Notes by paying cash equal to the principal amount of such converted 2028 Notes and paying or delivering, as the case may be, cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof, if any.
  (was, 2025-11-05, similarity 0.9992):
[0001628280-25-049073:note_history:40]
On or after March 15, 2028 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2028 Notes at any time. Following our irrevocable settlement method election made on September 25, 2024, upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2028 Notes by paying cash equal to the principal amount of such converted 2028 Notes and paying or delivering, as the case may be, cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof,if any.

- changed (2026-02-04):
[0001628280-26-005129:note_history:41]
We initially bifurcated the principal amount of the 2028 Notes into liability and equity components. The liability component of the 2028 Notes was initially valued at $629.8 million based on the contractual cash flow discounted at an appropriate comparable market on non-convertible debt borrowing rate at the date of issuance, which was 5.7%, with the equity component representing the residual amount of the proceeds of $231.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal year 2023, our 2028 Notes were accounted for as a single liability, net of unamortized debt issuance costs.
  (was, 2025-11-05, similarity 0.7721):
[0001628280-25-049073:note_history:41]
We initially bifurcated the principal amount of the 2028 Notes into liability and equity components. The liability component of the 2028 Notes was initially valued at $629.8 million based on the contractual cash flow discounted at an appropriate comparable market on non-convertible debt borrowing rate at the date of issuance, which was 5.7%, with the equity component representing the residual amount of the proceeds of $231.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2028 Notes were accounted for as a single liability measured at amortized cost. The entire 2028 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of September 27, 2025 and June 28, 2025, measured at amortized cost.

- added (2026-02-04):
[0001628280-26-005129:note_history:42]
Since the closing price of our stock exceeded $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of our second quarter of fiscal year 2026, our 2028 Notes became convertible at the option of the holders during the third quarter of fiscal year 2026. Following our irrevocable settlement method election made on September 25, 2024, upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2028 Notes by paying cash equal to the principal amount of such converted 2028 Notes and paying or delivering, as the case may be, cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof, if any. Therefore, the entire aggregate principal amount of the 2028 Notes outstanding is recorded as short-term debt, which is presented as a current liability in our consolidated balance sheets as of December 27, 2025, net of unamortized debt issuance costs, while the entire aggregate principal amount of the 2028 Notes outstanding is recorded as convertible notes, non-current in our consolidated balance sheets as of June 28, 2025, net of unamortized debt issuance costs.

- added (2026-02-04):
[0001628280-26-005129:note_history:43]
During the quarter ended December 27, 2025, we received conversion requests of $0.1 million of principal for the 2026 Notes, which we settled with a combination of $0.1 million of cash and an immaterial number of shares of our common stock in accordance with the 2026 Indenture.

- changed (2026-02-04):
[0001628280-26-005129:note_history:44]
We initially bifurcated the principal amount of the 2026 Notes into liability and equity components. The liability component of the 2026 Notes was initially valued at $734.8 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 5.8% with the equity component representing the residual amount of the proceeds of $315.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal year 2023, our 2026 Notes were accounted for as a single liability, net of unamortized debt issuance costs.
  (was, 2025-11-05, similarity 0.9564):
[0001628280-25-049073:note_history:44]
We initially bifurcated the principal amount of the 2026 Notes into liability and equity components. The liability component of the 2026 Notes was initially valued at $734.8 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 5.8% with the equity component representing the residual amount of the proceeds of $315.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2026 Notes were accounted for as a single liability measured at amortized cost.

- changed (2026-02-04):
[0001628280-26-005129:note_history:45]
Concurrent with the issuance of the 2032 Notes, we used approximately $843.1 million of the net proceeds to repurchase $581.1 million aggregate principal amount of the 2026 Notes. We also paid $0.7 million of the related accrued interest. We have adopted and applied ASU 2024-04, Debt with Conversion and Other Options: Induced Conversions of Convertible Debt Instruments. We determined that this transaction met the requirements for the settlement of debt as an induced conversion. Accordingly, we recorded $256.9 million, which represents the fair value increase in the fair value of the debt, as a reduction to additional paid-in capital within the Company’s consolidated Balance Sheets as of December 27, 2025, and recognized an inducement expense of $5.9 million in our consolidated statements of operations during the three and six months ended December 27, 2025, which represents the excess of fair value of the total consideration over the fair value of securities issuable pursuant to the original conversion terms.
  (was, 2025-11-05, similarity 0.8564):
[0001628280-25-049073:note_history:45]
Concurrent with the issuance of the 2032 Notes, we used approximately $843.1 million of the net proceeds to repurchase $581.1 million aggregate principal amount of the 2026 Notes. We also paid $0.7 million of the related accrued interest. We have adopted and applied ASU 2024-04, Debt with Conversion and Other Options: Induced Conversions of Convertible Debt Instruments. We determined that this transaction met the requirements for the settlement of debt as an induced conversion. Accordingly, we recorded $256.9 million, which represents the fair value increase in the fair value of the debt, as a reduction to additional paid-in capital within the Company’s consolidated Balance Sheets as of September 27, 2025, and recognized an inducement expense of $5.9 million in our consolidated statements of operations during the three months ended September 27, 2025, which represents the excess of fair value of the total consideration over the fair value of securities issuable pursuant to the original conversion terms.

- added (2026-02-04):
[0001628280-26-005129:note_history:46]
Since the closing price of our stock exceeded $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of our first and second quarters of fiscal year 2026, our 2026 Notes became convertible at the option of the holders during the second and third quarters of fiscal year 2026. Following our entry into the First Supplemental Indenture, dated as of September 25, 2024, to the 2026 Indenture, upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2026 Notes by paying cash equal to the principal amount of such converted 2026 Notes and paying or delivering, as the case may be, cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof, if any. Therefore, the remaining 2026 Notes outstanding are recorded as short-term debt, which is presented as current liabilities in our consolidated balance sheets as of December 27, 2025, net of unamortized debt issuance costs. The entire aggregate amount of the 2026 Notes outstanding is recorded as convertible notes, non-current in our consolidated balance sheets as of June 28, 2025, net of unamortized debt issuance costs.

- changed (2026-02-04):
[0001628280-26-005129:note_history:47]
| December 27, 2025 | 2026 Notes |  | 2028 Notes |  | 2029 Notes |  | 2032 Notes |  | Total |  |  |  |  |  |
| Principal | $ | 468.8 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 1,265.0 |  |  | $ | 3,198.5 |  |  |  |  |  |  |
| Unamortized debt issuance costs | (0.5) |  |  | (2.7) |  |  | (3.1) |  |  | (9.7) |  |  | (16.0) |  |  |  |  |  |  |
| Net carrying amount of the liability component | $ | 468.3 |  |  | $ | 858.3 |  |  | $ | 600.6 |  |  | $ | 1,255.3 |  |  | $ | 3,182.5 |  |  |  |  |  |  |
  (was, 2025-11-05, similarity 0.8593):
[0001628280-25-049073:note_history:47]
| September 27, 2025 | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | 2032 Notes (4) |  | Total |  |  |  |  |  |
| Principal | $ | 468.9 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 1,265.0 |  |  | $ | 3,198.6 |  |  |  |  |  |  |
| Unamortized debt discount and debt issuance costs | (0.6) |  |  | (3.0) |  |  | (3.3) |  |  | (10.4) |  |  | (17.3) |  |  |  |  |  |  |
| Net carrying amount of the liability component | $ | 468.3 |  |  | $ | 858.0 |  |  | $ | 600.4 |  |  | $ | 1,254.6 |  |  | $ | 3,181.3 |  |  |  |  |  |  |

- changed (2026-02-04):
[0001628280-26-005129:note_history:48]
| June 28, 2025 |  |  | 2026 Notes |  | 2028 Notes |  | 2029 Notes |  | Total |
| Principal |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,514.7 |  |
| Unamortized debt issuance costs |  |  | (1.7) |  |  | (3.3) |  |  | (3.5) |  |  | (8.5) |  |
| Net carrying amount of the liability component |  |  | $ | 1,048.3 |  |  | $ | 857.7 |  |  | $ | 600.2 |  |  | $ | 2,506.2 |  |
  (was, 2025-11-05, similarity 0.8805):
[0001628280-25-049073:note_history:48]
| June 28, 2025 |  |  | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | Total |
| Principal |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,514.7 |  |
| Unamortized debt discount and debt issuance costs |  |  | (1.7) |  |  | (3.3) |  |  | (3.5) |  |  | (8.5) |  |
| Net carrying amount of the liability component |  |  | $ | 1,048.3 |  |  | $ | 857.7 |  |  | $ | 600.2 |  |  | $ | 2,506.2 |  |

- added (2026-02-04):
[0001628280-26-005129:note_history:49]
|  | Three Months Ended |  | Six Months Ended |
|  | December 27, 2025 |  | December 28, 2024 |  | December 27, 2025 |  | December 28, 2024 |
| Contractual interest expense | $ | 5.0 |  |  | $ | 4.6 |  |  | $ | 9.7 |  |  | $ | 9.3 |  |
| Amortization of debt issuance costs | 1.1 |  |  | 0.8 |  |  | 1.9 |  |  | 1.5 |  |
| Total interest expense | $ | 6.1 |  |  | $ | 5.4 |  |  | $ | 11.6 |  |  | $ | 10.8 |  |

- changed (2026-02-04):
[0001628280-26-005129:note_history:50]
The future interest and principal payments related to our convertible notes are as follows as of December 27, 2025 (in millions):
  (was, 2025-11-05, similarity 0.9799):
[0001628280-25-049073:note_history:50]
The future interest and principal payments related to our convertible notes are as follows as of September 27, 2025 (in millions):

- changed (2026-02-04):
[0001628280-26-005129:note_history:51]
On August 9, 2024, the Company entered into a term loan agreement (the “SMBC 2029 Term Loan”) with Sumitomo Mitsui Banking Corporation (“SMBC”). The SMBC Term Loan provides an aggregate principal amount of 6.4 billion Japanese yen (“JPY”). The loan requires monthly principal payments of approximately 53.3 million JPY, from August 31, 2024 to June 30, 2029 and interest based on a fixed annual interest rate of 0.88%, with the remaining principal of approximately 3.3 billion JPY due on the loan maturity date of July 31, 2029. Under the loan agreement, the Company cannot prepay the outstanding loan without SMBC’s approval. In the event the Company prepays the outstanding loan with SMBC’s approval, the Company shall pay SMBC a settlement amount calculated pursuant to the terms of the loan agreement. The SMBC Term Loan is secured by the real estate owned in Sagamihara, Japan.
  (was, 2025-11-05, similarity 0.9988):
[0001628280-25-049073:note_history:51]
On August 9, 2024, the Company entered into a term loan agreement (the “SMBC Term Loan”) with Sumitomo Mitsui Banking Corporation (“SMBC”). The SMBC Term Loan provides an aggregate principal amount of 6.4 billion Japanese yen (“JPY”). The loan requires monthly principal payments of approximately 53.3 million JPY, from August 31, 2024 to June 30, 2029 and interest based on a fixed annual interest rate of 0.88%, with the remaining principal of approximately 3.3 billion JPY due on the loan maturity date of July 31, 2029. Under the loan agreement, the Company cannot prepay the outstanding loan without SMBC’s approval.  In the event the Company prepays the outstanding loan with SMBC’s approval, the Company shall pay SMBC a settlement amount calculated pursuant to the terms of the loan agreement. The SMBC Term Loan is secured by the real estate owned in Sagamihara, Japan.

- added (2026-02-04):
[0001628280-26-005129:note_history:52]
On December 18, 2025, the Company entered into another term loan agreement (the “SMBC 2026 Term Loan”) with SMBC. The SMBC 2026 Term Loan provides an aggregate principal amount of 7.5 billion JPY. The loan requires monthly principal payments of 125.0 million JPY and interest based on a fixed annual interest rate of 1.44%, with the remaining principal of approximately 6.1 billion JPY due on the loan maturity date of December 19, 2026, subject to repayment pitch of 60 months. Under the loan agreement, the Company cannot prepay the outstanding loan without SMBC’s approval. In the event the Company prepays the outstanding loan with SMBC’s approval, the Company shall pay SMBC a settlement amount calculated pursuant to the terms of the loan agreement. The SMBC Term Loan is secured by the real estate owned in Sagamihara, Japan.

- added (2026-02-04):
[0001628280-26-005129:note_history:53]
The SMBC 2029 Term Loan and the SMBC 2026 Term Loan are collectively referred to as SMBC Term Loans. The SMBC Term Loans require the Company to maintain a debt service coverage ratio of at least 1.2 for its Japan entity for fiscal year 2026. The SMBC 2026 Term Loan requires the Company to maintain a U.S. dollar deposit account with a balance, translated into JPY, equal to or greater than the outstanding principal amount of the SMBC 2026 Term Loan.

- changed (2026-02-04):
[0001628280-26-005129:note_history:54]
As of December 27, 2025, the Company had $83.3 million in principal amount outstanding in SMBC Term Loans, of which the short-term portion of $52.0 million is recorded as current liabilities while the long-term portion of $31.3 million is recorded as long-term debt in the Company’s condensed consolidated balance sheets.
  (was, 2025-11-05, similarity 0.9562):
[0001628280-25-049073:note_history:54]
As of September 27, 2025, the Company had $38.2 million in principal amount outstanding, of which the short-term portion of $4.3 million is recorded as current liabilities while the long-term portion of $33.9 million is recorded as long-term debt in the Company’s condensed consolidated balance sheets.

- changed (2026-02-04):
[0001628280-26-005129:note_history:55]
On September 20, 2024, the Company entered into a term loan agreement (the “Mizuho Term Loan”) with Mizuho Bank, Ltd. (“Mizuho”), in order to finance our planned manufacturing expansions. The Mizuho Term Loan provides for borrowings of 4.5 billion JPY with a 5-year term from the funding date September 20, 2024. The loan requires quarterly principal payments of approximately 225.0 million JPY commencing on December 20, 2024 with the final payment on September 20, 2029. The Mizuho Term Loan bears interest at a fixed annual rate of 0.90%. The Mizuho Term Loan is secured by the real estate assets owned by NeoPhotonics Semiconductor GK. The Mizuho Term Loan agreement requires that the Company and certain domestic subsidiaries comply with covenants relating to customary matters, including obtaining approval from Mizuho prior to transferring, creating a security interest, or disposing of the collateral assets; obtaining approval from Mizuho prior to a business transfer, business acquisition, corporate reorganization or changes such as mergers, company splits, share exchanges or share transfers or capital structure changes; obtaining approval from Mizuho prior to changing the Company’s indirect ownership in Lumentum Japan, Inc; and obtaining approval from Mizuho prior to a distribution of dividends by Lumentum Japan, Inc. to its shareholders. In addition, under the Mizuho Term Loan, the Company is committed to maintain a certain balance in U.S. dollar time and savings deposit accounts.
  (was, 2025-11-05, similarity 0.9477):
[0001628280-25-049073:note_history:55]
On September 20, 2024, the Company entered into a term loan agreement (the “Mizuho Term Loan”) with Mizuho Bank, Ltd. (“Mizuho”), in order to finance our planned manufacturing expansions. The Mizuho Term Loan provides for borrowings of 4.5 billion JPY with a 5-year term from the funding date September 20, 2024. The loan requires quarterly principal payments of approximately 225.0 million JPY commencing on December 20, 2024 with the final payment on September 20, 2029. The Mizuho Term Loan bears interest at a fixed annual rate of 0.90%. The Mizuho Term Loan is secured by the real estate assets owned by NeoPhotonics Semiconductor GK. The Mizuho Term Loan agreement requires that the Company and certain domestic subsidiaries comply with covenants relating to customary matters, including obtaining approval from Mizuho prior to transferring, creating a security interest, or disposing of the collateral assets; obtaining approval from Mizuho prior to a business transfer, business acquisition, corporate reorganization or changes such as mergers, company splits, share exchanges or share transfers or capital structure changes; obtaining approval from Mizuho prior to changing the Company’s indirect ownership in Lumentum Japan, Inc; and obtaining approval from Mizuho prior to a distribution of dividends by Lumentum Japan, Inc. to its shareholders.

- changed (2026-02-04):
[0001628280-26-005129:note_history:56]
As of December 27, 2025, the Company had $21.5 million in principal amount outstanding, of which the short-term portion of $5.7 million is recorded as current liabilities while the long-term portion of $15.8 million is recorded as long-term debt in the Company’s condensed consolidated balance sheets.
  (was, 2025-11-05, similarity 0.849):
[0001628280-25-049073:note_history:56]
As of September 27, 2025, the Company had $24.0 million in principal amount outstanding, of which the short-term portion of $6.0 million is recorded as current liabilities while the long-term portion of $18.0 million is recorded as long-term debt in the Company’s condensed consolidated balance sheets.
The SMBC Term Loan and the Mizuho Term Loan are collectively referred to as Japan Term Loans.

- added (2026-02-04):
[0001628280-26-005129:note_history:57]
The SMBC Term Loan and the Mizuho Term Loan are collectively referred to as Japan Term Loans.

- added (2026-02-04):
[0001628280-26-005129:note_history:58]
Revolving Credit Facility

- added (2026-02-04):
[0001628280-26-005129:note_history:59]
On December 19, 2025, the Company entered into a credit agreement (the “Credit Agreement”) with the lenders party thereto and Wells Fargo Bank, National Association, as administrative and collateral agent. The Credit Agreement provides for a senior secured revolving credit facility in an aggregate principal amount of $400.0 million, including a $23.0 million sublimit for the issuance of letters of credit. The Credit Agreement provides that the Company has the right at any time and from time to time to incur one or more incremental revolving commitments and/or incremental term loans up to an unlimited amount, subject to certain customary conditions precedent and other requirements. The proceeds of the loans under the Credit Agreement may be used for working capital and general corporate purposes.

- added (2026-02-04):
[0001628280-26-005129:note_history:60]
Revolving loans under the Credit Agreement may be borrowed, repaid and reborrowed, without premium or penalty (subject to customary breakage costs), until their maturity date under the Credit Agreement, at which time all amounts borrowed must be repaid. Revolving loans under the Credit Agreement will mature on December 19, 2030, subject to earlier maturity on the date that is 91 days prior to the final scheduled maturity date of the Company’s existing outstanding convertible notes, if on such date, the Company is unable to satisfy certain liquidity and/or total net leverage requirements.

- added (2026-02-04):
[0001628280-26-005129:note_history:61]
At the Company’s option, borrowings bear interest at either a base rate plus an applicable margin ranging from 0.50% to 1.50%, or a term Secured Overnight Financing Rate (“SOFR”) plus a margin ranging from 1.50% to 2.50%, in each case with such margin based upon the Company’s secured net leverage ratio, as determined in accordance with the terms of the Credit Agreement. Interest is payable quarterly in arrears with respect to borrowings bearing interest at the alternate base rate or on the last day of an interest period, but at least every three months, with respect to borrowings bearing interest at a term SOFR rate. The Company is required to pay to the Administrative Agent for the account of each Lender a commitment fee on a quarterly basis in an amount equal to 0.15% to 0.35% (depending on the Company’s secured net leverage ratio) of unused availability under the revolving facility. The Company is also obligated to pay other fees customary for revolving credit facilities of this size and type.

- added (2026-02-04):
[0001628280-26-005129:note_history:62]
The Credit Agreement contains customary representations, warranties, affirmative and negative covenants, and events of default. The negative covenants include, among others, restrictions on liens, investments, indebtedness, fundamental changes, restricted payments, transactions with affiliates and prepayments of subordinated debt, all subject to certain exceptions. In addition, the Credit Agreement contains financial covenants, tested at the end of each fiscal quarter, requiring the Company to maintain a secured net leverage ratio of less than or equal to 3.25:1.00, subject to a 0.50:1.00 step-up for four fiscal quarters in connection with a material acquisition, and an interest coverage ratio of no less than 3.00:1.00.

- added (2026-02-04):
[0001628280-26-005129:note_history:63]
The obligations under the Credit Agreement are required to be guaranteed by certain of the Company’s material domestic subsidiaries and are secured by substantially all assets of the Company and such subsidiary guarantors, subject to customary exceptions.

- added (2026-02-04):
[0001628280-26-005129:note_history:64]
As of December 27, 2025, there were no borrowings outstanding under the revolving credit facility.

- added (2026-02-04):
[0001628280-26-005129:note_history:65]
The Company incurred financing costs of about $2.5 million in connection with the revolving credit facility, which was presented as other non-current assets in the Company’s condensed consolidated balance sheets as of December 27, 2025 and are amortized to interest expense over the term of the facility.

- removed (2026-02-04):
[0001628280-25-049073:note_history:66]
The entirety of the 2032 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of September 27, 2025, measured at amortized cost.

- removed (2026-02-04):
[0001628280-25-049073:note_history:67]
Since the closing price of our stock exceeded $90.40 (or 130% of the conversion price of $69.54) for 20 of the last 30 trading days of our first quarter of fiscal year 2026, our 2029 Notes became convertible at the option of the holders during the second quarter of fiscal year 2026, thus, the entire 2029 Notes are recorded as short-term debt, which is presented as current liabilities in our consolidated balance sheets as of September 27, 2025, measured at amortized cost, while the entire 2029 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of June 28, 2025, measured at amortized cost.

- removed (2026-02-04):
[0001628280-25-049073:note_history:68]
Since the closing price of our stock exceeded $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of our first quarter of fiscal year, our 2026 Notes became convertible at the option of the holders during the second quarter of fiscal year 2026, thus, the remaining 2026 Notes outstanding are recorded as short-term debt, which is presented as current liabilities in our consolidated balance sheets as of September 27, 2025, measured at amortized cost. The entire 2026 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of June 28, 2025, measured at amortized cost.

- removed (2026-02-04):
[0001628280-25-049073:note_history:69]
(1) If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future fiscal quarter, our 2026 Notes would become convertible at the option of the holders during the subsequent fiscal quarter, which was the case as of the end of the first quarter of fiscal year 2026, and therefore, the debt was reclassified to current liabilities in our condensed consolidated balance sheets.

- removed (2026-02-04):
[0001628280-25-049073:note_history:70]
(2) If the closing price of our stock exceeds $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of any future fiscal quarter, our 2028 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheets.

- removed (2026-02-04):
[0001628280-25-049073:note_history:71]
(3) If the closing price of our stock exceeds $90.40 (or 130% of the conversion price of $69.54) for 20 of the last 30 trading days of any future quarter, our 2029 Notes would become convertible at the option of the holders during the subsequent fiscal quarter, which was the case as of the end of the first quarter of fiscal year 2026, and therefore, the debt was reclassified to current liabilities in our consolidated balance sheets.

- removed (2026-02-04):
[0001628280-25-049073:note_history:72]
(4) If the closing price of our stock exceeds $244.10 (or 130% of the conversion price of $187.77) for 20 of the last 30 trading days of any future quarter, our 2032 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our consolidated balance sheets.

- removed (2026-02-04):
[0001628280-25-049073:note_history:73]
|  | Three Months Ended |  |  |
|  | September 27, 2025 |  | September 28, 2024 |  |  |  |  |
| Contractual interest expense | $ | 4.7 |  |  | $ | 4.7 |  |  |  |  |  |
| Amortization of the debt discount and debt issuance costs | 0.8 |  |  | 0.7 |  |  |  |  |  |
| Total interest expense | $ | 5.5 |  |  | $ | 5.4 |  |  |  |  |  |


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-02-04):
[0001628280-26-005129:note_history:74]
|  | Continuous Loss Position for More Than 12 Months |  | Continuous Loss Position for Less Than 12 Months |  | Gross Unrealized Losses |  |  |  |  |  |  |  |  |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |  |
| December 27, 2025: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | — |  |  | $ | — |  |  | $ | 68.4 |  |  | $ | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 9.9 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 1.0 |  |  | — |  |  | 69.2 |  |  | (0.1) |  |  | (0.1) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | — |  |  | — |  |  | 3.5 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | 1.0 |  |  | $ | — |  |  | $ | 151.0 |  |  | $ | (0.1) |  |  | $ | (0.1) |  |  |  |  |  |  |  |  |  |
| June 28, 2025: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | — |  |  | $ | — |  |  | $ | 24.5 |  |  | $ | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 5.2 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | — |  |  | — |  |  | 73.8 |  |  | (0.1) |  |  | (0.1) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | — |  |  | — |  |  | 35.3 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | — |  |  | $ | — |  |  | $ | 138.8 |  |  | $ | (0.1) |  |  | $ | (0.1) |  |  |  |  |  |  |  |  |  |
  (was, 2025-11-05, similarity 0.8787):
[0001628280-25-049073:note_history:74]
|  | Continuous Loss Position for More Than 12 Months |  | Continuous Loss Position for Less Than 12 Months |  | Gross Unrealized Losses |  |  |  |  |  |  |  |  |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |  |
| September 27, 2025: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 16.0 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 2.7 |  |  | — |  |  | — |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 32.5 |  |  | (0.1) |  |  | 3.0 |  |  | — |  |  | (0.1) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 20.0 |  |  | — |  |  | — |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | 71.2 |  |  | $ | (0.1) |  |  | $ | 3.0 |  |  | $ | — |  |  | $ | (0.1) |  |  |  |  |  |  |  |  |  |
| June 28, 2025: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | — |  |  | $ | — |  |  | $ | 24.5 |  |  | $ | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 5.2 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | — |  |  | — |  |  | 73.8 |  |  | (0.1) |  |  | (0.1) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | — |  |  | — |  |  | 35.3 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | — |  |  | $ | — |  |  | $ | 138.8 |  |  | $ | (0.1) |  |  | $ | (0.1) |  |  |  |  |  |  |  |  |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-02-04):
[0001628280-26-005129:note_history:75]
|  | December 27, 2025 |  | June 28, 2025 |
|  | Short-term |  | Long-term |  | Total |  | Short-term |  | Long-term |  | Total |
| Convertible notes (1) | $ | 3,182.5 |  |  | $ | — |  |  | $ | 3,182.5 |  |  | $ | — |  |  | $ | 2,506.2 |  |  | $ | 2,506.2 |  |
| Term loans | 57.7 |  |  | 47.1 |  |  | 104.8 |  |  | 10.6 |  |  | 56.4 |  |  | 67.0 |  |
| Total | $ | 3,240.2 |  |  | $ | 47.1 |  |  | $ | 3,287.3 |  |  | $ | 10.6 |  |  | $ | 2,562.6 |  |  | $ | 2,573.2 |  |
  (was, 2025-11-05, similarity 0.9177):
[0001628280-25-049073:note_history:75]
|  | September 27, 2025 |  | June 28, 2025 |
|  | Short-term |  | Long-term |  | Total |  | Short-term |  | Long-term |  | Total |
| Convertible notes | $ | 1,068.7 |  |  | $ | 2,112.6 |  |  | $ | 3,181.3 |  |  | $ | — |  |  | $ | 2,506.2 |  |  | $ | 2,506.2 |  |
| Term loans | 10.3 |  |  | 51.9 |  |  | 62.2 |  |  | 10.6 |  |  | 56.4 |  |  | 67.0 |  |
| Total | $ | 1,079.0 |  |  | $ | 2,164.5 |  |  | $ | 3,243.5 |  |  | $ | 10.6 |  |  | $ | 2,562.6 |  |  | $ | 2,573.2 |  |

- added (2026-02-04):
[0001628280-26-005129:note_history:76]
(1) Since the closing price of our stock was at least 130% of the applicable conversion price for each series of Notes for 20 of the last 30 trading days of our second quarter of fiscal year 2026, all of our Notes became convertible at the option of the holders during the third quarter of fiscal year 2026. The outstanding Notes are recorded as short-term debt, which is presented as current liabilities in our condensed consolidated balance sheets as of December 27, 2025, net of unamortized debt issuance costs. If the Notes are converted by holders, we are required to satisfy our conversion obligations with respect to each series of converted Notes by paying cash equal to the principal amount of such series of converted Notes and paying or delivering, as the case may be, cash, shares of common stock, or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof. The outstanding Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of June 28, 2025, net of unamortized debt issuance costs.


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-02-04):
[0001628280-26-005129:note_history:77]
The future interest and principal payments related to our convertible notes are as follows as of December 27, 2025 (in millions):
  (was, 2025-11-05, similarity 0.9799):
[0001628280-25-049073:note_history:77]
The future interest and principal payments related to our convertible notes are as follows as of September 27, 2025 (in millions):


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2026-02-04):
[0001628280-26-005129:note_history:78]
|  | Three Months Ended |  | Six Months Ended |
|  | December 27, 2025 |  | December 28, 2024 |  | December 27, 2025 |  | December 28, 2024 |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Components | 443.7 |  |  | 66.7 | % |  | 263.7 |  |  | 65.6 | % |  | 822.9 |  |  | 68.6 | % |  | $ | 495.1 |  |  | 67.0 | % |
| Systems | 221.8 |  |  | 33.3 | % |  | 138.5 |  |  | 34.4 | % |  | 376.4 |  |  | 31.4 | % |  | 244.0 |  |  | 33.0 | % |
| Net revenue | $ | 665.5 |  |  | 100.0 | % |  | $ | 402.2 |  |  | 100.0 | % |  | $ | 1,199.3 |  |  | 100.0 | % |  | $ | 739.1 |  |  | 100.0 | % |

- changed (2026-02-04):
[0001628280-26-005129:note_history:79]
We record accounts receivable when we have an unconditional right to consideration. Contract liabilities are recorded when cash payments are received or due in advance of performance. Contract liabilities consist of advance payments and deferred revenue, where we have unsatisfied performance obligations. Contract liabilities are classified as deferred revenue and customer deposits and are included in other current and non-current liabilities within our condensed consolidated balance sheets. Payment terms vary by customer. The time between invoicing and when payment is due is not significant.
  (was, 2025-11-05, similarity 0.9864):
[0001628280-25-049073:note_history:79]
We record accounts receivable when we have an unconditional right to consideration. Contract liabilities are recorded when cash payments are received or due in advance of performance. Contract liabilities consist of advance payments and deferred revenue, where we have unsatisfied performance obligations. Contract liabilities are classified as deferred revenue and customer deposits and are included in other current liabilities within our condensed consolidated balance sheets. Payment terms vary by customer. The time between invoicing and when payment is due is not significant.

- added (2026-02-04):
[0001628280-26-005129:note_history:80]
| Contract balances |  | Balance sheet location |  | December 27, 2025 |  | June 28, 2025 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 376.8 |  |  | $ | 250.0 |  |  | $ | 126.8 |  |  | 50.7 | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | 2.1 |  |  | $ | 0.7 |  |  | $ | 1.4 |  |  | 200.0 | % |
| Deferred revenue and customer deposits |  | Other non-current liabilities |  | $ | 1.5 |  |  | $ | — |  |  | $ | 1.5 |  |  | n/a |

- removed (2026-02-04):
[0001628280-25-049073:note_history:81]
|  | Three Months Ended |  |  |
|  | September 27, 2025 |  | September 28, 2024 |  |  |  |  |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  |  |  |  |  |  |  |  |
| Components | 379.2 |  |  | 71.0 | % |  | 231.4 |  |  | 68.7 | % |  |  |  |  |  |  |  |  |
| Systems | 154.6 |  |  | 29.0 | % |  | 105.5 |  |  | 31.3 | % |  |  |  |  |  |  |  |  |
| Net revenue | $ | 533.8 |  |  | 100.0 | % |  | $ | 336.9 |  |  | 100.0 | % |  |  |  |  |  |  |  |  |

- removed (2026-02-04):
[0001628280-25-049073:note_history:82]
| Contract balances |  | Balance sheet location |  | September 27, 2025 |  | June 28, 2025 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 307.0 |  |  | $ | 250.0 |  |  | $ | 57.0 |  |  | 22.8 | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | 2.7 |  |  | $ | 0.7 |  |  | $ | 2.0 |  |  | 285.7 | % |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2026-02-04):
[0001628280-25-049073:note_history:83]
Note 16. Subsequent Event

- removed (2026-02-04):
[0001628280-25-049073:note_history:84]
TBD.
