# LITE 8-K — 0001628280-26-005005 filed 2026-02-03

## item codes, every 8-K on or before 2026-02-04

- 2026-02-03 0001628280-26-005005 — 2.02, 9.01
- 2026-01-05 0001193125-26-002602 — 5.02
- 2025-12-22 0001193125-25-328691 — 1.01, 2.03, 9.01
- 2025-12-15 0001628280-25-057025 — 5.02, 9.01
- 2025-11-24 0001628280-25-053795 — 5.02, 5.07, 9.01
- 2025-11-04 0001628280-25-048860 — 2.02, 9.01
- 2025-09-08 0001193125-25-198329 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2025-08-12 0001628280-25-039896 — 2.02, 9.01
- 2025-06-03 0001628280-25-029086 — 7.01, 9.01
- 2025-05-06 0001628280-25-022709 — 2.02, 9.01
- 2025-02-06 0001628280-25-004265 — 2.02, 9.01
- 2025-02-03 0001193125-25-019371 — 2.02, 5.02, 9.01
- 2024-12-12 0001193125-24-277338 — 5.02, 9.01
- 2024-11-22 0001628280-24-048886 — 5.02, 5.07, 9.01
- 2024-11-07 0001628280-24-046302 — 2.02, 9.01
- 2024-08-21 0001628280-24-037938 — 2.02, 9.01 — amendment of 0001628280-24-037191
- 2024-08-14 0001628280-24-037191 — 2.02, 9.01
- 2024-05-06 0001628280-24-020640 — 2.02, 9.01
- 2024-02-27 0001628280-24-006936 — 5.02
- 2024-02-08 0001628280-24-003789 — 2.02, 9.01
- 2024-01-18 0001628280-24-001551 — 9.01 — amendment of 0001193125-23-272452
- 2023-11-21 0001628280-23-039654 — 5.02, 5.07
- 2023-11-08 0001628280-23-037563 — 2.02, 9.01
- 2023-11-07 0001193125-23-272452 — 2.01, 8.01, 9.01
- 2023-10-30 0001193125-23-265658 — 1.01, 2.02, 9.01
- 2023-08-17 0001628280-23-029741 — 2.02, 9.01
- 2023-06-16 0001193125-23-168966 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2023-05-09 0001628280-23-016629 — 2.02, 9.01
- 2023-04-06 0001628280-23-010935 — 2.02, 8.01, 9.01
- 2023-02-24 0001193125-23-048742 — 5.02, 9.01
- 2023-02-09 0001628280-23-002866 — 2.02, 9.01
- 2022-11-21 0001628280-22-030473 — 5.02, 5.07, 9.01
- 2022-11-08 0001628280-22-028758 — 2.02, 9.01
- 2022-08-16 0001628280-22-022980 — 2.02, 9.01
- 2022-08-03 0001193125-22-210674 — 2.01, 8.01, 9.01
- 2022-07-29 0001193125-22-206587 — 8.01, 9.01
- 2022-05-04 0001628280-22-012145 — 2.02, 9.01
- 2022-03-08 0001193125-22-069350 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2022-02-03 0001628280-22-001736 — 2.02, 9.01
- 2022-01-21 0001193125-22-014413 — 8.01, 9.01
- 2021-11-23 0001628280-21-024070 — 5.02, 5.07
- 2021-11-05 0001193125-21-321796 — 1.01, 9.01
- 2021-11-04 0001628280-21-021618 — 2.02, 9.01
- 2021-11-04 0001193125-21-319601 — 8.01, 9.01
- 2021-08-18 0001628280-21-017219 — 2.02, 9.01
- 2021-06-08 0001633978-21-000030 — 5.02, 9.01
- 2021-05-12 0001633978-21-000008 — 2.02, 9.01
- 2021-03-10 0001193125-21-075438 — 1.01, 8.01, 9.01
- 2021-02-02 0001633978-21-000002 — 2.02, 9.01
- 2021-01-19 0001104659-21-005024 — 1.01, 2.02, 8.01, 9.01
- 2020-11-24 0001193125-20-302557 — 5.02, 5.07
- 2020-11-02 0001633978-20-000017 — 2.02, 9.01
- 2020-09-18 0001633978-20-000012 — 5.02, 9.01
- 2020-08-11 0001633978-20-000010 — 2.02, 9.01
- 2020-05-05 0001628280-20-006358 — 2.02, 9.01
- 2020-02-04 0001633978-20-000002 — 2.02, 9.01
- 2019-12-12 0001193125-19-312875 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2019-12-04 0001633978-19-000075 — 8.01
- 2019-11-20 0001633978-19-000074 — 5.07
- 2019-10-31 0001633978-19-000070 — 2.02, 9.01
- 2019-08-08 0001633978-19-000068 — 2.02, 9.01
- 2019-05-08 0001633978-19-000031 — 1.01
- 2019-05-07 0001633978-19-000029 — 2.02, 9.01
- 2019-02-15 0001633978-19-000005 — 9.01 — amendment of 0001193125-18-346211
- 2019-02-08 0001193125-19-031591 — 5.02, 9.01
- 2019-02-05 0001633978-19-000001 — 2.02, 9.01
- 2018-12-10 0001193125-18-346211 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-12-06 0001633978-18-000150 — 8.01
- 2018-11-14 0001633978-18-000139 — 5.07
- 2018-11-13 0001633978-18-000136 — 3.02
- 2018-11-13 0001633978-18-000132 — 7.01, 9.01
- 2018-11-01 0001628280-18-013238 — 2.02, 9.01
- 2018-08-08 0001633978-18-000056 — 2.02, 9.01
- 2018-06-08 0001193125-18-188241 — 5.02, 9.01
- 2018-05-02 0001633978-18-000029 — 2.02, 9.01
- 2018-03-12 0001193125-18-078154 — 1.01, 2.01, 8.01, 9.01
- 2018-02-06 0001628280-18-001082 — 2.02, 9.01
- 2017-11-08 0001633978-17-000133 — 5.02, 9.01
- 2017-11-07 0001633978-17-000131 — 5.07
- 2017-11-01 0001633978-17-000117 — 2.02, 9.01
- 2017-08-09 0001633978-17-000058 — 2.02, 9.01
- 2017-05-04 0001633978-17-000035 — 2.02, 9.01
- 2017-03-08 0001193125-17-074740 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2017-03-02 0001193125-17-066769 — 8.01, 9.01
- 2017-02-07 0001633978-17-000005 — 2.02, 9.01
- 2017-01-03 0001628280-17-000018 — 4.01, 9.01
- 2016-11-09 0001628280-16-021143 — 5.02, 5.07, 9.01
- 2016-10-27 0001628280-16-020382 — 2.02, 9.01
- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2026-02-04

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001628280-26-005005:8k_2_02:1]
EX-99.1
2
lite_ex991xq2fy26.htm
EX-99.1

[0001628280-26-005005:8k_2_02:2]
Document

[0001628280-26-005005:8k_2_02:3]
NEWS RELEASE

[0001628280-26-005005:8k_2_02:4]
LUMENTUM ANNOUNCES SECOND QUARTER OF FISCAL YEAR 2026 FINANCIAL RESULTS

[0001628280-26-005005:8k_2_02:5]
•Net revenue of $665.5 million

[0001628280-26-005005:8k_2_02:6]
•GAAP gross margin of 36.1%; Non-GAAP gross margin of 42.5%

[0001628280-26-005005:8k_2_02:7]
•GAAP operating margin of 9.7%; Non-GAAP operating margin of 25.2%

[0001628280-26-005005:8k_2_02:8]
•GAAP diluted net income per share of $0.89; Non-GAAP diluted net income per share of $1.67

[0001628280-26-005005:8k_2_02:9]
San Jose, Calif., February 3, 2026 – Lumentum Holdings Inc. (“Lumentum” or the “Company”) today reported results for its fiscal second quarter ended December 27, 2025.

[0001628280-26-005005:8k_2_02:10]
“Lumentum delivered a standout second quarter, with over 65 percent year-over-year revenue growth and non-GAAP operating margin expansion above 1,700 basis points,” said President and CEO Michael Hurlston. “Revenue hit the high end of our guidance range, while profitability and EPS expanded well beyond prior guidance, demonstrating the leverage of our business model.”

[0001628280-26-005005:8k_2_02:11]
“Our forward guidance calls for over 85 percent year-over-year revenue growth, yet we are only at the starting line for two substantial opportunities: optical circuit switches (OCS) and co-packaged optics (CPO). In OCS, we are scaling rapidly to meet extraordinary customer demand that has already driven our backlog well beyond $400 million. In CPO, we received an incremental multi-hundred-million-dollar order, deliverable in first half calendar 2027. Our results continue to highlight the strength of our roadmaps for both optical components and systems, which make us mission-critical to the world’s AI leaders.”

[0001628280-26-005005:8k_2_02:12]
Fiscal Second Quarter Highlights:

[0001628280-26-005005:8k_2_02:13]
Net revenue for the second quarter of fiscal year 2026 was $665.5 million, with GAAP net income of $78.2 million, or $0.89 per diluted share. Net revenue for the first quarter of fiscal year 2026 was $533.8 million, with GAAP net income of $4.2 million, or $0.05 per diluted share. Net revenue for the second quarter of fiscal year 2025 was $402.2 million, with GAAP net loss of $60.9 million, or $0.88 per diluted share.

[0001628280-26-005005:8k_2_02:14]
Non-GAAP net income for the second quarter of fiscal year 2026 was $143.9 million, or $1.67 per diluted share. Non-GAAP net income for the first quarter of fiscal year 2026 was $86.4 million, or $1.10 per diluted share. Non-GAAP net income for the second quarter of second year 2025 was $30.0 million, or $0.42 per diluted share.

[0001628280-26-005005:8k_2_02:15]
The Company held $1,155.3 million in total cash, cash equivalents, and short-term investments at the end of the second quarter of fiscal year 2026, up $33.5 million from the end of the first quarter of fiscal year 2026.

[0001628280-26-005005:8k_2_02:16]
Financial Overview – Fiscal Second Quarter Ended December 27, 2025

[0001628280-26-005005:8k_2_02:17]
|  | GAAP Results ($ in millions) |
|  | Q2 |  | Q1 |  | Q2 |  | Change |
|  | FY 2026 |  | FY 2026 |  | FY 2025 |  | Q/Q |  | Y/Y |
| Net revenue | $ | 665.5 |  |  | $ | 533.8 |  |  | $ | 402.2 |  |  | 24.7% |  | 65.5% |
| GAAP gross margin | 36.1 | % |  | 34.0 | % |  | 24.8 | % |  | 210 | bps |  | 1,130 | bps |
| GAAP operating margin (loss) | 9.7 | % |  | 1.3 | % |  | (12.8) | % |  | 840 | bps |  | 2,250 | bps |
|  | Non-GAAP Results ($ in millions) |
|  | Q2 |  | Q1 |  | Q2 |  | Change |
|  | FY 2026 |  | FY 2026 |  | FY 2025 |  | Q/Q |  | Y/Y |
| Net revenue | $ | 665.5 |  |  | $ | 533.8 |  |  | $ | 402.2 |  |  | 24.7% |  | 65.5% |
| Non-GAAP gross margin | 42.5 | % |  | 39.4 | % |  | 32.3 | % |  | 310 | bps |  | 1,020 | bps |
| Non-GAAP operating margin | 25.2 | % |  | 18.7 | % |  | 7.9 | % |  | 650 | bps |  | 1,730 | bps |

[0001628280-26-005005:8k_2_02:18]
|  | Net Revenue by Product Type ($ in millions) |  |  |  |  |
|  | Q2 |  | % of |  | Q1 |  | Q2 |  | Change |  |  |  |  |
|  | FY 2026 |  | Net Revenue |  | FY 2026 |  | FY 2025 |  | Q/Q |  | Y/Y |  |  |  |  |
| Components | $ | 443.7 |  |  | 66.7 | % |  | $ | 379.2 |  |  | $ | 263.7 |  |  | 17.0% |  | 68.3% |  |  |  |  |
| Systems | 221.8 |  |  | 33.3 | % |  | 154.6 |  |  | 138.5 |  |  | 43.5% |  | 60.1% |  |  |  |  |
| Total | $ | 665.5 |  |  | 100.0 | % |  | $ | 533.8 |  |  | $ | 402.2 |  |  | 24.7% |  | 65.5% |  |  |  |  |

[0001628280-26-005005:8k_2_02:19]
The tables above provide comparisons of quarterly results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled “Use of Non-GAAP Financial Measures.”

[0001628280-26-005005:8k_2_02:20]
Business Outlook

[0001628280-26-005005:8k_2_02:21]
Lumentum expects the following for the third quarter of fiscal year 2026:

[0001628280-26-005005:8k_2_02:22]
•Net revenue in the range of $780 million to $830 million

[0001628280-26-005005:8k_2_02:23]
•Non-GAAP operating margin of 30.0% to 31.0%

[0001628280-26-005005:8k_2_02:24]
•Non-GAAP diluted earnings per share of $2.15 to $2.35

[0001628280-26-005005:8k_2_02:25]
We have not provided reconciliations from GAAP to non-GAAP financial measures or the equivalent GAAP measure for non-GAAP financial measures in our outlook, as they cannot be provided without unreasonable effort. A large portion of non-GAAP adjustments, such as stock-based compensation, acquisition related costs (income), integration related costs, restructuring and related charges (reversals), non-GAAP income tax reconciling adjustments, and other costs and contingencies unrelated to current and future operations are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future.

[0001628280-26-005005:8k_2_02:26]
Related Announcement and Conference Call

[0001628280-26-005005:8k_2_02:27]
Lumentum will host a conference call today, February 3, 2026, at 2:00 pm PT / 5:00 pm ET to discuss its second quarter of fiscal year 2026 results. A live webcast of the call and replay will be available in the Investors section of the Lumentum website at http://investor.lumentum.com. The earnings press release will be posted at http://investor.lumentum.com under the “News Releases” section. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the “Events” section concurrently with this earnings press release. Lumentum has used, and intends to continue to use, its Investor Relations website as means of disclosing material nonpublic information and for complying with its disclosure obligations under Regulation FD. This press release is being furnished as an exhibit to a Current Report on Form 8-K filed with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001628280-26-005005:8k_2_02:28]
About Lumentum

[0001628280-26-005005:8k_2_02:29]
Lumentum (NASDAQ: LITE) is a global leader in optical and photonic technologies that power the networks and infrastructure behind AI, cloud computing, and next-generation communications. Built on decades of photonics innovation, Lumentum delivers high-performance lasers, modules, and optical subsystems that enable scalable, energy-efficient data center connectivity, advanced telecom networks, industrial manufacturing, and sensing applications. Headquartered in San Jose, California, the company operates R&D, manufacturing, and sales facilities worldwide. Learn more at www.lumentum.com.

[0001628280-26-005005:8k_2_02:30]
Forward-Looking Statements

[0001628280-26-005005:8k_2_02:31]
Contact Information

[0001628280-26-005005:8k_2_02:32]
Investors:    Kathy Ta, +1.408.750.3853; investor.relations@lumentum.com

[0001628280-26-005005:8k_2_02:33]
Media:        Victoria McDonald, +408.404.0636; media@lumentum.com

[0001628280-26-005005:8k_2_02:34]
Category:    Financial

[0001628280-26-005005:8k_2_02:35]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001628280-26-005005:8k_2_02:36]
LUMENTUM HOLDINGS INC.

[0001628280-26-005005:8k_2_02:37]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001628280-26-005005:8k_2_02:38]
(in millions, except per share data)

[0001628280-26-005005:8k_2_02:39]
(unaudited)

[0001628280-26-005005:8k_2_02:40]
|  | Three Months Ended |  | Six Months Ended |
|  | December 27, 2025 |  | December 28, 2024 |  | December 27, 2025 |  | December 28, 2024 |
| Net revenue | $ | 665.5 |  |  | $ | 402.2 |  |  | $ | 1,199.3 |  |  | $ | 739.1 |  |
| Cost of sales | 405.8 |  |  | 281.2 |  |  | 738.6 |  |  | 517.7 |  |
| Amortization of acquired developed intangibles | 19.6 |  |  | 21.4 |  |  | 39.1 |  |  | 43.9 |  |
| Gross profit | 240.1 |  |  | 99.6 |  |  | 421.6 |  |  | 177.5 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 80.1 |  |  | 74.2 |  |  | 161.5 |  |  | 148.5 |  |
| Selling, general and administrative | 96.1 |  |  | 76.3 |  |  | 181.2 |  |  | 152.6 |  |
| Restructuring and related charges (reversals) | (0.4) |  |  | 0.7 |  |  | 7.9 |  |  | 10.4 |  |
| Total operating expenses | 175.8 |  |  | 151.2 |  |  | 350.6 |  |  | 311.5 |  |
| Income (loss) from operations | 64.3 |  |  | (51.6) |  |  | 71.0 |  |  | (134.0) |  |
| Escrow settlement | 27.5 |  |  | — |  |  | 27.5 |  |  | — |  |
| Interest expense | (6.3) |  |  | (5.6) |  |  | (12.0) |  |  | (11.1) |  |
| Other income, net | 11.0 |  |  | 14.9 |  |  | 15.2 |  |  | 23.6 |  |
| Total other income, net | 32.2 |  |  | 9.3 |  |  | 30.7 |  |  | 12.5 |  |
| Income (loss) before income taxes | 96.5 |  |  | (42.3) |  |  | 101.7 |  |  | (121.5) |  |
| Income tax provision | 18.3 |  |  | 18.6 |  |  | 19.3 |  |  | 21.8 |  |
| Net income (loss) | $ | 78.2 |  |  | $ | (60.9) |  |  | $ | 82.4 |  |  | $ | (143.3) |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | 1.10 |  |  | $ | (0.88) |  |  | $ | 1.17 |  |  | $ | (2.09) |  |
| Diluted | $ | 0.89 |  |  | $ | (0.88) |  |  | $ | 0.99 |  |  | $ | (2.09) |  |
| Shares used to compute net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | 71.1 |  |  | 68.9 |  |  | 70.7 |  |  | 68.6 |  |
| Diluted | 87.8 |  |  | 68.9 |  |  | 83.1 |  |  | 68.6 |  |

[0001628280-26-005005:8k_2_02:41]
LUMENTUM HOLDINGS INC.

[0001628280-26-005005:8k_2_02:42]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-26-005005:8k_2_02:43]
(in millions, except per share data)

[0001628280-26-005005:8k_2_02:44]
(unaudited)

[0001628280-26-005005:8k_2_02:45]
|  | December 27, 2025 |  | June 28, 2025 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 657.7 |  |  | $ | 520.7 |  |
| Short-term investments | 497.6 |  |  | 356.4 |  |
| Accounts receivable, net | 376.8 |  |  | 250.0 |  |
| Inventories | 570.4 |  |  | 470.1 |  |
| Prepayments and other current assets | 180.7 |  |  | 120.1 |  |
| Total current assets | 2,283.2 |  |  | 1,717.3 |  |
| Property, plant and equipment, net | 813.5 |  |  | 726.4 |  |
| Operating lease right-of-use assets, net | 29.6 |  |  | 27.9 |  |
| Goodwill | 1,060.9 |  |  | 1,060.9 |  |
| Other intangible assets, net | 396.7 |  |  | 465.1 |  |
| Deferred tax asset | 206.1 |  |  | 210.3 |  |
| Other non-current assets | 15.3 |  |  | 10.8 |  |
| Total assets | $ | 4,805.3 |  |  | $ | 4,218.7 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 347.4 |  |  | $ | 225.2 |  |
| Accrued payroll and related expenses | 85.3 |  |  | 57.9 |  |
| Accrued expenses | 39.2 |  |  | 34.6 |  |
| Current portion of long-term debt | 3,240.2 |  |  | 10.6 |  |
| Operating lease liabilities, current | 12.7 |  |  | 11.4 |  |
| Other current liabilities | 42.8 |  |  | 53.1 |  |
| Total current liabilities | 3,767.6 |  |  | 392.8 |  |
| Long-term debt | 47.1 |  |  | 2,562.6 |  |
| Operating lease liabilities, non-current | 22.7 |  |  | 23.6 |  |
| Deferred tax liability | 5.6 |  |  | 7.2 |  |
| Other non-current liabilities | 115.7 |  |  | 97.8 |  |
| Total liabilities | 3,958.7 |  |  | 3,084.0 |  |
| Stockholders’ equity: |  |  |  |
| Common stock, $0.001 par value, 990 authorized shares, 71.4 and 69.8 shares issued and outstanding as of December 27, 2025 and June 28, 2025, respectively | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital | 1,615.9 |  |  | 1,986.8 |  |
| Accumulated deficit | (778.8) |  |  | (861.2) |  |
| Accumulated other comprehensive income | 9.4 |  |  | 9.0 |  |
| Total stockholders’ equity | 846.6 |  |  | 1,134.7 |  |
| Total liabilities and stockholders’ equity | $ | 4,805.3 |  |  | $ | 4,218.7 |  |

[0001628280-26-005005:8k_2_02:46]
Use of Non-GAAP Financial Measures

[0001628280-26-005005:8k_2_02:47]
In this press release, Lumentum provides investors with certain non-GAAP financial measures: gross profit, gross margin, research and development expense, selling, general and administrative expense, operating margin, income (loss) from operations, other income (expense), net, income before income taxes, provision for income taxes, net income (loss), shares used in per share calculation, and net income (loss) per share on a non-GAAP basis, as well as the non-GAAP measures of EBITDA and Adjusted EBITDA. Lumentum believes this non-GAAP financial information provides additional insight into the Company’s on-going business operations and results, and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons. In addition, the Company believes that providing certain of these measures allows investors to better understand the Company’s operating performance and, importantly, to evaluate the methodology and information used by management to monitor, manage, evaluate and measure the Company’s business and results of operations. However, investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future. Moreover, the non-GAAP financial measures we present may be different from non-GAAP financial measures used by other companies or may not be comparable to similarly titled measurements reported by other companies, limiting their usefulness for comparison purposes. We do not consider non-GAAP financial measures to be a substitute for, or superior to, the information provided by GAAP financial measures, and the non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP.

[0001628280-26-005005:8k_2_02:48]
Our non-GAAP measures used in this press release exclude (i) stock-based compensation and related payroll taxes, (ii) acquisition related costs (income), (iii) integration related costs, (iv) amortization of acquired intangibles, (v) restructuring and related charges (reversals), (vi) foreign exchange (gains) losses, net, (vii) non-cash interest expense on convertible notes, (viii) intangible assets write-off, (ix) inducement expense on partial repurchase of 2026 Notes, (x) escrow settlement and related charges, (xi) non-GAAP income tax reconciling adjustments, and (xii) other charges or income related to non-recurring activities.

[0001628280-26-005005:8k_2_02:49]
We utilize a long-term projected non-GAAP tax rate to compute our non-GAAP income tax provision. The long-term projected non-GAAP tax rate is based on a multi-year projection of our estimated annual GAAP income tax forecast, adjusted to account for the tax effect of non-GAAP pretax adjustments as well as the effects of significant non-recurring and period specific tax items. Our non-GAAP tax provision for fiscal year 2026 is 16.5%. The difference between our GAAP income tax provision and our non-GAAP income tax provision is presented as non-GAAP income tax reconciling adjustments.

[0001628280-26-005005:8k_2_02:50]
A quantitative reconciliation between GAAP and non-GAAP financial data is included in the supplemental financial table attached to this press release.

[0001628280-26-005005:8k_2_02:51]
LUMENTUM HOLDINGS INC.

[0001628280-26-005005:8k_2_02:52]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001628280-26-005005:8k_2_02:53]
(in millions, except per share data)

[0001628280-26-005005:8k_2_02:54]
(unaudited)

[0001628280-26-005005:8k_2_02:55]
|  | Three Months Ended |  | Six Months Ended |  |
|  | December 27, 2025 |  | September 27, 2025 |  | December 28, 2024 |  | December 27, 2025 |  | December 28, 2024 |  |
| Gross profit on GAAP basis | $ | 240.1 |  |  | $ | 181.5 |  |  | $ | 99.6 |  |  | $ | 421.6 |  |  | $ | 177.5 |  |  |
| Stock-based compensation and related payroll taxes (1) | 13.3 |  |  | 9.7 |  |  | 9.2 |  |  | 23.0 |  |  | 18.9 |  |  |
| Amortization of acquired intangibles | 19.6 |  |  | 19.5 |  |  | 21.4 |  |  | 39.1 |  |  | 43.9 |  |  |
| Integration related costs | — |  |  | — |  |  | 1.1 |  |  | — |  |  | 2.3 |  |  |
| Acquisition-related warranty provision (4) | 9.8 |  |  | — |  |  | — |  |  | 9.8 |  |  | — |  |  |
| Other income, net | (0.2) |  |  | (0.4) |  |  | (1.3) |  |  | (0.6) |  |  | (2.2) |  |  |
| Gross profit on non-GAAP basis | $ | 282.6 |  |  | $ | 210.3 |  |  | $ | 130.0 |  |  | $ | 492.9 |  |  | $ | 240.4 |  |  |
| Gross margin on non-GAAP basis | 42.5 | % |  | 39.4 | % |  | 32.3 | % |  | 41.1 | % |  | 32.5 | % |  |
| Research and development on GAAP basis | $ | 80.1 |  |  | $ | 81.4 |  |  | $ | 74.2 |  |  | $ | 161.5 |  |  | $ | 148.5 |  |  |
| Stock-based compensation and related payroll taxes (1) | (9.8) |  |  | (12.0) |  |  | (11.4) |  |  | (21.8) |  |  | (20.7) |  |  |
| Amortization of acquired intangibles | (0.4) |  |  | (0.4) |  |  | (0.4) |  |  | (0.8) |  |  | (0.8) |  |  |
| Intangible assets write-off | — |  |  | — |  |  | — |  |  | — |  |  | (1.9) |  |  |
| Research and development on non-GAAP basis | $ | 69.9 |  |  | $ | 69.0 |  |  | $ | 62.4 |  |  | $ | 138.9 |  |  | $ | 125.1 |  |  |
| Selling, general and administrative on GAAP basis | $ | 96.1 |  |  | $ | 85.1 |  |  | $ | 76.3 |  |  | $ | 181.2 |  |  | $ | 152.6 |  |  |
| Stock-based compensation and related payroll taxes (1) | (24.8) |  |  | (24.8) |  |  | (18.2) |  |  | (49.6) |  |  | (34.8) |  |  |
| Amortization of acquired intangibles | (14.0) |  |  | (14.5) |  |  | (17.2) |  |  | (28.5) |  |  | (36.0) |  |  |
| Acquisition related costs (2) | (0.4) |  |  | (1.3) |  |  | — |  |  | (1.7) |  |  | — |  |  |
| Integration related costs | (1.3) |  |  | 0.8 |  |  | (2.0) |  |  | (0.5) |  |  | (4.2) |  |  |
| Other charges, net (6) | (10.6) |  |  | (3.8) |  |  | (3.0) |  |  | (14.4) |  |  | (4.0) |  |  |
| Selling, general and administrative on non-GAAP basis | $ | 45.0 |  |  | $ | 41.5 |  |  | $ | 35.9 |  |  | $ | 86.5 |  |  | $ | 73.6 |  |  |
| Income (loss) from operations on GAAP basis | $ | 64.3 |  |  | $ | 6.7 |  |  | $ | (51.6) |  |  | $ | 71.0 |  |  | $ | (134.0) |  |  |
| Stock-based compensation and related payroll taxes (1) | 47.9 |  |  | 46.5 |  |  | 38.8 |  |  | 94.4 |  |  | 74.4 |  |  |
| Amortization of acquired intangibles | 34.0 |  |  | 34.4 |  |  | 39.0 |  |  | 68.4 |  |  | 80.7 |  |  |
| Acquisition related costs (2) | 0.4 |  |  | 1.3 |  |  | — |  |  | 1.7 |  |  | — |  |  |
| Integration related costs | 1.3 |  |  | (0.8) |  |  | 3.1 |  |  | 0.5 |  |  | 6.5 |  |  |
| Restructuring and related charges (reversals) (3) | (0.4) |  |  | 8.3 |  |  | 0.7 |  |  | 7.9 |  |  | 10.4 |  |  |
| Intangible assets write-off | — |  |  | — |  |  | — |  |  | — |  |  | 1.9 |  |  |
| Acquisition-related warranty provision (4) | 9.8 |  |  | 0 |  | — |  |  | 9.8 |  |  | — |  |  |
| Other charges, net (6) | 10.4 |  |  | 3.4 |  |  | 1.7 |  |  | 13.8 |  |  | 1.8 |  |  |
| Income from operations on non-GAAP basis | $ | 167.7 |  |  | $ | 99.8 |  |  | $ | 31.7 |  |  | $ | 267.5 |  |  | $ | 41.7 |  |  |
| Operating margin on non-GAAP basis | 25.2 | % |  | 18.7 | % |  | 7.9 | % |  | 22.3 | % |  | 5.6 | % |  |
| Other income (expense), net on GAAP basis | $ | 32.2 |  |  | $ | (1.5) |  |  | $ | 9.3 |  |  | $ | 30.7 |  |  | $ | 12.5 |  |  |
| Acquisition related income (2) | (1.8) |  |  | — |  |  | — |  |  | (1.8) |  |  | — |  |  |
| Escrow settlement (4) | (27.5) |  |  | — |  |  | — |  |  | (27.5) |  |  | — |  |  |
| Inducement expense (5) | — |  |  | 5.9 |  |  | — |  |  | 5.9 |  |  | — |  |  |

[0001628280-26-005005:8k_2_02:56]
| Foreign exchange (gains) losses, net | 0.6 |  |  | (1.5) |  |  | (5.9) |  |  | (0.9) |  |  | (5.2) |  |  |
| Non-cash interest expense on convertible notes | 1.1 |  |  | 0.8 |  |  | 0.8 |  |  | 1.9 |  |  | 1.5 |  |  |
| Other income, net on non-GAAP basis | $ | 4.6 |  |  | $ | 3.7 |  |  | $ | 4.2 |  |  | $ | 8.3 |  |  | $ | 8.8 |  |  |
| Income (loss) before income taxes on GAAP basis | $ | 96.5 |  |  | $ | 5.2 |  |  | $ | (42.3) |  |  | $ | 101.7 |  |  | $ | (121.5) |  |  |
| Stock-based compensation and related payroll taxes (1) | 47.9 |  |  | 46.5 |  |  | 38.8 |  |  | 94.4 |  |  | 74.4 |  |  |
| Acquisition related costs (income), net (2) | (1.4) |  |  | 1.3 |  |  | — |  |  | (0.1) |  |  | — |  |  |
| Integration related costs | 1.3 |  |  | (0.8) |  |  | 3.1 |  |  | 0.5 |  |  | 6.5 |  |  |
| Amortization of acquired intangibles | 34.0 |  |  | 34.4 |  |  | 39.0 |  |  | 68.4 |  |  | 80.7 |  |  |
| Restructuring and related charges (reversals) (3) | (0.4) |  |  | 8.3 |  |  | 0.7 |  |  | 7.9 |  |  | 10.4 |  |  |
| Escrow settlement (4) | (27.5) |  |  | — |  |  | — |  |  | (27.5) |  |  | — |  |  |
| Acquisition-related warranty provision (4) | 9.8 |  |  | — |  |  | — |  |  | 9.8 |  |  | — |  |  |
| Inducement expense (5) | — |  |  | 5.9 |  |  | — |  |  | 5.9 |  |  | — |  |  |
| Intangible assets write-off | — |  |  | — |  |  | — |  |  | — |  |  | 1.9 |  |  |
| Foreign exchange (gains) losses, net | 0.6 |  |  | (1.5) |  |  | (5.9) |  |  | (0.9) |  |  | (5.2) |  |  |
| Non-cash interest expense on convertible notes | 1.1 |  |  | 0.8 |  |  | 0.8 |  |  | 1.9 |  |  | 1.5 |  |  |
| Other charges, net (6) | 10.4 |  |  | 3.4 |  |  | 1.7 |  |  | 13.8 |  |  | 1.8 |  |  |
| Income before income taxes on non-GAAP basis | $ | 172.3 |  |  | $ | 103.5 |  |  | $ | 35.9 |  |  | $ | 275.8 |  |  | $ | 50.5 |  |  |
| Income tax provision on GAAP basis | $ | 18.3 |  |  | $ | 1.0 |  |  | $ | 18.6 |  |  | $ | 19.3 |  |  | $ | 21.8 |  |  |
| Non-GAAP income tax reconciling adjustments | 10.1 |  |  | 16.1 |  |  | (12.7) |  |  | 26.2 |  |  | (13.5) |  |  |
| Income tax provision on non-GAAP basis | $ | 28.4 |  |  | $ | 17.1 |  |  | $ | 5.9 |  |  | $ | 45.5 |  |  | $ | 8.3 |  |  |
| Net income (loss) on GAAP basis | $ | 78.2 |  |  | $ | 4.2 |  |  | $ | (60.9) |  |  | $ | 82.4 |  |  | $ | (143.3) |  |  |
| Stock-based compensation and related payroll taxes (1) | 47.9 |  |  | 46.5 |  |  | 38.8 |  |  | 94.4 |  |  | 74.4 |  |  |
| Acquisition related costs (income), net (2) | (1.4) |  |  | 1.3 |  |  | — |  |  | (0.1) |  |  | — |  |  |
| Integration related costs | 1.3 |  |  | (0.8) |  |  | 3.1 |  |  | 0.5 |  |  | 6.5 |  |  |
| Amortization of acquired intangibles | 34.0 |  |  | 34.4 |  |  | 39.0 |  |  | 68.4 |  |  | 80.7 |  |  |
| Restructuring and related charges (reversals) (3) | (0.4) |  |  | 8.3 |  |  | 0.7 |  |  | 7.9 |  |  | 10.4 |  |  |
| Intangible assets write-off | — |  |  | — |  |  | — |  |  | — |  |  | 1.9 |  |  |
| Escrow settlement (4) | (27.5) |  |  | — |  |  | — |  |  | (27.5) |  |  | — |  |  |
| Acquisition-related warranty provision (4) | 9.8 |  |  | — |  |  | — |  |  | 9.8 |  |  | — |  |  |
| Inducement expense (5) | — |  |  | 5.9 |  |  | — |  |  | 5.9 |  |  | — |  |  |
| Foreign exchange (gains) losses, net | 0.6 |  |  | (1.5) |  |  | (5.9) |  |  | (0.9) |  |  | (5.2) |  |  |
| Non-cash interest expense on convertible notes | 1.1 |  |  | 0.8 |  |  | 0.8 |  |  | 1.9 |  |  | 1.5 |  |  |
| Non-GAAP income tax reconciling adjustments | (10.1) |  |  | (16.1) |  |  | 12.7 |  |  | (26.2) |  |  | 13.5 |  |  |
| Other charges, net (6) | 10.4 |  |  | 3.4 |  |  | 1.7 |  |  | 13.8 |  |  | 1.8 |  |  |
| Net income on non-GAAP basis | $ | 143.9 |  |  | $ | 86.4 |  |  | $ | 30.0 |  |  | $ | 230.3 |  |  | $ | 42.2 |  |  |
| Net income per share on non-GAAP basis | $ | 1.67 |  |  | $ | 1.10 |  |  | $ | 0.42 |  |  | $ | 2.80 |  |  | $ | 0.60 |  |  |
| Shares used in per share calculation - diluted on GAAP basis | 87.8 |  |  | 78.3 |  |  | 68.9 |  |  | 83.1 |  |  | 68.6 |  |  |
| Non-GAAP adjustment (7) | (1.7) |  |  | — |  |  | 2.7 |  |  | (0.9) |  |  | 1.8 |  |  |
| Shares used in per share calculation - diluted on non-GAAP basis | 86.1 |  |  | 78.3 |  |  | 71.6 |  |  | 82.2 |  |  | 70.4 |  |  |

[0001628280-26-005005:8k_2_02:57]
(1) Stock-based compensation and related payroll taxes for the three and six months ended December 27, 2025 includes $2.5 million and $6.6 million of payroll taxes on stock-based compensation, respectively.

[0001628280-26-005005:8k_2_02:58]
(2) Acquisition related costs (income), net for the three and six months ended December 27, 2025 represent $1.8 million of interest income from the Cloud Light escrow fund in other income, net, offset by the associated legal expenses incurred related to Cloud Light escrow settlement of $0.4 million and $1.7 million both in selling, general and administrative expenses for the three and six months ended December 27, 2025, respectively.

[0001628280-26-005005:8k_2_02:59]
(3) During the three months ended December 27, 2025, we recorded a net reversal to our restructuring and related charges of  $0.4 million attributable to lower-than-estimated employee severance and wind-down charges. Restructuring and related charges for the six months ended December 27, 2025 primarily relate to reduction in force during the period in order to enhance operational efficiency and realign our investments toward the most critical initiatives.

[0001628280-26-005005:8k_2_02:60]
(4) During the three months ended December 27, 2025, we completed the settlement process with the sellers on the escrow agreement for the acquisition of Cloud Light. We believe the completion of this settlement represents a non-recurring activity as it relates directly to an acquisition. The settlement of $27.5 million, recorded in escrow settlement, for the three and six months ended December 27, 2025 represents the mutually agreed escrow settlement associated with indemnification obligations and working capital adjustments, including warranty adjustments, under the Cloud Light Merger agreement. Acquisition-related warranty provision relates to  $9.8 million of warranty expense associated with Cloud Light’s legacy products is recorded in cost of sales. As the measurement period for U.S. GAAP expired, these amounts were all included in our condensed consolidated results of operations on a GAAP basis as no further adjustments to the purchase consideration of Cloud Light can be made. Therefore, for non-GAAP reporting purposes, we have removed the net benefit of $17.7 million for the three and six months ended December 27, 2025.

[0001628280-26-005005:8k_2_02:61]
(5) Inducement expense on the partial repurchase of our 2026 Notes for the six months ended December 27, 2025 represents the excess of fair value of the total consideration over the fair value of securities issuable pursuant to the original conversion terms.

[0001628280-26-005005:8k_2_02:62]
(6) Other charges, net for the three and six months ended December 27, 2025 mainly includes an impairment charge of $7.5 million to write-down assets held for sale to fair value less cost to sell in selling, general and administrative expenses, and the remaining amount mostly relates to legal and professional fees primarily related to non-ordinary course legal matters in selling and general and administrative expenses.

[0001628280-26-005005:8k_2_02:63]
(7) The adjustment for the three and six months ended December 27, 2025 represents the impact of the capped call options. Our outstanding capped call options are anti-dilutive under GAAP as they are specifically designed to mitigate the dilutive impact of the 2032 Notes, such that no dilution will occur until the capped call price is exceeded. Therefore, we  included the 1.7 million and 0.9 million shares anti-dilutive impact of the capped call from the calculation of non-GAAP diluted shares in the three and six months ended December 27, 2025 to provide investors with useful information in evaluating our performance on a per share basis.

[0001628280-26-005005:8k_2_02:64]
LUMENTUM HOLDINGS INC.

[0001628280-26-005005:8k_2_02:65]
RECONCILIATION OF GAAP NET INCOME TO ADJUSTED EBITDA

[0001628280-26-005005:8k_2_02:66]
(in millions, except per share data)

[0001628280-26-005005:8k_2_02:67]
(unaudited)

[0001628280-26-005005:8k_2_02:68]
|  | Three Months Ended |  |  |  | Six Months Ended |
|  | December 27, 2025 |  |  |  | September 27, 2025 |  | December 28, 2024 |  |  |  |  |  | December 27, 2025 |  | December 28, 2024 |
| GAAP net income (loss) | $ | 78.2 |  |  |  |  | $ | 4.2 |  |  | $ | (60.9) |  |  |  |  |  |  | $ | 82.4 |  |  | $ | (143.3) |  |
| Other income (expense), net | (32.2) |  |  |  |  | 1.5 |  |  | (9.3) |  |  |  |  |  |  | (30.7) |  |  | (12.5) |  |
| Income tax provision | 18.3 |  |  |  |  | 1.0 |  |  | 18.6 |  |  |  |  |  |  | 19.3 |  |  | 21.8 |  |
| Depreciation | 30.6 |  |  |  |  | 27.8 |  |  | 25.9 |  |  |  |  |  |  | 58.4 |  |  | 52.9 |  |
| Amortization of acquired intangibles | 34.0 |  |  |  |  | 34.4 |  |  | 39.0 |  |  |  |  |  |  | 68.4 |  |  | 80.7 |  |
| EBITDA | 128.9 |  |  |  |  | 68.9 |  |  | 13.3 |  |  |  |  |  |  | 197.8 |  |  | (0.4) |  |
| Restructuring and related charges (reversals) | (0.4) |  |  |  |  | 8.3 |  |  | 0.7 |  |  |  |  |  |  | 7.9 |  |  | 10.4 |  |
| Stock-based compensation and related payroll taxes | 47.9 |  |  |  |  | 46.5 |  |  | 38.8 |  |  |  |  |  |  | 94.4 |  |  | 74.4 |  |
| Acquisition related costs | 0.4 |  |  |  |  | 1.3 |  |  | — |  |  |  |  |  |  | 1.7 |  |  | — |  |
| Acquisition-related warranty provision | 9.8 |  |  |  |  | — |  |  | — |  |  |  |  |  |  | 9.8 |  |  | — |  |
| Integration related costs | 1.3 |  |  |  |  | (0.8) |  |  | 3.1 |  |  |  |  |  |  | 0.5 |  |  | 6.5 |  |
| Intangible asset write-off | — |  |  |  |  | — |  |  | — |  |  |  |  |  | — |  |  | 1.9 |  |
| Other charges, net | 10.4 |  |  |  |  | 3.4 |  |  | 1.7 |  |  |  |  |  |  | 13.8 |  |  | 1.8 |  |
| Adjusted EBITDA | $ | 198.3 |  |  |  |  | $ | 127.6 |  |  | $ | 57.6 |  |  |  |  |  |  | $ | 325.9 |  |  | $ | 94.6 |  |
