# LITE notes — 0001633978-17-000006


## lite:PropertyPlantandEquipmentNetTableTextBlock

[0001633978-17-000006:notes:1]
[same as prior period, unchanged from 0001628280-16-020392:notes:1]

[0001633978-17-000006:notes:2]
|  | December 31, 2016 |  | July 2, 2016 |
| Land | $ | 5.9 |  |  | $ | 5.9 |  |
| Buildings and improvement | 29.3 |  |  | 28.9 |  |
| Machinery and equipment | 417.7 |  |  | 378.5 |  |
| Furniture and fixtures and software | 32.3 |  |  | 32.2 |  |
| Leasehold improvements | 27.7 |  |  | 28.6 |  |
| Construction in progress | 63.5 |  |  | 44.1 |  |
|  | 576.4 |  |  | 518.2 |  |
| Less: Accumulated depreciation | (356.8 | ) |  | (334.8 | ) |
| Property, plant and equipment, net | $ | 219.6 |  |  | $ | 183.4 |  |


## lite:ScheduleOfOtherLiabilitiesCurrentTableTextBlock

[0001633978-17-000006:notes:3]
[same as prior period, unchanged from 0001628280-16-020392:notes:3]

[0001633978-17-000006:notes:4]
|  | December 31, 2016 |  | July 2, 2016 |
| Warranty accrual | $ | 8.7 |  |  | $ | 2.8 |  |
| Restructuring accrual and related charges | 5.9 |  |  | 5.5 |  |
| Deferred revenue | 5.7 |  |  | 2.7 |  |
| Others | 1.0 |  |  | 1.1 |  |
| Other current liabilities | $ | 21.3 |  |  | $ | 12.1 |  |


## lite:ScheduleOfOtherLiabilitiesNoncurrentTableTextBlock

[0001633978-17-000006:notes:5]
[same as prior period, unchanged from 0001628280-16-020392:notes:5]

[0001633978-17-000006:notes:6]
|  | December 31, 2016 |  | July 2, 2016 |
| Asset retirement obligation | $ | 2.4 |  |  | $ | 2.3 |  |
| Pension and related accrual | 3.4 |  |  | 3.5 |  |
| Deferred rent | 3.2 |  |  | 1.6 |  |
| Restructuring accrual and related charges | 0.1 |  |  | 0.2 |  |
| Unrecognized tax benefit | 4.3 |  |  | 0.1 |  |
| Other non-current liabilities | 0.9 |  |  | 1.4 |  |
| Other non-current liabilities | $ | 14.3 |  |  | $ | 9.1 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001633978-17-000006:notes:7]
[same as prior period, unchanged from 0001628280-16-020392:notes:7]

[0001633978-17-000006:notes:8]
[same as prior period, unchanged from 0001628280-16-020392:notes:10]

[0001633978-17-000006:notes:9]
[same as prior period, unchanged from 0001628280-16-020392:notes:11]

[0001633978-17-000006:notes:10]
|  | December 31, 2016 |  | July 2, 2016 |
| Finished goods | $ | 60.2 |  |  | $ | 46.1 |  |
| Work in process | 34.4 |  |  | 25.5 |  |
| Raw materials and purchased parts | 26.4 |  |  | 29.0 |  |
| Inventories | $ | 121.0 |  |  | $ | 100.6 |  |

[0001633978-17-000006:notes:11]
[same as prior period, unchanged from 0001628280-16-020392:notes:13]

[0001633978-17-000006:notes:12]
[same as prior period, unchanged from 0001628280-16-020392:notes:14]

[0001633978-17-000006:notes:13]
|  | December 31, 2016 |  | July 2, 2016 |
| Capitalized manufacturing overhead | 27.4 |  |  | $ | 27.3 |  |
| Prepayments | 9.9 |  |  | 6.4 |  |
| Advances to contract manufacturers | 10.4 |  |  | 10.3 |  |
| Due from (to) Viavi, net | — |  |  | 2.0 |  |
| Other current assets | 10.5 |  |  | 15.3 |  |
| Prepayments and other current assets | $ | 58.2 |  |  | $ | 61.3 |  |

[0001633978-17-000006:notes:14]
[same as prior period, unchanged from 0001628280-16-020392:notes:16]

[0001633978-17-000006:notes:15]
[same as prior period, unchanged from 0001628280-16-020392:notes:17]

[0001633978-17-000006:notes:16]
During the three and six months ended December 31, 2016, we recorded depreciation expense of $13.1 million and $25.0 million, respectively. During the three and six months ended December 26, 2015, we recorded depreciation expense of $12.1 million and $23.8 million, respectively. Our construction in progress includes primarily machinery and equipment that was purchased to increase our manufacturing capacity. We expect to place these assets in service in next 12 months.

[0001633978-17-000006:notes:17]
[same as prior period, unchanged from 0001628280-16-020392:notes:19]

[0001633978-17-000006:notes:18]
[same as prior period, unchanged from 0001628280-16-020392:notes:20]


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001633978-17-000006:notes:19]
[same as prior period, unchanged from 0001628280-16-020392:notes:21]

[0001633978-17-000006:notes:20]
Lumentum was incorporated in Delaware as a wholly owned subsidiary of JDS Uniphase Corporation ("JDSU") on February 10, 2015 and is comprised of the former communications and commercial optical products (“CCOP”) segment and WaveReady product lines of JDSU.

[0001633978-17-000006:notes:21]
On July 31, 2015, prior to the Separation (as described below), JDSU transferred substantially all of the assets and liabilities and operations of the CCOP segment and WaveReady product lines to Lumentum. Financial statements for periods prior to the Separation were prepared on a stand-alone basis and were derived from JDSU’s consolidated financial statements and accounting records. The Company prepared consolidated financial statements for the period from June 28, 2015 to August 1, 2015 where expenses were allocated to the Company using estimates that it considers to be a reasonable reflection of the utilization of services provided to, or benefits received by, the Company. Since August 1, 2015, the Company has prepared consolidated financial statements as an independent stand-alone basis pursuant to the rules and regulations of the the U.S. Securities and Exchange Commission (SEC) and are in conformity with generally accepted accounting principles in the United States (GAAP). In the opinion of management, these consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments, which are necessary for a fair statement of the consolidated financial statements for the periods shown. The results of operations for such periods are not necessarily indicative of the results expected for the full year or for any future periods.

[0001633978-17-000006:notes:22]
[same as prior period, unchanged from 0001628280-16-020392:notes:24]


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001633978-17-000006:notes:23]
[same as prior period, unchanged from 0001628280-16-020392:notes:25]

[0001633978-17-000006:notes:24]
[same as prior period, unchanged from 0001628280-16-020392:notes:26]

[0001633978-17-000006:notes:25]
Lumentum Holdings Inc. ("we", "our", "Lumentum" or the "Company") is an industry leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including data communications ("Datacom") and telecommunications ("Telecom") networking and commercial lasers ("Commercial Lasers") for manufacturing, inspection and life-science applications. We are using our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including 3-D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be original equipment manufacturers ("OEMs") that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that our network equipment manufacturer ("NEM") customers assemble into communications networking systems, which they sell to network service providers or enterprises with their own networks. Similarly, many of our customers for our Commercial Lasers products incorporate our products into tools they produce, which are used for manufacturing processes by their customers.

[0001633978-17-000006:notes:26]
As of December 31, 2016, Viavi held a total of 1.7 million shares of our common stock, which is under 5% of our total shares outstanding.

[0001633978-17-000006:notes:27]
The preparation of the consolidated financial statements in accordance with GAAP in the United States requires management to make estimates and assumptions that affect the amounts reported in our consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, inventory valuation, allocation methods and allocated expenses from Viavi, valuation of goodwill and other intangible assets, stock-based compensation, retirement and post-retirement plan assumptions, restructuring, warranty, valuation of derivative liability, and accounting for income taxes.

[0001633978-17-000006:notes:28]
See "Note 3. Related Party Transactions" in the Notes to Consolidated Financial Statements regarding the relationships we have with Viavi.

[0001633978-17-000006:notes:29]
[same as prior period, unchanged from 0001628280-16-020392:notes:30]

[0001633978-17-000006:notes:30]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Our fiscal 2017 is a 52-week year ending on July 1, 2017, while fiscal 2016 was a 53-week year and ended on July 2, 2016.

[0001633978-17-000006:notes:31]
[same as prior period, unchanged from 0001628280-16-020392:notes:32]

[0001633978-17-000006:notes:32]
[same as prior period, unchanged from 0001628280-16-020392:notes:33]

[0001633978-17-000006:notes:33]
[same as prior period, unchanged from 0001628280-16-020392:notes:34]

[0001633978-17-000006:notes:34]
The preparation of our consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amount of assets and liabilities at the date of the financial statements, the reported amount of net revenue and expenses and the disclosure of commitments and contingencies during the reporting periods. We base estimates on historical experience and on various assumptions about the future believed to be reasonable based on available information. Our reported financial position or results of operations may be materially different under changed conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies. If estimates or assumptions differ from actual results, subsequent periods are adjusted to reflect more current information.

[0001633978-17-000006:notes:35]
[same as prior period, unchanged from 0001628280-16-020392:notes:36]

[0001633978-17-000006:notes:36]
There have been no material changes in our significant accounting policies during the six months ended December 31, 2016 compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 2, 2016. The accompanying unaudited interim consolidated financial statements and accompanying related notes should be read in conjunction with the consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended July 2, 2016.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001633978-17-000006:notes:37]
Note 13. Commitments and Contingencies

[0001633978-17-000006:notes:38]
Operating Leases

[0001633978-17-000006:notes:39]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2026. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. As of December 31, 2016, the future minimum annual lease payments under non-cancellable operating leases were as follows (in millions):

[0001633978-17-000006:notes:40]
| Remainder of 2017 | $ | 3.4 |  |
| 2018 | 6.4 |  |
| 2019 | 6.0 |  |
| 2020 | 4.6 |  |
| 2021 | 3.6 |  |
| Thereafter | 6.9 |  |
| Total minimum operating lease payments | $ | 30.9 |  |

[0001633978-17-000006:notes:41]
Included in the future minimum lease payments table above is $0.3 million related to lease commitments in connection with our restructuring and related activities. Refer to "Note 10. Restructuring and Related Charges" in the Notes to Consolidated Financial Statements.

[0001633978-17-000006:notes:42]
Purchase Obligations

[0001633978-17-000006:notes:43]
Purchase obligations of $122.3 million as of December 31, 2016, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001633978-17-000006:notes:44]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with such vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

[0001633978-17-000006:notes:45]
Product Warranties

[0001633978-17-000006:notes:46]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, product component or application of our products by the end customer, our warranties can vary and generally range from six months to 5 years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001633978-17-000006:notes:47]
The following table presents the changes in our warranty reserve during the three and six months ended December 31, 2016 and December 26, 2015 (in millions):

[0001633978-17-000006:notes:48]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |  | December 31, 2016 |  | December 26, 2015 |
| Balance as of beginning of period | $ | 5.4 |  |  | $ | 2.5 |  |  | $ | 2.8 |  |  | $ | 2.8 |  |
| Provision for warranty | 4.9 |  |  | 0.8 |  |  | 8.7 |  |  | 1.7 |  |
| Utilization of reserve | (1.6 | ) |  | (0.3 | ) |  | (2.8 | ) |  | (1.5 | ) |
| Adjustments related to pre-existing warranties (includingchanges in estimates) | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Balance as of period end | $ | 8.7 |  |  | $ | 3.1 |  |  | $ | 8.7 |  |  | $ | 3.1 |  |

[0001633978-17-000006:notes:49]
Environmental Liabilities

[0001633978-17-000006:notes:50]
Our R&D, manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental, product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001633978-17-000006:notes:51]
Legal Proceedings

[0001633978-17-000006:notes:52]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management's view of these matters may change in the future. Were an unfavorable final outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the effect becomes reasonably estimable.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001633978-17-000006:notes:53]
[same as prior period, unchanged from 0001628280-16-020392:notes:56]

[0001633978-17-000006:notes:54]
[same as prior period, unchanged from 0001628280-16-020392:notes:57]

[0001633978-17-000006:notes:55]
As of December 31, 2016 and July 2, 2016, balances for the components of accumulated other comprehensive income were as follows (in millions):

[0001633978-17-000006:notes:56]
|  | Foreign currency translation adjustments |  | Defined benefit obligation, net of tax |  | Total |
| Beginning balance as of July 2, 2016 | $ | 11.7 |  |  | $ | (2.3 | ) |  | $ | 9.4 |  |
| Other comprehensive loss | (0.9 | ) |  | — |  |  | (0.9 | ) |
| Ending balance as of October 1, 2016 | 10.8 |  |  | (2.3 | ) |  | 8.5 |  |
| Other comprehensive loss | (3.7 | ) |  | — |  |  | (3.7 | ) |
| Ending balance as of December 31, 2016 | $ | 7.1 |  |  | $ | (2.3 | ) |  | $ | 4.8 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001633978-17-000006:notes:57]
[same as prior period, unchanged from 0001628280-16-020392:notes:60]

[0001633978-17-000006:notes:58]
We estimate the fair value of the embedded derivative for the Series A Preferred Stock using the binomial lattice model. We applied the binomial lattice model to value the embedded derivative using a "with-and-without method," where the value of the Series A Preferred Stock including the embedded derivative, is defined as the "with", and the value of the Series A Preferred Stock excluding the embedded derivative, is defined as the "without". This method estimates the value of the embedded derivative by looking at the difference in the values between the Series A Preferred Stock with the embedded derivative and the value of the Series A Preferred Stock without the embedded derivative. The lattice model requires the following inputs: (i) the Company's common stock price; (ii) conversion price; (iii) term; (iv) yield; (v) recovery rate; (vi) estimated stock volatility; and (vii) risk-free rate. The fair value of the embedded derivative was determined using level 3 inputs under the fair value hierarchy (unobservable inputs). Changes in the inputs into this valuation model have a material impact in the estimated fair value of the embedded derivative. For example, a decrease (increase) in the stock price results in a decrease (increase) in the estimated fair value of the embedded derivative. The changes in the fair value of the bifurcated embedded derivative of $4.8 million and $(17.9) million for the three and six months ended December 31, 2016, respectively, and $(2.4) million and $(0.2) million for the three and six months ended December 26, 2015, respectively, are primarily related to the change in the price of the Company's underlying common stock and are reflected in the consolidated statements of operations as "Unrealized gain (loss) on derivative liability".

[0001633978-17-000006:notes:59]
The following table provides a reconciliation of the fair value of the embedded derivative for the Series A Preferred Stock measured by significant unobservable inputs (Level 3) for the three and six months ended December 31, 2016:

[0001633978-17-000006:notes:60]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | December 31, 2016 |  | December 26, 2015 |  | December 31, 2016 |  | December 26, 2015 |
| (in millions) |  |  |  |  |  |  |  |  |
| Balance as of beginning of period |  | $ | (33.0 | ) |  | $ | (7.5 | ) |  | $ | (10.3 | ) |  | $ | — |  |
| Fair value of the embedded derivative for the Series A Preferred Stock at issuance |  | — |  |  | — |  |  | — |  |  | (9.7 | ) |
| Unrealized loss (gain) included in net income |  | 4.8 |  |  | (2.4 | ) |  | (17.9 | ) |  | (0.2 | ) |
| Balance as of end of period |  | $ | (28.2 | ) |  | $ | (9.9 | ) |  | $ | (28.2 | ) |  | $ | (9.9 | ) |

[0001633978-17-000006:notes:61]
The following table summarizes the assumptions used to determine the fair value of the embedded derivative:

[0001633978-17-000006:notes:62]
|  |  | December 31, 2016 |
| Stock price |  | $ | 38.65 |  |
| Conversion price |  | $ | 24.63 |  |
| Expected term (years) |  | 3.61 |  |
| Expected annual volatility |  | 40.0 | % |
| Risk-free rate |  | 1.75 | % |
| Expected common dividend yield |  | — | % |
| Preferred yield |  | 8.34 | % |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001633978-17-000006:notes:63]
[same as prior period, unchanged from 0001628280-16-020392:notes:65]

[0001633978-17-000006:notes:64]
[same as prior period, unchanged from 0001628280-16-020392:notes:66]

[0001633978-17-000006:notes:65]
[same as prior period, unchanged from 0001628280-16-020392:notes:67]

[0001633978-17-000006:notes:66]
On June 23, 2015, the board of directors of JDS Uniphase Corporation (“JDSU” and, now, Viavi Solutions Inc.) approved, and subsequently, our sole stockholder adopted, the 2015 Equity Incentive Plan (the "2015 Plan") under which 8.5 million shares of our Common Stock were authorized for issuance. The 2015 Plan was ratified by the Company’s board of directors on July 31, 2015.  In connection with our Separation from JDSU on August 1, 2015, outstanding JDSU equity-based awards, held by employees continuing employment with the Company after the Separation, were converted into equity-based awards under the 2015 Plan, reducing the number of shares remaining available for grant under the 2015 Plan.  As of immediately following our Separation from JDSU, 2.1 million shares of our Common Stock were subject to outstanding equity-based awards under the 2015 Plan that were converted from JDSU equity-based awards.

[0001633978-17-000006:notes:67]
On November 4, 2016, the Company’s stockholders approved an amendment to increase the number of shares that may be issued under the 2015 Plan by 3.0 million shares and to approve the material terms of the 2015 Plan.

[0001633978-17-000006:notes:68]
As of December 31, 2016, the Company had 2.8 million stock options, performance stock units, restricted stock awards, and restricted stock units outstanding under the 2015 Plan. Performance stock units, restricted stock awards, and restricted stock units are performance-based, time-based or a combination of both and are expected to vest over one to four years. The fair value of the time-based performance stock units, restricted stock awards, or restricted stock units is based on the closing market price of the Company’s common stock on the date of award.

[0001633978-17-000006:notes:69]
The exercise price for stock options is equal to the fair value of the underlying stock at the date of grant. The Company issues new shares of common stock upon exercise of stock options. Options generally become exercisable over a three-year or four-year period and, if not exercised, expire from five to ten years after the date of grant. As of December 31, 2016, 6.7 million shares of common stock under the 2015 Plan were available for grant.

[0001633978-17-000006:notes:70]
[same as prior period, unchanged from 0001628280-16-020392:notes:71]

[0001633978-17-000006:notes:71]
On June 23, 2015, the board of directors of JDSU approved, and subsequently, our sole stockholder adopted, the 2015 Employee Stock Purchase Plan (the “2015 Purchase Plan”) under which 3.0 million shares of our Common Stock were authorized for issuance. The 2015 Purchase Plan was ratified by our board of directors on July 31, 2015. The 2015 Purchase Plan provides eligible employees with the opportunity to acquire an ownership interest in the Company through periodic payroll deductions and provides a 15% purchase price discount as well as a six-month look-back period. The 2015 Purchase Plan is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986. However, the 2015 Purchase Plan is not intended to be a qualified pension, profit sharing or stock bonus plan under Section 401(a) of the Internal Revenue Code of 1986 and is not subject to the provisions of the Employee Retirement Income Security Act of 1974. The 2015 Purchase Plan will terminate upon the date on which all shares available for issuance have been sold. Of the 3.0 million shares authorized under the 2015 Purchase Plan, 2.6 million shares remained available for issuance as of December 31, 2016.

[0001633978-17-000006:notes:72]
[same as prior period, unchanged from 0001628280-16-020392:notes:73]

[0001633978-17-000006:notes:73]
[same as prior period, unchanged from 0001628280-16-020392:notes:74]

[0001633978-17-000006:notes:74]
[same as prior period, unchanged from 0001628280-16-020392:notes:75]

[0001633978-17-000006:notes:75]
[same as prior period, unchanged from 0001628280-16-020392:notes:76]

[0001633978-17-000006:notes:76]
Restricted stock awards (“RSAs”) are grants of shares of our common stock that are subject to various restrictions, including restrictions on transferability and forfeiture provisions. Restricted stock awards are expected to vest over one to four years, and the shares acquired may not be transferred by the holder until the vesting conditions (if any) are satisfied.

[0001633978-17-000006:notes:77]
[same as prior period, unchanged from 0001628280-16-020392:notes:78]

[0001633978-17-000006:notes:78]
The impact on our results of operations of recording stock-based compensation by function for the three and six months ended December 31, 2016 and December 26, 2015 was as follows (in millions):

[0001633978-17-000006:notes:79]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |  | December 31, 2016 |  | December 26, 2015 |
| Cost of sales | $ | 2.1 |  |  | $ | 1.5 |  |  | $ | 4.1 |  |  | $ | 2.7 |  |
| Research and development | 3.0 |  |  | 2.3 |  |  | 5.8 |  |  | 4.2 |  |
| Selling, general and administrative | 4.0 |  |  | 2.5 |  |  | 7.0 |  |  | 5.9 |  |
|  | $ | 9.1 |  |  | $ | 6.3 |  |  | $ | 16.9 |  |  | $ | 12.8 |  |

[0001633978-17-000006:notes:80]
Approximately $1.0 million and $1.2 million of stock-based compensation was capitalized to inventory as of December 31, 2016 and July 2, 2016, respectively. The table above includes allocated stock-based compensation from Viavi of $0.5 million for the six months ended December 26, 2015. There were no allocations to stock-based compensation from Viavi during the six months ended December 31, 2016. Refer to "Note 3. Related Party Transactions" in the Notes to Consolidated Financial Statements.

[0001633978-17-000006:notes:81]
[same as prior period, unchanged from 0001628280-16-020392:notes:82]

[0001633978-17-000006:notes:82]
We granted no stock options during the three and six months ended December 31, 2016. The total intrinsic value of options exercised by our employees during the three and six months ended December 31, 2016 was $0.5 million and $3.6 million, respectively. The total intrinsic value of options exercised by our employees during the three and six months ended December 26, 2015 was $0.1 million.

[0001633978-17-000006:notes:83]
In connection with these exercises, the tax benefit realized during the three and six months ended December 31, 2016 was $2.9 million. For the three and six months ended December 26, 2015 there has been no tax benefit related to options exercised.

[0001633978-17-000006:notes:84]
As of December 31, 2016, $58.4 million of stock-based compensation cost related to RSUs, performance stock units (“PSUs”), and RSAs granted to our employees remains to be amortized. That cost is expected to be recognized over an estimated amortization period of 2.12 years.

[0001633978-17-000006:notes:85]
The following table summarizes our stock option, RSA, and RSU activities during the three and six months ended December 31, 2016 (amount in millions except per share amounts):

[0001633978-17-000006:notes:86]
|  | Options Outstanding |  | Restricted Stock Units/Awards Outstanding |
|  | Number of Shares |  | Weighted-Average Exercise Price |  | Number of Shares (PSU) |  | Number of Shares(RSU/RSA) |  | Weighted-Average Grant Date Fair Value |
| Outstanding as of July 2, 2016, as converted | 0.3 |  |  | $ | 17.83 |  |  | 0.1 |  |  | 2.5 |  |  | $ | 21.04 |  |
| Granted | — |  |  | — |  |  | — |  |  | 1.1 |  |  | 32.74 |  |
| Exercised / Vested | (0.2 | ) |  | 14.92 |  |  | (0.1 | ) |  | (0.6 | ) |  | 21.11 |  |
| Canceled | — |  |  | — |  |  | — |  |  | (0.1 | ) |  | 21.83 |  |
| Outstanding as of October 1, 2016 | 0.1 |  |  | 22.06 |  |  | — |  |  | 2.9 |  |  | 25.53 |  |
| Granted | — |  |  | — |  |  | — |  |  | 0.1 |  |  | 38.80 |  |
| Exercised / Vested | (0.0) |  |  | 15.29 |  |  | — |  |  | (0.3 | ) |  | 21.11 |  |
| Canceled | — |  |  | — |  |  | — |  |  | — |  |  | 23.02 |  |
| Outstanding as of December 31, 2016 | 0.1 |  |  | 23.35 |  |  | — |  |  | 2.7 |  |  | 26.46 |  |
| Vested and expected to vest | 0.1 |  |  | $ | 23.35 |  |  | — |  |  | 2.4 |  |  | 26.46 |  |

[0001633978-17-000006:notes:87]
Employee Stock Purchase Plan (“ESPP”) Activity

[0001633978-17-000006:notes:88]
The ESPP expense we recorded for the three and six months ended December 31, 2016 was $0.7 million and $1.2 million, respectively. The expense related to the plan is recorded on a straight-line basis over the relevant subscription period. During the three and six months ended December 31, 2016, there were 188,864 shares issued to employees through the ESPP program in one offering period from May 16, 2016 to November 15, 2016.


## us-gaap:EarningsPerShareTextBlock

[0001633978-17-000006:notes:89]
[same as prior period, unchanged from 0001628280-16-020392:notes:90]

[0001633978-17-000006:notes:90]
The following table sets forth the computation of basic and diluted net income (loss) attributable to common stockholders per share (in millions, except per share data):

[0001633978-17-000006:notes:91]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |  | December 31, 2016 |  | December 26, 2015 |
| Numerator: |  |  |  |  |  |  |  |  |  |  |
| Net income | $ | 11.8 |  |  | $ | 2.8 |  |  | $ | 8.4 |  |  | $ | 2.6 |  |
| Less: Cumulative dividends on Series A Preferred Stock | (0.2 | ) |  | (0.2 | ) |  | (0.4 | ) |  | (0.3 | ) |
| Less: Accretion of Series A Preferred Stock | — |  |  | (2.0 | ) |  | — |  |  | (11.7 | ) |
| Net income (loss) attributable to common stockholders | $ | 11.6 |  |  | $ | 0.6 |  |  | $ | 8.0 |  |  | $ | (9.4 | ) |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average number of common shares outstanding |  |  |  |  |  |  |  |
| Basic | 60.3 |  |  | 59.0 |  |  | 60.1 |  |  | 58.9 |  |
| Effect of dilutive securities from stock-based benefit plans | 2.4 |  |  | 0.2 |  |  | 2.5 |  |  | — |  |
| Diluted | 62.7 |  |  | 59.2 |  |  | 62.6 |  |  | 58.9 |  |
| Net income (loss) per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | $ | 0.19 |  |  | $ | 0.01 |  |  | $ | 0.13 |  |  | $ | (0.16 | ) |
| Diluted | $ | 0.19 |  |  | $ | 0.01 |  |  | $ | 0.13 |  |  | $ | (0.16 | ) |

[0001633978-17-000006:notes:92]
On August 1, 2015, JDSU distributed 47.1 million shares, or 80.1% of the outstanding shares of the Company's common stock to existing holders of JDSU common stock. The weighted average number of common stock outstanding is calculated as the number of shares of common stock outstanding immediately following the Separation through December 26, 2015, and the weighted average number of shares outstanding following the Separation through December 31, 2016. Diluted earnings per share is calculated by dividing net income attributable to common stockholders for the period by the weighted average number of shares of common stock and potentially dilutive common stock outstanding for the period beginning after the Separation.

[0001633978-17-000006:notes:93]
[same as prior period, unchanged from 0001628280-16-020392:notes:94]

[0001633978-17-000006:notes:94]
[same as prior period, unchanged from 0001628280-16-020392:notes:95]


## us-gaap:FiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0001633978-17-000006:notes:95]
[same as prior period, unchanged from 0001628280-16-020392:notes:97]

[0001633978-17-000006:notes:96]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |  | December 31, 2016 |  | December 26, 2015 |
| Cost of sales | $ | 1.7 |  |  | $ | 1.7 |  |  | $ | 3.4 |  |  | $ | 3.4 |  |
| Operating expense | 0.1 |  |  | 0.1 |  |  | 0.2 |  |  | 0.2 |  |
| Total | $ | 1.8 |  |  | $ | 1.8 |  |  | $ | 3.6 |  |  | $ | 3.6 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001633978-17-000006:notes:97]
[same as prior period, unchanged from 0001628280-16-020392:notes:99]

[0001633978-17-000006:notes:98]
[same as prior period, unchanged from 0001628280-16-020392:notes:100]

[0001633978-17-000006:notes:99]
The following table presents the changes in goodwill by operating segments during the six months ended December 31, 2016 (in millions):

[0001633978-17-000006:notes:100]
|  |  | Optical Communications |  | Commercial Lasers |  | Total |
| Balance as of July 2, 2016 | $ | — |  |  | $ | 5.4 |  |  | $ | 5.4 |  |
|  | Currency translation | — |  |  | (0.2 | ) |  | (0.2 | ) |
| Balance as of December 31, 2016 | $ | — |  |  | $ | 5.2 |  |  | $ | 5.2 |  |

[0001633978-17-000006:notes:101]
[same as prior period, unchanged from 0001628280-16-020392:notes:103]

[0001633978-17-000006:notes:102]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. In the fourth quarter of fiscal 2016, we completed the annual impairment test of goodwill, which indicated there was no goodwill impairment. During the three and six months ended December 31, 2016, there have been no events or circumstances that have required us to perform an interim assessment of goodwill for impairment.

[0001633978-17-000006:notes:103]
[same as prior period, unchanged from 0001628280-16-020392:notes:105]

[0001633978-17-000006:notes:104]
We allocated acquired developed technology and other intangibles to our Commercial Lasers operating segment. The following tables present details of our acquired developed technology and other intangibles (in millions):

[0001633978-17-000006:notes:105]
| As of December 31, 2016 | Gross Carrying Amount |  | Accumulated Amortization |  | Net |
| Acquired developed technology | $ | 102.7 |  |  | $ | (92.2 | ) |  | $ | 10.5 |  |
| Other | 9.4 |  |  | (9.1 | ) |  | 0.3 |  |
| Total Intangibles | $ | 112.1 |  |  | $ | (101.3 | ) |  | $ | 10.8 |  |

[0001633978-17-000006:notes:106]
[same as prior period, unchanged from 0001628280-16-020392:notes:108]

[0001633978-17-000006:notes:107]
During the three and six months ended December 31, 2016, we recorded $1.8 million and $3.6 million, respectively, of amortization related to acquired developed technology and other intangibles.

[0001633978-17-000006:notes:108]
During the three and six months ended December 26, 2015, the Company recorded $1.8 million and $3.6 million, respectively, of amortization expense relating to acquired developed technology and other intangibles.

[0001633978-17-000006:notes:109]
Based on the carrying amount of acquired developed technology and other intangibles as of December 31, 2016, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001633978-17-000006:notes:110]
| Remainder of 2017 | $ | 2.7 |  |
| 2018 | 2.8 |  |
| 2019 | 2.6 |  |
| 2020 | 2.5 |  |
| Thereafter | 0.2 |  |
| Total amortization | $ | 10.8 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001633978-17-000006:notes:111]
[same as prior period, unchanged from 0001628280-16-020392:notes:112]

[0001633978-17-000006:notes:112]
The effective tax rate was 34.1% and 31.1% for the three and six months ended December 31, 2016, respectively.  The amounts differ from the statutory rate of 35.0% primarily due to operating profit generated in lower rate jurisdictions.

[0001633978-17-000006:notes:113]
The Company recorded a tax provision of $6.1 million and $3.8 million for the three and six months ended December 31, 2016, respectively. The Company recorded a tax provision of $0.5 million and $0.2 million for the three and six months ended December 26, 2015, respectively. The quarterly provision for income taxes is based on the estimated annual effective tax rate, plus any discrete items for the respective year. The Company updates its estimated annual effective tax rate at the end of each quarterly period and takes into account the estimates for annual pre-tax income, the geographical mix of pre-tax income and interpretations of tax laws.

[0001633978-17-000006:notes:114]
The Company’s tax provision for both the three and six months ended December 31, 2016 was primarily due to the tax effect of our operating profits, non-deductible stock-based compensation, and unrecognized tax benefits offset by the benefit from the utilization of US deferred tax assets that were subject to a full valuation allowance.

[0001633978-17-000006:notes:115]
The Company’s tax provision for both the three and six months ended December 26, 2015 was primarily attributable to the utilization of U.S. tax attributes that were subject to a full valuation allowance, and certain Canadian tax incentives.

[0001633978-17-000006:notes:116]
The Company’s net deferred tax assets relate predominantly to the Canadian tax jurisdiction for which it has recognized a partial valuation allowance against these deferred tax assets. The Company weighed both positive and negative evidence and determined that due to the limited carryover period of certain tax attributes in Canada, there is a continued need for a partial valuation allowance against these deferred tax assets as of December 31, 2016. Should the Company determine that it needs to adjust the valuation allowance, the adjustment may have a material impact to net income in the period such determination is made.

[0001633978-17-000006:notes:117]
The Company also evaluates the ability to realize its U.S. net deferred tax assets based on all available evidence, both positive and negative, on a quarterly basis. The realization of net deferred tax assets is dependent on the Company’s ability to generate sufficient future taxable income during periods prior to the expiration of tax attributes to fully utilize these assets. The Company weighed both positive and negative evidence and determined that due to cumulative losses in the United States, there is a continued need for a full valuation allowance against the U.S. deferred tax assets as of December 31, 2016.

[0001633978-17-000006:notes:118]
At December 31, 2016 and December 26, 2015, the Company recorded $4.3 million and $0.1 million, respectively, in its liability for unrecognized tax benefits, which, if recognized, would affect the effective tax rate.

[0001633978-17-000006:notes:119]
The Company is routinely subject to various federal, state and foreign audits by taxing authorities. The timing for the resolution and closure of tax audits is highly unpredictable. Given the uncertainty, it is reasonably possible that certain tax audits may be concluded within the next 12 months that could materially impact the balance of our gross unrecognized tax benefits. The estimated impact to tax expense and net income from the resolution and closure of tax exams is not expected to be significant within the next 12 months.


## us-gaap:MinorityInterestDisclosureTextBlock

[0001633978-17-000006:notes:120]
[same as prior period, unchanged from 0001628280-16-020392:notes:121]

[0001633978-17-000006:notes:121]
[same as prior period, unchanged from 0001628280-16-020392:notes:122]

[0001633978-17-000006:notes:122]
The Series A Preferred Stock is redeemable at the option of Amada after five years and classified as non-controlling interest redeemable convertible preferred stock in our consolidated balance sheet. The Series A Preferred Stock is measured at its redemption value.  The Series A Preferred Stock value of $35.8 million as of December 26, 2015 has not changed from prior periods. The Series A Preferred Stock conversion feature is bifurcated from the Series A Preferred Stock and accounted for separately as a derivative liability.  The derivative liability is measured at fair value each reporting period with the change in fair value recorded in the consolidated statements of operations.

[0001633978-17-000006:notes:123]
[same as prior period, unchanged from 0001628280-16-020392:notes:124]

[0001633978-17-000006:notes:124]
[same as prior period, unchanged from 0001628280-16-020392:notes:125]

[0001633978-17-000006:notes:125]
[same as prior period, unchanged from 0001628280-16-020392:notes:126]

[0001633978-17-000006:notes:126]
[same as prior period, unchanged from 0001628280-16-020392:notes:127]

[0001633978-17-000006:notes:127]
[same as prior period, unchanged from 0001628280-16-020392:notes:128]

[0001633978-17-000006:notes:128]
[same as prior period, unchanged from 0001628280-16-020392:notes:129]

[0001633978-17-000006:notes:129]
[same as prior period, unchanged from 0001628280-16-020392:notes:130]

[0001633978-17-000006:notes:130]
| • | The Series A Preferred Stock has no voting rights except as follows: |

[0001633978-17-000006:notes:131]
[same as prior period, unchanged from 0001628280-16-020392:notes:132]

[0001633978-17-000006:notes:132]
[same as prior period, unchanged from 0001628280-16-020392:notes:133]

[0001633978-17-000006:notes:133]
[same as prior period, unchanged from 0001628280-16-020392:notes:134]

[0001633978-17-000006:notes:134]
[same as prior period, unchanged from 0001628280-16-020392:notes:135]

[0001633978-17-000006:notes:135]
[same as prior period, unchanged from 0001628280-16-020392:notes:136]

[0001633978-17-000006:notes:136]
The accrued dividends as of December 31, 2016 and July 2, 2016 are $0.2 million and $0.2 million, respectively. Dividends paid were $0.4 million for the six months ended December 31, 2016. The Company did not pay dividends during the six months ended December 26, 2015.

[0001633978-17-000006:notes:137]
[same as prior period, unchanged from 0001628280-16-020392:notes:138]

[0001633978-17-000006:notes:138]
[same as prior period, unchanged from 0001628280-16-020392:notes:139]

[0001633978-17-000006:notes:139]
[same as prior period, unchanged from 0001628280-16-020392:notes:140]

[0001633978-17-000006:notes:140]
[same as prior period, unchanged from 0001628280-16-020392:notes:141]

[0001633978-17-000006:notes:141]
[same as prior period, unchanged from 0001628280-16-020392:notes:142]


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001633978-17-000006:notes:142]
In October 2016, the Financial Accounting Standards Board (FASB) issued  Accounting Standards Update (ASU) 2016-16, Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets other than Inventory. The new guidance removes the prohibition in ASC 740 against the immediate recognition of the current and deferred income tax effects of intra-entity transfers of assets other than inventory. The new guidance will be effective for us in our first quarter of fiscal 2019. We are currently evaluating the impact of our pending adoption of ASU 2016-16 on our consolidated financial statements.

[0001633978-17-000006:notes:143]
In August 2016, FASB issued ASU 2016-15, Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments, which clarifies how companies present and classify certain cash receipts and cash payments in the statement of cash flows. ASU 2016-15 is effective for us in our first quarter of fiscal 2019 and earlier adoption is permitted. We are currently evaluating the impact of our pending adoption of ASU 2016-15 on our consolidated financial statements.

[0001633978-17-000006:notes:144]
In March 2016, FASB ASU 2016-9, Stock Compensation ASU 718 - Improvements to Employee Share-Based Payment Accounting. This guidance simplifies various aspects related to how share-based payments are accounted for and presented in the financial statements. This guidance is effective for fiscal years, and interim periods within those years, beginning after December 15, 2016. The Company will adopt this standard in fiscal year 2018. The Company has not yet determined the effect that the adoption of this standard will have on its consolidated financial statements or results of operations.

[0001633978-17-000006:notes:145]
In February 2016, FASB issued ASU 2016-02, Leases. The new guidance generally requires an entity to recognize on its balance sheet operating and financing lease liabilities and corresponding right-of-use assets. The standard is effective for us in our first quarter of fiscal 2019 and early adoption is permitted. The Company is currently evaluating the impact of the adoption of ASU 2016-02 on its consolidated financial statements.

[0001633978-17-000006:notes:146]
In April 2015, FASB issued ASU 2015-04 Compensation-Retirement Benefits to provide a practical expedient that permits the entity to measure defined benefit plan assets and obligations using the month-end that is closest to the entity’s fiscal year-end and apply that practical expedient consistently from year to year. The Company adopted this guidance effective first quarter of fiscal 2017 on a prospective basis. No prior periods were retrospectively adjusted. The Company does not believe this standard will have a material impact on its consolidated financial statements or the related footnote disclosures.

[0001633978-17-000006:notes:147]
In May 2014, FASB issued ASU 2014-09, Revenue from Contracts with Customers, which amended the existing accounting standards for revenue recognition. ASU 2014-09 establishes principles for recognizing revenue upon the transfer of promised goods or services to customers, in an amount that reflects the consideration expected to be received in exchange for those goods or services. The new standard requires that reporting companies disclose the nature, amount, timing and uncertainty of revenue and cash flows arising from contracts with customers. On July 9, 2015, FASB agreed to delay the effective date by one year and, accordingly, the new standard is effective for the Company beginning in the first quarter of fiscal 2018. Early adoption is permitted, but not before the original effective date of the standard. The new standard is required to be applied retrospectively to each prior reporting period presented or retrospectively with the cumulative effect of initially applying it recognized at the date of initial application. The standard is effective for us for our first quarter of fiscal 2018. We are currently evaluating whether this standard will have a material impact on our consolidated financial statements.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001633978-17-000006:notes:148]
Note 3. Related Party Transactions

[0001633978-17-000006:notes:149]
Transactions with Viavi

[0001633978-17-000006:notes:150]
During the three and six months ended December 31, 2016, the Company recognized revenue of $0.9 million and $1.5 million, respectively, from products sold to Viavi. During the three and six months ended December 26, 2015, the Company recognized revenue of $0.7 million and $1.5 million, respectively, for products sold to Viavi.

[0001633978-17-000006:notes:151]
During the three months ended December 31, 2016, the Company did not record any research and development cost reimbursement from Viavi. During the six months ended December 31, 2016, the Company recorded $0.4 million in research and development cost reimbursement from Viavi. For the three and six months ended December 26, 2015, the Company recorded $0.7 million and $1.2 million, respectively, in research and development cost reimbursement.

[0001633978-17-000006:notes:152]
During the three and six months ended December 31, 2016, the Company recorded $0.2 million and $0.4 million, respectively, in sublease rental income. For the three and six months ended December 26, 2015, the Company recorded and $0.2 million and $0.3 million, respectively, in sublease rental income.

[0001633978-17-000006:notes:153]
As of December 31, 2016 and July 2, 2016, the Company had $0.4 million and $1.1 million, respectively, in trade accounts receivable due from Viavi.

[0001633978-17-000006:notes:154]
As of December 31, 2016 and July 2, 2016, the Company had $0.3 million in payables due to Viavi and $2.0 million in other receivables from Viavi, respectively.

[0001633978-17-000006:notes:155]
On July 31, 2015, the Company also entered into the following agreements with Viavi:

[0001633978-17-000006:notes:156]
| a) | Contribution Agreement which identified the assets transferred, the liabilities assumed and the contracts assigned and which provided for when and how these transfers, assumptions and assignments would occur. |

[0001633978-17-000006:notes:157]
| b) | Separation and Distribution Agreement which governs the Separation of the Lumentum business and other matters related to Lumentum’s relationship with Viavi. |

[0001633978-17-000006:notes:158]
| c) | Tax Matters Agreement which governs the respective rights, responsibilities and obligations of Lumentum and Viavi with respect to tax liabilities and benefits, attributes, proceedings, returns and certain other tax matters. |

[0001633978-17-000006:notes:159]
| d) | Employee Matters Agreement which governs the compensation and employee benefit obligations with respect to the current and former employees of Lumentum and Viavi, the treatment of equity based compensation and generally allocates liabilities and responsibilities relating to employee compensation, benefit plans and programs. The Employee Matters Agreement provides that employees of Lumentum will participate in benefit plans sponsored or maintained by Lumentum. |

[0001633978-17-000006:notes:160]
| e) | Securities Purchase Agreement, which also includes Amada Holdings Co., Ltd. (“Amada”) as a party, which sets forth the terms for the sale by Viavi to Amada of shares of Series A Preferred Stock (the "Series A Preferred Stock") of Lumentum Inc., our wholly-owned subsidiary, following the Separation. |

[0001633978-17-000006:notes:161]
| f) | Intellectual Property Matters Agreement which outlines the intellectual property rights of Lumentum and Viavi following the Separation, as well as non-compete restrictions between Viavi and Lumentum. |

[0001633978-17-000006:notes:162]
Allocated Costs

[0001633978-17-000006:notes:163]
From June 28, 2015 to August 1, 2015, the effective date of the Separation, the consolidated statements of operations included the Company's direct expenses for cost of sales, research and development, sales and marketing, and administration as well as allocations of expenses arising from shared services and infrastructure provided by Viavi to the Company. These allocated expenses include costs of information technology, human resources, accounting, legal, real estate and facilities, corporate marketing, insurance, treasury and other corporate and infrastructure services. In addition, other costs allocated to the Company include restructuring and stock-based compensation related to Viavi’s corporate and shared services employees and are included in the table below. These expenses were allocated to the Company using estimates that we consider to be a reasonable reflection of the utilization of services or benefits received by our business. The allocation methods include revenue, headcount, square footage, actual consumption and usage of services and others.

[0001633978-17-000006:notes:164]
There were no allocations of expenses from Viavi for the three and six months ended December 31, 2016, and the three months ended December 26, 2015. During the six months ended December 26, 2015, allocated costs from Viavi included in the accompanying consolidated statements of operations were as follows (in millions):

[0001633978-17-000006:notes:165]
|  | Six Months Ended |
|  | December 26, 2015 |
| Selling, general and administrative | 11.7 |  |
| Interest and other (income) expenses, net | (0.1 | ) |
| Interest expense | 0.1 |  |
| Total allocated costs | $ | 11.7 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001633978-17-000006:notes:166]
[same as prior period, unchanged from 0001628280-16-020392:notes:166]

[0001633978-17-000006:notes:167]
We have initiated various strategic restructuring events primarily intended to reduce costs, consolidate our operations, rationalize the manufacturing of our products and align our business in response to the market conditions. As of December 31, 2016 and July 2, 2016, our total restructuring accrual was $6.0 million and $5.7 million, respectively.

[0001633978-17-000006:notes:168]
As of December 31, 2016, our total restructuring accrual was $6.0 million. During the three and six months ended December 31, 2016, we recorded $4.0 million and $6.9 million, respectively, in restructuring and related charges. Of the $4.0 million and $6.9 million charge recorded during the three months and six months ended December 31, 2016, $1.3 million and $1.7 million, respectively, was related to severance, retention, lease termination costs, and employee benefits; $2.7 million and $5.2 million, respectively, was related to other restructuring related charges which include relocation costs, equipment set-up costs, product qualification costs, facilities, and equipment costs to vacate facilities and consolidate operations. The timing of cash payments associated with these restructuring related charges and exit costs is dependent upon the type of restructuring charge and can extend over multiple periods.

[0001633978-17-000006:notes:169]
As of December 26, 2015, our total restructuring accrual was $4.3 million. During the three and six months ended December 26, 2015, we recorded $1.1 million and $2.1 million, respectively, in restructuring and related charges in the consolidated statements of operations.

[0001633978-17-000006:notes:170]
[same as prior period, unchanged from 0001628280-16-020392:notes:168]

[0001633978-17-000006:notes:171]
The adjustments to the restructuring accrual related to all of our restructuring plans described below as of December 31, 2016, were as follows (in millions):

[0001633978-17-000006:notes:172]
|  | Fiscal 2015 & earlier Restructuring Plan |  | Fiscal 2016 Restructuring Plan |  |  |
|  | Restructuring Charges |  | Exit Costs |  | Other Charges |  | Restructuring Charges |  | Total |
| Liability as of July 2, 2016 | $ | 4.5 |  |  | $ | 0.5 |  |  | $ | — |  |  | $ | 0.7 |  |  | $ | 5.7 |  |
| Charges | 1.7 |  |  | — |  |  | 5.2 |  |  | — |  |  | 6.9 |  |
| Payments | (0.6 | ) |  | (0.1 | ) |  | (5.2 | ) |  | (0.7 | ) |  | (6.6 | ) |
| Liability as of December 31, 2016 | $ | 5.6 |  |  | $ | 0.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 6.0 |  |

[0001633978-17-000006:notes:173]
As of December 31, 2016, our restructuring liability includes $5.9 million in short-term other current liabilities and $0.1 million in other non-current liabilities on the consolidated balance sheets. The total amount expected to be incurred under the fiscal 2015 Plan is $6.8 million, of which $1.7 million was incurred during the six months ended December 31, 2016. The cumulative amount incurred as of December 31, 2016 is $5.5 million.

[0001633978-17-000006:notes:174]
[same as prior period, unchanged from 0001628280-16-020392:notes:172]


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001633978-17-000006:notes:175]
[same as prior period, unchanged from 0001628280-16-020392:notes:175]

[0001633978-17-000006:notes:176]
|  | December 31, 2016 |  | July 2, 2016 |
| Property, Plant and Equipment, net |  |  |  |
| United States | $ | 86.9 |  |  | $ | 69.0 |  |
| Canada | 18.3 |  |  | 21.4 |  |
| China | 68.1 |  |  | 46.6 |  |
| Thailand | 44.0 |  |  | 43.8 |  |
| Other Asia-Pacific | 0.3 |  |  | 0.2 |  |
| EMEA | 2.0 |  |  | 2.4 |  |
| Total Property, Plant and Equipment, net | $ | 219.6 |  |  | $ | 183.4 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001633978-17-000006:notes:177]
[same as prior period, unchanged from 0001628280-16-020392:notes:177]

[0001633978-17-000006:notes:178]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |  | December 31, 2016 |  | December 26, 2015 |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 35.6 |  |  | 13.4 | % |  | $ | 28.0 |  |  | 12.8 | % |  | $ | 71.5 |  |  | 13.7 | % |  | $ | 62.5 |  |  | 14.5 | % |
| Mexico | 48.7 |  |  | 18.4 |  |  | 36.5 |  |  | 16.7 |  |  | 88.5 |  |  | 16.9 |  |  | 78.3 |  |  | 18.2 |  |
| Other Americas | 1.9 |  |  | 0.7 |  |  | 5.0 |  |  | 2.3 |  |  | 5.9 |  |  | 1.1 |  |  | 12.8 |  |  | 3.0 |  |
| Total Americas | $ | 86.2 |  |  | 32.5 | % |  | $ | 69.5 |  |  | 31.8 | % |  | $ | 165.9 |  |  | 31.7 | % |  | $ | 153.6 |  |  | 35.7 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 75.7 |  |  | 28.6 | % |  | $ | 51.8 |  |  | 23.8 | % |  | $ | 134.0 |  |  | 25.6 | % |  | $ | 82.6 |  |  | 19.1 | % |
| Japan | 21.3 |  |  | 8.0 |  |  | 21.0 |  |  | 9.6 |  |  | 52.6 |  |  | 10.1 |  |  | 46.0 |  |  | 10.7 |  |
| Thailand | 16.9 |  |  | 6.4 |  |  | 25.5 |  |  | 11.7 |  |  | 45.5 |  |  | 8.7 |  |  | 44.0 |  |  | 10.2 |  |
| Other Asia-Pacific | 36.1 |  |  | 13.6 |  |  | 20.8 |  |  | 9.5 |  |  | 72.9 |  |  | 13.9 |  |  | 42.3 |  |  | 9.8 |  |
| Total Asia-Pacific | $ | 150.0 |  |  | 56.6 | % |  | $ | 119.1 |  |  | 54.6 | % |  | $ | 305.0 |  |  | 58.3 | % |  | $ | 214.9 |  |  | 49.8 | % |
| EMEA | $ | 28.8 |  |  | 10.9 | % |  | $ | 29.7 |  |  | 13.6 | % |  | $ | 52.2 |  |  | 10.0 | % |  | $ | 62.4 |  |  | 14.5 | % |
| Total net revenue | $ | 265.0 |  |  |  |  | $ | 218.3 |  |  |  |  | $ | 523.1 |  |  |  |  | $ | 430.9 |  |  |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001633978-17-000006:notes:179]
[same as prior period, unchanged from 0001628280-16-020392:notes:179]

[0001633978-17-000006:notes:180]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |  | December 31, 2016 |  | December 26, 2015 |
| Net revenue: |  |  |  |  |  |  |  |
| OpComms | $ | 236.6 |  |  | $ | 185.8 |  |  | $ | 454.9 |  |  | $ | 362.9 |  |
| Lasers | 28.4 |  |  | 32.5 |  |  | 68.2 |  |  | 68.0 |  |
| Net revenue | $ | 265.0 |  |  | $ | 218.3 |  |  | $ | 523.1 |  |  | $ | 430.9 |  |
| Gross profit: |  |  |  |  |  |  |  |
| OpComms | 86.7 |  |  | 57.1 |  |  | 157.7 |  |  | 112.7 |  |
| Lasers | 11.2 |  |  | 14.2 |  |  | 28.4 |  |  | 28.4 |  |
| Total segment gross profit | 97.9 |  |  | 71.3 |  |  | 186.1 |  |  | 141.1 |  |
| Unallocated amounts: |  |  |  |  |  |  |  |
| Stock-based compensation | (2.1 | ) |  | (1.5 | ) |  | (4.1 | ) |  | (2.7 | ) |
| Amortization of intangibles | (1.7 | ) |  | (1.7 | ) |  | (3.4 | ) |  | (3.4 | ) |
| Other charges | (7.1 | ) |  | — |  |  | (9.9 | ) |  | — |  |
| Gross profit | $ | 87.0 |  |  | $ | 68.1 |  |  | $ | 168.7 |  |  | $ | 135.0 |  |


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001633978-17-000006:notes:181]
[same as prior period, unchanged from 0001628280-16-020392:notes:181]

[0001633978-17-000006:notes:182]
|  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  | December 31, 2016 |  | December 26, 2015 |  | December 31, 2016 |  | December 26, 2015 |
| OpComms: |  |  | 89.4 | % |  | 85.1 | % |  | 86.9 | % |  | 84.2 | % |
| Telecom |  |  | 60.5 | % |  | 63.1 | % |  | 62.3 | % |  | 62.8 | % |
| Datacom |  |  | 25.7 | % |  | 16.0 | % |  | 21.4 | % |  | 16.4 | % |
| Consumer and Industrial |  |  | 3.2 | % |  | 6.0 | % |  | 3.2 | % |  | 5.0 | % |
| Lasers |  |  | 10.6 | % |  | 14.9 | % |  | 13.1 | % |  | 15.8 | % |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001633978-17-000006:notes:183]
[same as prior period, unchanged from 0001628280-16-020392:notes:183]

[0001633978-17-000006:notes:184]
[same as prior period, unchanged from 0001628280-16-020392:notes:184]

[0001633978-17-000006:notes:185]
[same as prior period, unchanged from 0001628280-16-020392:notes:185]

[0001633978-17-000006:notes:186]
[same as prior period, unchanged from 0001628280-16-020392:notes:186]

[0001633978-17-000006:notes:187]
[same as prior period, unchanged from 0001628280-16-020392:notes:187]

[0001633978-17-000006:notes:188]
[same as prior period, unchanged from 0001628280-16-020392:notes:188]

[0001633978-17-000006:notes:189]
[same as prior period, unchanged from 0001628280-16-020392:notes:189]

[0001633978-17-000006:notes:190]
[same as prior period, unchanged from 0001628280-16-020392:notes:190]

[0001633978-17-000006:notes:191]
[same as prior period, unchanged from 0001628280-16-020392:notes:191]

[0001633978-17-000006:notes:192]
[same as prior period, unchanged from 0001628280-16-020392:notes:192]

[0001633978-17-000006:notes:193]
[same as prior period, unchanged from 0001628280-16-020392:notes:193]

[0001633978-17-000006:notes:194]
We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments because management does not include the information in its measurement of the performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, stock-based compensation, and other charges impacting the gross margin of each segment because management does not include this information in its measurement of the performance of the operating segments. Other charges are primarily warranty expenses that were accrued and which are expected to be reimbursed by the manufacturer.

[0001633978-17-000006:notes:195]
[same as prior period, unchanged from 0001628280-16-020392:notes:195]

[0001633978-17-000006:notes:196]
Our net revenue is primarily denominated in U.S. dollars, including our net revenue from customers outside the United States as presented above.
