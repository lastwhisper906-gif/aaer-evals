# LITE 8-K — 0001633978-17-000005 filed 2017-02-07

## item codes, every 8-K on or before 2017-02-07

- 2017-02-07 0001633978-17-000005 — 2.02, 9.01
- 2017-01-03 0001628280-17-000018 — 4.01, 9.01
- 2016-11-09 0001628280-16-021143 — 5.02, 5.07, 9.01
- 2016-10-27 0001628280-16-020382 — 2.02, 9.01
- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2017-02-07

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001633978-17-000005:8k_2_02:1]
EX-99.1
2
liteex991q2fy17.htm
EXHIBIT 99.1

[0001633978-17-000005:8k_2_02:2]
Exhibit

[0001633978-17-000005:8k_2_02:3]
NEWS RELEASE

[0001633978-17-000005:8k_2_02:4]
LUMENTUM ANNOUNCES FISCAL SECOND QUARTER 2017 RESULTS

[0001633978-17-000005:8k_2_02:5]
Fiscal Second Quarter Highlights

[0001633978-17-000005:8k_2_02:6]
| • | Net Revenue of $265.0 million exceeded mid-point of guidance |

[0001633978-17-000005:8k_2_02:7]
| • | GAAP Operating margin of 5.0%; Non-GAAP Operating margin of 14.7% exceeded high-end of guidance |

[0001633978-17-000005:8k_2_02:8]
| • | GAAP diluted Net income per share of $0.19; Non-GAAP diluted Net income per share of $0.57 exceeded high-end of guidance |

[0001633978-17-000005:8k_2_02:9]
Milpitas, Calif., February 7, 2017 – Lumentum Holdings Inc. ("Lumentum" or the "Company") today reported results for its fiscal second quarter ended December 31, 2016.

[0001633978-17-000005:8k_2_02:10]
Net revenue for the fiscal second quarter of 2017 was $265.0 million, with GAAP net income of $11.8 million or $0.19 per diluted share. Net revenue for the fiscal first quarter of 2017 was $258.1 million, with GAAP net loss of $(3.4) million, or $(0.06) per diluted share. Net revenue for the fiscal second quarter of 2016 was $218.3 million, with GAAP net income of $2.8 million, or $0.05 per diluted share.

[0001633978-17-000005:8k_2_02:11]
Non-GAAP net income for the fiscal second quarter of 2017 was $35.9 million or $0.57 per diluted share. Non-GAAP net income for the fiscal first quarter of 2017 was $30.7 million, or $0.49 per diluted share. Non-GAAP net income for the fiscal second quarter of 2016 was $19.1 million, or $0.31 per diluted share. The Company held $155.9 million in total cash at the end of the fiscal second quarter 2017 and remains debt-free.

[0001633978-17-000005:8k_2_02:12]
"We achieved record revenue of $265.0 million, growing 21% year over year," said Alan Lowe, president and CEO. "Strong growth in new product revenue, particularly 100G datacom, which was up 124% sequentially and more than 500% year over year, drove operating margin to a new record high of 14.7%."

[0001633978-17-000005:8k_2_02:13]
Financial Overview – Fiscal Second Quarter Ended December 31, 2016

[0001633978-17-000005:8k_2_02:14]
|  | GAAP Results ($ in millions) |
|  | Q2 |  | Q1 |  | Q2 |  | Change |
|  | FY 2017 |  | FY 2017 |  | FY 2016 |  | Q/Q |  | Y/Y |
| Net revenue | $ | 265.0 |  |  | $ | 258.1 |  |  | $ | 218.3 |  |  | 2.7 | % |  | 21.4 | % |
| Gross margin | 32.8 | % |  | 31.7 | % |  | 31.2 | % |  | 110bps |  |  | 160bps |  |
| Operating margin | 5.0 | % |  | 6.5 | % |  | 2.8 | % |  | (150)bps |  |  | 220bps |  |
|  | Non-GAAP Results ($ in millions) |
|  | Q2 |  | Q1 |  | Q2 |  | Change |
|  | FY 2017 |  | FY 2017 |  | FY 2016 |  | Q/Q |  | Y/Y |
| Net revenue | $ | 265.0 |  |  | $ | 258.1 |  |  | $ | 218.3 |  |  | 2.7 | % |  | 21.4 | % |
| Gross margin | 36.9 | % |  | 34.2 | % |  | 32.7 | % |  | 270bps |  |  | 420bps |  |
| Operating margin | 14.7 | % |  | 12.7 | % |  | 9.0 | % |  | 200bps |  |  | 570bps |  |

[0001633978-17-000005:8k_2_02:15]
|  | Net Revenue by Segment ($ in millions) |
|  | Q2 |  | % of |  | Q1 |  | Q2 |  | Change |
|  | FY 2017 |  | Net Revenue |  | FY 2017 |  | FY 2016 |  | Q/Q |  | Y/Y |
| Optical Communications | $ | 236.6 |  |  | 89.3 | % |  | $ | 218.3 |  |  | $ | 185.8 |  |  | 8.4 | % |  | 27.3 | % |
| Lasers | 28.4 |  |  | 10.7 | % |  | 39.8 |  |  | 32.5 |  |  | (28.6 | )% |  | (12.6 | )% |
| Total | $ | 265.0 |  |  | 100.0 | % |  | $ | 258.1 |  |  | $ | 218.3 |  |  | 2.7 | % |  | 21.4 | % |

[0001633978-17-000005:8k_2_02:16]
The tables above provide comparisons of quarterly results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled "Use of Non-GAAP Financial Measures."

[0001633978-17-000005:8k_2_02:17]
Business Outlook

[0001633978-17-000005:8k_2_02:18]
For the fiscal third quarter of 2017, the Company expects net revenue to be in the range of $250 million to $265 million, non-GAAP operating margin to be 12.5% to 14.0%, and non-GAAP diluted earnings per share to be $0.46 to $0.54 per share, based on approximately 63.0 million shares outstanding on a fully diluted basis.

[0001633978-17-000005:8k_2_02:19]
We have not provided reconciliations from GAAP to non-GAAP measures for our outlook. A large portion of non-GAAP adjustments, such as derivative liability adjustments, restructuring, stock-based compensation, litigation, and other costs and contingencies unrelated to current and future operations are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future. For example, the unrealized gain or loss on the derivative liability for Series A Preferred Stock in our fiscal second quarter of 2017 was a gain of $4.8 million and is revalued based on the fair market value of our common stock on the last day of each fiscal quarter, which is difficult to predict and subject to change.

[0001633978-17-000005:8k_2_02:20]
Conference Call

[0001633978-17-000005:8k_2_02:21]
Lumentum will host a conference call on February 7, 2017 at 1:30pm PT/4:30pm ET. A live webcast of the call and the replay will be available on the Lumentum website at http://investor.lumentum.com. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the "Events and Presentations" section concurrently with this earnings press release. This press release will be available on our website at http:/investor.lumentum.com under the "Events and Presentations" section and is also being furnished as a Current Report on Form 8-K with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001633978-17-000005:8k_2_02:22]
About Lumentum

[0001633978-17-000005:8k_2_02:23]
Lumentum (NASDAQ: LITE) is a market-leading manufacturer of innovative optical and photonic products enabling optical networking and commercial laser customers worldwide. Lumentum’s optical components and subsystems are part of virtually every type of telecom, enterprise, and data center network. Lumentum’s commercial lasers enable advanced manufacturing techniques and diverse applications including next-generation 3D sensing capabilities. Lumentum is headquartered in Milpitas, California with R&D, manufacturing, and sales offices worldwide.  For more information, visit https://www.lumentum.com/en.

[0001633978-17-000005:8k_2_02:24]
Forward-Looking Statements

[0001633978-17-000005:8k_2_02:25]
For more information on these and other risks, please refer to the "Risk Factors" section included in the Company’s 10-Q filed on October 27, 2016 with the Securities and Exchange Commission, and the Company’s other filings with the Securities and Exchange Commission. The forward-looking statements and preliminary financial results contained in this press release are made as of the date hereof and the Company assumes no obligation to update such statements, except as required by applicable law.

[0001633978-17-000005:8k_2_02:26]
Contact Information

[0001633978-17-000005:8k_2_02:27]
Investors: Chris Coldren, 408-404-0606; investor.relations@lumentum.com

[0001633978-17-000005:8k_2_02:28]
Press: Greg Kaufman, 408-546-4235; media@lumentum.com

[0001633978-17-000005:8k_2_02:29]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001633978-17-000005:8k_2_02:30]
LUMENTUM HOLDINGS INC.

[0001633978-17-000005:8k_2_02:31]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001633978-17-000005:8k_2_02:32]
(in millions, except per share data)

[0001633978-17-000005:8k_2_02:33]
(unaudited)

[0001633978-17-000005:8k_2_02:34]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |  | December 31, 2016 |  | December 26, 2015 |
| Net revenue | $ | 265.0 |  |  | $ | 218.3 |  |  | $ | 523.1 |  |  | $ | 430.9 |  |
| Cost of sales | 176.3 |  |  | 148.5 |  |  | 351.0 |  |  | 292.5 |  |
| Amortization of acquired technologies | 1.7 |  |  | 1.7 |  |  | 3.4 |  |  | 3.4 |  |
| Gross profit | 87.0 |  |  | 68.1 |  |  | 168.7 |  |  | 135.0 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 38.7 |  |  | 35.0 |  |  | 75.6 |  |  | 69.4 |  |
| Selling, general and administrative | 31.0 |  |  | 25.8 |  |  | 56.1 |  |  | 59.8 |  |
| Restructuring and related charges | 4.0 |  |  | 1.1 |  |  | 6.9 |  |  | 2.1 |  |
| Total operating expenses | 73.7 |  |  | 61.9 |  |  | 138.6 |  |  | 131.3 |  |
| Income from operations | 13.3 |  |  | 6.2 |  |  | 30.1 |  |  | 3.7 |  |
| Unrealized gain (loss) on derivative liability | 4.8 |  |  | (2.4 | ) |  | (17.9 | ) |  | (0.2 | ) |
| Interest and other income (expense), net | (0.2 | ) |  | (0.5 | ) |  | — |  |  | (0.7 | ) |
| Income before income taxes | 17.9 |  |  | 3.3 |  |  | 12.2 |  |  | 2.8 |  |
| Provision for income taxes | 6.1 |  |  | 0.5 |  |  | 3.8 |  |  | 0.2 |  |
| Net income | 11.8 |  |  | 2.8 |  |  | 8.4 |  |  | 2.6 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.20 |  |  | $ | 0.05 |  |  | $ | 0.14 |  |  | $ | 0.04 |  |
| Diluted | $ | 0.19 |  |  | $ | 0.05 |  |  | $ | 0.13 |  |  | $ | 0.04 |  |
| Items reconciling net income to net income available to common stockholders: |  |  |  |  |  |  |  |
| Dividends on Series A preferred stock | (0.2 | ) |  | (0.2 | ) |  | (0.4 | ) |  | (0.3 | ) |
| Adjustment for Series A preferred stock redemption value | — |  |  | (2.0 | ) |  | — |  |  | (11.7 | ) |
| Net income available to common stockholders | $ | 11.6 |  |  | $ | 0.6 |  |  | $ | 8.0 |  |  | $ | (9.4 | ) |
| Net income available to common stockholders per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.19 |  |  | $ | 0.01 |  |  | $ | 0.13 |  |  | $ | (0.16 | ) |
| Diluted | $ | 0.19 |  |  | $ | 0.01 |  |  | $ | 0.13 |  |  | $ | (0.16 | ) |
| Shares used in per share calculation: |  |  |  |  |  |  |  |
| Basic | 60.3 |  |  | 59.0 |  |  | 60.1 |  |  | 58.9 |  |
| Diluted | 62.7 |  |  | 59.2 |  |  | 62.6 |  |  | 58.9 |  |

[0001633978-17-000005:8k_2_02:35]
LUMENTUM HOLDINGS INC.

[0001633978-17-000005:8k_2_02:36]
CONSOLIDATED BALANCE SHEETS

[0001633978-17-000005:8k_2_02:37]
(in millions, except share and per share data)

[0001633978-17-000005:8k_2_02:38]
(unaudited)

[0001633978-17-000005:8k_2_02:39]
|  | December 31, 2016 |  | July 2, 2016 |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |  |
| Cash and cash equivalents | $ | 155.9 |  |  | $ | 157.1 |  |
| Accounts receivable, net | 192.5 |  |  | 170.5 |  |
| Inventories | 121.0 |  |  | 100.6 |  |
| Prepayments and other current assets | 58.2 |  |  | 61.3 |  |
| Total current assets | 527.6 |  |  | 489.5 |  |
| Property, plant and equipment, net | 219.6 |  |  | 183.4 |  |
| Goodwill and intangibles, net | 16.0 |  |  | 19.9 |  |
| Deferred income taxes, net | 30.8 |  |  | 31.9 |  |
| Other non-current assets | 2.7 |  |  | 1.6 |  |
| Total assets | $ | 796.7 |  |  | $ | 726.3 |  |
| LIABILITIES, REDEEMABLE CONVERTIBLE PREFERRED STOCK, AND EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 127.8 |  |  | $ | 118.3 |  |
| Accrued payroll and related expenses | 36.0 |  |  | 26.5 |  |
| Income taxes payable | 0.4 |  |  | 1.9 |  |
| Accrued expenses | 16.5 |  |  | 14.9 |  |
| Other current liabilities | 21.3 |  |  | 12.1 |  |
| Total current liabilities | 202.0 |  |  | 173.7 |  |
| Derivative liability | 28.2 |  |  | 10.3 |  |
| Other non-current liabilities | 14.3 |  |  | 9.1 |  |
| Total liabilities | 244.5 |  |  | 193.1 |  |
| Redeemable convertible preferred stock: |  |  |  |
| Non-controlling interest redeemable convertible Series A preferred stock, $0.001 par value, 10,000,000 authorized shares; 35,805 shares issued and outstanding as of December 31, 2016 and as of July 2, 2016 | 35.8 |  |  | 35.8 |  |
| Total redeemable convertible preferred stock | 35.8 |  |  | 35.8 |  |
| Stockholders’ equity: |  |  |  |
| Common stock, $0.001 par value, 990,000,000 shares authorized, 60,580,652 and 59,580,596 shares issued and outstanding as of December 31, 2016, and July 2, 2016, respectively | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital | 483.3 |  |  | 467.7 |  |
| Retained earnings | 28.2 |  |  | 20.2 |  |
| Accumulated other comprehensive income | 4.8 |  |  | 9.4 |  |
| Total stockholders’ equity | 516.4 |  |  | 497.4 |  |
| Total liabilities and stockholders' equity | $ | 796.7 |  |  | $ | 726.3 |  |

[0001633978-17-000005:8k_2_02:40]
Use of Non-GAAP Financial Measures

[0001633978-17-000005:8k_2_02:41]
In this press release, Lumentum provides investors with gross margin, operating margin, net income, net income per share and Adjusted EBITDA on a non-GAAP basis. Lumentum also supplementally provides gross profit, income (loss) before income taxes and certain expenses (collectively “non-GAAP expenses”) on a non-GAAP basis. Lumentum believes this non-GAAP financial information provides additional insight into the Company's on-going performance and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company's on-going operations and enable more meaningful period to period comparisons. Specifically, the Company believes that providing this information allows investors to better understand the Company’s financial performance and, importantly, to evaluate the efficacy of the methodology and information used by management to evaluate and measure such operating performance.  However, these measures may be different from non-GAAP measures used by other companies, limiting their usefulness for comparison purposes. The non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP. Investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future. Further, these non-GAAP financial measures may not be comparable to similarly titled measurements reported by other companies.

[0001633978-17-000005:8k_2_02:42]
Non-GAAP gross margin, non-GAAP operating margin, non-GAAP net income, and non-GAAP net income per share, Adjusted EBITDA, non-GAAP gross profit, income (loss) before income taxes and non-GAAP expenses exclude (i) workforce related charges such as severance, retention bonuses and employee relocation costs related to formal restructuring plans, (ii) costs for facilities not required for ongoing operations, and costs related to the relocation of certain equipment from these facilities and/or contract manufacturer facilities, (iii) stock-based compensation, (iv) amortization of intangibles, (v)amortization of acquired developed technologies, (vi) non-cash interest expense, (vii) unrealized loss on derivative liability, and (viii) warranty charges related to our vendor quality issues with expected future recoveries and (ix) other charges comprising mainly of one-time provision for excess and obsolete inventory, acquisition, integration, litigation and other costs and contingencies unrelated to current and future operations including post-separation activities such as small site consolidations, reorganizations, insourcing or outsourcing of activities, severance related costs and transition related costs for the separation from Viavi. Beginning in the third fiscal quarter 2016, we began to exclude unrealized gain or loss on derivative liability for the Series A Preferred Stock from Adjusted EBITDA and prior periods have been adjusted. Management does not believe that these items are reflective of the Company's underlying operating performance. The presentation of these and other similar items in Lumentum's non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001633978-17-000005:8k_2_02:43]
A quantitative reconciliation between GAAP and non-GAAP financial data with respect to historical periods is included in the supplemental financial table attached to this press release. The Company has not reconciled its projections of non-GAAP earnings per share.  As items that impact net loss are out of the Company's control and/or cannot be reasonably predicted, Lumentum has determined that a quantitative reconciliation of forward-looking non-GAAP financial measures to their most directly comparable GAAP financial measures cannot be provided without unreasonable efforts.

[0001633978-17-000005:8k_2_02:44]
LUMENTUM HOLDINGS INC.

[0001633978-17-000005:8k_2_02:45]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001633978-17-000005:8k_2_02:46]
(in millions, except per share data)

[0001633978-17-000005:8k_2_02:47]
(unaudited)

[0001633978-17-000005:8k_2_02:48]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |  | December 31, 2016 |  | December 26, 2015 |
| Gross profit on GAAP basis | $ | 87.0 |  |  | $ | 68.1 |  |  | $ | 168.7 |  |  | $ | 135.0 |  |
| Stock-based compensation | 2.1 |  |  | 1.5 |  |  | 4.1 |  |  | 2.7 |  |
| Other charges related to non-recurring activities | 7.1 |  |  | — |  |  | 9.9 |  |  | — |  |
| Amortization of acquired developed technologies | 1.7 |  |  | 1.7 |  |  | 3.4 |  |  | 3.4 |  |
| Gross profit on non-GAAP basis | $ | 97.9 |  |  | $ | 71.3 |  |  | $ | 186.1 |  |  | $ | 141.1 |  |
| Research and development on GAAP basis | $ | 38.7 |  |  | $ | 35.0 |  |  | $ | 75.6 |  |  | $ | 69.4 |  |
| Stock-based compensation | (3.0 | ) |  | (2.3 | ) |  | (5.8 | ) |  | (4.2 | ) |
| Other charges related to non-recurring activities | (0.3 | ) |  | — |  |  | (0.6 | ) |  | (0.6 | ) |
| Research and development on non-GAAP basis | $ | 35.4 |  |  | $ | 32.7 |  |  | $ | 69.2 |  |  | $ | 64.6 |  |
| Selling, general and administrative on GAAP basis | $ | 31.0 |  |  | $ | 25.8 |  |  | $ | 56.1 |  |  | $ | 59.8 |  |
| Stock-based compensation | (4.0 | ) |  | (2.5 | ) |  | (6.9 | ) |  | (5.9 | ) |
| Other charges related to non-recurring activities | (3.4 | ) |  | (4.2 | ) |  | (3.8 | ) |  | (12.0 | ) |
| Amortization of intangibles | (0.1 | ) |  | (0.1 | ) |  | (0.2 | ) |  | (0.2 | ) |
| Selling, general and administrative on non-GAAP basis | $ | 23.5 |  |  | $ | 19.0 |  |  | $ | 45.2 |  |  | $ | 41.7 |  |
| Income from operations on GAAP basis | $ | 13.3 |  |  | $ | 6.2 |  |  | $ | 30.1 |  |  | $ | 3.7 |  |
| Stock-based compensation | 9.1 |  |  | 6.3 |  |  | 16.8 |  |  | 12.8 |  |
| Other charges related to non-recurring activities | 10.8 |  |  | 4.2 |  |  | 14.3 |  |  | 12.6 |  |
| Amortization of intangibles | 1.8 |  |  | 1.8 |  |  | 3.6 |  |  | 3.6 |  |
| Restructuring and related charges | 4.0 |  |  | 1.1 |  |  | 6.9 |  |  | 2.1 |  |
| Income from operations on non-GAAP basis | $ | 39.0 |  |  | $ | 19.6 |  |  | $ | 71.7 |  |  | $ | 34.8 |  |
| Income before income taxes on GAAP basis | $ | 17.9 |  |  | $ | 3.3 |  |  | $ | 12.2 |  |  | $ | 2.8 |  |
| Stock-based compensation | 9.1 |  |  | 6.3 |  |  | 16.8 |  |  | 12.8 |  |
| Other charges related to non-recurring activities | 10.8 |  |  | 4.2 |  |  | 14.3 |  |  | 12.6 |  |
| Amortization of intangibles | 1.8 |  |  | 1.8 |  |  | 3.6 |  |  | 3.6 |  |
| Restructuring and related charges | 4.0 |  |  | 1.1 |  |  | 6.9 |  |  | 2.1 |  |
| Other income | (0.2 | ) |  | — |  |  | (0.2 | ) |  | — |  |
| Unrealized (gain) loss on derivative liability | (4.8 | ) |  | 2.4 |  |  | 17.9 |  |  | 0.2 |  |
| Income before income taxes on non-GAAP basis | $ | 38.6 |  |  | $ | 19.1 |  |  | $ | 71.5 |  |  | $ | 34.1 |  |
| Provision for income taxes on GAAP basis | $ | 6.1 |  |  | $ | 0.5 |  |  | $ | 3.8 |  |  | $ | 0.2 |  |
| Income tax effect of non-GAAP exclusions | (3.4 | ) |  | (0.5 | ) |  | 1.1 |  |  | — |  |
| Provision for income taxes on non-GAAP basis | $ | 2.7 |  |  | $ | — |  |  | $ | 4.9 |  |  | $ | 0.2 |  |
| Net income on GAAP basis | $ | 11.8 |  |  | $ | 2.8 |  |  | $ | 8.4 |  |  | $ | 2.6 |  |
| Stock-based compensation | 9.1 |  |  | 6.3 |  |  | 16.8 |  |  | 12.8 |  |

[0001633978-17-000005:8k_2_02:49]
| Other charges related to non-recurring activities | 10.8 |  |  | 4.2 |  |  | 14.3 |  |  | 12.6 |  |
| Amortization of intangibles | 1.8 |  |  | 1.8 |  |  | 3.6 |  |  | 3.6 |  |
| Restructuring and related charges | 4.0 |  |  | 1.1 |  |  | 6.9 |  |  | 2.1 |  |
| Other income | (0.2 | ) |  | — |  |  | (0.2 | ) |  | — |  |
| Unrealized (gain) loss on derivative liability | (4.8 | ) |  | 2.4 |  |  | 17.9 |  |  | 0.2 |  |
| Income tax effect of non-GAAP exclusions | 3.4 |  |  | 0.5 |  |  | (1.1 | ) |  | — |  |
| Net income on non-GAAP basis | $ | 35.9 |  |  | $ | 19.1 |  |  | $ | 66.6 |  |  | $ | 33.9 |  |
| Net income per share on non-GAAP basis | $ | 0.57 |  |  | $ | 0.31 |  |  | $ | 1.06 |  |  | $ | 0.56 |  |
| Shares used in per share calculation - diluted on non-GAAP basis | 62.7 |  |  | 60.7 |  |  | 62.6 |  |  | 60.3 |  |

[0001633978-17-000005:8k_2_02:50]
LUMENTUM HOLDINGS INC.

[0001633978-17-000005:8k_2_02:51]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EBITDA

[0001633978-17-000005:8k_2_02:52]
(in millions)

[0001633978-17-000005:8k_2_02:53]
(unaudited)

[0001633978-17-000005:8k_2_02:54]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |  | December 31, 2016 |  | December 26, 2015 |
| GAAP net income | $ | 11.8 |  |  | $ | 2.8 |  |  | $ | 8.4 |  |  | $ | 2.6 |  |
| Interest and other expense (income), net | 0.2 |  |  | 0.5 |  |  | — |  |  | 0.7 |  |
| Provision for income taxes | 6.1 |  |  | 0.5 |  |  | 3.8 |  |  | 0.2 |  |
| Depreciation | 13.1 |  |  | 12.1 |  |  | 25.0 |  |  | 23.8 |  |
| Amortization | 1.8 |  |  | 1.8 |  |  | 3.6 |  |  | 3.6 |  |
| EBITDA | 33.0 |  |  | 17.7 |  |  | 40.8 |  |  | 30.9 |  |
| Costs related to restructuring and related charges | 4.0 |  |  | 1.1 |  |  | 6.9 |  |  | 2.1 |  |
| Costs related to stock-based compensation | 9.1 |  |  | 6.3 |  |  | 16.8 |  |  | 12.8 |  |
| Costs related to other non-recurring activities | 10.8 |  |  | 4.2 |  |  | 14.3 |  |  | 12.6 |  |
| Unrealized (gain) loss on derivative liability | (4.8 | ) |  | 2.4 |  |  | 17.9 |  |  | 0.2 |  |
| Adjusted EBITDA | $ | 52.1 |  |  | $ | 31.7 |  |  | $ | 96.7 |  |  | $ | 58.6 |  |
