# LITE MD&A — 0001633978-17-000006


## mdna

[0001633978-17-000006:mdna:1]
[same as prior period, unchanged from 0001628280-16-020392:mdna:1]

[0001633978-17-000006:mdna:2]
[same as prior period, unchanged from 0001628280-16-020392:mdna:2]

[0001633978-17-000006:mdna:3]
[same as prior period, unchanged from 0001628280-16-020392:mdna:3]

[0001633978-17-000006:mdna:4]
[same as prior period, unchanged from 0001628280-16-020392:mdna:4]

[0001633978-17-000006:mdna:5]
[same as prior period, unchanged from 0001628280-16-020392:mdna:5]

[0001633978-17-000006:mdna:6]
[same as prior period, unchanged from 0001628280-16-020392:mdna:6]

[0001633978-17-000006:mdna:7]
[same as prior period, unchanged from 0001628280-16-020392:mdna:7]

[0001633978-17-000006:mdna:8]
[same as prior period, unchanged from 0001628280-16-020392:mdna:8]

[0001633978-17-000006:mdna:9]
[same as prior period, unchanged from 0001628280-16-020392:mdna:9]

[0001633978-17-000006:mdna:10]
Our OpComms customers include Ciena Corporation, Cisco Systems, Inc., Coriant GmbH, Fujitsu, Alphabet Inc. (formerly Google), Huawei Technologies Co. Ltd., Microsoft Corporation and Nokia Networks (including Alcatel-Lucent International).

[0001633978-17-000006:mdna:11]
[same as prior period, unchanged from 0001628280-16-020392:mdna:11]

[0001633978-17-000006:mdna:12]
[same as prior period, unchanged from 0001628280-16-020392:mdna:12]

[0001633978-17-000006:mdna:13]
[same as prior period, unchanged from 0001628280-16-020392:mdna:13]

[0001633978-17-000006:mdna:14]
[same as prior period, unchanged from 0001628280-16-020392:mdna:14]

[0001633978-17-000006:mdna:15]
[same as prior period, unchanged from 0001628280-16-020392:mdna:15]

[0001633978-17-000006:mdna:16]
[same as prior period, unchanged from 0001628280-16-020392:mdna:16]

[0001633978-17-000006:mdna:17]
[same as prior period, unchanged from 0001628280-16-020392:mdna:17]

[0001633978-17-000006:mdna:18]
[same as prior period, unchanged from 0001628280-16-020392:mdna:18]

[0001633978-17-000006:mdna:19]
[same as prior period, unchanged from 0001628280-16-020392:mdna:19]

[0001633978-17-000006:mdna:20]
[same as prior period, unchanged from 0001628280-16-020392:mdna:20]

[0001633978-17-000006:mdna:21]
[same as prior period, unchanged from 0001628280-16-020392:mdna:21]

[0001633978-17-000006:mdna:22]
[same as prior period, unchanged from 0001628280-16-020392:mdna:22]

[0001633978-17-000006:mdna:23]
[same as prior period, unchanged from 0001628280-16-020392:mdna:23]

[0001633978-17-000006:mdna:24]
| • | Derivative Liability |

[0001633978-17-000006:mdna:25]
[same as prior period, unchanged from 0001628280-16-020392:mdna:24]

[0001633978-17-000006:mdna:26]
Derivative Liability

[0001633978-17-000006:mdna:27]
Starting in three months ended December 31, 2016, the Company assessed the derivative liability to be one of the critical accounting policies. The Series A Preferred Stock is redeemable at the option of Amada after five years and classified as non-controlling interest redeemable convertible preferred stock in our combined and consolidated balance sheet and is measured at its redemption value. The Series A Preferred Stock conversion feature is bifurcated from the Series A Preferred Stock and accounted for separately as a derivative liability. On a quarterly basis, the derivative liability is marked to market based on the fair value of the conversion feature, with the resulting income or loss recorded as unrealized loss on derivative liability on our consolidated statements of operations.  The determination of fair value includes various inputs, including volatility and interest rate assumptions. However, the change in the fair value of our common stock has the largest impact to the fair value of the derivative.

[0001633978-17-000006:mdna:28]
In many cases, the accounting treatment of a particular transaction is specifically dictated by GAAP and does not require management’s judgment in its application. There are also areas in which management’s judgment in selecting among available alternatives would not produce a materially different result. Our senior management has reviewed our critical accounting policies and related disclosures with the Audit Committee of our board of directors.

[0001633978-17-000006:mdna:29]
During the second quarter of fiscal 2017, there were no significant changes to our critical accounting policies and estimates. Management’s Discussion and Analysis of Financial Condition and Results of Operations contained in Part II, Item 7 of our Annual Report on Form 10-K for our fiscal year ended July 2, 2016 provides a more complete discussion of our critical accounting policies and estimates.

[0001633978-17-000006:mdna:30]
Recently Issued Accounting Pronouncements

[0001633978-17-000006:mdna:31]
Refer to "Note 2. Recently Issued Accounting Pronouncements" in the Notes to Consolidated Financial Statements.

[0001633978-17-000006:mdna:32]
[same as prior period, unchanged from 0001628280-16-020392:mdna:29]

[0001633978-17-000006:mdna:33]
[same as prior period, unchanged from 0001628280-16-020392:mdna:30]

[0001633978-17-000006:mdna:34]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |  | December 31, 2016 |  | December 26, 2015 |
| Segment net revenue: |  |  |  |  |  |  |  |
| OpComms | 89.3 | % |  | 85.1 | % |  | 87.0 | % |  | 84.2 | % |
| Lasers | 10.7 |  |  | 14.9 |  |  | 13.0 |  |  | 15.8 |  |
| Net revenue | 100.0 |  |  | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of sales | 66.6 |  |  | 68.0 |  |  | 67.1 |  |  | 67.9 |  |
| Amortization of acquired technologies | 0.6 |  |  | 0.8 |  |  | 0.6 |  |  | 0.8 |  |
| Gross profit | 32.8 |  |  | 31.2 |  |  | 32.3 |  |  | 31.3 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 14.6 |  |  | 16.1 |  |  | 14.5 |  |  | 16.1 |  |
| Selling, general and administrative | 11.7 |  |  | 11.8 |  |  | 10.7 |  |  | 13.9 |  |
| Restructuring and related charges | 1.5 |  |  | 0.5 |  |  | 1.3 |  |  | 0.5 |  |
| Total operating expenses | 27.8 |  |  | 28.4 |  |  | 26.5 |  |  | 30.5 |  |
| Income from operations | 5.0 |  |  | 2.8 |  |  | 5.8 |  |  | 0.9 |  |
| Unrealized gain (loss) on derivative liabilities | 1.8 |  |  | (1.1 | ) |  | (3.4 | ) |  | — |  |
| Interest and other income (expense), net | (0.1 | ) |  | (0.2 | ) |  | — |  |  | (0.2 | ) |
| Income before income taxes | 6.7 |  |  | 1.5 |  |  | 2.4 |  |  | 0.6 |  |
| Provision for income tax | 2.3 |  |  | 0.2 |  |  | 0.7 |  |  | — |  |
| Net income | 4.4 | % |  | 1.3 | % |  | 1.7 | % |  | 0.6 | % |

[0001633978-17-000006:mdna:35]
Financial Data for the three and six months ended December 31, 2016 and December 26, 2015

[0001633978-17-000006:mdna:36]
27

[0001633978-17-000006:mdna:37]
[same as prior period, unchanged from 0001628280-16-020392:mdna:34]

[0001633978-17-000006:mdna:38]
|  | Three Months Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | December 31, 2016 |  | December 26, 2015 |  | Change |  | Percentage Change |  | December 31, 2016 |  | December 26, 2015 |  | Change |  | Percentage Change |
| Segment net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| OpComms | $ | 236.6 |  |  | $ | 185.8 |  |  | $ | 50.8 |  |  | 27.3 | % |  | $ | 454.9 |  |  | $ | 362.9 |  |  | $ | 92.0 |  |  | 25.4 | % |
| Lasers | 28.4 |  |  | 32.5 |  |  | (4.1 | ) |  | (12.6 | ) |  | 68.2 |  |  | 68.0 |  |  | 0.2 |  |  | 0.3 |  |
| Net revenue | $ | 265.0 |  |  | $ | 218.3 |  |  | $ | 46.7 |  |  | 21.4 | % |  | $ | 523.1 |  |  | $ | 430.9 |  |  | $ | 92.2 |  |  | 21.4 | % |
| Gross profit | $ | 87.0 |  |  | $ | 68.1 |  |  | $ | 18.9 |  |  | 27.8 | % |  | $ | 168.7 |  |  | $ | 135.0 |  |  | $ | 33.7 |  |  | 25.0 | % |
| Gross margin | 32.8 | % |  | 31.2 | % |  |  |  |  |  | 32.3 | % |  | 31.3 | % |  |  |  |  |
| Research and development | 38.7 |  |  | 35.0 |  |  | 3.7 |  |  | 10.6 | % |  | 75.6 |  |  | 69.4 |  |  | 6.2 |  |  | 8.9 | % |
| Percentage of net revenue | 14.6 | % |  | 16.0 | % |  |  |  |  |  | 14.5 | % |  | 16.1 | % |  |  |  |  |
| Selling, general and administrative | 31.0 |  |  | 25.8 |  |  | 5.2 |  |  | 20.2 | % |  | 56.1 |  |  | 59.8 |  |  | (3.7 | ) |  | (6.2 | )% |
| Percentage of net revenue | 11.7 | % |  | 11.8 | % |  |  |  |  |  | 10.7 | % |  | 13.9 | % |  |  |  |  |
| Restructuring and related charges | 4.0 |  |  | 1.1 |  |  | 2.9 |  |  | 263.6 | % |  | 6.9 |  |  | 2.1 |  |  | 4.8 |  |  | 228.6 | % |
| Percentage of net revenue | 1.5 | % |  | 0.5 | % |  |  |  |  |  | 1.3 | % |  | 0.5 | % |  |  |  |  |

[0001633978-17-000006:mdna:39]
[same as prior period, unchanged from 0001628280-16-020392:mdna:37]

[0001633978-17-000006:mdna:40]
Net revenue increased by $46.7 million, or 21.4%, during the three months ended December 31, 2016 compared to the three months ended December 26, 2015. This increase was primarily due to an increase in net revenue from our OpComms segment, partially offset by a decrease in revenue from our Lasers segment.

[0001633978-17-000006:mdna:41]
OpComms net revenue increased by $50.8 million, or 27.3%, during the three months ended December 31, 2016 compared to the three months ended December 26, 2015, driven by an increase in demand for our 100G datacom products.

[0001633978-17-000006:mdna:42]
Lasers net revenue decreased by $4.1 million, or 12.6%, during the three months ended December 31, 2016 compared to the three months ended December 26, 2015. This change was primarily due to lower demand for our solid state lasers and ultrafast lasers products.

[0001633978-17-000006:mdna:43]
Net revenue increased by $92.2 million, or 21.4%, during the six months ended December 31, 2016 compared to the six months ended December 26, 2015. This increase was primarily due to an increase in net revenue from our OpComms segment.

[0001633978-17-000006:mdna:44]
OpComms net revenue increased by $92.0 million, or 25.4%, during the six months ended December 31, 2016 compared to the six months ended December 26, 2015, driven by an increase in demand for our 100G datacom and supertransport blade products.

[0001633978-17-000006:mdna:45]
Lasers net revenue increased by $0.2 million, or 0.3%, during the six months ended December 31, 2016 compared to the six months ended December 26, 2015. This change was primarily due to an increase in revenue for our fiber lasers products and partially offset by a decrease in revenue for our ultrafast lasers products.

[0001633978-17-000006:mdna:46]
[same as prior period, unchanged from 0001628280-16-020392:mdna:39]

[0001633978-17-000006:mdna:47]
We operate in three geographic regions: Americas, Asia-Pacific and EMEA. Net revenue is assigned to the geographic region and country where our product is initially shipped. For example, certain customers may request shipment of our product to a contract manufacturer in one country, but the location of the end customers may differ. The following table presents net revenue by the three geographic regions we operate in and net revenue from countries that represented 10% or more of our total net revenue (in millions, except for percentages):

[0001633978-17-000006:mdna:48]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |  | December 31, 2016 |  | December 26, 2015 |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 35.6 |  |  | 13.4 | % |  | $ | 28.0 |  |  | 12.8 | % |  | $ | 71.5 |  |  | 13.7 | % |  | $ | 62.5 |  |  | 14.5 | % |
| Mexico | 48.7 |  |  | 18.4 |  |  | 36.5 |  |  | 16.7 |  |  | 88.5 |  |  | 16.9 |  |  | 78.3 |  |  | 18.2 |  |
| Other Americas | 1.9 |  |  | 0.7 |  |  | 5.0 |  |  | 2.3 |  |  | 5.9 |  |  | 1.1 |  |  | 12.8 |  |  | 3.0 |  |
| Total Americas | $ | 86.2 |  |  | 32.5 | % |  | $ | 69.5 |  |  | 31.8 | % |  | $ | 165.9 |  |  | 31.7 | % |  | $ | 153.6 |  |  | 35.7 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 75.7 |  |  | 28.6 | % |  | $ | 51.8 |  |  | 23.8 | % |  | $ | 134.0 |  |  | 25.6 |  |  | $ | 82.6 |  |  | 19.1 | % |
| Japan | 21.3 |  |  | 8.0 |  |  | 21.0 |  |  | 9.6 |  |  | 52.6 |  |  | 10.1 |  |  | 46.0 |  |  | 10.7 |  |
| Thailand | 16.9 |  |  | 6.4 |  |  | 25.5 |  |  | 11.7 |  |  | 45.5 |  |  | 8.7 |  |  | 44.0 |  |  | 10.2 |  |
| Other Asia-Pacific | 36.1 |  |  | 13.6 |  |  | 20.8 |  |  | 9.5 |  |  | 72.9 |  |  | 13.9 |  |  | 42.3 |  |  | 9.8 |  |
| Total Asia-Pacific | $ | 150.0 |  |  | 56.6 | % |  | $ | 119.1 |  |  | 54.6 | % |  | $ | 305.0 |  |  | 58.3 | % |  | $ | 214.9 |  |  | 49.8 | % |
| EMEA | $ | 28.8 |  |  | 10.9 | % |  | $ | 29.7 |  |  | 13.6 | % |  | $ | 52.2 |  |  | 10.0 | % |  | $ | 62.4 |  |  | 14.5 | % |
| Total net revenue | $ | 265.0 |  |  |  |  | $ | 218.3 |  |  |  |  | $ | 523.1 |  |  |  |  | $ | 430.9 |  |  |  |

[0001633978-17-000006:mdna:49]
Our net revenue is primarily denominated in U.S. dollars, including our net revenue from customers outside the United States as presented above. We expect revenue from customers outside of the United States to continue to be an important part of our overall net revenue and an increasing focus for net revenue growth opportunities.

[0001633978-17-000006:mdna:50]
[same as prior period, unchanged from 0001628280-16-020392:mdna:43]

[0001633978-17-000006:mdna:51]
The following table summarizes segment gross margin for the three and six months ended December 31, 2016 and December 26, 2015 (in millions, except for percentages):

[0001633978-17-000006:mdna:52]
|  |  | Gross Margin |  |  |  | Gross Margin |
|  | Three Months Ended |  | Three Months Ended |  | Six Months Ended |  | Six Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |  | December 31, 2016 |  | December 26, 2015 |  | December 31, 2016 |  | December 26, 2015 |  | December 31, 2016 |  | December 26, 2015 |
| OpComms | $ | 86.7 |  |  | $ | 57.1 |  |  | 36.6 | % |  | 30.7 | % |  | $ | 157.7 |  |  | $ | 112.7 |  |  | 34.7 | % |  | 31.1 | % |
| Lasers | 11.2 |  |  | 14.2 |  |  | 39.4 | % |  | 43.7 | % |  | 28.4 |  |  | 28.4 |  |  | 41.6 | % |  | 41.8 | % |
| Segment total | $ | 97.9 |  |  | $ | 71.3 |  |  | 36.9 | % |  | 32.7 | % |  | $ | 186.1 |  |  | $ | 141.1 |  |  | 35.6 | % |  | 32.7 | % |
| Unallocated corporate items (1) | (10.9 | ) |  | (3.2 | ) |  |  |  |  |  | (17.4 | ) |  | (6.1 | ) |  |  |  |  |
| Total | $ | 87.0 |  |  | $ | 68.1 |  |  | 32.8 | % |  | 31.2 | % |  | $ | 168.7 |  |  | $ | 135.0 |  |  | 32.3 | % |  | 31.3 | % |

[0001633978-17-000006:mdna:53]
(1) The unallocated corporate items for the three month periods presented include the effects of amortization of acquired developed technology intangible assets, share-based compensation, warranty charges, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0001633978-17-000006:mdna:54]
[same as prior period, unchanged from 0001628280-16-020392:mdna:47]

[0001633978-17-000006:mdna:55]
[same as prior period, unchanged from 0001628280-16-020392:mdna:48]

[0001633978-17-000006:mdna:56]
[same as prior period, unchanged from 0001628280-16-020392:mdna:49]

[0001633978-17-000006:mdna:57]
[same as prior period, unchanged from 0001628280-16-020392:mdna:50]

[0001633978-17-000006:mdna:58]
OpComms gross margin during the three months ended December 31, 2016 increased by 5.9% to 36.6% from 30.7% in the three months ended December 26, 2015. The improvement was due to an increase in higher margin 100G datacom products.  To a lesser extent, the positive impact from cost reductions was offset by inventory charges.

[0001633978-17-000006:mdna:59]
OpComms gross margin during the six months ended December 31, 2016 increased by 3.6% to 34.7% from 31.1% in the six months ended December 26, 2015. The improvement was due to an increase in volumes of high margin products.  To a lesser extent, the positive impact from cost reductions was offset by inventory charges.

[0001633978-17-000006:mdna:60]
[same as prior period, unchanged from 0001628280-16-020392:mdna:52]

[0001633978-17-000006:mdna:61]
Lasers gross margin during the three months ended December 31, 2016 decreased by 4.3% to 39.4% from 43.7% in the three months ended December 26, 2015. The decrease was due mainly to lower sales volumes of our high margin fiber lasers.

[0001633978-17-000006:mdna:62]
Lasers gross margin during the six months ended December 31, 2016 was relatively flat compared to the six months ended December 26, 2015.

[0001633978-17-000006:mdna:63]
[same as prior period, unchanged from 0001628280-16-020392:mdna:54]

[0001633978-17-000006:mdna:64]
R&D expense increased by $3.7 million, or 10.6%, for the three months ended December 31, 2016 compared to the three months ended December 26, 2015. The increase in R&D expense was primarily due to the increase in the headcount related expense of $3.3 million during the three months ended December 31, 2016.

[0001633978-17-000006:mdna:65]
R&D expense increased by $6.2 million, or 8.9%, for the six months ended December 31, 2016 compared to the six months ended December 26, 2015. The increase in R&D expense was primarily due to the increased headcount related expense of $4.5 million and stock-based compensation of $1.6 million during the six months ended December 31, 2016.

[0001633978-17-000006:mdna:66]
[same as prior period, unchanged from 0001628280-16-020392:mdna:57]

[0001633978-17-000006:mdna:67]
[same as prior period, unchanged from 0001628280-16-020392:mdna:58]

[0001633978-17-000006:mdna:68]
SG&A expense increased by $5.2 million, or 20.2%, during the three months ended December 31, 2016 compared to the three months ended December 26, 2015. The increase was primarily attributable to the increased employee compensation of $1.7 million, stock-based compensation of $1.5 million, and facility spend related to expansion of $2.2 million during the three months ended December 31, 2016.

[0001633978-17-000006:mdna:69]
SG&A expense decreased by $3.7 million, or 6.2%, during the six months ended December 31, 2016 compared to the six months ended December 26, 2015. The change was primarily driven by pre-Separation costs of $8.2 million during the six months ended December 26, 2015, that were not repeated in the 2016 period, offset by the increase in headcount of $3.1 million and stock-based compensation of $1.1 million during the six months ended December 31, 2016.

[0001633978-17-000006:mdna:70]
We may experience in the future, certain non-core expenses, such as mergers and acquisitions-related expenses and litigation expenses, which could increase our SG&A expenses and potentially impact our profitability expectations in any particular quarter.

[0001633978-17-000006:mdna:71]
[same as prior period, unchanged from 0001628280-16-020392:mdna:61]

[0001633978-17-000006:mdna:72]
We have reduced costs through targeted restructuring efforts intended to consolidate our operations, rationalize the manufacturing of our products and align our business in response to market conditions. We estimate annualized cost savings of $13.9 million as of December 31, 2016, excluding any one-time charge as a result of the restructuring activities described below. Refer to "Note 10. Restructuring and Related Charges" in the Notes to Consolidated Financial Statements.

[0001633978-17-000006:mdna:73]
As of December 31, 2016, our total restructuring accrual was $6.0 million. During the three and six months ended December 31, 2016, we recorded $4.0 million and $6.9 million, respectively, in restructuring and related charges. Of the $4.0 million and

[0001633978-17-000006:mdna:74]
$6.9 million charge recorded during the three months and six months ended December 31, 2016, $1.3 million and $1.7 million, respectively, was related to severance, retention, lease termination costs, and employee benefits, and $2.7 million and $5.2 million, respectively, was related to other restructuring related charges which include relocation costs, equipment set-up costs, product qualification costs, facilities, and equipment costs to vacate facilities and consolidate operations. The timing of cash payments associated with these restructuring related charges and exit costs is dependent upon the type of restructuring charge and can extend over multiple periods.

[0001633978-17-000006:mdna:75]
The total amount expected to be incurred under the fiscal 2015 Plan is $6.8 million, of which $1.7 million was incurred during the six months ended December 31, 2016. The cumulative amount incurred as of December 31, 2016 is $5.5 million.

[0001633978-17-000006:mdna:76]
As of December 26, 2015, our total restructuring accrual was $4.3 million. During the three and six months ended December 26, 2015, we recorded $1.1 million and $2.1 million, respectively, in restructuring charges. These charges are primarily due to a previously announced restructuring plan for our Bloomfield, Connecticut site for severance and benefits. Refer to “Note 10. Restructuring and Related Charges” in the Notes to Consolidated Financial Statements. The Company is expected to pay these charges in fiscal 2018.

[0001633978-17-000006:mdna:77]
[same as prior period, unchanged from 0001628280-16-020392:mdna:65]

[0001633978-17-000006:mdna:78]
Interest and other income (expense), net is comprised substantially of gains and losses associated with the re-measurement of non-functional currency denominated monetary assets and liabilities, as well as other transactions outside of the normal course of business.

[0001633978-17-000006:mdna:79]
Interest and other income (expense), net was $(0.2) million and $0.0 million, respectively, during the three and six months ended December 31, 2016 as compared to $(0.5) million and $(0.7) million, respectively, for the three and six months ended December 26, 2015. The change was primarily due to higher foreign exchange gains for the three and six months ended December 31, 2016.

[0001633978-17-000006:mdna:80]
[same as prior period, unchanged from 0001628280-16-020392:mdna:68]

[0001633978-17-000006:mdna:81]
The change in the fair value of the bifurcated embedded derivative of gain of $4.8 million and loss of $17.9 million, respectively, for three and six months ended December 31, 2016, is primarily related to the change in the price of the Company's underlying common stock and is reflected in the consolidated statements of operations as "Unrealized gain (loss) on derivative liability".

[0001633978-17-000006:mdna:82]
[same as prior period, unchanged from 0001628280-16-020392:mdna:70]

[0001633978-17-000006:mdna:83]
Provision for Income Taxes

[0001633978-17-000006:mdna:84]
The effective tax rate was 34.1% and 31.1% for the three and six months ended December 31, 2016, respectively.  The amounts differ from the statutory rate of 35.0% primarily due to operating profit generated in lower rate jurisdictions.

[0001633978-17-000006:mdna:85]
We recorded a tax provision of $6.1 million and $3.8 million for the three and six months ended December 31, 2016, respectively. We recorded a tax provision of $0.5 million and $0.2 million for the three and six months ended December 26, 2015, respectively.

[0001633978-17-000006:mdna:86]
The Company’s tax provision for both the three and six months ended December 31, 2016 was primarily due to the tax effect of our operating profits, non-deductible stock-based compensation, and unrecognized tax benefits offset by the benefit from the utilization of US deferred tax assets that were subject to a full valuation allowance.

[0001633978-17-000006:mdna:87]
The tax provision for both the three and six months ended December 26, 2015 was primarily attributable to the utilization of U.S. tax attributes that were subject to a full valuation allowance, and certain Canadian tax incentives.

[0001633978-17-000006:mdna:88]
[same as prior period, unchanged from 0001628280-16-020392:mdna:74]

[0001633978-17-000006:mdna:89]
[same as prior period, unchanged from 0001628280-16-020392:mdna:75]

[0001633978-17-000006:mdna:90]
We presented our contractual obligations at July 2, 2016 in our Annual Report on Form 10-K for the fiscal year then ended. There have been no material changes outside the ordinary course of business in those obligations during the six months ended December 31, 2016, other than as noted under the section entitled "Note 13. Commitments and Contingencies"  in the Notes to Consolidated Financial Statements.

[0001633978-17-000006:mdna:91]
[same as prior period, unchanged from 0001628280-16-020392:mdna:77]

[0001633978-17-000006:mdna:92]
[same as prior period, unchanged from 0001628280-16-020392:mdna:78]

[0001633978-17-000006:mdna:93]
[same as prior period, unchanged from 0001628280-16-020392:mdna:79]

[0001633978-17-000006:mdna:94]
[same as prior period, unchanged from 0001628280-16-020392:mdna:80]

[0001633978-17-000006:mdna:95]
As of December 31, 2016 and July 2, 2016, our cash and cash equivalents of $155.9 million and $157.1 million, respectively, were held predominantly in the United States, Cayman Islands, Canada, China and Japan. The total amount of cash outside the United States as of December 31, 2016 is $103.6 million. Although the cash generated in the United States from future operations is expected to cover our normal operating requirements, a substantial amount of additional cash could be required for other purposes, such as capital expenditures to support our business and growth, strategic transactions and partnerships, acquisitions, dividends that may be declared, and future stock repurchase programs. Our intent is to indefinitely reinvest funds held outside the United States and our current plans do not demonstrate a need to repatriate them to fund our domestic operations. However, if in the future, we encounter a significant need for liquidity domestically or at a particular location that we cannot fulfill through borrowings, equity offerings, or other internal or external sources, we may determine that cash repatriations are necessary. Repatriation could result in additional material U.S. federal and state income tax payments in future years. Such adverse consequences would occur, for example, if the transfer of cash into the United States is taxed and no foreign tax credit is available to offset the U.S. tax liability, resulting in higher taxes. These factors may cause us to have an overall tax rate higher than other companies or higher than our tax rates have been in the past. If conditions warrant, we may seek to obtain additional financing through debt or equity sources. To the extent we issue additional shares, our existing stockholders may be diluted. However, any such financing may not be available on terms favorable to us, or may not be available at all.

[0001633978-17-000006:mdna:96]
As of December 31, 2016, our consolidated balance of cash and cash equivalents decreased by $1.2 million, to $155.9 million from $157.1 million as of July 2, 2016. The decrease in cash and cash equivalents was mainly due to capital expenditures exceeding operating activities during the six months ended December 31, 2016.

[0001633978-17-000006:mdna:97]
[same as prior period, unchanged from 0001628280-16-020392:mdna:83]

[0001633978-17-000006:mdna:98]
Cash provided by operating activities was $55.5 million during the six months ended December 31, 2016, primarily resulting from $8.4 million of net income and $60.4 million of non-cash items such as depreciation, stock-based compensation, amortization of intangibles, unrealized gain on derivative liability, offset by changes in excess tax benefit associated with stock-based compensation and changes in operating assets and liabilities of $13.3 million. Changes in our operating assets and liabilities related primarily to an increase in accounts receivable of $22.0 million due to the timing of collections, an increase in inventories of $20.1 million related to the growth in our business, offset by a decrease in accrued expenses and other current and non-current liabilities of $12.5 million and a decrease in accrued payroll and related expenses of $9.6 million.

[0001633978-17-000006:mdna:99]
Cash provided by operating activities was $53.0 million during the six months ended December 26, 2015, primarily resulting from $2.6 million of net income and $40.4 million of non-cash items such as depreciation, stock-based compensation, amortization of intangibles and unrealized loss on derivative liability, and changes in operating assets and liabilities of $10.0 million. Changes in our operating assets and liabilities related primarily to an increase in accounts payable of $18.2 million, an increase in accrued payroll and related expenses of $13.6 million, an increase in accrued expenses and other current and non-current liabilities of $3.3 million, an increase in accounts receivable of $11.1 million, an increase in inventories of $9.7 million, and an increase in other current and non-current assets of $5.2 million.

[0001633978-17-000006:mdna:100]
[same as prior period, unchanged from 0001628280-16-020392:mdna:86]

[0001633978-17-000006:mdna:101]
Cash used in investing activities was for capital expenditures of $64.3 million and $35.7 million during the six months ended December 31, 2016 and December 26, 2015, respectively.

[0001633978-17-000006:mdna:102]
[same as prior period, unchanged from 0001628280-16-020392:mdna:88]

[0001633978-17-000006:mdna:103]
Cash provided by financing activities was $9.0 million during the six months ended December 31, 2016 resulting primarily from issuance of common stock under the employee stock plan.

[0001633978-17-000006:mdna:104]
Cash provided by financing activities was $130.1 million during the six months ended December 26, 2015 resulting primarily from net transfers from Viavi.

[0001633978-17-000006:mdna:105]
Liquidity and Capital Resources Requirements

[0001633978-17-000006:mdna:106]
We expect our primary liquidity and capital spending requirements over at least the next 12 months to be the funding of our operating activities and capital expenditures. We believe that our cash and cash equivalents as of December 31, 2016, and cash flows from our operating activities will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months. However, if market conditions are favorable, we may evaluate alternatives to opportunistically pursue additional financing.

[0001633978-17-000006:mdna:107]
[same as prior period, unchanged from 0001628280-16-020392:mdna:94]

[0001633978-17-000006:mdna:108]
[same as prior period, unchanged from 0001628280-16-020392:mdna:95]

[0001633978-17-000006:mdna:109]
[same as prior period, unchanged from 0001628280-16-020392:mdna:96]

[0001633978-17-000006:mdna:110]
[same as prior period, unchanged from 0001628280-16-020392:mdna:97]

[0001633978-17-000006:mdna:111]
[same as prior period, unchanged from 0001628280-16-020392:mdna:98]

[0001633978-17-000006:mdna:112]
[same as prior period, unchanged from 0001628280-16-020392:mdna:99]

[0001633978-17-000006:mdna:113]
[same as prior period, unchanged from 0001628280-16-020392:mdna:100]

[0001633978-17-000006:mdna:114]
[same as prior period, unchanged from 0001628280-16-020392:mdna:101]

[0001633978-17-000006:mdna:115]
[same as prior period, unchanged from 0001628280-16-020392:mdna:102]

[0001633978-17-000006:mdna:116]
[same as prior period, unchanged from 0001628280-16-020392:mdna:103]

[0001633978-17-000006:mdna:117]
[same as prior period, unchanged from 0001628280-16-020392:mdna:104]

[0001633978-17-000006:mdna:118]
[same as prior period, unchanged from 0001628280-16-020392:mdna:105]

[0001633978-17-000006:mdna:119]
[same as prior period, unchanged from 0001628280-16-020392:mdna:106]
