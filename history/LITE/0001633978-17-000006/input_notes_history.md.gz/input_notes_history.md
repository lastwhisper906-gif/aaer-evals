# LITE note change history — 0001628280-16-020392 → 0001633978-17-000006


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-02-07):
[0001633978-17-000006:note_history:1]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2026. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. As of December 31, 2016, the future minimum annual lease payments under non-cancellable operating leases were as follows (in millions):
  (was, 2016-10-27, similarity 0.9888):
[0001628280-16-020392:note_history:1]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2026. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. As of October 1, 2016 the future minimum annual lease payments under non-cancellable operating leases were as follows (in millions):

- changed (2017-02-07):
[0001633978-17-000006:note_history:2]
Purchase obligations of $122.3 million as of December 31, 2016, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.
  (was, 2016-10-27, similarity 0.9921):
[0001628280-16-020392:note_history:2]
Purchase obligations of $125.4 million as of October 1, 2016, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

- changed (2017-02-07):
[0001633978-17-000006:note_history:3]
The following table presents the changes in our warranty reserve during the three and six months ended December 31, 2016 and December 26, 2015 (in millions):
  (was, 2016-10-27, similarity 0.9301):
[0001628280-16-020392:note_history:3]
The following table presents the changes in our warranty reserve during the three months ended October 1, 2016 and September 26, 2015 (in millions):

- added (2017-02-07):
[0001633978-17-000006:note_history:4]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |  | December 31, 2016 |  | December 26, 2015 |
| Balance as of beginning of period | $ | 5.4 |  |  | $ | 2.5 |  |  | $ | 2.8 |  |  | $ | 2.8 |  |
| Provision for warranty | 4.9 |  |  | 0.8 |  |  | 8.7 |  |  | 1.7 |  |
| Utilization of reserve | (1.6 | ) |  | (0.3 | ) |  | (2.8 | ) |  | (1.5 | ) |
| Adjustments related to pre-existing warranties (includingchanges in estimates) | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Balance as of period end | $ | 8.7 |  |  | $ | 3.1 |  |  | $ | 8.7 |  |  | $ | 3.1 |  |

- removed (2017-02-07):
[0001628280-16-020392:note_history:5]
Rental expense was $2.2 million and $1.5 million for the three months ended October 1, 2016 and September 26, 2015, respectively.

- removed (2017-02-07):
[0001628280-16-020392:note_history:6]
|  | Three months ended |
|  | October 1, 2016 |  | September 26, 2015 |
| Balance as of beginning of period | $ | 2.8 |  |  | $ | 2.8 |  |
| Provision for warranty | 3.8 |  |  | 0.9 |  |
| Utilization of reserve | (1.2 | ) |  | (1.2 | ) |
| Balance as of period end | $ | 5.4 |  |  | $ | 2.5 |  |

- removed (2017-02-07):
[0001628280-16-020392:note_history:7]
In connection with the Separation, we agreed to indemnify Viavi for any liability associated with contamination from past operations at all properties transferred to us from Viavi, to the extent the resulting issues primarily related to our business.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-02-07):
[0001633978-17-000006:note_history:8]
Lumentum Holdings Inc. ("we", "our", "Lumentum" or the "Company") is an industry leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including data communications ("Datacom") and telecommunications ("Telecom") networking and commercial lasers ("Commercial Lasers") for manufacturing, inspection and life-science applications. We are using our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including 3-D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be original equipment manufacturers ("OEMs") that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that our network equipment manufacturer ("NEM") customers assemble into communications networking systems, which they sell to network service providers or enterprises with their own networks. Similarly, many of our customers for our Commercial Lasers products incorporate our products into tools they produce, which are used for manufacturing processes by their customers.
  (was, 2016-10-27, similarity 0.9959):
[0001628280-16-020392:note_history:8]
Lumentum Holdings Inc. ("we", "our", "Lumentum" or the "Company") is an industry leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including data communications ("Datacom") and telecommunications ("Telecom") networking and commercial lasers ("commercial lasers") for manufacturing, inspection and life-science applications. We are using our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including 3-D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be original equipment manufacturers ("OEMs") that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that our network equipment manufacturer ("NEM") customers assemble into communications networking systems, which they sell to network service providers or enterprises with their own networks. Similarly, many of our customers for our Lasers products incorporate our products into tools they produce, which are used for manufacturing processes by their customers.

- changed (2017-02-07):
[0001633978-17-000006:note_history:9]
Lumentum was incorporated in Delaware as a wholly owned subsidiary of JDS Uniphase Corporation ("JDSU") on February 10, 2015 and is comprised of the former communications and commercial optical products (“CCOP”) segment and WaveReady product lines of JDSU.
  (was, 2016-10-27, similarity 0.9755):
[0001628280-16-020392:note_history:9]
Lumentum was incorporated in Delaware as a wholly owned subsidiary of JDS Uniphase ("JDSU") on February 10, 2015 and is comprised of the former communications and commercial optical products (“CCOP”) segment and WaveReady product lines of JDSU.

- changed (2017-02-07):
[0001633978-17-000006:note_history:10]
On July 31, 2015, prior to the Separation (as described below), JDSU transferred substantially all of the assets and liabilities and operations of the CCOP segment and WaveReady product lines to Lumentum. Financial statements for periods prior to the Separation were prepared on a stand-alone basis and were derived from JDSU’s consolidated financial statements and accounting records. The Company prepared consolidated financial statements for the period from June 28, 2015 to August 1, 2015 where expenses were allocated to the Company using estimates that it considers to be a reasonable reflection of the utilization of services provided to, or benefits received by, the Company. Since August 1, 2015, the Company has prepared consolidated financial statements as an independent stand-alone basis pursuant to the rules and regulations of the the U.S. Securities and Exchange Commission (SEC) and are in conformity with generally accepted accounting principles in the United States (GAAP). In the opinion of management, these consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments, which are necessary for a fair statement of the consolidated financial statements for the periods shown. The results of operations for such periods are not necessarily indicative of the results expected for the full year or for any future periods.
  (was, 2016-10-27, similarity 0.6374):
[0001628280-16-020392:note_history:10]
On July 31, 2015, prior to the Separation (as described below), JDSU transferred substantially all of the assets and liabilities and operations of the CCOP segment and WaveReady product lines to Lumentum. Financial statements for periods prior to the Separation were prepared on a stand-alone basis and were derived from JDSU’s consolidated financial statements and accounting records. The Company prepared consolidated financial statements for the period from June 28, 2015 to August 1, 2015 where expenses were allocated to the Company using estimates that it considers to be a reasonable reflection of the utilization of services provided to, or benefits received by, the Company. Since August 1, 2015, the Company has prepared consolidated financial statements as an independent stand-alone basis pursuant to the rules and regulations of the SEC and are in conformity with U.S. GAAP. In the opinion of management, these consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments, which are necessary for a fair statement of the consolidated financial statements for the periods shown. The results of operations for such periods are not necessarily indicative of the results expected for the full year or for any future periods.

- added (2017-02-07):
[0001633978-17-000006:note_history:11]
As of December 31, 2016, Viavi held a total of 1.7 million shares of our common stock, which is under 5% of our total shares outstanding.

- changed (2017-02-07):
[0001633978-17-000006:note_history:12]
The preparation of the consolidated financial statements in accordance with GAAP in the United States requires management to make estimates and assumptions that affect the amounts reported in our consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, inventory valuation, allocation methods and allocated expenses from Viavi, valuation of goodwill and other intangible assets, stock-based compensation, retirement and post-retirement plan assumptions, restructuring, warranty, valuation of derivative liability, and accounting for income taxes.
  (was, 2016-10-27, similarity 0.9826):
[0001628280-16-020392:note_history:12]
The preparation of the consolidated financial statements in accordance with GAAP in the United States requires management to make estimates and assumptions that affect the amounts reported in our consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, inventory valuation, allocation methods and allocated expenses from Viavi, valuation of goodwill and other intangible assets, stock-based compensation, retirement and post-retirement plan assumptions, restructuring, warranty and accounting for income taxes.

- changed (2017-02-07):
[0001633978-17-000006:note_history:13]
See "Note 3. Related Party Transactions" in the Notes to Consolidated Financial Statements regarding the relationships we have with Viavi.
  (was, 2016-10-27, similarity 0.989):
[0001628280-16-020392:note_history:13]
See "Note 3. Related Party Transactions" in the Notes to Consolidated Financial Statements regarding the relationships we had with Viavi.

- changed (2017-02-07):
[0001633978-17-000006:note_history:14]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Our fiscal 2017 is a 52-week year ending on July 1, 2017, while fiscal 2016 was a 53-week year and ended on July 2, 2016.
  (was, 2016-10-27, similarity 0.9663):
[0001628280-16-020392:note_history:14]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Our fiscal 2017 is a 52-week year ending on July 1, 2017. Our fiscal 2016 was a 53-week year ended on July 2, 2016.

- changed (2017-02-07):
[0001633978-17-000006:note_history:15]
There have been no material changes in our significant accounting policies during the six months ended December 31, 2016 compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 2, 2016. The accompanying unaudited interim consolidated financial statements and accompanying related notes should be read in conjunction with the consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended July 2, 2016.
  (was, 2016-10-27, similarity 0.9558):
[0001628280-16-020392:note_history:15]
There have been no material changes in our significant accounting policies during the three months ended October 1, 2016 compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 2, 2016. The accompanying unaudited interim consolidated financial statements and accompanying related notes should be read in conjunction with the consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended July 2, 2016.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2017-02-07):
[0001633978-17-000006:note_history:16]
During the three and six months ended December 31, 2016, the Company recognized revenue of $0.9 million and $1.5 million, respectively, from products sold to Viavi. During the three and six months ended December 26, 2015, the Company recognized revenue of $0.7 million and $1.5 million, respectively, for products sold to Viavi.

- added (2017-02-07):
[0001633978-17-000006:note_history:17]
During the three months ended December 31, 2016, the Company did not record any research and development cost reimbursement from Viavi. During the six months ended December 31, 2016, the Company recorded $0.4 million in research and development cost reimbursement from Viavi. For the three and six months ended December 26, 2015, the Company recorded $0.7 million and $1.2 million, respectively, in research and development cost reimbursement.

- added (2017-02-07):
[0001633978-17-000006:note_history:18]
During the three and six months ended December 31, 2016, the Company recorded $0.2 million and $0.4 million, respectively, in sublease rental income. For the three and six months ended December 26, 2015, the Company recorded and $0.2 million and $0.3 million, respectively, in sublease rental income.

- added (2017-02-07):
[0001633978-17-000006:note_history:19]
As of December 31, 2016 and July 2, 2016, the Company had $0.4 million and $1.1 million, respectively, in trade accounts receivable due from Viavi.

- added (2017-02-07):
[0001633978-17-000006:note_history:20]
As of December 31, 2016 and July 2, 2016, the Company had $0.3 million in payables due to Viavi and $2.0 million in other receivables from Viavi, respectively.

- changed (2017-02-07):
[0001633978-17-000006:note_history:21]
There were no allocations of expenses from Viavi for the three and six months ended December 31, 2016, and the three months ended December 26, 2015. During the six months ended December 26, 2015, allocated costs from Viavi included in the accompanying consolidated statements of operations were as follows (in millions):
  (was, 2016-10-27, similarity 0.7742):
[0001628280-16-020392:note_history:21]
There were no allocations of expenses from Viavi for the three months ended October 1, 2016. During the three months ended September 26, 2015, allocated costs from Viavi included in the accompanying consolidated statements of operations  were as follows (in millions):

- added (2017-02-07):
[0001633978-17-000006:note_history:22]
|  | Six Months Ended |
|  | December 26, 2015 |
| Selling, general and administrative | 11.7 |  |
| Interest and other (income) expenses, net | (0.1 | ) |
| Interest expense | 0.1 |  |
| Total allocated costs | $ | 11.7 |  |

- removed (2017-02-07):
[0001628280-16-020392:note_history:23]
During the three months ended October 1, 2016 and September 26, 2015, the Company recognized revenue of $0.6 million and $0.8 million, respectively, from products sold to Viavi. During the three months ended October 1, 2016 and September 26, 2015, the Company recorded $0.4 million and $0.5 million, respectively, in research and development cost reimbursement and $0.2 million and $0.1 million, respectively, in sublease rental income. As of October 1, 2016 and July 2, 2016, the Company had $0.2 million and $1.1 million, respectively, in accounts receivable due from Viavi.

- removed (2017-02-07):
[0001628280-16-020392:note_history:24]
|  | Three Months Ended |
|  | September 26, 2015 |
| Research and development | $ | — |  |
| Selling, general and administrative | 11.7 |  |
| Restructuring and related charges | — |  |
| Interest and other (income) expenses, net | (0.1 | ) |
| Interest expense | 0.1 |  |
| Total allocated costs | $ | 11.7 |  |

- removed (2017-02-07):
[0001628280-16-020392:note_history:25]
Other Agreements

- removed (2017-02-07):
[0001628280-16-020392:note_history:26]
We share and operate under agreements executed by Viavi with third parties, including but not limited to purchasing, manufacturing, and freight agreements; use of facilities owned, leased, and managed by Viavi; and software, technology and other intellectual property agreements.


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2017-02-07):
[0001633978-17-000006:note_history:27]
During the six months ended December 26, 2015, allocated costs from Viavi included in the accompanying consolidated statements of operations were as follows (in millions):
  (was, 2016-10-27, similarity 0.961):
[0001628280-16-020392:note_history:27]
During the three months ended September 26, 2015, allocated costs from Viavi included in the accompanying consolidated statements of operations  were as follows (in millions):

- added (2017-02-07):
[0001633978-17-000006:note_history:28]
|  | Six Months Ended |
|  | December 26, 2015 |
| Selling, general and administrative | 11.7 |  |
| Interest and other (income) expenses, net | (0.1 | ) |
| Interest expense | 0.1 |  |
| Total allocated costs | $ | 11.7 |  |

- removed (2017-02-07):
[0001628280-16-020392:note_history:29]
|  | Three Months Ended |
|  | September 26, 2015 |
| Research and development | $ | — |  |
| Selling, general and administrative | 11.7 |  |
| Restructuring and related charges | — |  |
| Interest and other (income) expenses, net | (0.1 | ) |
| Interest expense | 0.1 |  |
| Total allocated costs | $ | 11.7 |  |
