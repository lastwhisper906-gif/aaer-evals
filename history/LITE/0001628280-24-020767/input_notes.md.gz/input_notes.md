# LITE notes — 0001628280-24-020767


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001628280-24-020767:notes:1]
[same as prior period, unchanged from 0001628280-24-003796:notes:1]

[0001628280-24-020767:notes:2]
[same as prior period, unchanged from 0001628280-24-003796:notes:2]

[0001628280-24-020767:notes:3]
Lumentum Holdings Inc. (“we,” “us,” “our,” “Lumentum” or the “Company”) is an industry-leading provider of optical and photonic products that address a range of end-market applications that include cloud data center and optical communications network infrastructure, consumer electronic devices, automobiles, and high-precision manufacturing.

[0001628280-24-020767:notes:4]
Our Cloud & Networking products include a comprehensive portfolio of optical and photonic components, modules, and subsystems supplied to network operator and network equipment manufacturer customers building cloud data center infrastructure, including that for artificial intelligence and machine learning (“AI/ML”) and data center interconnect (“DCI”) applications, and communications service provider networks, including in access (local), metro (intracity), long-haul (city-to-city and worldwide), and submarine (undersea) network infrastructure. Our Cloud & Networking products also support network equipment manufacturers building enterprise network infrastructure, including storage-area networks (“SANs”), local-area networks (“LANs”) and wide-area networks (“WANs”). Demand for our Cloud & Networking products is driven by the continual growth in network capacity required for cloud computing and services, including for AI/ML, streaming video and video conferencing, wireless and mobile devices, and internet of things (“IoT”).

[0001628280-24-020767:notes:5]
Our Industrial Tech products include solid-state lasers, kilowatt-class fiber lasers, diode lasers, and gas lasers, which address applications in numerous end-markets. In the consumer end-market, our laser light sources are integrated into our customers’ 3D sensing cameras, which are used in mobile devices, payment kiosks, and other consumer electronics devices to enable applications including biometric identification, computational photography and virtual and augmented reality. In the automotive end-market, our lasers are used in our customers’ LiDAR and other optical sensor devices, which are increasingly being used in advanced driver assistance systems (“ADAS”) and in-cabin driver and occupant monitoring systems. In the industrial manufacturing end-market, our lasers are incorporated into our customers’ manufacturing machine tools used for the precision processing of materials in a range of industries including semiconductor device and microelectronics fabrication, electric vehicle and battery production, metal cutting and welding, and advanced manufacturing. Our products can also be used in the industrial end-market in imaging and sensing systems for process feedback and control, quality assurance, and waste reduction. Adoption of our products in the industrial end-market is driven by the needs of customers to advance semiconductor and microelectronics industry roadmaps, and by Industry 4.0/5.0 trends, including increasing manufacturing precision and flexibility and reducing waste and environmental impact. Demand for our products in the industrial end-market is driven by end-customer investments in manufacturing capacity. Our lasers also address certain semiconductor inspection and life-science applications.

[0001628280-24-020767:notes:6]
[same as prior period, unchanged from 0001628280-24-003796:notes:6]

[0001628280-24-020767:notes:7]
[same as prior period, unchanged from 0001628280-24-003796:notes:7]

[0001628280-24-020767:notes:8]
[same as prior period, unchanged from 0001628280-24-003796:notes:8]

[0001628280-24-020767:notes:9]
[same as prior period, unchanged from 0001628280-24-003796:notes:9]

[0001628280-24-020767:notes:10]
We are continuously monitoring both the current developments in the ongoing war between Russia and Ukraine including the related additional export controls and resulting sanctions imposed on Russia and Belarus by the U.S. and other countries, and the Israel-Hamas war. Additional factors, such as increased inflation, escalating energy costs, constrained raw material availability and the related cost increases, could continue to impact the global economy and our business. Although the global implications of the wars are difficult to predict at this time, we do not presently foresee direct material adverse effects on our business.

[0001628280-24-020767:notes:11]
[same as prior period, unchanged from 0001628280-24-003796:notes:11]

[0001628280-24-020767:notes:12]
On November 7, 2023 (the “Closing date”), we completed the acquisition of Cloud Light Technology Limited (“Cloud Light”). Our condensed consolidated financial statements include the operating results of Cloud Light from the Closing date. On August 3, 2022, we completed the acquisition of NeoPhotonics Corporation (“NeoPhotonics”). On August 15, 2022, we completed the acquisition of IPG Photonics’ telecom transmission product lines. We have applied the acquisition method of accounting to account for these transactions in accordance with ASC Topic 805, Business Combinations. Refer to “Note 4. Business Combinations” for further discussions of these transactions.

[0001628280-24-020767:notes:13]
[same as prior period, unchanged from 0001628280-24-003796:notes:13]

[0001628280-24-020767:notes:14]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2024 is a 52-week year ending on June 29, 2024, with the quarter ended March 30, 2024 being a 13-week quarterly period. Our fiscal 2023 was a 52-week year that ended on July 1, 2023, with the quarter ended April 1, 2023 being a 13-week quarterly period.

[0001628280-24-020767:notes:15]
[same as prior period, unchanged from 0001628280-24-003796:notes:15]

[0001628280-24-020767:notes:16]
[same as prior period, unchanged from 0001628280-24-003796:notes:16]

[0001628280-24-020767:notes:17]
Accounting Policies
The condensed consolidated financial statements and accompanying notes should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the fiscal year ended July 1, 2023. There were no significant changes to our accounting policies during the nine months ended March 30, 2024


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001628280-24-020767:notes:18]
Note 2. Recently Issued Accounting Pronouncements

[0001628280-24-020767:notes:19]
In March 2024, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2024-02: Codification Improvements - Amendments to Remove References to the Concepts Statements, which contains amendments to the Codification that remove references to various FASB Concepts Statements.  ASU 2024-02 is effective for fiscal years beginning after December 15, 2024, with early adoption permitted. We do not expect this ASU to have a material impact on our consolidated financial statements and disclosures.

[0001628280-24-020767:notes:20]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which requires disaggregated information about a reporting entity’s effective tax rate reconciliation as well as information on income tax paid. ASU 2023-09 is effective for fiscal years beginning after December 15, 2024, with early adoption permitted. We are currently evaluating the impact of this ASU on our income tax disclosures within the consolidated financial statements.

[0001628280-24-020767:notes:21]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which updates reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses. ASU 2023-07 does not change how a public entity identifies its operating segments, aggregates those operating segments, or applies quantitative thresholds to determine its reportable segments. The update is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. The amendments should be applied retrospectively to all prior periods presented in the financial statements. We plan to adopt ASU 2023-07 in the fiscal first quarter of 2025. We are currently evaluating the impact of adopting this ASU on our consolidated financial statements and disclosures.


## us-gaap:EarningsPerShareTextBlock

[0001628280-24-020767:notes:22]
[same as prior period, unchanged from 0001628280-24-003796:notes:22]

[0001628280-24-020767:notes:23]
[same as prior period, unchanged from 0001628280-24-003796:notes:23]

[0001628280-24-020767:notes:24]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |  | March 30, 2024 |  | April 1, 2023 |
| Numerator: |  |  |  |  |  |  |  |
| Net loss - basic and diluted | $ | (127.0) |  |  | $ | (39.3) |  |  | $ | (294.0) |  |  | $ | (71.4) |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average common shares outstanding - basic and diluted | 67.5 |  |  | 68.6 |  |  | 67.1 |  |  | 68.3 |  |
| Net loss per share: |  |  |  |  |  |  |  |
| Basic | $ | (1.88) |  |  | $ | (0.57) |  |  | $ | (4.38) |  |  | $ | (1.05) |  |
| Diluted | $ | (1.88) |  |  | $ | (0.57) |  |  | $ | (4.38) |  |  | $ | (1.05) |  |

[0001628280-24-020767:notes:25]
Shares from stock-based benefit plans and shares issuable assuming conversion of our convertible notes are anti-dilutive for the three and nine months ended March 30, 2024 and April 1, 2023, respectively, and are therefore excluded from the calculation of diluted net loss per share as the Company had a net loss for both periods.

[0001628280-24-020767:notes:26]
Anti-dilutive shares excluded from the calculation of diluted net loss per share for the three months ended March 30, 2024 include 30.3 million shares related to convertible notes, 3.9 million shares issuable under restricted stock units (“RSUs”) and performance stock units (“PSUs”), 0.2 million shares issuable under the Employee Stock Purchase Plan (the “2015 Purchase Plan”), and 1.1 million shares outstanding related to stock options. Average anti-dilutive shares excluded from the calculation of diluted net loss per share for the nine months ended March 30, 2024 include 30.9 million shares related to convertible notes, 4.3 million shares issuable under RSUs and PSUs, 0.2 million shares issuable under the 2015 Purchase Plan, and 1.1 million shares outstanding related to stock options. Refer to “Note 13. Equity.”

[0001628280-24-020767:notes:27]
Anti-dilutive shares excluded from the calculation of diluted net loss per share for the three months ended April 1, 2023 include 24.5 million shares related to convertible notes, 3.5 million shares issuable under RSUs and PSUs, and 0.1 million shares issuable under the 2015 Purchase Plan. Average anti-dilutive shares excluded from the calculation of diluted net loss per share for the nine months ended April 1, 2023 include 24.5 million shares related to convertible notes, 3.8 million shares issuable under RSUs and PSUs, and 0.1 million shares issuable under the 2015 Purchase Plan. 
Potentially dilutive common shares issuable upon conversion of our outstanding convertible notes are determined using the if-converted method.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001628280-24-020767:notes:28]
[same as prior period, unchanged from 0001628280-24-003796:notes:28]

[0001628280-24-020767:notes:29]
[same as prior period, unchanged from 0001628280-24-003796:notes:29]

[0001628280-24-020767:notes:30]
On October 29, 2023, we entered into a definitive merger agreement (the “Merger Agreement”) with Cloud Light. On November 7, 2023, we completed the acquisition of Cloud Light. Cloud Light designs, markets, and manufactures advanced optical modules for data center interconnect applications. The acquisition enables us to be well-positioned to serve the growing needs of cloud & networking customers, particularly those customers focused on optimizing their data center infrastructure for the demands of AI/ML.

[0001628280-24-020767:notes:31]
[same as prior period, unchanged from 0001628280-24-003796:notes:31]

[0001628280-24-020767:notes:32]
[same as prior period, unchanged from 0001628280-24-003796:notes:32]

[0001628280-24-020767:notes:33]
[same as prior period, unchanged from 0001628280-24-003796:notes:33]

[0001628280-24-020767:notes:34]
[same as prior period, unchanged from 0001628280-24-003796:notes:34]

[0001628280-24-020767:notes:35]
[same as prior period, unchanged from 0001628280-24-003796:notes:35]

[0001628280-24-020767:notes:36]
We also incurred a total of $9.4 million of merger-related costs, representing professional and other direct acquisition costs, of which $0.2 million and $9.4 million was incurred during the three and nine months ended March 30, 2024 during the fiscal second quarter of 2024, respectively. Merger related costs are recorded as selling, general and administrative expense in the consolidated statement of operations when incurred.

[0001628280-24-020767:notes:37]
[same as prior period, unchanged from 0001628280-24-003796:notes:37]

[0001628280-24-020767:notes:38]
|  | Fair Value |
| Total purchase price consideration | $ | 728.5 |  |
| Assets acquired |  |
| Cash and cash equivalents | 4.1 |  |
| Short-term investments | 1.0 |  |
| Accounts receivable, net | 20.9 |  |
| Inventories | 71.2 |  |
| Prepayments and other current assets | 14.3 |  |
| Property, plant and equipment, net | 63.2 |  |
| Operating lease right-of-use assets, net | 3.7 |  |
| Other intangible assets, net (1) | 333.0 |  |
| Other non-current assets | 0.3 |  |
| Total assets | 511.7 |  |
| Liabilities assumed |  |
| Accounts payable | 45.8 |  |
| Accrued payroll and related expenses | 5.9 |  |
| Accrued expenses | 10.4 |  |
| Operating lease liabilities, current | 1.8 |  |
| Other current liabilities | 10.9 |  |
| Operating lease liabilities, non-current | 1.9 |  |
| Deferred tax liability | 58.2 |  |
| Other non-current liabilities | 9.1 |  |
| Total liabilities | 144.0 |  |
| Goodwill | $ | 360.8 |  |

[0001628280-24-020767:notes:39]
[same as prior period, unchanged from 0001628280-24-003796:notes:39]

[0001628280-24-020767:notes:40]
[same as prior period, unchanged from 0001628280-24-003796:notes:40]

[0001628280-24-020767:notes:41]
Goodwill from the Cloud Light acquisition has been assigned to the Cloud & Networking segment. The preliminary goodwill of $360.8 million arising from the acquisition is attributed to the expected revenue growth and synergies, including future cost efficiencies and other benefits that are expected to be generated by combining Lumentum and Cloud Light. None of the goodwill is expected to be deductible for local tax purposes. Refer to “Note 8. Goodwill and Other Intangible Assets.”

[0001628280-24-020767:notes:42]
Cloud Light contributed $84.6 million and $144.1 million of our consolidated net revenue for the three and nine months ended March 30, 2024, respectively. Due to the continued integration of the combined businesses, as well as our corporate structure and the allocation of selling, general and administrative costs, it is impracticable to determine Cloud Light’s contribution to our earnings.

[0001628280-24-020767:notes:43]
[same as prior period, unchanged from 0001628280-24-003796:notes:43]

[0001628280-24-020767:notes:44]
The following supplemental pro forma information presents the combined results of operations for the three and nine months ended March 30, 2024 and April 1, 2023, as if the acquisition was completed on July 3, 2022, the first day of the fiscal year 2023. The supplemental pro forma financial information presented below is not necessarily indicative of the financial position or results of operations that would have been realized if the acquisition had been completed on the date indicated. The supplemental pro forma financial information does not reflect synergies that might have been achieved, nor is it indicative of future operating results or financial position.

[0001628280-24-020767:notes:45]
[same as prior period, unchanged from 0001628280-24-003796:notes:45]

[0001628280-24-020767:notes:46]
[same as prior period, unchanged from 0001628280-24-003796:notes:46]

[0001628280-24-020767:notes:47]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |  | March 30, 2024 |  | April 1, 2023 |
| Net revenue | $ | 366.5 |  |  | $ | 422.5 |  |  | $ | 1,139.6 |  |  | $ | 1,535.9 |  |
| Net loss | $ | (122.8) |  |  | $ | (51.2) |  |  | $ | (282.7) |  |  | $ | (112.9) |  |

[0001628280-24-020767:notes:48]
[same as prior period, unchanged from 0001628280-24-003796:notes:48]

[0001628280-24-020767:notes:49]
On August 3, 2022, we completed the acquisition of NeoPhotonics through the consummation of the merger and, accordingly, we acquired all of the issued and outstanding common stock of NeoPhotonics with a total purchase price consideration of $934.4 million, which was funded by the cash balances of the combined company. The addition of NeoPhotonics expands our opportunity in some of the fastest growing markets for optical components used in cloud and telecom network infrastructure.

[0001628280-24-020767:notes:50]
We have applied the acquisition method of accounting in accordance with ASC Topic 805, Business Combinations to account for this transaction and recorded a goodwill of $315.3 million arising from the acquisition, which has been assigned to the Cloud & Networking segment. NeoPhotonics contributed $104.6 million and $177.4 million of our consolidated net revenue for the three and nine months ended April 1, 2023, respectively. Due to the integration of the combined businesses, as well as our corporate structure and the allocation of selling, general and administrative costs, it is impracticable to determine NeoPhotonics’ contribution to our earnings. As of March 30, 2024, the operation of NeoPhotonics has been fully integrated to the combined business.

[0001628280-24-020767:notes:51]
[same as prior period, unchanged from 0001628280-24-003796:notes:51]

[0001628280-24-020767:notes:52]
The following supplemental pro forma information presents the combined results of operations for the three and nine months ended December 31, 2022, as if the acquisition was completed at the first day of fiscal 2022. The supplemental pro forma financial information is not necessarily indicative of the financial position or results of operations that would have been realized if the acquisition had been completed on the date indicated. The supplemental pro forma financial information does not reflect synergies that might have been achieved, nor is it indicative of future operating results or financial position. The pro forma financial information includes adjustments for: (i) amortization expense that would have been recognized related to the acquired intangible assets, (ii) depreciation expense that would have been recognized related to the acquired property, plant, and equipment, (iii) amortization of inventory fair value adjustment, (iv) acquisition related costs, such as third party transaction costs and restructuring costs, (v) stock-based compensation expense and (vi) the estimated income tax effect on the pro forma adjustments.

[0001628280-24-020767:notes:53]
|  | April 1, 2023 |
|  | Three Months Ended |  | Nine Months Ended |
| Net revenue | $ | 383.4 |  |  |  |  | $ | 1,420.1 |  |
| Net loss | (35.9) |  |  |  |  | (29.3) |  |

[0001628280-24-020767:notes:54]
[same as prior period, unchanged from 0001628280-24-003796:notes:54]

[0001628280-24-020767:notes:55]
[same as prior period, unchanged from 0001628280-24-003796:notes:55]

[0001628280-24-020767:notes:56]
[same as prior period, unchanged from 0001628280-24-003796:notes:56]

[0001628280-24-020767:notes:57]
[same as prior period, unchanged from 0001628280-24-003796:notes:57]


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001628280-24-020767:notes:58]
[same as prior period, unchanged from 0001628280-24-003796:notes:58]

[0001628280-24-020767:notes:59]
[same as prior period, unchanged from 0001628280-24-003796:notes:59]

[0001628280-24-020767:notes:60]
|  | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| March 30, 2024: |  |  |  |  |  |  |  |
| Cash | $ | 287.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 287.2 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 7.2 |  |  | — |  |  | — |  |  | 7.2 |  |
| Money market funds | 130.6 |  |  | — |  |  | — |  |  | 130.6 |  |
| Total cash and cash equivalents | $ | 425.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 425.0 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 1.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 1.8 |  |
| Commercial paper | 8.2 |  |  | — |  |  | — |  |  | 8.2 |  |
| Corporate debt securities | 222.4 |  |  | 0.1 |  |  | (0.8) |  |  | 221.7 |  |
| U.S. Agency securities | 95.0 |  |  | — |  |  | (0.4) |  |  | 94.6 |  |
| U.S. Treasury securities | 120.3 |  |  | — |  |  | (0.7) |  |  | 119.6 |  |
| Total short-term investments | $ | 447.7 |  |  | $ | 0.1 |  |  | $ | (1.9) |  |  | $ | 445.9 |  |
| July 1, 2023: |  |  |  |  |  |  |  |
| Cash | $ | 254.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 254.3 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | 276.1 |  |  | — |  |  | — |  |  | 276.1 |  |
| U.S. Agency securities | 4.0 |  |  | — |  |  | — |  |  | 4.0 |  |
| U.S. Treasury securities | 324.6 |  |  | — |  |  | — |  |  | 324.6 |  |
| Total cash and cash equivalents | $ | 859.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 859.0 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 16.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 16.5 |  |
| Commercial paper | 132.9 |  |  | — |  |  | (0.2) |  |  | 132.7 |  |
| Corporate debt securities | 472.7 |  |  | — |  |  | (3.9) |  |  | 468.8 |  |
| U.S. Agency securities | 207.9 |  |  | — |  |  | (1.7) |  |  | 206.2 |  |
| U.S. Treasury securities | 332.4 |  |  | — |  |  | (2.0) |  |  | 330.4 |  |
| Total short-term investments | $ | 1,162.4 |  |  | $ | — |  |  | $ | (7.8) |  |  | $ | 1,154.6 |  |

[0001628280-24-020767:notes:61]
[same as prior period, unchanged from 0001628280-24-003796:notes:61]

[0001628280-24-020767:notes:62]
We use the specific-identification method to determine any realized gains or losses from the sale of our short-term investments classified as available-for-sale. During the three and nine months ended March 30, 2024 and April 1, 2023, we did not realize significant gains or losses on a gross level from the sale of our short-term investments classified as available-for-sale.

[0001628280-24-020767:notes:63]
During the three and nine months ended March 30, 2024, our other income, net was $16.2 million and $50.8 million, respectively, which includes interest and investment income on cash equivalents and short-term investments of $12.6 million and $51.4 million, respectively. During the three and nine months ended April 1, 2023, our other income, net was $11.4 million and $28.9 million, respectively, which includes interest and investment income on cash equivalents and short-term investments of $11.9 million and $24.4 million, respectively.

[0001628280-24-020767:notes:64]
As of March 30, 2024 and July 1, 2023, we recorded interest receivables of $5.0 million and $6.7 million, respectively, in prepayments and other current assets within the condensed consolidated balance sheets. We did not recognize an allowance for credit losses against interest receivables in any of the periods presented, as there were no such losses.

[0001628280-24-020767:notes:65]
[same as prior period, unchanged from 0001628280-24-003796:notes:66]

[0001628280-24-020767:notes:66]
|  | Continuous Loss Position for More Than 12 Months |  | Continuous Loss Position for Less Than 12 Months |  | Gross Unrealized Losses |  |  |  |  |  |  |  |  |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |  |
| March 30, 2024: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 3.5 |  |  | $ | — |  |  | $ | 89.2 |  |  | $ | (0.4) |  |  | $ | (0.4) |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 13.1 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 21.6 |  |  | (0.1) |  |  | 175.7 |  |  | (0.7) |  |  | (0.8) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 2.0 |  |  | — |  |  | 117.6 |  |  | (0.7) |  |  | (0.7) |  |  |  |  |  |  |  |  |  |
| Total | $ | 27.1 |  |  | $ | (0.1) |  |  | $ | 395.6 |  |  | $ | (1.8) |  |  | $ | (1.9) |  |  |  |  |  |  |  |  |  |
| July 1, 2023: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 39.6 |  |  | $ | (0.4) |  |  | $ | 170.6 |  |  | $ | (1.3) |  |  | $ | (1.7) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | — |  |  | 7.7 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 128.5 |  |  | (0.2) |  |  | (0.2) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 93.6 |  |  | (1.2) |  |  | 358.9 |  |  | (2.7) |  |  | (3.9) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 50.8 |  |  | (0.6) |  |  | 221.4 |  |  | (1.4) |  |  | (2.0) |  |  |  |  |  |  |  |  |  |
| Total | $ | 184.0 |  |  | $ | (2.2) |  |  | $ | 887.1 |  |  | $ | (5.6) |  |  | $ | (7.8) |  |  |  |  |  |  |  |  |  |

[0001628280-24-020767:notes:67]
[same as prior period, unchanged from 0001628280-24-003796:notes:68]

[0001628280-24-020767:notes:68]
|  | March 30, 2024 |  | July 1, 2023 |
|  | Amortized Cost |  | Fair Value |  | Amortized Cost |  | Fair Value |
| Due within 1 year | $ | 394.6 |  |  | $ | 393.0 |  |  | $ | 762.9 |  |  | $ | 759.1 |  |
| Due in 1 year to 5 years | 53.1 |  |  | 52.9 |  |  | 399.5 |  |  | 395.5 |  |
| Total | $ | 447.7 |  |  | $ | 445.9 |  |  | $ | 1,162.4 |  |  | $ | 1,154.6 |  |

[0001628280-24-020767:notes:69]
[same as prior period, unchanged from 0001628280-24-003796:notes:70]


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-24-020767:notes:70]
[same as prior period, unchanged from 0001628280-24-003796:notes:71]

[0001628280-24-020767:notes:71]
[same as prior period, unchanged from 0001628280-24-003796:notes:72]

[0001628280-24-020767:notes:72]
[same as prior period, unchanged from 0001628280-24-003796:notes:73]

[0001628280-24-020767:notes:73]
[same as prior period, unchanged from 0001628280-24-003796:notes:74]

[0001628280-24-020767:notes:74]
[same as prior period, unchanged from 0001628280-24-003796:notes:75]

[0001628280-24-020767:notes:75]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| March 30, 2024: (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | — |  |  | $ | 7.2 |  |  | $ | — |  |  | $ | 7.2 |  |
| Money market funds | 130.6 |  |  | — |  |  | — |  |  | 130.6 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 1.8 |  |  | — |  |  | 1.8 |  |
| Commercial paper | — |  |  | 8.2 |  |  | — |  |  | 8.2 |  |
| Corporate debt securities | — |  |  | 221.7 |  |  | — |  |  | 221.7 |  |
| U.S. Agency securities | — |  |  | 94.6 |  |  | — |  |  | 94.6 |  |
| U.S. Treasury securities | 119.6 |  |  | — |  |  | — |  |  | 119.6 |  |
| Total assets | $ | 250.2 |  |  | $ | 333.5 |  |  | $ | — |  |  | $ | 583.7 |  |

[0001628280-24-020767:notes:76]
(1)  Excludes $287.2 million in cash held in our bank accounts as of March 30, 2024.

[0001628280-24-020767:notes:77]
[same as prior period, unchanged from 0001628280-24-003796:notes:78]

[0001628280-24-020767:notes:78]
[same as prior period, unchanged from 0001628280-24-003796:notes:79]

[0001628280-24-020767:notes:79]
[same as prior period, unchanged from 0001628280-24-003796:notes:80]

[0001628280-24-020767:notes:80]
[same as prior period, unchanged from 0001628280-24-003796:notes:81]

[0001628280-24-020767:notes:81]
[same as prior period, unchanged from 0001628280-24-003796:notes:82]

[0001628280-24-020767:notes:82]
|  | March 30, 2024 |  | July 1, 2023 |
|  | Carrying Amount |  | Estimated Fair Value |  | Carrying Amount |  | Estimated Fair Value |
| 2029 Notes | $ | 599.1 |  |  | $ | 570.1 |  |  | $ | 598.6 |  |  | $ | 625.2 |  |
| 2028 Notes | 856.5 |  |  | 668.0 |  |  | 855.5 |  |  | 677.8 |  |
| 2026 Notes | 1,046.8 |  |  | 925.7 |  |  | 1,045.9 |  |  | 933.2 |  |
| 2024 Notes | — |  |  | — |  |  | 311.6 |  |  | 345.2 |  |
|  | $ | 2,502.4 |  |  | $ | 2,163.8 |  |  | $ | 2,811.6 |  |  | $ | 2,581.4 |  |

[0001628280-24-020767:notes:83]
[same as prior period, unchanged from 0001628280-24-003796:notes:84]

[0001628280-24-020767:notes:84]
[same as prior period, unchanged from 0001628280-24-003796:notes:85]

[0001628280-24-020767:notes:85]
Management utilizes various valuation methods, including an income approach, a market approach and a cost approach, to estimate the fair value of intangibles and other long-lived assets. During the annual impairment testing performed in the fourth quarter of fiscal 2023, we concluded that there was no impairment of our intangible and other long-lived assets. We review our intangible and other long-lived assets for impairment at least annually in the fourth quarter of each fiscal year, absent any interim indicators of impairment. There were no indicators of impairment during the three and nine months ended March 30, 2024.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-24-020767:notes:86]
[same as prior period, unchanged from 0001628280-24-003796:notes:87]

[0001628280-24-020767:notes:87]
[same as prior period, unchanged from 0001628280-24-003796:notes:88]

[0001628280-24-020767:notes:88]
We did not have any allowance for credit losses other than our allowance for uncollectible accounts receivable. As of March 30, 2024 and July 1, 2023, the allowance for credit losses on our trade receivables was $0.2 million and less than $0.1 million, respectively.

[0001628280-24-020767:notes:89]
[same as prior period, unchanged from 0001628280-24-003796:notes:90]

[0001628280-24-020767:notes:90]
[same as prior period, unchanged from 0001628280-24-003796:notes:91]

[0001628280-24-020767:notes:91]
|  | March 30, 2024 |  | July 1, 2023 |
| Raw materials and purchased parts | $ | 202.8 |  |  | $ | 170.5 |  |
| Work in process | 114.1 |  |  | 103.2 |  |
| Finished goods | 103.8 |  |  | 134.9 |  |
| Inventories | $ | 420.7 |  |  | $ | 408.6 |  |

[0001628280-24-020767:notes:92]
In connection with the Cloud Light Acquisition, we recorded $71.2 million of inventory as of the acquisition Closing date. During the three and nine months ended March 30, 2024, we recorded an amortization of fair value step-up of $4.9 million and $8.0 million, respectively. As of March 30, 2024, the entire $8.0 million of fair value step-up of inventory acquired from Cloud Light was amortized and recognized as cost of sales in our condensed consolidated statements of operations.

[0001628280-24-020767:notes:93]
[same as prior period, unchanged from 0001628280-24-003796:notes:94]

[0001628280-24-020767:notes:94]
[same as prior period, unchanged from 0001628280-24-003796:notes:95]

[0001628280-24-020767:notes:95]
|  | March 30, 2024 |  | July 1, 2023 |
| Land | $ | 75.2 |  |  | $ | 63.5 |  |
| Buildings and improvements | 211.8 |  |  | 170.3 |  |
| Machinery and equipment | 748.6 |  |  | 657.9 |  |
| Computer equipment and software | 44.3 |  |  | 41.4 |  |
| Furniture and fixtures | 12.5 |  |  | 10.2 |  |
| Leasehold improvements | 45.2 |  |  | 49.6 |  |
| Construction in progress | 82.0 |  |  | 69.2 |  |
|  | 1,219.6 |  |  | 1,062.1 |  |
| Less: Accumulated depreciation | (640.9) |  |  | (572.6) |  |
| Property, plant and equipment, net | $ | 578.7 |  |  | $ | 489.5 |  |

[0001628280-24-020767:notes:96]
In connection with the Cloud Light acquisition, we assumed $63.2 million of property, plant and equipment, net, as of the acquisition Closing date.

[0001628280-24-020767:notes:97]
[same as prior period, unchanged from 0001628280-24-003796:notes:98]

[0001628280-24-020767:notes:98]
[same as prior period, unchanged from 0001628280-24-003796:notes:99]

[0001628280-24-020767:notes:99]
During the three and nine months ended March 30, 2024, we recorded depreciation expense of $27.0 million and $82.4 million, respectively. During the three and nine months ended April 1, 2023, we recorded depreciation expense of $27.7 million and $78.6 million, respectively.

[0001628280-24-020767:notes:100]
[same as prior period, unchanged from 0001628280-24-003796:notes:101]

[0001628280-24-020767:notes:101]
[same as prior period, unchanged from 0001628280-24-003796:notes:102]

[0001628280-24-020767:notes:102]
|  | March 30, 2024 |  | July 1, 2023 |
| Operating lease right-of-use assets | $ | 112.3 |  |  | $ | 116.5 |  |
| Less: accumulated amortization | (35.6) |  |  | (39.2) |  |
| Operating lease right-of-use assets, net | $ | 76.7 |  |  | $ | 77.3 |  |

[0001628280-24-020767:notes:103]
[same as prior period, unchanged from 0001628280-24-003796:notes:104]

[0001628280-24-020767:notes:104]
[same as prior period, unchanged from 0001628280-24-003796:notes:105]

[0001628280-24-020767:notes:105]
[same as prior period, unchanged from 0001628280-24-003796:notes:106]

[0001628280-24-020767:notes:106]
[same as prior period, unchanged from 0001628280-24-003796:notes:107]

[0001628280-24-020767:notes:107]
|  | March 30, 2024 |  | July 1, 2023 |
| Restructuring accrual and related charges (1) | $ | 17.7 |  |  | $ | 5.0 |  |
| Warranty accrual (2) | 13.5 |  |  | 6.8 |  |
| Deferred revenue and customer deposits | 0.8 |  |  | 2.1 |  |
| Income tax payable (3) | 32.4 |  |  | 28.0 |  |
| Other current liabilities | 3.9 |  |  | 5.9 |  |
| Other current liabilities | $ | 68.3 |  |  | $ | 47.8 |  |

[0001628280-24-020767:notes:108]
[same as prior period, unchanged from 0001628280-24-003796:notes:109]

[0001628280-24-020767:notes:109]
(2) Refer to “Note 14. Commitments and Contingencies.”

[0001628280-24-020767:notes:110]
[same as prior period, unchanged from 0001628280-24-003796:notes:111]

[0001628280-24-020767:notes:111]
[same as prior period, unchanged from 0001628280-24-003796:notes:112]

[0001628280-24-020767:notes:112]
[same as prior period, unchanged from 0001628280-24-003796:notes:113]

[0001628280-24-020767:notes:113]
|  | March 30, 2024 |  | July 1, 2023 |
| Asset retirement obligations | $ | 7.5 |  |  | $ | 8.2 |  |
| Pension and related accruals (1) | 9.6 |  |  | 9.6 |  |
| Unrecognized tax benefit | 73.9 |  |  | 64.4 |  |
| Other non-current liabilities | 7.8 |  |  | 9.2 |  |
| Other non-current liabilities | $ | 98.8 |  |  | $ | 91.4 |  |

[0001628280-24-020767:notes:114]
(1) We have defined benefit pension plans in Japan, Switzerland, and Thailand. Pension and related accrual of $9.6 million as of March 30, 2024 represents $10.6 million of non-current portion of benefit obligation, offset by $1.0 million of funding for the pension plan in Switzerland. Pension and related accrual of $9.6 million as of July 1, 2023 relates to $10.2 million of non-current portion of benefit obligation, offset by $0.6 million of funding for the pension plan in Switzerland. We typically re-evaluate the assumptions related to the fair value of our defined benefit obligations annually in the fiscal fourth quarter and make any updates as necessary.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001628280-24-020767:notes:115]
[same as prior period, unchanged from 0001628280-24-003796:notes:116]

[0001628280-24-020767:notes:116]
[same as prior period, unchanged from 0001628280-24-003796:notes:117]

[0001628280-24-020767:notes:117]
In November 2023, we completed the acquisition of Cloud Light. We recognized preliminary goodwill of $360.8 million, which was allocated to the Cloud & Networking segment.

[0001628280-24-020767:notes:118]
The following table presents goodwill by reportable segments as of March 30, 2024 and July 1, 2023 (in millions):

[0001628280-24-020767:notes:119]
|  | Cloud & Networking |  | Industrial Tech |  | Total |
| Balances as of July 1, 2023 | $ | 683.9 |  |  | $ | 11.2 |  |  | $ | 695.1 |  |
| Acquisition of Cloud Light (1) | 360.8 |  |  | — |  |  | 360.8 |  |
| Balances as of March 30, 2024 | $ | 1,044.7 |  |  | $ | 11.2 |  |  | $ | 1,055.9 |  |

[0001628280-24-020767:notes:120]
(1) We recorded $359.5 million of goodwill as of the acquisition date and $1.3 million of measurement period adjustments to increase goodwill during the third quarter of fiscal 2024.

[0001628280-24-020767:notes:121]
[same as prior period, unchanged from 0001628280-24-003796:notes:121]

[0001628280-24-020767:notes:122]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. In the fourth quarter of fiscal 2023, we completed the annual impairment test of goodwill, which indicated there was no goodwill impairment. There were no indicators of goodwill impairment during the three and nine months ended March 30, 2024.

[0001628280-24-020767:notes:123]
[same as prior period, unchanged from 0001628280-24-003796:notes:123]

[0001628280-24-020767:notes:124]
[same as prior period, unchanged from 0001628280-24-003796:notes:124]

[0001628280-24-020767:notes:125]
[same as prior period, unchanged from 0001628280-24-003796:notes:125]

[0001628280-24-020767:notes:126]
During the annual impairment testing performed in the fourth quarter of fiscal 2023, we concluded that our intangible and other long-lived assets were not impaired at the asset group level. We review our intangible and other long-lived assets for impairment at least annually in the fourth quarter of each fiscal year, absent any interim indicators of impairment. There were no indicators of impairment at the asset group level during the three and nine months ended March 30, 2024.

[0001628280-24-020767:notes:127]
[same as prior period, unchanged from 0001628280-24-003796:notes:127]

[0001628280-24-020767:notes:128]
[same as prior period, unchanged from 0001628280-24-003796:notes:128]

[0001628280-24-020767:notes:129]
[same as prior period, unchanged from 0001628280-24-003796:notes:129]

[0001628280-24-020767:notes:130]
[same as prior period, unchanged from 0001628280-24-003796:notes:130]

[0001628280-24-020767:notes:131]
[same as prior period, unchanged from 0001628280-24-003796:notes:131]

[0001628280-24-020767:notes:132]
[same as prior period, unchanged from 0001628280-24-003796:notes:132]

[0001628280-24-020767:notes:133]
| March 30, 2024 | Gross Carrying Amounts |  | Accumulated Amortization |  | Net Carrying Amounts |  | Weighted Average Remaining Amortization Period (Years) |
| Acquired developed technologies | $ | 807.8 |  |  | $ | (450.1) |  |  | $ | 357.7 |  |  | 5.0 |
| Customer relationships | 419.8 |  |  | (154.5) |  |  | 265.3 |  |  | 5.2 |
| In-process research and development | 54.9 |  |  | — |  |  | 54.9 |  |  | n/a |
| Order backlog | 14.0 |  |  | (5.4) |  |  | 8.6 |  |  | 0.6 |
| Trade name and trademarks | 3.0 |  |  | (1.0) |  |  | 2.0 |  |  | 0.8 |
| Total intangible assets | $ | 1,299.5 |  |  | $ | (611.0) |  |  | $ | 688.5 |  |  |  |

[0001628280-24-020767:notes:134]
[same as prior period, unchanged from 0001628280-24-003796:notes:134]

[0001628280-24-020767:notes:135]
[same as prior period, unchanged from 0001628280-24-003796:notes:135]

[0001628280-24-020767:notes:136]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |  | March 30, 2024 |  | April 1, 2023 |
| Cost of sales | $ | 22.3 |  |  | $ | 18.7 |  |  | $ | 61.8 |  |  | $ | 66.4 |  |
| Research and development | 0.4 |  |  | — |  |  | 1.1 |  |  | — |  |
| Selling, general and administrative | 19.4 |  |  | 11.3 |  |  | 45.8 |  |  | 31.9 |  |
| Total amortization of intangibles | $ | 42.1 |  |  | $ | 30.0 |  |  | $ | 108.7 |  |  | $ | 98.3 |  |

[0001628280-24-020767:notes:137]
Based on the carrying amount of our acquired intangible assets except in-process research and development as of March 30, 2024, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001628280-24-020767:notes:138]
| Fiscal Years |  |
| Remainder of 2024 | $ | 41.7 |  |
| 2025 | 147.5 |  |
| 2026 | 131.5 |  |
| 2027 | 118.7 |  |
| 2028 | 80.5 |  |
| Thereafter | 113.7 |  |
| Total future amortization | $ | 633.6 |  |


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0001628280-24-020767:notes:139]
[same as prior period, unchanged from 0001628280-24-003796:notes:139]

[0001628280-24-020767:notes:140]
[same as prior period, unchanged from 0001628280-24-003796:notes:140]


## us-gaap:DebtDisclosureTextBlock

[0001628280-24-020767:notes:141]
Note 9. Debt

[0001628280-24-020767:notes:142]
Convertible Notes

[0001628280-24-020767:notes:143]
2029 Notes

[0001628280-24-020767:notes:144]
On June 16, 2023, we issued $603.7 million in aggregate principal amount of 1.50% Convertible Senior Notes due in 2029 (“2029 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended. The 2029 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association, (as successor in interest to U.S. Bank National Association), as a trustee (the “2029 Indenture”). The 2029 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-24-020767:notes:145]
The net proceeds from the sale of the 2029 Notes was $599.4 million, after deducting $4.3 million of net issuance costs. In addition, we incurred $0.8 million of professional fees directly related to this transaction. Concurrent with the issuance of the 2029 Notes, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 2024 Notes and $125.0 million of the net proceeds to repurchase our common stock in privately negotiated transactions. We intend to use the remaining net proceeds for general corporate purposes, which may include the repayment of our indebtedness, including any of our existing convertible notes, capital expenditures, working capital and potential acquisitions.

[0001628280-24-020767:notes:146]
The 2029 Notes bear interest at a rate of 1.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year. The 2029 Notes will mature on December 15, 2029, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-24-020767:notes:147]
The initial conversion rate is 14.3808 shares of common stock per $1,000 principal amount of the 2029 Notes (which is equivalent to an initial conversion price of approximately $69.54 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2029 Indenture but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2029 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-24-020767:notes:148]
Prior to the close of business on the business day immediately preceding September 15, 2029, holders of the 2029 Notes may convert their 2029 Notes only under the following circumstances:

[0001628280-24-020767:notes:149]
•during any fiscal quarter commencing after September 30, 2023 (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% if the applicable conversion price on each applicable trading day;

[0001628280-24-020767:notes:150]
•during the five consecutive business day period after any five consecutive trading day period (the “2029 measurement period”) in which the trading price per $1,000 principal amount of 2029 Notes for each trading day of the 2029 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day;

[0001628280-24-020767:notes:151]
•if we call any or all of the 2029 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the redemption date; or

[0001628280-24-020767:notes:152]
•upon the occurrence of specified corporate events as specified in the 2029 Indenture.

[0001628280-24-020767:notes:153]
On or after September 15, 2029 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2029 Notes at any time. Upon conversion, we will satisfy our conversion obligation in cash, shares of common stock or a combination of cash and shares of common stock, at our election.

[0001628280-24-020767:notes:154]
We may redeem for cash all or any portion of the 2029 Notes, at our option (subject to the partial redemption limitation set forth in the 2029 Indenture), on or after June 22, 2026, if the last reported sale price of our  common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide notice of redemption at a redemption price equal to 100% of the principal amount of the 2029 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2029 Notes. If we elect to redeem fewer than all of the outstanding 2029 Notes, at least $100.0 million aggregate principal amount of the 2029 Notes must be outstanding and not subject to redemption as of the redemption notice date. Upon the occurrence of a fundamental change (as defined in the 2029 Indenture), holders may require us to repurchase all or a portion of their 2029 Notes for cash at a price equal to 100% of the principal amount of the 2029 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-24-020767:notes:155]
The entire 2029 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of March 30, 2024 and July 1, 2023, measured at amortized cost.

[0001628280-24-020767:notes:156]
2028 Notes

[0001628280-24-020767:notes:157]
In March 2022, we issued $861.0 million in aggregate principal amount of 0.50% Convertible Senior Notes due in 2028 (the “2028 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2028 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2028 Indenture”). The 2028 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-24-020767:notes:158]
The net proceeds from the sale of the 2028 Notes was $854.8 million, after deducting $6.2 million in issuance costs. In addition, we incurred $0.7 million in professional fees in connection with this transaction. Concurrent with the issuance of the 2028 Notes, we used $200.0 million of the net proceeds to repurchase our common stock in privately negotiated transactions.

[0001628280-24-020767:notes:159]
The 2028 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year. The 2028 Notes will mature on June 15, 2028, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-24-020767:notes:160]
The initial conversion rate is 7.6319 shares of common stock per $1,000 principal amount of the 2028 Notes (which is equivalent to an initial conversion price of approximately $131.03 per share). The conversion rate is subject to adjustment upon the occurrence of certain specified events, but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2028 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2028 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-24-020767:notes:161]
Prior to the close of business on the business day immediately preceding March 15, 2028, holders of the 2028 Notes may convert their 2028 Notes only under the following circumstances:

[0001628280-24-020767:notes:162]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price, or $170.34, on each applicable trading day;

[0001628280-24-020767:notes:163]
•during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the 2028 Notes for each trading day of such measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the applicable conversion rate on each such trading day;

[0001628280-24-020767:notes:164]
•if the Company calls any or all of the 2028 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the redemption date; or

[0001628280-24-020767:notes:165]
•upon the occurrence of specified corporate events, as specified in the 2028 Indenture.

[0001628280-24-020767:notes:166]
On or after March 15, 2028 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2028 Notes at any time. Upon conversion, we may satisfy our conversion obligation in cash, shares of common stock or a combination of cash and shares of common stock, at our election.

[0001628280-24-020767:notes:167]
We may redeem for cash all or any portion of the 2028 Notes, at our option (subject to the partial redemption limitation set forth in the 2028 Indenture), on or after June 20, 2025, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the 2028 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2028 Notes. If we elect to redeem fewer than all of the outstanding 2028 Notes, at least $100.0 million aggregate principal amount of the 2028 Notes must be outstanding and not subject to redemption as of the redemption notice date. Upon the occurrence of a fundamental change (as defined in the 2028 Indenture), holders may require the Company to repurchase all or a portion of their 2028 Notes for cash at a price equal to 100% of the principal amount of the 2028 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-24-020767:notes:168]
We initially bifurcated the principal amount of the 2028 Notes into liability and equity components. The liability component of the 2028 Notes was initially valued at $629.8 million based on the contractual cash flow discounted at an appropriate comparable market on non-convertible debt borrowing rate at the date of issuance, which was 5.7%, with the equity component representing the residual amount of the proceeds of $231.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2028 Notes were accounted for as a single liability measured at amortized cost. The entire 2028 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of March 30, 2024 and July 1, 2023, measured at amortized cost.

[0001628280-24-020767:notes:169]
2026 Notes

[0001628280-24-020767:notes:170]
In December 2019, we issued $1,050.0 million in aggregate principal amount of 0.50% Convertible Senior Notes due in 2026 (the “2026 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2026 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association, as trustee (the “2026 Indenture”). We used approximately $196.0 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan credit facility, and a portion of the net proceeds of the offering to purchase approximately $200.0 million of our common stock concurrently with the pricing of the offering in privately negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-24-020767:notes:171]
The 2026 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year. The 2026 Notes will mature on December 15, 2026, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-24-020767:notes:172]
The initial conversion rate is 10.0711 shares of common stock per $1,000 principal amount of the 2026 Notes (which is equivalent to an initial conversion price of approximately $99.29 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2026 Indenture, but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2026 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares set forth in the 2026 Indenture or a holder that elects to convert the 2026 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-24-020767:notes:173]
Prior to the close of business on the business day immediately preceding September 15, 2026, holders of the 2026 Notes may convert their 2026 Notes only under the following circumstances:

[0001628280-24-020767:notes:174]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price of the 2026 Notes, or $129.08 on each applicable trading day;

[0001628280-24-020767:notes:175]
•during the five consecutive business day period after any five consecutive trading day period (the “2026 measurement period”) in which the trading price per $1,000 principal amount of the 2026 Notes for each trading day of the 2026 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the 2026 Notes on each such trading day;

[0001628280-24-020767:notes:176]
•if we call any or all of the 2026 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the relevant redemption date; or

[0001628280-24-020767:notes:177]
•upon the occurrence of specified corporate events.

[0001628280-24-020767:notes:178]
On or after September 15, 2026 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2026 Notes at any time. Upon conversion, we may satisfy our conversion obligation in cash, shares of common stock or a combination of cash and shares of common stock, at our election.

[0001628280-24-020767:notes:179]
We may redeem for cash, all or any portion of the 2026 Notes, at our option, on or after December 20, 2023, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide a notice of redemption at a redemption price equal to 100% of the principal amount of the 2026 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2026 Notes. Upon the occurrence of a fundamental change (as defined in the 2026 Indenture), holders may require us to repurchase all or a portion of the 2026 Notes for cash at a price equal to 100% of the principal amount of the 2026 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-24-020767:notes:180]
We initially bifurcated the principal amount of the 2026 Notes into liability and equity components. The liability component of the 2026 Notes was initially valued at $734.8 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 5.8% with the equity component representing the residual amount of the proceeds of $315.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2026 Notes were accounted for as a single liability measured at amortized cost. The entire 2026 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of March 30, 2024 and July 1, 2023, measured at amortized cost.

[0001628280-24-020767:notes:181]
2024 Notes

[0001628280-24-020767:notes:182]
In March 2017, we issued $450.0 million in aggregate principal amount of 0.25% convertible senior notes due in 2024 (the “2024 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes were governed by an indenture between the Company, as the issuer, and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2024 Indenture”). The 2024 Notes were unsecured and did not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-24-020767:notes:183]
The 2024 Notes bore interest at a rate of 0.25% per year. Interest on the 2024 Notes was payable semi-annually in arrears on March 15 and September 15 of each year. The 2024 Notes matured on March 15, 2024.

[0001628280-24-020767:notes:184]
The initial conversion rate of the 2024 Notes was 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which was equivalent to an initial conversion price of approximately $60.62 per share. The conversion rate was subject to adjustment upon the occurrence of certain specified events but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2024 Indenture) or our issuance of a notice of redemption, we were required to, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elected to convert the 2024 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-24-020767:notes:185]
Prior to the close of business on the business day immediately preceding December 15, 2023, each holder of the 2024 Notes was able to convert their 2024 Notes only under the following circumstances:

[0001628280-24-020767:notes:186]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter was greater than or equal to 130% of the applicable conversion price, or $78.80 on each applicable trading day;

[0001628280-24-020767:notes:187]
•during the five consecutive business day period after any five consecutive trading day period (the “2024 measurement period”) in which the trading price per $1,000 principal amount of 2024 Notes for each trading day of such 2024 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the 2024 Notes on each such trading day; or

[0001628280-24-020767:notes:188]
On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders could convert their 2024 Notes at any time. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2024 Indenture), we were required to, in certain circumstances, increase the conversion rate by a number of additional shares set forth in the 2024 Indenture for a holder that elected to convert 2024 Notes in connection with such make-whole fundamental change.

[0001628280-24-020767:notes:189]
We could not redeem the 2024 Notes prior to their maturity date and no sinking fund was provided for the 2024 Notes. Upon the occurrence of a fundamental change (as defined in the 2024 Indenture), holders could require us to repurchase all or a portion of their 2024 Notes for cash at a price equal to 100% of the principal amount of the 2024 Notes to be repurchased, plus any accrued and unpaid interest.

[0001628280-24-020767:notes:190]
We considered the features embedded in the 2024 Notes other than the conversion feature, including the holders’ put feature, our call feature, and the make-whole feature, and concluded that they are not required to be bifurcated and accounted for separately from the host debt instrument.

[0001628280-24-020767:notes:191]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. We incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. We amortized the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes was 5.4% per year.

[0001628280-24-020767:notes:192]
During fiscal 2017, we satisfied the TMA settlement condition. As such, the value of the conversion option was no longer marked-to-market and was reclassified to additional paid-in capital within stockholders’ equity on our condensed consolidated balance sheets. The value of the conversion option at the time of issuance was treated as an original issue discount for purposes of accounting for the debt component of the 2024 Notes. The debt component accreted up to the original amount over the term of the debt. The adoption of ASU 2020-06 did not change the presentation of the 2024 Notes, as the conversion feature associated with the 2024 Notes was classified within stockholders’ equity.

[0001628280-24-020767:notes:193]
Concurrent with the issuance of the 2029 Notes in June 2023, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 2024 Notes, which we accounted for as an extinguishment of liability. $13.5 million of the $132.8 million repurchase price was allocated to the conversion feature of the repurchased 2024 Notes, representing the fair value of the conversion feature at the date of the repurchase, and was recognized as a reduction of the stockholders’ equity. Additionally, since issuing the 2024 Notes, we converted a total of approximately $1.9 million of principal amount of the 2024 Notes, with less than $0.1 million of principle amount converted during the three and nine months ended March 30, 2024.

[0001628280-24-020767:notes:194]
On March 15, 2024, the 2024 Notes maturity date, we fully repaid the remaining principal amount of $323.1 million. The conversion feature previously classified within stockholder’s equity was fully amortized as of the maturity date.

[0001628280-24-020767:notes:195]
Convertible Notes - Additional Disclosures

[0001628280-24-020767:notes:196]
Our convertible notes consisted of the following components as of the periods presented (in millions):

[0001628280-24-020767:notes:197]
| March 30, 2024 |  |  | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | Total |  |  |  |  |  |
| Principal |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,514.7 |  |  |  |  |  |  |
| Unamortized debt discount and debt issuance costs |  |  | (3.2) |  |  | (4.5) |  |  | (4.6) |  |  | (12.3) |  |  |  |  |  |  |
| Net carrying amount of the liability component |  |  | $ | 1,046.8 |  |  | $ | 856.5 |  |  | $ | 599.1 |  |  | $ | 2,502.4 |  |  |  |  |  |  |

[0001628280-24-020767:notes:198]
| July 1, 2023 | 2024 Notes |  | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | Total |
| Principal | $ | 323.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,837.8 |  |
| Unamortized debt discount and debt issuance costs | (11.5) |  |  | (4.1) |  |  | (5.5) |  |  | (5.1) |  |  | (26.2) |  |
| Net carrying amount of the liability component | $ | 311.6 |  |  | $ | 1,045.9 |  |  | $ | 855.5 |  |  | $ | 598.6 |  |  | $ | 2,811.6 |  |

[0001628280-24-020767:notes:199]
(1) If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future fiscal quarter, our 2026 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-24-020767:notes:200]
(2) If the closing price of our stock exceeds $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of any future fiscal quarter, our 2028 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-24-020767:notes:201]
(3) If the closing price of our stock exceeds $90.40 (or 130% of the conversion price of $69.54) for 20 of the last 30 trading days of any future quarter, the 2029 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our consolidated balance sheets.

[0001628280-24-020767:notes:202]
The following table sets forth interest expense information related to the convertible notes for the periods presented (in millions):

[0001628280-24-020767:notes:203]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |  | March 30, 2024 |  | April 1, 2023 |
| Contractual interest expense | $ | 4.9 |  |  | $ | 2.7 |  |  | $ | 14.6 |  |  | $ | 8.1 |  |
| Amortization of the debt discount and debt issuance costs | 4.1 |  |  | 6.0 |  |  | 13.8 |  |  | 17.9 |  |
| Total interest expense | $ | 9.0 |  |  | $ | 8.7 |  |  | $ | 28.4 |  |  | $ | 26.0 |  |

[0001628280-24-020767:notes:204]
The future interest and principal payments related to our convertible notes are as follows as of March 30, 2024 (in millions):

[0001628280-24-020767:notes:205]
| Fiscal Years |  |  | 2026 Notes |  | 2028 Notes |  | 2029 Notes |  | Total |
| 2024 |  |  | $ | 2.6 |  |  | $ | 2.2 |  |  | $ | 4.6 |  |  | $ | 9.4 |  |
| 2025 |  |  | 5.3 |  |  | 4.3 |  |  | 9.1 |  |  | 18.7 |  |
| 2026 |  |  | 5.3 |  |  | 4.3 |  |  | 9.1 |  |  | 18.7 |  |
| 2027 |  |  | 1,052.5 |  |  | 4.3 |  |  | 9.1 |  |  | 1,065.9 |  |
| 2028 |  |  | — |  |  | 865.3 |  |  | 9.1 |  |  | 874.4 |  |
| Thereafter |  |  | — |  |  | — |  |  | 617.1 |  |  | 617.1 |  |
| Total payments |  |  | $ | 1,065.7 |  |  | $ | 880.4 |  |  | $ | 658.1 |  |  | $ | 2,604.2 |  |

[0001628280-24-020767:notes:206]
The principal balances of our convertible notes are reflected in the payment periods in the table above based on their respective contractual maturities.

[0001628280-24-020767:notes:207]
Mitsubishi Bank Loans

[0001628280-24-020767:notes:208]
In connection with the NeoPhotonics acquisition, we assumed several loan agreements with MUFG Bank, Ltd. (the “Mitsubishi Bank Loans”) for an aggregate fair value of approximately $5.9 million, approximately $0.9 million of which was paid in the fiscal first quarter of 2023 and the remaining balance of approximately $5.0 million was fully paid in the fiscal second quarter of 2023.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-24-020767:notes:209]
[same as prior period, unchanged from 0001628280-24-003796:notes:209]

[0001628280-24-020767:notes:210]
[same as prior period, unchanged from 0001628280-24-003796:notes:210]

[0001628280-24-020767:notes:211]
[same as prior period, unchanged from 0001628280-24-003796:notes:211]

[0001628280-24-020767:notes:212]
|  | Foreign Currency Translation Adjustments, Net of Tax (1) |  | Defined Benefit Obligations, Net of Tax (2) |  | Unrealized Gain (Loss) on Available-for-Sale Securities, Net of Tax (3) |  |  |  | Total |
| Beginning balance as of July 1, 2023 | $ | 10.4 |  |  | $ | (0.4) |  |  | $ | (5.9) |  |  |  |  | $ | 4.1 |  |
| Other comprehensive gain (loss), net | (0.2) |  |  | — |  |  | 1.3 |  |  |  |  | 1.1 |  |
| Ending balance as of September 30, 2023 | $ | 10.2 |  |  | $ | (0.4) |  |  | $ | (4.6) |  |  |  |  | $ | 5.2 |  |
| Other comprehensive gain, net | 0.2 |  |  | — |  |  | 3.8 |  |  |  |  | 4.0 |  |
| Ending balance as of December 30, 2023 | $ | 10.4 |  |  | $ | (0.4) |  |  | $ | (0.8) |  |  |  |  | $ | 9.2 |  |
| Other comprehensive gain, net | (0.1) |  |  | — |  |  | (0.3) |  |  |  |  | (0.4) |  |
| Ending balance as of March 30, 2024 | $ | 10.3 |  |  | $ | (0.4) |  |  | $ | (1.1) |  |  |  |  | $ | 8.8 |  |
|  | Foreign Currency Translation Adjustments, Net of Tax (1) |  | Defined Benefit Obligations, Net of Tax (2) |  | Unrealized Gain (Loss) on Available-for-Sale Securities, Net of Tax (3) |  |  |  | Total |
| Beginning balance as of July 2, 2022 | $ | 9.7 |  |  | $ | 1.0 |  |  | $ | (10.3) |  |  |  |  | $ | 0.4 |  |
| Other comprehensive loss, net | — |  |  | — |  |  | (0.6) |  |  |  |  | (0.6) |  |
| Ending balance as of October 1, 2022 | $ | 9.7 |  |  | $ | 1.0 |  |  | $ | (10.9) |  |  |  |  | $ | (0.2) |  |
| Other comprehensive gain, net | — |  |  | — |  |  | 3.6 |  |  |  |  | 3.6 |  |
| Ending balance as of December 31, 2022 | $ | 9.7 |  |  | $ | 1.0 |  |  | $ | (7.3) |  |  |  |  | $ | 3.4 |  |
| Other comprehensive loss, net | 0.3 |  |  | — |  |  | 3.4 |  |  |  |  | 3.7 |  |
| Ending balance as of April 1, 2023 | $ | 10.0 |  |  | $ | 1.0 |  |  | $ | (3.9) |  |  |  |  | $ | 7.1 |  |

[0001628280-24-020767:notes:213]
(1) In fiscal 2019, we established the functional currency for our worldwide operations as the U.S. dollar. Translation adjustments reported prior to December 10, 2018 remain as a component of accumulated other comprehensive income (loss) in our condensed consolidated balance sheets, until all or a part of the investment in the subsidiaries is sold or liquidated. In fiscal 2023, we acquired IPG telecom transmission product lines. The functional currency of the Brazilian entities acquired as part of this acquisition is the local currency.

[0001628280-24-020767:notes:214]
[same as prior period, unchanged from 0001628280-24-003796:notes:214]

[0001628280-24-020767:notes:215]
(3) For the three months ended March 30, 2024, December 30, 2023 and September 30, 2023, our unrealized loss on available-for-sale securities is presented net of tax of  $(0.1) million, $1.0 million and $0.4 million, respectively.

[0001628280-24-020767:notes:216]
For the three months ended April 1, 2023, December 31, 2022 and October 1, 2022, our unrealized loss on available-for-sale securities is presented net of tax of  $1.0 million, $1.0 million and $(0.2) million, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-24-020767:notes:217]
[same as prior period, unchanged from 0001628280-24-003796:notes:216]

[0001628280-24-020767:notes:218]
[same as prior period, unchanged from 0001628280-24-003796:notes:217]

[0001628280-24-020767:notes:219]
[same as prior period, unchanged from 0001628280-24-003796:notes:218]

[0001628280-24-020767:notes:220]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |  | March 30, 2024 |  | April 1, 2023 |
| Balance as of beginning of period | $ | 10.2 |  |  | $ | 14.1 |  |  | $ | 5.0 |  |  | $ | — |  |
| Charges | 19.2 |  |  | 1.6 |  |  | 36.0 |  |  | 24.8 |  |
| Payments | (11.7) |  |  | (11.5) |  |  | (23.3) |  |  | (20.6) |  |
| Balance as of end of period | $ | 17.7 |  |  | $ | 4.2 |  |  | $ | 17.7 |  |  | $ | 4.2 |  |

[0001628280-24-020767:notes:221]
During the three and nine months ended March 30, 2024, we recorded restructuring and related charges of $19.2 million and $36.0 million, respectively, primarily due to company-wide cost reduction initiatives, as well as our integration efforts to consolidate our manufacturing sites. We have shutdown our factories in China acquired as part of the NeoPhotonics acquisition and are ramping up production of most of related products at our Thailand facility. In addition, we are executing our plans to consolidate our wafer fabrication facilities in Japan.

[0001628280-24-020767:notes:222]
During the three months ended April 1, 2023, we recorded restructuring and related charges of $1.6 million in our condensed consolidated statements of operations, which was primarily due to company-wide integration efforts as a result of the merger with NeoPhotonics, as well as our cost reduction initiatives. During the nine months ended April 1, 2023, we recorded restructuring and related charges of $24.8 million in our condensed consolidated statements of operations, which was primarily attributable to company-wide integration efforts as a result of the merger with NeoPhotonics, our cost reduction initiatives, as well as severance and employee-related benefits associated with NeoPhotonics’ executive severance and retention agreements. These agreements provide for payments and benefits upon an involuntary termination of employment under certain circumstances.

[0001628280-24-020767:notes:223]
[same as prior period, unchanged from 0001628280-24-003796:notes:222]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-24-020767:notes:224]
[same as prior period, unchanged from 0001628280-24-003796:notes:223]

[0001628280-24-020767:notes:225]
[same as prior period, unchanged from 0001628280-24-003796:notes:224]

[0001628280-24-020767:notes:226]
We recorded a tax provision of $19.6 million and $15.8 million for the three and nine months ended March 30, 2024, respectively. Our tax provision for the three months ended March 30, 2024 includes a discrete tax expense of $17.6 million, primarily related to the establishment of a partial valuation allowance against certain deferred tax assets, withholding taxes, and changes in prior year uncertain tax positions, partially offset by the tax benefit of tax rate changes. Our tax provision for the nine months ended March 30, 2024 includes a discrete tax expense of $19.2 million, primarily related to the establishment of a partial valuation allowance against certain deferred tax assets, withholding taxes, a shortfall in connection with stock-based compensation vested during the period, and interest on uncertain tax positions, partially offset by the tax benefit from tax rate changes.

[0001628280-24-020767:notes:227]
We regularly assess our ability to realize our deferred tax assets on a quarterly basis and will establish a valuation allowance if it is more-likely-than-not that some portion of the deferred tax assets will not be realized. During the three-months ended March 30, 2024, we determined that a portion of our deferred tax assets related to certain tax credit carryforwards are not more-likely-than-not to be realized, and we established a valuation allowance of $10.9 million against such deferred tax assets. We will continue to assess the need for a valuation allowance against our remaining deferred tax assets and may increase or decrease our valuation allowance materially in the future.

[0001628280-24-020767:notes:228]
We recorded a tax benefit of $9.4 million and a tax provision of $14.4 million for the three and nine months ended April 1, 2023, respectively. Our tax provision for the three months ended April 1, 2023 includes a discrete tax benefit of $9.8 million primarily related to a tax planning action that was implemented during the quarter relating to fiscal year 2022 and changes in prior year uncertain tax positions, partially offset by a shortfall in connection with stock-based compensation vested during the quarter. Our tax provision for the nine months ended April 1, 2023 includes a discrete tax expense of $7.2 million, primarily related to international restructuring, partially offset by the tax benefits from tax rate changes, a tax planning action that was implemented during the quarter relating to fiscal year 2022, and changes in prior year uncertain tax positions.

[0001628280-24-020767:notes:229]
Our estimated effective tax rate for fiscal 2024 differs from the 21% U.S. statutory rate primarily due to the income tax expense from foreign rate differential, non-deductible stock-based compensation, and current year valuation allowance changes, partially offset by the income tax benefit from various income tax credits.

[0001628280-24-020767:notes:230]
As of March 30, 2024, we had $73.9 million of unrecognized tax benefits, which, if recognized, would affect the effective tax rate. We are subject to examination of income tax returns by various domestic and foreign tax authorities. The timing of resolution and closure of these tax examinations is highly unpredictable. Although it is possible that certain ongoing tax examinations may be concluded within the next 12 months, we cannot reasonably estimate the impact to tax expense and net income from tax examinations that could be resolved or closed within the next 12 months. Subject to audit timing and uncertainty, we expect the amount of unrecognized tax benefit that would become recognized due to expiration of the statute of limitations and affect the effective tax rate to decrease by $3.0 million over the next 12 months.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-24-020767:notes:231]
[same as prior period, unchanged from 0001628280-24-003796:notes:229]

[0001628280-24-020767:notes:232]
[same as prior period, unchanged from 0001628280-24-003796:notes:230]

[0001628280-24-020767:notes:233]
[same as prior period, unchanged from 0001628280-24-003796:notes:231]

[0001628280-24-020767:notes:234]
[same as prior period, unchanged from 0001628280-24-003796:notes:233]

[0001628280-24-020767:notes:235]
As of March 30, 2024, we had 5.0 million shares subject to stock options, restricted stock units, restricted stock awards, and performance stock units issued and outstanding under the 2015 Plan. Restricted stock units, restricted stock awards, and performance stock units are performance-based, time-based or a combination of both and are expected to vest within four years. The fair value of these grants is based on the closing market price of our common stock on the date of grant. The exercise price for stock options is equal to the fair value of the underlying stock at the date of grant. We issue new shares of common stock upon exercise of stock options. Options generally have vesting period of three years. As of March 30, 2024, 4.1 million shares of common stock under the 2015 Plan were available for grant.

[0001628280-24-020767:notes:236]
On November 28, 2023 we adopted and assumed the Cloud Light Share Option Scheme (the “Cloud Light Scheme”) in connection with the Cloud Light acquisition and we have reserved a total of 1.5 million shares of common stock for issuance thereunder, of which 1.1 million options was granted at the acquisition date.

[0001628280-24-020767:notes:237]
[same as prior period, unchanged from 0001628280-24-003796:notes:235]

[0001628280-24-020767:notes:238]
[same as prior period, unchanged from 0001628280-24-003796:notes:236]

[0001628280-24-020767:notes:239]
[same as prior period, unchanged from 0001628280-24-003796:notes:237]

[0001628280-24-020767:notes:240]
[same as prior period, unchanged from 0001628280-24-003796:notes:238]

[0001628280-24-020767:notes:241]
[same as prior period, unchanged from 0001628280-24-003796:notes:239]

[0001628280-24-020767:notes:242]
[same as prior period, unchanged from 0001628280-24-003796:notes:240]

[0001628280-24-020767:notes:243]
During the nine months ended March 30, 2024, our board of directors approved grants of 1.9 million RSUs, which primarily vest over three years.

[0001628280-24-020767:notes:244]
[same as prior period, unchanged from 0001628280-24-003796:notes:242]

[0001628280-24-020767:notes:245]
[same as prior period, unchanged from 0001628280-24-003796:notes:243]

[0001628280-24-020767:notes:246]
[same as prior period, unchanged from 0001628280-24-003796:notes:244]

[0001628280-24-020767:notes:247]
During the nine months ended March 30, 2024, our board of directors approved a grant of 0.3 million PSUs with an aggregate grant date fair value of $16.0 million to executive and non-executive employees as part of our revised Annual Incentive Plan. These PSUs are subject to performance targets and service conditions, with a vesting period of one year. The board of directors also approved a grant of 0.4 million PSUs with an aggregate grant date fair value of $19.9 million to certain executive officers and senior management. These PSUs will vest subject to the achievement of revenue targets and certain non-financial performance measurements, as well as service conditions, over three years.

[0001628280-24-020767:notes:248]
[same as prior period, unchanged from 0001628280-24-003796:notes:246]

[0001628280-24-020767:notes:249]
Our 2015 Purchase Plan provides eligible employees with the opportunity to acquire an ownership interest in the Company through periodic payroll deductions and provides a 15% purchase price discount as well as a 6-month look-back period. The 2015 Purchase Plan is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986, as amended. The 2015 Purchase Plan will terminate upon the date on which all shares available for issuance have been sold. Of the 3.0 million shares authorized under the 2015 Purchase Plan, 0.9 million shares remained available for issuance as of March 30, 2024.

[0001628280-24-020767:notes:250]
[same as prior period, unchanged from 0001628280-24-003796:notes:248]

[0001628280-24-020767:notes:251]
[same as prior period, unchanged from 0001628280-24-003796:notes:249]

[0001628280-24-020767:notes:252]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |  | March 30, 2024 |  | April 1, 2023 |
| Cost of sales | $ | 8.5 |  |  | $ | 6.9 |  |  | $ | 23.5 |  |  | $ | 19.1 |  |
| Research and development | 9.8 |  |  | 11.0 |  |  | 30.1 |  |  | 31.2 |  |
| Selling, general and administrative | 13.3 |  |  | 15.2 |  |  | 44.7 |  |  | 66.0 |  |
| Total stock-based compensation | $ | 31.6 |  |  | $ | 33.1 |  |  | $ | 98.3 |  |  | $ | 116.3 |  |

[0001628280-24-020767:notes:253]
Stock-based compensation for the nine months ended April 1, 2023 includes $11.9 million of expenses related to the acceleration of certain equity awards in connection with the NeoPhotonics acquisition.

[0001628280-24-020767:notes:254]
During the three months ended March 30, 2024, we recorded $0.9 million of net reversal of stock-based compensation related to PSUs due to decline in the anticipated achievement of performance conditions. During the nine months ended March 30, 2024, we recorded $3.6 million of stock-based compensation related to PSUs. During the three and nine months ended April 1, 2023, we recorded $3.5 million and $17.0 million of stock-based compensation related to PSUs, respectively. The amount of stock-based compensation expense recognized in any one period related to PSUs can vary based on the achievement or anticipated achievement of the performance conditions. If the performance conditions are not met or not expected to be met, no compensation cost would be recognized on the underlying PSUs, and any previously recognized compensation expense related to those PSUs would be reversed.

[0001628280-24-020767:notes:255]
[same as prior period, unchanged from 0001628280-24-003796:notes:253]

[0001628280-24-020767:notes:256]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |  | March 30, 2024 |  | April 1, 2023 |
| Income tax benefit associated with stock-based compensation | $ | 3.6 |  |  | $ | 3.3 |  |  | $ | 6.1 |  |  | $ | 9.7 |  |

[0001628280-24-020767:notes:257]
Approximately $16.0 million and $14.2 million of stock-based compensation was capitalized to inventory as of March 30, 2024 and July 1, 2023, respectively.

[0001628280-24-020767:notes:258]
As of March 30, 2024, $153.4 million of stock-based compensation cost related to RSU awards remains to be amortized, which is expected to be recognized over an estimated amortization period of 2.0 years.

[0001628280-24-020767:notes:259]
[same as prior period, unchanged from 0001628280-24-003796:notes:257]

[0001628280-24-020767:notes:260]
The following table summarizes our award activities for the nine months ended March 30, 2024 (in millions):

[0001628280-24-020767:notes:261]
|  | Stock Options |  | Restricted Stock Units |  | Performance Stock Units |  |  |  |  |
|  | Number of Shares |  | Weighted-Average Exercise Price per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  |  |  |  |
| Balance as of July 1, 2023 | — |  |  | $ | — |  |  | 2.6 |  |  | $ | 85.0 |  |  | 0.6 |  |  | $ | 89.1 |  |  |  |  |  |
| Replacement options in connection with Cloud Light acquisition | 1.1 |  |  | 34.6 |  |  | — |  |  | — |  |  | — |  |  | — |  |  |  |  |  |
| Granted | — |  |  | — |  |  | 1.9 |  |  | 52.4 |  |  | 0.7 |  |  | 53.1 |  |  |  |  |  |
| Vested/Exercised (1) | — |  |  | 8.0 |  |  | (1.2) |  |  | 85.8 |  |  | (0.1) |  |  | 88.8 |  |  |  |  |  |
| Canceled | — |  |  | — |  |  | (0.3) |  |  | 72.8 |  |  | (0.3) |  |  | 84.1 |  |  |  |  |  |
| Balance as of March 30, 2024 | 1.1 |  |  | $ | 34.6 |  |  | 3.0 |  |  | $ | 64.7 |  |  | 0.9 |  |  | $ | 65.8 |  |  |  |  |  |

[0001628280-24-020767:notes:262]
[same as prior period, unchanged from 0001628280-24-003796:notes:260]

[0001628280-24-020767:notes:263]
[same as prior period, unchanged from 0001628280-24-003796:notes:261]

[0001628280-24-020767:notes:264]
|  | Awards Available for Grant |
| Balance as of July 1, 2023 | 2.7 |  |
| Authorized in connection with Cloud Light acquisition | 1.5 |  |
| Replacement options in connection with Cloud Light acquisition | (1.1) |  |
| Authorized | 3.0 |  |
| Granted | (2.6) |  |
| Canceled | 0.6 |  |
| Balance as of March 30, 2024 | 4.1 |  |

[0001628280-24-020767:notes:265]
[same as prior period, unchanged from 0001628280-24-003796:notes:263]

[0001628280-24-020767:notes:266]
The 2015 Purchase Plan expense for the three and nine months ended March 30, 2024 was $1.3 million and $3.6 million, respectively. The 2015 Purchase Plan expense for the three and nine months ended April 1, 2023 was $1.7 million and $3.7 million, respectively. The expense related to the 2015 Purchase Plan is recorded on a straight-line basis over the relevant subscription period.

[0001628280-24-020767:notes:267]
During the nine months ended March 30, 2024, there were 0.2 million shares issued to employees through the 2015 Purchase Plan. During the nine months ended April 1, 2023, there were 0.1 million shares issued to employees through the 2015 Purchase Plan.

[0001628280-24-020767:notes:268]
[same as prior period, unchanged from 0001628280-24-003796:notes:266]

[0001628280-24-020767:notes:269]
[same as prior period, unchanged from 0001628280-24-003796:notes:267]

[0001628280-24-020767:notes:270]
We have a share buyback program that authorizes us to utilize up to an aggregate amount of $1.2 billion to purchase our own shares of common stock through May 2025. During the nine months ended March 30, 2024, we did not repurchase any shares of our common stock. During the nine months ended April 1, 2023, we repurchased 0.3 million shares of our common stock at an average price of $89.80 per share for an aggregate purchase price of $25.7 million. Since the board of directors initially approved the share buyback program, we have repurchased 7.7 million shares in aggregate at an average price of $81.66 per share for a total purchase price of $630.4 million. We recorded the $630.4 million aggregate purchase price as a reduction of retained earnings within our condensed consolidated balance sheet and immediately retired all repurchased shares. As of March 30, 2024, we have $569.6 million remaining under the share buyback program.

[0001628280-24-020767:notes:271]
[same as prior period, unchanged from 0001628280-24-003796:notes:269]


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001628280-24-020767:notes:272]
Note 14. Commitments and Contingencies

[0001628280-24-020767:notes:273]
Purchase Obligations

[0001628280-24-020767:notes:274]
Our purchase obligations of $369.8 million as of March 30, 2024 represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001628280-24-020767:notes:275]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with these vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

[0001628280-24-020767:notes:276]
Product Warranties

[0001628280-24-020767:notes:277]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve-month warranty for most of our products. However, in some instances depending upon the product, product components or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products, and service delivery costs incurred in correcting product failures. In addition, from time-to-time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001628280-24-020767:notes:278]
The following table presents the changes in our warranty reserve for the periods presented (in millions):

[0001628280-24-020767:notes:279]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |  | March 30, 2024 |  | April 1, 2023 |
| Balance as of beginning of period | $ | 10.1 |  |  | $ | 8.4 |  |  | $ | 6.8 |  |  | $ | 10.0 |  |
| Warranties assumed in NeoPhotonics merger | — |  |  | — |  |  | — |  |  | 0.7 |  |
| Warranty assumed from Cloud Light | 3.0 |  |  | — |  |  | 8.2 |  |  | — |  |
| Provision for warranty | 2.6 |  |  | 1.1 |  |  | 3.6 |  |  | 5.4 |  |
| Utilization of reserve, net | (2.2) |  |  | (2.7) |  |  | (5.1) |  |  | (9.3) |  |
| Balance as of end of period | $ | 13.5 |  |  | $ | 6.8 |  |  | $ | 13.5 |  |  | $ | 6.8 |  |

[0001628280-24-020767:notes:280]
Environmental Liabilities

[0001628280-24-020767:notes:281]
Our research and development, manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental and product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001628280-24-020767:notes:282]
Legal Proceedings

[0001628280-24-020767:notes:283]
We are subject to a variety of claims and suits that arise from time-to-time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss. During the year ended July 1, 2023, we recorded $7.8 million with respect to the pending settlement of certain non-ordinary course litigation matters under accrued expenses in our consolidated balance sheet, which has not been settled as of March 30, 2024.

[0001628280-24-020767:notes:284]
Oclaro Merger Litigation

[0001628280-24-020767:notes:285]
In connection with our acquisition of Oclaro in 2018, seven lawsuits were filed by purported stockholders of Oclaro challenging the proposed merger (the “Merger”). All but one was voluntarily dismissed after the Oclaro Merger closed. The remaining lawsuit, SaiSravan B. Karri v. Oclaro, Inc., et al., No. 3:18-cv-03435-JD (the “Karri Lawsuit”), was filed in the United States District Court for the Northern District of California and is styled as a class action.

[0001628280-24-020767:notes:286]
The Karri Lawsuit alleges, among other things, that Oclaro and its directors violated Section 14(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), and Rule 14a-9 promulgated thereunder by disseminating an incomplete and misleading Form S-4, including proxy statement/prospectus. The Karri Lawsuit further alleged that Oclaro’s directors violated Section 20(a) of the Exchange Act by failing to exercise proper control over the person(s) who violated Section 14(a) of the Exchange Act. The plaintiff in the Karri Lawsuit seeks, among other things, damages to be awarded to the plaintiff and any class, if a class is certified, and litigation costs, including attorneys’ fees.

[0001628280-24-020767:notes:287]
After the plaintiff in the Karri Lawsuit was appointed as lead plaintiff and his counsel as lead counsel, the plaintiff filed a first amended complaint on April 15, 2019. The first amended complaint, also named Lumentum as a defendant but Lumentum has since been dismissed from the action. On October 8, 2020, the court granted in part and denied in part the defendant’s motion to dismiss the first amended complaint. On December 1, 2020, defendants answered the first amended complaint. On September 17, 2021, lead plaintiff filed a second amended complaint. Defendants moved to stay discovery in light of the second amended complaint. On January 11, 2022, the Court struck the second amended complaint as untimely, terminated defendants’ motions to dismiss as moot, and lifted the stay. The case proceeded through fact and expert discovery.

[0001628280-24-020767:notes:288]
On August 16, 2022, the lead plaintiff moved for class certification and to be appointed class representative. Defendants opposed the motion. The action subsequently was stayed while the parties participated in a mediation. On January 18, 2023, the lead plaintiff filed a Notice of Settlement informing the court of an agreement in principle between the parties for a class-wide settlement of the Karri Lawsuit. On January 24, 2023, in light of the potential settlement, the court vacated all pretrial and trial dates and ordered the lead plaintiff to file a motion for preliminary approval of the settlement by March 17, 2023. The lead plaintiff filed his motion for preliminary approval of the settlement on March 16, 2023, and defendants filed a statement of non-opposition on March 30, 2023. On April 20, 2023, the court held a hearing on lead plaintiff’s motion for preliminary approval of the settlement. The court declined to grant lead plaintiff’s motion for preliminary approval and ordered lead plaintiff to file a revised motion by May 22, 2023. Lead plaintiff filed his Revised Motion for Preliminary Approval of Settlement (the “Amended Motion”) on May 22, 2023, defendants filed a response in support of the Amended Motion on June 5, 2023, and the lead plaintiff submitted his reply on June 12, 2023. The hearing on the Amended Motion took place on August 17, 2023 and the court preliminarily approved the settlement. In March 2024, the court approved the settlement amount of $15.3 million.

[0001628280-24-020767:notes:289]
We recorded the court approved settlement amount of $15.3 million as accrued expenses in our condensed consolidated balance sheet as of March 30, 2024, of which $7.5 million represents the amount to be reimbursed by insurance and was recorded as prepayments and other current assets.

[0001628280-24-020767:notes:290]
Indemnifications

[0001628280-24-020767:notes:291]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown, because claims may be made against us in the future, and we may record charges in the future as a result of these indemnification obligations. As of March 30, 2024, we did not have any material indemnification claims that were probable or reasonably possible.

[0001628280-24-020767:notes:292]
Audit Proceedings

[0001628280-24-020767:notes:293]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period when we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-24-020767:notes:294]
[same as prior period, unchanged from 0001628280-24-003796:notes:291]

[0001628280-24-020767:notes:295]
[same as prior period, unchanged from 0001628280-24-003796:notes:292]

[0001628280-24-020767:notes:296]
[same as prior period, unchanged from 0001628280-24-003796:notes:293]

[0001628280-24-020767:notes:297]
[same as prior period, unchanged from 0001628280-24-003796:notes:294]

[0001628280-24-020767:notes:298]
[same as prior period, unchanged from 0001628280-24-003796:notes:295]

[0001628280-24-020767:notes:299]
[same as prior period, unchanged from 0001628280-24-003796:notes:296]

[0001628280-24-020767:notes:300]
[same as prior period, unchanged from 0001628280-24-003796:notes:297]

[0001628280-24-020767:notes:301]
[same as prior period, unchanged from 0001628280-24-003796:notes:298]

[0001628280-24-020767:notes:302]
[same as prior period, unchanged from 0001628280-24-003796:notes:299]

[0001628280-24-020767:notes:303]
[same as prior period, unchanged from 0001628280-24-003796:notes:300]

[0001628280-24-020767:notes:304]
[same as prior period, unchanged from 0001628280-24-003796:notes:301]

[0001628280-24-020767:notes:305]
[same as prior period, unchanged from 0001628280-24-003796:notes:302]

[0001628280-24-020767:notes:306]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |  | March 30, 2024 |  | April 1, 2023 |
| Net revenue: |  |  |  |  |  |  |  |
| Cloud & Networking | $ | 313.8 |  |  | 293.0 |  |  | $ | 830.2 |  |  | $ | 1,036.0 |  |
| Industrial Tech | 52.7 |  |  | 90.4 |  |  | 220.7 |  |  | 360.2 |  |
| Net revenue | $ | 366.5 |  |  | $ | 383.4 |  |  | $ | 1,050.9 |  |  | $ | 1,396.2 |  |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Cloud & Networking | $ | 45.9 |  |  | 61.0 |  |  | $ | 98.9 |  |  | $ | 262.6 |  |
| Industrial Tech | (2.7) |  |  | 22.1 |  |  | 25.3 |  |  | 140.6 |  |
| Total segment profit | 43.2 |  |  | 83.1 |  |  | 124.2 |  |  | 403.2 |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Selling, general and administrative (1) | (28.2) |  |  | (31.7) |  |  | (85.6) |  |  | (97.7) |  |
| Stock-based compensation | (31.6) |  |  | (33.1) |  |  | (98.3) |  |  | (104.4) |  |
| Stock-based compensation - acquisition related | — |  |  | — |  |  | — |  |  | (11.9) |  |
| Amortization of acquired intangibles | (42.1) |  |  | (30.0) |  |  | (108.7) |  |  | (98.3) |  |
| Amortization of acquired inventory fair value adjustments | (4.9) |  |  | (3.6) |  |  | (8.3) |  |  | (17.8) |  |
| Acquisition related costs | (0.5) |  |  | — |  |  | (13.5) |  |  | (16.2) |  |
| Integration related costs | (10.2) |  |  | (10.6) |  |  | (29.7) |  |  | (19.2) |  |
| Restructuring and related charges | (19.2) |  |  | (1.6) |  |  | (36.0) |  |  | (24.8) |  |
| Abnormal excess capacity (2) | (11.9) |  |  | — |  |  | (13.7) |  |  | — |  |
| Litigation matters | — |  |  | — |  |  | — |  |  | (7.8) |  |
| Intangible asset write-off | — |  |  | (11.5) |  |  | — |  |  | (11.5) |  |
| Other charges, net (3) | (9.2) |  |  | (12.4) |  |  | (31.0) |  |  | (53.4) |  |
| Interest expense | (9.0) |  |  | (8.7) |  |  | (28.4) |  |  | (26.1) |  |
| Other income, net (4) | 16.2 |  |  | 11.4 |  |  | 50.8 |  |  | 28.9 |  |
| Consolidated loss before income taxes | $ | (107.4) |  |  | $ | (48.7) |  |  | $ | (278.2) |  |  | $ | (57.0) |  |

[0001628280-24-020767:notes:307]
[same as prior period, unchanged from 0001628280-24-003796:notes:304]

[0001628280-24-020767:notes:308]
(2) Abnormal excess capacity for the three months ended March 30, 2024 represents excess capacity attributable to a near-term reduction in our manufacturing production, primarily driven by our non-recurring inventory reduction effort following the disruptions in the supply chain due to the COVID-19 pandemic and factory consolidation efforts.

[0001628280-24-020767:notes:309]
(3) Other charges, net for the three months ended March 30, 2024 primarily relate to $4.8 million of non-recurring legal and tax related fees and $1.7 million of net excess and obsolete inventory, offset by various miscellaneous gains. The excess and obsolete inventory charges relate to charges that are not attributable to our operating segments due to their unusual nature, primarily those charges driven by U.S. trade restrictions whereby we are no longer able to sell certain products to one of our customers.

[0001628280-24-020767:notes:310]
Other charges, net for the nine months ended March 30, 2024 primarily relate to $10.9 million of net excess and obsolete inventory, $10.2 million of non-recurring legal and tax related fees, and $4.4 million of incremental costs of sales related to components previously acquired from various brokers to satisfy customer demand, offset by various miscellaneous gains. The excess and obsolete inventory charges relate to charges that are not attributable to our operating segments due to their unusual nature, primarily those charges driven by U.S. trade restrictions whereby we are no longer able to sell certain products to one of our customers.

[0001628280-24-020767:notes:311]
Other charges, net for the three months ended April 1, 2023 primarily relate to $8.0 million of incremental costs of sales related to components previously acquired from various brokers to satisfy customer demand.

[0001628280-24-020767:notes:312]
Other charges, net for the nine months ended April 1, 2023 primarily relate to $27.0 million of incremental costs of sales related to components previously acquired from various brokers to satisfy customer demand, $6.7 million of non-recurring legal and professional fees, and $5.4 million of excess and obsolete inventory charges primarily driven by synergies as a result of the NeoPhotonics integration.

[0001628280-24-020767:notes:313]
(4) Other income, net for the three months ended March 30, 2024 includes interest and investment income of $12.6 million, offset by foreign exchange and other gains, net of $3.7 million. Other income, net for the nine months ended March 30, 2024 includes interest and investment income of $51.4 million, offset by foreign exchange and other loss, net of $0.5 million.

[0001628280-24-020767:notes:314]
Other income, net for the three months ended April 1, 2023 includes interest and investment income of $11.9 million, offset by net foreign exchange losses of $0.5 million. Other income, net for the nine months ended April 1, 2023 includes interest and investment income of $24.4 million, net foreign exchange gains of $4.4 million and other income of $0.1 million.

[0001628280-24-020767:notes:315]
[same as prior period, unchanged from 0001628280-24-003796:notes:311]

[0001628280-24-020767:notes:316]
[same as prior period, unchanged from 0001628280-24-003796:notes:312]

[0001628280-24-020767:notes:317]
[same as prior period, unchanged from 0001628280-24-003796:notes:313]

[0001628280-24-020767:notes:318]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |  | March 30, 2024 |  | April 1, 2023 |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 129.9 |  |  | 35.4 | % |  | $ | 68.3 |  |  | 17.8 | % |  | $ | 274.0 |  |  | 26.2 | % |  | $ | 196.0 |  |  | 14.0 | % |
| Mexico | 18.9 |  |  | 5.2 |  |  | 20.5 |  |  | 5.4 |  |  | 74.0 |  |  | 7.0 |  |  | 137.5 |  |  | 9.8 |  |
| Other Americas | 0.6 |  |  | 0.2 |  |  | 1.9 |  |  | 0.5 |  |  | 2.6 |  |  | 0.2 |  |  | 8.0 |  |  | 0.6 |  |
| Total Americas | $ | 149.4 |  |  | 40.8 | % |  | $ | 90.7 |  |  | 23.7 | % |  | $ | 350.6 |  |  | 33.4 | % |  | $ | 341.5 |  |  | 24.4 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 62.0 |  |  | 16.9 | % |  | $ | 46.5 |  |  | 12.1 | % |  | $ | 192.6 |  |  | 18.3 | % |  | $ | 190.0 |  |  | 13.6 | % |
| South Korea | 16.2 |  |  | 4.4 |  |  | 28.5 |  |  | 7.4 |  |  | 62.0 |  |  | 5.9 |  |  | 148.2 |  |  | 10.6 |  |
| Japan | 16.6 |  |  | 4.5 |  |  | 41.8 |  |  | 10.9 |  |  | 67.9 |  |  | 6.5 |  |  | 137.4 |  |  | 9.8 |  |
| Thailand | 44.0 |  |  | 12.0 |  |  | 67.8 |  |  | 17.7 |  |  | 147.5 |  |  | 14.0 |  |  | 203.2 |  |  | 14.6 |  |
| Other Asia-Pacific | 46.0 |  |  | 12.6 |  |  | 61.5 |  |  | 16.0 |  |  | 135.0 |  |  | 12.8 |  |  | 235.1 |  |  | 16.8 |  |
| Total Asia-Pacific | $ | 184.8 |  |  | 50.4 | % |  | $ | 246.1 |  |  | 64.1 | % |  | $ | 605.0 |  |  | 57.5 | % |  | $ | 913.9 |  |  | 65.5 | % |
| EMEA | $ | 32.3 |  |  | 8.8 | % |  | $ | 46.6 |  |  | 12.2 | % |  | $ | 95.3 |  |  | 9.1 | % |  | $ | 140.8 |  |  | 10.1 | % |
| Total net revenue | $ | 366.5 |  |  | 100.0 | % |  | $ | 383.4 |  |  | 100.0 | % |  | $ | 1,050.9 |  |  | 100.0 | % |  | $ | 1,396.2 |  |  | 100.0 | % |

[0001628280-24-020767:notes:319]
The following table sets forth net revenue generated from a single customer that represented 10% or greater of the total net revenue for the periods presented:

[0001628280-24-020767:notes:320]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |  | March 30, 2024 |  | April 1, 2023 |
| Customer A | 28.5 | % |  | * |  | 18.7 | % |  | * |
| Customer B | * |  | 12.7 | % |  | * |  | * |
| Customer C | * |  | 10.7 | % |  | 12.1 | % |  | 16.1 | % |
| Customer D | * |  | * |  | * |  | 13.1 | % |
| *Represents less than 10% of total net revenue |  |  |  |  |  |  |  |

[0001628280-24-020767:notes:321]
The following table sets forth accounts receivable from a single customer that represented 10% or greater of the total accounts receivable for the periods presented:

[0001628280-24-020767:notes:322]
|  | March 30, 2024 |  | July 1, 2023 |
| Customer 1 | 18.9 | % |  | * |
| Customer 2 | * |  | 14.3 | % |
| Customer 3 | * |  | 11.9 | % |
| Customer 4 | * |  | 11.9 | % |
| *Represents less than 10% of total accounts receivable |  |  |  |

[0001628280-24-020767:notes:323]
[same as prior period, unchanged from 0001628280-24-003796:notes:318]

[0001628280-24-020767:notes:324]
|  | March 30, 2024 |  | July 1, 2023 |
| Property, plant and equipment, net |  |  |  |
| United States | $ | 134.2 |  |  | $ | 134.7 |  |
| Thailand | 135.9 |  |  | 132.0 |  |
| Japan | 80.1 |  |  | 93.0 |  |
| United Kingdom | 80.2 |  |  | 38.2 |  |
| China | 92.0 |  |  | 42.1 |  |
| Other countries | 56.3 |  |  | 49.5 |  |
| Total property, plant and equipment, net | $ | 578.7 |  |  | $ | 489.5 |  |

[0001628280-24-020767:notes:325]
We purchase a portion of our inventory from contract manufacturers and vendors located primarily in Taiwan, Thailand and Malaysia. The following table sets forth accounts receivable from a single contract manufacturer that represented 10% or greater of our total net inventory purchases for the periods presented:

[0001628280-24-020767:notes:326]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |  | March 30, 2024 |  | April 1, 2023 |
| Contract Manufacturer A | 24.7 | % |  | 44.4% |  | 30.6 | % |  | 42.4% |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-24-020767:notes:327]
[same as prior period, unchanged from 0001628280-24-003796:notes:321]

[0001628280-24-020767:notes:328]
[same as prior period, unchanged from 0001628280-24-003796:notes:322]

[0001628280-24-020767:notes:329]
[same as prior period, unchanged from 0001628280-24-003796:notes:323]

[0001628280-24-020767:notes:330]
[same as prior period, unchanged from 0001628280-24-003796:notes:324]

[0001628280-24-020767:notes:331]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |  | March 30, 2024 |  | April 1, 2023 |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Cloud & Networking | $ | 313.8 |  |  | 85.6 | % |  | 293.0 |  |  | 76.4 | % |  | $ | 830.2 |  |  | 79.0 | % |  | $ | 1,036.0 |  |  | 74.2 | % |
| Industrial Tech | 52.7 |  |  | 14.4 | % |  | 90.4 |  |  | 23.6 | % |  | 220.7 |  |  | 21.0 | % |  | 360.2 |  |  | 25.8 | % |
| Net revenue | $ | 366.5 |  |  | 100.0 | % |  | $ | 383.4 |  |  | 100.0 | % |  | $ | 1,050.9 |  |  | 100.0 | % |  | $ | 1,396.2 |  |  | 100.0 | % |

[0001628280-24-020767:notes:332]
[same as prior period, unchanged from 0001628280-24-003796:notes:326]

[0001628280-24-020767:notes:333]
[same as prior period, unchanged from 0001628280-24-003796:notes:327]

[0001628280-24-020767:notes:334]
| Contract balances |  | Balance sheet location |  | March 30, 2024 |  | July 1, 2023 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 229.8 |  |  | $ | 246.1 |  |  | $ | (16.3) |  |  | (6.6) | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | 0.8 |  |  | $ | 2.1 |  |  | $ | (1.3) |  |  | (61.9) | % |
