# LITE 8-K — 0001628280-24-020640 filed 2024-05-06

## item codes, every 8-K on or before 2024-05-07

- 2024-05-06 0001628280-24-020640 — 2.02, 9.01
- 2024-02-27 0001628280-24-006936 — 5.02
- 2024-02-08 0001628280-24-003789 — 2.02, 9.01
- 2024-01-18 0001628280-24-001551 — 9.01 — amendment of 0001193125-23-272452
- 2023-11-21 0001628280-23-039654 — 5.02, 5.07
- 2023-11-08 0001628280-23-037563 — 2.02, 9.01
- 2023-11-07 0001193125-23-272452 — 2.01, 8.01, 9.01
- 2023-10-30 0001193125-23-265658 — 1.01, 2.02, 9.01
- 2023-08-17 0001628280-23-029741 — 2.02, 9.01
- 2023-06-16 0001193125-23-168966 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2023-05-09 0001628280-23-016629 — 2.02, 9.01
- 2023-04-06 0001628280-23-010935 — 2.02, 8.01, 9.01
- 2023-02-24 0001193125-23-048742 — 5.02, 9.01
- 2023-02-09 0001628280-23-002866 — 2.02, 9.01
- 2022-11-21 0001628280-22-030473 — 5.02, 5.07, 9.01
- 2022-11-08 0001628280-22-028758 — 2.02, 9.01
- 2022-08-16 0001628280-22-022980 — 2.02, 9.01
- 2022-08-03 0001193125-22-210674 — 2.01, 8.01, 9.01
- 2022-07-29 0001193125-22-206587 — 8.01, 9.01
- 2022-05-04 0001628280-22-012145 — 2.02, 9.01
- 2022-03-08 0001193125-22-069350 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2022-02-03 0001628280-22-001736 — 2.02, 9.01
- 2022-01-21 0001193125-22-014413 — 8.01, 9.01
- 2021-11-23 0001628280-21-024070 — 5.02, 5.07
- 2021-11-05 0001193125-21-321796 — 1.01, 9.01
- 2021-11-04 0001628280-21-021618 — 2.02, 9.01
- 2021-11-04 0001193125-21-319601 — 8.01, 9.01
- 2021-08-18 0001628280-21-017219 — 2.02, 9.01
- 2021-06-08 0001633978-21-000030 — 5.02, 9.01
- 2021-05-12 0001633978-21-000008 — 2.02, 9.01
- 2021-03-10 0001193125-21-075438 — 1.01, 8.01, 9.01
- 2021-02-02 0001633978-21-000002 — 2.02, 9.01
- 2021-01-19 0001104659-21-005024 — 1.01, 2.02, 8.01, 9.01
- 2020-11-24 0001193125-20-302557 — 5.02, 5.07
- 2020-11-02 0001633978-20-000017 — 2.02, 9.01
- 2020-09-18 0001633978-20-000012 — 5.02, 9.01
- 2020-08-11 0001633978-20-000010 — 2.02, 9.01
- 2020-05-05 0001628280-20-006358 — 2.02, 9.01
- 2020-02-04 0001633978-20-000002 — 2.02, 9.01
- 2019-12-12 0001193125-19-312875 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2019-12-04 0001633978-19-000075 — 8.01
- 2019-11-20 0001633978-19-000074 — 5.07
- 2019-10-31 0001633978-19-000070 — 2.02, 9.01
- 2019-08-08 0001633978-19-000068 — 2.02, 9.01
- 2019-05-08 0001633978-19-000031 — 1.01
- 2019-05-07 0001633978-19-000029 — 2.02, 9.01
- 2019-02-15 0001633978-19-000005 — 9.01 — amendment of 0001193125-18-346211
- 2019-02-08 0001193125-19-031591 — 5.02, 9.01
- 2019-02-05 0001633978-19-000001 — 2.02, 9.01
- 2018-12-10 0001193125-18-346211 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-12-06 0001633978-18-000150 — 8.01
- 2018-11-14 0001633978-18-000139 — 5.07
- 2018-11-13 0001633978-18-000136 — 3.02
- 2018-11-13 0001633978-18-000132 — 7.01, 9.01
- 2018-11-01 0001628280-18-013238 — 2.02, 9.01
- 2018-08-08 0001633978-18-000056 — 2.02, 9.01
- 2018-06-08 0001193125-18-188241 — 5.02, 9.01
- 2018-05-02 0001633978-18-000029 — 2.02, 9.01
- 2018-03-12 0001193125-18-078154 — 1.01, 2.01, 8.01, 9.01
- 2018-02-06 0001628280-18-001082 — 2.02, 9.01
- 2017-11-08 0001633978-17-000133 — 5.02, 9.01
- 2017-11-07 0001633978-17-000131 — 5.07
- 2017-11-01 0001633978-17-000117 — 2.02, 9.01
- 2017-08-09 0001633978-17-000058 — 2.02, 9.01
- 2017-05-04 0001633978-17-000035 — 2.02, 9.01
- 2017-03-08 0001193125-17-074740 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2017-03-02 0001193125-17-066769 — 8.01, 9.01
- 2017-02-07 0001633978-17-000005 — 2.02, 9.01
- 2017-01-03 0001628280-17-000018 — 4.01, 9.01
- 2016-11-09 0001628280-16-021143 — 5.02, 5.07, 9.01
- 2016-10-27 0001628280-16-020382 — 2.02, 9.01
- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2024-05-07

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001628280-24-020640:8k_2_02:1]
EX-99.1
2
lite_ex991xq3fy24.htm
EX-99.1

[0001628280-24-020640:8k_2_02:2]
Document

[0001628280-24-020640:8k_2_02:3]
NEWS RELEASE

[0001628280-24-020640:8k_2_02:4]
LUMENTUM ANNOUNCES FISCAL THIRD QUARTER 2024 FINANCIAL RESULTS

[0001628280-24-020640:8k_2_02:5]
•Net revenue of $366.5 million

[0001628280-24-020640:8k_2_02:6]
•GAAP gross margin of 16.2%; Non-GAAP gross margin of 32.6%

[0001628280-24-020640:8k_2_02:7]
•GAAP operating loss of 31.3%; Non-GAAP operating margin of 4.1%

[0001628280-24-020640:8k_2_02:8]
•GAAP diluted net loss per share of $1.88; Non-GAAP diluted net income per share of $0.29

[0001628280-24-020640:8k_2_02:9]
San Jose, Calif., May 6, 2024 – Lumentum Holdings Inc. (“Lumentum” or the “Company”) today reported results for its fiscal third quarter ended March 30, 2024.

[0001628280-24-020640:8k_2_02:10]
“Lumentum is well-positioned to capitalize on surging cloud data center demand driven by the exponentially increasing requirements of artificial intelligence,” said Alan Lowe, President and CEO. “We are making significant strides in developing new products and customer programs, and expanding production capacity to capitalize on exciting opportunities that we expect will meaningfully increase calendar 2025 revenue and beyond.”

[0001628280-24-020640:8k_2_02:11]
“Our third-quarter revenue and EPS exceeded guidance midpoints, with data center revenues achieving a record quarter. The next few quarters’ revenue will continue to be burdened by telecom customer inventory challenges as telco spending has slowed but we are highly confident in our market position and the future recovery and growth in our telecom business,” concluded Mr. Lowe.

[0001628280-24-020640:8k_2_02:12]
Fiscal Third  Quarter Highlights:

[0001628280-24-020640:8k_2_02:13]
Net revenue for the fiscal third quarter of 2024 was $366.5 million, with GAAP net loss of $127.0 million, or $1.88 per diluted share. Net revenue for the fiscal second quarter of 2024 was $366.8 million, with GAAP net loss of $99.1 million, or $1.47 per diluted share. Net revenue for the fiscal third quarter of 2023 was $383.4 million, with GAAP net loss of $39.3 million, or $0.57 per diluted share.

[0001628280-24-020640:8k_2_02:14]
Non-GAAP net income for the fiscal third quarter of 2024 was $19.6 million, or $0.29 per diluted share. Non-GAAP net income for fiscal second quarter of 2024 was $21.7 million, or $0.32 per diluted share. Non-GAAP net income for the fiscal third quarter of 2023 was $51.8 million, or $0.75 per diluted share.

[0001628280-24-020640:8k_2_02:15]
The Company held $870.9 million in total cash, cash equivalents, and short-term investments at the end of the fiscal third quarter of 2024, down $353.1 million from the end of the fiscal second quarter of 2024. In March 2024, we paid the remaining $323.1 million principal amount of the convertible notes due in 2024 in full upon maturity.

[0001628280-24-020640:8k_2_02:16]
Financial Overview – Fiscal Third Quarter Ended March 30, 2024

[0001628280-24-020640:8k_2_02:17]
|  | GAAP Results ($ in millions) |
|  | Q3 |  | Q2 |  | Q3 |  | Change |
|  | FY 2024 |  | FY 2024 |  | FY 2023 |  | Q/Q |  | Y/Y |
| Net revenue | $ | 366.5 |  |  | $ | 366.8 |  |  | $383.4 |  | (0.1)% |  | (4.4)% |
| GAAP gross margin | 16.2 | % |  | 17.4 | % |  | 29.2% |  | (120) | bps |  | (1,300) | bps |
| GAAP operating loss | (31.3) | % |  | (28.7) | % |  | (13.4)% |  | (260) | bps |  | (1,790) | bps |
|  | Non-GAAP Results ($ in millions) |
|  | Q3 |  | Q2 |  | Q3 |  | Change |
|  | FY 2024 |  | FY 2024 |  | FY 2023 |  | Q/Q |  | Y/Y |
| Net revenue | $ | 366.5 |  |  | $ | 366.8 |  |  | $383.4 |  | (0.1)% |  | (4.4)% |
| Non-GAAP gross margin | 32.6 | % |  | 32.6 | % |  | 40.8% |  | — | bps |  | (820) | bps |
| Non-GAAP operating margin | 4.1 | % |  | 3.5 | % |  | 13.4% |  | 60 | bps |  | (930) | bps |

[0001628280-24-020640:8k_2_02:18]
|  | Net Revenue by Segment ($ in millions) |  |  |  |  |
|  | Q3 |  | % of |  | Q2 |  | Q3 |  | Change |  |  |  |  |
|  | FY 2024 |  | Net Revenue |  | FY 2024 |  | FY 2023 (1) |  | Q/Q |  | Y/Y |  |  |  |  |
| Cloud & Networking | $ | 313.8 |  |  | 85.6 | % |  | $ | 286.7 |  |  | $ | 293.0 |  |  | 9.5% |  | 7.1% |  |  |  |  |
| Industrial Tech | 52.7 |  |  | 14.4 | % |  | 80.1 |  |  | 90.4 |  |  | (34.2)% |  | (41.7)% |  |  |  |  |
| Total | $ | 366.5 |  |  | 100.0 | % |  | $ | 366.8 |  |  | $ | 383.4 |  |  | (0.1)% |  | (4.4)% |  |  |  |  |

[0001628280-24-020640:8k_2_02:19]
(1) Prior period amounts have been recast to conform to the new segment structure effective the fiscal first quarter of 2024.

[0001628280-24-020640:8k_2_02:20]
The tables above provide comparisons of quarterly results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled “Use of Non-GAAP Financial Measures.”

[0001628280-24-020640:8k_2_02:21]
Business Outlook

[0001628280-24-020640:8k_2_02:22]
Lumentum expects the following for the fiscal fourth quarter 2024:

[0001628280-24-020640:8k_2_02:23]
•Net revenue in the range of $290 million to $315 million

[0001628280-24-020640:8k_2_02:24]
•Non-GAAP operating margin of (3.0%) to 1.0%

[0001628280-24-020640:8k_2_02:25]
•Non-GAAP diluted earnings per share of ($0.05) to $0.10

[0001628280-24-020640:8k_2_02:26]
These projections also exclude certain unusual expenses, including factory under-absorption, due to factory consolidations and transitions, restructuring, other synergy attainment and integration activities, and inventory reduction activities, related to prior acquisitions and the COVID-19 pandemic. These expenses are related to one-time events, and we expect these will  decline over the coming quarters. These expenses for our third fiscal quarter can be found in our GAAP to non-GAAP reconciliation tables.

[0001628280-24-020640:8k_2_02:27]
We have not provided reconciliations from GAAP to non-GAAP measures or the equivalent GAAP measure for non-GAAP measures in our outlook, as they cannot be provided without unreasonable effort. A large portion of non-GAAP adjustments, such as restructuring charges, stock-based compensation, non-GAAP income tax reconciling adjustments, acquisition related costs, and other costs and contingencies unrelated to current and future operations are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future.

[0001628280-24-020640:8k_2_02:28]
Related Announcement and Conference Call

[0001628280-24-020640:8k_2_02:29]
Lumentum will host a conference call today, May 6, 2024, at 2:00 pm PT / 5:00 pm ET to discuss its fiscal third quarter results. A live webcast of the call will be available in the Investors section of the Lumentum website at http://investor.lumentum.com. To listen to the live conference call, dial (833) 470-1428 or (404) 975-4839 and reference the conference ID 840104. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the “Events and Presentations” section concurrently with this earnings press release. Lumentum has used, and intends to continue to use, its Investor Relations website as means of disclosing material nonpublic information

[0001628280-24-020640:8k_2_02:30]
and for complying with its disclosure obligations under Regulation FD. This press release is being furnished as an exhibit to a Current Report on Form 8-K filed with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001628280-24-020640:8k_2_02:31]
About Lumentum

[0001628280-24-020640:8k_2_02:32]
Lumentum (NASDAQ: LITE) is a market-leading designer and manufacturer of innovative optical and photonic products enabling optical networking and laser applications worldwide. Lumentum optical components and subsystems are part of virtually every type of telecom, enterprise, and data center network. Lumentum lasers enable advanced manufacturing techniques and diverse applications including next-generation imaging and sensing capabilities. Lumentum is headquartered in San Jose, California with R&D, manufacturing, and sales offices worldwide. For more information, visit www.lumentum.com and follow Lumentum on LinkedIn, X (formerly known as Twitter), Facebook, Instagram and YouTube.

[0001628280-24-020640:8k_2_02:33]
Forward-Looking Statements

[0001628280-24-020640:8k_2_02:34]
Contact Information

[0001628280-24-020640:8k_2_02:35]
Investors:    Kathy Ta, (408) 750-3853; investor.relations@lumentum.com

[0001628280-24-020640:8k_2_02:36]
Media:        Noël Bilodeau, 408-439-2140; noel.bilodeau@lumentum.com

[0001628280-24-020640:8k_2_02:37]
Category:    Financial

[0001628280-24-020640:8k_2_02:38]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001628280-24-020640:8k_2_02:39]
LUMENTUM HOLDINGS INC.

[0001628280-24-020640:8k_2_02:40]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001628280-24-020640:8k_2_02:41]
(in millions, except per share data)

[0001628280-24-020640:8k_2_02:42]
(unaudited)

[0001628280-24-020640:8k_2_02:43]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |  | March 30, 2024 |  | April 1, 2023 |
| Net revenue | $ | 366.5 |  |  | $ | 383.4 |  |  | $ | 1,050.9 |  |  | $ | 1,396.2 |  |
| Cost of sales | 284.7 |  |  | 252.7 |  |  | 788.9 |  |  | 850.4 |  |
| Amortization of acquired developed intangibles | 22.3 |  |  | 18.7 |  |  | 61.8 |  |  | 66.4 |  |
| Gross profit | 59.5 |  |  | 112.0 |  |  | 200.2 |  |  | 479.4 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 77.2 |  |  | 85.4 |  |  | 229.0 |  |  | 233.9 |  |
| Selling, general and administrative | 77.7 |  |  | 76.4 |  |  | 235.8 |  |  | 280.5 |  |
| Restructuring and related charges | 19.2 |  |  | 1.6 |  |  | 36.0 |  |  | 24.8 |  |
| Total operating expenses | 174.1 |  |  | 163.4 |  |  | 500.8 |  |  | 539.2 |  |
| Loss from operations | (114.6) |  |  | (51.4) |  |  | (300.6) |  |  | (59.8) |  |
| Interest expense | (9.0) |  |  | (8.7) |  |  | (28.4) |  |  | (26.1) |  |
| Other income, net | 16.2 |  |  | 11.4 |  |  | 50.8 |  |  | 28.9 |  |
| Loss before income taxes | (107.4) |  |  | (48.7) |  |  | (278.2) |  |  | (57.0) |  |
| Income tax provision (benefit) | 19.6 |  |  | (9.4) |  |  | 15.8 |  |  | 14.4 |  |
| Net loss | $ | (127.0) |  |  | $ | (39.3) |  |  | $ | (294.0) |  |  | $ | (71.4) |  |
| Net loss per share: |  |  |  |  |  |  |  |
| Basic | $ | (1.88) |  |  | $ | (0.57) |  |  | $ | (4.38) |  |  | $ | (1.05) |  |
| Diluted | $ | (1.88) |  |  | $ | (0.57) |  |  | $ | (4.38) |  |  | $ | (1.05) |  |
| Shares used to compute net loss per share: |  |  |  |  |  |  |  |
| Basic | 67.5 |  |  | 68.6 |  |  | 67.1 |  |  | 68.3 |  |
| Diluted | 67.5 |  |  | 68.6 |  |  | 67.1 |  |  | 68.3 |  |

[0001628280-24-020640:8k_2_02:44]
LUMENTUM HOLDINGS INC.

[0001628280-24-020640:8k_2_02:45]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-24-020640:8k_2_02:46]
(in millions, except per share data)

[0001628280-24-020640:8k_2_02:47]
(unaudited)

[0001628280-24-020640:8k_2_02:48]
|  | March 30, 2024 |  | July 1, 2023 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 425.0 |  |  | $ | 859.0 |  |
| Short-term investments | 445.9 |  |  | 1,154.6 |  |
| Accounts receivable, net | 229.8 |  |  | 246.1 |  |
| Inventories | 420.7 |  |  | 408.6 |  |
| Prepayments and other current assets | 128.6 |  |  | 109.6 |  |
| Total current assets | 1,650.0 |  |  | 2,777.9 |  |
| Property, plant and equipment, net | 578.7 |  |  | 489.5 |  |
| Operating lease right-of-use assets, net | 76.7 |  |  | 77.3 |  |
| Goodwill | 1,055.9 |  |  | 695.1 |  |
| Other intangible assets, net | 688.5 |  |  | 459.2 |  |
| Deferred tax asset | 139.2 |  |  | 116.3 |  |
| Other non-current assets | 15.5 |  |  | 16.8 |  |
| Total assets | $ | 4,204.5 |  |  | $ | 4,632.1 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 133.4 |  |  | $ | 169.4 |  |
| Accrued payroll and related expenses | 40.4 |  |  | 39.4 |  |
| Accrued expenses | 61.7 |  |  | 51.2 |  |
| Convertible notes, current | — |  |  | 311.6 |  |
| Operating lease liabilities, current | 13.8 |  |  | 14.4 |  |
| Other current liabilities | 68.3 |  |  | 47.8 |  |
| Total current liabilities | 317.6 |  |  | 633.8 |  |
| Convertible notes, non-current | 2,502.4 |  |  | 2,500.0 |  |
| Operating lease liabilities, non-current | 47.3 |  |  | 47.7 |  |
| Deferred tax liability | 61.7 |  |  | 3.4 |  |
| Other non-current liabilities | 98.8 |  |  | 91.4 |  |
| Total liabilities | 3,027.8 |  |  | 3,276.3 |  |
| Stockholders’ equity: |  |  |  |
| Common stock, $0.001 par value, 990 authorized shares, 67.6 and 66.4 shares issued and outstanding as of March 30, 2024 and July 1, 2023, respectively | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital | 1,802.4 |  |  | 1,692.2 |  |
| Accumulated deficit | (634.6) |  |  | (340.6) |  |
| Accumulated other comprehensive income | 8.8 |  |  | 4.1 |  |
| Total stockholders’ equity | 1,176.7 |  |  | 1,355.8 |  |
| Total liabilities and stockholders’ equity | $ | 4,204.5 |  |  | $ | 4,632.1 |  |

[0001628280-24-020640:8k_2_02:49]
Use of Non-GAAP Financial Measures

[0001628280-24-020640:8k_2_02:50]
In this press release, Lumentum provides investors with certain non-GAAP financial measures: gross profit, gross margin, research and development expense, selling, general and administrative expense, operating margin, income from operations, interest and other income (expense), net, income before income taxes, provision for income taxes, net income (loss), and net income (loss) per share on a non-GAAP basis, as well as the non-GAAP measures of EBITDA and Adjusted EBITDA. Lumentum believes this non-GAAP financial information provides additional insight into the Company’s on-going business operations and results, as well as cash generation, and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons. In addition, the Company believes that providing certain of these measures allows investors to better understand the Company’s operating performance and cash flows and, importantly, to evaluate the methodology and information used by management to monitor, manage, evaluate and measure the Company’s business, results of operations, and cash flows. However, these measures may be different from non-GAAP measures used by other companies, limiting their usefulness for comparison purposes. The non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP. Investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future. Further, these non-GAAP financial measures may not be comparable to similarly titled measurements reported by other companies.

[0001628280-24-020640:8k_2_02:51]
Our non-GAAP measures used in this press release exclude (i) stock-based compensation, (ii) acquisition related stock-based compensation, (iii) acquisition related costs, (iv) amortization of acquired intangibles, (v) amortization of acquired inventory fair value adjustments, (vi) restructuring and related charges, (vii) foreign exchange (gains) losses, net, (viii) non-cash interest expense on convertible notes, (ix) gain on repurchase of convertible notes, (x) non-recurring expenses related to litigation matters, (xi) intangible assets write-off, (xii) integration related costs, (xiii) abnormal excess capacity, (xiv) foreign exchange gains and losses, (xv) non-GAAP income tax reconciling adjustments, and (xvi) other (gains) charges related to non-recurring activities.

[0001628280-24-020640:8k_2_02:52]
We utilize a long-term projected non-GAAP tax rate to compute our non-GAAP income tax provision. The long-term projected non-GAAP tax rate is based on a multi-year projection of our estimated annual GAAP income tax forecast, adjusted to account for the tax effect of non-GAAP pretax adjustments as well as the effects of significant non-recurring and period specific tax items. Our non-GAAP tax provision for the fiscal third quarter of 2024 is 14.5%. The difference between our GAAP income tax provision and our non-GAAP income tax provision is presented as non-GAAP income tax reconciling adjustments.

[0001628280-24-020640:8k_2_02:53]
A quantitative reconciliation between GAAP and non-GAAP financial data with respect to historical periods is included in the supplemental financial table attached to this press release.

[0001628280-24-020640:8k_2_02:54]
LUMENTUM HOLDINGS INC.

[0001628280-24-020640:8k_2_02:55]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001628280-24-020640:8k_2_02:56]
(in millions, except per share data)

[0001628280-24-020640:8k_2_02:57]
(unaudited)

[0001628280-24-020640:8k_2_02:58]
|  | Three Months Ended |  | Nine Months Ended |  |
|  | March 30, 2024 |  | December 30, 2023 |  | April 1, 2023 |  | March 30, 2024 |  | April 1, 2023 |  |
| Gross profit on GAAP basis | $ | 59.5 |  |  | $ | 64.0 |  |  | $ | 112.0 |  |  | $ | 200.2 |  |  | $ | 479.4 |  |  |
| Stock-based compensation | 8.5 |  |  | 9.0 |  |  | 6.9 |  |  | 23.5 |  |  | 19.1 |  |  |
| Amortization of acquired intangibles | 22.3 |  |  | 21.5 |  |  | 18.7 |  |  | 61.8 |  |  | 66.4 |  |  |
| Amortization of acquired inventory fair value adjustments | 4.9 |  |  | 3.4 |  |  | 3.6 |  |  | 8.3 |  |  | 17.8 |  |  |
| Integration related costs | 6.4 |  |  | 10.1 |  |  | 6.7 |  |  | 19.9 |  |  | 9.5 |  |  |
| Abnormal excess capacity (1) | 11.9 |  |  | 1.8 |  |  | — |  |  | 13.7 |  |  | — |  |  |
| Other charges, net (2) | 5.8 |  |  | 9.9 |  |  | 8.4 |  |  | 22.3 |  |  | 35.2 |  |  |
| Gross profit on non-GAAP basis | $ | 119.3 |  |  | $ | 119.7 |  |  | $ | 156.3 |  |  | $ | 349.7 |  |  | $ | 627.4 |  |  |
| Gross margin on non-GAAP basis | 32.6 | % |  | 32.6 | % |  | 40.8 | % |  | 33.3 | % |  | 44.9 | % |  |
| Research and development on GAAP basis | $ | 77.2 |  |  | $ | 78.3 |  |  | $ | 85.4 |  |  | $ | 229.0 |  |  | 233.9 |  |  |
| Stock-based compensation | (9.8) |  |  | (10.0) |  |  | (11.0) |  |  | (30.1) |  |  | (31.2) |  |  |
| Amortization of acquired intangibles | (0.4) |  |  | (0.4) |  |  | — |  |  | (1.1) |  |  | — |  |  |
| Acquisition related costs | — |  |  | (0.1) |  |  | — |  |  | (0.4) |  |  | — |  |  |
| Integration related costs (reversal) | (0.4) |  |  | 0.6 |  |  | (0.5) |  |  | (0.7) |  |  | (1.3) |  |  |
| Write-off of in-process research and development intangible assets | — |  |  | — |  |  | (11.5) |  |  | — |  |  | (11.5) |  |  |
| Other charges, net | (0.4) |  |  | (0.1) |  |  | (0.3) |  |  | (1.2) |  |  | (2.6) |  |  |
| Research and development on non-GAAP basis | $ | 66.2 |  |  | $ | 68.3 |  |  | $ | 62.1 |  |  | $ | 195.5 |  |  | $ | 187.3 |  |  |
| Selling, general and administrative on GAAP basis | $ | 77.7 |  |  | $ | 85.1 |  |  | $ | 76.4 |  |  | $ | 235.8 |  |  | $ | 280.5 |  |  |
| Stock-based compensation | (13.3) |  |  | (15.6) |  |  | (15.2) |  |  | (44.7) |  |  | (54.1) |  |  |
| Stock-based compensation - acquisition related | — |  |  | — |  |  | — |  |  | — |  |  | (11.9) |  |  |
| Amortization of acquired intangibles | (19.4) |  |  | (15.7) |  |  | (11.3) |  |  | (45.8) |  |  | (31.9) |  |  |
| Acquisition related costs | (0.5) |  |  | (8.9) |  |  | — |  |  | (13.1) |  |  | (16.2) |  |  |
| Integration related costs | (3.4) |  |  | (2.1) |  |  | (3.4) |  |  | (9.1) |  |  | (8.4) |  |  |
| Litigation matters | — |  |  | — |  |  | — |  |  | — |  |  | (7.8) |  |  |
| Other charges, net (2) | (3.0) |  |  | (4.4) |  |  | (3.7) |  |  | (7.5) |  |  | (15.6) |  |  |
| Selling, general and administrative on non-GAAP basis | $ | 38.1 |  |  | $ | 38.4 |  |  | $ | 42.8 |  |  | $ | 115.6 |  |  | $ | 134.6 |  |  |
| Loss from operations on GAAP basis | $ | (114.6) |  |  | $ | (105.2) |  |  | $ | (51.4) |  |  | $ | (300.6) |  |  | $ | (59.8) |  |  |
| Stock-based compensation | 31.6 |  |  | 34.6 |  |  | 33.1 |  |  | 98.3 |  |  | 104.4 |  |  |
| Stock-based compensation - acquisition related | — |  |  | — |  |  | — |  |  | — |  |  | 11.9 |  |  |
| Amortization of acquired intangibles | 42.1 |  |  | 37.6 |  |  | 30.0 |  |  | 108.7 |  |  | 98.3 |  |  |
| Amortization of acquired inventory fair value adjustments | 4.9 |  |  | 3.4 |  |  | 3.6 |  |  | 8.3 |  |  | 17.8 |  |  |
| Acquisition related costs | 0.5 |  |  | 9.0 |  |  | — |  |  | 13.5 |  |  | 16.2 |  |  |
| Integration related costs | 10.2 |  |  | 11.6 |  |  | 10.6 |  |  | 29.7 |  |  | 19.2 |  |  |
| Abnormal excess capacity (1) | 11.9 |  |  | 1.8 |  |  | — |  |  | 13.7 |  |  | — |  |  |
| Restructuring and related charges | 19.2 |  |  | 5.8 |  |  | 1.6 |  |  | 36.0 |  |  | 24.8 |  |  |

[0001628280-24-020640:8k_2_02:59]
| Write-off of in-process research and development intangible assets | — |  |  | — |  |  | 11.5 |  |  | — |  |  | 11.5 |  |  |
| Litigation matters | — |  |  | — |  |  | — |  |  | — |  |  | 7.8 |  |  |
| Other charges, net (2) | 9.2 |  |  | 14.4 |  |  | 12.4 |  |  | 31.0 |  |  | 53.4 |  |  |
| Income from operations on non-GAAP basis | $ | 15.0 |  |  | $ | 13.0 |  |  | $ | 51.4 |  |  | $ | 38.6 |  |  | $ | 305.5 |  |  |
| Operating margin on non-GAAP basis | 4.1 | % |  | 3.5 | % |  | 13.4 | % |  | 3.7 | % |  | 21.9 | % |  |
| Interest and other income, net on GAAP basis | $ | 7.2 |  |  | $ | 3.7 |  |  | $ | 2.7 |  |  | $ | 22.4 |  |  | $ | 2.8 |  |  |
| Foreign exchange (gains) losses, net | (3.7) |  |  | 3.8 |  |  | 0.5 |  |  | 0.5 |  |  | (4.4) |  |  |
| Non-cash interest expense on convertible notes and other income and expenses, net | 4.5 |  |  | 4.8 |  |  | 6.0 |  |  | 14.2 |  |  | 17.9 |  |  |
| Interest and other income, net on non-GAAP basis | $ | 8.0 |  |  | $ | 12.3 |  |  | $ | 9.2 |  |  | $ | 37.1 |  |  | $ | 16.3 |  |  |
| Loss before income taxes on GAAP basis | $ | (107.4) |  |  | $ | (101.5) |  |  | $ | (48.7) |  |  | $ | (278.2) |  |  | $ | (57.0) |  |  |
| Stock-based compensation | 31.6 |  |  | 34.6 |  |  | 33.1 |  |  | 98.3 |  |  | 104.4 |  |  |
| Stock-based compensation - acquisition related | — |  |  | — |  |  | — |  |  | — |  |  | 11.9 |  |  |
| Acquisition related costs | 0.5 |  |  | 9.0 |  |  | — |  |  | 13.5 |  |  | 16.2 |  |  |
| Integration related costs | 10.2 |  |  | 11.6 |  |  | 10.6 |  |  | 29.7 |  |  | 19.2 |  |  |
| Abnormal excess capacity (1) | 11.9 |  |  | 1.8 |  |  | — |  |  | 13.7 |  |  | — |  |  |
| Amortization of acquired intangibles | 42.1 |  |  | 37.6 |  |  | 30.0 |  |  | 108.7 |  |  | 98.3 |  |  |
| Amortization of acquired inventory fair value adjustments | 4.9 |  |  | 3.4 |  |  | 3.6 |  |  | 8.3 |  |  | 17.8 |  |  |
| Restructuring and related charges | 19.2 |  |  | 5.8 |  |  | 1.6 |  |  | 36.0 |  |  | 24.8 |  |  |
| Litigation matters | — |  |  | — |  |  | — |  |  | — |  |  | 7.8 |  |  |
| Write-off of in-process research and development intangible assets | — |  |  | — |  |  | 11.5 |  |  | — |  |  | 11.5 |  |  |
| Foreign exchange (gains) losses, net | (3.7) |  |  | 3.8 |  |  | 0.5 |  |  | 0.5 |  |  | (4.4) |  |  |
| Non-cash interest expense on convertible notes and other income and expenses, net | 4.5 |  |  | 4.8 |  |  | 6.0 |  |  | 14.2 |  |  | 17.9 |  |  |
| Other charges, net (2) | 9.2 |  |  | 14.4 |  |  | 12.4 |  |  | 31.0 |  |  | 53.4 |  |  |
| Income before income taxes on non-GAAP basis | $ | 23.0 |  |  | $ | 25.3 |  |  | $ | 60.6 |  |  | $ | 75.7 |  |  | $ | 321.8 |  |  |
| Income tax provision (benefit) on GAAP basis | $ | 19.6 |  |  | $ | (2.4) |  |  | $ | (9.4) |  |  | $ | 15.8 |  |  | $ | 14.4 |  |  |
| Non-GAAP income tax reconciling adjustments | (16.2) |  |  | 6.0 |  |  | 18.2 |  |  | (4.8) |  |  | 32.3 |  |  |
| Income tax provision on non-GAAP basis | $ | 3.4 |  |  | $ | 3.6 |  |  | $ | 8.8 |  |  | $ | 11.0 |  |  | $ | 46.7 |  |  |
| Net loss on GAAP basis | $ | (127.0) |  |  | $ | (99.1) |  |  | $ | (39.3) |  |  | $ | (294.0) |  |  | $ | (71.4) |  |  |
| Stock-based compensation | 31.6 |  |  | 34.6 |  |  | 33.1 |  |  | 98.3 |  |  | 104.4 |  |  |
| Stock-based compensation - acquisition related | — |  |  | — |  |  | — |  |  | — |  |  | 11.9 |  |  |
| Acquisition related costs | 0.5 |  |  | 9.0 |  |  | — |  |  | 13.5 |  |  | 16.2 |  |  |
| Integration related costs | 10.2 |  |  | 11.6 |  |  | 10.6 |  |  | 29.7 |  |  | 19.2 |  |  |
| Abnormal excess capacity (1) | 11.9 |  |  | 1.8 |  |  | — |  |  | 13.7 |  |  | — |  |  |
| Amortization of acquired intangibles | 42.1 |  |  | 37.6 |  |  | 30.0 |  |  | 108.7 |  |  | 98.3 |  |  |
| Amortization of acquired inventory fair value adjustments | 4.9 |  |  | 3.4 |  |  | 3.6 |  |  | 8.3 |  |  | 17.8 |  |  |
| Restructuring and related charges | 19.2 |  |  | 5.8 |  |  | 1.6 |  |  | 36.0 |  |  | 24.8 |  |  |
| Write-off of in-process research and development intangible assets | — |  |  | — |  |  | 11.5 |  |  | — |  |  | 11.5 |  |  |
| Litigation matters | — |  |  | — |  |  | — |  |  | — |  |  | 7.8 |  |  |
| Foreign exchange (gains) losses, net | (3.7) |  |  | 3.8 |  |  | 0.5 |  |  | 0.5 |  |  | (4.4) |  |  |

[0001628280-24-020640:8k_2_02:60]
| Non-cash interest expense on convertible notes and other income and expenses, net | 4.5 |  |  | 4.8 |  |  | 6.0 |  |  | 14.2 |  |  | 17.9 |  |  |
| Non-GAAP income tax reconciling adjustments | 16.2 |  |  | (6.0) |  |  | (18.2) |  |  | 4.8 |  |  | (32.3) |  |  |
| Other charges, net (2) | 9.2 |  |  | 14.4 |  |  | 12.4 |  |  | 31.0 |  |  | 53.4 |  |  |
| Net income on non-GAAP basis | $ | 19.6 |  |  | $ | 21.7 |  |  | $ | 51.8 |  |  | $ | 64.7 |  |  | $ | 275.1 |  |  |
| Net income per share on non-GAAP basis | $ | 0.29 |  |  | $ | 0.32 |  |  | $ | 0.75 |  |  | $ | 0.96 |  |  | $ | 3.97 |  |  |
| Shares used in per share calculation - diluted on GAAP basis | 67.5 |  |  | 67.2 |  |  | 68.6 |  |  | 67.1 |  |  | 68.3 |  |  |
| Non-GAAP adjustment (3) | 0.6 |  |  | 0.2 |  |  | 0.1 |  |  | 0.4 |  |  | 1.0 |  |  |
| Shares used in per share calculation - diluted on non-GAAP basis | 68.1 |  |  | 67.4 |  |  | 68.7 |  |  | 67.5 |  |  | 69.3 |  |  |

[0001628280-24-020640:8k_2_02:61]
(1) Abnormal excess capacity for the three months ended March 30, 2024 represents excess capacity attributable to a near-term reduction in our manufacturing production, primarily driven by our non-recurring inventory reduction effort following the disruptions in the supply chain due to the COVID-19 pandemic and factory consolidation efforts.

[0001628280-24-020640:8k_2_02:62]
(2) Other charges, net for the three months ended March 30, 2024 primarily relate to $4.8 million of non-recurring legal and tax related fees and $1.7 million of net excess and obsolete inventory, offset by various miscellaneous gains. The excess and obsolete inventory charges relate to charges that are not attributable to our operating segments due to their unusual nature, primarily those charges driven by U.S. trade restrictions whereby we are no longer able to sell certain products to one of our customers, as well as excess and obsolete inventory due to factory consolidation efforts.

[0001628280-24-020640:8k_2_02:63]
Other charges, net for the nine months ended March 30, 2024 primarily relate to $10.9 million of net excess and obsolete inventory, $10.2 million of non-recurring legal and tax related fees, and $4.4 million of incremental costs of sales related to components previously acquired from various brokers to satisfy customer demand, offset by various miscellaneous gains. The excess and obsolete inventory charges relate to charges that are not attributable to our operating segments due to their unusual nature, primarily those charges driven by U.S. trade restrictions whereby we are no longer able to sell certain products to one of our customers.

[0001628280-24-020640:8k_2_02:64]
(3) Shares used for net income per share on non-GAAP basis include incremental dilutive shares that would occur upon conversion of our convertible notes assuming we settle the face value of the notes in cash as the Company intends, and shares related to restricted stock units (“RSUs”) and stock options and shares issuable under our Employee Stock Purchase Plan that are anti-dilutive on GAAP basis.

[0001628280-24-020640:8k_2_02:65]
LUMENTUM HOLDINGS INC.

[0001628280-24-020640:8k_2_02:66]
RECONCILIATION OF GAAP NET INCOME TO ADJUSTED EBITDA

[0001628280-24-020640:8k_2_02:67]
(in millions, except per share data)

[0001628280-24-020640:8k_2_02:68]
(unaudited)

[0001628280-24-020640:8k_2_02:69]
|  | Three Months Ended |  |  |  | Nine Months Ended |
|  | March 30, 2024 |  |  |  | December 30, 2023 |  | April 1, 2023 |  |  |  |  |  | March 30, 2024 |  | April 1, 2023 |
| GAAP net loss | $ | (127.0) |  |  |  |  | $ | (99.1) |  |  | $ | (39.3) |  |  |  |  |  |  | $ | (294.0) |  |  | $ | (71.4) |  |
| Interest and other expense, net | (7.2) |  |  |  |  | (3.7) |  |  | (2.7) |  |  |  |  |  |  | (22.4) |  |  | (2.8) |  |
| Income tax provision (benefit) | 19.6 |  |  |  |  | (2.4) |  |  | (9.4) |  |  |  |  |  |  | 15.8 |  |  | 14.4 |  |
| Depreciation | 27.0 |  |  |  |  | 27.2 |  |  | 27.7 |  |  |  |  |  |  | 82.4 |  |  | 78.6 |  |
| Amortization of acquired intangibles | 42.1 |  |  |  |  | 37.6 |  |  | 30.0 |  |  |  |  |  |  | 108.7 |  |  | 98.3 |  |
| EBITDA | (45.5) |  |  |  |  | (40.4) |  |  | 6.3 |  |  |  |  |  |  | (109.5) |  |  | 117.1 |  |
| Amortization of inventory fair value adjustments | 4.9 |  |  |  |  | 3.4 |  |  | 3.6 |  |  |  |  |  |  | 8.3 |  |  | 17.8 |  |
| Restructuring and related charges | 19.2 |  |  |  |  | 5.8 |  |  | 1.6 |  |  |  |  |  |  | 36.0 |  |  | 24.8 |  |
| Stock-based compensation | 31.6 |  |  |  |  | 34.6 |  |  | 33.1 |  |  |  |  |  |  | 98.3 |  |  | 116.3 |  |
| Acquisition related costs | 0.5 |  |  |  |  | 9.0 |  |  | — |  |  |  |  |  |  | 13.5 |  |  | 16.2 |  |
| Integration related costs | 10.2 |  |  |  |  | 11.6 |  |  | 10.6 |  |  |  |  |  |  | 29.7 |  |  | 19.2 |  |
| Write-off of in-process research and development intangible assets | — |  |  |  |  | — |  |  | 11.5 |  |  |  |  |  |  | — |  |  | 11.5 |  |
| Abnormal excess capacity | 11.9 |  |  |  |  | 1.8 |  |  | — |  |  |  |  |  |  | 13.7 |  |  | — |  |
| Other charges (gains), net | 8.2 |  |  |  |  | 13.2 |  |  | 10.3 |  |  |  |  |  |  | 24.6 |  |  | 49.4 |  |
| Adjusted EBITDA | $ | 41.0 |  |  |  |  | $ | 39.0 |  |  | $ | 77.0 |  |  |  |  |  |  | $ | 114.6 |  |  | $ | 372.3 |  |
