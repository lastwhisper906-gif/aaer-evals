# LITE MD&A — 0001628280-24-020767


## mdna

[0001628280-24-020767:mdna:1]
[same as prior period, unchanged from 0001628280-24-003796:mdna:1]

[0001628280-24-020767:mdna:2]
[same as prior period, unchanged from 0001628280-24-003796:mdna:2]

[0001628280-24-020767:mdna:3]
[same as prior period, unchanged from 0001628280-24-003796:mdna:3]

[0001628280-24-020767:mdna:4]
[same as prior period, unchanged from 0001628280-24-003796:mdna:4]

[0001628280-24-020767:mdna:5]
[same as prior period, unchanged from 0001628280-24-003796:mdna:5]

[0001628280-24-020767:mdna:6]
[same as prior period, unchanged from 0001628280-24-003796:mdna:6]

[0001628280-24-020767:mdna:7]
[same as prior period, unchanged from 0001628280-24-003796:mdna:7]

[0001628280-24-020767:mdna:8]
[same as prior period, unchanged from 0001628280-24-003796:mdna:8]

[0001628280-24-020767:mdna:9]
[same as prior period, unchanged from 0001628280-24-003796:mdna:9]

[0001628280-24-020767:mdna:10]
[same as prior period, unchanged from 0001628280-24-003796:mdna:10]

[0001628280-24-020767:mdna:11]
[same as prior period, unchanged from 0001628280-24-003796:mdna:11]

[0001628280-24-020767:mdna:12]
Our Cloud & Networking products include a comprehensive portfolio of optical and photonic components, modules, and subsystems supplied to network operator and network equipment manufacturer customers building cloud data center infrastructure, including that for artificial intelligence and machine learning (“AI/ML”) and data center interconnect (“DCI”) applications, and communications service provider networks, including in access (local), metro (intracity), long-haul (city-to-city and worldwide), and submarine (undersea) network infrastructure. Our Cloud & Networking products also support network equipment manufacturers building enterprise network infrastructure, including storage-area networks (“SANs”), local-area networks (“LANs”) and wide-area networks (“WANs”). Demand for our Cloud & Networking products is driven by the continual growth in network capacity required for cloud computing and services, including for AI/ML, streaming video and video conferencing, wireless and mobile devices, and internet of things (“IoT”).

[0001628280-24-020767:mdna:13]
[same as prior period, unchanged from 0001628280-24-003796:mdna:13]

[0001628280-24-020767:mdna:14]
Our Industrial Tech products include solid-state lasers, kilowatt-class fiber lasers, diode lasers, and gas lasers, which address applications in numerous end-markets. In the consumer end-market, our laser light sources are integrated into our customers’ 3D sensing cameras, which are used in mobile devices, payment kiosks, and other consumer electronics devices to enable applications including biometric identification, computational photography and virtual and augmented reality. In the automotive end-market, our lasers are used in our customers’ LiDAR and other optical sensor devices, which are increasingly being used in advanced driver assistance systems (“ADAS”) and in-cabin driver and occupant monitoring systems. In the industrial manufacturing end-market, our lasers are incorporated into our customers’ manufacturing machine tools used for the precision processing of materials in a range of industries including semiconductor device and microelectronics fabrication, electric vehicle and battery production, metal cutting and welding, and advanced manufacturing. Our products can also be used in the industrial end-market in imaging and sensing systems for process feedback and control, quality assurance, and waste reduction. Adoption of our products in the industrial end-market is driven by the needs of customers to advance semiconductor and microelectronics industry roadmaps, and by Industry 4.0/5.0 trends, including increasing manufacturing precision and flexibility and reducing waste and environmental impact. Demand for our products in the industrial end-market is driven by end-customer investments in manufacturing capacity. Our lasers also address certain semiconductor inspection and life-science applications.

[0001628280-24-020767:mdna:15]
[same as prior period, unchanged from 0001628280-24-003796:mdna:16]

[0001628280-24-020767:mdna:16]
On October 29, 2023, Lumentum and Cloud Light Technology Limited (“Cloud Light”) entered into a definitive merger agreement (the “Merger Agreement”). On November 7, 2023 (the “Closing date”), we completed the acquisition of Cloud Light. Cloud Light designs, markets, and manufactures advanced optical modules for data center interconnect applications. The acquisition enables us to be well-positioned to serve the growing needs of cloud & networking customers, particularly those focused on optimizing their data center infrastructure for the demands of AI/ML. On the Closing date, we paid $705.0 million of total cash consideration to Cloud Light. Additionally, each of Cloud Light’s outstanding options was exchanged for a combination of cash and options to acquire Lumentum common stock having equivalent value (the “replacement options”). These replacement options have a total fair value of $38.9 million as of the Closing date, of which $23.5 million attributed to pre-acquisition service is recorded as part of purchase price consideration and the remaining $15.4 million is recorded as post-acquisition stock-based compensation expense over the vesting period of three years from the acquisition Closing date. We also incurred a total of $9.4 million of merger-related costs, representing professional and other direct acquisition costs, which was recorded as general and administrative expense in the consolidated statement of operations. Refer to “Note 4. Business Combinations” in the notes to condensed consolidated financial statements.

[0001628280-24-020767:mdna:17]
[same as prior period, unchanged from 0001628280-24-003796:mdna:18]

[0001628280-24-020767:mdna:18]
Supply Chain and Inventory Management

[0001628280-24-020767:mdna:19]
[same as prior period, unchanged from 0001628280-24-003796:mdna:20]

[0001628280-24-020767:mdna:20]
In addition, in response to component shortages, certain of our customers accumulated inventory that they are now managing down as supply conditions improve. Accordingly, customer orders have declined in recent periods and certain customers have not taken the shipments we had originally projected due to their inventory management. As customers manage their inventory down, our revenue has declined and our margins are adversely impacted as we are not able to fully recover costs, such as underutilized manufacturing capacity, associated with the forecasted demand and we may incur excess and obsolescence charges from unsold inventory. In the fiscal third quarter of 2024, inventory reduced by $51.0 million compared to the fiscal second quarter of 2024, due to our focused effort to manage our production and inventory levels. We plan to continue to manage down our inventory levels during the next several quarters.

[0001628280-24-020767:mdna:21]
[same as prior period, unchanged from 0001628280-24-003796:mdna:22]

[0001628280-24-020767:mdna:22]
[same as prior period, unchanged from 0001628280-24-003796:mdna:23]

[0001628280-24-020767:mdna:23]
[same as prior period, unchanged from 0001628280-24-003796:mdna:24]

[0001628280-24-020767:mdna:24]
[same as prior period, unchanged from 0001628280-24-003796:mdna:25]

[0001628280-24-020767:mdna:25]
[same as prior period, unchanged from 0001628280-24-003796:mdna:26]

[0001628280-24-020767:mdna:26]
[same as prior period, unchanged from 0001628280-24-003796:mdna:27]

[0001628280-24-020767:mdna:27]
[same as prior period, unchanged from 0001628280-24-003796:mdna:28]

[0001628280-24-020767:mdna:28]
[same as prior period, unchanged from 0001628280-24-003796:mdna:29]

[0001628280-24-020767:mdna:29]
Management’s Discussion and Analysis of Financial Condition and Results of Operations contained in Part II, Item 7 of our Annual Report on Form 10-K for our fiscal year ended July 1, 2023 provides a complete discussion of our critical accounting policies and estimates. There have been no changes to these policies during the three and nine months ended March 30, 2024.

[0001628280-24-020767:mdna:30]
Recently Issued Accounting Pronouncements

[0001628280-24-020767:mdna:31]
Refer to “Note 2. Recently Issued Accounting Pronouncements” in the notes to condensed consolidated financial statements.

[0001628280-24-020767:mdna:32]
[same as prior period, unchanged from 0001628280-24-003796:mdna:33]

[0001628280-24-020767:mdna:33]
[same as prior period, unchanged from 0001628280-24-003796:mdna:34]

[0001628280-24-020767:mdna:34]
[same as prior period, unchanged from 0001628280-24-003796:mdna:35]

[0001628280-24-020767:mdna:35]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |  | March 30, 2024 |  | April 1, 2023 |
| Segment net revenue: |  |  |  |  |  |  |  |
| Cloud & Networking | 85.6 | % |  | 76.4 | % |  | 79.0 | % |  | 74.2 | % |
| Industrial Tech | 14.4 |  |  | 23.6 | % |  | 21.0 |  |  | 25.8 | % |
| Net revenue | 100.0 |  |  | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of sales | 77.7 |  |  | 65.9 |  |  | 75.1 |  |  | 60.9 |  |
| Amortization of acquired developed intangibles | 6.1 |  |  | 4.9 |  |  | 5.9 |  |  | 4.8 |  |
| Gross profit | 16.2 |  |  | 29.2 |  |  | 19.1 |  |  | 34.3 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 21.1 |  |  | 22.3 |  |  | 21.8 |  |  | 16.8 |  |
| Selling, general and administrative | 21.2 |  |  | 19.9 |  |  | 22.4 |  |  | 20.1 |  |
| Restructuring and related charges | 5.2 |  |  | 0.4 |  |  | 3.4 |  |  | 1.8 |  |
| Total operating expenses | 47.5 |  |  | 42.6 |  |  | 47.7 |  |  | 38.6 |  |
| Loss from operations | (31.3) |  |  | (13.4) |  |  | (28.6) |  |  | (4.3) |  |
| Interest expense | (2.5) |  |  | (2.3) |  |  | (2.7) |  |  | (1.9) |  |
| Other income, net | 4.4 |  |  | 3.0 |  |  | 4.8 |  |  | 2.1 |  |
| Loss before income taxes | (29.3) |  |  | (12.7) |  |  | (26.5) |  |  | (4.1) |  |
| Income tax provision (benefit) | 5.3 |  |  | (2.5) |  |  | 1.5 |  |  | 1.0 |  |
| Net loss | (34.7) | % |  | (10.3) | % |  | (28.0) | % |  | (5.1) | % |

[0001628280-24-020767:mdna:36]
[same as prior period, unchanged from 0001628280-24-003796:mdna:57]

[0001628280-24-020767:mdna:37]
Financial data for the three and nine months ended March 30, 2024

[0001628280-24-020767:mdna:38]
[same as prior period, unchanged from 0001628280-24-003796:mdna:39]

[0001628280-24-020767:mdna:39]
|  | Three Months Ended |  | Nine Months Ended |  |  |  |  |
|  | March 30, 2024 |  | April 1, 2023 |  | Change |  | Percentage Change |  | March 30, 2024 |  | April 1, 2023 |  | Change |  | Percentage Change |
| Segment net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cloud & Networking | $ | 313.8 |  |  | 293.0 |  |  | $ | 20.8 |  |  | 7.1 | % |  | $ | 830.2 |  |  | $ | 1,036.0 |  |  | $ | (205.8) |  |  | (19.9) | % |
| Industrial Tech | 52.7 |  |  | 90.4 |  |  | (37.7) |  |  | (41.7) | % |  | 220.7 |  |  | 360.2 |  |  | (139.5) |  |  | (38.7) | % |
| Net revenue | $ | 366.5 |  |  | $ | 383.4 |  |  | $ | (16.9) |  |  | (4.4) | % |  | $ | 1,050.9 |  |  | $ | 1,396.2 |  |  | $ | (345.3) |  |  | (24.7) | % |
| Gross profit | $ | 59.5 |  |  | $ | 112.0 |  |  | $ | (52.5) |  |  | (46.9) | % |  | $ | 200.2 |  |  | $ | 479.4 |  |  | $ | (279.2) |  |  | (58.2) | % |
| Gross margin | 16.2 | % |  | 29.2 | % |  |  |  |  |  | 19.1 | % |  | 34.3 | % |  |  |  |  |
| Research and development | $ | 77.2 |  |  | $ | 85.4 |  |  | $ | (8.2) |  |  | (9.6) | % |  | $ | 229.0 |  |  | $ | 233.9 |  |  | $ | (4.9) |  |  | (2.1) | % |
| Percentage of net revenue | 21.1 | % |  | 22.3 | % |  |  |  |  |  | 21.8 | % |  | 16.8 | % |  |  |  |  |
| Selling, general and administrative | $ | 77.7 |  |  | $ | 76.4 |  |  | $ | 1.3 |  |  | 1.7 | % |  | $ | 235.8 |  |  | $ | 280.5 |  |  | $ | (44.7) |  |  | (15.9) | % |
| Percentage of net revenue | 21.2 | % |  | 19.9 | % |  |  |  |  |  | 22.4 | % |  | 20.1 | % |  |  |  |  |
| Restructuring and related charges | $ | 19.2 |  |  | $ | 1.6 |  |  | $ | 17.6 |  |  | N/A |  | $ | 36.0 |  |  | $ | 24.8 |  |  | $ | 11.2 |  |  | 45.2 | % |
| Percentage of net revenue | 5.2 | % |  | 0.4 | % |  |  |  |  |  | 3.4 | % |  | 1.8 | % |  |  |  |  |

[0001628280-24-020767:mdna:40]
[same as prior period, unchanged from 0001628280-24-003796:mdna:41]

[0001628280-24-020767:mdna:41]
Net revenue decreased by $16.9 million, or 4.4%, during the three months ended March 30, 2024 compared to the three months ended April 1, 2023, driven by a  $37.7 million decrease in Industrial Tech revenue, offset by a $20.8 million increase in Cloud & Networking revenue. The decrease in Industrial Tech net revenue is primarily due to higher market competition, which reflects share normalization in the market, as well as reduction in demand associated with a build-up of inventory and resulting inventory management actions by our customers.  The increase in Cloud & Networking net revenue is primarily due to $84.6 million of revenue generated by Cloud Light and $30.5 million of increase in revenue driven by growing customer demand in cloud applications, offset by reduction in shipment primarily driven by U.S. trade restriction and demand drop associated with a build-up of inventory and resulting inventory management actions by our customers.

[0001628280-24-020767:mdna:42]
Net revenue decreased by $345.3 million, or 24.7%, during the nine months ended March 30, 2024 compared to the nine months ended April 1, 2023, driven by a $205.8 million decrease in Cloud & Networking revenue and a $139.5 million decrease in Industrial Tech revenue. The decrease in Cloud & Networking net revenue is primarily due to reduction in shipment primarily driven by U.S. trade restriction and demand drop associated with a build-up of inventory and resulting inventory management actions by our customers, offset by $144.1 million of revenue generated by Cloud Light. The decrease in Industrial Tech net revenue is primarily due to higher market competition, which reflects share normalization in the market, as well as reduction in demand associated with a build-up of inventory and resulting inventory management actions by our customers.

[0001628280-24-020767:mdna:43]
The following table sets forth net revenue generated from a single customer that represented 10% or greater of the total net revenue for the periods presented:

[0001628280-24-020767:mdna:44]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |  | March 30, 2024 |  | April 1, 2023 |
| Customer A | 28.5 | % |  | * |  | 18.7 | % |  | * |
| Customer B | * |  | 12.7 | % |  | * |  | * |
| Customer C | * |  | 10.7 | % |  | 12.1 | % |  | 16.1 | % |
| Customer D | * |  | * |  | * |  | 13.1 | % |
| *Represents less than 10% of total net revenue |  |  |  |  |  |  |  |

[0001628280-24-020767:mdna:45]
.

[0001628280-24-020767:mdna:46]
[same as prior period, unchanged from 0001628280-24-003796:mdna:46]

[0001628280-24-020767:mdna:47]
[same as prior period, unchanged from 0001628280-24-003796:mdna:47]

[0001628280-24-020767:mdna:48]
[same as prior period, unchanged from 0001628280-24-003796:mdna:48]

[0001628280-24-020767:mdna:49]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |  | March 30, 2024 |  | April 1, 2023 |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 129.9 |  |  | 35.4 | % |  | $ | 68.3 |  |  | 17.8 | % |  | $ | 274.0 |  |  | 26.2 | % |  | $ | 196.0 |  |  | 14.0 | % |
| Mexico | 18.9 |  |  | 5.2 |  |  | 20.5 |  |  | 5.4 |  |  | 74.0 |  |  | 7.0 |  |  | 137.5 |  |  | 9.8 |  |
| Other Americas | 0.6 |  |  | 0.2 |  |  | 1.9 |  |  | 0.5 |  |  | 2.6 |  |  | 0.2 |  |  | 8.0 |  |  | 0.6 |  |
| Total Americas | $ | 149.4 |  |  | 40.8 | % |  | $ | 90.7 |  |  | 23.7 | % |  | $ | 350.6 |  |  | 33.4 | % |  | $ | 341.5 |  |  | 24.4 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 62.0 |  |  | 16.9 | % |  | $ | 46.5 |  |  | 12.1 | % |  | $ | 192.6 |  |  | 18.3 | % |  | $ | 190.0 |  |  | 13.6 | % |
| South Korea | 16.2 |  |  | 4.4 |  |  | 28.5 |  |  | 7.4 |  |  | 62.0 |  |  | 5.9 |  |  | 148.2 |  |  | 10.6 |  |
| Japan | 16.6 |  |  | 4.5 |  |  | 41.8 |  |  | 10.9 |  |  | 67.9 |  |  | 6.5 |  |  | 137.4 |  |  | 9.8 |  |
| Thailand | 44.0 |  |  | 12.0 |  |  | 67.8 |  |  | 17.7 |  |  | 147.5 |  |  | 14.0 |  |  | 203.2 |  |  | 14.6 |  |
| Other Asia-Pacific | 46.0 |  |  | 12.6 |  |  | 61.5 |  |  | 16.0 |  |  | 135.0 |  |  | 12.8 |  |  | 235.1 |  |  | 16.8 |  |
| Total Asia-Pacific | $ | 184.8 |  |  | 50.4 | % |  | $ | 246.1 |  |  | 64.1 | % |  | $ | 605.0 |  |  | 57.5 | % |  | $ | 913.9 |  |  | 65.5 | % |
| EMEA | $ | 32.3 |  |  | 8.8 | % |  | $ | 46.6 |  |  | 12.2 | % |  | $ | 95.3 |  |  | 9.1 | % |  | $ | 140.8 |  |  | 10.1 | % |
| Total net revenue | $ | 366.5 |  |  | 100.0 | % |  | $ | 383.4 |  |  | 100.0 | % |  | $ | 1,050.9 |  |  | 100.0 | % |  | $ | 1,396.2 |  |  | 100.0 | % |

[0001628280-24-020767:mdna:50]
For the three and nine months ended March 30, 2024, net revenue from customers outside the United States, based on customer shipping location, represented 64.7% and 73.9% of net revenue, respectively.

[0001628280-24-020767:mdna:51]
For the three and nine months ended April 1, 2023, net revenue from customers outside the United States, based on customer shipping location, represented 82.2% and 86.0% of net revenue, respectively.

[0001628280-24-020767:mdna:52]
[same as prior period, unchanged from 0001628280-24-003796:mdna:52]

[0001628280-24-020767:mdna:53]
[same as prior period, unchanged from 0001628280-24-003796:mdna:53]

[0001628280-24-020767:mdna:54]
Gross margin for the three months ended March 30, 2024 decreased to 16.2% from 29.2% for the three months ended April 1, 2023. The decrease was primarily due to lower sales of telecom products, which negatively impacted gross margin by approximately 9.7%. Additionally, gross margin was impacted by $11.9 million of abnormal excess capacity as a result of our manufacturing synergy plans driven by restructuring efforts in connection with the integration of NeoPhotonics, transferring product lines out of China due to U.S. trade restrictions, and a drop in demand due to customers actively working to reduce their elevated inventory levels, as well as $3.6 million of higher amortization of intangibles due to the Cloud Light acquisition.

[0001628280-24-020767:mdna:55]
Gross margin for the nine months ended March 30, 2024 decreased to 19.1% from 34.3% for the nine months ended April 1, 2023. The decrease was primarily due to a less profitable mix of products, including lower sales of telecom products, which negatively impacted gross margin by approximately 6.8%, as well as lower sales of imaging and sensing products, which negatively impacted gross margin by approximately 3.0%. Additionally, gross margin was impacted by $13.7 million of abnormal excess capacity as a result of our manufacturing synergy plans driven by restructuring efforts in connection with the integration of NeoPhotonics, transferring product lines out of China due to U.S. trade restrictions, and a drop in demand due to customers actively working to reduce their elevated inventory levels, as well as $14.6 million of higher inventory excess and obsolescence charges primarily due to U.S. trade restrictions whereby we are no longer able to sell certain products to one of our customers and customer demand changes as a result of product transitions. The decrease in gross margin was partially offset by $9.5 million of lower amortization of acquired inventory resulting from our acquisitions of NeoPhotonics in August 2022 and Cloud Light in November 2023.

[0001628280-24-020767:mdna:56]
The markets in which we sell products are consolidating, undergoing product, architectural and business model transitions, have high customer concentrations, are highly competitive, are price sensitive and/or are affected by customer seasonality and  variants in buying patterns. We expect these factors to result in variability of our gross margin.

[0001628280-24-020767:mdna:57]
Segment Profit (Loss)

[0001628280-24-020767:mdna:58]
The following table summarizes segment profit (loss) for each of our operating segments (in millions). Comparative prior period segment information has been recast to conform to the new segment structure.

[0001628280-24-020767:mdna:59]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |  | March 30, 2024 |  | April 1, 2023 |
| Cloud & Networking | $ | 45.9 |  |  | $ | 61.0 |  |  | $ | 98.9 |  |  | $ | 262.6 |  |
| Industrial Tech | (2.7) |  |  | 22.1 |  |  | 25.3 |  |  | 140.6 |  |

[0001628280-24-020767:mdna:60]
Cloud & Networking segment profit decreased by $15.1 million, or 24.8%, during the three months ended March 30, 2024 as compared to the same period in the prior year primarily due to lower sales of telecom products, which negatively impacted segment profit by $43.2 million, partially offset by $28.0 million of segment profit due to higher cloud data center revenue, including revenue from the acquisition of Cloud Light. Industrial Tech segment profit decreased by $24.8 million, or 112.2%, during the three months ended March 30, 2024 as compared to the same period in the prior year primarily due to lower revenue and a less profitable mix of products, including lower sales of higher margin imaging and sensing products due to share normalization, which negatively impacted segment profit by $11.7 million.

[0001628280-24-020767:mdna:61]
Cloud & Networking segment profit decreased by $163.7 million, or 62.3%, during the nine months ended March 30, 2024 as compared to the same period in the prior year primarily due to lower segment revenue and lower sales from telecom products, which negatively impacted segment profit by $162.1 million. Industrial Tech segment profit decreased by $115.3 million, or 82.0%, during the nine months ended March 30, 2024 as compared to the same period in the prior year primarily due to lower revenue and a less profitable mix of products, including lower sales of higher margin imaging and sensing products due to share normalization, which negatively impacted segment profit by $68.6 million.

[0001628280-24-020767:mdna:62]
[same as prior period, unchanged from 0001628280-24-003796:mdna:70]

[0001628280-24-020767:mdna:63]
R&D expense decreased by $8.2 million, or 9.6% for the three months ended March 30, 2024 compared to the three months ended April 1, 2023, primarily due to a charge of $11.5 million recorded during the three months ended April 1, 2023 related to a write-off of in-process research and development intangible assets acquired from NeoPhotonics for projects that we subsequently decided not to pursue, offset by $1.0 million of higher spending in software and computer supplies used for R&D purposes.

[0001628280-24-020767:mdna:64]
R&D expense decreased by $4.9 million, or 2.1% for the nine months ended March 30, 2024 compared to the nine months ended April 1, 2023, primarily due to a charge of $11.5 million recorded during the nine months ended April 1, 2023 related to a write-off of in-process research and development intangible assets acquired from NeoPhotonics for projects that we subsequently decided not to pursue, offset by $4.0 million of higher spending in software and computer supplies used for R&D purposes.

[0001628280-24-020767:mdna:65]
[same as prior period, unchanged from 0001628280-24-003796:mdna:73]

[0001628280-24-020767:mdna:66]
[same as prior period, unchanged from 0001628280-24-003796:mdna:74]

[0001628280-24-020767:mdna:67]
SG&A expense increased by $1.3 million, or 1.7%, during the three months ended March 30, 2024 compared to the three months ended April 1, 2023. The increase was driven by $8.1 million of incremental amortization of intangible assets associated with the Cloud Light acquisition, substantially offset by a reduction in payroll related expenses as a result of recent restructuring actions and $2.4 million of lower outside consultant costs as a result of business and system integrations efforts.

[0001628280-24-020767:mdna:68]
SG&A expense decreased by $44.7 million, or 15.9%, during the nine months ended March 30, 2024 compared to the nine months ended April 1, 2023. The decrease in SG&A expense for the nine months ended March 30, 2024 was primarily driven by the overall reduction in payroll related expenses as a result of recent restructuring actions, $17.8 million of lower outside consultant costs as a result of business and system integrations efforts, $21.3 million of lower stock-based compensation, $7.8 million of lower legal costs with respect to the settlement of certain non-ordinary course litigation matters and $3.1 million of lower acquisition related costs as a result of the timing of our recent acquisitions, partially offset by $13.9 million of incremental amortization of intangible assets associated with the Cloud Light acquisition. In connection with the merger with NeoPhotonics that occurred in August 2022, certain equity awards for NeoPhotonics employees were accelerated, resulting in $11.9 million of stock-based compensation recognized during the nine months ended April 1, 2023.

[0001628280-24-020767:mdna:69]
From time-to-time, we incur expenses that are not part of our ordinary operations, such as mergers and acquisition-related and litigation expenses, which generally increase our SG&A expenses and potentially impact our profitability expectations in any particular period.

[0001628280-24-020767:mdna:70]
[same as prior period, unchanged from 0001628280-24-003796:mdna:78]

[0001628280-24-020767:mdna:71]
We have initiated various strategic restructuring events primarily intended to reduce costs, consolidate our operations, rationalize the manufacturing of our products, and align our business in response to market conditions. We also took certain actions in connection with the integration of NeoPhotonics.

[0001628280-24-020767:mdna:72]
During the three and nine months ended March 30, 2024, we recorded restructuring and related charges of $19.2 million and $36.0 million, respectively, primarily due to company-wide cost reduction initiatives, as well as our integration efforts as a result of the NeoPhotonics acquisition in August 2022.

[0001628280-24-020767:mdna:73]
During the three months ended April 1, 2023, we recorded restructuring and related charges of $1.6 million in our condensed consolidated statements of operations, which was primarily due to company-wide integration efforts as a result of the merger with NeoPhotonics, as well as our cost reduction initiatives. During the nine months ended April 1, 2023, we recorded restructuring and related charges of $24.8 million in our condensed consolidated statements of operations, which was primarily attributable to company-wide integration efforts as a result of the merger with NeoPhotonics, our cost reduction initiatives, as well as severance and employee-related benefits associated with NeoPhotonics’ executive severance and retention agreements. These agreements provide for payments and benefits upon an involuntary termination of employment under certain circumstances.

[0001628280-24-020767:mdna:74]
[same as prior period, unchanged from 0001628280-24-003796:mdna:82]

[0001628280-24-020767:mdna:75]
For the three months ended March 30, 2024 and April 1, 2023, we recorded interest expense of $9.0 million and $8.7 million, respectively. For the nine months ended March 30, 2024 and April 1, 2023, we recorded interest expense of $28.4 million and $26.1 million, respectively. Interest expense relates to the amortization of the debt discount and issuance costs of our convertible notes. The increase in interest expense for the three and nine months ended March 30, 2024 is due to our 2029 Notes (as defined below) issued in June 2023, partially offset by the reduction of interest expense related to our 2024 Notes (as defined below) that matured and were fully paid in March 2024.

[0001628280-24-020767:mdna:76]
[same as prior period, unchanged from 0001628280-24-003796:mdna:84]

[0001628280-24-020767:mdna:77]
[same as prior period, unchanged from 0001628280-24-003796:mdna:85]

[0001628280-24-020767:mdna:78]
|  | Three Months Ended |  | Nine Months Ended |  |  |
|  | March 30, 2024 |  | April 1, 2023 |  | March 30, 2024 |  | April 1, 2023 |  |  |
| Foreign exchange and other gains (losses), net | $ | 3.7 |  |  | $ | (0.5) |  |  | $ | (0.5) |  |  | $ | 4.4 |  |  |  |
| Interest and investment income, net | 12.6 |  |  | 11.9 |  |  | 51.4 |  |  | 24.4 |  |  |  |
| Other income (expense), net | (0.1) |  |  | — |  |  | (0.1) |  |  | 0.1 |  |  |  |
| Total other income, net | $ | 16.2 |  |  | $ | 11.4 |  |  | $ | 50.8 |  |  | $ | 28.9 |  |  |  |

[0001628280-24-020767:mdna:79]
Other income, net for the three months ended March 30, 2024 increased by $4.8 million from the three months ended April 1, 2023 primarily due to an increase in income from foreign exchange of $4.2 million as a result of the strengthening of other foreign currencies relative to the U.S. dollar during the three months ended March 30, 2024.

[0001628280-24-020767:mdna:80]
Other income, net for the nine months ended March 30, 2024 increased by $21.9 million from the nine months ended April 1, 2023 primarily due to $27.0 million of increase in interest and investment income driven by an increase in interest rates on our fixed income securities, offset by a decrease in income from foreign exchange of $4.9 million as a result of the weakening of other foreign currencies relative to the U.S. dollar during the nine months ended April 1, 2023.

[0001628280-24-020767:mdna:81]
[same as prior period, unchanged from 0001628280-24-003796:mdna:89]

[0001628280-24-020767:mdna:82]
[same as prior period, unchanged from 0001628280-24-003796:mdna:90]

[0001628280-24-020767:mdna:83]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |  | March 30, 2024 |  | April 1, 2023 |
| Income tax provision (benefit) | $ | 19.6 |  |  | $ | (9.4) |  |  | $ | 15.8 |  |  | $ | 14.4 |  |

[0001628280-24-020767:mdna:84]
We recorded a tax provision of $19.6 million and $15.8 million for the three and nine months ended March 30, 2024, respectively. Our tax provision for the three months ended March 30, 2024 includes a discrete tax expense of $17.6 million primarily related to the establishment of a partial valuation allowance against certain deferred tax assets, withholding taxes, and changes in prior year uncertain tax positions, partially offset by the tax benefit of tax rate changes. Our tax provision for the nine months ended March 30, 2024 includes a discrete tax expense of $19.2 million, primarily related the establishment of a partial valuation allowance against certain deferred tax assets, withholding taxes, a shortfall in connection with stock-based compensation vested during the period, and interest on uncertain tax positions, partially offset by the tax benefit from tax rate changes.

[0001628280-24-020767:mdna:85]
We regularly assess our ability to realize our deferred tax assets on a quarterly basis and will establish a valuation allowance if it is more-likely-than-not that some portion of the deferred tax assets will not be realized. During the three-months ended March 30, 2024, we determined that a portion of our deferred tax assets related to certain tax credit carryforwards are not more-likely-than-not to be realized, and we established a valuation allowance of $10.9 million against such deferred tax assets. We will continue to assess the need for a valuation allowance against our remaining deferred tax assets and may increase or decrease our valuation allowance materially in the future.

[0001628280-24-020767:mdna:86]
We recorded a tax benefit of $9.4 million and a tax provision of $14.4 million for the three and nine months ended April 1, 2023, respectively. Our tax benefit for the three months ended April 1, 2023 includes a discrete tax expense of $9.8 million, primarily related to a tax planning action that was implemented during the quarter relating to fiscal year 2022 and changes in prior year uncertain tax positions, partially offset by a shortfall in connection with stock-based compensation vested during the quarter. Our tax provision for the nine months ended April 1, 2023 includes a discrete tax expense of $7.2 million, primarily related to the international restructuring, partially offset by the tax benefits from tax rate changes, a tax planning action that was implemented during the quarter relating to fiscal year 2022, and changes in prior year uncertain tax positions.

[0001628280-24-020767:mdna:87]
In accordance with the guidance in ASC 740, we review whether our deferred tax assets are more likely than not to be realizable in the future.  During the three months ended March 30, 2024, we determined that a portion of our deferred tax assets related to certain tax credit carryforwards were not expected to be realized on a more-likely-than-not basis. As such, we recognized a tax expense of $10.9 million to establish a partial valuation allowance against our deferred tax assets in the U.S.

[0001628280-24-020767:mdna:88]
Our estimated effective tax rate for fiscal 2024 differs from the 21% U.S. statutory rate primarily due to the income tax expense from foreign rate differential, non-deductible stock-based compensation, and current year valuation allowance changes, partially offset by the income tax benefit from various income tax credits.

[0001628280-24-020767:mdna:89]
[same as prior period, unchanged from 0001628280-24-003796:mdna:95]

[0001628280-24-020767:mdna:90]
[same as prior period, unchanged from 0001628280-24-003796:mdna:96]

[0001628280-24-020767:mdna:91]
[same as prior period, unchanged from 0001628280-24-003796:mdna:97]

[0001628280-24-020767:mdna:92]
[same as prior period, unchanged from 0001628280-24-003796:mdna:98]

[0001628280-24-020767:mdna:93]
As of March 30, 2024 and July 1, 2023, our cash and cash equivalents were $425.0 million and $859.0 million, respectively. As of March 30, 2024 and July 1, 2023, our short-term investments of $445.9 million and $1,154.6 million, respectively, were all held in the United States. Cash equivalents and short-term investments are primarily comprised of money market funds, treasuries, agencies, high quality investment grade fixed income securities, certificates of deposit and commercial paper. Our investment policy and strategy provide for diversification of investments and is focused on the preservation of capital and supporting our liquidity requirements.

[0001628280-24-020767:mdna:94]
The total amount of cash held by the non-United States entities as of March 30, 2024 and July 1, 2023 was $216.5 million and $298.4 million, respectively, which was primarily held by entities incorporated in the United Kingdom, the British Virgin Islands, Japan, Hong Kong, China, Switzerland, the Cayman Islands, Thailand and Brazil. Although cash currently held in the United States, as well as cash generated in the United States from future operations, is expected to cover our normal operating requirements, a substantial amount of additional cash could be required for other purposes, such as capital expenditures to support our business and growth, including costs associated with increasing internal manufacturing capabilities, strategic transactions and partnerships, and future acquisitions.

[0001628280-24-020767:mdna:95]
[same as prior period, unchanged from 0001628280-24-003796:mdna:101]

[0001628280-24-020767:mdna:96]
[same as prior period, unchanged from 0001628280-24-003796:mdna:102]

[0001628280-24-020767:mdna:97]
We believe that our cash and cash equivalents as of March 30, 2024 and cash flows from our operating activities will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months.

[0001628280-24-020767:mdna:98]
[same as prior period, unchanged from 0001628280-24-003796:mdna:104]

[0001628280-24-020767:mdna:99]
[same as prior period, unchanged from 0001628280-24-003796:mdna:105]

[0001628280-24-020767:mdna:100]
[same as prior period, unchanged from 0001628280-24-003796:mdna:106]

[0001628280-24-020767:mdna:101]
[same as prior period, unchanged from 0001628280-24-003796:mdna:107]

[0001628280-24-020767:mdna:102]
[same as prior period, unchanged from 0001628280-24-003796:mdna:108]

[0001628280-24-020767:mdna:103]
[same as prior period, unchanged from 0001628280-24-003796:mdna:109]

[0001628280-24-020767:mdna:104]
[same as prior period, unchanged from 0001628280-24-003796:mdna:110]

[0001628280-24-020767:mdna:105]
[same as prior period, unchanged from 0001628280-24-003796:mdna:111]

[0001628280-24-020767:mdna:106]
[same as prior period, unchanged from 0001628280-24-003796:mdna:112]

[0001628280-24-020767:mdna:107]
[same as prior period, unchanged from 0001628280-24-003796:mdna:113]

[0001628280-24-020767:mdna:108]
[same as prior period, unchanged from 0001628280-24-003796:mdna:114]

[0001628280-24-020767:mdna:109]
[same as prior period, unchanged from 0001628280-24-003796:mdna:115]

[0001628280-24-020767:mdna:110]
[same as prior period, unchanged from 0001628280-24-003796:mdna:116]

[0001628280-24-020767:mdna:111]
[same as prior period, unchanged from 0001628280-24-003796:mdna:117]

[0001628280-24-020767:mdna:112]
[same as prior period, unchanged from 0001628280-24-003796:mdna:118]

[0001628280-24-020767:mdna:113]
[same as prior period, unchanged from 0001628280-24-003796:mdna:119]

[0001628280-24-020767:mdna:114]
[same as prior period, unchanged from 0001628280-24-003796:mdna:120]

[0001628280-24-020767:mdna:115]
The following table summarizes our contractual obligations as of March 30, 2024, and the effect such obligations are expected to have on our liquidity and cash flow (in millions):

[0001628280-24-020767:mdna:116]
|  | Payments Due |
|  | Total |  | Less Than 1 Year |  | More Than 1 Year |  |  |  |  |
| Contractual Obligations |  |  |  |  |  |  |  |  |  |
| Asset retirement obligations | $ | 7.5 |  |  | $ | — |  |  | $ | 7.5 |  |  |  |  |  |
| Operating lease liabilities, including imputed interest (1) | 72.2 |  |  | 17.9 |  |  | 54.3 |  |  |  |  |  |
| Pension plan contributions (2) | 2.2 |  |  | 2.2 |  |  | — |  |  |  |  |  |
| Purchase obligations (3) | 369.8 |  |  | 319.6 |  |  | 50.2 |  |  |  |  |  |
| Convertible notes - principal (4) | 2,514.7 |  |  | — |  |  | 2,514.7 |  |  |  |  |  |
| Convertible notes - interest (4) | 89.5 |  |  | 18.8 |  |  | 70.7 |  |  |  |  |  |
| Total | $ | 3,055.9 |  |  | $ | 358.5 |  |  | $ | 2,697.4 |  |  |  |  |  |

[0001628280-24-020767:mdna:117]
(1) The amounts of operating lease liabilities do not include any sublease income amounts nor do they include payments for short-term leases or variable lease payments. As of March 30, 2024, we expect to receive sublease income of approximately $3.6 million over the sublease periods.

[0001628280-24-020767:mdna:118]
[same as prior period, unchanged from 0001628280-24-003796:mdna:124]

[0001628280-24-020767:mdna:119]
(3) Purchase obligations represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Refer to “Note 14. Commitments and Contingencies” in the notes to condensed consolidated financial statements.

[0001628280-24-020767:mdna:120]
(4) The amounts related to convertible notes include principal and interest on our 0.50% Convertible Senior Notes due 2026 (the “2026 Notes”), principal and interest on our 0.50% Convertible Senior Notes due 2028 (the “2028 Notes”), and principal and interest on our 1.50% Convertible Senior Notes due 2029 (the “2029 Notes”). The 2026 Notes have a maturity date of December 15, 2026, the 2028 Notes have a maturity date of June 15, 2028, and the 2029 Notes have a maturity date of December 15, 2029. The principal balances of our convertible notes are reflected in the payment periods in the table above based on their respective contractual maturities assuming no conversions. On March 15, 2024, the maturity date of the 2024 Notes, we repaid the outstanding $323.1 million principal amount of the 2024 Notes in full. Refer to “Note 9. Debt” in the notes to condensed consolidated financial statements.

[0001628280-24-020767:mdna:121]
[same as prior period, unchanged from 0001628280-24-003796:mdna:127]

[0001628280-24-020767:mdna:122]
[same as prior period, unchanged from 0001628280-24-003796:mdna:128]

[0001628280-24-020767:mdna:123]
As of March 30, 2024, the net carrying amount of our 2029 Notes of $599.1 million (principal balance of $603.7 million maturing in 2029) is presented in non-current liabilities. If the closing price of our stock exceeds $90.40 (or 130% of the conversion price of $69.54) for 20 of the last 30 trading days of any future quarter, the 2029 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our consolidated balance sheets.

[0001628280-24-020767:mdna:124]
As of March 30, 2024, the net carrying amount of our 2028 Notes of $856.5 million (which have an aggregate principal amount of $861.0 million outstanding that matures in 2028) is presented in non-current liabilities in our condensed consolidated balance sheets. If the closing price of our stock exceeds $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of any future fiscal quarter, our 2028 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-24-020767:mdna:125]
As of March 30, 2024, the net carrying amount of our 2026 Notes of $1,046.8 million (which have an aggregate principal amount of $1,050.0 million outstanding that matures in 2026) is presented in non-current liabilities in our condensed consolidated balance sheets. If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future fiscal quarter, our 2026 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-24-020767:mdna:126]
[same as prior period, unchanged from 0001628280-24-003796:mdna:133]

[0001628280-24-020767:mdna:127]
We have a share buyback program that authorizes us to utilize up to an aggregate amount of $1.2 billion to purchase our own shares of common stock through May 2025. During the nine months ended March 30, 2024, we did not repurchase any shares of our common stock. During the nine months ended April 1, 2023, we repurchased 0.3 million shares of our common stock at an average price of $89.80 per share for an aggregate purchase price of $25.7 million. Since the board of directors initially approved the share buyback program, we have repurchased 7.7 million shares in aggregate at an average price of $81.66 per share for a total purchase price of $630.4 million. We recorded the $630.4 million aggregate purchase price as a reduction of retained earnings within our condensed consolidated balance sheet. All repurchased shares were retired immediately. As of March 30, 2024, we have $569.6 million remaining under the share buyback program.

[0001628280-24-020767:mdna:128]
[same as prior period, unchanged from 0001628280-24-003796:mdna:135]

[0001628280-24-020767:mdna:129]
[same as prior period, unchanged from 0001628280-24-003796:mdna:136]

[0001628280-24-020767:mdna:130]
As of March 30, 2024 and July 1, 2023, our other non-current liabilities include unrecognized tax benefit for uncertain tax positions of $73.9 million and $64.4 million, respectively. We are unable to reliably estimate the timing of future payments related to uncertain tax positions.

[0001628280-24-020767:mdna:131]
[same as prior period, unchanged from 0001628280-24-003796:mdna:138]

[0001628280-24-020767:mdna:132]
Our balance of cash and cash equivalents decreased by $434.0 million from $859.0 million as of July 1, 2023 to $425.0 million as of March 30, 2024. The decrease in cash and cash equivalents during the nine months ended March 30, 2024 was due to cash used in financing activities of $336.4 million, cash used in investing activities of $86.8 million and cash used in operating activities of $10.8 million.

[0001628280-24-020767:mdna:133]
[same as prior period, unchanged from 0001628280-24-003796:mdna:140]

[0001628280-24-020767:mdna:134]
Cash used in operating activities was $10.8 million during the nine months ended March 30, 2024, which reflects a net loss of $294.0 million and changes in operating assets and liabilities of $19.1 million, offset by non-cash items of $302.3 million. Changes in operating assets and liabilities were primarily driven by a decrease in accounts payable of $82.8 million primarily due to lower inventory purchases and linearity of payments, and a decrease in income tax liabilities of $37.3 million primarily due annual income tax payments in Japan, offset by a decrease in accounts receivable of $37.2 million due to lower revenue and a decrease in inventories of $52.5 million primarily due to reduced inventory level in our Cloud & Networking business.

[0001628280-24-020767:mdna:135]
Cash provided by operating activities was $130.6 million during the nine months ended April 1, 2023, which reflects a net loss of $71.4 million and non-cash items of $346.5 million for the nine months ended April 1, 2023, offset by $144.5 million changes in our operating assets and liabilities. Changes in our operating assets and liabilities is mainly driven an increase in inventories of $80.6 million primarily related to prebuild inventory and safety stock, a decrease in accounts payable of $44.3 million lower purchases from our contract manufactures and linearity of payments, offset by a decrease in accounts receivable of $51.0 million due to lower revenue.

[0001628280-24-020767:mdna:136]
[same as prior period, unchanged from 0001628280-24-003796:mdna:143]

[0001628280-24-020767:mdna:137]
Cash used in investing activities of $86.8 million during the nine months ended March 30, 2024 was attributable to cash used in the acquisition of Cloud Light of $700.9 million, net of cash acquired, capital expenditures of $108.4 million and an intangible asset acquisition of $4.0 million, offset by net proceeds from sales or maturities of short-term investments of $725.7 million and proceeds from sales of property and equipment of $0.8 million.

[0001628280-24-020767:mdna:138]
Cash used in investing activities of $803.1 million during the nine months ended April 1, 2023 was attributable to the acquisition of NeoPhotonics and IPG product lines in the amount of $861.6 million, net of cash acquired, and capital expenditures of $92.2 million, partially offset by net proceeds from sales or maturities of short-term investments of $150.6 million.

[0001628280-24-020767:mdna:139]
[same as prior period, unchanged from 0001628280-24-003796:mdna:146]

[0001628280-24-020767:mdna:140]
Cash used in financing activities of $336.4 million during the nine months ended March 30, 2024 was attributable to $323.1 million of repayment of the principal amount of 2024 Notes upon maturity, tax payments related to net share settlement of restricted stock of $20.6 million, offset by $7.3 million of proceeds from employee stock plans.

[0001628280-24-020767:mdna:141]
Cash used in financing activities of $68.5 million during the nine months ended April 1, 2023 was driven by the repurchase of shares of our common stock of $35.8 million, tax payments related to net share settlement of restricted stock of $33.4 million, and $5.9 million of repayments for all the term loans that we assumed in connection with our merger with NeoPhotonics, offset by $6.6 million of proceeds from employee stock plans.
