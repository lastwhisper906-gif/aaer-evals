# LITE note change history — 0001628280-24-003796 → 0001628280-24-020767


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-05-07):
[0001628280-24-020767:note_history:1]
Our purchase obligations of $369.8 million as of March 30, 2024 represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.
  (was, 2024-02-08, similarity 0.9887):
[0001628280-24-003796:note_history:1]
Our purchase obligations of $423.8 million as of December 30, 2023 represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

- changed (2024-05-07):
[0001628280-24-020767:note_history:2]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |  | March 30, 2024 |  | April 1, 2023 |
| Balance as of beginning of period | $ | 10.1 |  |  | $ | 8.4 |  |  | $ | 6.8 |  |  | $ | 10.0 |  |
| Warranties assumed in NeoPhotonics merger | — |  |  | — |  |  | — |  |  | 0.7 |  |
| Warranty assumed from Cloud Light | 3.0 |  |  | — |  |  | 8.2 |  |  | — |  |
| Provision for warranty | 2.6 |  |  | 1.1 |  |  | 3.6 |  |  | 5.4 |  |
| Utilization of reserve, net | (2.2) |  |  | (2.7) |  |  | (5.1) |  |  | (9.3) |  |
| Balance as of end of period | $ | 13.5 |  |  | $ | 6.8 |  |  | $ | 13.5 |  |  | $ | 6.8 |  |
  (was, 2024-02-08, similarity 0.6521):
[0001628280-24-003796:note_history:2]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2023 |  | December 31, 2022 |  | December 30, 2023 |  | December 31, 2022 |
| Balance as of beginning of period | $ | 5.5 |  |  | $ | 10.1 |  |  | $ | 6.8 |  |  | $ | 10.0 |  |
| Warranty assumed from Cloud Light | 5.2 |  |  | — |  |  | 5.2 |  |  | — |  |
| Provision for warranty | 0.8 |  |  | 2.8 |  |  | 1.0 |  |  | 5.0 |  |
| Utilization of reserve, net | (1.4) |  |  | (4.5) |  |  | (2.9) |  |  | (6.6) |  |
| Balance as of end of period | $ | 10.1 |  |  | $ | 8.4 |  |  | $ | 10.1 |  |  | $ | 8.4 |  |

- changed (2024-05-07):
[0001628280-24-020767:note_history:3]
We are subject to a variety of claims and suits that arise from time-to-time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss. During the year ended July 1, 2023, we recorded $7.8 million with respect to the pending settlement of certain non-ordinary course litigation matters under accrued expenses in our consolidated balance sheet, which has not been settled as of March 30, 2024.
  (was, 2024-02-08, similarity 0.9925):
[0001628280-24-003796:note_history:3]
We are subject to a variety of claims and suits that arise from time-to-time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss. During the year ended July 1, 2023, we recorded $7.8 million with respect to the pending settlement of certain non-ordinary course litigation matters under accrued expenses in our consolidated balance sheet, which has not been settled as of December 30, 2023.

- changed (2024-05-07):
[0001628280-24-020767:note_history:4]
On August 16, 2022, the lead plaintiff moved for class certification and to be appointed class representative. Defendants opposed the motion. The action subsequently was stayed while the parties participated in a mediation. On January 18, 2023, the lead plaintiff filed a Notice of Settlement informing the court of an agreement in principle between the parties for a class-wide settlement of the Karri Lawsuit. On January 24, 2023, in light of the potential settlement, the court vacated all pretrial and trial dates and ordered the lead plaintiff to file a motion for preliminary approval of the settlement by March 17, 2023. The lead plaintiff filed his motion for preliminary approval of the settlement on March 16, 2023, and defendants filed a statement of non-opposition on March 30, 2023. On April 20, 2023, the court held a hearing on lead plaintiff’s motion for preliminary approval of the settlement. The court declined to grant lead plaintiff’s motion for preliminary approval and ordered lead plaintiff to file a revised motion by May 22, 2023. Lead plaintiff filed his Revised Motion for Preliminary Approval of Settlement (the “Amended Motion”) on May 22, 2023, defendants filed a response in support of the Amended Motion on June 5, 2023, and the lead plaintiff submitted his reply on June 12, 2023. The hearing on the Amended Motion took place on August 17, 2023 and the court preliminarily approved the settlement. In March 2024, the court approved the settlement amount of $15.3 million.
  (was, 2024-02-08, similarity 0.9332):
[0001628280-24-003796:note_history:4]
On August 16, 2022, the lead plaintiff moved for class certification and to be appointed class representative. Defendants opposed the motion. The action subsequently was stayed while the parties participated in a mediation. On January 18, 2023, the lead plaintiff filed a Notice of Settlement informing the court of an agreement in principle between the parties for a class-wide settlement of the Karri Lawsuit. On January 24, 2023, in light of the potential settlement, the court vacated all pretrial and trial dates and ordered the lead plaintiff to file a motion for preliminary approval of the settlement by March 17, 2023. The lead plaintiff filed his motion for preliminary approval of the settlement on March 16, 2023, and defendants filed a statement of non-opposition on March 30, 2023. On April 20, 2023, the court held a hearing on lead plaintiff’s motion for preliminary approval of the settlement. The court declined to grant lead plaintiff’s motion for preliminary approval and ordered lead plaintiff to file a revised motion by May 22, 2023. Lead plaintiff filed his Revised Motion for Preliminary Approval of Settlement (the “Amended Motion”) on May 22, 2023, defendants filed a response in support of the Amended Motion on June 5, 2023, and the lead plaintiff submitted his reply on June 12, 2023. The hearing on the Amended Motion took place on August 17, 2023 and the court preliminarily approved the settlement. In the event that the settlement does not go forward for any reason, the defendants intend to continue to defend the Karri Lawsuit vigorously.

- added (2024-05-07):
[0001628280-24-020767:note_history:5]
We recorded the court approved settlement amount of $15.3 million as accrued expenses in our condensed consolidated balance sheet as of March 30, 2024, of which $7.5 million represents the amount to be reimbursed by insurance and was recorded as prepayments and other current assets.

- changed (2024-05-07):
[0001628280-24-020767:note_history:6]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown, because claims may be made against us in the future, and we may record charges in the future as a result of these indemnification obligations. As of March 30, 2024, we did not have any material indemnification claims that were probable or reasonably possible.
  (was, 2024-02-08, similarity 0.9857):
[0001628280-24-003796:note_history:6]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown, because claims may be made against us in the future, and we may record charges in the future as a result of these indemnification obligations. As of December 30, 2023, we did not have any material indemnification claims that were probable or reasonably possible.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2024-05-07):
[0001628280-24-020767:note_history:7]
Lumentum Holdings Inc. (“we,” “us,” “our,” “Lumentum” or the “Company”) is an industry-leading provider of optical and photonic products that address a range of end-market applications that include cloud data center and optical communications network infrastructure, consumer electronic devices, automobiles, and high-precision manufacturing.

- added (2024-05-07):
[0001628280-24-020767:note_history:8]
Our Cloud & Networking products include a comprehensive portfolio of optical and photonic components, modules, and subsystems supplied to network operator and network equipment manufacturer customers building cloud data center infrastructure, including that for artificial intelligence and machine learning (“AI/ML”) and data center interconnect (“DCI”) applications, and communications service provider networks, including in access (local), metro (intracity), long-haul (city-to-city and worldwide), and submarine (undersea) network infrastructure. Our Cloud & Networking products also support network equipment manufacturers building enterprise network infrastructure, including storage-area networks (“SANs”), local-area networks (“LANs”) and wide-area networks (“WANs”). Demand for our Cloud & Networking products is driven by the continual growth in network capacity required for cloud computing and services, including for AI/ML, streaming video and video conferencing, wireless and mobile devices, and internet of things (“IoT”).

- added (2024-05-07):
[0001628280-24-020767:note_history:9]
Our Industrial Tech products include solid-state lasers, kilowatt-class fiber lasers, diode lasers, and gas lasers, which address applications in numerous end-markets. In the consumer end-market, our laser light sources are integrated into our customers’ 3D sensing cameras, which are used in mobile devices, payment kiosks, and other consumer electronics devices to enable applications including biometric identification, computational photography and virtual and augmented reality. In the automotive end-market, our lasers are used in our customers’ LiDAR and other optical sensor devices, which are increasingly being used in advanced driver assistance systems (“ADAS”) and in-cabin driver and occupant monitoring systems. In the industrial manufacturing end-market, our lasers are incorporated into our customers’ manufacturing machine tools used for the precision processing of materials in a range of industries including semiconductor device and microelectronics fabrication, electric vehicle and battery production, metal cutting and welding, and advanced manufacturing. Our products can also be used in the industrial end-market in imaging and sensing systems for process feedback and control, quality assurance, and waste reduction. Adoption of our products in the industrial end-market is driven by the needs of customers to advance semiconductor and microelectronics industry roadmaps, and by Industry 4.0/5.0 trends, including increasing manufacturing precision and flexibility and reducing waste and environmental impact. Demand for our products in the industrial end-market is driven by end-customer investments in manufacturing capacity. Our lasers also address certain semiconductor inspection and life-science applications.

- changed (2024-05-07):
[0001628280-24-020767:note_history:10]
We are continuously monitoring both the current developments in the ongoing war between Russia and Ukraine including the related additional export controls and resulting sanctions imposed on Russia and Belarus by the U.S. and other countries, and the Israel-Hamas war. Additional factors, such as increased inflation, escalating energy costs, constrained raw material availability and the related cost increases, could continue to impact the global economy and our business. Although the global implications of the wars are difficult to predict at this time, we do not presently foresee direct material adverse effects on our business.
  (was, 2024-02-08, similarity 0.9657):
[0001628280-24-003796:note_history:10]
We are continuously monitoring both the current developments in the ongoing war between Russia and Ukraine including the related additional export controls and resulting sanctions imposed on Russia and Belarus by the U.S. and other countries, and the war between Israel and Hamas. Additional factors, such as increased inflation, escalating energy costs, constrained raw material availability and the related cost increases, could continue to impact the global economy and our business. Although the global implications of the wars are difficult to predict at this time, we do not presently foresee direct material adverse effects on our business.

- changed (2024-05-07):
[0001628280-24-020767:note_history:11]
On November 7, 2023 (the “Closing date”), we completed the acquisition of Cloud Light Technology Limited (“Cloud Light”). Our condensed consolidated financial statements include the operating results of Cloud Light from the Closing date. On August 3, 2022, we completed the acquisition of NeoPhotonics Corporation (“NeoPhotonics”). On August 15, 2022, we completed the acquisition of IPG Photonics’ telecom transmission product lines. We have applied the acquisition method of accounting to account for these transactions in accordance with ASC Topic 805, Business Combinations. Refer to “Note 4. Business Combinations” for further discussions of these transactions.
  (was, 2024-02-08, similarity 0.9288):
[0001628280-24-003796:note_history:11]
On November 7, 2023 (the “Closing date”), we completed the acquisition of Cloud Light Technology Limited (“Cloud Light”). Our condensed consolidated financial statements include the operating results of Cloud Light for the period from the Closing date of the acquisition through December 30, 2023. On August 3, 2022, we completed the acquisition of NeoPhotonics Corporation (“NeoPhotonics”). On August 15, 2022, we completed the acquisition of IPG Photonics’ telecom transmission product lines. We have applied the acquisition method of accounting to account for these transactions in accordance with ASC Topic 805, Business Combinations. Refer to “Note 4. Business Combinations” for further discussions of these transactions.

- changed (2024-05-07):
[0001628280-24-020767:note_history:12]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2024 is a 52-week year ending on June 29, 2024, with the quarter ended March 30, 2024 being a 13-week quarterly period. Our fiscal 2023 was a 52-week year that ended on July 1, 2023, with the quarter ended April 1, 2023 being a 13-week quarterly period.
  (was, 2024-02-08, similarity 0.9027):
[0001628280-24-003796:note_history:12]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2024 is a 52-week year ending on June 29, 2024, with the quarter ended December 30, 2023 being a 13-week quarterly period. Our fiscal 2023 was a 52-week year that ended on July 1, 2023, with the quarter ended December 31, 2022 being a 13-week quarterly period.

- changed (2024-05-07):
[0001628280-24-020767:note_history:13]
Accounting Policies
The condensed consolidated financial statements and accompanying notes should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the fiscal year ended July 1, 2023. There were no significant changes to our accounting policies during the nine months ended March 30, 2024
  (was, 2024-02-08, similarity 0.895):
[0001628280-24-003796:note_history:13]
The condensed consolidated financial statements and accompanying notes should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the fiscal year ended July 1, 2023. There were no significant changes to our accounting policies during the six months ended December 30, 2023

- removed (2024-05-07):
[0001628280-24-003796:note_history:14]
Lumentum Holdings Inc. (“we,” “us,” “our,” “Lumentum” or the “Company”) is an industry-leading provider of optical and photonic products addressing a range of end-market applications for manufacturing, inspection, and life-science applications.

- removed (2024-05-07):
[0001628280-24-003796:note_history:15]
Our Cloud & Networking products include a wide range of components, modules and subsystems to support customers including carrier networks for access (local), metro (intracity), long-haul (city-to-city and worldwide) and submarine (undersea) applications. Our products also address enterprise, cloud and data center applications, including storage-access networks (“SANs”), local-area networks (“LANs”) and wide-area networks (“WANs”), as well as artificial intelligence and machine learning (“AI/ML”).

- removed (2024-05-07):
[0001628280-24-003796:note_history:16]
Our Industrial Tech products include diode laser products such as VCSELs and edge emitting lasers. In the consumer end-market, our laser light sources are integrated into 3D sensing cameras, which are used in applications in mobile devices, gaming, payment kiosks, computers, other consumer electronics devices, and automobiles. Applications include biometric identification, computational photography, virtual and augmented reality, and natural user interfaces, among others. In the industrial end-market, our diode lasers are used primarily as pump sources for pulsed and kilowatt class fiber lasers. Our products also include laser products used in a variety of OEM applications including diode-pumped solid-state, fiber, diode, direct-diode and gas lasers, such as argon-ion and helium-neon lasers.

- removed (2024-05-07):
[0001628280-24-003796:note_history:17]
Accounting Policies


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-07):
[0001628280-24-020767:note_history:18]
| March 30, 2024 |  |  | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | Total |  |  |  |  |  |
| Principal |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,514.7 |  |  |  |  |  |  |
| Unamortized debt discount and debt issuance costs |  |  | (3.2) |  |  | (4.5) |  |  | (4.6) |  |  | (12.3) |  |  |  |  |  |  |
| Net carrying amount of the liability component |  |  | $ | 1,046.8 |  |  | $ | 856.5 |  |  | $ | 599.1 |  |  | $ | 2,502.4 |  |  |  |  |  |  |
  (was, 2024-02-08, similarity 0.7796):
[0001628280-24-003796:note_history:18]
| December 30, 2023 | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |  | 2029 Notes (4) |  | Total |  |  |  |  |  |
| Principal | $ | 323.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,837.8 |  |  |  |  |  |  |
| Unamortized debt discount and debt issuance costs | (3.4) |  |  | (3.5) |  |  | (4.8) |  |  | (4.7) |  |  | (16.4) |  |  |  |  |  |  |
| Net carrying amount of the liability component | $ | 319.7 |  |  | $ | 1,046.5 |  |  | $ | 856.2 |  |  | $ | 599.0 |  |  | $ | 2,821.4 |  |  |  |  |  |  |

- changed (2024-05-07):
[0001628280-24-020767:note_history:19]
| July 1, 2023 | 2024 Notes |  | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | Total |
| Principal | $ | 323.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,837.8 |  |
| Unamortized debt discount and debt issuance costs | (11.5) |  |  | (4.1) |  |  | (5.5) |  |  | (5.1) |  |  | (26.2) |  |
| Net carrying amount of the liability component | $ | 311.6 |  |  | $ | 1,045.9 |  |  | $ | 855.5 |  |  | $ | 598.6 |  |  | $ | 2,811.6 |  |
  (was, 2024-02-08, similarity 0.9945):
[0001628280-24-003796:note_history:19]
| July 1, 2023 | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |  | 2029 Notes (4) |  | Total |
| Principal | $ | 323.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,837.8 |  |
| Unamortized debt discount and debt issuance costs | (11.5) |  |  | (4.1) |  |  | (5.5) |  |  | (5.1) |  |  | (26.2) |  |
| Net carrying amount of the liability component | $ | 311.6 |  |  | $ | 1,045.9 |  |  | $ | 855.5 |  |  | $ | 598.6 |  |  | $ | 2,811.6 |  |

- removed (2024-05-07):
[0001628280-24-003796:note_history:20]
(1) If the closing price of our stock exceeds $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of any future fiscal quarter, our 2024 Notes would become convertible at the option of the holders during the next fiscal quarter. The 2024 Notes are classified as current liabilities as the debt will mature on March 15, 2024.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-07):
[0001628280-24-020767:note_history:21]
The entire 2029 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of March 30, 2024 and July 1, 2023, measured at amortized cost.
  (was, 2024-02-08, similarity 0.9716):
[0001628280-24-003796:note_history:21]
The entire 2029 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of December 30, 2023 and July 1, 2023, measured at amortized cost.

- added (2024-05-07):
[0001628280-24-020767:note_history:22]
The 2028 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year. The 2028 Notes will mature on June 15, 2028, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

- changed (2024-05-07):
[0001628280-24-020767:note_history:23]
•upon the occurrence of specified corporate events, as specified in the 2028 Indenture.
  (was, 2024-02-08, similarity 0.9941):
[0001628280-24-003796:note_history:23]
•upon the occurrence of specified corporate events, as specified in the 2028 Indentures.

- changed (2024-05-07):
[0001628280-24-020767:note_history:24]
We initially bifurcated the principal amount of the 2028 Notes into liability and equity components. The liability component of the 2028 Notes was initially valued at $629.8 million based on the contractual cash flow discounted at an appropriate comparable market on non-convertible debt borrowing rate at the date of issuance, which was 5.7%, with the equity component representing the residual amount of the proceeds of $231.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2028 Notes were accounted for as a single liability measured at amortized cost. The entire 2028 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of March 30, 2024 and July 1, 2023, measured at amortized cost.
  (was, 2024-02-08, similarity 0.9914):
[0001628280-24-003796:note_history:24]
We initially bifurcated the principal amount of the 2028 Notes into liability and equity components. The liability component of the 2028 Notes was initially valued at $629.8 million based on the contractual cash flow discounted at an appropriate comparable market on non-convertible debt borrowing rate at the date of issuance, which was 5.7%, with the equity component representing the residual amount of the proceeds of $231.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2028 Notes were accounted for as a single liability measured at amortized cost. The entire 2028 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of December 30, 2023 and July 1, 2023, measured at amortized cost.

- changed (2024-05-07):
[0001628280-24-020767:note_history:25]
We initially bifurcated the principal amount of the 2026 Notes into liability and equity components. The liability component of the 2026 Notes was initially valued at $734.8 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 5.8% with the equity component representing the residual amount of the proceeds of $315.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2026 Notes were accounted for as a single liability measured at amortized cost. The entire 2026 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of March 30, 2024 and July 1, 2023, measured at amortized cost.
  (was, 2024-02-08, similarity 0.9913):
[0001628280-24-003796:note_history:25]
We initially bifurcated the principal amount of the 2026 Notes into liability and equity components. The liability component of the 2026 Notes was initially valued at $734.8 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 5.8% with the equity component representing the residual amount of the proceeds of $315.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2026 Notes were accounted for as a single liability measured at amortized cost. The entire 2026 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of December 30, 2023 and July 1, 2023, measured at amortized cost.

- changed (2024-05-07):
[0001628280-24-020767:note_history:26]
In March 2017, we issued $450.0 million in aggregate principal amount of 0.25% convertible senior notes due in 2024 (the “2024 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes were governed by an indenture between the Company, as the issuer, and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2024 Indenture”). The 2024 Notes were unsecured and did not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.
  (was, 2024-02-08, similarity 0.9648):
[0001628280-24-003796:note_history:26]
In March 2017, we issued $450.0 million in aggregate principal amount of 0.25% convertible senior notes due in 2024 (the “2024 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2024 Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

- added (2024-05-07):
[0001628280-24-020767:note_history:27]
The 2024 Notes bore interest at a rate of 0.25% per year. Interest on the 2024 Notes was payable semi-annually in arrears on March 15 and September 15 of each year. The 2024 Notes matured on March 15, 2024.

- changed (2024-05-07):
[0001628280-24-020767:note_history:28]
The initial conversion rate of the 2024 Notes was 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which was equivalent to an initial conversion price of approximately $60.62 per share. The conversion rate was subject to adjustment upon the occurrence of certain specified events but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2024 Indenture) or our issuance of a notice of redemption, we were required to, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elected to convert the 2024 Notes in connection with such make-whole fundamental change or notice of redemption.
  (was, 2024-02-08, similarity 0.979):
[0001628280-24-003796:note_history:28]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share. The conversion rate is subject to adjustment upon the occurrence of certain specified events but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2024 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2024 Notes in connection with such make-whole fundamental change or notice of redemption.

- changed (2024-05-07):
[0001628280-24-020767:note_history:29]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter was greater than or equal to 130% of the applicable conversion price, or $78.80 on each applicable trading day;
  (was, 2024-02-08, similarity 0.9963):
[0001628280-24-003796:note_history:29]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price, or $78.80 on each applicable trading day;

- changed (2024-05-07):
[0001628280-24-020767:note_history:30]
On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders could convert their 2024 Notes at any time. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2024 Indenture), we were required to, in certain circumstances, increase the conversion rate by a number of additional shares set forth in the 2024 Indenture for a holder that elected to convert 2024 Notes in connection with such make-whole fundamental change.
  (was, 2024-02-08, similarity 0.9715):
[0001628280-24-003796:note_history:30]
On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2024 Notes at any time. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2024 Indenture), we will, in certain circumstances, increase the conversion rate by a number of additional shares set forth in the 2024 Indenture for a holder that elects to convert 2024 Notes in connection with such make-whole fundamental change.

- changed (2024-05-07):
[0001628280-24-020767:note_history:31]
We could not redeem the 2024 Notes prior to their maturity date and no sinking fund was provided for the 2024 Notes. Upon the occurrence of a fundamental change (as defined in the 2024 Indenture), holders could require us to repurchase all or a portion of their 2024 Notes for cash at a price equal to 100% of the principal amount of the 2024 Notes to be repurchased, plus any accrued and unpaid interest.
  (was, 2024-02-08, similarity 0.856):
[0001628280-24-003796:note_history:31]
We may not redeem the 2024 Notes prior to their maturity date and no sinking fund is provided for the 2024 Notes. Upon the occurrence of a fundamental change (as defined in the 2024 Indenture), holders may require us to repurchase all or a portion of their 2024 Notes for cash at a price equal to 100% of the principal amount of the 2024 Notes to be repurchased, plus any accrued and unpaid interest.

- changed (2024-05-07):
[0001628280-24-020767:note_history:32]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. We incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. We amortized the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes was 5.4% per year.
  (was, 2024-02-08, similarity 0.9981):
[0001628280-24-003796:note_history:32]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. We incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. We amortize the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes is 5.4% per year.

- added (2024-05-07):
[0001628280-24-020767:note_history:33]
During fiscal 2017, we satisfied the TMA settlement condition. As such, the value of the conversion option was no longer marked-to-market and was reclassified to additional paid-in capital within stockholders’ equity on our condensed consolidated balance sheets. The value of the conversion option at the time of issuance was treated as an original issue discount for purposes of accounting for the debt component of the 2024 Notes. The debt component accreted up to the original amount over the term of the debt. The adoption of ASU 2020-06 did not change the presentation of the 2024 Notes, as the conversion feature associated with the 2024 Notes was classified within stockholders’ equity.

- changed (2024-05-07):
[0001628280-24-020767:note_history:34]
Concurrent with the issuance of the 2029 Notes in June 2023, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 2024 Notes, which we accounted for as an extinguishment of liability. $13.5 million of the $132.8 million repurchase price was allocated to the conversion feature of the repurchased 2024 Notes, representing the fair value of the conversion feature at the date of the repurchase, and was recognized as a reduction of the stockholders’ equity. Additionally, since issuing the 2024 Notes, we converted a total of approximately $1.9 million of principal amount of the 2024 Notes, with less than $0.1 million of principle amount converted during the three and nine months ended March 30, 2024.
  (was, 2024-02-08, similarity 0.7646):
[0001628280-24-003796:note_history:34]
Concurrent with the issuance of the 2029 Notes in June 2023, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 2024 Notes, which we accounted for as an extinguishment of liability. $13.5 million of the $132.8 million repurchase price was allocated to the conversion feature of the repurchased 2024 Notes, representing the fair value of the conversion feature at the date of the repurchase, and was recognized as a reduction of the stockholders’ equity. Additionally, since issuing the 2024 Notes, we have converted a total of approximately $1.9 million principal amount of the 2024 Notes. The remaining principal amount was $323.1 million as of December 30, 2023 and July 1, 2023, recorded as convertible notes, current in our consolidated balance sheets, as the 2024 Notes will mature on March 15, 2024.

- added (2024-05-07):
[0001628280-24-020767:note_history:35]
On March 15, 2024, the 2024 Notes maturity date, we fully repaid the remaining principal amount of $323.1 million. The conversion feature previously classified within stockholder’s equity was fully amortized as of the maturity date.

- changed (2024-05-07):
[0001628280-24-020767:note_history:36]
| March 30, 2024 |  |  | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | Total |  |  |  |  |  |
| Principal |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,514.7 |  |  |  |  |  |  |
| Unamortized debt discount and debt issuance costs |  |  | (3.2) |  |  | (4.5) |  |  | (4.6) |  |  | (12.3) |  |  |  |  |  |  |
| Net carrying amount of the liability component |  |  | $ | 1,046.8 |  |  | $ | 856.5 |  |  | $ | 599.1 |  |  | $ | 2,502.4 |  |  |  |  |  |  |
  (was, 2024-02-08, similarity 0.7796):
[0001628280-24-003796:note_history:36]
| December 30, 2023 | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |  | 2029 Notes (4) |  | Total |  |  |  |  |  |
| Principal | $ | 323.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,837.8 |  |  |  |  |  |  |
| Unamortized debt discount and debt issuance costs | (3.4) |  |  | (3.5) |  |  | (4.8) |  |  | (4.7) |  |  | (16.4) |  |  |  |  |  |  |
| Net carrying amount of the liability component | $ | 319.7 |  |  | $ | 1,046.5 |  |  | $ | 856.2 |  |  | $ | 599.0 |  |  | $ | 2,821.4 |  |  |  |  |  |  |

- changed (2024-05-07):
[0001628280-24-020767:note_history:37]
| July 1, 2023 | 2024 Notes |  | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | Total |
| Principal | $ | 323.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,837.8 |  |
| Unamortized debt discount and debt issuance costs | (11.5) |  |  | (4.1) |  |  | (5.5) |  |  | (5.1) |  |  | (26.2) |  |
| Net carrying amount of the liability component | $ | 311.6 |  |  | $ | 1,045.9 |  |  | $ | 855.5 |  |  | $ | 598.6 |  |  | $ | 2,811.6 |  |
  (was, 2024-02-08, similarity 0.9945):
[0001628280-24-003796:note_history:37]
| July 1, 2023 | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |  | 2029 Notes (4) |  | Total |
| Principal | $ | 323.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,837.8 |  |
| Unamortized debt discount and debt issuance costs | (11.5) |  |  | (4.1) |  |  | (5.5) |  |  | (5.1) |  |  | (26.2) |  |
| Net carrying amount of the liability component | $ | 311.6 |  |  | $ | 1,045.9 |  |  | $ | 855.5 |  |  | $ | 598.6 |  |  | $ | 2,811.6 |  |

- changed (2024-05-07):
[0001628280-24-020767:note_history:38]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |  | March 30, 2024 |  | April 1, 2023 |
| Contractual interest expense | $ | 4.9 |  |  | $ | 2.7 |  |  | $ | 14.6 |  |  | $ | 8.1 |  |
| Amortization of the debt discount and debt issuance costs | 4.1 |  |  | 6.0 |  |  | 13.8 |  |  | 17.9 |  |
| Total interest expense | $ | 9.0 |  |  | $ | 8.7 |  |  | $ | 28.4 |  |  | $ | 26.0 |  |
  (was, 2024-02-08, similarity 0.8402):
[0001628280-24-003796:note_history:38]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2023 |  | December 31, 2022 |  | December 30, 2023 |  | December 31, 2022 |
| Contractual interest expense | $ | 4.9 |  |  | $ | 2.7 |  |  | $ | 9.7 |  |  | $ | 5.4 |  |
| Amortization of the debt discount and debt issuance costs | 4.8 |  |  | 6.2 |  |  | 9.7 |  |  | 11.9 |  |
| Total interest expense | $ | 9.7 |  |  | $ | 8.9 |  |  | $ | 19.4 |  |  | $ | 17.3 |  |

- changed (2024-05-07):
[0001628280-24-020767:note_history:39]
The future interest and principal payments related to our convertible notes are as follows as of March 30, 2024 (in millions):
  (was, 2024-02-08, similarity 0.9633):
[0001628280-24-003796:note_history:39]
The future interest and principal payments related to our convertible notes are as follows as of December 30, 2023 (in millions):

- added (2024-05-07):
[0001628280-24-020767:note_history:40]
| Fiscal Years |  |  | 2026 Notes |  | 2028 Notes |  | 2029 Notes |  | Total |
| 2024 |  |  | $ | 2.6 |  |  | $ | 2.2 |  |  | $ | 4.6 |  |  | $ | 9.4 |  |
| 2025 |  |  | 5.3 |  |  | 4.3 |  |  | 9.1 |  |  | 18.7 |  |
| 2026 |  |  | 5.3 |  |  | 4.3 |  |  | 9.1 |  |  | 18.7 |  |
| 2027 |  |  | 1,052.5 |  |  | 4.3 |  |  | 9.1 |  |  | 1,065.9 |  |
| 2028 |  |  | — |  |  | 865.3 |  |  | 9.1 |  |  | 874.4 |  |
| Thereafter |  |  | — |  |  | — |  |  | 617.1 |  |  | 617.1 |  |
| Total payments |  |  | $ | 1,065.7 |  |  | $ | 880.4 |  |  | $ | 658.1 |  |  | $ | 2,604.2 |  |

- removed (2024-05-07):
[0001628280-24-003796:note_history:41]
The 2028 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on June 15, 2022. The 2028 Notes will mature on June 15, 2028, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

- removed (2024-05-07):
[0001628280-24-003796:note_history:42]
The 2024 Notes bear interest at a rate of 0.25% per year. Interest on the 2024 Notes is payable semi-annually in arrears on March 15 and September 15 of each year. The 2024 Notes will mature on March 15, 2024, unless earlier repurchased by us or converted pursuant to their terms.

- removed (2024-05-07):
[0001628280-24-003796:note_history:43]
During fiscal 2017, we satisfied the TMA settlement condition. As such, the value of the conversion option is no longer marked-to-market and was reclassified to additional paid-in capital within stockholders’ equity on our condensed consolidated balance sheets. The value of the conversion option at the time of issuance is treated as an original issue discount for purposes of accounting for the debt component of the 2024 Notes. The debt component will accrete up to the original amount over the expected term of the debt. The adoption of ASU 2020-06 did not change the presentation of the 2024 Notes, as the conversion feature associated with the 2024 Notes continues to be classified within stockholders’ equity.

- removed (2024-05-07):
[0001628280-24-003796:note_history:44]
(1) If the closing price of our stock exceeds $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of any future fiscal quarter, our 2024 Notes would become convertible at the option of the holders during the next fiscal quarter. The 2024 Notes are classified as current liabilities as the debt will mature on March 15, 2024.

- removed (2024-05-07):
[0001628280-24-003796:note_history:45]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | 2028 Notes |  | 2029 Notes |  | Total |
| 2024 | $ | 323.7 |  |  | $ | 2.6 |  |  | $ | 2.2 |  |  | $ | 4.5 |  |  | $ | 333.0 |  |
| 2025 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.1 |  |  | 18.7 |  |
| 2026 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.1 |  |  | 18.7 |  |
| 2027 | — |  |  | 1,052.5 |  |  | 4.3 |  |  | 9.1 |  |  | 1,065.9 |  |
| 2028 | — |  |  | — |  |  | 865.3 |  |  | 9.1 |  |  | 874.4 |  |
| Thereafter | — |  |  | — |  |  | — |  |  | 617.1 |  |  | 617.1 |  |
| Total payments | $ | 323.7 |  |  | $ | 1,065.7 |  |  | $ | 880.4 |  |  | $ | 658.0 |  |  | $ | 2,927.8 |  |


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-07):
[0001628280-24-020767:note_history:46]
|  | Continuous Loss Position for More Than 12 Months |  | Continuous Loss Position for Less Than 12 Months |  | Gross Unrealized Losses |  |  |  |  |  |  |  |  |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |  |
| March 30, 2024: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 3.5 |  |  | $ | — |  |  | $ | 89.2 |  |  | $ | (0.4) |  |  | $ | (0.4) |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 13.1 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 21.6 |  |  | (0.1) |  |  | 175.7 |  |  | (0.7) |  |  | (0.8) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 2.0 |  |  | — |  |  | 117.6 |  |  | (0.7) |  |  | (0.7) |  |  |  |  |  |  |  |  |  |
| Total | $ | 27.1 |  |  | $ | (0.1) |  |  | $ | 395.6 |  |  | $ | (1.8) |  |  | $ | (1.9) |  |  |  |  |  |  |  |  |  |
| July 1, 2023: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 39.6 |  |  | $ | (0.4) |  |  | $ | 170.6 |  |  | $ | (1.3) |  |  | $ | (1.7) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | — |  |  | 7.7 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 128.5 |  |  | (0.2) |  |  | (0.2) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 93.6 |  |  | (1.2) |  |  | 358.9 |  |  | (2.7) |  |  | (3.9) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 50.8 |  |  | (0.6) |  |  | 221.4 |  |  | (1.4) |  |  | (2.0) |  |  |  |  |  |  |  |  |  |
| Total | $ | 184.0 |  |  | $ | (2.2) |  |  | $ | 887.1 |  |  | $ | (5.6) |  |  | $ | (7.8) |  |  |  |  |  |  |  |  |  |
  (was, 2024-02-08, similarity 0.9658):
[0001628280-24-003796:note_history:46]
|  | Continuous Loss Position for More Than 12 Months |  | Continuous Loss Position for Less Than 12 Months |  | Gross Unrealized Losses |  |  |  |  |  |  |  |  |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |  |
| December 30, 2023: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 5.0 |  |  | $ | — |  |  | $ | 113.5 |  |  | $ | (0.4) |  |  | $ | (0.4) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | — |  |  | 4.0 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 25.0 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 40.8 |  |  | (0.1) |  |  | 231.3 |  |  | (0.7) |  |  | (0.8) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 4.5 |  |  | — |  |  | 167.0 |  |  | (0.5) |  |  | (0.5) |  |  |  |  |  |  |  |  |  |
| Total | $ | 50.3 |  |  | $ | (0.1) |  |  | $ | 540.8 |  |  | $ | (1.6) |  |  | $ | (1.7) |  |  |  |  |  |  |  |  |  |
| July 1, 2023: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 39.6 |  |  | $ | (0.4) |  |  | $ | 170.6 |  |  | $ | (1.3) |  |  | $ | (1.7) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | — |  |  | 7.7 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 128.5 |  |  | (0.2) |  |  | (0.2) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 93.6 |  |  | (1.2) |  |  | 358.9 |  |  | (2.7) |  |  | (3.9) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 50.8 |  |  | (0.6) |  |  | 221.4 |  |  | (1.4) |  |  | (2.0) |  |  |  |  |  |  |  |  |  |
| Total | $ | 184.0 |  |  | $ | (2.2) |  |  | $ | 887.1 |  |  | $ | (5.6) |  |  | $ | (7.8) |  |  |  |  |  |  |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-07):
[0001628280-24-020767:note_history:47]
The future interest and principal payments related to our convertible notes are as follows as of March 30, 2024 (in millions):
  (was, 2024-02-08, similarity 0.9633):
[0001628280-24-003796:note_history:47]
The future interest and principal payments related to our convertible notes are as follows as of December 30, 2023 (in millions):

- added (2024-05-07):
[0001628280-24-020767:note_history:48]
| Fiscal Years |  |  | 2026 Notes |  | 2028 Notes |  | 2029 Notes |  | Total |
| 2024 |  |  | $ | 2.6 |  |  | $ | 2.2 |  |  | $ | 4.6 |  |  | $ | 9.4 |  |
| 2025 |  |  | 5.3 |  |  | 4.3 |  |  | 9.1 |  |  | 18.7 |  |
| 2026 |  |  | 5.3 |  |  | 4.3 |  |  | 9.1 |  |  | 18.7 |  |
| 2027 |  |  | 1,052.5 |  |  | 4.3 |  |  | 9.1 |  |  | 1,065.9 |  |
| 2028 |  |  | — |  |  | 865.3 |  |  | 9.1 |  |  | 874.4 |  |
| Thereafter |  |  | — |  |  | — |  |  | 617.1 |  |  | 617.1 |  |
| Total payments |  |  | $ | 1,065.7 |  |  | $ | 880.4 |  |  | $ | 658.1 |  |  | $ | 2,604.2 |  |

- removed (2024-05-07):
[0001628280-24-003796:note_history:49]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | 2028 Notes |  | 2029 Notes |  | Total |
| 2024 | $ | 323.7 |  |  | $ | 2.6 |  |  | $ | 2.2 |  |  | $ | 4.5 |  |  | $ | 333.0 |  |
| 2025 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.1 |  |  | 18.7 |  |
| 2026 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.1 |  |  | 18.7 |  |
| 2027 | — |  |  | 1,052.5 |  |  | 4.3 |  |  | 9.1 |  |  | 1,065.9 |  |
| 2028 | — |  |  | — |  |  | 865.3 |  |  | 9.1 |  |  | 874.4 |  |
| Thereafter | — |  |  | — |  |  | — |  |  | 617.1 |  |  | 617.1 |  |
| Total payments | $ | 323.7 |  |  | $ | 1,065.7 |  |  | $ | 880.4 |  |  | $ | 658.0 |  |  | $ | 2,927.8 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2024-05-07):
[0001628280-24-020767:note_history:50]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |  | March 30, 2024 |  | April 1, 2023 |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Cloud & Networking | $ | 313.8 |  |  | 85.6 | % |  | 293.0 |  |  | 76.4 | % |  | $ | 830.2 |  |  | 79.0 | % |  | $ | 1,036.0 |  |  | 74.2 | % |
| Industrial Tech | 52.7 |  |  | 14.4 | % |  | 90.4 |  |  | 23.6 | % |  | 220.7 |  |  | 21.0 | % |  | 360.2 |  |  | 25.8 | % |
| Net revenue | $ | 366.5 |  |  | 100.0 | % |  | $ | 383.4 |  |  | 100.0 | % |  | $ | 1,050.9 |  |  | 100.0 | % |  | $ | 1,396.2 |  |  | 100.0 | % |

- added (2024-05-07):
[0001628280-24-020767:note_history:51]
| Contract balances |  | Balance sheet location |  | March 30, 2024 |  | July 1, 2023 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 229.8 |  |  | $ | 246.1 |  |  | $ | (16.3) |  |  | (6.6) | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | 0.8 |  |  | $ | 2.1 |  |  | $ | (1.3) |  |  | (61.9) | % |

- removed (2024-05-07):
[0001628280-24-003796:note_history:52]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2023 |  | December 31, 2022 |  | December 30, 2023 |  | December 31, 2022 |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Cloud & Networking | $ | 286.7 |  |  | 78.2 | % |  | $ | 382.9 |  |  | 75.7 | % |  | $ | 516.4 |  |  | 75.5 | % |  | $ | 743.0 |  |  | 73.4 | % |
| Industrial Tech | 80.1 |  |  | 21.8 | % |  | 123.1 |  |  | 24.3 | % |  | 168.0 |  |  | 24.5 | % |  | 269.8 |  |  | 26.6 | % |
| Net revenue | $ | 366.8 |  |  | 100.0 | % |  | $ | 506.0 |  |  | 100.0 | % |  | $ | 684.4 |  |  | 100.0 | % |  | $ | 1,012.8 |  |  | 100.0 | % |

- removed (2024-05-07):
[0001628280-24-003796:note_history:53]
| Contract balances |  | Balance sheet location |  | December 30, 2023 |  | July 1, 2023 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 248.3 |  |  | $ | 246.1 |  |  | $ | 2.2 |  |  | 0.9 | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | 0.9 |  |  | $ | 2.1 |  |  | $ | (1.2) |  |  | (57.1) | % |
