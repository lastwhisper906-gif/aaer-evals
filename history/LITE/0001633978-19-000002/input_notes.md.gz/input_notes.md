# LITE notes — 0001633978-19-000002


## lite:AssetAcquisitionDisclosureTextBlock

[0001633978-19-000002:notes:1]
Note 7. Asset Acquisition

[0001633978-19-000002:notes:2]
On March 30, 2018, we entered into a Transition Services Agreement (“TSA”) with one of our contract manufacturers to wind down the production of our products at their facility in China and to facilitate an orderly transition of manufacturing to either our manufacturing facility in Thailand or our third party contract manufacturers, including the purchase of the manufacturing equipment. Under the terms of the TSA, we are required to pay $5.3 million in cash upon completion of certain milestones related to the purchase of equipment. During the six months ended December 29, 2018, we paid $0.7 million and accrued an additional $2.0 million for the manufacturing equipment acquired under this TSA. This amount is included in machinery and equipment within property, plant and equipment in our condensed consolidated balance sheet as of December 29, 2018.

[0001633978-19-000002:notes:3]
We are also required to share cost of retention and severance, and to reimburse for certain other direct and indirect costs incurred by our contract manufacturer for transition services provided. These costs are expensed as incurred.


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001633978-19-000002:notes:4]
[same as prior period, unchanged from 0001628280-18-013240:notes:4]

[0001633978-19-000002:notes:5]
The preparation of the condensed consolidated financial statements in accordance with U.S. generally accepted accounting principles (“GAAP”) requires management to make estimates and assumptions that affect the amounts reported in our condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are inventory valuation, revenue recognition, income taxes, long-lived asset valuation, warranty, derivative liability, business combinations and goodwill.

[0001633978-19-000002:notes:6]
On December 10, 2018, the Company completed its merger with Oclaro, Inc. (“Oclaro”), a provider of optical components and modules for the long-haul, metro and data center markets. Our condensed consolidated financial statements include the operating results of Oclaro for the period from the date of acquisition through December 29, 2018. Refer to “Note 5. Business Combination” for further discussion of the merger.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001633978-19-000002:notes:7]
The supplemental pro forma financial information for the periods presented is as follows (in millions):

[0001633978-19-000002:notes:8]
|  | Six Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |
| Net revenue | $ | 941.8 |  |  | $ | 942.7 |  |
| Net income | 32.7 |  |  | 168.4 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001633978-19-000002:notes:9]
Note 5. Business Combination

[0001633978-19-000002:notes:10]
On December 10, 2018, we acquired all of the outstanding common stock of Oclaro, a provider of optical components and modules for the long-haul, metro and data center markets. Oclaro’s products provide differentiated solutions for optical networks and high-speed interconnects driving the next wave of streaming video, cloud computing, application virtualization and other bandwidth-intensive and high-speed applications. This acquisition strengthens our product portfolio, including gaining Oclaro’s leading indium phosphide laser and photonic integrated circuit and coherent component and module capabilities; broadens our revenue mix; and positions us strongly to meet the future needs of our customers.

[0001633978-19-000002:notes:11]
Pursuant to the merger agreement, Prota Merger Sub, Inc., a Delaware corporation and a wholly owned subsidiary of Lumentum (“Merger Sub”), merged with and into Oclaro (the “Merger”), with Oclaro surviving the Merger. Each outstanding share of Oclaro common stock, par value $0.01 per share, was automatically converted into the right to receive the following consideration (collectively, the “Merger Consideration”), without interest:

[0001633978-19-000002:notes:12]
•$5.60 in cash (the “Cash Consideration”) and;

[0001633978-19-000002:notes:13]
| • | 0.0636 of a share of Lumentum common stock, par value $0.001 per share (the “Exchange Ratio”). |

[0001633978-19-000002:notes:14]
The total fair value of consideration given in connection with the acquisition of Oclaro consisted of the following:

[0001633978-19-000002:notes:15]
|  | Shares | Per Share | Total Consideration(in millions) |
| Cash paid for outstanding Oclaro common stock |  |  | $ | 964.8 |  |
| Lumentum common shares issued to Oclaro stockholders | 10,941,436 |  | $ | 41.80 |  | 457.4 |  |
| Replacement equity awards for Oclaro equity awards |  |  | 2.7 |  |
| Total consideration |  |  | $ | 1,424.9 |  |

[0001633978-19-000002:notes:16]
Each Oclaro restricted stock unit award (“Oclaro RSU”) that did not become vested at the close of the transaction was converted into a Lumentum restricted stock unit award (a “Lumentum RSU”) with similar terms and conditions, including vesting, that were applicable to such Oclaro RSU, at a ratio of one Oclaro share to 0.1933 shares of Lumentum common stock. The 0.1933 ratio was determined based on the sum of (i) the 0.0636 shares of common stock received by Oclaro common stockholders for every one share of Oclaro common stock, plus (ii) the $5.60 per share received by Oclaro common stockholders, divided by $43.189 (Lumentum’s average closing price for the 10 trading days ending on December 4, 2018, the third trading day prior to the Closing Date).

[0001633978-19-000002:notes:17]
Each Oclaro stock option (“Oclaro Option”), whether vested or unvested, was converted into a Lumentum stock option (“Lumentum Option”) with similar terms and conditions, including vesting, that were applicable to such Oclaro Option, except that (i) the number of shares subject to the Lumentum Option equals the number of Oclaro shares subject to such Oclaro Option multiplied by 0.1933 and (ii) the exercise price of the Lumentum Option equals the exercise price per share of the Oclaro Option divided by 0.1933. Any Oclaro Option that was held by non-employees was cancelled and converted into the right to receive the Merger Consideration for each net option share covered by such Oclaro Option, subject to applicable withholding taxes.

[0001633978-19-000002:notes:18]
In addition, each Oclaro restricted stock award (“Oclaro Restricted Stock Award”) and Oclaro RSU that became vested with the close of the transaction was converted into the right to receive the Merger Consideration.

[0001633978-19-000002:notes:19]
The total transaction consideration was $1.4 billion, which was funded by the issuance of Lumentum common stock, new debt (refer to “Note 6. Term Loan Facility”), and cash balances of the combined company. We also recorded $14.4 million and $15.9 million, respectively, in acquisition-related costs in each of the three and six months ended December 29, 2018, representing professional and other direct acquisition costs. These costs are recorded within selling, general and administrative operating expense and within interest and other income (expense), net in our condensed consolidated statements of operations. The Company also incurred $9.3 million of debt financing costs which has been recorded as a contra liability. “Refer to Note 6. Term Loan Facility.”

[0001633978-19-000002:notes:20]
From the acquisition date, Oclaro contributed $29.6 million of our consolidated net revenue for each of the three and six months ended December 29, 2018. Due to the continued integration of the combined businesses, it is impractical to determine Oclaro’s contribution to our net income.

[0001633978-19-000002:notes:21]
We allocated the fair value of the purchase consideration to the tangible assets, liabilities and intangible assets acquired, including in-process research and development, or IPR&D, generally based on their estimated fair values. The excess purchase price over those fair values is recorded as goodwill. IPR&D is initially capitalized at fair value as an intangible asset with an indefinite life  and assessed for impairment thereafter. When an IPR&D project is completed, the IPR&D is reclassified as an amortizable purchased intangible asset and amortized over the asset’s estimated useful life.  Our valuation assumptions of acquired assets and assumed liabilities require significant estimates, especially with respect to intangible assets. Our preliminary allocation of the purchase price of Oclaro, based on the estimated fair values of the assets acquired and liabilities assumed as of the acquisition date, is as follows (in millions):

[0001633978-19-000002:notes:22]
|  | Purchase Price Allocation |
| Cash and cash equivalents | $ | 345.0 |  |
| Accounts receivable, net | 68.0 |  |
| Inventories | 153.2 |  |
| Prepayments and other current assets | 33.7 |  |
| Property, plant and equipment, net | 128.6 |  |
| Intangibles | 444.0 |  |
| Deferred income tax asset | 54.1 |  |
| Other non-current assets | 16.6 |  |
| Accounts payable | (57.8 | ) |
| Accrued payroll and related expenses | (11.4 | ) |
| Accrued expenses | (8.3 | ) |
| Other current liabilities | (8.1 | ) |
| Deferred tax liability | (55.8 | ) |
| Other non-current liabilities | (10.3 | ) |
| Goodwill | 333.4 |  |
| Total purchase price | $ | 1,424.9 |  |

[0001633978-19-000002:notes:23]
The merger consideration allocation set forth herein is preliminary and may be revised as additional information becomes available during the measurement period which could be up to 12 months from the closing date of the acquisition. Any such revisions or changes may be material. The primary areas of the preliminary purchase price allocation that are not yet finalized are certain tax matters, intangible assets, and identification of contingencies.

[0001633978-19-000002:notes:24]
Goodwill and intangibles has been assigned to the OpComms segment. The preliminary goodwill of $333.4 million arising from the acquisition is attributed to the expected synergies, including future cost efficiencies, and other benefits that are expected to be generated by combining Lumentum and Oclaro. Substantially all of the goodwill recognized is not expected to be deductible for tax purposes. See “Note 14. Goodwill and Other Intangible Assets” for more information on goodwill and IPR&D.

[0001633978-19-000002:notes:25]
During the three and six months ended December 29, 2018, we recorded $20.9 million in restructuring and stock-based compensation expense in our condensed consolidated statements of operations, primarily attributable to severance and employee related benefits associated with Oclaro’s executive severance and retention agreements. These retention agreements provide, under certain circumstances, for payments and benefits upon an involuntary termination of employment, including following a change in control of Oclaro. The payments and benefits payable under these arrangements in the event of a change in control of Oclaro are subject to a “double trigger,” meaning that both a change in control of Oclaro and a subsequent involuntary termination of employment are required by Lumentum. In other words, the change in control of Oclaro does not by itself trigger any payments or benefits. Instead, payments and benefits are paid only if the employment of the employee is subsequently terminated without “cause” (or the employee resigns for “good reason”) during a specified period following the change in control. The total expense incurred by us is $20.9 million for the three and six months ended December 29, 2018, out of which $5.7 million relates to cash severance as part of our restructuring expense which is recorded within restructuring and related charges in our condensed consolidated statements of operations (refer to “Note 15. Restructuring and Related Charges”) and $15.2 million relates to the acceleration of equity awards which is recorded within both cost of sales and selling, general and administrative expense, in our condensed consolidated statements of operations (refer to “Note 17. Stock-Based Compensation and Stock Plans”).

[0001633978-19-000002:notes:26]
Supplemental Pro Forma Information

[0001633978-19-000002:notes:27]
The supplemental pro forma financial information presented below is for illustrative purposes only and is not necessarily indicative of the financial position or results of operations that would have been realized if the acquisition had been completed on the date indicated, does not reflect synergies that might have been achieved, nor is it indicative of future operating results or financial position. The pro forma adjustments are based upon currently available information and certain assumptions we believe are reasonable under the circumstances.

[0001633978-19-000002:notes:28]
The following supplemental pro forma information presents the combined results of operations for the six months ended December 29, 2018 and December 30, 2017, as if Oclaro had been acquired as of the beginning of fiscal year 2018. The supplemental pro forma information includes adjustments to amortization and depreciation for acquired intangible assets and property and equipment, adjustments to share-based compensation expense, the fair value adjustments on the inventories acquired, transaction costs, interest expense and amortization of the term loan debt issuance costs. For fiscal year 2018, nonrecurring pro forma adjustments directly attributable to the Oclaro acquisition included (i) restructuring and stock-based compensation expense of $20.9 million, (ii) the purchase accounting effect of inventories acquired of $60.3 million and (iii) transaction costs of $23.0 million.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001633978-19-000002:notes:29]
[same as prior period, unchanged from 0001628280-18-013240:notes:6]

[0001633978-19-000002:notes:30]
[same as prior period, unchanged from 0001628280-18-013240:notes:7]

[0001633978-19-000002:notes:31]
Lumentum (“we,” “us,” “our” or the “Company”) is an industry-leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including Optical Communications (“OpComms”) and Lasers for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be Original Equipment Manufacturers (“OEMs”) that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that Network Equipment Manufacturers’ (“NEMs”) customers assemble into communications networking systems, which they sell to network service providers or enterprises with their own networks. Similarly, many of our customers for our Lasers products incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For 3D sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, and gaming who then integrate our devices within their products, for eventual resale to consumers and also into other industrial applications.

[0001633978-19-000002:notes:32]
[same as prior period, unchanged from 0001628280-18-013240:notes:16]

[0001633978-19-000002:notes:33]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Our fiscal 2019 is a 52-week year ending on June 29, 2019, with the quarter ended December 29, 2018 being a 13-week quarterly period. Our fiscal 2018 was a 52-week year that ended on June 30, 2018, with the quarter ended December 30, 2017 being a 13-week quarterly period.

[0001633978-19-000002:notes:34]
[same as prior period, unchanged from 0001628280-18-013240:notes:18]

[0001633978-19-000002:notes:35]
[same as prior period, unchanged from 0001628280-18-013240:notes:19]

[0001633978-19-000002:notes:36]
Certain prior period amounts have been reclassified to conform to the current year presentation in the notes to the condensed consolidated financial statements. The reclassification of the prior period amounts did not impact previously reported condensed consolidated financial statements, except for the presentation of net income attributable to common stockholders and net income per share attributable to common stockholders for the three and six months ended December 30, 2017. The adjustments are a result of using the two-class method to compute earnings per share for the impact of our Series A Preferred Stock outstanding. Refer to “Note 3. Earnings Per Share” for further details.

[0001633978-19-000002:notes:37]
[same as prior period, unchanged from 0001628280-18-013240:notes:21]

[0001633978-19-000002:notes:38]
The accompanying condensed consolidated financial statements and accompanying related notes should be read in conjunction with the audited consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended June 30, 2018.

[0001633978-19-000002:notes:39]
Except for the accounting policies for (i) revenue recognition and the adoption of Accounting Standards Update (“ASU”) 2014-09, Revenue from Contracts with Customers (Topic 606), and (ii) the change in our functional currency, from certain foreign currencies to the reporting currency, there have been no significant changes to our significant accounting policies as of and for the six months ended December 29, 2018, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the year ended June 30, 2018.

[0001633978-19-000002:notes:40]
[same as prior period, unchanged from 0001628280-18-013240:notes:24]

[0001633978-19-000002:notes:41]
[same as prior period, unchanged from 0001628280-18-013240:notes:25]

[0001633978-19-000002:notes:42]
[same as prior period, unchanged from 0001628280-18-013240:notes:26]

[0001633978-19-000002:notes:43]
[same as prior period, unchanged from 0001628280-18-013240:notes:27]

[0001633978-19-000002:notes:44]
[same as prior period, unchanged from 0001628280-18-013240:notes:28]

[0001633978-19-000002:notes:45]
[same as prior period, unchanged from 0001628280-18-013240:notes:29]

[0001633978-19-000002:notes:46]
[same as prior period, unchanged from 0001628280-18-013240:notes:30]

[0001633978-19-000002:notes:47]
| • | recognition of revenues when, or as, the contractual performance obligations are satisfied. |

[0001633978-19-000002:notes:48]
The majority of our revenue comes from product sales, consisting of sales of Lasers and OpComms hardware products to our customers. Our revenue contracts generally include only one performance obligation. Revenues are recognized at a point in time when control of the promised goods or services are transferred to our customers upon shipment or delivery, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services. We have entered into vendor managed inventory (“VMI”) programs with our customers. Under these arrangements, we receive purchase orders from our customers, and the inventory is shipped to the VMI location upon receipt of the purchase order. The customer then pulls the inventory from the VMI hub based on its production needs. Revenue under VMI programs is recognized when control transfers to the customer, which is generally once the customer pulls the inventory from the hub.

[0001633978-19-000002:notes:49]
Revenue from all sales types is recognized at the transaction price. The transaction price is determined based on the consideration to which we will be entitled in exchange for transferring goods or services to the customer adjusted for estimated variable consideration, if any. We typically estimate the impact on the transaction price for discounts offered to the customers for early payments on receivables or net of accruals for estimated sales returns. These estimates are based on historical returns, analysis of credit memo data and other known factors. Actual returns could differ from these estimates. We allocate the transaction price to each distinct product based on its relative standalone selling price. The product price as specified on the purchase order is considered the standalone selling price as it is an observable input that depicts the price as if sold to a similar customer in similar circumstances.

[0001633978-19-000002:notes:50]
[same as prior period, unchanged from 0001628280-18-013240:notes:34]

[0001633978-19-000002:notes:51]
If a customer pays consideration, or the Company has a right to an amount of consideration that is unconditional before we transfer a good or service to the customer, those amounts are classified as deferred revenue or deposits received from customers which are included in other current liabilities or other long-term liabilities when the payment is made or it is due, whichever is earlier.

[0001633978-19-000002:notes:52]
[same as prior period, unchanged from 0001628280-18-013240:notes:36]

[0001633978-19-000002:notes:53]
[same as prior period, unchanged from 0001628280-18-013240:notes:37]

[0001633978-19-000002:notes:54]
The following table includes estimated revenue expected to be recognized in the future for backlog related performance obligations that are unsatisfied as of December 29, 2018 (in millions):

[0001633978-19-000002:notes:55]
|  | Less than 1 year | 1-2 years | Greater than 2 years | Total |
| Performance Obligations | $550.1 | $11.0 | $0.3 | $561.4 |

[0001633978-19-000002:notes:56]
[same as prior period, unchanged from 0001628280-18-013240:notes:40]

[0001633978-19-000002:notes:57]
Hardware products regularly include warranties to the end customers such that the product continues to function according to published specifications. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, specific market, product line and geography in which we operate, and what is common in the industry, our warranties can vary and range from six months to five years. These standard warranties are assurance type warranties and do not offer any services in addition to the assurance that the product will continue working as specified. Therefore, warranties are not considered separate performance obligations in the arrangement. Instead, the expected cost of warranty is accrued as expense in accordance with authoritative guidance.

[0001633978-19-000002:notes:58]
[same as prior period, unchanged from 0001628280-18-013240:notes:42]

[0001633978-19-000002:notes:59]
[same as prior period, unchanged from 0001628280-18-013240:notes:43]

[0001633978-19-000002:notes:60]
[same as prior period, unchanged from 0001628280-18-013240:notes:44]

[0001633978-19-000002:notes:61]
[same as prior period, unchanged from 0001628280-18-013240:notes:45]

[0001633978-19-000002:notes:62]
[same as prior period, unchanged from 0001628280-18-013240:notes:46]

[0001633978-19-000002:notes:63]
[same as prior period, unchanged from 0001628280-18-013240:notes:47]

[0001633978-19-000002:notes:64]
The Company records accounts receivable when it has an unconditional right to consideration. Contract liabilities are recorded when cash payments are received or due in advance of performance. Contract liabilities consist of advance payments and deferred revenue, where the Company has unsatisfied performance obligations. Contract liabilities are classified as deferred revenue and customer deposits, and are included in other current liabilities within our condensed consolidated balance sheet. Payment terms vary by customer. The time between invoicing and when payment is due is not significant.

[0001633978-19-000002:notes:65]
The following table reflects the changes in contract balances for the six months ended December 29, 2018 (in millions, except percentages):

[0001633978-19-000002:notes:66]
| Contract balances | Balance sheet location | December 29, 2018 |  | June 30, 2018 |  | Change |  | Percentage Change |
| Accounts receivable, net | Accounts receivable, net | $266.5 |  | $197.1 |  | $69.4 |  | 35.2% |
| Deferred revenue and customer deposits | Other current liabilities | $3.9 |  | $2.8 |  | $1.1 |  | 39.3% |

[0001633978-19-000002:notes:67]
[same as prior period, unchanged from 0001628280-18-013240:notes:52]

[0001633978-19-000002:notes:68]
We disaggregate revenue by geography and by product. Refer to “Note 19. Operating Segments and Geographic Information” for a presentation of disaggregated revenue. We do not present other levels of disaggregation, such as by type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, as this information is not used by our Chief Operating Decision Maker to manage the business.

[0001633978-19-000002:notes:69]
Foreign Currency Translation

[0001633978-19-000002:notes:70]
Concurrent with the acquisition of Oclaro, on December 10, 2018, we established the functional currency for our worldwide operations as the U.S. dollar. The change in our functional currency is a result of significant changes in economic facts and circumstances, primarily the acquisition of Oclaro, a U.S. dollar-denominated functional currency company. The combined business, which requires the integration of our supply chain, manufacturing operations and sales organization, will predominantly use the U.S. dollar, including when negotiating customer and supplier contracts.

[0001633978-19-000002:notes:71]
Translation adjustments reported prior to December 10, 2018, remain as a component of accumulated other comprehensive income in our condensed consolidated balance sheet. The translated values for any non-monetary assets and liabilities as of December 10, 2018 become the new accounting basis for those assets. Accordingly, monetary assets and liabilities denominated in foreign currencies have been remeasured into U.S. dollars using the exchange rates in effect at the balance sheet date. Foreign currency re-measurement gains (losses) are included in interest and other income (expense), net from December 10, 2018.


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001633978-19-000002:notes:72]
Note 9. Cash, Cash Equivalents and Short-term Investments

[0001633978-19-000002:notes:73]
The following table summarizes our cash, cash equivalents and short-term investments by category for the periods presented (in millions):

[0001633978-19-000002:notes:74]
|  | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| December 29, 2018: |  |  |  |  |  |  |  |
| Cash | $ | 294.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 294.4 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | 2.0 |  |  | — |  |  | — |  |  | 2.0 |  |
| Commercial paper | 24.1 |  |  | — |  |  | — |  |  | 24.1 |  |
| Corporate debt securities | 5.0 |  |  | — |  |  | — |  |  | 5.0 |  |
| Money market funds | 4.8 |  |  | — |  |  | — |  |  | 4.8 |  |
| Foreign government bonds | 3.5 |  |  | — |  |  | — |  |  | 3.5 |  |
| U.S. Treasury | 35.6 |  |  | — |  |  | — |  |  | 35.6 |  |
| Asset-backed securities | 1.9 |  |  | — |  |  | — |  |  | 1.9 |  |
| Total cash and cash equivalents | $ | 371.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 371.3 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Commercial paper | $ | 13.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 13.3 |  |
| Asset-backed securities | 60.6 |  |  | — |  |  | (0.1 | ) |  | 60.5 |  |
| Corporate debt securities | 231.4 |  |  | 0.1 |  |  | (1.1 | ) |  | 230.4 |  |
| Municipal bonds | 1.3 |  |  | — |  |  | — |  |  | 1.3 |  |
| Mortgage-backed securities | 2.2 |  |  | — |  |  | — |  |  | 2.2 |  |
| Foreign government bonds | 5.1 |  |  | — |  |  | — |  |  | 5.1 |  |
| Total short-term investments | $ | 313.9 |  |  | $ | 0.1 |  |  | $ | (1.2 | ) |  | $ | 312.8 |  |
| June 30, 2018: |  |  |  |  |  |  |  |
| Cash | $ | 103.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 103.6 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | 3.0 |  |  | — |  |  | — |  |  | 3.0 |  |
| Commercial paper | 112.1 |  |  | — |  |  | — |  |  | 112.1 |  |
| Money market funds | 0.8 |  |  | — |  |  | — |  |  | 0.8 |  |
| U.S. Treasury securities | 143.6 |  |  | — |  |  | — |  |  | 143.6 |  |
| U.S. Agency securities | 34.2 |  |  | — |  |  | — |  |  | 34.2 |  |
| Total cash and cash equivalents | $ | 397.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 397.3 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 7.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 7.5 |  |
| Commercial paper | 10.5 |  |  | — |  |  | — |  |  | 10.5 |  |
| Asset-backed securities | 68.0 |  |  | — |  |  | (0.2 | ) |  | 67.8 |  |
| Corporate debt securities | 220.6 |  |  | 0.1 |  |  | (1.5 | ) |  | 219.2 |  |
| Municipal bonds | 1.6 |  |  | — |  |  | — |  |  | 1.6 |  |
| Mortgage-backed securities | 4.2 |  |  | — |  |  | — |  |  | 4.2 |  |
| Foreign government bonds | 3.4 |  |  | — |  |  | — |  |  | 3.4 |  |
| Total short-term investments | $ | 315.8 |  |  | $ | 0.1 |  |  | $ | (1.7 | ) |  | $ | 314.2 |  |

[0001633978-19-000002:notes:75]
We use the specific-identification method to determine any realized gains or losses from the sale of our short-term investments classified as available-for-sale. During the three and six months ended December 29, 2018 and December 30, 2017, we did not realize significant gains or losses on a gross level from the sale of our short-term investments classified as available-for-sale.

[0001633978-19-000002:notes:76]
During the three and six months ended December 29, 2018, our interest and other income (expense), net was $4.7 million  expense and $7.1 million expense, respectively, and includes interest income on cash equivalents and short-term investments of $3.4 million and $6.1 million, respectively. During the three and six months ended December 30, 2017, our interest and other income (expense), net was $3.2 million expense and $6.6 million expense, respectively, and includes interest income on cash equivalents and short-term investments of $1.7 million and $3.1 million, respectively.

[0001633978-19-000002:notes:77]
[same as prior period, unchanged from 0001628280-18-013240:notes:60]

[0001633978-19-000002:notes:78]
|  | Less than 12 months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| December 29, 2018: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper | $ | 12.8 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 12.8 |  |  | $ | — |  |
| Asset-backed securities | 32.1 |  |  | (0.1 | ) |  | 12.3 |  |  | — |  |  | 44.4 |  |  | (0.1 | ) |
| Corporate debt securities | 101.1 |  |  | (0.4 | ) |  | 88.1 |  |  | (0.7 | ) |  | 189.2 |  |  | (1.1 | ) |
| Mortgage-backed securities | 0.1 |  |  | — |  |  | — |  |  | — |  |  | 0.1 |  |  | — |  |
| Foreign government bonds | 2.9 |  |  | — |  |  | 2.1 |  |  | — |  |  | 5.0 |  |  | — |  |
| Total | $ | 149.0 |  |  | $ | (0.5 | ) |  | $ | 102.5 |  |  | $ | (0.7 | ) |  | $ | 251.5 |  |  | $ | (1.2 | ) |
| June 30, 2018: |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |  | $ | — |  |
| Commercial paper | 8.5 |  |  | — |  |  | — |  |  | — |  |  | 8.5 |  |  | — |  |
| Asset-backed securities | 66.6 |  |  | (0.2 | ) |  | 0.3 |  |  | — |  |  | 66.9 |  |  | (0.2 | ) |
| Corporate debt securities | 188.6 |  |  | (1.5 | ) |  | 2.0 |  |  | — |  |  | 190.6 |  |  | (1.5 | ) |
| Municipal bonds | 0.6 |  |  | — |  |  | — |  |  | — |  |  | 0.6 |  |  | — |  |
| U.S. Agency securities | 4.0 |  |  | — |  |  | — |  |  | — |  |  | 4.0 |  |  | — |  |
| Foreign government bonds | 3.4 |  |  | — |  |  | — |  |  | — |  |  | 3.4 |  |  | — |  |
| Total | $ | 277.1 |  |  | $ | (1.7 | ) |  | $ | 2.3 |  |  | $ | — |  |  | $ | 279.4 |  |  | $ | (1.7 | ) |

[0001633978-19-000002:notes:79]
The following table classifies our short-term investments by contractual maturities (in millions):

[0001633978-19-000002:notes:80]
|  | December 29, 2018 |  | June 30, 2018 |
|  | Amortized Cost |  | Fair Value |  | Amortized Cost |  | Fair Value |
| Due in 1 year | $ | 165.1 |  |  | $ | 164.7 |  |  | $ | 150.1 |  |  | $ | 149.6 |  |
| Due in 1 year through 5 years | 143.2 |  |  | 142.5 |  |  | 157.2 |  |  | 156.1 |  |
| Due in 5 years through 10 years | 4.3 |  |  | 4.3 |  |  | 6.1 |  |  | 6.1 |  |
| Due after 10 years | 1.3 |  |  | 1.3 |  |  | 2.4 |  |  | 2.4 |  |
|  | $ | 313.9 |  |  | $ | 312.8 |  |  | $ | 315.8 |  |  | $ | 314.2 |  |

[0001633978-19-000002:notes:81]
[same as prior period, unchanged from 0001628280-18-013240:notes:64]


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001633978-19-000002:notes:82]
Note 18. Commitments and Contingencies

[0001633978-19-000002:notes:83]
Operating Leases

[0001633978-19-000002:notes:84]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2033. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. As a result of our acquisition of Oclaro on December 10, 2018, we assumed operating leases with future minimum annual lease payments of $81.9 million.

[0001633978-19-000002:notes:85]
As of December 29, 2018, the total future minimum annual lease payments under non-cancellable operating leases were as follows (in millions):

[0001633978-19-000002:notes:86]
| Fiscal Years |  |
| Remainder of 2019 | $ | 10.4 |  |
| 2020 | 16.2 |  |
| 2021 | 14.9 |  |
| 2022 | 13.5 |  |
| 2023 | 12.4 |  |
| Thereafter | 39.1 |  |
| Total minimum operating lease payments | $ | 106.5 |  |

[0001633978-19-000002:notes:87]
During the three and six months ended December 29, 2018, rental expense relating to building and equipment was $3.2 million and $6.0 million, respectively. During the three and six months ended December 30, 2017, rental expense relating to building and equipment was $3.0 million and $6.4 million, respectively.

[0001633978-19-000002:notes:88]
Capital Leases

[0001633978-19-000002:notes:89]
As of December 29, 2018, equipment acquired under capital lease agreements, including those assumed as part of the Oclaro acquisition, was $17.5 million. Our capital lease assets are included in property, plant and equipment, net in our condensed consolidated balance sheets as of December 29, 2018. Amortization expense on these capital lease assets are recorded as depreciation expense and is included in cost of sales in our condensed consolidated statements of operations for the three and six months ended December 29, 2018 and December 30, 2017. Our capital lease obligations are recorded at the lesser of the estimated fair market value of the leased property or the net present value of the aggregate future minimum lease payments and is included in other current liabilities and other non-current liabilities in our condensed consolidated balance sheets as of December 29, 2018. Refer to “Note 8. Balance Sheet Details” for capital lease obligation amounts in other current liabilities and other non-current liabilities. Interest on these obligations is included in interest expense in our condensed consolidated statements of operations.

[0001633978-19-000002:notes:90]
In connection with our acquisition of Oclaro, we assumed capital leases related to plant and machinery. This capital lease extends through October 2020, after which time the ownership of the equipment transfers from the lessor to us. During the lease term, we are required to make equal installments of principal and interest, payable quarterly. Interest on this capital lease accrues at 1.15 percent per annum.

[0001633978-19-000002:notes:91]
As of December 29, 2018 the future minimum annual lease payments under our capital leases were as follows (in millions):

[0001633978-19-000002:notes:92]
| Fiscal Years |  |
| Remainder of 2019 | $ | 4.6 |  |
| 2020 | 1.0 |  |
| 2021 | 0.3 |  |
| Total minimum capital lease payments | $ | 5.9 |  |
| Less: amount representing interest | $ | (0.1 | ) |
| Present value of capital lease obligation | $ | 5.8 |  |

[0001633978-19-000002:notes:93]
Acquisition Contingencies

[0001633978-19-000002:notes:94]
In February 2017, we incurred liabilities in the amount of $3.6 million related to an acquisition of a privately held company. The amount of up to $3.0 million is expected to be paid within the following 12 months contingent upon meeting certain production targets, and is included in other current liabilities on our consolidated balance sheet as of December 29, 2018.

[0001633978-19-000002:notes:95]
We also retained $1.0 million of the purchase price as security for any potential liabilities of the seller under the representations, warranties and indemnifications included in the purchase agreement. The $1.0 million was fully paid to the seller during the six months ended December 29, 2018.

[0001633978-19-000002:notes:96]
Term Loan

[0001633978-19-000002:notes:97]
The estimated future interest and principal payments related to the term loan are as follows as of December 29, 2018:

[0001633978-19-000002:notes:98]
| Fiscal Years |  |
| Remainder of 2019 | $ | 16.1 |  |
| 2020 | 29.2 |  |
| 2021 | 29.0 |  |
| 2022 | 28.7 |  |
| 2023 | 28.5 |  |
| Thereafter | 533.9 |  |
| Total term loan payments | $ | 665.4 |  |

[0001633978-19-000002:notes:99]
0.25% Convertible Senior Notes due 2024

[0001633978-19-000002:notes:100]
The future interest and principal payments related to the 2024 Notes are as follows as of December 29, 2018:

[0001633978-19-000002:notes:101]
| Fiscal Years |  |
| Remainder of 2019 | $ | 0.6 |  |
| 2020 | 1.1 |  |
| 2021 | 1.1 |  |
| 2022 | 1.1 |  |
| 2023 | 1.1 |  |
| Thereafter | 451.2 |  |
| Total 2024 Notes payments | $ | 456.2 |  |

[0001633978-19-000002:notes:102]
Purchase Obligations

[0001633978-19-000002:notes:103]
Purchase obligations of $281.8 million as of December 29, 2018, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Included in the $281.8 million are approximately $85.9 million in purchase commitments assumed in connection with our acquisition of Oclaro on December 10, 2018.

[0001633978-19-000002:notes:104]
Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001633978-19-000002:notes:105]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with such vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

[0001633978-19-000002:notes:106]
Product Warranties

[0001633978-19-000002:notes:107]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, product component or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001633978-19-000002:notes:108]
The following table presents the changes in our warranty reserve during the three and six months ended December 29, 2018 and December 30, 2017 (in millions):

[0001633978-19-000002:notes:109]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |  | December 29, 2018 |  | December 30, 2017 |
| Balance as of beginning of period | $ | 6.6 |  |  | $ | 9.4 |  |  | $ | 6.6 |  |  | $ | 9.7 |  |
| Warranties assumed in Oclaro acquisition | 3.8 |  |  | — |  |  | 3.8 |  |  | — |  |
| Provision for warranty | 0.7 |  |  | 1.9 |  |  | 1.9 |  |  | 2.9 |  |
| Utilization of reserve | (1.4 | ) |  | (1.4 | ) |  | (2.6 | ) |  | (2.7 | ) |
| Balance as of end of period | $ | 9.7 |  |  | $ | 9.9 |  |  | $ | 9.7 |  |  | $ | 9.9 |  |

[0001633978-19-000002:notes:110]
Environmental Liabilities

[0001633978-19-000002:notes:111]
Our research and development (“R&D”), manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental, product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001633978-19-000002:notes:112]
In connection with the Separation, we agreed to indemnify Viavi for any liability associated with contamination from past operations at all properties transferred to us from Viavi, to the extent the resulting issues primarily related to our business.

[0001633978-19-000002:notes:113]
Legal Proceedings

[0001633978-19-000002:notes:114]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss.

[0001633978-19-000002:notes:115]
Merger Litigation

[0001633978-19-000002:notes:116]
In connection with our acquisition of Oclaro, seven lawsuits were filed by purported stockholders of Oclaro challenging the proposed merger (the “Merger”). Two of the seven suits were putative class actions filed against Oclaro, its directors, Lumentum, Prota Merger Sub, Inc. and Prota Merger, LLC: Nicholas Neinast v. Oclaro, Inc., et al., No. 3:18-cv-03112-VC, in the United States District Court for the Northern District of California (filed May 24, 2018) (the “Neinast Lawsuit”); and Adam Franchi v. Oclaro, Inc., et al., No. 1:18-cv-00817-GMS, in the United States District Court for the District of Delaware (filed June 9, 2018) (the “Franchi Lawsuit). Both the Neinstat Lawsuit and the Franchi Lawsuit were voluntarily dismissed with prejudice.

[0001633978-19-000002:notes:117]
The other five suits, styled as Gerald F. Wordehoff v. Oclaro, Inc., et al., No. 5:18-cv-03148-NC (the “Wordehoff Lawsuit”), Walter Ryan v. Oclaro, Inc., et al., No. 3:18-cv-03174-VC (the “Ryan Lawsuit”), Jayme Walker v. Oclaro, Inc., et al., No. 5:18-cv-03203-EJD (the “Walker Lawsuit”), Kevin Garcia v. Oclaro, Inc., et al., No. 5:18-cv-03262-VKD (the “Garcia Lawsuit”), and SaiSravan B. Karri v. Oclaro, Inc., et al., No. 3:18-cv-03435-JD (the “Karri Lawsuit” and, together with the other six lawsuits, the “Lawsuits”), were filed in the United States District Court for the Northern District of California on May 25, 2018, May 29, 2018, May 30, 2018, May 31, 2018, and June 9, 2018, respectively. These five Lawsuits named Oclaro and its directors as defendants only and did not name Lumentum. The Wordehoff, Ryan, Walker, and Garcia Lawsuits have been voluntarily dismissed, and the Wordehoff, Ryan, and Walker dismissals were with prejudice. The Karri Lawsuit has not yet been dismissed. The Ryan Lawsuit was, and the Karri Lawsuit is, a putative class action.

[0001633978-19-000002:notes:118]
The Lawsuits generally alleged, among other things, that Oclaro and its directors violated Section 14(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), and Rule 14a-9 promulgated thereunder by disseminating an incomplete and misleading Form S-4, including proxy statement/prospectus. The Lawsuits further alleged that Oclaro’s directors violated Section 20(a) of the Exchange Act by failing to exercise proper control over the person(s) who violated Section 14(a) of the Exchange Act.

[0001633978-19-000002:notes:119]
The remaining Lawsuit (the Karri Lawsuit) currently purports to seek, among other things, damages to be awarded to the plaintiff and any class if the Merger is consummated, and litigation costs, including attorneys’ fees. The defendants intend to defend the Karri Lawsuit vigorously.

[0001633978-19-000002:notes:120]
Indemnifications

[0001633978-19-000002:notes:121]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of December 29, 2018, we did not have any material indemnification claims that were probable or reasonably possible.

[0001633978-19-000002:notes:122]
Audit Proceedings

[0001633978-19-000002:notes:123]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.

[0001633978-19-000002:notes:124]
In connection with our acquisition of Oclaro, we recorded $0.7 million in Malaysia Goods and Services Tax (“GST”) refund claims within prepaid expenses and other current assets in our condensed consolidated balance sheet at December 29, 2018. The refund claim represents an initial claim of $2.5 million of Malaysia GST refund claims that were preliminarily denied by the Malaysian tax authorities in 2016. We are currently appealing the denial of these claims, and believe that additional options may be available to us if we do not obtain a favorable resolution. Although we have taken action to minimize the impact of the GST with respect to our ongoing operations, we believe it is reasonably possible that, ultimately, we may not be able to recover some of these GST amounts.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001633978-19-000002:notes:125]
[same as prior period, unchanged from 0001628280-18-013240:notes:95]

[0001633978-19-000002:notes:126]
Our accumulated other comprehensive income (loss) consists of the accumulated net unrealized gains or losses on foreign currency translation adjustments, the defined benefit obligations, and available-for-sale securities.

[0001633978-19-000002:notes:127]
As of December 29, 2018 and June 30, 2018, balances for the components of accumulated other comprehensive income (loss) were as follows (in millions):

[0001633978-19-000002:notes:128]
|  | Foreign currency translation adjustments, net of tax |  | Defined benefit obligations, net of tax (1) |  | Unrealized gain (loss) on available-for-sale securities, net of tax |  | Total |
| Beginning balance as of June 30, 2018 | $ | 10.3 |  |  | $ | (2.3 | ) |  | $ | (1.6 | ) |  | $ | 6.4 |  |
| Other comprehensive income (loss) | (0.6 | ) |  | (0.1 | ) |  | 0.5 |  |  | (0.2 | ) |
| Ending balance as of December 29, 2018 | $ | 9.7 |  |  | $ | (2.4 | ) |  | $ | (1.1 | ) |  | $ | 6.2 |  |

[0001633978-19-000002:notes:129]
(1) We evaluate the assumptions over the fair value of our defined benefit obligations annually and make changes as necessary.


## us-gaap:ConvertibleDebtTableTextBlock

[0001633978-19-000002:notes:130]
The 2024 Notes consisted of the following components as of the periods presented (in millions):

[0001633978-19-000002:notes:131]
| Liability component: | December 29, 2018 |  | June 30, 2018 |
| Principal | $ | 450.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount | (107.1 | ) |  | (115.8 | ) |
| Net carrying amount of the liability component | $ | 342.9 |  |  | $ | 334.2 |  |


## us-gaap:DebtDisclosureTextBlock

[0001633978-19-000002:notes:132]
Note 12. Convertible Senior Notes

[0001633978-19-000002:notes:133]
In March 2017, we issued the 2024 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank National Association, as trustee (the “Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001633978-19-000002:notes:134]
The 2024 Notes bear interest at a rate of 0.25% per year. Interest on the 2024 Notes is payable semi-annually in arrears on March 15 and September 15 of each year, beginning on September 15, 2017. The 2024 Notes will mature on March 15, 2024, unless earlier repurchased by us or converted pursuant to their terms.

[0001633978-19-000002:notes:135]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share, a 132.5% premium to the fair market value at the date of issuance. Prior to the close of business on the business day immediately preceding December 15, 2023, the 2024 Notes will be convertible only under the following circumstances: (1) during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price, or $78.80 on each applicable trading day; (2) during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of notes for each trading day of such measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day; or (3) upon the occurrence of specified corporate events. On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their notes at any time. In addition, upon the occurrence of a make-whole fundamental change, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert 2024 Notes in connection with such make-whole fundamental change.

[0001633978-19-000002:notes:136]
We may not redeem the 2024 Notes prior to their maturity date and no sinking fund is provided for the 2024 Notes. Upon the occurrence of a fundamental change, holders may require us to repurchase all or a portion of their 2024 Notes for cash at a price equal to 100% of the principal amount of the 2024 Notes to be repurchased, plus any accrued and unpaid interest.

[0001633978-19-000002:notes:137]
We considered the features embedded in the 2024 Notes other than the conversion feature, including the holders’ put feature, our call feature, and the make-whole feature, and concluded that they are not required to be bifurcated and accounted for separately from the host debt instrument.

[0001633978-19-000002:notes:138]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. We incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. We amortize the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes is 5.4% per year. As of December 29, 2018, the remaining debt discount amortization period was 62 months.

[0001633978-19-000002:notes:139]
During the year ended July 1, 2017, we satisfied the TMA settlement condition. As such, the value of the conversion option will no longer be marked to market and was reclassified to additional paid-in capital within stockholders’ equity on our condensed consolidated balance sheet. The value of the conversion option at the time of issuance will be treated as an original issue discount for purposes of accounting for the debt component of the notes. The debt component will accrete up to the principal amount over the expected term of the debt. These accounting standards do not affect the actual amount we are required to repay, and the amount shown in the table below for the notes is the aggregate principal amount of the notes and does not reflect the debt discount we will be required to recognize.

[0001633978-19-000002:notes:140]
The following table sets forth interest expense information related to the 2024 Notes for the periods presented (in millions, except percentages):

[0001633978-19-000002:notes:141]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |  | December 29, 2018 |  | December 30, 2017 |
| Contractual interest expense | $ | 0.3 |  |  | $ | 0.3 |  |  | $ | 0.6 |  |  | $ | 0.6 |  |
| Amortization of the debt discount | 4.4 |  |  | 4.1 |  |  | 8.7 |  |  | 8.2 |  |
| Total interest expense | $ | 4.7 |  |  | $ | 4.4 |  |  | $ | 9.3 |  |  | $ | 8.8 |  |
| Effective interest rate on the liability component | 5.4 | % |  | 5.4 | % |  | 5.4 | % |  | 5.4 | % |

[0001633978-19-000002:notes:142]
We have the ability and intent to settle the $450 million face value of the debt in cash. Therefore, we use the treasury stock method for calculating the dilutive impact of the debt. The 2024 Notes will have no impact to diluted earnings per share until the average price of our common stock exceeds the conversion price of $60.62.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001633978-19-000002:notes:143]
Note 13. Derivative Liability

[0001633978-19-000002:notes:144]
Up through the date of conversion of the Series A Preferred Stock, we estimated the fair value of the embedded derivative using the binomial lattice model. We applied the binomial lattice model to value the embedded derivative using a “with-and-without method,” where the value of the Series A Preferred Stock, including the embedded derivative, is defined as the “with”, and the value of the Series A Preferred Stock, excluding the embedded derivative, is defined as the “without”. The binomial lattice model requires the following inputs: (i) the Company's common stock price; (ii) conversion price; (iii) term; (iv) yield; (v) recovery rate for the Series A Preferred Stock; (vi) estimated stock volatility; and (vii) risk-free rate. The fair value of the embedded derivative was determined using Level 3 inputs under the fair value hierarchy (unobservable inputs). Changes in the inputs into this valuation model have a material impact in the estimated fair value of the embedded derivative. For example, a decrease (increase) in the stock price and the volatility results in a decrease (increase) in the estimated fair value of the embedded derivative. The changes in the fair value of the bifurcated embedded derivative for the Series A Preferred Stock are primarily related to the change in the price of our common stock and are reflected in the condensed consolidated statements of operations as “Unrealized gain (loss) on derivative liability.” Prior to the conversion of the Series A Preferred Stock on November 2, 2018, we marked to market the embedded derivative, resulting in a gain of $10.9 million. The gain (loss) on derivative liability for the Series A Preferred Stock up through the conversion date of November 2, 2018, amounted to a $10.9 million gain and a $8.8 million gain for the three and six months ended December 29, 2018, respectively. In connection with the conversion of the Series A Preferred Stock we also recorded $79.4 million in additional paid in capital within the condensed consolidated balance sheet as of December 29, 2018.

[0001633978-19-000002:notes:145]
Unrealized gain (loss) on derivative liability for the Series A Preferred Stock amounted to a $7.9 million gain and a $12.1 million gain for the three and six months ended December 30, 2017, respectively.

[0001633978-19-000002:notes:146]
The following table provides a reconciliation of the fair value of the embedded derivative for the Series A Preferred Stock for the three and six months ended December 29, 2018 and December 30, 2017 (in millions):

[0001633978-19-000002:notes:147]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |  | December 29, 2018 |  | December 30, 2017 |
| Balance as of beginning of period | $ | 54.5 |  |  | $ | 47.4 |  |  | $ | 52.4 |  |  | $ | 51.6 |  |
| Unrealized (gain) loss on the Series A Preferred Stock derivative liability up through the conversion date | (10.9 | ) |  | (7.9 | ) |  | (8.8 | ) |  | (12.1 | ) |
| Settlement of the derivative liability upon conversion of Series A Preferred Stock | (43.6 | ) |  | — |  |  | (43.6 | ) |  | — |  |
| Balance as of end of period | $ | — |  |  | $ | 39.5 |  |  | $ | — |  |  | $ | 39.5 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001633978-19-000002:notes:148]
Note 17. Stock-Based Compensation and Stock Plans

[0001633978-19-000002:notes:149]
[same as prior period, unchanged from 0001628280-18-013240:notes:118]

[0001633978-19-000002:notes:150]
[same as prior period, unchanged from 0001628280-18-013240:notes:119]

[0001633978-19-000002:notes:151]
As of December 29, 2018, we had 3.0 million shares subject to stock options, restricted stock units, restricted stock awards, and performance stock units issued and outstanding under the 2015 Equity Incentive Plan (the “2015 Plan”).

[0001633978-19-000002:notes:152]
Restricted stock units, restricted stock awards, and performance stock units are performance-based, time-based or a combination of both and are expected to vest over one to four years. The fair value of these grants is based on the closing market price of our common stock on the date of award. The exercise price for stock options is equal to the fair value of the underlying stock at the date of grant. We issue new shares of common stock upon exercise of stock options. Options generally become exercisable over a three-year or four-year period and, if not exercised, expire from five to ten years after the date of grant.

[0001633978-19-000002:notes:153]
As of December 29, 2018, 3.8 million shares of common stock under the 2015 Plan were available for grant.

[0001633978-19-000002:notes:154]
Replacement Awards

[0001633978-19-000002:notes:155]
In connection with the acquisition of Oclaro, we issued equity awards to Oclaro employees, consisting of stock options and restricted stock units (“replacement awards”) in exchange for their Oclaro equity awards. The replacement awards consisted of less than 0.1 million stock options with a weighted average grant date fair value of $34.34, and 1.0 million restricted stock units with a weighted average grant date fair value of $41.80. The terms of these replacement awards are substantially similar to the original Oclaro equity awards. The fair value of the replacement awards for services rendered through December 10, 2018, the acquisition date, was recognized as a component of the merger consideration, with the remaining fair value of the replacement awards related to the post-combination services recorded as stock-based compensation over the remaining vesting period.

[0001633978-19-000002:notes:156]
[same as prior period, unchanged from 0001628280-18-013240:notes:125]

[0001633978-19-000002:notes:157]
[same as prior period, unchanged from 0001628280-18-013240:notes:126]

[0001633978-19-000002:notes:158]
[same as prior period, unchanged from 0001628280-18-013240:notes:127]

[0001633978-19-000002:notes:159]
[same as prior period, unchanged from 0001628280-18-013240:notes:128]

[0001633978-19-000002:notes:160]
[same as prior period, unchanged from 0001628280-18-013240:notes:129]

[0001633978-19-000002:notes:161]
[same as prior period, unchanged from 0001628280-18-013240:notes:130]

[0001633978-19-000002:notes:162]
In November 2018, our board of directors approved the grant of 0.2 million PSUs to senior members of our management team. We determined that the achievement of the performance conditions was probable as of December 29, 2018, and as such, began recording stock-based compensation associated with these PSUs.

[0001633978-19-000002:notes:163]
[same as prior period, unchanged from 0001628280-18-013240:notes:132]

[0001633978-19-000002:notes:164]
Our 2015 Employee Stock Purchase Plan (the “2015 Purchase Plan”)  provides eligible employees with the opportunity to acquire an ownership interest in the Company through periodic payroll deductions and provides a 15% purchase price discount as well as a six-month look-back period. The 2015 Purchase Plan is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986. However, the 2015 Purchase Plan is not intended to be a qualified pension, profit sharing or stock bonus plan under Section 401(a) of the Internal Revenue Code of 1986 and is not subject to the provisions of the Employee Retirement Income Security Act of 1974. The 2015 Purchase Plan will terminate upon the date on which all shares available for issuance have been sold. Of the 3.0 million shares authorized under the 2015 Purchase Plan, 2.2 million shares remained available for issuance as of December 29, 2018.

[0001633978-19-000002:notes:165]
[same as prior period, unchanged from 0001628280-18-013240:notes:134]

[0001633978-19-000002:notes:166]
The impact on our results of operations of recording stock-based compensation by function for the three and six months ended December 29, 2018 and December 30, 2017 was as follows (in millions):

[0001633978-19-000002:notes:167]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |  | December 29, 2018 |  | December 30, 2017 |
| Cost of sales | $ | 5.2 |  |  | $ | 4.4 |  |  | $ | 8.5 |  |  | $ | 7.1 |  |
| Research and development | 3.4 |  |  | 3.8 |  |  | 6.2 |  |  | 6.9 |  |
| Selling, general and administrative | 21.1 |  |  | 6.6 |  |  | 25.8 |  |  | 10.1 |  |
|  | $ | 29.7 |  |  | $ | 14.8 |  |  | $ | 40.5 |  |  | $ | 24.1 |  |

[0001633978-19-000002:notes:168]
Approximately $2.1 million and $2.6 million of stock-based compensation was capitalized to inventory as of December 29, 2018 and June 30, 2018, respectively.

[0001633978-19-000002:notes:169]
In connection with the acquisition of Oclaro, we accelerated certain equity awards for Oclaro employees. The total stock-based compensation expense associated with the acceleration of equity awards was $15.2 million, out of which $10.0 million was settled in cash for the three months ended December 29, 2018. Refer to “Note 5. Business Combinations.”

[0001633978-19-000002:notes:170]
[same as prior period, unchanged from 0001628280-18-013240:notes:138]

[0001633978-19-000002:notes:171]
We did not grant any stock options during the three and six months ended December 29, 2018 and December 30, 2017, other than those assumed in connection with the Oclaro merger. As of December 29, 2018, there less than 0.1 million stock options outstanding under the 2015 Plan, all of which were replacement awards issued in connection with the Oclaro acquisition.

[0001633978-19-000002:notes:172]
During the three and six months ended December 29, 2018, there were no options exercised. During the three and six months ended December 30, 2017, there were 1,457 options and 41,727 options exercised, respectively, by our employees with a total intrinsic value of $0.1 million and $0.8 million, respectively.

[0001633978-19-000002:notes:173]
The following table summarizes our awards activity for the six months ended December 29, 2018 (in millions, except per share amounts):

[0001633978-19-000002:notes:174]
|  | Stock Options |  | Restricted Stock Units |  | Restricted Stock Awards |  | Performance Stock Units |
|  | Number of Shares |  | Weighted-Average Exercise Price |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares (1) |  | Weighted-Average Grant Date Fair Value per Share |
| Balance at beginning of period | — |  |  | $ | — |  |  | 1.7 |  |  | $ | 43.1 |  |  | 0.1 |  |  | $ | 32.5 |  |  | 0.1 |  |  | $ | 52.0 |  |
| Assumed in Oclaro merger | * |  |  | 34.3 |  |  | 1.0 |  |  | 41.8 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Granted | — |  |  | — |  |  | 0.8 |  |  | 64.8 |  |  | — |  |  | — |  |  | 0.2 |  |  | 55.9 |  |
| Vested | — |  |  | — |  |  | (0.7 | ) |  | 40.2 |  |  | * |  |  | 32.5 |  |  | (0.1 | ) |  | 50.3 |  |
| Canceled | — |  |  | — |  |  | (0.2 | ) |  | 51.0 |  |  | * |  |  | 32.8 |  |  | * |  |  | 52.0 |  |
| Balance at end of period | * |  |  | $ | 34.3 |  |  | 2.6 |  |  | $ | 51.2 |  |  | 0.1 |  |  | $ | 32.5 |  |  | 0.2 |  |  | $ | 55.2 |  |

[0001633978-19-000002:notes:175]
*  Less than 0.05 million.

[0001633978-19-000002:notes:176]
[same as prior period, unchanged from 0001628280-18-013240:notes:143]

[0001633978-19-000002:notes:177]
As of December 29, 2018, $133.4 million of stock-based compensation cost related to awards granted to our employees remains to be amortized. That cost is expected to be recognized over an estimated amortization period of 2.3 years.

[0001633978-19-000002:notes:178]
[same as prior period, unchanged from 0001628280-18-013240:notes:145]

[0001633978-19-000002:notes:179]
|  | Awards Available for Grant |
| Balance as of beginning of period | 5.6 |  |
| Replacement awards in connection with Oclaro acquisition | (1.0 | ) |
| Granted | (1.0 | ) |
| Canceled | 0.2 |  |
| Balance as of end of period | 3.8 |  |

[0001633978-19-000002:notes:180]
[same as prior period, unchanged from 0001628280-18-013240:notes:147]

[0001633978-19-000002:notes:181]
The 2015 Purchase Plan expense for the three and six months ended December 29, 2018 was $0.8 million and $1.8 million, respectively. The 2015 Purchase Plan expense for the three and six months ended December 30, 2017 was $0.8 million and $1.6 million, respectively. The expense related to the 2015 Purchase Plan is recorded on a straight-line basis over the relevant subscription period. During each of the three and six months ended December 29, 2018 there were 0.1 million shares issued to employees through the 2015 Purchase Plan. During each of the three and six months ended December 30, 2017, there were 0.1 million shares issued to employees through the 2015 Purchase Plan.

[0001633978-19-000002:notes:182]
We estimate the fair value of the 2015 Purchase Plan shares on the date of grant using the Black-Scholes option-pricing model. During the three and six months ended December 29, 2018 and December 30, 2017, the assumptions used to estimate the fair value of the 2015 Purchase Plan shares to be issued were as follows:

[0001633978-19-000002:notes:183]
|  | December 29, 2018 |  | December 30, 2017 |
| Expected term (years) | 0.5 |  |  | 0.5 |  |
| Expected volatility | 71.3 | % |  | 49.9 | % |
| Risk-free interest rate | 2.52 | % |  | 1.42 | % |
| Dividend yield | — | % |  | — | % |


## us-gaap:EarningsPerShareTextBlock

[0001633978-19-000002:notes:184]
[same as prior period, unchanged from 0001628280-18-013240:notes:151]

[0001633978-19-000002:notes:185]
[same as prior period, unchanged from 0001628280-18-013240:notes:152]

[0001633978-19-000002:notes:186]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |  | December 29, 2018 |  | December 30, 2017 |
| Basic Earnings per Common Share |  |  |  |  |  |  |  |  |  |  |
| Net income | $ | 16.3 |  |  | $ | 204.8 |  |  | $ | 63.7 |  |  | $ | 211.9 |  |
| Less: Cumulative dividends on Series A Preferred Stock | (0.1 | ) |  | (0.3 | ) |  | (0.3 | ) |  | (0.5 | ) |
| Less: Earnings allocated to Series A Preferred Stock | (0.1 | ) |  | (4.7 | ) |  | (1.2 | ) |  | (4.9 | ) |
| Net income attributable to common stockholders - Basic | $ | 16.1 |  |  | $ | 199.8 |  |  | $ | 62.2 |  |  | $ | 206.5 |  |
| Weighted average common shares outstanding including Series A Preferred Stock | 67.3 |  |  | 63.7 |  |  | 66.0 |  |  | 63.4 |  |
| Less: Weighted average Series A Preferred Stock | (0.5 | ) |  | (1.5 | ) |  | (1.0 | ) |  | (1.5 | ) |
| Basic weighted average common shares outstanding | 66.8 |  |  | 62.2 |  |  | 65.0 |  |  | 61.9 |  |
| Net income per share attributable to common stockholders - Basic | $ | 0.24 |  |  | $ | 3.21 |  |  | $ | 0.96 |  |  | $ | 3.34 |  |
| Diluted Earnings per Common Share |  |  |  |  |  |  |  |
| Net income attributable to common stockholders - Basic | $ | 16.1 |  |  | $ | 199.8 |  |  | $ | 62.2 |  |  | $ | 206.5 |  |
| Add: Earnings allocated to Series A Preferred Stock | 0.1 |  |  | 4.7 |  |  | 1.2 |  |  | 4.9 |  |
| Add/Less: Unrealized (gain) loss on derivative liability on Series A Preferred Stock | (10.9 | ) |  | (7.9 | ) |  | (8.8 | ) |  | (12.1 | ) |
| Add: Cumulative dividends on Series A Preferred Stock | 0.1 |  |  | 0.3 |  |  | 0.3 |  |  | 0.5 |  |
| Net income attributable to common stockholders - Diluted (a) | $ | 5.4 |  |  | $ | 196.9 |  |  | $ | 54.9 |  |  | $ | 199.8 |  |
| Weighted average common shares outstanding for basic earnings per common share | 66.8 |  |  | 62.2 |  |  | 65.0 |  |  | 61.9 |  |
| Effect of dilutive securities from 2015 Equity Incentive Plan | 0.5 |  |  | 0.9 |  |  | 0.6 |  |  | 1.1 |  |
| Effect of dilutive securities from Series A Preferred Stock | 0.5 |  |  | 1.5 |  |  | 1.0 |  |  | 1.5 |  |
| Diluted weighted average common shares outstanding | 67.8 |  |  | 64.6 |  |  | 66.6 |  |  | 64.5 |  |
| Net income per share attributable to common stockholders - Diluted | $ | 0.08 |  |  | $ | 3.05 |  |  | $ | 0.82 |  |  | $ | 3.10 |  |

[0001633978-19-000002:notes:187]
(a) For the three and six months ended December 29, 2018 and December 30, 2017, our diluted earnings per share attributable to common stockholders is calculated using the if-converted method because it is more dilutive than the treasury stock method.

[0001633978-19-000002:notes:188]
Our Series A Preferred Stock was considered a participating security, meaning that it had the right to participate in undistributed earnings with our common stock. Prior to conversion, the holders of our Series A Preferred Stock were entitled to share in dividends, on an as-converted basis, if the holders of our common stock were to receive dividends. On November 2, 2018, the remaining 35,805 shares of our Series A Preferred Stock were converted and we issued 1.5 million shares of our common stock. Refer to “Note 11. Non-Controlling Interest Redeemable Convertible Preferred Stock” for further discussion.

[0001633978-19-000002:notes:189]
We used the two-class method to compute earnings per share. The two-class method is an earnings allocation formula that determines earnings per share for each class of common stock and participating security according to dividends declared (or accumulated) and participation rights in undistributed earnings. In determining the amount of net earnings to allocate to common stockholders, earnings are allocated to both common and participating securities based on their respective weighted-average shares outstanding during the period. Diluted earnings per common share is calculated similar to basic earnings per common share except that it gives effect to all potentially dilutive common stock equivalents outstanding for the period, using the treasury stock method. Potentially dilutive common shares result from the assumed exercise of outstanding stock options, assumed vesting of outstanding equity awards, assumed issuance of stock under the employee stock purchase plan, and assumed conversion of our outstanding $450 million in aggregate principal amount of 0.25% Convertible Senior Notes due in 2024 (the “2024 Notes”), all using the treasury stock method. We have the ability and intent to settle the $450 million face value of the 2024 Notes in cash. Therefore, we use the treasury stock method for calculating the dilutive impact of the 2024 Notes. The 2024 Notes will have no impact on diluted earnings per share until the average price of our common stock exceeds the conversion price of $60.62. Refer to “Note 12. Convertible Senior Notes” for further discussion. Diluted earnings per common share is computed using the more dilutive of the treasury stock method or the if-converted method.

[0001633978-19-000002:notes:190]
Anti-dilutive potential shares from the 2015 Equity Incentive Plan are excluded from the calculation of diluted earnings per share if their exercise price exceeded the average market price during the period or the share-based awards were determined to be anti-dilutive based on applying the treasury stock method.


## us-gaap:FairValueDisclosuresTextBlock

[0001633978-19-000002:notes:191]
Note 10. Fair Value Measurements

[0001633978-19-000002:notes:192]
[same as prior period, unchanged from 0001628280-18-013240:notes:160]

[0001633978-19-000002:notes:193]
[same as prior period, unchanged from 0001628280-18-013240:notes:161]

[0001633978-19-000002:notes:194]
The fair value of our Level 1 financial instruments, such as money market funds, which are traded in active markets, is based on quoted market prices for identical instruments. The fair value of our Level 2 fixed income securities is obtained from an independent pricing service, which may use quoted market prices for identical or comparable instruments or model driven valuations using observable market data or inputs corroborated by observable market data. Our marketable securities are held by custodians who obtain investment prices from a third-party pricing provider that incorporates standard inputs in various asset price models. Our procedures include controls to ensure that appropriate fair values are recorded, including comparing the fair values obtained from our pricing service against fair values obtained from another independent source.

[0001633978-19-000002:notes:195]
Prior to the conversion of the Series A Preferred Stock in the second quarter of fiscal 2019, we estimated the fair value of the embedded derivative for the Series A Preferred Stock using the binomial lattice model to be $43.6 million. The binomial lattice model requires various assumptions to be made to determine the fair value of the embedded derivatives. These assumptions represent Level 3 inputs. Refer to “Note 13. Derivative Liability.” Upon the conversion of the Series A Preferred Stock and the settlement of the Series A Preferred Stock and the embedded derivative, we recorded $79.4 million in additional paid in capital in the condensed consolidated balance sheet as of December 29, 2018.

[0001633978-19-000002:notes:196]
In February 2017, we completed the acquisition of a privately held company to enhance our manufacturing and vertical integration capabilities for a total purchase consideration of $8.7 million. We estimated the fair value of our Level 3 contingent consideration related to this acquisition at the present value of the expected contingent payments, determined using a probabilistic approach. We are required to reassess the fair value of contingent payments on a periodic basis. We estimated the likelihood of meeting the production targets at 90 percent and recorded the fair value of such contingent consideration in other current liabilities on the condensed consolidated balance sheet as of December 29, 2018. This contingent consideration will result in a cash payment of $3.0 million (based on the exchange rate as of the acquisition date), if and when the production targets are achieved, which we expect to occur within the following 12 months. There was no change in the fair value of our contingent consideration during the three and six months ended December 29, 2018 and December 30, 2017.

[0001633978-19-000002:notes:197]
[same as prior period, unchanged from 0001628280-18-013240:notes:165]

[0001633978-19-000002:notes:198]
[same as prior period, unchanged from 0001628280-18-013240:notes:166]

[0001633978-19-000002:notes:199]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| December 29, 2018: (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | — |  |  | $ | 2.0 |  |  | $ | — |  |  | $ | 2.0 |  |
| Commercial paper | — |  |  | 24.1 |  |  | — |  |  | 24.1 |  |
| Corporate debt securities | — |  |  | 5.0 |  |  | — |  |  | 5.0 |  |
| Money market funds | 4.8 |  |  | — |  |  | — |  |  | 4.8 |  |
| Foreign government bonds | — |  |  | 3.5 |  |  | — |  |  | 3.5 |  |
| U.S. Treasury | 35.6 |  |  | — |  |  | — |  |  | 35.6 |  |
| Asset-backed securities | — |  |  | 1.9 |  |  | — |  |  | 1.9 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | 13.3 |  |  | — |  |  | 13.3 |  |
| Asset-backed securities | — |  |  | 60.5 |  |  | — |  |  | 60.5 |  |
| Corporate debt securities | — |  |  | 230.4 |  |  | — |  |  | 230.4 |  |
| Municipal bonds | — |  |  | 1.3 |  |  | — |  |  | 1.3 |  |
| Mortgage-backed securities | — |  |  | 2.2 |  |  | — |  |  | 2.2 |  |
| Foreign government bonds | — |  |  | 5.1 |  |  | — |  |  | 5.1 |  |
| Total assets | $ | 40.4 |  |  | $ | 349.3 |  |  | $ | — |  |  | $ | 389.7 |  |
| Other current liabilities: |  |  |  |  |  |  |  |
| Acquisition contingencies | $ | — |  |  | $ | — |  |  | $ | 2.7 |  |  | $ | 2.7 |  |
| Total other accrued liabilities | $ | — |  |  | $ | — |  |  | $ | 2.7 |  |  | $ | 2.7 |  |

[0001633978-19-000002:notes:200]
(1)  Excludes $294.4 million in cash held in our bank accounts at December 29, 2018.

[0001633978-19-000002:notes:201]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| June 30, 2018: (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | — |  |  | $ | 3.0 |  |  | $ | — |  |  | $ | 3.0 |  |
| Commercial paper | — |  |  | 112.1 |  |  | — |  |  | 112.1 |  |
| Money market funds | 0.8 |  |  | — |  |  | — |  |  | 0.8 |  |
| U.S. Treasury securities | 143.6 |  |  | — |  |  | — |  |  | 143.6 |  |
| U.S. Agency securities | — |  |  | 34.2 |  |  | — |  |  | 34.2 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 7.5 |  |  | — |  |  | 7.5 |  |
| Commercial paper | — |  |  | 10.5 |  |  | — |  |  | 10.5 |  |
| Asset-backed securities | — |  |  | 67.8 |  |  | — |  |  | 67.8 |  |
| Corporate debt securities | — |  |  | 219.2 |  |  | — |  |  | 219.2 |  |
| Municipal bonds | — |  |  | 1.6 |  |  | — |  |  | 1.6 |  |
| Mortgage-backed securities | — |  |  | 4.2 |  |  | — |  |  | 4.2 |  |
| Foreign government bonds | — |  |  | 3.4 |  |  | — |  |  | 3.4 |  |
| Total assets | $ | 144.4 |  |  | $ | 463.5 |  |  | $ | — |  |  | $ | 607.9 |  |
| Other accrued liabilities: |  |  |  |  |  |  |  |
| Derivative liability | $ | — |  |  | $ | — |  |  | $ | 52.4 |  |  | $ | 52.4 |  |
| Acquisition contingencies | — |  |  | — |  |  | 2.7 |  |  | 2.7 |  |
| Total other accrued liabilities | $ | — |  |  | $ | — |  |  | $ | 55.1 |  |  | $ | 55.1 |  |

[0001633978-19-000002:notes:202]
(1)  Excludes $103.6 million in cash held in our bank accounts at June 30, 2018.

[0001633978-19-000002:notes:203]
[same as prior period, unchanged from 0001628280-18-013240:notes:169]

[0001633978-19-000002:notes:204]
[same as prior period, unchanged from 0001628280-18-013240:notes:170]

[0001633978-19-000002:notes:205]
Management utilizes various valuation methods, including an income approach, a market approach and a cost approach, to estimate the fair value of intangible and other long-lived assets. During the annual impairment testing performed in fiscal 2018, we concluded that our intangible and other long-lived assets were not impaired.

[0001633978-19-000002:notes:206]
No impairment charges were recorded during the three and six months ended December 29, 2018 and December 30, 2017. Refer to “Note 5. Business Combination” and “Note 14. Goodwill and Other Intangible Assets.”


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001633978-19-000002:notes:207]
[same as prior period, unchanged from 0001628280-18-013240:notes:172]


## us-gaap:FiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0001633978-19-000002:notes:208]
[same as prior period, unchanged from 0001628280-18-013240:notes:173]

[0001633978-19-000002:notes:209]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |  | December 29, 2018 |  | December 30, 2017 |
| Cost of sales | $ | 4.4 |  |  | $ | 0.8 |  |  | $ | 5.2 |  |  | $ | 1.6 |  |
| Selling, general and administrative | 0.8 |  |  | — |  |  | 0.8 |  |  | — |  |
| Total | $ | 5.2 |  |  | $ | 0.8 |  |  | $ | 6.0 |  |  | $ | 1.6 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001633978-19-000002:notes:210]
Note 14. Goodwill and Other Intangible Assets

[0001633978-19-000002:notes:211]
[same as prior period, unchanged from 0001628280-18-013240:notes:176]

[0001633978-19-000002:notes:212]
On December 10, 2018, we completed the merger with Oclaro. As of the acquisition date, we recognized goodwill in the amount of $333.4 million and allocated it to OpComms. The following table presents the changes in goodwill by our reportable segments during the six months ended December 29, 2018 (in millions):

[0001633978-19-000002:notes:213]
|  | Optical Communications |  | Commercial Lasers |  | Total |
| Balance as of beginning of period | $ | 5.9 |  |  | $ | 5.4 |  |  | $ | 11.3 |  |
| Acquisition of Oclaro | 333.4 |  |  | — |  |  | 333.4 |  |
| Balance as of end of period | $ | 339.3 |  |  | $ | 5.4 |  |  | $ | 344.7 |  |

[0001633978-19-000002:notes:214]
[same as prior period, unchanged from 0001628280-18-013240:notes:181]

[0001633978-19-000002:notes:215]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. In the fourth quarter of fiscal 2018, we completed the annual impairment test of goodwill, which indicated there was no goodwill impairment. During the three and six months ended December 29, 2018 and December 30, 2017, there have been no events or circumstances that have required us to perform an interim assessment of goodwill for impairment.

[0001633978-19-000002:notes:216]
Other Intangibles

[0001633978-19-000002:notes:217]
In connection with our acquisition of Oclaro on December 10, 2018, we recorded $444.0 million as our preliminary estimate of the fair value of the acquired developed technologies and other intangible assets. The intangible assets acquired from Oclaro consist of the following:

[0001633978-19-000002:notes:218]
| Intangible |  | Fair value(in millions) |  | Weighted average amortization period(in years) |
| Acquired developed technologies |  | $ | 182.0 |  |  | 4.4 years |
| Customer relationships |  | 145.0 |  |  | 8 years |
| In-process research and development |  | 95.0 |  |  | n/a |
| Order backlog |  | 22.0 |  |  | 1 year |
|  |  | $ | 444.0 |  |  |  |

[0001633978-19-000002:notes:219]
The intangible assets are amortized on a straight-line basis over the estimated useful lives, except for customer relationships and order backlog, which are amortized using an accelerated method of amortization over the expected customer lives, which more accurately reflects the pattern of realization of economic benefits expected to be obtained. Acquired developed technologies and order backlog are amortized to cost of sales and customer relationships is amortized to selling, general and administrative. The IPR&D will be accounted for as an indefinite-lived intangible asset and will not be amortized until the underlying projects reach technological feasibility and commercial production or are abandoned at which point the IPR&D will be amortized over the estimated useful life. Useful lives for these IPR&D projects are expected to range between 4 to 9 years.

[0001633978-19-000002:notes:220]
The following tables present details of our other intangibles, including those acquired in connection with the Oclaro acquisition, as of the periods presented (in millions):

[0001633978-19-000002:notes:221]
| December 29, 2018: | Gross Carrying Amount |  | Accumulated Amortization |  | Net |
| Acquired developed technologies | $ | 287.5 |  |  | $ | (102.5 | ) |  | $ | 185.0 |  |
| Customer relationships and order backlog | 171.3 |  |  | (6.3 | ) |  | 165.0 |  |
| In-process research and development | 95.0 |  |  | — |  |  | 95.0 |  |
| Other intangibles | 2.7 |  |  | (2.7 | ) |  | — |  |
| Total intangible assets | $ | 556.5 |  |  | $ | (111.5 | ) |  | $ | 445.0 |  |

[0001633978-19-000002:notes:222]
| June 30, 2018: | Gross Carrying Amount |  | Accumulated Amortization |  | Net |
| Acquired developed technologies | $ | 105.5 |  |  | $ | (98.5 | ) |  | $ | 7.0 |  |
| Customer relationships | 4.3 |  |  | (4.3 | ) |  | — |  |
| Other intangibles | 2.7 |  |  | (2.7 | ) |  | — |  |
| Total intangible assets | $ | 112.5 |  |  | $ | (105.5 | ) |  | $ | 7.0 |  |

[0001633978-19-000002:notes:223]
[same as prior period, unchanged from 0001628280-18-013240:notes:187]

[0001633978-19-000002:notes:224]
During the three and six months ended December 29, 2018, we recorded $5.2 million and $6.0 million, respectively, of amortization related to acquired developed technologies and other intangibles. During the three and six months ended December 30, 2017, we recorded $0.8 million and $1.6 million, respectively, of amortization related to acquired developed technologies.

[0001633978-19-000002:notes:225]
Based on the carrying amount of our acquired developed technologies and other intangibles, excluding IPR&D, as of December 29, 2018, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001633978-19-000002:notes:226]
| Fiscal Years |  |
| Remainder of 2019 | $ | 40.9 |  |
| 2020 | 80.2 |  |
| 2021 | 65.7 |  |
| 2022 | 63.6 |  |
| Thereafter | 99.6 |  |
| Total amortization | $ | 350.0 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001633978-19-000002:notes:227]
Note 16. Income Taxes

[0001633978-19-000002:notes:228]
The comparability of our operating results in the first half of fiscal 2019 compared to the corresponding prior year period was impacted by the U.S. Tax Cuts and Jobs Act of 2017 (the “Tax Act”), which was enacted on December 22, 2017. The Tax Act introduced significant changes to U.S. income tax law including reducing the U.S. federal statutory tax rate from 35% to 21% and imposing new taxes on certain foreign-sourced earnings and certain intercompany payments. Due to the timing of the enactment and the complexity involved in applying the provisions of the Tax Act, we made reasonable estimates of the effects and recorded provisional amounts in our financial statements as of fiscal 2018 in accordance with SEC Staff Accounting Bulletin No. 118 (“SAB 118”). During the period ended December 29, 2018, we completed our accounting for the Tax Act with no material adjustment to our provisional estimates recorded.

[0001633978-19-000002:notes:229]
[same as prior period, unchanged from 0001628280-18-013240:notes:193]

[0001633978-19-000002:notes:230]
Our quarterly tax provision and estimate of our annual effective tax rate are subject to variation due to several factors, including variability in pre-tax income (or loss), the mix of jurisdictions to which such income relates, changes in how we do business, and tax law developments. Our estimated effective tax rate for the fiscal 2019 differs from the 21% U.S. statutory rate primarily due to the income tax benefit of the earnings of our foreign subsidiaries being taxed at rates lower than the U.S. statutory rate as well as the U.S. federal R&D tax credit, partially offset by the income tax expense from non-deductible stock-based compensation and the tax effect of Global Intangible Low-Taxed Income (“GILTI”), Base Erosion and Anti-Abuse Tax (“BEAT”), and subpart F inclusion.

[0001633978-19-000002:notes:231]
We recorded a tax expense of $1.4 million and $6.6 million for the three and six months ended December 29, 2018, respectively. Our provision for income taxes for the three and six months ended December 29, 2018 varied from the 21% U.S. statutory rate primarily due to the income tax benefit of the earnings of our foreign subsidiaries being taxed at rates lower than the U.S. statutory rate as well as the U.S. federal R&D tax credit, partially offset by the income tax expense from non-deductible stock-based compensation and the tax effect of GILTI, BEAT, and subpart F inclusion.

[0001633978-19-000002:notes:232]
We recorded a tax benefit of $109.3 million and $112.9 million for the three and six months ended December 30, 2017, respectively. Our benefit from income taxes for the three and six months ended December 30, 2017 varied from the previous U.S. federal statutory income tax rate of 35% primarily due to earnings in foreign operations, the tax benefit from excess stock-based compensation deductions, and the non-taxable unrealized gain from the embedded derivatives for the Series A Preferred Stock. Our tax benefit for the three and six months ended December 30, 2017 was primarily due to the release of our U.S. federal and certain state valuation allowances. The benefit of this valuation allowance release was partially offset by a non-cash deferred expense associated with the change in the U.S. statutory rate as a result of the Tax Act which was enacted during the three-month period ended December 30, 2017.

[0001633978-19-000002:notes:233]
As of December 29, 2018, we had $9.0 million of unrecognized tax benefits, which, if recognized, would affect the effective tax rate. We are subject to examination of income tax returns by various domestic and foreign tax authorities. The timing of resolutions and closures of tax audits is highly unpredictable. Given the uncertainty, it is reasonably possible that certain tax audits may be concluded within the next 12 months. An estimate of the range of increase or decrease that could occur in the next 12 months cannot be made. However, the estimated impact to tax expense and net income from the resolution and closure of tax exams is not expected to be significant within the next 12 months.

[0001633978-19-000002:notes:234]
On July 24, 2018, the Ninth Circuit Court of Appeals (the “Court”) issued an opinion in Altera Corp. v. Commissioner requiring related parties in an intercompany cost sharing arrangement to share expenses related to share-based compensation. This opinion reversed the prior decision of the United States Tax Court. On August 7, 2018, the Court withdrew the opinion issued on July 24, 2018 to allow time for a reconstituted panel of judges to confer. We will continue to monitor the case and potential impact to our consolidated financial statements.


## us-gaap:InterestIncomeAndInterestExpenseDisclosureTableTextBlock

[0001633978-19-000002:notes:235]
The following table sets forth interest expense information related to the term loan, including interest expense associated with the ticking fee, for the periods presented (in millions):

[0001633978-19-000002:notes:236]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |  | December 29, 2018 |  | December 30, 2017 |
| Contractual interest expense | $ | 3.7 |  |  | $ | — |  |  | $ | 4.1 |  |  | $ | — |  |
| Amortization of the debt issuance costs | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |
| Total interest expense | $ | 3.8 |  |  | $ | — |  |  | $ | 4.2 |  |  | $ | — |  |


## us-gaap:LongTermDebtTextBlock

[0001633978-19-000002:notes:237]
Note 6. Term Loan Facility

[0001633978-19-000002:notes:238]
On March 11, 2018, in connection with the Oclaro merger, Lumentum entered into a commitment letter with Deutsche Bank Securities Inc. and Deutsche Bank AG New York Branch (“Deutsche Bank”), pursuant to which, Deutsche Bank committed to provide a senior secured term loan facility to finance the merger.

[0001633978-19-000002:notes:239]
On December 10, 2018 (the “Closing Date”), concurrent with the closing of the Oclaro merger, Lumentum entered into a Credit and Guarantee Agreement (the “Credit Agreement”), by and among Lumentum, certain subsidiaries of Lumentum, the lenders party thereto, and Deutsche Bank, as administrative agent and collateral agent for the lenders. The Credit Agreement provides for a senior secured term loan facility (the “Term Loan Facility”) in an aggregate principal amount of $500.0 million. The term loans available under the Term Loan Facility were fully drawn on the Closing Date and the proceeds of the term loans were used to consummate the merger and pay fees and expenses in connection with the merger and the Term Loan Facility.

[0001633978-19-000002:notes:240]
The term loans will mature on the seventh anniversary of the Closing Date, at which time all outstanding principal and accrued and unpaid interest on the term loans must be repaid.  Commencing on the last business day of the first full fiscal quarter after the Closing Date, the term loans will amortize in equal quarterly installments equal to 0.25% of the original principal amount of the Term Loans, with the balance payable due on December 10, 2025, the maturity date. We are required to make mandatory prepayments of the outstanding principal amount of term loans with the net cash proceeds from the disposition of certain assets and the receipt of insurance proceeds upon certain casualty and condemnation events, in each case, to the extent in excess of the certain threshold amounts and to the extent not reinvested within a specified time period. We are also required to make mandatory prepayments of the outstanding principal amount of term loans from the incurrence of certain types of indebtedness and from any excess cash flow beyond stated threshold amounts. We have the right to prepay the term loans, in whole or in part, at any time without premium or penalty, subject to certain limitations and a 1.00% soft call premium applicable during the first six months following the Closing Date.

[0001633978-19-000002:notes:241]
The term loans bear interest at a rate equal to an applicable margin plus, at our option, either (a) a base rate equal to the highest of (i) the prime rate then in effect, (ii) the federal funds rate, plus 0.50% and (iii) an adjusted LIBOR rate determined on the basis of a one-month interest period, plus 1.0%, subject to a floor of 0.0%, or (b) an adjusted LIBOR rate, subject to a floor of 0.0%. The applicable margin with respect to the initial term loans is equal to 2.50% in the case of LIBOR rate loans and 1.50% in the case of base rate loans. The applicable margin is adjusted following the first full fiscal quarter after the Closing Date, if our first lien net leverage ratio is equal to or less than 0.50:1.00, to 2.25% in the case of LIBOR rate loans and 1.25% in the case of base rate loans. During the three and six months ended December 29, 2018, we recorded interest expense of $1.4 million related to the initial term loans, which is included in interest and other income (expense), net in our condensed consolidated statements of operations.

[0001633978-19-000002:notes:242]
The commitment letter with Deutsche Bank required payment of a ticking fee. During the three and six months ended December 29, 2018, we recorded total expenses in connection with the ticking fee of $2.3 million and $2.7 million, respectively. This ticking fee expense is included in interest and other income (expense), net in our condensed consolidated statements of operations.

[0001633978-19-000002:notes:243]
The Credit Agreement permits us to add one or more incremental term loan facilities. Incremental loans are subject to certain additional conditions, including, without limitation, obtaining additional commitments from the lenders then party to the Credit Agreement or from new lenders.

[0001633978-19-000002:notes:244]
Our obligations under the Credit Agreement are required to be guaranteed by certain of our domestic subsidiaries meeting materiality thresholds set forth in the Credit Agreement. Such obligations, including the guaranties, are secured by substantially all of the assets of Lumentum and Lumentum’s subsidiary guarantors (other than customarily excluded assets) pursuant to a Pledge and Security Agreement, dated as of December 10, 2018, by and among Lumentum and Deutsche Bank.

[0001633978-19-000002:notes:245]
The Credit Agreement contains customary affirmative and negative covenants, including covenants limiting the ability of Lumentum and its restricted subsidiaries to, among other things, incur debt, grant liens, undergo certain fundamental changes, make investments, make certain restricted payments, dispose of assets, and enter into transactions with affiliates, in each case, subject to limitations and exceptions set forth in the Credit Agreement. The Credit Agreement also contains customary events of default that include, among other things, certain payment defaults, cross defaults to other indebtedness, covenant defaults, change of control defaults, judgment defaults, and bankruptcy and insolvency defaults. If an event of default exists, the lenders may require the immediate payment of all obligations under the Credit Agreement, and may exercise certain other rights and remedies provided for under the Credit Agreement, the other loan documents and applicable law. As of December 29, 2018, we were in compliance with all of the covenants.

[0001633978-19-000002:notes:246]
We incurred $9.3 million of debt issuance costs in connection with the Term Loan Facility which were capitalized and recorded as a contra liability in our condensed consolidated balance sheet. These costs will be amortized to interest expense using the effective interest rate method from the issuance date of December 10, 2018, through the end of the term of the loan. As of December 29, 2018, the effective interest rate is 5.16% and the stated interest rate is 4.89%.

[0001633978-19-000002:notes:247]
The following table sets forth balance sheet information related to the term loan at December 29, 2018 (in millions):

[0001633978-19-000002:notes:248]
|  | December 29, 2018 |
| Principal | $ | 500.0 |  |
| Unamortized value of the debt issuance costs | (9.2 | ) |
| Net carrying value | $ | 490.8 |  |
| Term loan, current | $ | 5.0 |  |
| Term loan, non-current | $ | 485.8 |  |


## us-gaap:MinorityInterestDisclosureTextBlock

[0001633978-19-000002:notes:249]
Note 11. Non-Controlling Interest Redeemable Convertible Preferred Stock

[0001633978-19-000002:notes:250]
On July 31, 2015, our wholly-owned subsidiary, Lumentum Inc., issued 40,000 shares of its Series A Preferred Stock to Viavi Solutions Inc. (“Viavi”). Pursuant to a securities purchase agreement between us, Viavi and Amada Holdings Co., Ltd. (“Amada”), 35,805 shares of Series A Preferred Stock were sold by Viavi to Amada in August 2015. The remaining 4,195 shares of the Series A Preferred Stock were canceled.

[0001633978-19-000002:notes:251]
As of June 30, 2018, the Series A Preferred Stock was referred to as our Non-Controlling Interest Redeemable Convertible Preferred Stock within these condensed consolidated financial statements, and was recorded at $35.8 million.

[0001633978-19-000002:notes:252]
On October 15, 2018, we issued a 30-day notice of intent to the holders of Series A Preferred Stock to convert all shares of Series A Preferred Stock at a conversion price equal to the Issuance Value divided by $24.63 plus the accrued and unpaid dividends on each share and any past due dividends, whether or not authorized or declared. On November 2, 2018, we received notice from Amada of their intent to convert the Series A Preferred Stock and we issued 1.5 million shares of our common stock to Amada upon the conversion of the 35,805 shares of Series A Preferred Stock and recorded $79.4 million in additional paid in capital in the condensed consolidated balance sheet as of December 29, 2018.

[0001633978-19-000002:notes:253]
Up through the date of conversion, the Series A Preferred Stock conversion feature is bifurcated from the Series A Preferred Stock and accounted for separately as a derivative liability. The derivative liability is measured at fair value each reporting period, and at the date of conversion, with the change in fair value recorded in the condensed consolidated statements of operations. Refer to “Note 13. Derivative Liability”.

[0001633978-19-000002:notes:254]
Up through the date of conversion, holders of Series A Preferred Stock, in preference to holders of common stock or any other class or series of our outstanding capital stock ranking in any such event junior to the Series A Preferred Stock, were entitled to receive, when and as declared by the board of directors, quarterly cumulative cash dividends at the annual rate of 2.5% of the Issuance Value per share on each outstanding share of Series A Preferred Stock. The accrued dividends were payable on March 31, June 30, September 30 and December 31 of each year commencing on September 30, 2015. The accrued dividends as of November 2, 2018, the effective date of the conversion of all outstanding Series A Preferred Stock, and June 30, 2018 were $0.3 million and $0.4 million, respectively. During the three and six months ended December 29, 2018, we paid $0.3 million and $0.7 million, respectively, in dividends to the holders of Series A Preferred Stock. During the three and six months ended December 30, 2017, we paid zero and $0.2 million, respectively, in dividends to the holders of Series A Preferred Stock.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001633978-19-000002:notes:255]
Accounting Pronouncements Recently Adopted

[0001633978-19-000002:notes:256]
In May 2014, the Financial Accounting Standards Board (“FASB”) issued ASU 2014-09 (Topic 606), which amended the existing accounting standards for revenue recognition. Topic 606 outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers. The guidance is effective for annual reporting periods including interim reporting periods beginning after December 15, 2017. On July 1, 2018, we adopted Topic 606 using the modified retrospective method applied to all contracts that are not completed contracts at the date of initial adoption (i.e., July 1, 2018). Results for reporting periods after July 1, 2018 are presented under Topic 606, while prior period amounts are not adjusted and continue to be reported in accordance with our historical accounting under Topic 605. The adoption of Topic 606 did not have a material impact on the nature and timing of our revenues, condensed consolidated statements of operations, cash flows, and balance sheets and therefore, we do not present results for the three and six months ended December 29, 2018 under Topic 605. Refer to “Note 1. Description of Business and Summary of Significant Accounting Policies” for the changes in our accounting policies due to adoption of Topic 606.

[0001633978-19-000002:notes:257]
Select condensed consolidated balance sheet line items, as if we had adopted Topic 606 prior to July 1, 2018 are summarized below as of the periods presented (in millions):

[0001633978-19-000002:notes:258]
|  | June 30, 2018 |  | Adjustments |  | July 1, 2018 |
| Assets: |  |  |  |  |  |
| Accounts receivable, net | $ | 197.1 |  |  | $ | 0.6 |  |  | $ | 197.7 |  |
| Inventories | 153.6 |  |  | (1.2 | ) |  | 152.4 |  |
| Stockholders’ equity: |  |  |  |  |  |
| Retained earnings | $ | 166.4 |  |  | $ | (0.6 | ) |  | $ | 165.8 |  |

[0001633978-19-000002:notes:259]
In August 2016, FASB issued ASU 2016-15, Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments, which clarifies how companies present and classify certain cash receipts and cash payments in the statement of cash flows. The amendments contained in ASU 2016-15 are effective for interim and annual periods beginning after December 15, 2017. We adopted ASU 2016-15 on July 1, 2018 on a prospective basis. The application of ASU 2016-15 will have a material impact on our consolidated financial statements if we elect to settle the principal amounts of our 2024 Notes (refer to “Note 12. Convertible Senior Notes”) in cash. The principal repayment will be bifurcated between (i) cash outflows for operating activities of $137.6 million for the portion related to accreted interest attributable to debt discount, and (ii) financing activities for the remainder of $312.4 million.

[0001633978-19-000002:notes:260]
In January 2017, FASB issued ASU 2017-01, Business Combinations (Topic 805), which clarifies the definition of a business. For accounting and financial reporting purposes, businesses are generally comprised of three elements; inputs, processes, and outputs. Integrated sets of assets and activities capable of providing these three elements may not always be considered a business, and the lack of one of the three elements does not always disqualify the set from being a business. The issuance of ASU 2017-01 provides a clarifying test to determine when a set of assets and activities is not a business. Primarily, the test requires that when substantially all of the fair value of the gross assets acquired is concentrated in a single identifiable asset or group of similar identifiable assets, the set is not a business. The amendments contained in ASU 2017-01 are effective for annual periods beginning after December 15, 2017, including interim periods within those periods. We adopted ASU 2017-01 on July 1, 2018 on a prospective basis. The implementation of ASU 2017-01 did not have an impact on our condensed consolidated financial statements.

[0001633978-19-000002:notes:261]
In October 2016, FASB issued ASU 2016-16, Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets other than Inventory. The new guidance removes the prohibition in ASC 740 against the immediate recognition of the current and deferred income tax effects of intra-entity transfers of assets other than inventory. The new guidance became effective for us in the first quarter of our fiscal 2019. The adoption of ASU 2016-16 did not have a material impact on our financial statements.

[0001633978-19-000002:notes:262]
In August 2018, FASB issued ASU 2018-15, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract. ASU 2018-15 requires an entity in a hosting arrangement that is a service contract to follow the guidance in Subtopic 350-40 to determine which implementation costs to capitalize as an asset related to the service contract and which costs to expense. Implementation costs capitalized must be expensed over the term of the hosting arrangement, including the period covered by an option to extend the arrangement. The standard is effective for fiscal years beginning after December 15, 2019, and interim periods within those fiscal years, and should be applied either retrospectively or prospectively to all implementation costs incurred after the date of adoption. Early adoption is permitted, including adoption in any interim period, for all entities. We early adopted ASU 2018-15, which did not have a material impact on our financial statements.

[0001633978-19-000002:notes:263]
Accounting Pronouncements Not Yet Effective

[0001633978-19-000002:notes:264]
In August 2018, the Securities and Exchange Commission (“SEC”) adopted amendments to certain disclosure requirements in Securities Act Release No. 33-10532, Disclosure Update and Simplification. The amendments became effective on November 5, 2018.  Among the amendments is the requirement to present the changes in shareholders’ equity in the interim financial statements (either in a separate statement or footnote) in quarterly reports on Form 10-Q. The analysis should present a reconciliation of the beginning balance to the ending balance of each period for which a consolidated statement of operations is required to be filed. We will include the first presentation of changes in stockholders’ equity on our Form 10-Q in our third quarter of fiscal 2019.

[0001633978-19-000002:notes:265]
In August 2018, FASB issued ASU 2018-14, Compensation-Retirement Benefits-Defined Benefit Plans-General (Topic 715-20): Disclosure Framework-Changes to the Disclosure Requirements for Defined Benefit Plans. ASU 2018-14 modifies the disclosure requirements for defined benefit pension plans and other postretirement benefit plans. The new guidance is effective for fiscal years ending after December 15, 2020 and early adoption is permitted. ASU 2018-14 should be applied retrospectively to all periods presented and is effective for us in our first quarter of fiscal 2022. We are currently evaluating the impact of ASU 2018-14 on our consolidated financial statements.

[0001633978-19-000002:notes:266]
In August 2018, FASB issued ASU 2018-13, Fair Value Measurement (Topic 820): Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement. ASU 2018-13 modifies the disclosure requirements for fair value measurements. The new guidance is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Entities are permitted to early adopt any removed or modified disclosures upon issuance of ASU 2018-13 and delay adoption of the additional disclosures until the effective date. The standard is effective for us in our first quarter of fiscal 2021. We are currently evaluating the impact of ASU 2018-13 on our consolidated financial statements and related disclosures.

[0001633978-19-000002:notes:267]
In February 2018, FASB issued ASU 2018-02, Income Statement-Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which allows companies to reclassify stranded tax effects resulting from the Tax Act, from accumulated other comprehensive income to retained earnings. The guidance also requires certain new disclosures regardless of the election. The amendments in ASU 2018-02 are effective for all entities for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years. Early adoption is permitted, including adoption in any interim period. ASU 2018-02 is effective for us in the first quarter of fiscal 2020. We are currently evaluating the impact of our pending adoption of ASU 2018-02 on our consolidated financial statements.

[0001633978-19-000002:notes:268]
In January 2017, FASB issued ASU 2017-04, Intangibles - Goodwill and Other (Topic 350): Simplifying the Accounting for Goodwill Impairment. ASU 2017-04 removes the requirement to perform a hypothetical purchase price allocation to measure goodwill impairment. A goodwill impairment charge will be the amount by which a reporting unit's carrying value exceeds its fair value, not to exceed the carrying amount of goodwill. The amendments contained in ASU 2017-04 are effective for interim and annual periods beginning after December 15, 2019, with early adoption permitted, which should be applied prospectively. We plan to adopt the accounting standard update in our first quarter of fiscal 2020. We are currently evaluating the impact of ASU 2017-04 on our consolidated financial statements.

[0001633978-19-000002:notes:269]
In June 2016, FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments and a subsequent amendment, ASU 2018-19 (collectively, Topic 326). Topic 326 requires measurement and recognition of expected credit losses for financial assets held. Topic 326 is effective for annual periods beginning after December 15, 2019, including interim periods within those periods, with early adoption permitted. We are currently evaluating the impact of our pending adoption of Topic 326 on our consolidated financial statements.

[0001633978-19-000002:notes:270]
In February 2016, FASB issued ASU 2016-02, Leases (Topic 842) and subsequent amendments to the initial guidance: ASU 2017-13, ASU 2018-10, ASU 2018-11 and ASU 2018-20 (collectively, Topic 842). The new guidance generally requires an entity to recognize on its balance sheet operating and financing lease liabilities and corresponding right-of-use assets. The new guidance contained in Topic 842 is effective for annual periods beginning after December 15, 2018, including interim periods within those periods, with early adoption permitted. The standard is effective for us in our first quarter of fiscal 2020 where we will be required to recognize and measure leases existing at, or entered into after, the beginning of the earliest comparative period presented using a modified retrospective approach, with an option to elect certain practical expedients. Based on our current lease portfolio, we estimate the value of leased assets and liabilities that may be recognized will be material. We are continuing to evaluate the impact of Topic 842 which is subject to change.


## us-gaap:OtherCurrentLiabilitiesTableTextBlock

[0001633978-19-000002:notes:271]
[same as prior period, unchanged from 0001628280-18-013240:notes:236]

[0001633978-19-000002:notes:272]
|  | December 29, 2018 |  | June 30, 2018 |
| Warranty accrual (1) | $ | 9.7 |  |  | $ | 6.6 |  |
| Restructuring accrual and related charges (2) | 3.5 |  |  | 1.9 |  |
| Deferred revenue and customer deposits | 3.9 |  |  | 2.8 |  |
| Capital lease obligation (3) | 3.7 |  |  | 7.3 |  |
| Income tax payable (4) | 7.2 |  |  | 0.7 |  |
| Other current liabilities | 5.6 |  |  | 2.8 |  |
| Other current liabilities | $ | 33.6 |  |  | $ | 22.1 |  |

[0001633978-19-000002:notes:273]
(1) Refer to “Note 18. Commitments and Contingencies.”

[0001633978-19-000002:notes:274]
(2) Refer to “Note 15. Restructuring and Related Charges.”

[0001633978-19-000002:notes:275]
(3) In addition to the $3.7 million of capital lease obligations recorded within other current liabilities, we also recorded $1.6 million within accounts payable and $0.5 million within other non-current liabilities in the condensed consolidated balance sheet as of December 29, 2018. Refer to “Note 18. Commitments and Contingencies.”

[0001633978-19-000002:notes:276]
(4) Refer to “Note 16. Income Taxes.”


## us-gaap:OtherNoncurrentLiabilitiesTableTextBlock

[0001633978-19-000002:notes:277]
[same as prior period, unchanged from 0001628280-18-013240:notes:241]

[0001633978-19-000002:notes:278]
|  | December 29, 2018 |  | June 30, 2018 |
| Asset retirement obligation | $ | 2.8 |  |  | $ | 2.7 |  |
| Pension and related accrual (1) | 10.9 |  |  | 3.5 |  |
| Deferred rent | 2.5 |  |  | 2.6 |  |
| Unrecognized tax benefit | 9.0 |  |  | 6.1 |  |
| Capital lease obligation | 0.5 |  |  | 0.4 |  |
| Other non-current liabilities | 0.9 |  |  | 3.4 |  |
| Other non-current liabilities | $ | 26.6 |  |  | $ | 18.7 |  |

[0001633978-19-000002:notes:279]
(1) In connection with our acquisition of Oclaro, we assumed a defined benefit plan, which covers certain Japan employees. As of December 29, 2018, we recorded $6.9 million in other non-current liabilities in our condensed consolidated balance sheet to account for the projected benefit obligations.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001633978-19-000002:notes:280]
[same as prior period, unchanged from 0001628280-18-013240:notes:243]

[0001633978-19-000002:notes:281]
|  | December 29, 2018 |  | June 30, 2018 |
| Land | $ | 10.6 |  |  | $ | 10.6 |  |
| Buildings and improvement | 65.9 |  |  | 55.1 |  |
| Machinery and equipment (1) | 595.2 |  |  | 463.6 |  |
| Computer equipment and software | 41.4 |  |  | 26.3 |  |
| Furniture and fixtures | 4.0 |  |  | 2.2 |  |
| Leasehold improvements | 28.9 |  |  | 25.8 |  |
| Construction in progress | 63.6 |  |  | 52.6 |  |
|  | 809.6 |  |  | 636.2 |  |
| Less: Accumulated depreciation (1) | (364.9 | ) |  | (329.3 | ) |
| Property, plant and equipment, net | $ | 444.7 |  |  | $ | 306.9 |  |

[0001633978-19-000002:notes:282]
(1) In fiscal 2018, we started leasing equipment from a vendor and have accounted for the transaction as a capital lease.  Included in the table above are our capital lease assets of $17.5 million, gross and $8.2 million in accumulated depreciation as of December 29, 2018, and $15.6 million, gross and $5.2 million in accumulated depreciation as of June 30, 2018.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001633978-19-000002:notes:283]
Note 15. Restructuring and Related Charges

[0001633978-19-000002:notes:284]
We have initiated various strategic restructuring events primarily intended to reduce costs, consolidate our operations, rationalize the manufacturing of our products and align our business in response to market conditions and as a result of our acquisition of Oclaro on December 10, 2018.

[0001633978-19-000002:notes:285]
The following table summarizes the activity of restructuring and related charges during the three and six months ended December 29, 2018 and December 30, 2017 (in millions):

[0001633978-19-000002:notes:286]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |  | December 29, 2018 |  | December 30, 2017 |
| Balance as of beginning of period | $ | 1.6 |  |  | $ | 1.3 |  |  | $ | 1.9 |  |  | $ | 3.8 |  |
| Charges | 7.8 |  |  | 0.8 |  |  | 9.1 |  |  | 3.7 |  |
| Payments | (5.9 | ) |  | (1.7 | ) |  | (7.5 | ) |  | (7.1 | ) |
| Balance as of end of period | $ | 3.5 |  |  | $ | 0.4 |  |  | $ | 3.5 |  |  | $ | 0.4 |  |

[0001633978-19-000002:notes:287]
During the three and six months ended December 29, 2018, we recorded $7.8 million and $9.1 million, respectively, in restructuring and related charges in our condensed consolidated statements of operations, primarily attributable to severance and employee related benefits associated with Oclaro’s executive severance and retention agreements. These retention agreements provide, under certain circumstances, for payments and benefits upon an involuntary termination of employment. We made $5.7 million of payments in connection with these agreements during the three and six months ended December 29, 2018. Refer to “Note 5. Business Combinations.”

[0001633978-19-000002:notes:288]
On September 5, 2018, we implemented an internal re-organization to help us extend our market leadership position. The re-organization focuses on strengthening our product quality, developing new enabling technologies required to support a long-term portfolio roadmap, and developing commercial proposals and new product introduction (“NPI”) priorities to maintain and grow our market leadership position, while continuing to drive new customer and ecosystem partner engagements.

[0001633978-19-000002:notes:289]
During the three and six months ended December 30, 2017, we recorded $0.8 million and $3.7 million, respectively, in restructuring and related charges in our condensed consolidated statements of operations, primarily attributable to costs to vacate facilities, temporary labor and employee-related benefits, as well as costs for materials used in set up and production activities. We incurred no additional costs related to severance during the three and six months ended December 30, 2017.

[0001633978-19-000002:notes:290]
Any changes in the estimates of executing our restructuring activities will be reflected in our future results of operations.


## us-gaap:ScheduleOfBusinessAcquisitionsByAcquisitionTextBlock

[0001633978-19-000002:notes:291]
Our preliminary allocation of the purchase price of Oclaro, based on the estimated fair values of the assets acquired and liabilities assumed as of the acquisition date, is as follows (in millions):


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001633978-19-000002:notes:292]
Long-lived assets, namely net property, plant and equipment, net, were identified based on the physical location of the assets in the corresponding geographic areas as of the periods indicated (in millions):

[0001633978-19-000002:notes:293]
|  | December 29, 2018 |  | June 30, 2018 |
| Property, Plant and Equipment, net |  |  |  |
| United States | $ | 111.7 |  |  | $ | 97.6 |  |
| China | 60.9 |  |  | 70.0 |  |
| Japan | 55.2 |  |  | 0.5 |  |
| Thailand | 153.6 |  |  | 107.4 |  |
| Other countries | 63.3 |  |  | 31.4 |  |
| Total long-lived assets | $ | 444.7 |  |  | $ | 306.9 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001633978-19-000002:notes:294]
[same as prior period, unchanged from 0001628280-18-013240:notes:253]

[0001633978-19-000002:notes:295]
|  | December 29, 2018 |  | June 30, 2018 |
| Finished goods | $ | 118.1 |  |  | $ | 98.2 |  |
| Work in process | 129.0 |  |  | 34.5 |  |
| Raw materials and purchased parts | 56.1 |  |  | 20.9 |  |
| Inventories | $ | 303.2 |  |  | $ | 153.6 |  |


## us-gaap:ScheduleOfOtherCurrentAssetsTableTextBlock

[0001633978-19-000002:notes:296]
[same as prior period, unchanged from 0001628280-18-013240:notes:255]

[0001633978-19-000002:notes:297]
|  | December 29, 2018 |  | June 30, 2018 |
| Capitalized manufacturing overhead | $ | 17.1 |  |  | $ | 20.5 |  |
| Prepayments | 26.8 |  |  | 19.5 |  |
| Advances to contract manufacturers | 12.6 |  |  | 14.0 |  |
| Other current assets | 46.6 |  |  | 11.0 |  |
| Prepayments and other current assets | $ | 103.1 |  |  | $ | 65.0 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001633978-19-000002:notes:298]
[same as prior period, unchanged from 0001628280-18-013240:notes:257]

[0001633978-19-000002:notes:299]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |  | December 29, 2018 |  | December 30, 2017 |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 20.7 |  |  | 5.6 | % |  | $ | 25.9 |  |  | 6.4 | % |  | $ | 42.6 |  |  | 5.9 | % |  | $ | 59.5 |  |  | 9.2 | % |
| Mexico | 55.0 |  |  | 14.7 | % |  | 30.6 |  |  | 7.6 | % |  | 111.3 |  |  | 15.3 | % |  | 55.4 |  |  | 8.6 | % |
| Other Americas | 0.9 |  |  | 0.2 | % |  | 2.0 |  |  | 0.5 | % |  | 1.8 |  |  | 0.2 | % |  | 4.2 |  |  | 0.6 | % |
| Total Americas | $ | 76.6 |  |  | 20.5 | % |  | $ | 58.5 |  |  | 14.5 | % |  | $ | 155.7 |  |  | 21.4 | % |  | $ | 119.1 |  |  | 18.4 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 99.9 |  |  | 26.7 | % |  | $ | 45.7 |  |  | 11.3 | % |  | $ | 165.5 |  |  | 22.7 | % |  | $ | 94.6 |  |  | 14.6 | % |
| Japan | 43.2 |  |  | 11.6 | % |  | 89.5 |  |  | 22.1 | % |  | 79.2 |  |  | 10.9 | % |  | 123.6 |  |  | 19.1 | % |
| South Korea | 61.3 |  |  | 16.4 | % |  | 86.5 |  |  | 21.4 | % |  | 131.3 |  |  | 18.0 | % |  | 97.4 |  |  | 15.0 | % |
| Other Asia-Pacific | 61.8 |  |  | 16.5 | % |  | 98.9 |  |  | 24.4 | % |  | 136.0 |  |  | 18.7 | % |  | 162.2 |  |  | 25.0 | % |
| Total Asia-Pacific | $ | 266.2 |  |  | 71.2 | % |  | $ | 320.6 |  |  | 79.2 | % |  | $ | 512.0 |  |  | 70.3 | % |  | $ | 477.8 |  |  | 73.7 | % |
| EMEA | $ | 30.9 |  |  | 8.3 | % |  | $ | 25.5 |  |  | 6.3 | % |  | $ | 60.1 |  |  | 8.3 | % |  | $ | 50.9 |  |  | 7.9 | % |
| Total net revenue | $ | 373.7 |  |  |  |  | $ | 404.6 |  |  |  |  | $ | 727.8 |  |  |  |  | $ | 647.8 |  |  |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001633978-19-000002:notes:300]
[same as prior period, unchanged from 0001628280-18-013240:notes:259]

[0001633978-19-000002:notes:301]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |  | December 29, 2018 |  | December 30, 2017 |
| Net revenue: |  |  |  |  |  |  |  |
| OpComms | $ | 325.4 |  |  | $ | 360.1 |  |  | $ | 635.5 |  |  | $ | 568.0 |  |
| Lasers | 48.3 |  |  | 44.5 |  |  | 92.3 |  |  | 79.8 |  |
| Net revenue | $ | 373.7 |  |  | $ | 404.6 |  |  | $ | 727.8 |  |  | $ | 647.8 |  |
| Gross profit: |  |  |  |  |  |  |  |
| OpComms | 129.1 |  |  | 161.9 |  |  | 254.0 |  |  | 234.0 |  |
| Lasers | 20.6 |  |  | 19.9 |  |  | 38.3 |  |  | 30.5 |  |
| Total segment gross profit | 149.7 |  |  | 181.8 |  |  | 292.3 |  |  | 264.5 |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Stock-based compensation | (5.2 | ) |  | (4.4 | ) |  | (8.5 | ) |  | (7.1 | ) |
| Amortization of intangibles | (4.4 | ) |  | (0.8 | ) |  | (5.2 | ) |  | (1.6 | ) |
| Other charges (1) | (15.3 | ) |  | (5.5 | ) |  | (27.8 | ) |  | (16.2 | ) |
| Gross profit | $ | 124.8 |  |  | $ | 171.1 |  |  | $ | 250.8 |  |  | $ | 239.6 |  |

[0001633978-19-000002:notes:302]
(1) “Other charges” of unallocated corporate items for the three and six months ended December 29, 2018 primarily include costs of transferring product lines to Thailand of $14.5 million and $27.2 million, respectively. During each of the three and six months ended December 30, 2017, “other charges” of unallocated corporate items primarily consisted of set-up costs of our facility in Thailand of $3.1 million, which we incurred during our second quarter of fiscal 2018, as well as inventory write-downs due to canceled programs not allocated to the segments of $7.0 million.


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001633978-19-000002:notes:303]
During the three and six months ended December 29, 2018 and December 30, 2017, net revenue generated from a single customer which represented 10% or greater of total net revenue is summarized as follows:

[0001633978-19-000002:notes:304]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |  | December 29, 2018 |  | December 30, 2017 |
| Customer A | 26.1 | % |  | 49.8 | % |  | 28.3 | % |  | 37.2 | % |
| Customer B | 15.0 | % |  | * |  |  | 15.0 | % |  | 10.5 | % |
| Customer C | 13.8 | % |  | * |  |  | 13.4 | % |  | * |  |
| *Represents less than 10% of total net revenue |  |  |  |  |  |  |  |

[0001633978-19-000002:notes:305]
During the three and six months ended December 29, 2018 and December 30, 2017, net inventory purchased from a single contract manufacturer which represented 10% or greater of total net purchases is summarized as follows:

[0001633978-19-000002:notes:306]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |  | December 29, 2018 |  | December 30, 2017 |
| Vendor A | 48.7 | % |  | 36.0 | % |  | 50.0 | % |  | 40.0 | % |
| Vendor B | 20.4 | % |  | 36.0 | % |  | 22.5 | % |  | 25.0 | % |
| Vendor C | 17.4 | % |  | 14.0 | % |  | 12.6 | % |  | 19.0 | % |

[0001633978-19-000002:notes:307]
The table below discloses our total net revenue attributable to each of our two reportable segments. In addition, it discloses the percentage of our total net revenue attributable to our product offerings which serve the Telecom, Datacom, and Consumer and Industrial markets which accounted for 10% or more of our total net revenue during the periods presented (in millions, except percentage data):

[0001633978-19-000002:notes:308]
|  | Three Months Ended |  |  | Six Months Ended |  |
|  | December 29, 2018 |  | December 30, 2017 |  | December 29, 2018 |  | December 30, 2017 |
| OpComms: | $ | 325.4 |  | 87.1 | % |  | $ | 360.1 |  | 89.0 | % |  | $ | 635.5 |  | 87.3 | % |  | $ | 568.0 |  | 87.7 | % |
| Telecom | 172.5 |  | 46.2 | % |  | 110.2 |  | 27.2 | % |  | 315.4 |  | 43.3 | % |  | 220.6 |  | 34.1 | % |
| Datacom | 33.4 |  | 8.9 | % |  | 34.4 |  | 8.5 | % |  | 67.6 |  | 9.3 | % |  | 79.6 |  | 12.3 | % |
| Consumer and Industrial | 119.5 |  | 32.0 | % |  | 215.5 |  | 53.3 | % |  | 252.5 |  | 34.7 | % |  | 267.8 |  | 41.3 | % |
| Lasers | $ | 48.3 |  | 12.9 | % |  | $ | 44.5 |  | 11.0 | % |  | $ | 92.3 |  | 12.7 | % |  | $ | 79.8 |  | 12.3 | % |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001633978-19-000002:notes:309]
Note 19. Operating Segments and Geographic Information

[0001633978-19-000002:notes:310]
[same as prior period, unchanged from 0001628280-18-013240:notes:269]

[0001633978-19-000002:notes:311]
We are an industry leading provider of optical and photonic products defined by revenue and market share addressing a range of end-market applications including optical communications and commercial lasers. We have two operating segments, Optical Communications, which we refer to as OpComms, and Commercial Lasers, which we refer to as Lasers. Our OpComms products address the following markets: telecommunications (“Telecom”), data communications (“Datacom”), and consumer and industrial (“Consumer and Industrial”), and include product lines from the recent acquisition of Oclaro. The two operating segments were primarily determined based on how the CODM views and evaluates our operations. Operating results are regularly reviewed by the CODM to make decisions about resources to be allocated to the segments and to assess their performance. Other factors, including market separation and customer specific applications, go-to-market channels, products and manufacturing, are considered in determining the formation of these operating segments.

[0001633978-19-000002:notes:312]
[same as prior period, unchanged from 0001628280-18-013240:notes:271]

[0001633978-19-000002:notes:313]
[same as prior period, unchanged from 0001628280-18-013240:notes:272]

[0001633978-19-000002:notes:314]
Our net revenue from Mexico increased due to increased demand for our ROADM products from one of our large customers who manufactures in Mexico, while net revenue from Hong Kong grew due to our 3D sensing products for mobile devices.

[0001633978-19-000002:notes:315]
As of December 29, 2018, two customers each represented greater than 10% of total accounts receivable, net. As of June 30, 2018, two customers each represented greater than 10% of total accounts receivable, net.

[0001633978-19-000002:notes:316]
We purchase a substantial portion of our inventory from contract manufacturers and vendors located primarily in Taiwan, Thailand, and China. During the three and six months ended December 29, 2018 and December 30, 2017, net inventory purchased from a single contract manufacturer which represented 10% or greater of total net purchases is summarized as follows:


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001633978-19-000002:notes:317]
Note 8. Balance Sheet Details

[0001633978-19-000002:notes:318]
[same as prior period, unchanged from 0001628280-18-013240:notes:276]

[0001633978-19-000002:notes:319]
As of each of December 29, 2018 and June 30, 2018, our accounts receivable allowance balance was $2.6 million.

[0001633978-19-000002:notes:320]
[same as prior period, unchanged from 0001628280-18-013240:notes:278]

[0001633978-19-000002:notes:321]
The inventory balance at December 29, 2018 includes $60.3 million related to the inventory step-up adjustment from the Oclaro acquisition.

[0001633978-19-000002:notes:322]
[same as prior period, unchanged from 0001628280-18-013240:notes:279]

[0001633978-19-000002:notes:323]
[same as prior period, unchanged from 0001628280-18-013240:notes:280]

[0001633978-19-000002:notes:324]
During the three and six months ended December 29, 2018, we recorded depreciation expense of $26.0 million and $45.7 million, respectively. During the three and six months ended December 30, 2017, we recorded depreciation expense of $18.2 million and $34.9 million, respectively.

[0001633978-19-000002:notes:325]
[same as prior period, unchanged from 0001628280-18-013240:notes:282]

[0001633978-19-000002:notes:326]
[same as prior period, unchanged from 0001628280-18-013240:notes:283]

[0001633978-19-000002:notes:327]
[same as prior period, unchanged from 0001628280-18-013240:notes:284]
