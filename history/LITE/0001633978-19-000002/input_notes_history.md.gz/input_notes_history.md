# LITE note change history — 0001628280-18-013240 → 0001633978-19-000002


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-02-07):
[0001633978-19-000002:note_history:1]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2033. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. As a result of our acquisition of Oclaro on December 10, 2018, we assumed operating leases with future minimum annual lease payments of $81.9 million.
  (was, 2018-11-01, similarity 0.6984):
[0001628280-18-013240:note_history:1]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2026. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. As of September 29, 2018, the future minimum annual lease payments under non-cancellable operating leases were as follows (in millions):

- changed (2019-02-07):
[0001633978-19-000002:note_history:2]
As of December 29, 2018, the total future minimum annual lease payments under non-cancellable operating leases were as follows (in millions):
  (was, 2018-11-01, similarity 0.84):
[0001628280-18-013240:note_history:2]
As of September 29, 2018 the future minimum annual lease payments under our capital lease were as follows (in millions):

- changed (2019-02-07):
[0001633978-19-000002:note_history:3]
During the three and six months ended December 29, 2018, rental expense relating to building and equipment was $3.2 million and $6.0 million, respectively. During the three and six months ended December 30, 2017, rental expense relating to building and equipment was $3.0 million and $6.4 million, respectively.
  (was, 2018-11-01, similarity 0.6085):
[0001628280-18-013240:note_history:3]
During the three months ended September 29, 2018 and September 30, 2017, rental expense relating to building and equipment was $2.8 million and $3.4 million, respectively.

- changed (2019-02-07):
[0001633978-19-000002:note_history:4]
Capital Leases
  (was, 2018-11-01, similarity 0.963):
[0001628280-18-013240:note_history:4]
Capital Lease

- changed (2019-02-07):
[0001633978-19-000002:note_history:5]
As of December 29, 2018, equipment acquired under capital lease agreements, including those assumed as part of the Oclaro acquisition, was $17.5 million. Our capital lease assets are included in property, plant and equipment, net in our condensed consolidated balance sheets as of December 29, 2018. Amortization expense on these capital lease assets are recorded as depreciation expense and is included in cost of sales in our condensed consolidated statements of operations for the three and six months ended December 29, 2018 and December 30, 2017. Our capital lease obligations are recorded at the lesser of the estimated fair market value of the leased property or the net present value of the aggregate future minimum lease payments and is included in other current liabilities and other non-current liabilities in our condensed consolidated balance sheets as of December 29, 2018. Refer to “Note 8. Balance Sheet Details” for capital lease obligation amounts in other current liabilities and other non-current liabilities. Interest on these obligations is included in interest expense in our condensed consolidated statements of operations.
  (was, 2018-11-01, similarity 0.9014):
[0001628280-18-013240:note_history:5]
As of September 29, 2018, equipment acquired under a capital lease agreement was $15.6 million. Our capital lease asset is included in property, plant and equipment, net in our condensed consolidated balance sheets as of September 29, 2018. Amortization expense on this capital lease asset is recorded as depreciation expense and is included in cost of sales in our condensed consolidated statements of operations for the three months ended September 29, 2018. Our capital lease obligation is recorded at the lesser of the estimated fair market value of the leased property or the net present value of the aggregate future minimum lease payments and is included in other current liabilities and other non-current liabilities in our condensed consolidated balance sheets as of September 29, 2018. Refer to “Note 6. Balance Sheet Details” for capital lease obligation amounts in other current liabilities and other non-current liabilities. Interest on these obligations is included in interest expense in our condensed consolidated statements of operations.

- added (2019-02-07):
[0001633978-19-000002:note_history:6]
In connection with our acquisition of Oclaro, we assumed capital leases related to plant and machinery. This capital lease extends through October 2020, after which time the ownership of the equipment transfers from the lessor to us. During the lease term, we are required to make equal installments of principal and interest, payable quarterly. Interest on this capital lease accrues at 1.15 percent per annum.

- added (2019-02-07):
[0001633978-19-000002:note_history:7]
As of December 29, 2018 the future minimum annual lease payments under our capital leases were as follows (in millions):

- changed (2019-02-07):
[0001633978-19-000002:note_history:8]
| Fiscal Years |  |
| Remainder of 2019 | $ | 4.6 |  |
| 2020 | 1.0 |  |
| 2021 | 0.3 |  |
| Total minimum capital lease payments | $ | 5.9 |  |
| Less: amount representing interest | $ | (0.1 | ) |
| Present value of capital lease obligation | $ | 5.8 |  |
  (was, 2018-11-01, similarity 0.9732):
[0001628280-18-013240:note_history:8]
| Fiscal Years |  |
| Remainder of 2019 | $ | 6.7 |  |
| 2020 | 0.4 |  |
| Total minimum capital lease payments | $ | 7.1 |  |
| Less: amount representing interest | $ | (0.1 | ) |
| Present value of capital lease obligation | $ | 7.0 |  |

- added (2019-02-07):
[0001633978-19-000002:note_history:9]
In February 2017, we incurred liabilities in the amount of $3.6 million related to an acquisition of a privately held company. The amount of up to $3.0 million is expected to be paid within the following 12 months contingent upon meeting certain production targets, and is included in other current liabilities on our consolidated balance sheet as of December 29, 2018.

- added (2019-02-07):
[0001633978-19-000002:note_history:10]
We also retained $1.0 million of the purchase price as security for any potential liabilities of the seller under the representations, warranties and indemnifications included in the purchase agreement. The $1.0 million was fully paid to the seller during the six months ended December 29, 2018.

- added (2019-02-07):
[0001633978-19-000002:note_history:11]
Term Loan

- changed (2019-02-07):
[0001633978-19-000002:note_history:12]
The estimated future interest and principal payments related to the term loan are as follows as of December 29, 2018:
  (was, 2018-11-01, similarity 0.8732):
[0001628280-18-013240:note_history:12]
The future interest and principal payments related to the 2024 Notes are as follows as of September 29, 2018:

- added (2019-02-07):
[0001633978-19-000002:note_history:13]
| Fiscal Years |  |
| Remainder of 2019 | $ | 16.1 |  |
| 2020 | 29.2 |  |
| 2021 | 29.0 |  |
| 2022 | 28.7 |  |
| 2023 | 28.5 |  |
| Thereafter | 533.9 |  |
| Total term loan payments | $ | 665.4 |  |

- added (2019-02-07):
[0001633978-19-000002:note_history:14]
The future interest and principal payments related to the 2024 Notes are as follows as of December 29, 2018:

- added (2019-02-07):
[0001633978-19-000002:note_history:15]
Purchase obligations of $281.8 million as of December 29, 2018, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Included in the $281.8 million are approximately $85.9 million in purchase commitments assumed in connection with our acquisition of Oclaro on December 10, 2018.

- changed (2019-02-07):
[0001633978-19-000002:note_history:16]
Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.
  (was, 2018-11-01, similarity 0.7765):
[0001628280-18-013240:note_history:16]
Purchase obligations of $206.5 million as of September 29, 2018, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

- changed (2019-02-07):
[0001633978-19-000002:note_history:17]
The following table presents the changes in our warranty reserve during the three and six months ended December 29, 2018 and December 30, 2017 (in millions):
  (was, 2018-11-01, similarity 0.9375):
[0001628280-18-013240:note_history:17]
The following table presents the changes in our warranty reserve during the three months ended September 29, 2018 and September 30, 2017 (in millions):

- added (2019-02-07):
[0001633978-19-000002:note_history:18]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |  | December 29, 2018 |  | December 30, 2017 |
| Balance as of beginning of period | $ | 6.6 |  |  | $ | 9.4 |  |  | $ | 6.6 |  |  | $ | 9.7 |  |
| Warranties assumed in Oclaro acquisition | 3.8 |  |  | — |  |  | 3.8 |  |  | — |  |
| Provision for warranty | 0.7 |  |  | 1.9 |  |  | 1.9 |  |  | 2.9 |  |
| Utilization of reserve | (1.4 | ) |  | (1.4 | ) |  | (2.6 | ) |  | (2.7 | ) |
| Balance as of end of period | $ | 9.7 |  |  | $ | 9.9 |  |  | $ | 9.7 |  |  | $ | 9.9 |  |

- added (2019-02-07):
[0001633978-19-000002:note_history:19]
Merger Litigation

- added (2019-02-07):
[0001633978-19-000002:note_history:20]
In connection with our acquisition of Oclaro, seven lawsuits were filed by purported stockholders of Oclaro challenging the proposed merger (the “Merger”). Two of the seven suits were putative class actions filed against Oclaro, its directors, Lumentum, Prota Merger Sub, Inc. and Prota Merger, LLC: Nicholas Neinast v. Oclaro, Inc., et al., No. 3:18-cv-03112-VC, in the United States District Court for the Northern District of California (filed May 24, 2018) (the “Neinast Lawsuit”); and Adam Franchi v. Oclaro, Inc., et al., No. 1:18-cv-00817-GMS, in the United States District Court for the District of Delaware (filed June 9, 2018) (the “Franchi Lawsuit). Both the Neinstat Lawsuit and the Franchi Lawsuit were voluntarily dismissed with prejudice.

- added (2019-02-07):
[0001633978-19-000002:note_history:21]
The other five suits, styled as Gerald F. Wordehoff v. Oclaro, Inc., et al., No. 5:18-cv-03148-NC (the “Wordehoff Lawsuit”), Walter Ryan v. Oclaro, Inc., et al., No. 3:18-cv-03174-VC (the “Ryan Lawsuit”), Jayme Walker v. Oclaro, Inc., et al., No. 5:18-cv-03203-EJD (the “Walker Lawsuit”), Kevin Garcia v. Oclaro, Inc., et al., No. 5:18-cv-03262-VKD (the “Garcia Lawsuit”), and SaiSravan B. Karri v. Oclaro, Inc., et al., No. 3:18-cv-03435-JD (the “Karri Lawsuit” and, together with the other six lawsuits, the “Lawsuits”), were filed in the United States District Court for the Northern District of California on May 25, 2018, May 29, 2018, May 30, 2018, May 31, 2018, and June 9, 2018, respectively. These five Lawsuits named Oclaro and its directors as defendants only and did not name Lumentum. The Wordehoff, Ryan, Walker, and Garcia Lawsuits have been voluntarily dismissed, and the Wordehoff, Ryan, and Walker dismissals were with prejudice. The Karri Lawsuit has not yet been dismissed. The Ryan Lawsuit was, and the Karri Lawsuit is, a putative class action.

- added (2019-02-07):
[0001633978-19-000002:note_history:22]
The Lawsuits generally alleged, among other things, that Oclaro and its directors violated Section 14(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), and Rule 14a-9 promulgated thereunder by disseminating an incomplete and misleading Form S-4, including proxy statement/prospectus. The Lawsuits further alleged that Oclaro’s directors violated Section 20(a) of the Exchange Act by failing to exercise proper control over the person(s) who violated Section 14(a) of the Exchange Act.

- added (2019-02-07):
[0001633978-19-000002:note_history:23]
The remaining Lawsuit (the Karri Lawsuit) currently purports to seek, among other things, damages to be awarded to the plaintiff and any class if the Merger is consummated, and litigation costs, including attorneys’ fees. The defendants intend to defend the Karri Lawsuit vigorously.

- changed (2019-02-07):
[0001633978-19-000002:note_history:24]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of December 29, 2018, we did not have any material indemnification claims that were probable or reasonably possible.
  (was, 2018-11-01, similarity 0.9923):
[0001628280-18-013240:note_history:24]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of September 29, 2018, we did not have any material indemnification claims that were probable or reasonably possible.

- added (2019-02-07):
[0001633978-19-000002:note_history:25]
In connection with our acquisition of Oclaro, we recorded $0.7 million in Malaysia Goods and Services Tax (“GST”) refund claims within prepaid expenses and other current assets in our condensed consolidated balance sheet at December 29, 2018. The refund claim represents an initial claim of $2.5 million of Malaysia GST refund claims that were preliminarily denied by the Malaysian tax authorities in 2016. We are currently appealing the denial of these claims, and believe that additional options may be available to us if we do not obtain a favorable resolution. Although we have taken action to minimize the impact of the GST with respect to our ongoing operations, we believe it is reasonably possible that, ultimately, we may not be able to recover some of these GST amounts.

- removed (2019-02-07):
[0001628280-18-013240:note_history:26]
At the time of acquisition in February 2017, we incurred liabilities in the amount of $3.6 million. The amount of up to $3.0 million is expected to be paid within the following 12 months contingent upon meeting certain production targets, and is included in other current liabilities on our consolidated balance sheet as of September 29, 2018. We retained $1.0 million of the purchase price as security for any potential liabilities of the seller under the representations, warranties and indemnifications included in the purchase agreement. The amount of $1.0 million was fully paid to the seller during the three months ended September 29, 2018.

- removed (2019-02-07):
[0001628280-18-013240:note_history:27]
|  | Three Months Ended |
|  | September 29, 2018 |  | September 30, 2017 |
| Balance as of beginning of period | $ | 6.6 |  |  | $ | 9.7 |  |
| Provision for warranty | 1.2 |  |  | 1.0 |  |
| Utilization of reserve | (1.2 | ) |  | (1.3 | ) |
| Balance as of end of period | $ | 6.6 |  |  | $ | 9.4 |  |


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2019-02-07):
[0001633978-19-000002:note_history:28]
Lumentum (“we,” “us,” “our” or the “Company”) is an industry-leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including Optical Communications (“OpComms”) and Lasers for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be Original Equipment Manufacturers (“OEMs”) that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that Network Equipment Manufacturers’ (“NEMs”) customers assemble into communications networking systems, which they sell to network service providers or enterprises with their own networks. Similarly, many of our customers for our Lasers products incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For 3D sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, and gaming who then integrate our devices within their products, for eventual resale to consumers and also into other industrial applications.

- changed (2019-02-07):
[0001633978-19-000002:note_history:29]
The preparation of the condensed consolidated financial statements in accordance with U.S. generally accepted accounting principles (“GAAP”) requires management to make estimates and assumptions that affect the amounts reported in our condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are inventory valuation, revenue recognition, income taxes, long-lived asset valuation, warranty, derivative liability, business combinations and goodwill.
  (was, 2018-11-01, similarity 0.9995):
[0001628280-18-013240:note_history:29]
The preparation of the condensed consolidated financial statements in accordance with U.S. generally accepted accounting principles (“GAAP”) requires management to make estimates and assumptions that affect the amounts reported in our condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are inventory valuation, revenue recognition, income taxes, long-lived asset valuation, warranty, derivative liability, business combinations, and goodwill.

- added (2019-02-07):
[0001633978-19-000002:note_history:30]
On December 10, 2018, the Company completed its merger with Oclaro, Inc. (“Oclaro”), a provider of optical components and modules for the long-haul, metro and data center markets. Our condensed consolidated financial statements include the operating results of Oclaro for the period from the date of acquisition through December 29, 2018. Refer to “Note 5. Business Combination” for further discussion of the merger.

- changed (2019-02-07):
[0001633978-19-000002:note_history:31]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Our fiscal 2019 is a 52-week year ending on June 29, 2019, with the quarter ended December 29, 2018 being a 13-week quarterly period. Our fiscal 2018 was a 52-week year that ended on June 30, 2018, with the quarter ended December 30, 2017 being a 13-week quarterly period.
  (was, 2018-11-01, similarity 0.7123):
[0001628280-18-013240:note_history:31]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Our fiscal 2019 is a 52-week year ending on June 29, 2019. Our fiscal 2018 was a 52-week year and ended on June 30, 2018.

- added (2019-02-07):
[0001633978-19-000002:note_history:32]
Certain prior period amounts have been reclassified to conform to the current year presentation in the notes to the condensed consolidated financial statements. The reclassification of the prior period amounts did not impact previously reported condensed consolidated financial statements, except for the presentation of net income attributable to common stockholders and net income per share attributable to common stockholders for the three and six months ended December 30, 2017. The adjustments are a result of using the two-class method to compute earnings per share for the impact of our Series A Preferred Stock outstanding. Refer to “Note 3. Earnings Per Share” for further details.

- changed (2019-02-07):
[0001633978-19-000002:note_history:33]
The accompanying condensed consolidated financial statements and accompanying related notes should be read in conjunction with the audited consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended June 30, 2018.
  (was, 2018-11-01, similarity 0.9674):
[0001628280-18-013240:note_history:33]
The accompanying interim unaudited condensed consolidated financial statements and accompanying related notes should be read in conjunction with the audited consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended June 30, 2018.

- added (2019-02-07):
[0001633978-19-000002:note_history:34]
Except for the accounting policies for (i) revenue recognition and the adoption of Accounting Standards Update (“ASU”) 2014-09, Revenue from Contracts with Customers (Topic 606), and (ii) the change in our functional currency, from certain foreign currencies to the reporting currency, there have been no significant changes to our significant accounting policies as of and for the six months ended December 29, 2018, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the year ended June 30, 2018.

- changed (2019-02-07):
[0001633978-19-000002:note_history:35]
| • | recognition of revenues when, or as, the contractual performance obligations are satisfied. |
  (was, 2018-11-01, similarity 0.9949):
[0001628280-18-013240:note_history:35]
| • | recognition of revenues when, or as, the contractual performance obligations are satisfied |

- changed (2019-02-07):
[0001633978-19-000002:note_history:36]
The majority of our revenue comes from product sales, consisting of sales of Lasers and OpComms hardware products to our customers. Our revenue contracts generally include only one performance obligation. Revenues are recognized at a point in time when control of the promised goods or services are transferred to our customers upon shipment or delivery, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services. We have entered into vendor managed inventory (“VMI”) programs with our customers. Under these arrangements, we receive purchase orders from our customers, and the inventory is shipped to the VMI location upon receipt of the purchase order. The customer then pulls the inventory from the VMI hub based on its production needs. Revenue under VMI programs is recognized when control transfers to the customer, which is generally once the customer pulls the inventory from the hub.
  (was, 2018-11-01, similarity 0.9683):
[0001628280-18-013240:note_history:36]
The majority of our revenue comes from product sales, consisting of sales of Lasers and OpComms hardware products to our customers. Our revenue contracts generally include only one performance obligation. Revenues are recognized at a point in time when control of the promised goods or services is transferred to our customers upon shipment or delivery, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services. We have entered into vendor managed inventory (“VMI”) programs with our customers. Under these arrangements, we receive purchase orders from our customers, and the inventory is shipped to the VMI location upon receipt of the purchase order. The customer then pulls the inventory from the VMI hub based on its production needs. Revenue under VMI programs is recognized when control transfers to the customer, which is generally upon pull of inventory by the customer from the hub.

- changed (2019-02-07):
[0001633978-19-000002:note_history:37]
Revenue from all sales types is recognized at the transaction price. The transaction price is determined based on the consideration to which we will be entitled in exchange for transferring goods or services to the customer adjusted for estimated variable consideration, if any. We typically estimate the impact on the transaction price for discounts offered to the customers for early payments on receivables or net of accruals for estimated sales returns. These estimates are based on historical returns, analysis of credit memo data and other known factors. Actual returns could differ from these estimates. We allocate the transaction price to each distinct product based on its relative standalone selling price. The product price as specified on the purchase order is considered the standalone selling price as it is an observable input that depicts the price as if sold to a similar customer in similar circumstances.
  (was, 2018-11-01, similarity 0.9641):
[0001628280-18-013240:note_history:37]
Revenue from all sales types is recognized at transaction price. The transaction price is determined based on the consideration to which we will be entitled in exchange for transferring goods or services to the customer adjusted for estimated variable consideration, if any. We typically estimate the transaction price impact of discounts offered to the customers for early payments on receivables or net of accruals for estimated sales returns. These estimates are based on historical returns, analysis of credit memo data and other known factors. Actual returns could differ from these estimates. We allocate the transaction price to each distinct product based on its relative standalone selling price. The product price as specified on the purchase order is considered the standalone selling price as it is an observable input that depicts the price as if sold to a similar customer in similar circumstances.

- changed (2019-02-07):
[0001633978-19-000002:note_history:38]
If a customer pays consideration, or the Company has a right to an amount of consideration that is unconditional before we transfer a good or service to the customer, those amounts are classified as deferred revenue or deposits received from customers which are included in other current liabilities or other long-term liabilities when the payment is made or it is due, whichever is earlier.
  (was, 2018-11-01, similarity 0.9368):
[0001628280-18-013240:note_history:38]
If a customer pays consideration, or Lumentum has a right to an amount of consideration that is unconditional before we transfer a good or service to the customer, those amounts are classified as deferred income/advances received from customers which are included in other current liabilities or other long-term liabilities when the payment is made or it is due, whichever is earlier.

- changed (2019-02-07):
[0001633978-19-000002:note_history:39]
The following table includes estimated revenue expected to be recognized in the future for backlog related performance obligations that are unsatisfied as of December 29, 2018 (in millions):
  (was, 2018-11-01, similarity 0.8802):
[0001628280-18-013240:note_history:39]
The following table includes estimated revenue expected to be recognized in the future for backlog related performance obligations that are unsatisfied (or partially unsatisfied) as of September 29, 2018:

- changed (2019-02-07):
[0001633978-19-000002:note_history:40]
Hardware products regularly include warranties to the end customers such that the product continues to function according to published specifications. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, specific market, product line and geography in which we operate, and what is common in the industry, our warranties can vary and range from six months to five years. These standard warranties are assurance type warranties and do not offer any services in addition to the assurance that the product will continue working as specified. Therefore, warranties are not considered separate performance obligations in the arrangement. Instead, the expected cost of warranty is accrued as expense in accordance with authoritative guidance.
  (was, 2018-11-01, similarity 0.9819):
[0001628280-18-013240:note_history:40]
Hardware products regularly include warranties to the end customers such that the product continues to function according to published specifications. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, specific market, product line and geography we deal in, and what is common in the industry, our warranties can vary and range from six months to five years. These standard warranties are assurance type warranties and do not offer any services in addition to the assurance that the product will continue working as specified. Therefore, warranties are not considered separate performance obligations in the arrangement. Instead, the expected cost of warranty is accrued as expense in accordance with authoritative guidance.

- changed (2019-02-07):
[0001633978-19-000002:note_history:41]
The Company records accounts receivable when it has an unconditional right to consideration. Contract liabilities are recorded when cash payments are received or due in advance of performance. Contract liabilities consist of advance payments and deferred revenue, where the Company has unsatisfied performance obligations. Contract liabilities are classified as deferred revenue and customer deposits, and are included in other current liabilities within our condensed consolidated balance sheet. Payment terms vary by customer. The time between invoicing and when payment is due is not significant.
  (was, 2018-11-01, similarity 0.6779):
[0001628280-18-013240:note_history:41]
The Company records accounts receivable when it has an unconditional right to consideration. Contract liabilities are recorded when cash payments are received or due in advance of performance. Contract liabilities consist of advance payments and deferred revenue, where the Company has unsatisfied performance obligations. Contract liabilities are classified as deferred revenue and customer deposits and included in other current liabilities of our condensed consolidated balance sheet. Payment terms vary by customer. The time between invoicing and when payment is due is not significant.

- changed (2019-02-07):
[0001633978-19-000002:note_history:42]
The following table reflects the changes in contract balances for the six months ended December 29, 2018 (in millions, except percentages):
  (was, 2018-11-01, similarity 0.8017):
[0001628280-18-013240:note_history:42]
The following table reflects the changes in contract balances for the three months ended September 30, 2018:

- changed (2019-02-07):
[0001633978-19-000002:note_history:43]
| Contract balances | Balance sheet location | December 29, 2018 |  | June 30, 2018 |  | Change |  | Percentage Change |
| Accounts receivable, net | Accounts receivable, net | $266.5 |  | $197.1 |  | $69.4 |  | 35.2% |
| Deferred revenue and customer deposits | Other current liabilities | $3.9 |  | $2.8 |  | $1.1 |  | 39.3% |
  (was, 2018-11-01, similarity 0.9567):
[0001628280-18-013240:note_history:43]
| Contract balances | Balance sheet location | September 29, 2018 |  | June 30, 2018 |  | Change |  | Percentage Change |
| Accounts receivable, net | Accounts receivable, net | $239.6 |  | $197.1 |  | $42.5 |  | 21.6% |
| Deferred revenue and customer deposits | Other current liabilities | $2.6 |  | $2.8 |  | $(0.2) |  | (7.1)% |

- added (2019-02-07):
[0001633978-19-000002:note_history:44]
We disaggregate revenue by geography and by product. Refer to “Note 19. Operating Segments and Geographic Information” for a presentation of disaggregated revenue. We do not present other levels of disaggregation, such as by type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, as this information is not used by our Chief Operating Decision Maker to manage the business.

- added (2019-02-07):
[0001633978-19-000002:note_history:45]
Foreign Currency Translation

- added (2019-02-07):
[0001633978-19-000002:note_history:46]
Concurrent with the acquisition of Oclaro, on December 10, 2018, we established the functional currency for our worldwide operations as the U.S. dollar. The change in our functional currency is a result of significant changes in economic facts and circumstances, primarily the acquisition of Oclaro, a U.S. dollar-denominated functional currency company. The combined business, which requires the integration of our supply chain, manufacturing operations and sales organization, will predominantly use the U.S. dollar, including when negotiating customer and supplier contracts.

- added (2019-02-07):
[0001633978-19-000002:note_history:47]
Translation adjustments reported prior to December 10, 2018, remain as a component of accumulated other comprehensive income in our condensed consolidated balance sheet. The translated values for any non-monetary assets and liabilities as of December 10, 2018 become the new accounting basis for those assets. Accordingly, monetary assets and liabilities denominated in foreign currencies have been remeasured into U.S. dollars using the exchange rates in effect at the balance sheet date. Foreign currency re-measurement gains (losses) are included in interest and other income (expense), net from December 10, 2018.

- removed (2019-02-07):
[0001628280-18-013240:note_history:48]
Lumentum (we, us, our or the Company) is an industry-leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including OpComms and Lasers for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be OEMs that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that Network Equipment Manufacturers (“NEMs”) customers assemble into communications networking systems, which they sell to network service providers or enterprises with their own networks. Similarly, many of our customers for our Lasers products incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For 3D sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, and gaming who then integrate our devices within their products, for eventual resale to consumers and also into other industrial applications.

- removed (2019-02-07):
[0001628280-18-013240:note_history:49]
On March 11, 2018, we entered into an Agreement and Plan of Merger (the “Merger Agreement”) with Oclaro, Prota Merger Sub, Inc., and Prota Merger, LLC, pursuant to which we will acquire Oclaro and Oclaro will become a wholly-owned subsidiary of Lumentum. In accordance with the terms of the Merger Agreement, each issued and outstanding share of Oclaro common stock will be exchanged for $5.60 in cash and 0.0636 of a share of Lumentum common stock, subject to the conditions and restrictions set forth in the Merger Agreement. The total transaction consideration was approximately $1.8 billion as of the date of the Merger Agreement. Oclaro stockholders are expected to own approximately 16% of the combined company following the closing. Oclaro’s stockholders approved the Merger Agreement on July 10, 2018 and we have received approval for the transaction under the Hart-Scott Rodino Act in the United States. We are in the process of obtaining antitrust approval in China. The Merger Agreement contains certain termination rights for both Lumentum and Oclaro. The Merger Agreement further provides that upon termination of the Merger Agreement under specified circumstances relating to failure to obtain regulatory approvals by March 11, 2019, Lumentum may be required to pay Oclaro a termination fee of $80 million.

- removed (2019-02-07):
[0001628280-18-013240:note_history:50]
In connection with the Merger Agreement, Lumentum entered into a commitment letter, dated as of March 11, 2018, with Deutsche Bank Securities Inc. and Deutsche Bank AG New York Branch (“Deutsche Bank”), pursuant to which, subject to the terms and conditions set forth therein, Deutsche Bank has committed to provide a senior secured term loan facility in an aggregate principal amount of up to $550 million.

- removed (2019-02-07):
[0001628280-18-013240:note_history:51]
As of October 26, 2018, the total transaction consideration was expected to be approximately $1.6 billion, which would be funded by a combination of $600 million in Lumentum common stock, $500 million in new debt, and the remaining amount from the cash balances of the combined company.

- removed (2019-02-07):
[0001628280-18-013240:note_history:52]
Our commitment letter and related documentation with Deutsche Bank requires payment of a ticking fee to Deutsche Bank. The ticking fee accrues at a rate of (a) commencing on the 31st day following the date on which the term loans were allocated to members of the lending syndicate (the “Allocation Date”), 1.25% per annum, and (b) commencing on the 61st day following the Allocation Date, 2.5% per annum, in each case, based on an aggregate principal amount of term loan commitments provided by Deutsche Bank under the commitment letter.  The Allocation Date occurred on August 8, 2018 and, as of September 29, 2018, we had not borrowed any funds under the senior secured term loan facility. Accordingly, we began to incur ticking fees on the $500 million of term loan commitments on September 8, 2018. We expensed $0.4 million related to the ticking fee, which is included in interest expense in our condensed consolidated statements of operations for the three months ended September 29, 2018.

- removed (2019-02-07):
[0001628280-18-013240:note_history:53]
During the three months ended September 29, 2018, we also incurred $0.9 million of debt issuance costs in connection with the above facility which were capitalized and recorded in other non-current assets on our condensed consolidated balance sheet. These costs will be recorded as contra liability when the debt is drawn and will be amortized to interest expense using the effective interest rate method from the issuance date through the end of the term of the loan.

- removed (2019-02-07):
[0001628280-18-013240:note_history:54]
The transaction is subject to customary closing conditions, including antitrust regulatory approval in China. The transaction is not subject to any financing condition. Although we anticipate that the transaction will be be completed by December 11, 2018, the termination date of the merger agreement will be automatically extended to March 11, 2019, subject to certain conditions set forth in the Merger Agreement.

- removed (2019-02-07):
[0001628280-18-013240:note_history:55]
Certain prior period amounts have been reclassified to conform to the current year presentation on the notes to condensed consolidated financial statements. The reclassification of the prior period amounts did not impact previously reported condensed consolidated financial statements.

- removed (2019-02-07):
[0001628280-18-013240:note_history:56]
Except for the accounting policies for revenue recognition and adoption of Accounting Standard Update (“ASU”) 2014-09, Revenue from Contracts with Customers (Topic 606), there have been no significant changes to our significant accounting policies as of and for the three months ended September 29, 2018, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the year ended June 30, 2018.

- removed (2019-02-07):
[0001628280-18-013240:note_history:57]
During the three months ended September 29, 2018, deferred revenue and customer deposits decreased primarily due to revenue recognized for the satisfaction of performance obligation over time in the amount of $0.4 million.

- removed (2019-02-07):
[0001628280-18-013240:note_history:58]
We disaggregate revenue by geography and by product, no other level of disaggregation is required considering the type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, based on the information that our chief operating decision maker uses to manage the business.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-02-07):
[0001633978-19-000002:note_history:59]
| Liability component: | December 29, 2018 |  | June 30, 2018 |
| Principal | $ | 450.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount | (107.1 | ) |  | (115.8 | ) |
| Net carrying amount of the liability component | $ | 342.9 |  |  | $ | 334.2 |  |
  (was, 2018-11-01, similarity 0.6194):
[0001628280-18-013240:note_history:59]
| Liability component: | September 29, 2018 |  | June 30, 2018 |
| Principal | $ | 450.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount | (111.5 | ) |  | (115.8 | ) |
| Net carrying amount of the liability component | $ | 338.5 |  |  | $ | 334.2 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-02-07):
[0001633978-19-000002:note_history:60]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. We incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. We amortize the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes is 5.4% per year. As of December 29, 2018, the remaining debt discount amortization period was 62 months.
  (was, 2018-11-01, similarity 0.9969):
[0001628280-18-013240:note_history:60]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. We incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. We amortize the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes is 5.4% per year. As of September 29, 2018, the remaining debt discount amortization period was 65 months.

- changed (2019-02-07):
[0001633978-19-000002:note_history:61]
| Liability component: | December 29, 2018 |  | June 30, 2018 |
| Principal | $ | 450.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount | (107.1 | ) |  | (115.8 | ) |
| Net carrying amount of the liability component | $ | 342.9 |  |  | $ | 334.2 |  |
  (was, 2018-11-01, similarity 0.6194):
[0001628280-18-013240:note_history:61]
| Liability component: | September 29, 2018 |  | June 30, 2018 |
| Principal | $ | 450.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount | (111.5 | ) |  | (115.8 | ) |
| Net carrying amount of the liability component | $ | 338.5 |  |  | $ | 334.2 |  |

- added (2019-02-07):
[0001633978-19-000002:note_history:62]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |  | December 29, 2018 |  | December 30, 2017 |
| Contractual interest expense | $ | 0.3 |  |  | $ | 0.3 |  |  | $ | 0.6 |  |  | $ | 0.6 |  |
| Amortization of the debt discount | 4.4 |  |  | 4.1 |  |  | 8.7 |  |  | 8.2 |  |
| Total interest expense | $ | 4.7 |  |  | $ | 4.4 |  |  | $ | 9.3 |  |  | $ | 8.8 |  |
| Effective interest rate on the liability component | 5.4 | % |  | 5.4 | % |  | 5.4 | % |  | 5.4 | % |

- removed (2019-02-07):
[0001628280-18-013240:note_history:63]
|  | Three Months Ended |
| (in millions, except percentages) | September 29, 2018 |  | September 30, 2017 |
| Contractual interest expense | $ | 0.3 |  |  | $ | 0.3 |  |
| Amortization of the debt discount | 4.3 |  |  | 4.1 |  |
| Total interest expense | $ | 4.6 |  |  | $ | 4.4 |  |
| Effective interest rate on the liability component | 5.4 | % |  | 5.4 | % |


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-02-07):
[0001633978-19-000002:note_history:64]
|  | Less than 12 months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| December 29, 2018: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper | $ | 12.8 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 12.8 |  |  | $ | — |  |
| Asset-backed securities | 32.1 |  |  | (0.1 | ) |  | 12.3 |  |  | — |  |  | 44.4 |  |  | (0.1 | ) |
| Corporate debt securities | 101.1 |  |  | (0.4 | ) |  | 88.1 |  |  | (0.7 | ) |  | 189.2 |  |  | (1.1 | ) |
| Mortgage-backed securities | 0.1 |  |  | — |  |  | — |  |  | — |  |  | 0.1 |  |  | — |  |
| Foreign government bonds | 2.9 |  |  | — |  |  | 2.1 |  |  | — |  |  | 5.0 |  |  | — |  |
| Total | $ | 149.0 |  |  | $ | (0.5 | ) |  | $ | 102.5 |  |  | $ | (0.7 | ) |  | $ | 251.5 |  |  | $ | (1.2 | ) |
| June 30, 2018: |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |  | $ | — |  |
| Commercial paper | 8.5 |  |  | — |  |  | — |  |  | — |  |  | 8.5 |  |  | — |  |
| Asset-backed securities | 66.6 |  |  | (0.2 | ) |  | 0.3 |  |  | — |  |  | 66.9 |  |  | (0.2 | ) |
| Corporate debt securities | 188.6 |  |  | (1.5 | ) |  | 2.0 |  |  | — |  |  | 190.6 |  |  | (1.5 | ) |
| Municipal bonds | 0.6 |  |  | — |  |  | — |  |  | — |  |  | 0.6 |  |  | — |  |
| U.S. Agency securities | 4.0 |  |  | — |  |  | — |  |  | — |  |  | 4.0 |  |  | — |  |
| Foreign government bonds | 3.4 |  |  | — |  |  | — |  |  | — |  |  | 3.4 |  |  | — |  |
| Total | $ | 277.1 |  |  | $ | (1.7 | ) |  | $ | 2.3 |  |  | $ | — |  |  | $ | 279.4 |  |  | $ | (1.7 | ) |
  (was, 2018-11-01, similarity 0.9967):
[0001628280-18-013240:note_history:64]
|  | Less than 12 months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| September 29, 2018: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper | $ | 6.1 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 6.1 |  |  | $ | — |  |
| Asset-backed securities | 48.4 |  |  | (0.2 | ) |  | 8.5 |  |  | — |  |  | 56.9 |  |  | (0.2 | ) |
| Corporate debt securities | 113.3 |  |  | (0.8 | ) |  | 46.9 |  |  | (0.3 | ) |  | 160.2 |  |  | (1.1 | ) |
| Mortgage-backed securities | 2.8 |  |  | — |  |  | — |  |  | — |  |  | 2.8 |  |  | — |  |
| Foreign government bonds | 4.1 |  |  | — |  |  | — |  |  | — |  |  | 4.1 |  |  | — |  |
| Total | $ | 174.7 |  |  | $ | (1.0 | ) |  | $ | 55.4 |  |  | $ | (0.3 | ) |  | $ | 230.1 |  |  | $ | (1.3 | ) |
| June 30, 2018: |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |  | $ | — |  |
| Commercial paper | 8.5 |  |  | — |  |  | — |  |  | — |  |  | 8.5 |  |  | — |  |
| Asset-backed securities | 66.6 |  |  | (0.2 | ) |  | 0.3 |  |  | — |  |  | 66.9 |  |  | (0.2 | ) |
| Corporate debt securities | 188.6 |  |  | (1.5 | ) |  | 2.0 |  |  | — |  |  | 190.6 |  |  | (1.5 | ) |
| Municipal bonds | 0.6 |  |  | — |  |  | — |  |  | — |  |  | 0.6 |  |  | — |  |
| U.S. Agency securities | 4.0 |  |  | — |  |  | — |  |  | — |  |  | 4.0 |  |  | — |  |
| Foreign government bonds | 3.4 |  |  | — |  |  | — |  |  | — |  |  | 3.4 |  |  | — |  |
| Total | $ | 277.1 |  |  | $ | (1.7 | ) |  | $ | 2.3 |  |  | $ | — |  |  | $ | 279.4 |  |  | $ | (1.7 | ) |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2019-02-07):
[0001633978-19-000002:note_history:65]
Note 6. Term Loan Facility

- added (2019-02-07):
[0001633978-19-000002:note_history:66]
On March 11, 2018, in connection with the Oclaro merger, Lumentum entered into a commitment letter with Deutsche Bank Securities Inc. and Deutsche Bank AG New York Branch (“Deutsche Bank”), pursuant to which, Deutsche Bank committed to provide a senior secured term loan facility to finance the merger.

- added (2019-02-07):
[0001633978-19-000002:note_history:67]
On December 10, 2018 (the “Closing Date”), concurrent with the closing of the Oclaro merger, Lumentum entered into a Credit and Guarantee Agreement (the “Credit Agreement”), by and among Lumentum, certain subsidiaries of Lumentum, the lenders party thereto, and Deutsche Bank, as administrative agent and collateral agent for the lenders. The Credit Agreement provides for a senior secured term loan facility (the “Term Loan Facility”) in an aggregate principal amount of $500.0 million. The term loans available under the Term Loan Facility were fully drawn on the Closing Date and the proceeds of the term loans were used to consummate the merger and pay fees and expenses in connection with the merger and the Term Loan Facility.

- added (2019-02-07):
[0001633978-19-000002:note_history:68]
The term loans will mature on the seventh anniversary of the Closing Date, at which time all outstanding principal and accrued and unpaid interest on the term loans must be repaid.  Commencing on the last business day of the first full fiscal quarter after the Closing Date, the term loans will amortize in equal quarterly installments equal to 0.25% of the original principal amount of the Term Loans, with the balance payable due on December 10, 2025, the maturity date. We are required to make mandatory prepayments of the outstanding principal amount of term loans with the net cash proceeds from the disposition of certain assets and the receipt of insurance proceeds upon certain casualty and condemnation events, in each case, to the extent in excess of the certain threshold amounts and to the extent not reinvested within a specified time period. We are also required to make mandatory prepayments of the outstanding principal amount of term loans from the incurrence of certain types of indebtedness and from any excess cash flow beyond stated threshold amounts. We have the right to prepay the term loans, in whole or in part, at any time without premium or penalty, subject to certain limitations and a 1.00% soft call premium applicable during the first six months following the Closing Date.

- added (2019-02-07):
[0001633978-19-000002:note_history:69]
The term loans bear interest at a rate equal to an applicable margin plus, at our option, either (a) a base rate equal to the highest of (i) the prime rate then in effect, (ii) the federal funds rate, plus 0.50% and (iii) an adjusted LIBOR rate determined on the basis of a one-month interest period, plus 1.0%, subject to a floor of 0.0%, or (b) an adjusted LIBOR rate, subject to a floor of 0.0%. The applicable margin with respect to the initial term loans is equal to 2.50% in the case of LIBOR rate loans and 1.50% in the case of base rate loans. The applicable margin is adjusted following the first full fiscal quarter after the Closing Date, if our first lien net leverage ratio is equal to or less than 0.50:1.00, to 2.25% in the case of LIBOR rate loans and 1.25% in the case of base rate loans. During the three and six months ended December 29, 2018, we recorded interest expense of $1.4 million related to the initial term loans, which is included in interest and other income (expense), net in our condensed consolidated statements of operations.

- added (2019-02-07):
[0001633978-19-000002:note_history:70]
The commitment letter with Deutsche Bank required payment of a ticking fee. During the three and six months ended December 29, 2018, we recorded total expenses in connection with the ticking fee of $2.3 million and $2.7 million, respectively. This ticking fee expense is included in interest and other income (expense), net in our condensed consolidated statements of operations.

- added (2019-02-07):
[0001633978-19-000002:note_history:71]
The Credit Agreement permits us to add one or more incremental term loan facilities. Incremental loans are subject to certain additional conditions, including, without limitation, obtaining additional commitments from the lenders then party to the Credit Agreement or from new lenders.

- added (2019-02-07):
[0001633978-19-000002:note_history:72]
Our obligations under the Credit Agreement are required to be guaranteed by certain of our domestic subsidiaries meeting materiality thresholds set forth in the Credit Agreement. Such obligations, including the guaranties, are secured by substantially all of the assets of Lumentum and Lumentum’s subsidiary guarantors (other than customarily excluded assets) pursuant to a Pledge and Security Agreement, dated as of December 10, 2018, by and among Lumentum and Deutsche Bank.

- added (2019-02-07):
[0001633978-19-000002:note_history:73]
The Credit Agreement contains customary affirmative and negative covenants, including covenants limiting the ability of Lumentum and its restricted subsidiaries to, among other things, incur debt, grant liens, undergo certain fundamental changes, make investments, make certain restricted payments, dispose of assets, and enter into transactions with affiliates, in each case, subject to limitations and exceptions set forth in the Credit Agreement. The Credit Agreement also contains customary events of default that include, among other things, certain payment defaults, cross defaults to other indebtedness, covenant defaults, change of control defaults, judgment defaults, and bankruptcy and insolvency defaults. If an event of default exists, the lenders may require the immediate payment of all obligations under the Credit Agreement, and may exercise certain other rights and remedies provided for under the Credit Agreement, the other loan documents and applicable law. As of December 29, 2018, we were in compliance with all of the covenants.

- added (2019-02-07):
[0001633978-19-000002:note_history:74]
We incurred $9.3 million of debt issuance costs in connection with the Term Loan Facility which were capitalized and recorded as a contra liability in our condensed consolidated balance sheet. These costs will be amortized to interest expense using the effective interest rate method from the issuance date of December 10, 2018, through the end of the term of the loan. As of December 29, 2018, the effective interest rate is 5.16% and the stated interest rate is 4.89%.

- added (2019-02-07):
[0001633978-19-000002:note_history:75]
The following table sets forth balance sheet information related to the term loan at December 29, 2018 (in millions):

- added (2019-02-07):
[0001633978-19-000002:note_history:76]
|  | December 29, 2018 |
| Principal | $ | 500.0 |  |
| Unamortized value of the debt issuance costs | (9.2 | ) |
| Net carrying value | $ | 490.8 |  |
| Term loan, current | $ | 5.0 |  |
| Term loan, non-current | $ | 485.8 |  |

- added (2019-02-07):
[0001633978-19-000002:note_history:77]
The following table sets forth interest expense information related to the term loan, including interest expense associated with the ticking fee, for the periods presented (in millions):

- added (2019-02-07):
[0001633978-19-000002:note_history:78]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |  | December 29, 2018 |  | December 30, 2017 |
| Contractual interest expense | $ | 3.7 |  |  | $ | — |  |  | $ | 4.1 |  |  | $ | — |  |
| Amortization of the debt issuance costs | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |
| Total interest expense | $ | 3.8 |  |  | $ | — |  |  | $ | 4.2 |  |  | $ | — |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2019-02-07):
[0001633978-19-000002:note_history:79]
The following table sets forth balance sheet information related to the term loan at December 29, 2018 (in millions):

- added (2019-02-07):
[0001633978-19-000002:note_history:80]
|  | December 29, 2018 |
| Principal | $ | 500.0 |  |
| Unamortized value of the debt issuance costs | (9.2 | ) |
| Net carrying value | $ | 490.8 |  |
| Term loan, current | $ | 5.0 |  |
| Term loan, non-current | $ | 485.8 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-02-07):
[0001633978-19-000002:note_history:81]
The estimated future interest and principal payments related to the term loan are as follows as of December 29, 2018:
  (was, 2018-11-01, similarity 0.8732):
[0001628280-18-013240:note_history:81]
The future interest and principal payments related to the 2024 Notes are as follows as of September 29, 2018:

- added (2019-02-07):
[0001633978-19-000002:note_history:82]
| Fiscal Years |  |
| Remainder of 2019 | $ | 16.1 |  |
| 2020 | 29.2 |  |
| 2021 | 29.0 |  |
| 2022 | 28.7 |  |
| 2023 | 28.5 |  |
| Thereafter | 533.9 |  |
| Total term loan payments | $ | 665.4 |  |

- added (2019-02-07):
[0001633978-19-000002:note_history:83]
The future interest and principal payments related to the 2024 Notes are as follows as of December 29, 2018:


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-02-07):
[0001633978-19-000002:note_history:84]
The Company records accounts receivable when it has an unconditional right to consideration. Contract liabilities are recorded when cash payments are received or due in advance of performance. Contract liabilities consist of advance payments and deferred revenue, where the Company has unsatisfied performance obligations. Contract liabilities are classified as deferred revenue and customer deposits, and are included in other current liabilities within our condensed consolidated balance sheet. Payment terms vary by customer. The time between invoicing and when payment is due is not significant.
  (was, 2018-11-01, similarity 0.6779):
[0001628280-18-013240:note_history:84]
The Company records accounts receivable when it has an unconditional right to consideration. Contract liabilities are recorded when cash payments are received or due in advance of performance. Contract liabilities consist of advance payments and deferred revenue, where the Company has unsatisfied performance obligations. Contract liabilities are classified as deferred revenue and customer deposits and included in other current liabilities of our condensed consolidated balance sheet. Payment terms vary by customer. The time between invoicing and when payment is due is not significant.

- changed (2019-02-07):
[0001633978-19-000002:note_history:85]
| • | recognition of revenues when, or as, the contractual performance obligations are satisfied. |
  (was, 2018-11-01, similarity 0.9949):
[0001628280-18-013240:note_history:85]
| • | recognition of revenues when, or as, the contractual performance obligations are satisfied |

- changed (2019-02-07):
[0001633978-19-000002:note_history:86]
The majority of our revenue comes from product sales, consisting of sales of Lasers and OpComms hardware products to our customers. Our revenue contracts generally include only one performance obligation. Revenues are recognized at a point in time when control of the promised goods or services are transferred to our customers upon shipment or delivery, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services. We have entered into vendor managed inventory (“VMI”) programs with our customers. Under these arrangements, we receive purchase orders from our customers, and the inventory is shipped to the VMI location upon receipt of the purchase order. The customer then pulls the inventory from the VMI hub based on its production needs. Revenue under VMI programs is recognized when control transfers to the customer, which is generally once the customer pulls the inventory from the hub.
  (was, 2018-11-01, similarity 0.9683):
[0001628280-18-013240:note_history:86]
The majority of our revenue comes from product sales, consisting of sales of Lasers and OpComms hardware products to our customers. Our revenue contracts generally include only one performance obligation. Revenues are recognized at a point in time when control of the promised goods or services is transferred to our customers upon shipment or delivery, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services. We have entered into vendor managed inventory (“VMI”) programs with our customers. Under these arrangements, we receive purchase orders from our customers, and the inventory is shipped to the VMI location upon receipt of the purchase order. The customer then pulls the inventory from the VMI hub based on its production needs. Revenue under VMI programs is recognized when control transfers to the customer, which is generally upon pull of inventory by the customer from the hub.

- changed (2019-02-07):
[0001633978-19-000002:note_history:87]
Revenue from all sales types is recognized at the transaction price. The transaction price is determined based on the consideration to which we will be entitled in exchange for transferring goods or services to the customer adjusted for estimated variable consideration, if any. We typically estimate the impact on the transaction price for discounts offered to the customers for early payments on receivables or net of accruals for estimated sales returns. These estimates are based on historical returns, analysis of credit memo data and other known factors. Actual returns could differ from these estimates. We allocate the transaction price to each distinct product based on its relative standalone selling price. The product price as specified on the purchase order is considered the standalone selling price as it is an observable input that depicts the price as if sold to a similar customer in similar circumstances.
  (was, 2018-11-01, similarity 0.9641):
[0001628280-18-013240:note_history:87]
Revenue from all sales types is recognized at transaction price. The transaction price is determined based on the consideration to which we will be entitled in exchange for transferring goods or services to the customer adjusted for estimated variable consideration, if any. We typically estimate the transaction price impact of discounts offered to the customers for early payments on receivables or net of accruals for estimated sales returns. These estimates are based on historical returns, analysis of credit memo data and other known factors. Actual returns could differ from these estimates. We allocate the transaction price to each distinct product based on its relative standalone selling price. The product price as specified on the purchase order is considered the standalone selling price as it is an observable input that depicts the price as if sold to a similar customer in similar circumstances.

- changed (2019-02-07):
[0001633978-19-000002:note_history:88]
If a customer pays consideration, or the Company has a right to an amount of consideration that is unconditional before we transfer a good or service to the customer, those amounts are classified as deferred revenue or deposits received from customers which are included in other current liabilities or other long-term liabilities when the payment is made or it is due, whichever is earlier.
  (was, 2018-11-01, similarity 0.9368):
[0001628280-18-013240:note_history:88]
If a customer pays consideration, or Lumentum has a right to an amount of consideration that is unconditional before we transfer a good or service to the customer, those amounts are classified as deferred income/advances received from customers which are included in other current liabilities or other long-term liabilities when the payment is made or it is due, whichever is earlier.

- added (2019-02-07):
[0001633978-19-000002:note_history:89]
| Contract balances | Balance sheet location | December 29, 2018 |  | June 30, 2018 |  | Change |  | Percentage Change |
| Accounts receivable, net | Accounts receivable, net | $266.5 |  | $197.1 |  | $69.4 |  | 35.2% |
| Deferred revenue and customer deposits | Other current liabilities | $3.9 |  | $2.8 |  | $1.1 |  | 39.3% |

- added (2019-02-07):
[0001633978-19-000002:note_history:90]
We disaggregate revenue by geography and by product. Refer to “Note 19. Operating Segments and Geographic Information” for a presentation of disaggregated revenue. We do not present other levels of disaggregation, such as by type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, as this information is not used by our Chief Operating Decision Maker to manage the business.

- removed (2019-02-07):
[0001628280-18-013240:note_history:91]
We disaggregate revenue by geography and by product, no other level of disaggregation is required considering the type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, based on the information that our chief operating decision maker uses to manage the business.
