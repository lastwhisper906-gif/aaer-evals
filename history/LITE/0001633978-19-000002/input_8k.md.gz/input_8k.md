# LITE 8-K — 0001633978-19-000001 filed 2019-02-05

## item codes, every 8-K on or before 2019-02-07

- 2019-02-05 0001633978-19-000001 — 2.02, 9.01
- 2018-12-10 0001193125-18-346211 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-12-06 0001633978-18-000150 — 8.01
- 2018-11-14 0001633978-18-000139 — 5.07
- 2018-11-13 0001633978-18-000136 — 3.02
- 2018-11-13 0001633978-18-000132 — 7.01, 9.01
- 2018-11-01 0001628280-18-013238 — 2.02, 9.01
- 2018-08-08 0001633978-18-000056 — 2.02, 9.01
- 2018-06-08 0001193125-18-188241 — 5.02, 9.01
- 2018-05-02 0001633978-18-000029 — 2.02, 9.01
- 2018-03-12 0001193125-18-078154 — 1.01, 2.01, 8.01, 9.01
- 2018-02-06 0001628280-18-001082 — 2.02, 9.01
- 2017-11-08 0001633978-17-000133 — 5.02, 9.01
- 2017-11-07 0001633978-17-000131 — 5.07
- 2017-11-01 0001633978-17-000117 — 2.02, 9.01
- 2017-08-09 0001633978-17-000058 — 2.02, 9.01
- 2017-05-04 0001633978-17-000035 — 2.02, 9.01
- 2017-03-08 0001193125-17-074740 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2017-03-02 0001193125-17-066769 — 8.01, 9.01
- 2017-02-07 0001633978-17-000005 — 2.02, 9.01
- 2017-01-03 0001628280-17-000018 — 4.01, 9.01
- 2016-11-09 0001628280-16-021143 — 5.02, 5.07, 9.01
- 2016-10-27 0001628280-16-020382 — 2.02, 9.01
- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2019-02-07

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001633978-19-000001:8k_2_02:1]
EX-99.1
2
lite_ex991xq2fy19.htm
EXHIBIT 99.1

[0001633978-19-000001:8k_2_02:2]
Exhibit

[0001633978-19-000001:8k_2_02:3]
NEWS RELEASE

[0001633978-19-000001:8k_2_02:4]
LUMENTUM ANNOUNCES FISCAL SECOND QUARTER 2019 RESULTS

[0001633978-19-000001:8k_2_02:5]
| • | Net revenue of $373.7 million |

[0001633978-19-000001:8k_2_02:6]
| • | GAAP operating margin of 3.1%; Non-GAAP operating margin of 22.0% |

[0001633978-19-000001:8k_2_02:7]
| • | GAAP diluted net income per share of $0.08; Non-GAAP diluted net income per share of $1.15 |

[0001633978-19-000001:8k_2_02:8]
| • | Results include Oclaro since the closing of the acquisition on December 10 |

[0001633978-19-000001:8k_2_02:9]
Milpitas, Calif., February 5, 2019 – Lumentum Holdings Inc. (“Lumentum” or the “Company”) today reported results for its fiscal second quarter ended December 29, 2018.

[0001633978-19-000001:8k_2_02:10]
Net revenue for the fiscal second quarter of 2019 was $373.7 million, with GAAP net income attributable to common stockholders of $5.4 million, or $0.08 per diluted share. Net revenue for the fiscal first quarter of 2019 was $354.1 million, with GAAP net income attributable to common stockholders of $46.1 million, or $0.72 per diluted share. Net revenue for the fiscal second quarter of 2018 was $404.6 million, with GAAP net income attributable to common stockholders of $196.9 million, or $3.05 per diluted share.

[0001633978-19-000001:8k_2_02:11]
Non-GAAP net income for the fiscal second quarter of 2019 was $78.3 million, or $1.15 per diluted share. Non-GAAP net income for the fiscal first quarter of 2019 was $85.8 million, or $1.31 per diluted share. Non-GAAP net income for the fiscal second quarter of 2018 was $107.8 million, or $1.67 per diluted share.

[0001633978-19-000001:8k_2_02:12]
The Company held $684.1 million in total cash and short-term investments at the end of the fiscal second quarter of 2019.

[0001633978-19-000001:8k_2_02:13]
“Our investments in new and differentiated products continue to drive growth in our telecom and lasers product lines. ROADM and fiber laser revenues more than doubled over the prior year and once again achieved new record levels in the second quarter,” said Alan Lowe President and CEO. “Strength in Telecom demand is expected to continue in the third quarter, counter to historical seasonality. Second quarter 3D sensing revenue came in as expected, and we continue to make progress with new design wins with new and existing customers. The closing of the Oclaro acquisition in December gives us a first mover advantage in a consolidating industry and establishes leadership positions based on fundamental photonic chip capabilities across a broad range of products and technologies to address the growing communications, industrial, and consumer markets.”

[0001633978-19-000001:8k_2_02:14]
Financial Overview – Fiscal Second Quarter Ended December 29, 2018

[0001633978-19-000001:8k_2_02:15]
|  | GAAP Results ($ in millions) |
|  | Q2 |  | Q1 |  | Q2 |  | Change |
|  | FY 2019 |  | FY 2019 |  | FY 2018 |  | Q/Q |  | Y/Y |
| Net revenue | $373.7 |  | $354.1 |  | $404.6 |  | 5.5% |  | (7.6)% |
| Gross margin | 33.4% |  | 35.6% |  | 42.3% |  | (220)bps |  | (890)bps |
| Operating margin | 3.1% |  | 16.1% |  | 22.4% |  | (1300)bps |  | (1930)bps |
|  | Non-GAAP Results ($ in millions) |
|  | Q2 |  | Q1 |  | Q2 |  | Change |
|  | FY 2019 |  | FY 2019 |  | FY 2018 |  | Q/Q |  | Y/Y |
| Net revenue | $373.7 |  | $354.1 |  | $404.6 |  | 5.5% |  | (7.6)% |
| Gross margin | 40.1% |  | 40.3% |  | 44.9% |  | (20)bps |  | (480)bps |
| Operating margin | 22.0% |  | 23.9% |  | 28.3% |  | (190)bps |  | (630)bps |

[0001633978-19-000001:8k_2_02:16]
|  | Net Revenue by Segment ($ in millions) |
|  | Q2 |  | % of |  | Q1 |  | Q2 |  | Change |
|  | FY 2019 |  | Net Revenue |  | FY 2019 |  | FY 2018 |  | Q/Q |  | Y/Y |
| Optical Communications | $325.4 |  | 87.1% |  | $310.1 |  | $360.1 |  | 4.9% |  | (9.6)% |
| Lasers | 48.3 |  | 12.9% |  | 44.0 |  | 44.5 |  | 9.8% |  | 8.5% |
| Total | $373.7 |  | 100.0% |  | $354.1 |  | $404.6 |  | 5.5% |  | (7.6)% |

[0001633978-19-000001:8k_2_02:17]
The tables above provide comparisons of quarterly results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled “Use of Non-GAAP Financial Measures.”

[0001633978-19-000001:8k_2_02:18]
On July 1, 2018, we adopted Accounting Standards Update (ASU) 2014-09, Revenue from Contracts with Customers (Topic 606) using the modified retrospective method applied to all contracts that are not completed contracts at the date of initial adoption(i.e., July 1, 2018). Results for reporting periods after July 1, 2018 are presented under Topic 606, while prior period amounts are not adjusted and continue to be reported in accordance with our historic accounting under Topic 605. The adoption of Topic 606 did not have a material impact on the nature and timing of our revenues, consolidated statements of operations, cash flows, and balance sheet and therefore, we do not present results for the three and six months ended December 29, 2018 under Topic 605.

[0001633978-19-000001:8k_2_02:19]
Business Outlook

[0001633978-19-000001:8k_2_02:20]
The Company expects the following for the fiscal third quarter 2019:

[0001633978-19-000001:8k_2_02:21]
•Net revenue to be in the range of $420 million to $440 million

[0001633978-19-000001:8k_2_02:22]
•Non-GAAP operating margin of 16.0% to 18.0%

[0001633978-19-000001:8k_2_02:23]
•Non-GAAP diluted earnings per share of $0.76 to $0.94

[0001633978-19-000001:8k_2_02:24]
We have not provided reconciliations from GAAP to non-GAAP measures for our outlook. A large portion of non-GAAP adjustments, such as derivative liability adjustments, restructuring charges, stock-based compensation, litigation, acquisition-related costs, non-cash income tax expense and credits, transferring product lines to Thailand, amortization of fair value adjustments and other costs and contingencies unrelated to current and future operations are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future. For example, in the fiscal second quarter of 2018, we had a credit of $207.0 million primarily related to a release of a U.S. valuation allowance, which was offset by a write-down of deferred tax assets in the amount of $83.0 million due to the lower corporate tax rate enacted under the 2017 “Tax Cuts and Jobs Act” reform.

[0001633978-19-000001:8k_2_02:25]
Conference Call

[0001633978-19-000001:8k_2_02:26]
Lumentum will host a conference call on February 5, 2019, at 5:30 am PT/8:30 am ET. A live webcast of the call and the replay will be available on the Lumentum website at http://investor.lumentum.com through February 12, 2019, at 11:59 pm ET. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the “Events and Presentations” section concurrently with this earnings press release. This press release is being furnished as an exhibit to a Current Report on Form 8-K filed with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001633978-19-000001:8k_2_02:27]
About Lumentum

[0001633978-19-000001:8k_2_02:28]
Lumentum (NASDAQ: LITE) is a market-leading designer and manufacturer of innovative optical and photonic products enabling optical networking and laser applications worldwide.  Lumentum’s optical components and subsystems are part of virtually every type of telecom, enterprise, and data center network.  Lumentum’s lasers enable advanced manufacturing techniques and diverse applications including next-generation 3D sensing capabilities.  Lumentum is headquartered in Milpitas, California with R&D, manufacturing, and sales offices worldwide.  For more information, visit www.lumentum.com.

[0001633978-19-000001:8k_2_02:29]
Forward-Looking Statements

[0001633978-19-000001:8k_2_02:30]
performance, including the general trends in our business and the industries in which we operate, future net revenue, earnings per share, and operating margins, and anticipated trends in our markets. These forward-looking statements involve risks and uncertainties that could cause actual results to differ materially from those projected. Among the factors that could cause actual results to differ from those contemplated are: (a) quarter-over-quarter product mix fluctuations which can materially impact profitability measures due to the broad gross margin ranges across our portfolio; (b) continued decline of average selling prices across our businesses; (c) effects of seasonality; (d) the ability of our suppliers and contract manufacturers to meet production and delivery requirements for our forecasted demand; (e) inherent uncertainty related to global markets, including changes in the political or economic environment and the imposition of tariffs or other duties, and the effect of such markets on demand for our products; (f) changes in customer demand; (g) our ability to attract and retain new customers, particularly in the 3D sensing market; (h) the risk that synergies and non-GAAP earnings accretion will not be realized or realized to the extent anticipated; (i) the risk that Lumentum’s financing or operating strategies will not be successful; (j) litigation relating to the merger; and (k) disruption from the Oclaro merger making it more difficult to maintain customer, supplier, key personnel and other strategic relationships. For more information on these and other risks, please refer to the “Risk Factors” section included in the Company’s Quarterly Report on Form 10-Q for the fiscal quarter ended December 29, 2018, to be filed with the Securities and Exchange Commission, in the S-4, as amended, filed by Lumentum with the Securities and Exchange Commission which was declared effective May 31, 2018, in connection with the Oclaro transaction and in the documents which are incorporated by reference therein, and in the Company’s other filings with the Securities and Exchange Commission, including the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2018, filed by Lumentum with the Securities and Exchange Commission on August 28, 2018. The forward-looking statements and preliminary financial results contained in this press release are made as of the date hereof and the Company assumes no obligation to update such statements, except as required by applicable law.

[0001633978-19-000001:8k_2_02:31]
Contact Information

[0001633978-19-000001:8k_2_02:32]
Investors:     Chris Coldren, 408-404-0606; investor.relations@lumentum.com

[0001633978-19-000001:8k_2_02:33]
Jim Fanucchi, 408-404-5400; investor.relations@lumentum.com

[0001633978-19-000001:8k_2_02:34]
Media:         Greg Kaufman, 408-546-4593; media@lumentum.com

[0001633978-19-000001:8k_2_02:35]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001633978-19-000001:8k_2_02:36]
LUMENTUM HOLDINGS INC.

[0001633978-19-000001:8k_2_02:37]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001633978-19-000001:8k_2_02:38]
(in millions, except per share data)

[0001633978-19-000001:8k_2_02:39]
(unaudited)

[0001633978-19-000001:8k_2_02:40]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |  | December 29, 2018 |  | December 30, 2017 |
| Net revenue | $ | 373.7 |  |  | $ | 404.6 |  |  | $ | 727.8 |  |  | $ | 647.8 |  |
| Cost of sales | 244.5 |  |  | 232.7 |  |  | 471.8 |  |  | 406.6 |  |
| Amortization of acquired intangibles | 4.4 |  |  | 0.8 |  |  | 5.2 |  |  | 1.6 |  |
| Gross profit | 124.8 |  |  | 171.1 |  |  | 250.8 |  |  | 239.6 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 42.8 |  |  | 43.8 |  |  | 77.4 |  |  | 80.1 |  |
| Selling, general and administrative | 62.7 |  |  | 35.7 |  |  | 95.7 |  |  | 62.3 |  |
| Restructuring and related charges | 7.8 |  |  | 0.8 |  |  | 9.1 |  |  | 3.7 |  |
| Total operating expenses | 113.3 |  |  | 80.3 |  |  | 182.2 |  |  | 146.1 |  |
| Income from operations | 11.5 |  |  | 90.8 |  |  | 68.6 |  |  | 93.5 |  |
| Unrealized gain (loss) on derivative liability | 10.9 |  |  | 7.9 |  |  | 8.8 |  |  | 12.1 |  |
| Interest and other income (expense), net | (4.7 | ) |  | (3.2 | ) |  | (7.1 | ) |  | (6.6 | ) |
| Income before income taxes | 17.7 |  |  | 95.5 |  |  | 70.3 |  |  | 99.0 |  |
| Provision for (benefit from) income taxes | 1.4 |  |  | (109.3 | ) |  | 6.6 |  |  | (112.9 | ) |
| Net income | 16.3 |  |  | 204.8 |  |  | 63.7 |  |  | 211.9 |  |
| Items reconciling net income to net income attributable to common stockholders: |  |  |  |  |  |  |  |
| Less: Cumulative dividends on Series A Preferred Stock | (0.1 | ) |  | (0.3 | ) |  | (0.3 | ) |  | (0.5 | ) |
| Less: Earnings allocated to Series A Preferred Stock | (0.1 | ) |  | (4.7 | ) |  | (1.2 | ) |  | (4.9 | ) |
| Net income attributable to common stockholders - Basic | $ | 16.1 |  |  | $ | 199.8 |  |  | $ | 62.2 |  |  | $ | 206.5 |  |
| Add: Earnings allocated to Series A Preferred Stock | 0.1 |  |  | 4.7 |  |  | 1.2 |  |  | 4.9 |  |
| Add/Less: Unrealized (gain) loss on derivative liability on Series A Preferred Stock | (10.9 | ) |  | (7.9 | ) |  | (8.8 | ) |  | (12.1 | ) |
| Add: Cumulative dividends on Series A Preferred Stock | 0.1 |  |  | 0.3 |  |  | 0.3 |  |  | 0.5 |  |
| Net income attributable to common stockholders - Diluted (a) | $ | 5.4 |  |  | $ | 196.9 |  |  | $ | 54.9 |  |  | $ | 199.8 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | $ | 0.24 |  |  | $ | 3.21 |  |  | $ | 0.96 |  |  | $ | 3.34 |  |
| Diluted | $ | 0.08 |  |  | $ | 3.05 |  |  | $ | 0.82 |  |  | $ | 3.10 |  |
| Shares used to compute net income per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | 66.8 |  |  | 62.2 |  |  | 65.0 |  |  | 61.9 |  |
| Diluted | 67.8 |  |  | 64.6 |  |  | 66.6 |  |  | 64.5 |  |

[0001633978-19-000001:8k_2_02:41]
(a) For the three and six months ended December 29, 2018 and December 30, 2017, our diluted earnings per share attributable to common stockholders is calculated using the two-class method because it is more dilutive than using the treasury stock method.

[0001633978-19-000001:8k_2_02:42]
LUMENTUM HOLDINGS INC.

[0001633978-19-000001:8k_2_02:43]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001633978-19-000001:8k_2_02:44]
(in millions, except share and per share data)

[0001633978-19-000001:8k_2_02:45]
(unaudited)

[0001633978-19-000001:8k_2_02:46]
|  | December 29, 2018 |  | June 30, 2018 |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |  |
| Cash and cash equivalents | $ | 371.3 |  |  | $ | 397.3 |  |
| Short-term investments | 312.8 |  |  | 314.2 |  |
| Accounts receivable, net | 266.5 |  |  | 197.1 |  |
| Inventories | 303.2 |  |  | 153.6 |  |
| Prepayments and other current assets | 103.1 |  |  | 65.0 |  |
| Total current assets | 1,356.9 |  |  | 1,127.2 |  |
| Property, plant and equipment, net | 444.7 |  |  | 306.9 |  |
| Goodwill | 344.7 |  |  | 11.3 |  |
| Other intangible assets, net | 445.0 |  |  | 7.0 |  |
| Deferred income taxes | 184.3 |  |  | 125.6 |  |
| Other non-current assets | 21.0 |  |  | 3.5 |  |
| Total assets | $ | 2,796.6 |  |  | $ | 1,581.5 |  |
| LIABILITIES, REDEEMABLE CONVERTIBLE PREFERRED STOCK AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 199.2 |  |  | $ | 126.5 |  |
| Accrued payroll and related expenses | 41.2 |  |  | 31.5 |  |
| Accrued expenses | 46.5 |  |  | 33.9 |  |
| Term loan, current | 5.0 |  |  | — |  |
| Other current liabilities | 33.6 |  |  | 22.1 |  |
| Total current liabilities | 325.5 |  |  | 214.0 |  |
| Convertible notes | 342.9 |  |  | 334.2 |  |
| Term loan, non-current | 485.8 |  |  | — |  |
| Derivative liability | — |  |  | 52.4 |  |
| Deferred tax liability | 56.1 |  |  | 0.3 |  |
| Other non-current liabilities | 26.6 |  |  | 18.7 |  |
| Total liabilities | 1,236.9 |  |  | 619.6 |  |
| Redeemable convertible preferred stock: |  |  |  |
| Non-controlling interest redeemable convertible Series A Preferred Stock, $0.001 par value, 10,000,000 authorized shares; zero and 35,805 shares issued and outstanding as of December 29, 2018 and June 30, 2018, respectively | — |  |  | 35.8 |  |
| Total redeemable convertible preferred stock | — |  |  | 35.8 |  |
| Stockholders’ equity: |  |  |  |
| Common stock, $0.001 par value, 990,000,000 authorized shares, 76,102,664 and 62,790,087 shares issued and outstanding as of December 29, 2018 and June 30, 2018, respectively | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital | 1,324.2 |  |  | 753.2 |  |
| Retained earnings | 229.2 |  |  | 166.4 |  |
| Accumulated other comprehensive income | 6.2 |  |  | 6.4 |  |
| Total stockholders’ equity | 1,559.7 |  |  | 926.1 |  |
| Total liabilities, redeemable convertible preferred stock, and stockholders’ equity | $ | 2,796.6 |  |  | $ | 1,581.5 |  |

[0001633978-19-000001:8k_2_02:47]
Use of Non-GAAP Financial Measures

[0001633978-19-000001:8k_2_02:48]
In this press release, Lumentum provides investors with gross margin, gross profit, operating margin, operating income, income (loss) before income taxes and certain expenses, net income, and net income (loss) per share on a non-GAAP basis. Lumentum believes this non-GAAP financial information provides additional insight into the Company’s on-going performance and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons. Specifically, the Company believes that providing this information allows investors to better understand the Company’s financial performance and, importantly, to evaluate the efficacy of the methodology and information used by management to evaluate and measure such operating performance. However, these measures may be different from non-GAAP measures used by other companies, limiting their usefulness for comparison purposes. The non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP. Investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future. Further, these non-GAAP financial measures may not be comparable to similarly titled measurements reported by other companies.

[0001633978-19-000001:8k_2_02:49]
Non-GAAP gross margin, non-GAAP gross profit, non-GAAP expenses, non-GAAP operating margin, non-GAAP operating income, non-GAAP income (loss) before income taxes, non-GAAP net income, and non-GAAP net income per share exclude (i) stock-based compensation, (ii) acquisition related costs, (iii) inventory write-downs due to cancelled programs and other costs and contingencies unrelated to current and future operations, (iv) amortization of acquired intangibles, (v) workforce related charges such as severance, retention bonuses and employee relocation costs related to formal restructuring plans, (vi) amortization of fair value adjustments, (vii) non-cash interest expense, (viii) unrealized gain (loss) on derivative liability, (ix) transferring product lines to Thailand and (x) non-cash income tax provision impacts, for example, a release of a U.S. valuation allowance, and the write down of deferred tax assets due to the 2017 Tax Cuts and Jobs Act. The presentation of these and other similar items in Lumentum’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001633978-19-000001:8k_2_02:50]
A quantitative reconciliation between GAAP and non-GAAP financial data with respect to historical periods is included in the supplemental financial table attached to this press release.

[0001633978-19-000001:8k_2_02:51]
LUMENTUM HOLDINGS INC.

[0001633978-19-000001:8k_2_02:52]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001633978-19-000001:8k_2_02:53]
(in millions, except per share data)

[0001633978-19-000001:8k_2_02:54]
(unaudited)

[0001633978-19-000001:8k_2_02:55]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |  | December 29, 2018 |  | December 30, 2017 |
| Gross profit on GAAP basis | $ | 124.8 |  |  | $ | 171.1 |  |  | $ | 250.8 |  |  | $ | 239.6 |  |
| Stock-based compensation (2) | 5.2 |  |  | 4.4 |  |  | 8.5 |  |  | 7.1 |  |
| Other charges related to non-recurring activities (1) | 14.0 |  |  | 5.5 |  |  | 26.5 |  |  | 16.2 |  |
| Amortization of acquired intangibles | 4.4 |  |  | 0.8 |  |  | 5.2 |  |  | 1.6 |  |
| Amortization of fair value adjustments (3) | 1.3 |  |  | — |  |  | 1.3 |  |  |  |
| Gross profit on non-GAAP basis | $ | 149.7 |  |  | $ | 181.8 |  |  | $ | 292.3 |  |  | $ | 264.5 |  |
| Research and development on GAAP basis | $ | 42.8 |  |  | $ | 43.8 |  |  | $ | 77.4 |  |  | $ | 80.1 |  |
| Stock-based compensation | (3.4 | ) |  | (3.8 | ) |  | (6.2 | ) |  | (6.9 | ) |
| Other charges related to non-recurring activities | (0.1 | ) |  | (1.1 | ) |  | (0.3 | ) |  | (1.8 | ) |
| Research and development on non-GAAP basis | $ | 39.3 |  |  | $ | 38.9 |  |  | $ | 70.9 |  |  | $ | 71.4 |  |
| Selling, general and administrative on GAAP basis | $ | 62.7 |  |  | $ | 35.7 |  |  | $ | 95.7 |  |  | $ | 62.3 |  |
| Stock-based compensation (2) | (21.1 | ) |  | (6.6 | ) |  | (25.8 | ) |  | (10.1 | ) |
| Acquisition related costs | (12.0 | ) |  | — |  |  | (13.1 | ) |  | — |  |
| Other charges related to non-recurring activities | (0.6 | ) |  | (0.8 | ) |  | (1.5 | ) |  | (2.3 | ) |
| Amortization of acquired intangibles | (0.8 | ) |  | — |  |  | (0.8 | ) |  | — |  |
| Selling, general and administrative on non-GAAP basis | $ | 28.2 |  |  | $ | 28.3 |  |  | $ | 54.5 |  |  | $ | 49.9 |  |
| Income from operations on GAAP basis | $ | 11.5 |  |  | $ | 90.8 |  |  | $ | 68.6 |  |  | $ | 93.5 |  |
| Stock-based compensation (2) | 29.7 |  |  | 14.8 |  |  | 40.5 |  |  | 24.1 |  |
| Acquisition related costs | 12.0 |  |  | — |  |  | 13.1 |  |  | — |  |
| Other charges related to non-recurring activities (1) | 14.7 |  |  | 7.4 |  |  | 28.3 |  |  | 20.3 |  |
| Amortization of acquired intangibles | 5.2 |  |  | 0.8 |  |  | 6.0 |  |  | 1.6 |  |
| Amortization of fair value adjustments (3) | 1.3 |  |  | — |  |  | 1.3 |  |  | — |  |
| Restructuring and related charges (2) | 7.8 |  |  | 0.8 |  |  | 9.1 |  |  | 3.7 |  |
| Income from operations on non-GAAP basis | $ | 82.2 |  |  | $ | 114.6 |  |  | $ | 166.9 |  |  | $ | 143.2 |  |
| Interest and other (expense) income, net on GAAP basis | $ | (4.7 | ) |  | $ | (3.2 | ) |  | $ | (7.1 | ) |  | $ | (6.6 | ) |
| Other interest and (income) expense adjustments (4) | 2.2 |  |  | — |  |  | 2.0 |  |  | — |  |
| Non-cash interest expense on convertible notes and term loan | 4.5 |  |  | 4.1 |  |  | 8.8 |  |  | 8.2 |  |
| Interest and other (expense) income, net on non-GAAP basis | $ | 2.0 |  |  | $ | 0.9 |  |  | $ | 3.7 |  |  | $ | 1.6 |  |
| Income before income taxes on GAAP basis | $ | 17.7 |  |  | $ | 95.5 |  |  | $ | 70.3 |  |  | $ | 99.0 |  |
| Stock-based compensation (2) | 29.7 |  |  | 14.8 |  |  | 40.5 |  |  | 24.1 |  |
| Acquisition related costs | 12.0 |  |  | — |  |  | 13.1 |  |  | — |  |
| Other charges related to non-recurring activities (1) | 14.7 |  |  | 7.4 |  |  | 28.3 |  |  | 20.3 |  |
| Amortization of acquired intangibles | 5.2 |  |  | 0.8 |  |  | 6.0 |  |  | 1.6 |  |

[0001633978-19-000001:8k_2_02:56]
| Amortization of fair value adjustments (3) | 1.3 |  |  | — |  |  | 1.3 |  |  | — |  |
| Restructuring and related charges (2) | 7.8 |  |  | 0.8 |  |  | 9.1 |  |  | 3.7 |  |
| Other interest and (income) expense adjustments (4) | 2.2 |  |  | — |  |  | 2.0 |  |  | — |  |
| Non-cash interest expense on convertible notes and term loan | 4.5 |  |  | 4.1 |  |  | 8.8 |  |  | 8.2 |  |
| Unrealized (gain) loss on derivative liability | (10.9 | ) |  | (7.9 | ) |  | (8.8 | ) |  | (12.1 | ) |
| Income before income taxes on non-GAAP basis | $ | 84.2 |  |  | $ | 115.5 |  |  | $ | 170.6 |  |  | $ | 144.8 |  |
| Provision for (benefit from) income taxes on GAAP basis | $ | 1.4 |  |  | $ | (109.3 | ) |  | $ | 6.6 |  |  | $ | (112.9 | ) |
| Income tax adjustments | 4.5 |  |  | 117.0 |  |  | (0.1 | ) |  | 122.1 |  |
| Provision for (benefit from) income taxes on non-GAAP basis (5) | $ | 5.9 |  |  | $ | 7.7 |  |  | $ | 6.5 |  |  | $ | 9.2 |  |
| Net income on GAAP basis | $ | 16.3 |  |  | $ | 204.8 |  |  | $ | 63.7 |  |  | $ | 211.9 |  |
| Stock-based compensation (2) | 29.7 |  |  | 14.8 |  |  | 40.5 |  |  | 24.1 |  |
| Acquisition related costs | 12.0 |  |  | — |  |  | 13.1 |  |  | — |  |
| Other charges related to non-recurring activities (1) | 14.7 |  |  | 7.4 |  |  | 28.3 |  |  | 20.3 |  |
| Amortization of acquired intangibles | 5.2 |  |  | 0.8 |  |  | 6.0 |  |  | 1.6 |  |
| Amortization of fair value adjustments (3) | 1.3 |  |  | — |  |  | 1.3 |  |  | — |  |
| Restructuring and related charges (2) | 7.8 |  |  | 0.8 |  |  | 9.1 |  |  | 3.7 |  |
| Other interest and (income) expense adjustments (4) | 2.2 |  |  | — |  |  | 2.0 |  |  | — |  |
| Non-cash interest expense on convertible notes and term loan | 4.5 |  |  | 4.1 |  |  | 8.8 |  |  | 8.2 |  |
| Unrealized (gain) loss on derivative liability | (10.9 | ) |  | (7.9 | ) |  | (8.8 | ) |  | (12.1 | ) |
| Income tax adjustments | (4.5 | ) |  | (117.0 | ) |  | 0.1 |  |  | (122.1 | ) |
| Net income on non-GAAP basis | $ | 78.3 |  |  | $ | 107.8 |  |  | $ | 164.1 |  |  | $ | 135.6 |  |
| Net income per share on non-GAAP basis | $ | 1.15 |  |  | $ | 1.67 |  |  | $ | 2.46 |  |  | $ | 2.10 |  |
| Shares used in per share calculation - diluted on GAAP and non-GAAP basis | 67.8 |  |  | 64.6 |  |  | 66.6 |  |  | 64.5 |  |

[0001633978-19-000001:8k_2_02:57]
(1) Other charges related to non-recurring activities for the three and six months ended December 29, 2018, primarily costs of transferring product lines to Thailand of $14.5 million and $27.2 million, respectively. Other charges related to non-recurring activities for the three and six months ended December 30, 2017, primarily include set-up costs for our facility in Thailand of $3.1 million, which we incurred during our second quarter of fiscal 2018, as well as inventory write-downs due to canceled programs not allocated to the segments of $7.0 million.

[0001633978-19-000001:8k_2_02:58]
(2) In connection with the acquisition of Oclaro, we recorded $20.9 million in restructuring and stock-based compensation expense in our condensed consolidated statements of operations, primarily attributable to severance and employee related benefits associated with Oclaro’s executive severance and retention agreements.

[0001633978-19-000001:8k_2_02:59]
(3) In connection with the acquisition of Oclaro, we recorded a fair value adjustment of $60.3 million to inventory, resulting in $1.3 million of amortization expense of the fair value adjustment during the three and six months ended December 29, 2018.

[0001633978-19-000001:8k_2_02:60]
(4) For the three and six months ended December 29, 2018, interest expense includes a one-time charge of $2.3 million and $2.7 million, respectively, related to a ticking fee to Deutsche bank.
