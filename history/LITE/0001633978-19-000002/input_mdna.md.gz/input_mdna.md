# LITE MD&A — 0001633978-19-000002


## mdna

[0001633978-19-000002:mdna:1]
[same as prior period, unchanged from 0001628280-18-013240:mdna:1]

[0001633978-19-000002:mdna:2]
[same as prior period, unchanged from 0001628280-18-013240:mdna:2]

[0001633978-19-000002:mdna:3]
[same as prior period, unchanged from 0001628280-18-013240:mdna:3]

[0001633978-19-000002:mdna:4]
[same as prior period, unchanged from 0001628280-18-013240:mdna:101]

[0001633978-19-000002:mdna:5]
[same as prior period, unchanged from 0001628280-18-013240:mdna:4]

[0001633978-19-000002:mdna:6]
[same as prior period, unchanged from 0001628280-18-013240:mdna:5]

[0001633978-19-000002:mdna:7]
[same as prior period, unchanged from 0001628280-18-013240:mdna:6]

[0001633978-19-000002:mdna:8]
On December 10, 2018, the Company completed its acquisition of Oclaro, a provider of optical components and modules for the long-haul, metro and data center markets. In accordance with the terms of the Merger Agreement, each issued and outstanding share of Oclaro common stock was automatically converted into the right to receive (i) $5.60 in cash and (ii) 0.0636 of a share of Lumentum common stock. The total transaction consideration was $1.4 billion, which was funded through the issuance of Lumentum common stock, new debt (refer to “Note 6. Term Loan Facility”), and cash balances of the combined company. Refer to “Note 5. Business Combination” in the notes to condensed consolidated financial statements for further discussion of the merger.

[0001633978-19-000002:mdna:9]
During the three and six months ended December 29, 2018, we recorded $20.9 million in restructuring and stock-based compensation expense in our condensed consolidated statements of operations, primarily attributable to severance and employee related benefits associated with Oclaro’s executive severance and retention agreements. These retention agreements provide, under certain circumstances, for payments and benefits upon an involuntary termination of employment, including following a change in control of Oclaro. The payments and benefits payable under these arrangements in the event of a change in control of Oclaro are subject to a “double trigger,” meaning that both a change in control of Oclaro and a subsequent involuntary termination of employment are required. In other words, the change in control of Oclaro does not by itself trigger any payments or benefits. Instead, payments and benefits are paid only if the employment of the employee is subsequently terminated without “cause” (or the employee resigns for “good reason”)  during a specified period following the change in control. The total expense incurred by us is $20.9 million, out of which $5.7 million relates to cash severance as part of our Restructuring expense, refer to “Note 15. Restructuring and Related Charges” and $15.2 million relates to acceleration of equity awards, refer to “Note 17. Stock-Based Compensation and Stock Plans.”

[0001633978-19-000002:mdna:10]
[same as prior period, unchanged from 0001628280-18-013240:mdna:9]

[0001633978-19-000002:mdna:11]
[same as prior period, unchanged from 0001628280-18-013240:mdna:10]

[0001633978-19-000002:mdna:12]
[same as prior period, unchanged from 0001628280-18-013240:mdna:11]

[0001633978-19-000002:mdna:13]
[same as prior period, unchanged from 0001628280-18-013240:mdna:12]

[0001633978-19-000002:mdna:14]
[same as prior period, unchanged from 0001628280-18-013240:mdna:13]

[0001633978-19-000002:mdna:15]
[same as prior period, unchanged from 0001628280-18-013240:mdna:14]

[0001633978-19-000002:mdna:16]
[same as prior period, unchanged from 0001628280-18-013240:mdna:15]

[0001633978-19-000002:mdna:17]
[same as prior period, unchanged from 0001628280-18-013240:mdna:16]

[0001633978-19-000002:mdna:18]
[same as prior period, unchanged from 0001628280-18-013240:mdna:17]

[0001633978-19-000002:mdna:19]
[same as prior period, unchanged from 0001628280-18-013240:mdna:18]

[0001633978-19-000002:mdna:20]
Except for (i) the accounting policies for revenue recognition and the related accounts updated as a result of adopting ASU 2014-09 (Topic 606) and (ii) the change in our functional currency, from certain foreign currencies to the reporting currency, there have been no significant changes to our significant accounting policies as of and for the six months ended December 29, 2018, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the year ended June 30, 2018. Refer to “Note 1. Description of Business and Summary of Significant Accounting Policies” for the details of ASU 2014-09 (Topic 606) adoption and our transition to the U.S. dollar as our functional currency. Management’s Discussion and Analysis of Financial Condition and Results of Operations contained in Part II, Item 7 of our Annual Report on Form 10-K for our fiscal year ended June 30, 2018 provides a more complete discussion of our critical accounting policies and estimates.

[0001633978-19-000002:mdna:21]
Recently Issued Accounting Pronouncements

[0001633978-19-000002:mdna:22]
Refer to “Note 2. Recently Issued Accounting Pronouncements” in the notes to condensed consolidated financial statements.

[0001633978-19-000002:mdna:23]
[same as prior period, unchanged from 0001628280-18-013240:mdna:126]

[0001633978-19-000002:mdna:24]
[same as prior period, unchanged from 0001628280-18-013240:mdna:23]

[0001633978-19-000002:mdna:25]
The results of operations for the periods presented are not necessarily indicative of results to be expected for future periods. The following table summarizes selected unaudited condensed consolidated statements of operations items as a percentage of net revenue:

[0001633978-19-000002:mdna:26]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |  | December 29, 2018 |  | December 30, 2017 |
| Segment net revenue: |  |  |  |  |  |  |  |
| OpComms | 87.1 | % |  | 89.0 | % |  | 87.3 | % |  | 87.7 | % |
| Lasers | 12.9 |  |  | 11.0 |  |  | 12.7 |  |  | 12.3 |  |
| Net revenue | 100.0 |  |  | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of sales | 65.4 |  |  | 57.5 |  |  | 64.8 |  |  | 62.8 |  |
| Amortization of acquired developed technologies | 1.2 |  |  | 0.2 |  |  | 0.7 |  |  | 0.2 |  |
| Gross profit | 33.4 |  |  | 42.3 |  |  | 34.5 |  |  | 37.0 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 11.5 |  |  | 10.8 |  |  | 10.6 |  |  | 12.4 |  |
| Selling, general and administrative | 16.8 |  |  | 8.8 |  |  | 13.1 |  |  | 9.6 |  |
| Restructuring and related charges | 2.1 |  |  | 0.2 |  |  | 1.3 |  |  | 0.6 |  |
| Total operating expenses | 30.3 |  |  | 19.8 |  |  | 25.0 |  |  | 22.6 |  |
| Income from operations | 3.1 |  |  | 22.5 |  |  | 9.4 |  |  | 14.4 |  |
| Unrealized gain (loss) on derivative liability | 2.9 |  |  | 2.0 |  |  | 1.2 |  |  | 1.9 |  |
| Interest and other income (expense), net | (1.3 | ) |  | (0.8 | ) |  | (1.0 | ) |  | (1.0 | ) |
| Income before income taxes | 4.7 |  |  | 23.7 |  |  | 9.7 |  |  | 15.3 |  |
| Provision for (benefit from) income taxes | 0.4 |  |  | (27.0 | ) |  | 0.9 |  |  | (17.4 | ) |
| Net income | 4.4 | % |  | 50.7 | % |  | 8.8 | % |  | 32.7 | % |

[0001633978-19-000002:mdna:27]
Financial Data for the three and six months ended December 29, 2018 and December 30, 2017

[0001633978-19-000002:mdna:28]
The following table summarizes selected unaudited condensed consolidated statements of operations items (in millions, except for percentages):

[0001633978-19-000002:mdna:29]
|  | Three Months Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | December 29, 2018 |  | December 30, 2017 |  | Change |  | Percentage Change |  | December 29, 2018 |  | December 30, 2017 |  | Change |  | Percentage Change |
| Segment net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| OpComms | $ | 325.4 |  |  | $ | 360.1 |  |  | $ | (34.7 | ) |  | (9.6 | )% |  | $ | 635.5 |  |  | $ | 568.0 |  |  | $ | 67.5 |  |  | 11.9 | % |
| Lasers | 48.3 |  |  | 44.5 |  |  | 3.8 |  |  | 8.5 |  |  | 92.3 |  |  | 79.8 |  |  | 12.5 |  |  | 15.7 |  |
| Net revenue | $ | 373.7 |  |  | $ | 404.6 |  |  | $ | (30.9 | ) |  | (7.6 | )% |  | $ | 727.8 |  |  | $ | 647.8 |  |  | $ | 80.0 |  |  | 12.3 | % |
| Gross profit | $ | 124.8 |  |  | $ | 171.1 |  |  | $ | (46.3 | ) |  | (27.1 | )% |  | $ | 250.8 |  |  | $ | 239.6 |  |  | $ | 11.2 |  |  | 4.7 | % |
| Gross margin | 33.4 | % |  | 42.3 | % |  |  |  |  |  | 34.5 | % |  | 37.0 | % |  |  |  |  |
| Research and development | $ | 42.8 |  |  | $ | 43.8 |  |  | $ | (1.0 | ) |  | (2.3 | )% |  | $ | 77.4 |  |  | $ | 80.1 |  |  | $ | (2.7 | ) |  | (3.4 | )% |
| Percentage of net revenue | 11.5 | % |  | 10.8 | % |  |  |  |  |  | 10.6 | % |  | 12.4 | % |  |  |  |  |
| Selling, general and administrative | $ | 62.7 |  |  | $ | 35.7 |  |  | $ | 27.0 |  |  | 75.6 | % |  | $ | 95.7 |  |  | $ | 62.3 |  |  | $ | 33.4 |  |  | 53.6 | % |
| Percentage of net revenue | 16.8 | % |  | 8.8 | % |  |  |  |  |  | 13.1 | % |  | 9.6 | % |  |  |  |  |
| Restructuring and related charges | $ | 7.8 |  |  | $ | 0.8 |  |  | $ | 7.0 |  |  | 875.0 | % |  | $ | 9.1 |  |  | $ | 3.7 |  |  | $ | 5.4 |  |  | 145.9 | % |
| Percentage of net revenue | 2.1 | % |  | 0.2 | % |  |  |  |  |  | 1.3 | % |  | 0.6 | % |  |  |  |  |

[0001633978-19-000002:mdna:30]
[same as prior period, unchanged from 0001628280-18-013240:mdna:29]

[0001633978-19-000002:mdna:31]
Net revenue decreased by $30.9 million, or 7.6%, during the three months ended December 29, 2018 compared to the three months ended December 30, 2017. This decrease was primarily due to decreased sales in Consumer and Industrial products, partially offset by increases in our Telecom products and $29.6 million of net revenue generated by Oclaro from the acquisition date.

[0001633978-19-000002:mdna:32]
OpComms net revenue decreased by $34.7 million, or 9.6%, during the three months ended December 29, 2018 compared to the three months ended December 30, 2017, driven by decreased sales of Consumer and Industrial products of $96.0 million, primarily in 3D sensing for mobile devices. Datacom products decreased by $1.0 million, driven by an overall decline in units and average selling price, which was mostly offset by sales of Datacom products by the newly acquired Oclaro business. These declines were partially offset by increased sales of Telecom of $62.3 million, primarily driven by ROADMs.

[0001633978-19-000002:mdna:33]
Lasers net revenue increased by $3.8 million, or 8.5%, during the three months ended December 29, 2018 compared to the three months ended December 30, 2017, primarily due to increased sales of our kilowatt class fiber lasers, offset by lower sales of our solid state lasers products.

[0001633978-19-000002:mdna:34]
Net revenue increased by $80.0 million, or 12.3%, during the six months ended December 29, 2018 compared to the six months ended December 30, 2017. This increase was primarily due to increased sales in Telecom products and $29.6 million of net revenue generated by Oclaro from the acquisition date.

[0001633978-19-000002:mdna:35]
OpComms net revenue increased by $67.5 million, or 11.9%, during the six months ended December 29, 2018 compared to the six months ended December 30, 2017, driven by increased sales of Telecom products of $94.8 million, partially offset by decreased sales of Consumer and Industrial products of $15.3 million and Datacom products of $12.0 million.

[0001633978-19-000002:mdna:36]
Lasers net revenue increased by $12.5 million, or 15.7%, during the six months ended December 29, 2018 compared to the six months ended December 30, 2017, primarily due to increased sales of our kilowatt class fiber lasers, offset by lower sales of our solid state lasers products.

[0001633978-19-000002:mdna:37]
During the three and six months ended December 29, 2018 and December 30, 2017, net revenue generated from a single customer which represented 10% or greater of total net revenue is summarized as follows:

[0001633978-19-000002:mdna:38]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |  | December 29, 2018 |  | December 30, 2017 |
| Customer A | 26.1 | % |  | 49.8 | % |  | 28.3 | % |  | 37.2 | % |
| Customer B | 15.0 | % |  | * |  |  | 15.0 | % |  | 10.5 | % |
| Customer C | 13.8 | % |  | * |  |  | 13.4 | % |  | * |  |
| *Represents less than 10% of total net revenue |  |  |  |  |  |  |  |

[0001633978-19-000002:mdna:39]
[same as prior period, unchanged from 0001628280-18-013240:mdna:35]

[0001633978-19-000002:mdna:40]
[same as prior period, unchanged from 0001628280-18-013240:mdna:36]

[0001633978-19-000002:mdna:41]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |  | December 29, 2018 |  | December 30, 2017 |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 20.7 |  |  | 5.6 | % |  | $ | 25.9 |  |  | 6.4 | % |  | $ | 42.6 |  |  | 5.9 | % |  | $ | 59.5 |  |  | 9.2 | % |
| Mexico | 55.0 |  |  | 14.7 |  |  | 30.6 |  |  | 7.6 |  |  | 111.3 |  |  | 15.3 |  |  | 55.4 |  |  | 8.6 |  |
| Other Americas | 0.9 |  |  | 0.2 |  |  | 2.0 |  |  | 0.5 |  |  | 1.8 |  |  | 0.2 |  |  | 4.2 |  |  | 0.6 |  |
| Total Americas | $ | 76.6 |  |  | 20.5 | % |  | $ | 58.5 |  |  | 14.5 | % |  | $ | 155.7 |  |  | 21.4 | % |  | $ | 119.1 |  |  | 18.4 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 99.9 |  |  | 26.7 | % |  | $ | 45.7 |  |  | 11.3 | % |  | $ | 165.5 |  |  | 22.7 | % |  | $ | 94.6 |  |  | 14.6 | % |
| Japan | 43.2 |  |  | 11.6 |  |  | 89.5 |  |  | 22.1 |  |  | 79.2 |  |  | 10.9 |  |  | 123.6 |  |  | 19.1 |  |
| South Korea | 61.3 |  |  | 16.4 |  |  | 86.5 |  |  | 21.4 |  |  | 131.3 |  |  | 18.0 |  |  | 97.4 |  |  | 15.0 |  |
| Other Asia-Pacific | 61.8 |  |  | 16.5 |  |  | 98.9 |  |  | 24.4 |  |  | 136.0 |  |  | 18.7 |  |  | 162.2 |  |  | 25.0 |  |
| Total Asia-Pacific | $ | 266.2 |  |  | 71.2 | % |  | $ | 320.6 |  |  | 79.2 | % |  | $ | 512.0 |  |  | 70.3 | % |  | $ | 477.8 |  |  | 73.7 | % |
| EMEA | $ | 30.9 |  |  | 8.3 | % |  | $ | 25.5 |  |  | 6.3 | % |  | $ | 60.1 |  |  | 8.3 | % |  | $ | 50.9 |  |  | 7.9 | % |
| Total net revenue | $ | 373.7 |  |  |  |  |  | $ | 404.6 |  |  |  |  |  | $ | 727.8 |  |  |  |  |  | $ | 647.8 |  |  |  |  |

[0001633978-19-000002:mdna:42]
During the three months ended December 29, 2018 and December 30, 2017, net revenue from customers outside the United States, based on customer shipping location, represented 94.4% and 93.6% of net revenue, respectively. Our net revenue from Mexico increased due to increased demand for our ROADM products from one of our large customers who manufactures in Mexico, while net revenue from  Japan, South Korea and Other Asia-Pacific decreased largely driven by 3D sensing products for mobile devices.

[0001633978-19-000002:mdna:43]
During the six months ended December 29, 2018 and December 30, 2017, net revenue from customers outside the United States, based on customer shipping location, represented 94.1% and 90.8% of net revenue, respectively. Our net revenue from

[0001633978-19-000002:mdna:44]
Mexico increased due to increased demand for our ROADM products from one of our large customers who manufactures in Mexico, while net revenue from Hong Kong and South Korea grew due to our 3D sensing products ramp for mobile devices.

[0001633978-19-000002:mdna:45]
[same as prior period, unchanged from 0001628280-18-013240:mdna:39]

[0001633978-19-000002:mdna:46]
[same as prior period, unchanged from 0001628280-18-013240:mdna:40]

[0001633978-19-000002:mdna:47]
The following table summarizes segment gross margin for the three and six months ended December 29, 2018 and December 30, 2017 (in millions, except for percentages):

[0001633978-19-000002:mdna:48]
|  | Gross Profit |  | Gross Margin |  | Gross Profit |  | Gross Margin |
|  | Three Months Ended |  | Three Months Ended |  | Six Months Ended |  | Six Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |  | December 29, 2018 |  | December 30, 2017 |  | December 29, 2018 |  | December 30, 2017 |  | December 29, 2018 |  | December 30, 2017 |
| OpComms | $ | 129.1 |  |  | $ | 161.9 |  |  | 39.7 | % |  | 45.0 | % |  | $ | 254.0 |  |  | $ | 234.0 |  |  | 40.0 | % |  | 41.2 | % |
| Lasers | 20.6 |  |  | 19.9 |  |  | 42.7 | % |  | 44.7 | % |  | 38.3 |  |  | 30.5 |  |  | 41.5 | % |  | 38.2 | % |
| Segment total | $ | 149.7 |  |  | $ | 181.8 |  |  | 40.1 | % |  | 44.9 | % |  | $ | 292.3 |  |  | $ | 264.5 |  |  | 40.2 | % |  | 40.8 | % |
| Unallocated corporate items (1) | (24.9 | ) |  | (10.7 | ) |  |  |  |  |  | (41.5 | ) |  | (24.9 | ) |  |  |  |  |
| Total | $ | 124.8 |  |  | $ | 171.1 |  |  | 33.4 | % |  | 42.3 | % |  | $ | 250.8 |  |  | $ | 239.6 |  |  | 34.5 | % |  | 37.0 | % |

[0001633978-19-000002:mdna:49]
(1) The unallocated corporate items for the periods presented include the effects of amortization of acquired developed technologies and other intangibles, share-based compensation and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0001633978-19-000002:mdna:50]
Other charges of unallocated corporate items for the three and six months ended December 29, 2018 primarily include set-up costs of our facility in Thailand, including costs of transferring product lines to Thailand of $14.5 million and $27.2 million, respectively. During each of the three and six months ended December 30, 2017, other charges of unallocated corporate items primarily consisted of set-up costs of our facility in Thailand of $3.1 million, which we incurred during our second quarter of fiscal 2018, as well as inventory write-downs due to canceled programs not allocated to the segments of $7.0 million.

[0001633978-19-000002:mdna:51]
[same as prior period, unchanged from 0001628280-18-013240:mdna:45]

[0001633978-19-000002:mdna:52]
Gross margin during the three months ended December 29, 2018 decreased to 33.4% from 42.3% during the three months ended December 30, 2017. The decrease was primarily due to decreased sales in our 3D sensing products, which have higher gross margins than the average for the Company as well as increased costs related to startup and transfer costs for our Thailand facility.

[0001633978-19-000002:mdna:53]
Gross margin during the six months ended December 29, 2018 decreased to 34.5% from 37.0% during the six months ended December 30, 2017. The decrease was primarily due to increased startup and product transfer costs for our Thailand facility.

[0001633978-19-000002:mdna:54]
[same as prior period, unchanged from 0001628280-18-013240:mdna:47]

[0001633978-19-000002:mdna:55]
[same as prior period, unchanged from 0001628280-18-013240:mdna:48]

[0001633978-19-000002:mdna:56]
[same as prior period, unchanged from 0001628280-18-013240:mdna:49]

[0001633978-19-000002:mdna:57]
OpComms gross margin during the three months ended December 29, 2018 decreased to 39.7% from 45.0% during the three months ended December 30, 2017. This decrease was primarily due to lower sales of our 3D sensing products which have higher gross margins than the averages for this segment.

[0001633978-19-000002:mdna:58]
OpComms gross margin during the six months ended December 29, 2018 decreased to 40.0% from 41.2% during the six months ended December 30, 2017. This decrease was primarily due to decreased sales of our 3D sensing products which have higher gross margins than the averages for this segment.

[0001633978-19-000002:mdna:59]
[same as prior period, unchanged from 0001628280-18-013240:mdna:51]

[0001633978-19-000002:mdna:60]
Lasers gross margin during the three months ended December 29, 2018 decreased to 42.7% from 44.7% during the three months ended December 30, 2017. This decrease was primarily due to decreased sales of our Solid State products which have higher gross margins than the averages for this segment.

[0001633978-19-000002:mdna:61]
Lasers gross margin during the six months ended December 29, 2018 increased to 41.5% from 38.2% during the six months ended December 30, 2017. This increase was primarily due to increased revenue and manufacturing utilization for our kilowatt class fiber lasers products partially offset by decreased sales of our Solid State products.

[0001633978-19-000002:mdna:62]
Research and Development (“R&D”)

[0001633978-19-000002:mdna:63]
R&D expense decreased by $1.0 million, or 2.3%, during the three months ended December 29, 2018 compared to the three months ended December 30, 2017. The decrease in R&D expense was primarily due to a decrease in employee-related costs which includes a decrease in variable incentive compensation. The decrease is partially offset by additional R&D expense due to the Oclaro acquisition.

[0001633978-19-000002:mdna:64]
R&D expense decreased by $2.7 million, or 3.4%, during the six months ended December 29, 2018 compared to the six months ended December 30, 2017. The decrease in R&D expense was primarily due to a decrease in employee-related costs which includes a decrease in variable incentive compensation. The decrease is partially offset by additional R&D expense due to the Oclaro acquisition.

[0001633978-19-000002:mdna:65]
We believe that continuing our investments in R&D is critical to attaining our strategic objectives. We plan to continue to invest in R&D and new products that we believe will further differentiate us in the marketplace and expect our investment in R&D to increase in absolute dollars in future quarters.

[0001633978-19-000002:mdna:66]
Selling, General and Administrative (“SG&A”)

[0001633978-19-000002:mdna:67]
SG&A expense increased by $27.0 million, or 75.6%, during the three months ended December 29, 2018 compared to the three months ended December 30, 2017. The increase was primarily attributable to $13.3 million in charges related to the acceleration of equity awards under certain Oclaro executive severance and retention agreements, $9.0 million related to the success fee on the closing of the Oclaro transaction, an increase in payroll related expense of $2.4 million and an increase in stock-based compensation of $1.0 million.

[0001633978-19-000002:mdna:68]
SG&A expense increased by $33.4 million, or 53.6%, during the six months ended December 29, 2018 compared to the six months ended December 30, 2017. The increase was primarily attributable to $13.3 million in charges related to the acceleration of equity awards under certain Oclaro executive severance and retention agreements, $9.0 million related to the success fee on the closing of the Oclaro transaction, an increase in payroll related expense of $2.4 million, which includes an increase in variable incentive compensation of $1.2 million, an increase in stock-based compensation of $2.3 million and $1.1 million of costs related to the anticipated acquisition of Oclaro, which occurred on December 10, 2018.

[0001633978-19-000002:mdna:69]
We expect to experience in the future certain non-core expenses, such as mergers and acquisition-related expenses and litigation expenses, which will likely increase our SG&A expenses and potentially impact our profitability expectations in any particular quarter.

[0001633978-19-000002:mdna:70]
[same as prior period, unchanged from 0001628280-18-013240:mdna:59]

[0001633978-19-000002:mdna:71]
We have initiated various strategic restructuring events primarily intended to reduce costs, consolidate our operations, rationalize the manufacturing of our products and align our business in response to market conditions and as a result of our acquisition of Oclaro on December 10, 2018.

[0001633978-19-000002:mdna:72]
During the three and six months ended December 29, 2018, we recorded $7.8 million and $9.1 million, respectively, in restructuring and related charges in our condensed consolidated statements of operations, primarily attributable to severance and employee related benefits associated with Oclaro’s executive severance and retention agreements. These retention agreements provide, under certain circumstances, for payments and benefits upon an involuntary termination of employment. We made $5.7 million of payments in connection with these agreements during the three and six months ended December 29, 2018. Refer to “Note 5. Business Combinations.”

[0001633978-19-000002:mdna:73]
On September 5, 2018, we implemented an internal re-organization to help us extend our market leadership position. The re-organization focuses on strengthening our product quality, developing new enabling technologies required to support a long-term portfolio roadmap, and developing commercial proposals and new product introduction (“NPI”) priorities to maintain and grow our market leadership position, while continuing to drive new customer and ecosystem partner engagements. Refer to “Note 15. Restructuring and Related Charges” in the notes to condensed consolidated financial statements.

[0001633978-19-000002:mdna:74]
During the three and six months ended December 30, 2017, we recorded $0.8 million and $3.7 million, respectively, in restructuring and related charges in our condensed consolidated statements of operations, primarily attributable to costs to vacate facilities, temporary labor and employee-related benefits, as well as costs for materials used in set up and production activities. We incurred no additional costs related to severance during the three and six months ended December 30, 2017.

[0001633978-19-000002:mdna:75]
[same as prior period, unchanged from 0001628280-18-013240:mdna:63]

[0001633978-19-000002:mdna:76]
[same as prior period, unchanged from 0001628280-18-013240:mdna:64]

[0001633978-19-000002:mdna:77]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |  | December 29, 2018 |  | December 30, 2017 |
| Interest expense | $ | (8.5 | ) |  | $ | (4.6 | ) |  | $ | (13.6 | ) |  | $ | (9.0 | ) |
| Foreign exchange gains (losses), net | 0.3 |  |  | (0.3 | ) |  | — |  |  | (0.7 | ) |
| Interest income | 3.4 |  |  | 1.7 |  |  | 6.1 |  |  | 3.1 |  |
| Other income (expense), net | 0.1 |  |  | — |  |  | 0.4 |  |  | — |  |
| Interest and other income (expense), net | $ | (4.7 | ) |  | $ | (3.2 | ) |  | $ | (7.1 | ) |  | $ | (6.6 | ) |

[0001633978-19-000002:mdna:78]
For the three months ended December 29, 2018, interest and other income (expense), net increased by $1.5 million in expense as compared to the three months ended December 30, 2017, mainly driven by ticking fees and interest expense on our term loan that we entered into during the second quarter of fiscal 2018.

[0001633978-19-000002:mdna:79]
For the six months ended December 29, 2018, interest and other income (expense), net increased by $0.5 million in expense as compared to the six months ended December 30, 2017, mainly driven by increased interest expense on our term loan that we entered into during the second quarter of fiscal 2018.

[0001633978-19-000002:mdna:80]
[same as prior period, unchanged from 0001628280-18-013240:mdna:67]

[0001633978-19-000002:mdna:81]
Unrealized gain (loss) on Series A Preferred Stock derivative liability amounted to $10.9 million and $8.8 million for the three and six months ended December 29, 2018, respectively, as compared to $7.9 million and $12.1 million for the three and six months ended December 30, 2017, respectively. The changes are primarily related to the change in the price of our underlying common stock and are reflected in the condensed consolidated statements of operations as “unrealized gain (loss) on derivative liability”.  We do not expect any gains or loss in future due to conversion, for further discussion of our derivative liability, see “Note 13. Derivative Liability” in the notes to condensed consolidated financial statements.

[0001633978-19-000002:mdna:82]
[same as prior period, unchanged from 0001628280-18-013240:mdna:69]

[0001633978-19-000002:mdna:83]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |  | December 29, 2018 |  | December 30, 2017 |
| Provision for (benefit from) income taxes | $ | 1.4 |  |  | $ | (109.3 | ) |  | $ | 6.6 |  |  | $ | (112.9 | ) |

[0001633978-19-000002:mdna:84]
The comparability of our operating results in the first half of fiscal 2019 compared to the corresponding prior year period was impacted by the U.S. Tax Cuts and Jobs Act of 2017 (the “Tax Act”), which was enacted on December 22, 2017. The Tax Act introduced significant changes to U.S. income tax law including reducing the U.S. federal statutory tax rate from 35% to 21% and imposing new taxes on certain foreign-sourced earnings and certain intercompany payments. Due to the timing of the enactment and the complexity involved in applying the provisions of the Tax Act, we made reasonable estimates of the effects and recorded provisional amounts in our financial statements as of fiscal 2018 in accordance with SEC Staff Accounting Bulletin No. 118 (“SAB 118”). During the period ended December 29, 2018, we completed our accounting for the Tax Act with no material adjustment to our provisional estimates recorded.

[0001633978-19-000002:mdna:85]
[same as prior period, unchanged from 0001628280-18-013240:mdna:72]

[0001633978-19-000002:mdna:86]
Our quarterly tax provision and estimate of our annual effective tax rate are subject to variation due to several factors, including variability in pre-tax income (or loss), the mix of jurisdictions to which such income relates, changes in how we do business, and tax law developments. Our estimated effective tax rate for the fiscal 2019 differs from the 21% U.S. statutory rate primarily due to the income tax benefit of the earnings of our foreign subsidiaries being taxed at rates lower than the U.S. statutory rate as well as the U.S. federal R&D tax credit, partially offset by the income tax expense from non-deductible stock-based compensation and the tax effect of Global Intangible Low-Taxed Income (“GILTI”), Base Erosion and Anti-Abuse Tax (“BEAT”) and subpart F inclusion.

[0001633978-19-000002:mdna:87]
We recorded a tax expense of $1.4 million and $6.6 million for the three and six months ended December 29, 2018, respectively. Our provision for income taxes for the three and six months ended December 29, 2018 varied from the 21% U.S. statutory rate primarily due to the income tax benefit of the earnings of our foreign subsidiaries being taxed at rates lower than the U.S. statutory rate as well as the tax benefit from the U.S. federal R&D tax credit, partially offset by the income tax expense from non-deductible stock-based compensation and the tax effect of GILTI, BEAT, and subpart F inclusion.

[0001633978-19-000002:mdna:88]
We recorded a tax benefit of $109.3 million and $112.9 million for the three and six months ended December 30, 2017, respectively. Our benefit from income taxes for the three and six months ended December 30, 2017 varied from the previous U.S. federal statutory income tax rate of 35% primarily due to earnings in foreign operations, the tax benefit from excess stock-based compensation deductions, and the non-taxable unrealized gain from the embedded derivatives for the Series A Preferred Stock. Our tax benefit for the three and six months ended December 30, 2017 was primarily due to the release of our U.S. federal and certain state valuation allowances. The benefit of this valuation allowance release was partially offset by a non-cash deferred expense associated with the change in the U.S. statutory rate as a result of the Tax Act which was enacted during the three-month period ended December 30, 2017.

[0001633978-19-000002:mdna:89]
As of December 29, 2018, we had $9.0 million of unrecognized tax benefits, which, if recognized, would affect the effective tax rate. We are subject to examination of income tax returns by various domestic and foreign tax authorities. The timing of resolutions and closures of tax audits is highly unpredictable. Given the uncertainty, it is reasonably possible that certain tax audits may be concluded within the next 12 months. An estimate of the range of increase or decrease that could occur in the next 12 months cannot be made. However, the estimated impact to tax expense and net income from the resolution and closure of tax exams is not expected to be significant within the next 12 months.

[0001633978-19-000002:mdna:90]
On July 24, 2018, the Ninth Circuit Court of Appeals (the “Court”) issued an opinion in Altera Corp. v. Commissioner requiring related parties in an intercompany cost sharing arrangement to share expenses related to share-based compensation. This opinion reversed the prior decision of the United States Tax Court. On August 7, 2018, the Court withdrew the opinion issued on July 24, 2018 to allow time for a reconstituted panel of judges to confer. We will continue to monitor the case and potential impact to our consolidated financial statements.

[0001633978-19-000002:mdna:91]
We operate under a tax holiday in Thailand, which could be effective through fiscal year 2025, and may be extended if certain additional requirements are satisfied. The tax holiday is conditional upon our meeting certain employment and investment thresholds. The tax holiday had an insignificant impact on our foreign taxes and on net income per share (diluted) for the fiscal year ended June 30, 2018 and for the three and six months ended December 29, 2018. Oclaro’s China subsidiary operates under a tax incentive that is effective through fiscal year 2022. The tax incentive is conditional upon meeting certain operational requirements. The China tax incentive had insignificant impact on our tax provision and on net income per share (diluted) for the three and six months ended December 29, 2018.

[0001633978-19-000002:mdna:92]
[same as prior period, unchanged from 0001628280-18-013240:mdna:80]

[0001633978-19-000002:mdna:93]
The following table summarizes our contractual obligations as of December 29, 2018, and the effect such obligations are expected to have on our liquidity and cash flow over the next five years (in millions):

[0001633978-19-000002:mdna:94]
|  | Payments due by period |
|  | Total |  | Less than 1 year |  | 1 - 3 years |  | 3 - 5 years |  | More than 5 years |
| Contractual Obligations |  |  |  |  |  |  |  |  |  |
| Acquisition contingencies (1) | $ | 3.0 |  |  | $ | 3.0 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Asset retirement obligations | 2.8 |  |  | — |  |  | 1.0 |  |  | 0.5 |  |  | 1.3 |  |
| Capital lease obligations (2) | 5.9 |  |  | 5.3 |  |  | 0.6 |  |  | — |  |  | — |  |
| Operating lease obligations (2) | 106.6 |  |  | 18.5 |  |  | 29.8 |  |  | 24.1 |  |  | 34.2 |  |
| Pension plan contributions (3) | 1.8 |  |  | 1.8 |  |  | — |  |  | — |  |  | — |  |
| Purchase obligations (4) | 281.8 |  |  | 271.8 |  |  | 10.0 |  |  | — |  |  | — |  |
| Term loan - principal (5) | 500.0 |  |  | 5.0 |  |  | 10.0 |  |  | 8.8 |  |  | 476.2 |  |
| Term loan - interest (5) | 165.4 |  |  | 25.7 |  |  | 48.0 |  |  | 41.2 |  |  | 50.5 |  |
| Convertible notes - principal (6) | 450.0 |  |  | — |  |  | — |  |  | — |  |  | 450.0 |  |
| Convertible notes - interest (7) | 6.2 |  |  | 1.1 |  |  | 2.2 |  |  | 2.2 |  |  | 0.7 |  |
| Total | $ | 1,523.5 |  |  | $ | 332.2 |  |  | $ | 101.6 |  |  | $ | 76.8 |  |  | $ | 1,012.9 |  |

[0001633978-19-000002:mdna:95]
(1) Refer to “Note 10. Fair Value Measurements” in the notes to condensed consolidated financial statements.

[0001633978-19-000002:mdna:96]
(2) Refer to “Note 18. Commitments and Contingencies” in the notes to condensed consolidated financial statements.

[0001633978-19-000002:mdna:97]
(3) As a result of acquiring Time-Bandwidth Products Inc. in January 2014, we assumed a pension plan for our employees in Switzerland (“Switzerland Plan”). The Switzerland Plan is partially funded.

[0001633978-19-000002:mdna:98]
As a result of acquiring Oclaro, Inc. in December 2018, we assumed defined contribution pension plans for our employees in Japan and the U.K., and a defined benefit plan for our employees in Japan (“Japan Plan”). The Japan Plan is unfunded.

[0001633978-19-000002:mdna:99]
The amount in the preceding table represents planned contributions to our various pension plans. Although additional future contributions will be required, the amount and timing of these contributions will be affected by actuarial assumptions, the actual rate of returns on plan assets, the level of market interest rates, legislative changes, and the amount of voluntary contributions to the plan. Any contributions for the following fiscal year and later will depend on the value of the plan assets in the future and thus are uncertain. As such, we have not included any amounts beyond 1 year in the table above.

[0001633978-19-000002:mdna:100]
(4) Purchase obligations represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Refer to “Note 18. Commitments and Contingencies” in the notes to condensed consolidated financial statements.

[0001633978-19-000002:mdna:101]
(5) We incurred indebtedness in an aggregate principal amount of $500.0 million pursuant to a senior secured Term Loan Facility that we entered into in connection with the closing of the Oclaro acquisition on December 10, 2018. The amounts of interest included in the table above is based on current interest rate. Refer to “Note 6. Term Loan Facility” in the notes to condensed consolidated financial statements.

[0001633978-19-000002:mdna:102]
(6) Refer to “Note 12. Convertible Senior Notes” in the notes to condensed consolidated financial statements.

[0001633978-19-000002:mdna:103]
(7) Includes interest on our 0.25% Convertible Senior Notes due in 2024 through March 2024 as we have the right to redeem the 2024 Notes in whole or in part at any time on or after March 15, 2024. Refer to “Note 12. Convertible Senior Notes” in the notes to condensed consolidated financial statements.

[0001633978-19-000002:mdna:104]
As of December 29, 2018, our other non-current liabilities also include $9.0 million of unrecognized tax benefit for uncertain tax positions. We are unable to reliably estimate the timing of future payments related to uncertain tax positions and therefore have excluded them from the preceding table.

[0001633978-19-000002:mdna:105]
[same as prior period, unchanged from 0001628280-18-013240:mdna:90]

[0001633978-19-000002:mdna:106]
[same as prior period, unchanged from 0001628280-18-013240:mdna:91]

[0001633978-19-000002:mdna:107]
[same as prior period, unchanged from 0001628280-18-013240:mdna:98]

[0001633978-19-000002:mdna:108]
[same as prior period, unchanged from 0001628280-18-013240:mdna:99]

[0001633978-19-000002:mdna:109]
As of December 29, 2018 and June 30, 2018, our cash and cash equivalents of $371.3 million and $397.3 million, respectively, were largely held in the United States. The total amount of cash outside the United States as of December 29, 2018 was $105.1 million, which was primarily held in the British Virgin Islands, Canada, Cayman Islands, China, Japan, Thailand and the United Kingdom. Although the cash currently held in the United States as well as the cash generated in the United States from future operations is expected to cover our normal operating requirements, a substantial amount of additional cash could be required for other purposes, such as capital expenditures to support our business and growth, including costs associated with increasing internal manufacturing capabilities, such as our new Thailand facility, strategic transactions and partnerships, and acquisitions, such as our acquisition of Oclaro. Our intent is to indefinitely reinvest funds held outside the United States, except for the funds held in the Cayman Islands and Hong Kong, and our current plans do not demonstrate a need to repatriate them to fund our domestic operations. However, if in the future, we encounter a significant need for liquidity domestically or at a particular location that we cannot fulfill through borrowings, equity offerings, or other internal or external sources, or the cost to bring back the money is insignificant from a tax perspective, we may determine that cash repatriations are necessary or desirable. Repatriation could result in additional material taxes. These factors may cause us to have an overall tax rate higher than other companies or higher than our tax rates have been in the past. If conditions warrant, we may seek to obtain additional financing through debt or equity sources. To the extent we issue additional shares, our existing stockholders may be diluted. However, any such financing may not be available on terms favorable to us, or may not be available at all.

[0001633978-19-000002:mdna:110]
As of December 29, 2018, our consolidated balance of cash and cash equivalents decreased by $26.0 million, to $371.3 million from $397.3 million as of June 30, 2018. The decrease in cash and cash equivalents was mainly due to cash used in investing activities of $672.4 million, principally related to cash used to acquire Oclaro; partially offset by cash provided by financing activities of $487.0 million, primarily related to $491.0 million in proceeds from a term loan, net of debt issuance costs, used to fund the Oclaro acquisition, and cash provided by operating activities of $159.6 million during the six months ended December 29, 2018.

[0001633978-19-000002:mdna:111]
[same as prior period, unchanged from 0001628280-18-013240:mdna:103]

[0001633978-19-000002:mdna:112]
Cash provided by operating activities was $159.6 million during the six months ended December 29, 2018, primarily resulting from $63.7 million of net income, $83.4 million of non-cash items (such as depreciation, stock-based compensation, unrealized loss on derivative liability, amortization of intangibles, amortization of discount on the 2024 Notes, amortization of the debt issuance costs on the term loan, and amortization of the inventory fair value adjustment in connection with the acquisition of Oclaro), and $12.5 million of changes in our operating assets and liabilities. Changes in our operating assets and liabilities related

[0001633978-19-000002:mdna:113]
primarily to an increase in accounts payable of $16.5 million, a change in income taxes, net of $5.8 million, an increase in accrued expenses and other current and non-current liabilities of $2.8 million and a decrease in inventories of $0.5 million, partially offset by an increase of prepayments and other current and non-current assets of $10.7 million, an increase of accounts receivable of $0.8 million and a decrease in accrued payroll and related expenses of $1.6 million.

[0001633978-19-000002:mdna:114]
Cash provided by operating activities was $114.8 million during the six months ended December 30, 2017, primarily resulting from $211.9 million of net income, offset by $66.7 million of non-cash items (such as depreciation, stock-based compensation, amortization of intangibles, amortization of discount on the 2024 Notes, net of the release of the valuation allowance and unrealized gain on derivative liability), and $30.4 million of changes in our operating assets and liabilities. Changes in our operating assets and liabilities related primarily to an increase in accounts receivable of $55.8 million offset by an increase in accrued expenses and other current and non-current liabilities of $15.1 million.

[0001633978-19-000002:mdna:115]
[same as prior period, unchanged from 0001628280-18-013240:mdna:105]

[0001633978-19-000002:mdna:116]
Cash used in investing activities of $672.4 million during the six months ended December 29, 2018, was primarily attributable to $619.8 million in cash payments to acquire all outstanding shares of common stock of Oclaro, net of cash received through the acquisition of Oclaro. In addition we had capital expenditures of $53.9 million, partially offset by sales of short-term investments, net of purchases of $2.0 million.

[0001633978-19-000002:mdna:117]
Cash used in investing activities of $191.1 million during the six months ended December 30, 2017, was primarily attributable to capital expenditures of $50.2 million and purchases of short-term investments, net of sales of $140.9 million.

[0001633978-19-000002:mdna:118]
[same as prior period, unchanged from 0001628280-18-013240:mdna:107]

[0001633978-19-000002:mdna:119]
Cash provided by financing activities of $487.0 million during the six months ended December 29, 2018, primarily resulted from $491.0 million of proceeds from a term loan, net of debt issuance costs, used to partially finance the Oclaro acquisition, and $4.7 million from the issuance of common stock under the employee stock plan; partially offset by tax payments related to restricted stock of $2.4 million, the repayment of capital lease obligations of $4.6 million, a payment of an acquisition related holdback of $1.0 million, and dividend payments on our Series A Preferred Stock of $0.7 million.

[0001633978-19-000002:mdna:120]
During the six months ended December 30, 2017, cash provided by financing activities of $4.7 million, resulted primarily from the issuance of common stock under the employee stock plan.

[0001633978-19-000002:mdna:121]
[same as prior period, unchanged from 0001628280-18-013240:mdna:109]

[0001633978-19-000002:mdna:122]
We believe that our cash and cash equivalents as of December 29, 2018, and cash flows from our operating activities will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months. However, if market conditions are favorable, we may evaluate alternatives to opportunistically pursue additional financing.

[0001633978-19-000002:mdna:123]
[same as prior period, unchanged from 0001628280-18-013240:mdna:111]

[0001633978-19-000002:mdna:124]
[same as prior period, unchanged from 0001628280-18-013240:mdna:112]

[0001633978-19-000002:mdna:125]
[same as prior period, unchanged from 0001628280-18-013240:mdna:113]

[0001633978-19-000002:mdna:126]
[same as prior period, unchanged from 0001628280-18-013240:mdna:114]

[0001633978-19-000002:mdna:127]
[same as prior period, unchanged from 0001628280-18-013240:mdna:115]

[0001633978-19-000002:mdna:128]
[same as prior period, unchanged from 0001628280-18-013240:mdna:116]

[0001633978-19-000002:mdna:129]
[same as prior period, unchanged from 0001628280-18-013240:mdna:117]

[0001633978-19-000002:mdna:130]
[same as prior period, unchanged from 0001628280-18-013240:mdna:118]

[0001633978-19-000002:mdna:131]
[same as prior period, unchanged from 0001628280-18-013240:mdna:119]

[0001633978-19-000002:mdna:132]
[same as prior period, unchanged from 0001628280-18-013240:mdna:120]

[0001633978-19-000002:mdna:133]
[same as prior period, unchanged from 0001628280-18-013240:mdna:121]

[0001633978-19-000002:mdna:134]
[same as prior period, unchanged from 0001628280-18-013240:mdna:122]

[0001633978-19-000002:mdna:135]
[same as prior period, unchanged from 0001628280-18-013240:mdna:123]

[0001633978-19-000002:mdna:136]
In March 2018, we entered into the Merger Agreement with Oclaro. On December 10, 2018, we completed the merger. In accordance with the terms of the Merger Agreement, each issued and outstanding share of Oclaro common stock was automatically converted into the right to receive (i) $5.60 in cash and (ii) 0.0636 of a share of Lumentum common stock. The total transaction consideration was $1.4 billion, funded through a combination of the issuance of Lumentum common stock, new debt obtained through a Credit Agreement with Deutsche Bank, and cash balances of the combined company.

[0001633978-19-000002:mdna:137]
54
