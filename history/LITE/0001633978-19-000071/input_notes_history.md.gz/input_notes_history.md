# LITE note change history — 0001633978-19-000030 → 0001633978-19-000071


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2019-10-31):
[0001633978-19-000071:note_history:1]
In February 2017, we incurred liabilities in the amount of $3.6 million related to an acquisition of a privately held company (based on the exchange rate at the date of acquisition). The purchase price retainer for the seller’s indemnification obligations was paid to the seller in fiscal 2019, and the contingent liability of $3.0 million (actual payment is subject to the then applicable exchange rate) is expected to be paid within the next 12 months contingent upon meeting certain production targets. We estimated the fair value of the contingent consideration to be $3.0 million and recorded this amount in other current liabilities within our condensed consolidated balance sheet as of September 28, 2019.

- changed (2019-10-31):
[0001633978-19-000071:note_history:2]
The estimated future interest and principal payments related to the term loan are as follows as of September 28, 2019 (in millions):
  (was, 2019-05-07, similarity 0.8983):
[0001633978-19-000030:note_history:2]
The estimated future interest and principal payments related to the term loan are as follows as of March 30, 2019:

- changed (2019-10-31):
[0001633978-19-000071:note_history:3]
The future interest and principal payments related to the 2024 Notes are as follows as of September 28, 2019 (in millions):
  (was, 2019-05-07, similarity 0.8868):
[0001633978-19-000030:note_history:3]
The future interest and principal payments related to the 2024 Notes are as follows as of March 30, 2019:

- changed (2019-10-31):
[0001633978-19-000071:note_history:4]
| Fiscal Years |  |
| Remainder of 2020 | $ | 0.5 |  |
| 2021 | 1.1 |  |
| 2022 | 1.1 |  |
| 2023 | 1.1 |  |
| 2024 | 451.2 |  |
| Thereafter | — |  |
| Total 2024 Notes payments | $ | 455.0 |  |
  (was, 2019-05-07, similarity 0.9869):
[0001633978-19-000030:note_history:4]
| Fiscal Years |  |
| Remainder of 2019 | $ | — |  |
| 2020 | 1.1 |  |
| 2021 | 1.1 |  |
| 2022 | 1.1 |  |
| 2023 | 1.1 |  |
| Thereafter | 451.2 |  |
| Total 2024 Notes payments | $ | 455.6 |  |

- changed (2019-10-31):
[0001633978-19-000071:note_history:5]
Purchase obligations of $277.6 million as of September 28, 2019, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements.
  (was, 2019-05-07, similarity 0.966):
[0001633978-19-000030:note_history:5]
Purchase obligations of $208.0 million as of March 30, 2019, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements.

- changed (2019-10-31):
[0001633978-19-000071:note_history:6]
The following table presents the changes in our warranty reserve during the three months ended September 28, 2019 and September 29, 2018 (in millions):
  (was, 2019-05-07, similarity 0.8975):
[0001633978-19-000030:note_history:6]
The following table presents the changes in our warranty reserve during the three and nine months ended March 30, 2019 and March 31, 2018 (in millions):

- added (2019-10-31):
[0001633978-19-000071:note_history:7]
|  | Three Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |
| Balance as of beginning of period | $ | 7.5 |  |  | $ | 6.6 |  |
| Provision for warranty | 1.2 |  |  | 1.2 |  |
| Utilization of reserve | (1.7 | ) |  | (1.2 | ) |
| Balance as of end of period | $ | 7.0 |  |  | $ | 6.6 |  |

- changed (2019-10-31):
[0001633978-19-000071:note_history:8]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss. As of September 28, 2019, we did not have any material claims or proceedings that were probable or reasonably possible.
  (was, 2019-05-07, similarity 0.8726):
[0001633978-19-000030:note_history:8]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss. As of March 30, 2019, we did not have any material claims or proceedings that were probable or reasonably possible.

- changed (2019-10-31):
[0001633978-19-000071:note_history:9]
In connection with our acquisition of Oclaro, seven lawsuits were filed by purported stockholders of Oclaro challenging the proposed merger (the “Merger”). Two of the seven suits were putative class actions filed against Oclaro, its directors, Lumentum, Prota Merger Sub, Inc. and Prota Merger, LLC: Nicholas Neinast v. Oclaro, Inc., et al., No. 3:18-cv-03112-VC, in the United States District Court for the Northern District of California (filed May 24, 2018) (the “Neinast Lawsuit”); and Adam Franchi v. Oclaro, Inc., et al., No. 1:18-cv-00817-GMS, in the United States District Court for the District of Delaware (filed June 9, 2018) (the “Franchi Lawsuit”). Both the Neinstat Lawsuit and the Franchi Lawsuit were voluntarily dismissed with prejudice.
  (was, 2019-05-07, similarity 0.9993):
[0001633978-19-000030:note_history:9]
In connection with our acquisition of Oclaro, seven lawsuits were filed by purported stockholders of Oclaro challenging the proposed merger (the “Merger”). Two of the seven suits were putative class actions filed against Oclaro, its directors, Lumentum, Prota Merger Sub, Inc. and Prota Merger, LLC: Nicholas Neinast v. Oclaro, Inc., et al., No. 3:18-cv-03112-VC, in the United States District Court for the Northern District of California (filed May 24, 2018) (the “Neinast Lawsuit”); and Adam Franchi v. Oclaro, Inc., et al., No. 1:18-cv-00817-GMS, in the United States District Court for the District of Delaware (filed June 9, 2018) (the “Franchi Lawsuit). Both the Neinstat Lawsuit and the Franchi Lawsuit were voluntarily dismissed with prejudice.

- added (2019-10-31):
[0001633978-19-000071:note_history:10]
The remaining Lawsuit (the Karri Lawsuit) currently purports to seek, among other things, damages to be awarded to the plaintiff and any class, if a class is certified, and litigation costs, including attorneys’ fees.  A lead plaintiff and counsel has been selected, and an amended complaint was filed on April 15, 2019, which also names Lumentum as a defendant.  A motion to dismiss the amended complaint has been filed and is currently pending, and defendants intend to defend the Karri Lawsuit vigorously.

- changed (2019-10-31):
[0001633978-19-000071:note_history:11]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of September 28, 2019, we did not have any material indemnification claims that were probable or reasonably possible.
  (was, 2019-05-07, similarity 0.793):
[0001633978-19-000030:note_history:11]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of March 30, 2019, we did not have any material indemnification claims that were probable or reasonably possible.

- changed (2019-10-31):
[0001633978-19-000071:note_history:12]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.
In connection with our acquisition of Oclaro, we recorded $1.1 million in Malaysia Goods and Services Tax (“GST”) refund claims within prepaid expenses and other current assets in our condensed consolidated balance sheet. The refund claim represents an initial claim of $2.5 million of GST, net of reserves, that were previously denied by the Malaysian tax authorities in 2016. During the three months ended September 28, 2019, we were able to favorably resolve this audit and we received refunds for the majority of our outstanding GST claims, with the remaining amounts expected to be received in our second quarter of fiscal 2020.
  (was, 2019-05-07, similarity 0.7504):
[0001633978-19-000030:note_history:12]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.

- removed (2019-10-31):
[0001633978-19-000030:note_history:13]
Operating Leases

- removed (2019-10-31):
[0001633978-19-000030:note_history:14]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2033. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. As a result of our acquisition of Oclaro on December 10, 2018, we assumed operating leases with future minimum annual lease payments of $83.2 million as of March 30, 2019.

- removed (2019-10-31):
[0001633978-19-000030:note_history:15]
As of March 30, 2019, the total future minimum annual lease payments under non-cancellable operating leases were as follows (in millions):

- removed (2019-10-31):
[0001633978-19-000030:note_history:16]
| Fiscal Years |  |
| Remainder of 2019 | $ | 5.2 |  |
| 2020 | 18.0 |  |
| 2021 | 15.2 |  |
| 2022 | 14.1 |  |
| 2023 | 12.8 |  |
| Thereafter | 39.9 |  |
| Total minimum operating lease payments | $ | 105.2 |  |

- removed (2019-10-31):
[0001633978-19-000030:note_history:17]
During the three and nine months ended March 30, 2019, rental expense relating to building and equipment was $5.2 million and $11.2 million, respectively. During the three and nine months ended March 31, 2018, rental expense relating to building and equipment was $2.8 million and $9.2 million, respectively.

- removed (2019-10-31):
[0001633978-19-000030:note_history:18]
Capital Leases

- removed (2019-10-31):
[0001633978-19-000030:note_history:19]
As of March 30, 2019, equipment acquired under capital lease agreements, including those assumed as part of the Oclaro acquisition, was $16.4 million. Our capital lease assets are included in property, plant and equipment, net in our condensed consolidated balance sheets as of March 30, 2019. Amortization expense on these capital lease assets are recorded as depreciation expense and is included in cost of sales in our condensed consolidated statements of operations for the three and nine months ended March 30, 2019 and March 31, 2018. Our capital lease obligations are recorded at the lesser of the estimated fair market value of the leased property or the net present value of the aggregate future minimum lease payments and is included in other current liabilities and other non-current liabilities in our condensed consolidated balance sheets as of March 30, 2019. Refer to “Note 9. Balance Sheet Details” for capital lease obligation amounts in other current liabilities and other non-current liabilities. Interest on these obligations is included in interest expense in our condensed consolidated statements of operations.

- removed (2019-10-31):
[0001633978-19-000030:note_history:20]
As of March 30, 2019 the future minimum annual lease payments under our capital leases were as follows (in millions):

- removed (2019-10-31):
[0001633978-19-000030:note_history:21]
| Fiscal Years |  |
| Remainder of 2019 | $ | 2.7 |  |
| 2020 | 0.5 |  |
| 2021 | 0.1 |  |
| Total minimum capital lease payments | $ | 3.3 |  |
| Less: amount representing interest | $ | (0.1 | ) |
| Present value of capital lease obligation | $ | 3.2 |  |

- removed (2019-10-31):
[0001633978-19-000030:note_history:22]
In February 2017, we incurred liabilities in the amount of $3.6 million related to an acquisition of a privately held company. The amount of up to $3.0 million is expected to be paid within the following 12 months contingent upon meeting certain production targets, and is included in other current liabilities on our consolidated balance sheet as of March 30, 2019.

- removed (2019-10-31):
[0001633978-19-000030:note_history:23]
We also retained $1.0 million of the purchase price as security for any potential liabilities of the seller under the representations, warranties and indemnifications included in the purchase agreement. The $1.0 million was fully paid to the seller during the nine months ended March 30, 2019.

- removed (2019-10-31):
[0001633978-19-000030:note_history:24]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Balance as of beginning of period | $ | 9.7 |  |  | $ | 9.9 |  |  | $ | 6.6 |  |  | $ | 9.7 |  |
| Warranties assumed in Oclaro acquisition | — |  |  | — |  |  | 3.8 |  |  | — |  |
| Provision for warranty | 1.5 |  |  | 2.0 |  |  | 3.4 |  |  | 4.9 |  |
| Utilization of reserve | (1.4 | ) |  | (4.9 | ) |  | (4.0 | ) |  | (7.6 | ) |
| Balance as of end of period | $ | 9.8 |  |  | $ | 7.0 |  |  | $ | 9.8 |  |  | $ | 7.0 |  |

- removed (2019-10-31):
[0001633978-19-000030:note_history:25]
The remaining Lawsuit (the Karri Lawsuit) currently purports to seek, among other things, damages to be awarded to the plaintiff and any class if the Merger is consummated, and litigation costs, including attorneys’ fees. The defendants intend to defend the Karri Lawsuit vigorously.

- removed (2019-10-31):
[0001633978-19-000030:note_history:26]
In connection with our acquisition of Oclaro, we recorded $1.1 million in Malaysia Goods and Services Tax (“GST”) refund claims within prepaid expenses and other current assets in our condensed consolidated balance sheet at March 30, 2019. The refund claim represents an initial claim of $2.5 million of GST, net of reserves, that were previously denied by the Malaysian tax authorities in 2016. We are currently appealing the denial of these claims, and believe that additional options may be available to us if we do not obtain a favorable resolution. Although we have taken action to minimize the impact of the GST with respect to our ongoing operations, we believe it is reasonably possible that, ultimately, we may not be able to recover some of these GST amounts.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-10-31):
[0001633978-19-000071:note_history:27]
Lumentum (“we,” “us,” “our” or the “Company”) is an industry-leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including Optical Communications (“OpComms”) and Lasers for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be Original Equipment Manufacturers (“OEMs”) that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that Network Equipment Manufacturers’ (“NEMs”) customers assemble into communications networking systems, which they sell to network service providers or enterprises with their own networks. Similarly, many of our customers for our Lasers products incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For 3D sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, and gaming who then integrate our devices within their products, for eventual resale to consumers and also into other industrial applications. Further, we are starting to sell diode lasers and optical subassemblies containing diode lasers and other optical devices to automotive customers for sensing and LiDAR applications.
  (was, 2019-05-07, similarity 0.9427):
[0001633978-19-000030:note_history:27]
Lumentum (“we,” “us,” “our” or the “Company”) is an industry-leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including Optical Communications (“OpComms”) and Lasers for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be Original Equipment Manufacturers (“OEMs”) that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that Network Equipment Manufacturers’ (“NEMs”) customers assemble into communications networking systems, which they sell to network service providers or enterprises with their own networks. Similarly, many of our customers for our Lasers products incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For 3D sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, and gaming who then integrate our devices within their products, for eventual resale to consumers and also into other industrial applications.

- changed (2019-10-31):
[0001633978-19-000071:note_history:28]
The preparation of the condensed consolidated financial statements in accordance with U.S. generally accepted accounting principles (“GAAP”) requires management to make estimates and assumptions that affect the amounts reported in our condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are inventory valuation, revenue recognition, income taxes, long-lived asset valuation, business combinations and goodwill.
  (was, 2019-05-07, similarity 0.9501):
[0001633978-19-000030:note_history:28]
The preparation of the condensed consolidated financial statements in accordance with U.S. generally accepted accounting principles (“GAAP”) requires management to make estimates and assumptions that affect the amounts reported in our condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are inventory valuation, revenue recognition, income taxes, long-lived asset valuation, warranty, derivative liability, business combinations and goodwill.

- changed (2019-10-31):
[0001633978-19-000071:note_history:29]
On December 10, 2018, we completed our merger with Oclaro, Inc. (“Oclaro”), a provider of optical components and modules for the long-haul, metro and data center markets. Our condensed consolidated financial statements include the operating results of Oclaro beginning from the date of acquisition. Refer to “Note 4. Business Combinations” for further discussion of the merger.
  (was, 2019-05-07, similarity 0.6234):
[0001633978-19-000030:note_history:29]
On December 10, 2018, the Company completed its merger with Oclaro, Inc. (“Oclaro”), a provider of optical components and modules for the long-haul, metro and data center markets. Our condensed consolidated financial statements include the operating results of Oclaro for the period from the date of acquisition through March 30, 2019. Refer to “Note 5. Business Combination” for further discussion of the merger.

- added (2019-10-31):
[0001633978-19-000071:note_history:30]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Our fiscal 2020 is a 52-week year ending on June 27, 2020, with the quarter ended September 28, 2019 being a 13-week quarterly period. Our fiscal 2019 was a 52-week year that ended on June 29, 2019, with the quarter ended September 29, 2018 being a 13-week quarterly period.

- added (2019-10-31):
[0001633978-19-000071:note_history:31]
Certain prior period amounts have been reclassified to conform to the current period presentation, including the reclassification of capital lease obligations that existed as of June 29, 2019 to finance lease liabilities within other current liabilities and other non-current liabilities in our condensed consolidated balance sheets, as a result of the adoption of the new accounting guidance for leases. Refer to “Note 2. Recently Issued Accounting Pronouncements” for details. The reclassification of the prior period amounts did not impact previously reported condensed consolidated financial statements.

- added (2019-10-31):
[0001633978-19-000071:note_history:32]
Except for the accounting policies for lease accounting as a result of the adoption of Accounting Standards Update (“ASU”) 2016-02, Leases (Topic 842), there have been no significant changes to our significant accounting policies as of and for the three

- added (2019-10-31):
[0001633978-19-000071:note_history:33]
months ended September 28, 2019, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the year ended June 29, 2019.

- changed (2019-10-31):
[0001633978-19-000071:note_history:34]
Adoption of Leases (Topic 842)
  (was, 2019-05-07, similarity 0.8085):
[0001633978-19-000030:note_history:34]
Adoption of Topic 606

- added (2019-10-31):
[0001633978-19-000071:note_history:35]
On June 30, 2019, we adopted Topic 842, using the modified retrospective transition approach. Refer to “Note 2. Recently Issued Accounting Pronouncements” regarding the impact of adoption.

- added (2019-10-31):
[0001633978-19-000071:note_history:36]
We determine if an arrangement is a lease at inception for arrangements with an initial term of more than 12 months, and classify it as either finance or operating.

- added (2019-10-31):
[0001633978-19-000071:note_history:37]
Finance leases are generally those that allow us to substantially utilize or pay for the entire asset over its estimated useful life. Finance leases are recorded in property, plant and equipment, net, and finance lease liabilities within other current and other non-current liabilities on our condensed consolidated balance sheets. We have lease arrangements with lease and non-lease components, and the non-lease components for our finance leases are accounted for separately, based on estimated stand-alone values, and are not included in the initial measurement of our finance lease assets and corresponding liabilities. Finance lease assets are amortized in operating expenses on a straight-line basis over the shorter of the estimated useful lives of the assets or the lease term, with the interest component included in interest expense and recognized using the effective interest method over the lease term.

- added (2019-10-31):
[0001633978-19-000071:note_history:38]
Operating leases are recorded in operating lease right-of-use assets, net, and operating lease liabilities, current and non-current on our condensed consolidated balance sheets. For operating leases of buildings, we account for non-lease components, such as common area maintenance, as a component of the lease, and include it in the initial measurement of our operating lease assets and corresponding liabilities. Operating lease assets are amortized on a straight-line basis in operating expenses over the lease term.

- added (2019-10-31):
[0001633978-19-000071:note_history:39]
Our lease liabilities are recognized based on the present value of the remaining fixed lease payments, over the lease term, using a discount rate of similarly secured borrowings available to us. For the purpose of lease liability measurement, we consider only payments that are fixed and determinable at the time of commencement. Any variable payments that depend on an index or rate are expensed as incurred. Our lease terms may include options to extend when it is reasonably certain that we will exercise that option. Our lease assets also include any lease payments made and exclude any lease incentives received prior to commencement. Our lease assets are tested for impairment in the same manner as long-lived assets used in operations. We generally recognize sublease income on a straight-line basis over the sublease term.

- removed (2019-10-31):
[0001633978-19-000030:note_history:40]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Our fiscal 2019 is a 52-week year ending on June 29, 2019, with the quarter ended March 30, 2019 being a 13-week quarterly period. Our fiscal 2018 was a 52-week year that ended on June 30, 2018, with the quarter ended March 31, 2018 being a 13-week quarterly period.

- removed (2019-10-31):
[0001633978-19-000030:note_history:41]
Certain  prior  period  amounts  have  been  reclassified  to  conform  to  the  current  year  presentation  in  the  notes  to  the  condensed  consolidated  financial statements.  The  reclassification  of  the  prior  period  amounts  did  not  impact  previously  reported  condensed  consolidated  financial  statements.

- removed (2019-10-31):
[0001633978-19-000030:note_history:42]
Except for the accounting policies for (i) revenue recognition and the adoption of Accounting Standards Update (“ASU”) 2014-09, Revenue from Contracts with Customers (Topic 606), and (ii) the change in our functional currency, from certain foreign currencies to the reporting currency, there have been no significant changes to our significant accounting policies as of and for the nine months ended March 30, 2019, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the year ended June 30, 2018.

- removed (2019-10-31):
[0001633978-19-000030:note_history:43]
Revenue Recognition Policy

- removed (2019-10-31):
[0001633978-19-000030:note_history:44]
Pursuant to Topic 606, our revenues are recognized upon the application of the following steps:

- removed (2019-10-31):
[0001633978-19-000030:note_history:45]
| • | identification of the contract, or contracts, with a customer; |

- removed (2019-10-31):
[0001633978-19-000030:note_history:46]
| • | identification of the performance obligations in the contract; |

- removed (2019-10-31):
[0001633978-19-000030:note_history:47]
| • | determination of the transaction price; |

- removed (2019-10-31):
[0001633978-19-000030:note_history:48]
| • | allocation of the transaction price to the performance obligations in the contract; and |

- removed (2019-10-31):
[0001633978-19-000030:note_history:49]
| • | recognition of revenues when, or as, the contractual performance obligations are satisfied. |

- removed (2019-10-31):
[0001633978-19-000030:note_history:50]
The majority of our revenue comes from product sales, consisting of sales of Lasers and OpComms hardware products to our customers. Our revenue contracts generally include only one performance obligation. Revenues are recognized at a point in time when control of the promised goods or services are transferred to our customers upon shipment or delivery, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services. We have entered into vendor managed inventory (“VMI”) programs with our customers. Under these arrangements, we receive purchase orders from our customers, and the inventory is shipped to the VMI location upon receipt of the purchase order. The customer then pulls the inventory from the VMI hub based on its production needs. Revenue under VMI programs is recognized when control transfers to the customer, which is generally once the customer pulls the inventory from the hub.

- removed (2019-10-31):
[0001633978-19-000030:note_history:51]
Revenue from all sales types is recognized at the transaction price. The transaction price is determined based on the consideration to which we will be entitled in exchange for transferring goods or services to the customer adjusted for estimated variable consideration, if any. We typically estimate the impact on the transaction price for discounts offered to the customers for early payments on receivables or net of accruals for estimated sales returns. These estimates are based on historical returns, analysis of credit memo data and other known factors. Actual returns could differ from these estimates. We allocate the transaction price to each distinct product based on its relative standalone selling price. The product price as specified on the purchase order is considered the standalone selling price as it is an observable input that depicts the price as if sold to a similar customer in similar circumstances.

- removed (2019-10-31):
[0001633978-19-000030:note_history:52]
Taxes assessed by a governmental authority that are both imposed on and concurrent with a specific revenue-producing transaction, that are collected by us from a customer and deposited with the relevant government authority, are excluded from revenue. Our revenue arrangements do not contain significant financing components as our standard payment terms are less than one year.

- removed (2019-10-31):
[0001633978-19-000030:note_history:53]
If a customer pays consideration, or the Company has a right to an amount of consideration that is unconditional before we transfer a good or service to the customer, those amounts are classified as deferred revenue or deposits received from customers which are included in other current liabilities or other long-term liabilities when the payment is made or it is due, whichever is earlier.

- removed (2019-10-31):
[0001633978-19-000030:note_history:54]
Transaction Price Allocated to the Remaining Performance Obligations

- removed (2019-10-31):
[0001633978-19-000030:note_history:55]
Remaining performance obligations represent the transaction price allocated to performances obligations that are unsatisfied or partially unsatisfied as of the end of the reporting period. Unsatisfied and partially unsatisfied performance obligations consist of contract liabilities and non-cancellable backlog. Non-cancellable backlog includes goods and services for which customer purchase orders have been accepted that are scheduled or in the process of being scheduled for shipment.

- removed (2019-10-31):
[0001633978-19-000030:note_history:56]
The following table includes estimated revenue expected to be recognized in the future for backlog related performance obligations that are unsatisfied as of March 30, 2019 (in millions):

- removed (2019-10-31):
[0001633978-19-000030:note_history:57]
|  | Less than 1 year | 1-2 years | Greater than 2 years | Total |
| Performance Obligations | $531.5 | $7.7 | $— | $539.2 |

- removed (2019-10-31):
[0001633978-19-000030:note_history:58]
Warranty

- removed (2019-10-31):
[0001633978-19-000030:note_history:59]
Hardware products regularly include warranties to the end customers such that the product continues to function according to published specifications. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, specific market, product line and geography in which we operate, and what is common in the industry, our warranties can vary and range from six months to five years. These standard warranties are assurance type warranties and do not offer any services in addition to the assurance that the product will continue working as specified. Therefore, warranties are not considered separate performance obligations in the arrangement. Instead, the expected cost of warranty is accrued as expense in accordance with authoritative guidance.

- removed (2019-10-31):
[0001633978-19-000030:note_history:60]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We estimate the costs of our warranty obligations based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise.

- removed (2019-10-31):
[0001633978-19-000030:note_history:61]
Shipping and Handling Costs

- removed (2019-10-31):
[0001633978-19-000030:note_history:62]
We record shipping and handling costs related to revenue transactions within cost of sales as a period cost.

- removed (2019-10-31):
[0001633978-19-000030:note_history:63]
Contract Costs

- removed (2019-10-31):
[0001633978-19-000030:note_history:64]
The Company recognizes the incremental direct costs of obtaining a contract, which consist of sales commissions, when control over the products they relate to transfers to the customer. Applying the practical expedient, the Company recognizes commissions as expense when incurred, as the amortization period of the commission asset the Company would have otherwise recognized is less than one year.

- removed (2019-10-31):
[0001633978-19-000030:note_history:65]
Contract Balances

- removed (2019-10-31):
[0001633978-19-000030:note_history:66]
The Company records accounts receivable when it has an unconditional right to consideration. Contract liabilities are recorded when cash payments are received or due in advance of performance. Contract liabilities consist of advance payments and deferred revenue, where the Company has unsatisfied performance obligations. Contract liabilities are classified as deferred revenue and customer deposits, and are included in other current liabilities within our condensed consolidated balance sheet. Payment terms vary by customer. The time between invoicing and when payment is due is not significant.

- removed (2019-10-31):
[0001633978-19-000030:note_history:67]
The following table reflects the changes in contract balances as of March 30, 2019 (in millions, except percentages):

- removed (2019-10-31):
[0001633978-19-000030:note_history:68]
| Contract balances | Balance sheet location | March 30, 2019 |  | June 30, 2018 |  | Change |  | Percentage Change |
| Accounts receivable, net | Accounts receivable, net | $302.9 |  | $197.1 |  | $105.8 |  | 53.7% |
| Deferred revenue and customer deposits | Other current liabilities | $4.2 |  | $2.8 |  | $1.4 |  | 50.0% |

- removed (2019-10-31):
[0001633978-19-000030:note_history:69]
Disaggregation of Revenue

- removed (2019-10-31):
[0001633978-19-000030:note_history:70]
We disaggregate revenue by geography and by product. Refer to “Note 19. Operating Segments and Geographic Information” for a presentation of disaggregated revenue. We do not present other levels of disaggregation, such as by type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, as this information is not used by our Chief Operating Decision Maker to manage the business.

- removed (2019-10-31):
[0001633978-19-000030:note_history:71]
Foreign Currency Translation

- removed (2019-10-31):
[0001633978-19-000030:note_history:72]
Concurrent with the acquisition of Oclaro, on December 10, 2018, we established the functional currency for our worldwide operations as the U.S. dollar. The change in our functional currency is a result of significant changes in economic facts and circumstances, primarily the acquisition of Oclaro, a U.S. dollar-denominated functional currency company. The combined business, which requires the integration of our supply chain, manufacturing operations and sales organization, will predominantly use the U.S. dollar, including when negotiating customer and major supplier contracts.

- removed (2019-10-31):
[0001633978-19-000030:note_history:73]
Translation adjustments reported prior to December 10, 2018, remain as a component of accumulated other comprehensive income in our condensed consolidated balance sheet. The translated values for any non-monetary assets and liabilities as of December 10, 2018 become the new accounting basis for those assets. Accordingly, monetary assets and liabilities denominated in foreign currencies have been remeasured into U.S. dollars using the exchange rates in effect at the balance sheet date. Foreign currency re-measurement gains (losses) are included in interest and other income (expense), net.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2019-10-31):
[0001633978-19-000071:note_history:74]
| Liability component: | September 28, 2019 |  | June 29, 2019 |
| Principal | $ | 450.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount | (93.5 | ) |  | (98.1 | ) |
| Net carrying amount of the liability component | $ | 356.5 |  |  | $ | 351.9 |  |

- removed (2019-10-31):
[0001633978-19-000030:note_history:75]
| Liability component: | March 30, 2019 |  | June 30, 2018 |
| Principal | $ | 450.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount | (102.6 | ) |  | (115.8 | ) |
| Net carrying amount of the liability component | $ | 347.4 |  |  | $ | 334.2 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-10-31):
[0001633978-19-000071:note_history:76]
Convertible Notes
  (was, 2019-05-07, similarity 0.8293):
[0001633978-19-000030:note_history:76]
Note 13. Convertible Notes

- changed (2019-10-31):
[0001633978-19-000071:note_history:77]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. We incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. We amortize the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes is 5.4% per year. As of September 28, 2019, the remaining debt discount amortization period was 53 months.
  (was, 2019-05-07, similarity 0.9525):
[0001633978-19-000030:note_history:77]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. We incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. We amortize the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes is 5.4% per year. As of March 30, 2019, the remaining debt discount amortization period was 59 months.

- changed (2019-10-31):
[0001633978-19-000071:note_history:78]
During the fiscal year ended July 1, 2017, we satisfied the TMA settlement condition. As such, the value of the conversion option will no longer be marked to market and was reclassified to additional paid-in capital within stockholders’ equity on our condensed consolidated balance sheet. The value of the conversion option at the time of issuance will be treated as an original issue discount for purposes of accounting for the debt component of the notes. The debt component will accrete up to the principal
  (was, 2019-05-07, similarity 0.7629):
[0001633978-19-000030:note_history:78]
During the year ended July 1, 2017, we satisfied the TMA settlement condition. As such, the value of the conversion option will no longer be marked to market and was reclassified to additional paid-in capital within stockholders’ equity on our condensed consolidated balance sheet. The value of the conversion option at the time of issuance will be treated as an original issue discount for purposes of accounting for the debt component of the notes. The debt component will accrete up to the principal amount over the expected term of the debt. These accounting standards do not affect the actual amount we are required to repay, and the amount shown in the table below for the notes is the aggregate principal amount of the notes and does not reflect the debt discount we will be required to recognize.

- added (2019-10-31):
[0001633978-19-000071:note_history:79]
amount over the expected term of the debt. These accounting standards do not affect the actual amount we are required to repay, and the amount shown in the table below for the notes is the aggregate principal amount of the notes and does not reflect the debt discount we will be required to recognize.

- added (2019-10-31):
[0001633978-19-000071:note_history:80]
| Liability component: | September 28, 2019 |  | June 29, 2019 |
| Principal | $ | 450.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount | (93.5 | ) |  | (98.1 | ) |
| Net carrying amount of the liability component | $ | 356.5 |  |  | $ | 351.9 |  |

- changed (2019-10-31):
[0001633978-19-000071:note_history:81]
|  | Three Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |
| Contractual interest expense | $ | 0.3 |  |  | $ | 0.3 |  |
| Amortization of the debt discount | 4.6 |  |  | 4.3 |  |
| Total interest expense | $ | 4.9 |  |  | $ | 4.6 |  |
| Effective interest rate on the liability component | 5.4 | % |  | 5.4 | % |
  (was, 2019-05-07, similarity 0.7401):
[0001633978-19-000030:note_history:81]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Contractual interest expense | $ | 0.3 |  |  | $ | 0.3 |  |  | $ | 0.9 |  |  | $ | 0.9 |  |
| Amortization of the debt discount | 4.5 |  |  | 4.2 |  |  | 13.2 |  |  | 12.4 |  |
| Total interest expense | $ | 4.8 |  |  | $ | 4.5 |  |  | $ | 14.1 |  |  | $ | 13.3 |  |
| Effective interest rate on the liability component | 5.4 | % |  | 5.4 | % |  | 5.4 | % |  | 5.4 | % |

- added (2019-10-31):
[0001633978-19-000071:note_history:82]
Term Loan Facility

- added (2019-10-31):
[0001633978-19-000071:note_history:83]
On March 11, 2018, in connection with the Oclaro merger, we entered into a commitment letter with Deutsche Bank Securities Inc. and Deutsche Bank AG New York Branch (“Deutsche Bank”), pursuant to which Deutsche Bank committed to provide a senior secured term loan facility to finance the merger.

- added (2019-10-31):
[0001633978-19-000071:note_history:84]
On December 10, 2018 (the “Closing Date”), concurrent with the closing of the Oclaro merger, we entered into a Credit and Guarantee Agreement (the “Credit Agreement”), by and among us, certain of our subsidiaries, the lenders party thereto, and Deutsche Bank, as administrative agent and collateral agent for the lenders. The Credit Agreement provides for a senior secured term loan facility (the “Term Loan Facility”) in an aggregate principal amount of $500.0 million. The term loans available under the Term Loan Facility were fully drawn on the Closing Date and the proceeds of the term loans were used to consummate the merger and pay fees and expenses in connection with the merger and the Term Loan Facility.

- added (2019-10-31):
[0001633978-19-000071:note_history:85]
The term loans will mature on the seventh anniversary of the Closing Date, at which time all outstanding principal and accrued and unpaid interest on the term loans must be repaid.  Commencing on the last business day of the first full fiscal quarter after the Closing Date, the term loans will amortize in equal quarterly installments equal to 0.25% of the original principal amount of the Term Loans, with the balance payable due on December 10, 2025, the maturity date. We are required to make mandatory prepayments of the outstanding principal amount of term loans with the net cash proceeds from the disposition of certain assets and the receipt of insurance proceeds upon certain casualty and condemnation events, in each case, to the extent in excess of the certain threshold amounts and to the extent not reinvested within a specified time period. We are also required to make mandatory prepayments of the outstanding principal amount of term loans from the incurrence of certain types of indebtedness and from any excess cash flow beyond stated threshold amounts. We have the right to prepay the term loans, in whole or in part, at any time without premium or penalty, subject to certain limitations and a 1.00% soft call premium applicable during the first six months following the Closing Date.

- added (2019-10-31):
[0001633978-19-000071:note_history:86]
The term loans bear interest at a rate equal to an applicable margin plus, at our option, either (a) a base rate equal to the highest of (i) the prime rate then in effect, (ii) the federal funds rate, plus 0.50% and (iii) an adjusted LIBOR rate determined on the basis of a one-month interest period, plus 1.0%, subject to a floor of 0.0%, or (b) an adjusted LIBOR rate, subject to a floor of 0.0%. The applicable margin with respect to the initial term loans is equal to 2.50% in the case of LIBOR rate loans and 1.50% in the case of base rate loans. The applicable margin is adjusted following the first full fiscal quarter after the Closing Date, if our

- added (2019-10-31):
[0001633978-19-000071:note_history:87]
first lien net leverage ratio is equal to or less than 0.50:1.00, to 2.25% in the case of LIBOR rate loans and 1.25% in the case of base rate loans. During the three months ended September 28, 2019, we recorded a contractual interest expense of $6.1 million related to the term loans, which is included in interest expense in our condensed consolidated statements of operations.

- added (2019-10-31):
[0001633978-19-000071:note_history:88]
The commitment letter with Deutsche Bank required payment of a ticking fee. During the three months ended September 29, 2018, we recorded total expenses in connection with the ticking fee of $0.4 million. This ticking fee expense was included in interest expense in our condensed consolidated statements of operations.

- added (2019-10-31):
[0001633978-19-000071:note_history:89]
The Credit Agreement permits us to add one or more incremental term loan facilities. Incremental loans are subject to certain additional conditions, including, without limitation, obtaining additional commitments from the lenders then party to the Credit Agreement or from new lenders.

- added (2019-10-31):
[0001633978-19-000071:note_history:90]
Our obligations under the Credit Agreement are required to be guaranteed by certain of our domestic subsidiaries meeting materiality thresholds set forth in the Credit Agreement. Such obligations, including the guaranties, are secured by substantially all of the assets of Lumentum and Lumentum’s subsidiary guarantors (other than customarily excluded assets) pursuant to a Pledge and Security Agreement, dated as of December 10, 2018, by and among Lumentum and Deutsche Bank.

- added (2019-10-31):
[0001633978-19-000071:note_history:91]
The Credit Agreement contains customary affirmative and negative covenants, including covenants limiting the ability of Lumentum and its restricted subsidiaries to, among other things, incur debt, grant liens, undergo certain fundamental changes, make investments, make certain restricted payments, dispose of assets, and enter into transactions with affiliates, in each case, subject to limitations and exceptions set forth in the Credit Agreement. The Credit Agreement also contains customary events of default that include, among other things, certain payment defaults, cross defaults to other indebtedness, covenant defaults, change of control defaults, judgment defaults, and bankruptcy and insolvency defaults. If an event of default exists, the lenders may require the immediate payment of all obligations under the Credit Agreement, and may exercise certain other rights and remedies provided for under the Credit Agreement, the other loan documents and applicable law. As of September 28, 2019, we were in compliance with all of the covenants.

- added (2019-10-31):
[0001633978-19-000071:note_history:92]
We incurred $9.3 million of debt issuance costs in connection with the Term Loan Facility which were capitalized and recorded as a contra liability in our condensed consolidated balance sheet. These costs will be amortized to interest expense using the effective interest rate method from the issuance date of December 10, 2018, through the end of the term of the loan. As of September 28, 2019, the effective interest rate was 4.88% and the stated interest rate was 4.61%.

- added (2019-10-31):
[0001633978-19-000071:note_history:93]
The following table sets forth balance sheet information related to the term loan as of the periods presented (in millions):

- added (2019-10-31):
[0001633978-19-000071:note_history:94]
|  | September 28, 2019 |  | June 29, 2019 |
| Principal | $ | 497.5 |  |  | $ | 500.0 |  |
| Repayment of principal | — |  |  | (2.5 | ) |
| Unamortized value of the debt issuance costs | (8.2 | ) |  | (8.5 | ) |
| Net carrying value | $ | 489.3 |  |  | $ | 489.0 |  |
| Term loan, current | $ | 6.2 |  |  | $ | 5.0 |  |
| Term loan, non-current | $ | 483.1 |  |  | $ | 484.0 |  |

- added (2019-10-31):
[0001633978-19-000071:note_history:95]
The following table sets forth interest expense information related to the term loan, including interest expense associated with the ticking fee, for the periods presented (in millions):

- added (2019-10-31):
[0001633978-19-000071:note_history:96]
|  | Three Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |
| Contractual interest expense | $ | 6.1 |  |  | $ | 0.4 |  |
| Amortization of the debt issuance costs | 0.3 |  |  | — |  |
| Total interest expense | $ | 6.4 |  |  | $ | 0.4 |  |

- removed (2019-10-31):
[0001633978-19-000030:note_history:97]
| Liability component: | March 30, 2019 |  | June 30, 2018 |
| Principal | $ | 450.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount | (102.6 | ) |  | (115.8 | ) |
| Net carrying amount of the liability component | $ | 347.4 |  |  | $ | 334.2 |  |


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-10-31):
[0001633978-19-000071:note_history:98]
|  | Less than 12 months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| September 28, 2019: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper | $ | 3.8 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 3.8 |  |  | $ | — |  |
| Asset-backed securities | 0.7 |  |  | — |  |  | 2.1 |  |  | — |  |  | 2.8 |  |  | — |  |
| Corporate debt securities | 5.2 |  |  | — |  |  | 6.9 |  |  | — |  |  | 12.1 |  |  | — |  |
| Foreign government bonds | — |  |  | — |  |  | 2.2 |  |  | — |  |  | 2.2 |  |  | — |  |
| U.S. government bonds | 6.9 |  |  | — |  |  | — |  |  | — |  |  | 6.9 |  |  | — |  |
| Total | $ | 16.6 |  |  | $ | — |  |  | $ | 11.2 |  |  | $ | — |  |  | $ | 27.8 |  |  | $ | — |  |
| June 29, 2019: |  |  |  |  |  |  |  |  |  |  |  |
| Asset-backed securities | $ | 4.2 |  |  | $ | — |  |  | $ | 5.9 |  |  | $ | — |  |  | $ | 10.1 |  |  | $ | — |  |
| Corporate debt securities | 9.6 |  |  | — |  |  | 35.9 |  |  | (0.1 | ) |  | 45.5 |  |  | (0.1 | ) |
| Foreign government bonds | — |  |  | — |  |  | 2.1 |  |  | — |  |  | 2.1 |  |  | — |  |
| U.S. government bonds | 6.9 |  |  | — |  |  | — |  |  | — |  |  | 6.9 |  |  | — |  |
| Total | $ | 20.7 |  |  | $ | — |  |  | $ | 43.9 |  |  | $ | (0.1 | ) |  | $ | 64.6 |  |  | $ | (0.1 | ) |
  (was, 2019-05-07, similarity 0.6452):
[0001633978-19-000030:note_history:98]
|  | Less than 12 months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| March 30, 2019: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper | $ | 5.9 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 5.9 |  |  | $ | — |  |
| Asset-backed securities | 13.1 |  |  | — |  |  | 15.9 |  |  | — |  |  | 29.0 |  |  | — |  |
| Corporate debt securities | 15.4 |  |  | (0.1 | ) |  | 84.8 |  |  | (0.2 | ) |  | 100.2 |  |  | (0.3 | ) |
| Foreign government bonds | 1.7 |  |  | — |  |  | 2.1 |  |  | — |  |  | 3.8 |  |  | — |  |
| U.S. government bonds | 14.8 |  |  | — |  |  | — |  |  | — |  |  | 14.8 |  |  | — |  |
| Total | $ | 50.9 |  |  | $ | (0.1 | ) |  | $ | 102.8 |  |  | $ | (0.2 | ) |  | $ | 153.7 |  |  | $ | (0.3 | ) |
| June 30, 2018: |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |  | $ | — |  |
| Commercial paper | 8.5 |  |  | — |  |  | — |  |  | — |  |  | 8.5 |  |  | — |  |
| Asset-backed securities | 66.6 |  |  | (0.2 | ) |  | 0.3 |  |  | — |  |  | 66.9 |  |  | (0.2 | ) |
| Corporate debt securities | 188.6 |  |  | (1.5 | ) |  | 2.0 |  |  | — |  |  | 190.6 |  |  | (1.5 | ) |
| Municipal bonds | 0.6 |  |  | — |  |  | — |  |  | — |  |  | 0.6 |  |  | — |  |
| U.S. Agency securities | 4.0 |  |  | — |  |  | — |  |  | — |  |  | 4.0 |  |  | — |  |
| Foreign government bonds | 3.4 |  |  | — |  |  | — |  |  | — |  |  | 3.4 |  |  | — |  |
| Total | $ | 277.1 |  |  | $ | (1.7 | ) |  | $ | 2.3 |  |  | $ | — |  |  | $ | 279.4 |  |  | $ | (1.7 | ) |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2019-10-31):
[0001633978-19-000030:note_history:99]
Note 7. Term Loan Facility

- removed (2019-10-31):
[0001633978-19-000030:note_history:100]
On March 11, 2018, in connection with the Oclaro merger, Lumentum entered into a commitment letter with Deutsche Bank Securities Inc. and Deutsche Bank AG New York Branch (“Deutsche Bank”), pursuant to which, Deutsche Bank committed to provide a senior secured term loan facility to finance the merger.

- removed (2019-10-31):
[0001633978-19-000030:note_history:101]
On December 10, 2018 (the “Closing Date”), concurrent with the closing of the Oclaro merger, Lumentum entered into a Credit and Guarantee Agreement (the “Credit Agreement”), by and among Lumentum, certain subsidiaries of Lumentum, the lenders party thereto, and Deutsche Bank, as administrative agent and collateral agent for the lenders. The Credit Agreement provides for a senior secured term loan facility (the “Term Loan Facility”) in an aggregate principal amount of $500.0 million. The term loans available under the Term Loan Facility were fully drawn on the Closing Date and the proceeds of the term loans were used to consummate the merger and pay fees and expenses in connection with the merger and the Term Loan Facility.

- removed (2019-10-31):
[0001633978-19-000030:note_history:102]
The term loans will mature on the seventh anniversary of the Closing Date, at which time all outstanding principal and accrued and unpaid interest on the term loans must be repaid.  Commencing on the last business day of the first full fiscal quarter after the Closing Date, the term loans will amortize in equal quarterly installments equal to 0.25% of the original principal amount of the Term Loans, with the balance payable due on December 10, 2025, the maturity date. We are required to make mandatory prepayments of the outstanding principal amount of term loans with the net cash proceeds from the disposition of certain assets and the receipt of insurance proceeds upon certain casualty and condemnation events, in each case, to the extent in excess of the certain threshold amounts and to the extent not reinvested within a specified time period. We are also required to make mandatory prepayments of the outstanding principal amount of term loans from the incurrence of certain types of indebtedness and from any excess cash flow beyond stated threshold amounts. We have the right to prepay the term loans, in whole or in part, at any time without premium or penalty, subject to certain limitations and a 1.00% soft call premium applicable during the first six months following the Closing Date.

- removed (2019-10-31):
[0001633978-19-000030:note_history:103]
The term loans bear interest at a rate equal to an applicable margin plus, at our option, either (a) a base rate equal to the highest of (i) the prime rate then in effect, (ii) the federal funds rate, plus 0.50% and (iii) an adjusted LIBOR rate determined on the basis of a one-month interest period, plus 1.0%, subject to a floor of 0.0%, or (b) an adjusted LIBOR rate, subject to a floor of 0.0%. The applicable margin with respect to the initial term loans is equal to 2.50% in the case of LIBOR rate loans and 1.50% in the case of base rate loans. The applicable margin is adjusted following the first full fiscal quarter after the Closing Date, if our first lien net leverage ratio is equal to or less than 0.50:1.00, to 2.25% in the case of LIBOR rate loans and 1.25% in the case of base rate loans. During the three and nine months ended March 30, 2019, we recorded interest expense of $6.5 million and $8.0 million respectively related to the initial term loans, which is included in interest and other income (expense), net in our condensed consolidated statements of operations.

- removed (2019-10-31):
[0001633978-19-000030:note_history:104]
The commitment letter with Deutsche Bank required payment of a ticking fee. During the three and nine months ended March 30, 2019, we recorded total expenses in connection with the ticking fee of zero and $2.7 million, respectively. This ticking fee expense is included in interest and other income (expense), net in our condensed consolidated statements of operations. During the three and nine months ended March 30, 2019 we paid $1.3 million of principal on the term loan.

- removed (2019-10-31):
[0001633978-19-000030:note_history:105]
The Credit Agreement permits us to add one or more incremental term loan facilities. Incremental loans are subject to certain additional conditions, including, without limitation, obtaining additional commitments from the lenders then party to the Credit Agreement or from new lenders.

- removed (2019-10-31):
[0001633978-19-000030:note_history:106]
Our obligations under the Credit Agreement are required to be guaranteed by certain of our domestic subsidiaries meeting materiality thresholds set forth in the Credit Agreement. Such obligations, including the guaranties, are secured by substantially all of the assets of Lumentum and Lumentum’s subsidiary guarantors (other than customarily excluded assets) pursuant to a Pledge and Security Agreement, dated as of December 10, 2018, by and among Lumentum and Deutsche Bank.

- removed (2019-10-31):
[0001633978-19-000030:note_history:107]
The Credit Agreement contains customary affirmative and negative covenants, including covenants limiting the ability of Lumentum and its restricted subsidiaries to, among other things, incur debt, grant liens, undergo certain fundamental changes, make investments, make certain restricted payments, dispose of assets, and enter into transactions with affiliates, in each case, subject to limitations and exceptions set forth in the Credit Agreement. The Credit Agreement also contains customary events of default that include, among other things, certain payment defaults, cross defaults to other indebtedness, covenant defaults, change of control defaults, judgment defaults, and bankruptcy and insolvency defaults. If an event of default exists, the lenders may require the immediate payment of all obligations under the Credit Agreement, and may exercise certain other rights and remedies provided for under the Credit Agreement, the other loan documents and applicable law. As of March 30, 2019, we were in compliance with all of the covenants.

- removed (2019-10-31):
[0001633978-19-000030:note_history:108]
We incurred $9.3 million of debt issuance costs in connection with the Term Loan Facility which were capitalized and recorded as a contra liability in our condensed consolidated balance sheet. These costs will be amortized to interest expense using the effective interest rate method from the issuance date of December 10, 2018, through the end of the term of the loan. As of March 30, 2019, the effective interest rate is 5.27% and the stated interest rate is 4.99%.

- removed (2019-10-31):
[0001633978-19-000030:note_history:109]
The following table sets forth balance sheet information related to the term loan at March 30, 2019 (in millions):

- removed (2019-10-31):
[0001633978-19-000030:note_history:110]
|  | March 30, 2019 |
| Principal | $ | 500.0 |  |
| Repayment of principal | (1.3 | ) |
| Unamortized value of the debt issuance costs | (8.8 | ) |
| Net carrying value | $ | 489.9 |  |
| Term loan, current | $ | 5.0 |  |
| Term loan, non-current | $ | 484.9 |  |

- removed (2019-10-31):
[0001633978-19-000030:note_history:111]
The following table sets forth interest expense information related to the term loan, including interest expense associated with the ticking fee, for the periods presented (in millions):

- removed (2019-10-31):
[0001633978-19-000030:note_history:112]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Contractual interest expense | $ | 6.2 |  |  | $ | — |  |  | $ | 10.2 |  |  | $ | — |  |
| Amortization of the debt issuance costs | 0.4 |  |  | — |  |  | 0.5 |  |  | — |  |
| Total interest expense | $ | 6.6 |  |  | $ | — |  |  | $ | 10.7 |  |  | $ | — |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-10-31):
[0001633978-19-000071:note_history:113]
The following table sets forth balance sheet information related to the term loan as of the periods presented (in millions)
  (was, 2019-05-07, similarity 0.8621):
[0001633978-19-000030:note_history:113]
The following table sets forth balance sheet information related to the term loan at March 30, 2019 (in millions):

- removed (2019-10-31):
[0001633978-19-000030:note_history:114]
|  | March 30, 2019 |
| Principal | $ | 500.0 |  |
| Repayment of principal | (1.3 | ) |
| Unamortized value of the debt issuance costs | (8.8 | ) |
| Net carrying value | $ | 489.9 |  |
| Term loan, current | $ | 5.0 |  |
| Term loan, non-current | $ | 484.9 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-10-31):
[0001633978-19-000071:note_history:115]
The future interest and principal payments related to the 2024 Notes are as follows as of September 28, 2019 (in millions):
  (was, 2019-05-07, similarity 0.8868):
[0001633978-19-000030:note_history:115]
The future interest and principal payments related to the 2024 Notes are as follows as of March 30, 2019:

- changed (2019-10-31):
[0001633978-19-000071:note_history:116]
| Fiscal Years |  |
| Remainder of 2020 | $ | 0.5 |  |
| 2021 | 1.1 |  |
| 2022 | 1.1 |  |
| 2023 | 1.1 |  |
| 2024 | 451.2 |  |
| Thereafter | — |  |
| Total 2024 Notes payments | $ | 455.0 |  |
  (was, 2019-05-07, similarity 0.9869):
[0001633978-19-000030:note_history:116]
| Fiscal Years |  |
| Remainder of 2019 | $ | — |  |
| 2020 | 1.1 |  |
| 2021 | 1.1 |  |
| 2022 | 1.1 |  |
| 2023 | 1.1 |  |
| Thereafter | 451.2 |  |
| Total 2024 Notes payments | $ | 455.6 |  |

- changed (2019-10-31):
[0001633978-19-000071:note_history:117]
The estimated future interest and principal payments related to the term loan are as follows as of September 28, 2019 (in millions):
  (was, 2019-05-07, similarity 0.8983):
[0001633978-19-000030:note_history:117]
The estimated future interest and principal payments related to the term loan are as follows as of March 30, 2019:


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: no_current_note, score: 0.0

- removed (2019-10-31):
[0001633978-19-000030:note_history:118]
Shipping and Handling Costs

- removed (2019-10-31):
[0001633978-19-000030:note_history:119]
We record shipping and handling costs related to revenue transactions within cost of sales as a period cost.

- removed (2019-10-31):
[0001633978-19-000030:note_history:120]
Contract Costs

- removed (2019-10-31):
[0001633978-19-000030:note_history:121]
The Company recognizes the incremental direct costs of obtaining a contract, which consist of sales commissions, when control over the products they relate to transfers to the customer. Applying the practical expedient, the Company recognizes commissions as expense when incurred, as the amortization period of the commission asset the Company would have otherwise recognized is less than one year.

- removed (2019-10-31):
[0001633978-19-000030:note_history:122]
Contract Balances

- removed (2019-10-31):
[0001633978-19-000030:note_history:123]
The Company records accounts receivable when it has an unconditional right to consideration. Contract liabilities are recorded when cash payments are received or due in advance of performance. Contract liabilities consist of advance payments and deferred revenue, where the Company has unsatisfied performance obligations. Contract liabilities are classified as deferred revenue and customer deposits, and are included in other current liabilities within our condensed consolidated balance sheet. Payment terms vary by customer. The time between invoicing and when payment is due is not significant.

- removed (2019-10-31):
[0001633978-19-000030:note_history:124]
Revenue Recognition Policy

- removed (2019-10-31):
[0001633978-19-000030:note_history:125]
Pursuant to Topic 606, our revenues are recognized upon the application of the following steps:

- removed (2019-10-31):
[0001633978-19-000030:note_history:126]
| • | identification of the contract, or contracts, with a customer; |

- removed (2019-10-31):
[0001633978-19-000030:note_history:127]
| • | identification of the performance obligations in the contract; |

- removed (2019-10-31):
[0001633978-19-000030:note_history:128]
| • | determination of the transaction price; |

- removed (2019-10-31):
[0001633978-19-000030:note_history:129]
| • | allocation of the transaction price to the performance obligations in the contract; and |

- removed (2019-10-31):
[0001633978-19-000030:note_history:130]
| • | recognition of revenues when, or as, the contractual performance obligations are satisfied. |

- removed (2019-10-31):
[0001633978-19-000030:note_history:131]
The majority of our revenue comes from product sales, consisting of sales of Lasers and OpComms hardware products to our customers. Our revenue contracts generally include only one performance obligation. Revenues are recognized at a point in time when control of the promised goods or services are transferred to our customers upon shipment or delivery, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services. We have entered into vendor managed inventory (“VMI”) programs with our customers. Under these arrangements, we receive purchase orders from our customers, and the inventory is shipped to the VMI location upon receipt of the purchase order. The customer then pulls the inventory from the VMI hub based on its production needs. Revenue under VMI programs is recognized when control transfers to the customer, which is generally once the customer pulls the inventory from the hub.

- removed (2019-10-31):
[0001633978-19-000030:note_history:132]
Revenue from all sales types is recognized at the transaction price. The transaction price is determined based on the consideration to which we will be entitled in exchange for transferring goods or services to the customer adjusted for estimated variable consideration, if any. We typically estimate the impact on the transaction price for discounts offered to the customers for early payments on receivables or net of accruals for estimated sales returns. These estimates are based on historical returns, analysis of credit memo data and other known factors. Actual returns could differ from these estimates. We allocate the transaction price to each distinct product based on its relative standalone selling price. The product price as specified on the purchase order is considered the standalone selling price as it is an observable input that depicts the price as if sold to a similar customer in similar circumstances.

- removed (2019-10-31):
[0001633978-19-000030:note_history:133]
Taxes assessed by a governmental authority that are both imposed on and concurrent with a specific revenue-producing transaction, that are collected by us from a customer and deposited with the relevant government authority, are excluded from revenue. Our revenue arrangements do not contain significant financing components as our standard payment terms are less than one year.

- removed (2019-10-31):
[0001633978-19-000030:note_history:134]
If a customer pays consideration, or the Company has a right to an amount of consideration that is unconditional before we transfer a good or service to the customer, those amounts are classified as deferred revenue or deposits received from customers which are included in other current liabilities or other long-term liabilities when the payment is made or it is due, whichever is earlier.

- removed (2019-10-31):
[0001633978-19-000030:note_history:135]
Transaction Price Allocated to the Remaining Performance Obligations

- removed (2019-10-31):
[0001633978-19-000030:note_history:136]
Remaining performance obligations represent the transaction price allocated to performances obligations that are unsatisfied or partially unsatisfied as of the end of the reporting period. Unsatisfied and partially unsatisfied performance obligations consist of contract liabilities and non-cancellable backlog. Non-cancellable backlog includes goods and services for which customer purchase orders have been accepted that are scheduled or in the process of being scheduled for shipment.

- removed (2019-10-31):
[0001633978-19-000030:note_history:137]
| Contract balances | Balance sheet location | March 30, 2019 |  | June 30, 2018 |  | Change |  | Percentage Change |
| Accounts receivable, net | Accounts receivable, net | $302.9 |  | $197.1 |  | $105.8 |  | 53.7% |
| Deferred revenue and customer deposits | Other current liabilities | $4.2 |  | $2.8 |  | $1.4 |  | 50.0% |

- removed (2019-10-31):
[0001633978-19-000030:note_history:138]
Disaggregation of Revenue

- removed (2019-10-31):
[0001633978-19-000030:note_history:139]
We disaggregate revenue by geography and by product. Refer to “Note 19. Operating Segments and Geographic Information” for a presentation of disaggregated revenue. We do not present other levels of disaggregation, such as by type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, as this information is not used by our Chief Operating Decision Maker to manage the business.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2019-10-31):
[0001633978-19-000071:note_history:140]
On October 30, 2019, we made a voluntary pre-payment of principal amount under our term loan facility of $150.0 million. As a result of the early payment of the term loan, we will recognize a loss on early extinguishment of debt of approximately $2.5 million in our second quarter of fiscal 2020, which will be recorded in our interest expense.

- removed (2019-10-31):
[0001633978-19-000030:note_history:141]
On May 6, 2019,  the Company entered into an agreement for the purchase of property located in San Jose, California. The total purchase price for the property is $54.0 million.  The Purchase Agreement contains customary representations, warranties and covenants of the parties and the closing of the purchase is expected to occur during the Company’s fourth fiscal quarter of 2019 and is subject to conditions typical for a transaction of this type.
