# LITE notes — 0001633978-19-000071


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001633978-19-000071:notes:1]
[same as prior period, unchanged from 0001633978-19-000030:notes:26]

[0001633978-19-000071:notes:2]
[same as prior period, unchanged from 0001633978-19-000030:notes:27]

[0001633978-19-000071:notes:3]
Lumentum (“we,” “us,” “our” or the “Company”) is an industry-leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including Optical Communications (“OpComms”) and Lasers for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be Original Equipment Manufacturers (“OEMs”) that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that Network Equipment Manufacturers’ (“NEMs”) customers assemble into communications networking systems, which they sell to network service providers or enterprises with their own networks. Similarly, many of our customers for our Lasers products incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For 3D sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, and gaming who then integrate our devices within their products, for eventual resale to consumers and also into other industrial applications. Further, we are starting to sell diode lasers and optical subassemblies containing diode lasers and other optical devices to automotive customers for sensing and LiDAR applications.

[0001633978-19-000071:notes:4]
Basis of Presentation

[0001633978-19-000071:notes:5]
The preparation of the condensed consolidated financial statements in accordance with U.S. generally accepted accounting principles (“GAAP”) requires management to make estimates and assumptions that affect the amounts reported in our condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are inventory valuation, revenue recognition, income taxes, long-lived asset valuation, business combinations and goodwill.

[0001633978-19-000071:notes:6]
On December 10, 2018, we completed our merger with Oclaro, Inc. (“Oclaro”), a provider of optical components and modules for the long-haul, metro and data center markets. Our condensed consolidated financial statements include the operating results of Oclaro beginning from the date of acquisition. Refer to “Note 4. Business Combinations” for further discussion of the merger.

[0001633978-19-000071:notes:7]
[same as prior period, unchanged from 0001633978-19-000030:notes:29]

[0001633978-19-000071:notes:8]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Our fiscal 2020 is a 52-week year ending on June 27, 2020, with the quarter ended September 28, 2019 being a 13-week quarterly period. Our fiscal 2019 was a 52-week year that ended on June 29, 2019, with the quarter ended September 29, 2018 being a 13-week quarterly period.

[0001633978-19-000071:notes:9]
[same as prior period, unchanged from 0001633978-19-000030:notes:31]

[0001633978-19-000071:notes:10]
[same as prior period, unchanged from 0001633978-19-000030:notes:32]

[0001633978-19-000071:notes:11]
Certain prior period amounts have been reclassified to conform to the current period presentation, including the reclassification of capital lease obligations that existed as of June 29, 2019 to finance lease liabilities within other current liabilities and other non-current liabilities in our condensed consolidated balance sheets, as a result of the adoption of the new accounting guidance for leases. Refer to “Note 2. Recently Issued Accounting Pronouncements” for details. The reclassification of the prior period amounts did not impact previously reported condensed consolidated financial statements.

[0001633978-19-000071:notes:12]
[same as prior period, unchanged from 0001633978-19-000030:notes:34]

[0001633978-19-000071:notes:13]
The accompanying condensed consolidated financial statements and accompanying related notes should be read in conjunction with the audited consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended June 29, 2019.

[0001633978-19-000071:notes:14]
Except for the accounting policies for lease accounting as a result of the adoption of Accounting Standards Update (“ASU”) 2016-02, Leases (Topic 842), there have been no significant changes to our significant accounting policies as of and for the three

[0001633978-19-000071:notes:15]
months ended September 28, 2019, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the year ended June 29, 2019.

[0001633978-19-000071:notes:16]
Adoption of Leases (Topic 842)

[0001633978-19-000071:notes:17]
On June 30, 2019, we adopted Topic 842, using the modified retrospective transition approach. Refer to “Note 2. Recently Issued Accounting Pronouncements” regarding the impact of adoption.

[0001633978-19-000071:notes:18]
We determine if an arrangement is a lease at inception for arrangements with an initial term of more than 12 months, and classify it as either finance or operating.

[0001633978-19-000071:notes:19]
Finance leases are generally those that allow us to substantially utilize or pay for the entire asset over its estimated useful life. Finance leases are recorded in property, plant and equipment, net, and finance lease liabilities within other current and other non-current liabilities on our condensed consolidated balance sheets. We have lease arrangements with lease and non-lease components, and the non-lease components for our finance leases are accounted for separately, based on estimated stand-alone values, and are not included in the initial measurement of our finance lease assets and corresponding liabilities. Finance lease assets are amortized in operating expenses on a straight-line basis over the shorter of the estimated useful lives of the assets or the lease term, with the interest component included in interest expense and recognized using the effective interest method over the lease term.

[0001633978-19-000071:notes:20]
Operating leases are recorded in operating lease right-of-use assets, net, and operating lease liabilities, current and non-current on our condensed consolidated balance sheets. For operating leases of buildings, we account for non-lease components, such as common area maintenance, as a component of the lease, and include it in the initial measurement of our operating lease assets and corresponding liabilities. Operating lease assets are amortized on a straight-line basis in operating expenses over the lease term.

[0001633978-19-000071:notes:21]
Our lease liabilities are recognized based on the present value of the remaining fixed lease payments, over the lease term, using a discount rate of similarly secured borrowings available to us. For the purpose of lease liability measurement, we consider only payments that are fixed and determinable at the time of commencement. Any variable payments that depend on an index or rate are expensed as incurred. Our lease terms may include options to extend when it is reasonably certain that we will exercise that option. Our lease assets also include any lease payments made and exclude any lease incentives received prior to commencement. Our lease assets are tested for impairment in the same manner as long-lived assets used in operations. We generally recognize sublease income on a straight-line basis over the sublease term.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001633978-19-000071:notes:22]
Operating leases are recorded in operating lease right-of-use assets, net, and operating lease liabilities, current and non-current on our condensed consolidated balance sheets. For operating leases of buildings, we account for non-lease components, such as common area maintenance, as a component of the lease, and include it in the initial measurement of our operating lease assets and corresponding liabilities. Operating lease assets are amortized on a straight-line basis in operating expenses over the lease term. 
Our lease liabilities are recognized based on the present value of the remaining fixed lease payments, over the lease term, using a discount rate of similarly secured borrowings available to us. For the purpose of lease liability measurement, we consider only payments that are fixed and determinable at the time of commencement. Any variable payments that depend on an index or rate are expensed as incurred. Our lease terms may include options to extend when it is reasonably certain that we will exercise that option. Our lease assets also include any lease payments made and exclude any lease incentives received prior to commencement. Our lease assets are tested for impair
Accounting Pronouncements Recently Adopted

[0001633978-19-000071:notes:23]
Effective June 30, 2019, we adopted Topic 842, using the modified retrospective transition approach. We applied the new guidance to all leases existing as of the date of adoption. Our reported results for the first quarter of fiscal 2020 reflect the application of Topic 842, while prior period amounts have not been adjusted and continue to be reported in accordance with our historical accounting under Topic 840.

[0001633978-19-000071:notes:24]
We elected the practical expedient package permitted under the transition approach. As such, we did not reassess whether any expired or existing contracts are or contain leases, we did not reassess our historical lease classification, and we did not reassess our initial direct costs for any leases that existed prior to June 30, 2019. We have also elected to combine lease and non-lease components at a portfolio level for our operating leases of buildings and not to report leases with an initial term of 12 months or less on our balance sheet.

[0001633978-19-000071:notes:25]
As of the date of adoption, we recognized operating lease assets of $91.5 million, with corresponding operating lease liabilities of $81.5 million on the condensed consolidated balance sheets. The difference between the operating lease right-of-use assets and operating lease liabilities primarily represents the existing asset recognized in relation to the favorable terms of an operating lease acquired through a business combination offset by our deferred rent and ASC 420 “cease-use” balances.

[0001633978-19-000071:notes:26]
All existing leases that were classified as capital leases under Topic 840 will be classified as finance leases under the new guidance. As of adoption, we recognized finance lease assets of $12.4 million in property, plant and equipment, net, with corresponding finance lease liabilities of $12.4 million on the condensed consolidated balance sheets. For further information regarding the impact of Topic 842 adoption, see “Note 1. Description of Business and Summary of Significant Accounting Policies”  and “Note 8. Leases”.

[0001633978-19-000071:notes:27]
In February 2018, FASB issued ASU 2018-02, Income Statement-Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which allows companies to reclassify stranded tax effects resulting from the U.S. Tax Cuts and Jobs Act of 2017 (the “Tax Act”), from accumulated other comprehensive income to retained earnings. The guidance also requires certain new disclosures regardless of the election. The amendments in ASU 2018-02 are effective for all entities for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years. We adopted ASU 2018-02 in the current fiscal quarter with no impact to our condensed consolidated financial statements.

[0001633978-19-000071:notes:28]
In January 2017, FASB issued ASU 2017-04, Intangibles - Goodwill and Other (Topic 350): Simplifying the Accounting for Goodwill Impairment. ASU 2017-04 removes the requirement to perform a hypothetical purchase price allocation to measure goodwill impairment. A goodwill impairment charge will be the amount by which a reporting unit's carrying value exceeds its fair value, not to exceed the carrying amount of goodwill. The amendments contained in ASU 2017-04 are effective for interim and annual periods beginning after December 15, 2019, with early adoption permitted, which should be applied prospectively. We early adopted ASU 2017-04 in our first quarter of fiscal 2020. The implementation of ASU 2017-04 did not have an impact on our condensed consolidated financial statements.

[0001633978-19-000071:notes:29]
Accounting Pronouncements Not Yet Effective

[0001633978-19-000071:notes:30]
In August 2018, FASB issued ASU 2018-14, Compensation-Retirement Benefits-Defined Benefit Plans-General (Topic 715-20): Disclosure Framework-Changes to the Disclosure Requirements for Defined Benefit Plans. ASU 2018-14 modifies the disclosure requirements for defined benefit pension plans and other post-retirement benefit plans. The new guidance is effective for fiscal years ending after December 15, 2020, with early adoption permitted. ASU 2018-14 should be applied retrospectively to all periods presented and is effective for us in our first quarter of fiscal 2022. We are currently evaluating the impact of ASU 2018-14 on our condensed consolidated financial statements.

[0001633978-19-000071:notes:31]
In August 2018, FASB issued ASU 2018-13, Fair Value Measurement (Topic 820): Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement. ASU 2018-13 modifies the disclosure requirements for fair value measurements. The new guidance is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, with early adoption permitted. ASU 2018-13 requires that certain of the amendments be applied prospectively, while other amendments should be applied retrospectively to all periods presented. ASU 2018-13 is effective for us in our first quarter of fiscal 2021. We are currently evaluating the impact of ASU 2018-13 on our condensed consolidated financial statements and related disclosures.

[0001633978-19-000071:notes:32]
In June 2016, FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments and a subsequent amendment, ASU 2018-19 (collectively, Topic 326). Topic 326 requires measurement and recognition of expected credit losses for financial assets held. Topic 326 is effective for annual periods beginning after December 15, 2019, including interim periods within those periods, with early adoption permitted. ASU 2016-13 is effective for us in our first quarter of fiscal 2021. We are currently evaluating the impact of our pending adoption of Topic 326 on our condensed consolidated financial statements.


## us-gaap:EarningsPerShareTextBlock

[0001633978-19-000071:notes:33]
[same as prior period, unchanged from 0001633978-19-000030:notes:174]

[0001633978-19-000071:notes:34]
[same as prior period, unchanged from 0001633978-19-000030:notes:175]

[0001633978-19-000071:notes:35]
|  | Three Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |
| Basic Earnings per Common Share |  |  |  |  |  |
| Net income | $ | 47.6 |  |  | $ | 47.4 |  |
| Less: Cumulative dividends on Series A Preferred Stock | — |  |  | (0.2 | ) |
| Less: Earnings allocated to Series A Preferred Stock | — |  |  | (1.1 | ) |
| Net income attributable to common stockholders - Basic | $ | 47.6 |  |  | $ | 46.1 |  |
| Weighted average common shares outstanding including Series A Preferred Stock | 76.9 |  |  | 64.6 |  |
| Less: Weighted average Series A Preferred Stock | — |  |  | (1.5 | ) |
| Basic weighted average common shares outstanding | 76.9 |  |  | 63.1 |  |
| Net income per share attributable to common stockholders - Basic | $ | 0.62 |  |  | $ | 0.73 |  |
| Diluted Earnings per Common Share |  |  |  |
| Net income attributable to common stockholders - Basic | $ | 47.6 |  |  | $ | 46.1 |  |
| Net income attributable to common stockholders - Diluted | $ | 47.6 |  |  | $ | 46.1 |  |
| Weighted average common shares outstanding for basic earnings per common share | 76.9 |  |  | 63.1 |  |
| Effect of dilutive securities from 2015 Equity Incentive Plan | 0.7 |  |  | 0.8 |  |
| Diluted weighted average common shares outstanding | 77.6 |  |  | 63.9 |  |
| Net income per share attributable to common stockholders - Diluted | $ | 0.61 |  |  | $ | 0.72 |  |

[0001633978-19-000071:notes:36]
Our Series A Preferred Stock was considered a participating security, meaning that it had the right to participate in undistributed earnings with our common stock. On November 2, 2018, the remaining 35,805 shares of our Series A Preferred Stock were converted into 1.5 million shares of our common stock. Refer to “Note 10. Non-Controlling Interest Redeemable Convertible Preferred Stock and Derivative Liability” for further discussion. Prior to conversion, the holders of our Series A Preferred Stock were entitled to share in dividends, on an as-converted basis, if the holders of our common stock were to receive dividends. Through the date of conversion, we used the two-class method to compute earnings per share. The two-class method is an earnings allocation formula that determines earnings per share for each class of common stock and participating security according to dividends declared (or accumulated) and participation rights in undistributed earnings. In determining the amount of net earnings to allocate to common stockholders, earnings are allocated to both common and participating securities based on their respective weighted-average shares outstanding during the period. Diluted earnings per common share is calculated similar to basic earnings per common share except that it gives effect to all potentially dilutive common stock equivalents outstanding for the period, using the treasury stock method. Diluted earnings per common share is computed using the more dilutive of the treasury stock method or the if-converted method.

[0001633978-19-000071:notes:37]
Potentially dilutive common shares result from the assumed exercise of outstanding stock options, assumed vesting of outstanding equity awards, assumed issuance of stock under the employee stock purchase plan, and assumed conversion of our outstanding $450 million in aggregate principal amount of 0.25% Convertible Notes due in 2024 (the “2024 Notes”), all using the treasury stock method. We have the ability and intent to settle the $450 million face value of the 2024 Notes in cash. Therefore, we use the treasury stock method for calculating the dilutive impact of the 2024 Notes. The 2024 Notes will have no impact on diluted earnings per share until the average price of our common stock over a 30-day period exceeds the conversion price of $60.62. Refer to “Note 11. Debt” for further discussion.

[0001633978-19-000071:notes:38]
Anti-dilutive potential shares from the 2015 Equity Incentive Plan are excluded from the calculation of diluted earnings per share if their exercise price exceeded the average market price during the period or the share-based awards were determined to be

[0001633978-19-000071:notes:39]
anti-dilutive based on applying the treasury stock method. We excluded 0.4 million and 0.3 million of anti-dilutive shares from the calculation of diluted earnings per share for the three months ended September 28, 2019 and September 29, 2018, respectively.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0001633978-19-000071:notes:40]
Note 4. Business Combinations

[0001633978-19-000071:notes:41]
On December 10, 2018, we acquired all of the outstanding common stock of Oclaro, a provider of optical components and modules for the long-haul, metro and data center markets. Oclaro’s products provide differentiated solutions for optical networks and high-speed interconnects driving the next wave of streaming video, cloud computing, application virtualization and other bandwidth-intensive and high-speed applications.

[0001633978-19-000071:notes:42]
[same as prior period, unchanged from 0001633978-19-000030:notes:246]

[0001633978-19-000071:notes:43]
[same as prior period, unchanged from 0001633978-19-000030:notes:247]

[0001633978-19-000071:notes:44]
The total transaction consideration was funded by the issuance of Lumentum common stock, new debt, and cash balances of the combined company. The Company incurred $9.3 million of debt financing costs which has been recorded as a contra liability (refer to “Note 11. Debt”).

[0001633978-19-000071:notes:45]
Our preliminary allocation of the purchase price of Oclaro on December 10, 2018, based on the estimated fair values of the assets acquired and liabilities assumed is as follows (in millions):

[0001633978-19-000071:notes:46]
|  | As Previously Reported on June 29, 2019 |
| Cash and cash equivalents | $ | 345.0 |  |
| Accounts receivable, net | 68.0 |  |
| Inventories | 155.0 |  |
| Prepayments and other current assets | 33.7 |  |
| Property, plant and equipment, net | 134.7 |  |
| Intangibles | 444.0 |  |
| Deferred income tax asset | 42.6 |  |
| Other non-current assets | 16.6 |  |
| Accounts payable | (57.8 | ) |
| Accrued payroll and related expenses | (11.4 | ) |
| Accrued expenses | (8.3 | ) |
| Other current liabilities | (6.1 | ) |
| Deferred tax liability | (75.8 | ) |
| Other non-current liabilities | (12.9 | ) |
| Goodwill | 357.6 |  |
| Total purchase price | $ | 1,424.9 |  |

[0001633978-19-000071:notes:47]
The provisional amounts presented in the table above pertained to the preliminary purchase price allocation reported in our Form 10-K for the year ended June 29, 2019, filed with the Securities and Exchange Commission on August 27, 2019. There have been no measurement period adjustments during the three months ended September 28, 2019.

[0001633978-19-000071:notes:48]
We continually evaluate our existing portfolio of businesses to maximize long-term shareholder value. On April 18, 2019, we completed the sale of our Datacom transceiver module business based in Sagamihara, Japan and the transfer of related employees to Cambridge Industries Group (“CIG”) for $25.5 million in net cash. These product lines were initially acquired by us through

[0001633978-19-000071:notes:49]
the acquisition of Oclaro. This business did not meet the criteria for assets held-for-sale under the relevant accounting guidance as of December 10, 2018, the date of our acquisition of Oclaro, in our purchase price allocation. The assets and liabilities transferred to CIG were $33.5 million and $7.0 million, respectively.

[0001633978-19-000071:notes:50]
[same as prior period, unchanged from 0001633978-19-000030:notes:266]

[0001633978-19-000071:notes:51]
[same as prior period, unchanged from 0001633978-19-000030:notes:267]

[0001633978-19-000071:notes:52]
The following supplemental pro forma information presents the combined results of operations for the three months ended September 29, 2018, as if Oclaro had been acquired as of the beginning of fiscal year 2018. The supplemental pro forma information includes adjustments to amortization and depreciation for acquired intangible assets and property and equipment, adjustments to share-based compensation expense, the fair value adjustments on the inventories acquired, transaction costs, interest expense and amortization of the term loan debt issuance costs.

[0001633978-19-000071:notes:53]
The unaudited supplemental pro forma financial information for the period presented is as follows (in millions):

[0001633978-19-000071:notes:54]
|  | Three Months Ended |
|  | September 29, 2018 |
| Net revenue | $ | 485.8 |  |
| Net income | 39.1 |  |


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001633978-19-000071:notes:55]
Note 5. Cash, Cash Equivalents and Short-term Investments

[0001633978-19-000071:notes:56]
[same as prior period, unchanged from 0001633978-19-000030:notes:70]

[0001633978-19-000071:notes:57]
|  | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| September 28, 2019: |  |  |  |  |  |  |  |
| Cash | $ | 213.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 213.8 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | 5.5 |  |  | — |  |  | — |  |  | 5.5 |  |
| Commercial paper | 82.3 |  |  | — |  |  | — |  |  | 82.3 |  |
| Money market funds | 229.7 |  |  | — |  |  | — |  |  | 229.7 |  |
| U.S. Agency securities | 1.2 |  |  | — |  |  | — |  |  | 1.2 |  |
| U.S. Treasury securities | 6.5 |  |  | — |  |  | — |  |  | 6.5 |  |
| Total cash and cash equivalents | $ | 539.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 539.0 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 6.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 6.4 |  |
| Commercial paper | 12.3 |  |  | — |  |  | — |  |  | 12.3 |  |
| Asset-backed securities | 38.0 |  |  | 0.2 |  |  | — |  |  | 38.2 |  |
| Corporate debt securities | 179.7 |  |  | 0.9 |  |  | — |  |  | 180.6 |  |
| Mortgage-backed securities | 5.9 |  |  | 0.1 |  |  | — |  |  | 6.0 |  |
| Foreign government bonds | 6.2 |  |  | — |  |  | — |  |  | 6.2 |  |
| U.S. Treasury securities | 42.2 |  |  | — |  |  | — |  |  | 42.2 |  |
| Total short-term investments | $ | 290.7 |  |  | $ | 1.2 |  |  | $ | — |  |  | $ | 291.9 |  |
| June 29, 2019: |  |  |  |  |  |  |  |
| Cash | $ | 213.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 213.8 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 37.4 |  |  | — |  |  | — |  |  | 37.4 |  |
| Money market funds | 168.1 |  |  | — |  |  | — |  |  | 168.1 |  |
| U.S. Treasury securities | 13.3 |  |  | — |  |  | — |  |  | 13.3 |  |
| Total cash and cash equivalents | $ | 432.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 432.6 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 1.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 1.9 |  |
| Commercial paper | 22.3 |  |  | — |  |  | — |  |  | 22.3 |  |
| Asset-backed securities | 54.9 |  |  | 0.2 |  |  | — |  |  | 55.1 |  |
| Corporate debt securities | 207.6 |  |  | 0.9 |  |  | (0.1 | ) |  | 208.4 |  |
| Municipal bonds | 1.3 |  |  | — |  |  | — |  |  | 1.3 |  |
| Mortgage-backed securities | 6.6 |  |  | — |  |  | — |  |  | 6.6 |  |
| Foreign government bonds | 6.2 |  |  | — |  |  | — |  |  | 6.2 |  |
| U.S. Agency securities | 4.6 |  |  | — |  |  | — |  |  | 4.6 |  |
| U.S. Treasury securities | 29.4 |  |  | 0.1 |  |  | — |  |  | 29.5 |  |
| Total short-term investments | $ | 334.8 |  |  | $ | 1.2 |  |  | $ | (0.1 | ) |  | $ | 335.9 |  |

[0001633978-19-000071:notes:58]
We use the specific-identification method to determine any realized gains or losses from the sale of our short-term investments classified as available-for-sale. During the three months ended September 28, 2019 and September 29, 2018, we did not realize significant gains or losses on a gross level from the sale of our short-term investments classified as available-for-sale.

[0001633978-19-000071:notes:59]
During the three months ended September 28, 2019 and September 29, 2018, our other income (expense), net was $5.0 million and $2.7 million, respectively, and includes interest income on cash equivalents and short-term investments of $4.0 million and $2.7 million, respectively.

[0001633978-19-000071:notes:60]
[same as prior period, unchanged from 0001633978-19-000030:notes:75]

[0001633978-19-000071:notes:61]
|  | Less than 12 months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| September 28, 2019: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper | $ | 3.8 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 3.8 |  |  | $ | — |  |
| Asset-backed securities | 0.7 |  |  | — |  |  | 2.1 |  |  | — |  |  | 2.8 |  |  | — |  |
| Corporate debt securities | 5.2 |  |  | — |  |  | 6.9 |  |  | — |  |  | 12.1 |  |  | — |  |
| Foreign government bonds | — |  |  | — |  |  | 2.2 |  |  | — |  |  | 2.2 |  |  | — |  |
| U.S. government bonds | 6.9 |  |  | — |  |  | — |  |  | — |  |  | 6.9 |  |  | — |  |
| Total | $ | 16.6 |  |  | $ | — |  |  | $ | 11.2 |  |  | $ | — |  |  | $ | 27.8 |  |  | $ | — |  |
| June 29, 2019: |  |  |  |  |  |  |  |  |  |  |  |
| Asset-backed securities | $ | 4.2 |  |  | $ | — |  |  | $ | 5.9 |  |  | $ | — |  |  | $ | 10.1 |  |  | $ | — |  |
| Corporate debt securities | 9.6 |  |  | — |  |  | 35.9 |  |  | (0.1 | ) |  | 45.5 |  |  | (0.1 | ) |
| Foreign government bonds | — |  |  | — |  |  | 2.1 |  |  | — |  |  | 2.1 |  |  | — |  |
| U.S. government bonds | 6.9 |  |  | — |  |  | — |  |  | — |  |  | 6.9 |  |  | — |  |
| Total | $ | 20.7 |  |  | $ | — |  |  | $ | 43.9 |  |  | $ | (0.1 | ) |  | $ | 64.6 |  |  | $ | (0.1 | ) |

[0001633978-19-000071:notes:62]
[same as prior period, unchanged from 0001633978-19-000030:notes:77]

[0001633978-19-000071:notes:63]
|  | September 28, 2019 |  | June 29, 2019 |
|  | Amortized Cost |  | Fair Value |  | Amortized Cost |  | Fair Value |
| Due in 1 year | $ | 151.9 |  |  | $ | 152.2 |  |  | $ | 178.9 |  |  | $ | 179.1 |  |
| Due in 1 year through 5 years | 133.3 |  |  | 134.2 |  |  | 148.1 |  |  | 149.0 |  |
| Due in 5 years through 10 years | 4.5 |  |  | 4.5 |  |  | 6.0 |  |  | 6.0 |  |
| Due after 10 years | 1.0 |  |  | 1.0 |  |  | 1.8 |  |  | 1.8 |  |
|  | $ | 290.7 |  |  | $ | 291.9 |  |  | $ | 334.8 |  |  | $ | 335.9 |  |

[0001633978-19-000071:notes:64]
[same as prior period, unchanged from 0001633978-19-000030:notes:79]


## us-gaap:FairValueDisclosuresTextBlock

[0001633978-19-000071:notes:65]
Note 6. Fair Value Measurements

[0001633978-19-000071:notes:66]
[same as prior period, unchanged from 0001633978-19-000030:notes:182]

[0001633978-19-000071:notes:67]
[same as prior period, unchanged from 0001633978-19-000030:notes:183]

[0001633978-19-000071:notes:68]
[same as prior period, unchanged from 0001633978-19-000030:notes:184]

[0001633978-19-000071:notes:69]
Prior to the conversion of the Series A Preferred Stock in the second quarter of fiscal 2019, we estimated the fair value of the embedded derivative for the Series A Preferred Stock using the binomial lattice model. The binomial lattice model requires various assumptions to be made to determine the fair value of the embedded derivatives. These assumptions represent Level 3 inputs. Refer to “Note 10. Non-Controlling Interest Redeemable Convertible Preferred Stock and Derivative Liability.”

[0001633978-19-000071:notes:70]
In February 2017, we completed the acquisition of a privately held company to enhance our manufacturing and vertical integration capabilities for a total purchase consideration of $8.7 million. We estimated the fair value of our Level 3 contingent consideration related to this acquisition at the present value of the expected contingent payments, determined using a probabilistic approach. We are required to reassess the fair value of contingent payments on a periodic basis. We estimated the likelihood of meeting the production targets at 100 percent and recorded $3.0 million of the fair value of such contingent consideration in other current liabilities on the condensed consolidated balance sheet as of September 28, 2019. This contingent consideration is anticipated to be paid within the next 12 months, when the production targets are achieved, and the actual amount is subject to the then applicable exchange rate.

[0001633978-19-000071:notes:71]
Based on quoted market prices as of September 28, 2019, the fair value of the Convertible Notes (refer to “Note 11. Debt”) was approximately $529.6 million, determined using Level 2 inputs as they are not actively traded in markets.

[0001633978-19-000071:notes:72]
[same as prior period, unchanged from 0001633978-19-000030:notes:188]

[0001633978-19-000071:notes:73]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| September 28, 2019: (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | — |  |  | $ | 5.5 |  |  | $ | — |  |  | $ | 5.5 |  |
| Commercial paper | — |  |  | 82.3 |  |  | — |  |  | 82.3 |  |
| Money market funds | 229.7 |  |  | — |  |  | — |  |  | 229.7 |  |
| U.S. Agency securities | — |  |  | 1.2 |  |  | — |  |  | 1.2 |  |
| U.S. Treasury securities | 6.5 |  |  | — |  |  | — |  |  | 6.5 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 6.4 |  |  | — |  |  | 6.4 |  |
| Commercial paper | — |  |  | 12.3 |  |  | — |  |  | 12.3 |  |
| Asset-backed securities | — |  |  | 38.2 |  |  | — |  |  | 38.2 |  |
| Corporate debt securities | — |  |  | 180.6 |  |  | — |  |  | 180.6 |  |
| Mortgage-backed securities | — |  |  | 6.0 |  |  | — |  |  | 6.0 |  |
| Foreign government bonds | — |  |  | 6.2 |  |  | — |  |  | 6.2 |  |
| U.S. Treasury securities | 42.2 |  |  | — |  |  | — |  |  | 42.2 |  |
| Total assets | $ | 278.4 |  |  | $ | 338.7 |  |  | $ | — |  |  | $ | 617.1 |  |
| Other current liabilities: |  |  |  |  |  |  |  |
| Acquisition contingencies | $ | — |  |  | $ | — |  |  | $ | 3.0 |  |  | $ | 3.0 |  |
| Total other accrued liabilities | $ | — |  |  | $ | — |  |  | $ | 3.0 |  |  | $ | 3.0 |  |

[0001633978-19-000071:notes:74]
(1)  Excludes $213.8 million in cash held in our bank accounts at September 28, 2019.

[0001633978-19-000071:notes:75]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| June 29, 2019: (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | — |  |  | $ | 37.4 |  |  | $ | — |  |  | $ | 37.4 |  |
| Money market funds | 168.1 |  |  | — |  |  | — |  |  | 168.1 |  |
| U.S. Treasury securities | 13.3 |  |  | — |  |  | — |  |  | 13.3 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 1.9 |  |  | — |  |  | 1.9 |  |
| Commercial paper | — |  |  | 22.3 |  |  | — |  |  | 22.3 |  |
| Asset-backed securities | — |  |  | 55.1 |  |  | — |  |  | 55.1 |  |
| Corporate debt securities | — |  |  | 208.4 |  |  | — |  |  | 208.4 |  |
| Municipal bonds | — |  |  | 1.3 |  |  | — |  |  | 1.3 |  |
| Mortgage-backed securities | — |  |  | 6.6 |  |  | — |  |  | 6.6 |  |
| Foreign government bonds | — |  |  | 6.2 |  |  | — |  |  | 6.2 |  |
| U.S. Agency securities | — |  |  | 4.6 |  |  | — |  |  | 4.6 |  |
| U.S. Treasury securities | 29.5 |  |  | — |  |  | — |  |  | 29.5 |  |
| Total assets | $ | 210.9 |  |  | $ | 343.8 |  |  | $ | — |  |  | $ | 554.7 |  |
| Other accrued liabilities: |  |  |  |  |  |  |  |
| Acquisition contingencies | $ | — |  |  | $ | — |  |  | $ | 2.7 |  |  | $ | 2.7 |  |
| Total other accrued liabilities | $ | — |  |  | $ | — |  |  | $ | 2.7 |  |  | $ | 2.7 |  |

[0001633978-19-000071:notes:76]
(1)  Excludes $213.8 million in cash held in our bank accounts as of June 29, 2019.

[0001633978-19-000071:notes:77]
[same as prior period, unchanged from 0001633978-19-000030:notes:194]

[0001633978-19-000071:notes:78]
[same as prior period, unchanged from 0001633978-19-000030:notes:195]

[0001633978-19-000071:notes:79]
Management utilizes various valuation methods, including an income approach, a market approach and a cost approach, to estimate the fair value of intangible and other long-lived assets. During the annual impairment testing performed in fiscal 2019, we concluded that our intangible and other long-lived assets were not impaired.

[0001633978-19-000071:notes:80]
No impairment charges were recorded during the three months ended September 28, 2019 and September 29, 2018. Refer to “Note 9. Goodwill and Other Intangible Assets”.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001633978-19-000071:notes:81]
We periodically review our intangible and other long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. Determination of recoverability is based on the lowest level of identifiable estimated undiscounted cash flows resulting from use of the asset and its eventual disposition. If not recoverable, an impairment loss would be calculated based on the excess of the carrying amount over the fair value.
Management utilizes various valuation methods, including an income approach, a market approach and a cost approach, to estimate the fair value of intangible and other long-lived assets.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001633978-19-000071:notes:82]
[same as prior period, unchanged from 0001633978-19-000030:notes:343]

[0001633978-19-000071:notes:83]
As of each of September 28, 2019 and June 29, 2019, our accounts receivable allowance balance was $4.5 million.

[0001633978-19-000071:notes:84]
[same as prior period, unchanged from 0001633978-19-000030:notes:345]

[0001633978-19-000071:notes:85]
The components of inventories were as follows (in millions):

[0001633978-19-000071:notes:86]
|  | September 28, 2019 |  | June 29, 2019 |
| Raw materials and purchased parts | $ | 73.0 |  |  | $ | 78.3 |  |
| Work in process | 62.1 |  |  | 72.5 |  |
| Finished goods | 67.1 |  |  | 78.0 |  |
| Inventories (1) | $ | 202.2 |  |  | $ | 228.8 |  |

[0001633978-19-000071:notes:87]
(1) The inventory balance as of September 28, 2019 and June 29, 2019 includes $3.5 million and $5.7 million, net of amortization, related to the inventory step-up adjustment from the Oclaro acquisition, respectively.

[0001633978-19-000071:notes:88]
[same as prior period, unchanged from 0001633978-19-000030:notes:346]

[0001633978-19-000071:notes:89]
The components of prepayments and other current assets were as follows (in millions):

[0001633978-19-000071:notes:90]
|  | September 28, 2019 |  | June 29, 2019 |
| Prepayments | $ | 37.2 |  |  | $ | 32.4 |  |
| Vendor receivable | 34.2 |  |  | 36.3 |  |
| Value added tax receivable | 12.6 |  |  | 11.9 |  |
| Advances to contract manufacturers | 6.1 |  |  | 8.7 |  |
| Assets held-for-sale | 4.9 |  |  | 4.9 |  |
| Other current assets | 2.3 |  |  | 3.3 |  |
| Prepayments and other current assets | $ | 97.3 |  |  | $ | 97.5 |  |

[0001633978-19-000071:notes:91]
Operating lease right-of-use assets, net

[0001633978-19-000071:notes:92]
Operating lease right-of-use assets, net were as follows (in millions):

[0001633978-19-000071:notes:93]
|  | September 28, 2019 |
| Operating lease right-of-use assets | $ | 91.5 |  |
| Less: accumulated amortization | (3.3 | ) |
| Operating lease right-of-use assets, net | $ | 88.2 |  |

[0001633978-19-000071:notes:94]
[same as prior period, unchanged from 0001633978-19-000030:notes:347]

[0001633978-19-000071:notes:95]
The components of property, plant and equipment, net were as follows (in millions):

[0001633978-19-000071:notes:96]
|  | September 28, 2019 |  | June 29, 2019 |
| Land | $ | 44.2 |  |  | $ | 44.2 |  |
| Buildings and improvement | 106.5 |  |  | 103.7 |  |
| Machinery and equipment (1) | 510.2 |  |  | 500.5 |  |
| Computer equipment and software | 25.3 |  |  | 25.4 |  |
| Furniture and fixtures | 5.1 |  |  | 4.9 |  |
| Leasehold improvements | 30.9 |  |  | 31.2 |  |
| Finance lease right-of-use assets (1) | 28.4 |  |  | 16.0 |  |
| Construction in progress | 52.0 |  |  | 46.8 |  |
|  | 802.6 |  |  | 772.7 |  |
| Less: Accumulated depreciation (1) | (365.9 | ) |  | (339.4 | ) |
| Property, plant and equipment, net | $ | 436.7 |  |  | $ | 433.3 |  |

[0001633978-19-000071:notes:97]
(1) Included in the table above is our equipment acquired under finance leases. As of September 28, 2019 and June 29, 2019, the accumulated depreciation of finance lease right-of-use assets was $15.1 million and $11.2 million, respectively. For fiscal 2019 in accordance with Topic 842, we have reclassified $16.0 million of equipment acquired under finance leases from machinery and equipment to finance lease right-of-use assets to conform to current period presentation.

[0001633978-19-000071:notes:98]
During the three months ended September 28, 2019 and September 29, 2018, we recorded depreciation expense of $31.6 million and $19.7 million, respectively. Included in these amounts were depreciation expense for equipment acquired under finance leases in the amount of $3.9 million and $1.5 million for the same respective periods.

[0001633978-19-000071:notes:99]
In fiscal 2019, we purchased a property in San Jose, California for $54.6 million in cash. We have relocated our corporate headquarters to this new San Jose location in the second quarter of fiscal 2020. The allocations of value were $21.7 million to buildings and improvements and $32.9 million to the land. The total amount of $54.6 million is included in our property, plant and equipment, gross as of September 28, 2019.

[0001633978-19-000071:notes:100]
Our construction in progress primarily includes machinery and equipment that we expect to place in service in the next 12 months.

[0001633978-19-000071:notes:101]
[same as prior period, unchanged from 0001633978-19-000030:notes:348]

[0001633978-19-000071:notes:102]
The components of other current liabilities were as follows (in millions):

[0001633978-19-000071:notes:103]
|  | September 28, 2019 |  | June 29, 2019 |
| Restructuring accrual and related charges (1) | $ | 10.7 |  |  | $ | 14.6 |  |
| Warranty accrual (2) | 7.0 |  |  | 7.5 |  |
| Deferred revenue and customer deposits | 2.5 |  |  | 2.9 |  |
| Finance lease liabilities, current (3) | 9.7 |  |  | 0.4 |  |
| Income tax payable (4) | 17.0 |  |  | 8.7 |  |
| Other current liabilities | 5.7 |  |  | 5.1 |  |
| Other current liabilities | $ | 52.6 |  |  | $ | 39.2 |  |

[0001633978-19-000071:notes:104]
(1) Refer to “Note 14. Restructuring and Related Charges.”

[0001633978-19-000071:notes:105]
(2) Refer to “Note 17. Commitments and Contingencies.”

[0001633978-19-000071:notes:106]
(3) For fiscal 2019 in accordance with Topic 842, we have reclassified amounts from capital lease obligations to finance lease liabilities to conform to current period presentation. In addition to the $9.7 million of finance lease liabilities recorded within other current liabilities as of September 28, 2019, we also recorded $0.4 million within other non-current liabilities in the condensed consolidated balance sheet. Refer to “Note 8. Leases.”

[0001633978-19-000071:notes:107]
(4) Refer to “Note 15. Income Taxes.”

[0001633978-19-000071:notes:108]
[same as prior period, unchanged from 0001633978-19-000030:notes:349]

[0001633978-19-000071:notes:109]
The components of other non-current liabilities were as follows (in millions):

[0001633978-19-000071:notes:110]
|  | September 28, 2019 |  | June 29, 2019 |
| Asset retirement obligation | $ | 4.5 |  |  | $ | 4.5 |  |
| Pension and related accrual (1) | 8.1 |  |  | 7.9 |  |
| Deferred rent | — |  |  | 2.2 |  |
| Unrecognized tax benefit | 18.8 |  |  | 18.7 |  |
| Finance lease liabilities, non-current | 0.4 |  |  | — |  |
| Other non-current liabilities | 0.3 |  |  | 0.4 |  |
| Other non-current liabilities | $ | 32.1 |  |  | $ | 33.7 |  |

[0001633978-19-000071:notes:111]
(1) In connection with our acquisitions of Oclaro in fiscal 2019 and Time-Bandwidth  Products Inc. in fiscal 2014, we assumed defined benefit plans for Japan and Switzerland employees, respectively. As of September 28, 2019, the projected benefit obligations for Japanese and Swiss employees were $3.0 million and $5.1 million, respectively, and were included in other non-current liabilities in our condensed consolidated balance sheet. As of June 29, 2019, the projected benefit obligations for Japanese and Swiss employees were $2.8 million and $5.0 million, respectively, and were included in other non-current liabilities in our condensed consolidated balance sheet. Pension and related accruals as of June 29, 2019 also include $0.1 million attributable to post-retirement benefits for executives.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001633978-19-000071:notes:112]
Note 8. Leases

[0001633978-19-000071:notes:113]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2033. These operating leases are mainly for administrative offices, research-and-development and manufacturing facilities, as well as sales offices in various countries around the world. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. Many leases include one or more options to renew. We do not assume renewals in our determination of the lease term unless the renewals are deemed to be reasonably assured at lease commencement.

[0001633978-19-000071:notes:114]
We have also entered into various finance leases to obtain servers and certain other equipment for our operations. These arrangements are typically for two to four years.

[0001633978-19-000071:notes:115]
As of September 28, 2019, we sublease certain floors of our offices in the United Kingdom, Canada, and Japan. These subleases will expire at various dates by fiscal year 2023. We anticipate receiving approximately $6.4 million in sublease income over the next three years.

[0001633978-19-000071:notes:116]
The components of lease costs, lease term, and discount rate are as follows:

[0001633978-19-000071:notes:117]
|  | Three Months Ended |
|  | September 28, 2019 |
| Finance lease cost (in millions): |  |
| Amortization of right-of-use assets | $ | 3.9 |  |
| Interest | 0.1 |  |
| Operating lease cost | 4.0 |  |
| Variable lease cost | 0.6 |  |
| Short-term lease cost | 0.5 |  |
| Sublease income | (0.6 | ) |
| Total lease cost | $ | 8.5 |  |
| Weighted average remaining lease term (in years): |  |
| Operating leases | 9.1 |  |
| Finance leases | 1.1 |  |
| Weighted average discount rate: |  |
| Operating leases | 3.47 | % |
| Finance leases | 4.38 | % |

[0001633978-19-000071:notes:118]
As of September 28, 2019, maturities of our operating and finance lease liabilities, which do not include short-term leases and variable lease payments, were as follows (in millions):

[0001633978-19-000071:notes:119]
| Fiscal Years |  | Operating Leases (1) |  | Finance Leases |  | Total |
| Remainder of 2020 |  | $ | 10.6 |  |  | $ | 7.5 |  |  | $ | 18.1 |  |
| 2021 |  | 13.5 |  |  | 2.7 |  |  | 16.2 |  |
| 2022 |  | 12.5 |  |  | — |  |  | 12.5 |  |
| 2023 |  | 11.3 |  |  | — |  |  | 11.3 |  |
| 2024 |  | 9.6 |  |  | — |  |  | 9.6 |  |
| Thereafter |  | 30.9 |  |  | — |  |  | 30.9 |  |
| Total minimum lease payments |  | $ | 88.4 |  |  | $ | 10.2 |  |  | $ | 98.6 |  |
| Less: amount representing interest |  | (11.4 | ) |  | (0.1 | ) |  | (11.5 | ) |
| Present value of total lease liabilities |  | $ | 77.0 |  |  | $ | 10.1 |  |  | $ | 87.1 |  |

[0001633978-19-000071:notes:120]
(1) Non-cancellable sublease proceeds for the remainder of fiscal 2020, and fiscal 2021, 2022, and 2023 of $1.9 million, and $2.2 million, $1.9 million, and $0.4 million, respectively, are not included in the table above.

[0001633978-19-000071:notes:121]
Prior to our adoption of Topic 842, future minimum lease payments as of June 29, 2019, which were undiscounted, were net of our sublease income amounts, and included lease and non-lease components, were as follows (in millions):

[0001633978-19-000071:notes:122]
| Fiscal Years |  | Operating Leases |  | Finance Leases |  | Total |
| 2020 |  | $ | 13.9 |  |  | $ | 0.8 |  |  | $ | 14.7 |  |
| 2021 |  | 12.1 |  |  | — |  |  | 12.1 |  |
| 2022 |  | 11.2 |  |  | — |  |  | 11.2 |  |
| 2023 |  | 11.3 |  |  | — |  |  | 11.3 |  |
| 2024 |  | 9.8 |  |  | — |  |  | 9.8 |  |
| Thereafter |  | 31.7 |  |  | — |  |  | 31.7 |  |
| Total minimum operating lease payments |  | $ | 90.0 |  |  | $ | 0.8 |  |  | $ | 90.8 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001633978-19-000071:notes:123]
[same as prior period, unchanged from 0001633978-19-000030:notes:202]

[0001633978-19-000071:notes:124]
On December 10, 2018, we completed the acquisition of Oclaro. We recognized goodwill in the amount of $357.6 million for the acquisition of Oclaro and allocated it to our OpComms segment. There have been no measurement periods or other adjustments to goodwill during the three months ended September 28, 2019. The following table presents our goodwill balance by the reportable segments as of September 28, 2019 (in millions):

[0001633978-19-000071:notes:125]
|  | Optical Communications |  | Commercial Lasers |  | Total |
| Balance as of September 28, 2019 | $ | 363.5 |  |  | $ | 5.4 |  |  | $ | 368.9 |  |

[0001633978-19-000071:notes:126]
[same as prior period, unchanged from 0001633978-19-000030:notes:206]

[0001633978-19-000071:notes:127]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. In the fourth quarter of fiscal 2019, we completed the annual impairment test of goodwill, which indicated there was no goodwill impairment. During the three months ended September 28, 2019 and September 29, 2018, there have been no events or circumstances that have required us to perform an interim assessment of goodwill for impairment.

[0001633978-19-000071:notes:128]
[same as prior period, unchanged from 0001633978-19-000030:notes:208]

[0001633978-19-000071:notes:129]
[same as prior period, unchanged from 0001633978-19-000030:notes:209]

[0001633978-19-000071:notes:130]
| Intangible |  | Fair value(in millions) |  | Weighted average amortization period(in years) |
| Acquired developed technologies |  | $ | 182.0 |  |  | 4.4 years |
| Customer relationships |  | 145.0 |  |  | 8 years |
| In-process research and development |  | 94.0 |  |  | n/a |
| Order backlog |  | 22.0 |  |  | 1 year |
| Total intangible assets |  | $ | 443.0 |  |  |  |

[0001633978-19-000071:notes:131]
[same as prior period, unchanged from 0001633978-19-000030:notes:212]

[0001633978-19-000071:notes:132]
[same as prior period, unchanged from 0001633978-19-000030:notes:213]

[0001633978-19-000071:notes:133]
| September 28, 2019 | Gross Carrying Amount |  | Accumulated Amortization |  | Net |
| Acquired developed technologies | $ | 287.5 |  |  | $ | (136.2 | ) |  | $ | 151.3 |  |
| Customer relationships | 149.3 |  |  | (18.5 | ) |  | 130.8 |  |
| In-process research and development | 94.0 |  |  | — |  |  | 94.0 |  |
| Order backlog | 22.0 |  |  | (21.5 | ) |  | 0.5 |  |
| Other intangibles | 2.7 |  |  | (2.7 | ) |  | — |  |
| Total intangible assets | $ | 555.5 |  |  | $ | (178.9 | ) |  | $ | 376.6 |  |

[0001633978-19-000071:notes:134]
| June 29, 2019 | Gross Carrying Amount |  | Accumulated Amortization |  | Net |
| Acquired developed technologies | $ | 287.5 |  |  | $ | (125.2 | ) |  | $ | 162.3 |  |
| Customer relationships | 149.3 |  |  | (12.3 | ) |  | 137.0 |  |
| In-process research and development | 94.0 |  |  | — |  |  | 94.0 |  |
| Order backlog | 22.0 |  |  | (19.9 | ) |  | 2.1 |  |
| Other intangibles | 2.7 |  |  | (2.7 | ) |  | — |  |
| Total intangible assets | $ | 555.5 |  |  | $ | (160.1 | ) |  | $ | 395.4 |  |

[0001633978-19-000071:notes:135]
The amounts in the table above for fiscal 2019 include cumulative foreign currency translation adjustments, reflecting movement in the currencies of the underlying intangibles.

[0001633978-19-000071:notes:136]
The following table presents details of amortization for the periods presented (in millions):

[0001633978-19-000071:notes:137]
|  | Three Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |
| Cost of sales | $ | 12.5 |  |  | $ | 0.8 |  |
| Selling, general and administrative | 6.3 |  |  | — |  |
| Total amortization of intangibles | $ | 18.8 |  |  | $ | 0.8 |  |

[0001633978-19-000071:notes:138]
Based on the carrying amount of our acquired developed technologies and other intangibles, excluding IPR&D, as of September 28, 2019, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001633978-19-000071:notes:139]
| Fiscal Years |  |
| Remainder of 2020 | $ | 52.2 |  |
| 2021 | 66.7 |  |
| 2022 | 64.1 |  |
| 2023 | 40.6 |  |
| 2024 | 21.8 |  |
| Thereafter | 37.2 |  |
| Total future amortization | $ | 282.6 |  |


## lite:NoncontrollingInterestAndDerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001633978-19-000071:notes:140]
[same as prior period, unchanged from 0001633978-19-000030:notes:5]

[0001633978-19-000071:notes:141]
[same as prior period, unchanged from 0001633978-19-000030:notes:6]

[0001633978-19-000071:notes:142]
On October 15, 2018, we issued a 30-day notice of intent to the holders of Series A Preferred Stock to convert all shares of Series A Preferred Stock at a conversion price equal to the Issuance Value divided by $24.63 plus the accrued and unpaid dividends on each share and any past due dividends, whether or not authorized or declared. On November 2, 2018, we received notice from Amada of their intent to convert the Series A Preferred Stock and we issued 1.5 million shares of our common stock to Amada upon the conversion of the 35,805 shares of Series A Preferred Stock and recorded $79.4 million in additional paid in capital in the condensed consolidated balance sheet.

[0001633978-19-000071:notes:143]
Through the date of conversion, the Series A Preferred Stock conversion feature is bifurcated from the Series A Preferred Stock and accounted for separately as a derivative liability. The derivative liability is measured at fair value each reporting period, and at the date of conversion, with the change in fair value recorded in the condensed consolidated statements of operations. We estimated the fair value of the embedded derivative using the binomial lattice model. We applied the binomial lattice model to value the embedded derivative using a “with-and-without method,” where the value of the Series A Preferred Stock, including the embedded derivative, is defined as the “with”, and the value of the Series A Preferred Stock, excluding the embedded derivative, is defined as the “without”. The binomial lattice model requires the following inputs: (i) the Company's common stock price; (ii) conversion price; (iii) term; (iv) yield; (v) recovery rate for the Series A Preferred Stock; (vi) estimated stock volatility; and (vii) risk-free rate. The fair value of the embedded derivative was determined using Level 3 inputs under the fair value hierarchy (unobservable inputs). Changes in the inputs into this valuation model have a material impact in the estimated fair value of the embedded derivative. For example, a decrease (increase) in the stock price and the volatility results in a decrease (increase) in the estimated fair value of the embedded derivative. The changes in the fair value of the bifurcated embedded derivative for the Series A Preferred Stock are primarily related to the change in the price of our common stock and are reflected in the condensed consolidated statements of operations as “Unrealized gain (loss) on derivative liability.”

[0001633978-19-000071:notes:144]
Through the date of conversion, holders of Series A Preferred Stock, in preference to holders of common stock or any other class or series of our outstanding capital stock ranking in any such event junior to the Series A Preferred Stock, were entitled to receive, when and as declared by the board of directors, quarterly cumulative cash dividends at the annual rate of 2.5% of the Issuance Value per share on each outstanding share of Series A Preferred Stock. The accrued dividends were payable on March 31, June 30, September 30 and December 31 of each year commencing on September 30, 2015. The accrued dividends as of November 2, 2018, the effective date of the conversion of all outstanding Series A Preferred Stock, was $0.3 million. During the three months ended September 29, 2018, we paid $0.4 million in dividends to the holders of Series A Preferred Stock. 
Prior to the conversion of the Series A Preferred Stock on November 2, 2018, we marked to market the embedded derivative, resulting in a gain of $10.9 million in our second quarter of fiscal 2019. In connection with the conversion of the Series A Preferred Stock on November 2, 2018, we also recorded $79.4 million in additional paid in capital which is reflected within the condensed consolidated balance sheets as of September 28, 2019 and June 29, 2019. For the three months ended September 29, 2018, we recorded $2.1 million unrealized loss to our condensed consolidated statements of operations.


## us-gaap:DebtDisclosureTextBlock

[0001633978-19-000071:notes:145]
Convertible Notes

[0001633978-19-000071:notes:146]
In March 2017, we issued the 2024 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank National Association, as trustee (the “Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001633978-19-000071:notes:147]
The 2024 Notes bear interest at a rate of 0.25% per year. Interest on the 2024 Notes is payable semi-annually in arrears on March 15 and September 15 of each year, beginning on September 15, 2017. The 2024 Notes will mature on March 15, 2024, unless earlier repurchased by us or converted pursuant to their terms.

[0001633978-19-000071:notes:148]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share, a 132.5% premium to the fair market value at the date of issuance. Prior to the close of business on the business day immediately preceding December 15, 2023, the 2024 Notes will be convertible only under the following circumstances: (1) during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price, or $78.80 on each applicable trading day; (2) during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of notes for each trading day of such measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day; or (3) upon the occurrence of specified corporate events. On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their notes at any time. In addition, upon the occurrence of a make-whole fundamental change, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert 2024 Notes in connection with such make-whole fundamental change.

[0001633978-19-000071:notes:149]
We may not redeem the 2024 Notes prior to their maturity date and no sinking fund is provided for the 2024 Notes. Upon the occurrence of a fundamental change, holders may require us to repurchase all or a portion of their 2024 Notes for cash at a price equal to 100% of the principal amount of the 2024 Notes to be repurchased, plus any accrued and unpaid interest.

[0001633978-19-000071:notes:150]
We considered the features embedded in the 2024 Notes other than the conversion feature, including the holders’ put feature, our call feature, and the make-whole feature, and concluded that they are not required to be bifurcated and accounted for separately from the host debt instrument.

[0001633978-19-000071:notes:151]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. We incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. We amortize the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes is 5.4% per year. As of September 28, 2019, the remaining debt discount amortization period was 53 months.

[0001633978-19-000071:notes:152]
During the fiscal year ended July 1, 2017, we satisfied the TMA settlement condition. As such, the value of the conversion option will no longer be marked to market and was reclassified to additional paid-in capital within stockholders’ equity on our condensed consolidated balance sheet. The value of the conversion option at the time of issuance will be treated as an original issue discount for purposes of accounting for the debt component of the notes. The debt component will accrete up to the principal

[0001633978-19-000071:notes:153]
amount over the expected term of the debt. These accounting standards do not affect the actual amount we are required to repay, and the amount shown in the table below for the notes is the aggregate principal amount of the notes and does not reflect the debt discount we will be required to recognize.

[0001633978-19-000071:notes:154]
The 2024 Notes consisted of the following components as of the periods presented (in millions):

[0001633978-19-000071:notes:155]
| Liability component: | September 28, 2019 |  | June 29, 2019 |
| Principal | $ | 450.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount | (93.5 | ) |  | (98.1 | ) |
| Net carrying amount of the liability component | $ | 356.5 |  |  | $ | 351.9 |  |

[0001633978-19-000071:notes:156]
The following table sets forth interest expense information related to the 2024 Notes for the periods presented (in millions, except percentages):

[0001633978-19-000071:notes:157]
|  | Three Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |
| Contractual interest expense | $ | 0.3 |  |  | $ | 0.3 |  |
| Amortization of the debt discount | 4.6 |  |  | 4.3 |  |
| Total interest expense | $ | 4.9 |  |  | $ | 4.6 |  |
| Effective interest rate on the liability component | 5.4 | % |  | 5.4 | % |

[0001633978-19-000071:notes:158]
We have the ability and intent to settle the $450 million face value of the debt in cash. Therefore, we use the treasury stock method for calculating the dilutive impact of the debt. The 2024 Notes will have no impact to diluted earnings per share until the average price of our common stock exceeds the conversion price of $60.62.

[0001633978-19-000071:notes:159]
Term Loan Facility

[0001633978-19-000071:notes:160]
On March 11, 2018, in connection with the Oclaro merger, we entered into a commitment letter with Deutsche Bank Securities Inc. and Deutsche Bank AG New York Branch (“Deutsche Bank”), pursuant to which Deutsche Bank committed to provide a senior secured term loan facility to finance the merger.

[0001633978-19-000071:notes:161]
On December 10, 2018 (the “Closing Date”), concurrent with the closing of the Oclaro merger, we entered into a Credit and Guarantee Agreement (the “Credit Agreement”), by and among us, certain of our subsidiaries, the lenders party thereto, and Deutsche Bank, as administrative agent and collateral agent for the lenders. The Credit Agreement provides for a senior secured term loan facility (the “Term Loan Facility”) in an aggregate principal amount of $500.0 million. The term loans available under the Term Loan Facility were fully drawn on the Closing Date and the proceeds of the term loans were used to consummate the merger and pay fees and expenses in connection with the merger and the Term Loan Facility.

[0001633978-19-000071:notes:162]
The term loans will mature on the seventh anniversary of the Closing Date, at which time all outstanding principal and accrued and unpaid interest on the term loans must be repaid.  Commencing on the last business day of the first full fiscal quarter after the Closing Date, the term loans will amortize in equal quarterly installments equal to 0.25% of the original principal amount of the Term Loans, with the balance payable due on December 10, 2025, the maturity date. We are required to make mandatory prepayments of the outstanding principal amount of term loans with the net cash proceeds from the disposition of certain assets and the receipt of insurance proceeds upon certain casualty and condemnation events, in each case, to the extent in excess of the certain threshold amounts and to the extent not reinvested within a specified time period. We are also required to make mandatory prepayments of the outstanding principal amount of term loans from the incurrence of certain types of indebtedness and from any excess cash flow beyond stated threshold amounts. We have the right to prepay the term loans, in whole or in part, at any time without premium or penalty, subject to certain limitations and a 1.00% soft call premium applicable during the first six months following the Closing Date.

[0001633978-19-000071:notes:163]
The term loans bear interest at a rate equal to an applicable margin plus, at our option, either (a) a base rate equal to the highest of (i) the prime rate then in effect, (ii) the federal funds rate, plus 0.50% and (iii) an adjusted LIBOR rate determined on the basis of a one-month interest period, plus 1.0%, subject to a floor of 0.0%, or (b) an adjusted LIBOR rate, subject to a floor of 0.0%. The applicable margin with respect to the initial term loans is equal to 2.50% in the case of LIBOR rate loans and 1.50% in the case of base rate loans. The applicable margin is adjusted following the first full fiscal quarter after the Closing Date, if our

[0001633978-19-000071:notes:164]
first lien net leverage ratio is equal to or less than 0.50:1.00, to 2.25% in the case of LIBOR rate loans and 1.25% in the case of base rate loans. During the three months ended September 28, 2019, we recorded a contractual interest expense of $6.1 million related to the term loans, which is included in interest expense in our condensed consolidated statements of operations.

[0001633978-19-000071:notes:165]
The commitment letter with Deutsche Bank required payment of a ticking fee. During the three months ended September 29, 2018, we recorded total expenses in connection with the ticking fee of $0.4 million. This ticking fee expense was included in interest expense in our condensed consolidated statements of operations.

[0001633978-19-000071:notes:166]
The Credit Agreement permits us to add one or more incremental term loan facilities. Incremental loans are subject to certain additional conditions, including, without limitation, obtaining additional commitments from the lenders then party to the Credit Agreement or from new lenders.

[0001633978-19-000071:notes:167]
Our obligations under the Credit Agreement are required to be guaranteed by certain of our domestic subsidiaries meeting materiality thresholds set forth in the Credit Agreement. Such obligations, including the guaranties, are secured by substantially all of the assets of Lumentum and Lumentum’s subsidiary guarantors (other than customarily excluded assets) pursuant to a Pledge and Security Agreement, dated as of December 10, 2018, by and among Lumentum and Deutsche Bank.

[0001633978-19-000071:notes:168]
The Credit Agreement contains customary affirmative and negative covenants, including covenants limiting the ability of Lumentum and its restricted subsidiaries to, among other things, incur debt, grant liens, undergo certain fundamental changes, make investments, make certain restricted payments, dispose of assets, and enter into transactions with affiliates, in each case, subject to limitations and exceptions set forth in the Credit Agreement. The Credit Agreement also contains customary events of default that include, among other things, certain payment defaults, cross defaults to other indebtedness, covenant defaults, change of control defaults, judgment defaults, and bankruptcy and insolvency defaults. If an event of default exists, the lenders may require the immediate payment of all obligations under the Credit Agreement, and may exercise certain other rights and remedies provided for under the Credit Agreement, the other loan documents and applicable law. As of September 28, 2019, we were in compliance with all of the covenants.

[0001633978-19-000071:notes:169]
We incurred $9.3 million of debt issuance costs in connection with the Term Loan Facility which were capitalized and recorded as a contra liability in our condensed consolidated balance sheet. These costs will be amortized to interest expense using the effective interest rate method from the issuance date of December 10, 2018, through the end of the term of the loan. As of September 28, 2019, the effective interest rate was 4.88% and the stated interest rate was 4.61%.

[0001633978-19-000071:notes:170]
The following table sets forth balance sheet information related to the term loan as of the periods presented (in millions):

[0001633978-19-000071:notes:171]
|  | September 28, 2019 |  | June 29, 2019 |
| Principal | $ | 497.5 |  |  | $ | 500.0 |  |
| Repayment of principal | — |  |  | (2.5 | ) |
| Unamortized value of the debt issuance costs | (8.2 | ) |  | (8.5 | ) |
| Net carrying value | $ | 489.3 |  |  | $ | 489.0 |  |
| Term loan, current | $ | 6.2 |  |  | $ | 5.0 |  |
| Term loan, non-current | $ | 483.1 |  |  | $ | 484.0 |  |

[0001633978-19-000071:notes:172]
The following table sets forth interest expense information related to the term loan, including interest expense associated with the ticking fee, for the periods presented (in millions):

[0001633978-19-000071:notes:173]
|  | Three Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |
| Contractual interest expense | $ | 6.1 |  |  | $ | 0.4 |  |
| Amortization of the debt issuance costs | 0.3 |  |  | — |  |
| Total interest expense | $ | 6.4 |  |  | $ | 0.4 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001633978-19-000071:notes:174]
Note 12. Defined Benefit Plans

[0001633978-19-000071:notes:175]
We sponsor defined benefit pension plans which provide benefits to our employees in Switzerland (the “Switzerland Plan”) and Japan (the “Japan Plan”).

[0001633978-19-000071:notes:176]
The Switzerland Plan is partially funded. As of September 28, 2019, our Switzerland Plan was under funded by $5.1 million since the projected benefit obligation (“PBO”) exceeded the fair value of the plan assets. The $5.1 million is recorded in our condensed consolidated balance sheets as non-current liabilities.

[0001633978-19-000071:notes:177]
Our Japan Plan, which was assumed in connection with our acquisition of Oclaro on December 10, 2018, is unfunded. As of September 28, 2019, we had an obligation of $3.0 million, which is reflective of the total PBO and is recorded in our condensed consolidated balance sheets as non-current liabilities.

[0001633978-19-000071:notes:178]
The net periodic benefit cost of the Switzerland Plan and Japan Plan are comprised of the following components (in millions):

[0001633978-19-000071:notes:179]
|  | Three Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |
| Service cost | $ | 0.3 |  |  | $ | 0.2 |  |
| Expected return on plan assets | (0.1 | ) |  | (0.1 | ) |
| Amortization of net (gain) loss | 0.1 |  |  | 0.1 |  |
| Net periodic pension cost | $ | 0.3 |  |  | $ | 0.2 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001633978-19-000071:notes:180]
Note 13. Accumulated Other Comprehensive Income (Loss)

[0001633978-19-000071:notes:181]
[same as prior period, unchanged from 0001633978-19-000030:notes:122]

[0001633978-19-000071:notes:182]
The changes in accumulated other comprehensive income (loss) by component and related tax effects for each period presented were as follows (in millions):

[0001633978-19-000071:notes:183]
|  | Foreign currency translation adjustments, net of tax (1) |  | Defined benefit obligations, net of tax (2) |  | Unrealized gain (loss) on available-for-sale securities, net of tax (3) |  | Total |
| Beginning balance as of June 29, 2019 | $ | 9.7 |  |  | $ | (3.5 | ) |  | $ | 0.9 |  |  | $ | 7.1 |  |
| Other comprehensive income (4) | — |  |  | — |  |  | 0.1 |  |  | 0.1 |  |
| Ending balance as of September 28, 2019 | $ | 9.7 |  |  | $ | (3.5 | ) |  | $ | 1.0 |  |  | $ | 7.2 |  |
| Beginning balance as of June 30, 2018 | $ | 10.3 |  |  | $ | (2.3 | ) |  | $ | (1.6 | ) |  | $ | 6.4 |  |
| Other comprehensive income (4) | 0.1 |  |  | — |  |  | 0.4 |  |  | 0.5 |  |
| Ending balance as of September 29, 2018 | $ | 10.4 |  |  | $ | (2.3 | ) |  | $ | (1.2 | ) |  | $ | 6.9 |  |

[0001633978-19-000071:notes:184]
(1) In fiscal 2019, as a result of significant changes in economic facts and circumstances, primarily due to the acquisition of Oclaro, we established the functional currency for our worldwide operations as the U.S. dollar. Translation adjustments reported prior to December 10, 2018, remain as a component of accumulated other comprehensive income in our condensed consolidated balance sheets.

[0001633978-19-000071:notes:185]
(2) We evaluate the assumptions over the fair value of our defined benefit obligations annually and make changes as necessary.

[0001633978-19-000071:notes:186]
(3) As of September 28, 2019 and June 29, 2019, unrealized gain on available-for-sale securities is presented in the table above as net of tax of $0.2 million.

[0001633978-19-000071:notes:187]
(4) For the periods presented in the table above, tax effects were not material.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001633978-19-000071:notes:188]
[same as prior period, unchanged from 0001633978-19-000030:notes:302]

[0001633978-19-000071:notes:189]
We have initiated various strategic restructuring actions primarily intended to reduce costs, consolidate our operations, streamline the manufacturing of our products and align our business in response to market conditions and as a result of our acquisition of Oclaro on December 10, 2018.

[0001633978-19-000071:notes:190]
The following table summarizes the activity of restructuring and related charges during the three months ended September 28, 2019 and September 29, 2018 (in millions):

[0001633978-19-000071:notes:191]
|  | Three Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |
| Balance as of beginning of period | $ | 14.6 |  |  | $ | 1.9 |  |
| Charges | 1.3 |  |  | 1.3 |  |
| Payments | (5.2 | ) |  | (1.6 | ) |
| Balance as of end of period | $ | 10.7 |  |  | $ | 1.6 |  |

[0001633978-19-000071:notes:192]
During the three months ended September 28, 2019 and September 29, 2018, we recorded $1.3 million in restructuring and related charges in each of the respective period, in our condensed consolidated statements of operations.

[0001633978-19-000071:notes:193]
| • | During the first quarter of fiscal 2020, we recorded restructuring and related charges of $1.3 million attributable to severance charges associated with ongoing acquisition related synergies. |

[0001633978-19-000071:notes:194]
| • | During the first quarter of fiscal 2019, we implemented an internal reorganization in order to extend our market leadership position by strengthening product quality, to develop new enabling technologies required to support a long-term portfolio roadmap, and to develop commercial proposals and new product introduction priorities to maintain and grow our position while driving new customer and ecosystem partner engagements. In connection with this reorganization, we recorded restructuring and related charges of $1.3 million related to severance and employee related benefits. |

[0001633978-19-000071:notes:195]
[same as prior period, unchanged from 0001633978-19-000030:notes:311]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001633978-19-000071:notes:196]
Note 15. Income Taxes

[0001633978-19-000071:notes:197]
Our tax provision for interim periods is determined using an estimate of our annual effective tax rate, adjusted for discrete items, if any, that arise during the period. Each quarter, we update our estimate of the annual effective tax rate, and if the estimated annual effective tax rate changes, we make a cumulative adjustment in such period. Our quarterly tax provision and estimate of our annual effective tax rate are subject to variation due to several factors, including variability in pre-tax income (or loss), the mix of jurisdictions to which such income relates, changes in how we do business, and tax law developments.

[0001633978-19-000071:notes:198]
We recorded a tax provision of $5.8 million and $5.2 million for the three months ended September 28, 2019 and September 29, 2018, respectively. Our estimated effective tax rate for the fiscal 2020 differs from the 21% U.S. statutory rate primarily due to the income tax benefit of the earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate as well as the U.S. federal R&D and foreign  tax credits, partially offset by the income tax expense from non-deductible stock-based compensation and the tax effect of Global Intangible Low-Taxed Income (“GILTI”), Base Erosion and Anti-Abuse Tax (“BEAT”), and subpart F inclusion.

[0001633978-19-000071:notes:199]
As of September 28, 2019, we had $18.8 million of unrecognized tax benefits, which, if recognized, would affect the effective tax rate. We are subject to examination of income tax returns by various domestic and foreign tax authorities. The timing of commencement, resolution and closure of tax audits is highly unpredictable. Although it is possible that certain ongoing tax audits may be concluded within the next 12 months, we cannot reasonably estimate the impact to tax expense and net income from tax exams that could be resolved or closed within next 12 months. Subject to audit timing and uncertainty, we expect our unrecognized tax benefit amount that could affect the effective tax rate to decrease by $3.9 million over the next 12 months.

[0001633978-19-000071:notes:200]
We believe that we have adequately provided under GAAP for potential outcomes related to our tax audits. However, there can be no assurances as to the possible outcomes or any related financial statement effect thereof.

[0001633978-19-000071:notes:201]
On June 7, 2019, the U.S. Court of Appeals for the Ninth Circuit, reversing a previous decision of the U.S. Tax Court, held that the U.S. Treasury Department’s regulations requiring the inclusion of stock-based compensation expense in a taxpayer’s cost-

[0001633978-19-000071:notes:202]
sharing calculations were valid. Our financial statements have been prepared consistent with this outcome, but we will continue to monitor any ongoing developments, including the outcome of the taxpayer’s July 22, 2019 request for an en banc rehearing or a potential appeal to the U.S. Supreme Court, to determine if future changes are required.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001633978-19-000071:notes:203]
Note 16. Stock-Based Compensation and Stock Plans

[0001633978-19-000071:notes:204]
[same as prior period, unchanged from 0001633978-19-000030:notes:140]

[0001633978-19-000071:notes:205]
[same as prior period, unchanged from 0001633978-19-000030:notes:141]

[0001633978-19-000071:notes:206]
As of September 28, 2019, we had 2.8 million shares subject to stock options, restricted stock units, restricted stock awards, and performance stock units issued and outstanding under the 2015 Equity Incentive Plan (the “2015 Plan”).

[0001633978-19-000071:notes:207]
Restricted stock units, restricted stock awards and performance stock units are performance-based, time-based or a combination of both. The fair value of these grants is based on the closing market price of our common stock on the date of award.

[0001633978-19-000071:notes:208]
As of September 28, 2019, 3.7 million shares of common stock under the 2015 Plan were available for grant.

[0001633978-19-000071:notes:209]
[same as prior period, unchanged from 0001633978-19-000030:notes:147]

[0001633978-19-000071:notes:210]
[same as prior period, unchanged from 0001633978-19-000030:notes:148]

[0001633978-19-000071:notes:211]
[same as prior period, unchanged from 0001633978-19-000030:notes:149]

[0001633978-19-000071:notes:212]
[same as prior period, unchanged from 0001633978-19-000030:notes:150]

[0001633978-19-000071:notes:213]
[same as prior period, unchanged from 0001633978-19-000030:notes:151]

[0001633978-19-000071:notes:214]
[same as prior period, unchanged from 0001633978-19-000030:notes:152]

[0001633978-19-000071:notes:215]
[same as prior period, unchanged from 0001633978-19-000030:notes:154]

[0001633978-19-000071:notes:216]
Our 2015 Employee Stock Purchase Plan (the “2015 Purchase Plan”) provides eligible employees with the opportunity to acquire an ownership interest in the Company through periodic payroll deductions and provides a 15% purchase price discount as well as a six-month look-back period. The 2015 Purchase Plan is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986. However, the 2015 Purchase Plan is not intended to be a qualified pension, profit sharing or stock bonus plan under Section 401(a) of the Internal Revenue Code of 1986 and is not subject to the provisions of the Employee Retirement Income Security Act of 1974. The 2015 Purchase Plan will terminate upon the date on which all shares available for issuance have been sold. Of the 3.0 million shares authorized under the 2015 Purchase Plan, 2.0 million shares remained available for issuance as of September 28, 2019.

[0001633978-19-000071:notes:217]
During the three months ended September 28, 2019, our board of directors preliminarily approved the grant of 0.07 million PSUs to senior members of our management team. The grant date has not been established for these awards as the performance targets will be set and approved in the second quarter of fiscal 2020. As such, no stock-based compensation has been recorded for these grants during the three months ended September 28, 2019.

[0001633978-19-000071:notes:218]
[same as prior period, unchanged from 0001633978-19-000030:notes:156]

[0001633978-19-000071:notes:219]
The impact on our results of operations of recording stock-based compensation by function for the three months ended September 28, 2019 and September 29, 2018 was as follows (in millions):

[0001633978-19-000071:notes:220]
|  | Three Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |
| Cost of sales | $ | 4.2 |  |  | $ | 3.3 |  |
| Research and development | 3.8 |  |  | 2.8 |  |
| Selling, general and administrative | 8.7 |  |  | 4.7 |  |
| Total stock-based compensation | $ | 16.7 |  |  | $ | 10.8 |  |

[0001633978-19-000071:notes:221]
Total income tax benefit associated with stock-based compensation recognized in our consolidated statements of operations during the years presented was as follows (in millions):

[0001633978-19-000071:notes:222]
|  | Three Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |
| Income tax benefit associated with stock-based compensation | $ | 2.8 |  |  | $ | 2.9 |  |

[0001633978-19-000071:notes:223]
Approximately $3.3 million and $3.5 million of stock-based compensation was capitalized to inventory as of September 28, 2019 and June 29, 2019, respectively.

[0001633978-19-000071:notes:224]
[same as prior period, unchanged from 0001633978-19-000030:notes:161]

[0001633978-19-000071:notes:225]
The following table summarizes our awards activity for the three months ended September 28, 2019 (in millions, except per share amounts):

[0001633978-19-000071:notes:226]
|  | Stock Options |  | Restricted Stock Units |  | Restricted Stock Awards |  | Performance Stock Units |
|  | Number of Shares |  | Weighted-Average Exercise Price per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance as of June 29, 2019 | — |  |  | $ | 38.8 |  |  | 2.2 |  |  | $ | 52.4 |  |  | — |  |  | $ | 32.5 |  |  | 0.2 |  |  | $ | 56.0 |  |
| Granted | — |  |  | — |  |  | 0.9 |  |  | 58.5 |  |  | — |  |  | — |  |  | 0.2 |  |  | 58.7 |  |
| Vested/Exercised | — |  |  | 31.5 |  |  | (0.5 | ) |  | 54.3 |  |  | — |  |  | 32.5 |  |  | (0.1 | ) |  | 56.4 |  |
| Canceled | — |  |  | 29.4 |  |  | (0.1 | ) |  | 51.8 |  |  | — |  |  | — |  |  | — |  |  | 57.3 |  |
| Balance as of September 28, 2019 | — |  |  | $ | 41.3 |  |  | 2.5 |  |  | $ | 54.4 |  |  | — |  |  | $ | — |  |  | 0.3 |  |  | $ | 57.3 |  |

[0001633978-19-000071:notes:227]
As of September 28, 2019, $140.3 million of stock-based compensation cost related to awards granted to our employees remains to be amortized. That cost is expected to be recognized over an estimated amortization period of 2.2 years.

[0001633978-19-000071:notes:228]
[same as prior period, unchanged from 0001633978-19-000030:notes:168]

[0001633978-19-000071:notes:229]
|  | Awards Available for Grant |
| Balance as of June 29, 2019 | 4.7 |  |
| Granted | (1.1 | ) |
| Canceled | 0.1 |  |
| Balance as of September 28, 2019 | 3.7 |  |

[0001633978-19-000071:notes:230]
[same as prior period, unchanged from 0001633978-19-000030:notes:170]

[0001633978-19-000071:notes:231]
The 2015 Purchase Plan expense for the three months ended September 28, 2019 and September 29, 2018 was $0.9 million

[0001633978-19-000071:notes:232]
and $1.0 million, respectively. The expense related to the 2015 Purchase Plan is recorded on a straight-line basis over the relevant subscription period. During the three months ended September 28, 2019 and September 29, 2018 there were no shares issued to employees through the 2015 Purchase Plan.

[0001633978-19-000071:notes:233]
We estimate the fair value of the 2015 Purchase Plan shares on the date of grant using the Black-Scholes option-pricing model. During each of the three months ended September 28, 2019 and September 29, 2018, the assumptions used to estimate the fair value of the 2015 Purchase Plan shares to be issued were as follows:

[0001633978-19-000071:notes:234]
|  | September 28, 2019 |  | September 29, 2018 |
| Expected term (years) | 0.5 |  |  | 0.5 |  |
| Expected volatility | 60.1 | % |  | 58.8 | % |
| Risk-free interest rate | 2.47 | % |  | 2.02 | % |
| Dividend yield | — | % |  | — | % |


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001633978-19-000071:notes:235]
Note 17. Commitments and Contingencies

[0001633978-19-000071:notes:236]
Acquisition Contingencies

[0001633978-19-000071:notes:237]
In February 2017, we incurred liabilities in the amount of $3.6 million related to an acquisition of a privately held company (based on the exchange rate at the date of acquisition). The purchase price retainer for the seller’s indemnification obligations was paid to the seller in fiscal 2019, and the contingent liability of $3.0 million (actual payment is subject to the then applicable exchange rate) is expected to be paid within the next 12 months contingent upon meeting certain production targets. We estimated the fair value of the contingent consideration to be $3.0 million and recorded this amount in other current liabilities within our condensed consolidated balance sheet as of September 28, 2019.

[0001633978-19-000071:notes:238]
Term Loan

[0001633978-19-000071:notes:239]
The estimated future interest and principal payments related to the term loan are as follows as of September 28, 2019 (in millions):

[0001633978-19-000071:notes:240]
| Fiscal Years |  |
| Remainder of 2020 | $ | 31.0 |  |
| 2021 | 27.6 |  |
| 2022 | 27.3 |  |
| 2023 | 27.1 |  |
| 2024 | 26.9 |  |
| Thereafter | 497.1 |  |
| Total term loan payments | $ | 637.0 |  |

[0001633978-19-000071:notes:241]
0.25% Convertible Notes due 2024

[0001633978-19-000071:notes:242]
The future interest and principal payments related to the 2024 Notes are as follows as of September 28, 2019 (in millions):

[0001633978-19-000071:notes:243]
| Fiscal Years |  |
| Remainder of 2020 | $ | 0.5 |  |
| 2021 | 1.1 |  |
| 2022 | 1.1 |  |
| 2023 | 1.1 |  |
| 2024 | 451.2 |  |
| Thereafter | — |  |
| Total 2024 Notes payments | $ | 455.0 |  |

[0001633978-19-000071:notes:244]
Purchase Obligations

[0001633978-19-000071:notes:245]
Purchase obligations of $277.6 million as of September 28, 2019, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements.

[0001633978-19-000071:notes:246]
Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001633978-19-000071:notes:247]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with such vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

[0001633978-19-000071:notes:248]
Product Warranties

[0001633978-19-000071:notes:249]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, product component or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001633978-19-000071:notes:250]
The following table presents the changes in our warranty reserve during the three months ended September 28, 2019 and September 29, 2018 (in millions):

[0001633978-19-000071:notes:251]
|  | Three Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |
| Balance as of beginning of period | $ | 7.5 |  |  | $ | 6.6 |  |
| Provision for warranty | 1.2 |  |  | 1.2 |  |
| Utilization of reserve | (1.7 | ) |  | (1.2 | ) |
| Balance as of end of period | $ | 7.0 |  |  | $ | 6.6 |  |

[0001633978-19-000071:notes:252]
Environmental Liabilities

[0001633978-19-000071:notes:253]
Our research and development (“R&D”), manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental, product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001633978-19-000071:notes:254]
Legal Proceedings

[0001633978-19-000071:notes:255]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss. As of September 28, 2019, we did not have any material claims or proceedings that were probable or reasonably possible.

[0001633978-19-000071:notes:256]
Merger Litigation

[0001633978-19-000071:notes:257]
In connection with our acquisition of Oclaro, seven lawsuits were filed by purported stockholders of Oclaro challenging the proposed merger (the “Merger”). Two of the seven suits were putative class actions filed against Oclaro, its directors, Lumentum, Prota Merger Sub, Inc. and Prota Merger, LLC: Nicholas Neinast v. Oclaro, Inc., et al., No. 3:18-cv-03112-VC, in the United States District Court for the Northern District of California (filed May 24, 2018) (the “Neinast Lawsuit”); and Adam Franchi v. Oclaro, Inc., et al., No. 1:18-cv-00817-GMS, in the United States District Court for the District of Delaware (filed June 9, 2018) (the “Franchi Lawsuit”). Both the Neinstat Lawsuit and the Franchi Lawsuit were voluntarily dismissed with prejudice.

[0001633978-19-000071:notes:258]
The other five suits, styled as Gerald F. Wordehoff v. Oclaro, Inc., et al., No. 5:18-cv-03148-NC (the “Wordehoff Lawsuit”), Walter Ryan v. Oclaro, Inc., et al., No. 3:18-cv-03174-VC (the “Ryan Lawsuit”), Jayme Walker v. Oclaro, Inc., et al., No. 5:18-cv-03203-EJD (the “Walker Lawsuit”), Kevin Garcia v. Oclaro, Inc., et al., No. 5:18-cv-03262-VKD (the “Garcia Lawsuit”), and SaiSravan B. Karri v. Oclaro, Inc., et al., No. 3:18-cv-03435-JD (the “Karri Lawsuit” and, together with the other six lawsuits, the “Lawsuits”), were filed in the United States District Court for the Northern District of California on May 25, 2018, May 29, 2018, May 30, 2018, May 31, 2018, and June 9, 2018, respectively. These five Lawsuits named Oclaro and its directors as defendants only and did not name Lumentum. The Wordehoff, Ryan, Walker, and Garcia Lawsuits have been voluntarily dismissed, and the Wordehoff, Ryan, and Walker dismissals were with prejudice. The Karri Lawsuit has not yet been dismissed. The Ryan Lawsuit was, and the Karri Lawsuit is, a putative class action.

[0001633978-19-000071:notes:259]
The Lawsuits generally alleged, among other things, that Oclaro and its directors violated Section 14(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), and Rule 14a-9 promulgated thereunder by disseminating an incomplete and misleading Form S-4, including proxy statement/prospectus. The Lawsuits further alleged that Oclaro’s directors violated Section 20(a) of the Exchange Act by failing to exercise proper control over the person(s) who violated Section 14(a) of the Exchange Act.

[0001633978-19-000071:notes:260]
The remaining Lawsuit (the Karri Lawsuit) currently purports to seek, among other things, damages to be awarded to the plaintiff and any class, if a class is certified, and litigation costs, including attorneys’ fees.  A lead plaintiff and counsel has been selected, and an amended complaint was filed on April 15, 2019, which also names Lumentum as a defendant.  A motion to dismiss the amended complaint has been filed and is currently pending, and defendants intend to defend the Karri Lawsuit vigorously.

[0001633978-19-000071:notes:261]
Indemnifications

[0001633978-19-000071:notes:262]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of September 28, 2019, we did not have any material indemnification claims that were probable or reasonably possible.

[0001633978-19-000071:notes:263]
Audit Proceedings

[0001633978-19-000071:notes:264]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.
In connection with our acquisition of Oclaro, we recorded $1.1 million in Malaysia Goods and Services Tax (“GST”) refund claims within prepaid expenses and other current assets in our condensed consolidated balance sheet. The refund claim represents an initial claim of $2.5 million of GST, net of reserves, that were previously denied by the Malaysian tax authorities in 2016. During the three months ended September 28, 2019, we were able to favorably resolve this audit and we received refunds for the majority of our outstanding GST claims, with the remaining amounts expected to be received in our second quarter of fiscal 2020.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001633978-19-000071:notes:265]
Note 18. Operating Segments and Geographic Information

[0001633978-19-000071:notes:266]
[same as prior period, unchanged from 0001633978-19-000030:notes:333]

[0001633978-19-000071:notes:267]
We are an industry leading provider of optical and photonic products defined by revenue and market share addressing a range of end-market applications including optical communications and commercial lasers. We have two operating segments, Optical Communications, which we refer to as OpComms, and Commercial Lasers, which we refer to as Lasers. Our OpComms products address the following markets: telecommunications and data communications (“Telecom and Datacom”), and consumer and industrial (“Consumer and Industrial”), and include product lines from the recent acquisition of Oclaro. The two operating segments were primarily determined based on how the CODM views and evaluates our operations. Operating results are regularly reviewed by the CODM to make decisions about resources to be allocated to the segments and to assess their performance. Other factors, including market separation and customer specific applications, go-to-market channels, products and manufacturing, are considered in determining the formation of these operating segments.

[0001633978-19-000071:notes:268]
[same as prior period, unchanged from 0001633978-19-000030:notes:335]

[0001633978-19-000071:notes:269]
Information on reportable segments utilized by our CODM is as follows (in millions):

[0001633978-19-000071:notes:270]
|  | Three Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |
| Net revenue: |  |  |  |
| OpComms | $ | 416.1 |  |  | $ | 310.1 |  |
| Lasers | 33.8 |  |  | 44.0 |  |
| Net revenue | $ | 449.9 |  |  | $ | 354.1 |  |
| Gross profit: |  |  |  |
| OpComms | $ | 191.9 |  |  | $ | 124.9 |  |
| Lasers | 14.2 |  |  | 17.7 |  |
| Total segment gross profit | 206.1 |  |  | 142.6 |  |
| Unallocated corporate items: |  |  |  |
| Stock-based compensation | (4.2 | ) |  | (3.3 | ) |
| Amortization of acquired intangibles | (12.5 | ) |  | (0.8 | ) |
| Amortization of fair value adjustments | (2.2 | ) |  | — |  |
| Inventory write down due to product lines exit | (1.1 | ) |  | — |  |
| Integration related costs | (3.4 | ) |  | — |  |
| Other charges (1) | (15.0 | ) |  | (12.5 | ) |
| Gross profit | $ | 167.7 |  |  | $ | 126.0 |  |

[0001633978-19-000071:notes:271]
(1) “Other charges” of unallocated corporate items for the three months ended September 28, 2019 primarily include costs of transferring product lines to Thailand of $4.8 million as well as excess and obsolete charges driven by the decline in demand by Huawei of $6.7 million. During the three months ended September 29, 2018, “other charges” of unallocated corporate items primarily consisted of set-up costs of our facility in Thailand, including costs of transferring product lines to Thailand of $12.7 million.

[0001633978-19-000071:notes:272]
Disaggregation of Revenue

[0001633978-19-000071:notes:273]
We disaggregate revenue by product and by geography. We do not present other levels of disaggregation, such as by type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, as this information is not used by our CODM to manage the business.

[0001633978-19-000071:notes:274]
The table below discloses our total net revenue attributable to each of our two reportable segments. In addition, it discloses the percentage of our total net revenue attributable to our product offerings which serve Telecom and Datacom, and Consumer and Industrial markets which accounted for 10% or more of our total net revenue during the periods presented (in millions, except percentage data):

[0001633978-19-000071:notes:275]
|  | Three Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |
| OpComms: |  |  |  |  |  |  |  |
| Telecom and Datacom | $ | 248.1 |  | 55.2 | % |  | $ | 177.1 |  | 50.0 | % |
| Consumer and Industrial | 168.0 |  | 37.3 | % |  | 133.0 |  | 37.6 | % |
| Total OpComms | $ | 416.1 |  | 92.5 | % |  | $ | 310.1 |  | 87.6 | % |
| Lasers | 33.8 |  | 7.5 | % |  | 44.0 |  | 12.4 | % |
| Total Revenue | $ | 449.9 |  |  |  |  | $ | 354.1 |  |  |

[0001633978-19-000071:notes:276]
[same as prior period, unchanged from 0001633978-19-000030:notes:336]

[0001633978-19-000071:notes:277]
|  | Three Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |
|  | Amount |  | % of Total |  | Amount |  | % of Total |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 36.9 |  |  | 8.3 | % |  | $ | 21.9 |  |  | 6.2 | % |
| Mexico | 28.9 |  |  | 6.4 |  |  | 56.3 |  |  | 15.9 |  |
| Other Americas | 1.1 |  |  | 0.2 |  |  | 0.9 |  |  | 0.3 |  |
| Total Americas | $ | 66.9 |  |  | 14.9 | % |  | $ | 79.1 |  |  | 22.4 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |
| Hong Kong | $ | 133.8 |  |  | 29.7 | % |  | $ | 65.5 |  |  | 18.5 | % |
| South Korea | 91.6 |  |  | 20.4 |  |  | 70.0 |  |  | 19.8 |  |
| Japan | 32.5 |  |  | 7.2 |  |  | 36.1 |  |  | 10.2 |  |
| Other Asia-Pacific | 92.8 |  |  | 20.6 |  |  | 74.1 |  |  | 20.9 |  |
| Total Asia-Pacific | $ | 350.7 |  |  | 77.9 | % |  | $ | 245.7 |  |  | 69.4 | % |
| EMEA | $ | 32.3 |  |  | 7.2 | % |  | $ | 29.3 |  |  | 8.2 | % |
| Total net revenue | $ | 449.9 |  |  |  |  | $ | 354.1 |  |  |  |

[0001633978-19-000071:notes:278]
During the three months ended September 28, 2019 and September 29, 2018, net revenue from customers outside the United States, based on customer shipping location, represented 91.7% and 93.8% of net revenue, respectively. Our net revenue from Hong Kong grew due to increased sales of our 3D sensing products for mobile devices shipped to one of our large customers.

[0001633978-19-000071:notes:279]
Transaction Price Allocated to the Remaining Performance Obligations

[0001633978-19-000071:notes:280]
The following table includes estimated revenue expected to be recognized in the future for backlog related performance obligations that are unsatisfied as of September 28, 2019 (in millions):

[0001633978-19-000071:notes:281]
|  | Less than 1 year | 1-2 years | Greater than 2 years | Total |
| Performance obligations | $414.9 | $— | $— | $414.9 |

[0001633978-19-000071:notes:282]
Contract Balances

[0001633978-19-000071:notes:283]
The following table reflects the changes in contract balances as of September 28, 2019 (in millions, except percentages):

[0001633978-19-000071:notes:284]
| Contract balances | Balance sheet location | September 28, 2019 |  | June 29, 2019 |  | Change |  | Percentage Change |
| Accounts receivable, net | Accounts receivable, net | $292.8 |  | $238.0 |  | $54.8 |  | 23.0% |
| Deferred revenue and customer deposits | Other current liabilities | $2.5 |  | $2.9 |  | $(0.4) |  | (13.8)% |

[0001633978-19-000071:notes:285]
During the three months ended September 28, 2019 and September 29, 2018, our net revenue was concentrated with three customers, who collectively accounted for 58% and 59% of our total net revenue, respectively.

[0001633978-19-000071:notes:286]
As of September 28, 2019 and June 29, 2019, our accounts receivable balance was concentrated with three customers, who collectively represented 49% and 44% of gross accounts receivable, respectively.

[0001633978-19-000071:notes:287]
Long-lived assets, namely net property, plant and equipment, net, were identified based on the physical location of the assets in the corresponding geographic areas as of the periods indicated (in millions):

[0001633978-19-000071:notes:288]
|  | September 28, 2019 |  | June 29, 2019 |
| Property, plant and equipment, net |  |  |  |
| United States | $ | 155.9 |  |  | $ | 156.2 |  |
| Thailand | 144.1 |  |  | 157.1 |  |
| China | 51.9 |  |  | 33.5 |  |
| Japan | 28.3 |  |  | 28.3 |  |
| Other countries | 56.5 |  |  | 58.2 |  |
| Total long-lived assets | $ | 436.7 |  |  | $ | 433.3 |  |

[0001633978-19-000071:notes:289]
We purchase a substantial portion of our inventory from contract manufacturers and vendors located primarily in Taiwan, Thailand, and Malaysia. During the three months ended September 28, 2019 and September 29, 2018, net inventory purchases were concentrated with two contract manufacturers, who collectively accounted for 79% and 77% of total net inventory purchases, respectively.


## us-gaap:SubsequentEventsTextBlock

[0001633978-19-000071:notes:290]
Note 19. Subsequent Event

[0001633978-19-000071:notes:291]
On October 30, 2019, we made a voluntary pre-payment of principal amount under our term loan facility of $150.0 million. As a result of the early payment of the term loan, we will recognize a loss on early extinguishment of debt of approximately $2.5 million in our second quarter of fiscal 2020, which will be recorded in our interest expense.
