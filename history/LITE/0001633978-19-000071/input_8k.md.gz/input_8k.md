# LITE 8-K — 0001633978-19-000070 filed 2019-10-31

## item codes, every 8-K on or before 2019-10-31

- 2019-10-31 0001633978-19-000070 — 2.02, 9.01
- 2019-08-08 0001633978-19-000068 — 2.02, 9.01
- 2019-05-08 0001633978-19-000031 — 1.01
- 2019-05-07 0001633978-19-000029 — 2.02, 9.01
- 2019-02-15 0001633978-19-000005 — 9.01 — amendment of 0001193125-18-346211
- 2019-02-08 0001193125-19-031591 — 5.02, 9.01
- 2019-02-05 0001633978-19-000001 — 2.02, 9.01
- 2018-12-10 0001193125-18-346211 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-12-06 0001633978-18-000150 — 8.01
- 2018-11-14 0001633978-18-000139 — 5.07
- 2018-11-13 0001633978-18-000136 — 3.02
- 2018-11-13 0001633978-18-000132 — 7.01, 9.01
- 2018-11-01 0001628280-18-013238 — 2.02, 9.01
- 2018-08-08 0001633978-18-000056 — 2.02, 9.01
- 2018-06-08 0001193125-18-188241 — 5.02, 9.01
- 2018-05-02 0001633978-18-000029 — 2.02, 9.01
- 2018-03-12 0001193125-18-078154 — 1.01, 2.01, 8.01, 9.01
- 2018-02-06 0001628280-18-001082 — 2.02, 9.01
- 2017-11-08 0001633978-17-000133 — 5.02, 9.01
- 2017-11-07 0001633978-17-000131 — 5.07
- 2017-11-01 0001633978-17-000117 — 2.02, 9.01
- 2017-08-09 0001633978-17-000058 — 2.02, 9.01
- 2017-05-04 0001633978-17-000035 — 2.02, 9.01
- 2017-03-08 0001193125-17-074740 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2017-03-02 0001193125-17-066769 — 8.01, 9.01
- 2017-02-07 0001633978-17-000005 — 2.02, 9.01
- 2017-01-03 0001628280-17-000018 — 4.01, 9.01
- 2016-11-09 0001628280-16-021143 — 5.02, 5.07, 9.01
- 2016-10-27 0001628280-16-020382 — 2.02, 9.01
- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2019-10-31

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001633978-19-000070:8k_2_02:1]
EX-99.1
2
liteex991q1fy20.htm
EXHIBIT 99.1

[0001633978-19-000070:8k_2_02:2]
Exhibit

[0001633978-19-000070:8k_2_02:3]
NEWS RELEASE

[0001633978-19-000070:8k_2_02:4]
LUMENTUM ANNOUNCES FISCAL FIRST QUARTER 2020 RESULTS

[0001633978-19-000070:8k_2_02:5]
| • | Net revenue of $449.9 million |

[0001633978-19-000070:8k_2_02:6]
| • | GAAP operating margin of 13.3%; Non-GAAP operating margin of 27.3% |

[0001633978-19-000070:8k_2_02:7]
| • | GAAP diluted net income per share of $0.61; Non-GAAP diluted net income per share of $1.44 |

[0001633978-19-000070:8k_2_02:8]
San Jose, Calif., October 31, 2019 – Lumentum Holdings Inc. (“Lumentum” or the “Company”) today reported results for its fiscal first quarter of 2020 ended September 28, 2019.

[0001633978-19-000070:8k_2_02:9]
Net revenue for the fiscal first quarter of 2020 was $449.9 million, with GAAP net income of $47.6 million, or $0.61 per diluted share. Net revenue for the fiscal fourth quarter of 2019 was $404.6 million, with GAAP net loss to stockholders of $(25.8) million, or $(0.34) per diluted share. Net revenue for the fiscal first quarter of 2019 was $354.1 million, with GAAP net income attributable to common stockholders of $46.1 million, or $0.72 per diluted share.

[0001633978-19-000070:8k_2_02:10]
Non-GAAP net income for the fiscal first quarter of 2020 was $111.4 million, or $1.44 per diluted share. Non-GAAP net income for the fiscal fourth quarter of 2019 was $70.4 million, or $0.91 per diluted share. Non-GAAP net income for the fiscal first quarter of 2019 was $86.1 million, or $1.32 per diluted share.

[0001633978-19-000070:8k_2_02:11]
The Company held $830.9 million in total cash and short-term investments at the end of the fiscal first quarter of 2020. Subsequent to the first quarter, on October 30, 2019, the Company made a $150 million voluntary principal pre-payment under its term loan facility.

[0001633978-19-000070:8k_2_02:12]
“Our strong first quarter performance highlights our continued progress toward our long-term strategic and financial goals, with a revenue mix richer in newer and more innovative products, increased scale, and acquisition synergies all driving sequential and year on year improvements in gross and operating margins,” said Alan Lowe, Lumentum President and CEO.  “In particular, improvements in telecom and datacom margins helped first quarter non-GAAP gross margin expand significantly year on year to more than 45% for the first time. As we look to our second quarter, we are seeing strengthening demand for key differentiated products in telecom, datacom, and commercial lasers.”

[0001633978-19-000070:8k_2_02:13]
Financial Overview – Fiscal First Quarter Ended September 28, 2019

[0001633978-19-000070:8k_2_02:14]
|  | GAAP Results ($ in millions) |
|  | Q1 |  | Q4 |  | Q1 |  | Change |
|  | FY 2020 |  | FY 2019 |  | FY 2019 |  | Q/Q |  | Y/Y |
| Net revenue | $449.9 |  | $404.6 |  | $354.1 |  | 11.2% |  | 27.1% |
| Gross margin | 37.3% |  | 21.5% |  | 35.6% |  | 1,580bps |  | 170bps |
| Operating margin (loss) | 13.3% |  | (3.4)% |  | 16.1% |  | 1,670bps |  | (280)bps |
|  | Non-GAAP Results ($ in millions) |
|  | Q1 |  | Q4 |  | Q1 |  | Change |
|  | FY 2020 |  | FY 2019 |  | FY 2019 |  | Q/Q |  | Y/Y |
| Net revenue | $449.9 |  | $404.6 |  | $354.1 |  | 11.2% |  | 27.1% |
| Gross margin | 45.8% |  | 38.9% |  | 40.3% |  | 690bps |  | 550bps |
| Operating margin | 27.3% |  | 19.0% |  | 23.9% |  | 830bps |  | 340bps |

[0001633978-19-000070:8k_2_02:15]
|  | Net Revenue by Segment ($ in millions) |
|  | Q1 |  | % of |  | Q4 |  | Q1 |  | Change |
|  | FY 2020 |  | Net Revenue |  | FY 2019 |  | FY 2019 |  | Q/Q |  | Y/Y |
| Optical Communications | $ | 416.1 |  |  | 92.5 | % |  | $ | 356.8 |  |  | $ | 310.1 |  |  | 16.6 | % |  | 34.2 | % |
| Lasers | 33.8 |  |  | 7.5 | % |  | 47.8 |  |  | 44.0 |  |  | (29.3 | )% |  | (23.2 | )% |
| Total | $ | 449.9 |  |  | 100.0 | % |  | $ | 404.6 |  |  | $ | 354.1 |  |  | 11.2 | % |  | 27.1 | % |

[0001633978-19-000070:8k_2_02:16]
The tables above provide comparisons of quarterly results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled “Use of Non-GAAP Financial Measures.”

[0001633978-19-000070:8k_2_02:17]
Effective June 30, 2019, we adopted Topic 842, using the modified retrospective transition approach. We applied the new guidance to all leases existing as of the date of adoption. Our reported results for the first quarter of fiscal 2020 reflect the application of Topic 842, while prior period amounts have not been adjusted and continue to be reported in accordance with our historical accounting under Topic 840.

[0001633978-19-000070:8k_2_02:18]
Business Outlook

[0001633978-19-000070:8k_2_02:19]
Lumentum expects the following for the fiscal second quarter 2020:

[0001633978-19-000070:8k_2_02:20]
•Net revenue in the range of $445 million to $460 million

[0001633978-19-000070:8k_2_02:21]
•Non-GAAP operating margin of 24% to 26%

[0001633978-19-000070:8k_2_02:22]
•Non-GAAP diluted earnings per share of $1.20 to $1.35

[0001633978-19-000070:8k_2_02:23]
We have not provided reconciliations from GAAP to non-GAAP measures for our outlook. A large portion of non-GAAP adjustments, such as restructuring charges, stock-based compensation, acquisition-related costs, non-cash income tax expense and credits, amortization of fair value adjustments, integration related costs, impairment charges, inventory write down due to plans to exit certain product lines and other costs and contingencies unrelated to current and future operations are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future.

[0001633978-19-000070:8k_2_02:24]
Conference Call

[0001633978-19-000070:8k_2_02:25]
Lumentum will host a conference call on October 31, 2019, at 5:30 am PT/8:30 am ET. A live webcast of the call and the replay will be available on the Lumentum website at http://investor.lumentum.com through November 7, 2019, at 11:59 pm ET. To listen to the live conference call, dial (866) 393-4306 or (734) 385-2616 and reference the passcode 9321408.  A replay of the conference call will be available through November 7, 2019. To access the replay, dial (855) 859-2056 or (404) 537-3406. The passcode for the replay is 9321408. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the “Events and Presentations” section concurrently with this earnings press release. This press release is being furnished as an exhibit to a Current Report on Form 8-K filed with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001633978-19-000070:8k_2_02:26]
About Lumentum

[0001633978-19-000070:8k_2_02:27]
Lumentum (NASDAQ: LITE) is a market-leading designer and manufacturer of innovative optical and photonic products enabling optical networking and laser applications worldwide.  Lumentum’s optical components and subsystems are part of virtually every type of telecom, enterprise, and data center network.  Lumentum’s lasers enable advanced manufacturing techniques and diverse applications including next-generation 3D sensing capabilities. Lumentum is headquartered in San Jose, California with R&D, manufacturing, and sales offices worldwide.  For more information, visit www.lumentum.com.

[0001633978-19-000070:8k_2_02:28]
Forward-Looking Statements

[0001633978-19-000070:8k_2_02:29]
statements involve risks and uncertainties that could cause actual results to differ materially from those projected. Among the factors that could cause actual results to differ from those contemplated are: (a) quarter-over-quarter product mix fluctuations which can materially impact profitability measures due to the broad gross margin ranges across our portfolio; (b) continued decline of average selling prices across our businesses; (c) effects of seasonality; (d) the ability of our suppliers and contract manufacturers to meet production and delivery requirements for our forecasted demand; (e) inherent uncertainty related to global markets, including changes in the political or economic environment and the imposition of tariffs or other duties, and the effect of such markets on demand for our products; (f) changes in customer demand; (g) our ability to attract and retain new customers, particularly in the 3D sensing market; (h) the risk that synergies and non-GAAP earnings accretion related to the acquisition of Oclaro will not be realized or realized to the extent anticipated or that we will incur significant costs and charges to achieve such synergies; (i) the risk that Lumentum’s financing or operating strategies will not be successful; and (j) disruption related to the acquisition and integration of Oclaro making it more difficult to maintain customer, supplier, key personnel and other strategic relationships. For more information on these and other risks, please refer to the “Risk Factors” section included in the Company’s Quarterly Report on Form 10-Q for the fiscal quarter ended September 28, 2019 to be filed with the Securities and Exchange Commission, and in the Company’s other filings with the Securities and Exchange Commission, including the Company’s Annual Report on Form 10-K for the fiscal year ended June 29, 2019, filed by Lumentum with the Securities and Exchange Commission on August 27, 2019. The forward-looking statements and preliminary financial results contained in this press release are made as of the date hereof and the Company assumes no obligation to update such statements, except as required by applicable law.

[0001633978-19-000070:8k_2_02:30]
Contact Information

[0001633978-19-000070:8k_2_02:31]
Investors:            Jim Fanucchi, 408-404-5400; investor.relations@lumentum.com

[0001633978-19-000070:8k_2_02:32]
Media:         Sean Ogarrio, 408-404-5400; media@lumentum.com

[0001633978-19-000070:8k_2_02:33]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001633978-19-000070:8k_2_02:34]
LUMENTUM HOLDINGS INC.

[0001633978-19-000070:8k_2_02:35]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001633978-19-000070:8k_2_02:36]
(in millions, except per share data)

[0001633978-19-000070:8k_2_02:37]
(unaudited)

[0001633978-19-000070:8k_2_02:38]
|  | Three Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |
| Net revenue | $ | 449.9 |  |  | $ | 354.1 |  |
| Cost of sales | 269.7 |  |  | 227.3 |  |
| Amortization of acquired developed intangibles | 12.5 |  |  | 0.8 |  |
| Gross profit | 167.7 |  |  | 126.0 |  |
| Operating expenses: |  |  |  |
| Research and development | 49.9 |  |  | 34.6 |  |
| Selling, general and administrative | 56.7 |  |  | 33.0 |  |
| Restructuring and related charges | 1.3 |  |  | 1.3 |  |
| Total operating expenses | 107.9 |  |  | 68.9 |  |
| Income from operations | 59.8 |  |  | 57.1 |  |
| Unrealized loss on derivative liability | — |  |  | (2.1 | ) |
| Interest expense | (11.4 | ) |  | (5.1 | ) |
| Other income (expense), net | 5.0 |  |  | 2.7 |  |
| Income before income taxes | 53.4 |  |  | 52.6 |  |
| Provision for income taxes | 5.8 |  |  | 5.2 |  |
| Net income | $ | 47.6 |  |  | $ | 47.4 |  |
| Items reconciling net income to net income attributable to common stockholders: |  |  |  |
| Less: Cumulative dividends on Series A Preferred Stock | — |  |  | (0.2 | ) |
| Less: Earnings allocated to Series A Preferred Stock | — |  |  | (1.1 | ) |
| Net income attributable to common stockholders - Basic | $ | 47.6 |  |  | $ | 46.1 |  |
| Net income attributable to common stockholders - Diluted | $ | 47.6 |  |  | $ | 46.1 |  |
| Net income per share attributable to common stockholders: |  |  |  |
| Basic | $ | 0.62 |  |  | $ | 0.73 |  |
| Diluted | $ | 0.61 |  |  | $ | 0.72 |  |
| Shares used to compute net income per share attributable to common stockholders: |  |  |  |
| Basic | 76.9 |  |  | 63.1 |  |
| Diluted | 77.6 |  |  | 63.9 |  |

[0001633978-19-000070:8k_2_02:39]
LUMENTUM HOLDINGS INC.

[0001633978-19-000070:8k_2_02:40]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001633978-19-000070:8k_2_02:41]
(in millions, except share and per share data)

[0001633978-19-000070:8k_2_02:42]
(unaudited)

[0001633978-19-000070:8k_2_02:43]
|  | September 28, 2019 |  | June 29, 2019 |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |  |
| Cash and cash equivalents | $ | 539.0 |  |  | $ | 432.6 |  |
| Short-term investments | 291.9 |  |  | 335.9 |  |
| Accounts receivable, net | 292.8 |  |  | 238.0 |  |
| Inventories | 202.2 |  |  | 228.8 |  |
| Prepayments and other current assets | 97.3 |  |  | 97.5 |  |
| Total current assets | 1,423.2 |  |  | 1,332.8 |  |
| Property, plant and equipment, net | 436.7 |  |  | 433.3 |  |
| Operating lease right-of-use assets, net | 88.2 |  |  | — |  |
| Goodwill | 368.9 |  |  | 368.9 |  |
| Other intangible assets, net | 376.6 |  |  | 395.4 |  |
| Deferred income taxes | 169.6 |  |  | 169.6 |  |
| Other non-current assets | 4.6 |  |  | 16.6 |  |
| Total assets | $ | 2,867.8 |  |  | $ | 2,716.6 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 152.2 |  |  | $ | 160.8 |  |
| Accrued payroll and related expenses | 42.7 |  |  | 42.3 |  |
| Accrued expenses | 51.4 |  |  | 46.7 |  |
| Term loan, current | 6.2 |  |  | 5.0 |  |
| Operating lease liabilities, current | 11.7 |  |  | — |  |
| Other current liabilities | 52.6 |  |  | 39.2 |  |
| Total current liabilities | 316.8 |  |  | 294.0 |  |
| Convertible notes | 356.5 |  |  | 351.9 |  |
| Term loan, non-current | 483.1 |  |  | 484.0 |  |
| Operating lease liabilities, non-current | 65.3 |  |  | — |  |
| Deferred tax liability | 52.7 |  |  | 55.9 |  |
| Other non-current liabilities | 32.1 |  |  | 33.7 |  |
| Total liabilities | 1,306.5 |  |  | 1,219.5 |  |
| Stockholders’ equity: |  |  |  |
| Common stock, $0.001 par value, 990,000,000 authorized shares, 77,184,591 and 76,653,478 shares issued and outstanding as of September 28, 2019 and June 29, 2019, respectively | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital | 1,377.3 |  |  | 1,360.8 |  |
| Retained earnings | 176.7 |  |  | 129.1 |  |
| Accumulated other comprehensive income | 7.2 |  |  | 7.1 |  |
| Total stockholders’ equity | 1,561.3 |  |  | 1,497.1 |  |
| Total liabilities and stockholders’ equity | $ | 2,867.8 |  |  | $ | 2,716.6 |  |

[0001633978-19-000070:8k_2_02:44]
Use of Non-GAAP Financial Measures

[0001633978-19-000070:8k_2_02:45]
In this press release, Lumentum provides investors with gross margin, gross profit, operating margin (loss), operating income (loss), income (loss) before income taxes and certain expenses, net income (loss), and net income (loss) per share on a non-GAAP basis. Lumentum believes this non-GAAP financial information provides additional insight into the Company’s on-going cash generation and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons. Specifically, the Company believes that providing this information allows investors to better understand the Company’s cash flows and, importantly, to evaluate the efficacy of the methodology and information used by management to evaluate and measure such cash flows. However, these measures may be different from non-GAAP measures used by other companies, limiting their usefulness for comparison purposes. The non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP. Investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future. Further, these non-GAAP financial measures may not be comparable to similarly titled measurements reported by other companies.

[0001633978-19-000070:8k_2_02:46]
Non-GAAP gross margin, non-GAAP gross profit, non-GAAP expenses, non-GAAP operating margin, non-GAAP operating income, non-GAAP income before income taxes, non-GAAP net income, and non-GAAP net income per share exclude (i) stock-based compensation, (ii) inventory write-downs due to cancelled programs, plans to exit certain lines of business and other costs and contingencies unrelated to current and future operations, (iii) acquisition related costs, (iv) integration related costs, (v) amortization of acquired intangibles, (vi) amortization of fair value adjustments, (vii) restructuring and related charges, (viii) impairment charges,  (ix)  foreign exchange (gains) losses, net, (x) non-cash interest expense, (xi) unrealized gain (loss) on derivative liability, (xii) transferring product lines to Thailand, and (xiii) non-cash income tax provision impacts. The presentation of these and other similar items in Lumentum’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001633978-19-000070:8k_2_02:47]
A quantitative reconciliation between GAAP and non-GAAP financial data with respect to historical periods is included in the supplemental financial table attached to this press release.

[0001633978-19-000070:8k_2_02:48]
LUMENTUM HOLDINGS INC.

[0001633978-19-000070:8k_2_02:49]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001633978-19-000070:8k_2_02:50]
(in millions, except per share data)

[0001633978-19-000070:8k_2_02:51]
(unaudited)

[0001633978-19-000070:8k_2_02:52]
|  | Three Months Ended |  |
|  | September 28, 2019 |  | June 29, 2019 |  | September 29, 2018 |  |
| Gross profit on GAAP basis | $ | 167.7 |  |  | $ | 86.8 |  |  | $ | 126.0 |  |  |
| Stock-based compensation | 4.2 |  |  | 3.4 |  |  | 3.3 |  |  |
| Inventory write down due to product lines exit (3) | 1.1 |  |  | 1.4 |  |  | — |  |  |
| Integration related costs | 3.4 |  |  | 3.8 |  |  | — |  |  |
| Amortization of acquired intangibles | 12.5 |  |  | 13.3 |  |  | 0.8 |  |  |
| Amortization of fair value adjustments (2) | 2.2 |  |  | 38.8 |  |  | — |  |  |
| Other charges (1) | 15.0 |  |  | 9.9 |  |  | 12.5 |  |  |
| Gross profit on non-GAAP basis | $ | 206.1 |  |  | $ | 157.4 |  |  | $ | 142.6 |  |  |
| Gross margin on non-GAAP basis | 45.8 | % |  | 38.9 | % |  | 40.3 | % |  |
| Research and development on GAAP basis | $ | 49.9 |  |  | $ | 49.5 |  |  | $ | 34.6 |  |  |
| Stock-based compensation | (3.8 | ) |  | (3.1 | ) |  | (2.8 | ) |  |
| Other charges | 0.2 |  |  | — |  |  | (0.2 | ) |  |
| Research and development on non-GAAP basis | $ | 46.3 |  |  | $ | 46.4 |  |  | $ | 31.6 |  |  |
| Selling, general and administrative on GAAP basis | $ | 56.7 |  |  | $ | 49.4 |  |  | $ | 33.0 |  |  |
| Stock-based compensation | (8.7 | ) |  | (7.7 | ) |  | (4.7 | ) |  |
| Acquisition related costs | — |  |  | (0.3 | ) |  | (1.1 | ) |  |
| Integration related costs | (3.2 | ) |  | (1.7 | ) |  | — |  |  |
| Amortization of acquired intangibles | (6.3 | ) |  | (3.6 | ) |  | — |  |  |
| Other charges | (1.4 | ) |  | (1.8 | ) |  | (0.9 | ) |  |
| Selling, general and administrative on non-GAAP basis | $ | 37.1 |  |  | $ | 34.3 |  |  | $ | 26.3 |  |  |
| Income (loss) from operations on GAAP basis | $ | 59.8 |  |  | $ | (13.8 | ) |  | $ | 57.1 |  |  |
| Stock-based compensation | 16.7 |  |  | 14.2 |  |  | 10.8 |  |  |
| Inventory write down due to product lines exit (3) | 1.1 |  |  | 1.4 |  |  | — |  |  |
| Acquisition related costs | — |  |  | 0.3 |  |  | 1.1 |  |  |
| Integration related costs | 6.6 |  |  | 5.5 |  |  | — |  |  |
| Amortization of acquired intangibles | 18.8 |  |  | 16.9 |  |  | 0.8 |  |  |
| Amortization of fair value adjustments (2) | 2.2 |  |  | 38.8 |  |  | — |  |  |
| Restructuring and related charges | 1.3 |  |  | 1.7 |  |  | 1.3 |  |  |
| Other charges | 16.2 |  |  | 11.7 |  |  | 13.6 |  |  |
| Income from operations on non-GAAP basis | $ | 122.7 |  |  | $ | 76.7 |  |  | $ | 84.7 |  |  |
| Operating margin on non-GAAP basis | 27.3 | % |  | 19.0 | % |  | 23.9 | % |  |
| Interest and other income (expense), net on GAAP basis | $ | (6.4 | ) |  | $ | (7.3 | ) |  | $ | (2.4 | ) |  |
| Other interest and (income) expense adjustments | — |  |  | — |  |  | (0.2 | ) |  |
| Foreign exchange (gains) losses, net (4) | (1.1 | ) |  | (0.4 | ) |  | 0.3 |  |  |
| Non-cash interest expense on convertible notes and term loan | 4.9 |  |  | 4.9 |  |  | 4.3 |  |  |

[0001633978-19-000070:8k_2_02:53]
| Interest and other income (expense), net on non-GAAP basis | $ | (2.6 | ) |  | $ | (2.8 | ) |  | $ | 2.0 |  |  |
| Income (loss) before income taxes on GAAP basis | $ | 53.4 |  |  | $ | (21.1 | ) |  | $ | 52.6 |  |  |
| Stock-based compensation | 16.7 |  |  | 14.2 |  |  | 10.8 |  |  |
| Inventory write down due to product lines exit (3) | 1.1 |  |  | 1.4 |  |  | — |  |  |
| Acquisition related costs | — |  |  | 0.3 |  |  | 1.1 |  |  |
| Integration related costs | 6.6 |  |  | 5.5 |  |  | — |  |  |
| Amortization of acquired intangibles | 18.8 |  |  | 16.9 |  |  | 0.8 |  |  |
| Amortization of fair value adjustments (2) | 2.2 |  |  | 38.8 |  |  | — |  |  |
| Restructuring and related charges | 1.3 |  |  | 1.7 |  |  | 1.3 |  |  |
| Other interest and (income) expense adjustments | — |  |  | — |  |  | (0.2 | ) |  |
| Foreign exchange (gains) losses, net (4) | (1.1 | ) |  | (0.4 | ) |  | 0.3 |  |  |
| Non-cash interest expense on convertible notes and term loan | 4.9 |  |  | 4.9 |  |  | 4.3 |  |  |
| Unrealized loss on derivative liability | — |  |  | — |  |  | 2.1 |  |  |
| Other charges | 16.2 |  |  | 11.7 |  |  | 13.6 |  |  |
| Income before income taxes on non-GAAP basis | $ | 120.1 |  |  | $ | 73.9 |  |  | $ | 86.7 |  |  |
| Provision for income taxes on GAAP basis | $ | 5.8 |  |  | $ | 4.7 |  |  | $ | 5.2 |  |  |
| Income tax adjustments | 2.9 |  |  | (1.2 | ) |  | (4.6 | ) |  |
| Provision for income taxes on non-GAAP basis | $ | 8.7 |  |  | $ | 3.5 |  |  | $ | 0.6 |  |  |
| Net income (loss) on GAAP basis | $ | 47.6 |  |  | $ | (25.8 | ) |  | $ | 47.4 |  |  |
| Stock-based compensation | 16.7 |  |  | 14.2 |  |  | 10.8 |  |  |
| Inventory write down due to product lines exit (3) | 1.1 |  |  | 1.4 |  |  | — |  |  |
| Acquisition related costs | — |  |  | 0.3 |  |  | 1.1 |  |  |
| Integration related costs | 6.6 |  |  | 5.5 |  |  | — |  |  |
| Amortization of acquired intangibles | 18.8 |  |  | 16.9 |  |  | 0.8 |  |  |
| Amortization of fair value adjustments (2) | 2.2 |  |  | 38.8 |  |  | — |  |  |
| Restructuring and related charges | 1.3 |  |  | 1.7 |  |  | 1.3 |  |  |
| Other interest and (income) expense adjustments | — |  |  | — |  |  | (0.2 | ) |  |
| Foreign exchange (gains) losses, net (4) | (1.1 | ) |  | (0.4 | ) |  | 0.3 |  |  |
| Non-cash interest expense on convertible notes and term loan | 4.9 |  |  | 4.9 |  |  | 4.3 |  |  |
| Unrealized loss on derivative liability | — |  |  | — |  |  | 2.1 |  |  |
| Other charges | 16.2 |  |  | 11.7 |  |  | 13.6 |  |  |
| Income tax adjustments | (2.9 | ) |  | 1.2 |  |  | 4.6 |  |  |
| Net income on non-GAAP basis | $ | 111.4 |  |  | $ | 70.4 |  | (4) | $ | 86.1 |  | (4) |
| Net income per share on non-GAAP basis | $ | 1.44 |  |  | $ | 0.91 |  | (4) | $ | 1.32 |  | (4) |
| Shares used in per share calculation - diluted on GAAP basis | 77.6 |  |  | 76.5 |  |  | 63.9 |  |  |
| Non-GAAP adjustment (5) | — |  |  | 0.6 |  |  | — |  |  |
| Effect of diluted securities from Series A Preferred Stock (6) | — |  |  | — |  |  | 1.5 |  |  |
| Shares used in per share calculation - diluted on non-GAAP basis | 77.6 |  |  | 77.1 |  |  | 65.4 |  |  |

[0001633978-19-000070:8k_2_02:54]
(1) Other charges for the three months ended September 28, 2019, primarily include costs of transferring product lines to Thailand of $4.8 million as well as excess and obsolete charges driven by the decline in demand by Huawei of $6.7 million. For the three months ended September 29, 2018, other charges related to non-recurring activities primarily include set-up costs of our facility in Thailand, including costs of transferring product lines to Thailand of $12.7 million.

[0001633978-19-000070:8k_2_02:55]
(2) In connection with the acquisition of Oclaro in fiscal 2019, we recorded a fair value adjustment of $60.3 million to inventory, resulting in $2.2 million and $38.8 million of amortization expense of the fair value adjustment during the three months ended September 28, 2019 and June 29, 2019, respectively.

[0001633978-19-000070:8k_2_02:56]
(3) For the three months ended September 28, 2019 and June 29, 2019, we recorded an inventory write down charge of $1.1 million and $1.4 million, respectively, related to the decision to exit the Datacom module and Lithium Niobate product lines.

[0001633978-19-000070:8k_2_02:57]
(4) The non-GAAP financial measures for the three months ended June 29, 2019 and September 29, 2018 have been adjusted to conform to the current period presentation, by removing foreign exchange (gains) losses, net.

[0001633978-19-000070:8k_2_02:58]
(5) This adjustment represents weighted-average potentially dilutive securities from our stock-based benefit plans excluded from the computation of diluted net loss per share attributable to common stockholders on a GAAP basis because the effect would have been anti-dilutive. This adjustment amount is added for the computation of diluted net income per share on a non-GAAP basis as we had a net income on a non-GAAP basis.

[0001633978-19-000070:8k_2_02:59]
(6) For the three months ended September 29, 2018, 1.5 million shares related to the potential conversion of the Series A Preferred Stock were added to the calculation of diluted shares available on a non-GAAP basis because their inclusion results in more dilutive earnings per share.

[0001633978-19-000070:8k_2_02:60]
LUMENTUM HOLDINGS INC.

[0001633978-19-000070:8k_2_02:61]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO EBITDA

[0001633978-19-000070:8k_2_02:62]
(in millions, except per share data)

[0001633978-19-000070:8k_2_02:63]
(unaudited)

[0001633978-19-000070:8k_2_02:64]
|  | Three Months Ended |
|  | September 28, 2019 |  | June 29, 2019 |  | September 29, 2018 |
| GAAP Net income (loss) | $ | 47.6 |  |  | $ | (25.8 | ) |  | $ | 47.4 |  |
| Interest and other expense (income), net | 6.4 |  |  | 7.3 |  |  | 2.4 |  |
| Provision for (benefit from) income taxes | 5.8 |  |  | 4.7 |  |  | 5.2 |  |
| Depreciation | 31.6 |  |  | 28.2 |  |  | 19.7 |  |
| Amortization of acquired intangibles | 18.8 |  |  | 16.9 |  |  | 0.8 |  |
| EBITDA | 110.2 |  |  | 31.3 |  |  | 75.5 |  |
| Amortization of fair value adjustments | 2.2 |  |  | 38.8 |  |  | — |  |
| Restructuring and related charges | 1.3 |  |  | 1.7 |  |  | 1.3 |  |
| Stock-based compensation | 16.7 |  |  | 14.2 |  |  | 10.8 |  |
| Acquisition related costs | — |  |  | 0.3 |  |  | 1.1 |  |
| Unrealized gain (loss) on derivative liabilities | — |  |  | — |  |  | 2.1 |  |
| Inventory write down due to product lines exit | 1.1 |  |  | 1.4 |  |  | — |  |
| Integration related costs | 6.6 |  |  | 5.5 |  |  | — |  |
| Other charges | 16.2 |  |  | 11.7 |  |  | 13.6 |  |
| Adjusted EBITDA | $ | 154.3 |  |  | $ | 104.9 |  |  | $ | 104.4 |  |
