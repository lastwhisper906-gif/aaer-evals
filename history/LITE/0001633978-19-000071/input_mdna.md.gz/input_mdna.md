# LITE MD&A — 0001633978-19-000071


## mdna

[0001633978-19-000071:mdna:1]
[same as prior period, unchanged from 0001633978-19-000030:mdna:1]

[0001633978-19-000071:mdna:2]
You should read the following discussion in conjunction with the unaudited condensed consolidated financial statements and the corresponding notes included elsewhere in this Quarterly Report on Form 10-Q (this “Quarterly Report”). This Management’s Discussion and Analysis of Financial Condition and Results of Operations contains forward-looking statements. The matters discussed in these forward-looking statements are subject to risk, uncertainties and other factors that could cause actual results to differ materially from those made, projected or implied in the forward-looking statements. Please see “Risk Factors” and “Forward-Looking Statements” for a discussion of the uncertainties, risks and assumptions associated with these statements.

[0001633978-19-000071:mdna:3]
[same as prior period, unchanged from 0001633978-19-000030:mdna:4]

[0001633978-19-000071:mdna:4]
[same as prior period, unchanged from 0001633978-19-000030:mdna:6]

[0001633978-19-000071:mdna:5]
We are an industry-leading provider of optical and photonic products defined by revenue and market share addressing a range of end-market applications including Optical Communications, which we refer to as OpComms, and Lasers for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. We have two operating segments, OpComms and Lasers. The two operating segments were primarily determined based on how the Chief Operating Decision Maker (“CODM”) views and evaluates our operations. Operating results are regularly reviewed by the CODM to make decisions about resources to be allocated to the segments and to assess their performance. Other factors, including market separation and customer specific applications, go-to-market channels, products and manufacturing, are considered in determining the formation of these operating segments.

[0001633978-19-000071:mdna:6]
[same as prior period, unchanged from 0001633978-19-000030:mdna:8]

[0001633978-19-000071:mdna:7]
On December 10, 2018, we completed the acquisition of Oclaro, a provider of optical components and modules for the long-haul, metro and data center markets. The total transaction consideration was $1.4 billion, which was funded through the issuance of Lumentum common stock, new debt (refer to “Note 11. Debt”), and cash balances of the combined company. Refer to “Note 4. Business Combinations” in the notes to condensed consolidated financial statements for further discussion of the merger.

[0001633978-19-000071:mdna:8]
Following the acquisition of Oclaro, during our fiscal 2019, we made several strategic changes to our OpComms business as follows:

[0001633978-19-000071:mdna:9]
•First, for overlapping products as a result of the acquisition, we are transitioning to a common lower cost design and manufacturing platform, which we expect will result in gross margin improvement over time. In addition, we are discontinuing certain Telecom product lines that we believe have muted growth and profitability trends that are inconsistent with our long term model. We expect that these transitions will be completed in our fiscal 2021. For the Telecom product lines we are exiting, we do not expect significant revenue declines until fiscal 2021 as in fiscal 2020 we are continuing to satisfy customers’ product needs with respect to these product lines.

[0001633978-19-000071:mdna:10]
•Second, we announced our plan to discontinue development and manufacturing of Lithium Niobate modulators, and we plan to wind down these operations in San Donato, Italy during fiscal year 2020. Development and manufacturing will also be discontinued in our San Jose, California manufacturing locations within the next few quarters in order to facilitate our customers’ transition to new products. We expect our Indium Phosphide photonic integrated circuits will continue to replace Lithium Niobate modulators over time.

[0001633978-19-000071:mdna:11]
•Third, we announced the sale of many of our Datacom transceiver modules to Cambridge Industries Group (“CIG”). This transaction closed on April 18, 2019.We expect Datacom transceiver modules sales to ramp down to zero during fiscal year 2020. We are investing in new Datacom chip development and expect sales of these chips to customers serving the Datacom and 5G wireless markets will grow over time.  For further information regarding this transaction, refer to “Note 4. Business Combinations” in the notes to condensed consolidated financial statements. With the exit from the business of selling Datacom transceiver modules in fiscal 2019, we recorded an impairment charge to our long-lived assets that were not deemed to be useful, as they were retired from active use and classified as held-for-sale for $4.9 million on our Balance Sheet.

[0001633978-19-000071:mdna:12]
[same as prior period, unchanged from 0001633978-19-000030:mdna:13]

[0001633978-19-000071:mdna:13]
[same as prior period, unchanged from 0001633978-19-000030:mdna:14]

[0001633978-19-000071:mdna:14]
[same as prior period, unchanged from 0001633978-19-000030:mdna:15]

[0001633978-19-000071:mdna:15]
[same as prior period, unchanged from 0001633978-19-000030:mdna:16]

[0001633978-19-000071:mdna:16]
[same as prior period, unchanged from 0001633978-19-000030:mdna:17]

[0001633978-19-000071:mdna:17]
[same as prior period, unchanged from 0001633978-19-000030:mdna:18]

[0001633978-19-000071:mdna:18]
[same as prior period, unchanged from 0001633978-19-000030:mdna:21]

[0001633978-19-000071:mdna:19]
[same as prior period, unchanged from 0001633978-19-000030:mdna:22]

[0001633978-19-000071:mdna:20]
Except for the adoption of ASU 2016-02 , Leases (Topic 842) and the resulting changes in our accounting policies and disclosures for lease accounting, there have been no significant changes to our significant accounting policies as of and for the three months ended September 28, 2019, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the year ended June 29, 2019. Refer to “Note 1. Description of Business and Summary of Significant Accounting Policies” for the details of ASU 2016-02 (Topic 842) adoption. Management’s Discussion and Analysis of Financial Condition and Results of Operations contained in Part II, Item 7 of our Annual Report on Form 10-K for our fiscal year ended June 29, 2019 provides a more complete discussion of our critical accounting policies and estimates.

[0001633978-19-000071:mdna:21]
Recently Issued Accounting Pronouncements

[0001633978-19-000071:mdna:22]
Refer to “Note 2. Recently Issued Accounting Pronouncements” in the notes to condensed consolidated financial statements.

[0001633978-19-000071:mdna:23]
[same as prior period, unchanged from 0001633978-19-000030:mdna:26]

[0001633978-19-000071:mdna:24]
[same as prior period, unchanged from 0001633978-19-000030:mdna:27]

[0001633978-19-000071:mdna:25]
|  | Three Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |
| Segment net revenue: |  |  |  |
| OpComms | 92.5 | % |  | 87.6 | % |
| Lasers | 7.5 |  |  | 12.4 |  |
| Net revenue | 100.0 |  |  | 100.0 |  |
| Cost of sales | 59.9 |  |  | 64.2 |  |
| Amortization of acquired developed technologies | 2.8 |  |  | 0.2 |  |
| Gross profit | 37.3 |  |  | 35.6 |  |
| Operating expenses: |  |  |  |
| Research and development | 11.1 |  |  | 9.8 |  |
| Selling, general and administrative | 12.6 |  |  | 9.3 |  |
| Restructuring and related charges | 0.3 |  |  | 0.4 |  |
| Total operating expenses | 24.0 |  |  | 19.5 |  |
| Income from operations | 13.3 |  |  | 16.1 |  |
| Unrealized loss on derivative liability | — |  |  | (0.6 | ) |
| Interest expense | (2.5 | ) |  | (1.4 | ) |
| Other income (expense), net | 1.1 |  |  | 0.8 |  |
| Income before income taxes | 11.9 |  |  | 14.9 |  |
| Provision for income taxes | 1.3 |  |  | 1.5 |  |
| Net income | 10.6 | % |  | 13.4 | % |

[0001633978-19-000071:mdna:26]
39

[0001633978-19-000071:mdna:27]
Financial Data for the three months ended September 28, 2019 and September 29, 2018

[0001633978-19-000071:mdna:28]
[same as prior period, unchanged from 0001633978-19-000030:mdna:31]

[0001633978-19-000071:mdna:29]
|  | Three Months Ended |  |  |  |  |
|  | September 28, 2019 |  | September 29, 2018 |  | Change |  | Percentage Change |
| Segment net revenue: |  |  |  |  |  |  |  |
| OpComms | $ | 416.1 |  |  | $ | 310.1 |  |  | $ | 106.0 |  |  | 34.2 | % |
| Lasers | 33.8 |  |  | 44.0 |  |  | (10.2 | ) |  | (23.2 | ) |
| Net revenue | $ | 449.9 |  |  | $ | 354.1 |  |  | $ | 95.8 |  |  | 27.1 | % |
| Gross profit | $ | 167.7 |  |  | $ | 126.0 |  |  | $ | 41.7 |  |  | 33.1 | % |
| Gross margin | 37.3 | % |  | 35.6 | % |  |  |  |  |
| Research and development | $ | 49.9 |  |  | $ | 34.6 |  |  | $ | 15.3 |  |  | 44.2 | % |
| Percentage of net revenue | 11.1 | % |  | 9.8 | % |  |  |  |  |
| Selling, general and administrative | $ | 56.7 |  |  | $ | 33.0 |  |  | $ | 23.7 |  |  | 71.8 | % |
| Percentage of net revenue | 12.6 | % |  | 9.3 | % |  |  |  |  |
| Restructuring and related charges | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | — |  |  | — | % |
| Percentage of net revenue | 0.3 | % |  | 0.4 | % |  |  |  |  |

[0001633978-19-000071:mdna:30]
[same as prior period, unchanged from 0001633978-19-000030:mdna:33]

[0001633978-19-000071:mdna:31]
Net revenue increased by $95.8 million, or 27.1%, during the three months ended September 28, 2019 compared to the three months ended September 29, 2018. This increase was primarily due to the acquisition of Oclaro in the second quarter of fiscal 2019, increased sales in our Consumer and Industrial business, as well as organic growth in our Telecom and Datacom business.

[0001633978-19-000071:mdna:32]
OpComms net revenue increased by $106.0 million, or 34.2%, during the three months ended September 28, 2019 compared to the three months ended September 29, 2018, primarily driven by increased sales of Telecom and Datacom products of $71.0 million, and Consumer and Industrial products of $35.0 million.

[0001633978-19-000071:mdna:33]
Lasers net revenue decreased by $10.2 million, or 23.2%, during the three months ended September 28, 2019 compared to the three months ended September 29, 2018, primarily due to decreased sales of our kilowatt class fiber lasers and solid state lasers.

[0001633978-19-000071:mdna:34]
During the three months ended September 28, 2019 and September 29, 2018, our net revenue was concentrated with three customers, who collectively accounted for 58% and 59% of our total net revenue, respectively.

[0001633978-19-000071:mdna:35]
[same as prior period, unchanged from 0001633978-19-000030:mdna:42]

[0001633978-19-000071:mdna:36]
[same as prior period, unchanged from 0001633978-19-000030:mdna:43]

[0001633978-19-000071:mdna:37]
|  | Three Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |
|  | Amount |  | % of Total |  | Amount |  | % of Total |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 36.9 |  |  | 8.3 | % |  | $ | 21.9 |  |  | 6.2 | % |
| Mexico | 28.9 |  |  | 6.4 |  |  | 56.3 |  |  | 15.9 |  |
| Other Americas | 1.1 |  |  | 0.2 |  |  | 0.9 |  |  | 0.3 |  |
| Total Americas | $ | 66.9 |  |  | 14.9 | % |  | $ | 79.1 |  |  | 22.4 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |
| Hong Kong | $ | 133.8 |  |  | 29.7 | % |  | $ | 65.5 |  |  | 18.5 | % |
| South Korea | 91.6 |  |  | 20.4 |  |  | 70.0 |  |  | 19.8 |  |
| Japan | 32.5 |  |  | 7.2 |  |  | 36.1 |  |  | 10.2 |  |
| Other Asia-Pacific | 92.8 |  |  | 20.6 |  |  | 74.1 |  |  | 20.9 |  |
| Total Asia-Pacific | $ | 350.7 |  |  | 77.9 | % |  | $ | 245.7 |  |  | 69.4 | % |
| EMEA | $ | 32.3 |  |  | 7.2 | % |  | $ | 29.3 |  |  | 8.2 | % |
| Total net revenue | $ | 449.9 |  |  |  |  | $ | 354.1 |  |  |  |

[0001633978-19-000071:mdna:38]
For the three months ended September 28, 2019 and September 29, 2018, net revenue from customers outside the United States, based on customer shipping location, represented 91.7% and 93.8% of net revenue, respectively. Our net revenue from Hong Kong grew due to increased sales of our 3D sensing products for mobile devices shipped to one of our large customers.

[0001633978-19-000071:mdna:39]
Our net revenue is primarily denominated in U.S. dollars, including our net revenue from customers outside the United States as presented above. We expect revenue from customers outside of the United States to continue to be an important part of our overall net revenue and an increasing focus for net revenue growth opportunities. However, regulatory and enforcement actions by the United States and other governmental agencies, as well as changes in tax and trade policies and tariffs, have impacted and may continue to impact net revenue from customers outside the United States.

[0001633978-19-000071:mdna:40]
41

[0001633978-19-000071:mdna:41]
[same as prior period, unchanged from 0001633978-19-000030:mdna:49]

[0001633978-19-000071:mdna:42]
The following table summarizes segment gross margin for the three months ended September 28, 2019 and September 29, 2018 (in millions, except for percentages):

[0001633978-19-000071:mdna:43]
|  | Three Months Ended |
|  | Gross Profit |  | Gross Margin |
|  | September 28, 2019 |  | September 29, 2018 |  | September 28, 2019 |  | September 29, 2018 |
| OpComms | $ | 191.9 |  |  | $ | 124.9 |  |  | 46.1 | % |  | 40.3 | % |
| Lasers | 14.2 |  |  | 17.7 |  |  | 42.0 | % |  | 40.2 | % |
| Segment total | $ | 206.1 |  |  | $ | 142.6 |  |  | 45.8 | % |  | 40.3 | % |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Stock-based compensation | (4.2 | ) |  | (3.3 | ) |  |  |  |  |
| Amortization of acquired intangibles | (12.5 | ) |  | (0.8 | ) |  |  |  |  |
| Amortization of fair value adjustments | (2.2 | ) |  | — |  |  |  |  |  |
| Inventory write down due to product lines exit | (1.1 | ) |  | — |  |  |  |  |  |
| Integration related costs | (3.4 | ) |  | — |  |  |  |  |  |
| Other charges (1) | (15.0 | ) |  | (12.5 | ) |  |  |  |  |
| Total | $ | 167.7 |  |  | $ | 126.0 |  |  | 37.3 | % |  | 35.6 | % |

[0001633978-19-000071:mdna:44]
(1) “Other charges” of unallocated corporate items for the three months ended September 28, 2019 primarily include costs of transferring product lines to Thailand of $4.8 million as well as excess and obsolete charges driven by the decline in demand by Huawei of $6.7 million. During the three months ended September 29, 2018, “other charges” of unallocated corporate items primarily consisted of set-up costs of our facility in Thailand, including costs of transferring product lines to Thailand of $12.7 million.

[0001633978-19-000071:mdna:45]
The unallocated corporate items for the periods presented include the effects of amortization of acquired developed technologies and other intangibles, share-based compensation and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0001633978-19-000071:mdna:46]
[same as prior period, unchanged from 0001633978-19-000030:mdna:54]

[0001633978-19-000071:mdna:47]
Gross margin for the three months ended September 28, 2019 increased to 37.3% from 35.6% for the three months ended September 29, 2018. The increase was primarily due to increased sales in our 3D sensing products, which have higher gross margins than the average for other products.

[0001633978-19-000071:mdna:48]
[same as prior period, unchanged from 0001633978-19-000030:mdna:57]

[0001633978-19-000071:mdna:49]
[same as prior period, unchanged from 0001633978-19-000030:mdna:58]

[0001633978-19-000071:mdna:50]
[same as prior period, unchanged from 0001633978-19-000030:mdna:59]

[0001633978-19-000071:mdna:51]
OpComms gross margin for the three months ended September 28, 2019 increased to 46.1% from 40.3% for the three months ended September 29, 2018. This increase was primarily due to increased sales of our 3D sensing products and wavelength selective switches products, which have higher gross margins than the averages for this segment, as well as increased sales of our transmission products due to the recent acquisition of Oclaro, which have higher gross margins than previous transmission products.

[0001633978-19-000071:mdna:52]
[same as prior period, unchanged from 0001633978-19-000030:mdna:62]

[0001633978-19-000071:mdna:53]
Lasers gross margin for the three months ended September 28, 2019 increased to 42.0% from 40.2% for the three months ended September 29, 2018. This increase was primarily due to the streamlining of our manufacturing supply chain related to our kilowatt class fiber products.

[0001633978-19-000071:mdna:54]
[same as prior period, unchanged from 0001633978-19-000030:mdna:65]

[0001633978-19-000071:mdna:55]
R&D expense increased by $15.3 million, or 44.2%, for the three months ended September 28, 2019 compared to the three months ended September 29, 2018. The increase in R&D expense was primarily due to the increase of $6.7 million  in investments in key product lines and R&D materials. In addition, payroll related expense increased $5.8 million, $2.7 million of which was due to the result of our acquisition of Oclaro.

[0001633978-19-000071:mdna:56]
[same as prior period, unchanged from 0001633978-19-000030:mdna:68]

[0001633978-19-000071:mdna:57]
[same as prior period, unchanged from 0001633978-19-000030:mdna:69]

[0001633978-19-000071:mdna:58]
SG&A expense increased by $23.7 million, or 71.8%, during the three months ended September 28, 2019 compared to the three months ended September 29, 2018. The increase was primarily attributable to the acquisition of Oclaro, including an incremental stock-based compensation charge of $2.0 million, integration related costs of $3.2 million, and amortization of intangibles of $6.3 million. In addition, payroll related expense increased $5.9 million, partially as a result of our acquisition of Oclaro.

[0001633978-19-000071:mdna:59]
From time to time, we expect to incur non-core expenses, such as mergers and acquisition-related expenses and litigation expenses, which will likely increase our SG&A expenses and potentially impact our profitability expectations in any particular quarter.

[0001633978-19-000071:mdna:60]
[same as prior period, unchanged from 0001633978-19-000030:mdna:73]

[0001633978-19-000071:mdna:61]
We have initiated various strategic restructuring events primarily intended to reduce costs, consolidate our operations, rationalize the manufacturing of our products and align our business in response to market conditions and as a result of our acquisition of Oclaro in the second quarter of fiscal 2019.

[0001633978-19-000071:mdna:62]
During the three months ended September 28, 2019 and September 29, 2018, we recorded $1.3 million in restructuring and related charges, in each of the respective period, in our condensed consolidated statements of operations.

[0001633978-19-000071:mdna:63]
| • | During the first quarter of fiscal 2020, we recorded restructuring and related charges of $1.3 million attributable to severance charges associated with ongoing acquisition related synergies. |

[0001633978-19-000071:mdna:64]
| • | During the first quarter of fiscal 2019, we implemented an internal reorganization in order to extend our market leadership position by strengthening product quality, to develop new enabling technologies required to support a long-term portfolio roadmap, and to develop commercial proposals and new product introduction priorities to maintain and grow our position while driving new customer and ecosystem partner engagements. In connection with this reorganization, we recorded restructuring and related charges of $1.3 million related to severance and employee related benefits. |

[0001633978-19-000071:mdna:65]
Any changes in the estimates of executing our restructuring activities will be reflected in our future results of operations.

[0001633978-19-000071:mdna:66]
Interest Expense

[0001633978-19-000071:mdna:67]
For the three months ended September 28, 2019 and September 29, 2018, we recorded interest expense of $11.4 million and $5.1 million, respectively. The increase in interest expense during the three months ended September 28, 2019 as compared to the three months ended September 29, 2018 is mainly driven by interest expense on our Term Loan Facility that we entered into in connection with the acquisition of Oclaro in December 2018.

[0001633978-19-000071:mdna:68]
Other Income (Expense), Net

[0001633978-19-000071:mdna:69]
The components of other income (expense), net are as follows (in millions):

[0001633978-19-000071:mdna:70]
|  | Three Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |
| Foreign exchange gains (losses), net | $ | 1.1 |  |  | $ | (0.3 | ) |
| Interest income | 4.0 |  |  | 2.7 |  |
| Other income (expense), net | (0.1 | ) |  | 0.3 |  |
| Total other income (expense), net | $ | 5.0 |  |  | $ | 2.7 |  |

[0001633978-19-000071:mdna:71]
For the three months ended September 28, 2019 and September 29, 2018, other income (expense), net increased by $2.3 million in income as compared to the three months ended September 29, 2018, mainly driven by an increase in interest income on our cash equivalents and short-term investments. Foreign exchange gains increased mainly due to dollar strengthening and  newly recorded monetary liabilities in connection with adoption of Topic 842.

[0001633978-19-000071:mdna:72]
Unrealized Loss on Derivative Liability

[0001633978-19-000071:mdna:73]
Unrealized loss on Series A Preferred Stock derivative liability amounted to zero and $2.1 million for the three months ended September 28, 2019 and September 29, 2018, respectively. On November 2, 2018, all 35,805 shares of our Series A Preferred Stock were converted to common stock with the outstanding balance of the embedded derivative liability reclassed to additional paid in capital. There will be no further adjustments to “unrealized gain (loss) on derivative liability” due to this conversion. For further discussion of our derivative liability, see “Note 10. Non-Controlling Interest Redeemable Convertible Preferred Stock and Derivative Liability” in the notes to condensed consolidated financial statements.

[0001633978-19-000071:mdna:74]
Provision for Income Taxes

[0001633978-19-000071:mdna:75]
| (in millions) | Three Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |
| Provision for income taxes | $ | 5.8 |  |  | $ | 5.2 |  |

[0001633978-19-000071:mdna:76]
We recorded a tax provision of $5.8 million and $5.2 million for the three months ended September 28, 2019 and September 29, 2018, respectively. Our estimated effective tax rate for the fiscal 2020 differs from the 21% U.S. statutory rate primarily due to the income tax benefit of the earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate as well as the U.S. federal R&D and foreign tax credits, partially offset by the income tax expense from non-deductible stock-based compensation and the tax effect of Global Intangible Low-Taxed Income (“GILTI”), Base Erosion and Anti-Abuse Tax (“BEAT”) and subpart F inclusion.

[0001633978-19-000071:mdna:77]
[same as prior period, unchanged from 0001633978-19-000030:mdna:94]

[0001633978-19-000071:mdna:78]
The following table summarizes our contractual obligations as of September 28, 2019, and the effect such obligations are expected to have on our liquidity and cash flow over the next five years (in millions):

[0001633978-19-000071:mdna:79]
|  | Payments due by period |
|  | Total |  | Less than 1 year |  | 1 - 3 years |  | 3 - 5 years |  | More than 5 years |
| Contractual Obligations |  |  |  |  |  |  |  |  |  |
| Acquisition contingencies (1) | $ | 3.0 |  |  | $ | 3.0 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Asset retirement obligations | 5.5 |  |  | 1.0 |  |  | 0.8 |  |  | 1.2 |  |  | 2.5 |  |
| Finance lease liabilities, including imputed interest | 10.2 |  |  | 9.8 |  |  | 0.4 |  |  | — |  |  | — |  |
| Operating lease liabilities, including imputed interest (2) | 88.4 |  |  | 14.1 |  |  | 25.7 |  |  | 19.4 |  |  | 29.2 |  |
| Pension plan contributions (3) | 0.5 |  |  | 0.5 |  |  | — |  |  | — |  |  | — |  |
| Purchase obligations (4) | 277.6 |  |  | 273.3 |  |  | 4.2 |  |  | 0.1 |  |  | — |  |
| Term loan - principal (5) | 497.5 |  |  | 6.2 |  |  | 10.0 |  |  | 10.0 |  |  | 471.3 |  |
| Term loan - interest (5) | 139.5 |  |  | 24.8 |  |  | 44.9 |  |  | 44.0 |  |  | 25.8 |  |
| Convertible notes - principal (6) | 450.0 |  |  | — |  |  | — |  |  | 450.0 |  |  | — |  |
| Convertible notes - interest (6) | 5.0 |  |  | 1.1 |  |  | 2.2 |  |  | 1.7 |  |  | — |  |
| Total | $ | 1,477.2 |  |  | $ | 333.8 |  |  | $ | 88.2 |  |  | $ | 526.4 |  |  | $ | 528.8 |  |

[0001633978-19-000071:mdna:80]
(1) Refer to “Note 6. Fair Value Measurements” in the notes to condensed consolidated financial statements.

[0001633978-19-000071:mdna:81]
(2) The amounts of operating lease liabilities in the table above do not include any sublease income amounts nor do they include payments for short-term leases or variable lease payments. As of September 28, 2019, we expect to receive sublease income of approximately $6.4 million over the next three years.

[0001633978-19-000071:mdna:82]
(3) In connection with our acquisitions of Oclaro in fiscal 2019 and Time-Bandwidth Products Inc. in fiscal 2014, we assumed defined benefit plans for Japan and Switzerland employees, respectively. The Switzerland Plan is partially funded. The Japan Plan is unfunded. The amount in the preceding table represents planned contributions to our defined benefit plans. Although additional future contributions will be required, the amount and timing of these contributions will be affected by actuarial assumptions, the actual rate of returns on plan assets, the level of market interest rates, legislative changes, and the amount of voluntary contributions to the plan. Any contributions for the following fiscal year and later will depend on the value of the plan assets in the future and thus are uncertain. As such, we have not included any amounts beyond 1 year in the table above.

[0001633978-19-000071:mdna:83]
(4) Purchase obligations represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Refer to “Note 17. Commitments and Contingencies” in the notes to condensed consolidated financial statements.

[0001633978-19-000071:mdna:84]
(5) We incurred indebtedness in an aggregate principal amount of $500.0 million pursuant to a senior secured Term Loan Facility that we entered into in connection with the closing of the Oclaro acquisition on December 10, 2018. The amounts of interest included in the table above are based on current interest rates. Refer to “Note 11. Debt” in the notes to condensed consolidated financial statements.

[0001633978-19-000071:mdna:85]
(6) Includes interest on our 0.25% Convertible Notes due in 2024 through March 2024 as we have the right to redeem the 2024 Notes in whole or in part at any time on or after March 15, 2024. Refer to “Note 11. Debt” in the notes to condensed consolidated financial statements.

[0001633978-19-000071:mdna:86]
As of September 28, 2019, our other non-current liabilities also include $18.8 million of unrecognized tax benefit for uncertain tax positions. We are unable to reliably estimate the timing of future payments related to uncertain tax positions and therefore have excluded them from the preceding table.

[0001633978-19-000071:mdna:87]
[same as prior period, unchanged from 0001633978-19-000030:mdna:107]

[0001633978-19-000071:mdna:88]
[same as prior period, unchanged from 0001633978-19-000030:mdna:108]

[0001633978-19-000071:mdna:89]
[same as prior period, unchanged from 0001633978-19-000030:mdna:109]

[0001633978-19-000071:mdna:90]
[same as prior period, unchanged from 0001633978-19-000030:mdna:110]

[0001633978-19-000071:mdna:91]
As of September 28, 2019 and June 29, 2019, our cash and cash equivalents of $539.0 million and $432.6 million, respectively, were largely held in the United States. The total amount of cash outside the United States as of September 28, 2019 was $100.3 million, which was primarily held by entities incorporated in Japan, Hong Kong, the United Kingdom, Thailand, the British Virgin Islands, China, and the Netherlands. Although the cash currently held in the United States as well as the cash generated in the United States from future operations is expected to cover our normal operating requirements, a substantial amount of additional cash could be required for other purposes, such as capital expenditures to support our business and growth, including costs associated with increasing internal manufacturing capabilities, such as our new Thailand facility, strategic transactions and partnerships, and future acquisitions. Our intent is to indefinitely reinvest funds held outside the United States, except for the funds held in the Cayman Islands, Japan and Hong Kong, and our current plans do not demonstrate a need to repatriate them to fund our domestic operations. However, if in the future, we encounter a significant need for liquidity domestically or at a particular location that we cannot fulfill through borrowings, equity offerings, or other internal or external sources, or the cost to bring back the money is insignificant from a tax perspective, we may determine that cash repatriations are necessary or desirable. Repatriation could result in additional material taxes. These factors may cause us to have an overall tax rate higher than other companies or higher than our tax rates have been in the past. If conditions warrant, we may seek to obtain additional financing through debt or equity sources. To the extent we issue additional shares, our existing stockholders may be diluted. However, any such financing may not be available on terms favorable to us, or may not be available at all.

[0001633978-19-000071:mdna:92]
As of September 28, 2019, our condensed consolidated balance of cash and cash equivalents, increased by $106.4 million, to $539.0 million from $432.6 million as of June 29, 2019. The increase in cash and cash equivalents was mainly due to cash provided by operating activities of $87.5 million and cash provided by investing activities of $21.7 million during the three months ended September 28, 2019.

[0001633978-19-000071:mdna:93]
[same as prior period, unchanged from 0001633978-19-000030:mdna:113]

[0001633978-19-000071:mdna:94]
Cash provided by operating activities was $87.5 million during the three months ended September 28, 2019. Our net income was $47.6 million for the three months ended September 28, 2019. Cash provided by operating activities was generated primarily from $79.0 million of non-cash items (such as depreciation, stock-based compensation, amortization of intangibles, amortization of debt discount and debt issuance costs on our term loans and 2024 Notes, and other non-cash charges), offset by $39.1 million of changes in our operating assets and liabilities. Changes in our operating assets and liabilities related primarily to an increase in accounts receivable of $54.8 million offset by a decrease in inventories of $23.5 million.

[0001633978-19-000071:mdna:95]
Cash provided by operating activities was $57.2 million during the three months ended September 29, 2018, primarily resulting from $47.4 million of net income and $37.7 million of non-cash items (such as depreciation, stock-based compensation, unrealized loss on derivative liability, amortization of intangibles, and amortization of discount on the 2024 Notes), offset by $27.9 million of changes in our operating assets and liabilities. Changes in our operating assets and liabilities related primarily to an increase in accounts receivable of $41.9 million offset by a decrease in inventories of $15.3 million.

[0001633978-19-000071:mdna:96]
[same as prior period, unchanged from 0001633978-19-000030:mdna:116]

[0001633978-19-000071:mdna:97]
Cash provided by investing activities of $21.7 million during the three months ended September 28, 2019 was primarily attributable to sales of short-term investments, net of purchases of $44.4 million, offset by capital expenditures of $21.7 million and payment for asset acquisition of $1.0 million.

[0001633978-19-000071:mdna:98]
Cash provided by investing activities of $9.5 million during the three months ended September 29, 2018 was primarily attributable to sales of short-term investments, net of purchases of $39.8 million offset by capital expenditures of $29.6 million.

[0001633978-19-000071:mdna:99]
[same as prior period, unchanged from 0001633978-19-000030:mdna:119]

[0001633978-19-000071:mdna:100]
Cash used in financing activities of $2.8 million during the three months ended September 28, 2019 resulted from the repayment of principal on our finance leases.

[0001633978-19-000071:mdna:101]
Cash used in financing activities of $4.6 million during the three months ended September 29, 2018 resulted primarily from a repayment of a capital lease obligation of $2.3 million, payment of debt issuance costs of $0.9 million, and payment of acquisition related holdback of $1.0 million.

[0001633978-19-000071:mdna:102]
[same as prior period, unchanged from 0001633978-19-000030:mdna:122]

[0001633978-19-000071:mdna:103]
We believe that our cash and cash equivalents as of September 28, 2019, and cash flows from our operating activities will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months. However, if market conditions are favorable, we may evaluate alternatives to opportunistically pursue additional financing.

[0001633978-19-000071:mdna:104]
[same as prior period, unchanged from 0001633978-19-000030:mdna:124]

[0001633978-19-000071:mdna:105]
[same as prior period, unchanged from 0001633978-19-000030:mdna:125]

[0001633978-19-000071:mdna:106]
[same as prior period, unchanged from 0001633978-19-000030:mdna:126]

[0001633978-19-000071:mdna:107]
[same as prior period, unchanged from 0001633978-19-000030:mdna:127]

[0001633978-19-000071:mdna:108]
[same as prior period, unchanged from 0001633978-19-000030:mdna:128]

[0001633978-19-000071:mdna:109]
[same as prior period, unchanged from 0001633978-19-000030:mdna:129]

[0001633978-19-000071:mdna:110]
[same as prior period, unchanged from 0001633978-19-000030:mdna:130]

[0001633978-19-000071:mdna:111]
[same as prior period, unchanged from 0001633978-19-000030:mdna:131]

[0001633978-19-000071:mdna:112]
[same as prior period, unchanged from 0001633978-19-000030:mdna:132]

[0001633978-19-000071:mdna:113]
[same as prior period, unchanged from 0001633978-19-000030:mdna:133]

[0001633978-19-000071:mdna:114]
[same as prior period, unchanged from 0001633978-19-000030:mdna:134]

[0001633978-19-000071:mdna:115]
| • | repaying or refinancing our existing debt obligations; |

[0001633978-19-000071:mdna:116]
[same as prior period, unchanged from 0001633978-19-000030:mdna:135]

[0001633978-19-000071:mdna:117]
[same as prior period, unchanged from 0001633978-19-000030:mdna:136]

[0001633978-19-000071:mdna:118]
[same as prior period, unchanged from 0001633978-19-000030:mdna:5]
