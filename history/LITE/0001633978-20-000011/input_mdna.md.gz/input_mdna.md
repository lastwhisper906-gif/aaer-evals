# LITE MD&A — 0001633978-20-000011


## mdna

[0001633978-20-000011:mdna:1]
ITEM 7.    MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001633978-20-000011:mdna:2]
You should read the following discussion in conjunction with the audited consolidated financial statements and the corresponding notes included elsewhere in this Annual Report. This Management’s Discussion and Analysis of Financial Condition and Results of Operations contains forward-looking statements. The matters discussed in these forward-looking statements are subject to risk, uncertainties and other factors that could cause actual results to differ materially from those made, projected or implied in the forward-looking statements. Please see “Risk Factors” and “Forward-Looking Statements” for a discussion of the uncertainties, risks and assumptions associated with these statements.

[0001633978-20-000011:mdna:3]
Overview

[0001633978-20-000011:mdna:4]
We are an industry-leading provider of optical and photonic products defined by revenue and market share addressing a range of end-market applications including Optical Communications, which we refer to as OpComms, and Lasers for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. We have two operating segments, OpComms and Lasers. The two operating segments were primarily determined based on how the Chief Operating Decision Maker (“CODM”) views and evaluates our operations. Operating results are regularly reviewed by the CODM to make decisions about resources to be allocated to the segments and to assess their performance. Other factors, including market separation and customer specific applications, go-to-market channels, products and manufacturing, are considered in determining the formation of these operating segments.

[0001633978-20-000011:mdna:5]
We believe the world is becoming more reliant on ever-increasing amounts of data flowing through optical networks and data centers, which require new networks and data centers to satisfy this demand. As manufacturers demand higher levels of precision, new materials, and factory and energy efficiency, suppliers of manufacturing tools globally are turning to laser based approaches, including the types of lasers Lumentum supplies. Laser based 3D sensing is a rapidly developing market. The technology enables computer vision applications that enhance security, safety, and new functionality in the electronic devices that people rely on every day. We believe the global markets in which Lumentum participates have fundamentally robust, long-term trends that increase the need for our photonics products and technologies.

[0001633978-20-000011:mdna:6]
On December 10, 2018, we completed the acquisition of Oclaro, a provider of optical components and modules for the long-haul, metro and data center markets. Refer to “Note 4. Business Combinations” in the notes to consolidated financial statements for further discussion of the merger.

[0001633978-20-000011:mdna:7]
OpComms

[0001633978-20-000011:mdna:8]
Our OpComms products address the following markets: Telecom, Datacom and Consumer and Industrial.

[0001633978-20-000011:mdna:9]
Our OpComms products include a wide range of components, modules and subsystems to support customers including carrier networks for access (local), metro (intracity), long-haul (city-to-city and worldwide) and submarine (undersea) applications. Additionally, our products address enterprise, cloud, and data center applications, including storage-access networks (“SANs”), local-area networks (“LANs”) and wide-area networks (“WANs”). These products enable the transmission and transport of video, audio and data over high-capacity fiber-optic cables. We maintain leading positions in these fast growing OpComms markets through our extensive product portfolio, including reconfigurable optical add/drop multiplexers (“ROADMs”), coherent DWDM pluggable transceivers, and tunable small form-factor pluggable transceivers. We also sell laser chips for use in the manufacture of high-speed Datacom transceivers.

[0001633978-20-000011:mdna:10]
In the Consumer and Industrial market, our OpComms products include laser light sources, which are integrated into 3D sensing platforms being used in applications for mobile devices, gaming, computers, and other consumer electronics devices. New emerging applications include virtual and augmented reality, as well as automotive and industrial segments. Our products include vertical cavity surface emitting lasers (“VCSELs”) and edge emitting lasers which are used in 3D sensing depth imaging systems. These systems simplify the way people interact with technology by enabling the use of natural user interfaces. Systems are used for biometric identification, surveillance, and process efficiency, among numerous other application spaces. Emerging applications for this technology include various mobile device applications, autonomous vehicles, self-navigating robotics and drones in industrial applications and 3D capture of objects coupled with 3D printing. In addition, our industrial diode lasers are used primarily as pump sources for pulsed and kilowatt class fiber lasers.

[0001633978-20-000011:mdna:11]
Our OpComms customers include Alphabet, Apple, Ciena, Cisco Systems (which announced the acquisition of Acacia Communications, another customer of ours), Huawei Technologies (including HiSilicon), Infinera, Innolight, Nokia Networks (including Alcatel-Lucent International), O-Net, and ZTE.

[0001633978-20-000011:mdna:12]
Following the acquisition of Oclaro, during our fiscal 2019, we made several strategic changes to our OpComms business to better position it for growth and profitability. These changes included attaining acquisition cost synergies related to redundant capabilities and divestiture of Telecom Lithium Niobate modulators and Datacom transceiver modules because of their muted growth and profitability trends. These changes were substantially completed in fiscal 2020. We expect our Indium Phosphide photonic integrated circuits will continue to replace Lithium Niobate modulators over time and focusing on the development and sale of Datacom chips has enabled us to participate in the growth of the Datacom and 5G wireless markets.

[0001633978-20-000011:mdna:13]
Related to the strategic changes in our OpComms business, we entered into two strategic transactions to sell some of the discontinued product lines. In the second quarter of fiscal year 2020, we entered into an agreement with Advanced Fiber Resources (Zhuhai) Ltd. (“AFR”), a leading provider of passive optical components, to sell the assets associated with certain Lithium Niobate product lines manufactured by our San Donato site for $17.0 million. The transaction was closed in the third quarter of fiscal year 2020. For further information regarding this transaction, refer to “Note 5. Assets and Liabilities Held For Sale” in the notes to consolidated financial statements. On April 18, 2019, we closed a transaction selling many of our Datacom transceiver module product lines to Cambridge Industries Group (“CIG”). For further information regarding this transaction, refer to “Note 4. Business Combinations” in the notes to consolidated financial statements.

[0001633978-20-000011:mdna:14]
Lasers

[0001633978-20-000011:mdna:15]
Our Lasers products serve our customers in markets and applications such as sheet metal processing, general manufacturing, biotechnology, graphics and imaging, remote sensing, and precision machining such as drilling in printed circuit boards, wafer singulation, glass cutting and solar cell scribing.

[0001633978-20-000011:mdna:16]
Our Lasers products are used in a variety of OEM applications including diode-pumped solid-state, fiber, diode, direct-diode and gas lasers such as argon-ion and helium-neon lasers. Fiber lasers provide kW-class output powers combined with excellent beam quality and are used in sheet metal processing and metal welding applications. Diode-pumped solid-state lasers provide excellent beam quality, low noise and exceptional reliability and are used in biotechnology, graphics and imaging, remote sensing, materials processing and precision machining applications. Diode and direct-diode lasers address a wide variety of applications, including laser pumping, thermal exposure, illumination, ophthalmology, image recording, printing, plastic welding and selective soldering. Gas lasers such as argon-ion and helium-neon lasers provide a stable, low-cost and reliable solution over a wide range of operating conditions, making them well-suited for complex, high-resolution OEM applications such as flow cytometry, DNA sequencing, graphics and imaging and semiconductor inspection.

[0001633978-20-000011:mdna:17]
We also provide high-powered and ultrafast lasers for the industrial and scientific markets. Manufacturers use high-power, ultrafast lasers to create micro parts for consumer electronics and to process semiconductor, LED, and other types of chips. Use of ultrafast lasers for micromachining applications is being driven primarily by the increasing use of consumer electronics and connected devices globally.

[0001633978-20-000011:mdna:18]
Our Lasers customers include Amada, ASML Holding, Beckman Coulter, DISCO, Electro Scientific Industries (recently acquired by MKS Instruments, a competitor of ours), Han’s Laser Technology, KLA-Tencor, Lasertec, Life Technologies, and NR Electric.

[0001633978-20-000011:mdna:19]
Impact of COVID-19 to our Business

[0001633978-20-000011:mdna:20]
The outbreak of the COVID-19 has been declared a pandemic by the World Health Organization and continues to spread globally. The spread of COVID-19 has caused public health officials to recommend, and governments to enact, precautions to mitigate the spread of the virus, including travel restrictions and bans, extensive social distancing guidelines and issuing a “shelter-in-place” order in many regions of the world. The pandemic and these related responses have caused, and are expected to continue to cause a global slowdown of economic activity (including the decrease in demand for a broad variety of goods and services), disruptions in global supply chains and significant volatility and disruption of financial markets. We have adopted several measures in response to the COVID-19 outbreak including complying with local, state or federal orders that require employees to work from home, instructing employees to work from home in certain jurisdictions, limiting the number of employees onsite which slowed our manufacturing operations in certain countries, enhanced use of personal protective equipment and restricting non-critical business travel by our employees.

[0001633978-20-000011:mdna:21]
In the geographies we have operations, we have in general been deemed an essential business and been permitted to continue manufacturing and new product development operations in a more limited capacity during the pandemic. This stems from our critical role in global supply chains for the world’s communications and health-care systems. Given the rapidly evolving situation, it is difficult to predict precisely when our ability to supply our products will improve or the magnitude and duration of the impact of the COVID-19 pandemic to our markets. We will continue to actively monitor the situation and may take further actions altering our business operations that we determine are in the best interests of our employees, customers, communities, business partners, suppliers, and stockholders, or as required by federal, state, or local authorities. It is not clear what the potential effects any such

[0001633978-20-000011:mdna:22]
alterations or modifications may have on our business, including the effects on our customers, employees, and prospects, or on our financial results for fiscal year 2021.

[0001633978-20-000011:mdna:23]
While the recent outbreak of the COVID-19 did not have a material adverse effect on our reported results for our third and fourth quarters, we are actively monitoring the impact of the coronavirus outbreak. The extent to which our operations will be impacted by the outbreak will depend largely on future developments, which are highly uncertain and cannot be accurately predicted, including new information which may emerge concerning the severity of the outbreak and actions by government authorities and private businesses to contain the outbreak or recover from its impact, among other things.

[0001633978-20-000011:mdna:24]
Our primary strategic focus for several years has been technology and product leadership combined with close customer relationships in long-term healthy and growing markets. We believe this strategy is even more apt, and our long-term opportunity is not diminished, with COVID-19. We believe there may be long-term opportunities, as the world’s experience with COVID-19 could drive an increasingly digital and virtual world touching all aspects of life and work that increasingly emphasizes communications systems, cloud services, augmented and virtual reality, and enhanced security. Additionally, ever advancing electronic devices are needed to consume, produce, and communicate digital and virtual content. All these trends could drive the need for higher volumes of higher performing optical devices that we could supply. As such, we expect to continue to invest strongly in new products, technology, and customer programs.

[0001633978-20-000011:mdna:25]
For more information on risks associated with the COVID-19 outbreak, see the section titled “Risk Factors” in Item 1A of Part I.

[0001633978-20-000011:mdna:26]
Critical Accounting Policies and Estimates

[0001633978-20-000011:mdna:27]
Our consolidated financial statements are prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) as set forth in the Financial Accounting Standards Board’s Accounting Standards Codification (“ASC”), and we consider the various staff accounting bulletins and other applicable guidance issued by the United States Securities and Exchange Commission (“SEC”). GAAP, as set forth within the ASC, requires us to make certain estimates, judgments and assumptions. We believe that the estimates, judgments and assumptions upon which we rely are reasonable based upon information available to us at the time that these estimates, judgments and assumptions are made. These estimates, judgments and assumptions can affect the reported amounts of assets and liabilities as of the date of the financial statements as well as the reported amounts of revenues and expenses during the periods presented. To the extent there are differences between these estimates, judgments or assumptions and actual results, our financial statements will be affected. The accounting policies that reflect our more significant estimates, judgments and assumptions and which we believe are the most critical to aid in fully understanding and evaluating our reported financial results include the following:

[0001633978-20-000011:mdna:28]
• Inventory Valuation

[0001633978-20-000011:mdna:29]
• Revenue Recognition

[0001633978-20-000011:mdna:30]
• Income Taxes

[0001633978-20-000011:mdna:31]
• Long-lived Asset Valuation

[0001633978-20-000011:mdna:32]
• Goodwill

[0001633978-20-000011:mdna:33]
Except for the adoption of ASU 2016-02, Leases (Topic 842) and the resulting changes in our accounting policies and disclosures for lease accounting, there have been no significant changes to our significant accounting policies as of and for the year ended June 27, 2020. Refer to “Note 1. Description of Business and Summary of Significant Accounting Policies” for the details of ASU 2016-02 (Topic 842) adoption.

[0001633978-20-000011:mdna:34]
Inventory Valuation

[0001633978-20-000011:mdna:35]
Inventory is valued at standard cost, which approximates actual cost computed on a first-in, first-out basis, not in excess of net realizable value. We assess the value of our inventory on a quarterly basis and write down those inventories which are obsolete or in excess of our forecasted demand to the lower of their cost or estimated net realizable value. Our estimates of forecasted demand are based upon our analysis and assumptions including, but not limited to, expected product lifecycles, product development plans and historical usage by product. Our product line management personnel play a key role in our excess review process by providing updated sales forecasts, managing product transitions and working with manufacturing to minimize excess inventory. If actual market conditions are less favorable than our forecasts, or actual demand from our customers is lower than our estimates, we may be required to record additional inventory write-downs. If actual market conditions are more favorable than anticipated, inventory previously written down may be sold, resulting in lower cost of sales and higher income from operations than expected in that period.

[0001633978-20-000011:mdna:36]
Revenue Recognition

[0001633978-20-000011:mdna:37]
Adoption of Topic 606

[0001633978-20-000011:mdna:38]
Pursuant to Topic 606, our revenues are recognized upon the application of the following steps:

[0001633978-20-000011:mdna:39]
•identification of the contract, or contracts, with a customer;

[0001633978-20-000011:mdna:40]
•identification of the performance obligations in the contract;

[0001633978-20-000011:mdna:41]
•determination of the transaction price;

[0001633978-20-000011:mdna:42]
•allocation of the transaction price to the performance obligations in the contract; and

[0001633978-20-000011:mdna:43]
•recognition of revenues when, or as, the contractual performance obligations are satisfied.

[0001633978-20-000011:mdna:44]
The majority of our revenue comes from product sales, consisting of sales of Lasers and OpComms hardware products to our customers. Our revenue contracts generally include only one performance obligation. Revenues are recognized at a point in time when control of the promised goods or services are transferred to our customers upon shipment or delivery, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services. We have entered into vendor managed inventory (“VMI”) programs with our customers. Under these arrangements, we receive purchase orders from our customers, and the inventory is shipped to the VMI location upon receipt of the purchase order. The customer then pulls the inventory from the VMI hub based on its production needs. Revenue under VMI programs is recognized when control transfers to the customer, which is generally once the customer pulls the inventory from the hub.

[0001633978-20-000011:mdna:45]
Revenue from all sales types is recognized at the transaction price. The transaction price is determined based on the consideration to which we will be entitled in exchange for transferring goods or services to the customer, adjusted for estimated variable consideration, if any. We typically estimate the impact on the transaction price for discounts offered to the customer for early payments on receivables or net of accruals for estimated sales returns. These estimates are based on historical returns, analysis of credit memo data and other known factors. Actual returns could differ from these estimates. We allocate the transaction price to each distinct product based on its relative standalone selling price. The product price as specified on the purchase order is considered the standalone selling price as it is an observable input that depicts the price as if sold to a similar customer in similar circumstances.

[0001633978-20-000011:mdna:46]
Taxes assessed by a governmental authority that are both imposed on and concurrent with a specific revenue-producing transaction, that are collected by us from a customer and deposited with the relevant government authority, are excluded from revenue. Our revenue arrangements do not contain significant financing components as our standard payment terms are less than one year.

[0001633978-20-000011:mdna:47]
If a customer pays consideration, or if we have a right to an amount of consideration that is unconditional before we transfer a good or service to the customer, those amounts are classified as deferred revenue or deposits received from customers which are included in other current liabilities or other long-term liabilities when the payment is made or when it is due, whichever is earlier.

[0001633978-20-000011:mdna:48]
Transaction Price Allocated to the Remaining Performance Obligations

[0001633978-20-000011:mdna:49]
Remaining performance obligations represent the transaction price allocated to performance obligations that are unsatisfied or partially unsatisfied as of the end of the reporting period. Unsatisfied and partially unsatisfied performance obligations consist of contract liabilities and non-cancellable backlog. Non-cancellable backlog includes goods and services for which customer purchase orders have been accepted that are scheduled or in the process of being scheduled for shipment. A portion of our revenue arises from vendor-managed inventory arrangements where the timing and volume of customer utilization is difficult to predict.

[0001633978-20-000011:mdna:50]
The following table includes estimated revenue expected to be recognized in the future for backlog related performance obligations that are unsatisfied as of June 27, 2020 (in millions):

[0001633978-20-000011:mdna:51]
|  | Less than 1 year | 1-2 years | Greater than 2 years | Total |
| Performance Obligations | $525.5 | $32.3 | $— | $557.8 |

[0001633978-20-000011:mdna:52]
Warranty

[0001633978-20-000011:mdna:53]
Hardware products regularly include warranties to the end customers such that the product continues to function according to published specifications. We typically offer a twelve-month warranty for most of our products. However, in some instances depending upon the product, specific market, product line and geography in which we operate, and what is common in the industry, our warranties can vary and range from six months to five years. These standard warranties are assurance type warranties and do not offer any services in addition to the assurance that the product will continue working as specified. Therefore, warranties are not considered separate performance obligations in the arrangement. Instead, the expected cost of the warranty is accrued as expense in accordance with authoritative guidance.

[0001633978-20-000011:mdna:54]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We estimate the costs of our warranty obligations based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise.

[0001633978-20-000011:mdna:55]
Shipping and Handling Costs

[0001633978-20-000011:mdna:56]
We record shipping and handling costs related to revenue transactions within cost of sales as a period cost.

[0001633978-20-000011:mdna:57]
Contract Costs

[0001633978-20-000011:mdna:58]
We recognize the incremental direct costs of obtaining a contract, which consist of sales commissions, when control over the products they relate to transfers to the customer. Applying the practical expedient, we recognize commissions as expense when incurred, as the amortization period of the commission asset we would have otherwise recognized is less than one year.

[0001633978-20-000011:mdna:59]
Contract Balances

[0001633978-20-000011:mdna:60]
We record accounts receivable when we have an unconditional right to consideration. Contract liabilities are recorded when cash payments are received or due in advance of performance. Contract liabilities consist of advance payments and deferred revenue, where we have unsatisfied performance obligations. Contract liabilities are classified as deferred revenue and customer deposits, and are included in other current liabilities within our consolidated balance sheet. Payment terms vary by customer. The time between invoicing and when payment is due is not significant.

[0001633978-20-000011:mdna:61]
The following table reflects the changes in contract balances as of June 27, 2020 (in millions, except percentages):

[0001633978-20-000011:mdna:62]
| Contract balances | Balance sheet location | June 27, 2020 |  | June 29, 2019 |  | Change |  | Percentage Change |
| Accounts receivable, net | Accounts receivable, net | $233.5 |  | $238.0 |  | $(4.5) |  | (1.9)% |
| Deferred revenue and customer deposits | Other current liabilities | $1.9 |  | $2.9 |  | $(1.0) |  | (34.5)% |

[0001633978-20-000011:mdna:63]
Disaggregation of Revenue

[0001633978-20-000011:mdna:64]
We disaggregate revenue by geography and by product. Refer to “Note 20. Operating Segments and Geographic Information” for a presentation of disaggregated revenue. We do not present other levels of disaggregation, such as by type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, as this information is not used by our CODM to manage the business.

[0001633978-20-000011:mdna:65]
Income Taxes

[0001633978-20-000011:mdna:66]
In accordance with the authoritative guidance on accounting for income taxes, we recognize income taxes using an asset and liability approach. This approach requires the recognition of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in our consolidated financial statements

[0001633978-20-000011:mdna:67]
or tax returns. The measurement of current and deferred taxes is based on provisions of the enacted tax law, and the effects of future changes in tax laws or rates are not anticipated.

[0001633978-20-000011:mdna:68]
The authoritative guidance provides for recognition of deferred tax assets if the realization of such deferred tax assets is more likely than not to occur based on an evaluation of both positive and negative evidence and the relative weight of the evidence. We consider future growth, forecasted earnings, future taxable income, the mix of earnings in the jurisdictions in which we operate, historical earnings, taxable income in prior years, if carryback is permitted under the law, and prudent and feasible tax planning strategies in determining the need for a valuation allowance. In the event we were to determine that we would not be able to realize all or part of our net deferred tax assets in the future, an adjustment to the deferred tax assets valuation allowance would be charged to earnings in the period in which we make such a determination, or goodwill would be adjusted at our final determination of the valuation allowance related to an acquisition within the measurement period. If we later determine that it is more likely than not that the net deferred tax assets would be realized, we would reverse the applicable portion of the previously provided valuation allowance as an adjustment to earnings at such time.

[0001633978-20-000011:mdna:69]
We are subject to income tax audits by the respective tax authorities of the jurisdictions in which we operate. The determination of our income tax liabilities in each of these jurisdictions requires the interpretation and application of complex, and sometimes uncertain, tax laws and regulations. The authoritative guidance on accounting for income taxes prescribes both recognition and measurement criteria that must be met for the benefit of a tax position to be recognized in the financial statements.  If a tax position taken, or expected to be taken, in a tax return does not meet such recognition or measurement criteria, an unrecognized tax benefit liability is recorded.  If we ultimately determine that an unrecognized tax benefit liability is no longer necessary, we reverse the liability and recognize a tax benefit in the period in which it is determined that the unrecognized tax benefit liability is no longer necessary.

[0001633978-20-000011:mdna:70]
The recognition and measurement of current taxes payable or refundable and deferred tax assets and liabilities requires that we make certain estimates and judgments. Changes to these estimates or a change in judgment may have a material impact on our tax provision in a future period.

[0001633978-20-000011:mdna:71]
Long-lived Asset Valuation

[0001633978-20-000011:mdna:72]
We test long-lived assets for recoverability, at the asset group level, when events or changes in circumstances indicate that their carrying amount may not be recoverable. Circumstances which could trigger a review include, but are not limited to: significant decreases in the market price of the asset, significant adverse changes in the business climate or legal factors, accumulation of costs significantly in excess of the amount originally expected for the acquisition or construction of the asset, current period cash flow or operating losses combined with a history of losses or a forecast of continuing losses associated with the use of the asset, or current expectation that the asset will more likely than not be sold or disposed significantly before the end of its estimated useful life.

[0001633978-20-000011:mdna:73]
Recoverability is assessed based on the difference between the carrying amount of the asset and the sum of the undiscounted cash flows expected to result from the use and the eventual disposal of the asset. An impairment loss is recognized when the carrying amount is not recoverable and exceeds fair value.

[0001633978-20-000011:mdna:74]
Goodwill

[0001633978-20-000011:mdna:75]
Goodwill represents the excess of the purchase price of an acquired business over the fair value of the identifiable assets acquired and liabilities assumed. We test for impairment of goodwill on an annual basis in the fourth quarter and at any other time when events occur or circumstances indicate that the carrying amount of goodwill may not be recoverable.

[0001633978-20-000011:mdna:76]
We have the option to first assess qualitative factors to determine whether it is necessary to perform the quantitative goodwill impairment test. The qualitative factors we assess include long-term prospects of our performance, share price trends and market capitalization, and Company specific events. Unanticipated events and circumstances may occur that affect the accuracy of our assumptions, estimates and judgments. For example, if the price of our common stock were to significantly decrease combined with other adverse changes in market conditions, thus indicating that the underlying fair value of our reporting units may have decreased, we might be required to reassess the value of our goodwill in the period such circumstances were identified.

[0001633978-20-000011:mdna:77]
If we determine that as a result of the qualitative assessment that it is more likely than not (i.e., greater than 50% likelihood) that the fair value of a reporting unit is less than its carrying amount, then the quantitative test is required. Otherwise, no further testing is required. The quantitative goodwill impairment test requires us to estimate the fair value of our reporting units. If the carrying value of a reporting unit exceeds its fair value, the goodwill of that reporting unit is potentially impaired and we record an impairment loss equal to the excess of the carrying value of the reporting unit’s goodwill over its fair value, not to exceed the carrying amount of goodwill. The fair value of each of our goodwill reporting units is generally estimated using a combination of public company multiples and discounted cash flow methodologies.

[0001633978-20-000011:mdna:78]
Based on the impairment analysis performed in the fourth quarter of each year presented, the fair value of our reporting units substantially exceeded the carrying value; as such, our annual qualitative assessment did not indicate that a more detailed quantitative analysis was necessary.

[0001633978-20-000011:mdna:79]
In many cases, the accounting treatment of a particular transaction is specifically dictated by GAAP and does not require management’s judgment in its application. There are also areas in which management’s judgment in selecting among available alternatives would not produce a materially different result. Our senior management has reviewed our critical accounting policies and related disclosures with the Audit Committee of our board of directors.

[0001633978-20-000011:mdna:80]
Recently Issued Accounting Pronouncements

[0001633978-20-000011:mdna:81]
Refer to “Note 2. Recently Issued Accounting Pronouncements” in the notes to consolidated financial statements.

[0001633978-20-000011:mdna:82]
Results of Operations

[0001633978-20-000011:mdna:83]
The results of operations for the periods presented are not necessarily indicative of results to be expected for future periods. The following table summarizes selected consolidated statements of operations items as a percentage of net revenue:

[0001633978-20-000011:mdna:84]
|  | Years Ended |
|  | June 27, 2020 |  | June 29, 2019 |  | June 30, 2018 |
| Segment net revenue: |  |  |  |  |  |
| OpComms | 90.3 | % |  | 87.5 | % |  | 84.9 | % |
| Lasers | 9.7 |  |  | 12.5 |  |  | 15.1 |  |
| Net revenue | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of sales | 58.1 |  |  | 69.8 |  |  | 65.1 |  |
| Amortization of acquired developed intangibles | 3.2 |  |  | 3.0 |  |  | 0.3 |  |
| Gross profit | 38.7 |  |  | 27.2 |  |  | 34.6 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 11.8 |  |  | 11.8 |  |  | 12.6 |  |
| Selling, general and administrative | 14.0 |  |  | 12.8 |  |  | 10.3 |  |
| Restructuring and related charges | 0.5 |  |  | 2.0 |  |  | 0.6 |  |
| Impairment charges | 0.3 |  |  | 2.0 |  |  | — |  |
| Total operating expenses | 26.6 |  |  | 28.6 |  |  | 23.4 |  |
| Income (loss) from operations | 12.2 |  |  | (1.4 | ) |  | 11.2 |  |
| Unrealized gain (loss) on derivative liability | — |  |  | 0.6 |  |  | (0.1 | ) |
| Interest expense | (3.6 | ) |  | (2.3 | ) |  | (1.5 | ) |
| Other income (expense), net | 1.9 |  |  | 1.0 |  |  | 0.7 |  |
| Income (loss) before income taxes | 10.4 |  |  | (2.1 | ) |  | 10.4 |  |
| Provision for (benefit from) income taxes | 2.3 |  |  | 0.2 |  |  | (9.5 | ) |
| Net income (loss) | 8.1 | % |  | (2.3 | )% |  | 19.9 | % |

[0001633978-20-000011:mdna:85]
42

[0001633978-20-000011:mdna:86]
Financial Data for Fiscal 2020, 2019 and 2018

[0001633978-20-000011:mdna:87]
The following table summarizes selected consolidated statements of operations items (in millions, except for percentages):

[0001633978-20-000011:mdna:88]
|  | 2020 |  | 2019 |  | Change |  | Percentage Change |  | 2019 |  | 2018 |  | Change |  | Percentage Change |
| Segment net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| OpComms | $ | 1,515.1 |  |  | $ | 1,370.2 |  |  | $ | 144.9 |  |  | 10.6 | % |  | $ | 1,370.2 |  |  | $ | 1,059.2 |  |  | $ | 311.0 |  |  | 29.4 | % |
| Lasers | 163.5 |  |  | 195.1 |  |  | (31.6 | ) |  | (16.2 | ) |  | 195.1 |  |  | 188.5 |  |  | 6.6 |  |  | 3.5 |  |
| Net revenue | $ | 1,678.6 |  |  | $ | 1,565.3 |  |  | $ | 113.3 |  |  | 7.2 | % |  | $ | 1,565.3 |  |  | $ | 1,247.7 |  |  | $ | 317.6 |  |  | 25.5 | % |
| Gross profit | $ | 650.2 |  |  | $ | 425.9 |  |  | $ | 224.3 |  |  | 52.7 | % |  | $ | 425.9 |  |  | $ | 432.1 |  |  | $ | (6.2 | ) |  | (1.4 | )% |
| Gross margin | 38.7 | % |  | 27.2 | % |  |  |  |  |  | 27.2 | % |  | 34.6 | % |  |  |  |  |
| Research and development | $ | 198.6 |  |  | $ | 184.6 |  |  | $ | 14.0 |  |  | 7.6 | % |  | $ | 184.6 |  |  | $ | 156.8 |  |  | $ | 27.8 |  |  | 17.7 | % |
| Percentage of net revenue | 11.8 | % |  | 11.8 | % |  |  |  |  |  | 11.8 | % |  | 12.6 | % |  |  |  |  |
| Selling, general and administrative | $ | 235.2 |  |  | $ | 200.3 |  |  | $ | 34.9 |  |  | 17.4 | % |  | $ | 200.3 |  |  | $ | 128.2 |  |  | $ | 72.1 |  |  | 56.2 | % |
| Percentage of net revenue | 14.0 | % |  | 12.8 | % |  |  |  |  |  | 12.8 | % |  | 10.3 | % |  |  |  |  |
| Restructuring and related charges | $ | 8.0 |  |  | $ | 31.9 |  |  | $ | (23.9 | ) |  | (74.9 | )% |  | $ | 31.9 |  |  | $ | 7.2 |  |  | $ | 24.7 |  |  | 343.1 | % |
| Percentage of net revenue | 0.5 | % |  | 2.0 | % |  |  |  |  |  | 2.0 | % |  | 0.6 | % |  |  |  |  |
| Impairment charges | $ | 4.3 |  |  | $ | 30.7 |  |  | $ | (26.4 | ) |  | (86.0 | )% |  | $ | 30.7 |  |  | $ | — |  |  | $ | 30.7 |  |  | 100.0 | % |
| Percentage of net revenue | 0.3 | % |  | 2.0 | % |  |  |  |  |  | 2.0 | % |  | — | % |  |  |  |  |

[0001633978-20-000011:mdna:89]
Net Revenue

[0001633978-20-000011:mdna:90]
Net revenue increased by $113.3 million, or 7.2%, during fiscal 2020 compared to fiscal 2019. This increase was primarily due to the increased sales of Telecom and Datacom of $68.9 million and Consumer and Industrial of $76.0 million, offset by decreased sales of Lasers of $31.6 million.

[0001633978-20-000011:mdna:91]
OpComms net revenue increased by $144.9 million, or 10.6%, during fiscal 2020 compared to fiscal 2019, primarily driven by increased sales of Telecom and Datacom products, driven by the acquisition of Oclaro, as well as increased sales in 3D sensing products for mobile devices.

[0001633978-20-000011:mdna:92]
Lasers net revenue decreased by $31.6 million, or 16.2%, during fiscal 2020 compared to fiscal 2019, primarily due to decreased sales of our kilowatt class fiber lasers.

[0001633978-20-000011:mdna:93]
Net revenue increased by $317.6 million, or 25.5%, during fiscal 2019 compared to fiscal 2018. This increase was primarily due to the acquisition of Oclaro, which closed in December 2018, and organic growth in our Telecom business.

[0001633978-20-000011:mdna:94]
OpComms net revenue increased by $311.0 million, or 29.4%, during fiscal 2019 compared to fiscal 2018, primarily driven by increased sales of Telecom Products of $310.2 million, specifically ROADM products. OpComms net revenue in fiscal 2019 includes $250.1 million from the acquisition of Oclaro from the date of closing.

[0001633978-20-000011:mdna:95]
Lasers net revenue increased by $6.6 million, or 3.5%, during fiscal 2019 compared to fiscal 2018, primarily due to increased sales of our kilowatt class fiber lasers, offset by lower sales of our solid state lasers products.

[0001633978-20-000011:mdna:96]
During our fiscal 2020, 2019, and 2018, net revenue generated from a single customer which represented 10% or greater of total net revenue is summarized as follows:

[0001633978-20-000011:mdna:97]
|  | Years Ended |
|  | June 27, 2020 |  | June 29, 2019 |  | June 30, 2018 |
| Apple | 26.0 | % |  | 21.0 | % |  | 30.0 | % |
| Huawei | 13.2 | % |  | 15.2 | % |  | 11.0 | % |
| Ciena | * |  |  | 13.7 | % |  | 11.0 | % |
| *Represents less than 10% of total net revenue |  |  |  |  |  |

[0001633978-20-000011:mdna:98]
Revenue by Region

[0001633978-20-000011:mdna:99]
We operate in three geographic regions: Americas, Asia-Pacific and EMEA. Net revenue is assigned to the geographic region and country where our product is initially shipped. For example, certain customers may request shipment of our product to a contract manufacturer in one country, however, the location of the end customers may differ. The following table presents net revenue by the three geographic regions we operate in and net revenue from countries within those regions that represented 10% or more of our total net revenue (in millions, except for percentages):

[0001633978-20-000011:mdna:100]
|  | Years Ended |
|  | June 27, 2020 |  | June 29, 2019 |  | June 30, 2018 |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 149.8 |  |  | 8.9 | % |  | $ | 100.9 |  |  | 6.4 | % |  | $ | 115.1 |  |  | 9.2 | % |
| Mexico | 122.8 |  |  | 7.3 |  |  | 214.9 |  |  | 13.7 |  |  | 145.8 |  |  | 11.7 |  |
| Other Americas | 5.5 |  |  | 0.3 |  |  | 4.3 |  |  | 0.3 |  |  | 7.0 |  |  | 0.6 |  |
| Total Americas | $ | 278.1 |  |  | 16.5 | % |  | $ | 320.1 |  |  | 20.4 | % |  | $ | 267.9 |  |  | 21.5 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 532.0 |  |  | 31.8 | % |  | $ | 387.9 |  |  | 24.8 | % |  | $ | 183.0 |  |  | 14.7 | % |
| South Korea | 260.9 |  |  | 15.5 |  |  | 162.4 |  |  | 10.4 |  |  | 146.1 |  |  | 11.7 |  |
| Japan | 137.9 |  |  | 8.2 |  |  | 176.0 |  |  | 11.2 |  |  | 194.7 |  |  | 15.6 |  |
| Other Asia-Pacific | 346.0 |  |  | 20.6 |  |  | 356.1 |  |  | 22.7 |  |  | 354.2 |  |  | 28.3 |  |
| Total Asia-Pacific | $ | 1,276.8 |  |  | 76.1 | % |  | $ | 1,082.4 |  |  | 69.1 | % |  | $ | 878.0 |  |  | 70.3 | % |
| EMEA | $ | 123.7 |  |  | 7.4 | % |  | $ | 162.8 |  |  | 10.5 | % |  | $ | 101.8 |  |  | 8.2 | % |
| Total net revenue | $ | 1,678.6 |  |  |  |  | $ | 1,565.3 |  |  |  |  | $ | 1,247.7 |  |  |  |

[0001633978-20-000011:mdna:101]
During fiscal 2020, 2019 and 2018, net revenue from customers outside the United States, based on customer shipping location, represented 91.1%, 93.6% and 90.8% of net revenue, respectively.

[0001633978-20-000011:mdna:102]
44

[0001633978-20-000011:mdna:103]
Gross Margin and Segment Gross Margin

[0001633978-20-000011:mdna:104]
The following table summarizes segment gross margin for fiscal 2020, 2019 and 2018 (in millions, except for percentages):

[0001633978-20-000011:mdna:105]
|  | Gross Profit |  | Gross Margin |
|  | Years Ended |  | Years Ended |
|  | 2020 |  | 2019 |  | 2018 |  | 2020 |  | 2019 |  | 2018 |
| OpComms | $ | 704.0 |  |  | $ | 534.1 |  |  | $ | 402.3 |  |  | 46.5 | % |  | 39.0 | % |  | 38.0 | % |
| Lasers | 76.2 |  |  | 84.4 |  |  | 82.8 |  |  | 46.6 | % |  | 43.3 | % |  | 43.9 | % |
| Segment total | $ | 780.2 |  |  | $ | 618.5 |  |  | $ | 485.1 |  |  | 46.5 | % |  | 39.5 | % |  | 38.9 | % |
| Unallocated corporate items: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation | (16.1 | ) |  | (15.1 | ) |  | (12.6 | ) |  |  |  |  |  |  |
| Amortization of acquired intangibles | (53.8 | ) |  | (46.6 | ) |  | (3.2 | ) |  |  |  |  |  |  |
| Amortization of fair value adjustments | (5.8 | ) |  | (54.6 | ) |  | — |  |  |  |  |  |  |  |
| Inventory and fixed asset write down due to product lines exit (1) | (7.0 | ) |  | (20.8 | ) |  | — |  |  |  |  |  |  |  |
| Integration related costs | (4.9 | ) |  | (6.6 | ) |  | — |  |  |  |  |  |  |  |
| Expenses related to COVID-19 outbreak | (6.6 | ) |  | — |  |  | — |  |  |  |  |  |  |  |
| Other charges (2) | (35.8 | ) |  | (48.9 | ) |  | (37.2 | ) |  |  |  |  |  |  |
| Total | $ | 650.2 |  |  | $ | 425.9 |  |  | $ | 432.1 |  |  | 38.7 | % |  | 27.2 | % |  | 34.6 | % |

[0001633978-20-000011:mdna:106]
(1) In fiscal 2020 and 2019, we recorded inventory and fixed assets write down charges of $7.0 million and $20.8 million related to the decision to exit the Datacom module and Lithium Niobate product lines.

[0001633978-20-000011:mdna:107]
(2) “Other charges” of unallocated corporate items for the year ended June 27, 2020 primarily include costs of transferring product lines to new production facilities, including Thailand of $11.5 million. We also incurred excess and obsolete inventory charges driven by the decline in demand from Huawei of $12.8 million during the year ended June 27, 2020. In addition, for the year ended June 27, 2020, we incurred $6.2 million impairment charges associated with excess capacity related to our Fiber laser business. Other charges for the years ended June 29, 2019 and June 30, 2018, primarily include costs of transferring product lines to Thailand of $45.8 million and $27.0 million, respectively.

[0001633978-20-000011:mdna:108]
In addition, there were net expenses of $6.6 million related to COVID-19 outbreak during the year ended June 27, 2020, which include incremental costs for payroll expense such as overtime pay, pay for employees who are not working, facilities costs such as gloves, masks and temperature gauges, and under-utilized capacity at certain facilities, in which manufacturing output was impacted. These COVID-19 related costs are offset by benefits realized from government credits for employers’ payroll tax.

[0001633978-20-000011:mdna:109]
The unallocated corporate items for the periods presented include the effects of amortization of acquired developed technologies and other intangibles, share-based compensation and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0001633978-20-000011:mdna:110]
Gross Margin

[0001633978-20-000011:mdna:111]
Gross margin in fiscal 2020 increased to 38.7% from 27.2% in fiscal 2019. The increase was primarily driven by better gross margins within Telecom, due to the acquisition of Oclaro, better gross margins within Datacom, due to the sale and exit of our Datacom transceiver module business which historically generated lower margins, increased revenue of our Datacom chip products, which have higher margins, and increased revenue of 3D sensing products for mobile devices, which have higher margins. In addition, for the year June 27, 2020, we had lower amortization of fair value adjustments related to the Oclaro acquisition of $48.8 million, as well as lower inventory and fixed asset write down charges due to product lines exit of $13.8 million.

[0001633978-20-000011:mdna:112]
Gross margin in fiscal 2019 decreased to 27.2% from 34.6% in fiscal 2018. The decrease was primarily due to amortization of intangibles and amortization of inventory step up related to the acquisition of Oclaro of $54.6 million, as well as inventory write down charges of $20.8 million due to our exit of Datacom module and Lithium Niobate product lines.

[0001633978-20-000011:mdna:113]
We sell products in certain markets that are consolidating, undergoing product, architectural and business model transitions, have high customer concentrations, are highly competitive, are price sensitive and/or are affected by customer seasonal and mix variant buying patterns. We expect these factors to continue to result in variability of our gross margin.

[0001633978-20-000011:mdna:114]
Although the magnitude of the impact of COVID-19 on our business operations remains uncertain and difficult to predict, and this remains a highly dynamic situation, we have experienced and we expect that we may continue to experience in subsequent periods, disruptions to our and our customers’ businesses that will adversely impact our business, financial condition and results of operations.

[0001633978-20-000011:mdna:115]
Segment Gross Margin

[0001633978-20-000011:mdna:116]
OpComms

[0001633978-20-000011:mdna:117]
OpComms gross margin in fiscal 2020 increased to 46.5% from 39.0% in fiscal 2019. The increase was primarily driven by better gross margins within Telecom, due to the acquisition of Oclaro, better gross margins within Datacom, due to the sale of our lower margin Datacom transceiver module business and increased revenue of our higher margin Datacom chip products, and increased revenue of 3D sensing products for mobile devices.

[0001633978-20-000011:mdna:118]
OpComms gross margin in fiscal 2019 increased to 39.0% from 38.0% in fiscal 2018. This increase was primarily due to increased sales of our ROADM products, which have higher gross margins than the average for the segment as well as increased sales of our transmission products due to the acquisition of Oclaro which have higher gross margins than legacy transmission products. This was partially offset by decreased sales of our 3D sensing products which have higher gross margins than the average for this segment.

[0001633978-20-000011:mdna:119]
Lasers

[0001633978-20-000011:mdna:120]
Lasers gross margin in fiscal 2020 increased to 46.6% from 43.3% in fiscal 2019. This increase was primarily driven by the streamlining of our manufacturing supply chain related to our kilowatt class fiber products.

[0001633978-20-000011:mdna:121]
Lasers gross margin in fiscal 2019 decreased to 43.3% from 43.9% in fiscal 2018. This decrease was primarily due to decreased sales of our solid state products which have higher gross margins than the average for the segment. This was partially offset by increased revenue and manufacturing utilization for our kilowatt class fiber products.

[0001633978-20-000011:mdna:122]
Research and Development (“R&D”)

[0001633978-20-000011:mdna:123]
R&D expense increased by $14.0 million, or 7.6%, in fiscal 2020 compared to fiscal 2019. The increase in R&D expense was primarily due to an increase of $10.7 million in payroll related expense, mainly due to the acquisition of Oclaro, partially offset by the sale of our Datacom transceiver module business. In addition, we had an increase of $7.6 million in investments in key product lines and R&D materials. These increases were offset by $2.8 million higher non-recurring engineering credits from customers and government grants.

[0001633978-20-000011:mdna:124]
R&D expense increased by $27.8 million, or 17.7%, in fiscal 2019 compared to fiscal 2018. The increase in R&D expense was primarily due to the increase in investments in key product lines and R&D materials. In addition, we had an increase in payroll related expense of $10.1 million as a result of our acquisition of Oclaro.

[0001633978-20-000011:mdna:125]
We believe that continuing our investments in R&D is critical to attaining our strategic objectives. Despite the uncertainty related to COVID-19 and the global economic outlook, we plan to continue to invest in R&D and new products that we believe will further differentiate us in the marketplace and expect our investment in R&D to increase in absolute dollars in future quarters.

[0001633978-20-000011:mdna:126]
Selling, General and Administrative (“SG&A”)

[0001633978-20-000011:mdna:127]
SG&A expense increased by $34.9 million, or 17.4%, in fiscal 2020 compared to fiscal 2019. The increase in SG&A expense was primarily due to the increase in amortization of intangibles of $16.8 million and integration related costs of $9.2 million as a result of the Oclaro acquisition, as well as the increase in payroll related expense of $16.2 million, offset by lower discretionary travel and trade shows of $2.6 million, partially due to COVID-19 restrictions in third and fourth quarters of fiscal 2020.

[0001633978-20-000011:mdna:128]
SG&A expense increased by $72.1 million, or 56.2%, in fiscal 2019 compared to fiscal 2018. The increase was primarily attributable to additional costs from our acquisition of Oclaro, including $14.6 million of payroll related expense, $2.4 million of facility related expense, $13.3 million in charges related to the acceleration of equity awards under certain Oclaro executive severance and retention agreements, $9.0 million related to the success fee on the closing of the Oclaro transaction, $8.0 million related to the amortization of acquired intangibles, and $3.1 million related to the incremental stock-based compensation expense of Oclaro awards. The remainder of the increase was primarily driven by higher payroll related expense and stock-based compensation.

[0001633978-20-000011:mdna:129]
From time to time, we expect to incur non-core expenses, such as mergers and acquisition-related expenses and litigation expenses, which will likely increase our SG&A expenses and potentially impact our profitability expectations in any particular quarter.

[0001633978-20-000011:mdna:130]
Restructuring and Related Charges

[0001633978-20-000011:mdna:131]
We have initiated various strategic restructuring events primarily intended to reduce costs, consolidate our operations, rationalize the manufacturing of our products and align our business in response to market conditions and as a result of our acquisition of Oclaro in the second quarter of fiscal 2019.

[0001633978-20-000011:mdna:132]
During fiscal 2020, we recorded $8.0 million in restructuring and related charges in our consolidated statements of operations. The charges were mainly attributable to severance charges associated with the decision to move certain manufacturing from San Jose, California to our facility in Thailand.

[0001633978-20-000011:mdna:133]
During fiscal 2019, we recorded $31.9 million in restructuring and related charges in our consolidated statements of operations, primarily attributable to severance and employee related benefits associated with the wind down of operations for Lithium Niobate modulators and Datacom modules of $21.1 million. In fiscal 2019, we also recorded $1.6 million of lease restructuring charges for the former Oclaro corporate headquarters and restructuring charges primarily associated with acquisition related synergies. In addition, the charges included severance and employee related benefits associated with Oclaro’s executive severance and retention agreements. These retention agreements provided, under certain circumstances, for payments and benefits upon an involuntary termination of employment.

[0001633978-20-000011:mdna:134]
Refer to “Note 14. Restructuring and Related Charges” in the notes to consolidated financial statements.

[0001633978-20-000011:mdna:135]
Impairment Charges

[0001633978-20-000011:mdna:136]
In the third quarter of fiscal 2019, we announced our plan to discontinue the development and manufacturing of future Datacom transceiver modules which impacted the California and China based Datacom module teams. As a result of these actions, we recorded impairment charges of $4.3 million and $30.7 million in fiscal 2020 and 2019, respectively, to our long-lived assets that were not deemed to be useful. While we expect strong growth in Datacom volumes in the future, gross margins at the transceiver market level are lower due to extreme competition. Following the Oclaro acquisition, we have a differentiated leadership position across a range of photonic chips on which the Datacom, wireless, and access markets critically rely.

[0001633978-20-000011:mdna:137]
Interest Expense

[0001633978-20-000011:mdna:138]
The components of interest expense are as follows for the years presented (in millions):

[0001633978-20-000011:mdna:139]
|  | Years Ended |
|  | June 27, 2020 |  | June 29, 2019 |  | June 30, 2018 |
| Interest expense | $ | (61.2 | ) |  | $ | (36.3 | ) |  | $ | (18.2 | ) |

[0001633978-20-000011:mdna:140]
For fiscal 2020, we recorded interest expense of $61.2 million. The increase in interest expense during fiscal 2020 as compared to fiscal 2019 was mainly driven by the increase in amortization of the debt discount and contractual interest expense due to the issuance of our 0.50% Convertible Notes due in 2026 (the “2026 Notes”), as well as the loss on early extinguishment of debt of $8.0 million, which represents the write-off of the issuance costs in conjunction with payback of our term loan facility in the second quarter of fiscal 2020.

[0001633978-20-000011:mdna:141]
For fiscal 2019, we recorded interest expense of $36.3 million. The increase in interest expense during fiscal 2019 as compared to fiscal 2018 was mainly driven by interest expense on our term loan and ticking fees.

[0001633978-20-000011:mdna:142]
Other Income, Net

[0001633978-20-000011:mdna:143]
The components of other income (expense), net are as follows for the years presented (in millions):

[0001633978-20-000011:mdna:144]
|  | Years Ended |
|  | June 27, 2020 |  | June 29, 2019 |  | June 30, 2018 |
| Foreign exchange gains (losses), net | $ | (1.4 | ) |  | $ | (0.6 | ) |  | $ | (0.3 | ) |
| Interest income | 15.8 |  |  | 13.9 |  |  | 8.5 |  |
| Other income, net | 17.0 |  |  | 2.5 |  |  | 0.3 |  |
| Total other income (expense), net | $ | 31.4 |  |  | $ | 15.8 |  |  | $ | 8.5 |  |

[0001633978-20-000011:mdna:145]
During fiscal 2020, other income, net increased by $15.6 million as compared to fiscal 2019, mainly driven by a gain on the sale of Lithium Niobate modulators business of $13.8 million, completed in fiscal 2020.

[0001633978-20-000011:mdna:146]
During fiscal 2019, other income, net increased by $7.3 million as compared to fiscal 2018, mainly driven by higher interest income due to higher interest rates on our investment portfolio.

[0001633978-20-000011:mdna:147]
Unrealized Gain (Loss) on Derivative Liability

[0001633978-20-000011:mdna:148]
Unrealized gain (loss) on Series A Preferred Stock derivative liability amounted to $8.8 million and $(0.8) million in fiscal 2019 and 2018, respectively. On November 2, 2018, all 35,805 shares of our Series A Preferred Stock were converted to common stock with the outstanding balance of the embedded derivative liability reclassed to additional paid in capital. There will be no further adjustments to “unrealized gain (loss) on derivative liability” due to this conversion.

[0001633978-20-000011:mdna:149]
For further discussion of our derivative liability, see “Note 11. Non-Controlling Interest Redeemable Convertible Preferred Stock and Derivative Liability” in the notes to consolidated financial statements.

[0001633978-20-000011:mdna:150]
Provision for (Benefit from) Income Taxes (in millions):

[0001633978-20-000011:mdna:151]
|  |  | Years Ended |
|  |  | June 27, 2020 |  | June 29, 2019 |  | July 1, 2017 |
| Provision for (benefit from) income taxes |  | $ | 38.8 |  |  | $ | 3.1 |  |  | $ | (118.7 | ) |

[0001633978-20-000011:mdna:152]
Our provision for income taxes for fiscal 2020 differs from the 21% U.S. statutory rate primarily due to the Global Intangible Low-Taxed Income (“GILTI”) and subpart F inclusions and an increase to the valuation allowance because it is not more-likely-than-not that certain deferred tax assets will be realizable, which are partially offset by the income tax benefit of the earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate as well as the U.S. federal R&D tax credit.

[0001633978-20-000011:mdna:153]
Our provision for income taxes for fiscal 2019 differs from the 21% U.S. statutory rate primarily due to GILTI and subpart F inclusions and the income tax expense from non-deductible stock-based compensation and increased valuation allowance in the

[0001633978-20-000011:mdna:154]
U.K. and Thailand, partially offset by the income tax benefit of the earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate as well as the U.S. federal R&D tax credit.

[0001633978-20-000011:mdna:155]
Our provision for income taxes for fiscal 2018 differed from the tax provision based on the U.S. statutory federal income tax rate of approximately 28% as a result of $207.2 million of income tax benefit related to the release of valuation allowance against our U.S. federal and certain state deferred tax assets, partially offset by $80.5 million of income tax expense related to the remeasurement of our net deferred tax assets as a result of reduction in the U.S. federal corporate tax rate. Our provision for income taxes was also impacted by the benefit our foreign income being taxed at lower rates than the U.S. statutory rate, as well as the benefit of research and development tax credits.

[0001633978-20-000011:mdna:156]
The comparability of our operating results of fiscal 2019 compared to the corresponding prior year was impacted by the U.S. Tax Cuts and Jobs Act of 2017 (the “Tax Act”), which was enacted on December 22, 2017. The Tax Act introduced significant changes to U.S. income tax law including reducing the U.S. federal statutory tax rate from 35% to 21% and imposing new taxes on certain foreign-sourced earnings and certain intercompany payments. Due to the timing of the enactment and the complexity involved in applying the provisions of the Tax Act, we made reasonable estimates of the effects and recorded provisional amounts in our financial statements as of fiscal 2018 in accordance with SEC Staff Accounting Bulletin No. 118 (“SAB 118”). During the period ended December 29, 2018, we completed our accounting for the Tax Act with no material adjustment to our provisional estimates recorded.

[0001633978-20-000011:mdna:157]
Contractual Obligations

[0001633978-20-000011:mdna:158]
The following table summarizes our contractual obligations as of June 27, 2020, and the effect such obligations are expected to have on our liquidity and cash flow over the next five years (in millions):

[0001633978-20-000011:mdna:159]
|  | Payments due by period |
|  | Total |  | Less than 1 year |  | 1 - 3 years |  | 3 - 5 years |  | More than 5 years |
| Contractual Obligations |  |  |  |  |  |  |  |  |  |
| Asset retirement obligations | $ | 4.9 |  |  | $ | 0.3 |  |  | $ | 1.0 |  |  | $ | 1.4 |  |  | $ | 2.2 |  |
| Finance lease liabilities, including imputed interest | 0.6 |  |  | 0.6 |  |  | — |  |  | — |  |  | — |  |
| Operating lease liabilities, including imputed interest (1) | 77.8 |  |  | 13.1 |  |  | 23.6 |  |  | 15.8 |  |  | 25.3 |  |
| Pension plan contributions (2) | 0.5 |  |  | 0.5 |  |  | — |  |  | — |  |  | — |  |
| Purchase obligations (3) | 261.5 |  |  | 251.1 |  |  | 10.1 |  |  | 0.3 |  |  | — |  |
| Convertible notes - principal (4) | 1,500.0 |  |  | — |  |  | — |  |  | 450.0 |  |  | 1,050.0 |  |
| Convertible notes - interest (4) | 38.6 |  |  | 6.3 |  |  | 12.7 |  |  | 11.7 |  |  | 7.9 |  |
| Total | $ | 1,883.9 |  |  | $ | 271.9 |  |  | $ | 47.4 |  |  | $ | 479.2 |  |  | $ | 1,085.4 |  |

[0001633978-20-000011:mdna:160]
(1) The amounts of operating lease liabilities in the table above do not include any sublease income amounts nor do they include payments for short-term leases or variable lease payments. As of June 27, 2020, we expect to receive sublease income of approximately $5.4 million over the next three years. Refer to “Note 9. Leases” in the notes to consolidated financial statements.

[0001633978-20-000011:mdna:161]
(2) The amount in the preceding table represents planned contributions to our defined benefit plans. Although additional future contributions will be required, the amount and timing of these contributions will be affected by actuarial assumptions, the actual rate of returns on plan assets, the level of market interest rates, legislative changes, and the amount of voluntary contributions to the plan. Any contributions for the following fiscal year and later will depend on the value of the plan assets in the future and thus are uncertain. As such, we have not included any amounts beyond one year in the table above.  Refer to “Note 18. Employee Retirement Plans” in the notes to consolidated financial statements.

[0001633978-20-000011:mdna:162]
(3) Purchase obligations represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Refer to “Note 19. Commitments and Contingencies” in the notes to consolidated financial statements.

[0001633978-20-000011:mdna:163]
(4)  Includes principal and interest on our 0.25% Convertible Notes due in 2024 (the “2024 Notes” and together with the 2026 Notes, the “Notes”) through March 2024, and principal and interest on our 0.5% 2026 Notes through December 2026. We have the right to redeem the 2024 Notes and the 2026 Notes in whole or in part at any time on or after March 15, 2024 and on or after December 15, 2026, respectively. Refer to “Note 12. Debt” in the notes to consolidated financial statements.

[0001633978-20-000011:mdna:164]
As of June 27, 2020, our other non-current liabilities also include $17.3 million of unrecognized tax benefit for uncertain tax positions. We are unable to reliably estimate the timing of future payments related to uncertain tax positions and therefore have excluded them from the preceding table.

[0001633978-20-000011:mdna:165]
Off-Balance Sheet Arrangements

[0001633978-20-000011:mdna:166]
We do not have any off-balance sheet arrangements, as such term is defined in rules promulgated by the SEC, that have or are reasonably likely to have a current or future effect on our financial condition, changes in financial condition, revenues or expenses, results of operations, liquidity, capital expenditures or capital resources that are material to investors.

[0001633978-20-000011:mdna:167]
Defined Benefit Plans

[0001633978-20-000011:mdna:168]
The Company sponsors defined benefit pension plans covering employees in Japan, Switzerland, and Thailand. Pension plan benefits are based primarily on participants’ compensation and years of service credited as specified under the terms of each country’s plan. Employees are entitled to a lump sum benefit upon retirement or upon certain instances of termination.  The funding policy is consistent with the local requirements of each country. As of June 27, 2020, a defined benefit plan in Switzerland was partially funded, while defined benefit plans in Japan and Thailand were unfunded. As of June 27, 2020, our projected benefit obligations, net in Japan, Switzerland, and Thailand were $2.9 million, $6.4 million, and $2.5 million, respectively. They were recorded in our consolidated balance sheets as other non-current liabilities and represent the total projected benefit obligation (“PBO”) less the fair value of plan assets.

[0001633978-20-000011:mdna:169]
A key actuarial assumption in calculating the net periodic cost and the PBO is the discount rate. Changes in the discount rate impact the interest cost component of the net periodic benefit cost calculation and PBO due to the fact that the PBO is calculated on a net present value basis. Decreases in the discount rate will generally increase pre-tax cost, recognized expense and the PBO. Increases in the discount rate tend to have the opposite effect. We estimate a 50 basis point decrease or increase in the discount rate would cause a corresponding increase or decrease, respectively, in the PBO of $1.9 million or $(1.7) million, based upon data as of June 27, 2020.

[0001633978-20-000011:mdna:170]
We expect to contribute $0.5 million to our defined benefit pension plans in fiscal 2021.

[0001633978-20-000011:mdna:171]
Financial Condition

[0001633978-20-000011:mdna:172]
Liquidity and Capital Resources

[0001633978-20-000011:mdna:173]
As of June 27, 2020 and June 29, 2019, our cash and cash equivalents of $298.0 million and $432.6 million, respectively, were largely held in the United States. As of June 27, 2020 and June 29, 2019, our short-term investments of $1,255.8 million and $335.9 million, respectively, were all held in the United States. Cash equivalents and short-term investments are primarily comprised of money market funds, treasuries, and highly liquid investment grade fixed income securities. Our investment policy and strategy is focused on the preservation of capital and supporting our liquidity requirements.

[0001633978-20-000011:mdna:174]
The total amount of cash outside the United States as of June 27, 2020 was $81.3 million, which was primarily held by entities incorporated in the British Virgin Islands, China, Hong Kong, Japan, Thailand, and the United Kingdom. Although the cash currently held in the United States as well as the cash generated in the United States from future operations is expected to cover our normal operating requirements, a substantial amount of additional cash could be required for other purposes, such as capital expenditures to support our business and growth, including costs associated with increasing internal manufacturing capabilities, particularly in our Thailand facility, strategic transactions and partnerships, and future acquisitions.

[0001633978-20-000011:mdna:175]
Our intent is to indefinitely reinvest funds held outside the United States, except for the funds held in the Cayman Islands, Japan and Hong Kong, and our current plans do not demonstrate a need to repatriate them to fund our domestic operations. However, if in the future, we encounter a significant need for liquidity domestically or at a particular location that we cannot fulfill through borrowings, equity offerings, or other internal or external sources, or the cost to bring back the money is insignificant from a tax perspective, we may determine that cash repatriations are necessary or desirable. Repatriation could result in additional material taxes. These factors may cause us to have an overall tax rate higher than other companies or higher than our tax rates have been in the past. If conditions warrant, we may seek to obtain additional financing through debt or equity sources. To the extent we issue additional shares, our existing stockholders may be diluted. However, any such financing may not be available on terms favorable to us, or may not be available at all.

[0001633978-20-000011:mdna:176]
During fiscal 2020 and 2019, the debt component of our 2024 Notes was recorded in long-term liabilities. However, if our stock price exceeds $78.80 for 20 of the last 30 trading days of the first quarter of fiscal 2021, the 2024 Notes would become callable at the option of the holders.

[0001633978-20-000011:mdna:177]
Fiscal 2020

[0001633978-20-000011:mdna:178]
As of June 27, 2020, our consolidated balance of cash and cash equivalents decreased by $134.6 million, to $298.0 million from $432.6 million as of June 29, 2019. The decrease in cash and cash equivalents was mainly due to cash used in investing activities of $987.7 million, offset by cash provided by operating activities of $524.3 million and cash provided by financing activities of $328.8 million during the year ended June 27, 2020.

[0001633978-20-000011:mdna:179]
Cash provided by operating activities of $524.3 million during the year ended June 27, 2020, primarily resulted from $323.4 million of non-cash items (such as depreciation, stock-based compensation, amortization of intangibles, amortization of debt discount and debt issuance costs on our term loan and the Notes, and other non-cash items), net income of $135.5 million, and $65.4 million of changes in our operating assets and liabilities.

[0001633978-20-000011:mdna:180]
Cash used in investing activities of $987.7 million during the year ended June 27, 2020, was primarily attributable to purchases of short-term investments, net of sales and maturities of $917.8 million. In addition, we had capital expenditures of $86.0 million, payment for asset acquisition of $4.0 million, offset by proceeds from sales of product lines of $20.1 million.

[0001633978-20-000011:mdna:181]
Cash provided by financing activities of $328.8 million during the year ended June 27, 2020, primarily resulted from the proceeds of the issuance of the 2026 Notes of $1,042.2 million, net of issuance costs, offset by repayment of our term loan facility of $497.5 million and the repurchase of shares of our common stock of $200.0 million.

[0001633978-20-000011:mdna:182]
Fiscal 2019

[0001633978-20-000011:mdna:183]
As of June 29, 2019, our consolidated balance of cash and cash equivalents increased by $35.3 million, to $432.6 million from $397.3 million as of June 30, 2018. The increase in cash and cash equivalents was mainly due to cash provided by financing activities of $485.1 million, primarily related to $490.8 million in proceeds from a term loan, net of debt issuance costs, used to fund the Oclaro acquisition, and cash provided by operating activities of $330.1 million during the year ended June 29, 2019; which was offset by cash used in investing activities of $779.7 million, principally related to net cash of $619.8 million paid to acquire Oclaro.

[0001633978-20-000011:mdna:184]
Cash provided by operating activities of $330.1 million during the year ended June 29, 2019, primarily resulted from $314.4 million of non-cash items (such as depreciation, stock-based compensation, amortization of intangibles, amortization of discount on the 2024 Notes, amortization of the debt issuance costs on the term loan, amortization of fair value adjustment in connection with the acquisition of Oclaro, impairment charges, net of unrealized gain on derivative liability and other non-cash items) and $52.1 million of changes in our operating assets and liabilities, offset by our net loss of $36.4 million.

[0001633978-20-000011:mdna:185]
Cash used in investing activities of $779.7 million during the year ended June 29, 2019, was primarily attributable to $619.8 million paid to acquire all outstanding shares of common stock of Oclaro, net of cash received through the acquisition of Oclaro. In addition, we had capital expenditures of $166.0 million (mainly attributable to the purchase of the property for $54.6 million), payment for asset acquisition of $1.3 million, purchases of short-term investments, net of sales of $18.1 million, offset by proceeds from sales of product lines of $25.5 million.

[0001633978-20-000011:mdna:186]
Cash provided by financing activities of $485.1 million during the year ended June 29, 2019, primarily resulted from $490.8 million of proceeds from a term loan, net of debt issuance costs, used to partially finance the Oclaro acquisition, offset by the repayment of a term loan of $2.5 million. In addition, we received $9.3 million from the issuance of common stock under our employee stock plan, offset by the repayment of finance lease obligations of $8.8 million, tax payments related to restricted stock of $2.4 million, a payment of an acquisition related holdback of $1.0 million, and dividend payments on our Series A Preferred Stock of $0.7 million.

[0001633978-20-000011:mdna:187]
Fiscal 2018

[0001633978-20-000011:mdna:188]
As of June 30, 2018, our consolidated balance of cash and cash equivalents increased by $124.4 million, to $397.3 million from $272.9 million as of July 1, 2017. The increase in cash and cash equivalents was mainly due to cash provided by operating activities of $247.5 million during fiscal 2018 offset by purchases of short-term investments, net of sales of $33.8 million and capital expenditures of $93.2 million.

[0001633978-20-000011:mdna:189]
Cash provided by operating activities was $247.5 million for the year ended June 30, 2018, primarily resulting from $248.1 million of net income and $18.5 million of non-cash items (such as depreciation, stock-based compensation, amortization of intangibles, amortization of discount on the 2024 Notes, net of the release of the valuation allowance), offset by $19.1 million of changes in our operating assets and liabilities. Changes in our operating assets and liabilities related primarily to an increase in accounts receivable of $30.8 million, offset by an increase in accrued expenses and other current and non-current liabilities of $11.9 million.

[0001633978-20-000011:mdna:190]
Cash used in investing activities of $127.0 million for the year ended June 30, 2018, was primarily attributable to capital expenditures of $93.2 million and purchases of short-term investments, net of sales of $33.8 million.

[0001633978-20-000011:mdna:191]
Cash provided by financing activities was $3.8 million for the year ended June 30, 2018, resulting primarily from the issuance of common stock under the 2015 Employee Stock Purchase Plan of $9.2 million offset by repayment of finance lease obligation of $6.4 million.

[0001633978-20-000011:mdna:192]
Liquidity and Capital Resources Requirements

[0001633978-20-000011:mdna:193]
We believe that our cash and cash equivalents as of June 27, 2020, and cash flows from our operating activities will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months. However, if market conditions are favorable, we may evaluate alternatives to opportunistically pursue additional financing.

[0001633978-20-000011:mdna:194]
There are a number of factors that could positively or negatively impact our liquidity position, including:

[0001633978-20-000011:mdna:195]
| • | global economic conditions which affect demand for our products and services and impact the financial stability of our suppliers and customers, including the impact of COVID-19; |

[0001633978-20-000011:mdna:196]
| • | fluctuations in demand for our products as a result of changes in regulations, tariffs or other trade barriers, and trade relations in general; |

[0001633978-20-000011:mdna:197]
| • | changes in accounts receivable, inventory or other operating assets and liabilities, which affect our working capital; |

[0001633978-20-000011:mdna:198]
| • | increase in capital expenditures to support our business and growth; |

[0001633978-20-000011:mdna:199]
| • | the tendency of customers to delay payments or to negotiate favorable payment terms to manage their own liquidity positions; |

[0001633978-20-000011:mdna:200]
| • | timing of payments to our suppliers; |

[0001633978-20-000011:mdna:201]
| • | factoring or sale of accounts receivable; |

[0001633978-20-000011:mdna:202]
| • | volatility in fixed income and credit, which impact the liquidity and valuation of our investment portfolios; |

[0001633978-20-000011:mdna:203]
| • | volatility in foreign exchange markets, which impacts our financial results; |

[0001633978-20-000011:mdna:204]
| • | possible investments or acquisitions of complementary businesses, products or technologies, or other strategic transactions or partnerships; |

[0001633978-20-000011:mdna:205]
| • | issuance of debt or equity securities, or other financing transactions, including bank debt; |

[0001633978-20-000011:mdna:206]
| • | potential funding of pension liabilities either voluntarily or as required by law or regulation; and |

[0001633978-20-000011:mdna:207]
| • | the settlement of any conversion or redemption of the 2024 Notes and the 2026 Notes in cash. |

[0001633978-20-000011:mdna:208]
52
