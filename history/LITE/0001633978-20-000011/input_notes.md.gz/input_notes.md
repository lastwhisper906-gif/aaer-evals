# LITE notes — 0001633978-20-000011


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001633978-20-000011:notes:1]
Portions of the information called for by Part III of this Annual Report on Form 10-K is hereby incorporated by reference from the definitive proxy statement for the Registrant’s annual meeting of stockholders, which will be filed with the Securities and Exchange Commission not later than 120 days after the Registrant’s fiscal year ended June 27, 2020.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001633978-20-000011:notes:2]
Note 1. Description of Business and Summary of Significant Accounting Policies

[0001633978-20-000011:notes:3]
Description of Business

[0001633978-20-000011:notes:4]
Lumentum Holdings Inc. (“we,” “us,” “our”, “Lumentum” or the “Company”) is an industry-leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including Optical Communications (“OpComms”) and Commercial Lasers (“Lasers”) for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology, and our volume manufacturing capability, to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be original equipment manufacturers (“OEMs”) that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that network equipment manufacturers (“NEMs”) assemble into communications networking systems, which they sell to network service providers, operators or enterprises with their own networks. Similarly, many of our customers for our Lasers products incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For 3D sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, gaming, and other applications who then integrate our devices within their products, for eventual resale to consumers and also into other industrial applications.

[0001633978-20-000011:notes:5]
Basis of Presentation

[0001633978-20-000011:notes:6]
The preparation of the consolidated financial statements in accordance with U.S. generally accepted accounting principles (“GAAP”) requires management to make estimates and assumptions that affect the amounts reported in our consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are inventory valuation, revenue recognition, income taxes, long-lived asset valuation, business combinations and goodwill.

[0001633978-20-000011:notes:7]
On December 10, 2018, we completed our merger with Oclaro, Inc. (“Oclaro”), a provider of optical components and modules for the long-haul, metro and data center markets. Our consolidated financial statements include the operating results of Oclaro beginning from the date of acquisition. Refer to “Note 4. Business Combinations” for further discussion of the merger.

[0001633978-20-000011:notes:8]
The COVID-19 pandemic has created and may continue to create significant uncertainty in global financial markets, which has disrupted and harmed, and may continue to disrupt and harm, the Company's business, financial condition, and results of operations. The extent of the impact of COVID-19 on the Company's operational and financial performance will depend on certain developments, including but not limited to the duration and spread of the outbreak, duration of local, state and federal issued public health orders in each jurisdiction where we operate or in which our customers and suppliers operate, impact on our customers and our sales cycles, impact on our supply chain and manufacturing partners, impact on our employees and impact on regional and worldwide economies and financial markets in general, all of which are uncertain and cannot be predicted.

[0001633978-20-000011:notes:9]
Fiscal Years

[0001633978-20-000011:notes:10]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2021 will be a 53-week year. Our fiscal 2020, 2019, and 2018 ended on June 27, 2020, June 29, 2019 and  June 30, 2018, respectively, and were 52-week years.

[0001633978-20-000011:notes:11]
Principles of Consolidation

[0001633978-20-000011:notes:12]
The preparation of the consolidated financial statements in accordance with GAAP in the United States requires management to make estimates and assumptions that affect the amounts reported in our consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates.

[0001633978-20-000011:notes:13]
Certain prior period amounts have been reclassified to conform to the current period presentation, including the reclassification of capital lease obligations that existed as of June 29, 2019 to finance lease liabilities within other current liabilities and other non-current liabilities in our consolidated balance sheets, as a result of the adoption of the new accounting guidance for leases. Refer to “Note 2. Recently Issued Accounting Pronouncements” for details. The reclassification of the prior period amounts did not impact previously reported consolidated financial statements.

[0001633978-20-000011:notes:14]
Summary of Significant Accounting Policies

[0001633978-20-000011:notes:15]
Our significant accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. We believe that of our significant accounting policies described below, certain accounting policies involve a greater degree of judgment and complexity and are the most critical to aid in fully understanding and evaluating our consolidated financial statements. These policies are inventory valuation, revenue recognition, income taxes, long-lived asset valuation, and goodwill. For a description of our critical accounting policies, also refer to “Management’s Discussion and Analysis of Financial Condition and Results of Operations”, Critical Accounting Policies and Estimates.

[0001633978-20-000011:notes:16]
Leases

[0001633978-20-000011:notes:17]
We adopted Topic 842 on June 30, 2019, the first day of fiscal year 2020, using the modified retrospective transition approach. Refer to “Note 2. Recently Issued Accounting Pronouncements” regarding the impact of adoption.

[0001633978-20-000011:notes:18]
We determine if an arrangement is a lease at inception for arrangements with an initial term of more than 12 months, and classify it as either finance or operating.

[0001633978-20-000011:notes:19]
Finance leases are generally those that allow us to substantially utilize or pay for the entire asset over its estimated useful life. Finance leases are recorded in property, plant and equipment, net, and finance lease liabilities within other current and other non-current liabilities on our consolidated balance sheets. We have lease arrangements with lease and non-lease components, and the non-lease components for our finance leases are accounted for separately, based on estimated stand-alone values, and are not included in the initial measurement of our finance lease assets and corresponding liabilities. Finance lease assets are amortized in operating expenses on a straight-line basis over the shorter of the estimated useful lives of the assets or the lease term, with the interest component included in interest expense and recognized using the effective interest method over the lease term.

[0001633978-20-000011:notes:20]
Operating leases are recorded in operating lease right-of-use assets, net, and operating lease liabilities, current and non-current on our consolidated balance sheets. For operating leases of buildings, we account for non-lease components, such as common area maintenance, as a component of the lease, and include it in the initial measurement of our operating lease assets and corresponding liabilities. Operating lease assets are amortized on a straight-line basis in operating expenses over the lease term.

[0001633978-20-000011:notes:21]
Our lease liabilities are recognized based on the present value of the remaining fixed lease payments, over the lease term, using a discount rate of similarly secured borrowings available to us. For the purpose of lease liability measurement, we consider only payments that are fixed and determinable at the time of commencement. Any variable payments that depend on an index or rate are expensed as incurred. Our lease terms may include options to extend when it is reasonably certain that we will exercise that option. Our lease assets also include any lease payments made and exclude any lease incentives received prior to commencement. Our lease assets are tested for impairment in the same manner as long-lived assets used in operations. We generally recognize sublease income on a straight-line basis over the sublease term.

[0001633978-20-000011:notes:22]
Cash and Cash Equivalents

[0001633978-20-000011:notes:23]
We consider highly-liquid fixed income securities with original maturities of three months or less at the time of purchase to be cash equivalents. As of fiscal year ended June 27, 2020, our cash equivalents consist of money market funds and U.S. Treasury securities. As of fiscal year ended June 27, 2020, our cash and cash equivalents did not include any investments with original maturities of three months or less.

[0001633978-20-000011:notes:24]
Short-Term Investments

[0001633978-20-000011:notes:25]
We classify our investments in debt as available-for-sale and record these investments at fair value. Investments with an original maturity of three months or less at the date of purchase are considered cash equivalents, while all other investments are classified as short-term based on management’s intent and ability to use the funds in current operations. Unrealized gains and losses are reported as a component of other comprehensive loss. Realized gains and losses are determined based on the specific identification method, and are reflected as interest and other income (expense), net in our Consolidated Statements of Operations. We regularly review our investment portfolio to identify and evaluate investments that have indicators of possible impairment. Factors considered in determining whether a loss is other-than-temporary include, but are not limited to: the length of time and extent a security’s fair value has been below its cost, the financial condition and near-term prospects of the investee, the credit quality of the security’s issuer, likelihood of recovery and our intent and ability to hold the security for a period of time sufficient to allow for any anticipated recovery in value. For our debt instruments, we also evaluate whether we have the intent to sell the security or it is more likely than not that we will be required to sell the security before recovery of its cost basis.

[0001633978-20-000011:notes:26]
Fair Value of Financial Instruments

[0001633978-20-000011:notes:27]
We define fair value as the price that would be received from selling an asset, or paid to transfer a liability, in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities which are required to be recorded at fair value, we consider the principal or most advantageous market in which to transact and the market-based risk. We apply fair value accounting for all financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. The carrying amounts reported in the consolidated financial statements approximate the fair value for cash and cash equivalents, accounts receivable, accounts payable and accrued liabilities due to their short-term nature.

[0001633978-20-000011:notes:28]
Basic and Diluted Net Income (Loss) per Common Share

[0001633978-20-000011:notes:29]
Basic income (loss) per share is computed by dividing net income (loss) available to common stockholders by the weighted average number of common shares outstanding during the reporting period. The weighted average number of shares is calculated by taking the number of shares outstanding and weighting them by the amount of time that they were outstanding.  Diluted earnings per share reflects the potential dilution that could occur if stock options, preferred stock, and other commitments to issue common stock were exercised or equity awards vest resulting in the issuance of common stock that could share in the earnings of the Company.

[0001633978-20-000011:notes:30]
Diluted loss per share is the same as basic loss per share during periods where net losses are incurred since the inclusion of the potential common stock equivalents would be anti-dilutive as a result of the net loss.

[0001633978-20-000011:notes:31]
Our Series A Preferred Stock was considered a participating security where the holders of Series A Preferred Stock had the right to participate in undistributed earnings with holders of common stock. On November 2, 2018, the remaining 35,805 shares of our Series A Preferred Stock were converted into 1.5 million shares of our common stock. Refer to “Note 11. Non-Controlling Interest Redeemable Convertible Preferred Stock and Derivative Liability” for further discussion. Prior to conversion, the holders of our Series A Preferred Stock were entitled to share in dividends, on an as-converted basis, if the holders of our common stock were to receive dividends. Up through the date of conversion, we used the two-class method to compute earnings per share. The two-class method is an earnings allocation formula that determines earnings per share for each class of common stock and participating security according to dividends declared (or accumulated) and participation rights in undistributed earnings. In determining the amount of net earnings to allocate to common stockholders, earnings are allocated to both common and participating securities based on their respective weighted-average shares outstanding during the period. Diluted earnings per common share is calculated similar to basic earnings per common share except that it gives effect to all potentially dilutive common stock equivalents outstanding for the period, using the treasury stock method.

[0001633978-20-000011:notes:32]
Potentially dilutive common shares result from the assumed exercise of outstanding stock options, assumed vesting of outstanding equity awards, assumed issuance of stock under the employee stock purchase plan, and assumed conversion of our outstanding $450 million in aggregate principal amount of 0.25% Convertible Notes due in 2024 (the “2024 Notes”) and $1,050 million in aggregate principal amount of 0.50% Convertible Notes due in 2026 (the “2026 Notes” and together with the 2024 Notes, the “convertible notes”), all using the treasury stock method as we have the ability and intent to settle the face value of the convertible notes in cash.

[0001633978-20-000011:notes:33]
The dilutive effect of securities from the 2015 Equity Incentive Plan is reflected in diluted earnings per share by application of the treasury stock method, which includes consideration of unamortized share-based compensation expense and the dilutive effect of in-the-money options and non-vested restricted stock units. Under the treasury stock method, the amount the employee

[0001633978-20-000011:notes:34]
must pay for exercising stock options and the amount of unamortized share-based compensation expense are collectively assumed to be used to repurchase hypothetical shares. An increase in the fair value of our common stock can result in a greater dilutive effect from potentially dilutive awards.

[0001633978-20-000011:notes:35]
Anti-dilutive potential shares from 2015 Equity Incentive Plan are excluded from the calculation of diluted earnings per share if their exercise price exceeded the average market price during the period or the share-based awards were determined to be anti-dilutive based on applying the treasury stock method.

[0001633978-20-000011:notes:36]
Inventory Valuation

[0001633978-20-000011:notes:37]
Inventory is valued at standard cost, which approximates actual cost computed on a first-in, first-out basis, not in excess of net realizable value. We assess the value of our inventory on a quarterly basis and write down those inventories which are obsolete or in excess of our forecasted demand to the lower of their cost or estimated net realizable value. Our estimates of forecasted demand are based upon our analysis and assumptions including, but not limited to, expected product lifecycles, product development plans and historical usage by product. Our product line management personnel play a key role in our excess review process by providing updated sales forecasts, managing product transitions and working with manufacturing to minimize excess inventory. If actual market conditions are less favorable than our forecasts, or actual demand from our customers is lower than our estimates, we may be required to record additional inventory write-downs. If actual market conditions are more favorable than anticipated, inventory previously written down may be sold, resulting in lower cost of sales and higher income from operations than expected in that period.

[0001633978-20-000011:notes:38]
Revenue Recognition

[0001633978-20-000011:notes:39]
Adoption of Topic 606

[0001633978-20-000011:notes:40]
Pursuant to Topic 606, our revenues are recognized upon the application of the following steps:

[0001633978-20-000011:notes:41]
| • | identification of the contract, or contracts, with a customer; |

[0001633978-20-000011:notes:42]
| • | identification of the performance obligations in the contract; |

[0001633978-20-000011:notes:43]
| • | determination of the transaction price; |

[0001633978-20-000011:notes:44]
| • | allocation of the transaction price to the performance obligations in the contract; and |

[0001633978-20-000011:notes:45]
| • | recognition of revenues when, or as, the contractual performance obligations are satisfied. |

[0001633978-20-000011:notes:46]
The majority of our revenue comes from product sales, consisting of sales of Lasers and OpComms hardware products to our customers. Our revenue contracts generally include only one performance obligation. Revenues are recognized at a point in time when control of the promised goods or services are transferred to our customers upon shipment or delivery, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services. We have entered into vendor managed inventory (“VMI”) programs with our customers. Under these arrangements, we receive purchase orders from our customers, and the inventory is shipped to the VMI location upon receipt of the purchase order. The customer then pulls the inventory from the VMI hub based on its production needs. Revenue under VMI programs is recognized when control transfers to the customer, which is generally once the customer pulls the inventory from the hub.

[0001633978-20-000011:notes:47]
Revenue from all sales types is recognized at the transaction price. The transaction price is determined based on the consideration to which we will be entitled in exchange for transferring goods or services to the customer adjusted for estimated variable consideration, if any. We typically estimate the impact on the transaction price for discounts offered to the customers for early payments on receivables or net of accruals for estimated sales returns. These estimates are based on historical returns, analysis of credit memo data and other known factors. Actual returns could differ from these estimates. We allocate the transaction price to each distinct product based on its relative standalone selling price. The product price as specified on the purchase order is considered the standalone selling price as it is an observable input that depicts the price as if sold to a similar customer in similar circumstances.

[0001633978-20-000011:notes:48]
Taxes assessed by a governmental authority that are both imposed on and concurrent with a specific revenue-producing transaction, that are collected by us from a customer and deposited with the relevant government authority, are excluded from revenue. Our revenue arrangements do not contain significant financing components as our standard payment terms are less than one year.

[0001633978-20-000011:notes:49]
If a customer pays consideration, or the Company has a right to an amount of consideration that is unconditional before we transfer a good or service to the customer, those amounts are classified as deferred revenue or deposits received from customers which are included in other current liabilities or other long-term liabilities when the payment is made or it is due, whichever is earlier.

[0001633978-20-000011:notes:50]
Transaction Price Allocated to the Remaining Performance Obligations

[0001633978-20-000011:notes:51]
Remaining performance obligations represent the transaction price allocated to performances obligations that are unsatisfied or partially unsatisfied as of the end of the reporting period. Unsatisfied and partially unsatisfied performance obligations consist of contract liabilities and non-cancellable backlog. Non-cancellable backlog includes goods and services for which customer purchase orders have been accepted that are scheduled or in the process of being scheduled for shipment. A portion of our revenue arises from vendor managed inventory arrangements where the timing and volume of customer utilization is difficult to predict.

[0001633978-20-000011:notes:52]
The following table includes estimated revenue expected to be recognized in the future for backlog related performance obligations that are unsatisfied as of June 27, 2020 (in millions):

[0001633978-20-000011:notes:53]
|  | Less than 1 year | 1-2 years | Greater than 2 years | Total |
| Performance Obligations | $525.5 | $32.3 | $— | $557.8 |

[0001633978-20-000011:notes:54]
Warranty

[0001633978-20-000011:notes:55]
Hardware products regularly include warranties to the end customers such that the product continues to function according to published specifications. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, specific market, product line and geography in which we operate, and what is common in the industry, our warranties can vary and range from six months to five years. These standard warranties are assurance type warranties and do not offer any services in addition to the assurance that the product will continue working as specified. Therefore, warranties are not considered separate performance obligations in the arrangement. Instead, the expected cost of warranty is accrued as expense in accordance with authoritative guidance.

[0001633978-20-000011:notes:56]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We estimate the costs of our warranty obligations based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise.

[0001633978-20-000011:notes:57]
Shipping and Handling Costs

[0001633978-20-000011:notes:58]
We record shipping and handling costs related to revenue transactions within cost of sales as a period cost.

[0001633978-20-000011:notes:59]
Contract Costs

[0001633978-20-000011:notes:60]
The Company recognizes the incremental direct costs of obtaining a contract, which consist of sales commissions, when control over the products they relate to transfers to the customer. Applying the practical expedient, the Company recognizes commissions as expense when incurred, as the amortization period of the commission asset the Company would have otherwise recognized is less than one year.

[0001633978-20-000011:notes:61]
Contract Balances

[0001633978-20-000011:notes:62]
The Company records accounts receivable when it has an unconditional right to consideration. Contract liabilities are recorded when cash payments are received or due in advance of performance. Contract liabilities consist of advance payments and deferred revenue, where the Company has unsatisfied performance obligations. Contract liabilities are classified as deferred revenue and customer deposits, and are included in other current liabilities within our consolidated balance sheet. Payment terms vary by customer. The time between invoicing and when payment is due is not significant.

[0001633978-20-000011:notes:63]
The following table reflects the changes in contract balances as of June 27, 2020 (in millions, except percentages):

[0001633978-20-000011:notes:64]
| Contract balances | Balance sheet location | June 27, 2020 |  | June 29, 2019 |  | Change |  | Percentage Change |
| Accounts receivable, net | Accounts receivable, net | $233.5 |  | $238.0 |  | $(4.5) |  | (1.9)% |
| Deferred revenue and customer deposits | Other current liabilities | $1.9 |  | $2.9 |  | $(1.0) |  | (34.5)% |

[0001633978-20-000011:notes:65]
Disaggregation of Revenue

[0001633978-20-000011:notes:66]
We disaggregate revenue by geography and by product. Refer to “Note 20. Operating Segments and Geographic Information” for a presentation of disaggregated revenue. We do not present other levels of disaggregation, such as by type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, as this information is not used by our Chief Operating Decision Maker to manage the business.

[0001633978-20-000011:notes:67]
Income Taxes

[0001633978-20-000011:notes:68]
In accordance with the authoritative guidance on accounting for income taxes, we recognize income taxes using an asset and liability approach. This approach requires the recognition of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in our consolidated financial statements or tax returns. The measurement of current and deferred taxes is based on provisions of the enacted tax law, and the effects of future changes in tax laws or rates are not anticipated.

[0001633978-20-000011:notes:69]
The authoritative guidance provides for recognition of deferred tax assets if the realization of such deferred tax assets is more likely than not to occur based on an evaluation of both positive and negative evidence and the relative weight of the evidence. We consider future growth, forecasted earnings, future taxable income, the mix of earnings in the jurisdictions in which we operate, historical earnings, taxable income in prior years, if carryback is permitted under the law, and prudent and feasible tax planning strategies in determining the need for a valuation allowance. In the event we were to determine that we would not be able to realize all or part of our net deferred tax assets in the future, an adjustment to the deferred tax assets valuation allowance would be charged to earnings in the period in which we make such a determination, or goodwill would be adjusted at our final determination of the valuation allowance related to an acquisition within the measurement period. If we later determine that it is more likely than not that the net deferred tax assets would be realized, we would reverse the applicable portion of the previously provided valuation allowance as an adjustment to earnings at such time.

[0001633978-20-000011:notes:70]
We are subject to income tax audits by the respective tax authorities of the jurisdictions in which we operate. The determination of our income tax liabilities in each of these jurisdictions requires the interpretation and application of complex, and sometimes uncertain, tax laws and regulations. The authoritative guidance on accounting for income taxes prescribes both recognition and measurement criteria that must be met for the benefit of a tax position to be recognized in the financial statements. If a tax position taken, or expected to be taken, in a tax return does not meet such recognition or measurement criteria, an unrecognized tax benefit liability is recorded.  If we ultimately determine that an unrecognized tax benefit liability is no longer necessary, we reverse the liability and recognize a tax benefit in the period in which it is determined that the unrecognized tax benefit liability is no longer necessary.

[0001633978-20-000011:notes:71]
The recognition and measurement of current taxes payable or refundable and deferred tax assets and liabilities requires that we make certain estimates and judgments. Changes to these estimates or a change in judgment may have a material impact on our tax provision in a future period.

[0001633978-20-000011:notes:72]
Property, Plant and Equipment

[0001633978-20-000011:notes:73]
Property, plant and equipment are stated at cost. Depreciation is computed by the straight-line method generally over the following estimated useful lives of the assets: 10 to 40 years for building and improvements, 3 to 5 years for machinery and equipment, and 2 to 5 years for furniture, fixtures, software and office equipment. Leasehold improvements are amortized using the straight-line method over the shorter of the estimated useful lives of the assets or the term of the lease.

[0001633978-20-000011:notes:74]
Goodwill

[0001633978-20-000011:notes:75]
Goodwill represents the excess of the purchase price of an acquired business over the fair value of the identifiable assets acquired and liabilities assumed. We test for impairment of goodwill on an annual basis in the fourth quarter and at any other time when events occur or circumstances indicate that the carrying amount of goodwill may not be recoverable.

[0001633978-20-000011:notes:76]
We have the option to first assess qualitative factors to determine whether it is necessary to perform the quantitative goodwill impairment test. The qualitative factors we assess include long-term prospects of our performance, share price trends and market capitalization, and Company specific events. Unanticipated events and circumstances may occur that affect the accuracy of our assumptions, estimates and judgments. For example, if the price of our common stock were to significantly decrease combined with other adverse changes in market conditions, thus indicating that the underlying fair value of our reporting units may have decreased, we might be required to reassess the value of our goodwill in the period such circumstances were identified.

[0001633978-20-000011:notes:77]
If we determine that as a result of the qualitative assessment that it is more likely than not (i.e., greater than 50% likelihood) that the fair value of a reporting unit is less than its carrying amount, then the quantitative test is required. Otherwise, no further testing is required. The quantitative goodwill impairment test requires us to estimate the fair value of our reporting units. If the carrying value of a reporting unit exceeds its fair value, the goodwill of that reporting unit is potentially impaired and we record an impairment loss equal to the excess of the carrying value of the reporting unit over its fair value, not to exceed the carrying amount of goodwill. The fair value of each of our goodwill reporting units is generally estimated using a combination of public company multiples and discounted cash flow methodologies.

[0001633978-20-000011:notes:78]
Based on the impairment analysis performed in the fourth quarter of each year presented, the fair value of each of our reporting units substantially exceeded the carrying value; as such, our annual qualitative assessment did not indicate that a more detailed quantitative analysis was necessary.

[0001633978-20-000011:notes:79]
Intangible Assets

[0001633978-20-000011:notes:80]
Intangible assets consist primarily of intangible assets purchased through acquisitions. Purchased intangible assets include acquired developed technologies (developed and core technology), customer relationships, in-process research and development, and order backlog. Intangible assets, with the exception of customer relationships and order backlog, are amortized using the straight-line method over the estimated economic useful lives of the assets, which is the period during which expected cash flows support the fair value of such intangible assets. Customer relationships and order backlog are amortized using an accelerated method of amortization over the expected customer lives, which more accurately reflects the pattern of realization of economic benefits expected to be obtained.

[0001633978-20-000011:notes:81]
Long-lived Asset Valuation

[0001633978-20-000011:notes:82]
We test long-lived assets for recoverability, at the asset group level, when events or changes in circumstances indicate that their carrying amount may not be recoverable. Circumstances which could trigger a review include, but are not limited to: significant decreases in the market price of the asset, significant adverse changes in the business climate or legal factors, accumulation of costs significantly in excess of the amount originally expected for the acquisition or construction of the asset, current period cash flow or operating losses combined with a history of losses or a forecast of continuing losses associated with the use of the asset, or current expectation that the asset will more likely than not be sold or disposed significantly before the end of its estimated useful life.

[0001633978-20-000011:notes:83]
Recoverability is assessed based on the difference between the carrying amount of the asset and the sum of the undiscounted cash flows expected to result from the use and the eventual disposal of the asset. An impairment loss is recognized when the carrying amount is not recoverable and exceeds fair value.

[0001633978-20-000011:notes:84]
Pension Benefits

[0001633978-20-000011:notes:85]
The funded status of our retirement-related benefit plan is measured as the difference between the fair value of plan assets and the benefit obligation at fiscal year end, the measurement date. The funded status of an underfunded benefit plan, of which the fair value of plan assets is less than the benefit obligation, is recognized as a non-current net pension liability in the consolidated balance sheets unless the fair value of plan assets is not sufficient to cover the expected payments to be made over the next year (or operating cycle, if longer) from the measurement date. For defined benefit pension plans, the benefit obligation is the projected benefit obligation (“PBO”) which represents the actuarial present value of benefits expected to be paid upon retirement.

[0001633978-20-000011:notes:86]
Net periodic pension cost (income) (“NPPC”) is recorded in the consolidated statements of operations and includes service cost, interest cost, expected return on plan assets, amortization of prior service cost and (gains) losses previously recognized as a component of accumulated other comprehensive income. Service cost represents the actuarial present value of participant benefits attributed to services rendered by employees in the current year. Interest cost represents the time value of money cost associated with the passage of time. (Gains) losses arise as a result of differences between actual experience and assumptions or as a result of changes in actuarial assumptions. Prior service cost (credit) represents the cost of benefit improvements attributable to prior service granted in plan amendments. (Gains) losses and prior service cost (credit) that arise during the current year are first

[0001633978-20-000011:notes:87]
recognized as a component of accumulated other comprehensive income in the consolidated balances sheets, net of tax. Prior service cost is amortized as a component of NPPC over the average remaining service period of active plan participants starting at the date the plan amendment is adopted. Deferred actuarial (gains) losses are subsequently recognized as a component of NPPC if they exceed the greater of 10% of PBO or the fair value of plan assets, with the excess amortized over the average remaining service period of active plan participants.

[0001633978-20-000011:notes:88]
The measurement of the benefit obligation and NPPC is based on our estimates and actuarial valuations, provided by third-party actuaries, which are approved by management. These valuations reflect the terms of the plans and use participant-specific information such as compensation, age and years of service, as well as certain assumptions, including estimates of discount rates, expected return on plan assets, rate of compensation increases, and mortality rates. We evaluate these assumptions annually at a minimum. In estimating the expected return on plan assets, we consider historical returns on plan assets, adjusted for forward-looking considerations, inflation assumptions and the impact of the active management of the plan’s invested assets.

[0001633978-20-000011:notes:89]
Concentration of Credit and Other Risks

[0001633978-20-000011:notes:90]
Financial instruments that potentially subject our business to concentration of credit risk consist primarily of cash, short-term investments, and trade receivables. We perform credit evaluations of our customers’ financial condition and generally do not require collateral from our customers. These evaluations require significant judgment and are based on a variety of factors including, but not limited to, current economic trends, payment history, bad debt write-off experience, and financial review of the customer.

[0001633978-20-000011:notes:91]
Although the Company deposits its cash with financial institutions that management believes are of high credit quality, its deposits, at times, may exceed federally insured limits. The Company’s investment portfolio consists of investment grade securities diversified amongst security types, industries, and issuers. The Company’s investment policy limits the amount of credit exposure in the investment portfolio by imposing credit rating minimums and limiting purchases of a single issuer, security type, geography and industry, except for Treasury securities. The Company believes no significant concentration risk exists with respect to these investments.

[0001633978-20-000011:notes:92]
We maintain an allowance for doubtful accounts for estimated losses resulting from the inability of our customers to make required payments. When we become aware that a specific customer is unable to meet their financial obligations, we record a specific allowance to reflect the level of credit risk in the customer’s outstanding receivable balance. In addition, we record additional allowances based on certain percentages of aged receivable balances. These percentages take into account a variety of factors including, but not limited to, current economic trends, payment history and bad debt write-off experience. We classify bad debt expenses as selling, general and administrative (“SG&A”) expense.

[0001633978-20-000011:notes:93]
During fiscal 2020, 2019, and 2018, a few customers generated more than 10% of total net revenue. Refer to “Note 20. Operating Segments and Geographic Information” in the Notes to Consolidated Financial Statements.

[0001633978-20-000011:notes:94]
Our accounts receivable was concentrated with one customer as of June 27, 2020, who represented 14% of gross accounts receivable, compared with three customers as of June 29, 2019, who represented 17%, 17% and 10% of gross accounts receivable, respectively.

[0001633978-20-000011:notes:95]
We rely on a limited number of suppliers for a number of key components contained in our products. We also rely on a limited number of significant independent contract manufacturers for the production of certain key components and subassemblies contained in our products.

[0001633978-20-000011:notes:96]
We generally use a rolling twelve months forecast based on anticipated product orders, customer forecasts, product order history and backlog to determine our materials requirements. Lead times for the parts and components that we order vary significantly and depend on factors such as the specific supplier, contract terms and demand for a component at a given time. If the forecast does not meet or if it exceeds actual demand, we may have excess or shortfalls of some materials and components, as well as excess inventory purchase commitments. We could experience reduced or delayed product shipments or incur additional inventory write-downs and cancellation charges or penalties, which would increase costs and could have a material adverse impact on our results of operations.

[0001633978-20-000011:notes:97]
Foreign Currency Translation

[0001633978-20-000011:notes:98]
Concurrent with the acquisition of Oclaro on December 10, 2018, we established the functional currency for our worldwide operations as the U.S. dollar. The change in our functional currency is a result of significant changes in economic facts and circumstances, primarily the acquisition of Oclaro, a U.S. dollar-denominated functional currency company. The combined business, which requires the integration of our supply chain, manufacturing operations and sales organization, will predominantly use the U.S. dollar, including when negotiating customer and major supplier contracts.

[0001633978-20-000011:notes:99]
Translation adjustments reported prior to December 10, 2018, remain as a component of accumulated other comprehensive income in our consolidated balance sheet. The translated values for any non-monetary assets and liabilities as of December 10, 2018 become the new accounting basis for those assets. Accordingly, monetary assets and liabilities denominated in foreign currencies have been remeasured into U.S. dollars using the exchange rates in effect at the balance sheet date. Foreign currency re-measurement gains (losses) are included in interest and other income (expense), net.

[0001633978-20-000011:notes:100]
Stock-based Compensation

[0001633978-20-000011:notes:101]
Compensation expense related to stock-based transactions is measured and recognized in the financial statements based on fair value at the grant date.

[0001633978-20-000011:notes:102]
Restricted stock units (“RSUs”) are grants of shares of our common stock, the vesting of which is based on the requisite service requirement. Generally, our RSUs are subject to forfeiture and expected to vest over one to four years. For new-hire grants, RSUs generally vest ratably on an annual basis over four years. For annual refresh grants, RSUs generally vest ratably on an annual, or combination of annual and quarterly, basis over three years.

[0001633978-20-000011:notes:103]
Restricted stock awards (“RSAs”) are grants of shares of our common stock that are subject to various restrictions, including restrictions on transferability and forfeiture provisions. RSAs are expected to vest over one to four years, and the shares acquired may not be transferred by the holder until the vesting conditions (if any) are satisfied.

[0001633978-20-000011:notes:104]
Performance stock units (“PSUs”) are grants of shares of our common stock that vest upon the achievement of certain performance and service conditions. We account for the fair value of PSUs using the closing market price of our common stock on the date of grant. We begin recognizing compensation expense when we conclude that it is probable that the performance conditions will be achieved. We reassess the probability of vesting at each reporting period and adjust our compensation cost based on this probability assessment. Our PSUs are subject to risk of forfeiture until performance and service conditions are satisfied and generally vest over three years.

[0001633978-20-000011:notes:105]
We estimate the fair value of the rights to acquire stock under our 2015 Employee Stock Purchase Plan (the “2015 Purchase Plan”) using the Black-Scholes option pricing formula. Our 2015 Purchase Plan provides for consecutive six-month offering periods. We recognize such compensation expense on a straight-line basis over the requisite service period. We calculate the volatility factor based on our historical stock prices.

[0001633978-20-000011:notes:106]
Restructuring Accrual

[0001633978-20-000011:notes:107]
Costs associated with restructuring activities are recognized when they are obligated. However, in the case of leases, the expense is estimated and accrued when the property is vacated. Given the significance of, and the timing of the execution of such activities, this process is complex and involves periodic reassessments of estimates made from the time the property was vacated, including evaluating real estate market conditions for expected vacancy periods and sub-lease income. We recognize a liability for post-employment benefits for workforce reductions related to restructuring activities when payment is probable and the amount is reasonably estimable. We continually evaluate the adequacy of the remaining liabilities under our restructuring initiatives. Although we believe that these estimates accurately reflect the costs of our restructuring plans, actual results may differ, thereby requiring us to record additional provisions or reverse a portion of such provisions. Refer to “Note 14. Restructuring and Related Charges” in the Notes to Consolidated Financial Statements.

[0001633978-20-000011:notes:108]
Business Combinations

[0001633978-20-000011:notes:109]
In accordance with the guidance for business combinations, we determine whether a transaction or other event is a business combination, which requires that the assets acquired and liabilities assumed constitute a business. Each business combination is then accounted for by applying the acquisition method. If the assets acquired are not a business, we account for the transaction or other event as an asset acquisition. Under both methods, we recognize the identifiable assets acquired, the liabilities assumed, and any noncontrolling interest in the acquired entity. We capitalize acquisition-related costs and fees associated with asset acquisitions and immediately expense acquisition-related costs and fees associated with business combinations.

[0001633978-20-000011:notes:110]
We allocate the fair value of purchase consideration to the tangible assets acquired, liabilities assumed and intangible assets acquired based on their estimated fair values. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. When determining the fair values of assets acquired and liabilities assumed, we make significant estimates and assumptions, especially with respect to intangible assets. Critical estimates in valuing certain intangible assets include, but are not limited to, future expected cash flows from customer relationships and acquired developed technology and discount rates. Our estimates of fair value are based upon assumptions believed to be reasonable, but which are inherently uncertain and unpredictable and, as a result, actual results may differ materially from estimates. Other estimates associated

[0001633978-20-000011:notes:111]
with the accounting for acquisitions may change as additional information becomes available regarding the assets acquired and liabilities assumed. Any change in facts and circumstances that existed as of the acquisition date and impacts our preliminary estimates is recorded to goodwill if identified within the measurement period. Subsequent to the measurement period or our final determination of fair value of assets and liabilities whichever is earlier the adjustments will affect our earnings.

[0001633978-20-000011:notes:112]
In addition, we estimate the economic lives of certain acquired assets and these lives are used to calculate depreciation and amortization expense. If our estimates of the economic lives change, depreciation or amortization expenses could be accelerated or slowed.

[0001633978-20-000011:notes:113]
Research and Development (“R&D”) Expense

[0001633978-20-000011:notes:114]
Costs related to R&D, which primarily consists of labor and benefits, supplies, facilities, consulting and outside service fees, are charged to expense as incurred.

[0001633978-20-000011:notes:115]
Loss Contingencies

[0001633978-20-000011:notes:116]
We are subject to the possibility of various loss contingencies arising in the ordinary course of business. We consider the likelihood of loss or impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss in determining loss contingencies. An estimated loss is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate current information available to determine whether such accruals should be adjusted and whether new accruals are required.

[0001633978-20-000011:notes:117]
Asset Retirement Obligations (“ARO”)

[0001633978-20-000011:notes:118]
Our ARO are legal obligations associated with the retirement of long-lived assets pertaining to leasehold improvements. These liabilities are initially recorded at fair value and the related asset retirement costs are capitalized by increasing the carrying amount of the related assets by the same amount as the liability. Asset retirement costs are subsequently depreciated over the useful lives of the related assets. Subsequent to initial recognition, we record period-to-period changes in the ARO liability resulting from the passage of time and revisions to either the timing or the amount of the original estimate of undiscounted cash flows. We derecognize ARO liabilities when the related obligations are settled.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001633978-20-000011:notes:119]
We determine fair value based on the fair value hierarchy, which requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs when measuring fair value. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. The fair value assumes that the transaction to sell the asset or transfer the liability occurs in the principal or most advantageous market for the asset or liability and establishes that the fair value of an asset or liability shall be determined based on the assumptions that market participants would use in pricing the asset or liability. The classification of a financial asset or liability within the hierarchy is based upon the lowest level input that is significant to the fair value measurement. The fair value hierarchy prioritizes the inputs into three levels that may be used to measure fair value:

[0001633978-20-000011:notes:120]
| Level 1: | Inputs are unadjusted quoted prices in active markets for identical assets or liabilities. |
| Level 2: | Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the asset or liability, either directly or indirectly through market corroboration, for substantially the full term of the financial instrument. |
| Level 3: | Inputs are unobservable inputs based on our assumptions. |

[0001633978-20-000011:notes:121]
The fair value of our Level 1 financial instruments, such as money market funds, which are traded in active markets, is based on quoted market prices for identical instruments. The fair value of our Level 2 fixed income securities is obtained from an independent pricing service, which may use quoted market prices for identical or comparable instruments or model driven valuations using observable market data or inputs corroborated by observable market data. Our marketable securities are held by custodians who obtain investment prices from a third-party pricing provider that incorporates standard inputs in various asset price models. Our procedures include controls to ensure that appropriate fair values are recorded, including comparing the fair values obtained from our pricing service against fair values obtained from another independent source.

[0001633978-20-000011:notes:122]
Our pension assets consist of multiple institutional funds (“pension funds”) of which the fair values are based on the quoted prices of the underlying funds. Pension funds are mainly classified as Level 2 assets since such funds are not directly traded in active markets. Refer to “Note 18. Employee Retirement Plans.”

[0001633978-20-000011:notes:123]
Assets Measured at Fair Value on a Non-Recurring Basis

[0001633978-20-000011:notes:124]
We periodically review our intangible and other long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. Determination of recoverability is based on the lowest level of identifiable estimated undiscounted cash flows resulting from use of the asset and its eventual disposition. If not recoverable, an impairment loss would be calculated based on the excess of the carrying amount over the fair value.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001633978-20-000011:notes:125]
Accounting Pronouncements Recently Adopted

[0001633978-20-000011:notes:126]
In February 2016, FASB issued ASU 2016-02, Leases (Topic 842) and subsequent amendments to the initial guidance: ASU 2017-13, ASU 2018-10, ASU 2018-11, ASU 2018-20 and ASU 2019-01 (collectively, Topic 842). Effective June 30, 2019, we adopted Topic 842, using the modified retrospective transition approach. We applied the new guidance to all leases existing as of the date of adoption. Our reported results beginning with the first quarter of fiscal 2020 reflect the application of Topic 842, while prior period amounts have not been adjusted and continue to be reported in accordance with our historical accounting under Topic 840.

[0001633978-20-000011:notes:127]
We elected the practical expedient package permitted under the transition approach. As such, we did not reassess whether any expired or existing contracts are or contain leases, we did not reassess our historical lease classification, and we did not reassess our initial direct costs for any leases that existed prior to June 30, 2019. We have also elected to combine lease and non-lease components at a portfolio level for our operating leases of buildings and not to report leases with an initial term of 12 months or less on our balance sheet.

[0001633978-20-000011:notes:128]
As of the date of adoption, we recognized operating lease assets of $91.5 million, with corresponding operating lease liabilities of $81.5 million on the consolidated balance sheets. The difference between the operating lease right-of-use assets and operating lease liabilities primarily represents the existing asset recognized in relation to the favorable terms of an operating lease acquired through a business combination offset by our deferred rent and ASC 420 “cease-use” balances.

[0001633978-20-000011:notes:129]
All existing leases that were classified as capital leases under Topic 840 are classified as finance leases under the new guidance. As of adoption, we recognized finance lease assets of $12.4 million in property, plant and equipment, net, with corresponding finance lease liabilities of $12.4 million on the consolidated balance sheets. For further information regarding the impact of Topic 842 adoption, see “Note 1. Description of Business and Summary of Significant Accounting Policies” and “Note 9. Leases”.

[0001633978-20-000011:notes:130]
In February 2018, FASB issued ASU 2018-02, Income Statement-Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which allows companies to reclassify stranded tax effects resulting from the U.S. Tax Cuts and Jobs Act of 2017 (the “Tax Act”), from accumulated other comprehensive income to retained earnings. The guidance also requires certain new disclosures regardless of the election. The amendments in ASU 2018-02 are effective for all entities for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years. We adopted ASU 2018-02 in the first quarter of fiscal 2020 with no impact to our consolidated financial statements.

[0001633978-20-000011:notes:131]
In January 2017, FASB issued ASU 2017-04, Intangibles - Goodwill and Other (Topic 350): Simplifying the Accounting for Goodwill Impairment. ASU 2017-04 removes the requirement to perform a hypothetical purchase price allocation to measure goodwill impairment. A goodwill impairment charge will be the amount by which a reporting unit's carrying value exceeds its fair value, not to exceed the carrying amount of goodwill. The amendments contained in ASU 2017-04 are effective for interim and annual periods beginning after December 15, 2019, with early adoption permitted, which should be applied prospectively. We early adopted ASU 2017-04 in our first quarter of fiscal 2020. The implementation of ASU 2017-04 did not have an impact on our consolidated financial statements.

[0001633978-20-000011:notes:132]
Accounting Pronouncements Not Yet Effective

[0001633978-20-000011:notes:133]
In August 2020, FASB issued ASU 2020-06, Debt—Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging—Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity, which simplifies the accounting for convertible instruments by removing the separation models for (1) convertible debt with a cash conversion feature and (2) convertible instruments with a beneficial conversion feature. As a result, a convertible debt instrument will be accounted for as a single liability measured at its amortized cost. These changes will reduce reported interest expense and increase reported net income for entities that have issued a convertible instrument that was bifurcated according to previously existing rules. Also, ASU 2020-06 requires the application of the if-converted method for calculating diluted earnings per share and the treasury stock method will be no longer available. The new guidance is effective for fiscal years beginning after December 15, 2021, with early adoption permitted no earlier than fiscal years beginning after December 15, 2020. ASU 2020-06 is effective for us in our first quarter of fiscal 2023. We are currently evaluating the impact of ASU 2020-06 on our consolidated financial statements.

[0001633978-20-000011:notes:134]
In December 2019, FASB issued ASU 2019-12, Simplifying the Accounting for Income Taxes (Topic 740), which is intended to simplify various aspects related to accounting for income taxes by removing certain exceptions to the general principles in Topic 740 and which also clarifies and amends existing guidance to improve consistent application. ASU 2019-12 is effective for us at the beginning of fiscal 2022, including interim periods within that reporting period, although early adoption is permitted. We are currently evaluating the impact of ASU 2019-12 on our consolidated financial statements.

[0001633978-20-000011:notes:135]
In August 2018, FASB issued ASU 2018-14, Compensation-Retirement Benefits-Defined Benefit Plans-General (Topic 715-20): Disclosure Framework-Changes to the Disclosure Requirements for Defined Benefit Plans. ASU 2018-14 modifies the disclosure requirements for defined benefit pension plans and other post-retirement benefit plans. The new guidance is effective for fiscal years ending after December 15, 2020, with early adoption permitted. ASU 2018-14 should be applied retrospectively to all periods presented and is effective for us in our first quarter of fiscal 2022. We are currently evaluating the impact of ASU 2018-14 on our consolidated financial statements.

[0001633978-20-000011:notes:136]
In August 2018, FASB issued ASU 2018-13, Fair Value Measurement (Topic 820): Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement. ASU 2018-13 modifies the disclosure requirements for fair value measurements. The new guidance is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, with early adoption permitted. ASU 2018-13 requires that certain of the amendments be applied prospectively, while other amendments should be applied retrospectively to all periods presented. ASU 2018-13 is effective for us in our first quarter of fiscal 2021. The adoption of this standard is not expected to have a significant impact on our consolidated financial statements.

[0001633978-20-000011:notes:137]
In August 2018, FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Customer's Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract. This standard requires capitalization of the implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software. Further, the standard also requires the Company to expense the capitalized implementation costs of a hosting arrangement over the term of the hosting arrangement. This standard is effective for us in our first quarter of fiscal 2021. Early adoption is permitted. The adoption of this standard is not expected to have a significant impact on our consolidated financial statements.

[0001633978-20-000011:notes:138]
In June 2016, FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments and a subsequent amendment, ASU 2018-19 (collectively, Topic 326). Topic 326 requires measurement 
and recognition of expected credit losses for financial assets held. Topic 326 is effective for annual periods beginning after December 15, 2019, including interim periods within those periods, with early adoption permitted. ASU 2016-13 is effective for us in our first quarter of fiscal 2021. The adoption of Topic 326 will not have a material impact on our consolidated financial statements.


## us-gaap:EarningsPerShareTextBlock

[0001633978-20-000011:notes:139]
Note 3. Earnings Per Share

[0001633978-20-000011:notes:140]
The following table sets forth the computation of basic and diluted net income (loss) attributable to common stockholders per share (in millions, except per share data):

[0001633978-20-000011:notes:141]
|  | Years Ended |
|  | June 27, 2020 |  | June 29, 2019 |  | June 30, 2018 |
| Basic Earnings per Common Share |  |  |  |  |  |  |  |
| Net income (loss) | $ | 135.5 |  |  | $ | (36.4 | ) |  | $ | 248.1 |  |
| Less: Cumulative dividends on Series A Preferred Stock | — |  |  | (0.3 | ) |  | (0.9 | ) |
| Less: Earnings allocated to Series A Preferred Stock | — |  |  | (1.2 | ) |  | (5.7 | ) |
| Net income (loss) attributable to common stockholders - Basic | $ | 135.5 |  |  | $ | (37.9 | ) |  | $ | 241.5 |  |
| Weighted average common shares outstanding including Series A Preferred Stock | 75.9 |  |  | 70.7 |  |  | 63.8 |  |
| Less: Weighted average Series A Preferred Stock | — |  |  | — |  |  | (1.5 | ) |
| Basic weighted average common shares outstanding | 75.9 |  |  | 70.7 |  |  | 62.3 |  |
| Net income (loss) per share attributable to common stockholders - Basic | $ | 1.79 |  |  | $ | (0.54 | ) |  | $ | 3.88 |  |
| Diluted Earnings per Common Share |  |  |  |  |  |
| Net income (loss) attributable to common stockholders - Diluted | $ | 135.5 |  |  | $ | (37.9 | ) |  | $ | 241.5 |  |
| Weighted average common shares outstanding for basic earnings per common share | 75.9 |  |  | 70.7 |  |  | 62.3 |  |
| Effect of dilutive securities from 2015 Equity Incentive Plan | 0.8 |  |  | — |  |  | 1.0 |  |
| Shares issuable assuming conversion of the 2024 Notes | 0.9 |  |  | — |  |  | — |  |
| Diluted weighted average common shares outstanding | 77.6 |  |  | 70.7 |  |  | 63.3 |  |
| Net income (loss) per share attributable to common stockholders - Diluted | $ | 1.75 |  |  | $ | (0.54 | ) |  | $ | 3.82 |  |

[0001633978-20-000011:notes:142]
For the year ended June 29, 2019, our diluted earnings per share attributable to common stockholders is the same as basic EPS as we are in net loss position. For the year ended June 30, 2018, our diluted earnings per share attributable to common stockholders is calculated using the “treasury stock” method because it is more dilutive than the “if-converted” method.

[0001633978-20-000011:notes:143]
Our Series A Preferred Stock was considered a participating security, meaning that it had the right to participate in undistributed earnings with our common stock. On November 2, 2018, the remaining 35,805 shares of our Series A Preferred Stock were converted into 1.5 million shares of our common stock. Refer to “Note 11. Non-Controlling Interest Redeemable Convertible Preferred Stock and Derivative Liability” for further discussion. Prior to conversion, the holders of our Series A Preferred Stock were entitled to share in dividends, on an as-converted basis, if the holders of our common stock were to receive dividends.  Through the date of conversion, we used the two-class method to compute earnings per share. The two-class method is an earnings allocation formula that determines earnings per share for each class of common stock and participating security according to dividends declared (or accumulated) and participation rights in undistributed earnings. In determining the amount of net earnings to allocate to common stockholders, earnings are allocated to both common and participating securities based on their respective weighted-average shares outstanding during the period. Diluted earnings per common share is calculated similar to basic earnings per common share except

[0001633978-20-000011:notes:144]
that it gives effect to all potentially dilutive common stock equivalents outstanding for the period, using the treasury stock method. Diluted earnings per common share is computed using the more dilutive of the treasury stock method or the if-converted method.

[0001633978-20-000011:notes:145]
Potentially dilutive common shares result from the assumed exercise of outstanding stock options, assumed vesting of outstanding equity awards, assumed issuance of stock under the employee stock purchase plan, and assumed conversion of our outstanding convertible notes, all using the treasury stock method.

[0001633978-20-000011:notes:146]
We have the ability and intent to settle the face value of our convertible notes in cash. Therefore, we use the treasury stock method for calculating the dilutive impact of the convertible notes. The 2026 Notes will have no impact on diluted earnings per share until the average price of our common stock exceeds the conversion price of $99.29. The potentially dilutive shares resulting from the 2024 Notes were included in the calculation of diluted income per share for the year ended June 27, 2020, since the average price of our common stock exceeded the conversion price of $60.62.  Refer to “Note 12. Debt” for further discussion.

[0001633978-20-000011:notes:147]
Anti-dilutive potential shares from the 2015 Equity Incentive Plan are excluded from the calculation of diluted earnings per share if their exercise price exceeded the average market price during the period or the share-based awards were determined to be anti-dilutive based on applying the treasury stock method. Anti-dilutive shares excluded from the calculation of diluted earnings per share were not material for the years presented. However, during the year ended June 29, 2019, 0.6 million of potentially dilutive securities were excluded from the computation of diluted earnings per share due to net loss generated for the period, since the effect would have been anti-dilutive.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0001633978-20-000011:notes:148]
Note 4. Business Combinations

[0001633978-20-000011:notes:149]
On December 10, 2018, we acquired all of the outstanding common stock of Oclaro, a provider of optical components and modules for the long-haul, metro and data center markets. Oclaro’s products provide differentiated solutions for optical networks and high-speed interconnects driving the next wave of streaming video, cloud computing, application virtualization and other bandwidth-intensive and high-speed applications. This acquisition strengthened our product portfolio, including gaining Oclaro’s indium phosphide laser and photonic integrated circuit and coherent component and module capabilities; broadens our revenue mix; and positions us strongly to meet the future needs of our customers.

[0001633978-20-000011:notes:150]
Pursuant to the merger agreement, Prota Merger Sub, Inc., a Delaware corporation and a wholly owned subsidiary of Lumentum (“Merger Sub”), merged with and into Oclaro (the “Merger”), with Oclaro surviving the Merger. Each outstanding share of Oclaro common stock, par value $0.01 per share, was automatically converted into the right to receive the following consideration (collectively, the “Merger Consideration”), without interest:

[0001633978-20-000011:notes:151]
•$5.60 in cash (the “Cash Consideration”) and;

[0001633978-20-000011:notes:152]
| • | 0.0636 of a share of Lumentum common stock, par value $0.001 per share (the “Exchange Ratio”). |

[0001633978-20-000011:notes:153]
The total fair value of consideration given in connection with the acquisition of Oclaro consisted of the following:

[0001633978-20-000011:notes:154]
|  | Shares | Per Share | Total Consideration(in millions) |
| Cash paid for outstanding Oclaro common stock |  |  | $ | 964.8 |  |
| Lumentum common shares issued to Oclaro stockholders | 10,941,436 |  | $ | 41.80 |  | 457.4 |  |
| Replacement equity awards for Oclaro equity awards |  |  | 2.7 |  |
| Total consideration |  |  | $ | 1,424.9 |  |

[0001633978-20-000011:notes:155]
The total transaction consideration was $1.4 billion, which was funded by the issuance of Lumentum common stock, new debt, and cash balances of the combined company. We also recorded $18.3 million in acquisition-related costs in the year ended June 29, 2019, representing professional and other direct acquisition costs. These costs were recorded within selling, general and administrative operating expense and within interest and other income (expense), net in our consolidated statements of operations. The Company also incurred $9.3 million of debt financing costs which has been recorded as a contra liability. “Refer to Note 12. Debt.”

[0001633978-20-000011:notes:156]
The final purchase price allocation is as follows (in millions):

[0001633978-20-000011:notes:157]
|  | FinalAs AdjustedJune 29, 2019 |
| Cash and cash equivalents | $ | 345.0 |  |
| Accounts receivable, net | 68.0 |  |
| Inventories | 155.0 |  |
| Prepayments and other current assets | 33.7 |  |
| Property, plant and equipment, net | 134.7 |  |
| Intangibles | 444.0 |  |
| Deferred income tax asset | 42.6 |  |
| Other non-current assets | 16.6 |  |
| Accounts payable | (57.8 | ) |
| Accrued payroll and related expenses | (11.4 | ) |
| Accrued expenses | (8.3 | ) |
| Other current liabilities | (6.1 | ) |
| Deferred tax liability | (75.8 | ) |
| Other non-current liabilities | (12.9 | ) |
| Goodwill | 357.6 |  |
| Total purchase price | $ | 1,424.9 |  |

[0001633978-20-000011:notes:158]
The measurement period adjustments recorded in fiscal 2019 were primarily related to the sale of several product lines within our Datacom business based in Sagamihara, Japan and the transfer of related employees to Cambridge Industries Group (“CIG”). This business was acquired on December 10, 2018 as part of the acquisition of Oclaro. These assets and liabilities were recorded at fair value less cost to sell and the adjustments to fair value were recorded as measurement period adjustments. The measurement period adjustments recorded in fiscal 2019 also included tax adjustment of $31.5 million upon the completion of additional analysis involving refining the amount of Oclaro’s tax attributes that may be utilizable going forward, deferred tax asset valuation allowances, and the effects of the Tax Act.

[0001633978-20-000011:notes:159]
Goodwill and intangibles have been assigned to the OpComms segment. Goodwill of $357.6 million arising from the acquisition is attributed to the expected synergies, including future cost efficiencies, and other benefits that are expected to be generated by combining Lumentum and Oclaro. Substantially all of the goodwill recognized is not expected to be deductible for tax purposes. See “Note 10. Goodwill and Other Intangible Assets” for more information on goodwill and IPR&D.

[0001633978-20-000011:notes:160]
Following our acquisition of Oclaro, in third quarter of fiscal 2019, we completed the sale of our Datacom transceiver module business based in Sagamihara, Japan and the transfer of related employees to CIG for $25.5 million in net cash. These product lines were initially acquired by us through the acquisition of Oclaro. This business did not meet the criteria for assets held-for-sale under the relevant accounting guidance as of December 10, 2018, the date of our acquisition of Oclaro, in our purchase price allocation. The assets and liabilities transferred to CIG were $33.5 million and $7.0 million, respectively.

[0001633978-20-000011:notes:161]
Following our acquisition of Oclaro, we announced our plan to discontinue development and manufacturing of Lithium Niobate modulators and wind down these operations in our San Donato, Italy site. In fiscal year 2020, we sold our assets associated with certain Lithium Niobate product lines manufactured by our San Donato site for $17 million to Advanced Fiber Resources (Zhuhai) Ltd. (“AFR”). In fiscal 2020, we received the final proceeds of $16.9 million, net of $0.1 million retainer from AFR, and recognized a gain of $13.8 million, which was recorded in our other income (expense), net in the consolidated statements of operations. Refer to “Note 5. Assets Held For Sale and Related Dispositions” for further discussion.

[0001633978-20-000011:notes:162]
Supplemental Pro Forma Information

[0001633978-20-000011:notes:163]
The supplemental pro forma financial information presented below is for illustrative purposes only and is not necessarily indicative of the financial position or results of operations that would have been realized if the acquisition had been completed on the date indicated, does not reflect synergies that might have been achieved, nor is it indicative of future operating results or financial position. The pro forma adjustments are based upon currently available information and certain assumptions we believe are reasonable under the circumstances.

[0001633978-20-000011:notes:164]
The following supplemental pro forma information presents the combined results of operations for the year June 29, 2019, as if Oclaro had been acquired as of the beginning of fiscal year 2018. The supplemental pro forma information includes adjustments to amortization and depreciation for acquired intangible assets and property and equipment, adjustments to share-based compensation expense, the fair value adjustments on the inventories acquired, transaction costs, interest expense and amortization of the term loan debt issuance costs.

[0001633978-20-000011:notes:165]
The unaudited supplemental pro forma financial information for the periods presented is as follows (in millions):

[0001633978-20-000011:notes:166]
|  | Years Ended |
|  | June 29, 2019 |
| Net revenue | $ | 1,779.4 |  |
| Net income | 21.5 |  |


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001633978-20-000011:notes:167]
Note 5. Assets Held For Sale and Related Dispositions

[0001633978-20-000011:notes:168]
We continually evaluate our existing portfolio of businesses to maximize long-term shareholder value. We consider assets and liabilities as held-for-sale when management approves and commits to a plan to actively market assets or a group of assets for sale. Assets held-for-sale are recorded initially at the lower of its carrying value or its estimated fair value, less estimated costs to sell. Upon designation as an asset held-for-sale, we discontinue recording depreciation expense on such asset.

[0001633978-20-000011:notes:169]
Sale of Lithium Niobate modulators

[0001633978-20-000011:notes:170]
Following our acquisition of Oclaro, we announced our plan to discontinue development and manufacturing of Lithium Niobate modulators and wind down these operations in our San Donato, Italy site. In fiscal year 2020, we sold our assets associated with certain Lithium Niobate product lines manufactured by our San Donato site for $17.0 million to Advanced Fiber Resources (Zhuhai) Ltd. (“AFR”). In fiscal 2020, we received the final proceeds of $16.9 million, net of $0.1 million retainer from AFR, and recognized a gain of $13.8 million, which was recorded in our other income (expense), net in the consolidated statements of operations. The assets sold of $6.6 million primarily consisted of property, plant and equipment, net, inventory, and operating lease right-of-use assets, net, offset by liabilities transferred of $3.5 million primarily attributable to operating lease liabilities.

[0001633978-20-000011:notes:171]
In fiscal year 2020, we also sold certain assets that did not have any carrying value, including licenses to manufacture specific Lithium Niobate products and recognized a gain of $0.7 million, which was recorded in our other income (expense), net in the consolidated statements of operations.

[0001633978-20-000011:notes:172]
With the close of these transactions, our telecom transmission product strategy is now focused on Indium Phosphide photonic integrated circuits, as well as components and modules that incorporate these Indium Phosphide photonic integrated circuits.

[0001633978-20-000011:notes:173]
Datacom transceiver modules

[0001633978-20-000011:notes:174]
As of June 29, 2019, we had $4.9 million of long-lived assets related to our plan to discontinue the development of future Datacom transceiver modules. As these assets were not deemed to be useful, we retired them from active use and classified them as held-for-sale on our balance sheet. This is a result of the strategic change we made in the third quarter of fiscal year 2019 when we announced the exit from the Datacom transceiver modules and investments in the new Datacom chips development. In fiscal year 2020, we sold $3.0 million and impaired $1.6 million of these Datacom assets held-for-sale. As of June 27, 2020, $0.3 million is expected to be disposed in the next quarter.

[0001633978-20-000011:notes:175]
Other assets held-for-sale
 As of June 27, 2020, we also have $0.4 million of land, building, and improvements as assets held-for-sale for one of our manufacturing sites in Slovenia.


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001633978-20-000011:notes:176]
Note 6. Cash, Cash Equivalents and Short-term Investments

[0001633978-20-000011:notes:177]
The following table summarizes our cash, cash equivalents and short-term investments by category for the periods presented (in millions):

[0001633978-20-000011:notes:178]
|  | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| June 27, 2020: |  |  |  |  |  |  |  |
| Cash | $ | 114.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 114.2 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | 159.6 |  |  | — |  |  | — |  |  | 159.6 |  |
| U.S. Treasury securities | 24.2 |  |  | — |  |  | — |  |  | 24.2 |  |
| Total cash and cash equivalents | $ | 298.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 298.0 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 12.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 12.9 |  |
| Commercial paper | 179.9 |  |  | 0.3 |  |  | — |  |  | 180.2 |  |
| Corporate debt securities | 435.0 |  |  | 1.7 |  |  | (0.1 | ) |  | 436.6 |  |
| Foreign government bonds | 1.7 |  |  | — |  |  | — |  |  | 1.7 |  |
| U.S. Agency securities | 59.5 |  |  | — |  |  | — |  |  | 59.5 |  |
| U.S. Treasury securities | 563.9 |  |  | 1.0 |  |  | — |  |  | 564.9 |  |
| Total short-term investments | $ | 1,252.9 |  |  | $ | 3.0 |  |  | $ | (0.1 | ) |  | $ | 1,255.8 |  |
| June 29, 2019: |  |  |  |  |  |  |  |
| Cash | $ | 213.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 213.8 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 37.4 |  |  | — |  |  | — |  |  | 37.4 |  |
| Money market funds | 168.1 |  |  | — |  |  | — |  |  | 168.1 |  |
| U.S. Treasury securities | 13.3 |  |  | — |  |  | — |  |  | 13.3 |  |
| Total cash and cash equivalents | $ | 432.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 432.6 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 1.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 1.9 |  |
| Commercial paper | 22.3 |  |  | — |  |  | — |  |  | 22.3 |  |
| Asset-backed securities | 54.9 |  |  | 0.2 |  |  | — |  |  | 55.1 |  |
| Corporate debt securities | 207.6 |  |  | 0.9 |  |  | (0.1 | ) |  | 208.4 |  |
| Municipal bonds | 1.3 |  |  | — |  |  | — |  |  | 1.3 |  |
| Mortgage-backed securities | 6.6 |  |  | — |  |  | — |  |  | 6.6 |  |
| Foreign government bonds | 6.2 |  |  | — |  |  | — |  |  | 6.2 |  |
| U.S. Agency securities | 4.6 |  |  | — |  |  | — |  |  | 4.6 |  |
| U.S. Treasury securities | 29.4 |  |  | 0.1 |  |  | — |  |  | 29.5 |  |
| Total short-term investments | $ | 334.8 |  |  | $ | 1.2 |  |  | $ | (0.1 | ) |  | $ | 335.9 |  |

[0001633978-20-000011:notes:179]
We use the specific-identification method to determine any realized gains or losses from the sale of our short-term investments classified as available-for-sale. During fiscal 2020, 2019 and 2018, we did not realize significant gains or losses on a gross level from the sale of our short-term investments classified as available-for-sale.

[0001633978-20-000011:notes:180]
The components of other income (expense), net are as follows for the years presented (in millions):

[0001633978-20-000011:notes:181]
|  | Years Ended |
|  | June 27, 2020 |  | June 29, 2019 |  | June 30, 2018 |
| Foreign exchange gains (losses), net | $ | (1.4 | ) |  | $ | (0.6 | ) |  | $ | (0.3 | ) |
| Interest income | 15.8 |  |  | 13.9 |  |  | 8.5 |  |
| Other income, net | 17.0 |  |  | 2.5 |  |  | 0.3 |  |
| Total other income (expense), net | $ | 31.4 |  |  | $ | 15.8 |  |  | $ | 8.5 |  |

[0001633978-20-000011:notes:182]
Other income, net in fiscal 2020 includes a gain on the sale of Lithium Niobate modulators business of $13.8 million and a gain on the sale of certain assets to manufacture specific Lithium Niobate products of $0.7 million, which were completed in fiscal 2020. Refer to “Note 5. Assets Held For Sale and Related Dispositions”.

[0001633978-20-000011:notes:183]
The following table summarizes unrealized losses on our cash equivalents and short-term investments by category and length of time the investment has been in a continuous unrealized loss position as of the periods presented (in millions):

[0001633978-20-000011:notes:184]
|  | Less than 12 months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| June 27, 2020: |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 3.1 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 3.1 |  |  | $ | — |  |
| Commercial paper | 51.1 |  |  | — |  |  | — |  |  | — |  |  | 51.1 |  |  | — |  |
| Corporate debt securities | 96.5 |  |  | (0.1 | ) |  | — |  |  | — |  |  | 96.5 |  |  | (0.1 | ) |
| Foreign government bonds | 1.7 |  |  | — |  |  | — |  |  | — |  |  | 1.7 |  |  | — |  |
| U.S. Agency securities | 47.0 |  |  | — |  |  | — |  |  | — |  |  | 47.0 |  |  | — |  |
| U.S. government bonds | 159.8 |  |  | — |  |  | — |  |  | — |  |  | 159.8 |  |  | — |  |
| Total | $ | 359.2 |  |  | $ | (0.1 | ) |  | $ | — |  |  | $ | — |  |  | $ | 359.2 |  |  | $ | (0.1 | ) |
| June 29, 2019: |  |  |  |  |  |  |  |  |  |  |  |
| Asset-backed securities | $ | 4.2 |  |  | $ | — |  |  | $ | 5.9 |  |  | $ | — |  |  | $ | 10.1 |  |  | $ | — |  |
| Corporate debt securities | 9.6 |  |  | — |  |  | 35.9 |  |  | (0.1 | ) |  | 45.5 |  |  | (0.1 | ) |
| Foreign government bonds | — |  |  | — |  |  | 2.1 |  |  | — |  |  | 2.1 |  |  | — |  |
| U.S. government bonds | 6.9 |  |  | — |  |  | — |  |  | — |  |  | 6.9 |  |  | — |  |
| Total | $ | 20.7 |  |  | $ | — |  |  | $ | 43.9 |  |  | $ | (0.1 | ) |  | $ | 64.6 |  |  | $ | (0.1 | ) |

[0001633978-20-000011:notes:185]
The following table classifies our short-term investments by contractual maturities (in millions):

[0001633978-20-000011:notes:186]
|  | June 27, 2020 |  | June 29, 2019 |
|  | Amortized Cost |  | Fair Value |  | Amortized Cost |  | Fair Value |
| Due in 1 year | $ | 1,237.4 |  |  | $ | 1,239.9 |  |  | $ | 178.9 |  |  | $ | 179.1 |  |
| Due in 1 year through 5 years | 15.5 |  |  | 15.9 |  |  | 148.1 |  |  | 149.0 |  |
| Due in 5 years through 10 years | — |  |  | — |  |  | 6.0 |  |  | 6.0 |  |
| Due after 10 years | — |  |  | — |  |  | 1.8 |  |  | 1.8 |  |
|  | $ | 1,252.9 |  |  | $ | 1,255.8 |  |  | $ | 334.8 |  |  | $ | 335.9 |  |

[0001633978-20-000011:notes:187]
All available-for-sale securities have been classified as current, based on management’s intent and ability to use the funds in current operations.


## us-gaap:FairValueDisclosuresTextBlock

[0001633978-20-000011:notes:188]
Note 7. Fair Value Measurements

[0001633978-20-000011:notes:189]
Financial assets and liabilities measured at fair value on a recurring basis are summarized below (in millions):

[0001633978-20-000011:notes:190]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| June 27, 2020 (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 159.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 159.6 |  |
| U.S. Treasury securities | 24.2 |  |  | — |  |  | — |  |  | 24.2 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 12.9 |  |  | — |  |  | 12.9 |  |
| Commercial paper | — |  |  | 180.2 |  |  | — |  |  | 180.2 |  |
| Corporate debt securities | — |  |  | 436.6 |  |  | — |  |  | 436.6 |  |
| Foreign government bonds | — |  |  | 1.7 |  |  | — |  |  | 1.7 |  |
| U.S. Agency securities | — |  |  | 59.5 |  |  | — |  |  | 59.5 |  |
| U.S. Treasury securities | 564.9 |  |  | — |  |  | — |  |  | 564.9 |  |
| Total assets | $ | 748.7 |  |  | $ | 690.9 |  |  | $ | — |  |  | $ | 1,439.6 |  |

[0001633978-20-000011:notes:191]
(1)  Excludes $114.2 million in cash held in our bank accounts as of June 27, 2020.

[0001633978-20-000011:notes:192]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| June 29, 2019: (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | — |  |  | $ | 37.4 |  |  | $ | — |  |  | $ | 37.4 |  |
| Money market funds | 168.1 |  |  | — |  |  | — |  |  | 168.1 |  |
| U.S. Treasury securities | 13.3 |  |  | — |  |  | — |  |  | 13.3 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 1.9 |  |  | — |  |  | 1.9 |  |
| Commercial paper | — |  |  | 22.3 |  |  | — |  |  | 22.3 |  |
| Asset-backed securities | — |  |  | 55.1 |  |  | — |  |  | 55.1 |  |
| Corporate debt securities | — |  |  | 208.4 |  |  | — |  |  | 208.4 |  |
| Municipal bonds | — |  |  | 1.3 |  |  | — |  |  | 1.3 |  |
| Mortgage-backed securities | — |  |  | 6.6 |  |  | — |  |  | 6.6 |  |
| Foreign government bonds | — |  |  | 6.2 |  |  | — |  |  | 6.2 |  |
| U.S. Agency securities | — |  |  | 4.6 |  |  | — |  |  | 4.6 |  |
| U.S. Treasury securities | 29.5 |  |  | — |  |  | — |  |  | 29.5 |  |
| Total assets | $ | 210.9 |  |  | $ | 343.8 |  |  | $ | — |  |  | $ | 554.7 |  |
| Other accrued liabilities: |  |  |  |  |  |  |  |
| Acquisition contingencies | $ | — |  |  | $ | — |  |  | $ | 2.7 |  |  | $ | 2.7 |  |
| Total other accrued liabilities | $ | — |  |  | $ | — |  |  | $ | 2.7 |  |  | $ | 2.7 |  |

[0001633978-20-000011:notes:193]
(1)  Excludes $213.8 million in cash held in our bank accounts as of June 29, 2019.

[0001633978-20-000011:notes:194]
Financial Instruments Not Recorded at Fair Value on a Recurring Basis

[0001633978-20-000011:notes:195]
We report our financial instruments at fair value with the exception of the 2026 Notes and the 2024 Notes (“Note 12. Debt”). The estimated fair value of the notes was determined based on the trading price of the notes as of the last day of trading for the period. We consider the fair value of the notes to be a Level 2 measurement as they are not actively traded in markets.

[0001633978-20-000011:notes:196]
The carrying amounts and estimated fair values of the 2026 Notes and the 2024 Notes are as follows for the periods presented (in millions):

[0001633978-20-000011:notes:197]
|  | June 27, 2020 |  | June 29, 2019 |
|  | Carrying Amount |  | Estimated Fair Value |  | Carrying Amount |  | Estimated Fair Value |
| 2026 Notes | $ | 749.7 |  |  | $ | 1,070.2 |  |  | $ | — |  |  | $ | — |  |
| 2024 Notes | 370.6 |  |  | 620.0 |  |  | 351.9 |  |  | 527.0 |  |
|  | $ | 1,120.3 |  |  | $ | 1,690.2 |  |  | $ | 351.9 |  |  | $ | 527.0 |  |

[0001633978-20-000011:notes:198]
Management utilizes various valuation methods, including an income approach, a market approach and a cost approach, to estimate the fair value of intangibles and other long-lived assets. During the annual impairment testing performed in the fourth quarter of fiscal 2020, we concluded that our intangible and other long-lived assets were not impaired.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001633978-20-000011:notes:199]
Note 8. Balance Sheet Details

[0001633978-20-000011:notes:200]
Accounts receivable allowance

[0001633978-20-000011:notes:201]
As of June 27, 2020 and June 29, 2019, our accounts receivable allowance balance was $1.8 million and $4.5 million respectively. In fiscal 2020, we wrote off $2.8 million of accounts receivable and the associated accounts receivable allowance, which we assumed in Oclaro acquisition.

[0001633978-20-000011:notes:202]
Inventories

[0001633978-20-000011:notes:203]
The components of inventories were as follows (in millions):

[0001633978-20-000011:notes:204]
|  | June 27, 2020 |  | June 29, 2019 |
| Raw materials and purchased parts | $ | 57.9 |  |  | $ | 78.3 |  |
| Work in process | 67.6 |  |  | 72.5 |  |
| Finished goods | 63.4 |  |  | 78.0 |  |
| Inventories (1) | $ | 188.9 |  |  | $ | 228.8 |  |

[0001633978-20-000011:notes:205]
(1) The inventory balance as of June 29, 2019 includes $5.7 million, net of amortization, related to the inventory step-up adjustment from the Oclaro acquisition.  As of June 27, 2020, the inventory step-up adjustment from the Oclaro acquisition was fully amortized.

[0001633978-20-000011:notes:206]
Operating lease right-of-use assets, net

[0001633978-20-000011:notes:207]
Operating lease right-of-use assets, net were as follows (in millions):

[0001633978-20-000011:notes:208]
|  | June 27, 2020 |
| Operating lease right-of-use assets | $ | 90.3 |  |
| Less: accumulated amortization | (11.6 | ) |
| Operating lease right-of-use assets, net | $ | 78.7 |  |

[0001633978-20-000011:notes:209]
Property, plant and equipment, net

[0001633978-20-000011:notes:210]
The components of property, plant and equipment, net were as follows (in millions):

[0001633978-20-000011:notes:211]
|  | June 27, 2020 |  | June 29, 2019 |
| Land | $ | 44.1 |  |  | $ | 44.2 |  |
| Buildings and improvement | 114.8 |  |  | 103.7 |  |
| Machinery and equipment (1) | 487.0 |  |  | 500.5 |  |
| Computer equipment and software | 27.5 |  |  | 25.4 |  |
| Furniture and fixtures | 7.2 |  |  | 4.9 |  |
| Leasehold improvements | 27.8 |  |  | 31.2 |  |
| Finance lease right-of-use assets (1) | 28.1 |  |  | 16.0 |  |
| Construction in progress | 54.7 |  |  | 46.8 |  |
|  | 791.2 |  |  | 772.7 |  |
| Less: Accumulated depreciation (1) | (398.2 | ) |  | (339.4 | ) |
| Property, plant and equipment, net | $ | 393.0 |  |  | $ | 433.3 |  |

[0001633978-20-000011:notes:212]
(1) Included in the table above is our equipment acquired under finance leases. As of  June 27, 2020 and June 29, 2019, the accumulated depreciation of finance lease right-of-use assets was $27.5 million and $11.2 million, respectively. For fiscal 2019 in accordance with Topic 842, we have reclassified $16.0 million of equipment acquired under finance leases from machinery and equipment to finance lease right-of-use assets to conform to current period presentation.

[0001633978-20-000011:notes:213]
During fiscal 2020, 2019 and 2018, we recorded depreciation expense of $113.3 million, $102.9 million, and $74.0 million, respectively.

[0001633978-20-000011:notes:214]
Our construction in progress primarily includes machinery and equipment which we expect to place in service in the next 12 months.

[0001633978-20-000011:notes:215]
Other current liabilities

[0001633978-20-000011:notes:216]
The components of other current liabilities were as follows (in millions):

[0001633978-20-000011:notes:217]
|  | June 27, 2020 |  | June 29, 2019 |
| Warranty accrual (1) | $ | 5.0 |  |  | $ | 7.5 |  |
| Restructuring accrual and related charges (2) | 5.2 |  |  | 14.6 |  |
| Deferred revenue and customer deposits | 1.9 |  |  | 2.9 |  |
| Finance lease liabilities, current (3) | 0.6 |  |  | 0.4 |  |
| Income tax payable (4) | 28.8 |  |  | 8.7 |  |
| Other current liabilities | 2.8 |  |  | 5.1 |  |
| Other current liabilities | $ | 44.3 |  |  | $ | 39.2 |  |

[0001633978-20-000011:notes:218]
(1) Refer to “Note 19. Commitments and Contingencies.”

[0001633978-20-000011:notes:219]
(2) Refer to “Note 14. Restructuring and Related Charges.”

[0001633978-20-000011:notes:220]
(3) For fiscal 2019 in accordance with Topic 842, we have reclassified amounts from capital lease obligations to finance lease liabilities to conform to current period presentation. Refer to “Note 9. Leases.”

[0001633978-20-000011:notes:221]
(4) Refer to “Note 16. Income Taxes.”

[0001633978-20-000011:notes:222]
Other non-current liabilities

[0001633978-20-000011:notes:223]
The components of other non-current liabilities were as follows (in millions):

[0001633978-20-000011:notes:224]
|  | June 27, 2020 |  | June 29, 2019 |
| Asset retirement obligation | $ | 4.6 |  |  | $ | 4.5 |  |
| Pension and related accrual (1) | 11.8 |  |  | 7.9 |  |
| Deferred rent | — |  |  | 2.2 |  |
| Unrecognized tax benefit | 17.3 |  |  | 18.7 |  |
| Other non-current liabilities | 2.3 |  |  | 0.4 |  |
| Other non-current liabilities | $ | 36.0 |  |  | $ | 33.7 |  |

[0001633978-20-000011:notes:225]
(1) We have defined benefit pension plans in Japan, Switzerland, and Thailand. As of June 27, 2020, the projected benefit obligations in Japan, Switzerland, and Thailand were $2.9 million, $6.4 million, and $2.5 million, respectively. As of June 29, 2019, the projected benefit obligations in Japan and Switzerland were $2.8 million and $5.0 million, respectively. Pension and related accruals as of June 29, 2019 also include $0.1 million attributable to post-retirement benefits for executives.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001633978-20-000011:notes:226]
Note 9. Leases

[0001633978-20-000011:notes:227]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2033. These operating leases are mainly for administrative offices, research-and-development and manufacturing facilities, as well as sales offices in various countries around the world. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. Many leases include one or more options to renew. We do not assume renewals in our determination of the lease term unless the renewals are deemed to be reasonably assured at lease commencement.

[0001633978-20-000011:notes:228]
We have also entered into various finance leases to obtain servers and certain other equipment for our operations. These arrangements are typically for two to four years.

[0001633978-20-000011:notes:229]
As of June 27, 2020, we sublease certain floors of our offices in the United Kingdom, the United States, Canada, and Japan. These subleases will expire at various dates by fiscal year 2023. We anticipate receiving approximately $5.4 million in sublease income over the next three years.

[0001633978-20-000011:notes:230]
The components of lease costs, lease term, and discount rate are as follows:

[0001633978-20-000011:notes:231]
| (in millions) | June 27, 2020 |
| Finance lease cost: |  |
| Amortization of right-of-use assets | $ | 16.3 |  |
| Interest | 0.1 |  |
| Operating lease cost | 15.5 |  |
| Variable lease cost | 1.8 |  |
| Short-term lease cost | 2.6 |  |
| Sublease income | (2.6 | ) |
| Total lease cost | $ | 33.7 |  |
| Weighted average remaining lease term (in years): |  |
| Operating leases | 8.6 |  |
| Finance leases | 1.0 |  |
| Weighted average discount rate: |  |
| Operating leases | 3.5 | % |
| Finance leases | 4.4 | % |

[0001633978-20-000011:notes:232]
As of June 27, 2020, maturities of our operating and finance lease liabilities, which do not include short-term leases and variable lease payments, were as follows (in millions):

[0001633978-20-000011:notes:233]
| Fiscal Years |  | Operating Leases (1) |  | Finance Leases |  | Total |
| 2021 |  | $ | 13.1 |  |  | $ | 0.6 |  |  | $ | 13.7 |  |
| 2022 |  | 12.4 |  |  | — |  |  | 12.4 |  |
| 2023 |  | 11.2 |  |  | — |  |  | 11.2 |  |
| 2024 |  | 9.5 |  |  | — |  |  | 9.5 |  |
| 2025 |  | 6.3 |  |  | — |  |  | 6.3 |  |
| Thereafter |  | 25.3 |  |  | — |  |  | 25.3 |  |
| Total minimum lease payments |  | $ | 77.8 |  |  | $ | 0.6 |  |  | $ | 78.4 |  |
| Less: amount representing interest |  | (9.4 | ) |  | — |  |  | (9.4 | ) |
| Present value of total lease liabilities |  | $ | 68.4 |  |  | $ | 0.6 |  |  | $ | 69.0 |  |

[0001633978-20-000011:notes:234]
(1) Non-cancellable sublease proceeds for fiscal 2021, 2022, and 2023 of $2.5 million, $2.3 million, and $0.6 million, respectively, are not included in the table above.

[0001633978-20-000011:notes:235]
Prior to our adoption of Topic 842, future minimum lease payments as of June 29, 2019, which were undiscounted, were net of our sublease income amounts, and included lease and non-lease components, were as follows (in millions):

[0001633978-20-000011:notes:236]
| Fiscal Years |  | Operating Leases |  | Finance Leases |  | Total |
| 2020 |  | $ | 13.9 |  |  | $ | 0.8 |  |  | $ | 14.7 |  |
| 2021 |  | 12.1 |  |  | — |  |  | 12.1 |  |
| 2022 |  | 11.2 |  |  | — |  |  | 11.2 |  |
| 2023 |  | 11.3 |  |  | — |  |  | 11.3 |  |
| 2024 |  | 9.8 |  |  | — |  |  | 9.8 |  |
| Thereafter |  | 31.7 |  |  | — |  |  | 31.7 |  |
| Total minimum operating lease payments |  | $ | 90.0 |  |  | $ | 0.8 |  |  | $ | 90.8 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001633978-20-000011:notes:237]
Note 10. Goodwill and Other Intangible Assets

[0001633978-20-000011:notes:238]
On December 10, 2018, we completed the acquisition of Oclaro. We recognized goodwill in the amount of $357.6 million for the acquisition of Oclaro and allocated it to our OpComms segment. The following table presents our goodwill balance by the reportable segments during the years ended June 27, 2020 and June 29, 2019 (in millions):

[0001633978-20-000011:notes:239]
|  |  | Optical Communications |  | Commercial Lasers |  | Total |
| Balance as of June 30, 2018 | $ | 5.9 |  |  | $ | 5.4 |  |  | $ | 11.3 |  |
|  | Acquisition of Oclaro in fiscal year 2019 | 357.6 |  |  | — |  |  | 357.6 |  |
| Balance as of June 29, 2019 and June 27, 2020 | $ | 363.5 |  |  | $ | 5.4 |  |  | $ | 368.9 |  |

[0001633978-20-000011:notes:240]
Impairment of Goodwill

[0001633978-20-000011:notes:241]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. Based on the impairment analysis performed in the fourth quarter of each year presented, the fair value of each of our reporting units substantially exceeded the carrying value; as such, our annual qualitative assessment did not indicate that a more detailed quantitative analysis was necessary.

[0001633978-20-000011:notes:242]
Other Intangibles

[0001633978-20-000011:notes:243]
In connection with our acquisition of Oclaro in fiscal year 2019, we recorded $443.0 million as the fair value of the acquired developed technologies and other intangible assets. This amount excludes $1.0 million of in-process research and development assets that were subsequently sold to CIG.

[0001633978-20-000011:notes:244]
The intangible assets are amortized on a straight-line basis over the estimated useful lives, except for customer relationships and order backlog, which are amortized using an accelerated method of amortization over the expected customer lives, which more accurately reflects the pattern of realization of economic benefits expected to be obtained. Acquired developed technologies and order backlog are amortized to cost of sales and customer relationships is amortized to selling, general and administrative. IPR&D is initially capitalized at fair value as an intangible asset with an indefinite life and assessed for impairment thereafter. When an IPR&D project is completed, the IPR&D is reclassified as an amortizable purchased intangible asset and amortized over the asset’s estimated useful life expected to range between 4 to 9 years.

[0001633978-20-000011:notes:245]
The following tables present details of our other intangibles, including those acquired in connection with the Oclaro acquisition, as of the periods presented (in millions, except for weighted average remaining amortization period):

[0001633978-20-000011:notes:246]
| June 27, 2020 | Gross Carrying Amounts |  | Accumulated Amortization |  | Net Carrying Amounts |  | Weighted average remaining amortization period (years) |
| Acquired developed technologies (1) | $ | 371.5 |  |  | $ | (176.9 | ) |  | $ | 194.6 |  |  | 3.7 |
| Customer relationships | 149.3 |  |  | (37.1 | ) |  | 112.2 |  |  | 6.5 |
| In-process research and development (1) | 10.0 |  |  | — |  |  | 10.0 |  |  | n/a |
| Order backlog | 22.0 |  |  | (22.0 | ) |  | — |  |  | — |
| Other intangibles | 2.7 |  |  | (2.7 | ) |  | — |  |  | — |
| Total intangible assets | $ | 555.5 |  |  | $ | (238.7 | ) |  | $ | 316.8 |  |  |  |

[0001633978-20-000011:notes:247]
(1) During the year ended June 27, 2020, we completed $84.0 million of IPR&D projects, and reclassified the value assigned to them to acquired developed technologies. The amount will be amortized over the assets’ estimated useful life of 4 to 7 years.

[0001633978-20-000011:notes:248]
| June 29, 2019 | Gross Carrying Amounts |  | Accumulated Amortization |  | Net Carrying Amounts |  | Weighted average remaining amortization period (years) |
| Acquired developed technologies | $ | 287.5 |  |  | $ | (125.2 | ) |  | $ | 162.3 |  |  | 3.8 |
| Customer relationships | 149.3 |  |  | (12.3 | ) |  | 137.0 |  |  | 7.5 |
| In-process research and development | 94.0 |  |  | — |  |  | 94.0 |  |  | n/a |
| Order backlog | 22.0 |  |  | (19.9 | ) |  | 2.1 |  |  | 0.5 |
| Other intangibles | 2.7 |  |  | (2.7 | ) |  | — |  |  | — |
| Total intangible assets | $ | 555.5 |  |  | $ | (160.1 | ) |  | $ | 395.4 |  |  |  |

[0001633978-20-000011:notes:249]
During fiscal 2020, 2019 and 2018, we recorded $78.6 million, $54.6 million, and $3.2 million, respectively, of amortization related to intangibles assets.

[0001633978-20-000011:notes:250]
The following table presents details of amortization for the periods presented (in millions):

[0001633978-20-000011:notes:251]
|  | Years ended |
|  | June 27, 2020 |  | June 29, 2019 |  | June 30, 2018 |
| Cost of sales | $ | 53.8 |  |  | $ | 46.6 |  |  | $ | 3.2 |  |
| Selling, general and administrative | 24.8 |  |  | 8.0 |  |  | — |  |
| Total amortization of intangibles | $ | 78.6 |  |  | $ | 54.6 |  |  | $ | 3.2 |  |

[0001633978-20-000011:notes:252]
Based on the carrying amount of our acquired developed technologies and other intangibles, excluding IPR&D, as of June 27, 2020, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001633978-20-000011:notes:253]
| Fiscal Years |  |
| 2021 | $ | 82.6 |  |
| 2022 | 80.1 |  |
| 2023 | 56.6 |  |
| 2024 | 36.8 |  |
| 2025 | 25.7 |  |
| Thereafter | 25.0 |  |
| Total | $ | 306.8 |  |


## lite:NoncontrollingInterestAndDerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001633978-20-000011:notes:254]
Note 11. Non-Controlling Interest Redeemable Convertible Preferred Stock and Derivative Liability

[0001633978-20-000011:notes:255]
On July 31, 2015, our wholly-owned subsidiary, Lumentum Inc., issued 40,000 shares of its Series A Preferred Stock to Viavi Solutions Inc. (“Viavi”). Pursuant to a securities purchase agreement between us, Viavi and Amada Holdings Co., Ltd. (“Amada”), 35,805 shares of Series A Preferred Stock were sold by Viavi to Amada in August 2015. The remaining 4,195 shares of the Series A Preferred Stock were canceled. The Series A Preferred Stock was referred to as our Non-Controlling Interest Redeemable Convertible Preferred Stock of $35.8 million on our consolidated balance sheets through the date of conversion in fiscal 2019.

[0001633978-20-000011:notes:256]
On October 15, 2018, we issued a 30-day notice of intent to the holders of Series A Preferred Stock to convert all shares of Series A Preferred Stock at a conversion price equal to the Issuance Value divided by $24.63 plus the accrued and unpaid dividends on each share and any past due dividends, whether or not authorized or declared. On November 2, 2018, we received notice from Amada of their intent to convert the Series A Preferred Stock and we issued 1.5 million shares of our common stock to Amada upon the conversion of the 35,805 shares of Series A Preferred Stock and recorded $79.4 million in additional paid in capital in the balance sheet.

[0001633978-20-000011:notes:257]
Through the date of conversion, holders of Series A Preferred Stock, in preference to holders of common stock or any other class or series of our outstanding capital stock ranking in any such event junior to the Series A Preferred Stock, were entitled to receive, when and as declared by the board of directors, quarterly cumulative cash dividends at the annual rate of 2.5% of the

[0001633978-20-000011:notes:258]
Issuance Value per share on each outstanding share of Series A Preferred Stock. The accrued dividends were payable on March 31, June 30, September 30 and December 31 of each year commencing on September 30, 2015. During each of the years ended June 29, 2019 and June 30, 2018, we paid $0.7 million in dividends to the holders of Series A Preferred Stock.

[0001633978-20-000011:notes:259]
Through the date of conversion, the Series A Preferred Stock conversion feature was bifurcated from the Series A Preferred Stock and accounted for separately as a derivative liability. The derivative liability was measured at fair value each reporting period, and at the date of conversion, with the change in fair value recorded in the consolidated statements of operations.

[0001633978-20-000011:notes:260]
The following table provides a reconciliation of the fair value of the embedded derivative for the Series A Preferred Stock for the years ended June 29, 2019 and June 30, 2018 (in millions):

[0001633978-20-000011:notes:261]
|  | Years Ended |
|  |  | June 29, 2019 |  | June 30, 2018 |
| Balance as of beginning of period |  | $ | 52.4 |  |  | $ | 51.6 |  |
| Unrealized (gain) loss on the Series A Preferred Stock derivative liability up through the conversion date |  | (8.8 | ) |  | 0.8 |  |
| Settlement of the derivative liability upon conversion of Series A Preferred Stock |  | (43.6 | ) |  | — |  |
| Balance as of end of period |  | $ | — |  |  | $ | 52.4 |  |


## us-gaap:DebtDisclosureTextBlock

[0001633978-20-000011:notes:262]
Note 12. Debt

[0001633978-20-000011:notes:263]
Convertible Notes

[0001633978-20-000011:notes:264]
2026 Notes

[0001633978-20-000011:notes:265]
In December 2019, we issued $1,050.0 million in aggregate principal amount of the 2026 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2026 Notes are governed by an indenture between the Company and U.S. Bank National Association (the “2026 Indenture”). We used approximately $196 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan credit facility, and a portion of the net proceeds of the offering to purchase approximately $200 million of our common stock concurrently with the pricing of the offering in privately negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001633978-20-000011:notes:266]
The 2026 Notes will bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on June 15, 2020. The 2026 Notes will mature on December 15, 2026, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001633978-20-000011:notes:267]
The initial conversion rate is 10.0711 shares of common stock per $1,000 principal amount of the 2026 Notes (which is equivalent to an initial conversion price of approximately $99.29 per share). The conversion rate is subject to adjustment upon the occurrence of certain specified events but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2026 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001633978-20-000011:notes:268]
Prior to the close of business on the business day immediately preceding September 15, 2026, holders of the 2026 Notes may convert their 2026 Notes only under the following circumstances:

[0001633978-20-000011:notes:269]
| • | during any fiscal quarter commencing after the fiscal quarter ended on March 28, 2020 (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price of the 2026 Notes, or $129.08 on each applicable trading day; |

[0001633978-20-000011:notes:270]
| • | during the five business day period after any five consecutive trading day period (the "2026 measurement period") in which the trading price per $1,000 principal amount of the 2026 Notes for each trading day of the 2026 measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the notes on each such trading day; |

[0001633978-20-000011:notes:271]
| • | if we call any or all of the 2026 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the relevant redemption date; or |

[0001633978-20-000011:notes:272]
| • | upon the occurrence of specified corporate events, as specified in each indenture governing the 2026 Notes. |

[0001633978-20-000011:notes:273]
On or after September 15, 2026 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert the 2026 Notes at any time. Upon conversion, we may satisfy our conversion obligation in cash, shares of common stock or a combination of cash and shares of common stock, at our election.

[0001633978-20-000011:notes:274]
We may redeem for cash, stock or combination of both for all or any portion of the 2026 Notes, at our option, on or after December 20, 2023, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide a notice of redemption at a redemption price equal to 100% of the principal amount of the 2026 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2026 Notes. Upon the occurrence of a fundamental change (as defined in the 2026 Indenture), holders may require us to repurchase all or a portion of the 2026 Notes for cash at a price equal to 100% of the principal amount of the 2026 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001633978-20-000011:notes:275]
In accordance with accounting for debt with conversions and other options, we bifurcated the principal amount of the 2026 Notes into liability and equity components. The liability component of the 2026 Notes was valued at $734.8 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 5.8% with the equity component representing the residual amount of the proceeds of $315.2 million, which was recorded as a debt discount.

[0001633978-20-000011:notes:276]
We incurred approximately $7.8 million in transaction costs in connection with the issuance of the 2026 Notes and these costs were allocated pro rata based on the relative carrying amounts of the liability and equity components. The debt discount and debt issuance costs attributable to the liability component will be amortized to interest expense using an effective interest rate of 5.8% over the expected life of the 2026 Notes. Debt issuance costs attributable to the equity component are netted with the equity component in stockholders’ equity, and the equity component is not remeasured as long as it continues to meet the conditions for equity classification.

[0001633978-20-000011:notes:277]
2024 Notes

[0001633978-20-000011:notes:278]
In March 2017, we issued $450.0 million of the 2024 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank National Association, as trustee (the “2024 Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001633978-20-000011:notes:279]
The 2024 Notes bear interest at a rate of 0.25% per year. Interest on the 2024 Notes is payable semi-annually in arrears on March 15 and September 15 of each year, beginning on September 15, 2017. The 2024 Notes will mature on March 15, 2024, unless earlier repurchased by us or converted pursuant to their terms.

[0001633978-20-000011:notes:280]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share, a 132.5% premium to the fair market value at the date of issuance. Prior to the close of business on the business day immediately preceding December 15, 2023, the 2024 Notes will be convertible only under the following circumstances:

[0001633978-20-000011:notes:281]
| • | during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price, or $78.80 on each applicable trading day; |

[0001633978-20-000011:notes:282]
| • | during the five consecutive business day period after any five consecutive trading day period (the “2024 measurement period”) in which the trading price per $1,000 principal amount of notes for each trading day of such 2024 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day; |

[0001633978-20-000011:notes:283]
| • | upon the occurrence of specified corporate events. |

[0001633978-20-000011:notes:284]
On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2024 Notes at any time. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2024 Indenture), we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert 2024 Notes in connection with such make-whole fundamental change.

[0001633978-20-000011:notes:285]
We may not redeem the 2024 Notes prior to their maturity date and no sinking fund is provided for the 2024 Notes. Upon the occurrence of a fundamental change, holders may require us to repurchase all or a portion of their 2024 Notes for cash at a price equal to 100% of the principal amount of the 2024 Notes to be repurchased, plus any accrued and unpaid interest.

[0001633978-20-000011:notes:286]
We considered the features embedded in the 2024 Notes other than the conversion feature, including the holders’ put feature, our call feature, and the make-whole feature, and concluded that they are not required to be bifurcated and accounted for separately from the host debt instrument.

[0001633978-20-000011:notes:287]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. We incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. We amortize the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes is 5.4% per year.

[0001633978-20-000011:notes:288]
During the fiscal year ended July 1, 2017, we satisfied the TMA settlement condition. As such, the value of the conversion option will no longer be marked to market and was reclassified to additional paid-in capital within stockholders’ equity on our consolidated balance sheet. The value of the conversion option at the time of issuance will be treated as an original issue discount for purposes of accounting for the debt component of the notes. The debt component will accrete up to the principal amount over the expected term of the debt.

[0001633978-20-000011:notes:289]
Our convertible notes consisted of the following components as of the periods presented (in millions):

[0001633978-20-000011:notes:290]
| Liability component: | June 27, 2020 |  | June 29, 2019 |
|  | 2024 Notes |  | 2026 Notes |  | 2024 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount and debt issuance costs | (79.4 | ) |  | (300.3 | ) |  | (98.1 | ) |
| Net carrying amount of the liability component | $ | 370.6 |  |  | $ | 749.7 |  |  | $ | 351.9 |  |

[0001633978-20-000011:notes:291]
During all periods presented, the debt component of our 2024 Notes was recorded in long-term liabilities. However, if our stock price exceeds $78.80 for 20 of the last 30 trading days of the first quarter of fiscal 2021, the 2024 Notes would become callable at the option of the holders. Therefore, the debt component of our 2024 notes (approximately $371 million as of June 27, 2020) would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001633978-20-000011:notes:292]
The following table sets forth interest expense information related to the convertible notes for the periods presented (in millions, except percentages):

[0001633978-20-000011:notes:293]
|  | June 27, 2020 |  | June 29, 2019 |  | June 30, 2018 |
| Contractual interest expense | $ | 3.9 |  |  | $ | 1.1 |  |  | $ | 1.2 |  |
| Amortization of the debt discount and debt issuance costs | 39.1 |  |  | 17.7 |  |  | 16.7 |  |
| Total interest expense | $ | 43.0 |  |  | $ | 18.8 |  |  | $ | 17.9 |  |

[0001633978-20-000011:notes:294]
The future interest and principal payments related to our convertible notes are as follows as of June 27, 2020 (in millions):

[0001633978-20-000011:notes:295]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | Total |
| 2021 | $ | 1.1 |  |  | $ | 5.2 |  |  | $ | 6.3 |  |
| 2022 | 1.1 |  |  | 5.3 |  |  | 6.4 |  |
| 2023 | 1.1 |  |  | 5.2 |  |  | 6.3 |  |
| 2024 | 451.2 |  |  | 5.3 |  |  | 456.5 |  |
| 2025 | — |  |  | 5.2 |  |  | 5.2 |  |
| Thereafter | — |  |  | 1,057.9 |  |  | 1,057.9 |  |
| Total convertible notes payments | $ | 454.5 |  |  | $ | 1,084.1 |  |  | $ | 1,538.6 |  |

[0001633978-20-000011:notes:296]
Term Loan Facility

[0001633978-20-000011:notes:297]
On December 10, 2018 (the “Closing Date”), concurrent with the closing of the Oclaro merger, we entered into a Credit and Guarantee Agreement (the “Credit Agreement”), by and among us, certain of our subsidiaries, the lenders party thereto, and Deutsche Bank, as administrative agent and collateral agent for the lenders. The Credit Agreement provides for a senior secured term loan facility (the “Term Loan Facility”) in an aggregate principal amount of $500.0 million. The term loans available under the Term Loan Facility were fully drawn on the Closing Date and the proceeds of the term loans were used to consummate the merger and pay fees and expenses in connection with the merger and the Term Loan Facility.

[0001633978-20-000011:notes:298]
In fiscal 2019, we incurred $9.3 million of debt issuance costs in connection with the Term Loan Facility which were capitalized and recorded as a contra liability in our consolidated balance sheet. These costs were amortized to interest expense using the effective interest rate method from the issuance date of December 10, 2018.

[0001633978-20-000011:notes:299]
In fiscal 2020, we repaid, in full, all amounts outstanding under our Term Loan Facility. During the year ended June 27, 2020, we incurred an $8.0 million loss for the unamortized debt issuance costs as a result of this full repayment.

[0001633978-20-000011:notes:300]
The following table sets forth interest expense information related to the term loan for the periods presented (in millions):

[0001633978-20-000011:notes:301]
|  | June 27, 2020 |  | June 29, 2019 |
| Contractual interest expense | $ | 9.6 |  |  | $ | 13.8 |  |
| Ticking fee | — |  |  | 2.7 |  |
| Amortization of the debt issuance costs | 0.5 |  |  | 0.8 |  |
| Loss on early extinguishment of debt | 8.0 |  |  | — |  |
| Total interest expense | $ | 18.1 |  |  | $ | 17.3 |  |

[0001633978-20-000011:notes:302]
For each of the years ended June 27, 2020 and June 29, 2019, we recorded $0.1 million and $0.2 million interest expense related to our finance leases, respectively.

[0001633978-20-000011:notes:303]
The following table sets forth balance sheet information related to the term loan as of the periods presented (in millions):

[0001633978-20-000011:notes:304]
|  | June 27, 2020 |  | June 29, 2019 |
| Principal | $ | 497.5 |  |  | $ | 500.0 |  |
| Repayment of principal | (497.5 | ) |  | (2.5 | ) |
| Unamortized value of the debt issuance costs | — |  |  | (8.5 | ) |
| Net carrying value | $ | — |  |  | $ | 489.0 |  |
| Term loan, current | $ | — |  |  | $ | 5.0 |  |
| Term loan, non-current | $ | — |  |  | $ | 484.0 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001633978-20-000011:notes:305]
Note 13. Accumulated Other Comprehensive Income (Loss)

[0001633978-20-000011:notes:306]
Our accumulated other comprehensive income (loss) consists of the accumulated net unrealized gains or losses on foreign currency translation adjustments, the defined benefit obligations, and available-for-sale securities.

[0001633978-20-000011:notes:307]
The components of accumulated other comprehensive income (loss) were as follows for the periods as presented (in millions):

[0001633978-20-000011:notes:308]
|  | Foreign currency translation adjustments, net of tax (1) |  | Defined benefit obligations, net of tax (2) |  | Unrealized gain (loss) on available-for-sale securities, net of tax (3) |  | Total |
| Beginning balance as of July 1, 2017 | $ | 10.5 |  |  | $ | (3.1 | ) |  | $ | — |  |  | $ | 7.4 |  |
| Other comprehensive income (loss) | (0.2 | ) |  | 0.8 |  |  | (1.6 | ) |  | (1.0 | ) |
| Ending balance as of June 30, 2018 | 10.3 |  |  | (2.3 | ) |  | (1.6 | ) |  | 6.4 |  |
| Other comprehensive income (loss) | (0.6 | ) |  | (1.2 | ) |  | 2.5 |  |  | 0.7 |  |
| Ending balance as of June 29, 2019 | 9.7 |  |  | (3.5 | ) |  | 0.9 |  |  | 7.1 |  |
| Other comprehensive income (loss) | — |  |  | (0.7 | ) |  | 1.5 |  |  | 0.8 |  |
| Ending balance as of June 27, 2020 | $ | 9.7 |  |  | $ | (4.2 | ) |  | $ | 2.4 |  |  | $ | 7.9 |  |

[0001633978-20-000011:notes:309]
(1) In fiscal 2019, as a result of significant changes in economic facts and circumstances, primarily due to the acquisition of Oclaro, we established the functional currency for our worldwide operations as the U.S. dollar. Translation adjustments reported prior to December 10, 2018, remain as a component of accumulated other comprehensive income in our consolidated balance sheets, until all or a part of the investment in the subsidiaries is sold or liquidated.

[0001633978-20-000011:notes:310]
(2) We evaluate the assumptions over the fair value of our defined benefit obligations annually and make changes as necessary.  During each of fiscal 2020, 2019, and 2018, our income (loss) on defined benefit obligations is presented net of tax of $0.2 million.
(3) In fiscal 2020 and 2019, our unrealized gain on available-for-sale securities is presented net of tax of $0.3 million and $0.2 million, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001633978-20-000011:notes:311]
Note 14. Restructuring and Related Charges

[0001633978-20-000011:notes:312]
We have initiated various strategic restructuring actions primarily intended to reduce costs, consolidate our operations, rationalize the manufacturing of our products and align our business in response to market conditions and as a result of our acquisition of Oclaro on December 10, 2018.

[0001633978-20-000011:notes:313]
The following table summarizes the activity of restructuring and related charges during the periods presented (in millions):

[0001633978-20-000011:notes:314]
|  | Years Ended |
|  | June 27, 2020 |  | June 29, 2019 |  | June 30, 2018 |
| Balance as of beginning of period | $ | 14.6 |  |  | $ | 1.9 |  |  | $ | 3.8 |  |
| Charges | 8.0 |  |  | 31.9 |  |  | 7.2 |  |
| Payments | (17.4 | ) |  | (19.2 | ) |  | (9.1 | ) |
| Balance as of end of period | $ | 5.2 |  |  | $ | 14.6 |  |  | $ | 1.9 |  |

[0001633978-20-000011:notes:315]
During fiscal 2020, we recorded $8.0 million in restructuring and related charges in our consolidated statements of operations. The charges were mainly attributable to severance charges associated with the decision to move certain manufacturing from San Jose, California to our facility in Thailand.

[0001633978-20-000011:notes:316]
During fiscal 2019, we recorded $31.9 million in restructuring and related charges in our consolidated statements of operations, primarily attributable to severance and employee related benefits associated with the wind down of operations for Lithium Niobate modulators and Datacom modules of $21.1 million. In addition, the charges included severance and employee related benefits associated with Oclaro’s executive severance and retention agreements. These retention agreements provided,

[0001633978-20-000011:notes:317]
under certain circumstances, for payments and benefits upon an involuntary termination of employment. In fiscal 2019, we also recorded $1.6 million of lease restructuring charges for the former Oclaro corporate headquarters and restructuring charges primarily associated with acquisition related synergies.

[0001633978-20-000011:notes:318]
During fiscal 2018, we recorded $7.2 million in restructuring and related charges in the consolidated statements of operations, where $3.4 million related to severance costs and employee benefits and $3.8 million related to restructuring plans approved prior to fiscal 2016 primarily related to the shutdown of our manufacturing facility in Bloomfield, Connecticut as a result of the transfer of certain production processes into existing sites in the United States or to contract manufacturers.

[0001633978-20-000011:notes:319]
Any changes in the estimates of executing our restructuring activities will be reflected in our future results of operations.


## us-gaap:AssetImpairmentChargesTextBlock

[0001633978-20-000011:notes:320]
Note 15. Impairment and Other Charges

[0001633978-20-000011:notes:321]
Impairment charges associated with product lines exit

[0001633978-20-000011:notes:322]
The following table summarizes the activity of  impairment charges during the periods presented (in millions):

[0001633978-20-000011:notes:323]
|  | Years Ended |
|  | June 27, 2020 |  | June 29, 2019 |  | June 30, 2018 |
| Impairment charges | $ | 4.3 |  |  | $ | 30.7 |  |  | $ | — |  |

[0001633978-20-000011:notes:324]
In the third quarter of fiscal 2019, we announced our plan to discontinue the development and manufacturing of future Datacom transceiver modules which impacted the California and China based Datacom module teams. As a result of these actions, we recorded impairment charges of $4.3 million and $30.7 million in fiscal 2020 and 2019, respectively, to our Long-lived assets that were not deemed to be useful. While we expect strong growth in Datacom volumes in the future, gross margins at the transceiver market level are lower due to extreme competition. Following the Oclaro acquisition, we have a differentiated leadership position across a range of photonic chips on which the Datacom, wireless, and access markets critically rely.

[0001633978-20-000011:notes:325]
In fiscal 2020 and 2019, we also recorded inventory and fixed assets write down charges of $7.0 million and $20.8 million related to the decision to exit the Datacom module and Lithium Niobate product lines in our cost of goods sold of consolidated statements of operations. Refer to “Note 5. Assets Held For Sale and Related Dispositions” for details on the exit from these product lines.

[0001633978-20-000011:notes:326]
These actions do not qualify as discontinued operations for disclosure purposes as they do not represent a strategic shift having a major effect on an entity’s operations and financial results.

[0001633978-20-000011:notes:327]
Other losses on property, plant and equipment

[0001633978-20-000011:notes:328]
We also had other fixed assets losses, mainly attributable to the retirement and disposal of fixed assets, and not associated with the exit from product lines. The impact of such losses on our results of operations by function during the periods presented was as follows (in millions):

[0001633978-20-000011:notes:329]
|  | Years Ended |
|  | June 27, 2020 |  | June 29, 2019 |  | June 30, 2018 |
| Cost of sales | $ | 16.1 |  |  | $ | 2.2 |  |  | $ | 0.4 |  |
| Research and development | 0.8 |  |  | — |  |  | 0.1 |  |
| Selling, general and administrative | 0.6 |  |  | — |  |  | 0.1 |  |
|  | $ | 17.5 |  |  | $ | 2.2 |  |  | $ | 0.6 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001633978-20-000011:notes:330]
Note 16. Income Taxes

[0001633978-20-000011:notes:331]
Our income (loss) before income taxes consisted of the following (in millions):

[0001633978-20-000011:notes:332]
|  | Years Ended |
|  | June 27, 2020 |  | June 29, 2019 |  | June 30, 2018 |
| Domestic | $ | (33.1 | ) |  | $ | (21.9 | ) |  | $ | 37.8 |  |
| Foreign | 207.4 |  |  | (11.4 | ) |  | 91.6 |  |
| Income (loss) before income taxes | $ | 174.3 |  |  | $ | (33.3 | ) |  | $ | 129.4 |  |

[0001633978-20-000011:notes:333]
Our income tax (benefit) expense consisted of the following (in millions):

[0001633978-20-000011:notes:334]
|  | Years Ended |
|  | June 27, 2020 |  | June 29, 2019 |  | June 30, 2018 |
| Federal: |  |  |  |  |  |
| Current | $ | 2.9 |  |  | $ | 13.8 |  |  | $ | 1.2 |  |
| Deferred | 19.3 |  |  | (0.1 | ) |  | (120.4 | ) |
|  | 22.2 |  |  | 13.7 |  |  | (119.2 | ) |
| State: |  |  |  |  |  |
| Current | 0.1 |  |  | 0.1 |  |  | 1.0 |  |
| Deferred | (0.4 | ) |  | 0.4 |  |  | (1.3 | ) |
|  | (0.3 | ) |  | 0.5 |  |  | (0.3 | ) |
| Foreign: |  |  |  |  |  |
| Current | 23.4 |  |  | 10.3 |  |  | 1.2 |  |
| Deferred | (6.5 | ) |  | (21.4 | ) |  | (0.4 | ) |
|  | 16.9 |  |  | (11.1 | ) |  | 0.8 |  |
| Total income tax (benefit) expense | $ | 38.8 |  |  | $ | 3.1 |  |  | $ | (118.7 | ) |

[0001633978-20-000011:notes:335]
The comparability of our operating results of fiscal 2019 compared to the corresponding prior year was impacted by the U.S. Tax Cuts and Jobs Act of 2017 (the “Tax Act”), which was enacted on December 22, 2017.

[0001633978-20-000011:notes:336]
The provision for income taxes differs from the amount computed by applying the U.S. Federal statutory income tax rate to our income before provision for income taxes as follows (in millions):

[0001633978-20-000011:notes:337]
|  | Years Ended |
|  | June 27, 2020 |  | June 29, 2019 |  | June 30, 2018 |
| Income tax (benefit) expense computed at federal statutory rate | $ | 36.6 |  |  | $ | (7.0 | ) |  | $ | 36.3 |  |
| Foreign rate differential | (24.6 | ) |  | (17.8 | ) |  | (24.3 | ) |
| Change in valuation allowance | 13.4 |  |  | 7.4 |  |  | (206.0 | ) |
| Change in Tax law | — |  |  | — |  |  | 80.5 |  |
| Tax credits | (10.2 | ) |  | (7.1 | ) |  | (11.0 | ) |
| Stock-based compensation | 4.8 |  |  | 5.9 |  |  | (1.0 | ) |
| Subpart F and GILTI | 22.9 |  |  | 13.4 |  |  | 2.0 |  |
| Unrecognized tax benefits | (1.7 | ) |  | 4.8 |  |  | 7.9 |  |
| Other | (2.4 | ) |  | 0.5 |  |  | (3.1 | ) |
| Audit settlement | — |  |  | 3.0 |  |  | — |  |
| Total income tax (benefit) expense | $ | 38.8 |  |  | $ | 3.1 |  |  | $ | (118.7 | ) |

[0001633978-20-000011:notes:338]
Our provision for income taxes for fiscal 2020 differs from the 21% U.S. statutory rate primarily due to GILTI and subpart F inclusions and an increase to the valuation allowance because it is not more-likely-than-not that certain deferred tax assets will be realizable, which are partially offset by the income tax benefit of the earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate as well as tax credits.

[0001633978-20-000011:notes:339]
Our provision for income taxes for fiscal 2019 differs from the 21% U.S. statutory rate primarily due to GILTI and subpart F inclusions, partially offset by the income tax benefit of the earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate as well as tax credits.

[0001633978-20-000011:notes:340]
Our provision for income taxes for fiscal 2018 differed from the tax provision based on the U.S. statutory federal income tax rate of approximately 28% as a result of $207.2 million of income tax benefit related to the release of valuation allowance against our U.S. federal and certain state deferred tax assets, partially offset by $80.5 million of income tax expense related to the remeasurement of our net deferred tax assets as a result of reduction in the U.S. federal corporate tax rate.

[0001633978-20-000011:notes:341]
The components of our net deferred taxes consisted of the following (in millions):

[0001633978-20-000011:notes:342]
|  | Years Ended |
|  | June 27, 2020 |  | June 29, 2019 |
| Gross deferred tax assets: |  |  |  |
| Intangibles | $ | 101.1 |  |  | $ | 111.7 |  |
| Tax credit carryforwards | 67.8 |  |  | 66.5 |  |
| Net operating loss carryforwards | 129.8 |  |  | 134.6 |  |
| Inventories | 7.4 |  |  | 11.3 |  |
| Accruals and reserves | 13.1 |  |  | 19.6 |  |
| Fixed assets | 23.2 |  |  | 32.3 |  |
| Capital loss carryforwards | 11.5 |  |  | 12.1 |  |
| Unclaimed research and experimental development expenditure | 33.4 |  |  | 25.6 |  |
| Stock-based compensation | 3.6 |  |  | 3.4 |  |
| Lease liabilities | 17.7 |  |  | — |  |
| Other | 0.2 |  |  | — |  |
| Gross deferred tax assets | 408.8 |  |  | 417.1 |  |
| Valuation allowance | (200.8 | ) |  | (190.3 | ) |
| Deferred tax assets | 208.0 |  |  | 226.8 |  |
| Gross deferred tax liabilities: |  |  |  |
| Intangible amortization | (68.5 | ) |  | (90.8 | ) |
| Convertible notes | (79.4 | ) |  | (20.1 | ) |
| Right-of-use assets | (21.3 | ) |  | — |  |
| Other | (4.1 | ) |  | (2.2 | ) |
| Deferred tax liabilities | (173.3 | ) |  | (113.1 | ) |
| Total net deferred tax assets | $ | 34.7 |  |  | $ | 113.7 |  |

[0001633978-20-000011:notes:343]
We assess our ability to realize the deferred tax assets on a quarterly basis and establish a valuation allowance if the deferred tax assets are not more-likely-than-not to be realized. We weigh all available positive and negative evidence, including our earnings history and results of recent operations, reversals of deferred tax liabilities, projected future taxable income and the character of such income, and tax planning strategies.

[0001633978-20-000011:notes:344]
As of each reporting date, we consider new evidence, both positive and negative, that could affect our view of the future realization of deferred tax assets. During fiscal 2020, we determined it is not more-likely-than-not that certain U.S. federal and states deferred tax assets are realizable. We, therefore, have recorded a valuation allowance against certain U.S. federal, states, and foreign deferreds resulting in an income tax expense of $10.5 million. A majority of the increase to our valuation allowance relates to certain foreign tax credits and foreign deferred tax assets.

[0001633978-20-000011:notes:345]
Due to the weight of negative evidence, we continue to maintain a full valuation allowance on our California, Canada and the U.K. deferred tax assets, and partial valuation allowance on our Federal deferred tax asset and Thailand deferred tax assets. In the event the Company determines that it will be able to realize all or a portion of the deferred tax assets in the future, the valuation allowance will be reversed in the period in which the Company makes such determination. Based on the information currently available, we do not believe that a significant portion of our valuation allowance for the U.K., Thailand, the U.S., California, and Canada will be released in the next 12 months. Such a release would result in the recognition of certain deferred tax assets and a decrease in the income tax expense for the period in which the release is recorded.

[0001633978-20-000011:notes:346]
As a result of meeting certain capital funding, capital investments and hiring requirements, income from operations in Thailand was exempt from income tax in fiscal 2020 and fiscal 2019. However, the aggregate dollar and per-share effect were not significant in both fiscal years.

[0001633978-20-000011:notes:347]
As of June 27, 2020, the Company had federal and foreign net operating loss carryforwards of $154.6 million and $498.3 million, respectively. These carryforwards will begin to expire in the fiscal years 2022 and 2025, respectively. The federal and foreign tax attributes carried forward are subject to various rules which impose limitations on the utilization.

[0001633978-20-000011:notes:348]
Additionally, the Company has federal, state, and foreign research and other tax credit carryforwards of $15.6 million, $39.3 million, and $43.8 million, respectively. The federal credits will begin to expire in the fiscal year ending 2033 and California credits can be carried forward indefinitely. The foreign tax credits began to expire in the fiscal year ending 2022.

[0001633978-20-000011:notes:349]
The Tax Act generally provides greater flexibility for us to access and utilize our cash held by certain of our foreign subsidiaries and we intend to repatriate all or some of the earnings of our subsidiaries in the Cayman Islands, Japan, and Hong Kong. As to all other foreign subsidiaries, we intend to reinvest these earnings indefinitely outside of the U.S. As a result, U.S. income and foreign withholding taxes associated with the repatriation of $20.2 million of undistributed earnings of foreign subsidiaries, other than the Cayman Islands, Japan, and Hong Kong subsidiaries, have not been provided for. We estimate that an additional $1.8 million of foreign withholding taxes would have to be provided if these earnings were repatriated back to the U.S. and such withholding taxes may be available as foreign tax credit or deduction to reduce U.S. tax liability.

[0001633978-20-000011:notes:350]
The aggregate changes in the balance of our unrecognized tax benefits between June 30, 2018 and June 27, 2020 are as follows (in millions):

[0001633978-20-000011:notes:351]
| Balance at June 30, 2018 | $ | 25.8 |  |
| Additions based on the tax positions related to the prior year | 3.7 |  |
| Decreases related to settlement with Tax Authorities | (0.7 | ) |
| Additions based on tax positions related to current year | 29.2 |  |
| Balance at June 29, 2019 | $ | 58.0 |  |
| Decreases based on the tax positions related to the prior year | (8.2 | ) |
| Decreases related to settlement with Tax Authorities | (2.0 | ) |
| Additions based on tax positions related to current year | 7.7 |  |
| Balance at June 27, 2020 | $ | 55.5 |  |

[0001633978-20-000011:notes:352]
As of June 27, 2020, we had $26.8 million of unrecognized tax benefits, which, if recognized, would affect the effective tax rate. We are subject to examination of income tax returns by various domestic and foreign tax authorities. The timing of resolutions and closures of tax audits is highly unpredictable. Although it is possible that certain tax audits may be concluded within the next 12 months, we cannot reasonably estimate the impact to tax expense and net income from tax exams that could be resolved or closed within next 12 months. However, we believe that we have adequately provided under GAAP for potential audit outcomes. Subject to audit timing and uncertainty, we expect the amount of unrecognized tax benefit that would become recognized due to expiration of the statute of limitations and affect the effective tax rate to be $9.8 million over the next 12 months.

[0001633978-20-000011:notes:353]
Our policy is to recognize accrued interest and penalties related to unrecognized tax benefits within the income tax provision. The amount of interest and penalties accrued as of June 27, 2020 and June 29, 2019 were $1.4 million and $1.0 million, respectively.

[0001633978-20-000011:notes:354]
The major tax jurisdictions where we file tax returns are the U.S. federal government, the state of California, Japan, the United Kingdom, Thailand, China and Canada. As of June 27, 2020, our fiscal 2010 to 2020 tax returns are open to potential examination in one or more jurisdictions. In addition, certain net operating loss and credit carryforwards may extend the ability of the tax authorities to examine our tax returns beyond the regular limits.

[0001633978-20-000011:notes:355]
On June 22, 2020, the U.S. Supreme Court declined a Writ of Certiorari in the case of Altera Corp vs. Commissioner challenging a decision by the Ninth Circuit Court of Appeals (which itself reversed a previous decision of the U.S. Tax Court) holding that the U.S. Treasury Department's regulations requiring the inclusion of stock-based compensation expense in a taxpayer's cost-sharing calculations were valid. Our financial statements have been prepared consistent with this outcome.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001633978-20-000011:notes:356]
Note 17. Equity

[0001633978-20-000011:notes:357]
Description of Lumentum Stock-Based Benefit Plans

[0001633978-20-000011:notes:358]
Equity Incentive Plan

[0001633978-20-000011:notes:359]
As of June 27, 2020, we had 2.2 million shares subject to stock options, restricted stock units, restricted stock awards, and performance stock units issued and outstanding under the 2015 Equity Incentive Plan (the “2015 Plan”).

[0001633978-20-000011:notes:360]
Restricted stock units, restricted stock awards, and performance stock units are performance-based, time-based or a combination of both and are expected to vest over one to four years. The fair value of these grants is based on the closing market

[0001633978-20-000011:notes:361]
price of our common stock on the date of award. The exercise price for stock options is equal to the fair value of the underlying stock at the date of grant. We issue new shares of common stock upon exercise of stock options. Options generally become exercisable over a three-year or four-year period and, if not exercised, expire from five to ten years after the date of grant.

[0001633978-20-000011:notes:362]
As of June 27, 2020, 3.5 million shares of common stock under the 2015 Plan were available for grant.

[0001633978-20-000011:notes:363]
Replacement Awards

[0001633978-20-000011:notes:364]
In connection with the acquisition of Oclaro, we issued equity awards to Oclaro employees, consisting of stock options and restricted stock units (“replacement awards”) in exchange for their Oclaro equity awards. The replacement awards consisted of less than 0.1 million stock options with a weighted average grant date fair value of $34.34, and 1.0 million restricted stock units with a weighted average grant date fair value of $41.80. The terms of these replacement awards are substantially similar to the original Oclaro equity awards. The fair value of the replacement awards for services rendered through December 10, 2018, the acquisition date, was recognized as a component of the merger consideration, with the remaining fair value of the replacement awards related to the post-combination services recorded as stock-based compensation over the remaining vesting period.

[0001633978-20-000011:notes:365]
Restricted Stock Units

[0001633978-20-000011:notes:366]
Restricted stock units (“RSUs”) under the 2015 Plan are grants of shares of our common stock, the vesting of which is based on the requisite service requirement. Generally, our RSUs are subject to forfeiture and are expected to vest over one to four years. For annual refresh grants, RSUs generally vest ratably on an annual, or combination of annual and quarterly, basis over three years.

[0001633978-20-000011:notes:367]
Restricted Stock Awards

[0001633978-20-000011:notes:368]
Restricted stock awards (“RSAs”) under the 2015 Plan are grants of shares of our common stock that are subject to various restrictions, including restrictions on transferability and forfeiture provisions. RSAs usually vest over one to four years, and the shares acquired may not be transferred by the holder until the vesting conditions (if any) are satisfied.

[0001633978-20-000011:notes:369]
Performance Stock Units

[0001633978-20-000011:notes:370]
Performance stock units (“PSUs”) under the 2015 Plan are grants of shares of our common stock that vest upon the achievement of certain performance and service conditions. We begin recognizing compensation expense when we conclude that it is probable that the performance conditions will be achieved. We reassess the probability of vesting at each reporting period and adjust our compensation cost based on this probability assessment. Our PSUs are subject to risk of forfeiture until performance and service conditions are satisfied and generally vest over three years.

[0001633978-20-000011:notes:371]
Employee Stock Purchase Plan

[0001633978-20-000011:notes:372]
Our 2015 Employee Stock Purchase Plan (the “2015 Purchase Plan”)  provides eligible employees with the opportunity to acquire an ownership interest in the Company through periodic payroll deductions and provides a 15% purchase price discount as well as a six-month look-back period. The 2015 Purchase Plan is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986. The 2015 Purchase Plan will terminate upon the date on which all shares available for issuance have been sold. Of the 3.0 million shares authorized under the 2015 Purchase Plan, 1.8 million shares remained available for issuance as of June 27, 2020.

[0001633978-20-000011:notes:373]
Stock-Based Compensation

[0001633978-20-000011:notes:374]
The impact on our results of operations of recording stock-based compensation by function during the periods presented was as follows (in millions):

[0001633978-20-000011:notes:375]
|  | Years Ended |
|  | June 27, 2020 |  | June 29, 2019 |  | June 30, 2018 |
| Cost of sales | $ | 16.1 |  |  | $ | 15.1 |  |  | $ | 12.6 |  |
| Research and development | 15.9 |  |  | 13.8 |  |  | 14.2 |  |
| Selling, general and administrative | 41.2 |  |  | 41.8 |  |  | 20.0 |  |
|  | $ | 73.2 |  |  | $ | 70.7 |  |  | $ | 46.8 |  |

[0001633978-20-000011:notes:376]
Total income tax benefit associated with stock-based compensation recognized in our consolidated statements of operations during the years presented was as follows (in millions):

[0001633978-20-000011:notes:377]
|  | Years Ended |
|  | June 27, 2020 |  | June 29, 2019 |  | June 30, 2018 |
| Income tax benefit associated with stock-based compensation | $ | 10.6 |  |  | $ | 8.9 |  |  | $ | 16.6 |  |

[0001633978-20-000011:notes:378]
Approximately $3.6 million and $3.5 million of stock-based compensation was capitalized to inventory as of June 27, 2020 and June 29, 2019, respectively.

[0001633978-20-000011:notes:379]
In fiscal 2019, in connection with the acquisition of Oclaro, we accelerated certain equity awards for Oclaro employees. The total stock-based compensation expense associated with the acceleration of equity awards was $15.2 million, out of which $10.0 million was settled in cash in our second quarter of fiscal 2019. Refer to “Note 4. Business Combinations.”

[0001633978-20-000011:notes:380]
Stock Option and Stock Award Activity

[0001633978-20-000011:notes:381]
We did not grant any stock options during fiscal 2020, 2019, or 2018, other than those assumed in connection with the Oclaro merger. As of June 27, 2020, there were less than 0.05 million stock options outstanding under the 2015 Plan, all of which were replacement awards issued in connection with the Oclaro acquisition.

[0001633978-20-000011:notes:382]
The following table summarizes our awards activity in fiscal 2020, 2019, and 2018 (in millions, except per share amounts):

[0001633978-20-000011:notes:383]
|  | Restricted Stock Units |  | Restricted Stock Awards |  | Performance Stock Units |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance as of July 1, 2017 | 1.9 |  |  | $ | 27.9 |  |  | 0.3 |  |  | $ | 32.5 |  |  | — |  |  | $ | — |  |
| Granted | 1.1 |  |  | 54.5 |  |  | — |  |  | — |  |  | 0.1 |  |  | 52.0 |  |
| Vested/Exercised | (1.1 | ) |  | 26.6 |  |  | (0.2 | ) |  | 32.5 |  |  | — |  |  | — |  |
| Canceled | (0.2 | ) |  | 38.8 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Balance as of June 30, 2018 | 1.7 |  |  | $ | 43.1 |  |  | 0.1 |  |  | $ | 32.5 |  |  | 0.1 |  |  | $ | 52.0 |  |
| Assumed in Oclaro merger | 1.0 |  |  | 41.8 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Granted | 1.0 |  |  | 60.3 |  |  | — |  |  | — |  |  | 0.2 |  |  | 55.9 |  |
| Vested/Exercised | (1.0 | ) |  | 41.5 |  |  | (0.1 | ) |  | 32.5 |  |  | (0.1 | ) |  | 49.0 |  |
| Canceled | (0.5 | ) |  | 50.2 |  |  | — |  |  | 32.8 |  |  | — |  |  | 53.8 |  |
| Balance as of June 29, 2019 | 2.2 |  |  | $ | 52.4 |  |  | — |  |  | $ | 32.5 |  |  | 0.2 |  |  | $ | 56.0 |  |
| Granted | 1.1 |  |  | 60.3 |  |  | — |  |  | — |  |  | 0.2 |  |  | 61.9 |  |
| Vested/Exercised | (1.2 | ) |  | 52.1 |  |  | — |  |  | 32.4 |  |  | (0.1 | ) |  | 54.7 |  |
| Canceled | (0.2 | ) |  | 52.3 |  |  | — |  |  | — |  |  | — |  |  | 57.3 |  |
| Balance as of June 27, 2020 | 1.9 |  |  | $ | 56.6 |  |  | — |  |  | $ | — |  |  | 0.3 |  |  | $ | 60.6 |  |

[0001633978-20-000011:notes:384]
As of June 27, 2020, $98.0 million of stock-based compensation cost related to awards granted to our employees remains to be amortized. That cost is expected to be recognized over an estimated amortization period of 1.8 years.

[0001633978-20-000011:notes:385]
A summary of awards available for grant is as follows (in millions):

[0001633978-20-000011:notes:386]
|  | Awards Available for Grant |
| Balance as of July 1, 2017 | 6.6 |  |
| Granted | (1.2 | ) |
| Canceled | 0.2 |  |
| Balance as of June 30, 2018 | 5.6 |  |
| Granted | (1.2 | ) |
| Canceled | 0.3 |  |
| Balance as of June 29, 2019 | 4.7 |  |
| Granted | (1.3 | ) |
| Canceled | 0.1 |  |
| Balance as of June 27, 2020 | 3.5 |  |

[0001633978-20-000011:notes:387]
Employee Stock Purchase Plan Activity

[0001633978-20-000011:notes:388]
The 2015 Purchase Plan expense for fiscal 2020, 2019 and 2018 were $3.5 million, $3.6 million, and $3.3 million, respectively. The expense related to the 2015 Purchase Plan is recorded on a straight-line basis over the relevant subscription period. During fiscal 2020, 2019, and 2018, there were 0.2 million, 0.3 million, and 0.2 million shares issued to employees through the 2015 Purchase Plan.

[0001633978-20-000011:notes:389]
We estimate the fair value of the 2015 Purchase Plan shares on the date of grant using the Black-Scholes option-pricing model. The assumptions used to estimate the fair value of the 2015 Purchase Plan shares during the periods presented were as follows:

[0001633978-20-000011:notes:390]
|  | June 27, 2020 |  | June 29, 2019 |
| Expected term (years) | 0.5 |  |  | 0.5 |  |
| Expected volatility | 56.0 | % |  | 60.1 | % |
| Risk-free interest rate | 0.87 | % |  | 2.47 | % |
| Dividend yield | — | % |  | — | % |

[0001633978-20-000011:notes:391]
Repurchase and Retirement of Common Stock

[0001633978-20-000011:notes:392]
In December 2019, concurrently with the issuance of the 2026 Notes, we repurchased 2.9 million shares of our common stock in privately negotiated transactions at an average price of $69.68 per share for an aggregate purchase price of $200 million. These shares were retired immediately.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001633978-20-000011:notes:393]
Note 18. Employee Retirement Plans

[0001633978-20-000011:notes:394]
Defined Contribution Plans

[0001633978-20-000011:notes:395]
In the United States, the Company sponsors the Lumentum 401(k) Retirement Plan (the “401(k) Plan”), a defined contribution plan under ERISA, which provides retirement benefits for its eligible employees through tax deferred salary deductions. The 401(k) Plan allows employees to contribute up to 50% of their annual compensation, with contributions limited to $19,500 in calendar year 2020 as set by the Internal Revenue Service. Employees are eligible for matching contributions after completing 180 days of service. The Company’s match is contributed on a per-pay-period basis and is based on employees’ before-tax contributions and compensation each pay period. All matching contributions are made in cash and vest immediately under the 401(k) Plan. In fiscal 2020, 2019, and 2018, our contribution expense to the 401(k) Plan was $3.8 million, $3.7 million, and $3.4 million, respectively.

[0001633978-20-000011:notes:396]
We also have defined contribution plans outside of the United States, almost in every country we operate in, either as required by statutory law or as provided by the Company’s supplemental offering. Our contribution expense to all defined contribution plans outside the United States were $6.7 million, $4.8 million, and $2.9 million for fiscal years 2020, 2019, and 2018, respectively.

[0001633978-20-000011:notes:397]
Defined Benefit Plans

[0001633978-20-000011:notes:398]
The Company sponsors defined benefit pension plans covering employees in Japan, Switzerland, and Thailand. Pension plan benefits are based primarily on participants’ compensation and years of service credited as specified under the terms of each country’s plan. Employees are entitled to a lump sum benefit upon retirement or upon certain instances of termination.  The funding policy is consistent with the local requirements of each country.

[0001633978-20-000011:notes:399]
We account for our defined benefit obligations in accordance with the authoritative guidance which requires us to record our obligation to the participants, as well as the corresponding net periodic cost. We determine our obligation to the participants and our net periodic cost principally using actuarial valuations provided by third-party actuaries. As of June 27, 2020, our projected benefit obligations, net in Japan, Switzerland, and Thailand were $2.9 million, $6.4 million, and $2.5 million, respectively. They were recorded in our consolidated balance sheets as other non-current liabilities and represent the total projected benefit obligation (“PBO”) less the fair value of plan assets.

[0001633978-20-000011:notes:400]
As of June 27, 2020, the defined benefit plan in Switzerland was partially funded, while the defined benefit plans in Japan and Thailand were unfunded.

[0001633978-20-000011:notes:401]
The change in the benefit obligations of pension plans in Japan, Switzerland, and Thailand, and the change in plan assets in Switzerland were as follows (in millions):

[0001633978-20-000011:notes:402]
|  | 2020 |  | 2019 |
| Change in projected benefit obligation: |  |  |  |
| Benefit obligation at beginning of year | $ | 16.1 |  |  | $ | 12.1 |  |
| Assumed pension liability in Japan in connection with Oclaro acquisition | — |  |  | 7.2 |  |
| Service cost | 3.5 |  |  | 1.2 |  |
| Interest cost | 0.2 |  |  | 0.1 |  |
| Plan participants’ contributions | 0.5 |  |  | 0.5 |  |
| Actuarial (gains) losses | 0.9 |  |  | 1.2 |  |
| Benefits paid | (0.7 | ) |  | (1.1 | ) |
| Transfer of benefit obligation in connection with disposition | — |  |  | (4.9 | ) |
| Plan amendments | — |  |  | (0.6 | ) |
| Foreign exchange impact | 0.4 |  |  | 0.4 |  |
| Benefit obligation at end of year | $ | 20.9 |  |  | $ | 16.1 |  |
| Change in plan assets: |  |  |  |
| Fair value of plan assets at beginning of year | $ | 8.3 |  |  | $ | 8.6 |  |
| Actual return on plan assets | — |  |  | (0.3 | ) |
| Employer contribution | 0.6 |  |  | 0.4 |  |
| Plan participants’ contribution | 0.6 |  |  | 0.4 |  |
| Benefits paid | (0.7 | ) |  | (1.0 | ) |
| Foreign exchange impact | 0.3 |  |  | 0.2 |  |
| Fair value of plan assets at end of year | $ | 9.1 |  |  | $ | 8.3 |  |
| Funded status (1) | $ | (11.8 | ) |  | $ | (7.8 | ) |
| Changes in benefit obligations and plan assets recognized in other comprehensive (income) loss: |  |  |  |
| Prior service cost | $ | — |  |  | $ | (0.6 | ) |
| Amortization of accumulated net actuarial gain (loss) | (0.3 | ) |  | (0.1 | ) |
| Net actuarial (gain) loss | 1.2 |  |  | 2.1 |  |
|  | $ | 0.9 |  |  | $ | 1.4 |  |
| Accumulated benefit obligation | $ | 17.8 |  |  | $ | 14.4 |  |

[0001633978-20-000011:notes:403]
(1) As of June 27, 2020 and June 29, 2019, $11.8 million and $7.8 million were recorded in other non-current liabilities on our consolidated balance sheets to account for the PBO. Refer to “Note 8. Balance Sheet Details” in the Notes to Consolidated Financial Statements.

[0001633978-20-000011:notes:404]
Net periodic pension costs in Japan, Switzerland, and Thailand include the following components for the periods presented:

[0001633978-20-000011:notes:405]
|  | 2020 |  | 2019 |  | 2018 |
| Service cost | $ | 3.5 |  |  | $ | 1.2 |  |  | $ | 0.9 |  |
| Interest cost | 0.2 |  |  | 0.1 |  |  | 0.1 |  |
| Expected return on plan assets | (0.3 | ) |  | (0.3 | ) |  | (0.2 | ) |
| Amortization of net loss | 0.3 |  |  | 0.1 |  |  | 0.2 |  |
| Net periodic pension cost | $ | 3.7 |  |  | $ | 1.1 |  |  | $ | 1.0 |  |

[0001633978-20-000011:notes:406]
Assumptions

[0001633978-20-000011:notes:407]
Underlying both the calculation of the PBO and net periodic cost are actuarial valuations. These valuations use participant-specific information such as salary, age and assumptions about interest rates, compensation increases and other factors. At a minimum, we evaluate these assumptions annually and make changes as necessary.

[0001633978-20-000011:notes:408]
The discount rate reflects the estimated rate at which the pension benefits could be effectively settled. In developing the discount rate, we consider the yield available on an appropriate AA or AAA corporate bond index, adjusted to reflect the term of the plan’s liabilities.

[0001633978-20-000011:notes:409]
The expected return on assets was estimated by using the weighted average of the real expected long-term return (net of inflation) on the relevant classes of assets based on the target asset mix and adding the chosen inflation assumption.

[0001633978-20-000011:notes:410]
The following table summarizes the weighted-average assumptions used to determine net periodic cost and benefit obligation for our defined benefit plans in Japan, Switzerland, and Thailand:

[0001633978-20-000011:notes:411]
|  | Defined Benefit Plans |
|  | 2020 |  | 2019 |
| Assumptions used to determine net periodic cost: |  |  |  |
| Discount rate | 0.8 | % |  | 0.4 | % |
| Expected long-term return on plan assets | 3.2 | % |  | 3.2 | % |
| Salary increase rate | 4.1 | % |  | 2.2 | % |
| Assumptions used to determine benefit obligation at end of year: |  |  |  |
| Discount rate | 0.4 | % |  | 0.4 | % |
| Salary increase rate | 2.7 | % |  | 2.2 | % |

[0001633978-20-000011:notes:412]
Fair Value Measurement of Plan Assets

[0001633978-20-000011:notes:413]
The following table sets forth the plan assets of our defined benefit plan in Switzerland at fair value and the percentage of assets allocations as of June 27, 2020 (in millions, except percentage data):

[0001633978-20-000011:notes:414]
|  |  |  |  |  |  | Fair value measurement as of June 27, 2020 |
|  | Target Allocation | Total |  | Percentage of Plan Asset |  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs (Level 2) |
| Assets: |  |  |  |  |  |  |  |  |  |
| Global equity | 29 | % |  | $ | 2.6 |  |  | 28 | % |  | $ | — |  |  | $ | 2.6 |  |
| Fixed income | 33 | % |  | 3.0 |  |  | 30 | % |  | — |  |  | 3.0 |  |
| Alternative investment | 16 | % |  | 1.5 |  |  | 21 | % |  | — |  |  | 1.5 |  |
| Cash | 2 | % |  | 0.2 |  |  | 1 | % |  | 0.2 |  |  | — |  |
| Other assets | 20 | % |  | 1.8 |  |  | 20 | % |  | — |  |  | 1.8 |  |
| Total Assets | 100 | % |  | $ | 9.1 |  |  | 100 | % |  | $ | 0.2 |  |  | $ | 8.9 |  |

[0001633978-20-000011:notes:415]
The following table sets forth the plan’s assets at fair value and the percentage of assets allocations as of June 29, 2019 (in millions, except percentage data):

[0001633978-20-000011:notes:416]
|  |  |  |  |  |  | Fair value measurement as of June 29, 2019 |
|  | Target Allocation | Total |  | Percentage of Plan Asset |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs (Level 2) |
| Assets: |  |  |  |  |  |  |  |  |  |
| Global equity | 28 | % |  | $ | 2.3 |  |  | 28 | % |  | $ | — |  |  | $ | 2.3 |  |
| Fixed income | 30 | % |  | 2.6 |  |  | 31 | % |  | — |  |  | 2.6 |  |
| Alternative investment | 21 | % |  | 1.3 |  |  | 16 | % |  | — |  |  | 1.3 |  |
| Cash | 1 | % |  | 0.3 |  |  | 3 | % |  | 0.3 |  |  | — |  |
| Other assets | 20 | % |  | 1.8 |  |  | 22 | % |  | — |  |  | 1.8 |  |
| Total Assets | 100 | % |  | $ | 8.3 |  |  | 100 | % |  | $ | 0.3 |  |  | $ | 8.0 |  |

[0001633978-20-000011:notes:417]
Our pension assets consist of multiple institutional funds (“pension funds”) of which the fair values are based on the quoted prices of the underlying funds. Pension funds are classified as Level 2 assets since such funds are not directly traded in active markets. Global equity consists of several funds that invest primarily in Swiss and foreign equities; fixed income consists of several funds that invest primarily in investment grade domestic and overseas bonds; other assets consist of several funds that primarily invest in hedge fund, private equity, global real estate and infrastructure funds.

[0001633978-20-000011:notes:418]
Future Benefit Payments

[0001633978-20-000011:notes:419]
We estimate our expected benefit payments to defined benefit pension plans’ participants based on the same assumptions used to measure our PBO at year-end which includes benefits attributable to estimated future compensation increases.

[0001633978-20-000011:notes:420]
The following benefit payments are estimated to be paid from our defined benefit pension plans:

[0001633978-20-000011:notes:421]
| Fiscal Years |  | Total |
| 2021 |  | $ | 1.1 |  |
| 2022 |  | 0.5 |  |
| 2023 |  | 0.7 |  |
| 2024 |  | 0.6 |  |
| 2025 |  | 0.8 |  |
| Next five years |  | 4.6 |  |

[0001633978-20-000011:notes:422]
We expect to contribute $0.5 million to our defined benefit pension plans in fiscal 2021.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001633978-20-000011:notes:423]
Note 19. Commitments and Contingencies

[0001633978-20-000011:notes:424]
Purchase Obligations

[0001633978-20-000011:notes:425]
Purchase obligations of $261.5 million as of June 27, 2020, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements.

[0001633978-20-000011:notes:426]
Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001633978-20-000011:notes:427]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with such vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

[0001633978-20-000011:notes:428]
Product Warranties

[0001633978-20-000011:notes:429]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, product components or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001633978-20-000011:notes:430]
The following table presents the changes in our warranty reserve during the periods presented (in millions):

[0001633978-20-000011:notes:431]
|  | Years Ended |
|  | June 27, 2020 |  | June 29, 2019 |
| Balance as of beginning of period | $ | 7.5 |  |  | $ | 6.6 |  |
| Warranties assumed in Oclaro acquisition | — |  |  | 1.8 |  |
| Provision for warranty | 2.9 |  |  | 5.9 |  |
| Utilization of reserve | (5.4 | ) |  | (6.8 | ) |
| Balance as of end of period | $ | 5.0 |  |  | $ | 7.5 |  |

[0001633978-20-000011:notes:432]
Environmental Liabilities

[0001633978-20-000011:notes:433]
Our research and development (“R&D”), manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental, product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001633978-20-000011:notes:434]
Legal Proceedings

[0001633978-20-000011:notes:435]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties

[0001633978-20-000011:notes:436]
and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss.

[0001633978-20-000011:notes:437]
Merger Litigation

[0001633978-20-000011:notes:438]
In connection with our acquisition of Oclaro, seven lawsuits were filed by purported stockholders of Oclaro challenging the proposed merger (the “Merger”). Two of the seven suits were putative class actions filed against Oclaro, its directors, Lumentum, Prota Merger Sub, Inc. and Prota Merger, LLC: Nicholas Neinast v. Oclaro, Inc., et al., No. 3:18-cv-03112-VC, in the United States District Court for the Northern District of California (filed May 24, 2018) (the “Neinast Lawsuit”); and Adam Franchi v. Oclaro, Inc., et al., No. 1:18-cv-00817-GMS, in the United States District Court for the District of Delaware (filed June 9, 2018) (the “Franchi Lawsuit). Both the Neinast Lawsuit and the Franchi Lawsuit were voluntarily dismissed with prejudice.

[0001633978-20-000011:notes:439]
The other five suits, styled as Gerald F. Wordehoff v. Oclaro, Inc., et al., No. 5:18-cv-03148-NC (the “Wordehoff Lawsuit”), Walter Ryan v. Oclaro, Inc., et al., No. 3:18-cv-03174-VC (the “Ryan Lawsuit”), Jayme Walker v. Oclaro, Inc., et al., No. 5:18-cv-03203-EJD (the “Walker Lawsuit”), Kevin Garcia v. Oclaro, Inc., et al., No. 5:18-cv-03262-VKD (the “Garcia Lawsuit”), and SaiSravan B. Karri v. Oclaro, Inc., et al., No. 3:18-cv-03435-JD (the “Karri Lawsuit” and, together with the other six lawsuits, the “Lawsuits”), were filed in the United States District Court for the Northern District of California on May 25, 2018, May 29, 2018, May 30, 2018, May 31, 2018, and June 9, 2018, respectively. These five Lawsuits named Oclaro and its directors as defendants only and did not name Lumentum. The Wordehoff, Ryan, Walker, and Garcia Lawsuits have been voluntarily dismissed, and the Wordehoff, Ryan, and Walker dismissals were with prejudice. The Karri Lawsuit has not yet been dismissed. The Ryan Lawsuit was, and the Karri Lawsuit is, a putative class action.

[0001633978-20-000011:notes:440]
The Lawsuits generally alleged, among other things, that Oclaro and its directors violated Section 14(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), and Rule 14a-9 promulgated thereunder by disseminating an incomplete and misleading Form S-4, including proxy statement/prospectus. The Lawsuits further alleged that Oclaro’s directors violated Section 20(a) of the Exchange Act by failing to exercise proper control over the person(s) who violated Section 14(a) of the Exchange Act.

[0001633978-20-000011:notes:441]
The remaining Lawsuit (the Karri Lawsuit) currently purports to seek, among other things, damages to be awarded to the plaintiff and any class, if a class is certified, and litigation costs, including attorneys’ fees.  A lead plaintiff and counsel has been selected, and an amended complaint was filed on April 15, 2019, which also names Lumentum as a defendant.  A motion to dismiss the amended complaint has been fully briefed and is currently pending, and defendants intend to defend the Karri Lawsuit vigorously.

[0001633978-20-000011:notes:442]
Indemnifications

[0001633978-20-000011:notes:443]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of June 27, 2020, we did not have any material indemnification claims that were probable or reasonably possible.

[0001633978-20-000011:notes:444]
Audit Proceedings

[0001633978-20-000011:notes:445]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.
In connection with our acquisition of Oclaro, in fiscal 2019, we recorded $1.1 million in Malaysia Goods and Services Tax (“GST”) refund claims within prepaid expenses and other current assets in our consolidated balance sheet. The refund claim represented an initial claim of $2.5 million of GST, net of reserves, that was previously denied by the Malaysian tax authorities in 2016. During the year ended June 27, 2020, we were able to favorably resolve this audit and received refunds for all of our outstanding GST claims.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001633978-20-000011:notes:446]
Note 20. Operating Segments and Geographic Information

[0001633978-20-000011:notes:447]
Our chief executive officer is our Chief Operating Decision Maker (“CODM”). The CODM allocates resources to the segments based on their business prospects, competitive factors, net revenue and gross margin. We do not track all of our property, plant and equipment by operating segments. The geographic identification of these assets is set forth below.

[0001633978-20-000011:notes:448]
We are an industry leading provider of optical and photonic products defined by revenue and market share addressing a range of end-market applications including optical communications and commercial lasers. We have two operating segments, Optical Communications, which we refer to as OpComms, and Commercial Lasers, which we refer to as Lasers. Our OpComms products address the following markets: telecommunications and data communications (“Telecom and Datacom”), and consumer and industrial (“Consumer and Industrial”), and include product lines from the acquisition of Oclaro. The two operating segments were primarily determined based on how the CODM views and evaluates our operations. Operating results are regularly reviewed by the CODM to make decisions about resources to be allocated to the segments and to assess their performance. Other factors, including market separation and customer specific applications, go-to-market channels, products and manufacturing, are considered in determining the formation of these operating segments.

[0001633978-20-000011:notes:449]
OpComms

[0001633978-20-000011:notes:450]
Our OpComms products address the following markets: Telecom, Datacom and Consumer and Industrial.

[0001633978-20-000011:notes:451]
Our OpComms products include a wide range of components, modules and subsystems to support customers including carrier networks for access (local), metro (intracity), long-haul (city-to-city and worldwide) and submarine (undersea) applications. Additionally, our products address enterprise, cloud, and data center applications, including storage-access networks (“SANs”),

[0001633978-20-000011:notes:452]
local-area networks (“LANs”) and wide-area networks (“WANs”). These products enable the transmission and transport of video, audio and data over high-capacity fiber-optic cables. We maintain leading positions in these fast growing OpComms markets through our extensive product portfolio, including reconfigurable optical add/drop multiplexers (“ROADMs”), coherent DWDM pluggable transceivers, and tunable small form-factor pluggable transceivers. We also sell laser chips for use in the manufacture of high-speed Datacom transceivers.

[0001633978-20-000011:notes:453]
In the Consumer and Industrial market, our OpComms products include laser light sources, which are integrated into 3D sensing platforms being used in applications for mobile devices, gaming, payment kiosks, computers, and other consumer electronics devices. New emerging applications include virtual and augmented reality, as well as automotive and industrial segments. Our products include vertical cavity surface emitting lasers (“VCSELs”) and edge emitting lasers which are used in 3D sensing depth imaging systems. These systems simplify the way people interact with technology by enabling the use of natural user interfaces. Systems are used for biometric identification, surveillance, and process efficiency, among numerous other application spaces. Emerging applications for this technology include various mobile device applications, autonomous vehicles, self-navigating robotics and drones in industrial applications and 3D capture of objects coupled with 3D printing. In addition, our industrial diode lasers are used primarily as pump sources for pulsed and kilowatt class fiber lasers.

[0001633978-20-000011:notes:454]
Lasers

[0001633978-20-000011:notes:455]
Our Lasers products serve our customers in markets and applications such as sheet metal processing, general manufacturing, biotechnology, graphics and imaging, remote sensing, and precision machining such as drilling in printed circuit boards, wafer singulation, glass cutting and solar cell scribing.

[0001633978-20-000011:notes:456]
Our Lasers products are used in a variety of OEM applications including diode-pumped solid-state, fiber, diode, direct-diode and gas lasers such as argon-ion and helium-neon lasers. Fiber lasers provide kW-class output powers combined with excellent beam quality and are used in sheet metal processing and metal welding applications. Diode-pumped solid-state lasers provide excellent beam quality, low noise and exceptional reliability and are used in biotechnology, graphics and imaging, remote sensing, materials processing and precision machining applications. Diode and direct-diode lasers address a wide variety of applications, including laser pumping, thermal exposure, illumination, ophthalmology, image recording, printing, plastic welding and selective soldering. Gas lasers such as argon-ion and helium-neon lasers provide a stable, low-cost and reliable solution over a wide range of operating conditions, making them well-suited for complex, high-resolution OEM applications such as flow cytometry, DNA sequencing, graphics and imaging and semiconductor inspection.

[0001633978-20-000011:notes:457]
We also provide high-powered and ultrafast lasers for the industrial and scientific markets. Manufacturers use high-power, ultrafast lasers to create micro parts for consumer electronics and to process semiconductor, LED, and other types of chips. Use of ultrafast lasers for micromachining applications is being driven primarily by the increasing use of consumer electronics and connected devices globally.

[0001633978-20-000011:notes:458]
We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments because management does not include the information in its measurement of the performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, stock-based compensation and certain other charges impacting the gross margin of each segment because management does not include this information in its measurement of the performance of the operating segments.

[0001633978-20-000011:notes:459]
Information on reportable segments utilized by our CODM is as follows (in millions):

[0001633978-20-000011:notes:460]
|  | Years Ended |
|  | June 27, 2020 |  | June 29, 2019 |  | June 30, 2018 |
| Net revenue: |  |  |  |  |  |
| OpComms | $ | 1,515.1 |  |  | $ | 1,370.2 |  |  | $ | 1,059.2 |  |
| Lasers | 163.5 |  |  | 195.1 |  |  | 188.5 |  |
| Net revenue | $ | 1,678.6 |  |  | $ | 1,565.3 |  |  | $ | 1,247.7 |  |
| Gross profit: |  |  |  |  |  |
| OpComms | $ | 704.0 |  |  | $ | 534.1 |  |  | $ | 402.3 |  |
| Lasers | 76.2 |  |  | 84.4 |  |  | 82.8 |  |
| Total segment gross profit | 780.2 |  |  | 618.5 |  |  | 485.1 |  |
| Unallocated corporate items: |  |  |  |  |  |
| Stock-based compensation | (16.1 | ) |  | (15.1 | ) |  | (12.6 | ) |
| Amortization of acquired intangibles | (53.8 | ) |  | (46.6 | ) |  | (3.2 | ) |
| Amortization of fair value adjustments | (5.8 | ) |  | (54.6 | ) |  | — |  |
| Inventory and fixed asset write down due to product lines exit (1) | (7.0 | ) |  | (20.8 | ) |  | — |  |
| Integration related costs | (4.9 | ) |  | (6.6 | ) |  | — |  |
| Expenses related to COVID-19 outbreak | (6.6 | ) |  | — |  |  | — |  |
| Other charges (2) | (35.8 | ) |  | (48.9 | ) |  | (37.2 | ) |
| Gross profit | $ | 650.2 |  |  | $ | 425.9 |  |  | $ | 432.1 |  |

[0001633978-20-000011:notes:461]
(1) In fiscal 2020 and 2019, we recorded inventory and fixed assets write down charges of $7.0 million and $20.8 million related to the decision to exit the Datacom module and Lithium Niobate product lines.

[0001633978-20-000011:notes:462]
(2) “Other charges” of unallocated corporate items for the year ended June 27, 2020 primarily include costs of transferring product lines to new production facilities, including Thailand of $11.5 million. We also incurred excess and obsolete inventory charges of $12.8 million driven by the decline in demand from Huawei during the year ended June 27, 2020. In addition, for the year ended June 27, 2020, we incurred $6.2 million impairment charges associated with excess capacity related to our Fiber laser business. Other charges for the years ended June 29, 2019 and June 30, 2018, primarily include costs of transferring product lines to Thailand of $45.8 million and $27.0 million, respectively.

[0001633978-20-000011:notes:463]
In addition, we recorded net expenses of $6.6 million related to COVID-19 outbreak during the year ended June 27, 2020, which include incremental costs for payroll expense such as overtime pay, pay for employees who are not working, facilities costs such as gloves, masks and temperature gauges, and under-utilized capacity at certain facilities, in which manufacturing output was impacted. These COVID-19 related costs are offset by benefits realized from government credits for employers’ payroll tax.

[0001633978-20-000011:notes:464]
We disaggregate revenue by product and by geography. We do not present other levels of disaggregation, such as by type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, as this information is not used by our CODM to manage the business.

[0001633978-20-000011:notes:465]
The table below discloses our total net revenue attributable to each of our two reportable segments. In addition, it discloses the percentage of our total net revenue attributable to our product offerings which serve Telecom and Datacom, and Consumer and Industrial markets which accounted for 10% or more of our total net revenue during the periods presented (in millions, except percentage data):

[0001633978-20-000011:notes:466]
|  | Years Ended |
|  | June 27, 2020 |  | June 29, 2019 |  | June 30, 2018 |
| OpComms: |  |  |  |  |  |  |  |  |
| Telecom and Datacom | $ | 1,021.8 |  | 60.9 | % |  | $ | 952.9 |  | 60.8 | % |  | $ | 626.7 |  | 50.2 | % |
| Consumer and Industrial | 493.3 |  | 29.4 | % |  | 417.3 |  | 26.7 | % |  | 432.5 |  | 34.7 | % |
| Total OpComms | $ | 1,515.1 |  | 90.3 | % |  | $ | 1,370.2 |  | 87.5 | % |  | $ | 1,059.2 |  | 84.9 | % |
| Lasers | 163.5 |  | 9.7 | % |  | 195.1 |  | 12.5 | % |  | 188.5 |  | 15.1 | % |
| Total Revenue | $ | 1,678.6 |  |  |  | $ | 1,565.3 |  |  |  | $ | 1,247.7 |  |  |

[0001633978-20-000011:notes:467]
We operate in three geographic regions: Americas, Asia-Pacific, and EMEA (Europe, Middle East, and Africa). Net revenue is assigned to the geographic region and country where our product is initially shipped. For example, certain customers may request shipment of our product to a contract manufacturer in one country, which may differ from the location of their end customers. The following table presents net revenue by the three geographic regions we operate in and net revenue from countries that represented 10% or more of our total net revenue (in millions, except percentage data):

[0001633978-20-000011:notes:468]
|  | Years Ended |
|  | June 27, 2020 |  | June 29, 2019 |  | June 30, 2018 |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 149.8 |  |  | 8.9 | % |  | $ | 100.9 |  |  | 6.4 | % |  | $ | 115.1 |  |  | 9.2 | % |
| Mexico | 122.8 |  |  | 7.3 |  |  | 214.9 |  |  | 13.7 |  |  | 145.8 |  |  | 11.7 |  |
| Other Americas | 5.5 |  |  | 0.3 |  |  | 4.3 |  |  | 0.3 |  |  | 7.0 |  |  | 0.6 |  |
| Total Americas | $ | 278.1 |  |  | 16.5 | % |  | $ | 320.1 |  |  | 20.4 | % |  | $ | 267.9 |  |  | 21.5 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 532.0 |  |  | 31.8 | % |  | $ | 387.9 |  |  | 24.8 | % |  | $ | 183.0 |  |  | 14.7 | % |
| South Korea | 260.9 |  |  | 15.5 |  |  | 162.4 |  |  | 10.4 |  |  | 146.1 |  |  | 11.7 |  |
| Japan | 137.9 |  |  | 8.2 |  |  | 176.0 |  |  | 11.2 |  |  | 194.7 |  |  | 15.6 |  |
| Other Asia-Pacific | 346.0 |  |  | 20.6 |  |  | 356.1 |  |  | 22.7 |  |  | 354.2 |  |  | 28.3 |  |
| Total Asia-Pacific | $ | 1,276.8 |  |  | 76.1 | % |  | $ | 1,082.4 |  |  | 69.1 | % |  | $ | 878.0 |  |  | 70.3 | % |
| EMEA | $ | 123.7 |  |  | 7.4 | % |  | $ | 162.8 |  |  | 10.5 | % |  | $ | 101.8 |  |  | 8.2 | % |
| Total net revenue | $ | 1,678.6 |  |  |  |  | $ | 1,565.3 |  |  |  |  | $ | 1,247.7 |  |  |  |

[0001633978-20-000011:notes:469]
During fiscal 2020, 2019 and 2018, net revenue from customers outside the United States, based on customer shipping location, represented 91.1%, 93.6% and 90.8% of net revenue, respectively.

[0001633978-20-000011:notes:470]
During the years ended June 27, 2020, June 29, 2019, and June 30, 2018, net revenue generated from a single customer which represented 10% or greater of total net revenue is summarized as follows:

[0001633978-20-000011:notes:471]
|  | Years Ended |
|  | June 27, 2020 |  | June 29, 2019 |  | June 30, 2018 |
| Customer A | 26.0 | % |  | 21.0 | % |  | 30.0 | % |
| Customer B | 13.2 | % |  | 15.2 | % |  | 11.0 | % |
| Customer C | * |  |  | 13.7 | % |  | 11.0 | % |
| *Represents less than 10% of total net revenue |  |  |  |  |  |

[0001633978-20-000011:notes:472]
Long-lived assets, namely net property, plant and equipment, net, were identified based on the physical location of the assets in the corresponding geographic areas as of the periods indicated (in millions):

[0001633978-20-000011:notes:473]
|  | June 27, 2020 |  | June 29, 2019 |
| Property, Plant and Equipment, net |  |  |  |
| Thailand | $ | 122.6 |  |  | $ | 157.1 |  |
| United States | 139.1 |  |  | 156.2 |  |
| China | 43.2 |  |  | 33.5 |  |
| Japan | 32.3 |  |  | 28.3 |  |
| Other countries | 55.8 |  |  | 58.2 |  |
| Total long-lived assets | $ | 393.0 |  |  | $ | 433.3 |  |

[0001633978-20-000011:notes:474]
We purchase a substantial portion of our inventory from contract manufacturers and vendors located primarily in Taiwan, Thailand, and Malaysia. During fiscal 2020, 2019, and 2018, our total net inventory purchases from contract manufacturers represented approximately 39%, 46%, and 54% of our total cost of sales, respectively. During fiscal 2020, 2019, and 2018, our net inventory purchases which represented 10% or greater of total net purchases, were concentrated with two, three, and three contract manufacturers, respectively.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001633978-20-000011:notes:475]
Note 21. Quarterly Financial Information (Unaudited)

[0001633978-20-000011:notes:476]
The following table presents our quarterly consolidated statements of operations for fiscal 2020 and 2019 (in millions, except per share data):

[0001633978-20-000011:notes:477]
|  | June 27, 2020 |  | March 28, 2020 |  | December 28, 2019 |  | September 28, 2019 |  | June 29, 2019 |  | March 30, 2019 |  | December 29, 2018 |  | September 29, 2018 |
| Net revenue | $ | 368.1 |  |  | $ | 402.8 |  |  | $ | 457.8 |  |  | $ | 449.9 |  |  | $ | 404.6 |  |  | $ | 432.9 |  |  | $ | 373.7 |  |  | $ | 354.1 |  |
| Cost of sales | 217.4 |  |  | 231.2 |  |  | 256.3 |  |  | 269.7 |  |  | 304.6 |  |  | 316.5 |  |  | 244.5 |  |  | 227.3 |  |
| Amortization of acquired developed intangibles | 15.0 |  |  | 13.9 |  |  | 12.4 |  |  | 12.5 |  |  | 13.2 |  |  | 28.1 |  |  | 4.4 |  |  | 0.8 |  |
| Gross profit | 135.7 |  |  | 157.7 |  |  | 189.1 |  |  | 167.7 |  |  | 86.8 |  |  | 88.3 |  |  | 124.8 |  |  | 126.0 |  |

[0001633978-20-000011:notes:478]
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 49.0 |  |  | 48.7 |  |  | 51.0 |  |  | 49.9 |  |  | 49.5 |  |  | 57.7 |  |  | 42.8 |  |  | 34.6 |  |
| Selling, general and administrative | 54.8 |  |  | 61.3 |  |  | 62.4 |  |  | 56.7 |  |  | 49.4 |  |  | 55.2 |  |  | 62.7 |  |  | 33.0 |  |
| Restructuring and related charges | 3.1 |  |  | 2.7 |  |  | 0.9 |  |  | 1.3 |  |  | 1.7 |  |  | 21.1 |  |  | 7.8 |  |  | 1.3 |  |
| Impairment charges | 1.8 |  |  | 2.5 |  |  | — |  |  | — |  |  | — |  |  | 30.7 |  |  | — |  |  | — |  |
| Total operating expenses | 108.7 |  |  | 115.2 |  |  | 114.3 |  |  | 107.9 |  |  | 100.6 |  |  | 164.7 |  |  | 113.3 |  |  | 68.9 |  |
| Income (loss) from operations | 27.0 |  |  | 42.5 |  |  | 74.8 |  |  | 59.8 |  |  | (13.8 | ) |  | (76.4 | ) |  | 11.5 |  |  | 57.1 |  |
| Unrealized gain (loss) on derivative liability | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 10.9 |  |  | (2.1 | ) |
| Interest expense | (15.9 | ) |  | (15.6 | ) |  | (18.3 | ) |  | (11.4 | ) |  | (11.4 | ) |  | (11.3 | ) |  | (8.5 | ) |  | (5.1 | ) |
| Other income (expense), net | 3.5 |  |  | 21.7 |  |  | 1.2 |  |  | 5.0 |  |  | 4.1 |  |  | 5.2 |  |  | 3.8 |  |  | 2.7 |  |
| Income (loss) before income taxes | 14.6 |  |  | 48.6 |  |  | 57.7 |  |  | 53.4 |  |  | (21.1 | ) |  | (82.5 | ) |  | 17.7 |  |  | 52.6 |  |
| Provision for (benefit from) income taxes | 19.2 |  |  | 5.2 |  |  | 8.6 |  |  | 5.8 |  |  | 4.7 |  |  | (8.2 | ) |  | 1.4 |  |  | 5.2 |  |
| Net income (loss) | $ | (4.6 | ) |  | $ | 43.4 |  |  | $ | 49.1 |  |  | $ | 47.6 |  |  | $ | (25.8 | ) |  | $ | (74.3 | ) |  | $ | 16.3 |  |  | $ | 47.4 |  |
| Net income (loss) attributable to common stockholders - Basic | $ | (4.6 | ) |  | $ | 43.4 |  |  | $ | 49.1 |  |  | $ | 47.6 |  |  | (25.8 | ) |  | $ | (74.3 | ) |  | $ | 16.1 |  |  | $ | 46.1 |  |
| Net income (loss) attributable to common stockholders - Diluted | $ | (4.6 | ) |  | $ | 43.4 |  |  | $ | 49.1 |  |  | $ | 47.6 |  |  | (25.8 | ) |  | $ | (74.3 | ) |  | $ | 5.4 |  |  | $ | 46.1 |  |
| Net income (loss) per share attributable to common stockholders: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | (0.06 | ) |  | $ | 0.58 |  |  | $ | 0.64 |  |  | $ | 0.62 |  |  | $ | (0.34 | ) |  | $ | (0.98 | ) |  | $ | 0.24 |  |  | $ | 0.73 |  |
| Diluted | $ | (0.06 | ) |  | $ | 0.56 |  |  | $ | 0.63 |  |  | $ | 0.61 |  |  | $ | (0.34 | ) |  | $ | (0.98 | ) |  | $ | 0.08 |  |  | $ | 0.72 |  |
| Shares used to compute net income (loss) per share attributable to common stockholders: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | 75.0 |  |  | 74.8 |  |  | 76.8 |  |  | 76.9 |  |  | 76.5 |  |  | 76.2 |  |  | 66.8 |  |  | 63.1 |  |
| Diluted | 75.0 |  |  | 77.5 |  |  | 78.0 |  |  | 77.6 |  |  | 76.5 |  |  | 76.2 |  |  | 67.8 |  |  | 63.9 |  |


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001633978-20-000011:notes:479]
SCHEDULE II - VALUATION AND QUALIFYING ACCOUNTS

[0001633978-20-000011:notes:480]
|  | (in millions) |
|  | Balance atBeginningof Period |  | Assumed in Oclaro Acquisition |  | Increase (decrease) toIncome Statement |  | WriteOffs and Other Adjustments |  | Balanceat End ofPeriod |
| Accounts receivable allowance: |  |  |  |  |  |  |  |  |  |
| Fiscal year ended June 27, 2020 | $ | 4.5 |  |  | $ | — |  |  | $ | 0.1 |  |  | $ | (2.8 | ) |  | $ | 1.8 |  |
| Fiscal year ended June 29, 2019 | $ | 2.6 |  |  | $ | 3.3 |  |  | $ | (0.2 | ) |  | $ | (1.2 | ) |  | $ | 4.5 |  |
| Fiscal year ended June 30, 2018 | $ | 1.8 |  |  | $ | — |  |  | $ | 0.9 |  |  | $ | (0.1 | ) |  | $ | 2.6 |  |

[0001633978-20-000011:notes:481]
|  |  | (in millions) |
| Description |  | Balance at Beginning of Period |  | Additions Charged to Expenses or Other Accounts* |  | Deductions Credited to Expenses or Other Accounts** |  | Balance at End of Period |
| Deferred tax valuation allowance: |  |  |  |  |  |  |  |  |
| Fiscal year ended June 27, 2020 |  | $ | 190.3 |  |  | $ | 16.3 |  |  | $ | (5.8 | ) |  | $ | 200.8 |  |
| Fiscal year ended June 29, 2019 |  | $ | 99.4 |  |  | $ | 153.9 |  |  | $ | (63.0 | ) |  | $ | 190.3 |  |
| Fiscal year ended June 30, 2018 |  | $ | 296.4 |  |  | $ | 234.1 |  |  | $ | (431.1 | ) |  | $ | 99.4 |  |

[0001633978-20-000011:notes:482]
*    Additions include current year additions charged to expenses and current year build due to increases in net deferred tax assets, return to provision true-ups, other adjustments to deferred taxes.

[0001633978-20-000011:notes:483]
**    Deductions include current year releases credited to expenses and current year reductions due to decreases in net deferred tax assets, return to provision true-ups, other adjustments to deferred taxes.
