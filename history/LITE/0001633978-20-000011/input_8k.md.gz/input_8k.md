# LITE 8-K — 0001633978-20-000010 filed 2020-08-11

## item codes, every 8-K on or before 2020-08-25

- 2020-08-11 0001633978-20-000010 — 2.02, 9.01
- 2020-05-05 0001628280-20-006358 — 2.02, 9.01
- 2020-02-04 0001633978-20-000002 — 2.02, 9.01
- 2019-12-12 0001193125-19-312875 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2019-12-04 0001633978-19-000075 — 8.01
- 2019-11-20 0001633978-19-000074 — 5.07
- 2019-10-31 0001633978-19-000070 — 2.02, 9.01
- 2019-08-08 0001633978-19-000068 — 2.02, 9.01
- 2019-05-08 0001633978-19-000031 — 1.01
- 2019-05-07 0001633978-19-000029 — 2.02, 9.01
- 2019-02-15 0001633978-19-000005 — 9.01 — amendment of 0001193125-18-346211
- 2019-02-08 0001193125-19-031591 — 5.02, 9.01
- 2019-02-05 0001633978-19-000001 — 2.02, 9.01
- 2018-12-10 0001193125-18-346211 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-12-06 0001633978-18-000150 — 8.01
- 2018-11-14 0001633978-18-000139 — 5.07
- 2018-11-13 0001633978-18-000136 — 3.02
- 2018-11-13 0001633978-18-000132 — 7.01, 9.01
- 2018-11-01 0001628280-18-013238 — 2.02, 9.01
- 2018-08-08 0001633978-18-000056 — 2.02, 9.01
- 2018-06-08 0001193125-18-188241 — 5.02, 9.01
- 2018-05-02 0001633978-18-000029 — 2.02, 9.01
- 2018-03-12 0001193125-18-078154 — 1.01, 2.01, 8.01, 9.01
- 2018-02-06 0001628280-18-001082 — 2.02, 9.01
- 2017-11-08 0001633978-17-000133 — 5.02, 9.01
- 2017-11-07 0001633978-17-000131 — 5.07
- 2017-11-01 0001633978-17-000117 — 2.02, 9.01
- 2017-08-09 0001633978-17-000058 — 2.02, 9.01
- 2017-05-04 0001633978-17-000035 — 2.02, 9.01
- 2017-03-08 0001193125-17-074740 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2017-03-02 0001193125-17-066769 — 8.01, 9.01
- 2017-02-07 0001633978-17-000005 — 2.02, 9.01
- 2017-01-03 0001628280-17-000018 — 4.01, 9.01
- 2016-11-09 0001628280-16-021143 — 5.02, 5.07, 9.01
- 2016-10-27 0001628280-16-020382 — 2.02, 9.01
- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2020-08-25

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001633978-20-000010:8k_2_02:1]
EX-99.1
2
liteex991q4fy20.htm
EXHIBIT 99.1

[0001633978-20-000010:8k_2_02:2]
Exhibit

[0001633978-20-000010:8k_2_02:3]
NEWS RELEASE

[0001633978-20-000010:8k_2_02:4]
LUMENTUM ANNOUNCES FISCAL FOURTH QUARTER AND FULL YEAR 2020 RESULTS

[0001633978-20-000010:8k_2_02:5]
Fiscal Year 2020 Highlights:

[0001633978-20-000010:8k_2_02:6]
| • | Record net revenue of $1.68 billion |

[0001633978-20-000010:8k_2_02:7]
| • | GAAP operating margin of 12.2%; Non-GAAP operating margin of 26.6% |

[0001633978-20-000010:8k_2_02:8]
| • | GAAP diluted net income per share of $1.75; Non-GAAP diluted net income per share of $5.42 |

[0001633978-20-000010:8k_2_02:9]
Fiscal Fourth Quarter Highlights:

[0001633978-20-000010:8k_2_02:10]
| • | Net revenue of $368.1 million |

[0001633978-20-000010:8k_2_02:11]
| • | GAAP operating margin of 7.3%; Non-GAAP operating margin of 24.8% |

[0001633978-20-000010:8k_2_02:12]
| • | GAAP diluted net loss per share of $(0.06); Non-GAAP diluted net income per share of $1.18 |

[0001633978-20-000010:8k_2_02:13]
San Jose, Calif., August 11, 2020 – Lumentum Holdings Inc. (“Lumentum” or the “Company”) today reported results for its fiscal fourth quarter and full year ended June 27, 2020.

[0001633978-20-000010:8k_2_02:14]
“Strong market demand and solid execution drove better than projected results across all financial metrics in our fourth quarter, especially gross margin and EPS,” said Alan Lowe, President and CEO. “We head into fiscal 2021 with demand increasingly driven by new products and technologies, strengthened market positions, and an improving financial model with accruing benefits from acquisition synergies. We became a standalone public company five years ago and since then have significantly improved our financial performance every year. While we have accomplished a lot over the past five years, I believe our future is brighter than ever.”

[0001633978-20-000010:8k_2_02:15]
Full Fiscal Year 2020 Highlights:

[0001633978-20-000010:8k_2_02:16]
Net revenue for fiscal year 2020 was $1,678.6 million, with GAAP net income attributable to common stockholders of $135.5 million, or $1.75 per diluted share. Net revenue for fiscal year 2019 was $1,565.3 million, with GAAP net loss attributable to common stockholders of $(37.9) million, or $(0.54) per diluted share. Results include the impact of the Oclaro acquisition starting from December 10, 2018.

[0001633978-20-000010:8k_2_02:17]
Non-GAAP net income for fiscal year 2020 was $420.5 million, or $5.42 per diluted share.  Non-GAAP net income for fiscal year 2019 was $305.4 million, or $4.25 per diluted share.

[0001633978-20-000010:8k_2_02:18]
Fiscal Fourth Quarter Highlights:

[0001633978-20-000010:8k_2_02:19]
Net revenue for the fiscal fourth quarter of 2020 was $368.1 million, with GAAP net loss attributable to common stockholders of $(4.6) million, or $(0.06) per diluted share. Net revenue for the fiscal third quarter of 2020 was $402.8 million, with GAAP net income of $43.4 million, or $0.56 per diluted share. Net revenue for the fiscal fourth quarter of 2019 was $404.6 million, with GAAP net loss attributable to common stockholders of $(25.8) million, or $(0.34) per diluted share.

[0001633978-20-000010:8k_2_02:20]
Non-GAAP net income for the fiscal fourth quarter of 2020 was $91.7 million, or $1.18 per diluted share. Non-GAAP net income for the fiscal third quarter of 2020 was $98.0 million, or $1.26 per diluted share. Non-GAAP net income for the fiscal fourth quarter of 2019 was $70.4 million, or $0.91 per diluted share.

[0001633978-20-000010:8k_2_02:21]
The Company held $1,553.8 million in total cash, cash equivalents, and short-term investments at the end of the fiscal fourth quarter of 2020, up $102.4 million from third quarter of 2020.

[0001633978-20-000010:8k_2_02:22]
Financial Overview – Fiscal Fourth Quarter Ended June 27, 2020

[0001633978-20-000010:8k_2_02:23]
|  | GAAP Results ($ in millions) |
|  | Q4 |  | Q3 |  | Q4 |  | Change |
|  | FY 2020 |  | FY 2020 |  | FY 2019 |  | Q/Q |  | Y/Y |
| Net revenue | $ | 368.1 |  |  | $ | 402.8 |  |  | $ | 404.6 |  |  | (8.6)% |  | (9.0)% |
| Gross margin | 36.9 | % |  | 39.2 | % |  | 21.5 | % |  | (230)bps |  | 1,540bps |
| Operating margin (loss) | 7.3 | % |  | 10.6 | % |  | (3.4 | )% |  | (330)bps |  | 1,070bps |
|  | Non-GAAP Results ($ in millions) |
|  | Q4 |  | Q3 |  | Q4 |  | Change |
|  | FY 2020 |  | FY 2020 |  | FY 2019 |  | Q/Q |  | Y/Y |
| Net revenue | $ | 368.1 |  |  | $ | 402.8 |  |  | $ | 404.6 |  |  | (8.6)% |  | (9.0)% |
| Gross margin | 47.2 | % |  | 45.5 | % |  | 38.9 | % |  | 170bps |  | 830bps |
| Operating margin | 24.8 | % |  | 25.0 | % |  | 19.0 | % |  | (20)bps |  | 580bps |

[0001633978-20-000010:8k_2_02:24]
|  | Net Revenue by Segment ($ in millions) |
|  | Q4 |  | % of |  | Q3 |  | Q4 |  | Change |
|  | FY 2020 |  | Net Revenue |  | FY 2020 |  | FY 2019 |  | Q/Q |  | Y/Y |
| Optical Communications | $ | 330.3 |  |  | 89.7 | % |  | $ | 359.3 |  |  | $ | 356.8 |  |  | (8.1)% |  | (7.4)% |
| Lasers | 37.8 |  |  | 10.3 | % |  | 43.5 |  |  | 47.8 |  |  | (13.1)% |  | (20.9)% |
| Total | $ | 368.1 |  |  | 100.0 | % |  | $ | 402.8 |  |  | $ | 404.6 |  |  | (8.6)% |  | (9.0)% |

[0001633978-20-000010:8k_2_02:25]
Financial Overview – Fiscal Year Ended June 27, 2020

[0001633978-20-000010:8k_2_02:26]
|  | GAAP Results ($ in millions) |
|  | FY 2020 |  | FY 2019 |  | Change Y/Y |  |
| Net revenue | $ | 1,678.6 |  |  | $ | 1,565.3 |  |  | 7.2% |  |
| Gross margin | 38.7 | % |  | 27.2 | % |  | 1,150bps |  |
| Operating margin (loss) | 12.2 | % |  | (1.4 | )% |  | 1,360bps |  |

[0001633978-20-000010:8k_2_02:27]
|  | Non-GAAP Results ($ in millions) |
|  | FY 2020 |  | FY 2019 |  | Change Y/Y |  |
| Net revenue | $ | 1,678.6 |  |  | $ | 1,565.3 |  |  | 7.2% |  |
| Gross margin | 46.5 | % |  | 39.5 | % |  | 700bps |  |
| Operating margin | 26.6 | % |  | 20.5 | % |  | 610bps |  |

[0001633978-20-000010:8k_2_02:28]
|  | Net Revenue by Segment ($ in millions) |
|  | FY 2020 |  | FY 2019 |  | Change Y/Y |  |
| Optical Communications | $ | 1,515.1 |  |  | $ | 1,370.2 |  |  | 10.6% |  |
| Lasers | 163.5 |  |  | 195.1 |  |  | (16.2)% |  |
| Total | $ | 1,678.6 |  |  | $ | 1,565.3 |  |  | 7.2% |  |

[0001633978-20-000010:8k_2_02:29]
The tables above provide comparisons of quarterly and annual results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled “Use of Non-GAAP Financial Measures.”

[0001633978-20-000010:8k_2_02:30]
Effective June 30, 2019, we adopted Topic 842, using the modified retrospective transition approach. We applied the new guidance to all leases existing as of the date of adoption. Our reported results for the year ended June 27, 2020 reflect the application of Topic 842, while fiscal 2019 amounts have not been adjusted and continue to be reported in accordance with our historical accounting under Topic 840.

[0001633978-20-000010:8k_2_02:31]
Business Outlook

[0001633978-20-000010:8k_2_02:32]
Lumentum expects the following for the fiscal first quarter of 2021:

[0001633978-20-000010:8k_2_02:33]
•Net revenue in the range of $430 million to $455 million

[0001633978-20-000010:8k_2_02:34]
•Non-GAAP operating margin of 28.0% to 30.0%

[0001633978-20-000010:8k_2_02:35]
•Non-GAAP diluted earnings per share of $1.40 to $1.55

[0001633978-20-000010:8k_2_02:36]
We have not provided reconciliations from GAAP to non-GAAP measures for our outlook. A large portion of non-GAAP adjustments, such as restructuring charges, stock-based compensation, acquisition-related costs, non-cash income tax expense and credits, amortization of fair value adjustments, integration related costs, impairment charges, inventory write down due to plans to exit certain product lines and other costs and contingencies unrelated to current and future operations are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future.

[0001633978-20-000010:8k_2_02:37]
Conference Call

[0001633978-20-000010:8k_2_02:38]
Lumentum will host a conference call on August 11, 2020, at 5:30 am PT/8:30 am ET. A live webcast of the call and the replay will be available on the Lumentum website at http://investor.lumentum.com through August 18, 2020, at 11:59 pm ET. To listen to the live conference call, dial (866) 270-1533 or (412) 317-0797 and reference the passcode 10146626. To access the replay, dial (877) 344-7529 or (412) 317-0088 and reference the passcode 10146626. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the “Events and Presentations” section concurrently with this earnings press release. Lumentum has used, and intends to continue to use, its Investor Relations website as means of disclosing material nonpublic information and for complying with its disclosure obligations under Regulation FD. This press release is being furnished as an exhibit to a Current Report on Form 8-K filed with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001633978-20-000010:8k_2_02:39]
About Lumentum

[0001633978-20-000010:8k_2_02:40]
Lumentum (NASDAQ: LITE) is a market-leading designer and manufacturer of innovative optical and photonic products enabling optical networking and laser applications worldwide. Lumentum optical components and subsystems are part of virtually every type of telecom, enterprise, and data center network. Lumentum lasers enable advanced manufacturing techniques and diverse applications including next-generation 3D sensing capabilities. Lumentum is headquartered in San Jose, California with R&D, manufacturing, and sales offices worldwide. For more information, visit www.lumentum.com.

[0001633978-20-000010:8k_2_02:41]
Forward-Looking Statements

[0001633978-20-000010:8k_2_02:42]
preliminary financial results contained in this press release are made as of the date hereof and the Company assumes no obligation to update such statements, except as required by applicable law.

[0001633978-20-000010:8k_2_02:43]
Contact Information

[0001633978-20-000010:8k_2_02:44]
Investors:     Jim Fanucchi, 408-404-5400; investor.relations@lumentum.com

[0001633978-20-000010:8k_2_02:45]
Media:         Sean Ogarrio, 408-546-5405; media@lumentum.com

[0001633978-20-000010:8k_2_02:46]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001633978-20-000010:8k_2_02:47]
LUMENTUM HOLDINGS INC.

[0001633978-20-000010:8k_2_02:48]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001633978-20-000010:8k_2_02:49]
(in millions, except per share data)

[0001633978-20-000010:8k_2_02:50]
(unaudited)

[0001633978-20-000010:8k_2_02:51]
|  | Three Months Ended |  | Twelve Months Ended |
|  | June 27, 2020 |  | June 29, 2019 |  | June 27, 2020 |  | June 29, 2019 |
| Net revenue | $ | 368.1 |  |  | $ | 404.6 |  |  | $ | 1,678.6 |  |  | $ | 1,565.3 |  |
| Cost of sales | 217.4 |  |  | 304.6 |  |  | 974.6 |  |  | 1,092.9 |  |
| Amortization of acquired developed intangibles | 15.0 |  |  | 13.2 |  |  | 53.8 |  |  | 46.5 |  |
| Gross profit | 135.7 |  |  | 86.8 |  |  | 650.2 |  |  | 425.9 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 49.0 |  |  | 49.5 |  |  | 198.6 |  |  | 184.6 |  |
| Selling, general and administrative | 54.8 |  |  | 49.4 |  |  | 235.2 |  |  | 200.3 |  |
| Restructuring and related charges | 3.1 |  |  | 1.7 |  |  | 8.0 |  |  | 31.9 |  |
| Impairment charges | 1.8 |  |  | — |  |  | 4.3 |  |  | 30.7 |  |
| Total operating expenses | 108.7 |  |  | 100.6 |  |  | 446.1 |  |  | 447.5 |  |
| Income (loss) from operations | 27.0 |  |  | (13.8 | ) |  | 204.1 |  |  | (21.6 | ) |
| Unrealized gain on derivative liability | — |  |  | — |  |  | — |  |  | 8.8 |  |
| Interest expense | (15.9 | ) |  | (11.4 | ) |  | (61.2 | ) |  | (36.3 | ) |
| Other income, net | 3.5 |  |  | 4.1 |  |  | 31.4 |  |  | 15.8 |  |
| Income (loss) before income taxes | 14.6 |  |  | (21.1 | ) |  | 174.3 |  |  | (33.3 | ) |
| Provision for income taxes | 19.2 |  |  | 4.7 |  |  | 38.8 |  |  | 3.1 |  |
| Net income (loss) | (4.6 | ) |  | (25.8 | ) |  | 135.5 |  |  | (36.4 | ) |
| Items reconciling net income (loss) to net income (loss) attributable to common stockholders: |  |  |  |  |  |  |  |
| Less: Cumulative dividends on Series A Preferred Stock | — |  |  | — |  |  | — |  |  | (0.3 | ) |
| Less: Earnings allocated to Series A Preferred Stock | — |  |  | — |  |  | — |  |  | (1.2 | ) |
| Net income (loss) attributable to common stockholders - Basic and Diluted | $ | (4.6 | ) |  | $ | (25.8 | ) |  | $ | 135.5 |  |  | $ | (37.9 | ) |
| Net income (loss) per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | $ | (0.06 | ) |  | $ | (0.34 | ) |  | $ | 1.79 |  |  | $ | (0.54 | ) |
| Diluted | $ | (0.06 | ) |  | $ | (0.34 | ) |  | $ | 1.75 |  |  | $ | (0.54 | ) |
| Shares used to compute net income (loss) per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | 75.0 |  |  | 76.5 |  |  | 75.9 |  |  | 70.7 |  |
| Diluted | 75.0 |  |  | 76.5 |  |  | 77.6 |  |  | 70.7 |  |

[0001633978-20-000010:8k_2_02:52]
LUMENTUM HOLDINGS INC.

[0001633978-20-000010:8k_2_02:53]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001633978-20-000010:8k_2_02:54]
(in millions, except share and per share data)

[0001633978-20-000010:8k_2_02:55]
(unaudited)

[0001633978-20-000010:8k_2_02:56]
|  | June 27, 2020 |  | June 29, 2019 |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |  |
| Cash and cash equivalents | $ | 298.0 |  |  | $ | 432.6 |  |
| Short-term investments | 1,255.8 |  |  | 335.9 |  |
| Accounts receivable, net | 233.5 |  |  | 238.0 |  |
| Inventories | 188.9 |  |  | 228.8 |  |
| Prepayments and other current assets | 73.8 |  |  | 97.5 |  |
| Total current assets | 2,050.0 |  |  | 1,332.8 |  |
| Property, plant and equipment, net | 393.0 |  |  | 433.3 |  |
| Operating lease right-of-use assets, net | 78.7 |  |  | — |  |
| Goodwill | 368.9 |  |  | 368.9 |  |
| Other intangible assets, net | 316.8 |  |  | 395.4 |  |
| Deferred income taxes | 81.2 |  |  | 169.6 |  |
| Other non-current assets | 4.0 |  |  | 16.6 |  |
| Total assets | $ | 3,292.6 |  |  | $ | 2,716.6 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 150.8 |  |  | $ | 160.8 |  |
| Accrued payroll and related expenses | 53.4 |  |  | 42.3 |  |
| Accrued expenses | 23.7 |  |  | 46.7 |  |
| Term loan, current | — |  |  | 5.0 |  |
| Operating lease liabilities, current | 10.8 |  |  | — |  |
| Other current liabilities | 44.3 |  |  | 39.2 |  |
| Total current liabilities | 283.0 |  |  | 294.0 |  |
| Convertible notes | 1,120.3 |  |  | 351.9 |  |
| Term loan, non-current | — |  |  | 484.0 |  |
| Operating lease liabilities, non-current | 57.6 |  |  | — |  |
| Deferred tax liability | 46.5 |  |  | 55.9 |  |
| Other non-current liabilities | 36.0 |  |  | 33.7 |  |
| Total liabilities | 1,543.4 |  |  | 1,219.5 |  |
| Commitments and contingencies |  |  |  |
| Stockholders’ equity: |  |  |  |
| Common stock, $0.001 par value, 990,000,000 authorized shares, 75,100,664 and 76,653,478 shares issued and outstanding as of June 27, 2020 and June 29, 2019, respectively | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital | 1,676.6 |  |  | 1,360.8 |  |
| Retained earnings | 64.6 |  |  | 129.1 |  |
| Accumulated other comprehensive income | 7.9 |  |  | 7.1 |  |
| Total stockholders’ equity | 1,749.2 |  |  | 1,497.1 |  |
| Total liabilities and stockholders’ equity | $ | 3,292.6 |  |  | $ | 2,716.6 |  |

[0001633978-20-000010:8k_2_02:57]
Use of Non-GAAP Financial Measures

[0001633978-20-000010:8k_2_02:58]
In this press release, Lumentum provides investors with gross margin, gross profit, research and development expense, selling, general and administrative expense, operating margin, operating income, interest and other income (expense), net, income before income taxes and certain expenses, provision for taxes, net income, and net income per share on a non-GAAP basis as well as the non-GAAP measure of Adjusted EBITDA. Lumentum believes this non-GAAP financial information provides additional insight into the Company’s on-going business operations and results, as well as cash generation, and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons. Specifically, the Company believes that providing this information allows investors to better understand the Company’s cash flows and, importantly, to evaluate the efficacy of the methodology and information used by management to evaluate and measure such cash flows. However, these measures may be different from non-GAAP measures used by other companies, limiting their usefulness for comparison purposes. The non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP. Investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future. Further, these non-GAAP financial measures may not be comparable to similarly titled measurements reported by other companies.

[0001633978-20-000010:8k_2_02:59]
Non-GAAP gross margin, non-GAAP gross profit, non-GAAP expenses, non-GAAP operating margin, non-GAAP operating income, non-GAAP income before income taxes, non-GAAP net income, and non-GAAP net income per share and Adjusted EBITDA exclude (i) stock-based compensation, (ii) inventory write-downs and fixed asset impairment due to cancelled programs, plans to exit certain lines of business and other costs and contingencies unrelated to current and future operations, (iii) acquisition and disposition related costs, (iv) integration related costs, (v) amortization of acquired intangibles, (vi) amortization of fair value adjustments, (vii) restructuring and related charges, (viii) non-cash interest expense, (ix) foreign exchange (gains) losses, net, (x) impairment charges, (xi) transferring product lines to Thailand, (xii) excess and obsolete inventory charges driven by the decline in demand from Huawei, (xiii) certain expenses related to the COVID-19 outbreak, and (xiv) non-cash income tax provision impacts. The presentation of these and other similar items in Lumentum’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001633978-20-000010:8k_2_02:60]
A quantitative reconciliation between GAAP and non-GAAP financial data with respect to historical periods is included in the supplemental financial table attached to this press release.

[0001633978-20-000010:8k_2_02:61]
LUMENTUM HOLDINGS INC.

[0001633978-20-000010:8k_2_02:62]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001633978-20-000010:8k_2_02:63]
(in millions, except per share data)

[0001633978-20-000010:8k_2_02:64]
(unaudited)

[0001633978-20-000010:8k_2_02:65]
|  | Three Months Ended |  | Twelve Months Ended |
|  | June 27, 2020 |  | March 28, 2020 |  | June 29, 2019 |  | June 27, 2020 |  | June 29, 2019 |
| Gross profit on GAAP basis | $ | 135.7 |  |  | $ | 157.7 |  |  | $ | 86.8 |  |  | $ | 650.2 |  |  | $ | 425.9 |  |
| Stock-based compensation | 3.5 |  |  | 4.3 |  |  | 3.4 |  |  | 16.1 |  |  | 15.1 |  |
| Inventory and fixed asset write down due to product lines exit (1) | 1.0 |  |  | 2.3 |  |  | 1.4 |  |  | 7.0 |  |  | 20.8 |  |
| Integration related costs | 1.8 |  |  | (0.3 | ) |  | 3.8 |  |  | 4.9 |  |  | 6.6 |  |
| Amortization of acquired intangibles | 15.0 |  |  | 13.9 |  |  | 13.3 |  |  | 53.8 |  |  | 46.6 |  |
| Amortization of fair value adjustments (2) | — |  |  | 1.5 |  |  | 38.8 |  |  | 5.8 |  |  | 54.6 |  |
| Expenses related to COVID-19 outbreak (3) | 5.0 |  |  | 1.6 |  |  | — |  |  | 6.6 |  |  | — |  |
| Other charges (4) | 11.9 |  |  | 2.4 |  |  | 9.9 |  |  | 35.8 |  |  | 48.9 |  |
| Gross profit on non-GAAP basis | $ | 173.9 |  |  | $ | 183.4 |  |  | $ | 157.4 |  |  | $ | 780.2 |  |  | $ | 618.5 |  |
| Gross margin on non-GAAP basis | 47.2 | % |  | 45.5 | % |  | 38.9 | % |  | 46.5 | % |  | 39.5 | % |
| Research and development on GAAP basis | $ | 49.0 |  |  | $ | 48.7 |  |  | $ | 49.5 |  |  | $ | 198.6 |  |  | $ | 184.6 |  |
| Stock-based compensation | (3.8 | ) |  | (4.2 | ) |  | (3.1 | ) |  | (15.9 | ) |  | (13.8 | ) |
| Expenses related to COVID-19 outbreak (3) | (0.5 | ) |  | — |  |  | — |  |  | (0.5 | ) |  | — |  |
| Other charges | 1.2 |  |  | (0.2 | ) |  | — |  |  | 1.1 |  |  | (0.7 | ) |
| Research and development on non-GAAP basis | $ | 45.9 |  |  | $ | 44.3 |  |  | $ | 46.4 |  |  | $ | 183.3 |  |  | $ | 170.1 |  |
| Selling, general and administrative on GAAP basis | $ | 54.8 |  |  | $ | 61.3 |  |  | $ | 49.4 |  |  | $ | 235.2 |  |  | $ | 200.3 |  |
| Stock-based compensation | (9.8 | ) |  | (10.7 | ) |  | (7.7 | ) |  | (41.2 | ) |  | (41.8 | ) |
| Acquisition related costs | — |  |  | — |  |  | (0.3 | ) |  | — |  |  | (15.6 | ) |
| Integration related costs | (1.1 | ) |  | (5.0 | ) |  | (1.7 | ) |  | (12.2 | ) |  | (3.0 | ) |
| Amortization of acquired intangibles | (6.2 | ) |  | (6.1 | ) |  | (3.6 | ) |  | (24.8 | ) |  | (8.0 | ) |
| Other charges | (1.1 | ) |  | (1.1 | ) |  | (1.8 | ) |  | (6.9 | ) |  | (4.1 | ) |
| Selling, general and administrative on non-GAAP basis | $ | 36.6 |  |  | $ | 38.4 |  |  | $ | 34.3 |  |  | $ | 150.1 |  |  | $ | 127.8 |  |
| Income (loss) from operations on GAAP basis | $ | 27.0 |  |  | $ | 42.5 |  |  | $ | (13.8 | ) |  | $ | 204.1 |  |  | $ | (21.6 | ) |
| Stock-based compensation | 17.1 |  |  | 19.2 |  |  | 14.2 |  |  | 73.2 |  |  | 70.7 |  |
| Inventory and fixed asset write down due to product lines exit (1) | 1.0 |  |  | 2.3 |  |  | 1.4 |  |  | 7.0 |  |  | 20.8 |  |
| Acquisition related costs | — |  |  | — |  |  | 0.3 |  |  | — |  |  | 15.6 |  |
| Integration related costs | 2.9 |  |  | 4.7 |  |  | 5.5 |  |  | 17.1 |  |  | 9.6 |  |
| Amortization of acquired intangibles | 21.2 |  |  | 20.0 |  |  | 16.9 |  |  | 78.6 |  |  | 54.6 |  |
| Amortization of fair value adjustments (2) | — |  |  | 1.5 |  |  | 38.8 |  |  | 5.8 |  |  | 54.6 |  |
| Restructuring and related charges | 3.1 |  |  | 2.7 |  |  | 1.7 |  |  | 8.0 |  |  | 31.9 |  |
| Expenses related to COVID-19 outbreak (3) | 5.5 |  |  | 1.6 |  |  | — |  |  | 7.1 |  |  | — |  |
| Impairment charge (5) | 1.8 |  |  | 2.5 |  |  | — |  |  | 4.3 |  |  | 30.7 |  |
| Other charges | 11.8 |  |  | 3.7 |  |  | 11.7 |  |  | 41.6 |  |  | 53.7 |  |
| Income from operations on non-GAAP basis | $ | 91.4 |  |  | $ | 100.7 |  |  | $ | 76.7 |  |  | $ | 446.8 |  |  | $ | 320.6 |  |
| Operating margin on non-GAAP basis | 24.8 | % |  | 25.0 | % |  | 19.0 | % |  | 26.6 | % |  | 20.5 | % |

[0001633978-20-000010:8k_2_02:66]
| Interest and other (expense) income, net on GAAP basis | $ | (12.4 | ) |  | $ | 6.1 |  |  | $ | (7.3 | ) |  | $ | (29.8 | ) |  | $ | (20.5 | ) |
| Other interest and (income) expense adjustments | — |  |  | (2.0 | ) |  | — |  |  | (2.0 | ) |  | (0.5 | ) |
| Gain on sale of product lines | (0.7 | ) |  | (13.8 | ) |  | — |  |  | (14.5 | ) |  | — |  |
| Foreign exchange (gains) losses, net (6) | 1.1 |  |  | (0.7 | ) |  | (0.4 | ) |  | 1.4 |  |  | 0.6 |  |
| Non-cash interest expense on convertible notes and term loan | 14.3 |  |  | 14.0 |  |  | 4.9 |  |  | 47.6 |  |  | 18.5 |  |
| Interest and other (expense) income, net on non-GAAP basis | $ | 2.3 |  |  | $ | 3.6 |  |  | $ | (2.8 | ) |  | $ | 2.7 |  |  | $ | (1.9 | ) |
| Income (loss) before income taxes on GAAP basis | $ | 14.6 |  |  | $ | 48.6 |  |  | $ | (21.1 | ) |  | $ | 174.3 |  |  | $ | (33.3 | ) |
| Stock-based compensation | 17.1 |  |  | 19.2 |  |  | 14.2 |  |  | 73.2 |  |  | 70.7 |  |
| Inventory and fixed asset write down due to product lines exit (1) | 1.0 |  |  | 2.3 |  |  | 1.4 |  |  | 7.0 |  |  | 20.8 |  |
| Acquisition related costs | — |  |  | — |  |  | 0.3 |  |  | — |  |  | 15.6 |  |
| Integration related costs | 2.9 |  |  | 4.7 |  |  | 5.5 |  |  | 17.1 |  |  | 9.6 |  |
| Amortization of acquired intangibles | 21.2 |  |  | 20.0 |  |  | 16.9 |  |  | 78.6 |  |  | 54.6 |  |
| Amortization of fair value adjustments (2) | — |  |  | 1.5 |  |  | 38.8 |  |  | 5.8 |  |  | 54.6 |  |
| Restructuring and related charges | 3.1 |  |  | 2.7 |  |  | 1.7 |  |  | 8.0 |  |  | 31.9 |  |
| Expenses related to COVID-19 outbreak (3) | 5.5 |  |  | 1.6 |  |  | — |  |  | 7.1 |  |  | — |  |
| Impairment charge (5) | 1.8 |  |  | 2.5 |  |  | — |  |  | 4.3 |  |  | 30.7 |  |
| Other interest and (income) expense adjustments | — |  |  | (2.0 | ) |  | — |  |  | (2.0 | ) |  | (0.5 | ) |
| Gain on sale of product lines | (0.7 | ) |  | (13.8 | ) |  | — |  |  | (14.5 | ) |  | — |  |
| Foreign exchange (gains) losses, net (6) | 1.1 |  |  | (0.7 | ) |  | (0.4 | ) |  | 1.4 |  |  | 0.6 |  |
| Non-cash interest expense on convertible notes and term loan | 14.3 |  |  | 14.0 |  |  | 4.9 |  |  | 47.6 |  |  | 18.5 |  |
| Unrealized gain on derivative liability | — |  |  | — |  |  | — |  |  | — |  |  | (8.8 | ) |
| Other charges | 11.8 |  |  | 3.7 |  |  | 11.7 |  |  | 41.6 |  |  | 53.7 |  |
| Income before income taxes on non-GAAP basis | $ | 93.7 |  |  | $ | 104.3 |  |  | $ | 73.9 |  |  | $ | 449.5 |  |  | $ | 318.7 |  |
| Provision for income taxes on GAAP basis | $ | 19.2 |  |  | $ | 5.2 |  |  | $ | 4.7 |  |  | $ | 38.8 |  |  | $ | 3.1 |  |
| Income tax adjustments | (17.2 | ) |  | 1.1 |  |  | (1.2 | ) |  | (9.8 | ) |  | 10.2 |  |
| Provision for income taxes on non-GAAP basis | $ | 2.0 |  |  | $ | 6.3 |  |  | $ | 3.5 |  |  | $ | 29.0 |  |  | $ | 13.3 |  |
| Net income (loss) on GAAP basis | $ | (4.6 | ) |  | $ | 43.4 |  |  | $ | (25.8 | ) |  | $ | 135.5 |  |  | $ | (36.4 | ) |
| Stock-based compensation | 17.1 |  |  | 19.2 |  |  | 14.2 |  |  | 73.2 |  |  | 70.7 |  |
| Inventory and fixed asset write down due to product lines exit (1) | 1.0 |  |  | 2.3 |  |  | 1.4 |  |  | 7.0 |  |  | 20.8 |  |
| Acquisition related costs | — |  |  | — |  |  | 0.3 |  |  | — |  |  | 15.6 |  |
| Integration related costs | 2.9 |  |  | 4.7 |  |  | 5.5 |  |  | 17.1 |  |  | 9.6 |  |
| Amortization of acquired intangibles | 21.2 |  |  | 20.0 |  |  | 16.9 |  |  | 78.6 |  |  | 54.6 |  |
| Amortization of fair value adjustments (2) | — |  |  | 1.5 |  |  | 38.8 |  |  | 5.8 |  |  | 54.6 |  |
| Restructuring and related charges | 3.1 |  |  | 2.7 |  |  | 1.7 |  |  | 8.0 |  |  | 31.9 |  |
| Expenses related to COVID-19 outbreak (3) | 5.5 |  |  | 1.6 |  |  | — |  |  | 7.1 |  |  | — |  |
| Impairment charge (5) | 1.8 |  |  | 2.5 |  |  | — |  |  | 4.3 |  |  | 30.7 |  |
| Other interest and (income) expense adjustments | — |  |  | (2.0 | ) |  | — |  |  | (2.0 | ) |  | (0.5 | ) |
| Gain on sale of product lines | (0.7 | ) |  | (13.8 | ) |  | — |  |  | (14.5 | ) |  | — |  |
| Foreign exchange (gains) losses, net (6) | 1.1 |  |  | (0.7 | ) |  | (0.4 | ) |  | 1.4 |  |  | 0.6 |  |

[0001633978-20-000010:8k_2_02:67]
| Non-cash interest expense on convertible notes and term loan | 14.3 |  |  | 14.0 |  |  | 4.9 |  |  | 47.6 |  |  | 18.5 |  |
| Unrealized gain on derivative liability | — |  |  | — |  |  | — |  |  | — |  |  | (8.8 | ) |
| Other charges | 11.8 |  |  | 3.7 |  |  | 11.7 |  |  | 41.6 |  |  | 53.7 |  |
| Income tax adjustments | 17.2 |  |  | (1.1 | ) |  | 1.2 |  |  | 9.8 |  |  | (10.2 | ) |
| Net income on non-GAAP basis | $ | 91.7 |  |  | $ | 98.0 |  |  | $ | 70.4 |  |  | $ | 420.5 |  |  | $ | 305.4 |  |
| Net income per share on non-GAAP basis | $ | 1.18 |  |  | $ | 1.26 |  |  | $ | 0.91 |  |  | $ | 5.42 |  |  | $ | 4.25 |  |
| Shares used in per share calculation - diluted on GAAP basis | 75.0 |  |  | 77.5 |  |  | 76.5 |  |  | 77.6 |  |  | 70.7 |  |
| Non-GAAP adjustment (7) | 2.5 |  |  | — |  |  | 0.6 |  |  | — |  |  | 0.6 |  |
| Effect of diluted securities from Series A Preferred Stock | — |  |  | — |  |  | — |  |  | — |  |  | 0.5 |  |
| Shares used in per share calculation - diluted on non-GAAP basis | 77.5 |  |  | 77.5 |  |  | 77.1 |  |  | 77.6 |  |  | 71.8 |  |

[0001633978-20-000010:8k_2_02:68]
(1) For the three and twelve months ended June 27, 2020, we recorded inventory and fixed asset write down charges of $1.0 million and $7.0 million, respectively, related to the decision to exit the Datacom module and Lithium Niobate product lines.

[0001633978-20-000010:8k_2_02:69]
(2) In connection with the acquisition of Oclaro in fiscal 2019, we recorded a fair value adjustment of $60.3 million to inventory, resulting in $5.8 million of amortization expense of the fair value adjustment during the twelve months ended June 27, 2020.

[0001633978-20-000010:8k_2_02:70]
(3) During the three and twelve months ended June 27, 2020, we recorded expenses of $5.5 million and $7.1 million, respectively, related to the COVID-19 outbreak, which included incremental costs for payroll expense such as overtime pay, pay for employees who are not working, facilities costs such as gloves, masks and temperature gauges, and under-utilized capacity at certain facilities, in which manufacturing output was impacted. These COVID-19 related costs were partially offset by benefits realized from government credits for employers’ payroll tax.

[0001633978-20-000010:8k_2_02:71]
(4) Other adjustments to gross profit on a non-GAAP basis for the three and twelve months ended June 27, 2020, primarily include costs of transferring product lines to new production facilities, including Thailand of $3.0 million and $11.5 million, respectively. We also incurred excess and obsolete inventory charges driven by the decline in demand from Huawei $12.8 million during the twelve months ended June 27, 2020. In addition, during the three months ended June 27, 2020,  we incurred $6.2 million impairment charges associated with excess capacity related to our Fiber laser business. Other charges to gross profit on a non-GAAP basis for the three and twelve months ended June 29, 2019, included costs of transferring product lines to Thailand of $7.3 million and $45.8 million, respectively.

[0001633978-20-000010:8k_2_02:72]
(5) For the twelve months ended June 27, 2020 and June 29, 2019, we recorded impairment charges of $4.3 million and $30.7 million, respectively, in property, plant and equipment related to the decision to exit the Datacom module product line.

[0001633978-20-000010:8k_2_02:73]
(6) The non-GAAP financial measures for the three and twelve months ended June 29, 2019 have been adjusted to conform to the current period presentation, by removing foreign exchange (gains) losses, net.

[0001633978-20-000010:8k_2_02:74]
(7) This adjustment represents weighted-average potentially dilutive securities from our stock-based benefit plans excluded from the computation of diluted net loss per share attributable to common stockholders on a GAAP basis because the effect would have been anti-dilutive. This adjustment amount is added for the computation of diluted net income per share on a non-GAAP basis as we had a net income on a non-GAAP basis.

[0001633978-20-000010:8k_2_02:75]
LUMENTUM HOLDINGS INC.

[0001633978-20-000010:8k_2_02:76]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO EBITDA

[0001633978-20-000010:8k_2_02:77]
(in millions, except per share data)

[0001633978-20-000010:8k_2_02:78]
(unaudited)

[0001633978-20-000010:8k_2_02:79]
|  | Three Months Ended |  | Twelve Months Ended |
|  | June 27, 2020 |  | March 28, 2020 |  | June 29, 2019 |  | June 27, 2020 |  | June 29, 2019 |
| GAAP Net income (loss) | $ | (4.6 | ) |  | $ | 43.4 |  |  | $ | (25.8 | ) |  | $ | 135.5 |  |  | $ | (36.4 | ) |
| Interest and other expense (income), net | 12.4 |  |  | (6.1 | ) |  | 7.3 |  |  | 29.8 |  |  | 20.5 |  |
| Provision for (benefit from) income taxes | 19.2 |  |  | 5.2 |  |  | 4.7 |  |  | 38.8 |  |  | 3.1 |  |
| Depreciation | 25.5 |  |  | 27.5 |  |  | 28.2 |  |  | 113.3 |  |  | 102.9 |  |
| Amortization of acquired intangibles | 21.2 |  |  | 20.0 |  |  | 16.9 |  |  | 78.6 |  |  | 54.6 |  |
| EBITDA | 73.7 |  |  | 90.0 |  |  | 31.3 |  |  | 396.0 |  |  | 144.7 |  |
| Amortization of fair value adjustments | — |  |  | 1.5 |  |  | 38.8 |  |  | 5.8 |  |  | 54.6 |  |
| Restructuring and related charges | 3.1 |  |  | 2.7 |  |  | 1.7 |  |  | 8.0 |  |  | 31.9 |  |
| Stock-based compensation | 17.1 |  |  | 19.2 |  |  | 14.2 |  |  | 73.2 |  |  | 70.7 |  |
| Acquisition related costs | — |  |  | — |  |  | 0.3 |  |  | — |  |  | 15.6 |  |
| Unrealized gain on derivative liability | — |  |  | — |  |  | — |  |  | — |  |  | (8.8 | ) |
| Inventory and fixed asset write down due to product lines exit | 1.0 |  |  | 2.3 |  |  | 1.4 |  |  | 7.0 |  |  | 20.8 |  |
| Integration related costs | 2.9 |  |  | 4.7 |  |  | 5.5 |  |  | 17.1 |  |  | 9.6 |  |
| Impairment charges | 1.8 |  |  | 2.5 |  |  | — |  |  | 4.3 |  |  | 30.7 |  |
| Expenses related to COVID-19 outbreak | 5.5 |  |  | 1.6 |  |  | — |  |  | 7.1 |  |  | — |  |
| Other charges | 11.8 |  |  | 3.7 |  |  | 11.7 |  |  | 41.6 |  |  | 53.7 |  |
| Adjusted EBITDA | $ | 116.9 |  |  | $ | 128.2 |  |  | $ | 104.9 |  |  | $ | 560.1 |  |  | $ | 423.5 |  |
