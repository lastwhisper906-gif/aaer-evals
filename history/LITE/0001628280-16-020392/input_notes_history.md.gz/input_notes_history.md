# LITE note change history — 0001628280-16-015527 → 0001628280-16-020392


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-10-27):
[0001628280-16-020392:note_history:1]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2026. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. As of October 1, 2016 the future minimum annual lease payments under non-cancellable operating leases were as follows (in millions):
  (was, 2016-05-04, similarity 0.985):
[0001628280-16-015527:note_history:1]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2026. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. As of April 2, 2016 the future minimum annual lease payments under non-cancellable operating leases were as follows (in millions):

- changed (2016-10-27):
[0001628280-16-020392:note_history:2]
Included in the future minimum lease payments table above is $0.5 million related to lease commitments in connection with our restructuring and related activities. Refer to "Note 10. Restructuring and Related Charges" in the Notes to Consolidated Financial Statements.
  (was, 2016-05-04, similarity 0.8617):
[0001628280-16-015527:note_history:2]
Included in the future minimum lease payments table above is $0.7 million related to lease commitments in connection with our restructuring and related activities. Refer to "Note 10. Restructuring and Related Charges" for more information.

- added (2016-10-27):
[0001628280-16-020392:note_history:3]
Rental expense was $2.2 million and $1.5 million for the three months ended October 1, 2016 and September 26, 2015, respectively.

- changed (2016-10-27):
[0001628280-16-020392:note_history:4]
Purchase obligations of $125.4 million as of October 1, 2016, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.
  (was, 2016-05-04, similarity 0.9895):
[0001628280-16-015527:note_history:4]
Purchase obligations of $164.4 million as of April 2, 2016, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

- changed (2016-10-27):
[0001628280-16-020392:note_history:5]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, product component or application of our products by the end customer, our warranties can vary and generally range from six months to 5 years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.
  (was, 2016-05-04, similarity 0.9797):
[0001628280-16-015527:note_history:5]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, product component or application of our products by the end customer, our warranties can vary and generally range from six to thirty-six months. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

- changed (2016-10-27):
[0001628280-16-020392:note_history:6]
The following table presents the changes in our warranty reserve during the three months ended October 1, 2016 and September 26, 2015 (in millions):
  (was, 2016-05-04, similarity 0.8968):
[0001628280-16-015527:note_history:6]
The following table presents the changes in our warranty reserve during the three and nine months ended April 2, 2016 and March 28, 2015 (in millions):

- added (2016-10-27):
[0001628280-16-020392:note_history:7]
|  | Three months ended |
|  | October 1, 2016 |  | September 26, 2015 |
| Balance as of beginning of period | $ | 2.8 |  |  | $ | 2.8 |  |
| Provision for warranty | 3.8 |  |  | 0.9 |  |
| Utilization of reserve | (1.2 | ) |  | (1.2 | ) |
| Balance as of period end | $ | 5.4 |  |  | $ | 2.5 |  |

- changed (2016-10-27):
[0001628280-16-020392:note_history:8]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management's view of these matters may change in the future. Were an unfavorable final outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the effect becomes reasonably estimable.
  (was, 2016-05-04, similarity 0.9993):
[0001628280-16-015527:note_history:8]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statement of cash flows, these matters are subject to inherent uncertainties and management's view of these matters may change in the future. Were an unfavorable final outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the effect becomes reasonably estimable.

- removed (2016-10-27):
[0001628280-16-015527:note_history:9]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2016 |  | March 28, 2015 |  | April 2, 2016 |  | March 28, 2015 |
| Balance as of beginning of period | $ | 3.1 |  |  | $ | 2.0 |  |  | $ | 2.8 |  |  | $ | 2.7 |  |
| Provision for warranty | 0.8 |  |  | 0.8 |  |  | 2.5 |  |  | 2.3 |  |
| Utilization of reserve | (0.8 | ) |  | (0.7 | ) |  | (2.3 | ) |  | (2.8 | ) |
| Adjustments related to pre-existing warranties (including changes in estimates) | (1.3 | ) |  | (0.3 | ) |  | (1.2 | ) |  | (0.4 | ) |
| Balance as of end of period | $ | 1.8 |  |  | $ | 1.8 |  |  | $ | 1.8 |  |  | $ | 1.8 |  |


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-10-27):
[0001628280-16-020392:note_history:10]
Lumentum Holdings Inc. ("we", "our", "Lumentum" or the "Company") is an industry leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including data communications ("Datacom") and telecommunications ("Telecom") networking and commercial lasers ("commercial lasers") for manufacturing, inspection and life-science applications. We are using our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including 3-D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be original equipment manufacturers ("OEMs") that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that our network equipment manufacturer ("NEM") customers assemble into communications networking systems, which they sell to network service providers or enterprises with their own networks. Similarly, many of our customers for our Lasers products incorporate our products into tools they produce, which are used for manufacturing processes by their customers.
  (was, 2016-05-04, similarity 0.9422):
[0001628280-16-015527:note_history:10]
Lumentum Holdings Inc. (“we”, “our” or “Lumentum”) is an industry leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including data communications (“Datacom”) and telecommunications (“Telecom”) networking and commercial lasers (“commercial lasers”) for manufacturing, inspection and life-science applications. We are using our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including 3-D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be original equipment manufacturers (“OEMs”) that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that our network equipment manufacturer (“NEM”) customers assemble into communications networking systems, which they sell to network service providers or enterprises with their own networks. Similarly, many of our customers for our Lasers products incorporate our products into tools they produce, which are used for manufacturing processes by their customers.

- added (2016-10-27):
[0001628280-16-020392:note_history:11]
Lumentum was incorporated in Delaware as a wholly owned subsidiary of JDS Uniphase ("JDSU") on February 10, 2015 and is comprised of the former communications and commercial optical products (“CCOP”) segment and WaveReady product lines of JDSU.

- added (2016-10-27):
[0001628280-16-020392:note_history:12]
On July 31, 2015, prior to the Separation (as described below), JDSU transferred substantially all of the assets and liabilities and operations of the CCOP segment and WaveReady product lines to Lumentum. Financial statements for periods prior to the Separation were prepared on a stand-alone basis and were derived from JDSU’s consolidated financial statements and accounting records. The Company prepared consolidated financial statements for the period from June 28, 2015 to August 1, 2015 where expenses were allocated to the Company using estimates that it considers to be a reasonable reflection of the utilization of services provided to, or benefits received by, the Company. Since August 1, 2015, the Company has prepared consolidated financial statements as an independent stand-alone basis pursuant to the rules and regulations of the SEC and are in conformity with U.S. GAAP. In the opinion of management, these consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments, which are necessary for a fair statement of the consolidated financial statements for the periods shown. The results of operations for such periods are not necessarily indicative of the results expected for the full year or for any future periods.

- changed (2016-10-27):
[0001628280-16-020392:note_history:13]
On August 1, 2015, Lumentum became an independent publicly-traded company through the distribution by JDSU to its stockholders of 80.1% of our outstanding common stock (the “Separation”). Each JDSU stockholder of record as of the close of business on July 27, 2015 received one share of Lumentum common stock for every five shares of JDSU common stock held on the record date. JDSU was renamed Viavi Solutions Inc. ("Viavi") and at the time of the distribution retained ownership of 19.9% of Lumentum’s outstanding shares. Lumentum’s Registration Statement on Form 10 was declared effective by the SEC on July 16, 2015. Lumentum’s common stock began trading “regular-way” under the ticker “LITE” on the NASDAQ stock market on August 4, 2015.
  (was, 2016-05-04, similarity 0.6263):
[0001628280-16-015527:note_history:13]
On August 1, 2015, Lumentum became an independent publicly-traded company through the distribution by JDSU to its stockholders of 80.1% of our outstanding common stock (the “Separation”). Each JDSU stockholder of record as of the close of business on July 27, 2015 received one share of Lumentum common stock for every five shares of JDSU common stock held on the record date. JDSU was renamed Viavi and at the time of the distribution retained ownership of 19.9% of Lumentum’s outstanding shares. Lumentum was incorporated in Delaware as a wholly owned subsidiary of Viavi on February 10, 2015 and is comprised of the former communications and commercial optical products (“CCOP”) segment and WaveReady product lines of Viavi. Lumentum’s Registration Statement on Form 10 was declared effective by the U.S. Securities and Exchange Commission (“SEC”) on July 16, 2015. Lumentum’s common stock began trading “regular-way” under the ticker “LITE” on the NASDAQ stock market on August 4, 2015.

- changed (2016-10-27):
[0001628280-16-020392:note_history:14]
The preparation of the consolidated financial statements in accordance with GAAP in the United States requires management to make estimates and assumptions that affect the amounts reported in our consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, inventory valuation, allocation methods and allocated expenses from Viavi, valuation of goodwill and other intangible assets, stock-based compensation, retirement and post-retirement plan assumptions, restructuring, warranty and accounting for income taxes.
  (was, 2016-05-04, similarity 0.9961):
[0001628280-16-015527:note_history:14]
The preparation of the consolidated financial statements in accordance with GAAP in the United States requires management to make estimates and assumptions that affect the amounts reported in our consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, inventory valuation, allocation methods and allocated expenses from Viavi, valuation of goodwill and other intangible assets, share-based compensation, retirement and post-retirement plan assumptions, restructuring, warranty and accounting for income taxes.

- changed (2016-10-27):
[0001628280-16-020392:note_history:15]
See "Note 3. Related Party Transactions" in the Notes to Consolidated Financial Statements regarding the relationships we had with Viavi.
  (was, 2016-05-04, similarity 0.8141):
[0001628280-16-015527:note_history:15]
See "Note 3. Related Party Transactions" in the consolidated financial statements for further information regarding the relationships we had with Viavi and other Viavi entities.

- changed (2016-10-27):
[0001628280-16-020392:note_history:16]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Our fiscal 2017 is a 52-week year ending on July 1, 2017. Our fiscal 2016 was a 53-week year ended on July 2, 2016.
  (was, 2016-05-04, similarity 0.6921):
[0001628280-16-015527:note_history:16]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Our fiscal 2016 is a 53-week year ending on July 2, 2016 and our third quarter of fiscal 2016 included one additional week. Our fiscal 2015 ended on June 27, 2015 and was a 52-week year.

- added (2016-10-27):
[0001628280-16-020392:note_history:17]
These unaudited interim consolidated financial statements include the accounts of the Company and its wholly-owned subsidiaries. All intra-company transactions and balances within our business were eliminated. All material transactions between us and other businesses of Viavi prior to Separation were reflected as net transfers to and from Viavi as a component of financing activities in the consolidated statements of cash flows.

- changed (2016-10-27):
[0001628280-16-020392:note_history:18]
There have been no material changes in our significant accounting policies during the three months ended October 1, 2016 compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 2, 2016. The accompanying unaudited interim consolidated financial statements and accompanying related notes should be read in conjunction with the consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended July 2, 2016.
  (was, 2016-05-04, similarity 0.9324):
[0001628280-16-015527:note_history:18]
There have been no material changes in our significant accounting policies during the nine months ended April 2, 2016 compared to the significant accounting policies described in our Annual Report on Form 10-K/A for the fiscal year ended June 27, 2015. The accompanying unaudited interim consolidated financial statements and accompanying related notes should be read in conjunction with the consolidated financial statements and related notes included in our Annual Report on Form 10-K/A for the fiscal year ended June 27, 2015.

- removed (2016-10-27):
[0001628280-16-015527:note_history:19]
On July 31, 2015, prior to the Separation, Viavi transferred substantially all of the assets and liabilities and operations of the CCOP segment and WaveReady product lines to Lumentum (the “Capitalization"). Financial statements for periods prior to the Capitalization were prepared on a stand-alone basis and were derived from Viavi’s consolidated financial statements and accounting records. For the period from June 28, 2015 to August 1, 2015, expenses were allocated to us using estimates that we consider to be a reasonable reflection of the utilization of services provided to, or benefits received by, us.

- removed (2016-10-27):
[0001628280-16-015527:note_history:20]
Our consolidated financial statements have been prepared pursuant to the rules and regulations of the SEC and are in conformity with U.S. generally accepted accounting principles (“U.S. GAAP”). In the opinion of management, these consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments, which are necessary for a fair statement of the consolidated financial statements for the periods shown. The results of operations for such periods are not necessarily indicative of the results expected for the full year or for any future periods.

- removed (2016-10-27):
[0001628280-16-015527:note_history:21]
The consolidated financial statements include certain assets and liabilities that were historically held at the Viavi level which were specifically identifiable or otherwise attributable to us. All intra-company transactions within our business were eliminated. All material transactions between us and other businesses of Viavi prior to separation were reflected as net transfers to and from Viavi as a component of financing activities in the consolidated statement of cash flows.

- removed (2016-10-27):
[0001628280-16-015527:note_history:22]
Correction of Immaterial Error

- removed (2016-10-27):
[0001628280-16-015527:note_history:23]
During the three months ended April 2, 2016, we identified an error relating to stock-based compensation expense for the three months ended December 26, 2015 in which stock-based compensation expense of $1.0 million was excluded for a specific restricted stock grant. Additionally, we identified an error relating to the overstatement of sales and use tax accrual of $0.2 million and $0.3 million for the three months ended September 26, 2015 and December 26, 2015, respectively. During the three months ended December 26, 2015, we identified an error relating to the determination of the accretion amount of Series A preferred stock for the three months ended September 26, 2015 in which the accretion of the discount related to issuance cost of $2.0 million was excluded. As a result, our net loss attributable to common stockholders and basic and diluted net loss per share attributable to common stockholders included in our quarterly report on Form 10-Q ("Form 10-Q") for the three months ended September 26, 2015 was understated by $1.8 million and $0.03 per basic and diluted share, respectively. Our net income attributable to common stockholders and basic and diluted net income per share attributable to common stockholders included in Form 10-Q for the three months ended December 26, 2015 was understated by $1.3 million and $0.02 per basic and diluted share, respectively. The correction of the errors identified in the three months ended April 2, 2016 resulted in an overstatement of net loss per share attributable to common stockholders by $0.5 million and $0.01 per basic and diluted share.

- removed (2016-10-27):
[0001628280-16-015527:note_history:24]
We assessed the materiality of these errors and determined that the above errors were not material to our unaudited consolidated financial statements as of each of the periods mentioned above.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2016-10-27):
[0001628280-16-020392:note_history:25]
During the three months ended October 1, 2016 and September 26, 2015, the Company recognized revenue of $0.6 million and $0.8 million, respectively, from products sold to Viavi. During the three months ended October 1, 2016 and September 26, 2015, the Company recorded $0.4 million and $0.5 million, respectively, in research and development cost reimbursement and $0.2 million and $0.1 million, respectively, in sublease rental income. As of October 1, 2016 and July 2, 2016, the Company had $0.2 million and $1.1 million, respectively, in accounts receivable due from Viavi.

- changed (2016-10-27):
[0001628280-16-020392:note_history:26]
| a) | Contribution Agreement which identified the assets transferred, the liabilities assumed and the contracts assigned and which provided for when and how these transfers, assumptions and assignments would occur. |
  (was, 2016-05-04, similarity 0.7589):
[0001628280-16-015527:note_history:26]
| a) | Contribution Agreement which identifies the assets to be transferred, the liabilities to be assumed and the contracts to be assigned and it provides for when and how these transfers, assumptions and assignments will occur. |

- changed (2016-10-27):
[0001628280-16-020392:note_history:27]
From June 28, 2015 to August 1, 2015, the effective date of the Separation, the consolidated statements of operations included the Company's direct expenses for cost of sales, research and development, sales and marketing, and administration as well as allocations of expenses arising from shared services and infrastructure provided by Viavi to the Company. These allocated expenses include costs of information technology, human resources, accounting, legal, real estate and facilities, corporate marketing, insurance, treasury and other corporate and infrastructure services. In addition, other costs allocated to the Company include restructuring and stock-based compensation related to Viavi’s corporate and shared services employees and are included in the table below. These expenses were allocated to the Company using estimates that we consider to be a reasonable reflection of the utilization of services or benefits received by our business. The allocation methods include revenue, headcount, square footage, actual consumption and usage of services and others.
  (was, 2016-05-04, similarity 0.6258):
[0001628280-16-015527:note_history:27]
Through and up to August 1, 2015, the separation date, the consolidated statements of operations included our direct expenses for cost of sales, research and development, sales and marketing, and administration as well as allocations of expenses arising from shared services and infrastructure provided by Viavi to us. These allocated expenses include costs of information technology, human resources, accounting, legal, real estate and facilities, corporate marketing, insurance, treasury and other corporate and infrastructure services. In addition, other costs allocated to us include restructuring and stock-based compensation related to Viavi’s corporate and shared services employees and are included in the table below. These expenses were allocated to us using estimates that we consider to be a reasonable reflection of the utilization of services or benefits received by our business. The allocation methods include revenue, headcount, square footage, actual consumption and usage of services and others.

- changed (2016-10-27):
[0001628280-16-020392:note_history:28]
There were no allocations of expenses from Viavi for the three months ended October 1, 2016. During the three months ended September 26, 2015, allocated costs from Viavi included in the accompanying consolidated statements of operations  were as follows (in millions):
  (was, 2016-05-04, similarity 0.6033):
[0001628280-16-015527:note_history:28]
Allocated costs included in the accompanying consolidated statements of operations are as follows (in millions):

- added (2016-10-27):
[0001628280-16-020392:note_history:29]
|  | Three Months Ended |
|  | September 26, 2015 |
| Research and development | $ | — |  |
| Selling, general and administrative | 11.7 |  |
| Restructuring and related charges | — |  |
| Interest and other (income) expenses, net | (0.1 | ) |
| Interest expense | 0.1 |  |
| Total allocated costs | $ | 11.7 |  |

- added (2016-10-27):
[0001628280-16-020392:note_history:30]
Other Agreements

- added (2016-10-27):
[0001628280-16-020392:note_history:31]
We share and operate under agreements executed by Viavi with third parties, including but not limited to purchasing, manufacturing, and freight agreements; use of facilities owned, leased, and managed by Viavi; and software, technology and other intellectual property agreements.

- removed (2016-10-27):
[0001628280-16-015527:note_history:32]
Agreements with Viavi

- removed (2016-10-27):
[0001628280-16-015527:note_history:33]
On July 31, 2015, the Company entered into a Supply Agreement with Viavi providing that each party will supply certain products at pre-determined prices, and providing Viavi with research and development services at cost plus a specified markup. The Company also agreed to supply office space via a sublease agreement to Viavi. The sublease income and research and development cost reimbursements are each recorded as contra operating expenses in the Consolidated Statements of Operations for the three and nine months ended April 2, 2016.

- removed (2016-10-27):
[0001628280-16-015527:note_history:34]
The Supply Agreement contains a $15.0 million purchase commitment with Viavi for certain products, and for the three and nine months ended April 2, 2016, the Company purchased $6.8 million and $13.3 million, respectively, in product from Viavi against the $15.0 million purchase commitment. During the three and nine months ended April 2, 2016, the Company recognized revenue of $0.9 million and  $2.4 million, respectively, from products sold to Viavi. For the three and nine months ended April 2, 2016, the Company recorded $0.5 million and $1.7 million, respectively, in research and development cost reimbursement and $0.2 million and $0.5 million, respectively, in sublease rental income. As of April 2, 2016, the Company had $0.4 million in accounts receivable due from Viavi.

- removed (2016-10-27):
[0001628280-16-015527:note_history:35]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2016 |  | March 28, 2015 |  | April 2, 2016 |  | March 28, 2015 |
| Research and development | $ | — |  |  | $ | 0.2 |  |  | $ | — |  |  | $ | 0.2 |  |
| Selling, general and administrative | — |  |  | 20.0 |  |  | 11.7 |  |  | 56.6 |  |
| Restructuring and related charges | — |  |  | 0.6 |  |  | — |  |  | 3.8 |  |
| Interest and other (income) expenses, net | — |  |  | 0.1 |  |  | (0.1 | ) |  | 0.1 |  |
| Interest expense | — |  |  | 0.3 |  |  | 0.1 |  |  | 0.7 |  |
| Total allocated costs | $ | — |  |  | $ | 21.2 |  |  | $ | 11.7 |  |  | $ | 61.4 |  |


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2016-10-27):
[0001628280-16-020392:note_history:36]
During the three months ended September 26, 2015, allocated costs from Viavi included in the accompanying consolidated statements of operations  were as follows (in millions):
  (was, 2016-05-04, similarity 0.7929):
[0001628280-16-015527:note_history:36]
Allocated costs included in the accompanying consolidated statements of operations are as follows (in millions):

- added (2016-10-27):
[0001628280-16-020392:note_history:37]
|  | Three Months Ended |
|  | September 26, 2015 |
| Research and development | $ | — |  |
| Selling, general and administrative | 11.7 |  |
| Restructuring and related charges | — |  |
| Interest and other (income) expenses, net | (0.1 | ) |
| Interest expense | 0.1 |  |
| Total allocated costs | $ | 11.7 |  |

- removed (2016-10-27):
[0001628280-16-015527:note_history:38]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2016 |  | March 28, 2015 |  | April 2, 2016 |  | March 28, 2015 |
| Research and development | $ | — |  |  | $ | 0.2 |  |  | $ | — |  |  | $ | 0.2 |  |
| Selling, general and administrative | — |  |  | 20.0 |  |  | 11.7 |  |  | 56.6 |  |
| Restructuring and related charges | — |  |  | 0.6 |  |  | — |  |  | 3.8 |  |
| Interest and other (income) expenses, net | — |  |  | 0.1 |  |  | (0.1 | ) |  | 0.1 |  |
| Interest expense | — |  |  | 0.3 |  |  | 0.1 |  |  | 0.7 |  |
| Total allocated costs | $ | — |  |  | $ | 21.2 |  |  | $ | 11.7 |  |  | $ | 61.4 |  |
