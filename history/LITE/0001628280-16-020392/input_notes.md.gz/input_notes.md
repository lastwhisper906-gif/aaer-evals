# LITE notes — 0001628280-16-020392


## lite:PropertyPlantandEquipmentNetTableTextBlock

[0001628280-16-020392:notes:1]
[same as prior period, unchanged from 0001628280-16-015527:notes:1]

[0001628280-16-020392:notes:2]
|  | October 1, 2016 |  | July 2, 2016 |
| Land | $ | 5.9 |  |  | $ | 5.9 |  |
| Buildings and improvement | 29.0 |  |  | 28.9 |  |
| Machinery and equipment | 392.3 |  |  | 378.5 |  |
| Furniture and fixtures and software | 32.3 |  |  | 32.2 |  |
| Leasehold improvements | 28.8 |  |  | 28.6 |  |
| Construction in progress | 54.0 |  |  | 44.1 |  |
|  | 542.3 |  |  | 518.2 |  |
| Less: Accumulated depreciation | (346.3 | ) |  | (334.8 | ) |
| Property, plant and equipment, net | $ | 196.0 |  |  | $ | 183.4 |  |


## lite:ScheduleOfOtherLiabilitiesCurrentTableTextBlock

[0001628280-16-020392:notes:3]
[same as prior period, unchanged from 0001628280-16-015527:notes:3]

[0001628280-16-020392:notes:4]
|  | October 1, 2016 |  | July 2, 2016 |
| Warranty accrual | $ | 5.4 |  |  | $ | 2.8 |  |
| Restructuring accrual and related charges | 5.1 |  |  | 5.5 |  |
| Others | 3.9 |  |  | 3.8 |  |
| Other current liabilities | $ | 14.4 |  |  | $ | 12.1 |  |


## lite:ScheduleOfOtherLiabilitiesNoncurrentTableTextBlock

[0001628280-16-020392:notes:5]
[same as prior period, unchanged from 0001628280-16-015527:notes:5]

[0001628280-16-020392:notes:6]
|  | October 1, 2016 |  | July 2, 2016 |
| Asset retirement obligation | $ | 2.3 |  |  | $ | 2.3 |  |
| Pension and related accrual | 3.5 |  |  | 3.5 |  |
| Deferred rent | 1.5 |  |  | 1.6 |  |
| Restructuring accrual and related charges | 0.2 |  |  | 0.2 |  |
| Other non-current liabilities | 2.0 |  |  | 1.5 |  |
| Other non-current liabilities | $ | 9.5 |  |  | $ | 9.1 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001628280-16-020392:notes:7]
Note 6. Balance Sheet and Other Details

[0001628280-16-020392:notes:8]
[same as prior period, unchanged from 0001628280-16-015527:notes:8]

[0001628280-16-020392:notes:9]
As of October 1, 2016 and July 2, 2016, our accounts receivable allowance balance was $1.4 million and $0.9 million, respectively.

[0001628280-16-020392:notes:10]
[same as prior period, unchanged from 0001628280-16-015527:notes:10]

[0001628280-16-020392:notes:11]
[same as prior period, unchanged from 0001628280-16-015527:notes:11]

[0001628280-16-020392:notes:12]
|  | October 1, 2016 |  | July 2, 2016 |
| Finished goods | $ | 45.8 |  |  | $ | 46.1 |  |
| Work in process | 26.6 |  |  | 25.5 |  |
| Raw materials and purchased parts | 31.3 |  |  | 29.0 |  |
| Inventories | $ | 103.7 |  |  | $ | 100.6 |  |

[0001628280-16-020392:notes:13]
[same as prior period, unchanged from 0001628280-16-015527:notes:15]

[0001628280-16-020392:notes:14]
[same as prior period, unchanged from 0001628280-16-015527:notes:16]

[0001628280-16-020392:notes:15]
|  | October 1, 2016 |  | July 2, 2016 |
| Prepayments | $ | 41.2 |  |  | $ | 33.7 |  |
| Advances to contract manufacturers | 9.6 |  |  | 10.3 |  |
| Due from (to) Viavi, net | — |  |  | 2.0 |  |
| Other current assets | 11.5 |  |  | 15.3 |  |
| Prepayments and other current assets | $ | 62.3 |  |  | $ | 61.3 |  |

[0001628280-16-020392:notes:16]
Amount due from (to) Viavi, net represents certain obligations to be reimbursed from Viavi, net of payables, pursuant to the Separation and Distribution Agreement and Contribution Agreement.

[0001628280-16-020392:notes:17]
[same as prior period, unchanged from 0001628280-16-015527:notes:19]

[0001628280-16-020392:notes:18]
During the three months ended October 1, 2016 and September 26, 2015, we recorded depreciation expense of $11.9 million and $11.7 million, respectively. Our construction in progress includes primarily machinery and equipment that was purchased to increase our manufacturing capacity. We expect to place these assets in service in next 12 months.

[0001628280-16-020392:notes:19]
[same as prior period, unchanged from 0001628280-16-015527:notes:20]

[0001628280-16-020392:notes:20]
[same as prior period, unchanged from 0001628280-16-015527:notes:21]


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001628280-16-020392:notes:21]
[same as prior period, unchanged from 0001628280-16-015527:notes:22]

[0001628280-16-020392:notes:22]
Lumentum was incorporated in Delaware as a wholly owned subsidiary of JDS Uniphase ("JDSU") on February 10, 2015 and is comprised of the former communications and commercial optical products (“CCOP”) segment and WaveReady product lines of JDSU.

[0001628280-16-020392:notes:23]
On July 31, 2015, prior to the Separation (as described below), JDSU transferred substantially all of the assets and liabilities and operations of the CCOP segment and WaveReady product lines to Lumentum. Financial statements for periods prior to the Separation were prepared on a stand-alone basis and were derived from JDSU’s consolidated financial statements and accounting records. The Company prepared consolidated financial statements for the period from June 28, 2015 to August 1, 2015 where expenses were allocated to the Company using estimates that it considers to be a reasonable reflection of the utilization of services provided to, or benefits received by, the Company. Since August 1, 2015, the Company has prepared consolidated financial statements as an independent stand-alone basis pursuant to the rules and regulations of the SEC and are in conformity with U.S. GAAP. In the opinion of management, these consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments, which are necessary for a fair statement of the consolidated financial statements for the periods shown. The results of operations for such periods are not necessarily indicative of the results expected for the full year or for any future periods.

[0001628280-16-020392:notes:24]
On August 1, 2015, Lumentum became an independent publicly-traded company through the distribution by JDSU to its stockholders of 80.1% of our outstanding common stock (the “Separation”). Each JDSU stockholder of record as of the close of business on July 27, 2015 received one share of Lumentum common stock for every five shares of JDSU common stock held on the record date. JDSU was renamed Viavi Solutions Inc. ("Viavi") and at the time of the distribution retained ownership of 19.9% of Lumentum’s outstanding shares. Lumentum’s Registration Statement on Form 10 was declared effective by the SEC on July 16, 2015. Lumentum’s common stock began trading “regular-way” under the ticker “LITE” on the NASDAQ stock market on August 4, 2015.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001628280-16-020392:notes:25]
[same as prior period, unchanged from 0001628280-16-015527:notes:31]

[0001628280-16-020392:notes:26]
[same as prior period, unchanged from 0001628280-16-015527:notes:32]

[0001628280-16-020392:notes:27]
Lumentum Holdings Inc. ("we", "our", "Lumentum" or the "Company") is an industry leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including data communications ("Datacom") and telecommunications ("Telecom") networking and commercial lasers ("commercial lasers") for manufacturing, inspection and life-science applications. We are using our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including 3-D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be original equipment manufacturers ("OEMs") that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that our network equipment manufacturer ("NEM") customers assemble into communications networking systems, which they sell to network service providers or enterprises with their own networks. Similarly, many of our customers for our Lasers products incorporate our products into tools they produce, which are used for manufacturing processes by their customers.

[0001628280-16-020392:notes:28]
The preparation of the consolidated financial statements in accordance with GAAP in the United States requires management to make estimates and assumptions that affect the amounts reported in our consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, inventory valuation, allocation methods and allocated expenses from Viavi, valuation of goodwill and other intangible assets, stock-based compensation, retirement and post-retirement plan assumptions, restructuring, warranty and accounting for income taxes.

[0001628280-16-020392:notes:29]
See "Note 3. Related Party Transactions" in the Notes to Consolidated Financial Statements regarding the relationships we had with Viavi.

[0001628280-16-020392:notes:30]
[same as prior period, unchanged from 0001628280-16-015527:notes:34]

[0001628280-16-020392:notes:31]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Our fiscal 2017 is a 52-week year ending on July 1, 2017. Our fiscal 2016 was a 53-week year ended on July 2, 2016.

[0001628280-16-020392:notes:32]
[same as prior period, unchanged from 0001628280-16-015527:notes:36]

[0001628280-16-020392:notes:33]
These unaudited interim consolidated financial statements include the accounts of the Company and its wholly-owned subsidiaries. All intra-company transactions and balances within our business were eliminated. All material transactions between us and other businesses of Viavi prior to Separation were reflected as net transfers to and from Viavi as a component of financing activities in the consolidated statements of cash flows.

[0001628280-16-020392:notes:34]
[same as prior period, unchanged from 0001628280-16-015527:notes:38]

[0001628280-16-020392:notes:35]
The preparation of our consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amount of assets and liabilities at the date of the financial statements, the reported amount of net revenue and expenses and the disclosure of commitments and contingencies during the reporting periods. We base estimates on historical experience and on various assumptions about the future believed to be reasonable based on available information. Our reported financial position or results of operations may be materially different under changed conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies. If estimates or assumptions differ from actual results, subsequent periods are adjusted to reflect more current information.

[0001628280-16-020392:notes:36]
[same as prior period, unchanged from 0001628280-16-015527:notes:40]

[0001628280-16-020392:notes:37]
There have been no material changes in our significant accounting policies during the three months ended October 1, 2016 compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 2, 2016. The accompanying unaudited interim consolidated financial statements and accompanying related notes should be read in conjunction with the consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended July 2, 2016.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001628280-16-020392:notes:38]
Note 13. Commitments and Contingencies

[0001628280-16-020392:notes:39]
Operating Leases

[0001628280-16-020392:notes:40]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2026. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. As of October 1, 2016 the future minimum annual lease payments under non-cancellable operating leases were as follows (in millions):

[0001628280-16-020392:notes:41]
| Remainder of 2017 | $ | 5.0 |  |
| 2018 | 5.6 |  |
| 2019 | 3.9 |  |
| 2020 | 2.8 |  |
| 2021 | 1.7 |  |
| Thereafter | 3.9 |  |
| Total minimum operating lease payments | $ | 22.9 |  |

[0001628280-16-020392:notes:42]
Included in the future minimum lease payments table above is $0.5 million related to lease commitments in connection with our restructuring and related activities. Refer to "Note 10. Restructuring and Related Charges" in the Notes to Consolidated Financial Statements.

[0001628280-16-020392:notes:43]
Rental expense was $2.2 million and $1.5 million for the three months ended October 1, 2016 and September 26, 2015, respectively.

[0001628280-16-020392:notes:44]
Purchase Obligations

[0001628280-16-020392:notes:45]
Purchase obligations of $125.4 million as of October 1, 2016, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001628280-16-020392:notes:46]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with such vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

[0001628280-16-020392:notes:47]
Product Warranties

[0001628280-16-020392:notes:48]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, product component or application of our products by the end customer, our warranties can vary and generally range from six months to 5 years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001628280-16-020392:notes:49]
The following table presents the changes in our warranty reserve during the three months ended October 1, 2016 and September 26, 2015 (in millions):

[0001628280-16-020392:notes:50]
|  | Three months ended |
|  | October 1, 2016 |  | September 26, 2015 |
| Balance as of beginning of period | $ | 2.8 |  |  | $ | 2.8 |  |
| Provision for warranty | 3.8 |  |  | 0.9 |  |
| Utilization of reserve | (1.2 | ) |  | (1.2 | ) |
| Balance as of period end | $ | 5.4 |  |  | $ | 2.5 |  |

[0001628280-16-020392:notes:51]
Environmental Liabilities

[0001628280-16-020392:notes:52]
Our R&D, manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental, product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001628280-16-020392:notes:53]
In connection with the Separation, we agreed to indemnify Viavi for any liability associated with contamination from past operations at all properties transferred to us from Viavi, to the extent the resulting issues primarily related to our business.

[0001628280-16-020392:notes:54]
Legal Proceedings

[0001628280-16-020392:notes:55]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management's view of these matters may change in the future. Were an unfavorable final outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the effect becomes reasonably estimable.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-16-020392:notes:56]
Note 5. Accumulated Other Comprehensive Income (Loss)

[0001628280-16-020392:notes:57]
Our accumulated other comprehensive income (loss) consists of the accumulated net unrealized gains or losses on foreign currency translation adjustments and defined benefit obligation.

[0001628280-16-020392:notes:58]
As of October 1, 2016 and July 2, 2016, balances for the components of accumulated other comprehensive income were as follows (in millions):

[0001628280-16-020392:notes:59]
|  | Foreign currency translation adjustments |  | Defined benefit obligation, net of tax |  | Total |
| Beginning balance as of July 2, 2016 | $ | 11.7 |  |  | $ | (2.3 | ) |  | $ | 9.4 |  |
| Other comprehensive loss | (0.9 | ) |  | — |  |  | (0.9 | ) |
| Ending balance as of October 1, 2016 | $ | 10.8 |  |  | $ | (2.3 | ) |  | 8.5 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001628280-16-020392:notes:60]
[same as prior period, unchanged from 0001628280-16-015527:notes:66]

[0001628280-16-020392:notes:61]
We estimate the fair value of the embedded derivative for the Series A Preferred Stock using the binomial lattice model. We applied the binomial lattice model to value the embedded derivative using a "with-and-without method," where the value of the Series A Preferred Stock including the embedded derivative, is defined as the "with", and the value of the Series A Preferred Stock excluding the embedded derivative, is defined as the "without". This method estimates the value of the embedded derivative by looking at the difference in the values between the Series A Preferred Stock with the embedded derivative and the value of the Series A Preferred Stock without the embedded derivative. The lattice model requires the following inputs: (i) the Company's common stock price; (ii) conversion price; (iii) term; (iv) yield; (v) recovery rate; (vi) estimated stock volatility; and (vii) risk-free rate. The fair value of the embedded derivative was determined using level 3 inputs under the fair value hierarchy (unobservable inputs). Changes in the inputs into this valuation model have a material impact in the estimated fair value of the embedded derivative. For example, a decrease (increase) in the stock price results in a decrease (increase) in the estimated fair value of the embedded derivative. The changes in the fair value of the bifurcated embedded derivative of $(22.7) million for the three months ended October 1, 2016 is primarily related to the change in the price of the Company's underlying common stock and is reflected in the consolidated statements of operations as "Unrealized loss on derivative liability".

[0001628280-16-020392:notes:62]
The following table provides a reconciliation of the fair value of the embedded derivative for the Series A Preferred Stock measured by significant unobservable inputs (Level 3) for the three months ended October 1, 2016:

[0001628280-16-020392:notes:63]
|  |  | Balance as of (in millions) |
|  |  | October 1, 2016 |
| Balance as of beginning of period |  | $ | 10.3 |  |
| Unrealized loss included in net loss |  | 22.7 |  |
| Balance as of end of period |  | $ | 33.0 |  |

[0001628280-16-020392:notes:64]
|  |  | October 1, 2016 |
| Stock price |  | $ | 41.77 |  |
| Conversion price |  | $ | 24.63 |  |
| Expected term (years) |  | 3.86 |  |
| Expected annual volatility |  | 40.0 | % |
| Risk-free rate |  | 1.10 | % |
| Expected common dividend yield |  | — | % |
| Preferred yield |  | 8.23 | % |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-16-020392:notes:65]
Note 12. Stock-Based Compensation and Stock Plans

[0001628280-16-020392:notes:66]
Description of Lumentum Stock-Based Benefit Plans

[0001628280-16-020392:notes:67]
Stock Option Plans

[0001628280-16-020392:notes:68]
On June 23, 2015, the board of directors of JDS Uniphase Corporation (“JDSU” and, now, Viavi Solutions Inc.) approved, and subsequently, our sole stockholder adopted, the 2015 Equity Incentive Plan (the "2015 Plan") under which 8.5 million shares of our Common Stock were authorized for issuance. The 2015 Plan was ratified by the Company’s board of directors in August 2015.  In connection with our Separation from JDSU on July 31, 2015, outstanding JDSU equity-based awards, held by employees continuing employment with the Company after the Separation, were converted into equity-based awards under the 2015 Plan, reducing the number of shares remaining available for grant under the 2015 Plan.  As of immediately following our Separation from JDSU, 2.1 million shares of our Common Stock were subject to outstanding equity-based awards under the 2015 Plan that were converted from JDSU equity-based awards.

[0001628280-16-020392:notes:69]
As of October 1, 2016, the Company had 2.7 million stock options, performance stock units, restricted stock awards, and restricted stock units outstanding under the 2015 Plan. Performance stock units, restricted stock awards, and restricted stock units are performance-based, time-based or a combination of both and are expected to vest over one to four years. The fair value of the time-based performance stock units, restricted stock awards, or restricted stock units is based on the closing market price of the Company’s common stock on the date of award.

[0001628280-16-020392:notes:70]
The exercise price for stock options is equal to the fair value of the underlying stock at the date of grant. The Company issues new shares of common stock upon exercise of stock options. Options generally become exercisable over a three-year or four-year period and, if not exercised, expire from five to ten years after the date of grant. As of October 1, 2016, 4.3 million shares of common stock under the 2015 Plan were available for grant.

[0001628280-16-020392:notes:71]
Employee Stock Purchase Plan

[0001628280-16-020392:notes:72]
On June 23, 2015, the board of directors of JDSU approved, and subsequently, our sole stockholder adopted, the 2015 Employee Stock Purchase Plan (the “2015 Purchase Plan”) under which 3.0 million shares of our Common Stock were authorized for issuance. The 2015 Purchase Plan was ratified by our board of directors on July 31, 2015. The 2015 Purchase Plan provides eligible employees with the opportunity to acquire an ownership interest in the Company through periodic payroll deductions and provides a 15% purchase price discount as well as a six-month look-back period. The 2015 Purchase Plan is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986. However, the 2015 Purchase Plan is not intended to be a qualified pension, profit sharing or stock bonus plan under Section 401(a) of the Internal Revenue Code of 1986 and is not subject to the provisions of the Employee Retirement Income Security Act of 1974. The 2015 Purchase Plan will terminate upon the date on which all shares available for issuance have been sold. Of the 3.0 million shares authorized under the 2015 Purchase Plan, 2.8 million shares remained available for issuance as of October 1, 2016.

[0001628280-16-020392:notes:73]
Restricted Stock Units

[0001628280-16-020392:notes:74]
Each restricted stock unit (“RSU”) granted is a bookkeeping entry representing an amount equal to the fair market value of one share. RSUs result in a payment to a holders if any performance goals or other vesting criteria are achieved or the awards otherwise vest.  The administrator determines in its sole discretion whether an award will be settled in stock, cash, or a combination of both.

[0001628280-16-020392:notes:75]
Generally, our RSUs have service conditions, performance conditions, or a combination of both and are expected to vest over one to four years. The fair value of the time-based RSUs is based on the closing market price of the common stock on the date of award.

[0001628280-16-020392:notes:76]
Restricted Stock Awards

[0001628280-16-020392:notes:77]
Restricted stock awards are grants of shares of our common stock that are subject to various restrictions, including restrictions on transferability and forfeiture provisions. Restricted stock awards are expected to vest over one to four years, and the shares acquired may not be transferred by the holder until the vesting conditions (if any) are satisfied.

[0001628280-16-020392:notes:78]
Stock-Based Compensation

[0001628280-16-020392:notes:79]
The impact on our results of operations of recording stock-based compensation by function for the three months ended October 1, 2016 and September 26, 2015 was as follows (in millions):

[0001628280-16-020392:notes:80]
|  | Three Months Ended |
|  | October 1, 2016 |  | September 26, 2015 |
| Cost of sales | $ | 1.9 |  |  | $ | 1.2 |  |
| Research and development | 2.8 |  |  | 1.9 |  |
| Selling, general and administrative | 3.0 |  |  | 3.4 |  |
|  | 7.7 |  |  | 6.5 |  |

[0001628280-16-020392:notes:81]
Approximately $1.0 million and $1.2 million of stock-based compensation was capitalized to inventory as of October 1, 2016 and July 2, 2016, respectively. The table above includes allocated stock-based compensation from Viavi of $0.5 million for the three months ended September 26, 2015. There were no allocations to stock-based compensation from Viavi for the three months ended October 1, 2016. Refer to "Note 3. Related Party Transactions" in the Notes to Consolidated Financial Statements.

[0001628280-16-020392:notes:82]
Stock Option, Restricted Stock Awards, and Restricted Stock Units Activity

[0001628280-16-020392:notes:83]
We granted no stock options during the three months ended October 1, 2016. The total intrinsic value of options exercised by our employees during the three months ended October 1, 2016 and September 26, 2015 was $3.1 million and $0.1 million, respectively.

[0001628280-16-020392:notes:84]
In connection with these exercises, the tax benefit realized by us was immaterial due to the fact that Lumentum has no material tax benefit in foreign jurisdictions and a full valuation allowance on its domestic deferred tax assets.

[0001628280-16-020392:notes:85]
As of October 1, 2016, $63.9 million of stock-based compensation cost related to RSUs granted to our employees remains to be amortized. That cost is expected to be recognized over an estimated amortization period of 2.18 years.

[0001628280-16-020392:notes:86]
The following table summarizes our stock option, RSA, and RSU activities during the three months ended October 1, 2016 (amount in millions except per share amounts):

[0001628280-16-020392:notes:87]
|  | Options Outstanding |  | Restricted Stock Units/Awards Outstanding |
|  | Number of Shares |  | Weighted-Average Exercise Price |  | Number of Shares (PSU) |  | Number of Shares(RSU/RSA) |  | Weighted-Average Grant Date Fair Value |
| Outstanding as of July 2, 2016, as converted | 0.3 |  |  | $ | 17.83 |  |  | 0.1 |  |  | 2.5 |  |  | $ | 21.04 |  |
| Granted | — |  |  | — |  |  | — |  |  | 1.1 |  |  | 32.74 |  |
| Exercised / Vested | (0.2 | ) |  | 14.92 |  |  | (0.1 | ) |  | (0.6 | ) |  | 21.11 |  |
| Canceled | — |  |  | — |  |  | — |  |  | (0.1 | ) |  | 21.83 |  |
| Outstanding as of October 1, 2016 | 0.1 |  |  | $ | 22.06 |  |  | — |  |  | 2.9 |  |  | 25.53 |  |
| Vested and expected to vest | 0.1 |  |  | $ | 22.06 |  |  | — |  |  | 2.2 |  |  | 24.30 |  |

[0001628280-16-020392:notes:88]
Employee Stock Purchase Plan Activity

[0001628280-16-020392:notes:89]
The ESPP expense we recorded for the three months ended October 1, 2016 was $0.5 million. The expense related to the plan is recorded on a straight-line basis over the relevant subscription period. During the three months ended October 1, 2016, there were no shares issued to employees through the ESPP program.


## us-gaap:EarningsPerShareTextBlock

[0001628280-16-020392:notes:90]
[same as prior period, unchanged from 0001628280-16-015527:notes:88]

[0001628280-16-020392:notes:91]
The following table sets forth the computation of basic and diluted net income (loss) per share (in millions, except per share data):

[0001628280-16-020392:notes:92]
|  | Three Months Ended |
|  | October 1, 2016 |  | September 26, 2015 |
| Numerator: |  |  |  |  |  |
| Net income (loss) | $ | (3.4 | ) |  | $ | (0.2 | ) |
| Less: Cumulative dividends on Series A Preferred Stock | (0.2 | ) |  | (0.1 | ) |
| Less: Accretion of Series A Preferred Stock | — |  |  | (9.7 | ) |
| Net income (loss) attributable to common stockholders | (3.6 | ) |  | (10.0 | ) |
| Denominator: |  |  |  |
| Weighted-average number of common shares outstanding |  |  |  |
| Basic | 59.9 |  |  | 58.8 |  |
| Diluted | 59.9 |  |  | 58.8 |  |
| Net income (loss) per share attributable to common stockholders: |  |  |  |
| Basic | $ | (0.06 | ) |  | $ | (0.17 | ) |
| Diluted | $ | (0.06 | ) |  | $ | (0.17 | ) |

[0001628280-16-020392:notes:93]
On August 1, 2015, JDSU distributed 47.1 million shares, or 80.1% of the outstanding shares of the Company's common stock to existing holders of JDSU common stock. The weighted average number of common stock outstanding is calculated as the number of shares of common stock outstanding immediately following the Separation through September 26, 2015, and the weighted average number of shares outstanding following the Separation through October 1, 2016. Diluted earnings per share is calculated by dividing net income for the period by the weighted average number of shares of common stock and potentially dilutive common stock outstanding for the period beginning after the Separation.

[0001628280-16-020392:notes:94]
The dilutive effect of stock-based awards is reflected in diluted earnings per share by application of the treasury stock method, which includes consideration of unamortized share-based compensation expense, the tax benefits or shortfalls recorded to additional paid-in capital and the dilutive effect of in-the-money options and non-vested restricted stock units. Under the treasury stock method, the amount the employee must pay for exercising stock options and unamortized share-based compensation expense and tax benefits or shortfalls collectively are assumed proceeds to be used to repurchase hypothetical shares. An increase in the fair value of the Company's common stock can result in a greater dilutive effect from potentially dilutive awards.

[0001628280-16-020392:notes:95]
[same as prior period, unchanged from 0001628280-16-015527:notes:93]

[0001628280-16-020392:notes:96]
For the three months ended October 1, 2016, 2.5 million weighted average shares were excluded from the calculation of diluted shares because their inclusion would have been antidilutive.


## us-gaap:FiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0001628280-16-020392:notes:97]
The following table presents details of our amortization (in millions):

[0001628280-16-020392:notes:98]
|  | Three Months Ended |
|  | October 1, 2016 |  | September 26, 2015 |
| Cost of sales | $ | 1.7 |  |  | $ | 1.7 |  |
| Operating expense | 0.1 |  |  | 0.1 |  |
| Total | $ | 1.8 |  |  | $ | 1.8 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001628280-16-020392:notes:99]
[same as prior period, unchanged from 0001628280-16-015527:notes:99]

[0001628280-16-020392:notes:100]
[same as prior period, unchanged from 0001628280-16-015527:notes:100]

[0001628280-16-020392:notes:101]
The following table presents the changes in goodwill by operating segments during the three months ended October 1, 2016 (in millions):

[0001628280-16-020392:notes:102]
|  |  | Optical Communications |  | Commercial Lasers |  | Total |
| Balance as of July 2, 2016 | $ | — |  |  | $ | 5.4 |  |  | $ | 5.4 |  |
|  | Currency translation | — |  |  | — |  |  | — |  |
| Balance as of October 1, 2016 | $ | — |  |  | $ | 5.4 |  |  | $ | 5.4 |  |

[0001628280-16-020392:notes:103]
Impairment of Goodwill

[0001628280-16-020392:notes:104]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. In the fourth quarter of fiscal 2016, we completed the annual impairment test of goodwill, which indicated there was no goodwill impairment. During the three months ended October 1, 2016, there have been no events or circumstances that have required us to perform an interim assessment of goodwill for impairment.

[0001628280-16-020392:notes:105]
[same as prior period, unchanged from 0001628280-16-015527:notes:104]

[0001628280-16-020392:notes:106]
[same as prior period, unchanged from 0001628280-16-015527:notes:105]

[0001628280-16-020392:notes:107]
| As of October 1, 2016 | Gross Carrying Amount |  | Accumulated Amortization |  | Net |
| Acquired developed technology | $ | 103.0 |  |  | $ | (90.6 | ) |  | $ | 12.4 |  |
| Other | 9.4 |  |  | (9.1 | ) |  | 0.3 |  |
| Total Intangibles | $ | 112.4 |  |  | $ | (99.7 | ) |  | $ | 12.7 |  |

[0001628280-16-020392:notes:108]
| As of July 2, 2016 | Gross Carrying Amount |  | Accumulated Amortization |  | Net |
| Acquired developed technology | $ | 103.0 |  |  | $ | (88.9 | ) |  | $ | 14.1 |  |
| Other | 9.4 |  |  | (9.0 | ) |  | 0.4 |  |
| Total Intangibles | $ | 112.4 |  |  | $ | (97.9 | ) |  | $ | 14.5 |  |

[0001628280-16-020392:notes:109]
During the three months ended October 1, 2016 and September 26, 2015, we recorded $1.8 million and $1.8 million, respectively, of amortization related to acquired developed technology and other intangibles. The following table presents details of our amortization (in millions):

[0001628280-16-020392:notes:110]
Based on the carrying amount of acquired developed technology and other intangibles as of October 1, 2016, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001628280-16-020392:notes:111]
| Remainder of 2017 | $ | 4.8 |  |
| 2018 | 2.8 |  |
| 2019 | 2.6 |  |
| 2020 | 2.5 |  |
| Thereafter | — |  |
| Total amortization | $ | 12.7 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-16-020392:notes:112]
[same as prior period, unchanged from 0001628280-16-015527:notes:112]

[0001628280-16-020392:notes:113]
The Company recorded a tax benefit of $2.3 million and $0.3 million for the three months ended October 1, 2016, and September 26, 2015, respectively. The quarterly provision for income taxes is based on the estimated annual effective tax rate, plus any discrete items for the respective year.  The Company updates its estimated annual effective tax rate at the end of each quarterly period. The estimate takes into account the estimates for annual pre-tax income, the geographic mix of pre-tax income and interpretations of tax laws.

[0001628280-16-020392:notes:114]
The benefit for income taxes for the three months ended October 1, 2016 was primarily due to an increase of profit in jurisdictions with lower tax rates, utilization of U.S. tax attributes that were subject to a full valuation allowance, certain Canadian tax incentives, and a net benefit of $0.5 million of true-up adjustments in our foreign jurisdictions.  The benefit for income taxes for the three months ended September 26, 2015 was primarily attributable to the utilization of US tax attributes that were subject to a full valuation allowance, and certain Canadian tax incentives.

[0001628280-16-020392:notes:115]
The Company’s net deferred tax assets relate predominantly to the Canadian tax jurisdiction and the Company has a partial valuation allowance against these deferred tax assets. The Company weighed both positive and negative evidence and determined that due to the limited carryover period of certain tax attributes in Canada, there is a continued need for a partial valuation allowance against these deferred tax assets as of October 1, 2016. Should the Company determine that it needs to adjust the valuation allowance, the adjustment may have a material impact to net income in the period such determination is made.

[0001628280-16-020392:notes:116]
The Company also evaluates the ability to realize its U.S. net deferred tax assets based on all available evidence, both positive and negative, on a quarterly basis. The realization of net deferred tax assets is dependent on the Company’s ability to generate sufficient future taxable income during periods prior to the expiration of tax attributes to fully utilize these assets. The Company weighed both positive and negative evidence and determined that due to cumulative losses in the United States, there is a continued need for a full valuation allowance against the U.S. deferred tax assets as of October 1, 2016.

[0001628280-16-020392:notes:117]
At October 1, 2016 and September 26, 2015, the Company had $0.8 million and $0.1 million of liability for unrecognized tax benefits, respectively, which, if recognized, would affect the effective tax rate.

[0001628280-16-020392:notes:118]
The Company is routinely subject to various federal, state and foreign audits by taxing authorities. The timing for the resolution and closure of tax audits is highly unpredictable. Given the uncertainty, it is reasonably possible that certain tax audits may be concluded within the next 12 months that could materially impact the balance of our gross unrecognized tax benefits. An estimate of the range of increase or decrease that could occur in the next twelve months cannot be made. However, the estimated impact to tax expense and net income from the resolution and closure of tax exams is not expected to be significant within the next 12 months.

[0001628280-16-020392:notes:119]
On October 4, 2016, the Company received a notice of reassessment letter related to an on-going tax audit in one of the foreign jurisdictions for tax years prior to the separation from Viavi. As part of the indemnification agreement entered into with Viavi, the Company will be indemnified for any tax liability assessed.

[0001628280-16-020392:notes:120]
In addition, the Company is in the process of evaluating its international operational footprint, which could result in future changes to the Company’s legal entity structure and operating model. A wholly-owned foreign subsidiary of the Company acquired certain rights to sell the existing products and also those products to be developed or licensed in the future, and will also share in the research and development cost. The existing rights were transferred to its wholly-owned foreign subsidiary prior to the Separation. As a result of these changes, the Company expects that an increasing percentage of its consolidated pre-tax income will be derived from, and reinvested in, its foreign operations. The Company anticipates that this pre-tax income will be subject to foreign tax at relatively lower tax rates when compared to the U.S. federal statutory tax rate and as a consequence, the Company’s effective income tax rate is expected to be lower than the U.S. federal statutory rate.


## us-gaap:MinorityInterestDisclosureTextBlock

[0001628280-16-020392:notes:121]
Note 7. Non-Controlling Interest Redeemable Convertible Preferred Stock

[0001628280-16-020392:notes:122]
On July 31, 2015, our wholly-owned subsidiary, Lumentum Inc., issued 40,000 shares of its Series A Preferred Stock to Viavi. Pursuant to a securities purchase agreement between the Company, Viavi and Amada, 35,805 shares of Series A Preferred Stock were sold by Viavi to Amada in August 2015. The remaining 4,195 shares of the Series A Preferred Stock were canceled. The Series A Preferred Stock is referred to as our Non-Controlling Interest Redeemable Convertible Preferred Stock within these consolidated financial statements.

[0001628280-16-020392:notes:123]
The Series A Preferred Stock is redeemable at the option of Amada after five years and classified as mezzanine equity in our consolidated balance sheet.  The Series A Preferred Stock is measured at its redemption value.  The Series A Preferred Stock value of $35.8 million has not changed from prior period. The Series A Preferred Stock conversion feature is bifurcated from the Series A Preferred Stock and accounted for separately as a derivative liability.  The derivative liability is measured at fair value each reporting period with the change in fair value recorded in the consolidated statements of operations.

[0001628280-16-020392:notes:124]
The following paragraphs describe the terms and conditions of the Series A Preferred Stock:

[0001628280-16-020392:notes:125]
Conversion

[0001628280-16-020392:notes:126]
The Series A Preferred Stock is convertible, at the option of the holder, into shares of our common stock commencing on the second anniversary of the closing of the securities purchase (absent a change of control of us or similar event) using a conversion price of $24.63, which is equal to 125% of the volume weighted average price per share of our common stock in the five “regular-way” trading days following the Separation.

[0001628280-16-020392:notes:127]
Liquidation

[0001628280-16-020392:notes:128]
Upon any liquidation, dissolution, or winding up of our business, whether voluntary or involuntary, holders of Series A Preferred Stock will be entitled to receive, in preference to holders of common stock or any other class or series of our outstanding capital stock ranking in any such event junior to the Series A Preferred Stock, an amount per share equal to the greater of (i) the Issuance Value of $1,000 per share for Series A Preferred Stock plus all accrued and unpaid dividends thereon (whether or not authorized or declared) through the date of payment and (ii) the amount as would have been payable had all Series A Preferred Stock been converted into common stock immediately prior to such liquidation event.

[0001628280-16-020392:notes:129]
If upon occurrence of any such event, our assets legally available for distribution are insufficient to permit payment of the aforementioned preferential amounts, then all of our assets legally available for distribution will be distributed ratably to the holders of the Series A Preferred Stock and to the holders of any other class or series of our capital stock ranking on parity with the Series A Preferred Stock.

[0001628280-16-020392:notes:130]
Voting Rights

[0001628280-16-020392:notes:131]
| • | The Series A Preferred Stock have no voting rights except as follows: |

[0001628280-16-020392:notes:132]
| • | Authorize, approve, or make any change to the powers, preferences, privileges or rights of the Series A Preferred Stock; |

[0001628280-16-020392:notes:133]
| • | Authorize or issue any additional shares of Series A Preferred Stock or reduce the number of shares of Series A Preferred Stock; or |

[0001628280-16-020392:notes:134]
| • | Create, or hold capital stock in, any subsidiary that is not wholly-owned by the Company. |

[0001628280-16-020392:notes:135]
Dividends

[0001628280-16-020392:notes:136]
Holders of Series A Preferred Stock, in preference to holders of common stock or any other class or series of our outstanding capital stock ranking in any such event junior to the Series A Preferred Stock, are entitled to receive, when and as declared by the board of directors, quarterly cumulative cash dividends at the annual rate of 2.5% of the Issuance Value per share on each outstanding share of Series A Preferred Stock. The accrued dividends are payable on March 31, June 30, September 30 and December 31 of each year commencing on September 30, 2015.

[0001628280-16-020392:notes:137]
The accrued dividends as of October 1, 2016 are $0.2 million.

[0001628280-16-020392:notes:138]
Redemption

[0001628280-16-020392:notes:139]
Optional redemption by the Company

[0001628280-16-020392:notes:140]
On or after the third anniversary, we will have the option to redeem for cash all (but not less than all) of the shares of Series A Preferred Stock at a redemption price equal to the Issuance Value plus the accrued and unpaid dividends on each share and any past due dividends, whether or not authorized or declared.

[0001628280-16-020392:notes:141]
Optional redemption by holders

[0001628280-16-020392:notes:142]
Commencing on the fifth anniversary of the Issuance Date, each holder of Series A Preferred Stock may cause the Company to redeem for cash any number of shares of Series A Preferred Stock on any date at a redemption price for share redeemed equal to the Issuance Value plus the accrued and unpaid dividends on each share and any past due dividends, whether or not authorized or declared.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001628280-16-020392:notes:143]
In August 2016, the Financial Accounting Standards Board (FASB) issued ASU 2016-15, Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments (ASU 2016-15), which clarifies how companies present and classify certain cash receipts and cash payments in the statement of cash flows. ASU 2016-15 is effective for us in our first quarter of fiscal 2019 and earlier adoption is permitted. We are currently evaluating the impact of our pending adoption of ASU 2016-15 on our consolidated financial statements.

[0001628280-16-020392:notes:144]
In June 2016, the FASB issued ASU 2016-13 - Financial Instruments - Credit Losses: Measurement of Credit Losses on Financial Instruments ("ASU 2016-13"). ASU 2016-13 amends the impairment model to utilize an expected loss methodology in place of the currently used incurred loss methodology, which will result in the more timely recognition of losses. The new standard applies to financial assets measured at amortized cost basis, including receivables that result from revenue transactions and held-to-maturity debt securities. The new guidance will be effective for the Company starting in the first quarter of fiscal 2021. Early adoption is permitted starting in the first quarter of fiscal 2020. The Company is in the process of determining the effects the adoption will have on its consolidated financial  statements as well as whether to adopt the new guidance early.

[0001628280-16-020392:notes:145]
In March 2016, FASB issued Accounting Standards Update No. ASU 2016-9, Stock Compensation (“ASU 718”) - Improvements to Employee Share-Based Payment Accounting.” This guidance simplifies various aspects related to how share-based payments are accounted for and presented in the financial statements. This guidance is effective for fiscal years, and interim periods within those years, beginning after December 15, 2016. The Company will adopt this standard in fiscal year 2018. The Company has not yet determined the effect, that the adoption of this standard will have on its consolidated financial statements or results of operations.

[0001628280-16-020392:notes:146]
In February 2016, FASB issued Accounting Standards Update No. 2016-02, Leases (“ASU 2016-02”). The new guidance generally requires an entity to recognize on its balance sheet operating and financing lease liabilities and corresponding right-of-use assets. The standard is effective for us in our first quarter of fiscal 2019 and early adoption is permitted. The Company is currently evaluating the impact of the adoption of ASU 2016-02 on its consolidated financial statements.

[0001628280-16-020392:notes:147]
In January 2016, FASB issued Accounting Standards Update 2016-01, Recognition and Measurement of Financial Assets and Financial Liabilities (Subtopic 825-10) (“ASU 2016-01”). The new standard provides guidance for the recognition, measurement, presentation and disclosure of financial instruments. This guidance is effective for us in our first quarter of fiscal 2018, and early adoption is not permitted. The Company is currently evaluating the impact of the adoption of ASU 2016-01 on its consolidated financial statements.

[0001628280-16-020392:notes:148]
In April 2015, the FASB issued Accounting Standards Update No. 2015-04 Compensation-Retirement Benefits, ("ASU 2015-04") to provide a practical expedient that permits the entity to measure defined benefit plan assets and obligations using the month-end that is closest to the entity’s fiscal year-end and apply that practical expedient consistently from year to year. We adopted this guidance effective first quarter of fiscal 2017 on a prospective basis. No prior periods were retrospectively adjusted. The Company does not believe this standard will have a material impact on its consolidated financial statements or the related footnote disclosures.

[0001628280-16-020392:notes:149]
In May 2014, FASB issued Accounting Standards Update No. 2014-09, Revenue from Contracts with Customers (“ASU 2014-09”), which amended the existing accounting standards for revenue recognition. ASU 2014-09 establishes principles for recognizing revenue upon the transfer of promised goods or services to customers, in an amount that reflects the consideration expected to be received in exchange for those goods or services. The new standard requires that reporting companies disclose the nature, amount, timing and uncertainty of revenue and cash flows arising from contracts with customers. On July 9, 2015, FASB agreed to delay the effective date by one year and, accordingly, the new standard is effective for the Company beginning in the first quarter of fiscal 2018. Early adoption is permitted, but not before the original effective date of the standard. The new standard is required to be applied retrospectively to each prior reporting period presented or retrospectively with the cumulative effect of initially applying it recognized at the date of initial application. The Company has not yet selected a transition method nor has it determined the impact of the new standard on its consolidated financial statements.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001628280-16-020392:notes:150]
Note 3. Related Party Transactions

[0001628280-16-020392:notes:151]
Transactions with Viavi

[0001628280-16-020392:notes:152]
During the three months ended October 1, 2016 and September 26, 2015, the Company recognized revenue of $0.6 million and $0.8 million, respectively, from products sold to Viavi. During the three months ended October 1, 2016 and September 26, 2015, the Company recorded $0.4 million and $0.5 million, respectively, in research and development cost reimbursement and $0.2 million and $0.1 million, respectively, in sublease rental income. As of October 1, 2016 and July 2, 2016, the Company had $0.2 million and $1.1 million, respectively, in accounts receivable due from Viavi.

[0001628280-16-020392:notes:153]
On July 31, 2015, the Company also entered into the following agreements with Viavi:

[0001628280-16-020392:notes:154]
| a) | Contribution Agreement which identified the assets transferred, the liabilities assumed and the contracts assigned and which provided for when and how these transfers, assumptions and assignments would occur. |

[0001628280-16-020392:notes:155]
| b) | Separation and Distribution Agreement which governs the Separation of the Lumentum business and other matters related to Lumentum’s relationship with Viavi. |

[0001628280-16-020392:notes:156]
| c) | Tax Matters Agreement which governs the respective rights, responsibilities and obligations of Lumentum and Viavi with respect to tax liabilities and benefits, attributes, proceedings, returns and certain other tax matters. |

[0001628280-16-020392:notes:157]
| d) | Employee Matters Agreement which governs the compensation and employee benefit obligations with respect to the current and former employees of Lumentum and Viavi, the treatment of equity based compensation and generally allocates liabilities and responsibilities relating to employee compensation, benefit plans and programs. The Employee Matters Agreement provides that employees of Lumentum will participate in benefit plans sponsored or maintained by Lumentum. |

[0001628280-16-020392:notes:158]
| e) | Securities Purchase Agreement, which also includes Amada Holdings Co., Ltd. (“Amada”) as a party, which sets forth the terms for the sale by Viavi to Amada of shares of Series A Preferred Stock (the "Series A Preferred Stock") of Lumentum Inc., our wholly-owned subsidiary, following the Separation. |

[0001628280-16-020392:notes:159]
| f) | Intellectual Property Matters Agreement which outlines the intellectual property rights of Lumentum and Viavi following the Separation, as well as non-compete restrictions between Viavi and Lumentum. |

[0001628280-16-020392:notes:160]
Allocated Costs

[0001628280-16-020392:notes:161]
From June 28, 2015 to August 1, 2015, the effective date of the Separation, the consolidated statements of operations included the Company's direct expenses for cost of sales, research and development, sales and marketing, and administration as well as allocations of expenses arising from shared services and infrastructure provided by Viavi to the Company. These allocated expenses include costs of information technology, human resources, accounting, legal, real estate and facilities, corporate marketing, insurance, treasury and other corporate and infrastructure services. In addition, other costs allocated to the Company include restructuring and stock-based compensation related to Viavi’s corporate and shared services employees and are included in the table below. These expenses were allocated to the Company using estimates that we consider to be a reasonable reflection of the utilization of services or benefits received by our business. The allocation methods include revenue, headcount, square footage, actual consumption and usage of services and others.

[0001628280-16-020392:notes:162]
There were no allocations of expenses from Viavi for the three months ended October 1, 2016. During the three months ended September 26, 2015, allocated costs from Viavi included in the accompanying consolidated statements of operations  were as follows (in millions):

[0001628280-16-020392:notes:163]
|  | Three Months Ended |
|  | September 26, 2015 |
| Research and development | $ | — |  |
| Selling, general and administrative | 11.7 |  |
| Restructuring and related charges | — |  |
| Interest and other (income) expenses, net | (0.1 | ) |
| Interest expense | 0.1 |  |
| Total allocated costs | $ | 11.7 |  |

[0001628280-16-020392:notes:164]
Other Agreements

[0001628280-16-020392:notes:165]
We share and operate under agreements executed by Viavi with third parties, including but not limited to purchasing, manufacturing, and freight agreements; use of facilities owned, leased, and managed by Viavi; and software, technology and other intellectual property agreements.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-16-020392:notes:166]
[same as prior period, unchanged from 0001628280-16-015527:notes:145]

[0001628280-16-020392:notes:167]
We have initiated various strategic restructuring events primarily intended to reduce costs, consolidate our operations, rationalize the manufacturing of our products and align our business in response to the market conditions. As of October 1, 2016 and July 2, 2016, our total restructuring accrual was $5.3 million and $5.7 million, respectively. During the three months ended October 1, 2016 and September 26, 2015, we recorded $2.9 million and $1.0 million, respectively, in restructuring and related charges in the consolidated statements of operations. Of the $2.9 million charge recorded during the three months ended October 1, 2016, $0.4 million was related to severance, retention and employee benefits. Other restructuring related charges and exit costs include relocation costs, equipment set-up costs, product qualification costs, facilities and equipment costs to vacate facilities and consolidate operations, and lease termination costs. The timing of associated cash payments is dependent upon the type of restructuring charge and can extend over multiple periods.

[0001628280-16-020392:notes:168]
[same as prior period, unchanged from 0001628280-16-015527:notes:147]

[0001628280-16-020392:notes:169]
The adjustments to the restructuring accrual related to all of our restructuring plans described below as of October 1, 2016, were as follows (in millions):

[0001628280-16-020392:notes:170]
|  | Fiscal 2015 & earlier Restructuring Plan |  | Fiscal 2016 Restructuring Plan |  |  |
|  | Restructuring Charges |  | Exit Costs |  | Other Charges |  | Restructuring Charges |  | Total |
| Liability as of July 2, 2016 | $ | 4.5 |  |  | $ | 0.5 |  |  | $ | — |  |  | $ | 0.7 |  |  | $ | 5.7 |  |
| Charges | 0.4 |  |  |  |  | 2.5 |  |  | — |  |  | 2.9 |  |
| Payments | — |  |  | (0.1 | ) |  | (2.5 | ) |  | (0.7 | ) |  | (3.3 | ) |
| Liability as of October 1, 2016 | $ | 4.9 |  |  | $ | 0.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.3 |  |

[0001628280-16-020392:notes:171]
As of October 1, 2016, our restructuring liability includes $5.1 million in short-term other current liabilities and $0.2 million in other non-current liabilities on the consolidated balance sheets.

[0001628280-16-020392:notes:172]
As of July 2, 2016, our restructuring liability includes $5.5 million in short-term other current liabilities and $0.2 million in other non-current liabilities on the consolidated balance sheets.

[0001628280-16-020392:notes:173]
[same as prior period, unchanged from 0001628280-16-015527:notes:154]

[0001628280-16-020392:notes:174]
During fiscal 2008, we recorded lease exit charges, net of assumed sub-lease income related to our Ottawa facility which was included in selling, general and administrative expenses as the space was never occupied and we had no need for the space in the foreseeable future due to changes in business requirements.  For the three months ended October 1, 2016 and September 26, 2015, we had cash settlements of $0.1 million and $0.1 million, respectively. The fair value of the remaining contractual obligations, net of sublease income is $0.5 million and $0.5 million as of October 1, 2016 and July 2, 2016, respectively. As of October 1, 2016 and July 2, 2016, $0.3 million and $0.3 million was included in other current liabilities for each year, and $0.2 million and $0.2 million in other non-current liabilities, respectively, in the consolidated balance sheets. The payments related to these lease costs are expected to be paid by the end of the third quarter of fiscal 2018.


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001628280-16-020392:notes:175]
Long-lived assets, namely net property, plant and equipment were identified based on the operations in the corresponding geographic areas (in millions):

[0001628280-16-020392:notes:176]
|  | October 1, 2016 |  | July 2, 2016 |
| Property, Plant and Equipment, net |  |  |  |
| United States | $ | 75.3 |  |  | $ | 69.0 |  |
| Canada | 21.6 |  |  | 21.4 |  |
| China | 50.1 |  |  | 46.6 |  |
| Thailand | 46.4 |  |  | 43.8 |  |
| Other Asia-Pacific | 0.2 |  |  | 0.2 |  |
| EMEA | 2.4 |  |  | 2.4 |  |
| Total Property, Plant and Equipment, net | $ | 196.0 |  |  | $ | 183.4 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001628280-16-020392:notes:177]
The following table presents net revenue by the three geographic regions we operate in and net revenue from countries that exceeded 10% of our total net revenue (in millions, except percentage data):

[0001628280-16-020392:notes:178]
|  | Three Months Ended |
|  | October 1, 2016 |  | September 26, 2015 |
| Net revenue: |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |
| Mexico | $ | 39.8 |  |  | 15.4 | % |  | $ | 41.8 |  |  | 19.7 | % |
| United States | 35.9 |  |  | 13.9 |  |  | 34.5 |  |  | 16.2 |  |
| Other Americas | 4.0 |  |  | 1.5 |  |  | 7.8 |  |  | 3.7 |  |
| Total Americas | $ | 79.7 |  |  | 30.8 | % |  | $ | 84.1 |  |  | 39.6 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |
| Hong Kong | $ | 58.3 |  |  | 22.6 | % |  | $ | 30.8 |  |  | 14.5 | % |
| Japan | 31.3 |  |  | 12.1 |  |  | 25.0 |  |  | 11.8 |  |
| Other Asia-Pacific | 65.4 |  |  | 25.3 |  |  | 40.0 |  |  | 18.8 |  |
| Total Asia-Pacific | $ | 155.0 |  |  | 60.0 | % |  | $ | 95.8 |  |  | 45.1 | % |
| EMEA | $ | 23.4 |  |  | 9.2 | % |  | $ | 32.7 |  |  | 15.3 | % |
| Total net revenue | $ | 258.1 |  |  |  |  | $ | 212.6 |  |  |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001628280-16-020392:notes:179]
[same as prior period, unchanged from 0001628280-16-015527:notes:158]

[0001628280-16-020392:notes:180]
|  | Three Months Ended |
|  | October 1, 2016 |  | September 26, 2015 |
| Net revenue: |  |  |  |
| OpComms | $ | 218.3 |  |  | $ | 177.1 |  |
| Lasers | 39.8 |  |  | 35.5 |  |
| Net revenue | $ | 258.1 |  |  | $ | 212.6 |  |
| Gross profit: |  |  |  |
| OpComms | 71.0 |  |  | 55.6 |  |
| Lasers | 17.2 |  |  | 14.2 |  |
| Total segment gross profit | 88.2 |  |  | 69.8 |  |
| Unallocated amounts: |  |  |  |
| Stock-based compensation | (2.0 | ) |  | (1.2 | ) |
| Amortization of intangibles | (1.7 | ) |  | (1.7 | ) |
| Other charges | (2.8 | ) |  | — |  |
| Gross profit | $ | 81.7 |  |  | $ | 66.9 |  |


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001628280-16-020392:notes:181]
The table below discloses the percentage of our total net revenue attributable to each of our two reportable segments. In addition, it discloses the percentage of our total net revenue attributable to our product offerings which serve the Telecom, Datacom and consumer and industrial ("Consumer and Industrial") markets which accounted for more than 10% or more of our total net revenue during the last three fiscal years:

[0001628280-16-020392:notes:182]
|  |  | Three Months Ended |
|  |  | October 1, 2016 |  | September 26, 2015 |
| OpComms: |  |  | 84.6 | % |  |  | 83.3 | % |
| Telecom |  |  | 64.2 | % |  |  | 62.5 | % |
| Datacom |  |  | 17.1 | % |  |  | 16.8 | % |
| Lasers |  |  | 15.4 | % |  |  | 16.7 | % |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-16-020392:notes:183]
[same as prior period, unchanged from 0001628280-16-015527:notes:162]

[0001628280-16-020392:notes:184]
[same as prior period, unchanged from 0001628280-16-015527:notes:163]

[0001628280-16-020392:notes:185]
We are an industry leading provider of optical and photonic products defined by revenue and market share addressing a range of end-market applications including optical communications and commercial lasers. We have two operating segments, Optical Communications, which we refer to as OpComms, and Commercial Lasers, which we refer to as Lasers. The two operating segments were primarily determined based on how the CODM views and evaluates our operations. Operating results are regularly reviewed by the CODM to make decisions about resources to be allocated to the segments and to assess their performance. Other factors, including market separation and customer specific applications, go-to-market channels, products and manufacturing, are considered in determining the formation of these operating segments.

[0001628280-16-020392:notes:186]
OpComms

[0001628280-16-020392:notes:187]
Our OpComms products address the following markets: telecommunications (Telecom), data communications (Datacom) and Consumer and Industrial.

[0001628280-16-020392:notes:188]
Our OpComms products include a wide range of components, modules and subsystems to support and maintain customers in our two primary markets: Telecom and Datacom. The Telecom market includes carrier networks for access (local), metro (intracity), long-haul (city-to-city and worldwide) and submarine (undersea) networks. The Datacom market addresses enterprise, cloud and data center applications, including storage-access networks (“SANs”), local-area networks (“LANs”) and wide-area networks (“WANs”). These products enable the transmission and transport of video, audio and text data over high-capacity fiber-optic cables. We maintain leading positions in the fastest-growing OpComms markets, including reconfigurable optical add/drop multiplexers (“ROADMs”), 100G coherent components, tunable 10-gigabit small form-factor pluggable transceivers and tunable small form-factor pluggables. Our 10G, 40G legacy transceivers and a growing portfolio of 100G pluggable transceivers support LAN/SAN/WAN needs and the cloud for customers building enterprise and hyperscale data center networks.

[0001628280-16-020392:notes:189]
In the Consumer and Industrial markets, our OpComms products include our light source products, which are integrated into 3-D sensing platforms being used in applications for gaming, computing, virtual and augmented reality, mobile and industrial segments. These systems simplify the way people interact with technology by enabling the use of natural body gestures, like the wave of a hand, to control a product or application. Systems can also be used for human identification, safety, and process efficiency, among numerous other application spaces.  Emerging applications for this technology include various mobile device applications, autonomous vehicles, self-navigating robotics and drones in industrial applications and 3-D capture of objects coupled with 3-D printing.  Our light sources are also used in a variety of other industrial laser and processing applications.

[0001628280-16-020392:notes:190]
Lasers

[0001628280-16-020392:notes:191]
Our Lasers products serve our customers in markets and applications such as manufacturing, biotechnology, graphics and imaging, remote sensing, and precision machining such as drilling in printed circuit boards, wafer singulation and solar cell scribing. Our Lasers products are used in a variety of original equipment manufacturer (“OEM”) applications.

[0001628280-16-020392:notes:192]
Our Laser products are used in a variety of OEM applications including diode-pumped solid-state, fiber, diode, direct-diode and gas lasers such as argon-ion and helium-neon lasers. Diode-pumped solid-state and fiber lasers provide excellent beam quality, low noise and exceptional reliability and are used in biotechnology, graphics and imaging, remote sensing, materials processing and precision machining applications. Diode and direct-diode lasers address a wide variety of applications, including laser pumping, thermal exposure, illumination, ophthalmology, image recording, printing, plastic welding and selective soldering. Gas lasers such as argon-ion and helium-neon lasers provide a stable, low-cost and reliable solution over a wide range of operating conditions, making them well suited for complex, high-resolution OEM applications such as flow cytometry, DNA sequencing, graphics and imaging and semiconductor inspection.

[0001628280-16-020392:notes:193]
Our acquisition of Time-Bandwidth in 2014 enabled us to provide high-powered and ultrafast lasers for the industrial and scientific markets. Manufacturers use high-power, ultrafast lasers to create micro parts for consumer electronics and to process glass, semiconductor, LED, and other types of materials. Use of ultrafast lasers for micromachining applications is being driven primarily by the increasing use of consumer electronics and connected devices globally.

[0001628280-16-020392:notes:194]
We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments because management does not include the information in its measurement of the performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, stock-based compensation and certain other charges impacting the gross margin of each segment because management does not include this information in its measurement of the performance of the operating segments.

[0001628280-16-020392:notes:195]
We operate in three geographic regions: Americas, Asia-Pacific, and EMEA (Europe, Middle East and Africa). Net revenue is assigned to the geographic region and country where our product is initially shipped. For example, certain customers may request shipment of our product to a contract manufacturer in one country, which may differ from the location of their end customers. The following table presents net revenue by the three geographic regions we operate in and net revenue from countries that exceeded 10% of our total net revenue (in millions, except percentage data):

[0001628280-16-020392:notes:196]
During the three months ended October 1, 2016 and September 26, 2015, net revenue from customers outside the United States, based on customer shipping location, represented 86.1% and 83.8%  of net revenue, respectively. Our net revenue is primarily denominated in U.S. dollars, including our net revenue from customers outside the United States as presented above.
