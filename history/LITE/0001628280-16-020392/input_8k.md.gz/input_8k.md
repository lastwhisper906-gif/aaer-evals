# LITE 8-K — 0001628280-16-020382 filed 2016-10-27

## item codes, every 8-K on or before 2016-10-27

- 2016-10-27 0001628280-16-020382 — 2.02, 9.01
- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2016-10-27

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001628280-16-020382:8k_2_02:1]
EX-99.1
2
liteex991q1fy17.htm
EXHIBIT 99.1

[0001628280-16-020382:8k_2_02:2]
Exhibit

[0001628280-16-020382:8k_2_02:3]
NEWS RELEASE

[0001628280-16-020382:8k_2_02:4]
LUMENTUM ANNOUNCES FISCAL FIRST QUARTER 2017 RESULTS

[0001628280-16-020382:8k_2_02:5]
Fiscal First Quarter Highlights

[0001628280-16-020382:8k_2_02:6]
| • | Net Revenue of $258.1 million exceeded high-end of guidance |

[0001628280-16-020382:8k_2_02:7]
| • | GAAP Operating margin of 6.5%; Non-GAAP Operating margin of 12.7% exceeded high-end of guidance |

[0001628280-16-020382:8k_2_02:8]
| • | GAAP diluted Net loss per share of $(0.06); Non-GAAP diluted Net income per share of $0.49 exceeded high-end of guidance |

[0001628280-16-020382:8k_2_02:9]
Milpitas, Calif., October 27, 2016 – Lumentum Holdings Inc. ("Lumentum" or the "Company") today reported results for its fiscal first quarter ended October 1, 2016.

[0001628280-16-020382:8k_2_02:10]
Net revenue for the fiscal first quarter of 2017 was $258.1 million, with GAAP net loss of $(3.4) million, or $(0.06) per diluted share. Net revenue for fiscal fourth quarter of 2016 was $241.7 million, with GAAP net profit of $14.3 million, or $0.23 per diluted share. Net revenue for the fiscal first quarter of 2016 was $212.6 million, with GAAP net loss of $(0.2) million, or $0.00 per diluted share.

[0001628280-16-020382:8k_2_02:11]
Non-GAAP net income for the fiscal first quarter of 2017 was $30.7 million or $0.49 per diluted share. Non-GAAP net income for fiscal fourth quarter of 2016 was $25.4 million, or $0.41 per diluted share. Non-GAAP net income for the fiscal first quarter of 2016 was $14.8 million, or $0.25 per diluted share. The Company held $166.8 million in total cash at the end of the fiscal first quarter 2017, which increased $9.7 million sequentially, and the Company remains debt-free.

[0001628280-16-020382:8k_2_02:12]
"We achieved record revenues of $258.1 million and grew approximately 7% sequentially, and 21% year-over-year," said Alan Lowe, president and CEO. "Operating margins were 12.7% as we generated favorable operating leverage from higher volume. On a year-over-year basis, Telecom revenue was up 25%, Datacom revenue was up 24%, and Commercial Lasers were up 12%.  Our TrueFlex® ROADM revenue accelerated during the quarter and was up 11% sequentially, and 184% from last year as the North America metro deployments continued and worldwide adoption of our TrueFlex® technology strengthened."

[0001628280-16-020382:8k_2_02:13]
Financial Overview – Fiscal First Quarter Ended October 1, 2016

[0001628280-16-020382:8k_2_02:14]
|  | GAAP Results ($ in millions) |
|  | Q1 |  | Q4 |  | Q1 |  | Change |
|  | FY 2017 |  | FY 2016 |  | FY 2016 |  | Q/Q |  | Y/Y |
| Net revenue | $ | 258.1 |  |  | $ | 241.7 |  |  | $ | 212.6 |  |  | 6.8 | % |  | 21.4 | % |
| Gross margin | 31.7 | % |  | 32.9 | % |  | 31.5 | % |  | (120)bps |  |  | 20bps |  |
| Operating margin | 6.5 | % |  | 4.2 | % |  | (1.2 | )% |  | 230bps |  |  | 770bps |  |
|  | Non-GAAP Results ($ in millions) |
|  | Q1 |  | Q4 |  | Q1 |  | Change |
|  | FY 2017 |  | FY 2016 |  | FY 2016 |  | Q/Q |  | Y/Y |
| Net revenue | $ | 258.1 |  |  | $ | 241.7 |  |  | $ | 212.6 |  |  | 6.8 | % |  | 21.4 | % |
| Gross margin | 34.2 | % |  | 34.1 | % |  | 32.9 | % |  | 10bps |  |  | 130bps |  |
| Operating margin | 12.7 | % |  | 11.6 | % |  | 7.2 | % |  | 110bps |  |  | 550bps |  |

[0001628280-16-020382:8k_2_02:15]
|  | Net Revenue by Segment ($ in millions) |
|  | Q1 |  | % of |  | Q4 |  | Q1 |  | Change |
|  | FY 2017 |  | Net Revenue |  | FY 2016 |  | FY 2016 |  | Q/Q |  | Y/Y |
| Optical Communications | $ | 218.3 |  |  | 84.6 | % |  | $ | 201.2 |  |  | $ | 177.1 |  |  | 8.5 | % |  | 23.3 | % |
| Lasers | 39.8 |  |  | 15.4 | % |  | 40.5 |  |  | 35.5 |  |  | (1.7 | )% |  | 12.1 | % |
| Total | $ | 258.1 |  |  | 100.0 | % |  | $ | 241.7 |  |  | $ | 212.6 |  |  | 6.8 | % |  | 21.4 | % |

[0001628280-16-020382:8k_2_02:16]
The tables above provide comparisons of quarterly results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled "Use of Non-GAAP Financial Measures."

[0001628280-16-020382:8k_2_02:17]
Business Outlook

[0001628280-16-020382:8k_2_02:18]
For the fiscal second quarter of 2017, the Company expects net revenue to be in the range of $258 million to $270 million, non-GAAP operating margin to be 12.4% to 13.7%, and non-GAAP diluted earnings per share to be $0.47 to $0.55 per share, based on approximately 63.0 million shares outstanding on a fully diluted basis.

[0001628280-16-020382:8k_2_02:19]
We have not provided reconciliations from GAAP to non-GAAP measures for our outlook. A large portion of non-GAAP adjustments, such as derivative liability adjustments, restructuring, stock-based compensation, litigation, and other costs and contingencies unrelated to current and future operations are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future.  For example, the unrealized gain or loss on the derivative liability for Series A Preferred Stock in our fiscal first quarter was a loss of $22.7 million and is revalued based on the fair market value of our common stock on the last day of each fiscal quarter, which is difficult to predict in the future and subject to constant change.

[0001628280-16-020382:8k_2_02:20]
Conference Call

[0001628280-16-020382:8k_2_02:21]
Lumentum will host a conference call on October 27, 2016 at 1:30pm PT/4:30pm ET. A live webcast of the call and the replay will be available on the Lumentum website at http://investor.lumentum.com. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the "Events and Presentations" section concurrently with this earnings press release. This press release will be available on our website at http:/investor.lumentum.com under the "Events and Presentations" section and is also being furnished as a Current Report on Form 8-K with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001628280-16-020382:8k_2_02:22]
About Lumentum

[0001628280-16-020382:8k_2_02:23]
Lumentum (NASDAQ: LITE) is a market-leading manufacturer of innovative optical and photonic products enabling optical networking and commercial laser customers worldwide. Lumentum’s optical components and subsystems are part of virtually every type of telecom, enterprise, and data center network. Lumentum’s commercial lasers enable advanced manufacturing techniques and diverse applications including next-generation 3D sensing capabilities. Lumentum is headquartered in Milpitas, California with R&D, manufacturing, and sales offices worldwide.  For more information, visit https://www.lumentum.com/en.

[0001628280-16-020382:8k_2_02:24]
Forward-Looking Statements

[0001628280-16-020382:8k_2_02:25]
For more information on these and other risks, please refer to the "Risk Factors" section included in the Company’s 10-K filed on September 2, 2016 with the Securities and Exchange Commission, and the Company’s other filings with the Securities and Exchange Commission. The forward-looking statements and preliminary financial results contained in this press release are made as of the date hereof and the Company assumes no obligation to update such statements, except as required by applicable law.

[0001628280-16-020382:8k_2_02:26]
Contact Information

[0001628280-16-020382:8k_2_02:27]
Investors: Chris Coldren, 408-404-0606; investor.relations@lumentum.com

[0001628280-16-020382:8k_2_02:28]
Press: Greg Kaufman, 408-546-4235; media@lumentum.com

[0001628280-16-020382:8k_2_02:29]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001628280-16-020382:8k_2_02:30]
LUMENTUM HOLDINGS INC.

[0001628280-16-020382:8k_2_02:31]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001628280-16-020382:8k_2_02:32]
(in millions, except per share data)

[0001628280-16-020382:8k_2_02:33]
(unaudited)

[0001628280-16-020382:8k_2_02:34]
|  | Three Months Ended |
|  | October 1, 2016 |  | September 26, 2015 |
| Net revenue | $ | 258.1 |  |  | $ | 212.6 |  |
| Cost of sales | 174.7 |  |  | 144.0 |  |
| Amortization of acquired technologies | 1.7 |  |  | 1.7 |  |
| Gross profit | 81.7 |  |  | 66.9 |  |
| Operating expenses: |  |  |  |
| Research and development | 36.9 |  |  | 34.4 |  |
| Selling, general and administrative | 25.1 |  |  | 34.0 |  |
| Restructuring and related charges | 2.9 |  |  | 1.0 |  |
| Total operating expenses | 64.9 |  |  | 69.4 |  |
| Income (loss) from operations | 16.8 |  |  | (2.5 | ) |
| Unrealized gain (loss) on derivative liability | (22.7 | ) |  | 2.2 |  |
| Interest and other income (expense), net | 0.2 |  |  | (0.2 | ) |
| Loss before income taxes | (5.7 | ) |  | (0.5 | ) |
| Benefit from income tax | (2.3 | ) |  | (0.3 | ) |
| Net loss | (3.4 | ) |  | (0.2 | ) |
| Net loss per share:(a) |  |  |  |
| Basic | $ | (0.06 | ) |  | $ | — |  |
| Diluted | $ | (0.06 | ) |  | $ | — |  |
| Items reconciling net loss to net loss available to common shareholders: |  |  |  |
| Cumulative dividends on Series A preferred stock | (0.2 | ) |  | (0.1 | ) |
| Adjustment for Series A preferred stock redemption value | — |  |  | (9.7 | ) |
| Net loss available to common shareholders | $ | (3.6 | ) |  | $ | (10.0 | ) |
| Net loss available to common shareholders per share: |  |  |  |
| Basic | $ | (0.06 | ) |  | $ | (0.17 | ) |
| Diluted | $ | (0.06 | ) |  | $ | (0.17 | ) |
| Shares used in per share calculation:(a) |  |  |  |
| Basic | 59.9 |  |  | 58.8 |  |
| Diluted | 59.9 |  |  | 58.8 |  |

[0001628280-16-020382:8k_2_02:35]
| (a) | On August 1, 2015, JDSU distributed 47.1 million shares, or 80.1% of the outstanding shares of common stock of Lumentum to existing holders of JDSU common stock. JDSU was renamed Viavi Solutions Inc. and at the time of the distribution, retained 11.7 million shares, or 19.9% of Lumentum’s outstanding shares. Basic and diluted net income (loss) per share for the three and twelve months ended June 27, 2015 are calculated using the shares of Lumentum common stock outstanding on August 1, 2015. |

[0001628280-16-020382:8k_2_02:36]
LUMENTUM HOLDINGS INC.

[0001628280-16-020382:8k_2_02:37]
CONSOLIDATED BALANCE SHEETS

[0001628280-16-020382:8k_2_02:38]
(in millions, except share and per share data)

[0001628280-16-020382:8k_2_02:39]
(unaudited)

[0001628280-16-020382:8k_2_02:40]
|  | October 1, 2016 |  | July 2, 2016 |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |  |
| Cash and cash equivalents | $ | 166.8 |  |  | $ | 157.1 |  |
| Accounts receivable, net | 156.5 |  |  | 170.5 |  |
| Inventories | 103.7 |  |  | 100.6 |  |
| Prepayments and other current assets | 62.3 |  |  | 61.3 |  |
| Total current assets | 489.3 |  |  | 489.5 |  |
| Property, plant and equipment, net | 196.0 |  |  | 183.4 |  |
| Goodwill and intangibles, net | 18.1 |  |  | 19.9 |  |
| Deferred income taxes, net | 31.6 |  |  | 31.9 |  |
| Other non-current assets | 2.5 |  |  | 1.6 |  |
| Total assets | $ | 737.5 |  |  | $ | 726.3 |  |
| LIABILITIES, MEZZANINE EQUITY AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 108.3 |  |  | $ | 118.3 |  |
| Accrued payroll and related expenses | 26.9 |  |  | 26.5 |  |
| Income taxes payable | 0.6 |  |  | 1.9 |  |
| Accrued expenses | 13.3 |  |  | 14.9 |  |
| Other current liabilities | 14.4 |  |  | 12.1 |  |
| Total current liabilities | 163.5 |  |  | 173.7 |  |
| Derivative liability | 33.0 |  |  | 10.3 |  |
| Other non-current liabilities | 9.5 |  |  | 9.1 |  |
| Total liabilities | 206.0 |  |  | 193.1 |  |
| Mezzanine equity: |  |  |  |
| Non-controlling interest redeemable convertible Series A preferred stock, $0.001 par value, 10,000,000 authorized shares; 35,805 shares issued and outstanding as of October 1, 2016 and as of July 2, 2016 | 35.8 |  |  | 35.8 |  |
| Total mezzanine equity | 35.8 |  |  | 35.8 |  |
| Stockholders’ equity: |  |  |  |
| Common stock, $0.001 par value, 990,000,000 authorized shares, 60,121,177 and 59,580,596 shares issued and outstanding as of October 1, 2016 and July 2, 2016, respectively | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital | 470.5 |  |  | 467.7 |  |
| Retained earnings | 16.6 |  |  | 20.2 |  |
| Accumulated other comprehensive income | 8.5 |  |  | 9.4 |  |
| Total stockholders’ equity | 495.7 |  |  | 497.4 |  |
| Total liabilities, mezzanine equity and stockholders’ equity | $ | 737.5 |  |  | $ | 726.3 |  |

[0001628280-16-020382:8k_2_02:41]
Use of Non-GAAP Financial Measures

[0001628280-16-020382:8k_2_02:42]
In this press release, Lumentum provides investors with gross margin, operating margin, net income, net income per share and Adjusted EBITDA on a non-GAAP basis. Lumentum also supplementally provides gross profit, income (loss) before income taxes and certain expenses (collectively “non-GAAP expenses”) on a non-GAAP basis. Lumentum believes this non-GAAP financial information provides additional insight into the Company's on-going performance and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company's on-going operations and enable more meaningful period to period comparisons. Specifically, the Company believes that providing this information allows investors to better understand the Company’s financial performance and, importantly, to evaluate the efficacy of the methodology and information used by management to evaluate and measure such operating performance.  However, these measures may be different from non-GAAP measures used by other companies, limiting their usefulness for comparison purposes. The non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP. Investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future. Further, these non-GAAP financial measures may not be comparable to similarly titled measurements reported by other companies.

[0001628280-16-020382:8k_2_02:43]
Non-GAAP gross margin, non-GAAP operating margin, non-GAAP net income, and non-GAAP net income per share, Adjusted EBITDA, non-GAAP gross profit, income (loss) before income taxes and non-GAAP expenses exclude (i) workforce related charges such as severance, retention bonuses and employee relocation costs related to formal restructuring plans, (ii) costs for facilities not required for ongoing operations, and costs related to the relocation of certain equipment from these facilities and/or contract manufacturer facilities, (iii) stock-based compensation, (iv) amortization of intangibles, (v)amortization of acquired developed technologies, (vi) non-cash interest expense, (vii) unrealized loss on derivative liability, and (viii) other non-recurring charges comprising mainly of one-time provision for excess and obsolete inventory, acquisition, integration, litigation and other costs and contingencies unrelated to current and future operations including post-separation activities such as small site consolidations, reorganizations, insourcing or outsourcing of activities, severance related costs and transition related costs for the separation from Viavi. Beginning in the third fiscal quarter 2016, we began to exclude unrealized gain or loss on derivative liability for the Series A Preferred Stock to Adjusted EBITDA and prior periods have been adjusted. Management does not believe that these items are reflective of the Company's underlying operating performance. The presentation of these and other similar items in Lumentum's non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001628280-16-020382:8k_2_02:44]
A quantitative reconciliation between GAAP and non-GAAP financial data with respect to historical periods is included in the supplemental financial table attached to this press release. The Company has not reconciled its projections of non-GAAP earnings per share.  As items that impact net loss are out of the Company's control and/or cannot be reasonably predicted, Lumentum has determined that a quantitative reconciliation of forward-looking non-GAAP financial measures to their most directly comparable GAAP financial measures cannot be provided without unreasonable efforts.

[0001628280-16-020382:8k_2_02:45]
LUMENTUM HOLDINGS INC.

[0001628280-16-020382:8k_2_02:46]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001628280-16-020382:8k_2_02:47]
(in millions, except per share data)

[0001628280-16-020382:8k_2_02:48]
(unaudited)

[0001628280-16-020382:8k_2_02:49]
|  | Three Months Ended |
|  | October 1, 2016 |  | September 26, 2015 |
| Gross profit on GAAP basis | $ | 81.7 |  |  | $ | 66.9 |  |
| Stock-based compensation | 2.0 |  |  | 1.2 |  |
| Other charges related to non-recurring activities | 2.8 |  |  | 0.1 |  |
| Amortization of acquired developed technologies | 1.7 |  |  | 1.7 |  |
| Gross profit on non-GAAP basis | $ | 88.2 |  |  | $ | 69.9 |  |
| Research and development on GAAP basis | $ | 36.9 |  |  | $ | 34.4 |  |
| Stock-based compensation | (2.8 | ) |  | (1.8 | ) |
| Other charges related to non-recurring activities | (0.3 | ) |  | (0.6 | ) |
| Research and development on non-GAAP basis | $ | 33.8 |  |  | $ | 32.0 |  |
| Selling, general and administrative on GAAP basis | $ | 25.1 |  |  | $ | 34.0 |  |
| Stock-based compensation | (2.9 | ) |  | (3.5 | ) |
| Other charges related to non-recurring activities | (0.4 | ) |  | (7.8 | ) |
| Amortization of intangibles | (0.1 | ) |  | (0.1 | ) |
| Selling, general and administrative on non-GAAP basis | $ | 21.7 |  |  | $ | 22.6 |  |
| Income (loss) from operations on GAAP basis | $ | 16.8 |  |  | $ | (2.5 | ) |
| Stock-based compensation | 7.7 |  |  | 6.5 |  |
| Other charges related to non-recurring activities | 3.5 |  |  | 8.5 |  |
| Amortization of intangibles | 1.8 |  |  | 1.8 |  |
| Restructuring and related charges | 2.9 |  |  | 1.0 |  |
| Income from operations on non-GAAP basis | $ | 32.7 |  |  | $ | 15.3 |  |
| Loss before income taxes on GAAP basis | $ | (5.7 | ) |  | $ | (0.5 | ) |
| Stock-based compensation | 7.7 |  |  | 6.5 |  |
| Other charges related to non-recurring activities | 3.5 |  |  | 8.4 |  |
| Amortization of intangibles | 1.8 |  |  | 1.8 |  |
| Restructuring and related charges | 2.9 |  |  | 1.0 |  |
| Unrealized (gain) loss on derivative liability | 22.7 |  |  | (2.2 | ) |
| Income before income taxes on non-GAAP basis | $ | 32.9 |  |  | $ | 15.0 |  |
| Benefit from income taxes on GAAP basis | $ | (2.3 | ) |  | $ | (0.3 | ) |
| Non-cash income tax expense | 4.5 |  |  | 0.5 |  |
| Provision for income taxes on non-GAAP basis | $ | 2.2 |  |  | $ | 0.2 |  |
| Net loss on GAAP basis | $ | (3.4 | ) |  | $ | (0.2 | ) |
| Stock-based compensation | 7.7 |  |  | 6.5 |  |
| Other charges related to non-recurring activities | 3.5 |  |  | 8.4 |  |

[0001628280-16-020382:8k_2_02:50]
| Amortization of intangibles | 1.8 |  |  | 1.8 |  |
| Restructuring and related charges | 2.9 |  |  | 1.0 |  |
| Unrealized (gain) loss on derivative liability | 22.7 |  |  | (2.2 | ) |
| Non-cash income tax expense | (4.5 | ) |  | (0.5 | ) |
| Net income on non-GAAP basis | $ | 30.7 |  |  | $ | 14.8 |  |
| Net income per share on non-GAAP basis | $ | 0.49 |  |  | $ | 0.25 |  |
| Shares used in per share calculation - diluted on GAAP basis | 59.9 |  |  | 58.8 |  |
| Non-GAAP adjustment | 2.5 |  |  | 0.9 |  |
| Shares used in per share calculation - diluted on non-GAAP basis | 62.4 |  |  | 59.7 |  |

[0001628280-16-020382:8k_2_02:51]
LUMENTUM HOLDINGS INC.

[0001628280-16-020382:8k_2_02:52]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EBITDA

[0001628280-16-020382:8k_2_02:53]
(in millions)

[0001628280-16-020382:8k_2_02:54]
(unaudited)

[0001628280-16-020382:8k_2_02:55]
|  | Three Months Ended |
|  | October 1, 2016 |  | September 26, 2015 |
| GAAP net loss | $ | (3.4 | ) |  | $ | (0.2 | ) |
| Interest and other expense (income), net | (0.2 | ) |  | 0.2 |  |
| Benefit from income taxes | (2.3 | ) |  | (0.3 | ) |
| Depreciation | 11.9 |  |  | 11.7 |  |
| Amortization | 1.8 |  |  | 1.8 |  |
| EBITDA | 7.8 |  |  | 13.2 |  |
| Costs related to restructuring and related charges | 2.9 |  |  | 1.0 |  |
| Costs related to stock-based compensation | 7.7 |  |  | 6.5 |  |
| Costs related to other non-recurring activities | 3.5 |  |  | 8.5 |  |
| Unrealized (gain) loss on derivative liability | 22.7 |  |  | (2.2 | ) |
| Adjusted EBITDA | $ | 44.6 |  |  | $ | 27.0 |  |
