# LITE MD&A — 0001628280-16-020392


## mdna

[0001628280-16-020392:mdna:1]
[same as prior period, unchanged from 0001628280-16-015527:mdna:1]

[0001628280-16-020392:mdna:2]
You should read the following discussion in conjunction with the unaudited interim consolidated financial statements and the corresponding notes included elsewhere in this Quarterly Report on Form 10-Q (this "Quarterly Report"). This Management's Discussion and Analysis of Financial Condition and Results of Operations contains forward-looking statements. The matters discussed in these forward-looking statements are subject to risk, uncertainties and other factors that could cause actual results to differ materially from those made, projected or implied in the forward-looking statements. Please see "Risk Factors" and "Forward-Looking Statements" for a discussion of the uncertainties, risks and assumptions associated with these statements.

[0001628280-16-020392:mdna:3]
FORWARD-LOOKING STATEMENTS

[0001628280-16-020392:mdna:4]
Overview

[0001628280-16-020392:mdna:5]
We are an industry leading provider of optical and photonic products, defined by revenue and market share addressing a range of end-market applications including optical communications and commercial lasers. We have two operating segments, Optical Communications, which we refer to as OpComms, and Commercial Lasers, which we refer to as Lasers. The two operating segments were primarily determined based on how the Chief Operating Decision Maker (“CODM”) views and evaluates our operations. Operating results are regularly reviewed by the CODM to make decisions about resources to be allocated to the segments and to assess their performance. Other factors, including market separation and customer specific applications, go-to-market channels, products and manufacturing, are considered in determining the formation of these operating segments.

[0001628280-16-020392:mdna:6]
[same as prior period, unchanged from 0001628280-16-015527:mdna:28]

[0001628280-16-020392:mdna:7]
Our OpComms products address the following markets: telecommunications ("Telecom"), data communications ("Datacom"), and Consumer and Industrial.

[0001628280-16-020392:mdna:8]
Our OpComms products include a wide range of components, modules and subsystems to support and maintain customers in our two primary markets: Telecom and Datacom. The Telecom market includes carrier networks for access (local), metro (intracity), long-haul (city-to-city and worldwide) and submarine (undersea) networks. The Datacom market addresses enterprise, cloud and data center applications, including Storage Area Networks ("SANs"), Local Area Networks ("LANs"), and Wide Area Networks ("WANs"). These products enable the transmission and transport of video, audio and text data over high-capacity fiber-optic cables. We maintain leading positions in the fastest-growing OpComms markets, including ROADMs, 100G coherent components, tunable 10-gigabit small form-factor pluggable transceivers and tunable small form-factor pluggables. Our 10G and 40G legacy transceivers and a growing portfolio of 100G pluggable transceivers support LAN/SAN/WAN needs and the cloud for customers building enterprise and hyperscale data center networks.

[0001628280-16-020392:mdna:9]
In the Consumer and Industrial markets, our OpComms products include our light source products, which are integrated into 3-D sensing platforms being used in applications for gaming, computing, virtual and augmented reality, mobile and industrial segments. These systems simplify the way people interact with technology by enabling the use of natural body gestures, like the wave of a hand, to control a product or application. Systems can also be used for human identification, safety, and process efficiency, among numerous other application spaces.  Emerging applications for this technology include various mobile device applications, autonomous vehicles, self-navigating robotics and drones in industrial applications and 3-D capture of objects coupled with 3-D printing.  Our light sources are also used in a variety of other industrial laser and processing applications.

[0001628280-16-020392:mdna:10]
Our OpComms customers include Ciena Corporation, Cisco Systems, Inc., Coriant GmbH, Fujitsu, Alphabet Inc. (formerly Google), Facebook, Huawei Technologies Co. Ltd., Microsoft Corporation and Nokia Networks (including Alcatel-Lucent International).

[0001628280-16-020392:mdna:11]
[same as prior period, unchanged from 0001628280-16-015527:mdna:34]

[0001628280-16-020392:mdna:12]
Our Lasers products serve our customers in markets and applications such as manufacturing, biotechnology, graphics and imaging, remote sensing, and precision machining, such as drilling of printed circuit boards, wafer singulation and solar cell scribing.

[0001628280-16-020392:mdna:13]
Our Laser products include diode-pumped solid-state with short and ultrafast pulses, fiber, diode, direct-diode and gas lasers such as argon-ion and helium-neon lasers. Diode-pumped solid-state and fiber lasers provide excellent beam quality, low noise and exceptional reliability and are used in biotechnology, graphics and imaging, remote sensing, materials processing and precision machining applications. Diode and direct-diode lasers address a wide variety of applications, including laser pumping, thermal exposure, illumination, ophthalmology, image recording, printing, plastic welding and selective soldering. Gas lasers such as argon-ion and helium-neon lasers provide a stable, low-cost and reliable solution over a wide range of operating conditions, making them well suited for complex, high-resolution OEM applications such as flow cytometry, DNA sequencing, graphics and imaging and semiconductor inspection.

[0001628280-16-020392:mdna:14]
We also provide high-powered and ultrafast lasers for the industrial and scientific markets. Manufacturers use high-power, ultrafast lasers to create micro parts for consumer electronics and for medical devises, and to process semiconductor, LED, and other types of materials. Use of ultrafast lasers for micromachining applications is being driven primarily by the increasing use of consumer electronics and connected devices globally.

[0001628280-16-020392:mdna:15]
Our Lasers customers include Amada Holdings, Ltd., ASML Holding N.V., Beckman Coulter, Inc., Becton, Dickinson and Company, DISCO Corporation, Electro Scientific Industries, Inc., EO Technics Co., Ltd. and KLA-Tencor Corporation.

[0001628280-16-020392:mdna:16]
[same as prior period, unchanged from 0001628280-16-015527:mdna:39]

[0001628280-16-020392:mdna:17]
Our consolidated financial statements are prepared in accordance with U.S. generally accepted accounting principles ("GAAP") as set forth in the Financial Accounting Standards Board’s Accounting Standards Codification ("ASC"), and we consider the various staff accounting bulletins and other applicable guidance issued by the United States Securities and Exchange Commission. GAAP, as set forth within the ASC, requires us to make certain estimates, judgments and assumptions. We believe that the estimates, judgments and assumptions upon which we rely are reasonable based upon information available to us at the time that these estimates, judgments and assumptions are made. These estimates, judgments and assumptions can affect the reported amounts of assets and liabilities as of the date of the financial statements as well as the reported amounts of revenues and expenses during the periods presented. To the extent there are differences between these estimates, judgments or assumptions and actual results, our financial statements will be affected. The accounting policies that reflect our more significant estimates, judgments and assumptions and which we believe are the most critical to aid in fully understanding and evaluating our reported financial results include the following:

[0001628280-16-020392:mdna:18]
| • | Revenue Recognition |

[0001628280-16-020392:mdna:19]
| • | Inventory Valuation |

[0001628280-16-020392:mdna:20]
| • | Stock-based Compensation |

[0001628280-16-020392:mdna:21]
| • | Goodwill and Intangibles |

[0001628280-16-020392:mdna:22]
| • | Long-lived Asset Valuation |

[0001628280-16-020392:mdna:23]
| • | Restructuring |

[0001628280-16-020392:mdna:24]
| • | Income Taxes |

[0001628280-16-020392:mdna:25]
In many cases, the accounting treatment of a particular transaction is specifically dictated by GAAP and does not require management’s judgment in its application. There are also areas in which management’s judgment in selecting among available alternatives would not produce a materially different result. Our senior management has reviewed our critical accounting policies and related disclosures with the Audit Committee of the Board of Directors.

[0001628280-16-020392:mdna:26]
During the first quarter of fiscal 2017, there were no significant changes to our critical accounting policies and estimates. Management’s Discussion and Analysis of Financial Condition and Results of Operations contained in Part II, Item 7 of our Annual Report on Form 10-K for our fiscal year ended July 2, 2016 provides a more complete discussion of our critical accounting policies and estimates.

[0001628280-16-020392:mdna:27]
Recently Issued Accounting Pronouncements

[0001628280-16-020392:mdna:28]
Refer to "Note 2. Recently Issued Accounting Pronouncements" in the Notes to Consolidated Financial Statements.

[0001628280-16-020392:mdna:29]
[same as prior period, unchanged from 0001628280-16-015527:mdna:45]

[0001628280-16-020392:mdna:30]
The results of operations for the periods presented are not necessarily indicative of results to be expected for future periods. The following table summarizes selected Consolidated Statements of Operations items as a percentage of net revenue:

[0001628280-16-020392:mdna:31]
|  | Three Months Ended |
|  | October 1, 2016 |  | September 26, 2015 |
| Segment net revenue: |  |  |  |
| OpComms | 84.6 | % |  | 83.3 | % |
| Lasers | 15.4 |  |  | 16.7 |  |
| Net revenue | 100.0 |  |  | 100.0 |  |
| Cost of sales | 67.7 |  |  | 67.7 |  |
| Amortization of acquired technologies | 0.6 |  |  | 0.8 |  |
| Gross profit | 31.7 |  |  | 31.5 |  |
| Operating expenses: |  |  |  |
| Research and development | 14.3 |  |  | 16.2 |  |
| Selling, general and administrative | 9.7 |  |  | 16.0 |  |
| Restructuring and related charges | 1.1 |  |  | 0.5 |  |
| Total operating expenses | 25.1 |  |  | 32.6 |  |
| Income (loss) from operations | 6.5 |  |  | (1.2 | ) |
| Unrealized gain (loss) on derivative liabilities | (8.8 | ) |  | 1.0 |  |
| Interest and other income (expense), net | 0.1 |  |  | * |  |
| Loss before income taxes | (2.2 | ) |  | (0.2 | ) |
| Benefit from income tax | (0.9 | ) |  | (0.1 | ) |
| Net loss | (1.3 | )% |  | (0.1 | )% |

[0001628280-16-020392:mdna:32]
* Amount represents less than 0.1%

[0001628280-16-020392:mdna:33]
Financial Data for the three months ended October 1, 2016 and September 26, 2015

[0001628280-16-020392:mdna:34]
The following table summarizes selected Consolidated Statements of Operations items (in millions, except for percentages):

[0001628280-16-020392:mdna:35]
|  | Three Months Ended |  |  |  |  |
|  | October 1, 2016 |  | September 26, 2015 |  | Change |  | Percentage Change |
| Segment net revenue: |  |  |  |  |  |  |  |
| OpComms | $ | 218.3 |  |  | $ | 177.1 |  |  | $ | 41.2 |  |  | 23.3 | % |
| Lasers | 39.8 |  |  | 35.5 |  |  | 4.3 |  |  | 12.1 |  |
| Net revenue | $ | 258.1 |  |  | $ | 212.6 |  |  | $ | 45.5 |  |  | 21.4 | % |
| Gross profit | $ | 81.7 |  |  | $ | 66.9 |  |  | $ | 14.8 |  |  | 22.1 | % |
| Gross margin | 31.7 | % |  | 31.5 | % |  |  |  |  |
| Research and development | 36.9 |  |  | 34.4 |  |  | 2.5 |  |  | 7.3 | % |
| Percentage of net revenue | 14.3 | % |  | 16.2 | % |  |  |  |  |
| Selling, general and administrative | 25.1 |  |  | 34.0 |  |  | (8.9 | ) |  | (26.2 | )% |
| Percentage of net revenue | 9.7 | % |  | 16.0 | % |  |  |  |  |
| Restructuring and related charges | 2.9 |  |  | 1.0 |  |  | 1.9 |  |  | 190.0 | % |
| Percentage of net revenue | 1.1 | % |  | 0.5 | % |  |  |  |  |

[0001628280-16-020392:mdna:36]
[same as prior period, unchanged from 0001628280-16-015527:mdna:69]

[0001628280-16-020392:mdna:37]
[same as prior period, unchanged from 0001628280-16-015527:mdna:52]

[0001628280-16-020392:mdna:38]
Net revenue increased by $45.5 million, or 21.4%, during the three months ended October 1, 2016 compared to the same period ended September 26, 2015. This increase was primarily due to an increase in net revenue from our OpComms segment. OpComms net revenue increased by $41.2 million, or 23.3%, during the three months ended October 1, 2016 compared to three months ended September 26, 2015, driven by increased demand from our SuperTransport Blade and 100G Datacom products. Lasers net revenue, driven by higher demand, increased by $4.3 million, or 12.1%, during the three months ended October 1, 2016 compared to the same period a year ago.

[0001628280-16-020392:mdna:39]
[same as prior period, unchanged from 0001628280-16-015527:mdna:59]

[0001628280-16-020392:mdna:40]
We operate in three geographic regions: Americas, Asia-Pacific and EMEA. Net revenue is assigned to the geographic region and country where our product is initially shipped. For example, certain customers may request shipment of our product to a contract manufacturer in one country, but the location of the end customers may differ. The following table presents net revenue by the three geographic regions we operate in and net revenue from countries that represented10% or more of our total net revenue (in millions, except for percentages):

[0001628280-16-020392:mdna:41]
|  | Three Months Ended |
|  | October 1, 2016 |  | September 26, 2015 |
| Net revenue: |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |
| Mexico | $ | 39.8 |  |  | 15.4 | % |  | $ | 41.8 |  |  | 19.7 | % |
| United States | 35.9 |  |  | 13.9 |  |  | 34.5 |  |  | 16.2 |  |
| Other Americas | 4.0 |  |  | 1.5 |  |  | 7.8 |  |  | 3.7 |  |
| Total Americas | $ | 79.7 |  |  | 30.8 | % |  | $ | 84.1 |  |  | 39.6 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |
| Hong Kong | $ | 58.3 |  |  | 22.6 | % |  | $ | 30.8 |  |  | 14.5 | % |
| Japan | 31.3 |  |  | 12.1 |  |  | 25.0 |  |  | 11.8 |  |
| Other Asia-Pacific | 65.4 |  |  | 25.3 |  |  | 40.0 |  |  | 18.8 |  |
| Total Asia-Pacific | $ | 155.0 |  |  | 60.0 | % |  | $ | 95.8 |  |  | 45.1 | % |
| EMEA | $ | 23.4 |  |  | 9.2 | % |  | $ | 32.7 |  |  | 15.3 | % |
| Total net revenue | $ | 258.1 |  |  |  |  | $ | 212.6 |  |  |  |

[0001628280-16-020392:mdna:42]
During the three months ended October 1, 2016 and September 26, 2015, net revenue from customers outside the United States, based on customer shipping location, represented 86.1%  and 83.8% of net revenue, respectively. Our net revenue is primarily denominated in U.S. dollars, including our net revenue from customers outside the United States as presented above. We expect revenue from customers outside of the United States to continue to be an important part of our overall net revenue and an increasing focus for net revenue growth opportunities.

[0001628280-16-020392:mdna:43]
[same as prior period, unchanged from 0001628280-16-015527:mdna:63]

[0001628280-16-020392:mdna:44]
The following table summarizes segment gross margin for the three months ended October 1, 2016 and September 26, 2015 (in millions, except for percentages):

[0001628280-16-020392:mdna:45]
|  | Gross Profit |  | Gross Margin |
|  | Three Months Ended |  | Three Months Ended |
|  | October 1, 2016 |  | September 26, 2015 |  | October 1, 2016 |  | September 26, 2015 |
| OpComms | $ | 71.0 |  |  | $ | 55.6 |  |  | 32.5 | % |  | 31.4 | % |
| Lasers | 17.2 |  |  | 14.2 |  |  | 43.2 | % |  | 39.9 | % |
| Segment total | $ | 88.2 |  |  | $ | 69.8 |  |  | 34.2 | % |  | 32.8 | % |
| Unallocated corporate items (1) | (6.5 | ) |  | (2.9 | ) |  |  |  |  |
| Total | $ | 81.7 |  |  | $ | 66.9 |  |  | 31.7 | % |  | 31.5 | % |

[0001628280-16-020392:mdna:46]
(1) The unallocated corporate items for the three month periods presented include the effects of amortization of acquired developed technology intangible assets, share-based compensation and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0001628280-16-020392:mdna:47]
[same as prior period, unchanged from 0001628280-16-015527:mdna:67]

[0001628280-16-020392:mdna:48]
[same as prior period, unchanged from 0001628280-16-015527:mdna:72]

[0001628280-16-020392:mdna:49]
[same as prior period, unchanged from 0001628280-16-015527:mdna:73]

[0001628280-16-020392:mdna:50]
[same as prior period, unchanged from 0001628280-16-015527:mdna:74]

[0001628280-16-020392:mdna:51]
OpComms gross margin during the three months ended October 1, 2016 increased by 1.1 percentage points to 32.5% from 31.4% in the same period a year ago. This increase was primarily due to higher sales volumes of SuperTransport Blade and 100G Datacom products.

[0001628280-16-020392:mdna:52]
[same as prior period, unchanged from 0001628280-16-015527:mdna:77]

[0001628280-16-020392:mdna:53]
Lasers gross margin during the three months ended October 1, 2016 increased by 3.3 percentage points to 43.2% from 39.9% in the same period a year ago. This increase was primarily due to higher sales volumes of kW laser products partially offset by increases in warranty related costs.

[0001628280-16-020392:mdna:54]
Research and Development ("R&D")

[0001628280-16-020392:mdna:55]
R&D expense increased by $2.5 million, or 7.3%, for the three months ended October 1, 2016 compared to the same period a year ago.

[0001628280-16-020392:mdna:56]
The increase in R&D expense was primarily due to increased investment in new R&D programs, the increase in the headcount and the employee compensation expense, including stock-based compensation during the three months ended October 1, 2016.

[0001628280-16-020392:mdna:57]
[same as prior period, unchanged from 0001628280-16-015527:mdna:83]

[0001628280-16-020392:mdna:58]
Selling, General and Administrative ("SG&A")

[0001628280-16-020392:mdna:59]
SG&A expense decreased by $8.9 million, or 26.2%, during the three months ended October 1, 2016 compared to the same period ended September 26, 2015. The change was primarily attributed to the reduction of $5.1 million in corporate allocations from Viavi during the three months ended September 26, 2015, which related to pre-separation costs.

[0001628280-16-020392:mdna:60]
We may experience in the future, certain non-core expenses, such as mergers and acquisitions-related expenses and litigation expenses, which could increase our SG&A expenses and potentially impact our profitability expectations in any particular quarter.

[0001628280-16-020392:mdna:61]
[same as prior period, unchanged from 0001628280-16-015527:mdna:88]

[0001628280-16-020392:mdna:62]
We have reduced costs through targeted restructuring efforts intended to consolidate our operations, rationalize the manufacturing of our products and align our business in response to market conditions. We estimate annualized cost savings of $12.9 million as of October 1, 2016, excluding any one-time charge as a result of the restructuring activities described below. Refer to "Note 10. Restructuring and Related Charges" in the Notes to Consolidated Financial Statements.

[0001628280-16-020392:mdna:63]
As of October 1, 2016, our total restructuring accrual was $5.3 million. During the three months ended October 1, 2016, we recorded $2.9 million in restructuring and related charges. Of the $2.9 million charge recorded during the three months ended October 1, 2016, $0.4 million related to severance, retention and employee benefits. Other restructuring related charges and exit costs include relocation costs, equipment set-up costs, product qualification costs, facilities and equipment costs to vacate facilities and consolidate operations, and lease termination costs. Payments related to the remaining severance and benefits accrual are expected to be paid by the end of fiscal 2017.

[0001628280-16-020392:mdna:64]
As of September 26, 2015, our total restructuring accrual was $5.1 million. During the three months ended September 26, 2015, we recorded $0.9 million in restructuring charges. These charges are primarily due to a previously announced restructuring plan for our Bloomfield, Connecticut site for severance and benefits. Refer to “Note 10. Restructuring and Related Charges” in the Notes to Consolidated Financial Statements.

[0001628280-16-020392:mdna:65]
[same as prior period, unchanged from 0001628280-16-015527:mdna:95]

[0001628280-16-020392:mdna:66]
Interest and other income (expense), net is comprised substantially of gains and losses associated with the re-measurement of non-functional currency denominated monetary assets and liabilities, as well as other transactions outside of the normal course of business. The three months ended September 26, 2015 also included an allocation from Viavi of gains and losses on the foreign currency forward contracts utilized in Viavi's balance sheet hedging program.

[0001628280-16-020392:mdna:67]
Interest and other income (expense), net was $0.2 million during the three months ended October 1, 2016 as compared to $(0.2) million for the three month period ended September 26, 2015. The $0.4 million change was primarily due to higher foreign exchange gains for the three months ended October 1, 2016.

[0001628280-16-020392:mdna:68]
Unrealized gain (loss) on derivative liabilities

[0001628280-16-020392:mdna:69]
The changes in the fair value of the bifurcated embedded derivative of $(22.7) million for the three months ended October 1, 2016 is primarily related to the change in the price of the Company's underlying common stock and is reflected in the consolidated statements of operations as "Unrealized loss on derivative liability".

[0001628280-16-020392:mdna:70]
For further discussion of our derivative liability, see "Note 8. Derivative Liability" in the Notes to Consolidated Financial Statements.

[0001628280-16-020392:mdna:71]
Provision for (Benefit from) Income Taxes

[0001628280-16-020392:mdna:72]
We recorded a benefit for income taxes of $2.3 million and $0.3 million for the three months ended October 1, 2016 and September 26, 2015, respectively.  The quarterly provision for income taxes is based on the estimated annual effective tax rate, plus any discrete items for the respective year.

[0001628280-16-020392:mdna:73]
The benefit for income taxes for the three months ended October 1, 2016 was primarily due to an increase of profit in jurisdictions with lower tax rates, utilization of U.S. tax attributes that were subject to a full valuation allowance, certain Canadian tax incentives, and a net benefit of $0.5 million of true-up adjustments in our foreign jurisdictions.  The benefit for income taxes for the three months ended September 26, 2015 was primarily attributable to the utilization of U.S. tax attributes that were subject to a full valuation allowance, and certain Canadian tax incentives.

[0001628280-16-020392:mdna:74]
For further discussion of our income tax provision, see "Note 11. Income Taxes" in the Notes to Consolidated Financial Statements.

[0001628280-16-020392:mdna:75]
[same as prior period, unchanged from 0001628280-16-015527:mdna:102]

[0001628280-16-020392:mdna:76]
We presented our contractual obligations at July 2, 2016 in our Annual Report on Form 10-K for the fiscal year then ended. There have been no material changes outside the ordinary course of business in those obligations during the three months ended October 1, 2016, other than as noted under the section entitled "Note 13. Commitments and Contingencies".

[0001628280-16-020392:mdna:77]
[same as prior period, unchanged from 0001628280-16-015527:mdna:109]

[0001628280-16-020392:mdna:78]
[same as prior period, unchanged from 0001628280-16-015527:mdna:110]

[0001628280-16-020392:mdna:79]
[same as prior period, unchanged from 0001628280-16-015527:mdna:111]

[0001628280-16-020392:mdna:80]
[same as prior period, unchanged from 0001628280-16-015527:mdna:112]

[0001628280-16-020392:mdna:81]
As of October 1, 2016 and July 2, 2016, our cash and cash equivalents of $166.8 million and $157.1 million, respectively, were held predominantly in the United States, Cayman Islands, Canada, China and Japan. Although the cash generated in the United States from future operations is expected to cover our normal operating requirements, a substantial amount of additional cash could be required for other purposes, such as capital expenditures to support our business and growth, strategic transactions and partnerships, acquisitions, dividends that may be declared, and future stock repurchase programs. Our intent is to indefinitely reinvest funds held outside the United States and our current plans do not demonstrate a need to repatriate them to fund our domestic operations. However, if in the future, we encounter a significant need for liquidity domestically or at a particular location that we cannot fulfill through borrowings, equity offerings, or other internal or external sources, we may determine that cash repatriations are necessary. Repatriation could result in additional material U.S. federal and state income tax payments in future years. Such adverse consequences would occur, for example, if the transfer of cash into the United States is taxed and no foreign tax credit is available to offset the U.S. tax liability, resulting in higher taxes. These factors may cause us to have an overall tax rate higher than other companies or higher than our tax rates have been in the past.

[0001628280-16-020392:mdna:82]
As of October 1, 2016, our consolidated balance of cash and cash equivalents increased by $9.7 million, to $166.8 million from $157.1 million as of July 2, 2016. The increase in cash and cash equivalents was mainly due to operating activities during the three months ended October 1, 2016.

[0001628280-16-020392:mdna:83]
[same as prior period, unchanged from 0001628280-16-015527:mdna:115]

[0001628280-16-020392:mdna:84]
Cash provided by operating activities was $36.3 million during the three months ended October 1, 2016, primarily resulting from $3.4 million of net loss and $44.1 million of non-cash items such as depreciation, stock-based compensation, amortization of intangibles and unrealized loss on derivative liability, offset by changes in operating assets and liabilities of $4.4 million. Changes in our operating assets and liabilities related primarily to a decrease in accounts receivable of $14.0 million due to an increase in billings as well as the timing of payments from these customers, a decrease in accrued expenses and other current and non-current liabilities of $1.6 million is due to  the timing of invoices and payments to vendors, offset by an increase in accounts payable of $14.2 million related to the growth in our business, an increase in inventories of $3.0 million, and an increase in income tax payable of $1.3 million.

[0001628280-16-020392:mdna:85]
Cash provided by operating activities was $10.6 million during the three months ended September 26, 2015, primarily resulting from $0.2 million of net loss and $17.5 million of non-cash items such as depreciation, stock-based compensation, amortization of intangibles and unrealized gain on derivative liability, partially offset by changes in operating assets and liabilities of $6.7 million. Changes in our operating assets and liabilities related primarily to a decrease in accounts receivable of $8.6 million, an increase in deferred taxes of $0.2 million, a decrease in prepayments other current and non-currents assets of $6.4 million, an increase in accounts payable of $8.3 million, a decrease in inventories of $5.4 million, and an increase in accrued payroll and related expenses, accrued expenses and other current and non-current liabilities of $5.2 million.

[0001628280-16-020392:mdna:86]
[same as prior period, unchanged from 0001628280-16-015527:mdna:118]

[0001628280-16-020392:mdna:87]
Cash used in investing activities was for capital expenditures of $28.9 million and $13.9 million during the three months ended October 1, 2016 and September 26, 2015, respectively.

[0001628280-16-020392:mdna:88]
[same as prior period, unchanged from 0001628280-16-015527:mdna:120]

[0001628280-16-020392:mdna:89]
Cash provided by financing activities was $2.3 million during the three months ended October 1, 2016 resulting primarily from proceeds of stock option exercises.

[0001628280-16-020392:mdna:90]
Cash provided by financing activities was $130.7 million during the three months ended September 26, 2015 resulting primarily from net transfers from Viavi.

[0001628280-16-020392:mdna:91]
[same as prior period, unchanged from 0001628280-16-015527:mdna:123]

[0001628280-16-020392:mdna:92]
We expect our primary liquidity and capital spending requirements over at least the next 12 months to be the funding of our operating activities and capital expenditures. We believe that our cash and cash equivalents as of October 1, 2016, and cash flows

[0001628280-16-020392:mdna:93]
from our operating activities will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months. However, if market conditions are favorable, we may evaluate alternatives to opportunistically pursue liquidity options.

[0001628280-16-020392:mdna:94]
There are a number of factors that could positively or negatively impact our liquidity position, including:

[0001628280-16-020392:mdna:95]
[same as prior period, unchanged from 0001628280-16-015527:mdna:125]

[0001628280-16-020392:mdna:96]
[same as prior period, unchanged from 0001628280-16-015527:mdna:126]

[0001628280-16-020392:mdna:97]
| • | increase in capital expenditures to support our business and growth; |

[0001628280-16-020392:mdna:98]
[same as prior period, unchanged from 0001628280-16-015527:mdna:128]

[0001628280-16-020392:mdna:99]
[same as prior period, unchanged from 0001628280-16-015527:mdna:129]

[0001628280-16-020392:mdna:100]
[same as prior period, unchanged from 0001628280-16-015527:mdna:130]

[0001628280-16-020392:mdna:101]
| • | volatility in fixed income and credit which impact the liquidity and valuation of our investment portfolios; |

[0001628280-16-020392:mdna:102]
[same as prior period, unchanged from 0001628280-16-015527:mdna:132]

[0001628280-16-020392:mdna:103]
| • | possible investments or acquisitions of complementary businesses, products or technologies, or other strategic transactions or partnerships; |

[0001628280-16-020392:mdna:104]
| • | issuance of debt or equity securities, or other financing transactions, including bank debt; and |

[0001628280-16-020392:mdna:105]
[same as prior period, unchanged from 0001628280-16-015527:mdna:135]

[0001628280-16-020392:mdna:106]
33
