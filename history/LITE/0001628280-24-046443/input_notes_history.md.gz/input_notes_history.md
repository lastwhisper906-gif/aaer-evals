# LITE note change history — 0001628280-24-020767 → 0001628280-24-046443


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-11-08):
[0001628280-24-046443:note_history:1]
Our purchase obligations of $589.2 million as of September 28, 2024 represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and
  (was, 2024-05-07, similarity 0.7438):
[0001628280-24-020767:note_history:1]
Our purchase obligations of $369.8 million as of March 30, 2024 represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

- added (2024-11-08):
[0001628280-24-046443:note_history:2]
adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

- added (2024-11-08):
[0001628280-24-046443:note_history:3]
|  | Three Months Ended |  |  |
|  | September 28, 2024 |  | September 30, 2023 |  |  |  |  |
| Balance as of beginning of period | $ | 13.2 |  |  | $ | 6.8 |  |  |  |  |  |
| Warranties assumed in Cloud Light acquisition | 0.8 |  |  | — |  |  |  |  |  |
| Provision for warranty | 2.4 |  |  | 0.2 |  |  |  |  |  |
| Utilization of reserve, net | (3.2) |  |  | (1.5) |  |  |  |  |  |
| Balance as of end of period | $ | 13.2 |  |  | $ | 5.5 |  |  |  |  |  |

- changed (2024-11-08):
[0001628280-24-046443:note_history:4]
We are subject to a variety of claims and suits that arise from time-to-time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss. During the year ended June 29, 2024, we recorded $7.8 million with respect to the pending settlement of certain non-ordinary course litigation matters which has been settled as of September 28, 2024.
  (was, 2024-05-07, similarity 0.9184):
[0001628280-24-020767:note_history:4]
We are subject to a variety of claims and suits that arise from time-to-time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss. During the year ended July 1, 2023, we recorded $7.8 million with respect to the pending settlement of certain non-ordinary course litigation matters under accrued expenses in our consolidated balance sheet, which has not been settled as of March 30, 2024.

- changed (2024-11-08):
[0001628280-24-046443:note_history:5]
In connection with our acquisition of Oclaro in 2018, seven lawsuits were filed by purported stockholders of Oclaro challenging the proposed merger (the “Merger”). All but one was voluntarily dismissed after the Oclaro Merger closed. The remaining lawsuit, SaiSravan B. Karri v. Oclaro, Inc., et al., No. 3:18-cv-03435-JD (the “Karri Lawsuit”), was filed in the United States District Court for the Northern District of California and was styled as a class action.
  (was, 2024-05-07, similarity 0.9967):
[0001628280-24-020767:note_history:5]
In connection with our acquisition of Oclaro in 2018, seven lawsuits were filed by purported stockholders of Oclaro challenging the proposed merger (the “Merger”). All but one was voluntarily dismissed after the Oclaro Merger closed. The remaining lawsuit, SaiSravan B. Karri v. Oclaro, Inc., et al., No. 3:18-cv-03435-JD (the “Karri Lawsuit”), was filed in the United States District Court for the Northern District of California and is styled as a class action.

- changed (2024-11-08):
[0001628280-24-046443:note_history:6]
The Karri Lawsuit alleged, among other things, that Oclaro and its directors violated Section 14(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), and Rule 14a-9 promulgated thereunder by disseminating an incomplete and misleading Form S-4, including proxy statement/prospectus. The Karri Lawsuit further alleged that Oclaro’s directors violated Section 20(a) of the Exchange Act by failing to exercise proper control over the person(s) who violated Section 14(a) of the Exchange Act. The plaintiff in the Karri Lawsuit sought, among other things, damages to be awarded to the plaintiff and any class, if a class is certified, and litigation costs, including attorneys’ fees.
  (was, 2024-05-07, similarity 0.992):
[0001628280-24-020767:note_history:6]
The Karri Lawsuit alleges, among other things, that Oclaro and its directors violated Section 14(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), and Rule 14a-9 promulgated thereunder by disseminating an incomplete and misleading Form S-4, including proxy statement/prospectus. The Karri Lawsuit further alleged that Oclaro’s directors violated Section 20(a) of the Exchange Act by failing to exercise proper control over the person(s) who violated Section 14(a) of the Exchange Act. The plaintiff in the Karri Lawsuit seeks, among other things, damages to be awarded to the plaintiff and any class, if a class is certified, and litigation costs, including attorneys’ fees.

- added (2024-11-08):
[0001628280-24-046443:note_history:7]
The case proceeded through fact and expert discovery and the parties subsequently reached an agreement for a class-wide settlement of the Karri Lawsuit that provided for a payment of $15.3 million to the members of the class. On August 17, 2023, the court preliminarily approved the settlement. In March 2024, the court finally approved the settlement.

- changed (2024-11-08):
[0001628280-24-046443:note_history:8]
We recorded the court approved settlement amount of $15.3 million as accrued expenses in our condensed consolidated balance sheet as of June 29, 2024, of which $7.5 million represents the amount to be reimbursed by insurance and was recorded as prepayments and other current assets. As of September 28, 2024, this litigation matter has been settled.
  (was, 2024-05-07, similarity 0.8841):
[0001628280-24-020767:note_history:8]
We recorded the court approved settlement amount of $15.3 million as accrued expenses in our condensed consolidated balance sheet as of March 30, 2024, of which $7.5 million represents the amount to be reimbursed by insurance and was recorded as prepayments and other current assets.

- added (2024-11-08):
[0001628280-24-046443:note_history:9]
Regulatory Matters

- added (2024-11-08):
[0001628280-24-046443:note_history:10]
In August 2024, the Company received inquiries from the Bureau of Industry and Security of the U.S. Department of Commerce (“BIS”) and Department of Justice (“DOJ”) following the Company’s voluntary disclosure to BIS in December 2023, and supplemented in April 2024. The Company continues to cooperate with both agencies on this matter.  The Company is unable to predict the likely outcome of these matters.

- changed (2024-11-08):
[0001628280-24-046443:note_history:11]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown, because claims may be made against us in the future, and we may record charges in the future as a result of these indemnification obligations. As of September 28, 2024, we did not have any material indemnification claims that were probable or reasonably possible.
  (was, 2024-05-07, similarity 0.7939):
[0001628280-24-020767:note_history:11]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown, because claims may be made against us in the future, and we may record charges in the future as a result of these indemnification obligations. As of March 30, 2024, we did not have any material indemnification claims that were probable or reasonably possible.

- removed (2024-11-08):
[0001628280-24-020767:note_history:12]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |  | March 30, 2024 |  | April 1, 2023 |
| Balance as of beginning of period | $ | 10.1 |  |  | $ | 8.4 |  |  | $ | 6.8 |  |  | $ | 10.0 |  |
| Warranties assumed in NeoPhotonics merger | — |  |  | — |  |  | — |  |  | 0.7 |  |
| Warranty assumed from Cloud Light | 3.0 |  |  | — |  |  | 8.2 |  |  | — |  |
| Provision for warranty | 2.6 |  |  | 1.1 |  |  | 3.6 |  |  | 5.4 |  |
| Utilization of reserve, net | (2.2) |  |  | (2.7) |  |  | (5.1) |  |  | (9.3) |  |
| Balance as of end of period | $ | 13.5 |  |  | $ | 6.8 |  |  | $ | 13.5 |  |  | $ | 6.8 |  |

- removed (2024-11-08):
[0001628280-24-020767:note_history:13]
After the plaintiff in the Karri Lawsuit was appointed as lead plaintiff and his counsel as lead counsel, the plaintiff filed a first amended complaint on April 15, 2019. The first amended complaint, also named Lumentum as a defendant but Lumentum has since been dismissed from the action. On October 8, 2020, the court granted in part and denied in part the defendant’s motion to dismiss the first amended complaint. On December 1, 2020, defendants answered the first amended complaint. On September 17, 2021, lead plaintiff filed a second amended complaint. Defendants moved to stay discovery in light of the second amended complaint. On January 11, 2022, the Court struck the second amended complaint as untimely, terminated defendants’ motions to dismiss as moot, and lifted the stay. The case proceeded through fact and expert discovery.

- removed (2024-11-08):
[0001628280-24-020767:note_history:14]
On August 16, 2022, the lead plaintiff moved for class certification and to be appointed class representative. Defendants opposed the motion. The action subsequently was stayed while the parties participated in a mediation. On January 18, 2023, the lead plaintiff filed a Notice of Settlement informing the court of an agreement in principle between the parties for a class-wide settlement of the Karri Lawsuit. On January 24, 2023, in light of the potential settlement, the court vacated all pretrial and trial dates and ordered the lead plaintiff to file a motion for preliminary approval of the settlement by March 17, 2023. The lead plaintiff filed his motion for preliminary approval of the settlement on March 16, 2023, and defendants filed a statement of non-opposition on March 30, 2023. On April 20, 2023, the court held a hearing on lead plaintiff’s motion for preliminary approval of the settlement. The court declined to grant lead plaintiff’s motion for preliminary approval and ordered lead plaintiff to file a revised motion by May 22, 2023. Lead plaintiff filed his Revised Motion for Preliminary Approval of Settlement (the “Amended Motion”) on May 22, 2023, defendants filed a response in support of the Amended Motion on June 5, 2023, and the lead plaintiff submitted his reply on June 12, 2023. The hearing on the Amended Motion took place on August 17, 2023 and the court preliminarily approved the settlement. In March 2024, the court approved the settlement amount of $15.3 million.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2024-11-08):
[0001628280-24-046443:note_history:15]
Lumentum Holdings Inc. (“we,” “us,” “our,” “Lumentum” or the “Company”) is an industry-leading provider of optical and photonic products essential to a range of cloud, artificial intelligence and machine learning (“AI/ML”), telecommunications, consumer, and industrial end-market applications. We operate in two end-market focused reportable segments, Cloud & Networking and Industrial Tech.

- changed (2024-11-08):
[0001628280-24-046443:note_history:16]
Our Cloud & Networking products include a comprehensive portfolio of optical and photonic chips, modules, and subsystems supplied to cloud data center operator, AI/ML infrastructure provider, and network equipment manufacturer customers who are building cloud data center and network infrastructures. Our products enable high-capacity optical data links in cloud, AI/ML, and data center interconnect (“DCI”) applications, and communications service provider networks, including in access (local), metro (intracity), long-haul (city-to-city and worldwide), and submarine (undersea) network infrastructure. Our Cloud & Networking products also support network equipment manufacturers building enterprise network infrastructure, including storage-area networks (“SANs”), local-area networks (“LANs”) and wide-area networks (“WANs”). Demand for our Cloud & Networking products is driven by the continual growth in network capacity required for cloud computing and services, including for AI/ML, streaming video and video conferencing, wireless and mobile devices, and internet of things (“IoT”).
  (was, 2024-05-07, similarity 0.7688):
[0001628280-24-020767:note_history:16]
Our Cloud & Networking products include a comprehensive portfolio of optical and photonic components, modules, and subsystems supplied to network operator and network equipment manufacturer customers building cloud data center infrastructure, including that for artificial intelligence and machine learning (“AI/ML”) and data center interconnect (“DCI”) applications, and communications service provider networks, including in access (local), metro (intracity), long-haul (city-to-city and worldwide), and submarine (undersea) network infrastructure. Our Cloud & Networking products also support network equipment manufacturers building enterprise network infrastructure, including storage-area networks (“SANs”), local-area networks (“LANs”) and wide-area networks (“WANs”). Demand for our Cloud & Networking products is driven by the continual growth in network capacity required for cloud computing and services, including for AI/ML, streaming video and video conferencing, wireless and mobile devices, and internet of things (“IoT”).

- changed (2024-11-08):
[0001628280-24-046443:note_history:17]
Our Industrial Tech products include short pulse solid-state lasers, kilowatt-class fiber lasers, diode lasers, and gas lasers, which address applications in numerous end-markets. In the consumer end-market, our laser light sources are integrated into our customers’ 3D sensing cameras, which are used in mobile devices, payment kiosks, and other consumer electronics devices to enable applications including biometric identification, computational photography and virtual and augmented reality. In the automotive end-market, our lasers are used in our customers’ LiDAR and other optical sensor devices, which are increasingly being used in advanced driver assistance systems (“ADAS”) and in-cabin driver and occupant monitoring systems. In the industrial manufacturing end-market, our lasers are incorporated into our customers’ manufacturing machine tools used for the precision processing of materials in a range of industries including semiconductor device and microelectronics fabrication, electric vehicle and battery production, metal cutting and welding, and advanced manufacturing. Our products can also be used in the industrial end-market in imaging and sensing systems for process feedback and control, quality assurance, and waste reduction. Adoption of our products in the industrial end-market is driven by the needs of customers to advance semiconductor and microelectronics industry roadmaps, and by Industry 4.0/5.0 trends, including increasing manufacturing precision and flexibility and reducing waste and environmental impact. Demand for our products in the industrial end-market is driven by end-customer investments in manufacturing capacity. Our lasers also address certain semiconductor inspection and life-science applications.
  (was, 2024-05-07, similarity 0.9966):
[0001628280-24-020767:note_history:17]
Our Industrial Tech products include solid-state lasers, kilowatt-class fiber lasers, diode lasers, and gas lasers, which address applications in numerous end-markets. In the consumer end-market, our laser light sources are integrated into our customers’ 3D sensing cameras, which are used in mobile devices, payment kiosks, and other consumer electronics devices to enable applications including biometric identification, computational photography and virtual and augmented reality. In the automotive end-market, our lasers are used in our customers’ LiDAR and other optical sensor devices, which are increasingly being used in advanced driver assistance systems (“ADAS”) and in-cabin driver and occupant monitoring systems. In the industrial manufacturing end-market, our lasers are incorporated into our customers’ manufacturing machine tools used for the precision processing of materials in a range of industries including semiconductor device and microelectronics fabrication, electric vehicle and battery production, metal cutting and welding, and advanced manufacturing. Our products can also be used in the industrial end-market in imaging and sensing systems for process feedback and control, quality assurance, and waste reduction. Adoption of our products in the industrial end-market is driven by the needs of customers to advance semiconductor and microelectronics industry roadmaps, and by Industry 4.0/5.0 trends, including increasing manufacturing precision and flexibility and reducing waste and environmental impact. Demand for our products in the industrial end-market is driven by end-customer investments in manufacturing capacity. Our lasers also address certain semiconductor inspection and life-science applications.

- added (2024-11-08):
[0001628280-24-046443:note_history:18]
We are continuously monitoring both the current developments in the ongoing Russia-Ukraine war including the related export controls and resulting sanctions imposed on Russia and Belarus by the U.S. and other countries, and the ongoing conflicts in the Middle East. Additional factors, such as increased inflation, escalating energy prices and the related cost increases, could continue to impact the global economy and our business. Although the global implications of these wars are difficult to predict at this time, we do not presently foresee direct material adverse effects on our business.

- added (2024-11-08):
[0001628280-24-046443:note_history:19]
On November 7, 2023, we completed the acquisition of Cloud Light Technology Limited (“Cloud Light”). We have applied the acquisition method of accounting to account for this transaction in accordance with ASC Topic 805, Business Combinations. Our condensed consolidated financial statements include the operating results of the acquired entities from the acquisition close date. Refer to “Note 4. Business Combinations” for further discussions of this transaction.

- changed (2024-11-08):
[0001628280-24-046443:note_history:20]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2025 is a 52-week year ending on June 28, 2025, with the quarter ended September 28, 2024 being a 13-week quarterly period. Our fiscal 2024 was a 52-week year that ended on June 29, 2024, with the quarter ended September 30, 2023 being a 13-week quarterly period.
  (was, 2024-05-07, similarity 0.7252):
[0001628280-24-020767:note_history:20]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2024 is a 52-week year ending on June 29, 2024, with the quarter ended March 30, 2024 being a 13-week quarterly period. Our fiscal 2023 was a 52-week year that ended on July 1, 2023, with the quarter ended April 1, 2023 being a 13-week quarterly period.

- changed (2024-11-08):
[0001628280-24-046443:note_history:21]
Accounting Policies
The condensed consolidated financial statements and accompanying notes should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the fiscal year ended June 29, 2024. There were no significant changes to our accounting policies during the three months ended September 28, 2024
  (was, 2024-05-07, similarity 0.9157):
[0001628280-24-020767:note_history:21]
Accounting Policies
The condensed consolidated financial statements and accompanying notes should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the fiscal year ended July 1, 2023. There were no significant changes to our accounting policies during the nine months ended March 30, 2024

- removed (2024-11-08):
[0001628280-24-020767:note_history:22]
Lumentum Holdings Inc. (“we,” “us,” “our,” “Lumentum” or the “Company”) is an industry-leading provider of optical and photonic products that address a range of end-market applications that include cloud data center and optical communications network infrastructure, consumer electronic devices, automobiles, and high-precision manufacturing.

- removed (2024-11-08):
[0001628280-24-020767:note_history:23]
Prior to fiscal year 2024, we operated in two reportable segments consisting of Optical Communications (“OpComms”) and Commercial Lasers (“Lasers”). During the fiscal first quarter of 2024, we changed our organizational structure to better align with trends in our markets and our customer and product mix. Our new operating segments are Cloud & Networking and Industrial Tech. The Cloud & Networking segment includes the Telecom and Datacom product lines that were previously part of the OpComms segment. The Industrial Tech segment includes the previous Lasers segment and the Industrial & Consumer product lines that were previously part of the OpComms segment. Comparative prior period segment information has been recast to conform to the new segment structure and measures. The changes in our operating segments had no impact on our previously reported consolidated results of operations, financial condition, or cash flows. Refer to “Note 15. Operating Segments and Geographic Information”.

- removed (2024-11-08):
[0001628280-24-020767:note_history:24]
We are continuously monitoring both the current developments in the ongoing war between Russia and Ukraine including the related additional export controls and resulting sanctions imposed on Russia and Belarus by the U.S. and other countries, and the Israel-Hamas war. Additional factors, such as increased inflation, escalating energy costs, constrained raw material availability and the related cost increases, could continue to impact the global economy and our business. Although the global implications of the wars are difficult to predict at this time, we do not presently foresee direct material adverse effects on our business.

- removed (2024-11-08):
[0001628280-24-020767:note_history:25]
On November 7, 2023 (the “Closing date”), we completed the acquisition of Cloud Light Technology Limited (“Cloud Light”). Our condensed consolidated financial statements include the operating results of Cloud Light from the Closing date. On August 3, 2022, we completed the acquisition of NeoPhotonics Corporation (“NeoPhotonics”). On August 15, 2022, we completed the acquisition of IPG Photonics’ telecom transmission product lines. We have applied the acquisition method of accounting to account for these transactions in accordance with ASC Topic 805, Business Combinations. Refer to “Note 4. Business Combinations” for further discussions of these transactions.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-11-08):
[0001628280-24-046443:note_history:26]
| September 28, 2024 |  |  | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | Total |  |  |  |  |  |
| Principal |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,514.7 |  |  |  |  |  |  |
| Unamortized debt discount and debt issuance costs |  |  | (2.6) |  |  | (4.1) |  |  | (4.1) |  |  | (10.8) |  |  |  |  |  |  |
| Net carrying amount of the liability component |  |  | $ | 1,047.4 |  |  | $ | 856.9 |  |  | $ | 599.6 |  |  | $ | 2,503.9 |  |  |  |  |  |  |
  (was, 2024-05-07, similarity 0.984):
[0001628280-24-020767:note_history:26]
| March 30, 2024 |  |  | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | Total |  |  |  |  |  |
| Principal |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,514.7 |  |  |  |  |  |  |
| Unamortized debt discount and debt issuance costs |  |  | (3.2) |  |  | (4.5) |  |  | (4.6) |  |  | (12.3) |  |  |  |  |  |  |
| Net carrying amount of the liability component |  |  | $ | 1,046.8 |  |  | $ | 856.5 |  |  | $ | 599.1 |  |  | $ | 2,502.4 |  |  |  |  |  |  |

- changed (2024-11-08):
[0001628280-24-046443:note_history:27]
| June 29, 2024 |  |  | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | Total |
| Principal |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,514.7 |  |
| Unamortized debt discount and debt issuance costs |  |  | (2.8) |  |  | (4.4) |  |  | (4.3) |  |  | (11.5) |  |
| Net carrying amount of the liability component |  |  | $ | 1,047.2 |  |  | $ | 856.6 |  |  | $ | 599.4 |  |  | $ | 2,503.2 |  |
  (was, 2024-05-07, similarity 0.7931):
[0001628280-24-020767:note_history:27]
| July 1, 2023 | 2024 Notes |  | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | Total |
| Principal | $ | 323.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,837.8 |  |
| Unamortized debt discount and debt issuance costs | (11.5) |  |  | (4.1) |  |  | (5.5) |  |  | (5.1) |  |  | (26.2) |  |
| Net carrying amount of the liability component | $ | 311.6 |  |  | $ | 1,045.9 |  |  | $ | 855.5 |  |  | $ | 598.6 |  |  | $ | 2,811.6 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-11-08):
[0001628280-24-046443:note_history:28]
On June 16, 2023, we issued $603.7 million in aggregate principal amount of 1.50% Convertible Senior Notes due in 2029 (“2029 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended. The 2029 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association, (as successor in interest to U.S. Bank National Association), as a trustee (the “2029 Indenture”). The 2029 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.
  (was, 2024-05-07, similarity 0.9992):
[0001628280-24-020767:note_history:28]
On June 16, 2023, we issued $603.7 million in aggregate principal amount of 1.50% Convertible Senior Notes due in 2029 (“2029 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended. The 2029 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association, (as successor in interest to U.S. Bank National Association), as a trustee (the “2029 Indenture”). The 2029 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

- added (2024-11-08):
[0001628280-24-046443:note_history:29]
On or after September 15, 2029 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2029 Notes at any time. Following our irrevocable settlement method election made on September 25, 2024, upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2029 Notes by delivering cash equal to the principal amount of such converted 2029 Notes and cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof.

- changed (2024-11-08):
[0001628280-24-046443:note_history:30]
The entire 2029 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of September 28, 2024 and June 29, 2024, measured at amortized cost.
  (was, 2024-05-07, similarity 0.956):
[0001628280-24-020767:note_history:30]
The entire 2029 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of March 30, 2024 and July 1, 2023, measured at amortized cost.

- changed (2024-11-08):
[0001628280-24-046443:note_history:31]
In March 2022, we issued $861.0 million in aggregate principal amount of 0.50% Convertible Senior Notes due in 2028 (the “2028 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2028 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2028 Indenture”). The 2028 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.
  (was, 2024-05-07, similarity 0.9992):
[0001628280-24-020767:note_history:31]
In March 2022, we issued $861.0 million in aggregate principal amount of 0.50% Convertible Senior Notes due in 2028 (the “2028 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2028 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2028 Indenture”). The 2028 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

- changed (2024-11-08):
[0001628280-24-046443:note_history:32]
•during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the 2028 Notes for each trading day of such
  (was, 2024-05-07, similarity 0.7129):
[0001628280-24-020767:note_history:32]
•during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the 2028 Notes for each trading day of such measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the applicable conversion rate on each such trading day;

- added (2024-11-08):
[0001628280-24-046443:note_history:33]
measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the applicable conversion rate on each such trading day;

- added (2024-11-08):
[0001628280-24-046443:note_history:34]
On or after March 15, 2028 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2028 Notes at any time. Following our irrevocable settlement method election made on September 25, 2024, upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2028 Notes by delivering cash equal to the principal amount of such converted 2028 Notes and cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof.

- changed (2024-11-08):
[0001628280-24-046443:note_history:35]
We initially bifurcated the principal amount of the 2028 Notes into liability and equity components. The liability component of the 2028 Notes was initially valued at $629.8 million based on the contractual cash flow discounted at an appropriate comparable market on non-convertible debt borrowing rate at the date of issuance, which was 5.7%, with the equity component representing the residual amount of the proceeds of $231.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2028 Notes were accounted for as a single liability measured at amortized cost. The entire 2028 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of September 28, 2024 and June 29, 2024, measured at amortized cost.
  (was, 2024-05-07, similarity 0.9881):
[0001628280-24-020767:note_history:35]
We initially bifurcated the principal amount of the 2028 Notes into liability and equity components. The liability component of the 2028 Notes was initially valued at $629.8 million based on the contractual cash flow discounted at an appropriate comparable market on non-convertible debt borrowing rate at the date of issuance, which was 5.7%, with the equity component representing the residual amount of the proceeds of $231.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2028 Notes were accounted for as a single liability measured at amortized cost. The entire 2028 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of March 30, 2024 and July 1, 2023, measured at amortized cost.

- changed (2024-11-08):
[0001628280-24-046443:note_history:36]
In December 2019, we issued $1,050.0 million in aggregate principal amount of 0.50% Convertible Senior Notes due in 2026 (the “2026 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2026 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association (as successor in interest to U.S. Bank National Association, as trustee (as supplemented by the First Supplemental Indenture, dated as of September 25, 2024, the “2026 Indenture”). We used approximately $196.0 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan credit facility, and a portion of the net proceeds of the offering to purchase approximately $200.0 million of our common stock concurrently with the pricing of the offering in privately negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.
  (was, 2024-05-07, similarity 0.8691):
[0001628280-24-020767:note_history:36]
In December 2019, we issued $1,050.0 million in aggregate principal amount of 0.50% Convertible Senior Notes due in 2026 (the “2026 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2026 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association, as trustee (the “2026 Indenture”). We used approximately $196.0 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan credit facility, and a portion of the net proceeds of the offering to purchase approximately $200.0 million of our common stock concurrently with the pricing of the offering in privately negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

- changed (2024-11-08):
[0001628280-24-046443:note_history:37]
The initial conversion rate is 10.0711 shares of common stock per $1,000 principal amount of the 2026 Notes (which is equivalent to an initial conversion price of approximately $99.29 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2026 Indenture but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2026 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares set forth in the 2026 Indenture or a holder that elects to convert the 2026 Notes in connection with such make-whole fundamental change or notice of redemption.
  (was, 2024-05-07, similarity 0.9993):
[0001628280-24-020767:note_history:37]
The initial conversion rate is 10.0711 shares of common stock per $1,000 principal amount of the 2026 Notes (which is equivalent to an initial conversion price of approximately $99.29 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2026 Indenture, but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2026 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares set forth in the 2026 Indenture or a holder that elects to convert the 2026 Notes in connection with such make-whole fundamental change or notice of redemption.

- added (2024-11-08):
[0001628280-24-046443:note_history:38]
On or after September 15, 2026 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2026 Notes at any time. Following our entry into the First Supplemental Indenture, dated as of September 25, 2024, to the 2026 Indenture, upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2026 Notes by delivering cash equal to the principal amount of such converted 2026 Notes and cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof.

- changed (2024-11-08):
[0001628280-24-046443:note_history:39]
We initially bifurcated the principal amount of the 2026 Notes into liability and equity components. The liability component of the 2026 Notes was initially valued at $734.8 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 5.8% with the equity component representing the residual amount of the proceeds of $315.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2026 Notes were accounted for as a single liability measured at amortized cost. The entire 2026 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of September 28, 2024 and June 29, 2024, measured at amortized cost.
  (was, 2024-05-07, similarity 0.988):
[0001628280-24-020767:note_history:39]
We initially bifurcated the principal amount of the 2026 Notes into liability and equity components. The liability component of the 2026 Notes was initially valued at $734.8 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 5.8% with the equity component representing the residual amount of the proceeds of $315.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2026 Notes were accounted for as a single liability measured at amortized cost. The entire 2026 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of March 30, 2024 and July 1, 2023, measured at amortized cost.

- changed (2024-11-08):
[0001628280-24-046443:note_history:40]
The initial conversion rate of the 2024 Notes was 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which was equivalent to an initial conversion price of approximately $60.62 per share. The conversion rate was subject to adjustment upon the occurrence of certain specified events but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2024 Indenture) or our issuance of a notice of redemption, we were required to, in certain circumstances, increase the conversion rate by a number of additional
  (was, 2024-05-07, similarity 0.8969):
[0001628280-24-020767:note_history:40]
The initial conversion rate of the 2024 Notes was 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which was equivalent to an initial conversion price of approximately $60.62 per share. The conversion rate was subject to adjustment upon the occurrence of certain specified events but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2024 Indenture) or our issuance of a notice of redemption, we were required to, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elected to convert the 2024 Notes in connection with such make-whole fundamental change or notice of redemption.

- added (2024-11-08):
[0001628280-24-046443:note_history:41]
shares for a holder that elected to convert the 2024 Notes in connection with such make-whole fundamental change or notice of redemption.

- changed (2024-11-08):
[0001628280-24-046443:note_history:42]
Concurrent with the issuance of the 2029 Notes in June 2023, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 2024 Notes, which we accounted for as an extinguishment of liability. $13.5 million of the $132.8 million repurchase price was allocated to the conversion feature of the repurchased 2024 Notes, representing the fair value of the conversion feature at the date of the repurchase, and was recognized as a reduction of the stockholders’ equity. Additionally, since issuing the 2024 Notes, we converted a total of approximately $1.9 million of principal amount of the 2024 Notes, with less than $0.1 million of principle amount converted during the three months ended September 28, 2024.
  (was, 2024-05-07, similarity 0.9598):
[0001628280-24-020767:note_history:42]
Concurrent with the issuance of the 2029 Notes in June 2023, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 2024 Notes, which we accounted for as an extinguishment of liability. $13.5 million of the $132.8 million repurchase price was allocated to the conversion feature of the repurchased 2024 Notes, representing the fair value of the conversion feature at the date of the repurchase, and was recognized as a reduction of the stockholders’ equity. Additionally, since issuing the 2024 Notes, we converted a total of approximately $1.9 million of principal amount of the 2024 Notes, with less than $0.1 million of principle amount converted during the three and nine months ended March 30, 2024.

- changed (2024-11-08):
[0001628280-24-046443:note_history:43]
On March 15, 2024, the 2024 Notes maturity date, we fully repaid the remaining principal amount of $323.1 million. The
  (was, 2024-05-07, similarity 0.6481):
[0001628280-24-020767:note_history:43]
On March 15, 2024, the 2024 Notes maturity date, we fully repaid the remaining principal amount of $323.1 million. The conversion feature previously classified within stockholder’s equity was fully amortized as of the maturity date.

- added (2024-11-08):
[0001628280-24-046443:note_history:44]
conversion feature previously classified within stockholder’s equity was fully amortized as of the maturity date.

- added (2024-11-08):
[0001628280-24-046443:note_history:45]
On September 25, 2024, Lumentum entered into the First Supplemental Indenture to the 2029 Indenture, 2028 Indenture and 2026 Indenture, pursuant to which we irrevocably elected to settle the principal amounts of the 2029 Notes, 2028 Notes and 2026 Notes in cash. Any amounts due above the principal may be settled in cash, equity, or any combination thereof at the election of the Company.

- changed (2024-11-08):
[0001628280-24-046443:note_history:46]
| September 28, 2024 |  |  | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | Total |  |  |  |  |  |
| Principal |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,514.7 |  |  |  |  |  |  |
| Unamortized debt discount and debt issuance costs |  |  | (2.6) |  |  | (4.1) |  |  | (4.1) |  |  | (10.8) |  |  |  |  |  |  |
| Net carrying amount of the liability component |  |  | $ | 1,047.4 |  |  | $ | 856.9 |  |  | $ | 599.6 |  |  | $ | 2,503.9 |  |  |  |  |  |  |
  (was, 2024-05-07, similarity 0.984):
[0001628280-24-020767:note_history:46]
| March 30, 2024 |  |  | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | Total |  |  |  |  |  |
| Principal |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,514.7 |  |  |  |  |  |  |
| Unamortized debt discount and debt issuance costs |  |  | (3.2) |  |  | (4.5) |  |  | (4.6) |  |  | (12.3) |  |  |  |  |  |  |
| Net carrying amount of the liability component |  |  | $ | 1,046.8 |  |  | $ | 856.5 |  |  | $ | 599.1 |  |  | $ | 2,502.4 |  |  |  |  |  |  |

- changed (2024-11-08):
[0001628280-24-046443:note_history:47]
| June 29, 2024 |  |  | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | Total |
| Principal |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,514.7 |  |
| Unamortized debt discount and debt issuance costs |  |  | (2.8) |  |  | (4.4) |  |  | (4.3) |  |  | (11.5) |  |
| Net carrying amount of the liability component |  |  | $ | 1,047.2 |  |  | $ | 856.6 |  |  | $ | 599.4 |  |  | $ | 2,503.2 |  |
  (was, 2024-05-07, similarity 0.7931):
[0001628280-24-020767:note_history:47]
| July 1, 2023 | 2024 Notes |  | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | Total |
| Principal | $ | 323.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,837.8 |  |
| Unamortized debt discount and debt issuance costs | (11.5) |  |  | (4.1) |  |  | (5.5) |  |  | (5.1) |  |  | (26.2) |  |
| Net carrying amount of the liability component | $ | 311.6 |  |  | $ | 1,045.9 |  |  | $ | 855.5 |  |  | $ | 598.6 |  |  | $ | 2,811.6 |  |

- changed (2024-11-08):
[0001628280-24-046443:note_history:48]
|  | Three Months Ended |  |  |
|  | September 28, 2024 |  | September 30, 2023 |  |  |  |  |
| Contractual interest expense | $ | 4.7 |  |  | $ | 4.8 |  |  |  |  |  |
| Amortization of the debt discount and debt issuance costs | 0.7 |  |  | 4.9 |  |  |  |  |  |
| Total interest expense | $ | 5.4 |  |  | $ | 9.7 |  |  |  |  |  |
  (was, 2024-05-07, similarity 0.7284):
[0001628280-24-020767:note_history:48]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |  | March 30, 2024 |  | April 1, 2023 |
| Contractual interest expense | $ | 4.9 |  |  | $ | 2.7 |  |  | $ | 14.6 |  |  | $ | 8.1 |  |
| Amortization of the debt discount and debt issuance costs | 4.1 |  |  | 6.0 |  |  | 13.8 |  |  | 17.9 |  |
| Total interest expense | $ | 9.0 |  |  | $ | 8.7 |  |  | $ | 28.4 |  |  | $ | 26.0 |  |

- changed (2024-11-08):
[0001628280-24-046443:note_history:49]
The future interest and principal payments related to our convertible notes are as follows as of September 28, 2024 (in millions):
  (was, 2024-05-07, similarity 0.9593):
[0001628280-24-020767:note_history:49]
The future interest and principal payments related to our convertible notes are as follows as of March 30, 2024 (in millions):

- changed (2024-11-08):
[0001628280-24-046443:note_history:50]
| Fiscal Years |  |  | 2026 Notes |  | 2028 Notes |  | 2029 Notes |  | Total |
| 2025 |  |  | $ | 5.3 |  |  | $ | 4.3 |  |  | $ | 9.1 |  |  | $ | 18.7 |  |
| 2026 |  |  | 5.3 |  |  | 4.3 |  |  | 9.1 |  |  | 18.7 |  |
| 2027 |  |  | 1,052.5 |  |  | 4.3 |  |  | 9.1 |  |  | 1,065.9 |  |
| 2028 |  |  | — |  |  | 865.3 |  |  | 9.1 |  |  | 874.4 |  |
| 2029 |  |  | — |  |  | — |  |  | 617.1 |  |  | 617.1 |  |
| Total payments |  |  | $ | 1,063.1 |  |  | $ | 878.2 |  |  | $ | 653.5 |  |  | $ | 2,594.8 |  |
  (was, 2024-05-07, similarity 0.9317):
[0001628280-24-020767:note_history:50]
| Fiscal Years |  |  | 2026 Notes |  | 2028 Notes |  | 2029 Notes |  | Total |
| 2024 |  |  | $ | 2.6 |  |  | $ | 2.2 |  |  | $ | 4.6 |  |  | $ | 9.4 |  |
| 2025 |  |  | 5.3 |  |  | 4.3 |  |  | 9.1 |  |  | 18.7 |  |
| 2026 |  |  | 5.3 |  |  | 4.3 |  |  | 9.1 |  |  | 18.7 |  |
| 2027 |  |  | 1,052.5 |  |  | 4.3 |  |  | 9.1 |  |  | 1,065.9 |  |
| 2028 |  |  | — |  |  | 865.3 |  |  | 9.1 |  |  | 874.4 |  |
| Thereafter |  |  | — |  |  | — |  |  | 617.1 |  |  | 617.1 |  |
| Total payments |  |  | $ | 1,065.7 |  |  | $ | 880.4 |  |  | $ | 658.1 |  |  | $ | 2,604.2 |  |

- added (2024-11-08):
[0001628280-24-046443:note_history:51]
Term Loans

- added (2024-11-08):
[0001628280-24-046443:note_history:52]
SMBC Term Loan

- added (2024-11-08):
[0001628280-24-046443:note_history:53]
On August 9, 2024, the Company entered into a term loan agreement with Sumitomo Mitsui Banking Corporation (“SMBC”). The SMBC term loan provides an aggregate principal amount of 6.4 billion Japanese yen (“JPY”). The loan requires monthly payments of the principal amounting to approximately 53.3 million JPY, which commenced on August 31, 2024 totaling approximately 3.1 billion JPY and interest based on a fixed annual interest rate of 0.88%, with the remaining principal of approximately 3.3 billion JPY due on the loan maturity date of July 31, 2029. Under the loan agreement, the Company cannot prepay the outstanding loan without SMBC’s approval.  In the event the Company prepays the outstanding loan with SMBC’s approval, the Company shall pay SMBC settlement money pursuant to the loan agreement. The term loan is secured by the real estate owned in Sagamihara, Japan.

- added (2024-11-08):
[0001628280-24-046443:note_history:54]
As of September 28, 2024, the Company has $44.5 million in principal amount outstanding, of which the short-term portion of $4.5 million is recorded as current liabilities while the long-term portion of $40.0 million is recorded as long-term debt in the Company’s condensed consolidated balance sheets.

- added (2024-11-08):
[0001628280-24-046443:note_history:55]
Mizuho Term Loan

- added (2024-11-08):
[0001628280-24-046443:note_history:56]
On September 20, 2024, the Company entered into a loan agreement with Mizuho Bank, Ltd. (the “Mizuho Term Loan”), in order to finance our planned manufacturing expansions. The Mizuho Term Loan provides for borrowings of 4.5 billion JPY with a 5-year term from the funding date September 20, 2024. The loan requires quarterly principal payments of approximately 225.0 million JPY commencing on December 20, 2024 with the final payment on September 20, 2029. The Mizuho Term Loan bears a fixed annual interest rate of 0.90%. The term loan is secured by the real estate assets owned by NeoPhotonics Semiconductor GK. The Mizuho Term Loan agreement requires that the Company and certain domestic subsidiaries comply with covenants relating to customary matters, including obtaining prior approval from lender in case of transferring, creating a security interest, or disposing the collateral assets; obtaining prior approval from lender in case of business transfer, business acquisition, corporate reorganization or changes as mergers, company splits, share exchanges or share transfers or capital structure changes; obtaining prior approval of the lender in case Lumentum Holdings Inc. changes its indirect ownership in Lumentum Japan, Inc; and obtaining prior approval from the lender in case Lumentum Japan, Inc. distributes dividends to its shareholders.

- added (2024-11-08):
[0001628280-24-046443:note_history:57]
As of September 28, 2024, the Company has $31.6 million in principal amount outstanding, of which the short-term portion of $6.3 million is recorded as current liabilities while the long-term portion of $25.3 million is recorded as long-term debt in the Company’s condensed consolidated balance sheets.

- removed (2024-11-08):
[0001628280-24-020767:note_history:58]
On or after September 15, 2029 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2029 Notes at any time. Upon conversion, we will satisfy our conversion obligation in cash, shares of common stock or a combination of cash and shares of common stock, at our election.

- removed (2024-11-08):
[0001628280-24-020767:note_history:59]
On or after March 15, 2028 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2028 Notes at any time. Upon conversion, we may satisfy our conversion obligation in cash, shares of common stock or a combination of cash and shares of common stock, at our election.

- removed (2024-11-08):
[0001628280-24-020767:note_history:60]
On or after September 15, 2026 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2026 Notes at any time. Upon conversion, we may satisfy our conversion obligation in cash, shares of common stock or a combination of cash and shares of common stock, at our election.

- removed (2024-11-08):
[0001628280-24-020767:note_history:61]
Mitsubishi Bank Loans

- removed (2024-11-08):
[0001628280-24-020767:note_history:62]
In connection with the NeoPhotonics acquisition, we assumed several loan agreements with MUFG Bank, Ltd. (the “Mitsubishi Bank Loans”) for an aggregate fair value of approximately $5.9 million, approximately $0.9 million of which was paid in the fiscal first quarter of 2023 and the remaining balance of approximately $5.0 million was fully paid in the fiscal second quarter of 2023.


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-11-08):
[0001628280-24-046443:note_history:63]
|  | Continuous Loss Position for More Than 12 Months |  | Continuous Loss Position for Less Than 12 Months |  | Gross Unrealized Losses |  |  |  |  |  |  |  |  |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |  |
| September 28, 2024: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 44.6 |  |  | $ | — |  |  | $ | 4.0 |  |  | $ | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 7.5 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 67.1 |  |  | (0.1) |  |  | 18.0 |  |  | — |  |  | (0.1) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 68.4 |  |  | (0.1) |  |  | 22.5 |  |  | — |  |  | (0.1) |  |  |  |  |  |  |  |  |  |
| Total | $ | 180.1 |  |  | $ | (0.2) |  |  | $ | 52.0 |  |  | $ | — |  |  | $ | (0.2) |  |  |  |  |  |  |  |  |  |
| June 29, 2024: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 62.3 |  |  | $ | (0.3) |  |  | $ | 12.6 |  |  | $ | — |  |  | $ | (0.3) |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 28.6 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 133.7 |  |  | (0.5) |  |  | 90.6 |  |  | (0.2) |  |  | (0.7) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 72.3 |  |  | (0.4) |  |  | 39.7 |  |  | (0.1) |  |  | (0.5) |  |  |  |  |  |  |  |  |  |
| Total | $ | 268.3 |  |  | $ | (1.2) |  |  | $ | 171.5 |  |  | $ | (0.3) |  |  | $ | (1.5) |  |  |  |  |  |  |  |  |  |
  (was, 2024-05-07, similarity 0.7296):
[0001628280-24-020767:note_history:63]
|  | Continuous Loss Position for More Than 12 Months |  | Continuous Loss Position for Less Than 12 Months |  | Gross Unrealized Losses |  |  |  |  |  |  |  |  |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |  |
| March 30, 2024: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 3.5 |  |  | $ | — |  |  | $ | 89.2 |  |  | $ | (0.4) |  |  | $ | (0.4) |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 13.1 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 21.6 |  |  | (0.1) |  |  | 175.7 |  |  | (0.7) |  |  | (0.8) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 2.0 |  |  | — |  |  | 117.6 |  |  | (0.7) |  |  | (0.7) |  |  |  |  |  |  |  |  |  |
| Total | $ | 27.1 |  |  | $ | (0.1) |  |  | $ | 395.6 |  |  | $ | (1.8) |  |  | $ | (1.9) |  |  |  |  |  |  |  |  |  |
| July 1, 2023: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 39.6 |  |  | $ | (0.4) |  |  | $ | 170.6 |  |  | $ | (1.3) |  |  | $ | (1.7) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | — |  |  | 7.7 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 128.5 |  |  | (0.2) |  |  | (0.2) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 93.6 |  |  | (1.2) |  |  | 358.9 |  |  | (2.7) |  |  | (3.9) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 50.8 |  |  | (0.6) |  |  | 221.4 |  |  | (1.4) |  |  | (2.0) |  |  |  |  |  |  |  |  |  |
| Total | $ | 184.0 |  |  | $ | (2.2) |  |  | $ | 887.1 |  |  | $ | (5.6) |  |  | $ | (7.8) |  |  |  |  |  |  |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-11-08):
[0001628280-24-046443:note_history:64]
The future interest and principal payments related to our convertible notes are as follows as of September 28, 2024 (in millions):
  (was, 2024-05-07, similarity 0.9593):
[0001628280-24-020767:note_history:64]
The future interest and principal payments related to our convertible notes are as follows as of March 30, 2024 (in millions):

- changed (2024-11-08):
[0001628280-24-046443:note_history:65]
| Fiscal Years |  |  | 2026 Notes |  | 2028 Notes |  | 2029 Notes |  | Total |
| 2025 |  |  | $ | 5.3 |  |  | $ | 4.3 |  |  | $ | 9.1 |  |  | $ | 18.7 |  |
| 2026 |  |  | 5.3 |  |  | 4.3 |  |  | 9.1 |  |  | 18.7 |  |
| 2027 |  |  | 1,052.5 |  |  | 4.3 |  |  | 9.1 |  |  | 1,065.9 |  |
| 2028 |  |  | — |  |  | 865.3 |  |  | 9.1 |  |  | 874.4 |  |
| 2029 |  |  | — |  |  | — |  |  | 617.1 |  |  | 617.1 |  |
| Total payments |  |  | $ | 1,063.1 |  |  | $ | 878.2 |  |  | $ | 653.5 |  |  | $ | 2,594.8 |  |
  (was, 2024-05-07, similarity 0.9317):
[0001628280-24-020767:note_history:65]
| Fiscal Years |  |  | 2026 Notes |  | 2028 Notes |  | 2029 Notes |  | Total |
| 2024 |  |  | $ | 2.6 |  |  | $ | 2.2 |  |  | $ | 4.6 |  |  | $ | 9.4 |  |
| 2025 |  |  | 5.3 |  |  | 4.3 |  |  | 9.1 |  |  | 18.7 |  |
| 2026 |  |  | 5.3 |  |  | 4.3 |  |  | 9.1 |  |  | 18.7 |  |
| 2027 |  |  | 1,052.5 |  |  | 4.3 |  |  | 9.1 |  |  | 1,065.9 |  |
| 2028 |  |  | — |  |  | 865.3 |  |  | 9.1 |  |  | 874.4 |  |
| Thereafter |  |  | — |  |  | — |  |  | 617.1 |  |  | 617.1 |  |
| Total payments |  |  | $ | 1,065.7 |  |  | $ | 880.4 |  |  | $ | 658.1 |  |  | $ | 2,604.2 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-11-08):
[0001628280-24-046443:note_history:66]
|  | Three Months Ended |  |  |
|  | September 28, 2024 |  | September 30, 2023 |  |  |  |  |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  |  |  |  |  |  |  |  |
| Cloud & Networking | $ | 282.3 |  |  | 83.8 | % |  | 229.7 |  |  | 72.3 | % |  |  |  |  |  |  |  |  |
| Industrial Tech | 54.6 |  |  | 16.2 | % |  | 87.9 |  |  | 27.7 | % |  |  |  |  |  |  |  |  |
| Net revenue | $ | 336.9 |  |  | 100.0 | % |  | $ | 317.6 |  |  | 100.0 | % |  |  |  |  |  |  |  |  |
  (was, 2024-05-07, similarity 0.6353):
[0001628280-24-020767:note_history:66]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |  | March 30, 2024 |  | April 1, 2023 |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Cloud & Networking | $ | 313.8 |  |  | 85.6 | % |  | 293.0 |  |  | 76.4 | % |  | $ | 830.2 |  |  | 79.0 | % |  | $ | 1,036.0 |  |  | 74.2 | % |
| Industrial Tech | 52.7 |  |  | 14.4 | % |  | 90.4 |  |  | 23.6 | % |  | 220.7 |  |  | 21.0 | % |  | 360.2 |  |  | 25.8 | % |
| Net revenue | $ | 366.5 |  |  | 100.0 | % |  | $ | 383.4 |  |  | 100.0 | % |  | $ | 1,050.9 |  |  | 100.0 | % |  | $ | 1,396.2 |  |  | 100.0 | % |

- added (2024-11-08):
[0001628280-24-046443:note_history:67]
| Contract balances |  | Balance sheet location |  | September 28, 2024 |  | June 29, 2024 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 198.5 |  |  | $ | 194.7 |  |  | $ | 3.8 |  |  | 2.0 | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | 0.6 |  |  | $ | 0.6 |  |  | $ | — |  |  | — | % |

- removed (2024-11-08):
[0001628280-24-020767:note_history:68]
| Contract balances |  | Balance sheet location |  | March 30, 2024 |  | July 1, 2023 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 229.8 |  |  | $ | 246.1 |  |  | $ | (16.3) |  |  | (6.6) | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | 0.8 |  |  | $ | 2.1 |  |  | $ | (1.3) |  |  | (61.9) | % |
