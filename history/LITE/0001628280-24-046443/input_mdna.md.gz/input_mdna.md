# LITE MD&A — 0001628280-24-046443


## mdna

[0001628280-24-046443:mdna:1]
[same as prior period, unchanged from 0001628280-24-020767:mdna:1]

[0001628280-24-046443:mdna:2]
[same as prior period, unchanged from 0001628280-24-020767:mdna:2]

[0001628280-24-046443:mdna:3]
[same as prior period, unchanged from 0001628280-24-020767:mdna:3]

[0001628280-24-046443:mdna:4]
40

[0001628280-24-046443:mdna:5]
[same as prior period, unchanged from 0001628280-24-020767:mdna:4]

[0001628280-24-046443:mdna:6]
We are an industry-leading provider of optical and photonic products defined by revenue and market share, essential to range of cloud, artificial intelligence and machine learning (“AI/ML”), telecommunications, consumer, and industrial end-market applications.

[0001628280-24-046443:mdna:7]
We have two operating segments, Cloud & Networking and Industrial Tech. The two operating segments were primarily determined based on how the Chief Operating Decision Maker (“CODM”) views and evaluates our operations. Operating results are regularly reviewed by the CODM to make decisions about resources to be allocated to the segments and to assess their performance. Other factors, including market separation and customer specific applications, go-to-market channels, products and manufacturing, are considered in determining the formation of these operating segments.

[0001628280-24-046443:mdna:8]
We believe the global markets in which Lumentum participates have fundamentally robust, long-term trends that will increase the need for our photonics products and technologies. We believe the world is becoming more reliant on ever-increasing amounts of data flowing through optical networks and data centers. Lumentum’s products and technology enable the scaling of these optical networks and data centers to higher capacities. The advent of AI/ML has caused a dramatic surge in the growing demands on data networking in cloud data centers and accelerated the usage of optical components and modules. We expect that the accelerating shift to digital and virtual approaches to many aspects of work and life will continue into the future. Virtual meetings, video calls, and hybrid in-person and virtual environments for work and other aspects of life will continue to drive strong needs for bandwidth growth and present dynamic new challenges that our technology addresses. As manufacturers demand higher levels of precision, new materials, and factory and energy efficiency, suppliers of manufacturing tools globally are turning to laser-based approaches, including the types of lasers Lumentum supplies. Laser-based 3D sensing and LiDAR for security, industrial and automotive applications are rapidly developing markets. The technology enables computer vision applications that enhance security, safety, and new functionality in the electronic devices that people rely on every day. The use of LiDAR and in-cabin 3D sensing in automobile and delivery vehicles over time significantly adds to our long-term market opportunity. Additionally, we expect 3D-enabled machine vision solutions to expand significantly in industrial applications in the coming years.

[0001628280-24-046443:mdna:9]
[same as prior period, unchanged from 0001628280-24-020767:mdna:7]

[0001628280-24-046443:mdna:10]
[same as prior period, unchanged from 0001628280-24-020767:mdna:11]

[0001628280-24-046443:mdna:11]
Our Cloud & Networking products include comprehensive portfolio of optical and photonic chips, components, modules, and subsystems supplied to cloud data center operator, AI/ML infrastructure provider, and network equipment manufacturer customers who are building cloud data center and network infrastructures. Our products enable high-capacity optical links in cloud, AI/ML and DCI applications, and communications service provider networks, including products for access (local), metro (intracity), long-haul (city-to-city and worldwide) and submarine (undersea) network infrastructure. Our Cloud & Networking products also support network equipment manufacturers building enterprise network infrastructure, including SANs, LANs, and WANs. Demand for our Cloud & Networking products is driven by the continual growth in network capacity required for cloud computing and services, including for AI/ML, streaming video and video conferencing, wireless and mobile services, and IoT.

[0001628280-24-046443:mdna:12]
[same as prior period, unchanged from 0001628280-24-020767:mdna:13]

[0001628280-24-046443:mdna:13]
Our Industrial Tech products include short pulse solid-state lasers, kilowatt-class fiber lasers, diode lasers, and gas lasers, which address applications in numerous end-markets. In the consumer end-market, our laser light sources are integrated into our customers’ 3D sensing cameras, which are used in mobile devices, payment kiosks, and other consumer electronics devices to enable applications including biometric identification, computational photography and virtual and augmented reality. In the automotive end-market, our lasers are used in our customers’ LiDAR and other optical sensor devices, which are increasingly being used in advanced driver assistance systems (“ADAS”) and in-cabin driver and occupant monitoring systems. In the industrial manufacturing end-market, our lasers are incorporated into our customers’ manufacturing machine tools used for the precision processing of materials in a range of industries including semiconductor device and microelectronics fabrication, electric vehicle and battery production, metal cutting and welding, and advanced manufacturing. Our products can also be used in the industrial end-market in imaging and sensing systems for process feedback and control, quality assurance, and waste

[0001628280-24-046443:mdna:14]
reduction. Adoption of our products in the industrial end-market is driven by the needs of customers to advance semiconductor and microelectronics industry roadmaps, and by Industry 4.0/5.0 trends, including increasing manufacturing precision and flexibility and reducing waste and environmental impact. Demand for our products in the industrial end-market is driven by end-customer investments in manufacturing capacity. Our lasers also address certain semiconductor inspection and life-science applications.

[0001628280-24-046443:mdna:15]
[same as prior period, unchanged from 0001628280-24-020767:mdna:15]

[0001628280-24-046443:mdna:16]
On November 7, 2023 (the “Cloud Light Closing Date”), we completed the acquisition of Cloud Light. Cloud Light designs, markets, and manufactures advanced optical modules for data center interconnect applications. The acquisition enables us to be well-positioned to serve the growing needs of cloud & networking customers, particularly those focused on optimizing their data center infrastructure for the demands of AI/ML. On the Cloud Light Closing Date, we paid $705.0 million of total cash consideration to Cloud Light. Additionally, each of Cloud Light’s outstanding options was exchanged for a combination of cash and options to acquire Lumentum common stock having equivalent value (the “replacement options”). These replacement options have a total fair value of $38.9 million as of the Cloud Light Closing Date, of which $23.5 million attributed to pre-acquisition service is recorded as part of purchase price consideration and the remaining $15.4 million is recorded as post-acquisition stock-based compensation expense over the vesting period of three years from the Cloud Light Closing Date. We incurred a total of $9.6 million of acquisition-related costs, representing professional and other direct acquisition costs, which was recorded as general and administrative expense in the consolidated statement of operations for the year ended June 29, 2024. Refer to “Note 4. Business Combinations” in the notes to condensed consolidated financial statements.

[0001628280-24-046443:mdna:17]
[same as prior period, unchanged from 0001628280-24-020767:mdna:17]

[0001628280-24-046443:mdna:18]
[same as prior period, unchanged from 0001628280-24-020767:mdna:18]

[0001628280-24-046443:mdna:19]
Our business and our customers’ businesses were negatively impacted by worldwide logistics and supply chain issues during the COVID-19 pandemic, including constraints on available cargo capabilities and limited availability of once broadly available supplies of both raw materials and finished components. COVID-19 also created dynamics in the semiconductor component supply chains that have led to shortages of the types of components we and our customers require in our products. Although the supply chain constraints started to improve in the latter half of fiscal 2023, we felt its ongoing effects in fiscal 2024, as described below, and these constraints or effects may impact our ability to supply our products to our customers and may reduce our revenue and profit margin if they continue to reoccur. In addition, if our customers are unable to procure needed semiconductor components, their demand for our products will decrease. Due to the global supply chain constraints, we had to incur incremental supply and procurement costs in order to increase our ability to fulfill demands from our customers.

[0001628280-24-046443:mdna:20]
In addition, in response to component shortages, certain of our customers accumulated inventory that they began managing down in fiscal year 2024 as supply conditions improved. Accordingly, customer orders have declined in recent periods and certain customers have not taken the shipments we had originally projected due to their inventory management.  As customers have been managing their inventory down, our revenue has declined and our margins have been adversely impacted as we have not able to fully recover costs, such as underutilized manufacturing capacity. However, we have recently seen signs of inventory normalization at network equipment manufacturers during the first fiscal quarter of 2025.

[0001628280-24-046443:mdna:21]
[same as prior period, unchanged from 0001628280-24-020767:mdna:21]

[0001628280-24-046443:mdna:22]
[same as prior period, unchanged from 0001628280-24-020767:mdna:22]

[0001628280-24-046443:mdna:23]
[same as prior period, unchanged from 0001628280-24-020767:mdna:23]

[0001628280-24-046443:mdna:24]
[same as prior period, unchanged from 0001628280-24-020767:mdna:24]

[0001628280-24-046443:mdna:25]
[same as prior period, unchanged from 0001628280-24-020767:mdna:25]

[0001628280-24-046443:mdna:26]
[same as prior period, unchanged from 0001628280-24-020767:mdna:26]

[0001628280-24-046443:mdna:27]
[same as prior period, unchanged from 0001628280-24-020767:mdna:27]

[0001628280-24-046443:mdna:28]
[same as prior period, unchanged from 0001628280-24-020767:mdna:28]

[0001628280-24-046443:mdna:29]
Management’s Discussion and Analysis of Financial Condition and Results of Operations contained in Part II, Item 7 of our Annual Report on Form 10-K for our fiscal year ended June 29, 2024 provides a complete discussion of our critical accounting policies and estimates. There have been no changes to these policies during the three months ended September 28, 2024.

[0001628280-24-046443:mdna:30]
Recently Issued Accounting Pronouncements

[0001628280-24-046443:mdna:31]
Refer to “Note 2. Recently Issued Accounting Pronouncements” in the notes to condensed consolidated financial statements.

[0001628280-24-046443:mdna:32]
[same as prior period, unchanged from 0001628280-24-020767:mdna:32]

[0001628280-24-046443:mdna:33]
[same as prior period, unchanged from 0001628280-24-020767:mdna:34]

[0001628280-24-046443:mdna:34]
|  | Three Months Ended |  |  |
|  | September 28, 2024 |  | September 30, 2023 |  |  |  |  |
| Segment net revenue: |  |  |  |  |  |  |  |
| Cloud & Networking | 83.8 | % |  | 72.3 | % |  |  |  |  |
| Industrial Tech | 16.2 |  |  | 27.7 | % |  |  |  |  |
| Net revenue | 100.0 |  |  | 100.0 |  |  |  |  |  |
| Cost of sales | 70.2 |  |  | 70.2 |  |  |  |  |  |
| Amortization of acquired developed intangibles | 6.7 |  |  | 5.7 |  |  |  |  |  |
| Gross profit | 23.1 |  |  | 24.1 |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 22.1 |  |  | 23.1 |  |  |  |  |  |
| Selling, general and administrative | 22.6 |  |  | 23.0 |  |  |  |  |  |
| Restructuring and related charges | 2.9 |  |  | 3.5 |  |  |  |  |  |
| Total operating expenses | 47.6 |  |  | 49.6 |  |  |  |  |  |
| Loss from operations | (24.5) |  |  | (25.4) |  |  |  |  |  |
| Interest expense | (1.6) |  |  | (3.0) |  |  |  |  |  |
| Other income, net | 2.6 |  |  | 6.7 |  |  |  |  |  |
| Loss before income taxes | (23.5) |  |  | (21.8) |  |  |  |  |  |
| Income tax provision (benefit) | 0.9 |  |  | (0.4) |  |  |  |  |  |
| Net loss | (24.5) | % |  | (21.4) | % |  |  |  |  |

[0001628280-24-046443:mdna:35]
44

[0001628280-24-046443:mdna:36]
Financial data for the three months ended September 28, 2024

[0001628280-24-046443:mdna:37]
[same as prior period, unchanged from 0001628280-24-020767:mdna:38]

[0001628280-24-046443:mdna:38]
|  | Three Months Ended |  |  |  |  |  |  |
|  | September 28, 2024 |  | September 30, 2023 |  | Change |  | Percentage Change |  |  |  |  |  |  |  |  |
| Segment net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cloud & Networking | $ | 282.3 |  |  | 229.7 |  |  | $ | 52.6 |  |  | 22.9 | % |  |  |  |  |  |  |  |  |
| Industrial Tech | 54.6 |  |  | 87.9 |  |  | (33.3) |  |  | (37.9) | % |  |  |  |  |  |  |  |  |
| Net revenue | $ | 336.9 |  |  | $ | 317.6 |  |  | $ | 19.3 |  |  | 6.1 | % |  |  |  |  |  |  |  |  |
| Gross profit | $ | 77.9 |  |  | $ | 76.7 |  |  | $ | 1.2 |  |  | 1.6 | % |  |  |  |  |  |  |  |  |
| Gross margin | 23.1 | % |  | 24.1 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 74.3 |  |  | $ | 73.5 |  |  | $ | 0.8 |  |  | 1.1 | % |  |  |  |  |  |  |  |  |
| Percentage of net revenue | 22.1 | % |  | 23.1 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative | $ | 76.3 |  |  | $ | 73.0 |  |  | $ | 3.3 |  |  | 4.5 | % |  |  |  |  |  |  |  |  |
| Percentage of net revenue | 22.6 | % |  | 23.0 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring and related charges | $ | 9.7 |  |  | $ | 11.0 |  |  | $ | (1.3) |  |  | (11.8) | % |  |  |  |  |  |  |  |  |
| Percentage of net revenue | 2.9 | % |  | 3.5 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0001628280-24-046443:mdna:39]
45

[0001628280-24-046443:mdna:40]
[same as prior period, unchanged from 0001628280-24-020767:mdna:40]

[0001628280-24-046443:mdna:41]
Net revenue increased by $19.3 million, or 6.1%, during the three months ended September 28, 2024 compared to the three months ended September 30, 2023, driven by a $52.6 million increase in Cloud & Networking revenue offset by a  $33.3 million decrease in Industrial Tech revenue. The increase in Cloud & Networking net revenue is primarily due to higher revenue from cloud and AI/ML customers, which increased by $71.0 million, inclusive of revenue from Cloud Light, which we acquired in the second quarter of fiscal 2024. This was partially offset by a reduction in shipments to a specific customer in China driven by U.S. trade restrictions. The decrease in Industrial Tech net revenue is primarily due to higher market competition in the consumer end-market, a reduction in demand due to declines in macro-economic factors globally year over year, and customers continuing to reduce high levels of inventory they purchased for security of supply during the COVID-19 pandemic.

[0001628280-24-046443:mdna:42]
During the three months ended September 28, 2024, two customers individually accounted for 15% and 12% of our total revenue, respectively. During the three months ended September 30, 2023, three customers individually accounted for 15%, 13% and 10% of our total net revenue, respectively. We had no other customers that represented 10% or greater of our total net revenue.

[0001628280-24-046443:mdna:43]
[same as prior period, unchanged from 0001628280-24-020767:mdna:46]

[0001628280-24-046443:mdna:44]
[same as prior period, unchanged from 0001628280-24-020767:mdna:47]

[0001628280-24-046443:mdna:45]
[same as prior period, unchanged from 0001628280-24-020767:mdna:48]

[0001628280-24-046443:mdna:46]
|  | Three Months Ended |  |  |
|  | September 28, 2024 |  | September 30, 2023 |  |  |  |  |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 65.4 |  |  | 19.4 | % |  | $ | 41.1 |  |  | 12.9 | % |  |  |  |  |  |  |  |  |
| Mexico | 33.9 |  |  | 10.0 |  |  | 23.7 |  |  | 7.5 |  |  |  |  |  |  |  |  |  |
| Other Americas | 2.9 |  |  | 0.9 |  |  | 1.2 |  |  | 0.4 |  |  |  |  |  |  |  |  |  |
| Total Americas | $ | 102.2 |  |  | 30.3 | % |  | $ | 66.0 |  |  | 20.8 | % |  |  |  |  |  |  |  |  |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 88.7 |  |  | 26.4 | % |  | $ | 64.9 |  |  | 20.4 | % |  |  |  |  |  |  |  |  |
| South Korea | 8.8 |  |  | 2.6 |  |  | 25.0 |  |  | 7.9 |  |  |  |  |  |  |  |  |  |
| Japan | 16.9 |  |  | 5.0 |  |  | 25.4 |  |  | 8.0 |  |  |  |  |  |  |  |  |  |
| Thailand | 52.5 |  |  | 15.6 |  |  | 64.2 |  |  | 20.2 |  |  |  |  |  |  |  |  |  |
| Other Asia-Pacific | 37.2 |  |  | 11.0 |  |  | 39.5 |  |  | 12.4 |  |  |  |  |  |  |  |  |  |
| Total Asia-Pacific | $ | 204.1 |  |  | 60.6 | % |  | $ | 219.0 |  |  | 68.9 | % |  |  |  |  |  |  |  |  |
| EMEA | $ | 30.6 |  |  | 9.1 | % |  | $ | 32.6 |  |  | 10.3 | % |  |  |  |  |  |  |  |  |
| Total net revenue | $ | 336.9 |  |  | 100.0 | % |  | $ | 317.6 |  |  | 100.0 | % |  |  |  |  |  |  |  |  |

[0001628280-24-046443:mdna:47]
For the three months ended September 28, 2024 and September 30, 2023, net revenue from customers outside the United States, based on customer shipping location, represented 80.6% and 87.1% of net revenue, respectively.

[0001628280-24-046443:mdna:48]
[same as prior period, unchanged from 0001628280-24-020767:mdna:52]

[0001628280-24-046443:mdna:49]
[same as prior period, unchanged from 0001628280-24-020767:mdna:53]

[0001628280-24-046443:mdna:50]
Gross margin for the three months ended September 28, 2024 decreased to 23.1% from 24.1% for the three months ended September 30, 2023. The 1% decrease was primarily due to less profitable mix of products, which impacted gross margin by 2%, mainly due to higher sales of laser chips and modules driven by AI and the cloud, which together have a lower than average margin compared to our other products. This was mostly offset by the impact of higher revenue. Gross margin was negatively impacted by approximately 4% due to lower factory utilization as a result of lower production levels, as customers continue to work to reduce their elevated inventory levels, as well as $4.4 million of higher amortization of intangibles due to the Cloud Light acquisition. This was partially offset by a $8.4 million decrease in excess and obsolete inventory charges, and approximately $5.5 million of lower post-acquisition charges such as integration and manufacturing consolidation.

[0001628280-24-046443:mdna:51]
The markets in which we sell products are undergoing product, architectural and business model transitions, have high customer concentrations, are highly competitive, are price sensitive and/or are affected by customer seasonal and variants in buying patterns. We expect these factors to result in variability of our gross margin and our gross margin maybe subject to increasing downward pressure due to these factors.

[0001628280-24-046443:mdna:52]
[same as prior period, unchanged from 0001628280-24-020767:mdna:57]

[0001628280-24-046443:mdna:53]
The following table summarizes segment profit (loss) for each of our operating segments for the periods presented (in millions):

[0001628280-24-046443:mdna:54]
|  | Three Months Ended |  |  |
|  | September 28, 2024 |  | September 30, 2023 |  |  |  |  |
| Cloud & Networking | $ | 36.5 |  |  | 23.9 |  |  |  |  |  |
| Industrial Tech | 2.2 |  |  | 15.3 |  |  |  |  |  |

[0001628280-24-046443:mdna:55]
Cloud & Networking segment profit increased by $12.6 million, or 52.7%, during the three months ended September 28, 2024 as compared to the three months ended September 30, 2023 primarily due to higher sales of laser chips and modules driven by AI and cloud demand, partially offset by lower sales from telecom products. Industrial Tech segment profit decreased by $13.1 million, or 85.6%, during the three months ended September 28, 2024 as compared to the three months ended September 30, 2023 primarily due to lower revenue, including lower sales of imaging and sensing products.

[0001628280-24-046443:mdna:56]
[same as prior period, unchanged from 0001628280-24-020767:mdna:62]

[0001628280-24-046443:mdna:57]
R&D expense increased by $0.8 million, or 1.1% for the three months ended September 28, 2024 compared to the three months ended September 30, 2023, primarily due to $2.9 million of higher spending in software and computer supplies used for R&D purposes and a charge of $1.9 million related to a write-off of in-process research and development intangible assets acquired from NeoPhotonics for projects that we subsequently decided not to pursue. These increases were partially offset by lower payroll related expenses as a result of restructuring actions.

[0001628280-24-046443:mdna:58]
We believe that continuing our investments in R&D is critical to attaining our strategic objectives. We plan to continue to invest in R&D and new products that we believe will further differentiate us in the marketplace.

[0001628280-24-046443:mdna:59]
[same as prior period, unchanged from 0001628280-24-020767:mdna:66]

[0001628280-24-046443:mdna:60]
SG&A expense increased by $3.3 million, or 4.5%, during the three months ended September 28, 2024 compared to the three months ended September 30, 2023. The increase was driven by $8.1 million of incremental amortization of intangible assets associated with the Cloud Light acquisition, substantially offset by a reduction in payroll related expenses as a result of recent restructuring actions and $3.2 million of lower outside consultant costs as a result of business and system integrations efforts being completed in the prior periods.

[0001628280-24-046443:mdna:61]
From time-to-time, we incur expenses that are not part of our ordinary operations, such as mergers and acquisition-related and litigation expenses, which generally increase our SG&A expenses and potentially impact our profitability expectations in

[0001628280-24-046443:mdna:62]
any particular period.

[0001628280-24-046443:mdna:63]
[same as prior period, unchanged from 0001628280-24-020767:mdna:70]

[0001628280-24-046443:mdna:64]
We have initiated various strategic restructuring events primarily intended to reduce costs, consolidate our operations, rationalize the manufacturing of our products, and align our business in response to market conditions and as a result of recent acquisitions.

[0001628280-24-046443:mdna:65]
During the three months ended September 28, 2024, we recorded restructuring and related charges of $9.7 million, which includes $6.0 million of asset write-offs primarily due to integration efforts to consolidate our sites, $3.0 million of charges related to the discontinuation of our in-house development of coherent DSPs and RFICs and the remaining restructuring charges due to company-wide cost reduction initiatives.

[0001628280-24-046443:mdna:66]
During the three months ended September 30, 2023, we recorded restructuring and related charges of $11.0 million in our condensed consolidated statements of operations, which were primarily due to company-wide  cost reduction initiatives,  as well as our integration efforts as a result of the merger with NeoPhotonics.

[0001628280-24-046443:mdna:67]
[same as prior period, unchanged from 0001628280-24-020767:mdna:74]

[0001628280-24-046443:mdna:68]
For the three months ended September 28, 2024 and September 30, 2023, we recorded interest expense of $5.5 million and $9.7 million, respectively. Interest expense is primarily driven by the amortization of the debt discount and issuance costs of our convertible notes. The decrease in interest expense for the three months ended September 28, 2024 is mainly due to the repayment of our 2024 Notes (as defined below) upon maturity in March 2024.

[0001628280-24-046443:mdna:69]
[same as prior period, unchanged from 0001628280-24-020767:mdna:76]

[0001628280-24-046443:mdna:70]
[same as prior period, unchanged from 0001628280-24-020767:mdna:77]

[0001628280-24-046443:mdna:71]
|  | Three Months Ended |  |  |  |  |
|  | September 28, 2024 |  | September 30, 2023 |  |  |  |  |  |  |
| Foreign exchange and other gains (losses), net | $ | (0.7) |  |  | $ | (0.5) |  |  |  |  |  |  |  |
| Interest and investment income, net | 9.4 |  |  | 21.7 |  |  |  |  |  |  |  |
| Total other income, net | $ | 8.7 |  |  | $ | 21.2 |  |  |  |  |  |  |  |

[0001628280-24-046443:mdna:72]
Other income, net for the three months ended September 28, 2024 decreased by $12.5 million compared to the three months ended September 30, 2023 primarily due to the lower short term investment balances, as we used cash to purchase Cloud Light as well as the repayment of the 2024 Notes in March 2024.

[0001628280-24-046443:mdna:73]
[same as prior period, unchanged from 0001628280-24-020767:mdna:81]

[0001628280-24-046443:mdna:74]
[same as prior period, unchanged from 0001628280-24-020767:mdna:82]

[0001628280-24-046443:mdna:75]
|  | Three Months Ended |  |  |
|  | September 28, 2024 |  | September 30, 2023 |  |  |  |  |
| Income tax provision (benefit) | $ | 3.2 |  |  | $ | (1.4) |  |  |  |  |  |

[0001628280-24-046443:mdna:76]
We recorded a tax provision of $3.2 million and a tax benefit of $1.4 million for the three  months ended September 28, 2024 and September 30, 2023, respectively. Our tax provision for the three months ended September 28, 2024 is primarily related to the tax expense associated with interest on uncertain tax positions, partially offset by the tax benefit from currency re-measurements.  Our tax provision for the three months ended September 30, 2023 includes a discrete tax benefit of $1.8 million primarily related to a tax benefit from changes in prior year uncertain tax positions, partially offset by the tax expenses related to a shortfall in connection with stock-based compensation vested during the quarter and foreign return to provision differences.

[0001628280-24-046443:mdna:77]
Our estimated effective tax rate for the three months ended September 28, 2024 differs from the 21% U.S. statutory rate primarily due to the income tax expense from foreign rate differential, non-deductible stock-based compensation, uncertain tax positions, and current year valuation allowance changes, partially offset by the income tax benefit from various income tax credits.

[0001628280-24-046443:mdna:78]
We regularly assess our ability to realize our deferred tax assets on a quarterly basis and will establish a valuation allowance if it is more-likely-than-not that some portion of the deferred tax assets will not be realized. As of September 28, 2024, we maintain a full valuation allowance on U.S. federal and state and certain foreign deferred tax assets. We will continue to assess the need for a valuation allowance against our remaining deferred tax assets and may increase or decrease our valuation allowance materially in the future.

[0001628280-24-046443:mdna:79]
[same as prior period, unchanged from 0001628280-24-020767:mdna:89]

[0001628280-24-046443:mdna:80]
[same as prior period, unchanged from 0001628280-24-020767:mdna:90]

[0001628280-24-046443:mdna:81]
[same as prior period, unchanged from 0001628280-24-020767:mdna:91]

[0001628280-24-046443:mdna:82]
[same as prior period, unchanged from 0001628280-24-020767:mdna:92]

[0001628280-24-046443:mdna:83]
As of September 28, 2024 and June 29, 2024, our cash and cash equivalents were $489.2 million and $436.7 million, respectively. As of September 28, 2024 and June 29, 2024, our short-term investments of $426.9 million and $450.3 million, respectively, were all held in the United States. Cash equivalents and short-term investments are primarily comprised of money market funds, treasuries, agencies, high quality investment grade fixed income securities, certificates of deposit and commercial paper. Our investment policy and strategy provide for diversification of investments and is focused on the preservation of capital and supporting our liquidity requirements.

[0001628280-24-046443:mdna:84]
The total amount of cash held by the non-United States entities as of September 28, 2024 and June 29, 2024 was $394.8 million and $306.9 million, respectively, which was primarily held by entities incorporated in the United Kingdom, the British Virgin Islands, Japan, Hong Kong, China, Switzerland, the Cayman Islands, Thailand and Brazil. Although cash currently held in the United States, as well as cash generated in the United States from future operations, is expected to cover our normal operating requirements, a substantial amount of additional cash could be required for other purposes, such as capital expenditures to support our business and growth, including costs associated with increasing internal manufacturing capabilities, strategic transactions and partnerships, and future acquisitions.

[0001628280-24-046443:mdna:85]
[same as prior period, unchanged from 0001628280-24-020767:mdna:95]

[0001628280-24-046443:mdna:86]
[same as prior period, unchanged from 0001628280-24-020767:mdna:96]

[0001628280-24-046443:mdna:87]
We believe that our cash and cash equivalents as of September 28, 2024 and cash flows from our operating activities will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months.

[0001628280-24-046443:mdna:88]
[same as prior period, unchanged from 0001628280-24-020767:mdna:98]

[0001628280-24-046443:mdna:89]
[same as prior period, unchanged from 0001628280-24-020767:mdna:99]

[0001628280-24-046443:mdna:90]
[same as prior period, unchanged from 0001628280-24-020767:mdna:100]

[0001628280-24-046443:mdna:91]
[same as prior period, unchanged from 0001628280-24-020767:mdna:101]

[0001628280-24-046443:mdna:92]
[same as prior period, unchanged from 0001628280-24-020767:mdna:102]

[0001628280-24-046443:mdna:93]
[same as prior period, unchanged from 0001628280-24-020767:mdna:103]

[0001628280-24-046443:mdna:94]
[same as prior period, unchanged from 0001628280-24-020767:mdna:104]

[0001628280-24-046443:mdna:95]
[same as prior period, unchanged from 0001628280-24-020767:mdna:105]

[0001628280-24-046443:mdna:96]
[same as prior period, unchanged from 0001628280-24-020767:mdna:106]

[0001628280-24-046443:mdna:97]
[same as prior period, unchanged from 0001628280-24-020767:mdna:107]

[0001628280-24-046443:mdna:98]
[same as prior period, unchanged from 0001628280-24-020767:mdna:108]

[0001628280-24-046443:mdna:99]
[same as prior period, unchanged from 0001628280-24-020767:mdna:109]

[0001628280-24-046443:mdna:100]
[same as prior period, unchanged from 0001628280-24-020767:mdna:110]

[0001628280-24-046443:mdna:101]
[same as prior period, unchanged from 0001628280-24-020767:mdna:111]

[0001628280-24-046443:mdna:102]
[same as prior period, unchanged from 0001628280-24-020767:mdna:112]

[0001628280-24-046443:mdna:103]
[same as prior period, unchanged from 0001628280-24-020767:mdna:113]

[0001628280-24-046443:mdna:104]
[same as prior period, unchanged from 0001628280-24-020767:mdna:114]

[0001628280-24-046443:mdna:105]
The following table summarizes our contractual obligations as of September 28, 2024, and the effect such obligations are expected to have on our liquidity and cash flow (in millions):

[0001628280-24-046443:mdna:106]
|  | Payments Due |
|  | Total |  | Less Than 1 Year |  | More Than 1 Year |  |  |  |  |
| Contractual Obligations |  |  |  |  |  |  |  |  |  |
| Asset retirement obligations | $ | 7.0 |  |  | $ | — |  |  | $ | 7.0 |  |  |  |  |  |
| Operating lease liabilities, including imputed interest (1) | 45.1 |  |  | 13.5 |  |  | 31.6 |  |  |  |  |  |
| Pension plan contributions (2) | 1.6 |  |  | 1.6 |  |  | — |  |  |  |  |  |
| Purchase obligations (3) | 589.2 |  |  | 542.9 |  |  | 46.3 |  |  |  |  |  |
| Term loans - principal (5) | 76.1 |  |  | 10.8 |  |  | 65.3 |  |  |  |  |  |
| Term loans - interest (5) | 2.2 |  |  | 0.6 |  |  | 1.6 |  |  |  |  |  |
| Convertible notes - principal (4) | 2,514.7 |  |  | — |  |  | 2,514.7 |  |  |  |  |  |
| Convertible notes - interest (4) | 80.1 |  |  | 18.7 |  |  | 61.4 |  |  |  |  |  |
| Total | $ | 3,316.0 |  |  | $ | 588.1 |  |  | $ | 2,727.9 |  |  |  |  |  |

[0001628280-24-046443:mdna:107]
(1) The amounts of operating lease liabilities do not include any sublease income amounts nor do they include payments for short-term leases or variable lease payments. As of September 28, 2024, we expect to receive sublease income of approximately $2.9 million over the sublease periods.

[0001628280-24-046443:mdna:108]
[same as prior period, unchanged from 0001628280-24-020767:mdna:118]

[0001628280-24-046443:mdna:109]
(3) Purchase obligations represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Refer to “Note 14. Commitments and Contingencies” in the notes to condensed consolidated financial statements.

[0001628280-24-046443:mdna:110]
(4) The amounts related to convertible notes include principal and interest on our 0.50% Convertible Senior Notes due 2026 (the “2026 Notes”), principal and interest on our 0.50% Convertible Senior Notes due 2028 (the “2028 Notes”), and principal and interest on our 1.50% Convertible Senior Notes due 2029 (the “2029 Notes”). The 2026 Notes have a maturity date of December 15, 2026, the 2028 Notes have a maturity date of June 15, 2028, and the 2029 Notes have a maturity date of December 15, 2029. The principal balances of our convertible notes are reflected in the payment periods in the table above based on their respective contractual maturities assuming no conversions. On March 15, 2024, the maturity date of the 2024 Notes, we repaid the outstanding $323.1 million principal amount of the 2024 Notes in full. Refer to “Note 9. Debt” in the notes to condensed consolidated financial statements.

[0001628280-24-046443:mdna:111]
(5) The amounts related to term loans include principal and interest on our Sumitomo Mitsui Banking Corporation (“SMBC”) term loan with a fixed annual interest rate of 0.88% and Mizuho Bank, Ltd. (“Mizuho”) term loan with a fixed annual interest rate of 0.90%. The SMBC term loan requires monthly principal payments with the remaining principal due on the loan maturity date of July 31, 2029 while the Mizuho term loan requires quarterly principal payments with the final payment date on September 20, 2029.

[0001628280-24-046443:mdna:112]
[same as prior period, unchanged from 0001628280-24-020767:mdna:121]

[0001628280-24-046443:mdna:113]
[same as prior period, unchanged from 0001628280-24-020767:mdna:122]

[0001628280-24-046443:mdna:114]
As of September 28, 2024, the net carrying amount of our 2029 Notes of $599.6 million (principal balance of $603.7 million maturing in 2029) is presented in non-current liabilities. If the closing price of our stock exceeds $90.40 (or 130% of the conversion price of $69.54) for 20 of the last 30 trading days of any future quarter, the 2029 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our consolidated balance sheets.

[0001628280-24-046443:mdna:115]
As of September 28, 2024, the net carrying amount of our 2028 Notes of $856.9 million (which have an aggregate principal amount of $861.0 million outstanding that matures in 2028) is presented in non-current liabilities in our condensed consolidated balance sheets. If the closing price of our stock exceeds $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of any future fiscal quarter, our 2028 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-24-046443:mdna:116]
As of September 28, 2024, the net carrying amount of our 2026 Notes of $1047.4 million (which have an aggregate principal amount of $1,050.0 million outstanding that matures in 2026) is presented in non-current liabilities in our condensed consolidated balance sheets. If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future fiscal quarter, our 2026 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-24-046443:mdna:117]
On March 15, 2024, our 0.25% Convertible Senior Notes due 2024 (the “2024 Notes”) reached maturity. We fully repaid the remaining principal amount of $323.1 million at the maturity date.

[0001628280-24-046443:mdna:118]
As of September 28, 2024, the Company has $44.5 million in principal amount outstanding on our SMBC term loan, of which the short-term portion of $4.5 million is recorded as current liabilities while the long-term portion of $40.0 million is recorded as long-term debt in the Company’s condensed consolidated balance sheets.

[0001628280-24-046443:mdna:119]
As of September 28, 2024, the Company has $31.6 million in principal amount outstanding on our Mizuho term loan, of which the short-term portion of $6.3 million is recorded as current liabilities while the long-term portion of $25.3 million is recorded as long-term debt in the Company’s condensed consolidated balance sheets.

[0001628280-24-046443:mdna:120]
[same as prior period, unchanged from 0001628280-24-020767:mdna:126]

[0001628280-24-046443:mdna:121]
We have a share buyback program that authorizes us to utilize up to an aggregate amount of $1.2 billion to purchase our own shares of common stock through May 2025. During the three months ended September 28, 2024 and September 30, 2023, we did not repurchase any shares of our common stock. Since the board of directors initially approved the share buyback program, we have repurchased 7.7 million shares in aggregate at an average price of $81.66 per share for a total purchase price of $630.4 million. We recorded the $630.4 million aggregate purchase price as a reduction of retained earnings within our condensed consolidated balance sheet. All repurchased shares were retired immediately. As of September 28, 2024, we have

[0001628280-24-046443:mdna:122]
$569.6 million remaining under the share buyback program.

[0001628280-24-046443:mdna:123]
[same as prior period, unchanged from 0001628280-24-020767:mdna:128]

[0001628280-24-046443:mdna:124]
[same as prior period, unchanged from 0001628280-24-020767:mdna:129]

[0001628280-24-046443:mdna:125]
As of September 28, 2024 and June 29, 2024, our other non-current liabilities include unrecognized tax benefit for uncertain tax positions of $94.4 million and $83.0 million, respectively. We are unable to reliably estimate the timing of future payments related to uncertain tax positions.

[0001628280-24-046443:mdna:126]
[same as prior period, unchanged from 0001628280-24-020767:mdna:131]

[0001628280-24-046443:mdna:127]
Our balance of cash and cash equivalents increased by $52.5 million from $436.7 million as of June 29, 2024 to $489.2 million as of September 28, 2024. The increase in cash and cash equivalents during the three months ended September 28, 2024 was due to cash from financing activities of $60.0 million and cash from operating activities of $39.6 million, offset by cash used in investing activities of $47.1 million.

[0001628280-24-046443:mdna:128]
[same as prior period, unchanged from 0001628280-24-020767:mdna:133]

[0001628280-24-046443:mdna:129]
Cash from operating activities was $39.6 million during the three months ended September 28, 2024, which reflects a net loss of $82.4 million, offset by non-cash items of $112.1 million and changes in operating assets and liabilities of $9.9 million. Changes in operating assets and liabilities were primarily driven by an increase in accounts payable of $32.6 million primarily due to higher inventory purchases and capital expenditures and an increase in income tax liabilities of $7.2 million primarily due to income tax provision for the three months ended September 28, 2024, offset by an increase of $16.6 million in prepayments and other current and non-current assets related mainly to value-added-tax receivables driven by higher recent capital expenditures and inventory purchases, and a decrease of $9.7 million in accrued expenses and other current and non-current liabilities primarily due to payment of the net settlement amount of the Oclaro merger litigation.

[0001628280-24-046443:mdna:130]
Cash used in operating activities was $2.3 million during the three months ended September 30, 2023, which reflects a net loss of $67.9 million and non-cash items of $89.9 million for the three months ended September 30, 2023, offset by $24.3 million changes in our operating assets and liabilities. Changes in our operating assets and liabilities were mainly driven by an increase in inventories of $16.8 million primarily due to purchases made to support our manufacturing transition and lower shipments than expected, a decrease in accounts payable of $28.0 million primarily due to lower purchases from our contract manufactures and linearity of payments, and a decrease in income taxes of $19.9 million due to annual income tax payment in Japan, offset by a decrease in accounts receivable of $26.1 million due to lower revenue.

[0001628280-24-046443:mdna:131]
[same as prior period, unchanged from 0001628280-24-020767:mdna:136]

[0001628280-24-046443:mdna:132]
Cash used in investing activities of $47.1 million during the three months ended September 28, 2024 was attributable to capital expenditures of $74.1 million, offset by net proceeds from sales or maturities of short-term investments of $26.8 million and proceeds from sales of property and equipment of $0.2 million.

[0001628280-24-046443:mdna:133]
Cash provided by investing activities of $17.8 million during the three months ended September 30, 2023 was attributable to the net proceeds from sales or maturities of short-term investments of $78.6 million partially offset by capital expenditures of $57.8 million and a $3.0 million payment for an intangible asset acquisition.

[0001628280-24-046443:mdna:134]
[same as prior period, unchanged from 0001628280-24-020767:mdna:139]

[0001628280-24-046443:mdna:135]
Cash from financing activities of $60.0 million during the three months ended September 28, 2024 was attributable to $76.5 million of proceeds from SMBC and Mizuho term loans and $0.9 million of proceeds from the exercise of stock options, offset by tax payments related to net share settlement of restricted stock of $16.0 million, payment for an intangible asset acquisition holdback of $1.0 million and $0.4 million of principal payments on term loans.

[0001628280-24-046443:mdna:136]
Cash used in financing activities of $12.9 million during the three months ended September 30, 2023 was attributable to tax payments related to net share settlement of restricted stock of $12.9 million.
