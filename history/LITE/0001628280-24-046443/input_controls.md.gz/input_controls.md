# LITE 10-Q controls and the auditor's report


## item_4_controls

[0001628280-24-046443:item_4_controls:1]
ITEM 4. CONTROLS AND PROCEDURES

[0001628280-24-046443:item_4_controls:2]
(a) Evaluation of Disclosure Controls and Procedures

[0001628280-24-046443:item_4_controls:3]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting. Management, with the participation of our chief executive officer and our chief financial officer, evaluated the effectiveness of our disclosure controls and procedures as of September 28, 2024. The term “disclosure controls and procedures,” as defined in Rules 13a-15 and 15d-15 under the Exchange Act, means controls and other procedures of a company that are designed to ensure that information required to be disclosed by a company in the reports that it files or submits under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in the SEC’s rules and forms. Disclosure controls and procedures include, without limitation, controls and procedures designed to ensure that information required to be disclosed by a company in the reports that it files or submits under the Exchange Act is accumulated and communicated to the company’s management, including its principal executive and principal financial officers, as appropriate to allow timely decisions regarding required disclosure. Management recognizes that any controls and procedures, no matter how well-designed and operated, can provide only reasonable assurance of achieving their objectives, and management necessarily applies its judgment in evaluating the cost-benefit relationship of possible controls and procedures. Based on the evaluation of our disclosure controls and procedures as of September 28, 2024, our chief executive officer and chief financial officer concluded that our disclosure controls and procedures were effective at a reasonable assurance level.

[0001628280-24-046443:item_4_controls:4]
(b) Changes in Internal Control over Financial Reporting

[0001628280-24-046443:item_4_controls:5]
There were no changes in our internal control over financial reporting identified in connection with the evaluation required by Exchange Act Rules 13a-15(d) or 15d-15(d) that occurred during the quarter ended September 28, 2024 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001628280-24-046443:item_4_controls:6]
(c)  Inherent Limitations on Effectiveness of Controls

[0001628280-24-046443:item_4_controls:7]
Our management, including the CEO and CFO, recognizes that our disclosure controls and procedures or our internal control over financial reporting cannot prevent or detect all possible instances of errors and all fraud. A control system, no matter how well designed and operated, can provide only reasonable, not absolute, assurance that the control system's objectives will be met. The design of a control system must reflect the fact that there are resource constraints, and the benefits of controls must be considered relative to their costs.

[0001628280-24-046443:item_4_controls:8]
54
